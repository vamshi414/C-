#!/usr/bin/perl -w
# UA5zip.pl
use Net::FTP;
########################
## main processing    ##
########################

#declare subroutines
sub copyFile;
sub processXML;
sub fixSize;
sub writeLog;

## default to unix command names
my $delcmd = "rm";
my $zipcmd = "gzip";
my $copyCommands = "copyCommands.txt";
my $vrolBatch = "";  ## Batch descriptor file
my $vrolXML = "";    ## Request descriptor file
my $inBatch = "";
my $inXML = "";
my $imagefile = "";  ## Zipped images
my $zipfile = "";    ## Main zip file containing previous 3 files
my $Docs = "N";
my ($day, $mon, $year)  = (localtime)[3,4,5];
$year += 1900;
$mon = sprintf("%02d",$mon+1);
$day = sprintf("%02d",$day);
my $logFile = "$year$mon\_UA5zip.txt";
open(LOG, '>>', $logFile) or die writeLog("Can not open log file: $!");
opendir (DIR, ".\\") or die writeLog("Couldn't open directory, $!");
my @files = readdir DIR;
closedir(DIR);
@files = grep /^BUA5/, @files;
$inBatch = $files[0];
print writeLog("\nPROCESSING STARTED AT: " . localtime());
if (length($inBatch) < 4) {
   die writeLog("No input files found. \n");
}
$inXML = "RUA5" . substr($files[0],4) ;
print writeLog ("Processing files : $inBatch ; $inXML\n");

## Readn config file
open(CONFIG,'<', "UA5zip.cfg") || die writeLog("Configuration file UA5zip.cfg is not found: $!");
while (<CONFIG>) {
    chomp;                  # no newline
    s/#.*//;                # no comments
    s/^\s+//;               # no leading white
    s/\s+$//;               # no trailing white
    next unless length;     # anything left?
    my ($var, $value) = split(/\s*=\s*/, $_, 2);
    $User_Preferences{$var} = $value;
}
close CONFIG;

## if windows update command names
if($^O eq "MSWin32") {
   $delcmd = "del";
   $zipcmd = "pkzip25";
}
processXML();

#copy image files to current directory for sizing and zipping
my $firstDoc = 1;
open(IN_COPY_COMMANDS,'<', $copyCommands) || die writeLog("Unable to open file $copyCommands: $!");
print writeLog("Processing image files...");
while(<IN_COPY_COMMANDS>) {
   my @words = split;
   s/$words[0]//;       #remove first and last words in the Command
   s/$words[-1]//;
   my $myline = $_;
   $myline =~ s/^\s+//;    #remove leading spaces
   $myline =~ s/\s+$//;    #remove trailing spaces
   my $in = $myline;
   my $out = $words[-1];
   my $size = 0;
   $size = copyFile($in,$out);
## fixSize($words[2],$size);
   if($^O eq "MSWin32") {
      system("$zipcmd -add -path=none -nozipextension $imagefile $out");
   }
   else{
      if($firstDoc) {
         $firstDoc = 0;
         system("tar cvf DUA5MD00.tar $out");
      }
      else{
         system("tar uvf DUA5MD00.tar $out");
      }
   }
  system("$delcmd $out");
}
close IN_COPY_COMMANDS;
if($^O eq "MSWin32") {
   #zip vrol.xml, header.xml and images.zip into bams.zip
   print writeLog("Adding file $vrolXML to $zipfile");
   system("$zipcmd -add -path=none -nozipextension $zipfile $vrolXML");
   print writeLog("Adding file $vrolBatch to $zipfile");
   system("$zipcmd -add -path=none -nozipextension $zipfile $vrolBatch");
   if ($imagefile) {
      print writeLog("Adding file $imagefile to $zipfile");
      system("$zipcmd -add -path=none -nozipextension $zipfile $imagefile");
      system("$delcmd $imagefile");
   }

   # FTP
   print writeLog("FTP is in progress ....\n Source File: $zipfile Dest File: " . $User_Preferences{"DatasetName"}.".".$zipfile . " Host: ". $User_Preferences{"HostName"});
   $ftpobj = Net::FTP -> new ($User_Preferences{"HostName"}) or die writeLog("Cannot connect to Host-" . $User_Preferences{"HostName"} .": $!");
   $ftpobj -> login($User_Preferences{"UserID"},$User_Preferences{"Password"})  or die writeLog("Cannot login to ftp ", $ftpobj->message);
   $ftpobj ->binary();
   $ftpobj -> put($zipfile, "'".$User_Preferences{"DatasetName"}.".".$zipfile."'") or die writeLog("Cannot FTP file: $!");
   print writeLog("FTP successful");
}
else {
   #zip docs.tar into docs.tar.gz
   system("$zipcmd -N -v DUA5MD00.tar");
   #tar vrol.xml, header.xml and doc.tar.gz into bams.tar
   system("tar cvf UA5MD00.tar vrolXML vrolBatch DUA5MD00.tar.gz");
   #zip vrol.tar into bams.tar.gz
   system("$delcmd UA5MD00.tar.gz"); #clean up old files
   system("$zipcmd -N -v UA5MD00.tar");
   system("$delcmd DUA5MD00.tar.gz");

}
   #delete intermediate files
   system("$delcmd $vrolXML");
   system("$delcmd $vrolBatch");
   system("$delcmd $copyCommands");
   system("$delcmd $inXML");
   system("$delcmd $inBatch");
   print writeLog("PROCESSING COMPLETED AT: " . localtime() . "\n\n");
   close LOG;
########################
##subroutines         ##
########################
## strip out embedded commands from XML file
sub processXML() {
   my $outXML = "outXML.txt";
   my $outBatch = "outBatch.txt";
   my $value1 = "";
   my $value2 = "";
   my $pat1 = "\<\\w*\>\\s*\<\/\\w*\>";
   my $pat2 =  "\<\\w*\/\>";
   my $outZip = "zipCommands.txt";
   open(IN_BATCH, '<',$inBatch) || die writeLog("Unable to open input file $inBatch: $!");
   open(IN_XML, '<',$inXML) || die writeLog("Unable to open input file $inXML: $!");
   open(OUT_XML, '>', $outXML) || die writeLog("Unable to open output file $outXML: $!");
   open(OUT_BATCH, '>', $outBatch) || die writeLog("Unable to open output file $outBatch: $!");
   open(OUT_COPY, '>', $copyCommands) || die writeLog("Unable to open output file $copyCommands: $!");
   print writeLog("Processing Response descriptor XML...");
   while (<IN_XML>) {
      #  print $_;
      s/\s+$//;
      $_ .= "\n";
      s/(<ECMOTO>)(\s*0*)/$1/; # remove leading 0's for ECMOTO tag
      if(/((^copy))\s+/)
      {
         print OUT_COPY $_;
		 $Docs = "Y";
      }
      else {
         next unless !/\s+<\/?EFUNDS_.+/;
         if (/\>\s*$/){
            if (length($value1) > 0){
               chomp($value1);
               $value2 = $value1.$_;
               $value1 = "";
            }
            else{
               $value2 = $_;
            }
         }
         else{
            if (!/^\s*$/){
               if (length($value1) > 0){
                  chomp($value1);
                  $value1 .= $_;
               }
               else{
                  $value1 = $_;
               }
            }
            next;
         }
         $value2 =~ s/$pat1//g;
         $value2 =~ s/$pat2//g;
         $value2 =~ s/^\s*$//;
         $value2 =~ s/&/ /g;

         print OUT_XML $value2;
         $value2="";
      }
   }
   print writeLog("Processing Batch descriptor XML...");
   while (<IN_BATCH>) {
      s/\s+$//;
      $_ .= "\n";
      if (/(BUA5)(\w{2})(00)/){
         $vrolBatch = $1.$2.$3;        # get batch descriptor file name
         $zipfile = "UA5" . $2 . "00";
      }
      if (/(RUA5\w{2}00)/){
         $vrolXML = $1;   # get response file name
         }
      if (/(DUA5\w{2}00)/){
         $imagefile = $1; # get image file name
         }
      $value2 = $_;
      $value2 =~ s/$pat1//g;
      $value2 =~ s/$pat2//g;
      $value2 =~ s/^\s*$//;
      if($Docs eq "N" && $value2 =~ /PackageFile/) {
         ;
		 }
      else
	  {
         print OUT_BATCH $value2;
		 }
      $value2="";
   }
   close IN_BATCH;
   close IN_XML;
   close OUT_XML;
   close OUT_BATCH;
   close OUT_COPY;
   rename $outBatch, $vrolBatch;

   open(IN_XML, '<',$outXML) || die writeLog("Unable to open input file $outXML: $!");
   open(OUT_XML, '>', $vrolXML) || die writeLog("Unable to open output file $vrolXML: $!");
   my $termininator=$/;
   undef $/;
   my $text = <IN_XML>;
   $text =~ s/<(\w*)>\s*<\/\1>//g;
   $/ = $termininator;
   print OUT_XML $text;
   close IN_XML;
   close OUT_XML;
}

## copy image files from central location to working location
## and compute size in bytes
sub copyFile() {
   my $infile = $_[0];
   my $outfile = $_[1];
   my $numBytes = $_[2];
   my $char = ' ';
   print writeLog(" copying $infile to $outfile");
   open(IN2,'<',$infile) || die writeLog("Unable to open file $infile: $!");
   open(OUT,'>', $outfile) || die writeLog("Unable to open file $outfile: $!");
   binmode(IN2);
   binmode(OUT);
   my $size = 0;
   while(sysread(IN2,$char,1,0)){
      syswrite(OUT,$char,1,0);
      $numBytes++;
   }
  #print "$outfile is $numBytes bytes \n";
   close IN2;
   close OUT;
   $numBytes;
}

## update image file size in XML file
sub fixSize() {
   my @params2 = split;
   my $imageFile = $_[0];
   my $fileSize = $_[1];
   my $suffix = "_SIZE";
   my $oldtext = "$imageFile$suffix";
  open(IN_VROLXML,"$vrolXML") || die writeLog("Unable to open input file $vrolXML: $!");
  ## print the modified contents to .bak file
  open (OUT_VROLXML, ">$vrolXML.bak") || die writeLog($!);
  while ($_ = <IN_VROLXML> ) {

     ## If text exists, replace text
     ## Search = case insensitive
     if ($_ =~ /$oldtext/i) {
         # Replace text, all instances on a line (/g), case insensitive (/i)
         $_ =~ s/$oldtext/$fileSize/gi;
     }
     print OUT_VROLXML "$_";
  }
  close IN_VROLXML;
  close OUT_VROLXML;
   ## copy the modified .bak file contents to the original file,
  ## thereby overwriting the original
  rename("$vrolXML.bak","$vrolXML") || die writeLog($!);
}


## writing to log file
sub writeLog(){
   my $logText = $_[0]. "\n";
   print LOG $logText;
   return $logText;
}
