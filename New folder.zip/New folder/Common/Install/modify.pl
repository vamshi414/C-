use Getopt::Std;
getopts("n:q:u:p:d:v:c:s:");
while ($text = <STDIN>)
{
   $text =~ s/node001/$opt_n/;
   $text =~ s/qualify/$opt_q/;
   $text =~ s/userid/$opt_u/;
   $text =~ s/password/$opt_p/;
   $text =~ s/system/$opt_s/;
   $text =~ s/database/$opt_d/;
   $text =~ s/version/$opt_v/;
   $text =~ s/change/$opt_c/;
   print $text;
}
