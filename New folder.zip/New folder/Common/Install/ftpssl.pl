use Getopt::Std;
use FIS_FTPSSL;
use Term::ReadKey;
getopts("s:p:u:i:");
print "Password:";
ReadMode('noecho');
my $password = ReadLine(0);
print "\n";
ReadMode(0);
#my $ftps = FIS_FTPSSL->new($opt_s,Port => $opt_p,Encryption => EXP_CRYPT,Debug => 1,Trace => 1) or die "Cannot connect to host";
#my $ftps = FIS_FTPSSL->new($opt_s,Port => $opt_p,Encryption => EXP_CRYPT,SSL_version => 'TLSv12',Debug => 2,DebugLogFile => "perl_ftp.log",Trace => 1) or die "Cannot connect to host";
my $ftps = FIS_FTPSSL->new($opt_s,Port => $opt_p,Encryption => EXP_CRYPT,SSL_version => 'TLSv12',Debug => 1,Trace => 1) or die "Cannot connect to host";
$ftps->login($opt_u,$password) or die "login failed";
open(FI,'<',$opt_i) or die "die: cannot open " . $opt_i . "\n";
while ($text = <FI>)
{
   chomp($text);
   if (substr($text,0,5) eq "ascii")
   {
      $ftps->quit();
      #$ftps = FIS_FTPSSL->new($opt_s,Port => $opt_p,Encryption => EXP_CRYPT,Debug => 1,Trace => 1) or die "Cannot connect to host";
	  #$ftps = FIS_FTPSSL->new($opt_s,Port => $opt_p,Encryption => EXP_CRYPT,SSL_version => 'TLSv12',Debug => 2,DebugLogFile => "perl_ftp.log",Trace => 1) or die "Cannot connect to host";
	  $ftps = FIS_FTPSSL->new($opt_s,Port => $opt_p,Encryption => EXP_CRYPT,SSL_version => 'TLSv12',Debug => 1,Trace => 1) or die "Cannot connect to host";
      $ftps->login($opt_u,$password) or die "login failed";
      $ftps->ascii();
   }
   elsif (substr($text,0,6) eq "binary")
   {
      $ftps->binary();
   }
   elsif (substr($text,0,3) eq "put")
   {
      my @tokens = split / /, $text;
      $ftps->put($tokens[1],$tokens[2]);
   }
   elsif (substr($text,0,5) eq "quote")
   {
      $ftps->site(substr($text,11));
   }
}
close FI;
$ftps->quit();
