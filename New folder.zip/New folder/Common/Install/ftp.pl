use Getopt::Std;
use Term::ReadKey;
getopts("s:u:i:");
print "Password:";
ReadMode('noecho');
my $password = ReadLine(0);
print "\n";
ReadMode(0);
open(FI,'<',$opt_i) or die "die: cannot open " . $opt_i . "\n";
open(FO,'>',"temp3.txt") or die "die: cannot open text3.txt\n";
while ($text = <FI>)
{
   $text =~ s/password/$password/;
   print FO $text;
}
close FO;
close FI;
$_ = "c:\\windows\\system32\\ftp -i -s:temp3.txt " . $opt_s;
print($_ . "\n");
system($_);
