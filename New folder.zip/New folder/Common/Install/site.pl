#!/usr/bin/perl -w
# site.pl
# substitute values from SITESPEC and CUSTSPEC
use Getopt::Std;
use strict;
my $cfg1 = "..\\..\\..\\Server\\Setup\\SITESPEC.txt";
my $cfg2 = "..\\..\\..\\Server\\Setup\\CUSTSPEC.txt";
open(CFG1,'<',$cfg1) || die "Unable to open configuration file $cfg1: $!\n";
open(CFG2,'<',$cfg2) || die "Unable to open configuration file $cfg2: $!\n";
my @config_records;
@config_records = <CFG1>;     #read SITESPEC into array
push @config_records, <CFG2>; #concatenate CUSTSPEC
close CFG1;
close CFG2;
my %hash = ();
chomp(@config_records);
for (@config_records)
{
   if (substr($_,0,1) eq "*") { next; }
   my @vals = split(/\s+/,$_);
   #handle possible blanks in the parameter value
   for (my $i = 2; $i < @vals; $i++)
   {
      $vals[1] = $vals[1] . ' ' . $vals[$i];
   }
   my $key = "&" . $vals[0] . "\\.";
   $hash{$key} = $vals[1];
   if ($key eq "&version\\.")
   {
      my $value = substr($vals[1],0,3) . substr($vals[1],4,2);
      $hash{"&release\\."} = $value;
   }
}

$hash{"&fl\\."} = ($hash{"&fin_transactions\\."} * 500) / 1000000;
$hash{"&fr\\."} = ($hash{"&fin_transactions\\."} * 2000) / 1000000;
$hash{"&ej\\."} = 100;
$hash{"&ejx\\."} = 50;
$hash{"&sl\\."} = 100;
$hash{"&slx\\."} = 50;
$hash{"&am\\."} = 100;
$hash{"&amx\\."} = 50;
$hash{"&dl\\."} = 100;
$hash{"&dlx\\."} = 50;
$hash{"&au\\."} = 100;
$hash{"&aux\\."} = 50;
$hash{"&devadmin\\."} = 100;
$hash{"&devadminx\\."} = 50;
$hash{"&devsrv\\."} = 100;
$hash{"&devsrvx\\."} = 50;
$hash{"&dx\\."} = 100;
$hash{"&dxx\\."} = 50;
$hash{"&ems\\."} = 100;
$hash{"&emsx\\."} = 50;
$hash{"&tot\\."} = 100;
$hash{"&totx\\."} = 50;

while (my $text = <STDIN>)
{
   while ( my ($key, $value) = each(%hash) )
   {
      $text =~ s/$key/$value/;
      $text =~ s/$key/$value/;
      $text =~ s/$key/$value/;
   }
   print "$text";
}
