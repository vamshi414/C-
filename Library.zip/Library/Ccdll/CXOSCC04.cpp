//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39ABB29B023B.cm preserve=no
//	$Date:   Oct 24 2019 10:22:22  $ $Author:   e1009839  $
//	$Revision:   1.30  $
//## end module%39ABB29B023B.cm

//## begin module%39ABB29B023B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39ABB29B023B.cp

//## Module: CXOSCC04%39ABB29B023B; Package body
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXOSCC04.cpp

//## begin module%39ABB29B023B.additionalIncludes preserve=no
//## end module%39ABB29B023B.additionalIncludes

//## begin module%39ABB29B023B.includes preserve=yes
//## end module%39ABB29B023B.includes

#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSUS05_h
#include "CXODUS05.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSCC04_h
#include "CXODCC04.hpp"
#endif


//## begin module%39ABB29B023B.declarations preserve=no
//## end module%39ABB29B023B.declarations

//## begin module%39ABB29B023B.additionalDeclarations preserve=yes
#define STS_INVALID_ENTITY_LIST_LENGTH 68
//## end module%39ABB29B023B.additionalDeclarations


//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

// Class canistercommand::DeviceViewConstraint

//## begin canistercommand::DeviceViewConstraint::Instance%39AADE6400B4.attr preserve=no  private: static canistercommand::DeviceViewConstraint* {U} 0
canistercommand::DeviceViewConstraint* DeviceViewConstraint::m_pInstance = 0;
//## end canistercommand::DeviceViewConstraint::Instance%39AADE6400B4.attr

DeviceViewConstraint::DeviceViewConstraint()
  //## begin DeviceViewConstraint::DeviceViewConstraint%39AADB690315_const.hasinit preserve=no
  //## end DeviceViewConstraint::DeviceViewConstraint%39AADB690315_const.hasinit
  //## begin DeviceViewConstraint::DeviceViewConstraint%39AADB690315_const.initialization preserve=yes
  //## end DeviceViewConstraint::DeviceViewConstraint%39AADB690315_const.initialization
{
  //## begin canistercommand::DeviceViewConstraint::DeviceViewConstraint%39AADB690315_const.body preserve=yes
   memcpy(m_sID,"CC04",4);
   m_hENTITY_TYPE["PROC_ID_***"] = make_pair(string("PROCESSOR"),string("PROC_ID"));
   m_hENTITY_TYPE["PROC_ID_ACQ"] = make_pair(string("PROCESSOR"),string("PROC_ID"));
   m_hENTITY_TYPE["PROC_ID_ISS"] = make_pair(string("PROCESSOR"),string("PROC_ID"));
   m_hENTITY_TYPE["INST_ID_RECON_***"] = make_pair(string("INSTITUTION"),string("INST_ID"));
   m_hENTITY_TYPE["INST_ID_RECON_ACQ"] = make_pair(string("INSTITUTION"),string("INST_ID"));
   m_hENTITY_TYPE["INST_ID_RECON_ISS"] = make_pair(string("INSTITUTION"),string("INST_ID"));
   m_hENTITY_TYPE["NET_TERM_ID"] = make_pair(string("DEVICE"),string("DEVICE_ID"));
   m_hENTITY_TYPE["DEVICE_ID"] = make_pair(string("DEVICE"),string("DEVICE_ID"));
   m_hENTITY_TYPE["COURIER_ID"] = make_pair(string("DEVICE_COURIER"),string("COURIER_PTR"));
   m_hENTITY_TYPE["COURIER_PTR"] = make_pair(string("DEVICE_COURIER"),string("COURIER_PTR"));
   m_hENTITY_TYPE["COURIER_RTE_ID"] = make_pair(string("DEVICE_COURIER_RTE"),string("COURIER_ROUTE_PTR"));
   m_hENTITY_TYPE["COURIER_ROUTE_PTR"] = make_pair(string("DEVICE_COURIER_RTE"),string("COURIER_ROUTE_PTR"));
   m_hENTITY_TYPE["ALL_COURIER"] = make_pair(string("INSTITUTION"),string("INST_ID"));
  //## end canistercommand::DeviceViewConstraint::DeviceViewConstraint%39AADB690315_const.body
}


DeviceViewConstraint::~DeviceViewConstraint()
{
  //## begin canistercommand::DeviceViewConstraint::~DeviceViewConstraint%39AADB690315_dest.body preserve=yes
  //## end canistercommand::DeviceViewConstraint::~DeviceViewConstraint%39AADB690315_dest.body
}



//## Other Operations (implementation)
int DeviceViewConstraint::addConstraints (Query& hQuery, bool bATM)
{
  //## begin canistercommand::DeviceViewConstraint::addConstraints%39AADE8103C3.body preserve=yes
   map<string,pair<string,string>,less<string> >::iterator pENTITY_TYPE;
   pENTITY_TYPE = m_hENTITY_TYPE.find(m_strColumnName);
   if (pENTITY_TYPE == m_hENTITY_TYPE.end())
      return STS_RECORD_NOT_FOUND;
   string strTable((*pENTITY_TYPE).second.first);
   string strColumn((*pENTITY_TYPE).second.second);
   hQuery.join("T_FIN_ENTITY","INNER","DEVICE","ENTITY_ID","DEVICE_ID");
   hQuery.join("DEVICE","INNER","INSTITUTION","INST_ID");
   hQuery.join("DEVICE","INNER","INSTITUTION","CUST_ID");
   hQuery.join("INSTITUTION","INNER","PROCESSOR","PROC_ID");
   hQuery.join("INSTITUTION","INNER","PROCESSOR","CUST_ID");
   if (!bATM)
   {
      hQuery.join("T_FIN_ENTITY","INNER","T_CANISTER","T_FIN_ENTITY_ID");
      hQuery.join("T_CANISTER","INNER","T_CAN_PERIOD","CANISTER_ID");
   }
   hQuery.join("DEVICE","LEFT OUTER","SUBJECT_STATE","DEVICE_ID","SUBJECT");
   if (!bATM)
   {
      hQuery.join("T_CAN_TOTAL","LEFT OUTER","T_FIN_PERIOD","ENTITY_PERIOD_ID","PERIOD_ID");
      hQuery.join("T_CAN_PERIOD","LEFT OUTER","T_CAN_TOTAL","PERIOD_ID","CANISTER_PERIOD_ID");
   }
   if (strTable.find("COURIER") != string::npos)
   {
      hQuery.join("DEVICE","INNER","DEVICE_COURIER_RTE","COURIER_ROUTE_PTR");
      hQuery.join("DEVICE_COURIER_RTE","INNER","DEVICE_COURIER","COURIER_PTR");
   }
   else
   {
      hQuery.join("DEVICE","LEFT OUTER","DEVICE_COURIER_RTE","COURIER_ROUTE_PTR");
      hQuery.join("DEVICE_COURIER_RTE","LEFT OUTER","DEVICE_COURIER","COURIER_PTR");
   }
   hQuery.setQualifier("QUALIFY","PROCESSOR");
   hQuery.setQualifier("QUALIFY","INSTITUTION");
   hQuery.setQualifier("QUALIFY","DEVICE");
   hQuery.setQualifier("QUALIFY","DEVICE_COURIER");
   hQuery.setQualifier("QUALIFY","DEVICE_COURIER_RTE");
   if (m_strValue.length() > 0)
   {
      if (strTable.find("COURIER") != string::npos)
      {
         size_t pos;
         while ((pos = m_strValue.find('\'')) != string::npos)
            m_strValue.replace(pos,1," ");
      }
      hQuery.setBasicPredicate(strTable.c_str(),strColumn.c_str(),"IN",m_strValue.c_str());
   }
   hQuery.setBasicPredicate("T_FIN_ENTITY","ENTITY_TYPE","=","AT");
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.setBasicPredicate("DEVICE","CUST_ID","=",strCUST_ID.c_str());
   hQuery.setBasicPredicate("DEVICE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("DEVICE","CC_STATE","=","A");
   hQuery.setBasicPredicate("INSTITUTION","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("INSTITUTION","CC_STATE","IN","('A','I')");
   hQuery.setBasicPredicate("PROCESSOR","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("PROCESSOR","CC_STATE","=","A");
   if (!bATM)
   {
      hQuery.setBasicPredicate("T_CAN_PERIOD","TSTAMP_REPLACE_TO","=","9999123123595999");
      hQuery.setBasicPredicate("T_CAN_PERIOD","TSTAMP_REPLACE","<>","0000000000000000");
   }
   if (hQuery.getSearchCondition().length() > 0)
      hQuery.getSearchCondition().append(" AND ");
   hQuery.getSearchCondition().append("(");
   hQuery.setBasicPredicate("SUBJECT_STATE","SUBJECT_TYPE","=",60);
   hQuery.setBasicPredicate("SUBJECT_STATE","SUBJECT_TYPE","IS NULL",(const char*)0,false,false);
   hQuery.getSearchCondition().append(")");
   if (m_strQualifyData.find("LOWCASH") != string::npos)
      hQuery.setBasicPredicate("SUBJECT_STATE","LOW_CASH_FLG","=","Y");
   hQuery.getSearchCondition().append(" AND (");
   hQuery.setBasicPredicate("INSTITUTION", "PROC_ID", "IN", m_hReportCommand.secure(ClientCommand::Processor));
   hQuery.setBasicPredicate("PROCESSOR", "PROC_GRP_ID", "IN", m_hReportCommand.secure(ClientCommand::ProcessorGroup), false, false);
   hQuery.setBasicPredicate("DEVICE", "INST_ID", "IN", m_hReportCommand.secure(ClientCommand::Institution), false, false);
   hQuery.setBasicPredicate("DEVICE", "RPT_LVL_ID", "IN", m_hReportCommand.secure(ClientCommand::ReportingLevel), false, false);
   hQuery.setBasicPredicate("DEVICE", "DEVICE_ID", "IN", m_hReportCommand.secure(ClientCommand::Device), false, false);
   hQuery.setBasicPredicate(0, "'*'", "IN", m_hReportCommand.secure(ClientCommand::All), false, false);
   hQuery.getSearchCondition().append(")");
   return 0;
  //## end canistercommand::DeviceViewConstraint::addConstraints%39AADE8103C3.body
}

DeviceViewConstraint* DeviceViewConstraint::instance ()
{
  //## begin canistercommand::DeviceViewConstraint::instance%39AADE8200AD.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new DeviceViewConstraint();
   return m_pInstance;
  //## end canistercommand::DeviceViewConstraint::instance%39AADE8200AD.body
}

int DeviceViewConstraint::read (int lCONSTRAINT_ID)
{
  //## begin canistercommand::DeviceViewConstraint::read%39AADE82014D.body preserve=yes
   Query hQuery;
   hQuery.setQualifier("QUALIFY","CQC_COLUMN_QUAL");
   m_hWorkQueueEntitySegment.bind(hQuery);
   hQuery.setBasicPredicate("CQC_COLUMN_QUAL","CONSTRAINT_ID","=",lCONSTRAINT_ID);
   hQuery.attach(this);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return STS_DATABASE_FAILURE;
   return (pSelectStatement->getRows() == 0) ? STS_RECORD_NOT_FOUND : 0;
  //## end canistercommand::DeviceViewConstraint::read%39AADE82014D.body
}

void DeviceViewConstraint::reset ()
{
  //## begin canistercommand::DeviceViewConstraint::reset%39AADE8201B1.body preserve=yes
   m_hEntities.erase(m_hEntities.begin(),m_hEntities.end());
   m_strValue.erase();
  //## end canistercommand::DeviceViewConstraint::reset%39AADE8201B1.body
}

int DeviceViewConstraint::setValue (const string& strCOLUMN_NAME, const string& strCOLUMN_VALUE)
{
  //## begin canistercommand::DeviceViewConstraint::setValue%39AADE82020C.body preserve=yes
   m_strColumnName = strCOLUMN_NAME;
   if (strCOLUMN_VALUE.length() > 0)
   {
      vector<string> hTokens;
      Buffer::parse(strCOLUMN_VALUE,",')(",hTokens);
      for (int i = 0; i < hTokens.size(); i++)
         m_hEntities.push_back(strCOLUMN_NAME + "," + hTokens[i]);
      if (m_strValue.length() == 0)
         m_strValue = "('";
      else
         m_strValue.replace(m_strValue.length() - 1,1,",'",2);
      m_strValue += strCOLUMN_VALUE + "')";
   }
   return 0;
  //## end canistercommand::DeviceViewConstraint::setValue%39AADE82020C.body
}

void DeviceViewConstraint::update (Subject* pSubject)
{
  //## begin canistercommand::DeviceViewConstraint::update%39AADE820266.body preserve=yes
   setValue(m_hWorkQueueEntitySegment.getCOLUMN_NAME(),m_hWorkQueueEntitySegment.getCOLUMN_VALUE());
  //## end canistercommand::DeviceViewConstraint::update%39AADE820266.body
}

// Additional Declarations
  //## begin canistercommand::DeviceViewConstraint%39AADB690315.declarations preserve=yes
  //## end canistercommand::DeviceViewConstraint%39AADB690315.declarations

} // namespace canistercommand

//## begin module%39ABB29B023B.epilog preserve=yes
//## end module%39ABB29B023B.epilog
