//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39ABB26F0210.cm preserve=no
//	$Date:   Oct 24 2019 10:22:20  $ $Author:   e1009839  $
//	$Revision:   1.13  $
//## end module%39ABB26F0210.cm

//## begin module%39ABB26F0210.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39ABB26F0210.cp

//## Module: CXOSCC04%39ABB26F0210; Package specification
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXODCC04.hpp

#ifndef CXOSCC04_h
#define CXOSCC04_h 1

//## begin module%39ABB26F0210.additionalIncludes preserve=no
//## end module%39ABB26F0210.additionalIncludes

//## begin module%39ABB26F0210.includes preserve=yes
// $Date:   Oct 24 2019 10:22:20  $ $Author:   e1009839  $ $Revision:   1.13  $
#include <map>
//## end module%39ABB26F0210.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSVS03_h
#include "CXODVS03.hpp"
#endif
#ifndef CXOSVC07_h
#include "CXODVC07.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
class Buffer;
class FormatSelectVisitor;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
} // namespace segment

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class RelationshipSegment;

} // namespace usersegment

//## begin module%39ABB26F0210.declarations preserve=no
//## end module%39ABB26F0210.declarations

//## begin module%39ABB26F0210.additionalDeclarations preserve=yes
#include "CXODVC07.hpp"
//## end module%39ABB26F0210.additionalDeclarations


//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

//## begin canistercommand::DeviceViewConstraint%39AADB690315.preface preserve=yes
//## end canistercommand::DeviceViewConstraint%39AADB690315.preface

//## Class: DeviceViewConstraint%39AADB690315
//## Category: Device Management::CanisterCommand_CAT%39A2966401E2
//## Subsystem: CCDLL%39A29BAF006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39AADDB701BA;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%39AADDC00361;reusable::FormatSelectVisitor { -> F}
//## Uses: <unnamed>%39AADDC4028B;reusable::Query { -> F}
//## Uses: <unnamed>%39AADDC8002D;segment::InformationSegment { -> F}
//## Uses: <unnamed>%39AADDCC014C;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%39AADE230219;IF::Trace { -> F}
//## Uses: <unnamed>%39AC171103E3;IF::Extract { -> F}
//## Uses: <unnamed>%3A2D0EAD0110;usersegment::RelationshipSegment { -> F}
//## Uses: <unnamed>%5D250839038E;reusable::Buffer { -> F}
//## Uses: <unnamed>%5D25083D0135;IF::Trace { -> F}

class DllExport DeviceViewConstraint : public reusable::Observer  //## Inherits: <unnamed>%39AADD160399
{
  //## begin canistercommand::DeviceViewConstraint%39AADB690315.initialDeclarations preserve=yes
  //## end canistercommand::DeviceViewConstraint%39AADB690315.initialDeclarations

  public:
    //## Constructors (generated)
      DeviceViewConstraint();

    //## Destructor (generated)
      virtual ~DeviceViewConstraint();


    //## Other Operations (specified)
      //## Operation: addConstraints%39AADE8103C3
      int addConstraints (Query& hQuery, bool bATM = false);

      //## Operation: instance%39AADE8200AD
      static DeviceViewConstraint* instance ();

      //## Operation: read%39AADE82014D
      int read (int lCONSTRAINT_ID);

      //## Operation: reset%39AADE8201B1
      void reset ();

      //## Operation: setValue%39AADE82020C
      int setValue (const string& strCOLUMN_NAME, const string& strCOLUMN_VALUE);

      //## Operation: update%39AADE820266
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ColumnName%39ABD930033A
      const reusable::string& getColumnName () const
      {
        //## begin canistercommand::DeviceViewConstraint::getColumnName%39ABD930033A.get preserve=no
        return m_strColumnName;
        //## end canistercommand::DeviceViewConstraint::getColumnName%39ABD930033A.get
      }

      void setColumnName (const reusable::string& value)
      {
        //## begin canistercommand::DeviceViewConstraint::setColumnName%39ABD930033A.set preserve=no
        m_strColumnName = value;
        //## end canistercommand::DeviceViewConstraint::setColumnName%39ABD930033A.set
      }


      //## Attribute: QualifyData%39CFAF0A0335
      const reusable::string& getQualifyData () const
      {
        //## begin canistercommand::DeviceViewConstraint::getQualifyData%39CFAF0A0335.get preserve=no
        return m_strQualifyData;
        //## end canistercommand::DeviceViewConstraint::getQualifyData%39CFAF0A0335.get
      }

      void setQualifyData (const reusable::string& value)
      {
        //## begin canistercommand::DeviceViewConstraint::setQualifyData%39CFAF0A0335.set preserve=no
        m_strQualifyData = value;
        //## end canistercommand::DeviceViewConstraint::setQualifyData%39CFAF0A0335.set
      }


    // Additional Public Declarations
      //## begin canistercommand::DeviceViewConstraint%39AADB690315.public preserve=yes
      //## end canistercommand::DeviceViewConstraint%39AADB690315.public

  protected:
    // Additional Protected Declarations
      //## begin canistercommand::DeviceViewConstraint%39AADB690315.protected preserve=yes
      //## end canistercommand::DeviceViewConstraint%39AADB690315.protected

  private:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Value%39ABB95800BD
      const reusable::string& getValue () const
      {
        //## begin canistercommand::DeviceViewConstraint::getValue%39ABB95800BD.get preserve=no
        return m_strValue;
        //## end canistercommand::DeviceViewConstraint::getValue%39ABB95800BD.get
      }


    // Additional Private Declarations
      //## begin canistercommand::DeviceViewConstraint%39AADB690315.private preserve=yes
      //## end canistercommand::DeviceViewConstraint%39AADB690315.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%39AADE6400B4
      //## begin canistercommand::DeviceViewConstraint::Instance%39AADE6400B4.attr preserve=no  private: static DeviceViewConstraint* {U} 0
      static DeviceViewConstraint* m_pInstance;
      //## end canistercommand::DeviceViewConstraint::Instance%39AADE6400B4.attr

      //## begin canistercommand::DeviceViewConstraint::Value%39ABB95800BD.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strValue;
      //## end canistercommand::DeviceViewConstraint::Value%39ABB95800BD.attr

      //## begin canistercommand::DeviceViewConstraint::ColumnName%39ABD930033A.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strColumnName;
      //## end canistercommand::DeviceViewConstraint::ColumnName%39ABD930033A.attr

      //## begin canistercommand::DeviceViewConstraint::QualifyData%39CFAF0A0335.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strQualifyData;
      //## end canistercommand::DeviceViewConstraint::QualifyData%39CFAF0A0335.attr

    // Data Members for Associations

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%39AADD4901ED
      //## Role: DeviceViewConstraint::<m_hWorkQueueEntitySegment>%39AADD4B01C8
      //## begin canistercommand::DeviceViewConstraint::<m_hWorkQueueEntitySegment>%39AADD4B01C8.role preserve=no  public: viewsegment::WorkQueueEntitySegment { -> VHgN}
      viewsegment::WorkQueueEntitySegment m_hWorkQueueEntitySegment;
      //## end canistercommand::DeviceViewConstraint::<m_hWorkQueueEntitySegment>%39AADD4B01C8.role

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%5D2506D50295
      //## Role: DeviceViewConstraint::<m_hReportCommand>%5D2506D70227
      //## begin canistercommand::DeviceViewConstraint::<m_hReportCommand>%5D2506D70227.role preserve=no  public: viewcommand::ReportCommand { -> VHgN}
      viewcommand::ReportCommand m_hReportCommand;
      //## end canistercommand::DeviceViewConstraint::<m_hReportCommand>%5D2506D70227.role

    // Additional Implementation Declarations
      //## begin canistercommand::DeviceViewConstraint%39AADB690315.implementation preserve=yes
      vector<string> m_hEntities;
      map<string,pair<string,string>,less<string> > m_hENTITY_TYPE;
      //## end canistercommand::DeviceViewConstraint%39AADB690315.implementation
};

//## begin canistercommand::DeviceViewConstraint%39AADB690315.postscript preserve=yes
//## end canistercommand::DeviceViewConstraint%39AADB690315.postscript

} // namespace canistercommand

//## begin module%39ABB26F0210.epilog preserve=yes
using namespace canistercommand;
//## end module%39ABB26F0210.epilog


#endif
