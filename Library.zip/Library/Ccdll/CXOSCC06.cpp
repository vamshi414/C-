//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39AD80970054.cm preserve=no
//	$Date:   Oct 24 2019 10:29:40  $ $Author:   e1009839  $
//	$Revision:   1.10  $
//## end module%39AD80970054.cm

//## begin module%39AD80970054.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39AD80970054.cp

//## Module: CXOSCC06%39AD80970054; Package body
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXOSCC06.cpp

//## begin module%39AD80970054.additionalIncludes preserve=no
//## end module%39AD80970054.additionalIncludes

//## begin module%39AD80970054.includes preserve=yes
//## end module%39AD80970054.includes

#ifndef CXOSCC05_h
#include "CXODCC05.hpp"
#endif
#ifndef CXOSCC06_h
#include "CXODCC06.hpp"
#endif


//## begin module%39AD80970054.declarations preserve=no
//## end module%39AD80970054.declarations

//## begin module%39AD80970054.additionalDeclarations preserve=yes
//## end module%39AD80970054.additionalDeclarations


//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

// Class canistercommand::CanisterBalance 

CanisterBalance::CanisterBalance()
  //## begin CanisterBalance::CanisterBalance%39AD7E5D02DA_const.hasinit preserve=no
      : m_dBEGINNING_AMT(0),
        m_iBEGINNING_COUNT(0),
        m_siCUR_TYPE(0),
        m_iDISPNSD_ITEM_COUNT(0),
        m_iITEM_VALUE(0)
  //## end CanisterBalance::CanisterBalance%39AD7E5D02DA_const.hasinit
  //## begin CanisterBalance::CanisterBalance%39AD7E5D02DA_const.initialization preserve=yes
  //## end CanisterBalance::CanisterBalance%39AD7E5D02DA_const.initialization
{
  //## begin canistercommand::CanisterBalance::CanisterBalance%39AD7E5D02DA_const.body preserve=yes
   memcpy(m_sID,"CC06",4);
  //## end canistercommand::CanisterBalance::CanisterBalance%39AD7E5D02DA_const.body
}

CanisterBalance::CanisterBalance(const CanisterBalance &right)
  //## begin CanisterBalance::CanisterBalance%39AD7E5D02DA_copy.hasinit preserve=no
  //## end CanisterBalance::CanisterBalance%39AD7E5D02DA_copy.hasinit
  //## begin CanisterBalance::CanisterBalance%39AD7E5D02DA_copy.initialization preserve=yes
  //## end CanisterBalance::CanisterBalance%39AD7E5D02DA_copy.initialization
{
  //## begin canistercommand::CanisterBalance::CanisterBalance%39AD7E5D02DA_copy.body preserve=yes
   memcpy(m_sID,"CC06",4);
   m_dBEGINNING_AMT = right.m_dBEGINNING_AMT;
   m_iBEGINNING_COUNT = right.m_iBEGINNING_COUNT;
   m_strCURRENCY_CODE = right.m_strCURRENCY_CODE;
   m_siCUR_TYPE = right.m_siCUR_TYPE;
   m_iDISPNSD_ITEM_COUNT = right.m_iDISPNSD_ITEM_COUNT;
   m_iITEM_VALUE = right.m_iITEM_VALUE;
   m_strTSTAMP_REPLACE = right.m_strTSTAMP_REPLACE;
  //## end canistercommand::CanisterBalance::CanisterBalance%39AD7E5D02DA_copy.body
}


CanisterBalance::~CanisterBalance()
{
  //## begin canistercommand::CanisterBalance::~CanisterBalance%39AD7E5D02DA_dest.body preserve=yes
  //## end canistercommand::CanisterBalance::~CanisterBalance%39AD7E5D02DA_dest.body
}



//## Other Operations (implementation)
void CanisterBalance::add (CanisterTotal hCanisterTotal)
{
  //## begin canistercommand::CanisterBalance::add%39AD7ED10219.body preserve=yes
   if (m_strCURRENCY_CODE.length() == 0)
   {
      m_dBEGINNING_AMT = hCanisterTotal.getBEGINNING_AMT();
      m_iBEGINNING_COUNT = hCanisterTotal.getBEGINNING_COUNT();
      m_strCURRENCY_CODE = hCanisterTotal.getCURRENCY_CODE();
      m_siCUR_TYPE = hCanisterTotal.getCUR_TYPE();
      m_iITEM_VALUE = hCanisterTotal.getITEM_VALUE();
      m_strTSTAMP_REPLACE = hCanisterTotal.getTSTAMP_REPLACE();
   }
   m_iDISPNSD_ITEM_COUNT += hCanisterTotal.getDISPNSD_ITEM_COUNT();
  //## end canistercommand::CanisterBalance::add%39AD7ED10219.body
}

void CanisterBalance::reset ()
{
  //## begin canistercommand::CanisterBalance::reset%39AD80C801E5.body preserve=yes
   m_dBEGINNING_AMT = 0;
   m_iBEGINNING_COUNT = 0;
   m_strCURRENCY_CODE.erase();
   m_siCUR_TYPE = 0;
   m_iDISPNSD_ITEM_COUNT = 0;
   m_iITEM_VALUE = 0;
   m_strTSTAMP_REPLACE.erase();
  //## end canistercommand::CanisterBalance::reset%39AD80C801E5.body
}

// Additional Declarations
  //## begin canistercommand::CanisterBalance%39AD7E5D02DA.declarations preserve=yes
  //## end canistercommand::CanisterBalance%39AD7E5D02DA.declarations

} // namespace canistercommand

//## begin module%39AD80970054.epilog preserve=yes
//## end module%39AD80970054.epilog
