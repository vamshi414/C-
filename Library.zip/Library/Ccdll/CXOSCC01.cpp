//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39A29C320131.cm preserve=no
//	$Date:   Oct 24 2019 15:27:48  $ $Author:   e1009839  $
//	$Revision:   1.32  $
//## end module%39A29C320131.cm

//## begin module%39A29C320131.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39A29C320131.cp

//## Module: CXOSCC01%39A29C320131; Package body
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXOSCC01.cpp

//## begin module%39A29C320131.additionalIncludes preserve=no
//## end module%39A29C320131.additionalIncludes

//## begin module%39A29C320131.includes preserve=yes
#define STS_WORK_QUEUE_NOT_FOUND 61
#include "CXODIF16.hpp"
#include "CXODBS16.hpp"
//## end module%39A29C320131.includes

#ifndef CXOSVS07_h
#include "CXODVS07.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBS10_h
#include "CXODBS10.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSCC03_h
#include "CXODCC03.hpp"
#endif
#ifndef CXOSCC04_h
#include "CXODCC04.hpp"
#endif
#ifndef CXOSVC17_h
#include "CXODVC17.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSCC09_h
#include "CXODCC09.hpp"
#endif
#ifndef CXOSBS12_h
#include "CXODBS12.hpp"
#endif
#ifndef CXOSCC02_h
#include "CXODCC02.hpp"
#endif
#ifndef CXOSCC01_h
#include "CXODCC01.hpp"
#endif


//## begin module%39A29C320131.declarations preserve=no
//## end module%39A29C320131.declarations

//## begin module%39A29C320131.additionalDeclarations preserve=yes
//## end module%39A29C320131.additionalDeclarations


//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

// Class canistercommand::DeviceViewCommand

DeviceViewCommand::DeviceViewCommand()
  //## begin DeviceViewCommand::DeviceViewCommand%39A29733012B_const.hasinit preserve=no
      : m_iColumnCount(0),
        m_pPrimaryKeySegment(0),
        m_pViewCanister(0),
        m_pListSegment(0)
  //## end DeviceViewCommand::DeviceViewCommand%39A29733012B_const.hasinit
  //## begin DeviceViewCommand::DeviceViewCommand%39A29733012B_const.initialization preserve=yes
  //## end DeviceViewCommand::DeviceViewCommand%39A29733012B_const.initialization
{
  //## begin canistercommand::DeviceViewCommand::DeviceViewCommand%39A29733012B_const.body preserve=yes
   memcpy(m_sID,"CC01",4);
   m_pPrimaryKeySegment = new PrimaryKeySegment();
   m_hSegments.push_back(m_pPrimaryKeySegment);
   m_pListSegment = new ListSegment();
   m_hSegments.push_back(m_pListSegment);
   ReportMailCommand::instance()->addReportView("CANISTERS",new CurrentDevicePosition());
   ReportMailCommand::instance()->addReportView("LOWCASH",new CurrentDevicePosition());
  //## end canistercommand::DeviceViewCommand::DeviceViewCommand%39A29733012B_const.body
}

DeviceViewCommand::DeviceViewCommand (Handler* pSuccessor)
  //## begin canistercommand::DeviceViewCommand::DeviceViewCommand%39A29A2601AC.hasinit preserve=no
      : m_iColumnCount(0),
        m_pPrimaryKeySegment(0),
        m_pViewCanister(0),
        m_pListSegment(0)
  //## end canistercommand::DeviceViewCommand::DeviceViewCommand%39A29A2601AC.hasinit
  //## begin canistercommand::DeviceViewCommand::DeviceViewCommand%39A29A2601AC.initialization preserve=yes
   ,ReportCommand("S0003D","@##TMXCANV")
  //## end canistercommand::DeviceViewCommand::DeviceViewCommand%39A29A2601AC.initialization
{
  //## begin canistercommand::DeviceViewCommand::DeviceViewCommand%39A29A2601AC.body preserve=yes
   memcpy(m_sID,"CC01",4);
   m_pSuccessor = pSuccessor;
   m_pPrimaryKeySegment = new PrimaryKeySegment();
   m_hSegments.push_back(m_pPrimaryKeySegment);
   m_pListSegment = new ListSegment();
   m_hSegments.push_back(m_pListSegment);
   ReportMailCommand::instance()->addReportView("CANISTERS",new CurrentDevicePosition());
   ReportMailCommand::instance()->addReportView("LOWCASH",new CurrentDevicePosition());
  //## end canistercommand::DeviceViewCommand::DeviceViewCommand%39A29A2601AC.body
}


DeviceViewCommand::~DeviceViewCommand()
{
  //## begin canistercommand::DeviceViewCommand::~DeviceViewCommand%39A29733012B_dest.body preserve=yes
   delete m_pPrimaryKeySegment;
   delete m_pListSegment;
  //## end canistercommand::DeviceViewCommand::~DeviceViewCommand%39A29733012B_dest.body
}



//## Other Operations (implementation)
bool DeviceViewCommand::execute ()
{
  //## begin canistercommand::DeviceViewCommand::execute%39A29A2601CA.body preserve=yes
   // CL63: Client_Requests_Canister_Data_From_DB
   UseCase hUseCase("CLIENT","## CL63 CANISTER TOTALS");
   int iRC;
   if ((iRC = Command::parse()) != 0)
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,iRC);
      return false;
   }
   if (!m_pMultipleRowContextSegment->presence())
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_MULTIPLEROWCONTEXT_SEGMENT);
      return false;
   }
   if (!m_pPrimaryKeySegment->presence())
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_PRIMARYKEY_SEGMENT);
      return false;
   }
   // capture arguments from the request
   int lCONSTRAINT_ID = atoi(m_pPrimaryKeySegment->getPrimaryKey().substr(0,8).c_str());
   string strQUALIFY_DATA;
   int lREPORT_ID = -1;
   short int iNull = -1;
   Query hQuery;
   if (m_pPrimaryKeySegment->getPrimaryKey().length() > 8
      && m_pPrimaryKeySegment->getPrimaryKey()[8] == 'R')
   {
      hQuery.setQualifier("QUALIFY","RW_REPORT_DEF");
      hQuery.bind("RW_REPORT_DEF","REPORT_TYPE_QUAL",Column::STRING,&strQUALIFY_DATA);
      hQuery.setBasicPredicate("RW_REPORT_DEF","REPORT_ID","=",lCONSTRAINT_ID);
      lREPORT_ID = lCONSTRAINT_ID;
      iNull = 0;
   }
   else
   {
      hQuery.setQualifier("QUALIFY","CQC_CONSTRAINT");
      hQuery.bind("CQC_CONSTRAINT","QUALIFY_DATA",Column::STRING,&strQUALIFY_DATA);
      hQuery.bind("CQC_CONSTRAINT","REPORT_ID",Column::LONG,&lREPORT_ID,&iNull);
      hQuery.setBasicPredicate("CQC_CONSTRAINT","CONSTRAINT_ID","=",lCONSTRAINT_ID);
   }
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   pSelectStatement->execute(hQuery);
   if (pSelectStatement->getRows() == 0)
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_WORK_QUEUE_NOT_FOUND);
      return false;
   }
   if ((strQUALIFY_DATA.find("CANISTER") == string::npos) &&
      (strQUALIFY_DATA.find("LOWCASH") == string::npos))
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_WORK_QUEUE_NOT_FOUND);
      return false;
   }
   const char* pszMember = (strQUALIFY_DATA.find("CANISTER") != string::npos)
      ? "## CL64 GET DEVICE POSITION" : "## CL65 LIST LOW CASH DEVICES";
   UseCase hUseCase2("CLIENT",pszMember);
   string strRecord;
   if (Extract::instance()->getRecord("DSPEC   CC01    OLD",strRecord))
      m_pViewCanister = new CurrentDevicePosition();
   else
      m_pViewCanister = new CurrentATMPosition();
   int lInfoIDNumber;
   string strDEFAULT_VALUE;
   DeviceViewConstraint::instance()->reset();
   DeviceViewConstraint::instance()->setQualifyData(strQUALIFY_DATA);
   char* p = (char*)*m_pListSegment;
   ReportOptionSegment hReportOptionSegment;
   if ((m_pListSegment->presence() && m_pListSegment->itemCount() == 0)
     || (!m_pListSegment->presence()))
   {
      lInfoIDNumber = DeviceViewConstraint::instance()->read(lCONSTRAINT_ID);
      if (lInfoIDNumber != 0)
      {
         delete m_pViewCanister;
         char cSeverityLevel = (lInfoIDNumber == STS_RECORD_NOT_FOUND) ? STS_INFORMATION : STS_ERROR;
         sendError(STS_QUERY_ERROR,cSeverityLevel,lInfoIDNumber);
         return false;
      }
   }
   else
   for (int i = 0;i < m_pListSegment->itemCount();++i)
   {
      if ((iRC = hReportOptionSegment.import(&p)) != 0)
      {
         delete m_pViewCanister;
         sendError(STS_PARSE_ERROR,STS_ERROR,iRC);
         return false;
      }
      strDEFAULT_VALUE = hReportOptionSegment.getDEFAULT_VALUE();
      if (strDEFAULT_VALUE[0] == '\'')
      {
         strDEFAULT_VALUE.erase(strDEFAULT_VALUE.length() - 1);
         strDEFAULT_VALUE.erase(0,1);
      }
      lInfoIDNumber = DeviceViewConstraint::instance()->setValue(hReportOptionSegment.getCOLUMN_NAME(),strDEFAULT_VALUE);
      if (lInfoIDNumber != 0)
      {
         delete m_pViewCanister;
         sendError(STS_QUERY_ERROR,STS_ERROR,lInfoIDNumber);
         return false;
      }
   }
   Message::instance(Message::INBOUND)->reset("TI CI ","S0003R");
   m_pDataBuffer = Message::instance(Message::INBOUND)->data() + 8;
   CommonHeaderSegment::instance()->setExternalContextData(strQUALIFY_DATA);
   CommonHeaderSegment::instance()->deport(&m_pDataBuffer);
   m_pMRC = m_pDataBuffer;
   m_pMultipleRowContextSegment->deport(&m_pDataBuffer);
   m_pList = m_pDataBuffer;
   m_pListSegment->deport(&m_pDataBuffer);
   m_iColumnCount = m_pViewCanister->describe(&m_pDataBuffer);
   if (iNull != -1)
   {
      m_hQuery.reset();
      m_hQuery.attach(this);
      m_hReportColumnSegment.bind(m_hQuery);
      m_hQuery.setQualifier("QUALIFY","RW_REPORT_COLUMN");
      m_hQuery.setBasicPredicate("RW_REPORT_COLUMN","REPORT_ID","=",lREPORT_ID);
      m_hQuery.setOrderByClause("RW_REPORT_COLUMN.SEQ_NO");
      if (pSelectStatement->execute(m_hQuery) == false)
      {
         delete m_pViewCanister;
         sendError(STS_QUERY_ERROR,STS_ERROR,pSelectStatement->getInfoIDNumber(),false);
         return false;
      }
   }
   m_pListSegment->update(m_pList,m_iColumnCount,(int)(m_pDataBuffer - m_pList));
   m_pList = m_pDataBuffer;
   m_hListResultsSegment.deport(&m_pDataBuffer);
   m_iResultSetCount = 0;
   m_lTotalRecordsFound = 0;
   m_pViewCanister->getRow()->attach(this);
   // ::update() will be called for each row of the view
   lInfoIDNumber = m_pViewCanister->execute();
   delete m_pViewCanister;
   if (lInfoIDNumber != 0 && lInfoIDNumber != STS_RECORD_NOT_FOUND)
   {
      sendError(STS_QUERY_ERROR,STS_ERROR,lInfoIDNumber,false);
      return false;
   }
   UseCase::addItem(m_lTotalRecordsFound);
   return ReportCommand::execute();
  //## end canistercommand::DeviceViewCommand::execute%39A29A2601CA.body
}

void DeviceViewCommand::update (Subject* pSubject)
{
  //## begin canistercommand::DeviceViewCommand::update%39A29A2601DE.body preserve=yes

   // CL51: Operator_Starts_TotalsInquiry
   // CL63: Client_Requests_Canister_Data_From_DB
   if (pSubject == Message::instance(Message::INBOUND)
      || pSubject == Database::instance())
   {
      ClientCommand::update(pSubject);
      return;
   }
   // CL63: Client_Requests_Canister_Data_From_DB
   if (pSubject == &m_hQuery)
   {
      m_iColumnCount++;
      m_hReportColumnSegment.setPrecision("0000");
      m_hReportColumnSegment.setScale("0000");
      m_hReportColumnSegment.deport(&m_pDataBuffer);
      return;
   }
   // CL64: SW_Retrieves_Current_Canister_Totals_From_DB
   m_lTotalRecordsFound++;
   if (((m_pDataBuffer - Message::instance(Message::INBOUND)->data())
      + sizeof(segResponseTimeSegment) + m_pViewCanister->getRow()->getBuffer().length()) > MAX_MESSAGE_SIZE)
      sendMessage();
   m_iResultSetCount++;
   memcpy(m_pDataBuffer,m_pViewCanister->getRow()->getBuffer().data(),m_pViewCanister->getRow()->getBuffer().length());
   m_pDataBuffer += m_pViewCanister->getRow()->getBuffer().length();
  //## end canistercommand::DeviceViewCommand::update%39A29A2601DE.body
}

// Additional Declarations
  //## begin canistercommand::DeviceViewCommand%39A29733012B.declarations preserve=yes
  //## end canistercommand::DeviceViewCommand%39A29733012B.declarations

} // namespace canistercommand

//## begin module%39A29C320131.epilog preserve=yes
//## end module%39A29C320131.epilog
