//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39AD02D800E3.cm preserve=no
//	$Date:   Oct 24 2019 10:27:06  $ $Author:   e1009839  $
//	$Revision:   1.16  $
//## end module%39AD02D800E3.cm

//## begin module%39AD02D800E3.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39AD02D800E3.cp

//## Module: CXOSCC05%39AD02D800E3; Package specification
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXODCC05.hpp

#ifndef CXOSCC05_h
#define CXOSCC05_h 1

//## begin module%39AD02D800E3.additionalIncludes preserve=no
//## end module%39AD02D800E3.additionalIncludes

//## begin module%39AD02D800E3.includes preserve=yes
// $Date:   Oct 24 2019 10:27:06  $ $Author:   e1009839  $ $Revision:   1.16  $
//## end module%39AD02D800E3.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
class DeviceViewConstraint;
} // namespace canistercommand

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%39AD02D800E3.declarations preserve=no
//## end module%39AD02D800E3.declarations

//## begin module%39AD02D800E3.additionalDeclarations preserve=yes
//## end module%39AD02D800E3.additionalDeclarations


namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

//## begin canistercommand::CanisterTotal%39AD005E03AE.preface preserve=yes
//## end canistercommand::CanisterTotal%39AD005E03AE.preface

//## Class: CanisterTotal%39AD005E03AE
//## Category: Device Management::CanisterCommand_CAT%39A2966401E2
//## Subsystem: CCDLL%39A29BAF006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39AD00E0029C;reusable::Query { -> F}
//## Uses: <unnamed>%39AD01010326;DeviceViewConstraint { -> F}

class DllExport CanisterTotal : public reusable::Object  //## Inherits: <unnamed>%39AD00D002A3
{
  //## begin canistercommand::CanisterTotal%39AD005E03AE.initialDeclarations preserve=yes
  //## end canistercommand::CanisterTotal%39AD005E03AE.initialDeclarations

  public:
    //## Constructors (generated)
      CanisterTotal();

    //## Destructor (generated)
      virtual ~CanisterTotal();


    //## Other Operations (specified)
      //## Operation: bind%39AD012000DB
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>CM
      //	<h2>FI
      //	<h3>Canister Totals Tables
      //	<p>
      //	Canister totals are retrieved from the following tables:
      //	<ul>
      //	<li><i>custqual</i>.T_CANISTER
      //	<li><i>custqual</i>.T_CAN_PERIOD
      //	<li><i>custqual</i>.T_CAN_TOTAL
      //	</ul>
      //	</body>
      void bind (Query& hQuery, bool bATM = false);

      //## Operation: getTSTAMP_TRANS_TO%4410E10F0222
      string* getTSTAMP_TRANS_TO ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: BEGINNING_AMT%39AD05F50086
      const double& getBEGINNING_AMT () const
      {
        //## begin canistercommand::CanisterTotal::getBEGINNING_AMT%39AD05F50086.get preserve=no
        return m_dBEGINNING_AMT;
        //## end canistercommand::CanisterTotal::getBEGINNING_AMT%39AD05F50086.get
      }


      //## Attribute: BEGINNING_COUNT%39AD06200114
      const int& getBEGINNING_COUNT () const
      {
        //## begin canistercommand::CanisterTotal::getBEGINNING_COUNT%39AD06200114.get preserve=no
        return m_lBEGINNING_COUNT;
        //## end canistercommand::CanisterTotal::getBEGINNING_COUNT%39AD06200114.get
      }


      //## Attribute: CANISTER_NO%39AD0425020E
      const short int& getCANISTER_NO () const
      {
        //## begin canistercommand::CanisterTotal::getCANISTER_NO%39AD0425020E.get preserve=no
        return m_siCANISTER_NO;
        //## end canistercommand::CanisterTotal::getCANISTER_NO%39AD0425020E.get
      }


      //## Attribute: COURIER_DESC%3A02D81D0180
      const reusable::string& getCOURIER_DESC () const
      {
        //## begin canistercommand::CanisterTotal::getCOURIER_DESC%3A02D81D0180.get preserve=no
        return m_strCOURIER_DESC;
        //## end canistercommand::CanisterTotal::getCOURIER_DESC%3A02D81D0180.get
      }


      //## Attribute: COURIER_OFFICE_ID%3A02D7F5002E
      const reusable::string& getCOURIER_OFFICE_ID () const
      {
        //## begin canistercommand::CanisterTotal::getCOURIER_OFFICE_ID%3A02D7F5002E.get preserve=no
        return m_strCOURIER_OFFICE_ID;
        //## end canistercommand::CanisterTotal::getCOURIER_OFFICE_ID%3A02D7F5002E.get
      }


      //## Attribute: COURIER_OFFICE_ID_NULL%3A02D7C00213
      const short int& getCOURIER_OFFICE_ID_NULL () const
      {
        //## begin canistercommand::CanisterTotal::getCOURIER_OFFICE_ID_NULL%3A02D7C00213.get preserve=no
        return m_siCOURIER_OFFICE_ID_NULL;
        //## end canistercommand::CanisterTotal::getCOURIER_OFFICE_ID_NULL%3A02D7C00213.get
      }


      //## Attribute: COURIER_PTR%3A114804017B
      const int& getCOURIER_PTR () const
      {
        //## begin canistercommand::CanisterTotal::getCOURIER_PTR%3A114804017B.get preserve=no
        return m_lCOURIER_PTR;
        //## end canistercommand::CanisterTotal::getCOURIER_PTR%3A114804017B.get
      }


      //## Attribute: COURIER_ROUTE_ID_NULL%3A02D82F0302
      const short int& getCOURIER_ROUTE_ID_NULL () const
      {
        //## begin canistercommand::CanisterTotal::getCOURIER_ROUTE_ID_NULL%3A02D82F0302.get preserve=no
        return m_siCOURIER_ROUTE_ID_NULL;
        //## end canistercommand::CanisterTotal::getCOURIER_ROUTE_ID_NULL%3A02D82F0302.get
      }


      //## Attribute: COURIER_ROUTE_ID%3A02D845012D
      const reusable::string& getCOURIER_ROUTE_ID () const
      {
        //## begin canistercommand::CanisterTotal::getCOURIER_ROUTE_ID%3A02D845012D.get preserve=no
        return m_strCOURIER_ROUTE_ID;
        //## end canistercommand::CanisterTotal::getCOURIER_ROUTE_ID%3A02D845012D.get
      }


      //## Attribute: COURIER_ROUTE_DESC%3A02D85D0363
      const reusable::string& getCOURIER_ROUTE_DESC () const
      {
        //## begin canistercommand::CanisterTotal::getCOURIER_ROUTE_DESC%3A02D85D0363.get preserve=no
        return m_strCOURIER_ROUTE_DESC;
        //## end canistercommand::CanisterTotal::getCOURIER_ROUTE_DESC%3A02D85D0363.get
      }


      //## Attribute: COURIER_ROUTE_PTR%3A1148480151
      const int& getCOURIER_ROUTE_PTR () const
      {
        //## begin canistercommand::CanisterTotal::getCOURIER_ROUTE_PTR%3A1148480151.get preserve=no
        return m_lCOURIER_ROUTE_PTR;
        //## end canistercommand::CanisterTotal::getCOURIER_ROUTE_PTR%3A1148480151.get
      }


      //## Attribute: CUR_TYPE%39AD050E007A
      const short int& getCUR_TYPE () const
      {
        //## begin canistercommand::CanisterTotal::getCUR_TYPE%39AD050E007A.get preserve=no
        return m_siCUR_TYPE;
        //## end canistercommand::CanisterTotal::getCUR_TYPE%39AD050E007A.get
      }


      //## Attribute: CURRENCY_CODE%39AD04ED0343
      const reusable::string& getCURRENCY_CODE () const
      {
        //## begin canistercommand::CanisterTotal::getCURRENCY_CODE%39AD04ED0343.get preserve=no
        return m_strCURRENCY_CODE;
        //## end canistercommand::CanisterTotal::getCURRENCY_CODE%39AD04ED0343.get
      }


      //## Attribute: DEVICE_ADDRESS%39AD03D700F3
      const reusable::string& getDEVICE_ADDRESS () const
      {
        //## begin canistercommand::CanisterTotal::getDEVICE_ADDRESS%39AD03D700F3.get preserve=no
        return m_strDEVICE_ADDRESS;
        //## end canistercommand::CanisterTotal::getDEVICE_ADDRESS%39AD03D700F3.get
      }


      //## Attribute: DEVICE_CITY%39AD03E3017D
      const reusable::string& getDEVICE_CITY () const
      {
        //## begin canistercommand::CanisterTotal::getDEVICE_CITY%39AD03E3017D.get preserve=no
        return m_strDEVICE_CITY;
        //## end canistercommand::CanisterTotal::getDEVICE_CITY%39AD03E3017D.get
      }


      //## Attribute: DEVICE_COUNTRY%39AD03C90161
      const reusable::string& getDEVICE_COUNTRY () const
      {
        //## begin canistercommand::CanisterTotal::getDEVICE_COUNTRY%39AD03C90161.get preserve=no
        return m_strDEVICE_COUNTRY;
        //## end canistercommand::CanisterTotal::getDEVICE_COUNTRY%39AD03C90161.get
      }


      //## Attribute: DEVICE_POSTAL_CODE%4BEA7B7701F1
      const reusable::string& getDEVICE_POSTAL_CODE () const
      {
        //## begin canistercommand::CanisterTotal::getDEVICE_POSTAL_CODE%4BEA7B7701F1.get preserve=no
        return m_strDEVICE_POSTAL_CODE;
        //## end canistercommand::CanisterTotal::getDEVICE_POSTAL_CODE%4BEA7B7701F1.get
      }


      //## Attribute: DEVICE_REGION%4BEA7C440215
      const reusable::string& getDEVICE_REGION () const
      {
        //## begin canistercommand::CanisterTotal::getDEVICE_REGION%4BEA7C440215.get preserve=no
        return m_strDEVICE_REGION;
        //## end canistercommand::CanisterTotal::getDEVICE_REGION%4BEA7C440215.get
      }


      //## Attribute: DISPNSD_ITEM_COUNT%39AD05470285
      const short int& getDISPNSD_ITEM_COUNT () const
      {
        //## begin canistercommand::CanisterTotal::getDISPNSD_ITEM_COUNT%39AD05470285.get preserve=no
        return m_siDISPNSD_ITEM_COUNT;
        //## end canistercommand::CanisterTotal::getDISPNSD_ITEM_COUNT%39AD05470285.get
      }


      //## Attribute: ENTITY_ID%39AD01340211
      const reusable::string& getENTITY_ID () const
      {
        //## begin canistercommand::CanisterTotal::getENTITY_ID%39AD01340211.get preserve=no
        return m_strENTITY_ID;
        //## end canistercommand::CanisterTotal::getENTITY_ID%39AD01340211.get
      }


      //## Attribute: INST_ID%39AD03AD03D8
      const reusable::string& getINST_ID () const
      {
        //## begin canistercommand::CanisterTotal::getINST_ID%39AD03AD03D8.get preserve=no
        return m_strINST_ID;
        //## end canistercommand::CanisterTotal::getINST_ID%39AD03AD03D8.get
      }


      //## Attribute: INST_NAME%39AD03BB019D
      const reusable::string& getINST_NAME () const
      {
        //## begin canistercommand::CanisterTotal::getINST_NAME%39AD03BB019D.get preserve=no
        return m_strINST_NAME;
        //## end canistercommand::CanisterTotal::getINST_NAME%39AD03BB019D.get
      }


      //## Attribute: ITEM_VALUE%39AD050400A8
      const int& getITEM_VALUE () const
      {
        //## begin canistercommand::CanisterTotal::getITEM_VALUE%39AD050400A8.get preserve=no
        return m_lITEM_VALUE;
        //## end canistercommand::CanisterTotal::getITEM_VALUE%39AD050400A8.get
      }


      //## Attribute: LOW_CASH_FLG_NULL%39D89CA50198
      const short int& getLOW_CASH_FLG_NULL () const
      {
        //## begin canistercommand::CanisterTotal::getLOW_CASH_FLG_NULL%39D89CA50198.get preserve=no
        return m_siLOW_CASH_FLG_NULL;
        //## end canistercommand::CanisterTotal::getLOW_CASH_FLG_NULL%39D89CA50198.get
      }


      //## Attribute: LOW_CASH_FLG%39D89CEB0045
      const reusable::string& getLOW_CASH_FLG () const
      {
        //## begin canistercommand::CanisterTotal::getLOW_CASH_FLG%39D89CEB0045.get preserve=no
        return m_strLOW_CASH_FLG;
        //## end canistercommand::CanisterTotal::getLOW_CASH_FLG%39D89CEB0045.get
      }


      //## Attribute: NULL%4BED862A0017
      const short int& getNULL () const
      {
        //## begin canistercommand::CanisterTotal::getNULL%4BED862A0017.get preserve=no
        return m_siNULL;
        //## end canistercommand::CanisterTotal::getNULL%4BED862A0017.get
      }


      //## Attribute: PROC_ID%39AD039702A0
      const reusable::string& getPROC_ID () const
      {
        //## begin canistercommand::CanisterTotal::getPROC_ID%39AD039702A0.get preserve=no
        return m_strPROC_ID;
        //## end canistercommand::CanisterTotal::getPROC_ID%39AD039702A0.get
      }


      //## Attribute: PROC_NAME%39AD03A300A8
      const reusable::string& getPROC_NAME () const
      {
        //## begin canistercommand::CanisterTotal::getPROC_NAME%39AD03A300A8.get preserve=no
        return m_strPROC_NAME;
        //## end canistercommand::CanisterTotal::getPROC_NAME%39AD03A300A8.get
      }


      //## Attribute: SUBJECT_STATE%39C8D0FF0081
      const reusable::string& getSUBJECT_STATE () const
      {
        //## begin canistercommand::CanisterTotal::getSUBJECT_STATE%39C8D0FF0081.get preserve=no
        return m_strSUBJECT_STATE;
        //## end canistercommand::CanisterTotal::getSUBJECT_STATE%39C8D0FF0081.get
      }


      //## Attribute: SUBJECT_STATE_NULL%39C8D123015F
      const short int& getSUBJECT_STATE_NULL () const
      {
        //## begin canistercommand::CanisterTotal::getSUBJECT_STATE_NULL%39C8D123015F.get preserve=no
        return m_siSUBJECT_STATE_NULL;
        //## end canistercommand::CanisterTotal::getSUBJECT_STATE_NULL%39C8D123015F.get
      }


      //## Attribute: TSTAMP_REPLACE%4410DFE00148
      const reusable::string& getTSTAMP_REPLACE () const
      {
        //## begin canistercommand::CanisterTotal::getTSTAMP_REPLACE%4410DFE00148.get preserve=no
        return m_strTSTAMP_REPLACE;
        //## end canistercommand::CanisterTotal::getTSTAMP_REPLACE%4410DFE00148.get
      }


      //## Attribute: TSTAMP_REPLACE_TO%39AEC01400BF
      const reusable::string& getTSTAMP_REPLACE_TO () const
      {
        //## begin canistercommand::CanisterTotal::getTSTAMP_REPLACE_TO%39AEC01400BF.get preserve=no
        return m_strTSTAMP_REPLACE_TO;
        //## end canistercommand::CanisterTotal::getTSTAMP_REPLACE_TO%39AEC01400BF.get
      }


    // Additional Public Declarations
      //## begin canistercommand::CanisterTotal%39AD005E03AE.public preserve=yes
      //## end canistercommand::CanisterTotal%39AD005E03AE.public

  protected:
    // Additional Protected Declarations
      //## begin canistercommand::CanisterTotal%39AD005E03AE.protected preserve=yes
      //## end canistercommand::CanisterTotal%39AD005E03AE.protected

  private:
    // Additional Private Declarations
      //## begin canistercommand::CanisterTotal%39AD005E03AE.private preserve=yes
      //## end canistercommand::CanisterTotal%39AD005E03AE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin canistercommand::CanisterTotal::BEGINNING_AMT%39AD05F50086.attr preserve=no  public: double {U} 0
      double m_dBEGINNING_AMT;
      //## end canistercommand::CanisterTotal::BEGINNING_AMT%39AD05F50086.attr

      //## begin canistercommand::CanisterTotal::BEGINNING_COUNT%39AD06200114.attr preserve=no  public: int {U} 0
      int m_lBEGINNING_COUNT;
      //## end canistercommand::CanisterTotal::BEGINNING_COUNT%39AD06200114.attr

      //## begin canistercommand::CanisterTotal::CANISTER_NO%39AD0425020E.attr preserve=no  public: short int {U} 0
      short int m_siCANISTER_NO;
      //## end canistercommand::CanisterTotal::CANISTER_NO%39AD0425020E.attr

      //## begin canistercommand::CanisterTotal::COURIER_DESC%3A02D81D0180.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strCOURIER_DESC;
      //## end canistercommand::CanisterTotal::COURIER_DESC%3A02D81D0180.attr

      //## begin canistercommand::CanisterTotal::COURIER_OFFICE_ID%3A02D7F5002E.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strCOURIER_OFFICE_ID;
      //## end canistercommand::CanisterTotal::COURIER_OFFICE_ID%3A02D7F5002E.attr

      //## begin canistercommand::CanisterTotal::COURIER_OFFICE_ID_NULL%3A02D7C00213.attr preserve=no  public: short int {U} 0
      short int m_siCOURIER_OFFICE_ID_NULL;
      //## end canistercommand::CanisterTotal::COURIER_OFFICE_ID_NULL%3A02D7C00213.attr

      //## begin canistercommand::CanisterTotal::COURIER_PTR%3A114804017B.attr preserve=no  public: int {U} 0
      int m_lCOURIER_PTR;
      //## end canistercommand::CanisterTotal::COURIER_PTR%3A114804017B.attr

      //## begin canistercommand::CanisterTotal::COURIER_ROUTE_ID_NULL%3A02D82F0302.attr preserve=no  public: short int {U} 0
      short int m_siCOURIER_ROUTE_ID_NULL;
      //## end canistercommand::CanisterTotal::COURIER_ROUTE_ID_NULL%3A02D82F0302.attr

      //## begin canistercommand::CanisterTotal::COURIER_ROUTE_ID%3A02D845012D.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strCOURIER_ROUTE_ID;
      //## end canistercommand::CanisterTotal::COURIER_ROUTE_ID%3A02D845012D.attr

      //## begin canistercommand::CanisterTotal::COURIER_ROUTE_DESC%3A02D85D0363.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strCOURIER_ROUTE_DESC;
      //## end canistercommand::CanisterTotal::COURIER_ROUTE_DESC%3A02D85D0363.attr

      //## begin canistercommand::CanisterTotal::COURIER_ROUTE_PTR%3A1148480151.attr preserve=no  public: int {U} 0
      int m_lCOURIER_ROUTE_PTR;
      //## end canistercommand::CanisterTotal::COURIER_ROUTE_PTR%3A1148480151.attr

      //## begin canistercommand::CanisterTotal::CUR_TYPE%39AD050E007A.attr preserve=no  public: short int {U} 0
      short int m_siCUR_TYPE;
      //## end canistercommand::CanisterTotal::CUR_TYPE%39AD050E007A.attr

      //## begin canistercommand::CanisterTotal::CURRENCY_CODE%39AD04ED0343.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strCURRENCY_CODE;
      //## end canistercommand::CanisterTotal::CURRENCY_CODE%39AD04ED0343.attr

      //## begin canistercommand::CanisterTotal::DEVICE_ADDRESS%39AD03D700F3.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strDEVICE_ADDRESS;
      //## end canistercommand::CanisterTotal::DEVICE_ADDRESS%39AD03D700F3.attr

      //## begin canistercommand::CanisterTotal::DEVICE_CITY%39AD03E3017D.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strDEVICE_CITY;
      //## end canistercommand::CanisterTotal::DEVICE_CITY%39AD03E3017D.attr

      //## begin canistercommand::CanisterTotal::DEVICE_COUNTRY%39AD03C90161.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strDEVICE_COUNTRY;
      //## end canistercommand::CanisterTotal::DEVICE_COUNTRY%39AD03C90161.attr

      //## begin canistercommand::CanisterTotal::DEVICE_POSTAL_CODE%4BEA7B7701F1.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strDEVICE_POSTAL_CODE;
      //## end canistercommand::CanisterTotal::DEVICE_POSTAL_CODE%4BEA7B7701F1.attr

      //## begin canistercommand::CanisterTotal::DEVICE_REGION%4BEA7C440215.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strDEVICE_REGION;
      //## end canistercommand::CanisterTotal::DEVICE_REGION%4BEA7C440215.attr

      //## begin canistercommand::CanisterTotal::DISPNSD_ITEM_COUNT%39AD05470285.attr preserve=no  public: short int {U} 0
      short int m_siDISPNSD_ITEM_COUNT;
      //## end canistercommand::CanisterTotal::DISPNSD_ITEM_COUNT%39AD05470285.attr

      //## begin canistercommand::CanisterTotal::ENTITY_ID%39AD01340211.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strENTITY_ID;
      //## end canistercommand::CanisterTotal::ENTITY_ID%39AD01340211.attr

      //## begin canistercommand::CanisterTotal::INST_ID%39AD03AD03D8.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strINST_ID;
      //## end canistercommand::CanisterTotal::INST_ID%39AD03AD03D8.attr

      //## begin canistercommand::CanisterTotal::INST_NAME%39AD03BB019D.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strINST_NAME;
      //## end canistercommand::CanisterTotal::INST_NAME%39AD03BB019D.attr

      //## begin canistercommand::CanisterTotal::ITEM_VALUE%39AD050400A8.attr preserve=no  public: int {U} 0
      int m_lITEM_VALUE;
      //## end canistercommand::CanisterTotal::ITEM_VALUE%39AD050400A8.attr

      //## begin canistercommand::CanisterTotal::LOW_CASH_FLG_NULL%39D89CA50198.attr preserve=no  public: short int {U} 0
      short int m_siLOW_CASH_FLG_NULL;
      //## end canistercommand::CanisterTotal::LOW_CASH_FLG_NULL%39D89CA50198.attr

      //## begin canistercommand::CanisterTotal::LOW_CASH_FLG%39D89CEB0045.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strLOW_CASH_FLG;
      //## end canistercommand::CanisterTotal::LOW_CASH_FLG%39D89CEB0045.attr

      //## begin canistercommand::CanisterTotal::NULL%4BED862A0017.attr preserve=no  public: short int {U} 0
      short int m_siNULL;
      //## end canistercommand::CanisterTotal::NULL%4BED862A0017.attr

      //## begin canistercommand::CanisterTotal::PROC_ID%39AD039702A0.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strPROC_ID;
      //## end canistercommand::CanisterTotal::PROC_ID%39AD039702A0.attr

      //## begin canistercommand::CanisterTotal::PROC_NAME%39AD03A300A8.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strPROC_NAME;
      //## end canistercommand::CanisterTotal::PROC_NAME%39AD03A300A8.attr

      //## begin canistercommand::CanisterTotal::SUBJECT_STATE%39C8D0FF0081.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strSUBJECT_STATE;
      //## end canistercommand::CanisterTotal::SUBJECT_STATE%39C8D0FF0081.attr

      //## begin canistercommand::CanisterTotal::SUBJECT_STATE_NULL%39C8D123015F.attr preserve=no  public: short int {U} 0
      short int m_siSUBJECT_STATE_NULL;
      //## end canistercommand::CanisterTotal::SUBJECT_STATE_NULL%39C8D123015F.attr

      //## Attribute: TSTAMP_TRANS_TO%39AD063001B7
      //## begin canistercommand::CanisterTotal::TSTAMP_TRANS_TO%39AD063001B7.attr preserve=no  public: string[2] {U} 
      string m_strTSTAMP_TRANS_TO[2];
      //## end canistercommand::CanisterTotal::TSTAMP_TRANS_TO%39AD063001B7.attr

      //## begin canistercommand::CanisterTotal::TSTAMP_REPLACE%4410DFE00148.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strTSTAMP_REPLACE;
      //## end canistercommand::CanisterTotal::TSTAMP_REPLACE%4410DFE00148.attr

      //## begin canistercommand::CanisterTotal::TSTAMP_REPLACE_TO%39AEC01400BF.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strTSTAMP_REPLACE_TO;
      //## end canistercommand::CanisterTotal::TSTAMP_REPLACE_TO%39AEC01400BF.attr

    // Additional Implementation Declarations
      //## begin canistercommand::CanisterTotal%39AD005E03AE.implementation preserve=yes
      //## end canistercommand::CanisterTotal%39AD005E03AE.implementation

};

//## begin canistercommand::CanisterTotal%39AD005E03AE.postscript preserve=yes
//## end canistercommand::CanisterTotal%39AD005E03AE.postscript

} // namespace canistercommand

//## begin module%39AD02D800E3.epilog preserve=yes
using namespace canistercommand;
//## end module%39AD02D800E3.epilog


#endif
