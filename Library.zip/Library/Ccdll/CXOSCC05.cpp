//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39AD02FB013D.cm preserve=no
//	$Date:   Oct 24 2019 10:27:06  $ $Author:   e1009839  $
//	$Revision:   1.18  $
//## end module%39AD02FB013D.cm

//## begin module%39AD02FB013D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39AD02FB013D.cp

//## Module: CXOSCC05%39AD02FB013D; Package body
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXOSCC05.cpp

//## begin module%39AD02FB013D.additionalIncludes preserve=no
//## end module%39AD02FB013D.additionalIncludes

//## begin module%39AD02FB013D.includes preserve=yes
// $Date:   Oct 24 2019 10:27:06  $ $Author:   e1009839  $ $Revision:   1.18  $
//## end module%39AD02FB013D.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCC04_h
#include "CXODCC04.hpp"
#endif
#ifndef CXOSCC05_h
#include "CXODCC05.hpp"
#endif


//## begin module%39AD02FB013D.declarations preserve=no
//## end module%39AD02FB013D.declarations

//## begin module%39AD02FB013D.additionalDeclarations preserve=yes
//## end module%39AD02FB013D.additionalDeclarations


//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

// Class canistercommand::CanisterTotal

CanisterTotal::CanisterTotal()
  //## begin CanisterTotal::CanisterTotal%39AD005E03AE_const.hasinit preserve=no
      : m_dBEGINNING_AMT(0),
        m_lBEGINNING_COUNT(0),
        m_siCANISTER_NO(0),
        m_siCOURIER_OFFICE_ID_NULL(0),
        m_lCOURIER_PTR(0),
        m_siCOURIER_ROUTE_ID_NULL(0),
        m_lCOURIER_ROUTE_PTR(0),
        m_siCUR_TYPE(0),
        m_siDISPNSD_ITEM_COUNT(0),
        m_lITEM_VALUE(0),
        m_siLOW_CASH_FLG_NULL(0),
        m_siNULL(0),
        m_siSUBJECT_STATE_NULL(0)
  //## end CanisterTotal::CanisterTotal%39AD005E03AE_const.hasinit
  //## begin CanisterTotal::CanisterTotal%39AD005E03AE_const.initialization preserve=yes
  //## end CanisterTotal::CanisterTotal%39AD005E03AE_const.initialization
{
  //## begin canistercommand::CanisterTotal::CanisterTotal%39AD005E03AE_const.body preserve=yes
   memcpy(m_sID,"CC05",4);
  //## end canistercommand::CanisterTotal::CanisterTotal%39AD005E03AE_const.body
}


CanisterTotal::~CanisterTotal()
{
  //## begin canistercommand::CanisterTotal::~CanisterTotal%39AD005E03AE_dest.body preserve=yes
  //## end canistercommand::CanisterTotal::~CanisterTotal%39AD005E03AE_dest.body
}



//## Other Operations (implementation)
void CanisterTotal::bind (Query& hQuery, bool bATM)
{
  //## begin canistercommand::CanisterTotal::bind%39AD012000DB.body preserve=yes
   hQuery.bind("PROCESSOR","PROC_ID",Column::STRING,&m_strPROC_ID);
   hQuery.bind("PROCESSOR","PROC_NAME",Column::STRING,&m_strPROC_NAME);
   hQuery.bind("INSTITUTION","INST_ID",Column::STRING,&m_strINST_ID);
   hQuery.bind("INSTITUTION","NAME",Column::STRING,&m_strINST_NAME);
   hQuery.bind("DEVICE","COUNTRY",Column::STRING,&m_strDEVICE_COUNTRY);
   hQuery.bind("DEVICE","ADDRESS",Column::STRING,&m_strDEVICE_ADDRESS);
   hQuery.bind("DEVICE","REGION",Column::STRING,&m_strDEVICE_REGION);
   hQuery.bind("DEVICE","POSTAL_CODE",Column::STRING,&m_strDEVICE_POSTAL_CODE);
   hQuery.bind("DEVICE","CITY",Column::STRING,&m_strDEVICE_CITY);
   hQuery.bind("T_FIN_ENTITY","ENTITY_ID",Column::STRING,&m_strENTITY_ID);
   if (!bATM)
   {
      hQuery.bind("T_CANISTER","CANISTER_NO",Column::SHORT,&m_siCANISTER_NO);
      hQuery.bind("T_CANISTER","ITEM_VALUE",Column::LONG,&m_lITEM_VALUE);
      hQuery.bind("T_CANISTER","CUR_TYPE",Column::SHORT,&m_siCUR_TYPE);
      hQuery.bind("T_CANISTER","CURRENCY_CODE",Column::STRING,&m_strCURRENCY_CODE);
      hQuery.bind("T_CAN_PERIOD","BEGINNING_AMT",Column::DOUBLE,&m_dBEGINNING_AMT);
      hQuery.bind("T_CAN_PERIOD","BEGINNING_COUNT",Column::LONG,&m_lBEGINNING_COUNT);
      hQuery.bind("T_CAN_PERIOD","TSTAMP_REPLACE",Column::STRING,&m_strTSTAMP_REPLACE);
      hQuery.bind("T_CAN_PERIOD","TSTAMP_REPLACE_TO",Column::STRING,&m_strTSTAMP_REPLACE_TO);
      hQuery.bind("T_CAN_PERIOD","TSTAMP_TRANS_TO",Column::STRING,&m_strTSTAMP_TRANS_TO[1]);
      hQuery.bind("T_FIN_PERIOD","TSTAMP_TRANS_TO",Column::STRING,&m_strTSTAMP_TRANS_TO[0]);
      hQuery.bind("T_CAN_TOTAL","DISPNSD_ITEM_COUNT",Column::SHORT,&m_siDISPNSD_ITEM_COUNT,&m_siNULL);
   }
   hQuery.bind("SUBJECT_STATE","SUBJECT_STATE",Column::STRING,&m_strSUBJECT_STATE,&m_siSUBJECT_STATE_NULL);
   hQuery.bind("SUBJECT_STATE","LOW_CASH_FLG",Column::STRING,&m_strLOW_CASH_FLG,&m_siLOW_CASH_FLG_NULL);
   hQuery.bind("DEVICE_COURIER","COURIER_OFFICE_ID",Column::STRING,&m_strCOURIER_OFFICE_ID,&m_siCOURIER_OFFICE_ID_NULL);
   hQuery.bind("DEVICE_COURIER","DESCRIPTION",Column::STRING,&m_strCOURIER_DESC);
   hQuery.bind("DEVICE_COURIER","COURIER_PTR",Column::LONG,&m_lCOURIER_PTR);
   hQuery.bind("DEVICE_COURIER_RTE","COURIER_ROUTE_ID",Column::STRING,&m_strCOURIER_ROUTE_ID,&m_siCOURIER_ROUTE_ID_NULL);
   hQuery.bind("DEVICE_COURIER_RTE","DESCRIPTION",Column::STRING,&m_strCOURIER_ROUTE_DESC);
   hQuery.bind("DEVICE_COURIER_RTE","COURIER_ROUTE_PTR",Column::LONG,&m_lCOURIER_ROUTE_PTR);
   if (!bATM)
      hQuery.setOrderByClause("PROC_ID,INST_ID,ENTITY_ID ASC,TSTAMP_REPLACE DESC");
   else
      hQuery.setOrderByClause("PROC_ID,INST_ID,ENTITY_ID");
  //## end canistercommand::CanisterTotal::bind%39AD012000DB.body
}

string* CanisterTotal::getTSTAMP_TRANS_TO ()
{
  //## begin canistercommand::CanisterTotal::getTSTAMP_TRANS_TO%4410E10F0222.body preserve=yes
   return &m_strTSTAMP_TRANS_TO[0];
  //## end canistercommand::CanisterTotal::getTSTAMP_TRANS_TO%4410E10F0222.body
}

// Additional Declarations
  //## begin canistercommand::CanisterTotal%39AD005E03AE.declarations preserve=yes
  //## end canistercommand::CanisterTotal%39AD005E03AE.declarations

} // namespace canistercommand

//## begin module%39AD02FB013D.epilog preserve=yes
//## end module%39AD02FB013D.epilog
