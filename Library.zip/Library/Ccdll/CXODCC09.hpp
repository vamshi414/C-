//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5DAE5F3203A5.cm preserve=no
//	$Date:   Oct 24 2019 10:43:24  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5DAE5F3203A5.cm

//## begin module%5DAE5F3203A5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5DAE5F3203A5.cp

//## Module: CXOSCC09%5DAE5F3203A5; Package specification
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXODCC09.hpp

#ifndef CXOSCC09_h
#define CXOSCC09_h 1

//## begin module%5DAE5F3203A5.additionalIncludes preserve=no
//## end module%5DAE5F3203A5.additionalIncludes

//## begin module%5DAE5F3203A5.includes preserve=yes
//## end module%5DAE5F3203A5.includes

#ifndef CXOSCC03_h
#include "CXODCC03.hpp"
#endif
#ifndef CXOSAT03_h
#include "CXODAT03.hpp"
#endif
#ifndef CXOSAT02_h
#include "CXODAT02.hpp"
#endif

//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
class DeviceViewConstraint;
} // namespace canistercommand

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%5DAE5F3203A5.declarations preserve=no
//## end module%5DAE5F3203A5.declarations

//## begin module%5DAE5F3203A5.additionalDeclarations preserve=yes
//## end module%5DAE5F3203A5.additionalDeclarations


namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

//## begin canistercommand::CurrentATMPosition%5DAE5E95026E.preface preserve=yes
//## end canistercommand::CurrentATMPosition%5DAE5E95026E.preface

//## Class: CurrentATMPosition%5DAE5E95026E
//## Category: Device Management::CanisterCommand_CAT%39A2966401E2
//## Subsystem: CCDLL%39A29BAF006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5DAF0B5702EC;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5DAF0B5C0060;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5DAF0B6B03D3;DeviceViewConstraint { -> F}
//## Uses: <unnamed>%5DB068AB01C4;entitysegment::SwitchBusinessDay { -> F}

class DllExport CurrentATMPosition : public CurrentDevicePosition  //## Inherits: <unnamed>%5DAF06F20189
{
  //## begin canistercommand::CurrentATMPosition%5DAE5E95026E.initialDeclarations preserve=yes
  //## end canistercommand::CurrentATMPosition%5DAE5E95026E.initialDeclarations

  public:
    //## Constructors (generated)
      CurrentATMPosition();

    //## Destructor (generated)
      virtual ~CurrentATMPosition();


    //## Other Operations (specified)
      //## Operation: execute%5DAE61C50063
      virtual int execute ();

      //## Operation: update%5DAF07320222
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin canistercommand::CurrentATMPosition%5DAE5E95026E.public preserve=yes
      //## end canistercommand::CurrentATMPosition%5DAE5E95026E.public

  protected:

    //## Other Operations (specified)
      //## Operation: exportTotals%5DAF626E02FA
      virtual void exportTotals ();

    // Additional Protected Declarations
      //## begin canistercommand::CurrentATMPosition%5DAE5E95026E.protected preserve=yes
      //## end canistercommand::CurrentATMPosition%5DAE5E95026E.protected

  private:
    // Additional Private Declarations
      //## begin canistercommand::CurrentATMPosition%5DAE5E95026E.private preserve=yes
      //## end canistercommand::CurrentATMPosition%5DAE5E95026E.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%5DAFB78B02D4
      //## Role: CurrentATMPosition::<m_hATMEvent>%5DAFB78C0132
      //## begin canistercommand::CurrentATMPosition::<m_hATMEvent>%5DAFB78C0132.role preserve=no  public: atm::ATMEvent { -> VHgN}
      atm::ATMEvent m_hATMEvent;
      //## end canistercommand::CurrentATMPosition::<m_hATMEvent>%5DAFB78C0132.role

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%5DAFB79300F0
      //## Role: CurrentATMPosition::<m_hATMActivity>%5DAFB7930303
      //## begin canistercommand::CurrentATMPosition::<m_hATMActivity>%5DAFB7930303.role preserve=no  public: atm::ATMActivity { -> VHgN}
      atm::ATMActivity m_hATMActivity;
      //## end canistercommand::CurrentATMPosition::<m_hATMActivity>%5DAFB7930303.role

    // Additional Implementation Declarations
      //## begin canistercommand::CurrentATMPosition%5DAE5E95026E.implementation preserve=yes
      //## end canistercommand::CurrentATMPosition%5DAE5E95026E.implementation

};

//## begin canistercommand::CurrentATMPosition%5DAE5E95026E.postscript preserve=yes
//## end canistercommand::CurrentATMPosition%5DAE5E95026E.postscript

} // namespace canistercommand

//## begin module%5DAE5F3203A5.epilog preserve=yes
//## end module%5DAE5F3203A5.epilog


#endif
