//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5BB79E1C0309.cm preserve=no
//	$Date:   Jan 09 2020 13:06:08  $ $Author:   e1009839  $
//	$Revision:   1.9  $
//## end module%5BB79E1C0309.cm

//## begin module%5BB79E1C0309.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5BB79E1C0309.cp

//## Module: CXOSCC08%5BB79E1C0309; Package body
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXOSCC08.cpp

//## begin module%5BB79E1C0309.additionalIncludes preserve=no
//## end module%5BB79E1C0309.additionalIncludes

//## begin module%5BB79E1C0309.includes preserve=yes
//## end module%5BB79E1C0309.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCC08_h
#include "CXODCC08.hpp"
#endif


//## begin module%5BB79E1C0309.declarations preserve=no
//## end module%5BB79E1C0309.declarations

//## begin module%5BB79E1C0309.additionalDeclarations preserve=yes
//## end module%5BB79E1C0309.additionalDeclarations


//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
#define FIELDS 70
Fields ATM_Fields[FIELDS + 1] =
{
   "a         ","NET_TERM_ID",0,0,
   "a         ","VENDOR_MODEL",0,0,
   "a         ","ADDRESS",0,0,
   "a         ","NEXT_ID",0,0,
   "a         ","CITY",0,0,
   "a         ","REPORTING_REGION",0,0,
   "a         ","REGION",0,0,
   "a         ","SUBJECT_STATE",0,0,
   "a         ","STATE_REASON",0,0,
   "a         ","LOW_CASH_FLG",0,0,
   "a         ","NORMAL_OPEN_HOUR",0,0,
   "a         ","NORMAL_CLOSE_HOUR",0,0,
   "a         ","LOAD",0,0,
   "a         ","VAULT",0,0,
   "a         ","DEFAULT_CUR_CODE",0,0,
   "d%-18.0f  ","CASSETTES_END",0,0,
   "d%-18.0f  ","CASH_END",0,0,
   "d%-18.0f  ","CHECK_END",0,0,
   "l         ","TRAN_COUNT1",0,0,
   "a         ","CUR_RECON_NET1",0,0,
   "d%-18.0f  ","AMT_SURCHARGE1",0,0,
   "d%-18.0f  ","AMT_RECON_NET1",0,0,
   "l         ","TRAN_COUNT30",0,0,
   "a         ","CUR_RECON_NET30",0,0,
   "d%-18.0f  ","AMT_SURCHARGE30",0,0,
   "d%-18.0f  ","AMT_RECON_NET30",0,0,
   "l         ","TRAN_COUNT60",0,0,
   "a         ","CUR_RECON_NET60",0,0,
   "d%-18.0f  ","AMT_SURCHARGE60",0,0,
   "d%-18.0f  ","AMT_RECON_NET60",0,0,
   "s         ","CUR_TYPE1",0,0,
   "l         ","ITEM_COUNT1",0,0,
   "l         ","ITEM_VALUE1",0,0,
   "a         ","CUR_CODE1",0,0,
   "d%-18.0f  ","CASSETTE1_END",0,0,
   "s         ","CUR_TYPE2",0,0,
   "l         ","ITEM_COUNT2",0,0,
   "l         ","ITEM_VALUE2",0,0,
   "a         ","CUR_CODE2",0,0,
   "d%-18.0f  ","CASSETTE2_END",0,0,
   "s         ","CUR_TYPE3",0,0,
   "l         ","ITEM_COUNT3",0,0,
   "l         ","ITEM_VALUE3",0,0,
   "a         ","CUR_CODE3",0,0,
   "d%-18.0f  ","CASSETTE3_END",0,0,
   "s         ","CUR_TYPE4",0,0,
   "l         ","ITEM_COUNT4",0,0,
   "l         ","ITEM_VALUE4",0,0,
   "a         ","CUR_CODE4",0,0,
   "d%-18.0f  ","CASSETTE4_END",0,0,
   "s         ","CUR_TYPE5",0,0,
   "l         ","ITEM_COUNT5",0,0,
   "l         ","ITEM_VALUE5",0,0,
   "a         ","CUR_CODE5",0,0,
   "d%-18.0f  ","CASSETTE5_END",0,0,
   "s         ","CUR_TYPE6",0,0,
   "l         ","ITEM_COUNT6",0,0,
   "l         ","ITEM_VALUE6",0,0,
   "a         ","CUR_CODE6",0,0,
   "d%-18.0f  ","CASSETTE6_END",0,0,
   "s         ","CUR_TYPE7",0,0,
   "l         ","ITEM_COUNT7",0,0,
   "l         ","ITEM_VALUE7",0,0,
   "a         ","CUR_CODE7",0,0,
   "d%-18.0f  ","CASSETTE7_END",0,0,
   "s         ","CUR_TYPE8",0,0,
   "l         ","ITEM_COUNT8",0,0,
   "l         ","ITEM_VALUE8",0,0,
   "a         ","CUR_CODE8",0,0,
   "d%-18.0f  ","CASSETTE8_END",0,0,
   "~","~",0,0,
};
//## end canistercommand%39A2966401E2.initialDeclarations

// Class canistercommand::ATM

ATM::ATM()
  //## begin ATM::ATM%5BB79D6D01DC_const.hasinit preserve=no
      : m_iACTIVITY_TYPE(0),
        m_dCASH_END(0),
        m_dCASSETTES_END(0),
        m_dCHECK_END(0)
  //## end ATM::ATM%5BB79D6D01DC_const.hasinit
  //## begin ATM::ATM%5BB79D6D01DC_const.initialization preserve=yes
  //## end ATM::ATM%5BB79D6D01DC_const.initialization
{
  //## begin canistercommand::ATM::ATM%5BB79D6D01DC_const.body preserve=yes
   memcpy(m_sID,"CC08",4);
   reset();
   setFields();
  //## end canistercommand::ATM::ATM%5BB79D6D01DC_const.body
}

ATM::ATM(const ATM &right)
  //## begin ATM::ATM%5BB79D6D01DC_copy.hasinit preserve=no
  //## end ATM::ATM%5BB79D6D01DC_copy.hasinit
  //## begin ATM::ATM%5BB79D6D01DC_copy.initialization preserve=yes
   : Segment(right)
  //## end ATM::ATM%5BB79D6D01DC_copy.initialization
{
  //## begin canistercommand::ATM::ATM%5BB79D6D01DC_copy.body preserve=yes
   m_iACTIVITY_TYPE = right.m_iACTIVITY_TYPE;
   m_strADDRESS = right.m_strADDRESS;
   m_dCASH_END = right.m_dCASH_END;
   m_dCASSETTES_END = right.m_dCASSETTES_END;
   m_dCHECK_END = right.m_dCHECK_END;
   m_strCITY = right.m_strCITY;
   m_strCUSTOM_DATA = right.m_strCUSTOM_DATA;
   m_strDEFAULT_CUR_CODE = right.m_strDEFAULT_CUR_CODE;
   m_strDEVICE_ID = right.m_strDEVICE_ID;
   m_strLOAD = right.m_strLOAD;
   m_strLOW_CASH_FLG = right.m_strLOW_CASH_FLG;
   m_strNEXT_ID = right.m_strNEXT_ID;
   m_strNORMAL_CLOSE_HOUR = right.m_strNORMAL_CLOSE_HOUR;
   m_strNORMAL_OPEN_HOUR = right.m_strNORMAL_OPEN_HOUR;
   m_strREGION = right.m_strREGION;
   m_strREPORTING_REGION = right.m_strREPORTING_REGION;
   m_strSTATE_REASON = right.m_strSTATE_REASON;
   m_strSUBJECT_STATE = right.m_strSUBJECT_STATE;
   m_strTRAN_DISPOSITION = right.m_strTRAN_DISPOSITION;
   m_strVAULT = right.m_strVAULT;
   m_strVENDOR_MODEL = right.m_strVENDOR_MODEL;
   for (int i = 0;i < 4;++i)
   {
      m_dAMT_RECON_NET[i] = right.m_dAMT_RECON_NET[i];
      m_dAMT_SURCHARGE[i] = right.m_dAMT_SURCHARGE[i];
      m_strCUR_RECON_NET[i] = right.m_strCUR_RECON_NET[i];
      m_iTRAN_COUNT[i] = right.m_iTRAN_COUNT[i];
   }
   for (int i = 0;i < 9;++i)
   {
      m_dCASSETTEn_END[i] = right.m_dCASSETTEn_END[i];
      m_siCUR_TYPE[i] = right.m_siCUR_TYPE[i];
      m_iITEM_COUNT[i] = right.m_iITEM_COUNT[i];
      m_iITEM_VALUE[i] = right.m_iITEM_VALUE[i];
   }
  //## end canistercommand::ATM::ATM%5BB79D6D01DC_copy.body
}

ATM::ATM (const string& strDEVICE_ID, const string& strADDRESS, double dBalance)
  //## begin canistercommand::ATM::ATM%5BBB6D9D023C.hasinit preserve=no
      : m_iACTIVITY_TYPE(0),
        m_dCASH_END(0),
        m_dCASSETTES_END(0),
        m_dCHECK_END(0)
  //## end canistercommand::ATM::ATM%5BBB6D9D023C.hasinit
  //## begin canistercommand::ATM::ATM%5BBB6D9D023C.initialization preserve=yes
  //## end canistercommand::ATM::ATM%5BBB6D9D023C.initialization
{
  //## begin canistercommand::ATM::ATM%5BBB6D9D023C.body preserve=yes
   memcpy(m_sID,"CC08",4);
   reset();
   setFields();
  //## end canistercommand::ATM::ATM%5BBB6D9D023C.body
}


ATM::~ATM()
{
  //## begin canistercommand::ATM::~ATM%5BB79D6D01DC_dest.body preserve=yes
  //## end canistercommand::ATM::~ATM%5BB79D6D01DC_dest.body
}


ATM & ATM::operator=(const ATM &right)
{
  //## begin canistercommand::ATM::operator=%5BB79D6D01DC_assign.body preserve=yes
   if (&right == this)
      return *this;
   Segment::operator=(right);
   m_iACTIVITY_TYPE = right.m_iACTIVITY_TYPE;
   m_strADDRESS = right.m_strADDRESS;
   m_dCASH_END = right.m_dCASH_END;
   m_dCASSETTES_END = right.m_dCASSETTES_END;
   m_dCHECK_END = right.m_dCHECK_END;
   m_strCITY = right.m_strCITY;
   m_strCUSTOM_DATA = right.m_strCUSTOM_DATA;
   m_strDEFAULT_CUR_CODE = right.m_strDEFAULT_CUR_CODE;
   m_strDEVICE_ID = right.m_strDEVICE_ID;
   m_strLOAD = right.m_strLOAD;
   m_strLOW_CASH_FLG = right.m_strLOW_CASH_FLG;
   m_strNEXT_ID = right.m_strNEXT_ID;
   m_strNORMAL_CLOSE_HOUR = right.m_strNORMAL_CLOSE_HOUR;
   m_strNORMAL_OPEN_HOUR = right.m_strNORMAL_OPEN_HOUR;
   m_strREGION = right.m_strREGION;
   m_strREPORTING_REGION = right.m_strREPORTING_REGION;
   m_strSTATE_REASON = right.m_strSTATE_REASON;
   m_strSUBJECT_STATE = right.m_strSUBJECT_STATE;
   m_strTRAN_DISPOSITION = right.m_strTRAN_DISPOSITION;
   m_strVAULT = right.m_strVAULT;
   m_strVENDOR_MODEL = right.m_strVENDOR_MODEL;
   int i = 0;
   for (i = 0;i < 4;++i)
   {
      m_dAMT_RECON_NET[i] = right.m_dAMT_RECON_NET[i];
      m_dAMT_SURCHARGE[i] = right.m_dAMT_SURCHARGE[i];
      m_strCUR_RECON_NET[i] = right.m_strCUR_RECON_NET[i];
      m_iTRAN_COUNT[i] = right.m_iTRAN_COUNT[i];
   }
   for (int i = 0;i < 9;++i)
   {
      m_dCASSETTEn_END[i] = right.m_dCASSETTEn_END[i];
      m_siCUR_TYPE[i] = right.m_siCUR_TYPE[i];
      m_iITEM_COUNT[i] = right.m_iITEM_COUNT[i];
      m_iITEM_VALUE[i] = right.m_iITEM_VALUE[i];
      m_strCUR_CODE[i] = right.m_strCUR_CODE[i];
   }
   return *this;
  //## end canistercommand::ATM::operator=%5BB79D6D01DC_assign.body
}



//## Other Operations (implementation)
void ATM::bind (Query& hQuery)
{
  //## begin canistercommand::ATM::bind%5D3823C200A4.body preserve=yes
   hQuery.join("T_ATM_EVENT","LEFT OUTER","SUBJECT_STATE","NET_TERM_ID","SUBJECT");
   hQuery.join(0,"LEFT OUTER","SUBJECT_STATE","60","SUBJECT_TYPE");
   hQuery.setQualifier("QUALIFY","DEVICE");
   hQuery.join("T_ATM_EVENT","INNER","DEVICE","NET_TERM_ID","DEVICE_ID");
   hQuery.setQualifier("QUALIFY","REPORTING_LVL");
   hQuery.join("DEVICE","INNER","REPORTING_LVL","RPT_LVL_ID");
   hQuery.join("T_ATM_EVENT","LEFT OUTER","T_ATM_ACTIVITY","NET_TERM_ID");
   hQuery.join("T_ATM_EVENT","LEFT OUTER","T_ATM_ACTIVITY","DATE_RECON_ACQ");
   hQuery.join("T_ATM_EVENT","LEFT OUTER","T_ATM_ACTIVITY","TSTAMP_TRANS");
   hQuery.join("T_ATM_EVENT","LEFT OUTER","T_ATM_ACTIVITY","UNIQUENESS_KEY");
   hQuery.join("T_ATM_EVENT","LEFT OUTER","T_ATM_ACTIVITY","FUNCTION_CODE");
   hQuery.bind("T_ATM_EVENT","CASH_END",Column::DOUBLE,&m_dCASH_END);
   hQuery.bind("T_ATM_EVENT","CASSETTES_END",Column::DOUBLE,&m_dCASSETTES_END);
   char szTemp[10] = {"012345678"};
   char szCASSETTEn_CUR_CODE[19] = {"CASSETTEn_CUR_CODE"};
   char szCASSETTEn_CUR_TYPE[19] = {"CASSETTEn_CUR_TYPE"};
   char szCASSETTEn_END[14] = {"CASSETTEn_END"};
   char szCASSETTEn_VALUE[16] = {"CASSETTEn_VALUE"};
   for (int i = 1;i < 9;++i)
   {
      szCASSETTEn_CUR_CODE[8] = szTemp[i];
      szCASSETTEn_CUR_TYPE[8] = szTemp[i];
      szCASSETTEn_END[8] = szTemp[i];
      szCASSETTEn_VALUE[8] = szTemp[i];
      hQuery.bind("T_ATM_EVENT",szCASSETTEn_CUR_CODE,Column::STRING,&m_strCUR_CODE[i]);
      hQuery.bind("T_ATM_EVENT",szCASSETTEn_CUR_TYPE,Column::SHORT,&m_siCUR_TYPE[i]);
      hQuery.bind("T_ATM_EVENT",szCASSETTEn_END,Column::DOUBLE,&m_dCASSETTEn_END[i]);
      hQuery.bind("T_ATM_EVENT",szCASSETTEn_VALUE,Column::LONG,&m_iITEM_VALUE[i]);
   }
   hQuery.bind("T_ATM_EVENT","CHECK_END",Column::DOUBLE,&m_dCHECK_END);
   hQuery.bind("T_ATM_EVENT","NET_TERM_ID",Column::STRING,&m_strDEVICE_ID);
   hQuery.bind("T_ATM_ACTIVITY","ACTIVITY_TYPE",Column::LONG,&m_iACTIVITY_TYPE);
   hQuery.bind("T_ATM_ACTIVITY","AMT_RECON_NET",Column::DOUBLE,&m_dAMT_RECON_NET[0]);
   hQuery.bind("T_ATM_ACTIVITY","AMT_SURCHARGE",Column::DOUBLE,&m_dAMT_SURCHARGE[0]);
   hQuery.bind("T_ATM_ACTIVITY","CUR_RECON_NET",Column::STRING,&m_strCUR_RECON_NET[0]);
   hQuery.bind("T_ATM_ACTIVITY","TRAN_COUNT",Column::LONG,&m_iTRAN_COUNT[0]);
   hQuery.bind("T_ATM_ACTIVITY","ITEM_COUNT",Column::LONG,&m_iITEM_COUNT[0]);
   hQuery.bind("T_ATM_ACTIVITY","ITEM_VALUE",Column::LONG,&m_iITEM_VALUE[0]);
   hQuery.bind("T_ATM_ACTIVITY","CUR_TYPE",Column::SHORT,&m_siCUR_TYPE[0]);
   hQuery.bind("T_ATM_ACTIVITY","TRAN_DISPOSITION",Column::STRING,&m_strTRAN_DISPOSITION);
   hQuery.bind("DEVICE","ADDRESS",Column::STRING,&m_strADDRESS);
   hQuery.bind("DEVICE","CITY",Column::STRING,&m_strCITY);
   hQuery.bind("DEVICE","REPORTING_REGION",Column::STRING,&m_strREPORTING_REGION);
   hQuery.bind("DEVICE","CUSTOM_DATA",Column::STRING,&m_strCUSTOM_DATA);
   hQuery.bind("DEVICE","DEFAULT_CUR_CODE",Column::STRING,&m_strDEFAULT_CUR_CODE);
   hQuery.bind("DEVICE","NORMAL_CLOSE_HOUR",Column::STRING,&m_strNORMAL_CLOSE_HOUR);
   hQuery.bind("DEVICE","NORMAL_OPEN_HOUR",Column::STRING,&m_strNORMAL_OPEN_HOUR);
   hQuery.bind("DEVICE","REGION",Column::STRING,&m_strREGION);
   hQuery.bind("DEVICE","VENDOR_MODEL",Column::STRING,&m_strVENDOR_MODEL);
   hQuery.bind("REPORTING_LVL","NEXT_ID",Column::STRING,&m_strNEXT_ID);
   hQuery.bind("SUBJECT_STATE","LOW_CASH_FLG",Column::STRING,&m_strLOW_CASH_FLG);
   hQuery.bind("SUBJECT_STATE","STATE_REASON",Column::STRING,&m_strSTATE_REASON);
   hQuery.bind("SUBJECT_STATE","SUBJECT_STATE",Column::STRING,&m_strSUBJECT_STATE);
  //## end canistercommand::ATM::bind%5D3823C200A4.body
}

struct  Fields* ATM::fields () const
{
  //## begin canistercommand::ATM::fields%5BB79E760211.body preserve=yes
   return &ATM_Fields[0];
  //## end canistercommand::ATM::fields%5BB79E760211.body
}

double ATM::getAMT_RECON_NET (int iIndex)
{
  //## begin canistercommand::ATM::getAMT_RECON_NET%5D4896FC0112.body preserve=yes
   return m_dAMT_RECON_NET[iIndex];
  //## end canistercommand::ATM::getAMT_RECON_NET%5D4896FC0112.body
}

double ATM::getCASSETTEn_END (int iIndex)
{
  //## begin canistercommand::ATM::getCASSETTEn_END%5D56D1B102CC.body preserve=yes
   return m_dCASSETTEn_END[iIndex];
  //## end canistercommand::ATM::getCASSETTEn_END%5D56D1B102CC.body
}

const reusable::string& ATM::getCUR_CODE (int iIndex)
{
  //## begin canistercommand::ATM::getCUR_CODE%5DBC888E0155.body preserve=yes
   return m_strCUR_CODE[iIndex];
  //## end canistercommand::ATM::getCUR_CODE%5DBC888E0155.body
}

short int ATM::getCUR_TYPE (int iIndex)
{
  //## begin canistercommand::ATM::getCUR_TYPE%5DBC888D038A.body preserve=yes
   return m_siCUR_TYPE[iIndex];
  //## end canistercommand::ATM::getCUR_TYPE%5DBC888D038A.body
}

int ATM::getITEM_COUNT (int iIndex)
{
  //## begin canistercommand::ATM::getITEM_COUNT%5D570E8403A2.body preserve=yes
   return m_iITEM_COUNT[iIndex];
  //## end canistercommand::ATM::getITEM_COUNT%5D570E8403A2.body
}

int ATM::getITEM_VALUE (int iIndex)
{
  //## begin canistercommand::ATM::getITEM_VALUE%5D570E9A00A6.body preserve=yes
   return m_iITEM_VALUE[iIndex];
  //## end canistercommand::ATM::getITEM_VALUE%5D570E9A00A6.body
}

void ATM::reset ()
{
  //## begin canistercommand::ATM::reset%5D56CE0D0050.body preserve=yes
   int i = 0;
   for (i = 1;i < 4;++i)
   {
      m_dAMT_RECON_NET[i] = 0;
      m_iTRAN_COUNT[i] = 0;
      m_dAMT_SURCHARGE[i] = 0;
   }
  //## end canistercommand::ATM::reset%5D56CE0D0050.body
}

void ATM::setActivityType ()
{
  //## begin canistercommand::ATM::setActivityType%5D3823A40148.body preserve=yes
   int i = 0;
   switch (m_iACTIVITY_TYPE)
   {
      case 1:
         i = 1;
         break;
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
      case 17:
      case 18:
         i = m_iACTIVITY_TYPE - 10;
         if (m_strTRAN_DISPOSITION == "1")
            m_iITEM_COUNT[i] += m_iITEM_COUNT[0];
         else
            m_iITEM_COUNT[i] -= m_iITEM_COUNT[0];
         m_iITEM_VALUE[i] = m_iITEM_VALUE[0];
         m_siCUR_TYPE[i] = m_siCUR_TYPE[0];
         return;
      case 30:
         i = 2;
         break;
      case 60:
         i = 3;
         break;
      default:
         return;
   }
   m_strCUR_RECON_NET[i] = m_strCUR_RECON_NET[0];
   if (m_strTRAN_DISPOSITION == "1")
   {
      m_dAMT_RECON_NET[i] += m_dAMT_RECON_NET[0];
      m_dAMT_SURCHARGE[i] += m_dAMT_SURCHARGE[0];
      m_iTRAN_COUNT[i] += m_iTRAN_COUNT[0];
   }
   else
   {
      m_dAMT_RECON_NET[i] -= m_dAMT_RECON_NET[0];
      m_dAMT_SURCHARGE[i] -= m_dAMT_SURCHARGE[0];
      m_iTRAN_COUNT[i] -= m_iTRAN_COUNT[0];
   }
  //## end canistercommand::ATM::setActivityType%5D3823A40148.body
}

void ATM::setCASSETTEn_END (int iIndex, double dCASSETTEn_END)
{
  //## begin canistercommand::ATM::setCASSETTEn_END%5D56D1B503DB.body preserve=yes
   m_dCASSETTEn_END[iIndex] = dCASSETTEn_END;
  //## end canistercommand::ATM::setCASSETTEn_END%5D56D1B503DB.body
}

void ATM::setCUR_CODE (int iIndex, const reusable::string& strCUR_CODE)
{
  //## begin canistercommand::ATM::setCUR_CODE%5DBC3D960163.body preserve=yes
   m_strCUR_CODE[iIndex] = strCUR_CODE;
  //## end canistercommand::ATM::setCUR_CODE%5DBC3D960163.body
}

void ATM::setCUR_TYPE (int iIndex, short int siCUR_TYPE)
{
  //## begin canistercommand::ATM::setCUR_TYPE%5DBC3D96000B.body preserve=yes
   m_siCUR_TYPE[iIndex] = siCUR_TYPE;
  //## end canistercommand::ATM::setCUR_TYPE%5DBC3D96000B.body
}

void ATM::setFields ()
{
  //## begin canistercommand::ATM::setFields%5BBB6A4C02FC.body preserve=yes
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strDEVICE_ID;
   m_pField[1] = &m_strVENDOR_MODEL;
   m_pField[2] = &m_strADDRESS;
   m_pField[3] = &m_strNEXT_ID;
   m_pField[4] = &m_strCITY;
   m_pField[5] = &m_strREPORTING_REGION;
   m_pField[6] = &m_strREGION;
   m_pField[7] = &m_strSUBJECT_STATE;
   m_pField[8] = &m_strSTATE_REASON;
   m_pField[9] = &m_strLOW_CASH_FLG;
   m_pField[10] = &m_strNORMAL_OPEN_HOUR;
   m_pField[11] = &m_strNORMAL_CLOSE_HOUR;
   m_pField[12] = &m_strLOAD;
   m_pField[13] = &m_strVAULT;
   m_pField[14] = &m_strDEFAULT_CUR_CODE;
   m_pField[15] = &m_dCASSETTES_END;
   m_pField[16] = &m_dCASH_END;
   m_pField[17] = &m_dCHECK_END;
   int j = 17;
   m_iTRAN_COUNT[0] = 0;
   m_dAMT_SURCHARGE[0] = 0;
   m_dAMT_RECON_NET[0] = 0;
   for (int i = 1;i < 4;++i)
   {
      m_iTRAN_COUNT[i] = 0;
      m_pField[++j] = &m_iTRAN_COUNT[i];
      m_pField[++j] = &m_strCUR_RECON_NET[i];
      m_dAMT_SURCHARGE[i] = 0;
      m_pField[++j] = &m_dAMT_SURCHARGE[i];
      m_dAMT_RECON_NET[i] = 0;
      m_pField[++j] = &m_dAMT_RECON_NET[i];
   }
   m_siCUR_TYPE[0] = 0;
   m_iITEM_COUNT[0] = 0;
   m_iITEM_VALUE[0] = 0;
   m_dCASSETTEn_END[0] = 0;
   for (int i = 1;i < 9;++i)
   {
      m_siCUR_TYPE[i] = 0;
      m_pField[++j] = &m_siCUR_TYPE[i];
      m_iITEM_COUNT[i] = 0;
      m_pField[++j] = &m_iITEM_COUNT[i];
      m_iITEM_VALUE[i] = 0;
      m_pField[++j] = &m_iITEM_VALUE[i];
      m_pField[++j] = &m_strCUR_CODE[i];
      m_dCASSETTEn_END[i] = 0;
      m_pField[++j] = &m_dCASSETTEn_END[i];
   }
  //## end canistercommand::ATM::setFields%5BBB6A4C02FC.body
}

void ATM::setITEM_COUNT (int iIndex, int iITEM_COUNT)
{
  //## begin canistercommand::ATM::setITEM_COUNT%5DBC3D920017.body preserve=yes
   m_iITEM_COUNT[iIndex] = iITEM_COUNT;
  //## end canistercommand::ATM::setITEM_COUNT%5DBC3D920017.body
}

void ATM::setITEM_VALUE (int iIndex, int iITEM_VALUE)
{
  //## begin canistercommand::ATM::setITEM_VALUE%5DBC3D9501B9.body preserve=yes
   m_iITEM_VALUE[iIndex] = iITEM_VALUE;
  //## end canistercommand::ATM::setITEM_VALUE%5DBC3D9501B9.body
}

// Additional Declarations
  //## begin canistercommand::ATM%5BB79D6D01DC.declarations preserve=yes
  //## end canistercommand::ATM%5BB79D6D01DC.declarations

} // namespace canistercommand

//## begin module%5BB79E1C0309.epilog preserve=yes
//## end module%5BB79E1C0309.epilog
