//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39A2A39A0212.cm preserve=no
//	$Date:   Oct 24 2019 10:12:28  $ $Author:   e1009839  $
//	$Revision:   1.18  $
//## end module%39A2A39A0212.cm

//## begin module%39A2A39A0212.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39A2A39A0212.cp

//## Module: CXOSCC03%39A2A39A0212; Package specification
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXODCC03.hpp

#ifndef CXOSCC03_h
#define CXOSCC03_h 1

//## begin module%39A2A39A0212.additionalIncludes preserve=no
//## end module%39A2A39A0212.additionalIncludes

//## begin module%39A2A39A0212.includes preserve=yes
// $Date:   Oct 24 2019 10:12:28  $ $Author:   e1009839  $ $Revision:   1.18  $
#include <vector>
//## end module%39A2A39A0212.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCC06_h
#include "CXODCC06.hpp"
#endif
#ifndef CXOSCC05_h
#include "CXODCC05.hpp"
#endif
#ifndef CXOSCC02_h
#include "CXODCC02.hpp"
#endif

//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
class DeviceViewConstraint;
} // namespace canistercommand

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
} // namespace segment

//## Modelname: Connex Library::ViewSegment_CAT%394E276801C1
namespace viewsegment {
class ReportControlSegment;

} // namespace viewsegment

//## begin module%39A2A39A0212.declarations preserve=no
//## end module%39A2A39A0212.declarations

//## begin module%39A2A39A0212.additionalDeclarations preserve=yes
//## end module%39A2A39A0212.additionalDeclarations


namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

//## begin canistercommand::CurrentDevicePosition%39A2A1E70027.preface preserve=yes
//## end canistercommand::CurrentDevicePosition%39A2A1E70027.preface

//## Class: CurrentDevicePosition%39A2A1E70027
//## Category: Device Management::CanisterCommand_CAT%39A2966401E2
//## Subsystem: CCDLL%39A29BAF006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39A2A221030F;viewsegment::ReportControlSegment { -> F}
//## Uses: <unnamed>%39A2A241015D;segment::InformationSegment { -> F}
//## Uses: <unnamed>%39A2A26F0235;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%39A2A28E0095;IF::Extract { -> F}
//## Uses: <unnamed>%39A2A2C00286;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%39ABBA1F006D;DeviceViewConstraint { -> F}
//## Uses: <unnamed>%462378D8036C;timer::Date { -> F}

class DllExport CurrentDevicePosition : public ViewCanister  //## Inherits: <unnamed>%39A2A20202F7
{
  //## begin canistercommand::CurrentDevicePosition%39A2A1E70027.initialDeclarations preserve=yes
  //## end canistercommand::CurrentDevicePosition%39A2A1E70027.initialDeclarations

  public:
    //## Constructors (generated)
      CurrentDevicePosition();

    //## Destructor (generated)
      virtual ~CurrentDevicePosition();


    //## Other Operations (specified)
      //## Operation: columns%39A2A2F80100
      virtual struct  ReportColumn* columns () const;

      //## Operation: execute%39A2A2F8013C
      virtual int execute ();

      //## Operation: update%39A2A2F80178
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin canistercommand::CurrentDevicePosition%39A2A1E70027.public preserve=yes
      //## end canistercommand::CurrentDevicePosition%39A2A1E70027.public

  protected:

    //## Other Operations (specified)
      //## Operation: exportTotals%39A2A2F801BE
      virtual void exportTotals ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: COURIER_DESC%3A02DD9403BD
      const reusable::string& getCOURIER_DESC () const
      {
        //## begin canistercommand::CurrentDevicePosition::getCOURIER_DESC%3A02DD9403BD.get preserve=no
        return m_strCOURIER_DESC;
        //## end canistercommand::CurrentDevicePosition::getCOURIER_DESC%3A02DD9403BD.get
      }


      //## Attribute: COURIER_OFFICE_ID%3A02DD94000F
      const reusable::string& getCOURIER_OFFICE_ID () const
      {
        //## begin canistercommand::CurrentDevicePosition::getCOURIER_OFFICE_ID%3A02DD94000F.get preserve=no
        return m_strCOURIER_OFFICE_ID;
        //## end canistercommand::CurrentDevicePosition::getCOURIER_OFFICE_ID%3A02DD94000F.get
      }


      //## Attribute: COURIER_PTR%3A115496025B
      const reusable::string& getCOURIER_PTR () const
      {
        //## begin canistercommand::CurrentDevicePosition::getCOURIER_PTR%3A115496025B.get preserve=no
        return m_strCOURIER_PTR;
        //## end canistercommand::CurrentDevicePosition::getCOURIER_PTR%3A115496025B.get
      }


      //## Attribute: COURIER_ROUTE_DESC%3A02DD990319
      const reusable::string& getCOURIER_ROUTE_DESC () const
      {
        //## begin canistercommand::CurrentDevicePosition::getCOURIER_ROUTE_DESC%3A02DD990319.get preserve=no
        return m_strCOURIER_ROUTE_DESC;
        //## end canistercommand::CurrentDevicePosition::getCOURIER_ROUTE_DESC%3A02DD990319.get
      }


      //## Attribute: COURIER_ROUTE_ID%3A02DD9702D1
      const reusable::string& getCOURIER_ROUTE_ID () const
      {
        //## begin canistercommand::CurrentDevicePosition::getCOURIER_ROUTE_ID%3A02DD9702D1.get preserve=no
        return m_strCOURIER_ROUTE_ID;
        //## end canistercommand::CurrentDevicePosition::getCOURIER_ROUTE_ID%3A02DD9702D1.get
      }


      //## Attribute: COURIER_ROUTE_PTR%3A1154B70317
      const reusable::string& getCOURIER_ROUTE_PTR () const
      {
        //## begin canistercommand::CurrentDevicePosition::getCOURIER_ROUTE_PTR%3A1154B70317.get preserve=no
        return m_strCOURIER_ROUTE_PTR;
        //## end canistercommand::CurrentDevicePosition::getCOURIER_ROUTE_PTR%3A1154B70317.get
      }


      //## Attribute: DEVICE_ADDRESS%39AD526F0193
      const reusable::string& getDEVICE_ADDRESS () const
      {
        //## begin canistercommand::CurrentDevicePosition::getDEVICE_ADDRESS%39AD526F0193.get preserve=no
        return m_strDEVICE_ADDRESS;
        //## end canistercommand::CurrentDevicePosition::getDEVICE_ADDRESS%39AD526F0193.get
      }


      //## Attribute: DEVICE_CITY%39AD526F01ED
      const reusable::string& getDEVICE_CITY () const
      {
        //## begin canistercommand::CurrentDevicePosition::getDEVICE_CITY%39AD526F01ED.get preserve=no
        return m_strDEVICE_CITY;
        //## end canistercommand::CurrentDevicePosition::getDEVICE_CITY%39AD526F01ED.get
      }


      //## Attribute: DEVICE_COUNTRY%39AD526F012F
      const reusable::string& getDEVICE_COUNTRY () const
      {
        //## begin canistercommand::CurrentDevicePosition::getDEVICE_COUNTRY%39AD526F012F.get preserve=no
        return m_strDEVICE_COUNTRY;
        //## end canistercommand::CurrentDevicePosition::getDEVICE_COUNTRY%39AD526F012F.get
      }


      //## Attribute: DEVICE_POSTAL_CODE%4BEA7CDE0227
      const reusable::string& getDEVICE_POSTAL_CODE () const
      {
        //## begin canistercommand::CurrentDevicePosition::getDEVICE_POSTAL_CODE%4BEA7CDE0227.get preserve=no
        return m_strDEVICE_POSTAL_CODE;
        //## end canistercommand::CurrentDevicePosition::getDEVICE_POSTAL_CODE%4BEA7CDE0227.get
      }


      //## Attribute: DEVICE_REGION%4BEA7CEE03AE
      const reusable::string& getDEVICE_REGION () const
      {
        //## begin canistercommand::CurrentDevicePosition::getDEVICE_REGION%4BEA7CEE03AE.get preserve=no
        return m_strDEVICE_REGION;
        //## end canistercommand::CurrentDevicePosition::getDEVICE_REGION%4BEA7CEE03AE.get
      }


      //## Attribute: INST_ID%39AD526F0067
      const reusable::string& getINST_ID () const
      {
        //## begin canistercommand::CurrentDevicePosition::getINST_ID%39AD526F0067.get preserve=no
        return m_strINST_ID;
        //## end canistercommand::CurrentDevicePosition::getINST_ID%39AD526F0067.get
      }


      //## Attribute: INST_NAME%39AD526F00CB
      const reusable::string& getINST_NAME () const
      {
        //## begin canistercommand::CurrentDevicePosition::getINST_NAME%39AD526F00CB.get preserve=no
        return m_strINST_NAME;
        //## end canistercommand::CurrentDevicePosition::getINST_NAME%39AD526F00CB.get
      }


      //## Attribute: LOW_CASH_FLG%39E5C834027C
      const reusable::string& getLOW_CASH_FLG () const
      {
        //## begin canistercommand::CurrentDevicePosition::getLOW_CASH_FLG%39E5C834027C.get preserve=no
        return m_strLOW_CASH_FLG;
        //## end canistercommand::CurrentDevicePosition::getLOW_CASH_FLG%39E5C834027C.get
      }


      //## Attribute: PROC_ID%39AD526E0390
      const reusable::string& getPROC_ID () const
      {
        //## begin canistercommand::CurrentDevicePosition::getPROC_ID%39AD526E0390.get preserve=no
        return m_strPROC_ID;
        //## end canistercommand::CurrentDevicePosition::getPROC_ID%39AD526E0390.get
      }


      //## Attribute: PROC_NAME%39AD526F000D
      const reusable::string& getPROC_NAME () const
      {
        //## begin canistercommand::CurrentDevicePosition::getPROC_NAME%39AD526F000D.get preserve=no
        return m_strPROC_NAME;
        //## end canistercommand::CurrentDevicePosition::getPROC_NAME%39AD526F000D.get
      }


      //## Attribute: SUBJECT_STATE%39E5C863002A
      const reusable::string& getSUBJECT_STATE () const
      {
        //## begin canistercommand::CurrentDevicePosition::getSUBJECT_STATE%39E5C863002A.get preserve=no
        return m_strSUBJECT_STATE;
        //## end canistercommand::CurrentDevicePosition::getSUBJECT_STATE%39E5C863002A.get
      }


      //## Attribute: TSTAMP_TRANS_TO%39AE6FB3032F
      const reusable::string& getTSTAMP_TRANS_TO () const
      {
        //## begin canistercommand::CurrentDevicePosition::getTSTAMP_TRANS_TO%39AE6FB3032F.get preserve=no
        return m_strTSTAMP_TRANS_TO;
        //## end canistercommand::CurrentDevicePosition::getTSTAMP_TRANS_TO%39AE6FB3032F.get
      }


    // Data Members for Class Attributes

      //## begin canistercommand::CurrentDevicePosition::COURIER_DESC%3A02DD9403BD.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strCOURIER_DESC;
      //## end canistercommand::CurrentDevicePosition::COURIER_DESC%3A02DD9403BD.attr

      //## begin canistercommand::CurrentDevicePosition::COURIER_OFFICE_ID%3A02DD94000F.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strCOURIER_OFFICE_ID;
      //## end canistercommand::CurrentDevicePosition::COURIER_OFFICE_ID%3A02DD94000F.attr

      //## begin canistercommand::CurrentDevicePosition::COURIER_PTR%3A115496025B.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strCOURIER_PTR;
      //## end canistercommand::CurrentDevicePosition::COURIER_PTR%3A115496025B.attr

      //## begin canistercommand::CurrentDevicePosition::COURIER_ROUTE_DESC%3A02DD990319.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strCOURIER_ROUTE_DESC;
      //## end canistercommand::CurrentDevicePosition::COURIER_ROUTE_DESC%3A02DD990319.attr

      //## begin canistercommand::CurrentDevicePosition::COURIER_ROUTE_ID%3A02DD9702D1.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strCOURIER_ROUTE_ID;
      //## end canistercommand::CurrentDevicePosition::COURIER_ROUTE_ID%3A02DD9702D1.attr

      //## begin canistercommand::CurrentDevicePosition::COURIER_ROUTE_PTR%3A1154B70317.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strCOURIER_ROUTE_PTR;
      //## end canistercommand::CurrentDevicePosition::COURIER_ROUTE_PTR%3A1154B70317.attr

      //## begin canistercommand::CurrentDevicePosition::DEVICE_ADDRESS%39AD526F0193.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strDEVICE_ADDRESS;
      //## end canistercommand::CurrentDevicePosition::DEVICE_ADDRESS%39AD526F0193.attr

      //## begin canistercommand::CurrentDevicePosition::DEVICE_CITY%39AD526F01ED.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strDEVICE_CITY;
      //## end canistercommand::CurrentDevicePosition::DEVICE_CITY%39AD526F01ED.attr

      //## begin canistercommand::CurrentDevicePosition::DEVICE_COUNTRY%39AD526F012F.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strDEVICE_COUNTRY;
      //## end canistercommand::CurrentDevicePosition::DEVICE_COUNTRY%39AD526F012F.attr

      //## begin canistercommand::CurrentDevicePosition::DEVICE_POSTAL_CODE%4BEA7CDE0227.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strDEVICE_POSTAL_CODE;
      //## end canistercommand::CurrentDevicePosition::DEVICE_POSTAL_CODE%4BEA7CDE0227.attr

      //## begin canistercommand::CurrentDevicePosition::DEVICE_REGION%4BEA7CEE03AE.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strDEVICE_REGION;
      //## end canistercommand::CurrentDevicePosition::DEVICE_REGION%4BEA7CEE03AE.attr

      //## Attribute: ENTITY_ID%39AD0882004C
      //## begin canistercommand::CurrentDevicePosition::ENTITY_ID%39AD0882004C.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strENTITY_ID;
      //## end canistercommand::CurrentDevicePosition::ENTITY_ID%39AD0882004C.attr

      //## begin canistercommand::CurrentDevicePosition::INST_ID%39AD526F0067.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strINST_ID;
      //## end canistercommand::CurrentDevicePosition::INST_ID%39AD526F0067.attr

      //## begin canistercommand::CurrentDevicePosition::INST_NAME%39AD526F00CB.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strINST_NAME;
      //## end canistercommand::CurrentDevicePosition::INST_NAME%39AD526F00CB.attr

      //## begin canistercommand::CurrentDevicePosition::LOW_CASH_FLG%39E5C834027C.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strLOW_CASH_FLG;
      //## end canistercommand::CurrentDevicePosition::LOW_CASH_FLG%39E5C834027C.attr

      //## begin canistercommand::CurrentDevicePosition::PROC_ID%39AD526E0390.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strPROC_ID;
      //## end canistercommand::CurrentDevicePosition::PROC_ID%39AD526E0390.attr

      //## begin canistercommand::CurrentDevicePosition::PROC_NAME%39AD526F000D.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strPROC_NAME;
      //## end canistercommand::CurrentDevicePosition::PROC_NAME%39AD526F000D.attr

      //## begin canistercommand::CurrentDevicePosition::SUBJECT_STATE%39E5C863002A.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strSUBJECT_STATE;
      //## end canistercommand::CurrentDevicePosition::SUBJECT_STATE%39E5C863002A.attr

      //## begin canistercommand::CurrentDevicePosition::TSTAMP_TRANS_TO%39AE6FB3032F.attr preserve=no  protected: reusable::string {UA} 
      reusable::string m_strTSTAMP_TRANS_TO;
      //## end canistercommand::CurrentDevicePosition::TSTAMP_TRANS_TO%39AE6FB3032F.attr

    // Data Members for Associations

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%39A2A25D0316
      //## Role: CurrentDevicePosition::<m_hQuery>%39A2A25F0106
      //## begin canistercommand::CurrentDevicePosition::<m_hQuery>%39A2A25F0106.role preserve=no  protected: reusable::Query { -> VHgAN}
      reusable::Query m_hQuery;
      //## end canistercommand::CurrentDevicePosition::<m_hQuery>%39A2A25F0106.role

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%39AD07860318
      //## Role: CurrentDevicePosition::<m_hCanisterTotal>%39AD078800E0
      //## begin canistercommand::CurrentDevicePosition::<m_hCanisterTotal>%39AD078800E0.role preserve=no  protected: canistercommand::CanisterTotal { -> VHgAN}
      CanisterTotal m_hCanisterTotal;
      //## end canistercommand::CurrentDevicePosition::<m_hCanisterTotal>%39AD078800E0.role

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%39AEB11302F5
      //## Role: CurrentDevicePosition::<m_hCanisterBalance>%39AEB114033D
      //## begin canistercommand::CurrentDevicePosition::<m_hCanisterBalance>%39AEB114033D.role preserve=no  protected: canistercommand::CanisterBalance { -> 0..nVHgAN}
      vector<CanisterBalance> m_hCanisterBalance;
      //## end canistercommand::CurrentDevicePosition::<m_hCanisterBalance>%39AEB114033D.role

    // Additional Protected Declarations
      //## begin canistercommand::CurrentDevicePosition%39A2A1E70027.protected preserve=yes
      //## end canistercommand::CurrentDevicePosition%39A2A1E70027.protected

  private:
    // Additional Private Declarations
      //## begin canistercommand::CurrentDevicePosition%39A2A1E70027.private preserve=yes
      //## end canistercommand::CurrentDevicePosition%39A2A1E70027.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin canistercommand::CurrentDevicePosition%39A2A1E70027.implementation preserve=yes
      //## end canistercommand::CurrentDevicePosition%39A2A1E70027.implementation

};

//## begin canistercommand::CurrentDevicePosition%39A2A1E70027.postscript preserve=yes
//## end canistercommand::CurrentDevicePosition%39A2A1E70027.postscript

} // namespace canistercommand

//## begin module%39A2A39A0212.epilog preserve=yes
using namespace canistercommand;
//## end module%39A2A39A0212.epilog


#endif
