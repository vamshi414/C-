//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39A2A3B40273.cm preserve=no
//	$Date:   May 26 2020 09:58:26  $ $Author:   e1009510  $
//	$Revision:   1.34  $
//## end module%39A2A3B40273.cm

//## begin module%39A2A3B40273.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39A2A3B40273.cp

//## Module: CXOSCC03%39A2A3B40273; Package body
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXOSCC03.cpp

//## begin module%39A2A3B40273.additionalIncludes preserve=no
//## end module%39A2A3B40273.additionalIncludes

//## begin module%39A2A3B40273.includes preserve=yes
#include <stdio.h>
#include <map>
//## end module%39A2A3B40273.includes

#ifndef CXOSVS08_h
#include "CXODVS08.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSCC04_h
#include "CXODCC04.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSCC03_h
#include "CXODCC03.hpp"
#endif


//## begin module%39A2A3B40273.declarations preserve=no
//## end module%39A2A3B40273.declarations

//## begin module%39A2A3B40273.additionalDeclarations preserve=yes
ReportColumn DeviceCurrentPositionReportColumns[79] =
{
   "RowID",          "CHAR",   "0007",    //DCP0000
   "Courier_Office_ID","CHAR", "0040",
   "Courier_Desc",   "CHAR",   "0050",
   "Courier_Ptr",    "CHAR",   "0010",
   "Courier_Route",  "CHAR",   "0015",
   "Cour_Rte_Desc",  "CHAR",   "0050",
   "Cour_Rte_Ptr",   "CHAR",   "0010",
   "Processor_ID",   "CHAR",   "0028",
   "Proc_Name",      "CHAR",   "0035",
   "Institution_ID", "CHAR",   "0028",
   "Inst_Name",      "CHAR",   "0035",
   "Device_ID",      "CHAR",   "0028",
   "Device_Address", "CHAR",   "0028",
   "Device_City",    "CHAR",   "0027",
   "Device_Country", "CHAR",   "0003",
   "Device_Status",  "CHAR",   "0001",
   "Low_Cash_Flg",   "CHAR",   "0001",
   "Tstamp_Trans_To","CHAR",   "0016",
   "NumNetCash",     "DECIMAL","0008",
   "NumCanisters",   "DECIMAL","0008",
   "NetCash1",       "DECIMAL","0018",
   "NetCashCC1",     "CHAR",   "0003",
   "NetCash2",       "DECIMAL","0018",
   "NetCashCC2",     "CHAR",   "0003",
   "NetCash3",       "DECIMAL","0018",
   "NetCashCC3",     "CHAR",   "0003",
   "NetCash4",       "DECIMAL","0018",
   "NetCashCC4",     "CHAR",   "0003",
   "NetCash5",       "DECIMAL","0018",
   "NetCashCC5",     "CHAR",   "0003",
   "NetCash6",       "DECIMAL","0018",
   "NetCashCC6",     "CHAR",   "0003",
   "NetCash7",       "DECIMAL","0018",
   "NetCashCC7",     "CHAR",   "0003",
   "NetCash8",       "DECIMAL","0018",
   "NetCashCC8",     "CHAR",   "0003",
   "Can1MediaType",  "CHAR",   "0002",
   "Can1Value",      "DECIMAL","0008",
   "Can1Count",      "DECIMAL","0008",
   "Can1Amt",        "DECIMAL","0018",
   "Can1Cur",        "CHAR",   "0003",
   "Can2MediaType",  "CHAR",   "0002",
   "Can2Value",      "DECIMAL","0008",
   "Can2Count",      "DECIMAL","0008",
   "Can2Amt",        "DECIMAL","0018",
   "Can2Cur",        "CHAR",   "0003",
   "Can3MediaType",  "CHAR",   "0002",
   "Can3Value",      "DECIMAL","0008",
   "Can3Count",      "DECIMAL","0008",
   "Can3Amt",        "DECIMAL","0018",
   "Can3Cur",        "CHAR",   "0003",
   "Can4MediaType",  "CHAR",   "0002",
   "Can4Value",      "DECIMAL","0008",
   "Can4Count",      "DECIMAL","0008",
   "Can4Amt",        "DECIMAL","0018",
   "Can4Cur",        "CHAR",   "0003",
   "Can5MediaType",  "CHAR",   "0002",
   "Can5Value",      "DECIMAL","0008",
   "Can5Count",      "DECIMAL","0008",
   "Can5Amt",        "DECIMAL","0018",
   "Can5Cur",        "CHAR",   "0003",
   "Can6MediaType",  "CHAR",   "0002",
   "Can6Value",      "DECIMAL","0008",
   "Can6Count",      "DECIMAL","0008",
   "Can6Amt",        "DECIMAL","0018",
   "Can6Cur",        "CHAR",   "0003",
   "Can7MediaType",  "CHAR",   "0002",
   "Can7Value",      "DECIMAL","0008",
   "Can7Count",      "DECIMAL","0008",
   "Can7Amt",        "DECIMAL","0018",
   "Can7Cur",        "CHAR",   "0003",
   "Can8MediaType",  "CHAR",   "0002",
   "Can8Value",      "DECIMAL","0008",
   "Can8Count",      "DECIMAL","0008",
   "Can8Amt",        "DECIMAL","0018",
   "Can8Cur",        "CHAR",   "0003",
   "Device_Region",  "CHAR",   "0003",
   "Device_Postal_Code","CHAR","0010",
   "~",              "~",      "0000"
};
//## end module%39A2A3B40273.additionalDeclarations


//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

// Class canistercommand::CurrentDevicePosition 

CurrentDevicePosition::CurrentDevicePosition()
  //## begin CurrentDevicePosition::CurrentDevicePosition%39A2A1E70027_const.hasinit preserve=no
      : m_hCanisterBalance(9)
  //## end CurrentDevicePosition::CurrentDevicePosition%39A2A1E70027_const.hasinit
  //## begin CurrentDevicePosition::CurrentDevicePosition%39A2A1E70027_const.initialization preserve=yes
  //## end CurrentDevicePosition::CurrentDevicePosition%39A2A1E70027_const.initialization
{
  //## begin canistercommand::CurrentDevicePosition::CurrentDevicePosition%39A2A1E70027_const.body preserve=yes
   memcpy(m_sID,"CC03",4);
   m_strMailTemplate = "DN##CC03";
  //## end canistercommand::CurrentDevicePosition::CurrentDevicePosition%39A2A1E70027_const.body
}


CurrentDevicePosition::~CurrentDevicePosition()
{
  //## begin canistercommand::CurrentDevicePosition::~CurrentDevicePosition%39A2A1E70027_dest.body preserve=yes
  //## end canistercommand::CurrentDevicePosition::~CurrentDevicePosition%39A2A1E70027_dest.body
}



//## Other Operations (implementation)
struct  ReportColumn* CurrentDevicePosition::columns () const
{
  //## begin canistercommand::CurrentDevicePosition::columns%39A2A2F80100.body preserve=yes
   return &DeviceCurrentPositionReportColumns[0];
  //## end canistercommand::CurrentDevicePosition::columns%39A2A2F80100.body
}

int CurrentDevicePosition::execute ()
{
  //## begin canistercommand::CurrentDevicePosition::execute%39A2A2F8013C.body preserve=yes
   // CL64: SW_Retrieves_Current_Canister_Totals_From_DB
   int lInfoIDNumber = DeviceViewConstraint::instance()->addConstraints(m_hQuery);
   if (lInfoIDNumber != 0)
      return lInfoIDNumber;
   m_hCanisterTotal.bind(m_hQuery);
   m_hQuery.attach(this);
   m_strENTITY_ID.erase();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*) DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(m_hQuery) == false
      || pSelectStatement->getRows() == 0
      || m_strENTITY_ID.empty())
      return STS_RECORD_NOT_FOUND;
   exportTotals();
   return 0;
  //## end canistercommand::CurrentDevicePosition::execute%39A2A2F8013C.body
}

void CurrentDevicePosition::exportTotals ()
{
  //## begin canistercommand::CurrentDevicePosition::exportTotals%39A2A2F801BE.body preserve=yes
   string strFormat("DCP0000%40.40s%50.50s%10.10s%15.15s%50.50s%10.10s" 
        "%28.28s%35.35s%28.28s%35.35s%28.28s"
        "%28.28s%27.27s%03.3s%1.1s%1.1s%16.16s%8d%8d"
        "%-18.0f%03.3s%-18.0f%03.3s%-18.0f%03.3s%-18.0f%03.3s"
        "%-18.0f%03.3s%-18.0f%03.3s%-18.0f%03.3s%-18.0f%03.3s"
        "%02hd%8d%8d%-18.0f%03.3s%02hd%8d%8d%-18.0f%03.3s"
        "%02hd%8d%8d%-18.0f%03.3s%02hd%8d%8d%-18.0f%03.3s"
        "%02hd%8d%8d%-18.0f%03.3s%02hd%8d%8d%-18.0f%03.3s"
        "%02hd%8d%8d%-18.0f%03.3s%02hd%8d%8d%-18.0f%03.3s"
        "%03.3s%10.10s");
   // use latest cash replacement (either device or sum of canisters)
   map<string,double,less<string> > hNetCash;
   map<string,double,less<string> >::iterator pNetCash;
   int i = 0;
   int j = 0;
   int k = 0;
   for (i = 1;i <= 8;++i)
      if (m_hCanisterBalance[i].getTSTAMP_REPLACE() > m_hCanisterBalance[0].getTSTAMP_REPLACE())
      {
         j = 1;
         k = 8;
         break;
      }
   // cash on hand by currency code
   for (i = j;i <= k;++i)
   {
      if (m_hCanisterBalance[i].getCURRENCY_CODE().length() > 0)
      {
         pNetCash = hNetCash.find(m_hCanisterBalance[i].getCURRENCY_CODE());
         if (pNetCash == hNetCash.end())
         {
            pair<map<string,double,less<string> >::iterator,bool> hResult;
            hResult = hNetCash.insert(map<string,double,less<string> >::value_type(m_hCanisterBalance[i].getCURRENCY_CODE(),0));
            pNetCash = hResult.first;
         }
         (*pNetCash).second += m_hCanisterBalance[i].getBEGINNING_AMT();
      }
   }
   // remaining bills and cash on hand
   int iCanisterCount = 0; // return 0 if cash replacement at device level
   int lBillCount[9];
   double dCashOnHand[9];
   lBillCount[0] = 0; // not used
   dCashOnHand[0] = 0; // not used
   for (i = 1;i <= 8;++i)
   {
      if (m_hCanisterBalance[i].getCURRENCY_CODE().length() > 0)
      {
         if (k == 8)
            ++iCanisterCount;
         pNetCash = hNetCash.find(m_hCanisterBalance[i].getCURRENCY_CODE());
         if (pNetCash != hNetCash.end())
            (*pNetCash).second -= (m_hCanisterBalance[i].getDISPNSD_ITEM_COUNT() * m_hCanisterBalance[i].getITEM_VALUE());
      }
      lBillCount[i] = m_hCanisterBalance[i].getBEGINNING_COUNT() - m_hCanisterBalance[i].getDISPNSD_ITEM_COUNT();
      dCashOnHand[i] = lBillCount[i] * m_hCanisterBalance[i].getITEM_VALUE();
   }
   // copy currency codes and balances
   string strNetCashCC[8];
   double dNetCash[8];
   for (i = 0;i < 8;++i)
      dNetCash[i] = 0;
   i = 0;
   for (pNetCash = hNetCash.begin();pNetCash != hNetCash.end();++pNetCash)
   {
      strNetCashCC[i] = (*pNetCash).first;
      dNetCash[i++] = (*pNetCash).second;
   }
   char* pszBuffer = new char[getRowLength() + 1];
   snprintf(pszBuffer,getRowLength() + 1,strFormat.c_str(),
      m_strCOURIER_OFFICE_ID.c_str(),
      m_strCOURIER_DESC.c_str(),
      m_strCOURIER_PTR.c_str(),
      m_strCOURIER_ROUTE_ID.c_str(),
      m_strCOURIER_ROUTE_DESC.c_str(),
      m_strCOURIER_ROUTE_PTR.c_str(),
      m_strPROC_ID.c_str(),
      m_strPROC_NAME.c_str(),
      m_strINST_ID.c_str(),
      m_strINST_NAME.c_str(),
      m_strENTITY_ID.c_str(),
      m_strDEVICE_ADDRESS.c_str(),
      m_strDEVICE_CITY.c_str(),
      m_strDEVICE_COUNTRY.c_str(),
      m_strSUBJECT_STATE.c_str(),
      m_strLOW_CASH_FLG.c_str(),
      m_strTSTAMP_TRANS_TO.c_str(),
      hNetCash.size(),
      iCanisterCount,
      dNetCash[0],
      strNetCashCC[0].c_str(),
      dNetCash[1],
      strNetCashCC[1].c_str(),
      dNetCash[2],
      strNetCashCC[2].c_str(),
      dNetCash[3],
      strNetCashCC[3].c_str(),
      dNetCash[4],
      strNetCashCC[4].c_str(),
      dNetCash[5],
      strNetCashCC[5].c_str(),
      dNetCash[6],
      strNetCashCC[6].c_str(),
      dNetCash[7],
      strNetCashCC[7].c_str(),
      m_hCanisterBalance[1].getCUR_TYPE(),
      m_hCanisterBalance[1].getITEM_VALUE(),
      lBillCount[1],
      dCashOnHand[1],
      m_hCanisterBalance[1].getCURRENCY_CODE().c_str(),
      m_hCanisterBalance[2].getCUR_TYPE(),
      m_hCanisterBalance[2].getITEM_VALUE(),
      lBillCount[2],
      dCashOnHand[2],
      m_hCanisterBalance[2].getCURRENCY_CODE().c_str(),
      m_hCanisterBalance[3].getCUR_TYPE(),
      m_hCanisterBalance[3].getITEM_VALUE(),
      lBillCount[3],
      dCashOnHand[3],
      m_hCanisterBalance[3].getCURRENCY_CODE().c_str(),
      m_hCanisterBalance[4].getCUR_TYPE(),
      m_hCanisterBalance[4].getITEM_VALUE(),
      lBillCount[4],
      dCashOnHand[4],
      m_hCanisterBalance[4].getCURRENCY_CODE().c_str(),
      m_hCanisterBalance[5].getCUR_TYPE(),
      m_hCanisterBalance[5].getITEM_VALUE(),
      lBillCount[5],
      dCashOnHand[5],
      m_hCanisterBalance[5].getCURRENCY_CODE().c_str(),
      m_hCanisterBalance[6].getCUR_TYPE(),
      m_hCanisterBalance[6].getITEM_VALUE(),
      lBillCount[6],
      dCashOnHand[6],
      m_hCanisterBalance[6].getCURRENCY_CODE().c_str(),
      m_hCanisterBalance[7].getCUR_TYPE(),
      m_hCanisterBalance[7].getITEM_VALUE(),
      lBillCount[7],
      dCashOnHand[7],
      m_hCanisterBalance[7].getCURRENCY_CODE().c_str(),
      m_hCanisterBalance[8].getCUR_TYPE(),
      m_hCanisterBalance[8].getITEM_VALUE(),
      lBillCount[8],
      dCashOnHand[8],
      m_hCanisterBalance[8].getCURRENCY_CODE().c_str(),
      m_strDEVICE_REGION.c_str(),
      m_strDEVICE_POSTAL_CODE.c_str());
   m_hRow.getBuffer() = pszBuffer;
   m_hRow.notify();
   delete [] pszBuffer;
   for (i = 0;i < 9;++i)
      m_hCanisterBalance[i].reset();
  //## end canistercommand::CurrentDevicePosition::exportTotals%39A2A2F801BE.body
}

void CurrentDevicePosition::update (Subject* pSubject)
{
  //## begin canistercommand::CurrentDevicePosition::update%39A2A2F80178.body preserve=yes
   // avoid canisters that have been removed or modified
   Date hDate1(Date::today());
   if (m_hCanisterTotal.getTSTAMP_TRANS_TO()[1] > m_hCanisterTotal.getTSTAMP_REPLACE())
   {
      Date hDate2(m_hCanisterTotal.getTSTAMP_TRANS_TO()[1].c_str());
      if (hDate2 < (hDate1 - 30))
         return;
   }
   else
   {
      Date hDate2(m_hCanisterTotal.getTSTAMP_REPLACE().c_str());
      if (hDate2 < (hDate1 - 30))
         return;
   }
   if (m_strENTITY_ID.length() == 0
      || m_strENTITY_ID != m_hCanisterTotal.getENTITY_ID())
   {
      if (m_strENTITY_ID.length() > 0)
         exportTotals();
      m_strENTITY_ID = m_hCanisterTotal.getENTITY_ID();
      m_strPROC_ID = m_hCanisterTotal.getPROC_ID();
      m_strPROC_NAME = m_hCanisterTotal.getPROC_NAME();
      m_strINST_ID = m_hCanisterTotal.getINST_ID();
      m_strINST_NAME = m_hCanisterTotal.getINST_NAME();
      m_strDEVICE_ADDRESS = m_hCanisterTotal.getDEVICE_ADDRESS();
      m_strDEVICE_CITY = m_hCanisterTotal.getDEVICE_CITY();
      m_strDEVICE_COUNTRY = m_hCanisterTotal.getDEVICE_COUNTRY();
      m_strDEVICE_REGION = m_hCanisterTotal.getDEVICE_REGION();
      m_strDEVICE_POSTAL_CODE = m_hCanisterTotal.getDEVICE_POSTAL_CODE();
      m_strTSTAMP_TRANS_TO = m_hCanisterTotal.getTSTAMP_TRANS_TO()[0];
      m_strSUBJECT_STATE = m_hCanisterTotal.getSUBJECT_STATE();
      m_strLOW_CASH_FLG = m_hCanisterTotal.getLOW_CASH_FLG();
      m_strCOURIER_OFFICE_ID.erase();
      m_strCOURIER_DESC.erase();
      m_strCOURIER_PTR.erase();
      char szTemp[11];
      if (m_hCanisterTotal.getCOURIER_OFFICE_ID_NULL() == 0)
      {
         m_strCOURIER_OFFICE_ID = m_hCanisterTotal.getCOURIER_OFFICE_ID();
         m_strCOURIER_DESC = m_hCanisterTotal.getCOURIER_DESC();
         snprintf(szTemp,sizeof(szTemp),"%010d",m_hCanisterTotal.getCOURIER_PTR());
         m_strCOURIER_PTR = szTemp;
      }
      m_strCOURIER_ROUTE_ID.erase();
      m_strCOURIER_ROUTE_DESC.erase();
      m_strCOURIER_ROUTE_PTR.erase();
      if (m_hCanisterTotal.getCOURIER_ROUTE_ID_NULL() == 0)
      {
         m_strCOURIER_ROUTE_ID = m_hCanisterTotal.getCOURIER_ROUTE_ID();
         m_strCOURIER_ROUTE_DESC = m_hCanisterTotal.getCOURIER_ROUTE_DESC();
         snprintf(szTemp,sizeof(szTemp),"%010d",m_hCanisterTotal.getCOURIER_ROUTE_PTR());
         m_strCOURIER_ROUTE_PTR = szTemp;
      }
   }
   if (m_hCanisterBalance[m_hCanisterTotal.getCANISTER_NO() + 1].getCURRENCY_CODE().empty() == false) 
      if (m_hCanisterBalance[m_hCanisterTotal.getCANISTER_NO() + 1].getCURRENCY_CODE() != m_hCanisterTotal.getCURRENCY_CODE() 
         || m_hCanisterBalance[m_hCanisterTotal.getCANISTER_NO() + 1].getCUR_TYPE() != m_hCanisterTotal.getCUR_TYPE() 
         || m_hCanisterBalance[m_hCanisterTotal.getCANISTER_NO() + 1].getITEM_VALUE() != m_hCanisterTotal.getITEM_VALUE()) 
         return;
   if (m_hCanisterTotal.getTSTAMP_REPLACE() > m_strTSTAMP_TRANS_TO)
      m_strTSTAMP_TRANS_TO = m_hCanisterTotal.getTSTAMP_REPLACE();
   if (m_hCanisterTotal.getTSTAMP_TRANS_TO()[0] > m_strTSTAMP_TRANS_TO)
      m_strTSTAMP_TRANS_TO = m_hCanisterTotal.getTSTAMP_TRANS_TO()[0];
   if (m_hCanisterTotal.getTSTAMP_TRANS_TO()[1] > m_strTSTAMP_TRANS_TO)
      m_strTSTAMP_TRANS_TO = m_hCanisterTotal.getTSTAMP_TRANS_TO()[1];
   m_hCanisterBalance[m_hCanisterTotal.getCANISTER_NO() + 1].add(m_hCanisterTotal);
  //## end canistercommand::CurrentDevicePosition::update%39A2A2F80178.body
}

// Additional Declarations
  //## begin canistercommand::CurrentDevicePosition%39A2A1E70027.declarations preserve=yes
  //## end canistercommand::CurrentDevicePosition%39A2A1E70027.declarations

} // namespace canistercommand

//## begin module%39A2A3B40273.epilog preserve=yes
//## end module%39A2A3B40273.epilog
