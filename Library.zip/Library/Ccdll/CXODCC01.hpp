//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39A29C06003E.cm preserve=no
//	$Date:   Oct 24 2019 10:46:00  $ $Author:   e1009839  $
//	$Revision:   1.12  $
//## end module%39A29C06003E.cm

//## begin module%39A29C06003E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39A29C06003E.cp

//## Module: CXOSCC01%39A29C06003E; Package specification
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXODCC01.hpp

#ifndef CXOSCC01_h
#define CXOSCC01_h 1

//## begin module%39A29C06003E.additionalIncludes preserve=no
//## end module%39A29C06003E.additionalIncludes

//## begin module%39A29C06003E.includes preserve=yes
// $Date:   Oct 24 2019 10:46:00  $ $Author:   e1009839  $ $Revision:   1.12  $
//## end module%39A29C06003E.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSVS06_h
#include "CXODVS06.hpp"
#endif
#ifndef CXOSVC07_h
#include "CXODVC07.hpp"
#endif

//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
class CurrentATMPosition;
class DeviceViewConstraint;
class CurrentDevicePosition;
class ViewCanister;
} // namespace canistercommand

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::ViewCommand_CAT%394E26F50072
namespace viewcommand {
class ReportMailCommand;
} // namespace viewcommand

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class ResponseTimeSegment;
class PrimaryKeySegment;
class MultipleRowContextSegment;
class CommonHeaderSegment;
} // namespace segment

//## Modelname: Connex Library::ViewSegment_CAT%394E276801C1
namespace viewsegment {
class ReportOptionSegment;

} // namespace viewsegment

//## begin module%39A29C06003E.declarations preserve=no
//## end module%39A29C06003E.declarations

//## begin module%39A29C06003E.additionalDeclarations preserve=yes
//## end module%39A29C06003E.additionalDeclarations


namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

//## begin canistercommand::DeviceViewCommand%39A29733012B.preface preserve=yes
//## end canistercommand::DeviceViewCommand%39A29733012B.preface

//## Class: DeviceViewCommand%39A29733012B
//	QTMXCANV - retrieve a canister totals view result set.
//## Category: Device Management::CanisterCommand_CAT%39A2966401E2
//## Subsystem: CCDLL%39A29BAF006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39A298CC0050;viewsegment::ReportOptionSegment { -> F}
//## Uses: <unnamed>%39A298CF03A7;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%39A298D30295;segment::MultipleRowContextSegment { -> F}
//## Uses: <unnamed>%39A298D8001B;segment::InformationSegment { -> F}
//## Uses: <unnamed>%39A2993B024E;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%39A2996B00E5;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%39A299760163;database::Database { -> F}
//## Uses: <unnamed>%39A299A5035F;IF::Message { -> F}
//## Uses: <unnamed>%39A299B8010D;IF::Extract { -> F}
//## Uses: <unnamed>%39A299E60218;entitysegment::Customer { -> F}
//## Uses: <unnamed>%39A2A400007E;CurrentDevicePosition { -> F}
//## Uses: <unnamed>%39ABB9AA0273;DeviceViewConstraint { -> F}
//## Uses: <unnamed>%3A0701520059;viewcommand::ReportMailCommand { -> F}
//## Uses: <unnamed>%3A2BDFE70179;monitor::UseCase { -> F}
//## Uses: <unnamed>%5D2509D1009E;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%5DAF5FC30298;CurrentATMPosition { -> F}

class DllExport DeviceViewCommand : public viewcommand::ReportCommand  //## Inherits: <unnamed>%39A297E000D0
{
  //## begin canistercommand::DeviceViewCommand%39A29733012B.initialDeclarations preserve=yes
  //## end canistercommand::DeviceViewCommand%39A29733012B.initialDeclarations

  public:
    //## Constructors (generated)
      DeviceViewCommand();

    //## Constructors (specified)
      //## Operation: DeviceViewCommand%39A29A2601AC
      DeviceViewCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~DeviceViewCommand();


    //## Other Operations (specified)
      //## Operation: execute%39A29A2601CA
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%39A29A2601DE
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin canistercommand::DeviceViewCommand%39A29733012B.public preserve=yes
      //## end canistercommand::DeviceViewCommand%39A29733012B.public

  protected:
    // Additional Protected Declarations
      //## begin canistercommand::DeviceViewCommand%39A29733012B.protected preserve=yes
      //## end canistercommand::DeviceViewCommand%39A29733012B.protected

  private:
    // Additional Private Declarations
      //## begin canistercommand::DeviceViewCommand%39A29733012B.private preserve=yes
      //## end canistercommand::DeviceViewCommand%39A29733012B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ColumnCount%39A29A3E00FC
      //## begin canistercommand::DeviceViewCommand::ColumnCount%39A29A3E00FC.attr preserve=no  private: int {U} 0
      int m_iColumnCount;
      //## end canistercommand::DeviceViewCommand::ColumnCount%39A29A3E00FC.attr

    // Data Members for Associations

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%39A2983600D6
      //## Role: DeviceViewCommand::<m_pPrimaryKeySegment>%39A298370164
      //## begin canistercommand::DeviceViewCommand::<m_pPrimaryKeySegment>%39A298370164.role preserve=no  public: segment::PrimaryKeySegment { -> RFHgN}
      segment::PrimaryKeySegment *m_pPrimaryKeySegment;
      //## end canistercommand::DeviceViewCommand::<m_pPrimaryKeySegment>%39A298370164.role

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%39A2987302B5
      //## Role: DeviceViewCommand::<m_hReportColumnSegment>%39A29875002D
      //## begin canistercommand::DeviceViewCommand::<m_hReportColumnSegment>%39A29875002D.role preserve=no  public: viewsegment::ReportColumnSegment { -> VHgN}
      viewsegment::ReportColumnSegment m_hReportColumnSegment;
      //## end canistercommand::DeviceViewCommand::<m_hReportColumnSegment>%39A29875002D.role

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%39A2991703C9
      //## Role: DeviceViewCommand::<m_hQuery>%39A29919017D
      //## begin canistercommand::DeviceViewCommand::<m_hQuery>%39A29919017D.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end canistercommand::DeviceViewCommand::<m_hQuery>%39A29919017D.role

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%39A2A0D9032C
      //## Role: DeviceViewCommand::<m_pViewCanister>%39A2A0DB01A8
      //## begin canistercommand::DeviceViewCommand::<m_pViewCanister>%39A2A0DB01A8.role preserve=no  public: canistercommand::ViewCanister { -> RFHgN}
      ViewCanister *m_pViewCanister;
      //## end canistercommand::DeviceViewCommand::<m_pViewCanister>%39A2A0DB01A8.role

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%3A08731B0231
      //## Role: DeviceViewCommand::<m_pListSegment>%3A08731C005C
      //## begin canistercommand::DeviceViewCommand::<m_pListSegment>%3A08731C005C.role preserve=no  public: segment::ListSegment { -> RHgN}
      segment::ListSegment *m_pListSegment;
      //## end canistercommand::DeviceViewCommand::<m_pListSegment>%3A08731C005C.role

    // Additional Implementation Declarations
      //## begin canistercommand::DeviceViewCommand%39A29733012B.implementation preserve=yes
      //## end canistercommand::DeviceViewCommand%39A29733012B.implementation

};

//## begin canistercommand::DeviceViewCommand%39A29733012B.postscript preserve=yes
//## end canistercommand::DeviceViewCommand%39A29733012B.postscript

} // namespace canistercommand

//## begin module%39A29C06003E.epilog preserve=yes
using namespace canistercommand;
//## end module%39A29C06003E.epilog


#endif
