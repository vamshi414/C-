//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5BB79E1A03C2.cm preserve=no
//	$Date:   Nov 04 2019 14:12:52  $ $Author:   e1009839  $
//	$Revision:   1.4  $
//## end module%5BB79E1A03C2.cm

//## begin module%5BB79E1A03C2.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5BB79E1A03C2.cp

//## Module: CXOSCC08%5BB79E1A03C2; Package specification
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXODCC08.hpp

#ifndef CXOSCC08_h
#define CXOSCC08_h 1

//## begin module%5BB79E1A03C2.additionalIncludes preserve=no
//## end module%5BB79E1A03C2.additionalIncludes

//## begin module%5BB79E1A03C2.includes preserve=yes
//## end module%5BB79E1A03C2.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%5BB79E1A03C2.declarations preserve=no
//## end module%5BB79E1A03C2.declarations

//## begin module%5BB79E1A03C2.additionalDeclarations preserve=yes
//## end module%5BB79E1A03C2.additionalDeclarations


//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

//## begin canistercommand::ATM%5BB79D6D01DC.preface preserve=yes
//## end canistercommand::ATM%5BB79D6D01DC.preface

//## Class: ATM%5BB79D6D01DC
//## Category: Device Management::CanisterCommand_CAT%39A2966401E2
//## Subsystem: CCDLL%39A29BAF006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5D381B8B0376;reusable::Query { -> F}

class DllExport ATM : public segment::Segment  //## Inherits: <unnamed>%5BB79D7E00EB
{
  //## begin canistercommand::ATM%5BB79D6D01DC.initialDeclarations preserve=yes
  //## end canistercommand::ATM%5BB79D6D01DC.initialDeclarations

  public:
    //## Constructors (generated)
      ATM();

      ATM(const ATM &right);

    //## Constructors (specified)
      //## Operation: ATM%5BBB6D9D023C
      ATM (const string& strDEVICE_ID, const string& strADDRESS, double dBalance);

    //## Destructor (generated)
      virtual ~ATM();

    //## Assignment Operation (generated)
      ATM & operator=(const ATM &right);


    //## Other Operations (specified)
      //## Operation: bind%5D3823C200A4
      void bind (Query& hQuery);

      //## Operation: fields%5BB79E760211
      virtual struct  Fields* fields () const;

      //## Operation: getAMT_RECON_NET%5D4896FC0112
      double getAMT_RECON_NET (int iIndex);

      //## Operation: getCASSETTEn_END%5D56D1B102CC
      double getCASSETTEn_END (int iIndex);

      //## Operation: getCUR_CODE%5DBC888E0155
      const reusable::string& getCUR_CODE (int iIndex);

      //## Operation: getCUR_TYPE%5DBC888D038A
      short int getCUR_TYPE (int iIndex);

      //## Operation: getITEM_COUNT%5D570E8403A2
      int getITEM_COUNT (int iIndex);

      //## Operation: getITEM_VALUE%5D570E9A00A6
      int getITEM_VALUE (int iIndex);

      //## Operation: reset%5D56CE0D0050
      virtual void reset ();

      //## Operation: setActivityType%5D3823A40148
      void setActivityType ();

      //## Operation: setCASSETTEn_END%5D56D1B503DB
      void setCASSETTEn_END (int iIndex, double dCASSETTEn_END);

      //## Operation: setCUR_CODE%5DBC3D960163
      void setCUR_CODE (int iIndex, const reusable::string& strCUR_CODE);

      //## Operation: setCUR_TYPE%5DBC3D96000B
      void setCUR_TYPE (int iIndex, short int siCUR_TYPE);

      //## Operation: setFields%5BBB6A4C02FC
      void setFields ();

      //## Operation: setITEM_COUNT%5DBC3D920017
      void setITEM_COUNT (int iIndex, int iITEM_COUNT);

      //## Operation: setITEM_VALUE%5DBC3D9501B9
      void setITEM_VALUE (int iIndex, int iITEM_VALUE);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ACTIVITY_TYPE%5D381CD50342
      const int& getACTIVITY_TYPE () const
      {
        //## begin canistercommand::ATM::getACTIVITY_TYPE%5D381CD50342.get preserve=no
        return m_iACTIVITY_TYPE;
        //## end canistercommand::ATM::getACTIVITY_TYPE%5D381CD50342.get
      }

      void setACTIVITY_TYPE (const int& value)
      {
        //## begin canistercommand::ATM::setACTIVITY_TYPE%5D381CD50342.set preserve=no
        m_iACTIVITY_TYPE = value;
        //## end canistercommand::ATM::setACTIVITY_TYPE%5D381CD50342.set
      }


      //## Attribute: ADDRESS%5D3821040245
      const reusable::string& getADDRESS () const
      {
        //## begin canistercommand::ATM::getADDRESS%5D3821040245.get preserve=no
        return m_strADDRESS;
        //## end canistercommand::ATM::getADDRESS%5D3821040245.get
      }

      void setADDRESS (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setADDRESS%5D3821040245.set preserve=no
        m_strADDRESS = value;
        //## end canistercommand::ATM::setADDRESS%5D3821040245.set
      }


      //## Attribute: CASH_END%5D3821930082
      const double getCASH_END () const
      {
        //## begin canistercommand::ATM::getCASH_END%5D3821930082.get preserve=no
        return m_dCASH_END;
        //## end canistercommand::ATM::getCASH_END%5D3821930082.get
      }

      void setCASH_END (double value)
      {
        //## begin canistercommand::ATM::setCASH_END%5D3821930082.set preserve=no
        m_dCASH_END = value;
        //## end canistercommand::ATM::setCASH_END%5D3821930082.set
      }


      //## Attribute: CASSETTEn_END%5D56C3F001E1
      const double* const& getCASSETTEn_END () const
      {
        //## begin canistercommand::ATM::getCASSETTEn_END%5D56C3F001E1.get preserve=no
        return m_dCASSETTEn_END;
        //## end canistercommand::ATM::getCASSETTEn_END%5D56C3F001E1.get
      }


      //## Attribute: CASSETTES_END%5D3821930261
      const double getCASSETTES_END () const
      {
        //## begin canistercommand::ATM::getCASSETTES_END%5D3821930261.get preserve=no
        return m_dCASSETTES_END;
        //## end canistercommand::ATM::getCASSETTES_END%5D3821930261.get
      }

      void setCASSETTES_END (double value)
      {
        //## begin canistercommand::ATM::setCASSETTES_END%5D3821930261.set preserve=no
        m_dCASSETTES_END = value;
        //## end canistercommand::ATM::setCASSETTES_END%5D3821930261.set
      }


      //## Attribute: CHECK_END%5D3821940063
      const double getCHECK_END () const
      {
        //## begin canistercommand::ATM::getCHECK_END%5D3821940063.get preserve=no
        return m_dCHECK_END;
        //## end canistercommand::ATM::getCHECK_END%5D3821940063.get
      }

      void setCHECK_END (double value)
      {
        //## begin canistercommand::ATM::setCHECK_END%5D3821940063.set preserve=no
        m_dCHECK_END = value;
        //## end canistercommand::ATM::setCHECK_END%5D3821940063.set
      }


      //## Attribute: CITY%5D382274013A
      const reusable::string& getCITY () const
      {
        //## begin canistercommand::ATM::getCITY%5D382274013A.get preserve=no
        return m_strCITY;
        //## end canistercommand::ATM::getCITY%5D382274013A.get
      }

      void setCITY (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setCITY%5D382274013A.set preserve=no
        m_strCITY = value;
        //## end canistercommand::ATM::setCITY%5D382274013A.set
      }


      //## Attribute: CUSTOM_DATA%5D38227500A3
      const reusable::string& getCUSTOM_DATA () const
      {
        //## begin canistercommand::ATM::getCUSTOM_DATA%5D38227500A3.get preserve=no
        return m_strCUSTOM_DATA;
        //## end canistercommand::ATM::getCUSTOM_DATA%5D38227500A3.get
      }

      void setCUSTOM_DATA (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setCUSTOM_DATA%5D38227500A3.set preserve=no
        m_strCUSTOM_DATA = value;
        //## end canistercommand::ATM::setCUSTOM_DATA%5D38227500A3.set
      }


      //## Attribute: DEFAULT_CUR_CODE%5D7663F60001
      const reusable::string& getDEFAULT_CUR_CODE () const
      {
        //## begin canistercommand::ATM::getDEFAULT_CUR_CODE%5D7663F60001.get preserve=no
        return m_strDEFAULT_CUR_CODE;
        //## end canistercommand::ATM::getDEFAULT_CUR_CODE%5D7663F60001.get
      }

      void setDEFAULT_CUR_CODE (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setDEFAULT_CUR_CODE%5D7663F60001.set preserve=no
        m_strDEFAULT_CUR_CODE = value;
        //## end canistercommand::ATM::setDEFAULT_CUR_CODE%5D7663F60001.set
      }


      //## Attribute: DEVICE_ID%5D38227502E8
      const reusable::string& getDEVICE_ID () const
      {
        //## begin canistercommand::ATM::getDEVICE_ID%5D38227502E8.get preserve=no
        return m_strDEVICE_ID;
        //## end canistercommand::ATM::getDEVICE_ID%5D38227502E8.get
      }

      void setDEVICE_ID (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setDEVICE_ID%5D38227502E8.set preserve=no
        m_strDEVICE_ID = value;
        //## end canistercommand::ATM::setDEVICE_ID%5D38227502E8.set
      }


      //## Attribute: LOAD%5D38227600E6
      const reusable::string& getLOAD () const
      {
        //## begin canistercommand::ATM::getLOAD%5D38227600E6.get preserve=no
        return m_strLOAD;
        //## end canistercommand::ATM::getLOAD%5D38227600E6.get
      }

      void setLOAD (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setLOAD%5D38227600E6.set preserve=no
        m_strLOAD = value;
        //## end canistercommand::ATM::setLOAD%5D38227600E6.set
      }


      //## Attribute: LOW_CASH_FLG%5D38227602BF
      const reusable::string& getLOW_CASH_FLG () const
      {
        //## begin canistercommand::ATM::getLOW_CASH_FLG%5D38227602BF.get preserve=no
        return m_strLOW_CASH_FLG;
        //## end canistercommand::ATM::getLOW_CASH_FLG%5D38227602BF.get
      }

      void setLOW_CASH_FLG (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setLOW_CASH_FLG%5D38227602BF.set preserve=no
        m_strLOW_CASH_FLG = value;
        //## end canistercommand::ATM::setLOW_CASH_FLG%5D38227602BF.set
      }


      //## Attribute: NEXT_ID%5DB6E71000B5
      const reusable::string& getNEXT_ID () const
      {
        //## begin canistercommand::ATM::getNEXT_ID%5DB6E71000B5.get preserve=no
        return m_strNEXT_ID;
        //## end canistercommand::ATM::getNEXT_ID%5DB6E71000B5.get
      }

      void setNEXT_ID (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setNEXT_ID%5DB6E71000B5.set preserve=no
        m_strNEXT_ID = value;
        //## end canistercommand::ATM::setNEXT_ID%5DB6E71000B5.set
      }


      //## Attribute: NORMAL_CLOSE_HOUR%5D38227702E3
      const reusable::string& getNORMAL_CLOSE_HOUR () const
      {
        //## begin canistercommand::ATM::getNORMAL_CLOSE_HOUR%5D38227702E3.get preserve=no
        return m_strNORMAL_CLOSE_HOUR;
        //## end canistercommand::ATM::getNORMAL_CLOSE_HOUR%5D38227702E3.get
      }

      void setNORMAL_CLOSE_HOUR (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setNORMAL_CLOSE_HOUR%5D38227702E3.set preserve=no
        m_strNORMAL_CLOSE_HOUR = value;
        //## end canistercommand::ATM::setNORMAL_CLOSE_HOUR%5D38227702E3.set
      }


      //## Attribute: NORMAL_OPEN_HOUR%5D3822780111
      const reusable::string& getNORMAL_OPEN_HOUR () const
      {
        //## begin canistercommand::ATM::getNORMAL_OPEN_HOUR%5D3822780111.get preserve=no
        return m_strNORMAL_OPEN_HOUR;
        //## end canistercommand::ATM::getNORMAL_OPEN_HOUR%5D3822780111.get
      }

      void setNORMAL_OPEN_HOUR (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setNORMAL_OPEN_HOUR%5D3822780111.set preserve=no
        m_strNORMAL_OPEN_HOUR = value;
        //## end canistercommand::ATM::setNORMAL_OPEN_HOUR%5D3822780111.set
      }


      //## Attribute: REGION%5D3822780379
      const reusable::string& getREGION () const
      {
        //## begin canistercommand::ATM::getREGION%5D3822780379.get preserve=no
        return m_strREGION;
        //## end canistercommand::ATM::getREGION%5D3822780379.get
      }

      void setREGION (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setREGION%5D3822780379.set preserve=no
        m_strREGION = value;
        //## end canistercommand::ATM::setREGION%5D3822780379.set
      }


      //## Attribute: REPORTING_REGION%5DB6E6CF038B
      const reusable::string& getREPORTING_REGION () const
      {
        //## begin canistercommand::ATM::getREPORTING_REGION%5DB6E6CF038B.get preserve=no
        return m_strREPORTING_REGION;
        //## end canistercommand::ATM::getREPORTING_REGION%5DB6E6CF038B.get
      }

      void setREPORTING_REGION (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setREPORTING_REGION%5DB6E6CF038B.set preserve=no
        m_strREPORTING_REGION = value;
        //## end canistercommand::ATM::setREPORTING_REGION%5DB6E6CF038B.set
      }


      //## Attribute: STATE_REASON%5D38227901C4
      const reusable::string& getSTATE_REASON () const
      {
        //## begin canistercommand::ATM::getSTATE_REASON%5D38227901C4.get preserve=no
        return m_strSTATE_REASON;
        //## end canistercommand::ATM::getSTATE_REASON%5D38227901C4.get
      }

      void setSTATE_REASON (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setSTATE_REASON%5D38227901C4.set preserve=no
        m_strSTATE_REASON = value;
        //## end canistercommand::ATM::setSTATE_REASON%5D38227901C4.set
      }


      //## Attribute: SUBJECT_STATE%5D38227A0048
      const reusable::string& getSUBJECT_STATE () const
      {
        //## begin canistercommand::ATM::getSUBJECT_STATE%5D38227A0048.get preserve=no
        return m_strSUBJECT_STATE;
        //## end canistercommand::ATM::getSUBJECT_STATE%5D38227A0048.get
      }

      void setSUBJECT_STATE (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setSUBJECT_STATE%5D38227A0048.set preserve=no
        m_strSUBJECT_STATE = value;
        //## end canistercommand::ATM::setSUBJECT_STATE%5D38227A0048.set
      }


      //## Attribute: TRAN_DISPOSITION%5D5711AC00E9
      const reusable::string& getTRAN_DISPOSITION () const
      {
        //## begin canistercommand::ATM::getTRAN_DISPOSITION%5D5711AC00E9.get preserve=no
        return m_strTRAN_DISPOSITION;
        //## end canistercommand::ATM::getTRAN_DISPOSITION%5D5711AC00E9.get
      }

      void setTRAN_DISPOSITION (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setTRAN_DISPOSITION%5D5711AC00E9.set preserve=no
        m_strTRAN_DISPOSITION = value;
        //## end canistercommand::ATM::setTRAN_DISPOSITION%5D5711AC00E9.set
      }


      //## Attribute: VAULT%5D38236A00BE
      const reusable::string& getVAULT () const
      {
        //## begin canistercommand::ATM::getVAULT%5D38236A00BE.get preserve=no
        return m_strVAULT;
        //## end canistercommand::ATM::getVAULT%5D38236A00BE.get
      }

      void setVAULT (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setVAULT%5D38236A00BE.set preserve=no
        m_strVAULT = value;
        //## end canistercommand::ATM::setVAULT%5D38236A00BE.set
      }


      //## Attribute: VENDOR_MODEL%5D38236A0359
      const reusable::string& getVENDOR_MODEL () const
      {
        //## begin canistercommand::ATM::getVENDOR_MODEL%5D38236A0359.get preserve=no
        return m_strVENDOR_MODEL;
        //## end canistercommand::ATM::getVENDOR_MODEL%5D38236A0359.get
      }

      void setVENDOR_MODEL (const reusable::string& value)
      {
        //## begin canistercommand::ATM::setVENDOR_MODEL%5D38236A0359.set preserve=no
        m_strVENDOR_MODEL = value;
        //## end canistercommand::ATM::setVENDOR_MODEL%5D38236A0359.set
      }


    // Additional Public Declarations
      //## begin canistercommand::ATM%5BB79D6D01DC.public preserve=yes
      //## end canistercommand::ATM%5BB79D6D01DC.public

  protected:
    // Additional Protected Declarations
      //## begin canistercommand::ATM%5BB79D6D01DC.protected preserve=yes
      //## end canistercommand::ATM%5BB79D6D01DC.protected

  private:
    // Additional Private Declarations
      //## begin canistercommand::ATM%5BB79D6D01DC.private preserve=yes
      //## end canistercommand::ATM%5BB79D6D01DC.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin canistercommand::ATM::ACTIVITY_TYPE%5D381CD50342.attr preserve=no  public: int {V} 0
      int m_iACTIVITY_TYPE;
      //## end canistercommand::ATM::ACTIVITY_TYPE%5D381CD50342.attr

      //## begin canistercommand::ATM::ADDRESS%5D3821040245.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strADDRESS;
      //## end canistercommand::ATM::ADDRESS%5D3821040245.attr

      //## Attribute: AMT_RECON_NET%5D3821850120
      //## begin canistercommand::ATM::AMT_RECON_NET%5D3821850120.attr preserve=no  public: double[4] {V} 
      double m_dAMT_RECON_NET[4];
      //## end canistercommand::ATM::AMT_RECON_NET%5D3821850120.attr

      //## Attribute: AMT_SURCHARGE%5D3821920097
      //## begin canistercommand::ATM::AMT_SURCHARGE%5D3821920097.attr preserve=no  public: double[4] {V} 
      double m_dAMT_SURCHARGE[4];
      //## end canistercommand::ATM::AMT_SURCHARGE%5D3821920097.attr

      //## begin canistercommand::ATM::CASH_END%5D3821930082.attr preserve=no  public: double {U} 0
      double m_dCASH_END;
      //## end canistercommand::ATM::CASH_END%5D3821930082.attr

      //## begin canistercommand::ATM::CASSETTEn_END%5D56C3F001E1.attr preserve=no  public: double[9] {U} 
      double m_dCASSETTEn_END[9];
      //## end canistercommand::ATM::CASSETTEn_END%5D56C3F001E1.attr

      //## begin canistercommand::ATM::CASSETTES_END%5D3821930261.attr preserve=no  public: double {U} 0
      double m_dCASSETTES_END;
      //## end canistercommand::ATM::CASSETTES_END%5D3821930261.attr

      //## begin canistercommand::ATM::CHECK_END%5D3821940063.attr preserve=no  public: double {U} 0
      double m_dCHECK_END;
      //## end canistercommand::ATM::CHECK_END%5D3821940063.attr

      //## begin canistercommand::ATM::CITY%5D382274013A.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strCITY;
      //## end canistercommand::ATM::CITY%5D382274013A.attr

      //## Attribute: CUR_CODE%5DBC3F590227
      //## begin canistercommand::ATM::CUR_CODE%5DBC3F590227.attr preserve=no  public: reusable::string[9] {V} 
      reusable::string m_strCUR_CODE[9];
      //## end canistercommand::ATM::CUR_CODE%5DBC3F590227.attr

      //## Attribute: CUR_RECON_NET%5D434CFB0301
      //## begin canistercommand::ATM::CUR_RECON_NET%5D434CFB0301.attr preserve=no  public: reusable::string[4] {V} 
      reusable::string m_strCUR_RECON_NET[4];
      //## end canistercommand::ATM::CUR_RECON_NET%5D434CFB0301.attr

      //## Attribute: CUR_TYPE%5D5701E503DB
      //## begin canistercommand::ATM::CUR_TYPE%5D5701E503DB.attr preserve=no  public: short int[9] {V} 
      short int m_siCUR_TYPE[9];
      //## end canistercommand::ATM::CUR_TYPE%5D5701E503DB.attr

      //## begin canistercommand::ATM::CUSTOM_DATA%5D38227500A3.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strCUSTOM_DATA;
      //## end canistercommand::ATM::CUSTOM_DATA%5D38227500A3.attr

      //## begin canistercommand::ATM::DEFAULT_CUR_CODE%5D7663F60001.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strDEFAULT_CUR_CODE;
      //## end canistercommand::ATM::DEFAULT_CUR_CODE%5D7663F60001.attr

      //## begin canistercommand::ATM::DEVICE_ID%5D38227502E8.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strDEVICE_ID;
      //## end canistercommand::ATM::DEVICE_ID%5D38227502E8.attr

      //## Attribute: ITEM_COUNT%5D56F11B03D2
      //## begin canistercommand::ATM::ITEM_COUNT%5D56F11B03D2.attr preserve=no  public: int[9] {V} 
      int m_iITEM_COUNT[9];
      //## end canistercommand::ATM::ITEM_COUNT%5D56F11B03D2.attr

      //## Attribute: ITEM_VALUE%5D56F13300F6
      //## begin canistercommand::ATM::ITEM_VALUE%5D56F13300F6.attr preserve=no  public: int[9] {V} 
      int m_iITEM_VALUE[9];
      //## end canistercommand::ATM::ITEM_VALUE%5D56F13300F6.attr

      //## begin canistercommand::ATM::LOAD%5D38227600E6.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strLOAD;
      //## end canistercommand::ATM::LOAD%5D38227600E6.attr

      //## begin canistercommand::ATM::LOW_CASH_FLG%5D38227602BF.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strLOW_CASH_FLG;
      //## end canistercommand::ATM::LOW_CASH_FLG%5D38227602BF.attr

      //## begin canistercommand::ATM::NEXT_ID%5DB6E71000B5.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strNEXT_ID;
      //## end canistercommand::ATM::NEXT_ID%5DB6E71000B5.attr

      //## begin canistercommand::ATM::NORMAL_CLOSE_HOUR%5D38227702E3.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strNORMAL_CLOSE_HOUR;
      //## end canistercommand::ATM::NORMAL_CLOSE_HOUR%5D38227702E3.attr

      //## begin canistercommand::ATM::NORMAL_OPEN_HOUR%5D3822780111.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strNORMAL_OPEN_HOUR;
      //## end canistercommand::ATM::NORMAL_OPEN_HOUR%5D3822780111.attr

      //## begin canistercommand::ATM::REGION%5D3822780379.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strREGION;
      //## end canistercommand::ATM::REGION%5D3822780379.attr

      //## begin canistercommand::ATM::REPORTING_REGION%5DB6E6CF038B.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strREPORTING_REGION;
      //## end canistercommand::ATM::REPORTING_REGION%5DB6E6CF038B.attr

      //## begin canistercommand::ATM::STATE_REASON%5D38227901C4.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strSTATE_REASON;
      //## end canistercommand::ATM::STATE_REASON%5D38227901C4.attr

      //## begin canistercommand::ATM::SUBJECT_STATE%5D38227A0048.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strSUBJECT_STATE;
      //## end canistercommand::ATM::SUBJECT_STATE%5D38227A0048.attr

      //## Attribute: TRAN_COUNT%5D3823370005
      //## begin canistercommand::ATM::TRAN_COUNT%5D3823370005.attr preserve=no  public: int[4] {V} 
      int m_iTRAN_COUNT[4];
      //## end canistercommand::ATM::TRAN_COUNT%5D3823370005.attr

      //## begin canistercommand::ATM::TRAN_DISPOSITION%5D5711AC00E9.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strTRAN_DISPOSITION;
      //## end canistercommand::ATM::TRAN_DISPOSITION%5D5711AC00E9.attr

      //## begin canistercommand::ATM::VAULT%5D38236A00BE.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strVAULT;
      //## end canistercommand::ATM::VAULT%5D38236A00BE.attr

      //## begin canistercommand::ATM::VENDOR_MODEL%5D38236A0359.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strVENDOR_MODEL;
      //## end canistercommand::ATM::VENDOR_MODEL%5D38236A0359.attr

    // Additional Implementation Declarations
      //## begin canistercommand::ATM%5BB79D6D01DC.implementation preserve=yes
      //## end canistercommand::ATM%5BB79D6D01DC.implementation

};

//## begin canistercommand::ATM%5BB79D6D01DC.postscript preserve=yes
//## end canistercommand::ATM%5BB79D6D01DC.postscript

} // namespace canistercommand

//## begin module%5BB79E1A03C2.epilog preserve=yes
//## end module%5BB79E1A03C2.epilog


#endif
