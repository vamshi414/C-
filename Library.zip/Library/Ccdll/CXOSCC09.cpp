//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5DAE5F36018B.cm preserve=no
//	$Date:   Jun 16 2020 21:49:04  $ $Author:   e1009591  $
//	$Revision:   1.6  $
//## end module%5DAE5F36018B.cm

//## begin module%5DAE5F36018B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5DAE5F36018B.cp

//## Module: CXOSCC09%5DAE5F36018B; Package body
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXOSCC09.cpp

//## begin module%5DAE5F36018B.additionalIncludes preserve=no
//## end module%5DAE5F36018B.additionalIncludes

//## begin module%5DAE5F36018B.includes preserve=yes
#include "CXODBS09.hpp"
#include "CXODTM06.hpp"
#include "CXODNS29.hpp"
#include "CXODTM03.hpp"
//## end module%5DAE5F36018B.includes

#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSCC04_h
#include "CXODCC04.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSCC09_h
#include "CXODCC09.hpp"
#endif


//## begin module%5DAE5F36018B.declarations preserve=no
//## end module%5DAE5F36018B.declarations

//## begin module%5DAE5F36018B.additionalDeclarations preserve=yes
//## end module%5DAE5F36018B.additionalDeclarations


//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

// Class canistercommand::CurrentATMPosition

CurrentATMPosition::CurrentATMPosition()
  //## begin CurrentATMPosition::CurrentATMPosition%5DAE5E95026E_const.hasinit preserve=no
  //## end CurrentATMPosition::CurrentATMPosition%5DAE5E95026E_const.hasinit
  //## begin CurrentATMPosition::CurrentATMPosition%5DAE5E95026E_const.initialization preserve=yes
  //## end CurrentATMPosition::CurrentATMPosition%5DAE5E95026E_const.initialization
{
  //## begin canistercommand::CurrentATMPosition::CurrentATMPosition%5DAE5E95026E_const.body preserve=yes
   memcpy(m_sID,"CC09",4);
  //## end canistercommand::CurrentATMPosition::CurrentATMPosition%5DAE5E95026E_const.body
}


CurrentATMPosition::~CurrentATMPosition()
{
  //## begin canistercommand::CurrentATMPosition::~CurrentATMPosition%5DAE5E95026E_dest.body preserve=yes
  //## end canistercommand::CurrentATMPosition::~CurrentATMPosition%5DAE5E95026E_dest.body
}



//## Other Operations (implementation)
int CurrentATMPosition::execute ()
{
  //## begin canistercommand::CurrentATMPosition::execute%5DAE61C50063.body preserve=yes
   int lInfoIDNumber = DeviceViewConstraint::instance()->addConstraints(m_hQuery,true);
   if (lInfoIDNumber != 0)
      return lInfoIDNumber;
   m_hCanisterTotal.bind(m_hQuery,true);
   m_hQuery.attach(this);
   m_strENTITY_ID.erase();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*) DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(m_hQuery) == false
      || pSelectStatement->getRows() == 0
      || m_strENTITY_ID.empty())
      return STS_RECORD_NOT_FOUND;
   exportTotals();
   return 0;
  //## end canistercommand::CurrentATMPosition::execute%5DAE61C50063.body
}

void CurrentATMPosition::exportTotals ()
{
  //## begin canistercommand::CurrentATMPosition::exportTotals%5DAF626E02FA.body preserve=yes
   entitysegment::SwitchBusinessDay::instance()->update(MidnightAlarm::instance());
   Query hQuery;
   hQuery.attach(this);
   m_hATMEvent.bind(hQuery);
   hQuery.setBasicPredicate("T_ATM_EVENT","NET_TERM_ID","=",m_strENTITY_ID.c_str());
   hQuery.setBasicPredicate("T_ATM_EVENT","DATE_RECON_ACQ","=",entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(1).c_str());
   hQuery.setBasicPredicate("T_ATM_EVENT","FUNCTION_CODE","=","998");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == false
      || pSelectStatement->getRows() == 0)
      return;
   hQuery.detach(this);
   string strTable("FIN_Lyyyymm");
   string strDate(entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(1).data(),6);
   for (int i = 0;i < 3;++i)
   {
      strTable.replace(5,6,strDate.data(),6);
      hQuery.reset();
      hQuery.bind(strTable.c_str(),"TSTAMP_TRANS",Column::STRING,&m_strTSTAMP_TRANS_TO,0,"MAX");
      hQuery.setBasicPredicate(strTable.c_str(),"NET_TERM_ID","=",m_strENTITY_ID.c_str());
      if (pSelectStatement->execute(hQuery) == false
         || m_strTSTAMP_TRANS_TO.empty() == false)
         break;
      strDate.replace(6,2,"01",2);
      Date hDate(strDate.c_str());
      hDate -= 1;
      strDate = hDate.asString("%Y%m%d");
   }
   CurrentDevicePosition::exportTotals();
  //## end canistercommand::CurrentATMPosition::exportTotals%5DAF626E02FA.body
}

void CurrentATMPosition::update (Subject* pSubject)
{
  //## begin canistercommand::CurrentATMPosition::update%5DAF07320222.body preserve=yes
   if (pSubject != &m_hQuery)
   {
      m_hCanisterBalance[0].setBEGINNING_AMT(m_hATMEvent.getCASSETTES_END());
      m_hCanisterBalance[0].setCUR_TYPE(1);
      m_hCanisterBalance[0].setCURRENCY_CODE(entitysegment::Customer::instance()->getCUST_CURRENCY_CODE());
      for (int i = 1;i <= 8;++i)
      {
         m_hCanisterBalance[i].setBEGINNING_AMT(m_hATMEvent.getCASSETTEn_END(i - 1));
         if (m_hATMEvent.getCASSETTEn_VALUE(i - 1) > 0)
            m_hCanisterBalance[i].setBEGINNING_COUNT(m_hATMEvent.getCASSETTEn_END(i - 1) / m_hATMEvent.getCASSETTEn_VALUE(i - 1));
         m_hCanisterBalance[i].setITEM_VALUE(m_hATMEvent.getCASSETTEn_VALUE(i - 1));
         m_hCanisterBalance[i].setCURRENCY_CODE(m_hATMEvent.getCASSETTEn_CUR_CODE(i - 1));
         m_hCanisterBalance[i].setCUR_TYPE(m_hATMEvent.getCASSETTEn_CUR_TYPE(i - 1));
         if (m_hATMEvent.getCASSETTEn_CUR_TYPE(i - 1) != 0)
         {
            m_hCanisterBalance[0].setCURRENCY_CODE(m_hATMEvent.getCASSETTEn_CUR_CODE(i - 1));
            m_hCanisterBalance[0].setCUR_TYPE(m_hATMEvent.getCASSETTEn_CUR_TYPE(i - 1));
         }
         if (m_hATMEvent.getCASSETTEn_END(i - 1) > 0)
            m_hCanisterBalance[i].setTSTAMP_REPLACE(m_hATMEvent.getTSTAMP_TRANS());
         if (m_hATMEvent.getCASSETTEn_END(i - 1) < 0)
            m_hCanisterBalance[0].setTSTAMP_REPLACE(m_hATMEvent.getTSTAMP_TRANS());
      }
      return;
   }
   if (m_strENTITY_ID.length() == 0
      || m_strENTITY_ID != m_hCanisterTotal.getENTITY_ID())
   {
      if (m_strENTITY_ID.length() > 0)
         exportTotals();
      m_strENTITY_ID = m_hCanisterTotal.getENTITY_ID();
      m_strPROC_ID = m_hCanisterTotal.getPROC_ID();
      m_strPROC_NAME = m_hCanisterTotal.getPROC_NAME();
      m_strINST_ID = m_hCanisterTotal.getINST_ID();
      m_strINST_NAME = m_hCanisterTotal.getINST_NAME();
      m_strDEVICE_ADDRESS = m_hCanisterTotal.getDEVICE_ADDRESS();
      m_strDEVICE_CITY = m_hCanisterTotal.getDEVICE_CITY();
      m_strDEVICE_COUNTRY = m_hCanisterTotal.getDEVICE_COUNTRY();
      m_strDEVICE_REGION = m_hCanisterTotal.getDEVICE_REGION();
      m_strDEVICE_POSTAL_CODE = m_hCanisterTotal.getDEVICE_POSTAL_CODE();
      m_strTSTAMP_TRANS_TO = m_hCanisterTotal.getTSTAMP_TRANS_TO()[0];
      m_strSUBJECT_STATE = m_hCanisterTotal.getSUBJECT_STATE();
      m_strLOW_CASH_FLG = m_hCanisterTotal.getLOW_CASH_FLG();
      m_strCOURIER_OFFICE_ID.erase();
      m_strCOURIER_DESC.erase();
      m_strCOURIER_PTR.erase();
      char szTemp[11];
      if (m_hCanisterTotal.getCOURIER_OFFICE_ID_NULL() == 0)
      {
         m_strCOURIER_OFFICE_ID = m_hCanisterTotal.getCOURIER_OFFICE_ID();
         m_strCOURIER_DESC = m_hCanisterTotal.getCOURIER_DESC();
         snprintf(szTemp,sizeof(szTemp),"%010d",m_hCanisterTotal.getCOURIER_PTR());
         m_strCOURIER_PTR = szTemp;
      }
      m_strCOURIER_ROUTE_ID.erase();
      m_strCOURIER_ROUTE_DESC.erase();
      m_strCOURIER_ROUTE_PTR.erase();
      if (m_hCanisterTotal.getCOURIER_ROUTE_ID_NULL() == 0)
      {
         m_strCOURIER_ROUTE_ID = m_hCanisterTotal.getCOURIER_ROUTE_ID();
         m_strCOURIER_ROUTE_DESC = m_hCanisterTotal.getCOURIER_ROUTE_DESC();
         snprintf(szTemp,sizeof(szTemp),"%010d",m_hCanisterTotal.getCOURIER_ROUTE_PTR());
         m_strCOURIER_ROUTE_PTR = szTemp;
      }
   }
  //## end canistercommand::CurrentATMPosition::update%5DAF07320222.body
}

// Additional Declarations
  //## begin canistercommand::CurrentATMPosition%5DAE5E95026E.declarations preserve=yes
  //## end canistercommand::CurrentATMPosition%5DAE5E95026E.declarations

} // namespace canistercommand

//## begin module%5DAE5F36018B.epilog preserve=yes
//## end module%5DAE5F36018B.epilog
