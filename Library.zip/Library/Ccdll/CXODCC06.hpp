//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39AD8077013E.cm preserve=no
//	$Date:   Oct 24 2019 10:29:40  $ $Author:   e1009839  $
//	$Revision:   1.10  $
//## end module%39AD8077013E.cm

//## begin module%39AD8077013E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39AD8077013E.cp

//## Module: CXOSCC06%39AD8077013E; Package specification
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Ccdll\CXODCC06.hpp

#ifndef CXOSCC06_h
#define CXOSCC06_h 1

//## begin module%39AD8077013E.additionalIncludes preserve=no
//## end module%39AD8077013E.additionalIncludes

//## begin module%39AD8077013E.includes preserve=yes
//## end module%39AD8077013E.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
class CanisterTotal;

} // namespace canistercommand

//## begin module%39AD8077013E.declarations preserve=no
//## end module%39AD8077013E.declarations

//## begin module%39AD8077013E.additionalDeclarations preserve=yes
//## end module%39AD8077013E.additionalDeclarations


namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

//## begin canistercommand::CanisterBalance%39AD7E5D02DA.preface preserve=yes
//## end canistercommand::CanisterBalance%39AD7E5D02DA.preface

//## Class: CanisterBalance%39AD7E5D02DA
//## Category: Device Management::CanisterCommand_CAT%39A2966401E2
//## Subsystem: CCDLL%39A29BAF006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39AD7E8902C0;CanisterTotal { -> F}

class DllExport CanisterBalance : public reusable::Object  //## Inherits: <unnamed>%39AD7EAD0253
{
  //## begin canistercommand::CanisterBalance%39AD7E5D02DA.initialDeclarations preserve=yes
  //## end canistercommand::CanisterBalance%39AD7E5D02DA.initialDeclarations

  public:
    //## Constructors (generated)
      CanisterBalance();

      CanisterBalance(const CanisterBalance &right);

    //## Destructor (generated)
      virtual ~CanisterBalance();


    //## Other Operations (specified)
      //## Operation: add%39AD7ED10219
      void add (CanisterTotal hCanisterTotal);

      //## Operation: reset%39AD80C801E5
      void reset ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: BEGINNING_AMT%39AD7F7A00D1
      const double getBEGINNING_AMT () const
      {
        //## begin canistercommand::CanisterBalance::getBEGINNING_AMT%39AD7F7A00D1.get preserve=no
        return m_dBEGINNING_AMT;
        //## end canistercommand::CanisterBalance::getBEGINNING_AMT%39AD7F7A00D1.get
      }

      void setBEGINNING_AMT (double value)
      {
        //## begin canistercommand::CanisterBalance::setBEGINNING_AMT%39AD7F7A00D1.set preserve=no
        m_dBEGINNING_AMT = value;
        //## end canistercommand::CanisterBalance::setBEGINNING_AMT%39AD7F7A00D1.set
      }


      //## Attribute: BEGINNING_COUNT%39AD7F95033D
      const int getBEGINNING_COUNT () const
      {
        //## begin canistercommand::CanisterBalance::getBEGINNING_COUNT%39AD7F95033D.get preserve=no
        return m_iBEGINNING_COUNT;
        //## end canistercommand::CanisterBalance::getBEGINNING_COUNT%39AD7F95033D.get
      }

      void setBEGINNING_COUNT (int value)
      {
        //## begin canistercommand::CanisterBalance::setBEGINNING_COUNT%39AD7F95033D.set preserve=no
        m_iBEGINNING_COUNT = value;
        //## end canistercommand::CanisterBalance::setBEGINNING_COUNT%39AD7F95033D.set
      }


      //## Attribute: CUR_TYPE%39AD7F350349
      const short int getCUR_TYPE () const
      {
        //## begin canistercommand::CanisterBalance::getCUR_TYPE%39AD7F350349.get preserve=no
        return m_siCUR_TYPE;
        //## end canistercommand::CanisterBalance::getCUR_TYPE%39AD7F350349.get
      }

      void setCUR_TYPE (short int value)
      {
        //## begin canistercommand::CanisterBalance::setCUR_TYPE%39AD7F350349.set preserve=no
        m_siCUR_TYPE = value;
        //## end canistercommand::CanisterBalance::setCUR_TYPE%39AD7F350349.set
      }


      //## Attribute: CURRENCY_CODE%39AD7F520016
      const reusable::string& getCURRENCY_CODE () const
      {
        //## begin canistercommand::CanisterBalance::getCURRENCY_CODE%39AD7F520016.get preserve=no
        return m_strCURRENCY_CODE;
        //## end canistercommand::CanisterBalance::getCURRENCY_CODE%39AD7F520016.get
      }

      void setCURRENCY_CODE (const reusable::string& value)
      {
        //## begin canistercommand::CanisterBalance::setCURRENCY_CODE%39AD7F520016.set preserve=no
        m_strCURRENCY_CODE = value;
        //## end canistercommand::CanisterBalance::setCURRENCY_CODE%39AD7F520016.set
      }


      //## Attribute: DISPNSD_ITEM_COUNT%39AD7FCD03AC
      const int getDISPNSD_ITEM_COUNT () const
      {
        //## begin canistercommand::CanisterBalance::getDISPNSD_ITEM_COUNT%39AD7FCD03AC.get preserve=no
        return m_iDISPNSD_ITEM_COUNT;
        //## end canistercommand::CanisterBalance::getDISPNSD_ITEM_COUNT%39AD7FCD03AC.get
      }

      void setDISPNSD_ITEM_COUNT (int value)
      {
        //## begin canistercommand::CanisterBalance::setDISPNSD_ITEM_COUNT%39AD7FCD03AC.set preserve=no
        m_iDISPNSD_ITEM_COUNT = value;
        //## end canistercommand::CanisterBalance::setDISPNSD_ITEM_COUNT%39AD7FCD03AC.set
      }


      //## Attribute: ITEM_VALUE%39AD7EFD02C6
      const int getITEM_VALUE () const
      {
        //## begin canistercommand::CanisterBalance::getITEM_VALUE%39AD7EFD02C6.get preserve=no
        return m_iITEM_VALUE;
        //## end canistercommand::CanisterBalance::getITEM_VALUE%39AD7EFD02C6.get
      }

      void setITEM_VALUE (int value)
      {
        //## begin canistercommand::CanisterBalance::setITEM_VALUE%39AD7EFD02C6.set preserve=no
        m_iITEM_VALUE = value;
        //## end canistercommand::CanisterBalance::setITEM_VALUE%39AD7EFD02C6.set
      }


      //## Attribute: TSTAMP_REPLACE%4176A8330186
      const reusable::string& getTSTAMP_REPLACE () const
      {
        //## begin canistercommand::CanisterBalance::getTSTAMP_REPLACE%4176A8330186.get preserve=no
        return m_strTSTAMP_REPLACE;
        //## end canistercommand::CanisterBalance::getTSTAMP_REPLACE%4176A8330186.get
      }

      void setTSTAMP_REPLACE (const reusable::string& value)
      {
        //## begin canistercommand::CanisterBalance::setTSTAMP_REPLACE%4176A8330186.set preserve=no
        m_strTSTAMP_REPLACE = value;
        //## end canistercommand::CanisterBalance::setTSTAMP_REPLACE%4176A8330186.set
      }


    // Additional Public Declarations
      //## begin canistercommand::CanisterBalance%39AD7E5D02DA.public preserve=yes
      //## end canistercommand::CanisterBalance%39AD7E5D02DA.public

  protected:
    // Additional Protected Declarations
      //## begin canistercommand::CanisterBalance%39AD7E5D02DA.protected preserve=yes
      //## end canistercommand::CanisterBalance%39AD7E5D02DA.protected

  private:
    // Additional Private Declarations
      //## begin canistercommand::CanisterBalance%39AD7E5D02DA.private preserve=yes
      //## end canistercommand::CanisterBalance%39AD7E5D02DA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin canistercommand::CanisterBalance::BEGINNING_AMT%39AD7F7A00D1.attr preserve=no  public: double {V} 0
      double m_dBEGINNING_AMT;
      //## end canistercommand::CanisterBalance::BEGINNING_AMT%39AD7F7A00D1.attr

      //## begin canistercommand::CanisterBalance::BEGINNING_COUNT%39AD7F95033D.attr preserve=no  public: int {V} 0
      int m_iBEGINNING_COUNT;
      //## end canistercommand::CanisterBalance::BEGINNING_COUNT%39AD7F95033D.attr

      //## begin canistercommand::CanisterBalance::CUR_TYPE%39AD7F350349.attr preserve=no  public: short int {V} 0
      short int m_siCUR_TYPE;
      //## end canistercommand::CanisterBalance::CUR_TYPE%39AD7F350349.attr

      //## begin canistercommand::CanisterBalance::CURRENCY_CODE%39AD7F520016.attr preserve=no  public: reusable::string {V}  
      reusable::string m_strCURRENCY_CODE;
      //## end canistercommand::CanisterBalance::CURRENCY_CODE%39AD7F520016.attr

      //## begin canistercommand::CanisterBalance::DISPNSD_ITEM_COUNT%39AD7FCD03AC.attr preserve=no  public: int {V} 0
      int m_iDISPNSD_ITEM_COUNT;
      //## end canistercommand::CanisterBalance::DISPNSD_ITEM_COUNT%39AD7FCD03AC.attr

      //## begin canistercommand::CanisterBalance::ITEM_VALUE%39AD7EFD02C6.attr preserve=no  public: int {V} 0
      int m_iITEM_VALUE;
      //## end canistercommand::CanisterBalance::ITEM_VALUE%39AD7EFD02C6.attr

      //## begin canistercommand::CanisterBalance::TSTAMP_REPLACE%4176A8330186.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strTSTAMP_REPLACE;
      //## end canistercommand::CanisterBalance::TSTAMP_REPLACE%4176A8330186.attr

    // Additional Implementation Declarations
      //## begin canistercommand::CanisterBalance%39AD7E5D02DA.implementation preserve=yes
      //## end canistercommand::CanisterBalance%39AD7E5D02DA.implementation

};

//## begin canistercommand::CanisterBalance%39AD7E5D02DA.postscript preserve=yes
//## end canistercommand::CanisterBalance%39AD7E5D02DA.postscript

} // namespace canistercommand

//## begin module%39AD8077013E.epilog preserve=yes
using namespace canistercommand;
//## end module%39AD8077013E.epilog


#endif
