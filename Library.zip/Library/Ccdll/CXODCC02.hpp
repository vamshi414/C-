//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%39A2A06302C8.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%39A2A06302C8.cm

//## begin module%39A2A06302C8.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%39A2A06302C8.cp

//## Module: CXOSCC02%39A2A06302C8; Package specification
//## Subsystem: CCDLL%39A29BAF006B
//## Source file: C:\Devel\Dn\Server\Library\CCDLL\CXODCC02.hpp

#ifndef CXOSCC02_h
#define CXOSCC02_h 1

//## begin module%39A2A06302C8.additionalIncludes preserve=no
//## end module%39A2A06302C8.additionalIncludes

//## begin module%39A2A06302C8.includes preserve=yes
// $Date:   Jun 30 2006 12:15:38  $ $Author:   D02405  $ $Revision:   1.8  $
//## end module%39A2A06302C8.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU20_h
#include "CXODRU20.hpp"
#endif
#ifndef CXOSVC19_h
#include "CXODVC19.hpp"
#endif

//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
class DeviceViewConstraint;
} // namespace canistercommand

//## Modelname: Connex Foundation::ViewSegment_CAT%394E276801C1
namespace viewsegment {
class ReportColumnSegment;

} // namespace viewsegment

//## begin module%39A2A06302C8.declarations preserve=no
//## end module%39A2A06302C8.declarations

//## begin module%39A2A06302C8.additionalDeclarations preserve=yes
//## end module%39A2A06302C8.additionalDeclarations


namespace canistercommand {
//## begin canistercommand%39A2966401E2.initialDeclarations preserve=yes
//## end canistercommand%39A2966401E2.initialDeclarations

//## begin canistercommand::ViewCanister%39A29E0A0285.preface preserve=yes
//## end canistercommand::ViewCanister%39A29E0A0285.preface

//## Class: ViewCanister%39A29E0A0285
//## Category: Device Management::CanisterCommand_CAT%39A2966401E2
//## Subsystem: CCDLL%39A29BAF006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%39A29F060088;viewsegment::ReportColumnSegment { -> F}
//## Uses: <unnamed>%39ABB9E102C7;DeviceViewConstraint { -> F}

class DllExport ViewCanister : public viewcommand::View  //## Inherits: <unnamed>%3D342B0F0271
{
  //## begin canistercommand::ViewCanister%39A29E0A0285.initialDeclarations preserve=yes
  //## end canistercommand::ViewCanister%39A29E0A0285.initialDeclarations

  public:
    //## Constructors (generated)
      ViewCanister();

    //## Destructor (generated)
      virtual ~ViewCanister();


    //## Other Operations (specified)
      //## Operation: execute%39A29F4800F4
      virtual int execute () = 0;

      //## Operation: getRow%39A29F480181
      Row* getRow ()
      {
        //## begin canistercommand::ViewCanister::getRow%39A29F480181.body preserve=yes
         return &m_hRow;
        //## end canistercommand::ViewCanister::getRow%39A29F480181.body
      }

    // Additional Public Declarations
      //## begin canistercommand::ViewCanister%39A29E0A0285.public preserve=yes
      //## end canistercommand::ViewCanister%39A29E0A0285.public

  protected:
    // Data Members for Associations

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%39A29EBC01CC
      //## Role: ViewCanister::<m_hQuery>%39A29EBD0250
      //## begin canistercommand::ViewCanister::<m_hQuery>%39A29EBD0250.role preserve=no  protected: reusable::Query { -> VHgAN}
      reusable::Query m_hQuery;
      //## end canistercommand::ViewCanister::<m_hQuery>%39A29EBD0250.role

      //## Association: Device Management::CanisterCommand_CAT::<unnamed>%39A29EDD0346
      //## Role: ViewCanister::<m_hRow>%39A29EDF006E
      //## begin canistercommand::ViewCanister::<m_hRow>%39A29EDF006E.role preserve=no  protected: reusable::Row { -> VHgAN}
      reusable::Row m_hRow;
      //## end canistercommand::ViewCanister::<m_hRow>%39A29EDF006E.role

    // Additional Protected Declarations
      //## begin canistercommand::ViewCanister%39A29E0A0285.protected preserve=yes
      //## end canistercommand::ViewCanister%39A29E0A0285.protected

  private:
    // Additional Private Declarations
      //## begin canistercommand::ViewCanister%39A29E0A0285.private preserve=yes
      //## end canistercommand::ViewCanister%39A29E0A0285.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin canistercommand::ViewCanister%39A29E0A0285.implementation preserve=yes
      //## end canistercommand::ViewCanister%39A29E0A0285.implementation

};

//## begin canistercommand::ViewCanister%39A29E0A0285.postscript preserve=yes
//## end canistercommand::ViewCanister%39A29E0A0285.postscript

} // namespace canistercommand

//## begin module%39A2A06302C8.epilog preserve=yes
using namespace canistercommand;
//## end module%39A2A06302C8.epilog


#endif
