
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[13];
};
static const struct sqlcxp sqlfpn =
{
    12,
    "CXOSDO13.sqx"
};


static unsigned int sqlctx = 306118;


static struct sqlexd {
   unsigned int   sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
            void  **sqphsv;
   unsigned int   *sqphsl;
            int   *sqphss;
            void  **sqpind;
            int   *sqpins;
   unsigned int   *sqparm;
   unsigned int   **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
              int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned int   sqlpfmem;
            void  *sqhstv[17];
   unsigned int   sqhstl[17];
            int   sqhsts[17];
            void  *sqindv[17];
            int   sqinds[17];
   unsigned int   sqharm[17];
   unsigned int   *sqharc[17];
   unsigned short  sqadto[17];
   unsigned short  sqtdso[17];
} sqlstm = {13,17};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(unsigned char *, signed int *); }

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{13,4130,178,8,0,
5,0,0,1,335,0,3,171,0,0,17,17,0,1,0,1,97,0,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,
1,3,0,0,1,3,0,0,1,4,0,0,1,4,0,0,1,4,0,0,1,4,0,0,1,3,0,0,1,4,0,0,1,4,0,0,1,4,0,
0,1,3,0,0,1,97,0,0,
88,0,0,2,504,0,5,266,0,0,15,15,0,1,0,1,4,0,0,1,4,0,0,1,4,0,0,1,4,0,0,1,3,0,0,1,
4,0,0,1,4,0,0,1,4,0,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,
0,0,
163,0,0,3,500,0,5,288,0,0,16,16,0,1,0,1,4,0,0,1,4,0,0,1,4,0,0,1,4,0,0,1,3,0,0,
1,4,0,0,1,4,0,0,1,4,0,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,
0,0,1,97,0,0,
};


//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%44492F1700FA.cm preserve=no
//## end module%44492F1700FA.cm

//## begin module%44492F1700FA.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%44492F1700FA.cp

//## Module: CXOSDO13%44492F1700FA; Package body
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Library\Dodll\CXOSDO13.sqx

//## begin module%44492F1700FA.additionalIncludes preserve=no
//## end module%44492F1700FA.additionalIncludes

//## begin module%44492F1700FA.includes preserve=yes
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif

#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#include "CXODST08.hpp"
//## end module%44492F1700FA.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSST03_h
#include "CXODST03.hpp"
#endif
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
#ifndef CXOSPO01_h
#include "CXODPO01.hpp"
#endif
#ifndef CXOSDO13_h
#include "CXODDO13.hpp"
#endif


//## begin module%44492F1700FA.declarations preserve=no
//## end module%44492F1700FA.declarations

//## begin module%44492F1700FA.additionalDeclarations preserve=yes
/* EXEC SQL BEGIN DECLARE SECTION; */ 

   char AMS_TSTAMP_START[11];
   char AMS_INTERVAL_TYPE[2];
   int AMS_T_FIN_ENTITY_ID;
   int AMS_T_FIN_ENTITY_ID_2;
   char AMS_T_MIS_MCC[5];
   int AMS_CATEGORY_ID;
   double AMS_AMT_TRAN;
   double AMS_AMT_SURCHARGE;
   double AMS_AMT_POS_REIMBURSE;
   double AMS_CASHBACK_AMT;
   int AMS_TRAN_COUNT;
   short AMS_PARTITION_KEY;
   short AMS_NULL;
   double AMS_TIME_AT_ISS;
   double AMS_TIME_AT_RQST_SWTCH;
   double AMS_AMT_FEE;
   int AMS_SYNC_INTERVAL_NO;
   char AMS_BIN[12];
/* EXEC SQL END DECLARE SECTION; */ 

//## end module%44492F1700FA.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

// Class dnoracledatabase::OracleAggregatorMIS 

OracleAggregatorMIS::OracleAggregatorMIS()
  //## begin OracleAggregatorMIS::OracleAggregatorMIS%444917190203_const.hasinit preserve=no
      : m_lTransaction(-1)
  //## end OracleAggregatorMIS::OracleAggregatorMIS%444917190203_const.hasinit
  //## begin OracleAggregatorMIS::OracleAggregatorMIS%444917190203_const.initialization preserve=yes
  //## end OracleAggregatorMIS::OracleAggregatorMIS%444917190203_const.initialization
{
  //## begin dnoracledatabase::OracleAggregatorMIS::OracleAggregatorMIS%444917190203_const.body preserve=yes
   memcpy(m_sID,"DO13",4);
  //## end dnoracledatabase::OracleAggregatorMIS::OracleAggregatorMIS%444917190203_const.body
}


OracleAggregatorMIS::~OracleAggregatorMIS()
{
  //## begin dnoracledatabase::OracleAggregatorMIS::~OracleAggregatorMIS%444917190203_dest.body preserve=yes
  //## end dnoracledatabase::OracleAggregatorMIS::~OracleAggregatorMIS%444917190203_dest.body
}



//## Other Operations (implementation)
int OracleAggregatorMIS::checkResult ()
{
  //## begin dnoracledatabase::OracleAggregatorMIS::checkResult%44493536034B.body preserve=yes
   switch (sqlca.sqlcode)
   {
      case 0:
         UseCase::addItem();
         return 1;
      case 100:
      case 1403:
         return 0;
      case -51:
      case -54:
      case -99999913:
         UseCase::add("DEADLOCK");
         break;
      case -1012:
      case -2396:
      case -3113:
      case -3114:
      case -3135:
         UseCase::add("CONNECT");
         Database::instance()->setState(Database::DISCONNECTED);
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            Database::instance()->traceSQLError((void*)&sqlca,m_sID,m_strDBAccess.c_str());
            UseCase::addItem();
            return 1;
         }
         else
            UseCase::add("DBERROR");
   }
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca, m_sID,m_strDBAccess.c_str());
   return -1;
  //## end dnoracledatabase::OracleAggregatorMIS::checkResult%44493536034B.body
}

void OracleAggregatorMIS::lockTables ()
{
  //## begin dnoracledatabase::OracleAggregatorMIS::lockTables%44493536035B.body preserve=yes
   //if (m_lTransaction == Database::instance()->transaction())
   //   return;
   //m_lTransaction = Database::instance()->transaction();
   //EXEC SQL LOCK TABLE T_MIS_TOTAL IN EXCLUSIVE MODE;
   //if (sqlca.sqlcode != 0)
   //{
   //   Database::instance()->traceSQLError((void*)&sqlca,m_sID,"lockTables");
   //   if (sqlca.sqlcode == -51 || sqlca.sqlcode == -54 || sqlca.sqlcode == -99999913)
   //      Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   //}
  //## end dnoracledatabase::OracleAggregatorMIS::lockTables%44493536035B.body
}

bool OracleAggregatorMIS::tableInsert (bool bSubtractFromTotals)
{
  //## begin dnoracledatabase::OracleAggregatorMIS::tableInsert%44493536036B.body preserve=yes
   AMS_NULL = (AMS_T_FIN_ENTITY_ID_2 == -1) ? -1 : 0;
   m_strDBAccess = "INSERT";
   /* EXEC SQL
      INSERT INTO T_MIS_TOTAL
         (
            TSTAMP_START,
            INTERVAL_TYPE,
            T_FIN_ENTITY_ID,
            T_FIN_ENTITY_ID_2,
            T_MIS_MCC,
            CATEGORY_ID,
            PARTITION_KEY,
            AMT_TRAN,
            AMT_SURCHARGE,
            AMT_POS_REIMBURSE,
            CASHBACK_AMT,
            TRAN_COUNT,
            TIME_AT_ISS,
            TIME_AT_RQST_SWTCH,
            AMT_FEE,
            SYNC_INTERVAL_NO,
            BIN
         )
         VALUES
         (
            :AMS_TSTAMP_START,
            :AMS_INTERVAL_TYPE,
            :AMS_T_FIN_ENTITY_ID,
            :AMS_T_FIN_ENTITY_ID_2 :AMS_NULL,
            :AMS_T_MIS_MCC,
            :AMS_CATEGORY_ID,
            :AMS_PARTITION_KEY,
            :AMS_AMT_TRAN,
            :AMS_AMT_SURCHARGE,
            :AMS_AMT_POS_REIMBURSE,
            :AMS_CASHBACK_AMT,
            :AMS_TRAN_COUNT,
            :AMS_TIME_AT_ISS,
            :AMS_TIME_AT_RQST_SWTCH,
            :AMS_AMT_FEE,
            :AMS_SYNC_INTERVAL_NO,
            :AMS_BIN
         ); */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 13;
   sqlstm.arrsiz = 17;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "insert into T_MIS_TOTAL (TSTAMP_START,INTERVAL_TYPE,T_FIN_\
ENTITY_ID,T_FIN_ENTITY_ID_2,T_MIS_MCC,CATEGORY_ID,PARTITION_KEY,AMT_TRAN,AMT_S\
URCHARGE,AMT_POS_REIMBURSE,CASHBACK_AMT,TRAN_COUNT,TIME_AT_ISS,TIME_AT_RQST_SW\
TCH,AMT_FEE,SYNC_INTERVAL_NO,BIN) values (:b0,:b1,:b2,:b3:b4,:b5,:b6,:b7,:b8,:\
b9,:b10,:b11,:b12,:b13,:b14,:b15,:b16,:b17)";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )5;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (         void  *)AMS_TSTAMP_START;
   sqlstm.sqhstl[0] = (unsigned int  )11;
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         void  *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned int  )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (         void  *)AMS_INTERVAL_TYPE;
   sqlstm.sqhstl[1] = (unsigned int  )2;
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         void  *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned int  )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqhstv[2] = (         void  *)&AMS_T_FIN_ENTITY_ID;
   sqlstm.sqhstl[2] = (unsigned int  )sizeof(int);
   sqlstm.sqhsts[2] = (         int  )0;
   sqlstm.sqindv[2] = (         void  *)0;
   sqlstm.sqinds[2] = (         int  )0;
   sqlstm.sqharm[2] = (unsigned int  )0;
   sqlstm.sqadto[2] = (unsigned short )0;
   sqlstm.sqtdso[2] = (unsigned short )0;
   sqlstm.sqhstv[3] = (         void  *)&AMS_T_FIN_ENTITY_ID_2;
   sqlstm.sqhstl[3] = (unsigned int  )sizeof(int);
   sqlstm.sqhsts[3] = (         int  )0;
   sqlstm.sqindv[3] = (         void  *)&AMS_NULL;
   sqlstm.sqinds[3] = (         int  )0;
   sqlstm.sqharm[3] = (unsigned int  )0;
   sqlstm.sqadto[3] = (unsigned short )0;
   sqlstm.sqtdso[3] = (unsigned short )0;
   sqlstm.sqhstv[4] = (         void  *)AMS_T_MIS_MCC;
   sqlstm.sqhstl[4] = (unsigned int  )5;
   sqlstm.sqhsts[4] = (         int  )0;
   sqlstm.sqindv[4] = (         void  *)0;
   sqlstm.sqinds[4] = (         int  )0;
   sqlstm.sqharm[4] = (unsigned int  )0;
   sqlstm.sqadto[4] = (unsigned short )0;
   sqlstm.sqtdso[4] = (unsigned short )0;
   sqlstm.sqhstv[5] = (         void  *)&AMS_CATEGORY_ID;
   sqlstm.sqhstl[5] = (unsigned int  )sizeof(int);
   sqlstm.sqhsts[5] = (         int  )0;
   sqlstm.sqindv[5] = (         void  *)0;
   sqlstm.sqinds[5] = (         int  )0;
   sqlstm.sqharm[5] = (unsigned int  )0;
   sqlstm.sqadto[5] = (unsigned short )0;
   sqlstm.sqtdso[5] = (unsigned short )0;
   sqlstm.sqhstv[6] = (         void  *)&AMS_PARTITION_KEY;
   sqlstm.sqhstl[6] = (unsigned int  )sizeof(short);
   sqlstm.sqhsts[6] = (         int  )0;
   sqlstm.sqindv[6] = (         void  *)0;
   sqlstm.sqinds[6] = (         int  )0;
   sqlstm.sqharm[6] = (unsigned int  )0;
   sqlstm.sqadto[6] = (unsigned short )0;
   sqlstm.sqtdso[6] = (unsigned short )0;
   sqlstm.sqhstv[7] = (         void  *)&AMS_AMT_TRAN;
   sqlstm.sqhstl[7] = (unsigned int  )sizeof(double);
   sqlstm.sqhsts[7] = (         int  )0;
   sqlstm.sqindv[7] = (         void  *)0;
   sqlstm.sqinds[7] = (         int  )0;
   sqlstm.sqharm[7] = (unsigned int  )0;
   sqlstm.sqadto[7] = (unsigned short )0;
   sqlstm.sqtdso[7] = (unsigned short )0;
   sqlstm.sqhstv[8] = (         void  *)&AMS_AMT_SURCHARGE;
   sqlstm.sqhstl[8] = (unsigned int  )sizeof(double);
   sqlstm.sqhsts[8] = (         int  )0;
   sqlstm.sqindv[8] = (         void  *)0;
   sqlstm.sqinds[8] = (         int  )0;
   sqlstm.sqharm[8] = (unsigned int  )0;
   sqlstm.sqadto[8] = (unsigned short )0;
   sqlstm.sqtdso[8] = (unsigned short )0;
   sqlstm.sqhstv[9] = (         void  *)&AMS_AMT_POS_REIMBURSE;
   sqlstm.sqhstl[9] = (unsigned int  )sizeof(double);
   sqlstm.sqhsts[9] = (         int  )0;
   sqlstm.sqindv[9] = (         void  *)0;
   sqlstm.sqinds[9] = (         int  )0;
   sqlstm.sqharm[9] = (unsigned int  )0;
   sqlstm.sqadto[9] = (unsigned short )0;
   sqlstm.sqtdso[9] = (unsigned short )0;
   sqlstm.sqhstv[10] = (         void  *)&AMS_CASHBACK_AMT;
   sqlstm.sqhstl[10] = (unsigned int  )sizeof(double);
   sqlstm.sqhsts[10] = (         int  )0;
   sqlstm.sqindv[10] = (         void  *)0;
   sqlstm.sqinds[10] = (         int  )0;
   sqlstm.sqharm[10] = (unsigned int  )0;
   sqlstm.sqadto[10] = (unsigned short )0;
   sqlstm.sqtdso[10] = (unsigned short )0;
   sqlstm.sqhstv[11] = (         void  *)&AMS_TRAN_COUNT;
   sqlstm.sqhstl[11] = (unsigned int  )sizeof(int);
   sqlstm.sqhsts[11] = (         int  )0;
   sqlstm.sqindv[11] = (         void  *)0;
   sqlstm.sqinds[11] = (         int  )0;
   sqlstm.sqharm[11] = (unsigned int  )0;
   sqlstm.sqadto[11] = (unsigned short )0;
   sqlstm.sqtdso[11] = (unsigned short )0;
   sqlstm.sqhstv[12] = (         void  *)&AMS_TIME_AT_ISS;
   sqlstm.sqhstl[12] = (unsigned int  )sizeof(double);
   sqlstm.sqhsts[12] = (         int  )0;
   sqlstm.sqindv[12] = (         void  *)0;
   sqlstm.sqinds[12] = (         int  )0;
   sqlstm.sqharm[12] = (unsigned int  )0;
   sqlstm.sqadto[12] = (unsigned short )0;
   sqlstm.sqtdso[12] = (unsigned short )0;
   sqlstm.sqhstv[13] = (         void  *)&AMS_TIME_AT_RQST_SWTCH;
   sqlstm.sqhstl[13] = (unsigned int  )sizeof(double);
   sqlstm.sqhsts[13] = (         int  )0;
   sqlstm.sqindv[13] = (         void  *)0;
   sqlstm.sqinds[13] = (         int  )0;
   sqlstm.sqharm[13] = (unsigned int  )0;
   sqlstm.sqadto[13] = (unsigned short )0;
   sqlstm.sqtdso[13] = (unsigned short )0;
   sqlstm.sqhstv[14] = (         void  *)&AMS_AMT_FEE;
   sqlstm.sqhstl[14] = (unsigned int  )sizeof(double);
   sqlstm.sqhsts[14] = (         int  )0;
   sqlstm.sqindv[14] = (         void  *)0;
   sqlstm.sqinds[14] = (         int  )0;
   sqlstm.sqharm[14] = (unsigned int  )0;
   sqlstm.sqadto[14] = (unsigned short )0;
   sqlstm.sqtdso[14] = (unsigned short )0;
   sqlstm.sqhstv[15] = (         void  *)&AMS_SYNC_INTERVAL_NO;
   sqlstm.sqhstl[15] = (unsigned int  )sizeof(int);
   sqlstm.sqhsts[15] = (         int  )0;
   sqlstm.sqindv[15] = (         void  *)0;
   sqlstm.sqinds[15] = (         int  )0;
   sqlstm.sqharm[15] = (unsigned int  )0;
   sqlstm.sqadto[15] = (unsigned short )0;
   sqlstm.sqtdso[15] = (unsigned short )0;
   sqlstm.sqhstv[16] = (         void  *)AMS_BIN;
   sqlstm.sqhstl[16] = (unsigned int  )12;
   sqlstm.sqhsts[16] = (         int  )0;
   sqlstm.sqindv[16] = (         void  *)0;
   sqlstm.sqinds[16] = (         int  )0;
   sqlstm.sqharm[16] = (unsigned int  )0;
   sqlstm.sqadto[16] = (unsigned short )0;
   sqlstm.sqtdso[16] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   if (checkResult() == -1)
   {
      char szTemp[5 * PERCENTLD + 7 * PERCENTF + 3 * PERCENTS];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_MIS_TOTAL %s %ld %ld %s %ld %.0f %.0f %.0f %.0f %ld %.0f %.0f %.0f %ld %s",
         AMS_TSTAMP_START,AMS_T_FIN_ENTITY_ID,AMS_T_FIN_ENTITY_ID_2,AMS_T_MIS_MCC,AMS_CATEGORY_ID,AMS_AMT_TRAN,AMS_AMT_SURCHARGE,
         AMS_AMT_POS_REIMBURSE,AMS_CASHBACK_AMT,AMS_TRAN_COUNT,AMS_TIME_AT_ISS,AMS_TIME_AT_RQST_SWTCH,AMS_AMT_FEE,AMS_SYNC_INTERVAL_NO,AMS_BIN);
      Trace::put(szTemp);
      return false;
   }
   return true;
  //## end dnoracledatabase::OracleAggregatorMIS::tableInsert%44493536036B.body
}

int OracleAggregatorMIS::tableUpdate (bool bSubtractFromTotals)
{
  //## begin dnoracledatabase::OracleAggregatorMIS::tableUpdate%44493536037A.body preserve=yes
   memcpy(AMS_TSTAMP_START,getTSTAMP_START().data(),min((size_t)getTSTAMP_START().length(),sizeof(AMS_TSTAMP_START)-1));
   AMS_TSTAMP_START[min((size_t)getTSTAMP_START().length(),sizeof(AMS_TSTAMP_START)-1)] = '\0';
   memcpy(AMS_INTERVAL_TYPE,getINTERVAL_TYPE().data(),min((size_t)getINTERVAL_TYPE().length(),sizeof(AMS_INTERVAL_TYPE)-1));
   AMS_INTERVAL_TYPE[min((size_t)getINTERVAL_TYPE().length(),sizeof(AMS_INTERVAL_TYPE)-1)] = '\0';
   memcpy(AMS_BIN,getBIN().data(),min((size_t)getBIN().length(),sizeof(AMS_BIN)-1));
   AMS_BIN[min((size_t)getBIN().length(),sizeof(AMS_BIN)-1)] = '\0';
   int iT_FIN_ENTITY_ID = 0;
   RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(0).c_str(),getENTITY_ID(0).c_str(),&iT_FIN_ENTITY_ID);
   AMS_T_FIN_ENTITY_ID = iT_FIN_ENTITY_ID;
   int iT_FIN_ENTITY_ID_2 = -1;
   if (getENTITY_ID(1) != "~NULL!")
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(1).c_str(),getENTITY_ID(1).c_str(),&iT_FIN_ENTITY_ID_2);
   AMS_T_FIN_ENTITY_ID_2 = iT_FIN_ENTITY_ID_2;
   if (getT_MIS_MCC().length() == 0)
   {
      AMS_T_MIS_MCC[0] = ' ';
      AMS_T_MIS_MCC[1] = '\0';
   }
   else
   {
      memcpy(AMS_T_MIS_MCC,getT_MIS_MCC().data(),min((size_t)getT_MIS_MCC().length(),sizeof(AMS_T_MIS_MCC)-1));
      AMS_T_MIS_MCC[min((size_t)getT_MIS_MCC().length(),sizeof(AMS_T_MIS_MCC)-1)] = '\0';
   }
   AMS_SYNC_INTERVAL_NO = getSYNC_INTERVAL_NO();
   AMS_CATEGORY_ID = getCATEGORY_ID();
   AMS_AMT_TRAN = (bSubtractFromTotals) ? 0 - getAMT_TRAN() : getAMT_TRAN();
   AMS_AMT_SURCHARGE = (bSubtractFromTotals) ? 0 - getAMT_SURCHARGE() : getAMT_SURCHARGE();
   AMS_AMT_POS_REIMBURSE = (bSubtractFromTotals) ? 0 - getAMT_POS_REIMBURSE() : getAMT_POS_REIMBURSE();
   AMS_CASHBACK_AMT = (bSubtractFromTotals) ? 0 - getCASHBACK_AMT() : getCASHBACK_AMT();
   AMS_TRAN_COUNT = (bSubtractFromTotals) ? -1 : 1;
   AMS_TIME_AT_ISS = (bSubtractFromTotals) ? 0 - (double)getTIME_AT_ISS() : (double)getTIME_AT_ISS();
   AMS_TIME_AT_RQST_SWTCH = (bSubtractFromTotals) ? 0 - (double)getTIME_AT_RQST_SWTCH() : (double)getTIME_AT_RQST_SWTCH();
   AMS_AMT_FEE = (bSubtractFromTotals) ? 0 - getAMT_FEE() : getAMT_FEE();
   //lockTables();
   //if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
   //   return -1;
   m_strDBAccess = "UPDATE";
   if (AMS_T_FIN_ENTITY_ID_2 == -1)
      /* EXEC SQL
         UPDATE T_MIS_TOTAL
            SET
               AMT_TRAN = AMT_TRAN + :AMS_AMT_TRAN,
               AMT_SURCHARGE = AMT_SURCHARGE + :AMS_AMT_SURCHARGE,
               AMT_POS_REIMBURSE = AMT_POS_REIMBURSE + :AMS_AMT_POS_REIMBURSE,
               CASHBACK_AMT = CASHBACK_AMT + :AMS_CASHBACK_AMT,
               TRAN_COUNT = TRAN_COUNT + :AMS_TRAN_COUNT,
               TIME_AT_ISS = TIME_AT_ISS + :AMS_TIME_AT_ISS,
               TIME_AT_RQST_SWTCH = TIME_AT_RQST_SWTCH + :AMS_TIME_AT_RQST_SWTCH,
               AMT_FEE = AMT_FEE + :AMS_AMT_FEE
            WHERE
               TSTAMP_START = :AMS_TSTAMP_START
               AND T_FIN_ENTITY_ID = :AMS_T_FIN_ENTITY_ID
               AND T_FIN_ENTITY_ID_2 IS NULL
               AND T_MIS_MCC = :AMS_T_MIS_MCC
               AND CATEGORY_ID = :AMS_CATEGORY_ID
               AND INTERVAL_TYPE = :AMS_INTERVAL_TYPE
               AND (SYNC_INTERVAL_NO = :AMS_SYNC_INTERVAL_NO
                OR SYNC_INTERVAL_NO IS NULL)
               AND BIN = :AMS_BIN; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 13;
      sqlstm.arrsiz = 17;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "update T_MIS_TOTAL  set AMT_TRAN=(AMT_TRAN+:b0),AMT_SUR\
CHARGE=(AMT_SURCHARGE+:b1),AMT_POS_REIMBURSE=(AMT_POS_REIMBURSE+:b2),CASHBACK_\
AMT=(CASHBACK_AMT+:b3),TRAN_COUNT=(TRAN_COUNT+:b4),TIME_AT_ISS=(TIME_AT_ISS+:b\
5),TIME_AT_RQST_SWTCH=(TIME_AT_RQST_SWTCH+:b6),AMT_FEE=(AMT_FEE+:b7) where (((\
((((TSTAMP_START=:b8 and T_FIN_ENTITY_ID=:b9) and T_FIN_ENTITY_ID_2 is null ) \
and T_MIS_MCC=:b10) and CATEGORY_ID=:b11) and INTERVAL_TYPE=:b12) and (SYNC_IN\
TERVAL_NO=:b13 or SYNC_INTERVAL_NO is null )) and BIN=:b14)";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )88;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (         void  *)&AMS_AMT_TRAN;
      sqlstm.sqhstl[0] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         void  *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned int  )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqhstv[1] = (         void  *)&AMS_AMT_SURCHARGE;
      sqlstm.sqhstl[1] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[1] = (         int  )0;
      sqlstm.sqindv[1] = (         void  *)0;
      sqlstm.sqinds[1] = (         int  )0;
      sqlstm.sqharm[1] = (unsigned int  )0;
      sqlstm.sqadto[1] = (unsigned short )0;
      sqlstm.sqtdso[1] = (unsigned short )0;
      sqlstm.sqhstv[2] = (         void  *)&AMS_AMT_POS_REIMBURSE;
      sqlstm.sqhstl[2] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[2] = (         int  )0;
      sqlstm.sqindv[2] = (         void  *)0;
      sqlstm.sqinds[2] = (         int  )0;
      sqlstm.sqharm[2] = (unsigned int  )0;
      sqlstm.sqadto[2] = (unsigned short )0;
      sqlstm.sqtdso[2] = (unsigned short )0;
      sqlstm.sqhstv[3] = (         void  *)&AMS_CASHBACK_AMT;
      sqlstm.sqhstl[3] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[3] = (         int  )0;
      sqlstm.sqindv[3] = (         void  *)0;
      sqlstm.sqinds[3] = (         int  )0;
      sqlstm.sqharm[3] = (unsigned int  )0;
      sqlstm.sqadto[3] = (unsigned short )0;
      sqlstm.sqtdso[3] = (unsigned short )0;
      sqlstm.sqhstv[4] = (         void  *)&AMS_TRAN_COUNT;
      sqlstm.sqhstl[4] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[4] = (         int  )0;
      sqlstm.sqindv[4] = (         void  *)0;
      sqlstm.sqinds[4] = (         int  )0;
      sqlstm.sqharm[4] = (unsigned int  )0;
      sqlstm.sqadto[4] = (unsigned short )0;
      sqlstm.sqtdso[4] = (unsigned short )0;
      sqlstm.sqhstv[5] = (         void  *)&AMS_TIME_AT_ISS;
      sqlstm.sqhstl[5] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[5] = (         int  )0;
      sqlstm.sqindv[5] = (         void  *)0;
      sqlstm.sqinds[5] = (         int  )0;
      sqlstm.sqharm[5] = (unsigned int  )0;
      sqlstm.sqadto[5] = (unsigned short )0;
      sqlstm.sqtdso[5] = (unsigned short )0;
      sqlstm.sqhstv[6] = (         void  *)&AMS_TIME_AT_RQST_SWTCH;
      sqlstm.sqhstl[6] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[6] = (         int  )0;
      sqlstm.sqindv[6] = (         void  *)0;
      sqlstm.sqinds[6] = (         int  )0;
      sqlstm.sqharm[6] = (unsigned int  )0;
      sqlstm.sqadto[6] = (unsigned short )0;
      sqlstm.sqtdso[6] = (unsigned short )0;
      sqlstm.sqhstv[7] = (         void  *)&AMS_AMT_FEE;
      sqlstm.sqhstl[7] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[7] = (         int  )0;
      sqlstm.sqindv[7] = (         void  *)0;
      sqlstm.sqinds[7] = (         int  )0;
      sqlstm.sqharm[7] = (unsigned int  )0;
      sqlstm.sqadto[7] = (unsigned short )0;
      sqlstm.sqtdso[7] = (unsigned short )0;
      sqlstm.sqhstv[8] = (         void  *)AMS_TSTAMP_START;
      sqlstm.sqhstl[8] = (unsigned int  )11;
      sqlstm.sqhsts[8] = (         int  )0;
      sqlstm.sqindv[8] = (         void  *)0;
      sqlstm.sqinds[8] = (         int  )0;
      sqlstm.sqharm[8] = (unsigned int  )0;
      sqlstm.sqadto[8] = (unsigned short )0;
      sqlstm.sqtdso[8] = (unsigned short )0;
      sqlstm.sqhstv[9] = (         void  *)&AMS_T_FIN_ENTITY_ID;
      sqlstm.sqhstl[9] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[9] = (         int  )0;
      sqlstm.sqindv[9] = (         void  *)0;
      sqlstm.sqinds[9] = (         int  )0;
      sqlstm.sqharm[9] = (unsigned int  )0;
      sqlstm.sqadto[9] = (unsigned short )0;
      sqlstm.sqtdso[9] = (unsigned short )0;
      sqlstm.sqhstv[10] = (         void  *)AMS_T_MIS_MCC;
      sqlstm.sqhstl[10] = (unsigned int  )5;
      sqlstm.sqhsts[10] = (         int  )0;
      sqlstm.sqindv[10] = (         void  *)0;
      sqlstm.sqinds[10] = (         int  )0;
      sqlstm.sqharm[10] = (unsigned int  )0;
      sqlstm.sqadto[10] = (unsigned short )0;
      sqlstm.sqtdso[10] = (unsigned short )0;
      sqlstm.sqhstv[11] = (         void  *)&AMS_CATEGORY_ID;
      sqlstm.sqhstl[11] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[11] = (         int  )0;
      sqlstm.sqindv[11] = (         void  *)0;
      sqlstm.sqinds[11] = (         int  )0;
      sqlstm.sqharm[11] = (unsigned int  )0;
      sqlstm.sqadto[11] = (unsigned short )0;
      sqlstm.sqtdso[11] = (unsigned short )0;
      sqlstm.sqhstv[12] = (         void  *)AMS_INTERVAL_TYPE;
      sqlstm.sqhstl[12] = (unsigned int  )2;
      sqlstm.sqhsts[12] = (         int  )0;
      sqlstm.sqindv[12] = (         void  *)0;
      sqlstm.sqinds[12] = (         int  )0;
      sqlstm.sqharm[12] = (unsigned int  )0;
      sqlstm.sqadto[12] = (unsigned short )0;
      sqlstm.sqtdso[12] = (unsigned short )0;
      sqlstm.sqhstv[13] = (         void  *)&AMS_SYNC_INTERVAL_NO;
      sqlstm.sqhstl[13] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[13] = (         int  )0;
      sqlstm.sqindv[13] = (         void  *)0;
      sqlstm.sqinds[13] = (         int  )0;
      sqlstm.sqharm[13] = (unsigned int  )0;
      sqlstm.sqadto[13] = (unsigned short )0;
      sqlstm.sqtdso[13] = (unsigned short )0;
      sqlstm.sqhstv[14] = (         void  *)AMS_BIN;
      sqlstm.sqhstl[14] = (unsigned int  )12;
      sqlstm.sqhsts[14] = (         int  )0;
      sqlstm.sqindv[14] = (         void  *)0;
      sqlstm.sqinds[14] = (         int  )0;
      sqlstm.sqharm[14] = (unsigned int  )0;
      sqlstm.sqadto[14] = (unsigned short )0;
      sqlstm.sqtdso[14] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   else
      /* EXEC SQL
         UPDATE T_MIS_TOTAL
            SET
               AMT_TRAN = AMT_TRAN + :AMS_AMT_TRAN,
               AMT_SURCHARGE = AMT_SURCHARGE + :AMS_AMT_SURCHARGE,
               AMT_POS_REIMBURSE = AMT_POS_REIMBURSE + :AMS_AMT_POS_REIMBURSE,
               CASHBACK_AMT = CASHBACK_AMT + :AMS_CASHBACK_AMT,
               TRAN_COUNT = TRAN_COUNT + :AMS_TRAN_COUNT,
               TIME_AT_ISS = TIME_AT_ISS + :AMS_TIME_AT_ISS,
               TIME_AT_RQST_SWTCH = TIME_AT_RQST_SWTCH + :AMS_TIME_AT_RQST_SWTCH,
               AMT_FEE = AMT_FEE + :AMS_AMT_FEE
            WHERE
               TSTAMP_START = :AMS_TSTAMP_START
               AND T_FIN_ENTITY_ID = :AMS_T_FIN_ENTITY_ID
               AND T_FIN_ENTITY_ID_2 = :AMS_T_FIN_ENTITY_ID_2
               AND T_MIS_MCC = :AMS_T_MIS_MCC
               AND CATEGORY_ID = :AMS_CATEGORY_ID
               AND INTERVAL_TYPE = :AMS_INTERVAL_TYPE
               AND (SYNC_INTERVAL_NO = :AMS_SYNC_INTERVAL_NO
                OR SYNC_INTERVAL_NO IS NULL)
               AND BIN = :AMS_BIN; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 13;
      sqlstm.arrsiz = 17;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "update T_MIS_TOTAL  set AMT_TRAN=(AMT_TRAN+:b0),AMT_SUR\
CHARGE=(AMT_SURCHARGE+:b1),AMT_POS_REIMBURSE=(AMT_POS_REIMBURSE+:b2),CASHBACK_\
AMT=(CASHBACK_AMT+:b3),TRAN_COUNT=(TRAN_COUNT+:b4),TIME_AT_ISS=(TIME_AT_ISS+:b\
5),TIME_AT_RQST_SWTCH=(TIME_AT_RQST_SWTCH+:b6),AMT_FEE=(AMT_FEE+:b7) where (((\
((((TSTAMP_START=:b8 and T_FIN_ENTITY_ID=:b9) and T_FIN_ENTITY_ID_2=:b10) and \
T_MIS_MCC=:b11) and CATEGORY_ID=:b12) and INTERVAL_TYPE=:b13) and (SYNC_INTERV\
AL_NO=:b14 or SYNC_INTERVAL_NO is null )) and BIN=:b15)";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )163;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (         void  *)&AMS_AMT_TRAN;
      sqlstm.sqhstl[0] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         void  *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned int  )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqhstv[1] = (         void  *)&AMS_AMT_SURCHARGE;
      sqlstm.sqhstl[1] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[1] = (         int  )0;
      sqlstm.sqindv[1] = (         void  *)0;
      sqlstm.sqinds[1] = (         int  )0;
      sqlstm.sqharm[1] = (unsigned int  )0;
      sqlstm.sqadto[1] = (unsigned short )0;
      sqlstm.sqtdso[1] = (unsigned short )0;
      sqlstm.sqhstv[2] = (         void  *)&AMS_AMT_POS_REIMBURSE;
      sqlstm.sqhstl[2] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[2] = (         int  )0;
      sqlstm.sqindv[2] = (         void  *)0;
      sqlstm.sqinds[2] = (         int  )0;
      sqlstm.sqharm[2] = (unsigned int  )0;
      sqlstm.sqadto[2] = (unsigned short )0;
      sqlstm.sqtdso[2] = (unsigned short )0;
      sqlstm.sqhstv[3] = (         void  *)&AMS_CASHBACK_AMT;
      sqlstm.sqhstl[3] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[3] = (         int  )0;
      sqlstm.sqindv[3] = (         void  *)0;
      sqlstm.sqinds[3] = (         int  )0;
      sqlstm.sqharm[3] = (unsigned int  )0;
      sqlstm.sqadto[3] = (unsigned short )0;
      sqlstm.sqtdso[3] = (unsigned short )0;
      sqlstm.sqhstv[4] = (         void  *)&AMS_TRAN_COUNT;
      sqlstm.sqhstl[4] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[4] = (         int  )0;
      sqlstm.sqindv[4] = (         void  *)0;
      sqlstm.sqinds[4] = (         int  )0;
      sqlstm.sqharm[4] = (unsigned int  )0;
      sqlstm.sqadto[4] = (unsigned short )0;
      sqlstm.sqtdso[4] = (unsigned short )0;
      sqlstm.sqhstv[5] = (         void  *)&AMS_TIME_AT_ISS;
      sqlstm.sqhstl[5] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[5] = (         int  )0;
      sqlstm.sqindv[5] = (         void  *)0;
      sqlstm.sqinds[5] = (         int  )0;
      sqlstm.sqharm[5] = (unsigned int  )0;
      sqlstm.sqadto[5] = (unsigned short )0;
      sqlstm.sqtdso[5] = (unsigned short )0;
      sqlstm.sqhstv[6] = (         void  *)&AMS_TIME_AT_RQST_SWTCH;
      sqlstm.sqhstl[6] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[6] = (         int  )0;
      sqlstm.sqindv[6] = (         void  *)0;
      sqlstm.sqinds[6] = (         int  )0;
      sqlstm.sqharm[6] = (unsigned int  )0;
      sqlstm.sqadto[6] = (unsigned short )0;
      sqlstm.sqtdso[6] = (unsigned short )0;
      sqlstm.sqhstv[7] = (         void  *)&AMS_AMT_FEE;
      sqlstm.sqhstl[7] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[7] = (         int  )0;
      sqlstm.sqindv[7] = (         void  *)0;
      sqlstm.sqinds[7] = (         int  )0;
      sqlstm.sqharm[7] = (unsigned int  )0;
      sqlstm.sqadto[7] = (unsigned short )0;
      sqlstm.sqtdso[7] = (unsigned short )0;
      sqlstm.sqhstv[8] = (         void  *)AMS_TSTAMP_START;
      sqlstm.sqhstl[8] = (unsigned int  )11;
      sqlstm.sqhsts[8] = (         int  )0;
      sqlstm.sqindv[8] = (         void  *)0;
      sqlstm.sqinds[8] = (         int  )0;
      sqlstm.sqharm[8] = (unsigned int  )0;
      sqlstm.sqadto[8] = (unsigned short )0;
      sqlstm.sqtdso[8] = (unsigned short )0;
      sqlstm.sqhstv[9] = (         void  *)&AMS_T_FIN_ENTITY_ID;
      sqlstm.sqhstl[9] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[9] = (         int  )0;
      sqlstm.sqindv[9] = (         void  *)0;
      sqlstm.sqinds[9] = (         int  )0;
      sqlstm.sqharm[9] = (unsigned int  )0;
      sqlstm.sqadto[9] = (unsigned short )0;
      sqlstm.sqtdso[9] = (unsigned short )0;
      sqlstm.sqhstv[10] = (         void  *)&AMS_T_FIN_ENTITY_ID_2;
      sqlstm.sqhstl[10] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[10] = (         int  )0;
      sqlstm.sqindv[10] = (         void  *)0;
      sqlstm.sqinds[10] = (         int  )0;
      sqlstm.sqharm[10] = (unsigned int  )0;
      sqlstm.sqadto[10] = (unsigned short )0;
      sqlstm.sqtdso[10] = (unsigned short )0;
      sqlstm.sqhstv[11] = (         void  *)AMS_T_MIS_MCC;
      sqlstm.sqhstl[11] = (unsigned int  )5;
      sqlstm.sqhsts[11] = (         int  )0;
      sqlstm.sqindv[11] = (         void  *)0;
      sqlstm.sqinds[11] = (         int  )0;
      sqlstm.sqharm[11] = (unsigned int  )0;
      sqlstm.sqadto[11] = (unsigned short )0;
      sqlstm.sqtdso[11] = (unsigned short )0;
      sqlstm.sqhstv[12] = (         void  *)&AMS_CATEGORY_ID;
      sqlstm.sqhstl[12] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[12] = (         int  )0;
      sqlstm.sqindv[12] = (         void  *)0;
      sqlstm.sqinds[12] = (         int  )0;
      sqlstm.sqharm[12] = (unsigned int  )0;
      sqlstm.sqadto[12] = (unsigned short )0;
      sqlstm.sqtdso[12] = (unsigned short )0;
      sqlstm.sqhstv[13] = (         void  *)AMS_INTERVAL_TYPE;
      sqlstm.sqhstl[13] = (unsigned int  )2;
      sqlstm.sqhsts[13] = (         int  )0;
      sqlstm.sqindv[13] = (         void  *)0;
      sqlstm.sqinds[13] = (         int  )0;
      sqlstm.sqharm[13] = (unsigned int  )0;
      sqlstm.sqadto[13] = (unsigned short )0;
      sqlstm.sqtdso[13] = (unsigned short )0;
      sqlstm.sqhstv[14] = (         void  *)&AMS_SYNC_INTERVAL_NO;
      sqlstm.sqhstl[14] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[14] = (         int  )0;
      sqlstm.sqindv[14] = (         void  *)0;
      sqlstm.sqinds[14] = (         int  )0;
      sqlstm.sqharm[14] = (unsigned int  )0;
      sqlstm.sqadto[14] = (unsigned short )0;
      sqlstm.sqtdso[14] = (unsigned short )0;
      sqlstm.sqhstv[15] = (         void  *)AMS_BIN;
      sqlstm.sqhstl[15] = (unsigned int  )12;
      sqlstm.sqhsts[15] = (         int  )0;
      sqlstm.sqindv[15] = (         void  *)0;
      sqlstm.sqinds[15] = (         int  )0;
      sqlstm.sqharm[15] = (unsigned int  )0;
      sqlstm.sqadto[15] = (unsigned short )0;
      sqlstm.sqtdso[15] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   int iRC = checkResult();
   if (iRC == -1)
   {
      char szTemp[5 * PERCENTLD + 7 * PERCENTF + 3 * PERCENTS];
      snprintf(szTemp,sizeof(szTemp),"UPDATE T_MIS_TOTAL %s %ld %ld %s %ld %.0f %.0f %.0f %.0f %ld %.0f %.0f %.0f %ld %s",
         AMS_TSTAMP_START,AMS_T_FIN_ENTITY_ID,AMS_T_FIN_ENTITY_ID_2,AMS_T_MIS_MCC,AMS_CATEGORY_ID,AMS_AMT_TRAN,AMS_AMT_SURCHARGE,
         AMS_AMT_POS_REIMBURSE,AMS_CASHBACK_AMT,AMS_TRAN_COUNT,AMS_TIME_AT_ISS,AMS_TIME_AT_RQST_SWTCH,AMS_AMT_FEE,AMS_SYNC_INTERVAL_NO,AMS_BIN);
      Trace::put(szTemp);
   }
   return iRC;
  //## end dnoracledatabase::OracleAggregatorMIS::tableUpdate%44493536037A.body
}

// Additional Declarations
  //## begin dnoracledatabase::OracleAggregatorMIS%444917190203.declarations preserve=yes
  //## end dnoracledatabase::OracleAggregatorMIS%444917190203.declarations

} // namespace dnoracledatabase

//## begin module%44492F1700FA.epilog preserve=yes
//## end module%44492F1700FA.epilog
