//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%631062DF036A.cm preserve=no
//## end module%631062DF036A.cm

//## begin module%631062DF036A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%631062DF036A.cp

//## Module: CXOSDO17%631062DF036A; Package specification
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Dodll\CXODDO17.hpp

#ifndef CXOSDO17_h
#define CXOSDO17_h 1

//## begin module%631062DF036A.additionalIncludes preserve=no
//## end module%631062DF036A.additionalIncludes

//## begin module%631062DF036A.includes preserve=yes
//## end module%631062DF036A.includes

#ifndef CXOSST87_h
#include "CXODST87.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class FinancialTransaction;
} // namespace settlement

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class NPI;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::OracleDatabase_CAT%44141ACC02DE
namespace oracledatabase {
class OracleDatabase;

} // namespace oracledatabase

//## begin module%631062DF036A.declarations preserve=no
//## end module%631062DF036A.declarations

//## begin module%631062DF036A.additionalDeclarations preserve=yes
//## end module%631062DF036A.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

//## begin dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.preface preserve=yes
//## end dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.preface

//## Class: OracleMISMonthlyCardHolder%63106438036C
//## Category: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
//## Subsystem: DODLL%444917C7035B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%631064E90388;monitor::UseCase { -> F}
//## Uses: <unnamed>%631064ED031F;IF::Trace { -> F}
//## Uses: <unnamed>%631064EF0358;oracledatabase::OracleDatabase { -> F}
//## Uses: <unnamed>%631064F202E1;settlement::FinancialTransaction { -> F}
//## Uses: <unnamed>%631064F5032A;reusable::NPI { -> F}

class DllExport OracleMISMonthlyCardHolder : public settlement::MISMonthlyCardHolder  //## Inherits: <unnamed>%631064E60038
{
  //## begin dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.initialDeclarations preserve=yes
  //## end dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.initialDeclarations

  public:
    //## Constructors (generated)
      OracleMISMonthlyCardHolder();

    //## Destructor (generated)
      virtual ~OracleMISMonthlyCardHolder();


    //## Other Operations (specified)
      //## Operation: add%6310651A0226
      virtual bool add (const FinancialTransaction& hFinancialTransaction);

      //## Operation: checkResult%631065440263
      int checkResult ();

      //## Operation: commit%631065590200
      virtual bool commit ();

      //## Operation: lockTables%63106573004C
      void lockTables ();

    // Additional Public Declarations
      //## begin dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.public preserve=yes
      //## end dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.public

  protected:
    // Additional Protected Declarations
      //## begin dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.protected preserve=yes
      //## end dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.protected

  private:
    // Additional Private Declarations
      //## begin dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.private preserve=yes
      //## end dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.implementation preserve=yes
      //## end dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.implementation

};

//## begin dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.postscript preserve=yes
//## end dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.postscript

} // namespace dnoracledatabase

//## begin module%631062DF036A.epilog preserve=yes
//## end module%631062DF036A.epilog


#endif
