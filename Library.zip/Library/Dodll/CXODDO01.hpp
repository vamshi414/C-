//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4449300C01A5.cm preserve=no
//	$Date:   Feb 06 2020 13:56:56  $ $Author:   e1009839  $
//	$Revision:   1.5  $
//## end module%4449300C01A5.cm

//## begin module%4449300C01A5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4449300C01A5.cp

//## Module: CXOSDO01%4449300C01A5; Package specification
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Dodll\CXODDO01.hpp

#ifndef CXOSDO01_h
#define CXOSDO01_h 1

//## begin module%4449300C01A5.additionalIncludes preserve=no
//## end module%4449300C01A5.additionalIncludes

//## begin module%4449300C01A5.includes preserve=yes
//## end module%4449300C01A5.includes

#ifndef CXOSPO02_h
#include "CXODPO02.hpp"
#endif

//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
class ODBCTransactionRemover;
class ODBCAddFinancialCommand;
class ODBCPartitionAllocator;
class ODBCPartitionDeallocator;
class ODBCLocator;
class ODBCAggregatorMIS;
class ODBCAggregatorPOSRisk;
} // namespace dnodbcdatabase

//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
class OracleMaintenanceProcedure;
class OracleCheckpointTotalsVisitor;

} // namespace dnoracledatabase

//## begin module%4449300C01A5.declarations preserve=no
//## end module%4449300C01A5.declarations

//## begin module%4449300C01A5.additionalDeclarations preserve=yes
//## end module%4449300C01A5.additionalDeclarations


namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

//## begin dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.preface preserve=yes
//## end dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.preface

//## Class: DNOracleDatabaseFactory%444916ED03B9
//## Category: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
//## Subsystem: DODLL%444917C7035B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%444A17E50242;OracleMaintenanceProcedure { -> F}
//## Uses: <unnamed>%444A1834033C;dnodbcdatabase::ODBCAddFinancialCommand { -> F}
//## Uses: <unnamed>%444A183B01A5;dnodbcdatabase::ODBCPartitionAllocator { -> F}
//## Uses: <unnamed>%444A183D004E;dnodbcdatabase::ODBCLocator { -> F}
//## Uses: <unnamed>%444A183E0290;dnodbcdatabase::ODBCPartitionDeallocator { -> F}
//## Uses: <unnamed>%444A1840004E;dnodbcdatabase::ODBCTransactionRemover { -> F}
//## Uses: <unnamed>%444A184101F4;dnodbcdatabase::ODBCAggregatorPOSRisk { -> F}
//## Uses: <unnamed>%444A184201B5;dnodbcdatabase::ODBCAggregatorMIS { -> F}
//## Uses: <unnamed>%47AC5CD7003E;OracleCheckpointTotalsVisitor { -> F}

class DllExport DNOracleDatabaseFactory : public oracledatabase::OracleDatabaseFactory  //## Inherits: <unnamed>%4449392A01D4
{
  //## begin dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.initialDeclarations preserve=yes
  //## end dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.initialDeclarations

  public:
    //## Constructors (generated)
      DNOracleDatabaseFactory();

    //## Destructor (generated)
      virtual ~DNOracleDatabaseFactory();


    //## Other Operations (specified)
      //## Operation: create%4449393C0280
      virtual Object* create (const char* pszClass, const char* pszValue = 0);

    // Additional Public Declarations
      //## begin dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.public preserve=yes
      //## end dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.public

  protected:
    // Additional Protected Declarations
      //## begin dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.protected preserve=yes
      //## end dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.protected

  private:
    // Additional Private Declarations
      //## begin dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.private preserve=yes
      //## end dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Classes%444938FB03B9
      //## begin dnoracledatabase::DNOracleDatabaseFactory::Classes%444938FB03B9.attr preserve=no  private: map<string,int,less<string> > {V} 
      map<string,int,less<string> > m_hClasses;
      //## end dnoracledatabase::DNOracleDatabaseFactory::Classes%444938FB03B9.attr

    // Additional Implementation Declarations
      //## begin dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.implementation preserve=yes
      //## end dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.implementation

};

//## begin dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.postscript preserve=yes
//## end dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.postscript

} // namespace dnoracledatabase

//## begin module%4449300C01A5.epilog preserve=yes
using namespace dnoracledatabase;
//## end module%4449300C01A5.epilog


#endif
