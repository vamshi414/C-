//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%44492E420157.cm preserve=no
//## end module%44492E420157.cm

//## begin module%44492E420157.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%44492E420157.cp

//## Module: CXOSDO10%44492E420157; Package specification
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Library\Dodll\CXODDO10.hpp

#ifndef CXOSDO10_h
#define CXOSDO10_h 1

//## begin module%44492E420157.additionalIncludes preserve=no
//## end module%44492E420157.additionalIncludes

//## begin module%44492E420157.includes preserve=yes
#define SQLCA_NONE
#include "sqlca.h"
//## end module%44492E420157.includes

#ifndef CXOSST06_h
#include "CXODST06.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class ReportingEntity;
class Total;
class RecoveryPoint;
class EntityGroup;
class ReportingPeriod;
class TotalsCategory;
} // namespace settlement

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::OracleDatabase_CAT%44141ACC02DE
namespace oracledatabase {
class OracleDatabase;

} // namespace oracledatabase

//## begin module%44492E420157.declarations preserve=no
//## end module%44492E420157.declarations

//## begin module%44492E420157.additionalDeclarations preserve=yes
//## end module%44492E420157.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

//## begin dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.preface preserve=yes
//## end dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.preface

//## Class: OracleCheckpointTotalsVisitor%4449173D004E
//## Category: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
//## Subsystem: DODLL%444917C7035B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%444933CA0148;database::Database { -> F}
//## Uses: <unnamed>%444933CB0148;monitor::UseCase { -> F}
//## Uses: <unnamed>%444933CC0148;timer::Clock { -> F}
//## Uses: <unnamed>%444933CD01E4;settlement::EntityGroup { -> F}
//## Uses: <unnamed>%444933D000EA;settlement::Total { -> F}
//## Uses: <unnamed>%444933D2029F;settlement::RecoveryPoint { -> F}
//## Uses: <unnamed>%444933D80157;settlement::ReportingEntity { -> F}
//## Uses: <unnamed>%444933DF01A5;settlement::ReportingPeriod { -> F}
//## Uses: <unnamed>%444933E7003E;settlement::TotalsCategory { -> F}
//## Uses: <unnamed>%444933F003C8;process::Application { -> F}
//## Uses: <unnamed>%5AE36F2702F5;oracledatabase::OracleDatabase { -> F}

class DllExport OracleCheckpointTotalsVisitor : public settlement::CheckpointTotalsVisitor  //## Inherits: <unnamed>%444933C800CB
{
  //## begin dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.initialDeclarations preserve=yes
  //## end dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.initialDeclarations

  public:
    //## Constructors (generated)
      OracleCheckpointTotalsVisitor();

    //## Destructor (generated)
      virtual ~OracleCheckpointTotalsVisitor();


    //## Other Operations (specified)
      //## Operation: visitAccumulator%4449341603D8
      virtual void visitAccumulator (Accumulator* pAccumulator);

      //## Operation: visitEntityGroup%44493417001F
      virtual void visitEntityGroup (EntityGroup* pEntityGroup);

      //## Operation: visitRecoveryPoint%44493417002E
      virtual void visitRecoveryPoint (RecoveryPoint* pRecoveryPoint);

      //## Operation: visitReportingEntity%44493417003E
      virtual void visitReportingEntity (ReportingEntity* pReportingEntity);

      //## Operation: visitReportingPeriod%44493417004E
      virtual void visitReportingPeriod (ReportingPeriod* pReportingPeriod);

      //## Operation: visitTotal%44493417005D
      virtual void visitTotal (Total* pTotal);

      //## Operation: visitTotalsCategory%44493417006D
      virtual void visitTotalsCategory (TotalsCategory* pTotalsCategory);

    // Additional Public Declarations
      //## begin dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.public preserve=yes
      //## end dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.public

  protected:
    // Additional Protected Declarations
      //## begin dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.protected preserve=yes
      //## end dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.protected

  private:

    //## Other Operations (specified)
      //## Operation: checkResult%4449341603B9
      bool checkResult ();

      //## Operation: lockTables%4449341603C8
      void lockTables ();

    // Additional Private Declarations
      //## begin dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.private preserve=yes
      //## end dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Transaction%4449340A00CB
      //## begin dnoracledatabase::OracleCheckpointTotalsVisitor::Transaction%4449340A00CB.attr preserve=no  private: int {V} -1
      int m_iTransaction;
      //## end dnoracledatabase::OracleCheckpointTotalsVisitor::Transaction%4449340A00CB.attr

    // Additional Implementation Declarations
      //## begin dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.implementation preserve=yes
      string m_strDBAccess;
      struct sqlca sqlca;
      //## end dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.implementation
};

//## begin dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.postscript preserve=yes
//## end dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.postscript

} // namespace dnoracledatabase

//## begin module%44492E420157.epilog preserve=yes
//## end module%44492E420157.epilog


#endif
