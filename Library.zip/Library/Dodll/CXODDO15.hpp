//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%606408C1001A.cm preserve=no
//## end module%606408C1001A.cm

//## begin module%606408C1001A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%606408C1001A.cp

//## Module: CXOSDO15%606408C1001A; Package specification
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Library\Dodll\CXODDO15.hpp

#ifndef CXOSDO15_h
#define CXOSDO15_h 1

//## begin module%606408C1001A.additionalIncludes preserve=no
//## end module%606408C1001A.additionalIncludes

//## begin module%606408C1001A.includes preserve=yes
//## end module%606408C1001A.includes

#ifndef CXOSST80_h
#include "CXODST80.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::OracleDatabase_CAT%44141ACC02DE
namespace oracledatabase {
class OracleDatabase;

} // namespace oracledatabase

//## begin module%606408C1001A.declarations preserve=no
//## end module%606408C1001A.declarations

//## begin module%606408C1001A.additionalDeclarations preserve=yes
//## end module%606408C1001A.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

//## begin dnoracledatabase::OracleMonthlyTotals%606409A6000D.preface preserve=yes
//## end dnoracledatabase::OracleMonthlyTotals%606409A6000D.preface

//## Class: OracleMonthlyTotals%606409A6000D
//## Category: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
//## Subsystem: DODLL%444917C7035B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%60640AF003C2;oracledatabase::OracleDatabase { -> F}
//## Uses: <unnamed>%60640B070152;monitor::UseCase { -> F}
//## Uses: <unnamed>%60640B1600A2;IF::Trace { -> F}

class DllExport OracleMonthlyTotals : public settlement::MonthlyTotal  //## Inherits: <unnamed>%606409FA0122
{
  //## begin dnoracledatabase::OracleMonthlyTotals%606409A6000D.initialDeclarations preserve=yes
  //## end dnoracledatabase::OracleMonthlyTotals%606409A6000D.initialDeclarations

  public:
    //## Constructors (generated)
      OracleMonthlyTotals();

    //## Destructor (generated)
      virtual ~OracleMonthlyTotals();


    //## Other Operations (specified)
      //## Operation: commit%60640A190385
      virtual bool commit ();

      //## Operation: tableUpdate%606421650038
      virtual int tableUpdate ();

    // Additional Public Declarations
      //## begin dnoracledatabase::OracleMonthlyTotals%606409A6000D.public preserve=yes
      //## end dnoracledatabase::OracleMonthlyTotals%606409A6000D.public

  protected:
    // Additional Protected Declarations
      //## begin dnoracledatabase::OracleMonthlyTotals%606409A6000D.protected preserve=yes
      //## end dnoracledatabase::OracleMonthlyTotals%606409A6000D.protected

  private:

    //## Other Operations (specified)
      //## Operation: checkResult%60640A43027E
      int checkResult ();

      //## Operation: lockTables%60640A51020E
      void lockTables ();

    // Additional Private Declarations
      //## begin dnoracledatabase::OracleMonthlyTotals%606409A6000D.private preserve=yes
      //## end dnoracledatabase::OracleMonthlyTotals%606409A6000D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DBAccess%60E40F8002CA
      //## begin dnoracledatabase::OracleMonthlyTotals::DBAccess%60E40F8002CA.attr preserve=no  private: string {U} 
      string m_strDBAccess;
      //## end dnoracledatabase::OracleMonthlyTotals::DBAccess%60E40F8002CA.attr

      //## Attribute: Transaction%60640AB1039D
      //## begin dnoracledatabase::OracleMonthlyTotals::Transaction%60640AB1039D.attr preserve=no  private: long {U} -1
      long m_lTransaction;
      //## end dnoracledatabase::OracleMonthlyTotals::Transaction%60640AB1039D.attr

    // Additional Implementation Declarations
      //## begin dnoracledatabase::OracleMonthlyTotals%606409A6000D.implementation preserve=yes
      //## end dnoracledatabase::OracleMonthlyTotals%606409A6000D.implementation

};

//## begin dnoracledatabase::OracleMonthlyTotals%606409A6000D.postscript preserve=yes
//## end dnoracledatabase::OracleMonthlyTotals%606409A6000D.postscript

} // namespace dnoracledatabase

//## begin module%606408C1001A.epilog preserve=yes
//## end module%606408C1001A.epilog


#endif
