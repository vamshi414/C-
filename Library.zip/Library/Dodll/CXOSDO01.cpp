//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4449300D0222.cm preserve=no
//	$Date:   Nov 10 2021 14:22:20  $ $Author:   e1009652  $
//	$Revision:   1.12  $
//## end module%4449300D0222.cm

//## begin module%4449300D0222.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4449300D0222.cp

//## Module: CXOSDO01%4449300D0222; Package body
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Dodll\CXOSDO01.cpp

//## begin module%4449300D0222.additionalIncludes preserve=no
//## end module%4449300D0222.additionalIncludes

//## begin module%4449300D0222.includes preserve=yes
#ifndef CXOSDQ10_h
#include "CXODDQ10.hpp"
#endif
#ifndef CXOSDO10_h
#include "CXODDO10.hpp"
#endif
#ifndef CXOSDO13_h
#include "CXODDO13.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDO15_h
#include "CXODDO15.hpp"
#endif
#ifndef CXOSDO16_h
#include "CXODDO16.hpp"
#endif
#ifndef CXOSDO17_h
#include "CXODDO17.hpp"
#endif
#ifndef CXOSDO18_h
#include "CXODDO18.hpp"
#endif
//## end module%4449300D0222.includes

#ifndef CXOSDO14_h
#include "CXODDO14.hpp"
#endif
#ifndef CXOSDQ04_h
#include "CXODDQ04.hpp"
#endif
#ifndef CXOSDQ07_h
#include "CXODDQ07.hpp"
#endif
#ifndef CXOSDQ02_h
#include "CXODDQ02.hpp"
#endif
#ifndef CXOSDQ08_h
#include "CXODDQ08.hpp"
#endif
#ifndef CXOSDQ09_h
#include "CXODDQ09.hpp"
#endif
#ifndef CXOSDQ12_h
#include "CXODDQ12.hpp"
#endif
#ifndef CXOSDQ13_h
#include "CXODDQ13.hpp"
#endif
#ifndef CXOSDO01_h
#include "CXODDO01.hpp"
#endif


//## begin module%4449300D0222.declarations preserve=no
//## end module%4449300D0222.declarations

//## begin module%4449300D0222.additionalDeclarations preserve=yes
//## end module%4449300D0222.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
extern "C" DatabaseFactory * create()
{
   return new DNOracleDatabaseFactory;
}
//## end dnoracledatabase%4449152200AB.initialDeclarations

// Class dnoracledatabase::DNOracleDatabaseFactory 

DNOracleDatabaseFactory::DNOracleDatabaseFactory()
  //## begin DNOracleDatabaseFactory::DNOracleDatabaseFactory%444916ED03B9_const.hasinit preserve=no
  //## end DNOracleDatabaseFactory::DNOracleDatabaseFactory%444916ED03B9_const.hasinit
  //## begin DNOracleDatabaseFactory::DNOracleDatabaseFactory%444916ED03B9_const.initialization preserve=yes
  //## end DNOracleDatabaseFactory::DNOracleDatabaseFactory%444916ED03B9_const.initialization
{
  //## begin dnoracledatabase::DNOracleDatabaseFactory::DNOracleDatabaseFactory%444916ED03B9_const.body preserve=yes
   memcpy(m_sID,"DO01",4);
   #define CLASSES 12
   const char* pszOracleClass[CLASSES] =
   {
      "AddFinancialCommand",
      "AggregatorMIS",
      "AggregatorPOSRisk",
      "CheckpointTotalsVisitor",
      "Locator",
      "MaintenanceProcedure",
      "PartitionAllocator",
      "PartitionDeallocator",
      "TransactionRemover",
      "MonthlyTotal",
      "MonthlyCardHolder",
      "MISMonthlyCardHolder"
   };
   string strClass;
   for (int m = 0;m < CLASSES;++m)
   {
      strClass = pszOracleClass[m];
      m_hClasses.insert(map<string,int,less<string> >::value_type(strClass,m));
   }
  //## end dnoracledatabase::DNOracleDatabaseFactory::DNOracleDatabaseFactory%444916ED03B9_const.body
}


DNOracleDatabaseFactory::~DNOracleDatabaseFactory()
{
  //## begin dnoracledatabase::DNOracleDatabaseFactory::~DNOracleDatabaseFactory%444916ED03B9_dest.body preserve=yes
  //## end dnoracledatabase::DNOracleDatabaseFactory::~DNOracleDatabaseFactory%444916ED03B9_dest.body
}



//## Other Operations (implementation)
Object* DNOracleDatabaseFactory::create (const char* pszClass, const char* pszValue)
{
  //## begin dnoracledatabase::DNOracleDatabaseFactory::create%4449393C0280.body preserve=yes
   string strClass(pszClass);
   map<string,int,less<string> >::iterator pClass = m_hClasses.find(strClass);
   if (pClass == m_hClasses.end())
      return OracleDatabaseFactory::create(pszClass,pszValue);
   Object* pObject = 0;
   vector<string > hValue;
   vector<string >::iterator p;
   int iMIS = 2;
   switch ((*pClass).second)
   {
      case 0:
         pObject = new ODBCAddFinancialCommand();
         break;
      case 1:
         Extract::instance()->getSpec("DO01", hValue);
         for (p = hValue.begin(); p != hValue.end(); ++p)
         {
            if ((*p).length() > 4
               && (*p).substr(0, 5) == "MIS~1")
               iMIS = 1;
         }
         if (iMIS != 1)
            pObject = new OracleAggregatorMIS2();
         else
            pObject = new OracleAggregatorMIS();
         break;
      case 2:
         pObject = new ODBCAggregatorPOSRisk();
         break;
      case 3:
         pObject = new OracleCheckpointTotalsVisitor();
         break;
      case 4:
         pObject = new ODBCLocator();
         break;
      case 5:
         pObject = new OracleMaintenanceProcedure();
         break;
      case 6:
         pObject = new ODBCPartitionAllocator();
         break;
      case 7:
         pObject = new ODBCPartitionDeallocator();
         break;
      case 8:
         pObject = new ODBCTransactionRemover();
         break;
      case 9:
         pObject = new OracleMonthlyTotals();
         break;
      case 10:
         pObject = new OracleMonthlyCardHolder();
         break;
      case 11:
         pObject = new OracleMISMonthlyCardHolder();
         break;
   }
   return pObject;
  //## end dnoracledatabase::DNOracleDatabaseFactory::create%4449393C0280.body
}

// Additional Declarations
  //## begin dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.declarations preserve=yes
  //## end dnoracledatabase::DNOracleDatabaseFactory%444916ED03B9.declarations

} // namespace dnoracledatabase

//## begin module%4449300D0222.epilog preserve=yes
//## end module%4449300D0222.epilog
