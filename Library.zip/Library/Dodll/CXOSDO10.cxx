
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[13];
};
static const struct sqlcxp sqlfpn =
{
    12,
    "CXOSDO10.sqx"
};


static unsigned int sqlctx = 306070;


static struct sqlexd {
   unsigned int   sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
            void  **sqphsv;
   unsigned int   *sqphsl;
            int   *sqphss;
            void  **sqpind;
            int   *sqpins;
   unsigned int   *sqparm;
   unsigned int   **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
              int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned int   sqlpfmem;
            void  *sqhstv[21];
   unsigned int   sqhstl[21];
            int   sqhsts[21];
            void  *sqindv[21];
            int   sqinds[21];
   unsigned int   sqharm[21];
   unsigned int   *sqharc[21];
   unsigned short  sqadto[21];
   unsigned short  sqtdso[21];
} sqlstm = {13,21};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(unsigned char *, signed int *); }

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{13,4130,178,8,0,
5,0,0,1,82,0,3,214,0,0,2,2,0,1,0,1,3,0,0,1,3,0,0,
28,0,0,2,91,0,3,235,0,0,3,3,0,1,0,1,3,0,0,1,3,0,0,1,3,0,0,
55,0,0,3,108,0,3,270,0,0,5,5,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,
0,
90,0,0,4,121,0,5,291,0,0,5,5,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,
0,
125,0,0,5,85,0,3,334,0,0,3,3,0,1,0,1,3,0,0,1,97,0,0,1,97,0,0,
152,0,0,6,164,0,3,405,0,0,7,7,0,1,0,1,3,0,0,1,3,0,0,1,97,0,0,1,97,0,0,1,97,0,0,
1,97,0,0,1,97,0,0,
195,0,0,7,139,0,5,430,0,0,6,6,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,
0,1,3,0,0,
234,0,0,8,282,0,5,469,0,0,9,9,0,1,0,1,3,0,0,1,4,0,0,1,4,0,0,1,4,0,0,1,4,0,0,1,
4,0,0,1,97,0,0,1,3,0,0,1,3,0,0,
285,0,0,9,193,0,3,485,0,0,9,9,0,1,0,1,3,0,0,1,3,0,0,1,3,0,0,1,4,0,0,1,4,0,0,1,
4,0,0,1,4,0,0,1,4,0,0,1,97,0,0,
336,0,0,10,381,0,3,671,0,0,21,21,0,1,0,1,3,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,
0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,
97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,
};


//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%44492E4400FA.cm preserve=no
//## end module%44492E4400FA.cm

//## begin module%44492E4400FA.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%44492E4400FA.cp

//## Module: CXOSDO10%44492E4400FA; Package body
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Library\Dodll\CXOSDO10.sqx

//## begin module%44492E4400FA.additionalIncludes preserve=no
//## end module%44492E4400FA.additionalIncludes

//## begin module%44492E4400FA.includes preserve=yes
#include <sqlcpr.h>
#include "CXODRU55.hpp"
#include "CXODIF03.hpp"
#include "CXODIF16.hpp"
//## end module%44492E4400FA.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSST12_h
#include "CXODST12.hpp"
#endif
#ifndef CXOSST04_h
#include "CXODST04.hpp"
#endif
#ifndef CXOSST14_h
#include "CXODST14.hpp"
#endif
#ifndef CXOSST09_h
#include "CXODST09.hpp"
#endif
#ifndef CXOSST11_h
#include "CXODST11.hpp"
#endif
#ifndef CXOSST10_h
#include "CXODST10.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSPO01_h
#include "CXODPO01.hpp"
#endif
#ifndef CXOSDO10_h
#include "CXODDO10.hpp"
#endif


//## begin module%44492E4400FA.declarations preserve=no
//## end module%44492E4400FA.declarations

//## begin module%44492E4400FA.additionalDeclarations preserve=yes
/* EXEC SQL BEGIN DECLARE SECTION; */ 

   int CTV_CATEGORY_ID;
   int CTV_ENTITY_GROUP_ID;
   int CTV_TRAN_COUNT;
   double CTV_AMT_RECON_NET;
   double CTV_AMT_TRAN;
   double CTV_AMT_CARD_BILL;
   double CTV_AMT_RECON_ACQ;
   double CTV_AMT_RECON_ISS;
   char CTV_TSTAMP_LAST_UPDATE[15];
   int CTV_T_FIN_ENTITY_ID;
   char CTV_ENTITY_TYPE[3];
   char CTV_ENTITY_ID[29];
   int CTV_SYNC_INTERVAL_NO;
   short CTV_SEQUENCE_NO;
   int CTV_PERIOD_ID;
   char CTV_TSTAMP_END[17];
   char CTV_TSTAMP_TRANS_FROM[17];
   char CTV_TSTAMP_TRANS_TO[17];
   char CTV_DATE_RECON[9];
   char CTV_TSTAMP_LAST_UPDATED[17];
   char CTV_NET_ID_ACQ[4];
   char CTV_NET_ID_ISS[4];
   char CTV_FIN_TYPE[4];
   char CTV_TRAN_TYPE_ID[11];
   char CTV_ACT_CODE[4];
   char CTV_FUNC_CODE[4];
   char CTV_AUTH_BY[2];
   char CTV_REV_BY[2];
   char CTV_CUR_RECON_NET[4];
   char CTV_CUR_TRAN[4];
   char CTV_CUR_CARD_BILL[4];
   char CTV_CUR_RECON_ACQ[4];
   char CTV_CUR_RECON_ISS[4];
   char CTV_IMPACT_TO_ACQ[2];
   char CTV_IMPACT_TO_ISS[2];
   char CTV_TRAN_DISPOSITION[2];
   char CTV_TOTAL_TYPE[5];
   char CTV_TRAN_CLASS[4];
   char CTV_MERCH_TYPE[5];
   char CTV_NETWORK_PROGRAM[11];
   char CTV_IMAGEID[5];
   char CTV_TASKID[8];
   char CTV_CONTEXT_TYPE[2];
   char CTV_CONTEXT_KEY[33];
   char CTV_CONTEXT_DATA[101];
/* EXEC SQL END DECLARE SECTION; */ 

//## end module%44492E4400FA.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

// Class dnoracledatabase::OracleCheckpointTotalsVisitor 

OracleCheckpointTotalsVisitor::OracleCheckpointTotalsVisitor()
  //## begin OracleCheckpointTotalsVisitor::OracleCheckpointTotalsVisitor%4449173D004E_const.hasinit preserve=no
      : m_iTransaction(-1)
  //## end OracleCheckpointTotalsVisitor::OracleCheckpointTotalsVisitor%4449173D004E_const.hasinit
  //## begin OracleCheckpointTotalsVisitor::OracleCheckpointTotalsVisitor%4449173D004E_const.initialization preserve=yes
  //## end OracleCheckpointTotalsVisitor::OracleCheckpointTotalsVisitor%4449173D004E_const.initialization
{
  //## begin dnoracledatabase::OracleCheckpointTotalsVisitor::OracleCheckpointTotalsVisitor%4449173D004E_const.body preserve=yes
   memcpy(m_sID,"DO10",4);
   memcpy(CTV_IMAGEID,"I01/",4);
   CTV_IMAGEID[4] = '\0';
   memcpy(CTV_TASKID,Application::instance()->name().data(),Application::instance()->name().length());
   CTV_TASKID[Application::instance()->name().length()] = '\0';
   CTV_CONTEXT_TYPE[0] = ' ';
   CTV_CONTEXT_TYPE[1] = '\0';
   memcpy(CTV_CONTEXT_KEY,"LOAD ",5);
  //## end dnoracledatabase::OracleCheckpointTotalsVisitor::OracleCheckpointTotalsVisitor%4449173D004E_const.body
}


OracleCheckpointTotalsVisitor::~OracleCheckpointTotalsVisitor()
{
  //## begin dnoracledatabase::OracleCheckpointTotalsVisitor::~OracleCheckpointTotalsVisitor%4449173D004E_dest.body preserve=yes
  //## end dnoracledatabase::OracleCheckpointTotalsVisitor::~OracleCheckpointTotalsVisitor%4449173D004E_dest.body
}



//## Other Operations (implementation)
bool OracleCheckpointTotalsVisitor::checkResult ()
{
  //## begin dnoracledatabase::OracleCheckpointTotalsVisitor::checkResult%4449341603B9.body preserve=yes
   int iSqlCode = sqlca.sqlcode; //debugging
   switch (sqlca.sqlcode)
   {
      case 0:
         UseCase::addItem();
         return true;
      case 100:
      case 1403:
         UseCase::add("DBERROR");
         break;
      case -51:
      case -54:
      case -99999913:
         UseCase::add("DEADLOCK");
         break;
      case -1012:
      case -2396:
      case -3113:
      case -3114:
      case -3135:
         UseCase::add("CONNECT");
         Database::instance()->setState(Database::DISCONNECTED);
         break;
      default:
         UseCase::add("DBERROR");
   }
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,m_strDBAccess.c_str());
   return false;
  //## end dnoracledatabase::OracleCheckpointTotalsVisitor::checkResult%4449341603B9.body
}

void OracleCheckpointTotalsVisitor::lockTables ()
{
  //## begin dnoracledatabase::OracleCheckpointTotalsVisitor::lockTables%4449341603C8.body preserve=yes
  //## end dnoracledatabase::OracleCheckpointTotalsVisitor::lockTables%4449341603C8.body
}

void OracleCheckpointTotalsVisitor::visitAccumulator (Accumulator* pAccumulator)
{
  //## begin dnoracledatabase::OracleCheckpointTotalsVisitor::visitAccumulator%4449341603D8.body preserve=yes
   if (Database::instance()->getDormant())
      Database::instance()->connect();
  //## end dnoracledatabase::OracleCheckpointTotalsVisitor::visitAccumulator%4449341603D8.body
}

void OracleCheckpointTotalsVisitor::visitEntityGroup (EntityGroup* pEntityGroup)
{
  //## begin dnoracledatabase::OracleCheckpointTotalsVisitor::visitEntityGroup%44493417001F.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   m_lENTITY_GROUP_ID = pEntityGroup->getENTITY_GROUP_ID();
   CTV_ENTITY_GROUP_ID = pEntityGroup->getENTITY_GROUP_ID();
   CTV_SYNC_INTERVAL_NO = pEntityGroup->getSYNC_INTERVAL_NO();
   m_strDBAccess = "INSERT";
   /* EXEC SQL
      INSERT INTO T_FIN_ENTITY_GROUP
      (
         ENTITY_GROUP_ID,
         SYNC_INTERVAL_NO
      )
      VALUES
      (
         :CTV_ENTITY_GROUP_ID,
         :CTV_SYNC_INTERVAL_NO
      ); */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 13;
   sqlstm.arrsiz = 2;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "insert into T_FIN_ENTITY_GROUP (ENTITY_GROUP_ID,SYNC_INTER\
VAL_NO) values (:b0,:b1)";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )5;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (         void  *)&CTV_ENTITY_GROUP_ID;
   sqlstm.sqhstl[0] = (unsigned int  )sizeof(int);
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         void  *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned int  )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (         void  *)&CTV_SYNC_INTERVAL_NO;
   sqlstm.sqhstl[1] = (unsigned int  )sizeof(int);
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         void  *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned int  )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_ENTITY_GROUP %ld %ld",CTV_ENTITY_GROUP_ID,CTV_SYNC_INTERVAL_NO);
      Trace::put(szTemp,-1,true);
      return;
   }
   for (CTV_SEQUENCE_NO = 1;CTV_SEQUENCE_NO <= 7;++CTV_SEQUENCE_NO)
   {
      CTV_PERIOD_ID = pEntityGroup->getPERIOD_ID(CTV_SEQUENCE_NO);
      /* EXEC SQL
         INSERT INTO T_FIN_E_GROUP_ITEM
         (
            ENTITY_GROUP_ID,
            SEQUENCE_NO,
            PERIOD_ID
         )
         VALUES
         (
            :CTV_ENTITY_GROUP_ID,
            :CTV_SEQUENCE_NO,
            :CTV_PERIOD_ID
         ); */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 13;
      sqlstm.arrsiz = 3;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "insert into T_FIN_E_GROUP_ITEM (ENTITY_GROUP_ID,SEQUENC\
E_NO,PERIOD_ID) values (:b0,:b1,:b2)";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )28;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (         void  *)&CTV_ENTITY_GROUP_ID;
      sqlstm.sqhstl[0] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         void  *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned int  )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqhstv[1] = (         void  *)&CTV_SEQUENCE_NO;
      sqlstm.sqhstl[1] = (unsigned int  )sizeof(short);
      sqlstm.sqhsts[1] = (         int  )0;
      sqlstm.sqindv[1] = (         void  *)0;
      sqlstm.sqinds[1] = (         int  )0;
      sqlstm.sqharm[1] = (unsigned int  )0;
      sqlstm.sqadto[1] = (unsigned short )0;
      sqlstm.sqtdso[1] = (unsigned short )0;
      sqlstm.sqhstv[2] = (         void  *)&CTV_PERIOD_ID;
      sqlstm.sqhstl[2] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[2] = (         int  )0;
      sqlstm.sqindv[2] = (         void  *)0;
      sqlstm.sqinds[2] = (         int  )0;
      sqlstm.sqharm[2] = (unsigned int  )0;
      sqlstm.sqadto[2] = (unsigned short )0;
      sqlstm.sqtdso[2] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


      if (!checkResult())
      {
         char szTemp[128];
         snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_E_GROUP_ITEM %ld %hd %ld",CTV_ENTITY_GROUP_ID,CTV_SEQUENCE_NO,CTV_PERIOD_ID);
         Trace::put(szTemp,-1,true);
         return;
      }
   }
  //## end dnoracledatabase::OracleCheckpointTotalsVisitor::visitEntityGroup%44493417001F.body
}

void OracleCheckpointTotalsVisitor::visitRecoveryPoint (RecoveryPoint* pRecoveryPoint)
{
  //## begin dnoracledatabase::OracleCheckpointTotalsVisitor::visitRecoveryPoint%44493417002E.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   memcpy(CTV_CONTEXT_KEY + 5,pRecoveryPoint->getInterval().data(),pRecoveryPoint->getInterval().length());
   CTV_CONTEXT_KEY[pRecoveryPoint->getInterval().length() + 5] = '\0';
   snprintf(CTV_CONTEXT_DATA,sizeof(CTV_CONTEXT_DATA),"%d:%d",pRecoveryPoint->getStartTime(),pRecoveryPoint->getEndTime());
   if (pRecoveryPoint->getState() == PersistentObject::NEW)
   {
      m_strDBAccess = "INSERT";
      /* EXEC SQL
         INSERT INTO TASK_CONTEXT
            (
               IMAGEID,
               TASKID,
               CONTEXT_TYPE,
               CONTEXT_KEY,
               CONTEXT_DATA
            )
            VALUES
            (
               :CTV_IMAGEID,
               :CTV_TASKID,
               :CTV_CONTEXT_TYPE,
               :CTV_CONTEXT_KEY,
               :CTV_CONTEXT_DATA
            ); */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 13;
      sqlstm.arrsiz = 5;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "insert into TASK_CONTEXT (IMAGEID,TASKID,CONTEXT_TYPE,C\
ONTEXT_KEY,CONTEXT_DATA) values (:b0,:b1,:b2,:b3,:b4)";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )55;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (         void  *)CTV_IMAGEID;
      sqlstm.sqhstl[0] = (unsigned int  )5;
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         void  *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned int  )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqhstv[1] = (         void  *)CTV_TASKID;
      sqlstm.sqhstl[1] = (unsigned int  )8;
      sqlstm.sqhsts[1] = (         int  )0;
      sqlstm.sqindv[1] = (         void  *)0;
      sqlstm.sqinds[1] = (         int  )0;
      sqlstm.sqharm[1] = (unsigned int  )0;
      sqlstm.sqadto[1] = (unsigned short )0;
      sqlstm.sqtdso[1] = (unsigned short )0;
      sqlstm.sqhstv[2] = (         void  *)CTV_CONTEXT_TYPE;
      sqlstm.sqhstl[2] = (unsigned int  )2;
      sqlstm.sqhsts[2] = (         int  )0;
      sqlstm.sqindv[2] = (         void  *)0;
      sqlstm.sqinds[2] = (         int  )0;
      sqlstm.sqharm[2] = (unsigned int  )0;
      sqlstm.sqadto[2] = (unsigned short )0;
      sqlstm.sqtdso[2] = (unsigned short )0;
      sqlstm.sqhstv[3] = (         void  *)CTV_CONTEXT_KEY;
      sqlstm.sqhstl[3] = (unsigned int  )33;
      sqlstm.sqhsts[3] = (         int  )0;
      sqlstm.sqindv[3] = (         void  *)0;
      sqlstm.sqinds[3] = (         int  )0;
      sqlstm.sqharm[3] = (unsigned int  )0;
      sqlstm.sqadto[3] = (unsigned short )0;
      sqlstm.sqtdso[3] = (unsigned short )0;
      sqlstm.sqhstv[4] = (         void  *)CTV_CONTEXT_DATA;
      sqlstm.sqhstl[4] = (unsigned int  )101;
      sqlstm.sqhsts[4] = (         int  )0;
      sqlstm.sqindv[4] = (         void  *)0;
      sqlstm.sqinds[4] = (         int  )0;
      sqlstm.sqharm[4] = (unsigned int  )0;
      sqlstm.sqadto[4] = (unsigned short )0;
      sqlstm.sqtdso[4] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   }
   else
   {
      m_strDBAccess = "UPDATE";
      /* EXEC SQL
         UPDATE TASK_CONTEXT
            SET
               CONTEXT_DATA = :CTV_CONTEXT_DATA
            WHERE
               IMAGEID = :CTV_IMAGEID
               AND TASKID = :CTV_TASKID
               AND CONTEXT_TYPE = :CTV_CONTEXT_TYPE
               AND CONTEXT_KEY = :CTV_CONTEXT_KEY; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 13;
      sqlstm.arrsiz = 5;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "update TASK_CONTEXT  set CONTEXT_DATA=:b0 where (((IMAG\
EID=:b1 and TASKID=:b2) and CONTEXT_TYPE=:b3) and CONTEXT_KEY=:b4)";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )90;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (         void  *)CTV_CONTEXT_DATA;
      sqlstm.sqhstl[0] = (unsigned int  )101;
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         void  *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned int  )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqhstv[1] = (         void  *)CTV_IMAGEID;
      sqlstm.sqhstl[1] = (unsigned int  )5;
      sqlstm.sqhsts[1] = (         int  )0;
      sqlstm.sqindv[1] = (         void  *)0;
      sqlstm.sqinds[1] = (         int  )0;
      sqlstm.sqharm[1] = (unsigned int  )0;
      sqlstm.sqadto[1] = (unsigned short )0;
      sqlstm.sqtdso[1] = (unsigned short )0;
      sqlstm.sqhstv[2] = (         void  *)CTV_TASKID;
      sqlstm.sqhstl[2] = (unsigned int  )8;
      sqlstm.sqhsts[2] = (         int  )0;
      sqlstm.sqindv[2] = (         void  *)0;
      sqlstm.sqinds[2] = (         int  )0;
      sqlstm.sqharm[2] = (unsigned int  )0;
      sqlstm.sqadto[2] = (unsigned short )0;
      sqlstm.sqtdso[2] = (unsigned short )0;
      sqlstm.sqhstv[3] = (         void  *)CTV_CONTEXT_TYPE;
      sqlstm.sqhstl[3] = (unsigned int  )2;
      sqlstm.sqhsts[3] = (         int  )0;
      sqlstm.sqindv[3] = (         void  *)0;
      sqlstm.sqinds[3] = (         int  )0;
      sqlstm.sqharm[3] = (unsigned int  )0;
      sqlstm.sqadto[3] = (unsigned short )0;
      sqlstm.sqtdso[3] = (unsigned short )0;
      sqlstm.sqhstv[4] = (         void  *)CTV_CONTEXT_KEY;
      sqlstm.sqhstl[4] = (unsigned int  )33;
      sqlstm.sqhsts[4] = (         int  )0;
      sqlstm.sqindv[4] = (         void  *)0;
      sqlstm.sqinds[4] = (         int  )0;
      sqlstm.sqharm[4] = (unsigned int  )0;
      sqlstm.sqadto[4] = (unsigned short )0;
      sqlstm.sqtdso[4] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   }
   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"%s TASK_CONTEXT %s %s %s %s %s",m_strDBAccess.c_str(),
         CTV_IMAGEID,CTV_TASKID,CTV_CONTEXT_TYPE,CTV_CONTEXT_KEY,CTV_CONTEXT_DATA);
      Trace::put(szTemp,-1,true);
      return;
   }
  //## end dnoracledatabase::OracleCheckpointTotalsVisitor::visitRecoveryPoint%44493417002E.body
}

void OracleCheckpointTotalsVisitor::visitReportingEntity (ReportingEntity* pReportingEntity)
{
  //## begin dnoracledatabase::OracleCheckpointTotalsVisitor::visitReportingEntity%44493417003E.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   m_lT_FIN_ENTITY_ID = pReportingEntity->getT_FIN_ENTITY_ID();
   if (pReportingEntity->getState() != PersistentObject::NEW)
      return;
   CTV_T_FIN_ENTITY_ID = pReportingEntity->getT_FIN_ENTITY_ID();
   memcpy(CTV_ENTITY_TYPE,pReportingEntity->getENTITY_TYPE().data(),pReportingEntity->getENTITY_TYPE().length());
   CTV_ENTITY_TYPE[pReportingEntity->getENTITY_TYPE().length()] = '\0';
   if (pReportingEntity->getENTITY_ID().length() == 0)
   {
      memcpy(CTV_ENTITY_ID," ",1);
      CTV_ENTITY_ID[1] = '\0';
   }
   else
   {
      memcpy(CTV_ENTITY_ID,pReportingEntity->getENTITY_ID().data(),pReportingEntity->getENTITY_ID().length());
      CTV_ENTITY_ID[pReportingEntity->getENTITY_ID().length()] = '\0';
   }
   m_strDBAccess = "INSERT";
   /* EXEC SQL
      INSERT INTO T_FIN_ENTITY
      (
         T_FIN_ENTITY_ID,
         ENTITY_TYPE,
         ENTITY_ID
      )
      VALUES
      (
         :CTV_T_FIN_ENTITY_ID,
         :CTV_ENTITY_TYPE,
         :CTV_ENTITY_ID
      ); */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 13;
   sqlstm.arrsiz = 5;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "insert into T_FIN_ENTITY (T_FIN_ENTITY_ID,ENTITY_TYPE,ENTI\
TY_ID) values (:b0,:b1,:b2)";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )125;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (         void  *)&CTV_T_FIN_ENTITY_ID;
   sqlstm.sqhstl[0] = (unsigned int  )sizeof(int);
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         void  *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned int  )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (         void  *)CTV_ENTITY_TYPE;
   sqlstm.sqhstl[1] = (unsigned int  )3;
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         void  *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned int  )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqhstv[2] = (         void  *)CTV_ENTITY_ID;
   sqlstm.sqhstl[2] = (unsigned int  )29;
   sqlstm.sqhsts[2] = (         int  )0;
   sqlstm.sqindv[2] = (         void  *)0;
   sqlstm.sqinds[2] = (         int  )0;
   sqlstm.sqharm[2] = (unsigned int  )0;
   sqlstm.sqadto[2] = (unsigned short )0;
   sqlstm.sqtdso[2] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_ENTITY %ld %s %s",CTV_T_FIN_ENTITY_ID,CTV_ENTITY_TYPE,CTV_ENTITY_ID);
      Trace::put(szTemp,-1,true);
      return;
   }
  //## end dnoracledatabase::OracleCheckpointTotalsVisitor::visitReportingEntity%44493417003E.body
}

void OracleCheckpointTotalsVisitor::visitReportingPeriod (ReportingPeriod* pReportingPeriod)
{
  //## begin dnoracledatabase::OracleCheckpointTotalsVisitor::visitReportingPeriod%44493417004E.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   if (pReportingPeriod->getState() == ReportingPeriod::SAVED)
      return;
   CTV_PERIOD_ID = pReportingPeriod->getPERIOD_ID();
   CTV_T_FIN_ENTITY_ID = m_lT_FIN_ENTITY_ID;
   char szSpace[2] = {" "};
   if (!pReportingPeriod->getTSTAMP_END().empty())
   {
      memcpy(CTV_TSTAMP_END,pReportingPeriod->getTSTAMP_END().data(),pReportingPeriod->getTSTAMP_END().length());
      CTV_TSTAMP_END[pReportingPeriod->getTSTAMP_END().length()] = '\0';
   }
   else
      memcpy(CTV_TSTAMP_END,szSpace,2);
   if (!pReportingPeriod->getTSTAMP_TRANS_FROM().empty())
   {
      memcpy(CTV_TSTAMP_TRANS_FROM,pReportingPeriod->getTSTAMP_TRANS_FROM().data(),pReportingPeriod->getTSTAMP_TRANS_FROM().length());
      CTV_TSTAMP_TRANS_FROM[pReportingPeriod->getTSTAMP_TRANS_FROM().length()] = '\0';
   }
   else
      memcpy(CTV_TSTAMP_TRANS_FROM,szSpace,2);
   if (!pReportingPeriod->getTSTAMP_TRANS_TO().empty())
   {
      memcpy(CTV_TSTAMP_TRANS_TO,pReportingPeriod->getTSTAMP_TRANS_TO().data(),pReportingPeriod->getTSTAMP_TRANS_TO().length());
      CTV_TSTAMP_TRANS_TO[pReportingPeriod->getTSTAMP_TRANS_TO().length()] = '\0';
   }
   else
      memcpy(CTV_TSTAMP_TRANS_TO,szSpace,2);
   if (!pReportingPeriod->getDATE_RECON().empty())
   {
      memcpy(CTV_DATE_RECON,pReportingPeriod->getDATE_RECON().data(),pReportingPeriod->getDATE_RECON().length());
      CTV_DATE_RECON[pReportingPeriod->getDATE_RECON().length()] = '\0';
   }
   else
      memcpy(CTV_DATE_RECON,szSpace,2);
   if (!pReportingPeriod->getTSTAMP_LAST_UPDATE().empty())
   {
      memcpy(CTV_TSTAMP_LAST_UPDATED,pReportingPeriod->getTSTAMP_LAST_UPDATE().data(),pReportingPeriod->getTSTAMP_LAST_UPDATE().length());
      CTV_TSTAMP_LAST_UPDATED[pReportingPeriod->getTSTAMP_LAST_UPDATE().length()] = '\0';
   }
   else
      memcpy(CTV_TSTAMP_LAST_UPDATED,szSpace,2);
   m_strDBAccess = "INSERT";
   if (pReportingPeriod->getState() == ReportingPeriod::NEW)
   {
      /* EXEC SQL
         INSERT INTO T_FIN_PERIOD
         (
            PERIOD_ID,
            T_FIN_ENTITY_ID,
            TSTAMP_END,
            TSTAMP_TRANS_FROM,
            TSTAMP_TRANS_TO,
            DATE_RECON,
            TSTAMP_LAST_UPDATE
         )
         VALUES
         (
            :CTV_PERIOD_ID,
            :CTV_T_FIN_ENTITY_ID,
            :CTV_TSTAMP_END,
            :CTV_TSTAMP_TRANS_FROM,
            :CTV_TSTAMP_TRANS_TO,
            :CTV_DATE_RECON,
            :CTV_TSTAMP_LAST_UPDATED
         ); */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 13;
      sqlstm.arrsiz = 7;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "insert into T_FIN_PERIOD (PERIOD_ID,T_FIN_ENTITY_ID,TST\
AMP_END,TSTAMP_TRANS_FROM,TSTAMP_TRANS_TO,DATE_RECON,TSTAMP_LAST_UPDATE) value\
s (:b0,:b1,:b2,:b3,:b4,:b5,:b6)";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )152;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (         void  *)&CTV_PERIOD_ID;
      sqlstm.sqhstl[0] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         void  *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned int  )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqhstv[1] = (         void  *)&CTV_T_FIN_ENTITY_ID;
      sqlstm.sqhstl[1] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[1] = (         int  )0;
      sqlstm.sqindv[1] = (         void  *)0;
      sqlstm.sqinds[1] = (         int  )0;
      sqlstm.sqharm[1] = (unsigned int  )0;
      sqlstm.sqadto[1] = (unsigned short )0;
      sqlstm.sqtdso[1] = (unsigned short )0;
      sqlstm.sqhstv[2] = (         void  *)CTV_TSTAMP_END;
      sqlstm.sqhstl[2] = (unsigned int  )17;
      sqlstm.sqhsts[2] = (         int  )0;
      sqlstm.sqindv[2] = (         void  *)0;
      sqlstm.sqinds[2] = (         int  )0;
      sqlstm.sqharm[2] = (unsigned int  )0;
      sqlstm.sqadto[2] = (unsigned short )0;
      sqlstm.sqtdso[2] = (unsigned short )0;
      sqlstm.sqhstv[3] = (         void  *)CTV_TSTAMP_TRANS_FROM;
      sqlstm.sqhstl[3] = (unsigned int  )17;
      sqlstm.sqhsts[3] = (         int  )0;
      sqlstm.sqindv[3] = (         void  *)0;
      sqlstm.sqinds[3] = (         int  )0;
      sqlstm.sqharm[3] = (unsigned int  )0;
      sqlstm.sqadto[3] = (unsigned short )0;
      sqlstm.sqtdso[3] = (unsigned short )0;
      sqlstm.sqhstv[4] = (         void  *)CTV_TSTAMP_TRANS_TO;
      sqlstm.sqhstl[4] = (unsigned int  )17;
      sqlstm.sqhsts[4] = (         int  )0;
      sqlstm.sqindv[4] = (         void  *)0;
      sqlstm.sqinds[4] = (         int  )0;
      sqlstm.sqharm[4] = (unsigned int  )0;
      sqlstm.sqadto[4] = (unsigned short )0;
      sqlstm.sqtdso[4] = (unsigned short )0;
      sqlstm.sqhstv[5] = (         void  *)CTV_DATE_RECON;
      sqlstm.sqhstl[5] = (unsigned int  )9;
      sqlstm.sqhsts[5] = (         int  )0;
      sqlstm.sqindv[5] = (         void  *)0;
      sqlstm.sqinds[5] = (         int  )0;
      sqlstm.sqharm[5] = (unsigned int  )0;
      sqlstm.sqadto[5] = (unsigned short )0;
      sqlstm.sqtdso[5] = (unsigned short )0;
      sqlstm.sqhstv[6] = (         void  *)CTV_TSTAMP_LAST_UPDATED;
      sqlstm.sqhstl[6] = (unsigned int  )17;
      sqlstm.sqhsts[6] = (         int  )0;
      sqlstm.sqindv[6] = (         void  *)0;
      sqlstm.sqinds[6] = (         int  )0;
      sqlstm.sqharm[6] = (unsigned int  )0;
      sqlstm.sqadto[6] = (unsigned short )0;
      sqlstm.sqtdso[6] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   }
   else
   {
      m_strDBAccess = "UPDATE";
      /* EXEC SQL
         UPDATE T_FIN_PERIOD
            SET
               TSTAMP_END = :CTV_TSTAMP_END,
               TSTAMP_TRANS_FROM = :CTV_TSTAMP_TRANS_FROM,
               TSTAMP_TRANS_TO = :CTV_TSTAMP_TRANS_TO,
               DATE_RECON = :CTV_DATE_RECON,
               TSTAMP_LAST_UPDATE = :CTV_TSTAMP_LAST_UPDATED
            WHERE
               PERIOD_ID = :CTV_PERIOD_ID; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 13;
      sqlstm.arrsiz = 7;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "update T_FIN_PERIOD  set TSTAMP_END=:b0,TSTAMP_TRANS_FR\
OM=:b1,TSTAMP_TRANS_TO=:b2,DATE_RECON=:b3,TSTAMP_LAST_UPDATE=:b4 where PERIOD_\
ID=:b5";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )195;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (         void  *)CTV_TSTAMP_END;
      sqlstm.sqhstl[0] = (unsigned int  )17;
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         void  *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned int  )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqhstv[1] = (         void  *)CTV_TSTAMP_TRANS_FROM;
      sqlstm.sqhstl[1] = (unsigned int  )17;
      sqlstm.sqhsts[1] = (         int  )0;
      sqlstm.sqindv[1] = (         void  *)0;
      sqlstm.sqinds[1] = (         int  )0;
      sqlstm.sqharm[1] = (unsigned int  )0;
      sqlstm.sqadto[1] = (unsigned short )0;
      sqlstm.sqtdso[1] = (unsigned short )0;
      sqlstm.sqhstv[2] = (         void  *)CTV_TSTAMP_TRANS_TO;
      sqlstm.sqhstl[2] = (unsigned int  )17;
      sqlstm.sqhsts[2] = (         int  )0;
      sqlstm.sqindv[2] = (         void  *)0;
      sqlstm.sqinds[2] = (         int  )0;
      sqlstm.sqharm[2] = (unsigned int  )0;
      sqlstm.sqadto[2] = (unsigned short )0;
      sqlstm.sqtdso[2] = (unsigned short )0;
      sqlstm.sqhstv[3] = (         void  *)CTV_DATE_RECON;
      sqlstm.sqhstl[3] = (unsigned int  )9;
      sqlstm.sqhsts[3] = (         int  )0;
      sqlstm.sqindv[3] = (         void  *)0;
      sqlstm.sqinds[3] = (         int  )0;
      sqlstm.sqharm[3] = (unsigned int  )0;
      sqlstm.sqadto[3] = (unsigned short )0;
      sqlstm.sqtdso[3] = (unsigned short )0;
      sqlstm.sqhstv[4] = (         void  *)CTV_TSTAMP_LAST_UPDATED;
      sqlstm.sqhstl[4] = (unsigned int  )17;
      sqlstm.sqhsts[4] = (         int  )0;
      sqlstm.sqindv[4] = (         void  *)0;
      sqlstm.sqinds[4] = (         int  )0;
      sqlstm.sqharm[4] = (unsigned int  )0;
      sqlstm.sqadto[4] = (unsigned short )0;
      sqlstm.sqtdso[4] = (unsigned short )0;
      sqlstm.sqhstv[5] = (         void  *)&CTV_PERIOD_ID;
      sqlstm.sqhstl[5] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[5] = (         int  )0;
      sqlstm.sqindv[5] = (         void  *)0;
      sqlstm.sqinds[5] = (         int  )0;
      sqlstm.sqharm[5] = (unsigned int  )0;
      sqlstm.sqadto[5] = (unsigned short )0;
      sqlstm.sqtdso[5] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   }
   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"%s T_FIN_PERIOD %ld %ld %s %s %s %s %s",m_strDBAccess.c_str(),
         CTV_PERIOD_ID,CTV_T_FIN_ENTITY_ID,CTV_TSTAMP_END,CTV_TSTAMP_TRANS_FROM,CTV_TSTAMP_TRANS_TO,CTV_DATE_RECON,CTV_TSTAMP_LAST_UPDATE);
      Trace::put(szTemp,-1,true);
      return;
   }
   pReportingPeriod->setState(ReportingPeriod::SAVED);
  //## end dnoracledatabase::OracleCheckpointTotalsVisitor::visitReportingPeriod%44493417004E.body
}

void OracleCheckpointTotalsVisitor::visitTotal (Total* pTotal)
{
  //## begin dnoracledatabase::OracleCheckpointTotalsVisitor::visitTotal%44493417005D.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   CTV_CATEGORY_ID = pTotal->getCATEGORY_ID();
   CTV_ENTITY_GROUP_ID = pTotal->getENTITY_GROUP_ID();
   CTV_TRAN_COUNT = pTotal->getTRAN_COUNT();;
   CTV_AMT_RECON_NET = pTotal->getAMT_RECON_NET();
   CTV_AMT_TRAN = pTotal->getAMT_TRAN();
   CTV_AMT_CARD_BILL = pTotal->getAMT_CARD_BILL();
   CTV_AMT_RECON_ACQ = pTotal->getAMT_RECON_ACQ();
   CTV_AMT_RECON_ISS = pTotal->getAMT_RECON_ISS();
   memcpy(CTV_TSTAMP_LAST_UPDATE,Clock::instance()->getYYYYMMDDHHMMSS().data(),14);
   CTV_TSTAMP_LAST_UPDATE[14] = '\0';
   m_strDBAccess = "UPDATE";
   /* EXEC SQL
      UPDATE T_FIN_TOTAL
         SET
            TRAN_COUNT = TRAN_COUNT + :CTV_TRAN_COUNT,
            AMT_RECON_NET = AMT_RECON_NET + :CTV_AMT_RECON_NET,
            AMT_TRAN = AMT_TRAN + :CTV_AMT_TRAN,
            AMT_CARD_BILL = AMT_CARD_BILL + :CTV_AMT_CARD_BILL,
            AMT_RECON_ACQ = AMT_RECON_ACQ + :CTV_AMT_RECON_ACQ,
            AMT_RECON_ISS = AMT_RECON_ISS + :CTV_AMT_RECON_ISS,
            TSTAMP_LAST_UPDATE = :CTV_TSTAMP_LAST_UPDATE
         WHERE
            CATEGORY_ID = :CTV_CATEGORY_ID
            AND ENTITY_GROUP_ID = :CTV_ENTITY_GROUP_ID; */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 13;
   sqlstm.arrsiz = 9;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "update T_FIN_TOTAL  set TRAN_COUNT=(TRAN_COUNT+:b0),AMT_RE\
CON_NET=(AMT_RECON_NET+:b1),AMT_TRAN=(AMT_TRAN+:b2),AMT_CARD_BILL=(AMT_CARD_BI\
LL+:b3),AMT_RECON_ACQ=(AMT_RECON_ACQ+:b4),AMT_RECON_ISS=(AMT_RECON_ISS+:b5),TS\
TAMP_LAST_UPDATE=:b6 where (CATEGORY_ID=:b7 and ENTITY_GROUP_ID=:b8)";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )234;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (         void  *)&CTV_TRAN_COUNT;
   sqlstm.sqhstl[0] = (unsigned int  )sizeof(int);
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         void  *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned int  )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (         void  *)&CTV_AMT_RECON_NET;
   sqlstm.sqhstl[1] = (unsigned int  )sizeof(double);
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         void  *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned int  )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqhstv[2] = (         void  *)&CTV_AMT_TRAN;
   sqlstm.sqhstl[2] = (unsigned int  )sizeof(double);
   sqlstm.sqhsts[2] = (         int  )0;
   sqlstm.sqindv[2] = (         void  *)0;
   sqlstm.sqinds[2] = (         int  )0;
   sqlstm.sqharm[2] = (unsigned int  )0;
   sqlstm.sqadto[2] = (unsigned short )0;
   sqlstm.sqtdso[2] = (unsigned short )0;
   sqlstm.sqhstv[3] = (         void  *)&CTV_AMT_CARD_BILL;
   sqlstm.sqhstl[3] = (unsigned int  )sizeof(double);
   sqlstm.sqhsts[3] = (         int  )0;
   sqlstm.sqindv[3] = (         void  *)0;
   sqlstm.sqinds[3] = (         int  )0;
   sqlstm.sqharm[3] = (unsigned int  )0;
   sqlstm.sqadto[3] = (unsigned short )0;
   sqlstm.sqtdso[3] = (unsigned short )0;
   sqlstm.sqhstv[4] = (         void  *)&CTV_AMT_RECON_ACQ;
   sqlstm.sqhstl[4] = (unsigned int  )sizeof(double);
   sqlstm.sqhsts[4] = (         int  )0;
   sqlstm.sqindv[4] = (         void  *)0;
   sqlstm.sqinds[4] = (         int  )0;
   sqlstm.sqharm[4] = (unsigned int  )0;
   sqlstm.sqadto[4] = (unsigned short )0;
   sqlstm.sqtdso[4] = (unsigned short )0;
   sqlstm.sqhstv[5] = (         void  *)&CTV_AMT_RECON_ISS;
   sqlstm.sqhstl[5] = (unsigned int  )sizeof(double);
   sqlstm.sqhsts[5] = (         int  )0;
   sqlstm.sqindv[5] = (         void  *)0;
   sqlstm.sqinds[5] = (         int  )0;
   sqlstm.sqharm[5] = (unsigned int  )0;
   sqlstm.sqadto[5] = (unsigned short )0;
   sqlstm.sqtdso[5] = (unsigned short )0;
   sqlstm.sqhstv[6] = (         void  *)CTV_TSTAMP_LAST_UPDATE;
   sqlstm.sqhstl[6] = (unsigned int  )15;
   sqlstm.sqhsts[6] = (         int  )0;
   sqlstm.sqindv[6] = (         void  *)0;
   sqlstm.sqinds[6] = (         int  )0;
   sqlstm.sqharm[6] = (unsigned int  )0;
   sqlstm.sqadto[6] = (unsigned short )0;
   sqlstm.sqtdso[6] = (unsigned short )0;
   sqlstm.sqhstv[7] = (         void  *)&CTV_CATEGORY_ID;
   sqlstm.sqhstl[7] = (unsigned int  )sizeof(int);
   sqlstm.sqhsts[7] = (         int  )0;
   sqlstm.sqindv[7] = (         void  *)0;
   sqlstm.sqinds[7] = (         int  )0;
   sqlstm.sqharm[7] = (unsigned int  )0;
   sqlstm.sqadto[7] = (unsigned short )0;
   sqlstm.sqtdso[7] = (unsigned short )0;
   sqlstm.sqhstv[8] = (         void  *)&CTV_ENTITY_GROUP_ID;
   sqlstm.sqhstl[8] = (unsigned int  )sizeof(int);
   sqlstm.sqhsts[8] = (         int  )0;
   sqlstm.sqindv[8] = (         void  *)0;
   sqlstm.sqinds[8] = (         int  )0;
   sqlstm.sqharm[8] = (unsigned int  )0;
   sqlstm.sqadto[8] = (unsigned short )0;
   sqlstm.sqtdso[8] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   if (sqlca.sqlcode == 100 || sqlca.sqlcode == 1403)
   {
      m_strDBAccess = "INSERT";
      /* EXEC SQL
         INSERT INTO T_FIN_TOTAL
         (
            CATEGORY_ID,
            ENTITY_GROUP_ID,
            TRAN_COUNT,
            AMT_RECON_NET,
            AMT_TRAN,
            AMT_CARD_BILL,
            AMT_RECON_ACQ,
            AMT_RECON_ISS,
            TSTAMP_LAST_UPDATE
         )
         VALUES
         (
            :CTV_CATEGORY_ID,
            :CTV_ENTITY_GROUP_ID,
            :CTV_TRAN_COUNT,
            :CTV_AMT_RECON_NET,
            :CTV_AMT_TRAN,
            :CTV_AMT_CARD_BILL,
            :CTV_AMT_RECON_ACQ,
            :CTV_AMT_RECON_ISS,
            :CTV_TSTAMP_LAST_UPDATE
         ); */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 13;
      sqlstm.arrsiz = 9;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "insert into T_FIN_TOTAL (CATEGORY_ID,ENTITY_GROUP_ID,TR\
AN_COUNT,AMT_RECON_NET,AMT_TRAN,AMT_CARD_BILL,AMT_RECON_ACQ,AMT_RECON_ISS,TSTA\
MP_LAST_UPDATE) values (:b0,:b1,:b2,:b3,:b4,:b5,:b6,:b7,:b8)";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )285;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (         void  *)&CTV_CATEGORY_ID;
      sqlstm.sqhstl[0] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         void  *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned int  )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqhstv[1] = (         void  *)&CTV_ENTITY_GROUP_ID;
      sqlstm.sqhstl[1] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[1] = (         int  )0;
      sqlstm.sqindv[1] = (         void  *)0;
      sqlstm.sqinds[1] = (         int  )0;
      sqlstm.sqharm[1] = (unsigned int  )0;
      sqlstm.sqadto[1] = (unsigned short )0;
      sqlstm.sqtdso[1] = (unsigned short )0;
      sqlstm.sqhstv[2] = (         void  *)&CTV_TRAN_COUNT;
      sqlstm.sqhstl[2] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[2] = (         int  )0;
      sqlstm.sqindv[2] = (         void  *)0;
      sqlstm.sqinds[2] = (         int  )0;
      sqlstm.sqharm[2] = (unsigned int  )0;
      sqlstm.sqadto[2] = (unsigned short )0;
      sqlstm.sqtdso[2] = (unsigned short )0;
      sqlstm.sqhstv[3] = (         void  *)&CTV_AMT_RECON_NET;
      sqlstm.sqhstl[3] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[3] = (         int  )0;
      sqlstm.sqindv[3] = (         void  *)0;
      sqlstm.sqinds[3] = (         int  )0;
      sqlstm.sqharm[3] = (unsigned int  )0;
      sqlstm.sqadto[3] = (unsigned short )0;
      sqlstm.sqtdso[3] = (unsigned short )0;
      sqlstm.sqhstv[4] = (         void  *)&CTV_AMT_TRAN;
      sqlstm.sqhstl[4] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[4] = (         int  )0;
      sqlstm.sqindv[4] = (         void  *)0;
      sqlstm.sqinds[4] = (         int  )0;
      sqlstm.sqharm[4] = (unsigned int  )0;
      sqlstm.sqadto[4] = (unsigned short )0;
      sqlstm.sqtdso[4] = (unsigned short )0;
      sqlstm.sqhstv[5] = (         void  *)&CTV_AMT_CARD_BILL;
      sqlstm.sqhstl[5] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[5] = (         int  )0;
      sqlstm.sqindv[5] = (         void  *)0;
      sqlstm.sqinds[5] = (         int  )0;
      sqlstm.sqharm[5] = (unsigned int  )0;
      sqlstm.sqadto[5] = (unsigned short )0;
      sqlstm.sqtdso[5] = (unsigned short )0;
      sqlstm.sqhstv[6] = (         void  *)&CTV_AMT_RECON_ACQ;
      sqlstm.sqhstl[6] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[6] = (         int  )0;
      sqlstm.sqindv[6] = (         void  *)0;
      sqlstm.sqinds[6] = (         int  )0;
      sqlstm.sqharm[6] = (unsigned int  )0;
      sqlstm.sqadto[6] = (unsigned short )0;
      sqlstm.sqtdso[6] = (unsigned short )0;
      sqlstm.sqhstv[7] = (         void  *)&CTV_AMT_RECON_ISS;
      sqlstm.sqhstl[7] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[7] = (         int  )0;
      sqlstm.sqindv[7] = (         void  *)0;
      sqlstm.sqinds[7] = (         int  )0;
      sqlstm.sqharm[7] = (unsigned int  )0;
      sqlstm.sqadto[7] = (unsigned short )0;
      sqlstm.sqtdso[7] = (unsigned short )0;
      sqlstm.sqhstv[8] = (         void  *)CTV_TSTAMP_LAST_UPDATE;
      sqlstm.sqhstl[8] = (unsigned int  )15;
      sqlstm.sqhsts[8] = (         int  )0;
      sqlstm.sqindv[8] = (         void  *)0;
      sqlstm.sqinds[8] = (         int  )0;
      sqlstm.sqharm[8] = (unsigned int  )0;
      sqlstm.sqadto[8] = (unsigned short )0;
      sqlstm.sqtdso[8] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   }
   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"%s T_FIN_TOTAL %ld %ld %ld %f %f %f %f %f %s",
         m_strDBAccess.c_str(),CTV_CATEGORY_ID,CTV_ENTITY_GROUP_ID,CTV_TRAN_COUNT,
         CTV_AMT_RECON_NET,CTV_AMT_TRAN,CTV_AMT_CARD_BILL,CTV_AMT_RECON_ACQ,
         CTV_AMT_RECON_ISS,CTV_TSTAMP_LAST_UPDATE);
      Trace::put(szTemp,-1,true);
   }
  //## end dnoracledatabase::OracleCheckpointTotalsVisitor::visitTotal%44493417005D.body
}

void OracleCheckpointTotalsVisitor::visitTotalsCategory (TotalsCategory* pTotalsCategory)
{
  //## begin dnoracledatabase::OracleCheckpointTotalsVisitor::visitTotalsCategory%44493417006D.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   CTV_CATEGORY_ID = pTotalsCategory->getCATEGORY_ID();
   char szSpace[2] = {" "};
   if (!pTotalsCategory->getNET_ID_ACQ().empty())
   {
      memcpy(CTV_NET_ID_ACQ,pTotalsCategory->getNET_ID_ACQ().data(),pTotalsCategory->getNET_ID_ACQ().length());
      CTV_NET_ID_ACQ[pTotalsCategory->getNET_ID_ACQ().length()] = '\0';
   }
   else
      memcpy(CTV_NET_ID_ACQ,szSpace,2);
   if (!pTotalsCategory->getNET_ID_ISS().empty())
   {
      memcpy(CTV_NET_ID_ISS,pTotalsCategory->getNET_ID_ISS().data(),pTotalsCategory->getNET_ID_ISS().length());
      CTV_NET_ID_ISS[pTotalsCategory->getNET_ID_ISS().length()] = '\0';
   }
   else
      memcpy(CTV_NET_ID_ISS,szSpace,2);
   if (!pTotalsCategory->getFIN_TYPE().empty())
   {
      memcpy(CTV_FIN_TYPE,pTotalsCategory->getFIN_TYPE().data(),pTotalsCategory->getFIN_TYPE().length());
      CTV_FIN_TYPE[pTotalsCategory->getFIN_TYPE().length()] = '\0';
   }
   else
      memcpy(CTV_FIN_TYPE,szSpace,2);
   if (!pTotalsCategory->getTRAN_TYPE_ID().empty())
   {
      memcpy(CTV_TRAN_TYPE_ID,pTotalsCategory->getTRAN_TYPE_ID().data(),pTotalsCategory->getTRAN_TYPE_ID().length());
      CTV_TRAN_TYPE_ID[pTotalsCategory->getTRAN_TYPE_ID().length()] = '\0';
   }
   else
      memcpy(CTV_TRAN_TYPE_ID,szSpace,2);
   if (!pTotalsCategory->getACT_CODE().empty())
   {
      memcpy(CTV_ACT_CODE,pTotalsCategory->getACT_CODE().data(),pTotalsCategory->getACT_CODE().length());
      CTV_ACT_CODE[pTotalsCategory->getACT_CODE().length()] = '\0';
   }
   else
      memcpy(CTV_ACT_CODE,szSpace,2);
   if (!pTotalsCategory->getFUNC_CODE().empty())
   {
      memcpy(CTV_FUNC_CODE,pTotalsCategory->getFUNC_CODE().data(),pTotalsCategory->getFUNC_CODE().length());
      CTV_FUNC_CODE[pTotalsCategory->getFUNC_CODE().length()] = '\0';
   }
   else
      memcpy(CTV_FUNC_CODE,szSpace,2);
   if (!pTotalsCategory->getAUTH_BY().empty())
   {
      memcpy(CTV_AUTH_BY,pTotalsCategory->getAUTH_BY().data(),pTotalsCategory->getAUTH_BY().length());
      CTV_AUTH_BY[pTotalsCategory->getAUTH_BY().length()] = '\0';
   }
   else
      memcpy(CTV_AUTH_BY,szSpace,2);
   if (!pTotalsCategory->getREV_BY().empty())
   {
      memcpy(CTV_REV_BY,pTotalsCategory->getREV_BY().data(),pTotalsCategory->getREV_BY().length());
      CTV_REV_BY[pTotalsCategory->getREV_BY().length()] = '\0';
   }
   else
      memcpy(CTV_REV_BY,szSpace,2);
   if (!pTotalsCategory->getCUR_RECON_NET().empty())
   {
      memcpy(CTV_CUR_RECON_NET,pTotalsCategory->getCUR_RECON_NET().data(),pTotalsCategory->getCUR_RECON_NET().length());
      CTV_CUR_RECON_NET[pTotalsCategory->getCUR_RECON_NET().length()] = '\0';
   }
   else
      memcpy(CTV_CUR_RECON_NET,szSpace,2);
   if (!pTotalsCategory->getCUR_TRAN().empty())
   {
      memcpy(CTV_CUR_TRAN,pTotalsCategory->getCUR_TRAN().data(),pTotalsCategory->getCUR_TRAN().length());
      CTV_CUR_TRAN[pTotalsCategory->getCUR_TRAN().length()] = '\0';
   }
   else
      memcpy(CTV_CUR_TRAN,szSpace,2);
   if (!pTotalsCategory->getCUR_CARD_BILL().empty())
   {
      memcpy(CTV_CUR_CARD_BILL,pTotalsCategory->getCUR_CARD_BILL().data(),pTotalsCategory->getCUR_CARD_BILL().length());
      CTV_CUR_CARD_BILL[pTotalsCategory->getCUR_CARD_BILL().length()] = '\0';
   }
   else
      memcpy(CTV_CUR_CARD_BILL,szSpace,2);
   if (!pTotalsCategory->getCUR_RECON_ACQ().empty())
   {
      memcpy(CTV_CUR_RECON_ACQ,pTotalsCategory->getCUR_RECON_ACQ().data(),pTotalsCategory->getCUR_RECON_ACQ().length());
      CTV_CUR_RECON_ACQ[pTotalsCategory->getCUR_RECON_ACQ().length()] = '\0';
   }
   else
      memcpy(CTV_CUR_RECON_ACQ,szSpace,2);
   if (!pTotalsCategory->getCUR_RECON_ISS().empty())
   {
      memcpy(CTV_CUR_RECON_ISS,pTotalsCategory->getCUR_RECON_ISS().data(),pTotalsCategory->getCUR_RECON_ISS().length());
      CTV_CUR_RECON_ISS[pTotalsCategory->getCUR_RECON_ISS().length()] = '\0';
   }
   else
      memcpy(CTV_CUR_RECON_ISS,szSpace,2);
   if (!pTotalsCategory->getIMPACT_TO_ACQ().empty())
   {
      memcpy(CTV_IMPACT_TO_ACQ,pTotalsCategory->getIMPACT_TO_ACQ().data(),pTotalsCategory->getIMPACT_TO_ACQ().length());
      CTV_IMPACT_TO_ACQ[pTotalsCategory->getIMPACT_TO_ACQ().length()] = '\0';
   }
   else
      memcpy(CTV_IMPACT_TO_ACQ,szSpace,2);
   if (!pTotalsCategory->getIMPACT_TO_ISS().empty())
   {
      memcpy(CTV_IMPACT_TO_ISS,pTotalsCategory->getIMPACT_TO_ISS().data(),pTotalsCategory->getIMPACT_TO_ISS().length());
      CTV_IMPACT_TO_ISS[pTotalsCategory->getIMPACT_TO_ISS().length()] = '\0';
   }
   else
      memcpy(CTV_IMPACT_TO_ISS,szSpace,2);
   if (!pTotalsCategory->getTRAN_DISPOSITION().empty())
   {
      memcpy(CTV_TRAN_DISPOSITION,pTotalsCategory->getTRAN_DISPOSITION().data(),pTotalsCategory->getTRAN_DISPOSITION().length());
      CTV_TRAN_DISPOSITION[pTotalsCategory->getTRAN_DISPOSITION().length()] = '\0';
   }
   else
      memcpy(CTV_TRAN_DISPOSITION,szSpace,2);
   if (!pTotalsCategory->getTOTAL_TYPE().empty())
   {
      memcpy(CTV_TOTAL_TYPE,pTotalsCategory->getTOTAL_TYPE().data(),pTotalsCategory->getTOTAL_TYPE().length());
      CTV_TOTAL_TYPE[pTotalsCategory->getTOTAL_TYPE().length()] = '\0';
   }
   else
      memcpy(CTV_TOTAL_TYPE,szSpace,2);
   if (!pTotalsCategory->getTRAN_CLASS().empty())
   {
      memcpy(CTV_TRAN_CLASS,pTotalsCategory->getTRAN_CLASS().data(),pTotalsCategory->getTRAN_CLASS().length());
      CTV_TRAN_CLASS[pTotalsCategory->getTRAN_CLASS().length()] = '\0';
   }
   else
      memcpy(CTV_TRAN_CLASS,szSpace,2);
   if (!pTotalsCategory->getMERCH_TYPE().empty())
   {
      memcpy(CTV_MERCH_TYPE,pTotalsCategory->getMERCH_TYPE().data(),pTotalsCategory->getMERCH_TYPE().length());
      CTV_MERCH_TYPE[pTotalsCategory->getMERCH_TYPE().length()] = '\0';
   }
   else
      memcpy(CTV_MERCH_TYPE,szSpace,2);
   if (!pTotalsCategory->getNETWORK_PROGRAM().empty())
   {
      memcpy(CTV_NETWORK_PROGRAM,pTotalsCategory->getNETWORK_PROGRAM().data(),pTotalsCategory->getNETWORK_PROGRAM().length());
      CTV_NETWORK_PROGRAM[pTotalsCategory->getNETWORK_PROGRAM().length()] = '\0';
   }
   else
      memcpy(CTV_NETWORK_PROGRAM,szSpace,2);
   m_strDBAccess = "INSERT";
   /* EXEC SQL
      INSERT INTO T_FIN_CATEGORY
      (
         CATEGORY_ID,
         NET_ID_ACQ,
         NET_ID_ISS,
         FIN_TYPE,
         TRAN_TYPE_ID,
         ACT_CODE,
         FUNC_CODE,
         AUTH_BY,
         REV_BY,
         CUR_RECON_NET,
         CUR_TRAN,
         CUR_CARD_BILL,
         CUR_RECON_ACQ,
         CUR_RECON_ISS,
         IMPACT_TO_ACQ,
         IMPACT_TO_ISS,
         TRAN_DISPOSITION,
         TOTAL_TYPE,
         TRAN_CLASS,
         MERCH_TYPE,
         NETWORK_PROGRAM
      )
      VALUES
      (
         :CTV_CATEGORY_ID,
         :CTV_NET_ID_ACQ,
         :CTV_NET_ID_ISS,
         :CTV_FIN_TYPE,
         :CTV_TRAN_TYPE_ID,
         :CTV_ACT_CODE,
         :CTV_FUNC_CODE,
         :CTV_AUTH_BY,
         :CTV_REV_BY,
         :CTV_CUR_RECON_NET,
         :CTV_CUR_TRAN,
         :CTV_CUR_CARD_BILL,
         :CTV_CUR_RECON_ACQ,
         :CTV_CUR_RECON_ISS,
         :CTV_IMPACT_TO_ACQ,
         :CTV_IMPACT_TO_ISS,
         :CTV_TRAN_DISPOSITION,
         :CTV_TOTAL_TYPE,
         :CTV_TRAN_CLASS,
         :CTV_MERCH_TYPE,
         :CTV_NETWORK_PROGRAM
      ); */ 

{
   struct sqlexd sqlstm;
   sqlstm.sqlvsn = 13;
   sqlstm.arrsiz = 21;
   sqlstm.sqladtp = &sqladt;
   sqlstm.sqltdsp = &sqltds;
   sqlstm.stmt = "insert into T_FIN_CATEGORY (CATEGORY_ID,NET_ID_ACQ,NET_ID_\
ISS,FIN_TYPE,TRAN_TYPE_ID,ACT_CODE,FUNC_CODE,AUTH_BY,REV_BY,CUR_RECON_NET,CUR_\
TRAN,CUR_CARD_BILL,CUR_RECON_ACQ,CUR_RECON_ISS,IMPACT_TO_ACQ,IMPACT_TO_ISS,TRA\
N_DISPOSITION,TOTAL_TYPE,TRAN_CLASS,MERCH_TYPE,NETWORK_PROGRAM) values (:b0,:b\
1,:b2,:b3,:b4,:b5,:b6,:b7,:b8,:b9,:b10,:b11,:b12,:b13,:b14,:b15,:b16,:b17,:b18\
,:b19,:b20)";
   sqlstm.iters = (unsigned int  )1;
   sqlstm.offset = (unsigned int  )336;
   sqlstm.cud = sqlcud0;
   sqlstm.sqlest = (unsigned char  *)&sqlca;
   sqlstm.sqlety = (unsigned short)4352;
   sqlstm.occurs = (unsigned int  )0;
   sqlstm.sqhstv[0] = (         void  *)&CTV_CATEGORY_ID;
   sqlstm.sqhstl[0] = (unsigned int  )sizeof(int);
   sqlstm.sqhsts[0] = (         int  )0;
   sqlstm.sqindv[0] = (         void  *)0;
   sqlstm.sqinds[0] = (         int  )0;
   sqlstm.sqharm[0] = (unsigned int  )0;
   sqlstm.sqadto[0] = (unsigned short )0;
   sqlstm.sqtdso[0] = (unsigned short )0;
   sqlstm.sqhstv[1] = (         void  *)CTV_NET_ID_ACQ;
   sqlstm.sqhstl[1] = (unsigned int  )4;
   sqlstm.sqhsts[1] = (         int  )0;
   sqlstm.sqindv[1] = (         void  *)0;
   sqlstm.sqinds[1] = (         int  )0;
   sqlstm.sqharm[1] = (unsigned int  )0;
   sqlstm.sqadto[1] = (unsigned short )0;
   sqlstm.sqtdso[1] = (unsigned short )0;
   sqlstm.sqhstv[2] = (         void  *)CTV_NET_ID_ISS;
   sqlstm.sqhstl[2] = (unsigned int  )4;
   sqlstm.sqhsts[2] = (         int  )0;
   sqlstm.sqindv[2] = (         void  *)0;
   sqlstm.sqinds[2] = (         int  )0;
   sqlstm.sqharm[2] = (unsigned int  )0;
   sqlstm.sqadto[2] = (unsigned short )0;
   sqlstm.sqtdso[2] = (unsigned short )0;
   sqlstm.sqhstv[3] = (         void  *)CTV_FIN_TYPE;
   sqlstm.sqhstl[3] = (unsigned int  )4;
   sqlstm.sqhsts[3] = (         int  )0;
   sqlstm.sqindv[3] = (         void  *)0;
   sqlstm.sqinds[3] = (         int  )0;
   sqlstm.sqharm[3] = (unsigned int  )0;
   sqlstm.sqadto[3] = (unsigned short )0;
   sqlstm.sqtdso[3] = (unsigned short )0;
   sqlstm.sqhstv[4] = (         void  *)CTV_TRAN_TYPE_ID;
   sqlstm.sqhstl[4] = (unsigned int  )11;
   sqlstm.sqhsts[4] = (         int  )0;
   sqlstm.sqindv[4] = (         void  *)0;
   sqlstm.sqinds[4] = (         int  )0;
   sqlstm.sqharm[4] = (unsigned int  )0;
   sqlstm.sqadto[4] = (unsigned short )0;
   sqlstm.sqtdso[4] = (unsigned short )0;
   sqlstm.sqhstv[5] = (         void  *)CTV_ACT_CODE;
   sqlstm.sqhstl[5] = (unsigned int  )4;
   sqlstm.sqhsts[5] = (         int  )0;
   sqlstm.sqindv[5] = (         void  *)0;
   sqlstm.sqinds[5] = (         int  )0;
   sqlstm.sqharm[5] = (unsigned int  )0;
   sqlstm.sqadto[5] = (unsigned short )0;
   sqlstm.sqtdso[5] = (unsigned short )0;
   sqlstm.sqhstv[6] = (         void  *)CTV_FUNC_CODE;
   sqlstm.sqhstl[6] = (unsigned int  )4;
   sqlstm.sqhsts[6] = (         int  )0;
   sqlstm.sqindv[6] = (         void  *)0;
   sqlstm.sqinds[6] = (         int  )0;
   sqlstm.sqharm[6] = (unsigned int  )0;
   sqlstm.sqadto[6] = (unsigned short )0;
   sqlstm.sqtdso[6] = (unsigned short )0;
   sqlstm.sqhstv[7] = (         void  *)CTV_AUTH_BY;
   sqlstm.sqhstl[7] = (unsigned int  )2;
   sqlstm.sqhsts[7] = (         int  )0;
   sqlstm.sqindv[7] = (         void  *)0;
   sqlstm.sqinds[7] = (         int  )0;
   sqlstm.sqharm[7] = (unsigned int  )0;
   sqlstm.sqadto[7] = (unsigned short )0;
   sqlstm.sqtdso[7] = (unsigned short )0;
   sqlstm.sqhstv[8] = (         void  *)CTV_REV_BY;
   sqlstm.sqhstl[8] = (unsigned int  )2;
   sqlstm.sqhsts[8] = (         int  )0;
   sqlstm.sqindv[8] = (         void  *)0;
   sqlstm.sqinds[8] = (         int  )0;
   sqlstm.sqharm[8] = (unsigned int  )0;
   sqlstm.sqadto[8] = (unsigned short )0;
   sqlstm.sqtdso[8] = (unsigned short )0;
   sqlstm.sqhstv[9] = (         void  *)CTV_CUR_RECON_NET;
   sqlstm.sqhstl[9] = (unsigned int  )4;
   sqlstm.sqhsts[9] = (         int  )0;
   sqlstm.sqindv[9] = (         void  *)0;
   sqlstm.sqinds[9] = (         int  )0;
   sqlstm.sqharm[9] = (unsigned int  )0;
   sqlstm.sqadto[9] = (unsigned short )0;
   sqlstm.sqtdso[9] = (unsigned short )0;
   sqlstm.sqhstv[10] = (         void  *)CTV_CUR_TRAN;
   sqlstm.sqhstl[10] = (unsigned int  )4;
   sqlstm.sqhsts[10] = (         int  )0;
   sqlstm.sqindv[10] = (         void  *)0;
   sqlstm.sqinds[10] = (         int  )0;
   sqlstm.sqharm[10] = (unsigned int  )0;
   sqlstm.sqadto[10] = (unsigned short )0;
   sqlstm.sqtdso[10] = (unsigned short )0;
   sqlstm.sqhstv[11] = (         void  *)CTV_CUR_CARD_BILL;
   sqlstm.sqhstl[11] = (unsigned int  )4;
   sqlstm.sqhsts[11] = (         int  )0;
   sqlstm.sqindv[11] = (         void  *)0;
   sqlstm.sqinds[11] = (         int  )0;
   sqlstm.sqharm[11] = (unsigned int  )0;
   sqlstm.sqadto[11] = (unsigned short )0;
   sqlstm.sqtdso[11] = (unsigned short )0;
   sqlstm.sqhstv[12] = (         void  *)CTV_CUR_RECON_ACQ;
   sqlstm.sqhstl[12] = (unsigned int  )4;
   sqlstm.sqhsts[12] = (         int  )0;
   sqlstm.sqindv[12] = (         void  *)0;
   sqlstm.sqinds[12] = (         int  )0;
   sqlstm.sqharm[12] = (unsigned int  )0;
   sqlstm.sqadto[12] = (unsigned short )0;
   sqlstm.sqtdso[12] = (unsigned short )0;
   sqlstm.sqhstv[13] = (         void  *)CTV_CUR_RECON_ISS;
   sqlstm.sqhstl[13] = (unsigned int  )4;
   sqlstm.sqhsts[13] = (         int  )0;
   sqlstm.sqindv[13] = (         void  *)0;
   sqlstm.sqinds[13] = (         int  )0;
   sqlstm.sqharm[13] = (unsigned int  )0;
   sqlstm.sqadto[13] = (unsigned short )0;
   sqlstm.sqtdso[13] = (unsigned short )0;
   sqlstm.sqhstv[14] = (         void  *)CTV_IMPACT_TO_ACQ;
   sqlstm.sqhstl[14] = (unsigned int  )2;
   sqlstm.sqhsts[14] = (         int  )0;
   sqlstm.sqindv[14] = (         void  *)0;
   sqlstm.sqinds[14] = (         int  )0;
   sqlstm.sqharm[14] = (unsigned int  )0;
   sqlstm.sqadto[14] = (unsigned short )0;
   sqlstm.sqtdso[14] = (unsigned short )0;
   sqlstm.sqhstv[15] = (         void  *)CTV_IMPACT_TO_ISS;
   sqlstm.sqhstl[15] = (unsigned int  )2;
   sqlstm.sqhsts[15] = (         int  )0;
   sqlstm.sqindv[15] = (         void  *)0;
   sqlstm.sqinds[15] = (         int  )0;
   sqlstm.sqharm[15] = (unsigned int  )0;
   sqlstm.sqadto[15] = (unsigned short )0;
   sqlstm.sqtdso[15] = (unsigned short )0;
   sqlstm.sqhstv[16] = (         void  *)CTV_TRAN_DISPOSITION;
   sqlstm.sqhstl[16] = (unsigned int  )2;
   sqlstm.sqhsts[16] = (         int  )0;
   sqlstm.sqindv[16] = (         void  *)0;
   sqlstm.sqinds[16] = (         int  )0;
   sqlstm.sqharm[16] = (unsigned int  )0;
   sqlstm.sqadto[16] = (unsigned short )0;
   sqlstm.sqtdso[16] = (unsigned short )0;
   sqlstm.sqhstv[17] = (         void  *)CTV_TOTAL_TYPE;
   sqlstm.sqhstl[17] = (unsigned int  )5;
   sqlstm.sqhsts[17] = (         int  )0;
   sqlstm.sqindv[17] = (         void  *)0;
   sqlstm.sqinds[17] = (         int  )0;
   sqlstm.sqharm[17] = (unsigned int  )0;
   sqlstm.sqadto[17] = (unsigned short )0;
   sqlstm.sqtdso[17] = (unsigned short )0;
   sqlstm.sqhstv[18] = (         void  *)CTV_TRAN_CLASS;
   sqlstm.sqhstl[18] = (unsigned int  )4;
   sqlstm.sqhsts[18] = (         int  )0;
   sqlstm.sqindv[18] = (         void  *)0;
   sqlstm.sqinds[18] = (         int  )0;
   sqlstm.sqharm[18] = (unsigned int  )0;
   sqlstm.sqadto[18] = (unsigned short )0;
   sqlstm.sqtdso[18] = (unsigned short )0;
   sqlstm.sqhstv[19] = (         void  *)CTV_MERCH_TYPE;
   sqlstm.sqhstl[19] = (unsigned int  )5;
   sqlstm.sqhsts[19] = (         int  )0;
   sqlstm.sqindv[19] = (         void  *)0;
   sqlstm.sqinds[19] = (         int  )0;
   sqlstm.sqharm[19] = (unsigned int  )0;
   sqlstm.sqadto[19] = (unsigned short )0;
   sqlstm.sqtdso[19] = (unsigned short )0;
   sqlstm.sqhstv[20] = (         void  *)CTV_NETWORK_PROGRAM;
   sqlstm.sqhstl[20] = (unsigned int  )11;
   sqlstm.sqhsts[20] = (         int  )0;
   sqlstm.sqindv[20] = (         void  *)0;
   sqlstm.sqinds[20] = (         int  )0;
   sqlstm.sqharm[20] = (unsigned int  )0;
   sqlstm.sqadto[20] = (unsigned short )0;
   sqlstm.sqtdso[20] = (unsigned short )0;
   sqlstm.sqphsv = sqlstm.sqhstv;
   sqlstm.sqphsl = sqlstm.sqhstl;
   sqlstm.sqphss = sqlstm.sqhsts;
   sqlstm.sqpind = sqlstm.sqindv;
   sqlstm.sqpins = sqlstm.sqinds;
   sqlstm.sqparm = sqlstm.sqharm;
   sqlstm.sqparc = sqlstm.sqharc;
   sqlstm.sqpadto = sqlstm.sqadto;
   sqlstm.sqptdso = sqlstm.sqtdso;
   sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   if (!checkResult())
   {
      char szTemp[133];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_CATEGORY %ld %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
         CTV_CATEGORY_ID,CTV_NET_ID_ACQ,CTV_NET_ID_ISS,CTV_FIN_TYPE,CTV_TRAN_TYPE_ID,
         CTV_ACT_CODE,CTV_FUNC_CODE,CTV_AUTH_BY,CTV_REV_BY,CTV_CUR_RECON_NET,CTV_CUR_TRAN,
         CTV_CUR_CARD_BILL,CTV_CUR_RECON_ACQ,CTV_CUR_RECON_ISS,CTV_IMPACT_TO_ACQ,
         CTV_IMPACT_TO_ISS,CTV_TRAN_DISPOSITION,CTV_TOTAL_TYPE,CTV_TRAN_CLASS,CTV_MERCH_TYPE,CTV_NETWORK_PROGRAM);
      Trace::put(szTemp,-1,true);
      return;
   }
  //## end dnoracledatabase::OracleCheckpointTotalsVisitor::visitTotalsCategory%44493417006D.body
}

// Additional Declarations
  //## begin dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.declarations preserve=yes
  //## end dnoracledatabase::OracleCheckpointTotalsVisitor%4449173D004E.declarations

} // namespace dnoracledatabase

//## begin module%44492E4400FA.epilog preserve=yes
//## end module%44492E4400FA.epilog
