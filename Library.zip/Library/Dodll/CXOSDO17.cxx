
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[13];
};
static const struct sqlcxp sqlfpn =
{
    12,
    "CXOSDO17.sqx"
};


static unsigned int sqlctx = 306182;


static struct sqlexd {
   unsigned int   sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
            void  **sqphsv;
   unsigned int   *sqphsl;
            int   *sqphss;
            void  **sqpind;
            int   *sqpins;
   unsigned int   *sqparm;
   unsigned int   **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
              int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned int   sqlpfmem;
            void  *sqhstv[8];
   unsigned int   sqhstl[8];
            int   sqhsts[8];
            void  *sqindv[8];
            int   sqinds[8];
   unsigned int   sqharm[8];
   unsigned int   *sqharc[8];
   unsigned short  sqadto[8];
   unsigned short  sqtdso[8];
} sqlstm = {13,8};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(unsigned char *, signed int *); }

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{13,4130,178,8,0,
5,0,0,1,0,0,17,195,0,0,1,1,0,1,0,1,97,0,0,
24,0,0,1,0,0,21,199,0,0,8,8,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,
1,97,0,0,1,97,0,0,1,97,0,0,
};


//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%631062E10217.cm preserve=no
//## end module%631062E10217.cm

//## begin module%631062E10217.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%631062E10217.cp

//## Module: CXOSDO17%631062E10217; Package body
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Dodll\CXOSDO17.sqx

//## begin module%631062E10217.additionalIncludes preserve=no
//## end module%631062E10217.additionalIncludes

//## begin module%631062E10217.includes preserve=yes
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
//## end module%631062E10217.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSPO01_h
#include "CXODPO01.hpp"
#endif
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
#ifndef CXOSRU48_h
#include "CXODRU48.hpp"
#endif
#ifndef CXOSDO17_h
#include "CXODDO17.hpp"
#endif


//## begin module%631062E10217.declarations preserve=no
//## end module%631062E10217.declarations

//## begin module%631062E10217.additionalDeclarations preserve=yes
/* EXEC SQL BEGIN DECLARE SECTION; */ 

       char MIS_CARDHOLDER_PAN[512][29];
       char MIS_CARDHOLDER_INST_ID[512][12];
       char MIS_CARDHOLDER_YEAR_MONTH[512][7];
       char MIS_CARDHOLDER_BIN[512][12];
       char MIS_CARDHOLDER_MERGE[2048];
       int  MIS_CARDHOLDER_ROWS;
/* EXEC SQL DECLARE MIS_CARDHOLDER_STATEMENT STATEMENT; */ 

/* EXEC SQL END DECLARE SECTION; */ 

//## end module%631062E10217.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

// Class dnoracledatabase::OracleMISMonthlyCardHolder 

OracleMISMonthlyCardHolder::OracleMISMonthlyCardHolder()
  //## begin OracleMISMonthlyCardHolder::OracleMISMonthlyCardHolder%63106438036C_const.hasinit preserve=no
  //## end OracleMISMonthlyCardHolder::OracleMISMonthlyCardHolder%63106438036C_const.hasinit
  //## begin OracleMISMonthlyCardHolder::OracleMISMonthlyCardHolder%63106438036C_const.initialization preserve=yes
  //## end OracleMISMonthlyCardHolder::OracleMISMonthlyCardHolder%63106438036C_const.initialization
{
  //## begin dnoracledatabase::OracleMISMonthlyCardHolder::OracleMISMonthlyCardHolder%63106438036C_const.body preserve=yes
   memcpy(m_sID,"DO17",4);
   MIS_CARDHOLDER_ROWS =0;
   string strQualifier(Database::instance()->qualifier());
   memcpy(MIS_CARDHOLDER_MERGE,"MERGE INTO ",11);
   memcpy(MIS_CARDHOLDER_MERGE + 11,strQualifier.data(),strQualifier.length());
   strcpy(MIS_CARDHOLDER_MERGE + 11 + strQualifier.length(),".T_MIS_CARDHOLDER USING DUAL ON ("
          " PAN = ? AND INST_ID =? AND YEAR_MONTH = ? AND BIN = ?)"
          " WHEN NOT MATCHED THEN INSERT (PAN,INST_ID,YEAR_MONTH,BIN)"
          " VALUES (?,?,?,?)");
   int i = 0;
   size_t pos = 0;
   char szTemp[7];
   string strSQL(MIS_CARDHOLDER_MERGE);
   while ((pos = strSQL.find('?')) != string::npos)
      strSQL.replace(pos,1,szTemp,snprintf(szTemp,sizeof(szTemp),":p%d",1000 + i++));
   memcpy(MIS_CARDHOLDER_MERGE,strSQL.data(),strSQL.length());
  //## end dnoracledatabase::OracleMISMonthlyCardHolder::OracleMISMonthlyCardHolder%63106438036C_const.body
}


OracleMISMonthlyCardHolder::~OracleMISMonthlyCardHolder()
{
  //## begin dnoracledatabase::OracleMISMonthlyCardHolder::~OracleMISMonthlyCardHolder%63106438036C_dest.body preserve=yes
  //## end dnoracledatabase::OracleMISMonthlyCardHolder::~OracleMISMonthlyCardHolder%63106438036C_dest.body
}



//## Other Operations (implementation)
bool OracleMISMonthlyCardHolder::add (const FinancialTransaction& hFinancialTransaction)
{
  //## begin dnoracledatabase::OracleMISMonthlyCardHolder::add%6310651A0226.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return false;
   if (MIS_CARDHOLDER_ROWS >= 512)
      if (!commit())
         return false;
   string strBIN;
   if(hFinancialTransaction.getBIN_LENGTH() > 0)
      strBIN = hFinancialTransaction.getPAN().substr(0, hFinancialTransaction.getBIN_LENGTH());
   else
      strBIN = hFinancialTransaction.getPAN().substr(0, 6);
   string strPAN(hFinancialTransaction.getPAN());
   NPI::instance(2)->protect(strPAN);
   if(!hFinancialTransaction.getTSTAMP_TRANS().empty())
   {
      memcpy(MIS_CARDHOLDER_YEAR_MONTH[MIS_CARDHOLDER_ROWS],hFinancialTransaction.getTSTAMP_TRANS().data(),6);
      MIS_CARDHOLDER_YEAR_MONTH[MIS_CARDHOLDER_ROWS][6] = '\0';
   }
   else
      return true;
   if(!strPAN.empty())
   {
      memcpy(MIS_CARDHOLDER_PAN[MIS_CARDHOLDER_ROWS] ,strPAN.data(),strPAN.length());
      MIS_CARDHOLDER_PAN[MIS_CARDHOLDER_ROWS][strPAN.length()] = '\0';
      memcpy(MIS_CARDHOLDER_BIN[MIS_CARDHOLDER_ROWS] ,strBIN.data(),strBIN.length());
      MIS_CARDHOLDER_BIN[MIS_CARDHOLDER_ROWS][strBIN.length()] = '\0';
   }
   else
      return true;
   if(!hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).empty())
   {
       memcpy(MIS_CARDHOLDER_INST_ID[MIS_CARDHOLDER_ROWS] ,hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).data(),
              hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).length());
      MIS_CARDHOLDER_INST_ID[MIS_CARDHOLDER_ROWS][hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).length()] = '\0';
   }
   else
      return true;
   MIS_CARDHOLDER_ROWS++;
   return true;
  //## end dnoracledatabase::OracleMISMonthlyCardHolder::add%6310651A0226.body
}

int OracleMISMonthlyCardHolder::checkResult ()
{
  //## begin dnoracledatabase::OracleMISMonthlyCardHolder::checkResult%631065440263.body preserve=yes
   switch (sqlca.sqlcode)
   {
      case 0:
         UseCase::addItem();
         return 1;
      case 100:
      case 1403:
         return 0;
      case -51:
      case -54:
      case -99999913:
         UseCase::add("DEADLOCK");
         break;
      case -1012:
      case -2396:
      case -3113:
      case -3114:
      case -3135:
         UseCase::add("CONNECT");
         Database::instance()->setState(Database::DISCONNECTED);
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            Database::instance()->traceSQLError((void*)&sqlca,m_sID,"MERGE");
            UseCase::addItem();
            return 1;
         }
         else
            UseCase::add("DBERROR");
   }
   MIS_CARDHOLDER_ROWS = 0;
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca, m_sID,"MERGE");
   return -1;
  //## end dnoracledatabase::OracleMISMonthlyCardHolder::checkResult%631065440263.body
}

bool OracleMISMonthlyCardHolder::commit ()
{
  //## begin dnoracledatabase::OracleMISMonthlyCardHolder::commit%631065590200.body preserve=yes
  if(MIS_CARDHOLDER_ROWS ==0)
     return true;
  /* EXEC SQL PREPARE MIS_CARDHOLDER_STATEMENT FROM :MIS_CARDHOLDER_MERGE; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 13;
  sqlstm.arrsiz = 1;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )5;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)4352;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqhstv[0] = (         void  *)MIS_CARDHOLDER_MERGE;
  sqlstm.sqhstl[0] = (unsigned int  )2048;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


  int iRC= checkResult();
  if(iRC == -1)
     return false;
  /* EXEC SQL FOR :MIS_CARDHOLDER_ROWS 
     EXECUTE  MIS_CARDHOLDER_STATEMENT
     USING
          :MIS_CARDHOLDER_PAN,
          :MIS_CARDHOLDER_INST_ID,
          :MIS_CARDHOLDER_YEAR_MONTH,
          :MIS_CARDHOLDER_BIN,
          :MIS_CARDHOLDER_PAN,
          :MIS_CARDHOLDER_INST_ID,
          :MIS_CARDHOLDER_YEAR_MONTH,
          :MIS_CARDHOLDER_BIN; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 13;
  sqlstm.arrsiz = 8;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "";
  sqlstm.iters = (unsigned int  )MIS_CARDHOLDER_ROWS;
  sqlstm.offset = (unsigned int  )24;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)4352;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqhstv[0] = (         void  *)MIS_CARDHOLDER_PAN;
  sqlstm.sqhstl[0] = (unsigned int  )29;
  sqlstm.sqhsts[0] = (         int  )29;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqharc[0] = (unsigned int   *)0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (         void  *)MIS_CARDHOLDER_INST_ID;
  sqlstm.sqhstl[1] = (unsigned int  )12;
  sqlstm.sqhsts[1] = (         int  )12;
  sqlstm.sqindv[1] = (         void  *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned int  )0;
  sqlstm.sqharc[1] = (unsigned int   *)0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqhstv[2] = (         void  *)MIS_CARDHOLDER_YEAR_MONTH;
  sqlstm.sqhstl[2] = (unsigned int  )7;
  sqlstm.sqhsts[2] = (         int  )7;
  sqlstm.sqindv[2] = (         void  *)0;
  sqlstm.sqinds[2] = (         int  )0;
  sqlstm.sqharm[2] = (unsigned int  )0;
  sqlstm.sqharc[2] = (unsigned int   *)0;
  sqlstm.sqadto[2] = (unsigned short )0;
  sqlstm.sqtdso[2] = (unsigned short )0;
  sqlstm.sqhstv[3] = (         void  *)MIS_CARDHOLDER_BIN;
  sqlstm.sqhstl[3] = (unsigned int  )12;
  sqlstm.sqhsts[3] = (         int  )12;
  sqlstm.sqindv[3] = (         void  *)0;
  sqlstm.sqinds[3] = (         int  )0;
  sqlstm.sqharm[3] = (unsigned int  )0;
  sqlstm.sqharc[3] = (unsigned int   *)0;
  sqlstm.sqadto[3] = (unsigned short )0;
  sqlstm.sqtdso[3] = (unsigned short )0;
  sqlstm.sqhstv[4] = (         void  *)MIS_CARDHOLDER_PAN;
  sqlstm.sqhstl[4] = (unsigned int  )29;
  sqlstm.sqhsts[4] = (         int  )29;
  sqlstm.sqindv[4] = (         void  *)0;
  sqlstm.sqinds[4] = (         int  )0;
  sqlstm.sqharm[4] = (unsigned int  )0;
  sqlstm.sqharc[4] = (unsigned int   *)0;
  sqlstm.sqadto[4] = (unsigned short )0;
  sqlstm.sqtdso[4] = (unsigned short )0;
  sqlstm.sqhstv[5] = (         void  *)MIS_CARDHOLDER_INST_ID;
  sqlstm.sqhstl[5] = (unsigned int  )12;
  sqlstm.sqhsts[5] = (         int  )12;
  sqlstm.sqindv[5] = (         void  *)0;
  sqlstm.sqinds[5] = (         int  )0;
  sqlstm.sqharm[5] = (unsigned int  )0;
  sqlstm.sqharc[5] = (unsigned int   *)0;
  sqlstm.sqadto[5] = (unsigned short )0;
  sqlstm.sqtdso[5] = (unsigned short )0;
  sqlstm.sqhstv[6] = (         void  *)MIS_CARDHOLDER_YEAR_MONTH;
  sqlstm.sqhstl[6] = (unsigned int  )7;
  sqlstm.sqhsts[6] = (         int  )7;
  sqlstm.sqindv[6] = (         void  *)0;
  sqlstm.sqinds[6] = (         int  )0;
  sqlstm.sqharm[6] = (unsigned int  )0;
  sqlstm.sqharc[6] = (unsigned int   *)0;
  sqlstm.sqadto[6] = (unsigned short )0;
  sqlstm.sqtdso[6] = (unsigned short )0;
  sqlstm.sqhstv[7] = (         void  *)MIS_CARDHOLDER_BIN;
  sqlstm.sqhstl[7] = (unsigned int  )12;
  sqlstm.sqhsts[7] = (         int  )12;
  sqlstm.sqindv[7] = (         void  *)0;
  sqlstm.sqinds[7] = (         int  )0;
  sqlstm.sqharm[7] = (unsigned int  )0;
  sqlstm.sqharc[7] = (unsigned int   *)0;
  sqlstm.sqadto[7] = (unsigned short )0;
  sqlstm.sqtdso[7] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


  iRC= checkResult();
  if (iRC == -1)
  {
     char szTemp[4 * PERCENTLD];
     for (int i=0;i < MIS_CARDHOLDER_ROWS; i++)
     {
        snprintf(szTemp, sizeof(szTemp), "MERGE INTO  %s %s %s %s ",
          MIS_CARDHOLDER_PAN[i], MIS_CARDHOLDER_INST_ID[i],
          MIS_CARDHOLDER_YEAR_MONTH[i], MIS_CARDHOLDER_BIN[i]);
          Trace::put(szTemp);
     }
     return false;
   }    
   MIS_CARDHOLDER_ROWS = 0;
   Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   return true;
  //## end dnoracledatabase::OracleMISMonthlyCardHolder::commit%631065590200.body
}

void OracleMISMonthlyCardHolder::lockTables ()
{
  //## begin dnoracledatabase::OracleMISMonthlyCardHolder::lockTables%63106573004C.body preserve=yes
  //## end dnoracledatabase::OracleMISMonthlyCardHolder::lockTables%63106573004C.body
}

// Additional Declarations
  //## begin dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.declarations preserve=yes
  //## end dnoracledatabase::OracleMISMonthlyCardHolder%63106438036C.declarations

} // namespace dnoracledatabase

//## begin module%631062E10217.epilog preserve=yes
//## end module%631062E10217.epilog
