
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[13];
};
static const struct sqlcxp sqlfpn =
{
    12,
    "CXOSDO16.sqx"
};


static unsigned int sqlctx = 306166;


static struct sqlexd {
   unsigned int   sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
            void  **sqphsv;
   unsigned int   *sqphsl;
            int   *sqphss;
            void  **sqpind;
            int   *sqpins;
   unsigned int   *sqparm;
   unsigned int   **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
              int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned int   sqlpfmem;
            void  *sqhstv[10];
   unsigned int   sqhstl[10];
            int   sqhsts[10];
            void  *sqindv[10];
            int   sqinds[10];
   unsigned int   sqharm[10];
   unsigned int   *sqharc[10];
   unsigned short  sqadto[10];
   unsigned short  sqtdso[10];
} sqlstm = {13,10};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(unsigned char *, signed int *); }

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{13,4130,178,8,0,
5,0,0,1,0,0,17,223,0,0,1,1,0,1,0,1,97,0,0,
24,0,0,1,0,0,21,227,0,0,10,10,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,
0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,
};


//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6064094E026E.cm preserve=no
//## end module%6064094E026E.cm

//## begin module%6064094E026E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6064094E026E.cp

//## Module: CXOSDO16%6064094E026E; Package body
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Library\Dodll\CXOSDO16.sqx

//## begin module%6064094E026E.additionalIncludes preserve=no
//## end module%6064094E026E.additionalIncludes

//## begin module%6064094E026E.includes preserve=yes
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
//## end module%6064094E026E.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSPO01_h
#include "CXODPO01.hpp"
#endif
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
#ifndef CXOSCFB7_h
#include "CXODCFB7.hpp"
#endif
#ifndef CXOSRU48_h
#include "CXODRU48.hpp"
#endif
#ifndef CXOSDO16_h
#include "CXODDO16.hpp"
#endif


//## begin module%6064094E026E.declarations preserve=no
//## end module%6064094E026E.declarations

//## begin module%6064094E026E.additionalDeclarations preserve=yes
/* EXEC SQL BEGIN DECLARE SECTION; */ 

       char QMR_CARDHOLDER_PAN[512][29];
       char QMR_CARDHOLDER_INST_ID[512][12];
       char QMR_CARDHOLDER_NETWORK_ID[512][4];
       char QMR_CARDHOLDER_YEAR_MONTH[512][7];
       char QMR_CARDHOLDER_BIN[512][12];       
       char QMR_CARDHOLDER_MERGE[2048];
       int  QMR_CARDHOLDER_ROWS;
/* EXEC SQL DECLARE QMR_CARDHOLDER_STATEMENT STATEMENT; */ 

/* EXEC SQL END DECLARE SECTION; */ 

//## end module%6064094E026E.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

// Class dnoracledatabase::OracleMonthlyCardHolder 

OracleMonthlyCardHolder::OracleMonthlyCardHolder()
  //## begin OracleMonthlyCardHolder::OracleMonthlyCardHolder%60640BD3004E_const.hasinit preserve=no
  //## end OracleMonthlyCardHolder::OracleMonthlyCardHolder%60640BD3004E_const.hasinit
  //## begin OracleMonthlyCardHolder::OracleMonthlyCardHolder%60640BD3004E_const.initialization preserve=yes
  //## end OracleMonthlyCardHolder::OracleMonthlyCardHolder%60640BD3004E_const.initialization
{
  //## begin dnoracledatabase::OracleMonthlyCardHolder::OracleMonthlyCardHolder%60640BD3004E_const.body preserve=yes
   memcpy(m_sID,"DO16",4);
   QMR_CARDHOLDER_ROWS =0;
   string strQualifier(Database::instance()->qualifier());
   memcpy(QMR_CARDHOLDER_MERGE,"MERGE INTO ",11);
   memcpy(QMR_CARDHOLDER_MERGE + 11,strQualifier.data(),strQualifier.length());
   strcpy(QMR_CARDHOLDER_MERGE + 11 + strQualifier.length(),".T_QMR_CARDHOLDER USING DUAL ON ("
          " PAN = ? AND INST_ID =? AND NETWORK_ID = ? AND YEAR_MONTH = ? AND BIN = ?)"
          " WHEN NOT MATCHED THEN INSERT (PAN,INST_ID,NETWORK_ID,YEAR_MONTH,BIN)"
          " VALUES (?,?,?,?,?)");
     int i = 0;
     size_t pos = 0;
     char szTemp[7];
     string strSQL(QMR_CARDHOLDER_MERGE);
     while ((pos = strSQL.find('?')) != string::npos)
        strSQL.replace(pos,1,szTemp,snprintf(szTemp,sizeof(szTemp),":p%d",1000 + i++));
     memcpy(QMR_CARDHOLDER_MERGE,strSQL.data(),strSQL.length());
  //## end dnoracledatabase::OracleMonthlyCardHolder::OracleMonthlyCardHolder%60640BD3004E_const.body
}


OracleMonthlyCardHolder::~OracleMonthlyCardHolder()
{
  //## begin dnoracledatabase::OracleMonthlyCardHolder::~OracleMonthlyCardHolder%60640BD3004E_dest.body preserve=yes
  //## end dnoracledatabase::OracleMonthlyCardHolder::~OracleMonthlyCardHolder%60640BD3004E_dest.body
}



//## Other Operations (implementation)
bool OracleMonthlyCardHolder::add (const FinancialTransaction& hFinancialTransaction)
{
  //## begin dnoracledatabase::OracleMonthlyCardHolder::add%60641A030123.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return false;
   if (hFinancialTransaction.getTRAN_DISPOSITION() == "2" || hFinancialTransaction.getPAN().empty())
      return true;
   if (QMR_CARDHOLDER_ROWS >= 512)
      if (!commit())
         return false;
   int iBIN_LENGTH = hFinancialTransaction.getBIN_LENGTH();
   string strNETWORK_ID;
   string strBIN(hFinancialTransaction.getPAN().c_str(), 11);
   if (iBIN_LENGTH == 0 && QMRInstitution::getBinDetails(hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN)
      ,strBIN,iBIN_LENGTH,strNETWORK_ID) == false)
      iBIN_LENGTH = 6;
   strBIN.resize(iBIN_LENGTH);
   char szSpace[2] = {" "};
   string strPAN(hFinancialTransaction.getPAN());
   NPI::instance(2)->protect(strPAN);
   if(!hFinancialTransaction.getTSTAMP_TRANS().empty())
   {
      memcpy(QMR_CARDHOLDER_YEAR_MONTH[QMR_CARDHOLDER_ROWS],hFinancialTransaction.getTSTAMP_TRANS().data(),6);
      QMR_CARDHOLDER_YEAR_MONTH[QMR_CARDHOLDER_ROWS][6] = '\0';
   }
   else
       memcpy(QMR_CARDHOLDER_YEAR_MONTH[QMR_CARDHOLDER_ROWS],szSpace,2);
   if(!strPAN.empty())
   {
      memcpy(QMR_CARDHOLDER_PAN[QMR_CARDHOLDER_ROWS] ,strPAN.data(),strPAN.length());
      QMR_CARDHOLDER_PAN[QMR_CARDHOLDER_ROWS][strPAN.length()] = '\0';
   }
   else
      memcpy(QMR_CARDHOLDER_PAN[QMR_CARDHOLDER_ROWS],szSpace,2);
   if(!hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).empty())
   {
       memcpy(QMR_CARDHOLDER_INST_ID[QMR_CARDHOLDER_ROWS] ,hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).data(),
              hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).length());
      QMR_CARDHOLDER_INST_ID[QMR_CARDHOLDER_ROWS][hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).length()] = '\0';
   }
   else
      memcpy(QMR_CARDHOLDER_INST_ID[QMR_CARDHOLDER_ROWS],szSpace,2);
   if(!hFinancialTransaction.getNET_ID_ACQ().empty())
   {
      memcpy(QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS] ,hFinancialTransaction.getNET_ID_ACQ().data(),
              hFinancialTransaction.getNET_ID_ACQ().length());
      QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS][hFinancialTransaction.getNET_ID_ACQ().length()] = '\0';
   }
   else if (!strNETWORK_ID.empty())
   {
      memcpy(QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS], strNETWORK_ID.data(),strNETWORK_ID.length());
      QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS][strNETWORK_ID.length()] = '\0';
   }
   else
      memcpy(QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS],szSpace,2);
   if(!strBIN.empty())
   {
      memcpy(QMR_CARDHOLDER_BIN[QMR_CARDHOLDER_ROWS] ,strBIN.data(),
             strBIN.length());
      QMR_CARDHOLDER_BIN[QMR_CARDHOLDER_ROWS][strBIN.length()] = '\0';
   }
   else
      memcpy(QMR_CARDHOLDER_BIN[QMR_CARDHOLDER_ROWS],szSpace,2);
   QMR_CARDHOLDER_ROWS++;
   return true;
  //## end dnoracledatabase::OracleMonthlyCardHolder::add%60641A030123.body
}

int OracleMonthlyCardHolder::checkResult ()
{
  //## begin dnoracledatabase::OracleMonthlyCardHolder::checkResult%6064103402A7.body preserve=yes
     switch (sqlca.sqlcode)
   {
      case 0:
         UseCase::addItem();
         return 1;
      case 100:
      case 1403:
         return 0;
      case -51:
      case -54:
      case -99999913:
         UseCase::add("DEADLOCK");
         break;
      case -1012:
      case -2396:
      case -3113:
      case -3114:
      case -3135:
         UseCase::add("CONNECT");
         Database::instance()->setState(Database::DISCONNECTED);
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            Database::instance()->traceSQLError((void*)&sqlca,m_sID,"MERGE");
            UseCase::addItem();
            return 1;
         }
         else
            UseCase::add("DBERROR");
   }
   QMR_CARDHOLDER_ROWS = 0;
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca, m_sID,"MERGE");
   return -1;
  //## end dnoracledatabase::OracleMonthlyCardHolder::checkResult%6064103402A7.body
}

bool OracleMonthlyCardHolder::commit ()
{
  //## begin dnoracledatabase::OracleMonthlyCardHolder::commit%606410240261.body preserve=yes
  if(QMR_CARDHOLDER_ROWS ==0)
     return true;
  /* EXEC SQL PREPARE QMR_CARDHOLDER_STATEMENT FROM :QMR_CARDHOLDER_MERGE; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 13;
  sqlstm.arrsiz = 1;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )5;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)4352;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqhstv[0] = (         void  *)QMR_CARDHOLDER_MERGE;
  sqlstm.sqhstl[0] = (unsigned int  )2048;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


  int iRC= checkResult();
  if(iRC == -1)
     return false;
  /* EXEC SQL FOR :QMR_CARDHOLDER_ROWS 
     EXECUTE  QMR_CARDHOLDER_STATEMENT
     USING
          :QMR_CARDHOLDER_PAN,
          :QMR_CARDHOLDER_INST_ID,
          :QMR_CARDHOLDER_NETWORK_ID,
          :QMR_CARDHOLDER_YEAR_MONTH,
          :QMR_CARDHOLDER_BIN,
          :QMR_CARDHOLDER_PAN,
          :QMR_CARDHOLDER_INST_ID,
          :QMR_CARDHOLDER_NETWORK_ID,
          :QMR_CARDHOLDER_YEAR_MONTH,
          :QMR_CARDHOLDER_BIN; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 13;
  sqlstm.arrsiz = 10;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "";
  sqlstm.iters = (unsigned int  )QMR_CARDHOLDER_ROWS;
  sqlstm.offset = (unsigned int  )24;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)4352;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqhstv[0] = (         void  *)QMR_CARDHOLDER_PAN;
  sqlstm.sqhstl[0] = (unsigned int  )29;
  sqlstm.sqhsts[0] = (         int  )29;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqharc[0] = (unsigned int   *)0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (         void  *)QMR_CARDHOLDER_INST_ID;
  sqlstm.sqhstl[1] = (unsigned int  )12;
  sqlstm.sqhsts[1] = (         int  )12;
  sqlstm.sqindv[1] = (         void  *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned int  )0;
  sqlstm.sqharc[1] = (unsigned int   *)0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqhstv[2] = (         void  *)QMR_CARDHOLDER_NETWORK_ID;
  sqlstm.sqhstl[2] = (unsigned int  )4;
  sqlstm.sqhsts[2] = (         int  )4;
  sqlstm.sqindv[2] = (         void  *)0;
  sqlstm.sqinds[2] = (         int  )0;
  sqlstm.sqharm[2] = (unsigned int  )0;
  sqlstm.sqharc[2] = (unsigned int   *)0;
  sqlstm.sqadto[2] = (unsigned short )0;
  sqlstm.sqtdso[2] = (unsigned short )0;
  sqlstm.sqhstv[3] = (         void  *)QMR_CARDHOLDER_YEAR_MONTH;
  sqlstm.sqhstl[3] = (unsigned int  )7;
  sqlstm.sqhsts[3] = (         int  )7;
  sqlstm.sqindv[3] = (         void  *)0;
  sqlstm.sqinds[3] = (         int  )0;
  sqlstm.sqharm[3] = (unsigned int  )0;
  sqlstm.sqharc[3] = (unsigned int   *)0;
  sqlstm.sqadto[3] = (unsigned short )0;
  sqlstm.sqtdso[3] = (unsigned short )0;
  sqlstm.sqhstv[4] = (         void  *)QMR_CARDHOLDER_BIN;
  sqlstm.sqhstl[4] = (unsigned int  )12;
  sqlstm.sqhsts[4] = (         int  )12;
  sqlstm.sqindv[4] = (         void  *)0;
  sqlstm.sqinds[4] = (         int  )0;
  sqlstm.sqharm[4] = (unsigned int  )0;
  sqlstm.sqharc[4] = (unsigned int   *)0;
  sqlstm.sqadto[4] = (unsigned short )0;
  sqlstm.sqtdso[4] = (unsigned short )0;
  sqlstm.sqhstv[5] = (         void  *)QMR_CARDHOLDER_PAN;
  sqlstm.sqhstl[5] = (unsigned int  )29;
  sqlstm.sqhsts[5] = (         int  )29;
  sqlstm.sqindv[5] = (         void  *)0;
  sqlstm.sqinds[5] = (         int  )0;
  sqlstm.sqharm[5] = (unsigned int  )0;
  sqlstm.sqharc[5] = (unsigned int   *)0;
  sqlstm.sqadto[5] = (unsigned short )0;
  sqlstm.sqtdso[5] = (unsigned short )0;
  sqlstm.sqhstv[6] = (         void  *)QMR_CARDHOLDER_INST_ID;
  sqlstm.sqhstl[6] = (unsigned int  )12;
  sqlstm.sqhsts[6] = (         int  )12;
  sqlstm.sqindv[6] = (         void  *)0;
  sqlstm.sqinds[6] = (         int  )0;
  sqlstm.sqharm[6] = (unsigned int  )0;
  sqlstm.sqharc[6] = (unsigned int   *)0;
  sqlstm.sqadto[6] = (unsigned short )0;
  sqlstm.sqtdso[6] = (unsigned short )0;
  sqlstm.sqhstv[7] = (         void  *)QMR_CARDHOLDER_NETWORK_ID;
  sqlstm.sqhstl[7] = (unsigned int  )4;
  sqlstm.sqhsts[7] = (         int  )4;
  sqlstm.sqindv[7] = (         void  *)0;
  sqlstm.sqinds[7] = (         int  )0;
  sqlstm.sqharm[7] = (unsigned int  )0;
  sqlstm.sqharc[7] = (unsigned int   *)0;
  sqlstm.sqadto[7] = (unsigned short )0;
  sqlstm.sqtdso[7] = (unsigned short )0;
  sqlstm.sqhstv[8] = (         void  *)QMR_CARDHOLDER_YEAR_MONTH;
  sqlstm.sqhstl[8] = (unsigned int  )7;
  sqlstm.sqhsts[8] = (         int  )7;
  sqlstm.sqindv[8] = (         void  *)0;
  sqlstm.sqinds[8] = (         int  )0;
  sqlstm.sqharm[8] = (unsigned int  )0;
  sqlstm.sqharc[8] = (unsigned int   *)0;
  sqlstm.sqadto[8] = (unsigned short )0;
  sqlstm.sqtdso[8] = (unsigned short )0;
  sqlstm.sqhstv[9] = (         void  *)QMR_CARDHOLDER_BIN;
  sqlstm.sqhstl[9] = (unsigned int  )12;
  sqlstm.sqhsts[9] = (         int  )12;
  sqlstm.sqindv[9] = (         void  *)0;
  sqlstm.sqinds[9] = (         int  )0;
  sqlstm.sqharm[9] = (unsigned int  )0;
  sqlstm.sqharc[9] = (unsigned int   *)0;
  sqlstm.sqadto[9] = (unsigned short )0;
  sqlstm.sqtdso[9] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


  iRC= checkResult();
  if (iRC == -1)
  {
     char szTemp[5 * PERCENTLD + 7 * PERCENTF + 2 * PERCENTS];
     for (int i=0;i < QMR_CARDHOLDER_ROWS; i++)
     {
        snprintf(szTemp, sizeof(szTemp), "MERGE INTO  %s %s %s %s %s ",
          QMR_CARDHOLDER_PAN[i], QMR_CARDHOLDER_INST_ID[i],
          QMR_CARDHOLDER_NETWORK_ID[i], QMR_CARDHOLDER_YEAR_MONTH[i], 
          QMR_CARDHOLDER_BIN[i]);
          Trace::put(szTemp);
     }
     return false;
   }    
   QMR_CARDHOLDER_ROWS = 0;
   Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   return true;
  //## end dnoracledatabase::OracleMonthlyCardHolder::commit%606410240261.body
}

void OracleMonthlyCardHolder::lockTables ()
{
  //## begin dnoracledatabase::OracleMonthlyCardHolder::lockTables%6064103C019F.body preserve=yes
  //## end dnoracledatabase::OracleMonthlyCardHolder::lockTables%6064103C019F.body
}

// Additional Declarations
  //## begin dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.declarations preserve=yes
  //## end dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.declarations

} // namespace dnoracledatabase

//## begin module%6064094E026E.epilog preserve=yes
//## end module%6064094E026E.epilog
