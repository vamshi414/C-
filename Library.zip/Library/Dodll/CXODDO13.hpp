//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%44492F1503A9.cm preserve=no
//## end module%44492F1503A9.cm

//## begin module%44492F1503A9.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%44492F1503A9.cp

//## Module: CXOSDO13%44492F1503A9; Package specification
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Library\Dodll\CXODDO13.hpp

#ifndef CXOSDO13_h
#define CXOSDO13_h 1

//## begin module%44492F1503A9.additionalIncludes preserve=no
//## end module%44492F1503A9.additionalIncludes

//## begin module%44492F1503A9.includes preserve=yes
//## end module%44492F1503A9.includes

#ifndef CXOSST34_h
#include "CXODST34.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class FinancialTransaction;
class Accumulator;
} // namespace settlement

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::OracleDatabase_CAT%44141ACC02DE
namespace oracledatabase {
class OracleDatabase;

} // namespace oracledatabase

//## begin module%44492F1503A9.declarations preserve=no
//## end module%44492F1503A9.declarations

//## begin module%44492F1503A9.additionalDeclarations preserve=yes
//## end module%44492F1503A9.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

//## begin dnoracledatabase::OracleAggregatorMIS%444917190203.preface preserve=yes
//## end dnoracledatabase::OracleAggregatorMIS%444917190203.preface

//## Class: OracleAggregatorMIS%444917190203
//## Category: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
//## Subsystem: DODLL%444917C7035B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4449350F0000;database::Database { -> F}
//## Uses: <unnamed>%4449350F03C8;monitor::UseCase { -> F}
//## Uses: <unnamed>%4449351100FA;settlement::Accumulator { -> F}
//## Uses: <unnamed>%444935120232;settlement::FinancialTransaction { -> F}
//## Uses: <unnamed>%5AE36F530254;oracledatabase::OracleDatabase { -> F}

class DllExport OracleAggregatorMIS : public settlement::AggregatorMIS  //## Inherits: <unnamed>%4449350C0261
{
  //## begin dnoracledatabase::OracleAggregatorMIS%444917190203.initialDeclarations preserve=yes
  //## end dnoracledatabase::OracleAggregatorMIS%444917190203.initialDeclarations

  public:
    //## Constructors (generated)
      OracleAggregatorMIS();

    //## Destructor (generated)
      virtual ~OracleAggregatorMIS();


    //## Other Operations (specified)
      //## Operation: tableInsert%44493536036B
      virtual bool tableInsert (bool bSubtractFromTotals = false);

      //## Operation: tableUpdate%44493536037A
      virtual int tableUpdate (bool bSubtractFromTotals = false);

    // Additional Public Declarations
      //## begin dnoracledatabase::OracleAggregatorMIS%444917190203.public preserve=yes
      //## end dnoracledatabase::OracleAggregatorMIS%444917190203.public

  protected:
    // Additional Protected Declarations
      //## begin dnoracledatabase::OracleAggregatorMIS%444917190203.protected preserve=yes
      //## end dnoracledatabase::OracleAggregatorMIS%444917190203.protected

  private:

    //## Other Operations (specified)
      //## Operation: checkResult%44493536034B
      int checkResult ();

      //## Operation: lockTables%44493536035B
      void lockTables ();

    // Additional Private Declarations
      //## begin dnoracledatabase::OracleAggregatorMIS%444917190203.private preserve=yes
      //## end dnoracledatabase::OracleAggregatorMIS%444917190203.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DBAccess%51643BD40314
      //## begin dnoracledatabase::OracleAggregatorMIS::DBAccess%51643BD40314.attr preserve=no  private: string {U} 
      string m_strDBAccess;
      //## end dnoracledatabase::OracleAggregatorMIS::DBAccess%51643BD40314.attr

      //## Attribute: Transaction%4449352F0280
      //## begin dnoracledatabase::OracleAggregatorMIS::Transaction%4449352F0280.attr preserve=no  private: long {U} -1
      long m_lTransaction;
      //## end dnoracledatabase::OracleAggregatorMIS::Transaction%4449352F0280.attr

    // Additional Implementation Declarations
      //## begin dnoracledatabase::OracleAggregatorMIS%444917190203.implementation preserve=yes
      //## end dnoracledatabase::OracleAggregatorMIS%444917190203.implementation

};

//## begin dnoracledatabase::OracleAggregatorMIS%444917190203.postscript preserve=yes
//## end dnoracledatabase::OracleAggregatorMIS%444917190203.postscript

} // namespace dnoracledatabase

//## begin module%44492F1503A9.epilog preserve=yes
//## end module%44492F1503A9.epilog


#endif
