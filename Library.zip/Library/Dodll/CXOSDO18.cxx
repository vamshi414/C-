
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[13];
};
static const struct sqlcxp sqlfpn =
{
    12,
    "CXOSDO18.sqx"
};


static unsigned int sqlctx = 306198;


static struct sqlexd {
   unsigned int   sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
            void  **sqphsv;
   unsigned int   *sqphsl;
            int   *sqphss;
            void  **sqpind;
            int   *sqpins;
   unsigned int   *sqparm;
   unsigned int   **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
              int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned int   sqlpfmem;
            void  *sqhstv[33];
   unsigned int   sqhstl[33];
            int   sqhsts[33];
            void  *sqindv[33];
            int   sqinds[33];
   unsigned int   sqharm[33];
   unsigned int   *sqharc[33];
   unsigned short  sqadto[33];
   unsigned short  sqtdso[33];
} sqlstm = {13,33};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(unsigned char *, signed int *); }

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{13,4130,178,8,0,
5,0,0,1,0,0,17,274,0,0,1,1,0,1,0,1,97,0,0,
24,0,0,1,0,0,21,278,0,0,31,31,0,1,0,1,97,0,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,
1,3,0,0,1,97,0,0,1,4,0,0,1,4,0,0,1,4,0,0,1,4,0,0,1,3,0,0,1,4,0,0,1,4,0,0,1,4,0,
0,1,97,0,0,1,97,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,3,0,0,1,4,0,0,1,4,0,0,1,4,0,0,1,
4,0,0,1,3,0,0,1,4,0,0,1,4,0,0,1,4,0,0,1,3,0,0,1,97,0,0,
163,0,0,2,0,0,17,331,0,0,1,1,0,1,0,1,97,0,0,
182,0,0,2,0,0,21,335,0,0,33,33,0,1,0,1,97,0,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,
0,1,3,0,0,1,3,0,0,1,97,0,0,1,4,0,0,1,4,0,0,1,4,0,0,1,4,0,0,1,3,0,0,1,4,0,0,1,4,
0,0,1,4,0,0,1,97,0,0,1,97,0,0,1,3,0,0,1,3,0,0,1,97,0,0,1,3,0,0,1,3,0,0,1,4,0,0,
1,4,0,0,1,4,0,0,1,4,0,0,1,3,0,0,1,4,0,0,1,4,0,0,1,4,0,0,1,3,0,0,1,97,0,0,
};


//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%640A41A60044.cm preserve=no
//## end module%640A41A60044.cm

//## begin module%640A41A60044.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%640A41A60044.cp

//## Module: CXOSDO18%640A41A60044; Package body
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Library\Dodll\CXOSDO18.sqx

//## begin module%640A41A60044.additionalIncludes preserve=no
//## end module%640A41A60044.additionalIncludes

//## begin module%640A41A60044.includes preserve=yes
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSST03_h
#include "CXODST03.hpp"
#endif
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
#ifndef CXOSPO01_h
#include "CXODPO01.hpp"
#endif
#ifndef CXOSST08_h
#include "CXODST08.hpp"
#endif
//## end module%640A41A60044.includes

#ifndef CXOSDO18_h
#include "CXODDO18.hpp"
#endif
//## begin module%640A41A60044.declarations preserve=no
//## end module%640A41A60044.declarations

//## begin module%640A41A60044.additionalDeclarations preserve=yes
   /* EXEC SQL BEGIN DECLARE SECTION; */ 

   char AMS1_TSTAMP_START[512][11];
   char AMS1_INTERVAL_TYPE[512][2];
   int AMS1_T_FIN_ENTITY_ID[512];
   char AMS1_T_MIS_MCC[512][5];
   int AMS1_CATEGORY_ID[512];
   int AMS1_PARTITION_KEY[512];
   double AMS1_AMT_TRAN[512];
   double AMS1_AMT_SURCHARGE[512];
   double AMS1_AMT_POS_REIMBURSE[512];
   double AMS1_CASHBACK_AMT[512];
   int AMS1_TRAN_COUNT[512];
   double AMS1_TIME_AT_ISS[512];
   double AMS1_TIME_AT_RQST_SWTCH[512];
   double AMS1_AMT_FEE[512];
   int AMS1_SYNC_INTERVAL_NO[512];
   char AMS1_BIN[512][12];
   int AMS1_ROWS;
   char AMS1_MERGE[2048];
   /* EXEC SQL DECLARE AMS1_STATEMENT STATEMENT; */ 

   char AMS2_TSTAMP_START[512][11];
   char AMS2_INTERVAL_TYPE[512][2];
   int AMS2_T_FIN_ENTITY_ID[512];
   int AMS2_T_FIN_ENTITY_ID_2[512];
   char AMS2_T_MIS_MCC[512][5];
   int AMS2_CATEGORY_ID[512];
   int AMS2_PARTITION_KEY[512];
   double AMS2_AMT_TRAN[512];
   double AMS2_AMT_SURCHARGE[512];
   double AMS2_AMT_POS_REIMBURSE[512];
   double AMS2_CASHBACK_AMT[512];
   int AMS2_TRAN_COUNT[512];
   double AMS2_TIME_AT_ISS[512];
   double AMS2_TIME_AT_RQST_SWTCH[512];
   double AMS2_AMT_FEE[512];
   int AMS2_SYNC_INTERVAL_NO[512];
   char AMS2_BIN[512][12];
   int AMS2_ROWS;
   char AMS2_MERGE[2048];
   /* EXEC SQL DECLARE AMS2_STATEMENT STATEMENT; */ 

   /* EXEC SQL END DECLARE SECTION; */ 

//## end module%640A41A60044.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

// Class dnoracledatabase::OracleAggregatorMIS2 

OracleAggregatorMIS2::OracleAggregatorMIS2()
  //## begin OracleAggregatorMIS2::OracleAggregatorMIS2%640A409C00BC_const.hasinit preserve=no
      : m_iTransaction(-1)
  //## end OracleAggregatorMIS2::OracleAggregatorMIS2%640A409C00BC_const.hasinit
  //## begin OracleAggregatorMIS2::OracleAggregatorMIS2%640A409C00BC_const.initialization preserve=yes
  //## end OracleAggregatorMIS2::OracleAggregatorMIS2%640A409C00BC_const.initialization
{
  //## begin dnoracledatabase::OracleAggregatorMIS2::OracleAggregatorMIS2%640A409C00BC_const.body preserve=yes
   memcpy(m_sID, "DO18", 4);
   AMS1_ROWS = 0;
   string strQualifier(Database::instance()->qualifier());
   memcpy(AMS1_MERGE, "MERGE INTO ", 11);
   memcpy(AMS1_MERGE + 11, strQualifier.data(), strQualifier.length());
   strcpy(AMS1_MERGE + 11 + strQualifier.length(),
      ".T_MIS_TOTAL USING DUAL ON "
      "(TSTAMP_START = ? AND "
      "INTERVAL_TYPE = ?  AND "
      "T_FIN_ENTITY_ID = ?  AND "
      "T_FIN_ENTITY_ID_2 IS NULL  AND "
      "T_MIS_MCC = ?  AND "
      "CATEGORY_ID = ?  AND "
      "SYNC_INTERVAL_NO = ?  AND "
      "BIN = ? )"
      " WHEN MATCHED THEN UPDATE SET "
      "AMT_TRAN = AMT_TRAN + ? , "
      "AMT_SURCHARGE = AMT_SURCHARGE + ? , "
      "AMT_POS_REIMBURSE = AMT_POS_REIMBURSE + ? , "
      "CASHBACK_AMT = CASHBACK_AMT + ? , "
      "TRAN_COUNT = TRAN_COUNT + ? , "
      "TIME_AT_ISS = TIME_AT_ISS + ? , "
      "TIME_AT_RQST_SWTCH = TIME_AT_RQST_SWTCH + ? , "
      "AMT_FEE = AMT_FEE + ? "
      "WHEN NOT MATCHED THEN INSERT"
      "(TSTAMP_START"
      ",INTERVAL_TYPE"
      ",T_FIN_ENTITY_ID"
      ",T_MIS_MCC"
      ",CATEGORY_ID"
      ",PARTITION_KEY"
      ",AMT_TRAN"
      ",AMT_SURCHARGE"
      ",AMT_POS_REIMBURSE"
      ",CASHBACK_AMT"
      ",TRAN_COUNT"
      ",TIME_AT_ISS"
      ",TIME_AT_RQST_SWTCH"
      ",AMT_FEE"
      ",SYNC_INTERVAL_NO"
      ",BIN)"
      "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
   int i = 0;
   size_t pos = 0;
   char szTemp[7];
   string strSQL(AMS1_MERGE);
   while ((pos = strSQL.find('?')) != string::npos)
      strSQL.replace(pos, 1, szTemp, snprintf(szTemp, sizeof(szTemp), ":p%d", 1000 + i++));
   memcpy(AMS1_MERGE, strSQL.data(), strSQL.length());

   AMS2_ROWS = 0;
   memcpy(AMS2_MERGE, "MERGE INTO ", 11);
   memcpy(AMS2_MERGE + 11, strQualifier.data(), strQualifier.length());
   strcpy(AMS2_MERGE + 11 + strQualifier.length(),
      ".T_MIS_TOTAL USING DUAL ON "
      "(TSTAMP_START = ? AND "
      "INTERVAL_TYPE = ?  AND "
      "T_FIN_ENTITY_ID = ?  AND "
      "T_FIN_ENTITY_ID_2 = ?  AND "
      "T_MIS_MCC = ?  AND "
      "CATEGORY_ID = ?  AND "
      "SYNC_INTERVAL_NO = ?  AND "
      "BIN = ? )"
      " WHEN MATCHED THEN UPDATE SET "
      "AMT_TRAN = AMT_TRAN + ? , "
      "AMT_SURCHARGE = AMT_SURCHARGE + ? , "
      "AMT_POS_REIMBURSE = AMT_POS_REIMBURSE + ? , "
      "CASHBACK_AMT = CASHBACK_AMT + ? , "
      "TRAN_COUNT = TRAN_COUNT + ? , "
      "TIME_AT_ISS = TIME_AT_ISS + ? , "
      "TIME_AT_RQST_SWTCH = TIME_AT_RQST_SWTCH + ? , "
      "AMT_FEE = AMT_FEE + ? "
      "WHEN NOT MATCHED THEN INSERT"
      "(TSTAMP_START"
      ",INTERVAL_TYPE"
      ",T_FIN_ENTITY_ID"
      ",T_FIN_ENTITY_ID_2"
      ",T_MIS_MCC"
      ",CATEGORY_ID"
      ",PARTITION_KEY"
      ",AMT_TRAN"
      ",AMT_SURCHARGE"
      ",AMT_POS_REIMBURSE"
      ",CASHBACK_AMT"
      ",TRAN_COUNT"
      ",TIME_AT_ISS"
      ",TIME_AT_RQST_SWTCH"
      ",AMT_FEE"
      ",SYNC_INTERVAL_NO"
      ",BIN)"
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
   i = 0;
   pos = 0;
   strSQL.assign(AMS2_MERGE);
   while ((pos = strSQL.find('?')) != string::npos)
      strSQL.replace(pos, 1, szTemp, snprintf(szTemp, sizeof(szTemp), ":p%d", 1000 + i++));
   memcpy(AMS2_MERGE, strSQL.data(), strSQL.length());
  //## end dnoracledatabase::OracleAggregatorMIS2::OracleAggregatorMIS2%640A409C00BC_const.body
}


OracleAggregatorMIS2::~OracleAggregatorMIS2()
{
  //## begin dnoracledatabase::OracleAggregatorMIS2::~OracleAggregatorMIS2%640A409C00BC_dest.body preserve=yes
  //## end dnoracledatabase::OracleAggregatorMIS2::~OracleAggregatorMIS2%640A409C00BC_dest.body
}



//## Other Operations (implementation)
int OracleAggregatorMIS2::checkResult ()
{
  //## begin dnoracledatabase::OracleAggregatorMIS2::checkResult%640A409C00C0.body preserve=yes
   switch (sqlca.sqlcode)
   {
   case 0:
      UseCase::addItem();
      return 1;
   case 100:
   case 1403:
      return 0;
   case -51:
   case -54:
   case -99999913:
      UseCase::add("DEADLOCK");
      break;
   case -1012:
   case -2396:
   case -3113:
   case -3114:
   case -3135:
      UseCase::add("CONNECT");
      Database::instance()->setState(Database::DISCONNECTED);
      break;
   default:
      if (sqlca.sqlcode > 0)
      {
         Database::instance()->traceSQLError((void*)&sqlca, m_sID, m_strDBAccess.c_str());
         UseCase::addItem();
         return 1;
      }
      else
         UseCase::add("DBERROR");
   }
   AMS1_ROWS = 0;
   AMS2_ROWS = 0;
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca, m_sID, m_strDBAccess.c_str());
   return -1;
  //## end dnoracledatabase::OracleAggregatorMIS2::checkResult%640A409C00C0.body
}

bool OracleAggregatorMIS2::commit ()
{
  //## begin dnoracledatabase::OracleAggregatorMIS2::commit%640A846901CC.body preserve=yes
   if (AMS1_ROWS > 0)
   {
      m_strDBAccess = "MERGE1";
      /* EXEC SQL PREPARE AMS1_STATEMENT FROM : AMS1_MERGE; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 13;
      sqlstm.arrsiz = 1;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )5;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (         void  *)AMS1_MERGE;
      sqlstm.sqhstl[0] = (unsigned int  )2048;
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         void  *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned int  )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


      int iRC = checkResult();
      if (iRC == -1)
         return false;
      /* EXEC SQL FOR : AMS1_ROWS
         EXECUTE  AMS1_STATEMENT
         USING
         : AMS1_TSTAMP_START,
         : AMS1_INTERVAL_TYPE,
         : AMS1_T_FIN_ENTITY_ID,
         : AMS1_T_MIS_MCC,
         : AMS1_CATEGORY_ID,
         : AMS1_SYNC_INTERVAL_NO,
         : AMS1_BIN,
         : AMS1_AMT_TRAN,
         : AMS1_AMT_SURCHARGE,
         : AMS1_AMT_POS_REIMBURSE,
         : AMS1_CASHBACK_AMT,
         : AMS1_TRAN_COUNT,
         : AMS1_TIME_AT_ISS,
         : AMS1_TIME_AT_RQST_SWTCH,
         : AMS1_AMT_FEE,
         : AMS1_TSTAMP_START,
         : AMS1_INTERVAL_TYPE,
         : AMS1_T_FIN_ENTITY_ID,
         : AMS1_T_MIS_MCC,
         : AMS1_CATEGORY_ID,
         : AMS1_PARTITION_KEY,
         : AMS1_AMT_TRAN,
         : AMS1_AMT_SURCHARGE,
         : AMS1_AMT_POS_REIMBURSE,
         : AMS1_CASHBACK_AMT,
         : AMS1_TRAN_COUNT,
         : AMS1_TIME_AT_ISS,
         : AMS1_TIME_AT_RQST_SWTCH,
         : AMS1_AMT_FEE,
         : AMS1_SYNC_INTERVAL_NO,
         : AMS1_BIN; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 13;
      sqlstm.arrsiz = 31;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "";
      sqlstm.iters = (unsigned int  )AMS1_ROWS;
      sqlstm.offset = (unsigned int  )24;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (         void  *)AMS1_TSTAMP_START;
      sqlstm.sqhstl[0] = (unsigned int  )11;
      sqlstm.sqhsts[0] = (         int  )11;
      sqlstm.sqindv[0] = (         void  *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned int  )0;
      sqlstm.sqharc[0] = (unsigned int   *)0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqhstv[1] = (         void  *)AMS1_INTERVAL_TYPE;
      sqlstm.sqhstl[1] = (unsigned int  )2;
      sqlstm.sqhsts[1] = (         int  )2;
      sqlstm.sqindv[1] = (         void  *)0;
      sqlstm.sqinds[1] = (         int  )0;
      sqlstm.sqharm[1] = (unsigned int  )0;
      sqlstm.sqharc[1] = (unsigned int   *)0;
      sqlstm.sqadto[1] = (unsigned short )0;
      sqlstm.sqtdso[1] = (unsigned short )0;
      sqlstm.sqhstv[2] = (         void  *)AMS1_T_FIN_ENTITY_ID;
      sqlstm.sqhstl[2] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[2] = (         int  )sizeof(int);
      sqlstm.sqindv[2] = (         void  *)0;
      sqlstm.sqinds[2] = (         int  )0;
      sqlstm.sqharm[2] = (unsigned int  )0;
      sqlstm.sqharc[2] = (unsigned int   *)0;
      sqlstm.sqadto[2] = (unsigned short )0;
      sqlstm.sqtdso[2] = (unsigned short )0;
      sqlstm.sqhstv[3] = (         void  *)AMS1_T_MIS_MCC;
      sqlstm.sqhstl[3] = (unsigned int  )5;
      sqlstm.sqhsts[3] = (         int  )5;
      sqlstm.sqindv[3] = (         void  *)0;
      sqlstm.sqinds[3] = (         int  )0;
      sqlstm.sqharm[3] = (unsigned int  )0;
      sqlstm.sqharc[3] = (unsigned int   *)0;
      sqlstm.sqadto[3] = (unsigned short )0;
      sqlstm.sqtdso[3] = (unsigned short )0;
      sqlstm.sqhstv[4] = (         void  *)AMS1_CATEGORY_ID;
      sqlstm.sqhstl[4] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[4] = (         int  )sizeof(int);
      sqlstm.sqindv[4] = (         void  *)0;
      sqlstm.sqinds[4] = (         int  )0;
      sqlstm.sqharm[4] = (unsigned int  )0;
      sqlstm.sqharc[4] = (unsigned int   *)0;
      sqlstm.sqadto[4] = (unsigned short )0;
      sqlstm.sqtdso[4] = (unsigned short )0;
      sqlstm.sqhstv[5] = (         void  *)AMS1_SYNC_INTERVAL_NO;
      sqlstm.sqhstl[5] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[5] = (         int  )sizeof(int);
      sqlstm.sqindv[5] = (         void  *)0;
      sqlstm.sqinds[5] = (         int  )0;
      sqlstm.sqharm[5] = (unsigned int  )0;
      sqlstm.sqharc[5] = (unsigned int   *)0;
      sqlstm.sqadto[5] = (unsigned short )0;
      sqlstm.sqtdso[5] = (unsigned short )0;
      sqlstm.sqhstv[6] = (         void  *)AMS1_BIN;
      sqlstm.sqhstl[6] = (unsigned int  )12;
      sqlstm.sqhsts[6] = (         int  )12;
      sqlstm.sqindv[6] = (         void  *)0;
      sqlstm.sqinds[6] = (         int  )0;
      sqlstm.sqharm[6] = (unsigned int  )0;
      sqlstm.sqharc[6] = (unsigned int   *)0;
      sqlstm.sqadto[6] = (unsigned short )0;
      sqlstm.sqtdso[6] = (unsigned short )0;
      sqlstm.sqhstv[7] = (         void  *)AMS1_AMT_TRAN;
      sqlstm.sqhstl[7] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[7] = (         int  )sizeof(double);
      sqlstm.sqindv[7] = (         void  *)0;
      sqlstm.sqinds[7] = (         int  )0;
      sqlstm.sqharm[7] = (unsigned int  )0;
      sqlstm.sqharc[7] = (unsigned int   *)0;
      sqlstm.sqadto[7] = (unsigned short )0;
      sqlstm.sqtdso[7] = (unsigned short )0;
      sqlstm.sqhstv[8] = (         void  *)AMS1_AMT_SURCHARGE;
      sqlstm.sqhstl[8] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[8] = (         int  )sizeof(double);
      sqlstm.sqindv[8] = (         void  *)0;
      sqlstm.sqinds[8] = (         int  )0;
      sqlstm.sqharm[8] = (unsigned int  )0;
      sqlstm.sqharc[8] = (unsigned int   *)0;
      sqlstm.sqadto[8] = (unsigned short )0;
      sqlstm.sqtdso[8] = (unsigned short )0;
      sqlstm.sqhstv[9] = (         void  *)AMS1_AMT_POS_REIMBURSE;
      sqlstm.sqhstl[9] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[9] = (         int  )sizeof(double);
      sqlstm.sqindv[9] = (         void  *)0;
      sqlstm.sqinds[9] = (         int  )0;
      sqlstm.sqharm[9] = (unsigned int  )0;
      sqlstm.sqharc[9] = (unsigned int   *)0;
      sqlstm.sqadto[9] = (unsigned short )0;
      sqlstm.sqtdso[9] = (unsigned short )0;
      sqlstm.sqhstv[10] = (         void  *)AMS1_CASHBACK_AMT;
      sqlstm.sqhstl[10] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[10] = (         int  )sizeof(double);
      sqlstm.sqindv[10] = (         void  *)0;
      sqlstm.sqinds[10] = (         int  )0;
      sqlstm.sqharm[10] = (unsigned int  )0;
      sqlstm.sqharc[10] = (unsigned int   *)0;
      sqlstm.sqadto[10] = (unsigned short )0;
      sqlstm.sqtdso[10] = (unsigned short )0;
      sqlstm.sqhstv[11] = (         void  *)AMS1_TRAN_COUNT;
      sqlstm.sqhstl[11] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[11] = (         int  )sizeof(int);
      sqlstm.sqindv[11] = (         void  *)0;
      sqlstm.sqinds[11] = (         int  )0;
      sqlstm.sqharm[11] = (unsigned int  )0;
      sqlstm.sqharc[11] = (unsigned int   *)0;
      sqlstm.sqadto[11] = (unsigned short )0;
      sqlstm.sqtdso[11] = (unsigned short )0;
      sqlstm.sqhstv[12] = (         void  *)AMS1_TIME_AT_ISS;
      sqlstm.sqhstl[12] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[12] = (         int  )sizeof(double);
      sqlstm.sqindv[12] = (         void  *)0;
      sqlstm.sqinds[12] = (         int  )0;
      sqlstm.sqharm[12] = (unsigned int  )0;
      sqlstm.sqharc[12] = (unsigned int   *)0;
      sqlstm.sqadto[12] = (unsigned short )0;
      sqlstm.sqtdso[12] = (unsigned short )0;
      sqlstm.sqhstv[13] = (         void  *)AMS1_TIME_AT_RQST_SWTCH;
      sqlstm.sqhstl[13] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[13] = (         int  )sizeof(double);
      sqlstm.sqindv[13] = (         void  *)0;
      sqlstm.sqinds[13] = (         int  )0;
      sqlstm.sqharm[13] = (unsigned int  )0;
      sqlstm.sqharc[13] = (unsigned int   *)0;
      sqlstm.sqadto[13] = (unsigned short )0;
      sqlstm.sqtdso[13] = (unsigned short )0;
      sqlstm.sqhstv[14] = (         void  *)AMS1_AMT_FEE;
      sqlstm.sqhstl[14] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[14] = (         int  )sizeof(double);
      sqlstm.sqindv[14] = (         void  *)0;
      sqlstm.sqinds[14] = (         int  )0;
      sqlstm.sqharm[14] = (unsigned int  )0;
      sqlstm.sqharc[14] = (unsigned int   *)0;
      sqlstm.sqadto[14] = (unsigned short )0;
      sqlstm.sqtdso[14] = (unsigned short )0;
      sqlstm.sqhstv[15] = (         void  *)AMS1_TSTAMP_START;
      sqlstm.sqhstl[15] = (unsigned int  )11;
      sqlstm.sqhsts[15] = (         int  )11;
      sqlstm.sqindv[15] = (         void  *)0;
      sqlstm.sqinds[15] = (         int  )0;
      sqlstm.sqharm[15] = (unsigned int  )0;
      sqlstm.sqharc[15] = (unsigned int   *)0;
      sqlstm.sqadto[15] = (unsigned short )0;
      sqlstm.sqtdso[15] = (unsigned short )0;
      sqlstm.sqhstv[16] = (         void  *)AMS1_INTERVAL_TYPE;
      sqlstm.sqhstl[16] = (unsigned int  )2;
      sqlstm.sqhsts[16] = (         int  )2;
      sqlstm.sqindv[16] = (         void  *)0;
      sqlstm.sqinds[16] = (         int  )0;
      sqlstm.sqharm[16] = (unsigned int  )0;
      sqlstm.sqharc[16] = (unsigned int   *)0;
      sqlstm.sqadto[16] = (unsigned short )0;
      sqlstm.sqtdso[16] = (unsigned short )0;
      sqlstm.sqhstv[17] = (         void  *)AMS1_T_FIN_ENTITY_ID;
      sqlstm.sqhstl[17] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[17] = (         int  )sizeof(int);
      sqlstm.sqindv[17] = (         void  *)0;
      sqlstm.sqinds[17] = (         int  )0;
      sqlstm.sqharm[17] = (unsigned int  )0;
      sqlstm.sqharc[17] = (unsigned int   *)0;
      sqlstm.sqadto[17] = (unsigned short )0;
      sqlstm.sqtdso[17] = (unsigned short )0;
      sqlstm.sqhstv[18] = (         void  *)AMS1_T_MIS_MCC;
      sqlstm.sqhstl[18] = (unsigned int  )5;
      sqlstm.sqhsts[18] = (         int  )5;
      sqlstm.sqindv[18] = (         void  *)0;
      sqlstm.sqinds[18] = (         int  )0;
      sqlstm.sqharm[18] = (unsigned int  )0;
      sqlstm.sqharc[18] = (unsigned int   *)0;
      sqlstm.sqadto[18] = (unsigned short )0;
      sqlstm.sqtdso[18] = (unsigned short )0;
      sqlstm.sqhstv[19] = (         void  *)AMS1_CATEGORY_ID;
      sqlstm.sqhstl[19] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[19] = (         int  )sizeof(int);
      sqlstm.sqindv[19] = (         void  *)0;
      sqlstm.sqinds[19] = (         int  )0;
      sqlstm.sqharm[19] = (unsigned int  )0;
      sqlstm.sqharc[19] = (unsigned int   *)0;
      sqlstm.sqadto[19] = (unsigned short )0;
      sqlstm.sqtdso[19] = (unsigned short )0;
      sqlstm.sqhstv[20] = (         void  *)AMS1_PARTITION_KEY;
      sqlstm.sqhstl[20] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[20] = (         int  )sizeof(int);
      sqlstm.sqindv[20] = (         void  *)0;
      sqlstm.sqinds[20] = (         int  )0;
      sqlstm.sqharm[20] = (unsigned int  )0;
      sqlstm.sqharc[20] = (unsigned int   *)0;
      sqlstm.sqadto[20] = (unsigned short )0;
      sqlstm.sqtdso[20] = (unsigned short )0;
      sqlstm.sqhstv[21] = (         void  *)AMS1_AMT_TRAN;
      sqlstm.sqhstl[21] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[21] = (         int  )sizeof(double);
      sqlstm.sqindv[21] = (         void  *)0;
      sqlstm.sqinds[21] = (         int  )0;
      sqlstm.sqharm[21] = (unsigned int  )0;
      sqlstm.sqharc[21] = (unsigned int   *)0;
      sqlstm.sqadto[21] = (unsigned short )0;
      sqlstm.sqtdso[21] = (unsigned short )0;
      sqlstm.sqhstv[22] = (         void  *)AMS1_AMT_SURCHARGE;
      sqlstm.sqhstl[22] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[22] = (         int  )sizeof(double);
      sqlstm.sqindv[22] = (         void  *)0;
      sqlstm.sqinds[22] = (         int  )0;
      sqlstm.sqharm[22] = (unsigned int  )0;
      sqlstm.sqharc[22] = (unsigned int   *)0;
      sqlstm.sqadto[22] = (unsigned short )0;
      sqlstm.sqtdso[22] = (unsigned short )0;
      sqlstm.sqhstv[23] = (         void  *)AMS1_AMT_POS_REIMBURSE;
      sqlstm.sqhstl[23] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[23] = (         int  )sizeof(double);
      sqlstm.sqindv[23] = (         void  *)0;
      sqlstm.sqinds[23] = (         int  )0;
      sqlstm.sqharm[23] = (unsigned int  )0;
      sqlstm.sqharc[23] = (unsigned int   *)0;
      sqlstm.sqadto[23] = (unsigned short )0;
      sqlstm.sqtdso[23] = (unsigned short )0;
      sqlstm.sqhstv[24] = (         void  *)AMS1_CASHBACK_AMT;
      sqlstm.sqhstl[24] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[24] = (         int  )sizeof(double);
      sqlstm.sqindv[24] = (         void  *)0;
      sqlstm.sqinds[24] = (         int  )0;
      sqlstm.sqharm[24] = (unsigned int  )0;
      sqlstm.sqharc[24] = (unsigned int   *)0;
      sqlstm.sqadto[24] = (unsigned short )0;
      sqlstm.sqtdso[24] = (unsigned short )0;
      sqlstm.sqhstv[25] = (         void  *)AMS1_TRAN_COUNT;
      sqlstm.sqhstl[25] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[25] = (         int  )sizeof(int);
      sqlstm.sqindv[25] = (         void  *)0;
      sqlstm.sqinds[25] = (         int  )0;
      sqlstm.sqharm[25] = (unsigned int  )0;
      sqlstm.sqharc[25] = (unsigned int   *)0;
      sqlstm.sqadto[25] = (unsigned short )0;
      sqlstm.sqtdso[25] = (unsigned short )0;
      sqlstm.sqhstv[26] = (         void  *)AMS1_TIME_AT_ISS;
      sqlstm.sqhstl[26] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[26] = (         int  )sizeof(double);
      sqlstm.sqindv[26] = (         void  *)0;
      sqlstm.sqinds[26] = (         int  )0;
      sqlstm.sqharm[26] = (unsigned int  )0;
      sqlstm.sqharc[26] = (unsigned int   *)0;
      sqlstm.sqadto[26] = (unsigned short )0;
      sqlstm.sqtdso[26] = (unsigned short )0;
      sqlstm.sqhstv[27] = (         void  *)AMS1_TIME_AT_RQST_SWTCH;
      sqlstm.sqhstl[27] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[27] = (         int  )sizeof(double);
      sqlstm.sqindv[27] = (         void  *)0;
      sqlstm.sqinds[27] = (         int  )0;
      sqlstm.sqharm[27] = (unsigned int  )0;
      sqlstm.sqharc[27] = (unsigned int   *)0;
      sqlstm.sqadto[27] = (unsigned short )0;
      sqlstm.sqtdso[27] = (unsigned short )0;
      sqlstm.sqhstv[28] = (         void  *)AMS1_AMT_FEE;
      sqlstm.sqhstl[28] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[28] = (         int  )sizeof(double);
      sqlstm.sqindv[28] = (         void  *)0;
      sqlstm.sqinds[28] = (         int  )0;
      sqlstm.sqharm[28] = (unsigned int  )0;
      sqlstm.sqharc[28] = (unsigned int   *)0;
      sqlstm.sqadto[28] = (unsigned short )0;
      sqlstm.sqtdso[28] = (unsigned short )0;
      sqlstm.sqhstv[29] = (         void  *)AMS1_SYNC_INTERVAL_NO;
      sqlstm.sqhstl[29] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[29] = (         int  )sizeof(int);
      sqlstm.sqindv[29] = (         void  *)0;
      sqlstm.sqinds[29] = (         int  )0;
      sqlstm.sqharm[29] = (unsigned int  )0;
      sqlstm.sqharc[29] = (unsigned int   *)0;
      sqlstm.sqadto[29] = (unsigned short )0;
      sqlstm.sqtdso[29] = (unsigned short )0;
      sqlstm.sqhstv[30] = (         void  *)AMS1_BIN;
      sqlstm.sqhstl[30] = (unsigned int  )12;
      sqlstm.sqhsts[30] = (         int  )12;
      sqlstm.sqindv[30] = (         void  *)0;
      sqlstm.sqinds[30] = (         int  )0;
      sqlstm.sqharm[30] = (unsigned int  )0;
      sqlstm.sqharc[30] = (unsigned int   *)0;
      sqlstm.sqadto[30] = (unsigned short )0;
      sqlstm.sqtdso[30] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


      iRC = checkResult();
      AMS1_ROWS = 0;
      if (iRC == -1)
      {
         char szTemp[265];
         int iLength = 0;
         for (int i = 0; i < AMS1_ROWS; i++)
         {
            iLength = snprintf(szTemp, sizeof(szTemp), "MERGE INTO %s %ld %s %ld %18.0f %18.0f %18.0f %18.0f %ld %18.0f %18.0f %18.0f %ld %s",
               AMS1_TSTAMP_START[i], AMS1_T_FIN_ENTITY_ID[i], AMS1_T_MIS_MCC[i], AMS1_CATEGORY_ID[i], AMS1_AMT_TRAN[i], AMS1_AMT_SURCHARGE[i],
               AMS1_AMT_POS_REIMBURSE[i], AMS1_CASHBACK_AMT[i], AMS1_TRAN_COUNT[i], AMS1_TIME_AT_ISS[i], AMS1_TIME_AT_RQST_SWTCH[i], AMS1_AMT_FEE[i], AMS1_SYNC_INTERVAL_NO[i], AMS1_BIN[i]);
            Trace::put(szTemp,iLength,true);
         }
         return false;
      }
   }
   if (AMS2_ROWS > 0)
   {
      m_strDBAccess = "MERGE2";
      /* EXEC SQL PREPARE AMS2_STATEMENT FROM : AMS2_MERGE; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 13;
      sqlstm.arrsiz = 31;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "";
      sqlstm.iters = (unsigned int  )1;
      sqlstm.offset = (unsigned int  )163;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (         void  *)AMS2_MERGE;
      sqlstm.sqhstl[0] = (unsigned int  )2048;
      sqlstm.sqhsts[0] = (         int  )0;
      sqlstm.sqindv[0] = (         void  *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned int  )0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


      int iRC = checkResult();
      if (iRC == -1)
         return false;
      /* EXEC SQL FOR : AMS2_ROWS
         EXECUTE  AMS2_STATEMENT
         USING
         : AMS2_TSTAMP_START,
         : AMS2_INTERVAL_TYPE,
         : AMS2_T_FIN_ENTITY_ID,
         : AMS2_T_FIN_ENTITY_ID_2,
         : AMS2_T_MIS_MCC,
         : AMS2_CATEGORY_ID,
         : AMS2_SYNC_INTERVAL_NO,
         : AMS2_BIN,
         : AMS2_AMT_TRAN,
         : AMS2_AMT_SURCHARGE,
         : AMS2_AMT_POS_REIMBURSE,
         : AMS2_CASHBACK_AMT,
         : AMS2_TRAN_COUNT,
         : AMS2_TIME_AT_ISS,
         : AMS2_TIME_AT_RQST_SWTCH,
         : AMS2_AMT_FEE,
         : AMS2_TSTAMP_START,
         : AMS2_INTERVAL_TYPE,
         : AMS2_T_FIN_ENTITY_ID,
         : AMS2_T_FIN_ENTITY_ID_2,
         : AMS2_T_MIS_MCC,
         : AMS2_CATEGORY_ID,
         : AMS2_PARTITION_KEY,
         : AMS2_AMT_TRAN,
         : AMS2_AMT_SURCHARGE,
         : AMS2_AMT_POS_REIMBURSE,
         : AMS2_CASHBACK_AMT,
         : AMS2_TRAN_COUNT,
         : AMS2_TIME_AT_ISS,
         : AMS2_TIME_AT_RQST_SWTCH,
         : AMS2_AMT_FEE,
         : AMS2_SYNC_INTERVAL_NO,
         : AMS2_BIN; */ 

{
      struct sqlexd sqlstm;
      sqlstm.sqlvsn = 13;
      sqlstm.arrsiz = 33;
      sqlstm.sqladtp = &sqladt;
      sqlstm.sqltdsp = &sqltds;
      sqlstm.stmt = "";
      sqlstm.iters = (unsigned int  )AMS2_ROWS;
      sqlstm.offset = (unsigned int  )182;
      sqlstm.cud = sqlcud0;
      sqlstm.sqlest = (unsigned char  *)&sqlca;
      sqlstm.sqlety = (unsigned short)4352;
      sqlstm.occurs = (unsigned int  )0;
      sqlstm.sqhstv[0] = (         void  *)AMS2_TSTAMP_START;
      sqlstm.sqhstl[0] = (unsigned int  )11;
      sqlstm.sqhsts[0] = (         int  )11;
      sqlstm.sqindv[0] = (         void  *)0;
      sqlstm.sqinds[0] = (         int  )0;
      sqlstm.sqharm[0] = (unsigned int  )0;
      sqlstm.sqharc[0] = (unsigned int   *)0;
      sqlstm.sqadto[0] = (unsigned short )0;
      sqlstm.sqtdso[0] = (unsigned short )0;
      sqlstm.sqhstv[1] = (         void  *)AMS2_INTERVAL_TYPE;
      sqlstm.sqhstl[1] = (unsigned int  )2;
      sqlstm.sqhsts[1] = (         int  )2;
      sqlstm.sqindv[1] = (         void  *)0;
      sqlstm.sqinds[1] = (         int  )0;
      sqlstm.sqharm[1] = (unsigned int  )0;
      sqlstm.sqharc[1] = (unsigned int   *)0;
      sqlstm.sqadto[1] = (unsigned short )0;
      sqlstm.sqtdso[1] = (unsigned short )0;
      sqlstm.sqhstv[2] = (         void  *)AMS2_T_FIN_ENTITY_ID;
      sqlstm.sqhstl[2] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[2] = (         int  )sizeof(int);
      sqlstm.sqindv[2] = (         void  *)0;
      sqlstm.sqinds[2] = (         int  )0;
      sqlstm.sqharm[2] = (unsigned int  )0;
      sqlstm.sqharc[2] = (unsigned int   *)0;
      sqlstm.sqadto[2] = (unsigned short )0;
      sqlstm.sqtdso[2] = (unsigned short )0;
      sqlstm.sqhstv[3] = (         void  *)AMS2_T_FIN_ENTITY_ID_2;
      sqlstm.sqhstl[3] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[3] = (         int  )sizeof(int);
      sqlstm.sqindv[3] = (         void  *)0;
      sqlstm.sqinds[3] = (         int  )0;
      sqlstm.sqharm[3] = (unsigned int  )0;
      sqlstm.sqharc[3] = (unsigned int   *)0;
      sqlstm.sqadto[3] = (unsigned short )0;
      sqlstm.sqtdso[3] = (unsigned short )0;
      sqlstm.sqhstv[4] = (         void  *)AMS2_T_MIS_MCC;
      sqlstm.sqhstl[4] = (unsigned int  )5;
      sqlstm.sqhsts[4] = (         int  )5;
      sqlstm.sqindv[4] = (         void  *)0;
      sqlstm.sqinds[4] = (         int  )0;
      sqlstm.sqharm[4] = (unsigned int  )0;
      sqlstm.sqharc[4] = (unsigned int   *)0;
      sqlstm.sqadto[4] = (unsigned short )0;
      sqlstm.sqtdso[4] = (unsigned short )0;
      sqlstm.sqhstv[5] = (         void  *)AMS2_CATEGORY_ID;
      sqlstm.sqhstl[5] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[5] = (         int  )sizeof(int);
      sqlstm.sqindv[5] = (         void  *)0;
      sqlstm.sqinds[5] = (         int  )0;
      sqlstm.sqharm[5] = (unsigned int  )0;
      sqlstm.sqharc[5] = (unsigned int   *)0;
      sqlstm.sqadto[5] = (unsigned short )0;
      sqlstm.sqtdso[5] = (unsigned short )0;
      sqlstm.sqhstv[6] = (         void  *)AMS2_SYNC_INTERVAL_NO;
      sqlstm.sqhstl[6] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[6] = (         int  )sizeof(int);
      sqlstm.sqindv[6] = (         void  *)0;
      sqlstm.sqinds[6] = (         int  )0;
      sqlstm.sqharm[6] = (unsigned int  )0;
      sqlstm.sqharc[6] = (unsigned int   *)0;
      sqlstm.sqadto[6] = (unsigned short )0;
      sqlstm.sqtdso[6] = (unsigned short )0;
      sqlstm.sqhstv[7] = (         void  *)AMS2_BIN;
      sqlstm.sqhstl[7] = (unsigned int  )12;
      sqlstm.sqhsts[7] = (         int  )12;
      sqlstm.sqindv[7] = (         void  *)0;
      sqlstm.sqinds[7] = (         int  )0;
      sqlstm.sqharm[7] = (unsigned int  )0;
      sqlstm.sqharc[7] = (unsigned int   *)0;
      sqlstm.sqadto[7] = (unsigned short )0;
      sqlstm.sqtdso[7] = (unsigned short )0;
      sqlstm.sqhstv[8] = (         void  *)AMS2_AMT_TRAN;
      sqlstm.sqhstl[8] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[8] = (         int  )sizeof(double);
      sqlstm.sqindv[8] = (         void  *)0;
      sqlstm.sqinds[8] = (         int  )0;
      sqlstm.sqharm[8] = (unsigned int  )0;
      sqlstm.sqharc[8] = (unsigned int   *)0;
      sqlstm.sqadto[8] = (unsigned short )0;
      sqlstm.sqtdso[8] = (unsigned short )0;
      sqlstm.sqhstv[9] = (         void  *)AMS2_AMT_SURCHARGE;
      sqlstm.sqhstl[9] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[9] = (         int  )sizeof(double);
      sqlstm.sqindv[9] = (         void  *)0;
      sqlstm.sqinds[9] = (         int  )0;
      sqlstm.sqharm[9] = (unsigned int  )0;
      sqlstm.sqharc[9] = (unsigned int   *)0;
      sqlstm.sqadto[9] = (unsigned short )0;
      sqlstm.sqtdso[9] = (unsigned short )0;
      sqlstm.sqhstv[10] = (         void  *)AMS2_AMT_POS_REIMBURSE;
      sqlstm.sqhstl[10] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[10] = (         int  )sizeof(double);
      sqlstm.sqindv[10] = (         void  *)0;
      sqlstm.sqinds[10] = (         int  )0;
      sqlstm.sqharm[10] = (unsigned int  )0;
      sqlstm.sqharc[10] = (unsigned int   *)0;
      sqlstm.sqadto[10] = (unsigned short )0;
      sqlstm.sqtdso[10] = (unsigned short )0;
      sqlstm.sqhstv[11] = (         void  *)AMS2_CASHBACK_AMT;
      sqlstm.sqhstl[11] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[11] = (         int  )sizeof(double);
      sqlstm.sqindv[11] = (         void  *)0;
      sqlstm.sqinds[11] = (         int  )0;
      sqlstm.sqharm[11] = (unsigned int  )0;
      sqlstm.sqharc[11] = (unsigned int   *)0;
      sqlstm.sqadto[11] = (unsigned short )0;
      sqlstm.sqtdso[11] = (unsigned short )0;
      sqlstm.sqhstv[12] = (         void  *)AMS2_TRAN_COUNT;
      sqlstm.sqhstl[12] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[12] = (         int  )sizeof(int);
      sqlstm.sqindv[12] = (         void  *)0;
      sqlstm.sqinds[12] = (         int  )0;
      sqlstm.sqharm[12] = (unsigned int  )0;
      sqlstm.sqharc[12] = (unsigned int   *)0;
      sqlstm.sqadto[12] = (unsigned short )0;
      sqlstm.sqtdso[12] = (unsigned short )0;
      sqlstm.sqhstv[13] = (         void  *)AMS2_TIME_AT_ISS;
      sqlstm.sqhstl[13] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[13] = (         int  )sizeof(double);
      sqlstm.sqindv[13] = (         void  *)0;
      sqlstm.sqinds[13] = (         int  )0;
      sqlstm.sqharm[13] = (unsigned int  )0;
      sqlstm.sqharc[13] = (unsigned int   *)0;
      sqlstm.sqadto[13] = (unsigned short )0;
      sqlstm.sqtdso[13] = (unsigned short )0;
      sqlstm.sqhstv[14] = (         void  *)AMS2_TIME_AT_RQST_SWTCH;
      sqlstm.sqhstl[14] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[14] = (         int  )sizeof(double);
      sqlstm.sqindv[14] = (         void  *)0;
      sqlstm.sqinds[14] = (         int  )0;
      sqlstm.sqharm[14] = (unsigned int  )0;
      sqlstm.sqharc[14] = (unsigned int   *)0;
      sqlstm.sqadto[14] = (unsigned short )0;
      sqlstm.sqtdso[14] = (unsigned short )0;
      sqlstm.sqhstv[15] = (         void  *)AMS2_AMT_FEE;
      sqlstm.sqhstl[15] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[15] = (         int  )sizeof(double);
      sqlstm.sqindv[15] = (         void  *)0;
      sqlstm.sqinds[15] = (         int  )0;
      sqlstm.sqharm[15] = (unsigned int  )0;
      sqlstm.sqharc[15] = (unsigned int   *)0;
      sqlstm.sqadto[15] = (unsigned short )0;
      sqlstm.sqtdso[15] = (unsigned short )0;
      sqlstm.sqhstv[16] = (         void  *)AMS2_TSTAMP_START;
      sqlstm.sqhstl[16] = (unsigned int  )11;
      sqlstm.sqhsts[16] = (         int  )11;
      sqlstm.sqindv[16] = (         void  *)0;
      sqlstm.sqinds[16] = (         int  )0;
      sqlstm.sqharm[16] = (unsigned int  )0;
      sqlstm.sqharc[16] = (unsigned int   *)0;
      sqlstm.sqadto[16] = (unsigned short )0;
      sqlstm.sqtdso[16] = (unsigned short )0;
      sqlstm.sqhstv[17] = (         void  *)AMS2_INTERVAL_TYPE;
      sqlstm.sqhstl[17] = (unsigned int  )2;
      sqlstm.sqhsts[17] = (         int  )2;
      sqlstm.sqindv[17] = (         void  *)0;
      sqlstm.sqinds[17] = (         int  )0;
      sqlstm.sqharm[17] = (unsigned int  )0;
      sqlstm.sqharc[17] = (unsigned int   *)0;
      sqlstm.sqadto[17] = (unsigned short )0;
      sqlstm.sqtdso[17] = (unsigned short )0;
      sqlstm.sqhstv[18] = (         void  *)AMS2_T_FIN_ENTITY_ID;
      sqlstm.sqhstl[18] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[18] = (         int  )sizeof(int);
      sqlstm.sqindv[18] = (         void  *)0;
      sqlstm.sqinds[18] = (         int  )0;
      sqlstm.sqharm[18] = (unsigned int  )0;
      sqlstm.sqharc[18] = (unsigned int   *)0;
      sqlstm.sqadto[18] = (unsigned short )0;
      sqlstm.sqtdso[18] = (unsigned short )0;
      sqlstm.sqhstv[19] = (         void  *)AMS2_T_FIN_ENTITY_ID_2;
      sqlstm.sqhstl[19] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[19] = (         int  )sizeof(int);
      sqlstm.sqindv[19] = (         void  *)0;
      sqlstm.sqinds[19] = (         int  )0;
      sqlstm.sqharm[19] = (unsigned int  )0;
      sqlstm.sqharc[19] = (unsigned int   *)0;
      sqlstm.sqadto[19] = (unsigned short )0;
      sqlstm.sqtdso[19] = (unsigned short )0;
      sqlstm.sqhstv[20] = (         void  *)AMS2_T_MIS_MCC;
      sqlstm.sqhstl[20] = (unsigned int  )5;
      sqlstm.sqhsts[20] = (         int  )5;
      sqlstm.sqindv[20] = (         void  *)0;
      sqlstm.sqinds[20] = (         int  )0;
      sqlstm.sqharm[20] = (unsigned int  )0;
      sqlstm.sqharc[20] = (unsigned int   *)0;
      sqlstm.sqadto[20] = (unsigned short )0;
      sqlstm.sqtdso[20] = (unsigned short )0;
      sqlstm.sqhstv[21] = (         void  *)AMS2_CATEGORY_ID;
      sqlstm.sqhstl[21] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[21] = (         int  )sizeof(int);
      sqlstm.sqindv[21] = (         void  *)0;
      sqlstm.sqinds[21] = (         int  )0;
      sqlstm.sqharm[21] = (unsigned int  )0;
      sqlstm.sqharc[21] = (unsigned int   *)0;
      sqlstm.sqadto[21] = (unsigned short )0;
      sqlstm.sqtdso[21] = (unsigned short )0;
      sqlstm.sqhstv[22] = (         void  *)AMS2_PARTITION_KEY;
      sqlstm.sqhstl[22] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[22] = (         int  )sizeof(int);
      sqlstm.sqindv[22] = (         void  *)0;
      sqlstm.sqinds[22] = (         int  )0;
      sqlstm.sqharm[22] = (unsigned int  )0;
      sqlstm.sqharc[22] = (unsigned int   *)0;
      sqlstm.sqadto[22] = (unsigned short )0;
      sqlstm.sqtdso[22] = (unsigned short )0;
      sqlstm.sqhstv[23] = (         void  *)AMS2_AMT_TRAN;
      sqlstm.sqhstl[23] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[23] = (         int  )sizeof(double);
      sqlstm.sqindv[23] = (         void  *)0;
      sqlstm.sqinds[23] = (         int  )0;
      sqlstm.sqharm[23] = (unsigned int  )0;
      sqlstm.sqharc[23] = (unsigned int   *)0;
      sqlstm.sqadto[23] = (unsigned short )0;
      sqlstm.sqtdso[23] = (unsigned short )0;
      sqlstm.sqhstv[24] = (         void  *)AMS2_AMT_SURCHARGE;
      sqlstm.sqhstl[24] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[24] = (         int  )sizeof(double);
      sqlstm.sqindv[24] = (         void  *)0;
      sqlstm.sqinds[24] = (         int  )0;
      sqlstm.sqharm[24] = (unsigned int  )0;
      sqlstm.sqharc[24] = (unsigned int   *)0;
      sqlstm.sqadto[24] = (unsigned short )0;
      sqlstm.sqtdso[24] = (unsigned short )0;
      sqlstm.sqhstv[25] = (         void  *)AMS2_AMT_POS_REIMBURSE;
      sqlstm.sqhstl[25] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[25] = (         int  )sizeof(double);
      sqlstm.sqindv[25] = (         void  *)0;
      sqlstm.sqinds[25] = (         int  )0;
      sqlstm.sqharm[25] = (unsigned int  )0;
      sqlstm.sqharc[25] = (unsigned int   *)0;
      sqlstm.sqadto[25] = (unsigned short )0;
      sqlstm.sqtdso[25] = (unsigned short )0;
      sqlstm.sqhstv[26] = (         void  *)AMS2_CASHBACK_AMT;
      sqlstm.sqhstl[26] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[26] = (         int  )sizeof(double);
      sqlstm.sqindv[26] = (         void  *)0;
      sqlstm.sqinds[26] = (         int  )0;
      sqlstm.sqharm[26] = (unsigned int  )0;
      sqlstm.sqharc[26] = (unsigned int   *)0;
      sqlstm.sqadto[26] = (unsigned short )0;
      sqlstm.sqtdso[26] = (unsigned short )0;
      sqlstm.sqhstv[27] = (         void  *)AMS2_TRAN_COUNT;
      sqlstm.sqhstl[27] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[27] = (         int  )sizeof(int);
      sqlstm.sqindv[27] = (         void  *)0;
      sqlstm.sqinds[27] = (         int  )0;
      sqlstm.sqharm[27] = (unsigned int  )0;
      sqlstm.sqharc[27] = (unsigned int   *)0;
      sqlstm.sqadto[27] = (unsigned short )0;
      sqlstm.sqtdso[27] = (unsigned short )0;
      sqlstm.sqhstv[28] = (         void  *)AMS2_TIME_AT_ISS;
      sqlstm.sqhstl[28] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[28] = (         int  )sizeof(double);
      sqlstm.sqindv[28] = (         void  *)0;
      sqlstm.sqinds[28] = (         int  )0;
      sqlstm.sqharm[28] = (unsigned int  )0;
      sqlstm.sqharc[28] = (unsigned int   *)0;
      sqlstm.sqadto[28] = (unsigned short )0;
      sqlstm.sqtdso[28] = (unsigned short )0;
      sqlstm.sqhstv[29] = (         void  *)AMS2_TIME_AT_RQST_SWTCH;
      sqlstm.sqhstl[29] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[29] = (         int  )sizeof(double);
      sqlstm.sqindv[29] = (         void  *)0;
      sqlstm.sqinds[29] = (         int  )0;
      sqlstm.sqharm[29] = (unsigned int  )0;
      sqlstm.sqharc[29] = (unsigned int   *)0;
      sqlstm.sqadto[29] = (unsigned short )0;
      sqlstm.sqtdso[29] = (unsigned short )0;
      sqlstm.sqhstv[30] = (         void  *)AMS2_AMT_FEE;
      sqlstm.sqhstl[30] = (unsigned int  )sizeof(double);
      sqlstm.sqhsts[30] = (         int  )sizeof(double);
      sqlstm.sqindv[30] = (         void  *)0;
      sqlstm.sqinds[30] = (         int  )0;
      sqlstm.sqharm[30] = (unsigned int  )0;
      sqlstm.sqharc[30] = (unsigned int   *)0;
      sqlstm.sqadto[30] = (unsigned short )0;
      sqlstm.sqtdso[30] = (unsigned short )0;
      sqlstm.sqhstv[31] = (         void  *)AMS2_SYNC_INTERVAL_NO;
      sqlstm.sqhstl[31] = (unsigned int  )sizeof(int);
      sqlstm.sqhsts[31] = (         int  )sizeof(int);
      sqlstm.sqindv[31] = (         void  *)0;
      sqlstm.sqinds[31] = (         int  )0;
      sqlstm.sqharm[31] = (unsigned int  )0;
      sqlstm.sqharc[31] = (unsigned int   *)0;
      sqlstm.sqadto[31] = (unsigned short )0;
      sqlstm.sqtdso[31] = (unsigned short )0;
      sqlstm.sqhstv[32] = (         void  *)AMS2_BIN;
      sqlstm.sqhstl[32] = (unsigned int  )12;
      sqlstm.sqhsts[32] = (         int  )12;
      sqlstm.sqindv[32] = (         void  *)0;
      sqlstm.sqinds[32] = (         int  )0;
      sqlstm.sqharm[32] = (unsigned int  )0;
      sqlstm.sqharc[32] = (unsigned int   *)0;
      sqlstm.sqadto[32] = (unsigned short )0;
      sqlstm.sqtdso[32] = (unsigned short )0;
      sqlstm.sqphsv = sqlstm.sqhstv;
      sqlstm.sqphsl = sqlstm.sqhstl;
      sqlstm.sqphss = sqlstm.sqhsts;
      sqlstm.sqpind = sqlstm.sqindv;
      sqlstm.sqpins = sqlstm.sqinds;
      sqlstm.sqparm = sqlstm.sqharm;
      sqlstm.sqparc = sqlstm.sqharc;
      sqlstm.sqpadto = sqlstm.sqadto;
      sqlstm.sqptdso = sqlstm.sqtdso;
      sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


      iRC = checkResult();
      AMS2_ROWS = 0;
      if (iRC == -1)
      {
         char szTemp[286];
         int iLength = 0;
         for (int i = 0; i < AMS2_ROWS; i++)
         {
            iLength = snprintf(szTemp, sizeof(szTemp), "MERGE INTO %s %ld %ld %s %ld %18.0f %18.0f %18.0f %18.0f %ld %18.0f %18.0f %18.0f %ld %s",
               AMS2_TSTAMP_START[i], AMS2_T_FIN_ENTITY_ID[i], AMS2_T_FIN_ENTITY_ID_2[i], AMS2_T_MIS_MCC[i], AMS2_CATEGORY_ID[i], AMS2_AMT_TRAN[i], AMS2_AMT_SURCHARGE[i],
               AMS2_AMT_POS_REIMBURSE[i], AMS2_CASHBACK_AMT[i], AMS2_TRAN_COUNT[i], AMS2_TIME_AT_ISS[i], AMS2_TIME_AT_RQST_SWTCH[i], AMS2_AMT_FEE[i], AMS2_SYNC_INTERVAL_NO[i], AMS2_BIN[i]);
            Trace::put(szTemp,iLength,true);
         }
         return false;
      }
   }
   Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   return true;
  //## end dnoracledatabase::OracleAggregatorMIS2::commit%640A846901CC.body
}

void OracleAggregatorMIS2::lockTables ()
{
  //## begin dnoracledatabase::OracleAggregatorMIS2::lockTables%640A409C00C1.body preserve=yes
  //## end dnoracledatabase::OracleAggregatorMIS2::lockTables%640A409C00C1.body
}

bool OracleAggregatorMIS2::tableInsert (bool bSubtractFromTotals)
{
  //## begin dnoracledatabase::OracleAggregatorMIS2::tableInsert%640A409C00C2.body preserve=yes
  return true;
  //## end dnoracledatabase::OracleAggregatorMIS2::tableInsert%640A409C00C2.body
}

int OracleAggregatorMIS2::tableUpdate (bool bSubtractFromTotals)
{
  //## begin dnoracledatabase::OracleAggregatorMIS2::tableUpdate%640A409C00C4.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return -1;
   char szSpace[2] = { " " };
   if (getENTITY_ID(1) == "~NULL!")
   {
      if (AMS1_ROWS >= 512)
         if (!commit())
            return -1;
      if (!getTSTAMP_START().empty())
      {
         memcpy(AMS1_TSTAMP_START[AMS1_ROWS], getTSTAMP_START().data(), getTSTAMP_START().length());
         AMS1_TSTAMP_START[AMS1_ROWS][getTSTAMP_START().length()] = '\0';
      }
      else
         memcpy(AMS1_TSTAMP_START[AMS1_ROWS], szSpace, 2);
      if (!getINTERVAL_TYPE().empty())
      {
         memcpy(AMS1_INTERVAL_TYPE[AMS1_ROWS], getINTERVAL_TYPE().data(), getINTERVAL_TYPE().length());
         AMS1_INTERVAL_TYPE[AMS1_ROWS][getINTERVAL_TYPE().length()] = '\0';
      }
      else
         memcpy(AMS1_INTERVAL_TYPE[AMS1_ROWS], szSpace, 2);
      if (!getBIN().empty())
      {
         memcpy(AMS1_BIN[AMS1_ROWS], getBIN().data(), getBIN().length());
         AMS1_BIN[AMS1_ROWS][getBIN().length()] = '\0';
      }
      else
         memcpy(AMS1_BIN[AMS1_ROWS], szSpace, 2);
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(0), getENTITY_ID(0), &AMS1_T_FIN_ENTITY_ID[AMS1_ROWS]);
      if (!getT_MIS_MCC().empty())
      {
         memcpy(AMS1_T_MIS_MCC[AMS1_ROWS], getT_MIS_MCC().data(), getT_MIS_MCC().length());
         AMS1_T_MIS_MCC[AMS1_ROWS][getT_MIS_MCC().length()] = '\0';
      }
      else
         memcpy(AMS1_T_MIS_MCC[AMS1_ROWS], szSpace, 2);
      AMS1_SYNC_INTERVAL_NO[AMS1_ROWS] = getSYNC_INTERVAL_NO();
      AMS1_CATEGORY_ID[AMS1_ROWS] = getCATEGORY_ID();
      int iSign = (bSubtractFromTotals ? -1 : 1);
      AMS1_AMT_TRAN[AMS1_ROWS] = getAMT_TRAN() * iSign;
      AMS1_AMT_SURCHARGE[AMS1_ROWS] = getAMT_SURCHARGE() * iSign;
      AMS1_AMT_POS_REIMBURSE[AMS1_ROWS] = getAMT_POS_REIMBURSE() * iSign;
      AMS1_CASHBACK_AMT[AMS1_ROWS] = getCASHBACK_AMT() * iSign;
      AMS1_TRAN_COUNT[AMS1_ROWS] = iSign;
      AMS1_TIME_AT_ISS[AMS1_ROWS] = getTIME_AT_ISS() * iSign;
      AMS1_TIME_AT_RQST_SWTCH[AMS1_ROWS] = getTIME_AT_RQST_SWTCH() * iSign;
      AMS1_AMT_FEE[AMS1_ROWS] = getAMT_FEE() * iSign;
      AMS1_ROWS++;
   }
   else
   {
      if (AMS2_ROWS >= 512)
         if (!commit())
            return -1;
      if (!getTSTAMP_START().empty())
      {
         memcpy(AMS2_TSTAMP_START[AMS2_ROWS], getTSTAMP_START().data(), getTSTAMP_START().length());
         AMS2_TSTAMP_START[AMS2_ROWS][getTSTAMP_START().length()] = '\0';
      }
      else
         memcpy(AMS2_TSTAMP_START[AMS2_ROWS], szSpace, 2);
      if (!getINTERVAL_TYPE().empty())
      {
         memcpy(AMS2_INTERVAL_TYPE[AMS2_ROWS], getINTERVAL_TYPE().data(), getINTERVAL_TYPE().length());
         AMS2_INTERVAL_TYPE[AMS2_ROWS][getINTERVAL_TYPE().length()] = '\0';
      }
      else
         memcpy(AMS2_INTERVAL_TYPE[AMS2_ROWS], szSpace, 2);
      if (!getBIN().empty())
      {
         memcpy(AMS2_BIN[AMS2_ROWS], getBIN().data(), getBIN().length());
         AMS2_BIN[AMS2_ROWS][getBIN().length()] = '\0';
      }
      else
         memcpy(AMS2_BIN[AMS2_ROWS], szSpace, 2);
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(0), getENTITY_ID(0), &AMS2_T_FIN_ENTITY_ID[AMS2_ROWS]);
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(1), getENTITY_ID(1), &AMS2_T_FIN_ENTITY_ID_2[AMS2_ROWS]);
      if (!getT_MIS_MCC().empty())
      {
         memcpy(AMS2_T_MIS_MCC[AMS2_ROWS], getT_MIS_MCC().data(), getT_MIS_MCC().length());
         AMS2_T_MIS_MCC[AMS2_ROWS][getT_MIS_MCC().length()] = '\0';
      }
      else
         memcpy(AMS2_T_MIS_MCC[AMS2_ROWS], szSpace, 2);
      AMS2_SYNC_INTERVAL_NO[AMS2_ROWS] = getSYNC_INTERVAL_NO();
      AMS2_CATEGORY_ID[AMS2_ROWS] = getCATEGORY_ID();
      int iSign = (bSubtractFromTotals ? -1 : 1);
      AMS2_AMT_TRAN[AMS2_ROWS] = getAMT_TRAN() * iSign;
      AMS2_AMT_SURCHARGE[AMS2_ROWS] = getAMT_SURCHARGE() * iSign;
      AMS2_AMT_POS_REIMBURSE[AMS2_ROWS] = getAMT_POS_REIMBURSE() * iSign;
      AMS2_CASHBACK_AMT[AMS2_ROWS] = getCASHBACK_AMT() * iSign;
      AMS2_TRAN_COUNT[AMS2_ROWS] = iSign;
      AMS2_TIME_AT_ISS[AMS2_ROWS] = getTIME_AT_ISS() * iSign;
      AMS2_TIME_AT_RQST_SWTCH[AMS2_ROWS] = getTIME_AT_RQST_SWTCH() * iSign;
      AMS2_AMT_FEE[AMS2_ROWS] = getAMT_FEE() * iSign;
      AMS2_ROWS++;
   }
   return 1;
  //## end dnoracledatabase::OracleAggregatorMIS2::tableUpdate%640A409C00C4.body
}

// Additional Declarations
  //## begin dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.declarations preserve=yes
  //## end dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.declarations

} // namespace dnoracledatabase

//## begin module%640A41A60044.epilog preserve=yes
//## end module%640A41A60044.epilog
