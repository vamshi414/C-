//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6064094D00F0.cm preserve=no
//## end module%6064094D00F0.cm

//## begin module%6064094D00F0.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6064094D00F0.cp

//## Module: CXOSDO16%6064094D00F0; Package specification
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Library\Dodll\CXODDO16.hpp

#ifndef CXOSDO16_h
#define CXOSDO16_h 1

//## begin module%6064094D00F0.additionalIncludes preserve=no
//## end module%6064094D00F0.additionalIncludes

//## begin module%6064094D00F0.includes preserve=yes
//## end module%6064094D00F0.includes

#ifndef CXOSST81_h
#include "CXODST81.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class FinancialTransaction;
} // namespace settlement

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class QMRInstitution;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class NPI;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::OracleDatabase_CAT%44141ACC02DE
namespace oracledatabase {
class OracleDatabase;

} // namespace oracledatabase

//## begin module%6064094D00F0.declarations preserve=no
//## end module%6064094D00F0.declarations

//## begin module%6064094D00F0.additionalDeclarations preserve=yes
//## end module%6064094D00F0.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

//## begin dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.preface preserve=yes
//## end dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.preface

//## Class: OracleMonthlyCardHolder%60640BD3004E
//## Category: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
//## Subsystem: DODLL%444917C7035B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%60640FF6002D;monitor::UseCase { -> F}
//## Uses: <unnamed>%606410030065;IF::Trace { -> F}
//## Uses: <unnamed>%60641014024C;oracledatabase::OracleDatabase { -> F}
//## Uses: <unnamed>%60641A4B0330;settlement::FinancialTransaction { -> F}
//## Uses: <unnamed>%60642051021C;configuration::QMRInstitution { -> F}
//## Uses: <unnamed>%6064A3AC0030;reusable::NPI { -> F}

class DllExport OracleMonthlyCardHolder : public settlement::MonthlyCardHolder  //## Inherits: <unnamed>%60640FE5023D
{
  //## begin dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.initialDeclarations preserve=yes
  //## end dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.initialDeclarations

  public:
    //## Constructors (generated)
      OracleMonthlyCardHolder();

    //## Destructor (generated)
      virtual ~OracleMonthlyCardHolder();


    //## Other Operations (specified)
      //## Operation: add%60641A030123
      virtual bool add (const FinancialTransaction& hFinancialTransaction);

      //## Operation: checkResult%6064103402A7
      int checkResult ();

      //## Operation: commit%606410240261
      virtual bool commit ();

      //## Operation: lockTables%6064103C019F
      void lockTables ();

    // Additional Public Declarations
      //## begin dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.public preserve=yes
      //## end dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.public

  protected:
    // Additional Protected Declarations
      //## begin dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.protected preserve=yes
      //## end dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.protected

  private:
    // Additional Private Declarations
      //## begin dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.private preserve=yes
      //## end dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Transaction%6064106102B0
      //## begin dnoracledatabase::OracleMonthlyCardHolder::Transaction%6064106102B0.attr preserve=no  private: long {U} 
      long m_lTransaction;
      //## end dnoracledatabase::OracleMonthlyCardHolder::Transaction%6064106102B0.attr

    // Additional Implementation Declarations
      //## begin dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.implementation preserve=yes
      //## end dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.implementation

};

//## begin dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.postscript preserve=yes
//## end dnoracledatabase::OracleMonthlyCardHolder%60640BD3004E.postscript

} // namespace dnoracledatabase

//## begin module%6064094D00F0.epilog preserve=yes
//## end module%6064094D00F0.epilog


#endif
