
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[13];
};
static const struct sqlcxp sqlfpn =
{
    12,
    "CXOSDO15.sqx"
};


static unsigned int sqlctx = 306150;


static struct sqlexd {
   unsigned int   sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
            void  **sqphsv;
   unsigned int   *sqphsl;
            int   *sqphss;
            void  **sqpind;
            int   *sqpins;
   unsigned int   *sqparm;
   unsigned int   **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
              int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
   unsigned int   sqlpfmem;
            void  *sqhstv[52];
   unsigned int   sqhstl[52];
            int   sqhsts[52];
            void  *sqindv[52];
            int   sqinds[52];
   unsigned int   sqharm[52];
   unsigned int   *sqharc[52];
   unsigned short  sqadto[52];
   unsigned short  sqtdso[52];
} sqlstm = {13,52};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(unsigned char *, signed int *); }

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{13,4130,178,8,0,
5,0,0,1,0,0,17,177,0,0,1,1,0,1,0,1,97,0,0,
24,0,0,1,0,0,21,181,0,0,52,52,0,1,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,
0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,
0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,
4,0,0,1,3,0,0,1,3,0,0,1,4,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,
97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,
1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,97,0,0,1,4,0,
0,1,3,0,0,1,3,0,0,1,4,0,0,
};


//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%606409130160.cm preserve=no
//## end module%606409130160.cm

//## begin module%606409130160.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%606409130160.cp

//## Module: CXOSDO15%606409130160; Package body
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Library\Dodll\CXOSDO15.sqx

//## begin module%606409130160.additionalIncludes preserve=no
//## end module%606409130160.additionalIncludes

//## begin module%606409130160.includes preserve=yes
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
//## end module%606409130160.includes

#ifndef CXOSPO01_h
#include "CXODPO01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDO15_h
#include "CXODDO15.hpp"
#endif


//## begin module%606409130160.declarations preserve=no
//## end module%606409130160.declarations

//## begin module%606409130160.additionalDeclarations preserve=yes
/* EXEC SQL BEGIN DECLARE SECTION; */ 

       char QMR_YEAR_MONTH[512][7];          
       char QMR_INST_ID[512][12];
       char QMR_ENTITY_ROLE[512][2];                
       char QMR_BIN[512][12];                 
       char QMR_TOKEN_REQUESTOR_ID[512][12];  
       char QMR_NETWORK_ID[512][4];          
       char QMR_FUNCTION_TYPE[512][3];       
       char QMR_ACCT_TYPES_ISS[512][5];      
       char QMR_MSG_CLASS[512][2];           
       char QMR_PRE_AUTH[512][2];            
       char QMR_TERM_CLASS[512][3];          
       char QMR_COUNTRY_ISS_INST[512][4];              
       char QMR_COUNTRY_ACQ_INST[512][4];              
       char QMR_ONUS_FLG[512][2];                      
       char QMR_AUTHENTICATED[512][2];                 
       char QMR_POS_CRD_DAT_IN_MOD[512][2];            
       char QMR_CUR_TRAN[512][4];                      
       char QMR_MERCH_TYPE[512][5];
       char QMR_NETWORK_TRAN_TYPE[512][3];
       char QMR_CUR_CASHBACK[512][4];
       char QMR_POS_CRDHLDR_PRESNT[512][2];
       char QMR_PAYMENT_TYPE_IND[512][4];
       double QMR_AMT_TRAN[512];                      
       int QMR_TRAN_COUNT[512];
       double QMR_AMT_CASHBACK[512];
       int QMR_CASHBACK_COUNT[512];
       int QMR_ROWS;                 
       char QMR_MERGE[2048];
/* EXEC SQL DECLARE QMR_STATEMENT STATEMENT; */ 

/* EXEC SQL END DECLARE SECTION; */ 

//## end module%606409130160.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

// Class dnoracledatabase::OracleMonthlyTotals 

OracleMonthlyTotals::OracleMonthlyTotals()
  //## begin OracleMonthlyTotals::OracleMonthlyTotals%606409A6000D_const.hasinit preserve=no
      : m_lTransaction(-1)
  //## end OracleMonthlyTotals::OracleMonthlyTotals%606409A6000D_const.hasinit
  //## begin OracleMonthlyTotals::OracleMonthlyTotals%606409A6000D_const.initialization preserve=yes
  //## end OracleMonthlyTotals::OracleMonthlyTotals%606409A6000D_const.initialization
{
  //## begin dnoracledatabase::OracleMonthlyTotals::OracleMonthlyTotals%606409A6000D_const.body preserve=yes
   memcpy(m_sID,"DO15",4);
   QMR_ROWS =0;
   string strQualifier(Database::instance()->qualifier());
   memcpy(QMR_MERGE,"MERGE INTO ",11);
   memcpy(QMR_MERGE + 11,strQualifier.data(),strQualifier.length());

   strcpy(QMR_MERGE + 11 + strQualifier.length(),".T_QMR_TOTAL USING DUAL ON ("
     "YEAR_MONTH = ? AND INST_ID = ? AND ENTITY_ROLE = ? AND BIN = ? "
     "AND TOKEN_REQUESTOR_ID = ? AND NETWORK_ID = ? AND FUNCTION_TYPE = ? AND "
     "ACCT_TYPES_ISS = ? AND MSG_CLASS = ? AND PRE_AUTH = ? AND TERM_CLASS = ?  "
     "AND COUNTRY_ISS_INST = ?  AND COUNTRY_ACQ_INST = ? AND "
     "ONUS_FLG = ?  AND AUTHENTICATED = ? AND POS_CRD_DAT_IN_MOD = ? AND "
     "CUR_TRAN = ? AND MERCH_TYPE = ? AND NETWORK_TRAN_TYPE = ? AND CUR_CASHBACK = ? AND POS_CRDHLDR_PRESNT = ? AND PAYMENT_TYPE_IND = ?) WHEN MATCHED THEN UPDATE SET AMT_TRAN = AMT_TRAN + ? , "
     "TRAN_COUNT = TRAN_COUNT + ? , CASHBACK_COUNT = CASHBACK_COUNT + ? , AMT_CASHBACK = AMT_CASHBACK + ? WHEN NOT MATCHED THEN INSERT(YEAR_MONTH,"
     "INST_ID,ENTITY_ROLE,BIN,TOKEN_REQUESTOR_ID,NETWORK_ID,FUNCTION_TYPE,ACCT_TYPES_ISS,"
     "MSG_CLASS,PRE_AUTH,TERM_CLASS,COUNTRY_ISS_INST,COUNTRY_ACQ_INST,ONUS_FLG,"
     "AUTHENTICATED,POS_CRD_DAT_IN_MOD,CUR_TRAN,MERCH_TYPE,NETWORK_TRAN_TYPE,CUR_CASHBACK,POS_CRDHLDR_PRESNT,PAYMENT_TYPE_IND,AMT_TRAN,TRAN_COUNT,CASHBACK_COUNT,AMT_CASHBACK) VALUES "
     "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
     int i = 0;
     size_t pos = 0;
     char szTemp[7];
     string strSQL(QMR_MERGE);
     while ((pos = strSQL.find('?')) != string::npos)
      strSQL.replace(pos,1,szTemp,snprintf(szTemp,sizeof(szTemp),":p%d",1000 + i++));
      memcpy(QMR_MERGE,strSQL.data(),strSQL.length());
  //## end dnoracledatabase::OracleMonthlyTotals::OracleMonthlyTotals%606409A6000D_const.body
}


OracleMonthlyTotals::~OracleMonthlyTotals()
{
  //## begin dnoracledatabase::OracleMonthlyTotals::~OracleMonthlyTotals%606409A6000D_dest.body preserve=yes
  //## end dnoracledatabase::OracleMonthlyTotals::~OracleMonthlyTotals%606409A6000D_dest.body
}



//## Other Operations (implementation)
int OracleMonthlyTotals::checkResult ()
{
  //## begin dnoracledatabase::OracleMonthlyTotals::checkResult%60640A43027E.body preserve=yes
     switch (sqlca.sqlcode)
   {
      case 0:
         UseCase::addItem();
         return 1;
      case 100:
      case 1403:
         return 0;
      case -51:
      case -54:
      case -99999913:
         UseCase::add("DEADLOCK");
         break;
      case -1012:
      case -2396:
      case -3113:
      case -3114:
      case -3135:
         UseCase::add("CONNECT");
         Database::instance()->setState(Database::DISCONNECTED);
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            Database::instance()->traceSQLError((void*)&sqlca,m_sID,m_strDBAccess.c_str());
            UseCase::addItem();
            return 1;
         }
         else
            UseCase::add("DBERROR");
   }
   QMR_ROWS =0;
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca, m_sID,m_strDBAccess.c_str());
   return -1;
  //## end dnoracledatabase::OracleMonthlyTotals::checkResult%60640A43027E.body
}

bool OracleMonthlyTotals::commit ()
{
  //## begin dnoracledatabase::OracleMonthlyTotals::commit%60640A190385.body preserve=yes
  if(QMR_ROWS ==0)
     return true;
  /* EXEC SQL PREPARE QMR_STATEMENT FROM :QMR_MERGE; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 13;
  sqlstm.arrsiz = 1;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "";
  sqlstm.iters = (unsigned int  )1;
  sqlstm.offset = (unsigned int  )5;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)4352;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqhstv[0] = (         void  *)QMR_MERGE;
  sqlstm.sqhstl[0] = (unsigned int  )2048;
  sqlstm.sqhsts[0] = (         int  )0;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


  int iRC= checkResult();
  if(iRC == -1)
     return false;
  /* EXEC SQL FOR :QMR_ROWS 
       EXECUTE  QMR_STATEMENT
       USING
              :QMR_YEAR_MONTH,
              :QMR_INST_ID,
              :QMR_ENTITY_ROLE,
              :QMR_BIN,
              :QMR_TOKEN_REQUESTOR_ID,
              :QMR_NETWORK_ID,
              :QMR_FUNCTION_TYPE,
              :QMR_ACCT_TYPES_ISS,
              :QMR_MSG_CLASS,
              :QMR_PRE_AUTH,
              :QMR_TERM_CLASS,
              :QMR_COUNTRY_ISS_INST,
              :QMR_COUNTRY_ACQ_INST,
              :QMR_ONUS_FLG,
              :QMR_AUTHENTICATED,
              :QMR_POS_CRD_DAT_IN_MOD,
              :QMR_CUR_TRAN,
              :QMR_MERCH_TYPE,
              :QMR_NETWORK_TRAN_TYPE,
              :QMR_CUR_CASHBACK,
              :QMR_POS_CRDHLDR_PRESNT,
              :QMR_PAYMENT_TYPE_IND,
              :QMR_AMT_TRAN,
              :QMR_TRAN_COUNT,
              :QMR_CASHBACK_COUNT,
              :QMR_AMT_CASHBACK,
              :QMR_YEAR_MONTH,
              :QMR_INST_ID,
              :QMR_ENTITY_ROLE,
              :QMR_BIN,
              :QMR_TOKEN_REQUESTOR_ID,
              :QMR_NETWORK_ID,
              :QMR_FUNCTION_TYPE,
              :QMR_ACCT_TYPES_ISS,
              :QMR_MSG_CLASS,
              :QMR_PRE_AUTH,
              :QMR_TERM_CLASS,
              :QMR_COUNTRY_ISS_INST,
              :QMR_COUNTRY_ACQ_INST,
              :QMR_ONUS_FLG,
              :QMR_AUTHENTICATED,
              :QMR_POS_CRD_DAT_IN_MOD,
              :QMR_CUR_TRAN,
              :QMR_MERCH_TYPE,
              :QMR_NETWORK_TRAN_TYPE,
              :QMR_CUR_CASHBACK,
              :QMR_POS_CRDHLDR_PRESNT,
              :QMR_PAYMENT_TYPE_IND,
              :QMR_AMT_TRAN,
              :QMR_TRAN_COUNT,
              :QMR_CASHBACK_COUNT,
              :QMR_AMT_CASHBACK; */ 

{
  struct sqlexd sqlstm;
  sqlstm.sqlvsn = 13;
  sqlstm.arrsiz = 52;
  sqlstm.sqladtp = &sqladt;
  sqlstm.sqltdsp = &sqltds;
  sqlstm.stmt = "";
  sqlstm.iters = (unsigned int  )QMR_ROWS;
  sqlstm.offset = (unsigned int  )24;
  sqlstm.cud = sqlcud0;
  sqlstm.sqlest = (unsigned char  *)&sqlca;
  sqlstm.sqlety = (unsigned short)4352;
  sqlstm.occurs = (unsigned int  )0;
  sqlstm.sqhstv[0] = (         void  *)QMR_YEAR_MONTH;
  sqlstm.sqhstl[0] = (unsigned int  )7;
  sqlstm.sqhsts[0] = (         int  )7;
  sqlstm.sqindv[0] = (         void  *)0;
  sqlstm.sqinds[0] = (         int  )0;
  sqlstm.sqharm[0] = (unsigned int  )0;
  sqlstm.sqharc[0] = (unsigned int   *)0;
  sqlstm.sqadto[0] = (unsigned short )0;
  sqlstm.sqtdso[0] = (unsigned short )0;
  sqlstm.sqhstv[1] = (         void  *)QMR_INST_ID;
  sqlstm.sqhstl[1] = (unsigned int  )12;
  sqlstm.sqhsts[1] = (         int  )12;
  sqlstm.sqindv[1] = (         void  *)0;
  sqlstm.sqinds[1] = (         int  )0;
  sqlstm.sqharm[1] = (unsigned int  )0;
  sqlstm.sqharc[1] = (unsigned int   *)0;
  sqlstm.sqadto[1] = (unsigned short )0;
  sqlstm.sqtdso[1] = (unsigned short )0;
  sqlstm.sqhstv[2] = (         void  *)QMR_ENTITY_ROLE;
  sqlstm.sqhstl[2] = (unsigned int  )2;
  sqlstm.sqhsts[2] = (         int  )2;
  sqlstm.sqindv[2] = (         void  *)0;
  sqlstm.sqinds[2] = (         int  )0;
  sqlstm.sqharm[2] = (unsigned int  )0;
  sqlstm.sqharc[2] = (unsigned int   *)0;
  sqlstm.sqadto[2] = (unsigned short )0;
  sqlstm.sqtdso[2] = (unsigned short )0;
  sqlstm.sqhstv[3] = (         void  *)QMR_BIN;
  sqlstm.sqhstl[3] = (unsigned int  )12;
  sqlstm.sqhsts[3] = (         int  )12;
  sqlstm.sqindv[3] = (         void  *)0;
  sqlstm.sqinds[3] = (         int  )0;
  sqlstm.sqharm[3] = (unsigned int  )0;
  sqlstm.sqharc[3] = (unsigned int   *)0;
  sqlstm.sqadto[3] = (unsigned short )0;
  sqlstm.sqtdso[3] = (unsigned short )0;
  sqlstm.sqhstv[4] = (         void  *)QMR_TOKEN_REQUESTOR_ID;
  sqlstm.sqhstl[4] = (unsigned int  )12;
  sqlstm.sqhsts[4] = (         int  )12;
  sqlstm.sqindv[4] = (         void  *)0;
  sqlstm.sqinds[4] = (         int  )0;
  sqlstm.sqharm[4] = (unsigned int  )0;
  sqlstm.sqharc[4] = (unsigned int   *)0;
  sqlstm.sqadto[4] = (unsigned short )0;
  sqlstm.sqtdso[4] = (unsigned short )0;
  sqlstm.sqhstv[5] = (         void  *)QMR_NETWORK_ID;
  sqlstm.sqhstl[5] = (unsigned int  )4;
  sqlstm.sqhsts[5] = (         int  )4;
  sqlstm.sqindv[5] = (         void  *)0;
  sqlstm.sqinds[5] = (         int  )0;
  sqlstm.sqharm[5] = (unsigned int  )0;
  sqlstm.sqharc[5] = (unsigned int   *)0;
  sqlstm.sqadto[5] = (unsigned short )0;
  sqlstm.sqtdso[5] = (unsigned short )0;
  sqlstm.sqhstv[6] = (         void  *)QMR_FUNCTION_TYPE;
  sqlstm.sqhstl[6] = (unsigned int  )3;
  sqlstm.sqhsts[6] = (         int  )3;
  sqlstm.sqindv[6] = (         void  *)0;
  sqlstm.sqinds[6] = (         int  )0;
  sqlstm.sqharm[6] = (unsigned int  )0;
  sqlstm.sqharc[6] = (unsigned int   *)0;
  sqlstm.sqadto[6] = (unsigned short )0;
  sqlstm.sqtdso[6] = (unsigned short )0;
  sqlstm.sqhstv[7] = (         void  *)QMR_ACCT_TYPES_ISS;
  sqlstm.sqhstl[7] = (unsigned int  )5;
  sqlstm.sqhsts[7] = (         int  )5;
  sqlstm.sqindv[7] = (         void  *)0;
  sqlstm.sqinds[7] = (         int  )0;
  sqlstm.sqharm[7] = (unsigned int  )0;
  sqlstm.sqharc[7] = (unsigned int   *)0;
  sqlstm.sqadto[7] = (unsigned short )0;
  sqlstm.sqtdso[7] = (unsigned short )0;
  sqlstm.sqhstv[8] = (         void  *)QMR_MSG_CLASS;
  sqlstm.sqhstl[8] = (unsigned int  )2;
  sqlstm.sqhsts[8] = (         int  )2;
  sqlstm.sqindv[8] = (         void  *)0;
  sqlstm.sqinds[8] = (         int  )0;
  sqlstm.sqharm[8] = (unsigned int  )0;
  sqlstm.sqharc[8] = (unsigned int   *)0;
  sqlstm.sqadto[8] = (unsigned short )0;
  sqlstm.sqtdso[8] = (unsigned short )0;
  sqlstm.sqhstv[9] = (         void  *)QMR_PRE_AUTH;
  sqlstm.sqhstl[9] = (unsigned int  )2;
  sqlstm.sqhsts[9] = (         int  )2;
  sqlstm.sqindv[9] = (         void  *)0;
  sqlstm.sqinds[9] = (         int  )0;
  sqlstm.sqharm[9] = (unsigned int  )0;
  sqlstm.sqharc[9] = (unsigned int   *)0;
  sqlstm.sqadto[9] = (unsigned short )0;
  sqlstm.sqtdso[9] = (unsigned short )0;
  sqlstm.sqhstv[10] = (         void  *)QMR_TERM_CLASS;
  sqlstm.sqhstl[10] = (unsigned int  )3;
  sqlstm.sqhsts[10] = (         int  )3;
  sqlstm.sqindv[10] = (         void  *)0;
  sqlstm.sqinds[10] = (         int  )0;
  sqlstm.sqharm[10] = (unsigned int  )0;
  sqlstm.sqharc[10] = (unsigned int   *)0;
  sqlstm.sqadto[10] = (unsigned short )0;
  sqlstm.sqtdso[10] = (unsigned short )0;
  sqlstm.sqhstv[11] = (         void  *)QMR_COUNTRY_ISS_INST;
  sqlstm.sqhstl[11] = (unsigned int  )4;
  sqlstm.sqhsts[11] = (         int  )4;
  sqlstm.sqindv[11] = (         void  *)0;
  sqlstm.sqinds[11] = (         int  )0;
  sqlstm.sqharm[11] = (unsigned int  )0;
  sqlstm.sqharc[11] = (unsigned int   *)0;
  sqlstm.sqadto[11] = (unsigned short )0;
  sqlstm.sqtdso[11] = (unsigned short )0;
  sqlstm.sqhstv[12] = (         void  *)QMR_COUNTRY_ACQ_INST;
  sqlstm.sqhstl[12] = (unsigned int  )4;
  sqlstm.sqhsts[12] = (         int  )4;
  sqlstm.sqindv[12] = (         void  *)0;
  sqlstm.sqinds[12] = (         int  )0;
  sqlstm.sqharm[12] = (unsigned int  )0;
  sqlstm.sqharc[12] = (unsigned int   *)0;
  sqlstm.sqadto[12] = (unsigned short )0;
  sqlstm.sqtdso[12] = (unsigned short )0;
  sqlstm.sqhstv[13] = (         void  *)QMR_ONUS_FLG;
  sqlstm.sqhstl[13] = (unsigned int  )2;
  sqlstm.sqhsts[13] = (         int  )2;
  sqlstm.sqindv[13] = (         void  *)0;
  sqlstm.sqinds[13] = (         int  )0;
  sqlstm.sqharm[13] = (unsigned int  )0;
  sqlstm.sqharc[13] = (unsigned int   *)0;
  sqlstm.sqadto[13] = (unsigned short )0;
  sqlstm.sqtdso[13] = (unsigned short )0;
  sqlstm.sqhstv[14] = (         void  *)QMR_AUTHENTICATED;
  sqlstm.sqhstl[14] = (unsigned int  )2;
  sqlstm.sqhsts[14] = (         int  )2;
  sqlstm.sqindv[14] = (         void  *)0;
  sqlstm.sqinds[14] = (         int  )0;
  sqlstm.sqharm[14] = (unsigned int  )0;
  sqlstm.sqharc[14] = (unsigned int   *)0;
  sqlstm.sqadto[14] = (unsigned short )0;
  sqlstm.sqtdso[14] = (unsigned short )0;
  sqlstm.sqhstv[15] = (         void  *)QMR_POS_CRD_DAT_IN_MOD;
  sqlstm.sqhstl[15] = (unsigned int  )2;
  sqlstm.sqhsts[15] = (         int  )2;
  sqlstm.sqindv[15] = (         void  *)0;
  sqlstm.sqinds[15] = (         int  )0;
  sqlstm.sqharm[15] = (unsigned int  )0;
  sqlstm.sqharc[15] = (unsigned int   *)0;
  sqlstm.sqadto[15] = (unsigned short )0;
  sqlstm.sqtdso[15] = (unsigned short )0;
  sqlstm.sqhstv[16] = (         void  *)QMR_CUR_TRAN;
  sqlstm.sqhstl[16] = (unsigned int  )4;
  sqlstm.sqhsts[16] = (         int  )4;
  sqlstm.sqindv[16] = (         void  *)0;
  sqlstm.sqinds[16] = (         int  )0;
  sqlstm.sqharm[16] = (unsigned int  )0;
  sqlstm.sqharc[16] = (unsigned int   *)0;
  sqlstm.sqadto[16] = (unsigned short )0;
  sqlstm.sqtdso[16] = (unsigned short )0;
  sqlstm.sqhstv[17] = (         void  *)QMR_MERCH_TYPE;
  sqlstm.sqhstl[17] = (unsigned int  )5;
  sqlstm.sqhsts[17] = (         int  )5;
  sqlstm.sqindv[17] = (         void  *)0;
  sqlstm.sqinds[17] = (         int  )0;
  sqlstm.sqharm[17] = (unsigned int  )0;
  sqlstm.sqharc[17] = (unsigned int   *)0;
  sqlstm.sqadto[17] = (unsigned short )0;
  sqlstm.sqtdso[17] = (unsigned short )0;
  sqlstm.sqhstv[18] = (         void  *)QMR_NETWORK_TRAN_TYPE;
  sqlstm.sqhstl[18] = (unsigned int  )3;
  sqlstm.sqhsts[18] = (         int  )3;
  sqlstm.sqindv[18] = (         void  *)0;
  sqlstm.sqinds[18] = (         int  )0;
  sqlstm.sqharm[18] = (unsigned int  )0;
  sqlstm.sqharc[18] = (unsigned int   *)0;
  sqlstm.sqadto[18] = (unsigned short )0;
  sqlstm.sqtdso[18] = (unsigned short )0;
  sqlstm.sqhstv[19] = (         void  *)QMR_CUR_CASHBACK;
  sqlstm.sqhstl[19] = (unsigned int  )4;
  sqlstm.sqhsts[19] = (         int  )4;
  sqlstm.sqindv[19] = (         void  *)0;
  sqlstm.sqinds[19] = (         int  )0;
  sqlstm.sqharm[19] = (unsigned int  )0;
  sqlstm.sqharc[19] = (unsigned int   *)0;
  sqlstm.sqadto[19] = (unsigned short )0;
  sqlstm.sqtdso[19] = (unsigned short )0;
  sqlstm.sqhstv[20] = (         void  *)QMR_POS_CRDHLDR_PRESNT;
  sqlstm.sqhstl[20] = (unsigned int  )2;
  sqlstm.sqhsts[20] = (         int  )2;
  sqlstm.sqindv[20] = (         void  *)0;
  sqlstm.sqinds[20] = (         int  )0;
  sqlstm.sqharm[20] = (unsigned int  )0;
  sqlstm.sqharc[20] = (unsigned int   *)0;
  sqlstm.sqadto[20] = (unsigned short )0;
  sqlstm.sqtdso[20] = (unsigned short )0;
  sqlstm.sqhstv[21] = (         void  *)QMR_PAYMENT_TYPE_IND;
  sqlstm.sqhstl[21] = (unsigned int  )4;
  sqlstm.sqhsts[21] = (         int  )4;
  sqlstm.sqindv[21] = (         void  *)0;
  sqlstm.sqinds[21] = (         int  )0;
  sqlstm.sqharm[21] = (unsigned int  )0;
  sqlstm.sqharc[21] = (unsigned int   *)0;
  sqlstm.sqadto[21] = (unsigned short )0;
  sqlstm.sqtdso[21] = (unsigned short )0;
  sqlstm.sqhstv[22] = (         void  *)QMR_AMT_TRAN;
  sqlstm.sqhstl[22] = (unsigned int  )sizeof(double);
  sqlstm.sqhsts[22] = (         int  )sizeof(double);
  sqlstm.sqindv[22] = (         void  *)0;
  sqlstm.sqinds[22] = (         int  )0;
  sqlstm.sqharm[22] = (unsigned int  )0;
  sqlstm.sqharc[22] = (unsigned int   *)0;
  sqlstm.sqadto[22] = (unsigned short )0;
  sqlstm.sqtdso[22] = (unsigned short )0;
  sqlstm.sqhstv[23] = (         void  *)QMR_TRAN_COUNT;
  sqlstm.sqhstl[23] = (unsigned int  )sizeof(int);
  sqlstm.sqhsts[23] = (         int  )sizeof(int);
  sqlstm.sqindv[23] = (         void  *)0;
  sqlstm.sqinds[23] = (         int  )0;
  sqlstm.sqharm[23] = (unsigned int  )0;
  sqlstm.sqharc[23] = (unsigned int   *)0;
  sqlstm.sqadto[23] = (unsigned short )0;
  sqlstm.sqtdso[23] = (unsigned short )0;
  sqlstm.sqhstv[24] = (         void  *)QMR_CASHBACK_COUNT;
  sqlstm.sqhstl[24] = (unsigned int  )sizeof(int);
  sqlstm.sqhsts[24] = (         int  )sizeof(int);
  sqlstm.sqindv[24] = (         void  *)0;
  sqlstm.sqinds[24] = (         int  )0;
  sqlstm.sqharm[24] = (unsigned int  )0;
  sqlstm.sqharc[24] = (unsigned int   *)0;
  sqlstm.sqadto[24] = (unsigned short )0;
  sqlstm.sqtdso[24] = (unsigned short )0;
  sqlstm.sqhstv[25] = (         void  *)QMR_AMT_CASHBACK;
  sqlstm.sqhstl[25] = (unsigned int  )sizeof(double);
  sqlstm.sqhsts[25] = (         int  )sizeof(double);
  sqlstm.sqindv[25] = (         void  *)0;
  sqlstm.sqinds[25] = (         int  )0;
  sqlstm.sqharm[25] = (unsigned int  )0;
  sqlstm.sqharc[25] = (unsigned int   *)0;
  sqlstm.sqadto[25] = (unsigned short )0;
  sqlstm.sqtdso[25] = (unsigned short )0;
  sqlstm.sqhstv[26] = (         void  *)QMR_YEAR_MONTH;
  sqlstm.sqhstl[26] = (unsigned int  )7;
  sqlstm.sqhsts[26] = (         int  )7;
  sqlstm.sqindv[26] = (         void  *)0;
  sqlstm.sqinds[26] = (         int  )0;
  sqlstm.sqharm[26] = (unsigned int  )0;
  sqlstm.sqharc[26] = (unsigned int   *)0;
  sqlstm.sqadto[26] = (unsigned short )0;
  sqlstm.sqtdso[26] = (unsigned short )0;
  sqlstm.sqhstv[27] = (         void  *)QMR_INST_ID;
  sqlstm.sqhstl[27] = (unsigned int  )12;
  sqlstm.sqhsts[27] = (         int  )12;
  sqlstm.sqindv[27] = (         void  *)0;
  sqlstm.sqinds[27] = (         int  )0;
  sqlstm.sqharm[27] = (unsigned int  )0;
  sqlstm.sqharc[27] = (unsigned int   *)0;
  sqlstm.sqadto[27] = (unsigned short )0;
  sqlstm.sqtdso[27] = (unsigned short )0;
  sqlstm.sqhstv[28] = (         void  *)QMR_ENTITY_ROLE;
  sqlstm.sqhstl[28] = (unsigned int  )2;
  sqlstm.sqhsts[28] = (         int  )2;
  sqlstm.sqindv[28] = (         void  *)0;
  sqlstm.sqinds[28] = (         int  )0;
  sqlstm.sqharm[28] = (unsigned int  )0;
  sqlstm.sqharc[28] = (unsigned int   *)0;
  sqlstm.sqadto[28] = (unsigned short )0;
  sqlstm.sqtdso[28] = (unsigned short )0;
  sqlstm.sqhstv[29] = (         void  *)QMR_BIN;
  sqlstm.sqhstl[29] = (unsigned int  )12;
  sqlstm.sqhsts[29] = (         int  )12;
  sqlstm.sqindv[29] = (         void  *)0;
  sqlstm.sqinds[29] = (         int  )0;
  sqlstm.sqharm[29] = (unsigned int  )0;
  sqlstm.sqharc[29] = (unsigned int   *)0;
  sqlstm.sqadto[29] = (unsigned short )0;
  sqlstm.sqtdso[29] = (unsigned short )0;
  sqlstm.sqhstv[30] = (         void  *)QMR_TOKEN_REQUESTOR_ID;
  sqlstm.sqhstl[30] = (unsigned int  )12;
  sqlstm.sqhsts[30] = (         int  )12;
  sqlstm.sqindv[30] = (         void  *)0;
  sqlstm.sqinds[30] = (         int  )0;
  sqlstm.sqharm[30] = (unsigned int  )0;
  sqlstm.sqharc[30] = (unsigned int   *)0;
  sqlstm.sqadto[30] = (unsigned short )0;
  sqlstm.sqtdso[30] = (unsigned short )0;
  sqlstm.sqhstv[31] = (         void  *)QMR_NETWORK_ID;
  sqlstm.sqhstl[31] = (unsigned int  )4;
  sqlstm.sqhsts[31] = (         int  )4;
  sqlstm.sqindv[31] = (         void  *)0;
  sqlstm.sqinds[31] = (         int  )0;
  sqlstm.sqharm[31] = (unsigned int  )0;
  sqlstm.sqharc[31] = (unsigned int   *)0;
  sqlstm.sqadto[31] = (unsigned short )0;
  sqlstm.sqtdso[31] = (unsigned short )0;
  sqlstm.sqhstv[32] = (         void  *)QMR_FUNCTION_TYPE;
  sqlstm.sqhstl[32] = (unsigned int  )3;
  sqlstm.sqhsts[32] = (         int  )3;
  sqlstm.sqindv[32] = (         void  *)0;
  sqlstm.sqinds[32] = (         int  )0;
  sqlstm.sqharm[32] = (unsigned int  )0;
  sqlstm.sqharc[32] = (unsigned int   *)0;
  sqlstm.sqadto[32] = (unsigned short )0;
  sqlstm.sqtdso[32] = (unsigned short )0;
  sqlstm.sqhstv[33] = (         void  *)QMR_ACCT_TYPES_ISS;
  sqlstm.sqhstl[33] = (unsigned int  )5;
  sqlstm.sqhsts[33] = (         int  )5;
  sqlstm.sqindv[33] = (         void  *)0;
  sqlstm.sqinds[33] = (         int  )0;
  sqlstm.sqharm[33] = (unsigned int  )0;
  sqlstm.sqharc[33] = (unsigned int   *)0;
  sqlstm.sqadto[33] = (unsigned short )0;
  sqlstm.sqtdso[33] = (unsigned short )0;
  sqlstm.sqhstv[34] = (         void  *)QMR_MSG_CLASS;
  sqlstm.sqhstl[34] = (unsigned int  )2;
  sqlstm.sqhsts[34] = (         int  )2;
  sqlstm.sqindv[34] = (         void  *)0;
  sqlstm.sqinds[34] = (         int  )0;
  sqlstm.sqharm[34] = (unsigned int  )0;
  sqlstm.sqharc[34] = (unsigned int   *)0;
  sqlstm.sqadto[34] = (unsigned short )0;
  sqlstm.sqtdso[34] = (unsigned short )0;
  sqlstm.sqhstv[35] = (         void  *)QMR_PRE_AUTH;
  sqlstm.sqhstl[35] = (unsigned int  )2;
  sqlstm.sqhsts[35] = (         int  )2;
  sqlstm.sqindv[35] = (         void  *)0;
  sqlstm.sqinds[35] = (         int  )0;
  sqlstm.sqharm[35] = (unsigned int  )0;
  sqlstm.sqharc[35] = (unsigned int   *)0;
  sqlstm.sqadto[35] = (unsigned short )0;
  sqlstm.sqtdso[35] = (unsigned short )0;
  sqlstm.sqhstv[36] = (         void  *)QMR_TERM_CLASS;
  sqlstm.sqhstl[36] = (unsigned int  )3;
  sqlstm.sqhsts[36] = (         int  )3;
  sqlstm.sqindv[36] = (         void  *)0;
  sqlstm.sqinds[36] = (         int  )0;
  sqlstm.sqharm[36] = (unsigned int  )0;
  sqlstm.sqharc[36] = (unsigned int   *)0;
  sqlstm.sqadto[36] = (unsigned short )0;
  sqlstm.sqtdso[36] = (unsigned short )0;
  sqlstm.sqhstv[37] = (         void  *)QMR_COUNTRY_ISS_INST;
  sqlstm.sqhstl[37] = (unsigned int  )4;
  sqlstm.sqhsts[37] = (         int  )4;
  sqlstm.sqindv[37] = (         void  *)0;
  sqlstm.sqinds[37] = (         int  )0;
  sqlstm.sqharm[37] = (unsigned int  )0;
  sqlstm.sqharc[37] = (unsigned int   *)0;
  sqlstm.sqadto[37] = (unsigned short )0;
  sqlstm.sqtdso[37] = (unsigned short )0;
  sqlstm.sqhstv[38] = (         void  *)QMR_COUNTRY_ACQ_INST;
  sqlstm.sqhstl[38] = (unsigned int  )4;
  sqlstm.sqhsts[38] = (         int  )4;
  sqlstm.sqindv[38] = (         void  *)0;
  sqlstm.sqinds[38] = (         int  )0;
  sqlstm.sqharm[38] = (unsigned int  )0;
  sqlstm.sqharc[38] = (unsigned int   *)0;
  sqlstm.sqadto[38] = (unsigned short )0;
  sqlstm.sqtdso[38] = (unsigned short )0;
  sqlstm.sqhstv[39] = (         void  *)QMR_ONUS_FLG;
  sqlstm.sqhstl[39] = (unsigned int  )2;
  sqlstm.sqhsts[39] = (         int  )2;
  sqlstm.sqindv[39] = (         void  *)0;
  sqlstm.sqinds[39] = (         int  )0;
  sqlstm.sqharm[39] = (unsigned int  )0;
  sqlstm.sqharc[39] = (unsigned int   *)0;
  sqlstm.sqadto[39] = (unsigned short )0;
  sqlstm.sqtdso[39] = (unsigned short )0;
  sqlstm.sqhstv[40] = (         void  *)QMR_AUTHENTICATED;
  sqlstm.sqhstl[40] = (unsigned int  )2;
  sqlstm.sqhsts[40] = (         int  )2;
  sqlstm.sqindv[40] = (         void  *)0;
  sqlstm.sqinds[40] = (         int  )0;
  sqlstm.sqharm[40] = (unsigned int  )0;
  sqlstm.sqharc[40] = (unsigned int   *)0;
  sqlstm.sqadto[40] = (unsigned short )0;
  sqlstm.sqtdso[40] = (unsigned short )0;
  sqlstm.sqhstv[41] = (         void  *)QMR_POS_CRD_DAT_IN_MOD;
  sqlstm.sqhstl[41] = (unsigned int  )2;
  sqlstm.sqhsts[41] = (         int  )2;
  sqlstm.sqindv[41] = (         void  *)0;
  sqlstm.sqinds[41] = (         int  )0;
  sqlstm.sqharm[41] = (unsigned int  )0;
  sqlstm.sqharc[41] = (unsigned int   *)0;
  sqlstm.sqadto[41] = (unsigned short )0;
  sqlstm.sqtdso[41] = (unsigned short )0;
  sqlstm.sqhstv[42] = (         void  *)QMR_CUR_TRAN;
  sqlstm.sqhstl[42] = (unsigned int  )4;
  sqlstm.sqhsts[42] = (         int  )4;
  sqlstm.sqindv[42] = (         void  *)0;
  sqlstm.sqinds[42] = (         int  )0;
  sqlstm.sqharm[42] = (unsigned int  )0;
  sqlstm.sqharc[42] = (unsigned int   *)0;
  sqlstm.sqadto[42] = (unsigned short )0;
  sqlstm.sqtdso[42] = (unsigned short )0;
  sqlstm.sqhstv[43] = (         void  *)QMR_MERCH_TYPE;
  sqlstm.sqhstl[43] = (unsigned int  )5;
  sqlstm.sqhsts[43] = (         int  )5;
  sqlstm.sqindv[43] = (         void  *)0;
  sqlstm.sqinds[43] = (         int  )0;
  sqlstm.sqharm[43] = (unsigned int  )0;
  sqlstm.sqharc[43] = (unsigned int   *)0;
  sqlstm.sqadto[43] = (unsigned short )0;
  sqlstm.sqtdso[43] = (unsigned short )0;
  sqlstm.sqhstv[44] = (         void  *)QMR_NETWORK_TRAN_TYPE;
  sqlstm.sqhstl[44] = (unsigned int  )3;
  sqlstm.sqhsts[44] = (         int  )3;
  sqlstm.sqindv[44] = (         void  *)0;
  sqlstm.sqinds[44] = (         int  )0;
  sqlstm.sqharm[44] = (unsigned int  )0;
  sqlstm.sqharc[44] = (unsigned int   *)0;
  sqlstm.sqadto[44] = (unsigned short )0;
  sqlstm.sqtdso[44] = (unsigned short )0;
  sqlstm.sqhstv[45] = (         void  *)QMR_CUR_CASHBACK;
  sqlstm.sqhstl[45] = (unsigned int  )4;
  sqlstm.sqhsts[45] = (         int  )4;
  sqlstm.sqindv[45] = (         void  *)0;
  sqlstm.sqinds[45] = (         int  )0;
  sqlstm.sqharm[45] = (unsigned int  )0;
  sqlstm.sqharc[45] = (unsigned int   *)0;
  sqlstm.sqadto[45] = (unsigned short )0;
  sqlstm.sqtdso[45] = (unsigned short )0;
  sqlstm.sqhstv[46] = (         void  *)QMR_POS_CRDHLDR_PRESNT;
  sqlstm.sqhstl[46] = (unsigned int  )2;
  sqlstm.sqhsts[46] = (         int  )2;
  sqlstm.sqindv[46] = (         void  *)0;
  sqlstm.sqinds[46] = (         int  )0;
  sqlstm.sqharm[46] = (unsigned int  )0;
  sqlstm.sqharc[46] = (unsigned int   *)0;
  sqlstm.sqadto[46] = (unsigned short )0;
  sqlstm.sqtdso[46] = (unsigned short )0;
  sqlstm.sqhstv[47] = (         void  *)QMR_PAYMENT_TYPE_IND;
  sqlstm.sqhstl[47] = (unsigned int  )4;
  sqlstm.sqhsts[47] = (         int  )4;
  sqlstm.sqindv[47] = (         void  *)0;
  sqlstm.sqinds[47] = (         int  )0;
  sqlstm.sqharm[47] = (unsigned int  )0;
  sqlstm.sqharc[47] = (unsigned int   *)0;
  sqlstm.sqadto[47] = (unsigned short )0;
  sqlstm.sqtdso[47] = (unsigned short )0;
  sqlstm.sqhstv[48] = (         void  *)QMR_AMT_TRAN;
  sqlstm.sqhstl[48] = (unsigned int  )sizeof(double);
  sqlstm.sqhsts[48] = (         int  )sizeof(double);
  sqlstm.sqindv[48] = (         void  *)0;
  sqlstm.sqinds[48] = (         int  )0;
  sqlstm.sqharm[48] = (unsigned int  )0;
  sqlstm.sqharc[48] = (unsigned int   *)0;
  sqlstm.sqadto[48] = (unsigned short )0;
  sqlstm.sqtdso[48] = (unsigned short )0;
  sqlstm.sqhstv[49] = (         void  *)QMR_TRAN_COUNT;
  sqlstm.sqhstl[49] = (unsigned int  )sizeof(int);
  sqlstm.sqhsts[49] = (         int  )sizeof(int);
  sqlstm.sqindv[49] = (         void  *)0;
  sqlstm.sqinds[49] = (         int  )0;
  sqlstm.sqharm[49] = (unsigned int  )0;
  sqlstm.sqharc[49] = (unsigned int   *)0;
  sqlstm.sqadto[49] = (unsigned short )0;
  sqlstm.sqtdso[49] = (unsigned short )0;
  sqlstm.sqhstv[50] = (         void  *)QMR_CASHBACK_COUNT;
  sqlstm.sqhstl[50] = (unsigned int  )sizeof(int);
  sqlstm.sqhsts[50] = (         int  )sizeof(int);
  sqlstm.sqindv[50] = (         void  *)0;
  sqlstm.sqinds[50] = (         int  )0;
  sqlstm.sqharm[50] = (unsigned int  )0;
  sqlstm.sqharc[50] = (unsigned int   *)0;
  sqlstm.sqadto[50] = (unsigned short )0;
  sqlstm.sqtdso[50] = (unsigned short )0;
  sqlstm.sqhstv[51] = (         void  *)QMR_AMT_CASHBACK;
  sqlstm.sqhstl[51] = (unsigned int  )sizeof(double);
  sqlstm.sqhsts[51] = (         int  )sizeof(double);
  sqlstm.sqindv[51] = (         void  *)0;
  sqlstm.sqinds[51] = (         int  )0;
  sqlstm.sqharm[51] = (unsigned int  )0;
  sqlstm.sqharc[51] = (unsigned int   *)0;
  sqlstm.sqadto[51] = (unsigned short )0;
  sqlstm.sqtdso[51] = (unsigned short )0;
  sqlstm.sqphsv = sqlstm.sqhstv;
  sqlstm.sqphsl = sqlstm.sqhstl;
  sqlstm.sqphss = sqlstm.sqhsts;
  sqlstm.sqpind = sqlstm.sqindv;
  sqlstm.sqpins = sqlstm.sqinds;
  sqlstm.sqparm = sqlstm.sqharm;
  sqlstm.sqparc = sqlstm.sqharc;
  sqlstm.sqpadto = sqlstm.sqadto;
  sqlstm.sqptdso = sqlstm.sqtdso;
  sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


   iRC= checkResult();
   if(iRC == -1)
   {
     char szTemp[5 * PERCENTLD + 7 * PERCENTF + 2 * PERCENTS];
     for(int i=0;i < QMR_ROWS; i++)
     {
        snprintf(szTemp, sizeof(szTemp), "MERGE INTO %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %d %f %d %f %s %s %s %s",
          QMR_ACCT_TYPES_ISS[i], QMR_AUTHENTICATED[i], QMR_BIN[i], QMR_COUNTRY_ACQ_INST[i], QMR_COUNTRY_ISS_INST[i],
          QMR_CUR_TRAN[i], QMR_FUNCTION_TYPE[i], QMR_INST_ID[i], QMR_MSG_CLASS[i], 
          QMR_NETWORK_ID[i], QMR_ONUS_FLG[i], QMR_POS_CRD_DAT_IN_MOD[i], QMR_PRE_AUTH[i], QMR_ENTITY_ROLE[i], QMR_TERM_CLASS[i], QMR_TOKEN_REQUESTOR_ID[i],
          QMR_YEAR_MONTH[i],QMR_MERCH_TYPE[i] , QMR_TRAN_COUNT[i], QMR_AMT_TRAN[i] , QMR_CASHBACK_COUNT[i] , QMR_AMT_CASHBACK[i], QMR_NETWORK_TRAN_TYPE[i], 
          QMR_CUR_CASHBACK[i], QMR_POS_CRDHLDR_PRESNT[i],QMR_PAYMENT_TYPE_IND[i]);
        Trace::put(szTemp);
     }
     return false;
   }    
   Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   QMR_ROWS = 0;
  return true;
  //## end dnoracledatabase::OracleMonthlyTotals::commit%60640A190385.body
}

void OracleMonthlyTotals::lockTables ()
{
  //## begin dnoracledatabase::OracleMonthlyTotals::lockTables%60640A51020E.body preserve=yes
  //## end dnoracledatabase::OracleMonthlyTotals::lockTables%60640A51020E.body
}

int OracleMonthlyTotals::tableUpdate ()
{
  //## begin dnoracledatabase::OracleMonthlyTotals::tableUpdate%606421650038.body preserve=yes
   if (getENTITY_ROLE().empty())
      return 0;
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return -1;
   if (QMR_ROWS >= 512)
         if (!commit())
            return -1;
   char szSpace[2] = {" "};
   if(!getACCT_TYPES_ISS().empty())
   {
      memcpy(QMR_ACCT_TYPES_ISS[QMR_ROWS], getACCT_TYPES_ISS().data(), getACCT_TYPES_ISS().length());
      QMR_ACCT_TYPES_ISS[QMR_ROWS][getACCT_TYPES_ISS().length()] = '\0';
   }
   else
      memcpy(QMR_ACCT_TYPES_ISS[QMR_ROWS],szSpace,2);
   QMR_AMT_TRAN[QMR_ROWS] = getAMT_TRAN();
   QMR_AMT_CASHBACK[QMR_ROWS] = getAMT_CASHBACK();
   QMR_CASHBACK_COUNT[QMR_ROWS] = getCASHBACK_COUNT();
   if(!getNETWORK_TRAN_TYPE().empty())
   {
      memcpy(QMR_NETWORK_TRAN_TYPE[QMR_ROWS],getNETWORK_TRAN_TYPE().data(),getNETWORK_TRAN_TYPE().length());
      QMR_NETWORK_TRAN_TYPE[QMR_ROWS][getNETWORK_TRAN_TYPE().length()] = '\0';
   }
   else
      memcpy(QMR_NETWORK_TRAN_TYPE[QMR_ROWS],szSpace,2);
   if(!getCUR_CASHBACK().empty())
   {
      memcpy(QMR_CUR_CASHBACK[QMR_ROWS],getCUR_CASHBACK().data(),getCUR_CASHBACK().length());
      QMR_CUR_CASHBACK[QMR_ROWS][getCUR_CASHBACK().length()] = '\0';
   }
   else
      memcpy(QMR_CUR_CASHBACK[QMR_ROWS],szSpace,2);
   if(!getAUTHENTICATED().empty())
   {
      memcpy(QMR_AUTHENTICATED[QMR_ROWS],getAUTHENTICATED().data(),getAUTHENTICATED().length());
      QMR_AUTHENTICATED[QMR_ROWS][getAUTHENTICATED().length()] = '\0';
   }
   else
      memcpy(QMR_AUTHENTICATED[QMR_ROWS],szSpace,2);
   if(!getBIN().empty())
   {
      memcpy(QMR_BIN[QMR_ROWS], getBIN().data(), getBIN().length());
      QMR_BIN[QMR_ROWS][getBIN().length()] = '\0';
   }
   else
      memcpy(QMR_BIN[QMR_ROWS],szSpace,2);
   if(!getCOUNTRY_ACQ_INST().empty())
   {
      memcpy(QMR_COUNTRY_ACQ_INST[QMR_ROWS], getCOUNTRY_ACQ_INST().data(), getCOUNTRY_ACQ_INST().length());
      QMR_COUNTRY_ACQ_INST[QMR_ROWS][getCOUNTRY_ACQ_INST().length()] = '\0';
   }
   else
      memcpy(QMR_COUNTRY_ACQ_INST[QMR_ROWS],szSpace,2);
   if(!getCOUNTRY_ISS_INST().empty())
   {
      memcpy(QMR_COUNTRY_ISS_INST[QMR_ROWS], getCOUNTRY_ISS_INST().data(), getCOUNTRY_ISS_INST().length());
      QMR_COUNTRY_ISS_INST[QMR_ROWS][getCOUNTRY_ISS_INST().length()] = '\0';
   }
   else
      memcpy(QMR_COUNTRY_ISS_INST[QMR_ROWS],szSpace,2);
   if(!getCUR_TRAN().empty())
   {
      memcpy(QMR_CUR_TRAN[QMR_ROWS], getCUR_TRAN().data(), getCUR_TRAN().length());
      QMR_CUR_TRAN[QMR_ROWS][getCUR_TRAN().length()] = '\0';
   }
   else
      memcpy(QMR_CUR_TRAN[QMR_ROWS],szSpace,2);
   if(!getFUNCTION_TYPE().empty())
   {
      memcpy(QMR_FUNCTION_TYPE[QMR_ROWS], getFUNCTION_TYPE().data(), getFUNCTION_TYPE().length());
      QMR_FUNCTION_TYPE[QMR_ROWS][getFUNCTION_TYPE().length()] = '\0';
   }
   else
      memcpy(QMR_FUNCTION_TYPE[QMR_ROWS],szSpace,2);
   if(!getINST_ID().empty())
   {
      memcpy(QMR_INST_ID[QMR_ROWS],getINST_ID().data(), getINST_ID().length());
      QMR_INST_ID[QMR_ROWS][getINST_ID().length()] = '\0';
   }
   else
      memcpy(QMR_INST_ID[QMR_ROWS],szSpace,2);
   if(!getMSG_CLASS().empty())
   {
      memcpy(QMR_MSG_CLASS[QMR_ROWS], getMSG_CLASS().data(), getMSG_CLASS().length());
      QMR_MSG_CLASS[QMR_ROWS][getMSG_CLASS().length()] = '\0';
   }
   else
      memcpy(QMR_MSG_CLASS[QMR_ROWS],szSpace,2);
   if(!getNETWORK_ID().empty())
   {
      memcpy(QMR_NETWORK_ID[QMR_ROWS], getNETWORK_ID().data(), getNETWORK_ID().length());
      QMR_NETWORK_ID[QMR_ROWS][getNETWORK_ID().length()] = '\0';
   }
   else
      memcpy(QMR_NETWORK_ID[QMR_ROWS],szSpace,2);
   if(!getONUS_FLG().empty())
   {
      memcpy(QMR_ONUS_FLG[QMR_ROWS], getONUS_FLG().data(), getONUS_FLG().length());
      QMR_ONUS_FLG[QMR_ROWS][getONUS_FLG().length()] = '\0';
   }
   else
      memcpy(QMR_ONUS_FLG[QMR_ROWS],szSpace,2);
   if(!getPOS_CRD_DAT_IN_MOD().empty())
   {
      memcpy(QMR_POS_CRD_DAT_IN_MOD[QMR_ROWS], getPOS_CRD_DAT_IN_MOD().data(), getPOS_CRD_DAT_IN_MOD().length());
      QMR_POS_CRD_DAT_IN_MOD[QMR_ROWS][getPOS_CRD_DAT_IN_MOD().length()] = '\0';
   }
   else
      memcpy(QMR_POS_CRD_DAT_IN_MOD[QMR_ROWS],szSpace,2);
   if(!getPRE_AUTH().empty())
   {
      memcpy(QMR_PRE_AUTH[QMR_ROWS], getPRE_AUTH().data(), getPRE_AUTH().length());
      QMR_PRE_AUTH[QMR_ROWS][getPRE_AUTH().length()] = '\0';
   }
   else
      memcpy(QMR_PRE_AUTH[QMR_ROWS],szSpace,2);
   if(!getENTITY_ROLE().empty())
   {
      memcpy(QMR_ENTITY_ROLE[QMR_ROWS], getENTITY_ROLE().data(), getENTITY_ROLE().length());
      QMR_ENTITY_ROLE[QMR_ROWS][getENTITY_ROLE().length()] = '\0';
   }
   else
      memcpy(QMR_ENTITY_ROLE[QMR_ROWS],szSpace,2);
   if(!getTERM_CLASS().empty())
   {
      memcpy(QMR_TERM_CLASS[QMR_ROWS], getTERM_CLASS().data(), getTERM_CLASS().length());
      QMR_TERM_CLASS[QMR_ROWS][getTERM_CLASS().length()] = '\0';
   }
   else
      memcpy(QMR_TERM_CLASS[QMR_ROWS],szSpace,2);
   if(!getTOKEN_REQUESTOR_ID().empty())
   {
      memcpy(QMR_TOKEN_REQUESTOR_ID[QMR_ROWS], getTOKEN_REQUESTOR_ID().data(), getTOKEN_REQUESTOR_ID().length());
      QMR_TOKEN_REQUESTOR_ID[QMR_ROWS][getTOKEN_REQUESTOR_ID().length()] = '\0';
   }
   else
      memcpy(QMR_TOKEN_REQUESTOR_ID[QMR_ROWS],szSpace,2);
   QMR_TRAN_COUNT[QMR_ROWS] = getTRAN_COUNT();
   if(!getYEAR_MONTH().empty())
   {
      memcpy(QMR_YEAR_MONTH[QMR_ROWS], getYEAR_MONTH().data(), getYEAR_MONTH().length());
      QMR_YEAR_MONTH[QMR_ROWS][getYEAR_MONTH().length()] = '\0';
   }
   else
      memcpy(QMR_YEAR_MONTH[QMR_ROWS],szSpace,2);
   if(!getMERCH_TYPE().empty())
   {
      memcpy(QMR_MERCH_TYPE[QMR_ROWS], getMERCH_TYPE().data(), getMERCH_TYPE().length());
      QMR_MERCH_TYPE[QMR_ROWS][getMERCH_TYPE().length()] = '\0';
   }
   else
      memcpy(QMR_MERCH_TYPE[QMR_ROWS],szSpace,2);  
   if(!getPOS_CRDHLDR_PRESNT().empty())
   {
      memcpy(QMR_POS_CRDHLDR_PRESNT[QMR_ROWS],getPOS_CRDHLDR_PRESNT().data(),getPOS_CRDHLDR_PRESNT().length());
      QMR_POS_CRDHLDR_PRESNT[QMR_ROWS][getPOS_CRDHLDR_PRESNT().length()] = '\0';
   }
   else
      memcpy(QMR_POS_CRDHLDR_PRESNT[QMR_ROWS],szSpace,2);
   if(!getPAYMENT_TYPE_IND().empty())
   {
      memcpy(QMR_PAYMENT_TYPE_IND[QMR_ROWS],getPAYMENT_TYPE_IND().data(),getPAYMENT_TYPE_IND().length());
      QMR_PAYMENT_TYPE_IND[QMR_ROWS][getPAYMENT_TYPE_IND().length()] = '\0';
   }
   else
      memcpy(QMR_PAYMENT_TYPE_IND[QMR_ROWS],szSpace,2);
  QMR_ROWS++;
  return 0;
  //## end dnoracledatabase::OracleMonthlyTotals::tableUpdate%606421650038.body
}

// Additional Declarations
  //## begin dnoracledatabase::OracleMonthlyTotals%606409A6000D.declarations preserve=yes
  //## end dnoracledatabase::OracleMonthlyTotals%606409A6000D.declarations

} // namespace dnoracledatabase

//## begin module%606409130160.epilog preserve=yes
//## end module%606409130160.epilog
