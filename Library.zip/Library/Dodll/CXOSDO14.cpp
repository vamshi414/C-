//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%44492D6802DE.cm preserve=no
//	$Date:   Apr 28 2006 13:30:22  $ $Author:   D92705  $
//	$Revision:   1.0  $
//## end module%44492D6802DE.cm

//## begin module%44492D6802DE.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%44492D6802DE.cp

//## Module: CXOSDO14%44492D6802DE; Package body
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Devel\Dn\Server\Library\Dodll\CXOSDO14.cpp

//## begin module%44492D6802DE.additionalIncludes preserve=no
//## end module%44492D6802DE.additionalIncludes

//## begin module%44492D6802DE.includes preserve=yes
//## end module%44492D6802DE.includes

#ifndef CXOSIF44_h
#include "CXODIF44.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDO14_h
#include "CXODDO14.hpp"
#endif


//## begin module%44492D6802DE.declarations preserve=no
//## end module%44492D6802DE.declarations

//## begin module%44492D6802DE.additionalDeclarations preserve=yes
//## end module%44492D6802DE.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

// Class dnoracledatabase::OracleMaintenanceProcedure 

OracleMaintenanceProcedure::OracleMaintenanceProcedure()
  //## begin OracleMaintenanceProcedure::OracleMaintenanceProcedure%444917580232_const.hasinit preserve=no
      : m_lFreePages(0),
        m_lTotalPages(0),
        m_lUsedPages(0)
  //## end OracleMaintenanceProcedure::OracleMaintenanceProcedure%444917580232_const.hasinit
  //## begin OracleMaintenanceProcedure::OracleMaintenanceProcedure%444917580232_const.initialization preserve=yes
  //## end OracleMaintenanceProcedure::OracleMaintenanceProcedure%444917580232_const.initialization
{
  //## begin dnoracledatabase::OracleMaintenanceProcedure::OracleMaintenanceProcedure%444917580232_const.body preserve=yes
  //## end dnoracledatabase::OracleMaintenanceProcedure::OracleMaintenanceProcedure%444917580232_const.body
}


OracleMaintenanceProcedure::~OracleMaintenanceProcedure()
{
  //## begin dnoracledatabase::OracleMaintenanceProcedure::~OracleMaintenanceProcedure%444917580232_dest.body preserve=yes
  //## end dnoracledatabase::OracleMaintenanceProcedure::~OracleMaintenanceProcedure%444917580232_dest.body
}



//## Other Operations (implementation)
void OracleMaintenanceProcedure::review (const char* pszText)
{
  //## begin dnoracledatabase::OracleMaintenanceProcedure::review%444932E500DA.body preserve=yes
  //## end dnoracledatabase::OracleMaintenanceProcedure::review%444932E500DA.body
}

// Additional Declarations
  //## begin dnoracledatabase::OracleMaintenanceProcedure%444917580232.declarations preserve=yes
  //## end dnoracledatabase::OracleMaintenanceProcedure%444917580232.declarations

} // namespace dnoracledatabase

//## begin module%44492D6802DE.epilog preserve=yes
//## end module%44492D6802DE.epilog
