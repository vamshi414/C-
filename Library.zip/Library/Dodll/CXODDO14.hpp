//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%44492D670232.cm preserve=no
//	$Date:   Jun 30 2006 12:08:14  $ $Author:   D02405  $
//	$Revision:   1.1  $
//## end module%44492D670232.cm

//## begin module%44492D670232.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%44492D670232.cp

//## Module: CXOSDO14%44492D670232; Package specification
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Devel\Dn\Server\Library\Dodll\CXODDO14.hpp

#ifndef CXOSDO14_h
#define CXOSDO14_h 1

//## begin module%44492D670232.additionalIncludes preserve=no
//## end module%44492D670232.additionalIncludes

//## begin module%44492D670232.includes preserve=yes
//## end module%44492D670232.includes

#ifndef CXOSDB03_h
#include "CXODDB03.hpp"
#endif

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
} // namespace timer

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class SiteSpecification;

} // namespace IF

//## begin module%44492D670232.declarations preserve=no
//## end module%44492D670232.declarations

//## begin module%44492D670232.additionalDeclarations preserve=yes
//## end module%44492D670232.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

//## begin dnoracledatabase::OracleMaintenanceProcedure%444917580232.preface preserve=yes
//## end dnoracledatabase::OracleMaintenanceProcedure%444917580232.preface

//## Class: OracleMaintenanceProcedure%444917580232
//## Category: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
//## Subsystem: DODLL%444917C7035B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%444932CF00CB;IF::SiteSpecification { -> F}
//## Uses: <unnamed>%444932D00196;timer::Date { -> F}

class DllExport OracleMaintenanceProcedure : public database::MaintenanceProcedure  //## Inherits: <unnamed>%444932CD00FA
{
  //## begin dnoracledatabase::OracleMaintenanceProcedure%444917580232.initialDeclarations preserve=yes
  //## end dnoracledatabase::OracleMaintenanceProcedure%444917580232.initialDeclarations

  public:
    //## Constructors (generated)
      OracleMaintenanceProcedure();

    //## Destructor (generated)
      virtual ~OracleMaintenanceProcedure();


    //## Other Operations (specified)
      //## Operation: review%444932E500DA
      virtual void review (const char* pszText);

    // Additional Public Declarations
      //## begin dnoracledatabase::OracleMaintenanceProcedure%444917580232.public preserve=yes
      //## end dnoracledatabase::OracleMaintenanceProcedure%444917580232.public

  protected:
    // Additional Protected Declarations
      //## begin dnoracledatabase::OracleMaintenanceProcedure%444917580232.protected preserve=yes
      //## end dnoracledatabase::OracleMaintenanceProcedure%444917580232.protected

  private:
    // Additional Private Declarations
      //## begin dnoracledatabase::OracleMaintenanceProcedure%444917580232.private preserve=yes
      //## end dnoracledatabase::OracleMaintenanceProcedure%444917580232.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: FreePages%444932DE0138
      //## begin dnoracledatabase::OracleMaintenanceProcedure::FreePages%444932DE0138.attr preserve=no  private: int {V} 0
      int m_lFreePages;
      //## end dnoracledatabase::OracleMaintenanceProcedure::FreePages%444932DE0138.attr

      //## Attribute: Name%444932DE0148
      //## begin dnoracledatabase::OracleMaintenanceProcedure::Name%444932DE0148.attr preserve=no  private: string {V} 
      string m_strName;
      //## end dnoracledatabase::OracleMaintenanceProcedure::Name%444932DE0148.attr

      //## Attribute: TotalPages%444932DE0157
      //## begin dnoracledatabase::OracleMaintenanceProcedure::TotalPages%444932DE0157.attr preserve=no  private: int {V} 0
      int m_lTotalPages;
      //## end dnoracledatabase::OracleMaintenanceProcedure::TotalPages%444932DE0157.attr

      //## Attribute: UsedPages%444932DE0167
      //## begin dnoracledatabase::OracleMaintenanceProcedure::UsedPages%444932DE0167.attr preserve=no  private: int {V} 0
      int m_lUsedPages;
      //## end dnoracledatabase::OracleMaintenanceProcedure::UsedPages%444932DE0167.attr

    // Additional Implementation Declarations
      //## begin dnoracledatabase::OracleMaintenanceProcedure%444917580232.implementation preserve=yes
      //## end dnoracledatabase::OracleMaintenanceProcedure%444917580232.implementation

};

//## begin dnoracledatabase::OracleMaintenanceProcedure%444917580232.postscript preserve=yes
//## end dnoracledatabase::OracleMaintenanceProcedure%444917580232.postscript

} // namespace dnoracledatabase

//## begin module%44492D670232.epilog preserve=yes
using namespace dnoracledatabase;
//## end module%44492D670232.epilog


#endif
