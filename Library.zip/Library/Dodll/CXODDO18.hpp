//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%640A4141001A.cm preserve=no
//## end module%640A4141001A.cm

//## begin module%640A4141001A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%640A4141001A.cp

//## Module: CXOSDO18%640A4141001A; Package specification
//## Subsystem: DODLL%444917C7035B
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Library\Dodll\CXODDO18.hpp

#ifndef CXOSDO18_h
#define CXOSDO18_h 1

//## begin module%640A4141001A.additionalIncludes preserve=no
//## end module%640A4141001A.additionalIncludes

//## begin module%640A4141001A.includes preserve=yes
//## end module%640A4141001A.includes

#ifndef CXOSST34_h
#include "CXODST34.hpp"
#endif
//## begin module%640A4141001A.declarations preserve=no
//## end module%640A4141001A.declarations

//## begin module%640A4141001A.additionalDeclarations preserve=yes
//## end module%640A4141001A.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
namespace dnoracledatabase {
//## begin dnoracledatabase%4449152200AB.initialDeclarations preserve=yes
//## end dnoracledatabase%4449152200AB.initialDeclarations

//## begin dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.preface preserve=yes
//## end dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.preface

//## Class: OracleAggregatorMIS2%640A409C00BC
//## Category: DataNavigator Foundation::DNOracleDatabase_CAT%4449152200AB
//## Subsystem: DODLL%444917C7035B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport OracleAggregatorMIS2 : public settlement::AggregatorMIS  //## Inherits: <unnamed>%640A409C00C6
{
  //## begin dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.initialDeclarations preserve=yes
  //## end dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.initialDeclarations

  public:
    //## Constructors (generated)
      OracleAggregatorMIS2();

    //## Destructor (generated)
      virtual ~OracleAggregatorMIS2();


    //## Other Operations (specified)
      //## Operation: commit%640A846901CC
      virtual bool commit ();

      //## Operation: tableInsert%640A409C00C2
      bool tableInsert (bool bSubtractFromTotals = false);

      //## Operation: tableUpdate%640A409C00C4
      int tableUpdate (bool bSubtractFromTotals = false);

    // Additional Public Declarations
      //## begin dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.public preserve=yes
      //## end dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.public

  protected:
    // Additional Protected Declarations
      //## begin dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.protected preserve=yes
      //## end dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.protected

  private:

    //## Other Operations (specified)
      //## Operation: checkResult%640A409C00C0
      int checkResult ();

      //## Operation: lockTables%640A409C00C1
      void lockTables ();

    // Additional Private Declarations
      //## begin dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.private preserve=yes
      //## end dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DBAccess%640A409C00BE
      //## begin dnoracledatabase::OracleAggregatorMIS2::DBAccess%640A409C00BE.attr preserve=no  private: string {U} 
      string m_strDBAccess;
      //## end dnoracledatabase::OracleAggregatorMIS2::DBAccess%640A409C00BE.attr

      //## Attribute: Transaction%640A409C00BF
      //## begin dnoracledatabase::OracleAggregatorMIS2::Transaction%640A409C00BF.attr preserve=no  private: long {U} -1
      long m_iTransaction;
      //## end dnoracledatabase::OracleAggregatorMIS2::Transaction%640A409C00BF.attr

    // Additional Implementation Declarations
      //## begin dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.implementation preserve=yes
      //## end dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.implementation

};

//## begin dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.postscript preserve=yes
//## end dnoracledatabase::OracleAggregatorMIS2%640A409C00BC.postscript

} // namespace dnoracledatabase

//## begin module%640A4141001A.epilog preserve=yes
//## end module%640A4141001A.epilog


#endif
