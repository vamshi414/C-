//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4263E165031C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%4263E165031C.cm

//## begin module%4263E165031C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%4263E165031C.cp

//## Module: CXOSCF76%4263E165031C; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF76.hpp

#ifndef CXOSCF76_h
#define CXOSCF76_h 1

//## begin module%4263E165031C.additionalIncludes preserve=no
//## end module%4263E165031C.additionalIncludes

//## begin module%4263E165031C.includes preserve=yes
//## end module%4263E165031C.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%4263E165031C.declarations preserve=no
//## end module%4263E165031C.declarations

//## begin module%4263E165031C.additionalDeclarations preserve=yes
//## end module%4263E165031C.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::OasisCardProduct%4263E11A00EA.preface preserve=yes
//## end configuration::OasisCardProduct%4263E11A00EA.preface

//## Class: OasisCardProduct%4263E11A00EA
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4263E12C03D8;reusable::Query { -> F}
//## Uses: <unnamed>%4263E12F00CB;IF::Extract { -> F}

class DllExport OasisCardProduct : public ConversionItem  //## Inherits: <unnamed>%4263E12A03D8
{
  //## begin configuration::OasisCardProduct%4263E11A00EA.initialDeclarations preserve=yes
  //## end configuration::OasisCardProduct%4263E11A00EA.initialDeclarations

  public:
    //## Constructors (generated)
      OasisCardProduct();

    //## Destructor (generated)
      virtual ~OasisCardProduct();


    //## Other Operations (specified)
      //## Operation: bind%4263E1E10138
      virtual void bind (reusable::Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::OasisCardProduct%4263E11A00EA.public preserve=yes
      //## end configuration::OasisCardProduct%4263E11A00EA.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::OasisCardProduct%4263E11A00EA.protected preserve=yes
      //## end configuration::OasisCardProduct%4263E11A00EA.protected

  private:
    // Additional Private Declarations
      //## begin configuration::OasisCardProduct%4263E11A00EA.private preserve=yes
      //## end configuration::OasisCardProduct%4263E11A00EA.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::OasisCardProduct%4263E11A00EA.implementation preserve=yes
      //## end configuration::OasisCardProduct%4263E11A00EA.implementation

};

//## begin configuration::OasisCardProduct%4263E11A00EA.postscript preserve=yes
//## end configuration::OasisCardProduct%4263E11A00EA.postscript

} // namespace configuration

//## begin module%4263E165031C.epilog preserve=yes
//## end module%4263E165031C.epilog


#endif
