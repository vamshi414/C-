//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64DF81140239.cm preserve=no
//## end module%64DF81140239.cm

//## begin module%64DF81140239.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64DF81140239.cp

//## Module: CXOSCFD5%64DF81140239; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXODCFD5.hpp

#ifndef CXOSCFD5_h
#define CXOSCFD5_h 1

//## begin module%64DF81140239.additionalIncludes preserve=no
//## end module%64DF81140239.additionalIncludes

//## begin module%64DF81140239.includes preserve=yes
//## end module%64DF81140239.includes

#ifndef CXOSCF26_h
#include "CXODCF26.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%64DF81140239.declarations preserve=no
//## end module%64DF81140239.declarations

//## begin module%64DF81140239.additionalDeclarations preserve=yes
//## end module%64DF81140239.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ReportingLevelBusiness%64DF832701C4.preface preserve=yes
//## end configuration::ReportingLevelBusiness%64DF832701C4.preface

//## Class: ReportingLevelBusiness%64DF832701C4
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%64DF86FF0249;IF::Extract { -> F}
//## Uses: <unnamed>%64DF87270039;reusable::Query { -> F}

class DllExport ReportingLevelBusiness : public VerificationItem  //## Inherits: <unnamed>%64DFA4C803E3
{
  //## begin configuration::ReportingLevelBusiness%64DF832701C4.initialDeclarations preserve=yes
  //## end configuration::ReportingLevelBusiness%64DF832701C4.initialDeclarations

  public:
    //## Constructors (generated)
      ReportingLevelBusiness();

    //## Destructor (generated)
      virtual ~ReportingLevelBusiness();

    // Additional Public Declarations
      //## begin configuration::ReportingLevelBusiness%64DF832701C4.public preserve=yes
      //## end configuration::ReportingLevelBusiness%64DF832701C4.public

  protected:

    //## Other Operations (specified)
      //## Operation: bind%64DF87300000
      virtual void bind (Query& hQuery);

    // Additional Protected Declarations
      //## begin configuration::ReportingLevelBusiness%64DF832701C4.protected preserve=yes
      //## end configuration::ReportingLevelBusiness%64DF832701C4.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ReportingLevelBusiness%64DF832701C4.private preserve=yes
      //## end configuration::ReportingLevelBusiness%64DF832701C4.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ReportingLevelBusiness%64DF832701C4.implementation preserve=yes
      //## end configuration::ReportingLevelBusiness%64DF832701C4.implementation

};

//## begin configuration::ReportingLevelBusiness%64DF832701C4.postscript preserve=yes
//## end configuration::ReportingLevelBusiness%64DF832701C4.postscript

} // namespace configuration

//## begin module%64DF81140239.epilog preserve=yes
//## end module%64DF81140239.epilog


#endif
