//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40A51CF5006D.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40A51CF5006D.cm

//## begin module%40A51CF5006D.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40A51CF5006D.cp

//## Module: CXOSCF65%40A51CF5006D; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF65.cpp

//## begin module%40A51CF5006D.additionalIncludes preserve=no
//## end module%40A51CF5006D.additionalIncludes

//## begin module%40A51CF5006D.includes preserve=yes
// $Date:   May 26 2020 10:44:46  $ $Author:   e1009510  $ $Revision:   1.10  $
//## end module%40A51CF5006D.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSCF65_h
#include "CXODCF65.hpp"
#endif


//## begin module%40A51CF5006D.declarations preserve=no
//## end module%40A51CF5006D.declarations

//## begin module%40A51CF5006D.additionalDeclarations preserve=yes
//## end module%40A51CF5006D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::OasisOCSPresentmentMap 

OasisOCSPresentmentMap::OasisOCSPresentmentMap()
  //## begin OasisOCSPresentmentMap::OasisOCSPresentmentMap%40A3850E037A_const.hasinit preserve=no
  //## end OasisOCSPresentmentMap::OasisOCSPresentmentMap%40A3850E037A_const.hasinit
  //## begin OasisOCSPresentmentMap::OasisOCSPresentmentMap%40A3850E037A_const.initialization preserve=yes
   : ImportMapItem("DNDNOCSM")
  //## end OasisOCSPresentmentMap::OasisOCSPresentmentMap%40A3850E037A_const.initialization
{
  //## begin configuration::OasisOCSPresentmentMap::OasisOCSPresentmentMap%40A3850E037A_const.body preserve=yes
   memcpy(m_sID,"CF65",4);
   //loadDataMap();
  //## end configuration::OasisOCSPresentmentMap::OasisOCSPresentmentMap%40A3850E037A_const.body
}


OasisOCSPresentmentMap::~OasisOCSPresentmentMap()
{
  //## begin configuration::OasisOCSPresentmentMap::~OasisOCSPresentmentMap%40A3850E037A_dest.body preserve=yes
  //## end configuration::OasisOCSPresentmentMap::~OasisOCSPresentmentMap%40A3850E037A_dest.body
}



//## Other Operations (implementation)
bool OasisOCSPresentmentMap::loadDataMap ()
{
  //## begin configuration::OasisOCSPresentmentMap::loadDataMap%40A5202F038A.body preserve=yes
   if (!m_hDataMap.empty())
      return true;
#ifdef MVS
   FlatFile hTemplate("JCL","DNDNOCSM");
#else
   FlatFile hTemplate("SOURCE","CXOXOCSM");
#endif
   if (!hTemplate.open())
      return false;
   char* psBuffer = new char[256];
   memset(psBuffer,' ',256);
   size_t m = 0;
   string strTokenID, strTargetColumn, strTargetSegment;
   while (hTemplate.read(psBuffer,256,&m))
   {
      char *pRcdType;
      pRcdType = strchr(psBuffer,'.');
      if (pRcdType)
      {
         *pRcdType = '\0';
         ++pRcdType;
         char* pFieldID = strchr(pRcdType,'.');
         if (pFieldID)
         {
            *pFieldID = '\0';
            ++pFieldID;
            char* s = strchr(pFieldID,'.');
            if (s)
            {
               *s = '\0';
               ++s;
            }
            char* q = strchr(s,'~');
            if (q)
            {
               *q = '\0';
               ++q;
               strTargetSegment.assign(q,1);
            }
            q += 2;
            char* p = strchr(q,'.');
            if (p)
            {
               *p = '\0';
               strTargetColumn.assign(q);
            }
            strTokenID.assign(pRcdType);
            strTokenID += pFieldID;
            strTargetSegment += ' ';
            strTargetSegment += strTargetColumn;
            m_hDataMap.insert(map<string,string,less<string> >::value_type(strTokenID,strTargetSegment));
         }
      }
      strTokenID.erase();
      strTargetSegment.erase();
      strTargetColumn.erase();
   }
   delete [] psBuffer;
   return true;
  //## end configuration::OasisOCSPresentmentMap::loadDataMap%40A5202F038A.body
}

// Additional Declarations
  //## begin configuration::OasisOCSPresentmentMap%40A3850E037A.declarations preserve=yes
  //## end configuration::OasisOCSPresentmentMap%40A3850E037A.declarations

} // namespace configuration

//## begin module%40A51CF5006D.epilog preserve=yes
//## end module%40A51CF5006D.epilog
