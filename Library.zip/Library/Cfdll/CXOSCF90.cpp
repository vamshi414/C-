//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%45CBF7DC021B.cm preserve=no
//	$Date:   Aug 06 2020 14:46:12  $ $Author:   e1009652  $
//	$Revision:   1.3  $
//## end module%45CBF7DC021B.cm

//## begin module%45CBF7DC021B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%45CBF7DC021B.cp

//## Module: CXOSCF90%45CBF7DC021B; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV03.1A.R001\Build\Dn\Server\Library\Cfdll\CXOSCF90.cpp

//## begin module%45CBF7DC021B.additionalIncludes preserve=no
//## end module%45CBF7DC021B.additionalIncludes

//## begin module%45CBF7DC021B.includes preserve=yes
//## end module%45CBF7DC021B.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF90_h
#include "CXODCF90.hpp"
#endif


//## begin module%45CBF7DC021B.declarations preserve=no
//## end module%45CBF7DC021B.declarations

//## begin module%45CBF7DC021B.additionalDeclarations preserve=yes
//## end module%45CBF7DC021B.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ActionCode 

ActionCode::ActionCode()
  //## begin ActionCode::ActionCode%45CBF704015C_const.hasinit preserve=no
  //## end ActionCode::ActionCode%45CBF704015C_const.hasinit
  //## begin ActionCode::ActionCode%45CBF704015C_const.initialization preserve=yes
   : ConversionItem("## CR90 XLATE ACTION CODE")
  //## end ActionCode::ActionCode%45CBF704015C_const.initialization
{
  //## begin configuration::ActionCode::ActionCode%45CBF704015C_const.body preserve=yes
   memcpy(m_sID,"CF90",4);
  //## end configuration::ActionCode::ActionCode%45CBF704015C_const.body
}


ActionCode::~ActionCode()
{
  //## begin configuration::ActionCode::~ActionCode%45CBF704015C_dest.body preserve=yes
  //## end configuration::ActionCode::~ActionCode%45CBF704015C_dest.body
}



//## Other Operations (implementation)
void ActionCode::bind (Query& hQuery)
{
  //## begin configuration::ActionCode::bind%45CBFE6F02CC.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","ACTION_CODE");
   hQuery.bind("ACTION_CODE","ACTION_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("ACTION_CODE","ACTION_CODE_GROUP",Column::STRING,&m_strSecond);
   hQuery.bind("ACTION_CODE","CFG_DESCRIPTION",Column::STRING,&m_strThird);
   hQuery.bind("ACTION_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("ACTION_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("ACTION_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("ACTION_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("ACTION_CODE.ACTION_CODE ASC,ACTION_CODE.CUST_ID DESC");
  //## end configuration::ActionCode::bind%45CBFE6F02CC.body
}

// Additional Declarations
  //## begin configuration::ActionCode%45CBF704015C.declarations preserve=yes
  //## end configuration::ActionCode%45CBF704015C.declarations

} // namespace configuration

//## begin module%45CBF7DC021B.epilog preserve=yes
//## end module%45CBF7DC021B.epilog
