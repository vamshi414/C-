//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%45DA008A00F2.cm preserve=no
//	$Date:   Apr 17 2014 21:06:16  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%45DA008A00F2.cm

//## begin module%45DA008A00F2.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%45DA008A00F2.cp

//## Module: CXOSCF91%45DA008A00F2; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF91.cpp

//## begin module%45DA008A00F2.additionalIncludes preserve=no
//## end module%45DA008A00F2.additionalIncludes

//## begin module%45DA008A00F2.includes preserve=yes
//## end module%45DA008A00F2.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF91_h
#include "CXODCF91.hpp"
#endif


//## begin module%45DA008A00F2.declarations preserve=no
//## end module%45DA008A00F2.declarations

//## begin module%45DA008A00F2.additionalDeclarations preserve=yes
//## end module%45DA008A00F2.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::DeviceRev 

DeviceRev::DeviceRev()
  //## begin DeviceRev::DeviceRev%45D9FF6201BF_const.hasinit preserve=no
  //## end DeviceRev::DeviceRev%45D9FF6201BF_const.hasinit
  //## begin DeviceRev::DeviceRev%45D9FF6201BF_const.initialization preserve=yes
  : ConversionItem("## CR91 XLATE PSUEDO DEVICE ID")
  //## end DeviceRev::DeviceRev%45D9FF6201BF_const.initialization
{
  //## begin configuration::DeviceRev::DeviceRev%45D9FF6201BF_const.body preserve=yes
   memcpy(m_sID,"CF91",4);
  //## end configuration::DeviceRev::DeviceRev%45D9FF6201BF_const.body
}


DeviceRev::~DeviceRev()
{
  //## begin configuration::DeviceRev::~DeviceRev%45D9FF6201BF_dest.body preserve=yes
  //## end configuration::DeviceRev::~DeviceRev%45D9FF6201BF_dest.body
}



//## Other Operations (implementation)
void DeviceRev::bind (reusable::Query& hQuery)
{
  //## begin configuration::DeviceRev::bind%45DA03160096.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","DEVICE");
   hQuery.bind("DEVICE","INST_ID",Column::STRING,&m_strFirst);
   hQuery.bind("DEVICE","DEVICE_ID",Column::STRING,&m_strSecond);
   hQuery.bind("DEVICE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("DEVICE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("DEVICE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("DEVICE","CUST_ID","IN",strTemp.c_str());
   hQuery.setBasicPredicate("DEVICE","DEVICE_ID","LIKE","Z%");
   hQuery.setOrderByClause("DEVICE.INST_ID ASC,DEVICE.CUST_ID DESC");
  //## end configuration::DeviceRev::bind%45DA03160096.body
}

// Additional Declarations
  //## begin configuration::DeviceRev%45D9FF6201BF.declarations preserve=yes
  //## end configuration::DeviceRev%45D9FF6201BF.declarations

} // namespace configuration

//## begin module%45DA008A00F2.epilog preserve=yes
//## end module%45DA008A00F2.epilog
