//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%507D80750172.cm preserve=no
//	$Date:   Oct 25 2012 08:12:00  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%507D80750172.cm

//## begin module%507D80750172.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%507D80750172.cp

//## Module: CXOSCFA0%507D80750172; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.3A.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCFA0.hpp

#ifndef CXOSCFA0_h
#define CXOSCFA0_h 1

//## begin module%507D80750172.additionalIncludes preserve=no
//## end module%507D80750172.additionalIncludes

//## begin module%507D80750172.includes preserve=yes
//## end module%507D80750172.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%507D80750172.declarations preserve=no
//## end module%507D80750172.declarations

//## begin module%507D80750172.additionalDeclarations preserve=yes
//## end module%507D80750172.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::MasterCardResponseCode%507D800E0040.preface preserve=yes
//## end configuration::MasterCardResponseCode%507D800E0040.preface

//## Class: MasterCardResponseCode%507D800E0040
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%507D803A02CA;IF::Extract { -> F}
//## Uses: <unnamed>%507D803D0029;reusable::Query { -> F}

class DllExport MasterCardResponseCode : public ConversionItem  //## Inherits: <unnamed>%507D80380149
{
  //## begin configuration::MasterCardResponseCode%507D800E0040.initialDeclarations preserve=yes
  //## end configuration::MasterCardResponseCode%507D800E0040.initialDeclarations

  public:
    //## Constructors (generated)
      MasterCardResponseCode();

    //## Destructor (generated)
      virtual ~MasterCardResponseCode();


    //## Other Operations (specified)
      //## Operation: bind%507D804200B0
      virtual void bind (reusable::Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::MasterCardResponseCode%507D800E0040.public preserve=yes
      //## end configuration::MasterCardResponseCode%507D800E0040.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::MasterCardResponseCode%507D800E0040.protected preserve=yes
      //## end configuration::MasterCardResponseCode%507D800E0040.protected

  private:
    // Additional Private Declarations
      //## begin configuration::MasterCardResponseCode%507D800E0040.private preserve=yes
      //## end configuration::MasterCardResponseCode%507D800E0040.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::MasterCardResponseCode%507D800E0040.implementation preserve=yes
      //## end configuration::MasterCardResponseCode%507D800E0040.implementation

};

//## begin configuration::MasterCardResponseCode%507D800E0040.postscript preserve=yes
//## end configuration::MasterCardResponseCode%507D800E0040.postscript

} // namespace configuration

//## begin module%507D80750172.epilog preserve=yes
//## end module%507D80750172.epilog


#endif
