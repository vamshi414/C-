//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFC721500AB.cm preserve=no
//	$Date:   Dec 12 2016 13:08:58  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%3FFC721500AB.cm

//## begin module%3FFC721500AB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFC721500AB.cp

//## Module: CXOSCF55%3FFC721500AB; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF55.hpp

#ifndef CXOSCF55_h
#define CXOSCF55_h 1

//## begin module%3FFC721500AB.additionalIncludes preserve=no
//## end module%3FFC721500AB.additionalIncludes

//## begin module%3FFC721500AB.includes preserve=yes
// $Date:   Dec 12 2016 13:08:58  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%3FFC721500AB.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
//## begin module%3FFC721500AB.declarations preserve=no
//## end module%3FFC721500AB.declarations

//## begin module%3FFC721500AB.additionalDeclarations preserve=yes
//## end module%3FFC721500AB.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexPOSConditionCode6%3FFC71480271.preface preserve=yes
//## end configuration::ConnexPOSConditionCode6%3FFC71480271.preface

//## Class: ConnexPOSConditionCode6%3FFC71480271
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FFC717700FA;reusable::Query { -> F}

class DllExport ConnexPOSConditionCode6 : public ConversionItem  //## Inherits: <unnamed>%3FFC71690242
{
  //## begin configuration::ConnexPOSConditionCode6%3FFC71480271.initialDeclarations preserve=yes
  //## end configuration::ConnexPOSConditionCode6%3FFC71480271.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexPOSConditionCode6();

    //## Destructor (generated)
      virtual ~ConnexPOSConditionCode6();


    //## Other Operations (specified)
      //## Operation: bind%3FFC7158007D
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%5847164C01EC
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexPOSConditionCode6%3FFC71480271.public preserve=yes
      //## end configuration::ConnexPOSConditionCode6%3FFC71480271.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexPOSConditionCode6%3FFC71480271.protected preserve=yes
      //## end configuration::ConnexPOSConditionCode6%3FFC71480271.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexPOSConditionCode6%3FFC71480271.private preserve=yes
      //## end configuration::ConnexPOSConditionCode6%3FFC71480271.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexPOSConditionCode6%3FFC71480271.implementation preserve=yes
      //## end configuration::ConnexPOSConditionCode6%3FFC71480271.implementation

};

//## begin configuration::ConnexPOSConditionCode6%3FFC71480271.postscript preserve=yes
//## end configuration::ConnexPOSConditionCode6%3FFC71480271.postscript

} // namespace configuration

//## begin module%3FFC721500AB.epilog preserve=yes
using namespace configuration;
//## end module%3FFC721500AB.epilog


#endif
