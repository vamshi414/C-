//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%391C10F80190.cm preserve=no
//	$Date:   Feb 14 2019 03:27:24  $ $Author:   e3028298  $
//	$Revision:   1.7  $
//## end module%391C10F80190.cm

//## begin module%391C10F80190.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%391C10F80190.cp

//## Module: CXOSCF16%391C10F80190; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF16.hpp

#ifndef CXOSCF16_h
#define CXOSCF16_h 1

//## begin module%391C10F80190.additionalIncludes preserve=no
//## end module%391C10F80190.additionalIncludes

//## begin module%391C10F80190.includes preserve=yes
// $Date:   Feb 14 2019 03:27:24  $ $Author:   e3028298  $ $Revision:   1.7  $
//## end module%391C10F80190.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%391C10F80190.declarations preserve=no
//## end module%391C10F80190.declarations

//## begin module%391C10F80190.additionalDeclarations preserve=yes
//## end module%391C10F80190.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::Device%391C0C8A02DA.preface preserve=yes
//## end configuration::Device%391C0C8A02DA.preface

//## Class: Device%391C0C8A02DA
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%391C17250356;IF::Extract { -> F}
//## Uses: <unnamed>%391C172702A5;reusable::Query { -> F}

class DllExport Device : public ConversionItem  //## Inherits: <unnamed>%391C172400B6
{
  //## begin configuration::Device%391C0C8A02DA.initialDeclarations preserve=yes
  //## end configuration::Device%391C0C8A02DA.initialDeclarations

  public:
    //## Constructors (generated)
      Device();

    //## Destructor (generated)
      virtual ~Device();


    //## Other Operations (specified)
      //## Operation: bind%391C1BF30251
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getSecond%3943A10B03AF
      virtual const string& getSecond ();

      //## Operation: getThird%44B3FF0302BF
      virtual const string& getThird ();

    // Additional Public Declarations
      //## begin configuration::Device%391C0C8A02DA.public preserve=yes
      //## end configuration::Device%391C0C8A02DA.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::Device%391C0C8A02DA.protected preserve=yes
      //## end configuration::Device%391C0C8A02DA.protected

  private:
    // Additional Private Declarations
      //## begin configuration::Device%391C0C8A02DA.private preserve=yes
      //## end configuration::Device%391C0C8A02DA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: INST_ID%3943A13000A5
      //## begin configuration::Device::INST_ID%3943A13000A5.attr preserve=no  private: string {U} 
      string m_strINST_ID;
      //## end configuration::Device::INST_ID%3943A13000A5.attr

      //## Attribute: POSTAL_CODE%44B3FED80167
      //## begin configuration::Device::POSTAL_CODE%44B3FED80167.attr preserve=no  private: string {U} 
      string m_strPOSTAL_CODE;
      //## end configuration::Device::POSTAL_CODE%44B3FED80167.attr

      //## Attribute: REGION%44B3FEEF02BF
      //## begin configuration::Device::REGION%44B3FEEF02BF.attr preserve=no  private: string {U} 
      string m_strREGION;
      //## end configuration::Device::REGION%44B3FEEF02BF.attr

      //## Attribute: RPT_LVL_ID%3943A138016F
      //## begin configuration::Device::RPT_LVL_ID%3943A138016F.attr preserve=no  private: string {U} 
      string m_strRPT_LVL_ID;
      //## end configuration::Device::RPT_LVL_ID%3943A138016F.attr

      //## Attribute: DEFAULT_CUR_CODE%472AC5E100B3
      //## begin configuration::Device::DEFAULT_CUR_CODE%472AC5E100B3.attr preserve=no  private: string {U} 
      string m_strDEFAULT_CUR_CODE;
      //## end configuration::Device::DEFAULT_CUR_CODE%472AC5E100B3.attr

    // Additional Implementation Declarations
      //## begin configuration::Device%391C0C8A02DA.implementation preserve=yes
      string m_strHOW_TERM_ATTACHED;
      //## end configuration::Device%391C0C8A02DA.implementation

};

//## begin configuration::Device%391C0C8A02DA.postscript preserve=yes
//## end configuration::Device%391C0C8A02DA.postscript

} // namespace configuration

//## begin module%391C10F80190.epilog preserve=yes
using namespace configuration;
//## end module%391C10F80190.epilog


#endif
