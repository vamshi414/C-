//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C1A4CF903D8.cm preserve=no
//	$Date:   Apr 30 2020 11:12:14  $ $Author:   e1009839  $
//	$Revision:   1.7  $
//## end module%3C1A4CF903D8.cm

//## begin module%3C1A4CF903D8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C1A4CF903D8.cp

//## Module: CXOSCF45%3C1A4CF903D8; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF45.cpp

//## begin module%3C1A4CF903D8.additionalIncludes preserve=no
//## end module%3C1A4CF903D8.additionalIncludes

//## begin module%3C1A4CF903D8.includes preserve=yes
//## end module%3C1A4CF903D8.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF45_h
#include "CXODCF45.hpp"
#endif


//## begin module%3C1A4CF903D8.declarations preserve=no
//## end module%3C1A4CF903D8.declarations

//## begin module%3C1A4CF903D8.additionalDeclarations preserve=yes
//## end module%3C1A4CF903D8.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::GasperStatusCode

GasperStatusCode::GasperStatusCode()
  //## begin GasperStatusCode::GasperStatusCode%3C1A4FA40280_const.hasinit preserve=no
  //## end GasperStatusCode::GasperStatusCode%3C1A4FA40280_const.hasinit
  //## begin GasperStatusCode::GasperStatusCode%3C1A4FA40280_const.initialization preserve=yes
   : ConversionItem("## CF45 XLATE GASPER STATUS CODE")
  //## end GasperStatusCode::GasperStatusCode%3C1A4FA40280_const.initialization
{
  //## begin configuration::GasperStatusCode::GasperStatusCode%3C1A4FA40280_const.body preserve=yes
   memcpy(m_sID,"CF45",4);
  //## end configuration::GasperStatusCode::GasperStatusCode%3C1A4FA40280_const.body
}


GasperStatusCode::~GasperStatusCode()
{
  //## begin configuration::GasperStatusCode::~GasperStatusCode%3C1A4FA40280_dest.body preserve=yes
  //## end configuration::GasperStatusCode::~GasperStatusCode%3C1A4FA40280_dest.body
}



//## Other Operations (implementation)
void GasperStatusCode::bind (Query& hQuery)
{
  //## begin configuration::GasperStatusCode::bind%3C1A519800CB.body preserve=yes
   hQuery.setQualifier("QUALIFY","DEVICE_STATUS");
   hQuery.bind("DEVICE_STATUS","DEVICE_STATUS",Column::STRING,&m_strFirst);
   hQuery.bind("DEVICE_STATUS","DEVICE_STATE",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("DEVICE_STATUS","DEVICE_STATE",">","0");
   hQuery.setBasicPredicate("DEVICE_STATUS","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("DEVICE_STATUS","CC_STATE","=","A");
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   string strValue("('xxxx','****')");
   strValue.replace(2,4,strCUST_ID);
   hQuery.setBasicPredicate("DEVICE_STATUS","CUST_ID","IN",strValue.c_str());
   hQuery.setOrderByClause("DEVICE_STATUS");
  //## end configuration::GasperStatusCode::bind%3C1A519800CB.body
}

// Additional Declarations
  //## begin configuration::GasperStatusCode%3C1A4FA40280.declarations preserve=yes
  //## end configuration::GasperStatusCode%3C1A4FA40280.declarations

} // namespace configuration

//## begin module%3C1A4CF903D8.epilog preserve=yes
//## end module%3C1A4CF903D8.epilog
