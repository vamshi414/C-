//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%39985C8B02FC.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%39985C8B02FC.cm

//## begin module%39985C8B02FC.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%39985C8B02FC.cp

//## Module: CXOSCF37%39985C8B02FC; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF37.hpp

#ifndef CXOSCF37_h
#define CXOSCF37_h 1

//## begin module%39985C8B02FC.additionalIncludes preserve=no
//## end module%39985C8B02FC.additionalIncludes

//## begin module%39985C8B02FC.includes preserve=yes
// $Date:   Apr 08 2004 14:10:58  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%39985C8B02FC.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%39985C8B02FC.declarations preserve=no
//## end module%39985C8B02FC.declarations

//## begin module%39985C8B02FC.additionalDeclarations preserve=yes
//## end module%39985C8B02FC.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::Base24ReversalCode%39985CF8003B.preface preserve=yes
//## end configuration::Base24ReversalCode%39985CF8003B.preface

//## Class: Base24ReversalCode%39985CF8003B
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%399860150114;reusable::Query { -> F}
//## Uses: <unnamed>%3998601B016C;IF::Extract { -> F}

class DllExport Base24ReversalCode : public ConversionItem  //## Inherits: <unnamed>%399860130201
{
  //## begin configuration::Base24ReversalCode%39985CF8003B.initialDeclarations preserve=yes
  //## end configuration::Base24ReversalCode%39985CF8003B.initialDeclarations

  public:
    //## Constructors (generated)
      Base24ReversalCode();

    //## Destructor (generated)
      virtual ~Base24ReversalCode();


    //## Other Operations (specified)
      //## Operation: bind%39993C120196
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::Base24ReversalCode%39985CF8003B.public preserve=yes
      //## end configuration::Base24ReversalCode%39985CF8003B.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::Base24ReversalCode%39985CF8003B.protected preserve=yes
      //## end configuration::Base24ReversalCode%39985CF8003B.protected

  private:
    // Additional Private Declarations
      //## begin configuration::Base24ReversalCode%39985CF8003B.private preserve=yes
      //## end configuration::Base24ReversalCode%39985CF8003B.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::Base24ReversalCode%39985CF8003B.implementation preserve=yes
      //## end configuration::Base24ReversalCode%39985CF8003B.implementation

};

//## begin configuration::Base24ReversalCode%39985CF8003B.postscript preserve=yes
//## end configuration::Base24ReversalCode%39985CF8003B.postscript

} // namespace configuration

//## begin module%39985C8B02FC.epilog preserve=yes
using namespace configuration;
//## end module%39985C8B02FC.epilog


#endif
