//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64B14DAD01E5.cm preserve=no
//## end module%64B14DAD01E5.cm

//## begin module%64B14DAD01E5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64B14DAD01E5.cp

//## Module: CXOSCFD3%64B14DAD01E5; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFD3.cpp

//## begin module%64B14DAD01E5.additionalIncludes preserve=no
//## end module%64B14DAD01E5.additionalIncludes

//## begin module%64B14DAD01E5.includes preserve=yes
//## end module%64B14DAD01E5.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSCFD3_h
#include "CXODCFD3.hpp"
#endif


//## begin module%64B14DAD01E5.declarations preserve=no
//## end module%64B14DAD01E5.declarations

//## begin module%64B14DAD01E5.additionalDeclarations preserve=yes
//## end module%64B14DAD01E5.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::NetworkInstitution1 

NetworkInstitution1::NetworkInstitution1()
  //## begin NetworkInstitution1::NetworkInstitution1%64B14D7F0072_const.hasinit preserve=no
  //## end NetworkInstitution1::NetworkInstitution1%64B14D7F0072_const.hasinit
  //## begin NetworkInstitution1::NetworkInstitution1%64B14D7F0072_const.initialization preserve=yes
  //## end NetworkInstitution1::NetworkInstitution1%64B14D7F0072_const.initialization
{
  //## begin configuration::NetworkInstitution1::NetworkInstitution1%64B14D7F0072_const.body preserve=yes
   memcpy(m_sID, "CFD3", 4);
  //## end configuration::NetworkInstitution1::NetworkInstitution1%64B14D7F0072_const.body
}


NetworkInstitution1::~NetworkInstitution1()
{
  //## begin configuration::NetworkInstitution1::~NetworkInstitution1%64B14D7F0072_dest.body preserve=yes
  //## end configuration::NetworkInstitution1::~NetworkInstitution1%64B14D7F0072_dest.body
}



//## Other Operations (implementation)
void NetworkInstitution1::bind (Query& hQuery)
{
  //## begin configuration::NetworkInstitution1::bind%64B14E1A03C0.body preserve=yes
   hQuery.setQualifier("QUALIFY", "X_NET_INST_ID");
   hQuery.bind("X_NET_INST_ID", "CUST_ID", Column::STRING, &m_strFirst);
   hQuery.bind("X_NET_INST_ID", "NET_ID", Column::STRING, &m_strNET_ID);
   hQuery.bind("X_NET_INST_ID", "NET_INST_ID_CODE", Column::STRING, &m_strNET_INST_ID_CODE);
   hQuery.bind("X_NET_INST_ID", "PAN_PREFIX", Column::STRING, &m_strPAN_PREFIX);
   hQuery.bind("X_NET_INST_ID", "INST_ID", Column::STRING, &m_strSecond);
   hQuery.setBasicPredicate("X_NET_INST_ID", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_NET_INST_ID", "CC_STATE", "=", "A");
   hQuery.setOrderByClause("X_NET_INST_ID.CUST_ID ASC,"
                           "X_NET_INST_ID.NET_ID ASC,"
                           "X_NET_INST_ID.NET_INST_ID_CODE ASC,"
                           "X_NET_INST_ID.PAN_PREFIX ASC");
  //## end configuration::NetworkInstitution1::bind%64B14E1A03C0.body
}

const string& NetworkInstitution1::getFirst ()
{
  //## begin configuration::NetworkInstitution1::getFirst%64B14E1E01C4.body preserve=yes
   m_strFirst.resize(4, ' ');
   m_strFirst += m_strNET_ID;
   m_strFirst.resize(7, ' ');
   m_strFirst += m_strNET_INST_ID_CODE;
   m_strFirst.resize(18, ' ');
   m_strFirst += m_strPAN_PREFIX;
   m_strFirst.resize(30, ' ');
   return m_strFirst;
  //## end configuration::NetworkInstitution1::getFirst%64B14E1E01C4.body
}

bool NetworkInstitution1::getINST_ID (const string& strNET_ID, const string& strNET_INST_ID_CODE, const string& strPAN_PREFIX, const string& strPROBLEM_TABLE, const string& strPROBLEM_COLUMN, string& strINST_ID, const char* pszCUST_ID)
{
  //## begin configuration::NetworkInstitution1::getINST_ID%64B14E2201EB.body preserve=yes
   string strFirst(Customer::instance()->getCUST_ID());
   if (pszCUST_ID)
      strFirst = pszCUST_ID;
   strFirst.resize(4, ' ');
   strFirst += strNET_ID;
   strFirst.resize(7, ' ');
   strFirst += strNET_INST_ID_CODE;
   strFirst.resize(18, ' ');
   strFirst += strPAN_PREFIX;
   strFirst.resize(31, ' ');
   while (strFirst.length() > 24)
   {
      strFirst.resize(strFirst.length() - 1);
      if (ConfigurationRepository::instance()->translate("X_NET_INST_ID1", strFirst, strINST_ID, strPROBLEM_TABLE, strPROBLEM_COLUMN, 0, false))
         return true;
   }
   if (strPROBLEM_TABLE.empty())
      return false;
   ConfigurationRepository::instance()->translate("X_NET_INST_ID1", strFirst, strINST_ID, strPROBLEM_TABLE, strPROBLEM_COLUMN);
   ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ISS_DATA);
   return false;
  //## end configuration::NetworkInstitution1::getINST_ID%64B14E2201EB.body
}

void NetworkInstitution1::setPredicate (Query& hQuery)
{
  //## begin configuration::NetworkInstitution1::setPredicate%64B14EE90309.body preserve=yes
   hQuery.setBasicPredicate("X_NET_INST_ID", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_NET_INST_ID", "CC_STATE", "=", "A");
  //## end configuration::NetworkInstitution1::setPredicate%64B14EE90309.body
}

// Additional Declarations
  //## begin configuration::NetworkInstitution1%64B14D7F0072.declarations preserve=yes
  //## end configuration::NetworkInstitution1%64B14D7F0072.declarations

} // namespace configuration

//## begin module%64B14DAD01E5.epilog preserve=yes
//## end module%64B14DAD01E5.epilog
