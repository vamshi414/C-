//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3917317B01A1.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3917317B01A1.cm

//## begin module%3917317B01A1.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3917317B01A1.cp

//## Module: CXOSCF06%3917317B01A1; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF06.hpp

#ifndef CXOSCF06_h
#define CXOSCF06_h 1

//## begin module%3917317B01A1.additionalIncludes preserve=no
//## end module%3917317B01A1.additionalIncludes

//## begin module%3917317B01A1.includes preserve=yes
// $Date:   Apr 08 2004 14:10:48  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%3917317B01A1.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%3917317B01A1.declarations preserve=no
//## end module%3917317B01A1.declarations

//## begin module%3917317B01A1.additionalDeclarations preserve=yes
//## end module%3917317B01A1.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::AdvantageCardLogo%3912F08603CF.preface preserve=yes
//## end configuration::AdvantageCardLogo%3912F08603CF.preface

//## Class: AdvantageCardLogo%3912F08603CF
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3912F717024F;reusable::Query { -> F}
//## Uses: <unnamed>%39184A870110;IF::Extract { -> F}

class DllExport AdvantageCardLogo : public ConversionItem  //## Inherits: <unnamed>%3912F09603C8
{
  //## begin configuration::AdvantageCardLogo%3912F08603CF.initialDeclarations preserve=yes
  //## end configuration::AdvantageCardLogo%3912F08603CF.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageCardLogo();

    //## Destructor (generated)
      virtual ~AdvantageCardLogo();


    //## Other Operations (specified)
      //## Operation: bind%3912F52A0387
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::AdvantageCardLogo%3912F08603CF.public preserve=yes
      //## end configuration::AdvantageCardLogo%3912F08603CF.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::AdvantageCardLogo%3912F08603CF.protected preserve=yes
      //## end configuration::AdvantageCardLogo%3912F08603CF.protected

  private:
    // Additional Private Declarations
      //## begin configuration::AdvantageCardLogo%3912F08603CF.private preserve=yes
      //## end configuration::AdvantageCardLogo%3912F08603CF.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::AdvantageCardLogo%3912F08603CF.implementation preserve=yes
      //## end configuration::AdvantageCardLogo%3912F08603CF.implementation

};

//## begin configuration::AdvantageCardLogo%3912F08603CF.postscript preserve=yes
//## end configuration::AdvantageCardLogo%3912F08603CF.postscript

} // namespace configuration

//## begin module%3917317B01A1.epilog preserve=yes
using namespace configuration;
//## end module%3917317B01A1.epilog


#endif
