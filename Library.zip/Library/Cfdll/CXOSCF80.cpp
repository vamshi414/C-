//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4288C42B003E.cm preserve=no
//	$Date:   Dec 12 2016 14:49:02  $ $Author:   e1009652  $
//	$Revision:   1.4  $
//## end module%4288C42B003E.cm

//## begin module%4288C42B003E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4288C42B003E.cp

//## Module: CXOSCF80%4288C42B003E; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF80.cpp

//## begin module%4288C42B003E.additionalIncludes preserve=no
//## end module%4288C42B003E.additionalIncludes

//## begin module%4288C42B003E.includes preserve=yes
//## end module%4288C42B003E.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF80_h
#include "CXODCF80.hpp"
#endif


//## begin module%4288C42B003E.declarations preserve=no
//## end module%4288C42B003E.declarations

//## begin module%4288C42B003E.additionalDeclarations preserve=yes
//## end module%4288C42B003E.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::CountryCodeNum 

CountryCodeNum::CountryCodeNum()
  //## begin CountryCodeNum::CountryCodeNum%4288BB1001B5_const.hasinit preserve=no
  //## end CountryCodeNum::CountryCodeNum%4288BB1001B5_const.hasinit
  //## begin CountryCodeNum::CountryCodeNum%4288BB1001B5_const.initialization preserve=yes
   : ConversionItem("## CR81 XLATE COUNTRY CODE")
  //## end CountryCodeNum::CountryCodeNum%4288BB1001B5_const.initialization
{
  //## begin configuration::CountryCodeNum::CountryCodeNum%4288BB1001B5_const.body preserve=yes
    memcpy(m_sID,"CF80",4);
  //## end configuration::CountryCodeNum::CountryCodeNum%4288BB1001B5_const.body
}


CountryCodeNum::~CountryCodeNum()
{
  //## begin configuration::CountryCodeNum::~CountryCodeNum%4288BB1001B5_dest.body preserve=yes
  //## end configuration::CountryCodeNum::~CountryCodeNum%4288BB1001B5_dest.body
}



//## Other Operations (implementation)
void CountryCodeNum::bind (Query& hQuery)
{
  //## begin configuration::CountryCodeNum::bind%4288BB4600AB.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY", "COUNTRY_CODE");
   hQuery.bind("COUNTRY_CODE","COUNTRY_CODE_ISO3",Column::STRING,&m_strFirst);
   hQuery.bind("COUNTRY_CODE","COUNTRY_CODE",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("COUNTRY_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("COUNTRY_CODE","CC_STATE","=","A"); 
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("COUNTRY_CODE", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("COUNTRY_CODE.COUNTRY_CODE_ISO3 ASC");
  //## end configuration::CountryCodeNum::bind%4288BB4600AB.body
}

// Additional Declarations
  //## begin configuration::CountryCodeNum%4288BB1001B5.declarations preserve=yes
  //## end configuration::CountryCodeNum%4288BB1001B5.declarations

} // namespace configuration

//## begin module%4288C42B003E.epilog preserve=yes
//## end module%4288C42B003E.epilog
