//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4F6C1C130215.cm preserve=no
//	$Date:   Dec 07 2016 15:46:52  $ $Author:   e1009652  $
//	$Revision:   1.8  $
//## end module%4F6C1C130215.cm

//## begin module%4F6C1C130215.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4F6C1C130215.cp

//## Module: CXOSCF31%4F6C1C130215; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF31.hpp

#ifndef CXOSCF31_h
#define CXOSCF31_h 1

//## begin module%4F6C1C130215.additionalIncludes preserve=no
//## end module%4F6C1C130215.additionalIncludes

//## begin module%4F6C1C130215.includes preserve=yes
//## end module%4F6C1C130215.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%4F6C1C130215.declarations preserve=no
//## end module%4F6C1C130215.declarations

//## begin module%4F6C1C130215.additionalDeclarations preserve=yes
//## end module%4F6C1C130215.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::PrepaidNetworkId%4F6C18C70161.preface preserve=yes
//## end configuration::PrepaidNetworkId%4F6C18C70161.preface

//## Class: PrepaidNetworkId%4F6C18C70161
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4F6C208A03A5;reusable::Query { -> F}

class DllExport PrepaidNetworkId : public ConversionItem  //## Inherits: <unnamed>%4F6C88690110
{
  //## begin configuration::PrepaidNetworkId%4F6C18C70161.initialDeclarations preserve=yes
  //## end configuration::PrepaidNetworkId%4F6C18C70161.initialDeclarations

  public:
    //## Constructors (generated)
      PrepaidNetworkId();

    //## Destructor (generated)
      virtual ~PrepaidNetworkId();


    //## Other Operations (specified)
      //## Operation: bind%4F6C1E75034D
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%5847182602EF
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::PrepaidNetworkId%4F6C18C70161.public preserve=yes
      //## end configuration::PrepaidNetworkId%4F6C18C70161.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::PrepaidNetworkId%4F6C18C70161.protected preserve=yes
      //## end configuration::PrepaidNetworkId%4F6C18C70161.protected

  private:
    // Additional Private Declarations
      //## begin configuration::PrepaidNetworkId%4F6C18C70161.private preserve=yes
      //## end configuration::PrepaidNetworkId%4F6C18C70161.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::PrepaidNetworkId%4F6C18C70161.implementation preserve=yes
      //## end configuration::PrepaidNetworkId%4F6C18C70161.implementation

};

//## begin configuration::PrepaidNetworkId%4F6C18C70161.postscript preserve=yes
//## end configuration::PrepaidNetworkId%4F6C18C70161.postscript

} // namespace configuration

//## begin module%4F6C1C130215.epilog preserve=yes
//## end module%4F6C1C130215.epilog


#endif
