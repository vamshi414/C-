//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FF19C7D02EE.cm preserve=no
//	$Date:   Dec 12 2016 12:54:00  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%3FF19C7D02EE.cm

//## begin module%3FF19C7D02EE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FF19C7D02EE.cp

//## Module: CXOSCF47%3FF19C7D02EE; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF47.hpp

#ifndef CXOSCF47_h
#define CXOSCF47_h 1

//## begin module%3FF19C7D02EE.additionalIncludes preserve=no
//## end module%3FF19C7D02EE.additionalIncludes

//## begin module%3FF19C7D02EE.includes preserve=yes
// $Date:   Dec 12 2016 12:54:00  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%3FF19C7D02EE.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%3FF19C7D02EE.declarations preserve=no
//## end module%3FF19C7D02EE.declarations

//## begin module%3FF19C7D02EE.additionalDeclarations preserve=yes
//## end module%3FF19C7D02EE.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexPinEntryMode%3FF19C32038A.preface preserve=yes
//## end configuration::ConnexPinEntryMode%3FF19C32038A.preface

//## Class: ConnexPinEntryMode%3FF19C32038A
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FF19DD4005D;reusable::Query { -> F}
//## Uses: <unnamed>%3FF19DE70196;IF::Extract { -> F}

class DllExport ConnexPinEntryMode : public ConversionItem  //## Inherits: <unnamed>%3FF19DC100CB
{
  //## begin configuration::ConnexPinEntryMode%3FF19C32038A.initialDeclarations preserve=yes
  //## end configuration::ConnexPinEntryMode%3FF19C32038A.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexPinEntryMode();

    //## Destructor (generated)
      virtual ~ConnexPinEntryMode();


    //## Other Operations (specified)
      //## Operation: bind%3FF19E090128
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%584715ED01AE
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexPinEntryMode%3FF19C32038A.public preserve=yes
      //## end configuration::ConnexPinEntryMode%3FF19C32038A.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexPinEntryMode%3FF19C32038A.protected preserve=yes
      //## end configuration::ConnexPinEntryMode%3FF19C32038A.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexPinEntryMode%3FF19C32038A.private preserve=yes
      //## end configuration::ConnexPinEntryMode%3FF19C32038A.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexPinEntryMode%3FF19C32038A.implementation preserve=yes
      //## end configuration::ConnexPinEntryMode%3FF19C32038A.implementation

};

//## begin configuration::ConnexPinEntryMode%3FF19C32038A.postscript preserve=yes
//## end configuration::ConnexPinEntryMode%3FF19C32038A.postscript

} // namespace configuration

//## begin module%3FF19C7D02EE.epilog preserve=yes
using namespace configuration;
//## end module%3FF19C7D02EE.epilog


#endif
