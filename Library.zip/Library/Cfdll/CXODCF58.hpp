//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%400551C0029F.cm preserve=no
//	$Date:   Dec 12 2016 13:10:52  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%400551C0029F.cm

//## begin module%400551C0029F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%400551C0029F.cp

//## Module: CXOSCF58%400551C0029F; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF58.hpp

#ifndef CXOSCF58_h
#define CXOSCF58_h 1

//## begin module%400551C0029F.additionalIncludes preserve=no
//## end module%400551C0029F.additionalIncludes

//## begin module%400551C0029F.includes preserve=yes
// $Date:   Dec 12 2016 13:10:52  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%400551C0029F.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
//## begin module%400551C0029F.declarations preserve=no
//## end module%400551C0029F.declarations

//## begin module%400551C0029F.additionalDeclarations preserve=yes
//## end module%400551C0029F.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexNetworkID%4002FB7401F4.preface preserve=yes
//## end configuration::ConnexNetworkID%4002FB7401F4.preface

//## Class: ConnexNetworkID%4002FB7401F4
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4002FBE30196;reusable::Query { -> F}

class DllExport ConnexNetworkID : public ConversionItem  //## Inherits: <unnamed>%4002FBAC00BB
{
  //## begin configuration::ConnexNetworkID%4002FB7401F4.initialDeclarations preserve=yes
  //## end configuration::ConnexNetworkID%4002FB7401F4.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexNetworkID();

    //## Destructor (generated)
      virtual ~ConnexNetworkID();


    //## Other Operations (specified)
      //## Operation: bind%4002FBCF005D
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%584715B00133
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexNetworkID%4002FB7401F4.public preserve=yes
      //## end configuration::ConnexNetworkID%4002FB7401F4.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexNetworkID%4002FB7401F4.protected preserve=yes
      //## end configuration::ConnexNetworkID%4002FB7401F4.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexNetworkID%4002FB7401F4.private preserve=yes
      //## end configuration::ConnexNetworkID%4002FB7401F4.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexNetworkID%4002FB7401F4.implementation preserve=yes
      //## end configuration::ConnexNetworkID%4002FB7401F4.implementation

};

//## begin configuration::ConnexNetworkID%4002FB7401F4.postscript preserve=yes
//## end configuration::ConnexNetworkID%4002FB7401F4.postscript

} // namespace configuration

//## begin module%400551C0029F.epilog preserve=yes
using namespace configuration;
//## end module%400551C0029F.epilog


#endif
