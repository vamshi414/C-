//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40A51C2B0119.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40A51C2B0119.cm

//## begin module%40A51C2B0119.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40A51C2B0119.cp

//## Module: CXOSCF64%40A51C2B0119; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF64.cpp

//## begin module%40A51C2B0119.additionalIncludes preserve=no
//## end module%40A51C2B0119.additionalIncludes

//## begin module%40A51C2B0119.includes preserve=yes
// $Date:   Jul 21 2004 08:29:16  $ $Author:   D92233  $ $Revision:   1.4  $
//## end module%40A51C2B0119.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSCF64_h
#include "CXODCF64.hpp"
#endif


//## begin module%40A51C2B0119.declarations preserve=no
//## end module%40A51C2B0119.declarations

//## begin module%40A51C2B0119.additionalDeclarations preserve=yes
//## end module%40A51C2B0119.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ImportMapItem 

ImportMapItem::ImportMapItem()
  //## begin ImportMapItem::ImportMapItem%40A384F80128_const.hasinit preserve=no
  //## end ImportMapItem::ImportMapItem%40A384F80128_const.hasinit
  //## begin ImportMapItem::ImportMapItem%40A384F80128_const.initialization preserve=yes
  //## end ImportMapItem::ImportMapItem%40A384F80128_const.initialization
{
  //## begin configuration::ImportMapItem::ImportMapItem%40A384F80128_const.body preserve=yes
   memcpy(m_sID,"CF64",4);
  //## end configuration::ImportMapItem::ImportMapItem%40A384F80128_const.body
}

ImportMapItem::ImportMapItem (const char* pszTemplate)
  //## begin configuration::ImportMapItem::ImportMapItem%40A5284A0271.hasinit preserve=no
  //## end configuration::ImportMapItem::ImportMapItem%40A5284A0271.hasinit
  //## begin configuration::ImportMapItem::ImportMapItem%40A5284A0271.initialization preserve=yes
   : m_strTemplate(pszTemplate)
  //## end configuration::ImportMapItem::ImportMapItem%40A5284A0271.initialization
{
  //## begin configuration::ImportMapItem::ImportMapItem%40A5284A0271.body preserve=yes
   memcpy(m_sID,"CF64",4);
  //## end configuration::ImportMapItem::ImportMapItem%40A5284A0271.body
}


ImportMapItem::~ImportMapItem()
{
  //## begin configuration::ImportMapItem::~ImportMapItem%40A384F80128_dest.body preserve=yes
  //## end configuration::ImportMapItem::~ImportMapItem%40A384F80128_dest.body
}



//## Other Operations (implementation)
bool ImportMapItem::loadDataMap ()
{
  //## begin configuration::ImportMapItem::loadDataMap%40A51F43003E.body preserve=yes
   return true;
  //## end configuration::ImportMapItem::loadDataMap%40A51F43003E.body
}

bool ImportMapItem::findTarget (string& strTokenID, string& strTarget)
{
  //## begin configuration::ImportMapItem::findTarget%40A92075035B.body preserve=yes
   map<string,string,less <string> >::iterator p;
   p = m_hDataMap.find(strTokenID);
   if (p == m_hDataMap.end())
      return false;
   strTarget = (*p).second;
   return true;
  //## end configuration::ImportMapItem::findTarget%40A92075035B.body
}

// Additional Declarations
  //## begin configuration::ImportMapItem%40A384F80128.declarations preserve=yes
  //## end configuration::ImportMapItem%40A384F80128.declarations

} // namespace configuration

//## begin module%40A51C2B0119.epilog preserve=yes
//## end module%40A51C2B0119.epilog
