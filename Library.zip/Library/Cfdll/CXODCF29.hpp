//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%393FFDFA01D0.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%393FFDFA01D0.cm

//## begin module%393FFDFA01D0.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%393FFDFA01D0.cp

//## Module: CXOSCF29%393FFDFA01D0; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF29.hpp

#ifndef CXOSCF29_h
#define CXOSCF29_h 1

//## begin module%393FFDFA01D0.additionalIncludes preserve=no
//## end module%393FFDFA01D0.additionalIncludes

//## begin module%393FFDFA01D0.includes preserve=yes
// $Date:   Apr 08 2004 14:10:56  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%393FFDFA01D0.includes

#ifndef CXOSCF26_h
#include "CXODCF26.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%393FFDFA01D0.declarations preserve=no
//## end module%393FFDFA01D0.declarations

//## begin module%393FFDFA01D0.additionalDeclarations preserve=yes
//## end module%393FFDFA01D0.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::CardOwnerType%393FFCF1034B.preface preserve=yes
//## end configuration::CardOwnerType%393FFCF1034B.preface

//## Class: CardOwnerType%393FFCF1034B
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%393FFDE40341;IF::Extract { -> F}
//## Uses: <unnamed>%393FFDE6038A;reusable::Query { -> F}

class DllExport CardOwnerType : public VerificationItem  //## Inherits: <unnamed>%393FFDE20316
{
  //## begin configuration::CardOwnerType%393FFCF1034B.initialDeclarations preserve=yes
  //## end configuration::CardOwnerType%393FFCF1034B.initialDeclarations

  public:
    //## Constructors (generated)
      CardOwnerType();

    //## Destructor (generated)
      virtual ~CardOwnerType();


    //## Other Operations (specified)
      //## Operation: bind%393FFD3B0370
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::CardOwnerType%393FFCF1034B.public preserve=yes
      //## end configuration::CardOwnerType%393FFCF1034B.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::CardOwnerType%393FFCF1034B.protected preserve=yes
      //## end configuration::CardOwnerType%393FFCF1034B.protected

  private:
    // Additional Private Declarations
      //## begin configuration::CardOwnerType%393FFCF1034B.private preserve=yes
      //## end configuration::CardOwnerType%393FFCF1034B.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::CardOwnerType%393FFCF1034B.implementation preserve=yes
      //## end configuration::CardOwnerType%393FFCF1034B.implementation

};

//## begin configuration::CardOwnerType%393FFCF1034B.postscript preserve=yes
//## end configuration::CardOwnerType%393FFCF1034B.postscript

} // namespace configuration

//## begin module%393FFDFA01D0.epilog preserve=yes
using namespace configuration;
//## end module%393FFDFA01D0.epilog


#endif
