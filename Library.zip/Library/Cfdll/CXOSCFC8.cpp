//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%623C78530337.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%623C78530337.cm

//## begin module%623C78530337.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%623C78530337.cp

//## Module: CXOSCFC8%623C78530337; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFC8.cpp

//## begin module%623C78530337.additionalIncludes preserve=no
//## end module%623C78530337.additionalIncludes

//## begin module%623C78530337.includes preserve=yes
//## end module%623C78530337.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFC8_h
#include "CXODCFC8.hpp"
#endif


//## begin module%623C78530337.declarations preserve=no
//## end module%623C78530337.declarations

//## begin module%623C78530337.additionalDeclarations preserve=yes
//## end module%623C78530337.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::NYCEProcCode 

NYCEProcCode::NYCEProcCode()
  //## begin NYCEProcCode::NYCEProcCode%623C77F303C8_const.hasinit preserve=no
  //## end NYCEProcCode::NYCEProcCode%623C77F303C8_const.hasinit
  //## begin NYCEProcCode::NYCEProcCode%623C77F303C8_const.initialization preserve=yes
   : ConversionItem("## CR12 XLATE PROCESS CODE")
  //## end NYCEProcCode::NYCEProcCode%623C77F303C8_const.initialization
{
  //## begin configuration::NYCEProcCode::NYCEProcCode%623C77F303C8_const.body preserve=yes
   memcpy(m_sID, "CFC8", 4);
  //## end configuration::NYCEProcCode::NYCEProcCode%623C77F303C8_const.body
}


NYCEProcCode::~NYCEProcCode()
{
  //## begin configuration::NYCEProcCode::~NYCEProcCode%623C77F303C8_dest.body preserve=yes
  //## end configuration::NYCEProcCode::~NYCEProcCode%623C77F303C8_dest.body
}



//## Other Operations (implementation)
void NYCEProcCode::bind (Query& hQuery)
{
  //## begin configuration::NYCEProcCode::bind%623C78DC00EE.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY", "X_NYCE_PROC_CODE");
   hQuery.bind("X_NYCE_PROC_CODE", "NYCE_TRAN_TYPE", Column::STRING, &m_strFirst);
   hQuery.bind("X_NYCE_PROC_CODE", "PROCESS_CODE", Column::STRING, &m_strPROCESS_CODE);
   hQuery.bind("X_NYCE_PROC_CODE", "MSG_CLASS", Column::STRING, &m_strMSG_CLASS);
   hQuery.bind("X_NYCE_PROC_CODE", "PRE_AUTH", Column::STRING, &m_strPRE_AUTH);
   hQuery.bind("X_NYCE_PROC_CODE", "MEDIA_TYPE", Column::STRING, &m_strMEDIA_TYPE);
   hQuery.bind("X_NYCE_PROC_CODE", "CUST_ID", Column::STRING, &m_strCUST_ID);
   hQuery.setBasicPredicate("X_NYCE_PROC_CODE", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_NYCE_PROC_CODE", "CC_STATE", "=", "A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_NYCE_PROC_CODE", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("X_NYCE_PROC_CODE.NYCE_TRAN_TYPE ASC");
  //## end configuration::NYCEProcCode::bind%623C78DC00EE.body
}

const string& NYCEProcCode::getFirst ()
{
  //## begin configuration::NYCEProcCode::getFirst%623C78DC00F5.body preserve=yes
   m_strFirst.resize(3, ' ');
   return m_strFirst;
  //## end configuration::NYCEProcCode::getFirst%623C78DC00F5.body
}

const string& NYCEProcCode::getSecond ()
{
  //## begin configuration::NYCEProcCode::getSecond%623C78DC00FE.body preserve=yes
   m_strPROCESS_CODE.resize(6, ' ');
   m_strMSG_CLASS.resize(1, ' ');
   m_strPRE_AUTH.resize(1, ' ');
   m_strMEDIA_TYPE.resize(2, ' ');
   m_strSecond = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strSecond;
  //## end configuration::NYCEProcCode::getSecond%623C78DC00FE.body
}

// Additional Declarations
  //## begin configuration::NYCEProcCode%623C77F303C8.declarations preserve=yes
  //## end configuration::NYCEProcCode%623C77F303C8.declarations

} // namespace configuration

//## begin module%623C78530337.epilog preserve=yes
//## end module%623C78530337.epilog
