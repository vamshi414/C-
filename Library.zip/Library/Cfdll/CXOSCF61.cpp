//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4091522C029F.cm preserve=no
//## end module%4091522C029F.cm

//## begin module%4091522C029F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4091522C029F.cp

//## Module: CXOSCF61%4091522C029F; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF61.cpp

//## begin module%4091522C029F.additionalIncludes preserve=no
//## end module%4091522C029F.additionalIncludes

//## begin module%4091522C029F.includes preserve=yes
//## end module%4091522C029F.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSCF61_h
#include "CXODCF61.hpp"
#endif


//## begin module%4091522C029F.declarations preserve=no
//## end module%4091522C029F.declarations

//## begin module%4091522C029F.additionalDeclarations preserve=yes
//## end module%4091522C029F.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::NetworkInstitution 

NetworkInstitution::NetworkInstitution()
  //## begin NetworkInstitution::NetworkInstitution%40912B9B00EA_const.hasinit preserve=no
  //## end NetworkInstitution::NetworkInstitution%40912B9B00EA_const.hasinit
  //## begin NetworkInstitution::NetworkInstitution%40912B9B00EA_const.initialization preserve=yes
  //## end NetworkInstitution::NetworkInstitution%40912B9B00EA_const.initialization
{
  //## begin configuration::NetworkInstitution::NetworkInstitution%40912B9B00EA_const.body preserve=yes
   memcpy(m_sID,"CF61",4);
  //## end configuration::NetworkInstitution::NetworkInstitution%40912B9B00EA_const.body
}


NetworkInstitution::~NetworkInstitution()
{
  //## begin configuration::NetworkInstitution::~NetworkInstitution%40912B9B00EA_dest.body preserve=yes
  //## end configuration::NetworkInstitution::~NetworkInstitution%40912B9B00EA_dest.body
}



//## Other Operations (implementation)
void NetworkInstitution::bind (Query& hQuery)
{
  //## begin configuration::NetworkInstitution::bind%409153170138.body preserve=yes
   hQuery.setQualifier("QUALIFY", "X_NET_INST_ID");
   hQuery.bind("X_NET_INST_ID", "NET_ID", Column::STRING, &m_strFirst);
   hQuery.bind("X_NET_INST_ID", "NET_INST_ID_CODE", Column::STRING, &m_strNET_INST_ID_CODE);
   hQuery.bind("X_NET_INST_ID", "PAN_PREFIX", Column::STRING, &m_strPAN_PREFIX);
   hQuery.bind("X_NET_INST_ID", "INST_ID", Column::STRING, &m_strSecond);
   hQuery.setBasicPredicate("X_NET_INST_ID", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_NET_INST_ID", "CC_STATE", "=", "A");
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER", strCUST_ID);
   string strTemp = "('" + strCUST_ID + "','****')";
   hQuery.setBasicPredicate("X_NET_INST_ID", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("X_NET_INST_ID.NET_ID ASC,"
                           "X_NET_INST_ID.NET_INST_ID_CODE ASC,"
                           "X_NET_INST_ID.PAN_PREFIX ASC,"
                           "X_NET_INST_ID.CUST_ID DESC");
  //## end configuration::NetworkInstitution::bind%409153170138.body
}

const string& NetworkInstitution::getFirst ()
{
  //## begin configuration::NetworkInstitution::getFirst%4091531E003E.body preserve=yes
   m_strFirst.resize(3, ' ');
   m_strFirst += m_strNET_INST_ID_CODE;
   m_strFirst.resize(14, ' ');
   m_strFirst += m_strPAN_PREFIX;
   return m_strFirst;
  //## end configuration::NetworkInstitution::getFirst%4091531E003E.body
}

bool NetworkInstitution::getINST_ID (const string& strNET_ID, const string& strNET_INST_ID_CODE, const string& strPAN_PREFIX, const string& strPROBLEM_TABLE, const string& strPROBLEM_COLUMN, string& strINST_ID)
{
  //## begin configuration::NetworkInstitution::getINST_ID%500193F80210.body preserve=yes
   string strFirst(strNET_ID);
   strFirst.resize(3, ' ');
   strFirst += strNET_INST_ID_CODE;
   strFirst.resize(14, ' ');
   strFirst += strPAN_PREFIX;
   strFirst.resize(27, ' ');
   while (strFirst.length() > 20)
   {
      strFirst.resize(strFirst.length() - 1);
      if (ConfigurationRepository::instance()->translate("X_NET_INST_ID", strFirst, strINST_ID, strPROBLEM_TABLE, strPROBLEM_COLUMN, 0, false))
         return true;
   }
   if (strPROBLEM_TABLE.empty())
      return false;
   ConfigurationRepository::instance()->translate("X_NET_INST_ID", strFirst, strINST_ID, strPROBLEM_TABLE, strPROBLEM_COLUMN);
   ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ISS_DATA);
   return false;
  //## end configuration::NetworkInstitution::getINST_ID%500193F80210.body
}

// Additional Declarations
  //## begin configuration::NetworkInstitution%40912B9B00EA.declarations preserve=yes
  //## end configuration::NetworkInstitution%40912B9B00EA.declarations

} // namespace configuration

//## begin module%4091522C029F.epilog preserve=yes
//## end module%4091522C029F.epilog
