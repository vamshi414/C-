//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%39985C9101CE.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%39985C9101CE.cm

//## begin module%39985C9101CE.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%39985C9101CE.cp

//## Module: CXOSCF36%39985C9101CE; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF36.hpp

#ifndef CXOSCF36_h
#define CXOSCF36_h 1

//## begin module%39985C9101CE.additionalIncludes preserve=no
//## end module%39985C9101CE.additionalIncludes

//## begin module%39985C9101CE.includes preserve=yes
// $Date:   Apr 08 2004 14:10:58  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%39985C9101CE.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%39985C9101CE.declarations preserve=no
//## end module%39985C9101CE.declarations

//## begin module%39985C9101CE.additionalDeclarations preserve=yes
//## end module%39985C9101CE.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::Base24POSResponseCode%39985CEF00F7.preface preserve=yes
//## end configuration::Base24POSResponseCode%39985CEF00F7.preface

//## Class: Base24POSResponseCode%39985CEF00F7
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3998600C01C5;reusable::Query { -> F}
//## Uses: <unnamed>%3998600E01FA;IF::Extract { -> F}

class DllExport Base24POSResponseCode : public ConversionItem  //## Inherits: <unnamed>%3998600A0276
{
  //## begin configuration::Base24POSResponseCode%39985CEF00F7.initialDeclarations preserve=yes
  //## end configuration::Base24POSResponseCode%39985CEF00F7.initialDeclarations

  public:
    //## Constructors (generated)
      Base24POSResponseCode();

    //## Destructor (generated)
      virtual ~Base24POSResponseCode();


    //## Other Operations (specified)
      //## Operation: bind%39993C0C00D9
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::Base24POSResponseCode%39985CEF00F7.public preserve=yes
      //## end configuration::Base24POSResponseCode%39985CEF00F7.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::Base24POSResponseCode%39985CEF00F7.protected preserve=yes
      //## end configuration::Base24POSResponseCode%39985CEF00F7.protected

  private:
    // Additional Private Declarations
      //## begin configuration::Base24POSResponseCode%39985CEF00F7.private preserve=yes
      //## end configuration::Base24POSResponseCode%39985CEF00F7.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::Base24POSResponseCode%39985CEF00F7.implementation preserve=yes
      //## end configuration::Base24POSResponseCode%39985CEF00F7.implementation

};

//## begin configuration::Base24POSResponseCode%39985CEF00F7.postscript preserve=yes
//## end configuration::Base24POSResponseCode%39985CEF00F7.postscript

} // namespace configuration

//## begin module%39985C9101CE.epilog preserve=yes
using namespace configuration;
//## end module%39985C9101CE.epilog


#endif
