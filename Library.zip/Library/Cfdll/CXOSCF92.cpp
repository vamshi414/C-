//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%45EC32BE03B7.cm preserve=no
//	$Date:   Apr 17 2014 21:06:18  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%45EC32BE03B7.cm

//## begin module%45EC32BE03B7.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%45EC32BE03B7.cp

//## Module: CXOSCF92%45EC32BE03B7; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF92.cpp

//## begin module%45EC32BE03B7.additionalIncludes preserve=no
//## end module%45EC32BE03B7.additionalIncludes

//## begin module%45EC32BE03B7.includes preserve=yes
//## end module%45EC32BE03B7.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF92_h
#include "CXODCF92.hpp"
#endif


//## begin module%45EC32BE03B7.declarations preserve=no
//## end module%45EC32BE03B7.declarations

//## begin module%45EC32BE03B7.additionalDeclarations preserve=yes
//## end module%45EC32BE03B7.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::DeviceAddress 

DeviceAddress::DeviceAddress()
  //## begin DeviceAddress::DeviceAddress%45EC3182011B_const.hasinit preserve=no
  //## end DeviceAddress::DeviceAddress%45EC3182011B_const.hasinit
  //## begin DeviceAddress::DeviceAddress%45EC3182011B_const.initialization preserve=yes
  : ConversionItem("## CR92 CHAIN DEVICE TO ADDRESS")
  //## end DeviceAddress::DeviceAddress%45EC3182011B_const.initialization
{
  //## begin configuration::DeviceAddress::DeviceAddress%45EC3182011B_const.body preserve=yes
   memcpy(m_sID,"CF91",4);
  //## end configuration::DeviceAddress::DeviceAddress%45EC3182011B_const.body
}


DeviceAddress::~DeviceAddress()
{
  //## begin configuration::DeviceAddress::~DeviceAddress%45EC3182011B_dest.body preserve=yes
  //## end configuration::DeviceAddress::~DeviceAddress%45EC3182011B_dest.body
}



//## Other Operations (implementation)
void DeviceAddress::bind (reusable::Query& hQuery)
{
  //## begin configuration::DeviceAddress::bind%45EC357002C4.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","DEVICE");
   hQuery.bind("DEVICE","DEVICE_ID",Column::STRING,&m_strFirst);
   hQuery.bind("DEVICE","ADDRESS",Column::STRING,&m_strSecond);
   hQuery.bind("DEVICE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("DEVICE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("DEVICE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("DEVICE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("DEVICE.DEVICE_ID ASC,DEVICE.CUST_ID DESC");
  //## end configuration::DeviceAddress::bind%45EC357002C4.body
}

// Additional Declarations
  //## begin configuration::DeviceAddress%45EC3182011B.declarations preserve=yes
  //## end configuration::DeviceAddress%45EC3182011B.declarations

} // namespace configuration

//## begin module%45EC32BE03B7.epilog preserve=yes
//## end module%45EC32BE03B7.epilog
