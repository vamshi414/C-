//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4315E8B60203.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%4315E8B60203.cm

//## begin module%4315E8B60203.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%4315E8B60203.cp

//## Module: CXOSCF84%4315E8B60203; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF84.cpp

//## begin module%4315E8B60203.additionalIncludes preserve=no
//## end module%4315E8B60203.additionalIncludes

//## begin module%4315E8B60203.includes preserve=yes
//## end module%4315E8B60203.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF84_h
#include "CXODCF84.hpp"
#endif


//## begin module%4315E8B60203.declarations preserve=no
//## end module%4315E8B60203.declarations

//## begin module%4315E8B60203.additionalDeclarations preserve=yes
//## end module%4315E8B60203.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::StarActionTypeRev 

StarActionTypeRev::StarActionTypeRev()
  //## begin StarActionTypeRev::StarActionTypeRev%4315E85602FD_const.hasinit preserve=no
  //## end StarActionTypeRev::StarActionTypeRev%4315E85602FD_const.hasinit
  //## begin StarActionTypeRev::StarActionTypeRev%4315E85602FD_const.initialization preserve=yes
   : ConversionItem("## CR84 XLATE STAR ACT TYPE REV")
  //## end StarActionTypeRev::StarActionTypeRev%4315E85602FD_const.initialization
{
  //## begin configuration::StarActionTypeRev::StarActionTypeRev%4315E85602FD_const.body preserve=yes
   memcpy(m_sID,"CF84",4);
  //## end configuration::StarActionTypeRev::StarActionTypeRev%4315E85602FD_const.body
}


StarActionTypeRev::~StarActionTypeRev()
{
  //## begin configuration::StarActionTypeRev::~StarActionTypeRev%4315E85602FD_dest.body preserve=yes
  //## end configuration::StarActionTypeRev::~StarActionTypeRev%4315E85602FD_dest.body
}



//## Other Operations (implementation)
void StarActionTypeRev::bind (reusable::Query& hQuery)
{
  //## begin configuration::StarActionTypeRev::bind%4315E9370167.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_STAR_ACTION_TYPE");
   hQuery.bind("X_STAR_ACTION_TYPE","STAR_ACTION_TYPE",Column::STRING,&m_strSecond);
   hQuery.bind("X_STAR_ACTION_TYPE","REQUEST_TYPE",Column::STRING,&m_strREQUEST_TYPE);
   hQuery.bind("X_STAR_ACTION_TYPE","STATUS",Column::STRING,&m_strSTATUS);
   hQuery.bind("X_STAR_ACTION_TYPE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_STAR_ACTION_TYPE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_STAR_ACTION_TYPE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_STAR_ACTION_TYPE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_STAR_ACTION_TYPE.REQUEST_TYPE ASC,"
                           "X_STAR_ACTION_TYPE.STATUS ASC,"
                           "X_STAR_ACTION_TYPE.CUST_ID DESC");
  //## end configuration::StarActionTypeRev::bind%4315E9370167.body
}

const string& StarActionTypeRev::getFirst ()
{
  //## begin configuration::StarActionTypeRev::getFirst%4315E93A003E.body preserve=yes
   m_strFirst = m_strREQUEST_TYPE + m_strSTATUS;
   return m_strFirst;
  //## end configuration::StarActionTypeRev::getFirst%4315E93A003E.body
}

// Additional Declarations
  //## begin configuration::StarActionTypeRev%4315E85602FD.declarations preserve=yes
  //## end configuration::StarActionTypeRev%4315E85602FD.declarations

} // namespace configuration

//## begin module%4315E8B60203.epilog preserve=yes
//## end module%4315E8B60203.epilog
