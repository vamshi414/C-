//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%391053CC018A.cm preserve=no
//	$Date:   Jan 04 2019 08:45:00  $ $Author:   e1009839  $
//	$Revision:   1.5  $
//## end module%391053CC018A.cm

//## begin module%391053CC018A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%391053CC018A.cp

//## Module: CXOSCF04%391053CC018A; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF04.hpp

#ifndef CXOSCF04_h
#define CXOSCF04_h 1

//## begin module%391053CC018A.additionalIncludes preserve=no
//## end module%391053CC018A.additionalIncludes

//## begin module%391053CC018A.includes preserve=yes
// $Date:   Jan 04 2019 08:45:00  $ $Author:   e1009839  $ $Revision:   1.5  $
//## end module%391053CC018A.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConversionTable;
class ConversionItem;
class ConfigurationFactory;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
class Global;
class Thread;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
class Count;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%391053CC018A.declarations preserve=no
//## end module%391053CC018A.declarations

//## begin module%391053CC018A.additionalDeclarations preserve=yes
//## end module%391053CC018A.additionalDeclarations


namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConversionLoader%3910517602C1.preface preserve=yes
//## end configuration::ConversionLoader%3910517602C1.preface

//## Class: ConversionLoader%3910517602C1
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3912EDF00341;ConfigurationFactory { -> F}
//## Uses: <unnamed>%391830B00028;reusable::Global { -> F}
//## Uses: <unnamed>%3918356A010E;reusable::Query { -> F}
//## Uses: <unnamed>%391835CA02ED;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%391835DE010B;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%391838700283;monitor::Count { -> F}
//## Uses: <unnamed>%3D2B065A032C;monitor::UseCase { -> F}
//## Uses: <unnamed>%5BF92F720030;reusable::Thread { -> F}

class DllExport ConversionLoader : public reusable::Observer  //## Inherits: <unnamed>%39105192025D
{
  //## begin configuration::ConversionLoader%3910517602C1.initialDeclarations preserve=yes
  //## end configuration::ConversionLoader%3910517602C1.initialDeclarations

  public:
    //## Constructors (generated)
      ConversionLoader();

    //## Destructor (generated)
      virtual ~ConversionLoader();


    //## Other Operations (specified)
      //## Operation: instance%391054230185
      static ConversionLoader* instance ();

      //## Operation: populate%3911824503CD
      bool populate (ConversionTable* pConversionTable);

      //## Operation: update%391082550004
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin configuration::ConversionLoader%3910517602C1.public preserve=yes
      //## end configuration::ConversionLoader%3910517602C1.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConversionLoader%3910517602C1.protected preserve=yes
      //## end configuration::ConversionLoader%3910517602C1.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConversionLoader%3910517602C1.private preserve=yes
      //## end configuration::ConversionLoader%3910517602C1.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5C05A4AC0208
      //## begin configuration::ConversionLoader::Instance%5C05A4AC0208.attr preserve=no  private: static vector<ConversionLoader*>* {V} 0
      static vector<ConversionLoader*>* m_pInstance;
      //## end configuration::ConversionLoader::Instance%5C05A4AC0208.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Configuration_CAT::<unnamed>%391831380182
      //## Role: ConversionLoader::<m_pConversionTable>%391831390075
      //## begin configuration::ConversionLoader::<m_pConversionTable>%391831390075.role preserve=no  public: configuration::ConversionTable { -> RFHgN}
      ConversionTable *m_pConversionTable;
      //## end configuration::ConversionLoader::<m_pConversionTable>%391831390075.role

      //## Association: DataNavigator Foundation::Configuration_CAT::<unnamed>%39183523012A
      //## Role: ConversionLoader::<m_pConversionItem>%391835230347
      //## begin configuration::ConversionLoader::<m_pConversionItem>%391835230347.role preserve=no  public: configuration::ConversionItem { -> RFHgN}
      ConversionItem *m_pConversionItem;
      //## end configuration::ConversionLoader::<m_pConversionItem>%391835230347.role

    // Additional Implementation Declarations
      //## begin configuration::ConversionLoader%3910517602C1.implementation preserve=yes
      //## end configuration::ConversionLoader%3910517602C1.implementation

};

//## begin configuration::ConversionLoader%3910517602C1.postscript preserve=yes
//## end configuration::ConversionLoader%3910517602C1.postscript

} // namespace configuration

//## begin module%391053CC018A.epilog preserve=yes
using namespace configuration;
//## end module%391053CC018A.epilog


#endif
