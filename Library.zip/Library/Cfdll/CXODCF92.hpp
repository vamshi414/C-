//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%45EC3201006E.cm preserve=no
//	$Date:   Mar 06 2007 17:43:36  $ $Author:   D92705  $
//	$Revision:   1.0  $
//## end module%45EC3201006E.cm

//## begin module%45EC3201006E.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%45EC3201006E.cp

//## Module: CXOSCF92%45EC3201006E; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF92.hpp

#ifndef CXOSCF92_h
#define CXOSCF92_h 1

//## begin module%45EC3201006E.additionalIncludes preserve=no
//## end module%45EC3201006E.additionalIncludes

//## begin module%45EC3201006E.includes preserve=yes
//## end module%45EC3201006E.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%45EC3201006E.declarations preserve=no
//## end module%45EC3201006E.declarations

//## begin module%45EC3201006E.additionalDeclarations preserve=yes
//## end module%45EC3201006E.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::DeviceAddress%45EC3182011B.preface preserve=yes
//## end configuration::DeviceAddress%45EC3182011B.preface

//## Class: DeviceAddress%45EC3182011B
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%45EC39C303B0;IF::Extract { -> F}
//## Uses: <unnamed>%45EC3A1A0073;reusable::Query { -> F}

class DllExport DeviceAddress : public ConversionItem  //## Inherits: <unnamed>%45EC396403B1
{
  //## begin configuration::DeviceAddress%45EC3182011B.initialDeclarations preserve=yes
  //## end configuration::DeviceAddress%45EC3182011B.initialDeclarations

  public:
    //## Constructors (generated)
      DeviceAddress();

    //## Destructor (generated)
      virtual ~DeviceAddress();


    //## Other Operations (specified)
      //## Operation: bind%45EC357002C4
      virtual void bind (reusable::Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::DeviceAddress%45EC3182011B.public preserve=yes
      //## end configuration::DeviceAddress%45EC3182011B.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::DeviceAddress%45EC3182011B.protected preserve=yes
      //## end configuration::DeviceAddress%45EC3182011B.protected

  private:
    // Additional Private Declarations
      //## begin configuration::DeviceAddress%45EC3182011B.private preserve=yes
      //## end configuration::DeviceAddress%45EC3182011B.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::DeviceAddress%45EC3182011B.implementation preserve=yes
      //## end configuration::DeviceAddress%45EC3182011B.implementation

};

//## begin configuration::DeviceAddress%45EC3182011B.postscript preserve=yes
//## end configuration::DeviceAddress%45EC3182011B.postscript

} // namespace configuration

//## begin module%45EC3201006E.epilog preserve=yes
//## end module%45EC3201006E.epilog


#endif
