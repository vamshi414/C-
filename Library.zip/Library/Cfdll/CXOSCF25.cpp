//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%393E6ABD0043.cm preserve=no
//	$Date:   Jan 04 2019 08:49:40  $ $Author:   e1009839  $
//	$Revision:   1.8  $
//## end module%393E6ABD0043.cm

//## begin module%393E6ABD0043.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%393E6ABD0043.cp

//## Module: CXOSCF25%393E6ABD0043; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF25.cpp

//## begin module%393E6ABD0043.additionalIncludes preserve=no
//## end module%393E6ABD0043.additionalIncludes

//## begin module%393E6ABD0043.includes preserve=yes
// $Date:   Jan 04 2019 08:49:40  $ $Author:   e1009839  $ $Revision:   1.8  $
//## end module%393E6ABD0043.includes

#ifndef CXOSMN02_h
#include "CXODMN02.hpp"
#endif
#ifndef CXOSCF02_h
#include "CXODCF02.hpp"
#endif
#ifndef CXOSRU23_h
#include "CXODRU23.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU55_h
#include "CXODRU55.hpp"
#endif
#ifndef CXOSCF25_h
#include "CXODCF25.hpp"
#endif


//## begin module%393E6ABD0043.declarations preserve=no
//## end module%393E6ABD0043.declarations

//## begin module%393E6ABD0043.additionalDeclarations preserve=yes
//## end module%393E6ABD0043.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::VerificationLoader

//## begin configuration::VerificationLoader::Instance%5C05A507024F.attr preserve=no  private: static vector<VerificationLoader*>* {V} 0
vector<VerificationLoader*>* VerificationLoader::m_pInstance = 0;
//## end configuration::VerificationLoader::Instance%5C05A507024F.attr

VerificationLoader::VerificationLoader()
  //## begin VerificationLoader::VerificationLoader%393E6D44008A_const.hasinit preserve=no
  //## end VerificationLoader::VerificationLoader%393E6D44008A_const.hasinit
  //## begin VerificationLoader::VerificationLoader%393E6D44008A_const.initialization preserve=yes
  //## end VerificationLoader::VerificationLoader%393E6D44008A_const.initialization
{
  //## begin configuration::VerificationLoader::VerificationLoader%393E6D44008A_const.body preserve=yes
   memcpy(m_sID,"CF25",4);
  //## end configuration::VerificationLoader::VerificationLoader%393E6D44008A_const.body
}


VerificationLoader::~VerificationLoader()
{
  //## begin configuration::VerificationLoader::~VerificationLoader%393E6D44008A_dest.body preserve=yes
  //## end configuration::VerificationLoader::~VerificationLoader%393E6D44008A_dest.body
}



//## Other Operations (implementation)
VerificationLoader* VerificationLoader::instance ()
{
  //## begin configuration::VerificationLoader::instance%393E708503B3.body preserve=yes
   if (!m_pInstance)
   {
      m_pInstance = new vector<VerificationLoader*>;
      m_pInstance->reserve(reusable::Thread::getTotal());
      for (int i = 0;i < reusable::Thread::getTotal();++i)
         m_pInstance->push_back(0);
   }
   int i = reusable::Thread::getNumber();
   if (!(*m_pInstance)[i])
      (*m_pInstance)[i] = new VerificationLoader();
   return (*m_pInstance)[i];
  //## end configuration::VerificationLoader::instance%393E708503B3.body
}

bool VerificationLoader::populate (VerificationTable* pVerificationTable)
{
  //## begin configuration::VerificationLoader::populate%393E708503DB.body preserve=yes
   UseCase hUseCase("CR","## CR27 LOAD VERIFY TABLE");
   m_pVerificationTable = pVerificationTable;
   m_pVerificationItem = (VerificationItem*)ConfigurationFactory::instance()->createVerificationItem(pVerificationTable->getTableName().c_str());
   if (m_pVerificationItem == 0)
   {
      UseCase::setSuccess(false);
      return false;
   }
   Query hQuery;
   hQuery.attach(this);
   m_pVerificationItem->bind(hQuery);
   m_pVerificationTable->setMember(m_pVerificationItem->getMember());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == false)
   {
      UseCase::setSuccess(false);
      delete m_pVerificationItem;
      return false;
   }
   delete m_pVerificationItem;
   return true;
  //## end configuration::VerificationLoader::populate%393E708503DB.body
}

void VerificationLoader::update (Subject* pSubject)
{
  //## begin configuration::VerificationLoader::update%393E70860011.body preserve=yes
   m_pVerificationTable->add(m_pVerificationItem->getKey());
   UseCase::addItem();
  //## end configuration::VerificationLoader::update%393E70860011.body
}

// Additional Declarations
  //## begin configuration::VerificationLoader%393E6D44008A.declarations preserve=yes
  //## end configuration::VerificationLoader%393E6D44008A.declarations

} // namespace configuration

//## begin module%393E6ABD0043.epilog preserve=yes
//## end module%393E6ABD0043.epilog
