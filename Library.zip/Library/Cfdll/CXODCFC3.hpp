//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%620DA99003B7.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%620DA99003B7.cm

//## begin module%620DA99003B7.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%620DA99003B7.cp

//## Module: CXOSCFC3%620DA99003B7; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCFC3.hpp

#ifndef CXOSCFC3_h
#define CXOSCFC3_h 1

//## begin module%620DA99003B7.additionalIncludes preserve=no
//## end module%620DA99003B7.additionalIncludes

//## begin module%620DA99003B7.includes preserve=yes
//## end module%620DA99003B7.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%620DA99003B7.declarations preserve=no
//## end module%620DA99003B7.declarations

//## begin module%620DA99003B7.additionalDeclarations preserve=yes
//## end module%620DA99003B7.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::AIMSBillingInstitutionReverse%620DA7E501AB.preface preserve=yes
//## end configuration::AIMSBillingInstitutionReverse%620DA7E501AB.preface

//## Class: AIMSBillingInstitutionReverse%620DA7E501AB
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%620DA8010320;reusable::Query { -> F}
//## Uses: <unnamed>%620DA80601DF;IF::Extract { -> F}

class DllExport AIMSBillingInstitutionReverse : public ConversionItem  //## Inherits: <unnamed>%620DA7FD0308
{
  //## begin configuration::AIMSBillingInstitutionReverse%620DA7E501AB.initialDeclarations preserve=yes
  //## end configuration::AIMSBillingInstitutionReverse%620DA7E501AB.initialDeclarations

  public:
    //## Constructors (generated)
      AIMSBillingInstitutionReverse();

    //## Destructor (generated)
      virtual ~AIMSBillingInstitutionReverse();


    //## Other Operations (specified)
      //## Operation: bind%620DA81801DA
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%620DA87A0057
      virtual const string& getFirst ();

      //## Operation: getSecond%620DA87C030E
      virtual const string& getSecond ();

      //## Operation: getThird%620FB45F0045
      virtual const string& getThird ();

    // Additional Public Declarations
      //## begin configuration::AIMSBillingInstitutionReverse%620DA7E501AB.public preserve=yes
      //## end configuration::AIMSBillingInstitutionReverse%620DA7E501AB.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::AIMSBillingInstitutionReverse%620DA7E501AB.protected preserve=yes
      //## end configuration::AIMSBillingInstitutionReverse%620DA7E501AB.protected

  private:
    // Additional Private Declarations
      //## begin configuration::AIMSBillingInstitutionReverse%620DA7E501AB.private preserve=yes
      //## end configuration::AIMSBillingInstitutionReverse%620DA7E501AB.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CATEGORY_ID%620DCC0B0047
      //## begin configuration::AIMSBillingInstitutionReverse::CATEGORY_ID%620DCC0B0047.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strCATEGORY_ID;
      //## end configuration::AIMSBillingInstitutionReverse::CATEGORY_ID%620DCC0B0047.attr

      //## Attribute: ITEM_NO%620DCBEC01C9
      //## begin configuration::AIMSBillingInstitutionReverse::ITEM_NO%620DCBEC01C9.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strITEM_NO;
      //## end configuration::AIMSBillingInstitutionReverse::ITEM_NO%620DCBEC01C9.attr

    // Additional Implementation Declarations
      //## begin configuration::AIMSBillingInstitutionReverse%620DA7E501AB.implementation preserve=yes
      //## end configuration::AIMSBillingInstitutionReverse%620DA7E501AB.implementation

};

//## begin configuration::AIMSBillingInstitutionReverse%620DA7E501AB.postscript preserve=yes
//## end configuration::AIMSBillingInstitutionReverse%620DA7E501AB.postscript

} // namespace configuration

//## begin module%620DA99003B7.epilog preserve=yes
//## end module%620DA99003B7.epilog


#endif
