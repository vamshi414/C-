//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4CD03A3000E0.cm preserve=no
//	$Date:   Dec 16 2016 15:36:42  $ $Author:   e1009652  $
//	$Revision:   1.3  $
//## end module%4CD03A3000E0.cm

//## begin module%4CD03A3000E0.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4CD03A3000E0.cp

//## Module: CXOSCF99%4CD03A3000E0; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF99.cpp

//## begin module%4CD03A3000E0.additionalIncludes preserve=no
//## end module%4CD03A3000E0.additionalIncludes

//## begin module%4CD03A3000E0.includes preserve=yes
#include "CXODIF16.hpp"
//## end module%4CD03A3000E0.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF99_h
#include "CXODCF99.hpp"
#endif


//## begin module%4CD03A3000E0.declarations preserve=no
//## end module%4CD03A3000E0.declarations

//## begin module%4CD03A3000E0.additionalDeclarations preserve=yes
//## end module%4CD03A3000E0.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::InstitutionBankID 

InstitutionBankID::InstitutionBankID()
  //## begin InstitutionBankID::InstitutionBankID%4CD039FB018B_const.hasinit preserve=no
  //## end InstitutionBankID::InstitutionBankID%4CD039FB018B_const.hasinit
  //## begin InstitutionBankID::InstitutionBankID%4CD039FB018B_const.initialization preserve=yes
  //## end InstitutionBankID::InstitutionBankID%4CD039FB018B_const.initialization
{
  //## begin configuration::InstitutionBankID::InstitutionBankID%4CD039FB018B_const.body preserve=yes
   memcpy(m_sID,"CF99",4);
  //## end configuration::InstitutionBankID::InstitutionBankID%4CD039FB018B_const.body
}


InstitutionBankID::~InstitutionBankID()
{
  //## begin configuration::InstitutionBankID::~InstitutionBankID%4CD039FB018B_dest.body preserve=yes
  //## end configuration::InstitutionBankID::~InstitutionBankID%4CD039FB018B_dest.body
}



//## Other Operations (implementation)
void InstitutionBankID::bind (Query& hQuery)
{
  //## begin configuration::InstitutionBankID::bind%4CD03B1300C2.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","INSTITUTION");
   hQuery.bind("INSTITUTION","INST_ID",Column::STRING,&m_strFirst);
   hQuery.bind("INSTITUTION","BANK_ID",Column::STRING,&m_strSecond);
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("INSTITUTION","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("INSTITUTION.INST_ID ASC");
  //## end configuration::InstitutionBankID::bind%4CD03B1300C2.body
}

void InstitutionBankID::setPredicate (Query& hQuery)
{
  //## begin configuration::InstitutionBankID::setPredicate%5847177900F4.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("INSTITUTION", "CUST_ID", "IN", strTemp.c_str());
  //## end configuration::InstitutionBankID::setPredicate%5847177900F4.body
}

// Additional Declarations
  //## begin configuration::InstitutionBankID%4CD039FB018B.declarations preserve=yes
  //## end configuration::InstitutionBankID%4CD039FB018B.declarations

} // namespace configuration

//## begin module%4CD03A3000E0.epilog preserve=yes
//## end module%4CD03A3000E0.epilog
