//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3917328601FF.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%3917328601FF.cm

//## begin module%3917328601FF.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%3917328601FF.cp

//## Module: CXOSCF08%3917328601FF; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF08.cpp

//## begin module%3917328601FF.additionalIncludes preserve=no
//## end module%3917328601FF.additionalIncludes

//## begin module%3917328601FF.includes preserve=yes
// $Date:   May 26 2020 10:44:44  $ $Author:   e1009510  $ $Revision:   1.10  $
#include <stdio.h>
//## end module%3917328601FF.includes

#ifndef CXOSCF08_h
#include "CXODCF08.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%3917328601FF.declarations preserve=no
//## end module%3917328601FF.declarations

//## begin module%3917328601FF.additionalDeclarations preserve=yes
//## end module%3917328601FF.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::AdvantageMessageCode




AdvantageMessageCode::AdvantageMessageCode()
  //## begin AdvantageMessageCode::AdvantageMessageCode%3912F128016F_const.hasinit preserve=no
  //## end AdvantageMessageCode::AdvantageMessageCode%3912F128016F_const.hasinit
  //## begin AdvantageMessageCode::AdvantageMessageCode%3912F128016F_const.initialization preserve=yes
   : ConversionItem("## CR11 XLATE MESSAGE CODE")
  //## end AdvantageMessageCode::AdvantageMessageCode%3912F128016F_const.initialization
{
  //## begin configuration::AdvantageMessageCode::AdvantageMessageCode%3912F128016F_const.body preserve=yes
   memcpy(m_sID,"CF08",4);
  //## end configuration::AdvantageMessageCode::AdvantageMessageCode%3912F128016F_const.body
}


AdvantageMessageCode::~AdvantageMessageCode()
{
  //## begin configuration::AdvantageMessageCode::~AdvantageMessageCode%3912F128016F_dest.body preserve=yes
  //## end configuration::AdvantageMessageCode::~AdvantageMessageCode%3912F128016F_dest.body
}



//## Other Operations (implementation)
void AdvantageMessageCode::bind (Query& hQuery)
{
  //## begin configuration::AdvantageMessageCode::bind%3912F79402A9.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_ADV_MSG_CODE");
   hQuery.bind("X_ADV_MSG_CODE","ADVG_MSG_CODE",Column::LONG,&m_lADVG_MSG_CODE);
   hQuery.bind("X_ADV_MSG_CODE","ADVG_STEP",Column::LONG,&m_lADVG_STEP);
   hQuery.bind("X_ADV_MSG_CODE","FIN_TRAN_TYPE",Column::LONG,&m_lFIN_TRAN_TYPE);
   hQuery.bind("X_ADV_MSG_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_ADV_MSG_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_ADV_MSG_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_ADV_MSG_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_ADV_MSG_CODE.ADVG_MSG_CODE ASC,"
                           "X_ADV_MSG_CODE.ADVG_STEP ASC,"
                           "X_ADV_MSG_CODE.CUST_ID DESC");
  //## end configuration::AdvantageMessageCode::bind%3912F79402A9.body
}

const string& AdvantageMessageCode::getFirst ()
{
  //## begin configuration::AdvantageMessageCode::getFirst%3912F79601C6.body preserve=yes
   char tempChar[9];
   snprintf(tempChar,sizeof(tempChar), "%04d%04d", m_lADVG_MSG_CODE, m_lADVG_STEP);
   m_strFirst = tempChar;
   return m_strFirst;
  //## end configuration::AdvantageMessageCode::getFirst%3912F79601C6.body
}

const string& AdvantageMessageCode::getSecond ()
{
  //## begin configuration::AdvantageMessageCode::getSecond%3950BD8802C2.body preserve=yes
   char tempChar[4];
   snprintf(tempChar,sizeof(tempChar), "%03d", m_lFIN_TRAN_TYPE);
   m_strSecond = tempChar;
   return m_strSecond;
  //## end configuration::AdvantageMessageCode::getSecond%3950BD8802C2.body
}

// Additional Declarations
  //## begin configuration::AdvantageMessageCode%3912F128016F.declarations preserve=yes
  //## end configuration::AdvantageMessageCode%3912F128016F.declarations

} // namespace configuration

//## begin module%3917328601FF.epilog preserve=yes
//## end module%3917328601FF.epilog
