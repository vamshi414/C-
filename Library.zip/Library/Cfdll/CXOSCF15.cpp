//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%391C0E0F0153.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%391C0E0F0153.cm

//## begin module%391C0E0F0153.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%391C0E0F0153.cp

//## Module: CXOSCF15%391C0E0F0153; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF15.cpp

//## begin module%391C0E0F0153.additionalIncludes preserve=no
//## end module%391C0E0F0153.additionalIncludes

//## begin module%391C0E0F0153.includes preserve=yes
// $Date:   Apr 17 2014 20:59:22  $ $Author:   e1009652  $ $Revision:   1.6  $
//## end module%391C0E0F0153.includes

#ifndef CXOSCF15_h
#include "CXODCF15.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%391C0E0F0153.declarations preserve=no
//## end module%391C0E0F0153.declarations

//## begin module%391C0E0F0153.additionalDeclarations preserve=yes
//## end module%391C0E0F0153.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::PlusCorrectionReason

PlusCorrectionReason::PlusCorrectionReason()
  //## begin PlusCorrectionReason::PlusCorrectionReason%391C0C7E011A_const.hasinit preserve=no
  //## end PlusCorrectionReason::PlusCorrectionReason%391C0C7E011A_const.hasinit
  //## begin PlusCorrectionReason::PlusCorrectionReason%391C0C7E011A_const.initialization preserve=yes
   : ConversionItem("## CR18 XLATE PLUS CORRECTION")
  //## end PlusCorrectionReason::PlusCorrectionReason%391C0C7E011A_const.initialization
{
  //## begin configuration::PlusCorrectionReason::PlusCorrectionReason%391C0C7E011A_const.body preserve=yes
   memcpy(m_sID,"CF15",4);
  //## end configuration::PlusCorrectionReason::PlusCorrectionReason%391C0C7E011A_const.body
}


PlusCorrectionReason::~PlusCorrectionReason()
{
  //## begin configuration::PlusCorrectionReason::~PlusCorrectionReason%391C0C7E011A_dest.body preserve=yes
  //## end configuration::PlusCorrectionReason::~PlusCorrectionReason%391C0C7E011A_dest.body
}



//## Other Operations (implementation)
void PlusCorrectionReason::bind (Query& hQuery)
{
  //## begin configuration::PlusCorrectionReason::bind%391C1BE60126.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_PLUS_CRCT_REASON");
   hQuery.bind("X_PLUS_CRCT_REASON","PLUS_CORECT_REASON",Column::STRING,&m_strFirst);
   hQuery.bind("X_PLUS_CRCT_REASON","MSG_REASON_CODE",Column::STRING,&m_strSecond);
   hQuery.bind("X_PLUS_CRCT_REASON","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_PLUS_CRCT_REASON","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_PLUS_CRCT_REASON","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_PLUS_CRCT_REASON","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_PLUS_CRCT_REASON.PLUS_CORECT_REASON ASC,X_PLUS_CRCT_REASON.CUST_ID DESC");
  //## end configuration::PlusCorrectionReason::bind%391C1BE60126.body
}

// Additional Declarations
  //## begin configuration::PlusCorrectionReason%391C0C7E011A.declarations preserve=yes
  //## end configuration::PlusCorrectionReason%391C0C7E011A.declarations

} // namespace configuration

//## begin module%391C0E0F0153.epilog preserve=yes
//## end module%391C0E0F0153.epilog
