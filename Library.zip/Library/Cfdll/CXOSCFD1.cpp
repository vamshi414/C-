//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%62BDD9A201C6.cm preserve=no
//## end module%62BDD9A201C6.cm

//## begin module%62BDD9A201C6.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%62BDD9A201C6.cp

//## Module: CXOSCFD1%62BDD9A201C6; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFD1.cpp

//## begin module%62BDD9A201C6.additionalIncludes preserve=no
//## end module%62BDD9A201C6.additionalIncludes

//## begin module%62BDD9A201C6.includes preserve=yes
//## end module%62BDD9A201C6.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFD1_h
#include "CXODCFD1.hpp"
#endif


//## begin module%62BDD9A201C6.declarations preserve=no
//## end module%62BDD9A201C6.declarations

//## begin module%62BDD9A201C6.additionalDeclarations preserve=yes
//## end module%62BDD9A201C6.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ActionTypeRev 

ActionTypeRev::ActionTypeRev()
  //## begin ActionTypeRev::ActionTypeRev%62BDDAF101EA_const.hasinit preserve=no
  //## end ActionTypeRev::ActionTypeRev%62BDDAF101EA_const.hasinit
  //## begin ActionTypeRev::ActionTypeRev%62BDDAF101EA_const.initialization preserve=yes
  : ConversionItem("## CFD1 XLATE ACTION TYPE REV")
  //## end ActionTypeRev::ActionTypeRev%62BDDAF101EA_const.initialization
{
  //## begin configuration::ActionTypeRev::ActionTypeRev%62BDDAF101EA_const.body preserve=yes
  //## end configuration::ActionTypeRev::ActionTypeRev%62BDDAF101EA_const.body
}


ActionTypeRev::~ActionTypeRev()
{
  //## begin configuration::ActionTypeRev::~ActionTypeRev%62BDDAF101EA_dest.body preserve=yes
  //## end configuration::ActionTypeRev::~ActionTypeRev%62BDDAF101EA_dest.body
}



//## Other Operations (implementation)
void ActionTypeRev::bind (Query& hQuery)
{
  //## begin configuration::ActionTypeRev::bind%62BDDBC00084.body preserve=yes
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.setQualifier("QUALIFY","X_ACTION_TYPE");
   hQuery.bind("X_ACTION_TYPE","ACTION_TYPE",Column::STRING,&m_strSecond);
   hQuery.bind("X_ACTION_TYPE","NETWORK_ID",Column::STRING,&m_strFirst);
   hQuery.bind("X_ACTION_TYPE","REQUEST_TYPE",Column::STRING,&m_strREQUEST_TYPE);
   hQuery.bind("X_ACTION_TYPE","STATUS",Column::STRING,&m_strSTATUS);
   hQuery.bind("X_ACTION_TYPE","ROLE",Column::STRING,&m_strROLE);
   hQuery.bind("X_ACTION_TYPE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_ACTION_TYPE","CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_ACTION_TYPE","CC_STATE", "=", "A");
   string strTemp = "('" + strCUST_ID + "','****')";
   hQuery.setBasicPredicate("X_ACTION_TYPE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_ACTION_TYPE.NETWORK_ID ASC,X_ACTION_TYPE.REQUEST_TYPE ASC,"
                           "X_ACTION_TYPE.STATUS ASC,X_ACTION_TYPE.ROLE ASC,"
                           "X_ACTION_TYPE.CUST_ID DESC");
  //## end configuration::ActionTypeRev::bind%62BDDBC00084.body
}

const string& ActionTypeRev::getFirst ()
{
  //## begin configuration::ActionTypeRev::getFirst%62BDDC6E016D.body preserve=yes
   m_strFirst.resize(3,' ');
   m_strFirst += m_strREQUEST_TYPE;
   m_strFirst.resize(7,' ');
   m_strFirst += m_strSTATUS;
   m_strFirst.resize(11,' ');
   m_strFirst += m_strROLE;
   m_strFirst.resize(12,' ');
   return m_strFirst;
  //## end configuration::ActionTypeRev::getFirst%62BDDC6E016D.body
}

// Additional Declarations
  //## begin configuration::ActionTypeRev%62BDDAF101EA.declarations preserve=yes
  //## end configuration::ActionTypeRev%62BDDAF101EA.declarations

} // namespace configuration

//## begin module%62BDD9A201C6.epilog preserve=yes
//## end module%62BDD9A201C6.epilog
