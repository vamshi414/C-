//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3ACA39C6034F.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3ACA39C6034F.cm

//## begin module%3ACA39C6034F.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3ACA39C6034F.cp

//## Module: CXOSCF41%3ACA39C6034F; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF41.cpp

//## begin module%3ACA39C6034F.additionalIncludes preserve=no
//## end module%3ACA39C6034F.additionalIncludes

//## begin module%3ACA39C6034F.includes preserve=yes
// $Date:   Apr 08 2004 14:11:20  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%3ACA39C6034F.includes

#ifndef CXOSCF41_h
#include "CXODCF41.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%3ACA39C6034F.declarations preserve=no
//## end module%3ACA39C6034F.declarations

//## begin module%3ACA39C6034F.additionalDeclarations preserve=yes
//## end module%3ACA39C6034F.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::MappingItem 








MappingItem::MappingItem()
  //## begin MappingItem::MappingItem%3ACA392B014D_const.hasinit preserve=no
  //## end MappingItem::MappingItem%3ACA392B014D_const.hasinit
  //## begin MappingItem::MappingItem%3ACA392B014D_const.initialization preserve=yes
  //## end MappingItem::MappingItem%3ACA392B014D_const.initialization
{
  //## begin configuration::MappingItem::MappingItem%3ACA392B014D_const.body preserve=yes
   memcpy(m_sID,"CF41",4);
  //## end configuration::MappingItem::MappingItem%3ACA392B014D_const.body
}

MappingItem::MappingItem (const char* pszMember)
  //## begin configuration::MappingItem::MappingItem%3ACA3B8801CF.hasinit preserve=no
  //## end configuration::MappingItem::MappingItem%3ACA3B8801CF.hasinit
  //## begin configuration::MappingItem::MappingItem%3ACA3B8801CF.initialization preserve=yes
   : m_strMember(pszMember)
  //## end configuration::MappingItem::MappingItem%3ACA3B8801CF.initialization
{
  //## begin configuration::MappingItem::MappingItem%3ACA3B8801CF.body preserve=yes
   memcpy(m_sID,"CF41",4);
  //## end configuration::MappingItem::MappingItem%3ACA3B8801CF.body
}


MappingItem::~MappingItem()
{
  //## begin configuration::MappingItem::~MappingItem%3ACA392B014D_dest.body preserve=yes
  //## end configuration::MappingItem::~MappingItem%3ACA392B014D_dest.body
}



//## Other Operations (implementation)
void MappingItem::bind (Query& hQuery)
{
  //## begin configuration::MappingItem::bind%3ACA3BB200AD.body preserve=yes
  //## end configuration::MappingItem::bind%3ACA3BB200AD.body
}

const string& MappingItem::getPrimary ()
{
  //## begin configuration::MappingItem::getPrimary%3ACA3BB50382.body preserve=yes
   return m_strPrimary;
  //## end configuration::MappingItem::getPrimary%3ACA3BB50382.body
}

const string& MappingItem::getSecondary ()
{
  //## begin configuration::MappingItem::getSecondary%3ACA3BB800FC.body preserve=yes
   return m_strSecondary;
  //## end configuration::MappingItem::getSecondary%3ACA3BB800FC.body
}

const string& MappingItem::getTertiary ()
{
  //## begin configuration::MappingItem::getTertiary%3ACDD5E900A0.body preserve=yes
   return m_strTertiary;
  //## end configuration::MappingItem::getTertiary%3ACDD5E900A0.body
}

const string& MappingItem::getResult ()
{
  //## begin configuration::MappingItem::getResult%3ACDD60E014E.body preserve=yes
   return m_strResult;
  //## end configuration::MappingItem::getResult%3ACDD60E014E.body
}

// Additional Declarations
  //## begin configuration::MappingItem%3ACA392B014D.declarations preserve=yes
  //## end configuration::MappingItem%3ACA392B014D.declarations

} // namespace configuration

//## begin module%3ACA39C6034F.epilog preserve=yes
//## end module%3ACA39C6034F.epilog
