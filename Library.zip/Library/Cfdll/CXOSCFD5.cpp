//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64DF815D012D.cm preserve=no
//## end module%64DF815D012D.cm

//## begin module%64DF815D012D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64DF815D012D.cp

//## Module: CXOSCFD5%64DF815D012D; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFD5.cpp

//## begin module%64DF815D012D.additionalIncludes preserve=no
//## end module%64DF815D012D.additionalIncludes

//## begin module%64DF815D012D.includes preserve=yes
//## end module%64DF815D012D.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFD5_h
#include "CXODCFD5.hpp"
#endif


//## begin module%64DF815D012D.declarations preserve=no
//## end module%64DF815D012D.declarations

//## begin module%64DF815D012D.additionalDeclarations preserve=yes
//## end module%64DF815D012D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ReportingLevelBusiness 

ReportingLevelBusiness::ReportingLevelBusiness()
  //## begin ReportingLevelBusiness::ReportingLevelBusiness%64DF832701C4_const.hasinit preserve=no
  //## end ReportingLevelBusiness::ReportingLevelBusiness%64DF832701C4_const.hasinit
  //## begin ReportingLevelBusiness::ReportingLevelBusiness%64DF832701C4_const.initialization preserve=yes
   : VerificationItem("## CFD5 VERIFY REPORTING LVL ID")
  //## end ReportingLevelBusiness::ReportingLevelBusiness%64DF832701C4_const.initialization
{
  //## begin configuration::ReportingLevelBusiness::ReportingLevelBusiness%64DF832701C4_const.body preserve=yes
   memcpy(m_sID, "CFD5", 4);
  //## end configuration::ReportingLevelBusiness::ReportingLevelBusiness%64DF832701C4_const.body
}


ReportingLevelBusiness::~ReportingLevelBusiness()
{
  //## begin configuration::ReportingLevelBusiness::~ReportingLevelBusiness%64DF832701C4_dest.body preserve=yes
  //## end configuration::ReportingLevelBusiness::~ReportingLevelBusiness%64DF832701C4_dest.body
}



//## Other Operations (implementation)
void ReportingLevelBusiness::bind (Query& hQuery)
{
  //## begin configuration::ReportingLevelBusiness::bind%64DF87300000.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY", "REPORTING_LVL_BUS");
   hQuery.bind("REPORTING_LVL_BUS", "RPT_LVL_ID", Column::STRING, &m_strKey);
   hQuery.bind("REPORTING_LVL_BUS", "CUST_ID", Column::STRING, &m_strCUST_ID);
   hQuery.setBasicPredicate("REPORTING_LVL_BUS", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("REPORTING_LVL_BUS", "CC_STATE", "=", "A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("REPORTING_LVL_BUS", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("REPORTING_LVL_BUS.CUST_ID DESC");
  //## end configuration::ReportingLevelBusiness::bind%64DF87300000.body
}

// Additional Declarations
  //## begin configuration::ReportingLevelBusiness%64DF832701C4.declarations preserve=yes
  //## end configuration::ReportingLevelBusiness%64DF832701C4.declarations

} // namespace configuration

//## begin module%64DF815D012D.epilog preserve=yes
//## end module%64DF815D012D.epilog
