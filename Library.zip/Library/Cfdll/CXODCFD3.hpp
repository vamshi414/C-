//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64B14DAB0380.cm preserve=no
//## end module%64B14DAB0380.cm

//## begin module%64B14DAB0380.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64B14DAB0380.cp

//## Module: CXOSCFD3%64B14DAB0380; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCFD3.hpp

#ifndef CXOSCFD3_h
#define CXOSCFD3_h 1

//## begin module%64B14DAB0380.additionalIncludes preserve=no
//## end module%64B14DAB0380.additionalIncludes

//## begin module%64B14DAB0380.includes preserve=yes
//## end module%64B14DAB0380.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;

} // namespace configuration

//## begin module%64B14DAB0380.declarations preserve=no
//## end module%64B14DAB0380.declarations

//## begin module%64B14DAB0380.additionalDeclarations preserve=yes
//## end module%64B14DAB0380.additionalDeclarations


namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::NetworkInstitution1%64B14D7F0072.preface preserve=yes
//## end configuration::NetworkInstitution1%64B14D7F0072.preface

//## Class: NetworkInstitution1%64B14D7F0072
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%64B14E5C02B2;reusable::Query { -> F}
//## Uses: <unnamed>%64B14E69032C;IF::Extract { -> F}
//## Uses: <unnamed>%64B14E760340;ConfigurationRepository { -> F}
//## Uses: <unnamed>%64B14E840172;entitysegment::Customer { -> F}

class DllExport NetworkInstitution1 : public ConversionItem  //## Inherits: <unnamed>%64B14E4D03E3
{
  //## begin configuration::NetworkInstitution1%64B14D7F0072.initialDeclarations preserve=yes
  //## end configuration::NetworkInstitution1%64B14D7F0072.initialDeclarations

  public:
    //## Constructors (generated)
      NetworkInstitution1();

    //## Destructor (generated)
      virtual ~NetworkInstitution1();


    //## Other Operations (specified)
      //## Operation: bind%64B14E1A03C0
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%64B14E1E01C4
      virtual const string& getFirst ();

      //## Operation: getINST_ID%64B14E2201EB
      static bool getINST_ID (const string& strNET_ID, const string& strNET_INST_ID_CODE, const string& strPAN_PREFIX, const string& strPROBLEM_TABLE, const string& strPROBLEM_COLUMN, string& strINST_ID, const char* pszCUST_ID = 0);

      //## Operation: setPredicate%64B14EE90309
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::NetworkInstitution1%64B14D7F0072.public preserve=yes
      //## end configuration::NetworkInstitution1%64B14D7F0072.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::NetworkInstitution1%64B14D7F0072.protected preserve=yes
      //## end configuration::NetworkInstitution1%64B14D7F0072.protected

  private:
    // Additional Private Declarations
      //## begin configuration::NetworkInstitution1%64B14D7F0072.private preserve=yes
      //## end configuration::NetworkInstitution1%64B14D7F0072.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: NET_INST_ID_CODE%64B14E2A024E
      //## begin configuration::NetworkInstitution1::NET_INST_ID_CODE%64B14E2A024E.attr preserve=no  private: string {V} 
      string m_strNET_INST_ID_CODE;
      //## end configuration::NetworkInstitution1::NET_INST_ID_CODE%64B14E2A024E.attr

      //## Attribute: PAN_PREFIX%64B14E2E03D3
      //## begin configuration::NetworkInstitution1::PAN_PREFIX%64B14E2E03D3.attr preserve=no  private: string {V} 
      string m_strPAN_PREFIX;
      //## end configuration::NetworkInstitution1::PAN_PREFIX%64B14E2E03D3.attr

      //## Attribute: NET_ID%64B14E32016A
      //## begin configuration::NetworkInstitution1::NET_ID%64B14E32016A.attr preserve=no  private: string {V} 
      string m_strNET_ID;
      //## end configuration::NetworkInstitution1::NET_ID%64B14E32016A.attr

    // Additional Implementation Declarations
      //## begin configuration::NetworkInstitution1%64B14D7F0072.implementation preserve=yes
      //## end configuration::NetworkInstitution1%64B14D7F0072.implementation

};

//## begin configuration::NetworkInstitution1%64B14D7F0072.postscript preserve=yes
//## end configuration::NetworkInstitution1%64B14D7F0072.postscript

} // namespace configuration

//## begin module%64B14DAB0380.epilog preserve=yes
//## end module%64B14DAB0380.epilog


#endif
