//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4255588E00EA.cm preserve=no
//	$Date:   Dec 12 2016 13:41:56  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%4255588E00EA.cm

//## begin module%4255588E00EA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4255588E00EA.cp

//## Module: CXOSCF72%4255588E00EA; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF72.hpp

#ifndef CXOSCF72_h
#define CXOSCF72_h 1

//## begin module%4255588E00EA.additionalIncludes preserve=no
//## end module%4255588E00EA.additionalIncludes

//## begin module%4255588E00EA.includes preserve=yes
//## end module%4255588E00EA.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%4255588E00EA.declarations preserve=no
//## end module%4255588E00EA.declarations

//## begin module%4255588E00EA.additionalDeclarations preserve=yes
//## end module%4255588E00EA.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::CountryCode%42554DAF0157.preface preserve=yes
//## end configuration::CountryCode%42554DAF0157.preface

//## Class: CountryCode%42554DAF0157
//	This Class translates 3 digits Country Code to 2
//	characters Country Code
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%42566CE800FA;reusable::Query { -> F}
//## Uses: <unnamed>%584EFCBB0399;IF::Extract { -> F}

class DllExport CountryCode : public ConversionItem  //## Inherits: <unnamed>%42554FC00261
{
  //## begin configuration::CountryCode%42554DAF0157.initialDeclarations preserve=yes
  //## end configuration::CountryCode%42554DAF0157.initialDeclarations

  public:
    //## Constructors (generated)
      CountryCode();

    //## Destructor (generated)
      virtual ~CountryCode();


    //## Other Operations (specified)
      //## Operation: bind%425559E803C8
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::CountryCode%42554DAF0157.public preserve=yes
      //## end configuration::CountryCode%42554DAF0157.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::CountryCode%42554DAF0157.protected preserve=yes
      //## end configuration::CountryCode%42554DAF0157.protected

  private:
    // Additional Private Declarations
      //## begin configuration::CountryCode%42554DAF0157.private preserve=yes
      //## end configuration::CountryCode%42554DAF0157.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::CountryCode%42554DAF0157.implementation preserve=yes
      //## end configuration::CountryCode%42554DAF0157.implementation

};

//## begin configuration::CountryCode%42554DAF0157.postscript preserve=yes
//## end configuration::CountryCode%42554DAF0157.postscript

} // namespace configuration

//## begin module%4255588E00EA.epilog preserve=yes
//## end module%4255588E00EA.epilog


#endif
