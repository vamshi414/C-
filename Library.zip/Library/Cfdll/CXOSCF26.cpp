//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%393E6AC303DB.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%393E6AC303DB.cm

//## begin module%393E6AC303DB.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%393E6AC303DB.cp

//## Module: CXOSCF26%393E6AC303DB; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF26.cpp

//## begin module%393E6AC303DB.additionalIncludes preserve=no
//## end module%393E6AC303DB.additionalIncludes

//## begin module%393E6AC303DB.includes preserve=yes
// $Date:   Apr 08 2004 14:11:16  $ $Author:   D02405  $ $Revision:   1.4  $
//## end module%393E6AC303DB.includes

#ifndef CXOSCF26_h
#include "CXODCF26.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%393E6AC303DB.declarations preserve=no
//## end module%393E6AC303DB.declarations

//## begin module%393E6AC303DB.additionalDeclarations preserve=yes
//## end module%393E6AC303DB.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::VerificationItem





VerificationItem::VerificationItem()
  //## begin VerificationItem::VerificationItem%393E6D47025B_const.hasinit preserve=no
  //## end VerificationItem::VerificationItem%393E6D47025B_const.hasinit
  //## begin VerificationItem::VerificationItem%393E6D47025B_const.initialization preserve=yes
  //## end VerificationItem::VerificationItem%393E6D47025B_const.initialization
{
  //## begin configuration::VerificationItem::VerificationItem%393E6D47025B_const.body preserve=yes
   memcpy(m_sID,"CF26",4);
  //## end configuration::VerificationItem::VerificationItem%393E6D47025B_const.body
}

VerificationItem::VerificationItem (const char* pszMember)
  //## begin configuration::VerificationItem::VerificationItem%393E721901A1.hasinit preserve=no
  //## end configuration::VerificationItem::VerificationItem%393E721901A1.hasinit
  //## begin configuration::VerificationItem::VerificationItem%393E721901A1.initialization preserve=yes
   : m_strMember(pszMember)
  //## end configuration::VerificationItem::VerificationItem%393E721901A1.initialization
{
  //## begin configuration::VerificationItem::VerificationItem%393E721901A1.body preserve=yes
   memcpy(m_sID,"CF26",4);
  //## end configuration::VerificationItem::VerificationItem%393E721901A1.body
}


VerificationItem::~VerificationItem()
{
  //## begin configuration::VerificationItem::~VerificationItem%393E6D47025B_dest.body preserve=yes
  //## end configuration::VerificationItem::~VerificationItem%393E6D47025B_dest.body
}



//## Other Operations (implementation)
void VerificationItem::bind (Query& hQuery)
{
  //## begin configuration::VerificationItem::bind%393E721901D3.body preserve=yes
  //## end configuration::VerificationItem::bind%393E721901D3.body
}

const string& VerificationItem::getKey ()
{
  //## begin configuration::VerificationItem::getKey%393E721901FB.body preserve=yes
   return m_strKey;
  //## end configuration::VerificationItem::getKey%393E721901FB.body
}

// Additional Declarations
  //## begin configuration::VerificationItem%393E6D47025B.declarations preserve=yes
  //## end configuration::VerificationItem%393E6D47025B.declarations

} // namespace configuration

//## begin module%393E6AC303DB.epilog preserve=yes
//## end module%393E6AC303DB.epilog
