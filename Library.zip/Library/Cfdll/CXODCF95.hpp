//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%482989650280.cm preserve=no
//	$Date:   May 22 2008 14:34:04  $ $Author:   D09372  $
//	$Revision:   1.0  $
//## end module%482989650280.cm

//## begin module%482989650280.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%482989650280.cp

//## Module: CXOSCF95%482989650280; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF95.hpp

#ifndef CXOSCF95_h
#define CXOSCF95_h 1

//## begin module%482989650280.additionalIncludes preserve=no
//## end module%482989650280.additionalIncludes

//## begin module%482989650280.includes preserve=yes
//## end module%482989650280.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%482989650280.declarations preserve=no
//## end module%482989650280.declarations

//## begin module%482989650280.additionalDeclarations preserve=yes
//## end module%482989650280.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::PulseProcessCode%482988A8029F.preface preserve=yes
//## end configuration::PulseProcessCode%482988A8029F.preface

//## Class: PulseProcessCode%482988A8029F
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%482988F3004E;IF::Extract { -> F}
//## Uses: <unnamed>%482988FF035B;reusable::Query { -> F}

class DllExport PulseProcessCode : public ConversionItem  //## Inherits: <unnamed>%482988D001C5
{
  //## begin configuration::PulseProcessCode%482988A8029F.initialDeclarations preserve=yes
  //## end configuration::PulseProcessCode%482988A8029F.initialDeclarations

  public:
    //## Constructors (generated)
      PulseProcessCode();

    //## Destructor (generated)
      virtual ~PulseProcessCode();


    //## Other Operations (specified)
      //## Operation: bind%482989240290
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>MS
      //	<h3>Star Process Codes
      //	<p>
      //	The Star Process Codes table is used to determine a
      //	value for the transaction type identifier (FIN_
      //	L<i>yyyymm</i>.TRAN_TYPE_ID) in the financial
      //	transaction.
      //	<p>
      //	Use the CR Client to add or update rows whenever the EFD
      //	Advantage acquiring platform introduces a new value in:
      //	<ul>
      //	<li>PROC^CODE (1)
      //	</ul>
      //	Star Process Codes are in the Parameter Tables folder in
      //	the CR Client for the DataNavigator Server.
      //	</body>
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getSecond%4829892C005D
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::PulseProcessCode%482988A8029F.public preserve=yes
      //## end configuration::PulseProcessCode%482988A8029F.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::PulseProcessCode%482988A8029F.protected preserve=yes
      //## end configuration::PulseProcessCode%482988A8029F.protected

  private:
    // Additional Private Declarations
      //## begin configuration::PulseProcessCode%482988A8029F.private preserve=yes
      //## end configuration::PulseProcessCode%482988A8029F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: MEDIA_TYPE%4829891001B5
      //## begin configuration::PulseProcessCode::MEDIA_TYPE%4829891001B5.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::PulseProcessCode::MEDIA_TYPE%4829891001B5.attr

      //## Attribute: MSG_CLASS%482989140232
      //## begin configuration::PulseProcessCode::MSG_CLASS%482989140232.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::PulseProcessCode::MSG_CLASS%482989140232.attr

      //## Attribute: PRE_AUTH%4829891800CB
      //## begin configuration::PulseProcessCode::PRE_AUTH%4829891800CB.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::PulseProcessCode::PRE_AUTH%4829891800CB.attr

      //## Attribute: PROCESS_CODE%4829891C0251
      //## begin configuration::PulseProcessCode::PROCESS_CODE%4829891C0251.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::PulseProcessCode::PROCESS_CODE%4829891C0251.attr

    // Additional Implementation Declarations
      //## begin configuration::PulseProcessCode%482988A8029F.implementation preserve=yes
      //## end configuration::PulseProcessCode%482988A8029F.implementation

};

//## begin configuration::PulseProcessCode%482988A8029F.postscript preserve=yes
//## end configuration::PulseProcessCode%482988A8029F.postscript

} // namespace configuration

//## begin module%482989650280.epilog preserve=yes
//## end module%482989650280.epilog


#endif
