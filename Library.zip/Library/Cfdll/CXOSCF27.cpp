//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%393E6ACB0093.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%393E6ACB0093.cm

//## begin module%393E6ACB0093.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%393E6ACB0093.cp

//## Module: CXOSCF27%393E6ACB0093; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF27.cpp

//## begin module%393E6ACB0093.additionalIncludes preserve=no
//## end module%393E6ACB0093.additionalIncludes

//## begin module%393E6ACB0093.includes preserve=yes
// $Date:   Apr 08 2004 14:11:16  $ $Author:   D02405  $ $Revision:   1.8  $
//## end module%393E6ACB0093.includes

#ifndef CXOSCF27_h
#include "CXODCF27.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%393E6ACB0093.declarations preserve=no
//## end module%393E6ACB0093.declarations

//## begin module%393E6ACB0093.additionalDeclarations preserve=yes
//## end module%393E6ACB0093.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::TransactionTypeIdentifier 





TransactionTypeIdentifier::TransactionTypeIdentifier()
  //## begin TransactionTypeIdentifier::TransactionTypeIdentifier%393E6D4A033B_const.hasinit preserve=no
  //## end TransactionTypeIdentifier::TransactionTypeIdentifier%393E6D4A033B_const.hasinit
  //## begin TransactionTypeIdentifier::TransactionTypeIdentifier%393E6D4A033B_const.initialization preserve=yes
   : VerificationItem("## CR28 VERIFY TRAN TYPE")
  //## end TransactionTypeIdentifier::TransactionTypeIdentifier%393E6D4A033B_const.initialization
{
  //## begin configuration::TransactionTypeIdentifier::TransactionTypeIdentifier%393E6D4A033B_const.body preserve=yes
   memcpy(m_sID,"CF27",4);
  //## end configuration::TransactionTypeIdentifier::TransactionTypeIdentifier%393E6D4A033B_const.body
}


TransactionTypeIdentifier::~TransactionTypeIdentifier()
{
  //## begin configuration::TransactionTypeIdentifier::~TransactionTypeIdentifier%393E6D4A033B_dest.body preserve=yes
  //## end configuration::TransactionTypeIdentifier::~TransactionTypeIdentifier%393E6D4A033B_dest.body
}



//## Other Operations (implementation)
void TransactionTypeIdentifier::bind (Query& hQuery)
{
  //## begin configuration::TransactionTypeIdentifier::bind%393E74D9012B.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID); 
   hQuery.setQualifier("QUALIFY","TRAN_TYPE_IND");
   hQuery.bind("TRAN_TYPE_IND","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("TRAN_TYPE_IND","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("TRAN_TYPE_IND","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("TRAN_TYPE_IND","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("TRAN_TYPE_IND","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("TRAN_TYPE_IND","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("TRAN_TYPE_IND","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("TRAN_TYPE_IND","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("TRAN_TYPE_IND.CUST_ID DESC");
  //## end configuration::TransactionTypeIdentifier::bind%393E74D9012B.body
}

const string& TransactionTypeIdentifier::getKey ()
{
  //## begin configuration::TransactionTypeIdentifier::getKey%393E74D90153.body preserve=yes
   while (m_strPROCESS_CODE.length() < 6)
      m_strPROCESS_CODE += ' '; 
   while (m_strMSG_CLASS.length() < 1)
      m_strMSG_CLASS += ' '; 
   while (m_strPRE_AUTH.length() < 1)
      m_strPRE_AUTH += ' '; 
   m_strKey = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strKey;
  //## end configuration::TransactionTypeIdentifier::getKey%393E74D90153.body
}

// Additional Declarations
  //## begin configuration::TransactionTypeIdentifier%393E6D4A033B.declarations preserve=yes
  //## end configuration::TransactionTypeIdentifier%393E6D4A033B.declarations

} // namespace configuration

//## begin module%393E6ACB0093.epilog preserve=yes
//## end module%393E6ACB0093.epilog
