//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%664032AE02C2.cm preserve=no
//## end module%664032AE02C2.cm

//## begin module%664032AE02C2.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%664032AE02C2.cp

//## Module: CXOSCFD7%664032AE02C2; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXODCFD7.hpp

#ifndef CXOSCFD7_h
#define CXOSCFD7_h 1

//## begin module%664032AE02C2.additionalIncludes preserve=no
//## end module%664032AE02C2.additionalIncludes

//## begin module%664032AE02C2.includes preserve=yes
//## end module%664032AE02C2.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%664032AE02C2.declarations preserve=no
//## end module%664032AE02C2.declarations

//## begin module%664032AE02C2.additionalDeclarations preserve=yes
//## end module%664032AE02C2.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ShazamProcessCode%664032080313.preface preserve=yes
//## end configuration::ShazamProcessCode%664032080313.preface

//## Class: ShazamProcessCode%664032080313
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6640338C03A0;IF::Extract { -> F}
//## Uses: <unnamed>%664033A40126;reusable::Query { -> F}

class DllExport ShazamProcessCode : public ConversionItem  //## Inherits: <unnamed>%664033D1028E
{
  //## begin configuration::ShazamProcessCode%664032080313.initialDeclarations preserve=yes
  //## end configuration::ShazamProcessCode%664032080313.initialDeclarations

  public:
    //## Constructors (generated)
      ShazamProcessCode();

    //## Destructor (generated)
      virtual ~ShazamProcessCode();


    //## Other Operations (specified)
      //## Operation: bind%6640323400A9
      virtual void bind (Query& hQuery);

      //## Operation: getSecond%664032380025
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::ShazamProcessCode%664032080313.public preserve=yes
      //## end configuration::ShazamProcessCode%664032080313.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ShazamProcessCode%664032080313.protected preserve=yes
      //## end configuration::ShazamProcessCode%664032080313.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ShazamProcessCode%664032080313.private preserve=yes
      //## end configuration::ShazamProcessCode%664032080313.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: PROCESS_CODE%6640323F0303
      //## begin configuration::ShazamProcessCode::PROCESS_CODE%6640323F0303.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::ShazamProcessCode::PROCESS_CODE%6640323F0303.attr

      //## Attribute: MSG_CLASS%664032430233
      //## begin configuration::ShazamProcessCode::MSG_CLASS%664032430233.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::ShazamProcessCode::MSG_CLASS%664032430233.attr

      //## Attribute: PRE_AUTH%66403246037D
      //## begin configuration::ShazamProcessCode::PRE_AUTH%66403246037D.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::ShazamProcessCode::PRE_AUTH%66403246037D.attr

      //## Attribute: MEDIA_TYPE%6640324B0152
      //## begin configuration::ShazamProcessCode::MEDIA_TYPE%6640324B0152.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::ShazamProcessCode::MEDIA_TYPE%6640324B0152.attr

    // Additional Implementation Declarations
      //## begin configuration::ShazamProcessCode%664032080313.implementation preserve=yes
      //## end configuration::ShazamProcessCode%664032080313.implementation

};

//## begin configuration::ShazamProcessCode%664032080313.postscript preserve=yes
//## end configuration::ShazamProcessCode%664032080313.postscript

} // namespace configuration

//## begin module%664032AE02C2.epilog preserve=yes
//## end module%664032AE02C2.epilog


#endif
