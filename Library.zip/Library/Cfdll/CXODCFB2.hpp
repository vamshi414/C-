//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5CF7CA0C0058.cm preserve=no
//	$Date:   Jun 06 2019 14:02:44  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5CF7CA0C0058.cm

//## begin module%5CF7CA0C0058.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5CF7CA0C0058.cp

//## Module: CXOSCFB2%5CF7CA0C0058; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV03.0A.R002\Windows\Build\Dn\Server\Library\Cfdll\CXODCFB2.hpp

#ifndef CXOSCFB2_h
#define CXOSCFB2_h 1

//## begin module%5CF7CA0C0058.additionalIncludes preserve=no
//## end module%5CF7CA0C0058.additionalIncludes

//## begin module%5CF7CA0C0058.includes preserve=yes
//## end module%5CF7CA0C0058.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%5CF7CA0C0058.declarations preserve=no
//## end module%5CF7CA0C0058.declarations

//## begin module%5CF7CA0C0058.additionalDeclarations preserve=yes
//## end module%5CF7CA0C0058.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::CurrencyCodeReverse%5CF7C71E030A.preface preserve=yes
//## end configuration::CurrencyCodeReverse%5CF7C71E030A.preface

//## Class: CurrencyCodeReverse%5CF7C71E030A
//	This class translates the 3 character currency code to
//	the numeric currency code.
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5CF7C8BD0305;reusable::Query { -> F}
//## Uses: <unnamed>%5CF835050302;entitysegment::Customer { -> F}

class DllExport CurrencyCodeReverse : public ConversionItem  //## Inherits: <unnamed>%5CF7C8A4002C
{
  //## begin configuration::CurrencyCodeReverse%5CF7C71E030A.initialDeclarations preserve=yes
  //## end configuration::CurrencyCodeReverse%5CF7C71E030A.initialDeclarations

  public:
    //## Constructors (generated)
      CurrencyCodeReverse();

    //## Destructor (generated)
      virtual ~CurrencyCodeReverse();


    //## Other Operations (specified)
      //## Operation: bind%5CF7CAA903C0
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::CurrencyCodeReverse%5CF7C71E030A.public preserve=yes
      //## end configuration::CurrencyCodeReverse%5CF7C71E030A.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::CurrencyCodeReverse%5CF7C71E030A.protected preserve=yes
      //## end configuration::CurrencyCodeReverse%5CF7C71E030A.protected

  private:
    // Additional Private Declarations
      //## begin configuration::CurrencyCodeReverse%5CF7C71E030A.private preserve=yes
      //## end configuration::CurrencyCodeReverse%5CF7C71E030A.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::CurrencyCodeReverse%5CF7C71E030A.implementation preserve=yes
      //## end configuration::CurrencyCodeReverse%5CF7C71E030A.implementation

};

//## begin configuration::CurrencyCodeReverse%5CF7C71E030A.postscript preserve=yes
//## end configuration::CurrencyCodeReverse%5CF7C71E030A.postscript

} // namespace configuration

//## begin module%5CF7CA0C0058.epilog preserve=yes
//## end module%5CF7CA0C0058.epilog


#endif
