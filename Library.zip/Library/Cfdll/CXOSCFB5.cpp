//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EF27A7C0065.cm preserve=no
//	$Date:   Jul 24 2020 16:37:24  $ $Author:   e1089842  $
//	$Revision:   1.0  $
//## end module%5EF27A7C0065.cm

//## begin module%5EF27A7C0065.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5EF27A7C0065.cp

//## Module: CXOSCFB5%5EF27A7C0065; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Dn_codes\V03.1A.R007\Dn\Server\Library\Cfdll\CXOSCFB5.cpp

//## begin module%5EF27A7C0065.additionalIncludes preserve=no
//## end module%5EF27A7C0065.additionalIncludes

//## begin module%5EF27A7C0065.includes preserve=yes
//## end module%5EF27A7C0065.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFB5_h
#include "CXODCFB5.hpp"
#endif


//## begin module%5EF27A7C0065.declarations preserve=no
//## end module%5EF27A7C0065.declarations

//## begin module%5EF27A7C0065.additionalDeclarations preserve=yes
//## end module%5EF27A7C0065.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::CountryCodeNumToRegion 

CountryCodeNumToRegion::CountryCodeNumToRegion()
  //## begin CountryCodeNumToRegion::CountryCodeNumToRegion%5EF2792F011A_const.hasinit preserve=no
  //## end CountryCodeNumToRegion::CountryCodeNumToRegion%5EF2792F011A_const.hasinit
  //## begin CountryCodeNumToRegion::CountryCodeNumToRegion%5EF2792F011A_const.initialization preserve=yes
  : ConversionItem("## CFB5 XLATE COUNTRY CODE")
  //## end CountryCodeNumToRegion::CountryCodeNumToRegion%5EF2792F011A_const.initialization
{
  //## begin configuration::CountryCodeNumToRegion::CountryCodeNumToRegion%5EF2792F011A_const.body preserve=yes
   memcpy(m_sID,"CFB5",4);
  //## end configuration::CountryCodeNumToRegion::CountryCodeNumToRegion%5EF2792F011A_const.body
}


CountryCodeNumToRegion::~CountryCodeNumToRegion()
{
  //## begin configuration::CountryCodeNumToRegion::~CountryCodeNumToRegion%5EF2792F011A_dest.body preserve=yes
  //## end configuration::CountryCodeNumToRegion::~CountryCodeNumToRegion%5EF2792F011A_dest.body
}



//## Other Operations (implementation)
void CountryCodeNumToRegion::bind (Query& hQuery)
{
  //## begin configuration::CountryCodeNumToRegion::bind%5EF282580086.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY","COUNTRY_CODE");
   hQuery.bind("COUNTRY_CODE","COUNTRY_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("COUNTRY_CODE","VISA_REGION",Column::STRING,&m_strSecond);
   hQuery.bind("COUNTRY_CODE","MC_REGION",Column::STRING,&m_strThird);
   hQuery.setBasicPredicate("COUNTRY_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("COUNTRY_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("COUNTRY_CODE", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("COUNTRY_CODE.COUNTRY_CODE ASC");
  //## end configuration::CountryCodeNumToRegion::bind%5EF282580086.body
}

// Additional Declarations
  //## begin configuration::CountryCodeNumToRegion%5EF2792F011A.declarations preserve=yes
  //## end configuration::CountryCodeNumToRegion%5EF2792F011A.declarations

} // namespace configuration

//## begin module%5EF27A7C0065.epilog preserve=yes
//## end module%5EF27A7C0065.epilog
