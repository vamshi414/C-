//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A2F883602FB.cm preserve=no
//	$Date:   Feb 05 2021 07:42:20  $ $Author:   e3028298  $
//	$Revision:   1.1  $
//## end module%5A2F883602FB.cm

//## begin module%5A2F883602FB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A2F883602FB.cp

//## Module: CXOSCFA9%5A2F883602FB; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Devel\V03.1A.R007\Dn\Server\Library\Cfdll\CXODCFA9.hpp

#ifndef CXOSCFA9_h
#define CXOSCFA9_h 1

//## begin module%5A2F883602FB.additionalIncludes preserve=no
//## end module%5A2F883602FB.additionalIncludes

//## begin module%5A2F883602FB.includes preserve=yes
//## end module%5A2F883602FB.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%5A2F883602FB.declarations preserve=no
//## end module%5A2F883602FB.declarations

//## begin module%5A2F883602FB.additionalDeclarations preserve=yes
//## end module%5A2F883602FB.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::BusinessCode%5A2F8C52035C.preface preserve=yes
//## end configuration::BusinessCode%5A2F8C52035C.preface

//## Class: BusinessCode%5A2F8C52035C
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5A2F8D42029B;IF::Extract { -> F}
//## Uses: <unnamed>%5A2F8D670201;reusable::Query { -> F}

class DllExport BusinessCode : public ConversionItem  //## Inherits: <unnamed>%5F6A3C52034A
{
  //## begin configuration::BusinessCode%5A2F8C52035C.initialDeclarations preserve=yes
  //## end configuration::BusinessCode%5A2F8C52035C.initialDeclarations

  public:
    //## Constructors (generated)
      BusinessCode();

    //## Destructor (generated)
      virtual ~BusinessCode();


    //## Other Operations (specified)
      //## Operation: bind%5A2F8C8D007A
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getSecond%6017748D01A6
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::BusinessCode%5A2F8C52035C.public preserve=yes
      //## end configuration::BusinessCode%5A2F8C52035C.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::BusinessCode%5A2F8C52035C.protected preserve=yes
      //## end configuration::BusinessCode%5A2F8C52035C.protected

  private:
    // Additional Private Declarations
      //## begin configuration::BusinessCode%5A2F8C52035C.private preserve=yes
      //## end configuration::BusinessCode%5A2F8C52035C.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::BusinessCode%5A2F8C52035C.implementation preserve=yes
      //## end configuration::BusinessCode%5A2F8C52035C.implementation

};

//## begin configuration::BusinessCode%5A2F8C52035C.postscript preserve=yes
//## end configuration::BusinessCode%5A2F8C52035C.postscript

} // namespace configuration

//## begin module%5A2F883602FB.epilog preserve=yes
//## end module%5A2F883602FB.epilog


#endif
