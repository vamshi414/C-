//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39105050014B.cm preserve=no
//## end module%39105050014B.cm

//## begin module%39105050014B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%39105050014B.cp

//## Module: CXOSCF02%39105050014B; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF02.cpp

//## begin module%39105050014B.additionalIncludes preserve=no
//## end module%39105050014B.additionalIncludes

//## begin module%39105050014B.includes preserve=yes
#include "CXODCFC1.hpp"
#include "CXODCFD7.hpp"
#include "CXODCFD8.hpp"
//## end module%39105050014B.includes

#ifndef CXOSRU23_h
#include "CXODRU23.hpp"
#endif
#ifndef CXOSCF06_h
#include "CXODCF06.hpp"
#endif
#ifndef CXOSCF07_h
#include "CXODCF07.hpp"
#endif
#ifndef CXOSCF08_h
#include "CXODCF08.hpp"
#endif
#ifndef CXOSCF09_h
#include "CXODCF09.hpp"
#endif
#ifndef CXOSCF10_h
#include "CXODCF10.hpp"
#endif
#ifndef CXOSCF11_h
#include "CXODCF11.hpp"
#endif
#ifndef CXOSCF12_h
#include "CXODCF12.hpp"
#endif
#ifndef CXOSCF13_h
#include "CXODCF13.hpp"
#endif
#ifndef CXOSCF14_h
#include "CXODCF14.hpp"
#endif
#ifndef CXOSCF15_h
#include "CXODCF15.hpp"
#endif
#ifndef CXOSCF16_h
#include "CXODCF16.hpp"
#endif
#ifndef CXOSCF17_h
#include "CXODCF17.hpp"
#endif
#ifndef CXOSCF18_h
#include "CXODCF18.hpp"
#endif
#ifndef CXOSCF19_h
#include "CXODCF19.hpp"
#endif
#ifndef CXOSCF20_h
#include "CXODCF20.hpp"
#endif
#ifndef CXOSCF21_h
#include "CXODCF21.hpp"
#endif
#ifndef CXOSCF22_h
#include "CXODCF22.hpp"
#endif
#ifndef CXOSCF23_h
#include "CXODCF23.hpp"
#endif
#ifndef CXOSCF27_h
#include "CXODCF27.hpp"
#endif
#ifndef CXOSCF28_h
#include "CXODCF28.hpp"
#endif
#ifndef CXOSCF30_h
#include "CXODCF30.hpp"
#endif
#ifndef CXOSCF29_h
#include "CXODCF29.hpp"
#endif
#ifndef CXOSCF36_h
#include "CXODCF36.hpp"
#endif
#ifndef CXOSCF33_h
#include "CXODCF33.hpp"
#endif
#ifndef CXOSCF37_h
#include "CXODCF37.hpp"
#endif
#ifndef CXOSCF34_h
#include "CXODCF34.hpp"
#endif
#ifndef CXOSCF35_h
#include "CXODCF35.hpp"
#endif
#ifndef CXOSCF38_h
#include "CXODCF38.hpp"
#endif
#ifndef CXOSCF43_h
#include "CXODCF43.hpp"
#endif
#ifndef CXOSCF42_h
#include "CXODCF42.hpp"
#endif
#ifndef CXOSCF46_h
#include "CXODCF46.hpp"
#endif
#ifndef CXOSCF57_h
#include "CXODCF57.hpp"
#endif
#ifndef CXOSCF61_h
#include "CXODCF61.hpp"
#endif
#ifndef CXOSCF62_h
#include "CXODCF62.hpp"
#endif
#ifndef CXOSCF66_h
#include "CXODCF66.hpp"
#endif
#ifndef CXOSCF68_h
#include "CXODCF68.hpp"
#endif
#ifndef CXOSCF69_h
#include "CXODCF69.hpp"
#endif
#ifndef CXOSCF71_h
#include "CXODCF71.hpp"
#endif
#ifndef CXOSCF72_h
#include "CXODCF72.hpp"
#endif
#ifndef CXOSCF73_h
#include "CXODCF73.hpp"
#endif
#ifndef CXOSCF02_h
#include "CXODCF02.hpp"
#endif
#ifndef CXOSCF76_h
#include "CXODCF76.hpp"
#endif
#ifndef CXOSCF79_h
#include "CXODCF79.hpp"
#endif
#ifndef CXOSCF75_h
#include "CXODCF75.hpp"
#endif
#ifndef CXOSCF78_h
#include "CXODCF78.hpp"
#endif
#ifndef CXOSCF77_h
#include "CXODCF77.hpp"
#endif
#ifndef CXOSCF80_h
#include "CXODCF80.hpp"
#endif
#ifndef CXOSCF83_h
#include "CXODCF83.hpp"
#endif
#ifndef CXOSCF82_h
#include "CXODCF82.hpp"
#endif
#ifndef CXOSCF84_h
#include "CXODCF84.hpp"
#endif
#ifndef CXOSCF85_h
#include "CXODCF85.hpp"
#endif
#ifndef CXOSCF86_h
#include "CXODCF86.hpp"
#endif
#ifndef CXOSCF87_h
#include "CXODCF87.hpp"
#endif
#ifndef CXOSCF88_h
#include "CXODCF88.hpp"
#endif
#ifndef CXOSCF89_h
#include "CXODCF89.hpp"
#endif
#ifndef CXOSCF90_h
#include "CXODCF90.hpp"
#endif
#ifndef CXOSCF91_h
#include "CXODCF91.hpp"
#endif
#ifndef CXOSCF92_h
#include "CXODCF92.hpp"
#endif
#ifndef CXOSCF93_h
#include "CXODCF93.hpp"
#endif
#ifndef CXOSCF94_h
#include "CXODCF94.hpp"
#endif
#ifndef CXOSCF95_h
#include "CXODCF95.hpp"
#endif
#ifndef CXOSCF96_h
#include "CXODCF96.hpp"
#endif
#ifndef CXOSCF97_h
#include "CXODCF97.hpp"
#endif
#ifndef CXOSCF98_h
#include "CXODCF98.hpp"
#endif
#ifndef CXOSCF31_h
#include "CXODCF31.hpp"
#endif
#ifndef CXOSCF99_h
#include "CXODCF99.hpp"
#endif
#ifndef CXOSCF70_h
#include "CXODCF70.hpp"
#endif
#ifndef CXOSCF63_h
#include "CXODCF63.hpp"
#endif
#ifndef CXOSCFA0_h
#include "CXODCFA0.hpp"
#endif
#ifndef CXOSCFA1_h
#include "CXODCFA1.hpp"
#endif
#ifndef CXOSCFA3_h
#include "CXODCFA3.hpp"
#endif
#ifndef CXOSCFA4_h
#include "CXODCFA4.hpp"
#endif
#ifndef CXOSCFA5_h
#include "CXODCFA5.hpp"
#endif
#ifndef CXOSCFA6_h
#include "CXODCFA6.hpp"
#endif
#ifndef CXOSCFA7_h
#include "CXODCFA7.hpp"
#endif
#ifndef CXOSCFB0_h
#include "CXODCFB0.hpp"
#endif
#ifndef CXOSCFB1_h
#include "CXODCFB1.hpp"
#endif
#ifndef CXOSCFB2_h
#include "CXODCFB2.hpp"
#endif
#ifndef CXOSCFB3_h
#include "CXODCFB3.hpp"
#endif
#ifndef CXOSCFB6_h
#include "CXODCFB6.hpp"
#endif
#ifndef CXOSCFB7_h
#include "CXODCFB7.hpp"
#endif
#ifndef CXOSCFB8_h
#include "CXODCFB8.hpp"
#endif
#ifndef CXOSCFC3_h
#include "CXODCFC3.hpp"
#endif
#ifndef CXOSCFB5_h
#include "CXODCFB5.hpp"
#endif
#ifndef CXOSCFA9_h
#include "CXODCFA9.hpp"
#endif
#ifndef CXOSCFB9_h
#include "CXODCFB9.hpp"
#endif
#ifndef CXOSCFC0_h
#include "CXODCFC0.hpp"
#endif
#ifndef CXOSCFC2_h
#include "CXODCFC2.hpp"
#endif
#ifndef CXOSCFC4_h
#include "CXODCFC4.hpp"
#endif
#ifndef CXOSCFC5_h
#include "CXODCFC5.hpp"
#endif
#ifndef CXOSCFC6_h
#include "CXODCFC6.hpp"
#endif
#ifndef CXOSCFC7_h
#include "CXODCFC7.hpp"
#endif
#ifndef CXOSCFC8_h
#include "CXODCFC8.hpp"
#endif
#ifndef CXOSCFC9_h
#include "CXODCFC9.hpp"
#endif
#ifndef CXOSCFD0_h
#include "CXODCFD0.hpp"
#endif
#ifndef CXOSCFD1_h
#include "CXODCFD1.hpp"
#endif
#ifndef CXOSCFD3_h
#include "CXODCFD3.hpp"
#endif
#ifndef CXOSCFD5_h
#include "CXODCFD5.hpp"
#endif
#ifndef CXOSCFD4_h
#include "CXODCFD4.hpp"
#endif
#ifndef CXOSCFD6_h
#include "CXODCFD6.hpp"
#endif
#ifndef CXOSCF45_h
#include "CXODCF45.hpp"
#endif
#ifndef CXOSCF47_h
#include "CXODCF47.hpp"
#endif
#ifndef CXOSCF48_h
#include "CXODCF48.hpp"
#endif
#ifndef CXOSCF49_h
#include "CXODCF49.hpp"
#endif
#ifndef CXOSCF50_h
#include "CXODCF50.hpp"
#endif
#ifndef CXOSCF51_h
#include "CXODCF51.hpp"
#endif
#ifndef CXOSCF52_h
#include "CXODCF52.hpp"
#endif
#ifndef CXOSCF53_h
#include "CXODCF53.hpp"
#endif
#ifndef CXOSCF54_h
#include "CXODCF54.hpp"
#endif
#ifndef CXOSCF55_h
#include "CXODCF55.hpp"
#endif
#ifndef CXOSCF56_h
#include "CXODCF56.hpp"
#endif
#ifndef CXOSCF58_h
#include "CXODCF58.hpp"
#endif
#ifndef CXOSCF60_h
#include "CXODCF60.hpp"
#endif
#ifndef CXOSCF59_h
#include "CXODCF59.hpp"
#endif


//## begin module%39105050014B.declarations preserve=no
//## end module%39105050014B.declarations

//## begin module%39105050014B.additionalDeclarations preserve=yes

const char* pszConversionClass[] =
{
   "X_ADV_CARD_LOGO",                  // 0
   "X_ADV_CARD_TYPE",                  // 1
   "X_ADV_MSG_CODE",                   // 2
   "X_ADV_PROC_CODE",                  // 3
   "X_VISA_PROC_CODE",                 // 4
   "X_CIRR_PROC_CODE",                 // 5
   "X_PLUS_PROC_CODE",                 // 6
   "X_VISA_ADJ_REASON",                // 7
   "X_CIRR_ADJ_REASON",                // 8
   "X_PLUS_CRCT_REASON",               // 9
   "DEVICE",                           // 10
   "INSTITUTION",                      // 11
   "PROCESSOR",                        // 12
   "X_IBM_REJECT_CODE",                // 13
   "X_IBM_MSG_TYPE_ID",                // 14
   "X_IBM_PROC_CODE",                  // 15
   "ONLINE_NETWORK",                   // 16
   "X_IBM_ADVIC_REASON",               // 17
   "X_B24_PROC_COD_ATM",               // 18
   "X_B24_PROC_COD_POS",               // 19
   "X_B24_RESP_COD_ATM",               // 20
   "X_B24_RESP_COD_POS",               // 21
   "X_B24_REV_CODE",                   // 22
   "X_DEV_LOW_CASH_FLG",               // 23
   "X_TO_TRAN_CLASS",                  // 24
   "X_GASPER_STATUS_CODE",             // 25
   "PROCESSOR_GRP",                    // 26
   "X_IBM_PIN_ENTR_MOD",               // 27
   "X_IBM_PAN_ENTR_MO1",               // 28
   "X_IBM_PAN_ENTR_MO2",               // 29
   "X_IBM_POS_COND_CO1",               // 30
   "X_IBM_POS_COND_CO2",               // 31
   "X_IBM_POS_COND_CO3",               // 32
   "X_IBM_POS_COND_CO4",               // 33
   "X_IBM_POS_COND_CO5",               // 34
   "X_IBM_POS_COND_CO6",               // 35
   "X_IBM_POS_COND_CO7",               // 36
   "X_IBM_POS_COND_CO8",               // 37
   "X_IBM_POS_TDT1",                   // 38
   "X_IBM_POS_TDT2",                   // 39
   "X_IBM_NET_ID",                     // 40
   "X_NET_INST_ID",                    // 41
   "X_IST_TID",                        // 42
   "X_NDC_ATM_STATUS",                 // 43
   "X_NET_MISC_DATA",                  // 44
   "X_NET_MISC_DATA_REV",              // 45
   "~X_ADV_PROC_CODE",                 // 46
   "COUNTRY_CODE",                     // 47
   "COUNTRY_CODE2to3",                 // 48
   "X_IST_RESP_REV_COD",               // 49
   "X_IST_CARD_TYPE",                  // 50
   "X_IST_REASON",                     // 51
   "X_IST_TERM_TYPE",                  // 52
   "X_IST_PROC_CODE",                  // 53
   "COUNTRY_CODENum",                  // 54
   "X_STAR_PROC_CODE",                 // 55
   "X_STAR_ACTION_TYPE",               // 56
   "~X_STAR_ACTION_TYPE",              // 57
   "~X_STAR_PROC_CODE",                // 58
   "TERM_CLASS",                       // 59
   "X_IST_NETWORK",                    // 60
   "X_MC_PROC_CODE",                   // 61
   "X_NACHA_RETURN_COD",               // 62
   "ACTION_CODE",                      // 63
   "~DEVICE",                          // 64
   "DEVICEAddress",                    // 65
   "X_GENERIC",                        // 66
   "COUNTRY_CODENumToISO",             // 67
   "X_PULSE_PROC_CODE",                // 68
   "~X_PULSE_PROC_CODE",               // 69
   "PROBLEM_TRAN",                     // 70
   "ERROR_MSG",                        // 71
   "INST_BANK_ID",                     // 72
   "X_PREPAID_NET_ID",                 // 73
   "X_VISA_RESP_CODE",                 // 74
   "X_MC_ADVICE_REASON",               // 75
   "X_MC_RESP_CODE",                   // 76
   "DEVICERevAll",                     // 77
   "PROCESSORName",                    // 78
   "~X_GENERIC",                       // 79
   "X_ACTION_TYPE",                    // 80
   "MASTERCARD_FEE",                   // 81
   "VISA_CHARGE",                      // 82
   "VISA_FEE",                         // 83
   "DISCOVER_AIP",                     // 84
   "MASTERCARD_IRD",                   // 85
   "BANK_ID_INST",                     // 86
   "X_WEB_ADJ_NETID",                  // 87
   "AMEX_FEE_CODE",                    // 88
   "CURRENCY_CODE",                    // 89
   "~CURRENCY_CODE",                   // 90
   "COUNTRY_CODEReg",                  // 91
   "MSG_REASON",                       // 92
   "X_NCR_PROC_CODE",                  // 93
   "QMR_BIN",                          // 94
   "QMR_ACQUIRER_BIN",                 // 95
   "BUSINESS_CODE",                    // 96
   "X_NETWORK_STATUS",                 // 97
   "~X_NETWORK_STATUS",                // 98
   "~AIMS_BILL_INST",                  // 99
   "AIMS_BILL_INST",                   // 100
   "PROCESSOR_CALENDAR",               // 101
   "INSTITUTION_CALENDAR",             // 102
   "X_CMS_PROC_CODE",                  // 103
   "X_NYCE_PROC_CODE",                 // 104
   "QMR_VISA_BID",                     // 105
   "X_SCHEME_FUNDING",                 // 106
   "~X_ACTION_TYPE",                   // 107
   "LOYALTY_BIN",                      // 108
   "ACH_CARD_TYPE",                    // 109
   "ACH_POS_DATA",                     // 110
   "ACI_RESPONSE",                     // 111
   "ADMIN_ISO_NETID",                  // 112
   "ADMIN_ISO_RTING",                  // 113
   "ARFMAC_TTID",                      // 114
   "BILL_NYCE_NET",                    // 115
   "CARD_OWNER",                       // 116
   "CARD_TYPE",                        // 117
   "DENOMINATION840",                  // 118
   "DISPUTE_GRP_CD",                   // 119
   "DOC_TYPE",                         // 120
   "DOC_TYPEOTH",                      // 121
   "EBT_BIN_STATEID",                  // 122
   "EBT_EXCPT_PROGR",                  // 123
   "EBT_TRANS_DTYPE",                  // 124
   "EBT_TRANS_EXCPT",                  // 125
   "EBT_TRANS_STDAY",                  // 126
   "ELAN_FROM_ACCT",                   // 127
   "ELAN_FUNC_CODE",                   // 128
   "ELAN_REV_CODE",                    // 129
   "ELAN_TO_ACCT",                     // 130
   "ELAN_TRAN_TYPE",                   // 131
   "IPM_POS_ENT_MOD",                  // 132
   "ISSUER_BIN_NET",                   // 133
   "LTY_TRAN_CODE",                    // 134
   "MAS_TID",                          // 135
   "MC_CB_FEE",                        // 136
   "MC_DCF_MTI",                       // 137
   "MIGS_PROC_CODE",                   // 138
   "MPGS_INST_ISS",                    // 139
   "NON_FIN_LIST",                     // 140
   "POSTILION_MTI",                    // 141
   "QMR_BIN_TYPE",                     // 142
   "QMR_MISS_ENTRY",                   // 143
   "QMR_PROC_CODES",                   // 144
   "QMR_PROD_CODE",                    // 145
   "QMR_TKN_REQ_ID",                   // 146
   "STR_PSEUDO_TERM",                  // 147
   "TRAN_DATA_FMT",                    // 148
   "TRAN_TYPE_FMT8",                   // 149
   "VENDOR_ITM",                       // 150
   "VISA_FPI",                         // 151
   "VISA_ISA_FEE",                     // 152
   "~ACH_CARD_TYPE",                   // 153
   "~ACH_POS_DATA",                    // 154
   "~ACI_RESPONSE",                    // 155
   "~ADMIN_ISO_NETID",                 // 156
   "~ADMIN_ISO_RTING",                 // 157
   "~ARFMAC_TTID",                     // 158
   "~BILL_NYCE_NET",                   // 159
   "~CARD_OWNER",                      // 160
   "~CARD_TYPE",                       // 161
   "~DENOMINATION840",                 // 162
   "~DISPUTE_GRP_CD",                  // 163
   "~DOC_TYPE",                        // 164
   "~DOC_TYPEOTH",                     // 165
   "~EBT_BIN_STATEID",                 // 166
   "~EBT_EXCPT_PROGR",                 // 167
   "~EBT_TRANS_DTYPE",                 // 168
   "~EBT_TRANS_EXCPT",                 // 169
   "~EBT_TRANS_STDAY",                 // 170
   "~ELAN_FROM_ACCT",                  // 171
   "~ELAN_FUNC_CODE",                  // 172
   "~ELAN_REV_CODE",                   // 173
   "~ELAN_TO_ACCT",                    // 174
   "~ELAN_TRAN_TYPE",                  // 175
   "~IPM_POS_ENT_MOD",                 // 176
   "~ISSUER_BIN_NET",                  // 177
   "~LTY_TRAN_CODE",                   // 178
   "~MAS_TID",                         // 179
   "~MC_CB_FEE",                       // 180
   "~MC_DCF_MTI",                      // 181
   "~MIGS_PROC_CODE",                  // 182
   "~MPGS_INST_ISS",                   // 183
   "~NON_FIN_LIST",                    // 184
   "~POSTILION_MTI",                   // 185
   "~QMR_BIN_TYPE",                    // 186
   "~QMR_MISS_ENTRY",                  // 187
   "~QMR_PROC_CODES",                  // 188
   "~QMR_PROD_CODE",                   // 189
   "~QMR_TKN_REQ_ID",                  // 190
   "~STR_PSEUDO_TERM",                 // 191
   "~TRAN_DATA_FMT",                   // 192
   "~TRAN_TYPE_FMT8",                  // 193
   "~VENDOR_ITM",                      // 194
   "~VISA_FPI",                        // 195
   "~VISA_ISA_FEE",                    // 196
   "STAR_AXS_PROC",                    // 197
   "REQ_TYPE",                         // 198
   "NET_ID_CODE",                      // 199
   "NET_PROC_CODE",                    // 200
   "MONTH_NAME",                       // 201
   "REV_REASON",                       // 202
   "REASON_CODE",                      // 203
   "CVRN_RELN_CODE",                   // 204
   "OCS_ACT",                          // 205
   "X_NET_INST_ID1",                   // 206
   "CARD_TYPE",                        // 207
   "REPORTING_LVL",                    // 208
   "FRD_CHB_LIMIT",                    // 209
   "CVRN_PROD_CODE",                   // 210
   "CVRN_SYC_CODE",                    // 211
   "MONEYPASS_RCD",                    // 212
   "X_MPAS_PROC_CODE",                 // 213
   "CVRN_CARD_TYPE",                   // 214
   "CVRN_TRAN_CODE",                   // 215
   "IST_TC57_MTI",                     // 216
   "IST_TC57_PCODE",                   // 217
   "TC57_CARD_TYPE",                   // 218
   "TC33_PROC_CODE",                   // 219
   "IST_TC57_AIIC",                    // 220
   "TC57_ENTRY_METH",                  // 221
   "TC57_TXNTYPE",                     // 222
   "TC57_VI_P_E_MOD",                  // 223
   "TC57_EHB_PE_MOD",                  // 224
   "TC57_MOTO_PCP",                    // 225
   "TC57_MOTO_PCAM",                   // 226
   "TC57_MOTO_PCAC",                   // 227
   "TC57_IN_CAP",                      // 228
   "TC57_AUTH_C",                      // 229
   "TC57_OPER_ENV",                    // 230
   "TC57_CRDHLDR_PT",                  // 231
   "TC57_IN_MOD",                      // 232
   "TC57_A_METH",                      // 233
   "TC57_CH_AUTHENT",                  // 234
   "TC57_CAPT_CAP",                    // 235
   "TC57_REV_AD_MOD",                  // 236
   "TC57_REV_AD_PIN",                  // 237
   "TC57_REV_MC_CDI",                  // 238
   "TC57_REV_CPT",                     // 239
   "TC57_CARD_PT",                     // 240
   "TC57_DC_REV_MOD",                  // 241
   "TC57_DC_REV_CAP",                  // 242
   "TC57_CAVV_RESLT",                  // 243
   "TC57_WALLET_IND",                  // 244
   "TC57_UN_ATTEND",                   // 245
   "TC57_AMX_IN_CAP",                  // 246
   "TC57_AMX_AUTH_C",                  // 247
   "TC57_AMX_OP_ENV",                  // 248
   "TC57_AMX_CH_PT",                   // 249
   "TC57_AMX_CRD_PT",                  // 250
   "TC57_AMX_IN_MOD",                  // 251
   "TC57_AMX_CH_ENT",                  // 252
   "TC57_AMX_OT_CAP",                  // 253
   "TC57_AMX_A_METH",                  // 254
   "TC57_AMX_PN_CAP",                  // 255
   "TSYS_PROC_CODE",                   // 256
   "CVRN_CARDTP_SB",                   // 257
   "AU_CLASS_NAME",                    // 258
   "ACH_FROM_ACCT",                    // 259
   "ACH_TO_ACCT",                      // 260
   "POST_BH_OVR_IND",                  // 261
   "X_SHZ_PROC_CODE",                  // 262
   "MRCHSTLTIME",                      // 263
   "TOKEN_STATUS"                      // 264

};
const char* pszVerificationClass[] =
{
   "CARD_OWNER_TYPE",                  // 0
   "CARD_TYPE",                        // 1
   "FIN_TRAN_TYPE",                    // 2
   "TRAN_TYPE_IND",                    // 3
   "X_XML_PROC_NETID",                 // 4
   "QMR_BIN",                          // 5
   "QMR_ISSUER_BINS",                  // 6
   "REPORTING_LVL_BUS"                 // 7

};
const char* pszMappingClass[] =
{
   "X_INST_ID_RECON"                   // 0
};
//## end module%39105050014B.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConfigurationFactory 

//## begin configuration::ConfigurationFactory::Instance%391050B10065.attr preserve=no  private: static configuration::ConfigurationFactory* {V} 0
configuration::ConfigurationFactory* ConfigurationFactory::m_pInstance = 0;
//## end configuration::ConfigurationFactory::Instance%391050B10065.attr

ConfigurationFactory::ConfigurationFactory()
  //## begin ConfigurationFactory::ConfigurationFactory%390F3EB902E3_const.hasinit preserve=no
  //## end ConfigurationFactory::ConfigurationFactory%390F3EB902E3_const.hasinit
  //## begin ConfigurationFactory::ConfigurationFactory%390F3EB902E3_const.initialization preserve=yes
  //## end ConfigurationFactory::ConfigurationFactory%390F3EB902E3_const.initialization
{
  //## begin configuration::ConfigurationFactory::ConfigurationFactory%390F3EB902E3_const.body preserve=yes
   memcpy(m_sID,"CF02",4);
   int iClass = sizeof(pszConversionClass) / sizeof(char*);
   string strClass;
   int m = 0;
   for (m = 0;m < iClass;++m)
   {
      strClass = pszConversionClass[m];
      m_hConversionClasses.insert(map<string,int,less<string> >::value_type(strClass,m));
   }
   iClass = sizeof(pszVerificationClass) / sizeof(char*);
   for (m = 0;m < iClass;++m)
   {
      strClass = pszVerificationClass[m];
      m_hVerificationClasses.insert(map<string,int,less<string> >::value_type(strClass,m));
   }
   iClass = sizeof(pszMappingClass) / sizeof(char*);
   for (m = 0;m < iClass;++m)
   {
      strClass = pszMappingClass[m];
      m_hMappingClasses.insert(map<string,int,less<string> >::value_type(strClass,m));
   }
  //## end configuration::ConfigurationFactory::ConfigurationFactory%390F3EB902E3_const.body
}


ConfigurationFactory::~ConfigurationFactory()
{
  //## begin configuration::ConfigurationFactory::~ConfigurationFactory%390F3EB902E3_dest.body preserve=yes
   m_hConversionClasses.erase(m_hConversionClasses.begin(),m_hConversionClasses.end());
   m_hVerificationClasses.erase(m_hVerificationClasses.begin(),m_hVerificationClasses.end());
   m_hMappingClasses.erase(m_hMappingClasses.begin(),m_hMappingClasses.end());
  //## end configuration::ConfigurationFactory::~ConfigurationFactory%390F3EB902E3_dest.body
}



//## Other Operations (implementation)
Object* ConfigurationFactory::createConversionItem (const char* pszClass, const char* pszValue)
{
  //## begin configuration::ConfigurationFactory::createConversionItem%391050E402E9.body preserve=yes
   string strClass(pszClass);
   map<string,int,less<string> >::iterator pClass = m_hConversionClasses.find(strClass);
   if (pClass == m_hConversionClasses.end())
      return 0;
   Object* pObject = 0;
   switch ((*pClass).second)
   {
      case 0:
         pObject = new AdvantageCardLogo();
         break;
      case 1:
         pObject = new AdvantageCardType();
         break;
      case 2:
         pObject = new AdvantageMessageCode();
         break;
      case 3:
         pObject = new AdvantageProcessCode();
         break;
      case 4:
         pObject = new VisaProcessCode();
         break;
      case 5:
         pObject = new CirrusProcessCode();
         break;
      case 6:
         pObject = new PlusProcessCode();
         break;
      case 7:
         pObject = new VisaAdjustmentReason();
         break;
      case 8:
         pObject = new CirrusAdjustmentReason();
         break;
      case 9:
         pObject = new PlusCorrectionReason();
         break;
      case 10:
         pObject = new Device();
         break;
      case 11:
         pObject = new Institution();
         break;
      case 12:
         pObject = new Processor();
         break;
      case 13:
         pObject = new ConnexRejectCode();
         break;
      case 14:
         pObject = new ConnexMessageTypeIdentifier();
         break;
      case 15:
         pObject = new ConnexProcessCode();
         break;
      case 16:
         pObject = new OnlineNetwork();
         break;
      case 17:
         pObject = new ConnexAdviceReason();
         break;
      case 18:
         pObject = new Base24ATMProcessCode();
         break;
      case 19:
         pObject = new Base24POSProcessCode();
         break;
      case 20:
         pObject = new Base24ATMResponseCode();
         break;
      case 21:
         pObject = new Base24POSResponseCode();
         break;
      case 22:
         pObject = new Base24ReversalCode();
         break;
      case 23:
         pObject = new LowCash();
         break;
      case 24:
         pObject = new GenericTransactionClass();
         break;
      case 25:
         pObject = new GasperStatusCode();
         break;
      case 26:
         pObject = new ProcessorGroup();
         break;
      case 27:
         pObject = new ConnexPinEntryMode();
         break;
      case 28:
         pObject = new ConnexPanEntryMode1();
         break;
      case 29:
         pObject = new ConnexPanEntryMode2();
         break;
      case 30:
         pObject = new ConnexPOSConditionCode1();
         break;
      case 31:
         pObject = new ConnexPOSConditionCode2();
         break;
      case 32:
         pObject = new ConnexPOSConditionCode3();
         break;
      case 33:
         pObject = new ConnexPOSConditionCode4();
         break;
      case 34:
         pObject = new ConnexPOSConditionCode5();
         break;
      case 35:
         pObject = new ConnexPOSConditionCode6();
         break;
      case 36:
         pObject = new ConnexPOSConditionCode7();
         break;
      case 37:
         pObject = new ConnexPOSConditionCode8();
         break;
      case 38:
         pObject = new ConnexTerminalType1();
         break;
      case 39:
         pObject = new ConnexTerminalType2();
         break;
      case 40:
         pObject = new ConnexNetworkID();
         break;
      case 41:
         pObject = new NetworkInstitution();
         break;
      case 42:
         pObject = new OasisProcessCode();
         break;
      case 43:
         pObject = new ConnexATMStatus();
         break;
      case 44:
         pObject = new NetworkMiscData();
         break;
      case 45:
         pObject = new NetworkMiscDataRev();
         break;
      case 46:
         pObject = new DNTransactionType();
         break;
      case 47:
         pObject = new CountryCode();
         break;
      case 48:
         pObject = new CountryCode2to3();
         break;
      case 49:
         pObject = new OasisRespCode();
         break;
      case 50:
         pObject = new OasisCardProduct();
         break;
      case 51:
         pObject = new OasisReasonCode();
         break;
      case 52:
         pObject = new OasisTermType();
         break;
      case 53:
         pObject = new OasisPCode();
         break;
      case 54:
         pObject = new CountryCodeNum();
         break;
      case 55:
         pObject = new StarProcessCode();
         break;
      case 56:
         pObject = new StarActionType();
         break;
      case 57:
         pObject = new StarActionTypeRev();
         break;
      case 58:
         pObject = new StarProcessCodeRev();
         break;
      case 59:
         pObject = new Miscellaneous("TERM_CLASS");
         break;
      case 60:
         pObject = new OasisNetwork();
         break;
      case 61:
         pObject = new MCIPMProcessCode();
         break;
      case 62:
         pObject = new NACHAReturnCode();
         break;
      case 63:
         pObject = new ActionCode();
         break;
      case 64:
         pObject = new DeviceRev();
         break;
      case 65:
         pObject = new DeviceAddress();
         break;
      case 66:
         pObject = new GenericTranslation();
         break;
      case 67:
         pObject = new CountryCodeNumToISO();
         break;
      case 68:
         pObject = new PulseProcessCode();
         break;
      case 69:
         pObject = new PulseProcessCodeRev();
         break;
      case 70:
         pObject = new DisputedAuthorizationTransaction();
         break;
      case 71:
         pObject = new ErrorMessage();
         break;
      case 72:
         pObject = new InstitutionBankID();
         break;
      case 73:
         pObject = new PrepaidNetworkId();
         break;
      case 74:
         pObject = new VisaResponseCode();
         break;
      case 75:
         pObject = new MasterCardAdviceReason();
         break;
      case 76:
         pObject = new MasterCardResponseCode();
         break;
      case 77:
         pObject = new DeviceRevAll();
         break;
      case 78:
         pObject = new ProcessorName();
         break;
      case 79:
         pObject = new GenericReverse();
         break;
      case 80:
         pObject = new ActionType();
         break;
      case 81:
         pObject = new Miscellaneous("MASTERCARD_FEE");
         break;
      case 82:
         pObject = new Miscellaneous("VISA_CHARGE");
         break;
      case 83:
         pObject = new Miscellaneous("VISA_FEE");
         break;
      case 84:
         pObject = new Miscellaneous("DISCOVER_AIP");
         break;
      case 85:
         pObject = new Miscellaneous("MASTERCARD_IRD");
         break;
      case 86:
         pObject = new BankIDInstitution();
         break;
      case 87:
         pObject = new SettlementWebAdjNetId();
         break;
      case 88:
         pObject = new Miscellaneous("AMEX_FEE_CODE");
         break;
      case 89:
         pObject = new CurrencyCode();
         break;
      case 90:
         pObject = new CurrencyCodeReverse();
         break;
      case 91:
         pObject = new CountryCodeNumToRegion();
         break;
      case 92:
         pObject = new MsgReason();
         break;
      case 93:
         pObject = new NCRProcessCode();
         break;
      case 94:
         pObject = new QMRInstitution();
         break;
      case 95:
         pObject = new QMRAcquirer();
         break;
      case 96:
         pObject = new BusinessCode();
         break;
      case 97:
         pObject = new NetworkStatus();
         break;
      case 98:
         pObject = new NetworkStatusReverse();
         break;
      case 99:
         pObject = new AIMSBillingInstitutionReverse();
         break;
      case 100:
         pObject = new AIMSBillingInstitution();
         break;
      case 101:
         pObject = new ProcessorCalendar();
         break;
      case 102:
         pObject = new InstitutionCalendar();
         break;
      case 103:
         pObject = new CMSProcCode();
         break;
      case 104:
         pObject = new NYCEProcCode();
         break;
      case 105:
         pObject = new QMRVisaBusinessID();
         break;
      case 106:
         pObject = new SchemeFunding();
         break;
      case 107:
         pObject = new ActionTypeRev();
         break;
      case 108:
         pObject = new LoyaltyBin();
         break;
      case 109:
      case 110:
      case 111:
      case 112:
      case 113:
      case 114:
      case 115:
      case 116:
      case 117:
      case 118:
      case 119:
      case 120:
      case 121:
      case 122:
      case 123:
      case 124:
      case 125:
      case 126:
      case 127:
      case 128:
      case 129:
      case 130:
      case 131:
      case 132:
      case 133:
      case 134:
      case 135:
      case 136:
      case 137:
      case 138:
      case 139:
      case 140:
      case 141:
      case 142:
      case 143:
      case 144:
      case 145:
      case 146:
      case 147:
      case 148:
      case 149:
      case 150:
      case 151:
      case 152:
      case 197:
      case 198:
      case 199:
      case 200:
      case 201:
      case 202:
      case 203:
      case 204:
      case 205:
      case 207:
      case 209:
      case 210:
      case 214:
      case 215:
      case 216:
      case 217:
      case 218:
      case 219:
      case 220:
      case 221:
      case 222:
      case 223:
      case 224:
      case 225:
      case 226:
      case 227:
      case 228:
      case 229:
      case 230:
      case 231:
      case 232:
      case 233:
      case 234:
      case 235:
      case 236:
      case 237:
      case 238:
      case 239:
      case 240:
      case 241:
      case 242:
      case 243:
      case 244:
      case 245:
      case 246:
      case 247:
      case 248:
      case 249:
      case 250:
      case 251:
      case 252:
      case 253:
      case 254:
      case 255:
      case 256:
	  case 257:
         pObject = new GenericTranslation(pszClass);
         break;
      case 206:
         pObject = new NetworkInstitution1();
         break;
      case 208:
         pObject = new ReportingLevel();
         break;
      case 153:
      case 154:
      case 155:
      case 156:
      case 157:
      case 158:
      case 159:
      case 160:
      case 161:
      case 162:
      case 163:
      case 164:
      case 165:
      case 166:
      case 167:
      case 168:
      case 169:
      case 170:
      case 171:
      case 172:
      case 173:
      case 174:
      case 175:
      case 176:
      case 177:
      case 178:
      case 179:
      case 180:
      case 181:
      case 182:
      case 183:
      case 184:
      case 185:
      case 186:
      case 187:
      case 188:
      case 189:
      case 190:
      case 191:
      case 192:
      case 193:
      case 194:
      case 195:
      case 196:
         pObject = new GenericReverse(pszClass);
         break;
      case 211:
         pObject = new Miscellaneous("CVRN_SYC_CODE");
         break;
      case 212:
         pObject = new Miscellaneous("MONEYPASS_RCD");
         break;
      case 213:
         pObject = new MoneyPassProcessCode();
         break;
      case 258:
         pObject = new Miscellaneous("AU_CLASS_NAME");
         break;
      case 259:
      case 260:
      case 261:
      case 264:
          pObject = new GenericTranslation(pszClass);
          break;
      case 262:
         pObject = new ShazamProcessCode();
         break;
      case 263:
         pObject = new MerchantSettlementTime();
         break;
}
   return pObject;
  //## end configuration::ConfigurationFactory::createConversionItem%391050E402E9.body
}

Object* ConfigurationFactory::createMappingItem (const char* pszClass, const char* pszValue)
{
  //## begin configuration::ConfigurationFactory::createMappingItem%3ACCDD0E0081.body preserve=yes
   string strClass(pszClass);
   map<string,int,less<string> >::iterator pClass = m_hMappingClasses.find(strClass);
   if (pClass == m_hMappingClasses.end())
      return 0;
   Object* pObject = 0;
   switch ((*pClass).second)
   {
      case 0:
         pObject = new ReconInstitution();
         break;
   }
   return pObject;
  //## end configuration::ConfigurationFactory::createMappingItem%3ACCDD0E0081.body
}

Object* ConfigurationFactory::createVerificationItem (const char* pszClass, const char* pszValue)
{
  //## begin configuration::ConfigurationFactory::createVerificationItem%393E95B50109.body preserve=yes
   string strClass(pszClass);
   map<string,int,less<string> >::iterator pClass = m_hVerificationClasses.find(strClass);
   if (pClass == m_hVerificationClasses.end())
      return 0;
   Object* pObject = 0;
   switch ((*pClass).second)
   {
      case 0:
         pObject = new CardOwnerType();
         break;
      case 1:
         pObject = new CardType();
         break;
      case 2:
         pObject = new FinancialType();
         break;
      case 3:
         pObject = new TransactionTypeIdentifier();
         break;
      case 4:
         pObject = new NetProcessorId();
         break;
      case 5:
         pObject = new QMRIssuers();
         break;
      case 6:
         pObject = new QMRIssuers("BIN");
         break;
        case 7:
         pObject = new ReportingLevelBusiness();
         break;
   }
   return pObject;
  //## end configuration::ConfigurationFactory::createVerificationItem%393E95B50109.body
}

bool ConfigurationFactory::getCRBook (const char* pszTable, string& strCRBook)
{
  //## begin configuration::ConfigurationFactory::getCRBook%3FDDCAA2009C.body preserve=yes
   string strClass(pszTable);
   map<string,int,less<string> >::iterator pClass = m_hVerificationClasses.find(strClass);
   if (pClass != m_hVerificationClasses.end())
   {
      switch ((*pClass).second)
      {
         case 0:
            strCRBook = "Card Owner Type Codes";
            break;
         case 1:
            strCRBook = "Card Type Codes";
            break;
         case 2:
            strCRBook = "Fin Type Codes";
            break;
         case 3:
            strCRBook = "Transaction Type Indicator Codes";
            break;
      }
      return true;
   }
   pClass = m_hConversionClasses.find(strClass);
   if (pClass != m_hConversionClasses.end())
   {
      switch ((*pClass).second)
      {
         case 0:
            strCRBook = "Advantage Card Logo";
            break;
         case 1:
            strCRBook = "Advantage Card Type";
            break;
         case 2:
            strCRBook = "Advantage Message Codes";
            break;
         case 3:
         case 46:
            strCRBook = "Advantage Process Codes";
            break;
         case 4:
            strCRBook = "Visa Process Codes";
            break;
         case 5:
            strCRBook = "CIRRUS Process Codes";
            break;
         case 6:
            strCRBook = "PLUS Process Codes";
            break;
         case 7:
            strCRBook = "VISA Adjustment Reason Codes";
            break;
         case 8:
            strCRBook = "CIRRUS Adjustment Reason Codes";
            break;
         case 9:
            strCRBook = "PLUS Correction Reason Codes";
            break;
         case 10:
         case 64:
         case 65:
         case 77:
            strCRBook = "Devices";
            break;
         case 11:
            strCRBook = "Institutions";
            break;
         case 12:
         case 78:
            strCRBook = "Processors";
            break;
         case 13:
            strCRBook = "IBM Reject Codes";
            break;
         case 14:
            strCRBook = "IBM Message IDs";
            break;
         case 15:
            strCRBook = "IBM Process Codes";
            break;
         case 16:
            strCRBook = "Online Network ID Codes";
            break;
         case 17:
            strCRBook = "IBM Advice Reason Codes";
            break;
         case 18:
            strCRBook = "Base 24 ATM Process Codes";
            break;
         case 19:
            strCRBook = "Base 24 POS Process Codes";
            break;
         case 20:
            strCRBook = "Base 24 ATM Response Codes";
            break;
         case 21:
            strCRBook = "Base 24 POS Response Codes";
            break;
         case 22:
            strCRBook = "Base 24 Reversal Codes";
            break;
         case 23:
            strCRBook = "Device Low Cash";
            break;
         case 24:
            strCRBook = "GenericTransactionClass";
            break;
         case 25:
            strCRBook = "Gasper Status Codes";
            break;
         case 26:
            strCRBook = "Processor Groups";
            break;
         case 27:
            strCRBook = "IBM PIN Entry Modes";
            break;
         case 28:
         case 29:
            strCRBook = "IBM PAN Entry Modes";
            break;
         case 30:
         case 31:
         case 32:
         case 33:
         case 34:
         case 35:
         case 36:
         case 37:
            strCRBook = "IBM POS Condition Codes";
            break;
         case 38:
         case 39:
            strCRBook = "IBM Terminal/Device Type";
            break;
         case 40:
            strCRBook = "IBM Network IDs";
            break;
         case 41:
            strCRBook = "Network Institution IDs";
            break;
         case 42:
            strCRBook = "Oasis TID Codes";
            break;
         case 43:
            strCRBook = "IBM ATM Status";
            break;
         case 44:
         case 45:
            strCRBook = "Miscellaneous Network Data";
            break;
         case 47:
         case 48:
         case 54:
         case 67:
            strCRBook = "ISO Country Codes";
            break;
         case 49:
            strCRBook = "IST Response Codes";
            break;
         case 50:
            strCRBook = "IST Card Type";
            break;
         case 51:
            strCRBook = "IST Reason Code";
            break;
         case 52:
            strCRBook = "IST Terminal Type";
            break;
         case 53:
            strCRBook = "IST Process Code";
            break;
         case 55:
            strCRBook = "Star Proc Code";
            break;
         case 56:
         case 57:
            strCRBook = "Star Action Type";
            break;
         case 58:
            strCRBook = "Star Process Code";
            break;
         case 59:
            strCRBook = "";
            break;
         case 60:
            strCRBook = "IST Network";
            break;
         case 61:
            strCRBook = "MasterCard Process Code";
            break;
         case 62:
            strCRBook = "NACHA Return Codes";
            break;
         case 63:
            strCRBook = "Action Codes";
            break;
         case 66:
            strCRBook = "";
            break;
         case 68:
         case 69:
            strCRBook = "Pulse Process Codes";
            break;
         case 74:
            strCRBook = "VISA Response Code";
            break;
         case 75:
            strCRBook = "MasterCard Advice Reason";
            break;
         case 76:
            strCRBook = "MasterCard Response Code";
            break;
      }
      return true;
   }
   return false;
  //## end configuration::ConfigurationFactory::getCRBook%3FDDCAA2009C.body
}

ConfigurationFactory* ConfigurationFactory::instance (Object* pSender)
{
  //## begin configuration::ConfigurationFactory::instance%3910510F0331.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ConfigurationFactory();
   return m_pInstance;
  //## end configuration::ConfigurationFactory::instance%3910510F0331.body
}

// Additional Declarations
  //## begin configuration::ConfigurationFactory%390F3EB902E3.declarations preserve=yes
  //## end configuration::ConfigurationFactory%390F3EB902E3.declarations

} // namespace configuration

//## begin module%39105050014B.epilog preserve=yes
//## end module%39105050014B.epilog