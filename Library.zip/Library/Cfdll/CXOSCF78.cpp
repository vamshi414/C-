//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4263E3B10119.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%4263E3B10119.cm

//## begin module%4263E3B10119.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%4263E3B10119.cp

//## Module: CXOSCF78%4263E3B10119; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF78.cpp

//## begin module%4263E3B10119.additionalIncludes preserve=no
//## end module%4263E3B10119.additionalIncludes

//## begin module%4263E3B10119.includes preserve=yes
//## end module%4263E3B10119.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF78_h
#include "CXODCF78.hpp"
#endif


//## begin module%4263E3B10119.declarations preserve=no
//## end module%4263E3B10119.declarations

//## begin module%4263E3B10119.additionalDeclarations preserve=yes
//## end module%4263E3B10119.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::OasisReasonCode 

OasisReasonCode::OasisReasonCode()
  //## begin OasisReasonCode::OasisReasonCode%4263E37B0213_const.hasinit preserve=no
  //## end OasisReasonCode::OasisReasonCode%4263E37B0213_const.hasinit
  //## begin OasisReasonCode::OasisReasonCode%4263E37B0213_const.initialization preserve=yes
  : ConversionItem("## CR81 XLATE IST REASON CODE")
  //## end OasisReasonCode::OasisReasonCode%4263E37B0213_const.initialization
{
  //## begin configuration::OasisReasonCode::OasisReasonCode%4263E37B0213_const.body preserve=yes
   memcpy(m_sID,"CF78",4);
  //## end configuration::OasisReasonCode::OasisReasonCode%4263E37B0213_const.body
}


OasisReasonCode::~OasisReasonCode()
{
  //## begin configuration::OasisReasonCode::~OasisReasonCode%4263E37B0213_dest.body preserve=yes
  //## end configuration::OasisReasonCode::~OasisReasonCode%4263E37B0213_dest.body
}



//## Other Operations (implementation)
void OasisReasonCode::bind (reusable::Query& hQuery)
{
  //## begin configuration::OasisReasonCode::bind%4263E41400DA.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_IST_REASON");
   hQuery.bind("X_IST_REASON","MSG_REASON_CODE",Column::STRING,&m_strSecond);
   hQuery.bind("X_IST_REASON","IST_REASON_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IST_REASON","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_IST_REASON","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IST_REASON","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_IST_REASON","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_IST_REASON.IST_REASON_CODE ASC,X_IST_REASON.CUST_ID DESC");

  //## end configuration::OasisReasonCode::bind%4263E41400DA.body
}

// Additional Declarations
  //## begin configuration::OasisReasonCode%4263E37B0213.declarations preserve=yes
  //## end configuration::OasisReasonCode%4263E37B0213.declarations

} // namespace configuration

//## begin module%4263E3B10119.epilog preserve=yes
//## end module%4263E3B10119.epilog


// Detached code regions:
// WARNING: this code will be lost if code is regenerated.
#if 0
//## begin configuration::OasisReasonCode::getSecond%42ADBAAD0167.body preserve=no
   //concatenate MSG_RESON_CODE_ACQ and MSG_RESON_CODE_ISS
   string strReasonCode(m_strMSG_RESON_CODE_ACQ);
   strReasonCode.append("~",1);
   strReasonCode.append(m_strMSG_RESON_CODE_ISS);
   return strReasonCode;
//## end configuration::OasisReasonCode::getSecond%42ADBAAD0167.body

#endif
