//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%391C0E1B011E.cm preserve=no
//## end module%391C0E1B011E.cm

//## begin module%391C0E1B011E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%391C0E1B011E.cp

//## Module: CXOSCF17%391C0E1B011E; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF17.cpp

//## begin module%391C0E1B011E.additionalIncludes preserve=no
//## end module%391C0E1B011E.additionalIncludes

//## begin module%391C0E1B011E.includes preserve=yes
// $Date:   Dec 16 2016 14:58:40  $ $Author:   e1009652  $ $Revision:   1.11  $
//## end module%391C0E1B011E.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF17_h
#include "CXODCF17.hpp"
#endif


//## begin module%391C0E1B011E.declarations preserve=no
//## end module%391C0E1B011E.declarations

//## begin module%391C0E1B011E.additionalDeclarations preserve=yes
//## end module%391C0E1B011E.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::Institution 

Institution::Institution()
  //## begin Institution::Institution%391C0CAC015D_const.hasinit preserve=no
  //## end Institution::Institution%391C0CAC015D_const.hasinit
  //## begin Institution::Institution%391C0CAC015D_const.initialization preserve=yes
   : ConversionItem("## CR20 CHAIN INST TO PROC")
  //## end Institution::Institution%391C0CAC015D_const.initialization
{
  //## begin configuration::Institution::Institution%391C0CAC015D_const.body preserve=yes
   memcpy(m_sID,"CF17",4);
  //## end configuration::Institution::Institution%391C0CAC015D_const.body
}


Institution::~Institution()
{
  //## begin configuration::Institution::~Institution%391C0CAC015D_dest.body preserve=yes
  //## end configuration::Institution::~Institution%391C0CAC015D_dest.body
}



//## Other Operations (implementation)
void Institution::bind (Query& hQuery)
{
  //## begin configuration::Institution::bind%391C1BFB02C0.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","INSTITUTION");
   hQuery.bind("INSTITUTION","INST_ID",Column::STRING,&m_strFirst);
   hQuery.bind("INSTITUTION","PROC_ID",Column::STRING,&m_strSecond);
   hQuery.bind("INSTITUTION","COUNTRY_CODE",Column::STRING,&m_strThird);
   hQuery.bind("INSTITUTION","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("INSTITUTION","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("INSTITUTION","CC_STATE","IN","('A','I')");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("INSTITUTION","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("INSTITUTION.INST_ID ASC,INSTITUTION.CUST_ID DESC");
  //## end configuration::Institution::bind%391C1BFB02C0.body
}

const string& Institution::getThird ()
{
  //## begin configuration::Institution::getThird%63185F4C01B3.body preserve=yes
	m_strThird.resize(3,' ');
	return m_strThird;
  //## end configuration::Institution::getThird%63185F4C01B3.body
}

void Institution::setPredicate (Query& hQuery)
{
  //## begin configuration::Institution::setPredicate%584714E50139.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setBasicPredicate("INSTITUTION", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("INSTITUTION", "CC_STATE", "IN", "('A','I')");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("INSTITUTION", "CUST_ID", "IN", strTemp.c_str());
  //## end configuration::Institution::setPredicate%584714E50139.body
}

// Additional Declarations
  //## begin configuration::Institution%391C0CAC015D.declarations preserve=yes
  //## end configuration::Institution%391C0CAC015D.declarations

} // namespace configuration

//## begin module%391C0E1B011E.epilog preserve=yes
//## end module%391C0E1B011E.epilog
