//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4092C23E02BF.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%4092C23E02BF.cm

//## begin module%4092C23E02BF.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%4092C23E02BF.cp

//## Module: CXOSCF62%4092C23E02BF; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF62.cpp

//## begin module%4092C23E02BF.additionalIncludes preserve=no
//## end module%4092C23E02BF.additionalIncludes

//## begin module%4092C23E02BF.includes preserve=yes
// $Date:   Apr 17 2014 21:06:02  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%4092C23E02BF.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF62_h
#include "CXODCF62.hpp"
#endif


//## begin module%4092C23E02BF.declarations preserve=no
//## end module%4092C23E02BF.declarations

//## begin module%4092C23E02BF.additionalDeclarations preserve=yes
//## end module%4092C23E02BF.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::OasisProcessCode 

OasisProcessCode::OasisProcessCode()
  //## begin OasisProcessCode::OasisProcessCode%4092BE1C03A9_const.hasinit preserve=no
  //## end OasisProcessCode::OasisProcessCode%4092BE1C03A9_const.hasinit
  //## begin OasisProcessCode::OasisProcessCode%4092BE1C03A9_const.initialization preserve=yes
   : ConversionItem("## CR74 XLATE OASIS TID")
  //## end OasisProcessCode::OasisProcessCode%4092BE1C03A9_const.initialization
{
  //## begin configuration::OasisProcessCode::OasisProcessCode%4092BE1C03A9_const.body preserve=yes
   memcpy(m_sID,"CF62",4);
  //## end configuration::OasisProcessCode::OasisProcessCode%4092BE1C03A9_const.body
}


OasisProcessCode::~OasisProcessCode()
{
  //## begin configuration::OasisProcessCode::~OasisProcessCode%4092BE1C03A9_dest.body preserve=yes
  //## end configuration::OasisProcessCode::~OasisProcessCode%4092BE1C03A9_dest.body
}



//## Other Operations (implementation)
void OasisProcessCode::bind (reusable::Query& hQuery)
{
  //## begin configuration::OasisProcessCode::bind%4092BF5A00AB.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_IST_TID");
   hQuery.bind("X_IST_TID","TID",Column::STRING,&m_strOASIS_PROCESS_CODE);
   hQuery.bind("X_IST_TID","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("X_IST_TID","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("X_IST_TID","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("X_IST_TID","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("X_IST_TID","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_IST_TID","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IST_TID","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_IST_TID","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_IST_TID.TID ASC,X_IST_TID.CUST_ID DESC");
  //## end configuration::OasisProcessCode::bind%4092BF5A00AB.body
}

const string& OasisProcessCode::getFirst ()
{
  //## begin configuration::OasisProcessCode::getFirst%4092BF5E005D.body preserve=yes
  return m_strOASIS_PROCESS_CODE;
  //## end configuration::OasisProcessCode::getFirst%4092BF5E005D.body
}

const string& OasisProcessCode::getSecond ()
{
  //## begin configuration::OasisProcessCode::getSecond%4092BF6301C5.body preserve=yes
   while (m_strPROCESS_CODE.length() < 6)
      m_strPROCESS_CODE += ' ';
   while (m_strMSG_CLASS.length() < 1)
      m_strMSG_CLASS += ' ';
   while (m_strPRE_AUTH.length() < 1)
      m_strPRE_AUTH += ' ';
   m_strSecond = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strSecond;
  //## end configuration::OasisProcessCode::getSecond%4092BF6301C5.body
}

// Additional Declarations
  //## begin configuration::OasisProcessCode%4092BE1C03A9.declarations preserve=yes
  //## end configuration::OasisProcessCode%4092BE1C03A9.declarations

} // namespace configuration

//## begin module%4092C23E02BF.epilog preserve=yes
//## end module%4092C23E02BF.epilog
