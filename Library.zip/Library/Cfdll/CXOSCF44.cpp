//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3AD310800274.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3AD310800274.cm

//## begin module%3AD310800274.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3AD310800274.cp

//## Module: CXOSCF44%3AD310800274; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF44.cpp

//## begin module%3AD310800274.additionalIncludes preserve=no
//## end module%3AD310800274.additionalIncludes

//## begin module%3AD310800274.includes preserve=yes
// $Date:   Apr 08 2004 14:11:22  $ $Author:   D02405  $ $Revision:   1.4  $
//## end module%3AD310800274.includes

#ifndef CXOSCF44_h
#include "CXODCF44.hpp"
#endif
//## begin module%3AD310800274.declarations preserve=no
//## end module%3AD310800274.declarations

//## begin module%3AD310800274.additionalDeclarations preserve=yes
//## end module%3AD310800274.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::MapData 






MapData::MapData()
  //## begin MapData::MapData%3AD30F9E02D3_const.hasinit preserve=no
  //## end MapData::MapData%3AD30F9E02D3_const.hasinit
  //## begin MapData::MapData%3AD30F9E02D3_const.initialization preserve=yes
  //## end MapData::MapData%3AD30F9E02D3_const.initialization
{
  //## begin configuration::MapData::MapData%3AD30F9E02D3_const.body preserve=yes
   memcpy(m_sID,"CF44",4);
  //## end configuration::MapData::MapData%3AD30F9E02D3_const.body
}

MapData::MapData(const MapData &right)
  //## begin MapData::MapData%3AD30F9E02D3_copy.hasinit preserve=no
  //## end MapData::MapData%3AD30F9E02D3_copy.hasinit
  //## begin MapData::MapData%3AD30F9E02D3_copy.initialization preserve=yes
  //## end MapData::MapData%3AD30F9E02D3_copy.initialization
{
  //## begin configuration::MapData::MapData%3AD30F9E02D3_copy.body preserve=yes
   memcpy(m_sID,"CF44",4);
   m_strPrimary = right.m_strPrimary;
   m_strSecondary = right.m_strSecondary;
   m_strTertiary = right.m_strTertiary;
   m_strResult = right.m_strResult;
  //## end configuration::MapData::MapData%3AD30F9E02D3_copy.body
}


MapData::~MapData()
{
  //## begin configuration::MapData::~MapData%3AD30F9E02D3_dest.body preserve=yes
  //## end configuration::MapData::~MapData%3AD30F9E02D3_dest.body
}


MapData & MapData::operator=(const MapData &right)
{
  //## begin configuration::MapData::operator=%3AD30F9E02D3_assign.body preserve=yes
   m_strPrimary = right.m_strPrimary;
   m_strSecondary = right.m_strSecondary;
   m_strTertiary = right.m_strTertiary;
   m_strResult = right.m_strResult;
   return *this;
  //## end configuration::MapData::operator=%3AD30F9E02D3_assign.body
}


bool MapData::operator==(const MapData &right) const
{
  //## begin configuration::MapData::operator==%3AD30F9E02D3_eq.body preserve=yes
   return (m_strPrimary == right.getPrimary()
      && m_strSecondary == right.getSecondary()
      && m_strTertiary == right.getTertiary()
      && m_strResult == right.getResult());
  //## end configuration::MapData::operator==%3AD30F9E02D3_eq.body
}

bool MapData::operator!=(const MapData &right) const
{
  //## begin configuration::MapData::operator!=%3AD30F9E02D3_neq.body preserve=yes
   return !(operator==(right));
  //## end configuration::MapData::operator!=%3AD30F9E02D3_neq.body
}


// Additional Declarations
  //## begin configuration::MapData%3AD30F9E02D3.declarations preserve=yes
  //## end configuration::MapData%3AD30F9E02D3.declarations

} // namespace configuration

//## begin module%3AD310800274.epilog preserve=yes
//## end module%3AD310800274.epilog
