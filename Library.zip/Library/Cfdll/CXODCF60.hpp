//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4006A1500128.cm preserve=no
//	$Date:   Dec 12 2016 13:12:20  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%4006A1500128.cm

//## begin module%4006A1500128.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4006A1500128.cp

//## Module: CXOSCF60%4006A1500128; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF60.hpp

#ifndef CXOSCF60_h
#define CXOSCF60_h 1

//## begin module%4006A1500128.additionalIncludes preserve=no
//## end module%4006A1500128.additionalIncludes

//## begin module%4006A1500128.includes preserve=yes
// $Date:   Dec 12 2016 13:12:20  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%4006A1500128.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
//## begin module%4006A1500128.declarations preserve=no
//## end module%4006A1500128.declarations

//## begin module%4006A1500128.additionalDeclarations preserve=yes
//## end module%4006A1500128.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexPOSConditionCode8%4006A1CF001F.preface preserve=yes
//## end configuration::ConnexPOSConditionCode8%4006A1CF001F.preface

//## Class: ConnexPOSConditionCode8%4006A1CF001F
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4006A2070167;reusable::Query { -> F}

class DllExport ConnexPOSConditionCode8 : public ConversionItem  //## Inherits: <unnamed>%4006A1F6038A
{
  //## begin configuration::ConnexPOSConditionCode8%4006A1CF001F.initialDeclarations preserve=yes
  //## end configuration::ConnexPOSConditionCode8%4006A1CF001F.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexPOSConditionCode8();

    //## Destructor (generated)
      virtual ~ConnexPOSConditionCode8();


    //## Other Operations (specified)
      //## Operation: bind%4006A20D03A9
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%584716790359
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexPOSConditionCode8%4006A1CF001F.public preserve=yes
      //## end configuration::ConnexPOSConditionCode8%4006A1CF001F.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexPOSConditionCode8%4006A1CF001F.protected preserve=yes
      //## end configuration::ConnexPOSConditionCode8%4006A1CF001F.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexPOSConditionCode8%4006A1CF001F.private preserve=yes
      //## end configuration::ConnexPOSConditionCode8%4006A1CF001F.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexPOSConditionCode8%4006A1CF001F.implementation preserve=yes
      //## end configuration::ConnexPOSConditionCode8%4006A1CF001F.implementation

};

//## begin configuration::ConnexPOSConditionCode8%4006A1CF001F.postscript preserve=yes
//## end configuration::ConnexPOSConditionCode8%4006A1CF001F.postscript

} // namespace configuration

//## begin module%4006A1500128.epilog preserve=yes
using namespace configuration;
//## end module%4006A1500128.epilog


#endif
