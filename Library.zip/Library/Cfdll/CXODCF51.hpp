//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFC3CE900CB.cm preserve=no
//	$Date:   Dec 12 2016 13:02:08  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%3FFC3CE900CB.cm

//## begin module%3FFC3CE900CB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFC3CE900CB.cp

//## Module: CXOSCF51%3FFC3CE900CB; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF51.hpp

#ifndef CXOSCF51_h
#define CXOSCF51_h 1

//## begin module%3FFC3CE900CB.additionalIncludes preserve=no
//## end module%3FFC3CE900CB.additionalIncludes

//## begin module%3FFC3CE900CB.includes preserve=yes
// $Date:   Dec 12 2016 13:02:08  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%3FFC3CE900CB.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
//## begin module%3FFC3CE900CB.declarations preserve=no
//## end module%3FFC3CE900CB.declarations

//## begin module%3FFC3CE900CB.additionalDeclarations preserve=yes
//## end module%3FFC3CE900CB.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexPOSConditionCode2%3FFC3B4E006D.preface preserve=yes
//## end configuration::ConnexPOSConditionCode2%3FFC3B4E006D.preface

//## Class: ConnexPOSConditionCode2%3FFC3B4E006D
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FFC3BB5037A;reusable::Query { -> F}

class DllExport ConnexPOSConditionCode2 : public ConversionItem  //## Inherits: <unnamed>%3FFC3B98006D
{
  //## begin configuration::ConnexPOSConditionCode2%3FFC3B4E006D.initialDeclarations preserve=yes
  //## end configuration::ConnexPOSConditionCode2%3FFC3B4E006D.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexPOSConditionCode2();

    //## Destructor (generated)
      virtual ~ConnexPOSConditionCode2();


    //## Other Operations (specified)
      //## Operation: bind%3FFC3BCD0251
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%5847161400A3
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexPOSConditionCode2%3FFC3B4E006D.public preserve=yes
      //## end configuration::ConnexPOSConditionCode2%3FFC3B4E006D.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexPOSConditionCode2%3FFC3B4E006D.protected preserve=yes
      //## end configuration::ConnexPOSConditionCode2%3FFC3B4E006D.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexPOSConditionCode2%3FFC3B4E006D.private preserve=yes
      //## end configuration::ConnexPOSConditionCode2%3FFC3B4E006D.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexPOSConditionCode2%3FFC3B4E006D.implementation preserve=yes
      //## end configuration::ConnexPOSConditionCode2%3FFC3B4E006D.implementation

};

//## begin configuration::ConnexPOSConditionCode2%3FFC3B4E006D.postscript preserve=yes
//## end configuration::ConnexPOSConditionCode2%3FFC3B4E006D.postscript

} // namespace configuration

//## begin module%3FFC3CE900CB.epilog preserve=yes
using namespace configuration;
//## end module%3FFC3CE900CB.epilog


#endif
