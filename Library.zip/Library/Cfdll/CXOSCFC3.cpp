//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%620DA993002D.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%620DA993002D.cm

//## begin module%620DA993002D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%620DA993002D.cp

//## Module: CXOSCFC3%620DA993002D; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFC3.cpp

//## begin module%620DA993002D.additionalIncludes preserve=no
//## end module%620DA993002D.additionalIncludes

//## begin module%620DA993002D.includes preserve=yes
//## end module%620DA993002D.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCFC3_h
#include "CXODCFC3.hpp"
#endif


//## begin module%620DA993002D.declarations preserve=no
//## end module%620DA993002D.declarations

//## begin module%620DA993002D.additionalDeclarations preserve=yes
//## end module%620DA993002D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::AIMSBillingInstitutionReverse 

AIMSBillingInstitutionReverse::AIMSBillingInstitutionReverse()
  //## begin AIMSBillingInstitutionReverse::AIMSBillingInstitutionReverse%620DA7E501AB_const.hasinit preserve=no
  //## end AIMSBillingInstitutionReverse::AIMSBillingInstitutionReverse%620DA7E501AB_const.hasinit
  //## begin AIMSBillingInstitutionReverse::AIMSBillingInstitutionReverse%620DA7E501AB_const.initialization preserve=yes
   : ConversionItem("## CFC3 XLATE AIMS CHARGE")
  //## end AIMSBillingInstitutionReverse::AIMSBillingInstitutionReverse%620DA7E501AB_const.initialization
{
  //## begin configuration::AIMSBillingInstitutionReverse::AIMSBillingInstitutionReverse%620DA7E501AB_const.body preserve=yes
   memcpy(m_sID,"CFC3",4);
  //## end configuration::AIMSBillingInstitutionReverse::AIMSBillingInstitutionReverse%620DA7E501AB_const.body
}


AIMSBillingInstitutionReverse::~AIMSBillingInstitutionReverse()
{
  //## begin configuration::AIMSBillingInstitutionReverse::~AIMSBillingInstitutionReverse%620DA7E501AB_dest.body preserve=yes
  //## end configuration::AIMSBillingInstitutionReverse::~AIMSBillingInstitutionReverse%620DA7E501AB_dest.body
}



//## Other Operations (implementation)
void AIMSBillingInstitutionReverse::bind (Query& hQuery)
{
  //## begin configuration::AIMSBillingInstitutionReverse::bind%620DA81801DA.body preserve=yes
   hQuery.setQualifier("QUALIFY","AIMS_BILL_INST");
   hQuery.bind("AIMS_BILL_INST","APPL_NO",Column::STRING,&m_strFirst);
   hQuery.bind("AIMS_BILL_INST","ITEM_NO",Column::STRING,&m_strITEM_NO);
   hQuery.bind("AIMS_BILL_INST","AIMS_FI_BILLING_ID",Column::STRING,&m_strSecond);
   hQuery.bind("AIMS_BILL_INST","CATEGORY_ID",Column::STRING,&m_strCATEGORY_ID);
   hQuery.bind("AIMS_BILL_INST","CFG_DESCRIPTION",Column::STRING,&m_strThird);
   hQuery.setBasicPredicate("AIMS_BILL_INST","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("AIMS_BILL_INST","CC_STATE","=","A");
   Extract::instance()->getSpec("CUSTOMER", m_strCUST_ID);
   string strTemp = "('" + m_strCUST_ID + "','****')";
   hQuery.setBasicPredicate("AIMS_BILL_INST","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("APPL_NO,ITEM_NO");
  //## end configuration::AIMSBillingInstitutionReverse::bind%620DA81801DA.body
}

const string& AIMSBillingInstitutionReverse::getFirst ()
{
  //## begin configuration::AIMSBillingInstitutionReverse::getFirst%620DA87A0057.body preserve=yes
   m_strFirst.append(",",1);
   m_strFirst += m_strITEM_NO;
   return m_strFirst;
  //## end configuration::AIMSBillingInstitutionReverse::getFirst%620DA87A0057.body
}

const string& AIMSBillingInstitutionReverse::getSecond ()
{
  //## begin configuration::AIMSBillingInstitutionReverse::getSecond%620DA87C030E.body preserve=yes
   m_strSecond += m_strCATEGORY_ID;
   return m_strSecond;
  //## end configuration::AIMSBillingInstitutionReverse::getSecond%620DA87C030E.body
}

const string& AIMSBillingInstitutionReverse::getThird ()
{
  //## begin configuration::AIMSBillingInstitutionReverse::getThird%620FB45F0045.body preserve=yes
   m_strThird.resize(50,' ');
   return m_strThird;
  //## end configuration::AIMSBillingInstitutionReverse::getThird%620FB45F0045.body
}

// Additional Declarations
  //## begin configuration::AIMSBillingInstitutionReverse%620DA7E501AB.declarations preserve=yes
  //## end configuration::AIMSBillingInstitutionReverse%620DA7E501AB.declarations

} // namespace configuration

//## begin module%620DA993002D.epilog preserve=yes
//## end module%620DA993002D.epilog
