//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%431359570157.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%431359570157.cm

//## begin module%431359570157.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%431359570157.cp

//## Module: CXOSCF83%431359570157; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF83.cpp

//## begin module%431359570157.additionalIncludes preserve=no
//## end module%431359570157.additionalIncludes

//## begin module%431359570157.includes preserve=yes
//## end module%431359570157.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF83_h
#include "CXODCF83.hpp"
#endif


//## begin module%431359570157.declarations preserve=no
//## end module%431359570157.declarations

//## begin module%431359570157.additionalDeclarations preserve=yes
//## end module%431359570157.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::StarActionType 

StarActionType::StarActionType()
  //## begin StarActionType::StarActionType%431357D803D8_const.hasinit preserve=no
  //## end StarActionType::StarActionType%431357D803D8_const.hasinit
  //## begin StarActionType::StarActionType%431357D803D8_const.initialization preserve=yes
   : ConversionItem("## CR83 XLATE STAR ACTION TYPE")
  //## end StarActionType::StarActionType%431357D803D8_const.initialization
{
  //## begin configuration::StarActionType::StarActionType%431357D803D8_const.body preserve=yes
   memcpy(m_sID,"CF83",4);
  //## end configuration::StarActionType::StarActionType%431357D803D8_const.body
}


StarActionType::~StarActionType()
{
  //## begin configuration::StarActionType::~StarActionType%431357D803D8_dest.body preserve=yes
  //## end configuration::StarActionType::~StarActionType%431357D803D8_dest.body
}



//## Other Operations (implementation)
void StarActionType::bind (reusable::Query& hQuery)
{
  //## begin configuration::StarActionType::bind%43135D050251.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_STAR_ACTION_TYPE");
   hQuery.bind("X_STAR_ACTION_TYPE","STAR_ACTION_TYPE",Column::STRING,&m_strFirst);
   hQuery.bind("X_STAR_ACTION_TYPE","REQUEST_TYPE",Column::STRING,&m_strREQUEST_TYPE);
   hQuery.bind("X_STAR_ACTION_TYPE","STATUS",Column::STRING,&m_strSTATUS);
   hQuery.bind("X_STAR_ACTION_TYPE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_STAR_ACTION_TYPE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_STAR_ACTION_TYPE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_STAR_ACTION_TYPE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_STAR_ACTION_TYPE.STAR_ACTION_TYPE ASC,X_STAR_ACTION_TYPE.CUST_ID DESC");
  //## end configuration::StarActionType::bind%43135D050251.body
}

const string& StarActionType::getSecond ()
{
  //## begin configuration::StarActionType::getSecond%43135D0A00FA.body preserve=yes
   while (m_strREQUEST_TYPE.length() < 4)
      m_strREQUEST_TYPE += ' ';
   m_strSecond = m_strREQUEST_TYPE + m_strSTATUS;
   return m_strSecond;
  //## end configuration::StarActionType::getSecond%43135D0A00FA.body
}

// Additional Declarations
  //## begin configuration::StarActionType%431357D803D8.declarations preserve=yes
  //## end configuration::StarActionType%431357D803D8.declarations

} // namespace configuration

//## begin module%431359570157.epilog preserve=yes
//## end module%431359570157.epilog
