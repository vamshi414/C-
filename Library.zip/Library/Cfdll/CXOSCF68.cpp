//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E02DB70280.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40E02DB70280.cm

//## begin module%40E02DB70280.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40E02DB70280.cp

//## Module: CXOSCF68%40E02DB70280; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF68.cpp

//## begin module%40E02DB70280.additionalIncludes preserve=no
//## end module%40E02DB70280.additionalIncludes

//## begin module%40E02DB70280.includes preserve=yes
// $Date:   Nov 10 2014 11:32:16  $ $Author:   e1009674  $ $Revision:   1.7  $
#include "CXODIF03.hpp"
//## end module%40E02DB70280.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF68_h
#include "CXODCF68.hpp"
#endif


//## begin module%40E02DB70280.declarations preserve=no
//## end module%40E02DB70280.declarations

//## begin module%40E02DB70280.additionalDeclarations preserve=yes
//## end module%40E02DB70280.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::NetworkMiscData 

NetworkMiscData::NetworkMiscData()
  //## begin NetworkMiscData::NetworkMiscData%40E02C3C0148_const.hasinit preserve=no
  //## end NetworkMiscData::NetworkMiscData%40E02C3C0148_const.hasinit
  //## begin NetworkMiscData::NetworkMiscData%40E02C3C0148_const.initialization preserve=yes
   : ConversionItem("## CR75 XLATE NETWORK MISC DATA")
  //## end NetworkMiscData::NetworkMiscData%40E02C3C0148_const.initialization
{
  //## begin configuration::NetworkMiscData::NetworkMiscData%40E02C3C0148_const.body preserve=yes
   memcpy(m_sID,"CF68",4);
  //## end configuration::NetworkMiscData::NetworkMiscData%40E02C3C0148_const.body
}


NetworkMiscData::~NetworkMiscData()
{
  //## begin configuration::NetworkMiscData::~NetworkMiscData%40E02C3C0148_dest.body preserve=yes
  //## end configuration::NetworkMiscData::~NetworkMiscData%40E02C3C0148_dest.body
}



//## Other Operations (implementation)
void NetworkMiscData::bind (reusable::Query& hQuery)
{
  //## begin configuration::NetworkMiscData::bind%40E02CC400DA.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_NET_MISC_DATA");
   hQuery.bind("X_NET_MISC_DATA","NET_ID",Column::STRING,&m_strNET_ID);
   hQuery.bind("X_NET_MISC_DATA","DATA_ELEMENT",Column::STRING,&m_strDATA_ELEMENT);
   hQuery.bind("X_NET_MISC_DATA","SUB_ELEMENT",Column::STRING,&m_strSUB_ELEMENT);
   hQuery.bind("X_NET_MISC_DATA","DATA_VALUE",Column::STRING,&m_strDATA_VALUE);
   hQuery.bind("X_NET_MISC_DATA","NETWORK_VALUE",Column::STRING,&m_strNETWORK_VALUE);
   hQuery.bind("X_NET_MISC_DATA","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.bind("X_NET_MISC_DATA","DATA_TYPE",Column::STRING,&m_strDATA_TYPE);
   hQuery.setBasicPredicate("X_NET_MISC_DATA","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_NET_MISC_DATA","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_NET_MISC_DATA","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_NET_MISC_DATA.NET_ID ASC,"
                           "X_NET_MISC_DATA.DATA_ELEMENT ASC,"
                           "X_NET_MISC_DATA.SUB_ELEMENT ASC,"
                           "X_NET_MISC_DATA.DATA_TYPE ASC,"
                           "X_NET_MISC_DATA.DATA_VALUE ASC,"
                           "X_NET_MISC_DATA.CUST_ID DESC");
  //## end configuration::NetworkMiscData::bind%40E02CC400DA.body
}

const string& NetworkMiscData::getFirst ()
{
  //## begin configuration::NetworkMiscData::getFirst%40E02CC7037A.body preserve=yes
   m_strFirst = m_strNET_ID;
   m_strFirst.resize(3,' ');
   m_strFirst.append(m_strDATA_ELEMENT);
   m_strFirst.resize(5,' ');
   m_strFirst.append(m_strSUB_ELEMENT);
   m_strFirst.resize(7,' ');
   m_strFirst.append(m_strDATA_TYPE);
   m_strFirst.append(m_strDATA_VALUE);
   m_strFirst.resize(11,' ');
   m_strNETWORK_VALUE.resize(3,' ');
   return m_strFirst;
  //## end configuration::NetworkMiscData::getFirst%40E02CC7037A.body
}

const string& NetworkMiscData::getSecond ()
{
  //## begin configuration::NetworkMiscData::getSecond%40E02CCB01C5.body preserve=yes
   return m_strNETWORK_VALUE;
  //## end configuration::NetworkMiscData::getSecond%40E02CCB01C5.body
}

// Additional Declarations
  //## begin configuration::NetworkMiscData%40E02C3C0148.declarations preserve=yes
  //## end configuration::NetworkMiscData%40E02C3C0148.declarations

} // namespace configuration

//## begin module%40E02DB70280.epilog preserve=yes
//## end module%40E02DB70280.epilog
