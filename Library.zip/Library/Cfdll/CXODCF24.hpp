//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%393E6B94011F.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%393E6B94011F.cm

//## begin module%393E6B94011F.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%393E6B94011F.cp

//## Module: CXOSCF24%393E6B94011F; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF24.hpp

#ifndef CXOSCF24_h
#define CXOSCF24_h 1

//## begin module%393E6B94011F.additionalIncludes preserve=no
//## end module%393E6B94011F.additionalIncludes

//## begin module%393E6B94011F.includes preserve=yes
// $Date:   Apr 08 2004 14:10:54  $ $Author:   D02405  $ $Revision:   1.4  $
#include <set>
//## end module%393E6B94011F.includes

#ifndef CXOSCF32_h
#include "CXODCF32.hpp"
#endif

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class Count;

} // namespace monitor

//## begin module%393E6B94011F.declarations preserve=no
//## end module%393E6B94011F.declarations

//## begin module%393E6B94011F.additionalDeclarations preserve=yes
//## end module%393E6B94011F.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::VerificationTable%393E6D3A02C0.preface preserve=yes
//## end configuration::VerificationTable%393E6D3A02C0.preface

//## Class: VerificationTable%393E6D3A02C0
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3958ECD6003D;monitor::Count { -> F}

class DllExport VerificationTable : public ConfigurationTable  //## Inherits: <unnamed>%3958D34202E1
{
  //## begin configuration::VerificationTable%393E6D3A02C0.initialDeclarations preserve=yes
  //## end configuration::VerificationTable%393E6D3A02C0.initialDeclarations

  public:
    //## Constructors (generated)
      VerificationTable();

    //## Constructors (specified)
      //## Operation: VerificationTable%393E6F68015A
      VerificationTable (const char* pszName);

    //## Destructor (generated)
      virtual ~VerificationTable();


    //## Other Operations (specified)
      //## Operation: add%393E6F680182
      bool add (const string& strKey);

      //## Operation: find%393E6F6801B4
      bool find (const string& strKey);

      //## Operation: getType%3958EBD20333
      virtual Type getType ()
      {
        //## begin configuration::VerificationTable::getType%3958EBD20333.body preserve=yes
		 return ConfigurationTable::VERIFICATION;
        //## end configuration::VerificationTable::getType%3958EBD20333.body
      }

    // Additional Public Declarations
      //## begin configuration::VerificationTable%393E6D3A02C0.public preserve=yes
      //## end configuration::VerificationTable%393E6D3A02C0.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::VerificationTable%393E6D3A02C0.protected preserve=yes
      //## end configuration::VerificationTable%393E6D3A02C0.protected

  private:
    // Additional Private Declarations
      //## begin configuration::VerificationTable%393E6D3A02C0.private preserve=yes
      //## end configuration::VerificationTable%393E6D3A02C0.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::VerificationTable%393E6D3A02C0.implementation preserve=yes
	  set<string,less<string> > m_hVerificationItem;
      //## end configuration::VerificationTable%393E6D3A02C0.implementation
};

//## begin configuration::VerificationTable%393E6D3A02C0.postscript preserve=yes
//## end configuration::VerificationTable%393E6D3A02C0.postscript

} // namespace configuration

//## begin module%393E6B94011F.epilog preserve=yes
using namespace configuration;
//## end module%393E6B94011F.epilog


#endif
