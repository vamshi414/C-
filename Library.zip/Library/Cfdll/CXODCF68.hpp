//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E02DB100CB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40E02DB100CB.cm

//## begin module%40E02DB100CB.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40E02DB100CB.cp

//## Module: CXOSCF68%40E02DB100CB; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF68.hpp

#ifndef CXOSCF68_h
#define CXOSCF68_h 1

//## begin module%40E02DB100CB.additionalIncludes preserve=no
//## end module%40E02DB100CB.additionalIncludes

//## begin module%40E02DB100CB.includes preserve=yes
// $Date:   May 31 2005 06:17:20  $ $Author:   D98885  $ $Revision:   1.1  $
//## end module%40E02DB100CB.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%40E02DB100CB.declarations preserve=no
//## end module%40E02DB100CB.declarations

//## begin module%40E02DB100CB.additionalDeclarations preserve=yes
//## end module%40E02DB100CB.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::NetworkMiscData%40E02C3C0148.preface preserve=yes
//## end configuration::NetworkMiscData%40E02C3C0148.preface

//## Class: NetworkMiscData%40E02C3C0148
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40E02EC9001F;reusable::Query { -> F}
//## Uses: <unnamed>%40E02ECC006D;IF::Extract { -> F}

class DllExport NetworkMiscData : public ConversionItem  //## Inherits: <unnamed>%40E02EBB001F
{
  //## begin configuration::NetworkMiscData%40E02C3C0148.initialDeclarations preserve=yes
  //## end configuration::NetworkMiscData%40E02C3C0148.initialDeclarations

  public:
    //## Constructors (generated)
      NetworkMiscData();

    //## Destructor (generated)
      virtual ~NetworkMiscData();


    //## Other Operations (specified)
      //## Operation: bind%40E02CC400DA
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getFirst%40E02CC7037A
      virtual const string& getFirst ();

      //## Operation: getSecond%40E02CCB01C5
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::NetworkMiscData%40E02C3C0148.public preserve=yes
      //## end configuration::NetworkMiscData%40E02C3C0148.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::NetworkMiscData%40E02C3C0148.protected preserve=yes
      //## end configuration::NetworkMiscData%40E02C3C0148.protected

  private:
    // Additional Private Declarations
      //## begin configuration::NetworkMiscData%40E02C3C0148.private preserve=yes
      //## end configuration::NetworkMiscData%40E02C3C0148.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DATA_ELEMENT%40E02D2102FD
      //## begin configuration::NetworkMiscData::DATA_ELEMENT%40E02D2102FD.attr preserve=no  private: string {U} 
      string m_strDATA_ELEMENT;
      //## end configuration::NetworkMiscData::DATA_ELEMENT%40E02D2102FD.attr

      //## Attribute: DATA_TYPE%4291E86A001F
      //## begin configuration::NetworkMiscData::DATA_TYPE%4291E86A001F.attr preserve=no  private: string {U} 
      string m_strDATA_TYPE;
      //## end configuration::NetworkMiscData::DATA_TYPE%4291E86A001F.attr

      //## Attribute: DATA_VALUE%40E02D41009C
      //## begin configuration::NetworkMiscData::DATA_VALUE%40E02D41009C.attr preserve=no  private: string {U} 
      string m_strDATA_VALUE;
      //## end configuration::NetworkMiscData::DATA_VALUE%40E02D41009C.attr

      //## Attribute: NET_ID%40E02CE301C5
      //## begin configuration::NetworkMiscData::NET_ID%40E02CE301C5.attr preserve=no  private: string {U} 
      string m_strNET_ID;
      //## end configuration::NetworkMiscData::NET_ID%40E02CE301C5.attr

      //## Attribute: NETWORK_VALUE%40E02D50035B
      //## begin configuration::NetworkMiscData::NETWORK_VALUE%40E02D50035B.attr preserve=no  private: string {U} 
      string m_strNETWORK_VALUE;
      //## end configuration::NetworkMiscData::NETWORK_VALUE%40E02D50035B.attr

      //## Attribute: SUB_ELEMENT%40E02D33003E
      //## begin configuration::NetworkMiscData::SUB_ELEMENT%40E02D33003E.attr preserve=no  private: string {U} 
      string m_strSUB_ELEMENT;
      //## end configuration::NetworkMiscData::SUB_ELEMENT%40E02D33003E.attr

    // Additional Implementation Declarations
      //## begin configuration::NetworkMiscData%40E02C3C0148.implementation preserve=yes
      //## end configuration::NetworkMiscData%40E02C3C0148.implementation

};

//## begin configuration::NetworkMiscData%40E02C3C0148.postscript preserve=yes
//## end configuration::NetworkMiscData%40E02C3C0148.postscript

} // namespace configuration

//## begin module%40E02DB100CB.epilog preserve=yes
using namespace configuration;
//## end module%40E02DB100CB.epilog


#endif
