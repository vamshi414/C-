//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5F0C73DD0356.cm preserve=no
//	$Date:   Aug 17 2020 15:00:54  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5F0C73DD0356.cm

//## begin module%5F0C73DD0356.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5F0C73DD0356.cp

//## Module: CXOSCFB6%5F0C73DD0356; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV03.1A.R001\Build\Dn\Server\Library\Cfdll\CXOSCFB6.cpp

//## begin module%5F0C73DD0356.additionalIncludes preserve=no
//## end module%5F0C73DD0356.additionalIncludes

//## begin module%5F0C73DD0356.includes preserve=yes
//## end module%5F0C73DD0356.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCFB6_h
#include "CXODCFB6.hpp"
#endif


//## begin module%5F0C73DD0356.declarations preserve=no
//## end module%5F0C73DD0356.declarations

//## begin module%5F0C73DD0356.additionalDeclarations preserve=yes
//## end module%5F0C73DD0356.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::MsgReason 

MsgReason::MsgReason()
  //## begin MsgReason::MsgReason%5F0C74D402B3_const.hasinit preserve=no
  //## end MsgReason::MsgReason%5F0C74D402B3_const.hasinit
  //## begin MsgReason::MsgReason%5F0C74D402B3_const.initialization preserve=yes
   : ConversionItem("## CRB6 XLATE MSG REASON")
  //## end MsgReason::MsgReason%5F0C74D402B3_const.initialization
{
  //## begin configuration::MsgReason::MsgReason%5F0C74D402B3_const.body preserve=yes
   memcpy(m_sID,"CFB6",4);
  //## end configuration::MsgReason::MsgReason%5F0C74D402B3_const.body
}


MsgReason::~MsgReason()
{
  //## begin configuration::MsgReason::~MsgReason%5F0C74D402B3_dest.body preserve=yes
  //## end configuration::MsgReason::~MsgReason%5F0C74D402B3_dest.body
}



//## Other Operations (implementation)
void MsgReason::bind (Query& hQuery)
{
  //## begin configuration::MsgReason::bind%5F0C761100C6.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","MSG_REASON");
   hQuery.bind("MSG_REASON","MSG_REASON_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("MSG_REASON","CFG_DESCRIPTION",Column::STRING,&m_strSecond);
   hQuery.bind("MSG_REASON","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("MSG_REASON","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("MSG_REASON","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("MSG_REASON","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("MSG_REASON.MSG_REASON_CODE ASC,MSG_REASON.CUST_ID DESC");
  //## end configuration::MsgReason::bind%5F0C761100C6.body
}

// Additional Declarations
  //## begin configuration::MsgReason%5F0C74D402B3.declarations preserve=yes
  //## end configuration::MsgReason%5F0C74D402B3.declarations

} // namespace configuration

//## begin module%5F0C73DD0356.epilog preserve=yes
//## end module%5F0C73DD0356.epilog
