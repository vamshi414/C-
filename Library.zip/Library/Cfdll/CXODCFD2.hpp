//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%62C6BC1803AD.cm preserve=no
//## end module%62C6BC1803AD.cm

//## begin module%62C6BC1803AD.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%62C6BC1803AD.cp

//## Module: CXOSCFD2%62C6BC1803AD; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCFD2.hpp

#ifndef CXOSCFD2_h
#define CXOSCFD2_h 1

//## begin module%62C6BC1803AD.additionalIncludes preserve=no
//## end module%62C6BC1803AD.additionalIncludes

//## begin module%62C6BC1803AD.includes preserve=yes
//## end module%62C6BC1803AD.includes

#ifndef CXOSDB43_h
#include "CXODDB43.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class WitchingHour;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%62C6BC1803AD.declarations preserve=no
//## end module%62C6BC1803AD.declarations

//## begin module%62C6BC1803AD.additionalDeclarations preserve=yes
//## end module%62C6BC1803AD.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::NationalNetworkBin%62C6BCDC0298.preface preserve=yes
//## end configuration::NationalNetworkBin%62C6BCDC0298.preface

//## Class: NationalNetworkBin%62C6BCDC0298
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%649AD459031F;reusable::Query { -> F}
//## Uses: <unnamed>%649AD45C0348;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%649AD45F02EF;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%649B4D7900FB;timer::WitchingHour { -> F}

class DllExport NationalNetworkBin : public database::Cache  //## Inherits: <unnamed>%649AD3FC03E7
{
  //## begin configuration::NationalNetworkBin%62C6BCDC0298.initialDeclarations preserve=yes
  //## end configuration::NationalNetworkBin%62C6BCDC0298.initialDeclarations

  public:
    //## Constructors (generated)
      NationalNetworkBin();

    //## Destructor (generated)
      virtual ~NationalNetworkBin();


    //## Other Operations (specified)
      //## Operation: instance%649ADE320075
      static NationalNetworkBin* instance ();

      //## Operation: load%649AD40A01D9
      virtual bool load ();

      //## Operation: update%649AD40C0300
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

      //## Operation: verify%649AD47B00AF
      bool verify (const reusable::string& strNET_ID, const reusable::string& strISSUER_BIN, const reusable::string& strPAN);

    // Additional Public Declarations
      //## begin configuration::NationalNetworkBin%62C6BCDC0298.public preserve=yes
      //## end configuration::NationalNetworkBin%62C6BCDC0298.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::NationalNetworkBin%62C6BCDC0298.protected preserve=yes
      //## end configuration::NationalNetworkBin%62C6BCDC0298.protected

  private:
    // Additional Private Declarations
      //## begin configuration::NationalNetworkBin%62C6BCDC0298.private preserve=yes
      //## end configuration::NationalNetworkBin%62C6BCDC0298.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BIN%649AD6260187
      //## begin configuration::NationalNetworkBin::BIN%649AD6260187.attr preserve=no  private: multimap<string,pair<string,string>,less<string> > {U} 
      multimap<string,pair<string,string>,less<string> > m_hBIN;
      //## end configuration::NationalNetworkBin::BIN%649AD6260187.attr

      //## Attribute: BIN_HIGH%649AD5410080
      //## begin configuration::NationalNetworkBin::BIN_HIGH%649AD5410080.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strBIN_HIGH;
      //## end configuration::NationalNetworkBin::BIN_HIGH%649AD5410080.attr

      //## Attribute: BIN_LOW%649AD54001C5
      //## begin configuration::NationalNetworkBin::BIN_LOW%649AD54001C5.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strBIN_LOW;
      //## end configuration::NationalNetworkBin::BIN_LOW%649AD54001C5.attr

      //## Attribute: Instance%649ADE51016C
      //## begin configuration::NationalNetworkBin::Instance%649ADE51016C.attr preserve=no  private: static NationalNetworkBin* {V} 0
      static NationalNetworkBin* m_pInstance;
      //## end configuration::NationalNetworkBin::Instance%649ADE51016C.attr

      //## Attribute: ISSUER_BIN%62C6C3DF01C3
      //## begin configuration::NationalNetworkBin::ISSUER_BIN%62C6C3DF01C3.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strISSUER_BIN;
      //## end configuration::NationalNetworkBin::ISSUER_BIN%62C6C3DF01C3.attr

      //## Attribute: NET_ID%649AD53D001E
      //## begin configuration::NationalNetworkBin::NET_ID%649AD53D001E.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strNET_ID;
      //## end configuration::NationalNetworkBin::NET_ID%649AD53D001E.attr

    // Additional Implementation Declarations
      //## begin configuration::NationalNetworkBin%62C6BCDC0298.implementation preserve=yes
      //## end configuration::NationalNetworkBin%62C6BCDC0298.implementation

};

//## begin configuration::NationalNetworkBin%62C6BCDC0298.postscript preserve=yes
//## end configuration::NationalNetworkBin%62C6BCDC0298.postscript

} // namespace configuration

//## begin module%62C6BC1803AD.epilog preserve=yes
//## end module%62C6BC1803AD.epilog


#endif
