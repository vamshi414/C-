//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%393FFEB603C5.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%393FFEB603C5.cm

//## begin module%393FFEB603C5.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%393FFEB603C5.cp

//## Module: CXOSCF30%393FFEB603C5; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF30.cpp

//## begin module%393FFEB603C5.additionalIncludes preserve=no
//## end module%393FFEB603C5.additionalIncludes

//## begin module%393FFEB603C5.includes preserve=yes
// $Date:   Apr 08 2004 14:11:18  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%393FFEB603C5.includes

#ifndef CXOSCF30_h
#include "CXODCF30.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%393FFEB603C5.declarations preserve=no
//## end module%393FFEB603C5.declarations

//## begin module%393FFEB603C5.additionalDeclarations preserve=yes
//## end module%393FFEB603C5.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::CardType

CardType::CardType()
  //## begin CardType::CardType%393FFCE60006_const.hasinit preserve=no
  //## end CardType::CardType%393FFCE60006_const.hasinit
  //## begin CardType::CardType%393FFCE60006_const.initialization preserve=yes
   : VerificationItem("## CR31 VERIFY CARD TYPE")
  //## end CardType::CardType%393FFCE60006_const.initialization
{
  //## begin configuration::CardType::CardType%393FFCE60006_const.body preserve=yes
   memcpy(m_sID,"CF30",4);
  //## end configuration::CardType::CardType%393FFCE60006_const.body
}


CardType::~CardType()
{
  //## begin configuration::CardType::~CardType%393FFCE60006_dest.body preserve=yes
  //## end configuration::CardType::~CardType%393FFCE60006_dest.body
}



//## Other Operations (implementation)
void CardType::bind (Query& hQuery)
{
  //## begin configuration::CardType::bind%393FFD3500DC.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","CARD_TYPE");
   hQuery.bind("CARD_TYPE","CARD_TYPE",Column::STRING,&m_strKey);
   hQuery.bind("CARD_TYPE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("CARD_TYPE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("CARD_TYPE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("CARD_TYPE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("CARD_TYPE.CUST_ID DESC");
  //## end configuration::CardType::bind%393FFD3500DC.body
}

// Additional Declarations
  //## begin configuration::CardType%393FFCE60006.declarations preserve=yes
  //## end configuration::CardType%393FFCE60006.declarations

} // namespace configuration

//## begin module%393FFEB603C5.epilog preserve=yes
//## end module%393FFEB603C5.epilog
