//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4263E16700AB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%4263E16700AB.cm

//## begin module%4263E16700AB.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%4263E16700AB.cp

//## Module: CXOSCF76%4263E16700AB; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF76.cpp

//## begin module%4263E16700AB.additionalIncludes preserve=no
//## end module%4263E16700AB.additionalIncludes

//## begin module%4263E16700AB.includes preserve=yes
//## end module%4263E16700AB.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF76_h
#include "CXODCF76.hpp"
#endif


//## begin module%4263E16700AB.declarations preserve=no
//## end module%4263E16700AB.declarations

//## begin module%4263E16700AB.additionalDeclarations preserve=yes
//## end module%4263E16700AB.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::OasisCardProduct 

OasisCardProduct::OasisCardProduct()
  //## begin OasisCardProduct::OasisCardProduct%4263E11A00EA_const.hasinit preserve=no
  //## end OasisCardProduct::OasisCardProduct%4263E11A00EA_const.hasinit
  //## begin OasisCardProduct::OasisCardProduct%4263E11A00EA_const.initialization preserve=yes
  : ConversionItem("## CR79 XLATE IST CARD PRODUCT")
  //## end OasisCardProduct::OasisCardProduct%4263E11A00EA_const.initialization
{
  //## begin configuration::OasisCardProduct::OasisCardProduct%4263E11A00EA_const.body preserve=yes
   memcpy(m_sID,"CF76",4);
  //## end configuration::OasisCardProduct::OasisCardProduct%4263E11A00EA_const.body
}


OasisCardProduct::~OasisCardProduct()
{
  //## begin configuration::OasisCardProduct::~OasisCardProduct%4263E11A00EA_dest.body preserve=yes
  //## end configuration::OasisCardProduct::~OasisCardProduct%4263E11A00EA_dest.body
}



//## Other Operations (implementation)
void OasisCardProduct::bind (reusable::Query& hQuery)
{
  //## begin configuration::OasisCardProduct::bind%4263E1E10138.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_IST_CARD_TYPE");
   hQuery.bind("X_IST_CARD_TYPE","CARD_TYPE",Column::STRING,&m_strSecond);
   hQuery.bind("X_IST_CARD_TYPE","IST_CARD_TYPE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IST_CARD_TYPE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_IST_CARD_TYPE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IST_CARD_TYPE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_IST_CARD_TYPE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_IST_CARD_TYPE.IST_CARD_TYPE ASC,X_IST_CARD_TYPE.CUST_ID DESC");
  //## end configuration::OasisCardProduct::bind%4263E1E10138.body
}

// Additional Declarations
  //## begin configuration::OasisCardProduct%4263E11A00EA.declarations preserve=yes
  //## end configuration::OasisCardProduct%4263E11A00EA.declarations

} // namespace configuration

//## begin module%4263E16700AB.epilog preserve=yes
//## end module%4263E16700AB.epilog


// Detached code regions:
// WARNING: this code will be lost if code is regenerated.
#if 0
//## begin configuration::OasisCardProduct::getFirst%4263E1E10148.body preserve=no
   return m_strCARD_TYPE;
//## end configuration::OasisCardProduct::getFirst%4263E1E10148.body

//## begin configuration::OasisCardProduct::getSecond%4263E1E10157.body preserve=no
   return m_strOASIS_VALUE;
//## end configuration::OasisCardProduct::getSecond%4263E1E10157.body

#endif
