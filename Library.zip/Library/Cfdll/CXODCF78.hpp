//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4263E3AF03C8.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%4263E3AF03C8.cm

//## begin module%4263E3AF03C8.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%4263E3AF03C8.cp

//## Module: CXOSCF78%4263E3AF03C8; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF78.hpp

#ifndef CXOSCF78_h
#define CXOSCF78_h 1

//## begin module%4263E3AF03C8.additionalIncludes preserve=no
//## end module%4263E3AF03C8.additionalIncludes

//## begin module%4263E3AF03C8.includes preserve=yes
//## end module%4263E3AF03C8.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%4263E3AF03C8.declarations preserve=no
//## end module%4263E3AF03C8.declarations

//## begin module%4263E3AF03C8.additionalDeclarations preserve=yes
//## end module%4263E3AF03C8.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::OasisReasonCode%4263E37B0213.preface preserve=yes
//## end configuration::OasisReasonCode%4263E37B0213.preface

//## Class: OasisReasonCode%4263E37B0213
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4263E38E02EE;reusable::Query { -> F}
//## Uses: <unnamed>%4263E39002CE;IF::Extract { -> F}

class DllExport OasisReasonCode : public ConversionItem  //## Inherits: <unnamed>%4263E38D001F
{
  //## begin configuration::OasisReasonCode%4263E37B0213.initialDeclarations preserve=yes
  //## end configuration::OasisReasonCode%4263E37B0213.initialDeclarations

  public:
    //## Constructors (generated)
      OasisReasonCode();

    //## Destructor (generated)
      virtual ~OasisReasonCode();


    //## Other Operations (specified)
      //## Operation: bind%4263E41400DA
      virtual void bind (reusable::Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::OasisReasonCode%4263E37B0213.public preserve=yes
      //## end configuration::OasisReasonCode%4263E37B0213.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::OasisReasonCode%4263E37B0213.protected preserve=yes
      //## end configuration::OasisReasonCode%4263E37B0213.protected

  private:
    // Additional Private Declarations
      //## begin configuration::OasisReasonCode%4263E37B0213.private preserve=yes
      //## end configuration::OasisReasonCode%4263E37B0213.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::OasisReasonCode%4263E37B0213.implementation preserve=yes
      //## end configuration::OasisReasonCode%4263E37B0213.implementation

};

//## begin configuration::OasisReasonCode%4263E37B0213.postscript preserve=yes
//## end configuration::OasisReasonCode%4263E37B0213.postscript

} // namespace configuration

//## begin module%4263E3AF03C8.epilog preserve=yes
//## end module%4263E3AF03C8.epilog


#endif
