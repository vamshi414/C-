//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%507D80760375.cm preserve=no
//	$Date:   Apr 17 2014 21:11:00  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%507D80760375.cm

//## begin module%507D80760375.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%507D80760375.cp

//## Module: CXOSCFA0%507D80760375; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.3A.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFA0.cpp

//## begin module%507D80760375.additionalIncludes preserve=no
//## end module%507D80760375.additionalIncludes

//## begin module%507D80760375.includes preserve=yes
//## end module%507D80760375.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFA0_h
#include "CXODCFA0.hpp"
#endif


//## begin module%507D80760375.declarations preserve=no
//## end module%507D80760375.declarations

//## begin module%507D80760375.additionalDeclarations preserve=yes
//## end module%507D80760375.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::MasterCardResponseCode 

MasterCardResponseCode::MasterCardResponseCode()
  //## begin MasterCardResponseCode::MasterCardResponseCode%507D800E0040_const.hasinit preserve=no
  //## end MasterCardResponseCode::MasterCardResponseCode%507D800E0040_const.hasinit
  //## begin MasterCardResponseCode::MasterCardResponseCode%507D800E0040_const.initialization preserve=yes
   : ConversionItem("## CR88 XLATE MC RESP CODE")
  //## end MasterCardResponseCode::MasterCardResponseCode%507D800E0040_const.initialization
{
  //## begin configuration::MasterCardResponseCode::MasterCardResponseCode%507D800E0040_const.body preserve=yes
   memcpy(m_sID,"CFA0",4);
  //## end configuration::MasterCardResponseCode::MasterCardResponseCode%507D800E0040_const.body
}


MasterCardResponseCode::~MasterCardResponseCode()
{
  //## begin configuration::MasterCardResponseCode::~MasterCardResponseCode%507D800E0040_dest.body preserve=yes
  //## end configuration::MasterCardResponseCode::~MasterCardResponseCode%507D800E0040_dest.body
}



//## Other Operations (implementation)
void MasterCardResponseCode::bind (reusable::Query& hQuery)
{
  //## begin configuration::MasterCardResponseCode::bind%507D804200B0.body preserve=yes
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.setQualifier("QUALIFY","X_MC_RESP_CODE");
   hQuery.bind("X_MC_RESP_CODE","MC_RESP_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_MC_RESP_CODE","ACTION_CODE",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_MC_RESP_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_MC_RESP_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCUST_ID + "','****')";
   hQuery.setBasicPredicate("X_MC_RESP_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_MC_RESP_CODE.MC_RESP_CODE ASC,X_MC_RESP_CODE.CUST_ID DESC");
  //## end configuration::MasterCardResponseCode::bind%507D804200B0.body
}

// Additional Declarations
  //## begin configuration::MasterCardResponseCode%507D800E0040.declarations preserve=yes
  //## end configuration::MasterCardResponseCode%507D800E0040.declarations

} // namespace configuration

//## begin module%507D80760375.epilog preserve=yes
//## end module%507D80760375.epilog
