//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%62211AE90361.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%62211AE90361.cm

//## begin module%62211AE90361.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%62211AE90361.cp

//## Module: CXOSCFC6%62211AE90361; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFC6.cpp

//## begin module%62211AE90361.additionalIncludes preserve=no
//## end module%62211AE90361.additionalIncludes

//## begin module%62211AE90361.includes preserve=yes
//## end module%62211AE90361.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFC6_h
#include "CXODCFC6.hpp"
#endif


//## begin module%62211AE90361.declarations preserve=no
//## end module%62211AE90361.declarations

//## begin module%62211AE90361.additionalDeclarations preserve=yes
//## end module%62211AE90361.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::InstitutionCalendar 

InstitutionCalendar::InstitutionCalendar()
  //## begin InstitutionCalendar::InstitutionCalendar%622116B00278_const.hasinit preserve=no
  //## end InstitutionCalendar::InstitutionCalendar%622116B00278_const.hasinit
  //## begin InstitutionCalendar::InstitutionCalendar%622116B00278_const.initialization preserve=yes
  //## end InstitutionCalendar::InstitutionCalendar%622116B00278_const.initialization
{
  //## begin configuration::InstitutionCalendar::InstitutionCalendar%622116B00278_const.body preserve=yes
  //## end configuration::InstitutionCalendar::InstitutionCalendar%622116B00278_const.body
}


InstitutionCalendar::~InstitutionCalendar()
{
  //## begin configuration::InstitutionCalendar::~InstitutionCalendar%622116B00278_dest.body preserve=yes
  //## end configuration::InstitutionCalendar::~InstitutionCalendar%622116B00278_dest.body
}



//## Other Operations (implementation)
void InstitutionCalendar::bind (Query& hQuery)
{
  //## begin configuration::InstitutionCalendar::bind%6221193C0352.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY", "INSTITUTION");
   hQuery.bind("INSTITUTION", "INST_ID", Column::STRING, &m_strFirst);
   hQuery.bind("INSTITUTION", "EVNTID", Column::STRING, &m_strSecond);
   hQuery.bind("INSTITUTION", "CUST_ID", Column::STRING, &m_strCUST_ID);
   hQuery.setBasicPredicate("INSTITUTION", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("INSTITUTION", "CC_STATE", "=", "A");
   hQuery.setBasicPredicate("INSTITUTION", "EVNTSTAT", "=", " ");
   hQuery.setBasicPredicate("INSTITUTION", "EVNTID", "IS NOT NULL");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("INSTITUTION", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("INST_ID ASC");
  //## end configuration::InstitutionCalendar::bind%6221193C0352.body
}

// Additional Declarations
  //## begin configuration::InstitutionCalendar%622116B00278.declarations preserve=yes
  //## end configuration::InstitutionCalendar%622116B00278.declarations

} // namespace configuration

//## begin module%62211AE90361.epilog preserve=yes
//## end module%62211AE90361.epilog
