//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5D9588EB0041.cm preserve=no
//	$Date:   Nov 27 2019 14:43:16  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5D9588EB0041.cm

//## begin module%5D9588EB0041.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5D9588EB0041.cp

//## Module: CXOSCFB3%5D9588EB0041; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\D Drive\Devel 9B\Dn\Server\Library\Cfdll\CXOSCFB3.cpp

//## begin module%5D9588EB0041.additionalIncludes preserve=no
//## end module%5D9588EB0041.additionalIncludes

//## begin module%5D9588EB0041.includes preserve=yes
//## end module%5D9588EB0041.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFB3_h
#include "CXODCFB3.hpp"
#endif


//## begin module%5D9588EB0041.declarations preserve=no
//## end module%5D9588EB0041.declarations

//## begin module%5D9588EB0041.additionalDeclarations preserve=yes
//## end module%5D9588EB0041.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::NCRProcessCode 

NCRProcessCode::NCRProcessCode()
  //## begin NCRProcessCode::NCRProcessCode%5D95867C02ED_const.hasinit preserve=no
  //## end NCRProcessCode::NCRProcessCode%5D95867C02ED_const.hasinit
  //## begin NCRProcessCode::NCRProcessCode%5D95867C02ED_const.initialization preserve=yes
  : ConversionItem("## CFB3 XLATE PROCESS CODE")
  //## end NCRProcessCode::NCRProcessCode%5D95867C02ED_const.initialization
{
  //## begin configuration::NCRProcessCode::NCRProcessCode%5D95867C02ED_const.body preserve=yes
	memcpy(m_sID,"CFB3",4);
  //## end configuration::NCRProcessCode::NCRProcessCode%5D95867C02ED_const.body
}


NCRProcessCode::~NCRProcessCode()
{
  //## begin configuration::NCRProcessCode::~NCRProcessCode%5D95867C02ED_dest.body preserve=yes
  //## end configuration::NCRProcessCode::~NCRProcessCode%5D95867C02ED_dest.body
}



//## Other Operations (implementation)
void NCRProcessCode::bind (reusable::Query& hQuery)
{
  //## begin configuration::NCRProcessCode::bind%5D958DEC00D2.body preserve=yes
	string strCustomerID;
	Extract::instance()->getSpec("CUSTOMER", strCustomerID);
	hQuery.setQualifier("QUALIFY","X_NCR_PROC_CODE");
	hQuery.bind("X_NCR_PROC_CODE","NCR_PROCESS_CODE",Column::STRING,&m_strNCR_PROCESS_CODE);
	hQuery.bind("X_NCR_PROC_CODE","NCR_MTI", Column::STRING,&m_strNCR_MTI);
	hQuery.bind("X_NCR_PROC_CODE","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
	hQuery.bind("X_NCR_PROC_CODE","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
	hQuery.bind("X_NCR_PROC_CODE","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
	hQuery.bind("X_NCR_PROC_CODE","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
	hQuery.bind("X_NCR_PROC_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
	hQuery.setBasicPredicate("X_NCR_PROC_CODE","CC_CHANGE_GRP_ID","IS NULL");
	hQuery.setBasicPredicate("X_NCR_PROC_CODE","CC_STATE", "=","A");
	string strTemp = "('" + strCustomerID + "','****')";
	hQuery.setBasicPredicate("X_NCR_PROC_CODE","CUST_ID","IN",strTemp.c_str());
	hQuery.setOrderByClause("X_NCR_PROC_CODE.NCR_PROCESS_CODE ASC,"
		"X_NCR_PROC_CODE.NCR_MTI ASC,"
		"X_NCR_PROC_CODE.CUST_ID DESC");
  //## end configuration::NCRProcessCode::bind%5D958DEC00D2.body
}

const string& NCRProcessCode::getFirst ()
{
  //## begin configuration::NCRProcessCode::getFirst%5D958EA300FF.body preserve=yes
	while (m_strNCR_PROCESS_CODE.length() < 6)
		m_strNCR_PROCESS_CODE += ' ';
	while (m_strNCR_MTI.length() < 4)
		m_strNCR_MTI += ' ';
	m_strFirst = m_strNCR_PROCESS_CODE + m_strNCR_MTI;
	return m_strFirst;
  //## end configuration::NCRProcessCode::getFirst%5D958EA300FF.body
}

const string& NCRProcessCode::getSecond ()
{
  //## begin configuration::NCRProcessCode::getSecond%5D958ECD01F6.body preserve=yes
	while (m_strPROCESS_CODE.length() < 6)
		m_strPROCESS_CODE += ' ';
	while (m_strMSG_CLASS.length() < 1)
		m_strMSG_CLASS += ' ';
	while (m_strPRE_AUTH.length() < 1)
		m_strPRE_AUTH += ' ';
	while (m_strMEDIA_TYPE.length() < 2)
		m_strPRE_AUTH += ' ';
	m_strSecond = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
	return m_strSecond;
  //## end configuration::NCRProcessCode::getSecond%5D958ECD01F6.body
}

// Additional Declarations
  //## begin configuration::NCRProcessCode%5D95867C02ED.declarations preserve=yes
  //## end configuration::NCRProcessCode%5D95867C02ED.declarations

} // namespace configuration

//## begin module%5D9588EB0041.epilog preserve=yes
//## end module%5D9588EB0041.epilog
