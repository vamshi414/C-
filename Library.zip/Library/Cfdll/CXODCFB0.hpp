//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5B9B637700D7.cm preserve=no
//	$Date:   Sep 21 2018 11:07:10  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5B9B637700D7.cm

//## begin module%5B9B637700D7.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5B9B637700D7.cp

//## Module: CXOSCFB0%5B9B637700D7; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Devel\Dn\Server\Library\Cfdll\CXODCFB0.hpp

#ifndef CXOSCFB0_h
#define CXOSCFB0_h 1

//## begin module%5B9B637700D7.additionalIncludes preserve=no
//## end module%5B9B637700D7.additionalIncludes

//## begin module%5B9B637700D7.includes preserve=yes
//## end module%5B9B637700D7.includes

#ifndef CXOSCF26_h
#include "CXODCF26.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%5B9B637700D7.declarations preserve=no
//## end module%5B9B637700D7.declarations

//## begin module%5B9B637700D7.additionalDeclarations preserve=yes
//## end module%5B9B637700D7.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::NetProcessorId%5B9B5F9E0204.preface preserve=yes
//## end configuration::NetProcessorId%5B9B5F9E0204.preface

//## Class: NetProcessorId%5B9B5F9E0204
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5B9B64AB0275;reusable::Query { -> F}
//## Uses: <unnamed>%5B9B6519020D;IF::Extract { -> F}

class DllExport NetProcessorId : public VerificationItem  //## Inherits: <unnamed>%5B9B9AD80078
{
  //## begin configuration::NetProcessorId%5B9B5F9E0204.initialDeclarations preserve=yes
  //## end configuration::NetProcessorId%5B9B5F9E0204.initialDeclarations

  public:
    //## Constructors (generated)
      NetProcessorId();

    //## Destructor (generated)
      virtual ~NetProcessorId();


    //## Other Operations (specified)
      //## Operation: bind%5B9B658103BD
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::NetProcessorId%5B9B5F9E0204.public preserve=yes
      //## end configuration::NetProcessorId%5B9B5F9E0204.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::NetProcessorId%5B9B5F9E0204.protected preserve=yes
      //## end configuration::NetProcessorId%5B9B5F9E0204.protected

  private:
    // Additional Private Declarations
      //## begin configuration::NetProcessorId%5B9B5F9E0204.private preserve=yes
      //## end configuration::NetProcessorId%5B9B5F9E0204.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::NetProcessorId%5B9B5F9E0204.implementation preserve=yes
      //## end configuration::NetProcessorId%5B9B5F9E0204.implementation

};

//## begin configuration::NetProcessorId%5B9B5F9E0204.postscript preserve=yes
//## end configuration::NetProcessorId%5B9B5F9E0204.postscript

} // namespace configuration

//## begin module%5B9B637700D7.epilog preserve=yes
//## end module%5B9B637700D7.epilog


#endif
