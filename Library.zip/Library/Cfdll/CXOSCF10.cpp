//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%391C0DD40357.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%391C0DD40357.cm

//## begin module%391C0DD40357.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%391C0DD40357.cp

//## Module: CXOSCF10%391C0DD40357; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF10.cpp

//## begin module%391C0DD40357.additionalIncludes preserve=no
//## end module%391C0DD40357.additionalIncludes

//## begin module%391C0DD40357.includes preserve=yes
// $Date:   Apr 17 2014 20:59:18  $ $Author:   e1009652  $ $Revision:   1.6  $
//## end module%391C0DD40357.includes

#ifndef CXOSCF10_h
#include "CXODCF10.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%391C0DD40357.declarations preserve=no
//## end module%391C0DD40357.declarations

//## begin module%391C0DD40357.additionalDeclarations preserve=yes
//## end module%391C0DD40357.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::VisaProcessCode





VisaProcessCode::VisaProcessCode()
  //## begin VisaProcessCode::VisaProcessCode%391C0C2D00C4_const.hasinit preserve=no
  //## end VisaProcessCode::VisaProcessCode%391C0C2D00C4_const.hasinit
  //## begin VisaProcessCode::VisaProcessCode%391C0C2D00C4_const.initialization preserve=yes
   : ConversionItem("## CR13 XLATE VISA PROCESS CODE")
  //## end VisaProcessCode::VisaProcessCode%391C0C2D00C4_const.initialization
{
  //## begin configuration::VisaProcessCode::VisaProcessCode%391C0C2D00C4_const.body preserve=yes
   memcpy(m_sID,"CF10",4);
  //## end configuration::VisaProcessCode::VisaProcessCode%391C0C2D00C4_const.body
}


VisaProcessCode::~VisaProcessCode()
{
  //## begin configuration::VisaProcessCode::~VisaProcessCode%391C0C2D00C4_dest.body preserve=yes
  //## end configuration::VisaProcessCode::~VisaProcessCode%391C0C2D00C4_dest.body
}



//## Other Operations (implementation)
void VisaProcessCode::bind (Query& hQuery)
{
  //## begin configuration::VisaProcessCode::bind%391C1A8202D2.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_VISA_PROC_CODE");
   hQuery.bind("X_VISA_PROC_CODE","VISA_PROCESS_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_VISA_PROC_CODE","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("X_VISA_PROC_CODE","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("X_VISA_PROC_CODE","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("X_VISA_PROC_CODE","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("X_VISA_PROC_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_VISA_PROC_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_VISA_PROC_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_VISA_PROC_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_VISA_PROC_CODE.VISA_PROCESS_CODE ASC,X_VISA_PROC_CODE.CUST_ID DESC");
  //## end configuration::VisaProcessCode::bind%391C1A8202D2.body
}

const string& VisaProcessCode::getSecond ()
{
  //## begin configuration::VisaProcessCode::getSecond%391C1AC8035F.body preserve=yes
   while (m_strPROCESS_CODE.length() < 6)
      m_strPROCESS_CODE += ' ';
   while (m_strMSG_CLASS.length() < 1)
      m_strMSG_CLASS += ' ';
   while (m_strPRE_AUTH.length() < 1)
      m_strPRE_AUTH += ' ';
   m_strSecond = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strSecond;
  //## end configuration::VisaProcessCode::getSecond%391C1AC8035F.body
}

// Additional Declarations
  //## begin configuration::VisaProcessCode%391C0C2D00C4.declarations preserve=yes
  //## end configuration::VisaProcessCode%391C0C2D00C4.declarations

} // namespace configuration

//## begin module%391C0DD40357.epilog preserve=yes
//## end module%391C0DD40357.epilog
