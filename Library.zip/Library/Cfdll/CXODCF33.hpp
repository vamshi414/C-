//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%39985CAE0298.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%39985CAE0298.cm

//## begin module%39985CAE0298.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%39985CAE0298.cp

//## Module: CXOSCF33%39985CAE0298; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF33.hpp

#ifndef CXOSCF33_h
#define CXOSCF33_h 1

//## begin module%39985CAE0298.additionalIncludes preserve=no
//## end module%39985CAE0298.additionalIncludes

//## begin module%39985CAE0298.includes preserve=yes
// $Date:   Apr 08 2004 14:10:58  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%39985CAE0298.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%39985CAE0298.declarations preserve=no
//## end module%39985CAE0298.declarations

//## begin module%39985CAE0298.additionalDeclarations preserve=yes
//## end module%39985CAE0298.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::Base24ATMProcessCode%39985CD10342.preface preserve=yes
//## end configuration::Base24ATMProcessCode%39985CD10342.preface

//## Class: Base24ATMProcessCode%39985CD10342
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%39985FF000DE;reusable::Query { -> F}
//## Uses: <unnamed>%39985FF20055;IF::Extract { -> F}

class DllExport Base24ATMProcessCode : public ConversionItem  //## Inherits: <unnamed>%39985FF4001C
{
  //## begin configuration::Base24ATMProcessCode%39985CD10342.initialDeclarations preserve=yes
  //## end configuration::Base24ATMProcessCode%39985CD10342.initialDeclarations

  public:
    //## Constructors (generated)
      Base24ATMProcessCode();

    //## Destructor (generated)
      virtual ~Base24ATMProcessCode();


    //## Other Operations (specified)
      //## Operation: bind%39993BF601D1
      virtual void bind (Query& hQuery);

      //## Operation: getSecond%39993BF601D3
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::Base24ATMProcessCode%39985CD10342.public preserve=yes
      //## end configuration::Base24ATMProcessCode%39985CD10342.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::Base24ATMProcessCode%39985CD10342.protected preserve=yes
      //## end configuration::Base24ATMProcessCode%39985CD10342.protected

  private:
    // Additional Private Declarations
      //## begin configuration::Base24ATMProcessCode%39985CD10342.private preserve=yes
      //## end configuration::Base24ATMProcessCode%39985CD10342.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: PROCESS_CODE%399860770219
      //## begin configuration::Base24ATMProcessCode::PROCESS_CODE%399860770219.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::Base24ATMProcessCode::PROCESS_CODE%399860770219.attr

      //## Attribute: MSG_CLASS%39986077022D
      //## begin configuration::Base24ATMProcessCode::MSG_CLASS%39986077022D.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::Base24ATMProcessCode::MSG_CLASS%39986077022D.attr

      //## Attribute: PRE_AUTH%399860770241
      //## begin configuration::Base24ATMProcessCode::PRE_AUTH%399860770241.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::Base24ATMProcessCode::PRE_AUTH%399860770241.attr

      //## Attribute: MEDIA_TYPE%39986077024B
      //## begin configuration::Base24ATMProcessCode::MEDIA_TYPE%39986077024B.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::Base24ATMProcessCode::MEDIA_TYPE%39986077024B.attr

    // Additional Implementation Declarations
      //## begin configuration::Base24ATMProcessCode%39985CD10342.implementation preserve=yes
      //## end configuration::Base24ATMProcessCode%39985CD10342.implementation

};

//## begin configuration::Base24ATMProcessCode%39985CD10342.postscript preserve=yes
//## end configuration::Base24ATMProcessCode%39985CD10342.postscript

} // namespace configuration

//## begin module%39985CAE0298.epilog preserve=yes
using namespace configuration;
//## end module%39985CAE0298.epilog


#endif
