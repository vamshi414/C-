//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%60A338330345.cm preserve=no
//	$Date:   Nov 08 2021 10:52:32  $ $Author:   e3028298  $
//	$Revision:   1.3  $
//## end module%60A338330345.cm

//## begin module%60A338330345.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%60A338330345.cp

//## Module: CXOSCFC0%60A338330345; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Devel\V03.2A.R003\Dn\Server\Library\Cfdll\CXOSCFC0.cpp

//## begin module%60A338330345.additionalIncludes preserve=no
//## end module%60A338330345.additionalIncludes

//## begin module%60A338330345.includes preserve=yes
#include "CXODCF01.hpp"
//## end module%60A338330345.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFC0_h
#include "CXODCFC0.hpp"
#endif


//## begin module%60A338330345.declarations preserve=no
//## end module%60A338330345.declarations

//## begin module%60A338330345.additionalDeclarations preserve=yes
//## end module%60A338330345.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::QMRIssuers 

QMRIssuers::QMRIssuers()
  //## begin QMRIssuers::QMRIssuers%60A335E30123_const.hasinit preserve=no
  //## end QMRIssuers::QMRIssuers%60A335E30123_const.hasinit
  //## begin QMRIssuers::QMRIssuers%60A335E30123_const.initialization preserve=yes
   : VerificationItem("## CRC0 VERIFY ISSUER BIN")
  //## end QMRIssuers::QMRIssuers%60A335E30123_const.initialization
{
  //## begin configuration::QMRIssuers::QMRIssuers%60A335E30123_const.body preserve=yes
   memcpy(m_sID,"CFC0",4);
  //## end configuration::QMRIssuers::QMRIssuers%60A335E30123_const.body
}

QMRIssuers::QMRIssuers (const char* pszVerificationItem)
  //## begin configuration::QMRIssuers::QMRIssuers%61065E8B0096.hasinit preserve=no
  //## end configuration::QMRIssuers::QMRIssuers%61065E8B0096.hasinit
  //## begin configuration::QMRIssuers::QMRIssuers%61065E8B0096.initialization preserve=yes
   : VerificationItem("## CRC0 VERIFY ISSUER BIN")
   ,m_strVerificationItem(pszVerificationItem)
  //## end configuration::QMRIssuers::QMRIssuers%61065E8B0096.initialization
{
  //## begin configuration::QMRIssuers::QMRIssuers%61065E8B0096.body preserve=yes
   memcpy(m_sID,"CFC0",4);
  //## end configuration::QMRIssuers::QMRIssuers%61065E8B0096.body
}


QMRIssuers::~QMRIssuers()
{
  //## begin configuration::QMRIssuers::~QMRIssuers%60A335E30123_dest.body preserve=yes
  //## end configuration::QMRIssuers::~QMRIssuers%60A335E30123_dest.body
}



//## Other Operations (implementation)
void QMRIssuers::bind (Query& hQuery)
{
  //## begin configuration::QMRIssuers::bind%60A339CD03BF.body preserve=yes
   string strOrderByClause;
   hQuery.setQualifier("QUALIFY","QMR_BIN");
   if (m_strVerificationItem.empty())
   {
      hQuery.bind("QMR_BIN","INST_ID",Column::STRING,&m_strKey);
      hQuery.bind("QMR_BIN","BIN",Column::STRING,&m_strBIN);
      hQuery.bind("QMR_BIN","NETWORK_ID",Column::STRING,&m_strNETWORK_ID);
      strOrderByClause.assign("INST_ID ASC,BIN ASC,CUST_ID DESC",32);
   }
   else
   {
      hQuery.bind("QMR_BIN",m_strVerificationItem.c_str(),Column::STRING,&m_strKey);
      strOrderByClause.assign(m_strVerificationItem);
   }
   hQuery.setBasicPredicate("QMR_BIN","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("QMR_BIN","CC_STATE","=","A");
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   string strTemp = "('" + strCUST_ID + "','****')";
   hQuery.setBasicPredicate("QMR_BIN","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause(strOrderByClause);
  //## end configuration::QMRIssuers::bind%60A339CD03BF.body
}

const string& QMRIssuers::getKey ()
{
  //## begin configuration::QMRIssuers::getKey%60A33A230225.body preserve=yes
   if (!m_strVerificationItem.empty())
      return m_strKey;
   m_strKey.resize(11,' ');
   m_strKey.append(m_strNETWORK_ID);
   m_strKey.resize(14,' ');
   m_strKey.append(m_strBIN);
   return m_strKey;
  //## end configuration::QMRIssuers::getKey%60A33A230225.body
}

bool QMRIssuers::verifyBin (const string& strBIN, int& iLength)
{
  //## begin configuration::QMRIssuers::verifyBin%610665A602AF.body preserve=yes
   string strKey(strBIN);
   iLength = strKey.length();
   do
   {
      if (ConfigurationRepository::instance()->verify("QMR_ISSUER_BINS",strKey))
         return true;
      strKey.resize(--iLength);
   } while (strKey.length() > 5);
   iLength = 11;
   return false;
  //## end configuration::QMRIssuers::verifyBin%610665A602AF.body
}

// Additional Declarations
  //## begin configuration::QMRIssuers%60A335E30123.declarations preserve=yes
  //## end configuration::QMRIssuers%60A335E30123.declarations

} // namespace configuration

//## begin module%60A338330345.epilog preserve=yes
//## end module%60A338330345.epilog
