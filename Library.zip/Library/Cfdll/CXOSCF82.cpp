//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%431358B40290.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%431358B40290.cm

//## begin module%431358B40290.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%431358B40290.cp

//## Module: CXOSCF82%431358B40290; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF82.cpp

//## begin module%431358B40290.additionalIncludes preserve=no
//## end module%431358B40290.additionalIncludes

//## begin module%431358B40290.includes preserve=yes
//## end module%431358B40290.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF82_h
#include "CXODCF82.hpp"
#endif


//## begin module%431358B40290.declarations preserve=no
//## end module%431358B40290.declarations

//## begin module%431358B40290.additionalDeclarations preserve=yes
//## end module%431358B40290.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::StarProcessCode 

StarProcessCode::StarProcessCode()
  //## begin StarProcessCode::StarProcessCode%431357C20109_const.hasinit preserve=no
  //## end StarProcessCode::StarProcessCode%431357C20109_const.hasinit
  //## begin StarProcessCode::StarProcessCode%431357C20109_const.initialization preserve=yes
   : ConversionItem("## CR82 XLATE STAR PROCESS CODE")
  //## end StarProcessCode::StarProcessCode%431357C20109_const.initialization
{
  //## begin configuration::StarProcessCode::StarProcessCode%431357C20109_const.body preserve=yes
   memcpy(m_sID,"CF82",4);
  //## end configuration::StarProcessCode::StarProcessCode%431357C20109_const.body
}


StarProcessCode::~StarProcessCode()
{
  //## begin configuration::StarProcessCode::~StarProcessCode%431357C20109_dest.body preserve=yes
  //## end configuration::StarProcessCode::~StarProcessCode%431357C20109_dest.body
}



//## Other Operations (implementation)
void StarProcessCode::bind (reusable::Query& hQuery)
{
  //## begin configuration::StarProcessCode::bind%43135A8E0222.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_STAR_PROC_CODE");
   hQuery.bind("X_STAR_PROC_CODE","STAR_TRAN_TYPE",Column::STRING,&m_strFirst);
   hQuery.bind("X_STAR_PROC_CODE","PROCESS_CODE",Column::STRING,&m_strSecond);
   hQuery.bind("X_STAR_PROC_CODE","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("X_STAR_PROC_CODE","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("X_STAR_PROC_CODE","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("X_STAR_PROC_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.getSearchCondition().append("((",2);
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","PROCESS_CODE","LIKE","__0000");
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","PROCESS_CODE","NOT LIKE","09____");
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","PROCESS_CODE","NOT LIKE","11____");
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","MSG_CLASS","=","2");
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","PRE_AUTH","=","0");
   hQuery.getSearchCondition().append(") OR (",6);
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","STAR_TRAN_TYPE","=","ABI");
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","PROCESS_CODE","=","310000");
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","PRE_AUTH","=","0");
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","MEDIA_TYPE","=","00");
   hQuery.getSearchCondition().append("))",2);
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("STAR_TRAN_TYPE ASC,PROCESS_CODE ASC,CUST_ID DESC");
  //## end configuration::StarProcessCode::bind%43135A8E0222.body
}

const string& StarProcessCode::getSecond ()
{
  //## begin configuration::StarProcessCode::getSecond%43135A92038A.body preserve=yes
   m_strSecond.resize(6,' ');
   m_strMSG_CLASS.resize(1,' ');
   m_strSecond += m_strMSG_CLASS;
   m_strPRE_AUTH.resize(1,' ');
   m_strSecond += m_strPRE_AUTH;
   m_strSecond += m_strMEDIA_TYPE;
   return m_strSecond;
  //## end configuration::StarProcessCode::getSecond%43135A92038A.body
}

// Additional Declarations
  //## begin configuration::StarProcessCode%431357C20109.declarations preserve=yes
  //## end configuration::StarProcessCode%431357C20109.declarations

} // namespace configuration

//## begin module%431358B40290.epilog preserve=yes
//## end module%431358B40290.epilog
