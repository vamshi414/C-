//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%394F809E0368.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%394F809E0368.cm

//## begin module%394F809E0368.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%394F809E0368.cp

//## Module: CXOSCF81%394F809E0368; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF81.cpp

//## begin module%394F809E0368.additionalIncludes preserve=no
//## end module%394F809E0368.additionalIncludes

//## begin module%394F809E0368.includes preserve=yes
// $Date:   18 Jan 2018 14:46:00  $ $Author:   e1009839  $ $Revision:   1.3  $
//## end module%394F809E0368.includes

#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif
//## begin module%394F809E0368.declarations preserve=no
//## end module%394F809E0368.declarations

//## begin module%394F809E0368.additionalDeclarations preserve=yes
struct segEvidenceSegment
{
   char sSegmentID[4];
   char sSegmentVersion[4];
   char sLengthOfSegment[8];
   char sTSTAMP_TRANS[16];
   char sUNIQUENESS_KEY[8];
   char sPROBLEM_COLUMN[18];
   char sPROBLEM_TABLE[18];
   char sSUSPECT_TABLE[18];
   char sREASON_CODE[2];
   char sTSTAMP_INSERTED[16];
   char sReserved[4];
   char sLengthOfValue[4];
// This last field is variable length.  It should be int enough
// to hold the intest key used for ConfigurationRepository as
// memory for this structure is not dynamically allocated below
// in read() and write().
   char sSOURCE_VALUE[50];
};

struct segEvidenceSegment* pSegEvidenceSegment = 0;
#define FIELDS 8
Fields EvidenceSegment_Fields[FIELDS + 1] =
{
   "a         ","PROBLEM_COLUMN",offsetof(segEvidenceSegment,sPROBLEM_COLUMN),sizeof(pSegEvidenceSegment->sPROBLEM_COLUMN),
   "a         ","PROBLEM_TABLE",offsetof(segEvidenceSegment,sPROBLEM_TABLE),sizeof(pSegEvidenceSegment->sPROBLEM_TABLE),
   "a         ","REASON_CODE",offsetof(segEvidenceSegment,sREASON_CODE),sizeof(pSegEvidenceSegment->sREASON_CODE),
   "u         ","SOURCE_VALUE",offsetof(segEvidenceSegment,sSOURCE_VALUE),sizeof(pSegEvidenceSegment->sSOURCE_VALUE),
   "a         ","SUSPECT_TABLE",offsetof(segEvidenceSegment,sSUSPECT_TABLE),sizeof(pSegEvidenceSegment->sSUSPECT_TABLE),
   "a         ","TSTAMP_INSERTED",offsetof(segEvidenceSegment,sTSTAMP_INSERTED),sizeof(pSegEvidenceSegment->sTSTAMP_INSERTED),
   "a         ","TSTAMP_TRANS",offsetof(segEvidenceSegment,sTSTAMP_TRANS),sizeof(pSegEvidenceSegment->sTSTAMP_TRANS),
   "s         ","UNIQUENESS_KEY",offsetof(segEvidenceSegment,sUNIQUENESS_KEY),sizeof(pSegEvidenceSegment->sUNIQUENESS_KEY),
   "~","~",0,sizeof(segEvidenceSegment),
};
//## end module%394F809E0368.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::EvidenceSegment 

EvidenceSegment::EvidenceSegment()
  //## begin EvidenceSegment::EvidenceSegment%394F7D850064_const.hasinit preserve=no
      : m_iUNIQUENESS_KEY(0)
  //## end EvidenceSegment::EvidenceSegment%394F7D850064_const.hasinit
  //## begin EvidenceSegment::EvidenceSegment%394F7D850064_const.initialization preserve=yes
   ,PersistentSegment("S235", "PROBLEM_TRAN")
  //## end EvidenceSegment::EvidenceSegment%394F7D850064_const.initialization
{
  //## begin configuration::EvidenceSegment::EvidenceSegment%394F7D850064_const.body preserve=yes
   memcpy(m_sID,"RS11",4);
   setFields();
   reset();
  //## end configuration::EvidenceSegment::EvidenceSegment%394F7D850064_const.body
}

EvidenceSegment::EvidenceSegment(const EvidenceSegment &right)
  //## begin EvidenceSegment::EvidenceSegment%394F7D850064_copy.hasinit preserve=no
      : m_iUNIQUENESS_KEY(0)
  //## end EvidenceSegment::EvidenceSegment%394F7D850064_copy.hasinit
  //## begin EvidenceSegment::EvidenceSegment%394F7D850064_copy.initialization preserve=yes
  //## end EvidenceSegment::EvidenceSegment%394F7D850064_copy.initialization
{
  //## begin configuration::EvidenceSegment::EvidenceSegment%394F7D850064_copy.body preserve=yes
   memcpy(m_sID,"RS11",4);
   setFields();
   reset();
   *this = right;
  //## end configuration::EvidenceSegment::EvidenceSegment%394F7D850064_copy.body
}


EvidenceSegment::~EvidenceSegment()
{
  //## begin configuration::EvidenceSegment::~EvidenceSegment%394F7D850064_dest.body preserve=yes
   delete [] m_pField;
  //## end configuration::EvidenceSegment::~EvidenceSegment%394F7D850064_dest.body
}


EvidenceSegment & EvidenceSegment::operator=(const EvidenceSegment &right)
{
  //## begin configuration::EvidenceSegment::operator=%394F7D850064_assign.body preserve=yes
   if (this == &right)
      return *this;
   PersistentSegment::operator=(right);
   m_strTSTAMP_TRANS = right.getTSTAMP_TRANS();
   m_iUNIQUENESS_KEY = right.getUNIQUENESS_KEY();
   m_strPROBLEM_COLUMN = right.getPROBLEM_COLUMN();
   m_strPROBLEM_TABLE = right.getPROBLEM_TABLE();
   m_strSUSPECT_TABLE = right.getSUSPECT_TABLE();
   m_strREASON_CODE = right.getREASON_CODE();
   m_strTSTAMP_INSERTED = right.getTSTAMP_INSERTED();
   m_strSOURCE_VALUE = right.getSOURCE_VALUE();
   return *this;
  //## end configuration::EvidenceSegment::operator=%394F7D850064_assign.body
}



//## Other Operations (implementation)
struct  Fields* EvidenceSegment::fields () const
{
  //## begin configuration::EvidenceSegment::fields%395386EE0248.body preserve=yes
   return &EvidenceSegment_Fields[0];
  //## end configuration::EvidenceSegment::fields%395386EE0248.body
}

int EvidenceSegment::read (char** ppsBuffer)
{
  //## begin configuration::EvidenceSegment::read%39523CAF0165.body preserve=yes
   return Segment::import(ppsBuffer);
  //## end configuration::EvidenceSegment::read%39523CAF0165.body
}

void EvidenceSegment::setFields ()
{
  //## begin configuration::EvidenceSegment::setFields%396A36450388.body preserve=yes
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strPROBLEM_COLUMN;
   m_pField[1] = &m_strPROBLEM_TABLE;
   m_pField[2] = &m_strREASON_CODE;
   m_pField[3] = &m_strSOURCE_VALUE;
   m_pField[4] = &m_strSUSPECT_TABLE;
   m_pField[5] = &m_strTSTAMP_INSERTED;
   m_pField[6] = &m_strTSTAMP_TRANS;
   m_pField[7] = &m_iUNIQUENESS_KEY;
  //## end configuration::EvidenceSegment::setFields%396A36450388.body
}

int EvidenceSegment::write (char** ppsBuffer)
{
  //## begin configuration::EvidenceSegment::write%39523C990037.body preserve=yes
   return Segment::deport(ppsBuffer);
  //## end configuration::EvidenceSegment::write%39523C990037.body
}

// Additional Declarations
  //## begin configuration::EvidenceSegment%394F7D850064.declarations preserve=yes
  //## end configuration::EvidenceSegment%394F7D850064.declarations

} // namespace configuration

//## begin module%394F809E0368.epilog preserve=yes
//## end module%394F809E0368.epilog
