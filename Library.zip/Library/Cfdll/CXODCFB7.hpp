//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5FA3C7FD0215.cm preserve=no
//	$Date:   Sep 06 2021 04:44:08  $ $Author:   e3028298  $
//	$Revision:   1.2  $
//## end module%5FA3C7FD0215.cm

//## begin module%5FA3C7FD0215.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5FA3C7FD0215.cp

//## Module: CXOSCFB7%5FA3C7FD0215; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\V03.1A.R010\Dn\Server\Library\Cfdll\CXODCFB7.hpp

#ifndef CXOSCFB7_h
#define CXOSCFB7_h 1

//## begin module%5FA3C7FD0215.additionalIncludes preserve=no
//## end module%5FA3C7FD0215.additionalIncludes

//## begin module%5FA3C7FD0215.includes preserve=yes
//## end module%5FA3C7FD0215.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%5FA3C7FD0215.declarations preserve=no
//## end module%5FA3C7FD0215.declarations

//## begin module%5FA3C7FD0215.additionalDeclarations preserve=yes
//## end module%5FA3C7FD0215.additionalDeclarations


namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::QMRInstitution%5FA3C92D01D5.preface preserve=yes
//## end configuration::QMRInstitution%5FA3C92D01D5.preface

//## Class: QMRInstitution%5FA3C92D01D5
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5FA3CD050028;reusable::Query { -> F}
//## Uses: <unnamed>%5FA3CECF02DE;ConfigurationRepository { -> F}
//## Uses: <unnamed>%5FA3D16C02D2;IF::Extract { -> F}

class DllExport QMRInstitution : public ConversionItem  //## Inherits: <unnamed>%5FA3C94E0334
{
  //## begin configuration::QMRInstitution%5FA3C92D01D5.initialDeclarations preserve=yes
  //## end configuration::QMRInstitution%5FA3C92D01D5.initialDeclarations

  public:
    //## Constructors (generated)
      QMRInstitution();

    //## Destructor (generated)
      virtual ~QMRInstitution();


    //## Other Operations (specified)
      //## Operation: bind%5FA3CD1D0361
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%5FA3CD210000
      virtual const string& getFirst ();

      //## Operation: getBinDetails%5FA3CD2802D0
      static bool getBinDetails (const string& strINST_ID, const string& strBIN, int&  iLength, string& strNET_ID);

    // Additional Public Declarations
      //## begin configuration::QMRInstitution%5FA3C92D01D5.public preserve=yes
      virtual const string& getThird();
      //## end configuration::QMRInstitution%5FA3C92D01D5.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::QMRInstitution%5FA3C92D01D5.protected preserve=yes
      //## end configuration::QMRInstitution%5FA3C92D01D5.protected

  private:
    // Additional Private Declarations
      //## begin configuration::QMRInstitution%5FA3C92D01D5.private preserve=yes
      //## end configuration::QMRInstitution%5FA3C92D01D5.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BIN%5FA3CEF203D0
      //## begin configuration::QMRInstitution::BIN%5FA3CEF203D0.attr preserve=no  private: string {V} 
      string m_strBIN;
      //## end configuration::QMRInstitution::BIN%5FA3CEF203D0.attr

    // Additional Implementation Declarations
      //## begin configuration::QMRInstitution%5FA3C92D01D5.implementation preserve=yes
      //## end configuration::QMRInstitution%5FA3C92D01D5.implementation

};

//## begin configuration::QMRInstitution%5FA3C92D01D5.postscript preserve=yes
//## end configuration::QMRInstitution%5FA3C92D01D5.postscript

} // namespace configuration

//## begin module%5FA3C7FD0215.epilog preserve=yes
//## end module%5FA3C7FD0215.epilog


#endif
