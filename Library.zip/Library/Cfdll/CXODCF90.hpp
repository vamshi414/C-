//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%45CBF7D9018C.cm preserve=no
//	$Date:   Aug 06 2020 14:43:22  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%45CBF7D9018C.cm

//## begin module%45CBF7D9018C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%45CBF7D9018C.cp

//## Module: CXOSCF90%45CBF7D9018C; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV03.1A.R001\Build\Dn\Server\Library\Cfdll\CXODCF90.hpp

#ifndef CXOSCF90_h
#define CXOSCF90_h 1

//## begin module%45CBF7D9018C.additionalIncludes preserve=no
//## end module%45CBF7D9018C.additionalIncludes

//## begin module%45CBF7D9018C.includes preserve=yes
//## end module%45CBF7D9018C.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%45CBF7D9018C.declarations preserve=no
//## end module%45CBF7D9018C.declarations

//## begin module%45CBF7D9018C.additionalDeclarations preserve=yes
//## end module%45CBF7D9018C.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ActionCode%45CBF704015C.preface preserve=yes
//## end configuration::ActionCode%45CBF704015C.preface

//## Class: ActionCode%45CBF704015C
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%45CBF903030B;reusable::Query { -> F}
//## Uses: <unnamed>%45CBF90D00EE;IF::Extract { -> F}

class DllExport ActionCode : public ConversionItem  //## Inherits: <unnamed>%45CBF79901B2
{
  //## begin configuration::ActionCode%45CBF704015C.initialDeclarations preserve=yes
  //## end configuration::ActionCode%45CBF704015C.initialDeclarations

  public:
    //## Constructors (generated)
      ActionCode();

    //## Destructor (generated)
      virtual ~ActionCode();


    //## Other Operations (specified)
      //## Operation: bind%45CBFE6F02CC
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>MS
      //	<h3>FIS Connex on HP Card Logo
      //	<p>
      //	The FIS Connex on HP Card Logo table is used to
      //	determine a value for the card owner type (FIN_
      //	RECORD<i>yyyymm</i>.CARD_OWNER) in the financial
      //	transaction.
      //	<p>
      //	Use the CR Client to add or update rows whenever the FIS
      //	Connex on HP acquiring platform introduces a new value
      //	in:
      //	<ul>
      //	<li>CARD^LOGO^ID (1)
      //	</ul>
      //	FIS Connex on HP Card Logo is in the Parameter Tables
      //	folder in the CR Client for the DataNavigator Server.
      //	</body>
      virtual void bind (Query& hQuery);

      //## Operation: getThird%5F0C7223004D
      virtual const string& getThird ()
      {
        //## begin configuration::ActionCode::getThird%5F0C7223004D.body preserve=yes
         m_strThird.resize(50,' ');
         return m_strThird;
        //## end configuration::ActionCode::getThird%5F0C7223004D.body
      }

    // Additional Public Declarations
      //## begin configuration::ActionCode%45CBF704015C.public preserve=yes
      //## end configuration::ActionCode%45CBF704015C.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ActionCode%45CBF704015C.protected preserve=yes
      //## end configuration::ActionCode%45CBF704015C.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ActionCode%45CBF704015C.private preserve=yes
      //## end configuration::ActionCode%45CBF704015C.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ActionCode%45CBF704015C.implementation preserve=yes
      //## end configuration::ActionCode%45CBF704015C.implementation

};

//## begin configuration::ActionCode%45CBF704015C.postscript preserve=yes
//## end configuration::ActionCode%45CBF704015C.postscript

} // namespace configuration

//## begin module%45CBF7D9018C.epilog preserve=yes
//## end module%45CBF7D9018C.epilog


#endif
