//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFDAF96006D.cm preserve=no
//	$Date:   Dec 12 2016 13:10:18  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%3FFDAF96006D.cm

//## begin module%3FFDAF96006D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFDAF96006D.cp

//## Module: CXOSCF57%3FFDAF96006D; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF57.hpp

#ifndef CXOSCF57_h
#define CXOSCF57_h 1

//## begin module%3FFDAF96006D.additionalIncludes preserve=no
//## end module%3FFDAF96006D.additionalIncludes

//## begin module%3FFDAF96006D.includes preserve=yes
// $Date:   Dec 12 2016 13:10:18  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%3FFDAF96006D.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
//## begin module%3FFDAF96006D.declarations preserve=no
//## end module%3FFDAF96006D.declarations

//## begin module%3FFDAF96006D.additionalDeclarations preserve=yes
//## end module%3FFDAF96006D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexTerminalType2%3FFDA85B006D.preface preserve=yes
//## end configuration::ConnexTerminalType2%3FFDA85B006D.preface

//## Class: ConnexTerminalType2%3FFDA85B006D
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FFDA8BA02DE;reusable::Query { -> F}

class DllExport ConnexTerminalType2 : public ConversionItem  //## Inherits: <unnamed>%3FFDA8AD035B
{
  //## begin configuration::ConnexTerminalType2%3FFDA85B006D.initialDeclarations preserve=yes
  //## end configuration::ConnexTerminalType2%3FFDA85B006D.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexTerminalType2();

    //## Destructor (generated)
      virtual ~ConnexTerminalType2();


    //## Other Operations (specified)
      //## Operation: bind%3FFDA87E0290
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%5847169E0140
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexTerminalType2%3FFDA85B006D.public preserve=yes
      //## end configuration::ConnexTerminalType2%3FFDA85B006D.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexTerminalType2%3FFDA85B006D.protected preserve=yes
      //## end configuration::ConnexTerminalType2%3FFDA85B006D.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexTerminalType2%3FFDA85B006D.private preserve=yes
      //## end configuration::ConnexTerminalType2%3FFDA85B006D.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexTerminalType2%3FFDA85B006D.implementation preserve=yes
      //## end configuration::ConnexTerminalType2%3FFDA85B006D.implementation

};

//## begin configuration::ConnexTerminalType2%3FFDA85B006D.postscript preserve=yes
//## end configuration::ConnexTerminalType2%3FFDA85B006D.postscript

} // namespace configuration

//## begin module%3FFDAF96006D.epilog preserve=yes
using namespace configuration;
//## end module%3FFDAF96006D.epilog


#endif
