//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%54AD2EC601D9.cm preserve=no
//	$Date:   Mar 22 2017 15:07:08  $ $Author:   e1009610  $
//	$Revision:   1.2  $
//## end module%54AD2EC601D9.cm

//## begin module%54AD2EC601D9.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%54AD2EC601D9.cp

//## Module: CXOSCFA3%54AD2EC601D9; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFA3.cpp

//## begin module%54AD2EC601D9.additionalIncludes preserve=no
//## end module%54AD2EC601D9.additionalIncludes

//## begin module%54AD2EC601D9.includes preserve=yes
//## end module%54AD2EC601D9.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFA3_h
#include "CXODCFA3.hpp"
#endif


//## begin module%54AD2EC601D9.declarations preserve=no
//## end module%54AD2EC601D9.declarations

//## begin module%54AD2EC601D9.additionalDeclarations preserve=yes
//## end module%54AD2EC601D9.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ProcessorName 

ProcessorName::ProcessorName()
  //## begin ProcessorName::ProcessorName%54AF8BB30160_const.hasinit preserve=no
  //## end ProcessorName::ProcessorName%54AF8BB30160_const.hasinit
  //## begin ProcessorName::ProcessorName%54AF8BB30160_const.initialization preserve=yes
   : ConversionItem("## CR101 PROCESS NAME TO PROCGRP")
  //## end ProcessorName::ProcessorName%54AF8BB30160_const.initialization
{
  //## begin configuration::ProcessorName::ProcessorName%54AF8BB30160_const.body preserve=yes
    memcpy(m_sID,"CFA3",4);
  //## end configuration::ProcessorName::ProcessorName%54AF8BB30160_const.body
}


ProcessorName::~ProcessorName()
{
  //## begin configuration::ProcessorName::~ProcessorName%54AF8BB30160_dest.body preserve=yes
  //## end configuration::ProcessorName::~ProcessorName%54AF8BB30160_dest.body
}



//## Other Operations (implementation)
void ProcessorName::bind (Query& hQuery)
{
  //## begin configuration::ProcessorName::bind%54AF9DD20095.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","PROCESSOR");
   hQuery.bind("PROCESSOR","PROCESS_NAME",Column::STRING,&m_strFirst);
   hQuery.bind("PROCESSOR","PROC_GRP_ID",Column::STRING,&m_strSecond);         
   hQuery.setBasicPredicate("PROCESSOR","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("PROCESSOR","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("PROCESSOR","CUST_ID","IN",strTemp.c_str());
   hQuery.setBasicPredicate("PROCESSOR","PROC_GRP_ID","<>"," ");
   hQuery.setBasicPredicate("PROCESSOR","PROCESS_NAME","<>"," ");
   hQuery.setOrderByClause("PROCESSOR.PROCESS_NAME ASC,PROCESSOR.CUST_ID ASC");
  //## end configuration::ProcessorName::bind%54AF9DD20095.body
}

void ProcessorName::setPredicate (Query& hQuery)
{
  //## begin configuration::ProcessorName::setPredicate%5847187B0317.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setBasicPredicate("PROCESSOR", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("PROCESSOR", "CC_STATE", "=", "A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("PROCESSOR", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setBasicPredicate("PROCESSOR", "PROC_GRP_ID", "<>", " ");
   hQuery.setBasicPredicate("PROCESSOR", "PROCESS_NAME", "<>", " ");
  //## end configuration::ProcessorName::setPredicate%5847187B0317.body
}

// Additional Declarations
  //## begin configuration::ProcessorName%54AF8BB30160.declarations preserve=yes
  //## end configuration::ProcessorName%54AF8BB30160.declarations

} // namespace configuration

//## begin module%54AD2EC601D9.epilog preserve=yes
//## end module%54AD2EC601D9.epilog
