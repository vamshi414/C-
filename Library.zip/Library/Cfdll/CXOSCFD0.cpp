//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%629681BC0096.cm preserve=no
//## end module%629681BC0096.cm

//## begin module%629681BC0096.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%629681BC0096.cp

//## Module: CXOSCFD0%629681BC0096; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFD0.cpp

//## begin module%629681BC0096.additionalIncludes preserve=no
//## end module%629681BC0096.additionalIncludes

//## begin module%629681BC0096.includes preserve=yes
//## end module%629681BC0096.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFD0_h
#include "CXODCFD0.hpp"
#endif


//## begin module%629681BC0096.declarations preserve=no
//## end module%629681BC0096.declarations

//## begin module%629681BC0096.additionalDeclarations preserve=yes
//## end module%629681BC0096.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::SchemeFunding 

SchemeFunding::SchemeFunding()
  //## begin SchemeFunding::SchemeFunding%629681010173_const.hasinit preserve=no
  //## end SchemeFunding::SchemeFunding%629681010173_const.hasinit
  //## begin SchemeFunding::SchemeFunding%629681010173_const.initialization preserve=yes
   : ConversionItem("## CFD0 XLATE SCHEME FUNDING")
  //## end SchemeFunding::SchemeFunding%629681010173_const.initialization
{
  //## begin configuration::SchemeFunding::SchemeFunding%629681010173_const.body preserve=yes
   memcpy(m_sID,"CFD0",4);
  //## end configuration::SchemeFunding::SchemeFunding%629681010173_const.body
}


SchemeFunding::~SchemeFunding()
{
  //## begin configuration::SchemeFunding::~SchemeFunding%629681010173_dest.body preserve=yes
  //## end configuration::SchemeFunding::~SchemeFunding%629681010173_dest.body
}



//## Other Operations (implementation)
void SchemeFunding::bind (Query& hQuery)
{
  //## begin configuration::SchemeFunding::bind%629681470196.body preserve=yes
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.setQualifier("QUALIFY","X_SCHEME_FUNDING");
   hQuery.bind("X_SCHEME_FUNDING","COUNTRY_ACQ_INST",Column::STRING,&m_strFirst);
   hQuery.bind("X_SCHEME_FUNDING","CUR_TRAN",Column::STRING,&m_strCUR_TRAN);
   hQuery.bind("X_SCHEME_FUNDING","COUNTRY_ISS_INST",Column::STRING,&m_strCOUNTRY_ISS_INST);
   hQuery.bind("X_SCHEME_FUNDING","NET_ID",Column::STRING,&m_strNET_ID);
   hQuery.bind("X_SCHEME_FUNDING","ACQUIRER_BIN",Column::STRING,&m_strPAN_PREFIX);
   hQuery.bind("X_SCHEME_FUNDING","ISSUER_BIN",Column::STRING,&m_strISSUER_BIN);
   hQuery.bind("X_SCHEME_FUNDING","NET_INST_ID_CODE",Column::STRING,&m_strSecond);
   hQuery.bind("X_SCHEME_FUNDING","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_SCHEME_FUNDING","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_SCHEME_FUNDING","CC_STATE","=","A");
   string strTemp = "('" + strCUST_ID + "','****')";
   hQuery.setBasicPredicate("X_SCHEME_FUNDING","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("COUNTRY_ACQ_INST,CUR_TRAN,COUNTRY_ISS_INST,NET_ID,ACQUIRER_BIN,ISSUER_BIN");
  //## end configuration::SchemeFunding::bind%629681470196.body
}

const string& SchemeFunding::getFirst ()
{
  //## begin configuration::SchemeFunding::getFirst%6296814B007B.body preserve=yes
   m_strFirst += m_strCUR_TRAN;
   m_strFirst += m_strCOUNTRY_ISS_INST;
   m_strFirst += m_strNET_ID;
   m_strFirst += m_strPAN_PREFIX;
   m_strFirst += m_strISSUER_BIN;
   return m_strFirst;
  //## end configuration::SchemeFunding::getFirst%6296814B007B.body
}

// Additional Declarations
  //## begin configuration::SchemeFunding%629681010173.declarations preserve=yes
  //## end configuration::SchemeFunding%629681010173.declarations

} // namespace configuration

//## begin module%629681BC0096.epilog preserve=yes
//## end module%629681BC0096.epilog
