//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4263E2E10222.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%4263E2E10222.cm

//## begin module%4263E2E10222.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%4263E2E10222.cp

//## Module: CXOSCF77%4263E2E10222; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF77.hpp

#ifndef CXOSCF77_h
#define CXOSCF77_h 1

//## begin module%4263E2E10222.additionalIncludes preserve=no
//## end module%4263E2E10222.additionalIncludes

//## begin module%4263E2E10222.includes preserve=yes
//## end module%4263E2E10222.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%4263E2E10222.declarations preserve=no
//## end module%4263E2E10222.declarations

//## begin module%4263E2E10222.additionalDeclarations preserve=yes
//## end module%4263E2E10222.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::OasisPCode%4263E29A0399.preface preserve=yes
//## end configuration::OasisPCode%4263E29A0399.preface

//## Class: OasisPCode%4263E29A0399
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4263E2B70177;reusable::Query { -> F}
//## Uses: <unnamed>%4263E2B9032C;IF::Extract { -> F}

class DllExport OasisPCode : public ConversionItem  //## Inherits: <unnamed>%4263E2B501A5
{
  //## begin configuration::OasisPCode%4263E29A0399.initialDeclarations preserve=yes
  //## end configuration::OasisPCode%4263E29A0399.initialDeclarations

  public:
    //## Constructors (generated)
      OasisPCode();

    //## Destructor (generated)
      virtual ~OasisPCode();


    //## Other Operations (specified)
      //## Operation: bind%4263E33D008C
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getSecond%42AA018803C8
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::OasisPCode%4263E29A0399.public preserve=yes
      //## end configuration::OasisPCode%4263E29A0399.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::OasisPCode%4263E29A0399.protected preserve=yes
      //## end configuration::OasisPCode%4263E29A0399.protected

  private:
    // Additional Private Declarations
      //## begin configuration::OasisPCode%4263E29A0399.private preserve=yes
      //## end configuration::OasisPCode%4263E29A0399.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: PROCESS_CODE%42AA01E302DE
      //## begin configuration::OasisPCode::PROCESS_CODE%42AA01E302DE.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::OasisPCode::PROCESS_CODE%42AA01E302DE.attr

      //## Attribute: MSG_CLASS%42AA01E302DF
      //## begin configuration::OasisPCode::MSG_CLASS%42AA01E302DF.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::OasisPCode::MSG_CLASS%42AA01E302DF.attr

      //## Attribute: PRE_AUTH%42AA01E302EE
      //## begin configuration::OasisPCode::PRE_AUTH%42AA01E302EE.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::OasisPCode::PRE_AUTH%42AA01E302EE.attr

      //## Attribute: MEDIA_TYPE%42AA01E302EF
      //## begin configuration::OasisPCode::MEDIA_TYPE%42AA01E302EF.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::OasisPCode::MEDIA_TYPE%42AA01E302EF.attr

    // Additional Implementation Declarations
      //## begin configuration::OasisPCode%4263E29A0399.implementation preserve=yes
      //## end configuration::OasisPCode%4263E29A0399.implementation

};

//## begin configuration::OasisPCode%4263E29A0399.postscript preserve=yes
//## end configuration::OasisPCode%4263E29A0399.postscript

} // namespace configuration

//## begin module%4263E2E10222.epilog preserve=yes
//## end module%4263E2E10222.epilog


#endif
