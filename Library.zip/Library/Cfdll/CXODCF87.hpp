//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%44A3C2A301E4.cm preserve=no
//	$Date:   Jul 12 2006 07:07:48  $ $Author:   D99663  $
//	$Revision:   1.0  $
//## end module%44A3C2A301E4.cm

//## begin module%44A3C2A301E4.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%44A3C2A301E4.cp

//## Module: CXOSCF87%44A3C2A301E4; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF87.hpp

#ifndef CXOSCF87_h
#define CXOSCF87_h 1

//## begin module%44A3C2A301E4.additionalIncludes preserve=no
//## end module%44A3C2A301E4.additionalIncludes

//## begin module%44A3C2A301E4.includes preserve=yes
//## end module%44A3C2A301E4.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%44A3C2A301E4.declarations preserve=no
//## end module%44A3C2A301E4.declarations

//## begin module%44A3C2A301E4.additionalDeclarations preserve=yes
//## end module%44A3C2A301E4.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::OasisNetwork%44A2E54000FA.preface preserve=yes
//## end configuration::OasisNetwork%44A2E54000FA.preface

//## Class: OasisNetwork%44A2E54000FA
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%44A3C39402CE;IF::Extract { -> F}
//## Uses: <unnamed>%44A3C397006D;reusable::Query { -> F}

class DllExport OasisNetwork : public ConversionItem  //## Inherits: <unnamed>%44A3C35C00DA
{
  //## begin configuration::OasisNetwork%44A2E54000FA.initialDeclarations preserve=yes
  //## end configuration::OasisNetwork%44A2E54000FA.initialDeclarations

  public:
    //## Constructors (generated)
      OasisNetwork();

    //## Destructor (generated)
      virtual ~OasisNetwork();


    //## Other Operations (specified)
      //## Operation: bind%44A3C3A60203
      virtual void bind (reusable::Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::OasisNetwork%44A2E54000FA.public preserve=yes
      //## end configuration::OasisNetwork%44A2E54000FA.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::OasisNetwork%44A2E54000FA.protected preserve=yes
      //## end configuration::OasisNetwork%44A2E54000FA.protected

  private:
    // Additional Private Declarations
      //## begin configuration::OasisNetwork%44A2E54000FA.private preserve=yes
      //## end configuration::OasisNetwork%44A2E54000FA.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::OasisNetwork%44A2E54000FA.implementation preserve=yes
      //## end configuration::OasisNetwork%44A2E54000FA.implementation

};

//## begin configuration::OasisNetwork%44A2E54000FA.postscript preserve=yes
//## end configuration::OasisNetwork%44A2E54000FA.postscript

} // namespace configuration

//## begin module%44A3C2A301E4.epilog preserve=yes
//## end module%44A3C2A301E4.epilog


#endif
