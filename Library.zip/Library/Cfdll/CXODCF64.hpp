//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40A51C2602FD.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40A51C2602FD.cm

//## begin module%40A51C2602FD.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40A51C2602FD.cp

//## Module: CXOSCF64%40A51C2602FD; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF64.hpp

#ifndef CXOSCF64_h
#define CXOSCF64_h 1

//## begin module%40A51C2602FD.additionalIncludes preserve=no
//## end module%40A51C2602FD.additionalIncludes

//## begin module%40A51C2602FD.includes preserve=yes
// $Date:   Jun 11 2004 11:49:18  $ $Author:   D92233  $ $Revision:   1.2  $
//## end module%40A51C2602FD.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;

} // namespace IF

//## begin module%40A51C2602FD.declarations preserve=no
//## end module%40A51C2602FD.declarations

//## begin module%40A51C2602FD.additionalDeclarations preserve=yes
#include <map>
//## end module%40A51C2602FD.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ImportMapItem%40A384F80128.preface preserve=yes
//## end configuration::ImportMapItem%40A384F80128.preface

//## Class: ImportMapItem%40A384F80128
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40AA3124002E;IF::Trace { -> F}

class DllExport ImportMapItem : public reusable::Object  //## Inherits: <unnamed>%40A387AD0119
{
  //## begin configuration::ImportMapItem%40A384F80128.initialDeclarations preserve=yes
  //## end configuration::ImportMapItem%40A384F80128.initialDeclarations

  public:
    //## Constructors (generated)
      ImportMapItem();

    //## Constructors (specified)
      //## Operation: ImportMapItem%40A5284A0271
      ImportMapItem (const char* pszTemplate);

    //## Destructor (generated)
      virtual ~ImportMapItem();


    //## Other Operations (specified)
      //## Operation: loadDataMap%40A51F43003E
      virtual bool loadDataMap ();

      //## Operation: findTarget%40A92075035B
      bool findTarget (string& strTokenID, string& strTarget);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Member%40A527E2004E
      const string& getMember () const
      {
        //## begin configuration::ImportMapItem::getMember%40A527E2004E.get preserve=no
        return m_strMember;
        //## end configuration::ImportMapItem::getMember%40A527E2004E.get
      }


      //## Attribute: Template%40AB9232002E
      const string& getTemplate () const
      {
        //## begin configuration::ImportMapItem::getTemplate%40AB9232002E.get preserve=no
        return m_strTemplate;
        //## end configuration::ImportMapItem::getTemplate%40AB9232002E.get
      }


    // Additional Public Declarations
      //## begin configuration::ImportMapItem%40A384F80128.public preserve=yes
      //## end configuration::ImportMapItem%40A384F80128.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: DataMap%40A515AE00BB
      //## begin configuration::ImportMapItem::DataMap%40A515AE00BB.attr preserve=no  private: map<string,string, less<string> > {U} 
      map<string,string, less<string> > m_hDataMap;
      //## end configuration::ImportMapItem::DataMap%40A515AE00BB.attr

    // Additional Protected Declarations
      //## begin configuration::ImportMapItem%40A384F80128.protected preserve=yes
      //## end configuration::ImportMapItem%40A384F80128.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ImportMapItem%40A384F80128.private preserve=yes
      //## end configuration::ImportMapItem%40A384F80128.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin configuration::ImportMapItem::Member%40A527E2004E.attr preserve=no  public: string {U} 
      string m_strMember;
      //## end configuration::ImportMapItem::Member%40A527E2004E.attr

      //## begin configuration::ImportMapItem::Template%40AB9232002E.attr preserve=no  public: string {U} 
      string m_strTemplate;
      //## end configuration::ImportMapItem::Template%40AB9232002E.attr

    // Additional Implementation Declarations
      //## begin configuration::ImportMapItem%40A384F80128.implementation preserve=yes
      //## end configuration::ImportMapItem%40A384F80128.implementation

};

//## begin configuration::ImportMapItem%40A384F80128.postscript preserve=yes
//## end configuration::ImportMapItem%40A384F80128.postscript

} // namespace configuration

//## begin module%40A51C2602FD.epilog preserve=yes
using namespace configuration;
//## end module%40A51C2602FD.epilog


#endif
