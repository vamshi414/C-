//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%391C0E350108.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%391C0E350108.cm

//## begin module%391C0E350108.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%391C0E350108.cp

//## Module: CXOSCF22%391C0E350108; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF22.cpp

//## begin module%391C0E350108.additionalIncludes preserve=no
//## end module%391C0E350108.additionalIncludes

//## begin module%391C0E350108.includes preserve=yes
// $Date:   Apr 17 2014 20:59:26  $ $Author:   e1009652  $ $Revision:   1.8  $
//## end module%391C0E350108.includes

#ifndef CXOSCF22_h
#include "CXODCF22.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%391C0E350108.declarations preserve=no
//## end module%391C0E350108.declarations

//## begin module%391C0E350108.additionalDeclarations preserve=yes
//## end module%391C0E350108.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::OnlineNetwork

OnlineNetwork::OnlineNetwork()
  //## begin OnlineNetwork::OnlineNetwork%391C0CE800A5_const.hasinit preserve=no
  //## end OnlineNetwork::OnlineNetwork%391C0CE800A5_const.hasinit
  //## begin OnlineNetwork::OnlineNetwork%391C0CE800A5_const.initialization preserve=yes
   : ConversionItem("## CR25 XLATE NETWORK ID")
  //## end OnlineNetwork::OnlineNetwork%391C0CE800A5_const.initialization
{
  //## begin configuration::OnlineNetwork::OnlineNetwork%391C0CE800A5_const.body preserve=yes
   memcpy(m_sID,"CF22",4);
  //## end configuration::OnlineNetwork::OnlineNetwork%391C0CE800A5_const.body
}


OnlineNetwork::~OnlineNetwork()
{
  //## begin configuration::OnlineNetwork::~OnlineNetwork%391C0CE800A5_dest.body preserve=yes
  //## end configuration::OnlineNetwork::~OnlineNetwork%391C0CE800A5_dest.body
}



//## Other Operations (implementation)
void OnlineNetwork::bind (Query& hQuery)
{
  //## begin configuration::OnlineNetwork::bind%391C1C190043.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","ONLINE_NETWORK");
   hQuery.bind("ONLINE_NETWORK","NETWORK_ID",Column::STRING,&m_strFirst);
   hQuery.bind("ONLINE_NETWORK","REIMB_ATTR_FLG",Column::STRING,&m_strSecond);
   // hQuery.setBasicPredicate("ONLINE_NETWORK","CUST_ID","=",strCustomerID.c_str());
   hQuery.bind("ONLINE_NETWORK","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("ONLINE_NETWORK","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("ONLINE_NETWORK","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("ONLINE_NETWORK","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("ONLINE_NETWORK.NETWORK_ID ASC,ONLINE_NETWORK.CUST_ID DESC");
  //## end configuration::OnlineNetwork::bind%391C1C190043.body
}

// Additional Declarations
  //## begin configuration::OnlineNetwork%391C0CE800A5.declarations preserve=yes
  //## end configuration::OnlineNetwork%391C0CE800A5.declarations

} // namespace configuration

//## begin module%391C0E350108.epilog preserve=yes
//## end module%391C0E350108.epilog
