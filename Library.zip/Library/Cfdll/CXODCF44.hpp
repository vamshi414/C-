//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3AD3107B00C8.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3AD3107B00C8.cm

//## begin module%3AD3107B00C8.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3AD3107B00C8.cp

//## Module: CXOSCF44%3AD3107B00C8; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF44.hpp

#ifndef CXOSCF44_h
#define CXOSCF44_h 1

//## begin module%3AD3107B00C8.additionalIncludes preserve=no
//## end module%3AD3107B00C8.additionalIncludes

//## begin module%3AD3107B00C8.includes preserve=yes
// $Date:   Apr 08 2004 14:11:02  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%3AD3107B00C8.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%3AD3107B00C8.declarations preserve=no
//## end module%3AD3107B00C8.declarations

//## begin module%3AD3107B00C8.additionalDeclarations preserve=yes
//## end module%3AD3107B00C8.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::MapData%3AD30F9E02D3.preface preserve=yes
//## end configuration::MapData%3AD30F9E02D3.preface

//## Class: MapData%3AD30F9E02D3
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class DllExport MapData : public reusable::Object  //## Inherits: <unnamed>%3AD30FF2014D
{
  //## begin configuration::MapData%3AD30F9E02D3.initialDeclarations preserve=yes
  //## end configuration::MapData%3AD30F9E02D3.initialDeclarations

  public:
    //## Constructors (generated)
      MapData();

      MapData(const MapData &right);

    //## Destructor (generated)
      virtual ~MapData();

    //## Assignment Operation (generated)
      MapData & operator=(const MapData &right);

    //## Equality Operations (generated)
      bool operator==(const MapData &right) const;

      bool operator!=(const MapData &right) const;

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Primary%3AD3132D0391
      const string& getPrimary () const
      {
        //## begin configuration::MapData::getPrimary%3AD3132D0391.get preserve=no
        return m_strPrimary;
        //## end configuration::MapData::getPrimary%3AD3132D0391.get
      }

      void setPrimary (const string& value)
      {
        //## begin configuration::MapData::setPrimary%3AD3132D0391.set preserve=no
        m_strPrimary = value;
        //## end configuration::MapData::setPrimary%3AD3132D0391.set
      }


      //## Attribute: Secondary%3AD3133E03BE
      const string& getSecondary () const
      {
        //## begin configuration::MapData::getSecondary%3AD3133E03BE.get preserve=no
        return m_strSecondary;
        //## end configuration::MapData::getSecondary%3AD3133E03BE.get
      }

      void setSecondary (const string& value)
      {
        //## begin configuration::MapData::setSecondary%3AD3133E03BE.set preserve=no
        m_strSecondary = value;
        //## end configuration::MapData::setSecondary%3AD3133E03BE.set
      }


      //## Attribute: Tertiary%3AD3134603BF
      const string& getTertiary () const
      {
        //## begin configuration::MapData::getTertiary%3AD3134603BF.get preserve=no
        return m_strTertiary;
        //## end configuration::MapData::getTertiary%3AD3134603BF.get
      }

      void setTertiary (const string& value)
      {
        //## begin configuration::MapData::setTertiary%3AD3134603BF.set preserve=no
        m_strTertiary = value;
        //## end configuration::MapData::setTertiary%3AD3134603BF.set
      }


      //## Attribute: Result%3AD3135D0065
      const string& getResult () const
      {
        //## begin configuration::MapData::getResult%3AD3135D0065.get preserve=no
        return m_strResult;
        //## end configuration::MapData::getResult%3AD3135D0065.get
      }

      void setResult (const string& value)
      {
        //## begin configuration::MapData::setResult%3AD3135D0065.set preserve=no
        m_strResult = value;
        //## end configuration::MapData::setResult%3AD3135D0065.set
      }


    // Additional Public Declarations
      //## begin configuration::MapData%3AD30F9E02D3.public preserve=yes
      //## end configuration::MapData%3AD30F9E02D3.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::MapData%3AD30F9E02D3.protected preserve=yes
      //## end configuration::MapData%3AD30F9E02D3.protected

  private:
    // Additional Private Declarations
      //## begin configuration::MapData%3AD30F9E02D3.private preserve=yes
      //## end configuration::MapData%3AD30F9E02D3.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin configuration::MapData::Primary%3AD3132D0391.attr preserve=no  public: string {U} 
      string m_strPrimary;
      //## end configuration::MapData::Primary%3AD3132D0391.attr

      //## begin configuration::MapData::Secondary%3AD3133E03BE.attr preserve=no  public: string {U} 
      string m_strSecondary;
      //## end configuration::MapData::Secondary%3AD3133E03BE.attr

      //## begin configuration::MapData::Tertiary%3AD3134603BF.attr preserve=no  public: string {U} 
      string m_strTertiary;
      //## end configuration::MapData::Tertiary%3AD3134603BF.attr

      //## begin configuration::MapData::Result%3AD3135D0065.attr preserve=no  public: string {U} 
      string m_strResult;
      //## end configuration::MapData::Result%3AD3135D0065.attr

    // Additional Implementation Declarations
      //## begin configuration::MapData%3AD30F9E02D3.implementation preserve=yes
      //## end configuration::MapData%3AD30F9E02D3.implementation

};

//## begin configuration::MapData%3AD30F9E02D3.postscript preserve=yes
//## end configuration::MapData%3AD30F9E02D3.postscript

} // namespace configuration

//## begin module%3AD3107B00C8.epilog preserve=yes
using namespace configuration;
//## end module%3AD3107B00C8.epilog


#endif
