//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%48298BE9031C.cm preserve=no
//	$Date:   May 22 2008 14:34:04  $ $Author:   D09372  $
//	$Revision:   1.0  $
//## end module%48298BE9031C.cm

//## begin module%48298BE9031C.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%48298BE9031C.cp

//## Module: CXOSCF96%48298BE9031C; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF96.hpp

#ifndef CXOSCF96_h
#define CXOSCF96_h 1

//## begin module%48298BE9031C.additionalIncludes preserve=no
//## end module%48298BE9031C.additionalIncludes

//## begin module%48298BE9031C.includes preserve=yes
//## end module%48298BE9031C.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%48298BE9031C.declarations preserve=no
//## end module%48298BE9031C.declarations

//## begin module%48298BE9031C.additionalDeclarations preserve=yes
//## end module%48298BE9031C.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::PulseProcessCodeRev%48298AE400DA.preface preserve=yes
//## end configuration::PulseProcessCodeRev%48298AE400DA.preface

//## Class: PulseProcessCodeRev%48298AE400DA
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%48298B2E007D;IF::Extract { -> F}
//## Uses: <unnamed>%48298B3D008C;reusable::Query { -> F}

class DllExport PulseProcessCodeRev : public ConversionItem  //## Inherits: <unnamed>%48298B06008C
{
  //## begin configuration::PulseProcessCodeRev%48298AE400DA.initialDeclarations preserve=yes
  //## end configuration::PulseProcessCodeRev%48298AE400DA.initialDeclarations

  public:
    //## Constructors (generated)
      PulseProcessCodeRev();

    //## Destructor (generated)
      virtual ~PulseProcessCodeRev();


    //## Other Operations (specified)
      //## Operation: bind%48298CF30128
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getFirst%48298CF603A9
      virtual const string& getFirst ();

    // Additional Public Declarations
      //## begin configuration::PulseProcessCodeRev%48298AE400DA.public preserve=yes
      //## end configuration::PulseProcessCodeRev%48298AE400DA.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::PulseProcessCodeRev%48298AE400DA.protected preserve=yes
      //## end configuration::PulseProcessCodeRev%48298AE400DA.protected

  private:
    // Additional Private Declarations
      //## begin configuration::PulseProcessCodeRev%48298AE400DA.private preserve=yes
      //## end configuration::PulseProcessCodeRev%48298AE400DA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: MEDIA_TYPE%48298C6C02FD
      //## begin configuration::PulseProcessCodeRev::MEDIA_TYPE%48298C6C02FD.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::PulseProcessCodeRev::MEDIA_TYPE%48298C6C02FD.attr

      //## Attribute: MSG_CLASS%48298C700222
      //## begin configuration::PulseProcessCodeRev::MSG_CLASS%48298C700222.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::PulseProcessCodeRev::MSG_CLASS%48298C700222.attr

      //## Attribute: PRE_AUTH%48298C740222
      //## begin configuration::PulseProcessCodeRev::PRE_AUTH%48298C740222.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::PulseProcessCodeRev::PRE_AUTH%48298C740222.attr

      //## Attribute: PROCESS_CODE%48298C810109
      //## begin configuration::PulseProcessCodeRev::PROCESS_CODE%48298C810109.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::PulseProcessCodeRev::PROCESS_CODE%48298C810109.attr

      //## Attribute: STAR_TRAN_TYPE%48298C8B02BF
      //## begin configuration::PulseProcessCodeRev::STAR_TRAN_TYPE%48298C8B02BF.attr preserve=no  private: string {U} 
      string m_pSTAR_TRAN_TYPE;
      //## end configuration::PulseProcessCodeRev::STAR_TRAN_TYPE%48298C8B02BF.attr

    // Additional Implementation Declarations
      //## begin configuration::PulseProcessCodeRev%48298AE400DA.implementation preserve=yes
      //## end configuration::PulseProcessCodeRev%48298AE400DA.implementation

};

//## begin configuration::PulseProcessCodeRev%48298AE400DA.postscript preserve=yes
//## end configuration::PulseProcessCodeRev%48298AE400DA.postscript

} // namespace configuration

//## begin module%48298BE9031C.epilog preserve=yes
//## end module%48298BE9031C.epilog


#endif
