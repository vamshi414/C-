//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5FC5DFDC0252.cm preserve=no
//	$Date:   Sep 06 2021 04:45:58  $ $Author:   e3028298  $
//	$Revision:   1.1  $
//## end module%5FC5DFDC0252.cm

//## begin module%5FC5DFDC0252.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5FC5DFDC0252.cp

//## Module: CXOSCFB8%5FC5DFDC0252; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Devel\V03.2A.R003\Dn\Server\Library\Cfdll\CXOSCFB8.cpp

//## begin module%5FC5DFDC0252.additionalIncludes preserve=no
//## end module%5FC5DFDC0252.additionalIncludes

//## begin module%5FC5DFDC0252.includes preserve=yes
//## end module%5FC5DFDC0252.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCFB8_h
#include "CXODCFB8.hpp"
#endif


//## begin module%5FC5DFDC0252.declarations preserve=no
//## end module%5FC5DFDC0252.declarations

//## begin module%5FC5DFDC0252.additionalDeclarations preserve=yes
//## end module%5FC5DFDC0252.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::QMRAcquirer 

QMRAcquirer::QMRAcquirer()
  //## begin QMRAcquirer::QMRAcquirer%5FC5E0C000E8_const.hasinit preserve=no
  //## end QMRAcquirer::QMRAcquirer%5FC5E0C000E8_const.hasinit
  //## begin QMRAcquirer::QMRAcquirer%5FC5E0C000E8_const.initialization preserve=yes
  //## end QMRAcquirer::QMRAcquirer%5FC5E0C000E8_const.initialization
{
  //## begin configuration::QMRAcquirer::QMRAcquirer%5FC5E0C000E8_const.body preserve=yes
  //## end configuration::QMRAcquirer::QMRAcquirer%5FC5E0C000E8_const.body
}


QMRAcquirer::~QMRAcquirer()
{
  //## begin configuration::QMRAcquirer::~QMRAcquirer%5FC5E0C000E8_dest.body preserve=yes
  //## end configuration::QMRAcquirer::~QMRAcquirer%5FC5E0C000E8_dest.body
}



//## Other Operations (implementation)
void QMRAcquirer::bind (Query& hQuery)
{
  //## begin configuration::QMRAcquirer::bind%5FC5E19101AD.body preserve=yes
   hQuery.setQualifier("QUALIFY", "QMR_ACQUIRER_BIN");
   hQuery.bind("QMR_ACQUIRER_BIN", "BIN", Column::STRING, &m_strFirst);
   hQuery.bind("QMR_ACQUIRER_BIN", "NETWORK_ID", Column::STRING, &m_strSecond);
   hQuery.bind("QMR_ACQUIRER_BIN", "BIN_TYPE", Column::STRING, &m_strBIN_TYPE);
   hQuery.bind("QMR_ACQUIRER_BIN", "MAESTRO_LOGO", Column::STRING, &m_strMAESTRO_LOGO);
   hQuery.bind("QMR_ACQUIRER_BIN", "MASTERCARD_LOGO", Column::STRING, &m_strMASTERCARD_LOGO);
   hQuery.bind("QMR_ACQUIRER_BIN", "CIRRUS_LOGO", Column::STRING, &m_strCIRRUS_LOGO);
   hQuery.bind("QMR_ACQUIRER_BIN", "VISA_LOGO", Column::STRING, &m_strVISA_LOGO);
   hQuery.bind("QMR_ACQUIRER_BIN", "INTERLINK_LOGO", Column::STRING, &m_strINTERLINK_LOGO);
   hQuery.bind("QMR_ACQUIRER_BIN", "PLUS_LOGO", Column::STRING, &m_strPLUS_LOGO);
   hQuery.bind("QMR_ACQUIRER_BIN", "CARD_BRAND", Column::STRING, &m_strCARD_BRAND);
   hQuery.setBasicPredicate("QMR_ACQUIRER_BIN", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("QMR_ACQUIRER_BIN", "CC_STATE", "=", "A");
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER", strCUST_ID);
   string strTemp = "('" + strCUST_ID + "','****')";
   hQuery.setBasicPredicate("QMR_ACQUIRER_BIN", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("BIN ASC,CUST_ID DESC");
  //## end configuration::QMRAcquirer::bind%5FC5E19101AD.body
}

bool QMRAcquirer::getBinDetails (const string& strBIN, int&  iLength, string& strNET_ID)
{
  //## begin configuration::QMRAcquirer::getBinDetails%5FC5E711003E.body preserve=yes
   string strFirst(strBIN);
   strFirst.resize(12, ' ');
   iLength = 11;
   while (strFirst.length() > 6)
   {
      strFirst.resize(strFirst.length() - 1);
      if (ConfigurationRepository::instance()->translate("QMR_ACQUIRER_BIN", strFirst, strNET_ID, " ", " ", 0, false))
         return true;
      iLength--;
   }
   iLength = 11;
   return false;
  //## end configuration::QMRAcquirer::getBinDetails%5FC5E711003E.body
}

const string& QMRAcquirer::getThird ()
{
  //## begin configuration::QMRAcquirer::getThird%5FC5E7C3005D.body preserve=yes
   m_strThird.assign(m_strCARD_BRAND);
   m_strThird.resize(3, ' ');
   m_strThird.append(m_strMAESTRO_LOGO);
   m_strThird.resize(4, ' ');
   m_strThird.append(m_strMASTERCARD_LOGO);
   m_strThird.resize(5, ' ');
   m_strThird.append(m_strCIRRUS_LOGO);
   m_strThird.resize(6, ' ');
   m_strThird.append(m_strVISA_LOGO);
   m_strThird.resize(7, ' ');
   m_strThird.append(m_strINTERLINK_LOGO);
   m_strThird.resize(8, ' ');
   m_strThird.append(m_strPLUS_LOGO);
   m_strThird.resize(9, ' ');
   m_strThird.append(m_strBIN_TYPE);
   m_strThird.resize(10, ' ');
   return m_strThird;
  //## end configuration::QMRAcquirer::getThird%5FC5E7C3005D.body
}

// Additional Declarations
  //## begin configuration::QMRAcquirer%5FC5E0C000E8.declarations preserve=yes
  //## end configuration::QMRAcquirer%5FC5E0C000E8.declarations

} // namespace configuration

//## begin module%5FC5DFDC0252.epilog preserve=yes
//## end module%5FC5DFDC0252.epilog
