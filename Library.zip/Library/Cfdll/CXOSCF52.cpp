//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFC3D70002E.cm preserve=no
//	$Date:   Dec 16 2016 15:21:28  $ $Author:   e1009652  $
//	$Revision:   1.4  $
//## end module%3FFC3D70002E.cm

//## begin module%3FFC3D70002E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFC3D70002E.cp

//## Module: CXOSCF52%3FFC3D70002E; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF52.cpp

//## begin module%3FFC3D70002E.additionalIncludes preserve=no
//## end module%3FFC3D70002E.additionalIncludes

//## begin module%3FFC3D70002E.includes preserve=yes
// $Date:   Dec 16 2016 15:21:28  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%3FFC3D70002E.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF52_h
#include "CXODCF52.hpp"
#endif
//## begin module%3FFC3D70002E.declarations preserve=no
//## end module%3FFC3D70002E.declarations

//## begin module%3FFC3D70002E.additionalDeclarations preserve=yes
//## end module%3FFC3D70002E.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexPOSConditionCode3 

ConnexPOSConditionCode3::ConnexPOSConditionCode3()
  //## begin ConnexPOSConditionCode3::ConnexPOSConditionCode3%3FFC3BED0157_const.hasinit preserve=no
  //## end ConnexPOSConditionCode3::ConnexPOSConditionCode3%3FFC3BED0157_const.hasinit
  //## begin ConnexPOSConditionCode3::ConnexPOSConditionCode3%3FFC3BED0157_const.initialization preserve=yes
   : ConversionItem("## CR64 XLATE POS CON COD3")
  //## end ConnexPOSConditionCode3::ConnexPOSConditionCode3%3FFC3BED0157_const.initialization
{
  //## begin configuration::ConnexPOSConditionCode3::ConnexPOSConditionCode3%3FFC3BED0157_const.body preserve=yes
   memcpy(m_sID,"CF52",4);
  //## end configuration::ConnexPOSConditionCode3::ConnexPOSConditionCode3%3FFC3BED0157_const.body
}


ConnexPOSConditionCode3::~ConnexPOSConditionCode3()
{
  //## begin configuration::ConnexPOSConditionCode3::~ConnexPOSConditionCode3%3FFC3BED0157_dest.body preserve=yes
  //## end configuration::ConnexPOSConditionCode3::~ConnexPOSConditionCode3%3FFC3BED0157_dest.body
}



//## Other Operations (implementation)
void ConnexPOSConditionCode3::bind (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode3::bind%3FFC3C51009C.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_IBM_POS_COND_COD");
   hQuery.bind("X_IBM_POS_COND_COD","POS_COND_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_POS_COND_COD","POS_CARD_PRES",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IBM_POS_COND_COD.POS_COND_CODE ASC");
  //## end configuration::ConnexPOSConditionCode3::bind%3FFC3C51009C.body
}

void ConnexPOSConditionCode3::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode3::setPredicate%5847162201FB.body preserve=yes
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_STATE", "=", "A");
  //## end configuration::ConnexPOSConditionCode3::setPredicate%5847162201FB.body
}

// Additional Declarations
  //## begin configuration::ConnexPOSConditionCode3%3FFC3BED0157.declarations preserve=yes
  //## end configuration::ConnexPOSConditionCode3%3FFC3BED0157.declarations

} // namespace configuration

//## begin module%3FFC3D70002E.epilog preserve=yes
//## end module%3FFC3D70002E.epilog
