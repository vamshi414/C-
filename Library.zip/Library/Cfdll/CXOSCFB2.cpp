//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5CF7CA0D02D7.cm preserve=no
//	$Date:   Jun 06 2019 14:02:46  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5CF7CA0D02D7.cm

//## begin module%5CF7CA0D02D7.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5CF7CA0D02D7.cp

//## Module: CXOSCFB2%5CF7CA0D02D7; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV03.0A.R002\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFB2.cpp

//## begin module%5CF7CA0D02D7.additionalIncludes preserve=no
//## end module%5CF7CA0D02D7.additionalIncludes

//## begin module%5CF7CA0D02D7.includes preserve=yes
//## end module%5CF7CA0D02D7.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSCFB2_h
#include "CXODCFB2.hpp"
#endif


//## begin module%5CF7CA0D02D7.declarations preserve=no
//## end module%5CF7CA0D02D7.declarations

//## begin module%5CF7CA0D02D7.additionalDeclarations preserve=yes
//## end module%5CF7CA0D02D7.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::CurrencyCodeReverse 

CurrencyCodeReverse::CurrencyCodeReverse()
  //## begin CurrencyCodeReverse::CurrencyCodeReverse%5CF7C71E030A_const.hasinit preserve=no
  //## end CurrencyCodeReverse::CurrencyCodeReverse%5CF7C71E030A_const.hasinit
  //## begin CurrencyCodeReverse::CurrencyCodeReverse%5CF7C71E030A_const.initialization preserve=yes
   : ConversionItem("## CFB2 XLATE COUNTRY CODE")
  //## end CurrencyCodeReverse::CurrencyCodeReverse%5CF7C71E030A_const.initialization
{
  //## begin configuration::CurrencyCodeReverse::CurrencyCodeReverse%5CF7C71E030A_const.body preserve=yes
   memcpy(m_sID, "CFB2", 4);
  //## end configuration::CurrencyCodeReverse::CurrencyCodeReverse%5CF7C71E030A_const.body
}


CurrencyCodeReverse::~CurrencyCodeReverse()
{
  //## begin configuration::CurrencyCodeReverse::~CurrencyCodeReverse%5CF7C71E030A_dest.body preserve=yes
  //## end configuration::CurrencyCodeReverse::~CurrencyCodeReverse%5CF7C71E030A_dest.body
}



//## Other Operations (implementation)
void CurrencyCodeReverse::bind (Query& hQuery)
{
  //## begin configuration::CurrencyCodeReverse::bind%5CF7CAA903C0.body preserve=yes
   hQuery.setQualifier("QUALIFY", "CURRENCY_CODE");
   hQuery.bind("CURRENCY_CODE", "CURRENCY_CODE_ISO3", Column::STRING, &m_strFirst);
   hQuery.bind("CURRENCY_CODE", "CURRENCY_CODE", Column::STRING, &m_strSecond);
   hQuery.setBasicPredicate("CURRENCY_CODE", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("CURRENCY_CODE", "CC_STATE", "=", "A");
   string strTemp = "('" + entitysegment::Customer::instance()->getCUST_ID() + "','****')";
   hQuery.setBasicPredicate("CURRENCY_CODE", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("CURRENCY_CODE.CURRENCY_CODE_ISO3 ASC");
  //## end configuration::CurrencyCodeReverse::bind%5CF7CAA903C0.body
}

// Additional Declarations
  //## begin configuration::CurrencyCodeReverse%5CF7C71E030A.declarations preserve=yes
  //## end configuration::CurrencyCodeReverse%5CF7C71E030A.declarations

} // namespace configuration

//## begin module%5CF7CA0D02D7.epilog preserve=yes
//## end module%5CF7CA0D02D7.epilog
