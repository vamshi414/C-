//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFDA91001C5.cm preserve=no
//	$Date:   Dec 12 2016 13:09:34  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%3FFDA91001C5.cm

//## begin module%3FFDA91001C5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFDA91001C5.cp

//## Module: CXOSCF56%3FFDA91001C5; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF56.hpp

#ifndef CXOSCF56_h
#define CXOSCF56_h 1

//## begin module%3FFDA91001C5.additionalIncludes preserve=no
//## end module%3FFDA91001C5.additionalIncludes

//## begin module%3FFDA91001C5.includes preserve=yes
// $Date:   Dec 12 2016 13:09:34  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%3FFDA91001C5.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
//## begin module%3FFDA91001C5.declarations preserve=no
//## end module%3FFDA91001C5.declarations

//## begin module%3FFDA91001C5.additionalDeclarations preserve=yes
//## end module%3FFDA91001C5.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexTerminalType1%3FFDA7FD0000.preface preserve=yes
//## end configuration::ConnexTerminalType1%3FFDA7FD0000.preface

//## Class: ConnexTerminalType1%3FFDA7FD0000
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FFDA83402DE;reusable::Query { -> F}

class DllExport ConnexTerminalType1 : public ConversionItem  //## Inherits: <unnamed>%3FFDA82200CB
{
  //## begin configuration::ConnexTerminalType1%3FFDA7FD0000.initialDeclarations preserve=yes
  //## end configuration::ConnexTerminalType1%3FFDA7FD0000.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexTerminalType1();

    //## Destructor (generated)
      virtual ~ConnexTerminalType1();


    //## Other Operations (specified)
      //## Operation: bind%3FFDA80F00DA
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%584716910132
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexTerminalType1%3FFDA7FD0000.public preserve=yes
      //## end configuration::ConnexTerminalType1%3FFDA7FD0000.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexTerminalType1%3FFDA7FD0000.protected preserve=yes
      //## end configuration::ConnexTerminalType1%3FFDA7FD0000.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexTerminalType1%3FFDA7FD0000.private preserve=yes
      //## end configuration::ConnexTerminalType1%3FFDA7FD0000.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexTerminalType1%3FFDA7FD0000.implementation preserve=yes
      //## end configuration::ConnexTerminalType1%3FFDA7FD0000.implementation

};

//## begin configuration::ConnexTerminalType1%3FFDA7FD0000.postscript preserve=yes
//## end configuration::ConnexTerminalType1%3FFDA7FD0000.postscript

} // namespace configuration

//## begin module%3FFDA91001C5.epilog preserve=yes
using namespace configuration;
//## end module%3FFDA91001C5.epilog


#endif
