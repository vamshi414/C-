//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6243FE590227.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%6243FE590227.cm

//## begin module%6243FE590227.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%6243FE590227.cp

//## Module: CXOSCFC9%6243FE590227; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFC9.cpp

//## begin module%6243FE590227.additionalIncludes preserve=no
//## end module%6243FE590227.additionalIncludes

//## begin module%6243FE590227.includes preserve=yes
//## end module%6243FE590227.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFC9_h
#include "CXODCFC9.hpp"
#endif


//## begin module%6243FE590227.declarations preserve=no
//## end module%6243FE590227.declarations

//## begin module%6243FE590227.additionalDeclarations preserve=yes
//## end module%6243FE590227.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::QMRVisaBusinessID 

QMRVisaBusinessID::QMRVisaBusinessID()
  //## begin QMRVisaBusinessID::QMRVisaBusinessID%6243F75D00E8_const.hasinit preserve=no
  //## end QMRVisaBusinessID::QMRVisaBusinessID%6243F75D00E8_const.hasinit
  //## begin QMRVisaBusinessID::QMRVisaBusinessID%6243F75D00E8_const.initialization preserve=yes
	: ConversionItem("## CFC9 XLATE QMR VISA BID")
  //## end QMRVisaBusinessID::QMRVisaBusinessID%6243F75D00E8_const.initialization
{
  //## begin configuration::QMRVisaBusinessID::QMRVisaBusinessID%6243F75D00E8_const.body preserve=yes
	memcpy(m_sID,"CFC9",4);
  //## end configuration::QMRVisaBusinessID::QMRVisaBusinessID%6243F75D00E8_const.body
}


QMRVisaBusinessID::~QMRVisaBusinessID()
{
  //## begin configuration::QMRVisaBusinessID::~QMRVisaBusinessID%6243F75D00E8_dest.body preserve=yes
  //## end configuration::QMRVisaBusinessID::~QMRVisaBusinessID%6243F75D00E8_dest.body
}



//## Other Operations (implementation)
void QMRVisaBusinessID::bind (Query& hQuery)
{
  //## begin configuration::QMRVisaBusinessID::bind%624418A50180.body preserve=yes
   hQuery.setQualifier("QUALIFY","QMR_VISA_BID");
   hQuery.bind("QMR_VISA_BID","BIN",Column::STRING,&m_strBIN);
   hQuery.bind("QMR_VISA_BID","BIN_TYPE",Column::STRING,&m_strFirst);
   hQuery.bind("QMR_VISA_BID","BUSINESS_ID",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("QMR_VISA_BID","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("QMR_VISA_BID","CC_STATE","=","A");
   hQuery.setOrderByClause("BIN_TYPE,BIN");
  //## end configuration::QMRVisaBusinessID::bind%624418A50180.body
}

const string& QMRVisaBusinessID::getFirst ()
{
  //## begin configuration::QMRVisaBusinessID::getFirst%624420420274.body preserve=yes
   m_strFirst.resize(1,' ');
   m_strFirst += m_strBIN;
   return m_strFirst;
  //## end configuration::QMRVisaBusinessID::getFirst%624420420274.body
}

// Additional Declarations
  //## begin configuration::QMRVisaBusinessID%6243F75D00E8.declarations preserve=yes
  //## end configuration::QMRVisaBusinessID%6243F75D00E8.declarations

} // namespace configuration

//## begin module%6243FE590227.epilog preserve=yes
//## end module%6243FE590227.epilog
