//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3AC0B961002B.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%3AC0B961002B.cm

//## begin module%3AC0B961002B.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%3AC0B961002B.cp

//## Module: CXOSCF43%3AC0B961002B; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF43.cpp

//## begin module%3AC0B961002B.additionalIncludes preserve=no
//## end module%3AC0B961002B.additionalIncludes

//## begin module%3AC0B961002B.includes preserve=yes
// $Date:   Dec 07 2016 15:44:08  $ $Author:   e1009652  $ $Revision:   1.6  $
//## end module%3AC0B961002B.includes

#ifndef CXOSCF43_h
#include "CXODCF43.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%3AC0B961002B.declarations preserve=no
//## end module%3AC0B961002B.declarations

//## begin module%3AC0B961002B.additionalDeclarations preserve=yes
//## end module%3AC0B961002B.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::GenericTransactionClass

GenericTransactionClass::GenericTransactionClass()
  //## begin GenericTransactionClass::GenericTransactionClass%3AC0ADCA02B9_const.hasinit preserve=no
  //## end GenericTransactionClass::GenericTransactionClass%3AC0ADCA02B9_const.hasinit
  //## begin GenericTransactionClass::GenericTransactionClass%3AC0ADCA02B9_const.initialization preserve=yes
   : ConversionItem("## CR41 XLATE TRANSACTION CLASS")
  //## end GenericTransactionClass::GenericTransactionClass%3AC0ADCA02B9_const.initialization
{
  //## begin configuration::GenericTransactionClass::GenericTransactionClass%3AC0ADCA02B9_const.body preserve=yes
   memcpy(m_sID,"CF43",4);
  //## end configuration::GenericTransactionClass::GenericTransactionClass%3AC0ADCA02B9_const.body
}


GenericTransactionClass::~GenericTransactionClass()
{
  //## begin configuration::GenericTransactionClass::~GenericTransactionClass%3AC0ADCA02B9_dest.body preserve=yes
  //## end configuration::GenericTransactionClass::~GenericTransactionClass%3AC0ADCA02B9_dest.body
}



//## Other Operations (implementation)
void GenericTransactionClass::bind (Query& hQuery)
{
  //## begin configuration::GenericTransactionClass::bind%3AC0B41003DB.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_TO_TRAN_CLASS");
   hQuery.bind("X_TO_TRAN_CLASS","INPUT_VALUE",Column::STRING,&m_strFirst);
   hQuery.bind("X_TO_TRAN_CLASS","TRAN_CLASS",Column::STRING,&m_strSecond);
   hQuery.bind("X_TO_TRAN_CLASS","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_TO_TRAN_CLASS", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_TO_TRAN_CLASS", "CC_STATE", "=", "A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_TO_TRAN_CLASS","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_TO_TRAN_CLASS.INPUT_VALUE ASC,X_TO_TRAN_CLASS.CUST_ID DESC");
  //## end configuration::GenericTransactionClass::bind%3AC0B41003DB.body
}

// Additional Declarations
  //## begin configuration::GenericTransactionClass%3AC0ADCA02B9.declarations preserve=yes
  //## end configuration::GenericTransactionClass%3AC0ADCA02B9.declarations

} // namespace configuration

//## begin module%3AC0B961002B.epilog preserve=yes
//## end module%3AC0B961002B.epilog
