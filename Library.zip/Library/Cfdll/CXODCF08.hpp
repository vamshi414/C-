//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3917328500A9.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3917328500A9.cm

//## begin module%3917328500A9.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3917328500A9.cp

//## Module: CXOSCF08%3917328500A9; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF08.hpp

#ifndef CXOSCF08_h
#define CXOSCF08_h 1

//## begin module%3917328500A9.additionalIncludes preserve=no
//## end module%3917328500A9.additionalIncludes

//## begin module%3917328500A9.includes preserve=yes
// $Date:   Jun 30 2006 12:15:42  $ $Author:   D02405  $ $Revision:   1.5  $
//## end module%3917328500A9.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%3917328500A9.declarations preserve=no
//## end module%3917328500A9.declarations

//## begin module%3917328500A9.additionalDeclarations preserve=yes
//## end module%3917328500A9.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::AdvantageMessageCode%3912F128016F.preface preserve=yes
//## end configuration::AdvantageMessageCode%3912F128016F.preface

//## Class: AdvantageMessageCode%3912F128016F
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3912F7E4002D;reusable::Query { -> F}
//## Uses: <unnamed>%3919C7810109;IF::Extract { -> F}

class DllExport AdvantageMessageCode : public ConversionItem  //## Inherits: <unnamed>%3912F136007F
{
  //## begin configuration::AdvantageMessageCode%3912F128016F.initialDeclarations preserve=yes
  //## end configuration::AdvantageMessageCode%3912F128016F.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageMessageCode();

    //## Destructor (generated)
      virtual ~AdvantageMessageCode();


    //## Other Operations (specified)
      //## Operation: bind%3912F79402A9
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%3912F79601C6
      virtual const string& getFirst ();

      //## Operation: getSecond%3950BD8802C2
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::AdvantageMessageCode%3912F128016F.public preserve=yes
      //## end configuration::AdvantageMessageCode%3912F128016F.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: FIN_TRAN_TYPE%3950BD6E02CE
      //## begin configuration::AdvantageMessageCode::FIN_TRAN_TYPE%3950BD6E02CE.attr preserve=no  private: int {U} 
      int m_lFIN_TRAN_TYPE;
      //## end configuration::AdvantageMessageCode::FIN_TRAN_TYPE%3950BD6E02CE.attr

    // Additional Protected Declarations
      //## begin configuration::AdvantageMessageCode%3912F128016F.protected preserve=yes
      //## end configuration::AdvantageMessageCode%3912F128016F.protected

  private:
    // Additional Private Declarations
      //## begin configuration::AdvantageMessageCode%3912F128016F.private preserve=yes
      //## end configuration::AdvantageMessageCode%3912F128016F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ADVG_MSG_CODE%3912F7AF01B8
      //## begin configuration::AdvantageMessageCode::ADVG_MSG_CODE%3912F7AF01B8.attr preserve=no  private: int {V} 
      int m_lADVG_MSG_CODE;
      //## end configuration::AdvantageMessageCode::ADVG_MSG_CODE%3912F7AF01B8.attr

      //## Attribute: ADVG_STEP%3912F7C702DF
      //## begin configuration::AdvantageMessageCode::ADVG_STEP%3912F7C702DF.attr preserve=no  private: int {U} 
      int m_lADVG_STEP;
      //## end configuration::AdvantageMessageCode::ADVG_STEP%3912F7C702DF.attr

    // Additional Implementation Declarations
      //## begin configuration::AdvantageMessageCode%3912F128016F.implementation preserve=yes
      //## end configuration::AdvantageMessageCode%3912F128016F.implementation

};

//## begin configuration::AdvantageMessageCode%3912F128016F.postscript preserve=yes
//## end configuration::AdvantageMessageCode%3912F128016F.postscript

} // namespace configuration

//## begin module%3917328500A9.epilog preserve=yes
using namespace configuration;
//## end module%3917328500A9.epilog


#endif
