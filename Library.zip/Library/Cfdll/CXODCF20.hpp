//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%391C112C0217.cm preserve=no
//	$Date:   Dec 07 2016 15:46:08  $ $Author:   e1009652  $
//	$Revision:   1.4  $
//## end module%391C112C0217.cm

//## begin module%391C112C0217.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%391C112C0217.cp

//## Module: CXOSCF20%391C112C0217; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF20.hpp

#ifndef CXOSCF20_h
#define CXOSCF20_h 1

//## begin module%391C112C0217.additionalIncludes preserve=no
//## end module%391C112C0217.additionalIncludes

//## begin module%391C112C0217.includes preserve=yes
// $Date:   Dec 07 2016 15:46:08  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%391C112C0217.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%391C112C0217.declarations preserve=no
//## end module%391C112C0217.declarations

//## begin module%391C112C0217.additionalDeclarations preserve=yes
//## end module%391C112C0217.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexMessageTypeIdentifier%391C0CCE015C.preface preserve=yes
//## end configuration::ConnexMessageTypeIdentifier%391C0CCE015C.preface

//## Class: ConnexMessageTypeIdentifier%391C0CCE015C
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%391C180801E0;IF::Extract { -> F}
//## Uses: <unnamed>%391C180A008F;reusable::Query { -> F}

class DllExport ConnexMessageTypeIdentifier : public ConversionItem  //## Inherits: <unnamed>%391C17F002FE
{
  //## begin configuration::ConnexMessageTypeIdentifier%391C0CCE015C.initialDeclarations preserve=yes
  //## end configuration::ConnexMessageTypeIdentifier%391C0CCE015C.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexMessageTypeIdentifier();

    //## Destructor (generated)
      virtual ~ConnexMessageTypeIdentifier();


    //## Other Operations (specified)
      //## Operation: bind%391C1C10014E
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%584719110306
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexMessageTypeIdentifier%391C0CCE015C.public preserve=yes
      //## end configuration::ConnexMessageTypeIdentifier%391C0CCE015C.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexMessageTypeIdentifier%391C0CCE015C.protected preserve=yes
      //## end configuration::ConnexMessageTypeIdentifier%391C0CCE015C.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexMessageTypeIdentifier%391C0CCE015C.private preserve=yes
      //## end configuration::ConnexMessageTypeIdentifier%391C0CCE015C.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexMessageTypeIdentifier%391C0CCE015C.implementation preserve=yes
      //## end configuration::ConnexMessageTypeIdentifier%391C0CCE015C.implementation

};

//## begin configuration::ConnexMessageTypeIdentifier%391C0CCE015C.postscript preserve=yes
//## end configuration::ConnexMessageTypeIdentifier%391C0CCE015C.postscript

} // namespace configuration

//## begin module%391C112C0217.epilog preserve=yes
using namespace configuration;
//## end module%391C112C0217.epilog


#endif
