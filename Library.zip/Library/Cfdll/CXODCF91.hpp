//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%45DA00860327.cm preserve=no
//	$Date:   Feb 20 2007 11:09:48  $ $Author:   D92705  $
//	$Revision:   1.0  $
//## end module%45DA00860327.cm

//## begin module%45DA00860327.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%45DA00860327.cp

//## Module: CXOSCF91%45DA00860327; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF91.hpp

#ifndef CXOSCF91_h
#define CXOSCF91_h 1

//## begin module%45DA00860327.additionalIncludes preserve=no
//## end module%45DA00860327.additionalIncludes

//## begin module%45DA00860327.includes preserve=yes
//## end module%45DA00860327.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%45DA00860327.declarations preserve=no
//## end module%45DA00860327.declarations

//## begin module%45DA00860327.additionalDeclarations preserve=yes
//## end module%45DA00860327.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::DeviceRev%45D9FF6201BF.preface preserve=yes
//## end configuration::DeviceRev%45D9FF6201BF.preface

//## Class: DeviceRev%45D9FF6201BF
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%45DA02D900CA;reusable::Query { -> F}
//## Uses: <unnamed>%45DA03A903B8;IF::Extract { -> F}

class DllExport DeviceRev : public ConversionItem  //## Inherits: <unnamed>%45DA024D021D
{
  //## begin configuration::DeviceRev%45D9FF6201BF.initialDeclarations preserve=yes
  //## end configuration::DeviceRev%45D9FF6201BF.initialDeclarations

  public:
    //## Constructors (generated)
      DeviceRev();

    //## Destructor (generated)
      virtual ~DeviceRev();


    //## Other Operations (specified)
      //## Operation: bind%45DA03160096
      virtual void bind (reusable::Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::DeviceRev%45D9FF6201BF.public preserve=yes
      //## end configuration::DeviceRev%45D9FF6201BF.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::DeviceRev%45D9FF6201BF.protected preserve=yes
      //## end configuration::DeviceRev%45D9FF6201BF.protected

  private:
    // Additional Private Declarations
      //## begin configuration::DeviceRev%45D9FF6201BF.private preserve=yes
      //## end configuration::DeviceRev%45D9FF6201BF.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::DeviceRev%45D9FF6201BF.implementation preserve=yes
      //## end configuration::DeviceRev%45D9FF6201BF.implementation

};

//## begin configuration::DeviceRev%45D9FF6201BF.postscript preserve=yes
//## end configuration::DeviceRev%45D9FF6201BF.postscript

} // namespace configuration

//## begin module%45DA00860327.epilog preserve=yes
//## end module%45DA00860327.epilog


#endif
