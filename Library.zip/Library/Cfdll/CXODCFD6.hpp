//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6528229E03D7.cm preserve=no
//## end module%6528229E03D7.cm

//## begin module%6528229E03D7.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6528229E03D7.cp

//## Module: CXOSCFD6%6528229E03D7; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCFD6.hpp

#ifndef CXOSCFD6_h
#define CXOSCFD6_h 1

//## begin module%6528229E03D7.additionalIncludes preserve=no
//## end module%6528229E03D7.additionalIncludes

//## begin module%6528229E03D7.includes preserve=yes
//## end module%6528229E03D7.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%6528229E03D7.declarations preserve=no
//## end module%6528229E03D7.declarations

//## begin module%6528229E03D7.additionalDeclarations preserve=yes
//## end module%6528229E03D7.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::MoneyPassProcessCode%652821620178.preface preserve=yes
//## end configuration::MoneyPassProcessCode%652821620178.preface

//## Class: MoneyPassProcessCode%652821620178
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%65282162017B;IF::Extract { -> F}
//## Uses: <unnamed>%65282162017C;reusable::Query { -> F}

class DllExport MoneyPassProcessCode : public ConversionItem  //## Inherits: <unnamed>%652821620179
{
  //## begin configuration::MoneyPassProcessCode%652821620178.initialDeclarations preserve=yes
  //## end configuration::MoneyPassProcessCode%652821620178.initialDeclarations

  public:
    //## Constructors (generated)
      MoneyPassProcessCode();

    //## Destructor (generated)
      virtual ~MoneyPassProcessCode();


    //## Other Operations (specified)
      //## Operation: bind%65282162017D
      virtual void bind (Query& hQuery);

      //## Operation: getSecond%65282162017F
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::MoneyPassProcessCode%652821620178.public preserve=yes
      //## end configuration::MoneyPassProcessCode%652821620178.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::MoneyPassProcessCode%652821620178.protected preserve=yes
      //## end configuration::MoneyPassProcessCode%652821620178.protected

  private:
    // Additional Private Declarations
      //## begin configuration::MoneyPassProcessCode%652821620178.private preserve=yes
      //## end configuration::MoneyPassProcessCode%652821620178.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: PROCESS_CODE%652821620180
      //## begin configuration::MoneyPassProcessCode::PROCESS_CODE%652821620180.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::MoneyPassProcessCode::PROCESS_CODE%652821620180.attr

      //## Attribute: MSG_CLASS%652821620181
      //## begin configuration::MoneyPassProcessCode::MSG_CLASS%652821620181.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::MoneyPassProcessCode::MSG_CLASS%652821620181.attr

      //## Attribute: PRE_AUTH%652821620182
      //## begin configuration::MoneyPassProcessCode::PRE_AUTH%652821620182.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::MoneyPassProcessCode::PRE_AUTH%652821620182.attr

      //## Attribute: MEDIA_TYPE%652821620183
      //## begin configuration::MoneyPassProcessCode::MEDIA_TYPE%652821620183.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::MoneyPassProcessCode::MEDIA_TYPE%652821620183.attr

    // Additional Implementation Declarations
      //## begin configuration::MoneyPassProcessCode%652821620178.implementation preserve=yes
      //## end configuration::MoneyPassProcessCode%652821620178.implementation

};

//## begin configuration::MoneyPassProcessCode%652821620178.postscript preserve=yes
//## end configuration::MoneyPassProcessCode%652821620178.postscript

} // namespace configuration

//## begin module%6528229E03D7.epilog preserve=yes
//## end module%6528229E03D7.epilog


#endif
