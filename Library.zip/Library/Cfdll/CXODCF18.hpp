//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%391C110702FB.cm preserve=no
//	$Date:   Dec 07 2016 15:45:38  $ $Author:   e1009652  $
//	$Revision:   1.4  $
//## end module%391C110702FB.cm

//## begin module%391C110702FB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%391C110702FB.cp

//## Module: CXOSCF18%391C110702FB; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF18.hpp

#ifndef CXOSCF18_h
#define CXOSCF18_h 1

//## begin module%391C110702FB.additionalIncludes preserve=no
//## end module%391C110702FB.additionalIncludes

//## begin module%391C110702FB.includes preserve=yes
// $Date:   Dec 07 2016 15:45:38  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%391C110702FB.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%391C110702FB.declarations preserve=no
//## end module%391C110702FB.declarations

//## begin module%391C110702FB.additionalDeclarations preserve=yes
//## end module%391C110702FB.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::Processor%391C0CB60053.preface preserve=yes
//## end configuration::Processor%391C0CB60053.preface

//## Class: Processor%391C0CB60053
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%391C1799010E;IF::Extract { -> F}
//## Uses: <unnamed>%391C179A02E7;reusable::Query { -> F}

class DllExport Processor : public ConversionItem  //## Inherits: <unnamed>%391C17970314
{
  //## begin configuration::Processor%391C0CB60053.initialDeclarations preserve=yes
  //## end configuration::Processor%391C0CB60053.initialDeclarations

  public:
    //## Constructors (generated)
      Processor();

    //## Destructor (generated)
      virtual ~Processor();


    //## Other Operations (specified)
      //## Operation: bind%391C1C01016B
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%58471860010B
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::Processor%391C0CB60053.public preserve=yes
      //## end configuration::Processor%391C0CB60053.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::Processor%391C0CB60053.protected preserve=yes
      //## end configuration::Processor%391C0CB60053.protected

  private:
    // Additional Private Declarations
      //## begin configuration::Processor%391C0CB60053.private preserve=yes
      //## end configuration::Processor%391C0CB60053.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::Processor%391C0CB60053.implementation preserve=yes
      //## end configuration::Processor%391C0CB60053.implementation

};

//## begin configuration::Processor%391C0CB60053.postscript preserve=yes
//## end configuration::Processor%391C0CB60053.postscript

} // namespace configuration

//## begin module%391C110702FB.epilog preserve=yes
using namespace configuration;
//## end module%391C110702FB.epilog


#endif
