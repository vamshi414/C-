//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%664712B7005E.cm preserve=no
//## end module%664712B7005E.cm

//## begin module%664712B7005E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%664712B7005E.cp

//## Module: CXOSCFD8%664712B7005E; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFD8.cpp

//## begin module%664712B7005E.additionalIncludes preserve=no
//## end module%664712B7005E.additionalIncludes

//## begin module%664712B7005E.includes preserve=yes
//## end module%664712B7005E.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFD8_h
#include "CXODCFD8.hpp"
#endif


//## begin module%664712B7005E.declarations preserve=no
//## end module%664712B7005E.declarations

//## begin module%664712B7005E.additionalDeclarations preserve=yes
//## end module%664712B7005E.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::MerchantSettlementTime 

MerchantSettlementTime::MerchantSettlementTime()
  //## begin MerchantSettlementTime::MerchantSettlementTime%664713A00212_const.hasinit preserve=no
  //## end MerchantSettlementTime::MerchantSettlementTime%664713A00212_const.hasinit
  //## begin MerchantSettlementTime::MerchantSettlementTime%664713A00212_const.initialization preserve=yes
   :ConversionItem("## CFD8 CHAIN MERCHANT ID TO IST CUTOFF TIME")
  //## end MerchantSettlementTime::MerchantSettlementTime%664713A00212_const.initialization
{
  //## begin configuration::MerchantSettlementTime::MerchantSettlementTime%664713A00212_const.body preserve=yes
   memcpy(m_sID, "CFD8", 4);
  //## end configuration::MerchantSettlementTime::MerchantSettlementTime%664713A00212_const.body
}


MerchantSettlementTime::~MerchantSettlementTime()
{
  //## begin configuration::MerchantSettlementTime::~MerchantSettlementTime%664713A00212_dest.body preserve=yes
  //## end configuration::MerchantSettlementTime::~MerchantSettlementTime%664713A00212_dest.body
}



//## Other Operations (implementation)
void MerchantSettlementTime::bind (Query& hQuery)
{
  //## begin configuration::MerchantSettlementTime::bind%6647157F0052.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY", "REPORTING_LVL_BUS");
   hQuery.bind("REPORTING_LVL_BUS", "RPT_LVL_ID", Column::STRING, &m_strFirst);
   hQuery.bind("REPORTING_LVL_BUS", "SETTLEMENT_TIME", Column::STRING, &m_strSecond);
   hQuery.setBasicPredicate("REPORTING_LVL_BUS", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("REPORTING_LVL_BUS", "CC_STATE", "=", "A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("REPORTING_LVL_BUS", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("RPT_LVL_ID ASC");
  //## end configuration::MerchantSettlementTime::bind%6647157F0052.body
}

// Additional Declarations
  //## begin configuration::MerchantSettlementTime%664713A00212.declarations preserve=yes
  //## end configuration::MerchantSettlementTime%664713A00212.declarations

} // namespace configuration

//## begin module%664712B7005E.epilog preserve=yes
//## end module%664712B7005E.epilog
