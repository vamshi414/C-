//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%391C0E2F0069.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%391C0E2F0069.cm

//## begin module%391C0E2F0069.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%391C0E2F0069.cp

//## Module: CXOSCF21%391C0E2F0069; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF21.cpp

//## begin module%391C0E2F0069.additionalIncludes preserve=no
//## end module%391C0E2F0069.additionalIncludes

//## begin module%391C0E2F0069.includes preserve=yes
// $Date:   Apr 17 2014 20:59:26  $ $Author:   e1009652  $ $Revision:   1.7  $
//## end module%391C0E2F0069.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF21_h
#include "CXODCF21.hpp"
#endif


//## begin module%391C0E2F0069.declarations preserve=no
//## end module%391C0E2F0069.declarations

//## begin module%391C0E2F0069.additionalDeclarations preserve=yes
//## end module%391C0E2F0069.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexProcessCode 

ConnexProcessCode::ConnexProcessCode()
  //## begin ConnexProcessCode::ConnexProcessCode%391C0CE003A6_const.hasinit preserve=no
  //## end ConnexProcessCode::ConnexProcessCode%391C0CE003A6_const.hasinit
  //## begin ConnexProcessCode::ConnexProcessCode%391C0CE003A6_const.initialization preserve=yes
   : ConversionItem("## CR24 XLATE IBM PROCESS CODE")
  //## end ConnexProcessCode::ConnexProcessCode%391C0CE003A6_const.initialization
{
  //## begin configuration::ConnexProcessCode::ConnexProcessCode%391C0CE003A6_const.body preserve=yes
   memcpy(m_sID,"CF21",4);
  //## end configuration::ConnexProcessCode::ConnexProcessCode%391C0CE003A6_const.body
}


ConnexProcessCode::~ConnexProcessCode()
{
  //## begin configuration::ConnexProcessCode::~ConnexProcessCode%391C0CE003A6_dest.body preserve=yes
  //## end configuration::ConnexProcessCode::~ConnexProcessCode%391C0CE003A6_dest.body
}



//## Other Operations (implementation)
void ConnexProcessCode::bind (Query& hQuery)
{
  //## begin configuration::ConnexProcessCode::bind%391C1C730331.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_IBM_PROC_CODE");
   hQuery.bind("X_IBM_PROC_CODE","IBM_PROCESS_CODE",Column::STRING,&m_strIBM_PROCESS_CODE);
   hQuery.bind("X_IBM_PROC_CODE","IBM_MSG_CLASS",Column::STRING,&m_strIBM_MSG_CLASS);
   hQuery.bind("X_IBM_PROC_CODE","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("X_IBM_PROC_CODE","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("X_IBM_PROC_CODE","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("X_IBM_PROC_CODE","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("X_IBM_PROC_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_IBM_PROC_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_PROC_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_IBM_PROC_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_IBM_PROC_CODE.IBM_PROCESS_CODE ASC,"
                           "X_IBM_PROC_CODE.IBM_MSG_CLASS ASC,"
                           "X_IBM_PROC_CODE.CUST_ID DESC");
  //## end configuration::ConnexProcessCode::bind%391C1C730331.body
}

const string& ConnexProcessCode::getFirst ()
{
  //## begin configuration::ConnexProcessCode::getFirst%391C1C73033B.body preserve=yes
   while (m_strIBM_PROCESS_CODE.length() < 6)
      m_strIBM_PROCESS_CODE += ' ';
   m_strFirst = m_strIBM_PROCESS_CODE + m_strIBM_MSG_CLASS;
   return m_strFirst;
  //## end configuration::ConnexProcessCode::getFirst%391C1C73033B.body
}

const string& ConnexProcessCode::getSecond ()
{
  //## begin configuration::ConnexProcessCode::getSecond%392052B60109.body preserve=yes
   while (m_strPROCESS_CODE.length() < 6)
      m_strPROCESS_CODE += ' ';
   while (m_strMSG_CLASS.length() < 1)
      m_strMSG_CLASS += ' ';
   while (m_strPRE_AUTH.length() < 1)
      m_strPRE_AUTH += ' ';
   m_strSecond = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strSecond;
  //## end configuration::ConnexProcessCode::getSecond%392052B60109.body
}

// Additional Declarations
  //## begin configuration::ConnexProcessCode%391C0CE003A6.declarations preserve=yes
  //## end configuration::ConnexProcessCode%391C0CE003A6.declarations

} // namespace configuration

//## begin module%391C0E2F0069.epilog preserve=yes
//## end module%391C0E2F0069.epilog
