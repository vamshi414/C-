//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFC3CEA01F4.cm preserve=no
//	$Date:   Dec 16 2016 15:20:42  $ $Author:   e1009652  $
//	$Revision:   1.4  $
//## end module%3FFC3CEA01F4.cm

//## begin module%3FFC3CEA01F4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFC3CEA01F4.cp

//## Module: CXOSCF51%3FFC3CEA01F4; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF51.cpp

//## begin module%3FFC3CEA01F4.additionalIncludes preserve=no
//## end module%3FFC3CEA01F4.additionalIncludes

//## begin module%3FFC3CEA01F4.includes preserve=yes
// $Date:   Dec 16 2016 15:20:42  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%3FFC3CEA01F4.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF51_h
#include "CXODCF51.hpp"
#endif
//## begin module%3FFC3CEA01F4.declarations preserve=no
//## end module%3FFC3CEA01F4.declarations

//## begin module%3FFC3CEA01F4.additionalDeclarations preserve=yes
//## end module%3FFC3CEA01F4.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexPOSConditionCode2 

ConnexPOSConditionCode2::ConnexPOSConditionCode2()
  //## begin ConnexPOSConditionCode2::ConnexPOSConditionCode2%3FFC3B4E006D_const.hasinit preserve=no
  //## end ConnexPOSConditionCode2::ConnexPOSConditionCode2%3FFC3B4E006D_const.hasinit
  //## begin ConnexPOSConditionCode2::ConnexPOSConditionCode2%3FFC3B4E006D_const.initialization preserve=yes
   : ConversionItem("## CR63 XLATE POS CON COD2")
  //## end ConnexPOSConditionCode2::ConnexPOSConditionCode2%3FFC3B4E006D_const.initialization
{
  //## begin configuration::ConnexPOSConditionCode2::ConnexPOSConditionCode2%3FFC3B4E006D_const.body preserve=yes
   memcpy(m_sID,"CF51",4);
  //## end configuration::ConnexPOSConditionCode2::ConnexPOSConditionCode2%3FFC3B4E006D_const.body
}


ConnexPOSConditionCode2::~ConnexPOSConditionCode2()
{
  //## begin configuration::ConnexPOSConditionCode2::~ConnexPOSConditionCode2%3FFC3B4E006D_dest.body preserve=yes
  //## end configuration::ConnexPOSConditionCode2::~ConnexPOSConditionCode2%3FFC3B4E006D_dest.body
}



//## Other Operations (implementation)
void ConnexPOSConditionCode2::bind (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode2::bind%3FFC3BCD0251.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_IBM_POS_COND_COD");
   hQuery.bind("X_IBM_POS_COND_COD","POS_COND_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_POS_COND_COD","POS_CARD_CAPT_CAP",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IBM_POS_COND_COD.POS_COND_CODE ASC");
  //## end configuration::ConnexPOSConditionCode2::bind%3FFC3BCD0251.body
}

void ConnexPOSConditionCode2::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode2::setPredicate%5847161400A3.body preserve=yes
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_STATE", "=", "A");
  //## end configuration::ConnexPOSConditionCode2::setPredicate%5847161400A3.body
}

// Additional Declarations
  //## begin configuration::ConnexPOSConditionCode2%3FFC3B4E006D.declarations preserve=yes
  //## end configuration::ConnexPOSConditionCode2%3FFC3B4E006D.declarations

} // namespace configuration

//## begin module%3FFC3CEA01F4.epilog preserve=yes
//## end module%3FFC3CEA01F4.epilog
