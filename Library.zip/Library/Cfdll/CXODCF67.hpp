//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40C9A7910203.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40C9A7910203.cm

//## begin module%40C9A7910203.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40C9A7910203.cp

//## Module: CXOSCF67%40C9A7910203; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF67.hpp

#ifndef CXOSCF67_h
#define CXOSCF67_h 1

//## begin module%40C9A7910203.additionalIncludes preserve=no
//## end module%40C9A7910203.additionalIncludes

//## begin module%40C9A7910203.includes preserve=yes
//## end module%40C9A7910203.includes

#ifndef CXOSCF64_h
#include "CXODCF64.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;

} // namespace IF

//## begin module%40C9A7910203.declarations preserve=no
//## end module%40C9A7910203.declarations

//## begin module%40C9A7910203.additionalDeclarations preserve=yes
//## end module%40C9A7910203.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::OasisOCSExceptionMap%40C9A63F008C.preface preserve=yes
//## end configuration::OasisOCSExceptionMap%40C9A63F008C.preface

//## Class: OasisOCSExceptionMap%40C9A63F008C
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40C9A6DD0203;IF::FlatFile { -> F}

class DllExport OasisOCSExceptionMap : public ImportMapItem  //## Inherits: <unnamed>%40C9A6A60177
{
  //## begin configuration::OasisOCSExceptionMap%40C9A63F008C.initialDeclarations preserve=yes
  //## end configuration::OasisOCSExceptionMap%40C9A63F008C.initialDeclarations

  public:
    //## Constructors (generated)
      OasisOCSExceptionMap();

    //## Destructor (generated)
      virtual ~OasisOCSExceptionMap();


    //## Other Operations (specified)
      //## Operation: loadDataMap%40C9A80003D8
      virtual bool loadDataMap ();

    // Additional Public Declarations
      //## begin configuration::OasisOCSExceptionMap%40C9A63F008C.public preserve=yes
      //## end configuration::OasisOCSExceptionMap%40C9A63F008C.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::OasisOCSExceptionMap%40C9A63F008C.protected preserve=yes
      //## end configuration::OasisOCSExceptionMap%40C9A63F008C.protected

  private:
    // Additional Private Declarations
      //## begin configuration::OasisOCSExceptionMap%40C9A63F008C.private preserve=yes
      //## end configuration::OasisOCSExceptionMap%40C9A63F008C.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::OasisOCSExceptionMap%40C9A63F008C.implementation preserve=yes
      //## end configuration::OasisOCSExceptionMap%40C9A63F008C.implementation

};

//## begin configuration::OasisOCSExceptionMap%40C9A63F008C.postscript preserve=yes
//## end configuration::OasisOCSExceptionMap%40C9A63F008C.postscript

} // namespace configuration

//## begin module%40C9A7910203.epilog preserve=yes
using namespace configuration;
//## end module%40C9A7910203.epilog


#endif
