//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4641A96A019C.cm preserve=no
//## end module%4641A96A019C.cm

//## begin module%4641A96A019C.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4641A96A019C.cp

//## Module: CXOSCF93%4641A96A019C; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXODCF93.hpp

#ifndef CXOSCF93_h
#define CXOSCF93_h 1

//## begin module%4641A96A019C.additionalIncludes preserve=no
//## end module%4641A96A019C.additionalIncludes

//## begin module%4641A96A019C.includes preserve=yes
//## end module%4641A96A019C.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%4641A96A019C.declarations preserve=no
//## end module%4641A96A019C.declarations

//## begin module%4641A96A019C.additionalDeclarations preserve=yes
//## end module%4641A96A019C.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::GenericTranslation%4641AA5C011D.preface preserve=yes
//## end configuration::GenericTranslation%4641AA5C011D.preface

//## Class: GenericTranslation%4641AA5C011D
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4641ABB301D6;reusable::Query { -> F}

class DllExport GenericTranslation : public ConversionItem  //## Inherits: <unnamed>%4641AADC033F
{
  //## begin configuration::GenericTranslation%4641AA5C011D.initialDeclarations preserve=yes
  //## end configuration::GenericTranslation%4641AA5C011D.initialDeclarations

  public:
    //## Constructors (generated)
      GenericTranslation();

    //## Constructors (specified)
      //## Operation: GenericTranslation%63998A5B0349
      GenericTranslation (const char* pszX_TYPE);

    //## Destructor (generated)
      virtual ~GenericTranslation();


    //## Other Operations (specified)
      //## Operation: bind%4641AB370263
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%4647E9AC003E
      virtual const string& getFirst ();

      //## Operation: setPredicate%58471755038D
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::GenericTranslation%4641AA5C011D.public preserve=yes
      //## end configuration::GenericTranslation%4641AA5C011D.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::GenericTranslation%4641AA5C011D.protected preserve=yes
      //## end configuration::GenericTranslation%4641AA5C011D.protected

  private:
    // Additional Private Declarations
      //## begin configuration::GenericTranslation%4641AA5C011D.private preserve=yes
      //## end configuration::GenericTranslation%4641AA5C011D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: X_TYPE%4647E9D603B6
      //## begin configuration::GenericTranslation::X_TYPE%4647E9D603B6.attr preserve=no  private: string {U} 
      string m_strX_TYPE;
      //## end configuration::GenericTranslation::X_TYPE%4647E9D603B6.attr

      //## Attribute: FROM_VALUE%4647EA29016E
      //## begin configuration::GenericTranslation::FROM_VALUE%4647EA29016E.attr preserve=no  private: string {U} 
      string m_strFROM_VALUE;
      //## end configuration::GenericTranslation::FROM_VALUE%4647EA29016E.attr

    // Additional Implementation Declarations
      //## begin configuration::GenericTranslation%4641AA5C011D.implementation preserve=yes
      //## end configuration::GenericTranslation%4641AA5C011D.implementation

};

//## begin configuration::GenericTranslation%4641AA5C011D.postscript preserve=yes
//## end configuration::GenericTranslation%4641AA5C011D.postscript

} // namespace configuration

//## begin module%4641A96A019C.epilog preserve=yes
//## end module%4641A96A019C.epilog


#endif
