//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%535078BD0255.cm preserve=no
//	$Date:   Dec 16 2016 15:37:44  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%535078BD0255.cm

//## begin module%535078BD0255.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%535078BD0255.cp

//## Module: CXOSCFA2%535078BD0255; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFA2.cpp

//## begin module%535078BD0255.additionalIncludes preserve=no
//## end module%535078BD0255.additionalIncludes

//## begin module%535078BD0255.includes preserve=yes
//## end module%535078BD0255.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCFA2_h
#include "CXODCFA2.hpp"
#endif


//## begin module%535078BD0255.declarations preserve=no
//## end module%535078BD0255.declarations

//## begin module%535078BD0255.additionalDeclarations preserve=yes
//## end module%535078BD0255.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::DummyProblemTran 

DummyProblemTran::DummyProblemTran()
  //## begin DummyProblemTran::DummyProblemTran%535078830178_const.hasinit preserve=no
  //## end DummyProblemTran::DummyProblemTran%535078830178_const.hasinit
  //## begin DummyProblemTran::DummyProblemTran%535078830178_const.initialization preserve=yes
  //## end DummyProblemTran::DummyProblemTran%535078830178_const.initialization
{
  //## begin configuration::DummyProblemTran::DummyProblemTran%535078830178_const.body preserve=yes
  //## end configuration::DummyProblemTran::DummyProblemTran%535078830178_const.body
}


DummyProblemTran::~DummyProblemTran()
{
  //## begin configuration::DummyProblemTran::~DummyProblemTran%535078830178_dest.body preserve=yes
  //## end configuration::DummyProblemTran::~DummyProblemTran%535078830178_dest.body
}



//## Other Operations (implementation)
void DummyProblemTran::bind (Query& hQuery)
{
  //## begin configuration::DummyProblemTran::bind%53507A090375.body preserve=yes
   hQuery.setQualifier("CUSTQUAL","PROBLEM_TRAN");
   hQuery.setBasicPredicate("PROBLEM_TRAN","PROBLEM_TABLE","=","EMS_CASE");
   hQuery.setBasicPredicate("PROBLEM_TRAN","REASON_CODE","=","8");
   hQuery.setOrderByClause("PROBLEM_TRAN.SOURCE_VALUE ASC");
  //## end configuration::DummyProblemTran::bind%53507A090375.body
}

const string& DummyProblemTran::getFirst ()
{
  //## begin configuration::DummyProblemTran::getFirst%53507A09037B.body preserve=yes
   m_strFirst.assign("?");
   return m_strFirst;
  //## end configuration::DummyProblemTran::getFirst%53507A09037B.body
}

const string& DummyProblemTran::getSecond ()
{
  //## begin configuration::DummyProblemTran::getSecond%53507A090380.body preserve=yes
   m_strSecond.assign("?");
   return m_strSecond;
  //## end configuration::DummyProblemTran::getSecond%53507A090380.body
}

const string& DummyProblemTran::getThird ()
{
  //## begin configuration::DummyProblemTran::getThird%53507A090385.body preserve=yes
   m_strThird.assign("?");
   return m_strThird;
  //## end configuration::DummyProblemTran::getThird%53507A090385.body
}

void DummyProblemTran::setPredicate (Query& hQuery)
{
  //## begin configuration::DummyProblemTran::setPredicate%584717130077.body preserve=yes
   hQuery.setBasicPredicate("PROBLEM_TRAN", "PROBLEM_TABLE", "=", "EMS_CASE");
   hQuery.setBasicPredicate("PROBLEM_TRAN", "REASON_CODE", "=", "8");
  //## end configuration::DummyProblemTran::setPredicate%584717130077.body
}

// Additional Declarations
  //## begin configuration::DummyProblemTran%535078830178.declarations preserve=yes
  //## end configuration::DummyProblemTran%535078830178.declarations

} // namespace configuration

//## begin module%535078BD0255.epilog preserve=yes
//## end module%535078BD0255.epilog
