//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4535B04E024C.cm preserve=no
//	$Date:   Oct 19 2006 05:09:16  $ $Author:   D04832  $
//	$Revision:   1.0  $
//## end module%4535B04E024C.cm

//## begin module%4535B04E024C.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%4535B04E024C.cp

//## Module: CXOSCF88%4535B04E024C; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF88.hpp

#ifndef CXOSCF88_h
#define CXOSCF88_h 1

//## begin module%4535B04E024C.additionalIncludes preserve=no
//## end module%4535B04E024C.additionalIncludes

//## begin module%4535B04E024C.includes preserve=yes
//## end module%4535B04E024C.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%4535B04E024C.declarations preserve=no
//## end module%4535B04E024C.declarations

//## begin module%4535B04E024C.additionalDeclarations preserve=yes
//## end module%4535B04E024C.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::MCIPMProcessCode%4535B1D80068.preface preserve=yes
//## end configuration::MCIPMProcessCode%4535B1D80068.preface

//## Class: MCIPMProcessCode%4535B1D80068
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4535B602002E;reusable::Query { -> F}
//## Uses: <unnamed>%4535B608027C;IF::Extract { -> F}

class DllExport MCIPMProcessCode : public ConversionItem  //## Inherits: <unnamed>%4535B74100A5
{
  //## begin configuration::MCIPMProcessCode%4535B1D80068.initialDeclarations preserve=yes
  //## end configuration::MCIPMProcessCode%4535B1D80068.initialDeclarations

  public:
    //## Constructors (generated)
      MCIPMProcessCode();

    //## Destructor (generated)
      virtual ~MCIPMProcessCode();


    //## Other Operations (specified)
      //## Operation: bind%4535B5210360
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getFirst%4535B5210374
      virtual const string& getFirst ();

      //## Operation: getSecond%4535B5210388
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::MCIPMProcessCode%4535B1D80068.public preserve=yes
      //## end configuration::MCIPMProcessCode%4535B1D80068.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::MCIPMProcessCode%4535B1D80068.protected preserve=yes
      //## end configuration::MCIPMProcessCode%4535B1D80068.protected

  private:
    // Additional Private Declarations
      //## begin configuration::MCIPMProcessCode%4535B1D80068.private preserve=yes
      //## end configuration::MCIPMProcessCode%4535B1D80068.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: PROCESS_CODE%4535B4CC0213
      //## begin configuration::MCIPMProcessCode::PROCESS_CODE%4535B4CC0213.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::MCIPMProcessCode::PROCESS_CODE%4535B4CC0213.attr

      //## Attribute: MSG_CLASS%4535B4CC0227
      //## begin configuration::MCIPMProcessCode::MSG_CLASS%4535B4CC0227.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::MCIPMProcessCode::MSG_CLASS%4535B4CC0227.attr

      //## Attribute: PRE_AUTH%4535B4CC023B
      //## begin configuration::MCIPMProcessCode::PRE_AUTH%4535B4CC023B.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::MCIPMProcessCode::PRE_AUTH%4535B4CC023B.attr

      //## Attribute: MCIPM_PROCESS_CODE%4535B4CC0245
      //## begin configuration::MCIPMProcessCode::MCIPM_PROCESS_CODE%4535B4CC0245.attr preserve=no  private: string {U} 
      string m_strMCIPM_PROCESS_CODE;
      //## end configuration::MCIPMProcessCode::MCIPM_PROCESS_CODE%4535B4CC0245.attr

      //## Attribute: MEDIA_TYPE%4535B4CC025A
      //## begin configuration::MCIPMProcessCode::MEDIA_TYPE%4535B4CC025A.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::MCIPMProcessCode::MEDIA_TYPE%4535B4CC025A.attr

    // Additional Implementation Declarations
      //## begin configuration::MCIPMProcessCode%4535B1D80068.implementation preserve=yes
      //## end configuration::MCIPMProcessCode%4535B1D80068.implementation

};

//## begin configuration::MCIPMProcessCode%4535B1D80068.postscript preserve=yes
//## end configuration::MCIPMProcessCode%4535B1D80068.postscript

} // namespace configuration

//## begin module%4535B04E024C.epilog preserve=yes
//## end module%4535B04E024C.epilog


#endif
