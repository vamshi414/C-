//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%391C0E2A00B2.cm preserve=no
//	$Date:   Dec 16 2016 15:06:06  $ $Author:   e1009652  $
//	$Revision:   1.6  $
//## end module%391C0E2A00B2.cm

//## begin module%391C0E2A00B2.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%391C0E2A00B2.cp

//## Module: CXOSCF20%391C0E2A00B2; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF20.cpp

//## begin module%391C0E2A00B2.additionalIncludes preserve=no
//## end module%391C0E2A00B2.additionalIncludes

//## begin module%391C0E2A00B2.includes preserve=yes
// $Date:   Dec 16 2016 15:06:06  $ $Author:   e1009652  $ $Revision:   1.6  $
//## end module%391C0E2A00B2.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF20_h
#include "CXODCF20.hpp"
#endif


//## begin module%391C0E2A00B2.declarations preserve=no
//## end module%391C0E2A00B2.declarations

//## begin module%391C0E2A00B2.additionalDeclarations preserve=yes
//## end module%391C0E2A00B2.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexMessageTypeIdentifier 

ConnexMessageTypeIdentifier::ConnexMessageTypeIdentifier()
  //## begin ConnexMessageTypeIdentifier::ConnexMessageTypeIdentifier%391C0CCE015C_const.hasinit preserve=no
  //## end ConnexMessageTypeIdentifier::ConnexMessageTypeIdentifier%391C0CCE015C_const.hasinit
  //## begin ConnexMessageTypeIdentifier::ConnexMessageTypeIdentifier%391C0CCE015C_const.initialization preserve=yes
   : ConversionItem("## CR23 XLATE CONNEX MESSAGE ID")
  //## end ConnexMessageTypeIdentifier::ConnexMessageTypeIdentifier%391C0CCE015C_const.initialization
{
  //## begin configuration::ConnexMessageTypeIdentifier::ConnexMessageTypeIdentifier%391C0CCE015C_const.body preserve=yes
   memcpy(m_sID,"CF20",4);
  //## end configuration::ConnexMessageTypeIdentifier::ConnexMessageTypeIdentifier%391C0CCE015C_const.body
}


ConnexMessageTypeIdentifier::~ConnexMessageTypeIdentifier()
{
  //## begin configuration::ConnexMessageTypeIdentifier::~ConnexMessageTypeIdentifier%391C0CCE015C_dest.body preserve=yes
  //## end configuration::ConnexMessageTypeIdentifier::~ConnexMessageTypeIdentifier%391C0CCE015C_dest.body
}



//## Other Operations (implementation)
void ConnexMessageTypeIdentifier::bind (Query& hQuery)
{
  //## begin configuration::ConnexMessageTypeIdentifier::bind%391C1C10014E.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_IBM_MSG_TYPE_ID");
   hQuery.bind("X_IBM_MSG_TYPE_ID","IBM_MESSAGE_ID",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_MSG_TYPE_ID","MTI",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_IBM_MSG_TYPE_ID","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_MSG_TYPE_ID","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IBM_MSG_TYPE_ID.IBM_MESSAGE_ID ASC");
  //## end configuration::ConnexMessageTypeIdentifier::bind%391C1C10014E.body
}

void ConnexMessageTypeIdentifier::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexMessageTypeIdentifier::setPredicate%584719110306.body preserve=yes
   hQuery.setBasicPredicate("X_IBM_MSG_TYPE_ID", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IBM_MSG_TYPE_ID", "CC_STATE", "=", "A");
  //## end configuration::ConnexMessageTypeIdentifier::setPredicate%584719110306.body
}

// Additional Declarations
  //## begin configuration::ConnexMessageTypeIdentifier%391C0CCE015C.declarations preserve=yes
  //## end configuration::ConnexMessageTypeIdentifier%391C0CCE015C.declarations

} // namespace configuration

//## begin module%391C0E2A00B2.epilog preserve=yes
//## end module%391C0E2A00B2.epilog
