//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%393E6AE200FB.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%393E6AE200FB.cm

//## begin module%393E6AE200FB.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%393E6AE200FB.cp

//## Module: CXOSCF28%393E6AE200FB; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF28.cpp

//## begin module%393E6AE200FB.additionalIncludes preserve=no
//## end module%393E6AE200FB.additionalIncludes

//## begin module%393E6AE200FB.includes preserve=yes
// $Date:   May 26 2020 10:44:46  $ $Author:   e1009510  $ $Revision:   1.11  $
#include <stdio.h>
//## end module%393E6AE200FB.includes

#ifndef CXOSCF28_h
#include "CXODCF28.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%393E6AE200FB.declarations preserve=no
//## end module%393E6AE200FB.declarations

//## begin module%393E6AE200FB.additionalDeclarations preserve=yes
//## end module%393E6AE200FB.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::FinancialType


FinancialType::FinancialType()
  //## begin FinancialType::FinancialType%393E6D5002A4_const.hasinit preserve=no
  //## end FinancialType::FinancialType%393E6D5002A4_const.hasinit
  //## begin FinancialType::FinancialType%393E6D5002A4_const.initialization preserve=yes
   : VerificationItem("## CR29 VERIFY FIN TYPE")
  //## end FinancialType::FinancialType%393E6D5002A4_const.initialization
{
  //## begin configuration::FinancialType::FinancialType%393E6D5002A4_const.body preserve=yes
   memcpy(m_sID,"CF28",4);
  //## end configuration::FinancialType::FinancialType%393E6D5002A4_const.body
}


FinancialType::~FinancialType()
{
  //## begin configuration::FinancialType::~FinancialType%393E6D5002A4_dest.body preserve=yes
  //## end configuration::FinancialType::~FinancialType%393E6D5002A4_dest.body
}



//## Other Operations (implementation)
void FinancialType::bind (Query& hQuery)
{
  //## begin configuration::FinancialType::bind%393E757A0317.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","FIN_TRAN_TYPE");
   hQuery.bind("FIN_TRAN_TYPE","FIN_TRAN_TYPE",Column::LONG,&m_lFIN_TRAN_TYPE);
   hQuery.bind("FIN_TRAN_TYPE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("FIN_TRAN_TYPE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("FIN_TRAN_TYPE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("FIN_TRAN_TYPE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("FIN_TRAN_TYPE.CUST_ID DESC");
  //## end configuration::FinancialType::bind%393E757A0317.body
}

const string& FinancialType::getKey ()
{
  //## begin configuration::FinancialType::getKey%3943A3C10367.body preserve=yes
   char tempChar[4];
   snprintf(tempChar,sizeof(tempChar), "%03d", m_lFIN_TRAN_TYPE);
   m_strKey = tempChar;
   return m_strKey;
  //## end configuration::FinancialType::getKey%3943A3C10367.body
}

// Additional Declarations
  //## begin configuration::FinancialType%393E6D5002A4.declarations preserve=yes
  //## end configuration::FinancialType%393E6D5002A4.declarations

} // namespace configuration

//## begin module%393E6AE200FB.epilog preserve=yes
//## end module%393E6AE200FB.epilog
