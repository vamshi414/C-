//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%5190FFB20374.cm preserve=no
//	$Date:   May 16 2013 12:40:40  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5190FFB20374.cm

//## begin module%5190FFB20374.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5190FFB20374.cp

//## Module: CXOSCFA1%5190FFB20374; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCFA1.hpp

#ifndef CXOSCFA1_h
#define CXOSCFA1_h 1

//## begin module%5190FFB20374.additionalIncludes preserve=no
//## end module%5190FFB20374.additionalIncludes

//## begin module%5190FFB20374.includes preserve=yes
//## end module%5190FFB20374.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%5190FFB20374.declarations preserve=no
//## end module%5190FFB20374.declarations

//## begin module%5190FFB20374.additionalDeclarations preserve=yes
//## end module%5190FFB20374.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::DeviceRevAll%5190FF4602D1.preface preserve=yes
//## end configuration::DeviceRevAll%5190FF4602D1.preface

//## Class: DeviceRevAll%5190FF4602D1
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%519100930385;reusable::Query { -> F}
//## Uses: <unnamed>%51910096033A;IF::Extract { -> F}

class DllExport DeviceRevAll : public ConversionItem  //## Inherits: <unnamed>%5191009101B5
{
  //## begin configuration::DeviceRevAll%5190FF4602D1.initialDeclarations preserve=yes
  //## end configuration::DeviceRevAll%5190FF4602D1.initialDeclarations

  public:
    //## Constructors (generated)
      DeviceRevAll();

    //## Destructor (generated)
      virtual ~DeviceRevAll();


    //## Other Operations (specified)
      //## Operation: bind%519100A900DF
      virtual void bind (reusable::Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::DeviceRevAll%5190FF4602D1.public preserve=yes
      //## end configuration::DeviceRevAll%5190FF4602D1.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::DeviceRevAll%5190FF4602D1.protected preserve=yes
      //## end configuration::DeviceRevAll%5190FF4602D1.protected

  private:
    // Additional Private Declarations
      //## begin configuration::DeviceRevAll%5190FF4602D1.private preserve=yes
      //## end configuration::DeviceRevAll%5190FF4602D1.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::DeviceRevAll%5190FF4602D1.implementation preserve=yes
      //## end configuration::DeviceRevAll%5190FF4602D1.implementation

};

//## begin configuration::DeviceRevAll%5190FF4602D1.postscript preserve=yes
//## end configuration::DeviceRevAll%5190FF4602D1.postscript

} // namespace configuration

//## begin module%5190FFB20374.epilog preserve=yes
//## end module%5190FFB20374.epilog


#endif
