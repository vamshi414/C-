//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%391C0DE3002D.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%391C0DE3002D.cm

//## begin module%391C0DE3002D.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%391C0DE3002D.cp

//## Module: CXOSCF11%391C0DE3002D; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF11.cpp

//## begin module%391C0DE3002D.additionalIncludes preserve=no
//## end module%391C0DE3002D.additionalIncludes

//## begin module%391C0DE3002D.includes preserve=yes
// $Date:   Apr 17 2014 20:59:18  $ $Author:   e1009652  $ $Revision:   1.7  $
//## end module%391C0DE3002D.includes

#ifndef CXOSCF11_h
#include "CXODCF11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%391C0DE3002D.declarations preserve=no
//## end module%391C0DE3002D.declarations

//## begin module%391C0DE3002D.additionalDeclarations preserve=yes
//## end module%391C0DE3002D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::CirrusProcessCode





CirrusProcessCode::CirrusProcessCode()
  //## begin CirrusProcessCode::CirrusProcessCode%391C0C54021E_const.hasinit preserve=no
  //## end CirrusProcessCode::CirrusProcessCode%391C0C54021E_const.hasinit
  //## begin CirrusProcessCode::CirrusProcessCode%391C0C54021E_const.initialization preserve=yes
   : ConversionItem("## CR14 XLATE CIRR PROCESS CODE")
  //## end CirrusProcessCode::CirrusProcessCode%391C0C54021E_const.initialization
{
  //## begin configuration::CirrusProcessCode::CirrusProcessCode%391C0C54021E_const.body preserve=yes
   memcpy(m_sID,"CF11",4);
  //## end configuration::CirrusProcessCode::CirrusProcessCode%391C0C54021E_const.body
}


CirrusProcessCode::~CirrusProcessCode()
{
  //## begin configuration::CirrusProcessCode::~CirrusProcessCode%391C0C54021E_dest.body preserve=yes
  //## end configuration::CirrusProcessCode::~CirrusProcessCode%391C0C54021E_dest.body
}



//## Other Operations (implementation)
void CirrusProcessCode::bind (Query& hQuery)
{
  //## begin configuration::CirrusProcessCode::bind%391C1B55005F.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_CIRR_PROC_CODE");
   hQuery.bind("X_CIRR_PROC_CODE","CIRR_PROCESS_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_CIRR_PROC_CODE","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("X_CIRR_PROC_CODE","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("X_CIRR_PROC_CODE","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("X_CIRR_PROC_CODE","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("X_CIRR_PROC_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_CIRR_PROC_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_CIRR_PROC_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_CIRR_PROC_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_CIRR_PROC_CODE.CIRR_PROCESS_CODE ASC,X_CIRR_PROC_CODE.CUST_ID DESC");
  //## end configuration::CirrusProcessCode::bind%391C1B55005F.body
}

const string& CirrusProcessCode::getSecond ()
{
  //## begin configuration::CirrusProcessCode::getSecond%391C1B6A01B4.body preserve=yes
   while (m_strPROCESS_CODE.length() < 6)
      m_strPROCESS_CODE += ' ';
   while (m_strMSG_CLASS.length() < 1)
      m_strMSG_CLASS += ' ';
   while (m_strPRE_AUTH.length() < 1)
      m_strPRE_AUTH += ' ';
   m_strSecond = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strSecond;
  //## end configuration::CirrusProcessCode::getSecond%391C1B6A01B4.body
}

// Additional Declarations
  //## begin configuration::CirrusProcessCode%391C0C54021E.declarations preserve=yes
  //## end configuration::CirrusProcessCode%391C0C54021E.declarations

} // namespace configuration

//## begin module%391C0DE3002D.epilog preserve=yes
//## end module%391C0DE3002D.epilog
