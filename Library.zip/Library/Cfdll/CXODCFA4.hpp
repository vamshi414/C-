//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%56D6E2870221.cm preserve=no
//## end module%56D6E2870221.cm

//## begin module%56D6E2870221.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%56D6E2870221.cp

//## Module: CXOSCFA4%56D6E2870221; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXODCFA4.hpp

#ifndef CXOSCFA4_h
#define CXOSCFA4_h 1

//## begin module%56D6E2870221.additionalIncludes preserve=no
//## end module%56D6E2870221.additionalIncludes

//## begin module%56D6E2870221.includes preserve=yes
//## end module%56D6E2870221.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%56D6E2870221.declarations preserve=no
//## end module%56D6E2870221.declarations

//## begin module%56D6E2870221.additionalDeclarations preserve=yes
//## end module%56D6E2870221.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::GenericReverse%56D6DE670169.preface preserve=yes
//## end configuration::GenericReverse%56D6DE670169.preface

//## Class: GenericReverse%56D6DE670169
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%56D6DE8A022A;reusable::Query { -> F}

class DllExport GenericReverse : public ConversionItem  //## Inherits: <unnamed>%56D6DE86022F
{
  //## begin configuration::GenericReverse%56D6DE670169.initialDeclarations preserve=yes
  //## end configuration::GenericReverse%56D6DE670169.initialDeclarations

  public:
    //## Constructors (generated)
      GenericReverse();

    //## Constructors (specified)
      //## Operation: GenericReverse%639AA00303E2
      GenericReverse (const char* pszX_TYPE);

    //## Destructor (generated)
      virtual ~GenericReverse();


    //## Other Operations (specified)
      //## Operation: bind%56D6DEDC034D
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%56D6E13001D0
      virtual const string& getFirst ();

      //## Operation: setPredicate%5847173A0120
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::GenericReverse%56D6DE670169.public preserve=yes
      //## end configuration::GenericReverse%56D6DE670169.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::GenericReverse%56D6DE670169.protected preserve=yes
      //## end configuration::GenericReverse%56D6DE670169.protected

  private:
    // Additional Private Declarations
      //## begin configuration::GenericReverse%56D6DE670169.private preserve=yes
      //## end configuration::GenericReverse%56D6DE670169.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: TO_VALUE%56D6DEB5029F
      //## begin configuration::GenericReverse::TO_VALUE%56D6DEB5029F.attr preserve=no  private: string {V} 
      string m_strTO_VALUE;
      //## end configuration::GenericReverse::TO_VALUE%56D6DEB5029F.attr

      //## Attribute: X_TYPE%639A9F730018
      //## begin configuration::GenericReverse::X_TYPE%639A9F730018.attr preserve=no  private: string {U} 
      string m_strX_TYPE;
      //## end configuration::GenericReverse::X_TYPE%639A9F730018.attr

    // Additional Implementation Declarations
      //## begin configuration::GenericReverse%56D6DE670169.implementation preserve=yes
      //## end configuration::GenericReverse%56D6DE670169.implementation

};

//## begin configuration::GenericReverse%56D6DE670169.postscript preserve=yes
//## end configuration::GenericReverse%56D6DE670169.postscript

} // namespace configuration

//## begin module%56D6E2870221.epilog preserve=yes
//## end module%56D6E2870221.epilog


#endif
