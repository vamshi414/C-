//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39D0E42303A3.cm preserve=no
//	$Date:   Dec 16 2016 15:15:16  $ $Author:   e1009652  $
//	$Revision:   1.7  $
//## end module%39D0E42303A3.cm

//## begin module%39D0E42303A3.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39D0E42303A3.cp

//## Module: CXOSCF38%39D0E42303A3; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF38.cpp

//## begin module%39D0E42303A3.additionalIncludes preserve=no
//## end module%39D0E42303A3.additionalIncludes

//## begin module%39D0E42303A3.includes preserve=yes
// $Date:   Dec 16 2016 15:15:16  $ $Author:   e1009652  $ $Revision:   1.7  $
//## end module%39D0E42303A3.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF38_h
#include "CXODCF38.hpp"
#endif


//## begin module%39D0E42303A3.declarations preserve=no
//## end module%39D0E42303A3.declarations

//## begin module%39D0E42303A3.additionalDeclarations preserve=yes
//## end module%39D0E42303A3.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::LowCash 

LowCash::LowCash()
  //## begin LowCash::LowCash%39D0E70C02FA_const.hasinit preserve=no
  //## end LowCash::LowCash%39D0E70C02FA_const.hasinit
  //## begin LowCash::LowCash%39D0E70C02FA_const.initialization preserve=yes
   : ConversionItem("## CR38 CHAIN SUBJECT STATE")
  //## end LowCash::LowCash%39D0E70C02FA_const.initialization
{
  //## begin configuration::LowCash::LowCash%39D0E70C02FA_const.body preserve=yes
   memcpy(m_sID,"CF38",4);
  //## end configuration::LowCash::LowCash%39D0E70C02FA_const.body
}


LowCash::~LowCash()
{
  //## begin configuration::LowCash::~LowCash%39D0E70C02FA_dest.body preserve=yes
  //## end configuration::LowCash::~LowCash%39D0E70C02FA_dest.body
}



//## Other Operations (implementation)
void LowCash::bind (Query& hQuery)
{
  //## begin configuration::LowCash::bind%39D0E741030A.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_DEV_LOW_CASH_FLG");
   hQuery.bind("X_DEV_LOW_CASH_FLG","SUBJECT_STATE_RESN",Column::STRING,&m_strFirst);
   hQuery.bind("X_DEV_LOW_CASH_FLG","LOW_CASH_FLG_VALUE",Column::STRING,&m_strSecond);
   hQuery.setOrderByClause("X_DEV_LOW_CASH_FLG.SUBJECT_STATE_RESN ASC");
  //## end configuration::LowCash::bind%39D0E741030A.body
}

void LowCash::setPredicate (Query& hQuery)
{
  //## begin configuration::LowCash::setPredicate%584717930052.body preserve=yes
   //Do nothing! This method is just to override base class behaviour.
  //## end configuration::LowCash::setPredicate%584717930052.body
}

// Additional Declarations
  //## begin configuration::LowCash%39D0E70C02FA.declarations preserve=yes
  //## end configuration::LowCash%39D0E70C02FA.declarations

} // namespace configuration

//## begin module%39D0E42303A3.epilog preserve=yes
//## end module%39D0E42303A3.epilog
