//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3ACA17CA02E0.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3ACA17CA02E0.cm

//## begin module%3ACA17CA02E0.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%3ACA17CA02E0.cp

//## Module: CXOSCF39%3ACA17CA02E0; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF39.hpp

#ifndef CXOSCF39_h
#define CXOSCF39_h 1

//## begin module%3ACA17CA02E0.additionalIncludes preserve=no
//## end module%3ACA17CA02E0.additionalIncludes

//## begin module%3ACA17CA02E0.includes preserve=yes
// $Date:   Mar 26 2009 13:40:54  $ $Author:   D92233  $ $Revision:   1.4  $
#include <map>
//## end module%3ACA17CA02E0.includes

#ifndef CXOSCF32_h
#include "CXODCF32.hpp"
#endif

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class Count;

} // namespace monitor

//## begin module%3ACA17CA02E0.declarations preserve=no
//## end module%3ACA17CA02E0.declarations

//## begin module%3ACA17CA02E0.additionalDeclarations preserve=yes
//## end module%3ACA17CA02E0.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::MappingTable%3ACA134A0013.preface preserve=yes
//## end configuration::MappingTable%3ACA134A0013.preface

//## Class: MappingTable%3ACA134A0013
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3ACA15C80291;monitor::Count { -> F}

class DllExport MappingTable : public ConfigurationTable  //## Inherits: <unnamed>%3ACA15220080
{
  //## begin configuration::MappingTable%3ACA134A0013.initialDeclarations preserve=yes
  //## end configuration::MappingTable%3ACA134A0013.initialDeclarations

  public:
    //## Constructors (generated)
      MappingTable();

    //## Constructors (specified)
      //## Operation: MappingTable%3ACA1646008A
      MappingTable (const char* pszName);

    //## Destructor (generated)
      virtual ~MappingTable();


    //## Other Operations (specified)
      //## Operation: add%3ACA169A03A2
      bool add (const string& strPrimary, const string& strSecondary, const string& strTertiary, const string& strResult);

      //## Operation: find%3ACA16A102B1
      bool find (const string& strPrimary, const string& strSecondary, const string& strTertiary, string& strResult);

      //## Operation: getType%3ACCD97202A9
      virtual Type getType ()
      {
        //## begin configuration::MappingTable::getType%3ACCD97202A9.body preserve=yes
          return ConfigurationTable::MAPPING;
        //## end configuration::MappingTable::getType%3ACCD97202A9.body
      }

      //## Operation: size%3AD4BEE20398
      short int size ()
      {
        //## begin configuration::MappingTable::size%3AD4BEE20398.body preserve=yes
          return m_hMapData.size();
        //## end configuration::MappingTable::size%3AD4BEE20398.body
      }

    // Additional Public Declarations
      //## begin configuration::MappingTable%3ACA134A0013.public preserve=yes
      //## end configuration::MappingTable%3ACA134A0013.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::MappingTable%3ACA134A0013.protected preserve=yes
      //## end configuration::MappingTable%3ACA134A0013.protected

  private:
    // Additional Private Declarations
      //## begin configuration::MappingTable%3ACA134A0013.private preserve=yes
      //## end configuration::MappingTable%3ACA134A0013.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: MapData%49CB8C8A0103
      //## begin configuration::MappingTable::MapData%49CB8C8A0103.attr preserve=no  private: map<string,string,less<string> > {U} 
      map<string,string,less<string> > m_hMapData;
      //## end configuration::MappingTable::MapData%49CB8C8A0103.attr

    // Additional Implementation Declarations
      //## begin configuration::MappingTable%3ACA134A0013.implementation preserve=yes
      //## end configuration::MappingTable%3ACA134A0013.implementation

};

//## begin configuration::MappingTable%3ACA134A0013.postscript preserve=yes
//## end configuration::MappingTable%3ACA134A0013.postscript

} // namespace configuration

//## begin module%3ACA17CA02E0.epilog preserve=yes
using namespace configuration;
//## end module%3ACA17CA02E0.epilog


#endif
