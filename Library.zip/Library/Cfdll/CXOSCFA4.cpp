//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%56D6E2890115.cm preserve=no
//## end module%56D6E2890115.cm

//## begin module%56D6E2890115.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%56D6E2890115.cp

//## Module: CXOSCFA4%56D6E2890115; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFA4.cpp

//## begin module%56D6E2890115.additionalIncludes preserve=no
//## end module%56D6E2890115.additionalIncludes

//## begin module%56D6E2890115.includes preserve=yes
//## end module%56D6E2890115.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFA4_h
#include "CXODCFA4.hpp"
#endif


//## begin module%56D6E2890115.declarations preserve=no
//## end module%56D6E2890115.declarations

//## begin module%56D6E2890115.additionalDeclarations preserve=yes
//## end module%56D6E2890115.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::GenericReverse 

GenericReverse::GenericReverse()
  //## begin GenericReverse::GenericReverse%56D6DE670169_const.hasinit preserve=no
  //## end GenericReverse::GenericReverse%56D6DE670169_const.hasinit
  //## begin GenericReverse::GenericReverse%56D6DE670169_const.initialization preserve=yes
  : ConversionItem("## CFA4 XLATE ~X_GENERIC")
  //## end GenericReverse::GenericReverse%56D6DE670169_const.initialization
{
  //## begin configuration::GenericReverse::GenericReverse%56D6DE670169_const.body preserve=yes
   memcpy(m_sID,"CFA4",4);
  //## end configuration::GenericReverse::GenericReverse%56D6DE670169_const.body
}

GenericReverse::GenericReverse (const char* pszX_TYPE)
  //## begin configuration::GenericReverse::GenericReverse%639AA00303E2.hasinit preserve=no
  //## end configuration::GenericReverse::GenericReverse%639AA00303E2.hasinit
  //## begin configuration::GenericReverse::GenericReverse%639AA00303E2.initialization preserve=yes
   : ConversionItem("## CFA4 XLATE ~X_GENERIC")
   , m_strX_TYPE(pszX_TYPE + 1)
  //## end configuration::GenericReverse::GenericReverse%639AA00303E2.initialization
{
  //## begin configuration::GenericReverse::GenericReverse%639AA00303E2.body preserve=yes
   memcpy(m_sID,"CFA4",4);
  //## end configuration::GenericReverse::GenericReverse%639AA00303E2.body
}


GenericReverse::~GenericReverse()
{
  //## begin configuration::GenericReverse::~GenericReverse%56D6DE670169_dest.body preserve=yes
  //## end configuration::GenericReverse::~GenericReverse%56D6DE670169_dest.body
}



//## Other Operations (implementation)
void GenericReverse::bind (Query& hQuery)
{
  //## begin configuration::GenericReverse::bind%56D6DEDC034D.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_GENERIC");
   hQuery.bind("X_GENERIC","X_TYPE",Column::STRING,&m_strFirst);
   hQuery.bind("X_GENERIC","TO_VALUE",Column::STRING,&m_strTO_VALUE);
   hQuery.bind("X_GENERIC","FROM_VALUE",Column::STRING,&m_strSecond);
   if (!m_strX_TYPE.empty())
      hQuery.setBasicPredicate("X_GENERIC","X_TYPE","=",m_strX_TYPE.c_str());
   hQuery.setBasicPredicate("X_GENERIC","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_GENERIC","CC_STATE","=","A");
   hQuery.setOrderByClause("X_TYPE,TO_VALUE");
  //## end configuration::GenericReverse::bind%56D6DEDC034D.body
}

const string& GenericReverse::getFirst ()
{
  //## begin configuration::GenericReverse::getFirst%56D6E13001D0.body preserve=yes
   if (!m_strX_TYPE.empty())
      return m_strTO_VALUE;
   m_strFirst.resize(15, ' ');
   m_strTO_VALUE.resize(20, ' ');
   m_strFirst += m_strTO_VALUE;
   return m_strFirst;
  //## end configuration::GenericReverse::getFirst%56D6E13001D0.body
}

void GenericReverse::setPredicate (Query& hQuery)
{
  //## begin configuration::GenericReverse::setPredicate%5847173A0120.body preserve=yes
   if (!m_strX_TYPE.empty())
      hQuery.setBasicPredicate("X_GENERIC","X_TYPE","=",m_strX_TYPE.c_str());
   hQuery.setBasicPredicate("X_GENERIC", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_GENERIC", "CC_STATE", "=", "A");
  //## end configuration::GenericReverse::setPredicate%5847173A0120.body
}

// Additional Declarations
  //## begin configuration::GenericReverse%56D6DE670169.declarations preserve=yes
  //## end configuration::GenericReverse%56D6DE670169.declarations

} // namespace configuration

//## begin module%56D6E2890115.epilog preserve=yes
//## end module%56D6E2890115.epilog
