//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5907468A0376.cm preserve=no
//	$Date:   Jun 15 2017 15:29:36  $ $Author:   e1094689  $
//	$Revision:   1.1  $
//## end module%5907468A0376.cm

//## begin module%5907468A0376.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5907468A0376.cp

//## Module: CXOSCFA6%5907468A0376; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.8A.R004\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFA6.cpp

//## begin module%5907468A0376.additionalIncludes preserve=no
//## end module%5907468A0376.additionalIncludes

//## begin module%5907468A0376.includes preserve=yes
//## end module%5907468A0376.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCFA6_h
#include "CXODCFA6.hpp"
#endif


//## begin module%5907468A0376.declarations preserve=no
//## end module%5907468A0376.declarations

//## begin module%5907468A0376.additionalDeclarations preserve=yes
//## end module%5907468A0376.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::BankIDInstitution 

BankIDInstitution::BankIDInstitution()
  //## begin BankIDInstitution::BankIDInstitution%5907451A0041_const.hasinit preserve=no
  //## end BankIDInstitution::BankIDInstitution%5907451A0041_const.hasinit
  //## begin BankIDInstitution::BankIDInstitution%5907451A0041_const.initialization preserve=yes
  //## end BankIDInstitution::BankIDInstitution%5907451A0041_const.initialization
{
  //## begin configuration::BankIDInstitution::BankIDInstitution%5907451A0041_const.body preserve=yes
   memcpy(m_sID,"CFA6",4);
  //## end configuration::BankIDInstitution::BankIDInstitution%5907451A0041_const.body
}


BankIDInstitution::~BankIDInstitution()
{
  //## begin configuration::BankIDInstitution::~BankIDInstitution%5907451A0041_dest.body preserve=yes
  //## end configuration::BankIDInstitution::~BankIDInstitution%5907451A0041_dest.body
}



//## Other Operations (implementation)
void BankIDInstitution::bind (Query& hQuery)
{
  //## begin configuration::BankIDInstitution::bind%5907455F03C3.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","INSTITUTION");
   hQuery.bind("INSTITUTION","BANK_ID",Column::STRING,&m_strFirst);
   hQuery.bind("INSTITUTION","INST_ID",Column::STRING,&m_strSecond);
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("INSTITUTION","BANK_ID","<>"," ");
   hQuery.setBasicPredicate("INSTITUTION","CUST_ID","IN",strTemp.c_str());
   hQuery.setBasicPredicate("INSTITUTION", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("INSTITUTION", "CC_STATE", "=", "A");
   hQuery.setOrderByClause("INSTITUTION.BANK_ID ASC");
  //## end configuration::BankIDInstitution::bind%5907455F03C3.body
}

void BankIDInstitution::setPredicate (Query& hQuery)
{
  //## begin configuration::BankIDInstitution::setPredicate%5907455F03C7.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("INSTITUTION", "CUST_ID", "IN", strTemp.c_str());
  //## end configuration::BankIDInstitution::setPredicate%5907455F03C7.body
}

// Additional Declarations
  //## begin configuration::BankIDInstitution%5907451A0041.declarations preserve=yes
  //## end configuration::BankIDInstitution%5907451A0041.declarations

} // namespace configuration

//## begin module%5907468A0376.epilog preserve=yes
//## end module%5907468A0376.epilog
