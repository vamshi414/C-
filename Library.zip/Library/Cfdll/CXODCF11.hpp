//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%391C10C60044.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%391C10C60044.cm

//## begin module%391C10C60044.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%391C10C60044.cp

//## Module: CXOSCF11%391C10C60044; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF11.hpp

#ifndef CXOSCF11_h
#define CXOSCF11_h 1

//## begin module%391C10C60044.additionalIncludes preserve=no
//## end module%391C10C60044.additionalIncludes

//## begin module%391C10C60044.includes preserve=yes
// $Date:   Apr 08 2004 14:10:50  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%391C10C60044.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%391C10C60044.declarations preserve=no
//## end module%391C10C60044.declarations

//## begin module%391C10C60044.additionalDeclarations preserve=yes
//## end module%391C10C60044.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::CirrusProcessCode%391C0C54021E.preface preserve=yes
//## end configuration::CirrusProcessCode%391C0C54021E.preface

//## Class: CirrusProcessCode%391C0C54021E
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%391C159C01C1;ConversionItem { -> F}
//## Uses: <unnamed>%391C15A2007F;IF::Extract { -> F}
//## Uses: <unnamed>%391C15A40277;reusable::Query { -> F}

class DllExport CirrusProcessCode : public ConversionItem  //## Inherits: <unnamed>%391C159F0388
{
  //## begin configuration::CirrusProcessCode%391C0C54021E.initialDeclarations preserve=yes
  //## end configuration::CirrusProcessCode%391C0C54021E.initialDeclarations

  public:
    //## Constructors (generated)
      CirrusProcessCode();

    //## Destructor (generated)
      virtual ~CirrusProcessCode();


    //## Other Operations (specified)
      //## Operation: bind%391C1B55005F
      virtual void bind (Query& hQuery);

      //## Operation: getSecond%391C1B6A01B4
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::CirrusProcessCode%391C0C54021E.public preserve=yes
      //## end configuration::CirrusProcessCode%391C0C54021E.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::CirrusProcessCode%391C0C54021E.protected preserve=yes
      //## end configuration::CirrusProcessCode%391C0C54021E.protected

  private:
    // Additional Private Declarations
      //## begin configuration::CirrusProcessCode%391C0C54021E.private preserve=yes
      //## end configuration::CirrusProcessCode%391C0C54021E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: PROCESS_CODE%391C1B850054
      //## begin configuration::CirrusProcessCode::PROCESS_CODE%391C1B850054.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::CirrusProcessCode::PROCESS_CODE%391C1B850054.attr

      //## Attribute: MSG_CLASS%391C1B850055
      //## begin configuration::CirrusProcessCode::MSG_CLASS%391C1B850055.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::CirrusProcessCode::MSG_CLASS%391C1B850055.attr

      //## Attribute: PRE_AUTH%391C1B85005E
      //## begin configuration::CirrusProcessCode::PRE_AUTH%391C1B85005E.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::CirrusProcessCode::PRE_AUTH%391C1B85005E.attr

      //## Attribute: MEDIA_TYPE%3920527B02EF
      //## begin configuration::CirrusProcessCode::MEDIA_TYPE%3920527B02EF.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::CirrusProcessCode::MEDIA_TYPE%3920527B02EF.attr

    // Additional Implementation Declarations
      //## begin configuration::CirrusProcessCode%391C0C54021E.implementation preserve=yes
      //## end configuration::CirrusProcessCode%391C0C54021E.implementation

};

//## begin configuration::CirrusProcessCode%391C0C54021E.postscript preserve=yes
//## end configuration::CirrusProcessCode%391C0C54021E.postscript

} // namespace configuration

//## begin module%391C10C60044.epilog preserve=yes
using namespace configuration;
//## end module%391C10C60044.epilog


#endif
