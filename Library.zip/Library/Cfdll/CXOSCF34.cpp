//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%39985CA20268.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%39985CA20268.cm

//## begin module%39985CA20268.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%39985CA20268.cp

//## Module: CXOSCF34%39985CA20268; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF34.cpp

//## begin module%39985CA20268.additionalIncludes preserve=no
//## end module%39985CA20268.additionalIncludes

//## begin module%39985CA20268.includes preserve=yes
// $Date:   Apr 17 2014 21:00:22  $ $Author:   e1009652  $ $Revision:   1.5  $
//## end module%39985CA20268.includes

#ifndef CXOSCF34_h
#include "CXODCF34.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%39985CA20268.declarations preserve=no
//## end module%39985CA20268.declarations

//## begin module%39985CA20268.additionalDeclarations preserve=yes
//## end module%39985CA20268.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::Base24POSProcessCode





Base24POSProcessCode::Base24POSProcessCode()
  //## begin Base24POSProcessCode::Base24POSProcessCode%39985CDD029F_const.hasinit preserve=no
  //## end Base24POSProcessCode::Base24POSProcessCode%39985CDD029F_const.hasinit
  //## begin Base24POSProcessCode::Base24POSProcessCode%39985CDD029F_const.initialization preserve=yes
  //## end Base24POSProcessCode::Base24POSProcessCode%39985CDD029F_const.initialization
{
  //## begin configuration::Base24POSProcessCode::Base24POSProcessCode%39985CDD029F_const.body preserve=yes
   memcpy(m_sID,"CF34",4);
  //## end configuration::Base24POSProcessCode::Base24POSProcessCode%39985CDD029F_const.body
}


Base24POSProcessCode::~Base24POSProcessCode()
{
  //## begin configuration::Base24POSProcessCode::~Base24POSProcessCode%39985CDD029F_dest.body preserve=yes
  //## end configuration::Base24POSProcessCode::~Base24POSProcessCode%39985CDD029F_dest.body
}



//## Other Operations (implementation)
void Base24POSProcessCode::bind (Query& hQuery)
{
  //## begin configuration::Base24POSProcessCode::bind%39993BFE01BF.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_B24_PROC_COD_POS");
   hQuery.bind("X_B24_PROC_COD_POS","B24_PROC_CODE_POS",Column::STRING,&m_strFirst);
   hQuery.bind("X_B24_PROC_COD_POS","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("X_B24_PROC_COD_POS","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("X_B24_PROC_COD_POS","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("X_B24_PROC_COD_POS","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("X_B24_PROC_COD_POS","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_B24_PROC_COD_POS","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_B24_PROC_COD_POS","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_B24_PROC_COD_POS","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_B24_PROC_COD_POS.B24_PROC_CODE_POS ASC,X_B24_PROC_COD_POS.CUST_ID DESC");
  //## end configuration::Base24POSProcessCode::bind%39993BFE01BF.body
}

const string& Base24POSProcessCode::getSecond ()
{
  //## begin configuration::Base24POSProcessCode::getSecond%39993BFE01C1.body preserve=yes
   while (m_strPROCESS_CODE.length() < 6)
      m_strPROCESS_CODE += ' ';
   while (m_strMSG_CLASS.length() < 1)
      m_strMSG_CLASS += ' ';
   while (m_strPRE_AUTH.length() < 1)
      m_strPRE_AUTH += ' ';
   m_strSecond = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strSecond;
  //## end configuration::Base24POSProcessCode::getSecond%39993BFE01C1.body
}

// Additional Declarations
  //## begin configuration::Base24POSProcessCode%39985CDD029F.declarations preserve=yes
  //## end configuration::Base24POSProcessCode%39985CDD029F.declarations

} // namespace configuration

//## begin module%39985CA20268.epilog preserve=yes
//## end module%39985CA20268.epilog
