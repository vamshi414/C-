//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%622119CD029F.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%622119CD029F.cm

//## begin module%622119CD029F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%622119CD029F.cp

//## Module: CXOSCFC5%622119CD029F; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCFC5.hpp

#ifndef CXOSCFC5_h
#define CXOSCFC5_h 1

//## begin module%622119CD029F.additionalIncludes preserve=no
//## end module%622119CD029F.additionalIncludes

//## begin module%622119CD029F.includes preserve=yes
//## end module%622119CD029F.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%622119CD029F.declarations preserve=no
//## end module%622119CD029F.declarations

//## begin module%622119CD029F.additionalDeclarations preserve=yes
//## end module%622119CD029F.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ProcessorCalendar%622116CF023A.preface preserve=yes
//## end configuration::ProcessorCalendar%622116CF023A.preface

//## Class: ProcessorCalendar%622116CF023A
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6221188003A5;reusable::Query { -> F}
//## Uses: <unnamed>%622118960087;IF::Extract { -> F}

class DllExport ProcessorCalendar : public ConversionItem  //## Inherits: <unnamed>%622117CF01F4
{
  //## begin configuration::ProcessorCalendar%622116CF023A.initialDeclarations preserve=yes
  //## end configuration::ProcessorCalendar%622116CF023A.initialDeclarations

  public:
    //## Constructors (generated)
      ProcessorCalendar();

    //## Destructor (generated)
      virtual ~ProcessorCalendar();


    //## Other Operations (specified)
      //## Operation: bind%6221179A0298
      void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ProcessorCalendar%622116CF023A.public preserve=yes
      //## end configuration::ProcessorCalendar%622116CF023A.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ProcessorCalendar%622116CF023A.protected preserve=yes
      //## end configuration::ProcessorCalendar%622116CF023A.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ProcessorCalendar%622116CF023A.private preserve=yes
      //## end configuration::ProcessorCalendar%622116CF023A.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ProcessorCalendar%622116CF023A.implementation preserve=yes
      //## end configuration::ProcessorCalendar%622116CF023A.implementation

};

//## begin configuration::ProcessorCalendar%622116CF023A.postscript preserve=yes
//## end configuration::ProcessorCalendar%622116CF023A.postscript

} // namespace configuration

//## begin module%622119CD029F.epilog preserve=yes
//## end module%622119CD029F.epilog


#endif
