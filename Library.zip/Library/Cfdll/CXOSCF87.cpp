//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%44A3C2A6002E.cm preserve=no
//	$Date:   Apr 17 2014 21:06:14  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%44A3C2A6002E.cm

//## begin module%44A3C2A6002E.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%44A3C2A6002E.cp

//## Module: CXOSCF87%44A3C2A6002E; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF87.cpp

//## begin module%44A3C2A6002E.additionalIncludes preserve=no
//## end module%44A3C2A6002E.additionalIncludes

//## begin module%44A3C2A6002E.includes preserve=yes
//## end module%44A3C2A6002E.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF87_h
#include "CXODCF87.hpp"
#endif


//## begin module%44A3C2A6002E.declarations preserve=no
//## end module%44A3C2A6002E.declarations

//## begin module%44A3C2A6002E.additionalDeclarations preserve=yes
//## end module%44A3C2A6002E.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::OasisNetwork 

OasisNetwork::OasisNetwork()
  //## begin OasisNetwork::OasisNetwork%44A2E54000FA_const.hasinit preserve=no
  //## end OasisNetwork::OasisNetwork%44A2E54000FA_const.hasinit
  //## begin OasisNetwork::OasisNetwork%44A2E54000FA_const.initialization preserve=yes
   : ConversionItem("## CR86 XLATE IST NETWORK ID")
  //## end OasisNetwork::OasisNetwork%44A2E54000FA_const.initialization
{
  //## begin configuration::OasisNetwork::OasisNetwork%44A2E54000FA_const.body preserve=yes
   memcpy(m_sID,"CF87",4);
  //## end configuration::OasisNetwork::OasisNetwork%44A2E54000FA_const.body
}


OasisNetwork::~OasisNetwork()
{
  //## begin configuration::OasisNetwork::~OasisNetwork%44A2E54000FA_dest.body preserve=yes
  //## end configuration::OasisNetwork::~OasisNetwork%44A2E54000FA_dest.body
}



//## Other Operations (implementation)
void OasisNetwork::bind (reusable::Query& hQuery)
{
  //## begin configuration::OasisNetwork::bind%44A3C3A60203.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_IST_NETWORK");
   hQuery.bind("X_IST_NETWORK","IST_TRAN_DEST",Column::STRING,&m_strFirst);
   hQuery.bind("X_IST_NETWORK","NETWORK_ID",Column::STRING,&m_strSecond);
   hQuery.bind("X_IST_NETWORK","DESCRIPTION",Column::STRING,&m_strThird);
   hQuery.bind("X_IST_NETWORK","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_IST_NETWORK","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IST_NETWORK","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_IST_NETWORK","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_IST_NETWORK.IST_TRAN_DEST ASC,X_IST_NETWORK.CUST_ID DESC");
  //## end configuration::OasisNetwork::bind%44A3C3A60203.body
}

// Additional Declarations
  //## begin configuration::OasisNetwork%44A2E54000FA.declarations preserve=yes
  //## end configuration::OasisNetwork%44A2E54000FA.declarations

} // namespace configuration

//## begin module%44A3C2A6002E.epilog preserve=yes
//## end module%44A3C2A6002E.epilog
