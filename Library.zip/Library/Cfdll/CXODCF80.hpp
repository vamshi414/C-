//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4288C3DA00DA.cm preserve=no
//	$Date:   Dec 12 2016 14:44:16  $ $Author:   e1009652  $
//	$Revision:   1.3  $
//## end module%4288C3DA00DA.cm

//## begin module%4288C3DA00DA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4288C3DA00DA.cp

//## Module: CXOSCF80%4288C3DA00DA; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF80.hpp

#ifndef CXOSCF80_h
#define CXOSCF80_h 1

//## begin module%4288C3DA00DA.additionalIncludes preserve=no
//## end module%4288C3DA00DA.additionalIncludes

//## begin module%4288C3DA00DA.includes preserve=yes
//## end module%4288C3DA00DA.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%4288C3DA00DA.declarations preserve=no
//## end module%4288C3DA00DA.declarations

//## begin module%4288C3DA00DA.additionalDeclarations preserve=yes
//## end module%4288C3DA00DA.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::CountryCodeNum%4288BB1001B5.preface preserve=yes
//## end configuration::CountryCodeNum%4288BB1001B5.preface

//## Class: CountryCodeNum%4288BB1001B5
//	Translates 3 characters Country Code into 3 digits
//	Country Code
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4288BC3D0128;reusable::Query { -> F}
//## Uses: <unnamed>%584F0BB90124;IF::Extract { -> F}

class DllExport CountryCodeNum : public ConversionItem  //## Inherits: <unnamed>%4288BBBE038A
{
  //## begin configuration::CountryCodeNum%4288BB1001B5.initialDeclarations preserve=yes
  //## end configuration::CountryCodeNum%4288BB1001B5.initialDeclarations

  public:
    //## Constructors (generated)
      CountryCodeNum();

    //## Destructor (generated)
      virtual ~CountryCodeNum();


    //## Other Operations (specified)
      //## Operation: bind%4288BB4600AB
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::CountryCodeNum%4288BB1001B5.public preserve=yes
      //## end configuration::CountryCodeNum%4288BB1001B5.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::CountryCodeNum%4288BB1001B5.protected preserve=yes
      //## end configuration::CountryCodeNum%4288BB1001B5.protected

  private:
    // Additional Private Declarations
      //## begin configuration::CountryCodeNum%4288BB1001B5.private preserve=yes
      //## end configuration::CountryCodeNum%4288BB1001B5.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::CountryCodeNum%4288BB1001B5.implementation preserve=yes
      //## end configuration::CountryCodeNum%4288BB1001B5.implementation

};

//## begin configuration::CountryCodeNum%4288BB1001B5.postscript preserve=yes
//## end configuration::CountryCodeNum%4288BB1001B5.postscript

} // namespace configuration

//## begin module%4288C3DA00DA.epilog preserve=yes
//## end module%4288C3DA00DA.epilog


#endif
