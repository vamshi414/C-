//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%43414B5500DA.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%43414B5500DA.cm

//## begin module%43414B5500DA.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%43414B5500DA.cp

//## Module: CXOSCF85%43414B5500DA; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF85.cpp

//## begin module%43414B5500DA.additionalIncludes preserve=no
//## end module%43414B5500DA.additionalIncludes

//## begin module%43414B5500DA.includes preserve=yes
//## end module%43414B5500DA.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF85_h
#include "CXODCF85.hpp"
#endif


//## begin module%43414B5500DA.declarations preserve=no
//## end module%43414B5500DA.declarations

//## begin module%43414B5500DA.additionalDeclarations preserve=yes
//## end module%43414B5500DA.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::StarProcessCodeRev 

StarProcessCodeRev::StarProcessCodeRev()
  //## begin StarProcessCodeRev::StarProcessCodeRev%434149DA02FD_const.hasinit preserve=no
  //## end StarProcessCodeRev::StarProcessCodeRev%434149DA02FD_const.hasinit
  //## begin StarProcessCodeRev::StarProcessCodeRev%434149DA02FD_const.initialization preserve=yes
   : ConversionItem("## CR85 XLATE STAR PROCESS CODE")
  //## end StarProcessCodeRev::StarProcessCodeRev%434149DA02FD_const.initialization
{
  //## begin configuration::StarProcessCodeRev::StarProcessCodeRev%434149DA02FD_const.body preserve=yes
   memcpy(m_sID,"CF85",4);
  //## end configuration::StarProcessCodeRev::StarProcessCodeRev%434149DA02FD_const.body
}


StarProcessCodeRev::~StarProcessCodeRev()
{
  //## begin configuration::StarProcessCodeRev::~StarProcessCodeRev%434149DA02FD_dest.body preserve=yes
  //## end configuration::StarProcessCodeRev::~StarProcessCodeRev%434149DA02FD_dest.body
}



//## Other Operations (implementation)
void StarProcessCodeRev::bind (reusable::Query& hQuery)
{
  //## begin configuration::StarProcessCodeRev::bind%43414B180128.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_STAR_PROC_CODE");
   hQuery.bind("X_STAR_PROC_CODE","STAR_TRAN_TYPE",Column::STRING,&m_strSecond);
   hQuery.bind("X_STAR_PROC_CODE","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("X_STAR_PROC_CODE","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("X_STAR_PROC_CODE","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("X_STAR_PROC_CODE","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("X_STAR_PROC_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_STAR_PROC_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_STAR_PROC_CODE.PROCESS_CODE ASC,"
                           "X_STAR_PROC_CODE.MSG_CLASS ASC,"
                           "X_STAR_PROC_CODE.PRE_AUTH ASC,"
                           "X_STAR_PROC_CODE.MEDIA_TYPE ASC,"
                           "X_STAR_PROC_CODE.CUST_ID DESC");
  //## end configuration::StarProcessCodeRev::bind%43414B180128.body
}

const string& StarProcessCodeRev::getFirst ()
{
  //## begin configuration::StarProcessCodeRev::getFirst%43414D930213.body preserve=yes
   while (m_strPROCESS_CODE.length() < 6)
      m_strPROCESS_CODE += ' ';
   while (m_strMSG_CLASS.length() < 1)
      m_strMSG_CLASS += ' ';
   while (m_strPRE_AUTH.length() < 1)
      m_strPRE_AUTH += ' ';
   while (m_strMEDIA_TYPE.length() < 2)
      m_strMEDIA_TYPE += ' ';
   m_strFirst = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strFirst;
  //## end configuration::StarProcessCodeRev::getFirst%43414D930213.body
}

// Additional Declarations
  //## begin configuration::StarProcessCodeRev%434149DA02FD.declarations preserve=yes
  //## end configuration::StarProcessCodeRev%434149DA02FD.declarations

} // namespace configuration

//## begin module%43414B5500DA.epilog preserve=yes
//## end module%43414B5500DA.epilog
