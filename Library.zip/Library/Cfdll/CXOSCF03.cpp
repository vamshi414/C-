//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39102F4902CA.cm preserve=no
//	$Date:   May 11 2020 17:32:28  $ $Author:   e1009839  $
//	$Revision:   1.21  $
//## end module%39102F4902CA.cm

//## begin module%39102F4902CA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39102F4902CA.cp

//## Module: CXOSCF03%39102F4902CA; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF03.cpp

//## begin module%39102F4902CA.additionalIncludes preserve=no
//## end module%39102F4902CA.additionalIncludes

//## begin module%39102F4902CA.includes preserve=yes
//## end module%39102F4902CA.includes

#ifndef CXOSMN02_h
#include "CXODMN02.hpp"
#endif
#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSCF02_h
#include "CXODCF02.hpp"
#endif
#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSCF03_h
#include "CXODCF03.hpp"
#endif


//## begin module%39102F4902CA.declarations preserve=no
//## end module%39102F4902CA.declarations

//## begin module%39102F4902CA.additionalDeclarations preserve=yes
//## end module%39102F4902CA.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConversionTable 

ConversionTable::ConversionTable()
  //## begin ConversionTable::ConversionTable%390F3EFC027B_const.hasinit preserve=no
      : m_iAllocatedCount(0),
        m_pArray(0),
        m_iCount(0),
        m_iIndex(-1),
        m_pSortIndex(0),
        m_pMemory(0)
  //## end ConversionTable::ConversionTable%390F3EFC027B_const.hasinit
  //## begin ConversionTable::ConversionTable%390F3EFC027B_const.initialization preserve=yes
  //## end ConversionTable::ConversionTable%390F3EFC027B_const.initialization
{
  //## begin configuration::ConversionTable::ConversionTable%390F3EFC027B_const.body preserve=yes
   memcpy(m_sID,"CF03",4);
  //## end configuration::ConversionTable::ConversionTable%390F3EFC027B_const.body
}

ConversionTable::ConversionTable (const char* pszName)
  //## begin configuration::ConversionTable::ConversionTable%39106FB50026.hasinit preserve=no
      : m_iAllocatedCount(0),
        m_pArray(0),
        m_iCount(0),
        m_iIndex(-1),
        m_pSortIndex(0),
        m_pMemory(0)
  //## end configuration::ConversionTable::ConversionTable%39106FB50026.hasinit
  //## begin configuration::ConversionTable::ConversionTable%39106FB50026.initialization preserve=yes
   ,ConfigurationTable(pszName)
  //## end configuration::ConversionTable::ConversionTable%39106FB50026.initialization
{
  //## begin configuration::ConversionTable::ConversionTable%39106FB50026.body preserve=yes
   memcpy(m_sID,"CF03",4);
   for(int i = 0; i < 3; i++)
      m_iItemSize[i] = 0;
  //## end configuration::ConversionTable::ConversionTable%39106FB50026.body
}


ConversionTable::~ConversionTable()
{
  //## begin configuration::ConversionTable::~ConversionTable%390F3EFC027B_dest.body preserve=yes
   delete m_pMemory;
   delete [] m_pSortIndex;
  //## end configuration::ConversionTable::~ConversionTable%390F3EFC027B_dest.body
}



//## Other Operations (implementation)
bool ConversionTable::add (configuration::ConversionItem* pConversionItem)
{
  //## begin configuration::ConversionTable::add%39107A99015B.body preserve=yes
   const string* strData[3] = {&pConversionItem->getFirst(),&pConversionItem->getSecond(),&pConversionItem->getThird()};
   if (!m_pMemory)
   {
      m_iItemSize[0] = strData[0]->length();
      m_iItemSize[1] = strData[1]->length();
      m_iItemSize[2] = strData[2]->length();
      string strCUST_ID;
      Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
      Query hQuery;
      pConversionItem->bind(hQuery);
      vector<Table>& hTable = hQuery.getTable();
      if (hTable.size() != 1)
         return false;
      string strTableName = hTable[0].getTableName();
      string strQualifier = hTable[0].getQualifier();
      hQuery.reset();
      hQuery.setQualifier(strQualifier.c_str(),strTableName.c_str());
      hQuery.bind(strTableName.c_str(),"*",Column::LONG,&m_iAllocatedCount,0,"COUNT");
      pConversionItem->setPredicate(hQuery);
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (pSelectStatement->execute(hQuery) == false)
         return false;
      if (m_iAllocatedCount == 0)
         m_iAllocatedCount = 1; //handle dummy tables
      int iSizeArray = m_iAllocatedCount*(m_iItemSize[0] + m_iItemSize[1] + m_iItemSize[2]);
      m_pMemory = new Memory(iSizeArray,true);
      m_pArray = (char*)*m_pMemory;
      m_iIndex = -1;
   }
   if (m_iIndex + 1 >= m_iAllocatedCount)
      return false;
   int iSizeEntry = m_iItemSize[0] + m_iItemSize[1] + m_iItemSize[2];
   if (m_iIndex > -1 && memcmp(m_pArray + (m_iIndex * iSizeEntry),strData[0]->data(),strData[0]->length()) == 0)
      return true; //already have this one
   int iCursor = ++m_iIndex*(iSizeEntry);
   memset(m_pArray + iCursor,' ',iSizeEntry);
   for(int i = 0; i < 3; i++)
   {
      if (i == 0  && strData[i]->substr(0,1) == "*" && strData[i]->find_first_not_of("* ") == string::npos)
         memcpy(m_pArray + iCursor,"*",1);
      else
         memcpy(m_pArray + iCursor,strData[i]->data(),strData[i]->length());
      iCursor += m_iItemSize[i];
   }
   m_iCount++;
   return true;
  //## end configuration::ConversionTable::add%39107A99015B.body
}

bool ConversionTable::find (const string& strFirst, string& strSecond, string& strThird, bool bEvidence)
{
  //## begin configuration::ConversionTable::find%39107A4703AC.body preserve=yes
   if (!m_pArray)
      return false;
   m_pCount[0]->increment();
   string strSearch(strFirst);
   for(int i = 0; i < 2; i++)
   {
      strSearch.resize(m_iItemSize[0],' ');
      int iSizeEntry = m_iItemSize[0] + m_iItemSize[1] + m_iItemSize[2];
      int iHigh = m_iCount;
      int iLow = 0;
      int iMiddle = m_iCount/2;
      while (true && strSearch.length() > 0 && iMiddle < m_iCount)
      {
         int iC = memcmp(m_pArray+(iMiddle*iSizeEntry),strSearch.data(),m_iItemSize[0]);
         if (iC == 0)
         {
            strSecond.assign(m_pArray+(iMiddle*iSizeEntry)+m_iItemSize[0],m_iItemSize[1]);
            rtrim(strSecond);
            strThird.assign(m_pArray+(iMiddle*iSizeEntry)+m_iItemSize[0]+m_iItemSize[1],m_iItemSize[2]);
            rtrim(strThird);
            return true;
         }
         if (iLow == iHigh || iMiddle > iHigh || iMiddle < iLow)
            break;
         if (iC < 0)
            iLow = iMiddle+1;
         else
            iHigh = iMiddle-1;
         iMiddle = iLow + (iHigh - iLow)/2;
      }
      strSearch.assign("*");
   }
   if (bEvidence)
      m_pCount[1]->increment();
   return false;
  //## end configuration::ConversionTable::find%39107A4703AC.body
}

// Additional Declarations
  //## begin configuration::ConversionTable%390F3EFC027B.declarations preserve=yes
  //## end configuration::ConversionTable%390F3EFC027B.declarations

} // namespace configuration

//## begin module%39102F4902CA.epilog preserve=yes
//## end module%39102F4902CA.epilog
