//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%409152270000.cm preserve=no
//## end module%409152270000.cm

//## begin module%409152270000.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%409152270000.cp

//## Module: CXOSCF61%409152270000; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCF61.hpp

#ifndef CXOSCF61_h
#define CXOSCF61_h 1

//## begin module%409152270000.additionalIncludes preserve=no
//## end module%409152270000.additionalIncludes

//## begin module%409152270000.includes preserve=yes
//## end module%409152270000.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%409152270000.declarations preserve=no
//## end module%409152270000.declarations

//## begin module%409152270000.additionalDeclarations preserve=yes
//## end module%409152270000.additionalDeclarations


namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::NetworkInstitution%40912B9B00EA.preface preserve=yes
//## end configuration::NetworkInstitution%40912B9B00EA.preface

//## Class: NetworkInstitution%40912B9B00EA
//	<body>
//	<title>CG
//	<h1>AI
//	<h2>MS
//	<h3>Network Institution Codes
//	<p>
//	The Network Institution Codes table (X_NET_INST_ID) is
//	used to determine a value for the issuer institution (FIN
//	_L<i>yyyymm</i>.INST_ID_RECON_ISS) in the financial
//	transaction.
//	<p>
//	Use the CR Client to add or update rows whenever there
//	is a new combination of values in the following fields:
//	<ul>
//	<li>NET_ID
//	<li>NET_INST_ID_CODE
//	<li>PAN_PREFIX
//	</ul>
//	Network Institution Codes are in the Parameter Tables
//	folder in the CR Client for the DataNavigator Server.
//	</body>
//	<body>
//	<title>CG
//	<h1>IC
//	<h2>MS
//	<h3>Network Institution Codes
//	<p>
//	The Network Institution Codes table (X_NET_INST_ID) is
//	used to determine a value for the issuer institution (FIN
//	_L<i>yyyymm</i>.INST_ID_RECON_ISS) in the financial
//	transaction.
//	For VISA (network ID 'VNT'), the search key contains:
//	<ul>
//	<li>'VNT'
//	<li>First 6 digits of the PAN
//	<li>First 12, then 11, 10, 9, 8, 7 and 6 digits of the
//	PAN
//	</ul>
//	For all other network IDs, the search key contains:
//	<ul>
//	<li>NET_ID_ACQ
//	<li>INST_ID_RECON_ISS
//	<li>First 12, then 11, 10, 9, 8, 7 and 6 digits of the
//	PAN
//	</ul><p>
//	Use the CR Client to add or update rows whenever there
//	is a new network, institution or card base in your
//	switch routing configuration.
//	<p>
//	Network Institution Codes are in the Parameter Tables
//	folder in the CR Client for the DataNavigator Server.
//	</body>
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40912C3C00EA;reusable::Query { -> F}
//## Uses: <unnamed>%40912C620232;IF::Extract { -> F}
//## Uses: <unnamed>%50046D1C0385;ConfigurationRepository { -> F}
//## Uses: <unnamed>%64ADAED2019E;entitysegment::Customer { -> F}

class DllExport NetworkInstitution : public ConversionItem  //## Inherits: <unnamed>%40912C340138
{
  //## begin configuration::NetworkInstitution%40912B9B00EA.initialDeclarations preserve=yes
  //## end configuration::NetworkInstitution%40912B9B00EA.initialDeclarations

  public:
    //## Constructors (generated)
      NetworkInstitution();

    //## Destructor (generated)
      virtual ~NetworkInstitution();


    //## Other Operations (specified)
      //## Operation: bind%409153170138
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%4091531E003E
      virtual const string& getFirst ();

      //## Operation: getINST_ID%500193F80210
      static bool getINST_ID (const string& strNET_ID, const string& strNET_INST_ID_CODE, const string& strPAN_PREFIX, const string& strPROBLEM_TABLE, const string& strPROBLEM_COLUMN, string& strINST_ID);

    // Additional Public Declarations
      //## begin configuration::NetworkInstitution%40912B9B00EA.public preserve=yes
      //## end configuration::NetworkInstitution%40912B9B00EA.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::NetworkInstitution%40912B9B00EA.protected preserve=yes
      //## end configuration::NetworkInstitution%40912B9B00EA.protected

  private:
    // Additional Private Declarations
      //## begin configuration::NetworkInstitution%40912B9B00EA.private preserve=yes
      //## end configuration::NetworkInstitution%40912B9B00EA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: NET_INST_ID_CODE%409152AF004E
      //## begin configuration::NetworkInstitution::NET_INST_ID_CODE%409152AF004E.attr preserve=no  private: string {V} 
      string m_strNET_INST_ID_CODE;
      //## end configuration::NetworkInstitution::NET_INST_ID_CODE%409152AF004E.attr

      //## Attribute: PAN_PREFIX%409152C2001F
      //## begin configuration::NetworkInstitution::PAN_PREFIX%409152C2001F.attr preserve=no  private: string {V} 
      string m_strPAN_PREFIX;
      //## end configuration::NetworkInstitution::PAN_PREFIX%409152C2001F.attr

    // Additional Implementation Declarations
      //## begin configuration::NetworkInstitution%40912B9B00EA.implementation preserve=yes
      //## end configuration::NetworkInstitution%40912B9B00EA.implementation

};

//## begin configuration::NetworkInstitution%40912B9B00EA.postscript preserve=yes
//## end configuration::NetworkInstitution%40912B9B00EA.postscript

} // namespace configuration

//## begin module%409152270000.epilog preserve=yes
//## end module%409152270000.epilog


#endif
