//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4263D914033C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%4263D914033C.cm

//## begin module%4263D914033C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%4263D914033C.cp

//## Module: CXOSCF74%4263D914033C; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF74.cpp

//## begin module%4263D914033C.additionalIncludes preserve=no
//## end module%4263D914033C.additionalIncludes

//## begin module%4263D914033C.includes preserve=yes
//## end module%4263D914033C.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSCF74_h
#include "CXODCF74.hpp"
#endif


//## begin module%4263D914033C.declarations preserve=no
//## end module%4263D914033C.declarations

//## begin module%4263D914033C.additionalDeclarations preserve=yes
//## end module%4263D914033C.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::OasisISTFinancialMap 

OasisISTFinancialMap::OasisISTFinancialMap()
  //## begin OasisISTFinancialMap::OasisISTFinancialMap%4263D7FA000F_const.hasinit preserve=no
  //## end OasisISTFinancialMap::OasisISTFinancialMap%4263D7FA000F_const.hasinit
  //## begin OasisISTFinancialMap::OasisISTFinancialMap%4263D7FA000F_const.initialization preserve=yes
  //## end OasisISTFinancialMap::OasisISTFinancialMap%4263D7FA000F_const.initialization
{
  //## begin configuration::OasisISTFinancialMap::OasisISTFinancialMap%4263D7FA000F_const.body preserve=yes
  //## end configuration::OasisISTFinancialMap::OasisISTFinancialMap%4263D7FA000F_const.body
}


OasisISTFinancialMap::~OasisISTFinancialMap()
{
  //## begin configuration::OasisISTFinancialMap::~OasisISTFinancialMap%4263D7FA000F_dest.body preserve=yes
  //## end configuration::OasisISTFinancialMap::~OasisISTFinancialMap%4263D7FA000F_dest.body
}



//## Other Operations (implementation)
bool OasisISTFinancialMap::loadDataMap ()
{
  //## begin configuration::OasisISTFinancialMap::loadDataMap%4263DB1E00DA.body preserve=yes
   if (!m_hDataMap.empty())
      return true;
#ifdef MVS
   FlatFile hTemplate("JCL","DNDNOSCH");
#else
   FlatFile hTemplate("SOURCE","CXOXOSCH");
#endif
   if (!hTemplate.open())
      return false;
 
   char* psBuffer = m_hBuffer;
   memset(psBuffer,' ',256);
   size_t m = 0;
   while (hTemplate.read(psBuffer,256,&m))
   {
      char* q;
      char* s;
      string strType;
      string strFieldId;
      string strOffset;
      string strTargetSegment;
      string strTargetColumn;
      string strTokenId;
      
      q = strchr(psBuffer,'.');
      if (!q || q-psBuffer > 80)
         return false;

      //extract field type
      q++;
      strType.assign(q,1);

      //extract field name 
      q++;
      s = strchr(q,'.');
      if(!s || s-psBuffer > 80)
         return false;
      *s = '\0';
      strFieldId.assign(q);
      q = s+1;
      s = strchr(q,'.');
      if(!s || s-psBuffer > 80)
         return false;

      //extract offset as a string
      *s = '\0';
      strOffset.assign(q);
      s++;
      q = strchr(s,'~');
      if (!q || q-psBuffer > 80)
         return false;

      //extract segment type indicator
      ++q;
      strTargetSegment.assign(q,1);
      q += 2;
      s = strchr(q,'.');
      if (!s || s-psBuffer > 80)
         return false;

      //extract column name
      *s = '\0';
      strTargetColumn.assign(q);

      //concatenate column name to segment type
      strTargetSegment += ' ';
      strTargetSegment += strTargetColumn;

      //concatenate offset to token id
      strTokenId.assign(strType);
      strTokenId.append(strOffset);
      strTokenId.append(strFieldId);

      //add to map
      if(strTargetColumn != "NONE")
         m_hDataMap.insert(map<string,string,less<string> >::value_type(strTokenId,strTargetSegment));
      memset(psBuffer,' ',256);
   }
   return true;
  //## end configuration::OasisISTFinancialMap::loadDataMap%4263DB1E00DA.body
}

// Additional Declarations
  //## begin configuration::OasisISTFinancialMap%4263D7FA000F.declarations preserve=yes
  //## end configuration::OasisISTFinancialMap%4263D7FA000F.declarations

} // namespace configuration

//## begin module%4263D914033C.epilog preserve=yes
//## end module%4263D914033C.epilog
