//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%431358B3000F.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%431358B3000F.cm

//## begin module%431358B3000F.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%431358B3000F.cp

//## Module: CXOSCF82%431358B3000F; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF82.hpp

#ifndef CXOSCF82_h
#define CXOSCF82_h 1

//## begin module%431358B3000F.additionalIncludes preserve=no
//## end module%431358B3000F.additionalIncludes

//## begin module%431358B3000F.includes preserve=yes
//## end module%431358B3000F.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%431358B3000F.declarations preserve=no
//## end module%431358B3000F.declarations

//## begin module%431358B3000F.additionalDeclarations preserve=yes
//## end module%431358B3000F.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::StarProcessCode%431357C20109.preface preserve=yes
//## end configuration::StarProcessCode%431357C20109.preface

//## Class: StarProcessCode%431357C20109
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%43135BB003C8;IF::Extract { -> F}
//## Uses: <unnamed>%43135BBD006D;reusable::Query { -> F}

class DllExport StarProcessCode : public ConversionItem  //## Inherits: <unnamed>%4313583E002E
{
  //## begin configuration::StarProcessCode%431357C20109.initialDeclarations preserve=yes
  //## end configuration::StarProcessCode%431357C20109.initialDeclarations

  public:
    //## Constructors (generated)
      StarProcessCode();

    //## Destructor (generated)
      virtual ~StarProcessCode();


    //## Other Operations (specified)
      //## Operation: bind%43135A8E0222
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>MS
      //	<h3>VISA Process Codes
      //	<p>
      //	The VISA Process Codes table is used to determine a
      //	value for the transaction type identifier (FIN_
      //	L<i>yyyymm</i>.TRAN_TYPE_ID) in the financial
      //	transaction.
      //	<p>
      //	Use the CR Client to add or update rows whenever the e
      //	Funds Advantage acquiring platform introduces a new
      //	value in:
      //	<ul>
      //	<li>PROC^CODE (1)
      //	</ul>
      //	VISA Process Codes are in the Parameter Tables folder in
      //	the CR Client for the DataNavigator Server.
      //	</body>
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getSecond%43135A92038A
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::StarProcessCode%431357C20109.public preserve=yes
      //## end configuration::StarProcessCode%431357C20109.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::StarProcessCode%431357C20109.protected preserve=yes
      //## end configuration::StarProcessCode%431357C20109.protected

  private:
    // Additional Private Declarations
      //## begin configuration::StarProcessCode%431357C20109.private preserve=yes
      //## end configuration::StarProcessCode%431357C20109.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: MEDIA_TYPE%43135AAB0148
      //## begin configuration::StarProcessCode::MEDIA_TYPE%43135AAB0148.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::StarProcessCode::MEDIA_TYPE%43135AAB0148.attr

      //## Attribute: MSG_CLASS%43135A9E0109
      //## begin configuration::StarProcessCode::MSG_CLASS%43135A9E0109.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::StarProcessCode::MSG_CLASS%43135A9E0109.attr

      //## Attribute: PRE_AUTH%43135AA3005D
      //## begin configuration::StarProcessCode::PRE_AUTH%43135AA3005D.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::StarProcessCode::PRE_AUTH%43135AA3005D.attr

      //## Attribute: PROCESS_CODE%43135A9A02EE
      //## begin configuration::StarProcessCode::PROCESS_CODE%43135A9A02EE.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::StarProcessCode::PROCESS_CODE%43135A9A02EE.attr

    // Additional Implementation Declarations
      //## begin configuration::StarProcessCode%431357C20109.implementation preserve=yes
      //## end configuration::StarProcessCode%431357C20109.implementation

};

//## begin configuration::StarProcessCode%431357C20109.postscript preserve=yes
//## end configuration::StarProcessCode%431357C20109.postscript

} // namespace configuration

//## begin module%431358B3000F.epilog preserve=yes
using namespace configuration;
//## end module%431358B3000F.epilog


#endif
