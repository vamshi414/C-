//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4263DF6101A5.cm preserve=no
//	$Date:   May 05 2014 14:35:50  $ $Author:   e1009652  $
//	$Revision:   1.6  $
//## end module%4263DF6101A5.cm

//## begin module%4263DF6101A5.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%4263DF6101A5.cp

//## Module: CXOSCF75%4263DF6101A5; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF75.cpp

//## begin module%4263DF6101A5.additionalIncludes preserve=no
//## end module%4263DF6101A5.additionalIncludes

//## begin module%4263DF6101A5.includes preserve=yes
//## end module%4263DF6101A5.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF75_h
#include "CXODCF75.hpp"
#endif


//## begin module%4263DF6101A5.declarations preserve=no
//## end module%4263DF6101A5.declarations

//## begin module%4263DF6101A5.additionalDeclarations preserve=yes
//## end module%4263DF6101A5.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::OasisRespCode 

OasisRespCode::OasisRespCode()
  //## begin OasisRespCode::OasisRespCode%4263DEE200FA_const.hasinit preserve=no
  //## end OasisRespCode::OasisRespCode%4263DEE200FA_const.hasinit
  //## begin OasisRespCode::OasisRespCode%4263DEE200FA_const.initialization preserve=yes
  : ConversionItem("## CR78 XLATE IST RESPONSE CODE")
  //## end OasisRespCode::OasisRespCode%4263DEE200FA_const.initialization
{
  //## begin configuration::OasisRespCode::OasisRespCode%4263DEE200FA_const.body preserve=yes
   memcpy(m_sID,"CF75",4);
  //## end configuration::OasisRespCode::OasisRespCode%4263DEE200FA_const.body
}


OasisRespCode::~OasisRespCode()
{
  //## begin configuration::OasisRespCode::~OasisRespCode%4263DEE200FA_dest.body preserve=yes
  //## end configuration::OasisRespCode::~OasisRespCode%4263DEE200FA_dest.body
}



//## Other Operations (implementation)
void OasisRespCode::bind (reusable::Query& hQuery)
{
  //## begin configuration::OasisRespCode::bind%4263E1F700CB.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_IST_RESP_REV_COD");
   hQuery.bind("X_IST_RESP_REV_COD","ACTION_CODE",Column::STRING,&m_strSecond);
   hQuery.bind("X_IST_RESP_REV_COD","IST_RESP_REV_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IST_RESP_REV_COD","TRAN_DISPOSITION",Column::STRING,&m_strTRAN_DISPOSITION);
   hQuery.bind("X_IST_RESP_REV_COD","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_IST_RESP_REV_COD","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IST_RESP_REV_COD","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_IST_RESP_REV_COD","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_IST_RESP_REV_COD.IST_RESP_REV_CODE ASC,"
                           "X_IST_RESP_REV_COD.TRAN_DISPOSITION ASC,"
                           "X_IST_RESP_REV_COD.CUST_ID DESC");
  //## end configuration::OasisRespCode::bind%4263E1F700CB.body
}

const string& OasisRespCode::getFirst ()
{
  //## begin configuration::OasisRespCode::getFirst%43D7DEA7019A.body preserve=yes
   m_strKey.assign(m_strFirst);
   m_strKey.append("-");
   m_strKey.append(m_strTRAN_DISPOSITION);
   return m_strKey;
  //## end configuration::OasisRespCode::getFirst%43D7DEA7019A.body
}

// Additional Declarations
  //## begin configuration::OasisRespCode%4263DEE200FA.declarations preserve=yes
  //## end configuration::OasisRespCode%4263DEE200FA.declarations

} // namespace configuration

//## begin module%4263DF6101A5.epilog preserve=yes
//## end module%4263DF6101A5.epilog
