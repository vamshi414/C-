//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5CF7C99902DF.cm preserve=no
//	$Date:   Jun 06 2019 14:02:42  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5CF7C99902DF.cm

//## begin module%5CF7C99902DF.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5CF7C99902DF.cp

//## Module: CXOSCFB1%5CF7C99902DF; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV03.0A.R002\Windows\Build\Dn\Server\Library\Cfdll\CXODCFB1.hpp

#ifndef CXOSCFB1_h
#define CXOSCFB1_h 1

//## begin module%5CF7C99902DF.additionalIncludes preserve=no
//## end module%5CF7C99902DF.additionalIncludes

//## begin module%5CF7C99902DF.includes preserve=yes
//## end module%5CF7C99902DF.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%5CF7C99902DF.declarations preserve=no
//## end module%5CF7C99902DF.declarations

//## begin module%5CF7C99902DF.additionalDeclarations preserve=yes
//## end module%5CF7C99902DF.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::CurrencyCode%5CF7C70E0081.preface preserve=yes
//## end configuration::CurrencyCode%5CF7C70E0081.preface

//## Class: CurrencyCode%5CF7C70E0081
//	This Class translates the numeric currency code to the 3
//	character currency code.
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5CF7C7DF020E;reusable::Query { -> F}
//## Uses: <unnamed>%5CF831750138;entitysegment::Customer { -> F}

class DllExport CurrencyCode : public ConversionItem  //## Inherits: <unnamed>%5CF7C7C500F9
{
  //## begin configuration::CurrencyCode%5CF7C70E0081.initialDeclarations preserve=yes
  //## end configuration::CurrencyCode%5CF7C70E0081.initialDeclarations

  public:
    //## Constructors (generated)
      CurrencyCode();

    //## Destructor (generated)
      virtual ~CurrencyCode();


    //## Other Operations (specified)
      //## Operation: bind%5CF7CA7102F5
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::CurrencyCode%5CF7C70E0081.public preserve=yes
      //## end configuration::CurrencyCode%5CF7C70E0081.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::CurrencyCode%5CF7C70E0081.protected preserve=yes
      //## end configuration::CurrencyCode%5CF7C70E0081.protected

  private:
    // Additional Private Declarations
      //## begin configuration::CurrencyCode%5CF7C70E0081.private preserve=yes
      //## end configuration::CurrencyCode%5CF7C70E0081.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::CurrencyCode%5CF7C70E0081.implementation preserve=yes
      //## end configuration::CurrencyCode%5CF7C70E0081.implementation

};

//## begin configuration::CurrencyCode%5CF7C70E0081.postscript preserve=yes
//## end configuration::CurrencyCode%5CF7C70E0081.postscript

} // namespace configuration

//## begin module%5CF7C99902DF.epilog preserve=yes
//## end module%5CF7C99902DF.epilog


#endif
