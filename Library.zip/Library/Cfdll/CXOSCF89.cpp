//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%456545490177.cm preserve=no
//	$Date:   Apr 17 2014 21:06:16  $ $Author:   e1009652  $
//	$Revision:   1.6  $
//## end module%456545490177.cm

//## begin module%456545490177.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%456545490177.cp

//## Module: CXOSCF89%456545490177; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF89.cpp

//## begin module%456545490177.additionalIncludes preserve=no
//## end module%456545490177.additionalIncludes

//## begin module%456545490177.includes preserve=yes
//## end module%456545490177.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF89_h
#include "CXODCF89.hpp"
#endif


//## begin module%456545490177.declarations preserve=no
//## end module%456545490177.declarations

//## begin module%456545490177.additionalDeclarations preserve=yes
//## end module%456545490177.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::NACHAReturnCode 

NACHAReturnCode::NACHAReturnCode()
  //## begin NACHAReturnCode::NACHAReturnCode%456544E20167_const.hasinit preserve=no
  //## end NACHAReturnCode::NACHAReturnCode%456544E20167_const.hasinit
  //## begin NACHAReturnCode::NACHAReturnCode%456544E20167_const.initialization preserve=yes
  : ConversionItem("## CR89 XLATE NACHA RETURN CODE")
  //## end NACHAReturnCode::NACHAReturnCode%456544E20167_const.initialization
{
  //## begin configuration::NACHAReturnCode::NACHAReturnCode%456544E20167_const.body preserve=yes
   memcpy(m_sID,"CF89",4);
  //## end configuration::NACHAReturnCode::NACHAReturnCode%456544E20167_const.body
}


NACHAReturnCode::~NACHAReturnCode()
{
  //## begin configuration::NACHAReturnCode::~NACHAReturnCode%456544E20167_dest.body preserve=yes
  //## end configuration::NACHAReturnCode::~NACHAReturnCode%456544E20167_dest.body
}



//## Other Operations (implementation)
void NACHAReturnCode::bind (reusable::Query& hQuery)
{
  //## begin configuration::NACHAReturnCode::bind%45654512001F.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_NACHA_RETURN_COD");
   hQuery.bind("X_NACHA_RETURN_COD","NACHA_RETURN_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_NACHA_RETURN_COD","ACTION_CODE",Column::STRING,&m_strACTION_CODE);
   hQuery.bind("X_NACHA_RETURN_COD","TRAN_DESC_CODE",Column::STRING,&m_strTRAN_DESC_CODE);
   hQuery.bind("X_NACHA_RETURN_COD","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_NACHA_RETURN_COD","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_NACHA_RETURN_COD","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_NACHA_RETURN_COD","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_NACHA_RETURN_COD.NACHA_RETURN_CODE ASC,X_NACHA_RETURN_COD.CUST_ID DESC");
  //## end configuration::NACHAReturnCode::bind%45654512001F.body
}

const string& NACHAReturnCode::getSecond ()
{
  //## begin configuration::NACHAReturnCode::getSecond%45F56F3E03C8.body preserve=yes
   while (m_strACTION_CODE.length() < 3)
      m_strACTION_CODE += ' ';
   while (m_strTRAN_DESC_CODE.length() < 3)
      m_strTRAN_DESC_CODE += ' ';
   m_strSecond = m_strACTION_CODE + m_strTRAN_DESC_CODE;
   return m_strSecond;
  //## end configuration::NACHAReturnCode::getSecond%45F56F3E03C8.body
}

// Additional Declarations
  //## begin configuration::NACHAReturnCode%456544E20167.declarations preserve=yes
  //## end configuration::NACHAReturnCode%456544E20167.declarations

} // namespace configuration

//## begin module%456545490177.epilog preserve=yes
//## end module%456545490177.epilog
