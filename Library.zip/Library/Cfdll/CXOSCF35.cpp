//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%39985C9401FA.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%39985C9401FA.cm

//## begin module%39985C9401FA.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%39985C9401FA.cp

//## Module: CXOSCF35%39985C9401FA; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF35.cpp

//## begin module%39985C9401FA.additionalIncludes preserve=no
//## end module%39985C9401FA.additionalIncludes

//## begin module%39985C9401FA.includes preserve=yes
// $Date:   Apr 17 2014 21:00:22  $ $Author:   e1009652  $ $Revision:   1.5  $
//## end module%39985C9401FA.includes

#ifndef CXOSCF35_h
#include "CXODCF35.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%39985C9401FA.declarations preserve=no
//## end module%39985C9401FA.declarations

//## begin module%39985C9401FA.additionalDeclarations preserve=yes
//## end module%39985C9401FA.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::Base24ATMResponseCode

Base24ATMResponseCode::Base24ATMResponseCode()
  //## begin Base24ATMResponseCode::Base24ATMResponseCode%39985CE6011C_const.hasinit preserve=no
  //## end Base24ATMResponseCode::Base24ATMResponseCode%39985CE6011C_const.hasinit
  //## begin Base24ATMResponseCode::Base24ATMResponseCode%39985CE6011C_const.initialization preserve=yes
  //## end Base24ATMResponseCode::Base24ATMResponseCode%39985CE6011C_const.initialization
{
  //## begin configuration::Base24ATMResponseCode::Base24ATMResponseCode%39985CE6011C_const.body preserve=yes
   memcpy(m_sID,"CF35",4);
  //## end configuration::Base24ATMResponseCode::Base24ATMResponseCode%39985CE6011C_const.body
}


Base24ATMResponseCode::~Base24ATMResponseCode()
{
  //## begin configuration::Base24ATMResponseCode::~Base24ATMResponseCode%39985CE6011C_dest.body preserve=yes
  //## end configuration::Base24ATMResponseCode::~Base24ATMResponseCode%39985CE6011C_dest.body
}



//## Other Operations (implementation)
void Base24ATMResponseCode::bind (Query& hQuery)
{
  //## begin configuration::Base24ATMResponseCode::bind%39993C02039B.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_B24_RESP_COD_ATM");
   hQuery.bind("X_B24_RESP_COD_ATM","B24_RESP_CODE_ATM",Column::STRING,&m_strFirst);
   hQuery.bind("X_B24_RESP_COD_ATM","ACTION_CODE",Column::STRING,&m_strSecond);
   hQuery.bind("X_B24_RESP_COD_ATM","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_B24_RESP_COD_ATM","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_B24_RESP_COD_ATM","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_B24_RESP_COD_ATM","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_B24_RESP_COD_ATM.B24_RESP_CODE_ATM ASC,X_B24_RESP_COD_ATM.CUST_ID DESC");
  //## end configuration::Base24ATMResponseCode::bind%39993C02039B.body
}

// Additional Declarations
  //## begin configuration::Base24ATMResponseCode%39985CE6011C.declarations preserve=yes
  //## end configuration::Base24ATMResponseCode%39985CE6011C.declarations

} // namespace configuration

//## begin module%39985C9401FA.epilog preserve=yes
//## end module%39985C9401FA.epilog
