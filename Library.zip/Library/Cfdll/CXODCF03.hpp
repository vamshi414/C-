//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39102F48007A.cm preserve=no
//	$Date:   May 11 2020 17:32:28  $ $Author:   e1009839  $
//	$Revision:   1.11  $
//## end module%39102F48007A.cm

//## begin module%39102F48007A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39102F48007A.cp

//## Module: CXOSCF03%39102F48007A; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF03.hpp

#ifndef CXOSCF03_h
#define CXOSCF03_h 1

//## begin module%39102F48007A.additionalIncludes preserve=no
//## end module%39102F48007A.additionalIncludes

//## begin module%39102F48007A.includes preserve=yes
//## end module%39102F48007A.includes

#ifndef CXOSCF32_h
#include "CXODCF32.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationFactory;
class ConversionItem;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Memory;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class Count;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%39102F48007A.declarations preserve=no
//## end module%39102F48007A.declarations

//## begin module%39102F48007A.additionalDeclarations preserve=yes
#include "CXODCF05.hpp"
//## end module%39102F48007A.additionalDeclarations


namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConversionTable%390F3EFC027B.preface preserve=yes
//## end configuration::ConversionTable%390F3EFC027B.preface

//## Class: ConversionTable%390F3EFC027B
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3958ECBE006B;monitor::Count { -> F}
//## Uses: <unnamed>%534C0E7C0332;ConversionItem { -> F}
//## Uses: <unnamed>%534C183F00B3;reusable::Query { -> F}
//## Uses: <unnamed>%534C197803D4;IF::Extract { -> F}
//## Uses: <unnamed>%534C199203E5;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%534C19BC02A5;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%534D450C0344;ConfigurationFactory { -> F}

class DllExport ConversionTable : public ConfigurationTable  //## Inherits: <unnamed>%3958D322026D
{
  //## begin configuration::ConversionTable%390F3EFC027B.initialDeclarations preserve=yes
  //## end configuration::ConversionTable%390F3EFC027B.initialDeclarations

  public:
    //## Constructors (generated)
      ConversionTable();

    //## Constructors (specified)
      //## Operation: ConversionTable%39106FB50026
      ConversionTable (const char* pszName);

    //## Destructor (generated)
      virtual ~ConversionTable();


    //## Other Operations (specified)
      //## Operation: add%39107A99015B
      bool add (configuration::ConversionItem* pConversionItem);

      //## Operation: find%39107A4703AC
      bool find (const string& strFirst, string& strSecond, string& strThird, bool bEvidence = true);

      //## Operation: size%3EF368250213
      short int size ()
      {
        //## begin configuration::ConversionTable::size%3EF368250213.body preserve=yes
          return m_iCount;
        //## end configuration::ConversionTable::size%3EF368250213.body
      }

    // Additional Public Declarations
      //## begin configuration::ConversionTable%390F3EFC027B.public preserve=yes
      //## end configuration::ConversionTable%390F3EFC027B.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConversionTable%390F3EFC027B.protected preserve=yes
      //## end configuration::ConversionTable%390F3EFC027B.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConversionTable%390F3EFC027B.private preserve=yes
      //## end configuration::ConversionTable%390F3EFC027B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: AllocatedCount%53507ECD0285
      //## begin configuration::ConversionTable::AllocatedCount%53507ECD0285.attr preserve=no  private: int {U} 0
      int m_iAllocatedCount;
      //## end configuration::ConversionTable::AllocatedCount%53507ECD0285.attr

      //## Attribute: Array%534C00D30320
      //## begin configuration::ConversionTable::Array%534C00D30320.attr preserve=no  private: char* {U} 0
      char* m_pArray;
      //## end configuration::ConversionTable::Array%534C00D30320.attr

      //## Attribute: Count%534C1E1B0205
      //## begin configuration::ConversionTable::Count%534C1E1B0205.attr preserve=no  private: int {U} 0
      int m_iCount;
      //## end configuration::ConversionTable::Count%534C1E1B0205.attr

      //## Attribute: Index%534C012503C6
      //## begin configuration::ConversionTable::Index%534C012503C6.attr preserve=no  private: int {U} -1
      int m_iIndex;
      //## end configuration::ConversionTable::Index%534C012503C6.attr

      //## Attribute: ItemSize%534D47290385
      //## begin configuration::ConversionTable::ItemSize%534D47290385.attr preserve=no  private: int[3] {U} 
      int m_iItemSize[3];
      //## end configuration::ConversionTable::ItemSize%534D47290385.attr

      //## Attribute: SortIndex%534C4ECA00E6
      //## begin configuration::ConversionTable::SortIndex%534C4ECA00E6.attr preserve=no  private: int* {U} 0
      int* m_pSortIndex;
      //## end configuration::ConversionTable::SortIndex%534C4ECA00E6.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Configuration_CAT::<unnamed>%5EB9BD110181
      //## Role: ConversionTable::<m_pMemory>%5EB9BD12007A
      //## begin configuration::ConversionTable::<m_pMemory>%5EB9BD12007A.role preserve=no  public: IF::Memory { -> RFHgN}
      IF::Memory *m_pMemory;
      //## end configuration::ConversionTable::<m_pMemory>%5EB9BD12007A.role

    // Additional Implementation Declarations
      //## begin configuration::ConversionTable%390F3EFC027B.implementation preserve=yes
      //## end configuration::ConversionTable%390F3EFC027B.implementation

};

//## begin configuration::ConversionTable%390F3EFC027B.postscript preserve=yes
//## end configuration::ConversionTable%390F3EFC027B.postscript

} // namespace configuration

//## begin module%39102F48007A.epilog preserve=yes
using namespace configuration;
//## end module%39102F48007A.epilog


#endif
