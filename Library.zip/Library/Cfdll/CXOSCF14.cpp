//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%391C0E080370.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%391C0E080370.cm

//## begin module%391C0E080370.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%391C0E080370.cp

//## Module: CXOSCF14%391C0E080370; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF14.cpp

//## begin module%391C0E080370.additionalIncludes preserve=no
//## end module%391C0E080370.additionalIncludes

//## begin module%391C0E080370.includes preserve=yes
// $Date:   Apr 17 2014 20:59:20  $ $Author:   e1009652  $ $Revision:   1.6  $
//## end module%391C0E080370.includes

#ifndef CXOSCF14_h
#include "CXODCF14.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%391C0E080370.declarations preserve=no
//## end module%391C0E080370.declarations

//## begin module%391C0E080370.additionalDeclarations preserve=yes
//## end module%391C0E080370.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::CirrusAdjustmentReason

CirrusAdjustmentReason::CirrusAdjustmentReason()
  //## begin CirrusAdjustmentReason::CirrusAdjustmentReason%391C0C76008D_const.hasinit preserve=no
  //## end CirrusAdjustmentReason::CirrusAdjustmentReason%391C0C76008D_const.hasinit
  //## begin CirrusAdjustmentReason::CirrusAdjustmentReason%391C0C76008D_const.initialization preserve=yes
   : ConversionItem("## CR17 XLATE CIRRUS ADJ REASON")
  //## end CirrusAdjustmentReason::CirrusAdjustmentReason%391C0C76008D_const.initialization
{
  //## begin configuration::CirrusAdjustmentReason::CirrusAdjustmentReason%391C0C76008D_const.body preserve=yes
   memcpy(m_sID,"CF14",4);
  //## end configuration::CirrusAdjustmentReason::CirrusAdjustmentReason%391C0C76008D_const.body
}


CirrusAdjustmentReason::~CirrusAdjustmentReason()
{
  //## begin configuration::CirrusAdjustmentReason::~CirrusAdjustmentReason%391C0C76008D_dest.body preserve=yes
  //## end configuration::CirrusAdjustmentReason::~CirrusAdjustmentReason%391C0C76008D_dest.body
}



//## Other Operations (implementation)
void CirrusAdjustmentReason::bind (Query& hQuery)
{
  //## begin configuration::CirrusAdjustmentReason::bind%391C1BE103BD.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_CIRR_ADJ_REASON");
   hQuery.bind("X_CIRR_ADJ_REASON","CIRR_ADJ_REASON",Column::STRING,&m_strFirst);
   hQuery.bind("X_CIRR_ADJ_REASON","MSG_REASON_CODE",Column::STRING,&m_strSecond);
   hQuery.bind("X_CIRR_ADJ_REASON","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_CIRR_ADJ_REASON","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_CIRR_ADJ_REASON","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_CIRR_ADJ_REASON","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_CIRR_ADJ_REASON.CIRR_ADJ_REASON ASC,X_CIRR_ADJ_REASON.CUST_ID DESC");
  //## end configuration::CirrusAdjustmentReason::bind%391C1BE103BD.body
}

// Additional Declarations
  //## begin configuration::CirrusAdjustmentReason%391C0C76008D.declarations preserve=yes
  //## end configuration::CirrusAdjustmentReason%391C0C76008D.declarations

} // namespace configuration

//## begin module%391C0E080370.epilog preserve=yes
//## end module%391C0E080370.epilog
