//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%60A336CE0008.cm preserve=no
//	$Date:   Sep 06 2021 04:46:26  $ $Author:   e3028298  $
//	$Revision:   1.1  $
//## end module%60A336CE0008.cm

//## begin module%60A336CE0008.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%60A336CE0008.cp

//## Module: CXOSCFC0%60A336CE0008; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Devel\V03.2A.R003\Dn\Server\Library\Cfdll\CXODCFC0.hpp

#ifndef CXOSCFC0_h
#define CXOSCFC0_h 1

//## begin module%60A336CE0008.additionalIncludes preserve=no
//## end module%60A336CE0008.additionalIncludes

//## begin module%60A336CE0008.includes preserve=yes
//## end module%60A336CE0008.includes

#ifndef CXOSCF26_h
#include "CXODCF26.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%60A336CE0008.declarations preserve=no
//## end module%60A336CE0008.declarations

//## begin module%60A336CE0008.additionalDeclarations preserve=yes
//## end module%60A336CE0008.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::QMRIssuers%60A335E30123.preface preserve=yes
//## end configuration::QMRIssuers%60A335E30123.preface

//## Class: QMRIssuers%60A335E30123
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%60A3391A037D;IF::Extract { -> F}
//## Uses: <unnamed>%60A3391D01C3;reusable::Query { -> F}

class DllExport QMRIssuers : public VerificationItem  //## Inherits: <unnamed>%60A339230062
{
  //## begin configuration::QMRIssuers%60A335E30123.initialDeclarations preserve=yes
  //## end configuration::QMRIssuers%60A335E30123.initialDeclarations

  public:
    //## Constructors (generated)
      QMRIssuers();

    //## Constructors (specified)
      //## Operation: QMRIssuers%61065E8B0096
      QMRIssuers (const char* pszVerificationItem);

    //## Destructor (generated)
      virtual ~QMRIssuers();


    //## Other Operations (specified)
      //## Operation: bind%60A339CD03BF
      virtual void bind (Query& hQuery);

      //## Operation: getKey%60A33A230225
      virtual const reusable::string& getKey ();

      //## Operation: verifyBin%610665A602AF
      static bool verifyBin (const string& strBIN, int& iLength);

    // Additional Public Declarations
      //## begin configuration::QMRIssuers%60A335E30123.public preserve=yes
      //## end configuration::QMRIssuers%60A335E30123.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::QMRIssuers%60A335E30123.protected preserve=yes
      //## end configuration::QMRIssuers%60A335E30123.protected

  private:
    // Additional Private Declarations
      //## begin configuration::QMRIssuers%60A335E30123.private preserve=yes
      //## end configuration::QMRIssuers%60A335E30123.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BIN%60A339760088
      //## begin configuration::QMRIssuers::BIN%60A339760088.attr preserve=no  private: string {U} 
      string m_strBIN;
      //## end configuration::QMRIssuers::BIN%60A339760088.attr

      //## Attribute: NETWORK_ID%60A33996013A
      //## begin configuration::QMRIssuers::NETWORK_ID%60A33996013A.attr preserve=no  private: string {U} 
      string m_strNETWORK_ID;
      //## end configuration::QMRIssuers::NETWORK_ID%60A33996013A.attr

      //## Attribute: VerificationItem%61065F30034A
      //## begin configuration::QMRIssuers::VerificationItem%61065F30034A.attr preserve=no  private: string {U} 
      string m_strVerificationItem;
      //## end configuration::QMRIssuers::VerificationItem%61065F30034A.attr

    // Additional Implementation Declarations
      //## begin configuration::QMRIssuers%60A335E30123.implementation preserve=yes
      //## end configuration::QMRIssuers%60A335E30123.implementation

};

//## begin configuration::QMRIssuers%60A335E30123.postscript preserve=yes
//## end configuration::QMRIssuers%60A335E30123.postscript

} // namespace configuration

//## begin module%60A336CE0008.epilog preserve=yes
//## end module%60A336CE0008.epilog


#endif
