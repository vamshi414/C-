//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%62211A230336.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%62211A230336.cm

//## begin module%62211A230336.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%62211A230336.cp

//## Module: CXOSCFC5%62211A230336; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFC5.cpp

//## begin module%62211A230336.additionalIncludes preserve=no
//## end module%62211A230336.additionalIncludes

//## begin module%62211A230336.includes preserve=yes
//## end module%62211A230336.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCFC5_h
#include "CXODCFC5.hpp"
#endif


//## begin module%62211A230336.declarations preserve=no
//## end module%62211A230336.declarations

//## begin module%62211A230336.additionalDeclarations preserve=yes
//## end module%62211A230336.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ProcessorCalendar 

ProcessorCalendar::ProcessorCalendar()
  //## begin ProcessorCalendar::ProcessorCalendar%622116CF023A_const.hasinit preserve=no
  //## end ProcessorCalendar::ProcessorCalendar%622116CF023A_const.hasinit
  //## begin ProcessorCalendar::ProcessorCalendar%622116CF023A_const.initialization preserve=yes
  //## end ProcessorCalendar::ProcessorCalendar%622116CF023A_const.initialization
{
  //## begin configuration::ProcessorCalendar::ProcessorCalendar%622116CF023A_const.body preserve=yes
  //## end configuration::ProcessorCalendar::ProcessorCalendar%622116CF023A_const.body
}


ProcessorCalendar::~ProcessorCalendar()
{
  //## begin configuration::ProcessorCalendar::~ProcessorCalendar%622116CF023A_dest.body preserve=yes
  //## end configuration::ProcessorCalendar::~ProcessorCalendar%622116CF023A_dest.body
}



//## Other Operations (implementation)
void ProcessorCalendar::bind (Query& hQuery)
{
  //## begin configuration::ProcessorCalendar::bind%6221179A0298.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY", "PROCESSOR");
   hQuery.bind("PROCESSOR", "PROC_ID", Column::STRING, &m_strFirst);
   hQuery.bind("PROCESSOR", "EVNTID", Column::STRING, &m_strSecond);
   hQuery.bind("PROCESSOR", "CUST_ID", Column::STRING, &m_strCUST_ID);
   hQuery.setBasicPredicate("PROCESSOR", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("PROCESSOR", "CC_STATE", "=", "A");
   hQuery.setBasicPredicate("PROCESSOR", "EVNTSTAT", "=", " ");
   hQuery.setBasicPredicate("PROCESSOR", "EVNTID", "IS NOT NULL");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("PROCESSOR", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("PROC_ID ASC");
  //## end configuration::ProcessorCalendar::bind%6221179A0298.body
}

// Additional Declarations
  //## begin configuration::ProcessorCalendar%622116CF023A.declarations preserve=yes
  //## end configuration::ProcessorCalendar%622116CF023A.declarations

} // namespace configuration

//## begin module%62211A230336.epilog preserve=yes
//## end module%62211A230336.epilog
