//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%5059C9F10390.cm preserve=no
//	$Date:   Oct 25 2012 08:12:00  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5059C9F10390.cm

//## begin module%5059C9F10390.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5059C9F10390.cp

//## Module: CXOSCF70%5059C9F10390; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF70.hpp

#ifndef CXOSCF70_h
#define CXOSCF70_h 1

//## begin module%5059C9F10390.additionalIncludes preserve=no
//## end module%5059C9F10390.additionalIncludes

//## begin module%5059C9F10390.includes preserve=yes
//## end module%5059C9F10390.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%5059C9F10390.declarations preserve=no
//## end module%5059C9F10390.declarations

//## begin module%5059C9F10390.additionalDeclarations preserve=yes
//## end module%5059C9F10390.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::MasterCardAdviceReason%5059C1E60128.preface preserve=yes
//## end configuration::MasterCardAdviceReason%5059C1E60128.preface

//## Class: MasterCardAdviceReason%5059C1E60128
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5059C2090369;IF::Extract { -> F}
//## Uses: <unnamed>%5059C20D02FD;reusable::Query { -> F}

class DllExport MasterCardAdviceReason : public ConversionItem  //## Inherits: <unnamed>%5059C2070189
{
  //## begin configuration::MasterCardAdviceReason%5059C1E60128.initialDeclarations preserve=yes
  //## end configuration::MasterCardAdviceReason%5059C1E60128.initialDeclarations

  public:
    //## Constructors (generated)
      MasterCardAdviceReason();

    //## Destructor (generated)
      virtual ~MasterCardAdviceReason();


    //## Other Operations (specified)
      //## Operation: bind%5059C2660075
      virtual void bind (reusable::Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::MasterCardAdviceReason%5059C1E60128.public preserve=yes
      //## end configuration::MasterCardAdviceReason%5059C1E60128.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::MasterCardAdviceReason%5059C1E60128.protected preserve=yes
      //## end configuration::MasterCardAdviceReason%5059C1E60128.protected

  private:
    // Additional Private Declarations
      //## begin configuration::MasterCardAdviceReason%5059C1E60128.private preserve=yes
      //## end configuration::MasterCardAdviceReason%5059C1E60128.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::MasterCardAdviceReason%5059C1E60128.implementation preserve=yes
      //## end configuration::MasterCardAdviceReason%5059C1E60128.implementation

};

//## begin configuration::MasterCardAdviceReason%5059C1E60128.postscript preserve=yes
//## end configuration::MasterCardAdviceReason%5059C1E60128.postscript

} // namespace configuration

//## begin module%5059C9F10390.epilog preserve=yes
//## end module%5059C9F10390.epilog


#endif
