//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3910689B00AE.cm preserve=no
//	$Date:   Dec 07 2016 15:40:36  $ $Author:   e1009652  $
//	$Revision:   1.8  $
//## end module%3910689B00AE.cm

//## begin module%3910689B00AE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3910689B00AE.cp

//## Module: CXOSCF05%3910689B00AE; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF05.hpp

#ifndef CXOSCF05_h
#define CXOSCF05_h 1

//## begin module%3910689B00AE.additionalIncludes preserve=no
//## end module%3910689B00AE.additionalIncludes

//## begin module%3910689B00AE.includes preserve=yes
// $Date:   Dec 07 2016 15:40:36  $ $Author:   e1009652  $ $Revision:   1.8  $
//## end module%3910689B00AE.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConversionItem;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%3910689B00AE.declarations preserve=no
//## end module%3910689B00AE.declarations

//## begin module%3910689B00AE.additionalDeclarations preserve=yes
//## end module%3910689B00AE.additionalDeclarations


namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConversionItem%391054860304.preface preserve=yes
//## end configuration::ConversionItem%391054860304.preface

//## Class: ConversionItem%391054860304
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3D2B052801E4;reusable::Query { -> F}
//## Uses: <unnamed>%425EB3BA035B;ConversionItem { -> F}
//## Uses: <unnamed>%584865C7030A;IF::Extract { -> F}

class DllExport ConversionItem : public reusable::Object  //## Inherits: <unnamed>%3910549D0159
{
  //## begin configuration::ConversionItem%391054860304.initialDeclarations preserve=yes
  //## end configuration::ConversionItem%391054860304.initialDeclarations

  public:
    //## Constructors (generated)
      ConversionItem();

    //## Constructors (specified)
      //## Operation: ConversionItem%3911D86A0201
      ConversionItem (const char* pszMember);

    //## Destructor (generated)
      virtual ~ConversionItem();


    //## Other Operations (specified)
      //## Operation: bind%39107AF00319
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%391C314802F4
      virtual const string& getFirst ();

      //## Operation: getSecond%391C314A01CA
      virtual const string& getSecond ();

      //## Operation: getThird%44BD1C52009C
      virtual const string& getThird ();

      //## Operation: setPredicate%583DCA770057
      virtual void setPredicate (Query& hQuery);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Member%3912F65D0360
      const string& getMember () const
      {
        //## begin configuration::ConversionItem::getMember%3912F65D0360.get preserve=no
        return m_strMember;
        //## end configuration::ConversionItem::getMember%3912F65D0360.get
      }


    // Additional Public Declarations
      //## begin configuration::ConversionItem%391054860304.public preserve=yes
      //## end configuration::ConversionItem%391054860304.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: CUST_ID%394FB6370055
      //## begin configuration::ConversionItem::CUST_ID%394FB6370055.attr preserve=no  private: string {U} 
      string m_strCUST_ID;
      //## end configuration::ConversionItem::CUST_ID%394FB6370055.attr

      //## Attribute: First%3911D7F802DA
      //## begin configuration::ConversionItem::First%3911D7F802DA.attr preserve=no  public: string {V} 
      string m_strFirst;
      //## end configuration::ConversionItem::First%3911D7F802DA.attr

      //## Attribute: Second%3912F65F0269
      //## begin configuration::ConversionItem::Second%3912F65F0269.attr preserve=no  public: string {V} 
      string m_strSecond;
      //## end configuration::ConversionItem::Second%3912F65F0269.attr

      //## Attribute: Third%3DF634AB00AB
      //## begin configuration::ConversionItem::Third%3DF634AB00AB.attr preserve=no  public: string {U} 
      string m_strThird;
      //## end configuration::ConversionItem::Third%3DF634AB00AB.attr

    // Additional Protected Declarations
      //## begin configuration::ConversionItem%391054860304.protected preserve=yes
      //## end configuration::ConversionItem%391054860304.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConversionItem%391054860304.private preserve=yes
      //## end configuration::ConversionItem%391054860304.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin configuration::ConversionItem::Member%3912F65D0360.attr preserve=no  public: string {V} 
      string m_strMember;
      //## end configuration::ConversionItem::Member%3912F65D0360.attr

    // Additional Implementation Declarations
      //## begin configuration::ConversionItem%391054860304.implementation preserve=yes
      //## end configuration::ConversionItem%391054860304.implementation

};

//## begin configuration::ConversionItem%391054860304.postscript preserve=yes
//## end configuration::ConversionItem%391054860304.postscript

} // namespace configuration

//## begin module%3910689B00AE.epilog preserve=yes
using namespace configuration;
//## end module%3910689B00AE.epilog


#endif
