//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3ACA17CF02C0.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3ACA17CF02C0.cm

//## begin module%3ACA17CF02C0.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%3ACA17CF02C0.cp

//## Module: CXOSCF39%3ACA17CF02C0; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF39.cpp

//## begin module%3ACA17CF02C0.additionalIncludes preserve=no
//## end module%3ACA17CF02C0.additionalIncludes

//## begin module%3ACA17CF02C0.includes preserve=yes
// $Date:   Mar 26 2009 13:40:52  $ $Author:   D92233  $ $Revision:   1.6  $
//## end module%3ACA17CF02C0.includes

#ifndef CXOSMN02_h
#include "CXODMN02.hpp"
#endif
#ifndef CXOSCF39_h
#include "CXODCF39.hpp"
#endif


//## begin module%3ACA17CF02C0.declarations preserve=no
//## end module%3ACA17CF02C0.declarations

//## begin module%3ACA17CF02C0.additionalDeclarations preserve=yes
//## end module%3ACA17CF02C0.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::MappingTable 

MappingTable::MappingTable()
  //## begin MappingTable::MappingTable%3ACA134A0013_const.hasinit preserve=no
  //## end MappingTable::MappingTable%3ACA134A0013_const.hasinit
  //## begin MappingTable::MappingTable%3ACA134A0013_const.initialization preserve=yes
  //## end MappingTable::MappingTable%3ACA134A0013_const.initialization
{
  //## begin configuration::MappingTable::MappingTable%3ACA134A0013_const.body preserve=yes
   memcpy(m_sID,"CF39",4);
  //## end configuration::MappingTable::MappingTable%3ACA134A0013_const.body
}

MappingTable::MappingTable (const char* pszName)
  //## begin configuration::MappingTable::MappingTable%3ACA1646008A.hasinit preserve=no
  //## end configuration::MappingTable::MappingTable%3ACA1646008A.hasinit
  //## begin configuration::MappingTable::MappingTable%3ACA1646008A.initialization preserve=yes
   : ConfigurationTable(pszName)
  //## end configuration::MappingTable::MappingTable%3ACA1646008A.initialization
{
  //## begin configuration::MappingTable::MappingTable%3ACA1646008A.body preserve=yes
   memcpy(m_sID,"CF39",4);
  //## end configuration::MappingTable::MappingTable%3ACA1646008A.body
}


MappingTable::~MappingTable()
{
  //## begin configuration::MappingTable::~MappingTable%3ACA134A0013_dest.body preserve=yes
   m_hMapData.erase(m_hMapData.begin(),m_hMapData.end());
  //## end configuration::MappingTable::~MappingTable%3ACA134A0013_dest.body
}



//## Other Operations (implementation)
bool MappingTable::add (const string& strPrimary, const string& strSecondary, const string& strTertiary, const string& strResult)
{
  //## begin configuration::MappingTable::add%3ACA169A03A2.body preserve=yes
   string strKey(strPrimary + "~" + strSecondary + "~" + strTertiary);
   m_hMapData.insert(map<string,string,less<string> >::value_type(strKey,strResult));
   return true;
  //## end configuration::MappingTable::add%3ACA169A03A2.body
}

bool MappingTable::find (const string& strPrimary, const string& strSecondary, const string& strTertiary, string& strResult)
{
  //## begin configuration::MappingTable::find%3ACA16A102B1.body preserve=yes
   m_pCount[0]->increment();
   string strKey(strPrimary + "~" + strSecondary + "~" + strTertiary);
   map<string,string,less <string> >::iterator p;
   p = m_hMapData.find(strKey);
   if (p != m_hMapData.end())
   {
      strResult = (*p).second;   // MATCH 1 (exact match on all three columns)
      return true;
   }
   strKey = strPrimary + "~" + strSecondary + "~*";
   p = m_hMapData.find(strKey);
   if (p != m_hMapData.end())
   {
      strResult = (*p).second;   // MATCH 2 (match on primary/secondary and wildcard on tertiary)
      return true;
   }
   strKey = strPrimary + "~*~" + strTertiary;
   p = m_hMapData.find(strKey);
   if (p != m_hMapData.end())
   {
      strResult = (*p).second;   // MATCH 3 (match on primary/tertiary and wildcard on secondary)
      return true;
   }
   strKey = strPrimary + "~*~*";
   p = m_hMapData.find(strKey);
   if (p != m_hMapData.end())
   {
      strResult = (*p).second;   // MATCH 4 (match on primary and wildcard on secondary/tertiary)
      return true;
   }
   m_pCount[1]->increment();
   return false;
  //## end configuration::MappingTable::find%3ACA16A102B1.body
}

// Additional Declarations
  //## begin configuration::MappingTable%3ACA134A0013.declarations preserve=yes
  //## end configuration::MappingTable%3ACA134A0013.declarations

} // namespace configuration

//## begin module%3ACA17CF02C0.epilog preserve=yes
//## end module%3ACA17CF02C0.epilog
