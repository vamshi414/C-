//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFC3D6D0148.cm preserve=no
//	$Date:   Dec 12 2016 13:05:36  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%3FFC3D6D0148.cm

//## begin module%3FFC3D6D0148.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFC3D6D0148.cp

//## Module: CXOSCF52%3FFC3D6D0148; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF52.hpp

#ifndef CXOSCF52_h
#define CXOSCF52_h 1

//## begin module%3FFC3D6D0148.additionalIncludes preserve=no
//## end module%3FFC3D6D0148.additionalIncludes

//## begin module%3FFC3D6D0148.includes preserve=yes
// $Date:   Dec 12 2016 13:05:36  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%3FFC3D6D0148.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
//## begin module%3FFC3D6D0148.declarations preserve=no
//## end module%3FFC3D6D0148.declarations

//## begin module%3FFC3D6D0148.additionalDeclarations preserve=yes
//## end module%3FFC3D6D0148.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexPOSConditionCode3%3FFC3BED0157.preface preserve=yes
//## end configuration::ConnexPOSConditionCode3%3FFC3BED0157.preface

//## Class: ConnexPOSConditionCode3%3FFC3BED0157
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FFC3C3B03A9;reusable::Query { -> F}

class DllExport ConnexPOSConditionCode3 : public ConversionItem  //## Inherits: <unnamed>%3FFC3C270157
{
  //## begin configuration::ConnexPOSConditionCode3%3FFC3BED0157.initialDeclarations preserve=yes
  //## end configuration::ConnexPOSConditionCode3%3FFC3BED0157.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexPOSConditionCode3();

    //## Destructor (generated)
      virtual ~ConnexPOSConditionCode3();


    //## Other Operations (specified)
      //## Operation: bind%3FFC3C51009C
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%5847162201FB
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexPOSConditionCode3%3FFC3BED0157.public preserve=yes
      //## end configuration::ConnexPOSConditionCode3%3FFC3BED0157.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexPOSConditionCode3%3FFC3BED0157.protected preserve=yes
      //## end configuration::ConnexPOSConditionCode3%3FFC3BED0157.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexPOSConditionCode3%3FFC3BED0157.private preserve=yes
      //## end configuration::ConnexPOSConditionCode3%3FFC3BED0157.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexPOSConditionCode3%3FFC3BED0157.implementation preserve=yes
      //## end configuration::ConnexPOSConditionCode3%3FFC3BED0157.implementation

};

//## begin configuration::ConnexPOSConditionCode3%3FFC3BED0157.postscript preserve=yes
//## end configuration::ConnexPOSConditionCode3%3FFC3BED0157.postscript

} // namespace configuration

//## begin module%3FFC3D6D0148.epilog preserve=yes
using namespace configuration;
//## end module%3FFC3D6D0148.epilog


#endif
