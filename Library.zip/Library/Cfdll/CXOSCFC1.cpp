//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6147133E0149.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%6147133E0149.cm

//## begin module%6147133E0149.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%6147133E0149.cp

//## Module: CXOSCFC1%6147133E0149; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFC1.cpp

//## begin module%6147133E0149.additionalIncludes preserve=no
//## end module%6147133E0149.additionalIncludes

//## begin module%6147133E0149.includes preserve=yes
//## end module%6147133E0149.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSCFC1_h
#include "CXODCFC1.hpp"
#endif


//## begin module%6147133E0149.declarations preserve=no
//## end module%6147133E0149.declarations

//## begin module%6147133E0149.additionalDeclarations preserve=yes
//## end module%6147133E0149.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::LoyaltyBin 

LoyaltyBin::LoyaltyBin()
   //## begin LoyaltyBin::LoyaltyBin%614713A801F3_const.hasinit preserve=no
   //## end LoyaltyBin::LoyaltyBin%614713A801F3_const.hasinit
   //## begin LoyaltyBin::LoyaltyBin%614713A801F3_const.initialization preserve=yes
   //## end LoyaltyBin::LoyaltyBin%614713A801F3_const.initialization
{
   //## begin configuration::LoyaltyBin::LoyaltyBin%614713A801F3_const.body preserve=yes
   memcpy(m_sID, "CFC1", 4);
   //## end configuration::LoyaltyBin::LoyaltyBin%614713A801F3_const.body
}


LoyaltyBin::~LoyaltyBin()
{
   //## begin configuration::LoyaltyBin::~LoyaltyBin%614713A801F3_dest.body preserve=yes
   //## end configuration::LoyaltyBin::~LoyaltyBin%614713A801F3_dest.body
}



//## Other Operations (implementation)
void LoyaltyBin::bind(Query& hQuery)
{
   //## begin configuration::LoyaltyBin::bind%614714930301.body preserve=yes
   hQuery.setQualifier("QUALIFY", "LOYALTY_BIN");
   hQuery.bind("LOYALTY_BIN", "RECORD_TYPE", Column::STRING, &m_strFirst);
   hQuery.bind("LOYALTY_BIN", "INST_ID", Column::STRING, &m_strINST_ID);
   hQuery.bind("LOYALTY_BIN", "BIN", Column::STRING, &m_strBIN);
   hQuery.bind("LOYALTY_BIN", "PROC_ID", Column::STRING, &m_strPROC_ID);
   hQuery.bind("LOYALTY_BIN", "PROGRAM_ID", Column::STRING, &m_strPROGRAM_ID);
   hQuery.bind("LOYALTY_BIN", "ASSOC_ID", Column::STRING, &m_strASSOC_ID);
   hQuery.bind("LOYALTY_BIN", "CORP_ID", Column::STRING, &m_strCORP_ID);
   hQuery.bind("LOYALTY_BIN", "AGENT_ID", Column::STRING, &m_strAGENT_ID);
   hQuery.bind("LOYALTY_BIN", "LOYALTY_FLG", Column::STRING, &m_strSecond);
   hQuery.setBasicPredicate("LOYALTY_BIN", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("LOYALTY_BIN", "CC_STATE", "=", "A");
   Extract::instance()->getSpec("CUSTOMER", m_strCUST_ID);
   string strTemp = "('" + m_strCUST_ID + "','****')";
   hQuery.setBasicPredicate("LOYALTY_BIN", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("RECORD_TYPE ASC,INST_ID ASC,BIN ASC,CUST_ID DESC");
   //## end configuration::LoyaltyBin::bind%614714930301.body
}

bool LoyaltyBin::getBin(const string& strRECORD_TYPE, const string& strINST_ID, const string& strBIN, int& iLength, string& strLOYALTY_FLG)
{
   //## begin configuration::LoyaltyBin::getBin%614714BA0148.body preserve=yes
   string strFirst(strRECORD_TYPE);
   strFirst.resize(6, ' ');
   strFirst += strINST_ID;
   strFirst.resize(17, ' ');
   strFirst += strBIN;
   strFirst.resize(28, ' ');
   iLength = 10;
   while (strFirst.length() > 23)
   {
      strFirst.resize(strFirst.length() - 1);
      if (ConfigurationRepository::instance()->translate("LOYALTY_BIN", strFirst, strLOYALTY_FLG, " ", " ", 0, false))
         return true;
      iLength--;
   }
   iLength = 10;
   return false;
   //## end configuration::LoyaltyBin::getBin%614714BA0148.body
}

const string& LoyaltyBin::getFirst()
{
   //## begin configuration::LoyaltyBin::getFirst%61471AF30200.body preserve=yes
   m_strFirst.resize(6, ' ');
   m_strFirst += m_strINST_ID;
   m_strFirst.resize(17, ' ');
   m_strFirst += m_strBIN;
   return m_strFirst;
   //## end configuration::LoyaltyBin::getFirst%61471AF30200.body
}

const string& LoyaltyBin::getThird()
{
   //## begin configuration::LoyaltyBin::getThird%614715310014.body preserve=yes
   m_strThird.assign(m_strPROGRAM_ID);
   m_strThird.resize(6, ' ');
   m_strThird.append(m_strASSOC_ID);
   m_strThird.resize(8, ' ');
   m_strThird.append(m_strCORP_ID);
   m_strThird.resize(17, ' ');
   m_strThird.append(m_strAGENT_ID);
   m_strThird.resize(23, ' ');
   m_strThird.append(m_strINST_ID);
   m_strThird.resize(34, ' ');
   m_strThird.append(m_strPROC_ID);
   m_strThird.resize(42, ' ');
   return m_strThird;
   //## end configuration::LoyaltyBin::getThird%614715310014.body
}

// Additional Declarations
  //## begin configuration::LoyaltyBin%614713A801F3.declarations preserve=yes
  //## end configuration::LoyaltyBin%614713A801F3.declarations

} // namespace configuration

//## begin module%6147133E0149.epilog preserve=yes
//## end module%6147133E0149.epilog
