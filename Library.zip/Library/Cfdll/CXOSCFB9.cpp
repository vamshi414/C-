//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%61A79517005F.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%61A79517005F.cm

//## begin module%61A79517005F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%61A79517005F.cp

//## Module: CXOSCFB9%61A79517005F; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFB9.cpp

//## begin module%61A79517005F.additionalIncludes preserve=no
//## end module%61A79517005F.additionalIncludes

//## begin module%61A79517005F.includes preserve=yes
//## end module%61A79517005F.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFB9_h
#include "CXODCFB9.hpp"
#endif


//## begin module%61A79517005F.declarations preserve=no
//## end module%61A79517005F.declarations

//## begin module%61A79517005F.additionalDeclarations preserve=yes
//## end module%61A79517005F.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::NetworkStatus 

NetworkStatus::NetworkStatus()
  //## begin NetworkStatus::NetworkStatus%61A797C8022F_const.hasinit preserve=no
  //## end NetworkStatus::NetworkStatus%61A797C8022F_const.hasinit
  //## begin NetworkStatus::NetworkStatus%61A797C8022F_const.initialization preserve=yes
   : ConversionItem("## CFB9 XLATE NETWORK STATUS")
  //## end NetworkStatus::NetworkStatus%61A797C8022F_const.initialization
{
  //## begin configuration::NetworkStatus::NetworkStatus%61A797C8022F_const.body preserve=yes
   memcpy(m_sID, "CFB9", 4);
  //## end configuration::NetworkStatus::NetworkStatus%61A797C8022F_const.body
}


NetworkStatus::~NetworkStatus()
{
  //## begin configuration::NetworkStatus::~NetworkStatus%61A797C8022F_dest.body preserve=yes
  //## end configuration::NetworkStatus::~NetworkStatus%61A797C8022F_dest.body
}



//## Other Operations (implementation)
void NetworkStatus::bind (Query& hQuery)
{
  //## begin configuration::NetworkStatus::bind%61A79E9702BB.body preserve=yes
   hQuery.setQualifier("QUALIFY", "X_NETWORK_STATUS");
   hQuery.bind("X_NETWORK_STATUS", "NET_ID", Column::STRING, &m_strFirst);
   hQuery.bind("X_NETWORK_STATUS", "NET_CASE_STATUS", Column::STRING, &m_strNET_CASE_STATUS);
   hQuery.bind("X_NETWORK_STATUS", "REQUEST_TYPE", Column::STRING, &m_strSecond);
   hQuery.bind("X_NETWORK_STATUS", "STATUS", Column::STRING, &m_strThird);
   hQuery.setBasicPredicate("X_NETWORK_STATUS", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_NETWORK_STATUS", "CC_STATE", "=", "A");
   string strTemp = "('" + m_strCUST_ID + "','****')";
   hQuery.setBasicPredicate("X_NETWORK_STATUS", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("X_NETWORK_STATUS.NET_ID ASC, X_NETWORK_STATUS.NET_CASE_STATUS ASC,X_NETWORK_STATUS.CUST_ID DESC");
  //## end configuration::NetworkStatus::bind%61A79E9702BB.body
}

const string& NetworkStatus::getFirst ()
{
  //## begin configuration::NetworkStatus::getFirst%61A7A33800F3.body preserve=yes
   m_strFirst.resize(3, ' ');
   m_strFirst.append(m_strNET_CASE_STATUS);
   m_strFirst.resize(103, ' ');
   return m_strFirst;
  //## end configuration::NetworkStatus::getFirst%61A7A33800F3.body
}

const string& NetworkStatus::getSecond ()
{
  //## begin configuration::NetworkStatus::getSecond%61A7A3610309.body preserve=yes
   m_strSecond.resize(4, ' ');
   m_strSecond.append(m_strThird);
   m_strSecond.resize(8, ' ');
   return m_strSecond;
  //## end configuration::NetworkStatus::getSecond%61A7A3610309.body
}

// Additional Declarations
  //## begin configuration::NetworkStatus%61A797C8022F.declarations preserve=yes
  //## end configuration::NetworkStatus%61A797C8022F.declarations

} // namespace configuration

//## begin module%61A79517005F.epilog preserve=yes
//## end module%61A79517005F.epilog