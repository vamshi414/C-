//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EF27A7800C8.cm preserve=no
//	$Date:   Jul 24 2020 16:37:24  $ $Author:   e1089842  $
//	$Revision:   1.0  $
//## end module%5EF27A7800C8.cm

//## begin module%5EF27A7800C8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5EF27A7800C8.cp

//## Module: CXOSCFB5%5EF27A7800C8; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Dn_codes\V03.1A.R007\Dn\Server\Library\Cfdll\CXODCFB5.hpp

#ifndef CXOSCFB5_h
#define CXOSCFB5_h 1

//## begin module%5EF27A7800C8.additionalIncludes preserve=no
//## end module%5EF27A7800C8.additionalIncludes

//## begin module%5EF27A7800C8.includes preserve=yes
//## end module%5EF27A7800C8.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%5EF27A7800C8.declarations preserve=no
//## end module%5EF27A7800C8.declarations

//## begin module%5EF27A7800C8.additionalDeclarations preserve=yes
//## end module%5EF27A7800C8.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::CountryCodeNumToRegion%5EF2792F011A.preface preserve=yes
//## end configuration::CountryCodeNumToRegion%5EF2792F011A.preface

//## Class: CountryCodeNumToRegion%5EF2792F011A
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5EF2832F00C7;IF::Extract { -> F}
//## Uses: <unnamed>%5EF283380093;reusable::Query { -> F}

class DllExport CountryCodeNumToRegion : public ConversionItem  //## Inherits: <unnamed>%5EF2832901AC
{
  //## begin configuration::CountryCodeNumToRegion%5EF2792F011A.initialDeclarations preserve=yes
  //## end configuration::CountryCodeNumToRegion%5EF2792F011A.initialDeclarations

  public:
    //## Constructors (generated)
      CountryCodeNumToRegion();

    //## Destructor (generated)
      virtual ~CountryCodeNumToRegion();


    //## Other Operations (specified)
      //## Operation: bind%5EF282580086
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::CountryCodeNumToRegion%5EF2792F011A.public preserve=yes
      //## end configuration::CountryCodeNumToRegion%5EF2792F011A.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::CountryCodeNumToRegion%5EF2792F011A.protected preserve=yes
      //## end configuration::CountryCodeNumToRegion%5EF2792F011A.protected

  private:
    // Additional Private Declarations
      //## begin configuration::CountryCodeNumToRegion%5EF2792F011A.private preserve=yes
      //## end configuration::CountryCodeNumToRegion%5EF2792F011A.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::CountryCodeNumToRegion%5EF2792F011A.implementation preserve=yes
      //## end configuration::CountryCodeNumToRegion%5EF2792F011A.implementation

};

//## begin configuration::CountryCodeNumToRegion%5EF2792F011A.postscript preserve=yes
//## end configuration::CountryCodeNumToRegion%5EF2792F011A.postscript

} // namespace configuration

//## begin module%5EF27A7800C8.epilog preserve=yes
//## end module%5EF27A7800C8.epilog


#endif
