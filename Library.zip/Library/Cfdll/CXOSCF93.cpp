//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4641A96F02E4.cm preserve=no
//## end module%4641A96F02E4.cm

//## begin module%4641A96F02E4.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4641A96F02E4.cp

//## Module: CXOSCF93%4641A96F02E4; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF93.cpp

//## begin module%4641A96F02E4.additionalIncludes preserve=no
//## end module%4641A96F02E4.additionalIncludes

//## begin module%4641A96F02E4.includes preserve=yes
//## end module%4641A96F02E4.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF93_h
#include "CXODCF93.hpp"
#endif


//## begin module%4641A96F02E4.declarations preserve=no
//## end module%4641A96F02E4.declarations

//## begin module%4641A96F02E4.additionalDeclarations preserve=yes
//## end module%4641A96F02E4.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::GenericTranslation 

GenericTranslation::GenericTranslation()
  //## begin GenericTranslation::GenericTranslation%4641AA5C011D_const.hasinit preserve=no
  //## end GenericTranslation::GenericTranslation%4641AA5C011D_const.hasinit
  //## begin GenericTranslation::GenericTranslation%4641AA5C011D_const.initialization preserve=yes
  : ConversionItem("## CF93 XLATE X_GENERIC")
  //## end GenericTranslation::GenericTranslation%4641AA5C011D_const.initialization
{
  //## begin configuration::GenericTranslation::GenericTranslation%4641AA5C011D_const.body preserve=yes
   memcpy(m_sID,"CF93",4);
  //## end configuration::GenericTranslation::GenericTranslation%4641AA5C011D_const.body
}

GenericTranslation::GenericTranslation (const char* pszX_TYPE)
  //## begin configuration::GenericTranslation::GenericTranslation%63998A5B0349.hasinit preserve=no
  //## end configuration::GenericTranslation::GenericTranslation%63998A5B0349.hasinit
  //## begin configuration::GenericTranslation::GenericTranslation%63998A5B0349.initialization preserve=yes
   : ConversionItem("## CF93 XLATE X_GENERIC")
   , m_strX_TYPE(pszX_TYPE)
  //## end configuration::GenericTranslation::GenericTranslation%63998A5B0349.initialization
{
  //## begin configuration::GenericTranslation::GenericTranslation%63998A5B0349.body preserve=yes
   memcpy(m_sID,"CF93",4);
  //## end configuration::GenericTranslation::GenericTranslation%63998A5B0349.body
}


GenericTranslation::~GenericTranslation()
{
  //## begin configuration::GenericTranslation::~GenericTranslation%4641AA5C011D_dest.body preserve=yes
  //## end configuration::GenericTranslation::~GenericTranslation%4641AA5C011D_dest.body
}



//## Other Operations (implementation)
void GenericTranslation::bind (Query& hQuery)
{
  //## begin configuration::GenericTranslation::bind%4641AB370263.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_GENERIC");
   hQuery.bind("X_GENERIC","X_TYPE",Column::STRING,&m_strFirst);
   hQuery.bind("X_GENERIC","FROM_VALUE",Column::STRING,&m_strFROM_VALUE);
   hQuery.bind("X_GENERIC","TO_VALUE",Column::STRING,&m_strSecond);
   hQuery.bind("X_GENERIC","CC_TSTAMP_CHANGE",Column::STRING,&m_strThird);
   if (!m_strX_TYPE.empty())
      hQuery.setBasicPredicate("X_GENERIC","X_TYPE","=",m_strX_TYPE.c_str());
   hQuery.setBasicPredicate("X_GENERIC","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_GENERIC","CC_STATE","=","A");
   hQuery.setOrderByClause("X_GENERIC.X_TYPE ASC,X_GENERIC.FROM_VALUE ASC");

  //## end configuration::GenericTranslation::bind%4641AB370263.body
}

const string& GenericTranslation::getFirst ()
{
  //## begin configuration::GenericTranslation::getFirst%4647E9AC003E.body preserve=yes
   if (!m_strX_TYPE.empty())
      return m_strFROM_VALUE;
   m_strFirst.resize(15,' ');
   m_strFirst.append(m_strFROM_VALUE);
   m_strFirst.resize(35,' ');
   return m_strFirst;
  //## end configuration::GenericTranslation::getFirst%4647E9AC003E.body
}

void GenericTranslation::setPredicate (Query& hQuery)
{
  //## begin configuration::GenericTranslation::setPredicate%58471755038D.body preserve=yes
   if (!m_strX_TYPE.empty())
      hQuery.setBasicPredicate("X_GENERIC","X_TYPE","=",m_strX_TYPE.c_str());
   hQuery.setBasicPredicate("X_GENERIC","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_GENERIC","CC_STATE","=","A");
  //## end configuration::GenericTranslation::setPredicate%58471755038D.body
}

// Additional Declarations
  //## begin configuration::GenericTranslation%4641AA5C011D.declarations preserve=yes
  //## end configuration::GenericTranslation%4641AA5C011D.declarations

} // namespace configuration

//## begin module%4641A96F02E4.epilog preserve=yes
//## end module%4641A96F02E4.epilog
