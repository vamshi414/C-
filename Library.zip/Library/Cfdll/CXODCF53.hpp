//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFC3DDC03D8.cm preserve=no
//	$Date:   Dec 12 2016 13:07:26  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%3FFC3DDC03D8.cm

//## begin module%3FFC3DDC03D8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFC3DDC03D8.cp

//## Module: CXOSCF53%3FFC3DDC03D8; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF53.hpp

#ifndef CXOSCF53_h
#define CXOSCF53_h 1

//## begin module%3FFC3DDC03D8.additionalIncludes preserve=no
//## end module%3FFC3DDC03D8.additionalIncludes

//## begin module%3FFC3DDC03D8.includes preserve=yes
// $Date:   Dec 12 2016 13:07:26  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%3FFC3DDC03D8.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
//## begin module%3FFC3DDC03D8.declarations preserve=no
//## end module%3FFC3DDC03D8.declarations

//## begin module%3FFC3DDC03D8.additionalDeclarations preserve=yes
//## end module%3FFC3DDC03D8.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexPOSConditionCode4%3FFC3C7600BB.preface preserve=yes
//## end configuration::ConnexPOSConditionCode4%3FFC3C7600BB.preface

//## Class: ConnexPOSConditionCode4%3FFC3C7600BB
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FFC3CA80213;reusable::Query { -> F}

class DllExport ConnexPOSConditionCode4 : public ConversionItem  //## Inherits: <unnamed>%3FFC3C950290
{
  //## begin configuration::ConnexPOSConditionCode4%3FFC3C7600BB.initialDeclarations preserve=yes
  //## end configuration::ConnexPOSConditionCode4%3FFC3C7600BB.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexPOSConditionCode4();

    //## Destructor (generated)
      virtual ~ConnexPOSConditionCode4();


    //## Other Operations (specified)
      //## Operation: bind%3FFC3CB4004E
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%5847162F0108
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexPOSConditionCode4%3FFC3C7600BB.public preserve=yes
      //## end configuration::ConnexPOSConditionCode4%3FFC3C7600BB.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexPOSConditionCode4%3FFC3C7600BB.protected preserve=yes
      //## end configuration::ConnexPOSConditionCode4%3FFC3C7600BB.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexPOSConditionCode4%3FFC3C7600BB.private preserve=yes
      //## end configuration::ConnexPOSConditionCode4%3FFC3C7600BB.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexPOSConditionCode4%3FFC3C7600BB.implementation preserve=yes
      //## end configuration::ConnexPOSConditionCode4%3FFC3C7600BB.implementation

};

//## begin configuration::ConnexPOSConditionCode4%3FFC3C7600BB.postscript preserve=yes
//## end configuration::ConnexPOSConditionCode4%3FFC3C7600BB.postscript

} // namespace configuration

//## begin module%3FFC3DDC03D8.epilog preserve=yes
using namespace configuration;
//## end module%3FFC3DDC03D8.epilog


#endif
