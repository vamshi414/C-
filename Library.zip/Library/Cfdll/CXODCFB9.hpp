//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%61A795150191.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%61A795150191.cm

//## begin module%61A795150191.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%61A795150191.cp

//## Module: CXOSCFB9%61A795150191; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXODCFB9.hpp

#ifndef CXOSCFB9_h
#define CXOSCFB9_h 1

//## begin module%61A795150191.additionalIncludes preserve=no
//## end module%61A795150191.additionalIncludes

//## begin module%61A795150191.includes preserve=yes
//## end module%61A795150191.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%61A795150191.declarations preserve=no
//## end module%61A795150191.declarations

//## begin module%61A795150191.additionalDeclarations preserve=yes
//## end module%61A795150191.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::NetworkStatus%61A797C8022F.preface preserve=yes
//## end configuration::NetworkStatus%61A797C8022F.preface

//## Class: NetworkStatus%61A797C8022F
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%61A799010192;IF::Extract { -> F}
//## Uses: <unnamed>%61A799220149;reusable::Query { -> F}

class DllExport NetworkStatus : public ConversionItem  //## Inherits: <unnamed>%61A798D60148
{
  //## begin configuration::NetworkStatus%61A797C8022F.initialDeclarations preserve=yes
  //## end configuration::NetworkStatus%61A797C8022F.initialDeclarations

  public:
    //## Constructors (generated)
      NetworkStatus();

    //## Destructor (generated)
      virtual ~NetworkStatus();


    //## Other Operations (specified)
      //## Operation: bind%61A79E9702BB
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%61A7A33800F3
      virtual const reusable::string& getFirst ();

      //## Operation: getSecond%61A7A3610309
      virtual const reusable::string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::NetworkStatus%61A797C8022F.public preserve=yes
      //## end configuration::NetworkStatus%61A797C8022F.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::NetworkStatus%61A797C8022F.protected preserve=yes
      //## end configuration::NetworkStatus%61A797C8022F.protected

  private:
    // Additional Private Declarations
      //## begin configuration::NetworkStatus%61A797C8022F.private preserve=yes
      //## end configuration::NetworkStatus%61A797C8022F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: NET_ID%61A79A1A006D
      //## begin configuration::NetworkStatus::NET_ID%61A79A1A006D.attr preserve=no  private: string {U} 
      string m_strNET_ID;
      //## end configuration::NetworkStatus::NET_ID%61A79A1A006D.attr

      //## Attribute: NET_CASE_STATUS%61A79A3200E0
      //## begin configuration::NetworkStatus::NET_CASE_STATUS%61A79A3200E0.attr preserve=no  private: string {U} 
      string m_strNET_CASE_STATUS;
      //## end configuration::NetworkStatus::NET_CASE_STATUS%61A79A3200E0.attr

    // Additional Implementation Declarations
      //## begin configuration::NetworkStatus%61A797C8022F.implementation preserve=yes
      //## end configuration::NetworkStatus%61A797C8022F.implementation

};

//## begin configuration::NetworkStatus%61A797C8022F.postscript preserve=yes
//## end configuration::NetworkStatus%61A797C8022F.postscript

} // namespace configuration

//## begin module%61A795150191.epilog preserve=yes
//## end module%61A795150191.epilog


#endif
