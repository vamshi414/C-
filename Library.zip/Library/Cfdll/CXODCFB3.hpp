//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5D9588E40288.cm preserve=no
//	$Date:   Nov 27 2019 14:43:18  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5D9588E40288.cm

//## begin module%5D9588E40288.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5D9588E40288.cp

//## Module: CXOSCFB3%5D9588E40288; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\D Drive\Devel 9B\Dn\Server\Library\Cfdll\CXODCFB3.hpp

#ifndef CXOSCFB3_h
#define CXOSCFB3_h 1

//## begin module%5D9588E40288.additionalIncludes preserve=no
//## end module%5D9588E40288.additionalIncludes

//## begin module%5D9588E40288.includes preserve=yes
//## end module%5D9588E40288.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%5D9588E40288.declarations preserve=no
//## end module%5D9588E40288.declarations

//## begin module%5D9588E40288.additionalDeclarations preserve=yes
//## end module%5D9588E40288.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::NCRProcessCode%5D95867C02ED.preface preserve=yes
//## end configuration::NCRProcessCode%5D95867C02ED.preface

//## Class: NCRProcessCode%5D95867C02ED
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5D9587560100;IF::Extract { -> F}
//## Uses: <unnamed>%5D9587580300;reusable::Query { -> F}

class DllExport NCRProcessCode : public ConversionItem  //## Inherits: <unnamed>%5D9586F0039B
{
  //## begin configuration::NCRProcessCode%5D95867C02ED.initialDeclarations preserve=yes
  //## end configuration::NCRProcessCode%5D95867C02ED.initialDeclarations

  public:
    //## Constructors (generated)
      NCRProcessCode();

    //## Destructor (generated)
      virtual ~NCRProcessCode();


    //## Other Operations (specified)
      //## Operation: bind%5D958DEC00D2
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getFirst%5D958EA300FF
      virtual const string& getFirst ();

      //## Operation: getSecond%5D958ECD01F6
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::NCRProcessCode%5D95867C02ED.public preserve=yes
      //## end configuration::NCRProcessCode%5D95867C02ED.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::NCRProcessCode%5D95867C02ED.protected preserve=yes
      //## end configuration::NCRProcessCode%5D95867C02ED.protected

  private:
    // Additional Private Declarations
      //## begin configuration::NCRProcessCode%5D95867C02ED.private preserve=yes
      //## end configuration::NCRProcessCode%5D95867C02ED.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: NCR_PROCESS_CODE%5D95876B00CD
      //## begin configuration::NCRProcessCode::NCR_PROCESS_CODE%5D95876B00CD.attr preserve=no  private: string {U} 
      string m_strNCR_PROCESS_CODE;
      //## end configuration::NCRProcessCode::NCR_PROCESS_CODE%5D95876B00CD.attr

      //## Attribute: NCR_MTI%5D958B030149
      //## begin configuration::NCRProcessCode::NCR_MTI%5D958B030149.attr preserve=no  private: string {U} 
      string m_strNCR_MTI;
      //## end configuration::NCRProcessCode::NCR_MTI%5D958B030149.attr

      //## Attribute: NCR_PRE_AUTH%5D958B0D006E
      //## begin configuration::NCRProcessCode::NCR_PRE_AUTH%5D958B0D006E.attr preserve=no  private: string {U} 
      string m_strNCR_PRE_AUTH;
      //## end configuration::NCRProcessCode::NCR_PRE_AUTH%5D958B0D006E.attr

      //## Attribute: PROCESS_CODE%5D958B0D0298
      //## begin configuration::NCRProcessCode::PROCESS_CODE%5D958B0D0298.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::NCRProcessCode::PROCESS_CODE%5D958B0D0298.attr

      //## Attribute: MSG_CLASS%5D958BA002C4
      //## begin configuration::NCRProcessCode::MSG_CLASS%5D958BA002C4.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::NCRProcessCode::MSG_CLASS%5D958BA002C4.attr

      //## Attribute: PRE_AUTH%5D958BAB0201
      //## begin configuration::NCRProcessCode::PRE_AUTH%5D958BAB0201.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::NCRProcessCode::PRE_AUTH%5D958BAB0201.attr

      //## Attribute: MEDIA_TYPE%5D958BB80058
      //## begin configuration::NCRProcessCode::MEDIA_TYPE%5D958BB80058.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::NCRProcessCode::MEDIA_TYPE%5D958BB80058.attr

    // Additional Implementation Declarations
      //## begin configuration::NCRProcessCode%5D95867C02ED.implementation preserve=yes
      //## end configuration::NCRProcessCode%5D95867C02ED.implementation

};

//## begin configuration::NCRProcessCode%5D95867C02ED.postscript preserve=yes
//## end configuration::NCRProcessCode%5D95867C02ED.postscript

} // namespace configuration

//## begin module%5D9588E40288.epilog preserve=yes
//## end module%5D9588E40288.epilog


#endif
