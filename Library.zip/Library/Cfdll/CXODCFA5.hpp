//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%577405AF00C1.cm preserve=no
//	$Date:   Apr 04 2017 13:59:54  $ $Author:   e1009591  $
//	$Revision:   1.1  $
//## end module%577405AF00C1.cm

//## begin module%577405AF00C1.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%577405AF00C1.cp

//## Module: CXOSCFA5%577405AF00C1; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.5B.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCFA5.hpp

#ifndef CXOSCFA5_h
#define CXOSCFA5_h 1

//## begin module%577405AF00C1.additionalIncludes preserve=no
//## end module%577405AF00C1.additionalIncludes

//## begin module%577405AF00C1.includes preserve=yes
//## end module%577405AF00C1.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%577405AF00C1.declarations preserve=no
//## end module%577405AF00C1.declarations

//## begin module%577405AF00C1.additionalDeclarations preserve=yes
//## end module%577405AF00C1.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ActionType%57740458039E.preface preserve=yes
//## end configuration::ActionType%57740458039E.preface

//## Class: ActionType%57740458039E
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%577404C402DF;IF::Extract { -> F}
//## Uses: <unnamed>%577404D40087;reusable::Query { -> F}

class DllExport ActionType : public ConversionItem  //## Inherits: <unnamed>%577404A10325
{
  //## begin configuration::ActionType%57740458039E.initialDeclarations preserve=yes
  //## end configuration::ActionType%57740458039E.initialDeclarations

  public:
    //## Constructors (generated)
      ActionType();

    //## Destructor (generated)
      virtual ~ActionType();


    //## Other Operations (specified)
      //## Operation: bind%577404DF0073
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%5774055801D0
      virtual const string& getFirst ();

      //## Operation: getSecond%5774050F00E0
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::ActionType%57740458039E.public preserve=yes
      //## end configuration::ActionType%57740458039E.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ActionType%57740458039E.protected preserve=yes
      //## end configuration::ActionType%57740458039E.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ActionType%57740458039E.private preserve=yes
      //## end configuration::ActionType%57740458039E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ACTION_TYPE%5774080501F0
      //## begin configuration::ActionType::ACTION_TYPE%5774080501F0.attr preserve=no  private: string {U} 
      string m_strACTION_TYPE;
      //## end configuration::ActionType::ACTION_TYPE%5774080501F0.attr

      //## Attribute: NETWORK_ID%577407DA02A5
      //## begin configuration::ActionType::NETWORK_ID%577407DA02A5.attr preserve=no  private: string {U} 
      string m_strNETWORK_ID;
      //## end configuration::ActionType::NETWORK_ID%577407DA02A5.attr

      //## Attribute: REQUEST_TYPE%577405190270
      //## begin configuration::ActionType::REQUEST_TYPE%577405190270.attr preserve=no  private: string {U} 
      string m_strREQUEST_TYPE;
      //## end configuration::ActionType::REQUEST_TYPE%577405190270.attr

      //## Attribute: ROLE%5774051E0388
      //## begin configuration::ActionType::ROLE%5774051E0388.attr preserve=no  private: string {U} 
      string m_strROLE;
      //## end configuration::ActionType::ROLE%5774051E0388.attr

    // Additional Implementation Declarations
      //## begin configuration::ActionType%57740458039E.implementation preserve=yes
      string m_strSTATUS;
      //## end configuration::ActionType%57740458039E.implementation

};

//## begin configuration::ActionType%57740458039E.postscript preserve=yes
//## end configuration::ActionType%57740458039E.postscript

} // namespace configuration

//## begin module%577405AF00C1.epilog preserve=yes
//## end module%577405AF00C1.epilog


#endif
