//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%400551C70271.cm preserve=no
//	$Date:   Dec 16 2016 15:26:48  $ $Author:   e1009652  $
//	$Revision:   1.4  $
//## end module%400551C70271.cm

//## begin module%400551C70271.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%400551C70271.cp

//## Module: CXOSCF58%400551C70271; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF58.cpp

//## begin module%400551C70271.additionalIncludes preserve=no
//## end module%400551C70271.additionalIncludes

//## begin module%400551C70271.includes preserve=yes
// $Date:   Dec 16 2016 15:26:48  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%400551C70271.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF58_h
#include "CXODCF58.hpp"
#endif
//## begin module%400551C70271.declarations preserve=no
//## end module%400551C70271.declarations

//## begin module%400551C70271.additionalDeclarations preserve=yes
//## end module%400551C70271.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexNetworkID 

ConnexNetworkID::ConnexNetworkID()
  //## begin ConnexNetworkID::ConnexNetworkID%4002FB7401F4_const.hasinit preserve=no
  //## end ConnexNetworkID::ConnexNetworkID%4002FB7401F4_const.hasinit
  //## begin ConnexNetworkID::ConnexNetworkID%4002FB7401F4_const.initialization preserve=yes
  : ConversionItem("## CR70 XLATE NETWORKID")
  //## end ConnexNetworkID::ConnexNetworkID%4002FB7401F4_const.initialization
{
  //## begin configuration::ConnexNetworkID::ConnexNetworkID%4002FB7401F4_const.body preserve=yes
   memcpy(m_sID,"CF58",4);
  //## end configuration::ConnexNetworkID::ConnexNetworkID%4002FB7401F4_const.body
}


ConnexNetworkID::~ConnexNetworkID()
{
  //## begin configuration::ConnexNetworkID::~ConnexNetworkID%4002FB7401F4_dest.body preserve=yes
  //## end configuration::ConnexNetworkID::~ConnexNetworkID%4002FB7401F4_dest.body
}



//## Other Operations (implementation)
void ConnexNetworkID::bind (Query& hQuery)
{
  //## begin configuration::ConnexNetworkID::bind%4002FBCF005D.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_IBM_NET_ID");
   hQuery.bind("X_IBM_NET_ID","NET_ID_4",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_NET_ID","NET_ID",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_IBM_NET_ID","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_NET_ID","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IBM_NET_ID.NET_ID_4 ASC");
  //## end configuration::ConnexNetworkID::bind%4002FBCF005D.body
}

void ConnexNetworkID::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexNetworkID::setPredicate%584715B00133.body preserve=yes
   hQuery.setBasicPredicate("X_IBM_NET_ID", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IBM_NET_ID", "CC_STATE", "=", "A");
  //## end configuration::ConnexNetworkID::setPredicate%584715B00133.body
}

// Additional Declarations
  //## begin configuration::ConnexNetworkID%4002FB7401F4.declarations preserve=yes
  //## end configuration::ConnexNetworkID%4002FB7401F4.declarations

} // namespace configuration

//## begin module%400551C70271.epilog preserve=yes
//## end module%400551C70271.epilog
