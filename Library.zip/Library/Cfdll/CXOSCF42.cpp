//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3ACB7E10016E.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3ACB7E10016E.cm

//## begin module%3ACB7E10016E.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3ACB7E10016E.cp

//## Module: CXOSCF42%3ACB7E10016E; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF42.cpp

//## begin module%3ACB7E10016E.additionalIncludes preserve=no
//## end module%3ACB7E10016E.additionalIncludes

//## begin module%3ACB7E10016E.includes preserve=yes
// $Date:   Apr 08 2004 14:11:20  $ $Author:   D02405  $ $Revision:   1.5  $
//## end module%3ACB7E10016E.includes

#ifndef CXOSCF42_h
#include "CXODCF42.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%3ACB7E10016E.declarations preserve=no
//## end module%3ACB7E10016E.declarations

//## begin module%3ACB7E10016E.additionalDeclarations preserve=yes
//## end module%3ACB7E10016E.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ReconInstitution 

ReconInstitution::ReconInstitution()
  //## begin ReconInstitution::ReconInstitution%3ACB79B603C5_const.hasinit preserve=no
  //## end ReconInstitution::ReconInstitution%3ACB79B603C5_const.hasinit
  //## begin ReconInstitution::ReconInstitution%3ACB79B603C5_const.initialization preserve=yes
   : MappingItem("## CR42 MAP RECON INSTITUTION")
  //## end ReconInstitution::ReconInstitution%3ACB79B603C5_const.initialization
{
  //## begin configuration::ReconInstitution::ReconInstitution%3ACB79B603C5_const.body preserve=yes
   memcpy(m_sID,"CF42",4);
  //## end configuration::ReconInstitution::ReconInstitution%3ACB79B603C5_const.body
}


ReconInstitution::~ReconInstitution()
{
  //## begin configuration::ReconInstitution::~ReconInstitution%3ACB79B603C5_dest.body preserve=yes
  //## end configuration::ReconInstitution::~ReconInstitution%3ACB79B603C5_dest.body
}



//## Other Operations (implementation)
void ReconInstitution::bind (Query& hQuery)
{
  //## begin configuration::ReconInstitution::bind%3ACB7BE10340.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID); 
   hQuery.setQualifier("QUALIFY","X_INST_ID_RECON");
   hQuery.bind("X_INST_ID_RECON","INST_ID_RECON",Column::STRING,&m_strPrimary);
   hQuery.bind("X_INST_ID_RECON","ACQ_ISS_IND",Column::STRING,&m_strSecondary);
   hQuery.bind("X_INST_ID_RECON","OWNING_INST_ID",Column::STRING,&m_strTertiary);
   hQuery.bind("X_INST_ID_RECON","CONVERTED_INST_ID",Column::STRING,&m_strResult);
   hQuery.bind("X_INST_ID_RECON","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_INST_ID_RECON","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_INST_ID_RECON","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_INST_ID_RECON","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_INST_ID_RECON.CUST_ID DESC");
  //## end configuration::ReconInstitution::bind%3ACB7BE10340.body
}

// Additional Declarations
  //## begin configuration::ReconInstitution%3ACB79B603C5.declarations preserve=yes
  //## end configuration::ReconInstitution%3ACB79B603C5.declarations

} // namespace configuration

//## begin module%3ACB7E10016E.epilog preserve=yes
//## end module%3ACB7E10016E.epilog
