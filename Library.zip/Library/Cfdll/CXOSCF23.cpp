//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%391C0E3B0066.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%391C0E3B0066.cm

//## begin module%391C0E3B0066.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%391C0E3B0066.cp

//## Module: CXOSCF23%391C0E3B0066; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF23.cpp

//## begin module%391C0E3B0066.additionalIncludes preserve=no
//## end module%391C0E3B0066.additionalIncludes

//## begin module%391C0E3B0066.includes preserve=yes
// $Date:   Apr 17 2014 20:59:26  $ $Author:   e1009652  $ $Revision:   1.6  $
//## end module%391C0E3B0066.includes

#ifndef CXOSCF23_h
#include "CXODCF23.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%391C0E3B0066.declarations preserve=no
//## end module%391C0E3B0066.declarations

//## begin module%391C0E3B0066.additionalDeclarations preserve=yes
//## end module%391C0E3B0066.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexAdviceReason

ConnexAdviceReason::ConnexAdviceReason()
  //## begin ConnexAdviceReason::ConnexAdviceReason%391C0CFC036A_const.hasinit preserve=no
  //## end ConnexAdviceReason::ConnexAdviceReason%391C0CFC036A_const.hasinit
  //## begin ConnexAdviceReason::ConnexAdviceReason%391C0CFC036A_const.initialization preserve=yes
   : ConversionItem("## CR26 XLATE CONNEX ADVICE")
  //## end ConnexAdviceReason::ConnexAdviceReason%391C0CFC036A_const.initialization
{
  //## begin configuration::ConnexAdviceReason::ConnexAdviceReason%391C0CFC036A_const.body preserve=yes
   memcpy(m_sID,"CF23",4);
  //## end configuration::ConnexAdviceReason::ConnexAdviceReason%391C0CFC036A_const.body
}


ConnexAdviceReason::~ConnexAdviceReason()
{
  //## begin configuration::ConnexAdviceReason::~ConnexAdviceReason%391C0CFC036A_dest.body preserve=yes
  //## end configuration::ConnexAdviceReason::~ConnexAdviceReason%391C0CFC036A_dest.body
}



//## Other Operations (implementation)
void ConnexAdviceReason::bind (Query& hQuery)
{
  //## begin configuration::ConnexAdviceReason::bind%391C1C1C0354.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_IBM_ADVIC_REASON");
   hQuery.bind("X_IBM_ADVIC_REASON","IBM_ADVICE_REASON",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_ADVIC_REASON","MSG_REASON_CODE",Column::STRING,&m_strSecond);
   hQuery.bind("X_IBM_ADVIC_REASON","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_IBM_ADVIC_REASON","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_ADVIC_REASON","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_IBM_ADVIC_REASON","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_IBM_ADVIC_REASON.IBM_ADVICE_REASON ASC,X_IBM_ADVIC_REASON.CUST_ID DESC");
  //## end configuration::ConnexAdviceReason::bind%391C1C1C0354.body
}

// Additional Declarations
  //## begin configuration::ConnexAdviceReason%391C0CFC036A.declarations preserve=yes
  //## end configuration::ConnexAdviceReason%391C0CFC036A.declarations

} // namespace configuration

//## begin module%391C0E3B0066.epilog preserve=yes
//## end module%391C0E3B0066.epilog
