//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%391C0E20005D.cm preserve=no
//	$Date:   Aug 05 2021 08:04:30  $ $Author:   e3028298  $
//	$Revision:   1.10  $
//## end module%391C0E20005D.cm

//## begin module%391C0E20005D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%391C0E20005D.cp

//## Module: CXOSCF18%391C0E20005D; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF18.cpp

//## begin module%391C0E20005D.additionalIncludes preserve=no
//## end module%391C0E20005D.additionalIncludes

//## begin module%391C0E20005D.includes preserve=yes
// $Date:   Aug 05 2021 08:04:30  $ $Author:   e3028298  $ $Revision:   1.10  $
//## end module%391C0E20005D.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF18_h
#include "CXODCF18.hpp"
#endif


//## begin module%391C0E20005D.declarations preserve=no
//## end module%391C0E20005D.declarations

//## begin module%391C0E20005D.additionalDeclarations preserve=yes
//## end module%391C0E20005D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::Processor 

Processor::Processor()
  //## begin Processor::Processor%391C0CB60053_const.hasinit preserve=no
  //## end Processor::Processor%391C0CB60053_const.hasinit
  //## begin Processor::Processor%391C0CB60053_const.initialization preserve=yes
   : ConversionItem("## CR21 CHAIN PROC TO PROC GROUP")
  //## end Processor::Processor%391C0CB60053_const.initialization
{
  //## begin configuration::Processor::Processor%391C0CB60053_const.body preserve=yes
   memcpy(m_sID,"CF18",4);
  //## end configuration::Processor::Processor%391C0CB60053_const.body
}


Processor::~Processor()
{
  //## begin configuration::Processor::~Processor%391C0CB60053_dest.body preserve=yes
  //## end configuration::Processor::~Processor%391C0CB60053_dest.body
}



//## Other Operations (implementation)
void Processor::bind (Query& hQuery)
{
  //## begin configuration::Processor::bind%391C1C01016B.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","PROCESSOR");
   hQuery.bind("PROCESSOR","PROC_ID",Column::STRING,&m_strFirst);
   hQuery.bind("PROCESSOR","PROC_GRP_ID",Column::STRING,&m_strSecond);
   hQuery.bind("PROCESSOR","FUNDS_INTRCHG_OPT",Column::STRING,&m_strThird);
   hQuery.bind("PROCESSOR","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("PROCESSOR","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("PROCESSOR","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("PROCESSOR","CUST_ID","IN",strTemp.c_str());
   hQuery.setBasicPredicate("PROCESSOR","PROC_GRP_ID","IS NOT NULL");
   hQuery.setOrderByClause("PROCESSOR.PROC_ID ASC,PROCESSOR.CUST_ID DESC");
  //## end configuration::Processor::bind%391C1C01016B.body
}

void Processor::setPredicate (Query& hQuery)
{
  //## begin configuration::Processor::setPredicate%58471860010B.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setBasicPredicate("PROCESSOR", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("PROCESSOR", "CC_STATE", "=", "A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("PROCESSOR", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setBasicPredicate("PROCESSOR", "PROC_GRP_ID", "IS NOT NULL");
  //## end configuration::Processor::setPredicate%58471860010B.body
}

// Additional Declarations
  //## begin configuration::Processor%391C0CB60053.declarations preserve=yes
  //## end configuration::Processor%391C0CB60053.declarations

} // namespace configuration

//## begin module%391C0E20005D.epilog preserve=yes
//## end module%391C0E20005D.epilog
