//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%40B9CC5C00DA.cm preserve=no
//	$Date:   Dec 12 2016 13:13:56  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%40B9CC5C00DA.cm

//## begin module%40B9CC5C00DA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%40B9CC5C00DA.cp

//## Module: CXOSCF66%40B9CC5C00DA; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF66.hpp

#ifndef CXOSCF66_h
#define CXOSCF66_h 1

//## begin module%40B9CC5C00DA.additionalIncludes preserve=no
//## end module%40B9CC5C00DA.additionalIncludes

//## begin module%40B9CC5C00DA.includes preserve=yes
// $Date:   Dec 12 2016 13:13:56  $ $Author:   e1009652  $ $Revision:   1.1  $
//## end module%40B9CC5C00DA.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%40B9CC5C00DA.declarations preserve=no
//## end module%40B9CC5C00DA.declarations

//## begin module%40B9CC5C00DA.additionalDeclarations preserve=yes
//## end module%40B9CC5C00DA.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexATMStatus%40B9CBD6008C.preface preserve=yes
//## end configuration::ConnexATMStatus%40B9CBD6008C.preface

//## Class: ConnexATMStatus%40B9CBD6008C
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40B9CC3403D8;reusable::Query { -> F}
//## Uses: <unnamed>%40B9D56303C8;IF::Extract { -> F}

class DllExport ConnexATMStatus : public ConversionItem  //## Inherits: <unnamed>%40B9CBF10222
{
  //## begin configuration::ConnexATMStatus%40B9CBD6008C.initialDeclarations preserve=yes
  //## end configuration::ConnexATMStatus%40B9CBD6008C.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexATMStatus();

    //## Destructor (generated)
      virtual ~ConnexATMStatus();


    //## Other Operations (specified)
      //## Operation: bind%40B9CBFF034B
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%40B9CC010186
      virtual const string& getFirst ();

      //## Operation: getSecond%40B9CC030157
      virtual const string& getSecond ();

      //## Operation: setPredicate%58471593031E
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexATMStatus%40B9CBD6008C.public preserve=yes
      //## end configuration::ConnexATMStatus%40B9CBD6008C.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexATMStatus%40B9CBD6008C.protected preserve=yes
      //## end configuration::ConnexATMStatus%40B9CBD6008C.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexATMStatus%40B9CBD6008C.private preserve=yes
      //## end configuration::ConnexATMStatus%40B9CBD6008C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ALERT_NO%40B9D20A01C5
      //## begin configuration::ConnexATMStatus::ALERT_NO%40B9D20A01C5.attr preserve=no  private: string {V} 
      string m_strALERT_NO;
      //## end configuration::ConnexATMStatus::ALERT_NO%40B9D20A01C5.attr

      //## Attribute: CUST_ID%40B9D5BA02FD
      //## begin configuration::ConnexATMStatus::CUST_ID%40B9D5BA02FD.attr preserve=no  private: string {V} 
      string m_strCUST_ID;
      //## end configuration::ConnexATMStatus::CUST_ID%40B9D5BA02FD.attr

      //## Attribute: DEVICE_IDENTIFIER%40B9D20900CB
      //## begin configuration::ConnexATMStatus::DEVICE_IDENTIFIER%40B9D20900CB.attr preserve=no  private: string {V} 
      string m_strDEVICE_IDENTIFIER;
      //## end configuration::ConnexATMStatus::DEVICE_IDENTIFIER%40B9D20900CB.attr

      //## Attribute: DEVICE_STATUS%40B9D20B0138
      //## begin configuration::ConnexATMStatus::DEVICE_STATUS%40B9D20B0138.attr preserve=no  private: string {V} 
      string m_strDEVICE_STATUS;
      //## end configuration::ConnexATMStatus::DEVICE_STATUS%40B9D20B0138.attr

      //## Attribute: M_STATUS%40B9D20A00FA
      //## begin configuration::ConnexATMStatus::M_STATUS%40B9D20A00FA.attr preserve=no  private: string {V} 
      string m_strM_STATUS;
      //## end configuration::ConnexATMStatus::M_STATUS%40B9D20A00FA.attr

      //## Attribute: MSG_NO%40B9D20A033C
      //## begin configuration::ConnexATMStatus::MSG_NO%40B9D20A033C.attr preserve=no  private: string {V} 
      string m_strMSG_NO;
      //## end configuration::ConnexATMStatus::MSG_NO%40B9D20A033C.attr

      //## Attribute: SEVERITY%40B9D20B004E
      //## begin configuration::ConnexATMStatus::SEVERITY%40B9D20B004E.attr preserve=no  private: string {V} 
      string m_strSEVERITY;
      //## end configuration::ConnexATMStatus::SEVERITY%40B9D20B004E.attr

      //## Attribute: SOLICITED_STATUS%40B9D1CC005D
      //## begin configuration::ConnexATMStatus::SOLICITED_STATUS%40B9D1CC005D.attr preserve=no  private: string {V} 
      string m_strSOLICITED_STATUS;
      //## end configuration::ConnexATMStatus::SOLICITED_STATUS%40B9D1CC005D.attr

      //## Attribute: STATUS_DESCRIPTOR%40B9D1EF0119
      //## begin configuration::ConnexATMStatus::STATUS_DESCRIPTOR%40B9D1EF0119.attr preserve=no  private: string {V} 
      string m_strSTATUS_DESCRIPTOR;
      //## end configuration::ConnexATMStatus::STATUS_DESCRIPTOR%40B9D1EF0119.attr

      //## Attribute: STATUS_QUALIFIER%40B9D2090290
      //## begin configuration::ConnexATMStatus::STATUS_QUALIFIER%40B9D2090290.attr preserve=no  private: string {V} 
      string m_strSTATUS_QUALIFIER;
      //## end configuration::ConnexATMStatus::STATUS_QUALIFIER%40B9D2090290.attr

      //## Attribute: STATUS_TEXT%40B9D20B0222
      //## begin configuration::ConnexATMStatus::STATUS_TEXT%40B9D20B0222.attr preserve=no  private: string {V} 
      string m_strSTATUS_TEXT;
      //## end configuration::ConnexATMStatus::STATUS_TEXT%40B9D20B0222.attr

      //## Attribute: T_CODE%40B9D20901C5
      //## begin configuration::ConnexATMStatus::T_CODE%40B9D20901C5.attr preserve=no  private: string {V} 
      string m_strT_CODE;
      //## end configuration::ConnexATMStatus::T_CODE%40B9D20901C5.attr

    // Additional Implementation Declarations
      //## begin configuration::ConnexATMStatus%40B9CBD6008C.implementation preserve=yes
      //## end configuration::ConnexATMStatus%40B9CBD6008C.implementation

};

//## begin configuration::ConnexATMStatus%40B9CBD6008C.postscript preserve=yes
//## end configuration::ConnexATMStatus%40B9CBD6008C.postscript

} // namespace configuration

//## begin module%40B9CC5C00DA.epilog preserve=yes
using namespace configuration;
//## end module%40B9CC5C00DA.epilog


#endif
