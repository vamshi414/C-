//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%577405B00341.cm preserve=no
//	$Date:   Apr 04 2017 14:01:12  $ $Author:   e1009591  $
//	$Revision:   1.3  $
//## end module%577405B00341.cm

//## begin module%577405B00341.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%577405B00341.cp

//## Module: CXOSCFA5%577405B00341; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.5B.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFA5.cpp

//## begin module%577405B00341.additionalIncludes preserve=no
//## end module%577405B00341.additionalIncludes

//## begin module%577405B00341.includes preserve=yes
//## end module%577405B00341.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFA5_h
#include "CXODCFA5.hpp"
#endif


//## begin module%577405B00341.declarations preserve=no
//## end module%577405B00341.declarations

//## begin module%577405B00341.additionalDeclarations preserve=yes
//## end module%577405B00341.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ActionType 

ActionType::ActionType()
  //## begin ActionType::ActionType%57740458039E_const.hasinit preserve=no
  //## end ActionType::ActionType%57740458039E_const.hasinit
  //## begin ActionType::ActionType%57740458039E_const.initialization preserve=yes
  : ConversionItem("## CRA5 XLATE ACTION TYPE")
  //## end ActionType::ActionType%57740458039E_const.initialization
{
  //## begin configuration::ActionType::ActionType%57740458039E_const.body preserve=yes
  //## end configuration::ActionType::ActionType%57740458039E_const.body
}


ActionType::~ActionType()
{
  //## begin configuration::ActionType::~ActionType%57740458039E_dest.body preserve=yes
  //## end configuration::ActionType::~ActionType%57740458039E_dest.body
}



//## Other Operations (implementation)
void ActionType::bind (Query& hQuery)
{
  //## begin configuration::ActionType::bind%577404DF0073.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY", "X_ACTION_TYPE");
   hQuery.bind("X_ACTION_TYPE", "ACTION_TYPE", Column::STRING, &m_strACTION_TYPE);
   hQuery.bind("X_ACTION_TYPE", "NETWORK_ID", Column::STRING, &m_strNETWORK_ID);
   hQuery.bind("X_ACTION_TYPE", "REQUEST_TYPE", Column::STRING, &m_strREQUEST_TYPE);
   hQuery.bind("X_ACTION_TYPE", "STATUS", Column::STRING, &m_strSTATUS);
   hQuery.bind("X_ACTION_TYPE", "ROLE", Column::STRING, &m_strROLE);
   hQuery.bind("X_ACTION_TYPE", "XML_CLASS", Column::STRING, &m_strThird);
   hQuery.bind("X_ACTION_TYPE", "CUST_ID", Column::STRING, &m_strCUST_ID);
   hQuery.setBasicPredicate("X_ACTION_TYPE", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_ACTION_TYPE", "CC_STATE", "=", "A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_ACTION_TYPE", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("X_ACTION_TYPE.ACTION_TYPE ASC,X_ACTION_TYPE.NETWORK_ID ASC,X_ACTION_TYPE.CUST_ID DESC");
  //## end configuration::ActionType::bind%577404DF0073.body
}

const string& ActionType::getFirst ()
{
  //## begin configuration::ActionType::getFirst%5774055801D0.body preserve=yes
   m_strFirst = m_strACTION_TYPE;
   m_strFirst.resize(10, ' ');
   m_strFirst.append(m_strNETWORK_ID);
   m_strFirst.resize(13, ' ');
   return m_strFirst;
   //## end configuration::ActionType::getFirst%5774055801D0.body
}

const string& ActionType::getSecond ()
{
  //## begin configuration::ActionType::getSecond%5774050F00E0.body preserve=yes
   m_strSecond = m_strREQUEST_TYPE;
   m_strSecond.resize(4, ' ');
   m_strSecond.append(m_strROLE);
   m_strSecond.resize(5, ' ');
   m_strSecond.append(m_strSTATUS);
   m_strSecond.resize(9,' ');
   return m_strSecond;
   //## end configuration::ActionType::getSecond%5774050F00E0.body
}

// Additional Declarations
  //## begin configuration::ActionType%57740458039E.declarations preserve=yes
  //## end configuration::ActionType%57740458039E.declarations

} // namespace configuration

//## begin module%577405B00341.epilog preserve=yes
//## end module%577405B00341.epilog
