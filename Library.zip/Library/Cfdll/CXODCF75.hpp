//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4263DF5F0290.cm preserve=no
//	$Date:   Feb 02 2006 09:36:14  $ $Author:   D92186  $
//	$Revision:   1.2  $
//## end module%4263DF5F0290.cm

//## begin module%4263DF5F0290.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%4263DF5F0290.cp

//## Module: CXOSCF75%4263DF5F0290; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF75.hpp

#ifndef CXOSCF75_h
#define CXOSCF75_h 1

//## begin module%4263DF5F0290.additionalIncludes preserve=no
//## end module%4263DF5F0290.additionalIncludes

//## begin module%4263DF5F0290.includes preserve=yes
//## end module%4263DF5F0290.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%4263DF5F0290.declarations preserve=no
//## end module%4263DF5F0290.declarations

//## begin module%4263DF5F0290.additionalDeclarations preserve=yes
//## end module%4263DF5F0290.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::OasisRespCode%4263DEE200FA.preface preserve=yes
//## end configuration::OasisRespCode%4263DEE200FA.preface

//## Class: OasisRespCode%4263DEE200FA
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4263DEF90232;reusable::Query { -> F}
//## Uses: <unnamed>%4263DEFC01A5;IF::Extract { -> F}

class DllExport OasisRespCode : public ConversionItem  //## Inherits: <unnamed>%4263DEF7007D
{
  //## begin configuration::OasisRespCode%4263DEE200FA.initialDeclarations preserve=yes
  //## end configuration::OasisRespCode%4263DEE200FA.initialDeclarations

  public:
    //## Constructors (generated)
      OasisRespCode();

    //## Destructor (generated)
      virtual ~OasisRespCode();


    //## Other Operations (specified)
      //## Operation: bind%4263E1F700CB
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>OI
      //	<h2>MS
      //	<!-- OasisRespCode::bind Preconditions -->
      //	<h3>IST Response Code
      //	<p>
      //	The IST Response Code table is used to determine a value
      //	for the action code (FIN_RECORD<i>yyyymm</i>.ACT_CODE)
      //	in the financial transaction.
      //	Valid values for action code (bit 39) can be found in
      //	the ISO 8583 specification.
      //	<p>
      //	Use the CR Client to add or update rows whenever the e
      //	Funds IST acquiring platform introduces a new value in:
      //	<ul>
      //	<li>respcode
      //	</ul>
      //	IST Response Code is in the Parameter Tables folder in
      //	the CR Client for the DataNavigator Server.
      //	</body>
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getFirst%43D7DEA7019A
      virtual const string& getFirst ();

    // Additional Public Declarations
      //## begin configuration::OasisRespCode%4263DEE200FA.public preserve=yes
      //## end configuration::OasisRespCode%4263DEE200FA.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::OasisRespCode%4263DEE200FA.protected preserve=yes
      //## end configuration::OasisRespCode%4263DEE200FA.protected

  private:
    // Additional Private Declarations
      //## begin configuration::OasisRespCode%4263DEE200FA.private preserve=yes
      //## end configuration::OasisRespCode%4263DEE200FA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: TRAN_DISPOSITION%43D7DED90124
      //## begin configuration::OasisRespCode::TRAN_DISPOSITION%43D7DED90124.attr preserve=no  private: string {U} 
      string m_strTRAN_DISPOSITION;
      //## end configuration::OasisRespCode::TRAN_DISPOSITION%43D7DED90124.attr

      //## Attribute: Key%43D7E064010E
      //## begin configuration::OasisRespCode::Key%43D7E064010E.attr preserve=no  private: string {U} 
      string m_strKey;
      //## end configuration::OasisRespCode::Key%43D7E064010E.attr

    // Additional Implementation Declarations
      //## begin configuration::OasisRespCode%4263DEE200FA.implementation preserve=yes
      //## end configuration::OasisRespCode%4263DEE200FA.implementation

};

//## begin configuration::OasisRespCode%4263DEE200FA.postscript preserve=yes
//## end configuration::OasisRespCode%4263DEE200FA.postscript

} // namespace configuration

//## begin module%4263DF5F0290.epilog preserve=yes
//## end module%4263DF5F0290.epilog


#endif
