//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%42528C0E03A9.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%42528C0E03A9.cm

//## begin module%42528C0E03A9.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%42528C0E03A9.cp

//## Module: CXOSCF71%42528C0E03A9; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF71.cpp

//## begin module%42528C0E03A9.additionalIncludes preserve=no
//## end module%42528C0E03A9.additionalIncludes

//## begin module%42528C0E03A9.includes preserve=yes
// $Date:   Apr 17 2014 21:06:06  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%42528C0E03A9.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF71_h
#include "CXODCF71.hpp"
#endif


//## begin module%42528C0E03A9.declarations preserve=no
//## end module%42528C0E03A9.declarations

//## begin module%42528C0E03A9.additionalDeclarations preserve=yes
//## end module%42528C0E03A9.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::DNTransactionType 

DNTransactionType::DNTransactionType()
  //## begin DNTransactionType::DNTransactionType%42528B1F02CE_const.hasinit preserve=no
  //## end DNTransactionType::DNTransactionType%42528B1F02CE_const.hasinit
  //## begin DNTransactionType::DNTransactionType%42528B1F02CE_const.initialization preserve=yes
   : ConversionItem("## CR78 XLATE TRAN TYPE")
  //## end DNTransactionType::DNTransactionType%42528B1F02CE_const.initialization
{
  //## begin configuration::DNTransactionType::DNTransactionType%42528B1F02CE_const.body preserve=yes
   memcpy(m_sID,"CF71",4);
  //## end configuration::DNTransactionType::DNTransactionType%42528B1F02CE_const.body
}


DNTransactionType::~DNTransactionType()
{
  //## begin configuration::DNTransactionType::~DNTransactionType%42528B1F02CE_dest.body preserve=yes
  //## end configuration::DNTransactionType::~DNTransactionType%42528B1F02CE_dest.body
}



//## Other Operations (implementation)
void DNTransactionType::bind (reusable::Query& hQuery)
{
  //## begin configuration::DNTransactionType::bind%42528B7C0148.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_ADV_PROC_CODE");
   hQuery.bind("X_ADV_PROC_CODE","ADVG_PROCESS_CODE",Column::STRING,&m_strADVG_PROCESS_CODE);
   hQuery.bind("X_ADV_PROC_CODE","ADVG_MSG_CLASS",Column::STRING,&m_strADVG_MSG_CLASS);
   hQuery.bind("X_ADV_PROC_CODE","ADVG_ACCT_QUAL_1",Column::STRING,&m_strADVG_ACCT_QUAL_1);
   hQuery.bind("X_ADV_PROC_CODE","ADVG_PRE_AUTH",Column::STRING,&m_strADVG_PRE_AUTH);
   hQuery.bind("X_ADV_PROC_CODE","ADVG_TRAN_DESC",Column::STRING,&m_strADVG_TRAN_DESC);
   hQuery.bind("X_ADV_PROC_CODE","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("X_ADV_PROC_CODE","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("X_ADV_PROC_CODE","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("X_ADV_PROC_CODE","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("X_ADV_PROC_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_ADV_PROC_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_ADV_PROC_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_ADV_PROC_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_ADV_PROC_CODE.PROCESS_CODE ASC,"
                           "X_ADV_PROC_CODE.MSG_CLASS ASC,"
                           "X_ADV_PROC_CODE.PRE_AUTH ASC,"
                           "X_ADV_PROC_CODE.MEDIA_TYPE ASC,"
                           "X_ADV_PROC_CODE.CUST_ID DESC");
  //## end configuration::DNTransactionType::bind%42528B7C0148.body
}

const string& DNTransactionType::getFirst ()
{
  //## begin configuration::DNTransactionType::getFirst%42528B7D035B.body preserve=yes
   while (m_strPROCESS_CODE.length() < 6)
      m_strPROCESS_CODE += ' ';
   while (m_strMSG_CLASS.length() < 1)
      m_strMSG_CLASS += ' ';
   while (m_strPRE_AUTH.length() < 1)
      m_strPRE_AUTH += ' ';
   m_strFirst = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strFirst;
  //## end configuration::DNTransactionType::getFirst%42528B7D035B.body
}

const string& DNTransactionType::getSecond ()
{
  //## begin configuration::DNTransactionType::getSecond%42528B7F004E.body preserve=yes
   while (m_strADVG_PROCESS_CODE.length() < 6)
      m_strADVG_PROCESS_CODE += ' ';
   while (m_strADVG_MSG_CLASS.length() < 1)
      m_strADVG_MSG_CLASS += ' ';
   while (m_strADVG_ACCT_QUAL_1.length() < 3)
      m_strADVG_ACCT_QUAL_1 += ' ';
   while (m_strADVG_PRE_AUTH.length() < 1)
      m_strADVG_PRE_AUTH += ' ';
   m_strSecond = m_strADVG_PROCESS_CODE + m_strADVG_MSG_CLASS +
      m_strADVG_ACCT_QUAL_1 + m_strADVG_PRE_AUTH + m_strADVG_TRAN_DESC;
   return m_strSecond;
  //## end configuration::DNTransactionType::getSecond%42528B7F004E.body
}

// Additional Declarations
  //## begin configuration::DNTransactionType%42528B1F02CE.declarations preserve=yes
  //## end configuration::DNTransactionType%42528B1F02CE.declarations

} // namespace configuration

//## begin module%42528C0E03A9.epilog preserve=yes
//## end module%42528C0E03A9.epilog
