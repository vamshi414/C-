//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3958D46202E5.cm preserve=no
//	$Date:   Jul 20 2018 07:46:14  $ $Author:   e5561468  $
//	$Revision:   1.7  $
//## end module%3958D46202E5.cm

//## begin module%3958D46202E5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3958D46202E5.cp

//## Module: CXOSCF32%3958D46202E5; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\latest\V02.9B.R001\DN\Server\Library\Cfdll\CXOSCF32.cpp

//## begin module%3958D46202E5.additionalIncludes preserve=no
//## end module%3958D46202E5.additionalIncludes

//## begin module%3958D46202E5.includes preserve=yes
// $Date:   Jul 20 2018 07:46:14  $ $Author:   e5561468  $ $Revision:   1.7  $
//## end module%3958D46202E5.includes

#ifndef CXOSCF32_h
#include "CXODCF32.hpp"
#endif
#ifndef CXOSMN02_h
#include "CXODMN02.hpp"
#endif


//## begin module%3958D46202E5.declarations preserve=no
//## end module%3958D46202E5.declarations

//## begin module%3958D46202E5.additionalDeclarations preserve=yes
//## end module%3958D46202E5.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConfigurationTable 

ConfigurationTable::ConfigurationTable()
  //## begin ConfigurationTable::ConfigurationTable%3958B59602FC_const.hasinit preserve=no
      : m_bReset(false),
        m_lVersion(-1)
  //## end ConfigurationTable::ConfigurationTable%3958B59602FC_const.hasinit
  //## begin ConfigurationTable::ConfigurationTable%3958B59602FC_const.initialization preserve=yes
  //## end ConfigurationTable::ConfigurationTable%3958B59602FC_const.initialization
{
  //## begin configuration::ConfigurationTable::ConfigurationTable%3958B59602FC_const.body preserve=yes
   m_pCount[0] = 0;
   m_pCount[1] = 0;
  //## end configuration::ConfigurationTable::ConfigurationTable%3958B59602FC_const.body
}

ConfigurationTable::ConfigurationTable (const char* pszName)
  //## begin configuration::ConfigurationTable::ConfigurationTable%3958D29F0098.hasinit preserve=no
      : m_bReset(false),
        m_lVersion(-1)
  //## end configuration::ConfigurationTable::ConfigurationTable%3958D29F0098.hasinit
  //## begin configuration::ConfigurationTable::ConfigurationTable%3958D29F0098.initialization preserve=yes
   ,SharedResource(string(string("##") + pszName).c_str())
  //## end configuration::ConfigurationTable::ConfigurationTable%3958D29F0098.initialization
{
  //## begin configuration::ConfigurationTable::ConfigurationTable%3958D29F0098.body preserve=yes
   m_pCount[0] = 0;
   m_pCount[1] = 0;
  //## end configuration::ConfigurationTable::ConfigurationTable%3958D29F0098.body
}


ConfigurationTable::~ConfigurationTable()
{
  //## begin configuration::ConfigurationTable::~ConfigurationTable%3958B59602FC_dest.body preserve=yes
   delete m_pCount[0];
   delete m_pCount[1];
  //## end configuration::ConfigurationTable::~ConfigurationTable%3958B59602FC_dest.body
}



//## Other Operations (implementation)
string ConfigurationTable::getTableName ()
{
  //## begin configuration::ConfigurationTable::getTableName%3958D37800EA.body preserve=yes
   return string((const char*)name().c_str() + 3);
  //## end configuration::ConfigurationTable::getTableName%3958D37800EA.body
}

void ConfigurationTable::setMember (const string& strMember)
{
  //## begin configuration::ConfigurationTable::setMember%3958D25D033C.body preserve=yes
   if (m_pCount[0] == 0)
   {
      m_pCount[0] = new Count("CR",strMember.c_str(),"TOTAL");
      m_pCount[1] = new Count("CR",strMember.c_str(),"FAILURE");
   }
  //## end configuration::ConfigurationTable::setMember%3958D25D033C.body
}

// Additional Declarations
  //## begin configuration::ConfigurationTable%3958B59602FC.declarations preserve=yes
  //## end configuration::ConfigurationTable%3958B59602FC.declarations

} // namespace configuration

//## begin module%3958D46202E5.epilog preserve=yes
//## end module%3958D46202E5.epilog
