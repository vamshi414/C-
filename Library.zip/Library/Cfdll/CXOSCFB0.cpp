//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5B9B637A008F.cm preserve=no
//	$Date:   Sep 21 2018 11:07:12  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5B9B637A008F.cm

//## begin module%5B9B637A008F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5B9B637A008F.cp

//## Module: CXOSCFB0%5B9B637A008F; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Devel\Dn\Server\Library\Cfdll\CXOSCFB0.cpp

//## begin module%5B9B637A008F.additionalIncludes preserve=no
//## end module%5B9B637A008F.additionalIncludes

//## begin module%5B9B637A008F.includes preserve=yes
//## end module%5B9B637A008F.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCFB0_h
#include "CXODCFB0.hpp"
#endif


//## begin module%5B9B637A008F.declarations preserve=no
//## end module%5B9B637A008F.declarations

//## begin module%5B9B637A008F.additionalDeclarations preserve=yes
//## end module%5B9B637A008F.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::NetProcessorId 

NetProcessorId::NetProcessorId()
  //## begin NetProcessorId::NetProcessorId%5B9B5F9E0204_const.hasinit preserve=no
  //## end NetProcessorId::NetProcessorId%5B9B5F9E0204_const.hasinit
  //## begin NetProcessorId::NetProcessorId%5B9B5F9E0204_const.initialization preserve=yes
  : VerificationItem("## CR32 VERIFY PROCESSOR ID")
  //## end NetProcessorId::NetProcessorId%5B9B5F9E0204_const.initialization
{
  //## begin configuration::NetProcessorId::NetProcessorId%5B9B5F9E0204_const.body preserve=yes
  memcpy(m_sID, "CFB0", 4);
  //## end configuration::NetProcessorId::NetProcessorId%5B9B5F9E0204_const.body
}


NetProcessorId::~NetProcessorId()
{
  //## begin configuration::NetProcessorId::~NetProcessorId%5B9B5F9E0204_dest.body preserve=yes
  //## end configuration::NetProcessorId::~NetProcessorId%5B9B5F9E0204_dest.body
}



//## Other Operations (implementation)
void NetProcessorId::bind (Query& hQuery)
{
   //## begin configuration::NetProcessorId::bind%5B9B658103BD.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY", "X_XML_PROC_NETID");
   hQuery.bind("X_XML_PROC_NETID", "PROC_ID", Column::STRING, &m_strKey);
   hQuery.bind("X_XML_PROC_NETID", "CUST_ID", Column::STRING, &m_strCUST_ID);
   hQuery.setBasicPredicate("X_XML_PROC_NETID", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_XML_PROC_NETID", "CC_STATE", "=", "A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_XML_PROC_NETID", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("X_XML_PROC_NETID.CUST_ID DESC");
   //## end configuration::NetProcessorId::bind%5B9B658103BD.body
}

// Additional Declarations
  //## begin configuration::NetProcessorId%5B9B5F9E0204.declarations preserve=yes
  //## end configuration::NetProcessorId%5B9B5F9E0204.declarations

} // namespace configuration

//## begin module%5B9B637A008F.epilog preserve=yes
//## end module%5B9B637A008F.epilog
