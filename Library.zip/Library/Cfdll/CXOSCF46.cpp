//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3DF889AE0280.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3DF889AE0280.cm

//## begin module%3DF889AE0280.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3DF889AE0280.cp

//## Module: CXOSCF46%3DF889AE0280; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF46.cpp

//## begin module%3DF889AE0280.additionalIncludes preserve=no
//## end module%3DF889AE0280.additionalIncludes

//## begin module%3DF889AE0280.includes preserve=yes
// $Date:   Mar 22 2017 14:58:42  $ $Author:   e1009610  $ $Revision:   1.3  $
//## end module%3DF889AE0280.includes

#ifndef CXOSCF46_h
#include "CXODCF46.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif


//## begin module%3DF889AE0280.declarations preserve=no
//## end module%3DF889AE0280.declarations

//## begin module%3DF889AE0280.additionalDeclarations preserve=yes
//## end module%3DF889AE0280.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ProcessorGroup 

ProcessorGroup::ProcessorGroup()
  //## begin ProcessorGroup::ProcessorGroup%3DF638C50251_const.hasinit preserve=no
  //## end ProcessorGroup::ProcessorGroup%3DF638C50251_const.hasinit
  //## begin ProcessorGroup::ProcessorGroup%3DF638C50251_const.initialization preserve=yes
   : ConversionItem("## CR45 CHAIN PROC GRP TO CUST")
  //## end ProcessorGroup::ProcessorGroup%3DF638C50251_const.initialization
{
  //## begin configuration::ProcessorGroup::ProcessorGroup%3DF638C50251_const.body preserve=yes
  //## end configuration::ProcessorGroup::ProcessorGroup%3DF638C50251_const.body
}


ProcessorGroup::~ProcessorGroup()
{
  //## begin configuration::ProcessorGroup::~ProcessorGroup%3DF638C50251_dest.body preserve=yes
  //## end configuration::ProcessorGroup::~ProcessorGroup%3DF638C50251_dest.body
}



//## Other Operations (implementation)
void ProcessorGroup::bind (Query& hQuery)
{
  //## begin configuration::ProcessorGroup::bind%3DFDCF5B0177.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","PROCESSOR_GRP");
   hQuery.bind("PROCESSOR_GRP","PROC_GRP_ID",Column::STRING,&m_strFirst);
   hQuery.bind("PROCESSOR_GRP","CUST_ID",Column::STRING,&m_strSecond);
   hQuery.bind("PROCESSOR_GRP","SUBSCRIBER_IND",Column::STRING,&m_strThird);
   hQuery.setBasicPredicate("PROCESSOR_GRP","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("PROCESSOR_GRP","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("PROCESSOR_GRP","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("PROCESSOR_GRP.PROC_GRP_ID ASC,PROCESSOR_GRP.CUST_ID DESC");
  //## end configuration::ProcessorGroup::bind%3DFDCF5B0177.body
}

// Additional Declarations
  //## begin configuration::ProcessorGroup%3DF638C50251.declarations preserve=yes
  //## end configuration::ProcessorGroup%3DF638C50251.declarations

} // namespace configuration

//## begin module%3DF889AE0280.epilog preserve=yes
//## end module%3DF889AE0280.epilog
