//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4313595400AB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%4313595400AB.cm

//## begin module%4313595400AB.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%4313595400AB.cp

//## Module: CXOSCF83%4313595400AB; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF83.hpp

#ifndef CXOSCF83_h
#define CXOSCF83_h 1

//## begin module%4313595400AB.additionalIncludes preserve=no
//## end module%4313595400AB.additionalIncludes

//## begin module%4313595400AB.includes preserve=yes
//## end module%4313595400AB.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%4313595400AB.declarations preserve=no
//## end module%4313595400AB.declarations

//## begin module%4313595400AB.additionalDeclarations preserve=yes
//## end module%4313595400AB.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::StarActionType%431357D803D8.preface preserve=yes
//## end configuration::StarActionType%431357D803D8.preface

//## Class: StarActionType%431357D803D8
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%43135CA10119;IF::Extract { -> F}
//## Uses: <unnamed>%43135CAC007D;reusable::Query { -> F}

class DllExport StarActionType : public ConversionItem  //## Inherits: <unnamed>%43135853037A
{
  //## begin configuration::StarActionType%431357D803D8.initialDeclarations preserve=yes
  //## end configuration::StarActionType%431357D803D8.initialDeclarations

  public:
    //## Constructors (generated)
      StarActionType();

    //## Destructor (generated)
      virtual ~StarActionType();


    //## Other Operations (specified)
      //## Operation: bind%43135D050251
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>MS
      //	<h3>VISA Process Codes
      //	<p>
      //	The VISA Process Codes table is used to determine a
      //	value for the transaction type identifier (FIN_
      //	L<i>yyyymm</i>.TRAN_TYPE_ID) in the financial
      //	transaction.
      //	<p>
      //	Use the CR Client to add or update rows whenever the e
      //	Funds Advantage acquiring platform introduces a new
      //	value in:
      //	<ul>
      //	<li>PROC^CODE (1)
      //	</ul>
      //	VISA Process Codes are in the Parameter Tables folder in
      //	the CR Client for the DataNavigator Server.
      //	</body>
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getSecond%43135D0A00FA
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::StarActionType%431357D803D8.public preserve=yes
      //## end configuration::StarActionType%431357D803D8.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::StarActionType%431357D803D8.protected preserve=yes
      //## end configuration::StarActionType%431357D803D8.protected

  private:
    // Additional Private Declarations
      //## begin configuration::StarActionType%431357D803D8.private preserve=yes
      //## end configuration::StarActionType%431357D803D8.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: REQUEST_TYPE%43135CC90213
      //## begin configuration::StarActionType::REQUEST_TYPE%43135CC90213.attr preserve=no  private: string {U} 
      string m_strREQUEST_TYPE;
      //## end configuration::StarActionType::REQUEST_TYPE%43135CC90213.attr

      //## Attribute: STATUS%43135CE00157
      //## begin configuration::StarActionType::STATUS%43135CE00157.attr preserve=no  private: string {U} 
      string m_strSTATUS;
      //## end configuration::StarActionType::STATUS%43135CE00157.attr

    // Additional Implementation Declarations
      //## begin configuration::StarActionType%431357D803D8.implementation preserve=yes
      //## end configuration::StarActionType%431357D803D8.implementation

};

//## begin configuration::StarActionType%431357D803D8.postscript preserve=yes
//## end configuration::StarActionType%431357D803D8.postscript

} // namespace configuration

//## begin module%4313595400AB.epilog preserve=yes
using namespace configuration;
//## end module%4313595400AB.epilog


#endif
