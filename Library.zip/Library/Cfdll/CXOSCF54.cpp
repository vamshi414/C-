//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFC71A80290.cm preserve=no
//	$Date:   Dec 16 2016 15:23:14  $ $Author:   e1009652  $
//	$Revision:   1.4  $
//## end module%3FFC71A80290.cm

//## begin module%3FFC71A80290.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFC71A80290.cp

//## Module: CXOSCF54%3FFC71A80290; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF54.cpp

//## begin module%3FFC71A80290.additionalIncludes preserve=no
//## end module%3FFC71A80290.additionalIncludes

//## begin module%3FFC71A80290.includes preserve=yes
// $Date:   Dec 16 2016 15:23:14  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%3FFC71A80290.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF54_h
#include "CXODCF54.hpp"
#endif
//## begin module%3FFC71A80290.declarations preserve=no
//## end module%3FFC71A80290.declarations

//## begin module%3FFC71A80290.additionalDeclarations preserve=yes
//## end module%3FFC71A80290.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexPOSConditionCode5 

ConnexPOSConditionCode5::ConnexPOSConditionCode5()
  //## begin ConnexPOSConditionCode5::ConnexPOSConditionCode5%3FFC70EB00DA_const.hasinit preserve=no
  //## end ConnexPOSConditionCode5::ConnexPOSConditionCode5%3FFC70EB00DA_const.hasinit
  //## begin ConnexPOSConditionCode5::ConnexPOSConditionCode5%3FFC70EB00DA_const.initialization preserve=yes
   : ConversionItem("## CR66 XLATE POS CON COD5")
  //## end ConnexPOSConditionCode5::ConnexPOSConditionCode5%3FFC70EB00DA_const.initialization
{
  //## begin configuration::ConnexPOSConditionCode5::ConnexPOSConditionCode5%3FFC70EB00DA_const.body preserve=yes
   memcpy(m_sID,"CF54",4);
  //## end configuration::ConnexPOSConditionCode5::ConnexPOSConditionCode5%3FFC70EB00DA_const.body
}


ConnexPOSConditionCode5::~ConnexPOSConditionCode5()
{
  //## begin configuration::ConnexPOSConditionCode5::~ConnexPOSConditionCode5%3FFC70EB00DA_dest.body preserve=yes
  //## end configuration::ConnexPOSConditionCode5::~ConnexPOSConditionCode5%3FFC70EB00DA_dest.body
}



//## Other Operations (implementation)
void ConnexPOSConditionCode5::bind (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode5::bind%3FFC710F0148.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_IBM_POS_COND_COD");
   hQuery.bind("X_IBM_POS_COND_COD","POS_COND_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_POS_COND_COD","POS_CRD_DAT_OT_CAP",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IBM_POS_COND_COD.POS_COND_CODE ASC");
  //## end configuration::ConnexPOSConditionCode5::bind%3FFC710F0148.body
}

void ConnexPOSConditionCode5::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode5::setPredicate%5847163D03CE.body preserve=yes
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_STATE", "=", "A");
  //## end configuration::ConnexPOSConditionCode5::setPredicate%5847163D03CE.body
}

// Additional Declarations
  //## begin configuration::ConnexPOSConditionCode5%3FFC70EB00DA.declarations preserve=yes
  //## end configuration::ConnexPOSConditionCode5%3FFC70EB00DA.declarations

} // namespace configuration

//## begin module%3FFC71A80290.epilog preserve=yes
//## end module%3FFC71A80290.epilog
