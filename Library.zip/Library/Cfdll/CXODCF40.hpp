//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3ACA367E03DD.cm preserve=no
//	$Date:   Jan 04 2019 08:51:34  $ $Author:   e1009839  $
//	$Revision:   1.4  $
//## end module%3ACA367E03DD.cm

//## begin module%3ACA367E03DD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3ACA367E03DD.cp

//## Module: CXOSCF40%3ACA367E03DD; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF40.hpp

#ifndef CXOSCF40_h
#define CXOSCF40_h 1

//## begin module%3ACA367E03DD.additionalIncludes preserve=no
//## end module%3ACA367E03DD.additionalIncludes

//## begin module%3ACA367E03DD.includes preserve=yes
// $Date:   Jan 04 2019 08:51:34  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3ACA367E03DD.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationFactory;
class MappingItem;
class MappingTable;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
class Global;
class Thread;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
class Count;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%3ACA367E03DD.declarations preserve=no
//## end module%3ACA367E03DD.declarations

//## begin module%3ACA367E03DD.additionalDeclarations preserve=yes
//## end module%3ACA367E03DD.additionalDeclarations


namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::MappingLoader%3ACA357C0292.preface preserve=yes
//## end configuration::MappingLoader%3ACA357C0292.preface

//## Class: MappingLoader%3ACA357C0292
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3ACA37D60175;ConfigurationFactory { -> F}
//## Uses: <unnamed>%3ACA37F50151;reusable::Global { -> F}
//## Uses: <unnamed>%3ACA37F70212;reusable::Query { -> F}
//## Uses: <unnamed>%3ACA37FA0162;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%3ACA37FD001C;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3ACA37FF02A0;monitor::Count { -> F}
//## Uses: <unnamed>%3ACDCC6903D9;monitor::UseCase { -> F}
//## Uses: <unnamed>%5BF9373300AB;reusable::Thread { -> F}

class DllExport MappingLoader : public reusable::Observer  //## Inherits: <unnamed>%3ACA35F6008E
{
  //## begin configuration::MappingLoader%3ACA357C0292.initialDeclarations preserve=yes
  //## end configuration::MappingLoader%3ACA357C0292.initialDeclarations

  public:
    //## Constructors (generated)
      MappingLoader();

    //## Destructor (generated)
      virtual ~MappingLoader();


    //## Other Operations (specified)
      //## Operation: instance%3ACA3853012E
      static MappingLoader* instance ();

      //## Operation: populate%3ACA38710236
      bool populate (MappingTable* pMappingTable);

      //## Operation: update%3ACA387401A4
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin configuration::MappingLoader%3ACA357C0292.public preserve=yes
      //## end configuration::MappingLoader%3ACA357C0292.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::MappingLoader%3ACA357C0292.protected preserve=yes
      //## end configuration::MappingLoader%3ACA357C0292.protected

  private:
    // Additional Private Declarations
      //## begin configuration::MappingLoader%3ACA357C0292.private preserve=yes
      //## end configuration::MappingLoader%3ACA357C0292.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5C05A55302E2
      //## begin configuration::MappingLoader::Instance%5C05A55302E2.attr preserve=no  private: static vector<MappingLoader*>* {V} 0
      static vector<MappingLoader*>* m_pInstance;
      //## end configuration::MappingLoader::Instance%5C05A55302E2.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Configuration_CAT::<unnamed>%3ACA3614018C
      //## Role: MappingLoader::<m_pMappingTable>%3ACA361403DB
      //## begin configuration::MappingLoader::<m_pMappingTable>%3ACA361403DB.role preserve=no  public: configuration::MappingTable { -> RFHgN}
      MappingTable *m_pMappingTable;
      //## end configuration::MappingLoader::<m_pMappingTable>%3ACA361403DB.role

      //## Association: DataNavigator Foundation::Configuration_CAT::<unnamed>%3ACA3A6E004D
      //## Role: MappingLoader::<m_pMappingItem>%3ACA3A6E031E
      //## begin configuration::MappingLoader::<m_pMappingItem>%3ACA3A6E031E.role preserve=no  public: configuration::MappingItem { -> RFHgN}
      MappingItem *m_pMappingItem;
      //## end configuration::MappingLoader::<m_pMappingItem>%3ACA3A6E031E.role

    // Additional Implementation Declarations
      //## begin configuration::MappingLoader%3ACA357C0292.implementation preserve=yes
      //## end configuration::MappingLoader%3ACA357C0292.implementation

};

//## begin configuration::MappingLoader%3ACA357C0292.postscript preserve=yes
//## end configuration::MappingLoader%3ACA357C0292.postscript

} // namespace configuration

//## begin module%3ACA367E03DD.epilog preserve=yes
using namespace configuration;
//## end module%3ACA367E03DD.epilog


#endif
