//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4AE5D115029A.cm preserve=no
//	$Date:   Dec 16 2016 15:35:28  $ $Author:   e1009652  $
//	$Revision:   1.5  $
//## end module%4AE5D115029A.cm

//## begin module%4AE5D115029A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4AE5D115029A.cp

//## Module: CXOSCF98%4AE5D115029A; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF98.cpp

//## begin module%4AE5D115029A.additionalIncludes preserve=no
//## end module%4AE5D115029A.additionalIncludes

//## begin module%4AE5D115029A.includes preserve=yes
//## end module%4AE5D115029A.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF98_h
#include "CXODCF98.hpp"
#endif


//## begin module%4AE5D115029A.declarations preserve=no
//## end module%4AE5D115029A.declarations

//## begin module%4AE5D115029A.additionalDeclarations preserve=yes
//## end module%4AE5D115029A.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ErrorMessage 

ErrorMessage::ErrorMessage()
  //## begin ErrorMessage::ErrorMessage%4AE5D0E30365_const.hasinit preserve=no
  //## end ErrorMessage::ErrorMessage%4AE5D0E30365_const.hasinit
  //## begin ErrorMessage::ErrorMessage%4AE5D0E30365_const.initialization preserve=yes
  //## end ErrorMessage::ErrorMessage%4AE5D0E30365_const.initialization
{
  //## begin configuration::ErrorMessage::ErrorMessage%4AE5D0E30365_const.body preserve=yes
   memcpy(m_sID,"CF98",4);
  //## end configuration::ErrorMessage::ErrorMessage%4AE5D0E30365_const.body
}


ErrorMessage::~ErrorMessage()
{
  //## begin configuration::ErrorMessage::~ErrorMessage%4AE5D0E30365_dest.body preserve=yes
  //## end configuration::ErrorMessage::~ErrorMessage%4AE5D0E30365_dest.body
}



//## Other Operations (implementation)
void ErrorMessage::bind (Query& hQuery)
{
  //## begin configuration::ErrorMessage::bind%4AE5D30A02C5.body preserve=yes
   hQuery.setQualifier("QUALIFY","MISC_CFG_DATA");
   hQuery.bind("MISC_CFG_DATA","DATA_VALUE",Column::STRING,&m_strFirst);
   hQuery.bind("MISC_CFG_DATA","CFG_DESCRIPTION",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("MISC_CFG_DATA","CFG_DATA_TYPE","=","ERROR_MSGS");
   hQuery.setBasicPredicate("MISC_CFG_DATA","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("MISC_CFG_DATA","CC_STATE","=","A");
   hQuery.setOrderByClause("MISC_CFG_DATA.DATA_VALUE ASC");
  //## end configuration::ErrorMessage::bind%4AE5D30A02C5.body
}

const string& ErrorMessage::getSecond ()
{
  //## begin configuration::ErrorMessage::getSecond%4AE5D30F0219.body preserve=yes
   if(m_strSecond.length() > 100)
   {
      m_strSecond.resize(100);
      size_t nPos = m_strSecond.find_last_of('.'); 
      if (nPos != string::npos)
         m_strSecond.erase(nPos+1);
   }      
   else
      m_strSecond.resize(100,' ');
   
   return m_strSecond;
  //## end configuration::ErrorMessage::getSecond%4AE5D30F0219.body
}

void ErrorMessage::setPredicate (Query& hQuery)
{
  //## begin configuration::ErrorMessage::setPredicate%584F177802CA.body preserve=yes
   hQuery.setBasicPredicate("MISC_CFG_DATA", "CFG_DATA_TYPE", "=", "ERROR_MSGS");
   hQuery.setBasicPredicate("MISC_CFG_DATA", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("MISC_CFG_DATA", "CC_STATE", "=", "A");
  //## end configuration::ErrorMessage::setPredicate%584F177802CA.body
}

// Additional Declarations
  //## begin configuration::ErrorMessage%4AE5D0E30365.declarations preserve=yes
  //## end configuration::ErrorMessage%4AE5D0E30365.declarations

} // namespace configuration

//## begin module%4AE5D115029A.epilog preserve=yes
//## end module%4AE5D115029A.epilog
