//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%393E6BA90314.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%393E6BA90314.cm

//## begin module%393E6BA90314.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%393E6BA90314.cp

//## Module: CXOSCF28%393E6BA90314; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF28.hpp

#ifndef CXOSCF28_h
#define CXOSCF28_h 1

//## begin module%393E6BA90314.additionalIncludes preserve=no
//## end module%393E6BA90314.additionalIncludes

//## begin module%393E6BA90314.includes preserve=yes
// $Date:   Jun 30 2006 12:15:42  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%393E6BA90314.includes

#ifndef CXOSCF26_h
#include "CXODCF26.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%393E6BA90314.declarations preserve=no
//## end module%393E6BA90314.declarations

//## begin module%393E6BA90314.additionalDeclarations preserve=yes
//## end module%393E6BA90314.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::FinancialType%393E6D5002A4.preface preserve=yes
//## end configuration::FinancialType%393E6D5002A4.preface

//## Class: FinancialType%393E6D5002A4
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%393E7547018D;IF::Extract { -> F}
//## Uses: <unnamed>%393E754A000B;reusable::Query { -> F}

class DllExport FinancialType : public VerificationItem  //## Inherits: <unnamed>%393E7545022B
{
  //## begin configuration::FinancialType%393E6D5002A4.initialDeclarations preserve=yes
  //## end configuration::FinancialType%393E6D5002A4.initialDeclarations

  public:
    //## Constructors (generated)
      FinancialType();

    //## Destructor (generated)
      virtual ~FinancialType();


    //## Other Operations (specified)
      //## Operation: bind%393E757A0317
      virtual void bind (Query& hQuery);

      //## Operation: getKey%3943A3C10367
      virtual const string& getKey ();

    // Additional Public Declarations
      //## begin configuration::FinancialType%393E6D5002A4.public preserve=yes
      //## end configuration::FinancialType%393E6D5002A4.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::FinancialType%393E6D5002A4.protected preserve=yes
      //## end configuration::FinancialType%393E6D5002A4.protected

  private:
    // Additional Private Declarations
      //## begin configuration::FinancialType%393E6D5002A4.private preserve=yes
      //## end configuration::FinancialType%393E6D5002A4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: FIN_TRAN_TYPE%3943A41C0141
      //## begin configuration::FinancialType::FIN_TRAN_TYPE%3943A41C0141.attr preserve=no  private: int {U} 
      int m_lFIN_TRAN_TYPE;
      //## end configuration::FinancialType::FIN_TRAN_TYPE%3943A41C0141.attr

    // Additional Implementation Declarations
      //## begin configuration::FinancialType%393E6D5002A4.implementation preserve=yes
      //## end configuration::FinancialType%393E6D5002A4.implementation

};

//## begin configuration::FinancialType%393E6D5002A4.postscript preserve=yes
//## end configuration::FinancialType%393E6D5002A4.postscript

} // namespace configuration

//## begin module%393E6BA90314.epilog preserve=yes
using namespace configuration;
//## end module%393E6BA90314.epilog


#endif
