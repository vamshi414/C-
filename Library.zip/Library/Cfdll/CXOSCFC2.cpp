//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%61A79740039F.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%61A79740039F.cm

//## begin module%61A79740039F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%61A79740039F.cp

//## Module: CXOSCFC2%61A79740039F; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFC2.cpp

//## begin module%61A79740039F.additionalIncludes preserve=no
//## end module%61A79740039F.additionalIncludes

//## begin module%61A79740039F.includes preserve=yes
//## end module%61A79740039F.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCFC2_h
#include "CXODCFC2.hpp"
#endif


//## begin module%61A79740039F.declarations preserve=no
//## end module%61A79740039F.declarations

//## begin module%61A79740039F.additionalDeclarations preserve=yes
//## end module%61A79740039F.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::NetworkStatusReverse 

NetworkStatusReverse::NetworkStatusReverse()
  //## begin NetworkStatusReverse::NetworkStatusReverse%61A79831031F_const.hasinit preserve=no
  //## end NetworkStatusReverse::NetworkStatusReverse%61A79831031F_const.hasinit
  //## begin NetworkStatusReverse::NetworkStatusReverse%61A79831031F_const.initialization preserve=yes
   : ConversionItem("## CFC2 XLATE NETWORK STATUS REVERSE")
  //## end NetworkStatusReverse::NetworkStatusReverse%61A79831031F_const.initialization
{
  //## begin configuration::NetworkStatusReverse::NetworkStatusReverse%61A79831031F_const.body preserve=yes
   memcpy(m_sID, "CFC2", 4);
  //## end configuration::NetworkStatusReverse::NetworkStatusReverse%61A79831031F_const.body
}


NetworkStatusReverse::~NetworkStatusReverse()
{
  //## begin configuration::NetworkStatusReverse::~NetworkStatusReverse%61A79831031F_dest.body preserve=yes
  //## end configuration::NetworkStatusReverse::~NetworkStatusReverse%61A79831031F_dest.body
}



//## Other Operations (implementation)
void NetworkStatusReverse::bind (Query& hQuery)
{
  //## begin configuration::NetworkStatusReverse::bind%61A7A5040258.body preserve=yes
   hQuery.setQualifier("QUALIFY", "X_NETWORK_STATUS");
   hQuery.bind("X_NETWORK_STATUS", "NET_ID", Column::STRING, &m_strFirst);
   hQuery.bind("X_NETWORK_STATUS", "NET_CASE_STATUS", Column::STRING, &m_strSecond);
   hQuery.bind("X_NETWORK_STATUS", "REQUEST_TYPE", Column::STRING, &m_strREQ_TYPE);
   hQuery.bind("X_NETWORK_STATUS", "STATUS", Column::STRING, &m_strSTATUS);
   hQuery.setBasicPredicate("X_NETWORK_STATUS", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_NETWORK_STATUS", "CC_STATE", "=", "A");
   string strTemp = "('" + m_strCUST_ID + "','****')";
   hQuery.setBasicPredicate("X_NETWORK_STATUS", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("X_NETWORK_STATUS.NET_ID,X_NETWORK_STATUS.REQUEST_TYPE,X_NETWORK_STATUS.STATUS ASC,X_NETWORK_STATUS.CUST_ID DESC");
  //## end configuration::NetworkStatusReverse::bind%61A7A5040258.body
}

const string& NetworkStatusReverse::getFirst ()
{
  //## begin configuration::NetworkStatusReverse::getFirst%61A7A69E02EA.body preserve=yes
   m_strFirst.resize(3, ' ');
   m_strFirst.append(m_strREQ_TYPE);
   m_strFirst.resize(7, ' ');
   m_strFirst.append(m_strSTATUS);
   return m_strFirst;
  //## end configuration::NetworkStatusReverse::getFirst%61A7A69E02EA.body
}

// Additional Declarations
  //## begin configuration::NetworkStatusReverse%61A79831031F.declarations preserve=yes
  //## end configuration::NetworkStatusReverse%61A79831031F.declarations

} // namespace configuration

//## begin module%61A79740039F.epilog preserve=yes
//## end module%61A79740039F.epilog
