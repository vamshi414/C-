//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%391C0FA7002D.cm preserve=no
// $Date:   Feb 14 2019 03:29:50  $ $Author:   e3028298  $
// $Revision:   1.14  $
//## end module%391C0FA7002D.cm

//## begin module%391C0FA7002D.cp preserve=no
// Copyright (c) 1998 - 2007
// EFD | eFunds Corporation
//## end module%391C0FA7002D.cp

//## Module: CXOSCF16%391C0FA7002D; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF16.cpp

//## begin module%391C0FA7002D.additionalIncludes preserve=no
//## end module%391C0FA7002D.additionalIncludes

//## begin module%391C0FA7002D.includes preserve=yes
//## end module%391C0FA7002D.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF16_h
#include "CXODCF16.hpp"
#endif


//## begin module%391C0FA7002D.declarations preserve=no
//## end module%391C0FA7002D.declarations

//## begin module%391C0FA7002D.additionalDeclarations preserve=yes
//## end module%391C0FA7002D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::Device

Device::Device()
  //## begin Device::Device%391C0C8A02DA_const.hasinit preserve=no
  //## end Device::Device%391C0C8A02DA_const.hasinit
  //## begin Device::Device%391C0C8A02DA_const.initialization preserve=yes
   : ConversionItem("## CR19 CHAIN DEVICE TO INST")
  //## end Device::Device%391C0C8A02DA_const.initialization
{
  //## begin configuration::Device::Device%391C0C8A02DA_const.body preserve=yes
   memcpy(m_sID,"CF16",4);
  //## end configuration::Device::Device%391C0C8A02DA_const.body
}


Device::~Device()
{
  //## begin configuration::Device::~Device%391C0C8A02DA_dest.body preserve=yes
  //## end configuration::Device::~Device%391C0C8A02DA_dest.body
}



//## Other Operations (implementation)
void Device::bind (reusable::Query& hQuery)
{
  //## begin configuration::Device::bind%391C1BF30251.body preserve=yes
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.setQualifier("QUALIFY","DEVICE");
   hQuery.bind("DEVICE","DEVICE_ID",Column::STRING,&m_strFirst);
   hQuery.bind("DEVICE","INST_ID",Column::STRING,&m_strINST_ID);
   hQuery.bind("DEVICE","POSTAL_CODE",Column::STRING,&m_strPOSTAL_CODE);
   hQuery.bind("DEVICE","REGION",Column::STRING,&m_strREGION);
   hQuery.bind("DEVICE","RPT_LVL_ID",Column::STRING,&m_strRPT_LVL_ID);
   hQuery.bind("DEVICE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.bind("DEVICE","DEFAULT_CUR_CODE",Column::STRING,&m_strDEFAULT_CUR_CODE);
   hQuery.bind("DEVICE","HOW_TERM_ATTACHED",Column::STRING,&m_strHOW_TERM_ATTACHED);
   hQuery.setBasicPredicate("DEVICE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("DEVICE","CC_STATE","=","A");
   string strTemp = "('" + strCUST_ID + "','****')";
   hQuery.setBasicPredicate("DEVICE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("DEVICE.DEVICE_ID ASC,DEVICE.CUST_ID DESC");
  //## end configuration::Device::bind%391C1BF30251.body
}

const string& Device::getSecond ()
{
  //## begin configuration::Device::getSecond%3943A10B03AF.body preserve=yes
   m_strSecond = m_strINST_ID;
   m_strSecond.resize(11,' ');
   m_strSecond += m_strRPT_LVL_ID;
   return m_strSecond;
  //## end configuration::Device::getSecond%3943A10B03AF.body
}

const string& Device::getThird ()
{
  //## begin configuration::Device::getThird%44B3FF0302BF.body preserve=yes
   m_strThird = m_strPOSTAL_CODE;
   m_strThird.resize(10,' ');
   m_strThird += m_strREGION;
   m_strThird.resize(13,' ');
   m_strThird += m_strDEFAULT_CUR_CODE;
   m_strThird.resize(16,' ');
   m_strThird +=m_strHOW_TERM_ATTACHED;
   m_strThird.resize(17, ' ');
   return m_strThird;
  //## end configuration::Device::getThird%44B3FF0302BF.body
}

// Additional Declarations
  //## begin configuration::Device%391C0C8A02DA.declarations preserve=yes
  //## end configuration::Device%391C0C8A02DA.declarations

} // namespace configuration

//## begin module%391C0FA7002D.epilog preserve=yes
//## end module%391C0FA7002D.epilog
