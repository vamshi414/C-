//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5FA3C7FF0079.cm preserve=no
//	$Date:   Sep 06 2021 04:44:42  $ $Author:   e3028298  $
//	$Revision:   1.2  $
//## end module%5FA3C7FF0079.cm

//## begin module%5FA3C7FF0079.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5FA3C7FF0079.cp

//## Module: CXOSCFB7%5FA3C7FF0079; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\V03.1A.R010\Dn\Server\Library\Cfdll\CXOSCFB7.cpp

//## begin module%5FA3C7FF0079.additionalIncludes preserve=no
//## end module%5FA3C7FF0079.additionalIncludes

//## begin module%5FA3C7FF0079.includes preserve=yes
//## end module%5FA3C7FF0079.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCFB7_h
#include "CXODCFB7.hpp"
#endif


//## begin module%5FA3C7FF0079.declarations preserve=no
//## end module%5FA3C7FF0079.declarations

//## begin module%5FA3C7FF0079.additionalDeclarations preserve=yes
//## end module%5FA3C7FF0079.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::QMRInstitution 

QMRInstitution::QMRInstitution()
  //## begin QMRInstitution::QMRInstitution%5FA3C92D01D5_const.hasinit preserve=no
  //## end QMRInstitution::QMRInstitution%5FA3C92D01D5_const.hasinit
  //## begin QMRInstitution::QMRInstitution%5FA3C92D01D5_const.initialization preserve=yes
  //## end QMRInstitution::QMRInstitution%5FA3C92D01D5_const.initialization
{
  //## begin configuration::QMRInstitution::QMRInstitution%5FA3C92D01D5_const.body preserve=yes
   memcpy(m_sID,"CFB7",4);
  //## end configuration::QMRInstitution::QMRInstitution%5FA3C92D01D5_const.body
}


QMRInstitution::~QMRInstitution()
{
  //## begin configuration::QMRInstitution::~QMRInstitution%5FA3C92D01D5_dest.body preserve=yes
  //## end configuration::QMRInstitution::~QMRInstitution%5FA3C92D01D5_dest.body
}



//## Other Operations (implementation)
void QMRInstitution::bind (Query& hQuery)
{
  //## begin configuration::QMRInstitution::bind%5FA3CD1D0361.body preserve=yes
   hQuery.setQualifier("QUALIFY", "QMR_BIN");
   hQuery.bind("QMR_BIN", "INST_ID", Column::STRING, &m_strFirst);
   hQuery.bind("QMR_BIN", "BIN", Column::STRING, &m_strBIN);
   hQuery.bind("QMR_BIN", "NETWORK_ID", Column::STRING, &m_strSecond);
   hQuery.bind("QMR_BIN", "BIN_TYPE", Column::STRING, &m_strThird);
   hQuery.setBasicPredicate("QMR_BIN", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("QMR_BIN", "CC_STATE", "=", "A");
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER", strCUST_ID);
   string strTemp = "('" + strCUST_ID + "','****')";
   hQuery.setBasicPredicate("QMR_BIN", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("INST_ID ASC,"
      "BIN ASC,"
      "CUST_ID DESC");
  //## end configuration::QMRInstitution::bind%5FA3CD1D0361.body
}

const string& QMRInstitution::getFirst ()
{
  //## begin configuration::QMRInstitution::getFirst%5FA3CD210000.body preserve=yes
   m_strFirst.resize(11, ' ');
   m_strFirst += m_strBIN;
   return m_strFirst;
  //## end configuration::QMRInstitution::getFirst%5FA3CD210000.body
}

bool QMRInstitution::getBinDetails (const string& strINST_ID, const string& strBIN, int&  iLength, string& strNET_ID)
{
  //## begin configuration::QMRInstitution::getBinDetails%5FA3CD2802D0.body preserve=yes
   string strFirst(strINST_ID);
   strFirst.resize(11, ' ');
   strFirst += strBIN;
   strFirst.resize(23, ' ');
   iLength = 11;
   while (strFirst.length() > 17)
   {
      strFirst.resize(strFirst.length() - 1);
      if (ConfigurationRepository::instance()->translate("QMR_BIN", strFirst, strNET_ID, " ", " ", 0, false))
         return true;
      iLength--;
   }
   iLength = 11;
   return false;
  //## end configuration::QMRInstitution::getBinDetails%5FA3CD2802D0.body
}

// Additional Declarations
  //## begin configuration::QMRInstitution%5FA3C92D01D5.declarations preserve=yes
const string& QMRInstitution::getThird()
{
   //## begin configuration::QMRInstitution::getFirst%5FA3CD210000.body preserve=yes
   m_strThird.resize(1,' ');
   return m_strThird;
   //## end configuration::QMRInstitution::getFirst%5FA3CD210000.body
}
  //## end configuration::QMRInstitution%5FA3C92D01D5.declarations

} // namespace configuration

//## begin module%5FA3C7FF0079.epilog preserve=yes
//## end module%5FA3C7FF0079.epilog
