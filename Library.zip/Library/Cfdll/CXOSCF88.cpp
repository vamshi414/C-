//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4535B04B0252.cm preserve=no
//	$Date:   Apr 17 2014 21:06:14  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%4535B04B0252.cm

//## begin module%4535B04B0252.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%4535B04B0252.cp

//## Module: CXOSCF88%4535B04B0252; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF88.cpp

//## begin module%4535B04B0252.additionalIncludes preserve=no
//## end module%4535B04B0252.additionalIncludes

//## begin module%4535B04B0252.includes preserve=yes
//## end module%4535B04B0252.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF88_h
#include "CXODCF88.hpp"
#endif


//## begin module%4535B04B0252.declarations preserve=no
//## end module%4535B04B0252.declarations

//## begin module%4535B04B0252.additionalDeclarations preserve=yes
//## end module%4535B04B0252.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::MCIPMProcessCode 

MCIPMProcessCode::MCIPMProcessCode()
  //## begin MCIPMProcessCode::MCIPMProcessCode%4535B1D80068_const.hasinit preserve=no
  //## end MCIPMProcessCode::MCIPMProcessCode%4535B1D80068_const.hasinit
  //## begin MCIPMProcessCode::MCIPMProcessCode%4535B1D80068_const.initialization preserve=yes
  //## end MCIPMProcessCode::MCIPMProcessCode%4535B1D80068_const.initialization
{
  //## begin configuration::MCIPMProcessCode::MCIPMProcessCode%4535B1D80068_const.body preserve=yes
  //## end configuration::MCIPMProcessCode::MCIPMProcessCode%4535B1D80068_const.body
}


MCIPMProcessCode::~MCIPMProcessCode()
{
  //## begin configuration::MCIPMProcessCode::~MCIPMProcessCode%4535B1D80068_dest.body preserve=yes
  //## end configuration::MCIPMProcessCode::~MCIPMProcessCode%4535B1D80068_dest.body
}



//## Other Operations (implementation)
void MCIPMProcessCode::bind (reusable::Query& hQuery)
{
  //## begin configuration::MCIPMProcessCode::bind%4535B5210360.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_MC_PROC_CODE");
   hQuery.bind("X_MC_PROC_CODE","MC_PROCESS_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_MC_PROC_CODE","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("X_MC_PROC_CODE","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("X_MC_PROC_CODE","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("X_MC_PROC_CODE","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("X_MC_PROC_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_MC_PROC_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_MC_PROC_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_MC_PROC_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_MC_PROC_CODE.MC_PROCESS_CODE ASC,X_MC_PROC_CODE.CUST_ID DESC");
  //## end configuration::MCIPMProcessCode::bind%4535B5210360.body
}

const string& MCIPMProcessCode::getFirst ()
{
  //## begin configuration::MCIPMProcessCode::getFirst%4535B5210374.body preserve=yes
   return m_strFirst;
  //## end configuration::MCIPMProcessCode::getFirst%4535B5210374.body
}

const string& MCIPMProcessCode::getSecond ()
{
  //## begin configuration::MCIPMProcessCode::getSecond%4535B5210388.body preserve=yes
   while (m_strPROCESS_CODE.length() < 6)
      m_strPROCESS_CODE += ' ';
   while (m_strMSG_CLASS.length() < 1)
      m_strMSG_CLASS += ' ';
   while (m_strPRE_AUTH.length() < 1)
      m_strPRE_AUTH += ' ';
   m_strSecond = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strSecond;
  //## end configuration::MCIPMProcessCode::getSecond%4535B5210388.body
}

// Additional Declarations
  //## begin configuration::MCIPMProcessCode%4535B1D80068.declarations preserve=yes
  //## end configuration::MCIPMProcessCode%4535B1D80068.declarations

} // namespace configuration

//## begin module%4535B04B0252.epilog preserve=yes
//## end module%4535B04B0252.epilog
