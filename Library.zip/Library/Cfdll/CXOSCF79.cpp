//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4263E4A101B5.cm preserve=no
//	$Date:   Dec 16 2016 15:31:08  $ $Author:   e1009652  $
//	$Revision:   1.6  $
//## end module%4263E4A101B5.cm

//## begin module%4263E4A101B5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4263E4A101B5.cp

//## Module: CXOSCF79%4263E4A101B5; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF79.cpp

//## begin module%4263E4A101B5.additionalIncludes preserve=no
//## end module%4263E4A101B5.additionalIncludes

//## begin module%4263E4A101B5.includes preserve=yes
//## end module%4263E4A101B5.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF79_h
#include "CXODCF79.hpp"
#endif


//## begin module%4263E4A101B5.declarations preserve=no
//## end module%4263E4A101B5.declarations

//## begin module%4263E4A101B5.additionalDeclarations preserve=yes
//## end module%4263E4A101B5.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::OasisTermType 

OasisTermType::OasisTermType()
  //## begin OasisTermType::OasisTermType%4263E45C0203_const.hasinit preserve=no
  //## end OasisTermType::OasisTermType%4263E45C0203_const.hasinit
  //## begin OasisTermType::OasisTermType%4263E45C0203_const.initialization preserve=yes
   : ConversionItem("## CR82 XLATE IST TERM TYPE")
  //## end OasisTermType::OasisTermType%4263E45C0203_const.initialization
{
  //## begin configuration::OasisTermType::OasisTermType%4263E45C0203_const.body preserve=yes
   memcpy(m_sID,"CF79",4);
  //## end configuration::OasisTermType::OasisTermType%4263E45C0203_const.body
}


OasisTermType::~OasisTermType()
{
  //## begin configuration::OasisTermType::~OasisTermType%4263E45C0203_dest.body preserve=yes
  //## end configuration::OasisTermType::~OasisTermType%4263E45C0203_dest.body
}



//## Other Operations (implementation)
void OasisTermType::bind (Query& hQuery)
{
  //## begin configuration::OasisTermType::bind%4263E4EA02BF.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_IST_TERM_TYPE");
   hQuery.bind("X_IST_TERM_TYPE","IST_TERM_TYPE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IST_TERM_TYPE","TERM_CLASS",Column::STRING,&m_strSecond);
   hQuery.bind("X_IST_TERM_TYPE","X_TYPE",Column::STRING,&m_strThird);
   hQuery.setBasicPredicate("X_IST_TERM_TYPE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IST_TERM_TYPE","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IST_TERM_TYPE.IST_TERM_TYPE ASC");
  //## end configuration::OasisTermType::bind%4263E4EA02BF.body
}

void OasisTermType::setPredicate (Query& hQuery)
{
  //## begin configuration::OasisTermType::setPredicate%5847180D0287.body preserve=yes
   hQuery.setBasicPredicate("X_IST_TERM_TYPE", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IST_TERM_TYPE", "CC_STATE", "=", "A"); 
  //## end configuration::OasisTermType::setPredicate%5847180D0287.body
}

// Additional Declarations
  //## begin configuration::OasisTermType%4263E45C0203.declarations preserve=yes
  //## end configuration::OasisTermType%4263E45C0203.declarations

} // namespace configuration

//## begin module%4263E4A101B5.epilog preserve=yes
//## end module%4263E4A101B5.epilog
