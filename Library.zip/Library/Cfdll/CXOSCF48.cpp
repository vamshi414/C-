//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FF1D5C60271.cm preserve=no
//	$Date:   Dec 16 2016 15:18:04  $ $Author:   e1009652  $
//	$Revision:   1.3  $
//## end module%3FF1D5C60271.cm

//## begin module%3FF1D5C60271.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FF1D5C60271.cp

//## Module: CXOSCF48%3FF1D5C60271; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF48.cpp

//## begin module%3FF1D5C60271.additionalIncludes preserve=no
//## end module%3FF1D5C60271.additionalIncludes

//## begin module%3FF1D5C60271.includes preserve=yes
// $Date:   Dec 16 2016 15:18:04  $ $Author:   e1009652  $ $Revision:   1.3  $
//## end module%3FF1D5C60271.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF48_h
#include "CXODCF48.hpp"
#endif
//## begin module%3FF1D5C60271.declarations preserve=no
//## end module%3FF1D5C60271.declarations

//## begin module%3FF1D5C60271.additionalDeclarations preserve=yes
//## end module%3FF1D5C60271.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexPanEntryMode1 

ConnexPanEntryMode1::ConnexPanEntryMode1()
  //## begin ConnexPanEntryMode1::ConnexPanEntryMode1%3FF1D51B00AB_const.hasinit preserve=no
  //## end ConnexPanEntryMode1::ConnexPanEntryMode1%3FF1D51B00AB_const.hasinit
  //## begin ConnexPanEntryMode1::ConnexPanEntryMode1%3FF1D51B00AB_const.initialization preserve=yes
   : ConversionItem("## CR60 XLATE PAN ENTRY1")
  //## end ConnexPanEntryMode1::ConnexPanEntryMode1%3FF1D51B00AB_const.initialization
{
  //## begin configuration::ConnexPanEntryMode1::ConnexPanEntryMode1%3FF1D51B00AB_const.body preserve=yes
   memcpy(m_sID,"CF48",4);
  //## end configuration::ConnexPanEntryMode1::ConnexPanEntryMode1%3FF1D51B00AB_const.body
}


ConnexPanEntryMode1::~ConnexPanEntryMode1()
{
  //## begin configuration::ConnexPanEntryMode1::~ConnexPanEntryMode1%3FF1D51B00AB_dest.body preserve=yes
  //## end configuration::ConnexPanEntryMode1::~ConnexPanEntryMode1%3FF1D51B00AB_dest.body
}



//## Other Operations (implementation)
void ConnexPanEntryMode1::bind (Query& hQuery)
{
  //## begin configuration::ConnexPanEntryMode1::bind%3FF1D59C0109.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_IBM_PAN_ENTR_MOD");
   hQuery.bind("X_IBM_PAN_ENTR_MOD","PAN_ENTRY_MODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_PAN_ENTR_MOD","POS_CRD_DAT_IN_CAP",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_IBM_PAN_ENTR_MOD","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_PAN_ENTR_MOD","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IBM_PAN_ENTR_MOD.PAN_ENTRY_MODE ASC");
  //## end configuration::ConnexPanEntryMode1::bind%3FF1D59C0109.body
}

void ConnexPanEntryMode1::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexPanEntryMode1::setPredicate%584715C80044.body preserve=yes
   hQuery.setBasicPredicate("X_IBM_PAN_ENTR_MOD", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IBM_PAN_ENTR_MOD", "CC_STATE", "=", "A");
  //## end configuration::ConnexPanEntryMode1::setPredicate%584715C80044.body
}

// Additional Declarations
  //## begin configuration::ConnexPanEntryMode1%3FF1D51B00AB.declarations preserve=yes
  //## end configuration::ConnexPanEntryMode1%3FF1D51B00AB.declarations

} // namespace configuration

//## begin module%3FF1D5C60271.epilog preserve=yes
//## end module%3FF1D5C60271.epilog
