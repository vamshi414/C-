//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%482989670251.cm preserve=no
//	$Date:   Apr 17 2014 21:06:20  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%482989670251.cm

//## begin module%482989670251.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%482989670251.cp

//## Module: CXOSCF95%482989670251; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF95.cpp

//## begin module%482989670251.additionalIncludes preserve=no
//## end module%482989670251.additionalIncludes

//## begin module%482989670251.includes preserve=yes
//## end module%482989670251.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF95_h
#include "CXODCF95.hpp"
#endif


//## begin module%482989670251.declarations preserve=no
//## end module%482989670251.declarations

//## begin module%482989670251.additionalDeclarations preserve=yes
//## end module%482989670251.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::PulseProcessCode 

PulseProcessCode::PulseProcessCode()
  //## begin PulseProcessCode::PulseProcessCode%482988A8029F_const.hasinit preserve=no
  //## end PulseProcessCode::PulseProcessCode%482988A8029F_const.hasinit
  //## begin PulseProcessCode::PulseProcessCode%482988A8029F_const.initialization preserve=yes
   : ConversionItem("## CR95 XLATE PULSE PROCESS CODE")
  //## end PulseProcessCode::PulseProcessCode%482988A8029F_const.initialization
{
  //## begin configuration::PulseProcessCode::PulseProcessCode%482988A8029F_const.body preserve=yes
   memcpy(m_sID,"CF95",4);
  //## end configuration::PulseProcessCode::PulseProcessCode%482988A8029F_const.body
}


PulseProcessCode::~PulseProcessCode()
{
  //## begin configuration::PulseProcessCode::~PulseProcessCode%482988A8029F_dest.body preserve=yes
  //## end configuration::PulseProcessCode::~PulseProcessCode%482988A8029F_dest.body
}



//## Other Operations (implementation)
void PulseProcessCode::bind (reusable::Query& hQuery)
{
  //## begin configuration::PulseProcessCode::bind%482989240290.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_PULSE_PROC_CODE");
   hQuery.bind("X_PULSE_PROC_CODE","PULSE_TRAN_TYPE",Column::STRING,&m_strFirst);
   hQuery.bind("X_PULSE_PROC_CODE","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("X_PULSE_PROC_CODE","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("X_PULSE_PROC_CODE","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("X_PULSE_PROC_CODE","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("X_PULSE_PROC_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_PULSE_PROC_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_PULSE_PROC_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_PULSE_PROC_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_PULSE_PROC_CODE.PULSE_TRAN_TYPE ASC,X_PULSE_PROC_CODE.CUST_ID DESC");
  //## end configuration::PulseProcessCode::bind%482989240290.body
}

const string& PulseProcessCode::getSecond ()
{
  //## begin configuration::PulseProcessCode::getSecond%4829892C005D.body preserve=yes
   while (m_strPROCESS_CODE.length() < 6)
      m_strPROCESS_CODE += ' ';
   while (m_strMSG_CLASS.length() < 1)
      m_strMSG_CLASS += ' ';
   while (m_strPRE_AUTH.length() < 1)
      m_strPRE_AUTH += ' ';
   m_strSecond = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strSecond;
  //## end configuration::PulseProcessCode::getSecond%4829892C005D.body
}

// Additional Declarations
  //## begin configuration::PulseProcessCode%482988A8029F.declarations preserve=yes
  //## end configuration::PulseProcessCode%482988A8029F.declarations

} // namespace configuration

//## begin module%482989670251.epilog preserve=yes
//## end module%482989670251.epilog
