//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%43F34D09033C.cm preserve=no
//	$Date:   Dec 16 2016 15:33:08  $ $Author:   e1009652  $
//	$Revision:   1.3  $
//## end module%43F34D09033C.cm

//## begin module%43F34D09033C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%43F34D09033C.cp

//## Module: CXOSCF86%43F34D09033C; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF86.cpp

//## begin module%43F34D09033C.additionalIncludes preserve=no
//## end module%43F34D09033C.additionalIncludes

//## begin module%43F34D09033C.includes preserve=yes
//## end module%43F34D09033C.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF86_h
#include "CXODCF86.hpp"
#endif


//## begin module%43F34D09033C.declarations preserve=no
//## end module%43F34D09033C.declarations

//## begin module%43F34D09033C.additionalDeclarations preserve=yes
//## end module%43F34D09033C.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::Miscellaneous 

Miscellaneous::Miscellaneous()
  //## begin Miscellaneous::Miscellaneous%43F34C1D036B_const.hasinit preserve=no
  //## end Miscellaneous::Miscellaneous%43F34C1D036B_const.hasinit
  //## begin Miscellaneous::Miscellaneous%43F34C1D036B_const.initialization preserve=yes
  : ConversionItem("## CR80 MISCELLANEOUS")
  //## end Miscellaneous::Miscellaneous%43F34C1D036B_const.initialization
{
  //## begin configuration::Miscellaneous::Miscellaneous%43F34C1D036B_const.body preserve=yes
   memcpy(m_sID,"CF86",4);
  //## end configuration::Miscellaneous::Miscellaneous%43F34C1D036B_const.body
}

Miscellaneous::Miscellaneous (const char* pszCFG_DATA_TYPE)
  //## begin configuration::Miscellaneous::Miscellaneous%57B1C346037E.hasinit preserve=no
  //## end configuration::Miscellaneous::Miscellaneous%57B1C346037E.hasinit
  //## begin configuration::Miscellaneous::Miscellaneous%57B1C346037E.initialization preserve=yes
   : ConversionItem("## CR80 MISCELLANEOUS")
   ,m_strCFG_DATA_TYPE(pszCFG_DATA_TYPE)
  //## end configuration::Miscellaneous::Miscellaneous%57B1C346037E.initialization
{
  //## begin configuration::Miscellaneous::Miscellaneous%57B1C346037E.body preserve=yes
   memcpy(m_sID,"CF86",4);
  //## end configuration::Miscellaneous::Miscellaneous%57B1C346037E.body
}


Miscellaneous::~Miscellaneous()
{
  //## begin configuration::Miscellaneous::~Miscellaneous%43F34C1D036B_dest.body preserve=yes
  //## end configuration::Miscellaneous::~Miscellaneous%43F34C1D036B_dest.body
}



//## Other Operations (implementation)
void Miscellaneous::bind (Query& hQuery)
{
  //## begin configuration::Miscellaneous::bind%43F34CC9009C.body preserve=yes
   hQuery.setQualifier("QUALIFY","MISC_CFG_DATA");
   hQuery.bind("MISC_CFG_DATA","DATA_VALUE",Column::STRING,&m_strFirst);
   hQuery.bind("MISC_CFG_DATA","CFG_DESCRIPTION",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("MISC_CFG_DATA","CFG_DATA_TYPE","=",m_strCFG_DATA_TYPE.c_str());
   hQuery.setBasicPredicate("MISC_CFG_DATA","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("MISC_CFG_DATA","CC_STATE","=","A");
   hQuery.setOrderByClause("DATA_VALUE ASC");
  //## end configuration::Miscellaneous::bind%43F34CC9009C.body
}

const string& Miscellaneous::getFirst ()
{
  //## begin configuration::Miscellaneous::getFirst%57B1C2320098.body preserve=yes
   return m_strFirst;
  //## end configuration::Miscellaneous::getFirst%57B1C2320098.body
}

const string& Miscellaneous::getSecond ()
{
  //## begin configuration::Miscellaneous::getSecond%57B1C23400F7.body preserve=yes
   m_strSecond.resize(135,' ');
   return m_strSecond;
  //## end configuration::Miscellaneous::getSecond%57B1C23400F7.body
}

void Miscellaneous::setPredicate (Query& hQuery)
{
  //## begin configuration::Miscellaneous::setPredicate%584717C3025E.body preserve=yes
   hQuery.setBasicPredicate("MISC_CFG_DATA", "CFG_DATA_TYPE", "=", m_strCFG_DATA_TYPE.c_str());
   hQuery.setBasicPredicate("MISC_CFG_DATA", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("MISC_CFG_DATA", "CC_STATE", "=", "A");
  //## end configuration::Miscellaneous::setPredicate%584717C3025E.body
}

// Additional Declarations
  //## begin configuration::Miscellaneous%43F34C1D036B.declarations preserve=yes
  //## end configuration::Miscellaneous%43F34C1D036B.declarations

} // namespace configuration

//## begin module%43F34D09033C.epilog preserve=yes
//## end module%43F34D09033C.epilog
