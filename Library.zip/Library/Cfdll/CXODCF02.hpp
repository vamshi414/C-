//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3910504E022F.cm preserve=no
//## end module%3910504E022F.cm

//## begin module%3910504E022F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3910504E022F.cp

//## Module: CXOSCF02%3910504E022F; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCF02.hpp

#ifndef CXOSCF02_h
#define CXOSCF02_h 1

//## begin module%3910504E022F.additionalIncludes preserve=no
//## end module%3910504E022F.additionalIncludes

//## begin module%3910504E022F.includes preserve=yes
// $Date:   Dec 10 2020 02:47:00  $ $Author:   e3027760  $ $Revision:   1.52  $
#include <map>
//## end module%3910504E022F.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class Device;
class ConnexRejectCode;
class ConnexProcessCode;
class ConnexMessageTypeIdentifier;
class ConnexAdviceReason;
class ConfigurationFactory;
class CirrusProcessCode;
class CirrusAdjustmentReason;
class CardType;
class CardOwnerType;
class AdvantageProcessCode;
class AdvantageMessageCode;
class AdvantageCardType;
class AdvantageCardLogo;
class OasisProcessCode;
class NetworkInstitution;
class ConnexTerminalType2;
class ProcessorGroup;
class ReconInstitution;
class GenericTransactionClass;
class LowCash;
class Base24ReversalCode;
class Base24POSResponseCode;
class Base24ATMResponseCode;
class Base24POSProcessCode;
class Base24ATMProcessCode;
class VisaProcessCode;
class VisaAdjustmentReason;
class TransactionTypeIdentifier;
class Processor;
class PlusProcessCode;
class PlusCorrectionReason;
class OnlineNetwork;
class Institution;
class FinancialType;
class SettlementWebAdjNetId;
class BankIDInstitution;
class ActionType;
class GenericReverse;
class ProcessorName;
class DeviceRevAll;
class MasterCardResponseCode;
class VisaResponseCode;
class MasterCardAdviceReason;
class PrepaidNetworkId;
class InstitutionBankID;
class ErrorMessage;
class DisputedAuthorizationTransaction;
class PulseProcessCodeRev;
class PulseProcessCode;
class CountryCodeNumToISO;
class GenericTranslation;
class DeviceAddress;
class DeviceRev;
class ActionCode;
class NACHAReturnCode;
class MCIPMProcessCode;
class OasisNetwork;
class Miscellaneous;
class StarProcessCodeRev;
class StarActionTypeRev;
class StarActionType;
class StarProcessCode;
class CountryCodeNum;
class OasisTermType;
class OasisReasonCode;
class OasisPCode;
class OasisCardProduct;
class OasisRespCode;
class CountryCode2to3;
class CountryCode;
class DNTransactionType;
class NetworkMiscDataRev;
class NetworkMiscData;
class ConnexATMStatus;
class ReportingLevelBusiness;
class ReportingLevel;
class NetworkInstitution1;
class ActionTypeRev;
class SchemeFunding;
class QMRVisaBusinessID;
class NYCEProcCode;
class CMSProcCode;
class ProcessorCalendar;
class InstitutionCalendar;
class AIMSBillingInstitution;
class AIMSBillingInstitutionReverse;
class NetworkStatusReverse;
class NetworkStatus;
class QMRIssuers;
class QMRAcquirer;
class QMRInstitution;
class MsgReason;
class CountryCodeNumToRegion;
class NCRProcessCode;
class CurrencyCodeReverse;
class CurrencyCode;
class NetProcessorId;
class BusinessCode;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Global;
} // namespace reusable

namespace configuration {
class MoneyPassProcessCode;

} // namespace configuration

//## begin module%3910504E022F.declarations preserve=no
//## end module%3910504E022F.declarations

//## begin module%3910504E022F.additionalDeclarations preserve=yes
//## end module%3910504E022F.additionalDeclarations


namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConfigurationFactory%390F3EB902E3.preface preserve=yes
//## end configuration::ConfigurationFactory%390F3EB902E3.preface

//## Class: ConfigurationFactory%390F3EB902E3
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3911628B0310;reusable::Global { -> F}
//## Uses: <unnamed>%3912F16B019D;AdvantageCardLogo { -> F}
//## Uses: <unnamed>%3912F16E0238;AdvantageCardType { -> F}
//## Uses: <unnamed>%3912F17102BE;AdvantageMessageCode { -> F}
//## Uses: <unnamed>%3920118E001E;AdvantageProcessCode { -> F}
//## Uses: <unnamed>%392011900111;VisaProcessCode { -> F}
//## Uses: <unnamed>%3920119602B5;CirrusProcessCode { -> F}
//## Uses: <unnamed>%392011980380;PlusProcessCode { -> F}
//## Uses: <unnamed>%3920119B0077;VisaAdjustmentReason { -> F}
//## Uses: <unnamed>%3920119D01BA;CirrusAdjustmentReason { -> F}
//## Uses: <unnamed>%3920119F027B;PlusCorrectionReason { -> F}
//## Uses: <unnamed>%392011A1033D;Device { -> F}
//## Uses: <unnamed>%392011A400CA;Institution { -> F}
//## Uses: <unnamed>%392011A800BC;Processor { -> F}
//## Uses: <unnamed>%392011AB0016;ConnexRejectCode { -> F}
//## Uses: <unnamed>%392011AD029A;ConnexMessageTypeIdentifier { -> F}
//## Uses: <unnamed>%392011AF0397;ConnexProcessCode { -> F}
//## Uses: <unnamed>%392011B201F7;OnlineNetwork { -> F}
//## Uses: <unnamed>%392011B50092;ConnexAdviceReason { -> F}
//## Uses: <unnamed>%393E73DE021A;TransactionTypeIdentifier { -> F}
//## Uses: <unnamed>%393E73E10188;FinancialType { -> F}
//## Uses: <unnamed>%393FFD0B00DC;CardType { -> F}
//## Uses: <unnamed>%393FFD0F000F;CardOwnerType { -> F}
//## Uses: <unnamed>%39985EE0010F;Base24POSResponseCode { -> F}
//## Uses: <unnamed>%39985EE2005E;Base24ATMProcessCode { -> F}
//## Uses: <unnamed>%39985EE302FE;Base24ReversalCode { -> F}
//## Uses: <unnamed>%39985EE503B5;Base24POSProcessCode { -> F}
//## Uses: <unnamed>%39985EE70368;Base24ATMResponseCode { -> F}
//## Uses: <unnamed>%39D0E7FF02C7;LowCash { -> F}
//## Uses: <unnamed>%3ACCDCF60253;GenericTransactionClass { -> F}
//## Uses: <unnamed>%3ACCDCF90044;ReconInstitution { -> F}
//## Uses: <unnamed>%3C1A53D6031C;GasperStatusCode { -> }
//## Uses: <unnamed>%3E07427201A5;ProcessorGroup { -> F}
//## Uses: <unnamed>%3FF1A0F20261;ConnexPinEntryMode { -> F}
//## Uses: <unnamed>%3FF1D6680290;ConnexPanEntryMode1 { -> F}
//## Uses: <unnamed>%3FF1D9CB0157;ConnexPanEntryMode2 { -> F}
//## Uses: <unnamed>%3FF98D83033C;ConnexPOSConditionCode1 { -> F}
//## Uses: <unnamed>%3FFC525A031C;ConnexPOSConditionCode2 { -> F}
//## Uses: <unnamed>%3FFC5272035B;ConnexPOSConditionCode3 { -> F}
//## Uses: <unnamed>%3FFC52840242;ConnexPOSConditionCode4 { -> F}
//## Uses: <unnamed>%3FFC729F03A9;ConnexPOSConditionCode5 { -> F}
//## Uses: <unnamed>%3FFC72B800FA;ConnexPOSConditionCode6 { -> F}
//## Uses: <unnamed>%3FFDB01E00FA;ConnexTerminalType1 { -> F}
//## Uses: <unnamed>%3FFDB0340128;ConnexTerminalType2 { -> F}
//## Uses: <unnamed>%4005553300EA;ConnexNetworkID { -> F}
//## Uses: <unnamed>%4006A27003D8;ConnexPOSConditionCode8 { -> F}
//## Uses: <unnamed>%4006A27B035B;ConnexPOSConditionCode7 { -> F}
//## Uses: <unnamed>%40A22B9E00FA;NetworkInstitution { -> F}
//## Uses: <unnamed>%40A22BA00186;OasisProcessCode { -> F}
//## Uses: <unnamed>%40BCD9C202AF;ConnexATMStatus { -> F}
//## Uses: <unnamed>%40EAC4B6005D;NetworkMiscData { -> F}
//## Uses: <unnamed>%40F539BA035B;NetworkMiscDataRev { -> F}
//## Uses: <unnamed>%42528F8E0251;DNTransactionType { -> F}
//## Uses: <unnamed>%4255747400FA;CountryCode { -> F}
//## Uses: <unnamed>%425EB861006D;CountryCode2to3 { -> F}
//## Uses: <unnamed>%425FBEA302FD;ConfigurationFactory { -> F}
//## Uses: <unnamed>%4263EF4A00FA;OasisCardProduct { -> F}
//## Uses: <unnamed>%4263EF6B003E;OasisTermType { -> F}
//## Uses: <unnamed>%4263EF6D0271;OasisRespCode { -> F}
//## Uses: <unnamed>%4263EF700242;OasisReasonCode { -> F}
//## Uses: <unnamed>%4263EF73000F;OasisPCode { -> F}
//## Uses: <unnamed>%4288C69801F4;CountryCodeNum { -> F}
//## Uses: <unnamed>%43135EDB032C;StarActionType { -> F}
//## Uses: <unnamed>%43135EE90203;StarProcessCode { -> F}
//## Uses: <unnamed>%4315EEFD0203;StarActionTypeRev { -> F}
//## Uses: <unnamed>%434151060271;StarProcessCodeRev { -> F}
//## Uses: <unnamed>%43F34D9701D4;Miscellaneous { -> F}
//## Uses: <unnamed>%44A3C42401D4;OasisNetwork { -> F}
//## Uses: <unnamed>%45371E60036C;MCIPMProcessCode { -> F}
//## Uses: <unnamed>%45658C2D0213;NACHAReturnCode { -> F}
//## Uses: <unnamed>%45CC004B01E7;ActionCode { -> F}
//## Uses: <unnamed>%45DA062E0095;DeviceRev { -> F}
//## Uses: <unnamed>%45ECF20E037E;DeviceAddress { -> F}
//## Uses: <unnamed>%4641AC7901C7;GenericTranslation { -> F}
//## Uses: <unnamed>%47C507B90181;CountryCodeNumToISO { -> F}
//## Uses: <unnamed>%48299B4C003E;PulseProcessCode { -> F}
//## Uses: <unnamed>%48299B630119;PulseProcessCodeRev { -> F}
//## Uses: <unnamed>%4ACCBD5B039D;DisputedAuthorizationTransaction { -> F}
//## Uses: <unnamed>%4AE732AB003F;ErrorMessage { -> F}
//## Uses: <unnamed>%4F70996402B2;PrepaidNetworkId { -> F}
//## Uses: <unnamed>%4F7099950301;InstitutionBankID { -> F}
//## Uses: <unnamed>%5059C7980193;MasterCardAdviceReason { -> F}
//## Uses: <unnamed>%5059C79B0152;VisaResponseCode { -> F}
//## Uses: <unnamed>%507D846801CE;MasterCardResponseCode { -> F}
//## Uses: <unnamed>%5191029C019B;DeviceRevAll { -> F}
//## Uses: <unnamed>%54AFA0DA0065;ProcessorName { -> F}
//## Uses: <unnamed>%56D6E67A027D;GenericReverse { -> F}
//## Uses: <unnamed>%577406A1009F;ActionType { -> F}
//## Uses: <unnamed>%59074A3D003B;BankIDInstitution { -> F}
//## Uses: <unnamed>%594A90C202FF;SettlementWebAdjNetId { -> F}
//## Uses: <unnamed>%5BA4A48602AB;NetProcessorId { -> F}
//## Uses: <unnamed>%5CF7CBC201F3;CurrencyCode { -> F}
//## Uses: <unnamed>%5CF7CBD10076;CurrencyCodeReverse { -> F}
//## Uses: <unnamed>%5D959C8A0027;NCRProcessCode { -> F}
//## Uses: <unnamed>%5F0C804E0217;MsgReason { -> F}
//## Uses: <unnamed>%5FA3D5220105;QMRInstitution { -> F}
//## Uses: <unnamed>%5FC5F64E01F7;QMRAcquirer { -> F}
//## Uses: <unnamed>%620DAFDD01C8;AIMSBillingInstitutionReverse { -> F}
//## Uses: <unnamed>%620DB17C02FD;CountryCodeNumToRegion { -> F}
//## Uses: <unnamed>%620DB17E00C5;BusinessCode { -> F}
//## Uses: <unnamed>%620DB1800056;NetworkStatus { -> F}
//## Uses: <unnamed>%620DB1810245;QMRIssuers { -> F}
//## Uses: <unnamed>%620DB1830066;NetworkStatusReverse { -> F}
//## Uses: <unnamed>%620DCA72006E;AIMSBillingInstitution { -> F}
//## Uses: <unnamed>%6221380F0056;ProcessorCalendar { -> F}
//## Uses: <unnamed>%6221381F0053;InstitutionCalendar { -> F}
//## Uses: <unnamed>%623C7C380082;CMSProcCode { -> F}
//## Uses: <unnamed>%623C7C3B0218;NYCEProcCode { -> F}
//## Uses: <unnamed>%624BF4BC02BF;QMRVisaBusinessID { -> F}
//## Uses: <unnamed>%6296D151023E;SchemeFunding { -> F}
//## Uses: <unnamed>%62BDE53F00D1;ActionTypeRev { -> F}
//## Uses: <unnamed>%64B15142013C;NetworkInstitution1 { -> F}
//## Uses: <unnamed>%64DF8A820216;ReportingLevelBusiness { -> F}
//## Uses: <unnamed>%64DF8A95017E;ReportingLevel { -> F}
//## Uses: <unnamed>%652825BA0057;MoneyPassProcessCode { -> F}

class DllExport ConfigurationFactory : public reusable::Object  //## Inherits: <unnamed>%390F3EDC038D
{
  //## begin configuration::ConfigurationFactory%390F3EB902E3.initialDeclarations preserve=yes
  //## end configuration::ConfigurationFactory%390F3EB902E3.initialDeclarations

  public:
    //## Constructors (generated)
      ConfigurationFactory();

    //## Destructor (generated)
      virtual ~ConfigurationFactory();


    //## Other Operations (specified)
      //## Operation: createConversionItem%391050E402E9
      Object* createConversionItem (const char* pszClass, const char* pszValue = 0);

      //## Operation: createMappingItem%3ACCDD0E0081
      Object* createMappingItem (const char* pszClass, const char* pszValue = 0);

      //## Operation: createVerificationItem%393E95B50109
      Object* createVerificationItem (const char* pszClass, const char* pszValue = 0);

      //## Operation: getCRBook%3FDDCAA2009C
      bool getCRBook (const char* pszTable, string& strCRBook);

      //## Operation: instance%3910510F0331
      static ConfigurationFactory* instance (Object* pSender = 0);

    // Additional Public Declarations
      //## begin configuration::ConfigurationFactory%390F3EB902E3.public preserve=yes
      //## end configuration::ConfigurationFactory%390F3EB902E3.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConfigurationFactory%390F3EB902E3.protected preserve=yes
      //## end configuration::ConfigurationFactory%390F3EB902E3.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConfigurationFactory%390F3EB902E3.private preserve=yes
      //## end configuration::ConfigurationFactory%390F3EB902E3.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%391050B10065
      //## begin configuration::ConfigurationFactory::Instance%391050B10065.attr preserve=no  private: static ConfigurationFactory* {V} 0
      static ConfigurationFactory* m_pInstance;
      //## end configuration::ConfigurationFactory::Instance%391050B10065.attr

      //## Attribute: ConversionClasses%391867A603E1
      //## begin configuration::ConfigurationFactory::ConversionClasses%391867A603E1.attr preserve=no  private: map<string,int,less<string> > {U} 
      map<string,int,less<string> > m_hConversionClasses;
      //## end configuration::ConfigurationFactory::ConversionClasses%391867A603E1.attr

      //## Attribute: MappingClasses%3ACCDE7902BD
      //## begin configuration::ConfigurationFactory::MappingClasses%3ACCDE7902BD.attr preserve=no  private: map<string,int,less<string> > {U} 
      map<string,int,less<string> > m_hMappingClasses;
      //## end configuration::ConfigurationFactory::MappingClasses%3ACCDE7902BD.attr

      //## Attribute: VerificationClasses%393FBB6B0143
      //## begin configuration::ConfigurationFactory::VerificationClasses%393FBB6B0143.attr preserve=no  private: map<string,int,less<string> > {U} 
      map<string,int,less<string> > m_hVerificationClasses;
      //## end configuration::ConfigurationFactory::VerificationClasses%393FBB6B0143.attr

    // Additional Implementation Declarations
      //## begin configuration::ConfigurationFactory%390F3EB902E3.implementation preserve=yes
      //## end configuration::ConfigurationFactory%390F3EB902E3.implementation

};

//## begin configuration::ConfigurationFactory%390F3EB902E3.postscript preserve=yes
//## end configuration::ConfigurationFactory%390F3EB902E3.postscript

} // namespace configuration

//## begin module%3910504E022F.epilog preserve=yes
using namespace configuration;
//## end module%3910504E022F.epilog


#endif
