//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%391053CD0218.cm preserve=no
//	$Date:   Jan 04 2019 08:46:28  $ $Author:   e1009839  $
//	$Revision:   1.13  $
//## end module%391053CD0218.cm

//## begin module%391053CD0218.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%391053CD0218.cp

//## Module: CXOSCF04%391053CD0218; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF04.cpp

//## begin module%391053CD0218.additionalIncludes preserve=no
//## end module%391053CD0218.additionalIncludes

//## begin module%391053CD0218.includes preserve=yes
// $Date:   Jan 04 2019 08:46:28  $ $Author:   e1009839  $ $Revision:   1.13  $
//## end module%391053CD0218.includes

#ifndef CXOSCF02_h
#include "CXODCF02.hpp"
#endif
#ifndef CXOSRU23_h
#include "CXODRU23.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSMN02_h
#include "CXODMN02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU55_h
#include "CXODRU55.hpp"
#endif
#ifndef CXOSCF03_h
#include "CXODCF03.hpp"
#endif
#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
#ifndef CXOSCF04_h
#include "CXODCF04.hpp"
#endif


//## begin module%391053CD0218.declarations preserve=no
//## end module%391053CD0218.declarations

//## begin module%391053CD0218.additionalDeclarations preserve=yes
#include "CXODCFA2.hpp"
//## end module%391053CD0218.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConversionLoader

//## begin configuration::ConversionLoader::Instance%5C05A4AC0208.attr preserve=no  private: static vector<ConversionLoader*>* {V} 0
vector<ConversionLoader*>* ConversionLoader::m_pInstance = 0;
//## end configuration::ConversionLoader::Instance%5C05A4AC0208.attr

ConversionLoader::ConversionLoader()
  //## begin ConversionLoader::ConversionLoader%3910517602C1_const.hasinit preserve=no
  //## end ConversionLoader::ConversionLoader%3910517602C1_const.hasinit
  //## begin ConversionLoader::ConversionLoader%3910517602C1_const.initialization preserve=yes
  //## end ConversionLoader::ConversionLoader%3910517602C1_const.initialization
{
  //## begin configuration::ConversionLoader::ConversionLoader%3910517602C1_const.body preserve=yes
   memcpy(m_sID,"CF04",4);
  //## end configuration::ConversionLoader::ConversionLoader%3910517602C1_const.body
}


ConversionLoader::~ConversionLoader()
{
  //## begin configuration::ConversionLoader::~ConversionLoader%3910517602C1_dest.body preserve=yes
  //## end configuration::ConversionLoader::~ConversionLoader%3910517602C1_dest.body
}



//## Other Operations (implementation)
ConversionLoader* ConversionLoader::instance ()
{
  //## begin configuration::ConversionLoader::instance%391054230185.body preserve=yes
   if (!m_pInstance)
   {
      m_pInstance = new vector<ConversionLoader*>;
      m_pInstance->reserve(reusable::Thread::getTotal());
      for (int i = 0;i < reusable::Thread::getTotal();++i)
         m_pInstance->push_back(0);
   }
   int i = reusable::Thread::getNumber();
   if (!(*m_pInstance)[i])
      (*m_pInstance)[i] = new ConversionLoader();
   return (*m_pInstance)[i];
  //## end configuration::ConversionLoader::instance%391054230185.body
}

bool ConversionLoader::populate (ConversionTable* pConversionTable)
{
  //## begin configuration::ConversionLoader::populate%3911824503CD.body preserve=yes
   UseCase hUseCase("CR","## CR08 LOAD XLATE TABLE");
   m_pConversionTable = pConversionTable;
   m_pConversionItem = (ConversionItem*)ConfigurationFactory::instance()->createConversionItem(pConversionTable->getTableName().c_str());
   if (m_pConversionItem == 0)
   {
      UseCase::setSuccess(false);
      return false;
   }
   Query hQuery;
   hQuery.setTruncate(false);
   hQuery.attach(this);
   m_pConversionItem->bind(hQuery);
   m_pConversionTable->setMember(m_pConversionItem->getMember());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == false || hQuery.getAbort() == true)
   {
      delete m_pConversionItem;
      return UseCase::setSuccess(false);
   }
   //we have to make sure that the PROBLEM_TRAN table is never empty
   if (m_pConversionTable->getTableName() == "PROBLEM_TRAN" && pSelectStatement->getRows() == 0)
   {
      DummyProblemTran hDummyProblemTran;
      m_pConversionTable->add(&hDummyProblemTran);
   }
   delete m_pConversionItem;
   return true;
  //## end configuration::ConversionLoader::populate%3911824503CD.body
}

void ConversionLoader::update (Subject* pSubject)
{
  //## begin configuration::ConversionLoader::update%391082550004.body preserve=yes
   if(!m_pConversionTable->add(m_pConversionItem))
      ((Query*)pSubject)->setAbort(true);
   else
      UseCase::addItem();
  //## end configuration::ConversionLoader::update%391082550004.body
}

// Additional Declarations
  //## begin configuration::ConversionLoader%3910517602C1.declarations preserve=yes
  //## end configuration::ConversionLoader%3910517602C1.declarations

} // namespace configuration

//## begin module%391053CD0218.epilog preserve=yes
//## end module%391053CD0218.epilog
