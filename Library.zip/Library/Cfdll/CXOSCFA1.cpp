//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%5190FFB402DB.cm preserve=no
//	$Date:   Apr 17 2014 21:11:00  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%5190FFB402DB.cm

//## begin module%5190FFB402DB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5190FFB402DB.cp

//## Module: CXOSCFA1%5190FFB402DB; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCFA1.cpp

//## begin module%5190FFB402DB.additionalIncludes preserve=no
//## end module%5190FFB402DB.additionalIncludes

//## begin module%5190FFB402DB.includes preserve=yes
//## end module%5190FFB402DB.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCFA1_h
#include "CXODCFA1.hpp"
#endif


//## begin module%5190FFB402DB.declarations preserve=no
//## end module%5190FFB402DB.declarations

//## begin module%5190FFB402DB.additionalDeclarations preserve=yes
//## end module%5190FFB402DB.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::DeviceRevAll 

DeviceRevAll::DeviceRevAll()
  //## begin DeviceRevAll::DeviceRevAll%5190FF4602D1_const.hasinit preserve=no
  //## end DeviceRevAll::DeviceRevAll%5190FF4602D1_const.hasinit
  //## begin DeviceRevAll::DeviceRevAll%5190FF4602D1_const.initialization preserve=yes
  : ConversionItem("## CR91 XLATE INST DEVICE ID")
  //## end DeviceRevAll::DeviceRevAll%5190FF4602D1_const.initialization
{
  //## begin configuration::DeviceRevAll::DeviceRevAll%5190FF4602D1_const.body preserve=yes
   memcpy(m_sID,"CFA1",4);
  //## end configuration::DeviceRevAll::DeviceRevAll%5190FF4602D1_const.body
}


DeviceRevAll::~DeviceRevAll()
{
  //## begin configuration::DeviceRevAll::~DeviceRevAll%5190FF4602D1_dest.body preserve=yes
  //## end configuration::DeviceRevAll::~DeviceRevAll%5190FF4602D1_dest.body
}



//## Other Operations (implementation)
void DeviceRevAll::bind (reusable::Query& hQuery)
{
  //## begin configuration::DeviceRevAll::bind%519100A900DF.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","DEVICE");
   hQuery.bind("DEVICE","INST_ID",Column::STRING,&m_strFirst);
   hQuery.bind("DEVICE","DEVICE_ID",Column::STRING,&m_strSecond,0,"MIN");
   hQuery.bind("DEVICE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("DEVICE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("DEVICE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("DEVICE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("DEVICE.INST_ID ASC,DEVICE.CUST_ID DESC");
  //## end configuration::DeviceRevAll::bind%519100A900DF.body
}

// Additional Declarations
  //## begin configuration::DeviceRevAll%5190FF4602D1.declarations preserve=yes
  //## end configuration::DeviceRevAll%5190FF4602D1.declarations

} // namespace configuration

//## begin module%5190FFB402DB.epilog preserve=yes
//## end module%5190FFB402DB.epilog
