//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%394F809D0230.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%394F809D0230.cm

//## begin module%394F809D0230.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%394F809D0230.cp

//## Module: CXOSCF81%394F809D0230; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF81.hpp

#ifndef CXOSCF81_h
#define CXOSCF81_h 1

//## begin module%394F809D0230.additionalIncludes preserve=no
//## end module%394F809D0230.additionalIncludes

//## begin module%394F809D0230.includes preserve=yes
// $Date:   Jan 09 2013 08:27:38  $ $Author:   e3003354  $ $Revision:   1.3  $
//## end module%394F809D0230.includes

#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif
//## begin module%394F809D0230.declarations preserve=no
//## end module%394F809D0230.declarations

//## begin module%394F809D0230.additionalDeclarations preserve=yes
#define EVIDENCE_TRANSLATE_FAILURE             "01"
#define EVIDENCE_VERIFY_FAILURE                "02"
#define EVIDENCE_CHECK_REIMB_FLAG              "03"
#define EVIDENCE_SET_ACT_CODE                  "04"
#define EVIDENCE_PROPOGATE_ACQ_DATA            "05"
#define EVIDENCE_PROPOGATE_ISS_DATA            "06"
#define EVIDENCE_SET_ACCT_TYPES_ISS            "07"
//�08� and �09� are already being used by the disputed authorization process.
#define EVIDENCE_ACT_CODE_TRANSLATE_FAILURE    "10"
#define EVIDENCE_BAD_TSTAMP_TRANS              "11"
//## end module%394F809D0230.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::EvidenceSegment%394F7D850064.preface preserve=yes
//## end configuration::EvidenceSegment%394F7D850064.preface

//## Class: EvidenceSegment%394F7D850064
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport EvidenceSegment : public segment::PersistentSegment  //## Inherits: <unnamed>%394F7D990117
{
  //## begin configuration::EvidenceSegment%394F7D850064.initialDeclarations preserve=yes
  //## end configuration::EvidenceSegment%394F7D850064.initialDeclarations

  public:
    //## Constructors (generated)
      EvidenceSegment();

      EvidenceSegment(const EvidenceSegment &right);

    //## Destructor (generated)
      virtual ~EvidenceSegment();

    //## Assignment Operation (generated)
      EvidenceSegment & operator=(const EvidenceSegment &right);


    //## Other Operations (specified)
      //## Operation: fields%395386EE0248
      virtual struct  Fields* fields () const;

      //## Operation: read%39523CAF0165
      virtual int read (char** ppsBuffer);

      //## Operation: write%39523C990037
      virtual int write (char** ppsBuffer);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: PROBLEM_COLUMN%394F81D300C3
      const string& getPROBLEM_COLUMN () const
      {
        //## begin configuration::EvidenceSegment::getPROBLEM_COLUMN%394F81D300C3.get preserve=no
        return m_strPROBLEM_COLUMN;
        //## end configuration::EvidenceSegment::getPROBLEM_COLUMN%394F81D300C3.get
      }

      void setPROBLEM_COLUMN (const string& value)
      {
        //## begin configuration::EvidenceSegment::setPROBLEM_COLUMN%394F81D300C3.set preserve=no
        m_strPROBLEM_COLUMN = value;
        //## end configuration::EvidenceSegment::setPROBLEM_COLUMN%394F81D300C3.set
      }


      //## Attribute: PROBLEM_TABLE%394F81D70105
      const string& getPROBLEM_TABLE () const
      {
        //## begin configuration::EvidenceSegment::getPROBLEM_TABLE%394F81D70105.get preserve=no
        return m_strPROBLEM_TABLE;
        //## end configuration::EvidenceSegment::getPROBLEM_TABLE%394F81D70105.get
      }

      void setPROBLEM_TABLE (const string& value)
      {
        //## begin configuration::EvidenceSegment::setPROBLEM_TABLE%394F81D70105.set preserve=no
        m_strPROBLEM_TABLE = value;
        //## end configuration::EvidenceSegment::setPROBLEM_TABLE%394F81D70105.set
      }


      //## Attribute: REASON_CODE%394F81D7035E
      const string& getREASON_CODE () const
      {
        //## begin configuration::EvidenceSegment::getREASON_CODE%394F81D7035E.get preserve=no
        return m_strREASON_CODE;
        //## end configuration::EvidenceSegment::getREASON_CODE%394F81D7035E.get
      }

      void setREASON_CODE (const string& value)
      {
        //## begin configuration::EvidenceSegment::setREASON_CODE%394F81D7035E.set preserve=no
        m_strREASON_CODE = value;
        //## end configuration::EvidenceSegment::setREASON_CODE%394F81D7035E.set
      }


      //## Attribute: SOURCE_VALUE%394F81D8005C
      const string& getSOURCE_VALUE () const
      {
        //## begin configuration::EvidenceSegment::getSOURCE_VALUE%394F81D8005C.get preserve=no
        return m_strSOURCE_VALUE;
        //## end configuration::EvidenceSegment::getSOURCE_VALUE%394F81D8005C.get
      }

      void setSOURCE_VALUE (const string& value)
      {
        //## begin configuration::EvidenceSegment::setSOURCE_VALUE%394F81D8005C.set preserve=no
        m_strSOURCE_VALUE = value;
        //## end configuration::EvidenceSegment::setSOURCE_VALUE%394F81D8005C.set
      }


      //## Attribute: SUSPECT_TABLE%394F81D70029
      const string& getSUSPECT_TABLE () const
      {
        //## begin configuration::EvidenceSegment::getSUSPECT_TABLE%394F81D70029.get preserve=no
        return m_strSUSPECT_TABLE;
        //## end configuration::EvidenceSegment::getSUSPECT_TABLE%394F81D70029.get
      }

      void setSUSPECT_TABLE (const string& value)
      {
        //## begin configuration::EvidenceSegment::setSUSPECT_TABLE%394F81D70029.set preserve=no
        m_strSUSPECT_TABLE = value;
        //## end configuration::EvidenceSegment::setSUSPECT_TABLE%394F81D70029.set
      }


      //## Attribute: TSTAMP_INSERTED%394F81D80143
      const string& getTSTAMP_INSERTED () const
      {
        //## begin configuration::EvidenceSegment::getTSTAMP_INSERTED%394F81D80143.get preserve=no
        return m_strTSTAMP_INSERTED;
        //## end configuration::EvidenceSegment::getTSTAMP_INSERTED%394F81D80143.get
      }

      void setTSTAMP_INSERTED (const string& value)
      {
        //## begin configuration::EvidenceSegment::setTSTAMP_INSERTED%394F81D80143.set preserve=no
        m_strTSTAMP_INSERTED = value;
        //## end configuration::EvidenceSegment::setTSTAMP_INSERTED%394F81D80143.set
      }


      //## Attribute: TSTAMP_TRANS%394F7DBA029B
      const string& getTSTAMP_TRANS () const
      {
        //## begin configuration::EvidenceSegment::getTSTAMP_TRANS%394F7DBA029B.get preserve=no
        return m_strTSTAMP_TRANS;
        //## end configuration::EvidenceSegment::getTSTAMP_TRANS%394F7DBA029B.get
      }

      void setTSTAMP_TRANS (const string& value)
      {
        //## begin configuration::EvidenceSegment::setTSTAMP_TRANS%394F7DBA029B.set preserve=no
        m_strTSTAMP_TRANS = value;
        //## end configuration::EvidenceSegment::setTSTAMP_TRANS%394F7DBA029B.set
      }


      //## Attribute: UNIQUENESS_KEY%394F822C036A
      const short& getUNIQUENESS_KEY () const
      {
        //## begin configuration::EvidenceSegment::getUNIQUENESS_KEY%394F822C036A.get preserve=no
        return m_iUNIQUENESS_KEY;
        //## end configuration::EvidenceSegment::getUNIQUENESS_KEY%394F822C036A.get
      }

      void setUNIQUENESS_KEY (const short& value)
      {
        //## begin configuration::EvidenceSegment::setUNIQUENESS_KEY%394F822C036A.set preserve=no
        m_iUNIQUENESS_KEY = value;
        //## end configuration::EvidenceSegment::setUNIQUENESS_KEY%394F822C036A.set
      }


    // Additional Public Declarations
      //## begin configuration::EvidenceSegment%394F7D850064.public preserve=yes
      //## end configuration::EvidenceSegment%394F7D850064.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::EvidenceSegment%394F7D850064.protected preserve=yes
      //## end configuration::EvidenceSegment%394F7D850064.protected

  private:

    //## Other Operations (specified)
      //## Operation: setFields%396A36450388
      void setFields ();

    // Additional Private Declarations
      //## begin configuration::EvidenceSegment%394F7D850064.private preserve=yes
      //## end configuration::EvidenceSegment%394F7D850064.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin configuration::EvidenceSegment::PROBLEM_COLUMN%394F81D300C3.attr preserve=no  public: string {V} 
      string m_strPROBLEM_COLUMN;
      //## end configuration::EvidenceSegment::PROBLEM_COLUMN%394F81D300C3.attr

      //## begin configuration::EvidenceSegment::PROBLEM_TABLE%394F81D70105.attr preserve=no  public: string {V} 
      string m_strPROBLEM_TABLE;
      //## end configuration::EvidenceSegment::PROBLEM_TABLE%394F81D70105.attr

      //## begin configuration::EvidenceSegment::REASON_CODE%394F81D7035E.attr preserve=no  public: string {V} 
      string m_strREASON_CODE;
      //## end configuration::EvidenceSegment::REASON_CODE%394F81D7035E.attr

      //## begin configuration::EvidenceSegment::SOURCE_VALUE%394F81D8005C.attr preserve=no  public: string {V} 
      string m_strSOURCE_VALUE;
      //## end configuration::EvidenceSegment::SOURCE_VALUE%394F81D8005C.attr

      //## begin configuration::EvidenceSegment::SUSPECT_TABLE%394F81D70029.attr preserve=no  public: string {V} 
      string m_strSUSPECT_TABLE;
      //## end configuration::EvidenceSegment::SUSPECT_TABLE%394F81D70029.attr

      //## begin configuration::EvidenceSegment::TSTAMP_INSERTED%394F81D80143.attr preserve=no  public: string {V} 
      string m_strTSTAMP_INSERTED;
      //## end configuration::EvidenceSegment::TSTAMP_INSERTED%394F81D80143.attr

      //## begin configuration::EvidenceSegment::TSTAMP_TRANS%394F7DBA029B.attr preserve=no  public: string {V} 
      string m_strTSTAMP_TRANS;
      //## end configuration::EvidenceSegment::TSTAMP_TRANS%394F7DBA029B.attr

      //## begin configuration::EvidenceSegment::UNIQUENESS_KEY%394F822C036A.attr preserve=no  public: short {V} 0
      short m_iUNIQUENESS_KEY;
      //## end configuration::EvidenceSegment::UNIQUENESS_KEY%394F822C036A.attr

    // Additional Implementation Declarations
      //## begin configuration::EvidenceSegment%394F7D850064.implementation preserve=yes
      //## end configuration::EvidenceSegment%394F7D850064.implementation

};

//## begin configuration::EvidenceSegment%394F7D850064.postscript preserve=yes
//## end configuration::EvidenceSegment%394F7D850064.postscript

} // namespace configuration

//## begin module%394F809D0230.epilog preserve=yes
using namespace configuration;
//## end module%394F809D0230.epilog


#endif
