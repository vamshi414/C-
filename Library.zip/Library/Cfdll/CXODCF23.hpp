//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%391C114F0178.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%391C114F0178.cm

//## begin module%391C114F0178.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%391C114F0178.cp

//## Module: CXOSCF23%391C114F0178; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF23.hpp

#ifndef CXOSCF23_h
#define CXOSCF23_h 1

//## begin module%391C114F0178.additionalIncludes preserve=no
//## end module%391C114F0178.additionalIncludes

//## begin module%391C114F0178.includes preserve=yes
// $Date:   Apr 08 2004 14:10:54  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%391C114F0178.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%391C114F0178.declarations preserve=no
//## end module%391C114F0178.declarations

//## begin module%391C114F0178.additionalDeclarations preserve=yes
//## end module%391C114F0178.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexAdviceReason%391C0CFC036A.preface preserve=yes
//## end configuration::ConnexAdviceReason%391C0CFC036A.preface

//## Class: ConnexAdviceReason%391C0CFC036A
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%391C18AC03D1;IF::Extract { -> F}
//## Uses: <unnamed>%391C18AE02B1;reusable::Query { -> F}

class DllExport ConnexAdviceReason : public ConversionItem  //## Inherits: <unnamed>%391C18AB01C7
{
  //## begin configuration::ConnexAdviceReason%391C0CFC036A.initialDeclarations preserve=yes
  //## end configuration::ConnexAdviceReason%391C0CFC036A.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexAdviceReason();

    //## Destructor (generated)
      virtual ~ConnexAdviceReason();


    //## Other Operations (specified)
      //## Operation: bind%391C1C1C0354
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexAdviceReason%391C0CFC036A.public preserve=yes
      //## end configuration::ConnexAdviceReason%391C0CFC036A.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexAdviceReason%391C0CFC036A.protected preserve=yes
      //## end configuration::ConnexAdviceReason%391C0CFC036A.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexAdviceReason%391C0CFC036A.private preserve=yes
      //## end configuration::ConnexAdviceReason%391C0CFC036A.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexAdviceReason%391C0CFC036A.implementation preserve=yes
      //## end configuration::ConnexAdviceReason%391C0CFC036A.implementation

};

//## begin configuration::ConnexAdviceReason%391C0CFC036A.postscript preserve=yes
//## end configuration::ConnexAdviceReason%391C0CFC036A.postscript

} // namespace configuration

//## begin module%391C114F0178.epilog preserve=yes
using namespace configuration;
//## end module%391C114F0178.epilog


#endif
