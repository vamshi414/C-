//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3ACA368300B9.cm preserve=no
//	$Date:   Jan 04 2019 08:52:46  $ $Author:   e1009839  $
//	$Revision:   1.5  $
//## end module%3ACA368300B9.cm

//## begin module%3ACA368300B9.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3ACA368300B9.cp

//## Module: CXOSCF40%3ACA368300B9; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF40.cpp

//## begin module%3ACA368300B9.additionalIncludes preserve=no
//## end module%3ACA368300B9.additionalIncludes

//## begin module%3ACA368300B9.includes preserve=yes
// $Date:   Jan 04 2019 08:52:46  $ $Author:   e1009839  $ $Revision:   1.5  $
//## end module%3ACA368300B9.includes

#ifndef CXOSCF02_h
#include "CXODCF02.hpp"
#endif
#ifndef CXOSRU23_h
#include "CXODRU23.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSMN02_h
#include "CXODMN02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU55_h
#include "CXODRU55.hpp"
#endif
#ifndef CXOSCF39_h
#include "CXODCF39.hpp"
#endif
#ifndef CXOSCF41_h
#include "CXODCF41.hpp"
#endif
#ifndef CXOSCF40_h
#include "CXODCF40.hpp"
#endif


//## begin module%3ACA368300B9.declarations preserve=no
//## end module%3ACA368300B9.declarations

//## begin module%3ACA368300B9.additionalDeclarations preserve=yes
//## end module%3ACA368300B9.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::MappingLoader

//## begin configuration::MappingLoader::Instance%5C05A55302E2.attr preserve=no  private: static vector<MappingLoader*>* {V} 0
vector<MappingLoader*>* MappingLoader::m_pInstance = 0;
//## end configuration::MappingLoader::Instance%5C05A55302E2.attr

MappingLoader::MappingLoader()
  //## begin MappingLoader::MappingLoader%3ACA357C0292_const.hasinit preserve=no
  //## end MappingLoader::MappingLoader%3ACA357C0292_const.hasinit
  //## begin MappingLoader::MappingLoader%3ACA357C0292_const.initialization preserve=yes
  //## end MappingLoader::MappingLoader%3ACA357C0292_const.initialization
{
  //## begin configuration::MappingLoader::MappingLoader%3ACA357C0292_const.body preserve=yes
    memcpy(m_sID,"CF40",4);
  //## end configuration::MappingLoader::MappingLoader%3ACA357C0292_const.body
}


MappingLoader::~MappingLoader()
{
  //## begin configuration::MappingLoader::~MappingLoader%3ACA357C0292_dest.body preserve=yes
  //## end configuration::MappingLoader::~MappingLoader%3ACA357C0292_dest.body
}



//## Other Operations (implementation)
MappingLoader* MappingLoader::instance ()
{
  //## begin configuration::MappingLoader::instance%3ACA3853012E.body preserve=yes
   if (!m_pInstance)
   {
      m_pInstance = new vector<MappingLoader*>;
      m_pInstance->reserve(reusable::Thread::getTotal());
      for (int i = 0;i < reusable::Thread::getTotal();++i)
         m_pInstance->push_back(0);
   }
   int i = reusable::Thread::getNumber();
  if (!(*m_pInstance)[i])
     (*m_pInstance)[i] = new MappingLoader();
  return (*m_pInstance)[i];
  //## end configuration::MappingLoader::instance%3ACA3853012E.body
}

bool MappingLoader::populate (MappingTable* pMappingTable)
{
  //## begin configuration::MappingLoader::populate%3ACA38710236.body preserve=yes
   UseCase hUseCase("CR","## CR40 LOAD MAPPING TABLE");
   m_pMappingTable = pMappingTable;
   m_pMappingItem = (MappingItem*)ConfigurationFactory::instance()->createMappingItem(pMappingTable->getTableName().c_str());
   if (m_pMappingItem == 0)
   {
      UseCase::setSuccess(false);
      return false;
   }
   Query hQuery;
   hQuery.attach(this);
   m_pMappingItem->bind(hQuery);
   m_pMappingTable->setMember(m_pMappingItem->getMember());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == false)
   {
      UseCase::setSuccess(false);
      delete m_pMappingItem;
      return false;
   }
   delete m_pMappingItem;
   return true;
  //## end configuration::MappingLoader::populate%3ACA38710236.body
}

void MappingLoader::update (Subject* pSubject)
{
  //## begin configuration::MappingLoader::update%3ACA387401A4.body preserve=yes
   m_pMappingTable->add(m_pMappingItem->getPrimary(),m_pMappingItem->getSecondary(),
                        m_pMappingItem->getTertiary(),m_pMappingItem->getResult());
   UseCase::addItem();
  //## end configuration::MappingLoader::update%3ACA387401A4.body
}

// Additional Declarations
  //## begin configuration::MappingLoader%3ACA357C0292.declarations preserve=yes
  //## end configuration::MappingLoader%3ACA357C0292.declarations

} // namespace configuration

//## begin module%3ACA368300B9.epilog preserve=yes
//## end module%3ACA368300B9.epilog
