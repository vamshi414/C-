//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FF1D7B0031C.cm preserve=no
//	$Date:   Dec 16 2016 15:19:00  $ $Author:   e1009652  $
//	$Revision:   1.3  $
//## end module%3FF1D7B0031C.cm

//## begin module%3FF1D7B0031C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FF1D7B0031C.cp

//## Module: CXOSCF49%3FF1D7B0031C; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF49.cpp

//## begin module%3FF1D7B0031C.additionalIncludes preserve=no
//## end module%3FF1D7B0031C.additionalIncludes

//## begin module%3FF1D7B0031C.includes preserve=yes
// $Date:   Dec 16 2016 15:19:00  $ $Author:   e1009652  $ $Revision:   1.3  $
//## end module%3FF1D7B0031C.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF49_h
#include "CXODCF49.hpp"
#endif
//## begin module%3FF1D7B0031C.declarations preserve=no
//## end module%3FF1D7B0031C.declarations

//## begin module%3FF1D7B0031C.additionalDeclarations preserve=yes
//## end module%3FF1D7B0031C.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexPanEntryMode2 

ConnexPanEntryMode2::ConnexPanEntryMode2()
  //## begin ConnexPanEntryMode2::ConnexPanEntryMode2%3FF1D7020251_const.hasinit preserve=no
  //## end ConnexPanEntryMode2::ConnexPanEntryMode2%3FF1D7020251_const.hasinit
  //## begin ConnexPanEntryMode2::ConnexPanEntryMode2%3FF1D7020251_const.initialization preserve=yes
   : ConversionItem("## CR61 XLATE PAN ENTRY2")
  //## end ConnexPanEntryMode2::ConnexPanEntryMode2%3FF1D7020251_const.initialization
{
  //## begin configuration::ConnexPanEntryMode2::ConnexPanEntryMode2%3FF1D7020251_const.body preserve=yes
   memcpy(m_sID,"CF49",4);
  //## end configuration::ConnexPanEntryMode2::ConnexPanEntryMode2%3FF1D7020251_const.body
}


ConnexPanEntryMode2::~ConnexPanEntryMode2()
{
  //## begin configuration::ConnexPanEntryMode2::~ConnexPanEntryMode2%3FF1D7020251_dest.body preserve=yes
  //## end configuration::ConnexPanEntryMode2::~ConnexPanEntryMode2%3FF1D7020251_dest.body
}



//## Other Operations (implementation)
void ConnexPanEntryMode2::bind (Query& hQuery)
{
  //## begin configuration::ConnexPanEntryMode2::bind%3FF1D7860167.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_IBM_PAN_ENTR_MOD");
   hQuery.bind("X_IBM_PAN_ENTR_MOD","PAN_ENTRY_MODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_PAN_ENTR_MOD","POS_CRD_DAT_IN_MOD",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_IBM_PAN_ENTR_MOD","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_PAN_ENTR_MOD","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IBM_PAN_ENTR_MOD.PAN_ENTRY_MODE ASC");
  //## end configuration::ConnexPanEntryMode2::bind%3FF1D7860167.body
}

void ConnexPanEntryMode2::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexPanEntryMode2::setPredicate%584715DC02E4.body preserve=yes
   hQuery.setBasicPredicate("X_IBM_PAN_ENTR_MOD", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IBM_PAN_ENTR_MOD", "CC_STATE", "=", "A");
  //## end configuration::ConnexPanEntryMode2::setPredicate%584715DC02E4.body
}

// Additional Declarations
  //## begin configuration::ConnexPanEntryMode2%3FF1D7020251.declarations preserve=yes
  //## end configuration::ConnexPanEntryMode2%3FF1D7020251.declarations

} // namespace configuration

//## begin module%3FF1D7B0031C.epilog preserve=yes
//## end module%3FF1D7B0031C.epilog
