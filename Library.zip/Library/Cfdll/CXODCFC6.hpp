//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%62211A9B0325.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%62211A9B0325.cm

//## begin module%62211A9B0325.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%62211A9B0325.cp

//## Module: CXOSCFC6%62211A9B0325; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCFC6.hpp

#ifndef CXOSCFC6_h
#define CXOSCFC6_h 1

//## begin module%62211A9B0325.additionalIncludes preserve=no
//## end module%62211A9B0325.additionalIncludes

//## begin module%62211A9B0325.includes preserve=yes
//## end module%62211A9B0325.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%62211A9B0325.declarations preserve=no
//## end module%62211A9B0325.declarations

//## begin module%62211A9B0325.additionalDeclarations preserve=yes
//## end module%62211A9B0325.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::InstitutionCalendar%622116B00278.preface preserve=yes
//## end configuration::InstitutionCalendar%622116B00278.preface

//## Class: InstitutionCalendar%622116B00278
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6221197101BE;IF::Extract { -> F}
//## Uses: <unnamed>%6221199A0133;reusable::Query { -> F}

class DllExport InstitutionCalendar : public ConversionItem  //## Inherits: <unnamed>%6221196201E1
{
  //## begin configuration::InstitutionCalendar%622116B00278.initialDeclarations preserve=yes
  //## end configuration::InstitutionCalendar%622116B00278.initialDeclarations

  public:
    //## Constructors (generated)
      InstitutionCalendar();

    //## Destructor (generated)
      virtual ~InstitutionCalendar();


    //## Other Operations (specified)
      //## Operation: bind%6221193C0352
      void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::InstitutionCalendar%622116B00278.public preserve=yes
      //## end configuration::InstitutionCalendar%622116B00278.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::InstitutionCalendar%622116B00278.protected preserve=yes
      //## end configuration::InstitutionCalendar%622116B00278.protected

  private:
    // Additional Private Declarations
      //## begin configuration::InstitutionCalendar%622116B00278.private preserve=yes
      //## end configuration::InstitutionCalendar%622116B00278.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::InstitutionCalendar%622116B00278.implementation preserve=yes
      //## end configuration::InstitutionCalendar%622116B00278.implementation

};

//## begin configuration::InstitutionCalendar%622116B00278.postscript preserve=yes
//## end configuration::InstitutionCalendar%622116B00278.postscript

} // namespace configuration

//## begin module%62211A9B0325.epilog preserve=yes
//## end module%62211A9B0325.epilog


#endif
