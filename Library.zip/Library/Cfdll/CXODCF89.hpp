//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4565454503B9.cm preserve=no
//	$Date:   Apr 03 2007 09:22:52  $ $Author:   D92233  $
//	$Revision:   1.3  $
//## end module%4565454503B9.cm

//## begin module%4565454503B9.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%4565454503B9.cp

//## Module: CXOSCF89%4565454503B9; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF89.hpp

#ifndef CXOSCF89_h
#define CXOSCF89_h 1

//## begin module%4565454503B9.additionalIncludes preserve=no
//## end module%4565454503B9.additionalIncludes

//## begin module%4565454503B9.includes preserve=yes
//## end module%4565454503B9.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%4565454503B9.declarations preserve=no
//## end module%4565454503B9.declarations

//## begin module%4565454503B9.additionalDeclarations preserve=yes
//## end module%4565454503B9.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::NACHAReturnCode%456544E20167.preface preserve=yes
//## end configuration::NACHAReturnCode%456544E20167.preface

//## Class: NACHAReturnCode%456544E20167
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%456544FC0157;IF::Extract { -> F}
//## Uses: <unnamed>%456544FF0119;reusable::Query { -> F}

class DllExport NACHAReturnCode : public ConversionItem  //## Inherits: <unnamed>%456544F60290
{
  //## begin configuration::NACHAReturnCode%456544E20167.initialDeclarations preserve=yes
  //## end configuration::NACHAReturnCode%456544E20167.initialDeclarations

  public:
    //## Constructors (generated)
      NACHAReturnCode();

    //## Destructor (generated)
      virtual ~NACHAReturnCode();


    //## Other Operations (specified)
      //## Operation: bind%45654512001F
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getSecond%45F56F3E03C8
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::NACHAReturnCode%456544E20167.public preserve=yes
      //## end configuration::NACHAReturnCode%456544E20167.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::NACHAReturnCode%456544E20167.protected preserve=yes
      //## end configuration::NACHAReturnCode%456544E20167.protected

  private:
    // Additional Private Declarations
      //## begin configuration::NACHAReturnCode%456544E20167.private preserve=yes
      //## end configuration::NACHAReturnCode%456544E20167.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ACTION_CODE%45F56F540242
      //## begin configuration::NACHAReturnCode::ACTION_CODE%45F56F540242.attr preserve=no  private: string {U} 
      string m_strACTION_CODE;
      //## end configuration::NACHAReturnCode::ACTION_CODE%45F56F540242.attr

      //## Attribute: TRAN_DESC_CODE%45F56F5E003E
      //## begin configuration::NACHAReturnCode::TRAN_DESC_CODE%45F56F5E003E.attr preserve=no  private: string {U} 
      string m_strTRAN_DESC_CODE;
      //## end configuration::NACHAReturnCode::TRAN_DESC_CODE%45F56F5E003E.attr

    // Additional Implementation Declarations
      //## begin configuration::NACHAReturnCode%456544E20167.implementation preserve=yes
      //## end configuration::NACHAReturnCode%456544E20167.implementation

};

//## begin configuration::NACHAReturnCode%456544E20167.postscript preserve=yes
//## end configuration::NACHAReturnCode%456544E20167.postscript

} // namespace configuration

//## begin module%4565454503B9.epilog preserve=yes
//## end module%4565454503B9.epilog


#endif
