//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFC71A1006D.cm preserve=no
//	$Date:   Dec 12 2016 13:08:10  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%3FFC71A1006D.cm

//## begin module%3FFC71A1006D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFC71A1006D.cp

//## Module: CXOSCF54%3FFC71A1006D; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF54.hpp

#ifndef CXOSCF54_h
#define CXOSCF54_h 1

//## begin module%3FFC71A1006D.additionalIncludes preserve=no
//## end module%3FFC71A1006D.additionalIncludes

//## begin module%3FFC71A1006D.includes preserve=yes
// $Date:   Dec 12 2016 13:08:10  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%3FFC71A1006D.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
//## begin module%3FFC71A1006D.declarations preserve=no
//## end module%3FFC71A1006D.declarations

//## begin module%3FFC71A1006D.additionalDeclarations preserve=yes
//## end module%3FFC71A1006D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexPOSConditionCode5%3FFC70EB00DA.preface preserve=yes
//## end configuration::ConnexPOSConditionCode5%3FFC70EB00DA.preface

//## Class: ConnexPOSConditionCode5%3FFC70EB00DA
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FFC713101C5;reusable::Query { -> F}

class DllExport ConnexPOSConditionCode5 : public ConversionItem  //## Inherits: <unnamed>%3FFC7122038A
{
  //## begin configuration::ConnexPOSConditionCode5%3FFC70EB00DA.initialDeclarations preserve=yes
  //## end configuration::ConnexPOSConditionCode5%3FFC70EB00DA.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexPOSConditionCode5();

    //## Destructor (generated)
      virtual ~ConnexPOSConditionCode5();


    //## Other Operations (specified)
      //## Operation: bind%3FFC710F0148
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%5847163D03CE
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexPOSConditionCode5%3FFC70EB00DA.public preserve=yes
      //## end configuration::ConnexPOSConditionCode5%3FFC70EB00DA.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexPOSConditionCode5%3FFC70EB00DA.protected preserve=yes
      //## end configuration::ConnexPOSConditionCode5%3FFC70EB00DA.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexPOSConditionCode5%3FFC70EB00DA.private preserve=yes
      //## end configuration::ConnexPOSConditionCode5%3FFC70EB00DA.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexPOSConditionCode5%3FFC70EB00DA.implementation preserve=yes
      //## end configuration::ConnexPOSConditionCode5%3FFC70EB00DA.implementation

};

//## begin configuration::ConnexPOSConditionCode5%3FFC70EB00DA.postscript preserve=yes
//## end configuration::ConnexPOSConditionCode5%3FFC70EB00DA.postscript

} // namespace configuration

//## begin module%3FFC71A1006D.epilog preserve=yes
using namespace configuration;
//## end module%3FFC71A1006D.epilog


#endif
