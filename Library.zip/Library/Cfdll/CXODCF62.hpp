//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4092C22C03D8.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%4092C22C03D8.cm

//## begin module%4092C22C03D8.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%4092C22C03D8.cp

//## Module: CXOSCF62%4092C22C03D8; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF62.hpp

#ifndef CXOSCF62_h
#define CXOSCF62_h 1

//## begin module%4092C22C03D8.additionalIncludes preserve=no
//## end module%4092C22C03D8.additionalIncludes

//## begin module%4092C22C03D8.includes preserve=yes
// $Date:   Jun 11 2004 11:49:18  $ $Author:   D92233  $ $Revision:   1.1  $
//## end module%4092C22C03D8.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%4092C22C03D8.declarations preserve=no
//## end module%4092C22C03D8.declarations

//## begin module%4092C22C03D8.additionalDeclarations preserve=yes
//## end module%4092C22C03D8.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::OasisProcessCode%4092BE1C03A9.preface preserve=yes
//## end configuration::OasisProcessCode%4092BE1C03A9.preface

//## Class: OasisProcessCode%4092BE1C03A9
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4092BF1A01D4;reusable::Query { -> F}
//## Uses: <unnamed>%4092BF2601A5;IF::Extract { -> F}

class DllExport OasisProcessCode : public ConversionItem  //## Inherits: <unnamed>%4092BF0402AF
{
  //## begin configuration::OasisProcessCode%4092BE1C03A9.initialDeclarations preserve=yes
  //## end configuration::OasisProcessCode%4092BE1C03A9.initialDeclarations

  public:
    //## Constructors (generated)
      OasisProcessCode();

    //## Destructor (generated)
      virtual ~OasisProcessCode();


    //## Other Operations (specified)
      //## Operation: bind%4092BF5A00AB
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>MS
      //	<h3>Oasis Process Code
      //	<p>
      //	The X_OASIS_PROC_CODE table is used to determine a value
      //	for the transaction type ID  (FIN_L<i>yyyymm</i>.TRAN_
      //	TYPE_ID) in the financial transaction.
      //	<p>
      //	Use the CR Client to add or update rows whenever there
      //	is a new value in the following field:
      //	<ul>
      //	<li>OASIS_PROCESS_CODE
      //	</ul>
      //	Oasis Process Codes are in the Parameter Tables folder
      //	in the CR Client for the DataNavigator Server.
      //	</body>
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getFirst%4092BF5E005D
      virtual const string& getFirst ();

      //## Operation: getSecond%4092BF6301C5
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::OasisProcessCode%4092BE1C03A9.public preserve=yes
      //## end configuration::OasisProcessCode%4092BE1C03A9.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::OasisProcessCode%4092BE1C03A9.protected preserve=yes
      //## end configuration::OasisProcessCode%4092BE1C03A9.protected

  private:
    // Additional Private Declarations
      //## begin configuration::OasisProcessCode%4092BE1C03A9.private preserve=yes
      //## end configuration::OasisProcessCode%4092BE1C03A9.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: OASIS_PROCESS_CODE%4092C1C402CE
      //## begin configuration::OasisProcessCode::OASIS_PROCESS_CODE%4092C1C402CE.attr preserve=no  private: string {U} 
      string m_strOASIS_PROCESS_CODE;
      //## end configuration::OasisProcessCode::OASIS_PROCESS_CODE%4092C1C402CE.attr

      //## Attribute: PROCESS_CODE%4092C1CA02FD
      //## begin configuration::OasisProcessCode::PROCESS_CODE%4092C1CA02FD.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::OasisProcessCode::PROCESS_CODE%4092C1CA02FD.attr

      //## Attribute: MSG_CLASS%4092C1CF00FA
      //## begin configuration::OasisProcessCode::MSG_CLASS%4092C1CF00FA.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::OasisProcessCode::MSG_CLASS%4092C1CF00FA.attr

      //## Attribute: PRE_AUTH%4092C1D300DA
      //## begin configuration::OasisProcessCode::PRE_AUTH%4092C1D300DA.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::OasisProcessCode::PRE_AUTH%4092C1D300DA.attr

      //## Attribute: MEDIA_TYPE%4092C1D7009C
      //## begin configuration::OasisProcessCode::MEDIA_TYPE%4092C1D7009C.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::OasisProcessCode::MEDIA_TYPE%4092C1D7009C.attr

    // Additional Implementation Declarations
      //## begin configuration::OasisProcessCode%4092BE1C03A9.implementation preserve=yes
      //## end configuration::OasisProcessCode%4092BE1C03A9.implementation

};

//## begin configuration::OasisProcessCode%4092BE1C03A9.postscript preserve=yes
//## end configuration::OasisProcessCode%4092BE1C03A9.postscript

} // namespace configuration

//## begin module%4092C22C03D8.epilog preserve=yes
using namespace configuration;
//## end module%4092C22C03D8.epilog


#endif
