//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%390F38530251.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%390F38530251.cm

//## begin module%390F38530251.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%390F38530251.cp

//## Module: CXOSCF01%390F38530251; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXODCF01.hpp

#ifndef CXOSCF01_h
#define CXOSCF01_h 1

//## begin module%390F38530251.additionalIncludes preserve=no
//## end module%390F38530251.additionalIncludes

//## begin module%390F38530251.includes preserve=yes
// $Date:   Jan 29 2020 04:48:06  $ $Author:   e1014059  $ $Revision:   1.26  $
#include <map>
//## end module%390F38530251.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConversionLoader;
class ConfigurationFactory;
class MappingLoader;
class MappingTable;
class VerificationTable;
class VerificationLoader;
class ConversionTable;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Global;
class Thread;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ListSegment;

} // namespace segment

//## begin module%390F38530251.declarations preserve=no
//## end module%390F38530251.declarations

//## begin module%390F38530251.additionalDeclarations preserve=yes
//## end module%390F38530251.additionalDeclarations


namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConfigurationRepository%390F35570299.preface preserve=yes
//## end configuration::ConfigurationRepository%390F35570299.preface

//## Class: ConfigurationRepository%390F35570299
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3911B50B0125;ConversionLoader { -> F}
//## Uses: <unnamed>%39171FB803C0;reusable::Global { -> F}
//## Uses: <unnamed>%393E72A702EF;VerificationLoader { -> F}
//## Uses: <unnamed>%395218E10133;IF::Trace { -> F}
//## Uses: <unnamed>%3952362E0125;segment::ListSegment { -> F}
//## Uses: <unnamed>%3965F82900CE;timer::Clock { -> F}
//## Uses: <unnamed>%3ACCB4AE0010;MappingLoader { -> F}
//## Uses: <unnamed>%3FDDCBB4032C;ConfigurationFactory { -> F}
//## Uses: <unnamed>%5BF92DD300E8;reusable::Thread { -> F}

class DllExport ConfigurationRepository : public reusable::Observer  //## Inherits: <unnamed>%390F35810249
{
  //## begin configuration::ConfigurationRepository%390F35570299.initialDeclarations preserve=yes
  //## end configuration::ConfigurationRepository%390F35570299.initialDeclarations

  public:
    //## Constructors (generated)
      ConfigurationRepository();

    //## Destructor (generated)
      virtual ~ConfigurationRepository();


    //## Other Operations (specified)
      //## Operation: addEvidenceSegment%4ACB8A880145
      void addEvidenceSegment (const EvidenceSegment& hEvidenceSegment);

      //## Operation: getCRBook%3FDDCA2A0222
      bool getCRBook (const char* pszTable, string& strCRBook);

      //## Operation: getEvidenceSegment%3960A57D0052
      EvidenceSegment& getEvidenceSegment ();

      //## Operation: instance%3910494A0150
      static ConfigurationRepository* instance ();

      //## Operation: isSubscriber%3E0706A7032C
      string& isSubscriber (string strAcqValue, string strIssValue = "", char cAcqLevel = 'I', char cIssLevel = 'I');

      //## Operation: loadTable%3E070B0100FA
      configuration::ConversionTable* loadTable (const char* pszTable);

      //## Operation: mapItem%3ACCB66C017A
      bool mapItem (const char* pszTable, const string& strPrimaryKey, const string& strTertiaryKey, const string& strSecondaryKey, string& strResult);

      //## Operation: reset%3919A57802DB
      void reset (const char* pszTable = 0);

      //## Operation: reset%6238C9690229
      void reset (map<string,ConversionTable*,less<string> >::iterator& pConversionTable, const char* pszTable);

      //## Operation: reset%6238CBAC0212
      void reset (map<string,MappingTable*,less<string> >::iterator& pMappingTable, const char* pszTable);

      //## Operation: reset%6238CA2501CE
      void reset (map<string,VerificationTable*,less<string> >::iterator& pVerificationTable, const char* pszTable);

      //## Operation: translate%390F372E008D
      bool translate (const char* pszTable, const string& strFirst, string& strSecond, const string& strPROBLEM_TABLE, const string& strPROBLEM_COLUMN, int iVersion = -1, bool bEvidence = true);

      //## Operation: update%393FB5A0030D
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

      //## Operation: verify%393E74270374
      bool verify (const char* pszTable, const string& strKey, int iVersion = -1);

      //## Operation: write%3950D5EB023C
      void write (char** ppsBuffer, const string& strTSTAMP_TRANS, const short iUNIQUENESS_KEY);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Evidence%3950D731008C
      void setEvidence (const bool& value)
      {
        //## begin configuration::ConfigurationRepository::setEvidence%3950D731008C.set preserve=no
        m_bEvidence = value;
        //## end configuration::ConfigurationRepository::setEvidence%3950D731008C.set
      }


      //## Attribute: LoadFailure%3EF360970399
      const bool& loadFailure () const
      {
        //## begin configuration::ConfigurationRepository::loadFailure%3EF360970399.get preserve=no
        return m_bLoadFailure;
        //## end configuration::ConfigurationRepository::loadFailure%3EF360970399.get
      }

      void setLoadFailure (const bool& value)
      {
        //## begin configuration::ConfigurationRepository::setLoadFailure%3EF360970399.set preserve=no
        m_bLoadFailure = value;
        //## end configuration::ConfigurationRepository::setLoadFailure%3EF360970399.set
      }


      //## Attribute: SUBSCRIBER_IND%3EC3C8DA029F
      const string& getSUBSCRIBER_IND () const
      {
        //## begin configuration::ConfigurationRepository::getSUBSCRIBER_IND%3EC3C8DA029F.get preserve=no
        return m_strSUBSCRIBER_IND;
        //## end configuration::ConfigurationRepository::getSUBSCRIBER_IND%3EC3C8DA029F.get
      }


      //## Attribute: Third%44B4F722003E
      const string& getThird () const
      {
        //## begin configuration::ConfigurationRepository::getThird%44B4F722003E.get preserve=no
        return m_strThird;
        //## end configuration::ConfigurationRepository::getThird%44B4F722003E.get
      }


    // Additional Public Declarations
      //## begin configuration::ConfigurationRepository%390F35570299.public preserve=yes
      //## end configuration::ConfigurationRepository%390F35570299.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConfigurationRepository%390F35570299.protected preserve=yes
      //## end configuration::ConfigurationRepository%390F35570299.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConfigurationRepository%390F35570299.private preserve=yes
      //## end configuration::ConfigurationRepository%390F35570299.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin configuration::ConfigurationRepository::Evidence%3950D731008C.attr preserve=no  public: bool {U} true
      bool m_bEvidence;
      //## end configuration::ConfigurationRepository::Evidence%3950D731008C.attr

      //## Attribute: Instance%5C05A2B70232
      //## begin configuration::ConfigurationRepository::Instance%5C05A2B70232.attr preserve=no  private: static vector<ConfigurationRepository*>* {V} 0
      static vector<ConfigurationRepository*>* m_pInstance;
      //## end configuration::ConfigurationRepository::Instance%5C05A2B70232.attr

      //## begin configuration::ConfigurationRepository::LoadFailure%3EF360970399.attr preserve=no  public: bool {U} false
      bool m_bLoadFailure;
      //## end configuration::ConfigurationRepository::LoadFailure%3EF360970399.attr

      //## begin configuration::ConfigurationRepository::SUBSCRIBER_IND%3EC3C8DA029F.attr preserve=no  public: string {U} 
      string m_strSUBSCRIBER_IND;
      //## end configuration::ConfigurationRepository::SUBSCRIBER_IND%3EC3C8DA029F.attr

      //## begin configuration::ConfigurationRepository::Third%44B4F722003E.attr preserve=no  public: string {U} 
      string m_strThird;
      //## end configuration::ConfigurationRepository::Third%44B4F722003E.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Configuration_CAT::<unnamed>%390F3F4702D3
      //## Role: ConfigurationRepository::<m_hConversionTable>%390F3F4802D4
      //## Qualifier: Name%39102FBB0332; string
      //## begin configuration::ConfigurationRepository::<m_hConversionTable>%390F3F4802D4.role preserve=no  public: configuration::ConversionTable { -> RFHgN}
      map<string, ConversionTable *, less<string> > m_hConversionTable;
      //## end configuration::ConfigurationRepository::<m_hConversionTable>%390F3F4802D4.role

      //## Association: DataNavigator Foundation::Configuration_CAT::<unnamed>%393E727D0032
      //## Role: ConfigurationRepository::<m_hVerificationTable>%393E727D02B3
      //## Qualifier: Name%393E72850264; string
      //## begin configuration::ConfigurationRepository::<m_hVerificationTable>%393E727D02B3.role preserve=no  public: configuration::VerificationTable { -> RFHgN}
      map<string, VerificationTable *, less<string> > m_hVerificationTable;
      //## end configuration::ConfigurationRepository::<m_hVerificationTable>%393E727D02B3.role

      //## Association: DataNavigator Foundation::Configuration_CAT::<unnamed>%3952190703CD
      //## Role: ConfigurationRepository::<m_hEvidenceSegment>%3952190801A7
      //## begin configuration::ConfigurationRepository::<m_hEvidenceSegment>%3952190801A7.role preserve=no  public: configuration::EvidenceSegment {1 -> 0..nVHgN}
      vector<EvidenceSegment> m_hEvidenceSegment;
      //## end configuration::ConfigurationRepository::<m_hEvidenceSegment>%3952190801A7.role

      //## Association: DataNavigator Foundation::Configuration_CAT::<unnamed>%3ACCB4DF00C5
      //## Role: ConfigurationRepository::<m_hMappingTable>%3ACCB4E00076
      //## Qualifier: Name%3ACCB52A025D; string
      //## begin configuration::ConfigurationRepository::<m_hMappingTable>%3ACCB4E00076.role preserve=no  public: configuration::MappingTable { -> RFHgN}
      map<string, MappingTable *, less<string> > m_hMappingTable;
      //## end configuration::ConfigurationRepository::<m_hMappingTable>%3ACCB4E00076.role

    // Additional Implementation Declarations
      //## begin configuration::ConfigurationRepository%390F35570299.implementation preserve=yes
      //## end configuration::ConfigurationRepository%390F35570299.implementation

};

//## begin configuration::ConfigurationRepository%390F35570299.postscript preserve=yes
//## end configuration::ConfigurationRepository%390F35570299.postscript

} // namespace configuration

//## begin module%390F38530251.epilog preserve=yes
using namespace configuration;
//## end module%390F38530251.epilog


#endif
