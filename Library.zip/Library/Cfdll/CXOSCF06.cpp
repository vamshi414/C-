//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3917317C03C0.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%3917317C03C0.cm

//## begin module%3917317C03C0.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%3917317C03C0.cp

//## Module: CXOSCF06%3917317C03C0; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF06.cpp

//## begin module%3917317C03C0.additionalIncludes preserve=no
//## end module%3917317C03C0.additionalIncludes

//## begin module%3917317C03C0.includes preserve=yes
// $Date:   Apr 17 2014 20:59:16  $ $Author:   e1009652  $ $Revision:   1.8  $
//## end module%3917317C03C0.includes

#ifndef CXOSCF06_h
#include "CXODCF06.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%3917317C03C0.declarations preserve=no
//## end module%3917317C03C0.declarations

//## begin module%3917317C03C0.additionalDeclarations preserve=yes
//## end module%3917317C03C0.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::AdvantageCardLogo

AdvantageCardLogo::AdvantageCardLogo()
  //## begin AdvantageCardLogo::AdvantageCardLogo%3912F08603CF_const.hasinit preserve=no
  //## end AdvantageCardLogo::AdvantageCardLogo%3912F08603CF_const.hasinit
  //## begin AdvantageCardLogo::AdvantageCardLogo%3912F08603CF_const.initialization preserve=yes
   : ConversionItem("## CR09 XLATE CARD OWNER")
  //## end AdvantageCardLogo::AdvantageCardLogo%3912F08603CF_const.initialization
{
  //## begin configuration::AdvantageCardLogo::AdvantageCardLogo%3912F08603CF_const.body preserve=yes
   memcpy(m_sID,"CF06",4);
  //## end configuration::AdvantageCardLogo::AdvantageCardLogo%3912F08603CF_const.body
}


AdvantageCardLogo::~AdvantageCardLogo()
{
  //## begin configuration::AdvantageCardLogo::~AdvantageCardLogo%3912F08603CF_dest.body preserve=yes
  //## end configuration::AdvantageCardLogo::~AdvantageCardLogo%3912F08603CF_dest.body
}



//## Other Operations (implementation)
void AdvantageCardLogo::bind (Query& hQuery)
{
  //## begin configuration::AdvantageCardLogo::bind%3912F52A0387.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_ADV_CARD_LOGO");
   hQuery.bind("X_ADV_CARD_LOGO","ADVG_CARD_LOGO",Column::STRING,&m_strFirst);
   hQuery.bind("X_ADV_CARD_LOGO","CARD_OWNER_TYPE",Column::STRING,&m_strSecond);
   hQuery.bind("X_ADV_CARD_LOGO","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_ADV_CARD_LOGO","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_ADV_CARD_LOGO","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_ADV_CARD_LOGO","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_ADV_CARD_LOGO.ADVG_CARD_LOGO ASC,X_ADV_CARD_LOGO.CUST_ID DESC");
  //## end configuration::AdvantageCardLogo::bind%3912F52A0387.body
}

// Additional Declarations
  //## begin configuration::AdvantageCardLogo%3912F08603CF.declarations preserve=yes
  //## end configuration::AdvantageCardLogo%3912F08603CF.declarations

} // namespace configuration

//## begin module%3917317C03C0.epilog preserve=yes
//## end module%3917317C03C0.epilog
