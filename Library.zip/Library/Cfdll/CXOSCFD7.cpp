//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%664032B002B9.cm preserve=no
//## end module%664032B002B9.cm

//## begin module%664032B002B9.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%664032B002B9.cp

//## Module: CXOSCFD7%664032B002B9; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFD7.cpp

//## begin module%664032B002B9.additionalIncludes preserve=no
//## end module%664032B002B9.additionalIncludes

//## begin module%664032B002B9.includes preserve=yes
//## end module%664032B002B9.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFD7_h
#include "CXODCFD7.hpp"
#endif


//## begin module%664032B002B9.declarations preserve=no
//## end module%664032B002B9.declarations

//## begin module%664032B002B9.additionalDeclarations preserve=yes
//## end module%664032B002B9.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ShazamProcessCode 

ShazamProcessCode::ShazamProcessCode()
  //## begin ShazamProcessCode::ShazamProcessCode%664032080313_const.hasinit preserve=no
  //## end ShazamProcessCode::ShazamProcessCode%664032080313_const.hasinit
  //## begin ShazamProcessCode::ShazamProcessCode%664032080313_const.initialization preserve=yes
   : ConversionItem("## CFD7 XLATE SHAZAM PROCESS CODE")
  //## end ShazamProcessCode::ShazamProcessCode%664032080313_const.initialization
{
  //## begin configuration::ShazamProcessCode::ShazamProcessCode%664032080313_const.body preserve=yes
   memcpy(m_sID, "CFD7", 4);
  //## end configuration::ShazamProcessCode::ShazamProcessCode%664032080313_const.body
}


ShazamProcessCode::~ShazamProcessCode()
{
  //## begin configuration::ShazamProcessCode::~ShazamProcessCode%664032080313_dest.body preserve=yes
  //## end configuration::ShazamProcessCode::~ShazamProcessCode%664032080313_dest.body
}



//## Other Operations (implementation)
void ShazamProcessCode::bind (Query& hQuery)
{
  //## begin configuration::ShazamProcessCode::bind%6640323400A9.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY", "X_SHZ_PROC_CODE");
   hQuery.bind("X_SHZ_PROC_CODE", "SHZ_PROCESS_CODE", Column::STRING, &m_strFirst);
   hQuery.bind("X_SHZ_PROC_CODE", "PROCESS_CODE", Column::STRING, &m_strPROCESS_CODE);
   hQuery.bind("X_SHZ_PROC_CODE", "MSG_CLASS", Column::STRING, &m_strMSG_CLASS);
   hQuery.bind("X_SHZ_PROC_CODE", "PRE_AUTH", Column::STRING, &m_strPRE_AUTH);
   hQuery.bind("X_SHZ_PROC_CODE", "MEDIA_TYPE", Column::STRING, &m_strMEDIA_TYPE);
   hQuery.bind("X_SHZ_PROC_CODE", "CUST_ID", Column::STRING, &m_strCUST_ID);
   hQuery.setBasicPredicate("X_SHZ_PROC_CODE", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_SHZ_PROC_CODE", "CC_STATE", "=", "A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_SHZ_PROC_CODE", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("X_SHZ_PROC_CODE.SHZ_PROCESS_CODE ASC,X_SHZ_PROC_CODE.CUST_ID DESC");
  //## end configuration::ShazamProcessCode::bind%6640323400A9.body
}

const string& ShazamProcessCode::getSecond ()
{
  //## begin configuration::ShazamProcessCode::getSecond%664032380025.body preserve=yes
   m_strPROCESS_CODE.resize(6, ' ');
   m_strMSG_CLASS.resize(1, ' ');
   m_strPRE_AUTH.resize(1, ' ');
   m_strMEDIA_TYPE.resize(2, ' ');
   m_strSecond = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strSecond;
  //## end configuration::ShazamProcessCode::getSecond%664032380025.body
}

// Additional Declarations
  //## begin configuration::ShazamProcessCode%664032080313.declarations preserve=yes
  //## end configuration::ShazamProcessCode%664032080313.declarations

} // namespace configuration

//## begin module%664032B002B9.epilog preserve=yes
//## end module%664032B002B9.epilog
