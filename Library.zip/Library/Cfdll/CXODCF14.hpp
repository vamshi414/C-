//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%391C10E600C2.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%391C10E600C2.cm

//## begin module%391C10E600C2.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%391C10E600C2.cp

//## Module: CXOSCF14%391C10E600C2; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF14.hpp

#ifndef CXOSCF14_h
#define CXOSCF14_h 1

//## begin module%391C10E600C2.additionalIncludes preserve=no
//## end module%391C10E600C2.additionalIncludes

//## begin module%391C10E600C2.includes preserve=yes
// $Date:   Apr 08 2004 14:10:50  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%391C10E600C2.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%391C10E600C2.declarations preserve=no
//## end module%391C10E600C2.declarations

//## begin module%391C10E600C2.additionalDeclarations preserve=yes
//## end module%391C10E600C2.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::CirrusAdjustmentReason%391C0C76008D.preface preserve=yes
//## end configuration::CirrusAdjustmentReason%391C0C76008D.preface

//## Class: CirrusAdjustmentReason%391C0C76008D
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%391C16860113;IF::Extract { -> F}
//## Uses: <unnamed>%391C168800C6;reusable::Query { -> F}

class DllExport CirrusAdjustmentReason : public ConversionItem  //## Inherits: <unnamed>%391C168400D4
{
  //## begin configuration::CirrusAdjustmentReason%391C0C76008D.initialDeclarations preserve=yes
  //## end configuration::CirrusAdjustmentReason%391C0C76008D.initialDeclarations

  public:
    //## Constructors (generated)
      CirrusAdjustmentReason();

    //## Destructor (generated)
      virtual ~CirrusAdjustmentReason();


    //## Other Operations (specified)
      //## Operation: bind%391C1BE103BD
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::CirrusAdjustmentReason%391C0C76008D.public preserve=yes
      //## end configuration::CirrusAdjustmentReason%391C0C76008D.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::CirrusAdjustmentReason%391C0C76008D.protected preserve=yes
      //## end configuration::CirrusAdjustmentReason%391C0C76008D.protected

  private:
    // Additional Private Declarations
      //## begin configuration::CirrusAdjustmentReason%391C0C76008D.private preserve=yes
      //## end configuration::CirrusAdjustmentReason%391C0C76008D.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::CirrusAdjustmentReason%391C0C76008D.implementation preserve=yes
      //## end configuration::CirrusAdjustmentReason%391C0C76008D.implementation

};

//## begin configuration::CirrusAdjustmentReason%391C0C76008D.postscript preserve=yes
//## end configuration::CirrusAdjustmentReason%391C0C76008D.postscript

} // namespace configuration

//## begin module%391C10E600C2.epilog preserve=yes
using namespace configuration;
//## end module%391C10E600C2.epilog


#endif
