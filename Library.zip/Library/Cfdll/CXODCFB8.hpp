//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5FC5DFDB016C.cm preserve=no
//	$Date:   Sep 06 2021 04:45:28  $ $Author:   e3028298  $
//	$Revision:   1.1  $
//## end module%5FC5DFDB016C.cm

//## begin module%5FC5DFDB016C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5FC5DFDB016C.cp

//## Module: CXOSCFB8%5FC5DFDB016C; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Devel\V03.2A.R003\Dn\Server\Library\Cfdll\CXODCFB8.hpp

#ifndef CXOSCFB8_h
#define CXOSCFB8_h 1

//## begin module%5FC5DFDB016C.additionalIncludes preserve=no
//## end module%5FC5DFDB016C.additionalIncludes

//## begin module%5FC5DFDB016C.includes preserve=yes
//## end module%5FC5DFDB016C.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%5FC5DFDB016C.declarations preserve=no
//## end module%5FC5DFDB016C.declarations

//## begin module%5FC5DFDB016C.additionalDeclarations preserve=yes
//## end module%5FC5DFDB016C.additionalDeclarations


namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::QMRAcquirer%5FC5E0C000E8.preface preserve=yes
//## end configuration::QMRAcquirer%5FC5E0C000E8.preface

//## Class: QMRAcquirer%5FC5E0C000E8
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5FC5E157016F;reusable::Query { -> F}
//## Uses: <unnamed>%5FC5E1590249;ConfigurationRepository { -> F}
//## Uses: <unnamed>%5FC5E15C00CB;IF::Extract { -> F}

class DllExport QMRAcquirer : public ConversionItem  //## Inherits: <unnamed>%5FC5E11A0111
{
  //## begin configuration::QMRAcquirer%5FC5E0C000E8.initialDeclarations preserve=yes
  //## end configuration::QMRAcquirer%5FC5E0C000E8.initialDeclarations

  public:
    //## Constructors (generated)
      QMRAcquirer();

    //## Destructor (generated)
      virtual ~QMRAcquirer();


    //## Other Operations (specified)
      //## Operation: bind%5FC5E19101AD
      virtual void bind (Query& hQuery);

      //## Operation: getBinDetails%5FC5E711003E
      static bool getBinDetails (const string& strBIN, int&  iLength, string& strNET_ID);

      //## Operation: getThird%5FC5E7C3005D
      virtual const string& getThird ();

    // Additional Public Declarations
      //## begin configuration::QMRAcquirer%5FC5E0C000E8.public preserve=yes
      //## end configuration::QMRAcquirer%5FC5E0C000E8.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::QMRAcquirer%5FC5E0C000E8.protected preserve=yes
      //## end configuration::QMRAcquirer%5FC5E0C000E8.protected

  private:
    // Additional Private Declarations
      //## begin configuration::QMRAcquirer%5FC5E0C000E8.private preserve=yes
      //## end configuration::QMRAcquirer%5FC5E0C000E8.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BIN_TYPE%5FC7274F039D
      //## begin configuration::QMRAcquirer::BIN_TYPE%5FC7274F039D.attr preserve=no  private: string {V} 
      string m_strBIN_TYPE;
      //## end configuration::QMRAcquirer::BIN_TYPE%5FC7274F039D.attr

      //## Attribute: CARD_BRAND%5FC5E7D803C0
      //## begin configuration::QMRAcquirer::CARD_BRAND%5FC5E7D803C0.attr preserve=no  private: string {V} 
      string m_strCARD_BRAND;
      //## end configuration::QMRAcquirer::CARD_BRAND%5FC5E7D803C0.attr

      //## Attribute: CIRRUS_LOGO%5FC7274C0325
      //## begin configuration::QMRAcquirer::CIRRUS_LOGO%5FC7274C0325.attr preserve=no  private: string {V} 
      string m_strCIRRUS_LOGO;
      //## end configuration::QMRAcquirer::CIRRUS_LOGO%5FC7274C0325.attr

      //## Attribute: INTERLINK_LOGO%6118E33903AB
      //## begin configuration::QMRAcquirer::INTERLINK_LOGO%6118E33903AB.attr preserve=no  private: string {U} 
      string m_strINTERLINK_LOGO;
      //## end configuration::QMRAcquirer::INTERLINK_LOGO%6118E33903AB.attr

      //## Attribute: MAESTRO_LOGO%5FC7274E03D8
      //## begin configuration::QMRAcquirer::MAESTRO_LOGO%5FC7274E03D8.attr preserve=no  private: string {V} 
      string m_strMAESTRO_LOGO;
      //## end configuration::QMRAcquirer::MAESTRO_LOGO%5FC7274E03D8.attr

      //## Attribute: MASTERCARD_LOGO%5FC7274E0000
      //## begin configuration::QMRAcquirer::MASTERCARD_LOGO%5FC7274E0000.attr preserve=no  private: string {V} 
      string m_strMASTERCARD_LOGO;
      //## end configuration::QMRAcquirer::MASTERCARD_LOGO%5FC7274E0000.attr

      //## Attribute: PLUS_LOGO%6118E3530007
      //## begin configuration::QMRAcquirer::PLUS_LOGO%6118E3530007.attr preserve=no  private: string {U} 
      string m_strPLUS_LOGO;
      //## end configuration::QMRAcquirer::PLUS_LOGO%6118E3530007.attr

      //## Attribute: VISA_LOGO%6118E30F024A
      //## begin configuration::QMRAcquirer::VISA_LOGO%6118E30F024A.attr preserve=no  private: string {U} 
      string m_strVISA_LOGO;
      //## end configuration::QMRAcquirer::VISA_LOGO%6118E30F024A.attr

    // Additional Implementation Declarations
      //## begin configuration::QMRAcquirer%5FC5E0C000E8.implementation preserve=yes
      //## end configuration::QMRAcquirer%5FC5E0C000E8.implementation

};

//## begin configuration::QMRAcquirer%5FC5E0C000E8.postscript preserve=yes
//## end configuration::QMRAcquirer%5FC5E0C000E8.postscript

} // namespace configuration

//## begin module%5FC5DFDB016C.epilog preserve=yes
//## end module%5FC5DFDB016C.epilog


#endif
