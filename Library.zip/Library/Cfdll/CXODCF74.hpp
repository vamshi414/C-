//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4263D91202FD.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%4263D91202FD.cm

//## begin module%4263D91202FD.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%4263D91202FD.cp

//## Module: CXOSCF74%4263D91202FD; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF74.hpp

#ifndef CXOSCF74_h
#define CXOSCF74_h 1

//## begin module%4263D91202FD.additionalIncludes preserve=no
//## end module%4263D91202FD.additionalIncludes

//## begin module%4263D91202FD.includes preserve=yes
//## end module%4263D91202FD.includes

#ifndef CXOSCF64_h
#include "CXODCF64.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
class Trace;

} // namespace IF

//## begin module%4263D91202FD.declarations preserve=no
//## end module%4263D91202FD.declarations

//## begin module%4263D91202FD.additionalDeclarations preserve=yes
//## end module%4263D91202FD.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::OasisISTFinancialMap%4263D7FA000F.preface preserve=yes
//## end configuration::OasisISTFinancialMap%4263D7FA000F.preface

//## Class: OasisISTFinancialMap%4263D7FA000F
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4263D81C00BB;IF::FlatFile { -> F}
//## Uses: <unnamed>%4263D81E0399;IF::Trace { -> F}

class DllExport OasisISTFinancialMap : public ImportMapItem  //## Inherits: <unnamed>%4263D8190232
{
  //## begin configuration::OasisISTFinancialMap%4263D7FA000F.initialDeclarations preserve=yes
  //## end configuration::OasisISTFinancialMap%4263D7FA000F.initialDeclarations

  public:
    //## Constructors (generated)
      OasisISTFinancialMap();

    //## Destructor (generated)
      virtual ~OasisISTFinancialMap();


    //## Other Operations (specified)
      //## Operation: loadDataMap%4263DB1E00DA
      virtual bool loadDataMap ();

    // Additional Public Declarations
      //## begin configuration::OasisISTFinancialMap%4263D7FA000F.public preserve=yes
      //## end configuration::OasisISTFinancialMap%4263D7FA000F.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::OasisISTFinancialMap%4263D7FA000F.protected preserve=yes
      //## end configuration::OasisISTFinancialMap%4263D7FA000F.protected

  private:
    // Additional Private Declarations
      //## begin configuration::OasisISTFinancialMap%4263D7FA000F.private preserve=yes
      //## end configuration::OasisISTFinancialMap%4263D7FA000F.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::OasisISTFinancialMap%4263D7FA000F.implementation preserve=yes
     char  m_hBuffer[256];
      //## end configuration::OasisISTFinancialMap%4263D7FA000F.implementation

};

//## begin configuration::OasisISTFinancialMap%4263D7FA000F.postscript preserve=yes
//## end configuration::OasisISTFinancialMap%4263D7FA000F.postscript

} // namespace configuration

//## begin module%4263D91202FD.epilog preserve=yes
//## end module%4263D91202FD.epilog


#endif
