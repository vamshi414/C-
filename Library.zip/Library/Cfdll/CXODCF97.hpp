//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4ACBA11603B1.cm preserve=no
//	$Date:   Dec 12 2016 13:24:32  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%4ACBA11603B1.cm

//## begin module%4ACBA11603B1.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4ACBA11603B1.cp

//## Module: CXOSCF97%4ACBA11603B1; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF97.hpp

#ifndef CXOSCF97_h
#define CXOSCF97_h 1

//## begin module%4ACBA11603B1.additionalIncludes preserve=no
//## end module%4ACBA11603B1.additionalIncludes

//## begin module%4ACBA11603B1.includes preserve=yes
//## end module%4ACBA11603B1.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Column;
class Query;

} // namespace reusable

//## begin module%4ACBA11603B1.declarations preserve=no
//## end module%4ACBA11603B1.declarations

//## begin module%4ACBA11603B1.additionalDeclarations preserve=yes
//## end module%4ACBA11603B1.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::DisputedAuthorizationTransaction%4ACB9FA20120.preface preserve=yes
//## end configuration::DisputedAuthorizationTransaction%4ACB9FA20120.preface

//## Class: DisputedAuthorizationTransaction%4ACB9FA20120
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4ACCB381039B;reusable::Query { -> F}
//## Uses: <unnamed>%4ACCB3920197;reusable::Column { -> F}

class DllExport DisputedAuthorizationTransaction : public ConversionItem  //## Inherits: <unnamed>%4ACBA1D602A7
{
  //## begin configuration::DisputedAuthorizationTransaction%4ACB9FA20120.initialDeclarations preserve=yes
  //## end configuration::DisputedAuthorizationTransaction%4ACB9FA20120.initialDeclarations

  public:
    //## Constructors (generated)
      DisputedAuthorizationTransaction();

    //## Destructor (generated)
      virtual ~DisputedAuthorizationTransaction();


    //## Other Operations (specified)
      //## Operation: bind%4ACBA2060363
      virtual void bind (Query& hQuery);

      //## Operation: getSecond%4ACBA20D0026
      virtual const string& getSecond ();

      //## Operation: setPredicate%584716F00196
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::DisputedAuthorizationTransaction%4ACB9FA20120.public preserve=yes
      //## end configuration::DisputedAuthorizationTransaction%4ACB9FA20120.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::DisputedAuthorizationTransaction%4ACB9FA20120.protected preserve=yes
      //## end configuration::DisputedAuthorizationTransaction%4ACB9FA20120.protected

  private:
    // Additional Private Declarations
      //## begin configuration::DisputedAuthorizationTransaction%4ACB9FA20120.private preserve=yes
      //## end configuration::DisputedAuthorizationTransaction%4ACB9FA20120.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: TSTAMP_TRANS%4ACBA2D40391
      //## begin configuration::DisputedAuthorizationTransaction::TSTAMP_TRANS%4ACBA2D40391.attr preserve=no  private: string {U} 
      string m_strTSTAMP_TRANS;
      //## end configuration::DisputedAuthorizationTransaction::TSTAMP_TRANS%4ACBA2D40391.attr

      //## Attribute: UNIQUENESS_KEY%4ACBA2F303D0
      //## begin configuration::DisputedAuthorizationTransaction::UNIQUENESS_KEY%4ACBA2F303D0.attr preserve=no  private: int {U} 0
      int m_iUNIQUENESS_KEY;
      //## end configuration::DisputedAuthorizationTransaction::UNIQUENESS_KEY%4ACBA2F303D0.attr

    // Additional Implementation Declarations
      //## begin configuration::DisputedAuthorizationTransaction%4ACB9FA20120.implementation preserve=yes
      //## end configuration::DisputedAuthorizationTransaction%4ACB9FA20120.implementation

};

//## begin configuration::DisputedAuthorizationTransaction%4ACB9FA20120.postscript preserve=yes
//## end configuration::DisputedAuthorizationTransaction%4ACB9FA20120.postscript

} // namespace configuration

//## begin module%4ACBA11603B1.epilog preserve=yes
//## end module%4ACBA11603B1.epilog


#endif
