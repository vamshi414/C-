//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%535078BA01DF.cm preserve=no
//	$Date:   Dec 12 2016 13:26:54  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%535078BA01DF.cm

//## begin module%535078BA01DF.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%535078BA01DF.cp

//## Module: CXOSCFA2%535078BA01DF; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCFA2.hpp

#ifndef CXOSCFA2_h
#define CXOSCFA2_h 1

//## begin module%535078BA01DF.additionalIncludes preserve=no
//## end module%535078BA01DF.additionalIncludes

//## begin module%535078BA01DF.includes preserve=yes
//## end module%535078BA01DF.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%535078BA01DF.declarations preserve=no
//## end module%535078BA01DF.declarations

//## begin module%535078BA01DF.additionalDeclarations preserve=yes
//## end module%535078BA01DF.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::DummyProblemTran%535078830178.preface preserve=yes
//## end configuration::DummyProblemTran%535078830178.preface

//## Class: DummyProblemTran%535078830178
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%535079E400F5;reusable::Query { -> F}
//## Uses: <unnamed>%535079E6035F;IF::Extract { -> F}

class DllExport DummyProblemTran : public ConversionItem  //## Inherits: <unnamed>%535079AF0174
{
  //## begin configuration::DummyProblemTran%535078830178.initialDeclarations preserve=yes
  //## end configuration::DummyProblemTran%535078830178.initialDeclarations

  public:
    //## Constructors (generated)
      DummyProblemTran();

    //## Destructor (generated)
      virtual ~DummyProblemTran();


    //## Other Operations (specified)
      //## Operation: bind%53507A090375
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%53507A09037B
      virtual const string& getFirst ();

      //## Operation: getSecond%53507A090380
      virtual const string& getSecond ();

      //## Operation: getThird%53507A090385
      virtual const string& getThird ();

      //## Operation: setPredicate%584717130077
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::DummyProblemTran%535078830178.public preserve=yes
      //## end configuration::DummyProblemTran%535078830178.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::DummyProblemTran%535078830178.protected preserve=yes
      //## end configuration::DummyProblemTran%535078830178.protected

  private:
    // Additional Private Declarations
      //## begin configuration::DummyProblemTran%535078830178.private preserve=yes
      //## end configuration::DummyProblemTran%535078830178.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::DummyProblemTran%535078830178.implementation preserve=yes
      //## end configuration::DummyProblemTran%535078830178.implementation

};

//## begin configuration::DummyProblemTran%535078830178.postscript preserve=yes
//## end configuration::DummyProblemTran%535078830178.postscript

} // namespace configuration

//## begin module%535078BA01DF.epilog preserve=yes
//## end module%535078BA01DF.epilog


#endif
