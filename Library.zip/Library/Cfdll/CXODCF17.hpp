//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%391C10FE001D.cm preserve=no
//## end module%391C10FE001D.cm

//## begin module%391C10FE001D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%391C10FE001D.cp

//## Module: CXOSCF17%391C10FE001D; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXODCF17.hpp

#ifndef CXOSCF17_h
#define CXOSCF17_h 1

//## begin module%391C10FE001D.additionalIncludes preserve=no
//## end module%391C10FE001D.additionalIncludes

//## begin module%391C10FE001D.includes preserve=yes
// $Date:   Dec 07 2016 15:45:00  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%391C10FE001D.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%391C10FE001D.declarations preserve=no
//## end module%391C10FE001D.declarations

//## begin module%391C10FE001D.additionalDeclarations preserve=yes
//## end module%391C10FE001D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::Institution%391C0CAC015D.preface preserve=yes
//## end configuration::Institution%391C0CAC015D.preface

//## Class: Institution%391C0CAC015D
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%391C1761038F;IF::Extract { -> F}
//## Uses: <unnamed>%391C17640235;reusable::Query { -> F}

class DllExport Institution : public ConversionItem  //## Inherits: <unnamed>%391C1760018F
{
  //## begin configuration::Institution%391C0CAC015D.initialDeclarations preserve=yes
  //## end configuration::Institution%391C0CAC015D.initialDeclarations

  public:
    //## Constructors (generated)
      Institution();

    //## Destructor (generated)
      virtual ~Institution();


    //## Other Operations (specified)
      //## Operation: bind%391C1BFB02C0
      virtual void bind (Query& hQuery);

      //## Operation: getThird%63185F4C01B3
      virtual const reusable::string& getThird ();

      //## Operation: setPredicate%584714E50139
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::Institution%391C0CAC015D.public preserve=yes
      //## end configuration::Institution%391C0CAC015D.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::Institution%391C0CAC015D.protected preserve=yes
      //## end configuration::Institution%391C0CAC015D.protected

  private:
    // Additional Private Declarations
      //## begin configuration::Institution%391C0CAC015D.private preserve=yes
      //## end configuration::Institution%391C0CAC015D.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::Institution%391C0CAC015D.implementation preserve=yes
      //## end configuration::Institution%391C0CAC015D.implementation

};

//## begin configuration::Institution%391C0CAC015D.postscript preserve=yes
//## end configuration::Institution%391C0CAC015D.postscript

} // namespace configuration

//## begin module%391C10FE001D.epilog preserve=yes
using namespace configuration;
//## end module%391C10FE001D.epilog


#endif
