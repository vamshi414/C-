//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40C9A79702EE.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40C9A79702EE.cm

//## begin module%40C9A79702EE.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40C9A79702EE.cp

//## Module: CXOSCF67%40C9A79702EE; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF67.cpp

//## begin module%40C9A79702EE.additionalIncludes preserve=no
//## end module%40C9A79702EE.additionalIncludes

//## begin module%40C9A79702EE.includes preserve=yes
// $Date:   May 26 2020 10:44:48  $ $Author:   e1009510  $ $Revision:   1.7  $
//## end module%40C9A79702EE.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSCF67_h
#include "CXODCF67.hpp"
#endif


//## begin module%40C9A79702EE.declarations preserve=no
//## end module%40C9A79702EE.declarations

//## begin module%40C9A79702EE.additionalDeclarations preserve=yes
//## end module%40C9A79702EE.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::OasisOCSExceptionMap 

OasisOCSExceptionMap::OasisOCSExceptionMap()
  //## begin OasisOCSExceptionMap::OasisOCSExceptionMap%40C9A63F008C_const.hasinit preserve=no
  //## end OasisOCSExceptionMap::OasisOCSExceptionMap%40C9A63F008C_const.hasinit
  //## begin OasisOCSExceptionMap::OasisOCSExceptionMap%40C9A63F008C_const.initialization preserve=yes
   : ImportMapItem("CASEFLDS")
  //## end OasisOCSExceptionMap::OasisOCSExceptionMap%40C9A63F008C_const.initialization
{
  //## begin configuration::OasisOCSExceptionMap::OasisOCSExceptionMap%40C9A63F008C_const.body preserve=yes
   memcpy(m_sID,"CF67",4);
  //## end configuration::OasisOCSExceptionMap::OasisOCSExceptionMap%40C9A63F008C_const.body
}


OasisOCSExceptionMap::~OasisOCSExceptionMap()
{
  //## begin configuration::OasisOCSExceptionMap::~OasisOCSExceptionMap%40C9A63F008C_dest.body preserve=yes
   m_hDataMap.erase(m_hDataMap.begin(),m_hDataMap.end());
  //## end configuration::OasisOCSExceptionMap::~OasisOCSExceptionMap%40C9A63F008C_dest.body
}



//## Other Operations (implementation)
bool OasisOCSExceptionMap::loadDataMap ()
{
  //## begin configuration::OasisOCSExceptionMap::loadDataMap%40C9A80003D8.body preserve=yes
   if (!m_hDataMap.empty())
      return true;
#ifdef MVS
   FlatFile hTemplate("JCL","CASEFLDS");
#else
   FlatFile hTemplate("SOURCE","CXOXCFLD");
#endif
   if (!hTemplate.open())
      return false;
   char* psBuffer = new char[256];
   memset(psBuffer,' ',256);
   size_t m = 0;
   string strTokenID, strTargetColumn, strTargetSegment;
   while (hTemplate.read(psBuffer,256,&m))
   {
      char *pRcdType;
      pRcdType = strchr(psBuffer,'.');
      if (pRcdType)
      {
         *pRcdType = '\0';
         ++pRcdType;
         char* pFieldID = strchr(pRcdType,'.');
         if (pFieldID)
         {
            *pFieldID = '\0';
            ++pFieldID;
            char* s = strchr(pFieldID,'.');
            if (s)
            {
               *s = '\0';
               ++s;
            }
            char* q = strchr(s,'~');
            if (q)
            {
               *q = '\0';
               ++q;
               strTargetSegment.assign(q,1);
			      q += 2;
               char* p = strchr(q,'.');
			      if (p)
			      {
			         *p = '\0';
			         strTargetColumn.assign(q);
			      }
            }
            strTokenID.assign(pRcdType);
            strTokenID += pFieldID;
			   strTargetSegment += ' ';
			   strTargetSegment += strTargetColumn;
            m_hDataMap.insert(map<string,string,less<string> >::value_type(strTokenID,strTargetSegment));
         }
      }
      strTokenID.erase();
      strTargetSegment.erase();
      strTargetColumn.erase();
   }
   delete [] psBuffer;
   return true;
  //## end configuration::OasisOCSExceptionMap::loadDataMap%40C9A80003D8.body
}

// Additional Declarations
  //## begin configuration::OasisOCSExceptionMap%40C9A63F008C.declarations preserve=yes
  //## end configuration::OasisOCSExceptionMap%40C9A63F008C.declarations

} // namespace configuration

//## begin module%40C9A79702EE.epilog preserve=yes
//## end module%40C9A79702EE.epilog
