//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFC3DDE0109.cm preserve=no
//	$Date:   Dec 16 2016 15:22:24  $ $Author:   e1009652  $
//	$Revision:   1.4  $
//## end module%3FFC3DDE0109.cm

//## begin module%3FFC3DDE0109.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFC3DDE0109.cp

//## Module: CXOSCF53%3FFC3DDE0109; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF53.cpp

//## begin module%3FFC3DDE0109.additionalIncludes preserve=no
//## end module%3FFC3DDE0109.additionalIncludes

//## begin module%3FFC3DDE0109.includes preserve=yes
// $Date:   Dec 16 2016 15:22:24  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%3FFC3DDE0109.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF53_h
#include "CXODCF53.hpp"
#endif
//## begin module%3FFC3DDE0109.declarations preserve=no
//## end module%3FFC3DDE0109.declarations

//## begin module%3FFC3DDE0109.additionalDeclarations preserve=yes
//## end module%3FFC3DDE0109.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexPOSConditionCode4 

ConnexPOSConditionCode4::ConnexPOSConditionCode4()
  //## begin ConnexPOSConditionCode4::ConnexPOSConditionCode4%3FFC3C7600BB_const.hasinit preserve=no
  //## end ConnexPOSConditionCode4::ConnexPOSConditionCode4%3FFC3C7600BB_const.hasinit
  //## begin ConnexPOSConditionCode4::ConnexPOSConditionCode4%3FFC3C7600BB_const.initialization preserve=yes
   : ConversionItem("## CR65 XLATE POS CON COD4")
  //## end ConnexPOSConditionCode4::ConnexPOSConditionCode4%3FFC3C7600BB_const.initialization
{
  //## begin configuration::ConnexPOSConditionCode4::ConnexPOSConditionCode4%3FFC3C7600BB_const.body preserve=yes
   memcpy(m_sID,"CF53",4);
  //## end configuration::ConnexPOSConditionCode4::ConnexPOSConditionCode4%3FFC3C7600BB_const.body
}


ConnexPOSConditionCode4::~ConnexPOSConditionCode4()
{
  //## begin configuration::ConnexPOSConditionCode4::~ConnexPOSConditionCode4%3FFC3C7600BB_dest.body preserve=yes
  //## end configuration::ConnexPOSConditionCode4::~ConnexPOSConditionCode4%3FFC3C7600BB_dest.body
}



//## Other Operations (implementation)
void ConnexPOSConditionCode4::bind (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode4::bind%3FFC3CB4004E.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_IBM_POS_COND_COD");
   hQuery.bind("X_IBM_POS_COND_COD","POS_COND_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_POS_COND_COD","POS_CRDHLDR_AUTH",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IBM_POS_COND_COD.POS_COND_CODE ASC");
  //## end configuration::ConnexPOSConditionCode4::bind%3FFC3CB4004E.body
}

void ConnexPOSConditionCode4::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode4::setPredicate%5847162F0108.body preserve=yes
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_STATE", "=", "A");
  //## end configuration::ConnexPOSConditionCode4::setPredicate%5847162F0108.body
}

// Additional Declarations
  //## begin configuration::ConnexPOSConditionCode4%3FFC3C7600BB.declarations preserve=yes
  //## end configuration::ConnexPOSConditionCode4%3FFC3C7600BB.declarations

} // namespace configuration

//## begin module%3FFC3DDE0109.epilog preserve=yes
//## end module%3FFC3DDE0109.epilog
