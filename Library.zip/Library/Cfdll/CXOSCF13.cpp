//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%391C0DF10164.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%391C0DF10164.cm

//## begin module%391C0DF10164.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%391C0DF10164.cp

//## Module: CXOSCF13%391C0DF10164; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF13.cpp

//## begin module%391C0DF10164.additionalIncludes preserve=no
//## end module%391C0DF10164.additionalIncludes

//## begin module%391C0DF10164.includes preserve=yes
// $Date:   Apr 17 2014 20:59:20  $ $Author:   e1009652  $ $Revision:   1.6  $
//## end module%391C0DF10164.includes

#ifndef CXOSCF13_h
#include "CXODCF13.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%391C0DF10164.declarations preserve=no
//## end module%391C0DF10164.declarations

//## begin module%391C0DF10164.additionalDeclarations preserve=yes
//## end module%391C0DF10164.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::VisaAdjustmentReason

VisaAdjustmentReason::VisaAdjustmentReason()
  //## begin VisaAdjustmentReason::VisaAdjustmentReason%391C0C680123_const.hasinit preserve=no
  //## end VisaAdjustmentReason::VisaAdjustmentReason%391C0C680123_const.hasinit
  //## begin VisaAdjustmentReason::VisaAdjustmentReason%391C0C680123_const.initialization preserve=yes
   : ConversionItem("## CR16 XLATE VISA ADJ REASON")
  //## end VisaAdjustmentReason::VisaAdjustmentReason%391C0C680123_const.initialization
{
  //## begin configuration::VisaAdjustmentReason::VisaAdjustmentReason%391C0C680123_const.body preserve=yes
  //## end configuration::VisaAdjustmentReason::VisaAdjustmentReason%391C0C680123_const.body
}


VisaAdjustmentReason::~VisaAdjustmentReason()
{
  //## begin configuration::VisaAdjustmentReason::~VisaAdjustmentReason%391C0C680123_dest.body preserve=yes
   memcpy(m_sID,"CF13",4);
  //## end configuration::VisaAdjustmentReason::~VisaAdjustmentReason%391C0C680123_dest.body
}



//## Other Operations (implementation)
void VisaAdjustmentReason::bind (Query& hQuery)
{
  //## begin configuration::VisaAdjustmentReason::bind%391C1BCC0164.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_VISA_ADJ_REASON");
   hQuery.bind("X_VISA_ADJ_REASON","VISA_ADJ_REASON",Column::STRING,&m_strFirst);
   hQuery.bind("X_VISA_ADJ_REASON","MSG_REASON_CODE",Column::STRING,&m_strSecond);
   hQuery.bind("X_VISA_ADJ_REASON","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_VISA_ADJ_REASON","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_VISA_ADJ_REASON","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_VISA_ADJ_REASON","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_VISA_ADJ_REASON.VISA_ADJ_REASON ASC,X_VISA_ADJ_REASON.CUST_ID DESC");
  //## end configuration::VisaAdjustmentReason::bind%391C1BCC0164.body
}

// Additional Declarations
  //## begin configuration::VisaAdjustmentReason%391C0C680123.declarations preserve=yes
  //## end configuration::VisaAdjustmentReason%391C0C680123.declarations

} // namespace configuration

//## begin module%391C0DF10164.epilog preserve=yes
//## end module%391C0DF10164.epilog
