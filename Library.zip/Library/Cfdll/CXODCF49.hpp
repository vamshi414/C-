//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FF1D7AF0196.cm preserve=no
//	$Date:   Dec 12 2016 12:55:20  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%3FF1D7AF0196.cm

//## begin module%3FF1D7AF0196.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FF1D7AF0196.cp

//## Module: CXOSCF49%3FF1D7AF0196; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF49.hpp

#ifndef CXOSCF49_h
#define CXOSCF49_h 1

//## begin module%3FF1D7AF0196.additionalIncludes preserve=no
//## end module%3FF1D7AF0196.additionalIncludes

//## begin module%3FF1D7AF0196.includes preserve=yes
// $Date:   Dec 12 2016 12:55:20  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%3FF1D7AF0196.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
//## begin module%3FF1D7AF0196.declarations preserve=no
//## end module%3FF1D7AF0196.declarations

//## begin module%3FF1D7AF0196.additionalDeclarations preserve=yes
//## end module%3FF1D7AF0196.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexPanEntryMode2%3FF1D7020251.preface preserve=yes
//## end configuration::ConnexPanEntryMode2%3FF1D7020251.preface

//## Class: ConnexPanEntryMode2%3FF1D7020251
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FF1D7670148;IF::Extract { -> F}
//## Uses: <unnamed>%3FF1D7690109;reusable::Query { -> F}

class DllExport ConnexPanEntryMode2 : public ConversionItem  //## Inherits: <unnamed>%3FF1D74C0157
{
  //## begin configuration::ConnexPanEntryMode2%3FF1D7020251.initialDeclarations preserve=yes
  //## end configuration::ConnexPanEntryMode2%3FF1D7020251.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexPanEntryMode2();

    //## Destructor (generated)
      virtual ~ConnexPanEntryMode2();


    //## Other Operations (specified)
      //## Operation: bind%3FF1D7860167
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%584715DC02E4
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexPanEntryMode2%3FF1D7020251.public preserve=yes
      //## end configuration::ConnexPanEntryMode2%3FF1D7020251.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexPanEntryMode2%3FF1D7020251.protected preserve=yes
      //## end configuration::ConnexPanEntryMode2%3FF1D7020251.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexPanEntryMode2%3FF1D7020251.private preserve=yes
      //## end configuration::ConnexPanEntryMode2%3FF1D7020251.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexPanEntryMode2%3FF1D7020251.implementation preserve=yes
      //## end configuration::ConnexPanEntryMode2%3FF1D7020251.implementation

};

//## begin configuration::ConnexPanEntryMode2%3FF1D7020251.postscript preserve=yes
//## end configuration::ConnexPanEntryMode2%3FF1D7020251.postscript

} // namespace configuration

//## begin module%3FF1D7AF0196.epilog preserve=yes
using namespace configuration;
//## end module%3FF1D7AF0196.epilog


#endif
