//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3958D461004F.cm preserve=no
//	$Date:   Jul 20 2018 07:41:54  $ $Author:   e5561468  $
//	$Revision:   1.7  $
//## end module%3958D461004F.cm

//## begin module%3958D461004F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3958D461004F.cp

//## Module: CXOSCF32%3958D461004F; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\latest\V02.9B.R001\DN\Server\Library\Cfdll\CXODCF32.hpp

#ifndef CXOSCF32_h
#define CXOSCF32_h 1

//## begin module%3958D461004F.additionalIncludes preserve=no
//## end module%3958D461004F.additionalIncludes

//## begin module%3958D461004F.includes preserve=yes
// $Date:   Jul 20 2018 07:41:54  $ $Author:   e5561468  $ $Revision:   1.7  $
//## end module%3958D461004F.includes

#ifndef CXOSIF20_h
#include "CXODIF20.hpp"
#endif

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class Count;

} // namespace monitor

//## begin module%3958D461004F.declarations preserve=no
//## end module%3958D461004F.declarations

//## begin module%3958D461004F.additionalDeclarations preserve=yes
//## end module%3958D461004F.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConfigurationTable%3958B59602FC.preface preserve=yes
//## end configuration::ConfigurationTable%3958B59602FC.preface

//## Class: ConfigurationTable%3958B59602FC
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport ConfigurationTable : public IF::SharedResource  //## Inherits: <unnamed>%3958B5CA01F3
{
  //## begin configuration::ConfigurationTable%3958B59602FC.initialDeclarations preserve=yes
  public:
      enum Type
      {
         CONVERSION,
         VERIFICATION,
         MAPPING
      };
  //## end configuration::ConfigurationTable%3958B59602FC.initialDeclarations

  public:
    //## Constructors (generated)
      ConfigurationTable();

    //## Constructors (specified)
      //## Operation: ConfigurationTable%3958D29F0098
      ConfigurationTable (const char* pszName);

    //## Destructor (generated)
      virtual ~ConfigurationTable();


    //## Other Operations (specified)
      //## Operation: getTableName%3958D37800EA
      string getTableName ();

      //## Operation: getType%3958E9E0037D
      virtual Type getType ()
      {
        //## begin configuration::ConfigurationTable::getType%3958E9E0037D.body preserve=yes
		 return ConfigurationTable::CONVERSION;
        //## end configuration::ConfigurationTable::getType%3958E9E0037D.body
      }

      //## Operation: setMember%3958D25D033C
      void setMember (const string& strMember);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Reset%5B3C895B000D
      const bool& getReset () const
      {
        //## begin configuration::ConfigurationTable::getReset%5B3C895B000D.get preserve=no
        return m_bReset;
        //## end configuration::ConfigurationTable::getReset%5B3C895B000D.get
      }

      void setReset (const bool& value)
      {
        //## begin configuration::ConfigurationTable::setReset%5B3C895B000D.set preserve=no
        m_bReset = value;
        //## end configuration::ConfigurationTable::setReset%5B3C895B000D.set
      }


      //## Attribute: Version%3958B5E3013B
      const int& getVersion () const
      {
        //## begin configuration::ConfigurationTable::getVersion%3958B5E3013B.get preserve=no
        return m_lVersion;
        //## end configuration::ConfigurationTable::getVersion%3958B5E3013B.get
      }

      void setVersion (const int& value)
      {
        //## begin configuration::ConfigurationTable::setVersion%3958B5E3013B.set preserve=no
        m_lVersion = value;
        //## end configuration::ConfigurationTable::setVersion%3958B5E3013B.set
      }


    // Additional Public Declarations
      //## begin configuration::ConfigurationTable%3958B59602FC.public preserve=yes
      //## end configuration::ConfigurationTable%3958B59602FC.public

  protected:
    // Data Members for Associations

      //## Association: DataNavigator Foundation::Configuration_CAT::<unnamed>%3958B6390347
      //## Role: ConfigurationTable::<m_pCount>%3958B63A0226
      //## begin configuration::ConfigurationTable::<m_pCount>%3958B63A0226.role preserve=no  protected: monitor::Count {1 -> 2RFHgAN}
      monitor::Count *m_pCount[2];
      //## end configuration::ConfigurationTable::<m_pCount>%3958B63A0226.role

    // Additional Protected Declarations
      //## begin configuration::ConfigurationTable%3958B59602FC.protected preserve=yes
      //## end configuration::ConfigurationTable%3958B59602FC.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConfigurationTable%3958B59602FC.private preserve=yes
      //## end configuration::ConfigurationTable%3958B59602FC.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin configuration::ConfigurationTable::Reset%5B3C895B000D.attr preserve=no  public: bool {U} false
      bool m_bReset;
      //## end configuration::ConfigurationTable::Reset%5B3C895B000D.attr

      //## begin configuration::ConfigurationTable::Version%3958B5E3013B.attr preserve=no  public: int {V} -1
      int m_lVersion;
      //## end configuration::ConfigurationTable::Version%3958B5E3013B.attr

    // Additional Implementation Declarations
      //## begin configuration::ConfigurationTable%3958B59602FC.implementation preserve=yes
      //## end configuration::ConfigurationTable%3958B59602FC.implementation

};

//## begin configuration::ConfigurationTable%3958B59602FC.postscript preserve=yes
//## end configuration::ConfigurationTable%3958B59602FC.postscript

} // namespace configuration

//## begin module%3958D461004F.epilog preserve=yes
using namespace configuration;
//## end module%3958D461004F.epilog


#endif
