//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%62C6BC1B0081.cm preserve=no
//## end module%62C6BC1B0081.cm

//## begin module%62C6BC1B0081.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%62C6BC1B0081.cp

//## Module: CXOSCFD2%62C6BC1B0081; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFD2.cpp

//## begin module%62C6BC1B0081.additionalIncludes preserve=no
//## end module%62C6BC1B0081.additionalIncludes

//## begin module%62C6BC1B0081.includes preserve=yes
#include "CXODIF03.hpp"
//## end module%62C6BC1B0081.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSTM15_h
#include "CXODTM15.hpp"
#endif
#ifndef CXOSCFD2_h
#include "CXODCFD2.hpp"
#endif


//## begin module%62C6BC1B0081.declarations preserve=no
//## end module%62C6BC1B0081.declarations

//## begin module%62C6BC1B0081.additionalDeclarations preserve=yes
//## end module%62C6BC1B0081.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::NationalNetworkBin 

//## begin configuration::NationalNetworkBin::Instance%649ADE51016C.attr preserve=no  private: static configuration::NationalNetworkBin* {V} 0
configuration::NationalNetworkBin* NationalNetworkBin::m_pInstance = 0;
//## end configuration::NationalNetworkBin::Instance%649ADE51016C.attr

NationalNetworkBin::NationalNetworkBin()
  //## begin NationalNetworkBin::NationalNetworkBin%62C6BCDC0298_const.hasinit preserve=no
  //## end NationalNetworkBin::NationalNetworkBin%62C6BCDC0298_const.hasinit
  //## begin NationalNetworkBin::NationalNetworkBin%62C6BCDC0298_const.initialization preserve=yes
  //## end NationalNetworkBin::NationalNetworkBin%62C6BCDC0298_const.initialization
{
  //## begin configuration::NationalNetworkBin::NationalNetworkBin%62C6BCDC0298_const.body preserve=yes
   memcpy(m_sID,"CFD2",4);
   WitchingHour::instance()->attach(this);
  //## end configuration::NationalNetworkBin::NationalNetworkBin%62C6BCDC0298_const.body
}


NationalNetworkBin::~NationalNetworkBin()
{
  //## begin configuration::NationalNetworkBin::~NationalNetworkBin%62C6BCDC0298_dest.body preserve=yes
   WitchingHour::instance()->detach(this);
  //## end configuration::NationalNetworkBin::~NationalNetworkBin%62C6BCDC0298_dest.body
}



//## Other Operations (implementation)
configuration::NationalNetworkBin* NationalNetworkBin::instance ()
{
  //## begin configuration::NationalNetworkBin::instance%649ADE320075.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new NationalNetworkBin();
   return m_pInstance;
  //## end configuration::NationalNetworkBin::instance%649ADE320075.body
}

bool NationalNetworkBin::load ()
{
  //## begin configuration::NationalNetworkBin::load%649AD40A01D9.body preserve=yes
   m_hBIN.erase(m_hBIN.begin(),m_hBIN.end());
   Query hQuery;
   hQuery.attach(this);
   hQuery.setQualifier("QUALIFY","NATIONAL_NET_BIN");
   hQuery.bind("NATIONAL_NET_BIN","NET_ID",Column::STRING,&m_strNET_ID);
   hQuery.bind("NATIONAL_NET_BIN","ISSUER_BIN",Column::STRING,&m_strISSUER_BIN);
   hQuery.bind("NATIONAL_NET_BIN","BIN_LOW",Column::STRING,&m_strBIN_LOW);
   hQuery.bind("NATIONAL_NET_BIN","BIN_HIGH",Column::STRING,&m_strBIN_HIGH);
   hQuery.setBasicPredicate("NATIONAL_NET_BIN","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("NATIONAL_NET_BIN","CC_STATE","=","A");
   hQuery.setOrderByClause("NET_ID,ISSUER_BIN,BIN_LOW,BIN_HIGH");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   return pSelectStatement->execute(hQuery);
  //## end configuration::NationalNetworkBin::load%649AD40A01D9.body
}

void NationalNetworkBin::update (Subject* pSubject)
{
  //## begin configuration::NationalNetworkBin::update%649AD40C0300.body preserve=yes
   if (pSubject == WitchingHour::instance())
   {
      database::Cache::reload(this);
      return;
   }
   m_strNET_ID += m_strISSUER_BIN;
   m_hBIN.insert(multimap<string,pair<string,string>,less<string> >::value_type(m_strNET_ID,make_pair(m_strBIN_LOW,m_strBIN_HIGH)));
  //## end configuration::NationalNetworkBin::update%649AD40C0300.body
}

bool NationalNetworkBin::verify (const reusable::string& strNET_ID, const reusable::string& strISSUER_BIN, const reusable::string& strPAN)
{
  //## begin configuration::NationalNetworkBin::verify%649AD47B00AF.body preserve=yes
   string strFirst(strNET_ID);
   strFirst += strISSUER_BIN;
   pair<multimap<string,pair<string,string>,less<string> >::iterator,multimap<string,pair<string,string>,less<string> >::iterator> hRange = m_hBIN.equal_range(strFirst);
   multimap<string,pair<string,string>,less<string> >::iterator pRange;
   for (pRange = hRange.first;pRange != hRange.second;++pRange)
   {
      if (IF::Trace::getEnable())
      {
         string strText("CFD2 verify: ");
         strText.append(strFirst);
         strText.append(",",1);
         strText += strPAN;
         strText.append(",",1);
         strText += (*pRange).second.first;
         strText.append(",",1);
         strText += (*pRange).second.second;
         Trace::put(strText.data(),strText.length());
      }
      if (strPAN >= (*pRange).second.first
         && strPAN <= (*pRange).second.second)
         return true;
   }
   return false;
  //## end configuration::NationalNetworkBin::verify%649AD47B00AF.body
}

// Additional Declarations
  //## begin configuration::NationalNetworkBin%62C6BCDC0298.declarations preserve=yes
  //## end configuration::NationalNetworkBin%62C6BCDC0298.declarations

} // namespace configuration

//## begin module%62C6BC1B0081.epilog preserve=yes
//## end module%62C6BC1B0081.epilog
