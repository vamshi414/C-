//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%652822A001E9.cm preserve=no
//## end module%652822A001E9.cm

//## begin module%652822A001E9.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%652822A001E9.cp

//## Module: CXOSCFD6%652822A001E9; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFD6.cpp

//## begin module%652822A001E9.additionalIncludes preserve=no
//## end module%652822A001E9.additionalIncludes

//## begin module%652822A001E9.includes preserve=yes
//## end module%652822A001E9.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFD6_h
#include "CXODCFD6.hpp"
#endif


//## begin module%652822A001E9.declarations preserve=no
//## end module%652822A001E9.declarations

//## begin module%652822A001E9.additionalDeclarations preserve=yes
//## end module%652822A001E9.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::MoneyPassProcessCode 

MoneyPassProcessCode::MoneyPassProcessCode()
  //## begin MoneyPassProcessCode::MoneyPassProcessCode%652821620178_const.hasinit preserve=no
  //## end MoneyPassProcessCode::MoneyPassProcessCode%652821620178_const.hasinit
  //## begin MoneyPassProcessCode::MoneyPassProcessCode%652821620178_const.initialization preserve=yes
   : ConversionItem("## CR15 XLATE MONEYPASS PROCESS CODE")
  //## end MoneyPassProcessCode::MoneyPassProcessCode%652821620178_const.initialization
{
  //## begin configuration::MoneyPassProcessCode::MoneyPassProcessCode%652821620178_const.body preserve=yes
   memcpy(m_sID, "CFD6", 4);
  //## end configuration::MoneyPassProcessCode::MoneyPassProcessCode%652821620178_const.body
}


MoneyPassProcessCode::~MoneyPassProcessCode()
{
  //## begin configuration::MoneyPassProcessCode::~MoneyPassProcessCode%652821620178_dest.body preserve=yes
  //## end configuration::MoneyPassProcessCode::~MoneyPassProcessCode%652821620178_dest.body
}



//## Other Operations (implementation)
void MoneyPassProcessCode::bind (Query& hQuery)
{
  //## begin configuration::MoneyPassProcessCode::bind%65282162017D.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY", "X_MPAS_PROC_CODE");
   hQuery.bind("X_MPAS_PROC_CODE", "MPAS_PROCESS_CODE", Column::STRING, &m_strFirst);
   hQuery.bind("X_MPAS_PROC_CODE", "PROCESS_CODE", Column::STRING, &m_strPROCESS_CODE);
   hQuery.bind("X_MPAS_PROC_CODE", "MSG_CLASS", Column::STRING, &m_strMSG_CLASS);
   hQuery.bind("X_MPAS_PROC_CODE", "PRE_AUTH", Column::STRING, &m_strPRE_AUTH);
   hQuery.bind("X_MPAS_PROC_CODE", "MEDIA_TYPE", Column::STRING, &m_strMEDIA_TYPE);
   hQuery.bind("X_MPAS_PROC_CODE", "CUST_ID", Column::STRING, &m_strCUST_ID);
   hQuery.setBasicPredicate("X_MPAS_PROC_CODE", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_MPAS_PROC_CODE", "CC_STATE", "=", "A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_MPAS_PROC_CODE", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("X_MPAS_PROC_CODE.MPAS_PROCESS_CODE ASC,X_MPAS_PROC_CODE.CUST_ID DESC");
  //## end configuration::MoneyPassProcessCode::bind%65282162017D.body
}

const string& MoneyPassProcessCode::getSecond ()
{
  //## begin configuration::MoneyPassProcessCode::getSecond%65282162017F.body preserve=yes
   m_strPROCESS_CODE.resize(6, ' ');
   m_strMSG_CLASS.resize(1, ' ');
   m_strPRE_AUTH.resize(1, ' ');
   m_strMEDIA_TYPE.resize(2, ' ');
   m_strSecond = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strSecond;
  //## end configuration::MoneyPassProcessCode::getSecond%65282162017F.body
}

// Additional Declarations
  //## begin configuration::MoneyPassProcessCode%652821620178.declarations preserve=yes
  //## end configuration::MoneyPassProcessCode%652821620178.declarations

} // namespace configuration

//## begin module%652822A001E9.epilog preserve=yes
//## end module%652822A001E9.epilog
