//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40F5309203D8.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40F5309203D8.cm

//## begin module%40F5309203D8.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40F5309203D8.cp

//## Module: CXOSCF69%40F5309203D8; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF69.hpp

#ifndef CXOSCF69_h
#define CXOSCF69_h 1

//## begin module%40F5309203D8.additionalIncludes preserve=no
//## end module%40F5309203D8.additionalIncludes

//## begin module%40F5309203D8.includes preserve=yes
// $Date:   May 31 2005 06:18:00  $ $Author:   D98885  $ $Revision:   1.1  $
//## end module%40F5309203D8.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%40F5309203D8.declarations preserve=no
//## end module%40F5309203D8.declarations

//## begin module%40F5309203D8.additionalDeclarations preserve=yes
//## end module%40F5309203D8.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::NetworkMiscDataRev%40F52F980109.preface preserve=yes
//## end configuration::NetworkMiscDataRev%40F52F980109.preface

//## Class: NetworkMiscDataRev%40F52F980109
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40F5302403D8;reusable::Query { -> F}
//## Uses: <unnamed>%40F530270119;IF::Extract { -> F}

class DllExport NetworkMiscDataRev : public ConversionItem  //## Inherits: <unnamed>%40F530010196
{
  //## begin configuration::NetworkMiscDataRev%40F52F980109.initialDeclarations preserve=yes
  //## end configuration::NetworkMiscDataRev%40F52F980109.initialDeclarations

  public:
    //## Constructors (generated)
      NetworkMiscDataRev();

    //## Destructor (generated)
      virtual ~NetworkMiscDataRev();


    //## Other Operations (specified)
      //## Operation: bind%40F5306100FA
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getFirst%40F5306401A5
      virtual const string& getFirst ();

      //## Operation: getSecond%40F530670119
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::NetworkMiscDataRev%40F52F980109.public preserve=yes
      //## end configuration::NetworkMiscDataRev%40F52F980109.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::NetworkMiscDataRev%40F52F980109.protected preserve=yes
      //## end configuration::NetworkMiscDataRev%40F52F980109.protected

  private:
    // Additional Private Declarations
      //## begin configuration::NetworkMiscDataRev%40F52F980109.private preserve=yes
      //## end configuration::NetworkMiscDataRev%40F52F980109.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DATA_ELEMENT%40F5303D0242
      //## begin configuration::NetworkMiscDataRev::DATA_ELEMENT%40F5303D0242.attr preserve=no  private: string {U} 
      string m_strDATA_ELEMENT;
      //## end configuration::NetworkMiscDataRev::DATA_ELEMENT%40F5303D0242.attr

      //## Attribute: DATA_TYPE%4291F00600BB
      //## begin configuration::NetworkMiscDataRev::DATA_TYPE%4291F00600BB.attr preserve=no  private: string {U} 
      string m_strDATA_TYPE;
      //## end configuration::NetworkMiscDataRev::DATA_TYPE%4291F00600BB.attr

      //## Attribute: DATA_VALUE%40F53043009C
      //## begin configuration::NetworkMiscDataRev::DATA_VALUE%40F53043009C.attr preserve=no  private: string {U} 
      string m_strDATA_VALUE;
      //## end configuration::NetworkMiscDataRev::DATA_VALUE%40F53043009C.attr

      //## Attribute: NET_ID%40F5303A007D
      //## begin configuration::NetworkMiscDataRev::NET_ID%40F5303A007D.attr preserve=no  private: string {U} 
      string m_strNET_ID;
      //## end configuration::NetworkMiscDataRev::NET_ID%40F5303A007D.attr

      //## Attribute: NETWORK_VALUE%40F53045034B
      //## begin configuration::NetworkMiscDataRev::NETWORK_VALUE%40F53045034B.attr preserve=no  private: string {U} 
      string m_strNETWORK_VALUE;
      //## end configuration::NetworkMiscDataRev::NETWORK_VALUE%40F53045034B.attr

      //## Attribute: SUB_ELEMENT%40F530400148
      //## begin configuration::NetworkMiscDataRev::SUB_ELEMENT%40F530400148.attr preserve=no  private: string {U} 
      string m_strSUB_ELEMENT;
      //## end configuration::NetworkMiscDataRev::SUB_ELEMENT%40F530400148.attr

    // Additional Implementation Declarations
      //## begin configuration::NetworkMiscDataRev%40F52F980109.implementation preserve=yes
      //## end configuration::NetworkMiscDataRev%40F52F980109.implementation

};

//## begin configuration::NetworkMiscDataRev%40F52F980109.postscript preserve=yes
//## end configuration::NetworkMiscDataRev%40F52F980109.postscript

} // namespace configuration

//## begin module%40F5309203D8.epilog preserve=yes
using namespace configuration;
//## end module%40F5309203D8.epilog


#endif
