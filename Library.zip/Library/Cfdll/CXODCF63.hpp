//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%5059C94D025F.cm preserve=no
//	$Date:   Oct 25 2012 08:12:00  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5059C94D025F.cm

//## begin module%5059C94D025F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5059C94D025F.cp

//## Module: CXOSCF63%5059C94D025F; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF63.hpp

#ifndef CXOSCF63_h
#define CXOSCF63_h 1

//## begin module%5059C94D025F.additionalIncludes preserve=no
//## end module%5059C94D025F.additionalIncludes

//## begin module%5059C94D025F.includes preserve=yes
//## end module%5059C94D025F.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%5059C94D025F.declarations preserve=no
//## end module%5059C94D025F.declarations

//## begin module%5059C94D025F.additionalDeclarations preserve=yes
//## end module%5059C94D025F.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::VisaResponseCode%5059C2280182.preface preserve=yes
//## end configuration::VisaResponseCode%5059C2280182.preface

//## Class: VisaResponseCode%5059C2280182
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5059C239014F;IF::Extract { -> F}
//## Uses: <unnamed>%5059C23C00C7;reusable::Query { -> F}

class DllExport VisaResponseCode : public ConversionItem  //## Inherits: <unnamed>%5059C2360262
{
  //## begin configuration::VisaResponseCode%5059C2280182.initialDeclarations preserve=yes
  //## end configuration::VisaResponseCode%5059C2280182.initialDeclarations

  public:
    //## Constructors (generated)
      VisaResponseCode();

    //## Destructor (generated)
      virtual ~VisaResponseCode();


    //## Other Operations (specified)
      //## Operation: bind%5059C27803B7
      virtual void bind (reusable::Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::VisaResponseCode%5059C2280182.public preserve=yes
      //## end configuration::VisaResponseCode%5059C2280182.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::VisaResponseCode%5059C2280182.protected preserve=yes
      //## end configuration::VisaResponseCode%5059C2280182.protected

  private:
    // Additional Private Declarations
      //## begin configuration::VisaResponseCode%5059C2280182.private preserve=yes
      //## end configuration::VisaResponseCode%5059C2280182.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::VisaResponseCode%5059C2280182.implementation preserve=yes
      //## end configuration::VisaResponseCode%5059C2280182.implementation

};

//## begin configuration::VisaResponseCode%5059C2280182.postscript preserve=yes
//## end configuration::VisaResponseCode%5059C2280182.postscript

} // namespace configuration

//## begin module%5059C94D025F.epilog preserve=yes
//## end module%5059C94D025F.epilog


#endif
