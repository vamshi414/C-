//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%39985C8E01BF.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%39985C8E01BF.cm

//## begin module%39985C8E01BF.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%39985C8E01BF.cp

//## Module: CXOSCF36%39985C8E01BF; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF36.cpp

//## begin module%39985C8E01BF.additionalIncludes preserve=no
//## end module%39985C8E01BF.additionalIncludes

//## begin module%39985C8E01BF.includes preserve=yes
// $Date:   Apr 17 2014 21:00:22  $ $Author:   e1009652  $ $Revision:   1.5  $
//## end module%39985C8E01BF.includes

#ifndef CXOSCF36_h
#include "CXODCF36.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%39985C8E01BF.declarations preserve=no
//## end module%39985C8E01BF.declarations

//## begin module%39985C8E01BF.additionalDeclarations preserve=yes
//## end module%39985C8E01BF.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::Base24POSResponseCode

Base24POSResponseCode::Base24POSResponseCode()
  //## begin Base24POSResponseCode::Base24POSResponseCode%39985CEF00F7_const.hasinit preserve=no
  //## end Base24POSResponseCode::Base24POSResponseCode%39985CEF00F7_const.hasinit
  //## begin Base24POSResponseCode::Base24POSResponseCode%39985CEF00F7_const.initialization preserve=yes
  //## end Base24POSResponseCode::Base24POSResponseCode%39985CEF00F7_const.initialization
{
  //## begin configuration::Base24POSResponseCode::Base24POSResponseCode%39985CEF00F7_const.body preserve=yes
   memcpy(m_sID,"CF36",4);
  //## end configuration::Base24POSResponseCode::Base24POSResponseCode%39985CEF00F7_const.body
}


Base24POSResponseCode::~Base24POSResponseCode()
{
  //## begin configuration::Base24POSResponseCode::~Base24POSResponseCode%39985CEF00F7_dest.body preserve=yes
  //## end configuration::Base24POSResponseCode::~Base24POSResponseCode%39985CEF00F7_dest.body
}



//## Other Operations (implementation)
void Base24POSResponseCode::bind (Query& hQuery)
{
  //## begin configuration::Base24POSResponseCode::bind%39993C0C00D9.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_B24_RESP_COD_POS");
   hQuery.bind("X_B24_RESP_COD_POS","B24_RESP_CODE_POS",Column::STRING,&m_strFirst);
   hQuery.bind("X_B24_RESP_COD_POS","ACTION_CODE",Column::STRING,&m_strSecond);
   hQuery.bind("X_B24_RESP_COD_POS","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_B24_RESP_COD_POS","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_B24_RESP_COD_POS","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_B24_RESP_COD_POS","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_B24_RESP_COD_POS.B24_RESP_CODE_POS ASC,X_B24_RESP_COD_POS.CUST_ID DESC");
  //## end configuration::Base24POSResponseCode::bind%39993C0C00D9.body
}

// Additional Declarations
  //## begin configuration::Base24POSResponseCode%39985CEF00F7.declarations preserve=yes
  //## end configuration::Base24POSResponseCode%39985CEF00F7.declarations

} // namespace configuration

//## begin module%39985C8E01BF.epilog preserve=yes
//## end module%39985C8E01BF.epilog
