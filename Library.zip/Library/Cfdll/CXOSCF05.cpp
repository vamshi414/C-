//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3910689C02C2.cm preserve=no
//	$Date:   Dec 07 2016 15:41:12  $ $Author:   e1009652  $
//	$Revision:   1.8  $
//## end module%3910689C02C2.cm

//## begin module%3910689C02C2.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3910689C02C2.cp

//## Module: CXOSCF05%3910689C02C2; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF05.cpp

//## begin module%3910689C02C2.additionalIncludes preserve=no
//## end module%3910689C02C2.additionalIncludes

//## begin module%3910689C02C2.includes preserve=yes
// $Date:   Dec 07 2016 15:41:12  $ $Author:   e1009652  $ $Revision:   1.8  $
//## end module%3910689C02C2.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif


//## begin module%3910689C02C2.declarations preserve=no
//## end module%3910689C02C2.declarations

//## begin module%3910689C02C2.additionalDeclarations preserve=yes
//## end module%3910689C02C2.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConversionItem 

ConversionItem::ConversionItem()
  //## begin ConversionItem::ConversionItem%391054860304_const.hasinit preserve=no
  //## end ConversionItem::ConversionItem%391054860304_const.hasinit
  //## begin ConversionItem::ConversionItem%391054860304_const.initialization preserve=yes
  //## end ConversionItem::ConversionItem%391054860304_const.initialization
{
  //## begin configuration::ConversionItem::ConversionItem%391054860304_const.body preserve=yes
   memcpy(m_sID,"CF05",4);
  //## end configuration::ConversionItem::ConversionItem%391054860304_const.body
}

ConversionItem::ConversionItem (const char* pszMember)
  //## begin configuration::ConversionItem::ConversionItem%3911D86A0201.hasinit preserve=no
  //## end configuration::ConversionItem::ConversionItem%3911D86A0201.hasinit
  //## begin configuration::ConversionItem::ConversionItem%3911D86A0201.initialization preserve=yes
  :m_strMember(pszMember)
  //## end configuration::ConversionItem::ConversionItem%3911D86A0201.initialization
{
  //## begin configuration::ConversionItem::ConversionItem%3911D86A0201.body preserve=yes
   memcpy(m_sID,"CF05",4);
  //## end configuration::ConversionItem::ConversionItem%3911D86A0201.body
}


ConversionItem::~ConversionItem()
{
  //## begin configuration::ConversionItem::~ConversionItem%391054860304_dest.body preserve=yes
  //## end configuration::ConversionItem::~ConversionItem%391054860304_dest.body
}



//## Other Operations (implementation)
void ConversionItem::bind (Query& hQuery)
{
  //## begin configuration::ConversionItem::bind%39107AF00319.body preserve=yes
  //## end configuration::ConversionItem::bind%39107AF00319.body
}

const string& ConversionItem::getFirst ()
{
  //## begin configuration::ConversionItem::getFirst%391C314802F4.body preserve=yes
   return m_strFirst;
  //## end configuration::ConversionItem::getFirst%391C314802F4.body
}

const string& ConversionItem::getSecond ()
{
  //## begin configuration::ConversionItem::getSecond%391C314A01CA.body preserve=yes
   return m_strSecond;
  //## end configuration::ConversionItem::getSecond%391C314A01CA.body
}

const string& ConversionItem::getThird ()
{
  //## begin configuration::ConversionItem::getThird%44BD1C52009C.body preserve=yes
   return m_strThird;
  //## end configuration::ConversionItem::getThird%44BD1C52009C.body
}

void ConversionItem::setPredicate (Query& hQuery)
{
  //## begin configuration::ConversionItem::setPredicate%583DCA770057.body preserve=yes
   string strCUST_ID;
   IF::Extract::instance()->getSpec("CUSTOMER", strCUST_ID);
   vector<Table>& hTable = hQuery.getTable();
   if (hTable.size() != 1)
      return;
   string strTableName = hTable[0].getTableName();
   hQuery.setBasicPredicate(strTableName.c_str(), "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate(strTableName.c_str(), "CC_STATE", "=", "A");
   string strTemp = "('" + strCUST_ID + "','****')";
   hQuery.setBasicPredicate(strTableName.c_str(), "CUST_ID", "IN", strTemp.c_str());
  //## end configuration::ConversionItem::setPredicate%583DCA770057.body
}

// Additional Declarations
  //## begin configuration::ConversionItem%391054860304.declarations preserve=yes
  //## end configuration::ConversionItem%391054860304.declarations

} // namespace configuration

//## begin module%3910689C02C2.epilog preserve=yes
//## end module%3910689C02C2.epilog
