//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%391C10F10190.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%391C10F10190.cm

//## begin module%391C10F10190.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%391C10F10190.cp

//## Module: CXOSCF15%391C10F10190; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF15.hpp

#ifndef CXOSCF15_h
#define CXOSCF15_h 1

//## begin module%391C10F10190.additionalIncludes preserve=no
//## end module%391C10F10190.additionalIncludes

//## begin module%391C10F10190.includes preserve=yes
// $Date:   Apr 08 2004 14:10:52  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%391C10F10190.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%391C10F10190.declarations preserve=no
//## end module%391C10F10190.declarations

//## begin module%391C10F10190.additionalDeclarations preserve=yes
//## end module%391C10F10190.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::PlusCorrectionReason%391C0C7E011A.preface preserve=yes
//## end configuration::PlusCorrectionReason%391C0C7E011A.preface

//## Class: PlusCorrectionReason%391C0C7E011A
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%391C16D50243;IF::Extract { -> F}
//## Uses: <unnamed>%391C16D7014C;reusable::Query { -> F}

class DllExport PlusCorrectionReason : public ConversionItem  //## Inherits: <unnamed>%391C16D303E5
{
  //## begin configuration::PlusCorrectionReason%391C0C7E011A.initialDeclarations preserve=yes
  //## end configuration::PlusCorrectionReason%391C0C7E011A.initialDeclarations

  public:
    //## Constructors (generated)
      PlusCorrectionReason();

    //## Destructor (generated)
      virtual ~PlusCorrectionReason();


    //## Other Operations (specified)
      //## Operation: bind%391C1BE60126
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::PlusCorrectionReason%391C0C7E011A.public preserve=yes
      //## end configuration::PlusCorrectionReason%391C0C7E011A.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::PlusCorrectionReason%391C0C7E011A.protected preserve=yes
      //## end configuration::PlusCorrectionReason%391C0C7E011A.protected

  private:
    // Additional Private Declarations
      //## begin configuration::PlusCorrectionReason%391C0C7E011A.private preserve=yes
      //## end configuration::PlusCorrectionReason%391C0C7E011A.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::PlusCorrectionReason%391C0C7E011A.implementation preserve=yes
      //## end configuration::PlusCorrectionReason%391C0C7E011A.implementation

};

//## begin configuration::PlusCorrectionReason%391C0C7E011A.postscript preserve=yes
//## end configuration::PlusCorrectionReason%391C0C7E011A.postscript

} // namespace configuration

//## begin module%391C10F10190.epilog preserve=yes
using namespace configuration;
//## end module%391C10F10190.epilog


#endif
