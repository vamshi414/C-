//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%425EAE8501A5.cm preserve=no
//	$Date:   Dec 12 2016 13:48:30  $ $Author:   e1009652  $
//	$Revision:   1.3  $
//## end module%425EAE8501A5.cm

//## begin module%425EAE8501A5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%425EAE8501A5.cp

//## Module: CXOSCF73%425EAE8501A5; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF73.hpp

#ifndef CXOSCF73_h
#define CXOSCF73_h 1

//## begin module%425EAE8501A5.additionalIncludes preserve=no
//## end module%425EAE8501A5.additionalIncludes

//## begin module%425EAE8501A5.includes preserve=yes
//## end module%425EAE8501A5.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%425EAE8501A5.declarations preserve=no
//## end module%425EAE8501A5.declarations

//## begin module%425EAE8501A5.additionalDeclarations preserve=yes
//## end module%425EAE8501A5.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::CountryCode2to3%425EB2F002BF.preface preserve=yes
//## end configuration::CountryCode2to3%425EB2F002BF.preface

//## Class: CountryCode2to3%425EB2F002BF
//	This Class converts 2 bytes Country Code into 3 bytes
//	Country Code
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%425EB3DD005D;reusable::Query { -> F}
//## Uses: <unnamed>%584EFE8B009D;IF::Extract { -> F}

class DllExport CountryCode2to3 : public ConversionItem  //## Inherits: <unnamed>%425EB39E0280
{
  //## begin configuration::CountryCode2to3%425EB2F002BF.initialDeclarations preserve=yes
  //## end configuration::CountryCode2to3%425EB2F002BF.initialDeclarations

  public:
    //## Constructors (generated)
      CountryCode2to3();

    //## Destructor (generated)
      virtual ~CountryCode2to3();


    //## Other Operations (specified)
      //## Operation: bind%425EB3280280
      virtual void bind (Query& hQuery);

      //## Operation: getSecond%43E109BF01AA
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::CountryCode2to3%425EB2F002BF.public preserve=yes
      //## end configuration::CountryCode2to3%425EB2F002BF.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::CountryCode2to3%425EB2F002BF.protected preserve=yes
      //## end configuration::CountryCode2to3%425EB2F002BF.protected

  private:
    // Additional Private Declarations
      //## begin configuration::CountryCode2to3%425EB2F002BF.private preserve=yes
      //## end configuration::CountryCode2to3%425EB2F002BF.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::CountryCode2to3%425EB2F002BF.implementation preserve=yes
      //## end configuration::CountryCode2to3%425EB2F002BF.implementation

};

//## begin configuration::CountryCode2to3%425EB2F002BF.postscript preserve=yes
//## end configuration::CountryCode2to3%425EB2F002BF.postscript

} // namespace configuration

//## begin module%425EAE8501A5.epilog preserve=yes
//## end module%425EAE8501A5.epilog


#endif
