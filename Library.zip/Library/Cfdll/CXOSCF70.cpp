//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%5059C9F3032B.cm preserve=no
//	$Date:   Apr 17 2014 21:06:04  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%5059C9F3032B.cm

//## begin module%5059C9F3032B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5059C9F3032B.cp

//## Module: CXOSCF70%5059C9F3032B; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF70.cpp

//## begin module%5059C9F3032B.additionalIncludes preserve=no
//## end module%5059C9F3032B.additionalIncludes

//## begin module%5059C9F3032B.includes preserve=yes
//## end module%5059C9F3032B.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF70_h
#include "CXODCF70.hpp"
#endif


//## begin module%5059C9F3032B.declarations preserve=no
//## end module%5059C9F3032B.declarations

//## begin module%5059C9F3032B.additionalDeclarations preserve=yes
//## end module%5059C9F3032B.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::MasterCardAdviceReason 

MasterCardAdviceReason::MasterCardAdviceReason()
  //## begin MasterCardAdviceReason::MasterCardAdviceReason%5059C1E60128_const.hasinit preserve=no
  //## end MasterCardAdviceReason::MasterCardAdviceReason%5059C1E60128_const.hasinit
  //## begin MasterCardAdviceReason::MasterCardAdviceReason%5059C1E60128_const.initialization preserve=yes
   : ConversionItem("## CR98 XLATE MC ADVICE REASON")
  //## end MasterCardAdviceReason::MasterCardAdviceReason%5059C1E60128_const.initialization
{
  //## begin configuration::MasterCardAdviceReason::MasterCardAdviceReason%5059C1E60128_const.body preserve=yes
   memcpy(m_sID,"CF70",4);
  //## end configuration::MasterCardAdviceReason::MasterCardAdviceReason%5059C1E60128_const.body
}


MasterCardAdviceReason::~MasterCardAdviceReason()
{
  //## begin configuration::MasterCardAdviceReason::~MasterCardAdviceReason%5059C1E60128_dest.body preserve=yes
  //## end configuration::MasterCardAdviceReason::~MasterCardAdviceReason%5059C1E60128_dest.body
}



//## Other Operations (implementation)
void MasterCardAdviceReason::bind (reusable::Query& hQuery)
{
  //## begin configuration::MasterCardAdviceReason::bind%5059C2660075.body preserve=yes
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.setQualifier("QUALIFY","X_MC_ADVICE_REASON");
   hQuery.bind("X_MC_ADVICE_REASON","MC_ADVICE_REASON",Column::STRING,&m_strFirst);
   hQuery.bind("X_MC_ADVICE_REASON","MSG_REASON_CODE",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_MC_ADVICE_REASON","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_MC_ADVICE_REASON","CC_STATE","=","A");
   string strTemp = "('" + strCUST_ID + "','****')";
   hQuery.setBasicPredicate("X_MC_ADVICE_REASON","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_MC_ADVICE_REASON.MC_ADVICE_REASON ASC,X_MC_ADVICE_REASON.CUST_ID DESC");
  //## end configuration::MasterCardAdviceReason::bind%5059C2660075.body
}

// Additional Declarations
  //## begin configuration::MasterCardAdviceReason%5059C1E60128.declarations preserve=yes
  //## end configuration::MasterCardAdviceReason%5059C1E60128.declarations

} // namespace configuration

//## begin module%5059C9F3032B.epilog preserve=yes
//## end module%5059C9F3032B.epilog
