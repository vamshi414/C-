//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%54AD2EC30113.cm preserve=no
//	$Date:   Dec 12 2016 13:28:34  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%54AD2EC30113.cm

//## begin module%54AD2EC30113.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%54AD2EC30113.cp

//## Module: CXOSCFA3%54AD2EC30113; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCFA3.hpp

#ifndef CXOSCFA3_h
#define CXOSCFA3_h 1

//## begin module%54AD2EC30113.additionalIncludes preserve=no
//## end module%54AD2EC30113.additionalIncludes

//## begin module%54AD2EC30113.includes preserve=yes
//## end module%54AD2EC30113.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%54AD2EC30113.declarations preserve=no
//## end module%54AD2EC30113.declarations

//## begin module%54AD2EC30113.additionalDeclarations preserve=yes
//## end module%54AD2EC30113.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ProcessorName%54AF8BB30160.preface preserve=yes
//## end configuration::ProcessorName%54AF8BB30160.preface

//## Class: ProcessorName%54AF8BB30160
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%54AF8CE803DB;IF::Extract { -> F}
//## Uses: <unnamed>%54AF8D0E03AC;reusable::Query { -> F}

class DllExport ProcessorName : public ConversionItem  //## Inherits: <unnamed>%54AF8CAD03CF
{
  //## begin configuration::ProcessorName%54AF8BB30160.initialDeclarations preserve=yes
  //## end configuration::ProcessorName%54AF8BB30160.initialDeclarations

  public:
    //## Constructors (generated)
      ProcessorName();

    //## Destructor (generated)
      virtual ~ProcessorName();


    //## Other Operations (specified)
      //## Operation: bind%54AF9DD20095
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%5847187B0317
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ProcessorName%54AF8BB30160.public preserve=yes
      //## end configuration::ProcessorName%54AF8BB30160.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ProcessorName%54AF8BB30160.protected preserve=yes
      //## end configuration::ProcessorName%54AF8BB30160.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ProcessorName%54AF8BB30160.private preserve=yes
      //## end configuration::ProcessorName%54AF8BB30160.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ProcessorName%54AF8BB30160.implementation preserve=yes
      //## end configuration::ProcessorName%54AF8BB30160.implementation

};

//## begin configuration::ProcessorName%54AF8BB30160.postscript preserve=yes
//## end configuration::ProcessorName%54AF8BB30160.postscript

} // namespace configuration

//## begin module%54AD2EC30113.epilog preserve=yes
//## end module%54AD2EC30113.epilog


#endif
