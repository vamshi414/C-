//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%391C11350152.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%391C11350152.cm

//## begin module%391C11350152.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%391C11350152.cp

//## Module: CXOSCF21%391C11350152; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF21.hpp

#ifndef CXOSCF21_h
#define CXOSCF21_h 1

//## begin module%391C11350152.additionalIncludes preserve=no
//## end module%391C11350152.additionalIncludes

//## begin module%391C11350152.includes preserve=yes
// $Date:   Apr 08 2004 14:10:54  $ $Author:   D02405  $ $Revision:   1.4  $
//## end module%391C11350152.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%391C11350152.declarations preserve=no
//## end module%391C11350152.declarations

//## begin module%391C11350152.additionalDeclarations preserve=yes
//## end module%391C11350152.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexProcessCode%391C0CE003A6.preface preserve=yes
//## end configuration::ConnexProcessCode%391C0CE003A6.preface

//## Class: ConnexProcessCode%391C0CE003A6
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%391C183B025C;IF::Extract { -> F}
//## Uses: <unnamed>%391C183D0255;reusable::Query { -> F}

class DllExport ConnexProcessCode : public ConversionItem  //## Inherits: <unnamed>%391C183A0020
{
  //## begin configuration::ConnexProcessCode%391C0CE003A6.initialDeclarations preserve=yes
  //## end configuration::ConnexProcessCode%391C0CE003A6.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexProcessCode();

    //## Destructor (generated)
      virtual ~ConnexProcessCode();


    //## Other Operations (specified)
      //## Operation: bind%391C1C730331
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>II
      //	<h2>MS
      //	<h3>Configure Connex Process Code table
      //	<p>
      //	The Connex Process Code table (&qualify.X_ADV_PROC_CODE)
      //	is used to determine a value for the transaction type
      //	identifier (&custqual.FIN_Lyyyymm.TRAN_TYPE_ID) during
      //	financial transaction loading.
      //	<p>
      //	The Connex Process Code table is populated during
      //	initial server installation.  Use the CR Editor to add
      //	or update rows whenever the eFunds Connex on IBM
      //	acquiring platform introduces new values in any of the
      //	following columns:
      //	PROCESS CODE
      //	MESSAGE CLASS
      //	</body>
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%391C1C73033B
      virtual const string& getFirst ();

      //## Operation: getSecond%392052B60109
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::ConnexProcessCode%391C0CE003A6.public preserve=yes
      //## end configuration::ConnexProcessCode%391C0CE003A6.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexProcessCode%391C0CE003A6.protected preserve=yes
      //## end configuration::ConnexProcessCode%391C0CE003A6.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexProcessCode%391C0CE003A6.private preserve=yes
      //## end configuration::ConnexProcessCode%391C0CE003A6.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: IBM_PROCESS_CODE%391C1C3201D9
      //## begin configuration::ConnexProcessCode::IBM_PROCESS_CODE%391C1C3201D9.attr preserve=no  private: string {U} 
      string m_strIBM_PROCESS_CODE;
      //## end configuration::ConnexProcessCode::IBM_PROCESS_CODE%391C1C3201D9.attr

      //## Attribute: IBM_MSG_CLASS%391C1C48014F
      //## begin configuration::ConnexProcessCode::IBM_MSG_CLASS%391C1C48014F.attr preserve=no  private: string {U} 
      string m_strIBM_MSG_CLASS;
      //## end configuration::ConnexProcessCode::IBM_MSG_CLASS%391C1C48014F.attr

      //## Attribute: PROCESS_CODE%391C1C3201E3
      //## begin configuration::ConnexProcessCode::PROCESS_CODE%391C1C3201E3.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::ConnexProcessCode::PROCESS_CODE%391C1C3201E3.attr

      //## Attribute: MSG_CLASS%391C1C3201ED
      //## begin configuration::ConnexProcessCode::MSG_CLASS%391C1C3201ED.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::ConnexProcessCode::MSG_CLASS%391C1C3201ED.attr

      //## Attribute: PRE_AUTH%391C1C3201EE
      //## begin configuration::ConnexProcessCode::PRE_AUTH%391C1C3201EE.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::ConnexProcessCode::PRE_AUTH%391C1C3201EE.attr

      //## Attribute: MEDIA_TYPE%392052B000E2
      //## begin configuration::ConnexProcessCode::MEDIA_TYPE%392052B000E2.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::ConnexProcessCode::MEDIA_TYPE%392052B000E2.attr

    // Additional Implementation Declarations
      //## begin configuration::ConnexProcessCode%391C0CE003A6.implementation preserve=yes
      //## end configuration::ConnexProcessCode%391C0CE003A6.implementation

};

//## begin configuration::ConnexProcessCode%391C0CE003A6.postscript preserve=yes
//## end configuration::ConnexProcessCode%391C0CE003A6.postscript

} // namespace configuration

//## begin module%391C11350152.epilog preserve=yes
using namespace configuration;
//## end module%391C11350152.epilog


#endif
