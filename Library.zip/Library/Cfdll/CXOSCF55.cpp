//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFC72160128.cm preserve=no
//	$Date:   Dec 16 2016 15:23:56  $ $Author:   e1009652  $
//	$Revision:   1.4  $
//## end module%3FFC72160128.cm

//## begin module%3FFC72160128.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFC72160128.cp

//## Module: CXOSCF55%3FFC72160128; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF55.cpp

//## begin module%3FFC72160128.additionalIncludes preserve=no
//## end module%3FFC72160128.additionalIncludes

//## begin module%3FFC72160128.includes preserve=yes
// $Date:   Dec 16 2016 15:23:56  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%3FFC72160128.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF55_h
#include "CXODCF55.hpp"
#endif
//## begin module%3FFC72160128.declarations preserve=no
//## end module%3FFC72160128.declarations

//## begin module%3FFC72160128.additionalDeclarations preserve=yes
//## end module%3FFC72160128.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexPOSConditionCode6 

ConnexPOSConditionCode6::ConnexPOSConditionCode6()
  //## begin ConnexPOSConditionCode6::ConnexPOSConditionCode6%3FFC71480271_const.hasinit preserve=no
  //## end ConnexPOSConditionCode6::ConnexPOSConditionCode6%3FFC71480271_const.hasinit
  //## begin ConnexPOSConditionCode6::ConnexPOSConditionCode6%3FFC71480271_const.initialization preserve=yes
   : ConversionItem("## CR67 XLATE POS CON COD6")
  //## end ConnexPOSConditionCode6::ConnexPOSConditionCode6%3FFC71480271_const.initialization
{
  //## begin configuration::ConnexPOSConditionCode6::ConnexPOSConditionCode6%3FFC71480271_const.body preserve=yes
   memcpy(m_sID,"CF55",4);
  //## end configuration::ConnexPOSConditionCode6::ConnexPOSConditionCode6%3FFC71480271_const.body
}


ConnexPOSConditionCode6::~ConnexPOSConditionCode6()
{
  //## begin configuration::ConnexPOSConditionCode6::~ConnexPOSConditionCode6%3FFC71480271_dest.body preserve=yes
  //## end configuration::ConnexPOSConditionCode6::~ConnexPOSConditionCode6%3FFC71480271_dest.body
}



//## Other Operations (implementation)
void ConnexPOSConditionCode6::bind (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode6::bind%3FFC7158007D.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_IBM_POS_COND_COD");
   hQuery.bind("X_IBM_POS_COND_COD","POS_COND_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_POS_COND_COD","POS_TERM_OUT_CAP",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IBM_POS_COND_COD.POS_COND_CODE ASC");
  //## end configuration::ConnexPOSConditionCode6::bind%3FFC7158007D.body
}

void ConnexPOSConditionCode6::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode6::setPredicate%5847164C01EC.body preserve=yes
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_STATE", "=", "A");
  //## end configuration::ConnexPOSConditionCode6::setPredicate%5847164C01EC.body
}

// Additional Declarations
  //## begin configuration::ConnexPOSConditionCode6%3FFC71480271.declarations preserve=yes
  //## end configuration::ConnexPOSConditionCode6%3FFC71480271.declarations

} // namespace configuration

//## begin module%3FFC72160128.epilog preserve=yes
//## end module%3FFC72160128.epilog
