//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40A51CEB0399.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40A51CEB0399.cm

//## begin module%40A51CEB0399.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40A51CEB0399.cp

//## Module: CXOSCF65%40A51CEB0399; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF65.hpp

#ifndef CXOSCF65_h
#define CXOSCF65_h 1

//## begin module%40A51CEB0399.additionalIncludes preserve=no
//## end module%40A51CEB0399.additionalIncludes

//## begin module%40A51CEB0399.includes preserve=yes
// $Date:   Jun 11 2004 11:49:18  $ $Author:   D92233  $ $Revision:   1.1  $
//## end module%40A51CEB0399.includes

#ifndef CXOSCF64_h
#include "CXODCF64.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
class Trace;

} // namespace IF

//## begin module%40A51CEB0399.declarations preserve=no
//## end module%40A51CEB0399.declarations

//## begin module%40A51CEB0399.additionalDeclarations preserve=yes
//## end module%40A51CEB0399.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::OasisOCSPresentmentMap%40A3850E037A.preface preserve=yes
//## end configuration::OasisOCSPresentmentMap%40A3850E037A.preface

//## Class: OasisOCSPresentmentMap%40A3850E037A
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40A90438036B;IF::FlatFile { -> F}
//## Uses: <unnamed>%40A9047803A9;IF::Trace { -> F}

class DllExport OasisOCSPresentmentMap : public ImportMapItem  //## Inherits: <unnamed>%40A387F100AB
{
  //## begin configuration::OasisOCSPresentmentMap%40A3850E037A.initialDeclarations preserve=yes
  //## end configuration::OasisOCSPresentmentMap%40A3850E037A.initialDeclarations

  public:
    //## Constructors (generated)
      OasisOCSPresentmentMap();

    //## Destructor (generated)
      virtual ~OasisOCSPresentmentMap();


    //## Other Operations (specified)
      //## Operation: loadDataMap%40A5202F038A
      virtual bool loadDataMap ();

    // Additional Public Declarations
      //## begin configuration::OasisOCSPresentmentMap%40A3850E037A.public preserve=yes
      //## end configuration::OasisOCSPresentmentMap%40A3850E037A.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::OasisOCSPresentmentMap%40A3850E037A.protected preserve=yes
      //## end configuration::OasisOCSPresentmentMap%40A3850E037A.protected

  private:
    // Additional Private Declarations
      //## begin configuration::OasisOCSPresentmentMap%40A3850E037A.private preserve=yes
      //## end configuration::OasisOCSPresentmentMap%40A3850E037A.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::OasisOCSPresentmentMap%40A3850E037A.implementation preserve=yes
      //## end configuration::OasisOCSPresentmentMap%40A3850E037A.implementation

};

//## begin configuration::OasisOCSPresentmentMap%40A3850E037A.postscript preserve=yes
//## end configuration::OasisOCSPresentmentMap%40A3850E037A.postscript

} // namespace configuration

//## begin module%40A51CEB0399.epilog preserve=yes
using namespace configuration;
//## end module%40A51CEB0399.epilog


#endif
