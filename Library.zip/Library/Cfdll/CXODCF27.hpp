//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%393E6BA5034A.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%393E6BA5034A.cm

//## begin module%393E6BA5034A.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%393E6BA5034A.cp

//## Module: CXOSCF27%393E6BA5034A; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF27.hpp

#ifndef CXOSCF27_h
#define CXOSCF27_h 1

//## begin module%393E6BA5034A.additionalIncludes preserve=no
//## end module%393E6BA5034A.additionalIncludes

//## begin module%393E6BA5034A.includes preserve=yes
// $Date:   Apr 08 2004 14:10:56  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%393E6BA5034A.includes

#ifndef CXOSCF26_h
#include "CXODCF26.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%393E6BA5034A.declarations preserve=no
//## end module%393E6BA5034A.declarations

//## begin module%393E6BA5034A.additionalDeclarations preserve=yes
//## end module%393E6BA5034A.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::TransactionTypeIdentifier%393E6D4A033B.preface preserve=yes
//## end configuration::TransactionTypeIdentifier%393E6D4A033B.preface

//## Class: TransactionTypeIdentifier%393E6D4A033B
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%393E74C4031F;IF::Extract { -> F}
//## Uses: <unnamed>%393E74CA0274;reusable::Query { -> F}

class DllExport TransactionTypeIdentifier : public VerificationItem  //## Inherits: <unnamed>%393E74C20100
{
  //## begin configuration::TransactionTypeIdentifier%393E6D4A033B.initialDeclarations preserve=yes
  //## end configuration::TransactionTypeIdentifier%393E6D4A033B.initialDeclarations

  public:
    //## Constructors (generated)
      TransactionTypeIdentifier();

    //## Destructor (generated)
      virtual ~TransactionTypeIdentifier();


    //## Other Operations (specified)
      //## Operation: bind%393E74D9012B
      virtual void bind (Query& hQuery);

      //## Operation: getKey%393E74D90153
      virtual const string& getKey ();

    // Additional Public Declarations
      //## begin configuration::TransactionTypeIdentifier%393E6D4A033B.public preserve=yes
      //## end configuration::TransactionTypeIdentifier%393E6D4A033B.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::TransactionTypeIdentifier%393E6D4A033B.protected preserve=yes
      //## end configuration::TransactionTypeIdentifier%393E6D4A033B.protected

  private:
    // Additional Private Declarations
      //## begin configuration::TransactionTypeIdentifier%393E6D4A033B.private preserve=yes
      //## end configuration::TransactionTypeIdentifier%393E6D4A033B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: PROCESS_CODE%393E74F203DA
      //## begin configuration::TransactionTypeIdentifier::PROCESS_CODE%393E74F203DA.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::TransactionTypeIdentifier::PROCESS_CODE%393E74F203DA.attr

      //## Attribute: MSG_CLASS%393E74F30024
      //## begin configuration::TransactionTypeIdentifier::MSG_CLASS%393E74F30024.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::TransactionTypeIdentifier::MSG_CLASS%393E74F30024.attr

      //## Attribute: PRE_AUTH%393E74F30056
      //## begin configuration::TransactionTypeIdentifier::PRE_AUTH%393E74F30056.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::TransactionTypeIdentifier::PRE_AUTH%393E74F30056.attr

      //## Attribute: MEDIA_TYPE%393E74F3007E
      //## begin configuration::TransactionTypeIdentifier::MEDIA_TYPE%393E74F3007E.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::TransactionTypeIdentifier::MEDIA_TYPE%393E74F3007E.attr

    // Additional Implementation Declarations
      //## begin configuration::TransactionTypeIdentifier%393E6D4A033B.implementation preserve=yes
      //## end configuration::TransactionTypeIdentifier%393E6D4A033B.implementation

};

//## begin configuration::TransactionTypeIdentifier%393E6D4A033B.postscript preserve=yes
//## end configuration::TransactionTypeIdentifier%393E6D4A033B.postscript

} // namespace configuration

//## begin module%393E6BA5034A.epilog preserve=yes
using namespace configuration;
//## end module%393E6BA5034A.epilog


#endif
