//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%393FFE0C0013.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%393FFE0C0013.cm

//## begin module%393FFE0C0013.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%393FFE0C0013.cp

//## Module: CXOSCF29%393FFE0C0013; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF29.cpp

//## begin module%393FFE0C0013.additionalIncludes preserve=no
//## end module%393FFE0C0013.additionalIncludes

//## begin module%393FFE0C0013.includes preserve=yes
// $Date:   Apr 08 2004 14:11:16  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%393FFE0C0013.includes

#ifndef CXOSCF29_h
#include "CXODCF29.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%393FFE0C0013.declarations preserve=no
//## end module%393FFE0C0013.declarations

//## begin module%393FFE0C0013.additionalDeclarations preserve=yes
//## end module%393FFE0C0013.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::CardOwnerType

CardOwnerType::CardOwnerType()
  //## begin CardOwnerType::CardOwnerType%393FFCF1034B_const.hasinit preserve=no
  //## end CardOwnerType::CardOwnerType%393FFCF1034B_const.hasinit
  //## begin CardOwnerType::CardOwnerType%393FFCF1034B_const.initialization preserve=yes
   : VerificationItem("## CR30 VERIFY CARD OWNER")
  //## end CardOwnerType::CardOwnerType%393FFCF1034B_const.initialization
{
  //## begin configuration::CardOwnerType::CardOwnerType%393FFCF1034B_const.body preserve=yes
   memcpy(m_sID,"CF29",4);
  //## end configuration::CardOwnerType::CardOwnerType%393FFCF1034B_const.body
}


CardOwnerType::~CardOwnerType()
{
  //## begin configuration::CardOwnerType::~CardOwnerType%393FFCF1034B_dest.body preserve=yes
  //## end configuration::CardOwnerType::~CardOwnerType%393FFCF1034B_dest.body
}



//## Other Operations (implementation)
void CardOwnerType::bind (Query& hQuery)
{
  //## begin configuration::CardOwnerType::bind%393FFD3B0370.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","CARD_OWNER_TYPE");
   hQuery.bind("CARD_OWNER_TYPE","CARD_OWNER_TYPE",Column::STRING,&m_strKey);
   hQuery.bind("CARD_OWNER_TYPE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("CARD_OWNER_TYPE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("CARD_OWNER_TYPE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("CARD_OWNER_TYPE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("CARD_OWNER_TYPE.CUST_ID DESC");
  //## end configuration::CardOwnerType::bind%393FFD3B0370.body
}

// Additional Declarations
  //## begin configuration::CardOwnerType%393FFCF1034B.declarations preserve=yes
  //## end configuration::CardOwnerType%393FFCF1034B.declarations

} // namespace configuration

//## begin module%393FFE0C0013.epilog preserve=yes
//## end module%393FFE0C0013.epilog
