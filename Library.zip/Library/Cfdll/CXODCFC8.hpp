//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%623C78520126.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%623C78520126.cm

//## begin module%623C78520126.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%623C78520126.cp

//## Module: CXOSCFC8%623C78520126; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCFC8.hpp

#ifndef CXOSCFC8_h
#define CXOSCFC8_h 1

//## begin module%623C78520126.additionalIncludes preserve=no
//## end module%623C78520126.additionalIncludes

//## begin module%623C78520126.includes preserve=yes
//## end module%623C78520126.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%623C78520126.declarations preserve=no
//## end module%623C78520126.declarations

//## begin module%623C78520126.additionalDeclarations preserve=yes
//## end module%623C78520126.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::NYCEProcCode%623C77F303C8.preface preserve=yes
//## end configuration::NYCEProcCode%623C77F303C8.preface

//## Class: NYCEProcCode%623C77F303C8
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%623C781D010F;IF::Extract { -> F}
//## Uses: <unnamed>%623C78200310;reusable::Query { -> F}

class DllExport NYCEProcCode : public ConversionItem  //## Inherits: <unnamed>%623C780901C4
{
  //## begin configuration::NYCEProcCode%623C77F303C8.initialDeclarations preserve=yes
  //## end configuration::NYCEProcCode%623C77F303C8.initialDeclarations

  public:
    //## Constructors (generated)
      NYCEProcCode();

    //## Destructor (generated)
      virtual ~NYCEProcCode();


    //## Other Operations (specified)
      //## Operation: bind%623C78DC00EE
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%623C78DC00F5
      virtual const string& getFirst ();

      //## Operation: getSecond%623C78DC00FE
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::NYCEProcCode%623C77F303C8.public preserve=yes
      //## end configuration::NYCEProcCode%623C77F303C8.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::NYCEProcCode%623C77F303C8.protected preserve=yes
      //## end configuration::NYCEProcCode%623C77F303C8.protected

  private:
    // Additional Private Declarations
      //## begin configuration::NYCEProcCode%623C77F303C8.private preserve=yes
      //## end configuration::NYCEProcCode%623C77F303C8.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: PROCESS_CODE%623C78E50131
      //## begin configuration::NYCEProcCode::PROCESS_CODE%623C78E50131.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::NYCEProcCode::PROCESS_CODE%623C78E50131.attr

      //## Attribute: MSG_CLASS%623C78E5013B
      //## begin configuration::NYCEProcCode::MSG_CLASS%623C78E5013B.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::NYCEProcCode::MSG_CLASS%623C78E5013B.attr

      //## Attribute: PRE_AUTH%623C78E50144
      //## begin configuration::NYCEProcCode::PRE_AUTH%623C78E50144.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::NYCEProcCode::PRE_AUTH%623C78E50144.attr

      //## Attribute: MEDIA_TYPE%623C78E5014F
      //## begin configuration::NYCEProcCode::MEDIA_TYPE%623C78E5014F.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::NYCEProcCode::MEDIA_TYPE%623C78E5014F.attr

    // Additional Implementation Declarations
      //## begin configuration::NYCEProcCode%623C77F303C8.implementation preserve=yes
      //## end configuration::NYCEProcCode%623C77F303C8.implementation

};

//## begin configuration::NYCEProcCode%623C77F303C8.postscript preserve=yes
//## end configuration::NYCEProcCode%623C77F303C8.postscript

} // namespace configuration

//## begin module%623C78520126.epilog preserve=yes
//## end module%623C78520126.epilog


#endif
