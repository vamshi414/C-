//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%393E6B9E030E.cm preserve=no
//	$Date:   Jan 04 2019 08:48:06  $ $Author:   e1009839  $
//	$Revision:   1.6  $
//## end module%393E6B9E030E.cm

//## begin module%393E6B9E030E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%393E6B9E030E.cp

//## Module: CXOSCF25%393E6B9E030E; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF25.hpp

#ifndef CXOSCF25_h
#define CXOSCF25_h 1

//## begin module%393E6B9E030E.additionalIncludes preserve=no
//## end module%393E6B9E030E.additionalIncludes

//## begin module%393E6B9E030E.includes preserve=yes
// $Date:   Jan 04 2019 08:48:06  $ $Author:   e1009839  $ $Revision:   1.6  $
//## end module%393E6B9E030E.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSCF26_h
#include "CXODCF26.hpp"
#endif
#ifndef CXOSCF24_h
#include "CXODCF24.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationFactory;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
class Global;
class Thread;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
class Count;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%393E6B9E030E.declarations preserve=no
//## end module%393E6B9E030E.declarations

//## begin module%393E6B9E030E.additionalDeclarations preserve=yes
//## end module%393E6B9E030E.additionalDeclarations


namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::VerificationLoader%393E6D44008A.preface preserve=yes
//## end configuration::VerificationLoader%393E6D44008A.preface

//## Class: VerificationLoader%393E6D44008A
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%393E713A00EC;monitor::Count { -> F}
//## Uses: <unnamed>%393E713C0063;ConfigurationFactory { -> F}
//## Uses: <unnamed>%393E713E016A;reusable::Global { -> F}
//## Uses: <unnamed>%393E714203A0;reusable::Query { -> F}
//## Uses: <unnamed>%393E71450098;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%393E714701B3;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3D2B06C00261;monitor::UseCase { -> F}
//## Uses: <unnamed>%5BF9356A018D;reusable::Thread { -> F}

class DllExport VerificationLoader : public reusable::Observer  //## Inherits: <unnamed>%393E711E03D1
{
  //## begin configuration::VerificationLoader%393E6D44008A.initialDeclarations preserve=yes
  //## end configuration::VerificationLoader%393E6D44008A.initialDeclarations

  public:
    //## Constructors (generated)
      VerificationLoader();

    //## Destructor (generated)
      virtual ~VerificationLoader();


    //## Other Operations (specified)
      //## Operation: instance%393E708503B3
      static VerificationLoader* instance ();

      //## Operation: populate%393E708503DB
      bool populate (VerificationTable* pVerificationTable);

      //## Operation: update%393E70860011
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin configuration::VerificationLoader%393E6D44008A.public preserve=yes
      //## end configuration::VerificationLoader%393E6D44008A.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::VerificationLoader%393E6D44008A.protected preserve=yes
      //## end configuration::VerificationLoader%393E6D44008A.protected

  private:
    // Additional Private Declarations
      //## begin configuration::VerificationLoader%393E6D44008A.private preserve=yes
      //## end configuration::VerificationLoader%393E6D44008A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5C05A507024F
      //## begin configuration::VerificationLoader::Instance%5C05A507024F.attr preserve=no  private: static vector<VerificationLoader*>* {V} 0
      static vector<VerificationLoader*>* m_pInstance;
      //## end configuration::VerificationLoader::Instance%5C05A507024F.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Configuration_CAT::<unnamed>%393E71220200
      //## Role: VerificationLoader::<m_pVerificationTable>%393E7123011B
      //## begin configuration::VerificationLoader::<m_pVerificationTable>%393E7123011B.role preserve=no  public: configuration::VerificationTable { -> RHgN}
      VerificationTable *m_pVerificationTable;
      //## end configuration::VerificationLoader::<m_pVerificationTable>%393E7123011B.role

      //## Association: DataNavigator Foundation::Configuration_CAT::<unnamed>%393E71250240
      //## Role: VerificationLoader::<m_pVerificationItem>%393E712600ED
      //## begin configuration::VerificationLoader::<m_pVerificationItem>%393E712600ED.role preserve=no  public: configuration::VerificationItem { -> RHgN}
      VerificationItem *m_pVerificationItem;
      //## end configuration::VerificationLoader::<m_pVerificationItem>%393E712600ED.role

    // Additional Implementation Declarations
      //## begin configuration::VerificationLoader%393E6D44008A.implementation preserve=yes
      //## end configuration::VerificationLoader%393E6D44008A.implementation

};

//## begin configuration::VerificationLoader%393E6D44008A.postscript preserve=yes
//## end configuration::VerificationLoader%393E6D44008A.postscript

} // namespace configuration

//## begin module%393E6B9E030E.epilog preserve=yes
using namespace configuration;
//## end module%393E6B9E030E.epilog


#endif
