//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4006A1510222.cm preserve=no
//	$Date:   Dec 16 2016 15:28:38  $ $Author:   e1009652  $
//	$Revision:   1.3  $
//## end module%4006A1510222.cm

//## begin module%4006A1510222.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4006A1510222.cp

//## Module: CXOSCF60%4006A1510222; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF60.cpp

//## begin module%4006A1510222.additionalIncludes preserve=no
//## end module%4006A1510222.additionalIncludes

//## begin module%4006A1510222.includes preserve=yes
// $Date:   Dec 16 2016 15:28:38  $ $Author:   e1009652  $ $Revision:   1.3  $
//## end module%4006A1510222.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF60_h
#include "CXODCF60.hpp"
#endif
//## begin module%4006A1510222.declarations preserve=no
//## end module%4006A1510222.declarations

//## begin module%4006A1510222.additionalDeclarations preserve=yes
//## end module%4006A1510222.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexPOSConditionCode8 

ConnexPOSConditionCode8::ConnexPOSConditionCode8()
  //## begin ConnexPOSConditionCode8::ConnexPOSConditionCode8%4006A1CF001F_const.hasinit preserve=no
  //## end ConnexPOSConditionCode8::ConnexPOSConditionCode8%4006A1CF001F_const.hasinit
  //## begin ConnexPOSConditionCode8::ConnexPOSConditionCode8%4006A1CF001F_const.initialization preserve=yes
   : ConversionItem("## CR72 XLATE POS CON COD8")
  //## end ConnexPOSConditionCode8::ConnexPOSConditionCode8%4006A1CF001F_const.initialization
{
  //## begin configuration::ConnexPOSConditionCode8::ConnexPOSConditionCode8%4006A1CF001F_const.body preserve=yes
   memcpy(m_sID,"CF60",4);
  //## end configuration::ConnexPOSConditionCode8::ConnexPOSConditionCode8%4006A1CF001F_const.body
}


ConnexPOSConditionCode8::~ConnexPOSConditionCode8()
{
  //## begin configuration::ConnexPOSConditionCode8::~ConnexPOSConditionCode8%4006A1CF001F_dest.body preserve=yes
  //## end configuration::ConnexPOSConditionCode8::~ConnexPOSConditionCode8%4006A1CF001F_dest.body
}



//## Other Operations (implementation)
void ConnexPOSConditionCode8::bind (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode8::bind%4006A20D03A9.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_IBM_POS_COND_COD");
   hQuery.bind("X_IBM_POS_COND_COD","POS_COND_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_POS_COND_COD","POS_CRDHLDR_A_METH",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IBM_POS_COND_COD.POS_COND_CODE ASC");
  //## end configuration::ConnexPOSConditionCode8::bind%4006A20D03A9.body
}

void ConnexPOSConditionCode8::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode8::setPredicate%584716790359.body preserve=yes
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_STATE", "=", "A");
  //## end configuration::ConnexPOSConditionCode8::setPredicate%584716790359.body
}

// Additional Declarations
  //## begin configuration::ConnexPOSConditionCode8%4006A1CF001F.declarations preserve=yes
  //## end configuration::ConnexPOSConditionCode8%4006A1CF001F.declarations

} // namespace configuration

//## begin module%4006A1510222.epilog preserve=yes
//## end module%4006A1510222.epilog
