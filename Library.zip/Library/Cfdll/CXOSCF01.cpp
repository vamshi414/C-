//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%390F385403C5.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%390F385403C5.cm

//## begin module%390F385403C5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%390F385403C5.cp

//## Module: CXOSCF01%390F385403C5; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF01.cpp

//## begin module%390F385403C5.additionalIncludes preserve=no
//## end module%390F385403C5.additionalIncludes

//## begin module%390F385403C5.includes preserve=yes
#include "CXODIF12.hpp"
#include "CXODIF15.hpp"
#include "CXODTM03.hpp"
//## end module%390F385403C5.includes

#ifndef CXOSCF04_h
#include "CXODCF04.hpp"
#endif
#ifndef CXOSRU23_h
#include "CXODRU23.hpp"
#endif
#ifndef CXOSCF25_h
#include "CXODCF25.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSCF40_h
#include "CXODCF40.hpp"
#endif
#ifndef CXOSCF02_h
#include "CXODCF02.hpp"
#endif
#ifndef CXOSRU55_h
#include "CXODRU55.hpp"
#endif
#ifndef CXOSCF03_h
#include "CXODCF03.hpp"
#endif
#ifndef CXOSCF24_h
#include "CXODCF24.hpp"
#endif
#ifndef CXOSCF39_h
#include "CXODCF39.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif


//## begin module%390F385403C5.declarations preserve=no
//## end module%390F385403C5.declarations

//## begin module%390F385403C5.additionalDeclarations preserve=yes
//## end module%390F385403C5.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConfigurationRepository 

//## begin configuration::ConfigurationRepository::Instance%5C05A2B70232.attr preserve=no  private: static vector<ConfigurationRepository*>* {V} 0
vector<ConfigurationRepository*>* ConfigurationRepository::m_pInstance = 0;
//## end configuration::ConfigurationRepository::Instance%5C05A2B70232.attr

ConfigurationRepository::ConfigurationRepository()
  //## begin ConfigurationRepository::ConfigurationRepository%390F35570299_const.hasinit preserve=no
      : m_bEvidence(true),
        m_bLoadFailure(false)
  //## end ConfigurationRepository::ConfigurationRepository%390F35570299_const.hasinit
  //## begin ConfigurationRepository::ConfigurationRepository%390F35570299_const.initialization preserve=yes
  //## end ConfigurationRepository::ConfigurationRepository%390F35570299_const.initialization
{
  //## begin configuration::ConfigurationRepository::ConfigurationRepository%390F35570299_const.body preserve=yes
   memcpy(m_sID,"CF01",4);
   MidnightAlarm::instance()->attach(this);
  //## end configuration::ConfigurationRepository::ConfigurationRepository%390F35570299_const.body
}


ConfigurationRepository::~ConfigurationRepository()
{
  //## begin configuration::ConfigurationRepository::~ConfigurationRepository%390F35570299_dest.body preserve=yes
   MidnightAlarm::instance()->detach(this);
   reset();
  //## end configuration::ConfigurationRepository::~ConfigurationRepository%390F35570299_dest.body
}



//## Other Operations (implementation)
void ConfigurationRepository::addEvidenceSegment (const EvidenceSegment& hEvidenceSegment)
{
  //## begin configuration::ConfigurationRepository::addEvidenceSegment%4ACB8A880145.body preserve=yes
   m_hEvidenceSegment.push_back(hEvidenceSegment);
  //## end configuration::ConfigurationRepository::addEvidenceSegment%4ACB8A880145.body
}

bool ConfigurationRepository::getCRBook (const char* pszTable, string& strCRBook)
{
  //## begin configuration::ConfigurationRepository::getCRBook%3FDDCA2A0222.body preserve=yes
   return ConfigurationFactory::instance()->getCRBook(pszTable,strCRBook);
  //## end configuration::ConfigurationRepository::getCRBook%3FDDCA2A0222.body
}

EvidenceSegment& ConfigurationRepository::getEvidenceSegment ()
{
  //## begin configuration::ConfigurationRepository::getEvidenceSegment%3960A57D0052.body preserve=yes
   return m_hEvidenceSegment.back();
  //## end configuration::ConfigurationRepository::getEvidenceSegment%3960A57D0052.body
}

ConfigurationRepository* ConfigurationRepository::instance ()
{
  //## begin configuration::ConfigurationRepository::instance%3910494A0150.body preserve=yes
   if (!m_pInstance)
   {
      m_pInstance = new vector<ConfigurationRepository*>;
      m_pInstance->reserve(reusable::Thread::getTotal());
      for (int i = 0;i < reusable::Thread::getTotal();++i)
         m_pInstance->push_back(0);
   }
   int i = reusable::Thread::getNumber();
   if (!(*m_pInstance)[i])
      (*m_pInstance)[i] = new ConfigurationRepository();
   return (*m_pInstance)[i];
  //## end configuration::ConfigurationRepository::instance%3910494A0150.body
}

string& ConfigurationRepository::isSubscriber (string strAcqValue, string strIssValue, char cAcqLevel, char cIssLevel)
{
  //## begin configuration::ConfigurationRepository::isSubscriber%3E0706A7032C.body preserve=yes
  // following is disabled for now ... never implemented in production
  /*
   if ((m_strSUBSCRIBER_IND = Customer::instance()->getSUBSCRIBER_IND())!= "")
   {
      if (m_strSUBSCRIBER_IND == "X")
         m_hEvidenceSegment.erase(m_hEvidenceSegment.begin(),m_hEvidenceSegment.end());
      return m_strSUBSCRIBER_IND;
   }
   map<string,ConversionTable*,less<string> >::iterator pConversionTable;
   ConversionTable* pTable;
   char *pszTable = 0;
   string strTemp;
   string strSecond;
   size_t n;
   int i;
   switch (cAcqLevel)
   {
      case 'D':
         pszTable = "DEVICE";
         pConversionTable = m_hConversionTable.find(pszTable);
         if (pConversionTable == m_hConversionTable.end())
            pTable = loadTable(pszTable);
         else
            pTable = (*pConversionTable).second;
         strTemp = strAcqValue;
         n = strTemp.find_last_not_of(' ');
         strTemp.erase(n + 1);
         if (!pTable->find(strTemp,strSecond,0,false))
           {
               m_strSUBSCRIBER_IND = " ";
            return m_strSUBSCRIBER_IND;
           }
         else
            strTemp = strSecond.substr(0,11);
         i = 0;
         break;
      case 'P':
         strTemp = strAcqValue;
         i = 1;
         break;
      case 'I':
      default:
         strTemp = strAcqValue;
         i = 0;
         break;
   }

   while (i < 3 && m_strSUBSCRIBER_IND == "")
   {
      switch (i)
      {
         case 0:
            pszTable = "INSTITUTION";
            break;
         case 1:
            pszTable = "PROCESSOR";
            break;
         case 2:
            pszTable = "PROCESSOR_GRP";
            break;
      }
      pConversionTable = m_hConversionTable.find(pszTable);
      if (pConversionTable == m_hConversionTable.end())
         pTable = loadTable(pszTable);
      else
         pTable = (*pConversionTable).second;
      size_t n = strTemp.find_last_not_of(' ');
      strTemp.erase(n + 1);
      if (pTable->find(strTemp,strSecond,&m_strSUBSCRIBER_IND,false))
         strTemp = strSecond;
      else
         break;
      i++;
   }
   if ((m_strSUBSCRIBER_IND != ""
      && m_strSUBSCRIBER_IND != "X")
      || strIssValue == "")
   {
      if (m_strSUBSCRIBER_IND == "X")
           m_hEvidenceSegment.erase(m_hEvidenceSegment.begin(),m_hEvidenceSegment.end());
      return m_strSUBSCRIBER_IND;
   }
   if (cIssLevel == 'P')
      i = 1;
   else
      i = 0;
   m_strSUBSCRIBER_IND = "";
   strTemp = strIssValue;
   while (i < 3 && m_strSUBSCRIBER_IND == "")
   {
      switch (i)
      {
         case 0:
            pszTable = "INSTITUTION";
            break;
         case 1:
            pszTable = "PROCESSOR";
            break;
         case 2:
            pszTable = "PROCESSOR_GRP";
            break;
      }
      pConversionTable = m_hConversionTable.find(pszTable);
      if (pConversionTable == m_hConversionTable.end())
         pTable = loadTable(pszTable);
      else
         pTable = (*pConversionTable).second;
      size_t n = strTemp.find_last_not_of(' ');
      strTemp.erase(n + 1);
      if (pTable->find(strTemp,strSecond,&m_strSUBSCRIBER_IND,false))
         strTemp = strSecond;
      else
         break;
      i++;
   }
   if (m_strSUBSCRIBER_IND == "X")
      m_hEvidenceSegment.erase(m_hEvidenceSegment.begin(),m_hEvidenceSegment.end());
   */
   return m_strSUBSCRIBER_IND;
  //## end configuration::ConfigurationRepository::isSubscriber%3E0706A7032C.body
}

ConversionTable* ConfigurationRepository::loadTable (const char* pszTable)
{
  //## begin configuration::ConfigurationRepository::loadTable%3E070B0100FA.body preserve=yes
   ConversionTable* pTable;
   pTable = new ConversionTable(pszTable);
   m_hConversionTable.insert(map<string,ConversionTable*,less<string> >::value_type(pszTable,pTable));
   pTable->attach(this);
   if (!ConversionLoader::instance()->populate(pTable))
   {
      m_bLoadFailure = true;
      Console::display("ST134",pszTable);
   }
   return pTable;
  //## end configuration::ConfigurationRepository::loadTable%3E070B0100FA.body
}

bool ConfigurationRepository::mapItem (const char* pszTable, const string& strPrimaryKey, const string& strTertiaryKey, const string& strSecondaryKey, string& strResult)
{
  //## begin configuration::ConfigurationRepository::mapItem%3ACCB66C017A.body preserve=yes
   map<string,MappingTable*,less<string> >::iterator pMappingTable;
   MappingTable* pTable;
   pMappingTable = m_hMappingTable.find(pszTable);
   if (pMappingTable == m_hMappingTable.end())
   {
      pTable = new MappingTable(pszTable);
      if (!MappingLoader::instance()->populate(pTable))
      {
         m_bLoadFailure = true;
         Console::display("ST134",pszTable);
		 delete pTable;
         return false;
      }
	  m_hMappingTable.insert(map<string, MappingTable*, less<string> >::value_type(pszTable, pTable));
   }
   else
      pTable = (*pMappingTable).second;
   if (pTable->size() == 0)
      return false;
   string strPrimary(strPrimaryKey);
   strPrimary.trim();
   string strSecondary(strSecondaryKey);
   strSecondary.trim();
   string strTertiary(strTertiaryKey);
   strTertiary.trim();
   return pTable->find(strPrimary,strSecondary,strTertiary,strResult);
  //## end configuration::ConfigurationRepository::mapItem%3ACCB66C017A.body
}

void ConfigurationRepository::reset (const char* pszTable)
{
  //## begin configuration::ConfigurationRepository::reset%3919A57802DB.body preserve=yes
   map<string,ConversionTable*,less<string> >::iterator pConversionTable;
   map<string,VerificationTable*,less<string> >::iterator pVerificationTable;
   map<string,MappingTable*,less<string> >::iterator pMappingTable;
   if (pszTable)
   {
      if ((pConversionTable = m_hConversionTable.find(pszTable)) != m_hConversionTable.end())
         reset(pConversionTable, pszTable);
      if ((pVerificationTable = m_hVerificationTable.find(pszTable)) != m_hVerificationTable.end())
         reset(pVerificationTable, pszTable);
      if ((pMappingTable = m_hMappingTable.find(pszTable)) != m_hMappingTable.end())
         reset(pMappingTable,pszTable);
       return;
   }
   for (pConversionTable = m_hConversionTable.begin(); pConversionTable != m_hConversionTable.end(); ++pConversionTable)
      reset(pConversionTable, (*pConversionTable).first.c_str());
   for (pVerificationTable = m_hVerificationTable.begin();pVerificationTable != m_hVerificationTable.end();++pVerificationTable)
      reset(pVerificationTable, (*pVerificationTable).first.c_str());
   for (pMappingTable = m_hMappingTable.begin();pMappingTable != m_hMappingTable.end();++pMappingTable)
      reset(pMappingTable, (*pMappingTable).first.c_str());
   m_bLoadFailure = false;
  //## end configuration::ConfigurationRepository::reset%3919A57802DB.body
}

void ConfigurationRepository::reset (map<string,ConversionTable*,less<string> >::iterator& pConversionTable, const char* pszTable)
{
  //## begin configuration::ConfigurationRepository::reset%6238C9690229.body preserve=yes
   ConversionTable* pTable = new ConversionTable(pszTable);
   if (ConversionLoader::instance()->populate(pTable))
   {
      delete (*pConversionTable).second;
      pConversionTable->second = pTable;
   }
   else
      delete pTable;
   //## end configuration::ConfigurationRepository::reset%6238C9690229.body
}

void ConfigurationRepository::reset (map<string,MappingTable*,less<string> >::iterator& pMappingTable, const char* pszTable)
{
  //## begin configuration::ConfigurationRepository::reset%6238CBAC0212.body preserve=yes
   MappingTable* pTable = new MappingTable(pszTable);
   if (MappingLoader::instance()->populate(pTable))
   {
      delete (*pMappingTable).second;
      pMappingTable->second = pTable;
   }
   else
      delete pTable;
   //## end configuration::ConfigurationRepository::reset%6238CBAC0212.body
}

void ConfigurationRepository::reset (map<string,VerificationTable*,less<string> >::iterator& pVerificationTable, const char* pszTable)
{
  //## begin configuration::ConfigurationRepository::reset%6238CA2501CE.body preserve=yes
   VerificationTable* pTable = new VerificationTable(pszTable);
   if (VerificationLoader::instance()->populate(pTable))
   {
      delete (*pVerificationTable).second;
      pVerificationTable->second = pTable;
   }
   else
      delete pTable;
   //## end configuration::ConfigurationRepository::reset%6238CA2501CE.body
}

bool ConfigurationRepository::translate (const char* pszTable, const string& strFirst, string& strSecond, const string& strPROBLEM_TABLE, const string& strPROBLEM_COLUMN, int iVersion, bool bEvidence)
{
  //## begin configuration::ConfigurationRepository::translate%390F372E008D.body preserve=yes
   strSecond.erase();
   map<string,ConversionTable*,less<string> >::iterator pConversionTable;
   ConversionTable* pTable;
   pConversionTable = m_hConversionTable.find(pszTable);
   if (pConversionTable == m_hConversionTable.end())
   {
      pTable = new ConversionTable(pszTable);
	  if (ConversionLoader::instance()->populate(pTable) == false
		  || (pTable->size() == 0
		  && m_bEvidence
		  && bEvidence))
	  {
		  m_bLoadFailure = true;
		  Console::display("ST134", pszTable);
		  delete pTable;
		  return false;
	  }
	  m_hConversionTable.insert(map<string, ConversionTable*, less<string> >::value_type(pszTable, pTable));
   }
   else
      pTable = (*pConversionTable).second;
   string strTemp(strFirst);
   size_t n = strTemp.find_last_not_of(' ');
   strTemp.erase(n + 1);
   bool bFound = pTable->find(strTemp,strSecond,m_strThird,bEvidence);
   if (bFound == false
      && m_bEvidence
      && bEvidence)
   {
      EvidenceSegment hEvidenceSegment;
      hEvidenceSegment.setSUSPECT_TABLE(pszTable);
      hEvidenceSegment.setPROBLEM_TABLE(strPROBLEM_TABLE);
      hEvidenceSegment.setPROBLEM_COLUMN(strPROBLEM_COLUMN);
      hEvidenceSegment.setSOURCE_VALUE(strTemp);
      hEvidenceSegment.setREASON_CODE(EVIDENCE_TRANSLATE_FAILURE);
      m_hEvidenceSegment.push_back(hEvidenceSegment);
   }
   if (IF::Trace::getEnable())
   {
      string strText("CF01 translate: ");
      strText.append(pszTable);
      strText.append(",",1);
      strText += strFirst;
      strText.append(",",1);
      strText += strSecond;
      Trace::put(strText.data(),strText.length());
   }
   return bFound;
  //## end configuration::ConfigurationRepository::translate%390F372E008D.body
}

void ConfigurationRepository::update (Subject* pSubject)
{
  //## begin configuration::ConfigurationRepository::update%393FB5A0030D.body preserve=yes
   if (pSubject == MidnightAlarm::instance())
   {
      reset();
      return;
   }
  //## end configuration::ConfigurationRepository::update%393FB5A0030D.body
}

bool ConfigurationRepository::verify (const char* pszTable, const string& strKey, int iVersion)
{
  //## begin configuration::ConfigurationRepository::verify%393E74270374.body preserve=yes
   map<string,VerificationTable*,less<string> >::iterator pVerificationTable;
   VerificationTable* pTable;
   pVerificationTable = m_hVerificationTable.find(pszTable);
   if (pVerificationTable == m_hVerificationTable.end())
   {
      pTable = new VerificationTable(pszTable);
      if (!VerificationLoader::instance()->populate(pTable))
      {
         m_bLoadFailure = true;
         Console::display("ST134",pszTable);
		 delete pTable;
		 return false;
      }
	  m_hVerificationTable.insert(map<string, VerificationTable*, less<string> >::value_type(pszTable, pTable));
      /* need to implement size() in VerificationTable !!!
      if (pTable->size() == 0
         && m_bEvidence)
      {
         m_bLoadFailure = true;
         Console::display("ST134",pszTable);
      }
      */
   }
   else
      pTable = (*pVerificationTable).second;
   string strTemp(strKey);
   size_t n = strTemp.find_last_not_of(' ');
   strTemp.erase(n + 1);
   bool bFound = pTable->find(strTemp);
   if (bFound == false
      && m_bEvidence)
   {
      EvidenceSegment hEvidenceSegment;
      hEvidenceSegment.setSUSPECT_TABLE(pszTable);
      hEvidenceSegment.setPROBLEM_TABLE(" ");
      hEvidenceSegment.setPROBLEM_COLUMN(" ");
      hEvidenceSegment.setSOURCE_VALUE(strTemp);
      hEvidenceSegment.setREASON_CODE(EVIDENCE_VERIFY_FAILURE);
      m_hEvidenceSegment.push_back(hEvidenceSegment);
   }
   return bFound;
  //## end configuration::ConfigurationRepository::verify%393E74270374.body
}

void ConfigurationRepository::write (char** ppsBuffer, const string& strTSTAMP_TRANS, const short iUNIQUENESS_KEY)
{
  //## begin configuration::ConfigurationRepository::write%3950D5EB023C.body preserve=yes
   if (m_bEvidence && m_hEvidenceSegment.size())
   {
      vector<EvidenceSegment>::iterator pEvidenceSegment;
      char* p = *ppsBuffer + 4;
      ListSegment hListSegment;
      hListSegment.write(ppsBuffer);
      for (pEvidenceSegment = m_hEvidenceSegment.begin();pEvidenceSegment != m_hEvidenceSegment.end();++pEvidenceSegment)
      {
         string strTSTAMP_INSERTED = Clock::instance()->getYYYYMMDDHHMMSS();
         strTSTAMP_INSERTED += "00";
         pEvidenceSegment->setTSTAMP_INSERTED(strTSTAMP_INSERTED);
         pEvidenceSegment->setTSTAMP_TRANS(strTSTAMP_TRANS);
         pEvidenceSegment->setUNIQUENESS_KEY(iUNIQUENESS_KEY);
         pEvidenceSegment->write(ppsBuffer);
      }
      hListSegment.update(p,m_hEvidenceSegment.size(),(int)(*ppsBuffer - p));
   }
   m_hEvidenceSegment.erase(m_hEvidenceSegment.begin(),m_hEvidenceSegment.end());
  //## end configuration::ConfigurationRepository::write%3950D5EB023C.body
}

// Additional Declarations
  //## begin configuration::ConfigurationRepository%390F35570299.declarations preserve=yes
  //## end configuration::ConfigurationRepository%390F35570299.declarations

} // namespace configuration

//## begin module%390F385403C5.epilog preserve=yes
//## end module%390F385403C5.epilog
