//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FF98A92002E.cm preserve=no
//	$Date:   Dec 16 2016 15:19:54  $ $Author:   e1009652  $
//	$Revision:   1.4  $
//## end module%3FF98A92002E.cm

//## begin module%3FF98A92002E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FF98A92002E.cp

//## Module: CXOSCF50%3FF98A92002E; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF50.cpp

//## begin module%3FF98A92002E.additionalIncludes preserve=no
//## end module%3FF98A92002E.additionalIncludes

//## begin module%3FF98A92002E.includes preserve=yes
// $Date:   Dec 16 2016 15:19:54  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%3FF98A92002E.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF50_h
#include "CXODCF50.hpp"
#endif


//## begin module%3FF98A92002E.declarations preserve=no
//## end module%3FF98A92002E.declarations

//## begin module%3FF98A92002E.additionalDeclarations preserve=yes
//## end module%3FF98A92002E.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexPOSConditionCode1 

ConnexPOSConditionCode1::ConnexPOSConditionCode1()
  //## begin ConnexPOSConditionCode1::ConnexPOSConditionCode1%3FF98A0E02BF_const.hasinit preserve=no
  //## end ConnexPOSConditionCode1::ConnexPOSConditionCode1%3FF98A0E02BF_const.hasinit
  //## begin ConnexPOSConditionCode1::ConnexPOSConditionCode1%3FF98A0E02BF_const.initialization preserve=yes
   : ConversionItem("## CR62 XLATE POS CON COD1")
  //## end ConnexPOSConditionCode1::ConnexPOSConditionCode1%3FF98A0E02BF_const.initialization
{
  //## begin configuration::ConnexPOSConditionCode1::ConnexPOSConditionCode1%3FF98A0E02BF_const.body preserve=yes
   memcpy(m_sID,"CF50",4);
  //## end configuration::ConnexPOSConditionCode1::ConnexPOSConditionCode1%3FF98A0E02BF_const.body
}


ConnexPOSConditionCode1::~ConnexPOSConditionCode1()
{
  //## begin configuration::ConnexPOSConditionCode1::~ConnexPOSConditionCode1%3FF98A0E02BF_dest.body preserve=yes
  //## end configuration::ConnexPOSConditionCode1::~ConnexPOSConditionCode1%3FF98A0E02BF_dest.body
}



//## Other Operations (implementation)
void ConnexPOSConditionCode1::bind (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode1::bind%3FF98C2B0157.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_IBM_POS_COND_COD");
   hQuery.bind("X_IBM_POS_COND_COD","POS_COND_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_POS_COND_COD","POS_CRDHLDR_AUTH_C",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IBM_POS_COND_COD.POS_COND_CODE ASC");
  //## end configuration::ConnexPOSConditionCode1::bind%3FF98C2B0157.body
}

void ConnexPOSConditionCode1::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexPOSConditionCode1::setPredicate%584716060013.body preserve=yes
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_COND_COD", "CC_STATE", "=", "A");
  //## end configuration::ConnexPOSConditionCode1::setPredicate%584716060013.body
}

// Additional Declarations
  //## begin configuration::ConnexPOSConditionCode1%3FF98A0E02BF.declarations preserve=yes
  //## end configuration::ConnexPOSConditionCode1%3FF98A0E02BF.declarations

} // namespace configuration

//## begin module%3FF98A92002E.epilog preserve=yes
//## end module%3FF98A92002E.epilog
