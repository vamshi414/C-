//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%48298BEB037A.cm preserve=no
//	$Date:   Apr 17 2014 21:06:20  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%48298BEB037A.cm

//## begin module%48298BEB037A.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%48298BEB037A.cp

//## Module: CXOSCF96%48298BEB037A; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF96.cpp

//## begin module%48298BEB037A.additionalIncludes preserve=no
//## end module%48298BEB037A.additionalIncludes

//## begin module%48298BEB037A.includes preserve=yes
//## end module%48298BEB037A.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF96_h
#include "CXODCF96.hpp"
#endif


//## begin module%48298BEB037A.declarations preserve=no
//## end module%48298BEB037A.declarations

//## begin module%48298BEB037A.additionalDeclarations preserve=yes
//## end module%48298BEB037A.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::PulseProcessCodeRev 

PulseProcessCodeRev::PulseProcessCodeRev()
  //## begin PulseProcessCodeRev::PulseProcessCodeRev%48298AE400DA_const.hasinit preserve=no
  //## end PulseProcessCodeRev::PulseProcessCodeRev%48298AE400DA_const.hasinit
  //## begin PulseProcessCodeRev::PulseProcessCodeRev%48298AE400DA_const.initialization preserve=yes
   : ConversionItem("## CR96 XLATE PULSE PROCESS CODE")
  //## end PulseProcessCodeRev::PulseProcessCodeRev%48298AE400DA_const.initialization
{
  //## begin configuration::PulseProcessCodeRev::PulseProcessCodeRev%48298AE400DA_const.body preserve=yes
   memcpy(m_sID,"CF96",4);
  //## end configuration::PulseProcessCodeRev::PulseProcessCodeRev%48298AE400DA_const.body
}


PulseProcessCodeRev::~PulseProcessCodeRev()
{
  //## begin configuration::PulseProcessCodeRev::~PulseProcessCodeRev%48298AE400DA_dest.body preserve=yes
  //## end configuration::PulseProcessCodeRev::~PulseProcessCodeRev%48298AE400DA_dest.body
}



//## Other Operations (implementation)
void PulseProcessCodeRev::bind (reusable::Query& hQuery)
{
  //## begin configuration::PulseProcessCodeRev::bind%48298CF30128.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_PULSE_PROC_CODE");
   hQuery.bind("X_PULSE_PROC_CODE","PULSE_TRAN_TYPE",Column::STRING,&m_strSecond);
   hQuery.bind("X_PULSE_PROC_CODE","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("X_PULSE_PROC_CODE","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("X_PULSE_PROC_CODE","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("X_PULSE_PROC_CODE","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("X_PULSE_PROC_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_PULSE_PROC_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_PULSE_PROC_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_PULSE_PROC_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_PULSE_PROC_CODE.PROCESS_CODE ASC,"
                           "X_PULSE_PROC_CODE.MSG_CLASS ASC,"
                           "X_PULSE_PROC_CODE.PRE_AUTH ASC,"
                           "X_PULSE_PROC_CODE.MEDIA_TYPE ASC,"
                           "X_PULSE_PROC_CODE.CUST_ID DESC");
  //## end configuration::PulseProcessCodeRev::bind%48298CF30128.body
}

const string& PulseProcessCodeRev::getFirst ()
{
  //## begin configuration::PulseProcessCodeRev::getFirst%48298CF603A9.body preserve=yes
   while (m_strPROCESS_CODE.length() < 6)
      m_strPROCESS_CODE += ' ';
   while (m_strMSG_CLASS.length() < 1)
      m_strMSG_CLASS += ' ';
   while (m_strPRE_AUTH.length() < 1)
      m_strPRE_AUTH += ' ';
   while (m_strMEDIA_TYPE.length() < 2)
      m_strMEDIA_TYPE += ' ';
   m_strFirst = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strFirst;
  //## end configuration::PulseProcessCodeRev::getFirst%48298CF603A9.body
}

// Additional Declarations
  //## begin configuration::PulseProcessCodeRev%48298AE400DA.declarations preserve=yes
  //## end configuration::PulseProcessCodeRev%48298AE400DA.declarations

} // namespace configuration

//## begin module%48298BEB037A.epilog preserve=yes
//## end module%48298BEB037A.epilog
