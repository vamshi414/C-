//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%620DB6F702CF.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%620DB6F702CF.cm

//## begin module%620DB6F702CF.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%620DB6F702CF.cp

//## Module: CXOSCFC4%620DB6F702CF; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFC4.cpp

//## begin module%620DB6F702CF.additionalIncludes preserve=no
//## end module%620DB6F702CF.additionalIncludes

//## begin module%620DB6F702CF.includes preserve=yes
//## end module%620DB6F702CF.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCFC4_h
#include "CXODCFC4.hpp"
#endif


//## begin module%620DB6F702CF.declarations preserve=no
//## end module%620DB6F702CF.declarations

//## begin module%620DB6F702CF.additionalDeclarations preserve=yes
//## end module%620DB6F702CF.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::AIMSBillingInstitution 

AIMSBillingInstitution::AIMSBillingInstitution()
  //## begin AIMSBillingInstitution::AIMSBillingInstitution%620DB6B7030F_const.hasinit preserve=no
  //## end AIMSBillingInstitution::AIMSBillingInstitution%620DB6B7030F_const.hasinit
  //## begin AIMSBillingInstitution::AIMSBillingInstitution%620DB6B7030F_const.initialization preserve=yes
   : ConversionItem("## CFC4 XLATE AIMS CHARGE")
  //## end AIMSBillingInstitution::AIMSBillingInstitution%620DB6B7030F_const.initialization
{
  //## begin configuration::AIMSBillingInstitution::AIMSBillingInstitution%620DB6B7030F_const.body preserve=yes
   memcpy(m_sID,"CFC4",4);
  //## end configuration::AIMSBillingInstitution::AIMSBillingInstitution%620DB6B7030F_const.body
}


AIMSBillingInstitution::~AIMSBillingInstitution()
{
  //## begin configuration::AIMSBillingInstitution::~AIMSBillingInstitution%620DB6B7030F_dest.body preserve=yes
  //## end configuration::AIMSBillingInstitution::~AIMSBillingInstitution%620DB6B7030F_dest.body
}



//## Other Operations (implementation)
void AIMSBillingInstitution::bind (Query& hQuery)
{
  //## begin configuration::AIMSBillingInstitution::bind%620DCB3401B4.body preserve=yes
   hQuery.setQualifier("QUALIFY","AIMS_BILL_INST");
   hQuery.bind("AIMS_BILL_INST","AIMS_FI_BILLING_ID",Column::STRING,&m_strFirst);
   hQuery.bind("AIMS_BILL_INST","CATEGORY_ID",Column::STRING,&m_strCATEGORY_ID);
   hQuery.bind("AIMS_BILL_INST","APPL_NO",Column::STRING,&m_strSecond);
   hQuery.bind("AIMS_BILL_INST","ITEM_NO",Column::STRING,&m_strITEM_NO);
   hQuery.bind("AIMS_BILL_INST","CC_TSTAMP_CHANGE",Column::STRING,&m_strThird);
   hQuery.setBasicPredicate("AIMS_BILL_INST","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("AIMS_BILL_INST","CC_STATE","=","A");
   Extract::instance()->getSpec("CUSTOMER", m_strCUST_ID);
   string strTemp = "('" + m_strCUST_ID + "','****')";
   hQuery.setBasicPredicate("AIMS_BILL_INST", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("AIMS_FI_BILLING_ID,CATEGORY_ID");
  //## end configuration::AIMSBillingInstitution::bind%620DCB3401B4.body
}

const string& AIMSBillingInstitution::getFirst ()
{
  //## begin configuration::AIMSBillingInstitution::getFirst%620DCB4B039C.body preserve=yes
   m_strFirst += m_strCATEGORY_ID;
   return m_strFirst;
  //## end configuration::AIMSBillingInstitution::getFirst%620DCB4B039C.body
}

const string& AIMSBillingInstitution::getSecond ()
{
  //## begin configuration::AIMSBillingInstitution::getSecond%620DCB4E0127.body preserve=yes
   m_strSecond.append(",",1);
   m_strSecond += m_strITEM_NO;
   return m_strSecond;
  //## end configuration::AIMSBillingInstitution::getSecond%620DCB4E0127.body
}

const string& AIMSBillingInstitution::getThird ()
{
  //## begin configuration::AIMSBillingInstitution::getThird%620FB46A01F2.body preserve=yes
   m_strThird.resize(14,' ');
   return m_strThird;
  //## end configuration::AIMSBillingInstitution::getThird%620FB46A01F2.body
}

// Additional Declarations
  //## begin configuration::AIMSBillingInstitution%620DB6B7030F.declarations preserve=yes
  //## end configuration::AIMSBillingInstitution%620DB6B7030F.declarations

} // namespace configuration

//## begin module%620DB6F702CF.epilog preserve=yes
//## end module%620DB6F702CF.epilog
