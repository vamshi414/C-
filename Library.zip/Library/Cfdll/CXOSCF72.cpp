//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4255589403D8.cm preserve=no
//	$Date:   Dec 12 2016 14:53:30  $ $Author:   e1009652  $
//	$Revision:   1.6  $
//## end module%4255589403D8.cm

//## begin module%4255589403D8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4255589403D8.cp

//## Module: CXOSCF72%4255589403D8; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF72.cpp

//## begin module%4255589403D8.additionalIncludes preserve=no
//## end module%4255589403D8.additionalIncludes

//## begin module%4255589403D8.includes preserve=yes
//## end module%4255589403D8.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF72_h
#include "CXODCF72.hpp"
#endif


//## begin module%4255589403D8.declarations preserve=no
//## end module%4255589403D8.declarations

//## begin module%4255589403D8.additionalDeclarations preserve=yes
//## end module%4255589403D8.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::CountryCode 

CountryCode::CountryCode()
  //## begin CountryCode::CountryCode%42554DAF0157_const.hasinit preserve=no
  //## end CountryCode::CountryCode%42554DAF0157_const.hasinit
  //## begin CountryCode::CountryCode%42554DAF0157_const.initialization preserve=yes
   : ConversionItem("## CR79 XLATE COUNTRY CODE")
  //## end CountryCode::CountryCode%42554DAF0157_const.initialization
{
  //## begin configuration::CountryCode::CountryCode%42554DAF0157_const.body preserve=yes
    memcpy(m_sID,"CF72",4);
  //## end configuration::CountryCode::CountryCode%42554DAF0157_const.body
}


CountryCode::~CountryCode()
{
  //## begin configuration::CountryCode::~CountryCode%42554DAF0157_dest.body preserve=yes
  //## end configuration::CountryCode::~CountryCode%42554DAF0157_dest.body
}



//## Other Operations (implementation)
void CountryCode::bind (Query& hQuery)
{
  //## begin configuration::CountryCode::bind%425559E803C8.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY","COUNTRY_CODE");
   hQuery.bind("COUNTRY_CODE","COUNTRY_CODE_ISO3",Column::STRING,&m_strFirst);
   hQuery.bind("COUNTRY_CODE","COUNTRY_CODE_ISO2",Column::STRING,&m_strSecond);
   hQuery.bind("COUNTRY_CODE","VISA_REGION",Column::STRING,&m_strThird);
   hQuery.setBasicPredicate("COUNTRY_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("COUNTRY_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("COUNTRY_CODE", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("COUNTRY_CODE.COUNTRY_CODE_ISO3 ASC");
  //## end configuration::CountryCode::bind%425559E803C8.body
}

// Additional Declarations
  //## begin configuration::CountryCode%42554DAF0157.declarations preserve=yes
  //## end configuration::CountryCode%42554DAF0157.declarations

} // namespace configuration

//## begin module%4255589403D8.epilog preserve=yes
//## end module%4255589403D8.epilog
