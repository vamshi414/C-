//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%43414B5300FA.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%43414B5300FA.cm

//## begin module%43414B5300FA.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%43414B5300FA.cp

//## Module: CXOSCF85%43414B5300FA; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF85.hpp

#ifndef CXOSCF85_h
#define CXOSCF85_h 1

//## begin module%43414B5300FA.additionalIncludes preserve=no
//## end module%43414B5300FA.additionalIncludes

//## begin module%43414B5300FA.includes preserve=yes
//## end module%43414B5300FA.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%43414B5300FA.declarations preserve=no
//## end module%43414B5300FA.declarations

//## begin module%43414B5300FA.additionalDeclarations preserve=yes
//## end module%43414B5300FA.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::StarProcessCodeRev%434149DA02FD.preface preserve=yes
//## end configuration::StarProcessCodeRev%434149DA02FD.preface

//## Class: StarProcessCodeRev%434149DA02FD
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%43414B03035B;IF::Extract { -> F}
//## Uses: <unnamed>%43414B060261;reusable::Query { -> F}

class DllExport StarProcessCodeRev : public ConversionItem  //## Inherits: <unnamed>%43414AD103B9
{
  //## begin configuration::StarProcessCodeRev%434149DA02FD.initialDeclarations preserve=yes
  //## end configuration::StarProcessCodeRev%434149DA02FD.initialDeclarations

  public:
    //## Constructors (generated)
      StarProcessCodeRev();

    //## Destructor (generated)
      virtual ~StarProcessCodeRev();


    //## Other Operations (specified)
      //## Operation: bind%43414B180128
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>MS
      //	<h3>VISA Process Codes
      //	<p>
      //	The VISA Process Codes table is used to determine a
      //	value for the transaction type identifier (FIN_
      //	L<i>yyyymm</i>.TRAN_TYPE_ID) in the financial
      //	transaction.
      //	<p>
      //	Use the CR Client to add or update rows whenever the e
      //	Funds Advantage acquiring platform introduces a new
      //	value in:
      //	<ul>
      //	<li>PROC^CODE (1)
      //	</ul>
      //	VISA Process Codes are in the Parameter Tables folder in
      //	the CR Client for the DataNavigator Server.
      //	</body>
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getFirst%43414D930213
      virtual const string& getFirst ();

    // Additional Public Declarations
      //## begin configuration::StarProcessCodeRev%434149DA02FD.public preserve=yes
      //## end configuration::StarProcessCodeRev%434149DA02FD.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::StarProcessCodeRev%434149DA02FD.protected preserve=yes
      //## end configuration::StarProcessCodeRev%434149DA02FD.protected

  private:
    // Additional Private Declarations
      //## begin configuration::StarProcessCodeRev%434149DA02FD.private preserve=yes
      //## end configuration::StarProcessCodeRev%434149DA02FD.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: MEDIA_TYPE%43414FC90271
      //## begin configuration::StarProcessCodeRev::MEDIA_TYPE%43414FC90271.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::StarProcessCodeRev::MEDIA_TYPE%43414FC90271.attr

      //## Attribute: MSG_CLASS%43414FCE03C8
      //## begin configuration::StarProcessCodeRev::MSG_CLASS%43414FCE03C8.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::StarProcessCodeRev::MSG_CLASS%43414FCE03C8.attr

      //## Attribute: PRE_AUTH%43414FD30119
      //## begin configuration::StarProcessCodeRev::PRE_AUTH%43414FD30119.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::StarProcessCodeRev::PRE_AUTH%43414FD30119.attr

      //## Attribute: PROCESS_CODE%43414FD80196
      //## begin configuration::StarProcessCodeRev::PROCESS_CODE%43414FD80196.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::StarProcessCodeRev::PROCESS_CODE%43414FD80196.attr

      //## Attribute: STAR_TRAN_TYPE%43414C47005D
      //## begin configuration::StarProcessCodeRev::STAR_TRAN_TYPE%43414C47005D.attr preserve=no  private: string {U} 
      string m_pSTAR_TRAN_TYPE;
      //## end configuration::StarProcessCodeRev::STAR_TRAN_TYPE%43414C47005D.attr

    // Additional Implementation Declarations
      //## begin configuration::StarProcessCodeRev%434149DA02FD.implementation preserve=yes
      //## end configuration::StarProcessCodeRev%434149DA02FD.implementation

};

//## begin configuration::StarProcessCodeRev%434149DA02FD.postscript preserve=yes
//## end configuration::StarProcessCodeRev%434149DA02FD.postscript

} // namespace configuration

//## begin module%43414B5300FA.epilog preserve=yes
using namespace configuration;
//## end module%43414B5300FA.epilog


#endif
