//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64DF80D001AB.cm preserve=no
//## end module%64DF80D001AB.cm

//## begin module%64DF80D001AB.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64DF80D001AB.cp

//## Module: CXOSCFD4%64DF80D001AB; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFD4.cpp

//## begin module%64DF80D001AB.additionalIncludes preserve=no
//## end module%64DF80D001AB.additionalIncludes

//## begin module%64DF80D001AB.includes preserve=yes
//## end module%64DF80D001AB.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFD4_h
#include "CXODCFD4.hpp"
#endif


//## begin module%64DF80D001AB.declarations preserve=no
//## end module%64DF80D001AB.declarations

//## begin module%64DF80D001AB.additionalDeclarations preserve=yes
//## end module%64DF80D001AB.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ReportingLevel 

ReportingLevel::ReportingLevel()
  //## begin ReportingLevel::ReportingLevel%64DF82490361_const.hasinit preserve=no
  //## end ReportingLevel::ReportingLevel%64DF82490361_const.hasinit
  //## begin ReportingLevel::ReportingLevel%64DF82490361_const.initialization preserve=yes
   : ConversionItem("## CFD4 XLATE REPORTING LEVEL")
  //## end ReportingLevel::ReportingLevel%64DF82490361_const.initialization
{
  //## begin configuration::ReportingLevel::ReportingLevel%64DF82490361_const.body preserve=yes
   memcpy(m_sID, "CFD4", 4);
  //## end configuration::ReportingLevel::ReportingLevel%64DF82490361_const.body
}


ReportingLevel::~ReportingLevel()
{
  //## begin configuration::ReportingLevel::~ReportingLevel%64DF82490361_dest.body preserve=yes
  //## end configuration::ReportingLevel::~ReportingLevel%64DF82490361_dest.body
}



//## Other Operations (implementation)
void ReportingLevel::bind (Query& hQuery)
{
  //## begin configuration::ReportingLevel::bind%64DF850E010B.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY", "REPORTING_LVL");
   hQuery.bind("REPORTING_LVL", "RPT_LVL_ID", Column::STRING, &m_strFirst);
   hQuery.bind("REPORTING_LVL", "SERVICE_LINE", Column::STRING, &m_strSecond);
   hQuery.bind("REPORTING_LVL", "FEE_BILL_INST_ID", Column::STRING, &m_strThird);
   hQuery.setBasicPredicate("REPORTING_LVL", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("REPORTING_LVL", "CC_STATE", "=", "A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("REPORTING_LVL", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("RPT_LVL_ID ASC");
  //## end configuration::ReportingLevel::bind%64DF850E010B.body
}

// Additional Declarations
  //## begin configuration::ReportingLevel%64DF82490361.declarations preserve=yes
  //## end configuration::ReportingLevel%64DF82490361.declarations

} // namespace configuration

//## begin module%64DF80D001AB.epilog preserve=yes
//## end module%64DF80D001AB.epilog
