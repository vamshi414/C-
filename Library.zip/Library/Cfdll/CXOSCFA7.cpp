//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5949894E03B0.cm preserve=no
//	$Date:   Jun 23 2017 10:12:24  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5949894E03B0.cm

//## begin module%5949894E03B0.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5949894E03B0.cp

//## Module: CXOSCFA7%5949894E03B0; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.8A.R004\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFA7.cpp

//## begin module%5949894E03B0.additionalIncludes preserve=no
//## end module%5949894E03B0.additionalIncludes

//## begin module%5949894E03B0.includes preserve=yes
//## end module%5949894E03B0.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFA7_h
#include "CXODCFA7.hpp"
#endif


//## begin module%5949894E03B0.declarations preserve=no
//## end module%5949894E03B0.declarations

//## begin module%5949894E03B0.additionalDeclarations preserve=yes
//## end module%5949894E03B0.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::SettlementWebAdjNetId 

SettlementWebAdjNetId::SettlementWebAdjNetId()
  //## begin SettlementWebAdjNetId::SettlementWebAdjNetId%594988BB00A7_const.hasinit preserve=no
  //## end SettlementWebAdjNetId::SettlementWebAdjNetId%594988BB00A7_const.hasinit
  //## begin SettlementWebAdjNetId::SettlementWebAdjNetId%594988BB00A7_const.initialization preserve=yes
  : ConversionItem("## CRA7 XLATE SETTLEMENT NETID")
  //## end SettlementWebAdjNetId::SettlementWebAdjNetId%594988BB00A7_const.initialization
{
  //## begin configuration::SettlementWebAdjNetId::SettlementWebAdjNetId%594988BB00A7_const.body preserve=yes
   memcpy(m_sID,"CFA7",4);
  //## end configuration::SettlementWebAdjNetId::SettlementWebAdjNetId%594988BB00A7_const.body
}


SettlementWebAdjNetId::~SettlementWebAdjNetId()
{
  //## begin configuration::SettlementWebAdjNetId::~SettlementWebAdjNetId%594988BB00A7_dest.body preserve=yes
  //## end configuration::SettlementWebAdjNetId::~SettlementWebAdjNetId%594988BB00A7_dest.body
}



//## Other Operations (implementation)
void SettlementWebAdjNetId::bind (Query& hQuery)
{
  //## begin configuration::SettlementWebAdjNetId::bind%594988E60081.body preserve=yes
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.setQualifier("QUALIFY","X_WEB_ADJ_NETID");
   hQuery.bind("X_WEB_ADJ_NETID","X_WEB_ADJ_NETID",Column::STRING,&m_strFirst);
   hQuery.bind("X_WEB_ADJ_NETID","NET_ID",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_WEB_ADJ_NETID","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_WEB_ADJ_NETID","CC_STATE","=","A");
   string strTemp = "('" + strCUST_ID + "','****')";
   hQuery.setBasicPredicate("X_WEB_ADJ_NETID","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_WEB_ADJ_NETID.X_WEB_ADJ_NETID ASC,X_WEB_ADJ_NETID.CUST_ID DESC");
  //## end configuration::SettlementWebAdjNetId::bind%594988E60081.body
}

// Additional Declarations
  //## begin configuration::SettlementWebAdjNetId%594988BB00A7.declarations preserve=yes
  //## end configuration::SettlementWebAdjNetId%594988BB00A7.declarations

} // namespace configuration

//## begin module%5949894E03B0.epilog preserve=yes
//## end module%5949894E03B0.epilog
