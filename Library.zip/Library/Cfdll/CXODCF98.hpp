//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4AE5D1140123.cm preserve=no
//	$Date:   Dec 12 2016 15:36:14  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%4AE5D1140123.cm

//## begin module%4AE5D1140123.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4AE5D1140123.cp

//## Module: CXOSCF98%4AE5D1140123; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF98.hpp

#ifndef CXOSCF98_h
#define CXOSCF98_h 1

//## begin module%4AE5D1140123.additionalIncludes preserve=no
//## end module%4AE5D1140123.additionalIncludes

//## begin module%4AE5D1140123.includes preserve=yes
//## end module%4AE5D1140123.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%4AE5D1140123.declarations preserve=no
//## end module%4AE5D1140123.declarations

//## begin module%4AE5D1140123.additionalDeclarations preserve=yes
//## end module%4AE5D1140123.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ErrorMessage%4AE5D0E30365.preface preserve=yes
//## end configuration::ErrorMessage%4AE5D0E30365.preface

//## Class: ErrorMessage%4AE5D0E30365
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4AE5E24E00BF;reusable::Query { -> F}

class DllExport ErrorMessage : public ConversionItem  //## Inherits: <unnamed>%4AE5D2AA03DF
{
  //## begin configuration::ErrorMessage%4AE5D0E30365.initialDeclarations preserve=yes
  //## end configuration::ErrorMessage%4AE5D0E30365.initialDeclarations

  public:
    //## Constructors (generated)
      ErrorMessage();

    //## Destructor (generated)
      virtual ~ErrorMessage();


    //## Other Operations (specified)
      //## Operation: bind%4AE5D30A02C5
      virtual void bind (Query& hQuery);

      //## Operation: getSecond%4AE5D30F0219
      virtual const string& getSecond ();

      //## Operation: setPredicate%584F177802CA
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ErrorMessage%4AE5D0E30365.public preserve=yes
      //## end configuration::ErrorMessage%4AE5D0E30365.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ErrorMessage%4AE5D0E30365.protected preserve=yes
      //## end configuration::ErrorMessage%4AE5D0E30365.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ErrorMessage%4AE5D0E30365.private preserve=yes
      //## end configuration::ErrorMessage%4AE5D0E30365.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ErrorMessage%4AE5D0E30365.implementation preserve=yes
      //## end configuration::ErrorMessage%4AE5D0E30365.implementation

};

//## begin configuration::ErrorMessage%4AE5D0E30365.postscript preserve=yes
//## end configuration::ErrorMessage%4AE5D0E30365.postscript

} // namespace configuration

//## begin module%4AE5D1140123.epilog preserve=yes
//## end module%4AE5D1140123.epilog


#endif
