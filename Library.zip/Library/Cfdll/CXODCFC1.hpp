//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%614713270290.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%614713270290.cm

//## begin module%614713270290.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%614713270290.cp

//## Module: CXOSCFC1%614713270290; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCFC1.hpp

#ifndef CXOSCFC1_h
#define CXOSCFC1_h 1

//## begin module%614713270290.additionalIncludes preserve=no
//## end module%614713270290.additionalIncludes

//## begin module%614713270290.includes preserve=yes
//## end module%614713270290.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
   class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
   class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
   class Extract;

} // namespace IF

//## begin module%614713270290.declarations preserve=no
//## end module%614713270290.declarations

//## begin module%614713270290.additionalDeclarations preserve=yes
//## end module%614713270290.additionalDeclarations


namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::LoyaltyBin%614713A801F3.preface preserve=yes
//## end configuration::LoyaltyBin%614713A801F3.preface

//## Class: LoyaltyBin%614713A801F3
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6147148803C7;reusable::Query { -> F}
//## Uses: <unnamed>%6147148B034F;IF::Extract { -> F}
//## Uses: <unnamed>%6147148E009F;ConfigurationRepository { -> F}

class DllExport LoyaltyBin : public ConversionItem  //## Inherits: <unnamed>%61471412004D
{
   //## begin configuration::LoyaltyBin%614713A801F3.initialDeclarations preserve=yes
   //## end configuration::LoyaltyBin%614713A801F3.initialDeclarations

public:
   //## Constructors (generated)
   LoyaltyBin();

   //## Destructor (generated)
   virtual ~LoyaltyBin();


   //## Other Operations (specified)
     //## Operation: bind%614714930301
   virtual void bind(Query& hQuery);

   //## Operation: getBin%614714BA0148
   static bool getBin(const string& strRECORD_TYPE, const string& strINST_ID, const string& strBIN, int& iLength, string& strLOYALTY_FLG);

   //## Operation: getFirst%61471AF30200
   virtual const reusable::string& getFirst();

   //## Operation: getThird%614715310014
   virtual const reusable::string& getThird();

   // Additional Public Declarations
     //## begin configuration::LoyaltyBin%614713A801F3.public preserve=yes
     //## end configuration::LoyaltyBin%614713A801F3.public

protected:
   // Additional Protected Declarations
     //## begin configuration::LoyaltyBin%614713A801F3.protected preserve=yes
     //## end configuration::LoyaltyBin%614713A801F3.protected

private:
   // Additional Private Declarations
     //## begin configuration::LoyaltyBin%614713A801F3.private preserve=yes
     //## end configuration::LoyaltyBin%614713A801F3.private

private: //## implementation
  // Data Members for Class Attributes

    //## Attribute: AGENT_ID%614716A1014B
    //## begin configuration::LoyaltyBin::AGENT_ID%614716A1014B.attr preserve=no  private: string {U} 
   string m_strAGENT_ID;
   //## end configuration::LoyaltyBin::AGENT_ID%614716A1014B.attr

   //## Attribute: ASSOC_ID%614716470128
   //## begin configuration::LoyaltyBin::ASSOC_ID%614716470128.attr preserve=no  private: string {U} 
   string m_strASSOC_ID;
   //## end configuration::LoyaltyBin::ASSOC_ID%614716470128.attr

   //## Attribute: BIN%614717D50323
   //## begin configuration::LoyaltyBin::BIN%614717D50323.attr preserve=no  private: string {U} 
   string m_strBIN;
   //## end configuration::LoyaltyBin::BIN%614717D50323.attr

   //## Attribute: CORP_ID%6147166E02D3
   //## begin configuration::LoyaltyBin::CORP_ID%6147166E02D3.attr preserve=no  private: string {U} 
   string m_strCORP_ID;
   //## end configuration::LoyaltyBin::CORP_ID%6147166E02D3.attr

   //## Attribute: INST_ID%6148812902B3
   //## begin configuration::LoyaltyBin::INST_ID%6148812902B3.attr preserve=no  private: string {U} 
   string m_strINST_ID;
   //## end configuration::LoyaltyBin::INST_ID%6148812902B3.attr

   //## Attribute: PROGRAM_ID%614716830007
   //## begin configuration::LoyaltyBin::PROGRAM_ID%614716830007.attr preserve=no  private: string {U} 
   string m_strPROGRAM_ID;
   //## end configuration::LoyaltyBin::PROGRAM_ID%614716830007.attr

 // Additional Implementation Declarations
   //## begin configuration::LoyaltyBin%614713A801F3.implementation preserve=yes
   string m_strPROC_ID;
   //## end configuration::LoyaltyBin%614713A801F3.implementation
};

//## begin configuration::LoyaltyBin%614713A801F3.postscript preserve=yes
//## end configuration::LoyaltyBin%614713A801F3.postscript

} // namespace configuration

//## begin module%614713270290.epilog preserve=yes
//## end module%614713270290.epilog


#endif
