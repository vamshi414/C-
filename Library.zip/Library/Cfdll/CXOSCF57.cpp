//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFDAF970232.cm preserve=no
//	$Date:   Dec 16 2016 15:26:00  $ $Author:   e1009652  $
//	$Revision:   1.4  $
//## end module%3FFDAF970232.cm

//## begin module%3FFDAF970232.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFDAF970232.cp

//## Module: CXOSCF57%3FFDAF970232; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF57.cpp

//## begin module%3FFDAF970232.additionalIncludes preserve=no
//## end module%3FFDAF970232.additionalIncludes

//## begin module%3FFDAF970232.includes preserve=yes
// $Date:   Dec 16 2016 15:26:00  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%3FFDAF970232.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF57_h
#include "CXODCF57.hpp"
#endif
//## begin module%3FFDAF970232.declarations preserve=no
//## end module%3FFDAF970232.declarations

//## begin module%3FFDAF970232.additionalDeclarations preserve=yes
//## end module%3FFDAF970232.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexTerminalType2 

ConnexTerminalType2::ConnexTerminalType2()
  //## begin ConnexTerminalType2::ConnexTerminalType2%3FFDA85B006D_const.hasinit preserve=no
  //## end ConnexTerminalType2::ConnexTerminalType2%3FFDA85B006D_const.hasinit
  //## begin ConnexTerminalType2::ConnexTerminalType2%3FFDA85B006D_const.initialization preserve=yes
  : ConversionItem("## CR69 XLATE TERM TYPE2")
  //## end ConnexTerminalType2::ConnexTerminalType2%3FFDA85B006D_const.initialization
{
  //## begin configuration::ConnexTerminalType2::ConnexTerminalType2%3FFDA85B006D_const.body preserve=yes
   memcpy(m_sID,"CF57",4);
  //## end configuration::ConnexTerminalType2::ConnexTerminalType2%3FFDA85B006D_const.body
}


ConnexTerminalType2::~ConnexTerminalType2()
{
  //## begin configuration::ConnexTerminalType2::~ConnexTerminalType2%3FFDA85B006D_dest.body preserve=yes
  //## end configuration::ConnexTerminalType2::~ConnexTerminalType2%3FFDA85B006D_dest.body
}



//## Other Operations (implementation)
void ConnexTerminalType2::bind (Query& hQuery)
{
  //## begin configuration::ConnexTerminalType2::bind%3FFDA87E0290.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_IBM_POS_TDT");
   hQuery.bind("X_IBM_POS_TDT","TDT",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_POS_TDT","TERM_CLASS",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_IBM_POS_TDT","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_TDT","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IBM_POS_TDT.TDT ASC");
  //## end configuration::ConnexTerminalType2::bind%3FFDA87E0290.body
}

void ConnexTerminalType2::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexTerminalType2::setPredicate%5847169E0140.body preserve=yes
   hQuery.setBasicPredicate("X_IBM_POS_TDT", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_TDT", "CC_STATE", "=", "A");
  //## end configuration::ConnexTerminalType2::setPredicate%5847169E0140.body
}

// Additional Declarations
  //## begin configuration::ConnexTerminalType2%3FFDA85B006D.declarations preserve=yes
  //## end configuration::ConnexTerminalType2%3FFDA85B006D.declarations

} // namespace configuration

//## begin module%3FFDAF970232.epilog preserve=yes
//## end module%3FFDAF970232.epilog
