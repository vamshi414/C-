//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%39985C9B0381.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%39985C9B0381.cm

//## begin module%39985C9B0381.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%39985C9B0381.cp

//## Module: CXOSCF34%39985C9B0381; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF34.hpp

#ifndef CXOSCF34_h
#define CXOSCF34_h 1

//## begin module%39985C9B0381.additionalIncludes preserve=no
//## end module%39985C9B0381.additionalIncludes

//## begin module%39985C9B0381.includes preserve=yes
// $Date:   Apr 08 2004 14:10:58  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%39985C9B0381.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%39985C9B0381.declarations preserve=no
//## end module%39985C9B0381.declarations

//## begin module%39985C9B0381.additionalDeclarations preserve=yes
//## end module%39985C9B0381.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::Base24POSProcessCode%39985CDD029F.preface preserve=yes
//## end configuration::Base24POSProcessCode%39985CDD029F.preface

//## Class: Base24POSProcessCode%39985CDD029F
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%39985FF900C3;reusable::Query { -> F}
//## Uses: <unnamed>%39985FFA02EB;IF::Extract { -> F}

class DllExport Base24POSProcessCode : public ConversionItem  //## Inherits: <unnamed>%39985FFC01CC
{
  //## begin configuration::Base24POSProcessCode%39985CDD029F.initialDeclarations preserve=yes
  //## end configuration::Base24POSProcessCode%39985CDD029F.initialDeclarations

  public:
    //## Constructors (generated)
      Base24POSProcessCode();

    //## Destructor (generated)
      virtual ~Base24POSProcessCode();


    //## Other Operations (specified)
      //## Operation: bind%39993BFE01BF
      virtual void bind (Query& hQuery);

      //## Operation: getSecond%39993BFE01C1
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::Base24POSProcessCode%39985CDD029F.public preserve=yes
      //## end configuration::Base24POSProcessCode%39985CDD029F.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::Base24POSProcessCode%39985CDD029F.protected preserve=yes
      //## end configuration::Base24POSProcessCode%39985CDD029F.protected

  private:
    // Additional Private Declarations
      //## begin configuration::Base24POSProcessCode%39985CDD029F.private preserve=yes
      //## end configuration::Base24POSProcessCode%39985CDD029F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: PROCESS_CODE%3998608601C0
      //## begin configuration::Base24POSProcessCode::PROCESS_CODE%3998608601C0.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::Base24POSProcessCode::PROCESS_CODE%3998608601C0.attr

      //## Attribute: MSG_CLASS%3998608601C1
      //## begin configuration::Base24POSProcessCode::MSG_CLASS%3998608601C1.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::Base24POSProcessCode::MSG_CLASS%3998608601C1.attr

      //## Attribute: PRE_AUTH%3998608601CA
      //## begin configuration::Base24POSProcessCode::PRE_AUTH%3998608601CA.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::Base24POSProcessCode::PRE_AUTH%3998608601CA.attr

      //## Attribute: MEDIA_TYPE%3998608601D4
      //## begin configuration::Base24POSProcessCode::MEDIA_TYPE%3998608601D4.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::Base24POSProcessCode::MEDIA_TYPE%3998608601D4.attr

    // Additional Implementation Declarations
      //## begin configuration::Base24POSProcessCode%39985CDD029F.implementation preserve=yes
      //## end configuration::Base24POSProcessCode%39985CDD029F.implementation

};

//## begin configuration::Base24POSProcessCode%39985CDD029F.postscript preserve=yes
//## end configuration::Base24POSProcessCode%39985CDD029F.postscript

} // namespace configuration

//## begin module%39985C9B0381.epilog preserve=yes
using namespace configuration;
//## end module%39985C9B0381.epilog


#endif
