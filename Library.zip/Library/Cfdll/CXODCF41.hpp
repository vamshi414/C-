//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3ACA39C10026.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3ACA39C10026.cm

//## begin module%3ACA39C10026.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3ACA39C10026.cp

//## Module: CXOSCF41%3ACA39C10026; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF41.hpp

#ifndef CXOSCF41_h
#define CXOSCF41_h 1

//## begin module%3ACA39C10026.additionalIncludes preserve=no
//## end module%3ACA39C10026.additionalIncludes

//## begin module%3ACA39C10026.includes preserve=yes
// $Date:   Apr 08 2004 14:11:00  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%3ACA39C10026.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%3ACA39C10026.declarations preserve=no
//## end module%3ACA39C10026.declarations

//## begin module%3ACA39C10026.additionalDeclarations preserve=yes
//## end module%3ACA39C10026.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::MappingItem%3ACA392B014D.preface preserve=yes
//## end configuration::MappingItem%3ACA392B014D.preface

//## Class: MappingItem%3ACA392B014D
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3ACB7517014D;reusable::Query { -> F}

class DllExport MappingItem : public reusable::Object  //## Inherits: <unnamed>%3ACA3B240117
{
  //## begin configuration::MappingItem%3ACA392B014D.initialDeclarations preserve=yes
  //## end configuration::MappingItem%3ACA392B014D.initialDeclarations

  public:
    //## Constructors (generated)
      MappingItem();

    //## Constructors (specified)
      //## Operation: MappingItem%3ACA3B8801CF
      MappingItem (const char* pszMember);

    //## Destructor (generated)
      virtual ~MappingItem();


    //## Other Operations (specified)
      //## Operation: bind%3ACA3BB200AD
      virtual void bind (Query& hQuery);

      //## Operation: getPrimary%3ACA3BB50382
      virtual const string& getPrimary ();

      //## Operation: getSecondary%3ACA3BB800FC
      virtual const string& getSecondary ();

      //## Operation: getTertiary%3ACDD5E900A0
      virtual const string& getTertiary ();

      //## Operation: getResult%3ACDD60E014E
      virtual const string& getResult ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Member%3ACA3BCD035F
      const string& getMember () const
      {
        //## begin configuration::MappingItem::getMember%3ACA3BCD035F.get preserve=no
        return m_strMember;
        //## end configuration::MappingItem::getMember%3ACA3BCD035F.get
      }


    // Additional Public Declarations
      //## begin configuration::MappingItem%3ACA392B014D.public preserve=yes
      //## end configuration::MappingItem%3ACA392B014D.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: CUST_ID%3ACA3BC4024E
      //## begin configuration::MappingItem::CUST_ID%3ACA3BC4024E.attr preserve=no  private: string {U} 
      string m_strCUST_ID;
      //## end configuration::MappingItem::CUST_ID%3ACA3BC4024E.attr

      //## Attribute: Primary%3ACA3BC902B9
      //## begin configuration::MappingItem::Primary%3ACA3BC902B9.attr preserve=no  public: string {U} 
      string m_strPrimary;
      //## end configuration::MappingItem::Primary%3ACA3BC902B9.attr

      //## Attribute: Result%3ACDE9100368
      //## begin configuration::MappingItem::Result%3ACDE9100368.attr preserve=no  public: string {U} 
      string m_strResult;
      //## end configuration::MappingItem::Result%3ACDE9100368.attr

      //## Attribute: Secondary%3ACA3BD00183
      //## begin configuration::MappingItem::Secondary%3ACA3BD00183.attr preserve=no  public: string {U} 
      string m_strSecondary;
      //## end configuration::MappingItem::Secondary%3ACA3BD00183.attr

      //## Attribute: Tertiary%3ACDE8E302CD
      //## begin configuration::MappingItem::Tertiary%3ACDE8E302CD.attr preserve=no  public: string {U} 
      string m_strTertiary;
      //## end configuration::MappingItem::Tertiary%3ACDE8E302CD.attr

    // Additional Protected Declarations
      //## begin configuration::MappingItem%3ACA392B014D.protected preserve=yes
      //## end configuration::MappingItem%3ACA392B014D.protected

  private:
    // Additional Private Declarations
      //## begin configuration::MappingItem%3ACA392B014D.private preserve=yes
      //## end configuration::MappingItem%3ACA392B014D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin configuration::MappingItem::Member%3ACA3BCD035F.attr preserve=no  public: string {U} 
      string m_strMember;
      //## end configuration::MappingItem::Member%3ACA3BCD035F.attr

    // Additional Implementation Declarations
      //## begin configuration::MappingItem%3ACA392B014D.implementation preserve=yes
      //## end configuration::MappingItem%3ACA392B014D.implementation

};

//## begin configuration::MappingItem%3ACA392B014D.postscript preserve=yes
//## end configuration::MappingItem%3ACA392B014D.postscript

} // namespace configuration

//## begin module%3ACA39C10026.epilog preserve=yes
using namespace configuration;
//## end module%3ACA39C10026.epilog


#endif
