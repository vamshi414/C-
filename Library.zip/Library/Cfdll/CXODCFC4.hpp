//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%620DB6F40354.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%620DB6F40354.cm

//## begin module%620DB6F40354.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%620DB6F40354.cp

//## Module: CXOSCFC4%620DB6F40354; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCFC4.hpp

#ifndef CXOSCFC4_h
#define CXOSCFC4_h 1

//## begin module%620DB6F40354.additionalIncludes preserve=no
//## end module%620DB6F40354.additionalIncludes

//## begin module%620DB6F40354.includes preserve=yes
//## end module%620DB6F40354.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%620DB6F40354.declarations preserve=no
//## end module%620DB6F40354.declarations

//## begin module%620DB6F40354.additionalDeclarations preserve=yes
//## end module%620DB6F40354.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::AIMSBillingInstitution%620DB6B7030F.preface preserve=yes
//## end configuration::AIMSBillingInstitution%620DB6B7030F.preface

//## Class: AIMSBillingInstitution%620DB6B7030F
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%620DCB1A0148;reusable::Query { -> F}
//## Uses: <unnamed>%620DCB1E0167;IF::Extract { -> F}

class DllExport AIMSBillingInstitution : public ConversionItem  //## Inherits: <unnamed>%620DCB14015F
{
  //## begin configuration::AIMSBillingInstitution%620DB6B7030F.initialDeclarations preserve=yes
  //## end configuration::AIMSBillingInstitution%620DB6B7030F.initialDeclarations

  public:
    //## Constructors (generated)
      AIMSBillingInstitution();

    //## Destructor (generated)
      virtual ~AIMSBillingInstitution();


    //## Other Operations (specified)
      //## Operation: bind%620DCB3401B4
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%620DCB4B039C
      virtual const string& getFirst ();

      //## Operation: getSecond%620DCB4E0127
      virtual const string& getSecond ();

      //## Operation: getThird%620FB46A01F2
      virtual const string& getThird ();

    // Additional Public Declarations
      //## begin configuration::AIMSBillingInstitution%620DB6B7030F.public preserve=yes
      //## end configuration::AIMSBillingInstitution%620DB6B7030F.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::AIMSBillingInstitution%620DB6B7030F.protected preserve=yes
      //## end configuration::AIMSBillingInstitution%620DB6B7030F.protected

  private:
    // Additional Private Declarations
      //## begin configuration::AIMSBillingInstitution%620DB6B7030F.private preserve=yes
      //## end configuration::AIMSBillingInstitution%620DB6B7030F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CATEGORY_ID%620DCC3D021B
      //## begin configuration::AIMSBillingInstitution::CATEGORY_ID%620DCC3D021B.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strCATEGORY_ID;
      //## end configuration::AIMSBillingInstitution::CATEGORY_ID%620DCC3D021B.attr

      //## Attribute: ITEM_NO%620DCC4002C2
      //## begin configuration::AIMSBillingInstitution::ITEM_NO%620DCC4002C2.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strITEM_NO;
      //## end configuration::AIMSBillingInstitution::ITEM_NO%620DCC4002C2.attr

    // Additional Implementation Declarations
      //## begin configuration::AIMSBillingInstitution%620DB6B7030F.implementation preserve=yes
      //## end configuration::AIMSBillingInstitution%620DB6B7030F.implementation

};

//## begin configuration::AIMSBillingInstitution%620DB6B7030F.postscript preserve=yes
//## end configuration::AIMSBillingInstitution%620DB6B7030F.postscript

} // namespace configuration

//## begin module%620DB6F40354.epilog preserve=yes
//## end module%620DB6F40354.epilog


#endif
