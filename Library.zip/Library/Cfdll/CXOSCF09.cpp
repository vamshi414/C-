//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%391BFDEC0370.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%391BFDEC0370.cm

//## begin module%391BFDEC0370.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%391BFDEC0370.cp

//## Module: CXOSCF09%391BFDEC0370; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF09.cpp

//## begin module%391BFDEC0370.additionalIncludes preserve=no
//## end module%391BFDEC0370.additionalIncludes

//## begin module%391BFDEC0370.includes preserve=yes
// $Date:   Apr 17 2014 20:59:18  $ $Author:   e1009652  $ $Revision:   1.9  $
//## end module%391BFDEC0370.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF09_h
#include "CXODCF09.hpp"
#endif


//## begin module%391BFDEC0370.declarations preserve=no
//## end module%391BFDEC0370.declarations

//## begin module%391BFDEC0370.additionalDeclarations preserve=yes
//## end module%391BFDEC0370.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::AdvantageProcessCode 

AdvantageProcessCode::AdvantageProcessCode()
  //## begin AdvantageProcessCode::AdvantageProcessCode%391C2D4C00DA_const.hasinit preserve=no
  //## end AdvantageProcessCode::AdvantageProcessCode%391C2D4C00DA_const.hasinit
  //## begin AdvantageProcessCode::AdvantageProcessCode%391C2D4C00DA_const.initialization preserve=yes
   : ConversionItem("## CR12 XLATE PROCESS CODE")
  //## end AdvantageProcessCode::AdvantageProcessCode%391C2D4C00DA_const.initialization
{
  //## begin configuration::AdvantageProcessCode::AdvantageProcessCode%391C2D4C00DA_const.body preserve=yes
   memcpy(m_sID,"CF09",4);
  //## end configuration::AdvantageProcessCode::AdvantageProcessCode%391C2D4C00DA_const.body
}


AdvantageProcessCode::~AdvantageProcessCode()
{
  //## begin configuration::AdvantageProcessCode::~AdvantageProcessCode%391C2D4C00DA_dest.body preserve=yes
  //## end configuration::AdvantageProcessCode::~AdvantageProcessCode%391C2D4C00DA_dest.body
}



//## Other Operations (implementation)
void AdvantageProcessCode::bind (Query& hQuery)
{
  //## begin configuration::AdvantageProcessCode::bind%391C2DE8032D.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_ADV_PROC_CODE");
   hQuery.bind("X_ADV_PROC_CODE","ADVG_PROCESS_CODE",Column::STRING,&m_strADVG_PROCESS_CODE);
   hQuery.bind("X_ADV_PROC_CODE","ADVG_MSG_CLASS",Column::STRING,&m_strADVG_MSG_CLASS);
   hQuery.bind("X_ADV_PROC_CODE","ADVG_ACCT_QUAL_1",Column::STRING,&m_strADVG_ACCT_QUAL_1);
   hQuery.bind("X_ADV_PROC_CODE","ADVG_PRE_AUTH",Column::STRING,&m_strADVG_PRE_AUTH);
   hQuery.bind("X_ADV_PROC_CODE","ADVG_TRAN_DESC",Column::STRING,&m_strADVG_TRAN_DESC);
   hQuery.bind("X_ADV_PROC_CODE","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("X_ADV_PROC_CODE","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("X_ADV_PROC_CODE","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("X_ADV_PROC_CODE","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("X_ADV_PROC_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_ADV_PROC_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_ADV_PROC_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_ADV_PROC_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_ADV_PROC_CODE.ADVG_PROCESS_CODE ASC,"
                           "X_ADV_PROC_CODE.ADVG_MSG_CLASS ASC,"
                           "X_ADV_PROC_CODE.ADVG_ACCT_QUAL_1 ASC,"
                           "X_ADV_PROC_CODE.ADVG_PRE_AUTH ASC,"
                           "X_ADV_PROC_CODE.ADVG_TRAN_DESC ASC,"
                           "X_ADV_PROC_CODE.CUST_ID DESC");
  //## end configuration::AdvantageProcessCode::bind%391C2DE8032D.body
}

const string& AdvantageProcessCode::getFirst ()
{
  //## begin configuration::AdvantageProcessCode::getFirst%391C2DE80373.body preserve=yes
   while (m_strADVG_PROCESS_CODE.length() < 6)
      m_strADVG_PROCESS_CODE += ' ';
   while (m_strADVG_MSG_CLASS.length() < 1)
      m_strADVG_MSG_CLASS += ' ';
   while (m_strADVG_ACCT_QUAL_1.length() < 3)
      m_strADVG_ACCT_QUAL_1 += ' ';
   while (m_strADVG_PRE_AUTH.length() < 1)
      m_strADVG_PRE_AUTH += ' ';
   m_strFirst = m_strADVG_PROCESS_CODE + m_strADVG_MSG_CLASS + 
      m_strADVG_ACCT_QUAL_1 + m_strADVG_PRE_AUTH + m_strADVG_TRAN_DESC;
   return m_strFirst;
  //## end configuration::AdvantageProcessCode::getFirst%391C2DE80373.body
}

const string& AdvantageProcessCode::getSecond ()
{
  //## begin configuration::AdvantageProcessCode::getSecond%3920521C03B1.body preserve=yes
   while (m_strPROCESS_CODE.length() < 6)
      m_strPROCESS_CODE += ' ';
   while (m_strMSG_CLASS.length() < 1)
      m_strMSG_CLASS += ' ';
   while (m_strPRE_AUTH.length() < 1)
      m_strPRE_AUTH += ' ';
   m_strSecond = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strSecond;
  //## end configuration::AdvantageProcessCode::getSecond%3920521C03B1.body
}

// Additional Declarations
  //## begin configuration::AdvantageProcessCode%391C2D4C00DA.declarations preserve=yes
  //## end configuration::AdvantageProcessCode%391C2D4C00DA.declarations

} // namespace configuration

//## begin module%391BFDEC0370.epilog preserve=yes
//## end module%391BFDEC0370.epilog
