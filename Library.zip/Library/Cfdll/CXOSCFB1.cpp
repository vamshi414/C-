//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5CF7C99B0140.cm preserve=no
//	$Date:   Jun 06 2019 14:02:44  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5CF7C99B0140.cm

//## begin module%5CF7C99B0140.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5CF7C99B0140.cp

//## Module: CXOSCFB1%5CF7C99B0140; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV03.0A.R002\Windows\Build\Dn\Server\Library\Cfdll\CXOSCFB1.cpp

//## begin module%5CF7C99B0140.additionalIncludes preserve=no
//## end module%5CF7C99B0140.additionalIncludes

//## begin module%5CF7C99B0140.includes preserve=yes
//## end module%5CF7C99B0140.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSCFB1_h
#include "CXODCFB1.hpp"
#endif


//## begin module%5CF7C99B0140.declarations preserve=no
//## end module%5CF7C99B0140.declarations

//## begin module%5CF7C99B0140.additionalDeclarations preserve=yes
//## end module%5CF7C99B0140.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::CurrencyCode 

CurrencyCode::CurrencyCode()
  //## begin CurrencyCode::CurrencyCode%5CF7C70E0081_const.hasinit preserve=no
  //## end CurrencyCode::CurrencyCode%5CF7C70E0081_const.hasinit
  //## begin CurrencyCode::CurrencyCode%5CF7C70E0081_const.initialization preserve=yes
   : ConversionItem("## CFB1 XLATE COUNTRY CODE")
  //## end CurrencyCode::CurrencyCode%5CF7C70E0081_const.initialization
{
  //## begin configuration::CurrencyCode::CurrencyCode%5CF7C70E0081_const.body preserve=yes
   memcpy(m_sID, "CFB1", 4);
  //## end configuration::CurrencyCode::CurrencyCode%5CF7C70E0081_const.body
}


CurrencyCode::~CurrencyCode()
{
  //## begin configuration::CurrencyCode::~CurrencyCode%5CF7C70E0081_dest.body preserve=yes
  //## end configuration::CurrencyCode::~CurrencyCode%5CF7C70E0081_dest.body
}



//## Other Operations (implementation)
void CurrencyCode::bind (Query& hQuery)
{
  //## begin configuration::CurrencyCode::bind%5CF7CA7102F5.body preserve=yes
   hQuery.setQualifier("QUALIFY", "CURRENCY_CODE");
   hQuery.bind("CURRENCY_CODE", "CURRENCY_CODE", Column::STRING, &m_strFirst);
   hQuery.bind("CURRENCY_CODE", "CURRENCY_CODE_ISO3", Column::STRING, &m_strSecond);
   hQuery.setBasicPredicate("CURRENCY_CODE", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("CURRENCY_CODE", "CC_STATE", "=", "A");
   string strTemp = "('" + entitysegment::Customer::instance()->getCUST_ID() + "','****')";
   hQuery.setBasicPredicate("CURRENCY_CODE", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("CURRENCY_CODE.CURRENCY_CODE ASC");
  //## end configuration::CurrencyCode::bind%5CF7CA7102F5.body
}

// Additional Declarations
  //## begin configuration::CurrencyCode%5CF7C70E0081.declarations preserve=yes
  //## end configuration::CurrencyCode%5CF7C70E0081.declarations

} // namespace configuration

//## begin module%5CF7C99B0140.epilog preserve=yes
//## end module%5CF7C99B0140.epilog
