//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40F53094036B.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40F53094036B.cm

//## begin module%40F53094036B.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40F53094036B.cp

//## Module: CXOSCF69%40F53094036B; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF69.cpp

//## begin module%40F53094036B.additionalIncludes preserve=no
//## end module%40F53094036B.additionalIncludes

//## begin module%40F53094036B.includes preserve=yes
// $Date:   Nov 10 2014 11:32:16  $ $Author:   e1009674  $ $Revision:   1.3  $
//## end module%40F53094036B.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF69_h
#include "CXODCF69.hpp"
#endif


//## begin module%40F53094036B.declarations preserve=no
//## end module%40F53094036B.declarations

//## begin module%40F53094036B.additionalDeclarations preserve=yes
//## end module%40F53094036B.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::NetworkMiscDataRev 

NetworkMiscDataRev::NetworkMiscDataRev()
  //## begin NetworkMiscDataRev::NetworkMiscDataRev%40F52F980109_const.hasinit preserve=no
  //## end NetworkMiscDataRev::NetworkMiscDataRev%40F52F980109_const.hasinit
  //## begin NetworkMiscDataRev::NetworkMiscDataRev%40F52F980109_const.initialization preserve=yes
   : ConversionItem("## CR76 XLATE NET MISC DATA REV ")
  //## end NetworkMiscDataRev::NetworkMiscDataRev%40F52F980109_const.initialization
{
  //## begin configuration::NetworkMiscDataRev::NetworkMiscDataRev%40F52F980109_const.body preserve=yes
   memcpy(m_sID,"CF69",4);
  //## end configuration::NetworkMiscDataRev::NetworkMiscDataRev%40F52F980109_const.body
}


NetworkMiscDataRev::~NetworkMiscDataRev()
{
  //## begin configuration::NetworkMiscDataRev::~NetworkMiscDataRev%40F52F980109_dest.body preserve=yes
  //## end configuration::NetworkMiscDataRev::~NetworkMiscDataRev%40F52F980109_dest.body
}



//## Other Operations (implementation)
void NetworkMiscDataRev::bind (reusable::Query& hQuery)
{
  //## begin configuration::NetworkMiscDataRev::bind%40F5306100FA.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_NET_MISC_DATA");
   hQuery.bind("X_NET_MISC_DATA","NET_ID",Column::STRING,&m_strNET_ID);
   hQuery.bind("X_NET_MISC_DATA","DATA_ELEMENT",Column::STRING,&m_strDATA_ELEMENT);
   hQuery.bind("X_NET_MISC_DATA","SUB_ELEMENT",Column::STRING,&m_strSUB_ELEMENT);
   hQuery.bind("X_NET_MISC_DATA","DATA_VALUE",Column::STRING,&m_strDATA_VALUE);
   hQuery.bind("X_NET_MISC_DATA","NETWORK_VALUE",Column::STRING,&m_strNETWORK_VALUE);
   hQuery.bind("X_NET_MISC_DATA","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.bind("X_NET_MISC_DATA","DATA_TYPE",Column::STRING,&m_strDATA_TYPE);
   hQuery.setBasicPredicate("X_NET_MISC_DATA","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_NET_MISC_DATA","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_NET_MISC_DATA","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_NET_MISC_DATA.NET_ID ASC,"
                           "X_NET_MISC_DATA.DATA_ELEMENT ASC,"
                           "X_NET_MISC_DATA.SUB_ELEMENT ASC,"
                           "X_NET_MISC_DATA.DATA_TYPE ASC,"
                           "X_NET_MISC_DATA.NETWORK_VALUE ASC,"
                           "X_NET_MISC_DATA.CUST_ID DESC");
  //## end configuration::NetworkMiscDataRev::bind%40F5306100FA.body
}

const string& NetworkMiscDataRev::getFirst ()
{
  //## begin configuration::NetworkMiscDataRev::getFirst%40F5306401A5.body preserve=yes
   m_strFirst = m_strNET_ID;
   m_strFirst.resize(3,' ');
   m_strFirst.append(m_strDATA_ELEMENT);
   m_strFirst.resize(5,' ');
   m_strFirst.append(m_strSUB_ELEMENT);
   m_strFirst.resize(7,' ');
   m_strFirst.append(m_strDATA_TYPE);
   m_strFirst.append(m_strNETWORK_VALUE);
   m_strFirst.resize(11,' ');
   m_strDATA_VALUE.resize(3,' ');
   return m_strFirst;
  //## end configuration::NetworkMiscDataRev::getFirst%40F5306401A5.body
}

const string& NetworkMiscDataRev::getSecond ()
{
  //## begin configuration::NetworkMiscDataRev::getSecond%40F530670119.body preserve=yes
   return m_strDATA_VALUE;
  //## end configuration::NetworkMiscDataRev::getSecond%40F530670119.body
}

// Additional Declarations
  //## begin configuration::NetworkMiscDataRev%40F52F980109.declarations preserve=yes
  //## end configuration::NetworkMiscDataRev%40F52F980109.declarations

} // namespace configuration

//## begin module%40F53094036B.epilog preserve=yes
//## end module%40F53094036B.epilog
