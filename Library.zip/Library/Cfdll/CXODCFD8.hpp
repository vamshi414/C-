//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%664712FD0360.cm preserve=no
//## end module%664712FD0360.cm

//## begin module%664712FD0360.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%664712FD0360.cp

//## Module: CXOSCFD8%664712FD0360; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCFD8.hpp

#ifndef CXOSCFD8_h
#define CXOSCFD8_h 1

//## begin module%664712FD0360.additionalIncludes preserve=no
//## end module%664712FD0360.additionalIncludes

//## begin module%664712FD0360.includes preserve=yes
//## end module%664712FD0360.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%664712FD0360.declarations preserve=no
//## end module%664712FD0360.declarations

//## begin module%664712FD0360.additionalDeclarations preserve=yes
//## end module%664712FD0360.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::MerchantSettlementTime%664713A00212.preface preserve=yes
//## end configuration::MerchantSettlementTime%664713A00212.preface

//## Class: MerchantSettlementTime%664713A00212
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%66471562034E;IF::Extract { -> F}
//## Uses: <unnamed>%664719FB035E;reusable::Query { -> F}

class DllExport MerchantSettlementTime : public ConversionItem  //## Inherits: <unnamed>%66471B54010A
{
  //## begin configuration::MerchantSettlementTime%664713A00212.initialDeclarations preserve=yes
  //## end configuration::MerchantSettlementTime%664713A00212.initialDeclarations

  public:
    //## Constructors (generated)
      MerchantSettlementTime();

    //## Destructor (generated)
      virtual ~MerchantSettlementTime();


    //## Other Operations (specified)
      //## Operation: bind%6647157F0052
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::MerchantSettlementTime%664713A00212.public preserve=yes
      //## end configuration::MerchantSettlementTime%664713A00212.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::MerchantSettlementTime%664713A00212.protected preserve=yes
      //## end configuration::MerchantSettlementTime%664713A00212.protected

  private:
    // Additional Private Declarations
      //## begin configuration::MerchantSettlementTime%664713A00212.private preserve=yes
      //## end configuration::MerchantSettlementTime%664713A00212.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::MerchantSettlementTime%664713A00212.implementation preserve=yes
      //## end configuration::MerchantSettlementTime%664713A00212.implementation

};

//## begin configuration::MerchantSettlementTime%664713A00212.postscript preserve=yes
//## end configuration::MerchantSettlementTime%664713A00212.postscript

} // namespace configuration

//## begin module%664712FD0360.epilog preserve=yes
//## end module%664712FD0360.epilog


#endif
