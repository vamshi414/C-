//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6243FE64025A.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%6243FE64025A.cm

//## begin module%6243FE64025A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%6243FE64025A.cp

//## Module: CXOSCFC9%6243FE64025A; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXODCFC9.hpp

#ifndef CXOSCFC9_h
#define CXOSCFC9_h 1

//## begin module%6243FE64025A.additionalIncludes preserve=no
//## end module%6243FE64025A.additionalIncludes

//## begin module%6243FE64025A.includes preserve=yes
//## end module%6243FE64025A.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%6243FE64025A.declarations preserve=no
//## end module%6243FE64025A.declarations

//## begin module%6243FE64025A.additionalDeclarations preserve=yes
//## end module%6243FE64025A.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::QMRVisaBusinessID%6243F75D00E8.preface preserve=yes
//## end configuration::QMRVisaBusinessID%6243F75D00E8.preface

//## Class: QMRVisaBusinessID%6243F75D00E8
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%624414BF0116;reusable::Query { -> F}

class DllExport QMRVisaBusinessID : public ConversionItem  //## Inherits: <unnamed>%624414E602FE
{
  //## begin configuration::QMRVisaBusinessID%6243F75D00E8.initialDeclarations preserve=yes
  //## end configuration::QMRVisaBusinessID%6243F75D00E8.initialDeclarations

  public:
    //## Constructors (generated)
      QMRVisaBusinessID();

    //## Destructor (generated)
      virtual ~QMRVisaBusinessID();


    //## Other Operations (specified)
      //## Operation: bind%624418A50180
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%624420420274
      virtual const reusable::string& getFirst ();

    // Additional Public Declarations
      //## begin configuration::QMRVisaBusinessID%6243F75D00E8.public preserve=yes
      //## end configuration::QMRVisaBusinessID%6243F75D00E8.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::QMRVisaBusinessID%6243F75D00E8.protected preserve=yes
      //## end configuration::QMRVisaBusinessID%6243F75D00E8.protected

  private:
    // Additional Private Declarations
      //## begin configuration::QMRVisaBusinessID%6243F75D00E8.private preserve=yes
      //## end configuration::QMRVisaBusinessID%6243F75D00E8.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BIN%6244226A0300
      //## begin configuration::QMRVisaBusinessID::BIN%6244226A0300.attr preserve=no  public: string {U} 
      string m_strBIN;
      //## end configuration::QMRVisaBusinessID::BIN%6244226A0300.attr

    // Additional Implementation Declarations
      //## begin configuration::QMRVisaBusinessID%6243F75D00E8.implementation preserve=yes
      //## end configuration::QMRVisaBusinessID%6243F75D00E8.implementation

};

//## begin configuration::QMRVisaBusinessID%6243F75D00E8.postscript preserve=yes
//## end configuration::QMRVisaBusinessID%6243F75D00E8.postscript

} // namespace configuration

//## begin module%6243FE64025A.epilog preserve=yes
//## end module%6243FE64025A.epilog


#endif
