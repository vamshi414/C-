//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FF98A89036B.cm preserve=no
//	$Date:   Dec 12 2016 12:59:38  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%3FF98A89036B.cm

//## begin module%3FF98A89036B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FF98A89036B.cp

//## Module: CXOSCF50%3FF98A89036B; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF50.hpp

#ifndef CXOSCF50_h
#define CXOSCF50_h 1

//## begin module%3FF98A89036B.additionalIncludes preserve=no
//## end module%3FF98A89036B.additionalIncludes

//## begin module%3FF98A89036B.includes preserve=yes
// $Date:   Dec 12 2016 12:59:38  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%3FF98A89036B.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%3FF98A89036B.declarations preserve=no
//## end module%3FF98A89036B.declarations

//## begin module%3FF98A89036B.additionalDeclarations preserve=yes
//## end module%3FF98A89036B.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexPOSConditionCode1%3FF98A0E02BF.preface preserve=yes
//## end configuration::ConnexPOSConditionCode1%3FF98A0E02BF.preface

//## Class: ConnexPOSConditionCode1%3FF98A0E02BF
//	<body>
//	<title>CG
//	<h1>II
//	<h2>MS
//	<!-- ConnexPOSConditionCode1 : General -->
//	<h3>IBM POS Condition Codes
//	<p>
//	The Connex on IBM POS Condition Codes table is used to
//	determine a value for the following POS columns in the
//	financial transaction.
//	<ul>
//	<li>Cardholder Authentication Capability (FIN_
//	RECORD<i>yyyymm</i>.POS_CRDHLDR_AUTH_C)
//	<li>Card Capture Capability (FIN_RECORD<i>yyyymm</i>.POS_
//	CARD_CAPT_CAP)
//	<li>Cardholder Present (FIN_RECORD<i>yyyymm</i>.POS_
//	CRDHLDR_PRESNT)
//	<li>Card Present (FIN_RECORD<i>yyyymm</i>.POS_CARD_PRES)
//	<li>Cardholder Authentication Method (FIN_
//	RECORD<i>yyyymm</i>.POS_CRDHLDR_A_METH)
//	<li>Cardholder Authentication Entity (FIN_
//	RECORD<i>yyyymm</i>.POS_CRDHLDR_AUTH)
//	<li>Card Data Output Capability (FIN_
//	RECORD<i>yyyymm</i>.POS_CRD_DAT_OT_CAP)
//	<li>Terminal Output Capability (FIN_
//	RECORD<i>yyyymm</i>.POS_TERM_OUT_CAP)
//	</ul>
//	<p>
//	Use the CR Client to add or update rows whenever the FIS
//	Connex on IBM acquiring platform introduces a new value
//	in:
//	<ul>
//	<li>PSCC1
//	<li>PSCC2
//	</ul>
//	IBM POS Condition Codes are in the FIS Connex folder in
//	the CR Client for the DataNavigator Server.
//	</body>
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FF98A4703D8;reusable::Query { -> F}

class DllExport ConnexPOSConditionCode1 : public ConversionItem  //## Inherits: <unnamed>%3FF98A330213
{
  //## begin configuration::ConnexPOSConditionCode1%3FF98A0E02BF.initialDeclarations preserve=yes
  //## end configuration::ConnexPOSConditionCode1%3FF98A0E02BF.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexPOSConditionCode1();

    //## Destructor (generated)
      virtual ~ConnexPOSConditionCode1();


    //## Other Operations (specified)
      //## Operation: bind%3FF98C2B0157
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%584716060013
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexPOSConditionCode1%3FF98A0E02BF.public preserve=yes
      //## end configuration::ConnexPOSConditionCode1%3FF98A0E02BF.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexPOSConditionCode1%3FF98A0E02BF.protected preserve=yes
      //## end configuration::ConnexPOSConditionCode1%3FF98A0E02BF.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexPOSConditionCode1%3FF98A0E02BF.private preserve=yes
      //## end configuration::ConnexPOSConditionCode1%3FF98A0E02BF.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexPOSConditionCode1%3FF98A0E02BF.implementation preserve=yes
      //## end configuration::ConnexPOSConditionCode1%3FF98A0E02BF.implementation

};

//## begin configuration::ConnexPOSConditionCode1%3FF98A0E02BF.postscript preserve=yes
//## end configuration::ConnexPOSConditionCode1%3FF98A0E02BF.postscript

} // namespace configuration

//## begin module%3FF98A89036B.epilog preserve=yes
using namespace configuration;
//## end module%3FF98A89036B.epilog


#endif
