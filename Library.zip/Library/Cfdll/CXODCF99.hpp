//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4CD03A2E0331.cm preserve=no
//	$Date:   Dec 12 2016 13:26:16  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%4CD03A2E0331.cm

//## begin module%4CD03A2E0331.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4CD03A2E0331.cp

//## Module: CXOSCF99%4CD03A2E0331; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF99.hpp

#ifndef CXOSCF99_h
#define CXOSCF99_h 1

//## begin module%4CD03A2E0331.additionalIncludes preserve=no
//## end module%4CD03A2E0331.additionalIncludes

//## begin module%4CD03A2E0331.includes preserve=yes
//## end module%4CD03A2E0331.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%4CD03A2E0331.declarations preserve=no
//## end module%4CD03A2E0331.declarations

//## begin module%4CD03A2E0331.additionalDeclarations preserve=yes
//## end module%4CD03A2E0331.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::InstitutionBankID%4CD039FB018B.preface preserve=yes
//## end configuration::InstitutionBankID%4CD039FB018B.preface

//## Class: InstitutionBankID%4CD039FB018B
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4CD03D6B024C;reusable::Query { -> F}

class DllExport InstitutionBankID : public ConversionItem  //## Inherits: <unnamed>%4CD03AE80352
{
  //## begin configuration::InstitutionBankID%4CD039FB018B.initialDeclarations preserve=yes
  //## end configuration::InstitutionBankID%4CD039FB018B.initialDeclarations

  public:
    //## Constructors (generated)
      InstitutionBankID();

    //## Destructor (generated)
      virtual ~InstitutionBankID();


    //## Other Operations (specified)
      //## Operation: bind%4CD03B1300C2
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%5847177900F4
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::InstitutionBankID%4CD039FB018B.public preserve=yes
      //## end configuration::InstitutionBankID%4CD039FB018B.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::InstitutionBankID%4CD039FB018B.protected preserve=yes
      //## end configuration::InstitutionBankID%4CD039FB018B.protected

  private:
    // Additional Private Declarations
      //## begin configuration::InstitutionBankID%4CD039FB018B.private preserve=yes
      //## end configuration::InstitutionBankID%4CD039FB018B.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::InstitutionBankID%4CD039FB018B.implementation preserve=yes
      //## end configuration::InstitutionBankID%4CD039FB018B.implementation

};

//## begin configuration::InstitutionBankID%4CD039FB018B.postscript preserve=yes
//## end configuration::InstitutionBankID%4CD039FB018B.postscript

} // namespace configuration

//## begin module%4CD03A2E0331.epilog preserve=yes
//## end module%4CD03A2E0331.epilog


#endif
