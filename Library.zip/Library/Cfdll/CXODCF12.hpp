//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%391C10CF03E0.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%391C10CF03E0.cm

//## begin module%391C10CF03E0.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%391C10CF03E0.cp

//## Module: CXOSCF12%391C10CF03E0; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF12.hpp

#ifndef CXOSCF12_h
#define CXOSCF12_h 1

//## begin module%391C10CF03E0.additionalIncludes preserve=no
//## end module%391C10CF03E0.additionalIncludes

//## begin module%391C10CF03E0.includes preserve=yes
// $Date:   Apr 08 2004 14:10:50  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%391C10CF03E0.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%391C10CF03E0.declarations preserve=no
//## end module%391C10CF03E0.declarations

//## begin module%391C10CF03E0.additionalDeclarations preserve=yes
//## end module%391C10CF03E0.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::PlusProcessCode%391C0C5E0287.preface preserve=yes
//## end configuration::PlusProcessCode%391C0C5E0287.preface

//## Class: PlusProcessCode%391C0C5E0287
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%391C1603011F;IF::Extract { -> F}
//## Uses: <unnamed>%391C160403A1;reusable::Query { -> F}

class DllExport PlusProcessCode : public ConversionItem  //## Inherits: <unnamed>%391C160100FE
{
  //## begin configuration::PlusProcessCode%391C0C5E0287.initialDeclarations preserve=yes
  //## end configuration::PlusProcessCode%391C0C5E0287.initialDeclarations

  public:
    //## Constructors (generated)
      PlusProcessCode();

    //## Destructor (generated)
      virtual ~PlusProcessCode();


    //## Other Operations (specified)
      //## Operation: bind%391C1BB801E8
      virtual void bind (Query& hQuery);

      //## Operation: getSecond%391C1BB801F2
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::PlusProcessCode%391C0C5E0287.public preserve=yes
      //## end configuration::PlusProcessCode%391C0C5E0287.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::PlusProcessCode%391C0C5E0287.protected preserve=yes
      //## end configuration::PlusProcessCode%391C0C5E0287.protected

  private:
    // Additional Private Declarations
      //## begin configuration::PlusProcessCode%391C0C5E0287.private preserve=yes
      //## end configuration::PlusProcessCode%391C0C5E0287.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: PROCESS_CODE%391C1BA501F4
      //## begin configuration::PlusProcessCode::PROCESS_CODE%391C1BA501F4.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::PlusProcessCode::PROCESS_CODE%391C1BA501F4.attr

      //## Attribute: MSG_CLASS%391C1BA501F5
      //## begin configuration::PlusProcessCode::MSG_CLASS%391C1BA501F5.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::PlusProcessCode::MSG_CLASS%391C1BA501F5.attr

      //## Attribute: PRE_AUTH%391C1BA50208
      //## begin configuration::PlusProcessCode::PRE_AUTH%391C1BA50208.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::PlusProcessCode::PRE_AUTH%391C1BA50208.attr

      //## Attribute: MEDIA_TYPE%39205293028F
      //## begin configuration::PlusProcessCode::MEDIA_TYPE%39205293028F.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::PlusProcessCode::MEDIA_TYPE%39205293028F.attr

    // Additional Implementation Declarations
      //## begin configuration::PlusProcessCode%391C0C5E0287.implementation preserve=yes
      //## end configuration::PlusProcessCode%391C0C5E0287.implementation

};

//## begin configuration::PlusProcessCode%391C0C5E0287.postscript preserve=yes
//## end configuration::PlusProcessCode%391C0C5E0287.postscript

} // namespace configuration

//## begin module%391C10CF03E0.epilog preserve=yes
using namespace configuration;
//## end module%391C10CF03E0.epilog


#endif
