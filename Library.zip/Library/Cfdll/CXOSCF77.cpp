//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4263E2E202EE.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%4263E2E202EE.cm

//## begin module%4263E2E202EE.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%4263E2E202EE.cp

//## Module: CXOSCF77%4263E2E202EE; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF77.cpp

//## begin module%4263E2E202EE.additionalIncludes preserve=no
//## end module%4263E2E202EE.additionalIncludes

//## begin module%4263E2E202EE.includes preserve=yes
//## end module%4263E2E202EE.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF77_h
#include "CXODCF77.hpp"
#endif


//## begin module%4263E2E202EE.declarations preserve=no
//## end module%4263E2E202EE.declarations

//## begin module%4263E2E202EE.additionalDeclarations preserve=yes
//## end module%4263E2E202EE.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::OasisPCode 

OasisPCode::OasisPCode()
  //## begin OasisPCode::OasisPCode%4263E29A0399_const.hasinit preserve=no
  //## end OasisPCode::OasisPCode%4263E29A0399_const.hasinit
  //## begin OasisPCode::OasisPCode%4263E29A0399_const.initialization preserve=yes
  : ConversionItem("## CR80 XLATE IST PROC CODE")
  //## end OasisPCode::OasisPCode%4263E29A0399_const.initialization
{
  //## begin configuration::OasisPCode::OasisPCode%4263E29A0399_const.body preserve=yes
   memcpy(m_sID,"CF77",4);
  //## end configuration::OasisPCode::OasisPCode%4263E29A0399_const.body
}


OasisPCode::~OasisPCode()
{
  //## begin configuration::OasisPCode::~OasisPCode%4263E29A0399_dest.body preserve=yes
  //## end configuration::OasisPCode::~OasisPCode%4263E29A0399_dest.body
}



//## Other Operations (implementation)
void OasisPCode::bind (reusable::Query& hQuery)
{
  //## begin configuration::OasisPCode::bind%4263E33D008C.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_IST_PROC_CODE");
   hQuery.bind("X_IST_PROC_CODE","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("X_IST_PROC_CODE","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("X_IST_PROC_CODE","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("X_IST_PROC_CODE","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("X_IST_PROC_CODE","IST_PROCESS_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_IST_PROC_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_IST_PROC_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IST_PROC_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_IST_PROC_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_IST_PROC_CODE.IST_PROCESS_CODE ASC,X_IST_PROC_CODE.CUST_ID DESC");
  //## end configuration::OasisPCode::bind%4263E33D008C.body
}

const string& OasisPCode::getSecond ()
{
  //## begin configuration::OasisPCode::getSecond%42AA018803C8.body preserve=yes
   while (m_strPROCESS_CODE.length() < 6)
      m_strPROCESS_CODE += ' ';
   while (m_strMSG_CLASS.length() < 1)
      m_strMSG_CLASS += ' ';
   while (m_strPRE_AUTH.length() < 1)
      m_strPRE_AUTH += ' ';
   m_strSecond = m_strPROCESS_CODE + m_strMSG_CLASS + m_strPRE_AUTH + m_strMEDIA_TYPE;
   return m_strSecond;
  //## end configuration::OasisPCode::getSecond%42AA018803C8.body
}

// Additional Declarations
  //## begin configuration::OasisPCode%4263E29A0399.declarations preserve=yes
  //## end configuration::OasisPCode%4263E29A0399.declarations

} // namespace configuration

//## begin module%4263E2E202EE.epilog preserve=yes
//## end module%4263E2E202EE.epilog
