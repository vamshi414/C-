//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%39985C8801DF.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%39985C8801DF.cm

//## begin module%39985C8801DF.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%39985C8801DF.cp

//## Module: CXOSCF37%39985C8801DF; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF37.cpp

//## begin module%39985C8801DF.additionalIncludes preserve=no
//## end module%39985C8801DF.additionalIncludes

//## begin module%39985C8801DF.includes preserve=yes
// $Date:   Apr 17 2014 21:00:24  $ $Author:   e1009652  $ $Revision:   1.5  $
//## end module%39985C8801DF.includes

#ifndef CXOSCF37_h
#include "CXODCF37.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%39985C8801DF.declarations preserve=no
//## end module%39985C8801DF.declarations

//## begin module%39985C8801DF.additionalDeclarations preserve=yes
//## end module%39985C8801DF.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::Base24ReversalCode

Base24ReversalCode::Base24ReversalCode()
  //## begin Base24ReversalCode::Base24ReversalCode%39985CF8003B_const.hasinit preserve=no
  //## end Base24ReversalCode::Base24ReversalCode%39985CF8003B_const.hasinit
  //## begin Base24ReversalCode::Base24ReversalCode%39985CF8003B_const.initialization preserve=yes
  //## end Base24ReversalCode::Base24ReversalCode%39985CF8003B_const.initialization
{
  //## begin configuration::Base24ReversalCode::Base24ReversalCode%39985CF8003B_const.body preserve=yes
   memcpy(m_sID,"CF37",4);
  //## end configuration::Base24ReversalCode::Base24ReversalCode%39985CF8003B_const.body
}


Base24ReversalCode::~Base24ReversalCode()
{
  //## begin configuration::Base24ReversalCode::~Base24ReversalCode%39985CF8003B_dest.body preserve=yes
  //## end configuration::Base24ReversalCode::~Base24ReversalCode%39985CF8003B_dest.body
}



//## Other Operations (implementation)
void Base24ReversalCode::bind (Query& hQuery)
{
  //## begin configuration::Base24ReversalCode::bind%39993C120196.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_B24_REV_CODE");
   hQuery.bind("X_B24_REV_CODE","B24_REVERSAL_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_B24_REV_CODE","MSG_REASON_CODE",Column::STRING,&m_strSecond);
   hQuery.bind("X_B24_REV_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_B24_REV_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_B24_REV_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_B24_REV_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_B24_REV_CODE.B24_REVERSAL_CODE ASC,X_B24_REV_CODE.CUST_ID DESC");
  //## end configuration::Base24ReversalCode::bind%39993C120196.body
}

// Additional Declarations
  //## begin configuration::Base24ReversalCode%39985CF8003B.declarations preserve=yes
  //## end configuration::Base24ReversalCode%39985CF8003B.declarations

} // namespace configuration

//## begin module%39985C8801DF.epilog preserve=yes
//## end module%39985C8801DF.epilog
