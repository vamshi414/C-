//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%40B9CC5D0128.cm preserve=no
//	$Date:   Feb 25 2019 15:37:34  $ $Author:   e1009839  $
//	$Revision:   1.4  $
//## end module%40B9CC5D0128.cm

//## begin module%40B9CC5D0128.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%40B9CC5D0128.cp

//## Module: CXOSCF66%40B9CC5D0128; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF66.cpp

//## begin module%40B9CC5D0128.additionalIncludes preserve=no
//## end module%40B9CC5D0128.additionalIncludes

//## begin module%40B9CC5D0128.includes preserve=yes
//## end module%40B9CC5D0128.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF66_h
#include "CXODCF66.hpp"
#endif


//## begin module%40B9CC5D0128.declarations preserve=no
//## end module%40B9CC5D0128.declarations

//## begin module%40B9CC5D0128.additionalDeclarations preserve=yes
//## end module%40B9CC5D0128.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexATMStatus

ConnexATMStatus::ConnexATMStatus()
  //## begin ConnexATMStatus::ConnexATMStatus%40B9CBD6008C_const.hasinit preserve=no
  //## end ConnexATMStatus::ConnexATMStatus%40B9CBD6008C_const.hasinit
  //## begin ConnexATMStatus::ConnexATMStatus%40B9CBD6008C_const.initialization preserve=yes
   : ConversionItem("## CR75 XLATE ATM STATUS")
  //## end ConnexATMStatus::ConnexATMStatus%40B9CBD6008C_const.initialization
{
  //## begin configuration::ConnexATMStatus::ConnexATMStatus%40B9CBD6008C_const.body preserve=yes
   memcpy(m_sID,"CF66",4);
  //## end configuration::ConnexATMStatus::ConnexATMStatus%40B9CBD6008C_const.body
}


ConnexATMStatus::~ConnexATMStatus()
{
  //## begin configuration::ConnexATMStatus::~ConnexATMStatus%40B9CBD6008C_dest.body preserve=yes
  //## end configuration::ConnexATMStatus::~ConnexATMStatus%40B9CBD6008C_dest.body
}



//## Other Operations (implementation)
void ConnexATMStatus::bind (Query& hQuery)
{
  //## begin configuration::ConnexATMStatus::bind%40B9CBFF034B.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_NDC_ATM_STATUS");
   hQuery.bind("X_NDC_ATM_STATUS","SOLICITED_STATUS",Column::STRING,&m_strSOLICITED_STATUS);
   hQuery.bind("X_NDC_ATM_STATUS","STATUS_DESCRIPTOR",Column::STRING,&m_strSTATUS_DESCRIPTOR);
   hQuery.bind("X_NDC_ATM_STATUS","DEVICE_IDENTIFIER",Column::STRING,&m_strDEVICE_IDENTIFIER);
   hQuery.bind("X_NDC_ATM_STATUS","T_CODE",Column::STRING,&m_strT_CODE);
   hQuery.bind("X_NDC_ATM_STATUS","STATUS_QUALIFIER",Column::STRING,&m_strSTATUS_QUALIFIER);
   hQuery.bind("X_NDC_ATM_STATUS","M_STATUS",Column::STRING,&m_strM_STATUS);
   hQuery.bind("X_NDC_ATM_STATUS","ALERT_NO",Column::STRING,&m_strALERT_NO);
   hQuery.bind("X_NDC_ATM_STATUS","MSG_NO",Column::STRING,&m_strMSG_NO);
   hQuery.bind("X_NDC_ATM_STATUS","SEVERITY",Column::STRING,&m_strSEVERITY);
   hQuery.bind("X_NDC_ATM_STATUS","DEVICE_STATUS",Column::STRING,&m_strDEVICE_STATUS);
   hQuery.bind("X_NDC_ATM_STATUS","STATUS_TEXT",Column::STRING,&m_strSTATUS_TEXT);
   hQuery.setBasicPredicate("X_NDC_ATM_STATUS","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_NDC_ATM_STATUS","CC_STATE","=","A");
   hQuery.setOrderByClause("SOLICITED_STATUS,STATUS_DESCRIPTOR,DEVICE_IDENTIFIER,T_CODE,STATUS_QUALIFIER,M_STATUS");
  //## end configuration::ConnexATMStatus::bind%40B9CBFF034B.body
}

const string& ConnexATMStatus::getFirst ()
{
  //## begin configuration::ConnexATMStatus::getFirst%40B9CC010186.body preserve=yes
   m_strSOLICITED_STATUS.resize(2,' ');
   m_strSTATUS_DESCRIPTOR.resize(1,' ');
   m_strDEVICE_IDENTIFIER.resize(1,' ');
   m_strT_CODE.resize(1,' ');
   m_strSTATUS_QUALIFIER.resize(2,' ');
   m_strM_STATUS.resize(2,' ');
   m_strFirst = m_strSOLICITED_STATUS;
   m_strFirst += m_strSTATUS_DESCRIPTOR;
   m_strFirst += m_strDEVICE_IDENTIFIER;
   m_strFirst += m_strT_CODE;
   m_strFirst += m_strSTATUS_QUALIFIER;
   m_strFirst += m_strM_STATUS;
   return m_strFirst;
  //## end configuration::ConnexATMStatus::getFirst%40B9CC010186.body
}

const string& ConnexATMStatus::getSecond ()
{
  //## begin configuration::ConnexATMStatus::getSecond%40B9CC030157.body preserve=yes
   m_strALERT_NO.resize(5,' ');
   m_strMSG_NO.resize(5,' ');
   m_strSEVERITY.resize(4,' ');
   m_strDEVICE_STATUS.resize(5,' ');
   m_strSTATUS_TEXT.resize(254,' ');
   m_strSecond = m_strALERT_NO;
   m_strSecond += m_strMSG_NO;
   m_strSecond += m_strSEVERITY;
   m_strSecond += m_strDEVICE_STATUS;
   m_strSecond += m_strSTATUS_TEXT;
   return m_strSecond;
  //## end configuration::ConnexATMStatus::getSecond%40B9CC030157.body
}

void ConnexATMStatus::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexATMStatus::setPredicate%58471593031E.body preserve=yes
   hQuery.setBasicPredicate("X_NDC_ATM_STATUS","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_NDC_ATM_STATUS","CC_STATE","=","A");
  //## end configuration::ConnexATMStatus::setPredicate%58471593031E.body
}

// Additional Declarations
  //## begin configuration::ConnexATMStatus%40B9CBD6008C.declarations preserve=yes
  //## end configuration::ConnexATMStatus%40B9CBD6008C.declarations

} // namespace configuration

//## begin module%40B9CC5D0128.epilog preserve=yes
//## end module%40B9CC5D0128.epilog
