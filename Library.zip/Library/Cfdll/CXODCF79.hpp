//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4263E49F037A.cm preserve=no
//	$Date:   Dec 12 2016 13:15:10  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%4263E49F037A.cm

//## begin module%4263E49F037A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4263E49F037A.cp

//## Module: CXOSCF79%4263E49F037A; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF79.hpp

#ifndef CXOSCF79_h
#define CXOSCF79_h 1

//## begin module%4263E49F037A.additionalIncludes preserve=no
//## end module%4263E49F037A.additionalIncludes

//## begin module%4263E49F037A.includes preserve=yes
//## end module%4263E49F037A.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%4263E49F037A.declarations preserve=no
//## end module%4263E49F037A.declarations

//## begin module%4263E49F037A.additionalDeclarations preserve=yes
//## end module%4263E49F037A.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::OasisTermType%4263E45C0203.preface preserve=yes
//## end configuration::OasisTermType%4263E45C0203.preface

//## Class: OasisTermType%4263E45C0203
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4263E46F00DA;reusable::Query { -> F}
//## Uses: <unnamed>%4263E47101A5;IF::Extract { -> F}

class DllExport OasisTermType : public ConversionItem  //## Inherits: <unnamed>%4263E46C03C8
{
  //## begin configuration::OasisTermType%4263E45C0203.initialDeclarations preserve=yes
  //## end configuration::OasisTermType%4263E45C0203.initialDeclarations

  public:
    //## Constructors (generated)
      OasisTermType();

    //## Destructor (generated)
      virtual ~OasisTermType();


    //## Other Operations (specified)
      //## Operation: bind%4263E4EA02BF
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>OI
      //	<h2>MS
      //	<!-- OasisTermType::bind Preconditions -->
      //	<h3>IST Terminal Type
      //	<p>
      //	The IST Terminal Type table is used to determine a value
      //	for the terminal class (FIN_RECORD<i>yyyymm</i>.TERM_
      //	CLASS) in the financial transaction.
      //	<p>
      //	Use the CR Client to add or update rows whenever the e
      //	Funds IST acquiring platform introduces a new value in:
      //	<ul>
      //	<li>term_type
      //	</ul>
      //	IST Terminal Type is in the Parameter Tables folder in
      //	the CR Client for the DataNavigator Server.
      //	</body>
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%5847180D0287
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::OasisTermType%4263E45C0203.public preserve=yes
      //## end configuration::OasisTermType%4263E45C0203.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::OasisTermType%4263E45C0203.protected preserve=yes
      //## end configuration::OasisTermType%4263E45C0203.protected

  private:
    // Additional Private Declarations
      //## begin configuration::OasisTermType%4263E45C0203.private preserve=yes
      //## end configuration::OasisTermType%4263E45C0203.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::OasisTermType%4263E45C0203.implementation preserve=yes
      //## end configuration::OasisTermType%4263E45C0203.implementation

};

//## begin configuration::OasisTermType%4263E45C0203.postscript preserve=yes
//## end configuration::OasisTermType%4263E45C0203.postscript

} // namespace configuration

//## begin module%4263E49F037A.epilog preserve=yes
//## end module%4263E49F037A.epilog


#endif
