//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%61A7973F00BC.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%61A7973F00BC.cm

//## begin module%61A7973F00BC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%61A7973F00BC.cp

//## Module: CXOSCFC2%61A7973F00BC; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Cfdll\CXODCFC2.hpp

#ifndef CXOSCFC2_h
#define CXOSCFC2_h 1

//## begin module%61A7973F00BC.additionalIncludes preserve=no
//## end module%61A7973F00BC.additionalIncludes

//## begin module%61A7973F00BC.includes preserve=yes
//## end module%61A7973F00BC.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%61A7973F00BC.declarations preserve=no
//## end module%61A7973F00BC.declarations

//## begin module%61A7973F00BC.additionalDeclarations preserve=yes
//## end module%61A7973F00BC.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::NetworkStatusReverse%61A79831031F.preface preserve=yes
//## end configuration::NetworkStatusReverse%61A79831031F.preface

//## Class: NetworkStatusReverse%61A79831031F
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%61A799AC00C6;reusable::Query { -> F}
//## Uses: <unnamed>%61A799B002B8;IF::Extract { -> F}

class DllExport NetworkStatusReverse : public ConversionItem  //## Inherits: <unnamed>%61A7998A02B1
{
  //## begin configuration::NetworkStatusReverse%61A79831031F.initialDeclarations preserve=yes
  //## end configuration::NetworkStatusReverse%61A79831031F.initialDeclarations

  public:
    //## Constructors (generated)
      NetworkStatusReverse();

    //## Destructor (generated)
      virtual ~NetworkStatusReverse();


    //## Other Operations (specified)
      //## Operation: bind%61A7A5040258
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%61A7A69E02EA
      virtual const reusable::string& getFirst ();

    // Additional Public Declarations
      //## begin configuration::NetworkStatusReverse%61A79831031F.public preserve=yes
      //## end configuration::NetworkStatusReverse%61A79831031F.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::NetworkStatusReverse%61A79831031F.protected preserve=yes
      //## end configuration::NetworkStatusReverse%61A79831031F.protected

  private:
    // Additional Private Declarations
      //## begin configuration::NetworkStatusReverse%61A79831031F.private preserve=yes
      //## end configuration::NetworkStatusReverse%61A79831031F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: REQ_TYPE%61A7A71C0186
      //## begin configuration::NetworkStatusReverse::REQ_TYPE%61A7A71C0186.attr preserve=no  private: string {U} 
      string m_strREQ_TYPE;
      //## end configuration::NetworkStatusReverse::REQ_TYPE%61A7A71C0186.attr

      //## Attribute: STATUS%61A7A736023F
      //## begin configuration::NetworkStatusReverse::STATUS%61A7A736023F.attr preserve=no  private: string {U} 
      string m_strSTATUS;
      //## end configuration::NetworkStatusReverse::STATUS%61A7A736023F.attr

    // Additional Implementation Declarations
      //## begin configuration::NetworkStatusReverse%61A79831031F.implementation preserve=yes
      //## end configuration::NetworkStatusReverse%61A79831031F.implementation

};

//## begin configuration::NetworkStatusReverse%61A79831031F.postscript preserve=yes
//## end configuration::NetworkStatusReverse%61A79831031F.postscript

} // namespace configuration

//## begin module%61A7973F00BC.epilog preserve=yes
//## end module%61A7973F00BC.epilog


#endif
