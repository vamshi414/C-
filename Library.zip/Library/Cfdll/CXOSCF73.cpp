//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%425EAEBC0203.cm preserve=no
//	$Date:   Dec 12 2016 14:55:06  $ $Author:   e1009652  $
//	$Revision:   1.5  $
//## end module%425EAEBC0203.cm

//## begin module%425EAEBC0203.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%425EAEBC0203.cp

//## Module: CXOSCF73%425EAEBC0203; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF73.cpp

//## begin module%425EAEBC0203.additionalIncludes preserve=no
//## end module%425EAEBC0203.additionalIncludes

//## begin module%425EAEBC0203.includes preserve=yes
//## end module%425EAEBC0203.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF73_h
#include "CXODCF73.hpp"
#endif


//## begin module%425EAEBC0203.declarations preserve=no
//## end module%425EAEBC0203.declarations

//## begin module%425EAEBC0203.additionalDeclarations preserve=yes
//## end module%425EAEBC0203.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::CountryCode2to3 

CountryCode2to3::CountryCode2to3()
  //## begin CountryCode2to3::CountryCode2to3%425EB2F002BF_const.hasinit preserve=no
  //## end CountryCode2to3::CountryCode2to3%425EB2F002BF_const.hasinit
  //## begin CountryCode2to3::CountryCode2to3%425EB2F002BF_const.initialization preserve=yes
   : ConversionItem("## CR80 XLATE COUNTRY CODE")
  //## end CountryCode2to3::CountryCode2to3%425EB2F002BF_const.initialization
{
  //## begin configuration::CountryCode2to3::CountryCode2to3%425EB2F002BF_const.body preserve=yes
    memcpy(m_sID,"CF73",4);
  //## end configuration::CountryCode2to3::CountryCode2to3%425EB2F002BF_const.body
}


CountryCode2to3::~CountryCode2to3()
{
  //## begin configuration::CountryCode2to3::~CountryCode2to3%425EB2F002BF_dest.body preserve=yes
  //## end configuration::CountryCode2to3::~CountryCode2to3%425EB2F002BF_dest.body
}



//## Other Operations (implementation)
void CountryCode2to3::bind (Query& hQuery)
{
  //## begin configuration::CountryCode2to3::bind%425EB3280280.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY", "COUNTRY_CODE");
   hQuery.bind("COUNTRY_CODE","COUNTRY_CODE_ISO2",Column::STRING,&m_strFirst);
   hQuery.bind("COUNTRY_CODE","COUNTRY_CODE_ISO3",Column::STRING,&m_strSecond);
   hQuery.bind("COUNTRY_CODE","COUNTRY_CODE",Column::STRING,&m_strThird);
   hQuery.setBasicPredicate("COUNTRY_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("COUNTRY_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("COUNTRY_CODE", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("COUNTRY_CODE.COUNTRY_CODE_ISO2 ASC");
  //## end configuration::CountryCode2to3::bind%425EB3280280.body
}

const string& CountryCode2to3::getSecond ()
{
  //## begin configuration::CountryCode2to3::getSecond%43E109BF01AA.body preserve=yes
  return m_strSecond.append(m_strThird);
  //## end configuration::CountryCode2to3::getSecond%43E109BF01AA.body
}

// Additional Declarations
  //## begin configuration::CountryCode2to3%425EB2F002BF.declarations preserve=yes
  //## end configuration::CountryCode2to3%425EB2F002BF.declarations

} // namespace configuration

//## begin module%425EAEBC0203.epilog preserve=yes
//## end module%425EAEBC0203.epilog
