//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5F0C73DB00BC.cm preserve=no
//	$Date:   Aug 17 2020 14:49:14  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5F0C73DB00BC.cm

//## begin module%5F0C73DB00BC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5F0C73DB00BC.cp

//## Module: CXOSCFB6%5F0C73DB00BC; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV03.1A.R001\Build\Dn\Server\Library\Cfdll\CXODCFB6.hpp

#ifndef CXOSCFB6_h
#define CXOSCFB6_h 1

//## begin module%5F0C73DB00BC.additionalIncludes preserve=no
//## end module%5F0C73DB00BC.additionalIncludes

//## begin module%5F0C73DB00BC.includes preserve=yes
//## end module%5F0C73DB00BC.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%5F0C73DB00BC.declarations preserve=no
//## end module%5F0C73DB00BC.declarations

//## begin module%5F0C73DB00BC.additionalDeclarations preserve=yes
//## end module%5F0C73DB00BC.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::MsgReason%5F0C74D402B3.preface preserve=yes
//## end configuration::MsgReason%5F0C74D402B3.preface

//## Class: MsgReason%5F0C74D402B3
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5F0C75EE0352;reusable::Query { -> F}
//## Uses: <unnamed>%5F0C75F3027E;IF::Extract { -> F}

class DllExport MsgReason : public ConversionItem  //## Inherits: <unnamed>%5F0C75EA0312
{
  //## begin configuration::MsgReason%5F0C74D402B3.initialDeclarations preserve=yes
  //## end configuration::MsgReason%5F0C74D402B3.initialDeclarations

  public:
    //## Constructors (generated)
      MsgReason();

    //## Destructor (generated)
      virtual ~MsgReason();


    //## Other Operations (specified)
      //## Operation: bind%5F0C761100C6
      virtual void bind (Query& hQuery);

      //## Operation: getSecond%5F0C76E902A2
      virtual const string& getSecond ()
      {
        //## begin configuration::MsgReason::getSecond%5F0C76E902A2.body preserve=yes
         m_strSecond.resize(50,' ');
         return m_strSecond;
        //## end configuration::MsgReason::getSecond%5F0C76E902A2.body
      }

    // Additional Public Declarations
      //## begin configuration::MsgReason%5F0C74D402B3.public preserve=yes
      //## end configuration::MsgReason%5F0C74D402B3.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::MsgReason%5F0C74D402B3.protected preserve=yes
      //## end configuration::MsgReason%5F0C74D402B3.protected

  private:
    // Additional Private Declarations
      //## begin configuration::MsgReason%5F0C74D402B3.private preserve=yes
      //## end configuration::MsgReason%5F0C74D402B3.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::MsgReason%5F0C74D402B3.implementation preserve=yes
      //## end configuration::MsgReason%5F0C74D402B3.implementation

};

//## begin configuration::MsgReason%5F0C74D402B3.postscript preserve=yes
//## end configuration::MsgReason%5F0C74D402B3.postscript

} // namespace configuration

//## begin module%5F0C73DB00BC.epilog preserve=yes
//## end module%5F0C73DB00BC.epilog


#endif
