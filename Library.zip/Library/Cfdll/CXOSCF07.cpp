//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3917322901B6.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%3917322901B6.cm

//## begin module%3917322901B6.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%3917322901B6.cp

//## Module: CXOSCF07%3917322901B6; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF07.cpp

//## begin module%3917322901B6.additionalIncludes preserve=no
//## end module%3917322901B6.additionalIncludes

//## begin module%3917322901B6.includes preserve=yes
// $Date:   Apr 17 2014 20:59:16  $ $Author:   e1009652  $ $Revision:   1.7  $
//## end module%3917322901B6.includes

#ifndef CXOSCF07_h
#include "CXODCF07.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif


//## begin module%3917322901B6.declarations preserve=no
//## end module%3917322901B6.declarations

//## begin module%3917322901B6.additionalDeclarations preserve=yes
//## end module%3917322901B6.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::AdvantageCardType

AdvantageCardType::AdvantageCardType()
  //## begin AdvantageCardType::AdvantageCardType%3912F0DF0084_const.hasinit preserve=no
  //## end AdvantageCardType::AdvantageCardType%3912F0DF0084_const.hasinit
  //## begin AdvantageCardType::AdvantageCardType%3912F0DF0084_const.initialization preserve=yes
   : ConversionItem("## CR10 XLATE CARD TYPE")
  //## end AdvantageCardType::AdvantageCardType%3912F0DF0084_const.initialization
{
  //## begin configuration::AdvantageCardType::AdvantageCardType%3912F0DF0084_const.body preserve=yes
   memcpy(m_sID,"CF07",4);
  //## end configuration::AdvantageCardType::AdvantageCardType%3912F0DF0084_const.body
}


AdvantageCardType::~AdvantageCardType()
{
  //## begin configuration::AdvantageCardType::~AdvantageCardType%3912F0DF0084_dest.body preserve=yes
  //## end configuration::AdvantageCardType::~AdvantageCardType%3912F0DF0084_dest.body
}



//## Other Operations (implementation)
void AdvantageCardType::bind (Query& hQuery)
{
  //## begin configuration::AdvantageCardType::bind%3912F76902F8.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","X_ADV_CARD_TYPE");
   hQuery.bind("X_ADV_CARD_TYPE","ADVG_CARD_TYPE",Column::STRING,&m_strFirst);
   hQuery.bind("X_ADV_CARD_TYPE","CARD_TYPE",Column::STRING,&m_strSecond);
   hQuery.bind("X_ADV_CARD_TYPE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("X_ADV_CARD_TYPE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_ADV_CARD_TYPE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("X_ADV_CARD_TYPE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_ADV_CARD_TYPE.ADVG_CARD_TYPE ASC,X_ADV_CARD_TYPE.CUST_ID DESC");
  //## end configuration::AdvantageCardType::bind%3912F76902F8.body
}

// Additional Declarations
  //## begin configuration::AdvantageCardType%3912F0DF0084.declarations preserve=yes
  //## end configuration::AdvantageCardType%3912F0DF0084.declarations

} // namespace configuration

//## begin module%3917322901B6.epilog preserve=yes
//## end module%3917322901B6.epilog
