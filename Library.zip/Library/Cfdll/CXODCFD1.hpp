//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%62BDD91003CE.cm preserve=no
//## end module%62BDD91003CE.cm

//## begin module%62BDD91003CE.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%62BDD91003CE.cp

//## Module: CXOSCFD1%62BDD91003CE; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCFD1.hpp

#ifndef CXOSCFD1_h
#define CXOSCFD1_h 1

//## begin module%62BDD91003CE.additionalIncludes preserve=no
//## end module%62BDD91003CE.additionalIncludes

//## begin module%62BDD91003CE.includes preserve=yes
//## end module%62BDD91003CE.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%62BDD91003CE.declarations preserve=no
//## end module%62BDD91003CE.declarations

//## begin module%62BDD91003CE.additionalDeclarations preserve=yes
//## end module%62BDD91003CE.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ActionTypeRev%62BDDAF101EA.preface preserve=yes
//## end configuration::ActionTypeRev%62BDDAF101EA.preface

//## Class: ActionTypeRev%62BDDAF101EA
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%62BDDF9D0337;IF::Extract { -> F}
//## Uses: <unnamed>%62BDDFD00165;reusable::Query { -> F}

class DllExport ActionTypeRev : public ConversionItem  //## Inherits: <unnamed>%62BDDB5D01FF
{
  //## begin configuration::ActionTypeRev%62BDDAF101EA.initialDeclarations preserve=yes
  //## end configuration::ActionTypeRev%62BDDAF101EA.initialDeclarations

  public:
    //## Constructors (generated)
      ActionTypeRev();

    //## Destructor (generated)
      virtual ~ActionTypeRev();


    //## Other Operations (specified)
      //## Operation: bind%62BDDBC00084
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%62BDDC6E016D
      virtual const reusable::string& getFirst ();

    // Additional Public Declarations
      //## begin configuration::ActionTypeRev%62BDDAF101EA.public preserve=yes
      //## end configuration::ActionTypeRev%62BDDAF101EA.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ActionTypeRev%62BDDAF101EA.protected preserve=yes
      //## end configuration::ActionTypeRev%62BDDAF101EA.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ActionTypeRev%62BDDAF101EA.private preserve=yes
      //## end configuration::ActionTypeRev%62BDDAF101EA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ACTION_TYPE%62BDDDC201D6
      //## begin configuration::ActionTypeRev::ACTION_TYPE%62BDDDC201D6.attr preserve=no  public: string {U} 
      string m_strACTION_TYPE;
      //## end configuration::ActionTypeRev::ACTION_TYPE%62BDDDC201D6.attr

      //## Attribute: REQUEST_TYPE%62BDDDE9026E
      //## begin configuration::ActionTypeRev::REQUEST_TYPE%62BDDDE9026E.attr preserve=no  public: string {U} 
      string m_strREQUEST_TYPE;
      //## end configuration::ActionTypeRev::REQUEST_TYPE%62BDDDE9026E.attr

      //## Attribute: ROLE%62BDDDFA02E5
      //## begin configuration::ActionTypeRev::ROLE%62BDDDFA02E5.attr preserve=no  public: string {U} 
      string m_strROLE;
      //## end configuration::ActionTypeRev::ROLE%62BDDDFA02E5.attr

      //## Attribute: STATUS%62BDDF5F0382
      //## begin configuration::ActionTypeRev::STATUS%62BDDF5F0382.attr preserve=no  public: string {U} 
      string m_strSTATUS;
      //## end configuration::ActionTypeRev::STATUS%62BDDF5F0382.attr

    // Additional Implementation Declarations
      //## begin configuration::ActionTypeRev%62BDDAF101EA.implementation preserve=yes
      //## end configuration::ActionTypeRev%62BDDAF101EA.implementation

};

//## begin configuration::ActionTypeRev%62BDDAF101EA.postscript preserve=yes
//## end configuration::ActionTypeRev%62BDDAF101EA.postscript

} // namespace configuration

//## begin module%62BDD91003CE.epilog preserve=yes
//## end module%62BDD91003CE.epilog


#endif
