//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%590746880155.cm preserve=no
//	$Date:   Jun 08 2017 12:27:20  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%590746880155.cm

//## begin module%590746880155.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%590746880155.cp

//## Module: CXOSCFA6%590746880155; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.8A.R004\Windows\Build\Dn\Server\Library\Cfdll\CXODCFA6.hpp

#ifndef CXOSCFA6_h
#define CXOSCFA6_h 1

//## begin module%590746880155.additionalIncludes preserve=no
//## end module%590746880155.additionalIncludes

//## begin module%590746880155.includes preserve=yes
//## end module%590746880155.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%590746880155.declarations preserve=no
//## end module%590746880155.declarations

//## begin module%590746880155.additionalDeclarations preserve=yes
//## end module%590746880155.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::BankIDInstitution%5907451A0041.preface preserve=yes
//## end configuration::BankIDInstitution%5907451A0041.preface

//## Class: BankIDInstitution%5907451A0041
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5907454E011F;reusable::Query { -> F}
//## Uses: <unnamed>%5907492903DB;IF::Extract { -> F}

class DllExport BankIDInstitution : public ConversionItem  //## Inherits: <unnamed>%5907454300CD
{
  //## begin configuration::BankIDInstitution%5907451A0041.initialDeclarations preserve=yes
  //## end configuration::BankIDInstitution%5907451A0041.initialDeclarations

  public:
    //## Constructors (generated)
      BankIDInstitution();

    //## Destructor (generated)
      virtual ~BankIDInstitution();


    //## Other Operations (specified)
      //## Operation: bind%5907455F03C3
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%5907455F03C7
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::BankIDInstitution%5907451A0041.public preserve=yes
      //## end configuration::BankIDInstitution%5907451A0041.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::BankIDInstitution%5907451A0041.protected preserve=yes
      //## end configuration::BankIDInstitution%5907451A0041.protected

  private:
    // Additional Private Declarations
      //## begin configuration::BankIDInstitution%5907451A0041.private preserve=yes
      //## end configuration::BankIDInstitution%5907451A0041.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::BankIDInstitution%5907451A0041.implementation preserve=yes
      //## end configuration::BankIDInstitution%5907451A0041.implementation

};

//## begin configuration::BankIDInstitution%5907451A0041.postscript preserve=yes
//## end configuration::BankIDInstitution%5907451A0041.postscript

} // namespace configuration

//## begin module%590746880155.epilog preserve=yes
//## end module%590746880155.epilog


#endif
