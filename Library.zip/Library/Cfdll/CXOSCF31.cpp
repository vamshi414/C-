//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4F6C1C0A0159.cm preserve=no
//	$Date:   Dec 16 2016 15:10:46  $ $Author:   e1009652  $
//	$Revision:   1.14  $
//## end module%4F6C1C0A0159.cm

//## begin module%4F6C1C0A0159.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4F6C1C0A0159.cp

//## Module: CXOSCF31%4F6C1C0A0159; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF31.cpp

//## begin module%4F6C1C0A0159.additionalIncludes preserve=no
//## end module%4F6C1C0A0159.additionalIncludes

//## begin module%4F6C1C0A0159.includes preserve=yes
//## end module%4F6C1C0A0159.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF31_h
#include "CXODCF31.hpp"
#endif


//## begin module%4F6C1C0A0159.declarations preserve=no
//## end module%4F6C1C0A0159.declarations

//## begin module%4F6C1C0A0159.additionalDeclarations preserve=yes
//## end module%4F6C1C0A0159.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::PrepaidNetworkId 

PrepaidNetworkId::PrepaidNetworkId()
  //## begin PrepaidNetworkId::PrepaidNetworkId%4F6C18C70161_const.hasinit preserve=no
  //## end PrepaidNetworkId::PrepaidNetworkId%4F6C18C70161_const.hasinit
  //## begin PrepaidNetworkId::PrepaidNetworkId%4F6C18C70161_const.initialization preserve=yes
  //## end PrepaidNetworkId::PrepaidNetworkId%4F6C18C70161_const.initialization
{
  //## begin configuration::PrepaidNetworkId::PrepaidNetworkId%4F6C18C70161_const.body preserve=yes
   memcpy(m_sID,"CF31",4);
  //## end configuration::PrepaidNetworkId::PrepaidNetworkId%4F6C18C70161_const.body
}


PrepaidNetworkId::~PrepaidNetworkId()
{
  //## begin configuration::PrepaidNetworkId::~PrepaidNetworkId%4F6C18C70161_dest.body preserve=yes
  //## end configuration::PrepaidNetworkId::~PrepaidNetworkId%4F6C18C70161_dest.body
}



//## Other Operations (implementation)
void PrepaidNetworkId::bind (Query& hQuery)
{
  //## begin configuration::PrepaidNetworkId::bind%4F6C1E75034D.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_PREPAID_NET_ID");
   hQuery.bind("X_PREPAID_NET_ID","SWITCH_NET_ID",Column::STRING,&m_strFirst);
   hQuery.bind("X_PREPAID_NET_ID","PREPAID_NET_ID",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_PREPAID_NET_ID","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_PREPAID_NET_ID","CC_STATE","=","A");
   hQuery.setOrderByClause("X_PREPAID_NET_ID.SWITCH_NET_ID ASC");
  //## end configuration::PrepaidNetworkId::bind%4F6C1E75034D.body
}

void PrepaidNetworkId::setPredicate (Query& hQuery)
{
  //## begin configuration::PrepaidNetworkId::setPredicate%5847182602EF.body preserve=yes
   hQuery.setBasicPredicate("X_PREPAID_NET_ID", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_PREPAID_NET_ID", "CC_STATE", "=", "A");
  //## end configuration::PrepaidNetworkId::setPredicate%5847182602EF.body
}

// Additional Declarations
  //## begin configuration::PrepaidNetworkId%4F6C18C70161.declarations preserve=yes
  //## end configuration::PrepaidNetworkId%4F6C18C70161.declarations

} // namespace configuration

//## begin module%4F6C1C0A0159.epilog preserve=yes
//## end module%4F6C1C0A0159.epilog
