//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FF1D5C40399.cm preserve=no
//	$Date:   Dec 12 2016 12:54:40  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%3FF1D5C40399.cm

//## begin module%3FF1D5C40399.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FF1D5C40399.cp

//## Module: CXOSCF48%3FF1D5C40399; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF48.hpp

#ifndef CXOSCF48_h
#define CXOSCF48_h 1

//## begin module%3FF1D5C40399.additionalIncludes preserve=no
//## end module%3FF1D5C40399.additionalIncludes

//## begin module%3FF1D5C40399.includes preserve=yes
// $Date:   Dec 12 2016 12:54:40  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%3FF1D5C40399.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
//## begin module%3FF1D5C40399.declarations preserve=no
//## end module%3FF1D5C40399.declarations

//## begin module%3FF1D5C40399.additionalDeclarations preserve=yes
//## end module%3FF1D5C40399.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexPanEntryMode1%3FF1D51B00AB.preface preserve=yes
//## end configuration::ConnexPanEntryMode1%3FF1D51B00AB.preface

//## Class: ConnexPanEntryMode1%3FF1D51B00AB
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FF1D566030D;reusable::Query { -> F}
//## Uses: <unnamed>%3FF1D5840222;IF::Extract { -> F}

class DllExport ConnexPanEntryMode1 : public ConversionItem  //## Inherits: <unnamed>%3FF1D5440242
{
  //## begin configuration::ConnexPanEntryMode1%3FF1D51B00AB.initialDeclarations preserve=yes
  //## end configuration::ConnexPanEntryMode1%3FF1D51B00AB.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexPanEntryMode1();

    //## Destructor (generated)
      virtual ~ConnexPanEntryMode1();


    //## Other Operations (specified)
      //## Operation: bind%3FF1D59C0109
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%584715C80044
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexPanEntryMode1%3FF1D51B00AB.public preserve=yes
      //## end configuration::ConnexPanEntryMode1%3FF1D51B00AB.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexPanEntryMode1%3FF1D51B00AB.protected preserve=yes
      //## end configuration::ConnexPanEntryMode1%3FF1D51B00AB.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexPanEntryMode1%3FF1D51B00AB.private preserve=yes
      //## end configuration::ConnexPanEntryMode1%3FF1D51B00AB.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexPanEntryMode1%3FF1D51B00AB.implementation preserve=yes
      //## end configuration::ConnexPanEntryMode1%3FF1D51B00AB.implementation

};

//## begin configuration::ConnexPanEntryMode1%3FF1D51B00AB.postscript preserve=yes
//## end configuration::ConnexPanEntryMode1%3FF1D51B00AB.postscript

} // namespace configuration

//## begin module%3FF1D5C40399.epilog preserve=yes
using namespace configuration;
//## end module%3FF1D5C40399.epilog


#endif
