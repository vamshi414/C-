//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4315E8B4033C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%4315E8B4033C.cm

//## begin module%4315E8B4033C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%4315E8B4033C.cp

//## Module: CXOSCF84%4315E8B4033C; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF84.hpp

#ifndef CXOSCF84_h
#define CXOSCF84_h 1

//## begin module%4315E8B4033C.additionalIncludes preserve=no
//## end module%4315E8B4033C.additionalIncludes

//## begin module%4315E8B4033C.includes preserve=yes
//## end module%4315E8B4033C.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%4315E8B4033C.declarations preserve=no
//## end module%4315E8B4033C.declarations

//## begin module%4315E8B4033C.additionalDeclarations preserve=yes
//## end module%4315E8B4033C.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::StarActionTypeRev%4315E85602FD.preface preserve=yes
//## end configuration::StarActionTypeRev%4315E85602FD.preface

//## Class: StarActionTypeRev%4315E85602FD
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4315E914035B;IF::Extract { -> F}
//## Uses: <unnamed>%4315E92201D4;reusable::Query { -> F}

class DllExport StarActionTypeRev : public ConversionItem  //## Inherits: <unnamed>%4315E90603C8
{
  //## begin configuration::StarActionTypeRev%4315E85602FD.initialDeclarations preserve=yes
  //## end configuration::StarActionTypeRev%4315E85602FD.initialDeclarations

  public:
    //## Constructors (generated)
      StarActionTypeRev();

    //## Destructor (generated)
      virtual ~StarActionTypeRev();


    //## Other Operations (specified)
      //## Operation: bind%4315E9370167
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>MS
      //	<h3>VISA Process Codes
      //	<p>
      //	The VISA Process Codes table is used to determine a
      //	value for the transaction type identifier (FIN_
      //	L<i>yyyymm</i>.TRAN_TYPE_ID) in the financial
      //	transaction.
      //	<p>
      //	Use the CR Client to add or update rows whenever the e
      //	Funds Advantage acquiring platform introduces a new
      //	value in:
      //	<ul>
      //	<li>PROC^CODE (1)
      //	</ul>
      //	VISA Process Codes are in the Parameter Tables folder in
      //	the CR Client for the DataNavigator Server.
      //	</body>
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getFirst%4315E93A003E
      virtual const string& getFirst ();

    // Additional Public Declarations
      //## begin configuration::StarActionTypeRev%4315E85602FD.public preserve=yes
      //## end configuration::StarActionTypeRev%4315E85602FD.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::StarActionTypeRev%4315E85602FD.protected preserve=yes
      //## end configuration::StarActionTypeRev%4315E85602FD.protected

  private:
    // Additional Private Declarations
      //## begin configuration::StarActionTypeRev%4315E85602FD.private preserve=yes
      //## end configuration::StarActionTypeRev%4315E85602FD.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: REQUEST_TYPE%4315E97101A5
      //## begin configuration::StarActionTypeRev::REQUEST_TYPE%4315E97101A5.attr preserve=no  private: string {U} 
      string m_strREQUEST_TYPE;
      //## end configuration::StarActionTypeRev::REQUEST_TYPE%4315E97101A5.attr

      //## Attribute: STATUS%4315E97401E4
      //## begin configuration::StarActionTypeRev::STATUS%4315E97401E4.attr preserve=no  private: string {U} 
      string m_strSTATUS;
      //## end configuration::StarActionTypeRev::STATUS%4315E97401E4.attr

    // Additional Implementation Declarations
      //## begin configuration::StarActionTypeRev%4315E85602FD.implementation preserve=yes
      //## end configuration::StarActionTypeRev%4315E85602FD.implementation

};

//## begin configuration::StarActionTypeRev%4315E85602FD.postscript preserve=yes
//## end configuration::StarActionTypeRev%4315E85602FD.postscript

} // namespace configuration

//## begin module%4315E8B4033C.epilog preserve=yes
using namespace configuration;
//## end module%4315E8B4033C.epilog


#endif
