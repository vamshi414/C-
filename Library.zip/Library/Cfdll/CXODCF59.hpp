//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4006A096006D.cm preserve=no
//	$Date:   Dec 12 2016 13:11:28  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%4006A096006D.cm

//## begin module%4006A096006D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4006A096006D.cp

//## Module: CXOSCF59%4006A096006D; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF59.hpp

#ifndef CXOSCF59_h
#define CXOSCF59_h 1

//## begin module%4006A096006D.additionalIncludes preserve=no
//## end module%4006A096006D.additionalIncludes

//## begin module%4006A096006D.includes preserve=yes
// $Date:   Dec 12 2016 13:11:28  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%4006A096006D.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif
//## begin module%4006A096006D.declarations preserve=no
//## end module%4006A096006D.declarations

//## begin module%4006A096006D.additionalDeclarations preserve=yes
//## end module%4006A096006D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::ConnexPOSConditionCode7%4006A01F0242.preface preserve=yes
//## end configuration::ConnexPOSConditionCode7%4006A01F0242.preface

//## Class: ConnexPOSConditionCode7%4006A01F0242
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4006A05A036B;reusable::Query { -> F}

class DllExport ConnexPOSConditionCode7 : public ConversionItem  //## Inherits: <unnamed>%4006A04C00CB
{
  //## begin configuration::ConnexPOSConditionCode7%4006A01F0242.initialDeclarations preserve=yes
  //## end configuration::ConnexPOSConditionCode7%4006A01F0242.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexPOSConditionCode7();

    //## Destructor (generated)
      virtual ~ConnexPOSConditionCode7();


    //## Other Operations (specified)
      //## Operation: bind%4006A06B005D
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%5847165A0176
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::ConnexPOSConditionCode7%4006A01F0242.public preserve=yes
      //## end configuration::ConnexPOSConditionCode7%4006A01F0242.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::ConnexPOSConditionCode7%4006A01F0242.protected preserve=yes
      //## end configuration::ConnexPOSConditionCode7%4006A01F0242.protected

  private:
    // Additional Private Declarations
      //## begin configuration::ConnexPOSConditionCode7%4006A01F0242.private preserve=yes
      //## end configuration::ConnexPOSConditionCode7%4006A01F0242.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::ConnexPOSConditionCode7%4006A01F0242.implementation preserve=yes
      //## end configuration::ConnexPOSConditionCode7%4006A01F0242.implementation

};

//## begin configuration::ConnexPOSConditionCode7%4006A01F0242.postscript preserve=yes
//## end configuration::ConnexPOSConditionCode7%4006A01F0242.postscript

} // namespace configuration

//## begin module%4006A096006D.epilog preserve=yes
using namespace configuration;
//## end module%4006A096006D.epilog


#endif
