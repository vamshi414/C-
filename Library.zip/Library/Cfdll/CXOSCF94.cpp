//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%47C3D93F006E.cm preserve=no
//	$Date:   Dec 12 2016 15:00:44  $ $Author:   e1009652  $
//	$Revision:   1.3  $
//## end module%47C3D93F006E.cm

//## begin module%47C3D93F006E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%47C3D93F006E.cp

//## Module: CXOSCF94%47C3D93F006E; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF94.cpp

//## begin module%47C3D93F006E.additionalIncludes preserve=no
//## end module%47C3D93F006E.additionalIncludes

//## begin module%47C3D93F006E.includes preserve=yes
//## end module%47C3D93F006E.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF94_h
#include "CXODCF94.hpp"
#endif


//## begin module%47C3D93F006E.declarations preserve=no
//## end module%47C3D93F006E.declarations

//## begin module%47C3D93F006E.additionalDeclarations preserve=yes
//## end module%47C3D93F006E.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::CountryCodeNumToISO 

CountryCodeNumToISO::CountryCodeNumToISO()
  //## begin CountryCodeNumToISO::CountryCodeNumToISO%47C3E0170329_const.hasinit preserve=no
  //## end CountryCodeNumToISO::CountryCodeNumToISO%47C3E0170329_const.hasinit
  //## begin CountryCodeNumToISO::CountryCodeNumToISO%47C3E0170329_const.initialization preserve=yes
  : ConversionItem("## CR94 XLATE COUNTRY CODE")
  //## end CountryCodeNumToISO::CountryCodeNumToISO%47C3E0170329_const.initialization
{
  //## begin configuration::CountryCodeNumToISO::CountryCodeNumToISO%47C3E0170329_const.body preserve=yes
	 memcpy(m_sID,"CF94",4);
  //## end configuration::CountryCodeNumToISO::CountryCodeNumToISO%47C3E0170329_const.body
}


CountryCodeNumToISO::~CountryCodeNumToISO()
{
  //## begin configuration::CountryCodeNumToISO::~CountryCodeNumToISO%47C3E0170329_dest.body preserve=yes
  //## end configuration::CountryCodeNumToISO::~CountryCodeNumToISO%47C3E0170329_dest.body
}



//## Other Operations (implementation)
void CountryCodeNumToISO::bind (Query& hQuery)
{
  //## begin configuration::CountryCodeNumToISO::bind%47C4DA7E02F4.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   hQuery.setQualifier("QUALIFY", "COUNTRY_CODE");
   hQuery.bind("COUNTRY_CODE","COUNTRY_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("COUNTRY_CODE","COUNTRY_CODE_ISO2",Column::STRING,&m_strSecond);   
   hQuery.bind("COUNTRY_CODE","COUNTRY_CODE_ISO3",Column::STRING,&m_strThird);
   hQuery.setBasicPredicate("COUNTRY_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("COUNTRY_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("COUNTRY_CODE", "CUST_ID", "IN", strTemp.c_str());
   hQuery.setOrderByClause("COUNTRY_CODE.COUNTRY_CODE ASC");
  //## end configuration::CountryCodeNumToISO::bind%47C4DA7E02F4.body
}

const string& CountryCodeNumToISO::getSecond ()
{
  //## begin configuration::CountryCodeNumToISO::getSecond%47C4DA8301BC.body preserve=yes
	return m_strSecond.append(m_strThird);
  //## end configuration::CountryCodeNumToISO::getSecond%47C4DA8301BC.body
}

// Additional Declarations
  //## begin configuration::CountryCodeNumToISO%47C3E0170329.declarations preserve=yes
  //## end configuration::CountryCodeNumToISO%47C3E0170329.declarations

} // namespace configuration

//## begin module%47C3D93F006E.epilog preserve=yes
//## end module%47C3D93F006E.epilog
