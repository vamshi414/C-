//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A2F887C02CD.cm preserve=no
//	$Date:   Feb 05 2021 07:44:28  $ $Author:   e3028298  $
//	$Revision:   1.1  $
//## end module%5A2F887C02CD.cm

//## begin module%5A2F887C02CD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A2F887C02CD.cp

//## Module: CXOSCFA9%5A2F887C02CD; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: D:\Devel\V03.1A.R007\Dn\Server\Library\Cfdll\CXOSCFA9.cpp

//## begin module%5A2F887C02CD.additionalIncludes preserve=no
//## end module%5A2F887C02CD.additionalIncludes

//## begin module%5A2F887C02CD.includes preserve=yes
//## end module%5A2F887C02CD.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCFA9_h
#include "CXODCFA9.hpp"
#endif


//## begin module%5A2F887C02CD.declarations preserve=no
//## end module%5A2F887C02CD.declarations

//## begin module%5A2F887C02CD.additionalDeclarations preserve=yes
//## end module%5A2F887C02CD.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::BusinessCode 

BusinessCode::BusinessCode()
  //## begin BusinessCode::BusinessCode%5A2F8C52035C_const.hasinit preserve=no
  //## end BusinessCode::BusinessCode%5A2F8C52035C_const.hasinit
  //## begin BusinessCode::BusinessCode%5A2F8C52035C_const.initialization preserve=yes
  : ConversionItem("## CRA9 XLATE BUSINESS CODE")
  //## end BusinessCode::BusinessCode%5A2F8C52035C_const.initialization
{
  //## begin configuration::BusinessCode::BusinessCode%5A2F8C52035C_const.body preserve=yes
   memcpy(m_sID,"CFA9",4);
  //## end configuration::BusinessCode::BusinessCode%5A2F8C52035C_const.body
}


BusinessCode::~BusinessCode()
{
  //## begin configuration::BusinessCode::~BusinessCode%5A2F8C52035C_dest.body preserve=yes
  //## end configuration::BusinessCode::~BusinessCode%5A2F8C52035C_dest.body
}



//## Other Operations (implementation)
void BusinessCode::bind (reusable::Query& hQuery)
{
  //## begin configuration::BusinessCode::bind%5A2F8C8D007A.body preserve=yes
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   hQuery.setQualifier("QUALIFY","BUSINESS_CODE");
   hQuery.bind("BUSINESS_CODE","BUSINESS_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("BUSINESS_CODE","CFG_DESCRIPTION",Column::STRING,&m_strSecond);
   hQuery.bind("BUSINESS_CODE","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.setBasicPredicate("BUSINESS_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("BUSINESS_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCustomerID + "','****')";
   hQuery.setBasicPredicate("BUSINESS_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("BUSINESS_CODE.BUSINESS_CODE ASC,BUSINESS_CODE.CUST_ID DESC");
  //## end configuration::BusinessCode::bind%5A2F8C8D007A.body
}

const string& BusinessCode::getSecond ()
{
  //## begin configuration::BusinessCode::getSecond%6017748D01A6.body preserve=yes
   m_strSecond.resize(50,' ');
   return m_strSecond;
  //## end configuration::BusinessCode::getSecond%6017748D01A6.body
}

// Additional Declarations
  //## begin configuration::BusinessCode%5A2F8C52035C.declarations preserve=yes
  //## end configuration::BusinessCode%5A2F8C52035C.declarations

} // namespace configuration

//## begin module%5A2F887C02CD.epilog preserve=yes
//## end module%5A2F887C02CD.epilog
