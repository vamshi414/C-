//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3FFDA9150251.cm preserve=no
//	$Date:   Dec 16 2016 15:24:50  $ $Author:   e1009652  $
//	$Revision:   1.4  $
//## end module%3FFDA9150251.cm

//## begin module%3FFDA9150251.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FFDA9150251.cp

//## Module: CXOSCF56%3FFDA9150251; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF56.cpp

//## begin module%3FFDA9150251.additionalIncludes preserve=no
//## end module%3FFDA9150251.additionalIncludes

//## begin module%3FFDA9150251.includes preserve=yes
// $Date:   Dec 16 2016 15:24:50  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%3FFDA9150251.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF56_h
#include "CXODCF56.hpp"
#endif
//## begin module%3FFDA9150251.declarations preserve=no
//## end module%3FFDA9150251.declarations

//## begin module%3FFDA9150251.additionalDeclarations preserve=yes
//## end module%3FFDA9150251.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::ConnexTerminalType1 

ConnexTerminalType1::ConnexTerminalType1()
  //## begin ConnexTerminalType1::ConnexTerminalType1%3FFDA7FD0000_const.hasinit preserve=no
  //## end ConnexTerminalType1::ConnexTerminalType1%3FFDA7FD0000_const.hasinit
  //## begin ConnexTerminalType1::ConnexTerminalType1%3FFDA7FD0000_const.initialization preserve=yes
     : ConversionItem("## CR68 XLATE TERM TYPE1")
  //## end ConnexTerminalType1::ConnexTerminalType1%3FFDA7FD0000_const.initialization
{
  //## begin configuration::ConnexTerminalType1::ConnexTerminalType1%3FFDA7FD0000_const.body preserve=yes
   memcpy(m_sID,"CF56",4);
  //## end configuration::ConnexTerminalType1::ConnexTerminalType1%3FFDA7FD0000_const.body
}


ConnexTerminalType1::~ConnexTerminalType1()
{
  //## begin configuration::ConnexTerminalType1::~ConnexTerminalType1%3FFDA7FD0000_dest.body preserve=yes
  //## end configuration::ConnexTerminalType1::~ConnexTerminalType1%3FFDA7FD0000_dest.body
}



//## Other Operations (implementation)
void ConnexTerminalType1::bind (Query& hQuery)
{
  //## begin configuration::ConnexTerminalType1::bind%3FFDA80F00DA.body preserve=yes
   hQuery.setQualifier("QUALIFY","X_IBM_POS_TDT");
   hQuery.bind("X_IBM_POS_TDT","TDT",Column::STRING,&m_strFirst);
   hQuery.bind("X_IBM_POS_TDT","POS_OPER_ENV",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_IBM_POS_TDT","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_TDT","CC_STATE","=","A");
   hQuery.setOrderByClause("X_IBM_POS_TDT.TDT ASC");
  //## end configuration::ConnexTerminalType1::bind%3FFDA80F00DA.body
}

void ConnexTerminalType1::setPredicate (Query& hQuery)
{
  //## begin configuration::ConnexTerminalType1::setPredicate%584716910132.body preserve=yes
   hQuery.setBasicPredicate("X_IBM_POS_TDT", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("X_IBM_POS_TDT", "CC_STATE", "=", "A");
  //## end configuration::ConnexTerminalType1::setPredicate%584716910132.body
}

// Additional Declarations
  //## begin configuration::ConnexTerminalType1%3FFDA7FD0000.declarations preserve=yes
  //## end configuration::ConnexTerminalType1%3FFDA7FD0000.declarations

} // namespace configuration

//## begin module%3FFDA9150251.epilog preserve=yes
//## end module%3FFDA9150251.epilog
