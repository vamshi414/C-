//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%393E6BA20042.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%393E6BA20042.cm

//## begin module%393E6BA20042.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%393E6BA20042.cp

//## Module: CXOSCF26%393E6BA20042; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXODCF26.hpp

#ifndef CXOSCF26_h
#define CXOSCF26_h 1

//## begin module%393E6BA20042.additionalIncludes preserve=no
//## end module%393E6BA20042.additionalIncludes

//## begin module%393E6BA20042.includes preserve=yes
// $Date:   Apr 08 2004 14:10:56  $ $Author:   D02405  $ $Revision:   1.4  $
//## end module%393E6BA20042.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%393E6BA20042.declarations preserve=no
//## end module%393E6BA20042.declarations

//## begin module%393E6BA20042.additionalDeclarations preserve=yes
//## end module%393E6BA20042.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::VerificationItem%393E6D47025B.preface preserve=yes
//## end configuration::VerificationItem%393E6D47025B.preface

//## Class: VerificationItem%393E6D47025B
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%393E71FA02A1;reusable::Query { -> F}

class DllExport VerificationItem : public reusable::Object  //## Inherits: <unnamed>%393E71F70166
{
  //## begin configuration::VerificationItem%393E6D47025B.initialDeclarations preserve=yes
  //## end configuration::VerificationItem%393E6D47025B.initialDeclarations

  public:
    //## Constructors (generated)
      VerificationItem();

    //## Constructors (specified)
      //## Operation: VerificationItem%393E721901A1
      VerificationItem (const char* pszMember);

    //## Destructor (generated)
      virtual ~VerificationItem();


    //## Other Operations (specified)
      //## Operation: bind%393E721901D3
      virtual void bind (Query& hQuery);

      //## Operation: getKey%393E721901FB
      virtual const string& getKey ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Member%393E724003A6
      const string& getMember () const
      {
        //## begin configuration::VerificationItem::getMember%393E724003A6.get preserve=no
        return m_strMember;
        //## end configuration::VerificationItem::getMember%393E724003A6.get
      }


    // Additional Public Declarations
      //## begin configuration::VerificationItem%393E6D47025B.public preserve=yes
      //## end configuration::VerificationItem%393E6D47025B.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: CUST_ID%394FCE0402F6
      //## begin configuration::VerificationItem::CUST_ID%394FCE0402F6.attr preserve=no  private: string {U} 
      string m_strCUST_ID;
      //## end configuration::VerificationItem::CUST_ID%394FCE0402F6.attr

      //## Attribute: Key%393E7240037E
      //## begin configuration::VerificationItem::Key%393E7240037E.attr preserve=no  public: string {U} 
      string m_strKey;
      //## end configuration::VerificationItem::Key%393E7240037E.attr

    // Additional Protected Declarations
      //## begin configuration::VerificationItem%393E6D47025B.protected preserve=yes
      //## end configuration::VerificationItem%393E6D47025B.protected

  private:
    // Additional Private Declarations
      //## begin configuration::VerificationItem%393E6D47025B.private preserve=yes
      //## end configuration::VerificationItem%393E6D47025B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin configuration::VerificationItem::Member%393E724003A6.attr preserve=no  public: string {U} 
      string m_strMember;
      //## end configuration::VerificationItem::Member%393E724003A6.attr

    // Additional Implementation Declarations
      //## begin configuration::VerificationItem%393E6D47025B.implementation preserve=yes
      //## end configuration::VerificationItem%393E6D47025B.implementation

};

//## begin configuration::VerificationItem%393E6D47025B.postscript preserve=yes
//## end configuration::VerificationItem%393E6D47025B.postscript

} // namespace configuration

//## begin module%393E6BA20042.epilog preserve=yes
using namespace configuration;
//## end module%393E6BA20042.epilog


#endif
