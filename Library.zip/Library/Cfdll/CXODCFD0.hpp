//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%629681B9022D.cm preserve=no
//## end module%629681B9022D.cm

//## begin module%629681B9022D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%629681B9022D.cp

//## Module: CXOSCFD0%629681B9022D; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cfdll\CXODCFD0.hpp

#ifndef CXOSCFD0_h
#define CXOSCFD0_h 1

//## begin module%629681B9022D.additionalIncludes preserve=no
//## end module%629681B9022D.additionalIncludes

//## begin module%629681B9022D.includes preserve=yes
//## end module%629681B9022D.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%629681B9022D.declarations preserve=no
//## end module%629681B9022D.declarations

//## begin module%629681B9022D.additionalDeclarations preserve=yes
//## end module%629681B9022D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::SchemeFunding%629681010173.preface preserve=yes
//## end configuration::SchemeFunding%629681010173.preface

//## Class: SchemeFunding%629681010173
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%629681330211;IF::Extract { -> F}
//## Uses: <unnamed>%62968136030A;reusable::Query { -> F}

class DllExport SchemeFunding : public ConversionItem  //## Inherits: <unnamed>%6296812F01B2
{
  //## begin configuration::SchemeFunding%629681010173.initialDeclarations preserve=yes
  //## end configuration::SchemeFunding%629681010173.initialDeclarations

  public:
    //## Constructors (generated)
      SchemeFunding();

    //## Destructor (generated)
      virtual ~SchemeFunding();


    //## Other Operations (specified)
      //## Operation: bind%629681470196
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%6296814B007B
      virtual const string& getFirst ();

    // Additional Public Declarations
      //## begin configuration::SchemeFunding%629681010173.public preserve=yes
      //## end configuration::SchemeFunding%629681010173.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::SchemeFunding%629681010173.protected preserve=yes
      //## end configuration::SchemeFunding%629681010173.protected

  private:
    // Additional Private Declarations
      //## begin configuration::SchemeFunding%629681010173.private preserve=yes
      //## end configuration::SchemeFunding%629681010173.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: COUNTRY_ISS_INST%629684C20231
      //## begin configuration::SchemeFunding::COUNTRY_ISS_INST%629684C20231.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strCOUNTRY_ISS_INST;
      //## end configuration::SchemeFunding::COUNTRY_ISS_INST%629684C20231.attr

      //## Attribute: CUR_TRAN%629684AA000A
      //## begin configuration::SchemeFunding::CUR_TRAN%629684AA000A.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strCUR_TRAN;
      //## end configuration::SchemeFunding::CUR_TRAN%629684AA000A.attr

      //## Attribute: NET_ID%629684C30077
      //## begin configuration::SchemeFunding::NET_ID%629684C30077.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strNET_ID;
      //## end configuration::SchemeFunding::NET_ID%629684C30077.attr

      //## Attribute: PAN_PREFIX%629684C302FB
      //## begin configuration::SchemeFunding::PAN_PREFIX%629684C302FB.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strPAN_PREFIX;
      //## end configuration::SchemeFunding::PAN_PREFIX%629684C302FB.attr

    // Additional Implementation Declarations
      //## begin configuration::SchemeFunding%629681010173.implementation preserve=yes
      reusable::string m_strISSUER_BIN;
      //## end configuration::SchemeFunding%629681010173.implementation

};

//## begin configuration::SchemeFunding%629681010173.postscript preserve=yes
//## end configuration::SchemeFunding%629681010173.postscript

} // namespace configuration

//## begin module%629681B9022D.epilog preserve=yes
//## end module%629681B9022D.epilog


#endif
