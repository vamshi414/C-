//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39D0E4200182.cm preserve=no
//	$Date:   Dec 07 2016 15:47:38  $ $Author:   e1009652  $
//	$Revision:   1.5  $
//## end module%39D0E4200182.cm

//## begin module%39D0E4200182.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39D0E4200182.cp

//## Module: CXOSCF38%39D0E4200182; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF38.hpp

#ifndef CXOSCF38_h
#define CXOSCF38_h 1

//## begin module%39D0E4200182.additionalIncludes preserve=no
//## end module%39D0E4200182.additionalIncludes

//## begin module%39D0E4200182.includes preserve=yes
// $Date:   Dec 07 2016 15:47:38  $ $Author:   e1009652  $ $Revision:   1.5  $
//## end module%39D0E4200182.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%39D0E4200182.declarations preserve=no
//## end module%39D0E4200182.declarations

//## begin module%39D0E4200182.additionalDeclarations preserve=yes
//## end module%39D0E4200182.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::LowCash%39D0E70C02FA.preface preserve=yes
//## end configuration::LowCash%39D0E70C02FA.preface

//## Class: LowCash%39D0E70C02FA
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39D0EE8E0362;IF::Extract { -> F}
//## Uses: <unnamed>%39D0EE960255;reusable::Query { -> F}

class DllExport LowCash : public ConversionItem  //## Inherits: <unnamed>%39D0E909039C
{
  //## begin configuration::LowCash%39D0E70C02FA.initialDeclarations preserve=yes
  //## end configuration::LowCash%39D0E70C02FA.initialDeclarations

  public:
    //## Constructors (generated)
      LowCash();

    //## Destructor (generated)
      virtual ~LowCash();


    //## Other Operations (specified)
      //## Operation: bind%39D0E741030A
      virtual void bind (Query& hQuery);

      //## Operation: setPredicate%584717930052
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::LowCash%39D0E70C02FA.public preserve=yes
      //## end configuration::LowCash%39D0E70C02FA.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::LowCash%39D0E70C02FA.protected preserve=yes
      //## end configuration::LowCash%39D0E70C02FA.protected

  private:
    // Additional Private Declarations
      //## begin configuration::LowCash%39D0E70C02FA.private preserve=yes
      //## end configuration::LowCash%39D0E70C02FA.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::LowCash%39D0E70C02FA.implementation preserve=yes
      //## end configuration::LowCash%39D0E70C02FA.implementation

};

//## begin configuration::LowCash%39D0E70C02FA.postscript preserve=yes
//## end configuration::LowCash%39D0E70C02FA.postscript

} // namespace configuration

//## begin module%39D0E4200182.epilog preserve=yes
using namespace configuration;
//## end module%39D0E4200182.epilog


#endif
