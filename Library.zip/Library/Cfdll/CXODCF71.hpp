//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%42528C0D0203.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%42528C0D0203.cm

//## begin module%42528C0D0203.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%42528C0D0203.cp

//## Module: CXOSCF71%42528C0D0203; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF71.hpp

#ifndef CXOSCF71_h
#define CXOSCF71_h 1

//## begin module%42528C0D0203.additionalIncludes preserve=no
//## end module%42528C0D0203.additionalIncludes

//## begin module%42528C0D0203.includes preserve=yes
// $Date:   Apr 05 2005 13:22:14  $ $Author:   D92705  $ $Revision:   1.0  $
//## end module%42528C0D0203.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%42528C0D0203.declarations preserve=no
//## end module%42528C0D0203.declarations

//## begin module%42528C0D0203.additionalDeclarations preserve=yes
//## end module%42528C0D0203.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::DNTransactionType%42528B1F02CE.preface preserve=yes
//## end configuration::DNTransactionType%42528B1F02CE.preface

//## Class: DNTransactionType%42528B1F02CE
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%42528B5502CE;IF::Extract { -> F}
//## Uses: <unnamed>%42528B5603D8;reusable::Query { -> F}

class DllExport DNTransactionType : public ConversionItem  //## Inherits: <unnamed>%42528B300222
{
  //## begin configuration::DNTransactionType%42528B1F02CE.initialDeclarations preserve=yes
  //## end configuration::DNTransactionType%42528B1F02CE.initialDeclarations

  public:
    //## Constructors (generated)
      DNTransactionType();

    //## Destructor (generated)
      virtual ~DNTransactionType();


    //## Other Operations (specified)
      //## Operation: bind%42528B7C0148
      virtual void bind (reusable::Query& hQuery);

      //## Operation: getFirst%42528B7D035B
      virtual const string& getFirst ();

      //## Operation: getSecond%42528B7F004E
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::DNTransactionType%42528B1F02CE.public preserve=yes
      //## end configuration::DNTransactionType%42528B1F02CE.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::DNTransactionType%42528B1F02CE.protected preserve=yes
      //## end configuration::DNTransactionType%42528B1F02CE.protected

  private:
    // Additional Private Declarations
      //## begin configuration::DNTransactionType%42528B1F02CE.private preserve=yes
      //## end configuration::DNTransactionType%42528B1F02CE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ADVG_PROCESS_CODE%42528B720157
      //## begin configuration::DNTransactionType::ADVG_PROCESS_CODE%42528B720157.attr preserve=no  private: string {V} 
      string m_strADVG_PROCESS_CODE;
      //## end configuration::DNTransactionType::ADVG_PROCESS_CODE%42528B720157.attr

      //## Attribute: ADVG_MSG_CLASS%42528B720167
      //## begin configuration::DNTransactionType::ADVG_MSG_CLASS%42528B720167.attr preserve=no  private: string {V} 
      string m_strADVG_MSG_CLASS;
      //## end configuration::DNTransactionType::ADVG_MSG_CLASS%42528B720167.attr

      //## Attribute: ADVG_PRE_AUTH%42528B720186
      //## begin configuration::DNTransactionType::ADVG_PRE_AUTH%42528B720186.attr preserve=no  private: string {V} 
      string m_strADVG_PRE_AUTH;
      //## end configuration::DNTransactionType::ADVG_PRE_AUTH%42528B720186.attr

      //## Attribute: ADVG_ACCT_QUAL_1%42528B7201A5
      //## begin configuration::DNTransactionType::ADVG_ACCT_QUAL_1%42528B7201A5.attr preserve=no  private: string {V} 
      string m_strADVG_ACCT_QUAL_1;
      //## end configuration::DNTransactionType::ADVG_ACCT_QUAL_1%42528B7201A5.attr

      //## Attribute: ADVG_TRAN_DESC%42528B7201C5
      //## begin configuration::DNTransactionType::ADVG_TRAN_DESC%42528B7201C5.attr preserve=no  private: string {V} 
      string m_strADVG_TRAN_DESC;
      //## end configuration::DNTransactionType::ADVG_TRAN_DESC%42528B7201C5.attr

      //## Attribute: PROCESS_CODE%42528B7201E4
      //## begin configuration::DNTransactionType::PROCESS_CODE%42528B7201E4.attr preserve=no  private: string {V} 
      string m_strPROCESS_CODE;
      //## end configuration::DNTransactionType::PROCESS_CODE%42528B7201E4.attr

      //## Attribute: MSG_CLASS%42528B720203
      //## begin configuration::DNTransactionType::MSG_CLASS%42528B720203.attr preserve=no  private: string {V} 
      string m_strMSG_CLASS;
      //## end configuration::DNTransactionType::MSG_CLASS%42528B720203.attr

      //## Attribute: PRE_AUTH%42528B720222
      //## begin configuration::DNTransactionType::PRE_AUTH%42528B720222.attr preserve=no  private: string {V} 
      string m_strPRE_AUTH;
      //## end configuration::DNTransactionType::PRE_AUTH%42528B720222.attr

      //## Attribute: MEDIA_TYPE%42528B720242
      //## begin configuration::DNTransactionType::MEDIA_TYPE%42528B720242.attr preserve=no  private: string {V} 
      string m_strMEDIA_TYPE;
      //## end configuration::DNTransactionType::MEDIA_TYPE%42528B720242.attr

    // Additional Implementation Declarations
      //## begin configuration::DNTransactionType%42528B1F02CE.implementation preserve=yes
      //## end configuration::DNTransactionType%42528B1F02CE.implementation

};

//## begin configuration::DNTransactionType%42528B1F02CE.postscript preserve=yes
//## end configuration::DNTransactionType%42528B1F02CE.postscript

} // namespace configuration

//## begin module%42528C0D0203.epilog preserve=yes
using namespace configuration;
//## end module%42528C0D0203.epilog


#endif
