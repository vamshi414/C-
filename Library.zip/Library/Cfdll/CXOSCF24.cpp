//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%393E6AAF007F.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%393E6AAF007F.cm

//## begin module%393E6AAF007F.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%393E6AAF007F.cp

//## Module: CXOSCF24%393E6AAF007F; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Pvcswork\Dn\Server\Library\Cfdll\CXOSCF24.cpp

//## begin module%393E6AAF007F.additionalIncludes preserve=no
//## end module%393E6AAF007F.additionalIncludes

//## begin module%393E6AAF007F.includes preserve=yes
// $Date:   Apr 08 2004 14:11:16  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%393E6AAF007F.includes

#ifndef CXOSCF24_h
#include "CXODCF24.hpp"
#endif
#ifndef CXOSMN02_h
#include "CXODMN02.hpp"
#endif


//## begin module%393E6AAF007F.declarations preserve=no
//## end module%393E6AAF007F.declarations

//## begin module%393E6AAF007F.additionalDeclarations preserve=yes
//## end module%393E6AAF007F.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::VerificationTable 



VerificationTable::VerificationTable()
  //## begin VerificationTable::VerificationTable%393E6D3A02C0_const.hasinit preserve=no
  //## end VerificationTable::VerificationTable%393E6D3A02C0_const.hasinit
  //## begin VerificationTable::VerificationTable%393E6D3A02C0_const.initialization preserve=yes
  //## end VerificationTable::VerificationTable%393E6D3A02C0_const.initialization
{
  //## begin configuration::VerificationTable::VerificationTable%393E6D3A02C0_const.body preserve=yes
  //## end configuration::VerificationTable::VerificationTable%393E6D3A02C0_const.body
}

VerificationTable::VerificationTable (const char* pszName)
  //## begin configuration::VerificationTable::VerificationTable%393E6F68015A.hasinit preserve=no
  //## end configuration::VerificationTable::VerificationTable%393E6F68015A.hasinit
  //## begin configuration::VerificationTable::VerificationTable%393E6F68015A.initialization preserve=yes
   : ConfigurationTable(pszName)
  //## end configuration::VerificationTable::VerificationTable%393E6F68015A.initialization
{
  //## begin configuration::VerificationTable::VerificationTable%393E6F68015A.body preserve=yes
   memcpy(m_sID,"CF24",4);
  //## end configuration::VerificationTable::VerificationTable%393E6F68015A.body
}


VerificationTable::~VerificationTable()
{
  //## begin configuration::VerificationTable::~VerificationTable%393E6D3A02C0_dest.body preserve=yes
   m_hVerificationItem.erase(m_hVerificationItem.begin(),m_hVerificationItem.end());
  //## end configuration::VerificationTable::~VerificationTable%393E6D3A02C0_dest.body
}



//## Other Operations (implementation)
bool VerificationTable::add (const string& strKey)
{
  //## begin configuration::VerificationTable::add%393E6F680182.body preserve=yes
   m_hVerificationItem.insert(strKey);
   return true;
  //## end configuration::VerificationTable::add%393E6F680182.body
}

bool VerificationTable::find (const string& strKey)
{
  //## begin configuration::VerificationTable::find%393E6F6801B4.body preserve=yes
   m_pCount[0]->increment();
   set<string, less<string> >::iterator pVerificationItem;
   pVerificationItem = m_hVerificationItem.find(strKey);
   if (pVerificationItem == m_hVerificationItem.end())
   {
      m_pCount[1]->increment();
      return false;	
   }
   return true;
  //## end configuration::VerificationTable::find%393E6F6801B4.body
}

// Additional Declarations
  //## begin configuration::VerificationTable%393E6D3A02C0.declarations preserve=yes
  //## end configuration::VerificationTable%393E6D3A02C0.declarations

} // namespace configuration

//## begin module%393E6AAF007F.epilog preserve=yes
//## end module%393E6AAF007F.epilog
