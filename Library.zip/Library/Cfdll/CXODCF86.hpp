//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%43F34D0801E4.cm preserve=no
//	$Date:   Dec 12 2016 13:22:30  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%43F34D0801E4.cm

//## begin module%43F34D0801E4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%43F34D0801E4.cp

//## Module: CXOSCF86%43F34D0801E4; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXODCF86.hpp

#ifndef CXOSCF86_h
#define CXOSCF86_h 1

//## begin module%43F34D0801E4.additionalIncludes preserve=no
//## end module%43F34D0801E4.additionalIncludes

//## begin module%43F34D0801E4.includes preserve=yes
//## end module%43F34D0801E4.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%43F34D0801E4.declarations preserve=no
//## end module%43F34D0801E4.declarations

//## begin module%43F34D0801E4.additionalDeclarations preserve=yes
//## end module%43F34D0801E4.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::Miscellaneous%43F34C1D036B.preface preserve=yes
//## end configuration::Miscellaneous%43F34C1D036B.preface

//## Class: Miscellaneous%43F34C1D036B
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%43F34C510000;reusable::Query { -> F}

class DllExport Miscellaneous : public ConversionItem  //## Inherits: <unnamed>%43F34C4C03A9
{
  //## begin configuration::Miscellaneous%43F34C1D036B.initialDeclarations preserve=yes
  //## end configuration::Miscellaneous%43F34C1D036B.initialDeclarations

  public:
    //## Constructors (generated)
      Miscellaneous();

    //## Constructors (specified)
      //## Operation: Miscellaneous%57B1C346037E
      Miscellaneous (const char* pszCFG_DATA_TYPE);

    //## Destructor (generated)
      virtual ~Miscellaneous();


    //## Other Operations (specified)
      //## Operation: bind%43F34CC9009C
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%57B1C2320098
      virtual const string& getFirst ();

      //## Operation: getSecond%57B1C23400F7
      virtual const string& getSecond ();

      //## Operation: setPredicate%584717C3025E
      virtual void setPredicate (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::Miscellaneous%43F34C1D036B.public preserve=yes
      //## end configuration::Miscellaneous%43F34C1D036B.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::Miscellaneous%43F34C1D036B.protected preserve=yes
      //## end configuration::Miscellaneous%43F34C1D036B.protected

  private:
    // Additional Private Declarations
      //## begin configuration::Miscellaneous%43F34C1D036B.private preserve=yes
      //## end configuration::Miscellaneous%43F34C1D036B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CFG_DATA_TYPE%57B1C37302F6
      //## begin configuration::Miscellaneous::CFG_DATA_TYPE%57B1C37302F6.attr preserve=no  private: string {V} 
      string m_strCFG_DATA_TYPE;
      //## end configuration::Miscellaneous::CFG_DATA_TYPE%57B1C37302F6.attr

    // Additional Implementation Declarations
      //## begin configuration::Miscellaneous%43F34C1D036B.implementation preserve=yes
      //## end configuration::Miscellaneous%43F34C1D036B.implementation

};

//## begin configuration::Miscellaneous%43F34C1D036B.postscript preserve=yes
//## end configuration::Miscellaneous%43F34C1D036B.postscript

} // namespace configuration

//## begin module%43F34D0801E4.epilog preserve=yes
using namespace configuration;
//## end module%43F34D0801E4.epilog


#endif
