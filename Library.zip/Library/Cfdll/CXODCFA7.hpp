//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5949894C0079.cm preserve=no
//	$Date:   Jun 23 2017 10:12:24  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5949894C0079.cm

//## begin module%5949894C0079.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5949894C0079.cp

//## Module: CXOSCFA7%5949894C0079; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.8A.R004\Windows\Build\Dn\Server\Library\Cfdll\CXODCFA7.hpp

#ifndef CXOSCFA7_h
#define CXOSCFA7_h 1

//## begin module%5949894C0079.additionalIncludes preserve=no
//## end module%5949894C0079.additionalIncludes

//## begin module%5949894C0079.includes preserve=yes
//## end module%5949894C0079.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%5949894C0079.declarations preserve=no
//## end module%5949894C0079.declarations

//## begin module%5949894C0079.additionalDeclarations preserve=yes
//## end module%5949894C0079.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::SettlementWebAdjNetId%594988BB00A7.preface preserve=yes
//## end configuration::SettlementWebAdjNetId%594988BB00A7.preface

//## Class: SettlementWebAdjNetId%594988BB00A7
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5949891A02AD;IF::Extract { -> F}
//## Uses: <unnamed>%5949891D019F;reusable::Query { -> F}

class DllExport SettlementWebAdjNetId : public ConversionItem  //## Inherits: <unnamed>%59498917030F
{
  //## begin configuration::SettlementWebAdjNetId%594988BB00A7.initialDeclarations preserve=yes
  //## end configuration::SettlementWebAdjNetId%594988BB00A7.initialDeclarations

  public:
    //## Constructors (generated)
      SettlementWebAdjNetId();

    //## Destructor (generated)
      virtual ~SettlementWebAdjNetId();


    //## Other Operations (specified)
      //## Operation: bind%594988E60081
      virtual void bind (Query& hQuery);

    // Additional Public Declarations
      //## begin configuration::SettlementWebAdjNetId%594988BB00A7.public preserve=yes
      //## end configuration::SettlementWebAdjNetId%594988BB00A7.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::SettlementWebAdjNetId%594988BB00A7.protected preserve=yes
      //## end configuration::SettlementWebAdjNetId%594988BB00A7.protected

  private:
    // Additional Private Declarations
      //## begin configuration::SettlementWebAdjNetId%594988BB00A7.private preserve=yes
      //## end configuration::SettlementWebAdjNetId%594988BB00A7.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin configuration::SettlementWebAdjNetId%594988BB00A7.implementation preserve=yes
      //## end configuration::SettlementWebAdjNetId%594988BB00A7.implementation

};

//## begin configuration::SettlementWebAdjNetId%594988BB00A7.postscript preserve=yes
//## end configuration::SettlementWebAdjNetId%594988BB00A7.postscript

} // namespace configuration

//## begin module%5949894C0079.epilog preserve=yes
//## end module%5949894C0079.epilog


#endif
