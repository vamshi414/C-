//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4ACBA118023A.cm preserve=no
//	$Date:   May 26 2020 10:44:50  $ $Author:   e1009510  $
//	$Revision:   1.3  $
//## end module%4ACBA118023A.cm

//## begin module%4ACBA118023A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4ACBA118023A.cp

//## Module: CXOSCF97%4ACBA118023A; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Library\Cfdll\CXOSCF97.cpp

//## begin module%4ACBA118023A.additionalIncludes preserve=no
//## end module%4ACBA118023A.additionalIncludes

//## begin module%4ACBA118023A.includes preserve=yes
//## end module%4ACBA118023A.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU07_h
#include "CXODRU07.hpp"
#endif
#ifndef CXOSCF97_h
#include "CXODCF97.hpp"
#endif


//## begin module%4ACBA118023A.declarations preserve=no
//## end module%4ACBA118023A.declarations

//## begin module%4ACBA118023A.additionalDeclarations preserve=yes
//## end module%4ACBA118023A.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::DisputedAuthorizationTransaction 

DisputedAuthorizationTransaction::DisputedAuthorizationTransaction()
  //## begin DisputedAuthorizationTransaction::DisputedAuthorizationTransaction%4ACB9FA20120_const.hasinit preserve=no
      : m_iUNIQUENESS_KEY(0)
  //## end DisputedAuthorizationTransaction::DisputedAuthorizationTransaction%4ACB9FA20120_const.hasinit
  //## begin DisputedAuthorizationTransaction::DisputedAuthorizationTransaction%4ACB9FA20120_const.initialization preserve=yes
  //## end DisputedAuthorizationTransaction::DisputedAuthorizationTransaction%4ACB9FA20120_const.initialization
{
  //## begin configuration::DisputedAuthorizationTransaction::DisputedAuthorizationTransaction%4ACB9FA20120_const.body preserve=yes
   memcpy(m_sID,"CF97",4);
  //## end configuration::DisputedAuthorizationTransaction::DisputedAuthorizationTransaction%4ACB9FA20120_const.body
}


DisputedAuthorizationTransaction::~DisputedAuthorizationTransaction()
{
  //## begin configuration::DisputedAuthorizationTransaction::~DisputedAuthorizationTransaction%4ACB9FA20120_dest.body preserve=yes
  //## end configuration::DisputedAuthorizationTransaction::~DisputedAuthorizationTransaction%4ACB9FA20120_dest.body
}



//## Other Operations (implementation)
void DisputedAuthorizationTransaction::bind (Query& hQuery)
{
  //## begin configuration::DisputedAuthorizationTransaction::bind%4ACBA2060363.body preserve=yes
   hQuery.setQualifier("CUSTQUAL","PROBLEM_TRAN");
   hQuery.bind("PROBLEM_TRAN","SOURCE_VALUE",Column::STRING,&m_strFirst);
   hQuery.bind("PROBLEM_TRAN","TSTAMP_TRANS",Column::STRING,&m_strTSTAMP_TRANS);
   hQuery.bind("PROBLEM_TRAN","UNIQUENESS_KEY",Column::LONG,&m_iUNIQUENESS_KEY);
   hQuery.setBasicPredicate("PROBLEM_TRAN","PROBLEM_TABLE","=","EMS_CASE");
   hQuery.setBasicPredicate("PROBLEM_TRAN","REASON_CODE","=","8");
   hQuery.setOrderByClause("PROBLEM_TRAN.SOURCE_VALUE ASC");
  //## end configuration::DisputedAuthorizationTransaction::bind%4ACBA2060363.body
}

const string& DisputedAuthorizationTransaction::getSecond ()
{
  //## begin configuration::DisputedAuthorizationTransaction::getSecond%4ACBA20D0026.body preserve=yes
   char szTemp[9];
   snprintf(szTemp,sizeof(szTemp),"%08d",m_iUNIQUENESS_KEY);
   m_strTSTAMP_TRANS.append(szTemp,8);
   return m_strTSTAMP_TRANS;
  //## end configuration::DisputedAuthorizationTransaction::getSecond%4ACBA20D0026.body
}

void DisputedAuthorizationTransaction::setPredicate (Query& hQuery)
{
  //## begin configuration::DisputedAuthorizationTransaction::setPredicate%584716F00196.body preserve=yes
   hQuery.setBasicPredicate("PROBLEM_TRAN", "PROBLEM_TABLE", "=", "EMS_CASE");
   hQuery.setBasicPredicate("PROBLEM_TRAN", "REASON_CODE", "=", "8");
  //## end configuration::DisputedAuthorizationTransaction::setPredicate%584716F00196.body
}

// Additional Declarations
  //## begin configuration::DisputedAuthorizationTransaction%4ACB9FA20120.declarations preserve=yes
  //## end configuration::DisputedAuthorizationTransaction%4ACB9FA20120.declarations

} // namespace configuration

//## begin module%4ACBA118023A.epilog preserve=yes
//## end module%4ACBA118023A.epilog
