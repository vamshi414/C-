//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%5059C94F0214.cm preserve=no
//	$Date:   Apr 17 2014 21:06:02  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%5059C94F0214.cm

//## begin module%5059C94F0214.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5059C94F0214.cp

//## Module: CXOSCF63%5059C94F0214; Package body
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXOSCF63.cpp

//## begin module%5059C94F0214.additionalIncludes preserve=no
//## end module%5059C94F0214.additionalIncludes

//## begin module%5059C94F0214.includes preserve=yes
//## end module%5059C94F0214.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF63_h
#include "CXODCF63.hpp"
#endif


//## begin module%5059C94F0214.declarations preserve=no
//## end module%5059C94F0214.declarations

//## begin module%5059C94F0214.additionalDeclarations preserve=yes
//## end module%5059C94F0214.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

// Class configuration::VisaResponseCode 

VisaResponseCode::VisaResponseCode()
  //## begin VisaResponseCode::VisaResponseCode%5059C2280182_const.hasinit preserve=no
  //## end VisaResponseCode::VisaResponseCode%5059C2280182_const.hasinit
  //## begin VisaResponseCode::VisaResponseCode%5059C2280182_const.initialization preserve=yes
   : ConversionItem("## CR97 XLATE VISA RESP CODE")
  //## end VisaResponseCode::VisaResponseCode%5059C2280182_const.initialization
{
  //## begin configuration::VisaResponseCode::VisaResponseCode%5059C2280182_const.body preserve=yes
   memcpy(m_sID,"CF63",4);
  //## end configuration::VisaResponseCode::VisaResponseCode%5059C2280182_const.body
}


VisaResponseCode::~VisaResponseCode()
{
  //## begin configuration::VisaResponseCode::~VisaResponseCode%5059C2280182_dest.body preserve=yes
  //## end configuration::VisaResponseCode::~VisaResponseCode%5059C2280182_dest.body
}



//## Other Operations (implementation)
void VisaResponseCode::bind (reusable::Query& hQuery)
{
  //## begin configuration::VisaResponseCode::bind%5059C27803B7.body preserve=yes
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.setQualifier("QUALIFY","X_VISA_RESP_CODE");
   hQuery.bind("X_VISA_RESP_CODE","VISA_RESP_CODE",Column::STRING,&m_strFirst);
   hQuery.bind("X_VISA_RESP_CODE","ACTION_CODE",Column::STRING,&m_strSecond);
   hQuery.setBasicPredicate("X_VISA_RESP_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("X_VISA_RESP_CODE","CC_STATE","=","A");
   string strTemp = "('" + strCUST_ID + "','****')";
   hQuery.setBasicPredicate("X_VISA_RESP_CODE","CUST_ID","IN",strTemp.c_str());
   hQuery.setOrderByClause("X_VISA_RESP_CODE.VISA_RESP_CODE ASC,X_VISA_RESP_CODE.CUST_ID DESC");
  //## end configuration::VisaResponseCode::bind%5059C27803B7.body
}

// Additional Declarations
  //## begin configuration::VisaResponseCode%5059C2280182.declarations preserve=yes
  //## end configuration::VisaResponseCode%5059C2280182.declarations

} // namespace configuration

//## begin module%5059C94F0214.epilog preserve=yes
//## end module%5059C94F0214.epilog
