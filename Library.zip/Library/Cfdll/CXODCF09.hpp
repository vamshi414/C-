//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%391BFDC50049.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%391BFDC50049.cm

//## begin module%391BFDC50049.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%391BFDC50049.cp

//## Module: CXOSCF09%391BFDC50049; Package specification
//## Subsystem: CFDLL%390F350302D4
//## Source file: C:\Devel\Dn\Server\Library\Cfdll\CXODCF09.hpp

#ifndef CXOSCF09_h
#define CXOSCF09_h 1

//## begin module%391BFDC50049.additionalIncludes preserve=no
//## end module%391BFDC50049.additionalIncludes

//## begin module%391BFDC50049.includes preserve=yes
// $Date:   Apr 08 2004 14:10:50  $ $Author:   D02405  $ $Revision:   1.5  $
//## end module%391BFDC50049.includes

#ifndef CXOSCF05_h
#include "CXODCF05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%391BFDC50049.declarations preserve=no
//## end module%391BFDC50049.declarations

//## begin module%391BFDC50049.additionalDeclarations preserve=yes
//## end module%391BFDC50049.additionalDeclarations


//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
//## begin configuration%390F33ED01BC.initialDeclarations preserve=yes
//## end configuration%390F33ED01BC.initialDeclarations

//## begin configuration::AdvantageProcessCode%391C2D4C00DA.preface preserve=yes
//## end configuration::AdvantageProcessCode%391C2D4C00DA.preface

//## Class: AdvantageProcessCode%391C2D4C00DA
//## Category: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
//## Subsystem: CFDLL%390F350302D4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%391C2DA70149;IF::Extract { -> F}
//## Uses: <unnamed>%391C2DA9016A;reusable::Query { -> F}

class DllExport AdvantageProcessCode : public ConversionItem  //## Inherits: <unnamed>%391C2D7300D6
{
  //## begin configuration::AdvantageProcessCode%391C2D4C00DA.initialDeclarations preserve=yes
  //## end configuration::AdvantageProcessCode%391C2D4C00DA.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageProcessCode();

    //## Destructor (generated)
      virtual ~AdvantageProcessCode();


    //## Other Operations (specified)
      //## Operation: bind%391C2DE8032D
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>MS
      //	<h3>Configure Advantage Process Code table
      //	<p>
      //	The Advantage Process Code table (&qualify.X_ADV_PROC_
      //	CODE) is used to determine a value for the transaction
      //	type identifier (&custqual.FIN_Lyyyymm.TRAN_TYPE_ID)
      //	during financial transaction loading.
      //	<p>
      //	The Advantage Process Code table is populated during
      //	initial server installation.  Use the CR Editor to add
      //	or update rows whenever the eFunds Advantage acquiring
      //	platform introduces new values in any of the following
      //	columns:
      //	<ul>
      //	<li>PROC^CODE (1)
      //	<li>MTI.CLASS (1)
      //	<li>ACCT^QUAL^1 (1)
      //	<li>PROCESSING^FLAG[1].<9> (1)
      //	<li>PROCESSING^FLAG[1].<10> (1)
      //	</ul>
      //	</body>
      virtual void bind (Query& hQuery);

      //## Operation: getFirst%391C2DE80373
      virtual const string& getFirst ();

      //## Operation: getSecond%3920521C03B1
      virtual const string& getSecond ();

    // Additional Public Declarations
      //## begin configuration::AdvantageProcessCode%391C2D4C00DA.public preserve=yes
      //## end configuration::AdvantageProcessCode%391C2D4C00DA.public

  protected:
    // Additional Protected Declarations
      //## begin configuration::AdvantageProcessCode%391C2D4C00DA.protected preserve=yes
      //## end configuration::AdvantageProcessCode%391C2D4C00DA.protected

  private:
    // Additional Private Declarations
      //## begin configuration::AdvantageProcessCode%391C2D4C00DA.private preserve=yes
      //## end configuration::AdvantageProcessCode%391C2D4C00DA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ADVG_PROCESS_CODE%391C2D7602D9
      //## begin configuration::AdvantageProcessCode::ADVG_PROCESS_CODE%391C2D7602D9.attr preserve=no  private: string {U} 
      string m_strADVG_PROCESS_CODE;
      //## end configuration::AdvantageProcessCode::ADVG_PROCESS_CODE%391C2D7602D9.attr

      //## Attribute: ADVG_MSG_CLASS%391C2D76030B
      //## begin configuration::AdvantageProcessCode::ADVG_MSG_CLASS%391C2D76030B.attr preserve=no  private: string {U} 
      string m_strADVG_MSG_CLASS;
      //## end configuration::AdvantageProcessCode::ADVG_MSG_CLASS%391C2D76030B.attr

      //## Attribute: ADVG_PRE_AUTH%391C2D760329
      //## begin configuration::AdvantageProcessCode::ADVG_PRE_AUTH%391C2D760329.attr preserve=no  private: string {U} 
      string m_strADVG_PRE_AUTH;
      //## end configuration::AdvantageProcessCode::ADVG_PRE_AUTH%391C2D760329.attr

      //## Attribute: ADVG_ACCT_QUAL_1%391C2D760383
      //## begin configuration::AdvantageProcessCode::ADVG_ACCT_QUAL_1%391C2D760383.attr preserve=no  private: string {U} 
      string m_strADVG_ACCT_QUAL_1;
      //## end configuration::AdvantageProcessCode::ADVG_ACCT_QUAL_1%391C2D760383.attr

      //## Attribute: ADVG_TRAN_DESC%391C2D7603DE
      //## begin configuration::AdvantageProcessCode::ADVG_TRAN_DESC%391C2D7603DE.attr preserve=no  private: string {U} 
      string m_strADVG_TRAN_DESC;
      //## end configuration::AdvantageProcessCode::ADVG_TRAN_DESC%391C2D7603DE.attr

      //## Attribute: PROCESS_CODE%391C2D77001E
      //## begin configuration::AdvantageProcessCode::PROCESS_CODE%391C2D77001E.attr preserve=no  private: string {U} 
      string m_strPROCESS_CODE;
      //## end configuration::AdvantageProcessCode::PROCESS_CODE%391C2D77001E.attr

      //## Attribute: MSG_CLASS%391C2D770046
      //## begin configuration::AdvantageProcessCode::MSG_CLASS%391C2D770046.attr preserve=no  private: string {U} 
      string m_strMSG_CLASS;
      //## end configuration::AdvantageProcessCode::MSG_CLASS%391C2D770046.attr

      //## Attribute: PRE_AUTH%391C2D770096
      //## begin configuration::AdvantageProcessCode::PRE_AUTH%391C2D770096.attr preserve=no  private: string {U} 
      string m_strPRE_AUTH;
      //## end configuration::AdvantageProcessCode::PRE_AUTH%391C2D770096.attr

      //## Attribute: MEDIA_TYPE%3920520B0167
      //## begin configuration::AdvantageProcessCode::MEDIA_TYPE%3920520B0167.attr preserve=no  private: string {U} 
      string m_strMEDIA_TYPE;
      //## end configuration::AdvantageProcessCode::MEDIA_TYPE%3920520B0167.attr

    // Additional Implementation Declarations
      //## begin configuration::AdvantageProcessCode%391C2D4C00DA.implementation preserve=yes
      //## end configuration::AdvantageProcessCode%391C2D4C00DA.implementation

};

//## begin configuration::AdvantageProcessCode%391C2D4C00DA.postscript preserve=yes
//## end configuration::AdvantageProcessCode%391C2D4C00DA.postscript

} // namespace configuration

//## begin module%391BFDC50049.epilog preserve=yes
using namespace configuration;
//## end module%391BFDC50049.epilog


#endif
