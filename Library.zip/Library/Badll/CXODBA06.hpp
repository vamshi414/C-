//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%44328FBB0251.cm preserve=no
//	$Date:   Aug 18 2009 16:29:28  $ $Author:   D93545  $
//	$Revision:   1.5  $
//## end module%44328FBB0251.cm

//## begin module%44328FBB0251.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%44328FBB0251.cp

//## Module: CXOSBA06%44328FBB0251; Package specification
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\Devel\Dn\Server\Library\BADLL\CXODBA06.hpp

#ifndef CXOSBA06_h
#define CXOSBA06_h 1

//## begin module%44328FBB0251.additionalIncludes preserve=no
//## end module%44328FBB0251.additionalIncludes

//## begin module%44328FBB0251.includes preserve=yes
//## end module%44328FBB0251.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
//## begin module%44328FBB0251.declarations preserve=no
//## end module%44328FBB0251.declarations

//## begin module%44328FBB0251.additionalDeclarations preserve=yes
//## end module%44328FBB0251.additionalDeclarations


//## Modelname: Platform \: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

//## begin bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.preface preserve=yes
//## end bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.preface

//## Class: BAMSExceptionImportSegment%44328F4A034B
//## Category: Platform \: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
//## Subsystem: BADLL%4421755F0157
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport BAMSExceptionImportSegment : public segment::Segment  //## Inherits: <unnamed>%44328F950280
{
  //## begin bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.initialDeclarations preserve=yes
  //## end bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.initialDeclarations

  public:
    //## Constructors (generated)
      BAMSExceptionImportSegment();

    //## Destructor (generated)
      virtual ~BAMSExceptionImportSegment();


    //## Other Operations (specified)
      //## Operation: fields%4432BE3002BF
      virtual struct  Fields* fields () const;

      //## Operation: incrementArbitrationMCCount%4983282502FD
      void incrementArbitrationMCCount ()
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::incrementArbitrationMCCount%4983282502FD.body preserve=yes
         m_iArbitrationMCCount++;
        //## end bamsprocessing::BAMSExceptionImportSegment::incrementArbitrationMCCount%4983282502FD.body
      }

      //## Operation: incrementArbitrationVisaCount%49832836033C
      void incrementArbitrationVisaCount ()
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::incrementArbitrationVisaCount%49832836033C.body preserve=yes
         m_iArbitrationVisaCount++;
        //## end bamsprocessing::BAMSExceptionImportSegment::incrementArbitrationVisaCount%49832836033C.body
      }

      //## Operation: increment2ndChargebackCount%44EB3B7602AF
      void increment2ndChargebackCount ()
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::increment2ndChargebackCount%44EB3B7602AF.body preserve=yes
         m_iChargeback2Count++;
        //## end bamsprocessing::BAMSExceptionImportSegment::increment2ndChargebackCount%44EB3B7602AF.body
      }

      //## Operation: incrementChargebackCount%443291F00280
      void incrementChargebackCount ()
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::incrementChargebackCount%443291F00280.body preserve=yes
         m_iChargebackCount++;
        //## end bamsprocessing::BAMSExceptionImportSegment::incrementChargebackCount%443291F00280.body
      }

      //## Operation: incrementErrorsCount%4433D18E00CB
      void incrementErrorsCount ()
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::incrementErrorsCount%4433D18E00CB.body preserve=yes
         m_iTotalErrors++;
        //## end bamsprocessing::BAMSExceptionImportSegment::incrementErrorsCount%4433D18E00CB.body
      }

      //## Operation: incrementRecordNo%443403EA01D4
      void incrementRecordNo ()
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::incrementRecordNo%443403EA01D4.body preserve=yes
         m_iRecordNo++;
        //## end bamsprocessing::BAMSExceptionImportSegment::incrementRecordNo%443403EA01D4.body
      }

      //## Operation: incrementRejectCount%45BA1C890177
      void incrementRejectCount ()
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::incrementRejectCount%45BA1C890177.body preserve=yes
         m_iRejectCount++;
        //## end bamsprocessing::BAMSExceptionImportSegment::incrementRejectCount%45BA1C890177.body
      }

      //## Operation: incrementRepresentmentCount%45BA1C950203
      void incrementRepresentmentCount ()
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::incrementRepresentmentCount%45BA1C950203.body preserve=yes
         m_iRepresentmentCount++;
        //## end bamsprocessing::BAMSExceptionImportSegment::incrementRepresentmentCount%45BA1C950203.body
      }

      //## Operation: incrementRetReqCount%443291E1030D
      void incrementRetReqCount ()
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::incrementRetReqCount%443291E1030D.body preserve=yes
         m_iRetReqCount++;
        //## end bamsprocessing::BAMSExceptionImportSegment::incrementRetReqCount%443291E1030D.body
      }

      //## Operation: incrementReversalCount%44EB3B95036B
      void incrementReversalCount ()
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::incrementReversalCount%44EB3B95036B.body preserve=yes
         m_iReversalCount++;
        //## end bamsprocessing::BAMSExceptionImportSegment::incrementReversalCount%44EB3B95036B.body
      }

      //## Operation: incrementTotalCount%443291FC031C
      void incrementTotalCount ()
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::incrementTotalCount%443291FC031C.body preserve=yes
         m_iTotalCases++;
        //## end bamsprocessing::BAMSExceptionImportSegment::incrementTotalCount%443291FC031C.body
      }

      //## Operation: resetCounts%4432923501F4
      void resetCounts ()
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::resetCounts%4432923501F4.body preserve=yes
         m_iArbitrationMCCount = 0;
         m_iArbitrationVisaCount = 0;
         m_iChargebackCount = 0;
         m_iChargeback2Count = 0;
         m_iRejectCount = 0;
         m_iRepresentmentCount = 0;
         m_iRetReqCount = 0;
         m_iReversalCount = 0;
         m_iRecordNo = 0;
         m_iTotalErrors = 0;
         m_iTotalCases = 0;
        //## end bamsprocessing::BAMSExceptionImportSegment::resetCounts%4432923501F4.body
      }

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ErrorText%443BD0430242
      const string& getErrorText () const
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::getErrorText%443BD0430242.get preserve=no
        return m_strErrorText;
        //## end bamsprocessing::BAMSExceptionImportSegment::getErrorText%443BD0430242.get
      }

      void setErrorText (const string& value)
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::setErrorText%443BD0430242.set preserve=no
        m_strErrorText = value;
        //## end bamsprocessing::BAMSExceptionImportSegment::setErrorText%443BD0430242.set
      }


      //## Attribute: File%4432AE3000FA
      const string& getFile () const
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::getFile%4432AE3000FA.get preserve=no
        return m_strFile;
        //## end bamsprocessing::BAMSExceptionImportSegment::getFile%4432AE3000FA.get
      }

      void setFile (const string& value)
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::setFile%4432AE3000FA.set preserve=no
        m_strFile = value;
        //## end bamsprocessing::BAMSExceptionImportSegment::setFile%4432AE3000FA.set
      }


      //## Attribute: Path%4433F5520280
      const string& getPath () const
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::getPath%4433F5520280.get preserve=no
        return m_strPath;
        //## end bamsprocessing::BAMSExceptionImportSegment::getPath%4433F5520280.get
      }

      void setPath (const string& value)
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::setPath%4433F5520280.set preserve=no
        m_strPath = value;
        //## end bamsprocessing::BAMSExceptionImportSegment::setPath%4433F5520280.set
      }


      //## Attribute: RunTime%4433F42002CE
      const string& getRunTime () const
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::getRunTime%4433F42002CE.get preserve=no
        return m_strRunTime;
        //## end bamsprocessing::BAMSExceptionImportSegment::getRunTime%4433F42002CE.get
      }

      void setRunTime (const string& value)
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::setRunTime%4433F42002CE.set preserve=no
        m_strRunTime = value;
        //## end bamsprocessing::BAMSExceptionImportSegment::setRunTime%4433F42002CE.set
      }


      //## Attribute: TransactionID%47FA7B3F0138
      const string& getTransactionID () const
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::getTransactionID%47FA7B3F0138.get preserve=no
        return m_strTransactionID;
        //## end bamsprocessing::BAMSExceptionImportSegment::getTransactionID%47FA7B3F0138.get
      }

      void setTransactionID (const string& value)
      {
        //## begin bamsprocessing::BAMSExceptionImportSegment::setTransactionID%47FA7B3F0138.set preserve=no
        m_strTransactionID = value;
        //## end bamsprocessing::BAMSExceptionImportSegment::setTransactionID%47FA7B3F0138.set
      }


    // Additional Public Declarations
      //## begin bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.public preserve=yes
      //## end bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.public

  protected:
    // Additional Protected Declarations
      //## begin bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.protected preserve=yes
      //## end bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.protected

  private:
    // Additional Private Declarations
      //## begin bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.private preserve=yes
      //## end bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ArbitrationMCCount%498327EC02CE
      //## begin bamsprocessing::BAMSExceptionImportSegment::ArbitrationMCCount%498327EC02CE.attr preserve=no  private: int {U} 0
      int m_iArbitrationMCCount;
      //## end bamsprocessing::BAMSExceptionImportSegment::ArbitrationMCCount%498327EC02CE.attr

      //## Attribute: ArbitrationVisaCount%498327F7034B
      //## begin bamsprocessing::BAMSExceptionImportSegment::ArbitrationVisaCount%498327F7034B.attr preserve=no  private: int {U} 0
      int m_iArbitrationVisaCount;
      //## end bamsprocessing::BAMSExceptionImportSegment::ArbitrationVisaCount%498327F7034B.attr

      //## Attribute: ChargebackCount%443291C903D8
      //## begin bamsprocessing::BAMSExceptionImportSegment::ChargebackCount%443291C903D8.attr preserve=no  private: int {U} 0
      int m_iChargebackCount;
      //## end bamsprocessing::BAMSExceptionImportSegment::ChargebackCount%443291C903D8.attr

      //## Attribute: Chargeback2Count%44EB3B3A0109
      //## begin bamsprocessing::BAMSExceptionImportSegment::Chargeback2Count%44EB3B3A0109.attr preserve=no  private: int {U} 0
      int m_iChargeback2Count;
      //## end bamsprocessing::BAMSExceptionImportSegment::Chargeback2Count%44EB3B3A0109.attr

      //## begin bamsprocessing::BAMSExceptionImportSegment::ErrorText%443BD0430242.attr preserve=no  public: string {U} 
      string m_strErrorText;
      //## end bamsprocessing::BAMSExceptionImportSegment::ErrorText%443BD0430242.attr

      //## begin bamsprocessing::BAMSExceptionImportSegment::File%4432AE3000FA.attr preserve=no  public: string {U} 
      string m_strFile;
      //## end bamsprocessing::BAMSExceptionImportSegment::File%4432AE3000FA.attr

      //## begin bamsprocessing::BAMSExceptionImportSegment::Path%4433F5520280.attr preserve=no  public: string {U} 
      string m_strPath;
      //## end bamsprocessing::BAMSExceptionImportSegment::Path%4433F5520280.attr

      //## Attribute: RecordNo%4434038A000F
      //## begin bamsprocessing::BAMSExceptionImportSegment::RecordNo%4434038A000F.attr preserve=no  private: int {U} 0
      int m_iRecordNo;
      //## end bamsprocessing::BAMSExceptionImportSegment::RecordNo%4434038A000F.attr

      //## Attribute: RejectCount%45BA1C5901D4
      //## begin bamsprocessing::BAMSExceptionImportSegment::RejectCount%45BA1C5901D4.attr preserve=no  private: int {U} 0
      int m_iRejectCount;
      //## end bamsprocessing::BAMSExceptionImportSegment::RejectCount%45BA1C5901D4.attr

      //## Attribute: RepresentmentCount%45BA1C0403B9
      //## begin bamsprocessing::BAMSExceptionImportSegment::RepresentmentCount%45BA1C0403B9.attr preserve=no  private: int {U} 0
      int m_iRepresentmentCount;
      //## end bamsprocessing::BAMSExceptionImportSegment::RepresentmentCount%45BA1C0403B9.attr

      //## Attribute: RetReqCount%443291A50242
      //## begin bamsprocessing::BAMSExceptionImportSegment::RetReqCount%443291A50242.attr preserve=no  private: int {U} 0
      int m_iRetReqCount;
      //## end bamsprocessing::BAMSExceptionImportSegment::RetReqCount%443291A50242.attr

      //## Attribute: ReversalCount%44EB3B2A0271
      //## begin bamsprocessing::BAMSExceptionImportSegment::ReversalCount%44EB3B2A0271.attr preserve=no  private: int {U} 0
      int m_iReversalCount;
      //## end bamsprocessing::BAMSExceptionImportSegment::ReversalCount%44EB3B2A0271.attr

      //## begin bamsprocessing::BAMSExceptionImportSegment::RunTime%4433F42002CE.attr preserve=no  public: string {U} 
      string m_strRunTime;
      //## end bamsprocessing::BAMSExceptionImportSegment::RunTime%4433F42002CE.attr

      //## Attribute: TotalCases%443291D5029F
      //## begin bamsprocessing::BAMSExceptionImportSegment::TotalCases%443291D5029F.attr preserve=no  private: int {U} 0
      int m_iTotalCases;
      //## end bamsprocessing::BAMSExceptionImportSegment::TotalCases%443291D5029F.attr

      //## Attribute: TotalErrors%4433D14F036B
      //## begin bamsprocessing::BAMSExceptionImportSegment::TotalErrors%4433D14F036B.attr preserve=no  private: int {U} 0
      int m_iTotalErrors;
      //## end bamsprocessing::BAMSExceptionImportSegment::TotalErrors%4433D14F036B.attr

      //## begin bamsprocessing::BAMSExceptionImportSegment::TransactionID%47FA7B3F0138.attr preserve=no  public: string {U} 
      string m_strTransactionID;
      //## end bamsprocessing::BAMSExceptionImportSegment::TransactionID%47FA7B3F0138.attr

    // Additional Implementation Declarations
      //## begin bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.implementation preserve=yes
      //## end bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.implementation

};

//## begin bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.postscript preserve=yes
//## end bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.postscript

} // namespace bamsprocessing

//## begin module%44328FBB0251.epilog preserve=yes
//## end module%44328FBB0251.epilog


#endif
