//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%44328FBC03A9.cm preserve=no
//	$Date:   Aug 18 2009 16:29:30  $ $Author:   D93545  $
//	$Revision:   1.6  $
//## end module%44328FBC03A9.cm

//## begin module%44328FBC03A9.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%44328FBC03A9.cp

//## Module: CXOSBA06%44328FBC03A9; Package body
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\Devel\Dn\Server\Library\BADLL\CXOSBA06.cpp

//## begin module%44328FBC03A9.additionalIncludes preserve=no
//## end module%44328FBC03A9.additionalIncludes

//## begin module%44328FBC03A9.includes preserve=yes
//## end module%44328FBC03A9.includes

#ifndef CXOSBA06_h
#include "CXODBA06.hpp"
#endif
//## begin module%44328FBC03A9.declarations preserve=no
//## end module%44328FBC03A9.declarations

//## begin module%44328FBC03A9.additionalDeclarations preserve=yes
#define FIELDS 16
Fields BAMSExceptionImportSegment_Fields[FIELDS + 1] = 
{
   "l         ","ArbitrationMCCount",0,0,
   "l         ","ArbitrationVisaCount",0,0,
   "l         ","ChargebackCount",0,0,
   "l         ","Chargeback2Count",0,0,
   "a         ","ErrorText",0,0,
   "a         ","File",0,0,
   "a         ","Path",0,0,
   "l         ","RecordNo",0,0,
   "l         ","RejectCount",0,0,
   "l         ","RepresentmentCount",0,0,
   "l         ","RetReqCount",0,0,
   "l         ","ReversalCount",0,0,
   "a         ","RunTime",0,0,
   "l         ","TotalErrors",0,0,
   "l         ","TotalCases",0,0,
   "a         ","TransactionID",0,0,
   "~","~",0,0,
};
//## end module%44328FBC03A9.additionalDeclarations


//## Modelname: Platform \: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

// Class bamsprocessing::BAMSExceptionImportSegment 

BAMSExceptionImportSegment::BAMSExceptionImportSegment()
  //## begin BAMSExceptionImportSegment::BAMSExceptionImportSegment%44328F4A034B_const.hasinit preserve=no
      : m_iArbitrationMCCount(0),
        m_iArbitrationVisaCount(0),
        m_iChargebackCount(0),
        m_iChargeback2Count(0),
        m_iRecordNo(0),
        m_iRejectCount(0),
        m_iRepresentmentCount(0),
        m_iRetReqCount(0),
        m_iReversalCount(0),
        m_iTotalCases(0),
        m_iTotalErrors(0)
  //## end BAMSExceptionImportSegment::BAMSExceptionImportSegment%44328F4A034B_const.hasinit
  //## begin BAMSExceptionImportSegment::BAMSExceptionImportSegment%44328F4A034B_const.initialization preserve=yes
  //## end BAMSExceptionImportSegment::BAMSExceptionImportSegment%44328F4A034B_const.initialization
{
  //## begin bamsprocessing::BAMSExceptionImportSegment::BAMSExceptionImportSegment%44328F4A034B_const.body preserve=yes
   memcpy(m_sID,"BA06",4);
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_iArbitrationMCCount;
   m_pField[1] = &m_iArbitrationVisaCount;
   m_pField[2] = &m_iChargebackCount;
   m_pField[3] = &m_iChargeback2Count;
   m_pField[4] = &m_strErrorText;
   m_pField[5] = &m_strFile;
   m_pField[6] = &m_strPath;
   m_pField[7] = &m_iRecordNo;
   m_pField[8] = &m_iRejectCount;
   m_pField[9] = &m_iRepresentmentCount;
   m_pField[10] = &m_iRetReqCount;
   m_pField[11] = &m_iReversalCount;
   m_pField[12] = &m_strRunTime;
   m_pField[13] = &m_iTotalErrors;
   m_pField[14] = &m_iTotalCases;
   m_pField[15] = &m_strTransactionID;
   m_strErrorText.erase();
  //## end bamsprocessing::BAMSExceptionImportSegment::BAMSExceptionImportSegment%44328F4A034B_const.body
}


BAMSExceptionImportSegment::~BAMSExceptionImportSegment()
{
  //## begin bamsprocessing::BAMSExceptionImportSegment::~BAMSExceptionImportSegment%44328F4A034B_dest.body preserve=yes
   delete [] m_pField;
  //## end bamsprocessing::BAMSExceptionImportSegment::~BAMSExceptionImportSegment%44328F4A034B_dest.body
}



//## Other Operations (implementation)
struct  Fields* BAMSExceptionImportSegment::fields () const
{
  //## begin bamsprocessing::BAMSExceptionImportSegment::fields%4432BE3002BF.body preserve=yes
   return &BAMSExceptionImportSegment_Fields[0];
  //## end bamsprocessing::BAMSExceptionImportSegment::fields%4432BE3002BF.body
}

// Additional Declarations
  //## begin bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.declarations preserve=yes
  //## end bamsprocessing::BAMSExceptionImportSegment%44328F4A034B.declarations

} // namespace bamsprocessing

//## begin module%44328FBC03A9.epilog preserve=yes
//## end module%44328FBC03A9.epilog
