//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%442185050222.cm preserve=no
//	$Date:   May 21 2020 20:25:18  $ $Author:   e1009510  $
//	$Revision:   1.30  $
//## end module%442185050222.cm

//## begin module%442185050222.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%442185050222.cp

//## Module: CXOSBA02%442185050222; Package body
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\bV02.7A.R001\Windows\Build\Dn\Server\Library\Badll\CXOSBA02.cpp

//## begin module%442185050222.additionalIncludes preserve=no
//## end module%442185050222.additionalIncludes

//## begin module%442185050222.includes preserve=yes
#include "CXODIF03.hpp"
//## end module%442185050222.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSBC20_h
#include "CXODBC20.hpp"
#endif
#ifndef CXOSBA02_h
#include "CXODBA02.hpp"
#endif


//## begin module%442185050222.declarations preserve=no
//## end module%442185050222.declarations

//## begin module%442185050222.additionalDeclarations preserve=yes
//## end module%442185050222.additionalDeclarations


//## Modelname: Platform \: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

// Class bamsprocessing::BAMSExceptionHandler 

BAMSExceptionHandler::BAMSExceptionHandler()
  //## begin BAMSExceptionHandler::BAMSExceptionHandler%4421843D03C8_const.hasinit preserve=no
  //## end BAMSExceptionHandler::BAMSExceptionHandler%4421843D03C8_const.hasinit
  //## begin BAMSExceptionHandler::BAMSExceptionHandler%4421843D03C8_const.initialization preserve=yes
  //## end BAMSExceptionHandler::BAMSExceptionHandler%4421843D03C8_const.initialization
{
  //## begin bamsprocessing::BAMSExceptionHandler::BAMSExceptionHandler%4421843D03C8_const.body preserve=yes
  //## end bamsprocessing::BAMSExceptionHandler::BAMSExceptionHandler%4421843D03C8_const.body
}


BAMSExceptionHandler::~BAMSExceptionHandler()
{
  //## begin bamsprocessing::BAMSExceptionHandler::~BAMSExceptionHandler%4421843D03C8_dest.body preserve=yes
  //## end bamsprocessing::BAMSExceptionHandler::~BAMSExceptionHandler%4421843D03C8_dest.body
}



//## Other Operations (implementation)
void BAMSExceptionHandler::characters (const XMLCh* const chars, const XMLSIZE length)
{
  //## begin bamsprocessing::BAMSExceptionHandler::characters%44218B3203B9.body preserve=yes
   if(getAbort())
      return;
   getToken("BAMSExceptionHandler::characters ",chars,length);
   if (m_strToken.length() == 0)
      return;
   m_hBAMSException.appendACTUAL_MSG(m_strToken);
   if (m_hElement.back() == "CardholderAccount")
      CaseSegment::instance()->setPAN(m_strToken);
   else
   if (m_hElement.back() == "AcqReferenceNumber")
      CaseNationalNetworkSegment::instance()->setACQ_REF_NO(m_strToken);
   else
   if (m_hElement.back() == "RecordType")
   {
      switch (atoi(m_strToken.c_str()))
      {
         case 0: m_hBAMSException.setREQUEST_TYPE("DOCR"); break;
         case 1: m_hBAMSException.setREQUEST_TYPE("CHB1"); break;
         case 2: m_hBAMSException.setREQUEST_TYPE("CHB2"); break;
         case 3: m_hBAMSException.setREQUEST_TYPE("REP1"); break;
         case 4: m_hBAMSException.setREQUEST_TYPE("ARB"); break; //resp to us sending MC pre-arb
         case 5: m_hBAMSException.setREQUEST_TYPE("PARB"); break;
      }
   }
   else
   if (m_hElement.back() == "Purpose")
      m_hBAMSException.setPurpose(atoi(m_strToken.c_str()));
   else
   if (m_hElement.back() == "MerchantNumber")
   {
      m_strToken.erase(0,1);
      CaseSegment::instance()->setCARD_ACPT_TERM_ID(m_strToken);
   }
   else
   if (m_hElement.back() == "CaseNumber")
      m_hBAMSException.setOTHER_CASE_NO(m_strToken);
   else
   if (m_hElement.back() == "TransactionAmount")
      m_hBAMSException.setAMT_TRAN(atof(m_strToken.c_str()));
   else
   if (m_hElement.back() == "ChargebackAmount")
      m_hBAMSException.setAMT_ADJUSTMENT(atof(m_strToken.c_str()));
   else
   if (m_hElement.back() == "CurrencyCode")
      m_hBAMSException.setCUR_ADJUSTMENT(m_strToken);
   else
   if (m_hElement.back() == "RequestID")
      m_hBAMSException.setRETRIEVAL_REQ_ID(m_strToken);
   else
   if (m_hElement.back() == "CardBrand")
   {
      switch (atoi(m_strToken.c_str()))
      {
         case 1: m_hBAMSException.setNET_ID_EMS("VNT"); break;
         case 2: m_hBAMSException.setNET_ID_EMS("MCI"); break;
         case 3: m_hBAMSException.setNET_ID_EMS("MCI"); 
                 CaseSegment::instance()->setNET_ID_ISS("DCC");
                 break; 
      }
   }
   else
   if (m_hElement.back() == "MerchantCategoryCode")
      CaseSegment::instance()->setMERCHANT_CAT_CODE(m_strToken);
   else
   if (m_hElement.back() == "PostDate")
   {
      reformatDate();
      CaseSegment::instance()->setDATE_RECON_NET(m_strToken);
   }
   else
   if (m_hElement.back() == "TransactionDate")
   {
      reformatDate();
      m_strToken += "000000";
      CaseSegment::instance()->setTSTAMP_LOCAL(m_strToken);
   }
   else
   if (m_hElement.back() == "ReceivedDate")
   {
      reformatDate();
      CasePhaseSegment::instance()->setDATE_RECONYYYYMMDD(m_strToken);
      m_hBAMSException.setDateReceived(m_strToken);
   }
   else
   if (m_hElement.back() == "RespondByDate")
   {
      reformatDate();
      m_strToken += "00000000";
      m_hBAMSException.setSTATE_EXPIR_TSTAMP(m_strToken);
   }
   else
   if (m_hElement.back() == "ReasonCode")
      m_hBAMSException.setREASON_CODE(m_strToken);
   else
   if (m_hElement.back() == "MemberMessageBlock")
      m_hBAMSException.setMMT(m_strToken);
   else
   if (m_hElement.back() == "IssuerReferenceNumber")
      m_hBAMSException.setIssuerRefNo(m_strToken);
   else
   if (m_hElement.back() == "TransactionID")
   {
      m_hBAMSException.setTransactionID(m_strToken);
      m_hBAMSExceptionImportSegment.setTransactionID(m_strToken);
   }
   else
   if (m_hElement.back() == "BAMSComment")
      m_hBAMSException.setCommentFields(m_strToken);
   else
   if (m_hElement.back() == "PageCount")
   {
      if (atoi(m_strToken.c_str()) > 0)
         m_hBAMSException.setDocumentPresence();
   }
  //## end bamsprocessing::BAMSExceptionHandler::characters%44218B3203B9.body
}

void BAMSExceptionHandler::endDocument ()
{
  //## begin bamsprocessing::BAMSExceptionHandler::endDocument%44218B3503C8.body preserve=yes
   Trace::put("BAMSExceptionHandler::endDocument");
   if (m_pAudit)
   {
      m_pAudit->report('T');
      m_pAudit->complete();
      delete m_pAudit;
      m_pAudit = 0;
   }
  //## end bamsprocessing::BAMSExceptionHandler::endDocument%44218B3503C8.body
}

void BAMSExceptionHandler::endElement (const XMLCh* const name)
{
  //## begin bamsprocessing::BAMSExceptionHandler::endElement%44218B3801F4.body preserve=yes
   if(getAbort())
      return;

   getToken("BAMSExceptionHandler::endElement ",name,XMLString::stringLen(name));
   m_hBAMSException.appendACTUAL_MSG("</");
   m_hBAMSException.appendACTUAL_MSG(m_strToken);
   m_hBAMSException.appendACTUAL_MSG(">");
   if (m_strToken == "BAMSChargebackRecord")
   {
      bool bReturn = m_hBAMSException.processCase();
      m_hCaseSegment = *(CaseSegment::instance());
      m_hCasePhaseSegment = *(CasePhaseSegment::instance());
      m_hCaseNationalNetworkSegment = *(CaseNationalNetworkSegment::instance());
      m_hCaseTransitionSegment = *(CaseTransitionSegment::instance());
      m_hBAMSExceptionImportSegment.incrementRecordNo();
      if (bReturn)
      {
         if (m_hBAMSException.getPurpose() == 3)
            m_hBAMSExceptionImportSegment.incrementRejectCount();
         if (CaseSegment::instance()->getREQUEST_TYPE() == "DOCR")
            m_hBAMSExceptionImportSegment.incrementRetReqCount();
         else if (CaseSegment::instance()->getREQUEST_TYPE() == "CHB1")
            m_hBAMSExceptionImportSegment.incrementChargebackCount();
         else if (CaseSegment::instance()->getREQUEST_TYPE() == "CHB2")
            m_hBAMSExceptionImportSegment.increment2ndChargebackCount();
         else if (CaseSegment::instance()->getREQUEST_TYPE() == "REP1")
            m_hBAMSExceptionImportSegment.incrementRepresentmentCount();
         else if (CaseSegment::instance()->getREQUEST_TYPE() == "PARB")
            m_hBAMSExceptionImportSegment.incrementArbitrationVisaCount();
         else if (CaseSegment::instance()->getREQUEST_TYPE() == "ARB")
            m_hBAMSExceptionImportSegment.incrementArbitrationMCCount();
         m_pAudit->report('S');
         Database::instance()->commit();
      }
      else
      {
         Database::instance()->rollback();
         m_hBAMSExceptionImportSegment.setErrorText(m_hBAMSException.getErrorText());
         m_pAudit->report('F');
         m_hBAMSExceptionImportSegment.incrementErrorsCount();
         Database::instance()->commit();
      }
      m_hBAMSExceptionImportSegment.incrementTotalCount();
   }
   m_hElement.pop_back();
  //## end bamsprocessing::BAMSExceptionHandler::endElement%44218B3801F4.body
}

void BAMSExceptionHandler::error (const SAXParseException& exc)
{
  //## begin bamsprocessing::BAMSExceptionHandler::error%44218B3B006D.body preserve=yes
   char szBuffer[64];
   Trace::put(szBuffer,Object::snprintf(szBuffer,sizeof(szBuffer),"BAMSExceptionHandler::error line %d column %d",(int)exc.getLineNumber(),(int)exc.getColumnNumber()));
   UseCase::setSuccess(false);
  //## end bamsprocessing::BAMSExceptionHandler::error%44218B3B006D.body
}

void BAMSExceptionHandler::fatalError (const SAXParseException& exc)
{
  //## begin bamsprocessing::BAMSExceptionHandler::fatalError%44218B3E0148.body preserve=yes
   char szBuffer[70];
   Trace::put(szBuffer,Object::snprintf(szBuffer,sizeof(szBuffer),"BAMSExceptionHandler::fatalError line %d column %d",(int)exc.getLineNumber(),(int)exc.getColumnNumber()));
   getToken("BAMSExceptionHandler::fatalError ",exc.getMessage(),XMLString::stringLen(exc.getMessage()));
   UseCase::setSuccess(false);
  //## end bamsprocessing::BAMSExceptionHandler::fatalError%44218B3E0148.body
}

bool BAMSExceptionHandler::getDOC_PATH (int iPath, int iIndex, string& strDOC_PATH)
{
  //## begin bamsprocessing::BAMSExceptionHandler::getDOC_PATH%44218B420148.body preserve=yes
   return false;
  //## end bamsprocessing::BAMSExceptionHandler::getDOC_PATH%44218B420148.body
}

bool BAMSExceptionHandler::initializeAudit (const string& strGENNAM, const string& strPath)
{
  //## begin bamsprocessing::BAMSExceptionHandler::initializeAudit%4432A76403C8.body preserve=yes
   m_hBAMSExceptionImportSegment.resetCounts();
   m_pAudit = new Audit("BAMSA2","AP",Customer::instance()->getCUST_ID(),Transaction::instance()->getTimeStamp().substr(0,8),"235959");
   m_hBAMSExceptionImportSegment.setFile(strGENNAM);
   m_hBAMSExceptionImportSegment.setPath(strPath);
   m_hBAMSExceptionImportSegment.setRunTime(Timestamp::format(Clock::instance()->getYYYYMMDDHHMMSS()));
   const char* pszAudit[] =
   {
      "HException Import from Bank of America",
      "HRun Time:,~I.RunTime.",
      "HFile Processed:,~I.File.",
      "HPath:,~I.Path.",
      "H",
      "HRecord No,Status,Case Number,PAN,Tran Amount,Tran Date"
      ",Chargeback Amount,Reason Code,BAMS Case,Acq Ref Num"
      ",Retrieval Ref Num,Transaction ID,Request Type,Status"
      ",Failed Req Type,Failed Status,Ruleset",
      "S~I.RecordNo.,Success,~C.CASE_NO.,~C.*PAN.,~C.AMT_TRAN.,"
      "~C.TSTAMP_LOCAL.,~P.AMT_ADJUSTMENT.,~P.REASON_CODE.,"
      "~C.OTHER_CASE_NO.,~N.ACQ_REF_NO.,~C.RETRIEVAL_REF_NO.,"
      "~I.TransactionID.,~C.REQUEST_TYPE.,~C.STATUS.",
      "F~I.RecordNo.,Failed,~C.CASE_NO.,~C.*PAN.,~C.AMT_TRAN.,"
      "~C.TSTAMP_LOCAL.,~P.AMT_ADJUSTMENT.,~P.REASON_CODE.,"
      "~C.OTHER_CASE_NO.,~N.ACQ_REF_NO.,~C.RETRIEVAL_REF_NO.,"
      "~I.TransactionID.,~C.REQUEST_TYPE.,~C.STATUS.,"
      "~R.REQUEST_TYPE_NEXT.,~R.STATUS_NEXT.,~C.NET_RULES.",
      "F~I.ErrorText.",
      "T",
      "TRetrieval Requests Processed:,~I.RetReqCount.",
      "TChargebacks Processed:,~I.ChargebackCount.",
      "T2nd Chargebacks Processed:,~I.Chargeback2Count.",
      "TRepresentments Processed:,~I.RepresentmentCount.",
      "TMasterCard Arbitrations Processed:,~I.ArbitrationMCCount.",
      "TVisa Pre-Arbitrations Processed:,~I.ArbitrationVisaCount.",
      "TRejects Processed:,~I.RejectCount.",
      "TTotal Errors:,~I.TotalErrors.",
      "TTotal Cases:,~I.TotalCases.",
      0
   };
   m_pAudit->setTemplate(&pszAudit[0]);
   m_pAudit->add('I',&m_hBAMSExceptionImportSegment);
   m_pAudit->add('C',&m_hCaseSegment);
   m_pAudit->add('P',&m_hCasePhaseSegment);
   m_pAudit->add('N',&m_hCaseNationalNetworkSegment);
   m_pAudit->add('R',&m_hCaseTransitionSegment);
   if (!m_pAudit->report('H'))
   {
      Database::instance()->rollback();
      return true; // !!! ?
   }
   Database::instance()->commit();
   return true;
  //## end bamsprocessing::BAMSExceptionHandler::initializeAudit%4432A76403C8.body
}

void BAMSExceptionHandler::reformatDate ()
{
  //## begin bamsprocessing::BAMSExceptionHandler::reformatDate%458AB97101B5.body preserve=yes
   size_t pos = m_strToken.find_first_of("-");
   while (pos != string::npos) 
   {
      m_strToken.erase(pos,1);
      pos = m_strToken.find_first_of("-");
   }
  //## end bamsprocessing::BAMSExceptionHandler::reformatDate%458AB97101B5.body
}

void BAMSExceptionHandler::startDocument ()
{
  //## begin bamsprocessing::BAMSExceptionHandler::startDocument%44218B45003E.body preserve=yes
   Trace::put("BAMSExceptionHandler::startDocument");
   DNHandlerBase::startDocument();
   m_hBAMSException.initializeListSegment();
  //## end bamsprocessing::BAMSExceptionHandler::startDocument%44218B45003E.body
}

void BAMSExceptionHandler::startElement (const XMLCh* const name, AttributeList& attributes)
{
  //## begin bamsprocessing::BAMSExceptionHandler::startElement%44218B4803A9.body preserve=yes
   if (getAbort())
      return;
   getToken("BAMSExceptionHandler::startElement ",name,XMLString::stringLen(name));
   m_hElement.push_back(m_strToken);
   if (m_strToken == "BAMSChargebackRecord")
      m_hBAMSException.reset();
   m_hBAMSException.appendACTUAL_MSG("<");
   m_hBAMSException.appendACTUAL_MSG(m_strToken);
   m_hBAMSException.appendACTUAL_MSG(">");
  //## end bamsprocessing::BAMSExceptionHandler::startElement%44218B4803A9.body
}

// Additional Declarations
  //## begin bamsprocessing::BAMSExceptionHandler%4421843D03C8.declarations preserve=yes
  //## end bamsprocessing::BAMSExceptionHandler%4421843D03C8.declarations

} // namespace bamsprocessing

//## begin module%442185050222.epilog preserve=yes
//## end module%442185050222.epilog
