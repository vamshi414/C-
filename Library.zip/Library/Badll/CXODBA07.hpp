//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%44A3E2000006.cm preserve=no
//	$Date:   Jul 06 2006 14:16:40  $ $Author:   D92186  $
//	$Revision:   1.2  $
//## end module%44A3E2000006.cm

//## begin module%44A3E2000006.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%44A3E2000006.cp

//## Module: CXOSBA07%44A3E2000006; Package specification
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\Devel\Dn\Server\Library\BADLL\CXODBA07.hpp

#ifndef CXOSBA07_h
#define CXOSBA07_h 1

//## begin module%44A3E2000006.additionalIncludes preserve=no
//## end module%44A3E2000006.additionalIncludes

//## begin module%44A3E2000006.includes preserve=yes
//## end module%44A3E2000006.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseAccountHistorySegment;
class CaseNationalNetworkSegment;
class CasePhaseSegment;
class CaseSegment;
class CaseTransitionSegment;
} // namespace emssegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%44A3E2000006.declarations preserve=no
//## end module%44A3E2000006.declarations

//## begin module%44A3E2000006.additionalDeclarations preserve=yes
//## end module%44A3E2000006.additionalDeclarations


//## Modelname: Processor\: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

//## begin bamsprocessing::ChesapeakeExport%44A3E14602DA.preface preserve=yes
//## end bamsprocessing::ChesapeakeExport%44A3E14602DA.preface

//## Class: ChesapeakeExport%44A3E14602DA
//## Category: Processor\: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
//## Subsystem: BADLL%4421755F0157
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%44A3E1B80252;reusable::Query { -> F}
//## Uses: <unnamed>%44A3E1BA02A5;database::Database { -> F}
//## Uses: <unnamed>%44A3E1BD0028;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%44A3E1C003E4;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%44A3E1C802E1;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%44A3E1D600CE;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%44A3ECA9029F;emssegment::CaseTransitionSegment { -> F}
//## Uses: <unnamed>%44A3ECAF00D1;emssegment::CaseNationalNetworkSegment { -> F}
//## Uses: <unnamed>%44A3ECC800FF;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%44A3EDA40282;emssegment::CaseAccountHistorySegment { -> F}
//## Uses: <unnamed>%44A413A4000A;timer::Clock { -> F}
//## Uses: <unnamed>%44A413A602C9;monitor::UseCase { -> F}
//## Uses: <unnamed>%44A413E5036A;reusable::Statement { -> F}

class DllExport ChesapeakeExport : public database::ExportFile  //## Inherits: <unnamed>%44A3E1960036
{
  //## begin bamsprocessing::ChesapeakeExport%44A3E14602DA.initialDeclarations preserve=yes
  //## end bamsprocessing::ChesapeakeExport%44A3E14602DA.initialDeclarations

  public:
    //## Constructors (generated)
      ChesapeakeExport();

    //## Destructor (generated)
      virtual ~ChesapeakeExport();


    //## Other Operations (specified)
      //## Operation: create%44A3E36D02F0
      virtual bool create ();

      //## Operation: update%44A3E3910342
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin bamsprocessing::ChesapeakeExport%44A3E14602DA.public preserve=yes
      //## end bamsprocessing::ChesapeakeExport%44A3E14602DA.public

  protected:
    // Additional Protected Declarations
      //## begin bamsprocessing::ChesapeakeExport%44A3E14602DA.protected preserve=yes
      //## end bamsprocessing::ChesapeakeExport%44A3E14602DA.protected

  private:
    // Additional Private Declarations
      //## begin bamsprocessing::ChesapeakeExport%44A3E14602DA.private preserve=yes
      //## end bamsprocessing::ChesapeakeExport%44A3E14602DA.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Processor\: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%44A4120B02DD
      //## Role: ChesapeakeExport::<m_hQuery>%44A4120C0252
      //## begin bamsprocessing::ChesapeakeExport::<m_hQuery>%44A4120C0252.role preserve=no  public: reusable::Query {1 -> 1VHgN}
      reusable::Query m_hQuery;
      //## end bamsprocessing::ChesapeakeExport::<m_hQuery>%44A4120C0252.role

    // Additional Implementation Declarations
      //## begin bamsprocessing::ChesapeakeExport%44A3E14602DA.implementation preserve=yes
      //## end bamsprocessing::ChesapeakeExport%44A3E14602DA.implementation

};

//## begin bamsprocessing::ChesapeakeExport%44A3E14602DA.postscript preserve=yes
//## end bamsprocessing::ChesapeakeExport%44A3E14602DA.postscript

} // namespace bamsprocessing

//## begin module%44A3E2000006.epilog preserve=yes
//## end module%44A3E2000006.epilog


#endif
