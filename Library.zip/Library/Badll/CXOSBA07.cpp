//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%44A3E201029D.cm preserve=no
//	$Date:   May 21 2020 20:25:20  $ $Author:   e1009510  $
//	$Revision:   1.13  $
//## end module%44A3E201029D.cm

//## begin module%44A3E201029D.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%44A3E201029D.cp

//## Module: CXOSBA07%44A3E201029D; Package body
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\Devel\Dn\Server\Library\BADLL\CXOSBA07.cpp

//## begin module%44A3E201029D.additionalIncludes preserve=no
//## end module%44A3E201029D.additionalIncludes

//## begin module%44A3E201029D.includes preserve=yes
//## end module%44A3E201029D.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSES18_h
#include "CXODES18.hpp"
#endif
#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSES34_h
#include "CXODES34.hpp"
#endif
#ifndef CXOSES45_h
#include "CXODES45.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSBA07_h
#include "CXODBA07.hpp"
#endif


//## begin module%44A3E201029D.declarations preserve=no
//## end module%44A3E201029D.declarations

//## begin module%44A3E201029D.additionalDeclarations preserve=yes
struct segChesapeakeExport
{
   char sRecordType;             //Value of D
   char sImportAccountId[35];    //1st 4 char should be 'Bank' followed by 5 spaces then MID (11 chars) (
   char sPostDate[8];            //Current date and time
   char sEffectiveDate[8];       //Date Recon Net
   char sTransactionType[2];     //01 - ACH, AC American express, MC Master Card, etc. 'EX' for RETAIL
   char sDebitCredit;            //D for debit, C for credit 
   char sAmount[16];             //zero filled right justified no +/- sign 2 decimal places no decimal pt
   char sReference1[16];         //Unique transaction number for each transaction (Station id for RETAIL)
   char sReference2[16];         //Program office finance number (District id for RETAIL)
   char sReference3[16];         //spaces
   char sReference4[16];         //Case Number
   char sReference5[16];         //time of transaction (spaces for RETAIL)
   char sDetails[40];            //Spaces
};   


//## end module%44A3E201029D.additionalDeclarations


//## Modelname: Processor\: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

// Class bamsprocessing::ChesapeakeExport 

ChesapeakeExport::ChesapeakeExport()
  //## begin ChesapeakeExport::ChesapeakeExport%44A3E14602DA_const.hasinit preserve=no
  //## end ChesapeakeExport::ChesapeakeExport%44A3E14602DA_const.hasinit
  //## begin ChesapeakeExport::ChesapeakeExport%44A3E14602DA_const.initialization preserve=yes
  //## end ChesapeakeExport::ChesapeakeExport%44A3E14602DA_const.initialization
{
  //## begin bamsprocessing::ChesapeakeExport::ChesapeakeExport%44A3E14602DA_const.body preserve=yes
   memcpy(m_sID,"BA07",4);
   m_hQuery.attach(this);
  //## end bamsprocessing::ChesapeakeExport::ChesapeakeExport%44A3E14602DA_const.body
}


ChesapeakeExport::~ChesapeakeExport()
{
  //## begin bamsprocessing::ChesapeakeExport::~ChesapeakeExport%44A3E14602DA_dest.body preserve=yes
  //## end bamsprocessing::ChesapeakeExport::~ChesapeakeExport%44A3E14602DA_dest.body
}



//## Other Operations (implementation)
bool ChesapeakeExport::create ()
{
  //## begin bamsprocessing::ChesapeakeExport::create%44A3E36D02F0.body preserve=yes
   UseCase hUseCase("DR","## DR49 EXPORT EMS EXPENSED FILE");
   Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSSHN());
   m_hQuery.reset();
   m_hQuery.join("EMS_ACCT_HISTORY","INNER","EMS_CASE","CASE_ID");
   m_hQuery.join("EMS_CASE","INNER","EMS_TRANSITION","CASE_ID");
   m_hQuery.join("EMS_CASE","INNER","EMS_TRANSITION","STATE_TSTAMP","TSTAMP_CREATED");
   m_hQuery.join("EMS_ACCT_HISTORY","INNER","EMS_PHASE","CASE_ID");
   m_hQuery.join("EMS_ACCT_HISTORY","INNER","EMS_PHASE","TSTAMP_PHASE","TSTAMP_CREATED");
   CaseSegment::instance()->bind(m_hQuery);
   CaseAccountHistorySegment::instance()->bind(m_hQuery);
   CasePhaseSegment::instance()->bind(m_hQuery);
   m_hQuery.setBasicPredicate("EMS_ACCT_HISTORY","PROCESSED_FLG","=","N");

   if(getDX_FILE_TYPE()== "EMCER")
      m_hQuery.setBasicPredicate("EMS_ACCT_HISTORY","ACCOUNTING_TYPE","IN","('RETL','VAUT')");
   else if(getDX_FILE_TYPE()== "EMCEE") 
      m_hQuery.setBasicPredicate("EMS_ACCT_HISTORY","ACCOUNTING_TYPE","=","ECOM");
   else
      return UseCase::setSuccess(false);
   auto_ptr<SelectStatement> pSelectStatement ((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(m_hQuery))
   {
      Database::instance()->rollback();
      return UseCase::setSuccess(false);
   }
   Database::instance()->commit();
   return UseCase::setSuccess(true);
  //## end bamsprocessing::ChesapeakeExport::create%44A3E36D02F0.body
}

void ChesapeakeExport::update (Subject* pSubject)
{
  //## begin bamsprocessing::ChesapeakeExport::update%44A3E3910342.body preserve=yes
   bool bRetail = (getDX_FILE_TYPE() == "EMCER") ? true : false;
   struct segChesapeakeExport* pDetail = (struct segChesapeakeExport*)getDATA_BUFFER();
   memset(pDetail,' ',sizeof(struct segChesapeakeExport));
   memset(&pDetail->sRecordType,'D',1);
   if(bRetail)
      memcpy(pDetail->sImportAccountId,"BANK FDMS",9);
   else
   {
      memcpy(pDetail->sImportAccountId,"Bank     ",9);
      memcpy(pDetail->sImportAccountId+9,CaseSegment::instance()->getINST_ID_ACQ().c_str(),
         CaseSegment::instance()->getINST_ID_ACQ().length());
   }
   memcpy(pDetail->sPostDate,Clock::instance()->getYYYYMMDDHHMMSS().substr(0,8).c_str(),8);          
   memcpy(pDetail->sEffectiveDate,CaseSegment::instance()->getDATE_RECON_NET().c_str(),8);       
   if(bRetail)
   {
      if (CaseAccountHistorySegment::instance()->getACCOUNTING_TYPE() == "VAUT")
         memcpy(pDetail->sTransactionType,"RE",2);
      else
         memcpy(pDetail->sTransactionType,"EX",2);
   }
   else
   {
      string strNetId(CaseSegment::instance()->getNET_ID_EMS().c_str(),
         CaseSegment::instance()->getNET_ID_EMS().length());
      if( strNetId == "GEN")
         strNetId.assign(CaseSegment::instance()->getNET_ID_ISS().c_str(),
            CaseSegment::instance()->getNET_ID_ISS().length());
      if(strNetId == "VNT" )    //Visa
         memcpy(pDetail->sTransactionType,"VC",2);
      else
      if(strNetId == "MCI" )   //Master Card
         memcpy(pDetail->sTransactionType,"MC",2);
      else
         memcpy(pDetail->sTransactionType,"01",2);
   }
   //check if it's set in account record first B4 looking in act_to_ch
   const char* p = strstr(CaseAccountHistorySegment::instance()->getCREDIT_ACCT().c_str(),"PAN");
   if (p)
      pDetail->sDebitCredit = 'D';
   else if (strstr(CaseAccountHistorySegment::instance()->getDEBIT_ACCT().c_str(),"PAN"))
      pDetail->sDebitCredit = 'C';
   else if (CasePhaseSegment::instance()->getACTION_TO_CARDHLDR()[0] == 'D')
      pDetail->sDebitCredit = 'C';
   else if (CasePhaseSegment::instance()->getACTION_TO_CARDHLDR()[0] == 'C')
      pDetail->sDebitCredit = 'D';

   char szTemp[20];
   int iAMOUNT_VAL = CaseAccountHistorySegment::instance()->getAMOUNT_VAL();
   memcpy(pDetail->sAmount,szTemp,snprintf(szTemp,sizeof(szTemp),"%016d",iAMOUNT_VAL));
   if(bRetail)
   {
      memcpy(pDetail->sReference1,CaseSegment::instance()->getRPT_LVL_ID_B().c_str(),
         CaseSegment::instance()->getRPT_LVL_ID_B().length()); //Finance number (station id)
      memcpy(pDetail->sReference2,CaseSegment::instance()->getINST_ID_RECN_ACQ_B().c_str(),
         CaseSegment::instance()->getINST_ID_RECN_ACQ_B().length()); //District Finance number (district id)
   }
   else
   {
      memcpy(pDetail->sReference1,CaseSegment::instance()->getRETRIEVAL_REF_NO().c_str(),
         CaseSegment::instance()->getRETRIEVAL_REF_NO().length()); //Program office finance number (station id)         
      memcpy(pDetail->sReference2,CaseSegment::instance()->getRPT_LVL_ID_B().c_str(),
         CaseSegment::instance()->getRPT_LVL_ID_B().length()); //Program office finance number (station id)         
      if(CaseSegment::instance()->getTSTAMP_LOCAL().length() > 0)
         memcpy(pDetail->sReference5,CaseSegment::instance()->getTSTAMP_LOCAL().substr(8,6).c_str(),6);
   }   
   memcpy(pDetail->sReference4,CaseSegment::instance()->getCASE_NO().c_str(),
      CaseSegment::instance()->getCASE_NO().length());         
   write(sizeof(struct segChesapeakeExport));

   //update EMS_ACCT_HISTORY 
   UseCase::addItem();
   Table hTable("EMS_ACCT_HISTORY");
   hTable.set("CASE_ID",(int)CaseAccountHistorySegment::instance()->getCASE_ID(),true);
   hTable.set("SEQ_NO",(int)CaseAccountHistorySegment::instance()->getSEQ_NO(),true);
   hTable.set("TSTAMP_CREATED",CaseAccountHistorySegment::instance()->getTSTAMP_CREATED(),false,true);
   hTable.set("PROCESSED_FLG","Y");
   hTable.set("TSTAMP_EXPORTED",Transaction::instance()->getTimeStamp());
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if (!pUpdateStatement->execute(hTable))
      m_hQuery.setAbort(true);
  //## end bamsprocessing::ChesapeakeExport::update%44A3E3910342.body
}

// Additional Declarations
  //## begin bamsprocessing::ChesapeakeExport%44A3E14602DA.declarations preserve=yes
  //## end bamsprocessing::ChesapeakeExport%44A3E14602DA.declarations

} // namespace bamsprocessing

//## begin module%44A3E201029D.epilog preserve=yes
//## end module%44A3E201029D.epilog
