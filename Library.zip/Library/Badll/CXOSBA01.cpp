//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%442181E7029F.cm preserve=no
//	$Date:   May 21 2020 20:25:18  $ $Author:   e1009510  $
//	$Revision:   1.13  $
//## end module%442181E7029F.cm

//## begin module%442181E7029F.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%442181E7029F.cp

//## Module: CXOSBA01%442181E7029F; Package body
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\Devel\Dn\Server\Library\BADLL\CXOSBA01.cpp

//## begin module%442181E7029F.additionalIncludes preserve=no
//## end module%442181E7029F.additionalIncludes

//## begin module%442181E7029F.includes preserve=yes
#ifdef _WIN32
#include "xercesc\framework\MemBufInputSource.hpp"
#include "xercesc\util\PlatformUtils.hpp"
#include "xercesc\parsers\SAXParser.hpp"
#else
#include "xercesc/framework/MemBufInputSource.hpp"
#include "xercesc/util/PlatformUtils.hpp"
#include "xercesc/parsers/SAXParser.hpp"
#endif
#include "CXODTM04.hpp"
#include "CXODIF04.hpp"
#include "CXODIF15.hpp"
//## end module%442181E7029F.includes

#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSVE08_h
#include "CXODVE08.hpp"
#endif
#ifndef CXOSBA02_h
#include "CXODBA02.hpp"
#endif
#ifndef CXOSBA01_h
#include "CXODBA01.hpp"
#endif


//## begin module%442181E7029F.declarations preserve=no
//## end module%442181E7029F.declarations

//## begin module%442181E7029F.additionalDeclarations preserve=yes
//## end module%442181E7029F.additionalDeclarations


//## Modelname: Processor\: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

// Class bamsprocessing::BAMSExceptionImport 

BAMSExceptionImport::BAMSExceptionImport()
  //## begin BAMSExceptionImport::BAMSExceptionImport%4421824900CB_const.hasinit preserve=no
  //## end BAMSExceptionImport::BAMSExceptionImport%4421824900CB_const.hasinit
  //## begin BAMSExceptionImport::BAMSExceptionImport%4421824900CB_const.initialization preserve=yes
  //## end BAMSExceptionImport::BAMSExceptionImport%4421824900CB_const.initialization
{
  //## begin bamsprocessing::BAMSExceptionImport::BAMSExceptionImport%4421824900CB_const.body preserve=yes
   memcpy(m_sID,"BA01",4);
   XMLPlatformUtils::Initialize();
   m_pBAMSExceptionHandler = new BAMSExceptionHandler();
  //## end bamsprocessing::BAMSExceptionImport::BAMSExceptionImport%4421824900CB_const.body
}


BAMSExceptionImport::~BAMSExceptionImport()
{
  //## begin bamsprocessing::BAMSExceptionImport::~BAMSExceptionImport%4421824900CB_dest.body preserve=yes
   delete m_pBAMSExceptionHandler;
   XMLPlatformUtils::Terminate();
  //## end bamsprocessing::BAMSExceptionImport::~BAMSExceptionImport%4421824900CB_dest.body
}



//## Other Operations (implementation)
bool BAMSExceptionImport::execute ()
{
  //## begin bamsprocessing::BAMSExceptionImport::execute%44218C5F005D.body preserve=yes
   UseCase hUseCase("DR","## DR79 IMPORT BAMS CASES",true,true);
   GenerationDataGroup hGenerationDataGroup(Application::instance()->image(),Application::instance()->name(),"BAMSIN");
   //parse Exception File
   if(!parseFile(m_pBAMSExceptionHandler,hGenerationDataGroup))
      return false;
 
   hGenerationDataGroup.commit();
   Database::instance()->commit();

   return true;
  //## end bamsprocessing::BAMSExceptionImport::execute%44218C5F005D.body
}

bool BAMSExceptionImport::parseFile (visaexception::DNHandlerBase* pDNHandlerBase, database::GenerationDataGroup& hGenerationDataGroup)
{
  //## begin bamsprocessing::BAMSExceptionImport::parseFile%44218C6102BF.body preserve=yes
   int lRecordCount = 0;
   size_t lByteCount = 0;
   size_t lMaxRecordLength = 0;
   if (!hGenerationDataGroup.getSize(&lRecordCount, &lByteCount, &lMaxRecordLength) )
      return UseCase::setSuccess(false);
   bool bEBCDIC = false;
   char* psMemBufInputSource = 0;
   if (lByteCount > INT_MAX - 1)
      return UseCase::setSuccess(false);
   psMemBufInputSource = new char[lByteCount + 1];
   if (!psMemBufInputSource)
      return UseCase::setSuccess(false);
   char* p = psMemBufInputSource;
   char* q = 0;
   size_t m = 0;
   int n = lByteCount + 1;
   while (n > 1 && hGenerationDataGroup.read(p,n,&m))
   {
      // SAX 1.0 parser fails with fatal error on the following ...
      q = strchr(p,'|');
      if (q)
         *q = ' ';
      q = strstr(p,"&"); // e.g. Unicode &#x201C;
      if (q)
         *q = ' ';
      //
#ifdef MVS
      if (bEBCDIC == false
         && strchr(p,'<'))
         bEBCDIC = true;
      if (bEBCDIC)
         CodeTable::translate(p,m,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
      p += m;
      n -= m;
   }
   *p = '\0';
   XMLCh sBufld[2] = {1,0};
#ifdef MVS
   m_pBAMSExceptionHandler->initializeAudit("BAMSIN", hGenerationDataGroup.datasetName());
#else
   m_pBAMSExceptionHandler->initializeAudit("BAMSIN", hGenerationDataGroup.getName());
#endif
   MemBufInputSource hMemBufInputSource((XMLByte*)psMemBufInputSource,(unsigned int)lByteCount,&sBufld[0]);
   SAXParser hSAXParser;
   hSAXParser.setDocumentHandler(pDNHandlerBase);
   hSAXParser.setErrorHandler(pDNHandlerBase);
   hSAXParser.parse(hMemBufInputSource);
   delete [] psMemBufInputSource;
   if(pDNHandlerBase->getAbort())
      return UseCase::setSuccess(false);
   return true;
  //## end bamsprocessing::BAMSExceptionImport::parseFile%44218C6102BF.body
}

void BAMSExceptionImport::update (Subject* pSubject)
{
  //## begin bamsprocessing::BAMSExceptionImport::update%44218C6700CB.body preserve=yes
  //## end bamsprocessing::BAMSExceptionImport::update%44218C6700CB.body
}

// Additional Declarations
  //## begin bamsprocessing::BAMSExceptionImport%4421824900CB.declarations preserve=yes
  //## end bamsprocessing::BAMSExceptionImport%4421824900CB.declarations

} // namespace bamsprocessing

//## begin module%442181E7029F.epilog preserve=yes
//## end module%442181E7029F.epilog
