//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%442DBA1502C3.cm preserve=no
//	$Date:   Mar 14 2007 14:11:24  $ $Author:   D93545  $
//	$Revision:   1.3  $
//## end module%442DBA1502C3.cm

//## begin module%442DBA1502C3.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%442DBA1502C3.cp

//## Module: CXOSBA05%442DBA1502C3; Package body
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\Devel\Dn\Server\Library\BADLL\CXOSBA05.cpp

//## begin module%442DBA1502C3.additionalIncludes preserve=no
//## end module%442DBA1502C3.additionalIncludes

//## begin module%442DBA1502C3.includes preserve=yes
//## end module%442DBA1502C3.includes

#ifndef CXOSBA05_h
#include "CXODBA05.hpp"
#endif
//## begin module%442DBA1502C3.declarations preserve=no
//## end module%442DBA1502C3.declarations

//## begin module%442DBA1502C3.additionalDeclarations preserve=yes
#define FIELDS 13
Fields BAMSExportSegment_Fields[FIELDS + 1] =
{
   "l%02d     ","PageCount",0,0,
   "a         ","ImageFileSize",0,0,
   "a         ","ImageFile",0,0,
   "a         ","Comment",0,0,
   "a         ","CurrentDate",0,0,
   "a         ","CurrentTime",0,0,
   "a         ","DocType",0,0,
   "a         ","DocCounter",0,0,
   "l         ","TotalCaseCount",0,0,
   "l         ","SeqNo",0,0,
   "d%-18.0f  ","TotalAdjAmount",0,0,
   "l         ","FailedCaseCount",0,0,
   "l         ","SuccessCaseCount",0,0,
   "~" ,"~", -1,0,
};
//## end module%442DBA1502C3.additionalDeclarations


//## Modelname: Processor\: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

// Class bamsprocessing::BAMSExportSegment 

BAMSExportSegment::BAMSExportSegment()
  //## begin BAMSExportSegment::BAMSExportSegment%442DBA7402FC_const.hasinit preserve=no
      : m_iFailedCaseCount(0),
        m_iSuccessCaseCount(0),
        m_dTotalAdjAmount(0)
  //## end BAMSExportSegment::BAMSExportSegment%442DBA7402FC_const.hasinit
  //## begin BAMSExportSegment::BAMSExportSegment%442DBA7402FC_const.initialization preserve=yes
  //## end BAMSExportSegment::BAMSExportSegment%442DBA7402FC_const.initialization
{
  //## begin bamsprocessing::BAMSExportSegment::BAMSExportSegment%442DBA7402FC_const.body preserve=yes
   memcpy(m_sID,"BA05",4);
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_iPageCount;
   m_pField[1] = &m_strImageFileSize;
   m_pField[2] = &m_strImageFile;
   m_pField[3] = &m_strComment;
   m_pField[4] = &m_strCurrentDate;
   m_pField[5] = &m_strCurrentTime;
   m_pField[6] = &m_strDocType;
   m_pField[7] = &m_strDocCounter;
   m_pField[8] = &m_iTotalCaseCount;
   m_pField[9] = &m_iSeqNo;
   m_pField[10] = &m_dTotalAdjAmount;
   m_pField[11] = &m_iFailedCaseCount;
   m_pField[12] = &m_iSuccessCaseCount;
  //## end bamsprocessing::BAMSExportSegment::BAMSExportSegment%442DBA7402FC_const.body
}


BAMSExportSegment::~BAMSExportSegment()
{
  //## begin bamsprocessing::BAMSExportSegment::~BAMSExportSegment%442DBA7402FC_dest.body preserve=yes
   delete [] m_pField;
  //## end bamsprocessing::BAMSExportSegment::~BAMSExportSegment%442DBA7402FC_dest.body
}



//## Other Operations (implementation)
struct  Fields* BAMSExportSegment::fields () const
{
  //## begin bamsprocessing::BAMSExportSegment::fields%45F80C6D008C.body preserve=yes
   return &BAMSExportSegment_Fields[0];
  //## end bamsprocessing::BAMSExportSegment::fields%45F80C6D008C.body
}

// Additional Declarations
  //## begin bamsprocessing::BAMSExportSegment%442DBA7402FC.declarations preserve=yes
  //## end bamsprocessing::BAMSExportSegment%442DBA7402FC.declarations
} // namespace bamsprocessing

//## begin module%442DBA1502C3.epilog preserve=yes
//## end module%442DBA1502C3.epilog
