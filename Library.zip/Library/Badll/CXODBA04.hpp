//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%442DB6170287.cm preserve=no
//	$Date:   Jun 09 2010 09:05:28  $ $Author:   E1009674  $
//	$Revision:   1.8  $
//## end module%442DB6170287.cm

//## begin module%442DB6170287.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%442DB6170287.cp

//## Module: CXOSBA04%442DB6170287; Package specification
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\Devel\Dn\Server\Library\BADLL\CXODBA04.hpp

#ifndef CXOSBA04_h
#define CXOSBA04_h 1

//## begin module%442DB6170287.additionalIncludes preserve=no
//## end module%442DB6170287.additionalIncludes

//## begin module%442DB6170287.includes preserve=yes
//## end module%442DB6170287.includes

#ifndef CXOSRU20_h
#include "CXODRU20.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSBA05_h
#include "CXODBA05.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseDocumentSegment;
class CasePhaseSegment;
class CaseSegment;
class CaseTransitionSegment;
} // namespace emssegment

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Context;
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Audit;
class XMLText;
class XMLDocument;

} // namespace command

//## begin module%442DB6170287.declarations preserve=no
//## end module%442DB6170287.declarations

//## begin module%442DB6170287.additionalDeclarations preserve=yes
//## end module%442DB6170287.additionalDeclarations


//## Modelname: Platform \: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

//## begin bamsprocessing::BAMSExport%442DB5E100F9.preface preserve=yes
//## end bamsprocessing::BAMSExport%442DB5E100F9.preface

//## Class: BAMSExport%442DB5E100F9
//	<body>
//	<title>CG
//	<h1>DF
//	<h2>FO
//	<!-- BAMSExport : General -->
//	<h3>Bank of America Exception Export
//	<p>
//	Bank of America Merchant Services (BAMS) provides
//	authorization services for VISA, Mastercard, American
//	Express and Discover credit payment transactions.
//	The DataNavigator server supports the BAMS batch
//	interface that processes any disputes related to those
//	transactions.
//	Dispute information is supplied to BAMS in the form of a
//	zip archive containing XML and a set of TIFF images.
//	<p>
//	The File Formatter service (<i>ca</i>DF01) retrieves the
//	pending cases from the EMS tables and produces the Bank
//	of America Exception Export (BAMSRP) and the related
//	audit report (BAMSA1) result sets in the data export
//	tables (DX_DATA_CONTROL and DX_DATA_<i>yyyymmdd</i>).
//	To generate this result set, define the BAMSRP file
//	associated with the processor representing your BAMS
//	endpoint.
//	The file should be produced every day (E) at a set time
//	after the BAMS end of day cutoff.
//	<p>
//	<img src=CXOCDF12.gif>
//	<p>
//	Case information is retrieved from the following tables:
//	<ul>
//	<li><i>custqual</i>.EMS_CASE
//	<li><i>custqual</i>.EMS_CASE_CONTEXT
//	<li><i>custqual</i>.EMS_PHASE
//	<li><i>custqual</i>.EMS_TRANSITION
//	<li><i>custqual</i>.EMS_DOCUMENT
//	</ul>
//	<p>
//	More information can be found in the Bank of America
//	Merchant Services documentation.
//	</body>
//## Category: Platform \: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
//## Subsystem: BADLL%4421755F0157
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%442DB6F300E9;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%442DB6F50178;emssegment::CaseTransitionSegment { -> F}
//## Uses: <unnamed>%442DB6FA002B;database::Database { -> F}
//## Uses: <unnamed>%442DB6FD010C;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%442DB701032E;monitor::UseCase { -> F}
//## Uses: <unnamed>%442DB70C0121;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%442DB71C0066;emssegment::CaseDocumentSegment { -> F}
//## Uses: <unnamed>%442DB72C0037;command::XMLText { -> F}
//## Uses: <unnamed>%442DB73600C7;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%44313CA3021E;entitysegment::Customer { -> F}

class DllExport BAMSExport : public database::ExportFile  //## Inherits: <unnamed>%442DB6EF00F7
{
  //## begin bamsprocessing::BAMSExport%442DB5E100F9.initialDeclarations preserve=yes
  //## end bamsprocessing::BAMSExport%442DB5E100F9.initialDeclarations

  public:
    //## Constructors (generated)
      BAMSExport();

    //## Destructor (generated)
      virtual ~BAMSExport();


    //## Other Operations (specified)
      //## Operation: create%442DB8630098
      virtual bool create ();

      //## Operation: update%442DB86300AC
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin bamsprocessing::BAMSExport%442DB5E100F9.public preserve=yes
      //## end bamsprocessing::BAMSExport%442DB5E100F9.public

  protected:
    // Additional Protected Declarations
      //## begin bamsprocessing::BAMSExport%442DB5E100F9.protected preserve=yes
      //## end bamsprocessing::BAMSExport%442DB5E100F9.protected

  private:

    //## Other Operations (specified)
      //## Operation: cleanup%44341EC9035A
      void cleanup ();

      //## Operation: createAuditReport%4431384901A4
      bool createAuditReport ();

      //## Operation: generateXML%44341E9A00C8
      bool generateXML ();

      //## Operation: processCases%44341E7A0130
      bool processCases ();

      //## Operation: reportAuditDetail%44341EAB02D5
      bool reportAuditDetail ();

      //## Operation: resetFlags%44341EC1013C
      bool resetFlags ();

      //## Operation: transitionCase%44341E9103BE
      bool transitionCase ();

      //## Operation: updateProcessFlg%44341EDF018F
      bool updateProcessFlg (string strOldFlg, string strNewFlg, int lCaseId = 0);

    // Additional Private Declarations
      //## begin bamsprocessing::BAMSExport%442DB5E100F9.private preserve=yes
      //## end bamsprocessing::BAMSExport%442DB5E100F9.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CASE_ID%45AFE91601C5
      //## begin bamsprocessing::BAMSExport::CASE_ID%45AFE91601C5.attr preserve=no  private: int {U} 0
      int m_iCASE_ID;
      //## end bamsprocessing::BAMSExport::CASE_ID%45AFE91601C5.attr

      //## Attribute: CONTEXT_DATA%4990649D01A5
      //## begin bamsprocessing::BAMSExport::CONTEXT_DATA%4990649D01A5.attr preserve=no  private: string {U} 
      string m_strCONTEXT_DATA;
      //## end bamsprocessing::BAMSExport::CONTEXT_DATA%4990649D01A5.attr

      //## Attribute: FirstPass%442DC00A0212
      //## begin bamsprocessing::BAMSExport::FirstPass%442DC00A0212.attr preserve=no  private: bool {U} true
      bool m_bFirstPass;
      //## end bamsprocessing::BAMSExport::FirstPass%442DC00A0212.attr

      //## Attribute: ImageFound%442DC02100E8
      //## begin bamsprocessing::BAMSExport::ImageFound%442DC02100E8.attr preserve=no  private: bool {U} false
      bool m_bImageFound;
      //## end bamsprocessing::BAMSExport::ImageFound%442DC02100E8.attr

      //## Attribute: LastCASE_ID%442DBFC70049
      //## begin bamsprocessing::BAMSExport::LastCASE_ID%442DBFC70049.attr preserve=no  private: int {U} 0
      int m_lLastCASE_ID;
      //## end bamsprocessing::BAMSExport::LastCASE_ID%442DBFC70049.attr

      //## Attribute: NET_RULES%4594032C030D
      //## begin bamsprocessing::BAMSExport::NET_RULES%4594032C030D.attr preserve=no  private: string {U} 
      string m_strNET_RULES;
      //## end bamsprocessing::BAMSExport::NET_RULES%4594032C030D.attr

      //## Attribute: NumRecords%442DB88703E3
      //## begin bamsprocessing::BAMSExport::NumRecords%442DB88703E3.attr preserve=no  private: int {U} 0
      int m_iNumRecords;
      //## end bamsprocessing::BAMSExport::NumRecords%442DB88703E3.attr

      //## Attribute: PROCESSED_FLG%44341DA50011
      //## begin bamsprocessing::BAMSExport::PROCESSED_FLG%44341DA50011.attr preserve=no  private: string {U} 
      string m_strPROCESSED_FLG;
      //## end bamsprocessing::BAMSExport::PROCESSED_FLG%44341DA50011.attr

      //## Attribute: TSTAMP_CREATED%45AFE9920213
      //## begin bamsprocessing::BAMSExport::TSTAMP_CREATED%45AFE9920213.attr preserve=no  private: string {U} 
      string m_strTSTAMP_CREATED;
      //## end bamsprocessing::BAMSExport::TSTAMP_CREATED%45AFE9920213.attr

    // Data Members for Associations

      //## Association: Platform \: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%442DB7610051
      //## Role: BAMSExport::<m_pXMLDocument>%442DB76200D5
      //## begin bamsprocessing::BAMSExport::<m_pXMLDocument>%442DB76200D5.role preserve=no  public: command::XMLDocument { -> RFHgN}
      command::XMLDocument *m_pXMLDocument;
      //## end bamsprocessing::BAMSExport::<m_pXMLDocument>%442DB76200D5.role

      //## Association: Platform \: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%442DB76401E6
      //## Role: BAMSExport::<m_hQuery>%442DB7650089
      //## begin bamsprocessing::BAMSExport::<m_hQuery>%442DB7650089.role preserve=no  public: reusable::Query {1 -> 4VHgN}
      reusable::Query m_hQuery[4];
      //## end bamsprocessing::BAMSExport::<m_hQuery>%442DB7650089.role

      //## Association: Platform \: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%442DB7680015
      //## Role: BAMSExport::<m_hRow>%442DB7680340
      //## begin bamsprocessing::BAMSExport::<m_hRow>%442DB7680340.role preserve=no  public: reusable::Row { -> VHgN}
      reusable::Row m_hRow;
      //## end bamsprocessing::BAMSExport::<m_hRow>%442DB7680340.role

      //## Association: Platform \: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%44312FCA0369
      //## Role: BAMSExport::<m_hBAMSExportSegment>%44312FCB01D0
      //## begin bamsprocessing::BAMSExport::<m_hBAMSExportSegment>%44312FCB01D0.role preserve=no  public: bamsprocessing::BAMSExportSegment { -> VHgN}
      BAMSExportSegment m_hBAMSExportSegment;
      //## end bamsprocessing::BAMSExport::<m_hBAMSExportSegment>%44312FCB01D0.role

      //## Association: Platform \: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%443135EF00E0
      //## Role: BAMSExport::<m_pAudit>%443135EF03E3
      //## begin bamsprocessing::BAMSExport::<m_pAudit>%443135EF03E3.role preserve=no  public: command::Audit { -> RFHgN}
      command::Audit *m_pAudit;
      //## end bamsprocessing::BAMSExport::<m_pAudit>%443135EF03E3.role

      //## Association: Platform \: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%44341DF00236
      //## Role: BAMSExport::<m_pContext>%44341DF10165
      //## begin bamsprocessing::BAMSExport::<m_pContext>%44341DF10165.role preserve=no  public: database::Context { -> RFHgN}
      database::Context *m_pContext;
      //## end bamsprocessing::BAMSExport::<m_pContext>%44341DF10165.role

    // Additional Implementation Declarations
      //## begin bamsprocessing::BAMSExport%442DB5E100F9.implementation preserve=yes
      vector<pair<int,int> > m_hCaseDocuments;
      string formatDate(string strDate);
      map<int,string,less<int> > m_hCaseKeys;
      //## end bamsprocessing::BAMSExport%442DB5E100F9.implementation
};

//## begin bamsprocessing::BAMSExport%442DB5E100F9.postscript preserve=yes
//## end bamsprocessing::BAMSExport%442DB5E100F9.postscript

} // namespace bamsprocessing

//## begin module%442DB6170287.epilog preserve=yes
//## end module%442DB6170287.epilog


#endif
