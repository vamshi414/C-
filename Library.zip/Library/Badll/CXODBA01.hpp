//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%442181E501E4.cm preserve=no
//	$Date:   Aug 14 2006 10:55:52  $ $Author:   D93545  $
//	$Revision:   1.3  $
//## end module%442181E501E4.cm

//## begin module%442181E501E4.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%442181E501E4.cp

//## Module: CXOSBA01%442181E501E4; Package specification
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\Devel\Dn\Server\Library\BADLL\CXODBA01.hpp

#ifndef CXOSBA01_h
#define CXOSBA01_h 1

//## begin module%442181E501E4.additionalIncludes preserve=no
//## end module%442181E501E4.additionalIncludes

//## begin module%442181E501E4.includes preserve=yes
//## end module%442181E501E4.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GenerationDataGroup;
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Processor\: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
class BAMSExceptionHandler;
} // namespace bamsprocessing

//## Modelname: Transaction Research and Adjustments::VisaException_CAT%4097A16101D4
namespace visaexception {
class DNHandlerBase;

} // namespace visaexception

//## begin module%442181E501E4.declarations preserve=no
//## end module%442181E501E4.declarations

//## begin module%442181E501E4.additionalDeclarations preserve=yes
//## end module%442181E501E4.additionalDeclarations


namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

//## begin bamsprocessing::BAMSExceptionImport%4421824900CB.preface preserve=yes
//## end bamsprocessing::BAMSExceptionImport%4421824900CB.preface

//## Class: BAMSExceptionImport%4421824900CB
//## Category: Processor\: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
//## Subsystem: BADLL%4421755F0157
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%44218D26038A;database::GenerationDataGroup { -> F}
//## Uses: <unnamed>%44218D3B0203;process::Application { -> F}
//## Uses: <unnamed>%44218D470271;monitor::UseCase { -> F}
//## Uses: <unnamed>%44218D5E0000;database::Database { -> F}
//## Uses: <unnamed>%442C26DD0148;visaexception::DNHandlerBase { -> F}

class DllExport BAMSExceptionImport : public reusable::Observer  //## Inherits: <unnamed>%442182C7001F
{
  //## begin bamsprocessing::BAMSExceptionImport%4421824900CB.initialDeclarations preserve=yes
  //## end bamsprocessing::BAMSExceptionImport%4421824900CB.initialDeclarations

  public:
    //## Constructors (generated)
      BAMSExceptionImport();

    //## Destructor (generated)
      virtual ~BAMSExceptionImport();


    //## Other Operations (specified)
      //## Operation: execute%44218C5F005D
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>EI
      //	<h2>AB
      //	<h3>Visa Resolve Online Bulk Questionnaire and Image
      //	Download
      //	<p>
      //	<img src=CXOCEI011.gif>
      //	<p>
      //	<img src=CXOCEI012.gif>
      //	<p>
      //	<img src=CXOCEI013.gif>
      //	<p>
      //	Visa Resolve Online sends the Bulk Questionnaire and
      //	Image Download file as a zip archive.
      //	The zip archive contains an XML Batch Descriptor, one or
      //	more XML Response Packages and a Doc Package of TIFF
      //	images.
      //	<p>
      //	The XML files are interpreted by the Exception Interface
      //	service:
      //	<ul>
      //	<li>The matching case is found in DataNavigator EMS
      //	<li>The case is transitioned from DOCR/PNDR to DOCR/FWRD
      //	<li>The location of the images are saved in the EMS_
      //	DOCUMENT table
      //	</ul>
      //	<p>
      //	More information can be found in the Visa Resolve Online
      //	BQI documentation.
      //	<h2>FI
      //	<h3>Visa Resolve Online Bulk Questionnaire and Image
      //	Download
      //	<p>
      //	The unzipped Batch Descriptor and Response Package XML
      //	files must be copied to a Pending folder:
      //	<ul>
      //	<li><i>node001\custqual</i>\VNT\VROL\Import\Pending\BDM5*
      //	<li><i>node001\custqual</i>\VNT\VROL\Import\Pending\RDM5*
      //	</ul>
      //	<h2>FO
      //	<h3>Visa Resolve Online Bulk Questionnaire and Image
      //	Download
      //	<p>
      //	The download process updates the following tables:
      //	<ul>
      //	<li><i>custqual</i>.EMS_CASE
      //	<li><i>custqual</i>.EMS_TRANSITION
      //	<li><i>custqual</i>.EMS_DOCUMENT
      //	<li><i>custqual</i>.EMS_DATA_CHG
      //	</ul>
      //	After processing the XML, the Exception Interface moves
      //	the files to a Complete folder:
      //	<ul>
      //	<li><i>node001\custqual</i>\VNT\VROL\Import\Complete
      //	</ul>
      //	</body>
      bool execute ();

      //## Operation: update%44218C6700CB
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin bamsprocessing::BAMSExceptionImport%4421824900CB.public preserve=yes
      //## end bamsprocessing::BAMSExceptionImport%4421824900CB.public

  protected:
    // Additional Protected Declarations
      //## begin bamsprocessing::BAMSExceptionImport%4421824900CB.protected preserve=yes
      //## end bamsprocessing::BAMSExceptionImport%4421824900CB.protected

  private:

    //## Other Operations (specified)
      //## Operation: parseFile%44218C6102BF
      bool parseFile (visaexception::DNHandlerBase* pDNHandlerBase, database::GenerationDataGroup& hGenerationDataGroup);

    // Additional Private Declarations
      //## begin bamsprocessing::BAMSExceptionImport%4421824900CB.private preserve=yes
      //## end bamsprocessing::BAMSExceptionImport%4421824900CB.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Processor\: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%44218CC0004E
      //## Role: BAMSExceptionImport::<m_pBAMSExceptionHandler>%44218CC002DE
      //## begin bamsprocessing::BAMSExceptionImport::<m_pBAMSExceptionHandler>%44218CC002DE.role preserve=no  public: bamsprocessing::BAMSExceptionHandler { -> RFHgN}
      BAMSExceptionHandler *m_pBAMSExceptionHandler;
      //## end bamsprocessing::BAMSExceptionImport::<m_pBAMSExceptionHandler>%44218CC002DE.role

    // Additional Implementation Declarations
      //## begin bamsprocessing::BAMSExceptionImport%4421824900CB.implementation preserve=yes
      //## end bamsprocessing::BAMSExceptionImport%4421824900CB.implementation

};

//## begin bamsprocessing::BAMSExceptionImport%4421824900CB.postscript preserve=yes
//## end bamsprocessing::BAMSExceptionImport%4421824900CB.postscript

} // namespace bamsprocessing

//## begin module%442181E501E4.epilog preserve=yes
using namespace bamsprocessing;
//## end module%442181E501E4.epilog


#endif
