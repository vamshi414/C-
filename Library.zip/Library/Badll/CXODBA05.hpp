//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%442DBA1301B2.cm preserve=no
//	$Date:   Mar 14 2007 14:11:22  $ $Author:   D93545  $
//	$Revision:   1.4  $
//## end module%442DBA1301B2.cm

//## begin module%442DBA1301B2.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%442DBA1301B2.cp

//## Module: CXOSBA05%442DBA1301B2; Package specification
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\Devel\Dn\Server\Library\BADLL\CXODBA05.hpp

#ifndef CXOSBA05_h
#define CXOSBA05_h 1

//## begin module%442DBA1301B2.additionalIncludes preserve=no
//## end module%442DBA1301B2.additionalIncludes

//## begin module%442DBA1301B2.includes preserve=yes
//## end module%442DBA1301B2.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
//## begin module%442DBA1301B2.declarations preserve=no
//## end module%442DBA1301B2.declarations

//## begin module%442DBA1301B2.additionalDeclarations preserve=yes
//## end module%442DBA1301B2.additionalDeclarations


//## Modelname: Processor\: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

//## begin bamsprocessing::BAMSExportSegment%442DBA7402FC.preface preserve=yes
//## end bamsprocessing::BAMSExportSegment%442DBA7402FC.preface

//## Class: BAMSExportSegment%442DBA7402FC
//## Category: Processor\: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
//## Subsystem: BADLL%4421755F0157
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport BAMSExportSegment : public segment::Segment  //## Inherits: <unnamed>%442DBAD90211
{
  //## begin bamsprocessing::BAMSExportSegment%442DBA7402FC.initialDeclarations preserve=yes
  //## end bamsprocessing::BAMSExportSegment%442DBA7402FC.initialDeclarations

  public:
    //## Constructors (generated)
      BAMSExportSegment();

    //## Destructor (generated)
      virtual ~BAMSExportSegment();


    //## Other Operations (specified)
      //## Operation: fields%45F80C6D008C
      virtual struct  Fields* fields () const;

      //## Operation: incrementDocCounter%45F80D6002FD
      void incrementDocCounter ()
      {
        //## begin bamsprocessing::BAMSExportSegment::incrementDocCounter%45F80D6002FD.body preserve=yes
         m_iDocCount++;
        //## end bamsprocessing::BAMSExportSegment::incrementDocCounter%45F80D6002FD.body
      }

      //## Operation: resetDocCounter%45F80D7100EA
      void resetDocCounter ()
      {
        //## begin bamsprocessing::BAMSExportSegment::resetDocCounter%45F80D7100EA.body preserve=yes
         m_iDocCount = 0;
        //## end bamsprocessing::BAMSExportSegment::resetDocCounter%45F80D7100EA.body
      }

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Comment%45F80A1503B9
      const string& getComment () const
      {
        //## begin bamsprocessing::BAMSExportSegment::getComment%45F80A1503B9.get preserve=no
        return m_strComment;
        //## end bamsprocessing::BAMSExportSegment::getComment%45F80A1503B9.get
      }

      void setComment (const string& value)
      {
        //## begin bamsprocessing::BAMSExportSegment::setComment%45F80A1503B9.set preserve=no
        m_strComment = value;
        //## end bamsprocessing::BAMSExportSegment::setComment%45F80A1503B9.set
      }


      //## Attribute: CurrentDate%442DC11001C8
      const string& getCurrentDate () const
      {
        //## begin bamsprocessing::BAMSExportSegment::getCurrentDate%442DC11001C8.get preserve=no
        return m_strCurrentDate;
        //## end bamsprocessing::BAMSExportSegment::getCurrentDate%442DC11001C8.get
      }

      void setCurrentDate (const string& value)
      {
        //## begin bamsprocessing::BAMSExportSegment::setCurrentDate%442DC11001C8.set preserve=no
        m_strCurrentDate = value;
        //## end bamsprocessing::BAMSExportSegment::setCurrentDate%442DC11001C8.set
      }


      //## Attribute: CurrentTime%4434081500AA
      const string& getCurrentTime () const
      {
        //## begin bamsprocessing::BAMSExportSegment::getCurrentTime%4434081500AA.get preserve=no
        return m_strCurrentTime;
        //## end bamsprocessing::BAMSExportSegment::getCurrentTime%4434081500AA.get
      }

      void setCurrentTime (const string& value)
      {
        //## begin bamsprocessing::BAMSExportSegment::setCurrentTime%4434081500AA.set preserve=no
        m_strCurrentTime = value;
        //## end bamsprocessing::BAMSExportSegment::setCurrentTime%4434081500AA.set
      }


      //## Attribute: DocType%442DC113015E
      const string& getDocType () const
      {
        //## begin bamsprocessing::BAMSExportSegment::getDocType%442DC113015E.get preserve=no
        return m_strDocType;
        //## end bamsprocessing::BAMSExportSegment::getDocType%442DC113015E.get
      }

      void setDocType (const string& value)
      {
        //## begin bamsprocessing::BAMSExportSegment::setDocType%442DC113015E.set preserve=no
        m_strDocType = value;
        //## end bamsprocessing::BAMSExportSegment::setDocType%442DC113015E.set
      }


      //## Attribute: ImageFileSize%442DBB000299
      const string& getImageFileSize () const
      {
        //## begin bamsprocessing::BAMSExportSegment::getImageFileSize%442DBB000299.get preserve=no
        return m_strImageFileSize;
        //## end bamsprocessing::BAMSExportSegment::getImageFileSize%442DBB000299.get
      }

      void setImageFileSize (const string& value)
      {
        //## begin bamsprocessing::BAMSExportSegment::setImageFileSize%442DBB000299.set preserve=no
        m_strImageFileSize = value;
        //## end bamsprocessing::BAMSExportSegment::setImageFileSize%442DBB000299.set
      }


      //## Attribute: ImageFile%442DBB0002A3
      const string& getImageFile () const
      {
        //## begin bamsprocessing::BAMSExportSegment::getImageFile%442DBB0002A3.get preserve=no
        return m_strImageFile;
        //## end bamsprocessing::BAMSExportSegment::getImageFile%442DBB0002A3.get
      }

      void setImageFile (const string& value)
      {
        //## begin bamsprocessing::BAMSExportSegment::setImageFile%442DBB0002A3.set preserve=no
        m_strImageFile = value;
        //## end bamsprocessing::BAMSExportSegment::setImageFile%442DBB0002A3.set
      }


    // Data Members for Class Attributes

      //## Attribute: DocCount%442DC15C0204
      //## begin bamsprocessing::BAMSExportSegment::DocCount%442DC15C0204.attr preserve=no  public: int {U} 
      int m_iDocCount;
      //## end bamsprocessing::BAMSExportSegment::DocCount%442DC15C0204.attr

      //## Attribute: FailedCaseCount%4431401F0112
      //## begin bamsprocessing::BAMSExportSegment::FailedCaseCount%4431401F0112.attr preserve=no  public: int {U} 0
      int m_iFailedCaseCount;
      //## end bamsprocessing::BAMSExportSegment::FailedCaseCount%4431401F0112.attr

      //## Attribute: PageCount%442DBB00028F
      //## begin bamsprocessing::BAMSExportSegment::PageCount%442DBB00028F.attr preserve=no  public: int {V} 
      int m_iPageCount;
      //## end bamsprocessing::BAMSExportSegment::PageCount%442DBB00028F.attr

      //## Attribute: SeqNo%443408330099
      //## begin bamsprocessing::BAMSExportSegment::SeqNo%443408330099.attr preserve=no  public: int {U} 
      int m_iSeqNo;
      //## end bamsprocessing::BAMSExportSegment::SeqNo%443408330099.attr

      //## Attribute: SuccessCaseCount%443406F6029C
      //## begin bamsprocessing::BAMSExportSegment::SuccessCaseCount%443406F6029C.attr preserve=no  public: int {U} 0
      int m_iSuccessCaseCount;
      //## end bamsprocessing::BAMSExportSegment::SuccessCaseCount%443406F6029C.attr

      //## Attribute: TotalAdjAmount%4434070F005D
      //## begin bamsprocessing::BAMSExportSegment::TotalAdjAmount%4434070F005D.attr preserve=no  public: double {U} 0
      double m_dTotalAdjAmount;
      //## end bamsprocessing::BAMSExportSegment::TotalAdjAmount%4434070F005D.attr

      //## Attribute: TotalCaseCount%44313F0E02B5
      //## begin bamsprocessing::BAMSExportSegment::TotalCaseCount%44313F0E02B5.attr preserve=no  public: int {U} 
      int m_iTotalCaseCount;
      //## end bamsprocessing::BAMSExportSegment::TotalCaseCount%44313F0E02B5.attr

    // Additional Public Declarations
      //## begin bamsprocessing::BAMSExportSegment%442DBA7402FC.public preserve=yes
      //## end bamsprocessing::BAMSExportSegment%442DBA7402FC.public

  protected:
    // Additional Protected Declarations
      //## begin bamsprocessing::BAMSExportSegment%442DBA7402FC.protected preserve=yes
      //## end bamsprocessing::BAMSExportSegment%442DBA7402FC.protected

  private:
    // Additional Private Declarations
      //## begin bamsprocessing::BAMSExportSegment%442DBA7402FC.private preserve=yes
      //## end bamsprocessing::BAMSExportSegment%442DBA7402FC.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin bamsprocessing::BAMSExportSegment::Comment%45F80A1503B9.attr preserve=no  public: string {U} 
      string m_strComment;
      //## end bamsprocessing::BAMSExportSegment::Comment%45F80A1503B9.attr

      //## begin bamsprocessing::BAMSExportSegment::CurrentDate%442DC11001C8.attr preserve=no  public: string {V} 
      string m_strCurrentDate;
      //## end bamsprocessing::BAMSExportSegment::CurrentDate%442DC11001C8.attr

      //## begin bamsprocessing::BAMSExportSegment::CurrentTime%4434081500AA.attr preserve=no  public: string {V} 
      string m_strCurrentTime;
      //## end bamsprocessing::BAMSExportSegment::CurrentTime%4434081500AA.attr

      //## begin bamsprocessing::BAMSExportSegment::DocType%442DC113015E.attr preserve=no  public: string {V} 
      string m_strDocType;
      //## end bamsprocessing::BAMSExportSegment::DocType%442DC113015E.attr

      //## begin bamsprocessing::BAMSExportSegment::ImageFileSize%442DBB000299.attr preserve=no  public: string {V} 
      string m_strImageFileSize;
      //## end bamsprocessing::BAMSExportSegment::ImageFileSize%442DBB000299.attr

      //## begin bamsprocessing::BAMSExportSegment::ImageFile%442DBB0002A3.attr preserve=no  public: string {V} 
      string m_strImageFile;
      //## end bamsprocessing::BAMSExportSegment::ImageFile%442DBB0002A3.attr

    // Additional Implementation Declarations
      //## begin bamsprocessing::BAMSExportSegment%442DBA7402FC.implementation preserve=yes
      string m_strDocCounter;
      string m_strMemberMessageBlock;
      string m_strTransactionDate;
      string m_strPostDate;
      //## end bamsprocessing::BAMSExportSegment%442DBA7402FC.implementation
};

//## begin bamsprocessing::BAMSExportSegment%442DBA7402FC.postscript preserve=yes
//## end bamsprocessing::BAMSExportSegment%442DBA7402FC.postscript

} // namespace bamsprocessing

//## begin module%442DBA1301B2.epilog preserve=yes
//## end module%442DBA1301B2.epilog


#endif
