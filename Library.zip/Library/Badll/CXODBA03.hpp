//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%442185F50000.cm preserve=no
//	$Date:   May 01 2012 10:57:02  $ $Author:   E1009674  $
//	$Revision:   1.20  $
//## end module%442185F50000.cm

//## begin module%442185F50000.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%442185F50000.cp

//## Module: CXOSBA03%442185F50000; Package specification
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\Devel\Dn\Server\Library\BADLL\CXODBA03.hpp

#ifndef CXOSBA03_h
#define CXOSBA03_h 1

//## begin module%442185F50000.additionalIncludes preserve=no
//## end module%442185F50000.additionalIncludes

//## begin module%442185F50000.includes preserve=yes
//## end module%442185F50000.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class Case;
class NationalException;
class CaseAddEventVisitor;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
class CaseCreateCommand;
} // namespace emscommand

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseVisaSegment;
class CaseSegment;
class CaseTransitionSegment;
class CasePreAuthSegment;
class CasePhaseMCSegment;
class CaseMCSegment;
class CaseNationalNetworkSegment;
class CaseDocumentSegment;
class CaseCommentSegment;
class CasePhaseSegment;
class CasePhaseVisaSegment;
} // namespace emssegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::ViewSegment_CAT%394E276801C1
namespace viewsegment {
class ReportOptionSegment;

} // namespace viewsegment

//## begin module%442185F50000.declarations preserve=no
//## end module%442185F50000.declarations

//## begin module%442185F50000.additionalDeclarations preserve=yes
//## end module%442185F50000.additionalDeclarations


//## Modelname: Platform \: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

//## begin bamsprocessing::BAMSException%442185560261.preface preserve=yes
//## end bamsprocessing::BAMSException%442185560261.preface

//## Class: BAMSException%442185560261
//## Category: Platform \: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
//## Subsystem: BADLL%4421755F0157
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%442827160109;database::Database { -> F}
//## Uses: <unnamed>%442829EE0128;emssegment::CaseDocumentSegment { -> F}
//## Uses: <unnamed>%44282A2F00BB;IF::Extract { -> F}
//## Uses: <unnamed>%44295D7B038A;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%44295E320196;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%44295E48030D;emssegment::CaseTransitionSegment { -> F}
//## Uses: <unnamed>%44295E6901E4;emssegment::CaseMCSegment { -> F}
//## Uses: <unnamed>%44295E7A0271;emssegment::CasePhaseMCSegment { -> F}
//## Uses: <unnamed>%44295E88038A;emssegment::CaseVisaSegment { -> F}
//## Uses: <unnamed>%44295E96036B;emssegment::CasePhaseVisaSegment { -> F}
//## Uses: <unnamed>%44295EA401C5;emssegment::CaseNationalNetworkSegment { -> F}
//## Uses: <unnamed>%4429721801B5;reusable::Query { -> F}
//## Uses: <unnamed>%4429724100AB;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4429726602EE;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4429A735005D;ems::Case { -> F}
//## Uses: <unnamed>%4429A77400CB;ems::NationalException { -> F}
//## Uses: <unnamed>%4429A8470222;emssegment::CasePreAuthSegment { -> F}
//## Uses: <unnamed>%44315AFF000F;reusable::Statement { -> F}
//## Uses: <unnamed>%44315B8203B9;reusable::Table { -> F}
//## Uses: <unnamed>%443FC7960167;ems::CaseAddEventVisitor { -> F}
//## Uses: <unnamed>%44B670A2038A;emscommand::CaseCreateCommand { -> F}
//## Uses: <unnamed>%459AA62403B9;emssegment::CaseCommentSegment { -> F}
//## Uses: <unnamed>%48060C05031C;viewsegment::ReportOptionSegment { -> F}

class DllExport BAMSException : public reusable::Observer  //## Inherits: <unnamed>%442185D6031C
{
  //## begin bamsprocessing::BAMSException%442185560261.initialDeclarations preserve=yes
  //## end bamsprocessing::BAMSException%442185560261.initialDeclarations

  public:
    //## Constructors (generated)
      BAMSException();

    //## Destructor (generated)
      virtual ~BAMSException();


    //## Other Operations (specified)
      //## Operation: addComment%45A28E53029F
      void addComment ();

      //## Operation: appendACTUAL_MSG%4429710900EA
      void appendACTUAL_MSG (const string& strValue);

      //## Operation: bind%44295C9601A5
      void bind (reusable::Query& hQuery);

      //## Operation: createDuplicateCase%4AAE64D90266
      bool createDuplicateCase ();

      //## Operation: initializeListSegment%44DC66250280
      void initializeListSegment ();

      //## Operation: mapFinancialData%4429A3C600CB
      void mapFinancialData ();

      //## Operation: mapUnmatchedData%4496AF6D01D4
      void mapUnmatchedData ();

      //## Operation: processCase%442956B10290
      bool processCase ();

      //## Operation: processChargeback%44296DCD005D
      bool processChargeback (bool bMatchingCase);

      //## Operation: process2ndChargeback%49876F230203
      bool process2ndChargeback (bool bMatchingCase);

      //## Operation: processMasterCardArbitration%498317EF00CB
      bool processMasterCardArbitration (bool bMatchingCase);

      //## Operation: processReject%445A0170029F
      bool processReject (bool bMatchingCase);

      //## Operation: processRepresentment%459B1E2F03D8
      bool processRepresentment (bool bMatchingCase);

      //## Operation: processRetrievalRequest%44296D2502CE
      bool processRetrievalRequest (bool bMatchingCase);

      //## Operation: processVisaArbitration%46058A51002E
      bool processVisaArbitration (bool bMatchingCase);

      //## Operation: reset%442953E1002E
      void reset ();

      //## Operation: retrieveCase%4C2900270330
      bool retrieveCase (bool& bMatchingCase);

      //## Operation: retrieveTransaction%48920A780128
      bool retrieveTransaction (bool bSecondTry = false);

      //## Operation: setCommentFields%459AA3EF0261
      void setCommentFields (const string& strEMS_COMMENT);

      //## Operation: setDocumentFields%4428296F008C
      bool setDocumentFields ();

      //## Operation: setDocumentPresence%44E5C9FF029F
      void setDocumentPresence ();

      //## Operation: setErrorText%443BFF9602AF
      void setErrorText ();

      //## Operation: setSTATE_EXPIR_TSTAMP%459AD17502DE
      void setSTATE_EXPIR_TSTAMP ();

      //## Operation: update%4421A7100399
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

      //## Operation: updateTransition%4F9E94E9018D
      bool updateTransition ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ACTUAL_MSG%4423022901B5
      const string& getACTUAL_MSG () const
      {
        //## begin bamsprocessing::BAMSException::getACTUAL_MSG%4423022901B5.get preserve=no
        return m_strACTUAL_MSG;
        //## end bamsprocessing::BAMSException::getACTUAL_MSG%4423022901B5.get
      }

      void setACTUAL_MSG (const string& value)
      {
        //## begin bamsprocessing::BAMSException::setACTUAL_MSG%4423022901B5.set preserve=no
        m_strACTUAL_MSG = value;
        //## end bamsprocessing::BAMSException::setACTUAL_MSG%4423022901B5.set
      }


      //## Attribute: AMT_ADJUSTMENT%442302B90280
      void setAMT_ADJUSTMENT (const double& value)
      {
        //## begin bamsprocessing::BAMSException::setAMT_ADJUSTMENT%442302B90280.set preserve=no
        m_dAMT_ADJUSTMENT = value;
        //## end bamsprocessing::BAMSException::setAMT_ADJUSTMENT%442302B90280.set
      }


      //## Attribute: AMT_TRAN%458606FF0271
      void setAMT_TRAN (const double& value)
      {
        //## begin bamsprocessing::BAMSException::setAMT_TRAN%458606FF0271.set preserve=no
        m_dAMT_TRAN = value;
        //## end bamsprocessing::BAMSException::setAMT_TRAN%458606FF0271.set
      }


      //## Attribute: CUR_ADJUSTMENT%44230300033C
      void setCUR_ADJUSTMENT (const string& value)
      {
        //## begin bamsprocessing::BAMSException::setCUR_ADJUSTMENT%44230300033C.set preserve=no
        m_strCUR_ADJUSTMENT = value;
        //## end bamsprocessing::BAMSException::setCUR_ADJUSTMENT%44230300033C.set
      }


      //## Attribute: DateReceived%4423022A0138
      const string& getDateReceived () const
      {
        //## begin bamsprocessing::BAMSException::getDateReceived%4423022A0138.get preserve=no
        return m_strDateReceived;
        //## end bamsprocessing::BAMSException::getDateReceived%4423022A0138.get
      }

      void setDateReceived (const string& value)
      {
        //## begin bamsprocessing::BAMSException::setDateReceived%4423022A0138.set preserve=no
        m_strDateReceived = value;
        //## end bamsprocessing::BAMSException::setDateReceived%4423022A0138.set
      }


      //## Attribute: ErrorText%443BD0F101B5
      const string& getErrorText () const
      {
        //## begin bamsprocessing::BAMSException::getErrorText%443BD0F101B5.get preserve=no
        return m_strErrorText;
        //## end bamsprocessing::BAMSException::getErrorText%443BD0F101B5.get
      }

      void setErrorText (const string& value)
      {
        //## begin bamsprocessing::BAMSException::setErrorText%443BD0F101B5.set preserve=no
        m_strErrorText = value;
        //## end bamsprocessing::BAMSException::setErrorText%443BD0F101B5.set
      }


      //## Attribute: IssuerRefNo%442812B4038A
      void setIssuerRefNo (const string& value)
      {
        //## begin bamsprocessing::BAMSException::setIssuerRefNo%442812B4038A.set preserve=no
        m_strIssuerRefNo = value;
        //## end bamsprocessing::BAMSException::setIssuerRefNo%442812B4038A.set
      }


      //## Attribute: MMT%4428126700DA
      void setMMT (const string& value)
      {
        //## begin bamsprocessing::BAMSException::setMMT%4428126700DA.set preserve=no
        m_strMMT = value;
        //## end bamsprocessing::BAMSException::setMMT%4428126700DA.set
      }


      //## Attribute: NET_ID_EMS%4432A2F203A9
      void setNET_ID_EMS (const string& value)
      {
        //## begin bamsprocessing::BAMSException::setNET_ID_EMS%4432A2F203A9.set preserve=no
        m_strNET_ID_EMS = value;
        //## end bamsprocessing::BAMSException::setNET_ID_EMS%4432A2F203A9.set
      }


      //## Attribute: OTHER_CASE_NO%458606C00261
      void setOTHER_CASE_NO (const string& value)
      {
        //## begin bamsprocessing::BAMSException::setOTHER_CASE_NO%458606C00261.set preserve=no
        m_strOTHER_CASE_NO = value;
        //## end bamsprocessing::BAMSException::setOTHER_CASE_NO%458606C00261.set
      }


      //## Attribute: Purpose%443A557503D8
      const short& getPurpose () const
      {
        //## begin bamsprocessing::BAMSException::getPurpose%443A557503D8.get preserve=no
        return m_siPurpose;
        //## end bamsprocessing::BAMSException::getPurpose%443A557503D8.get
      }

      void setPurpose (const short& value)
      {
        //## begin bamsprocessing::BAMSException::setPurpose%443A557503D8.set preserve=no
        m_siPurpose = value;
        //## end bamsprocessing::BAMSException::setPurpose%443A557503D8.set
      }


      //## Attribute: REASON_CODE%4423022A032C
      const string& getREASON_CODE () const
      {
        //## begin bamsprocessing::BAMSException::getREASON_CODE%4423022A032C.get preserve=no
        return m_strREASON_CODE;
        //## end bamsprocessing::BAMSException::getREASON_CODE%4423022A032C.get
      }

      void setREASON_CODE (const string& value)
      {
        //## begin bamsprocessing::BAMSException::setREASON_CODE%4423022A032C.set preserve=no
        m_strREASON_CODE = value;
        //## end bamsprocessing::BAMSException::setREASON_CODE%4423022A032C.set
      }


      //## Attribute: REQUEST_TYPE%44DCD95D003E
      void setREQUEST_TYPE (const string& value)
      {
        //## begin bamsprocessing::BAMSException::setREQUEST_TYPE%44DCD95D003E.set preserve=no
        m_strREQUEST_TYPE = value;
        //## end bamsprocessing::BAMSException::setREQUEST_TYPE%44DCD95D003E.set
      }


      //## Attribute: RETRIEVAL_REQ_ID%442814890167
      void setRETRIEVAL_REQ_ID (const string& value)
      {
        //## begin bamsprocessing::BAMSException::setRETRIEVAL_REQ_ID%442814890167.set preserve=no
        m_strRETRIEVAL_REQ_ID = value;
        //## end bamsprocessing::BAMSException::setRETRIEVAL_REQ_ID%442814890167.set
      }


      //## Attribute: SEQ_NO%44314C9102EE
      void setSEQ_NO (const short& value)
      {
        //## begin bamsprocessing::BAMSException::setSEQ_NO%44314C9102EE.set preserve=no
        m_siSEQ_NO = value;
        //## end bamsprocessing::BAMSException::setSEQ_NO%44314C9102EE.set
      }


      //## Attribute: STATE_EXPIR_TSTAMP%459A6FFD00AB
      const string& getSTATE_EXPIR_TSTAMP () const
      {
        //## begin bamsprocessing::BAMSException::getSTATE_EXPIR_TSTAMP%459A6FFD00AB.get preserve=no
        return m_strSTATE_EXPIR_TSTAMP;
        //## end bamsprocessing::BAMSException::getSTATE_EXPIR_TSTAMP%459A6FFD00AB.get
      }

      void setSTATE_EXPIR_TSTAMP (const string& value)
      {
        //## begin bamsprocessing::BAMSException::setSTATE_EXPIR_TSTAMP%459A6FFD00AB.set preserve=no
        m_strSTATE_EXPIR_TSTAMP = value;
        //## end bamsprocessing::BAMSException::setSTATE_EXPIR_TSTAMP%459A6FFD00AB.set
      }


      //## Attribute: TransactionID%47FA26740232
      const string& getTransactionID () const
      {
        //## begin bamsprocessing::BAMSException::getTransactionID%47FA26740232.get preserve=no
        return m_strTransactionID;
        //## end bamsprocessing::BAMSException::getTransactionID%47FA26740232.get
      }

      void setTransactionID (const string& value)
      {
        //## begin bamsprocessing::BAMSException::setTransactionID%47FA26740232.set preserve=no
        m_strTransactionID = value;
        //## end bamsprocessing::BAMSException::setTransactionID%47FA26740232.set
      }


    // Additional Public Declarations
      //## begin bamsprocessing::BAMSException%442185560261.public preserve=yes
      //## end bamsprocessing::BAMSException%442185560261.public

  protected:
    // Additional Protected Declarations
      //## begin bamsprocessing::BAMSException%442185560261.protected preserve=yes
      //## end bamsprocessing::BAMSException%442185560261.protected

  private:
    // Additional Private Declarations
      //## begin bamsprocessing::BAMSException%442185560261.private preserve=yes
      //## end bamsprocessing::BAMSException%442185560261.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin bamsprocessing::BAMSException::ACTUAL_MSG%4423022901B5.attr preserve=no  public: string {V} 
      string m_strACTUAL_MSG;
      //## end bamsprocessing::BAMSException::ACTUAL_MSG%4423022901B5.attr

      //## begin bamsprocessing::BAMSException::AMT_ADJUSTMENT%442302B90280.attr preserve=no  public: double {U} 0
      double m_dAMT_ADJUSTMENT;
      //## end bamsprocessing::BAMSException::AMT_ADJUSTMENT%442302B90280.attr

      //## begin bamsprocessing::BAMSException::AMT_TRAN%458606FF0271.attr preserve=no  public: double {U} 0
      double m_dAMT_TRAN;
      //## end bamsprocessing::BAMSException::AMT_TRAN%458606FF0271.attr

      //## Attribute: CaseCreateCommand%44B66FE10251
      //## begin bamsprocessing::BAMSException::CaseCreateCommand%44B66FE10251.attr preserve=no  private: emscommand::CaseCreateCommand* {U} 
      emscommand::CaseCreateCommand* m_pCaseCreateCommand;
      //## end bamsprocessing::BAMSException::CaseCreateCommand%44B66FE10251.attr

      //## Attribute: CFG_DESCRIPTION%443D3CD3008C
      //## begin bamsprocessing::BAMSException::CFG_DESCRIPTION%443D3CD3008C.attr preserve=no  private: string {V} 
      string m_strCFG_DESCRIPTION;
      //## end bamsprocessing::BAMSException::CFG_DESCRIPTION%443D3CD3008C.attr

      //## begin bamsprocessing::BAMSException::CUR_ADJUSTMENT%44230300033C.attr preserve=no  public: string {U} 
      string m_strCUR_ADJUSTMENT;
      //## end bamsprocessing::BAMSException::CUR_ADJUSTMENT%44230300033C.attr

      //## Attribute: CUST_ID%4423022A00AB
      //## begin bamsprocessing::BAMSException::CUST_ID%4423022A00AB.attr preserve=no  private: string {V} 
      string m_strCUST_ID;
      //## end bamsprocessing::BAMSException::CUST_ID%4423022A00AB.attr

      //## Attribute: DATA_VALUE%443D3CE602DE
      //## begin bamsprocessing::BAMSException::DATA_VALUE%443D3CE602DE.attr preserve=no  private: string {V} 
      string m_strDATA_VALUE;
      //## end bamsprocessing::BAMSException::DATA_VALUE%443D3CE602DE.attr

      //## begin bamsprocessing::BAMSException::DateReceived%4423022A0138.attr preserve=no  public: string {V} 
      string m_strDateReceived;
      //## end bamsprocessing::BAMSException::DateReceived%4423022A0138.attr

      //## Attribute: DateReceivedJulian%459A8EA401D4
      //## begin bamsprocessing::BAMSException::DateReceivedJulian%459A8EA401D4.attr preserve=no  private: string {U} 
      string m_strDateReceivedJulian;
      //## end bamsprocessing::BAMSException::DateReceivedJulian%459A8EA401D4.attr

      //## Attribute: DOC_PATH%4423022A01D4
      //## begin bamsprocessing::BAMSException::DOC_PATH%4423022A01D4.attr preserve=no  private: string {V} 
      string m_strDOC_PATH;
      //## end bamsprocessing::BAMSException::DOC_PATH%4423022A01D4.attr

      //## Attribute: Buffer%44230229032C
      //## begin bamsprocessing::BAMSException::Buffer%44230229032C.attr preserve=no  private: char* {V} 0
      char* m_pBuffer;
      //## end bamsprocessing::BAMSException::Buffer%44230229032C.attr

      //## begin bamsprocessing::BAMSException::ErrorText%443BD0F101B5.attr preserve=no  public: string {U} 
      string m_strErrorText;
      //## end bamsprocessing::BAMSException::ErrorText%443BD0F101B5.attr

      //## begin bamsprocessing::BAMSException::IssuerRefNo%442812B4038A.attr preserve=no  public: string {U} 
      string m_strIssuerRefNo;
      //## end bamsprocessing::BAMSException::IssuerRefNo%442812B4038A.attr

      //## begin bamsprocessing::BAMSException::MMT%4428126700DA.attr preserve=no  public: string {U} 
      string m_strMMT;
      //## end bamsprocessing::BAMSException::MMT%4428126700DA.attr

      //## begin bamsprocessing::BAMSException::NET_ID_EMS%4432A2F203A9.attr preserve=no  public: string {U} 
      string m_strNET_ID_EMS;
      //## end bamsprocessing::BAMSException::NET_ID_EMS%4432A2F203A9.attr

      //## begin bamsprocessing::BAMSException::OTHER_CASE_NO%458606C00261.attr preserve=no  public: string {U} 
      string m_strOTHER_CASE_NO;
      //## end bamsprocessing::BAMSException::OTHER_CASE_NO%458606C00261.attr

      //## begin bamsprocessing::BAMSException::Purpose%443A557503D8.attr preserve=no  public: short {U} 
      short m_siPurpose;
      //## end bamsprocessing::BAMSException::Purpose%443A557503D8.attr

      //## begin bamsprocessing::BAMSException::REASON_CODE%4423022A032C.attr preserve=no  public: string {U} 
      string m_strREASON_CODE;
      //## end bamsprocessing::BAMSException::REASON_CODE%4423022A032C.attr

      //## begin bamsprocessing::BAMSException::REQUEST_TYPE%44DCD95D003E.attr preserve=no  public: string {U} 
      string m_strREQUEST_TYPE;
      //## end bamsprocessing::BAMSException::REQUEST_TYPE%44DCD95D003E.attr

      //## Attribute: RETRIEVAL_REF_NO%4607BFC70138
      //## begin bamsprocessing::BAMSException::RETRIEVAL_REF_NO%4607BFC70138.attr preserve=no  public: string {U} 
      string m_strRETRIEVAL_REF_NO;
      //## end bamsprocessing::BAMSException::RETRIEVAL_REF_NO%4607BFC70138.attr

      //## begin bamsprocessing::BAMSException::RETRIEVAL_REQ_ID%442814890167.attr preserve=no  public: string {U} 
      string m_strRETRIEVAL_REQ_ID;
      //## end bamsprocessing::BAMSException::RETRIEVAL_REQ_ID%442814890167.attr

      //## begin bamsprocessing::BAMSException::SEQ_NO%44314C9102EE.attr preserve=no  public: short {U} 
      short m_siSEQ_NO;
      //## end bamsprocessing::BAMSException::SEQ_NO%44314C9102EE.attr

      //## begin bamsprocessing::BAMSException::STATE_EXPIR_TSTAMP%459A6FFD00AB.attr preserve=no  public: string {U} 
      string m_strSTATE_EXPIR_TSTAMP;
      //## end bamsprocessing::BAMSException::STATE_EXPIR_TSTAMP%459A6FFD00AB.attr

      //## begin bamsprocessing::BAMSException::TransactionID%47FA26740232.attr preserve=no  public: string {U} 
      string m_strTransactionID;
      //## end bamsprocessing::BAMSException::TransactionID%47FA26740232.attr

    // Additional Implementation Declarations
      //## begin bamsprocessing::BAMSException%442185560261.implementation preserve=yes
      //## end bamsprocessing::BAMSException%442185560261.implementation

};

//## begin bamsprocessing::BAMSException%442185560261.postscript preserve=yes
//## end bamsprocessing::BAMSException%442185560261.postscript

} // namespace bamsprocessing

//## begin module%442185F50000.epilog preserve=yes
using namespace bamsprocessing;
//## end module%442185F50000.epilog


#endif
