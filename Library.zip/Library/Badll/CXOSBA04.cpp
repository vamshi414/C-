//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%442DB61303D6.cm preserve=no
//	$Date:   May 21 2020 20:25:20  $ $Author:   e1009510  $
//	$Revision:   1.35  $
//## end module%442DB61303D6.cm

//## begin module%442DB61303D6.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%442DB61303D6.cp

//## Module: CXOSBA04%442DB61303D6; Package body
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\Devel\Dn\Server\Library\BADLL\CXOSBA04.cpp

//## begin module%442DB61303D6.additionalIncludes preserve=no
//## end module%442DB61303D6.additionalIncludes

//## begin module%442DB61303D6.includes preserve=yes
#define STS_RECORD_NOT_FOUND 14
#include <algorithm>
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSEX28_h
#include "CXODEX28.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#include "CXODEX17.hpp"
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
//## end module%442DB61303D6.includes

#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSES36_h
#include "CXODES36.hpp"
#endif
#ifndef CXOSBC16_h
#include "CXODBC16.hpp"
#endif
#ifndef CXOSES18_h
#include "CXODES18.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSBC15_h
#include "CXODBC15.hpp"
#endif
#ifndef CXOSBC20_h
#include "CXODBC20.hpp"
#endif
#ifndef CXOSBA04_h
#include "CXODBA04.hpp"
#endif


//## begin module%442DB61303D6.declarations preserve=no
//## end module%442DB61303D6.declarations

//## begin module%442DB61303D6.additionalDeclarations preserve=yes
//## end module%442DB61303D6.additionalDeclarations


//## Modelname: Platform \: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

// Class bamsprocessing::BAMSExport 

BAMSExport::BAMSExport()
  //## begin BAMSExport::BAMSExport%442DB5E100F9_const.hasinit preserve=no
      : m_iCASE_ID(0),
        m_bFirstPass(true),
        m_bImageFound(false),
        m_lLastCASE_ID(0),
        m_iNumRecords(0)
  //## end BAMSExport::BAMSExport%442DB5E100F9_const.hasinit
  //## begin BAMSExport::BAMSExport%442DB5E100F9_const.initialization preserve=yes
  //## end BAMSExport::BAMSExport%442DB5E100F9_const.initialization
{
  //## begin bamsprocessing::BAMSExport::BAMSExport%442DB5E100F9_const.body preserve=yes
   m_hRow.attach(this);
   m_hQuery[0].attach(this);
   m_hQuery[1].attach(this);
   m_hQuery[2].attach(this);
   m_pAudit = 0;
   m_pContext = new Context(Application::instance()->image(),Application::instance()->name());
  //## end bamsprocessing::BAMSExport::BAMSExport%442DB5E100F9_const.body
}


BAMSExport::~BAMSExport()
{
  //## begin bamsprocessing::BAMSExport::~BAMSExport%442DB5E100F9_dest.body preserve=yes
   delete m_pContext;
  //## end bamsprocessing::BAMSExport::~BAMSExport%442DB5E100F9_dest.body
}



//## Other Operations (implementation)
void BAMSExport::cleanup ()
{
  //## begin bamsprocessing::BAMSExport::cleanup%44341EC9035A.body preserve=yes
   string strCONTEXT_KEY("BAMS EXPORT PROGRESS ");
   strCONTEXT_KEY.append(getDATE_RECON());
   Query hQuery;
   hQuery.setQualifier("CUSTQUAL","TASK_CONTEXT");
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_DATA","=","Process Complete");

   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_KEY","<",strCONTEXT_KEY.c_str());
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   pDeleteStatement->execute(hQuery);
   Database::instance()->commit();
   m_strNET_RULES.erase();
  //## end bamsprocessing::BAMSExport::cleanup%44341EC9035A.body
}

bool BAMSExport::create ()
{
  //## begin bamsprocessing::BAMSExport::create%442DB8630098.body preserve=yes

   //clean up old TASK_CONTEXT checkpoint records
   cleanup();
   Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSSHN());

   if(!processCases())
      return UseCase::setSuccess(false);
   
   if(!generateXML())
      return UseCase::setSuccess(false);

   if(!createAuditReport())
      return UseCase::setSuccess(false);
   
   if(!resetFlags())
      return UseCase::setSuccess(false);
   
   return UseCase::setSuccess(true);
  //## end bamsprocessing::BAMSExport::create%442DB8630098.body
}

bool BAMSExport::createAuditReport ()
{
  //## begin bamsprocessing::BAMSExport::createAuditReport%4431384901A4.body preserve=yes
   m_pAudit = new Audit("BAMSA1",
      "AP",
      "AP",
      getDATE_RECON(),
      Clock::instance()->getYYYYMMDDHHMMSS().substr(8,6));
   const char* pszAudit[] =
   {
      "HDataNavigator BAMS Exception Export",
      "HRun Time,~Z.CurrentDate.,~Z.CurrentTime",
      "HFile BAMSExceptionExport.XML ",
      "H",
      "HSequence,Status,Case No.,Timestamp,PAN,Retrieval Ref#,Amount,"
      "Adj Amount",
      "S~Z.SeqNo.,Success,~C.CASE_NO.,~C.TSTAMP_TRANS.,~C.*PAN.,"
      "~C.RETRIEVAL_REF_NO.,~C.AMT_TRAN.,~P.AMT_ADJUSTMENT.",
      "F~Z.SeqNo.,Failed,~C.CASE_NO.,~C.TSTAMP_TRANS.,~C.*PAN.,"
      "~C.RETRIEVAL_REF_NO.,~C.AMT_TRAN.,~P.AMT_ADJUSTMENT.",
      "TNumber of Cases processed successfully:, ~Z.SuccessCaseCount.",
      "TNumber of failed cases:, ~Z.FailedCaseCount.",
      "TTotal Adjustment Amount:, ~Z.TotalAdjAmount.",
      0
   };
   m_hBAMSExportSegment.m_iSeqNo = 0;
   char szDateTime[15];
   m_hBAMSExportSegment.setCurrentDate(string(szDateTime,snprintf(szDateTime,sizeof(szDateTime),
      "%02d/%02d/%04d",
      Clock::instance()->getMonth(),
      Clock::instance()->getDay(),
      Clock::instance()->getYear())));
   m_hBAMSExportSegment.setCurrentTime(string(szDateTime,snprintf(szDateTime,sizeof(szDateTime),
      "%02d:%02d:%02d",
      Clock::instance()->getHour(),
      Clock::instance()->getMinute(),
      Clock::instance()->getSecond())));
   m_pAudit->setTemplate(&pszAudit[0]);
   m_pAudit->add('Z',&m_hBAMSExportSegment);
   m_pAudit->add('C',CaseSegment::instance());
   m_pAudit->add('P',CasePhaseSegment::instance());
   if(!m_pAudit->report('H')) //header
      return false;

   if(!reportAuditDetail())
      return false;

   if(!m_pAudit->report('T')) //trailer
      return false;
   m_pAudit->complete();
   delete m_pAudit;
   return true;
  //## end bamsprocessing::BAMSExport::createAuditReport%4431384901A4.body
}

bool BAMSExport::generateXML ()
{
  //## begin bamsprocessing::BAMSExport::generateXML%44341E9A00C8.body preserve=yes
   m_iNumRecords = 0;
   m_lLastCASE_ID = 0;
   m_hBAMSExportSegment.resetDocCounter();
   m_hBAMSExportSegment.m_iPageCount = 0;
   m_hBAMSExportSegment.setImageFileSize("0"); //filled in by post processing script 
   XMLText hXMLText;
   hXMLText.add('Z',&m_hBAMSExportSegment);
   hXMLText.add('C',CaseSegment::instance());
   hXMLText.add('D',CaseDocumentSegment::instance());
   string strXMLTemplateName("CXOXML01");
#ifdef MVS
   m_pXMLDocument = new command::XMLDocument("JCL","DN##ML01",&m_hRow,&hXMLText);
   strXMLTemplateName.assign("DNDNML01",8);
#else
   m_pXMLDocument = new command::XMLDocument("SOURCE","CXOXML01",&m_hRow,&hXMLText);
#endif
   if(m_pXMLDocument->recordCount() == 0)
   {
      char szError[80];
      Trace::put(szError,snprintf(szError,sizeof(szError),
         "Warning - CXOSBA04 Unable to open XML Template %s",
         strXMLTemplateName.c_str())); 
      return false;
   }
   m_hBAMSExportSegment.m_iTotalCaseCount  = 0;
   Query hQuery;
   int iCaseId = 0;
   hQuery.setDistinct(true);
   hQuery.bind("EMS_CASE","CASE_ID",Column::LONG,&iCaseId);
   hQuery.join("EMS_CASE","INNER","EMS_CASE_CONTEXT","CASE_ID");       
   hQuery.join("EMS_CASE","INNER","EMS_TRANSITION","STATE_TSTAMP","TSTAMP_CREATED");       
   hQuery.join("EMS_CASE","INNER","EMS_TRANSITION","CASE_ID");
   hQuery.setBasicPredicate("EMS_CASE_CONTEXT","CONTEXT_TYPE","=","EXPORT");
   hQuery.setBasicPredicate("EMS_CASE_CONTEXT","PROCESSED_FLG","=","S");
   hQuery.setGroupByClause("CASE_ID");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   pSelectStatement->execute(hQuery);
   m_hBAMSExportSegment.m_iTotalCaseCount = pSelectStatement->getRows();


   m_hQuery[0].reset();
   m_hQuery[0].join("EMS_CASE","INNER","EMS_CASE_CONTEXT","CASE_ID");       
   m_hQuery[0].join("EMS_CASE","INNER","EMS_TRANSITION","STATE_TSTAMP","TSTAMP_CREATED");       
   m_hQuery[0].join("EMS_CASE","INNER","EMS_TRANSITION","CASE_ID");
   m_hQuery[0].bind("EMS_CASE_CONTEXT","TSTAMP_CREATED",Column::STRING,&m_strTSTAMP_CREATED);
	m_hQuery[0].bind("EMS_CASE_CONTEXT","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA);
   CaseSegment::instance()->bind(m_hQuery[0]);
   CaseTransitionSegment::instance()->bind(m_hQuery[0]);
   m_hQuery[0].setBasicPredicate("EMS_CASE_CONTEXT","CONTEXT_TYPE","=","EXPORT");
   m_hQuery[0].setBasicPredicate("EMS_CASE_CONTEXT","PROCESSED_FLG","=","S");
   m_hQuery[0].setOrderByClause("EMS_CASE.CASE_ID");
   m_pXMLDocument->add("BAMSChargeback");
   if (strstr(m_strCONTEXT_DATA.c_str(),"PURPOSE"))
      m_pXMLDocument->add("Purpose");
   bool bReturn = pSelectStatement->execute(m_hQuery[0]);
   m_pXMLDocument->write("");
   delete m_pXMLDocument;
   m_pXMLDocument = 0;
   return bReturn;
  //## end bamsprocessing::BAMSExport::generateXML%44341E9A00C8.body
}

bool BAMSExport::processCases ()
{
  //## begin bamsprocessing::BAMSExport::processCases%44341E7A0130.body preserve=yes
   //handle rerun situations
   string strCONTEXT_DATA;
   string strCONTEXT_KEY("BAMS EXPORT PROGRESS ");
   strCONTEXT_KEY.append(getDATE_RECON());
   m_pContext->get(strCONTEXT_KEY.c_str(), strCONTEXT_DATA);
   if(strCONTEXT_DATA != "Process Complete" &&   //rerun only
      strCONTEXT_DATA != "Transition Cases in Progress" &&
      strCONTEXT_DATA.length() > 0)
      return true; //skip to next phase

   m_pContext->put(strCONTEXT_KEY.c_str(),"Transition Cases in Progress");
   Database::instance()->commit();

   m_lLastCASE_ID = 0;
   m_hQuery[1].reset();
   m_hQuery[1].setRetainCursor(true);
	m_hQuery[1].attach(this);
	m_hQuery[1].bind("EMS_CASE_CONTEXT","CASE_ID",Column::LONG,&m_iCASE_ID);
	m_hQuery[1].bind("EMS_CASE_CONTEXT","TSTAMP_CREATED",Column::STRING,&m_strTSTAMP_CREATED);
	m_hQuery[1].setBasicPredicate("EMS_CASE_CONTEXT","CONTEXT_TYPE","=","EXPORT");
   m_hQuery[1].setBasicPredicate("EMS_CASE_CONTEXT","NET_ID","IN",
      "('VNT','MCI')");
	m_hQuery[1].setBasicPredicate("EMS_CASE_CONTEXT","PROCESSED_FLG","=","N");
   m_hQuery[1].setOrderByClause("EMS_CASE_CONTEXT.TSTAMP_CREATED");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   if(!pSelectStatement->execute(m_hQuery[1]))
      return false;

   map<int, string, less<int> >::iterator pCaseKeys;
   for (pCaseKeys = m_hCaseKeys.begin(); pCaseKeys != m_hCaseKeys.end(); ++pCaseKeys)
   {
      Query hQuery;
      hQuery.join("EMS_CASE","INNER","EMS_TRANSITION","STATE_TSTAMP","TSTAMP_CREATED");       
      hQuery.join("EMS_CASE","INNER","EMS_TRANSITION","CASE_ID");
      hQuery.join("EMS_TRANSITION","INNER","EMS_PHASE","PHASE_TSTAMP","TSTAMP_CREATED");
      hQuery.join("EMS_TRANSITION","INNER","EMS_PHASE","CASE_ID");
      CaseSegment::instance()->bind(hQuery);
      CasePhaseSegment::instance()->bind(hQuery);
      CaseTransitionSegment::instance()->bind(hQuery);
      hQuery.setBasicPredicate("EMS_CASE","CASE_ID","=",(*pCaseKeys).first);
      hQuery.setBasicPredicate("EMS_TRANSITION","TSTAMP_CREATED","=",(*pCaseKeys).second.c_str());
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      pSelectStatement->execute(hQuery);
      if (pSelectStatement->getRows() == 0)
      {
         Trace::put("case not found:ST132");
      }
      else
      {
         if(transitionCase())
            updateProcessFlg("N","S",CaseSegment::instance()->getCASE_ID());
         else
            updateProcessFlg("N","F",CaseSegment::instance()->getCASE_ID());
         Database::instance()->commit();
      }
   }

   m_pContext->put(strCONTEXT_KEY.c_str(),"Generating Reports");
   Database::instance()->commit();
   return true;
  //## end bamsprocessing::BAMSExport::processCases%44341E7A0130.body
}

bool BAMSExport::reportAuditDetail ()
{
  //## begin bamsprocessing::BAMSExport::reportAuditDetail%44341EAB02D5.body preserve=yes
   //report on successful cases
   m_hQuery[2].reset();
   m_hQuery[2].join("EMS_CASE","INNER","EMS_CASE_CONTEXT","CASE_ID");       
   m_hQuery[2].join("EMS_CASE","INNER","EMS_TRANSITION","STATE_TSTAMP","TSTAMP_CREATED");       
   m_hQuery[2].join("EMS_CASE","INNER","EMS_TRANSITION","CASE_ID");
   m_hQuery[2].join("EMS_TRANSITION","INNER","EMS_PHASE","PHASE_TSTAMP","TSTAMP_CREATED");
   m_hQuery[2].join("EMS_TRANSITION","INNER","EMS_PHASE","CASE_ID");
   CaseSegment::instance()->bind(m_hQuery[2]);
   CasePhaseSegment::instance()->bind(m_hQuery[2]);
   CaseTransitionSegment::instance()->bind(m_hQuery[2]);
   m_hQuery[2].bind("EMS_CASE_CONTEXT","PROCESSED_FLG",Column::STRING,&m_strPROCESSED_FLG);
   m_hQuery[2].setBasicPredicate("EMS_CASE_CONTEXT","CONTEXT_TYPE","=","EXPORT");
   m_hQuery[2].setBasicPredicate("EMS_CASE_CONTEXT","PROCESSED_FLG","IN",
      "('S','F')");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   return pSelectStatement->execute(m_hQuery[2]);
  //## end bamsprocessing::BAMSExport::reportAuditDetail%44341EAB02D5.body
}

bool BAMSExport::resetFlags ()
{
  //## begin bamsprocessing::BAMSExport::resetFlags%44341EC1013C.body preserve=yes
   //mark successful cases as processed
   if(!updateProcessFlg("S","Y"))
      return false;

   //mark failed cases as not processed
   if(!updateProcessFlg("F","N"))
      return false;

   string strCONTEXT_KEY("BAMS EXPORT PROGRESS ");
   strCONTEXT_KEY.append(getDATE_RECON());
   m_pContext->put(strCONTEXT_KEY.c_str(),"Process Complete");
   Database::instance()->commit();
   return true;
  //## end bamsprocessing::BAMSExport::resetFlags%44341EC1013C.body
}

bool BAMSExport::transitionCase ()
{
  //## begin bamsprocessing::BAMSExport::transitionCase%44341E9103BE.body preserve=yes
   if (m_strNET_RULES != CaseSegment::instance()->getNET_RULES())
      EMSRulesEngine::instance()->resetRuleSetPointer();
   m_strNET_RULES = CaseSegment::instance()->getNET_RULES();
   return NationalException::instance()->transitionCase("PNDR");
  //## end bamsprocessing::BAMSExport::transitionCase%44341E9103BE.body
}

void BAMSExport::update (Subject* pSubject)
{
  //## begin bamsprocessing::BAMSExport::update%442DB86300AC.body preserve=yes
   if(pSubject == &m_hRow)
   {
      int lDataLength = snprintf((char*)getDATA_BUFFER(),DATA_BUFFER, "%s", m_hRow.getBuffer().c_str());
      write(lDataLength);
   }
   else if(pSubject == &m_hQuery[0]) //generateXML
   {
      m_iNumRecords++;
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      m_hBAMSExportSegment.clear();
      m_hBAMSExportSegment.m_iPageCount = 0;
      m_hBAMSExportSegment.setImageFileSize("0"); 
      string strComment("");
      Query hQuery;
      hQuery.bind("EMS_COMMENT","EMS_COMMENT",Column::STRING,&strComment);
      hQuery.setBasicPredicate("EMS_COMMENT","TSTAMP_CREATED","=",m_strTSTAMP_CREATED.c_str());
      hQuery.setBasicPredicate("EMS_COMMENT","EMAIL_STATUS","=","R");
      hQuery.setBasicPredicate("EMS_COMMENT","USER_ID","=","SYSTEM");
      pSelectStatement->execute(hQuery);
      m_pXMLDocument->add("BAMSChargebackRecord");
      if (pSelectStatement->getRows() != 0)
      {
         m_hBAMSExportSegment.setComment(strComment);
         m_pXMLDocument->add("BAMSComment");
      }
      if (strstr(m_strCONTEXT_DATA.c_str(),"PURPOSE"))
         m_pXMLDocument->add("Purpose");

      m_hQuery[3].reset();
      m_hQuery[3].attach(this);
      CaseDocumentSegment::instance()->bind(m_hQuery[3]);
      m_hQuery[3].setBasicPredicate("EMS_DOCUMENT","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
      m_hQuery[3].setBasicPredicate("EMS_DOCUMENT","EXPORT_IND","=","R");
      m_hQuery[3].setBasicPredicate("EMS_DOCUMENT","DELETE_FLG","=","N");
      m_hQuery[3].setOrderByClause("EMS_DOCUMENT.TSTAMP_CREATED ASC");
      pSelectStatement->execute(m_hQuery[3]);

      m_pXMLDocument->add("PageCount");
      m_pXMLDocument->add("ImageFileSize");
      m_pXMLDocument->write("BAMSChargebackRecord");
      //reset document fields
      m_hBAMSExportSegment.m_iPageCount = 0;
      m_hBAMSExportSegment.setImageFileSize("0");
   }
   else if(pSubject == &m_hQuery[1]) //processCases
   {
      m_hCaseKeys.insert(map<int,string,less<int> >::value_type(m_iCASE_ID,m_strTSTAMP_CREATED));
      return;
   }
   else if(pSubject == &m_hQuery[2]) //reportAuditDetail
   {
      m_hBAMSExportSegment.m_iSeqNo++;
      m_hBAMSExportSegment.m_iTotalCaseCount++;
      if(m_strPROCESSED_FLG == "S")
      {
         m_hBAMSExportSegment.m_dTotalAdjAmount += CasePhaseSegment::instance()->getAMT_ADJUSTMENT();
         m_hBAMSExportSegment.m_iSuccessCaseCount++;
         m_pAudit->report('S');
      }
      else
      {
         m_hBAMSExportSegment.m_iFailedCaseCount++;
         m_pAudit->report('F');
      }
   }
   else if(pSubject == &m_hQuery[3]) // list of documents to send
   {
      //check for documents associated with this case
      string strDOC_TYPE = CaseDocumentSegment::instance()->getDOC_TYPE();
      string strDocSuffix;
      //make sure we only process the correct types of documents
      if(strDOC_TYPE.length() > 4 && strDOC_TYPE.substr(0,4) == "REQ_")
         strDocSuffix = CaseDocumentSegment::instance()->getDOC_PATH().substr(
            CaseDocumentSegment::instance()->getDOC_PATH().find_last_of(".")+1);
      transform (strDocSuffix.begin(),strDocSuffix.end(), strDocSuffix.begin(), ::tolower);
      if(strDocSuffix == "tif")
      {
         //save CASE_ID, SEQ_NO for later to update TSTAMP_TRANSMITTED
         m_hCaseDocuments.push_back(pair<int,int>(CaseSegment::instance()->getCASE_ID(),
            CaseDocumentSegment::instance()->getSEQ_NO()));
         
         m_hBAMSExportSegment.m_iPageCount++;
         string strImageFile(CaseSegment::instance()->getOTHER_CASE_NO());
         string strImageFileSize(strImageFile);
         strImageFileSize.append(".TIF_SIZE");
         m_hBAMSExportSegment.setImageFile(strImageFile);
         m_hBAMSExportSegment.setImageFileSize(strImageFileSize);
         m_hBAMSExportSegment.setDocType(strDocSuffix);
         m_hBAMSExportSegment.incrementDocCounter(); //total count of docs
         m_pXMLDocument->add("EFUNDS_CMD1");
      }
   }
  //## end bamsprocessing::BAMSExport::update%442DB86300AC.body
}

bool BAMSExport::updateProcessFlg (string strOldFlg, string strNewFlg, int lCaseId)
{
  //## begin bamsprocessing::BAMSExport::updateProcessFlg%44341EDF018F.body preserve=yes
   if(lCaseId == 0 && strOldFlg == "S")
   {
      //mark all sent documents as transmitted
      for(int i = 0; i < m_hCaseDocuments.size(); i++)
      {
         Table hTable("EMS_DOCUMENT");
         hTable.set("TSTAMP_TRANSMITTED",Clock::instance()->getYYYYMMDDHHMMSSHN(),false,false);
         hTable.set("CASE_ID",(int)m_hCaseDocuments[i].first,true);
         hTable.set("SEQ_NO",(int)m_hCaseDocuments[i].second,true);
         hTable.set("EXPORT_IND","S",false,false);
         auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
         pUpdateStatement->execute(hTable);
      }   
   }
   
   Table hTable("EMS_CASE_CONTEXT");
   hTable.set("PROCESSED_FLG",strNewFlg,false,false);
   hTable.set("TSTAMP_UPDATED",Clock::instance()->getYYYYMMDDHHMMSSHN(),false,false);
   if(lCaseId != 0)
      hTable.set("CASE_ID",lCaseId,true);
   hTable.set("CONTEXT_TYPE","EXPORT",false,true);
   string strSearchCondition = " AND PROCESSED_FLG = '";
   strSearchCondition.append(strOldFlg);
   strSearchCondition.append("' ");
   auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   bool bReturn = pUpdateStatement->execute(hTable,strSearchCondition);
   if(pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      return true;
   return bReturn;
  //## end bamsprocessing::BAMSExport::updateProcessFlg%44341EDF018F.body
}

// Additional Declarations
  //## begin bamsprocessing::BAMSExport%442DB5E100F9.declarations preserve=yes
  //## end bamsprocessing::BAMSExport%442DB5E100F9.declarations

} // namespace bamsprocessing

//## begin module%442DB61303D6.epilog preserve=yes
//## end module%442DB61303D6.epilog
