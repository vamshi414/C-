//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%44218503035B.cm preserve=no
//	$Date:   Dec 30 2015 15:11:02  $ $Author:   e1009652  $
//	$Revision:   1.6  $
//## end module%44218503035B.cm

//## begin module%44218503035B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%44218503035B.cp

//## Module: CXOSBA02%44218503035B; Package specification
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\bV02.7A.R001\Windows\Build\Dn\Server\Library\Badll\CXODBA02.hpp

#ifndef CXOSBA02_h
#define CXOSBA02_h 1

//## begin module%44218503035B.additionalIncludes preserve=no
//## end module%44218503035B.additionalIncludes

//## begin module%44218503035B.includes preserve=yes
//## end module%44218503035B.includes

#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSES34_h
#include "CXODES34.hpp"
#endif
#ifndef CXOSES18_h
#include "CXODES18.hpp"
#endif
#ifndef CXOSVE08_h
#include "CXODVE08.hpp"
#endif
#ifndef CXOSBA06_h
#include "CXODBA06.hpp"
#endif
#ifndef CXOSBA03_h
#include "CXODBA03.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Timestamp;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Audit;

} // namespace command

//## begin module%44218503035B.declarations preserve=no
//## end module%44218503035B.declarations

//## begin module%44218503035B.additionalDeclarations preserve=yes
//## end module%44218503035B.additionalDeclarations


//## Modelname: Platform \: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

//## begin bamsprocessing::BAMSExceptionHandler%4421843D03C8.preface preserve=yes
//## end bamsprocessing::BAMSExceptionHandler%4421843D03C8.preface

//## Class: BAMSExceptionHandler%4421843D03C8
//## Category: Platform \: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
//## Subsystem: BADLL%4421755F0157
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%44218B1D0232;monitor::UseCase { -> F}
//## Uses: <unnamed>%4432A7F00242;entitysegment::Customer { -> F}
//## Uses: <unnamed>%4432A9AE03B9;reusable::Transaction { -> F}
//## Uses: <unnamed>%4432B2190203;database::Database { -> F}
//## Uses: <unnamed>%44EB3BC30261;IF::Timestamp { -> F}
//## Uses: <unnamed>%44EB3BC502AF;timer::Clock { -> F}

class DllExport BAMSExceptionHandler : public visaexception::DNHandlerBase  //## Inherits: <unnamed>%442184BA0251
{
  //## begin bamsprocessing::BAMSExceptionHandler%4421843D03C8.initialDeclarations preserve=yes
  //## end bamsprocessing::BAMSExceptionHandler%4421843D03C8.initialDeclarations

  public:
    //## Constructors (generated)
      BAMSExceptionHandler();

    //## Destructor (generated)
      virtual ~BAMSExceptionHandler();


    //## Other Operations (specified)
      //## Operation: characters%44218B3203B9
      void characters (const XMLCh* const chars, const XMLSIZE length);

      //## Operation: endDocument%44218B3503C8
      virtual void endDocument ();

      //## Operation: endElement%44218B3801F4
      virtual void endElement (const XMLCh* const name);

      //## Operation: error%44218B3B006D
      virtual void error (const SAXParseException& exc);

      //## Operation: fatalError%44218B3E0148
      virtual void fatalError (const SAXParseException& exc);

      //## Operation: getDOC_PATH%44218B420148
      bool getDOC_PATH (int iPath, int iIndex, string& strDOC_PATH);

      //## Operation: initializeAudit%4432A76403C8
      bool initializeAudit (const string& strGENNAM, const string& strPath);

      //## Operation: reformatDate%458AB97101B5
      void reformatDate ();

      //## Operation: startDocument%44218B45003E
      virtual void startDocument ();

      //## Operation: startElement%44218B4803A9
      virtual void startElement (const XMLCh* const name, AttributeList& attributes);

    // Additional Public Declarations
      //## begin bamsprocessing::BAMSExceptionHandler%4421843D03C8.public preserve=yes
      //## end bamsprocessing::BAMSExceptionHandler%4421843D03C8.public

  protected:
    // Additional Protected Declarations
      //## begin bamsprocessing::BAMSExceptionHandler%4421843D03C8.protected preserve=yes
      //## end bamsprocessing::BAMSExceptionHandler%4421843D03C8.protected

  private:
    // Additional Private Declarations
      //## begin bamsprocessing::BAMSExceptionHandler%4421843D03C8.private preserve=yes
      //## end bamsprocessing::BAMSExceptionHandler%4421843D03C8.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%44218AB4036B
      //## Role: BAMSExceptionHandler::<m_hBAMSException>%44218AB500BB
      //## begin bamsprocessing::BAMSExceptionHandler::<m_hBAMSException>%44218AB500BB.role preserve=no  public: bamsprocessing::BAMSException { -> VHgN}
      BAMSException m_hBAMSException;
      //## end bamsprocessing::BAMSExceptionHandler::<m_hBAMSException>%44218AB500BB.role

      //## Association: Platform \: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%44328DBB00BB
      //## Role: BAMSExceptionHandler::<m_pAudit>%44328DBC003E
      //## begin bamsprocessing::BAMSExceptionHandler::<m_pAudit>%44328DBC003E.role preserve=no  public: command::Audit { -> RFHgN}
      command::Audit *m_pAudit;
      //## end bamsprocessing::BAMSExceptionHandler::<m_pAudit>%44328DBC003E.role

      //## Association: Platform \: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%4432936F0203
      //## Role: BAMSExceptionHandler::<m_hBAMSExceptionImportSegment>%4432937000CB
      //## begin bamsprocessing::BAMSExceptionHandler::<m_hBAMSExceptionImportSegment>%4432937000CB.role preserve=no  public: bamsprocessing::BAMSExceptionImportSegment { -> VHgN}
      BAMSExceptionImportSegment m_hBAMSExceptionImportSegment;
      //## end bamsprocessing::BAMSExceptionHandler::<m_hBAMSExceptionImportSegment>%4432937000CB.role

      //## Association: Platform \: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%4432B19F00BB
      //## Role: BAMSExceptionHandler::<m_hCaseSegment>%4432B19F02FD
      //## begin bamsprocessing::BAMSExceptionHandler::<m_hCaseSegment>%4432B19F02FD.role preserve=no  public: emssegment::CaseSegment { -> VHgN}
      emssegment::CaseSegment m_hCaseSegment;
      //## end bamsprocessing::BAMSExceptionHandler::<m_hCaseSegment>%4432B19F02FD.role

      //## Association: Platform \: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%4432B1B50186
      //## Role: BAMSExceptionHandler::<m_hCaseNationalNetworkSegment>%4432B1B503A9
      //## begin bamsprocessing::BAMSExceptionHandler::<m_hCaseNationalNetworkSegment>%4432B1B503A9.role preserve=no  public: emssegment::CaseNationalNetworkSegment { -> VHgN}
      emssegment::CaseNationalNetworkSegment m_hCaseNationalNetworkSegment;
      //## end bamsprocessing::BAMSExceptionHandler::<m_hCaseNationalNetworkSegment>%4432B1B503A9.role

      //## Association: Platform \: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%45DDA0D702FD
      //## Role: BAMSExceptionHandler::<m_hCasePhaseSegment>%45DDA0D800EA
      //## begin bamsprocessing::BAMSExceptionHandler::<m_hCasePhaseSegment>%45DDA0D800EA.role preserve=no  public: emssegment::CasePhaseSegment { -> VHgN}
      emssegment::CasePhaseSegment m_hCasePhaseSegment;
      //## end bamsprocessing::BAMSExceptionHandler::<m_hCasePhaseSegment>%45DDA0D800EA.role

      //## Association: Platform \: Bank Of America::BankOfAmericaProcessing_CAT::<unnamed>%4C28FEC4021B
      //## Role: BAMSExceptionHandler::<m_hCaseTransitionSegment>%4C28FEC50027
      //## begin bamsprocessing::BAMSExceptionHandler::<m_hCaseTransitionSegment>%4C28FEC50027.role preserve=no  public: emssegment::CaseTransitionSegment { -> VHgN}
      emssegment::CaseTransitionSegment m_hCaseTransitionSegment;
      //## end bamsprocessing::BAMSExceptionHandler::<m_hCaseTransitionSegment>%4C28FEC50027.role

    // Additional Implementation Declarations
      //## begin bamsprocessing::BAMSExceptionHandler%4421843D03C8.implementation preserve=yes
      //## end bamsprocessing::BAMSExceptionHandler%4421843D03C8.implementation

};

//## begin bamsprocessing::BAMSExceptionHandler%4421843D03C8.postscript preserve=yes
//## end bamsprocessing::BAMSExceptionHandler%4421843D03C8.postscript

} // namespace bamsprocessing

//## begin module%44218503035B.epilog preserve=yes
using namespace bamsprocessing;
//## end module%44218503035B.epilog


#endif
