//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%442185F600AB.cm preserve=no
//	$Date:   May 21 2020 20:25:18  $ $Author:   e1009510  $
//	$Revision:   1.64  $
//## end module%442185F600AB.cm

//## begin module%442185F600AB.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%442185F600AB.cp

//## Module: CXOSBA03%442185F600AB; Package body
//## Subsystem: BADLL%4421755F0157
//## Source file: C:\Devel\Dn\Server\Library\BADLL\CXOSBA03.cpp

//## begin module%442185F600AB.additionalIncludes preserve=no
//## end module%442185F600AB.additionalIncludes

//## begin module%442185F600AB.includes preserve=yes
#include "CXODIF03.hpp"
#include "CXODTM04.hpp"
#include "CXODTM06.hpp"
#include "CXODES27.hpp"
#include "CXODEC01.hpp"
#include "CXODBS07.hpp"
#include "CXODRS13.hpp"
#include "CXODRS36.hpp"
#include "CXODEX17.hpp"
#include "CXODRU10.hpp"
//## end module%442185F600AB.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSES36_h
#include "CXODES36.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSES18_h
#include "CXODES18.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSES39_h
#include "CXODES39.hpp"
#endif
#ifndef CXOSES40_h
#include "CXODES40.hpp"
#endif
#ifndef CXOSES17_h
#include "CXODES17.hpp"
#endif
#ifndef CXOSES34_h
#include "CXODES34.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSEX01_h
#include "CXODEX01.hpp"
#endif
#ifndef CXOSEX28_h
#include "CXODEX28.hpp"
#endif
#ifndef CXOSES47_h
#include "CXODES47.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSEX27_h
#include "CXODEX27.hpp"
#endif
#ifndef CXOSES02_h
#include "CXODES02.hpp"
#endif
#ifndef CXOSVS07_h
#include "CXODVS07.hpp"
#endif
#ifndef CXOSBA03_h
#include "CXODBA03.hpp"
#endif


//## begin module%442185F600AB.declarations preserve=no
//## end module%442185F600AB.declarations

//## begin module%442185F600AB.additionalDeclarations preserve=yes
#define STS_DATABASE_FAILURE 15
#define STS_DUPLICATE_RECORD 35
#define STS_INVALID_TRANSITION 48
#define STS_SMTP_OPEN_FAILURE 53
//## end module%442185F600AB.additionalDeclarations


//## Modelname: Platform \: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
//## begin bamsprocessing%4421791802DE.initialDeclarations preserve=yes
//## end bamsprocessing%4421791802DE.initialDeclarations

// Class bamsprocessing::BAMSException 

BAMSException::BAMSException()
  //## begin BAMSException::BAMSException%442185560261_const.hasinit preserve=no
      : m_dAMT_ADJUSTMENT(0),
        m_dAMT_TRAN(0),
        m_pBuffer(0)
  //## end BAMSException::BAMSException%442185560261_const.hasinit
  //## begin BAMSException::BAMSException%442185560261_const.initialization preserve=yes
  //## end BAMSException::BAMSException%442185560261_const.initialization
{
  //## begin bamsprocessing::BAMSException::BAMSException%442185560261_const.body preserve=yes
   memcpy(m_sID,"VE03",4);
   m_strACTUAL_MSG.reserve(3500);
   m_pBuffer = new char[512];
   Database::instance()->attach(this);
   reset();
  //## end bamsprocessing::BAMSException::BAMSException%442185560261_const.body
}


BAMSException::~BAMSException()
{
  //## begin bamsprocessing::BAMSException::~BAMSException%442185560261_dest.body preserve=yes
   Database::instance()->detach(this);
   delete [] m_pBuffer;
  //## end bamsprocessing::BAMSException::~BAMSException%442185560261_dest.body
}



//## Other Operations (implementation)
void BAMSException::addComment ()
{
  //## begin bamsprocessing::BAMSException::addComment%45A28E53029F.body preserve=yes
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   Table hTable("EMS_COMMENT");
   CaseCommentSegment::instance()->setColumns(hTable);
   if (!pInsertStatement->execute(hTable))
      m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " was not created/updated.  Comment record could not be created.";
  //## end bamsprocessing::BAMSException::addComment%45A28E53029F.body
}

void BAMSException::appendACTUAL_MSG (const string& strValue)
{
  //## begin bamsprocessing::BAMSException::appendACTUAL_MSG%4429710900EA.body preserve=yes
   if (m_strACTUAL_MSG.length() + strValue.length() < 3500)
      m_strACTUAL_MSG += strValue;
  //## end bamsprocessing::BAMSException::appendACTUAL_MSG%4429710900EA.body
}

void BAMSException::bind (reusable::Query& hQuery)
{
  //## begin bamsprocessing::BAMSException::bind%44295C9601A5.body preserve=yes
   hQuery.reset();
   hQuery.join("EMS_CASE","INNER","EMS_TRANSITION","CASE_ID");
   hQuery.join("EMS_CASE","INNER","EMS_TRANSITION","STATE_TSTAMP","TSTAMP_CREATED");
   hQuery.join("EMS_TRANSITION","INNER","EMS_PHASE","CASE_ID");
   hQuery.join("EMS_TRANSITION","INNER","EMS_PHASE","PHASE_TSTAMP","TSTAMP_CREATED");
   hQuery.join("EMS_CASE","INNER","EMS_NATIONAL_NET","CASE_ID");
   CaseSegment::instance()->bind(hQuery);
   CasePhaseSegment::instance()->bind(hQuery);
   CaseTransitionSegment::instance()->bind(hQuery);
   if (m_strNET_ID_EMS == "VNT")
   {
      hQuery.join("EMS_CASE","INNER","EMS_CASE_VNT","CASE_ID");
      hQuery.join("EMS_TRANSITION","INNER","EMS_PHASE_VNT","CASE_ID");
      hQuery.join("EMS_TRANSITION","INNER","EMS_PHASE_VNT","PHASE_TSTAMP","TSTAMP_CREATED");
      CaseVisaSegment::instance()->bind(hQuery);
      CasePhaseVisaSegment::instance()->bind(hQuery);
   }
   else if (m_strNET_ID_EMS == "MCI")
   {
      hQuery.join("EMS_CASE","INNER","EMS_CASE_MCI","CASE_ID");
      hQuery.join("EMS_TRANSITION","INNER","EMS_PHASE_MCI","CASE_ID");
      hQuery.join("EMS_TRANSITION","INNER","EMS_PHASE_MCI","PHASE_TSTAMP","TSTAMP_CREATED");
      CaseMCSegment::instance()->bind(hQuery);
      CasePhaseMCSegment::instance()->bind(hQuery);
   }
  //## end bamsprocessing::BAMSException::bind%44295C9601A5.body
}

bool BAMSException::createDuplicateCase ()
{
  //## begin bamsprocessing::BAMSException::createDuplicateCase%4AAE64D90266.body preserve=yes
   CaseSegment::instance()->setCASE_NO("");
   CaseSegment::instance()->setCASE_ID(0);
   int lDUP_SEQ_NO = CaseSegment::instance()->getDUP_SEQ_NO() + 1;
   CaseSegment::instance()->setDUP_SEQ_NO(lDUP_SEQ_NO);
   CasePhaseSegment::instance()->setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   CasePhaseSegment::instance()->setREQUEST_TYPE("INIT");
   CaseSegment::instance()->setREQUEST_TYPE("INIT");
   CaseSegment::instance()->setSTATUS("TEMP");
   CaseTransitionSegment::instance()->setSTATUS_PREV("TEMP");
   CaseTransitionSegment::instance()->setREQUEST_TYPE_PREV("INIT");
   CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT(m_strREQUEST_TYPE);
   if (CaseSegment::instance()->getTSTAMP_TRANS().length() == 0)
   {
      CaseTransitionSegment::instance()->setSTATUS_NEXT("HOLD");
      if (!NationalException::instance()->createCase("UNMD", m_strNET_ID_EMS,"A"))
         return false;
   }
   else
   {
      CaseTransitionSegment::instance()->setSTATUS_NEXT("SDRC");
      if (!NationalException::instance()->createCase(m_strREQUEST_TYPE, m_strNET_ID_EMS,"A"))
         return false;
   }
   return true;
  //## end bamsprocessing::BAMSException::createDuplicateCase%4AAE64D90266.body
}

void BAMSException::initializeListSegment ()
{
  //## begin bamsprocessing::BAMSException::initializeListSegment%44DC66250280.body preserve=yes
   m_pCaseCreateCommand = (CaseCreateCommand*)NationalException::instance()->getCaseCreateCommand();
  //## end bamsprocessing::BAMSException::initializeListSegment%44DC66250280.body
}

void BAMSException::mapFinancialData ()
{
  //## begin bamsprocessing::BAMSException::mapFinancialData%4429A3C600CB.body preserve=yes
   Trace::put("mapFinancialData");
   CaseSegment::instance()->setFinancialData();
   if (CaseSegment::instance()->getNET_ID_ISS().length() == 0)
   {
      mapUnmatchedData();
      return;
   }
   CasePhaseSegment::instance()->setFinancialData();
   if (m_strNET_ID_EMS == "MCI")
   {
      CaseMCSegment::instance()->setFinancialData();
      CaseMCSegment::instance()->setBUS_DATE(m_strDateReceived);
      CasePhaseMCSegment::instance()->setMC_MMT(m_strMMT);
   }
   else
   {
      PersistentSegment *pCaseUniqueSegment = Case::instance()->getNetworkUniqueSegment ('C');
      pCaseUniqueSegment->setFinancialData();
   }

   if (m_strNET_ID_EMS == "VNT")
   {
      CasePhaseVisaSegment::instance()->setFinancialData();
      CaseVisaSegment::instance()->setB2_CPD_DN_FMT(CaseSegment::instance()->getDATE_RECON_NET());
      Date hDate(CaseSegment::instance()->getDATE_RECON_NET().c_str());
      string strYDDD("");
      if (CaseSegment::instance()->getDATE_RECON_NET().length() > 3)
         strYDDD = CaseSegment::instance()->getDATE_RECON_NET().substr(3,1).c_str();
      strYDDD += hDate.asString("%j");
      CaseVisaSegment::instance()->setB2_CPD_VISA_FMT(strYDDD);
      size_t pos = m_strTransactionID.find_first_of("%");
      if (pos != string::npos)
         m_strTransactionID.erase(pos);
      CaseVisaSegment::instance()->setTRAN_IDENTIFIER(m_strTransactionID);
      CasePhaseVisaSegment::instance()->setB2_CPD_VISA_FMT(m_strDateReceivedJulian);
      CasePhaseVisaSegment::instance()->setB2_CPD_DN_FMT(m_strDateReceived);
      CasePhaseVisaSegment::instance()->setVISA_MMT(m_strMMT);
   }
   else
   {
      PersistentSegment *pCasePhaseUniqueSegment = Case::instance()->getNetworkUniqueSegment ('P');
      pCasePhaseUniqueSegment->setFinancialData();
   }

   CasePreAuthSegment::instance()->setDefault();
   CasePreAuthSegment::instance()->setFinancialData();
   CaseNationalNetworkSegment::instance()->setAUTH_FOUND_FLG("N");
   //Need to save this because the ACQ_REF_NO is not getting saved on the tran
   string strACQ_REF_NO(CaseNationalNetworkSegment::instance()->getACQ_REF_NO());
   CaseNationalNetworkSegment::instance()->setFinancialData();
   CaseNationalNetworkSegment::instance()->setACQ_REF_NO(strACQ_REF_NO);
   CasePhaseSegment::instance()->setAMT_ADJUSTMENT(m_dAMT_ADJUSTMENT);
   CasePhaseSegment::instance()->setAMT_ADJ_TRAN(m_dAMT_ADJUSTMENT);
   CasePhaseSegment::instance()->setCUR_ADJUSTMENT(m_strCUR_ADJUSTMENT);
   CasePhaseSegment::instance()->setCUR_ADJ_TRAN(m_strCUR_ADJUSTMENT);
  //## end bamsprocessing::BAMSException::mapFinancialData%4429A3C600CB.body
}

void BAMSException::mapUnmatchedData ()
{
  //## begin bamsprocessing::BAMSException::mapUnmatchedData%4496AF6D01D4.body preserve=yes
   Trace::put("mapUnmatchedData");
   CaseSegment::instance()->setCUR_TRAN("840");
   CaseSegment::instance()->setAMT_TRAN(m_dAMT_TRAN);
   CaseSegment::instance()->setNET_ID_ISS(m_strNET_ID_EMS);
   CasePhaseSegment::instance()->setAMT_ADJUSTMENT(m_dAMT_ADJUSTMENT);
   CasePhaseSegment::instance()->setAMT_ADJ_TRAN(m_dAMT_ADJUSTMENT);
   CasePhaseSegment::instance()->setCUR_ADJUSTMENT(m_strCUR_ADJUSTMENT);
   CasePhaseSegment::instance()->setCUR_ADJ_TRAN(m_strCUR_ADJUSTMENT);
   CaseSegment::instance()->setRETRIEVAL_REF_NO("");
   size_t pos = m_strTransactionID.find_first_of("%");
   if (pos != string::npos)
      m_strTransactionID.erase(pos);
   if (m_strNET_ID_EMS == "MCI")
   {
      CaseMCSegment::instance()->setBUS_DATE(m_strDateReceived);
      CaseMCSegment::instance()->setLIFECYCLE_TRACE_ID(m_strTransactionID);
      CasePhaseMCSegment::instance()->setMC_MMT(m_strMMT);
   }
   else if (m_strNET_ID_EMS == "VNT")
   {
      CaseVisaSegment::instance()->setB2_CPD_DN_FMT(CaseSegment::instance()->getDATE_RECON_NET());
      Date hDate(CaseSegment::instance()->getDATE_RECON_NET().c_str());
      string strYDDD("");
      if (CaseSegment::instance()->getDATE_RECON_NET().length() > 3)
         strYDDD = CaseSegment::instance()->getDATE_RECON_NET().substr(3,1).c_str();
      strYDDD += hDate.asString("%j");
      CaseVisaSegment::instance()->setB2_CPD_VISA_FMT(strYDDD);
      CaseVisaSegment::instance()->setTRAN_IDENTIFIER(m_strTransactionID);
      CasePhaseVisaSegment::instance()->setB2_CPD_VISA_FMT(m_strDateReceivedJulian);
      CasePhaseVisaSegment::instance()->setB2_CPD_DN_FMT(m_strDateReceived);
      CasePhaseVisaSegment::instance()->setVISA_MMT(m_strMMT);
   }
  //## end bamsprocessing::BAMSException::mapUnmatchedData%4496AF6D01D4.body
}

bool BAMSException::processCase ()
{
  //## begin bamsprocessing::BAMSException::processCase%442956B10290.body preserve=yes
   bool bReturn = true;
   bool bMatchingCase;
   if (!retrieveCase(bMatchingCase))
      return false;
   CasePhaseSegment::instance()->setREASON_CODE(m_strREASON_CODE);
   CasePhaseSegment::instance()->setDATE_RECONYYYYMMDD(m_strDateReceived);
   if (m_strREQUEST_TYPE != "ARB" && m_siPurpose == 3)
      bReturn = processReject(bMatchingCase);
   else if (m_strREQUEST_TYPE == "DOCR")
      bReturn = processRetrievalRequest(bMatchingCase);
   else if (m_strREQUEST_TYPE == "CHB1")
      bReturn = processChargeback(bMatchingCase);
   else if (m_strREQUEST_TYPE == "REP1")
      bReturn = processRepresentment(bMatchingCase);
   else if (m_strREQUEST_TYPE == "CHB2")
      bReturn = process2ndChargeback(bMatchingCase);
   else if (m_strREQUEST_TYPE == "ARB")  
      bReturn = processMasterCardArbitration(bMatchingCase);
   else if (m_strREQUEST_TYPE == "PARB")  
      bReturn = processVisaArbitration(bMatchingCase);

   m_pCaseCreateCommand->getListSegment(0)->reset();
   if (CaseSegment::instance()->getRETRIEVAL_REF_NO().length() == 0)
   {
      m_strRETRIEVAL_REF_NO.erase(0,1);
      m_strRETRIEVAL_REF_NO.insert(0,"____",4);
      CaseSegment::instance()->setRETRIEVAL_REF_NO(m_strRETRIEVAL_REF_NO);
   }
   return bReturn;
  //## end bamsprocessing::BAMSException::processCase%442956B10290.body
}

bool BAMSException::processChargeback (bool bMatchingCase)
{
  //## begin bamsprocessing::BAMSException::processChargeback%44296DCD005D.body preserve=yes
   Trace::put("processChargeback");
   m_strErrorText.erase();
   CaseSegment::instance()->setACQ_USER_ID("TPPIMPRT");
   CaseSegment::instance()->setAMT_TRAN(m_dAMT_TRAN);
   switch (m_siPurpose)
   {
      case 4: // debit chargeback
         CasePhaseSegment::instance()->setACTION_TO_CARDHLDR("D"); break;
      case 5: //chargeback reversal
      {
         int iFWRDCount = 0;
         int iSDRCCount = 0;
         short iNull;
         Query hQuery;
         hQuery.bind("EMS_TRANSITION","*",Column::LONG,&iFWRDCount,&iNull,"COUNT");
         hQuery.setBasicPredicate("EMS_TRANSITION","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
         hQuery.setBasicPredicate("EMS_TRANSITION","REQUEST_TYPE_NEXT","=","REP1");
         hQuery.setBasicPredicate("EMS_TRANSITION","STATUS_NEXT","=","FWRD");
         auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
         pSelectStatement->execute(hQuery);
         if (pSelectStatement->getRows() > 0)
         {
            hQuery.reset();
            hQuery.bind("EMS_TRANSITION","*",Column::LONG,&iSDRCCount,&iNull,"COUNT");
            hQuery.setBasicPredicate("EMS_TRANSITION","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
            hQuery.setBasicPredicate("EMS_TRANSITION","REQUEST_TYPE_NEXT","=","REP1");
            hQuery.setBasicPredicate("EMS_TRANSITION","STATUS_NEXT","=","SDRC");
         }
         if (iFWRDCount != iSDRCCount
            || (CaseSegment::instance()->getREQUEST_TYPE() == "REP1" 
            && CaseSegment::instance()->getSTATUS() == "PNDR"))
         {
            ;
         }
         else
         {
            if (CasePhaseSegment::instance()->getACTION_TO_CARDHLDR() == "C")
               CasePhaseSegment::instance()->setACTION_TO_CARDHLDR("D");
            else
               CasePhaseSegment::instance()->setACTION_TO_CARDHLDR("C");
         }
         break;
      }
      default: // credit chargeback
         CasePhaseSegment::instance()->setACTION_TO_CARDHLDR("C"); break;
   }
   if (!bMatchingCase)
   {
      CasePhaseSegment::instance()->setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
      CaseSegment::instance()->setOTHER_CASE_NO(m_strOTHER_CASE_NO);
      bool bReturn = retrieveTransaction();
      if (!bReturn)
         bReturn = retrieveTransaction(true);
      if (m_strNET_ID_EMS == "MCI")
         CasePhaseMCSegment::instance()->setCARD_ISS_REF_DATA(m_strIssuerRefNo);
      else if (m_strNET_ID_EMS == "VNT")
         CasePhaseVisaSegment::instance()->setCHB_REF_NO(m_strIssuerRefNo);
      if (CaseDocumentSegment::instance()->presence() && !setDocumentFields())
      {
         m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " was not created.  Document record could not be created.";
         return false;
      }
      if (bReturn) //matching tran
      {
         mapFinancialData();
         if (FinancialBaseSegment::instance()->presence())
            FinancialBaseSegment::instance()->setPresence(false);
         if (m_siPurpose == 5)
         {
            CaseSegment::instance()->setSTATUS("SDRC");
            CaseTransitionSegment::instance()->setSTATUS_PREV("SDRC");
            CaseTransitionSegment::instance()->setSTATUS_NEXT("RVRD");
            CaseTransitionSegment::instance()->setREQUEST_TYPE_PREV(m_strREQUEST_TYPE);
            CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT(m_strREQUEST_TYPE);
            if (!NationalException::instance()->createCase("UNMD", m_strNET_ID_EMS,"A"))
               setErrorText();
         }
         else if (!NationalException::instance()->createCase(m_strREQUEST_TYPE, m_strNET_ID_EMS,"A"))
            setErrorText();
      }
      else
      {
         mapUnmatchedData();
         if (m_siPurpose == 5)
         {
            CaseSegment::instance()->setSTATUS("RVRD");
            CaseTransitionSegment::instance()->setSTATUS_PREV("RVRD");
            CaseTransitionSegment::instance()->setSTATUS_NEXT("CLUV");
            CaseTransitionSegment::instance()->setREQUEST_TYPE_PREV(m_strREQUEST_TYPE);
         }
         else
         {
            CaseSegment::instance()->setREQUEST_TYPE("INIT");
            CaseSegment::instance()->setSTATUS("TEMP");
            CaseTransitionSegment::instance()->setSTATUS_PREV("TEMP");
            CaseTransitionSegment::instance()->setSTATUS_NEXT("HOLD");
            CaseTransitionSegment::instance()->setREQUEST_TYPE_PREV("INIT");
         }
         CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT(m_strREQUEST_TYPE);
         if (!NationalException::instance()->createCase("UNMD", m_strNET_ID_EMS,"A"))
            setErrorText();
      }
   }
   else //found a matching case
   {
      if (m_dAMT_ADJUSTMENT != 0)
      {
         CasePhaseSegment::instance()->setAMT_ADJUSTMENT(m_dAMT_ADJUSTMENT);
         CasePhaseSegment::instance()->setAMT_ADJ_TRAN(m_dAMT_ADJUSTMENT);
         CasePhaseSegment::instance()->setCUR_ADJUSTMENT(m_strCUR_ADJUSTMENT);
         CasePhaseSegment::instance()->setCUR_ADJ_TRAN(m_strCUR_ADJUSTMENT);
      }
      if (CaseDocumentSegment::instance()->presence() && !setDocumentFields())
         m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " was not updated.  Document record could not be created.";
      if (m_strNET_ID_EMS == "MCI")
      {
         CaseMCSegment::instance()->setBUS_DATE(m_strDateReceived);
         CasePhaseMCSegment::instance()->setMC_MMT(m_strMMT);
         CasePhaseMCSegment::instance()->setCARD_ISS_REF_DATA(m_strIssuerRefNo);
      }
      else if (m_strNET_ID_EMS == "VNT")
      {
         CasePhaseVisaSegment::instance()->setB2_CPD_VISA_FMT(m_strDateReceivedJulian);
         CasePhaseVisaSegment::instance()->setB2_CPD_DN_FMT(m_strDateReceived);
         CasePhaseVisaSegment::instance()->setVISA_MMT(m_strMMT);
         CasePhaseVisaSegment::instance()->setCHB_REF_NO(m_strIssuerRefNo);
      }

      bool bAddDup = false;
      int m = 0;
      short iNull;
      Query hQuery;
      hQuery.reset();
      hQuery.bind("EMS_TRANSITION","*",Column::LONG,&m,&iNull,"COUNT");
      hQuery.setBasicPredicate("EMS_TRANSITION","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
      hQuery.setBasicPredicate("EMS_TRANSITION","REQUEST_TYPE_NEXT","=","CHB1");
      hQuery.setBasicPredicate("EMS_TRANSITION","STATUS_NEXT","=","SDRC");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      pSelectStatement->execute(hQuery);
      if (m_siPurpose != 5 && ((CaseSegment::instance()->getREQUEST_TYPE() == "DOCR" 
         && (CaseSegment::instance()->getSTATUS() == "SDRC"
         || CaseSegment::instance()->getSTATUS() == "HOLD"))
         || (CaseSegment::instance()->getREQUEST_TYPE() == "CHB1" 
         && CaseSegment::instance()->getSTATUS() == "HOLD")
         || m > 0  //if case is in DOCR or CHB1/HOLD or already has a CHB1/SDRC state & not incoming rev
         || (CaseSegment::instance()->getOTHER_CASE_NO().length()
         && m_strOTHER_CASE_NO.length()
         && CaseSegment::instance()->getOTHER_CASE_NO().substr(1) != m_strOTHER_CASE_NO.substr(1))))
      {
         if (m > 0)
         {
            int iSDRCRows = m;
            hQuery.reset();
            hQuery.bind("EMS_TRANSITION","*",Column::LONG,&m,&iNull,"COUNT");
            hQuery.setBasicPredicate("EMS_TRANSITION","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
            hQuery.setBasicPredicate("EMS_TRANSITION","REQUEST_TYPE_NEXT","=","CHB1");
            hQuery.setBasicPredicate("EMS_TRANSITION","STATUS_NEXT","=","RVRD");
            pSelectStatement->execute(hQuery);
            bAddDup = (m != iSDRCRows) ? true : false;
         }
         else
            bAddDup = true;
      }
      CaseSegment::instance()->setOTHER_CASE_NO(m_strOTHER_CASE_NO);
      if (bAddDup)
      {
         if (!createDuplicateCase())
            setErrorText();
      }
      else
      {
         Table hEMSCaseDataChg("EMS_DATA_CHG");
         auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
         CaseAddEventVisitor hCaseAddEventVisitor(&hEMSCaseDataChg,pInsertStatement.get());
         hEMSCaseDataChg.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
         hEMSCaseDataChg.set("USER_ID","SYSTEM");
         hEMSCaseDataChg.set("TSTAMP_CREATED",Clock::instance()->getYYYYMMDDHHMMSSHN());
         if (m_strNET_ID_EMS == "MCI")
         {
            CaseMCSegment::instance()->setBUS_DATE(m_strDateReceived);
            Table hTable("EMS_CASE_MCI");
            CaseMCSegment::instance()->setColumns(hTable);
            hTable.setAudit(true);
            if (!pUpdateStatement->execute(hTable))
               return false;

            hTable.accept(hCaseAddEventVisitor);
            if (!hCaseAddEventVisitor.successful())
               return false;
         }

         if (m_siPurpose == 5)
         {
            if (CaseSegment::instance()->getREQUEST_TYPE() == "CHB1" //put in for duplicate processing
               && CaseSegment::instance()->getSTATUS() == "RVRD")
               m_strErrorText = "Record dropped as duplicate of case " + CaseSegment::instance()->getCASE_NO();
            else 
            {
               if (CaseSegment::instance()->getREQUEST_TYPE() != "CHB1")
                  CasePhaseSegment::instance()->setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
               else
               {
                  Table hTable("EMS_PHASE");
                  CasePhaseSegment::instance()->setColumns(hTable);
                  hTable.setAudit(true);
                  if (!pUpdateStatement->execute(hTable))
                     return false;
                  hTable.accept(hCaseAddEventVisitor);
                  if (!hCaseAddEventVisitor.successful())
                     return false;
               }
               if (!NationalException::instance()->transitionCase("RVRD", m_strREQUEST_TYPE)
                  || !updateTransition())
                  m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " cannot be transitioned to Chargeback Reversal Received.";
            }
         }
         else
         {
            if (CaseSegment::instance()->getREQUEST_TYPE() == "CHB1")
            {
               Table hTable("EMS_PHASE");
               CasePhaseSegment::instance()->setColumns(hTable);
               hTable.setAudit(true);
               if (!pUpdateStatement->execute(hTable))
                  return false;
               hTable.accept(hCaseAddEventVisitor);
               if (!hCaseAddEventVisitor.successful())
                  return false;
            }
            else
               CasePhaseSegment::instance()->setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
            if (!NationalException::instance()->transitionCase("SDRC", m_strREQUEST_TYPE)
               || !updateTransition())
               m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " cannot be transitioned to Chargeback Sent/Received.";
         }
         if (m_strErrorText.length() == 0)
         {
            if (CaseDocumentSegment::instance()->presence())
            {
               auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
               Table hTable("EMS_DOCUMENT");
               CaseDocumentSegment::instance()->setColumns(hTable);
               if (!pInsertStatement->execute(hTable))
                  m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " was not updated.  Document record could not be created.";
            }
            if (CaseCommentSegment::instance()->presence())
               addComment();
         }
      }
   }
   if (m_strErrorText.length())
      return false;
   else
      setSTATE_EXPIR_TSTAMP();
   return true;
  //## end bamsprocessing::BAMSException::processChargeback%44296DCD005D.body
}

bool BAMSException::process2ndChargeback (bool bMatchingCase)
{
  //## begin bamsprocessing::BAMSException::process2ndChargeback%49876F230203.body preserve=yes
   Trace::put("process2ndChargeback");
   m_strErrorText.erase();
   if (!bMatchingCase || (bMatchingCase && m_siPurpose != 5))
      CasePhaseSegment::instance()->setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   switch (m_siPurpose)
   {
      case 4: // credit chargeback
         CasePhaseSegment::instance()->setACTION_TO_CARDHLDR("D"); break;
      case 5: //chargeback reversal
      {
         if (CaseSegment::instance()->getREQUEST_TYPE() == "ARB" 
            && (CaseSegment::instance()->getSTATUS() == "PNDR"
            || CaseSegment::instance()->getSTATUS() == "SDRC"))
         {
            ;
         }
         else
         {
            if (CasePhaseSegment::instance()->getACTION_TO_CARDHLDR() == "C")
               CasePhaseSegment::instance()->setACTION_TO_CARDHLDR("D");
            else
               CasePhaseSegment::instance()->setACTION_TO_CARDHLDR("C");
         }
         break;
      }
      default: // debit chargeback
         CasePhaseSegment::instance()->setACTION_TO_CARDHLDR("C"); break;
   }
   if (!bMatchingCase)
   {
      CaseSegment::instance()->setACQ_USER_ID("TPPIMPRT");
      CaseSegment::instance()->setOTHER_CASE_NO(m_strOTHER_CASE_NO);
      CaseSegment::instance()->setAMT_TRAN(m_dAMT_TRAN);
      bool bReturn = retrieveTransaction();
      if (!bReturn)
         bReturn = retrieveTransaction(true);
      CasePhaseMCSegment::instance()->setCARD_ISS_REF_DATA(m_strIssuerRefNo);
      if (CaseDocumentSegment::instance()->presence() && !setDocumentFields())
      {
         m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " was not created.  Document record could not be created.";
         return false;
      }
      if (bReturn) //matching tran
      {
         mapFinancialData();
         if (FinancialBaseSegment::instance()->presence())
            FinancialBaseSegment::instance()->setPresence(false);
         if (!NationalException::instance()->createCase(m_strREQUEST_TYPE, m_strNET_ID_EMS,"A"))
            setErrorText();
      }
      else
      {
         mapUnmatchedData();
         CaseSegment::instance()->setREQUEST_TYPE("INIT");
         CaseSegment::instance()->setSTATUS("TEMP");
         CaseTransitionSegment::instance()->setSTATUS_PREV("TEMP");
         CaseTransitionSegment::instance()->setSTATUS_NEXT("HOLD");
         CaseTransitionSegment::instance()->setREQUEST_TYPE_PREV("INIT");
         CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT(m_strREQUEST_TYPE);
         if (!NationalException::instance()->createCase("UNMD", m_strNET_ID_EMS,"A"))
            setErrorText();
      }
   }
   else //found a matching case
   {
      CasePhaseSegment::instance()->setREASON_CODE(m_strREASON_CODE);
      CasePhaseSegment::instance()->setAMT_ADJUSTMENT(m_dAMT_ADJUSTMENT);
      CasePhaseSegment::instance()->setAMT_ADJ_TRAN(m_dAMT_ADJUSTMENT);
      CasePhaseSegment::instance()->setCUR_ADJUSTMENT(m_strCUR_ADJUSTMENT);
      CasePhaseSegment::instance()->setCUR_ADJ_TRAN(m_strCUR_ADJUSTMENT);
      CaseMCSegment::instance()->setBUS_DATE(m_strDateReceived);
      CasePhaseMCSegment::instance()->setMC_MMT(m_strMMT);
      CasePhaseMCSegment::instance()->setCARD_ISS_REF_DATA(m_strIssuerRefNo);

      bool bAddDup = false;
      int m = 0;
      short iNull;
      Query hQuery;
      hQuery.reset();
      hQuery.bind("EMS_TRANSITION","*",Column::LONG,&m,&iNull,"COUNT");
      hQuery.setBasicPredicate("EMS_TRANSITION","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
      hQuery.setBasicPredicate("EMS_TRANSITION","REQUEST_TYPE_NEXT","=","CHB2");
      hQuery.setBasicPredicate("EMS_TRANSITION","STATUS_NEXT","=","SDRC");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      pSelectStatement->execute(hQuery);
      if (m_siPurpose != 5 && ((CaseSegment::instance()->getREQUEST_TYPE() == "DOCR" 
         && (CaseSegment::instance()->getSTATUS() == "SDRC"
         || CaseSegment::instance()->getSTATUS() == "HOLD"))
         || (CaseSegment::instance()->getREQUEST_TYPE() == "CHB2" 
         && CaseSegment::instance()->getSTATUS() == "HOLD")
         || m > 0  //if case is in DOCR or CHB2/HOLD or already has a CHB2/SDRC state & not incoming rev
         || (CaseSegment::instance()->getOTHER_CASE_NO().length() 
         && m_strOTHER_CASE_NO.length()
         && CaseSegment::instance()->getOTHER_CASE_NO().substr(1) != m_strOTHER_CASE_NO.substr(1))))
      {
         if (m > 0)
         {
            int iSDRCRows = m;
            hQuery.reset();
            hQuery.bind("EMS_TRANSITION","*",Column::LONG,&m,&iNull,"COUNT");
            hQuery.setBasicPredicate("EMS_TRANSITION","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
            hQuery.setBasicPredicate("EMS_TRANSITION","REQUEST_TYPE_NEXT","=","CHB2");
            hQuery.setBasicPredicate("EMS_TRANSITION","STATUS_NEXT","=","RVRD");
            pSelectStatement->execute(hQuery);
            bAddDup = (m != iSDRCRows 
               && (CaseSegment::instance()->getOTHER_CASE_NO().length() 
               && m_strOTHER_CASE_NO.length()
               && CaseSegment::instance()->getOTHER_CASE_NO().substr(1) != m_strOTHER_CASE_NO.substr(1))) ? true : false;
         }
         else
            bAddDup = true;
      }
      CaseSegment::instance()->setOTHER_CASE_NO(m_strOTHER_CASE_NO);
      if (bAddDup)
      {
         if (CaseDocumentSegment::instance()->presence() && !setDocumentFields())
         {
            m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " was not created.  Document record could not be created.";
            return false;
         }
         if (!createDuplicateCase())
            setErrorText();
      }
      else
      {
         Table hEMSCaseDataChg("EMS_DATA_CHG");
         auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
         CaseAddEventVisitor hCaseAddEventVisitor(&hEMSCaseDataChg,pInsertStatement.get());
         hEMSCaseDataChg.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
         hEMSCaseDataChg.set("USER_ID","SYSTEM");
         hEMSCaseDataChg.set("TSTAMP_CREATED",Clock::instance()->getYYYYMMDDHHMMSSHN());
         Table hTable("EMS_CASE_MCI");
         CaseMCSegment::instance()->setColumns(hTable);
         hTable.setAudit(true);
         if (!pUpdateStatement->execute(hTable))
            return false;

         hTable.accept(hCaseAddEventVisitor);
         if (!hCaseAddEventVisitor.successful())
            return false;

         if (m_siPurpose == 5)
         {
            if (CaseSegment::instance()->getREQUEST_TYPE() == "CHB2"
               && CaseSegment::instance()->getSTATUS() == "RVRD")
               m_strErrorText = "Record dropped as duplicate of case " + CaseSegment::instance()->getCASE_NO();
            else 
            {
               if (!NationalException::instance()->transitionCase("RVRD", m_strREQUEST_TYPE)
                  || !updateTransition())
                  m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " cannot be transitioned to 2nd Chargeback Reversal Received.";
               else
               {
                  Table hTable("EMS_PHASE");
                  CasePhaseSegment::instance()->setColumns(hTable);
                  hTable.setAudit(true);
                  if (!pUpdateStatement->execute(hTable))
                     return false;
                  hTable.accept(hCaseAddEventVisitor);
                  if (!hCaseAddEventVisitor.successful())
                     return false;
               }
            }
         }
         else
         {
            if (!NationalException::instance()->transitionCase("SDRC", m_strREQUEST_TYPE)
               || !updateTransition())
               m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " cannot be transitioned to 2nd Chargeback Sent/Received.";
         }
         if (m_strErrorText.length() == 0)
         {
            if (CaseDocumentSegment::instance()->presence())
            {
               if (setDocumentFields())
               {
                  auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
                  Table hTable("EMS_DOCUMENT");
                  CaseDocumentSegment::instance()->setColumns(hTable);
                  if (!pInsertStatement->execute(hTable))
                     m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " was not updated.  Document record could not be created.";
               }
               else
                  m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " was not updated.  Document record could not be created.";
            }
            if (CaseCommentSegment::instance()->presence())
               addComment();
         }
      }
   }
   if (m_strErrorText.length())
      return false;
   else
      setSTATE_EXPIR_TSTAMP();
   return true;
  //## end bamsprocessing::BAMSException::process2ndChargeback%49876F230203.body
}

bool BAMSException::processMasterCardArbitration (bool bMatchingCase)
{
  //## begin bamsprocessing::BAMSException::processMasterCardArbitration%498317EF00CB.body preserve=yes
   Trace::put("processMasterCardArbitration");
   m_strErrorText.erase();
   if (!bMatchingCase)
   {
      m_strErrorText = "A matching case could not be found to transition "
         " to an arb status for BAMS case " 
         + CaseSegment::instance()->getOTHER_CASE_NO(); 
   }
   else
   {
      m_strREQUEST_TYPE = "ARB";
      string strSTATUS = "ACPS";
      if (m_siPurpose == 3)
         strSTATUS = "DNYS";

      if (CaseSegment::instance()->getREQUEST_TYPE() != "ARB")
         CasePhaseSegment::instance()->setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
      CaseSegment::instance()->setOTHER_CASE_NO(m_strOTHER_CASE_NO);
      if (!NationalException::instance()->transitionCase(strSTATUS, m_strREQUEST_TYPE))
      {
         switch (m_siPurpose)
         {
            case 2: 
               m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + 
                  " cannot be transitioned to Arbitration Acceptance Received.";
               break;
            case 3: 
               m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + 
                  " cannot be transitioned to Arbitration Denial Received.";
               break;
            default: 
               m_strErrorText = "Invalid Purpose field for case " + 
                  CaseSegment::instance()->getCASE_NO() + ".";
               break;
         }
      }
   }
   if (m_strErrorText.length())
      return false;
   else
   {
      if (CaseDocumentSegment::instance()->presence())
      {
         auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         Table hTable("EMS_DOCUMENT");
         CaseDocumentSegment::instance()->setColumns(hTable);
         if (!pInsertStatement->execute(hTable))
            m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " was not updated.  Document record could not be created.";
      }
      if (CaseCommentSegment::instance()->presence())
         addComment();
      setSTATE_EXPIR_TSTAMP();
   }
   return true;
  //## end bamsprocessing::BAMSException::processMasterCardArbitration%498317EF00CB.body
}

bool BAMSException::processReject (bool bMatchingCase)
{
  //## begin bamsprocessing::BAMSException::processReject%445A0170029F.body preserve=yes
   m_strErrorText.erase();
   if (!bMatchingCase)
   {
      m_strErrorText = "A matching case could not be found to transition "
         " to a reject status for BAMS case " 
         + CaseSegment::instance()->getOTHER_CASE_NO(); 
   }
   else
   {
      CaseSegment::instance()->setOTHER_CASE_NO(m_strOTHER_CASE_NO);
      if (!NationalException::instance()->transitionCase("REJR"))
         m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " cannot be transitioned to Reject Received.";
   }
   if (m_strErrorText.length())
      return false;
   else
   {
      if (CaseCommentSegment::instance()->presence())
         addComment();
      setSTATE_EXPIR_TSTAMP();
   }
   return true;
  //## end bamsprocessing::BAMSException::processReject%445A0170029F.body
}

bool BAMSException::processRepresentment (bool bMatchingCase)
{
  //## begin bamsprocessing::BAMSException::processRepresentment%459B1E2F03D8.body preserve=yes
   Trace::put("processRepresentment");
   m_strErrorText.erase();
   if (m_strNET_ID_EMS == "MCI")
   {
      CaseMCSegment::instance()->setBUS_DATE(m_strDateReceived);
      CasePhaseMCSegment::instance()->setMC_MMT(m_strMMT);
   }
   else if (m_strNET_ID_EMS == "VNT")
   {
      CasePhaseVisaSegment::instance()->setB2_CPD_VISA_FMT(m_strDateReceivedJulian);
      CasePhaseVisaSegment::instance()->setB2_CPD_DN_FMT(m_strDateReceived);
      CasePhaseVisaSegment::instance()->setVISA_MMT(m_strMMT);
   }
   if (!bMatchingCase)
   {
      m_strErrorText = "Matching representment case could not be found " 
         "for BAMS case " + CaseSegment::instance()->getOTHER_CASE_NO();
      return false;
   }
   else
   {
      CasePhaseSegment::instance()->setREASON_CODE(m_strREASON_CODE);
      Table hEMSCaseDataChg("EMS_DATA_CHG");
      auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      CaseAddEventVisitor hCaseAddEventVisitor(&hEMSCaseDataChg,pInsertStatement.get());
      hEMSCaseDataChg.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
      hEMSCaseDataChg.set("USER_ID","SYSTEM");
      hEMSCaseDataChg.set("TSTAMP_CREATED",Clock::instance()->getYYYYMMDDHHMMSSHN());
      if (CaseSegment::instance()->getREQUEST_TYPE() != "REP1")
         CasePhaseSegment::instance()->setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
      else
      {
         Table hTable("EMS_PHASE");
         CasePhaseSegment::instance()->setColumns(hTable);
         hTable.setAudit(true);
         if (!pUpdateStatement->execute(hTable))
            return false;
         hTable.accept(hCaseAddEventVisitor);
         if (!hCaseAddEventVisitor.successful())
            return false;
         if (m_strNET_ID_EMS == "MCI")
         {
            CasePhaseMCSegment::instance()->setMC_MMT(m_strMMT);
            hTable.reset();
            hTable.setName("EMS_PHASE_MCI");
            CasePhaseMCSegment::instance()->setColumns(hTable);
            hTable.setAudit(true);
            if (!pUpdateStatement->execute(hTable))
               return false;
            hTable.accept(hCaseAddEventVisitor);
            if (!hCaseAddEventVisitor.successful())
               return false;
         }
         else if (m_strNET_ID_EMS == "VNT")
         {
            CasePhaseVisaSegment::instance()->setB2_CPD_VISA_FMT(m_strDateReceivedJulian);
            CasePhaseVisaSegment::instance()->setB2_CPD_DN_FMT(m_strDateReceived);
            CasePhaseVisaSegment::instance()->setVISA_MMT(m_strMMT);
            Table hTable("EMS_PHASE_VNT");
            CasePhaseVisaSegment::instance()->setColumns(hTable);
            hTable.setAudit(true);
            if (!pUpdateStatement->execute(hTable))
               return false;
            hTable.accept(hCaseAddEventVisitor);
            if (!hCaseAddEventVisitor.successful())
               return false;
         }
      }

      CaseSegment::instance()->setOTHER_CASE_NO(m_strOTHER_CASE_NO);
      if (!NationalException::instance()->transitionCase("SDRC", m_strREQUEST_TYPE))
         m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " cannot be transitioned to Representment Sent/Received.";
      if (m_strNET_ID_EMS == "MCI")
      {
         CaseMCSegment::instance()->setBUS_DATE(m_strDateReceived);
         Table hTable("EMS_CASE_MCI");
         CaseMCSegment::instance()->setColumns(hTable);
         hTable.setAudit(true);
         if (!pUpdateStatement->execute(hTable))
            return false;
         hTable.accept(hCaseAddEventVisitor);
         if (!hCaseAddEventVisitor.successful())
            return false;
      }
   }
   if (m_strErrorText.length())
      return false;
   else
   {
      if (CaseCommentSegment::instance()->presence())
         addComment();
      setSTATE_EXPIR_TSTAMP();
   }
   return true;
  //## end bamsprocessing::BAMSException::processRepresentment%459B1E2F03D8.body
}

bool BAMSException::processRetrievalRequest (bool bMatchingCase)
{
  //## begin bamsprocessing::BAMSException::processRetrievalRequest%44296D2502CE.body preserve=yes
   Trace::put("processRetrievalRequest");
   m_strErrorText.erase();
   CaseSegment::instance()->setACQ_USER_ID("TPPIMPRT");
   CaseSegment::instance()->setRETRIEVAL_REQ_ID(m_strRETRIEVAL_REQ_ID);
   CaseSegment::instance()->setOTHER_CASE_NO(m_strOTHER_CASE_NO);
   CaseSegment::instance()->setSTATE_EXPIR_TSTAMP(m_strSTATE_EXPIR_TSTAMP);
   CaseSegment::instance()->setAMT_TRAN(m_dAMT_TRAN);
   CasePhaseSegment::instance()->setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   if (m_strNET_ID_EMS == "VNT")
   {
      char szREASON_CODE[PERCENTD];
      snprintf(szREASON_CODE,sizeof(szREASON_CODE),"%04d",atoi(CasePhaseSegment::instance()->getREASON_CODE().c_str()));
      CasePhaseSegment::instance()->setREASON_CODE(szREASON_CODE);
      CasePhaseVisaSegment::instance()->setISSUER_CNTL_NO(m_strIssuerRefNo);
   }
   if (CaseDocumentSegment::instance()->presence() && !setDocumentFields())
      m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " was not updated.  Document record could not be created.";
   if (!bMatchingCase)
   {
      bool bReturn = retrieveTransaction();
      if (!bReturn)
         bReturn = retrieveTransaction(true);
      if (bReturn)
      {
         mapFinancialData();
         if (FinancialBaseSegment::instance()->presence())
            FinancialBaseSegment::instance()->setPresence(false);
         if (!NationalException::instance()->createCase("DOCR", m_strNET_ID_EMS,"A"))
            setErrorText();
      }
      else
      {
         mapUnmatchedData();
         CaseSegment::instance()->setREQUEST_TYPE("INIT");
         CaseSegment::instance()->setSTATUS("TEMP");
         CaseTransitionSegment::instance()->setREQUEST_TYPE_PREV("INIT");
         CaseTransitionSegment::instance()->setSTATUS_PREV("TEMP");
         CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT("DOCR");
         CaseTransitionSegment::instance()->setSTATUS_NEXT("HOLD");
         if (!NationalException::instance()->createCase("UNMD", m_strNET_ID_EMS,"A"))
            setErrorText();
      }
   }
   else 
   {
      CasePhaseSegment::instance()->setREASON_CODE(m_strREASON_CODE);
      if (CaseSegment::instance()->getREQUEST_TYPE() != "UNW1" //put in for duplicate processing
         && CaseSegment::instance()->getREQUEST_TYPE() != "UNW2")
      {
         if (m_strNET_ID_EMS == "MCI")
            CaseMCSegment::instance()->setBUS_DATE(m_strDateReceived);
         else if (m_strNET_ID_EMS == "VNT")
         {
            CasePhaseVisaSegment::instance()->setB2_CPD_VISA_FMT(m_strDateReceivedJulian);
            CasePhaseVisaSegment::instance()->setB2_CPD_DN_FMT(m_strDateReceived);
         }

         if (!createDuplicateCase())
            setErrorText();
      }
      else
      {
         if (m_strNET_ID_EMS == "MCI")
         {
            CaseMCSegment::instance()->setBUS_DATE(m_strDateReceived);
            auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
            Table hTable("EMS_CASE_MCI");
            CaseMCSegment::instance()->setColumns(hTable);
            hTable.setAudit(true);
            if (!pUpdateStatement->execute(hTable))
               return false;

            Table hEMSCaseDataChg("EMS_DATA_CHG");
            auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
            CaseAddEventVisitor hCaseAddEventVisitor(&hEMSCaseDataChg,pInsertStatement.get());
            hEMSCaseDataChg.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
            hEMSCaseDataChg.set("USER_ID","SYSTEM");
            hEMSCaseDataChg.set("TSTAMP_CREATED",Clock::instance()->getYYYYMMDDHHMMSS() + "00");
            hTable.accept(hCaseAddEventVisitor);
            if (!hCaseAddEventVisitor.successful())
               return false;
            CasePhaseMCSegment::instance()->setMC_MMT(m_strMMT);
         }
         else if (m_strNET_ID_EMS == "VNT")
         {
            CasePhaseVisaSegment::instance()->setB2_CPD_VISA_FMT(m_strDateReceivedJulian);
            CasePhaseVisaSegment::instance()->setB2_CPD_DN_FMT(m_strDateReceived);
            CasePhaseVisaSegment::instance()->setVISA_MMT(m_strMMT);
         }

         if (!NationalException::instance()->transitionCase("SDRC", "DOCR"))
            m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " cannot be transitioned to Retrieval Request received.";
         if (m_strErrorText.length() == 0)
         {
            if (CaseDocumentSegment::instance()->presence())
            {
               auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
               Table hTable("EMS_DOCUMENT");
               CaseDocumentSegment::instance()->setColumns(hTable);
               if (!pInsertStatement->execute(hTable))
                  m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " was not updated.  Document record could not be created.";
            }
            if (CaseCommentSegment::instance()->presence())
               addComment();
         }
      }
   }
   if (m_strErrorText.length())
      return false;
   else
      setSTATE_EXPIR_TSTAMP();
   return true;
  //## end bamsprocessing::BAMSException::processRetrievalRequest%44296D2502CE.body
}

bool BAMSException::processVisaArbitration (bool bMatchingCase)
{
  //## begin bamsprocessing::BAMSException::processVisaArbitration%46058A51002E.body preserve=yes
   Trace::put("processVisaArbitration");
   m_strErrorText.erase();
   CaseSegment::instance()->setAMT_TRAN(m_dAMT_TRAN);
   char szREASON_CODE[PERCENTD];
   snprintf(szREASON_CODE,sizeof(szREASON_CODE),"%04d",atoi(m_strREASON_CODE.c_str()));
   CasePhaseSegment::instance()->setREASON_CODE(szREASON_CODE);
   if (m_dAMT_ADJUSTMENT != 0)
   {
      CasePhaseSegment::instance()->setAMT_ADJUSTMENT(m_dAMT_ADJUSTMENT);
      CasePhaseSegment::instance()->setCUR_ADJUSTMENT(m_strCUR_ADJUSTMENT);
      CasePhaseSegment::instance()->setAMT_ADJ_TRAN(m_dAMT_ADJUSTMENT);
      CasePhaseSegment::instance()->setCUR_ADJ_TRAN(m_strCUR_ADJUSTMENT);
   }
   CaseSegment::instance()->setOTHER_CASE_NO(m_strOTHER_CASE_NO);
   if (!bMatchingCase)
   {
      CasePhaseSegment::instance()->setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
      CaseSegment::instance()->setACQ_USER_ID("TPPIMPRT");
      CasePhaseVisaSegment::instance()->setISSUER_CNTL_NO(m_strIssuerRefNo);
      CaseSegment::instance()->setRETRIEVAL_REQ_ID(m_strRETRIEVAL_REQ_ID);
      bool bReturn = retrieveTransaction();
      if (!bReturn)
         bReturn = retrieveTransaction(true);
      if (bReturn) //matching tran
      {
         mapFinancialData();
         if (FinancialBaseSegment::instance()->presence())
            FinancialBaseSegment::instance()->setPresence(false);
      }
      else
         mapUnmatchedData();
      CaseSegment::instance()->setREQUEST_TYPE("INIT");
      CaseSegment::instance()->setSTATUS("TEMP");
      CaseTransitionSegment::instance()->setSTATUS_PREV("TEMP");
      CaseTransitionSegment::instance()->setREQUEST_TYPE_PREV("INIT");
      CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT(m_strREQUEST_TYPE);
      if (CaseSegment::instance()->getTRAN_TYPE_ID().length())
      {
         if (CaseSegment::instance()->getTRAN_TYPE_ID().substr(0,4) == "2000")
            CasePhaseSegment::instance()->setACTION_TO_CARDHLDR("D");
         else
            CasePhaseSegment::instance()->setACTION_TO_CARDHLDR("C");
         if (m_siPurpose == 6)
            CaseTransitionSegment::instance()->setSTATUS_NEXT("SDRC");
         else
            CaseTransitionSegment::instance()->setSTATUS_NEXT("ACPS");
      }
      else
         CaseTransitionSegment::instance()->setSTATUS_NEXT("HOLD");
      if (!NationalException::instance()->createCase("UNMD", m_strNET_ID_EMS,"A"))
         setErrorText();
   }
   else
   {
      string strSTATUS = "SDRC";
      bool bTransition = true;
      if (CaseSegment::instance()->getREQUEST_TYPE().substr(0,3) == "DOC")
      {
         if (CaseSegment::instance()->getTRAN_TYPE_ID().substr(0,4) == "2000")
            CasePhaseSegment::instance()->setACTION_TO_CARDHLDR("D");
         else
            CasePhaseSegment::instance()->setACTION_TO_CARDHLDR("C");
         CasePhaseSegment::instance()->setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
         m_strREQUEST_TYPE = "PARB";
         if (m_siPurpose == 7)
            strSTATUS = "ACPS";
         if (CaseSegment::instance()->getSTATUS() == "HOLD")
            strSTATUS = "HOLD";
      }
      else if (m_siPurpose == 6)
      {
         if (CaseSegment::instance()->getREQUEST_TYPE() == "PARB"
            || CaseSegment::instance()->getREQUEST_TYPE() == "ARB")
            bTransition = false;  //assuming we're just getting more doc
         else
         {
            CasePhaseSegment::instance()->setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
            m_strREQUEST_TYPE = "PARB";
         }
      }
      else if (m_siPurpose == 7)
      {
         if (CaseSegment::instance()->getREQUEST_TYPE() == "ARB")
            m_strREQUEST_TYPE = "ARB";
         if (CaseSegment::instance()->getSTATUS() == "HOLD")
            bTransition = false;
         else
            strSTATUS = "ACPS";
         if (CaseSegment::instance()->getREQUEST_TYPE() != m_strREQUEST_TYPE)
            CasePhaseSegment::instance()->setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
      }

      if (bTransition && (!NationalException::instance()->transitionCase(strSTATUS, m_strREQUEST_TYPE)
         || !updateTransition()))
      {
         switch (m_siPurpose)
         {
            case 6:
               if (m_strREQUEST_TYPE == "PARB")
                  m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + 
                     " cannot be transitioned to Pre-Arb Received.";
               else
                  m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + 
                     " cannot be transitioned to Arbitration Received.";
               break;
            case 7: 
               if (m_strREQUEST_TYPE == "PARB")
                  m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + 
                     " cannot be transitioned to Pre-Arb Financial Received.";
               else
                  m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + 
                     " cannot be transitioned to Arbitration " +
                     "Financial Received.";
               break;
            default: 
               m_strErrorText = "Invalid Purpose field for case " + 
                  CaseSegment::instance()->getCASE_NO() + ".";
               break;
         }
      }
      else
      {
         if (CaseCommentSegment::instance()->presence())
            addComment();
      }
   }
   if (CaseDocumentSegment::instance()->presence() && setDocumentFields())
   {
      auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      Table hTable("EMS_DOCUMENT");
      CaseDocumentSegment::instance()->setColumns(hTable);
      if (!pInsertStatement->execute(hTable))
      {
         m_strErrorText = "Case " + CaseSegment::instance()->getCASE_NO() + " was not updated.  Document record could not be created.";
         return false;
      }
   }
   if (m_strErrorText.length())
      return false;
   else
      setSTATE_EXPIR_TSTAMP();
   return true;
  //## end bamsprocessing::BAMSException::processVisaArbitration%46058A51002E.body
}

void BAMSException::reset ()
{
  //## begin bamsprocessing::BAMSException::reset%442953E1002E.body preserve=yes
   m_strACTUAL_MSG = "              :";
   m_dAMT_ADJUSTMENT = 0;
   m_dAMT_TRAN = 0;
   m_strCUR_ADJUSTMENT.erase();
   m_strDateReceived.erase();
   m_strNET_ID_EMS.erase();
   m_strRETRIEVAL_REQ_ID.erase();
   m_strIssuerRefNo.erase();
   m_strMMT.erase();
   m_siPurpose = 0;
   Case::resetSegments();
   FinancialBaseSegment::instance()->setPresence(false);
   EMSRulesEngine::instance()->resetRuleSetPointer();
  //## end bamsprocessing::BAMSException::reset%442953E1002E.body
}

bool BAMSException::retrieveCase (bool& bMatchingCase)
{
  //## begin bamsprocessing::BAMSException::retrieveCase%4C2900270330.body preserve=yes
   Date hDate(m_strDateReceived.c_str());
   m_strDateReceivedJulian = m_strDateReceived.substr(3,1);
   m_strDateReceivedJulian += hDate.asString("%j");
      // extract ret ref no from ARN for matching purposes
   m_strRETRIEVAL_REF_NO = "%" + CaseNationalNetworkSegment::instance()->getACQ_REF_NO().substr(14,8);
   CaseSegment::instance()->setRETRIEVAL_REF_NO(m_strRETRIEVAL_REF_NO);
   CaseSegment::instance()->setNET_ID_EMS(m_strNET_ID_EMS);
   CaseSegment::instance()->setCASE_EXTENSION(m_strNET_ID_EMS);
   Query hQuery[2];
   bind(hQuery[0]);
   if (m_strREQUEST_TYPE == "CHB1")
      hQuery[0].setOrderByClause("EMS_CASE.REQUEST_TYPE DESC");
   else if (m_strREQUEST_TYPE == "REP1"
   || m_strREQUEST_TYPE == "PARB")
      hQuery[0].setOrderByClause("EMS_CASE.REQUEST_TYPE ASC");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   hQuery[1] = hQuery[0];
   hQuery[1].setBasicPredicate("EMS_CASE","OTHER_CASE_NO","=",m_strOTHER_CASE_NO.c_str());
   if (!pSelectStatement->execute(hQuery[1]))
   {
      m_strErrorText = "System error: Case search SQL";
      return false;
   }
   string strOTHER_CASE_NO = "%" + m_strOTHER_CASE_NO.substr(1) + "%";
   if (pSelectStatement->getRows() == 0)
   {
      hQuery[1].reset();
      hQuery[1] = hQuery[0];
      hQuery[1].setBasicPredicate("EMS_CASE","OTHER_CASE_NO","LIKE",strOTHER_CASE_NO.c_str());
      if (!pSelectStatement->execute(hQuery[1]))
      {
         m_strErrorText = "System error: Case search SQL";
         return false;
      }
   }
   if (pSelectStatement->getRows() == 0)
   {
      hQuery[1].reset();
      hQuery[1] = hQuery[0];
      strOTHER_CASE_NO = "%" + m_strOTHER_CASE_NO.substr(2) + "%";
      hQuery[1].setBasicPredicate("EMS_CASE","OTHER_CASE_NO","LIKE",strOTHER_CASE_NO.c_str());
      if (!pSelectStatement->execute(hQuery[1]))
      {
         m_strErrorText = "System error: Case search SQL";
         return false;
      }
   }
   if (pSelectStatement->getRows() > 1 && m_strREQUEST_TYPE == "REP1"
      && CaseSegment::instance()->getREQUEST_TYPE().substr(0,3) == "DOC")
   {
      // put in to handle having DOCR & CHB1/SDRC cases and get an REP1/SDRC in
      hQuery[0].reset();
      bind(hQuery[0]);
      hQuery[0].setOrderByClause("EMS_CASE.REQUEST_TYPE DESC");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      hQuery[0].setBasicPredicate("EMS_CASE","OTHER_CASE_NO","LIKE",strOTHER_CASE_NO.c_str());
      if (!pSelectStatement->execute(hQuery[0]))
      {
         m_strErrorText = "System error: Case search SQL";
         return false;
      }
   }
   if (pSelectStatement->getRows() == 0 && m_strREQUEST_TYPE != "REP1")
   {
      hQuery[0].reset();
      hQuery[1].reset();
      bind(hQuery[0]);
      hQuery[0].setBasicPredicate("EMS_CASE","PAN","=",CaseSegment::instance()->getPAN().c_str());
      hQuery[0].setBasicPredicate("EMS_CASE","RETRIEVAL_REF_NO","LIKE",m_strRETRIEVAL_REF_NO.c_str());
      if (m_strNET_ID_EMS == "VNT")
         hQuery[0].setBasicPredicate("EMS_CASE_VNT","TRAN_IDENTIFIER","=",m_strTransactionID.c_str());
      else if (m_strNET_ID_EMS == "MCI")
      {
         m_strTransactionID += "%";
         hQuery[0].setBasicPredicate("EMS_CASE_MCI","LIFECYCLE_TRACE_ID","LIKE",m_strTransactionID.c_str());
      }
      if (m_siPurpose == 5)
      {
         hQuery[1] = hQuery[0];
         if (m_strNET_ID_EMS == "VNT")
            hQuery[1].setBasicPredicate("EMS_PHASE_VNT","CHB_REF_NO","=",m_strIssuerRefNo.c_str());
         else if (m_strNET_ID_EMS == "MCI")
            hQuery[1].setBasicPredicate("EMS_PHASE_MCI","CARD_ISS_REF_DATA","=",m_strIssuerRefNo.c_str());
         if (!pSelectStatement->execute(hQuery[1]))
         {
            m_strErrorText = "System error: Case search SQL";
            return false;
         }
      }
      if (pSelectStatement->getRows() == 0)
      {
         if (!pSelectStatement->execute(hQuery[0]))
         {
            m_strErrorText = "System error: Case search SQL";
            return false;
         }
      }
   }
   bMatchingCase = (pSelectStatement->getRows() == 0) ? false : true;
   return true;
  //## end bamsprocessing::BAMSException::retrieveCase%4C2900270330.body
}

bool BAMSException::retrieveTransaction (bool bSecondTry)
{
  //## begin bamsprocessing::BAMSException::retrieveTransaction%48920A780128.body preserve=yes
   CaseSegment::instance()->setREQUEST_TYPE(m_strREQUEST_TYPE);
   m_strTransactionID += "%";
   vector <ReportOptionSegment> hReportOptionList;
   ReportOptionSegment hReportOptionSegment;
   hReportOptionSegment.setTABLE_NAME("FIN_LOCATOR");
   hReportOptionSegment.setCOLUMN_NAME("RETRIEVAL_REF_NO");
   hReportOptionSegment.setVALID_OPERATORS("LIKE");
   hReportOptionSegment.setDEFAULT_VALUE(CaseSegment::instance()->getRETRIEVAL_REF_NO());
   hReportOptionList.push_back(hReportOptionSegment);
   if (!bSecondTry)
   {
      hReportOptionSegment.setCOLUMN_NAME("MAPPED_DUP_DATA");
      hReportOptionSegment.setDEFAULT_VALUE(m_strTransactionID);
      hReportOptionList.push_back(hReportOptionSegment);
   }
   hReportOptionSegment.setCOLUMN_NAME("FUNC_CODE");
   hReportOptionSegment.setVALID_OPERATORS("LIKE,LIKE");
   hReportOptionSegment.setDEFAULT_VALUE("1%,2%");
   hReportOptionSegment.setOPTION_TYPE("OR");
   hReportOptionList.push_back(hReportOptionSegment);
   hReportOptionSegment.setTABLE_NAME("FIN_RECORD R");
   hReportOptionSegment.setCOLUMN_NAME("AMT_TRAN");
   hReportOptionSegment.setVALID_OPERATORS("=");
   hReportOptionSegment.setPROPERTIES("NUMERIC");
   hReportOptionSegment.setOPTION_TYPE("");
   char szTemp[PERCENTF];
   snprintf(szTemp,sizeof(szTemp),"%.0f",CaseSegment::instance()->getAMT_TRAN());
   hReportOptionSegment.setDEFAULT_VALUE(szTemp);
   hReportOptionList.push_back(hReportOptionSegment);
   return Case::instance()->retrieveTransaction(hReportOptionList,"A");
  //## end bamsprocessing::BAMSException::retrieveTransaction%48920A780128.body
}

void BAMSException::setCommentFields (const string& strEMS_COMMENT)
{
  //## begin bamsprocessing::BAMSException::setCommentFields%459AA3EF0261.body preserve=yes
   CaseCommentSegment::instance()->setPresence(true);
   CaseCommentSegment::instance()->setEMS_COMMENT(strEMS_COMMENT);
   CaseCommentSegment::instance()->setUSER_ID("SYSTEM");
  //## end bamsprocessing::BAMSException::setCommentFields%459AA3EF0261.body
}

bool BAMSException::setDocumentFields ()
{
  //## begin bamsprocessing::BAMSException::setDocumentFields%4428296F008C.body preserve=yes
   CaseDocumentSegment *pCaseDocumentSegment(CaseDocumentSegment::instance());
   string strDOC_PATH(m_strDOC_PATH);
   Date hDate(Date::today());
   string strDate(hDate.asString("%Y-%m-%d"));
   if (strDOC_PATH.find('/') != string::npos)
      strDOC_PATH += "/BAMS/IN/" + strDate + "/";
   else
      strDOC_PATH += "\\BAMS\\IN\\" + strDate + "\\";
   pCaseDocumentSegment->setDOC_PATH(strDOC_PATH + (m_strOTHER_CASE_NO + ".tif"));
   pCaseDocumentSegment->setDOC_TYPE("OTHER");
   pCaseDocumentSegment->setCREATED_BY_USER_ID("SYSTEM");
   pCaseDocumentSegment->setDELETE_FLG("N");
   pCaseDocumentSegment->setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
   pCaseDocumentSegment->setTSTAMP_TRANSMITTED(Clock::instance()->getYYYYMMDDHHMMSSHN());
   pCaseDocumentSegment->setEXPORT_IND("X");
   m_siSEQ_NO = 0;
   Query hQuery;
   hQuery.bind("EMS_DOCUMENT","SEQ_NO",Column::SHORT,&m_siSEQ_NO,0,"MAX");
   hQuery.setBasicPredicate("EMS_DOCUMENT","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   pCaseDocumentSegment->setSEQ_NO(++m_siSEQ_NO);
   pCaseDocumentSegment->setDATE_RECEIVED(m_strDateReceived);
   char *p = m_pBuffer;
   m_pCaseCreateCommand->getListSegment(0)->deport(&p);
   pCaseDocumentSegment->deport(&p);
   m_pCaseCreateCommand->getListSegment(0)->update(m_pBuffer,1,p - m_pBuffer);
   p = m_pBuffer;
   m_pCaseCreateCommand->getListSegment(0)->import(&p);
   return true;
  //## end bamsprocessing::BAMSException::setDocumentFields%4428296F008C.body
}

void BAMSException::setDocumentPresence ()
{
  //## begin bamsprocessing::BAMSException::setDocumentPresence%44E5C9FF029F.body preserve=yes
   CaseDocumentSegment::instance()->setPresence(true);
  //## end bamsprocessing::BAMSException::setDocumentPresence%44E5C9FF029F.body
}

void BAMSException::setErrorText ()
{
  //## begin bamsprocessing::BAMSException::setErrorText%443BFF9602AF.body preserve=yes
   switch (NationalException::instance()->getCaseCreateInfoID())
   {
      case STS_DATABASE_FAILURE: m_strErrorText = 
                      "Case cannot be created: Database failure."; break; 
      case STS_DUPLICATE_RECORD: m_strErrorText = 
           "Case cannot be created: Duplicate record for the transaction: " +
           Transaction::instance()->getText(); break;
      case STS_INVALID_TRANSITION: m_strErrorText = 
                      "Case cannot be created: Invalid transition."; break; 
      case STS_SMTP_OPEN_FAILURE: m_strErrorText = 
                      "Case cannot be created: Email cannot be sent."; break; 
      default: m_strErrorText = "Case create error."; break;
   }
  //## end bamsprocessing::BAMSException::setErrorText%443BFF9602AF.body
}

void BAMSException::setSTATE_EXPIR_TSTAMP ()
{
  //## begin bamsprocessing::BAMSException::setSTATE_EXPIR_TSTAMP%459AD17502DE.body preserve=yes
   //Update OTHER_CASE_NO and STATE_EXPIR_TSTAMP (set to "" in Case::transition())
   CaseSegment::instance()->setSTATE_EXPIR_TSTAMP(m_strSTATE_EXPIR_TSTAMP);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   Table hTable("EMS_CASE");
   CaseSegment::instance()->setColumns(hTable);
   hTable.setAudit(true);
   if (!pUpdateStatement->execute(hTable))
      m_strErrorText = "Could not save Respond By Date.";

   Table hEMSCaseDataChg("EMS_DATA_CHG");
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   CaseAddEventVisitor hCaseAddEventVisitor(&hEMSCaseDataChg,pInsertStatement.get());
   hEMSCaseDataChg.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
   hEMSCaseDataChg.set("USER_ID","SYSTEM");
   hEMSCaseDataChg.set("TSTAMP_CREATED",Clock::instance()->getYYYYMMDDHHMMSS() + "00");
   hTable.accept(hCaseAddEventVisitor);
   if (!hCaseAddEventVisitor.successful())
      m_strErrorText = "Could not save Respond By Date.";
  //## end bamsprocessing::BAMSException::setSTATE_EXPIR_TSTAMP%459AD17502DE.body
}

void BAMSException::update (Subject* pSubject)
{
  //## begin bamsprocessing::BAMSException::update%4421A7100399.body preserve=yes
   if (pSubject == Database::instance())
   {
      if (Database::instance()->state() == Database::CONNECTED)
      {
         Query hQuery;
         hQuery.attach(this);
         hQuery.setQualifier("QUALIFY","MISC_CFG_DATA");
         hQuery.bind("MISC_CFG_DATA","CFG_DESCRIPTION",Column::STRING,&m_strDOC_PATH);
         hQuery.setBasicPredicate("MISC_CFG_DATA","CFG_DATA_TYPE","=","DOCUMENTATION");
         hQuery.setBasicPredicate("MISC_CFG_DATA","DATA_VALUE","=","LETTER_STORAGE_LOCATION");
         string strCUST_ID;
         Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
         string strTemp = "('" + strCUST_ID + "','****')";
         hQuery.setBasicPredicate("MISC_CFG_DATA","CUST_ID","IN",strTemp.c_str());
         hQuery.setOrderByClause("MISC_CFG_DATA.CUST_ID ASC");
         auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
         pSelectStatement->execute(hQuery);
      }
      return;
   }
  //## end bamsprocessing::BAMSException::update%4421A7100399.body
}

bool BAMSException::updateTransition ()
{
  //## begin bamsprocessing::BAMSException::updateTransition%4F9E94E9018D.body preserve=yes
   //Save any changes to ACTION_TO_CARDHDLR,REASON_CODE and USER_ROLE to transition
   Table hTable;
   hTable.setAudit(true);
   hTable.setName("EMS_TRANSITION");
   hTable.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
   hTable.set("TSTAMP_CREATED",CaseTransitionSegment::instance()->getTSTAMP_CREATED(),false,true);
   hTable.set("ACTION_TO_CARDHLDR",CasePhaseSegment::instance()->getACTION_TO_CARDHLDR());
   hTable.set("REASON_CODE",CasePhaseSegment::instance()->getREASON_CODE());
   hTable.set("AMT_ADJUSTMENT",CasePhaseSegment::instance()->getAMT_ADJUSTMENT());
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if (pUpdateStatement->execute(hTable) == false)
      return false;

   Table hEMSCaseDataChg("EMS_DATA_CHG");
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   CaseAddEventVisitor hCaseAddEventVisitor(&hEMSCaseDataChg,pInsertStatement.get());
   hEMSCaseDataChg.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
   hEMSCaseDataChg.set("USER_ID","SYSTEM");
   hEMSCaseDataChg.set("TSTAMP_CREATED",Transaction::instance()->getTimeStamp());
   hTable.accept(hCaseAddEventVisitor);
   if (!hCaseAddEventVisitor.successful())
      return false;
   return true;
  //## end bamsprocessing::BAMSException::updateTransition%4F9E94E9018D.body
}

// Additional Declarations
  //## begin bamsprocessing::BAMSException%442185560261.declarations preserve=yes
  //## end bamsprocessing::BAMSException%442185560261.declarations

} // namespace bamsprocessing

//## begin module%442185F600AB.epilog preserve=yes
//## end module%442185F600AB.epilog


// Detached code regions:
// WARNING: this code will be lost if code is regenerated.
#if 0
//## begin bamsprocessing::BAMSException::retrieveCase%4B22979200C6.body preserve=no
   Date hDate(m_strDateReceived.c_str());
   m_strDateReceivedJulian = m_strDateReceived.substr(3,1);
   m_strDateReceivedJulian += hDate.asString("%j");
      // extract ret ref no from ARN for matching purposes
   m_strRETRIEVAL_REF_NO = "%" + CaseNationalNetworkSegment::instance()->getACQ_REF_NO().substr(14,8);
   CaseSegment::instance()->setRETRIEVAL_REF_NO(m_strRETRIEVAL_REF_NO);
   CaseSegment::instance()->setNET_ID_EMS(m_strNET_ID_EMS);
   CaseSegment::instance()->setCASE_EXTENSION(m_strNET_ID_EMS);
   Query hQuery[2];
   bind(hQuery[0]);
   if (m_strREQUEST_TYPE == "CHB1")
      hQuery[0].setOrderByClause("EMS_CASE.REQUEST_TYPE DESC");
   else if (m_strREQUEST_TYPE == "REP1"
   || m_strREQUEST_TYPE == "PARB")
      hQuery[0].setOrderByClause("EMS_CASE.REQUEST_TYPE ASC");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   hQuery[1] = hQuery[0];
   hQuery[1].setBasicPredicate("EMS_CASE","OTHER_CASE_NO","=",m_strOTHER_CASE_NO.c_str());
   if (!pSelectStatement->execute(hQuery[1]))
   {
      m_strErrorText = "System error: Case search SQL";
      return false;
   }
   string strOTHER_CASE_NO = "%" + m_strOTHER_CASE_NO.substr(1) + "%";
   if (pSelectStatement->getRows() == 0)
   {
      hQuery[1].reset();
      hQuery[1] = hQuery[0];
      hQuery[1].setBasicPredicate("EMS_CASE","OTHER_CASE_NO","LIKE",strOTHER_CASE_NO.c_str());
      if (!pSelectStatement->execute(hQuery[1]))
      {
         m_strErrorText = "System error: Case search SQL";
         return false;
      }
   }
   if (pSelectStatement->getRows() == 0)
   {
      hQuery[1].reset();
      hQuery[1] = hQuery[0];
      strOTHER_CASE_NO = "%" + m_strOTHER_CASE_NO.substr(2) + "%";
      hQuery[1].setBasicPredicate("EMS_CASE","OTHER_CASE_NO","LIKE",strOTHER_CASE_NO.c_str());
      if (!pSelectStatement->execute(hQuery[1]))
      {
         m_strErrorText = "System error: Case search SQL";
         return false;
      }
   }
   if (pSelectStatement->getRows() > 1 && m_strREQUEST_TYPE == "REP1"
      && CaseSegment::instance()->getREQUEST_TYPE().substr(0,3) == "DOC")
   {
      // put in to handle having DOCR & CHB1/SDRC cases and get an REP1/SDRC in
      hQuery[0].reset();
      bind(hQuery[0]);
      hQuery[0].setOrderByClause("EMS_CASE.REQUEST_TYPE DESC");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      hQuery[0].setBasicPredicate("EMS_CASE","OTHER_CASE_NO","LIKE",strOTHER_CASE_NO.c_str());
      if (!pSelectStatement->execute(hQuery[0]))
      {
         m_strErrorText = "System error: Case search SQL";
         return false;
      }
   }
   if (pSelectStatement->getRows() == 0 && m_strREQUEST_TYPE != "REP1")
   {
      hQuery[0].reset();
      hQuery[1].reset();
      bind(hQuery[0]);
      hQuery[0].setBasicPredicate("EMS_CASE","PAN","=",CaseSegment::instance()->getPAN().c_str());
      hQuery[0].setBasicPredicate("EMS_CASE","RETRIEVAL_REF_NO","LIKE",m_strRETRIEVAL_REF_NO.c_str());
      if (m_strNET_ID_EMS == "VNT")
         hQuery[0].setBasicPredicate("EMS_CASE_VNT","TRAN_IDENTIFIER","=",m_strTransactionID.c_str());
      else if (m_strNET_ID_EMS == "MCI")
      {
         m_strTransactionID += "%";
         hQuery[0].setBasicPredicate("EMS_CASE_MCI","LIFECYCLE_TRACE_ID","LIKE",m_strTransactionID.c_str());
      }
      if (m_siPurpose == 5)
      {
         hQuery[1] = hQuery[0];
         if (m_strNET_ID_EMS == "VNT")
            hQuery[1].setBasicPredicate("EMS_PHASE_VNT","CHB_REF_NO","=",m_strIssuerRefNo.c_str());
         else if (m_strNET_ID_EMS == "MCI")
            hQuery[1].setBasicPredicate("EMS_PHASE_MCI","CARD_ISS_REF_DATA","=",m_strIssuerRefNo.c_str());
         if (!pSelectStatement->execute(hQuery[1]))
         {
            m_strErrorText = "System error: Case search SQL";
            return false;
         }
      }
      if (pSelectStatement->getRows() == 0)
      {
         if (!pSelectStatement->execute(hQuery[0]))
         {
            m_strErrorText = "System error: Case search SQL";
            return false;
         }
      }
   }
   bMatchingCase = (pSelectStatement->getRows() == 0) ? false : true;
   return true;
//## end bamsprocessing::BAMSException::retrieveCase%4B22979200C6.body

#endif
