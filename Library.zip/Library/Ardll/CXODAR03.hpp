//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%367521CC0341.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%367521CC0341.cm

//## begin module%367521CC0341.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%367521CC0341.cp

//## Module: CXOSAR03%367521CC0341; Package specification
//## Subsystem: ARDLL%3597E7F203AA
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\ARDLL\CXODAR03.hpp

#ifndef CXOSAR03_h
#define CXOSAR03_h 1

//## begin module%367521CC0341.additionalIncludes preserve=no
//## end module%367521CC0341.additionalIncludes

//## begin module%367521CC0341.includes preserve=yes
// $Date:   Jun 30 2006 12:15:34  $ $Author:   D02405  $ $Revision:   1.15  $
//## end module%367521CC0341.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
//## begin module%367521CC0341.declarations preserve=no
//## end module%367521CC0341.declarations

//## begin module%367521CC0341.additionalDeclarations preserve=yes
//## end module%367521CC0341.additionalDeclarations


//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
//## begin archive%3451F7650251.initialDeclarations preserve=yes
//## end archive%3451F7650251.initialDeclarations

//## begin archive::ArchiveRetriever%34854F420188.preface preserve=yes
//## end archive::ArchiveRetriever%34854F420188.preface

//## Class: ArchiveRetriever%34854F420188
//	The ArchiveRetriever class provides an interface to
//	retrieval functions from an archive.
//
//	It is based on the Singleton pattern.
//
//	CXODAR03.hpp
//	CXOSAR03.cpp
//## Category: Archive::Archive_CAT%3451F7650251
//## Subsystem: ARDLL%3597E7F203AA
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1

class DllExport ArchiveRetriever : public reusable::Observer  //## Inherits: <unnamed>%37D973C302C7
{
  //## begin archive::ArchiveRetriever%34854F420188.initialDeclarations preserve=yes
  //## end archive::ArchiveRetriever%34854F420188.initialDeclarations

  public:
    //## Constructors (generated)
      ArchiveRetriever();

    //## Destructor (generated)
      virtual ~ArchiveRetriever();


    //## Other Operations (specified)
      //## Operation: closeArchive%37D95E6503E4
      virtual int closeArchive ();

      //## Operation: get%34855116009B
      //	Retrieve a transaction from this archive.
      virtual bool get (char cType, const char* pszTimestamp, short int iUniquenessKey, void* pBuffer, int nMaxBufferLength, int* pnBufferLength);

      //## Operation: instance%3485511B0228
      //	Return the one-and-only instance of ArchiveRetriever.
      //## Semantics:
      //	1. Return the value of m_pInstance.
      static ArchiveRetriever* instance ();

      //## Operation: update%3C0E71790102
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: InfoIDNumber%37D9698B0058
      int getInfoIDNumber () const
      {
        //## begin archive::ArchiveRetriever::getInfoIDNumber%37D9698B0058.get preserve=no
        return m_lInfoIDNumber;
        //## end archive::ArchiveRetriever::getInfoIDNumber%37D9698B0058.get
      }

      void setInfoIDNumber (int value)
      {
        //## begin archive::ArchiveRetriever::setInfoIDNumber%37D9698B0058.set preserve=no
        m_lInfoIDNumber = value;
        //## end archive::ArchiveRetriever::setInfoIDNumber%37D9698B0058.set
      }


    // Additional Public Declarations
      //## begin archive::ArchiveRetriever%34854F420188.public preserve=yes
      //## end archive::ArchiveRetriever%34854F420188.public

  protected:
    // Data Members for Class Attributes

      //## begin archive::ArchiveRetriever::InfoIDNumber%37D9698B0058.attr preserve=no  public: int {U} 0
      int m_lInfoIDNumber;
      //## end archive::ArchiveRetriever::InfoIDNumber%37D9698B0058.attr

    // Additional Protected Declarations
      //## begin archive::ArchiveRetriever%34854F420188.protected preserve=yes
      //## end archive::ArchiveRetriever%34854F420188.protected

  private:
    // Additional Private Declarations
      //## begin archive::ArchiveRetriever%34854F420188.private preserve=yes
      //## end archive::ArchiveRetriever%34854F420188.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%348550EC0159
      //	A pointer to the one-and-only instance of Archive
      //	Retriever.
      //## begin archive::ArchiveRetriever::Instance%348550EC0159.attr preserve=no  private: static ArchiveRetriever* {V} 0
      static ArchiveRetriever* m_pInstance;
      //## end archive::ArchiveRetriever::Instance%348550EC0159.attr

    // Additional Implementation Declarations
      //## begin archive::ArchiveRetriever%34854F420188.implementation preserve=yes
      //## end archive::ArchiveRetriever%34854F420188.implementation

};

//## begin archive::ArchiveRetriever%34854F420188.postscript preserve=yes
//## end archive::ArchiveRetriever%34854F420188.postscript

} // namespace archive

//## begin module%367521CC0341.epilog preserve=yes
using namespace archive;
//## end module%367521CC0341.epilog


#endif
