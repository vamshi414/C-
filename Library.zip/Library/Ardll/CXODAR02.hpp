//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%36DEF73000BF.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DEF73000BF.cm

//## begin module%36DEF73000BF.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DEF73000BF.cp

//## Module: CXODAR02%36DEF73000BF; Package specification
//## Subsystem: ARDLL%3597E7F203AA
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\ARDLL\CXODAR02.hpp

#ifndef CXODAR02_h
#define CXODAR02_h 1

//## begin module%36DEF73000BF.additionalIncludes preserve=no
//## end module%36DEF73000BF.additionalIncludes

//## begin module%36DEF73000BF.includes preserve=yes
// $Date:   Jan 31 2017 13:56:14  $ $Author:   e1009510  $ $Revision:   1.15  $
//## end module%36DEF73000BF.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%36DEF73000BF.declarations preserve=no
//## end module%36DEF73000BF.declarations

//## begin module%36DEF73000BF.additionalDeclarations preserve=yes
//## end module%36DEF73000BF.additionalDeclarations


//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
//## begin archive%3451F7650251.initialDeclarations preserve=yes
//## end archive%3451F7650251.initialDeclarations

//## begin archive::ArchiveCreator%345243910252.preface preserve=yes
//## end archive::ArchiveCreator%345243910252.preface

//## Class: ArchiveCreator%345243910252; Abstract
//	The ArchiveCreator class provides an abstract interface
//	to creation functions in an archive.
//
//	It is based on the Singleton pattern.
//
//	CXODAR02.hpp
//	CXOSAR02.cpp
//## Category: Archive::Archive_CAT%3451F7650251
//## Subsystem: ARDLL%3597E7F203AA
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1

//## Uses: <unnamed>%3BE02CD702FD;IF::Extract { -> F}

class DllExport ArchiveCreator : public reusable::Object  //## Inherits: <unnamed>%34EDE0AB019F
{
  //## begin archive::ArchiveCreator%345243910252.initialDeclarations preserve=yes
  public:
     enum state
{
   IDLE,
   OPEN
};
  //## end archive::ArchiveCreator%345243910252.initialDeclarations

  public:
    //## Constructors (generated)
      ArchiveCreator();

    //## Destructor (generated)
      virtual ~ArchiveCreator();


    //## Other Operations (specified)
      //## Operation: closeVersion%37DD212D0181
      virtual int closeVersion () = 0;

      //## Operation: commit%3480491F0297
      //	Commit the current unit of work.
      virtual bool commit () = 0;

      //## Operation: instance%3475FFE902CB
      //	Return the one-and-only instance of ArchiveCreator.
      //## Semantics:
      //	1. Return the value of m_pInstance.
      static ArchiveCreator* instance ();

      //## Operation: put%39BCE7A601EF
      virtual int put (char cType, const char* pszTimestamp, short iUniquenessKey, void* pBuffer, int nBufferLength) = 0;

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Timestamp%3C3C60E700AB
      void setTimestamp (const string& value)
      {
        //## begin archive::ArchiveCreator::setTimestamp%3C3C60E700AB.set preserve=no
        m_strTimestamp = value;
        //## end archive::ArchiveCreator::setTimestamp%3C3C60E700AB.set
      }


      //## Attribute: State%3C48506103D8
      const state getState () const
      {
        //## begin archive::ArchiveCreator::getState%3C48506103D8.get preserve=no
        return m_nState;
        //## end archive::ArchiveCreator::getState%3C48506103D8.get
      }


    // Additional Public Declarations
      //## begin archive::ArchiveCreator%345243910252.public preserve=yes
      //## end archive::ArchiveCreator%345243910252.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: RecordLimit%37D578A90236
      //## begin archive::ArchiveCreator::RecordLimit%37D578A90236.attr preserve=no  public: int {U} 50000
      int m_lRecordLimit;
      //## end archive::ArchiveCreator::RecordLimit%37D578A90236.attr

      //## begin archive::ArchiveCreator::Timestamp%3C3C60E700AB.attr preserve=no  public: string {U} 
      string m_strTimestamp;
      //## end archive::ArchiveCreator::Timestamp%3C3C60E700AB.attr

      //## begin archive::ArchiveCreator::State%3C48506103D8.attr preserve=no  public: state {U} 
      state m_nState;
      //## end archive::ArchiveCreator::State%3C48506103D8.attr

    // Additional Protected Declarations
      //## begin archive::ArchiveCreator%345243910252.protected preserve=yes
      //## end archive::ArchiveCreator%345243910252.protected

  private:
    // Additional Private Declarations
      //## begin archive::ArchiveCreator%345243910252.private preserve=yes
      //## end archive::ArchiveCreator%345243910252.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3475FFCD0112
      //	A pointer to the one-and-only instance of ArchiveCreator.
      //## begin archive::ArchiveCreator::Instance%3475FFCD0112.attr preserve=no  private: static ArchiveCreator* {V} 0
      static ArchiveCreator* m_pInstance;
      //## end archive::ArchiveCreator::Instance%3475FFCD0112.attr

    // Additional Implementation Declarations
      //## begin archive::ArchiveCreator%345243910252.implementation preserve=yes
      //## end archive::ArchiveCreator%345243910252.implementation

};

//## begin archive::ArchiveCreator%345243910252.postscript preserve=yes
//## end archive::ArchiveCreator%345243910252.postscript

} // namespace archive

//## begin module%36DEF73000BF.epilog preserve=yes
using namespace archive;
//## end module%36DEF73000BF.epilog


#endif
