//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%367523E3011A.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%367523E3011A.cm

//## begin module%367523E3011A.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%367523E3011A.cp

//## Module: CXOSAR01%367523E3011A; Package specification
//## Subsystem: ARDLL%3597E7F203AA
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\ARDLL\CXODAR01.hpp

#ifndef CXOSAR01_h
#define CXOSAR01_h 1

//## begin module%367523E3011A.additionalIncludes preserve=no
//## end module%367523E3011A.additionalIncludes

//## begin module%367523E3011A.includes preserve=yes
// $Date:   Apr 08 2004 12:42:42  $ $Author:   D02405  $ $Revision:   1.7  $
//## end module%367523E3011A.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
class ArchiveRetriever;
class ArchiveCreator;

} // namespace archive

//## begin module%367523E3011A.declarations preserve=no
//## end module%367523E3011A.declarations

//## begin module%367523E3011A.additionalDeclarations preserve=yes
//## end module%367523E3011A.additionalDeclarations


namespace archive {
//## begin archive%3451F7650251.initialDeclarations preserve=yes
//## end archive%3451F7650251.initialDeclarations

//## begin archive::ArchiveFactory%3475FFBA0165.preface preserve=yes
//## end archive::ArchiveFactory%3475FFBA0165.preface

//## Class: ArchiveFactory%3475FFBA0165; Abstract
//	The ArchiveFactory class provides an interface for
//	creating archive related objects.
//
//	It is based on the AbstractFactory object of the Abstract
//	Factory pattern.
//
//	It is also based on the Singleton pattern.
//
//	CXODAR01.hpp
//	CXOSAR01.cpp
//## Category: Archive::Archive_CAT%3451F7650251
//## Subsystem: ARDLL%3597E7F203AA
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1

//## Uses: <unnamed>%37D54DF402E0;ArchiveCreator { -> F}
//## Uses: <unnamed>%37D54DFC0291;ArchiveRetriever { -> F}

class DllExport ArchiveFactory : public reusable::Object  //## Inherits: <unnamed>%34EDE0B00246
{
  //## begin archive::ArchiveFactory%3475FFBA0165.initialDeclarations preserve=yes
  //## end archive::ArchiveFactory%3475FFBA0165.initialDeclarations

  public:
    //## Constructors (generated)
      ArchiveFactory();

    //## Destructor (generated)
      virtual ~ArchiveFactory();


    //## Other Operations (specified)
      //## Operation: createArchiveCreator%347600570233
      //	Return a new instance of ArchiveCreator.
      virtual ArchiveCreator* createArchiveCreator () = 0;

      //## Operation: createArchiveRetriever%3485681C0000
      //	Return a new instance of ArchiveRetriever.
      virtual ArchiveRetriever* createArchiveRetriever () = 0;

      //## Operation: instance%34760064003D
      static ArchiveFactory* instance ();

    // Additional Public Declarations
      //## begin archive::ArchiveFactory%3475FFBA0165.public preserve=yes
      //## end archive::ArchiveFactory%3475FFBA0165.public

  protected:
    // Additional Protected Declarations
      //## begin archive::ArchiveFactory%3475FFBA0165.protected preserve=yes
      //## end archive::ArchiveFactory%3475FFBA0165.protected

  private:
    // Additional Private Declarations
      //## begin archive::ArchiveFactory%3475FFBA0165.private preserve=yes
      //## end archive::ArchiveFactory%3475FFBA0165.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%347600110233
      //	A pointer to the one-and-only instance of ArchiveFactory.
      //## begin archive::ArchiveFactory::Instance%347600110233.attr preserve=no  private: static ArchiveFactory* {V} 0
      static ArchiveFactory* m_pInstance;
      //## end archive::ArchiveFactory::Instance%347600110233.attr

    // Additional Implementation Declarations
      //## begin archive::ArchiveFactory%3475FFBA0165.implementation preserve=yes
      //## end archive::ArchiveFactory%3475FFBA0165.implementation

};

//## begin archive::ArchiveFactory%3475FFBA0165.postscript preserve=yes
//## end archive::ArchiveFactory%3475FFBA0165.postscript

} // namespace archive

//## begin module%367523E3011A.epilog preserve=yes
using namespace archive;
//## end module%367523E3011A.epilog


#endif
