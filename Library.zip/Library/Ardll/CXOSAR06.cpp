//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4226326303A9.cm preserve=no
//	$Date:   May 21 2020 20:25:16  $ $Author:   e1009510  $
//	$Revision:   1.28  $
//## end module%4226326303A9.cm

//## begin module%4226326303A9.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4226326303A9.cp

//## Module: CXOSAR06%4226326303A9; Package body
//## Subsystem: ARDLL%3597E7F203AA
//	.
//## Source file: C:\V2.4B.R002\Dn\Server\Library\Ardll\CXOSAR06.cpp

//## begin module%4226326303A9.additionalIncludes preserve=no
//## end module%4226326303A9.additionalIncludes

//## begin module%4226326303A9.includes preserve=yes
#include "CXODTM03.hpp"
#include "CXODIF25.hpp"
//## end module%4226326303A9.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDB10_h
#include "CXODDB10.hpp"
#endif
#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB32_h
#include "CXODDB32.hpp"
#endif
#ifndef CXOSRU39_h
#include "CXODRU39.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSDB08_h
#include "CXODDB08.hpp"
#endif
#ifndef CXOSAR06_h
#include "CXODAR06.hpp"
#endif


//## begin module%4226326303A9.declarations preserve=no
//## end module%4226326303A9.declarations

//## begin module%4226326303A9.additionalDeclarations preserve=yes
#include "CXODPS01.hpp"
#include "CXODIF15.hpp"
//## end module%4226326303A9.additionalDeclarations


//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
//## begin archive%3451F7650251.initialDeclarations preserve=yes
//## end archive%3451F7650251.initialDeclarations

// Class archive::ExportData 

ExportData::ExportData()
  //## begin ExportData::ExportData%4226318D033C_const.hasinit preserve=no
  //## end ExportData::ExportData%4226318D033C_const.hasinit
  //## begin ExportData::ExportData%4226318D033C_const.initialization preserve=yes
  //## end ExportData::ExportData%4226318D033C_const.initialization
{
  //## begin archive::ExportData::ExportData%4226318D033C_const.body preserve=yes
   memcpy(m_sID,"AR06",4);
   MidnightAlarm::instance()->attach(this);
  //## end archive::ExportData::ExportData%4226318D033C_const.body
}


ExportData::~ExportData()
{
  //## begin archive::ExportData::~ExportData%4226318D033C_dest.body preserve=yes
   MidnightAlarm::instance()->detach(this);
  //## end archive::ExportData::~ExportData%4226318D033C_dest.body
}



//## Other Operations (implementation)
bool ExportData::process (const char* pszUseCase, const char* pszMember, const char* pszTableName)
{
  //## begin archive::ExportData::process%422713A70222.body preserve=yes
   UseCase hUseCase("DR",pszUseCase);
   if (strstr(pszUseCase,"DROP"))
   {
      Query hQuery;
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DATE_RECON","=",pszTableName + 8);
      auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
      if(KeyRing::instance()->getInitializedFromBackups())
         return true;//don't drop if problems with token database
      if(!pDeleteStatement->execute(hQuery))
      {
         Database::instance()->rollback();
         return false;
      }
      else
         Database::instance()->commit();
      if(KeyRing::instance()->getActive() && KeyRing::instance()->isPrimary() &&
         !KeyRing::instance()->getInitializedFromBackups())
         if (memcmp(pszTableName + 14,"00",2) == 0)
         {  //delete any key that is > 1 year old this month
            Date hDate(Date::today());
            hDate.incrementMonth(-1 * 12);
            KeyManager::instance()->ageKeys(hDate.asString("%Y%m"));
         }
   }
   char szHexMD[3] = {"  "};
   if (!memcmp(pszTableName + 12,"10",2))
      szHexMD[0] = 'A';
   else
   if (!memcmp(pszTableName + 12,"11",2))
      szHexMD[0] = 'B';
   else
   if (!memcmp(pszTableName + 12,"12",2))
      szHexMD[0] = 'C';
   else
      szHexMD[0] = pszTableName[13];
   char szB36[38] = "0123456789ABCDEFGHIJKLMNOPQRSTUV";
   szHexMD[1] = szB36[atoi(pszTableName + 14)];
   return UseCase::setSuccess(Job::submit(pszMember,"&CYYMMDD",pszTableName + 8,"&YYMMDD ",pszTableName + 10,"&HEXMD  ",szHexMD));
  //## end archive::ExportData::process%422713A70222.body
}

void ExportData::processPADSS (const string& strContext)
{
  //## begin archive::ExportData::processPADSS%4A048D0A029C.body preserve=yes
   if (strContext.find("BEGIN") != string::npos)
   {
      if (KeyManager::instance()->begin())
      {
         string strStartDate(KeyRing::instance()->getStartDate());
         strStartDate.append("01");
         Date hDate(strStartDate.c_str());
         Console::display("ST602","BEGIN");//ACCEPTED
         Console::display("ST606","BEGIN",hDate.asString("%m-%d-%Y").c_str());
      }
      else
         Console::display("ST603","BEGIN"); //REJECTED
   }
   else
   if (strContext.find("END") != string::npos)
   {
      if (KeyManager::instance()->end())
      {
         string strEndDate(KeyRing::instance()->getEndDate());
         strEndDate.append("01");
         Date hDate(strEndDate.c_str());
         Date hEndDate(hDate.getYear(),hDate.getMonth(),hDate.daysInMonth(hDate.getYear(),hDate.getMonth()));
         Console::display("ST602","END"); //ACCEPTED
         Console::display("ST606","END",hEndDate.asString("%m-%d-%Y").c_str());
      }
      else
         Console::display("ST603","END"); //REJECTED
   }
   else
   if (strContext.find("MASTERKEY") != string::npos)
   {
      if (KeyManager::instance()->changeMasterKey())
         Console::display("ST604","MASTERKEY"); //COMPLETED
      else
         Console::display("ST605","MASTERKEY"); //FAILED
   }
   else
   if (strContext.find("DATAKEY") != string::npos)
   {
      if (KeyManager::instance()->reencryptTokens())
         Console::display("ST604","DATAKEY"); //COMPLETED
      else
         Console::display("ST605","DATAKEY"); //FAILED
   }
   else if (strContext.find("KEYFILE") != string::npos)
   {
      if (KeyManager::instance()->readKeyFile(Application::instance()->image(),Application::instance()->name()))
         Console::display("ST604","KEYFILE"); //COMPLETED
      else
         Console::display("ST605","KEYFILE"); //FAILED
   }
  //## end archive::ExportData::processPADSS%4A048D0A029C.body
}

void ExportData::update (Subject* pSubject)
{
  //## begin archive::ExportData::update%422631B100DA.body preserve=yes
	UseCase hUseCase("DR","## DR84 CHECK DX TABLE");
   int lDay = 15;
   Extract::instance()->getLong("DUSER   ","DXDAYS=",&lDay);
   if (lDay < 15)
      lDay = 15;
#ifdef MVS
   string strMember("DN##CRDX");
#else
   string strMember("CXOXDRCX");
#endif
   auto_ptr<DatabaseCatalog> pDatabaseCatalog((DatabaseCatalog*)DatabaseFactory::instance()->create("DatabaseCatalog"));
   Date hDate(MidnightAlarm::instance()->getYesterday().c_str());
   string strTableName;
   // current month
   strTableName = hDate.asString("DX_DATA_%Y%m00");
   if (!pDatabaseCatalog->isExisting(strTableName))
      process("## DR85 CREATE DX TABLE",strMember.c_str(),strTableName.c_str());
   else
   {  //re-encrypt tokens once a month with new key
      //method does nothing if already encrypted with this month's key
      Date hDate2(MidnightAlarm::instance()->getToday().c_str());
      strTableName = hDate2.asString("DX_DATA_%Y%m%d");
      if(pDatabaseCatalog->isExisting(strTableName) &&
         KeyRing::instance()->getActive() && 
         KeyRing::instance()->isPrimary() && 
         !KeyRing::instance()->getInitializedFromBackups())
         KeyManager::instance()->reencryptTokens(hDate.asString("%Y%m"));
   }
   // next month
   int iYear = hDate.getYear();
   int iMonth = hDate.getMonth();
   if (iMonth == 12)
   {
      ++iYear;
      iMonth = 1;
   }
   else
      ++iMonth;
   char szTableName[17];
   snprintf(szTableName,sizeof(szTableName),"DX_DATA_%04d%02d00",iYear,iMonth);
   strTableName.assign(szTableName,16);
   if (!pDatabaseCatalog->isExisting(strTableName))
      process("## DR85 CREATE DX TABLE",strMember.c_str(),strTableName.c_str());
   // prior 7 days and next 7 days
   hDate -= 7;
   for (int i = 0;i < 15;++i)
   {
      strTableName = hDate.asString("DX_DATA_%Y%m%d");
      if (!pDatabaseCatalog->isExisting(strTableName))
      {
         process("## DR85 CREATE DX TABLE",strMember.c_str(),strTableName.c_str());
         Sleep::goTo("00000100");
         int j = 0;
         while (!pDatabaseCatalog->isExisting(strTableName))
         {
            if (++j > 2)
               return;
            Sleep::goTo("00000100");
         }
      }
      hDate += 1;
   }
   pDatabaseCatalog->getTable("DX_DATA_%","MIN",strTableName);
   if (strTableName.length() == 0)
   {
      Database::instance()->commit();
      return;
   }
#ifdef MVS
   strMember = "DN##DRDX";
#else
   strMember = "CXOXDRDX";
#endif
   hDate = Date(MidnightAlarm::instance()->getYesterday().c_str());  
   Date hDateSwitchClock(SwitchClock::instance()->getDate().c_str());
   // drop month
   if (strTableName.substr(14,2) == "00")
   {
      iYear = hDate.getYear();
      iMonth = hDate.getMonth();
      for (int i = 0;i < 2;++i)
      {
         if (iMonth == 1)
         {
            --iYear;
            iMonth = 12;
         }
         else
            --iMonth;
      }
      snprintf(szTableName,sizeof(szTableName),"DX_DATA_%04d%02d00",iYear,iMonth);      
      if (strTableName < string(szTableName) &&
         (strTableName.substr(8,6) < hDateSwitchClock.asString("%Y%m")))     
         process("## DR86 DROP DX TABLE",strMember.c_str(),strTableName.c_str());
      strTableName[15] = '1';
   }
   // drop days
   hDate -= lDay;
   Date hDropDate(strTableName.c_str() + 8);
   while (hDropDate < hDate)
   {
      strTableName = hDropDate.asString("DX_DATA_%Y%m%d");      
      if (pDatabaseCatalog->isExisting(strTableName) && (hDropDate < hDateSwitchClock))         
      {
         process("## DR86 DROP DX TABLE",strMember.c_str(),strTableName.c_str());
         Sleep::goTo("00000100");
         int j = 0;
         while (pDatabaseCatalog->isExisting(strTableName))
         {
            if (++j > 2)
               return;
            Sleep::goTo("00000100");
         }
      }
      hDropDate += 1;
   }
   Database::instance()->commit();
  //## end archive::ExportData::update%422631B100DA.body
}

// Additional Declarations
  //## begin archive::ExportData%4226318D033C.declarations preserve=yes
  //## end archive::ExportData%4226318D033C.declarations

} // namespace archive

//## begin module%4226326303A9.epilog preserve=yes
//## end module%4226326303A9.epilog
