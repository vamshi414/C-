//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%36DEF7310306.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DEF7310306.cm

//## begin module%36DEF7310306.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DEF7310306.cp

//## Module: CXODAR02%36DEF7310306; Package body
//## Subsystem: ARDLL%3597E7F203AA
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\ARDLL\CXOSAR02.cpp

//## begin module%36DEF7310306.additionalIncludes preserve=no
//## end module%36DEF7310306.additionalIncludes

//## begin module%36DEF7310306.includes preserve=yes
// $Date:   Apr 08 2004 12:42:44  $ $Author:   D02405  $ $Revision:   1.12  $
//## end module%36DEF7310306.includes

#ifndef CXODAR02_h
#include "CXODAR02.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif


//## begin module%36DEF7310306.declarations preserve=no
//## end module%36DEF7310306.declarations

//## begin module%36DEF7310306.additionalDeclarations preserve=yes
//## end module%36DEF7310306.additionalDeclarations


//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
//## begin archive%3451F7650251.initialDeclarations preserve=yes
//## end archive%3451F7650251.initialDeclarations

// Class archive::ArchiveCreator 

//## begin archive::ArchiveCreator::Instance%3475FFCD0112.attr preserve=no  private: static ArchiveCreator* {V} 0
ArchiveCreator* ArchiveCreator::m_pInstance = 0;
//## end archive::ArchiveCreator::Instance%3475FFCD0112.attr





ArchiveCreator::ArchiveCreator()
  //## begin ArchiveCreator::ArchiveCreator%345243910252_const.hasinit preserve=no
      : m_lRecordLimit(50000)
  //## end ArchiveCreator::ArchiveCreator%345243910252_const.hasinit
  //## begin ArchiveCreator::ArchiveCreator%345243910252_const.initialization preserve=yes
  //## end ArchiveCreator::ArchiveCreator%345243910252_const.initialization
{
  //## begin archive::ArchiveCreator::ArchiveCreator%345243910252_const.body preserve=yes
   m_pInstance = this;
   Extract::instance()->getLong("DUSER   ","LIMIT=",&m_lRecordLimit);
  //## end archive::ArchiveCreator::ArchiveCreator%345243910252_const.body
}


ArchiveCreator::~ArchiveCreator()
{
  //## begin archive::ArchiveCreator::~ArchiveCreator%345243910252_dest.body preserve=yes
  //## end archive::ArchiveCreator::~ArchiveCreator%345243910252_dest.body
}



//## Other Operations (implementation)
ArchiveCreator* ArchiveCreator::instance ()
{
  //## begin archive::ArchiveCreator::instance%3475FFE902CB.body preserve=yes
   return m_pInstance;
  //## end archive::ArchiveCreator::instance%3475FFE902CB.body
}

// Additional Declarations
  //## begin archive::ArchiveCreator%345243910252.declarations preserve=yes
  //## end archive::ArchiveCreator%345243910252.declarations

} // namespace archive

//## begin module%36DEF7310306.epilog preserve=yes
//## end module%36DEF7310306.epilog
