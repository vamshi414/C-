//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%366C49DB02DE.cm preserve=no
//	$Date:   May 21 2020 20:25:16  $ $Author:   e1009510  $
//	$Revision:   1.29  $
//## end module%366C49DB02DE.cm

//## begin module%366C49DB02DE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%366C49DB02DE.cp

//## Module: CXOSAR05%366C49DB02DE; Package body
//## Subsystem: ARDLL%3597E7F203AA
//	.
//## Source file: C:\Devel\Dn\Server\Library\ARDLL\CXOSAR05.cpp

//## begin module%366C49DB02DE.additionalIncludes preserve=no
//## end module%366C49DB02DE.additionalIncludes

//## begin module%366C49DB02DE.includes preserve=yes
#include "CXODTM06.hpp"
//## end module%366C49DB02DE.includes

#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSDB10_h
#include "CXODDB10.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSAR05_h
#include "CXODAR05.hpp"
#endif


//## begin module%366C49DB02DE.declarations preserve=no
//## end module%366C49DB02DE.declarations

//## begin module%366C49DB02DE.additionalDeclarations preserve=yes
//## end module%366C49DB02DE.additionalDeclarations


//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
//## begin archive%3451F7650251.initialDeclarations preserve=yes
//## end archive%3451F7650251.initialDeclarations

// Class archive::Locator

Locator::Locator()
  //## begin Locator::Locator%3505AB4803B4_const.hasinit preserve=no
      : m_lCount(0),
        m_strLocatorTime("090000"),
        m_cType(' ')
  //## end Locator::Locator%3505AB4803B4_const.hasinit
  //## begin Locator::Locator%3505AB4803B4_const.initialization preserve=yes
  //## end Locator::Locator%3505AB4803B4_const.initialization
{
  //## begin archive::Locator::Locator%3505AB4803B4_const.body preserve=yes
   m_pBegin = new GlobalContext("##BEGIN");
   m_pEnd = new GlobalContext("##END");
   if (Extract::instance()->getString("DUSER   ","LM_TIMER=",m_strLocatorTime,6))
      m_hTimer.setAlarm(m_strLocatorTime.data());
   m_hTimer.attach(this);
  //## end archive::Locator::Locator%3505AB4803B4_const.body
}


Locator::~Locator()
{
  //## begin archive::Locator::~Locator%3505AB4803B4_dest.body preserve=yes
   delete m_pEnd;
   delete m_pBegin;
  //## end archive::Locator::~Locator%3505AB4803B4_dest.body
}



//## Other Operations (implementation)
bool Locator::getMonths (set<string,less <string> >& hMonths)
{
  //## begin archive::Locator::getMonths%3F72F59D036B.body preserve=yes
   hMonths.erase(hMonths.begin(),hMonths.end());
   string strYYYYMM;
   if (!m_pEnd->get(strYYYYMM,m_cType))
      return false;
   char szText[7] = {"000000"};
   if (strYYYYMM.length() < 6)
      return false;
   memcpy(szText,strYYYYMM.data(),6);
   int iEndMM = atoi(szText + 4);
   szText[4] = '\0';
   int iEndYYYY = atoi(szText);
   if (!m_pBegin->get(strYYYYMM,m_cType))
      return false;
   if (strYYYYMM.length() < 6)
      return false;
   memcpy(szText,strYYYYMM.data(),6);
   int iMM = atoi(szText + 4) - 1;
   szText[4] = '\0';
   int iYYYY = atoi(szText);
   while (iYYYY < iEndYYYY || iMM < iEndMM)
   {
      ++iMM;
      if (iMM > 12)
      {
         iMM = 1;
         iYYYY++;
      }
      snprintf(szText,sizeof(szText),"%04d%02d",iYYYY,iMM);
      hMonths.insert(string(szText));
   }
   return true;
  //## end archive::Locator::getMonths%3F72F59D036B.body
}

bool Locator::process (const char* pszMember, const char* pszYYYYMM)
{
  //## begin archive::Locator::process%3E4264650399.body preserve=yes
   char szHEXYM[3] = {"  "};
   char szNYYYYMM[7] = {"      "};
   szHEXYM[0] = pszYYYYMM[3];
   if (!memcmp(pszYYYYMM + 4,"10",2))
      szHEXYM[1] = 'A';
   else
   if (!memcmp(pszYYYYMM + 4,"11",2))
      szHEXYM[1] = 'B';
   else
   if (!memcmp(pszYYYYMM + 4,"12",2))
      szHEXYM[1] = 'C';
   else
      szHEXYM[1] = pszYYYYMM[5];
   string strDateTime(pszYYYYMM,6);
   int m = atoi(strDateTime.c_str());
   if (strDateTime.substr(4,2) == "12")
      m = m + 89;
   else
      m = m + 1;
   snprintf(szNYYYYMM,sizeof(szNYYYYMM),"%d",m);
   Job::submit(pszMember,"&YYYYMM ",pszYYYYMM,"&HEXYM  ",szHEXYM,"&NYYYYMM",szNYYYYMM);
   return true;
  //## end archive::Locator::process%3E4264650399.body
}

bool Locator::synchronize ()
{
  //## begin archive::Locator::synchronize%3E42646A02AF.body preserve=yes
   string strData;
   size_t nPos = m_strMinName.find_last_not_of(' ');
   if (nPos != string::npos)
      m_strMinName.erase(nPos + 1);
   nPos = string::npos;
   if ((nPos = m_strMinName.find("_L")) != string::npos 
      || (nPos = m_strMinName.find("_l")) != string::npos) 
      m_strMinYYYYMM = m_strMinName.substr(nPos + 2);
   else
   if ((nPos = m_strMinName.find("EJ_REC")) != string::npos
      || (nPos = m_strMinName.find("ej_rec")) != string::npos)
      m_strMinYYYYMM = m_strMinName.substr(nPos + 6);
   else
   if ((nPos = m_strMinName.find("AUDIT_MAINT")) != string::npos
      || (nPos = m_strMinName.find("audit_maint")) != string::npos)
      m_strMinYYYYMM = m_strMinName.substr(nPos + 11);
   else
   {
      char szTemp[7] = {"      "};
      int iYear = Clock::instance()->getYear();
      int iMonth = Clock::instance()->getMonth();
      if (iMonth == 1)
      {
         iMonth = 12;
         --iYear;
      }
      else
         --iMonth;
      if (Extract::instance()->getSpec("YYYYMM",m_strMinYYYYMM))
      {
         memcpy(szTemp,m_strMinYYYYMM.data(),6);
         iMonth = atoi(szTemp + 4);
         szTemp[4] = '\0';
         iYear = atoi(szTemp);
         if (iMonth == 1)
         {
            iMonth = 12;
            --iYear;
         }
         else
            --iMonth;
      }
      m_strMinYYYYMM.assign(szTemp,snprintf(szTemp,sizeof(szTemp),"%04d%02d",iYear,iMonth));
   }
   if (!m_pBegin->get(strData,m_cType))
      return false;
   if (strData < m_strMinYYYYMM)
      if (!m_pBegin->put(m_strMinYYYYMM.c_str(),m_cType))
         return false;
   nPos = string::npos;
   if ((nPos = m_strMaxName.find("_L")) != string::npos
      || (nPos = m_strMaxName.find("_l")) != string::npos)
      m_strMaxYYYYMM = m_strMaxName.substr(nPos + 2);
   else
   if ((nPos = m_strMaxName.find("EJ_REC")) != string::npos
      || (nPos = m_strMaxName.find("ej_rec")) != string::npos)
      m_strMaxYYYYMM = m_strMaxName.substr(nPos + 6);
   else
   if ((nPos = m_strMaxName.find("AUDIT_MAINT")) != string::npos
      || (nPos = m_strMaxName.find("audit_maint")) != string::npos)
      m_strMaxYYYYMM = m_strMaxName.substr(nPos + 11);
   else
      m_strMaxYYYYMM = m_strMinYYYYMM;
   if (!m_pEnd->get(strData,m_cType))
      return false;
   if (strData != m_strMaxYYYYMM)
      if (!m_pEnd->put(m_strMaxYYYYMM.c_str(),m_cType))
         return false;
   return true;
  //## end archive::Locator::synchronize%3E42646A02AF.body
}

void Locator::update (Subject* pSubject)
{
  //## begin archive::Locator::update%3E4264700222.body preserve=yes
   UseCase hUseCase("DR","## DR63 CHECK LOCATOR");
   if (Database::instance()->state() == Database::DISCONNECTED)
      return;
   m_hTimer.setAlarm(m_strLocatorTime.data());
   string strMember;
   char szTemp[7];
   if (!synchronize())
   {
      UseCase::setSuccess(false);
      Database::instance()->rollback();
      return;
   }
   Database::instance()->commit();
   char psText[20];
   memset(psText,'\0',sizeof(psText));
   memcpy(psText,m_strTableName.data(),m_strTableName.length());
   char* q = strstr(psText,"_L");
   // if it does not exist, create current month locator
   //if (m_lCount == 0
   //   || Clock::instance()->getYYYYMMDDHHMMSS().substr(0,6) > m_strMaxYYYYMM)
   while (Clock::instance()->getYYYYMMDDHHMMSS().substr(0,6) > m_strMaxYYYYMM)
   {
      UseCase hUseCase("DR","## DR02 CREATE LOCATOR");
      char szTemp[7] = {"      "};
      memcpy(szTemp,m_strMaxYYYYMM.data(),6);
      int iMonth = atoi(szTemp + 4);
      szTemp[4] = '\0';
      int iYear = atoi(szTemp);
      if (iMonth == 12)
      {
         iMonth = 1;
         ++iYear;
      }
      else
         ++iMonth;
      m_strMaxYYYYMM.assign(szTemp,snprintf(szTemp,sizeof(szTemp),"%04d%02d",iYear,iMonth));
      if (q)
         memcpy(q + 2,szTemp,6);
#ifdef MVS
      strMember = "DN##CR";
      strMember += m_cType;
      if (Extract::instance()->getCustomCode() == "MPS"
         && m_cType == 'F')
         strMember += "2";
      else
         strMember += "L";
#else
      strMember = "CXOXDRC";
      if (Extract::instance()->getCustomCode() == "MPS"
         && m_cType == 'F')
         strMember += "2";
      else
         strMember += m_cType;
#endif
      Console::display("ST109",psText);
      if (!process(strMember.c_str(),szTemp))
         UseCase::setSuccess(false);
   }
   int lDay = 21;
   Extract::instance()->getLong("DUSER   ","DAY=",&lDay);
   if (lDay > 27)
      lDay = 27;
   if (lDay < 10)
      lDay = 10;
   // create next month locator after the 21st
   if (Clock::instance()->getDay() > lDay)
   {
      int m = (Clock::instance()->getYear() * 100) + Clock::instance()->getMonth();
      if (Clock::instance()->getMonth() == 12)
         m = m + 89;
      else
         m = m + 1;
      snprintf(szTemp,sizeof(szTemp),"%d",m);
      if (strcmp(szTemp,m_strMaxYYYYMM.c_str()) > 0)
      {
         UseCase hUseCase("DR","## DR02 CREATE LOCATOR");
         if (q)
            memcpy(q + 2,szTemp,6);
#ifdef MVS
         strMember = "DN##CR";
         strMember += m_cType;
         if (Extract::instance()->getCustomCode() == "MPS"
            && m_cType == 'F')
            strMember += "2";
         else
            strMember += "L";
#else
         strMember = "CXOXDRC";
         if (Extract::instance()->getCustomCode() == "MPS"
            && m_cType == 'F')
            strMember += "2";
         else
            strMember += m_cType;
#endif
         Console::display("ST109",psText);
         if (Clock::instance()->getDay() >= 25 )
            Console::display("ST143");
         if (!process(strMember.c_str(),szTemp))
            UseCase::setSuccess(false);
      }
   }
   int lMonths = 8;
   string strKey("_MONTHS");
   strKey[0] = m_cType;
   string strValue;
   if (Extract::instance()->getSpec(strKey.c_str(),strValue))
      lMonths = atoi(strValue.c_str());
   else
      Extract::instance()->getLong("DUSER   ","TABLES=",&lMonths);
   if (lMonths < 3)
      lMonths = 3;
   // if 8 tables exist, drop oldest locator between the 14th and 21st
   if ((Clock::instance()->getDay() > (lDay - 7)
      && Clock::instance()->getDay() < lDay
      && m_lCount == lMonths)
      || m_lCount > lMonths)
   {
      UseCase hUseCase("DR","## DR03 DROP LOCATOR");
      if (q)
         memcpy(q + 2,m_strMinYYYYMM.data(),6);
#ifdef MVS
      strMember = "DN##DR";
      strMember += m_cType;
      if (Extract::instance()->getCustomCode() == "MPS"
         && m_cType == 'F')
         strMember += "2";
      else
         strMember += "L";
#else
      strMember = "CXOXDRD";
      if (Extract::instance()->getCustomCode() == "MPS"
         && m_cType == 'F')
         strMember += "2";
      else
         strMember += m_cType;
#endif
      Console::display("ST110",psText);
      if (m_cType == 'F')
      {
         Query hQuery;
         auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
         string strTSTAMP_TRANS(m_strMinYYYYMM);
         strTSTAMP_TRANS += "9999999999";
         hQuery.setBasicPredicate("PROBLEM_TRAN","TSTAMP_TRANS","<",strTSTAMP_TRANS.c_str());
         pDeleteStatement->execute(hQuery);
         Database::instance()->commit();
      }
      if (!process(strMember.c_str(),m_strMinYYYYMM.c_str()))
         UseCase::setSuccess(false);
   }
   //set updated BEGIN one day before drop
   if ((Clock::instance()->getDay() > (lDay - 8)
      && Clock::instance()->getDay() < lDay
      && m_lCount == lMonths)
      || m_lCount > lMonths)
   {
      string strMinYYYYMMDD(m_strMinYYYYMM);
      strMinYYYYMMDD.append("01",2);
      Date hDate(strMinYYYYMMDD.c_str());
      hDate += 31;
      string strMinYYYYMM(hDate.asString("%Y%m"));
      if (m_pBegin->put(strMinYYYYMM.c_str(),m_cType))
         Database::instance()->commit();
      else
         Database::instance()->rollback();
   }
  //## end archive::Locator::update%3E4264700222.body
}

bool Locator::exists (const string &strLocatorDate, char cContextType)
{
  //## begin archive::Locator::exists%4F96CE6502A0.body preserve=yes
	string strBegin,strEnd;
	m_pBegin->get(strBegin,cContextType);
	if (strBegin.length() == 0)
		return false;
	m_pEnd->get(strEnd,cContextType);
	if (strEnd.length() == 0)
		return false;
	if (strLocatorDate < strBegin || strLocatorDate > strEnd)
		return false;
	return true;
  //## end archive::Locator::exists%4F96CE6502A0.body
}

// Additional Declarations
  //## begin archive::Locator%3505AB4803B4.declarations preserve=yes
  //## end archive::Locator%3505AB4803B4.declarations

} // namespace archive

//## begin module%366C49DB02DE.epilog preserve=yes
//## end module%366C49DB02DE.epilog
