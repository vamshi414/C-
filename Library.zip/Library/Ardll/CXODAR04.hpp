//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%39CA5B000392.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%39CA5B000392.cm

//## begin module%39CA5B000392.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%39CA5B000392.cp

//## Module: CXOSAR04%39CA5B000392; Package specification
//## Subsystem: ARDLL%3597E7F203AA
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\ARDLL\CXODAR04.hpp

#ifndef CXOSAR04_h
#define CXOSAR04_h 1

//## begin module%39CA5B000392.additionalIncludes preserve=no
//## end module%39CA5B000392.additionalIncludes

//## begin module%39CA5B000392.includes preserve=yes
// $Date:   Jun 30 2006 12:15:34  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%39CA5B000392.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;

} // namespace reusable

//## begin module%39CA5B000392.declarations preserve=no
//## end module%39CA5B000392.declarations

//## begin module%39CA5B000392.additionalDeclarations preserve=yes
//## end module%39CA5B000392.additionalDeclarations


//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
//## begin archive%3451F7650251.initialDeclarations preserve=yes
//## end archive%3451F7650251.initialDeclarations

//## begin archive::ArchiveLocator%34770EF90377.preface preserve=yes
//## end archive::ArchiveLocator%34770EF90377.preface

//## Class: ArchiveLocator%34770EF90377
//	The ArchiveLocator class encapsulates access to the
//	archive locator table.
//
//	It is based on the Singleton pattern.
//
//	CXODAR04.hpp
//	CXOSAR04.cpp
//## Category: Archive::Archive_CAT%3451F7650251
//## Subsystem: ARDLL%3597E7F203AA
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%39B8E51D0133;database::GlobalContext { -> F}
//## Uses: <unnamed>%39B8E51F00C7;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%39B8E5210138;reusable::Table { -> F}
//## Uses: <unnamed>%39B8E52300EB;reusable::Statement { -> F}
//## Uses: <unnamed>%39B8E5720167;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%39C928B502D2;reusable::Query { -> F}

class DllExport ArchiveLocator : public reusable::Object  //## Inherits: <unnamed>%39C927D90286
{
  //## begin archive::ArchiveLocator%34770EF90377.initialDeclarations preserve=yes
  //## end archive::ArchiveLocator%34770EF90377.initialDeclarations

  public:
    //## Constructors (generated)
      ArchiveLocator();

    //## Destructor (generated)
      virtual ~ArchiveLocator();


    //## Other Operations (specified)
      //## Operation: getArchiveKey%347B72520068
      //	Return the archive key for a transaction (based on type
      //	of transaction, timestamp, and uniqueness key).
      bool getArchiveKey (char cType, const string& strTstampTrans, short iUniquenessKey, string& strArchiveKey);

      //## Operation: getLastTransaction%347B71CA0081
      //	Return the timestamp and uniqueness key of the last
      //	transaction (of a given type) in the archive.
      bool getLastTransaction (char cType, string& strTstampTrans, short* piUniquenessKey);

      //## Operation: put%34772487023B
      //	Add a new row to the archive locator table.
      bool put (char cType, const string& strTstampTrans, short iUniquenessKey, const string& strArchiveKey, int lRecordCount);

    // Additional Public Declarations
      //## begin archive::ArchiveLocator%34770EF90377.public preserve=yes
      //## end archive::ArchiveLocator%34770EF90377.public

  protected:
    // Additional Protected Declarations
      //## begin archive::ArchiveLocator%34770EF90377.protected preserve=yes
      //## end archive::ArchiveLocator%34770EF90377.protected

  private:
    // Additional Private Declarations
      //## begin archive::ArchiveLocator%34770EF90377.private preserve=yes
      //## end archive::ArchiveLocator%34770EF90377.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin archive::ArchiveLocator%34770EF90377.implementation preserve=yes
      //## end archive::ArchiveLocator%34770EF90377.implementation

};

//## begin archive::ArchiveLocator%34770EF90377.postscript preserve=yes
//## end archive::ArchiveLocator%34770EF90377.postscript

} // namespace archive

//## begin module%39CA5B000392.epilog preserve=yes
using namespace archive;
//## end module%39CA5B000392.epilog


#endif
