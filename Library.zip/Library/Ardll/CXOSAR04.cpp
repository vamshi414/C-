//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%39CA5B02009C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%39CA5B02009C.cm

//## begin module%39CA5B02009C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%39CA5B02009C.cp

//## Module: CXOSAR04%39CA5B02009C; Package body
//## Subsystem: ARDLL%3597E7F203AA
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\ARDLL\CXOSAR04.cpp

//## begin module%39CA5B02009C.additionalIncludes preserve=no
//## end module%39CA5B02009C.additionalIncludes

//## begin module%39CA5B02009C.includes preserve=yes
// $Date:   May 21 2020 20:25:14  $ $Author:   e1009510  $ $Revision:   1.7  $
#include <stdio.h>
//## end module%39CA5B02009C.includes

#ifndef CXOSAR04_h
#include "CXODAR04.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif


//## begin module%39CA5B02009C.declarations preserve=no
//## end module%39CA5B02009C.declarations

//## begin module%39CA5B02009C.additionalDeclarations preserve=yes
//## end module%39CA5B02009C.additionalDeclarations


//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
//## begin archive%3451F7650251.initialDeclarations preserve=yes
//## end archive%3451F7650251.initialDeclarations

// Class archive::ArchiveLocator 

ArchiveLocator::ArchiveLocator()
  //## begin ArchiveLocator::ArchiveLocator%34770EF90377_const.hasinit preserve=no
  //## end ArchiveLocator::ArchiveLocator%34770EF90377_const.hasinit
  //## begin ArchiveLocator::ArchiveLocator%34770EF90377_const.initialization preserve=yes
  //## end ArchiveLocator::ArchiveLocator%34770EF90377_const.initialization
{
  //## begin archive::ArchiveLocator::ArchiveLocator%34770EF90377_const.body preserve=yes
    memcpy(m_sID,"DB18",4);
  //## end archive::ArchiveLocator::ArchiveLocator%34770EF90377_const.body
}


ArchiveLocator::~ArchiveLocator()
{
  //## begin archive::ArchiveLocator::~ArchiveLocator%34770EF90377_dest.body preserve=yes
  //## end archive::ArchiveLocator::~ArchiveLocator%34770EF90377_dest.body
}



//## Other Operations (implementation)
bool ArchiveLocator::getArchiveKey (char cType, const string& strTstampTrans, short iUniquenessKey, string& strArchiveKey)
{
  //## begin archive::ArchiveLocator::getArchiveKey%347B72520068.body preserve=yes
   char pszType[2] = {" "};
   pszType[0] = cType;
   string strEnd(strTstampTrans.substr(0,8));
   strEnd += "23595999";
   Query hQuery;
   hQuery.bind("ARCHIVE_LOCATOR","ARCHIVE_KEY",Column::STRING,&strArchiveKey);
   hQuery.setBasicPredicate("ARCHIVE_LOCATOR","TSTAMP_END",">=",strTstampTrans.c_str());
   hQuery.setBasicPredicate("ARCHIVE_LOCATOR","TSTAMP_END","<=",strEnd.c_str());
   hQuery.setBasicPredicate("ARCHIVE_LOCATOR","TRANS_TYPE","=",pszType);
   hQuery.setOrderByClause("TSTAMP_END DESC");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   return (pSelectStatement->execute(hQuery));
  //## end archive::ArchiveLocator::getArchiveKey%347B72520068.body
}

bool ArchiveLocator::getLastTransaction (char cType, string& strTstampTrans, short* piUniquenessKey)
{
  //## begin archive::ArchiveLocator::getLastTransaction%347B71CA0081.body preserve=yes
   // Use ##ARCHIVED from TASK_CONTEXT
   GlobalContext hGlobalContext("##ARCHIVED");
   string strData;
   if (!hGlobalContext.get(strData,cType))
      return false;
   if (strData.length() > 16)
   {
      strTstampTrans = strData.substr(0,16);
      *piUniquenessKey = atoi((const char*)strData.substr(17).c_str());
      return true;
   }
   // Use the latest date from ARCHIVE_LOCATOR
   char pszType[2] = {" "};
   pszType[0] = cType;
   *piUniquenessKey = 0;
   short iNull = -1;
   Query hQuery;
   hQuery.bind("ARCHIVE_LOCATOR","TSTAMP_END",Column::STRING,&strTstampTrans,&iNull,"MAX");
   hQuery.setBasicPredicate("ARCHIVE_LOCATOR","TRANS_TYPE","=",pszType);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   if (iNull != -1)
      return true;
   // Use the earliest date from the appropriate table
   string strTable;
   switch (cType)
   {
      case 'A':
         strTable = "DEV_ADMIN";
         break;
      case 'F':
         strTable = "FIN_RECORD";
         break;
   }
   hQuery.reset();
   hQuery.bind(strTable.c_str(),"TSTAMP_TRANS",Column::STRING,&strTstampTrans,&iNull,"MIN");
   if (pSelectStatement->execute(hQuery) == false
      || iNull == -1)
      return false;
   strTstampTrans.erase(12,string::npos);
   strTstampTrans += "0000";
   return true;
  //## end archive::ArchiveLocator::getLastTransaction%347B71CA0081.body
}

bool ArchiveLocator::put (char cType, const string& strTstampTrans, short iUniquenessKey, const string& strArchiveKey, int lRecordCount)
{
  //## begin archive::ArchiveLocator::put%34772487023B.body preserve=yes
   Table hTable("ARCHIVE_LOCATOR");
   hTable.set("ARCHIVE_KEY",strArchiveKey);
   hTable.set("RECORD_COUNT",lRecordCount);
   hTable.set("TRANS_TYPE",string(&cType,1),false,true);
   hTable.set("TSTAMP_END",strTstampTrans,false,true);
   hTable.set("UNIQUE_KEY_END",(int)iUniquenessKey,true);
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   if (!pInsertStatement->execute(hTable))
      return false;
   GlobalContext hGlobalContext("##ARCHIVED");
   string strData(strTstampTrans);
   char szTemp[9];
   snprintf(szTemp,sizeof(szTemp)," %hd",iUniquenessKey);
   strData += szTemp;
   return hGlobalContext.put(strData.c_str(),cType);
  //## end archive::ArchiveLocator::put%34772487023B.body
}

// Additional Declarations
  //## begin archive::ArchiveLocator%34770EF90377.declarations preserve=yes
  //## end archive::ArchiveLocator%34770EF90377.declarations

} // namespace archive

//## begin module%39CA5B02009C.epilog preserve=yes
//## end module%39CA5B02009C.epilog
