//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%366C49DA000C.cm preserve=no
//	$Date:   Apr 26 2012 07:48:24  $ $Author:   E3003354  $
//	$Revision:   1.9  $
//## end module%366C49DA000C.cm

//## begin module%366C49DA000C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%366C49DA000C.cp

//## Module: CXOSAR05%366C49DA000C; Package specification
//## Subsystem: ARDLL%3597E7F203AA
//	.
//## Source file: C:\Devel\Dn\Server\Library\ARDLL\CXODAR05.hpp

#ifndef CXOSAR05_h
#define CXOSAR05_h 1

//## begin module%366C49DA000C.additionalIncludes preserve=no
//## end module%366C49DA000C.additionalIncludes

//## begin module%366C49DA000C.includes preserve=yes
// $Date:   Apr 26 2012 07:48:24  $ $Author:   E3003354  $ $Revision:   1.9  $
#include <set>
//## end module%366C49DA000C.includes

#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif
#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Job;
} // namespace IF

namespace reusable {
class Transaction;
} // namespace reusable

namespace IF {
class Console;
class DateTime;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseCatalog;
class GlobalContext;
class DatabaseFactory;

} // namespace database

//## begin module%366C49DA000C.declarations preserve=no
//## end module%366C49DA000C.declarations

//## begin module%366C49DA000C.additionalDeclarations preserve=yes
//## end module%366C49DA000C.additionalDeclarations


//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
//## begin archive%3451F7650251.initialDeclarations preserve=yes
//## end archive%3451F7650251.initialDeclarations

//## begin archive::Locator%3505AB4803B4.preface preserve=yes
//## end archive::Locator%3505AB4803B4.preface

//## Class: Locator%3505AB4803B4
//	The Locator class represents a DN data repository
//	locator table.
//## Category: Archive::Archive_CAT%3451F7650251
//## Subsystem: ARDLL%3597E7F203AA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%366D60F80369;database::GlobalContext { -> F}
//## Uses: <unnamed>%3E4266D0008C;IF::Job { -> F}
//## Uses: <unnamed>%3E42673D009C;database::Database { -> F}
//## Uses: <unnamed>%3E4267830157;monitor::UseCase { -> F}
//## Uses: <unnamed>%3E42679000AB;IF::Console { -> F}
//## Uses: <unnamed>%3E4267BA00DA;IF::Extract { -> F}
//## Uses: <unnamed>%3E4274A8036B;timer::Clock { -> F}
//## Uses: <unnamed>%41F158E1000F;database::DatabaseCatalog { -> F}
//## Uses: <unnamed>%41F1590701E4;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%41F15A6500EA;IF::DateTime { -> F}
//## Uses: <unnamed>%420A2D5D01F4;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%420A2D7F03A9;reusable::Query { -> F}
//## Uses: <unnamed>%4F97A8F602F2;reusable::Transaction { -> F}

class DllExport Locator : public reusable::Observer  //## Inherits: <unnamed>%3505B33003DC
{
  //## begin archive::Locator%3505AB4803B4.initialDeclarations preserve=yes
  //## end archive::Locator%3505AB4803B4.initialDeclarations

  public:
    //## Constructors (generated)
      Locator();

    //## Destructor (generated)
      virtual ~Locator();


    //## Other Operations (specified)
      //## Operation: getMonths%3F72F59D036B
      bool getMonths (set<string,less <string> >& hMonths);

      //## Operation: synchronize%3E42646A02AF
      virtual bool synchronize ();

      //## Operation: update%3E4264700222
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>LM
      //	<h2>MS
      //	<!-- Locator::update Preconditions -->
      //	<h3>Scalability
      //	<p>
      //	By default, the DataNavigator server provides six months
      //	of key information for transactions received from the
      //	acquiring platform.
      //	Eight tables are actually needed to provide access to at
      //	least six months of transactions.
      //	<p>
      //	Use the CR Client to change the Locator Manager in the
      //	Task book.
      //	The number of months can be changed by specifying
      //	TABLES=<i>nnnnnn</i> in the task user data.
      //	The minimum value for <i>nn</i> is 000003.
      //	The maximum value is 000099.
      //	<p>
      //	The DataNavigator server stores five types of
      //	transactions:
      //	<ul>
      //	<li>Financial (F)
      //	<li>ATM Electronic Journal (E)
      //	<li>Status (S)
      //	<li>Administrative (A)
      //	<li>File Maintenance (M)
      //	</ul>
      //	A different retention period can be specified for each
      //	record type (this overrides the value specified by the
      //	TABLES option).
      //	The retention is specified in the Site Specification
      //	data for the Locator Manager task.
      //	Configure any of the following keys with a numeric value
      //	<i>n</i> between 3 and 99:
      //	<ul>
      //	<li>FMONTHS,<i>n</i>
      //	<li>EMONTHS,<i>n</i>
      //	<li>SMONTHS,<i>n</i>
      //	<li>AMONTHS,<i>n</i>
      //	<li>MMONTHS,<i>n</i>
      //	</ul>
      //	<p>
      //	The DataNavigator server distributes raw data files to
      //	external systems.
      //	Copies of the distributed files are retained in the data
      //	repository for a configured number of days.
      //	The files for each calendar day are kept in a separate
      //	table.
      //	By default, the server retains 15 days of backup to
      //	allow retransmission.
      //	Tables for seven days into the future are created as
      //	needed.
      //	The create and drop scripts for the daily export tables
      //	are submitted automatically at midnight each day.
      //	<p>
      //	Use the CR Client to change the Locator Manager in the
      //	Task book.
      //	The number of days can be changed by specifying
      //	DXDAYS=<i>nnnnnn</i> in the task user data.
      //	The minimum value for <i>nnnnnn</i> is 000015.
      //	The maximum value is 000180.
      //	</body>
      //	<body>
      //	<title>CG
      //	<h1>LM
      //	<h2>MS
      //	<h3>Scheduling
      //	<p>
      //	By default, the Locator Manager service submits scripts
      //	at 9:00 AM.
      //	The scripts for monthly table creation are submitted on
      //	the 21st day of the month.
      //	The scripts to drop the oldest monthly tables will be
      //	submitted one week prior to the table creation scripts.
      //	<p>
      //	Any script that fails will be automatically submitted
      //	again the next day until it succeeds.
      //	New tables should be verified by the DBA each month
      //	before transaction loading begins.
      //	<p>
      //	Use the CR Client to change the Locator Manager in the
      //	Task book.
      //	The time of day that scripts are submitted can be
      //	changed by specifying LM_TIMER=<i>hhmmss</i> in the task
      //	user data.
      //	The day that creation scripts are submitted can be
      //	changed by specifying DAY=<i>nn</i> in the task user
      //	data.
      //	The value for <i>nn</i> must be from 10 to 27.
      //	</body>
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

      //## Operation: exists%4F96CE6502A0
      bool exists (const string &strLocatorDate, char cContextType);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: TableName%3505B05F01EB
      //	The table name prefix of this locator (e.g. "FIN_L").
      void setTableName (const string& value)
      {
        //## begin archive::Locator::setTableName%3505B05F01EB.set preserve=no
        m_strTableName = value;
        //## end archive::Locator::setTableName%3505B05F01EB.set
      }


      //## Attribute: Type%3505C300031F
      //	The type of transactions contained in this locator ('F'
      //	: financial, 'M' : file maintenance, or 'S' : status).
      void setType (char value)
      {
        //## begin archive::Locator::setType%3505C300031F.set preserve=no
        m_cType = value;
        //## end archive::Locator::setType%3505C300031F.set
      }


    // Additional Public Declarations
      //## begin archive::Locator%3505AB4803B4.public preserve=yes
      //## end archive::Locator%3505AB4803B4.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Begin%3505C4220203
      //	The global context item representing the beginning table
      //	for this locator.
      //## begin archive::Locator::Begin%3505C4220203.attr preserve=no  protected: database::GlobalContext* {U} 
      database::GlobalContext* m_pBegin;
      //## end archive::Locator::Begin%3505C4220203.attr

      //## Attribute: Count%3E42720703A9
      //## begin archive::Locator::Count%3E42720703A9.attr preserve=no  protected: int {VA} 0
      int m_lCount;
      //## end archive::Locator::Count%3E42720703A9.attr

      //## Attribute: End%3505C42E01B0
      //	The global context item representing the ending table
      //	for this locator.
      //## begin archive::Locator::End%3505C42E01B0.attr preserve=no  protected: database::GlobalContext* {U} 
      database::GlobalContext* m_pEnd;
      //## end archive::Locator::End%3505C42E01B0.attr

      //## Attribute: MaxName%3E42B3150000
      //## begin archive::Locator::MaxName%3E42B3150000.attr preserve=no  protected: string {VA} 
      string m_strMaxName;
      //## end archive::Locator::MaxName%3E42B3150000.attr

      //## Attribute: MinName%3E42B316031C
      //## begin archive::Locator::MinName%3E42B316031C.attr preserve=no  protected: string {VA} 
      string m_strMinName;
      //## end archive::Locator::MinName%3E42B316031C.attr

      //## begin archive::Locator::TableName%3505B05F01EB.attr preserve=no  public: string {U} 
      string m_strTableName;
      //## end archive::Locator::TableName%3505B05F01EB.attr

      //## begin archive::Locator::Type%3505C300031F.attr preserve=no  public: char {U} ' '
      char m_cType;
      //## end archive::Locator::Type%3505C300031F.attr

    // Additional Protected Declarations
      //## begin archive::Locator%3505AB4803B4.protected preserve=yes
      //## end archive::Locator%3505AB4803B4.protected

  private:

    //## Other Operations (specified)
      //## Operation: process%3E4264650399
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>LM
      //	<h2>MS
      //	<!-- Locator::process Preconditions -->
      //	<h3>Database Structure
      //	<p>
      //	The DataNavigator server submits scripts to create new
      //	daily and monthly tables as needed.
      //	It also submits scripts to drop the oldest tables to
      //	retain the configured number of months of transaction
      //	data and days of distributed data.
      //	New releases of the DataNavigator server may require
      //	changes to the DDL in these scripts.
      //	<p>
      //	The following scripts are located in
      //	<i>node001</i>\*\Source:
      //	<p>
      //	<table>
      //	<tr>
      //	<th>Task
      //	<th>Script
      //	<th>Purpose
      //	<tr>
      //	<td>Create Locator
      //	<td>CXOXDRCA
      //	<td>Create next months DEV_ADMIN_L<i>yyyymm</i> locator
      //	table.
      //	<tr>
      //	<td>Create Locator
      //	<td>CXOXDRCF
      //	<td>Create next months FIN_L<i>yyyymm</i> locator table
      //	and FIN_RECORD<i>yyyymm</i> transaction table.
      //	<tr>
      //	<td>Create Locator
      //	<td>CXOXDRCM
      //	<td>Create next months FILE_MAINT_L<i>yyyymm</i> locator
      //	table.
      //	<tr>
      //	<td>Create Locator
      //	<td>CXOXDRCS
      //	<td>Create next months STAT_REC_L<i>yyyymm</i> locator
      //	table.
      //	<tr>
      //	<td>Create Daily Data Distribution
      //	<td>CXOXDRCX
      //	<td>Create daily DX_DATA_<i>yyyymmdd</i> data
      //	distribution table.
      //	<tr>
      //	<td>Drop Duplicate Index
      //	<td>CXOXDRDI
      //	<td>Drop last months business duplicate index (only used
      //	during transaction loading).
      //	<tr>
      //	<td>Drop Locator
      //	<td>CXOXDRDA
      //	<td>Drop the oldest DEV_ADMIN_L<i>yyyymm</i> locator
      //	table.
      //	<tr>
      //	<td>Drop Locator
      //	<td>CXOXDRDF
      //	<td>Drop the oldest FIN_L<i>yyyymm</i> locator table and
      //	FIN_RECORD<i>yyyymm</i> transaction table.
      //	<tr>
      //	<td>Drop Locator
      //	<td>CXOXDRDM
      //	<td>Drop the oldest FILE_MAINT_L<i>yyyymm</i> locator
      //	table.
      //	<tr>
      //	<td>Drop Locator
      //	<td>CXOXDRDS
      //	<td>Drop the oldest STAT_REC_L<i>yyyymm</i> locator
      //	table.
      //	<tr>
      //	<td>Drop Daily Data Distribution
      //	<td>CXOXDRDX
      //	<td>Drop the oldest DX_DATA_<i>yyyymmdd</i> data
      //	distribution table.
      //	</table>
      //	<p>
      //	Change each script as needed to comply with your
      //	installation standards and to implement changes needed
      //	for new releases of the DataNavigator server.
      //	</body>
      //## Postconditions:
      //	<body>
      //	<title>CG
      //	<h1>LM
      //	<h2>FO
      //	<!-- Locator::process Postconditions -->
      //	<h3>Data Repository Tables
      //	<p>
      //	The Locator Manager service creates (and drops) the
      //	following tables:
      //	<ul>
      //	<li><i>custqual</i>.DEV_ADMIN_L<i>yyyymm</i>
      //	<li><i>custqual</i>.DX_DATA_<i>yyyymmdd</i>
      //	<li><i>custqual</i>.FILE_MAINT_L<i>yyyymm</i>
      //	<li><i>custqual</i>.FIN_L<i>yyyymm</i>
      //	<li><i>custqual</i>.FIN_RECORD<i>yyyymm</i>
      //	<li><i>custqual</i>.STAT_REC_L<i>yyyymm</i>
      //	</ul>
      //	</body>
      bool process (const char* pszMember, const char* pszYYYYMM);

    // Additional Private Declarations
      //## begin archive::Locator%3505AB4803B4.private preserve=yes
      //## end archive::Locator%3505AB4803B4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: LocatorTime%3E4264950290
      //## begin archive::Locator::LocatorTime%3E4264950290.attr preserve=no  private: string {U} "090000"
      string m_strLocatorTime;
      //## end archive::Locator::LocatorTime%3E4264950290.attr

      //## Attribute: MaxYYYYMM%3E42709E0280
      //## begin archive::Locator::MaxYYYYMM%3E42709E0280.attr preserve=no  private: string {V} 
      string m_strMaxYYYYMM;
      //## end archive::Locator::MaxYYYYMM%3E42709E0280.attr

      //## Attribute: MinYYYYMM%3E427088032C
      //## begin archive::Locator::MinYYYYMM%3E427088032C.attr preserve=no  private: string {V} 
      string m_strMinYYYYMM;
      //## end archive::Locator::MinYYYYMM%3E427088032C.attr

    // Data Members for Associations

      //## Association: Archive::Archive_CAT::<unnamed>%3E4274F700CB
      //## Role: Locator::<m_hTimer>%3E4274F8000F
      //## begin archive::Locator::<m_hTimer>%3E4274F8000F.role preserve=no  public: timer::Timer { -> VHgN}
      timer::Timer m_hTimer;
      //## end archive::Locator::<m_hTimer>%3E4274F8000F.role

    // Additional Implementation Declarations
      //## begin archive::Locator%3505AB4803B4.implementation preserve=yes
      //## end archive::Locator%3505AB4803B4.implementation

};

//## begin archive::Locator%3505AB4803B4.postscript preserve=yes
//## end archive::Locator%3505AB4803B4.postscript

} // namespace archive

//## begin module%366C49DA000C.epilog preserve=yes
using namespace archive;
//## end module%366C49DA000C.epilog


#endif
