//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%422632620242.cm preserve=no
//	$Date:   May 13 2009 16:12:46  $ $Author:   D92186  $
//	$Revision:   1.4  $
//## end module%422632620242.cm

//## begin module%422632620242.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%422632620242.cp

//## Module: CXOSAR06%422632620242; Package specification
//## Subsystem: ARDLL%3597E7F203AA
//	.
//## Source file: C:\Devel\Dn\Server\Library\ARDLL\CXODAR06.hpp

#ifndef CXOSAR06_h
#define CXOSAR06_h 1

//## begin module%422632620242.additionalIncludes preserve=no
//## end module%422632620242.additionalIncludes

//## begin module%422632620242.includes preserve=yes
// $Date:   May 13 2009 16:12:46  $ $Author:   D92186  $ $Revision:   1.4  $
//## end module%422632620242.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Job;
} // namespace IF

namespace reusable {
class KeyRing;
class KeyManager;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseCatalog;
class DatabaseFactory;
class Database;
class AESKeyManager;

} // namespace database

//## begin module%422632620242.declarations preserve=no
//## end module%422632620242.declarations

//## begin module%422632620242.additionalDeclarations preserve=yes
//## end module%422632620242.additionalDeclarations


//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
//## begin archive%3451F7650251.initialDeclarations preserve=yes
//## end archive%3451F7650251.initialDeclarations

//## begin archive::ExportData%4226318D033C.preface preserve=yes
//## end archive::ExportData%4226318D033C.preface

//## Class: ExportData%4226318D033C
//## Category: Archive::Archive_CAT%3451F7650251
//## Subsystem: ARDLL%3597E7F203AA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%42263B1E032C;database::Database { -> F}
//## Uses: <unnamed>%42263DA4037A;timer::Date { -> F}
//## Uses: <unnamed>%42263DBA0203;database::DatabaseCatalog { -> F}
//## Uses: <unnamed>%42270F8200AB;IF::Job { -> F}
//## Uses: <unnamed>%42270FAD034B;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4227183E0128;monitor::UseCase { -> F}
//## Uses: <unnamed>%42271E720000;IF::Extract { -> F}
//## Uses: <unnamed>%4228BA3D0167;reusable::Query { -> F}
//## Uses: <unnamed>%4228BA4901D4;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4976186C0248;database::AESKeyManager { -> F}
//## Uses: <unnamed>%4A006CFF017D;reusable::KeyManager { -> F}
//## Uses: <unnamed>%4A006D0103A6;reusable::KeyRing { -> F}

class DllExport ExportData : public reusable::Observer  //## Inherits: <unnamed>%422631A900AB
{
  //## begin archive::ExportData%4226318D033C.initialDeclarations preserve=yes
  //## end archive::ExportData%4226318D033C.initialDeclarations

  public:
    //## Constructors (generated)
      ExportData();

    //## Destructor (generated)
      virtual ~ExportData();


    //## Other Operations (specified)
      //## Operation: process%422713A70222
      bool process (const char* pszUseCase, const char* pszMember, const char* pszTableName);

      //## Operation: processPADSS%4A048D0A029C
      void processPADSS (const string& strContext);

      //## Operation: update%422631B100DA
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin archive::ExportData%4226318D033C.public preserve=yes
      //## end archive::ExportData%4226318D033C.public

  protected:
    // Additional Protected Declarations
      //## begin archive::ExportData%4226318D033C.protected preserve=yes
      //## end archive::ExportData%4226318D033C.protected

  private:
    // Additional Private Declarations
      //## begin archive::ExportData%4226318D033C.private preserve=yes
      //## end archive::ExportData%4226318D033C.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin archive::ExportData%4226318D033C.implementation preserve=yes
      //## end archive::ExportData%4226318D033C.implementation

};

//## begin archive::ExportData%4226318D033C.postscript preserve=yes
//## end archive::ExportData%4226318D033C.postscript

} // namespace archive

//## begin module%422632620242.epilog preserve=yes
using namespace archive;
//## end module%422632620242.epilog


#endif
