//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%367523E4025C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%367523E4025C.cm

//## begin module%367523E4025C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%367523E4025C.cp

//## Module: CXOSAR01%367523E4025C; Package body
//## Subsystem: ARDLL%3597E7F203AA
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\ARDLL\CXOSAR01.cpp

//## begin module%367523E4025C.additionalIncludes preserve=no
//## end module%367523E4025C.additionalIncludes

//## begin module%367523E4025C.includes preserve=yes
// $Date:   Apr 08 2004 12:42:44  $ $Author:   D02405  $ $Revision:   1.7  $
//## end module%367523E4025C.includes

#ifndef CXOSAR03_h
#include "CXODAR03.hpp"
#endif
#ifndef CXOSAR01_h
#include "CXODAR01.hpp"
#endif
#ifndef CXODAR02_h
#include "CXODAR02.hpp"
#endif


//## begin module%367523E4025C.declarations preserve=no
//## end module%367523E4025C.declarations

//## begin module%367523E4025C.additionalDeclarations preserve=yes
//## end module%367523E4025C.additionalDeclarations


//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
//## begin archive%3451F7650251.initialDeclarations preserve=yes
//## end archive%3451F7650251.initialDeclarations

// Class archive::ArchiveFactory 

//## begin archive::ArchiveFactory::Instance%347600110233.attr preserve=no  private: static ArchiveFactory* {V} 0
ArchiveFactory* ArchiveFactory::m_pInstance = 0;
//## end archive::ArchiveFactory::Instance%347600110233.attr

ArchiveFactory::ArchiveFactory()
  //## begin ArchiveFactory::ArchiveFactory%3475FFBA0165_const.hasinit preserve=no
  //## end ArchiveFactory::ArchiveFactory%3475FFBA0165_const.hasinit
  //## begin ArchiveFactory::ArchiveFactory%3475FFBA0165_const.initialization preserve=yes
  //## end ArchiveFactory::ArchiveFactory%3475FFBA0165_const.initialization
{
  //## begin archive::ArchiveFactory::ArchiveFactory%3475FFBA0165_const.body preserve=yes
   m_pInstance = this;
  //## end archive::ArchiveFactory::ArchiveFactory%3475FFBA0165_const.body
}


ArchiveFactory::~ArchiveFactory()
{
  //## begin archive::ArchiveFactory::~ArchiveFactory%3475FFBA0165_dest.body preserve=yes
  //## end archive::ArchiveFactory::~ArchiveFactory%3475FFBA0165_dest.body
}



//## Other Operations (implementation)
ArchiveFactory* ArchiveFactory::instance ()
{
  //## begin archive::ArchiveFactory::instance%34760064003D.body preserve=yes
   return m_pInstance;
  //## end archive::ArchiveFactory::instance%34760064003D.body
}

// Additional Declarations
  //## begin archive::ArchiveFactory%3475FFBA0165.declarations preserve=yes
  //## end archive::ArchiveFactory%3475FFBA0165.declarations

} // namespace archive

//## begin module%367523E4025C.epilog preserve=yes
//## end module%367523E4025C.epilog

