//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%367521CE00E1.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%367521CE00E1.cm

//## begin module%367521CE00E1.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%367521CE00E1.cp

//## Module: CXOSAR03%367521CE00E1; Package body
//## Subsystem: ARDLL%3597E7F203AA
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\ARDLL\CXOSAR03.cpp

//## begin module%367521CE00E1.additionalIncludes preserve=no
//## end module%367521CE00E1.additionalIncludes

//## begin module%367521CE00E1.includes preserve=yes
// $Date:   Jun 30 2006 12:15:34  $ $Author:   D02405  $ $Revision:   1.12  $
//## end module%367521CE00E1.includes

#ifndef CXOSAR03_h
#include "CXODAR03.hpp"
#endif
//## begin module%367521CE00E1.declarations preserve=no
//## end module%367521CE00E1.declarations

//## begin module%367521CE00E1.additionalDeclarations preserve=yes
//## end module%367521CE00E1.additionalDeclarations


//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
//## begin archive%3451F7650251.initialDeclarations preserve=yes
//## end archive%3451F7650251.initialDeclarations

// Class archive::ArchiveRetriever 


//## begin archive::ArchiveRetriever::Instance%348550EC0159.attr preserve=no  private: static ArchiveRetriever* {V} 0
ArchiveRetriever* ArchiveRetriever::m_pInstance = 0;
//## end archive::ArchiveRetriever::Instance%348550EC0159.attr





ArchiveRetriever::ArchiveRetriever()
  //## begin ArchiveRetriever::ArchiveRetriever%34854F420188_const.hasinit preserve=no
      : m_lInfoIDNumber(0)
  //## end ArchiveRetriever::ArchiveRetriever%34854F420188_const.hasinit
  //## begin ArchiveRetriever::ArchiveRetriever%34854F420188_const.initialization preserve=yes
  //## end ArchiveRetriever::ArchiveRetriever%34854F420188_const.initialization
{
  //## begin archive::ArchiveRetriever::ArchiveRetriever%34854F420188_const.body preserve=yes
   m_pInstance = this;
  //## end archive::ArchiveRetriever::ArchiveRetriever%34854F420188_const.body
}


ArchiveRetriever::~ArchiveRetriever()
{
  //## begin archive::ArchiveRetriever::~ArchiveRetriever%34854F420188_dest.body preserve=yes
  //## end archive::ArchiveRetriever::~ArchiveRetriever%34854F420188_dest.body
}



//## Other Operations (implementation)
int ArchiveRetriever::closeArchive ()
{
  //## begin archive::ArchiveRetriever::closeArchive%37D95E6503E4.body preserve=yes
   return 0;
  //## end archive::ArchiveRetriever::closeArchive%37D95E6503E4.body
}

bool ArchiveRetriever::get (char cType, const char* pszTimestamp, short int iUniquenessKey, void* pBuffer, int nMaxBufferLength, int* pnBufferLength)
{
  //## begin archive::ArchiveRetriever::get%34855116009B.body preserve=yes
   return false;
  //## end archive::ArchiveRetriever::get%34855116009B.body
}

ArchiveRetriever* ArchiveRetriever::instance ()
{
  //## begin archive::ArchiveRetriever::instance%3485511B0228.body preserve=yes
   if (!m_pInstance)
      new ArchiveRetriever();
   return m_pInstance;
  //## end archive::ArchiveRetriever::instance%3485511B0228.body
}

void ArchiveRetriever::update (Subject* pSubject)
{
  //## begin archive::ArchiveRetriever::update%3C0E71790102.body preserve=yes
  //## end archive::ArchiveRetriever::update%3C0E71790102.body
}

// Additional Declarations
  //## begin archive::ArchiveRetriever%34854F420188.declarations preserve=yes
  //## end archive::ArchiveRetriever%34854F420188.declarations

} // namespace archive

//## begin module%367521CE00E1.epilog preserve=yes
//## end module%367521CE00E1.epilog
