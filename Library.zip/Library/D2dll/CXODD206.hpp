//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4915EB0D003E.cm preserve=no
//	$Date:   Jan 31 2017 16:46:44  $ $Author:   e1009510  $
//	$Revision:   1.11  $
//## end module%4915EB0D003E.cm

//## begin module%4915EB0D003E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4915EB0D003E.cp

//## Module: CXOSD206%4915EB0D003E; Package specification
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\Dn\Server\Library\D2dll\CXODD206.hpp

#ifndef CXOSD206_h
#define CXOSD206_h 1

//## begin module%4915EB0D003E.additionalIncludes preserve=no
//## end module%4915EB0D003E.additionalIncludes

//## begin module%4915EB0D003E.includes preserve=yes
//## end module%4915EB0D003E.includes

#ifndef CXOSRC01_h
#include "CXODRC01.hpp"
#endif

//## Modelname: DataNavigator Foundation::Partition_CAT%346B9162029B
namespace partition {
class PartitionControl;
} // namespace partition

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialBaseSegment;
class FinancialSettlementSegment;
class FinancialReversalSegment;
class FinancialFeeSegment;
class FinancialAdjustmentSegment;
class FinancialUserSegment;
class FinancialAdjustmentExtensionSegment;
class MultipleRouteSegment;
class FraudBlockSegment;
class IntegratedCircuitCardSegment;
} // namespace repositorysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class KeyRing;
class Transaction;
class SelectStatement;
class Query;
class Column;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Memory;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;
class InsertSequenceNumber;
class UniquenessKey;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class RepositorySegment;
class ListSegment;

} // namespace segment

//## begin module%4915EB0D003E.declarations preserve=no
//## end module%4915EB0D003E.declarations

//## begin module%4915EB0D003E.additionalDeclarations preserve=yes
//## end module%4915EB0D003E.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

//## begin dndb2database::UDBAddFinancialCommand%4915E99F001F.preface preserve=yes
//## end dndb2database::UDBAddFinancialCommand%4915E99F001F.preface

//## Class: UDBAddFinancialCommand%4915E99F001F
//## Category: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
//## Subsystem: D2DLL%3597E8A6029B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4915EA0B000F;partition::PartitionControl { -> F}
//## Uses: <unnamed>%4915EA110399;repositorysegment::FinancialAdjustmentSegment { -> F}
//## Uses: <unnamed>%4915EA170203;repositorysegment::FinancialFeeSegment { -> F}
//## Uses: <unnamed>%4915EA1A0213;IF::Extract { -> F}
//## Uses: <unnamed>%4915EA1D0186;monitor::UseCase { -> F}
//## Uses: <unnamed>%4915EA2301B5;IF::Trace { -> F}
//## Uses: <unnamed>%4915EA2C0109;timer::Clock { -> F}
//## Uses: <unnamed>%4915EA31029F;repositorysegment::FinancialAdjustmentExtensionSegment { -> F}
//## Uses: <unnamed>%4915EA3302BF;repositorysegment::FinancialUserSegment { -> F}
//## Uses: <unnamed>%4915EA38009C;repositorysegment::FinancialReversalSegment { -> F}
//## Uses: <unnamed>%4915EA3C003E;repositorysegment::FinancialSettlementSegment { -> F}
//## Uses: <unnamed>%4915EA4302BF;repositorysegment::FinancialBaseSegment { -> F}
//## Uses: <unnamed>%4915EA4F00CB;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4915EA5900FA;reusable::Column { -> F}
//## Uses: <unnamed>%4915EA65036B;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4915EA71032C;reusable::Query { -> F}
//## Uses: <unnamed>%4915EAC4009C;database::Database { -> F}
//## Uses: <unnamed>%49171C53034B;repositorysegment::IntegratedCircuitCardSegment { -> F}
//## Uses: <unnamed>%49171D0701E4;reusable::Transaction { -> F}
//## Uses: <unnamed>%49171EE90177;segment::ListSegment { -> F}
//## Uses: <unnamed>%49171F6F03A9;database::InsertSequenceNumber { -> F}
//## Uses: <unnamed>%4C0CCCD2014B;repositorysegment::FraudBlockSegment { -> F}
//## Uses: <unnamed>%54576F350267;database::UniquenessKey { -> F}
//## Uses: <unnamed>%5486234300AD;reusable::KeyRing { -> F}
//## Uses: <unnamed>%548623D903DB;segment::RepositorySegment { -> F}
//## Uses: <unnamed>%5486245F0046;repositorysegment::MultipleRouteSegment { -> F}

class DllExport UDBAddFinancialCommand : public repositorycommand::AddFinancialCommand  //## Inherits: <unnamed>%4915E9F5002E
{
  //## begin dndb2database::UDBAddFinancialCommand%4915E99F001F.initialDeclarations preserve=yes
  private:
      enum State
      {
         PREPARE_SELECT_FIN_L,
         SELECT_FIN_L,
         PREPARE_INSERT_FIN_L,
         PREPARE_RETRY,
         INSERT_FIN_L,
         PREPARE_INSERT_FIN_ICC,
         INSERT_FIN_ICC,
         PREPARE_INSERT_MULTIPLE_ROUTE,
         INSERT_MULTIPLE_ROUTE,
         PREPARE_INSERT_FRAUD_RULE,
         INSERT_FRAUD_RULE,
         PREPARE_INSERT_FIN_RECORD,
         INSERT_FIN_RECORD,
         SUCCESS,
         EXIT,
         PREPARE_UPDATE_FIN_L,
         UPDATE_FIN_L,
         PREPARE_UPDATE_FIN_RECORD,
         UPDATE_FIN_RECORD,
         INTERPRET_DUPLICATE,
         TIMESTAMP_DUPLICATE,
         INSERT_DEADLOCK_TIMEOUT,
         UPDATE_DEADLOCK_TIMEOUT,
         DATABASE_FAILURE,
         DATABASE_CONNECTION_ERROR,
         RESOURCE_UNAVAILABLE_ERROR
      };
  //## end dndb2database::UDBAddFinancialCommand%4915E99F001F.initialDeclarations

  public:
    //## Constructors (generated)
      UDBAddFinancialCommand();

    //## Destructor (generated)
      virtual ~UDBAddFinancialCommand();


    //## Other Operations (specified)
      //## Operation: execute%4915EAB1034B
      //	Perform the functions of this command.
      virtual bool execute ();

    // Additional Public Declarations
      //## begin dndb2database::UDBAddFinancialCommand%4915E99F001F.public preserve=yes
      //## end dndb2database::UDBAddFinancialCommand%4915E99F001F.public

  protected:
    // Additional Protected Declarations
      //## begin dndb2database::UDBAddFinancialCommand%4915E99F001F.protected preserve=yes
      //## end dndb2database::UDBAddFinancialCommand%4915E99F001F.protected

  private:

    //## Other Operations (specified)
      //## Operation: copyAdjustmentToHost%4915EAB102EE
      void copyAdjustmentToHost ();

      //## Operation: copyAdjustmentExtensionToHost%4915EAB102EF
      void copyAdjustmentExtensionToHost ();

      //## Operation: copyFeeToHost%4915EAB102FD
      void copyFeeToHost ();

      //## Operation: copyICCToHost%491719DB03D8
      void copyICCToHost ();

      //## Operation: copyFraudRuleToHost%4C0CCD960266
      bool copyFraudRuleToHost ();

      //## Operation: copyMemberToHost%4915EAB1030D
      void copyMemberToHost ();

      //## Operation: copyMultipleRouteToHost%54861FB00335
      void copyMultipleRouteToHost ();

      //## Operation: copyReversalToHost%4915EAB1031C
      void copyReversalToHost ();

      //## Operation: copySettlementToHost%4915EAB1032C
      void copySettlementToHost ();

      //## Operation: copyUserToHost%4915EAB1033C
      void copyUserToHost ();

      //## Operation: insertFinancial%4915EAB1035B
      UDBAddFinancialCommand::State insertFinancial ();

      //## Operation: insertICC%4917192B01E4
      UDBAddFinancialCommand::State insertICC ();

      //## Operation: insertFraudRule%4C0CCD130227
      UDBAddFinancialCommand::State insertFraudRule ();

      //## Operation: insertLocator%4915EAB1036B
      UDBAddFinancialCommand::State insertLocator ();

      //## Operation: insertMultipleRoute%54861FF60310
      UDBAddFinancialCommand::State insertMultipleRoute ();

      //## Operation: interpretDuplicate%4915EAB1037A
      UDBAddFinancialCommand::State interpretDuplicate ();

      //## Operation: prepareICC%491719B401B5
      UDBAddFinancialCommand::State prepareICC ();

      //## Operation: prepareFraudRule%4C0CCD690014
      UDBAddFinancialCommand::State prepareFraudRule ();

      //## Operation: prepareInsert%4915EAB1038A
      UDBAddFinancialCommand::State prepareInsert ();

      //## Operation: prepareMonthlyFinancial%4915EAB1038B
      UDBAddFinancialCommand::State prepareMonthlyFinancial ();

      //## Operation: prepareMonthlyUpdateFinancial%4915EAB10399
      UDBAddFinancialCommand::State prepareMonthlyUpdateFinancial ();

      //## Operation: prepareMultipleRoute%5486201D03B3
      UDBAddFinancialCommand::State prepareMultipleRoute ();

      //## Operation: prepareSelect%4915EAB103A9
      UDBAddFinancialCommand::State prepareSelect ();

      //## Operation: prepareUpdate%4915EAB103AA
      UDBAddFinancialCommand::State prepareUpdate ();

      //## Operation: resetAdjustmentHost%4915EAB103B9
      void resetAdjustmentHost ();

      //## Operation: resetAdjustmentExtensionHost%4915EAB103C8
      void resetAdjustmentExtensionHost ();

      //## Operation: resetFeeHost%4915EAB103C9
      void resetFeeHost ();

      //## Operation: resetICCHost%49171A0001E4
      void resetICCHost ();

      //## Operation: resetMultipleRouteHost%548620380345
      void resetMultipleRouteHost ();

      //## Operation: resetReversalHost%4915EAB103D8
      void resetReversalHost ();

      //## Operation: resetSettlementHost%4915EAB20000
      void resetSettlementHost ();

      //## Operation: resetUserHost%4915EAB2000F
      void resetUserHost ();

      //## Operation: selectLocator%4915EAB20010
      UDBAddFinancialCommand::State selectLocator ();

      //## Operation: updateFinancial%4915EAB2001F
      UDBAddFinancialCommand::State updateFinancial ();

      //## Operation: updateLocator%4915EAB2002E
      UDBAddFinancialCommand::State updateLocator ();

    // Additional Private Declarations
      //## begin dndb2database::UDBAddFinancialCommand%4915E99F001F.private preserve=yes
      bool checkForBusinessDuplicate (const char* pszTSTAMP_TRANS);
      //## end dndb2database::UDBAddFinancialCommand%4915E99F001F.private
  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%4C0CE20A02B0
      //## begin dndb2database::UDBAddFinancialCommand::Buffer%4C0CE20A02B0.attr preserve=no  private: char {R} 0
      char *m_pBuffer;
      //## end dndb2database::UDBAddFinancialCommand::Buffer%4C0CE20A02B0.attr

      //## Attribute: OptLogic%54861BB70092
      //## begin dndb2database::UDBAddFinancialCommand::OptLogic%54861BB70092.attr preserve=no  private: vector<pair<int,RepositorySegment*> > {U} 
      vector<pair<int,RepositorySegment*> > m_hOptLogic;
      //## end dndb2database::UDBAddFinancialCommand::OptLogic%54861BB70092.attr

      //## Attribute: PrevColumnNumber%54861C1D00A2
      //## begin dndb2database::UDBAddFinancialCommand::PrevColumnNumber%54861C1D00A2.attr preserve=no  private: int {U} 0
      int m_iPrevColumnNumber;
      //## end dndb2database::UDBAddFinancialCommand::PrevColumnNumber%54861C1D00A2.attr

      //## Attribute: RetryCount%49170ACD0138
      //## begin dndb2database::UDBAddFinancialCommand::RetryCount%49170ACD0138.attr preserve=no  private: int {V} 0
      int m_iRetryCount;
      //## end dndb2database::UDBAddFinancialCommand::RetryCount%49170ACD0138.attr

      //## Attribute: State%4915E9D7007D
      //## begin dndb2database::UDBAddFinancialCommand::State%4915E9D7007D.attr preserve=no  private: State {V} PREPARE_SELECT_FIN_L
      State m_nState;
      //## end dndb2database::UDBAddFinancialCommand::State%4915E9D7007D.attr

      //## Attribute: TotalUpdateFinancialColumns%54861BD0002E
      //## begin dndb2database::UDBAddFinancialCommand::TotalUpdateFinancialColumns%54861BD0002E.attr preserve=no  private: int {U} 0
      int m_iTotalUpdateFinancialColumns;
      //## end dndb2database::UDBAddFinancialCommand::TotalUpdateFinancialColumns%54861BD0002E.attr

      //## Attribute: UNIQUENESS_KEY%5485C14F024A
      //## begin dndb2database::UDBAddFinancialCommand::UNIQUENESS_KEY%5485C14F024A.attr preserve=no  private: short {U} 0
      short m_siUNIQUENESS_KEY;
      //## end dndb2database::UDBAddFinancialCommand::UNIQUENESS_KEY%5485C14F024A.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::DNDB2Database_CAT::<unnamed>%4915EA8102EE
      //## Role: UDBAddFinancialCommand::<m_pMemory>%4915EA820280
      //## begin dndb2database::UDBAddFinancialCommand::<m_pMemory>%4915EA820280.role preserve=no  public: IF::Memory { -> 3RFHgN}
      IF::Memory *m_pMemory[3];
      //## end dndb2database::UDBAddFinancialCommand::<m_pMemory>%4915EA820280.role

    // Additional Implementation Declarations
      //## begin dndb2database::UDBAddFinancialCommand%4915E99F001F.implementation preserve=yes
      string m_strTSTAMP_TRANS;
      //## end dndb2database::UDBAddFinancialCommand%4915E99F001F.implementation
};

//## begin dndb2database::UDBAddFinancialCommand%4915E99F001F.postscript preserve=yes
//## end dndb2database::UDBAddFinancialCommand%4915E99F001F.postscript

} // namespace dndb2database

//## begin module%4915EB0D003E.epilog preserve=yes
//## end module%4915EB0D003E.epilog


#endif
