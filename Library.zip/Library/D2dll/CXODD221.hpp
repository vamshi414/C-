//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%365B04E10217.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%365B04E10217.cm

//## begin module%365B04E10217.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%365B04E10217.cp

//## Module: CXOSD221%365B04E10217; Package specification
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXODD221.hpp

#ifndef CXOSD221_h
#define CXOSD221_h 1

//## begin module%365B04E10217.additionalIncludes preserve=no
//## end module%365B04E10217.additionalIncludes

//## begin module%365B04E10217.includes preserve=yes
// $Date:   Jan 31 2017 16:46:46  $ $Author:   e1009510  $ $Revision:   1.10  $
//## end module%365B04E10217.includes

#ifndef CXOSDB07_h
#include "CXODDB07.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Timestamp;
class Console;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%365B04E10217.declarations preserve=no
//## end module%365B04E10217.declarations

//## begin module%365B04E10217.additionalDeclarations preserve=yes
//## end module%365B04E10217.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

//## begin dndb2database::DB2TransactionRemover%34C3A867036D.preface preserve=yes
//## end dndb2database::DB2TransactionRemover%34C3A867036D.preface

//## Class: DB2TransactionRemover%34C3A867036D
//	The DB2TransactionRemover class encapsulates the process
//	of deleting transactions from the DN short term
//	repository implemented as a DB2 database.
//## Category: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
//## Subsystem: D2DLL%3597E8A6029B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3F8AFD480213;IF::Timestamp { -> F}
//## Uses: <unnamed>%3F8AFDC00280;monitor::UseCase { -> F}
//## Uses: <unnamed>%3F8AFDD1031C;database::Database { -> F}
//## Uses: <unnamed>%3F8AFDD303C8;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3F8AFDEC034B;IF::Trace { -> F}
//## Uses: <unnamed>%3F8AFDF3008C;IF::Console { -> F}

class DllExport DB2TransactionRemover : public database::TransactionRemover  //## Inherits: <unnamed>%34C3A8C801FA
{
  //## begin dndb2database::DB2TransactionRemover%34C3A867036D.initialDeclarations preserve=yes
   enum State
   {
      START,
      EXECUTE,
      SUCCESS,
      DELETE_DEADLOCK_TIMEOUT,
      DATABASE_FAILURE,
      DATABASE_CONNECTION_ERROR,
      RESOURCE_UNAVAILABLE
   };
  //## end dndb2database::DB2TransactionRemover%34C3A867036D.initialDeclarations

  public:
    //## Constructors (generated)
      DB2TransactionRemover();

    //## Destructor (generated)
      virtual ~DB2TransactionRemover();


    //## Other Operations (specified)
      //## Operation: remove%34C3AD060396
      //	Remove the next set of transactions within the specified
      //	time range.  Return:
      //
      //	    -1 if there is a failure.
      //	    0 if there are more rows to delete.
      //	    1 if there are no more rows to delete.
      //## Semantics:
      //	1. strTimestampEnd = m_strTimestampStart + 1 minute.
      //	2. If strTimestampEnd > m_strTimestampEnd:
      //	        strTimestampEnd = m_strTimestampEnd.
      //	3. EXEC SQL DELETE
      //	        FROM Database::qualifer . m_strTableName
      //	        WHERE TSTAMP_TRANS BETWEEN m_strTimestampStart
      //	AND strTimestampEnd.
      //	4. If unsuccessful, return -1.
      //	5. m_pTimestampCursor->put(strTimestampEnd).
      //	6. m_strTimestampStart = strTimestampEnd.
      //	7. Return (strTimestampEnd == m_strTimestampEnd) ? 1 : 0.
      virtual int remove ();

      //## Operation: setTimeRange%34C3C8C60355
      //	Establish the start and end timestamps for the current
      //	remove process.
      //## Semantics:
      //	1. Call TransactionRemover::setTimeRange(pszTimestamp
      //	Start,pszTimestampEnd).
      //	2. If m_pTimestampCursor == 0:
      //	        IString strName = "REMOVE_" + m_strTableName.
      //	        m_pTimestampCursor = Database
      //	Factory::instance()->createGlobalContext(strName).
      //	3. If m_pTimestampCursor->get(strTimestamp):
      //	        m_strTimestampStart = strTimestamp.
      virtual void setTimeRange (const char* pszTimestampStart, const char* pszTimestampEnd);

    // Additional Public Declarations
      //## begin dndb2database::DB2TransactionRemover%34C3A867036D.public preserve=yes
      //## end dndb2database::DB2TransactionRemover%34C3A867036D.public

  protected:
    // Additional Protected Declarations
      //## begin dndb2database::DB2TransactionRemover%34C3A867036D.protected preserve=yes
      //## end dndb2database::DB2TransactionRemover%34C3A867036D.protected

  private:

    //## Other Operations (specified)
      //## Operation: execute%3D36C3E400FA
      DB2TransactionRemover::State execute ();

      //## Operation: prepare%3D36C3F10232
      DB2TransactionRemover::State prepare ();

    // Additional Private Declarations
      //## begin dndb2database::DB2TransactionRemover%34C3A867036D.private preserve=yes
      //## end dndb2database::DB2TransactionRemover%34C3A867036D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Minutes%3D36C34E029F
      //## begin dndb2database::DB2TransactionRemover::Minutes%3D36C34E029F.attr preserve=no  private: int {V} 
      int m_iMinutes;
      //## end dndb2database::DB2TransactionRemover::Minutes%3D36C34E029F.attr

      //## Attribute: State%3D36C34801B5
      //## begin dndb2database::DB2TransactionRemover::State%3D36C34801B5.attr preserve=no  private: State {V} 
      State m_nState;
      //## end dndb2database::DB2TransactionRemover::State%3D36C34801B5.attr

      //## Attribute: Transactions%3D36C3590128
      //## begin dndb2database::DB2TransactionRemover::Transactions%3D36C3590128.attr preserve=no  private: int {V} 
      int m_iTransactions;
      //## end dndb2database::DB2TransactionRemover::Transactions%3D36C3590128.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::DNDB2Database_CAT::<unnamed>%3D36C4DC0203
      //## Role: DB2TransactionRemover::<m_pTimestampCursor>%3D36C4DD0222
      //## begin dndb2database::DB2TransactionRemover::<m_pTimestampCursor>%3D36C4DD0222.role preserve=no  public: database::GlobalContext { -> RFHgN}
      database::GlobalContext *m_pTimestampCursor;
      //## end dndb2database::DB2TransactionRemover::<m_pTimestampCursor>%3D36C4DD0222.role

    // Additional Implementation Declarations
      //## begin dndb2database::DB2TransactionRemover%34C3A867036D.implementation preserve=yes
      //## end dndb2database::DB2TransactionRemover%34C3A867036D.implementation

};

//## begin dndb2database::DB2TransactionRemover%34C3A867036D.postscript preserve=yes
//## end dndb2database::DB2TransactionRemover%34C3A867036D.postscript

} // namespace dndb2database

//## begin module%365B04E10217.epilog preserve=yes
using namespace dndb2database;
//## end module%365B04E10217.epilog


#endif
