static char sqla_program_id[292] = 
{
 '\xac','\x0','\x41','\x45','\x41','\x56','\x41','\x49','\x47','\x41','\x44','\x34','\x52','\x48','\x49','\x6f','\x30','\x31','\x31','\x31',
 '\x31','\x20','\x32','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x8','\x0','\x44','\x4e','\x53','\x45','\x52','\x56',
 '\x45','\x52','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x8','\x0','\x43','\x58','\x4f','\x53','\x44','\x32','\x32','\x31','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0'
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {'C',' ',' ',' '}};


static const short sqlIsLiteral   = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "CXOSD221.sqx"
//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%365B04E3001B.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%365B04E3001B.cm

//## begin module%365B04E3001B.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%365B04E3001B.cp

//## Module: CXOSD221%365B04E3001B; Package body
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXOSD221.sqx

//## begin module%365B04E3001B.additionalIncludes preserve=no
//## end module%365B04E3001B.additionalIncludes

//## begin module%365B04E3001B.includes preserve=yes
// $Date:   Feb 17 2009 19:17:14  $ $Author:   D02405  $ $Revision:   1.34  $
//## end module%365B04E3001B.includes

#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSD221_h
#include "CXODD221.hpp"
#endif


//## begin module%365B04E3001B.declarations preserve=no
//## end module%365B04E3001B.declarations

//## begin module%365B04E3001B.additionalDeclarations preserve=yes
#ifdef MVS

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
struct sqlca sqlca;


#line 58 "CXOSD221.sqx"

#else
#include "sqlca.h"
extern struct sqlca sqlca;
#endif


/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 64 "CXOSD221.sqx"

   char TR_TSTAMP_TRANS[17];
   short TR_INDICATOR;
   struct
   {
      short length;
      char data[512];
   } SQL_STMT;

/*
EXEC SQL END DECLARE SECTION;
*/

#line 72 "CXOSD221.sqx"

//## end module%365B04E3001B.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

// Class dndb2database::DB2TransactionRemover

DB2TransactionRemover::DB2TransactionRemover()
  //## begin DB2TransactionRemover::DB2TransactionRemover%34C3A867036D_const.hasinit preserve=no
  //## end DB2TransactionRemover::DB2TransactionRemover%34C3A867036D_const.hasinit
  //## begin DB2TransactionRemover::DB2TransactionRemover%34C3A867036D_const.initialization preserve=yes
  //## end DB2TransactionRemover::DB2TransactionRemover%34C3A867036D_const.initialization
{
  //## begin dndb2database::DB2TransactionRemover::DB2TransactionRemover%34C3A867036D_const.body preserve=yes
   memcpy(m_sID,"D221",4);
   m_iMinutes = 1;
   m_iTransactions = 2000;
   m_pTimestampCursor = new GlobalContext("##DELETED");
  //## end dndb2database::DB2TransactionRemover::DB2TransactionRemover%34C3A867036D_const.body
}


DB2TransactionRemover::~DB2TransactionRemover()
{
  //## begin dndb2database::DB2TransactionRemover::~DB2TransactionRemover%34C3A867036D_dest.body preserve=yes
   delete m_pTimestampCursor;
  //## end dndb2database::DB2TransactionRemover::~DB2TransactionRemover%34C3A867036D_dest.body
}



//## Other Operations (implementation)
DB2TransactionRemover::State DB2TransactionRemover::execute ()
{
  //## begin dndb2database::DB2TransactionRemover::execute%3D36C3E400FA.body preserve=yes
   
/*
EXEC SQL EXECUTE DD1;
*/

{
#line 111 "CXOSD221.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 111 "CXOSD221.sqx"
  sqlacall((unsigned short)24,1,0,0,0L);
#line 111 "CXOSD221.sqx"
  sqlastop(0L);
}

#line 111 "CXOSD221.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         m_iTransactions = sqlca.sqlerrd[2];
         UseCase::addItem(m_iTransactions);
      case 100:
         return DB2TransactionRemover::SUCCESS;
      case -904:
         return DB2TransactionRemover::RESOURCE_UNAVAILABLE;
      case -911:
      case -913:
         return DB2TransactionRemover::DELETE_DEADLOCK_TIMEOUT;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         return DB2TransactionRemover::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca,m_sID,"DELETE");
         if (sqlca.sqlcode > 0)
           return DB2TransactionRemover::SUCCESS;
   }
   return DB2TransactionRemover::DATABASE_FAILURE;
  //## end dndb2database::DB2TransactionRemover::execute%3D36C3E400FA.body
}

DB2TransactionRemover::State DB2TransactionRemover::prepare ()
{
  //## begin dndb2database::DB2TransactionRemover::prepare%3D36C3F10232.body preserve=yes
   
/*
EXEC SQL PREPARE DD1 FROM :SQL_STMT;
*/

{
#line 143 "CXOSD221.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 143 "CXOSD221.sqx"
  sqlastls( *(unsigned short *)&SQL_STMT,(const char*)&SQL_STMT+2,0L);
#line 143 "CXOSD221.sqx"
  sqlacall((unsigned short)27,1,0,0,0L);
#line 143 "CXOSD221.sqx"
  sqlastop(0L);
}

#line 143 "CXOSD221.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         return DB2TransactionRemover::EXECUTE;
      case -911:
      case -913:
         return DB2TransactionRemover::DELETE_DEADLOCK_TIMEOUT;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         return DB2TransactionRemover::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca,m_sID,"PREPARE");
         if (sqlca.sqlcode > 0)
           return DB2TransactionRemover::EXECUTE;
   }
   UseCase::add("PREPARE");
   return DB2TransactionRemover::DATABASE_FAILURE;
  //## end dndb2database::DB2TransactionRemover::prepare%3D36C3F10232.body
}

int DB2TransactionRemover::remove ()
{
  //## begin dndb2database::DB2TransactionRemover::remove%34C3AD060396.body preserve=yes
   if (Database::instance()->getDormant())
      Database::instance()->connect();
   IString strTimestampEnd(m_strTimestampStart);
   if (UseCase::getInterval() > 30000)
   {
      // target less than 30 seconds elapsed time per DELETE
      m_iMinutes = (int)((double)(30000 / (double)UseCase::getInterval()) * (double)m_iMinutes);
   }
   else
   {
      // target 2000 rows per DELETE if under 30 seconds
      if (m_iTransactions == 0)
         m_iMinutes = 60;
      else
         m_iMinutes = (int)((double)(2000 / (double)m_iTransactions) * (double)m_iMinutes);
   }
   if (m_iMinutes < 1)
      m_iMinutes = 1;
   else
   if (m_iMinutes > 60)
      m_iMinutes = 60;
   m_iTransactions = 0;
   string strDate(strTimestampEnd.data(),8);
   strDate += "000";
   string strTime(strTimestampEnd.data() + 8,6);
   Timestamp::adjustGMT(strDate,strTime,m_iMinutes);
   strTimestampEnd = strDate.substr(0,8).c_str();
   strTimestampEnd += strTime.c_str();
   strTimestampEnd += m_strTimestampEnd.subString(15,2);
   if (strTimestampEnd > m_strTimestampEnd)
      strTimestampEnd = m_strTimestampEnd;
   IString strDelete("DELETE FROM ");
   strDelete += Database::instance()->qualifier().c_str();
   strDelete += ".";
   strDelete += m_strTableName;
   strDelete += " WHERE TSTAMP_TRANS BETWEEN '";
   strDelete += m_strTimestampStart;
   strDelete += "' AND '";
   strDelete += strTimestampEnd;
   strDelete += "' AND UNIQUENESS_KEY > -1";
   SQL_STMT.length = strDelete.length();
   memcpy(SQL_STMT.data,(void*)(const char*)strDelete,strDelete.size());
   Trace::put(strDelete,strDelete.length());
   m_nState = DB2TransactionRemover::START;
   int iRetry = 0;
   while (iRetry < 5)
   {
      switch (m_nState)
      {
         case DB2TransactionRemover::START:
            m_nState = prepare();
            break;
         case DB2TransactionRemover::EXECUTE:
            m_nState = execute();
            break;
         case DB2TransactionRemover::SUCCESS:
            Database::instance()->commit();
            m_pTimestampCursor->put(strTimestampEnd,m_cType);
            if (strncmp(strTimestampEnd.subString(9,2),m_strTimestampStart.subString(9,2),2) != 0)
            {
              string strConsoleText(&m_cType,1);
              strConsoleText += " THROUGH TIMESTAMP: ";
              strConsoleText += strTimestampEnd;
              Console::display("ST114",strConsoleText.c_str());
              // ST114 - "DELETED TYPE: @ THROUGH TIMESTAMP: @@@@@@@@@@@@@@"
            }
            m_strTimestampStart = strTimestampEnd;
            Database::instance()->commit();
            return (strTimestampEnd == m_strTimestampEnd) ? 1 : 0;
         case DB2TransactionRemover::DELETE_DEADLOCK_TIMEOUT:
            UseCase::add("DEADLOCK");
            Database::instance()->rollback();
            iRetry++;
            m_nState = DB2TransactionRemover::START;
            break;
         case DB2TransactionRemover::RESOURCE_UNAVAILABLE:
            UseCase::add("RESOURCE");
            Database::instance()->rollback();
            return -1;
         case DB2TransactionRemover::DATABASE_FAILURE:
            UseCase::add("DBERROR");
            Database::instance()->rollback();
            return -1;
         case DB2TransactionRemover::DATABASE_CONNECTION_ERROR:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            return -2;
      }
   }
   return -1;
  //## end dndb2database::DB2TransactionRemover::remove%34C3AD060396.body
}

void DB2TransactionRemover::setTimeRange (const char* pszTimestampStart, const char* pszTimestampEnd)
{
  //## begin dndb2database::DB2TransactionRemover::setTimeRange%34C3C8C60355.body preserve=yes
   m_strTimestampStart = pszTimestampStart;
   m_strTimestampEnd = pszTimestampEnd;
   string strTimestamp;
   if (m_pTimestampCursor->get(strTimestamp,m_cType))
      if (strTimestamp.length() > 0)
         m_strTimestampStart = strTimestamp.substr(0,16).c_str();
  //## end dndb2database::DB2TransactionRemover::setTimeRange%34C3C8C60355.body
}

// Additional Declarations
  //## begin dndb2database::DB2TransactionRemover%34C3A867036D.declarations preserve=yes
  //## end dndb2database::DB2TransactionRemover%34C3A867036D.declarations

} // namespace dndb2database

//## begin module%365B04E3001B.epilog preserve=yes
//## end module%365B04E3001B.epilog
