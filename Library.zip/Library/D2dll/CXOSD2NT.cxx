static char sqla_program_id[292] = 
{
 '\xac','\x0','\x41','\x45','\x41','\x56','\x41','\x49','\x6c','\x41','\x61','\x35','\x52','\x48','\x49','\x6f','\x30','\x31','\x31','\x31',
 '\x31','\x20','\x32','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x8','\x0','\x44','\x4e','\x53','\x45','\x52','\x56',
 '\x45','\x52','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x8','\x0','\x43','\x58','\x4f','\x53','\x44','\x32','\x4e','\x54','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0'
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {'C',' ',' ',' '}};


static const short sqlIsLiteral   = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "CXOSD2NT.sqx"
//  Copyright (c) 1998 - 2009
//  Fidelity National Information Services
// $Date:   Feb 27 2007 08:47:40  $ $Author:   D08048  $ $Revision:   1.0  $

#include "CXODD206.hpp"
#include "CXODDB01.hpp"
#include "sqlca.h"
extern struct sqlca sqlca;


/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 10 "CXOSD2NT.sqx"

   short  FXN_INDEX_NUMBER;
   char FXN_INDNAME[129];
   char FXN_TABNAME[12] = "FIN_L200901";
   char FXN_TABSCHEMA[129];

/*
EXEC SQL END DECLARE SECTION;
*/

#line 15 "CXOSD2NT.sqx"


namespace dndb2database {
bool UDBAddFinancialCommand::checkForBusinessDuplicate(const char* pszTSTAMP_TRANS)
{
   string strSqlerrmc((char*)sqlca.sqlerrmc,sqlca.sqlerrml);
   strSqlerrmc.resize(strSqlerrmc.find_first_of(-1));
   FXN_INDEX_NUMBER = atoi(strSqlerrmc.c_str());
   memset(FXN_INDNAME,0x00,sizeof(FXN_INDNAME));
   memcpy(FXN_TABNAME + 5,pszTSTAMP_TRANS,6);
   memcpy(FXN_TABSCHEMA,Database::instance()->qualifier().data(),Database::instance()->qualifier().length());

   
/*
EXEC SQL
      SELECT
         INDNAME
      INTO
         :FXN_INDNAME
      FROM SYSCAT.INDEXES
      WHERE IID = :FXN_INDEX_NUMBER
        AND TABSCHEMA = :FXN_TABSCHEMA
        AND TABNAME = :FXN_TABNAME;
*/

{
#line 35 "CXOSD2NT.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 35 "CXOSD2NT.sqx"
  sqlaaloc(2,3,1,0L);
    {
      struct sqla_setdata_list sql_setdlist[3];
#line 35 "CXOSD2NT.sqx"
      sql_setdlist[0].sqltype = 500; sql_setdlist[0].sqllen = 2;
#line 35 "CXOSD2NT.sqx"
      sql_setdlist[0].sqldata = (void*)&FXN_INDEX_NUMBER;
#line 35 "CXOSD2NT.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 35 "CXOSD2NT.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 129;
#line 35 "CXOSD2NT.sqx"
      sql_setdlist[1].sqldata = (void*)FXN_TABSCHEMA;
#line 35 "CXOSD2NT.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 35 "CXOSD2NT.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 12;
#line 35 "CXOSD2NT.sqx"
      sql_setdlist[2].sqldata = (void*)FXN_TABNAME;
#line 35 "CXOSD2NT.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 35 "CXOSD2NT.sqx"
      sqlasetdata(2,0,3,sql_setdlist,0L,0L);
    }
#line 35 "CXOSD2NT.sqx"
  sqlaaloc(3,1,2,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 35 "CXOSD2NT.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 129;
#line 35 "CXOSD2NT.sqx"
      sql_setdlist[0].sqldata = (void*)FXN_INDNAME;
#line 35 "CXOSD2NT.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 35 "CXOSD2NT.sqx"
      sqlasetdata(3,0,1,sql_setdlist,0L,0L);
    }
#line 35 "CXOSD2NT.sqx"
  sqlacall((unsigned short)24,1,2,3,0L);
#line 35 "CXOSD2NT.sqx"
  sqlastop(0L);
}

#line 35 "CXOSD2NT.sqx"

   if (sqlca.sqlcode == 0)
   {
      if (!memcmp(FXN_INDNAME,"X0",2))
         return false;
      else
         return true;
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,"select");
   return false;
}
}
