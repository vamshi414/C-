//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%405A25B200FA.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%405A25B200FA.cm

//## begin module%405A25B200FA.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%405A25B200FA.cp

//## Module: CXOSD205%405A25B200FA; Package body
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXOSD205.cpp

//## begin module%405A25B200FA.additionalIncludes preserve=no
//## end module%405A25B200FA.additionalIncludes

//## begin module%405A25B200FA.includes preserve=yes
// $Date:   Jun 04 2020 14:54:02  $ $Author:   e1009510  $ $Revision:   1.7  $
//## end module%405A25B200FA.includes

#ifndef CXOSIF44_h
#include "CXODIF44.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSD205_h
#include "CXODD205.hpp"
#endif


//## begin module%405A25B200FA.declarations preserve=no
//## end module%405A25B200FA.declarations

//## begin module%405A25B200FA.additionalDeclarations preserve=yes
//## end module%405A25B200FA.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

// Class dndb2database::DB2MaintenanceProcedure 

DB2MaintenanceProcedure::DB2MaintenanceProcedure()
  //## begin DB2MaintenanceProcedure::DB2MaintenanceProcedure%405A1E2D03D8_const.hasinit preserve=no
      : m_lFreePages(0),
        m_lTotalPages(0),
        m_lUsedPages(0)
  //## end DB2MaintenanceProcedure::DB2MaintenanceProcedure%405A1E2D03D8_const.hasinit
  //## begin DB2MaintenanceProcedure::DB2MaintenanceProcedure%405A1E2D03D8_const.initialization preserve=yes
  //## end DB2MaintenanceProcedure::DB2MaintenanceProcedure%405A1E2D03D8_const.initialization
{
  //## begin dndb2database::DB2MaintenanceProcedure::DB2MaintenanceProcedure%405A1E2D03D8_const.body preserve=yes
   memcpy(m_sID,"D205",4);
  //## end dndb2database::DB2MaintenanceProcedure::DB2MaintenanceProcedure%405A1E2D03D8_const.body
}


DB2MaintenanceProcedure::~DB2MaintenanceProcedure()
{
  //## begin dndb2database::DB2MaintenanceProcedure::~DB2MaintenanceProcedure%405A1E2D03D8_dest.body preserve=yes
  //## end dndb2database::DB2MaintenanceProcedure::~DB2MaintenanceProcedure%405A1E2D03D8_dest.body
}



//## Other Operations (implementation)
void DB2MaintenanceProcedure::review (const char* pszText)
{
  //## begin dndb2database::DB2MaintenanceProcedure::review%405A1E900119.body preserve=yes
   if (m_strMember != "CXOXDB00")
      return;
   string strValue;
   const char* p = strstr(pszText," = ");
   if (p)
      strValue.assign(p + 3);
   if (memcmp(pszText," Name ",6) == 0
      || memcmp(pszText," Nombre ",8) == 0)
      m_strName = strValue;
   else
   if (memcmp(pszText," Total pages ",13) == 0
      || memcmp(pszText," P�ginas totales ",17) == 0)
      m_lTotalPages = atoi(strValue.c_str());
   else
   if (memcmp(pszText," Used pages ",12) == 0
      || memcmp(pszText," P�ginas utilizadas ",20) == 0)
      m_lUsedPages = atoi(strValue.c_str());
   else
   if (memcmp(pszText," Free pages ",12) == 0
      || memcmp(pszText," P�ginas libres ",16) == 0)
      if (strValue == "0")
         m_lFreePages = 1;
      else
         m_lFreePages = atoi(strValue.c_str());
   else
   if (memcmp(pszText," Page size ",11) == 0
      || memcmp(pszText," Tama�o p�gina ",15) == 0)
   {
      int lPageSize = atoi(strValue.c_str());
      if (m_lFreePages > 0) // i.e. not Not Applicable
      {
         int lTargetPercentFree = 20;
         size_t pYear = m_strName.find("20");
         if (pYear != string::npos)
         {
            char szTemp[7] = {"      "};
            memcpy(szTemp,m_strName.data() + pYear,6);
            int iMonth = atoi(szTemp + 4);
            szTemp[4] = '\0';
            int iYear = atoi(szTemp);
            Date hDate(Date::today());
            if (hDate.getYear() != iYear)
               return;
            if (hDate.getMonth() != iMonth)
               return;
            int iDay = hDate.getDay();
            int iDays = Date::daysInMonth(hDate.getYear(),hDate.getMonth());
            int iDaysRemaining = (iDays - iDay) + 1;
            if (iDaysRemaining < 5)
               lTargetPercentFree = iDaysRemaining * 4;
         }
         int lTargetFreePages = (m_lTotalPages * lTargetPercentFree) / 100;
         if (m_lFreePages < lTargetFreePages)
         {
            int lNeedPages = lTargetFreePages - m_lFreePages;
            int lAlter = (lNeedPages * lPageSize) / 1024000;
            if (lAlter < 1)
               lAlter = 1;
            char szTemp[16];
            snprintf(szTemp,sizeof(szTemp),"%d",lAlter);
            //Job::submit("CXOXDB01","&TS     ",m_strName.c_str(),"&ALTER ",szTemp);
            string strTS("TS");
            SiteSpecification::instance()->add(strTS,m_strName);
            string strALTER("ALTER");
            string strValue(szTemp);
            SiteSpecification::instance()->add(strALTER,strValue);
            DB2MaintenanceProcedure hMaintenanceProcedure;
            hMaintenanceProcedure.execute("CXOXDB01");
         }
      }
   }
  //## end dndb2database::DB2MaintenanceProcedure::review%405A1E900119.body
}

// Additional Declarations
  //## begin dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.declarations preserve=yes
  //## end dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.declarations

} // namespace dndb2database

//## begin module%405A25B200FA.epilog preserve=yes
//## end module%405A25B200FA.epilog
