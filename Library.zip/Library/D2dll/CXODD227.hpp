//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%365B069D02C0.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%365B069D02C0.cm

//## begin module%365B069D02C0.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%365B069D02C0.cp

//## Module: CXOSD227%365B069D02C0; Package specification
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXODD227.hpp

#ifndef CXOSD227_h
#define CXOSD227_h 1

//## begin module%365B069D02C0.additionalIncludes preserve=no
//## end module%365B069D02C0.additionalIncludes

//## begin module%365B069D02C0.includes preserve=yes
// $Date:   Apr 09 2004 06:20:58  $ $Author:   D02405  $ $Revision:   1.19  $
//## end module%365B069D02C0.includes

#ifndef CXOSAR05_h
#include "CXODAR05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class CriticalSection;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%365B069D02C0.declarations preserve=no
//## end module%365B069D02C0.declarations

//## begin module%365B069D02C0.additionalDeclarations preserve=yes
//## end module%365B069D02C0.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

//## begin dndb2database::DB2Locator%3505AB93031B.preface preserve=yes
//## end dndb2database::DB2Locator%3505AB93031B.preface

//## Class: DB2Locator%3505AB93031B
//	The DB2Locator class represents a data repository
//	locator table on DB2.
//## Category: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
//## Subsystem: D2DLL%3597E8A6029B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%366C52590280;database::Database { -> F}
//## Uses: <unnamed>%366C52CD004C;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3E42CEF80251;reusable::Query { -> F}
//## Uses: <unnamed>%3E42CF03034B;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%3E42D06301D4;reusable::CriticalSection { -> F}

class DllExport DB2Locator : public archive::Locator  //## Inherits: <unnamed>%3505AF080378
{
  //## begin dndb2database::DB2Locator%3505AB93031B.initialDeclarations preserve=yes
  //## end dndb2database::DB2Locator%3505AB93031B.initialDeclarations

  public:
    //## Constructors (generated)
      DB2Locator();

    //## Destructor (generated)
      virtual ~DB2Locator();


    //## Other Operations (specified)
      //## Operation: synchronize%366C477E0176
      virtual bool synchronize ();

    // Additional Public Declarations
      //## begin dndb2database::DB2Locator%3505AB93031B.public preserve=yes
      //## end dndb2database::DB2Locator%3505AB93031B.public

  protected:
    // Additional Protected Declarations
      //## begin dndb2database::DB2Locator%3505AB93031B.protected preserve=yes
      //## end dndb2database::DB2Locator%3505AB93031B.protected

  private:
    // Additional Private Declarations
      //## begin dndb2database::DB2Locator%3505AB93031B.private preserve=yes
      //## end dndb2database::DB2Locator%3505AB93031B.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dndb2database::DB2Locator%3505AB93031B.implementation preserve=yes
      //## end dndb2database::DB2Locator%3505AB93031B.implementation

};

//## begin dndb2database::DB2Locator%3505AB93031B.postscript preserve=yes
//## end dndb2database::DB2Locator%3505AB93031B.postscript

} // namespace dndb2database

//## begin module%365B069D02C0.epilog preserve=yes
using namespace dndb2database;
//## end module%365B069D02C0.epilog


#endif
