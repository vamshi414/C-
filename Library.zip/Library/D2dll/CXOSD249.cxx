static char sqla_program_id[292] = 
{
 '\xac','\x0','\x41','\x45','\x41','\x56','\x41','\x49','\x67','\x42','\x50','\x35','\x52','\x48','\x49','\x6f','\x30','\x31','\x31','\x31',
 '\x31','\x20','\x32','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x8','\x0','\x44','\x4e','\x53','\x45','\x52','\x56',
 '\x45','\x52','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x8','\x0','\x43','\x58','\x4f','\x53','\x44','\x32','\x34','\x39','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0'
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {'C',' ',' ',' '}};


static const short sqlIsLiteral   = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "CXOSD249.sqx"
//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6146FF92028A.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%6146FF92028A.cm

//## begin module%6146FF92028A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%6146FF92028A.cp

//## Module: CXOSD249%6146FF92028A; Package body
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: D:\Devel\V03.2A.R003\Dn\Server\Library\D2dll\CXOSD249.sqx

//## begin module%6146FF92028A.additionalIncludes preserve=no
//## end module%6146FF92028A.additionalIncludes

//## begin module%6146FF92028A.includes preserve=yes
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
//## end module%6146FF92028A.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
#ifndef CXOSCFB7_h
#include "CXODCFB7.hpp"
#endif
#ifndef CXOSRU48_h
#include "CXODRU48.hpp"
#endif
#ifndef CXOSD249_h
#include "CXODD249.hpp"
#endif


//## begin module%6146FF92028A.declarations preserve=no
//## end module%6146FF92028A.declarations

//## begin module%6146FF92028A.additionalDeclarations preserve=yes
#ifdef MVS

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
struct sqlca sqlca;


#line 55 "CXOSD249.sqx"

#else
#include "sqlca.h"
extern struct sqlca sqlca;
#endif

/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 60 "CXOSD249.sqx"

       char QMR_CARDHOLDER_ATTRIBUTES[32];
       char QMR_CARDHOLDER_PAN[512][29];
       char QMR_CARDHOLDER_INST_ID[512][12];
       char QMR_CARDHOLDER_NETWORK_ID[512][4];
       char QMR_CARDHOLDER_YEAR_MONTH[512][7];
       char QMR_CARDHOLDER_BIN[512][12];
       sqlint32  QMR_CARDHOLDER_ROWS;
       struct
       {
          short length;
          char data[2048];
       } QMR_CARDHOLDER_MERGE;

/*
EXEC SQL END DECLARE SECTION;
*/

#line 73 "CXOSD249.sqx"

//## end module%6146FF92028A.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

// Class dndb2database::DB2MonthlyCardHolder 

DB2MonthlyCardHolder::DB2MonthlyCardHolder()
  //## begin DB2MonthlyCardHolder::DB2MonthlyCardHolder%6146FE9800AE_const.hasinit preserve=no
  //## end DB2MonthlyCardHolder::DB2MonthlyCardHolder%6146FE9800AE_const.hasinit
  //## begin DB2MonthlyCardHolder::DB2MonthlyCardHolder%6146FE9800AE_const.initialization preserve=yes
  //## end DB2MonthlyCardHolder::DB2MonthlyCardHolder%6146FE9800AE_const.initialization
{
  //## begin dndb2database::DB2MonthlyCardHolder::DB2MonthlyCardHolder%6146FE9800AE_const.body preserve=yes
   memcpy(m_sID,"D249",4);
#ifdef MVS
   strcpy(QMR_CARDHOLDER_ATTRIBUTES,"FOR MULTIPLE ROWS");
#endif
   string strQualifier(Database::instance()->qualifier());
   QMR_CARDHOLDER_ROWS = 0;
   memcpy(QMR_CARDHOLDER_MERGE.data,"MERGE INTO ",11);
   memcpy(QMR_CARDHOLDER_MERGE.data + 11,strQualifier.data(),strQualifier.length());
   strcpy(QMR_CARDHOLDER_MERGE.data + 11 + strQualifier.length(),".T_QMR_CARDHOLDER AS A USING"
   " ( VALUES (?,?,?,?,?) "
#ifdef MVS
      " FOR ? ROWS"
#endif
      ") AS B "
    " (PAN,INST_ID,NETWORK_ID,YEAR_MONTH,BIN) ON "
    " A.PAN = B.PAN AND A.INST_ID = B.INST_ID "
    " AND A.NETWORK_ID = B.NETWORK_ID"
    " AND A.YEAR_MONTH = B.YEAR_MONTH"
    " AND A.BIN = B.BIN"
    " WHEN NOT MATCHED THEN INSERT "
    " (PAN,INST_ID,NETWORK_ID,YEAR_MONTH,BIN) VALUES "
    " (B.PAN,B.INST_ID,B.NETWORK_ID,B.YEAR_MONTH,B.BIN)"
#ifdef MVS
      " NOT ATOMIC CONTINUE ON SQLEXCEPTION"
#endif
   );
   QMR_CARDHOLDER_MERGE.length = strlen(QMR_CARDHOLDER_MERGE.data);
  //## end dndb2database::DB2MonthlyCardHolder::DB2MonthlyCardHolder%6146FE9800AE_const.body
}


DB2MonthlyCardHolder::~DB2MonthlyCardHolder()
{
  //## begin dndb2database::DB2MonthlyCardHolder::~DB2MonthlyCardHolder%6146FE9800AE_dest.body preserve=yes
  //## end dndb2database::DB2MonthlyCardHolder::~DB2MonthlyCardHolder%6146FE9800AE_dest.body
}



//## Other Operations (implementation)
bool DB2MonthlyCardHolder::add (const settlement::FinancialTransaction& hFinancialTransaction)
{
  //## begin dndb2database::DB2MonthlyCardHolder::add%614702EB007E.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return false;
   if (hFinancialTransaction.getTRAN_DISPOSITION() == "2")
      return true;
   if (QMR_CARDHOLDER_ROWS >= 512)
      if (!commit())
         return false;
   int iBIN_LENGTH;
   string strNETWORK_ID;
   string strBIN(hFinancialTransaction.getPAN().c_str(), 11);
   if (QMRInstitution::getBinDetails(hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN)
      , strBIN, iBIN_LENGTH, strNETWORK_ID) == false)
      return true;
   strBIN.resize(iBIN_LENGTH);
   char szSpace[2] = {" "};
   string strPAN(hFinancialTransaction.getPAN());
   NPI::instance(2)->protect(strPAN);
   if(hFinancialTransaction.getTSTAMP_TRANS().length() < sizeof(QMR_CARDHOLDER_YEAR_MONTH[QMR_CARDHOLDER_ROWS]))
   {
      memcpy(QMR_CARDHOLDER_YEAR_MONTH[QMR_CARDHOLDER_ROWS],hFinancialTransaction.getTSTAMP_TRANS().data(),6);
      QMR_CARDHOLDER_YEAR_MONTH[QMR_CARDHOLDER_ROWS][6] = '\0';
   }
   if(strPAN.length() < sizeof(QMR_CARDHOLDER_PAN[QMR_CARDHOLDER_ROWS]))
   {
      memcpy(QMR_CARDHOLDER_PAN[QMR_CARDHOLDER_ROWS] ,strPAN.data(),strPAN.length());
      QMR_CARDHOLDER_PAN[QMR_CARDHOLDER_ROWS][strPAN.length()] = '\0';
   }
   if(hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).length() < sizeof(QMR_CARDHOLDER_INST_ID[QMR_CARDHOLDER_ROWS]))
   {
       memcpy(QMR_CARDHOLDER_INST_ID[QMR_CARDHOLDER_ROWS] ,hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).data(),
              hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).length());
      QMR_CARDHOLDER_INST_ID[QMR_CARDHOLDER_ROWS][hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).length()] = '\0';
   }
   if(!hFinancialTransaction.getNET_ID_ACQ().empty())
   {
      memcpy(QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS] ,hFinancialTransaction.getNET_ID_ACQ().data(),
              hFinancialTransaction.getNET_ID_ACQ().length());
      QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS][hFinancialTransaction.getNET_ID_ACQ().length()] = '\0';
   }
   else if (!strNETWORK_ID.empty())
   {
      memcpy(QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS], strNETWORK_ID.data(),strNETWORK_ID.length());
      QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS][strNETWORK_ID.length()] = '\0';
   }
   else
      memcpy(QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS],szSpace,2);
   if(strBIN.length() < sizeof(QMR_CARDHOLDER_BIN[QMR_CARDHOLDER_ROWS]))
   {
      memcpy(QMR_CARDHOLDER_BIN[QMR_CARDHOLDER_ROWS] ,strBIN.data(),
             strBIN.length());
      QMR_CARDHOLDER_BIN[QMR_CARDHOLDER_ROWS][strBIN.length()] = '\0';
   }
   QMR_CARDHOLDER_ROWS++;
   return true;
  //## end dndb2database::DB2MonthlyCardHolder::add%614702EB007E.body
}

bool DB2MonthlyCardHolder::commit ()
{
  //## begin dndb2database::DB2MonthlyCardHolder::commit%6147031901C7.body preserve=yes
     UseCase hUseCase("TOTALS","## D249 COMMIT CARD");
   bool b = true;
   if (QMR_CARDHOLDER_ROWS > 0)
   {
#ifdef MVS
      XXEC SQL PREPARE MERGE1
         ATTRIBUTES :QMR_CARDHOLDER_ATTRIBUTES
         FROM :QMR_CARDHOLDER_MERGE;
#else
      
/*
EXEC SQL PREPARE MERGE1 FROM :QMR_CARDHOLDER_MERGE;
*/

{
#line 203 "CXOSD249.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 203 "CXOSD249.sqx"
  sqlastls( *(unsigned short *)&QMR_CARDHOLDER_MERGE,(const char*)&QMR_CARDHOLDER_MERGE+2,0L);
#line 203 "CXOSD249.sqx"
  sqlacall((unsigned short)27,1,0,0,0L);
#line 203 "CXOSD249.sqx"
  sqlastop(0L);
}

#line 203 "CXOSD249.sqx"

#endif
      switch (sqlca.sqlcode)
      {
         case 0:
            break;
         case -911:
         case -913:
            UseCase::add("DEADLOCK");
            b = false;
            break;
         case -900:
         case -923:
         case -924:
         case -991:
         case -1024:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            b = false;
            break;
         default:
            if (sqlca.sqlcode > 0)
               Database::instance()->traceSQLError((void*)&sqlca,m_sID,"PREPARE");
            else
            {
               UseCase::add("DBERROR");
               b = false;
            }
      }
      if (!b)
      {
         QMR_CARDHOLDER_ROWS = 0;
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"PREPARE");
         return UseCase::setSuccess(false);
      }
#ifdef MVS
      XXEC SQL
         EXECUTE MERGE1
            USING
              :QMR_CARDHOLDER_PAN,
              :QMR_CARDHOLDER_INST_ID,
              :QMR_CARDHOLDER_NETWORK_ID,
              :QMR_CARDHOLDER_YEAR_MONTH,
              :QMR_CARDHOLDER_BIN,
              :QMR_CARDHOLDER_ROWS;
#else
      
/*
EXEC SQL
         EXECUTE MERGE1
            USING
              :QMR_CARDHOLDER_PAN,
              :QMR_CARDHOLDER_INST_ID,
              :QMR_CARDHOLDER_NETWORK_ID,
              :QMR_CARDHOLDER_YEAR_MONTH,
              :QMR_CARDHOLDER_BIN
            FOR :QMR_CARDHOLDER_ROWS ROWS;
*/

{
#line 258 "CXOSD249.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 258 "CXOSD249.sqx"
  sqlaaloc(2,5,1,0L);
    {
      struct sqla_setdata_list sql_setdlist[5];
#line 258 "CXOSD249.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 29;
#line 258 "CXOSD249.sqx"
      sql_setdlist[0].sqldata = (void*)QMR_CARDHOLDER_PAN;
#line 258 "CXOSD249.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 258 "CXOSD249.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 12;
#line 258 "CXOSD249.sqx"
      sql_setdlist[1].sqldata = (void*)QMR_CARDHOLDER_INST_ID;
#line 258 "CXOSD249.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 258 "CXOSD249.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 4;
#line 258 "CXOSD249.sqx"
      sql_setdlist[2].sqldata = (void*)QMR_CARDHOLDER_NETWORK_ID;
#line 258 "CXOSD249.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 258 "CXOSD249.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 7;
#line 258 "CXOSD249.sqx"
      sql_setdlist[3].sqldata = (void*)QMR_CARDHOLDER_YEAR_MONTH;
#line 258 "CXOSD249.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 258 "CXOSD249.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 12;
#line 258 "CXOSD249.sqx"
      sql_setdlist[4].sqldata = (void*)QMR_CARDHOLDER_BIN;
#line 258 "CXOSD249.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 258 "CXOSD249.sqx"
      sqlasetdata(2,0,5,sql_setdlist,0L,0L);
    }
#line 258 "CXOSD249.sqx"
    {
      struct sqlacall_spare_info sqla_spare_info;
      sqla_spare_info.uiVersion    = 1;
      sqla_spare_info.arrayInfo.uiArraySize  = QMR_CARDHOLDER_ROWS;
      sqla_spare_info.arrayInfo.bIsStruct    = 0;
      sqla_spare_info.arrayInfo.bIsStructInd = 0;
      sqla_spare_info.arrayInfo.uiStructSize = 0;
      sqlacall((unsigned short)24,1,2,0,&sqla_spare_info);
    }
#line 258 "CXOSD249.sqx"
  sqlastop(0L);
}

#line 258 "CXOSD249.sqx"

#endif
      switch (sqlca.sqlcode)
      {
         case 0:
            UseCase::addItem(QMR_CARDHOLDER_ROWS);
            break;
         case -911:
         case -913:
            UseCase::add("DEADLOCK");
            b = false;
            break;
         case -900:
         case -923:
         case -924:
         case -991:
         case -1024:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            b = false;
            break;
         default:
            if (sqlca.sqlcode > 0)
               Database::instance()->traceSQLError((void*)&sqlca,m_sID,"MERGE");
            else
            {
               UseCase::add("DBERROR");
               b = false;
            }
      }
      QMR_CARDHOLDER_ROWS = 0;
      char szTemp[5 * PERCENTLD + 7 * PERCENTF + 2 * PERCENTS];
      for(int i=0;i < QMR_CARDHOLDER_ROWS; i++)
      {
         snprintf(szTemp, sizeof(szTemp), "MERGE INTO  %s %s %s %s %s ",
         QMR_CARDHOLDER_PAN[i], QMR_CARDHOLDER_INST_ID[i],
         QMR_CARDHOLDER_NETWORK_ID[i], QMR_CARDHOLDER_YEAR_MONTH[i], 
         QMR_CARDHOLDER_BIN[i]);
         Trace::put(szTemp);
      }
      if (!b)
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"MERGE");
         return UseCase::setSuccess(false);
      }
   }
   return b;
  //## end dndb2database::DB2MonthlyCardHolder::commit%6147031901C7.body
}

// Additional Declarations
  //## begin dndb2database::DB2MonthlyCardHolder%6146FE9800AE.declarations preserve=yes
  //## end dndb2database::DB2MonthlyCardHolder%6146FE9800AE.declarations

} // namespace dndb2database

//## begin module%6146FF92028A.epilog preserve=yes
//## end module%6146FF92028A.epilog
