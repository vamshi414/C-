//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3A2D72800048.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3A2D72800048.cm

//## begin module%3A2D72800048.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3A2D72800048.cp

//## Module: CXOSD242%3A2D72800048; Package specification
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXODD242.hpp

#ifndef CXOSD242_h
#define CXOSD242_h 1

//## begin module%3A2D72800048.additionalIncludes preserve=no
//## end module%3A2D72800048.additionalIncludes

//## begin module%3A2D72800048.includes preserve=yes
// $Date:   Jun 30 2006 12:15:44  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%3A2D72800048.includes

#ifndef CXOSST06_h
#include "CXODST06.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class RecoveryPoint;
class EntityGroup;
class ReportingPeriod;
class TotalsCategory;
class ReportingEntity;
class Total;
} // namespace settlement

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%3A2D72800048.declarations preserve=no
//## end module%3A2D72800048.declarations

//## begin module%3A2D72800048.additionalDeclarations preserve=yes
//## end module%3A2D72800048.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

//## begin dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.preface preserve=yes
//## end dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.preface

//## Class: DB2CheckpointTotalsVisitor%3A2D711201AB
//## Category: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
//## Subsystem: D2DLL%3597E8A6029B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3A2D7B6401B4;database::Database { -> F}
//## Uses: <unnamed>%3A2D7B8002FE;monitor::UseCase { -> F}
//## Uses: <unnamed>%3A2D806D03AC;timer::Clock { -> F}
//## Uses: <unnamed>%3A2D80770017;settlement::Total { -> F}
//## Uses: <unnamed>%3A2D96A401AB;settlement::EntityGroup { -> F}
//## Uses: <unnamed>%3A2D96A603DE;settlement::RecoveryPoint { -> F}
//## Uses: <unnamed>%3A2D96A902C0;settlement::ReportingEntity { -> F}
//## Uses: <unnamed>%3A2D96AD00D1;settlement::ReportingPeriod { -> F}
//## Uses: <unnamed>%3A2D96B00085;settlement::TotalsCategory { -> F}
//## Uses: <unnamed>%3A323D9B00BB;process::Application { -> F}

class DllExport DB2CheckpointTotalsVisitor : public settlement::CheckpointTotalsVisitor  //## Inherits: <unnamed>%3A2D713703CB
{
  //## begin dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.initialDeclarations preserve=yes
  //## end dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.initialDeclarations

  public:
    //## Constructors (generated)
      DB2CheckpointTotalsVisitor();

    //## Destructor (generated)
      virtual ~DB2CheckpointTotalsVisitor();


    //## Other Operations (specified)
      //## Operation: visitAccumulator%3A2D9606030C
      //## Postconditions:
      //	<body>
      //	<title>CG
      //	<h1>TE
      //	<h2>FO
      //	<h3>Financial Totals Tables
      //	<p>
      //	The Totals Engine service stores financial totals in the
      //	following tables:
      //	<ul>
      //	<li><i>custqual</i>.T_FIN_ENTITY
      //	<li><i>custqual</i>.T_FIN_PERIOD
      //	<li><i>custqual</i>.T_FIN_ENTITY_GROUP
      //	<li><i>custqual</i>.T_FIN_E_GROUP_ITEM
      //	<li><i>custqual</i>.T_FIN_CATEGORY
      //	<li><i>custqual</i>.T_FIN_TOTAL
      //	</ul>
      //	</body>
      virtual void visitAccumulator (Accumulator* pAccumulator);

      //## Operation: visitEntityGroup%3A2D916B02F2
      virtual void visitEntityGroup (settlement::EntityGroup* pEntityGroup);

      //## Operation: visitRecoveryPoint%3A2D916E0062
      virtual void visitRecoveryPoint (settlement::RecoveryPoint* pRecoveryPoint);

      //## Operation: visitReportingEntity%3A2D917002FA
      virtual void visitReportingEntity (settlement::ReportingEntity* pReportingEntity);

      //## Operation: visitReportingPeriod%3A2D9172036B
      virtual void visitReportingPeriod (settlement::ReportingPeriod* pReportingPeriod);

      //## Operation: visitTotal%3A2D7158018D
      virtual void visitTotal (settlement::Total* pTotal);

      //## Operation: visitTotalsCategory%3A2D917402D7
      virtual void visitTotalsCategory (settlement::TotalsCategory* pTotalsCategory);

    // Additional Public Declarations
      //## begin dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.public preserve=yes
      //## end dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.public

  protected:
    // Additional Protected Declarations
      //## begin dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.protected preserve=yes
      //## end dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.protected

  private:

    //## Other Operations (specified)
      //## Operation: checkResult%3A2D761F0178
      bool checkResult ();

      //## Operation: lockTables%42273D21001F
      void lockTables ();

    // Additional Private Declarations
      //## begin dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.private preserve=yes
      //## end dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Transaction%42273CE7004E
      //## begin dndb2database::DB2CheckpointTotalsVisitor::Transaction%42273CE7004E.attr preserve=no  private: int {U} -1
      int m_lTransaction;
      //## end dndb2database::DB2CheckpointTotalsVisitor::Transaction%42273CE7004E.attr

    // Additional Implementation Declarations
      //## begin dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.implementation preserve=yes
      //## end dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.implementation

};

//## begin dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.postscript preserve=yes
//## end dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.postscript

} // namespace dndb2database

//## begin module%3A2D72800048.epilog preserve=yes
using namespace dndb2database;
//## end module%3A2D72800048.epilog


#endif
