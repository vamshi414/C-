//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E5159700203.cm preserve=no
//	$Date:   Apr 09 2020 16:43:34  $ $Author:   e1009839  $
//	$Revision:   1.44  $
//## end module%3E5159700203.cm

//## begin module%3E5159700203.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3E5159700203.cp

//## Module: CXOSD202%3E5159700203; Package specification
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\D2dll\CXODD202.hpp

#ifndef CXOSD202_h
#define CXOSD202_h 1

//## begin module%3E5159700203.additionalIncludes preserve=no
//## end module%3E5159700203.additionalIncludes

//## begin module%3E5159700203.includes preserve=yes
#include <map>
//## end module%3E5159700203.includes

#ifndef CXOSP202_h
#include "CXODP202.hpp"
#endif

//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
class DB2AggregatorMIS2;
class UDBAddFinancialCommand;
class DB2AggregatorPOSRisk;
class DB2MaintenanceProcedure;
class DB2CheckpointTotalsVisitor;
class DB2Locator;
class DB2TransactionRemover;
class DB2PartitionDeallocator;
class DB2PartitionAllocator;
} // namespace dndb2database

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%3E5159700203.declarations preserve=no
//## end module%3E5159700203.declarations

//## begin module%3E5159700203.additionalDeclarations preserve=yes
//## end module%3E5159700203.additionalDeclarations


namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

//## begin dndb2database::DNDB2DatabaseFactory%3E51579F0109.preface preserve=yes
//## end dndb2database::DNDB2DatabaseFactory%3E51579F0109.preface

//## Class: DNDB2DatabaseFactory%3E51579F0109
//	The DNDB2DatabaseFactory class provides an interface for
//	creating DN DB2 dependent objects.
//
//	It is based on the ConcreteFactory object of the Abstract
//	Factory pattern.
//## Category: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
//## Subsystem: D2DLL%3597E8A6029B
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1



//## Uses: <unnamed>%3E515DEE032C;DB2PartitionDeallocator { -> F}
//## Uses: <unnamed>%3E515DF10128;DB2Locator { -> F}
//## Uses: <unnamed>%3E515DF302EE;DB2CheckpointTotalsVisitor { -> F}
//## Uses: <unnamed>%3E515DF9000F;DB2TransactionRemover { -> F}
//## Uses: <unnamed>%3E515DFE0186;DB2PartitionAllocator { -> F}
//## Uses: <unnamed>%405AF3AC029F;DB2MaintenanceProcedure { -> F}
//## Uses: <unnamed>%40759F3C0232;DB2AggregatorPOSRisk { -> F}
//## Uses: <unnamed>%40914901003E;DB2AggregatorMIS { -> F}
//## Uses: <unnamed>%49183AC802EE;UDBAddFinancialCommand { -> F}
//## Uses: <unnamed>%49183E6D00AB;IF::Extract { -> F}
//## Uses: <unnamed>%5E8BD1660113;DB2AggregatorMIS2 { -> F}

class DllExport DNDB2DatabaseFactory : public db2database::DB2DatabaseFactory  //## Inherits: <unnamed>%3E5158CC007D
{
  //## begin dndb2database::DNDB2DatabaseFactory%3E51579F0109.initialDeclarations preserve=yes
  //## end dndb2database::DNDB2DatabaseFactory%3E51579F0109.initialDeclarations

  public:
    //## Constructors (generated)
      DNDB2DatabaseFactory();

    //## Destructor (generated)
      virtual ~DNDB2DatabaseFactory();


    //## Other Operations (specified)
      //## Operation: create%3E515B330177
      virtual Object* create (const char* pszClass, const char* pszValue = 0);

    // Additional Public Declarations
      //## begin dndb2database::DNDB2DatabaseFactory%3E51579F0109.public preserve=yes
      //## end dndb2database::DNDB2DatabaseFactory%3E51579F0109.public

  protected:
    // Additional Protected Declarations
      //## begin dndb2database::DNDB2DatabaseFactory%3E51579F0109.protected preserve=yes
      //## end dndb2database::DNDB2DatabaseFactory%3E51579F0109.protected

  private:
    // Additional Private Declarations
      //## begin dndb2database::DNDB2DatabaseFactory%3E51579F0109.private preserve=yes
      //## end dndb2database::DNDB2DatabaseFactory%3E51579F0109.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Classes%3E515B650148
      //## begin dndb2database::DNDB2DatabaseFactory::Classes%3E515B650148.attr preserve=no  private: map<string,int,less<string> > {V} 
      map<string,int,less<string> > m_hClasses;
      //## end dndb2database::DNDB2DatabaseFactory::Classes%3E515B650148.attr

    // Additional Implementation Declarations
      //## begin dndb2database::DNDB2DatabaseFactory%3E51579F0109.implementation preserve=yes
      //## end dndb2database::DNDB2DatabaseFactory%3E51579F0109.implementation

};

//## begin dndb2database::DNDB2DatabaseFactory%3E51579F0109.postscript preserve=yes
//## end dndb2database::DNDB2DatabaseFactory%3E51579F0109.postscript

} // namespace dndb2database

//## begin module%3E5159700203.epilog preserve=yes
using namespace dndb2database;
//## end module%3E5159700203.epilog


#endif
