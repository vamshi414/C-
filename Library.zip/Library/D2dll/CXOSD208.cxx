static char sqla_program_id[292] = 
{
 '\xac','\x0','\x41','\x45','\x41','\x56','\x41','\x49','\x63','\x41','\x6b','\x33','\x52','\x48','\x49','\x6f','\x30','\x31','\x31','\x31',
 '\x31','\x20','\x32','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x8','\x0','\x44','\x4e','\x53','\x45','\x52','\x56',
 '\x45','\x52','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x8','\x0','\x43','\x58','\x4f','\x53','\x44','\x32','\x30','\x38','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0'
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {'C',' ',' ',' '}};


static const short sqlIsLiteral   = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "CXOSD208.sqx"
//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%365AD1050249.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%365AD1050249.cm

//## begin module%365AD1050249.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%365AD1050249.cp

//## Module: CXOSD208%365AD1050249; Package body
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXOSD208.sqx

//## begin module%365AD1050249.additionalIncludes preserve=no
//## end module%365AD1050249.additionalIncludes

//## begin module%365AD1050249.includes preserve=yes
// $Date:   Jun 26 2015 13:57:58  $ $Author:   e1009839  $ $Revision:   1.54  $
#include "CXODRU24.hpp"
#include "CXODPS01.hpp"
//## end module%365AD1050249.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSD208_h
#include "CXODD208.hpp"
#endif


//## begin module%365AD1050249.declarations preserve=no
//## end module%365AD1050249.declarations

//## begin module%365AD1050249.additionalDeclarations preserve=yes
#ifndef MVS
#include "sqlca.h"
#endif


/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
struct sqlca sqlca;


#line 60 "CXOSD208.sqx"



/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 62 "CXOSD208.sqx"

   char PC_TABLE_NAME[19];
   short  PC_PART_NUMBER;
   char PC_PART_STATUS[2];
   char PC_TSTAMP_START[17];
   char PC_TSTAMP_END[17];
   char PC_TSTAMP_UPDATE[17];
   short  PC_PARTITIONS;
   char PC_QUALIFIER[9];
   char PC_DBNAME[9];
   short  PC_INDICATOR;
   short  PC_ACTIVE_PARTITIONS;

/*
EXEC SQL END DECLARE SECTION;
*/

#line 74 "CXOSD208.sqx"

//## end module%365AD1050249.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

// Class dndb2database::DB2PartitionAllocator

DB2PartitionAllocator::DB2PartitionAllocator()
  //## begin DB2PartitionAllocator::DB2PartitionAllocator%3463469100C7_const.hasinit preserve=no
      : m_bLastPartitionAllocated(false)
  //## end DB2PartitionAllocator::DB2PartitionAllocator%3463469100C7_const.hasinit
  //## begin DB2PartitionAllocator::DB2PartitionAllocator%3463469100C7_const.initialization preserve=yes
  //## end DB2PartitionAllocator::DB2PartitionAllocator%3463469100C7_const.initialization
{
  //## begin dndb2database::DB2PartitionAllocator::DB2PartitionAllocator%3463469100C7_const.body preserve=yes
   memcpy(m_sID,"D208",4);
  //## end dndb2database::DB2PartitionAllocator::DB2PartitionAllocator%3463469100C7_const.body
}


DB2PartitionAllocator::~DB2PartitionAllocator()
{
  //## begin dndb2database::DB2PartitionAllocator::~DB2PartitionAllocator%3463469100C7_dest.body preserve=yes
  //## end dndb2database::DB2PartitionAllocator::~DB2PartitionAllocator%3463469100C7_dest.body
}



//## Other Operations (implementation)
int DB2PartitionAllocator::allocate (const char* pszTable, const char* pszDate, short int* piKey, const char* pszPartTable)
{
  //## begin dndb2database::DB2PartitionAllocator::allocate%346B98AA01E7.body preserve=yes
   UseCase hUseCase("DR","## DR08 ALLOCATE PARTITION");
   CriticalSection hCriticalSection("CATALOG");
   if (Database::instance()->getDormant())
      Database::instance()->connect();
   *piKey = PartitionAllocator::allocate(pszTable,pszDate,piKey,pszPartTable);
   if (*piKey < 0)
   {
      if (Application::instance()->name().substr(2,2) == "LE")
         Database::instance()->commit();
      return *piKey;
   }
   *piKey = -1;
   int i = 0;
   if (Database::instance()->state() == Database::DISCONNECTED)
   {
      UseCase::add("CONNECT");
      UseCase::setSuccess(false);
      return -1;
   }
   strcpy(PC_TABLE_NAME,pszTable);
   strcpy(PC_TSTAMP_START,pszDate);
   strcpy(PC_TSTAMP_START + 8,"00000000");
   strcpy(PC_TSTAMP_END,pszDate);
   strcpy(PC_TSTAMP_END + 8,"23595999");
   m_nState = DB2PartitionAllocator::START;
   for (;;)
   {
      switch (m_nState)
      {
         case DB2PartitionAllocator::START:
            i = 0;
            m_nState = lockTable();
            break;
         case DB2PartitionAllocator::SELECT:
            m_nState = select(piKey);
            break;
         case DB2PartitionAllocator::SUCCESS:
            if (Application::instance()->name().substr(2,2) == "LE")
               Database::instance()->commit();
            return i;
         case DB2PartitionAllocator::UPDATE:
            i = 1;
            m_nState = update(piKey,pszPartTable);
            break;
         case DB2PartitionAllocator::SYNC:
            m_nState = sync(piKey,pszPartTable);
            break;
         case DB2PartitionAllocator::LOCK_DEADLOCK_TIMEOUT:
            UseCase::add("DEADLOCK");
            UseCase::setSuccess(false);
            if (Application::instance()->name().substr(2,2) == "LE")
               Database::instance()->commit();
            return -1;
         case DB2PartitionAllocator::DATABASE_FAILURE:
            UseCase::add("DBERROR");
            UseCase::setSuccess(false);
            if (Application::instance()->name().substr(2,2) == "LE")
               Database::instance()->commit();
            return -1;
         case DB2PartitionAllocator::DATABASE_CONNECTION_ERROR:
            UseCase::add("CONNECT");
            UseCase::setSuccess(false);
            Database::instance()->setState(Database::DISCONNECTED);
            return -1;
      }
   }
   if (Application::instance()->name().substr(2,2) == "LE")
      Database::instance()->commit();
   UseCase::setSuccess(false);
   return -1;
  //## end dndb2database::DB2PartitionAllocator::allocate%346B98AA01E7.body
}

DB2PartitionAllocator::State DB2PartitionAllocator::lockTable ()
{
  //## begin dndb2database::DB2PartitionAllocator::lockTable%3D36BC4D037A.body preserve=yes
   
/*
EXEC SQL
      LOCK TABLE PARTITION_CONTROL IN EXCLUSIVE MODE;
*/

{
#line 187 "CXOSD208.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 187 "CXOSD208.sqx"
  sqlacall((unsigned short)24,1,0,0,0L);
#line 187 "CXOSD208.sqx"
  sqlastop(0L);
}

#line 187 "CXOSD208.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         return DB2PartitionAllocator::SELECT;
      case -911:
      case -913:
         return DB2PartitionAllocator::LOCK_DEADLOCK_TIMEOUT;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         return DB2PartitionAllocator::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca,m_sID,"lockTable");
         if (sqlca.sqlcode > 0)
           return DB2PartitionAllocator::SELECT;
   }
   return DB2PartitionAllocator::DATABASE_FAILURE;
  //## end dndb2database::DB2PartitionAllocator::lockTable%3D36BC4D037A.body
}

DB2PartitionAllocator::State DB2PartitionAllocator::select (short int* piKey)
{
  //## begin dndb2database::DB2PartitionAllocator::select%3D36BC570167.body preserve=yes
   
/*
EXEC SQL
      SELECT
         PART_NUMBER
      INTO
         :PC_PART_NUMBER
      FROM PARTITION_CONTROL
      WHERE TSTAMP_START = :PC_TSTAMP_START
        AND TABLE_NAME = :PC_TABLE_NAME
        AND PART_STAT = 'A';
*/

{
#line 222 "CXOSD208.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 222 "CXOSD208.sqx"
  sqlaaloc(2,2,1,0L);
    {
      struct sqla_setdata_list sql_setdlist[2];
#line 222 "CXOSD208.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 17;
#line 222 "CXOSD208.sqx"
      sql_setdlist[0].sqldata = (void*)PC_TSTAMP_START;
#line 222 "CXOSD208.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 222 "CXOSD208.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 19;
#line 222 "CXOSD208.sqx"
      sql_setdlist[1].sqldata = (void*)PC_TABLE_NAME;
#line 222 "CXOSD208.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 222 "CXOSD208.sqx"
      sqlasetdata(2,0,2,sql_setdlist,0L,0L);
    }
#line 222 "CXOSD208.sqx"
  sqlaaloc(3,1,2,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 222 "CXOSD208.sqx"
      sql_setdlist[0].sqltype = 500; sql_setdlist[0].sqllen = 2;
#line 222 "CXOSD208.sqx"
      sql_setdlist[0].sqldata = (void*)&PC_PART_NUMBER;
#line 222 "CXOSD208.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 222 "CXOSD208.sqx"
      sqlasetdata(3,0,1,sql_setdlist,0L,0L);
    }
#line 222 "CXOSD208.sqx"
  sqlacall((unsigned short)24,2,2,3,0L);
#line 222 "CXOSD208.sqx"
  sqlastop(0L);
}

#line 222 "CXOSD208.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         *piKey = PC_PART_NUMBER;
         return DB2PartitionAllocator::SUCCESS;
      case 100:
         return DB2PartitionAllocator::UPDATE;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         return DB2PartitionAllocator::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca,m_sID,"select");
         if (sqlca.sqlcode > 0)
         {
           *piKey = PC_PART_NUMBER;
           return DB2PartitionAllocator::SUCCESS;
         }
   }
   return DB2PartitionAllocator::DATABASE_FAILURE;
  //## end dndb2database::DB2PartitionAllocator::select%3D36BC570167.body
}

DB2PartitionAllocator::State DB2PartitionAllocator::sync (short int* piKey, const char* pszPartTable)
{
  //## begin dndb2database::DB2PartitionAllocator::sync%3D36BC680000.body preserve=yes
   PC_PARTITIONS = 0;
   string strPartitions;
   string strMisPartitions(pszPartTable);
   if (Extract::instance()->getSpec(pszPartTable,strPartitions))
      PC_PARTITIONS = atoi(strPartitions.c_str());
   if (PC_PARTITIONS == 0)
   {
#ifdef MVS
      strcpy(PC_QUALIFIER,Database::instance()->qualifier().c_str());
      strcpy(PC_DBNAME,Database::instance()->getName().c_str());
      XXEC SQL
         SELECT
               PARTITIONS
            INTO
               :PC_PARTITIONS
            FROM SYSIBM.SYSTABLES TA
            INNER JOIN SYSIBM.SYSTABLESPACE TS
               ON TA.DBNAME = TS.DBNAME
               AND TA.TSNAME = TS.NAME
            WHERE TA.CREATOR = :PC_QUALIFIER
            AND TA.DBNAME = :PC_DBNAME
            AND TA.NAME = :PC_TABLE_NAME;

            if (strMisPartitions == "MISPARTS")
               PC_PARTITIONS = PC_PARTITIONS - 1;
#else
      PC_PARTITIONS = 183;
#endif
   }
   PC_PART_NUMBER = 0;

   
/*
EXEC SQL
      SELECT
         MAX(PART_NUMBER)
      INTO
         :PC_PART_NUMBER INDICATOR :PC_INDICATOR
      FROM PARTITION_CONTROL
      WHERE TABLE_NAME = :PC_TABLE_NAME;
*/

{
#line 289 "CXOSD208.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 289 "CXOSD208.sqx"
  sqlaaloc(2,1,3,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 289 "CXOSD208.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 19;
#line 289 "CXOSD208.sqx"
      sql_setdlist[0].sqldata = (void*)PC_TABLE_NAME;
#line 289 "CXOSD208.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 289 "CXOSD208.sqx"
      sqlasetdata(2,0,1,sql_setdlist,0L,0L);
    }
#line 289 "CXOSD208.sqx"
  sqlaaloc(3,1,4,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 289 "CXOSD208.sqx"
      sql_setdlist[0].sqltype = 501; sql_setdlist[0].sqllen = 2;
#line 289 "CXOSD208.sqx"
      sql_setdlist[0].sqldata = (void*)&PC_PART_NUMBER;
#line 289 "CXOSD208.sqx"
      sql_setdlist[0].sqlind = &PC_INDICATOR;
#line 289 "CXOSD208.sqx"
      sqlasetdata(3,0,1,sql_setdlist,0L,0L);
    }
#line 289 "CXOSD208.sqx"
  sqlacall((unsigned short)24,3,2,3,0L);
#line 289 "CXOSD208.sqx"
  sqlastop(0L);
}

#line 289 "CXOSD208.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         break;
      case 100:
         PC_PART_NUMBER = 0;
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         return DB2PartitionAllocator::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca,m_sID,"sync");
         if (sqlca.sqlcode > 0)
           break;
         return DB2PartitionAllocator::DATABASE_FAILURE;
   }
   if (!(PC_PART_NUMBER < PC_PARTITIONS))
      return DB2PartitionAllocator::DATABASE_FAILURE;
   ++PC_PART_NUMBER;
   IString strDate;
   DateTime hDateTime;
   hDateTime.setCurrent(strDate);
   strcpy(PC_TSTAMP_UPDATE,strDate);

   
/*
EXEC SQL
      INSERT INTO PARTITION_CONTROL
         (
            TABLE_QUALIFIER,
            TABLE_NAME,
            PART_NUMBER,
            PART_STAT,
            TSTAMP_START,
            TSTAMP_END,
            TSTAMP_UPDATE
         )
         VALUES
         (
            ' ',
            :PC_TABLE_NAME,
            :PC_PART_NUMBER,
            'A',
            :PC_TSTAMP_START,
            :PC_TSTAMP_END,
            :PC_TSTAMP_UPDATE
         );
*/

{
#line 338 "CXOSD208.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 338 "CXOSD208.sqx"
  sqlaaloc(2,5,5,0L);
    {
      struct sqla_setdata_list sql_setdlist[5];
#line 338 "CXOSD208.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 19;
#line 338 "CXOSD208.sqx"
      sql_setdlist[0].sqldata = (void*)PC_TABLE_NAME;
#line 338 "CXOSD208.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 338 "CXOSD208.sqx"
      sql_setdlist[1].sqltype = 500; sql_setdlist[1].sqllen = 2;
#line 338 "CXOSD208.sqx"
      sql_setdlist[1].sqldata = (void*)&PC_PART_NUMBER;
#line 338 "CXOSD208.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 338 "CXOSD208.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 17;
#line 338 "CXOSD208.sqx"
      sql_setdlist[2].sqldata = (void*)PC_TSTAMP_START;
#line 338 "CXOSD208.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 338 "CXOSD208.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 17;
#line 338 "CXOSD208.sqx"
      sql_setdlist[3].sqldata = (void*)PC_TSTAMP_END;
#line 338 "CXOSD208.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 338 "CXOSD208.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 17;
#line 338 "CXOSD208.sqx"
      sql_setdlist[4].sqldata = (void*)PC_TSTAMP_UPDATE;
#line 338 "CXOSD208.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 338 "CXOSD208.sqx"
      sqlasetdata(2,0,5,sql_setdlist,0L,0L);
    }
#line 338 "CXOSD208.sqx"
  sqlacall((unsigned short)24,4,2,0,0L);
#line 338 "CXOSD208.sqx"
  sqlastop(0L);
}

#line 338 "CXOSD208.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         *piKey = PC_PART_NUMBER;
         return DB2PartitionAllocator::SUCCESS;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         return DB2PartitionAllocator::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca,m_sID,"sync");
         if (sqlca.sqlcode > 0)
         {
           *piKey = PC_PART_NUMBER;
           return DB2PartitionAllocator::SUCCESS;
         }
   }
   return DB2PartitionAllocator::DATABASE_FAILURE;
  //## end dndb2database::DB2PartitionAllocator::sync%3D36BC680000.body
}

DB2PartitionAllocator::State DB2PartitionAllocator::update (short int* piKey, const char* pszPartTable)
{
  //## begin dndb2database::DB2PartitionAllocator::update%3D36BC680119.body preserve=yes
   PC_ACTIVE_PARTITIONS = 0;
   string strPartitions;
   int lPartitions = 0;
   // select count of "Active" partitions for this table
   
/*
EXEC SQL
      SELECT
         COUNT(*)
      INTO
         :PC_ACTIVE_PARTITIONS
      FROM PARTITION_CONTROL
      WHERE TABLE_NAME = :PC_TABLE_NAME
        AND PART_STAT = 'A';
*/

{
#line 377 "CXOSD208.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 377 "CXOSD208.sqx"
  sqlaaloc(2,1,6,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 377 "CXOSD208.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 19;
#line 377 "CXOSD208.sqx"
      sql_setdlist[0].sqldata = (void*)PC_TABLE_NAME;
#line 377 "CXOSD208.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 377 "CXOSD208.sqx"
      sqlasetdata(2,0,1,sql_setdlist,0L,0L);
    }
#line 377 "CXOSD208.sqx"
  sqlaaloc(3,1,7,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 377 "CXOSD208.sqx"
      sql_setdlist[0].sqltype = 500; sql_setdlist[0].sqllen = 2;
#line 377 "CXOSD208.sqx"
      sql_setdlist[0].sqldata = (void*)&PC_ACTIVE_PARTITIONS;
#line 377 "CXOSD208.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 377 "CXOSD208.sqx"
      sqlasetdata(3,0,1,sql_setdlist,0L,0L);
    }
#line 377 "CXOSD208.sqx"
  sqlacall((unsigned short)24,5,2,3,0L);
#line 377 "CXOSD208.sqx"
  sqlastop(0L);
}

#line 377 "CXOSD208.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
        if (Extract::instance()->getSpec(pszPartTable,strPartitions))
           lPartitions = atoi(strPartitions.c_str());
        if ((PC_ACTIVE_PARTITIONS + 1) == lPartitions)
          Console::display("ST135",PC_TABLE_NAME);
        break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         return DB2PartitionAllocator::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca,m_sID,"update");
         if (sqlca.sqlcode > 0)
           break;
         return DB2PartitionAllocator::DATABASE_FAILURE;
   }

   
/*
EXEC SQL
      SELECT
         PART_NUMBER
      INTO
         :PC_PART_NUMBER
      FROM PARTITION_CONTROL
      WHERE TABLE_NAME = :PC_TABLE_NAME
        AND PART_NUMBER = (SELECT MIN(PART_NUMBER)
                              FROM PARTITION_CONTROL
                              WHERE TABLE_NAME = :PC_TABLE_NAME
                                AND PART_STAT = 'R');
*/

{
#line 410 "CXOSD208.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 410 "CXOSD208.sqx"
  sqlaaloc(2,2,8,0L);
    {
      struct sqla_setdata_list sql_setdlist[2];
#line 410 "CXOSD208.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 19;
#line 410 "CXOSD208.sqx"
      sql_setdlist[0].sqldata = (void*)PC_TABLE_NAME;
#line 410 "CXOSD208.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 410 "CXOSD208.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 19;
#line 410 "CXOSD208.sqx"
      sql_setdlist[1].sqldata = (void*)PC_TABLE_NAME;
#line 410 "CXOSD208.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 410 "CXOSD208.sqx"
      sqlasetdata(2,0,2,sql_setdlist,0L,0L);
    }
#line 410 "CXOSD208.sqx"
  sqlaaloc(3,1,9,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 410 "CXOSD208.sqx"
      sql_setdlist[0].sqltype = 500; sql_setdlist[0].sqllen = 2;
#line 410 "CXOSD208.sqx"
      sql_setdlist[0].sqldata = (void*)&PC_PART_NUMBER;
#line 410 "CXOSD208.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 410 "CXOSD208.sqx"
      sqlasetdata(3,0,1,sql_setdlist,0L,0L);
    }
#line 410 "CXOSD208.sqx"
  sqlacall((unsigned short)24,6,2,3,0L);
#line 410 "CXOSD208.sqx"
  sqlastop(0L);
}

#line 410 "CXOSD208.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         break;
      case 100:
         return DB2PartitionAllocator::SYNC;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         return DB2PartitionAllocator::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca,m_sID,"update");
         if (sqlca.sqlcode > 0)
           break;
         return DB2PartitionAllocator::DATABASE_FAILURE;
   }
   IString strDate;
   DateTime hDateTime;
   hDateTime.setCurrent(strDate);
   strcpy(PC_TSTAMP_UPDATE,strDate);

   
/*
EXEC SQL
      UPDATE PARTITION_CONTROL
         SET
            PART_STAT = 'A',
            TSTAMP_START = :PC_TSTAMP_START,
            TSTAMP_END = :PC_TSTAMP_END,
            TSTAMP_UPDATE = :PC_TSTAMP_UPDATE
         WHERE TABLE_NAME = :PC_TABLE_NAME
           AND PART_NUMBER = :PC_PART_NUMBER;
*/

{
#line 443 "CXOSD208.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 443 "CXOSD208.sqx"
  sqlaaloc(2,5,10,0L);
    {
      struct sqla_setdata_list sql_setdlist[5];
#line 443 "CXOSD208.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 17;
#line 443 "CXOSD208.sqx"
      sql_setdlist[0].sqldata = (void*)PC_TSTAMP_START;
#line 443 "CXOSD208.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 443 "CXOSD208.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 17;
#line 443 "CXOSD208.sqx"
      sql_setdlist[1].sqldata = (void*)PC_TSTAMP_END;
#line 443 "CXOSD208.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 443 "CXOSD208.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 17;
#line 443 "CXOSD208.sqx"
      sql_setdlist[2].sqldata = (void*)PC_TSTAMP_UPDATE;
#line 443 "CXOSD208.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 443 "CXOSD208.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 19;
#line 443 "CXOSD208.sqx"
      sql_setdlist[3].sqldata = (void*)PC_TABLE_NAME;
#line 443 "CXOSD208.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 443 "CXOSD208.sqx"
      sql_setdlist[4].sqltype = 500; sql_setdlist[4].sqllen = 2;
#line 443 "CXOSD208.sqx"
      sql_setdlist[4].sqldata = (void*)&PC_PART_NUMBER;
#line 443 "CXOSD208.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 443 "CXOSD208.sqx"
      sqlasetdata(2,0,5,sql_setdlist,0L,0L);
    }
#line 443 "CXOSD208.sqx"
  sqlacall((unsigned short)24,7,2,0,0L);
#line 443 "CXOSD208.sqx"
  sqlastop(0L);
}

#line 443 "CXOSD208.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         *piKey = PC_PART_NUMBER;
         return DB2PartitionAllocator::SUCCESS;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         return DB2PartitionAllocator::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca,m_sID,"update");
         if (sqlca.sqlcode > 0)
         {
           *piKey = PC_PART_NUMBER;
           return DB2PartitionAllocator::SUCCESS;
         }
   }
   return DB2PartitionAllocator::DATABASE_FAILURE;
  //## end dndb2database::DB2PartitionAllocator::update%3D36BC680119.body
}

// Additional Declarations
  //## begin dndb2database::DB2PartitionAllocator%3463469100C7.declarations preserve=yes
  //## end dndb2database::DB2PartitionAllocator%3463469100C7.declarations

} // namespace dndb2database

//## begin module%365AD1050249.epilog preserve=yes
//## end module%365AD1050249.epilog
