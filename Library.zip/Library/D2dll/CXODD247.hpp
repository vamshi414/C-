//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5E8265820328.cm preserve=no
//	$Date:   Apr 10 2020 08:49:30  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5E8265820328.cm

//## begin module%5E8265820328.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5E8265820328.cp

//## Module: CXOSD247%5E8265820328; Package specification
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\D2dll\CXODD247.hpp

#ifndef CXOSD247_h
#define CXOSD247_h 1

//## begin module%5E8265820328.additionalIncludes preserve=no
//## end module%5E8265820328.additionalIncludes

//## begin module%5E8265820328.includes preserve=yes
//## end module%5E8265820328.includes

#ifndef CXOSST34_h
#include "CXODST34.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class FinancialTransaction;
class Accumulator;
class RulesMediator;
} // namespace settlement

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%5E8265820328.declarations preserve=no
//## end module%5E8265820328.declarations

//## begin module%5E8265820328.additionalDeclarations preserve=yes
//## end module%5E8265820328.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

//## begin dndb2database::DB2AggregatorMIS2%5E826410015B.preface preserve=yes
//## end dndb2database::DB2AggregatorMIS2%5E826410015B.preface

//## Class: DB2AggregatorMIS2%5E826410015B
//## Category: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
//## Subsystem: D2DLL%3597E8A6029B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5E8264410224;database::Database { -> F}
//## Uses: <unnamed>%5E8264440333;monitor::UseCase { -> F}
//## Uses: <unnamed>%5E82644801EB;settlement::FinancialTransaction { -> F}
//## Uses: <unnamed>%5E82644C006D;settlement::Accumulator { -> F}
//## Uses: <unnamed>%5E8F1E110342;settlement::RulesMediator { -> F}

class DllExport DB2AggregatorMIS2 : public settlement::AggregatorMIS  //## Inherits: <unnamed>%5E82643B02E2
{
  //## begin dndb2database::DB2AggregatorMIS2%5E826410015B.initialDeclarations preserve=yes
  //## end dndb2database::DB2AggregatorMIS2%5E826410015B.initialDeclarations

  public:
    //## Constructors (generated)
      DB2AggregatorMIS2();

    //## Destructor (generated)
      virtual ~DB2AggregatorMIS2();


    //## Other Operations (specified)
      //## Operation: commit%5E826750003A
      virtual bool commit ();

      //## Operation: tableInsert%5E8264C90047
      virtual bool tableInsert (bool bSubtractFromTotals = false);

      //## Operation: tableUpdate%5E8264CB00EF
      virtual int tableUpdate (bool bSubtractFromTotals = false);

    // Additional Public Declarations
      //## begin dndb2database::DB2AggregatorMIS2%5E826410015B.public preserve=yes
      //## end dndb2database::DB2AggregatorMIS2%5E826410015B.public

  protected:
    // Additional Protected Declarations
      //## begin dndb2database::DB2AggregatorMIS2%5E826410015B.protected preserve=yes
      //## end dndb2database::DB2AggregatorMIS2%5E826410015B.protected

  private:
    // Additional Private Declarations
      //## begin dndb2database::DB2AggregatorMIS2%5E826410015B.private preserve=yes
      //## end dndb2database::DB2AggregatorMIS2%5E826410015B.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dndb2database::DB2AggregatorMIS2%5E826410015B.implementation preserve=yes
      //## end dndb2database::DB2AggregatorMIS2%5E826410015B.implementation

};

//## begin dndb2database::DB2AggregatorMIS2%5E826410015B.postscript preserve=yes
//## end dndb2database::DB2AggregatorMIS2%5E826410015B.postscript

} // namespace dndb2database

//## begin module%5E8265820328.epilog preserve=yes
//## end module%5E8265820328.epilog


#endif
