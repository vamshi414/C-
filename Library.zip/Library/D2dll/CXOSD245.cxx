static char sqla_program_id[292] = 
{
 '\xac','\x0','\x41','\x45','\x41','\x56','\x41','\x49','\x67','\x42','\x66','\x34','\x52','\x48','\x49','\x6f','\x30','\x31','\x31','\x31',
 '\x31','\x20','\x32','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x8','\x0','\x44','\x4e','\x53','\x45','\x52','\x56',
 '\x45','\x52','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x8','\x0','\x43','\x58','\x4f','\x53','\x44','\x32','\x34','\x35','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0'
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {'C',' ',' ',' '}};


static const short sqlIsLiteral   = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "CXOSD245.sqx"
//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40719CE500CB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40719CE500CB.cm

//## begin module%40719CE500CB.cp preserve=no
//	Copyright (c) 1998 - 2003
//	eFunds Corporation
//## end module%40719CE500CB.cp

//## Module: CXOSD245%40719CE500CB; Package body
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXOSD245.sqx

//## begin module%40719CE500CB.additionalIncludes preserve=no
//## end module%40719CE500CB.additionalIncludes

//## begin module%40719CE500CB.includes preserve=yes
#include <stdio.h>
#include "CXODIF03.hpp"
//## end module%40719CE500CB.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSD245_h
#include "CXODD245.hpp"
#endif
//## begin module%40719CE500CB.declarations preserve=no
//## end module%40719CE500CB.declarations

//## begin module%40719CE500CB.additionalDeclarations preserve=yes
#ifdef MVS

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
struct sqlca sqlca;


#line 42 "CXOSD245.sqx"

#else
#include "sqlca.h"
extern struct sqlca sqlca;
#endif


/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 48 "CXOSD245.sqx"

   char APR_ROW_TYPE[3];
   char APR_TSTAMP_PERIOD[11];
   sqlint32 APR_T_FIN_ENTITY_ID;
   short APR_COUNT_1;
   short APR_COUNT_2;
   short APR_COUNT_3;

/*
EXEC SQL END DECLARE SECTION;
*/

#line 55 "CXOSD245.sqx"

//## end module%40719CE500CB.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

// Class dndb2database::DB2AggregatorPOSRisk

DB2AggregatorPOSRisk::DB2AggregatorPOSRisk()
  //## begin DB2AggregatorPOSRisk::DB2AggregatorPOSRisk%40719C640138_const.hasinit preserve=no
  //## end DB2AggregatorPOSRisk::DB2AggregatorPOSRisk%40719C640138_const.hasinit
  //## begin DB2AggregatorPOSRisk::DB2AggregatorPOSRisk%40719C640138_const.initialization preserve=yes
  //## end DB2AggregatorPOSRisk::DB2AggregatorPOSRisk%40719C640138_const.initialization
{
  //## begin dndb2database::DB2AggregatorPOSRisk::DB2AggregatorPOSRisk%40719C640138_const.body preserve=yes
   memcpy(m_sID,"D245",4);
   memcpy(APR_ROW_TYPE,"PK",2);
   APR_ROW_TYPE[2] = '\0';
   APR_COUNT_1 = 1;
  //## end dndb2database::DB2AggregatorPOSRisk::DB2AggregatorPOSRisk%40719C640138_const.body
}


DB2AggregatorPOSRisk::~DB2AggregatorPOSRisk()
{
  //## begin dndb2database::DB2AggregatorPOSRisk::~DB2AggregatorPOSRisk%40719C640138_dest.body preserve=yes
  //## end dndb2database::DB2AggregatorPOSRisk::~DB2AggregatorPOSRisk%40719C640138_dest.body
}



//## Other Operations (implementation)
int DB2AggregatorPOSRisk::checkResult ()
{
  //## begin dndb2database::DB2AggregatorPOSRisk::checkResult%4072EFAC009C.body preserve=yes
   switch (sqlca.sqlcode)
   {
      case 0:
         UseCase::addItem();
         return 1;
      case 100:
         return 0;
      case -911:
      case -913:
         UseCase::add("DEADLOCK");
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         UseCase::add("CONNECT");
         Database::instance()->setState(Database::DISCONNECTED);
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
           Database::instance()->traceSQLError((void*)&sqlca,m_sID,"UPDATE");
           UseCase::addItem();
           return 1;
         }
         else
           UseCase::add("DBERROR");
   }
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca, m_sID,"UPDATE");
   return -1;
  //## end dndb2database::DB2AggregatorPOSRisk::checkResult%4072EFAC009C.body
}

bool DB2AggregatorPOSRisk::tableInsert ()
{
  //## begin dndb2database::DB2AggregatorPOSRisk::tableInsert%407416F501A5.body preserve=yes
   
/*
EXEC SQL
      INSERT INTO T_FIN_COUNT
         (
            ROW_TYPE,
            TSTAMP_PERIOD,
            T_FIN_ENTITY_ID,
            COUNT_1,
            COUNT_2,
            COUNT_3
         )
         VALUES
         (
            :APR_ROW_TYPE,
            :APR_TSTAMP_PERIOD,
            :APR_T_FIN_ENTITY_ID,
            :APR_COUNT_1,
            :APR_COUNT_2,
            :APR_COUNT_3
         );
*/

{
#line 149 "CXOSD245.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 149 "CXOSD245.sqx"
  sqlaaloc(2,6,1,0L);
    {
      struct sqla_setdata_list sql_setdlist[6];
#line 149 "CXOSD245.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 3;
#line 149 "CXOSD245.sqx"
      sql_setdlist[0].sqldata = (void*)APR_ROW_TYPE;
#line 149 "CXOSD245.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 149 "CXOSD245.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 11;
#line 149 "CXOSD245.sqx"
      sql_setdlist[1].sqldata = (void*)APR_TSTAMP_PERIOD;
#line 149 "CXOSD245.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 149 "CXOSD245.sqx"
      sql_setdlist[2].sqltype = 496; sql_setdlist[2].sqllen = 4;
#line 149 "CXOSD245.sqx"
      sql_setdlist[2].sqldata = (void*)&APR_T_FIN_ENTITY_ID;
#line 149 "CXOSD245.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 149 "CXOSD245.sqx"
      sql_setdlist[3].sqltype = 500; sql_setdlist[3].sqllen = 2;
#line 149 "CXOSD245.sqx"
      sql_setdlist[3].sqldata = (void*)&APR_COUNT_1;
#line 149 "CXOSD245.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 149 "CXOSD245.sqx"
      sql_setdlist[4].sqltype = 500; sql_setdlist[4].sqllen = 2;
#line 149 "CXOSD245.sqx"
      sql_setdlist[4].sqldata = (void*)&APR_COUNT_2;
#line 149 "CXOSD245.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 149 "CXOSD245.sqx"
      sql_setdlist[5].sqltype = 500; sql_setdlist[5].sqllen = 2;
#line 149 "CXOSD245.sqx"
      sql_setdlist[5].sqldata = (void*)&APR_COUNT_3;
#line 149 "CXOSD245.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 149 "CXOSD245.sqx"
      sqlasetdata(2,0,6,sql_setdlist,0L,0L);
    }
#line 149 "CXOSD245.sqx"
  sqlacall((unsigned short)24,1,2,0,0L);
#line 149 "CXOSD245.sqx"
  sqlastop(0L);
}

#line 149 "CXOSD245.sqx"

   if (checkResult() == -1)
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_COUNT %s %s %ld %ld %ld %ld",
         APR_ROW_TYPE,APR_TSTAMP_PERIOD,APR_T_FIN_ENTITY_ID,APR_COUNT_1,APR_COUNT_2,APR_COUNT_3);
      Trace::put(szTemp);
	  return false;
   }
   return true;
  //## end dndb2database::DB2AggregatorPOSRisk::tableInsert%407416F501A5.body
}

int DB2AggregatorPOSRisk::tableUpdate ()
{
  //## begin dndb2database::DB2AggregatorPOSRisk::tableUpdate%4074170001C5.body preserve=yes
   if(getTSTAMP_PERIOD().length() < sizeof(APR_TSTAMP_PERIOD)) {
      memcpy(APR_TSTAMP_PERIOD,getTSTAMP_PERIOD().data(),getTSTAMP_PERIOD().length());
      APR_TSTAMP_PERIOD[getTSTAMP_PERIOD().length()] = '\0';
   }
   APR_T_FIN_ENTITY_ID = getT_FIN_ENTITY_ID();
   APR_COUNT_2 = getCOUNT_2();
   APR_COUNT_3 = getCOUNT_3();
   
/*
EXEC SQL
      UPDATE T_FIN_COUNT
         SET
            COUNT_1 = COUNT_1 + 1,
            COUNT_2 = COUNT_2 + :APR_COUNT_2,
            COUNT_3 = COUNT_3 + :APR_COUNT_3
         WHERE
            ROW_TYPE = :APR_ROW_TYPE
            AND TSTAMP_PERIOD = :APR_TSTAMP_PERIOD
            AND T_FIN_ENTITY_ID = :APR_T_FIN_ENTITY_ID;
*/

{
#line 181 "CXOSD245.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 181 "CXOSD245.sqx"
  sqlaaloc(2,5,2,0L);
    {
      struct sqla_setdata_list sql_setdlist[5];
#line 181 "CXOSD245.sqx"
      sql_setdlist[0].sqltype = 500; sql_setdlist[0].sqllen = 2;
#line 181 "CXOSD245.sqx"
      sql_setdlist[0].sqldata = (void*)&APR_COUNT_2;
#line 181 "CXOSD245.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 181 "CXOSD245.sqx"
      sql_setdlist[1].sqltype = 500; sql_setdlist[1].sqllen = 2;
#line 181 "CXOSD245.sqx"
      sql_setdlist[1].sqldata = (void*)&APR_COUNT_3;
#line 181 "CXOSD245.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 181 "CXOSD245.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 3;
#line 181 "CXOSD245.sqx"
      sql_setdlist[2].sqldata = (void*)APR_ROW_TYPE;
#line 181 "CXOSD245.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 181 "CXOSD245.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 11;
#line 181 "CXOSD245.sqx"
      sql_setdlist[3].sqldata = (void*)APR_TSTAMP_PERIOD;
#line 181 "CXOSD245.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 181 "CXOSD245.sqx"
      sql_setdlist[4].sqltype = 496; sql_setdlist[4].sqllen = 4;
#line 181 "CXOSD245.sqx"
      sql_setdlist[4].sqldata = (void*)&APR_T_FIN_ENTITY_ID;
#line 181 "CXOSD245.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 181 "CXOSD245.sqx"
      sqlasetdata(2,0,5,sql_setdlist,0L,0L);
    }
#line 181 "CXOSD245.sqx"
  sqlacall((unsigned short)24,2,2,0,0L);
#line 181 "CXOSD245.sqx"
  sqlastop(0L);
}

#line 181 "CXOSD245.sqx"

   int IRC = checkResult();
   if (IRC == -1)
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"UPDATE T_FIN_COUNT %s %s %ld %ld %ld %ld",
         APR_ROW_TYPE,APR_TSTAMP_PERIOD,APR_T_FIN_ENTITY_ID,APR_COUNT_1,APR_COUNT_2,APR_COUNT_3);
      Trace::put(szTemp);
	  return IRC;
   }
   return IRC;
  //## end dndb2database::DB2AggregatorPOSRisk::tableUpdate%4074170001C5.body
}

// Additional Declarations
  //## begin dndb2database::DB2AggregatorPOSRisk%40719C640138.declarations preserve=yes
  //## end dndb2database::DB2AggregatorPOSRisk%40719C640138.declarations

} // namespace dndb2database

//## begin module%40719CE500CB.epilog preserve=yes
//## end module%40719CE500CB.epilog
