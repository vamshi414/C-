//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6146FDE402E2.cm preserve=no
//	$Date:   Nov 02 2021 12:42:00  $ $Author:   e3023547  $
//	$Revision:   1.0  $
//## end module%6146FDE402E2.cm

//## begin module%6146FDE402E2.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%6146FDE402E2.cp

//## Module: CXOSD248%6146FDE402E2; Package specification
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: D:\Devel\V03.2A.R003\Dn\Server\Library\D2dll\CXODD248.hpp

#ifndef CXOSD248_h
#define CXOSD248_h 1

//## begin module%6146FDE402E2.additionalIncludes preserve=no
//## end module%6146FDE402E2.additionalIncludes

//## begin module%6146FDE402E2.includes preserve=yes
//## end module%6146FDE402E2.includes

#ifndef CXOSST80_h
#include "CXODST80.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;

} // namespace monitor

//## begin module%6146FDE402E2.declarations preserve=no
//## end module%6146FDE402E2.declarations

//## begin module%6146FDE402E2.additionalDeclarations preserve=yes
//## end module%6146FDE402E2.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

//## begin dndb2database::DB2MonthlyTotals%6146FC1E036D.preface preserve=yes
//## end dndb2database::DB2MonthlyTotals%6146FC1E036D.preface

//## Class: DB2MonthlyTotals%6146FC1E036D
//## Category: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
//## Subsystem: D2DLL%3597E8A6029B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%614700F503CA;database::Database { -> F}
//## Uses: <unnamed>%614700F802FF;monitor::UseCase { -> F}

class DllExport DB2MonthlyTotals : public settlement::MonthlyTotal  //## Inherits: <unnamed>%61470044034F
{
  //## begin dndb2database::DB2MonthlyTotals%6146FC1E036D.initialDeclarations preserve=yes
  //## end dndb2database::DB2MonthlyTotals%6146FC1E036D.initialDeclarations

  public:
    //## Constructors (generated)
      DB2MonthlyTotals();

    //## Destructor (generated)
      virtual ~DB2MonthlyTotals();


    //## Other Operations (specified)
      //## Operation: commit%61470144039F
      virtual bool commit ();

      //## Operation: tableUpdate%61470114016E
      virtual int tableUpdate ();

    // Additional Public Declarations
      //## begin dndb2database::DB2MonthlyTotals%6146FC1E036D.public preserve=yes
      //## end dndb2database::DB2MonthlyTotals%6146FC1E036D.public

  protected:
    // Additional Protected Declarations
      //## begin dndb2database::DB2MonthlyTotals%6146FC1E036D.protected preserve=yes
      //## end dndb2database::DB2MonthlyTotals%6146FC1E036D.protected

  private:
    // Additional Private Declarations
      //## begin dndb2database::DB2MonthlyTotals%6146FC1E036D.private preserve=yes
      //## end dndb2database::DB2MonthlyTotals%6146FC1E036D.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dndb2database::DB2MonthlyTotals%6146FC1E036D.implementation preserve=yes
      //## end dndb2database::DB2MonthlyTotals%6146FC1E036D.implementation

};

//## begin dndb2database::DB2MonthlyTotals%6146FC1E036D.postscript preserve=yes
//## end dndb2database::DB2MonthlyTotals%6146FC1E036D.postscript

} // namespace dndb2database

//## begin module%6146FDE402E2.epilog preserve=yes
//## end module%6146FDE402E2.epilog


#endif
