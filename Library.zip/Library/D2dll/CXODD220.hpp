//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%365B049E018F.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%365B049E018F.cm

//## begin module%365B049E018F.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%365B049E018F.cp

//## Module: CXOSD220%365B049E018F; Package specification
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\D2DLL\CXODD220.hpp

#ifndef CXOSD220_h
#define CXOSD220_h 1

//## begin module%365B049E018F.additionalIncludes preserve=no
//## end module%365B049E018F.additionalIncludes

//## begin module%365B049E018F.includes preserve=yes
// $Date:   Jan 31 2017 16:46:44  $ $Author:   e1009510  $ $Revision:   1.8  $
//## end module%365B049E018F.includes

#ifndef CXOSPC05_h
#include "CXODPC05.hpp"
#endif
//## begin module%365B049E018F.declarations preserve=no
//## end module%365B049E018F.declarations

//## begin module%365B049E018F.additionalDeclarations preserve=yes
//## end module%365B049E018F.additionalDeclarations


//## Modelname: DataNavigator Foundation::DB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin db2database%346CAA2702B3.initialDeclarations preserve=yes
//## end db2database%346CAA2702B3.initialDeclarations

//## begin db2database::DB2PartitionDeallocator%34C1095E03BB.preface preserve=yes
//## end db2database::DB2PartitionDeallocator%34C1095E03BB.preface

//## Class: DB2PartitionDeallocator%34C1095E03BB
//	The DB2PartitionDeallocator class represents the
//	algorithms used to deallocate partitions for a table in
//	the STS short term repository implemented as a DB2
//	database.
//
//	It is based on the ConcreteStrategy object in the
//	Strategy pattern.
//## Category: DataNavigator Foundation::DB2Database_CAT%346CAA2702B3
//## Subsystem: D2DLL%3597E8A6029B
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class DllExport DB2PartitionDeallocator : public partition::PartitionDeallocator  //## Inherits: <unnamed>%34C10A6E02EA
{
  //## begin db2database::DB2PartitionDeallocator%34C1095E03BB.initialDeclarations preserve=yes
   enum State
   {
      START,
      SELECT,
      SUCCESS,
      DEADLOCK_TIMEOUT,
      DATABASE_FAILURE,
      DATABASE_CONNECTION_ERROR
   };
  //## end db2database::DB2PartitionDeallocator%34C1095E03BB.initialDeclarations

  public:
    //## Constructors (generated)
      DB2PartitionDeallocator();

    //## Destructor (generated)
      virtual ~DB2PartitionDeallocator();


    //## Other Operations (specified)
      //## Operation: available%34C3C60401B5
      //	Return the number of available partitions for an STS
      //	table.
      //## Semantics:
      //	1. SELECT
      //	        PARTITIONS
      //	        FROM SYSIBM.SYSTABLES TA,
      //	            SYSIBM.SYSTABLESPACE TS
      //	         WHERE TA.DBNAME =
      //	Database::instance()->qualifier()
      //	            AND TS.DBNAME =
      //	Database::instance()->qualifier()
      //	            AND TA.NAME = m_strTableName
      //	            AND TS.NAME = TA.TSNAME.
      //	2. SELECT
      //	        COUNT(*)
      //	        FROM PARTITION_CONTROL
      //	        WHERE TABLE_NAME = m_strTableName
      //	            AND PART_STAT NOT = 'R'.
      //	3. *piPartitionCount = result1 - result2.
      //	4. Return true if successful; else false.
      virtual bool available (int* piPartitionCount);

      //## Operation: deallocate%34C3C60802DD
      //	Deallocate a partition for a table in the STS repository.
      //## Semantics:
      //	1. UPDATE PARTITION_CONTROL SET
      //	        PART_STAT = 'R',
      //	        TSTAMP_START = ' ',
      //	        TSTAMP_END = ' ',
      //	        TSTAMP_UPDATE = current timestamp,
      //	        WHERE
      //	            TABLE_NAME = m_strTableName
      //	            AND PART_NUMBER = iPartitionNumber
      //	            AND PART_STAT = 'C'. /* Mark : who is
      //	setting this in 1.8 ? */
      //	2. Call SharedResource::notify.
      //	2. Return true if successful; else false.
      virtual bool deallocate (int iPartitionNumber);

      //## Operation: oldest%34C3C60D0096
      //	Return the starting timestamp, ending timestamp, and
      //	partition number of the oldest partition for a table in
      //	the STS repository.
      //## Semantics:
      //	1. SELECT TSTAMP_START, TSTAMP_END, PART_NUMBER
      //	        FROM PARTITION_CONTROL
      //	        WHERE TSTAMP_END =
      //	            (SELECT MIN(TSTAMP_END)
      //	                FROM PARTITION_CONTROL
      //	                WHERE TABLE_NAME = m_strTableName.
      //	2. Return true if successful; else false.
      virtual bool oldest (IString& strTimestampStart, IString& strTimestampEnd, int* piPartitionNumber);

    // Additional Public Declarations
      //## begin db2database::DB2PartitionDeallocator%34C1095E03BB.public preserve=yes
      //## end db2database::DB2PartitionDeallocator%34C1095E03BB.public

  protected:
    // Additional Protected Declarations
      //## begin db2database::DB2PartitionDeallocator%34C1095E03BB.protected preserve=yes
      //## end db2database::DB2PartitionDeallocator%34C1095E03BB.protected

  private:

    //## Other Operations (specified)
      //## Operation: selectCatalog%3D36BFE00177
      State selectCatalog ();

      //## Operation: selectCount%3D36BFEC00DA
      State selectCount ();

      //## Operation: selectOldest%3D36BFEC0203
      State selectOldest ();

      //## Operation: update%3D36BFEC030D
      State update ();

    // Additional Private Declarations
      //## begin db2database::DB2PartitionDeallocator%34C1095E03BB.private preserve=yes
      //## end db2database::DB2PartitionDeallocator%34C1095E03BB.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: State%3D36C03F007D
      //## begin db2database::DB2PartitionDeallocator::State%3D36C03F007D.attr preserve=no  private: State {V} 
      State m_nState;
      //## end db2database::DB2PartitionDeallocator::State%3D36C03F007D.attr

    // Additional Implementation Declarations
      //## begin db2database::DB2PartitionDeallocator%34C1095E03BB.implementation preserve=yes
      //## end db2database::DB2PartitionDeallocator%34C1095E03BB.implementation

};

//## begin db2database::DB2PartitionDeallocator%34C1095E03BB.postscript preserve=yes
//## end db2database::DB2PartitionDeallocator%34C1095E03BB.postscript

} // namespace db2database

//## begin module%365B049E018F.epilog preserve=yes
using namespace dndb2database;
//## end module%365B049E018F.epilog


#endif
