//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%365B069E03BC.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%365B069E03BC.cm

//## begin module%365B069E03BC.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%365B069E03BC.cp

//## Module: CXOSD227%365B069E03BC; Package body
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXOSD227.cpp

//## begin module%365B069E03BC.additionalIncludes preserve=no
//## end module%365B069E03BC.additionalIncludes

//## begin module%365B069E03BC.includes preserve=yes
// $Date:   Jan 30 2009 08:55:00  $ $Author:   D02405  $ $Revision:   1.7  $
//## end module%365B069E03BC.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSD227_h
#include "CXODD227.hpp"
#endif


//## begin module%365B069E03BC.declarations preserve=no
//## end module%365B069E03BC.declarations

//## begin module%365B069E03BC.additionalDeclarations preserve=yes
//## end module%365B069E03BC.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

// Class dndb2database::DB2Locator 

DB2Locator::DB2Locator()
  //## begin DB2Locator::DB2Locator%3505AB93031B_const.hasinit preserve=no
  //## end DB2Locator::DB2Locator%3505AB93031B_const.hasinit
  //## begin DB2Locator::DB2Locator%3505AB93031B_const.initialization preserve=yes
  //## end DB2Locator::DB2Locator%3505AB93031B_const.initialization
{
  //## begin dndb2database::DB2Locator::DB2Locator%3505AB93031B_const.body preserve=yes
  //## end dndb2database::DB2Locator::DB2Locator%3505AB93031B_const.body
}


DB2Locator::~DB2Locator()
{
  //## begin dndb2database::DB2Locator::~DB2Locator%3505AB93031B_dest.body preserve=yes
  //## end dndb2database::DB2Locator::~DB2Locator%3505AB93031B_dest.body
}



//## Other Operations (implementation)
bool DB2Locator::synchronize ()
{
  //## begin dndb2database::DB2Locator::synchronize%366C477E0176.body preserve=yes
   CriticalSection hCriticalSection("CATALOG");
   short iNull = 0;
   m_lCount = 0;
   string strName(m_strTableName);
   strName += '%';
#ifdef MVS
   char* pszQualifier = "SYSIBM";
   char* pszTables = "SYSTABLES";
   char* pszName = "NAME";
   char* pszCreator = "CREATOR";
   char* pszDBName = "DBNAME";
#else
   char* pszQualifier = "SYSCAT";
   char* pszTables = "TABLES";
   char* pszName = "TABNAME";
   char* pszCreator = "TABSCHEMA";
   char* pszDBName = "DEFINER";
#endif
   Query hQuery;
   hQuery.setQualifier(pszQualifier,pszTables);
   hQuery.bind(pszTables,"*",Column::LONG,&m_lCount,0,"COUNT");
   hQuery.bind(pszTables,pszName,Column::STRING,&m_strMinName,&iNull,"MIN");
   hQuery.setBasicPredicate(pszTables,pszCreator,"=",Database::instance()->qualifier().c_str());
#ifdef MVS
   hQuery.setBasicPredicate(pszTables,pszDBName,"=",Database::instance()->getName().c_str());
#endif
   hQuery.setBasicPredicate(pszTables,pszName,"LIKE",strName.c_str());
   hQuery.setBasicPredicate(pszTables,pszName,"NOT LIKE","%LOCATOR");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   if (iNull != -1)
   {
      hQuery.reset();
      hQuery.setQualifier(pszQualifier,pszTables);
      hQuery.bind(pszTables,pszName,Column::STRING,&m_strMaxName,0,"MAX");
      hQuery.setBasicPredicate(pszTables,pszCreator,"=",Database::instance()->qualifier().c_str());
#ifdef MVS
      hQuery.setBasicPredicate(pszTables,pszDBName,"=",Database::instance()->getName().c_str());
#endif
      hQuery.setBasicPredicate(pszTables,pszName,"LIKE",strName.c_str());
      hQuery.setBasicPredicate(pszTables,pszName,"NOT LIKE","%LOCATOR");
      if (!pSelectStatement->execute(hQuery))
         return false;
   }
   return archive::Locator::synchronize();
  //## end dndb2database::DB2Locator::synchronize%366C477E0176.body
}

// Additional Declarations
  //## begin dndb2database::DB2Locator%3505AB93031B.declarations preserve=yes
  //## end dndb2database::DB2Locator%3505AB93031B.declarations

} // namespace dndb2database

//## begin module%365B069E03BC.epilog preserve=yes
//## end module%365B069E03BC.epilog
