//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%365AD1030387.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%365AD1030387.cm

//## begin module%365AD1030387.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%365AD1030387.cp

//## Module: CXOSD208%365AD1030387; Package specification
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXODD208.hpp

#ifndef CXOSD208_h
#define CXOSD208_h 1

//## begin module%365AD1030387.additionalIncludes preserve=no
//## end module%365AD1030387.additionalIncludes

//## begin module%365AD1030387.includes preserve=yes
// $Date:   Jan 31 2017 16:46:44  $ $Author:   e1009510  $ $Revision:   1.15  $
//## end module%365AD1030387.includes

#ifndef CXOSPC03_h
#include "CXODPC03.hpp"
#endif

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CriticalSection;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Console;
class DateTime;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%365AD1030387.declarations preserve=no
//## end module%365AD1030387.declarations

//## begin module%365AD1030387.additionalDeclarations preserve=yes
//## end module%365AD1030387.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

//## begin dndb2database::DB2PartitionAllocator%3463469100C7.preface preserve=yes
//## end dndb2database::DB2PartitionAllocator%3463469100C7.preface

//## Class: DB2PartitionAllocator%3463469100C7
//	The DB2PartitionAllocator class represents the algorithm
//	used to determine a partition key based on a DB2 table
//	name and date.
//
//	It is based on the ConcreteStrategy object in the
//	Strategy pattern.
//## Category: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
//## Subsystem: D2DLL%3597E8A6029B
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1



//## Uses: <unnamed>%3475F0C303AB;database::Database { -> F}
//## Uses: <unnamed>%3E635D7902DE;IF::DateTime { -> F}
//## Uses: <unnamed>%3E635D7D002E;monitor::UseCase { -> F}
//## Uses: <unnamed>%3E635D9F00CB;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%3E635DB7005D;IF::Extract { -> F}
//## Uses: <unnamed>%3F02E6B0008C;IF::Console { -> F}

class DllExport DB2PartitionAllocator : public partition::PartitionAllocator  //## Inherits: <unnamed>%346B9879004C
{
  //## begin dndb2database::DB2PartitionAllocator%3463469100C7.initialDeclarations preserve=yes
   enum State
   {
      START,
      SELECT,
      SUCCESS,
      UPDATE,
      SYNC,
      LOCK_DEADLOCK_TIMEOUT,
      DATABASE_FAILURE,
      DATABASE_CONNECTION_ERROR
   };
  //## end dndb2database::DB2PartitionAllocator%3463469100C7.initialDeclarations

  public:
    //## Constructors (generated)
      DB2PartitionAllocator();

    //## Destructor (generated)
      virtual ~DB2PartitionAllocator();


    //## Other Operations (specified)
      //## Operation: allocate%346B98AA01E7
      //	Provides the key value if a partition can be allocated
      //	for the table and date provided.
      //
      //	If an existing partition is found, return 0.
      //	If a new partition is allocated, return 1.
      //	If a partition cannot be allocated, return -1.
      //## Semantics:
      //	1. Enqueue the partition control table.
      //	2. Query the partition control table for a row that
      //	matches the table name and date.
      //	3. If found:
      //	    Copy the partition key and return 0.
      //	4. If not found, query the partition control table for
      //	empty partitions.
      //	5. If no empty partitions are found:
      //	    Copy -1 to the new key and return -1.
      //	6. Update one empty partition by setting the status to
      //	in-use and the date to the date provided.
      //	7. Copy the newly allocated partition key and return 1.
      //
      //	In all cases, before returning:
      //
      //	1. Commit changes to the database.
      //	2. Dequeue the partition control table.
      virtual int allocate (const char* pszTable, const char* pszDate, short int* piKey, const char* pszPartTable);

    // Additional Public Declarations
      //## begin dndb2database::DB2PartitionAllocator%3463469100C7.public preserve=yes
      //## end dndb2database::DB2PartitionAllocator%3463469100C7.public

  protected:
    // Additional Protected Declarations
      //## begin dndb2database::DB2PartitionAllocator%3463469100C7.protected preserve=yes
      //## end dndb2database::DB2PartitionAllocator%3463469100C7.protected

  private:

    //## Other Operations (specified)
      //## Operation: lockTable%3D36BC4D037A
      DB2PartitionAllocator::State lockTable ();

      //## Operation: select%3D36BC570167
      DB2PartitionAllocator::State select (short int* piKey);

      //## Operation: sync%3D36BC680000
      DB2PartitionAllocator::State sync (short int* piKey, const char* pszPartTable);

      //## Operation: update%3D36BC680119
      DB2PartitionAllocator::State update (short int* piKey, const char* pszPartTable);

    // Additional Private Declarations
      //## begin dndb2database::DB2PartitionAllocator%3463469100C7.private preserve=yes
      //## end dndb2database::DB2PartitionAllocator%3463469100C7.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: State%3D36BCAD033C
      //## begin dndb2database::DB2PartitionAllocator::State%3D36BCAD033C.attr preserve=no  private: State {V} 
      State m_nState;
      //## end dndb2database::DB2PartitionAllocator::State%3D36BCAD033C.attr

      //## Attribute: LastPartitionAllocated%3F01856A009C
      //## begin dndb2database::DB2PartitionAllocator::LastPartitionAllocated%3F01856A009C.attr preserve=no  private: bool {U} false
      bool m_bLastPartitionAllocated;
      //## end dndb2database::DB2PartitionAllocator::LastPartitionAllocated%3F01856A009C.attr

    // Additional Implementation Declarations
      //## begin dndb2database::DB2PartitionAllocator%3463469100C7.implementation preserve=yes
      //## end dndb2database::DB2PartitionAllocator%3463469100C7.implementation

};

//## begin dndb2database::DB2PartitionAllocator%3463469100C7.postscript preserve=yes
//## end dndb2database::DB2PartitionAllocator%3463469100C7.postscript

} // namespace dndb2database

//## begin module%365AD1030387.epilog preserve=yes
using namespace dndb2database;
//## end module%365AD1030387.epilog


#endif
