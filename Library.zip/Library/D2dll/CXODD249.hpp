//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6146FF5800F5.cm preserve=no
//	$Date:   Nov 02 2021 12:42:02  $ $Author:   e3023547  $
//	$Revision:   1.0  $
//## end module%6146FF5800F5.cm

//## begin module%6146FF5800F5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%6146FF5800F5.cp

//## Module: CXOSD249%6146FF5800F5; Package specification
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: D:\Devel\V03.2A.R003\Dn\Server\Library\D2dll\CXODD249.hpp

#ifndef CXOSD249_h
#define CXOSD249_h 1

//## begin module%6146FF5800F5.additionalIncludes preserve=no
//## end module%6146FF5800F5.additionalIncludes

//## begin module%6146FF5800F5.includes preserve=yes
//## end module%6146FF5800F5.includes

#ifndef CXOSST81_h
#include "CXODST81.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class FinancialTransaction;
} // namespace settlement

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class QMRInstitution;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class NPI;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%6146FF5800F5.declarations preserve=no
//## end module%6146FF5800F5.declarations

//## begin module%6146FF5800F5.additionalDeclarations preserve=yes
//## end module%6146FF5800F5.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

//## begin dndb2database::DB2MonthlyCardHolder%6146FE9800AE.preface preserve=yes
//## end dndb2database::DB2MonthlyCardHolder%6146FE9800AE.preface

//## Class: DB2MonthlyCardHolder%6146FE9800AE
//## Category: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
//## Subsystem: D2DLL%3597E8A6029B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%614702D60229;database::Database { -> F}
//## Uses: <unnamed>%614702D90349;monitor::UseCase { -> F}
//## Uses: <unnamed>%61499D980236;settlement::FinancialTransaction { -> F}
//## Uses: <unnamed>%61499EC9001D;configuration::QMRInstitution { -> F}
//## Uses: <unnamed>%61499EDA03C3;reusable::NPI { -> F}

class DllExport DB2MonthlyCardHolder : public settlement::MonthlyCardHolder  //## Inherits: <unnamed>%614702D303BE
{
  //## begin dndb2database::DB2MonthlyCardHolder%6146FE9800AE.initialDeclarations preserve=yes
  //## end dndb2database::DB2MonthlyCardHolder%6146FE9800AE.initialDeclarations

  public:
    //## Constructors (generated)
      DB2MonthlyCardHolder();

    //## Destructor (generated)
      virtual ~DB2MonthlyCardHolder();


    //## Other Operations (specified)
      //## Operation: add%614702EB007E
      virtual bool add (const settlement::FinancialTransaction& hFinancialTransaction);

      //## Operation: commit%6147031901C7
      virtual bool commit ();

    // Additional Public Declarations
      //## begin dndb2database::DB2MonthlyCardHolder%6146FE9800AE.public preserve=yes
      //## end dndb2database::DB2MonthlyCardHolder%6146FE9800AE.public

  protected:
    // Additional Protected Declarations
      //## begin dndb2database::DB2MonthlyCardHolder%6146FE9800AE.protected preserve=yes
      //## end dndb2database::DB2MonthlyCardHolder%6146FE9800AE.protected

  private:
    // Additional Private Declarations
      //## begin dndb2database::DB2MonthlyCardHolder%6146FE9800AE.private preserve=yes
      //## end dndb2database::DB2MonthlyCardHolder%6146FE9800AE.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dndb2database::DB2MonthlyCardHolder%6146FE9800AE.implementation preserve=yes
      //## end dndb2database::DB2MonthlyCardHolder%6146FE9800AE.implementation

};

//## begin dndb2database::DB2MonthlyCardHolder%6146FE9800AE.postscript preserve=yes
//## end dndb2database::DB2MonthlyCardHolder%6146FE9800AE.postscript

} // namespace dndb2database

//## begin module%6146FF5800F5.epilog preserve=yes
//## end module%6146FF5800F5.epilog


#endif
