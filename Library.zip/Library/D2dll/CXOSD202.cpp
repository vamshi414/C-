//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E515974038A.cm preserve=no
//	$Date:   Nov 08 2021 11:21:06  $ $Author:   e3028298  $
//	$Revision:   1.73  $
//## end module%3E515974038A.cm

//## begin module%3E515974038A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3E515974038A.cp

//## Module: CXOSD202%3E515974038A; Package body
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\D2dll\CXOSD202.cpp

//## begin module%3E515974038A.additionalIncludes preserve=no
//## end module%3E515974038A.additionalIncludes

//## begin module%3E515974038A.includes preserve=yes
#ifndef CXOSD248_h
#include "CXODD248.hpp"
#endif
#ifndef CXOSD249_h
#include "CXODD249.hpp"
#endif
#include "CXODST87.hpp"
//## end module%3E515974038A.includes

#ifndef CXOSD220_h
#include "CXODD220.hpp"
#endif
#ifndef CXOSD227_h
#include "CXODD227.hpp"
#endif
#ifndef CXOSD242_h
#include "CXODD242.hpp"
#endif
#ifndef CXOSD221_h
#include "CXODD221.hpp"
#endif
#ifndef CXOSD208_h
#include "CXODD208.hpp"
#endif
#ifndef CXOSD205_h
#include "CXODD205.hpp"
#endif
#ifndef CXOSD245_h
#include "CXODD245.hpp"
#endif
#ifndef CXOSD206_h
#include "CXODD206.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSD247_h
#include "CXODD247.hpp"
#endif
#ifndef CXOSD246_h
#include "CXODD246.hpp"
#endif
#ifndef CXOSD202_h
#include "CXODD202.hpp"
#endif


//## begin module%3E515974038A.declarations preserve=no
//## end module%3E515974038A.declarations

//## begin module%3E515974038A.additionalDeclarations preserve=yes
//## end module%3E515974038A.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

// Class dndb2database::DNDB2DatabaseFactory 

DNDB2DatabaseFactory::DNDB2DatabaseFactory()
  //## begin DNDB2DatabaseFactory::DNDB2DatabaseFactory%3E51579F0109_const.hasinit preserve=no
  //## end DNDB2DatabaseFactory::DNDB2DatabaseFactory%3E51579F0109_const.hasinit
  //## begin DNDB2DatabaseFactory::DNDB2DatabaseFactory%3E51579F0109_const.initialization preserve=yes
  //## end DNDB2DatabaseFactory::DNDB2DatabaseFactory%3E51579F0109_const.initialization
{
  //## begin dndb2database::DNDB2DatabaseFactory::DNDB2DatabaseFactory%3E51579F0109_const.body preserve=yes
   memcpy(m_sID,"D202",4);
   #define CLASSES 12
   const char* pszDB2Class[CLASSES] =
   {
      "AddFinancialCommand",
      "AggregatorMIS",
      "AggregatorPOSRisk",
      "CheckpointTotalsVisitor",
      "Locator",
      "MaintenanceProcedure",
      "PartitionAllocator",
      "PartitionDeallocator",
      "TransactionRemover",
      "MonthlyTotal",
      "MonthlyCardHolder",
      "MISMonthlyCardHolder"
   };
   string strClass;
   for (int m = 0;m < CLASSES;++m)
   {
      strClass = pszDB2Class[m];
      m_hClasses.insert(map<string,int,less<string> >::value_type(strClass,m));
   }
  //## end dndb2database::DNDB2DatabaseFactory::DNDB2DatabaseFactory%3E51579F0109_const.body
}


DNDB2DatabaseFactory::~DNDB2DatabaseFactory()
{
  //## begin dndb2database::DNDB2DatabaseFactory::~DNDB2DatabaseFactory%3E51579F0109_dest.body preserve=yes
   m_hClasses.erase(m_hClasses.begin(),m_hClasses.end());
  //## end dndb2database::DNDB2DatabaseFactory::~DNDB2DatabaseFactory%3E51579F0109_dest.body
}



//## Other Operations (implementation)
Object* DNDB2DatabaseFactory::create (const char* pszClass, const char* pszValue)
{
  //## begin dndb2database::DNDB2DatabaseFactory::create%3E515B330177.body preserve=yes
   string strClass(pszClass);
   map<string,int,less<string> >::iterator pClass = m_hClasses.find(strClass);
   if (pClass == m_hClasses.end())
      return DB2DatabaseFactory::create(pszClass,pszValue);
   Object* pObject = 0;
   string strValue;
   vector<string> hValue;
   vector<string>::iterator p;
   short iMIS = 1;
   switch ((*pClass).second)
   {
      case 0:
         pObject = new UDBAddFinancialCommand();
         break;
      case 1:
         Extract::instance()->getSpec("D202",hValue);
         for (p = hValue.begin();p != hValue.end();++p)
         {
            if ((*p).length() > 4
               && (*p).substr(0,5) == "MIS~2")
               iMIS = 2;
         }
         if (iMIS == 2)
            pObject = new DB2AggregatorMIS2();
         else
            pObject = new DB2AggregatorMIS();
         break;
      case 2:
         pObject = new DB2AggregatorPOSRisk();
         break;
      case 3:
         pObject = new DB2CheckpointTotalsVisitor();
         break;
      case 4:
         pObject = new DB2Locator();
         break;
      case 5:
         pObject = new DB2MaintenanceProcedure();
         break;
      case 6:
         pObject = new DB2PartitionAllocator();
         break;
      case 7:
         pObject = new DB2PartitionDeallocator();
         break;
      case 8:
         pObject = new DB2TransactionRemover();
         break;
      case 9:
         pObject = new DB2MonthlyTotals();
         break;
      case 10:
         pObject = new DB2MonthlyCardHolder();
         break;
      case 11:
         pObject = new MISMonthlyCardHolder();
         break;
   }
   return pObject;
  //## end dndb2database::DNDB2DatabaseFactory::create%3E515B330177.body
}

// Additional Declarations
  //## begin dndb2database::DNDB2DatabaseFactory%3E51579F0109.declarations preserve=yes
  //## end dndb2database::DNDB2DatabaseFactory%3E51579F0109.declarations

} // namespace dndb2database

//## begin module%3E515974038A.epilog preserve=yes
//## end module%3E515974038A.epilog
