static char sqla_program_id[292] = 
{
 '\xac','\x0','\x41','\x45','\x41','\x56','\x41','\x49','\x6d','\x41','\x73','\x34','\x52','\x48','\x49','\x6f','\x30','\x31','\x31','\x31',
 '\x31','\x20','\x32','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x8','\x0','\x44','\x4e','\x53','\x45','\x52','\x56',
 '\x45','\x52','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x8','\x0','\x43','\x58','\x4f','\x53','\x44','\x32','\x34','\x36','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0'
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {'C',' ',' ',' '}};


static const short sqlIsLiteral   = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "CXOSD246.sqx"
//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4091105F02DE.cm preserve=no
//	$Date:   Sep 04 2008 14:10:34  $ $Author:   D02405  $
//	$Revision:   1.22  $
//## end module%4091105F02DE.cm

//## begin module%4091105F02DE.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%4091105F02DE.cp

//## Module: CXOSD246%4091105F02DE; Package body
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXOSD246.sqx

//## begin module%4091105F02DE.additionalIncludes preserve=no
//## end module%4091105F02DE.additionalIncludes

//## begin module%4091105F02DE.includes preserve=yes
#include "CXODIF03.hpp"
#include "CXODIF16.hpp"
#include "CXODST08.hpp"
//## end module%4091105F02DE.includes

#ifndef CXOSST03_h
#include "CXODST03.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
#ifndef CXOSD246_h
#include "CXODD246.hpp"
#endif


//## begin module%4091105F02DE.declarations preserve=no
//## end module%4091105F02DE.declarations

//## begin module%4091105F02DE.additionalDeclarations preserve=yes
#ifdef MVS

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
struct sqlca sqlca;


#line 52 "CXOSD246.sqx"

#else
#include "sqlca.h"
extern struct sqlca sqlca;
#endif

/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 57 "CXOSD246.sqx"

   char AMS_TSTAMP_START[11];
   char AMS_INTERVAL_TYPE[2];
   sqlint32 AMS_T_FIN_ENTITY_ID;
   sqlint32 AMS_T_FIN_ENTITY_ID_2;
   char AMS_T_MIS_MCC[5];
   sqlint32 AMS_CATEGORY_ID;
   double AMS_AMT_TRAN;
   double AMS_AMT_SURCHARGE;
   double AMS_AMT_POS_REIMBURSE;
   double AMS_CASHBACK_AMT;
   sqlint32 AMS_TRAN_COUNT;
   short AMS_PARTITION_KEY;
   short AMS_NULL;
   double AMS_TIME_AT_ISS;
   double AMS_TIME_AT_RQST_SWTCH;
   double AMS_AMT_FEE;
   sqlint32 AMS_SYNC_INTERVAL_NO;
   char AMS_BIN[12];

/*
EXEC SQL END DECLARE SECTION;
*/

#line 76 "CXOSD246.sqx"

//## end module%4091105F02DE.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

// Class dndb2database::DB2AggregatorMIS

DB2AggregatorMIS::DB2AggregatorMIS()
  //## begin DB2AggregatorMIS::DB2AggregatorMIS%409110150213_const.hasinit preserve=no
      : m_lTransaction(-1)
  //## end DB2AggregatorMIS::DB2AggregatorMIS%409110150213_const.hasinit
  //## begin DB2AggregatorMIS::DB2AggregatorMIS%409110150213_const.initialization preserve=yes
  //## end DB2AggregatorMIS::DB2AggregatorMIS%409110150213_const.initialization
{
  //## begin dndb2database::DB2AggregatorMIS::DB2AggregatorMIS%409110150213_const.body preserve=yes
   memcpy(m_sID,"D246",4);
  //## end dndb2database::DB2AggregatorMIS::DB2AggregatorMIS%409110150213_const.body
}


DB2AggregatorMIS::~DB2AggregatorMIS()
{
  //## begin dndb2database::DB2AggregatorMIS::~DB2AggregatorMIS%409110150213_dest.body preserve=yes
  //## end dndb2database::DB2AggregatorMIS::~DB2AggregatorMIS%409110150213_dest.body
}



//## Other Operations (implementation)
int DB2AggregatorMIS::checkResult ()
{
  //## begin dndb2database::DB2AggregatorMIS::checkResult%40911182029F.body preserve=yes
   switch (sqlca.sqlcode)
   {
      case 0:
         UseCase::addItem();
         return 1;
      case 100:
         return 0;
      case -911:
      case -913:
         UseCase::add("DEADLOCK");
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         UseCase::add("CONNECT");
         Database::instance()->setState(Database::DISCONNECTED);
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            Database::instance()->traceSQLError((void*)&sqlca,m_sID,"UPDATE");
            UseCase::addItem();
            return 1;
         }
         else
            UseCase::add("DBERROR");
   }
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca, m_sID,"UPDATE");
   return -1;
  //## end dndb2database::DB2AggregatorMIS::checkResult%40911182029F.body
}

void DB2AggregatorMIS::lockTables ()
{
  //## begin dndb2database::DB2AggregatorMIS::lockTables%42261ED90242.body preserve=yes
   if (m_lTransaction == Database::instance()->transaction())
      return ;
   m_lTransaction = Database::instance()->transaction();
   
/*
EXEC SQL LOCK TABLE T_MIS_TOTAL IN EXCLUSIVE MODE;
*/

{
#line 153 "CXOSD246.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 153 "CXOSD246.sqx"
  sqlacall((unsigned short)24,1,0,0,0L);
#line 153 "CXOSD246.sqx"
  sqlastop(0L);
}

#line 153 "CXOSD246.sqx"

   if (sqlca.sqlcode != 0)
   {
      Database::instance()->traceSQLError((void*)&sqlca,m_sID,"lockTables");
	  if (sqlca.sqlcode == -911)
          Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   }

  //## end dndb2database::DB2AggregatorMIS::lockTables%42261ED90242.body
}

bool DB2AggregatorMIS::tableInsert (bool bSubtractFromTotals)
{
  //## begin dndb2database::DB2AggregatorMIS::tableInsert%4091118703A9.body preserve=yes
   if (Extract::instance()->getCustomCode() == "EFTPOS")
      AMS_PARTITION_KEY = (getINTERVAL_TYPE() == "M" || getINTERVAL_TYPE() == "Y") ? 0 : (int)(PartitionControl::instance()->partitionKey("T_MIS_TOTAL",FinancialTransaction::instance()->getDATE_RECON_ACQ().data(),"MISPARTS"));
   else
      AMS_PARTITION_KEY = (getINTERVAL_TYPE() == "M" || getINTERVAL_TYPE() == "Y") ? 0 : (int)(PartitionControl::instance()->partitionKey("T_MIS_TOTAL",FinancialTransaction::instance()->getTSTAMP_TRANS().data(),"MISPARTS"));
   lockTables();

   AMS_NULL = (AMS_T_FIN_ENTITY_ID_2 == -1) ? -1 : 0;
   
/*
EXEC SQL
      INSERT INTO T_MIS_TOTAL
         (
            TSTAMP_START,
            INTERVAL_TYPE,
            T_FIN_ENTITY_ID,
            T_FIN_ENTITY_ID_2,
            T_MIS_MCC,
            CATEGORY_ID,
            PARTITION_KEY,
            AMT_TRAN,
            AMT_SURCHARGE,
            AMT_POS_REIMBURSE,
            CASHBACK_AMT,
            TRAN_COUNT,
            TIME_AT_ISS,
            TIME_AT_RQST_SWTCH,
            AMT_FEE,
            SYNC_INTERVAL_NO,
            BIN
         )
         VALUES
         (
            :AMS_TSTAMP_START,
            :AMS_INTERVAL_TYPE,
            :AMS_T_FIN_ENTITY_ID,
            :AMS_T_FIN_ENTITY_ID_2 :AMS_NULL,
            :AMS_T_MIS_MCC,
            :AMS_CATEGORY_ID,
            :AMS_PARTITION_KEY,
            :AMS_AMT_TRAN,
            :AMS_AMT_SURCHARGE,
            :AMS_AMT_POS_REIMBURSE,
            :AMS_CASHBACK_AMT,
            :AMS_TRAN_COUNT,
            :AMS_TIME_AT_ISS,
            :AMS_TIME_AT_RQST_SWTCH,
            :AMS_AMT_FEE,
            :AMS_SYNC_INTERVAL_NO,
            :AMS_BIN
         );
*/

/*
SQL0206N  "BIN" is not valid in the context where it is 
used.  SQLSTATE=42703

*/

{
#line 214 "CXOSD246.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 214 "CXOSD246.sqx"
  sqlaaloc(2,17,1,0L);
    {
      struct sqla_setdata_list sql_setdlist[17];
#line 214 "CXOSD246.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 11;
#line 214 "CXOSD246.sqx"
      sql_setdlist[0].sqldata = (void*)AMS_TSTAMP_START;
#line 214 "CXOSD246.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 2;
#line 214 "CXOSD246.sqx"
      sql_setdlist[1].sqldata = (void*)AMS_INTERVAL_TYPE;
#line 214 "CXOSD246.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[2].sqltype = 496; sql_setdlist[2].sqllen = 4;
#line 214 "CXOSD246.sqx"
      sql_setdlist[2].sqldata = (void*)&AMS_T_FIN_ENTITY_ID;
#line 214 "CXOSD246.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[3].sqltype = 497; sql_setdlist[3].sqllen = 4;
#line 214 "CXOSD246.sqx"
      sql_setdlist[3].sqldata = (void*)&AMS_T_FIN_ENTITY_ID_2;
#line 214 "CXOSD246.sqx"
      sql_setdlist[3].sqlind = (short*)&AMS_NULL;
#line 214 "CXOSD246.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 5;
#line 214 "CXOSD246.sqx"
      sql_setdlist[4].sqldata = (void*)AMS_T_MIS_MCC;
#line 214 "CXOSD246.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[5].sqltype = 496; sql_setdlist[5].sqllen = 4;
#line 214 "CXOSD246.sqx"
      sql_setdlist[5].sqldata = (void*)&AMS_CATEGORY_ID;
#line 214 "CXOSD246.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[6].sqltype = 500; sql_setdlist[6].sqllen = 2;
#line 214 "CXOSD246.sqx"
      sql_setdlist[6].sqldata = (void*)&AMS_PARTITION_KEY;
#line 214 "CXOSD246.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[7].sqltype = 480; sql_setdlist[7].sqllen = 8;
#line 214 "CXOSD246.sqx"
      sql_setdlist[7].sqldata = (void*)&AMS_AMT_TRAN;
#line 214 "CXOSD246.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[8].sqltype = 480; sql_setdlist[8].sqllen = 8;
#line 214 "CXOSD246.sqx"
      sql_setdlist[8].sqldata = (void*)&AMS_AMT_SURCHARGE;
#line 214 "CXOSD246.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[9].sqltype = 480; sql_setdlist[9].sqllen = 8;
#line 214 "CXOSD246.sqx"
      sql_setdlist[9].sqldata = (void*)&AMS_AMT_POS_REIMBURSE;
#line 214 "CXOSD246.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[10].sqltype = 480; sql_setdlist[10].sqllen = 8;
#line 214 "CXOSD246.sqx"
      sql_setdlist[10].sqldata = (void*)&AMS_CASHBACK_AMT;
#line 214 "CXOSD246.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[11].sqltype = 496; sql_setdlist[11].sqllen = 4;
#line 214 "CXOSD246.sqx"
      sql_setdlist[11].sqldata = (void*)&AMS_TRAN_COUNT;
#line 214 "CXOSD246.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[12].sqltype = 480; sql_setdlist[12].sqllen = 8;
#line 214 "CXOSD246.sqx"
      sql_setdlist[12].sqldata = (void*)&AMS_TIME_AT_ISS;
#line 214 "CXOSD246.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[13].sqltype = 480; sql_setdlist[13].sqllen = 8;
#line 214 "CXOSD246.sqx"
      sql_setdlist[13].sqldata = (void*)&AMS_TIME_AT_RQST_SWTCH;
#line 214 "CXOSD246.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[14].sqltype = 480; sql_setdlist[14].sqllen = 8;
#line 214 "CXOSD246.sqx"
      sql_setdlist[14].sqldata = (void*)&AMS_AMT_FEE;
#line 214 "CXOSD246.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[15].sqltype = 496; sql_setdlist[15].sqllen = 4;
#line 214 "CXOSD246.sqx"
      sql_setdlist[15].sqldata = (void*)&AMS_SYNC_INTERVAL_NO;
#line 214 "CXOSD246.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 12;
#line 214 "CXOSD246.sqx"
      sql_setdlist[16].sqldata = (void*)AMS_BIN;
#line 214 "CXOSD246.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 214 "CXOSD246.sqx"
      sqlasetdata(2,0,17,sql_setdlist,0L,0L);
    }
#line 214 "CXOSD246.sqx"
  sqlacall((unsigned short)24,2,2,0,0L);
#line 214 "CXOSD246.sqx"
  sqlastop(0L);
}

#line 214 "CXOSD246.sqx"

   if (checkResult() == -1)
   {
      char szTemp[5 * PERCENTLD + 7 * PERCENTF + 3 * PERCENTS];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_MIS_TOTAL %s %ld %ld %s %ld %.0f %.0f %.0f %.0f %ld %.0f %.0f %.0f %ld %s",
         AMS_TSTAMP_START,AMS_T_FIN_ENTITY_ID,AMS_T_FIN_ENTITY_ID_2,AMS_T_MIS_MCC,AMS_CATEGORY_ID,AMS_AMT_TRAN,AMS_AMT_SURCHARGE,
         AMS_AMT_POS_REIMBURSE,AMS_CASHBACK_AMT,AMS_TRAN_COUNT,AMS_TIME_AT_ISS,AMS_TIME_AT_RQST_SWTCH,AMS_AMT_FEE,AMS_SYNC_INTERVAL_NO,AMS_BIN);
      Trace::put(szTemp);
      return false;
   }
   return true;
  //## end dndb2database::DB2AggregatorMIS::tableInsert%4091118703A9.body
}

int DB2AggregatorMIS::tableUpdate (bool bSubtractFromTotals)
{
  //## begin dndb2database::DB2AggregatorMIS::tableUpdate%4091119400AB.body preserve=yes
   memcpy(AMS_TSTAMP_START,getTSTAMP_START().data(),min((size_t)getTSTAMP_START().length(),sizeof(AMS_TSTAMP_START)-1));
   AMS_TSTAMP_START[min((size_t)getTSTAMP_START().length(),sizeof(AMS_TSTAMP_START)-1)] = '\0';
   memcpy(AMS_INTERVAL_TYPE,getINTERVAL_TYPE().data(),min((size_t)getINTERVAL_TYPE().length(),sizeof(AMS_INTERVAL_TYPE)-1));
   AMS_INTERVAL_TYPE[min((size_t)getINTERVAL_TYPE().length(),sizeof(AMS_INTERVAL_TYPE)-1)] = '\0';
   memcpy(AMS_BIN,getBIN().data(),min((size_t)getBIN().length(),sizeof(AMS_BIN)-1));
   AMS_BIN[min((size_t)getBIN().length(),sizeof(AMS_BIN)-1)] = '\0';
   RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(0),getENTITY_ID(0),(int*)&AMS_T_FIN_ENTITY_ID);
   if (getENTITY_ID(1) != "~NULL!")
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(1),getENTITY_ID(1),(int*)&AMS_T_FIN_ENTITY_ID_2);
   else
      AMS_T_FIN_ENTITY_ID_2 = -1;
   memcpy(AMS_T_MIS_MCC,getT_MIS_MCC().data(),min((size_t)getT_MIS_MCC().length(),sizeof(AMS_T_MIS_MCC)-1));
   AMS_T_MIS_MCC[min((size_t)getT_MIS_MCC().length(),sizeof(AMS_T_MIS_MCC)-1)] = '\0';
   AMS_SYNC_INTERVAL_NO = getSYNC_INTERVAL_NO();
   AMS_CATEGORY_ID = getCATEGORY_ID();
   AMS_AMT_TRAN = (bSubtractFromTotals) ? 0 - getAMT_TRAN() : getAMT_TRAN();
   AMS_AMT_SURCHARGE = (bSubtractFromTotals) ? 0 - getAMT_SURCHARGE() : getAMT_SURCHARGE();
   AMS_AMT_POS_REIMBURSE = (bSubtractFromTotals) ? 0 - getAMT_POS_REIMBURSE() : getAMT_POS_REIMBURSE();
   AMS_CASHBACK_AMT = (bSubtractFromTotals) ? 0 - getCASHBACK_AMT() : getCASHBACK_AMT();
   AMS_TRAN_COUNT = (bSubtractFromTotals) ? -1 : 1;
   AMS_TIME_AT_ISS = (bSubtractFromTotals) ? 0 - (double)getTIME_AT_ISS() : (double)getTIME_AT_ISS();
   AMS_TIME_AT_RQST_SWTCH = (bSubtractFromTotals) ? 0 - (double)getTIME_AT_RQST_SWTCH() : (double)getTIME_AT_RQST_SWTCH();
   AMS_AMT_FEE = (bSubtractFromTotals) ? 0 - getAMT_FEE() : getAMT_FEE();
   lockTables();
   if (AMS_T_FIN_ENTITY_ID_2 == -1)
      
/*
EXEC SQL
         UPDATE T_MIS_TOTAL
            SET
               AMT_TRAN = AMT_TRAN + :AMS_AMT_TRAN,
               AMT_SURCHARGE = AMT_SURCHARGE + :AMS_AMT_SURCHARGE,
               AMT_POS_REIMBURSE = AMT_POS_REIMBURSE + :AMS_AMT_POS_REIMBURSE,
               CASHBACK_AMT = CASHBACK_AMT + :AMS_CASHBACK_AMT,
               TRAN_COUNT = TRAN_COUNT + :AMS_TRAN_COUNT,
               TIME_AT_ISS = TIME_AT_ISS + :AMS_TIME_AT_ISS,
               TIME_AT_RQST_SWTCH = TIME_AT_RQST_SWTCH + :AMS_TIME_AT_RQST_SWTCH,
               AMT_FEE = AMT_FEE + :AMS_AMT_FEE
            WHERE
               TSTAMP_START = :AMS_TSTAMP_START
               AND T_FIN_ENTITY_ID = :AMS_T_FIN_ENTITY_ID
               AND T_FIN_ENTITY_ID_2 IS NULL
               AND T_MIS_MCC = :AMS_T_MIS_MCC
               AND CATEGORY_ID = :AMS_CATEGORY_ID
               AND INTERVAL_TYPE = :AMS_INTERVAL_TYPE
               AND SYNC_INTERVAL_NO = :AMS_SYNC_INTERVAL_NO
               AND BIN = :AMS_BIN;
*/

/*
SQL0206N  "BIN" is not valid in the context where it is 
used.  SQLSTATE=42703

*/

{
#line 275 "CXOSD246.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 275 "CXOSD246.sqx"
  sqlaaloc(2,15,2,0L);
    {
      struct sqla_setdata_list sql_setdlist[15];
#line 275 "CXOSD246.sqx"
      sql_setdlist[0].sqltype = 480; sql_setdlist[0].sqllen = 8;
#line 275 "CXOSD246.sqx"
      sql_setdlist[0].sqldata = (void*)&AMS_AMT_TRAN;
#line 275 "CXOSD246.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[1].sqltype = 480; sql_setdlist[1].sqllen = 8;
#line 275 "CXOSD246.sqx"
      sql_setdlist[1].sqldata = (void*)&AMS_AMT_SURCHARGE;
#line 275 "CXOSD246.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[2].sqltype = 480; sql_setdlist[2].sqllen = 8;
#line 275 "CXOSD246.sqx"
      sql_setdlist[2].sqldata = (void*)&AMS_AMT_POS_REIMBURSE;
#line 275 "CXOSD246.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[3].sqltype = 480; sql_setdlist[3].sqllen = 8;
#line 275 "CXOSD246.sqx"
      sql_setdlist[3].sqldata = (void*)&AMS_CASHBACK_AMT;
#line 275 "CXOSD246.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[4].sqltype = 496; sql_setdlist[4].sqllen = 4;
#line 275 "CXOSD246.sqx"
      sql_setdlist[4].sqldata = (void*)&AMS_TRAN_COUNT;
#line 275 "CXOSD246.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[5].sqltype = 480; sql_setdlist[5].sqllen = 8;
#line 275 "CXOSD246.sqx"
      sql_setdlist[5].sqldata = (void*)&AMS_TIME_AT_ISS;
#line 275 "CXOSD246.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[6].sqltype = 480; sql_setdlist[6].sqllen = 8;
#line 275 "CXOSD246.sqx"
      sql_setdlist[6].sqldata = (void*)&AMS_TIME_AT_RQST_SWTCH;
#line 275 "CXOSD246.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[7].sqltype = 480; sql_setdlist[7].sqllen = 8;
#line 275 "CXOSD246.sqx"
      sql_setdlist[7].sqldata = (void*)&AMS_AMT_FEE;
#line 275 "CXOSD246.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 11;
#line 275 "CXOSD246.sqx"
      sql_setdlist[8].sqldata = (void*)AMS_TSTAMP_START;
#line 275 "CXOSD246.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[9].sqltype = 496; sql_setdlist[9].sqllen = 4;
#line 275 "CXOSD246.sqx"
      sql_setdlist[9].sqldata = (void*)&AMS_T_FIN_ENTITY_ID;
#line 275 "CXOSD246.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[10].sqltype = 460; sql_setdlist[10].sqllen = 5;
#line 275 "CXOSD246.sqx"
      sql_setdlist[10].sqldata = (void*)AMS_T_MIS_MCC;
#line 275 "CXOSD246.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[11].sqltype = 496; sql_setdlist[11].sqllen = 4;
#line 275 "CXOSD246.sqx"
      sql_setdlist[11].sqldata = (void*)&AMS_CATEGORY_ID;
#line 275 "CXOSD246.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 2;
#line 275 "CXOSD246.sqx"
      sql_setdlist[12].sqldata = (void*)AMS_INTERVAL_TYPE;
#line 275 "CXOSD246.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[13].sqltype = 496; sql_setdlist[13].sqllen = 4;
#line 275 "CXOSD246.sqx"
      sql_setdlist[13].sqldata = (void*)&AMS_SYNC_INTERVAL_NO;
#line 275 "CXOSD246.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 12;
#line 275 "CXOSD246.sqx"
      sql_setdlist[14].sqldata = (void*)AMS_BIN;
#line 275 "CXOSD246.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 275 "CXOSD246.sqx"
      sqlasetdata(2,0,15,sql_setdlist,0L,0L);
    }
#line 275 "CXOSD246.sqx"
  sqlacall((unsigned short)24,3,2,0,0L);
#line 275 "CXOSD246.sqx"
  sqlastop(0L);
}

#line 275 "CXOSD246.sqx"

   else
      
/*
EXEC SQL
         UPDATE T_MIS_TOTAL
            SET
               AMT_TRAN = AMT_TRAN + :AMS_AMT_TRAN,
               AMT_SURCHARGE = AMT_SURCHARGE + :AMS_AMT_SURCHARGE,
               AMT_POS_REIMBURSE = AMT_POS_REIMBURSE + :AMS_AMT_POS_REIMBURSE,
               CASHBACK_AMT = CASHBACK_AMT + :AMS_CASHBACK_AMT,
               TRAN_COUNT = TRAN_COUNT + :AMS_TRAN_COUNT,
               TIME_AT_ISS = TIME_AT_ISS + :AMS_TIME_AT_ISS,
               TIME_AT_RQST_SWTCH = TIME_AT_RQST_SWTCH + :AMS_TIME_AT_RQST_SWTCH,
               AMT_FEE = AMT_FEE + :AMS_AMT_FEE
            WHERE
               TSTAMP_START = :AMS_TSTAMP_START
               AND T_FIN_ENTITY_ID = :AMS_T_FIN_ENTITY_ID
               AND T_FIN_ENTITY_ID_2 = :AMS_T_FIN_ENTITY_ID_2
               AND T_MIS_MCC = :AMS_T_MIS_MCC
               AND CATEGORY_ID = :AMS_CATEGORY_ID
               AND INTERVAL_TYPE = :AMS_INTERVAL_TYPE
               AND SYNC_INTERVAL_NO = :AMS_SYNC_INTERVAL_NO
               AND BIN = :AMS_BIN;
*/

/*
SQL0206N  "BIN" is not valid in the context where it is 
used.  SQLSTATE=42703

*/

{
#line 296 "CXOSD246.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 296 "CXOSD246.sqx"
  sqlaaloc(2,16,3,0L);
    {
      struct sqla_setdata_list sql_setdlist[16];
#line 296 "CXOSD246.sqx"
      sql_setdlist[0].sqltype = 480; sql_setdlist[0].sqllen = 8;
#line 296 "CXOSD246.sqx"
      sql_setdlist[0].sqldata = (void*)&AMS_AMT_TRAN;
#line 296 "CXOSD246.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[1].sqltype = 480; sql_setdlist[1].sqllen = 8;
#line 296 "CXOSD246.sqx"
      sql_setdlist[1].sqldata = (void*)&AMS_AMT_SURCHARGE;
#line 296 "CXOSD246.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[2].sqltype = 480; sql_setdlist[2].sqllen = 8;
#line 296 "CXOSD246.sqx"
      sql_setdlist[2].sqldata = (void*)&AMS_AMT_POS_REIMBURSE;
#line 296 "CXOSD246.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[3].sqltype = 480; sql_setdlist[3].sqllen = 8;
#line 296 "CXOSD246.sqx"
      sql_setdlist[3].sqldata = (void*)&AMS_CASHBACK_AMT;
#line 296 "CXOSD246.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[4].sqltype = 496; sql_setdlist[4].sqllen = 4;
#line 296 "CXOSD246.sqx"
      sql_setdlist[4].sqldata = (void*)&AMS_TRAN_COUNT;
#line 296 "CXOSD246.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[5].sqltype = 480; sql_setdlist[5].sqllen = 8;
#line 296 "CXOSD246.sqx"
      sql_setdlist[5].sqldata = (void*)&AMS_TIME_AT_ISS;
#line 296 "CXOSD246.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[6].sqltype = 480; sql_setdlist[6].sqllen = 8;
#line 296 "CXOSD246.sqx"
      sql_setdlist[6].sqldata = (void*)&AMS_TIME_AT_RQST_SWTCH;
#line 296 "CXOSD246.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[7].sqltype = 480; sql_setdlist[7].sqllen = 8;
#line 296 "CXOSD246.sqx"
      sql_setdlist[7].sqldata = (void*)&AMS_AMT_FEE;
#line 296 "CXOSD246.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 11;
#line 296 "CXOSD246.sqx"
      sql_setdlist[8].sqldata = (void*)AMS_TSTAMP_START;
#line 296 "CXOSD246.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[9].sqltype = 496; sql_setdlist[9].sqllen = 4;
#line 296 "CXOSD246.sqx"
      sql_setdlist[9].sqldata = (void*)&AMS_T_FIN_ENTITY_ID;
#line 296 "CXOSD246.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[10].sqltype = 496; sql_setdlist[10].sqllen = 4;
#line 296 "CXOSD246.sqx"
      sql_setdlist[10].sqldata = (void*)&AMS_T_FIN_ENTITY_ID_2;
#line 296 "CXOSD246.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 5;
#line 296 "CXOSD246.sqx"
      sql_setdlist[11].sqldata = (void*)AMS_T_MIS_MCC;
#line 296 "CXOSD246.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[12].sqltype = 496; sql_setdlist[12].sqllen = 4;
#line 296 "CXOSD246.sqx"
      sql_setdlist[12].sqldata = (void*)&AMS_CATEGORY_ID;
#line 296 "CXOSD246.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 2;
#line 296 "CXOSD246.sqx"
      sql_setdlist[13].sqldata = (void*)AMS_INTERVAL_TYPE;
#line 296 "CXOSD246.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[14].sqltype = 496; sql_setdlist[14].sqllen = 4;
#line 296 "CXOSD246.sqx"
      sql_setdlist[14].sqldata = (void*)&AMS_SYNC_INTERVAL_NO;
#line 296 "CXOSD246.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 12;
#line 296 "CXOSD246.sqx"
      sql_setdlist[15].sqldata = (void*)AMS_BIN;
#line 296 "CXOSD246.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 296 "CXOSD246.sqx"
      sqlasetdata(2,0,16,sql_setdlist,0L,0L);
    }
#line 296 "CXOSD246.sqx"
  sqlacall((unsigned short)24,4,2,0,0L);
#line 296 "CXOSD246.sqx"
  sqlastop(0L);
}

#line 296 "CXOSD246.sqx"


   int iRC = checkResult();
   if (iRC == -1)
   {
      char szTemp[3 * PERCENTS + 5 * PERCENTD + 7 * PERCENTF];
      snprintf(szTemp,sizeof(szTemp),"UPDATE T_MIS_TOTAL %s %ld %ld %s %ld %.0f %.0f %.0f %.0f %ld %.0f %.0f %.0f %ld %s",
         AMS_TSTAMP_START,AMS_T_FIN_ENTITY_ID,AMS_T_FIN_ENTITY_ID_2,AMS_T_MIS_MCC,AMS_CATEGORY_ID,AMS_AMT_TRAN,AMS_AMT_SURCHARGE,
         AMS_AMT_POS_REIMBURSE,AMS_CASHBACK_AMT,AMS_TRAN_COUNT,AMS_TIME_AT_ISS,AMS_TIME_AT_RQST_SWTCH,AMS_AMT_FEE,AMS_SYNC_INTERVAL_NO,AMS_BIN);
      Trace::put(szTemp);
      return iRC;
   }
   return iRC;
  //## end dndb2database::DB2AggregatorMIS::tableUpdate%4091119400AB.body
}

// Additional Declarations
  //## begin dndb2database::DB2AggregatorMIS%409110150213.declarations preserve=yes
  //## end dndb2database::DB2AggregatorMIS%409110150213.declarations

} // namespace dndb2database

//## begin module%4091105F02DE.epilog preserve=yes
//## end module%4091105F02DE.epilog
