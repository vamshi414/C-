static char sqla_program_id[292] = 
{
 '\xac','\x0','\x41','\x45','\x41','\x56','\x41','\x49','\x6b','\x41','\x46','\x35','\x52','\x48','\x49','\x6f','\x30','\x31','\x31','\x31',
 '\x31','\x20','\x32','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x8','\x0','\x44','\x4e','\x53','\x45','\x52','\x56',
 '\x45','\x52','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x8','\x0','\x43','\x58','\x4f','\x53','\x44','\x32','\x34','\x38','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0'
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {'C',' ',' ',' '}};


static const short sqlIsLiteral   = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "CXOSD248.sqx"
//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6146FE1502D2.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%6146FE1502D2.cm

//## begin module%6146FE1502D2.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%6146FE1502D2.cp

//## Module: CXOSD248%6146FE1502D2; Package body
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: D:\Devel\V03.2A.R003\Dn\Server\Library\D2dll\CXOSD248.sqx

//## begin module%6146FE1502D2.additionalIncludes preserve=no
//## end module%6146FE1502D2.additionalIncludes

//## begin module%6146FE1502D2.includes preserve=yes
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
//## end module%6146FE1502D2.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSD248_h
#include "CXODD248.hpp"
#endif


//## begin module%6146FE1502D2.declarations preserve=no
//## end module%6146FE1502D2.declarations

//## begin module%6146FE1502D2.additionalDeclarations preserve=yes
#ifdef MVS

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
struct sqlca sqlca;


#line 46 "CXOSD248.sqx"

#else
#include "sqlca.h"
extern struct sqlca sqlca;
#endif

/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 51 "CXOSD248.sqx"

       char QMR_ATTRIBUTES[32];
       char QMR_YEAR_MONTH[512][7];
       char QMR_INST_ID[512][12];
       char QMR_ENTITY_ROLE[512][2];
       char QMR_BIN[512][12];
       char QMR_TOKEN_REQUESTOR_ID[512][12];
       char QMR_NETWORK_ID[512][4];
       char QMR_FUNCTION_TYPE[512][3];
       char QMR_ACCT_TYPES_ISS[512][5];
       char QMR_MSG_CLASS[512][2];
       char QMR_PRE_AUTH[512][2];
       char QMR_TERM_CLASS[512][3];
       char QMR_COUNTRY_ISS_INST[512][4];
       char QMR_COUNTRY_ACQ_INST[512][4];
       char QMR_ONUS_FLG[512][2];
       char QMR_AUTHENTICATED[512][2];
       char QMR_POS_CRD_DAT_IN_MOD[512][2];
       char QMR_CUR_TRAN[512][4];
       char QMR_MERCH_TYPE[512][5];
       char QMR_NETWORK_TRAN_TYPE[512][3];
       char QMR_CUR_CASHBACK[512][4];
       double QMR_AMT_TRAN[512];
       sqlint32 QMR_TRAN_COUNT[512];
       double QMR_AMT_CASHBACK[512];
       sqlint32 QMR_CASHBACK_COUNT[512];
       sqlint32 QMR_ROWS;
       struct
       {
          short length;
          char data[3072];
       } QMR_MERGE;

/*
EXEC SQL END DECLARE SECTION;
*/

#line 83 "CXOSD248.sqx"

//## end module%6146FE1502D2.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

// Class dndb2database::DB2MonthlyTotals 

DB2MonthlyTotals::DB2MonthlyTotals()
  //## begin DB2MonthlyTotals::DB2MonthlyTotals%6146FC1E036D_const.hasinit preserve=no
  //## end DB2MonthlyTotals::DB2MonthlyTotals%6146FC1E036D_const.hasinit
  //## begin DB2MonthlyTotals::DB2MonthlyTotals%6146FC1E036D_const.initialization preserve=yes
  //## end DB2MonthlyTotals::DB2MonthlyTotals%6146FC1E036D_const.initialization
{
  //## begin dndb2database::DB2MonthlyTotals::DB2MonthlyTotals%6146FC1E036D_const.body preserve=yes
   memcpy(m_sID,"D248",4);
#ifdef MVS
   strcpy(QMR_ATTRIBUTES,"FOR MULTIPLE ROWS");
#endif
   string strQualifier(Database::instance()->qualifier());
   QMR_ROWS = 0;
   memcpy(QMR_MERGE.data,"MERGE INTO ",11);
   memcpy(QMR_MERGE.data + 11,strQualifier.data(),strQualifier.length());
   strcpy(QMR_MERGE.data + 11 + strQualifier.length(),".T_QMR_TOTAL AS A USING"
   " (VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
#ifdef MVS
      " FOR ? ROWS"
#endif
      ") AS B"
      "(YEAR_MONTH,"
     "INST_ID,ENTITY_ROLE,BIN,TOKEN_REQUESTOR_ID,NETWORK_ID,FUNCTION_TYPE,ACCT_TYPES_ISS,"
     "MSG_CLASS,PRE_AUTH,TERM_CLASS,COUNTRY_ISS_INST,COUNTRY_ACQ_INST,ONUS_FLG,"
     "AUTHENTICATED,POS_CRD_DAT_IN_MOD,CUR_TRAN,MERCH_TYPE,NETWORK_TRAN_TYPE,CUR_CASHBACK,"
     "AMT_TRAN,TRAN_COUNT,CASHBACK_COUNT,AMT_CASHBACK) ON "
     "A.YEAR_MONTH = B.YEAR_MONTH AND A.INST_ID = B.INST_ID AND A.ENTITY_ROLE = B.ENTITY_ROLE AND A.BIN = B.BIN "
     "AND A.TOKEN_REQUESTOR_ID = B.TOKEN_REQUESTOR_ID AND A.NETWORK_ID = B.NETWORK_ID AND A.FUNCTION_TYPE = B.FUNCTION_TYPE AND "
     "A.ACCT_TYPES_ISS = B.ACCT_TYPES_ISS AND A.MSG_CLASS = B.MSG_CLASS AND A.PRE_AUTH = B.PRE_AUTH AND A.TERM_CLASS = B.TERM_CLASS  "
     "AND A.COUNTRY_ISS_INST = B.COUNTRY_ISS_INST  AND A.COUNTRY_ACQ_INST = B.COUNTRY_ACQ_INST AND "
     "A.ONUS_FLG = B.ONUS_FLG  AND A.AUTHENTICATED = B.AUTHENTICATED AND A.POS_CRD_DAT_IN_MOD = B.POS_CRD_DAT_IN_MOD AND "
     "A.CUR_TRAN = B.CUR_TRAN AND A.MERCH_TYPE = B.MERCH_TYPE AND A.NETWORK_TRAN_TYPE = B.NETWORK_TRAN_TYPE AND A.CUR_CASHBACK = B.CUR_CASHBACK"
      " WHEN NOT MATCHED THEN INSERT "
      "(YEAR_MONTH,"
     "INST_ID,ENTITY_ROLE,BIN,TOKEN_REQUESTOR_ID,NETWORK_ID,FUNCTION_TYPE,ACCT_TYPES_ISS,"
     "MSG_CLASS,PRE_AUTH,TERM_CLASS,COUNTRY_ISS_INST,COUNTRY_ACQ_INST,ONUS_FLG,"
     "AUTHENTICATED,POS_CRD_DAT_IN_MOD,CUR_TRAN,MERCH_TYPE,NETWORK_TRAN_TYPE,CUR_CASHBACK,"
     "AMT_TRAN,TRAN_COUNT,CASHBACK_COUNT,AMT_CASHBACK) VALUES"
     "(B.YEAR_MONTH,"
     "B.INST_ID,B.ENTITY_ROLE,B.BIN,B.TOKEN_REQUESTOR_ID,B.NETWORK_ID,B.FUNCTION_TYPE,B.ACCT_TYPES_ISS,"
     "B.MSG_CLASS,B.PRE_AUTH,B.TERM_CLASS,B.COUNTRY_ISS_INST,B.COUNTRY_ACQ_INST,B.ONUS_FLG,"
     "B.AUTHENTICATED,B.POS_CRD_DAT_IN_MOD,B.CUR_TRAN,B.MERCH_TYPE,B.NETWORK_TRAN_TYPE,B.CUR_CASHBACK,"
     "B.AMT_TRAN,B.TRAN_COUNT,B.CASHBACK_COUNT,B.AMT_CASHBACK)" 
      " WHEN MATCHED THEN UPDATE SET "
      " A.AMT_TRAN = A.AMT_TRAN + B.AMT_TRAN , "
      " A.TRAN_COUNT = A.TRAN_COUNT + B.TRAN_COUNT,"
      " A.CASHBACK_COUNT = A.CASHBACK_COUNT + B.CASHBACK_COUNT ,"
      " A.AMT_CASHBACK = A.AMT_CASHBACK + B.AMT_CASHBACK"
#ifdef MVS
      " NOT ATOMIC CONTINUE ON SQLEXCEPTION"
#endif
   );
   QMR_MERGE.length = strlen(QMR_MERGE.data);
  //## end dndb2database::DB2MonthlyTotals::DB2MonthlyTotals%6146FC1E036D_const.body
}


DB2MonthlyTotals::~DB2MonthlyTotals()
{
  //## begin dndb2database::DB2MonthlyTotals::~DB2MonthlyTotals%6146FC1E036D_dest.body preserve=yes
  //## end dndb2database::DB2MonthlyTotals::~DB2MonthlyTotals%6146FC1E036D_dest.body
}



//## Other Operations (implementation)
bool DB2MonthlyTotals::commit ()
{
  //## begin dndb2database::DB2MonthlyTotals::commit%61470144039F.body preserve=yes
   UseCase hUseCase("TOTALS","## D248 COMMIT QMR");
   bool b = true;
   if (QMR_ROWS > 0)
   {
   Trace::put("BEFORE PREPARE",-1,true);
   Trace::put(QMR_MERGE.data,QMR_MERGE.length,true);
#ifdef MVS
      XXEC SQL PREPARE MERGE1
         ATTRIBUTES :QMR_ATTRIBUTES
         FROM :QMR_MERGE;
#else
      
/*
EXEC SQL PREPARE MERGE1 FROM :QMR_MERGE;
*/

{
#line 174 "CXOSD248.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 174 "CXOSD248.sqx"
  sqlastls( *(unsigned short *)&QMR_MERGE,(const char*)&QMR_MERGE+2,0L);
#line 174 "CXOSD248.sqx"
  sqlacall((unsigned short)27,1,0,0,0L);
#line 174 "CXOSD248.sqx"
  sqlastop(0L);
}

#line 174 "CXOSD248.sqx"

#endif
      switch (sqlca.sqlcode)
      {
         case 0:
            break;
         case -911:
         case -913:
            UseCase::add("DEADLOCK");
            b = false;
            break;
         case -900:
         case -923:
         case -924:
         case -991:
         case -1024:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            b = false;
            break;
         default:
            if (sqlca.sqlcode > 0)
               Database::instance()->traceSQLError((void*)&sqlca,m_sID,"PREPARE");
            else
            {
               UseCase::add("DBERROR");
               b = false;
            }
      }
      char szTemp[5 * PERCENTLD + 7 * PERCENTF + 2 * PERCENTS];
      for(int i=0;i < QMR_ROWS; i++)
      {
            snprintf(szTemp, sizeof(szTemp), "MERGE INTO %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %f %d %d %f",
          QMR_YEAR_MONTH[i],QMR_INST_ID[i],QMR_ENTITY_ROLE[i],QMR_BIN[i],QMR_TOKEN_REQUESTOR_ID[i],QMR_NETWORK_ID[i],QMR_FUNCTION_TYPE[i],
          QMR_ACCT_TYPES_ISS[i],QMR_MSG_CLASS[i],QMR_PRE_AUTH[i],QMR_TERM_CLASS[i],QMR_COUNTRY_ISS_INST[i],QMR_COUNTRY_ACQ_INST[i],
          QMR_ONUS_FLG[i],QMR_AUTHENTICATED[i],QMR_POS_CRD_DAT_IN_MOD[i],QMR_CUR_TRAN[i],QMR_MERCH_TYPE[i],QMR_NETWORK_TRAN_TYPE[i],
          QMR_CUR_CASHBACK[i],QMR_AMT_TRAN[i],QMR_TRAN_COUNT[i],QMR_CASHBACK_COUNT[i],QMR_AMT_CASHBACK[i]);
          Trace::put(szTemp,strlen(szTemp),true);
      }
      if (!b)
      {
         QMR_ROWS = 0;
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"PREPARE");
         return UseCase::setSuccess(false);
      }
#ifdef MVS
   Trace::put("BEFORE EXECUTE",-1,true);
   Trace::put(QMR_MERGE.data,QMR_MERGE.length,true);
      XXEC SQL
         EXECUTE MERGE1
            USING
              :QMR_YEAR_MONTH,
              :QMR_INST_ID,
              :QMR_ENTITY_ROLE,
              :QMR_BIN,
              :QMR_TOKEN_REQUESTOR_ID,
              :QMR_NETWORK_ID,
              :QMR_FUNCTION_TYPE,
              :QMR_ACCT_TYPES_ISS,
              :QMR_MSG_CLASS,
              :QMR_PRE_AUTH,
              :QMR_TERM_CLASS,
              :QMR_COUNTRY_ISS_INST,
              :QMR_COUNTRY_ACQ_INST,
              :QMR_ONUS_FLG,
              :QMR_AUTHENTICATED,
              :QMR_POS_CRD_DAT_IN_MOD,
              :QMR_CUR_TRAN,
              :QMR_MERCH_TYPE,
              :QMR_NETWORK_TRAN_TYPE,
              :QMR_CUR_CASHBACK,
              :QMR_AMT_TRAN,
              :QMR_TRAN_COUNT,
              :QMR_CASHBACK_COUNT,
              :QMR_AMT_CASHBACK,
              :QMR_ROWS;
#else
      
/*
EXEC SQL
         EXECUTE MERGE1
            USING
              :QMR_YEAR_MONTH,
              :QMR_INST_ID,
              :QMR_ENTITY_ROLE,
              :QMR_BIN,
              :QMR_TOKEN_REQUESTOR_ID,
              :QMR_NETWORK_ID,
              :QMR_FUNCTION_TYPE,
              :QMR_ACCT_TYPES_ISS,
              :QMR_MSG_CLASS,
              :QMR_PRE_AUTH,
              :QMR_TERM_CLASS,
              :QMR_COUNTRY_ISS_INST,
              :QMR_COUNTRY_ACQ_INST,
              :QMR_ONUS_FLG,
              :QMR_AUTHENTICATED,
              :QMR_POS_CRD_DAT_IN_MOD,
              :QMR_CUR_TRAN,
              :QMR_MERCH_TYPE,
              :QMR_NETWORK_TRAN_TYPE,
              :QMR_CUR_CASHBACK,
              :QMR_AMT_TRAN,
              :QMR_TRAN_COUNT,
              :QMR_CASHBACK_COUNT,
              :QMR_AMT_CASHBACK
            FOR :QMR_ROWS ROWS;
*/

{
#line 279 "CXOSD248.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 279 "CXOSD248.sqx"
  sqlaaloc(2,24,1,0L);
    {
      struct sqla_setdata_list sql_setdlist[24];
#line 279 "CXOSD248.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 279 "CXOSD248.sqx"
      sql_setdlist[0].sqldata = (void*)QMR_YEAR_MONTH;
#line 279 "CXOSD248.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 12;
#line 279 "CXOSD248.sqx"
      sql_setdlist[1].sqldata = (void*)QMR_INST_ID;
#line 279 "CXOSD248.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 2;
#line 279 "CXOSD248.sqx"
      sql_setdlist[2].sqldata = (void*)QMR_ENTITY_ROLE;
#line 279 "CXOSD248.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 12;
#line 279 "CXOSD248.sqx"
      sql_setdlist[3].sqldata = (void*)QMR_BIN;
#line 279 "CXOSD248.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 12;
#line 279 "CXOSD248.sqx"
      sql_setdlist[4].sqldata = (void*)QMR_TOKEN_REQUESTOR_ID;
#line 279 "CXOSD248.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 4;
#line 279 "CXOSD248.sqx"
      sql_setdlist[5].sqldata = (void*)QMR_NETWORK_ID;
#line 279 "CXOSD248.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 3;
#line 279 "CXOSD248.sqx"
      sql_setdlist[6].sqldata = (void*)QMR_FUNCTION_TYPE;
#line 279 "CXOSD248.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 5;
#line 279 "CXOSD248.sqx"
      sql_setdlist[7].sqldata = (void*)QMR_ACCT_TYPES_ISS;
#line 279 "CXOSD248.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 2;
#line 279 "CXOSD248.sqx"
      sql_setdlist[8].sqldata = (void*)QMR_MSG_CLASS;
#line 279 "CXOSD248.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 2;
#line 279 "CXOSD248.sqx"
      sql_setdlist[9].sqldata = (void*)QMR_PRE_AUTH;
#line 279 "CXOSD248.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[10].sqltype = 460; sql_setdlist[10].sqllen = 3;
#line 279 "CXOSD248.sqx"
      sql_setdlist[10].sqldata = (void*)QMR_TERM_CLASS;
#line 279 "CXOSD248.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 4;
#line 279 "CXOSD248.sqx"
      sql_setdlist[11].sqldata = (void*)QMR_COUNTRY_ISS_INST;
#line 279 "CXOSD248.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 4;
#line 279 "CXOSD248.sqx"
      sql_setdlist[12].sqldata = (void*)QMR_COUNTRY_ACQ_INST;
#line 279 "CXOSD248.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 2;
#line 279 "CXOSD248.sqx"
      sql_setdlist[13].sqldata = (void*)QMR_ONUS_FLG;
#line 279 "CXOSD248.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 2;
#line 279 "CXOSD248.sqx"
      sql_setdlist[14].sqldata = (void*)QMR_AUTHENTICATED;
#line 279 "CXOSD248.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 2;
#line 279 "CXOSD248.sqx"
      sql_setdlist[15].sqldata = (void*)QMR_POS_CRD_DAT_IN_MOD;
#line 279 "CXOSD248.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 4;
#line 279 "CXOSD248.sqx"
      sql_setdlist[16].sqldata = (void*)QMR_CUR_TRAN;
#line 279 "CXOSD248.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 5;
#line 279 "CXOSD248.sqx"
      sql_setdlist[17].sqldata = (void*)QMR_MERCH_TYPE;
#line 279 "CXOSD248.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 3;
#line 279 "CXOSD248.sqx"
      sql_setdlist[18].sqldata = (void*)QMR_NETWORK_TRAN_TYPE;
#line 279 "CXOSD248.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 4;
#line 279 "CXOSD248.sqx"
      sql_setdlist[19].sqldata = (void*)QMR_CUR_CASHBACK;
#line 279 "CXOSD248.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[20].sqltype = 480; sql_setdlist[20].sqllen = 8;
#line 279 "CXOSD248.sqx"
      sql_setdlist[20].sqldata = (void*)QMR_AMT_TRAN;
#line 279 "CXOSD248.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[21].sqltype = 496; sql_setdlist[21].sqllen = 4;
#line 279 "CXOSD248.sqx"
      sql_setdlist[21].sqldata = (void*)QMR_TRAN_COUNT;
#line 279 "CXOSD248.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[22].sqltype = 496; sql_setdlist[22].sqllen = 4;
#line 279 "CXOSD248.sqx"
      sql_setdlist[22].sqldata = (void*)QMR_CASHBACK_COUNT;
#line 279 "CXOSD248.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sql_setdlist[23].sqltype = 480; sql_setdlist[23].sqllen = 8;
#line 279 "CXOSD248.sqx"
      sql_setdlist[23].sqldata = (void*)QMR_AMT_CASHBACK;
#line 279 "CXOSD248.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 279 "CXOSD248.sqx"
      sqlasetdata(2,0,24,sql_setdlist,0L,0L);
    }
#line 279 "CXOSD248.sqx"
    {
      struct sqlacall_spare_info sqla_spare_info;
      sqla_spare_info.uiVersion    = 1;
      sqla_spare_info.arrayInfo.uiArraySize  = QMR_ROWS;
      sqla_spare_info.arrayInfo.bIsStruct    = 0;
      sqla_spare_info.arrayInfo.bIsStructInd = 0;
      sqla_spare_info.arrayInfo.uiStructSize = 0;
      sqlacall((unsigned short)24,1,2,0,&sqla_spare_info);
    }
#line 279 "CXOSD248.sqx"
  sqlastop(0L);
}

#line 279 "CXOSD248.sqx"

#endif
      switch (sqlca.sqlcode)
      {
         case 0:
            UseCase::addItem(QMR_ROWS);
            break;
         case -911:
         case -913:
            UseCase::add("DEADLOCK");
            b = false;
            break;
         case -900:
         case -923:
         case -924:
         case -991:
         case -1024:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            b = false;
            break;
         default:
            if (sqlca.sqlcode > 0)
               Database::instance()->traceSQLError((void*)&sqlca,m_sID,"MERGE");
            else
            {
               UseCase::add("DBERROR");
               b = false;
            }
      }
      QMR_ROWS = 0;
      for(int i=0;i < QMR_ROWS; i++)
      {
            snprintf(szTemp, sizeof(szTemp), "MERGE INTO %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %d %f %d %f %s %s",
          QMR_ACCT_TYPES_ISS[i], QMR_AUTHENTICATED[i], QMR_BIN[i], QMR_COUNTRY_ACQ_INST[i], QMR_COUNTRY_ISS_INST[i],
          QMR_CUR_TRAN[i], QMR_FUNCTION_TYPE[i], QMR_INST_ID[i], QMR_MSG_CLASS[i], 
          QMR_NETWORK_ID[i], QMR_ONUS_FLG[i], QMR_POS_CRD_DAT_IN_MOD[i], QMR_PRE_AUTH[i], QMR_ENTITY_ROLE[i], QMR_TERM_CLASS[i], QMR_TOKEN_REQUESTOR_ID[i],
          QMR_YEAR_MONTH[i],QMR_MERCH_TYPE[i] , QMR_TRAN_COUNT[i], QMR_AMT_TRAN[i] , QMR_CASHBACK_COUNT[i] , QMR_AMT_CASHBACK[i], QMR_NETWORK_TRAN_TYPE[i], QMR_CUR_CASHBACK[i]);
          Trace::put(szTemp);
      }
      if (!b)
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"MERGE");
         return UseCase::setSuccess(false);
      }
   }
   return b;
  //## end dndb2database::DB2MonthlyTotals::commit%61470144039F.body
}

int DB2MonthlyTotals::tableUpdate ()
{
  //## begin dndb2database::DB2MonthlyTotals::tableUpdate%61470114016E.body preserve=yes
   if (getENTITY_ROLE().empty())
      return 0;
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return -1;
   if (QMR_ROWS >= 512)
         if (!commit())
            return -1;
   char szSpace[2] = {" "};
   if(getACCT_TYPES_ISS().length() < sizeof(QMR_ACCT_TYPES_ISS[QMR_ROWS]))
   {
      memcpy(QMR_ACCT_TYPES_ISS[QMR_ROWS], getACCT_TYPES_ISS().data(), getACCT_TYPES_ISS().length());
      QMR_ACCT_TYPES_ISS[QMR_ROWS][getACCT_TYPES_ISS().length()] = '\0';
   }
   QMR_AMT_TRAN[QMR_ROWS] = getAMT_TRAN();
   QMR_AMT_CASHBACK[QMR_ROWS] = getAMT_CASHBACK();
   QMR_CASHBACK_COUNT[QMR_ROWS] = getCASHBACK_COUNT();
   if(getNETWORK_TRAN_TYPE().length() < sizeof(QMR_NETWORK_TRAN_TYPE[QMR_ROWS]))
   {
      memcpy(QMR_NETWORK_TRAN_TYPE[QMR_ROWS],getNETWORK_TRAN_TYPE().data(),getNETWORK_TRAN_TYPE().length());
      QMR_NETWORK_TRAN_TYPE[QMR_ROWS][getNETWORK_TRAN_TYPE().length()] = '\0';
   }
   if(getCUR_CASHBACK().length() < sizeof(QMR_CUR_CASHBACK[QMR_ROWS]))
   {
      memcpy(QMR_CUR_CASHBACK[QMR_ROWS],getCUR_CASHBACK().data(),getCUR_CASHBACK().length());
      QMR_CUR_CASHBACK[QMR_ROWS][getCUR_CASHBACK().length()] = '\0';
   }
   if(getAUTHENTICATED().length() < sizeof(QMR_AUTHENTICATED[QMR_ROWS]))
   {
      memcpy(QMR_AUTHENTICATED[QMR_ROWS],getAUTHENTICATED().data(),getAUTHENTICATED().length());
      QMR_AUTHENTICATED[QMR_ROWS][getAUTHENTICATED().length()] = '\0';
   }
   if(getBIN().length() < sizeof(QMR_BIN[QMR_ROWS]))
   {
      memcpy(QMR_BIN[QMR_ROWS], getBIN().data(), getBIN().length());
      QMR_BIN[QMR_ROWS][getBIN().length()] = '\0';
   }
   if(getCOUNTRY_ACQ_INST().length() < sizeof(QMR_COUNTRY_ACQ_INST[QMR_ROWS]))
   {
      memcpy(QMR_COUNTRY_ACQ_INST[QMR_ROWS], getCOUNTRY_ACQ_INST().data(), getCOUNTRY_ACQ_INST().length());
      QMR_COUNTRY_ACQ_INST[QMR_ROWS][getCOUNTRY_ACQ_INST().length()] = '\0';
   }
   if(getCOUNTRY_ISS_INST().length() < sizeof(QMR_COUNTRY_ISS_INST[QMR_ROWS]))
   {
      memcpy(QMR_COUNTRY_ISS_INST[QMR_ROWS], getCOUNTRY_ISS_INST().data(), getCOUNTRY_ISS_INST().length());
      QMR_COUNTRY_ISS_INST[QMR_ROWS][getCOUNTRY_ISS_INST().length()] = '\0';
   }
   if(getCUR_TRAN().length() < sizeof(QMR_CUR_TRAN[QMR_ROWS]))
   {
      memcpy(QMR_CUR_TRAN[QMR_ROWS], getCUR_TRAN().data(), getCUR_TRAN().length());
      QMR_CUR_TRAN[QMR_ROWS][getCUR_TRAN().length()] = '\0';
   }
   if(getFUNCTION_TYPE().length() < sizeof(QMR_FUNCTION_TYPE[QMR_ROWS]))
   {
      memcpy(QMR_FUNCTION_TYPE[QMR_ROWS], getFUNCTION_TYPE().data(), getFUNCTION_TYPE().length());
      QMR_FUNCTION_TYPE[QMR_ROWS][getFUNCTION_TYPE().length()] = '\0';
   }
   if(getINST_ID().length() < sizeof(QMR_INST_ID[QMR_ROWS]))
   {
      memcpy(QMR_INST_ID[QMR_ROWS],getINST_ID().data(), getINST_ID().length());
      QMR_INST_ID[QMR_ROWS][getINST_ID().length()] = '\0';
   }
   if(getMSG_CLASS().length() <  sizeof(QMR_MSG_CLASS[QMR_ROWS]))
   {
      memcpy(QMR_MSG_CLASS[QMR_ROWS], getMSG_CLASS().data(), getMSG_CLASS().length());
      QMR_MSG_CLASS[QMR_ROWS][getMSG_CLASS().length()] = '\0';
   }
   if(getNETWORK_ID().length() < sizeof(QMR_NETWORK_ID[QMR_ROWS]))
   {
      memcpy(QMR_NETWORK_ID[QMR_ROWS], getNETWORK_ID().data(), getNETWORK_ID().length());
      QMR_NETWORK_ID[QMR_ROWS][getNETWORK_ID().length()] = '\0';
   }
   if(getONUS_FLG().length() < sizeof(QMR_ONUS_FLG[QMR_ROWS]) )
   {
      memcpy(QMR_ONUS_FLG[QMR_ROWS], getONUS_FLG().data(), getONUS_FLG().length());
      QMR_ONUS_FLG[QMR_ROWS][getONUS_FLG().length()] = '\0';
   }
   if(getPOS_CRD_DAT_IN_MOD().length() < sizeof(QMR_POS_CRD_DAT_IN_MOD[QMR_ROWS]))
   {
      memcpy(QMR_POS_CRD_DAT_IN_MOD[QMR_ROWS], getPOS_CRD_DAT_IN_MOD().data(), getPOS_CRD_DAT_IN_MOD().length());
      QMR_POS_CRD_DAT_IN_MOD[QMR_ROWS][getPOS_CRD_DAT_IN_MOD().length()] = '\0';
   }
   if(getPRE_AUTH().length() < sizeof(QMR_PRE_AUTH[QMR_ROWS]))
   {
      memcpy(QMR_PRE_AUTH[QMR_ROWS], getPRE_AUTH().data(), getPRE_AUTH().length());
      QMR_PRE_AUTH[QMR_ROWS][getPRE_AUTH().length()] = '\0';
   }
   if(getENTITY_ROLE().length() < sizeof(QMR_ENTITY_ROLE[QMR_ROWS]))
   {
      memcpy(QMR_ENTITY_ROLE[QMR_ROWS], getENTITY_ROLE().data(), getENTITY_ROLE().length());
      QMR_ENTITY_ROLE[QMR_ROWS][getENTITY_ROLE().length()] = '\0';
   }
   if(getTERM_CLASS().length() < sizeof(QMR_TERM_CLASS[QMR_ROWS]))
   {
      memcpy(QMR_TERM_CLASS[QMR_ROWS], getTERM_CLASS().data(), getTERM_CLASS().length());
      QMR_TERM_CLASS[QMR_ROWS][getTERM_CLASS().length()] = '\0';
   }
   if(getTOKEN_REQUESTOR_ID().length() < sizeof(QMR_TOKEN_REQUESTOR_ID[QMR_ROWS]))
   {
      memcpy(QMR_TOKEN_REQUESTOR_ID[QMR_ROWS], getTOKEN_REQUESTOR_ID().data(), getTOKEN_REQUESTOR_ID().length());
      QMR_TOKEN_REQUESTOR_ID[QMR_ROWS][getTOKEN_REQUESTOR_ID().length()] = '\0';
   }
   QMR_TRAN_COUNT[QMR_ROWS] = getTRAN_COUNT();
   if(getYEAR_MONTH().length() < sizeof(QMR_YEAR_MONTH[QMR_ROWS]))
   {
      memcpy(QMR_YEAR_MONTH[QMR_ROWS], getYEAR_MONTH().data(), getYEAR_MONTH().length());
      QMR_YEAR_MONTH[QMR_ROWS][getYEAR_MONTH().length()] = '\0';
   }
   if(getMERCH_TYPE().length() < sizeof(QMR_MERCH_TYPE[QMR_ROWS]))
   {
      memcpy(QMR_MERCH_TYPE[QMR_ROWS], getMERCH_TYPE().data(), getMERCH_TYPE().length());
      QMR_MERCH_TYPE[QMR_ROWS][getMERCH_TYPE().length()] = '\0';
   }
   QMR_ROWS++;
   return 0;
  //## end dndb2database::DB2MonthlyTotals::tableUpdate%61470114016E.body
}

// Additional Declarations
  //## begin dndb2database::DB2MonthlyTotals%6146FC1E036D.declarations preserve=yes
  //## end dndb2database::DB2MonthlyTotals%6146FC1E036D.declarations

} // namespace dndb2database

//## begin module%6146FE1502D2.epilog preserve=yes
//## end module%6146FE1502D2.epilog
