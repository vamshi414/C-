static char sqla_program_id[292] = 
{
 '\xac','\x0','\x41','\x45','\x41','\x56','\x41','\x49','\x6c','\x42','\x58','\x33','\x52','\x48','\x49','\x6f','\x30','\x31','\x31','\x31',
 '\x31','\x20','\x32','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x8','\x0','\x44','\x4e','\x53','\x45','\x52','\x56',
 '\x45','\x52','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x8','\x0','\x43','\x58','\x4f','\x53','\x44','\x32','\x30','\x36','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0'
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {'C',' ',' ',' '}};


static const short sqlIsLiteral   = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "CXOSD206.sqx"
//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4915EB0E01D4.cm preserve=no
// $Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
// $Revision:   1.27  $
//## end module%4915EB0E01D4.cm

//## begin module%4915EB0E01D4.cp preserve=no
// Copyright (c) 1997 - 2012
// FIS
//## end module%4915EB0E01D4.cp

//## Module: CXOSD206%4915EB0E01D4; Package body
//## Subsystem: D2DLL%3597E8A6029B
// .
//## Source file: C:\bV02.5B.R001\Windows\Build\Dn\Server\Library\D2dll\CXOSD206.sqx

//## begin module%4915EB0E01D4.additionalIncludes preserve=no
//## end module%4915EB0E01D4.additionalIncludes

//## begin module%4915EB0E01D4.includes preserve=yes
#include "CXODRU54.hpp"
//## end module%4915EB0E01D4.includes

#ifndef CXOSPC01_h
#include "CXODPC01.hpp"
#endif
#ifndef CXOSRS39_h
#include "CXODRS39.hpp"
#endif
#ifndef CXOSRS38_h
#include "CXODRS38.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSRS41_h
#include "CXODRS41.hpp"
#endif
#ifndef CXOSRS40_h
#include "CXODRS40.hpp"
#endif
#ifndef CXOSRS37_h
#include "CXODRS37.hpp"
#endif
#ifndef CXOSRS36_h
#include "CXODRS36.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU07_h
#include "CXODRU07.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRS70_h
#include "CXODRS70.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSDB30_h
#include "CXODDB30.hpp"
#endif
#ifndef CXOSRS76_h
#include "CXODRS76.hpp"
#endif
#ifndef CXOSDB49_h
#include "CXODDB49.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSBS18_h
#include "CXODBS18.hpp"
#endif
#ifndef CXOSRS80_h
#include "CXODRS80.hpp"
#endif
#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSD206_h
#include "CXODD206.hpp"
#endif


//## begin module%4915EB0E01D4.declarations preserve=no
//## end module%4915EB0E01D4.declarations

//## begin module%4915EB0E01D4.additionalDeclarations preserve=yes
#ifdef MVS

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
struct sqlca sqlca;


#line 119 "CXOSD206.sqx"

#else
#include "sqlca.h"
extern struct sqlca sqlca;
#endif


/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 125 "CXOSD206.sqx"

   sqlint32 FR_INSERT_SEQUENCE_NO;
   char FR_TSTAMP_TRANS[17];
   short  FR_UNIQUENESS_KEY;

   char FR_ACCT_ID_1[29];
   char FR_ACCT_ID_2[29];
   char FR_ACCT_ID_3[29];
   char FR_ACCT_TYPES_ISS[5];
   sqlint32 FR_CED_BUILD_NO;
   char FR_ACQ_PLAT_PROD_ID[2];
   double FR_AMT_CARD_BILL;
   double FR_AMT_RECON_NET;
   double FR_AMT_TRAN;
   char FR_CARD_ACPT_BUS_CODE[5];
   char FR_CARD_ACPT_COUNTRY[4];
   struct
   {
      short  FR_CARD_ACPT_NAME_LOC_len;
      char FR_CARD_ACPT_NAME_LOC_data[84];
   } FR_CARD_ACPT_NAME_LOC;
   char FR_CARD_ACPT_PST_CODE[11];
   char FR_CARD_ACPT_REGION[4];
   char FR_CARD_SEQ_NO[6];
   char FR_CIRC_ID_ACQ[9];
   char FR_CIRC_ID_ISS[9];
   char FR_COUNTRY_ACQ_INST[4];
   char FR_COUNTRY_ISS_INST[4];
   char FR_CUR_CARD_BILL[4];
   char FR_CUR_RECON_NET[4];
   char FR_CUR_TRAN[4];
   char FR_DATE_RECON_ACQ[9];
   char FR_FUNC_CODE[4];
   char FR_MERCH_TYPE[5];
   char FR_MSG_RESON_CODE_ACQ[5];
   char FR_MSG_RESON_CODE_ISS[5];
   char FR_NET_ID_ACQ[4];
   char FR_NET_ID_ISS[4];
   short  FR_PARTITION_KEY;
   char FR_POS_CRDHLDR_A_METH[2];
   char FR_REIMBURSEMENT_ATTR[2];
   char FR_REV_BY[2];
   char FR_TRAN_DISPOSITION[2];
   char FR_BRANCH_ID_ACQ[12];
   char FR_CNTRY_REC_INST_ADJ[4];
   char FR_CNTRY_REQ_INST_ADJ[4];
   struct
   {
      short  FR_EXTENSION_DATA_ADJ_len;
      char FR_EXTENSION_DATA_ADJ_data[400];
   } FR_EXTENSION_DATA_ADJ;
   char FR_INST_ID_REC_ADJ[12];
   char FR_INST_ID_REQ_ADJ[12];
   char FR_NET_IND_ADJ[2];
   double FR_ORIG_AMT_TRAN_ADJ;
   char FR_REQ_ACQ_ISS_IND[2];
   char FR_TRACE_DATA_ADJ[24];
   char FR_TSTAMP_LOCAL_ADJ[15];
   char FR_TSTAMP_TRANS_ADJ[17];
   struct
   {
      short  FR_ADTL_DATA_FEE_len;
      char FR_ADTL_DATA_FEE_data[254];
   } FR_ADTL_DATA_FEE;
   char FR_ISS_ACQ_TYPE_FEE[2];
   struct
   {
      short  FR_NET_UNIQUE_DAT_FEE_len;
      char FR_NET_UNIQUE_DAT_FEE_data[80];
   } FR_NET_UNIQUE_DAT_FEE;
   sqlint32 FR_FO_AMT_RECON_ACQ0;
   sqlint32 FR_FO_AMT_RECON_ACQ1;
   sqlint32 FR_FO_AMT_RECON_ACQ2;
   sqlint32 FR_FO_AMT_RECON_ACQ3;
   sqlint32 FR_FO_AMT_RECON_ACQ4;
   sqlint32 FR_FO_AMT_RECON_ACQ5;
   sqlint32 FR_FO_AMT_RECON_ISS0;
   sqlint32 FR_FO_AMT_RECON_ISS1;
   sqlint32 FR_FO_AMT_RECON_ISS2;
   sqlint32 FR_FO_AMT_RECON_ISS3;
   sqlint32 FR_FO_AMT_RECON_ISS4;
   sqlint32 FR_FO_AMT_RECON_ISS5;
   sqlint32 FR_FO_AMT_RECON_NET0;
   sqlint32 FR_FO_AMT_RECON_NET1;
   sqlint32 FR_FO_AMT_RECON_NET2;
   sqlint32 FR_FO_AMT_RECON_NET3;
   sqlint32 FR_FO_AMT_RECON_NET4;
   sqlint32 FR_FO_AMT_RECON_NET5;
   sqlint32 FR_FO_AMT0;
   sqlint32 FR_FO_AMT1;
   sqlint32 FR_FO_AMT2;
   sqlint32 FR_FO_AMT3;
   sqlint32 FR_FO_AMT4;
   sqlint32 FR_FO_AMT5;
   double FR_FO_CNV_ACQ_DE_POS0;
   double FR_FO_CNV_ACQ_DE_POS1;
   double FR_FO_CNV_ACQ_DE_POS2;
   double FR_FO_CNV_ACQ_DE_POS3;
   double FR_FO_CNV_ACQ_DE_POS4;
   double FR_FO_CNV_ACQ_DE_POS5;
   sqlint32 FR_FO_CNV_ACQ_RATE0;
   sqlint32 FR_FO_CNV_ACQ_RATE1;
   sqlint32 FR_FO_CNV_ACQ_RATE2;
   sqlint32 FR_FO_CNV_ACQ_RATE3;
   sqlint32 FR_FO_CNV_ACQ_RATE4;
   sqlint32 FR_FO_CNV_ACQ_RATE5;
   double FR_FO_CNV_ISS_DE_POS0;
   double FR_FO_CNV_ISS_DE_POS1;
   double FR_FO_CNV_ISS_DE_POS2;
   double FR_FO_CNV_ISS_DE_POS3;
   double FR_FO_CNV_ISS_DE_POS4;
   double FR_FO_CNV_ISS_DE_POS5;
   sqlint32 FR_FO_CNV_ISS_RATE0;
   sqlint32 FR_FO_CNV_ISS_RATE1;
   sqlint32 FR_FO_CNV_ISS_RATE2;
   sqlint32 FR_FO_CNV_ISS_RATE3;
   sqlint32 FR_FO_CNV_ISS_RATE4;
   sqlint32 FR_FO_CNV_ISS_RATE5;
   char FR_FO_CUR_CODE0[4];
   char FR_FO_CUR_CODE1[4];
   char FR_FO_CUR_CODE2[4];
   char FR_FO_CUR_CODE3[4];
   char FR_FO_CUR_CODE4[4];
   char FR_FO_CUR_CODE5[4];
   char FR_FO_CUR_RECON_ACQ0[4];
   char FR_FO_CUR_RECON_ACQ1[4];
   char FR_FO_CUR_RECON_ACQ2[4];
   char FR_FO_CUR_RECON_ACQ3[4];
   char FR_FO_CUR_RECON_ACQ4[4];
   char FR_FO_CUR_RECON_ACQ5[4];
   char FR_FO_CUR_RECON_ISS0[4];
   char FR_FO_CUR_RECON_ISS1[4];
   char FR_FO_CUR_RECON_ISS2[4];
   char FR_FO_CUR_RECON_ISS3[4];
   char FR_FO_CUR_RECON_ISS4[4];
   char FR_FO_CUR_RECON_ISS5[4];
   double FR_FO_DEC_POS0;
   double FR_FO_DEC_POS1;
   double FR_FO_DEC_POS2;
   double FR_FO_DEC_POS3;
   double FR_FO_DEC_POS4;
   double FR_FO_DEC_POS5;
   char FR_FO_INITIATOR0[2];
   char FR_FO_INITIATOR1[2];
   char FR_FO_INITIATOR2[2];
   char FR_FO_INITIATOR3[2];
   char FR_FO_INITIATOR4[2];
   char FR_FO_INITIATOR5[2];
   char FR_FO_MEMO0[2];
   char FR_FO_MEMO1[2];
   char FR_FO_MEMO2[2];
   char FR_FO_MEMO3[2];
   char FR_FO_MEMO4[2];
   char FR_FO_MEMO5[2];
   char FR_FO_TYPE0[3];
   char FR_FO_TYPE1[3];
   char FR_FO_TYPE2[3];
   char FR_FO_TYPE3[3];
   char FR_FO_TYPE4[3];
   char FR_FO_TYPE5[3];
   double FR_O_AMT_CARD_BILL;
   double FR_O_AMT_RECON_ACQ;
   double FR_O_AMT_RECON_ISS;
   double FR_O_AMT_RECON_NET;
   double FR_O_AMT_TRAN;
   char FR_ODE_INST_ID_ACQ[12];
   char FR_ODE_MTI[5];
   char FR_ODE_SYS_TRA_AUD_NO[7];
   char FR_ODE_TSTAMP_LOCL_TR[15];
   char FR_TSTAMP_REV_CREATED[17];
   char FR_ACCT_QUAL_1[4];
   char FR_ACCT_QUAL_2[4];
   struct
   {
      short  FR_ADL_DATA_PRIV_ACQ_len;
      char FR_ADL_DATA_PRIV_ACQ_data[255];
   } FR_ADL_DATA_PRIV_ACQ;
   struct
   {
      short  FR_ADL_RESP_DATA_len;
      char FR_ADL_RESP_DATA_data[99];
   } FR_ADL_RESP_DATA;
   double FR_AMT_RECON_ACQ;
   double FR_AMT_RECON_ISS;
   char FR_AP_FLG[2];
   sqlint32 FR_CAN_ITEM_VALUE0;
   sqlint32 FR_CAN_ITEM_VALUE1;
   sqlint32 FR_CAN_ITEM_VALUE2;
   sqlint32 FR_CAN_ITEM_VALUE3;
   sqlint32 FR_CAN_ITEM_VALUE4;
   sqlint32 FR_CAN_ITEM_VALUE5;
   sqlint32 FR_CAN_ITEM_VALUE6;
   sqlint32 FR_CAN_ITEM_VALUE7;
   short  FR_CAN_NO_ITEMS_DISP0;
   short  FR_CAN_NO_ITEMS_DISP1;
   short  FR_CAN_NO_ITEMS_DISP2;
   short  FR_CAN_NO_ITEMS_DISP3;
   short  FR_CAN_NO_ITEMS_DISP4;
   short  FR_CAN_NO_ITEMS_DISP5;
   short  FR_CAN_NO_ITEMS_DISP6;
   short  FR_CAN_NO_ITEMS_DISP7;
   short  FR_CAN_ORIG_NO_ITEMS0;
   short  FR_CAN_ORIG_NO_ITEMS1;
   short  FR_CAN_ORIG_NO_ITEMS2;
   short  FR_CAN_ORIG_NO_ITEMS3;
   short  FR_CAN_ORIG_NO_ITEMS4;
   short  FR_CAN_ORIG_NO_ITEMS5;
   short  FR_CAN_ORIG_NO_ITEMS6;
   short  FR_CAN_ORIG_NO_ITEMS7;
   char FR_CARD_ACPT_ID[16];
   char FR_CARD_OWNER[3];
   char FR_CARD_TYPE[2];
   char FR_CAVV_RESULT[2];
   double FR_CNV_CRD_BIL_DE_POS;
   double FR_CNV_CRD_BIL_RATE;
   double FR_CNV_RCN_ACQ_DE_POS;
   double FR_CNV_RCN_ACQ_RATE;
   double FR_CNV_RCN_ISS_DE_POS;
   double FR_CNV_RCN_ISS_RATE;
   double FR_CNV_RCN_NET_DE_POS;
   double FR_CNV_RCN_NET_RATE;
   char FR_CRD_ACP_NAM_FMTFLG[2];
   char FR_CUR_RECON_ACQ[4];
   char FR_CUR_RECON_ISS[4];
   short  FR_CUR_TYPE;
   struct
   {
      short  FR_DATA_PRIV_ACQ_len;
      char FR_DATA_PRIV_ACQ_data[100];
   } FR_DATA_PRIV_ACQ;
   short  FR_DATA_PRIV_ACQ_FMT;
   struct
   {
      short  FR_DATA_PRIV_ISS_len;
      char FR_DATA_PRIV_ISS_data[100];
   } FR_DATA_PRIV_ISS;
   short  FR_DATA_PRIV_ISS_FMT;
   char FR_DATE_EXP[5];
   char FR_DATE_RECON_ISS[9];
   char FR_DRAFT_CAPTURE_FLG[2];
   char FR_EXCHG_MASTER[2];
   char FR_EXCHG_SETL[2];
   double FR_F_ADL_DEC_POS0;
   double FR_F_ADL_DEC_POS1;
   double FR_F_ADL_DEC_POS2;
   double FR_F_ADL_DEC_POS3;
   double FR_F_ADL_DEC_POS4;
   double FR_F_ADL_DEC_POS5;
   sqlint32 FR_F_AMT0;
   sqlint32 FR_F_AMT1;
   sqlint32 FR_F_AMT2;
   sqlint32 FR_F_AMT3;
   sqlint32 FR_F_AMT4;
   sqlint32 FR_F_AMT5;
   sqlint32 FR_F_AMT_RECON_ACQ0;
   sqlint32 FR_F_AMT_RECON_ACQ1;
   sqlint32 FR_F_AMT_RECON_ACQ2;
   sqlint32 FR_F_AMT_RECON_ACQ3;
   sqlint32 FR_F_AMT_RECON_ACQ4;
   sqlint32 FR_F_AMT_RECON_ACQ5;
   sqlint32 FR_F_AMT_RECON_ISS0;
   sqlint32 FR_F_AMT_RECON_ISS1;
   sqlint32 FR_F_AMT_RECON_ISS2;
   sqlint32 FR_F_AMT_RECON_ISS3;
   sqlint32 FR_F_AMT_RECON_ISS4;
   sqlint32 FR_F_AMT_RECON_ISS5;
   sqlint32 FR_F_AMT_RECON_NET0;
   sqlint32 FR_F_AMT_RECON_NET1;
   sqlint32 FR_F_AMT_RECON_NET2;
   sqlint32 FR_F_AMT_RECON_NET3;
   sqlint32 FR_F_AMT_RECON_NET4;
   sqlint32 FR_F_AMT_RECON_NET5;
   double FR_F_CNV_ACQ_DEC_POS0;
   double FR_F_CNV_ACQ_DEC_POS1;
   double FR_F_CNV_ACQ_DEC_POS2;
   double FR_F_CNV_ACQ_DEC_POS3;
   double FR_F_CNV_ACQ_DEC_POS4;
   double FR_F_CNV_ACQ_DEC_POS5;
   double FR_F_CNV_ACQ_RATE0;
   double FR_F_CNV_ACQ_RATE1;
   double FR_F_CNV_ACQ_RATE2;
   double FR_F_CNV_ACQ_RATE3;
   double FR_F_CNV_ACQ_RATE4;
   double FR_F_CNV_ACQ_RATE5;
   double FR_F_CNV_ISS_DEC_POS0;
   double FR_F_CNV_ISS_DEC_POS1;
   double FR_F_CNV_ISS_DEC_POS2;
   double FR_F_CNV_ISS_DEC_POS3;
   double FR_F_CNV_ISS_DEC_POS4;
   double FR_F_CNV_ISS_DEC_POS5;
   double FR_F_CNV_ISS_RATE0;
   double FR_F_CNV_ISS_RATE1;
   double FR_F_CNV_ISS_RATE2;
   double FR_F_CNV_ISS_RATE3;
   double FR_F_CNV_ISS_RATE4;
   double FR_F_CNV_ISS_RATE5;
   char FR_F_CUR_CODE0[4];
   char FR_F_CUR_CODE1[4];
   char FR_F_CUR_CODE2[4];
   char FR_F_CUR_CODE3[4];
   char FR_F_CUR_CODE4[4];
   char FR_F_CUR_CODE5[4];
   char FR_F_CUR_RECON_ACQ0[4];
   char FR_F_CUR_RECON_ACQ1[4];
   char FR_F_CUR_RECON_ACQ2[4];
   char FR_F_CUR_RECON_ACQ3[4];
   char FR_F_CUR_RECON_ACQ4[4];
   char FR_F_CUR_RECON_ACQ5[4];
   char FR_F_CUR_RECON_ISS0[4];
   char FR_F_CUR_RECON_ISS1[4];
   char FR_F_CUR_RECON_ISS2[4];
   char FR_F_CUR_RECON_ISS3[4];
   char FR_F_CUR_RECON_ISS4[4];
   char FR_F_CUR_RECON_ISS5[4];
   char FR_F_INITIATOR0[2];
   char FR_F_INITIATOR1[2];
   char FR_F_INITIATOR2[2];
   char FR_F_INITIATOR3[2];
   char FR_F_INITIATOR4[2];
   char FR_F_INITIATOR5[2];
   char FR_F_MEMO0[2];
   char FR_F_MEMO1[2];
   char FR_F_MEMO2[2];
   char FR_F_MEMO3[2];
   char FR_F_MEMO4[2];
   char FR_F_MEMO5[2];
   char FR_F_TYPE0[3];
   char FR_F_TYPE1[3];
   char FR_F_TYPE2[3];
   char FR_F_TYPE3[3];
   char FR_F_TYPE4[3];
   char FR_F_TYPE5[3];
   char FR_HOST_RECV_FLG[2];
   char FR_HOST_SENT_FLG[2];
   char FR_MCI_AAV_RESULT_COD[2];
   char FR_MCI_ECS_LVL_IND[4];
   char FR_MCI_UCAF_DATA[33];
   char FR_MTI[5];
   char FR_MERCH_TIER_ID[15];
   char FR_OAR_RQST_FLG[2];
   char FR_PAYEE[26];
   char FR_POS_CARD_CAPT_CAP[2];
   char FR_POS_CARD_PRES[2];
   char FR_POS_CRDHLDR_AUTH[2];
   char FR_POS_CRDHLDR_AUTH_C[2];
   char FR_POS_CRDHLDR_PRESNT[2];
   char FR_POS_CRD_DAT_IN_CAP[2];
   char FR_POS_CRD_DAT_IN_MOD[2];
   char FR_POS_CRD_DAT_OT_CAP[2];
   char FR_POS_OPER_ENV[2];
   char FR_POS_PIN_CAPT_CAP[2];
   char FR_POS_TERM_OUT_CAP[2];
   char FR_PRINT_MASK_ID[9];
   struct
   {
      short  FR_REF_DATA_ACQ_len;
      char FR_REF_DATA_ACQ_data[99];
   } FR_REF_DATA_ACQ;
   short  FR_REF_DATA_ACQ_FMT;
   struct
   {
      short  FR_REF_DATA_ISS_len;
      char FR_REF_DATA_ISS_data[99];
   } FR_REF_DATA_ISS;
   short  FR_REF_DATA_ISS_FMT;
   char FR_TERM_CLASS[3];
   short  FR_TIME_AT_AP;
   short  FR_TIME_AT_ISS;
   short  FR_TIME_AT_RESP_QUE;
   short  FR_TIME_AT_RESP_SWTCH;
   short  FR_TIME_AT_RQST_QUE;
   short  FR_TIME_AT_RQST_SWTCH;
   struct
   {
      short  FR_TRACK_2_DATA_len;
      char FR_TRACK_2_DATA_data[40];
   } FR_TRACK_2_DATA;
   struct
   {
      short  FR_TRAN_DESC_len;
      char FR_TRAN_DESC_data[100];
   } FR_TRAN_DESC;
   struct
   {
      short  FR_TRAN_UNIQUE_DATA_len;
      char FR_TRAN_UNIQUE_DATA_data[50];
   } FR_TRAN_UNIQUE_DATA;
   char FR_TRAN_UNIQ_DATA_FMT[3];
   struct
   {
      short  FR_ADL_DATA_PRIV_ISS_len;
      char FR_ADL_DATA_PRIV_ISS_data[255];
   } FR_ADL_DATA_PRIV_ISS;
   char FR_ACCT_TYPE_1[5];
   char FR_ACCT_TYPE_2[5];
   char FR_ACCT_TYPE_3[5];
   short  FR_ADL_RESP_ACCT_IDX0;
   short  FR_ADL_RESP_ACCT_IDX1;
   short  FR_ADL_RESP_ACCT_IDX2;
   short  FR_ADL_RESP_ACCT_IDX3;
   short  FR_ADL_RESP_ACCT_IDX4;
   short  FR_ADL_RESP_ACCT_IDX5;
   char FR_ADL_RESP_ACCT_TYP0[3];
   char FR_ADL_RESP_ACCT_TYP1[3];
   char FR_ADL_RESP_ACCT_TYP2[3];
   char FR_ADL_RESP_ACCT_TYP3[3];
   char FR_ADL_RESP_ACCT_TYP4[3];
   char FR_ADL_RESP_ACCT_TYP5[3];
   double FR_ADL_RESP_AMT0;
   double FR_ADL_RESP_AMT1;
   double FR_ADL_RESP_AMT2;
   double FR_ADL_RESP_AMT3;
   double FR_ADL_RESP_AMT4;
   double FR_ADL_RESP_AMT5;
   char FR_ADL_RESP_AMT_TYP0[3];
   char FR_ADL_RESP_AMT_TYP1[3];
   char FR_ADL_RESP_AMT_TYP2[3];
   char FR_ADL_RESP_AMT_TYP3[3];
   char FR_ADL_RESP_AMT_TYP4[3];
   char FR_ADL_RESP_AMT_TYP5[3];
   char FR_ADL_RESP_CUR_CODE0[4];
   char FR_ADL_RESP_CUR_CODE1[4];
   char FR_ADL_RESP_CUR_CODE2[4];
   char FR_ADL_RESP_CUR_CODE3[4];
   char FR_ADL_RESP_CUR_CODE4[4];
   char FR_ADL_RESP_CUR_CODE5[4];
   short  FR_ADL_RQST_ACCT_IDX0;
   short  FR_ADL_RQST_ACCT_IDX1;
   short  FR_ADL_RQST_ACCT_IDX2;
   short  FR_ADL_RQST_ACCT_IDX3;
   short  FR_ADL_RQST_ACCT_IDX4;
   short  FR_ADL_RQST_ACCT_IDX5;
   char FR_ADL_RQST_ACCT_TYP0[3];
   char FR_ADL_RQST_ACCT_TYP1[3];
   char FR_ADL_RQST_ACCT_TYP2[3];
   char FR_ADL_RQST_ACCT_TYP3[3];
   char FR_ADL_RQST_ACCT_TYP4[3];
   char FR_ADL_RQST_ACCT_TYP5[3];
   double FR_ADL_RQST_AMT0;
   double FR_ADL_RQST_AMT1;
   double FR_ADL_RQST_AMT2;
   double FR_ADL_RQST_AMT3;
   double FR_ADL_RQST_AMT4;
   double FR_ADL_RQST_AMT5;
   char FR_ADL_RQST_AMT_TYP0[3];
   char FR_ADL_RQST_AMT_TYP1[3];
   char FR_ADL_RQST_AMT_TYP2[3];
   char FR_ADL_RQST_AMT_TYP3[3];
   char FR_ADL_RQST_AMT_TYP4[3];
   char FR_ADL_RQST_AMT_TYP5[3];
   char FR_ADL_RQST_CUR_CODE0[4];
   char FR_ADL_RQST_CUR_CODE1[4];
   char FR_ADL_RQST_CUR_CODE2[4];
   char FR_ADL_RQST_CUR_CODE3[4];
   char FR_ADL_RQST_CUR_CODE4[4];
   char FR_ADL_RQST_CUR_CODE5[4];
   char FR_ALT_ROUTE_FLG[2];
   char FR_AP_APPROVAL_CODE[7];
   char FR_AP_CARD_GRP[9];
   char FR_AP_DATA[9];
   short  FR_AP_ERROR_NO;
   short  FR_AP_ERROR_TRACE_LOC;
   short  FR_AP_REJ_REASON_CODE;
   char FR_AUTH_LCYCLE_TCODE[2];
   double FR_AUTH_LIFECYCLE_INT;
   short  FR_AUTH_RQST_TIMEOUT;
   char FR_CARD_ACPT_COUNTY[4];
   char FR_CARD_ACPT_SPNSR_ID[12];
   char FR_CARD_CAPT_FLG[2];
   char FR_CLERK_ID[29];
   char FR_CNTRY_RCN_ACQ_INST[4];
   char FR_CNTRY_RCN_ISS_INST[4];
   char FR_CVV_CVC_RESULT[2];
   char FR_CVV2_CVC2_RESULT[2];
   char FR_DATE_ACTION[9];
   char FR_DATE_CAPTURE[5];
   char FR_DATE_CNV_ACQ[5];
   char FR_DATE_CNV_ISS[5];
   char FR_DATE_EFFECTIVE[5];
   char FR_DATE_RECON_NET[9];
   char FR_DEPOSIT_ONLY_FLG[2];
   char FR_EXTENDED_PAY_DATA[3];
   short  FR_PIN_DATA_FMT;
   short  FR_PIN_RESULT;
   short  FR_PMC_ERROR;
   short  FR_PREAUTH_COMP_OPT;
   char FR_RECON_IND_ACQ[7];
   char FR_RESTRIC_INTCHG_GRP[9];
   char FR_SOURCE_ROUTE_ID[9];
   char FR_SRV_GRP_INTCHG_IND[2];
   char FR_SRV_GRP_SERV_CODE[3];
   char FR_STANDIN_ACT[2];
   char FR_STANDIN_OPTION[2];
   char FR_TRACINF_KEYTRAC_NO[2];
   char FR_TRACK_INFO_KEY_ID[9];
   char FR_TRAN_FROM_ACCT_FLG[2];
   char FR_TRAN_TO_ACCT_FLG[2];
   sqlint32 FR_USAGE_UPDATE_BITS;
   char FR_PAN_TOKEN[20];
   char FR_TOKEN_ASSURANCE[3];
   char FR_TOKEN_REQUESTOR_ID[12];
   char FR_PAN_INDICATOR[3];
   char FR_PAN_RANGE[20];
   char FR_TOKEN_EXP_DATE[5];
   char FR_TOKEN_REF_NUMBER[49];
   char FR_TOKEN_SER_PROVIDER[12];
   char FR_TOKEN_STATUS[2];
   char FR_ACQ_ROUTING_NO[12];
   char FR_ISS_ROUTING_NO[12];
   char FR_TRANS_ROUTING_NO[12];
   char FR_DEST_ROUTING_NO[12];
   char FR_AUTH_LCYCLE_TRACE[16];
   char FR_HCE_ACTIVATE_RESULT[2];
   char FR_AAM_VELOCITY_RESULT[3];
   short  FR_LUK_ELAPSED_TIME;
   short  FR_LUK_TRAN_COUNT;
   double FR_LUK_AMT_TRAN;
   char FR_TOKEN_DEVICE_TYPE[3];
   char FR_TOKEN_DEVICE_LOC[26];
   char FR_TOKEN_CARD_SEQ_NO[4];
   char FR_TOKEN_VERSION[7];
   char FR_NETWORK_PROGRAM[11];
   char FR_WEIGHTED_AVE_FLG[2];
   char FR_TOKEN_REF_NUMBER_EXT[17];
   char FR_ADDL_TRAN_DISP[3];
   struct
   {
      short  FR_ADDL_TRAN_RESULT_len;
	  char FR_ADDL_TRAN_RESULT_data[90];
   } FR_ADDL_TRAN_RESULT;
   char FR_SWIFT_CODE[12];
   char FR_IFSC_CODE[12];
   char FR_LOCAL_RETRIEVAL_REF_NO[13];
   char FR_TOKEN_ACT_CODE[3];
   char FR_TOKEN_STATUS_CODE[3];
   char FR_TOKEN_ISSUER_PROC[9];
   char FR_TOKEN_REQ_TSTAMP[17];
   char FR_TOKEN_RESP_TSTAMP[17];
   char FR_TOKEN_TIME_AT_TSP[6];
   char FR_VISA_ATM_TRAN_ID[8];
   char FR_DOMAIN_CTL_RESTR[3];
   short  FR_BIN_LENGTH;
   char FR_PAN_IDENTIFIER[26];
   char FR_PYMT_ACCT_REF[30];
   char FR_EMV_3D_CAVV_VER_BY[2];
   char FR_EMV_3D_TRAN_ID[37];
   char FR_PGRM_PROTOCOL[2];
   char FR_DIR_SERV_TRAN_ID[37];
   char FR_TRAN_INT_CLASS[3];
   char FR_ACL_ECOM_IND[3];
   char FR_P1C_ACCT_TOKEN[21];
   char FR_P1C_ADL_RESP_DATA[4];
   char FR_P1C_CRDHLDR_TOKEN[21];
   char FR_PRM_ADL_RESP_DATA[4];
   char FR_SAP_ADL_RESP_DATA[4];
   struct
   {
      short  FR_ECOM_DATA_len;
      char FR_ECOM_DATA_data[99];
   } FR_ECOM_DATA;
   char FR_INST_ID_FRWD[12];
   char FR_TOKEN_DEVICE_NAME[26];
   char FR_TOKEN_ENTITY[3];
   struct
   {
      short  FR_TOKEN_TRANID_len;
      char FR_TOKEN_TRANID_data[99];
   } FR_TOKEN_TRANID;
   char FR_TOKEN_TYPE[3];
   struct
   {
      short  FR_UNFORMATTED_MICR_DATA_len;
      char FR_UNFORMATTED_MICR_DATA_data[48];
   } FR_UNFORMATTED_MICR_DATA;
   struct
   {
      short  FR_PROC_FLGS1_len;
      char FR_PROC_FLGS1_data[2];
   } FR_PROC_FLGS1;
   struct
   {
      short  FR_PROC_FLGS2_len;
      char FR_PROC_FLGS2_data[2];
   } FR_PROC_FLGS2;
   struct
   {
      short  FR_PROC_FLGS3_len;
      char FR_PROC_FLGS3_data[2];
   } FR_PROC_FLGS3;
   struct
   {
      short  FR_PROC_FLGS4_len;
      char FR_PROC_FLGS4_data[2];
   } FR_PROC_FLGS4;
   struct
   {
      short  FR_PROC_BILLING_FLGS1_len;
      char FR_PROC_BILLING_FLGS1_data[2];
   } FR_PROC_BILLING_FLGS1;
   struct
   {
      short  FR_PROC_BILLING_FLGS2_len;
      char FR_PROC_BILLING_FLGS2_data[2];
   } FR_PROC_BILLING_FLGS2;
   struct
   {
      short  FR_PROC_BILLING_FLGS3_len;
      char FR_PROC_BILLING_FLGS3_data[2];
   } FR_PROC_BILLING_FLGS3;
   struct
   {
      short  FR_PROC_BILLING_FLGS4_len;
      char FR_PROC_BILLING_FLGS4_data[2];
   } FR_PROC_BILLING_FLGS4;
   struct
   {
      short  FR_MERCH_DISP_NAME_len;
      char FR_MERCH_DISP_NAME_data[100];
   } FR_MERCH_DISP_NAME;
   char FL_TRANSACTION_ID[37];
   char FL_ACT_CODE[4];
   char FL_APPROVAL_CODE[7];
   char FL_AUTH_BY[2];
   char FL_CARD_ACPT_TERM_ID[17];
   char FL_FIN_TYPE[4];
   char FL_INST_ID_ACQ[12];
   char FL_INST_ID_ISS[12];
   char FL_INST_ID_RECON_ACQ[12];
   char FL_INST_ID_RECN_ACQ_B[12];
   char FL_INST_ID_RECON_ISS[12];
   char FL_INST_ID_RECN_ISS_B[12];
   char FL_INV_ORDER_NO[16];
   char FL_MAPPED_DUP_DATA[31];
   char FL_NET_TERM_ID[9];
   char FL_PAN[29];
   char FL_PAN_PREFIX[13];
   char FL_PAN_SUFFIX[5];
   char FL_PAN_TOKEN_PREFIX[13];
   char FL_PAN_TOKEN_SUFFIX[5];
   char FL_PROC_GRP_ID_ACQ_B[9];
   char FL_PROC_GRP_ID_ISS_B[9];
   char FL_PROC_ID_ACQ[9];
   char FL_PROC_ID_ACQ_B[9];
   char FL_PROC_ID_ISS[9];
   char FL_PROC_ID_ISS_B[9];
   char FL_RETRIEVAL_REF_NO[13];
   char FL_RPT_LVL_ID_B[17];
   char FL_SUBSCRIBER_IND[2];
   char FL_SYS_TRACE_AUDIT_NO[7];
   char FL_TRAN_CLASS[4];
   char FL_TRAN_TYPE_ID[11];
   char FL_TSTAMP_LOCAL[15];

   char FI_AMOUNT_OTHER[13];
   char FI_APPL_CRYPTOGRAM[17];
   char FI_APPL_ID[17];
   char FI_APPL_INTRCHG_PROF[5];
   char FI_APPL_TRAN_COUNTER[5];
   char FI_APPL_VERSION_NO[5];
   char FI_CARDH_VER_RESULT[7];
   char FI_CHIP_TOKEN_REQ_ID[12];
   char FI_COPAC_CCS_CRYPTO[17];
   char FI_CRYPTOGRAM_AMOUNT[13];
   char FI_CRYPT_INFO_DATA[3];
   char FI_DEDICATED_FILE_NAM[17];
   char FI_FORM_FACTOR_IND[33];
   char FI_ISS_APPL_DATA[65];
   char FI_ISS_AUTH_DATA[33];
   char FI_ISS_DISCR_DATA[65];
   char FI_ISS_SCRIPT1_DATA[513];
   char FI_ISS_SCRIPT2_DATA[513];
   char FI_ISS_SCRIPT_RESULT[41];
   char FI_TERMINAL_TYPE[3];
   char FI_TERM_CAPABILITIES[7];
   char FI_TERM_COUNTRY_CODE[4];
   char FI_TERM_SERIAL_NO[9];
   char FI_TERM_VERIFY_RESULT[11];
   char FI_TRAN_CATEGORY_CODE[2];
   char FI_TRAN_CURRENCY_CODE[4];
   char FI_TRAN_DATE[7];
   char FI_TRAN_SEQ_COUNTER[9];
   char FI_TRAN_TYPE[3];
   char FI_UNPREDICTABLE_NO[11];
   char FI_DERIVATION_KEY_IDX[3];
   char FI_ARPC_CRYPTOGRAM[17];
   char FI_ARPC_RESPCODE[3];
   short  FI_UNIQUENESS_KEY;

   //Multi_route columns
   char FM_PRIMARY_PROC_ID[9];
   char FM_PRIMARY_PROCESS_ID[7];
   char FM_PRIMARY_TD_PROCESS_ID[16];
   char FM_PRIMARY_TD_MATCH_OPT[2];
   char FM_PROC_ID[9];
   char FM_PROCESS_ID[7];
   char FM_TD_PROCESS_ID[16];
   char FM_TD_MATCH_OPT[2];
   char FM_MULTI_RTE_OPT[2];
   char FM_STANDIN_IND[2];
   char FM_COMPLETION_IND[2];
   char FM_ADVICE_IND[2];
   char FM_DENY_OPT[2];
   char FM_PREAUTH_IND[2];
   char FM_REQUEST_BAL_IND[2];
   char FM_RESPONSE_BAL_IND[2];
   char FM_APPROVED_BY[2];
   char FM_ADVICE_TRAN[2];
   char FM_TDRESP[2];
   short  FM_UNIQUENESS_KEY;

   struct
   {
      short length;
      char data[32000];
   } FM_INSERT;

   short  FFR_SEQ_NO;
   char FFR_INST_ID_RECON_ISS[12];
   char FFR_INST_ID_RECON_ACQ[12];
   char FFR_FRAUD_SCORE[4];
   char FFR_SUB_CLASS_CODE[3];
   char FFR_FRAUD_ID[40];
   char FFR_CARD_BIN_HASH[24];
   struct
   {
      short  FFR_RULE_NAME_len;
      char FFR_RULE_NAME_data[64];
   } FFR_RULE_NAME;

   struct
   {
      short length;
      char data[4096];
   } FFR_INSERT;

   struct
   {
      short length;
      char data[4096];
   } FI_INSERT;

   struct
   {
      short length;
      char data[32000];
   } FL_INSERT;
   struct
   {
      short length;
      char data[4096];
   } FL_SELECT;
   struct
   {
      short length;
      char data[4096];
   } FL_UPDATE;
   struct
   {
      short length;
      char data[32000];
   } FINU_INSERT;
   struct
   {
      short length;
      char data[32000];
   } FINU_UPDATE;
   char FR_BIN_EXCLUSION_GRP[9];
   char FR_CARD_LOGO_ID[9];
   char FR_NET_INTRCHG_TIER[6];
   char FR_INST_TIER[3];
   char FR_CARD_INTRCHG_ID[9];
   char FR_PROGRAM_ID[3];
   char FR_PIN_FLG[2];
   struct
   {
      short  FR_ADL_DATA_NATIONAL_len;
      char FR_ADL_DATA_NATIONAL_data[999];
   } FR_ADL_DATA_NATIONAL;
   char FR_MULTI_CLEAR_SEQ_NO[3];
   char FR_MULTI_CLEAR_COUNT[3];
   char FR_BRIDGE_ACQ_FLG[2];
   char FR_BRIDGE_ISS_FLG[2];
   char FR_COOPER_SCORE[4];
   char FR_COOPER_REASON[3];
   struct
   {
      short  FR_AMX_FRAUD_DATA_len;
      char FR_AMX_FRAUD_DATA_data[52];
   } FR_AMX_FRAUD_DATA;
   char FR_ISSUER_SCRIPT_FLG[2];
   struct
   {
      short  FR_SELLER_EMAIL_len;
      char FR_SELLER_EMAIL_data[40];
   } FR_SELLER_EMAIL;
   struct
   {
      short  FR_SELLER_PHONE_len;
      char FR_SELLER_PHONE_data[20];
   } FR_SELLER_PHONE;
   struct
   {
      short  FR_SELLER_ID_len;
      char FR_SELLER_ID_data[20];
   } FR_SELLER_ID;
   char FR_FORCE_POST_DROP_IND[2];
   char FR_FP_HOLD_MATCH_FLG[2];
   char FR_ODE_INST_ID_FRWD[12];
   char FR_ODE_DATE_TIME_XMIT[11];
   char FR_DATE_TIME_XMIT[11];
   short  FR_PAN_TOKEN_BIN_LEN;
   struct
   {
      short  FR_TOKEN_DEVICE_ID_len;
      char FR_TOKEN_DEVICE_ID_data[48];
   } FR_TOKEN_DEVICE_ID;
   char FR_WALLET_REASON[7];
   short  FX_INDEX_NUMBER;
   char FX_INDNAME[129];
   char FX_TABNAME[12] = "FIN_L200503";
   char FX_TABSCHEMA[129];


/*
EXEC SQL END DECLARE SECTION;
*/

#line 947 "CXOSD206.sqx"



/*
EXEC SQL DECLARE D1 CURSOR FOR D2S1;
*/

#line 949 "CXOSD206.sqx"


/*
EXEC SQL DECLARE D2 CURSOR FOR D2S2;
*/

#line 950 "CXOSD206.sqx"

//## end module%4915EB0E01D4.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

// Class dndb2database::UDBAddFinancialCommand

UDBAddFinancialCommand::UDBAddFinancialCommand()
  //## begin UDBAddFinancialCommand::UDBAddFinancialCommand%4915E99F001F_const.hasinit preserve=no
      : m_pBuffer(0),
        m_iPrevColumnNumber(0),
        m_iRetryCount(0),
        m_nState(PREPARE_SELECT_FIN_L),
        m_iTotalUpdateFinancialColumns(0),
        m_siUNIQUENESS_KEY(0)
  //## end UDBAddFinancialCommand::UDBAddFinancialCommand%4915E99F001F_const.hasinit
  //## begin UDBAddFinancialCommand::UDBAddFinancialCommand%4915E99F001F_const.initialization preserve=yes
  //## end UDBAddFinancialCommand::UDBAddFinancialCommand%4915E99F001F_const.initialization
{
  //## begin dndb2database::UDBAddFinancialCommand::UDBAddFinancialCommand%4915E99F001F_const.body preserve=yes
   memcpy(m_sID,"D206",4);
   string strSQL("INSERT INTO ");
   strSQL.reserve(10000);
   strSQL += Database::instance()->qualifier();
   strSQL += ".FIN_LOCATOR";
   strSQL += " (TSTAMP_TRANS,UNIQUENESS_KEY,";
   strSQL += "ACCT_ID_1,AMT_RECON_NET,";
   strSQL += "CUR_RECON_NET,FUNC_CODE,MERCH_TYPE,";
   strSQL += "DATE_RECON_ACQ,DATE_RECON_ISS,PAN_TOKEN,";
   strSQL += "CARD_ACPT_BUS_CODE,COUNTRY_ACQ_INST,TRAN_DISPOSITION,";
   strSQL += "CARD_ACPT_ID,POS_CRD_DAT_IN_MOD,ACT_CODE,";
   strSQL += "APPROVAL_CODE,AUTH_BY,CARD_ACPT_TERM_ID,";
   strSQL += "FIN_TYPE,INST_ID_ACQ,INST_ID_ISS,";
   strSQL += "INST_ID_RECN_ACQ_B,INST_ID_RECN_ISS_B,";
   strSQL += "INST_ID_RECON_ACQ,INST_ID_RECON_ISS,";
   strSQL += "MAPPED_DUP_DATA,NET_TERM_ID,PAN,";
   strSQL += "PROC_GRP_ID_ACQ_B,PROC_GRP_ID_ISS_B,";
   strSQL += "PROC_ID_ACQ,PROC_ID_ACQ_B,PROC_ID_ISS,PROC_ID_ISS_B,";
   strSQL += "RETRIEVAL_REF_NO,RPT_LVL_ID_B,SUBSCRIBER_IND,";
   strSQL += "SYS_TRACE_AUDIT_NO,TRAN_CLASS,TRAN_TYPE_ID,";
   strSQL += "TSTAMP_LOCAL,PAN_PREFIX,INV_ORDER_NO,";
   strSQL += "PAN_SUFFIX,PAN_TOKEN_PREFIX,PAN_TOKEN_SUFFIX,";
   strSQL += "TRANSACTION_ID)";
   strSQL += " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
   strSQL += ",?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
   strSQL += ",?,?,?,?,?,?)";
   memcpy(FL_INSERT.data,strSQL.data(),strSQL.length());
   FL_INSERT.length = strSQL.length();

   strSQL = "INSERT INTO ";
   strSQL += Database::instance()->qualifier();
   strSQL += ".FIN_ICCYYYYMM";
   strSQL += " (";
   strSQL += "AMOUNT_OTHER,APPL_CRYPTOGRAM,APPL_ID,APPL_INTRCHG_PROF,";
   strSQL += "APPL_TRAN_COUNTER,APPL_VERSION_NO,";
   strSQL += "CARDH_VER_RESULT,CHIP_TOKEN_REQ_ID,COPAC_CCS_CRYPTO,CRYPTOGRAM_AMOUNT,";
   strSQL += "CRYPT_INFO_DATA,DEDICATED_FILE_NAM,FORM_FACTOR_IND,ISS_APPL_DATA,";
   strSQL += "ISS_AUTH_DATA,ISS_DISCR_DATA,";
   strSQL += "ISS_SCRIPT1_DATA,ISS_SCRIPT2_DATA,ISS_SCRIPT_RESULT,";
   strSQL += "TERMINAL_TYPE,TERM_CAPABILITIES,";
   strSQL += "TERM_COUNTRY_CODE,TERM_SERIAL_NO,TERM_VERIFY_RESULT,";
   strSQL += "TRAN_CATEGORY_CODE,TRAN_CURRENCY_CODE,";
   strSQL += "TRAN_DATE,TRAN_SEQ_COUNTER,TRAN_TYPE,UNPREDICTABLE_NO,";
   strSQL += "DERIVATION_KEY_IDX,ARPC_CRYPTOGRAM,ARPC_RESPCODE,";
   strSQL += "TSTAMP_TRANS,UNIQUENESS_KEY)";
   strSQL += " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?";
   strSQL += ",?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
   memcpy(FI_INSERT.data,strSQL.data(),strSQL.length());
   FI_INSERT.length = strSQL.length();

   strSQL = "INSERT INTO ";
   strSQL += Database::instance()->qualifier();
   strSQL += ".FIN_ROUTEYYYYMM";
   strSQL += " (";
   strSQL += "PRIMARY_PROC_ID,PRIMARY_PROCESS_ID,PRIMARY_TD_PROCESS_ID,";
   strSQL += "PRIMARY_TD_MATCH_OPT,PROC_ID,";
   strSQL += "PROCESS_ID,TD_PROCESS_ID,";
   strSQL += "TD_MATCH_OPT,MULTI_RTE_OPT,";
   strSQL += "STANDIN_IND,COMPLETION_IND,";
   strSQL += "ADVICE_IND,DENY_OPT,";
   strSQL += "PREAUTH_IND,REQUEST_BAL_IND,";
   strSQL += "RESPONSE_BAL_IND,APPROVED_BY,";
   strSQL += "ADVICE_TRAN,TDRESP,";
   strSQL += "TSTAMP_TRANS,UNIQUENESS_KEY)";
   strSQL += " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
   memcpy(FM_INSERT.data,strSQL.data(),strSQL.length());
   FM_INSERT.length = strSQL.length();

   strSQL = "INSERT INTO ";
   strSQL += Database::instance()->qualifier();
   strSQL += ".FIN_RECORDYYYYMM";
   strSQL += " (PARTITION_KEY,UNIQUENESS_KEY,";
   strSQL += "INSERT_SEQUENCE_NO,ACCT_ID_1,";
   strSQL += "ACCT_ID_2,ACCT_ID_3,ACCT_TYPES_ISS,";
   strSQL += "ACQ_PLAT_PROD_ID,AMT_CARD_BILL,";
   strSQL += "AMT_RECON_NET,AMT_TRAN,CARD_ACPT_BUS_CODE,";
   strSQL += "CARD_ACPT_COUNTRY,CARD_ACPT_NAME_LOC,";
   strSQL += "CARD_ACPT_PST_CODE,CARD_ACPT_REGION,";
   strSQL += "CARD_SEQ_NO,CED_BUILD_NO,CIRC_ID_ACQ,";
   strSQL += "CIRC_ID_ISS,COUNTRY_ACQ_INST,COUNTRY_ISS_INST,";
   strSQL += "CUR_CARD_BILL,CUR_RECON_NET,CUR_TRAN,";
   strSQL += "DATE_RECON_ACQ,FUNC_CODE,MERCH_TYPE,";
   strSQL += "MSG_RESON_CODE_ACQ,MSG_RESON_CODE_ISS,";
   strSQL += "NET_ID_ACQ,NET_ID_ISS,POS_CRDHLDR_A_METH,";
   strSQL += "REIMBURSEMENT_ATTR,REV_BY,TRAN_DISPOSITION,";
   strSQL += "TSTAMP_TRANS,ACCT_QUAL_1,ACCT_QUAL_2,";
   strSQL += "ADL_DATA_PRIV_ACQ,ADL_RESP_DATA,AMT_RECON_ACQ,";
   strSQL += "AMT_RECON_ISS,AP_FLG,";
   strSQL += "CAN_ITEM_VALUE0,CAN_ITEM_VALUE1,CAN_ITEM_VALUE2,";
   strSQL += "CAN_ITEM_VALUE3,CAN_ITEM_VALUE4,CAN_ITEM_VALUE5,";
   strSQL += "CAN_ITEM_VALUE6,CAN_ITEM_VALUE7,";
   strSQL += "CAN_NO_ITEMS_DISP0,CAN_NO_ITEMS_DISP1,";
   strSQL += "CAN_NO_ITEMS_DISP2,CAN_NO_ITEMS_DISP3,";
   strSQL += "CAN_NO_ITEMS_DISP4,CAN_NO_ITEMS_DISP5,";
   strSQL += "CAN_NO_ITEMS_DISP6,CAN_NO_ITEMS_DISP7,";
   strSQL += "CAN_ORIG_NO_ITEMS0,CAN_ORIG_NO_ITEMS1,";
   strSQL += "CAN_ORIG_NO_ITEMS2,CAN_ORIG_NO_ITEMS3,";
   strSQL += "CAN_ORIG_NO_ITEMS4,CAN_ORIG_NO_ITEMS5,";
   strSQL += "CAN_ORIG_NO_ITEMS6,CAN_ORIG_NO_ITEMS7,";
   strSQL += "CARD_ACPT_ID,CARD_OWNER,CARD_TYPE,CAVV_RESULT,";
   strSQL += "CNV_CRD_BIL_DE_POS,CNV_CRD_BIL_RATE,";
   strSQL += "CNV_RCN_ACQ_DE_POS,CNV_RCN_ACQ_RATE,";
   strSQL += "CNV_RCN_ISS_DE_POS,CNV_RCN_ISS_RATE,";
   strSQL += "CNV_RCN_NET_DE_POS,CNV_RCN_NET_RATE,";
   strSQL += "CRD_ACP_NAM_FMTFLG,CUR_RECON_ACQ,CUR_RECON_ISS,";
   strSQL += "CUR_TYPE,CVV_CVC_RESULT,CVV2_CVC2_RESULT,";
   strSQL += "DATA_PRIV_ACQ,DATA_PRIV_ACQ_FMT,";
   strSQL += "DATA_PRIV_ISS,DATA_PRIV_ISS_FMT,";
   strSQL += "DATE_EXP,DATE_RECON_ISS,DRAFT_CAPTURE_FLG,";
   strSQL += "EXCHG_MASTER,EXCHG_SETL,";
   strSQL += "F_ADL_DEC_POS0,F_ADL_DEC_POS1,F_ADL_DEC_POS2,";
   strSQL += "F_ADL_DEC_POS3,F_ADL_DEC_POS4,F_ADL_DEC_POS5,";
   strSQL += "F_AMT0,F_AMT1,F_AMT2,F_AMT3,F_AMT4,F_AMT5,";
   strSQL += "F_AMT_RECON_ACQ0,F_AMT_RECON_ACQ1,";
   strSQL += "F_AMT_RECON_ACQ2,F_AMT_RECON_ACQ3,";
   strSQL += "F_AMT_RECON_ACQ4,F_AMT_RECON_ACQ5,";
   strSQL += "F_AMT_RECON_ISS0,F_AMT_RECON_ISS1,";
   strSQL += "F_AMT_RECON_ISS2,F_AMT_RECON_ISS3,";
   strSQL += "F_AMT_RECON_ISS4,F_AMT_RECON_ISS5,";
   strSQL += "F_AMT_RECON_NET0,F_AMT_RECON_NET1,";
   strSQL += "F_AMT_RECON_NET2,F_AMT_RECON_NET3,";
   strSQL += "F_AMT_RECON_NET4,F_AMT_RECON_NET5,";
   strSQL += "F_CNV_ACQ_DEC_POS0,F_CNV_ACQ_DEC_POS1,";
   strSQL += "F_CNV_ACQ_DEC_POS2,F_CNV_ACQ_DEC_POS3,";
   strSQL += "F_CNV_ACQ_DEC_POS4,F_CNV_ACQ_DEC_POS5,";
   strSQL += "F_CNV_ACQ_RATE0,F_CNV_ACQ_RATE1,";
   strSQL += "F_CNV_ACQ_RATE2,F_CNV_ACQ_RATE3,";
   strSQL += "F_CNV_ACQ_RATE4,F_CNV_ACQ_RATE5,";
   strSQL += "F_CNV_ISS_DEC_POS0,F_CNV_ISS_DEC_POS1,";
   strSQL += "F_CNV_ISS_DEC_POS2,F_CNV_ISS_DEC_POS3,";
   strSQL += "F_CNV_ISS_DEC_POS4,F_CNV_ISS_DEC_POS5,";
   strSQL += "F_CNV_ISS_RATE0,F_CNV_ISS_RATE1,F_CNV_ISS_RATE2,";
   strSQL += "F_CNV_ISS_RATE3,F_CNV_ISS_RATE4,F_CNV_ISS_RATE5,";
   strSQL += "F_CUR_CODE0,F_CUR_CODE1,F_CUR_CODE2,";
   strSQL += "F_CUR_CODE3,F_CUR_CODE4,F_CUR_CODE5,";
   strSQL += "F_CUR_RECON_ACQ0,F_CUR_RECON_ACQ1,";
   strSQL += "F_CUR_RECON_ACQ2,F_CUR_RECON_ACQ3,";
   strSQL += "F_CUR_RECON_ACQ4,F_CUR_RECON_ACQ5,";
   strSQL += "F_CUR_RECON_ISS0,F_CUR_RECON_ISS1,";
   strSQL += "F_CUR_RECON_ISS2,F_CUR_RECON_ISS3,";
   strSQL += "F_CUR_RECON_ISS4,F_CUR_RECON_ISS5,";
   strSQL += "F_INITIATOR0,F_INITIATOR1,F_INITIATOR2,";
   strSQL += "F_INITIATOR3,F_INITIATOR4,F_INITIATOR5,";
   strSQL += "F_MEMO0,F_MEMO1,F_MEMO2,F_MEMO3,F_MEMO4,F_MEMO5,";
   strSQL += "F_TYPE0,F_TYPE1,F_TYPE2,F_TYPE3,F_TYPE4,F_TYPE5,";
   strSQL += "HOST_RECV_FLG,HOST_SENT_FLG,MCI_AAV_RESULT_COD,";
   strSQL += "MCI_ECS_LVL_IND,MCI_UCAF_DATA,MTI,MERCH_TIER_ID,OAR_RQST_FLG,";
   strSQL += "PAYEE,POS_CARD_CAPT_CAP,POS_CARD_PRES,";
   strSQL += "POS_CRDHLDR_AUTH,POS_CRDHLDR_AUTH_C,";
   strSQL += "POS_CRDHLDR_PRESNT,POS_CRD_DAT_IN_CAP,";
   strSQL += "POS_CRD_DAT_IN_MOD,POS_CRD_DAT_OT_CAP,";
   strSQL += "POS_OPER_ENV,POS_PIN_CAPT_CAP,";
   strSQL += "POS_TERM_OUT_CAP,PRINT_MASK_ID,REF_DATA_ACQ,";
   strSQL += "REF_DATA_ACQ_FMT,REF_DATA_ISS,REF_DATA_ISS_FMT,";
   strSQL += "TERM_CLASS,TIME_AT_AP,TIME_AT_ISS,";
   strSQL += "TIME_AT_RESP_QUE,TIME_AT_RESP_SWTCH,";
   strSQL += "TIME_AT_RQST_QUE,TIME_AT_RQST_SWTCH,";
   strSQL += "TRACK_2_DATA,TRAN_DESC,TRAN_UNIQUE_DATA,";
   strSQL += "TRAN_UNIQ_DATA_FMT,ADL_DATA_PRIV_ISS,";
   strSQL += "BIN_EXCLUSION_GRP,CARD_LOGO_ID,NET_INTRCHG_TIER,";
   strSQL += "INST_TIER,CARD_INTRCHG_ID,PROGRAM_ID,PIN_FLG,ADL_DATA_NATIONAL,";
   strSQL += "MULTI_CLEAR_SEQ_NO,MULTI_CLEAR_COUNT,";
   strSQL += "ACCT_TYPE_1,";
   strSQL += "ACCT_TYPE_2,ACCT_TYPE_3,";
   strSQL += "ADL_RESP_ACCT_IDX0,ADL_RESP_ACCT_IDX1,";
   strSQL += "ADL_RESP_ACCT_IDX2,ADL_RESP_ACCT_IDX3,";
   strSQL += "ADL_RESP_ACCT_IDX4,ADL_RESP_ACCT_IDX5,";
   strSQL += "ADL_RESP_ACCT_TYP0,ADL_RESP_ACCT_TYP1,";
   strSQL += "ADL_RESP_ACCT_TYP2,ADL_RESP_ACCT_TYP3,";
   strSQL += "ADL_RESP_ACCT_TYP4,ADL_RESP_ACCT_TYP5,";
   strSQL += "ADL_RESP_AMT0,ADL_RESP_AMT1,ADL_RESP_AMT2,";
   strSQL += "ADL_RESP_AMT3,ADL_RESP_AMT4,ADL_RESP_AMT5,";
   strSQL += "ADL_RESP_AMT_TYP0,ADL_RESP_AMT_TYP1,";
   strSQL += "ADL_RESP_AMT_TYP2,ADL_RESP_AMT_TYP3,";
   strSQL += "ADL_RESP_AMT_TYP4,ADL_RESP_AMT_TYP5,";
   strSQL += "ADL_RESP_CUR_CODE0,ADL_RESP_CUR_CODE1,";
   strSQL += "ADL_RESP_CUR_CODE2,ADL_RESP_CUR_CODE3,";
   strSQL += "ADL_RESP_CUR_CODE4,ADL_RESP_CUR_CODE5,";
   strSQL += "ADL_RQST_ACCT_IDX0,ADL_RQST_ACCT_IDX1,";
   strSQL += "ADL_RQST_ACCT_IDX2,ADL_RQST_ACCT_IDX3,";
   strSQL += "ADL_RQST_ACCT_IDX4,ADL_RQST_ACCT_IDX5,";
   strSQL += "ADL_RQST_ACCT_TYP0,ADL_RQST_ACCT_TYP1,";
   strSQL += "ADL_RQST_ACCT_TYP2,ADL_RQST_ACCT_TYP3,";
   strSQL += "ADL_RQST_ACCT_TYP4,ADL_RQST_ACCT_TYP5,";
   strSQL += "ADL_RQST_AMT0,ADL_RQST_AMT1,ADL_RQST_AMT2,";
   strSQL += "ADL_RQST_AMT3,ADL_RQST_AMT4,ADL_RQST_AMT5,";
   strSQL += "ADL_RQST_AMT_TYP0,ADL_RQST_AMT_TYP1,";
   strSQL += "ADL_RQST_AMT_TYP2,ADL_RQST_AMT_TYP3,";
   strSQL += "ADL_RQST_AMT_TYP4,ADL_RQST_AMT_TYP5,";
   strSQL += "ADL_RQST_CUR_CODE0,ADL_RQST_CUR_CODE1,";
   strSQL += "ADL_RQST_CUR_CODE2,ADL_RQST_CUR_CODE3,";
   strSQL += "ADL_RQST_CUR_CODE4,ADL_RQST_CUR_CODE5,";
   strSQL += "ALT_ROUTE_FLG,AP_APPROVAL_CODE,AP_CARD_GRP,";
   strSQL += "AP_DATA,AP_ERROR_NO,AP_ERROR_TRACE_LOC,";
   strSQL += "AP_REJ_REASON_CODE,AUTH_LCYCLE_TCODE,";
   strSQL += "AUTH_LIFECYCLE_INT,AUTH_RQST_TIMEOUT,";
   strSQL += "CARD_ACPT_COUNTY,CARD_ACPT_SPNSR_ID,";
   strSQL += "CARD_CAPT_FLG,CLERK_ID,CNTRY_RCN_ACQ_INST,";
   strSQL += "CNTRY_RCN_ISS_INST,DATE_ACTION,DATE_CAPTURE,";
   strSQL += "DATE_CNV_ACQ,DATE_CNV_ISS,DATE_EFFECTIVE,";
   strSQL += "DATE_RECON_NET,DEPOSIT_ONLY_FLG,EXTENDED_PAY_DATA,";
   strSQL += "PIN_DATA_FMT,PIN_RESULT,PMC_ERROR,PREAUTH_COMP_OPT,";
   strSQL += "PROC_BILLING_FLGS1,PROC_BILLING_FLGS2,";
   strSQL += "PROC_BILLING_FLGS3,PROC_BILLING_FLGS4,";
   strSQL += "PROC_FLGS1,PROC_FLGS2,PROC_FLGS3,PROC_FLGS4,";
   strSQL += "RECON_IND_ACQ,RESTRIC_INTCHG_GRP,SOURCE_ROUTE_ID,";
   strSQL += "SRV_GRP_INTCHG_IND,SRV_GRP_SERV_CODE,";
   strSQL += "STANDIN_ACT,STANDIN_OPTION,TRACINF_KEYTRAC_NO,";
   strSQL += "TRACK_INFO_KEY_ID,TRAN_FROM_ACCT_FLG,";
   strSQL += "TRAN_TO_ACCT_FLG,USAGE_UPDATE_BITS,";
   strSQL += "PAN_TOKEN,TOKEN_ASSURANCE,TOKEN_REQUESTOR_ID,";
   strSQL += "PAN_INDICATOR,PAN_RANGE,";
   strSQL += "TOKEN_EXP_DATE,TOKEN_REF_NUMBER,TOKEN_SER_PROVIDER,";
   strSQL += "TOKEN_STATUS,TOKEN_TRANID,TOKEN_TYPE,";
   strSQL += "UNFORMATTED_MICR_DATA,";
   strSQL += "ACQ_ROUTING_NO,ISS_ROUTING_NO,TRANS_ROUTING_NO,";
   strSQL += "DEST_ROUTING_NO,AUTH_LCYCLE_TRACE,";
   strSQL += "HCE_ACTIVATE_RESULT,AAM_VELOCITY_RESULT,";
   strSQL += "LUK_ELAPSED_TIME,LUK_TRAN_COUNT,LUK_AMT_TRAN,";
   strSQL += "TOKEN_DEVICE_TYPE,TOKEN_DEVICE_LOC,";
   strSQL += "TOKEN_CARD_SEQ_NO,TOKEN_VERSION,";
   strSQL += "NETWORK_PROGRAM,WEIGHTED_AVE_FLG,";
   strSQL += "TOKEN_REF_NUMBER_EXT,ADDL_TRAN_DISP,ADDL_TRAN_RESULT,";
   strSQL += "SWIFT_CODE,IFSC_CODE,LOCAL_RETRIEVAL_REF_NO,";
   strSQL += "TOKEN_ACT_CODE,TOKEN_STATUS_CODE,TOKEN_ISSUER_PROC,";
   strSQL += "TOKEN_REQ_TSTAMP,TOKEN_RESP_TSTAMP,TOKEN_TIME_AT_TSP,";
   strSQL += "VISA_ATM_TRAN_ID,DOMAIN_CTL_RESTR,";
   strSQL += "PGRM_PROTOCOL,DIR_SERV_TRAN_ID,TRAN_INT_CLASS,";
   strSQL += "ACL_ECOM_IND,";
   strSQL += "FO_AMT0,FO_AMT1,FO_AMT2,FO_AMT3,FO_AMT4,FO_AMT5,";
   strSQL += "FO_AMT_RECON_ACQ0,FO_AMT_RECON_ACQ1,";
   strSQL += "FO_AMT_RECON_ACQ2,FO_AMT_RECON_ACQ3,";
   strSQL += "FO_AMT_RECON_ACQ4,FO_AMT_RECON_ACQ5,";
   strSQL += "FO_AMT_RECON_ISS0,FO_AMT_RECON_ISS1,";
   strSQL += "FO_AMT_RECON_ISS2,FO_AMT_RECON_ISS3,";
   strSQL += "FO_AMT_RECON_ISS4,FO_AMT_RECON_ISS5,";
   strSQL += "FO_AMT_RECON_NET0,FO_AMT_RECON_NET1,";
   strSQL += "FO_AMT_RECON_NET2,FO_AMT_RECON_NET3,";
   strSQL += "FO_AMT_RECON_NET4,FO_AMT_RECON_NET5,";
   strSQL += "FO_CNV_ACQ_DE_POS0,FO_CNV_ACQ_DE_POS1,";
   strSQL += "FO_CNV_ACQ_DE_POS2,FO_CNV_ACQ_DE_POS3,";
   strSQL += "FO_CNV_ACQ_DE_POS4,FO_CNV_ACQ_DE_POS5,";
   strSQL += "FO_CNV_ACQ_RATE0,FO_CNV_ACQ_RATE1,";
   strSQL += "FO_CNV_ACQ_RATE2,FO_CNV_ACQ_RATE3,";
   strSQL += "FO_CNV_ACQ_RATE4,FO_CNV_ACQ_RATE5,";
   strSQL += "FO_CNV_ISS_DE_POS0,FO_CNV_ISS_DE_POS1,";
   strSQL += "FO_CNV_ISS_DE_POS2,FO_CNV_ISS_DE_POS3,";
   strSQL += "FO_CNV_ISS_DE_POS4,FO_CNV_ISS_DE_POS5,";
   strSQL += "FO_CNV_ISS_RATE0,FO_CNV_ISS_RATE1,";
   strSQL += "FO_CNV_ISS_RATE2,FO_CNV_ISS_RATE3,";
   strSQL += "FO_CNV_ISS_RATE4,FO_CNV_ISS_RATE5,";
   strSQL += "FO_CUR_CODE0,FO_CUR_CODE1,FO_CUR_CODE2,";
   strSQL += "FO_CUR_CODE3,FO_CUR_CODE4,FO_CUR_CODE5,";
   strSQL += "FO_CUR_RECON_ACQ0,FO_CUR_RECON_ACQ1,";
   strSQL += "FO_CUR_RECON_ACQ2,FO_CUR_RECON_ACQ3,";
   strSQL += "FO_CUR_RECON_ACQ4,FO_CUR_RECON_ACQ5,";
   strSQL += "FO_CUR_RECON_ISS0,FO_CUR_RECON_ISS1,";
   strSQL += "FO_CUR_RECON_ISS2,FO_CUR_RECON_ISS3,";
   strSQL += "FO_CUR_RECON_ISS4,FO_CUR_RECON_ISS5,";
   strSQL += "FO_DEC_POS0,FO_DEC_POS1,FO_DEC_POS2,";
   strSQL += "FO_DEC_POS3,FO_DEC_POS4,FO_DEC_POS5,";
   strSQL += "FO_INITIATOR0,FO_INITIATOR1,FO_INITIATOR2,";
   strSQL += "FO_INITIATOR3,FO_INITIATOR4,FO_INITIATOR5,";
   strSQL += "FO_MEMO0,FO_MEMO1,FO_MEMO2,";
   strSQL += "FO_MEMO3,FO_MEMO4,FO_MEMO5,";
   strSQL += "FO_TYPE0,FO_TYPE1,FO_TYPE2,";
   strSQL += "FO_TYPE3,FO_TYPE4,FO_TYPE5,";
   strSQL += "O_AMT_CARD_BILL,O_AMT_RECON_ACQ,";
   strSQL += "O_AMT_RECON_ISS,O_AMT_RECON_NET,O_AMT_TRAN,";
   strSQL += "ODE_INST_ID_ACQ,ODE_MTI,ODE_SYS_TRA_AUD_NO,";
   strSQL += "ODE_TSTAMP_LOCL_TR,TSTAMP_REV_CREATED,";
   strSQL += "ADTL_DATA_FEE,ISS_ACQ_TYPE_FEE,";
   strSQL += "NET_UNIQUE_DAT_FEE,BRANCH_ID_ACQ,";
   strSQL += "CNTRY_REC_INST_ADJ,CNTRY_REQ_INST_ADJ,";
   strSQL += "INST_ID_REC_ADJ,INST_ID_REQ_ADJ,";
   strSQL += "NET_IND_ADJ,ORIG_AMT_TRAN_ADJ,";
   strSQL += "REQ_ACQ_ISS_IND,TRACE_DATA_ADJ,";
   strSQL += "TSTAMP_LOCAL_ADJ,TSTAMP_TRANS_ADJ,";
   strSQL += "EXTENSION_DATA_ADJ,";
   strSQL += "BRIDGE_ACQ_FLG,BRIDGE_ISS_FLG,";
   strSQL += "BIN_LENGTH,PAN_IDENTIFIER,";
   strSQL += "PYMT_ACCT_REF,MERCH_DISP_NAME,";
   strSQL += "EMV_3D_CAVV_VER_BY,EMV_3D_TRAN_ID,";
   strSQL += "COOPER_SCORE,COOPER_REASON,AMX_FRAUD_DATA,";
   strSQL += "ISSUER_SCRIPT_FLG,";
   strSQL += "P1C_ACCT_TOKEN,P1C_ADL_RESP_DATA,";
   strSQL += "P1C_CRDHLDR_TOKEN,PRM_ADL_RESP_DATA,";
   strSQL += "SAP_ADL_RESP_DATA,ECOM_DATA,INST_ID_FRWD,";
   strSQL += "TOKEN_DEVICE_NAME,TOKEN_ENTITY,";
   strSQL += "SELLER_EMAIL,";
   strSQL += "SELLER_PHONE,";
   strSQL += "SELLER_ID,";
   strSQL += "FORCE_POST_DROP_IND,";
   strSQL += "FP_HOLD_MATCH_FLG,";
   strSQL += "ODE_INST_ID_FRWD,ODE_DATE_TIME_XMIT,";
   strSQL += "DATE_TIME_XMIT,PAN_TOKEN_BIN_LEN,";
   strSQL += "TOKEN_DEVICE_ID,WALLET_REASON)";
   strSQL += " VALUES ";
   strSQL += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,";
   strSQL += "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
   memcpy(FINU_INSERT.data,strSQL.data(),strSQL.length());
   FINU_INSERT.length = strSQL.length();

   strSQL = "INSERT INTO ";
   strSQL += Database::instance()->qualifier();
   strSQL += ".FIN_FRAUD_RULE_YYYYMM";
   strSQL += " (";
   strSQL += "TSTAMP_TRANS,UNIQUENESS_KEY,";
   strSQL += "SEQ_NO,INST_ID_RECON_ISS,";
   strSQL += "INST_ID_RECON_ACQ,RULE_NAME,";
   strSQL += "FRAUD_SCORE,SUB_CLASS_CODE,";
   strSQL += "FRAUD_ID,CARD_BIN_HASH)";
   strSQL += " VALUES (?,?,?,?,?,?,?,?,?,?)";
   memcpy(FFR_INSERT.data,strSQL.data(),strSQL.length());
   FFR_INSERT.length = strSQL.length();

   strSQL = "SELECT TSTAMP_TRANS,FIN_TYPE,UNIQUENESS_KEY FROM ";
   strSQL += Database::instance()->qualifier();
   strSQL += ".FIN_LOCATOR";
   strSQL += " WHERE TSTAMP_LOCAL = ?";
   strSQL += " AND MAPPED_DUP_DATA = ?";
   strSQL += " AND NET_TERM_ID = ?";
   strSQL += " AND PAN = ?";
   strSQL += " AND RETRIEVAL_REF_NO = ?";
   strSQL += " AND TRAN_TYPE_ID = ?";
   strSQL += " AND SYS_TRACE_AUDIT_NO = ?";
   strSQL += " AND ACT_CODE = ?";
   strSQL += " AND AUTH_BY = ?";
   strSQL += " AND CARD_ACPT_TERM_ID = ?";
   memcpy(FL_SELECT.data,strSQL.data(),strSQL.length());
   FL_SELECT.length = strSQL.length();

   strSQL = "UPDATE ";
   strSQL += Database::instance()->qualifier();
   strSQL += ".FIN_RECORDYYYYMM";
   strSQL += " SET ACCT_ID_1 = ?,";
   strSQL += "ACCT_ID_2 = ?,ACCT_ID_3 = ?,ACCT_TYPES_ISS = ?,";
   strSQL += "ACQ_PLAT_PROD_ID = ?,AMT_CARD_BILL = ?,";
   strSQL += "AMT_RECON_NET = ?,AMT_TRAN = ?,CARD_ACPT_BUS_CODE= ?,";
   strSQL += "CARD_ACPT_COUNTRY = ?,CARD_ACPT_NAME_LOC = ?,";
   strSQL += "CARD_ACPT_PST_CODE = ?,CARD_ACPT_REGION = ?,";
   strSQL += "CARD_SEQ_NO = ?,CED_BUILD_NO = ?,CIRC_ID_ACQ = ?,";
   strSQL += "CIRC_ID_ISS = ?,COUNTRY_ACQ_INST = ?,COUNTRY_ISS_INST = ?,";
   strSQL += "CUR_CARD_BILL = ?,CUR_RECON_NET = ?,CUR_TRAN = ?,";
   strSQL += "DATE_RECON_ACQ = ?,FUNC_CODE = ?,MERCH_TYPE = ?,";
   strSQL += "MSG_RESON_CODE_ACQ = ?,MSG_RESON_CODE_ISS = ?,";
   strSQL += "NET_ID_ACQ = ?,NET_ID_ISS = ?,POS_CRDHLDR_A_METH = ?,";
   strSQL += "REIMBURSEMENT_ATTR = ?,REV_BY = ?,TRAN_DISPOSITION = ?,";
   strSQL += "TSTAMP_TRANS = ?,ACCT_QUAL_1 = ?,ACCT_QUAL_2 = ?,";
   strSQL += "ADL_DATA_PRIV_ACQ = ?,ADL_RESP_DATA = ?,AMT_RECON_ACQ = ?,";
   strSQL += "AMT_RECON_ISS = ?,AP_FLG = ?,";
   strSQL += "CAN_ITEM_VALUE0 = ?,CAN_ITEM_VALUE1 = ?,CAN_ITEM_VALUE2 = ?,";
   strSQL += "CAN_ITEM_VALUE3 = ?,CAN_ITEM_VALUE4 = ?,CAN_ITEM_VALUE5 = ?,";
   strSQL += "CAN_ITEM_VALUE6 = ?,CAN_ITEM_VALUE7 = ?,";
   strSQL += "CAN_NO_ITEMS_DISP0 = ?,CAN_NO_ITEMS_DISP1 = ?,";
   strSQL += "CAN_NO_ITEMS_DISP2 = ?,CAN_NO_ITEMS_DISP3 = ?,";
   strSQL += "CAN_NO_ITEMS_DISP4 = ?,CAN_NO_ITEMS_DISP5 = ?,";
   strSQL += "CAN_NO_ITEMS_DISP6 = ?,CAN_NO_ITEMS_DISP7 = ?,";
   strSQL += "CAN_ORIG_NO_ITEMS0 = ?,CAN_ORIG_NO_ITEMS1 = ?,";
   strSQL += "CAN_ORIG_NO_ITEMS2 = ?,CAN_ORIG_NO_ITEMS3 = ?,";
   strSQL += "CAN_ORIG_NO_ITEMS4 = ?,CAN_ORIG_NO_ITEMS5 = ?,";
   strSQL += "CAN_ORIG_NO_ITEMS6 = ?,CAN_ORIG_NO_ITEMS7 = ?,";
   strSQL += "CARD_ACPT_ID = ?,CARD_OWNER = ?,CARD_TYPE = ?,CAVV_RESULT = ?,";
   strSQL += "CNV_CRD_BIL_DE_POS = ?,CNV_CRD_BIL_RATE = ?,";
   strSQL += "CNV_RCN_ACQ_DE_POS = ?,CNV_RCN_ACQ_RATE = ?,";
   strSQL += "CNV_RCN_ISS_DE_POS = ?,CNV_RCN_ISS_RATE = ?,";
   strSQL += "CNV_RCN_NET_DE_POS = ?,CNV_RCN_NET_RATE = ?,";
   strSQL += "CRD_ACP_NAM_FMTFLG = ?,CUR_RECON_ACQ = ?,CUR_RECON_ISS = ?,";
   strSQL += "CUR_TYPE = ?,CVV_CVC_RESULT = ?,CVV2_CVC2_RESULT = ?,";
   strSQL += "DATA_PRIV_ACQ = ?,DATA_PRIV_ACQ_FMT = ?,";
   strSQL += "DATA_PRIV_ISS = ?,DATA_PRIV_ISS_FMT = ?,";
   strSQL += "DATE_EXP = ?,DATE_RECON_ISS = ?,DRAFT_CAPTURE_FLG = ?,";
   strSQL += "EXCHG_MASTER = ?,EXCHG_SETL = ?,";
   strSQL += "F_ADL_DEC_POS0 = ?,F_ADL_DEC_POS1 = ?,F_ADL_DEC_POS2 = ?,";
   strSQL += "F_ADL_DEC_POS3 = ?,F_ADL_DEC_POS4 = ?,F_ADL_DEC_POS5 = ?,";
   strSQL += "F_AMT0 = ?,F_AMT1 = ?,F_AMT2 = ?,";
   strSQL += "F_AMT3 = ?,F_AMT4 = ?,F_AMT5 = ?,";
   strSQL += "F_AMT_RECON_ACQ0 = ?,F_AMT_RECON_ACQ1 = ?,";
   strSQL += "F_AMT_RECON_ACQ2 = ?,F_AMT_RECON_ACQ3 = ?,";
   strSQL += "F_AMT_RECON_ACQ4 = ?,F_AMT_RECON_ACQ5 = ?,";
   strSQL += "F_AMT_RECON_ISS0 = ?,F_AMT_RECON_ISS1 = ?,";
   strSQL += "F_AMT_RECON_ISS2 = ?,F_AMT_RECON_ISS3 = ?,";
   strSQL += "F_AMT_RECON_ISS4 = ?,F_AMT_RECON_ISS5 = ?,";
   strSQL += "F_AMT_RECON_NET0 = ?,F_AMT_RECON_NET1 = ?,";
   strSQL += "F_AMT_RECON_NET2 = ?,F_AMT_RECON_NET3 = ?,";
   strSQL += "F_AMT_RECON_NET4 = ?,F_AMT_RECON_NET5 = ?,";
   strSQL += "F_CNV_ACQ_DEC_POS0 = ?,F_CNV_ACQ_DEC_POS1 = ?,";
   strSQL += "F_CNV_ACQ_DEC_POS2 = ?,F_CNV_ACQ_DEC_POS3 = ?,";
   strSQL += "F_CNV_ACQ_DEC_POS4 = ?,F_CNV_ACQ_DEC_POS5 = ?,";
   strSQL += "F_CNV_ACQ_RATE0 = ?,F_CNV_ACQ_RATE1 = ?,";
   strSQL += "F_CNV_ACQ_RATE2 = ?,F_CNV_ACQ_RATE3 = ?,";
   strSQL += "F_CNV_ACQ_RATE4 = ?,F_CNV_ACQ_RATE5 = ?,";
   strSQL += "F_CNV_ISS_DEC_POS0 = ?,F_CNV_ISS_DEC_POS1 = ?,";
   strSQL += "F_CNV_ISS_DEC_POS2 = ?,F_CNV_ISS_DEC_POS3 = ?,";
   strSQL += "F_CNV_ISS_DEC_POS4 = ?,F_CNV_ISS_DEC_POS5 = ?,";
   strSQL += "F_CNV_ISS_RATE0 = ?,F_CNV_ISS_RATE1 = ?,";
   strSQL += "F_CNV_ISS_RATE2 = ?,F_CNV_ISS_RATE3 = ?,";
   strSQL += "F_CNV_ISS_RATE4 = ?,F_CNV_ISS_RATE5 = ?,";
   strSQL += "F_CUR_CODE0 = ?,F_CUR_CODE1 = ?,F_CUR_CODE2 = ?,";
   strSQL += "F_CUR_CODE3 = ?,F_CUR_CODE4 = ?,F_CUR_CODE5 = ?,";
   strSQL += "F_CUR_RECON_ACQ0 = ?,F_CUR_RECON_ACQ1 = ?,";
   strSQL += "F_CUR_RECON_ACQ2 = ?,F_CUR_RECON_ACQ3 = ?,";
   strSQL += "F_CUR_RECON_ACQ4 = ?,F_CUR_RECON_ACQ5 = ?,";
   strSQL += "F_CUR_RECON_ISS0 = ?,F_CUR_RECON_ISS1 = ?,";
   strSQL += "F_CUR_RECON_ISS2 = ?,F_CUR_RECON_ISS3 = ?,";
   strSQL += "F_CUR_RECON_ISS4 = ?,F_CUR_RECON_ISS5 = ?,";
   strSQL += "F_INITIATOR0 = ?,F_INITIATOR1 = ?,F_INITIATOR2 = ?,";
   strSQL += "F_INITIATOR3 = ?,F_INITIATOR4 = ?,F_INITIATOR5 = ?,";
   strSQL += "F_MEMO0 = ?,F_MEMO1 = ?,F_MEMO2 = ?,";
   strSQL += "F_MEMO3 = ?,F_MEMO4 = ?,F_MEMO5 = ?,";
   strSQL += "F_TYPE0 = ?,F_TYPE1 = ?,F_TYPE2 = ?,";
   strSQL += "F_TYPE3 = ?,F_TYPE4 = ?,F_TYPE5 = ?,";
   strSQL += "HOST_RECV_FLG = ?,HOST_SENT_FLG = ?,";
   strSQL += "MCI_AAV_RESULT_COD = ?,MCI_ECS_LVL_IND = ?,";
   strSQL += "MCI_UCAF_DATA = ?,MTI = ?,MERCH_TIER_ID = ?,OAR_RQST_FLG = ?,";
   strSQL += "PAYEE = ?,POS_CARD_CAPT_CAP = ?,POS_CARD_PRES = ?,";
   strSQL += "POS_CRDHLDR_AUTH = ?,POS_CRDHLDR_AUTH_C = ?,";
   strSQL += "POS_CRDHLDR_PRESNT = ?,POS_CRD_DAT_IN_CAP = ?,";
   strSQL += "POS_CRD_DAT_IN_MOD = ?,POS_CRD_DAT_OT_CAP = ?,";
   strSQL += "POS_OPER_ENV = ?,POS_PIN_CAPT_CAP = ?,";
   strSQL += "POS_TERM_OUT_CAP = ?,PRINT_MASK_ID = ?,REF_DATA_ACQ = ?,";
   strSQL += "REF_DATA_ACQ_FMT = ?,REF_DATA_ISS = ?,REF_DATA_ISS_FMT = ?,";
   strSQL += "TERM_CLASS = ?,TIME_AT_AP = ?,TIME_AT_ISS = ?,";
   strSQL += "TIME_AT_RESP_QUE = ?,TIME_AT_RESP_SWTCH = ?,";
   strSQL += "TIME_AT_RQST_QUE = ?,TIME_AT_RQST_SWTCH = ?,";
   strSQL += "TRACK_2_DATA = ?,TRAN_DESC = ?,TRAN_UNIQUE_DATA = ?,";
   strSQL += "TRAN_UNIQ_DATA_FMT = ?,ADL_DATA_PRIV_ISS = ?,";
   strSQL += "BIN_EXCLUSION_GRP = ?,CARD_LOGO_ID = ?,NET_INTRCHG_TIER = ?,";
   strSQL += "INST_TIER = ?,CARD_INTRCHG_ID = ?,PROGRAM_ID = ?,PIN_FLG = ?,";
   strSQL += "ADL_DATA_NATIONAL = ?,MULTI_CLEAR_SEQ_NO = ?,MULTI_CLEAR_COUNT = ?,";
   strSQL += "ACCT_TYPE_1 = ?,";
   strSQL += "ACCT_TYPE_2 = ?,ACCT_TYPE_3 = ?,";
   strSQL += "ADL_RESP_ACCT_IDX0 = ?,ADL_RESP_ACCT_IDX1 = ?,";
   strSQL += "ADL_RESP_ACCT_IDX2 = ?,ADL_RESP_ACCT_IDX3 = ?,";
   strSQL += "ADL_RESP_ACCT_IDX4 = ?,ADL_RESP_ACCT_IDX5 = ?,";
   strSQL += "ADL_RESP_ACCT_TYP0 = ?,ADL_RESP_ACCT_TYP1 = ?,";
   strSQL += "ADL_RESP_ACCT_TYP2 = ?,ADL_RESP_ACCT_TYP3 = ?,";
   strSQL += "ADL_RESP_ACCT_TYP4 = ?,ADL_RESP_ACCT_TYP5 = ?,";
   strSQL += "ADL_RESP_AMT0 = ?,ADL_RESP_AMT1 = ?,ADL_RESP_AMT2 = ?,";
   strSQL += "ADL_RESP_AMT3 = ?,ADL_RESP_AMT4 = ?,ADL_RESP_AMT5 = ?,";
   strSQL += "ADL_RESP_AMT_TYP0 = ?,ADL_RESP_AMT_TYP1 = ?,";
   strSQL += "ADL_RESP_AMT_TYP2 = ?,ADL_RESP_AMT_TYP3 = ?,";
   strSQL += "ADL_RESP_AMT_TYP4 = ?,ADL_RESP_AMT_TYP5 = ?,";
   strSQL += "ADL_RESP_CUR_CODE0 = ?,ADL_RESP_CUR_CODE1 = ?,";
   strSQL += "ADL_RESP_CUR_CODE2 = ?,ADL_RESP_CUR_CODE3 = ?,";
   strSQL += "ADL_RESP_CUR_CODE4 = ?,ADL_RESP_CUR_CODE5 = ?,";
   strSQL += "ADL_RQST_ACCT_IDX0 = ?,ADL_RQST_ACCT_IDX1 = ?,";
   strSQL += "ADL_RQST_ACCT_IDX2 = ?,ADL_RQST_ACCT_IDX3 = ?,";
   strSQL += "ADL_RQST_ACCT_IDX4 = ?,ADL_RQST_ACCT_IDX5 = ?,";
   strSQL += "ADL_RQST_ACCT_TYP0 = ?,ADL_RQST_ACCT_TYP1 = ?,";
   strSQL += "ADL_RQST_ACCT_TYP2 = ?,ADL_RQST_ACCT_TYP3 = ?,";
   strSQL += "ADL_RQST_ACCT_TYP4 = ?,ADL_RQST_ACCT_TYP5 = ?,";
   strSQL += "ADL_RQST_AMT0 = ?,ADL_RQST_AMT1 = ?,ADL_RQST_AMT2 = ?,";
   strSQL += "ADL_RQST_AMT3 = ?,ADL_RQST_AMT4 = ?,ADL_RQST_AMT5 = ?,";
   strSQL += "ADL_RQST_AMT_TYP0 = ?,ADL_RQST_AMT_TYP1 = ?,";
   strSQL += "ADL_RQST_AMT_TYP2 = ?,ADL_RQST_AMT_TYP3 = ?,";
   strSQL += "ADL_RQST_AMT_TYP4 = ?,ADL_RQST_AMT_TYP5 = ?,";
   strSQL += "ADL_RQST_CUR_CODE0 = ?,ADL_RQST_CUR_CODE1 = ?,";
   strSQL += "ADL_RQST_CUR_CODE2 = ?,ADL_RQST_CUR_CODE3 = ?,";
   strSQL += "ADL_RQST_CUR_CODE4 = ?,ADL_RQST_CUR_CODE5 = ?,";
   strSQL += "ALT_ROUTE_FLG = ?,AP_APPROVAL_CODE = ?,AP_CARD_GRP = ?,";
   strSQL += "AP_DATA = ?,AP_ERROR_NO = ?,AP_ERROR_TRACE_LOC = ?,";
   strSQL += "AP_REJ_REASON_CODE = ?,AUTH_LCYCLE_TCODE = ?,";
   strSQL += "AUTH_LIFECYCLE_INT = ?,AUTH_RQST_TIMEOUT = ?,";
   strSQL += "CARD_ACPT_COUNTY = ?,CARD_ACPT_SPNSR_ID = ?,";
   strSQL += "CARD_CAPT_FLG = ?,CLERK_ID = ?,CNTRY_RCN_ACQ_INST = ?,";
   strSQL += "CNTRY_RCN_ISS_INST = ?,DATE_ACTION = ?,DATE_CAPTURE = ?,";
   strSQL += "DATE_CNV_ACQ = ?,DATE_CNV_ISS = ?,DATE_EFFECTIVE = ?,";
   strSQL += "DATE_RECON_NET = ?,DEPOSIT_ONLY_FLG = ?,EXTENDED_PAY_DATA = ?,";
   strSQL += "PIN_DATA_FMT = ?,PIN_RESULT = ?,PMC_ERROR = ?,";
   strSQL += "PREAUTH_COMP_OPT = ?,PROC_BILLING_FLGS1 = ?,";
   strSQL += "PROC_BILLING_FLGS2 = ?,PROC_BILLING_FLGS3 = ?,";
   strSQL += "PROC_BILLING_FLGS4 = ?,PROC_FLGS1 = ?,PROC_FLGS2 = ?,";
   strSQL += "PROC_FLGS3 = ?,PROC_FLGS4 = ?,";
   strSQL += "RECON_IND_ACQ = ?,RESTRIC_INTCHG_GRP = ?,SOURCE_ROUTE_ID = ?,";
   strSQL += "SRV_GRP_INTCHG_IND = ?,SRV_GRP_SERV_CODE = ?,";
   strSQL += "STANDIN_ACT = ?,STANDIN_OPTION = ?,TRACINF_KEYTRAC_NO = ?,";
   strSQL += "TRACK_INFO_KEY_ID = ?,TRAN_FROM_ACCT_FLG = ?,";
   strSQL += "TRAN_TO_ACCT_FLG = ?,USAGE_UPDATE_BITS = ?,";
   strSQL += "PAN_TOKEN = ?,TOKEN_ASSURANCE = ?,TOKEN_REQUESTOR_ID = ?,";
   strSQL += "PAN_INDICATOR = ?,PAN_RANGE = ?,";
   strSQL += "TOKEN_EXP_DATE = ?,TOKEN_REF_NUMBER = ?,TOKEN_SER_PROVIDER = ?,";
   strSQL += "TOKEN_STATUS = ?,TOKEN_TRANID = ?,TOKEN_TYPE = ?,";
   strSQL += "UNFORMATTED_MICR_DATA = ?,";
   strSQL += "ACQ_ROUTING_NO = ?,ISS_ROUTING_NO = ?,TRANS_ROUTING_NO = ?,";
   strSQL += "DEST_ROUTING_NO = ?,AUTH_LCYCLE_TRACE = ?,";
   strSQL += "HCE_ACTIVATE_RESULT = ?,AAM_VELOCITY_RESULT = ?,";
   strSQL += "LUK_ELAPSED_TIME = ?,LUK_TRAN_COUNT = ?,LUK_AMT_TRAN = ?,";
   strSQL += "TOKEN_DEVICE_TYPE = ?,TOKEN_DEVICE_LOC = ?,";
   strSQL += "TOKEN_CARD_SEQ_NO = ?,TOKEN_VERSION = ?,";
   strSQL += "NETWORK_PROGRAM = ?,WEIGHTED_AVE_FLG = ?,";
   strSQL += "TOKEN_REF_NUMBER_EXT = ?,ADDL_TRAN_DISP = ?,ADDL_TRAN_RESULT = ?,";
   strSQL += "SWIFT_CODE = ?,IFSC_CODE = ?,LOCAL_RETRIEVAL_REF_NO = ?,";
   strSQL += "TOKEN_ACT_CODE = ?,TOKEN_STATUS_CODE = ?,TOKEN_ISSUER_PROC = ?,";
   strSQL += "TOKEN_REQ_TSTAMP = ?,TOKEN_RESP_TSTAMP = ?,TOKEN_TIME_AT_TSP = ?,";
   strSQL += "VISA_ATM_TRAN_ID = ?,DOMAIN_CTL_RESTR = ?,";
   strSQL += "PGRM_PROTOCOL = ?,DIR_SERV_TRAN_ID = ?,TRAN_INT_CLASS = ?,";
   strSQL += "ACL_ECOM_IND = ?,P1C_ACCT_TOKEN = ?,P1C_ADL_RESP_DATA =?,";
   strSQL += "P1C_CRDHLDR_TOKEN = ?,PRM_ADL_RESP_DATA = ?,SAP_ADL_RESP_DATA =?,";
   strSQL += "ECOM_DATA =?,INST_ID_FRWD =?,TOKEN_DEVICE_NAME =?,TOKEN_ENTITY =?,";
   strSQL += "FO_AMT0 = ?,FO_AMT1 = ?,FO_AMT2 = ?,";
   strSQL += "FO_AMT3 = ?,FO_AMT4 = ?,FO_AMT5 = ?,";
   strSQL += "FO_AMT_RECON_ACQ0 = ?,FO_AMT_RECON_ACQ1 = ?,";
   strSQL += "FO_AMT_RECON_ACQ2 = ?,FO_AMT_RECON_ACQ3 = ?,";
   strSQL += "FO_AMT_RECON_ACQ4 = ?,FO_AMT_RECON_ACQ5 = ?,";
   strSQL += "FO_AMT_RECON_ISS0 = ?,FO_AMT_RECON_ISS1 = ?,";
   strSQL += "FO_AMT_RECON_ISS2 = ?,FO_AMT_RECON_ISS3 = ?,";
   strSQL += "FO_AMT_RECON_ISS4 = ?,FO_AMT_RECON_ISS5 = ?,";
   strSQL += "FO_AMT_RECON_NET0 = ?,FO_AMT_RECON_NET1 = ?,";
   strSQL += "FO_AMT_RECON_NET2 = ?,FO_AMT_RECON_NET3 = ?,";
   strSQL += "FO_AMT_RECON_NET4 = ?,FO_AMT_RECON_NET5 = ?,";
   strSQL += "FO_CNV_ACQ_DE_POS0 = ?,FO_CNV_ACQ_DE_POS1 = ?,";
   strSQL += "FO_CNV_ACQ_DE_POS2 = ?,FO_CNV_ACQ_DE_POS3 = ?,";
   strSQL += "FO_CNV_ACQ_DE_POS4 = ?,FO_CNV_ACQ_DE_POS5 = ?,";
   strSQL += "FO_CNV_ACQ_RATE0 = ?,FO_CNV_ACQ_RATE1 = ?,";
   strSQL += "FO_CNV_ACQ_RATE2 = ?,FO_CNV_ACQ_RATE3 = ?,";
   strSQL += "FO_CNV_ACQ_RATE4 = ?,FO_CNV_ACQ_RATE5 = ?,";
   strSQL += "FO_CNV_ISS_DE_POS0 = ?,FO_CNV_ISS_DE_POS1 = ?,";
   strSQL += "FO_CNV_ISS_DE_POS2 = ?,FO_CNV_ISS_DE_POS3 = ?,";
   strSQL += "FO_CNV_ISS_DE_POS4 = ?,FO_CNV_ISS_DE_POS5 = ?,";
   strSQL += "FO_CNV_ISS_RATE0 = ?,FO_CNV_ISS_RATE1 = ?,";
   strSQL += "FO_CNV_ISS_RATE2 = ?,FO_CNV_ISS_RATE3 = ?,";
   strSQL += "FO_CNV_ISS_RATE4 = ?,FO_CNV_ISS_RATE5 = ?,";
   strSQL += "FO_CUR_CODE0 = ?,FO_CUR_CODE1 = ?,FO_CUR_CODE2 = ?,";
   strSQL += "FO_CUR_CODE3 = ?,FO_CUR_CODE4 = ?,FO_CUR_CODE5 = ?,";
   strSQL += "FO_CUR_RECON_ACQ0 = ?,FO_CUR_RECON_ACQ1 = ?,";
   strSQL += "FO_CUR_RECON_ACQ2 = ?,FO_CUR_RECON_ACQ3 = ?,";
   strSQL += "FO_CUR_RECON_ACQ4 = ?,FO_CUR_RECON_ACQ5 = ?,";
   strSQL += "FO_CUR_RECON_ISS0 = ?,FO_CUR_RECON_ISS1 = ?,";
   strSQL += "FO_CUR_RECON_ISS2 = ?,FO_CUR_RECON_ISS3 = ?,";
   strSQL += "FO_CUR_RECON_ISS4 = ?,FO_CUR_RECON_ISS5 = ?,";
   strSQL += "FO_DEC_POS0 = ?,FO_DEC_POS1 = ?,FO_DEC_POS2 = ?,";
   strSQL += "FO_DEC_POS3 = ?,FO_DEC_POS4 = ?,FO_DEC_POS5 = ?,";
   strSQL += "FO_INITIATOR0 = ?,FO_INITIATOR1 = ?,FO_INITIATOR2 = ?,";
   strSQL += "FO_INITIATOR3 = ?,FO_INITIATOR4 = ?,FO_INITIATOR5 = ?,";
   strSQL += "FO_MEMO0 = ?,FO_MEMO1 = ?,FO_MEMO2 = ?,";
   strSQL += "FO_MEMO3 = ?,FO_MEMO4 = ?,FO_MEMO5 = ?,";
   strSQL += "FO_TYPE0 = ?,FO_TYPE1 = ?,FO_TYPE2 = ?,";
   strSQL += "FO_TYPE3 = ?,FO_TYPE4 = ?,FO_TYPE5 = ?,";
   strSQL += "O_AMT_CARD_BILL = ?,O_AMT_RECON_ACQ = ?,";
   strSQL += "O_AMT_RECON_ISS = ?,O_AMT_RECON_NET = ?,O_AMT_TRAN = ?,";
   strSQL += "ODE_INST_ID_ACQ = ?,ODE_MTI = ?,ODE_SYS_TRA_AUD_NO = ?,";
   strSQL += "ODE_TSTAMP_LOCL_TR = ?,TSTAMP_REV_CREATED = ?,";
   strSQL += "ADTL_DATA_FEE = ?,ISS_ACQ_TYPE_FEE = ?,";
   strSQL += "NET_UNIQUE_DAT_FEE = ?,BRANCH_ID_ACQ = ?,";
   strSQL += "CNTRY_REC_INST_ADJ = ?,CNTRY_REQ_INST_ADJ = ?,";
   strSQL += "INST_ID_REC_ADJ = ?,INST_ID_REQ_ADJ = ?,";
   strSQL += "NET_IND_ADJ = ?,ORIG_AMT_TRAN_ADJ = ?,";
   strSQL += "REQ_ACQ_ISS_IND = ?,TRACE_DATA_ADJ = ?,";
   strSQL += "TSTAMP_LOCAL_ADJ = ?,TSTAMP_TRANS_ADJ = ?,";
   strSQL += "EXTENSION_DATA_ADJ = ?,BRIDGE_ACQ_FLG = ?,BRIDGE_ISS_FLG = ?,";
   strSQL += "BIN_LENGTH = ?,PAN_IDENTIFIER = ?,";
   strSQL += "PYMT_ACCT_REF = ?,MERCH_DISP_NAME = ?,";
   strSQL += "EMV_3D_CAVV_VER_BY = ?,EMV_3D_TRAN_ID = ?,";
   strSQL += "COOPER_SCORE = ?,COOPER_REASON = ?,AMX_FRAUD_DATA = ?,";
   strSQL += "ISSUER_SCRIPT_FLG = ?,";
   strSQL += "SELLER_EMAIL = ?,";
   strSQL += "SELLER_PHONE = ?,";
   strSQL += "SELLER_ID = ?,";
   strSQL += "FORCE_POST_DROP_IND = ?,";
   strSQL += "FP_HOLD_MATCH_FLG = ?,";
   strSQL += "ODE_INST_ID_FRWD = ?,ODE_DATE_TIME_XMIT = ?,";
   strSQL += "DATE_TIME_XMIT = ?,PAN_TOKEN_BIN_LEN = ?,";
   strSQL += "FR_TOKEN_DEVICE_ID = ?,WALLET_REASON = ?";
   strSQL += " WHERE TSTAMP_TRANS = ?";
   strSQL += " AND UNIQUENESS_KEY = ?";
   memcpy(FINU_UPDATE.data,strSQL.data(),strSQL.length());
   FINU_UPDATE.length = strSQL.length();
   FR_UNIQUENESS_KEY = 0;
   /*
   m_hOptLogic.push_back(std::pair<int,RepositorySegment*>(3,(RepositorySegment*)0));
   m_hOptLogic.push_back(pair<int,RepositorySegment*>(35,FinancialBaseSegment::instance())) ;
   m_hOptLogic.push_back(pair<int,RepositorySegment*>(207,FinancialSettlementSegment::instance()));
   m_hOptLogic.push_back(pair<int,RepositorySegment*>(158,FinancialUserSegment::instance()));
   m_hOptLogic.push_back(pair<int,RepositorySegment*>(100,FinancialReversalSegment::instance()));
   m_hOptLogic.push_back(pair<int,RepositorySegment*>(3,FinancialFeeSegment::instance()));
   m_hOptLogic.push_back(pair<int,RepositorySegment*>(11,FinancialAdjustmentSegment::instance()));
   m_hOptLogic.push_back(pair<int,RepositorySegment*>(1,FinancialAdjustmentExtensionSegment::instance()));
   m_iTotalUpdateFinancialColumns=35+207+158+100+3+11+1;             //515
   */
  //## end dndb2database::UDBAddFinancialCommand::UDBAddFinancialCommand%4915E99F001F_const.body
}


UDBAddFinancialCommand::~UDBAddFinancialCommand()
{
  //## begin dndb2database::UDBAddFinancialCommand::~UDBAddFinancialCommand%4915E99F001F_dest.body preserve=yes
  //## end dndb2database::UDBAddFinancialCommand::~UDBAddFinancialCommand%4915E99F001F_dest.body
}



//## Other Operations (implementation)
void UDBAddFinancialCommand::copyAdjustmentToHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::copyAdjustmentToHost%4915EAB102EE.body preserve=yes
   FinancialAdjustmentSegment* pFinancialAdjustmentSegment = FinancialAdjustmentSegment::instance();
   memcpy(FR_BRANCH_ID_ACQ,pFinancialAdjustmentSegment->zBRANCH_ID_ACQ(),sizeof(FR_BRANCH_ID_ACQ));
   memcpy(FR_CNTRY_REC_INST_ADJ,pFinancialAdjustmentSegment->zCNTRY_REC_INST_ADJ(),sizeof(FR_CNTRY_REC_INST_ADJ));
   memcpy(FR_CNTRY_REQ_INST_ADJ,pFinancialAdjustmentSegment->zCNTRY_REQ_INST_ADJ(),sizeof(FR_CNTRY_REQ_INST_ADJ));
   memcpy(FR_INST_ID_REC_ADJ,pFinancialAdjustmentSegment->zINST_ID_REC_ADJ(),sizeof(FR_INST_ID_REC_ADJ));
   memcpy(FR_INST_ID_REQ_ADJ,pFinancialAdjustmentSegment->zINST_ID_REQ_ADJ(),sizeof(FR_INST_ID_REQ_ADJ));
   memcpy(FR_NET_IND_ADJ,pFinancialAdjustmentSegment->zNET_IND_ADJ(),sizeof(FR_NET_IND_ADJ));
   FR_ORIG_AMT_TRAN_ADJ = pFinancialAdjustmentSegment->getORIG_AMT_TRAN_ADJ();
   memcpy(FR_REQ_ACQ_ISS_IND,pFinancialAdjustmentSegment->zREQ_ACQ_ISS_IND(),sizeof(FR_REQ_ACQ_ISS_IND));
   memcpy(FR_TRACE_DATA_ADJ,pFinancialAdjustmentSegment->zTRACE_DATA_ADJ(),sizeof(FR_TRACE_DATA_ADJ));
   memcpy(FR_TSTAMP_LOCAL_ADJ,pFinancialAdjustmentSegment->zTSTAMP_LOCAL_ADJ(),sizeof(FR_TSTAMP_LOCAL_ADJ));
   memcpy(FR_TSTAMP_TRANS_ADJ,pFinancialAdjustmentSegment->zTSTAMP_TRANS_ADJ(),sizeof(FR_TSTAMP_TRANS_ADJ));
  //## end dndb2database::UDBAddFinancialCommand::copyAdjustmentToHost%4915EAB102EE.body
}

void UDBAddFinancialCommand::copyAdjustmentExtensionToHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::copyAdjustmentExtensionToHost%4915EAB102EF.body preserve=yes
   FinancialAdjustmentExtensionSegment* pFinancialAdjustmentExtensionSegment = FinancialAdjustmentExtensionSegment::instance();
   FR_EXTENSION_DATA_ADJ.FR_EXTENSION_DATA_ADJ_len = pFinancialAdjustmentExtensionSegment->getSizeofEXTENSION_DATA_ADJ();
   memcpy(FR_EXTENSION_DATA_ADJ.FR_EXTENSION_DATA_ADJ_data,pFinancialAdjustmentExtensionSegment->zEXTENSION_DATA_ADJ(),pFinancialAdjustmentExtensionSegment->getSizeofEXTENSION_DATA_ADJ());
  //## end dndb2database::UDBAddFinancialCommand::copyAdjustmentExtensionToHost%4915EAB102EF.body
}

void UDBAddFinancialCommand::copyFeeToHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::copyFeeToHost%4915EAB102FD.body preserve=yes
   FinancialFeeSegment* pFinancialFeeSegment = FinancialFeeSegment::instance();
   FR_ADTL_DATA_FEE.FR_ADTL_DATA_FEE_len = 254;
   memcpy(FR_ADTL_DATA_FEE.FR_ADTL_DATA_FEE_data,pFinancialFeeSegment->zADTL_DATA_FEE(),sizeof(FR_ADTL_DATA_FEE.FR_ADTL_DATA_FEE_data) - 1);
   memcpy(FR_ISS_ACQ_TYPE_FEE,pFinancialFeeSegment->zISS_ACQ_TYPE_FEE(),sizeof(FR_ISS_ACQ_TYPE_FEE));
   FR_NET_UNIQUE_DAT_FEE.FR_NET_UNIQUE_DAT_FEE_len = 80;
   memcpy(FR_NET_UNIQUE_DAT_FEE.FR_NET_UNIQUE_DAT_FEE_data,pFinancialFeeSegment->zNET_UNIQUE_DAT_FEE(),sizeof(FR_NET_UNIQUE_DAT_FEE.FR_NET_UNIQUE_DAT_FEE_data) - 1);
  //## end dndb2database::UDBAddFinancialCommand::copyFeeToHost%4915EAB102FD.body
}

void UDBAddFinancialCommand::copyICCToHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::copyICCToHost%491719DB03D8.body preserve=yes
   IntegratedCircuitCardSegment* pIntegratedCircuitCardSegment = IntegratedCircuitCardSegment::instance();
   memcpy(FI_AMOUNT_OTHER,pIntegratedCircuitCardSegment->zAMOUNT_OTHER(),sizeof(FI_AMOUNT_OTHER));
   memcpy(FI_APPL_CRYPTOGRAM,pIntegratedCircuitCardSegment->zAPPL_CRYPTOGRAM(),sizeof(FI_APPL_CRYPTOGRAM));
   memcpy(FI_APPL_ID,pIntegratedCircuitCardSegment->zAPPL_ID(),sizeof(FI_APPL_ID));
   memcpy(FI_APPL_INTRCHG_PROF,pIntegratedCircuitCardSegment->zAPPL_INTRCHG_PROF(),sizeof(FI_APPL_INTRCHG_PROF));
   memcpy(FI_APPL_TRAN_COUNTER,pIntegratedCircuitCardSegment->zAPPL_TRAN_COUNTER(),sizeof(FI_APPL_TRAN_COUNTER));
   memcpy(FI_APPL_VERSION_NO,pIntegratedCircuitCardSegment->zAPPL_VERSION_NO(),sizeof(FI_APPL_VERSION_NO));
   memcpy(FI_CARDH_VER_RESULT,pIntegratedCircuitCardSegment->zCARDH_VER_RESULT(),sizeof(FI_CARDH_VER_RESULT));
   memcpy(FI_CHIP_TOKEN_REQ_ID,pIntegratedCircuitCardSegment->zCHIP_TOKEN_REQ_ID(),sizeof(FI_CHIP_TOKEN_REQ_ID));
   memcpy(FI_COPAC_CCS_CRYPTO,pIntegratedCircuitCardSegment->zCOPAC_CCS_CRYPTO(),sizeof(FI_COPAC_CCS_CRYPTO));
   memcpy(FI_CRYPT_INFO_DATA,pIntegratedCircuitCardSegment->zCRYPT_INFO_DATA(),sizeof(FI_CRYPT_INFO_DATA));
   memcpy(FI_CRYPTOGRAM_AMOUNT,pIntegratedCircuitCardSegment->zCRYPTOGRAM_AMOUNT(),sizeof(FI_CRYPTOGRAM_AMOUNT));
   memcpy(FI_DEDICATED_FILE_NAM,pIntegratedCircuitCardSegment->zDEDICATED_FILE_NAM(),sizeof(FI_DEDICATED_FILE_NAM));
   memcpy(FI_FORM_FACTOR_IND,pIntegratedCircuitCardSegment->zFORM_FACTOR_IND(),sizeof(FI_FORM_FACTOR_IND));
   memcpy(FI_ISS_APPL_DATA,pIntegratedCircuitCardSegment->zISS_APPL_DATA(),sizeof(FI_ISS_APPL_DATA));
   memcpy(FI_ISS_AUTH_DATA,pIntegratedCircuitCardSegment->zISS_AUTH_DATA(),sizeof(FI_ISS_AUTH_DATA));
   memcpy(FI_ISS_DISCR_DATA,pIntegratedCircuitCardSegment->zISS_DISCR_DATA(),sizeof(FI_ISS_DISCR_DATA));
   memcpy(FI_ISS_SCRIPT_RESULT,pIntegratedCircuitCardSegment->zISS_SCRIPT_RESULT(),sizeof(FI_ISS_SCRIPT_RESULT));
   memcpy(FI_ISS_SCRIPT1_DATA,pIntegratedCircuitCardSegment->zISS_SCRIPT1_DATA(),sizeof(FI_ISS_SCRIPT1_DATA));
   memcpy(FI_ISS_SCRIPT2_DATA,pIntegratedCircuitCardSegment->zISS_SCRIPT2_DATA(),sizeof(FI_ISS_SCRIPT2_DATA));
   memcpy(FI_TERM_CAPABILITIES,pIntegratedCircuitCardSegment->zTERM_CAPABILITIES(),sizeof(FI_TERM_CAPABILITIES));
   memcpy(FI_TERM_COUNTRY_CODE,pIntegratedCircuitCardSegment->zTERM_COUNTRY_CODE(),sizeof(FI_TERM_COUNTRY_CODE));
   memcpy(FI_TERM_SERIAL_NO,pIntegratedCircuitCardSegment->zTERM_SERIAL_NO(),sizeof(FI_TERM_SERIAL_NO));
   memcpy(FI_TERM_VERIFY_RESULT,pIntegratedCircuitCardSegment->zTERM_VERIFY_RESULT(),sizeof(FI_TERM_VERIFY_RESULT));
   memcpy(FI_TERMINAL_TYPE,pIntegratedCircuitCardSegment->zTERMINAL_TYPE(),sizeof(FI_TERMINAL_TYPE));
   memcpy(FI_TRAN_CATEGORY_CODE,pIntegratedCircuitCardSegment->zTRAN_CATEGORY_CODE(),sizeof(FI_TRAN_CATEGORY_CODE));
   memcpy(FI_TRAN_CURRENCY_CODE,pIntegratedCircuitCardSegment->zTRAN_CURRENCY_CODE(),sizeof(FI_TRAN_CURRENCY_CODE));
   memcpy(FI_TRAN_DATE,pIntegratedCircuitCardSegment->zTRAN_DATE(),sizeof(FI_TRAN_DATE));
   memcpy(FI_TRAN_SEQ_COUNTER,pIntegratedCircuitCardSegment->zTRAN_SEQ_COUNTER(),sizeof(FI_TRAN_SEQ_COUNTER));
   memcpy(FI_TRAN_TYPE,pIntegratedCircuitCardSegment->zTRAN_TYPE(),sizeof(FI_TRAN_TYPE));
   memcpy(FI_UNPREDICTABLE_NO,pIntegratedCircuitCardSegment->zUNPREDICTABLE_NO(),sizeof(FI_UNPREDICTABLE_NO));
   memcpy(FI_DERIVATION_KEY_IDX,pIntegratedCircuitCardSegment->zDERIVATION_KEY_IDX(),sizeof(FI_DERIVATION_KEY_IDX));
   memcpy(FI_ARPC_CRYPTOGRAM,pIntegratedCircuitCardSegment->zARPC_CRYPTOGRAM(),sizeof(FI_ARPC_CRYPTOGRAM));
   memcpy(FI_ARPC_RESPCODE,pIntegratedCircuitCardSegment->zARPC_RESPCODE(),sizeof(FI_ARPC_RESPCODE));
   FI_UNIQUENESS_KEY = FR_UNIQUENESS_KEY;
  //## end dndb2database::UDBAddFinancialCommand::copyICCToHost%491719DB03D8.body
}

bool UDBAddFinancialCommand::copyFraudRuleToHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::copyFraudRuleToHost%4C0CCD960266.body preserve=yes
   FraudBlockSegment hFraudBlockSegment;
   if (hFraudBlockSegment.read(&m_pBuffer))
      return false;
   FFR_SEQ_NO = hFraudBlockSegment.getSEQ_NO();
   memcpy(FFR_INST_ID_RECON_ISS,hFraudBlockSegment.getINST_ID_RECON_ISS().data(),hFraudBlockSegment.getINST_ID_RECON_ISS().length());
   FFR_INST_ID_RECON_ISS[hFraudBlockSegment.getINST_ID_RECON_ISS().length()] = '\0';
   memcpy(FFR_INST_ID_RECON_ACQ,hFraudBlockSegment.getINST_ID_RECON_ACQ().data(),hFraudBlockSegment.getINST_ID_RECON_ACQ().length());
   FFR_INST_ID_RECON_ACQ[hFraudBlockSegment.getINST_ID_RECON_ACQ().length()] = '\0';
   memcpy(FFR_RULE_NAME.FFR_RULE_NAME_data,hFraudBlockSegment.getRULE_NAME().data(),hFraudBlockSegment.getRULE_NAME().length());
   FFR_RULE_NAME.FFR_RULE_NAME_len=hFraudBlockSegment.getRULE_NAME().length();
   memcpy(FFR_FRAUD_SCORE,hFraudBlockSegment.getFRAUD_SCORE().data(),hFraudBlockSegment.getFRAUD_SCORE().length());
   FFR_FRAUD_SCORE[hFraudBlockSegment.getFRAUD_SCORE().length()] = '\0';
   memcpy(FFR_SUB_CLASS_CODE,hFraudBlockSegment.getSUB_CLASS_CODE().data(),hFraudBlockSegment.getSUB_CLASS_CODE().length());
   FFR_SUB_CLASS_CODE[hFraudBlockSegment.getSUB_CLASS_CODE().length()] = '\0';
   memcpy(FFR_FRAUD_ID,hFraudBlockSegment.getFRAUD_ID().data(),hFraudBlockSegment.getFRAUD_ID().length());
   FFR_FRAUD_ID[hFraudBlockSegment.getFRAUD_ID().length()] = '\0';
   memcpy(FFR_CARD_BIN_HASH,hFraudBlockSegment.getCARD_BIN_HASH().data(),hFraudBlockSegment.getCARD_BIN_HASH().length());
   FFR_CARD_BIN_HASH[hFraudBlockSegment.getCARD_BIN_HASH().length()] = '\0';
   return true;
  //## end dndb2database::UDBAddFinancialCommand::copyFraudRuleToHost%4C0CCD960266.body
}

void UDBAddFinancialCommand::copyMemberToHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::copyMemberToHost%4915EAB1030D.body preserve=yes
   FinancialBaseSegment* pBaseSegment = FinancialBaseSegment::instance();
   memcpy(FL_PROC_GRP_ID_ACQ_B,pBaseSegment->zPROC_GRP_ID_ACQ_B(),sizeof(FL_PROC_GRP_ID_ACQ_B));
   memcpy(FL_PROC_GRP_ID_ISS_B,pBaseSegment->zPROC_GRP_ID_ISS_B(),sizeof(FL_PROC_GRP_ID_ISS_B));
   memcpy(FL_PROC_ID_ACQ,pBaseSegment->zPROC_ID_ACQ(),sizeof(FL_PROC_ID_ACQ));
   memcpy(FL_PROC_ID_ACQ_B,pBaseSegment->zPROC_ID_ACQ_B(),sizeof(FL_PROC_ID_ACQ_B));
   memcpy(FL_PROC_ID_ISS,pBaseSegment->zPROC_ID_ISS(),sizeof(FL_PROC_ID_ISS));
   memcpy(FL_PROC_ID_ISS_B,pBaseSegment->zPROC_ID_ISS_B(),sizeof(FL_PROC_ID_ISS_B));
   memcpy(FL_ACT_CODE,pBaseSegment->zACT_CODE(),sizeof(FL_ACT_CODE));
   memcpy(FL_TRANSACTION_ID,pBaseSegment->zTRANSACTION_ID(),sizeof(FL_TRANSACTION_ID));
   memcpy(FL_APPROVAL_CODE,pBaseSegment->zAPPROVAL_CODE(),sizeof(FL_APPROVAL_CODE));
   memcpy(FL_AUTH_BY,pBaseSegment->zAUTH_BY(),sizeof(FL_AUTH_BY));
   memcpy(FL_CARD_ACPT_TERM_ID,pBaseSegment->zCARD_ACPT_TERM_ID(),sizeof(FL_CARD_ACPT_TERM_ID));
   memcpy(FL_INST_ID_ACQ,pBaseSegment->zINST_ID_ACQ(),sizeof(FL_INST_ID_ACQ));
   memcpy(FL_INST_ID_ISS,pBaseSegment->zINST_ID_ISS(),sizeof(FL_INST_ID_ISS));
   memcpy(FL_INST_ID_RECON_ACQ,pBaseSegment->zINST_ID_RECON_ACQ(),sizeof(FL_INST_ID_RECON_ACQ));
   memcpy(FL_INST_ID_RECN_ACQ_B,pBaseSegment->zINST_ID_RECN_ACQ_B(),sizeof(FL_INST_ID_RECN_ACQ_B));
   memcpy(FL_INST_ID_RECON_ISS,pBaseSegment->zINST_ID_RECON_ISS(),sizeof(FL_INST_ID_RECON_ISS));
   memcpy(FL_INST_ID_RECN_ISS_B,pBaseSegment->zINST_ID_RECN_ISS_B(),sizeof(FL_INST_ID_RECN_ISS_B));
   memcpy(FL_MAPPED_DUP_DATA,pBaseSegment->zMAPPED_DUP_DATA(),sizeof(FL_MAPPED_DUP_DATA));
   memcpy(FL_NET_TERM_ID,pBaseSegment->zNET_TERM_ID(),sizeof(FL_NET_TERM_ID));
   memcpy(FL_PAN,pBaseSegment->zPAN(),sizeof(FL_PAN));
   memcpy(FL_RETRIEVAL_REF_NO,pBaseSegment->zRETRIEVAL_REF_NO(),sizeof(FL_RETRIEVAL_REF_NO));
   memcpy(FL_RPT_LVL_ID_B,pBaseSegment->zRPT_LVL_ID_B(),sizeof(FL_RPT_LVL_ID_B));
   memcpy(FL_SUBSCRIBER_IND,pBaseSegment->zSUBSCRIBER_IND(),sizeof(FL_SUBSCRIBER_IND));
   memcpy(FL_SYS_TRACE_AUDIT_NO,pBaseSegment->zSYS_TRACE_AUDIT_NO(),sizeof(FL_SYS_TRACE_AUDIT_NO));
   memcpy(FL_TRAN_CLASS,pBaseSegment->zTRAN_CLASS(),sizeof(FL_TRAN_CLASS));
   memcpy(FL_TRAN_TYPE_ID,pBaseSegment->zTRAN_TYPE_ID(),sizeof(FL_TRAN_TYPE_ID));
   memcpy(FL_TSTAMP_LOCAL,pBaseSegment->zTSTAMP_LOCAL(),sizeof(FL_TSTAMP_LOCAL));
   memcpy(FR_ACCT_ID_2,pBaseSegment->zACCT_ID_2(),sizeof(FR_ACCT_ID_2));
   memcpy(FR_ACCT_ID_3,pBaseSegment->zACCT_ID_3(),sizeof(FR_ACCT_ID_3));
   memcpy(FR_ACCT_TYPES_ISS,pBaseSegment->zACCT_TYPES_ISS(),sizeof(FR_ACCT_TYPES_ISS));
   FR_CED_BUILD_NO = pBaseSegment->getCED_BUILD_NO();
   memcpy(FR_ACQ_PLAT_PROD_ID,pBaseSegment->zACQ_PLAT_PROD_ID(),sizeof(FR_ACQ_PLAT_PROD_ID));
   FR_AMT_CARD_BILL = pBaseSegment->getAMT_CARD_BILL();
   FR_AMT_RECON_NET = pBaseSegment->getAMT_RECON_NET();
   FR_AMT_TRAN = pBaseSegment->getAMT_TRAN();
   memcpy(FR_CARD_ACPT_BUS_CODE,pBaseSegment->zCARD_ACPT_BUS_CODE(),sizeof(FR_CARD_ACPT_BUS_CODE));
   memcpy(FR_CARD_ACPT_COUNTRY,pBaseSegment->zCARD_ACPT_COUNTRY(),sizeof(FR_CARD_ACPT_COUNTRY));
   memcpy(FR_CARD_ACPT_NAME_LOC.FR_CARD_ACPT_NAME_LOC_data,pBaseSegment->zCARD_ACPT_NAME_LOC(),pBaseSegment->getSizeofCARD_ACPT_NAME_LOC());
   FR_CARD_ACPT_NAME_LOC.FR_CARD_ACPT_NAME_LOC_len = pBaseSegment->getSizeofCARD_ACPT_NAME_LOC();
   memcpy(FR_CARD_ACPT_PST_CODE,pBaseSegment->zCARD_ACPT_PST_CODE(),sizeof(FR_CARD_ACPT_PST_CODE));
   memcpy(FR_CARD_ACPT_REGION,pBaseSegment->zCARD_ACPT_REGION(),sizeof(FR_CARD_ACPT_REGION));
   memcpy(FR_CARD_SEQ_NO,pBaseSegment->zCARD_SEQ_NO(),sizeof(FR_CARD_SEQ_NO));
   memcpy(FR_CIRC_ID_ACQ,pBaseSegment->zCIRC_ID_ACQ(),sizeof(FR_CIRC_ID_ACQ));
   memcpy(FR_CIRC_ID_ISS,pBaseSegment->zCIRC_ID_ISS(),sizeof(FR_CIRC_ID_ISS));
   memcpy(FR_COUNTRY_ACQ_INST,pBaseSegment->zCOUNTRY_ACQ_INST(),sizeof(FR_COUNTRY_ACQ_INST));
   memcpy(FR_COUNTRY_ISS_INST,pBaseSegment->zCOUNTRY_ISS_INST(),sizeof(FR_COUNTRY_ISS_INST));
   memcpy(FR_CUR_CARD_BILL,pBaseSegment->zCUR_CARD_BILL(),sizeof(FR_CUR_CARD_BILL));
   memcpy(FR_CUR_RECON_NET,pBaseSegment->zCUR_RECON_NET(),sizeof(FR_CUR_RECON_NET));
   memcpy(FR_CUR_TRAN,pBaseSegment->zCUR_TRAN(),sizeof(FR_CUR_TRAN));
   memcpy(FR_DATE_RECON_ACQ,pBaseSegment->zDATE_RECON_ACQ(),sizeof(FR_DATE_RECON_ACQ));
   memcpy(FR_FUNC_CODE,pBaseSegment->zFUNC_CODE(),sizeof(FR_FUNC_CODE));
   memcpy(FR_MERCH_TYPE,pBaseSegment->zMERCH_TYPE(),sizeof(FR_MERCH_TYPE));
   memcpy(FR_MSG_RESON_CODE_ACQ,pBaseSegment->zMSG_RESON_CODE_ACQ(),sizeof(FR_MSG_RESON_CODE_ACQ));
   memcpy(FR_MSG_RESON_CODE_ISS,pBaseSegment->zMSG_RESON_CODE_ISS(),sizeof(FR_MSG_RESON_CODE_ISS));
   memcpy(FR_NET_ID_ACQ,pBaseSegment->zNET_ID_ACQ(),sizeof(FR_NET_ID_ACQ));
   memcpy(FR_NET_ID_ISS,pBaseSegment->zNET_ID_ISS(),sizeof(FR_NET_ID_ISS));
   memcpy(FR_POS_CRDHLDR_A_METH,pBaseSegment->zPOS_CRDHLDR_A_METH(),sizeof(FR_POS_CRDHLDR_A_METH));
   memcpy(FR_REIMBURSEMENT_ATTR,pBaseSegment->zREIMBURSEMENT_ATTR(),sizeof(FR_REIMBURSEMENT_ATTR));
   memcpy(FR_REV_BY,pBaseSegment->zREV_BY(),sizeof(FR_REV_BY));
   memcpy(FR_TRAN_DISPOSITION,pBaseSegment->zTRAN_DISPOSITION(),sizeof(FR_TRAN_DISPOSITION));
   if (FinancialAdjustmentSegment::instance()->presence())
      copyAdjustmentToHost();
   else
      resetAdjustmentHost();
   if (FinancialAdjustmentExtensionSegment::instance()->presence())
      copyAdjustmentExtensionToHost();
   else
      resetAdjustmentExtensionHost();
   if (FinancialFeeSegment::instance()->presence())
      copyFeeToHost();
   else
      resetFeeHost();
   if (FinancialReversalSegment::instance()->presence())
      copyReversalToHost();
   else
      resetReversalHost();
   if (FinancialSettlementSegment::instance()->presence())
      copySettlementToHost();
   else
      resetSettlementHost();
   if (FinancialUserSegment::instance()->presence())
      copyUserToHost();
   else
      resetUserHost();
   if (IntegratedCircuitCardSegment::instance()->presence())
      copyICCToHost();
   else
      resetICCHost();
   if (MultipleRouteSegment::instance()->presence())
      copyMultipleRouteToHost();
   else
      resetMultipleRouteHost();
  //## end dndb2database::UDBAddFinancialCommand::copyMemberToHost%4915EAB1030D.body
}

void UDBAddFinancialCommand::copyMultipleRouteToHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::copyMultipleRouteToHost%54861FB00335.body preserve=yes
   MultipleRouteSegment* pMultipleRouteSegment = MultipleRouteSegment::instance();
   memcpy(FM_PRIMARY_PROC_ID,pMultipleRouteSegment->zPRIMARY_PROC_ID(),sizeof(FM_PRIMARY_PROC_ID));
   memcpy(FM_PRIMARY_PROCESS_ID,pMultipleRouteSegment->zPRIMARY_PROCESS_ID(),sizeof(FM_PRIMARY_PROCESS_ID));
   memcpy(FM_PRIMARY_TD_PROCESS_ID,pMultipleRouteSegment->zPRIMARY_TD_PROCESS_ID(),sizeof(FM_PRIMARY_TD_PROCESS_ID));
   memcpy(FM_PROC_ID,pMultipleRouteSegment->zPROC_ID(),sizeof(FM_PROC_ID));
   memcpy(FM_PROCESS_ID,pMultipleRouteSegment->zPROCESS_ID(),sizeof(FM_PROCESS_ID));
   memcpy(FM_TD_PROCESS_ID,pMultipleRouteSegment->zTD_PROCESS_ID(),sizeof(FM_TD_PROCESS_ID));
   memcpy(FM_PRIMARY_TD_MATCH_OPT,pMultipleRouteSegment->zPRIMARY_TD_MATCH_OPT(),sizeof(FM_PRIMARY_TD_MATCH_OPT));
   memcpy(FM_TD_MATCH_OPT,pMultipleRouteSegment->zTD_MATCH_OPT(),sizeof(FM_TD_MATCH_OPT));
   memcpy(FM_MULTI_RTE_OPT,pMultipleRouteSegment->zMULTI_RTE_OPT(),sizeof(FM_MULTI_RTE_OPT));
   memcpy(FM_STANDIN_IND,pMultipleRouteSegment->zSTANDIN_IND(),sizeof(FM_STANDIN_IND));
   memcpy(FM_COMPLETION_IND,pMultipleRouteSegment->zCOMPLETION_IND(),sizeof(FM_COMPLETION_IND));
   memcpy(FM_ADVICE_IND,pMultipleRouteSegment->zADVICE_IND(),sizeof(FM_ADVICE_IND));
   memcpy(FM_DENY_OPT,pMultipleRouteSegment->zDENY_OPT(),sizeof(FM_DENY_OPT));
   memcpy(FM_PREAUTH_IND,pMultipleRouteSegment->zPREAUTH_IND(),sizeof(FM_PREAUTH_IND));
   memcpy(FM_REQUEST_BAL_IND,pMultipleRouteSegment->zREQUEST_BAL_IND(),sizeof(FM_REQUEST_BAL_IND));
   memcpy(FM_RESPONSE_BAL_IND,pMultipleRouteSegment->zRESPONSE_BAL_IND(),sizeof(FM_RESPONSE_BAL_IND));
   memcpy(FM_APPROVED_BY,pMultipleRouteSegment->zAPPROVED_BY(),sizeof(FM_APPROVED_BY));
   memcpy(FM_ADVICE_TRAN,pMultipleRouteSegment->zADVICE_TRAN(),sizeof(FM_ADVICE_TRAN));
   memcpy(FM_TDRESP,pMultipleRouteSegment->zTDRESP(),sizeof(FM_TDRESP));
   FM_UNIQUENESS_KEY = FR_UNIQUENESS_KEY;
  //## end dndb2database::UDBAddFinancialCommand::copyMultipleRouteToHost%54861FB00335.body
}

void UDBAddFinancialCommand::copyReversalToHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::copyReversalToHost%4915EAB1031C.body preserve=yes
   FinancialReversalSegment* pReversalSegment = FinancialReversalSegment::instance();
   FR_FO_AMT_RECON_ACQ0 = pReversalSegment->getFO_AMT_RECON_ACQn()[0];
   FR_FO_AMT_RECON_ACQ1 = pReversalSegment->getFO_AMT_RECON_ACQn()[1];
   FR_FO_AMT_RECON_ACQ2 = pReversalSegment->getFO_AMT_RECON_ACQn()[2];
   FR_FO_AMT_RECON_ACQ3 = pReversalSegment->getFO_AMT_RECON_ACQn()[3];
   FR_FO_AMT_RECON_ACQ4 = pReversalSegment->getFO_AMT_RECON_ACQn()[4];
   FR_FO_AMT_RECON_ACQ5 = pReversalSegment->getFO_AMT_RECON_ACQn()[5];
   FR_FO_AMT_RECON_ISS0 = pReversalSegment->getFO_AMT_RECON_ISSn()[0];
   FR_FO_AMT_RECON_ISS1 = pReversalSegment->getFO_AMT_RECON_ISSn()[1];
   FR_FO_AMT_RECON_ISS2 = pReversalSegment->getFO_AMT_RECON_ISSn()[2];
   FR_FO_AMT_RECON_ISS3 = pReversalSegment->getFO_AMT_RECON_ISSn()[3];
   FR_FO_AMT_RECON_ISS4 = pReversalSegment->getFO_AMT_RECON_ISSn()[4];
   FR_FO_AMT_RECON_ISS5 = pReversalSegment->getFO_AMT_RECON_ISSn()[5];
   FR_FO_AMT_RECON_NET0 = pReversalSegment->getFO_AMT_RECON_NETn()[0];
   FR_FO_AMT_RECON_NET1 = pReversalSegment->getFO_AMT_RECON_NETn()[1];
   FR_FO_AMT_RECON_NET2 = pReversalSegment->getFO_AMT_RECON_NETn()[2];
   FR_FO_AMT_RECON_NET3 = pReversalSegment->getFO_AMT_RECON_NETn()[3];
   FR_FO_AMT_RECON_NET4 = pReversalSegment->getFO_AMT_RECON_NETn()[4];
   FR_FO_AMT_RECON_NET5 = pReversalSegment->getFO_AMT_RECON_NETn()[5];
   FR_FO_AMT0 = pReversalSegment->getFO_AMTn()[0];
   FR_FO_AMT1 = pReversalSegment->getFO_AMTn()[1];
   FR_FO_AMT2 = pReversalSegment->getFO_AMTn()[2];
   FR_FO_AMT3 = pReversalSegment->getFO_AMTn()[3];
   FR_FO_AMT4 = pReversalSegment->getFO_AMTn()[4];
   FR_FO_AMT5 = pReversalSegment->getFO_AMTn()[5];
   FR_FO_CNV_ACQ_DE_POS0 = pReversalSegment->getFO_CNV_ACQ_DE_POSn()[0];
   FR_FO_CNV_ACQ_DE_POS1 = pReversalSegment->getFO_CNV_ACQ_DE_POSn()[1];
   FR_FO_CNV_ACQ_DE_POS2 = pReversalSegment->getFO_CNV_ACQ_DE_POSn()[2];
   FR_FO_CNV_ACQ_DE_POS3 = pReversalSegment->getFO_CNV_ACQ_DE_POSn()[3];
   FR_FO_CNV_ACQ_DE_POS4 = pReversalSegment->getFO_CNV_ACQ_DE_POSn()[4];
   FR_FO_CNV_ACQ_DE_POS5 = pReversalSegment->getFO_CNV_ACQ_DE_POSn()[5];
   FR_FO_CNV_ACQ_RATE0 = pReversalSegment->getFO_CNV_ACQ_RATEn()[0];
   FR_FO_CNV_ACQ_RATE1 = pReversalSegment->getFO_CNV_ACQ_RATEn()[1];
   FR_FO_CNV_ACQ_RATE2 = pReversalSegment->getFO_CNV_ACQ_RATEn()[2];
   FR_FO_CNV_ACQ_RATE3 = pReversalSegment->getFO_CNV_ACQ_RATEn()[3];
   FR_FO_CNV_ACQ_RATE4 = pReversalSegment->getFO_CNV_ACQ_RATEn()[4];
   FR_FO_CNV_ACQ_RATE5 = pReversalSegment->getFO_CNV_ACQ_RATEn()[5];
   FR_FO_CNV_ISS_DE_POS0 = pReversalSegment->getFO_CNV_ISS_DE_POSn()[0];
   FR_FO_CNV_ISS_DE_POS1 = pReversalSegment->getFO_CNV_ISS_DE_POSn()[1];
   FR_FO_CNV_ISS_DE_POS2 = pReversalSegment->getFO_CNV_ISS_DE_POSn()[2];
   FR_FO_CNV_ISS_DE_POS3 = pReversalSegment->getFO_CNV_ISS_DE_POSn()[3];
   FR_FO_CNV_ISS_DE_POS4 = pReversalSegment->getFO_CNV_ISS_DE_POSn()[4];
   FR_FO_CNV_ISS_DE_POS5 = pReversalSegment->getFO_CNV_ISS_DE_POSn()[5];
   FR_FO_CNV_ISS_RATE0 = pReversalSegment->getFO_CNV_ISS_RATEn()[0];
   FR_FO_CNV_ISS_RATE1 = pReversalSegment->getFO_CNV_ISS_RATEn()[1];
   FR_FO_CNV_ISS_RATE2 = pReversalSegment->getFO_CNV_ISS_RATEn()[2];
   FR_FO_CNV_ISS_RATE3 = pReversalSegment->getFO_CNV_ISS_RATEn()[3];
   FR_FO_CNV_ISS_RATE4 = pReversalSegment->getFO_CNV_ISS_RATEn()[4];
   FR_FO_CNV_ISS_RATE5 = pReversalSegment->getFO_CNV_ISS_RATEn()[5];
   memcpy(FR_FO_CUR_CODE0,pReversalSegment->zFO_CUR_CODEn(0),sizeof(FR_FO_CUR_CODE0));
   memcpy(FR_FO_CUR_CODE1,pReversalSegment->zFO_CUR_CODEn(1),sizeof(FR_FO_CUR_CODE1));
   memcpy(FR_FO_CUR_CODE2,pReversalSegment->zFO_CUR_CODEn(2),sizeof(FR_FO_CUR_CODE2));
   memcpy(FR_FO_CUR_CODE3,pReversalSegment->zFO_CUR_CODEn(3),sizeof(FR_FO_CUR_CODE3));
   memcpy(FR_FO_CUR_CODE4,pReversalSegment->zFO_CUR_CODEn(4),sizeof(FR_FO_CUR_CODE4));
   memcpy(FR_FO_CUR_CODE5,pReversalSegment->zFO_CUR_CODEn(5),sizeof(FR_FO_CUR_CODE5));
   memcpy(FR_FO_CUR_RECON_ACQ0,pReversalSegment->zFO_CUR_RECON_ACQn(0),sizeof(FR_FO_CUR_RECON_ACQ0));
   memcpy(FR_FO_CUR_RECON_ACQ1,pReversalSegment->zFO_CUR_RECON_ACQn(1),sizeof(FR_FO_CUR_RECON_ACQ1));
   memcpy(FR_FO_CUR_RECON_ACQ2,pReversalSegment->zFO_CUR_RECON_ACQn(2),sizeof(FR_FO_CUR_RECON_ACQ2));
   memcpy(FR_FO_CUR_RECON_ACQ3,pReversalSegment->zFO_CUR_RECON_ACQn(3),sizeof(FR_FO_CUR_RECON_ACQ3));
   memcpy(FR_FO_CUR_RECON_ACQ4,pReversalSegment->zFO_CUR_RECON_ACQn(4),sizeof(FR_FO_CUR_RECON_ACQ4));
   memcpy(FR_FO_CUR_RECON_ACQ5,pReversalSegment->zFO_CUR_RECON_ACQn(5),sizeof(FR_FO_CUR_RECON_ACQ5));
   memcpy(FR_FO_CUR_RECON_ISS0,pReversalSegment->zFO_CUR_RECON_ISSn(0),sizeof(FR_FO_CUR_RECON_ISS0));
   memcpy(FR_FO_CUR_RECON_ISS1,pReversalSegment->zFO_CUR_RECON_ISSn(1),sizeof(FR_FO_CUR_RECON_ISS1));
   memcpy(FR_FO_CUR_RECON_ISS2,pReversalSegment->zFO_CUR_RECON_ISSn(2),sizeof(FR_FO_CUR_RECON_ISS2));
   memcpy(FR_FO_CUR_RECON_ISS3,pReversalSegment->zFO_CUR_RECON_ISSn(3),sizeof(FR_FO_CUR_RECON_ISS3));
   memcpy(FR_FO_CUR_RECON_ISS4,pReversalSegment->zFO_CUR_RECON_ISSn(4),sizeof(FR_FO_CUR_RECON_ISS4));
   memcpy(FR_FO_CUR_RECON_ISS5,pReversalSegment->zFO_CUR_RECON_ISSn(5),sizeof(FR_FO_CUR_RECON_ISS5));
   FR_FO_DEC_POS0 = pReversalSegment->getFO_DEC_POSn()[0];
   FR_FO_DEC_POS1 = pReversalSegment->getFO_DEC_POSn()[1];
   FR_FO_DEC_POS2 = pReversalSegment->getFO_DEC_POSn()[2];
   FR_FO_DEC_POS3 = pReversalSegment->getFO_DEC_POSn()[3];
   FR_FO_DEC_POS4 = pReversalSegment->getFO_DEC_POSn()[4];
   FR_FO_DEC_POS5 = pReversalSegment->getFO_DEC_POSn()[5];
   memcpy(FR_FO_INITIATOR0,pReversalSegment->zFO_INITIATORn(0),sizeof(FR_FO_INITIATOR0));
   memcpy(FR_FO_INITIATOR1,pReversalSegment->zFO_INITIATORn(1),sizeof(FR_FO_INITIATOR1));
   memcpy(FR_FO_INITIATOR2,pReversalSegment->zFO_INITIATORn(2),sizeof(FR_FO_INITIATOR2));
   memcpy(FR_FO_INITIATOR3,pReversalSegment->zFO_INITIATORn(3),sizeof(FR_FO_INITIATOR3));
   memcpy(FR_FO_INITIATOR4,pReversalSegment->zFO_INITIATORn(4),sizeof(FR_FO_INITIATOR4));
   memcpy(FR_FO_INITIATOR5,pReversalSegment->zFO_INITIATORn(5),sizeof(FR_FO_INITIATOR5));
   memcpy(FR_FO_MEMO0,pReversalSegment->zFO_MEMOn(0),sizeof(FR_FO_MEMO0));
   memcpy(FR_FO_MEMO1,pReversalSegment->zFO_MEMOn(1),sizeof(FR_FO_MEMO1));
   memcpy(FR_FO_MEMO2,pReversalSegment->zFO_MEMOn(2),sizeof(FR_FO_MEMO2));
   memcpy(FR_FO_MEMO3,pReversalSegment->zFO_MEMOn(3),sizeof(FR_FO_MEMO3));
   memcpy(FR_FO_MEMO4,pReversalSegment->zFO_MEMOn(4),sizeof(FR_FO_MEMO4));
   memcpy(FR_FO_MEMO5,pReversalSegment->zFO_MEMOn(5),sizeof(FR_FO_MEMO5));
   memcpy(FR_FO_TYPE0,pReversalSegment->zFO_TYPEn(0),sizeof(FR_FO_TYPE0));
   memcpy(FR_FO_TYPE1,pReversalSegment->zFO_TYPEn(1),sizeof(FR_FO_TYPE1));
   memcpy(FR_FO_TYPE2,pReversalSegment->zFO_TYPEn(2),sizeof(FR_FO_TYPE2));
   memcpy(FR_FO_TYPE3,pReversalSegment->zFO_TYPEn(3),sizeof(FR_FO_TYPE3));
   memcpy(FR_FO_TYPE4,pReversalSegment->zFO_TYPEn(4),sizeof(FR_FO_TYPE4));
   memcpy(FR_FO_TYPE5,pReversalSegment->zFO_TYPEn(5),sizeof(FR_FO_TYPE5));
   FR_O_AMT_CARD_BILL = pReversalSegment->getO_AMT_CARD_BILL();
   FR_O_AMT_RECON_ACQ = pReversalSegment->getO_AMT_RECON_ACQ();
   FR_O_AMT_RECON_ISS = pReversalSegment->getO_AMT_RECON_ISS();
   FR_O_AMT_RECON_NET = pReversalSegment->getO_AMT_RECON_NET();
   FR_O_AMT_TRAN = pReversalSegment->getO_AMT_TRAN();
   memcpy(FR_ODE_INST_ID_ACQ,pReversalSegment->zODE_INST_ID_ACQ(),sizeof(FR_ODE_INST_ID_ACQ));
   memcpy(FR_ODE_MTI,pReversalSegment->zODE_MTI(),sizeof(FR_ODE_MTI));
   memcpy(FR_ODE_SYS_TRA_AUD_NO,pReversalSegment->zODE_SYS_TRA_AUD_NO(),sizeof(FR_ODE_SYS_TRA_AUD_NO));
   memcpy(FR_ODE_TSTAMP_LOCL_TR,pReversalSegment->zODE_TSTAMP_LOCL_TR(),sizeof(FR_ODE_TSTAMP_LOCL_TR));
   memcpy(FR_TSTAMP_REV_CREATED,pReversalSegment->zTSTAMP_REV_CREATED(),sizeof(FR_TSTAMP_REV_CREATED));
  //## end dndb2database::UDBAddFinancialCommand::copyReversalToHost%4915EAB1031C.body
}

void UDBAddFinancialCommand::copySettlementToHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::copySettlementToHost%4915EAB1032C.body preserve=yes
   FinancialSettlementSegment* pSettlementSegment = FinancialSettlementSegment::instance();
   memcpy(FR_ACCT_QUAL_1,pSettlementSegment->zACCT_QUAL_1(),sizeof(FR_ACCT_QUAL_1));
   memcpy(FR_ACCT_QUAL_2,pSettlementSegment->zACCT_QUAL_2(),sizeof(FR_ACCT_QUAL_2));
   memcpy(FR_ADL_DATA_NATIONAL.FR_ADL_DATA_NATIONAL_data,pSettlementSegment->zADL_DATA_NATIONAL(),pSettlementSegment->getSizeofADL_DATA_NATIONAL());
   FR_ADL_DATA_NATIONAL.FR_ADL_DATA_NATIONAL_len = pSettlementSegment->getSizeofADL_DATA_NATIONAL();
   memcpy(FR_ADL_DATA_PRIV_ACQ.FR_ADL_DATA_PRIV_ACQ_data,pSettlementSegment->zADL_DATA_PRIV_ACQ(),pSettlementSegment->getSizeofADL_DATA_PRIV_ACQ());
   FR_ADL_DATA_PRIV_ACQ.FR_ADL_DATA_PRIV_ACQ_len = pSettlementSegment->getSizeofADL_DATA_PRIV_ACQ();
   FR_ADL_DATA_PRIV_ISS.FR_ADL_DATA_PRIV_ISS_len = pSettlementSegment->getSizeofADL_DATA_PRIV_ISS();
   memcpy(FR_ADL_DATA_PRIV_ISS.FR_ADL_DATA_PRIV_ISS_data,pSettlementSegment->zADL_DATA_PRIV_ISS(),pSettlementSegment->getSizeofADL_DATA_PRIV_ISS());
   memcpy(FR_ADL_RESP_DATA.FR_ADL_RESP_DATA_data,pSettlementSegment->zADL_RESP_DATA(),pSettlementSegment->getSizeofADL_RESP_DATA());
   FR_ADL_RESP_DATA.FR_ADL_RESP_DATA_len = pSettlementSegment->getSizeofADL_RESP_DATA();
   FR_AMT_RECON_ACQ = pSettlementSegment->getAMT_RECON_ACQ();
   FR_AMT_RECON_ISS = pSettlementSegment->getAMT_RECON_ISS();
   memcpy(FR_AP_FLG,pSettlementSegment->zAP_FLG(),sizeof(FR_AP_FLG));
   memcpy(FR_BIN_EXCLUSION_GRP,pSettlementSegment->zBIN_EXCLUSION_GRP(),sizeof(FR_BIN_EXCLUSION_GRP));
   FR_CAN_ITEM_VALUE0 = pSettlementSegment->getCAN_ITEM_VALUEn()[0];
   FR_CAN_ITEM_VALUE1 = pSettlementSegment->getCAN_ITEM_VALUEn()[1];
   FR_CAN_ITEM_VALUE2 = pSettlementSegment->getCAN_ITEM_VALUEn()[2];
   FR_CAN_ITEM_VALUE3 = pSettlementSegment->getCAN_ITEM_VALUEn()[3];
   FR_CAN_ITEM_VALUE4 = pSettlementSegment->getCAN_ITEM_VALUEn()[4];
   FR_CAN_ITEM_VALUE5 = pSettlementSegment->getCAN_ITEM_VALUEn()[5];
   FR_CAN_ITEM_VALUE6 = pSettlementSegment->getCAN_ITEM_VALUEn()[6];
   FR_CAN_ITEM_VALUE7 = pSettlementSegment->getCAN_ITEM_VALUEn()[7];
   FR_CAN_NO_ITEMS_DISP0 = pSettlementSegment->getCAN_NO_ITEMS_DISPn()[0];
   FR_CAN_NO_ITEMS_DISP1 = pSettlementSegment->getCAN_NO_ITEMS_DISPn()[1];
   FR_CAN_NO_ITEMS_DISP2 = pSettlementSegment->getCAN_NO_ITEMS_DISPn()[2];
   FR_CAN_NO_ITEMS_DISP3 = pSettlementSegment->getCAN_NO_ITEMS_DISPn()[3];
   FR_CAN_NO_ITEMS_DISP4 = pSettlementSegment->getCAN_NO_ITEMS_DISPn()[4];
   FR_CAN_NO_ITEMS_DISP5 = pSettlementSegment->getCAN_NO_ITEMS_DISPn()[5];
   FR_CAN_NO_ITEMS_DISP6 = pSettlementSegment->getCAN_NO_ITEMS_DISPn()[6];
   FR_CAN_NO_ITEMS_DISP7 = pSettlementSegment->getCAN_NO_ITEMS_DISPn()[7];
   FR_CAN_ORIG_NO_ITEMS0 = pSettlementSegment->getCAN_ORIG_NO_ITEMSn()[0];
   FR_CAN_ORIG_NO_ITEMS1 = pSettlementSegment->getCAN_ORIG_NO_ITEMSn()[1];
   FR_CAN_ORIG_NO_ITEMS2 = pSettlementSegment->getCAN_ORIG_NO_ITEMSn()[2];
   FR_CAN_ORIG_NO_ITEMS3 = pSettlementSegment->getCAN_ORIG_NO_ITEMSn()[3];
   FR_CAN_ORIG_NO_ITEMS4 = pSettlementSegment->getCAN_ORIG_NO_ITEMSn()[4];
   FR_CAN_ORIG_NO_ITEMS5 = pSettlementSegment->getCAN_ORIG_NO_ITEMSn()[5];
   FR_CAN_ORIG_NO_ITEMS6 = pSettlementSegment->getCAN_ORIG_NO_ITEMSn()[6];
   FR_CAN_ORIG_NO_ITEMS7 = pSettlementSegment->getCAN_ORIG_NO_ITEMSn()[7];
   memcpy(FR_CARD_ACPT_ID,pSettlementSegment->zCARD_ACPT_ID(),sizeof(FR_CARD_ACPT_ID));
   memcpy(FR_CARD_LOGO_ID,pSettlementSegment->zCARD_LOGO_ID(),sizeof(FR_CARD_LOGO_ID));
   memcpy(FR_CARD_OWNER,pSettlementSegment->zCARD_OWNER(),sizeof(FR_CARD_OWNER));
   memcpy(FR_CARD_TYPE,pSettlementSegment->zCARD_TYPE(),sizeof(FR_CARD_TYPE));
   FR_CNV_CRD_BIL_DE_POS = pSettlementSegment->getCNV_CRD_BIL_DE_POS();
   FR_CNV_CRD_BIL_RATE = pSettlementSegment->getCNV_CRD_BIL_RATE();
   FR_CNV_RCN_ACQ_DE_POS = pSettlementSegment->getCNV_RCN_ACQ_DE_POS();
   FR_CNV_RCN_ACQ_RATE = pSettlementSegment->getCNV_RCN_ACQ_RATE();
   FR_CNV_RCN_ISS_DE_POS = pSettlementSegment->getCNV_RCN_ISS_DE_POS();
   FR_CNV_RCN_ISS_RATE = pSettlementSegment->getCNV_RCN_ISS_RATE();
   FR_CNV_RCN_NET_DE_POS = pSettlementSegment->getCNV_RCN_NET_DE_POS();
   FR_CNV_RCN_NET_RATE = pSettlementSegment->getCNV_RCN_NET_RATE();
   memcpy(FR_CRD_ACP_NAM_FMTFLG,pSettlementSegment->zCRD_ACP_NAM_FMTFLG(),sizeof(FR_CRD_ACP_NAM_FMTFLG));
   memcpy(FR_CUR_RECON_ACQ,pSettlementSegment->zCUR_RECON_ACQ(),sizeof(FR_CUR_RECON_ACQ));
   memcpy(FR_CUR_RECON_ISS,pSettlementSegment->zCUR_RECON_ISS(),sizeof(FR_CUR_RECON_ISS));
   memcpy(FR_CAVV_RESULT,pSettlementSegment->zCAVV_RESULT(),sizeof(FR_CAVV_RESULT));
   memcpy(FR_CVV_CVC_RESULT,pSettlementSegment->zCVV_CVC_RESULT(),sizeof(FR_CVV_CVC_RESULT));
   memcpy(FR_CVV2_CVC2_RESULT,pSettlementSegment->zCVV2_CVC2_RESULT(),sizeof(FR_CVV2_CVC2_RESULT));
   FR_CUR_TYPE = pSettlementSegment->getCUR_TYPE();
   FR_DATA_PRIV_ACQ.FR_DATA_PRIV_ACQ_len = pSettlementSegment->getSizeofDATA_PRIV_ACQ();
   memcpy(FR_DATA_PRIV_ACQ.FR_DATA_PRIV_ACQ_data,(char*)pSettlementSegment->zDATA_PRIV_ACQ(),pSettlementSegment->getSizeofDATA_PRIV_ACQ());
   FR_DATA_PRIV_ACQ_FMT = pSettlementSegment->getDATA_PRIV_ACQ_FMT();
   FR_DATA_PRIV_ISS.FR_DATA_PRIV_ISS_len = pSettlementSegment->getSizeofDATA_PRIV_ISS();
   memcpy(FR_DATA_PRIV_ISS.FR_DATA_PRIV_ISS_data,(char*)pSettlementSegment->zDATA_PRIV_ISS(),pSettlementSegment->getSizeofDATA_PRIV_ISS());
   FR_DATA_PRIV_ISS_FMT = pSettlementSegment->getDATA_PRIV_ISS_FMT();
   memcpy(FR_DATE_EXP,pSettlementSegment->zDATE_EXP(),sizeof(FR_DATE_EXP));
   memcpy(FR_DATE_RECON_ISS,pSettlementSegment->zDATE_RECON_ISS(),sizeof(FR_DATE_RECON_ISS));
   memcpy(FR_DRAFT_CAPTURE_FLG, pSettlementSegment->zDRAFT_CAPTURE_FLG(),sizeof(FR_DRAFT_CAPTURE_FLG));
   memcpy(FR_EXCHG_MASTER,pSettlementSegment->zEXCHG_MASTER(),sizeof(FR_EXCHG_MASTER));
   memcpy(FR_EXCHG_SETL,pSettlementSegment->zEXCHG_SETL(),sizeof(FR_EXCHG_SETL));
   FR_F_ADL_DEC_POS0 = pSettlementSegment->getF_ADL_DEC_POSn()[0];
   FR_F_ADL_DEC_POS1 = pSettlementSegment->getF_ADL_DEC_POSn()[1];
   FR_F_ADL_DEC_POS2 = pSettlementSegment->getF_ADL_DEC_POSn()[2];
   FR_F_ADL_DEC_POS3 = pSettlementSegment->getF_ADL_DEC_POSn()[3];
   FR_F_ADL_DEC_POS4 = pSettlementSegment->getF_ADL_DEC_POSn()[4];
   FR_F_ADL_DEC_POS5 = pSettlementSegment->getF_ADL_DEC_POSn()[5];
   FR_F_AMT0 = pSettlementSegment->getF_AMTn()[0];
   FR_F_AMT1 = pSettlementSegment->getF_AMTn()[1];
   FR_F_AMT2 = pSettlementSegment->getF_AMTn()[2];
   FR_F_AMT3 = pSettlementSegment->getF_AMTn()[3];
   FR_F_AMT4 = pSettlementSegment->getF_AMTn()[4];
   FR_F_AMT5 = pSettlementSegment->getF_AMTn()[5];
   FR_F_AMT_RECON_ACQ0 = pSettlementSegment->getF_AMT_RECON_ACQn()[0];
   FR_F_AMT_RECON_ACQ1 = pSettlementSegment->getF_AMT_RECON_ACQn()[1];
   FR_F_AMT_RECON_ACQ2 = pSettlementSegment->getF_AMT_RECON_ACQn()[2];
   FR_F_AMT_RECON_ACQ3 = pSettlementSegment->getF_AMT_RECON_ACQn()[3];
   FR_F_AMT_RECON_ACQ4 = pSettlementSegment->getF_AMT_RECON_ACQn()[4];
   FR_F_AMT_RECON_ACQ5 = pSettlementSegment->getF_AMT_RECON_ACQn()[5];
   FR_F_AMT_RECON_ISS0 = pSettlementSegment->getF_AMT_RECON_ISSn()[0];
   FR_F_AMT_RECON_ISS1 = pSettlementSegment->getF_AMT_RECON_ISSn()[1];
   FR_F_AMT_RECON_ISS2 = pSettlementSegment->getF_AMT_RECON_ISSn()[2];
   FR_F_AMT_RECON_ISS3 = pSettlementSegment->getF_AMT_RECON_ISSn()[3];
   FR_F_AMT_RECON_ISS4 = pSettlementSegment->getF_AMT_RECON_ISSn()[4];
   FR_F_AMT_RECON_ISS5 = pSettlementSegment->getF_AMT_RECON_ISSn()[5];
   FR_F_AMT_RECON_NET0 = pSettlementSegment->getF_AMT_RECON_NETn()[0];
   FR_F_AMT_RECON_NET1 = pSettlementSegment->getF_AMT_RECON_NETn()[1];
   FR_F_AMT_RECON_NET2 = pSettlementSegment->getF_AMT_RECON_NETn()[2];
   FR_F_AMT_RECON_NET3 = pSettlementSegment->getF_AMT_RECON_NETn()[3];
   FR_F_AMT_RECON_NET4 = pSettlementSegment->getF_AMT_RECON_NETn()[4];
   FR_F_AMT_RECON_NET5 = pSettlementSegment->getF_AMT_RECON_NETn()[5];
   FR_F_CNV_ACQ_DEC_POS0 = pSettlementSegment->getF_CNV_ACQ_DEC_POSn()[0];
   FR_F_CNV_ACQ_DEC_POS1 = pSettlementSegment->getF_CNV_ACQ_DEC_POSn()[1];
   FR_F_CNV_ACQ_DEC_POS2 = pSettlementSegment->getF_CNV_ACQ_DEC_POSn()[2];
   FR_F_CNV_ACQ_DEC_POS3 = pSettlementSegment->getF_CNV_ACQ_DEC_POSn()[3];
   FR_F_CNV_ACQ_DEC_POS4 = pSettlementSegment->getF_CNV_ACQ_DEC_POSn()[4];
   FR_F_CNV_ACQ_DEC_POS5 = pSettlementSegment->getF_CNV_ACQ_DEC_POSn()[5];
   FR_F_CNV_ACQ_RATE0 = pSettlementSegment->getF_CNV_ACQ_RATEn()[0];
   FR_F_CNV_ACQ_RATE1 = pSettlementSegment->getF_CNV_ACQ_RATEn()[1];
   FR_F_CNV_ACQ_RATE2 = pSettlementSegment->getF_CNV_ACQ_RATEn()[2];
   FR_F_CNV_ACQ_RATE3 = pSettlementSegment->getF_CNV_ACQ_RATEn()[3];
   FR_F_CNV_ACQ_RATE4 = pSettlementSegment->getF_CNV_ACQ_RATEn()[4];
   FR_F_CNV_ACQ_RATE5 = pSettlementSegment->getF_CNV_ACQ_RATEn()[5];
   FR_F_CNV_ISS_DEC_POS0 = pSettlementSegment->getF_CNV_ISS_DEC_POSn()[0];
   FR_F_CNV_ISS_DEC_POS1 = pSettlementSegment->getF_CNV_ISS_DEC_POSn()[1];
   FR_F_CNV_ISS_DEC_POS2 = pSettlementSegment->getF_CNV_ISS_DEC_POSn()[2];
   FR_F_CNV_ISS_DEC_POS3 = pSettlementSegment->getF_CNV_ISS_DEC_POSn()[3];
   FR_F_CNV_ISS_DEC_POS4 = pSettlementSegment->getF_CNV_ISS_DEC_POSn()[4];
   FR_F_CNV_ISS_DEC_POS5 = pSettlementSegment->getF_CNV_ISS_DEC_POSn()[5];
   FR_F_CNV_ISS_RATE0 = pSettlementSegment->getF_CNV_ISS_RATEn()[0];
   FR_F_CNV_ISS_RATE1 = pSettlementSegment->getF_CNV_ISS_RATEn()[1];
   FR_F_CNV_ISS_RATE2 = pSettlementSegment->getF_CNV_ISS_RATEn()[2];
   FR_F_CNV_ISS_RATE3 = pSettlementSegment->getF_CNV_ISS_RATEn()[3];
   FR_F_CNV_ISS_RATE4 = pSettlementSegment->getF_CNV_ISS_RATEn()[4];
   FR_F_CNV_ISS_RATE5 = pSettlementSegment->getF_CNV_ISS_RATEn()[5];
   memcpy(FR_CARD_INTRCHG_ID,pSettlementSegment->zCARD_INTRCHG_ID(),sizeof(FR_CARD_INTRCHG_ID));
   memcpy(FR_F_CUR_CODE0,pSettlementSegment->zF_CUR_CODEn(0),sizeof(FR_F_CUR_CODE0));
   memcpy(FR_F_CUR_CODE1,pSettlementSegment->zF_CUR_CODEn(1),sizeof(FR_F_CUR_CODE0));
   memcpy(FR_F_CUR_CODE2,pSettlementSegment->zF_CUR_CODEn(2),sizeof(FR_F_CUR_CODE0));
   memcpy(FR_F_CUR_CODE3,pSettlementSegment->zF_CUR_CODEn(3),sizeof(FR_F_CUR_CODE0));
   memcpy(FR_F_CUR_CODE4,pSettlementSegment->zF_CUR_CODEn(4),sizeof(FR_F_CUR_CODE0));
   memcpy(FR_F_CUR_CODE5,pSettlementSegment->zF_CUR_CODEn(5),sizeof(FR_F_CUR_CODE0));
   memcpy(FR_F_CUR_RECON_ACQ0,pSettlementSegment->zF_CUR_RECON_ACQn(0),sizeof(FR_F_CUR_RECON_ACQ0));
   memcpy(FR_F_CUR_RECON_ACQ1,pSettlementSegment->zF_CUR_RECON_ACQn(1),sizeof(FR_F_CUR_RECON_ACQ0));
   memcpy(FR_F_CUR_RECON_ACQ2,pSettlementSegment->zF_CUR_RECON_ACQn(2),sizeof(FR_F_CUR_RECON_ACQ0));
   memcpy(FR_F_CUR_RECON_ACQ3,pSettlementSegment->zF_CUR_RECON_ACQn(3),sizeof(FR_F_CUR_RECON_ACQ0));
   memcpy(FR_F_CUR_RECON_ACQ4,pSettlementSegment->zF_CUR_RECON_ACQn(4),sizeof(FR_F_CUR_RECON_ACQ0));
   memcpy(FR_F_CUR_RECON_ACQ5,pSettlementSegment->zF_CUR_RECON_ACQn(5),sizeof(FR_F_CUR_RECON_ACQ0));
   memcpy(FR_F_CUR_RECON_ISS0,pSettlementSegment->zF_CUR_RECON_ISSn(0),sizeof(FR_F_CUR_RECON_ISS0));
   memcpy(FR_F_CUR_RECON_ISS1,pSettlementSegment->zF_CUR_RECON_ISSn(1),sizeof(FR_F_CUR_RECON_ISS0));
   memcpy(FR_F_CUR_RECON_ISS2,pSettlementSegment->zF_CUR_RECON_ISSn(2),sizeof(FR_F_CUR_RECON_ISS0));
   memcpy(FR_F_CUR_RECON_ISS3,pSettlementSegment->zF_CUR_RECON_ISSn(3),sizeof(FR_F_CUR_RECON_ISS0));
   memcpy(FR_F_CUR_RECON_ISS4,pSettlementSegment->zF_CUR_RECON_ISSn(4),sizeof(FR_F_CUR_RECON_ISS0));
   memcpy(FR_F_CUR_RECON_ISS5,pSettlementSegment->zF_CUR_RECON_ISSn(5),sizeof(FR_F_CUR_RECON_ISS0));
   memcpy(FR_F_INITIATOR0,pSettlementSegment->zF_INITIATORn(0),sizeof(FR_F_INITIATOR0));
   memcpy(FR_F_INITIATOR1,pSettlementSegment->zF_INITIATORn(1),sizeof(FR_F_INITIATOR0));
   memcpy(FR_F_INITIATOR2,pSettlementSegment->zF_INITIATORn(2),sizeof(FR_F_INITIATOR0));
   memcpy(FR_F_INITIATOR3,pSettlementSegment->zF_INITIATORn(3),sizeof(FR_F_INITIATOR0));
   memcpy(FR_F_INITIATOR4,pSettlementSegment->zF_INITIATORn(4),sizeof(FR_F_INITIATOR0));
   memcpy(FR_F_INITIATOR5,pSettlementSegment->zF_INITIATORn(5),sizeof(FR_F_INITIATOR0));
   memcpy(FR_F_MEMO0,pSettlementSegment->zF_MEMOn(0),sizeof(FR_F_MEMO0));
   memcpy(FR_F_MEMO1,pSettlementSegment->zF_MEMOn(1),sizeof(FR_F_MEMO0));
   memcpy(FR_F_MEMO2,pSettlementSegment->zF_MEMOn(2),sizeof(FR_F_MEMO0));
   memcpy(FR_F_MEMO3,pSettlementSegment->zF_MEMOn(3),sizeof(FR_F_MEMO0));
   memcpy(FR_F_MEMO4,pSettlementSegment->zF_MEMOn(4),sizeof(FR_F_MEMO0));
   memcpy(FR_F_MEMO5,pSettlementSegment->zF_MEMOn(5),sizeof(FR_F_MEMO0));
   memcpy(FR_F_TYPE0,pSettlementSegment->zF_TYPEn(0),sizeof(FR_F_TYPE0));
   memcpy(FR_F_TYPE1,pSettlementSegment->zF_TYPEn(1),sizeof(FR_F_TYPE0));
   memcpy(FR_F_TYPE2,pSettlementSegment->zF_TYPEn(2),sizeof(FR_F_TYPE0));
   memcpy(FR_F_TYPE3,pSettlementSegment->zF_TYPEn(3),sizeof(FR_F_TYPE0));
   memcpy(FR_F_TYPE4,pSettlementSegment->zF_TYPEn(4),sizeof(FR_F_TYPE0));
   memcpy(FR_F_TYPE5,pSettlementSegment->zF_TYPEn(5),sizeof(FR_F_TYPE0));
   memcpy(FR_HOST_RECV_FLG,pSettlementSegment->zHOST_RECV_FLG(),sizeof(FR_HOST_RECV_FLG));
   memcpy(FR_HOST_SENT_FLG,pSettlementSegment->zHOST_SENT_FLG(),sizeof(FR_HOST_SENT_FLG));
   memcpy(FR_INST_TIER,pSettlementSegment->zINST_TIER(),sizeof(FR_INST_TIER));
   memcpy(FR_MCI_AAV_RESULT_COD,pSettlementSegment->zMCI_AAV_RESULT_COD(),sizeof(FR_MCI_AAV_RESULT_COD));
   memcpy(FR_MCI_ECS_LVL_IND,pSettlementSegment->zMCI_ECS_LVL_IND(),sizeof(FR_MCI_ECS_LVL_IND));
   memcpy(FR_MCI_UCAF_DATA,pSettlementSegment->zMCI_UCAF_DATA(),sizeof(FR_MCI_UCAF_DATA));
   memcpy(FR_MTI,pSettlementSegment->zMTI(),sizeof(FR_MTI));
   memcpy(FR_MERCH_TIER_ID,pSettlementSegment->zMERCH_TIER_ID(),sizeof(FR_MERCH_TIER_ID));
   memcpy(FR_NET_INTRCHG_TIER,pSettlementSegment->zNET_INTRCHG_TIER(),sizeof(FR_NET_INTRCHG_TIER));
   memcpy(FR_OAR_RQST_FLG,pSettlementSegment->zOAR_RQST_FLG(),sizeof(FR_OAR_RQST_FLG));
   memcpy(FR_PAYEE,pSettlementSegment->zPAYEE(),sizeof(FR_PAYEE));
   memcpy(FR_PIN_FLG,pSettlementSegment->zPIN_FLG(),sizeof(FR_PIN_FLG));
   memcpy(FR_MULTI_CLEAR_SEQ_NO,pSettlementSegment->zMULTI_CLEAR_SEQ_NO(),sizeof(FR_MULTI_CLEAR_SEQ_NO));
   memcpy(FR_MULTI_CLEAR_COUNT,pSettlementSegment->zMULTI_CLEAR_COUNT(),sizeof(FR_MULTI_CLEAR_COUNT));
   memcpy(FR_POS_CARD_CAPT_CAP,pSettlementSegment->zPOS_CARD_CAPT_CAP(),sizeof(FR_POS_CARD_CAPT_CAP));
   memcpy(FR_POS_CARD_PRES,pSettlementSegment->zPOS_CARD_PRES(),sizeof(FR_POS_CARD_PRES));
   memcpy(FR_POS_CRDHLDR_AUTH,pSettlementSegment->zPOS_CRDHLDR_AUTH(),sizeof(FR_POS_CRDHLDR_AUTH));
   memcpy(FR_POS_CRDHLDR_AUTH_C,pSettlementSegment->zPOS_CRDHLDR_AUTH_C(),sizeof(FR_POS_CRDHLDR_AUTH_C));
   memcpy(FR_POS_CRDHLDR_PRESNT,pSettlementSegment->zPOS_CRDHLDR_PRESNT(),sizeof(FR_POS_CRDHLDR_PRESNT));
   memcpy(FR_POS_CRD_DAT_IN_CAP,pSettlementSegment->zPOS_CRD_DAT_IN_CAP(),sizeof(FR_POS_CRD_DAT_IN_CAP));
   memcpy(FR_POS_CRD_DAT_IN_MOD,pSettlementSegment->zPOS_CRD_DAT_IN_MOD(),sizeof(FR_POS_CRD_DAT_IN_MOD));
   memcpy(FR_POS_CRD_DAT_OT_CAP,pSettlementSegment->zPOS_CRD_DAT_OT_CAP(),sizeof(FR_POS_CRD_DAT_OT_CAP));
   memcpy(FR_POS_OPER_ENV,pSettlementSegment->zPOS_OPER_ENV(),sizeof(FR_POS_OPER_ENV));
   memcpy(FR_POS_PIN_CAPT_CAP,pSettlementSegment->zPOS_PIN_CAPT_CAP(),sizeof(FR_POS_PIN_CAPT_CAP));
   memcpy(FR_POS_TERM_OUT_CAP,pSettlementSegment->zPOS_TERM_OUT_CAP(),sizeof(FR_POS_TERM_OUT_CAP));
   memcpy(FR_PRINT_MASK_ID,pSettlementSegment->zPRINT_MASK_ID(),sizeof(FR_PRINT_MASK_ID));
   memcpy(FR_PROGRAM_ID,pSettlementSegment->zPROGRAM_ID(),sizeof(FR_PROGRAM_ID));
   memcpy(FR_ACQ_ROUTING_NO,pSettlementSegment->zACQ_ROUTING_NO(),sizeof(FR_ACQ_ROUTING_NO));
   memcpy(FR_ISS_ROUTING_NO,pSettlementSegment->zISS_ROUTING_NO(),sizeof(FR_ISS_ROUTING_NO));
   memcpy(FR_TRANS_ROUTING_NO,pSettlementSegment->zTRANS_ROUTING_NO(),sizeof(FR_TRANS_ROUTING_NO));
   memcpy(FR_DEST_ROUTING_NO,pSettlementSegment->zDEST_ROUTING_NO(),sizeof(FR_DEST_ROUTING_NO));
   memcpy(FR_AUTH_LCYCLE_TRACE,pSettlementSegment->zAUTH_LCYCLE_TRACE(),sizeof(FR_AUTH_LCYCLE_TRACE));
   FR_REF_DATA_ACQ.FR_REF_DATA_ACQ_len = pSettlementSegment->getSizeofREF_DATA_ACQ();
   memcpy(FR_REF_DATA_ACQ.FR_REF_DATA_ACQ_data,(char*)pSettlementSegment->zREF_DATA_ACQ(),FR_REF_DATA_ACQ.FR_REF_DATA_ACQ_len);
   FR_REF_DATA_ACQ_FMT = pSettlementSegment->getREF_DATA_ACQ_FMT();
   FR_REF_DATA_ISS.FR_REF_DATA_ISS_len = pSettlementSegment->getSizeofREF_DATA_ISS();
   memcpy(FR_REF_DATA_ISS.FR_REF_DATA_ISS_data,(char*)pSettlementSegment->zREF_DATA_ISS(),FR_REF_DATA_ISS.FR_REF_DATA_ISS_len);
   FR_REF_DATA_ISS_FMT = pSettlementSegment->getREF_DATA_ISS_FMT();
   memcpy(FR_TERM_CLASS,pSettlementSegment->zTERM_CLASS(),sizeof(FR_TERM_CLASS));
   FR_TIME_AT_AP = pSettlementSegment->getTIME_AT_AP();
   FR_TIME_AT_ISS = pSettlementSegment->getTIME_AT_ISS();
   FR_TIME_AT_RESP_QUE = pSettlementSegment->getTIME_AT_RESP_QUE();
   FR_TIME_AT_RESP_SWTCH = pSettlementSegment->getTIME_AT_RESP_SWTCH();
   FR_TIME_AT_RQST_QUE = pSettlementSegment->getTIME_AT_RQST_QUE();
   FR_TIME_AT_RQST_SWTCH = pSettlementSegment->getTIME_AT_RQST_SWTCH();
   FR_TRACK_2_DATA.FR_TRACK_2_DATA_len = pSettlementSegment->getSizeofTRACK_2_DATA();
   memcpy(FR_TRACK_2_DATA.FR_TRACK_2_DATA_data,pSettlementSegment->zTRACK_2_DATA(),pSettlementSegment->getSizeofTRACK_2_DATA());
   FR_TRAN_DESC.FR_TRAN_DESC_len = pSettlementSegment->getSizeofTRAN_DESC();
   memcpy(FR_TRAN_DESC.FR_TRAN_DESC_data,pSettlementSegment->zTRAN_DESC(),pSettlementSegment->getSizeofTRAN_DESC());
   FR_TRAN_UNIQUE_DATA.FR_TRAN_UNIQUE_DATA_len = pSettlementSegment->getSizeofTRAN_UNIQUE_DATA();
   memcpy(FR_TRAN_UNIQUE_DATA.FR_TRAN_UNIQUE_DATA_data,pSettlementSegment->zTRAN_UNIQUE_DATA(),pSettlementSegment->getSizeofTRAN_UNIQUE_DATA());
   memcpy(FR_TRAN_UNIQ_DATA_FMT,pSettlementSegment->zTRAN_UNIQ_DATA_FMT(),sizeof(FR_TRAN_UNIQ_DATA_FMT));
   memcpy(FR_BRIDGE_ACQ_FLG,pSettlementSegment->zBRIDGE_ACQ_FLG(),sizeof(FR_BRIDGE_ACQ_FLG));
   memcpy(FR_BRIDGE_ISS_FLG,pSettlementSegment->zBRIDGE_ISS_FLG(),sizeof(FR_BRIDGE_ISS_FLG));
   memcpy(FR_COOPER_SCORE,pSettlementSegment->zCOOPER_SCORE(),sizeof(FR_COOPER_SCORE));
   memcpy(FR_COOPER_REASON,pSettlementSegment->zCOOPER_REASON(),sizeof(FR_COOPER_REASON));
   FR_AMX_FRAUD_DATA.FR_AMX_FRAUD_DATA_len = pSettlementSegment->getSizeofAMX_FRAUD_DATA();
   memcpy(FR_AMX_FRAUD_DATA.FR_AMX_FRAUD_DATA_data,pSettlementSegment->zAMX_FRAUD_DATA(),pSettlementSegment->getSizeofAMX_FRAUD_DATA());
   memcpy(FR_ISSUER_SCRIPT_FLG,pSettlementSegment->zISSUER_SCRIPT_FLG(),sizeof(FR_ISSUER_SCRIPT_FLG));
   memcpy(FR_FP_HOLD_MATCH_FLG,pSettlementSegment->zFP_HOLD_MATCH_FLG(),sizeof(FR_FP_HOLD_MATCH_FLG));
  //## end dndb2database::UDBAddFinancialCommand::copySettlementToHost%4915EAB1032C.body
}

void UDBAddFinancialCommand::copyUserToHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::copyUserToHost%4915EAB1033C.body preserve=yes
   FinancialUserSegment* pUserSegment = FinancialUserSegment::instance();
   memcpy(FR_ACCT_TYPE_1,pUserSegment->zACCT_TYPE_1(),sizeof(FR_ACCT_TYPE_1));
   memcpy(FR_ACCT_TYPE_2,pUserSegment->zACCT_TYPE_2(),sizeof(FR_ACCT_TYPE_1));
   memcpy(FR_ACCT_TYPE_3,pUserSegment->zACCT_TYPE_3(),sizeof(FR_ACCT_TYPE_1));
   FR_ADL_RESP_ACCT_IDX0 = pUserSegment->getADL_RESP_ACCT_IDXn()[0];
   FR_ADL_RESP_ACCT_IDX1 = pUserSegment->getADL_RESP_ACCT_IDXn()[1];
   FR_ADL_RESP_ACCT_IDX2 = pUserSegment->getADL_RESP_ACCT_IDXn()[2];
   FR_ADL_RESP_ACCT_IDX3 = pUserSegment->getADL_RESP_ACCT_IDXn()[3];
   FR_ADL_RESP_ACCT_IDX4 = pUserSegment->getADL_RESP_ACCT_IDXn()[4];
   FR_ADL_RESP_ACCT_IDX5 = pUserSegment->getADL_RESP_ACCT_IDXn()[5];
   memcpy(FR_ADL_RESP_ACCT_TYP0,pUserSegment->zADL_RESP_ACCT_TYPn(0),sizeof(FR_ADL_RESP_ACCT_TYP0));
   memcpy(FR_ADL_RESP_ACCT_TYP1,pUserSegment->zADL_RESP_ACCT_TYPn(1),sizeof(FR_ADL_RESP_ACCT_TYP0));
   memcpy(FR_ADL_RESP_ACCT_TYP2,pUserSegment->zADL_RESP_ACCT_TYPn(2),sizeof(FR_ADL_RESP_ACCT_TYP0));
   memcpy(FR_ADL_RESP_ACCT_TYP3,pUserSegment->zADL_RESP_ACCT_TYPn(3),sizeof(FR_ADL_RESP_ACCT_TYP0));
   memcpy(FR_ADL_RESP_ACCT_TYP4,pUserSegment->zADL_RESP_ACCT_TYPn(4),sizeof(FR_ADL_RESP_ACCT_TYP0));
   memcpy(FR_ADL_RESP_ACCT_TYP5,pUserSegment->zADL_RESP_ACCT_TYPn(5),sizeof(FR_ADL_RESP_ACCT_TYP0));
   FR_ADL_RESP_AMT0 = pUserSegment->getADL_RESP_AMTn()[0];
   FR_ADL_RESP_AMT1 = pUserSegment->getADL_RESP_AMTn()[1];
   FR_ADL_RESP_AMT2 = pUserSegment->getADL_RESP_AMTn()[2];
   FR_ADL_RESP_AMT3 = pUserSegment->getADL_RESP_AMTn()[3];
   FR_ADL_RESP_AMT4 = pUserSegment->getADL_RESP_AMTn()[4];
   FR_ADL_RESP_AMT5 = pUserSegment->getADL_RESP_AMTn()[5];
   memcpy(FR_ADL_RESP_AMT_TYP0,pUserSegment->zADL_RESP_AMT_TYPn(0),sizeof(FR_ADL_RESP_AMT_TYP0));
   memcpy(FR_ADL_RESP_AMT_TYP1,pUserSegment->zADL_RESP_AMT_TYPn(1),sizeof(FR_ADL_RESP_AMT_TYP0));
   memcpy(FR_ADL_RESP_AMT_TYP2,pUserSegment->zADL_RESP_AMT_TYPn(2),sizeof(FR_ADL_RESP_AMT_TYP0));
   memcpy(FR_ADL_RESP_AMT_TYP3,pUserSegment->zADL_RESP_AMT_TYPn(3),sizeof(FR_ADL_RESP_AMT_TYP0));
   memcpy(FR_ADL_RESP_AMT_TYP4,pUserSegment->zADL_RESP_AMT_TYPn(4),sizeof(FR_ADL_RESP_AMT_TYP0));
   memcpy(FR_ADL_RESP_AMT_TYP5,pUserSegment->zADL_RESP_AMT_TYPn(5),sizeof(FR_ADL_RESP_AMT_TYP0));
   memcpy(FR_ADL_RESP_CUR_CODE0,pUserSegment->zADL_RESP_CUR_CODEn(0),sizeof(FR_ADL_RESP_CUR_CODE0));
   memcpy(FR_ADL_RESP_CUR_CODE1,pUserSegment->zADL_RESP_CUR_CODEn(1),sizeof(FR_ADL_RESP_CUR_CODE0));
   memcpy(FR_ADL_RESP_CUR_CODE2,pUserSegment->zADL_RESP_CUR_CODEn(2),sizeof(FR_ADL_RESP_CUR_CODE0));
   memcpy(FR_ADL_RESP_CUR_CODE3,pUserSegment->zADL_RESP_CUR_CODEn(3),sizeof(FR_ADL_RESP_CUR_CODE0));
   memcpy(FR_ADL_RESP_CUR_CODE4,pUserSegment->zADL_RESP_CUR_CODEn(4),sizeof(FR_ADL_RESP_CUR_CODE0));
   memcpy(FR_ADL_RESP_CUR_CODE5,pUserSegment->zADL_RESP_CUR_CODEn(5),sizeof(FR_ADL_RESP_CUR_CODE0));
   FR_ADL_RQST_ACCT_IDX0 = pUserSegment->getADL_RQST_ACCT_IDXn()[0];
   FR_ADL_RQST_ACCT_IDX1 = pUserSegment->getADL_RQST_ACCT_IDXn()[1];
   FR_ADL_RQST_ACCT_IDX2 = pUserSegment->getADL_RQST_ACCT_IDXn()[2];
   FR_ADL_RQST_ACCT_IDX3 = pUserSegment->getADL_RQST_ACCT_IDXn()[3];
   FR_ADL_RQST_ACCT_IDX4 = pUserSegment->getADL_RQST_ACCT_IDXn()[4];
   FR_ADL_RQST_ACCT_IDX5 = pUserSegment->getADL_RQST_ACCT_IDXn()[5];
   memcpy(FR_ADL_RQST_ACCT_TYP0,pUserSegment->zADL_RQST_ACCT_TYPn(0),sizeof(FR_ADL_RQST_ACCT_TYP0));
   memcpy(FR_ADL_RQST_ACCT_TYP1,pUserSegment->zADL_RQST_ACCT_TYPn(1),sizeof(FR_ADL_RQST_ACCT_TYP0));
   memcpy(FR_ADL_RQST_ACCT_TYP2,pUserSegment->zADL_RQST_ACCT_TYPn(2),sizeof(FR_ADL_RQST_ACCT_TYP0));
   memcpy(FR_ADL_RQST_ACCT_TYP3,pUserSegment->zADL_RQST_ACCT_TYPn(3),sizeof(FR_ADL_RQST_ACCT_TYP0));
   memcpy(FR_ADL_RQST_ACCT_TYP4,pUserSegment->zADL_RQST_ACCT_TYPn(4),sizeof(FR_ADL_RQST_ACCT_TYP0));
   memcpy(FR_ADL_RQST_ACCT_TYP5,pUserSegment->zADL_RQST_ACCT_TYPn(5),sizeof(FR_ADL_RQST_ACCT_TYP0));
   FR_ADL_RQST_AMT0 = pUserSegment->getADL_RQST_AMTn()[0];
   FR_ADL_RQST_AMT1 = pUserSegment->getADL_RQST_AMTn()[1];
   FR_ADL_RQST_AMT2 = pUserSegment->getADL_RQST_AMTn()[2];
   FR_ADL_RQST_AMT3 = pUserSegment->getADL_RQST_AMTn()[3];
   FR_ADL_RQST_AMT4 = pUserSegment->getADL_RQST_AMTn()[4];
   FR_ADL_RQST_AMT5 = pUserSegment->getADL_RQST_AMTn()[5];
   memcpy(FR_ADL_RQST_AMT_TYP0,pUserSegment->zADL_RQST_AMT_TYPn(0),sizeof(FR_ADL_RQST_AMT_TYP0));
   memcpy(FR_ADL_RQST_AMT_TYP1,pUserSegment->zADL_RQST_AMT_TYPn(1),sizeof(FR_ADL_RQST_AMT_TYP0));
   memcpy(FR_ADL_RQST_AMT_TYP2,pUserSegment->zADL_RQST_AMT_TYPn(2),sizeof(FR_ADL_RQST_AMT_TYP0));
   memcpy(FR_ADL_RQST_AMT_TYP3,pUserSegment->zADL_RQST_AMT_TYPn(3),sizeof(FR_ADL_RQST_AMT_TYP0));
   memcpy(FR_ADL_RQST_AMT_TYP4,pUserSegment->zADL_RQST_AMT_TYPn(4),sizeof(FR_ADL_RQST_AMT_TYP0));
   memcpy(FR_ADL_RQST_AMT_TYP5,pUserSegment->zADL_RQST_AMT_TYPn(5),sizeof(FR_ADL_RQST_AMT_TYP0));
   memcpy(FR_ADL_RQST_CUR_CODE0,pUserSegment->zADL_RQST_CUR_CODEn(0),sizeof(FR_ADL_RQST_CUR_CODE0));
   memcpy(FR_ADL_RQST_CUR_CODE1,pUserSegment->zADL_RQST_CUR_CODEn(1),sizeof(FR_ADL_RQST_CUR_CODE0));
   memcpy(FR_ADL_RQST_CUR_CODE2,pUserSegment->zADL_RQST_CUR_CODEn(2),sizeof(FR_ADL_RQST_CUR_CODE0));
   memcpy(FR_ADL_RQST_CUR_CODE3,pUserSegment->zADL_RQST_CUR_CODEn(3),sizeof(FR_ADL_RQST_CUR_CODE0));
   memcpy(FR_ADL_RQST_CUR_CODE4,pUserSegment->zADL_RQST_CUR_CODEn(4),sizeof(FR_ADL_RQST_CUR_CODE0));
   memcpy(FR_ADL_RQST_CUR_CODE5,pUserSegment->zADL_RQST_CUR_CODEn(5),sizeof(FR_ADL_RQST_CUR_CODE0));
   memcpy(FR_ALT_ROUTE_FLG,pUserSegment->zALT_ROUTE_FLG(),sizeof(FR_ALT_ROUTE_FLG));
   memcpy(FR_AP_APPROVAL_CODE,pUserSegment->zAP_APPROVAL_CODE(),sizeof(FR_AP_APPROVAL_CODE));
   memcpy(FR_AP_CARD_GRP,pUserSegment->zAP_CARD_GRP(),sizeof(FR_AP_CARD_GRP));
   memcpy(FR_AP_DATA,pUserSegment->zAP_DATA(),sizeof(FR_AP_DATA));
   FR_AP_ERROR_NO = pUserSegment->getAP_ERROR_NO();
   FR_AP_ERROR_TRACE_LOC = pUserSegment->getAP_ERROR_TRACE_LOC();
   FR_AP_REJ_REASON_CODE = pUserSegment->getAP_REJ_REASON_CODE();
   memcpy(FR_AUTH_LCYCLE_TCODE,pUserSegment->zAUTH_LCYCLE_TCODE(),sizeof(FR_AUTH_LCYCLE_TCODE));
   FR_AUTH_LIFECYCLE_INT = pUserSegment->getAUTH_LIFECYCLE_INT();
   FR_AUTH_RQST_TIMEOUT = pUserSegment->getAUTH_RQST_TIMEOUT();
   FR_BIN_LENGTH = pUserSegment->getBIN_LENGTH();
   memcpy(FR_CARD_ACPT_COUNTY,pUserSegment->zCARD_ACPT_COUNTY(),sizeof(FR_CARD_ACPT_COUNTY));
   memcpy(FR_CARD_ACPT_SPNSR_ID,pUserSegment->zCARD_ACPT_SPNSR_ID(),sizeof(FR_CARD_ACPT_SPNSR_ID));
   memcpy(FR_CARD_CAPT_FLG,pUserSegment->zCARD_CAPT_FLG(),sizeof(FR_CARD_CAPT_FLG));
   memcpy(FR_CLERK_ID,pUserSegment->zCLERK_ID(),sizeof(FR_CLERK_ID));
   memcpy(FR_CNTRY_RCN_ACQ_INST,pUserSegment->zCNTRY_RCN_ACQ_INST(),sizeof(FR_CNTRY_RCN_ACQ_INST));
   memcpy(FR_CNTRY_RCN_ISS_INST,pUserSegment->zCNTRY_RCN_ISS_INST(),sizeof(FR_CNTRY_RCN_ISS_INST));
   memcpy(FR_DATE_ACTION,pUserSegment->zDATE_ACTION(),sizeof(FR_DATE_ACTION));
   memcpy(FR_DATE_CAPTURE,pUserSegment->zDATE_CAPTURE(),sizeof(FR_DATE_CAPTURE));
   memcpy(FR_DATE_CNV_ACQ,pUserSegment->zDATE_CNV_ACQ(),sizeof(FR_DATE_CNV_ACQ));
   memcpy(FR_DATE_CNV_ISS,pUserSegment->zDATE_CNV_ISS(),sizeof(FR_DATE_CNV_ISS));
   memcpy(FR_DATE_EFFECTIVE,pUserSegment->zDATE_EFFECTIVE(),sizeof(FR_DATE_EFFECTIVE));
   memcpy(FR_DATE_RECON_NET,pUserSegment->zDATE_RECON_NET(),sizeof(FR_DATE_RECON_NET));
   memcpy(FR_DEPOSIT_ONLY_FLG,pUserSegment->zDEPOSIT_ONLY_FLG(),sizeof(FR_DEPOSIT_ONLY_FLG));
   memcpy(FR_EXTENDED_PAY_DATA,pUserSegment->zEXTENDED_PAY_DATA(),sizeof(FR_EXTENDED_PAY_DATA));
   memcpy(FR_PAN_INDICATOR,pUserSegment->zPAN_INDICATOR(),sizeof(FR_PAN_INDICATOR));
   memcpy(FR_PAN_RANGE,pUserSegment->zPAN_RANGE(),sizeof(FR_PAN_RANGE));
   KeyRing::instance()->tokenize((char*)pUserSegment->zPAN_RANGE(),19);
   memcpy(FR_PAN_TOKEN,pUserSegment->zPAN_TOKEN(),sizeof(FR_PAN_TOKEN));
   memcpy(FR_TOKEN_EXP_DATE,pUserSegment->zTOKEN_EXP_DATE(),sizeof(FR_TOKEN_EXP_DATE));
   memcpy(FR_TOKEN_REF_NUMBER,pUserSegment->zTOKEN_REF_NUMBER(),sizeof(FR_TOKEN_REF_NUMBER));
   memcpy(FR_TOKEN_SER_PROVIDER,pUserSegment->zTOKEN_SER_PROVIDER(),sizeof(FR_TOKEN_SER_PROVIDER));
   memcpy(FR_TOKEN_STATUS,pUserSegment->zTOKEN_STATUS(),sizeof(FR_TOKEN_STATUS));
   FR_TOKEN_TRANID.FR_TOKEN_TRANID_len = pUserSegment->getSizeofTOKEN_TRANID();
   memcpy(FR_TOKEN_TRANID.FR_TOKEN_TRANID_data,(char*)pUserSegment->zTOKEN_TRANID(),FR_TOKEN_TRANID.FR_TOKEN_TRANID_len);
   memcpy(FR_TOKEN_TYPE,pUserSegment->zTOKEN_TYPE(),sizeof(FR_TOKEN_TYPE));
   memcpy(FR_TOKEN_DEVICE_TYPE,pUserSegment->zTOKEN_DEVICE_TYPE(),sizeof(FR_TOKEN_DEVICE_TYPE));
   memcpy(FR_TOKEN_DEVICE_LOC,pUserSegment->zTOKEN_DEVICE_LOC(),sizeof(FR_TOKEN_DEVICE_LOC));
   memcpy(FR_TOKEN_CARD_SEQ_NO,pUserSegment->zTOKEN_CARD_SEQ_NO(),sizeof(FR_TOKEN_CARD_SEQ_NO));
   memcpy(FR_TOKEN_VERSION,pUserSegment->zTOKEN_VERSION(),sizeof(FR_TOKEN_VERSION));
   memcpy(FR_NETWORK_PROGRAM,pUserSegment->zNETWORK_PROGRAM(),sizeof(FR_NETWORK_PROGRAM));
   memcpy(FR_WEIGHTED_AVE_FLG,pUserSegment->zWEIGHTED_AVE_FLG(),sizeof(FR_WEIGHTED_AVE_FLG));
   memcpy(FR_TOKEN_REF_NUMBER_EXT,pUserSegment->zTOKEN_REF_NUMBER_EXT(),sizeof(FR_TOKEN_REF_NUMBER_EXT));
   memcpy(FR_ADDL_TRAN_DISP,pUserSegment->zADDL_TRAN_DISP(),sizeof(FR_ADDL_TRAN_DISP));
   FR_ADDL_TRAN_RESULT.FR_ADDL_TRAN_RESULT_len = pUserSegment->getSizeofADDL_TRAN_RESULT();
   memcpy(FR_ADDL_TRAN_RESULT.FR_ADDL_TRAN_RESULT_data,(char*)pUserSegment->zADDL_TRAN_RESULT(),FR_ADDL_TRAN_RESULT.FR_ADDL_TRAN_RESULT_len);
   memcpy(FR_SWIFT_CODE,pUserSegment->zSWIFT_CODE(),sizeof(FR_SWIFT_CODE));
   memcpy(FR_IFSC_CODE,pUserSegment->zIFSC_CODE(),sizeof(FR_IFSC_CODE));
   memcpy(FR_LOCAL_RETRIEVAL_REF_NO,pUserSegment->zLOCAL_RETRIEVAL_REF_NO(),sizeof(FR_LOCAL_RETRIEVAL_REF_NO));
   memcpy(FR_TOKEN_ACT_CODE,pUserSegment->zTOKEN_ACT_CODE(),sizeof(FR_TOKEN_ACT_CODE));
   memcpy(FR_TOKEN_STATUS_CODE,pUserSegment->zTOKEN_STATUS_CODE(),sizeof(FR_TOKEN_STATUS_CODE));
   memcpy(FR_TOKEN_ISSUER_PROC,pUserSegment->zTOKEN_ISSUER_PROC(),sizeof(FR_TOKEN_ISSUER_PROC));
   memcpy(FR_TOKEN_REQ_TSTAMP,pUserSegment->zTOKEN_REQ_TSTAMP(),sizeof(FR_TOKEN_REQ_TSTAMP));
   memcpy(FR_TOKEN_RESP_TSTAMP,pUserSegment->zTOKEN_RESP_TSTAMP(),sizeof(FR_TOKEN_RESP_TSTAMP));
   memcpy(FR_TOKEN_TIME_AT_TSP,pUserSegment->zTOKEN_TIME_AT_TSP(),sizeof(FR_TOKEN_TIME_AT_TSP));
   memcpy(FR_VISA_ATM_TRAN_ID,pUserSegment->zVISA_ATM_TRAN_ID(),sizeof(FR_VISA_ATM_TRAN_ID));
   memcpy(FR_DOMAIN_CTL_RESTR,pUserSegment->zDOMAIN_CTL_RESTR(),sizeof(FR_DOMAIN_CTL_RESTR));
   memcpy(FR_PGRM_PROTOCOL,pUserSegment->zPGRM_PROTOCOL(),sizeof(FR_PGRM_PROTOCOL));
   memcpy(FR_DIR_SERV_TRAN_ID,pUserSegment->zDIR_SERV_TRAN_ID(),sizeof(FR_DIR_SERV_TRAN_ID));
   memcpy(FR_TRAN_INT_CLASS,pUserSegment->zTRAN_INT_CLASS(),sizeof(FR_TRAN_INT_CLASS));
   memcpy(FR_ACL_ECOM_IND,pUserSegment->zACL_ECOM_IND(),sizeof(FR_ACL_ECOM_IND));
   memcpy(FR_P1C_ACCT_TOKEN,pUserSegment->zP1C_ACCT_TOKEN(),sizeof(FR_P1C_ACCT_TOKEN));
   memcpy(FR_P1C_ADL_RESP_DATA,pUserSegment->zP1C_ADL_RESP_DATA(),sizeof(FR_P1C_ADL_RESP_DATA));
   memcpy(FR_P1C_CRDHLDR_TOKEN,pUserSegment->zP1C_CRDHLDR_TOKEN(),sizeof(FR_P1C_CRDHLDR_TOKEN));
   memcpy(FR_PRM_ADL_RESP_DATA,pUserSegment->zPRM_ADL_RESP_DATA(),sizeof(FR_PRM_ADL_RESP_DATA));
   memcpy(FR_SAP_ADL_RESP_DATA,pUserSegment->zSAP_ADL_RESP_DATA(),sizeof(FR_SAP_ADL_RESP_DATA));
   FR_ECOM_DATA.FR_ECOM_DATA_len = pUserSegment->getSizeofECOM_DATA();
   memcpy(FR_ECOM_DATA.FR_ECOM_DATA_data,(char*)pUserSegment->zECOM_DATA(),FR_ECOM_DATA.FR_ECOM_DATA_len);
   memcpy(FR_INST_ID_FRWD,pUserSegment->zINST_ID_FRWD(),sizeof(FR_INST_ID_FRWD));
   memcpy(FR_TOKEN_DEVICE_NAME,pUserSegment->zTOKEN_DEVICE_NAME(),sizeof(FR_TOKEN_DEVICE_NAME));
   memcpy(FR_TOKEN_ENTITY,pUserSegment->zTOKEN_ENTITY(),sizeof(FR_TOKEN_ENTITY));
   memcpy(FR_HCE_ACTIVATE_RESULT,pUserSegment->zHCE_ACTIVATE_RESULT(),sizeof(FR_HCE_ACTIVATE_RESULT));
   memcpy(FR_AAM_VELOCITY_RESULT,pUserSegment->zAAM_VELOCITY_RESULT(),sizeof(FR_AAM_VELOCITY_RESULT));
   FR_LUK_ELAPSED_TIME = pUserSegment->getLUK_ELAPSED_TIME();
   FR_LUK_TRAN_COUNT = pUserSegment->getLUK_TRAN_COUNT();
   FR_LUK_AMT_TRAN = pUserSegment->getLUK_AMT_TRAN();
   FR_PIN_DATA_FMT = pUserSegment->getPIN_DATA_FMT();
   FR_PIN_RESULT = pUserSegment->getPIN_RESULT();
   FR_PMC_ERROR = pUserSegment->getPMC_ERROR();
   FR_PREAUTH_COMP_OPT = pUserSegment->getPREAUTH_COMP_OPT();
   FR_UNFORMATTED_MICR_DATA.FR_UNFORMATTED_MICR_DATA_len = pUserSegment->getSizeofUNFORMATTED_MICR_DATA();
   memcpy(FR_UNFORMATTED_MICR_DATA.FR_UNFORMATTED_MICR_DATA_data,(char*)pUserSegment->zUNFORMATTED_MICR_DATA(),FR_UNFORMATTED_MICR_DATA.FR_UNFORMATTED_MICR_DATA_len);
   memcpy(FR_RECON_IND_ACQ,pUserSegment->zRECON_IND_ACQ(),sizeof(FR_RECON_IND_ACQ));
   memcpy(FR_RESTRIC_INTCHG_GRP,pUserSegment->zRESTRIC_INTCHG_GRP(),sizeof(FR_RESTRIC_INTCHG_GRP));
   memcpy(FR_SOURCE_ROUTE_ID,pUserSegment->zSOURCE_ROUTE_ID(),sizeof(FR_SOURCE_ROUTE_ID));
   memcpy(FR_SRV_GRP_INTCHG_IND,pUserSegment->zSRV_GRP_INTCHG_IND(),sizeof(FR_SRV_GRP_INTCHG_IND));
   memcpy(FR_SRV_GRP_SERV_CODE,pUserSegment->zSRV_GRP_SERV_CODE(),sizeof(FR_SRV_GRP_SERV_CODE));
   memcpy(FR_STANDIN_ACT,pUserSegment->zSTANDIN_ACT(),sizeof(FR_STANDIN_ACT));
   memcpy(FR_STANDIN_OPTION,pUserSegment->zSTANDIN_OPTION(),sizeof(FR_STANDIN_OPTION));
   memcpy(FR_TOKEN_ASSURANCE,pUserSegment->zTOKEN_ASSURANCE(),sizeof(FR_TOKEN_ASSURANCE));
   memcpy(FR_TOKEN_REQUESTOR_ID,pUserSegment->zTOKEN_REQUESTOR_ID(),sizeof(FR_TOKEN_REQUESTOR_ID));
   memcpy(FR_TRACINF_KEYTRAC_NO,pUserSegment->zTRACINF_KEYTRAC_NO(),sizeof(FR_TRACINF_KEYTRAC_NO));
   memcpy(FR_TRACK_INFO_KEY_ID,pUserSegment->zTRACK_INFO_KEY_ID(),sizeof(FR_TRACK_INFO_KEY_ID));
   memcpy(FR_TRAN_FROM_ACCT_FLG,pUserSegment->zTRAN_FROM_ACCT_FLG(),sizeof(FR_TRAN_FROM_ACCT_FLG));
   memcpy(FR_TRAN_TO_ACCT_FLG,pUserSegment->zTRAN_TO_ACCT_FLG(),sizeof(FR_TRAN_TO_ACCT_FLG));
   FR_USAGE_UPDATE_BITS = pUserSegment->getUSAGE_UPDATE_BITS();
   FR_PROC_FLGS1.FR_PROC_FLGS1_len = 2;
   memcpy(FR_PROC_FLGS1.FR_PROC_FLGS1_data,pUserSegment->zPROC_FLGSn(0),2);
   FR_PROC_FLGS2.FR_PROC_FLGS2_len = 2;
   memcpy(FR_PROC_FLGS2.FR_PROC_FLGS2_data,pUserSegment->zPROC_FLGSn(1),2);
   FR_PROC_FLGS3.FR_PROC_FLGS3_len = 2;
   memcpy(FR_PROC_FLGS3.FR_PROC_FLGS3_data,pUserSegment->zPROC_FLGSn(2),2);
   FR_PROC_FLGS4.FR_PROC_FLGS4_len = 2;
   memcpy(FR_PROC_FLGS4.FR_PROC_FLGS4_data,pUserSegment->zPROC_FLGSn(3),2);
   FR_PROC_BILLING_FLGS1.FR_PROC_BILLING_FLGS1_len = 2;
   memcpy(FR_PROC_BILLING_FLGS1.FR_PROC_BILLING_FLGS1_data,pUserSegment->zPROC_BILLING_FLGSn(0),2);
   FR_PROC_BILLING_FLGS2.FR_PROC_BILLING_FLGS2_len = 2;
   memcpy(FR_PROC_BILLING_FLGS2.FR_PROC_BILLING_FLGS2_data,pUserSegment->zPROC_BILLING_FLGSn(1),2);
   FR_PROC_BILLING_FLGS3.FR_PROC_BILLING_FLGS3_len = 2;
   memcpy(FR_PROC_BILLING_FLGS3.FR_PROC_BILLING_FLGS3_data,pUserSegment->zPROC_BILLING_FLGSn(2),2);
   FR_PROC_BILLING_FLGS4.FR_PROC_BILLING_FLGS4_len = 2;
   memcpy(FR_PROC_BILLING_FLGS4.FR_PROC_BILLING_FLGS4_data,pUserSegment->zPROC_BILLING_FLGSn(3),2);
   memcpy(FR_PAN_IDENTIFIER,pUserSegment->zPAN_IDENTIFIER(),sizeof(FR_PAN_IDENTIFIER));
   memcpy(FR_PYMT_ACCT_REF,pUserSegment->zPYMT_ACCT_REF(),sizeof(FR_PYMT_ACCT_REF));
   FR_MERCH_DISP_NAME.FR_MERCH_DISP_NAME_len = pUserSegment->getSizeofMERCH_DISP_NAME();
   memcpy(FR_MERCH_DISP_NAME.FR_MERCH_DISP_NAME_data,(char*)pUserSegment->zMERCH_DISP_NAME(),FR_MERCH_DISP_NAME.FR_MERCH_DISP_NAME_len);
   memcpy(FR_EMV_3D_CAVV_VER_BY,pUserSegment->zEMV_3D_CAVV_VER_BY(),sizeof(FR_EMV_3D_CAVV_VER_BY));
   memcpy(FR_EMV_3D_TRAN_ID,pUserSegment->zEMV_3D_TRAN_ID(),sizeof(FR_EMV_3D_TRAN_ID));
   FR_SELLER_EMAIL.FR_SELLER_EMAIL_len = pUserSegment->getSizeofSELLER_EMAIL();
   memcpy(FR_SELLER_EMAIL.FR_SELLER_EMAIL_data,(char*)pUserSegment->zSELLER_EMAIL(),FR_SELLER_EMAIL.FR_SELLER_EMAIL_len);
   FR_SELLER_PHONE.FR_SELLER_PHONE_len = pUserSegment->getSizeofSELLER_PHONE();
   memcpy(FR_SELLER_PHONE.FR_SELLER_PHONE_data,(char*)pUserSegment->zSELLER_PHONE(),FR_SELLER_PHONE.FR_SELLER_PHONE_len);
   FR_SELLER_ID.FR_SELLER_ID_len = pUserSegment->getSizeofSELLER_ID();
   memcpy(FR_SELLER_ID.FR_SELLER_ID_data,(char*)pUserSegment->zSELLER_ID(),FR_SELLER_ID.FR_SELLER_ID_len);
   memcpy(FR_FORCE_POST_DROP_IND,pUserSegment->zFORCE_POST_DROP_IND(),sizeof(FR_FORCE_POST_DROP_IND));
   memcpy(FR_ODE_INST_ID_FRWD,pUserSegment->zODE_INST_ID_FRWD(),sizeof(FR_ODE_INST_ID_FRWD));
   memcpy(FR_ODE_DATE_TIME_XMIT,pUserSegment->zODE_DATE_TIME_XMIT(),sizeof(FR_ODE_DATE_TIME_XMIT));
   memcpy(FR_DATE_TIME_XMIT,pUserSegment->zDATE_TIME_XMIT(),sizeof(FR_DATE_TIME_XMIT));
   FR_PAN_TOKEN_BIN_LEN = pUserSegment->getPAN_TOKEN_BIN_LEN();
   FR_TOKEN_DEVICE_ID.FR_TOKEN_DEVICE_ID_len  = pUserSegment->getSizeofTOKEN_DEVICE_ID();
   memcpy(FR_TOKEN_DEVICE_ID.FR_TOKEN_DEVICE_ID_data,(char*)pUserSegment->zTOKEN_DEVICE_ID(),FR_TOKEN_DEVICE_ID.FR_TOKEN_DEVICE_ID_len);
   memcpy(FR_WALLET_REASON,pUserSegment->zWALLET_REASON(),sizeof(FR_WALLET_REASON));
  //## end dndb2database::UDBAddFinancialCommand::copyUserToHost%4915EAB1033C.body
}

bool UDBAddFinancialCommand::execute ()
{
  //## begin dndb2database::UDBAddFinancialCommand::execute%4915EAB1034B.body preserve=yes
   if (Database::instance()->getDormant())
      Database::instance()->connect();
   if (Database::instance()->state() == Database::DISCONNECTED)
   {
      UseCase::add("CONNECT");
      return false;
   }
   FinancialBaseSegment* pBaseSegment = FinancialBaseSegment::instance();
   string strBuffer;
   if (Extract::instance()->getSpec("RU07",strBuffer)
      && strBuffer.find("NPI~ACCT_ID_1=2") != string::npos)
      KeyRing::instance()->tokenize((char*)pBaseSegment->zACCT_ID_1(),28,FR_TSTAMP_TRANS);
   memcpy(FR_ACCT_ID_1,pBaseSegment->zACCT_ID_1(),sizeof(FR_ACCT_ID_1));
   FR_AMT_RECON_NET = pBaseSegment->getAMT_RECON_NET();
   memcpy(FR_CUR_RECON_NET,pBaseSegment->zCUR_RECON_NET(),sizeof(FR_CUR_RECON_NET));
   memcpy(FR_FUNC_CODE,pBaseSegment->zFUNC_CODE(),sizeof(FR_FUNC_CODE));
   memcpy(FR_MERCH_TYPE,pBaseSegment->zMERCH_TYPE(),sizeof(FR_MERCH_TYPE));
   memcpy(FR_DATE_RECON_ACQ,pBaseSegment->zDATE_RECON_ACQ(),sizeof(FR_DATE_RECON_ACQ));
   memcpy(FR_DATE_RECON_ISS,FinancialSettlementSegment::instance()->zDATE_RECON_ISS(),sizeof(FR_DATE_RECON_ISS));
   memcpy(FR_PAN_TOKEN,FinancialUserSegment::instance()->zPAN_TOKEN(),sizeof(FR_PAN_TOKEN));
   memcpy(FR_CARD_ACPT_BUS_CODE,pBaseSegment->zCARD_ACPT_BUS_CODE(),sizeof(FR_CARD_ACPT_BUS_CODE));
   memcpy(FR_COUNTRY_ACQ_INST,pBaseSegment->zCOUNTRY_ACQ_INST(),sizeof(FR_COUNTRY_ACQ_INST));
   memcpy(FR_TRAN_DISPOSITION,pBaseSegment->zTRAN_DISPOSITION(),sizeof(FR_TRAN_DISPOSITION));
   memcpy(FR_CARD_ACPT_ID,FinancialSettlementSegment::instance()->zCARD_ACPT_ID(),sizeof(FR_CARD_ACPT_ID));
   memcpy(FR_POS_CRD_DAT_IN_MOD,FinancialSettlementSegment::instance()->zPOS_CRD_DAT_IN_MOD(),sizeof(FR_POS_CRD_DAT_IN_MOD));
   bool bLateReversal = false;
   if (memcmp(DataModel::instance()->getCurrent().data(),pBaseSegment->zTSTAMP_TRANS(),6) > 0)
   {
      pBaseSegment->setTSTAMP_TRANS(Clock::instance()->getYYYYMMDDHHMMSSHN(true).data(),16);
      bLateReversal = true;
   }
   memcpy(FR_TSTAMP_TRANS,pBaseSegment->zTSTAMP_TRANS(),sizeof(FR_TSTAMP_TRANS));
   memcpy(FL_FIN_TYPE,pBaseSegment->zFIN_TYPE(),sizeof(FL_FIN_TYPE));
   int iBIN_LENGTH = FinancialUserSegment::instance()->getBIN_LENGTH();
   if (iBIN_LENGTH > 6 && iBIN_LENGTH <= 8)
   {
      memcpy(FL_PAN_PREFIX,pBaseSegment->zPAN(),iBIN_LENGTH);
      FL_PAN_PREFIX[iBIN_LENGTH] = '\0';
   }
   else
   {
      memcpy(FL_PAN_PREFIX,pBaseSegment->zPAN(),6);
      FL_PAN_PREFIX[6] = '\0';
   }
   string strPAN(pBaseSegment->zPAN());
   rtrim(strPAN);
   if (strPAN.length() > 4)
      memcpy(FL_PAN_SUFFIX,strPAN.data() + strPAN.length() - 4,4);
   else
      memcpy(FL_PAN_SUFFIX,"9999",4);
   FL_PAN_SUFFIX[4] = '\0';
   string strPAN_TOKEN(FinancialUserSegment::instance()->zPAN_TOKEN());
   rtrim(strPAN_TOKEN);
   int iPAN_TOKEN_BIN_LEN = FinancialUserSegment::instance()->getPAN_TOKEN_BIN_LEN();
   if (!strPAN_TOKEN.empty())
   {
      if (strPAN_TOKEN.length() > 6)
      {
         if (iPAN_TOKEN_BIN_LEN > 6 && iPAN_TOKEN_BIN_LEN <= 8)
         {
            memcpy(FL_PAN_TOKEN_PREFIX,FinancialUserSegment::instance()->zPAN_TOKEN(),iPAN_TOKEN_BIN_LEN);
            FL_PAN_TOKEN_PREFIX[iPAN_TOKEN_BIN_LEN] = '\0';
         }
         else
         {
             memcpy(FL_PAN_TOKEN_PREFIX,FinancialUserSegment::instance()->zPAN_TOKEN(),6);
             FL_PAN_TOKEN_PREFIX[6] = '\0';
         }
      }
      else
      {
         memcpy(FL_PAN_TOKEN_PREFIX,FinancialUserSegment::instance()->zPAN_TOKEN(),strPAN_TOKEN.length());
         FL_PAN_TOKEN_PREFIX[strPAN_TOKEN.length() - 1] = '\0';
      }
      if (strPAN_TOKEN.length() > 4)
         memcpy(FL_PAN_TOKEN_SUFFIX,strPAN_TOKEN.data() + strPAN_TOKEN.length() - 4,4);
      else
         memcpy(FL_PAN_TOKEN_SUFFIX,"9999",4);
      FL_PAN_TOKEN_SUFFIX[4] = '\0';
   }
   else
   {
      FL_PAN_TOKEN_PREFIX[0] = '\0';
      FL_PAN_TOKEN_SUFFIX[0] = '\0';
   }
   if (FinancialSettlementSegment::instance()->getSizeofTRAN_DESC() >= 5
      && memcmp(FinancialSettlementSegment::instance()->zTRAN_DESC(),"72  ",4) == 0)
   {
      int i = FinancialSettlementSegment::instance()->getSizeofTRAN_DESC() - 4;
      if (i > 15)
         i = 15;
      memcpy(FL_INV_ORDER_NO,FinancialSettlementSegment::instance()->zTRAN_DESC() + 4,i);
      FL_INV_ORDER_NO[i] = '\0';
   }
   else
      FL_INV_ORDER_NO[0] = '\0';
   KeyRing::instance()->tokenize((char*)pBaseSegment->zPAN(),28,FR_TSTAMP_TRANS);
   copyMemberToHost();
   char szDate[9] = {"        "};
   memcpy(szDate,FinancialBaseSegment::instance()->zTSTAMP_TRANS(),8);
   FR_PARTITION_KEY = atoi(szDate + 6);
   if (pBaseSegment->getUNIQUENESS_KEY() == 0)
   {
      if (m_siUNIQUENESS_KEY >= 32767)
         m_siUNIQUENESS_KEY = 1;
      else
         ++m_siUNIQUENESS_KEY;
      FR_UNIQUENESS_KEY = m_siUNIQUENESS_KEY;
      pBaseSegment->setUNIQUENESS_KEY(FR_UNIQUENESS_KEY);
   }
   else
      FR_UNIQUENESS_KEY = pBaseSegment->getUNIQUENESS_KEY();
   // sequence indicates minute load operation occurred
   // format is yyydddhhmm where yyy is year relative to 1997
   // if Evidence list is present and ACQ_PLAT_PROD_ID = 'V' (TC57) then value is -2
   // if Evidence list is not present and ACQ_PLAT_PROD_ID == 'V' then value is -1
   // if Evidence list is present and ACQ_PLAT_PROD_ID != 'V' then value is 0
   // if Evidence list is not present and ACQ_PLAT_PROD_ID != 'V' then assign valid sequence number
   string strCustomCode = Extract::instance()->getCustomCode();
   if (problem())
   {
      if (!memcmp(pBaseSegment->zACQ_PLAT_PROD_ID(),"V",1) && (strCustomCode == "USPS" || strCustomCode == "KFH"))
         FR_INSERT_SEQUENCE_NO = -2;
      else if ((!memcmp(pBaseSegment->zTRAN_CLASS(),"SBC",3) || !memcmp(pBaseSegment->zTRAN_CLASS(),"SBD",3))
               && Extract::instance()->getCustomCode() == "LCPL")
         FR_INSERT_SEQUENCE_NO = -2;
      else
         FR_INSERT_SEQUENCE_NO = 0;
   }
   else
   {
      if (!memcmp(pBaseSegment->zACQ_PLAT_PROD_ID(),"V",1) && (strCustomCode == "USPS" || strCustomCode == "KFH"))
         FR_INSERT_SEQUENCE_NO = -1;
      else
      if ((!memcmp(pBaseSegment->zTRAN_CLASS(),"SBC",3) || !memcmp(pBaseSegment->zTRAN_CLASS(),"SBD",3))
         && Extract::instance()->getCustomCode() == "LCPL")
         FR_INSERT_SEQUENCE_NO = -1;
      else
      if (bLateReversal
         && Extract::instance()->getCustomCode() != "NAB")
         FR_INSERT_SEQUENCE_NO = 0;
      else
         FR_INSERT_SEQUENCE_NO = InsertSequenceNumber::getYYYDDDHHMM((char* const)pBaseSegment->zTSTAMP_TRANS());
   }
   bool bReturn = false;
   if (m_nTransaction != Database::instance()->transaction())
   {
      char* p = strstr(FINU_INSERT.data,"FIN_RECORD");
      memcpy(p + 10,"YYYYMM",6);
      p = strstr(FI_INSERT.data,"FIN_ICC");
      memcpy(p + 7,"YYYYMM",6);
      p = strstr(FM_INSERT.data,"FIN_ROUTE");
      memcpy(p + 9,"YYYYMM",6);
      p = strstr(FFR_INSERT.data,"FIN_FRAUD_RULE_");
      memcpy(p + 15,"YYYYMM",6);
      p = strstr(FL_INSERT.data,"FIN_L");
      memcpy(p + 5,"YYYYMM",6);
      p = strstr(FL_SELECT.data,"FIN_L");
      memcpy(p + 5,"YYYYMM",6);
      p = strstr(FINU_UPDATE.data,"FIN_RECORD");
      memcpy(p + 10,"YYYYMM",6);
      m_nTransaction = Database::instance()->transaction();
   }
   if (m_bUpdate)
      m_nState = UDBAddFinancialCommand::PREPARE_UPDATE_FIN_L;
   else
   if (pBaseSegment->zACQ_PLAT_PROD_ID()[0] == 'I')
      m_nState = UDBAddFinancialCommand::PREPARE_INSERT_FIN_L;
   else
      m_nState =((memcmp(FinancialBaseSegment::instance()->zFIN_TYPE(),"025",3) > 0 &&
                  memcmp(FinancialBaseSegment::instance()->zFIN_TYPE(),"800",3) < 0) ||
                  memcmp(FinancialBaseSegment::instance()->zTRAN_DISPOSITION(),"3",1) == 0 ) ?
                    UDBAddFinancialCommand::PREPARE_SELECT_FIN_L :
                    UDBAddFinancialCommand::PREPARE_INSERT_FIN_L;
   m_strTSTAMP_TRANS.erase();
   m_iRetryCount = 0;
   int iLoop = 0;
   for (;;)
   {
      if (++iLoop > 32)
         m_nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
      switch (m_nState)
      {
         case UDBAddFinancialCommand::PREPARE_SELECT_FIN_L:
            m_nState = prepareSelect();
            break;
         case UDBAddFinancialCommand::SELECT_FIN_L:
            m_nState = selectLocator();
            break;
         case UDBAddFinancialCommand::PREPARE_INSERT_FIN_L:
            m_nState = prepareInsert();
            break;
         case UDBAddFinancialCommand::INSERT_FIN_L:
            m_nState = insertLocator();
            break;
         case UDBAddFinancialCommand::PREPARE_INSERT_FIN_ICC:
            m_nState = prepareICC();
            break;
         case UDBAddFinancialCommand::INSERT_FIN_ICC:
            m_nState = insertICC();
            if (MultipleRouteSegment::instance()->presence()
               && m_nState == UDBAddFinancialCommand::SUCCESS)
               m_nState = UDBAddFinancialCommand::PREPARE_INSERT_MULTIPLE_ROUTE;
            else
            {
               if (m_nState == UDBAddFinancialCommand::SUCCESS
                  && m_pListSegment[0]->presence()
                  && m_pListSegment[0]->itemCount() > 0)
               {
                  char* p = (char*)*m_pListSegment[0];
                  if (!memcmp(p,(const char*)"S231",4))
                     m_nState = UDBAddFinancialCommand::PREPARE_INSERT_FRAUD_RULE;
               }
            }
            break;
        case UDBAddFinancialCommand::PREPARE_INSERT_MULTIPLE_ROUTE:
            m_nState = prepareMultipleRoute();
            break;
        case UDBAddFinancialCommand::INSERT_MULTIPLE_ROUTE:
            m_nState = insertMultipleRoute();
             if (m_nState == UDBAddFinancialCommand::SUCCESS)
             {
                if (m_pListSegment[0]->presence()
                   && m_pListSegment[0]->itemCount() > 0)
                {
                   char* p = (char*)*m_pListSegment[0];
                   if (!memcmp(p,(const char*)"S231",4))
                      m_nState = UDBAddFinancialCommand::PREPARE_INSERT_FRAUD_RULE;
                }
             }
            break;
        case UDBAddFinancialCommand::PREPARE_INSERT_FRAUD_RULE:
            m_nState = prepareFraudRule();
            break;
        case UDBAddFinancialCommand::INSERT_FRAUD_RULE:
            m_pBuffer=(char*)*(m_pListSegment[0]);
            for (int i = 0;i < m_pListSegment[0]->itemCount();++i){
               if (m_nState == UDBAddFinancialCommand::DATABASE_FAILURE)
               {
                  Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
                  break;
               }
               m_nState = insertFraudRule();
            }
            break;
         case UDBAddFinancialCommand::PREPARE_INSERT_FIN_RECORD:
            m_nState = prepareMonthlyFinancial();
            break;
         case UDBAddFinancialCommand::INSERT_FIN_RECORD:
            m_nState = insertFinancial();
            if (m_nState == UDBAddFinancialCommand::SUCCESS)
            {
               if (!AddFinancialCommand::execute())
                  m_nState = UDBAddFinancialCommand::EXIT;
               else
               {
                  if(IntegratedCircuitCardSegment::instance()->presence())
                     m_nState = UDBAddFinancialCommand::PREPARE_INSERT_FIN_ICC;
                  else
                  {
                     if (MultipleRouteSegment::instance()->presence())
                        m_nState = UDBAddFinancialCommand::PREPARE_INSERT_MULTIPLE_ROUTE;
                     else
                     if (m_pListSegment[0]->presence()
                        && m_pListSegment[0]->itemCount() > 0)
                     {
                        char* p = (char*)*m_pListSegment[0];
                        if (!memcmp(p,(const char*)"S231",4))
                           m_nState = UDBAddFinancialCommand::PREPARE_INSERT_FRAUD_RULE;
                     }
                  }
               }
            }
            break;
         case UDBAddFinancialCommand::SUCCESS:
            bReturn = true;
            m_nState = UDBAddFinancialCommand::EXIT;
            break;
         case UDBAddFinancialCommand::EXIT:
            return bReturn;
         case UDBAddFinancialCommand::PREPARE_UPDATE_FIN_L:
            m_nState = prepareUpdate();
            break;
         case UDBAddFinancialCommand::UPDATE_FIN_L:
            m_nState = updateLocator();
            break;
         case UDBAddFinancialCommand::PREPARE_UPDATE_FIN_RECORD:
            m_nState = prepareMonthlyUpdateFinancial();
            break;
         case UDBAddFinancialCommand::UPDATE_FIN_RECORD:
            m_nState = updateFinancial();
            break;
         case UDBAddFinancialCommand::INTERPRET_DUPLICATE:
            m_nState = interpretDuplicate();
            break;
         case UDBAddFinancialCommand::TIMESTAMP_DUPLICATE:
            if (pBaseSegment->getUNIQUENESS_KEY() == 0)
            {
               if (m_siUNIQUENESS_KEY >= 32767)
                  m_siUNIQUENESS_KEY = 1;
               else
                  ++m_siUNIQUENESS_KEY;
               FR_UNIQUENESS_KEY = m_siUNIQUENESS_KEY;
               pBaseSegment->setUNIQUENESS_KEY(FR_UNIQUENESS_KEY);
            }
            else
            {
               if(FR_UNIQUENESS_KEY >= 32767)
                  FR_UNIQUENESS_KEY = 1;
               else
                  FR_UNIQUENESS_KEY++;
               pBaseSegment->setUNIQUENESS_KEY(FR_UNIQUENESS_KEY);
            }
            iLoop = 0;
            m_nState = UDBAddFinancialCommand::PREPARE_INSERT_FIN_L;
            break;
         case UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT:
            UseCase::add("DEADLOCK");
            Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            bReturn = true;
            m_nState = UDBAddFinancialCommand::EXIT;
            break;
         case UDBAddFinancialCommand::UPDATE_DEADLOCK_TIMEOUT:
            UseCase::add("DEADLOCK");
            Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            bReturn = true;
            m_nState = UDBAddFinancialCommand::EXIT;
            break;
         case UDBAddFinancialCommand::DATABASE_FAILURE:
            UseCase::add("DBERROR");
            Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            m_nState = UDBAddFinancialCommand::EXIT;
            break;
         case UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            m_nState = UDBAddFinancialCommand::EXIT;
            break;
         case UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR:
            UseCase::add("RESOURCE");
            Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            return bReturn;
      }
   }
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   return false;
  //## end dndb2database::UDBAddFinancialCommand::execute%4915EAB1034B.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::insertFinancial ()
{
  //## begin dndb2database::UDBAddFinancialCommand::insertFinancial%4915EAB1035B.body preserve=yes
   State nState;

   
/*
EXEC SQL EXECUTE DI2 USING
      :FR_PARTITION_KEY,
      :FR_UNIQUENESS_KEY,
      :FR_INSERT_SEQUENCE_NO,
      :FR_ACCT_ID_1,
      :FR_ACCT_ID_2,
      :FR_ACCT_ID_3,
      :FR_ACCT_TYPES_ISS,
      :FR_ACQ_PLAT_PROD_ID,
      :FR_AMT_CARD_BILL,
      :FR_AMT_RECON_NET,
      :FR_AMT_TRAN,
      :FR_CARD_ACPT_BUS_CODE,
      :FR_CARD_ACPT_COUNTRY,
      :FR_CARD_ACPT_NAME_LOC,
      :FR_CARD_ACPT_PST_CODE,
      :FR_CARD_ACPT_REGION,
      :FR_CARD_SEQ_NO,
      :FR_CED_BUILD_NO,
      :FR_CIRC_ID_ACQ,
      :FR_CIRC_ID_ISS,
      :FR_COUNTRY_ACQ_INST,
      :FR_COUNTRY_ISS_INST,
      :FR_CUR_CARD_BILL,
      :FR_CUR_RECON_NET,
      :FR_CUR_TRAN,
      :FR_DATE_RECON_ACQ,
      :FR_FUNC_CODE,
      :FR_MERCH_TYPE,
      :FR_MSG_RESON_CODE_ACQ,
      :FR_MSG_RESON_CODE_ISS,
      :FR_NET_ID_ACQ,
      :FR_NET_ID_ISS,
      :FR_POS_CRDHLDR_A_METH,
      :FR_REIMBURSEMENT_ATTR,
      :FR_REV_BY,
      :FR_TRAN_DISPOSITION,
      :FR_TSTAMP_TRANS,
      :FR_ACCT_QUAL_1,
      :FR_ACCT_QUAL_2,
      :FR_ADL_DATA_PRIV_ACQ,
      :FR_ADL_RESP_DATA,
      :FR_AMT_RECON_ACQ,
      :FR_AMT_RECON_ISS,
      :FR_AP_FLG,
      :FR_CAN_ITEM_VALUE0,
      :FR_CAN_ITEM_VALUE1,
      :FR_CAN_ITEM_VALUE2,
      :FR_CAN_ITEM_VALUE3,
      :FR_CAN_ITEM_VALUE4,
      :FR_CAN_ITEM_VALUE5,
      :FR_CAN_ITEM_VALUE6,
      :FR_CAN_ITEM_VALUE7,
      :FR_CAN_NO_ITEMS_DISP0,
      :FR_CAN_NO_ITEMS_DISP1,
      :FR_CAN_NO_ITEMS_DISP2,
      :FR_CAN_NO_ITEMS_DISP3,
      :FR_CAN_NO_ITEMS_DISP4,
      :FR_CAN_NO_ITEMS_DISP5,
      :FR_CAN_NO_ITEMS_DISP6,
      :FR_CAN_NO_ITEMS_DISP7,
      :FR_CAN_ORIG_NO_ITEMS0,
      :FR_CAN_ORIG_NO_ITEMS1,
      :FR_CAN_ORIG_NO_ITEMS2,
      :FR_CAN_ORIG_NO_ITEMS3,
      :FR_CAN_ORIG_NO_ITEMS4,
      :FR_CAN_ORIG_NO_ITEMS5,
      :FR_CAN_ORIG_NO_ITEMS6,
      :FR_CAN_ORIG_NO_ITEMS7,
      :FR_CARD_ACPT_ID,
      :FR_CARD_OWNER,
      :FR_CARD_TYPE,
      :FR_CAVV_RESULT,
      :FR_CNV_CRD_BIL_DE_POS,
      :FR_CNV_CRD_BIL_RATE,
      :FR_CNV_RCN_ACQ_DE_POS,
      :FR_CNV_RCN_ACQ_RATE,
      :FR_CNV_RCN_ISS_DE_POS,
      :FR_CNV_RCN_ISS_RATE,
      :FR_CNV_RCN_NET_DE_POS,
      :FR_CNV_RCN_NET_RATE,
      :FR_CRD_ACP_NAM_FMTFLG,
      :FR_CUR_RECON_ACQ,
      :FR_CUR_RECON_ISS,
      :FR_CUR_TYPE,
      :FR_CVV_CVC_RESULT,
      :FR_CVV2_CVC2_RESULT,
      :FR_DATA_PRIV_ACQ,
      :FR_DATA_PRIV_ACQ_FMT,
      :FR_DATA_PRIV_ISS,
      :FR_DATA_PRIV_ISS_FMT,
      :FR_DATE_EXP,
      :FR_DATE_RECON_ISS,
      :FR_DRAFT_CAPTURE_FLG,
      :FR_EXCHG_MASTER,
      :FR_EXCHG_SETL,
      :FR_F_ADL_DEC_POS0,
      :FR_F_ADL_DEC_POS1,
      :FR_F_ADL_DEC_POS2,
      :FR_F_ADL_DEC_POS3,
      :FR_F_ADL_DEC_POS4,
      :FR_F_ADL_DEC_POS5,
      :FR_F_AMT0,
      :FR_F_AMT1,
      :FR_F_AMT2,
      :FR_F_AMT3,
      :FR_F_AMT4,
      :FR_F_AMT5,
      :FR_F_AMT_RECON_ACQ0,
      :FR_F_AMT_RECON_ACQ1,
      :FR_F_AMT_RECON_ACQ2,
      :FR_F_AMT_RECON_ACQ3,
      :FR_F_AMT_RECON_ACQ4,
      :FR_F_AMT_RECON_ACQ5,
      :FR_F_AMT_RECON_ISS0,
      :FR_F_AMT_RECON_ISS1,
      :FR_F_AMT_RECON_ISS2,
      :FR_F_AMT_RECON_ISS3,
      :FR_F_AMT_RECON_ISS4,
      :FR_F_AMT_RECON_ISS5,
      :FR_F_AMT_RECON_NET0,
      :FR_F_AMT_RECON_NET1,
      :FR_F_AMT_RECON_NET2,
      :FR_F_AMT_RECON_NET3,
      :FR_F_AMT_RECON_NET4,
      :FR_F_AMT_RECON_NET5,
      :FR_F_CNV_ACQ_DEC_POS0,
      :FR_F_CNV_ACQ_DEC_POS1,
      :FR_F_CNV_ACQ_DEC_POS2,
      :FR_F_CNV_ACQ_DEC_POS3,
      :FR_F_CNV_ACQ_DEC_POS4,
      :FR_F_CNV_ACQ_DEC_POS5,
      :FR_F_CNV_ACQ_RATE0,
      :FR_F_CNV_ACQ_RATE1,
      :FR_F_CNV_ACQ_RATE2,
      :FR_F_CNV_ACQ_RATE3,
      :FR_F_CNV_ACQ_RATE4,
      :FR_F_CNV_ACQ_RATE5,
      :FR_F_CNV_ISS_DEC_POS0,
      :FR_F_CNV_ISS_DEC_POS1,
      :FR_F_CNV_ISS_DEC_POS2,
      :FR_F_CNV_ISS_DEC_POS3,
      :FR_F_CNV_ISS_DEC_POS4,
      :FR_F_CNV_ISS_DEC_POS5,
      :FR_F_CNV_ISS_RATE0,
      :FR_F_CNV_ISS_RATE1,
      :FR_F_CNV_ISS_RATE2,
      :FR_F_CNV_ISS_RATE3,
      :FR_F_CNV_ISS_RATE4,
      :FR_F_CNV_ISS_RATE5,
      :FR_F_CUR_CODE0,
      :FR_F_CUR_CODE1,
      :FR_F_CUR_CODE2,
      :FR_F_CUR_CODE3,
      :FR_F_CUR_CODE4,
      :FR_F_CUR_CODE5,
      :FR_F_CUR_RECON_ACQ0,
      :FR_F_CUR_RECON_ACQ1,
      :FR_F_CUR_RECON_ACQ2,
      :FR_F_CUR_RECON_ACQ3,
      :FR_F_CUR_RECON_ACQ4,
      :FR_F_CUR_RECON_ACQ5,
      :FR_F_CUR_RECON_ISS0,
      :FR_F_CUR_RECON_ISS1,
      :FR_F_CUR_RECON_ISS2,
      :FR_F_CUR_RECON_ISS3,
      :FR_F_CUR_RECON_ISS4,
      :FR_F_CUR_RECON_ISS5,
      :FR_F_INITIATOR0,
      :FR_F_INITIATOR1,
      :FR_F_INITIATOR2,
      :FR_F_INITIATOR3,
      :FR_F_INITIATOR4,
      :FR_F_INITIATOR5,
      :FR_F_MEMO0,
      :FR_F_MEMO1,
      :FR_F_MEMO2,
      :FR_F_MEMO3,
      :FR_F_MEMO4,
      :FR_F_MEMO5,
      :FR_F_TYPE0,
      :FR_F_TYPE1,
      :FR_F_TYPE2,
      :FR_F_TYPE3,
      :FR_F_TYPE4,
      :FR_F_TYPE5,
      :FR_HOST_RECV_FLG,
      :FR_HOST_SENT_FLG,
      :FR_MCI_AAV_RESULT_COD,
      :FR_MCI_ECS_LVL_IND,
      :FR_MCI_UCAF_DATA,
      :FR_MTI,
      :FR_MERCH_TIER_ID,
      :FR_OAR_RQST_FLG,
      :FR_PAYEE,
      :FR_POS_CARD_CAPT_CAP,
      :FR_POS_CARD_PRES,
      :FR_POS_CRDHLDR_AUTH,
      :FR_POS_CRDHLDR_AUTH_C,
      :FR_POS_CRDHLDR_PRESNT,
      :FR_POS_CRD_DAT_IN_CAP,
      :FR_POS_CRD_DAT_IN_MOD,
      :FR_POS_CRD_DAT_OT_CAP,
      :FR_POS_OPER_ENV,
      :FR_POS_PIN_CAPT_CAP,
      :FR_POS_TERM_OUT_CAP,
      :FR_PRINT_MASK_ID,
      :FR_REF_DATA_ACQ,
      :FR_REF_DATA_ACQ_FMT,
      :FR_REF_DATA_ISS,
      :FR_REF_DATA_ISS_FMT,
      :FR_TERM_CLASS,
      :FR_TIME_AT_AP,
      :FR_TIME_AT_ISS,
      :FR_TIME_AT_RESP_QUE,
      :FR_TIME_AT_RESP_SWTCH,
      :FR_TIME_AT_RQST_QUE,
      :FR_TIME_AT_RQST_SWTCH,
      :FR_TRACK_2_DATA,
      :FR_TRAN_DESC,
      :FR_TRAN_UNIQUE_DATA,
      :FR_TRAN_UNIQ_DATA_FMT,
      :FR_ADL_DATA_PRIV_ISS,
      :FR_BIN_EXCLUSION_GRP,
      :FR_CARD_LOGO_ID,
      :FR_NET_INTRCHG_TIER,
      :FR_INST_TIER,
      :FR_CARD_INTRCHG_ID,
      :FR_PROGRAM_ID,
      :FR_PIN_FLG,
      :FR_ADL_DATA_NATIONAL,
      :FR_MULTI_CLEAR_SEQ_NO,
      :FR_MULTI_CLEAR_COUNT,
      :FR_ACCT_TYPE_1,
      :FR_ACCT_TYPE_2,
      :FR_ACCT_TYPE_3,
      :FR_ADL_RESP_ACCT_IDX0,
      :FR_ADL_RESP_ACCT_IDX1,
      :FR_ADL_RESP_ACCT_IDX2,
      :FR_ADL_RESP_ACCT_IDX3,
      :FR_ADL_RESP_ACCT_IDX4,
      :FR_ADL_RESP_ACCT_IDX5,
      :FR_ADL_RESP_ACCT_TYP0,
      :FR_ADL_RESP_ACCT_TYP1,
      :FR_ADL_RESP_ACCT_TYP2,
      :FR_ADL_RESP_ACCT_TYP3,
      :FR_ADL_RESP_ACCT_TYP4,
      :FR_ADL_RESP_ACCT_TYP5,
      :FR_ADL_RESP_AMT0,
      :FR_ADL_RESP_AMT1,
      :FR_ADL_RESP_AMT2,
      :FR_ADL_RESP_AMT3,
      :FR_ADL_RESP_AMT4,
      :FR_ADL_RESP_AMT5,
      :FR_ADL_RESP_AMT_TYP0,
      :FR_ADL_RESP_AMT_TYP1,
      :FR_ADL_RESP_AMT_TYP2,
      :FR_ADL_RESP_AMT_TYP3,
      :FR_ADL_RESP_AMT_TYP4,
      :FR_ADL_RESP_AMT_TYP5,
      :FR_ADL_RESP_CUR_CODE0,
      :FR_ADL_RESP_CUR_CODE1,
      :FR_ADL_RESP_CUR_CODE2,
      :FR_ADL_RESP_CUR_CODE3,
      :FR_ADL_RESP_CUR_CODE4,
      :FR_ADL_RESP_CUR_CODE5,
      :FR_ADL_RQST_ACCT_IDX0,
      :FR_ADL_RQST_ACCT_IDX1,
      :FR_ADL_RQST_ACCT_IDX2,
      :FR_ADL_RQST_ACCT_IDX3,
      :FR_ADL_RQST_ACCT_IDX4,
      :FR_ADL_RQST_ACCT_IDX5,
      :FR_ADL_RQST_ACCT_TYP0,
      :FR_ADL_RQST_ACCT_TYP1,
      :FR_ADL_RQST_ACCT_TYP2,
      :FR_ADL_RQST_ACCT_TYP3,
      :FR_ADL_RQST_ACCT_TYP4,
      :FR_ADL_RQST_ACCT_TYP5,
      :FR_ADL_RQST_AMT0,
      :FR_ADL_RQST_AMT1,
      :FR_ADL_RQST_AMT2,
      :FR_ADL_RQST_AMT3,
      :FR_ADL_RQST_AMT4,
      :FR_ADL_RQST_AMT5,
      :FR_ADL_RQST_AMT_TYP0,
      :FR_ADL_RQST_AMT_TYP1,
      :FR_ADL_RQST_AMT_TYP2,
      :FR_ADL_RQST_AMT_TYP3,
      :FR_ADL_RQST_AMT_TYP4,
      :FR_ADL_RQST_AMT_TYP5,
      :FR_ADL_RQST_CUR_CODE0,
      :FR_ADL_RQST_CUR_CODE1,
      :FR_ADL_RQST_CUR_CODE2,
      :FR_ADL_RQST_CUR_CODE3,
      :FR_ADL_RQST_CUR_CODE4,
      :FR_ADL_RQST_CUR_CODE5,
      :FR_ALT_ROUTE_FLG,
      :FR_AP_APPROVAL_CODE,
      :FR_AP_CARD_GRP,
      :FR_AP_DATA,
      :FR_AP_ERROR_NO,
      :FR_AP_ERROR_TRACE_LOC,
      :FR_AP_REJ_REASON_CODE,
      :FR_AUTH_LCYCLE_TCODE,
      :FR_AUTH_LIFECYCLE_INT,
      :FR_AUTH_RQST_TIMEOUT,
      :FR_CARD_ACPT_COUNTY,
      :FR_CARD_ACPT_SPNSR_ID,
      :FR_CARD_CAPT_FLG,
      :FR_CLERK_ID,
      :FR_CNTRY_RCN_ACQ_INST,
      :FR_CNTRY_RCN_ISS_INST,
      :FR_DATE_ACTION,
      :FR_DATE_CAPTURE,
      :FR_DATE_CNV_ACQ,
      :FR_DATE_CNV_ISS,
      :FR_DATE_EFFECTIVE,
      :FR_DATE_RECON_NET,
      :FR_DEPOSIT_ONLY_FLG,
      :FR_EXTENDED_PAY_DATA,
      :FR_PIN_DATA_FMT,
      :FR_PIN_RESULT,
      :FR_PMC_ERROR,
      :FR_PREAUTH_COMP_OPT,
      :FR_PROC_BILLING_FLGS1,
      :FR_PROC_BILLING_FLGS2,
      :FR_PROC_BILLING_FLGS3,
      :FR_PROC_BILLING_FLGS4,
      :FR_PROC_FLGS1,
      :FR_PROC_FLGS2,
      :FR_PROC_FLGS3,
      :FR_PROC_FLGS4,
      :FR_RECON_IND_ACQ,
      :FR_RESTRIC_INTCHG_GRP,
      :FR_SOURCE_ROUTE_ID,
      :FR_SRV_GRP_INTCHG_IND,
      :FR_SRV_GRP_SERV_CODE,
      :FR_STANDIN_ACT,
      :FR_STANDIN_OPTION,
      :FR_TRACINF_KEYTRAC_NO,
      :FR_TRACK_INFO_KEY_ID,
      :FR_TRAN_FROM_ACCT_FLG,
      :FR_TRAN_TO_ACCT_FLG,
      :FR_USAGE_UPDATE_BITS,
      :FR_PAN_TOKEN,
      :FR_TOKEN_ASSURANCE,
      :FR_TOKEN_REQUESTOR_ID,
      :FR_PAN_INDICATOR,
      :FR_PAN_RANGE,
      :FR_TOKEN_EXP_DATE,
      :FR_TOKEN_REF_NUMBER,
      :FR_TOKEN_SER_PROVIDER,
      :FR_TOKEN_STATUS,
      :FR_TOKEN_TRANID,
      :FR_TOKEN_TYPE,
      :FR_UNFORMATTED_MICR_DATA,
      :FR_ACQ_ROUTING_NO,
      :FR_ISS_ROUTING_NO,
      :FR_TRANS_ROUTING_NO,
      :FR_DEST_ROUTING_NO,
      :FR_AUTH_LCYCLE_TRACE,
      :FR_HCE_ACTIVATE_RESULT,
      :FR_AAM_VELOCITY_RESULT,
      :FR_LUK_ELAPSED_TIME,
      :FR_LUK_TRAN_COUNT,
      :FR_LUK_AMT_TRAN,
      :FR_TOKEN_DEVICE_TYPE,
      :FR_TOKEN_DEVICE_LOC,
      :FR_TOKEN_CARD_SEQ_NO,
      :FR_TOKEN_VERSION,
      :FR_NETWORK_PROGRAM,
      :FR_WEIGHTED_AVE_FLG,
      :FR_TOKEN_REF_NUMBER_EXT,
      :FR_ADDL_TRAN_DISP,
      :FR_ADDL_TRAN_RESULT,
      :FR_SWIFT_CODE,
      :FR_IFSC_CODE,
      :FR_LOCAL_RETRIEVAL_REF_NO,
      :FR_TOKEN_ACT_CODE,
      :FR_TOKEN_STATUS_CODE,
      :FR_TOKEN_ISSUER_PROC,
      :FR_TOKEN_REQ_TSTAMP,
      :FR_TOKEN_RESP_TSTAMP,
      :FR_TOKEN_TIME_AT_TSP,
      :FR_VISA_ATM_TRAN_ID,
      :FR_DOMAIN_CTL_RESTR,
      :FR_PGRM_PROTOCOL,
      :FR_DIR_SERV_TRAN_ID,
      :FR_TRAN_INT_CLASS,
      :FR_ACL_ECOM_IND,
      :FR_FO_AMT0,
      :FR_FO_AMT1,
      :FR_FO_AMT2,
      :FR_FO_AMT3,
      :FR_FO_AMT4,
      :FR_FO_AMT5,
      :FR_FO_AMT_RECON_ACQ0,
      :FR_FO_AMT_RECON_ACQ1,
      :FR_FO_AMT_RECON_ACQ2,
      :FR_FO_AMT_RECON_ACQ3,
      :FR_FO_AMT_RECON_ACQ4,
      :FR_FO_AMT_RECON_ACQ5,
      :FR_FO_AMT_RECON_ISS0,
      :FR_FO_AMT_RECON_ISS1,
      :FR_FO_AMT_RECON_ISS2,
      :FR_FO_AMT_RECON_ISS3,
      :FR_FO_AMT_RECON_ISS4,
      :FR_FO_AMT_RECON_ISS5,
      :FR_FO_AMT_RECON_NET0,
      :FR_FO_AMT_RECON_NET1,
      :FR_FO_AMT_RECON_NET2,
      :FR_FO_AMT_RECON_NET3,
      :FR_FO_AMT_RECON_NET4,
      :FR_FO_AMT_RECON_NET5,
      :FR_FO_CNV_ACQ_DE_POS0,
      :FR_FO_CNV_ACQ_DE_POS1,
      :FR_FO_CNV_ACQ_DE_POS2,
      :FR_FO_CNV_ACQ_DE_POS3,
      :FR_FO_CNV_ACQ_DE_POS4,
      :FR_FO_CNV_ACQ_DE_POS5,
      :FR_FO_CNV_ACQ_RATE0,
      :FR_FO_CNV_ACQ_RATE1,
      :FR_FO_CNV_ACQ_RATE2,
      :FR_FO_CNV_ACQ_RATE3,
      :FR_FO_CNV_ACQ_RATE4,
      :FR_FO_CNV_ACQ_RATE5,
      :FR_FO_CNV_ISS_DE_POS0,
      :FR_FO_CNV_ISS_DE_POS1,
      :FR_FO_CNV_ISS_DE_POS2,
      :FR_FO_CNV_ISS_DE_POS3,
      :FR_FO_CNV_ISS_DE_POS4,
      :FR_FO_CNV_ISS_DE_POS5,
      :FR_FO_CNV_ISS_RATE0,
      :FR_FO_CNV_ISS_RATE1,
      :FR_FO_CNV_ISS_RATE2,
      :FR_FO_CNV_ISS_RATE3,
      :FR_FO_CNV_ISS_RATE4,
      :FR_FO_CNV_ISS_RATE5,
      :FR_FO_CUR_CODE0,
      :FR_FO_CUR_CODE1,
      :FR_FO_CUR_CODE2,
      :FR_FO_CUR_CODE3,
      :FR_FO_CUR_CODE4,
      :FR_FO_CUR_CODE5,
      :FR_FO_CUR_RECON_ACQ0,
      :FR_FO_CUR_RECON_ACQ1,
      :FR_FO_CUR_RECON_ACQ2,
      :FR_FO_CUR_RECON_ACQ3,
      :FR_FO_CUR_RECON_ACQ4,
      :FR_FO_CUR_RECON_ACQ5,
      :FR_FO_CUR_RECON_ISS0,
      :FR_FO_CUR_RECON_ISS1,
      :FR_FO_CUR_RECON_ISS2,
      :FR_FO_CUR_RECON_ISS3,
      :FR_FO_CUR_RECON_ISS4,
      :FR_FO_CUR_RECON_ISS5,
      :FR_FO_DEC_POS0,
      :FR_FO_DEC_POS1,
      :FR_FO_DEC_POS2,
      :FR_FO_DEC_POS3,
      :FR_FO_DEC_POS4,
      :FR_FO_DEC_POS5,
      :FR_FO_INITIATOR0,
      :FR_FO_INITIATOR1,
      :FR_FO_INITIATOR2,
      :FR_FO_INITIATOR3,
      :FR_FO_INITIATOR4,
      :FR_FO_INITIATOR5,
      :FR_FO_MEMO0,
      :FR_FO_MEMO1,
      :FR_FO_MEMO2,
      :FR_FO_MEMO3,
      :FR_FO_MEMO4,
      :FR_FO_MEMO5,
      :FR_FO_TYPE0,
      :FR_FO_TYPE1,
      :FR_FO_TYPE2,
      :FR_FO_TYPE3,
      :FR_FO_TYPE4,
      :FR_FO_TYPE5,
      :FR_O_AMT_CARD_BILL,
      :FR_O_AMT_RECON_ACQ,
      :FR_O_AMT_RECON_ISS,
      :FR_O_AMT_RECON_NET,
      :FR_O_AMT_TRAN,
      :FR_ODE_INST_ID_ACQ,
      :FR_ODE_MTI,
      :FR_ODE_SYS_TRA_AUD_NO,
      :FR_ODE_TSTAMP_LOCL_TR,
      :FR_TSTAMP_REV_CREATED,
      :FR_ADTL_DATA_FEE,
      :FR_ISS_ACQ_TYPE_FEE,
      :FR_NET_UNIQUE_DAT_FEE,
      :FR_BRANCH_ID_ACQ,
      :FR_CNTRY_REC_INST_ADJ,
      :FR_CNTRY_REQ_INST_ADJ,
      :FR_INST_ID_REC_ADJ,
      :FR_INST_ID_REQ_ADJ,
      :FR_NET_IND_ADJ,
      :FR_ORIG_AMT_TRAN_ADJ,
      :FR_REQ_ACQ_ISS_IND,
      :FR_TRACE_DATA_ADJ,
      :FR_TSTAMP_LOCAL_ADJ,
      :FR_TSTAMP_TRANS_ADJ,
      :FR_EXTENSION_DATA_ADJ,
      :FR_BRIDGE_ACQ_FLG,
      :FR_BRIDGE_ISS_FLG,
      :FR_BIN_LENGTH,
      :FR_PAN_IDENTIFIER,
      :FR_PYMT_ACCT_REF,
      :FR_MERCH_DISP_NAME,
      :FR_EMV_3D_CAVV_VER_BY,
      :FR_EMV_3D_TRAN_ID,
      :FR_COOPER_SCORE,
      :FR_COOPER_REASON,
      :FR_AMX_FRAUD_DATA,
      :FR_ISSUER_SCRIPT_FLG,
      :FR_P1C_ACCT_TOKEN,
      :FR_P1C_ADL_RESP_DATA,
      :FR_P1C_CRDHLDR_TOKEN,
      :FR_PRM_ADL_RESP_DATA,
      :FR_SAP_ADL_RESP_DATA,
      :FR_ECOM_DATA,
      :FR_INST_ID_FRWD,
      :FR_TOKEN_DEVICE_NAME,
      :FR_TOKEN_ENTITY,
      :FR_SELLER_EMAIL,
      :FR_SELLER_PHONE,
      :FR_SELLER_ID,
      :FR_FORCE_POST_DROP_IND,
      :FR_FP_HOLD_MATCH_FLG,
      :FR_ODE_INST_ID_FRWD,
      :FR_ODE_DATE_TIME_XMIT,
      :FR_DATE_TIME_XMIT,
      :FR_PAN_TOKEN_BIN_LEN,
      :FR_TOKEN_DEVICE_ID,
      :FR_WALLET_REASON;
*/

{
#line 3251 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 3251 "CXOSD206.sqx"
  sqlaaloc(2,536,1,0L);
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 500; sql_setdlist[0].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)&FR_PARTITION_KEY;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 500; sql_setdlist[1].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)&FR_UNIQUENESS_KEY;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 496; sql_setdlist[2].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)&FR_INSERT_SEQUENCE_NO;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 29;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FR_ACCT_ID_1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 29;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_ACCT_ID_2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 29;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FR_ACCT_ID_3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FR_ACCT_TYPES_ISS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FR_ACQ_PLAT_PROD_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 480; sql_setdlist[8].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)&FR_AMT_CARD_BILL;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 480; sql_setdlist[9].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)&FR_AMT_RECON_NET;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 480; sql_setdlist[10].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)&FR_AMT_TRAN;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)FR_CARD_ACPT_BUS_CODE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)FR_CARD_ACPT_COUNTRY;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 448; sql_setdlist[13].sqllen = 84;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)&FR_CARD_ACPT_NAME_LOC;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 11;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)FR_CARD_ACPT_PST_CODE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FR_CARD_ACPT_REGION;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 6;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FR_CARD_SEQ_NO;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 496; sql_setdlist[17].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)&FR_CED_BUILD_NO;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FR_CIRC_ID_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)FR_CIRC_ID_ISS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FR_COUNTRY_ACQ_INST;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 460; sql_setdlist[21].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)FR_COUNTRY_ISS_INST;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 460; sql_setdlist[22].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)FR_CUR_CARD_BILL;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 460; sql_setdlist[23].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)FR_CUR_RECON_NET;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 460; sql_setdlist[24].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)FR_CUR_TRAN;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FR_DATE_RECON_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FR_FUNC_CODE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FR_MERCH_TYPE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FR_MSG_RESON_CODE_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FR_MSG_RESON_CODE_ISS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FR_NET_ID_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 460; sql_setdlist[31].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)FR_NET_ID_ISS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 460; sql_setdlist[32].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)FR_POS_CRDHLDR_A_METH;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FR_REIMBURSEMENT_ATTR;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 460; sql_setdlist[34].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)FR_REV_BY;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 460; sql_setdlist[35].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)FR_TRAN_DISPOSITION;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 460; sql_setdlist[36].sqllen = 17;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)FR_TSTAMP_TRANS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 460; sql_setdlist[37].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)FR_ACCT_QUAL_1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 460; sql_setdlist[38].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)FR_ACCT_QUAL_2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 448; sql_setdlist[39].sqllen = 255;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)&FR_ADL_DATA_PRIV_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 448; sql_setdlist[40].sqllen = 99;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)&FR_ADL_RESP_DATA;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 480; sql_setdlist[41].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)&FR_AMT_RECON_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 480; sql_setdlist[42].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)&FR_AMT_RECON_ISS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 460; sql_setdlist[43].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)FR_AP_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 496; sql_setdlist[44].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)&FR_CAN_ITEM_VALUE0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 496; sql_setdlist[45].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)&FR_CAN_ITEM_VALUE1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 496; sql_setdlist[46].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)&FR_CAN_ITEM_VALUE2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 496; sql_setdlist[47].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)&FR_CAN_ITEM_VALUE3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 496; sql_setdlist[48].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)&FR_CAN_ITEM_VALUE4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 496; sql_setdlist[49].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)&FR_CAN_ITEM_VALUE5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 496; sql_setdlist[50].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)&FR_CAN_ITEM_VALUE6;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 496; sql_setdlist[51].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)&FR_CAN_ITEM_VALUE7;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 500; sql_setdlist[52].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 500; sql_setdlist[53].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 500; sql_setdlist[54].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 500; sql_setdlist[55].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 500; sql_setdlist[56].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 500; sql_setdlist[57].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 500; sql_setdlist[58].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP6;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 500; sql_setdlist[59].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP7;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 500; sql_setdlist[60].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 500; sql_setdlist[61].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 500; sql_setdlist[62].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 500; sql_setdlist[63].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sqlasetdata(2,0,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 500; sql_setdlist[0].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 500; sql_setdlist[1].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 500; sql_setdlist[2].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS6;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 500; sql_setdlist[3].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS7;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 16;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_CARD_ACPT_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FR_CARD_OWNER;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FR_CARD_TYPE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FR_CAVV_RESULT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 480; sql_setdlist[8].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)&FR_CNV_CRD_BIL_DE_POS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 480; sql_setdlist[9].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)&FR_CNV_CRD_BIL_RATE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 480; sql_setdlist[10].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)&FR_CNV_RCN_ACQ_DE_POS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 480; sql_setdlist[11].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)&FR_CNV_RCN_ACQ_RATE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 480; sql_setdlist[12].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)&FR_CNV_RCN_ISS_DE_POS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 480; sql_setdlist[13].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)&FR_CNV_RCN_ISS_RATE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 480; sql_setdlist[14].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)&FR_CNV_RCN_NET_DE_POS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 480; sql_setdlist[15].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)&FR_CNV_RCN_NET_RATE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FR_CRD_ACP_NAM_FMTFLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FR_CUR_RECON_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FR_CUR_RECON_ISS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 500; sql_setdlist[19].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)&FR_CUR_TYPE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FR_CVV_CVC_RESULT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 460; sql_setdlist[21].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)FR_CVV2_CVC2_RESULT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 448; sql_setdlist[22].sqllen = 100;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)&FR_DATA_PRIV_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 500; sql_setdlist[23].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)&FR_DATA_PRIV_ACQ_FMT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 448; sql_setdlist[24].sqllen = 100;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)&FR_DATA_PRIV_ISS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 500; sql_setdlist[25].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)&FR_DATA_PRIV_ISS_FMT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FR_DATE_EXP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FR_DATE_RECON_ISS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FR_DRAFT_CAPTURE_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FR_EXCHG_MASTER;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FR_EXCHG_SETL;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 480; sql_setdlist[31].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)&FR_F_ADL_DEC_POS0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 480; sql_setdlist[32].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)&FR_F_ADL_DEC_POS1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 480; sql_setdlist[33].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)&FR_F_ADL_DEC_POS2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 480; sql_setdlist[34].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)&FR_F_ADL_DEC_POS3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 480; sql_setdlist[35].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)&FR_F_ADL_DEC_POS4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 480; sql_setdlist[36].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)&FR_F_ADL_DEC_POS5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 496; sql_setdlist[37].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)&FR_F_AMT0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 496; sql_setdlist[38].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)&FR_F_AMT1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 496; sql_setdlist[39].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)&FR_F_AMT2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 496; sql_setdlist[40].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)&FR_F_AMT3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 496; sql_setdlist[41].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)&FR_F_AMT4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 496; sql_setdlist[42].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)&FR_F_AMT5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 496; sql_setdlist[43].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)&FR_F_AMT_RECON_ACQ0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 496; sql_setdlist[44].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)&FR_F_AMT_RECON_ACQ1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 496; sql_setdlist[45].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)&FR_F_AMT_RECON_ACQ2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 496; sql_setdlist[46].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)&FR_F_AMT_RECON_ACQ3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 496; sql_setdlist[47].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)&FR_F_AMT_RECON_ACQ4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 496; sql_setdlist[48].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)&FR_F_AMT_RECON_ACQ5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 496; sql_setdlist[49].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)&FR_F_AMT_RECON_ISS0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 496; sql_setdlist[50].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)&FR_F_AMT_RECON_ISS1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 496; sql_setdlist[51].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)&FR_F_AMT_RECON_ISS2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 496; sql_setdlist[52].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)&FR_F_AMT_RECON_ISS3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 496; sql_setdlist[53].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)&FR_F_AMT_RECON_ISS4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 496; sql_setdlist[54].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)&FR_F_AMT_RECON_ISS5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 496; sql_setdlist[55].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)&FR_F_AMT_RECON_NET0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 496; sql_setdlist[56].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)&FR_F_AMT_RECON_NET1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 496; sql_setdlist[57].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)&FR_F_AMT_RECON_NET2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 496; sql_setdlist[58].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)&FR_F_AMT_RECON_NET3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 496; sql_setdlist[59].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)&FR_F_AMT_RECON_NET4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 496; sql_setdlist[60].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)&FR_F_AMT_RECON_NET5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 480; sql_setdlist[61].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)&FR_F_CNV_ACQ_DEC_POS0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 480; sql_setdlist[62].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)&FR_F_CNV_ACQ_DEC_POS1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 480; sql_setdlist[63].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)&FR_F_CNV_ACQ_DEC_POS2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sqlasetdata(2,64,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 480; sql_setdlist[0].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)&FR_F_CNV_ACQ_DEC_POS3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 480; sql_setdlist[1].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)&FR_F_CNV_ACQ_DEC_POS4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 480; sql_setdlist[2].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)&FR_F_CNV_ACQ_DEC_POS5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 480; sql_setdlist[3].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)&FR_F_CNV_ACQ_RATE0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 480; sql_setdlist[4].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)&FR_F_CNV_ACQ_RATE1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 480; sql_setdlist[5].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)&FR_F_CNV_ACQ_RATE2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 480; sql_setdlist[6].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)&FR_F_CNV_ACQ_RATE3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 480; sql_setdlist[7].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)&FR_F_CNV_ACQ_RATE4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 480; sql_setdlist[8].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)&FR_F_CNV_ACQ_RATE5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 480; sql_setdlist[9].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)&FR_F_CNV_ISS_DEC_POS0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 480; sql_setdlist[10].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)&FR_F_CNV_ISS_DEC_POS1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 480; sql_setdlist[11].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)&FR_F_CNV_ISS_DEC_POS2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 480; sql_setdlist[12].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)&FR_F_CNV_ISS_DEC_POS3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 480; sql_setdlist[13].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)&FR_F_CNV_ISS_DEC_POS4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 480; sql_setdlist[14].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)&FR_F_CNV_ISS_DEC_POS5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 480; sql_setdlist[15].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)&FR_F_CNV_ISS_RATE0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 480; sql_setdlist[16].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)&FR_F_CNV_ISS_RATE1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 480; sql_setdlist[17].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)&FR_F_CNV_ISS_RATE2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 480; sql_setdlist[18].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)&FR_F_CNV_ISS_RATE3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 480; sql_setdlist[19].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)&FR_F_CNV_ISS_RATE4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 480; sql_setdlist[20].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)&FR_F_CNV_ISS_RATE5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 460; sql_setdlist[21].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)FR_F_CUR_CODE0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 460; sql_setdlist[22].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)FR_F_CUR_CODE1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 460; sql_setdlist[23].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)FR_F_CUR_CODE2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 460; sql_setdlist[24].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)FR_F_CUR_CODE3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FR_F_CUR_CODE4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FR_F_CUR_CODE5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FR_F_CUR_RECON_ACQ0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FR_F_CUR_RECON_ACQ1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FR_F_CUR_RECON_ACQ2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FR_F_CUR_RECON_ACQ3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 460; sql_setdlist[31].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)FR_F_CUR_RECON_ACQ4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 460; sql_setdlist[32].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)FR_F_CUR_RECON_ACQ5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FR_F_CUR_RECON_ISS0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 460; sql_setdlist[34].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)FR_F_CUR_RECON_ISS1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 460; sql_setdlist[35].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)FR_F_CUR_RECON_ISS2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 460; sql_setdlist[36].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)FR_F_CUR_RECON_ISS3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 460; sql_setdlist[37].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)FR_F_CUR_RECON_ISS4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 460; sql_setdlist[38].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)FR_F_CUR_RECON_ISS5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 460; sql_setdlist[39].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)FR_F_INITIATOR0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 460; sql_setdlist[40].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)FR_F_INITIATOR1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 460; sql_setdlist[41].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)FR_F_INITIATOR2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 460; sql_setdlist[42].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)FR_F_INITIATOR3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 460; sql_setdlist[43].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)FR_F_INITIATOR4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 460; sql_setdlist[44].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)FR_F_INITIATOR5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 460; sql_setdlist[45].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)FR_F_MEMO0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 460; sql_setdlist[46].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)FR_F_MEMO1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 460; sql_setdlist[47].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)FR_F_MEMO2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 460; sql_setdlist[48].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)FR_F_MEMO3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 460; sql_setdlist[49].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)FR_F_MEMO4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 460; sql_setdlist[50].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)FR_F_MEMO5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 460; sql_setdlist[51].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)FR_F_TYPE0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 460; sql_setdlist[52].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)FR_F_TYPE1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 460; sql_setdlist[53].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)FR_F_TYPE2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 460; sql_setdlist[54].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)FR_F_TYPE3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 460; sql_setdlist[55].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)FR_F_TYPE4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 460; sql_setdlist[56].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)FR_F_TYPE5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 460; sql_setdlist[57].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)FR_HOST_RECV_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 460; sql_setdlist[58].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)FR_HOST_SENT_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 460; sql_setdlist[59].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)FR_MCI_AAV_RESULT_COD;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 460; sql_setdlist[60].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)FR_MCI_ECS_LVL_IND;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 460; sql_setdlist[61].sqllen = 33;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)FR_MCI_UCAF_DATA;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 460; sql_setdlist[62].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)FR_MTI;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 460; sql_setdlist[63].sqllen = 15;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)FR_MERCH_TIER_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sqlasetdata(2,128,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_OAR_RQST_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 26;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FR_PAYEE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_POS_CARD_CAPT_CAP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FR_POS_CARD_PRES;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_POS_CRDHLDR_AUTH;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FR_POS_CRDHLDR_AUTH_C;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FR_POS_CRDHLDR_PRESNT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FR_POS_CRD_DAT_IN_CAP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FR_POS_CRD_DAT_IN_MOD;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)FR_POS_CRD_DAT_OT_CAP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 460; sql_setdlist[10].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)FR_POS_OPER_ENV;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)FR_POS_PIN_CAPT_CAP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)FR_POS_TERM_OUT_CAP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)FR_PRINT_MASK_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 448; sql_setdlist[14].sqllen = 99;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)&FR_REF_DATA_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 500; sql_setdlist[15].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)&FR_REF_DATA_ACQ_FMT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 448; sql_setdlist[16].sqllen = 99;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)&FR_REF_DATA_ISS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 500; sql_setdlist[17].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)&FR_REF_DATA_ISS_FMT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FR_TERM_CLASS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 500; sql_setdlist[19].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)&FR_TIME_AT_AP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 500; sql_setdlist[20].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)&FR_TIME_AT_ISS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 500; sql_setdlist[21].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)&FR_TIME_AT_RESP_QUE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 500; sql_setdlist[22].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)&FR_TIME_AT_RESP_SWTCH;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 500; sql_setdlist[23].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)&FR_TIME_AT_RQST_QUE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 500; sql_setdlist[24].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)&FR_TIME_AT_RQST_SWTCH;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 448; sql_setdlist[25].sqllen = 40;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)&FR_TRACK_2_DATA;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 448; sql_setdlist[26].sqllen = 100;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)&FR_TRAN_DESC;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 448; sql_setdlist[27].sqllen = 50;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)&FR_TRAN_UNIQUE_DATA;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FR_TRAN_UNIQ_DATA_FMT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 448; sql_setdlist[29].sqllen = 255;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)&FR_ADL_DATA_PRIV_ISS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FR_BIN_EXCLUSION_GRP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 460; sql_setdlist[31].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)FR_CARD_LOGO_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 460; sql_setdlist[32].sqllen = 6;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)FR_NET_INTRCHG_TIER;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FR_INST_TIER;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 460; sql_setdlist[34].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)FR_CARD_INTRCHG_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 460; sql_setdlist[35].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)FR_PROGRAM_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 460; sql_setdlist[36].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)FR_PIN_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 448; sql_setdlist[37].sqllen = 999;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)&FR_ADL_DATA_NATIONAL;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 460; sql_setdlist[38].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)FR_MULTI_CLEAR_SEQ_NO;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 460; sql_setdlist[39].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)FR_MULTI_CLEAR_COUNT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 460; sql_setdlist[40].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)FR_ACCT_TYPE_1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 460; sql_setdlist[41].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)FR_ACCT_TYPE_2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 460; sql_setdlist[42].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)FR_ACCT_TYPE_3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 500; sql_setdlist[43].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)&FR_ADL_RESP_ACCT_IDX0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 500; sql_setdlist[44].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)&FR_ADL_RESP_ACCT_IDX1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 500; sql_setdlist[45].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)&FR_ADL_RESP_ACCT_IDX2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 500; sql_setdlist[46].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)&FR_ADL_RESP_ACCT_IDX3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 500; sql_setdlist[47].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)&FR_ADL_RESP_ACCT_IDX4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 500; sql_setdlist[48].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)&FR_ADL_RESP_ACCT_IDX5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 460; sql_setdlist[49].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)FR_ADL_RESP_ACCT_TYP0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 460; sql_setdlist[50].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)FR_ADL_RESP_ACCT_TYP1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 460; sql_setdlist[51].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)FR_ADL_RESP_ACCT_TYP2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 460; sql_setdlist[52].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)FR_ADL_RESP_ACCT_TYP3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 460; sql_setdlist[53].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)FR_ADL_RESP_ACCT_TYP4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 460; sql_setdlist[54].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)FR_ADL_RESP_ACCT_TYP5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 480; sql_setdlist[55].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)&FR_ADL_RESP_AMT0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 480; sql_setdlist[56].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)&FR_ADL_RESP_AMT1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 480; sql_setdlist[57].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)&FR_ADL_RESP_AMT2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 480; sql_setdlist[58].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)&FR_ADL_RESP_AMT3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 480; sql_setdlist[59].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)&FR_ADL_RESP_AMT4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 480; sql_setdlist[60].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)&FR_ADL_RESP_AMT5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 460; sql_setdlist[61].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)FR_ADL_RESP_AMT_TYP0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 460; sql_setdlist[62].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)FR_ADL_RESP_AMT_TYP1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 460; sql_setdlist[63].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)FR_ADL_RESP_AMT_TYP2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sqlasetdata(2,192,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_ADL_RESP_AMT_TYP3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FR_ADL_RESP_AMT_TYP4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_ADL_RESP_AMT_TYP5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FR_ADL_RESP_CUR_CODE0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_ADL_RESP_CUR_CODE1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FR_ADL_RESP_CUR_CODE2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FR_ADL_RESP_CUR_CODE3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FR_ADL_RESP_CUR_CODE4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FR_ADL_RESP_CUR_CODE5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 500; sql_setdlist[9].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)&FR_ADL_RQST_ACCT_IDX0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 500; sql_setdlist[10].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)&FR_ADL_RQST_ACCT_IDX1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 500; sql_setdlist[11].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)&FR_ADL_RQST_ACCT_IDX2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 500; sql_setdlist[12].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)&FR_ADL_RQST_ACCT_IDX3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 500; sql_setdlist[13].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)&FR_ADL_RQST_ACCT_IDX4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 500; sql_setdlist[14].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)&FR_ADL_RQST_ACCT_IDX5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FR_ADL_RQST_ACCT_TYP0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FR_ADL_RQST_ACCT_TYP1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FR_ADL_RQST_ACCT_TYP2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FR_ADL_RQST_ACCT_TYP3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)FR_ADL_RQST_ACCT_TYP4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FR_ADL_RQST_ACCT_TYP5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 480; sql_setdlist[21].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)&FR_ADL_RQST_AMT0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 480; sql_setdlist[22].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)&FR_ADL_RQST_AMT1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 480; sql_setdlist[23].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)&FR_ADL_RQST_AMT2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 480; sql_setdlist[24].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)&FR_ADL_RQST_AMT3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 480; sql_setdlist[25].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)&FR_ADL_RQST_AMT4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 480; sql_setdlist[26].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)&FR_ADL_RQST_AMT5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FR_ADL_RQST_AMT_TYP0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FR_ADL_RQST_AMT_TYP1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FR_ADL_RQST_AMT_TYP2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FR_ADL_RQST_AMT_TYP3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 460; sql_setdlist[31].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)FR_ADL_RQST_AMT_TYP4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 460; sql_setdlist[32].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)FR_ADL_RQST_AMT_TYP5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FR_ADL_RQST_CUR_CODE0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 460; sql_setdlist[34].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)FR_ADL_RQST_CUR_CODE1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 460; sql_setdlist[35].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)FR_ADL_RQST_CUR_CODE2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 460; sql_setdlist[36].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)FR_ADL_RQST_CUR_CODE3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 460; sql_setdlist[37].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)FR_ADL_RQST_CUR_CODE4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 460; sql_setdlist[38].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)FR_ADL_RQST_CUR_CODE5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 460; sql_setdlist[39].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)FR_ALT_ROUTE_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 460; sql_setdlist[40].sqllen = 7;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)FR_AP_APPROVAL_CODE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 460; sql_setdlist[41].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)FR_AP_CARD_GRP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 460; sql_setdlist[42].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)FR_AP_DATA;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 500; sql_setdlist[43].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)&FR_AP_ERROR_NO;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 500; sql_setdlist[44].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)&FR_AP_ERROR_TRACE_LOC;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 500; sql_setdlist[45].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)&FR_AP_REJ_REASON_CODE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 460; sql_setdlist[46].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)FR_AUTH_LCYCLE_TCODE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 480; sql_setdlist[47].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)&FR_AUTH_LIFECYCLE_INT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 500; sql_setdlist[48].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)&FR_AUTH_RQST_TIMEOUT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 460; sql_setdlist[49].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)FR_CARD_ACPT_COUNTY;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 460; sql_setdlist[50].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)FR_CARD_ACPT_SPNSR_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 460; sql_setdlist[51].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)FR_CARD_CAPT_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 460; sql_setdlist[52].sqllen = 29;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)FR_CLERK_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 460; sql_setdlist[53].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)FR_CNTRY_RCN_ACQ_INST;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 460; sql_setdlist[54].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)FR_CNTRY_RCN_ISS_INST;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 460; sql_setdlist[55].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)FR_DATE_ACTION;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 460; sql_setdlist[56].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)FR_DATE_CAPTURE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 460; sql_setdlist[57].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)FR_DATE_CNV_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 460; sql_setdlist[58].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)FR_DATE_CNV_ISS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 460; sql_setdlist[59].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)FR_DATE_EFFECTIVE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 460; sql_setdlist[60].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)FR_DATE_RECON_NET;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 460; sql_setdlist[61].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)FR_DEPOSIT_ONLY_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 460; sql_setdlist[62].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)FR_EXTENDED_PAY_DATA;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 500; sql_setdlist[63].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)&FR_PIN_DATA_FMT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sqlasetdata(2,256,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 500; sql_setdlist[0].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)&FR_PIN_RESULT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 500; sql_setdlist[1].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)&FR_PMC_ERROR;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 500; sql_setdlist[2].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)&FR_PREAUTH_COMP_OPT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 448; sql_setdlist[3].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)&FR_PROC_BILLING_FLGS1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 448; sql_setdlist[4].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)&FR_PROC_BILLING_FLGS2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 448; sql_setdlist[5].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)&FR_PROC_BILLING_FLGS3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 448; sql_setdlist[6].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)&FR_PROC_BILLING_FLGS4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 448; sql_setdlist[7].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)&FR_PROC_FLGS1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 448; sql_setdlist[8].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)&FR_PROC_FLGS2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 448; sql_setdlist[9].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)&FR_PROC_FLGS3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 448; sql_setdlist[10].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)&FR_PROC_FLGS4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 7;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)FR_RECON_IND_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)FR_RESTRIC_INTCHG_GRP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)FR_SOURCE_ROUTE_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)FR_SRV_GRP_INTCHG_IND;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FR_SRV_GRP_SERV_CODE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FR_STANDIN_ACT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FR_STANDIN_OPTION;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FR_TRACINF_KEYTRAC_NO;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)FR_TRACK_INFO_KEY_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FR_TRAN_FROM_ACCT_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 460; sql_setdlist[21].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)FR_TRAN_TO_ACCT_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 496; sql_setdlist[22].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)&FR_USAGE_UPDATE_BITS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 460; sql_setdlist[23].sqllen = 20;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)FR_PAN_TOKEN;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 460; sql_setdlist[24].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)FR_TOKEN_ASSURANCE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FR_TOKEN_REQUESTOR_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FR_PAN_INDICATOR;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 20;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FR_PAN_RANGE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FR_TOKEN_EXP_DATE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 49;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FR_TOKEN_REF_NUMBER;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FR_TOKEN_SER_PROVIDER;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 460; sql_setdlist[31].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)FR_TOKEN_STATUS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 448; sql_setdlist[32].sqllen = 99;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)&FR_TOKEN_TRANID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FR_TOKEN_TYPE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 448; sql_setdlist[34].sqllen = 48;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)&FR_UNFORMATTED_MICR_DATA;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 460; sql_setdlist[35].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)FR_ACQ_ROUTING_NO;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 460; sql_setdlist[36].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)FR_ISS_ROUTING_NO;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 460; sql_setdlist[37].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)FR_TRANS_ROUTING_NO;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 460; sql_setdlist[38].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)FR_DEST_ROUTING_NO;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 460; sql_setdlist[39].sqllen = 16;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)FR_AUTH_LCYCLE_TRACE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 460; sql_setdlist[40].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)FR_HCE_ACTIVATE_RESULT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 460; sql_setdlist[41].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)FR_AAM_VELOCITY_RESULT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 500; sql_setdlist[42].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)&FR_LUK_ELAPSED_TIME;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 500; sql_setdlist[43].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)&FR_LUK_TRAN_COUNT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 480; sql_setdlist[44].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)&FR_LUK_AMT_TRAN;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 460; sql_setdlist[45].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)FR_TOKEN_DEVICE_TYPE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 460; sql_setdlist[46].sqllen = 26;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)FR_TOKEN_DEVICE_LOC;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 460; sql_setdlist[47].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)FR_TOKEN_CARD_SEQ_NO;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 460; sql_setdlist[48].sqllen = 7;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)FR_TOKEN_VERSION;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 460; sql_setdlist[49].sqllen = 11;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)FR_NETWORK_PROGRAM;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 460; sql_setdlist[50].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)FR_WEIGHTED_AVE_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 460; sql_setdlist[51].sqllen = 17;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)FR_TOKEN_REF_NUMBER_EXT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 460; sql_setdlist[52].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)FR_ADDL_TRAN_DISP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 448; sql_setdlist[53].sqllen = 90;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)&FR_ADDL_TRAN_RESULT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 460; sql_setdlist[54].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)FR_SWIFT_CODE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 460; sql_setdlist[55].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)FR_IFSC_CODE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 460; sql_setdlist[56].sqllen = 13;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)FR_LOCAL_RETRIEVAL_REF_NO;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 460; sql_setdlist[57].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)FR_TOKEN_ACT_CODE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 460; sql_setdlist[58].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)FR_TOKEN_STATUS_CODE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 460; sql_setdlist[59].sqllen = 9;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)FR_TOKEN_ISSUER_PROC;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 460; sql_setdlist[60].sqllen = 17;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)FR_TOKEN_REQ_TSTAMP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 460; sql_setdlist[61].sqllen = 17;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)FR_TOKEN_RESP_TSTAMP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 460; sql_setdlist[62].sqllen = 6;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)FR_TOKEN_TIME_AT_TSP;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 460; sql_setdlist[63].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)FR_VISA_ATM_TRAN_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sqlasetdata(2,320,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_DOMAIN_CTL_RESTR;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FR_PGRM_PROTOCOL;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 37;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_DIR_SERV_TRAN_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FR_TRAN_INT_CLASS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_ACL_ECOM_IND;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 496; sql_setdlist[5].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)&FR_FO_AMT0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 496; sql_setdlist[6].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)&FR_FO_AMT1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 496; sql_setdlist[7].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)&FR_FO_AMT2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 496; sql_setdlist[8].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)&FR_FO_AMT3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 496; sql_setdlist[9].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)&FR_FO_AMT4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 496; sql_setdlist[10].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)&FR_FO_AMT5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 496; sql_setdlist[11].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)&FR_FO_AMT_RECON_ACQ0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 496; sql_setdlist[12].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)&FR_FO_AMT_RECON_ACQ1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 496; sql_setdlist[13].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)&FR_FO_AMT_RECON_ACQ2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 496; sql_setdlist[14].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)&FR_FO_AMT_RECON_ACQ3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 496; sql_setdlist[15].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)&FR_FO_AMT_RECON_ACQ4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 496; sql_setdlist[16].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)&FR_FO_AMT_RECON_ACQ5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 496; sql_setdlist[17].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)&FR_FO_AMT_RECON_ISS0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 496; sql_setdlist[18].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)&FR_FO_AMT_RECON_ISS1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 496; sql_setdlist[19].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)&FR_FO_AMT_RECON_ISS2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 496; sql_setdlist[20].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)&FR_FO_AMT_RECON_ISS3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 496; sql_setdlist[21].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)&FR_FO_AMT_RECON_ISS4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 496; sql_setdlist[22].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)&FR_FO_AMT_RECON_ISS5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 496; sql_setdlist[23].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)&FR_FO_AMT_RECON_NET0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 496; sql_setdlist[24].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)&FR_FO_AMT_RECON_NET1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 496; sql_setdlist[25].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)&FR_FO_AMT_RECON_NET2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 496; sql_setdlist[26].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)&FR_FO_AMT_RECON_NET3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 496; sql_setdlist[27].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)&FR_FO_AMT_RECON_NET4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 496; sql_setdlist[28].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)&FR_FO_AMT_RECON_NET5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 480; sql_setdlist[29].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)&FR_FO_CNV_ACQ_DE_POS0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 480; sql_setdlist[30].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)&FR_FO_CNV_ACQ_DE_POS1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 480; sql_setdlist[31].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)&FR_FO_CNV_ACQ_DE_POS2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 480; sql_setdlist[32].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)&FR_FO_CNV_ACQ_DE_POS3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 480; sql_setdlist[33].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)&FR_FO_CNV_ACQ_DE_POS4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 480; sql_setdlist[34].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)&FR_FO_CNV_ACQ_DE_POS5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 496; sql_setdlist[35].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)&FR_FO_CNV_ACQ_RATE0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 496; sql_setdlist[36].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)&FR_FO_CNV_ACQ_RATE1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 496; sql_setdlist[37].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)&FR_FO_CNV_ACQ_RATE2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 496; sql_setdlist[38].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)&FR_FO_CNV_ACQ_RATE3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 496; sql_setdlist[39].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)&FR_FO_CNV_ACQ_RATE4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 496; sql_setdlist[40].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)&FR_FO_CNV_ACQ_RATE5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 480; sql_setdlist[41].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)&FR_FO_CNV_ISS_DE_POS0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 480; sql_setdlist[42].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)&FR_FO_CNV_ISS_DE_POS1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 480; sql_setdlist[43].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)&FR_FO_CNV_ISS_DE_POS2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 480; sql_setdlist[44].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)&FR_FO_CNV_ISS_DE_POS3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 480; sql_setdlist[45].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)&FR_FO_CNV_ISS_DE_POS4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 480; sql_setdlist[46].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)&FR_FO_CNV_ISS_DE_POS5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 496; sql_setdlist[47].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)&FR_FO_CNV_ISS_RATE0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 496; sql_setdlist[48].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)&FR_FO_CNV_ISS_RATE1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 496; sql_setdlist[49].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)&FR_FO_CNV_ISS_RATE2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 496; sql_setdlist[50].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)&FR_FO_CNV_ISS_RATE3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 496; sql_setdlist[51].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)&FR_FO_CNV_ISS_RATE4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 496; sql_setdlist[52].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)&FR_FO_CNV_ISS_RATE5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 460; sql_setdlist[53].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)FR_FO_CUR_CODE0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 460; sql_setdlist[54].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)FR_FO_CUR_CODE1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 460; sql_setdlist[55].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)FR_FO_CUR_CODE2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 460; sql_setdlist[56].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)FR_FO_CUR_CODE3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 460; sql_setdlist[57].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)FR_FO_CUR_CODE4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 460; sql_setdlist[58].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)FR_FO_CUR_CODE5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 460; sql_setdlist[59].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)FR_FO_CUR_RECON_ACQ0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 460; sql_setdlist[60].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)FR_FO_CUR_RECON_ACQ1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 460; sql_setdlist[61].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)FR_FO_CUR_RECON_ACQ2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 460; sql_setdlist[62].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)FR_FO_CUR_RECON_ACQ3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 460; sql_setdlist[63].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)FR_FO_CUR_RECON_ACQ4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sqlasetdata(2,384,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_FO_CUR_RECON_ACQ5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FR_FO_CUR_RECON_ISS0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_FO_CUR_RECON_ISS1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FR_FO_CUR_RECON_ISS2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_FO_CUR_RECON_ISS3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FR_FO_CUR_RECON_ISS4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FR_FO_CUR_RECON_ISS5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 480; sql_setdlist[7].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)&FR_FO_DEC_POS0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 480; sql_setdlist[8].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)&FR_FO_DEC_POS1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 480; sql_setdlist[9].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)&FR_FO_DEC_POS2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 480; sql_setdlist[10].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)&FR_FO_DEC_POS3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 480; sql_setdlist[11].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)&FR_FO_DEC_POS4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 480; sql_setdlist[12].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)&FR_FO_DEC_POS5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)FR_FO_INITIATOR0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)FR_FO_INITIATOR1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FR_FO_INITIATOR2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FR_FO_INITIATOR3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FR_FO_INITIATOR4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FR_FO_INITIATOR5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)FR_FO_MEMO0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FR_FO_MEMO1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 460; sql_setdlist[21].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)FR_FO_MEMO2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 460; sql_setdlist[22].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)FR_FO_MEMO3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 460; sql_setdlist[23].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)FR_FO_MEMO4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 460; sql_setdlist[24].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)FR_FO_MEMO5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FR_FO_TYPE0;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FR_FO_TYPE1;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FR_FO_TYPE2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FR_FO_TYPE3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FR_FO_TYPE4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FR_FO_TYPE5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 480; sql_setdlist[31].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)&FR_O_AMT_CARD_BILL;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 480; sql_setdlist[32].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)&FR_O_AMT_RECON_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 480; sql_setdlist[33].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)&FR_O_AMT_RECON_ISS;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 480; sql_setdlist[34].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)&FR_O_AMT_RECON_NET;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 480; sql_setdlist[35].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)&FR_O_AMT_TRAN;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 460; sql_setdlist[36].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)FR_ODE_INST_ID_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 460; sql_setdlist[37].sqllen = 5;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)FR_ODE_MTI;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 460; sql_setdlist[38].sqllen = 7;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)FR_ODE_SYS_TRA_AUD_NO;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 460; sql_setdlist[39].sqllen = 15;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)FR_ODE_TSTAMP_LOCL_TR;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 460; sql_setdlist[40].sqllen = 17;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)FR_TSTAMP_REV_CREATED;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 448; sql_setdlist[41].sqllen = 254;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)&FR_ADTL_DATA_FEE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 460; sql_setdlist[42].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)FR_ISS_ACQ_TYPE_FEE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 448; sql_setdlist[43].sqllen = 80;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)&FR_NET_UNIQUE_DAT_FEE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 460; sql_setdlist[44].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)FR_BRANCH_ID_ACQ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 460; sql_setdlist[45].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)FR_CNTRY_REC_INST_ADJ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 460; sql_setdlist[46].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)FR_CNTRY_REQ_INST_ADJ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 460; sql_setdlist[47].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)FR_INST_ID_REC_ADJ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 460; sql_setdlist[48].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)FR_INST_ID_REQ_ADJ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 460; sql_setdlist[49].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)FR_NET_IND_ADJ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 480; sql_setdlist[50].sqllen = 8;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)&FR_ORIG_AMT_TRAN_ADJ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 460; sql_setdlist[51].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)FR_REQ_ACQ_ISS_IND;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 460; sql_setdlist[52].sqllen = 24;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)FR_TRACE_DATA_ADJ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 460; sql_setdlist[53].sqllen = 15;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)FR_TSTAMP_LOCAL_ADJ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 460; sql_setdlist[54].sqllen = 17;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)FR_TSTAMP_TRANS_ADJ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 448; sql_setdlist[55].sqllen = 400;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)&FR_EXTENSION_DATA_ADJ;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 460; sql_setdlist[56].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)FR_BRIDGE_ACQ_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 460; sql_setdlist[57].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)FR_BRIDGE_ISS_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 500; sql_setdlist[58].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)&FR_BIN_LENGTH;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 460; sql_setdlist[59].sqllen = 26;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)FR_PAN_IDENTIFIER;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 460; sql_setdlist[60].sqllen = 30;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)FR_PYMT_ACCT_REF;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 448; sql_setdlist[61].sqllen = 100;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)&FR_MERCH_DISP_NAME;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 460; sql_setdlist[62].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)FR_EMV_3D_CAVV_VER_BY;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 460; sql_setdlist[63].sqllen = 37;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)FR_EMV_3D_TRAN_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sqlasetdata(2,448,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[24];
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_COOPER_SCORE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FR_COOPER_REASON;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 448; sql_setdlist[2].sqllen = 52;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)&FR_AMX_FRAUD_DATA;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FR_ISSUER_SCRIPT_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 21;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_P1C_ACCT_TOKEN;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FR_P1C_ADL_RESP_DATA;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 21;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FR_P1C_CRDHLDR_TOKEN;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FR_PRM_ADL_RESP_DATA;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 4;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FR_SAP_ADL_RESP_DATA;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 448; sql_setdlist[9].sqllen = 99;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)&FR_ECOM_DATA;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 460; sql_setdlist[10].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)FR_INST_ID_FRWD;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 26;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)FR_TOKEN_DEVICE_NAME;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 3;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)FR_TOKEN_ENTITY;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 448; sql_setdlist[13].sqllen = 40;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)&FR_SELLER_EMAIL;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 448; sql_setdlist[14].sqllen = 20;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)&FR_SELLER_PHONE;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 448; sql_setdlist[15].sqllen = 20;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)&FR_SELLER_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FR_FORCE_POST_DROP_IND;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FR_FP_HOLD_MATCH_FLG;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 12;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FR_ODE_INST_ID_FRWD;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 11;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)FR_ODE_DATE_TIME_XMIT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 11;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FR_DATE_TIME_XMIT;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 500; sql_setdlist[21].sqllen = 2;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)&FR_PAN_TOKEN_BIN_LEN;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 448; sql_setdlist[22].sqllen = 48;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)&FR_TOKEN_DEVICE_ID;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 460; sql_setdlist[23].sqllen = 7;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)FR_WALLET_REASON;
#line 3251 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 3251 "CXOSD206.sqx"
      sqlasetdata(2,512,24,sql_setdlist,0L,0L);
    }
#line 3251 "CXOSD206.sqx"
  sqlacall((unsigned short)24,3,2,0,0L);
#line 3251 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 3251 "CXOSD206.sqx"


   char* p;
   int nColumnNumber=0;
   switch (sqlca.sqlcode)
   {
      case 0:
         m_iPrevColumnNumber=0;
         return UDBAddFinancialCommand::SUCCESS;
      case -302:
         /*
         Database::instance()->traceSQLError((void*)&sqlca,m_sID, "captureColumnNumber");
         nColumnNumber=atoi((char*)((struct sqlca*)&sqlca)->sqlerrmc);
         if (nColumnNumber!=m_iPrevColumnNumber)
         {
            m_iPrevColumnNumber=nColumnNumber;
            if (nColumnNumber > 3)
            {
               int i=0;
               while ((i < m_hOptLogic.size()) && (nColumnNumber > m_hOptLogic[i].first))
               {
                  nColumnNumber = nColumnNumber - m_hOptLogic[i].first;
                  i++;
               }
               m_hOptLogic[i].second->repair(nColumnNumber-1);
               copyMemberToHost();
               nState=UDBAddFinancialCommand::INSERT_FIN_RECORD;
            }
         }
         else
         */
         {
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
         break;
      case -514:
      case -518:
         p = strstr(FINU_INSERT.data,"FIN_RECORD");
         memcpy(p + 10,"YYYYMM",6);
         return UDBAddFinancialCommand::PREPARE_INSERT_FIN_RECORD;
      case -204:
      case  204:
      case -205:
      case -206:
      case  206:
      case -289:
      case -818:
      case -904:
         nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
         break;
      case -911:
      case -913:
         nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
         Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            m_iPrevColumnNumber=0;
            nState = UDBAddFinancialCommand::SUCCESS;
         }
         else
         {
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,
      "insertMonthlyFinancial");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::insertFinancial%4915EAB1035B.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::insertICC ()
{
  //## begin dndb2database::UDBAddFinancialCommand::insertICC%4917192B01E4.body preserve=yes
   State nState;
   char *p;
   FI_UNIQUENESS_KEY = FR_UNIQUENESS_KEY;
   Trace::put(FI_INSERT.data, FI_INSERT.length);
   copyICCToHost();
   
/*
EXEC SQL EXECUTE DI3 USING
      :FI_AMOUNT_OTHER,
      :FI_APPL_CRYPTOGRAM,
      :FI_APPL_ID,
      :FI_APPL_INTRCHG_PROF,
      :FI_APPL_TRAN_COUNTER,
      :FI_APPL_VERSION_NO,
      :FI_CARDH_VER_RESULT,
      :FI_CHIP_TOKEN_REQ_ID,
      :FI_COPAC_CCS_CRYPTO,
      :FI_CRYPTOGRAM_AMOUNT,
      :FI_CRYPT_INFO_DATA,
      :FI_DEDICATED_FILE_NAM,
      :FI_FORM_FACTOR_IND,
      :FI_ISS_APPL_DATA,
      :FI_ISS_AUTH_DATA,
      :FI_ISS_DISCR_DATA,
      :FI_ISS_SCRIPT1_DATA,
      :FI_ISS_SCRIPT2_DATA,
      :FI_ISS_SCRIPT_RESULT,
      :FI_TERMINAL_TYPE,
      :FI_TERM_CAPABILITIES,
      :FI_TERM_COUNTRY_CODE,
      :FI_TERM_SERIAL_NO,
      :FI_TERM_VERIFY_RESULT,
      :FI_TRAN_CATEGORY_CODE,
      :FI_TRAN_CURRENCY_CODE,
      :FI_TRAN_DATE,
      :FI_TRAN_SEQ_COUNTER,
      :FI_TRAN_TYPE,
      :FI_UNPREDICTABLE_NO,
      :FI_DERIVATION_KEY_IDX,
      :FI_ARPC_CRYPTOGRAM,
      :FI_ARPC_RESPCODE,
      :FR_TSTAMP_TRANS,
      :FI_UNIQUENESS_KEY;
*/

{
#line 3375 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 3375 "CXOSD206.sqx"
  sqlaaloc(2,35,2,0L);
    {
      struct sqla_setdata_list sql_setdlist[35];
#line 3375 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 13;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FI_AMOUNT_OTHER;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 17;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FI_APPL_CRYPTOGRAM;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 17;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FI_APPL_ID;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 5;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FI_APPL_INTRCHG_PROF;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 5;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FI_APPL_TRAN_COUNTER;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 5;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FI_APPL_VERSION_NO;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 7;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FI_CARDH_VER_RESULT;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 12;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FI_CHIP_TOKEN_REQ_ID;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 17;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FI_COPAC_CCS_CRYPTO;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 13;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)FI_CRYPTOGRAM_AMOUNT;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 460; sql_setdlist[10].sqllen = 3;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)FI_CRYPT_INFO_DATA;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 17;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)FI_DEDICATED_FILE_NAM;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 33;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)FI_FORM_FACTOR_IND;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 65;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)FI_ISS_APPL_DATA;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 33;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)FI_ISS_AUTH_DATA;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 65;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FI_ISS_DISCR_DATA;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 513;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FI_ISS_SCRIPT1_DATA;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 513;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FI_ISS_SCRIPT2_DATA;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 41;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FI_ISS_SCRIPT_RESULT;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 3;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)FI_TERMINAL_TYPE;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 7;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FI_TERM_CAPABILITIES;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 460; sql_setdlist[21].sqllen = 4;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)FI_TERM_COUNTRY_CODE;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 460; sql_setdlist[22].sqllen = 9;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)FI_TERM_SERIAL_NO;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 460; sql_setdlist[23].sqllen = 11;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)FI_TERM_VERIFY_RESULT;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 460; sql_setdlist[24].sqllen = 2;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)FI_TRAN_CATEGORY_CODE;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 4;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FI_TRAN_CURRENCY_CODE;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 7;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FI_TRAN_DATE;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 9;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FI_TRAN_SEQ_COUNTER;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 3;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FI_TRAN_TYPE;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 11;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FI_UNPREDICTABLE_NO;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 3;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FI_DERIVATION_KEY_IDX;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 460; sql_setdlist[31].sqllen = 17;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)FI_ARPC_CRYPTOGRAM;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 460; sql_setdlist[32].sqllen = 3;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)FI_ARPC_RESPCODE;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 17;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FR_TSTAMP_TRANS;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 500; sql_setdlist[34].sqllen = 2;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)&FI_UNIQUENESS_KEY;
#line 3375 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 3375 "CXOSD206.sqx"
      sqlasetdata(2,0,35,sql_setdlist,0L,0L);
    }
#line 3375 "CXOSD206.sqx"
  sqlacall((unsigned short)24,4,2,0,0L);
#line 3375 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 3375 "CXOSD206.sqx"


   int nColumnNumber=0;
   switch (sqlca.sqlcode)
   {
      case 0:
         m_iPrevColumnNumber=0;
         return UDBAddFinancialCommand::SUCCESS;
      case -302:
         Database::instance()->traceSQLError((void*)&sqlca,m_sID, "captureColumnNumber");
         nColumnNumber=atoi((char*)((struct sqlca*)&sqlca)->sqlerrmc);
         if (nColumnNumber!=m_iPrevColumnNumber)
         {
            m_iPrevColumnNumber=nColumnNumber;
            if (nColumnNumber <= IntegratedCircuitCardSegment::instance()->getNumberOfFields()) //Ignore FR_TSTAMP_TRANS and FI_UNIQUENESS_KEY
            {
               IntegratedCircuitCardSegment::instance()->repair(nColumnNumber-1);
               copyICCToHost();
               nState=UDBAddFinancialCommand::INSERT_FIN_ICC;
            }
         }
         else
         {
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
         break;
      case -514:
      case -518:
         p = strstr(FI_INSERT.data,"FIN_ICC");
         memcpy(p + 7,"YYYYMM",6);
         return UDBAddFinancialCommand::PREPARE_INSERT_FIN_ICC;
      case -803:
         return UDBAddFinancialCommand::INTERPRET_DUPLICATE;
      case -204:
      case  204:
      case -205:
      case -206:
      case  206:
      case -289:
      case -818:
      case -904:
         nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
         break;
      case -911:
      case -913:
         nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
         Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            m_iPrevColumnNumber=0;
            nState = UDBAddFinancialCommand::SUCCESS;
         }
         else
         {
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,
      "insertICC");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::insertICC%4917192B01E4.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::insertFraudRule ()
{
  //## begin dndb2database::UDBAddFinancialCommand::insertFraudRule%4C0CCD130227.body preserve=yes
   State nState;
   char *p;
   Trace::put(FFR_INSERT.data, FFR_INSERT.length);
   if (!copyFraudRuleToHost())
   {
      nState = UDBAddFinancialCommand::DATABASE_FAILURE;
      Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
      return nState;
   }
   
/*
EXEC SQL EXECUTE DI4 USING
      :FR_TSTAMP_TRANS,
      :FR_UNIQUENESS_KEY,
      :FFR_SEQ_NO,
      :FFR_INST_ID_RECON_ISS,
      :FFR_INST_ID_RECON_ACQ,
      :FFR_RULE_NAME,
	  :FFR_FRAUD_SCORE,
	  :FFR_SUB_CLASS_CODE,
	  :FFR_FRAUD_ID,
	  :FFR_CARD_BIN_HASH;
*/

{
#line 3471 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 3471 "CXOSD206.sqx"
  sqlaaloc(2,10,3,0L);
    {
      struct sqla_setdata_list sql_setdlist[10];
#line 3471 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 17;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_TSTAMP_TRANS;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 500; sql_setdlist[1].sqllen = 2;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)&FR_UNIQUENESS_KEY;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 500; sql_setdlist[2].sqllen = 2;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)&FFR_SEQ_NO;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 12;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FFR_INST_ID_RECON_ISS;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 12;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FFR_INST_ID_RECON_ACQ;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 448; sql_setdlist[5].sqllen = 64;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)&FFR_RULE_NAME;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 4;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FFR_FRAUD_SCORE;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 3;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FFR_SUB_CLASS_CODE;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 40;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FFR_FRAUD_ID;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 24;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)FFR_CARD_BIN_HASH;
#line 3471 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 3471 "CXOSD206.sqx"
      sqlasetdata(2,0,10,sql_setdlist,0L,0L);
    }
#line 3471 "CXOSD206.sqx"
  sqlacall((unsigned short)24,5,2,0,0L);
#line 3471 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 3471 "CXOSD206.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         return UDBAddFinancialCommand::SUCCESS;
      case -514:
      case -518:
         p = strstr(FFR_INSERT.data,"FIN_FRAUD_RULE_");
         memcpy(p + 15,"YYYYMM",6);
         return UDBAddFinancialCommand::PREPARE_INSERT_FRAUD_RULE;
      case -204:
      case  204:
      case -205:
      case -206:
      case  206:
      case -289:
      case -818:
      case -904:
         nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
         break;
      case -911:
      case -913:
         nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
         Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
         break;
      default:
         if (sqlca.sqlcode > 0)
            nState = UDBAddFinancialCommand::SUCCESS;
         else
         {
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,
      "insertFraudRule");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::insertFraudRule%4C0CCD130227.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::insertLocator ()
{
  //## begin dndb2database::UDBAddFinancialCommand::insertLocator%4915EAB1036B.body preserve=yes
   UseCase::addItem();
   State nState;
   char *p;
   Trace::put(FL_INSERT.data, FL_INSERT.length);

   
/*
EXEC SQL EXECUTE DI1 USING
      :FR_TSTAMP_TRANS,
      :FR_UNIQUENESS_KEY,
      :FR_ACCT_ID_1,
      :FR_AMT_RECON_NET,
      :FR_CUR_RECON_NET,
      :FR_FUNC_CODE,
      :FR_MERCH_TYPE,
      :FR_DATE_RECON_ACQ,
      :FR_DATE_RECON_ISS,
      :FR_PAN_TOKEN,
      :FR_CARD_ACPT_BUS_CODE,
      :FR_COUNTRY_ACQ_INST,
      :FR_TRAN_DISPOSITION,
      :FR_CARD_ACPT_ID,
      :FR_POS_CRD_DAT_IN_MOD,
      :FL_ACT_CODE,
      :FL_APPROVAL_CODE,
      :FL_AUTH_BY,
      :FL_CARD_ACPT_TERM_ID,
      :FL_FIN_TYPE,
      :FL_INST_ID_ACQ,
      :FL_INST_ID_ISS,
      :FL_INST_ID_RECN_ACQ_B,
      :FL_INST_ID_RECN_ISS_B,
      :FL_INST_ID_RECON_ACQ,
      :FL_INST_ID_RECON_ISS,
      :FL_MAPPED_DUP_DATA,
      :FL_NET_TERM_ID,
      :FL_PAN,
      :FL_PROC_GRP_ID_ACQ_B,
      :FL_PROC_GRP_ID_ISS_B,
      :FL_PROC_ID_ACQ,
      :FL_PROC_ID_ACQ_B,
      :FL_PROC_ID_ISS,
      :FL_PROC_ID_ISS_B,
      :FL_RETRIEVAL_REF_NO,
      :FL_RPT_LVL_ID_B,
      :FL_SUBSCRIBER_IND,
      :FL_SYS_TRACE_AUDIT_NO,
      :FL_TRAN_CLASS,
      :FL_TRAN_TYPE_ID,
      :FL_TSTAMP_LOCAL,
      :FL_PAN_PREFIX,
      :FL_INV_ORDER_NO,
      :FL_PAN_SUFFIX,
      :FL_PAN_TOKEN_PREFIX,
      :FL_PAN_TOKEN_SUFFIX,
      :FL_TRANSACTION_ID;
*/

{
#line 3575 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 3575 "CXOSD206.sqx"
  sqlaaloc(2,48,4,0L);
    {
      struct sqla_setdata_list sql_setdlist[48];
#line 3575 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 17;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_TSTAMP_TRANS;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 500; sql_setdlist[1].sqllen = 2;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)&FR_UNIQUENESS_KEY;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 29;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_ACCT_ID_1;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 480; sql_setdlist[3].sqllen = 8;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)&FR_AMT_RECON_NET;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 4;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_CUR_RECON_NET;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 4;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FR_FUNC_CODE;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 5;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FR_MERCH_TYPE;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 9;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FR_DATE_RECON_ACQ;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 9;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FR_DATE_RECON_ISS;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 20;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)FR_PAN_TOKEN;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 460; sql_setdlist[10].sqllen = 5;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)FR_CARD_ACPT_BUS_CODE;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 4;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)FR_COUNTRY_ACQ_INST;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 2;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)FR_TRAN_DISPOSITION;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 16;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)FR_CARD_ACPT_ID;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 2;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)FR_POS_CRD_DAT_IN_MOD;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 4;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FL_ACT_CODE;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 7;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FL_APPROVAL_CODE;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 2;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FL_AUTH_BY;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 17;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FL_CARD_ACPT_TERM_ID;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 4;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)FL_FIN_TYPE;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 12;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FL_INST_ID_ACQ;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 460; sql_setdlist[21].sqllen = 12;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)FL_INST_ID_ISS;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 460; sql_setdlist[22].sqllen = 12;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)FL_INST_ID_RECN_ACQ_B;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 460; sql_setdlist[23].sqllen = 12;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)FL_INST_ID_RECN_ISS_B;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 460; sql_setdlist[24].sqllen = 12;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)FL_INST_ID_RECON_ACQ;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 12;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FL_INST_ID_RECON_ISS;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 31;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FL_MAPPED_DUP_DATA;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 9;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FL_NET_TERM_ID;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 29;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FL_PAN;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 9;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FL_PROC_GRP_ID_ACQ_B;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 9;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FL_PROC_GRP_ID_ISS_B;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 460; sql_setdlist[31].sqllen = 9;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)FL_PROC_ID_ACQ;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 460; sql_setdlist[32].sqllen = 9;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)FL_PROC_ID_ACQ_B;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 9;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FL_PROC_ID_ISS;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 460; sql_setdlist[34].sqllen = 9;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)FL_PROC_ID_ISS_B;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 460; sql_setdlist[35].sqllen = 13;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)FL_RETRIEVAL_REF_NO;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 460; sql_setdlist[36].sqllen = 17;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)FL_RPT_LVL_ID_B;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 460; sql_setdlist[37].sqllen = 2;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)FL_SUBSCRIBER_IND;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 460; sql_setdlist[38].sqllen = 7;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)FL_SYS_TRACE_AUDIT_NO;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 460; sql_setdlist[39].sqllen = 4;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)FL_TRAN_CLASS;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 460; sql_setdlist[40].sqllen = 11;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)FL_TRAN_TYPE_ID;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 460; sql_setdlist[41].sqllen = 15;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)FL_TSTAMP_LOCAL;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 460; sql_setdlist[42].sqllen = 13;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)FL_PAN_PREFIX;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 460; sql_setdlist[43].sqllen = 16;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)FL_INV_ORDER_NO;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 460; sql_setdlist[44].sqllen = 5;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)FL_PAN_SUFFIX;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 460; sql_setdlist[45].sqllen = 13;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)FL_PAN_TOKEN_PREFIX;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 460; sql_setdlist[46].sqllen = 5;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)FL_PAN_TOKEN_SUFFIX;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 460; sql_setdlist[47].sqllen = 37;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)FL_TRANSACTION_ID;
#line 3575 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 3575 "CXOSD206.sqx"
      sqlasetdata(2,0,48,sql_setdlist,0L,0L);
    }
#line 3575 "CXOSD206.sqx"
  sqlacall((unsigned short)24,6,2,0,0L);
#line 3575 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 3575 "CXOSD206.sqx"


   int nColumnNumber=0;
   switch (sqlca.sqlcode)
   {
      case 0:
         m_iPrevColumnNumber=0;
         return UDBAddFinancialCommand::PREPARE_INSERT_FIN_RECORD;
      case -302:
         Database::instance()->traceSQLError((void*)&sqlca,m_sID, "captureColumnNumber");
         nColumnNumber=atoi((char*)((struct sqlca*)&sqlca)->sqlerrmc);
         if (nColumnNumber!=m_iPrevColumnNumber)
         {
            m_iPrevColumnNumber=nColumnNumber;
            //Leave out FR_TSTAMP_TRANS, FR_UNIQUENESS_KEY, FR_ACCT_ID_1, FR_AMOUNT_RECON_NET, FR_CUR_RECON_NET, FR_FUNC_CODE, FR_MERCH_TYPE,
            //FL_PAN_PREFIX, FL_INV_ORDER_NO, FL_PAN_SUFFIX, FL_PAN_TOKEN_PREFIX, FL_PAN_TOKEN_SUFFIX
            //Restrict between ACT_CODE and TSTAMP_LOCAL from RS13, ACT_CODE is offset 36 in RS13
            if ((nColumnNumber > 7) && (nColumnNumber < 35))
            {
               int offset = nColumnNumber+28;
               if (nColumnNumber==11) offset=103;                        //CARD_ACPT_TERM_ID
               FinancialBaseSegment::instance()->repair(offset);
               copyMemberToHost();                                       //FL_FIN_TYPE is the only one that is not copied among FL members
               nState=UDBAddFinancialCommand::INSERT_FIN_L;
            }
         }
         else
         {
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
         break;
      case -514:
      case -518:
         p = strstr(FL_INSERT.data,"FIN_L");
         memcpy(p + 5,"YYYYMM",6);
         return UDBAddFinancialCommand::PREPARE_INSERT_FIN_L;
      case -803:
         return UDBAddFinancialCommand::INTERPRET_DUPLICATE;
      case -204:
      case  204:
      case -205:
      case -206:
      case  206:
      case -289:
      case -818:
      case -904:
         nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
         break;
      case -911:
      case -913:
         nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
         Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            m_iPrevColumnNumber=0;
            nState = UDBAddFinancialCommand::PREPARE_INSERT_FIN_RECORD;
         }
         else
         {
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,
      "insertLocator");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::insertLocator%4915EAB1036B.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::insertMultipleRoute ()
{
  //## begin dndb2database::UDBAddFinancialCommand::insertMultipleRoute%54861FF60310.body preserve=yes
   State nState;
   char *p;
   FM_UNIQUENESS_KEY = FR_UNIQUENESS_KEY;
   Trace::put(FM_INSERT.data, FM_INSERT.length);
   copyMultipleRouteToHost();

   
/*
EXEC SQL EXECUTE DI5 USING
     :FM_PRIMARY_PROC_ID,
     :FM_PRIMARY_PROCESS_ID,
     :FM_PRIMARY_TD_PROCESS_ID,
     :FM_PRIMARY_TD_MATCH_OPT,
     :FM_PROC_ID,
     :FM_PROCESS_ID,
     :FM_TD_PROCESS_ID,
     :FM_TD_MATCH_OPT,
     :FM_MULTI_RTE_OPT,
     :FM_STANDIN_IND,
     :FM_COMPLETION_IND,
     :FM_ADVICE_IND,
     :FM_DENY_OPT,
     :FM_PREAUTH_IND,
     :FM_REQUEST_BAL_IND,
     :FM_RESPONSE_BAL_IND,
     :FM_APPROVED_BY,
     :FM_ADVICE_TRAN,
     :FM_TDRESP,
     :FR_TSTAMP_TRANS,
     :FM_UNIQUENESS_KEY;
*/

{
#line 3684 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 3684 "CXOSD206.sqx"
  sqlaaloc(2,21,5,0L);
    {
      struct sqla_setdata_list sql_setdlist[21];
#line 3684 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 9;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FM_PRIMARY_PROC_ID;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 7;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FM_PRIMARY_PROCESS_ID;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 16;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FM_PRIMARY_TD_PROCESS_ID;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FM_PRIMARY_TD_MATCH_OPT;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 9;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FM_PROC_ID;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 7;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FM_PROCESS_ID;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 16;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FM_TD_PROCESS_ID;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FM_TD_MATCH_OPT;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FM_MULTI_RTE_OPT;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)FM_STANDIN_IND;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 460; sql_setdlist[10].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)FM_COMPLETION_IND;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)FM_ADVICE_IND;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)FM_DENY_OPT;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)FM_PREAUTH_IND;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)FM_REQUEST_BAL_IND;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FM_RESPONSE_BAL_IND;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FM_APPROVED_BY;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FM_ADVICE_TRAN;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FM_TDRESP;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 17;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)FR_TSTAMP_TRANS;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 500; sql_setdlist[20].sqllen = 2;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)&FM_UNIQUENESS_KEY;
#line 3684 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 3684 "CXOSD206.sqx"
      sqlasetdata(2,0,21,sql_setdlist,0L,0L);
    }
#line 3684 "CXOSD206.sqx"
  sqlacall((unsigned short)24,7,2,0,0L);
#line 3684 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 3684 "CXOSD206.sqx"


   int nColumnNumber=0;
   switch (sqlca.sqlcode)
   {
      case 0:
         m_iPrevColumnNumber=0;
         return UDBAddFinancialCommand::SUCCESS;
      case -302:
         Database::instance()->traceSQLError((void*)&sqlca,m_sID, "captureColumnNumber");
         nColumnNumber=atoi((char*)((struct sqlca*)&sqlca)->sqlerrmc);
         if (nColumnNumber!=m_iPrevColumnNumber)
         {
            m_iPrevColumnNumber=nColumnNumber;
            //Ignore FR_TSTAMP_TRANS and FM_UNIQUENESS_KEY
            if (nColumnNumber <= MultipleRouteSegment::instance()->getNumberOfFields())
            {
               MultipleRouteSegment::instance()->repair(nColumnNumber-1);
               copyMultipleRouteToHost();
               nState=UDBAddFinancialCommand::INSERT_MULTIPLE_ROUTE;
            }
         }
         else
         {
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
         break;
      case -514:
      case -518:
         p = strstr(FM_INSERT.data,"FIN_ROUTE");
         memcpy(p + 9,"YYYYMM",6);
         return UDBAddFinancialCommand::PREPARE_INSERT_MULTIPLE_ROUTE;
      case -204:
      case  204:
      case -205:
      case -206:
      case  206:
      case -289:
      case -818:
      case -904:
         nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
         break;
      case -911:
      case -913:
         nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
         Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            m_iPrevColumnNumber=0;
            nState = UDBAddFinancialCommand::SUCCESS;
         }
         else
         {
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,"insertMultipleRoute");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::insertMultipleRoute%54861FF60310.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::interpretDuplicate ()
{
  //## begin dndb2database::UDBAddFinancialCommand::interpretDuplicate%4915EAB1037A.body preserve=yes
   //check if failing on Timestamp or Business Duplicate
   if (!checkForBusinessDuplicate(FR_TSTAMP_TRANS))
   {
      m_iRetryCount++;
      if (m_iRetryCount >= 9999)  //prevent infinite loop
      {
         //record is not a business duplicate but is still failing on a duplicate constraint
         FinancialBaseSegment* pBaseSegment = FinancialBaseSegment::instance();
            int iLen = 0;
            char szDupMsg[512];
         string strDupMsg = "UDBAddFinancialCommand::execute() - ";
         strDupMsg.append
         ("interpretDuplicate() max retries failed for record with ");
         strDupMsg.append("TSTAMP_TRANS = %s, UNIQUENESS_ID = %d ");
         strDupMsg.append
         ("TSTAMP_LOCAL = %s, MAPPED_DUP_DATA = %s, NET_TERM_ID = %s, ");
         strDupMsg.append
         ("PAN = %s, RETRIEVAL_REF_NO = %s, TRAN_TYPE_ID = %s ");
         strDupMsg.append
         ("SYS_TRACE_AUDIT_NO = %s, ACT_CODE = %s, AUTH_BY = %s, ");
         strDupMsg.append("CARD_ACPT_TERM_ID = %s");
         iLen = snprintf(szDupMsg,sizeof(szDupMsg),strDupMsg.data(),
                              pBaseSegment->zTSTAMP_TRANS(),
                              FR_UNIQUENESS_KEY,
                              pBaseSegment->zTSTAMP_LOCAL(),
                              pBaseSegment->zMAPPED_DUP_DATA(),
                              pBaseSegment->zNET_TERM_ID(),
                              pBaseSegment->zPAN(),
                              pBaseSegment->zRETRIEVAL_REF_NO(),
                              pBaseSegment->zTRAN_TYPE_ID(),
                              pBaseSegment->zSYS_TRACE_AUDIT_NO(),
                              pBaseSegment->zACT_CODE(),
                              pBaseSegment->zAUTH_BY(),
                              pBaseSegment->zCARD_ACPT_TERM_ID());
         Trace::put(szDupMsg,iLen,true);
         //bump count of records tossed
         UseCase::add("DUPLICAT");
         //return failure because this is not a normal situation
         return UDBAddFinancialCommand::DATABASE_FAILURE;
      }
      return UDBAddFinancialCommand::TIMESTAMP_DUPLICATE;
   }
   else
   {
        UseCase::add("DUPLICAT");
        return UDBAddFinancialCommand::SUCCESS;
   }
  //## end dndb2database::UDBAddFinancialCommand::interpretDuplicate%4915EAB1037A.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::prepareICC ()
{
  //## begin dndb2database::UDBAddFinancialCommand::prepareICC%491719B401B5.body preserve=yes
   char* p = strstr(FI_INSERT.data,"FIN_ICC");
   if (!memcmp(p + 7,FR_TSTAMP_TRANS,6))
      return UDBAddFinancialCommand::INSERT_FIN_ICC;
   memcpy(p + 7,FR_TSTAMP_TRANS,6);
   State nState;

   
/*
EXEC SQL PREPARE DI3 FROM :FI_INSERT;
*/

{
#line 3818 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 3818 "CXOSD206.sqx"
  sqlastls( *(unsigned short *)&FI_INSERT,(const char*)&FI_INSERT+2,0L);
#line 3818 "CXOSD206.sqx"
  sqlacall((unsigned short)27,4,0,0,0L);
#line 3818 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 3818 "CXOSD206.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         return UDBAddFinancialCommand::INSERT_FIN_ICC;
      case -204:
      case  204:
      case -205:
      case -206:
      case  206:
      case -289:
      case -818:
      case -904:
         nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
         break;
      case -911:
      case -913:
         nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
         Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            nState = UDBAddFinancialCommand::INSERT_FIN_ICC;
         }
         else
         {
            UseCase::add("PREPARE");
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,
      "prepareICC");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::prepareICC%491719B401B5.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::prepareFraudRule ()
{
  //## begin dndb2database::UDBAddFinancialCommand::prepareFraudRule%4C0CCD690014.body preserve=yes
   char* p = strstr(FFR_INSERT.data,"FIN_FRAUD_RULE_");
   if (!memcmp(p + 15,FR_TSTAMP_TRANS,6))
      return UDBAddFinancialCommand::INSERT_FRAUD_RULE;
   memcpy(p + 15,FR_TSTAMP_TRANS,6);
   State nState;
   
/*
EXEC SQL PREPARE DI4 FROM :FFR_INSERT;
*/

{
#line 3872 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 3872 "CXOSD206.sqx"
  sqlastls( *(unsigned short *)&FFR_INSERT,(const char*)&FFR_INSERT+2,0L);
#line 3872 "CXOSD206.sqx"
  sqlacall((unsigned short)27,5,0,0,0L);
#line 3872 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 3872 "CXOSD206.sqx"

   switch (sqlca.sqlcode)
   {
      case 0:
         return UDBAddFinancialCommand::INSERT_FRAUD_RULE;
      case -204:
      case  204:
      case -205:
      case -206:
      case  206:
      case -289:
      case -818:
      case -904:
         nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
         break;
      case -911:
      case -913:
         nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
         Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            nState = UDBAddFinancialCommand::INSERT_FRAUD_RULE;
         }
         else
         {
            UseCase::add("PREPARE");
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,
      "prepareFraudRule");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::prepareFraudRule%4C0CCD690014.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::prepareInsert ()
{
  //## begin dndb2database::UDBAddFinancialCommand::prepareInsert%4915EAB1038A.body preserve=yes
   char* p = strstr(FL_INSERT.data,"FIN_L");
   if (!memcmp(p + 5,FR_TSTAMP_TRANS,6))
      return UDBAddFinancialCommand::INSERT_FIN_L;
   State nState = UDBAddFinancialCommand::PREPARE_INSERT_FIN_L;
   while (nState == UDBAddFinancialCommand::PREPARE_INSERT_FIN_L
      || nState == UDBAddFinancialCommand::PREPARE_RETRY)
   {
      memcpy(p + 5,FR_TSTAMP_TRANS,6);

      
/*
EXEC SQL PREPARE DI1 FROM :FL_INSERT;
*/

{
#line 3929 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 3929 "CXOSD206.sqx"
  sqlastls( *(unsigned short *)&FL_INSERT,(const char*)&FL_INSERT+2,0L);
#line 3929 "CXOSD206.sqx"
  sqlacall((unsigned short)27,6,0,0,0L);
#line 3929 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 3929 "CXOSD206.sqx"


      switch (sqlca.sqlcode)
      {
         case 0:
            return UDBAddFinancialCommand::INSERT_FIN_L;
         case -204:
         case  204:
            if (nState == UDBAddFinancialCommand::PREPARE_INSERT_FIN_L)
            {
               m_strTSTAMP_TRANS.assign(FR_TSTAMP_TRANS,16);
               FinancialBaseSegment::instance()->setTSTAMP_TRANS(Clock::instance()->getYYYYMMDDHHMMSSHN(true).data(),16);
               memcpy(FR_TSTAMP_TRANS,FinancialBaseSegment::instance()->zTSTAMP_TRANS(),sizeof(FR_TSTAMP_TRANS));
               FR_INSERT_SEQUENCE_NO = 0;
               KeyRing::instance()->tokenize((char*)FinancialBaseSegment::instance()->zPAN(),28,FR_TSTAMP_TRANS);
               string strBuffer;
               if (Extract::instance()->getSpec("RU07",strBuffer)
                   && strBuffer.find("NPI~ACCT_ID_1=2") != string::npos)
                   KeyRing::instance()->tokenize((char*)FinancialBaseSegment::instance()->zACCT_ID_1(),28,FR_TSTAMP_TRANS);
               nState = UDBAddFinancialCommand::PREPARE_RETRY;
               break;
            }
         case -205:
         case -206:
         case  206:
         case -289:
         case -818:
         case -904:
            nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
            break;
         case -911:
         case -913:
            nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
            break;
         case -900:
         case -923:
         case -924:
         case -991:
         case -1024:
            nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
            break;
         default:
            if (sqlca.sqlcode > 0)
            {
               nState = UDBAddFinancialCommand::INSERT_FIN_L;
            }
            else
            {
               UseCase::add("PREPARE");
               nState = UDBAddFinancialCommand::DATABASE_FAILURE;
               Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
            }
      }
   }
   memcpy(p + 5,"      ",6); // clear FIN_L date portion if prepare fails
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,"prepareInsert");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::prepareInsert%4915EAB1038A.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::prepareMonthlyFinancial ()
{
  //## begin dndb2database::UDBAddFinancialCommand::prepareMonthlyFinancial%4915EAB1038B.body preserve=yes
   State nState;
   char* p = strstr(FINU_INSERT.data,"FIN_RECORD");
   if (!memcmp(p + 10,FR_TSTAMP_TRANS,6))
      return UDBAddFinancialCommand::INSERT_FIN_RECORD;
   memcpy(p + 10,FR_TSTAMP_TRANS,6);

   
/*
EXEC SQL PREPARE DI2 FROM :FINU_INSERT;
*/

{
#line 3999 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 3999 "CXOSD206.sqx"
  sqlastls( *(unsigned short *)&FINU_INSERT,(const char*)&FINU_INSERT+2,0L);
#line 3999 "CXOSD206.sqx"
  sqlacall((unsigned short)27,3,0,0,0L);
#line 3999 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 3999 "CXOSD206.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         return UDBAddFinancialCommand::INSERT_FIN_RECORD;
         break;
      case -204:
      case  204:
      case -205:
      case -206:
      case  206:
      case -289:
      case -818:
      case -904:
         nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
         break;
      case -911:
      case -913:
         nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
         Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            return UDBAddFinancialCommand::INSERT_FIN_RECORD;
         }
         else
         {
            UseCase::add("PREPARE");
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,
    "prepareMonthlyFinancial");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::prepareMonthlyFinancial%4915EAB1038B.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::prepareMonthlyUpdateFinancial ()
{
  //## begin dndb2database::UDBAddFinancialCommand::prepareMonthlyUpdateFinancial%4915EAB10399.body preserve=yes
   State nState;
   char* p = strstr(FINU_UPDATE.data,"FIN_RECORD");
   if (!memcmp(p + 10,FR_TSTAMP_TRANS,6))
      return UDBAddFinancialCommand::UPDATE_FIN_RECORD;
   memcpy(p + 10,FR_TSTAMP_TRANS,6);

   
/*
EXEC SQL PREPARE D2U2 FROM :FINU_UPDATE;
*/

{
#line 4055 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 4055 "CXOSD206.sqx"
  sqlastls( *(unsigned short *)&FINU_UPDATE,(const char*)&FINU_UPDATE+2,0L);
#line 4055 "CXOSD206.sqx"
  sqlacall((unsigned short)27,8,0,0,0L);
#line 4055 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 4055 "CXOSD206.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         return UDBAddFinancialCommand::UPDATE_FIN_RECORD;
      case -204:
      case  204:
      case -205:
      case -206:
      case  206:
      case -289:
      case -818:
      case -904:
         nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
         break;
      case -911:
      case -913:
         nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
         Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            return UDBAddFinancialCommand::UPDATE_FIN_RECORD;
         }
         else
         {
            UseCase::add("PREPARE");
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,
    "prepareMonthlyUpdateFinancial");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::prepareMonthlyUpdateFinancial%4915EAB10399.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::prepareMultipleRoute ()
{
  //## begin dndb2database::UDBAddFinancialCommand::prepareMultipleRoute%5486201D03B3.body preserve=yes
   char* p = strstr(FM_INSERT.data,"FIN_ROUTE");
   if (!memcmp(p + 9,FR_TSTAMP_TRANS,6))
      return UDBAddFinancialCommand::INSERT_MULTIPLE_ROUTE;
   memcpy(p + 9,FR_TSTAMP_TRANS,6);
   State nState;
   
/*
EXEC SQL PREPARE DI5 FROM :FM_INSERT;
*/

{
#line 4109 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 4109 "CXOSD206.sqx"
  sqlastls( *(unsigned short *)&FM_INSERT,(const char*)&FM_INSERT+2,0L);
#line 4109 "CXOSD206.sqx"
  sqlacall((unsigned short)27,7,0,0,0L);
#line 4109 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 4109 "CXOSD206.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         return UDBAddFinancialCommand::INSERT_MULTIPLE_ROUTE;
      case -204:
      case  204:
      case -205:
      case -206:
      case  206:
      case -289:
      case -818:
      case -904:
         nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
         break;
      case -911:
      case -913:
         nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
         Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            nState = UDBAddFinancialCommand::INSERT_MULTIPLE_ROUTE;
         }
         else
         {
            UseCase::add("PREPARE");
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,
      "prepareMultipleRoute");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::prepareMultipleRoute%5486201D03B3.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::prepareSelect ()
{
  //## begin dndb2database::UDBAddFinancialCommand::prepareSelect%4915EAB103A9.body preserve=yes
   char* p = strstr(FL_SELECT.data,"FIN_L");
   if (!memcmp(p + 5,FR_TSTAMP_TRANS,6))
      return UDBAddFinancialCommand::SELECT_FIN_L;
   string strSQL1(FL_SELECT.data,FL_SELECT.length);
   string strSQL2(strSQL1);
   size_t nPos = string::npos;

   State nState = UDBAddFinancialCommand::PREPARE_SELECT_FIN_L;
   while (nState == UDBAddFinancialCommand::PREPARE_SELECT_FIN_L
      || nState == UDBAddFinancialCommand::PREPARE_RETRY)
   {
      memcpy(p + 5,FR_TSTAMP_TRANS,6);

      
/*
EXEC SQL PREPARE D2S2 FROM :FL_SELECT;
*/

{
#line 4171 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 4171 "CXOSD206.sqx"
  sqlastls( *(unsigned short *)&FL_SELECT,(const char*)&FL_SELECT+2,0L);
#line 4171 "CXOSD206.sqx"
  sqlacall((unsigned short)27,2,0,0,0L);
#line 4171 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 4171 "CXOSD206.sqx"


      if ((nPos = strSQL1.find("AND TRAN_TYPE_ID = ?")) != string::npos)
         strSQL1.erase(nPos,21);
      memcpy(FL_SELECT.data,strSQL1.data(),strSQL1.length());
      FL_SELECT.length = strSQL1.length();
      memcpy(p + 5,FR_TSTAMP_TRANS,6);

      
/*
EXEC SQL PREPARE D2S1 FROM :FL_SELECT;
*/

{
#line 4179 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 4179 "CXOSD206.sqx"
  sqlastls( *(unsigned short *)&FL_SELECT,(const char*)&FL_SELECT+2,0L);
#line 4179 "CXOSD206.sqx"
  sqlacall((unsigned short)27,1,0,0,0L);
#line 4179 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 4179 "CXOSD206.sqx"


      memcpy(FL_SELECT.data,strSQL2.data(),strSQL2.length());
      FL_SELECT.length = strSQL2.length();
      switch (sqlca.sqlcode)
      {
         case 0:
            return UDBAddFinancialCommand::SELECT_FIN_L;
         case -204:
         case  204:
            if (nState == UDBAddFinancialCommand::PREPARE_SELECT_FIN_L)
            {
               m_strTSTAMP_TRANS.assign(FR_TSTAMP_TRANS,16);
               FinancialBaseSegment::instance()->setTSTAMP_TRANS(Clock::instance()->getYYYYMMDDHHMMSSHN(true).data(),16);
               memcpy(FR_TSTAMP_TRANS,FinancialBaseSegment::instance()->zTSTAMP_TRANS(),sizeof(FR_TSTAMP_TRANS));
               FR_INSERT_SEQUENCE_NO = 0;
               nState = UDBAddFinancialCommand::PREPARE_RETRY;
               break;
            }
         case -205:
         case -206:
         case  206:
         case -289:
         case -818:
         case -904:
            nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
            break;
         case -911:
         case -913:
            nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
            break;
         case -900:
         case -923:
         case -924:
         case -991:
         case -1024:
            nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
            break;
         default:
            if (sqlca.sqlcode > 0)
               nState = UDBAddFinancialCommand::SELECT_FIN_L;
            else
            {
               UseCase::add("PREPARE");
               nState = UDBAddFinancialCommand::DATABASE_FAILURE;
               Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
            }
      }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,"prepareSelect");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::prepareSelect%4915EAB103A9.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::prepareUpdate ()
{
  //## begin dndb2database::UDBAddFinancialCommand::prepareUpdate%4915EAB103AA.body preserve=yes
   string strSQL;
   if (m_bUpdate)
   {
      strSQL = "UPDATE ";
      strSQL += Database::instance()->qualifier();
      strSQL += ".FIN_LOCATOR"
         " SET ACCT_ID_1 = ?,AMT_RECON_NET = ?,"
         "CUR_RECON_NET = ?,FUNC_CODE = ?,MERCH_TYPE = ?,"
         "DATE_RECON_ACQ = ?,DATE_RECON_ISS = ?,"
         "PAN_TOKEN = ?,CARD_ACPT_BUS_CODE = ?,"
         "COUNTRY_ACQ_INST = ?,TRAN_DISPOSITION = ?,"
         "CARD_ACPT_ID = ?,POS_CRD_DAT_IN_MOD = ?,ACT_CODE = ?,"
         "APPROVAL_CODE = ?,AUTH_BY = ?,CARD_ACPT_TERM_ID = ?,"
         "FIN_TYPE = ?,INST_ID_ACQ = ?,INST_ID_ISS = ?,"
         "INST_ID_RECN_ACQ_B = ?,INST_ID_RECN_ISS_B = ?,"
         "INST_ID_RECON_ACQ = ?,INST_ID_RECON_ISS = ?,"
         "MAPPED_DUP_DATA = ?,NET_TERM_ID = ?,PAN = ?,"
         "PROC_GRP_ID_ACQ_B = ?,PROC_GRP_ID_ISS_B = ?,"
         "PROC_ID_ACQ = ?,PROC_ID_ACQ_B = ?,PROC_ID_ISS = ?,"
         "PROC_ID_ISS_B = ?,"
         "RETRIEVAL_REF_NO = ?,RPT_LVL_ID_B = ?,SUBSCRIBER_IND = ?,"
         "SYS_TRACE_AUDIT_NO = ?,TRAN_CLASS = ?,TRAN_TYPE_ID = ?,"
         "TSTAMP_LOCAL = ?, "
         "PAN_PREFIX = ?, "
         "INV_ORDER_NO = ?, "
         "PAN_SUFFIX = ?, "
         "PAN_TOKEN_PREFIX = ?, "
         "PAN_TOKEN_SUFFIX = ?, "
         "TRANSACTION_ID = ?"
         " WHERE TSTAMP_TRANS = ?"
         " AND UNIQUENESS_KEY = ?";
   }
   else
   {
      strSQL = "UPDATE ";
      strSQL += Database::instance()->qualifier();
      strSQL += ".FIN_LOCATOR"
         " SET ACCT_ID_1 = ?,FIN_TYPE = ?"
         " WHERE TSTAMP_TRANS = ?"
         " AND UNIQUENESS_KEY = ?";
   }
   memcpy(FL_UPDATE.data,strSQL.data(),strSQL.length());
   FL_UPDATE.length = strSQL.length();
   char* p = strstr(FL_UPDATE.data,"FIN_L");
   State nState = UDBAddFinancialCommand::PREPARE_UPDATE_FIN_L;
   while (nState == UDBAddFinancialCommand::PREPARE_UPDATE_FIN_L
      || nState == UDBAddFinancialCommand::PREPARE_RETRY)
   {
      memcpy(p + 5,FR_TSTAMP_TRANS,6);

      
/*
EXEC SQL PREPARE D2U1 FROM :FL_UPDATE;
*/

{
#line 4287 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 4287 "CXOSD206.sqx"
  sqlastls( *(unsigned short *)&FL_UPDATE,(const char*)&FL_UPDATE+2,0L);
#line 4287 "CXOSD206.sqx"
  sqlacall((unsigned short)27,9,0,0,0L);
#line 4287 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 4287 "CXOSD206.sqx"


      switch (sqlca.sqlcode)
      {
         case 0:
            return UDBAddFinancialCommand::UPDATE_FIN_L;
         case -204:
         case  204:
            if (nState == UDBAddFinancialCommand::PREPARE_UPDATE_FIN_L)
            {
               m_strTSTAMP_TRANS.assign(FR_TSTAMP_TRANS,16);
               FinancialBaseSegment::instance()->setTSTAMP_TRANS(Clock::instance()->getYYYYMMDDHHMMSSHN(true).data(),16);
               memcpy(FR_TSTAMP_TRANS,FinancialBaseSegment::instance()->zTSTAMP_TRANS(),sizeof(FR_TSTAMP_TRANS));
               FR_INSERT_SEQUENCE_NO = 0;
               nState = UDBAddFinancialCommand::PREPARE_RETRY;
               break;
            }
         case -205:
         case -206:
         case  206:
         case -289:
         case -818:
         case -904:
            nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
            break;
         case -911:
         case -913:
            nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
            break;
         case -900:
         case -923:
         case -924:
         case -991:
         case -1024:
            nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
            break;
         default:
            if (sqlca.sqlcode > 0)
               nState = UDBAddFinancialCommand::UPDATE_FIN_L;
            else
            {
               UseCase::add("PREPARE");
               nState = UDBAddFinancialCommand::DATABASE_FAILURE;
               Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
            }
      }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,"prepareUpdate");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::prepareUpdate%4915EAB103AA.body
}

void UDBAddFinancialCommand::resetAdjustmentHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::resetAdjustmentHost%4915EAB103B9.body preserve=yes
   FR_BRANCH_ID_ACQ[0] = '\0';
   FR_CNTRY_REC_INST_ADJ[0] = '\0';
   FR_CNTRY_REQ_INST_ADJ[0] = '\0';
   FR_INST_ID_REC_ADJ[0] = '\0';
   FR_INST_ID_REQ_ADJ[0] = '\0';
   FR_NET_IND_ADJ[0] = '\0';
   FR_ORIG_AMT_TRAN_ADJ = 0;
   FR_REQ_ACQ_ISS_IND[0] = '\0';
   FR_TRACE_DATA_ADJ[0] = '\0';
   FR_TSTAMP_LOCAL_ADJ[0] = '\0';
   FR_TSTAMP_TRANS_ADJ[0] = '\0';
  //## end dndb2database::UDBAddFinancialCommand::resetAdjustmentHost%4915EAB103B9.body
}

void UDBAddFinancialCommand::resetAdjustmentExtensionHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::resetAdjustmentExtensionHost%4915EAB103C8.body preserve=yes
   FR_EXTENSION_DATA_ADJ.FR_EXTENSION_DATA_ADJ_len = 0;
  //## end dndb2database::UDBAddFinancialCommand::resetAdjustmentExtensionHost%4915EAB103C8.body
}

void UDBAddFinancialCommand::resetFeeHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::resetFeeHost%4915EAB103C9.body preserve=yes
   FR_ADTL_DATA_FEE.FR_ADTL_DATA_FEE_len = 0;
   FR_ISS_ACQ_TYPE_FEE[0] = '\0';
   FR_NET_UNIQUE_DAT_FEE.FR_NET_UNIQUE_DAT_FEE_len = 0;
  //## end dndb2database::UDBAddFinancialCommand::resetFeeHost%4915EAB103C9.body
}

void UDBAddFinancialCommand::resetICCHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::resetICCHost%49171A0001E4.body preserve=yes
   FI_AMOUNT_OTHER[0] = '\0';
   FI_APPL_CRYPTOGRAM[0] = '\0';
   FI_APPL_ID[0] = '\0';
   FI_APPL_INTRCHG_PROF[0] = '\0';
   FI_APPL_TRAN_COUNTER[0] = '\0';
   FI_APPL_VERSION_NO[0] = '\0';
   FI_CARDH_VER_RESULT[0] = '\0';
   FI_CHIP_TOKEN_REQ_ID[0] = '\0';
   FI_COPAC_CCS_CRYPTO[0] = '\0';
   FI_CRYPTOGRAM_AMOUNT[0] = '\0';
   FI_CRYPT_INFO_DATA[0] = '\0';
   FI_DEDICATED_FILE_NAM[0] = '\0';
   FI_FORM_FACTOR_IND[0] = '\0';
   FI_ISS_APPL_DATA[0] = '\0';
   FI_ISS_AUTH_DATA[0] = '\0';
   FI_ISS_DISCR_DATA[0] = '\0';
   FI_ISS_SCRIPT1_DATA[0] = '\0';
   FI_ISS_SCRIPT2_DATA[0] = '\0';
   FI_ISS_SCRIPT_RESULT[0] = '\0';
   FI_TERM_CAPABILITIES[0] = '\0';
   FI_TERM_COUNTRY_CODE[0] = '\0';
   FI_TERM_SERIAL_NO[0] = '\0';
   FI_TERM_VERIFY_RESULT[0] = '\0';
   FI_TERMINAL_TYPE[0] = '\0';
   FI_TRAN_CATEGORY_CODE[0] = '\0';
   FI_TRAN_CURRENCY_CODE[0] = '\0';
   FI_TRAN_DATE[0] = '\0';
   FI_TRAN_SEQ_COUNTER[0] = '\0';
   FI_TRAN_TYPE[0] = '\0';
   FI_UNPREDICTABLE_NO[0] = '\0';
   FI_DERIVATION_KEY_IDX[0] = '\0';
   FI_ARPC_CRYPTOGRAM[0] = '\0';
   FI_ARPC_RESPCODE[0] = '\0';
  //## end dndb2database::UDBAddFinancialCommand::resetICCHost%49171A0001E4.body
}

void UDBAddFinancialCommand::resetMultipleRouteHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::resetMultipleRouteHost%548620380345.body preserve=yes
   FM_PRIMARY_PROC_ID[0] = '\0';
   FM_PRIMARY_PROCESS_ID[0] = '\0';
   FM_PRIMARY_TD_PROCESS_ID[0] = '\0';
   FM_PRIMARY_TD_MATCH_OPT[0]= '\0';
   FM_PROC_ID[0] = '\0';
   FM_PROCESS_ID[0] = '\0';
   FM_TD_PROCESS_ID[0] = '\0';
   FM_TD_MATCH_OPT[0] = '\0';
   FM_MULTI_RTE_OPT[0] = '\0';
   FM_STANDIN_IND[0] = '\0';
   FM_COMPLETION_IND[0] = '\0';
   FM_ADVICE_IND[0] = '\0';
   FM_DENY_OPT[0] = '\0';
   FM_PREAUTH_IND[0] = '\0';
   FM_REQUEST_BAL_IND[0] = '\0';
   FM_RESPONSE_BAL_IND[0] = '\0';
   FM_APPROVED_BY[0] = '\0';
   FM_ADVICE_TRAN[0] = '\0';
   FM_TDRESP[0] = '\0';
   FM_UNIQUENESS_KEY = 0;
  //## end dndb2database::UDBAddFinancialCommand::resetMultipleRouteHost%548620380345.body
}

void UDBAddFinancialCommand::resetReversalHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::resetReversalHost%4915EAB103D8.body preserve=yes
   FR_FO_AMT_RECON_ACQ0 = 0;
   FR_FO_AMT_RECON_ACQ1 = 0;
   FR_FO_AMT_RECON_ACQ2 = 0;
   FR_FO_AMT_RECON_ACQ3 = 0;
   FR_FO_AMT_RECON_ACQ4 = 0;
   FR_FO_AMT_RECON_ACQ5 = 0;
   FR_FO_AMT_RECON_ISS0 = 0;
   FR_FO_AMT_RECON_ISS1 = 0;
   FR_FO_AMT_RECON_ISS2 = 0;
   FR_FO_AMT_RECON_ISS3 = 0;
   FR_FO_AMT_RECON_ISS4 = 0;
   FR_FO_AMT_RECON_ISS5 = 0;
   FR_FO_AMT_RECON_NET0 = 0;
   FR_FO_AMT_RECON_NET1 = 0;
   FR_FO_AMT_RECON_NET2 = 0;
   FR_FO_AMT_RECON_NET3 = 0;
   FR_FO_AMT_RECON_NET4 = 0;
   FR_FO_AMT_RECON_NET5 = 0;
   FR_FO_AMT0 = 0;
   FR_FO_AMT1 = 0;
   FR_FO_AMT2 = 0;
   FR_FO_AMT3 = 0;
   FR_FO_AMT4 = 0;
   FR_FO_AMT5 = 0;
   FR_FO_CNV_ACQ_DE_POS0 = 0;
   FR_FO_CNV_ACQ_DE_POS1 = 0;
   FR_FO_CNV_ACQ_DE_POS2 = 0;
   FR_FO_CNV_ACQ_DE_POS3 = 0;
   FR_FO_CNV_ACQ_DE_POS4 = 0;
   FR_FO_CNV_ACQ_DE_POS5 = 0;
   FR_FO_CNV_ACQ_RATE0 = 0;
   FR_FO_CNV_ACQ_RATE1 = 0;
   FR_FO_CNV_ACQ_RATE2 = 0;
   FR_FO_CNV_ACQ_RATE3 = 0;
   FR_FO_CNV_ACQ_RATE4 = 0;
   FR_FO_CNV_ACQ_RATE5 = 0;
   FR_FO_CNV_ISS_DE_POS0 = 0;
   FR_FO_CNV_ISS_DE_POS1 = 0;
   FR_FO_CNV_ISS_DE_POS2 = 0;
   FR_FO_CNV_ISS_DE_POS3 = 0;
   FR_FO_CNV_ISS_DE_POS4 = 0;
   FR_FO_CNV_ISS_DE_POS5 = 0;
   FR_FO_CNV_ISS_RATE0 = 0;
   FR_FO_CNV_ISS_RATE1 = 0;
   FR_FO_CNV_ISS_RATE2 = 0;
   FR_FO_CNV_ISS_RATE3 = 0;
   FR_FO_CNV_ISS_RATE4 = 0;
   FR_FO_CNV_ISS_RATE5 = 0;
   FR_FO_CUR_CODE0[0] = '\0';
   FR_FO_CUR_CODE1[0] = '\0';
   FR_FO_CUR_CODE2[0] = '\0';
   FR_FO_CUR_CODE3[0] = '\0';
   FR_FO_CUR_CODE4[0] = '\0';
   FR_FO_CUR_CODE5[0] = '\0';
   FR_FO_CUR_RECON_ACQ0[0] = '\0';
   FR_FO_CUR_RECON_ACQ1[0] = '\0';
   FR_FO_CUR_RECON_ACQ2[0] = '\0';
   FR_FO_CUR_RECON_ACQ3[0] = '\0';
   FR_FO_CUR_RECON_ACQ4[0] = '\0';
   FR_FO_CUR_RECON_ACQ5[0] = '\0';
   FR_FO_CUR_RECON_ISS0[0] = '\0';
   FR_FO_CUR_RECON_ISS1[0] = '\0';
   FR_FO_CUR_RECON_ISS2[0] = '\0';
   FR_FO_CUR_RECON_ISS3[0] = '\0';
   FR_FO_CUR_RECON_ISS4[0] = '\0';
   FR_FO_CUR_RECON_ISS5[0] = '\0';
   FR_FO_DEC_POS0 = 0;
   FR_FO_DEC_POS1 = 0;
   FR_FO_DEC_POS2 = 0;
   FR_FO_DEC_POS3 = 0;
   FR_FO_DEC_POS4 = 0;
   FR_FO_DEC_POS5 = 0;
   FR_FO_INITIATOR0[0] = '\0';
   FR_FO_INITIATOR1[0] = '\0';
   FR_FO_INITIATOR2[0] = '\0';
   FR_FO_INITIATOR3[0] = '\0';
   FR_FO_INITIATOR4[0] = '\0';
   FR_FO_INITIATOR5[0] = '\0';
   FR_FO_MEMO0[0] = '\0';
   FR_FO_MEMO1[0] = '\0';
   FR_FO_MEMO2[0] = '\0';
   FR_FO_MEMO3[0] = '\0';
   FR_FO_MEMO4[0] = '\0';
   FR_FO_MEMO5[0] = '\0';
   FR_FO_TYPE0[0] = '\0';
   FR_FO_TYPE1[0] = '\0';
   FR_FO_TYPE2[0] = '\0';
   FR_FO_TYPE3[0] = '\0';
   FR_FO_TYPE4[0] = '\0';
   FR_FO_TYPE5[0] = '\0';
   FR_O_AMT_CARD_BILL = 0;
   FR_O_AMT_RECON_ACQ = 0;
   FR_O_AMT_RECON_ISS = 0;
   FR_O_AMT_RECON_NET = 0;
   FR_O_AMT_TRAN = 0;
   FR_ODE_INST_ID_ACQ[0] = '\0';
   FR_ODE_MTI[0] = '\0';
   FR_ODE_SYS_TRA_AUD_NO[0] = '\0';
   FR_ODE_TSTAMP_LOCL_TR[0] = '\0';
   FR_TSTAMP_REV_CREATED[0] = '\0';
  //## end dndb2database::UDBAddFinancialCommand::resetReversalHost%4915EAB103D8.body
}

void UDBAddFinancialCommand::resetSettlementHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::resetSettlementHost%4915EAB20000.body preserve=yes
   FR_ACCT_QUAL_1[0] = '\0';
   FR_ACCT_QUAL_2[0] = '\0';
   FR_ADL_DATA_NATIONAL.FR_ADL_DATA_NATIONAL_data[0] = '\0';
   FR_ADL_DATA_NATIONAL.FR_ADL_DATA_NATIONAL_len = 0;
   FR_ADL_DATA_PRIV_ACQ.FR_ADL_DATA_PRIV_ACQ_data[0] = '\0';
   FR_ADL_DATA_PRIV_ACQ.FR_ADL_DATA_PRIV_ACQ_len = 0;
   FR_ADL_DATA_PRIV_ISS.FR_ADL_DATA_PRIV_ISS_data[0] = '\0';
   FR_ADL_DATA_PRIV_ISS.FR_ADL_DATA_PRIV_ISS_len = 0;
   FR_ADL_RESP_DATA.FR_ADL_RESP_DATA_data[0] = '\0';
   FR_ADL_RESP_DATA.FR_ADL_RESP_DATA_len = 0;
   FR_AMT_RECON_ACQ = 0;
   FR_AMT_RECON_ISS = 0;
   FR_AP_FLG[0] = '\0';
   FR_BIN_EXCLUSION_GRP[0] = '\0';
   FR_CAN_ITEM_VALUE0 = 0;
   FR_CAN_ITEM_VALUE1 = 0;
   FR_CAN_ITEM_VALUE2 = 0;
   FR_CAN_ITEM_VALUE3 = 0;
   FR_CAN_ITEM_VALUE4 = 0;
   FR_CAN_ITEM_VALUE5 = 0;
   FR_CAN_ITEM_VALUE6 = 0;
   FR_CAN_ITEM_VALUE7 = 0;
   FR_CAN_NO_ITEMS_DISP0 = 0;
   FR_CAN_NO_ITEMS_DISP1 = 0;
   FR_CAN_NO_ITEMS_DISP2 = 0;
   FR_CAN_NO_ITEMS_DISP3 = 0;
   FR_CAN_NO_ITEMS_DISP4 = 0;
   FR_CAN_NO_ITEMS_DISP5 = 0;
   FR_CAN_NO_ITEMS_DISP6 = 0;
   FR_CAN_NO_ITEMS_DISP7 = 0;
   FR_CAN_ORIG_NO_ITEMS0 = 0;
   FR_CAN_ORIG_NO_ITEMS1 = 0;
   FR_CAN_ORIG_NO_ITEMS2 = 0;
   FR_CAN_ORIG_NO_ITEMS3 = 0;
   FR_CAN_ORIG_NO_ITEMS4 = 0;
   FR_CAN_ORIG_NO_ITEMS5 = 0;
   FR_CAN_ORIG_NO_ITEMS6 = 0;
   FR_CAN_ORIG_NO_ITEMS7 = 0;
   FR_CARD_ACPT_ID[0] = '\0';
   FR_CARD_INTRCHG_ID[0] = '\0';
   FR_CARD_LOGO_ID[0] = '\0';
   FR_CARD_OWNER[0] = '\0';
   FR_CARD_TYPE[0] = '\0';
   FR_CAVV_RESULT[0] = '\0';
   FR_CNV_CRD_BIL_DE_POS = 0;
   FR_CNV_CRD_BIL_RATE = 0;
   FR_CNV_RCN_ACQ_DE_POS = 0;
   FR_CNV_RCN_ACQ_RATE = 0;
   FR_CNV_RCN_ISS_DE_POS = 0;
   FR_CNV_RCN_ISS_RATE = 0;
   FR_CNV_RCN_NET_DE_POS = 0;
   FR_CNV_RCN_NET_RATE = 0;
   FR_CRD_ACP_NAM_FMTFLG[0] = '\0';
   FR_CUR_RECON_ACQ[0] = '\0';
   FR_CUR_RECON_ISS[0] = '\0';
   FR_CUR_TYPE = 0;
   FR_CVV_CVC_RESULT[0] = '\0';
   FR_CVV2_CVC2_RESULT[0] = '\0';
   FR_DATA_PRIV_ACQ.FR_DATA_PRIV_ACQ_data[0] = '\0';
   FR_DATA_PRIV_ACQ.FR_DATA_PRIV_ACQ_len = 0;
   FR_DATA_PRIV_ACQ_FMT = 0;
   FR_DATA_PRIV_ISS.FR_DATA_PRIV_ISS_data[0] = '\0';
   FR_DATA_PRIV_ISS.FR_DATA_PRIV_ISS_len = 0;
   FR_DATA_PRIV_ISS_FMT = 0;
   FR_DATE_EXP[0] = '\0';
   FR_DATE_RECON_ISS[0] = '\0';
   FR_DRAFT_CAPTURE_FLG[0] = '\0';
   FR_EXCHG_MASTER[0] = '\0';
   FR_EXCHG_SETL[0] = '\0';
   FR_F_ADL_DEC_POS0 = 0;
   FR_F_ADL_DEC_POS1 = 0;
   FR_F_ADL_DEC_POS2 = 0;
   FR_F_ADL_DEC_POS3 = 0;
   FR_F_ADL_DEC_POS4 = 0;
   FR_F_ADL_DEC_POS5 = 0;
   FR_F_AMT0 = 0;
   FR_F_AMT1 = 0;
   FR_F_AMT2 = 0;
   FR_F_AMT3 = 0;
   FR_F_AMT4 = 0;
   FR_F_AMT5 = 0;
   FR_F_AMT_RECON_ACQ0 = 0;
   FR_F_AMT_RECON_ACQ1 = 0;
   FR_F_AMT_RECON_ACQ2 = 0;
   FR_F_AMT_RECON_ACQ3 = 0;
   FR_F_AMT_RECON_ACQ4 = 0;
   FR_F_AMT_RECON_ACQ5 = 0;
   FR_F_AMT_RECON_ISS0 = 0;
   FR_F_AMT_RECON_ISS1 = 0;
   FR_F_AMT_RECON_ISS2 = 0;
   FR_F_AMT_RECON_ISS3 = 0;
   FR_F_AMT_RECON_ISS4 = 0;
   FR_F_AMT_RECON_ISS5 = 0;
   FR_F_AMT_RECON_NET0 = 0;
   FR_F_AMT_RECON_NET1 = 0;
   FR_F_AMT_RECON_NET2 = 0;
   FR_F_AMT_RECON_NET3 = 0;
   FR_F_AMT_RECON_NET4 = 0;
   FR_F_AMT_RECON_NET5 = 0;
   FR_F_CNV_ACQ_DEC_POS0 = 0;
   FR_F_CNV_ACQ_DEC_POS1 = 0;
   FR_F_CNV_ACQ_DEC_POS2 = 0;
   FR_F_CNV_ACQ_DEC_POS3 = 0;
   FR_F_CNV_ACQ_DEC_POS4 = 0;
   FR_F_CNV_ACQ_DEC_POS5 = 0;
   FR_F_CNV_ACQ_RATE0 = 0;
   FR_F_CNV_ACQ_RATE1 = 0;
   FR_F_CNV_ACQ_RATE2 = 0;
   FR_F_CNV_ACQ_RATE3 = 0;
   FR_F_CNV_ACQ_RATE4 = 0;
   FR_F_CNV_ACQ_RATE5 = 0;
   FR_F_CNV_ISS_DEC_POS0 = 0;
   FR_F_CNV_ISS_DEC_POS1 = 0;
   FR_F_CNV_ISS_DEC_POS2 = 0;
   FR_F_CNV_ISS_DEC_POS3 = 0;
   FR_F_CNV_ISS_DEC_POS4 = 0;
   FR_F_CNV_ISS_DEC_POS5 = 0;
   FR_F_CNV_ISS_RATE0 = 0;
   FR_F_CNV_ISS_RATE1 = 0;
   FR_F_CNV_ISS_RATE2 = 0;
   FR_F_CNV_ISS_RATE3 = 0;
   FR_F_CNV_ISS_RATE4 = 0;
   FR_F_CNV_ISS_RATE5 = 0;
   FR_F_CUR_CODE0[0] = '\0';
   FR_F_CUR_CODE1[0] = '\0';
   FR_F_CUR_CODE2[0] = '\0';
   FR_F_CUR_CODE3[0] = '\0';
   FR_F_CUR_CODE4[0] = '\0';
   FR_F_CUR_CODE5[0] = '\0';
   FR_F_CUR_RECON_ACQ0[0] = '\0';
   FR_F_CUR_RECON_ACQ1[0] = '\0';
   FR_F_CUR_RECON_ACQ2[0] = '\0';
   FR_F_CUR_RECON_ACQ3[0] = '\0';
   FR_F_CUR_RECON_ACQ4[0] = '\0';
   FR_F_CUR_RECON_ACQ5[0] = '\0';
   FR_F_CUR_RECON_ISS0[0] = '\0';
   FR_F_CUR_RECON_ISS1[0] = '\0';
   FR_F_CUR_RECON_ISS2[0] = '\0';
   FR_F_CUR_RECON_ISS3[0] = '\0';
   FR_F_CUR_RECON_ISS4[0] = '\0';
   FR_F_CUR_RECON_ISS5[0] = '\0';
   FR_F_INITIATOR0[0] = '\0';
   FR_F_INITIATOR1[0] = '\0';
   FR_F_INITIATOR2[0] = '\0';
   FR_F_INITIATOR3[0] = '\0';
   FR_F_INITIATOR4[0] = '\0';
   FR_F_INITIATOR5[0] = '\0';
   FR_F_MEMO0[0] = '\0';
   FR_F_MEMO1[0] = '\0';
   FR_F_MEMO2[0] = '\0';
   FR_F_MEMO3[0] = '\0';
   FR_F_MEMO4[0] = '\0';
   FR_F_MEMO5[0] = '\0';
   FR_F_TYPE0[0] = '\0';
   FR_F_TYPE1[0] = '\0';
   FR_F_TYPE2[0] = '\0';
   FR_F_TYPE3[0] = '\0';
   FR_F_TYPE4[0] = '\0';
   FR_F_TYPE5[0] = '\0';
   FR_HOST_RECV_FLG[0] = '\0';
   FR_HOST_SENT_FLG[0] = '\0';
   FR_INST_TIER[0] = '\0';
   FR_MCI_AAV_RESULT_COD[0] = '\0';
   FR_MCI_ECS_LVL_IND[0] = '\0';
   FR_MCI_UCAF_DATA[0] = '\0';
   FR_MTI[0] = '\0';
   FR_NET_INTRCHG_TIER[0] = '\0';
   FR_OAR_RQST_FLG[0] = '\0';
   FR_PAYEE[0] = '\0';
   FR_PIN_FLG[0] = '\0';
   FR_MULTI_CLEAR_SEQ_NO[0] = '\0';
   FR_MULTI_CLEAR_COUNT[0] = '\0';
   FR_POS_CARD_CAPT_CAP[0] = '\0';
   FR_POS_CARD_PRES[0] = '\0';
   FR_POS_CRDHLDR_AUTH[0] = '\0';
   FR_POS_CRDHLDR_AUTH_C[0] = '\0';
   FR_POS_CRDHLDR_PRESNT[0] = '\0';
   FR_POS_CRD_DAT_IN_CAP[0] = '\0';
   FR_POS_CRD_DAT_IN_MOD[0] = '\0';
   FR_POS_CRD_DAT_OT_CAP[0] = '\0';
   FR_POS_OPER_ENV[0] = '\0';
   FR_POS_PIN_CAPT_CAP[0] = '\0';
   FR_POS_TERM_OUT_CAP[0] = '\0';
   FR_PRINT_MASK_ID[0] = '\0';
   FR_PROGRAM_ID[0] = '\0';
   FR_ACQ_ROUTING_NO[0] = '\0';
   FR_ISS_ROUTING_NO[0] = '\0';
   FR_TRANS_ROUTING_NO[0] = '\0';
   FR_DEST_ROUTING_NO[0] = '\0';
   FR_AUTH_LCYCLE_TRACE[0] = '\0';
   FR_REF_DATA_ACQ.FR_REF_DATA_ACQ_data[0] = '\0';
   FR_REF_DATA_ACQ.FR_REF_DATA_ACQ_len = 0;
   FR_REF_DATA_ACQ_FMT = 0;
   FR_REF_DATA_ISS.FR_REF_DATA_ISS_data[0] = '\0';
   FR_REF_DATA_ISS.FR_REF_DATA_ISS_len = 0;
   FR_REF_DATA_ISS_FMT = 0;
   FR_TERM_CLASS[0] = '\0';
   FR_TIME_AT_AP = 0;
   FR_TIME_AT_ISS = 0;
   FR_TIME_AT_RESP_QUE = 0;
   FR_TIME_AT_RESP_SWTCH = 0;
   FR_TIME_AT_RQST_QUE = 0;
   FR_TIME_AT_RQST_SWTCH = 0;
   FR_TRACK_2_DATA.FR_TRACK_2_DATA_data[0] = '\0';
   FR_TRACK_2_DATA.FR_TRACK_2_DATA_len = 0;
   FR_TRAN_DESC.FR_TRAN_DESC_data[0] = '\0';
   FR_TRAN_DESC.FR_TRAN_DESC_len = 0;
   FR_TRAN_UNIQUE_DATA.FR_TRAN_UNIQUE_DATA_data[0] = '\0';
   FR_TRAN_UNIQUE_DATA.FR_TRAN_UNIQUE_DATA_len = 0;
   FR_TRAN_UNIQ_DATA_FMT[0] = '\0';
   FR_MERCH_TIER_ID[0] = '\0';
   FR_BRIDGE_ACQ_FLG[0] = '\0';
   FR_BRIDGE_ISS_FLG[0] = '\0';
   FR_COOPER_SCORE[0] = '\0';
   FR_COOPER_REASON[0] = '\0';
   FR_AMX_FRAUD_DATA.FR_AMX_FRAUD_DATA_data[0] = '\0';
   FR_AMX_FRAUD_DATA.FR_AMX_FRAUD_DATA_len = 0;  
   FR_ISSUER_SCRIPT_FLG[0] = '\0';
   FR_FP_HOLD_MATCH_FLG[0] = '\0';
  //## end dndb2database::UDBAddFinancialCommand::resetSettlementHost%4915EAB20000.body
}

void UDBAddFinancialCommand::resetUserHost ()
{
  //## begin dndb2database::UDBAddFinancialCommand::resetUserHost%4915EAB2000F.body preserve=yes
   FR_ACCT_TYPE_1[0] = '\0';
   FR_ACCT_TYPE_2[0] = '\0';
   FR_ACCT_TYPE_3[0] = '\0';
   FR_ADL_RESP_ACCT_IDX0 = 0;
   FR_ADL_RESP_ACCT_IDX1 = 0;
   FR_ADL_RESP_ACCT_IDX2 = 0;
   FR_ADL_RESP_ACCT_IDX3 = 0;
   FR_ADL_RESP_ACCT_IDX4 = 0;
   FR_ADL_RESP_ACCT_IDX5 = 0;
   FR_ADL_RESP_ACCT_TYP0[0] = '\0';
   FR_ADL_RESP_ACCT_TYP1[0] = '\0';
   FR_ADL_RESP_ACCT_TYP2[0] = '\0';
   FR_ADL_RESP_ACCT_TYP3[0] = '\0';
   FR_ADL_RESP_ACCT_TYP4[0] = '\0';
   FR_ADL_RESP_ACCT_TYP5[0] = '\0';
   FR_ADL_RESP_AMT0 = 0;
   FR_ADL_RESP_AMT1 = 0;
   FR_ADL_RESP_AMT2 = 0;
   FR_ADL_RESP_AMT3 = 0;
   FR_ADL_RESP_AMT4 = 0;
   FR_ADL_RESP_AMT5 = 0;
   FR_ADL_RESP_AMT_TYP0[0] = '\0';
   FR_ADL_RESP_AMT_TYP1[0] = '\0';
   FR_ADL_RESP_AMT_TYP2[0] = '\0';
   FR_ADL_RESP_AMT_TYP3[0] = '\0';
   FR_ADL_RESP_AMT_TYP4[0] = '\0';
   FR_ADL_RESP_AMT_TYP5[0] = '\0';
   FR_ADL_RESP_CUR_CODE0[0] = '\0';
   FR_ADL_RESP_CUR_CODE1[0] = '\0';
   FR_ADL_RESP_CUR_CODE2[0] = '\0';
   FR_ADL_RESP_CUR_CODE3[0] = '\0';
   FR_ADL_RESP_CUR_CODE4[0] = '\0';
   FR_ADL_RESP_CUR_CODE5[0] = '\0';
   FR_ADL_RQST_ACCT_IDX0 = 0;
   FR_ADL_RQST_ACCT_IDX1 = 0;
   FR_ADL_RQST_ACCT_IDX2 = 0;
   FR_ADL_RQST_ACCT_IDX3 = 0;
   FR_ADL_RQST_ACCT_IDX4 = 0;
   FR_ADL_RQST_ACCT_IDX5 = 0;
   FR_ADL_RQST_ACCT_TYP0[0] = '\0';
   FR_ADL_RQST_ACCT_TYP1[0] = '\0';
   FR_ADL_RQST_ACCT_TYP2[0] = '\0';
   FR_ADL_RQST_ACCT_TYP3[0] = '\0';
   FR_ADL_RQST_ACCT_TYP4[0] = '\0';
   FR_ADL_RQST_ACCT_TYP5[0] = '\0';
   FR_ADL_RQST_AMT0 = 0;
   FR_ADL_RQST_AMT1 = 0;
   FR_ADL_RQST_AMT2 = 0;
   FR_ADL_RQST_AMT3 = 0;
   FR_ADL_RQST_AMT4 = 0;
   FR_ADL_RQST_AMT5 = 0;
   FR_ADL_RQST_AMT_TYP0[0] = '\0';
   FR_ADL_RQST_AMT_TYP1[0] = '\0';
   FR_ADL_RQST_AMT_TYP2[0] = '\0';
   FR_ADL_RQST_AMT_TYP3[0] = '\0';
   FR_ADL_RQST_AMT_TYP4[0] = '\0';
   FR_ADL_RQST_AMT_TYP5[0] = '\0';
   FR_ADL_RQST_CUR_CODE0[0] = '\0';
   FR_ADL_RQST_CUR_CODE1[0] = '\0';
   FR_ADL_RQST_CUR_CODE2[0] = '\0';
   FR_ADL_RQST_CUR_CODE3[0] = '\0';
   FR_ADL_RQST_CUR_CODE4[0] = '\0';
   FR_ADL_RQST_CUR_CODE5[0] = '\0';
   FR_ALT_ROUTE_FLG[0] = '\0';
   FR_AP_APPROVAL_CODE[0] = '\0';
   FR_AP_CARD_GRP[0] = '\0';
   FR_AP_DATA[0] = '\0';
   FR_AP_ERROR_NO = 0;
   FR_AP_ERROR_TRACE_LOC = 0;
   FR_AP_REJ_REASON_CODE = 0;
   FR_AUTH_LCYCLE_TCODE[0] = '\0';
   FR_AUTH_LIFECYCLE_INT = 0;
   FR_AUTH_RQST_TIMEOUT = 0;
   FR_BIN_LENGTH = 0;
   FR_CARD_ACPT_COUNTY[0] = '\0';
   FR_CARD_ACPT_SPNSR_ID[0] = '\0';
   FR_CARD_CAPT_FLG[0] = '\0';
   FR_CLERK_ID[0] = '\0';
   FR_CNTRY_RCN_ACQ_INST[0] = '\0';
   FR_CNTRY_RCN_ISS_INST[0] = '\0';
   FR_DATE_ACTION[0] = '\0';
   FR_DATE_CAPTURE[0] = '\0';
   FR_DATE_CNV_ACQ[0] = '\0';
   FR_DATE_CNV_ISS[0] = '\0';
   FR_DATE_EFFECTIVE[0] = '\0';
   FR_DATE_RECON_NET[0] = '\0';
   FR_DEPOSIT_ONLY_FLG[0] = '\0';
   FR_EXTENDED_PAY_DATA[0] = '\0';
   FR_PAN_INDICATOR[0] = '\0';
   FR_PAN_RANGE[0] = '\0';
   FR_PAN_TOKEN[0] = '\0';
   FR_PIN_DATA_FMT = 0;
   FR_PIN_RESULT = 0;
   FR_PMC_ERROR = 0;
   FR_PREAUTH_COMP_OPT = 0;
   FR_RECON_IND_ACQ[0] = '\0';
   FR_RESTRIC_INTCHG_GRP[0] = '\0';
   FR_SOURCE_ROUTE_ID[0] = '\0';
   FR_SRV_GRP_INTCHG_IND[0] = '\0';
   FR_SRV_GRP_SERV_CODE[0] = '\0';
   FR_STANDIN_ACT[0] = '\0';
   FR_STANDIN_OPTION[0] = '\0';
   FR_TOKEN_ASSURANCE[0] = '\0';
   FR_TOKEN_REQUESTOR_ID[0] = '\0';
   FR_TOKEN_EXP_DATE[0] = '\0';
   FR_TOKEN_REF_NUMBER[0] = '\0';
   FR_TOKEN_SER_PROVIDER[0] = '\0';
   FR_TOKEN_STATUS[0] = '\0';
   FR_TOKEN_TRANID.FR_TOKEN_TRANID_data[0] = '\0';
   FR_TOKEN_TRANID.FR_TOKEN_TRANID_len = 0;
   FR_TOKEN_TYPE[0] = '\0';
   FR_UNFORMATTED_MICR_DATA.FR_UNFORMATTED_MICR_DATA_data[0] = '\0';
   FR_UNFORMATTED_MICR_DATA.FR_UNFORMATTED_MICR_DATA_len = 0;
   FR_HCE_ACTIVATE_RESULT[0] = '\0';
   FR_AAM_VELOCITY_RESULT[0] = '\0';
   FR_LUK_ELAPSED_TIME = 0;
   FR_LUK_TRAN_COUNT = 0;
   FR_LUK_AMT_TRAN = 0;
   FR_TOKEN_DEVICE_TYPE[0] = '\0';
   FR_TOKEN_DEVICE_LOC[0] = '\0';
   FR_TOKEN_CARD_SEQ_NO[0] = '\0';
   FR_TOKEN_VERSION[0] = '\0';
   FR_NETWORK_PROGRAM[0] = '\0';
   FR_WEIGHTED_AVE_FLG[0] = '\0';
   FR_TOKEN_REF_NUMBER_EXT[0] = '\0';
   FR_ADDL_TRAN_DISP[0] = '\0';
   FR_ADDL_TRAN_RESULT.FR_ADDL_TRAN_RESULT_data[0] = '\0';
   FR_ADDL_TRAN_RESULT.FR_ADDL_TRAN_RESULT_len = 0;
   FR_SWIFT_CODE[0] = '\0';
   FR_IFSC_CODE[0] = '\0';
   FR_LOCAL_RETRIEVAL_REF_NO[0] = '\0';
   FR_TOKEN_ACT_CODE[0] = '\0';
   FR_TOKEN_STATUS_CODE[0] = '\0';
   FR_TOKEN_ISSUER_PROC[0] = '\0';
   FR_TOKEN_REQ_TSTAMP[0] = '\0';
   FR_TOKEN_RESP_TSTAMP[0] = '\0';
   FR_TOKEN_TIME_AT_TSP[0] = '\0';
   FR_VISA_ATM_TRAN_ID[0] = '\0';
   FR_DOMAIN_CTL_RESTR[0] = '\0';
   FR_PGRM_PROTOCOL[0] = '\0';
   FR_DIR_SERV_TRAN_ID[0] = '\0';
   FR_TRAN_INT_CLASS[0] = '\0';
   FR_ACL_ECOM_IND[0] = '\0';
   FR_P1C_ACCT_TOKEN[0] = '\0';
   FR_P1C_ADL_RESP_DATA[0] = '\0';
   FR_P1C_CRDHLDR_TOKEN[0] = '\0';
   FR_PRM_ADL_RESP_DATA[0] = '\0';
   FR_SAP_ADL_RESP_DATA[0] = '\0';
   FR_ECOM_DATA.FR_ECOM_DATA_data[0] = '\0';
   FR_ECOM_DATA.FR_ECOM_DATA_len = 0;
   FR_INST_ID_FRWD[0] = '\0';
   FR_TOKEN_DEVICE_NAME[0] = '\0';
   FR_TOKEN_ENTITY[0] = '\0';
   FR_TRACINF_KEYTRAC_NO[0] = '\0';
   FR_TRACK_INFO_KEY_ID[0] = '\0';
   FR_TRAN_FROM_ACCT_FLG[0] = '\0';
   FR_TRAN_TO_ACCT_FLG[0] = '\0';
   FR_USAGE_UPDATE_BITS = 0;
   FR_CED_BUILD_NO = 0;
   FR_PROC_FLGS1.FR_PROC_FLGS1_data[0] = '\0';
   FR_PROC_FLGS1.FR_PROC_FLGS1_len = 0;
   FR_PROC_FLGS2.FR_PROC_FLGS2_data[0] = '\0';
   FR_PROC_FLGS2.FR_PROC_FLGS2_len = 0;
   FR_PROC_FLGS3.FR_PROC_FLGS3_data[0] = '\0';
   FR_PROC_FLGS3.FR_PROC_FLGS3_len = 0;
   FR_PROC_FLGS4.FR_PROC_FLGS4_data[0] = '\0';
   FR_PROC_FLGS4.FR_PROC_FLGS4_len = 0;
   FR_PROC_BILLING_FLGS1.FR_PROC_BILLING_FLGS1_data[0] = '\0';
   FR_PROC_BILLING_FLGS1.FR_PROC_BILLING_FLGS1_len = 0;
   FR_PROC_BILLING_FLGS2.FR_PROC_BILLING_FLGS2_data[0] = '\0';
   FR_PROC_BILLING_FLGS2.FR_PROC_BILLING_FLGS2_len = 0;
   FR_PROC_BILLING_FLGS3.FR_PROC_BILLING_FLGS3_data[0] = '\0';
   FR_PROC_BILLING_FLGS3.FR_PROC_BILLING_FLGS3_len = 0;
   FR_PROC_BILLING_FLGS4.FR_PROC_BILLING_FLGS4_data[0] = '\0';
   FR_PROC_BILLING_FLGS4.FR_PROC_BILLING_FLGS4_len = 0;
   FR_PAN_IDENTIFIER[0] = '\0';
   FR_PYMT_ACCT_REF[0] = '\0';
   FR_MERCH_DISP_NAME.FR_MERCH_DISP_NAME_data[0] = '\0';
   FR_MERCH_DISP_NAME.FR_MERCH_DISP_NAME_len = 0;
   FR_EMV_3D_CAVV_VER_BY[0] = '\0';
   FR_EMV_3D_TRAN_ID[0] = '\0';
   FR_SELLER_EMAIL.FR_SELLER_EMAIL_data[0] = '\0';
   FR_SELLER_EMAIL.FR_SELLER_EMAIL_len = 0;
   FR_SELLER_PHONE.FR_SELLER_PHONE_data[0] = '\0';
   FR_SELLER_PHONE.FR_SELLER_PHONE_len = 0;
   FR_SELLER_ID.FR_SELLER_ID_data[0] = '\0';
   FR_SELLER_ID.FR_SELLER_ID_len = 0;
   FR_FORCE_POST_DROP_IND[0] = '\0';
   FR_ODE_INST_ID_FRWD[0] = '\0';
   FR_ODE_DATE_TIME_XMIT[0] = '\0';
   FR_DATE_TIME_XMIT[0] = '\0';
   FR_PAN_TOKEN_BIN_LEN = 0;
   FR_TOKEN_DEVICE_ID.FR_TOKEN_DEVICE_ID_data[0] = '\0';
   FR_TOKEN_DEVICE_ID.FR_TOKEN_DEVICE_ID_len = 0;
   FR_WALLET_REASON[0] = '\0';
  //## end dndb2database::UDBAddFinancialCommand::resetUserHost%4915EAB2000F.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::selectLocator ()
{
  //## begin dndb2database::UDBAddFinancialCommand::selectLocator%4915EAB20010.body preserve=yes
   FinancialBaseSegment* pBaseSegment = FinancialBaseSegment::instance();
   memcpy(FL_TSTAMP_LOCAL,pBaseSegment->zTSTAMP_LOCAL(),sizeof(FL_TSTAMP_LOCAL));
   memcpy(FL_MAPPED_DUP_DATA,pBaseSegment->zMAPPED_DUP_DATA(),sizeof(FL_MAPPED_DUP_DATA));
   memcpy(FL_NET_TERM_ID,pBaseSegment->zNET_TERM_ID(),sizeof(FL_NET_TERM_ID));
   memcpy(FL_PAN,pBaseSegment->zPAN(),sizeof(FL_PAN));
   memcpy(FL_RETRIEVAL_REF_NO,pBaseSegment->zRETRIEVAL_REF_NO(),sizeof(FL_RETRIEVAL_REF_NO));
   memcpy(FL_TRAN_TYPE_ID,pBaseSegment->zTRAN_TYPE_ID(),sizeof(FL_TRAN_TYPE_ID));
   memcpy(FL_SYS_TRACE_AUDIT_NO,pBaseSegment->zSYS_TRACE_AUDIT_NO(),sizeof(FL_SYS_TRACE_AUDIT_NO));
   memcpy(FL_ACT_CODE,pBaseSegment->zACT_CODE(),sizeof(FL_ACT_CODE));
   memcpy(FL_AUTH_BY,pBaseSegment->zAUTH_BY(),sizeof(FL_AUTH_BY));
   memcpy(FL_CARD_ACPT_TERM_ID,pBaseSegment->zCARD_ACPT_TERM_ID(),sizeof(FL_CARD_ACPT_TERM_ID));
   if (memcmp(FL_ACT_CODE,"400",3) == 0)
   {
      
/*
EXEC SQL OPEN D1 USING
         :FL_TSTAMP_LOCAL,
         :FL_MAPPED_DUP_DATA,
         :FL_NET_TERM_ID,
         :FL_PAN,
         :FL_RETRIEVAL_REF_NO,
         :FL_SYS_TRACE_AUDIT_NO,
         :FL_ACT_CODE,
         :FL_AUTH_BY,
         :FL_CARD_ACPT_TERM_ID;
*/

{
#line 4995 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 4995 "CXOSD206.sqx"
  sqlaaloc(2,9,6,0L);
    {
      struct sqla_setdata_list sql_setdlist[9];
#line 4995 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 15;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FL_TSTAMP_LOCAL;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 31;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FL_MAPPED_DUP_DATA;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 9;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FL_NET_TERM_ID;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 29;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FL_PAN;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 13;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FL_RETRIEVAL_REF_NO;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 7;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FL_SYS_TRACE_AUDIT_NO;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 4;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FL_ACT_CODE;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 2;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FL_AUTH_BY;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 17;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FL_CARD_ACPT_TERM_ID;
#line 4995 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 4995 "CXOSD206.sqx"
      sqlasetdata(2,0,9,sql_setdlist,0L,0L);
    }
#line 4995 "CXOSD206.sqx"
  sqlacall((unsigned short)26,1,2,0,0L);
#line 4995 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 4995 "CXOSD206.sqx"

   }
   else
   {
      
/*
EXEC SQL OPEN D2 USING
         :FL_TSTAMP_LOCAL,
         :FL_MAPPED_DUP_DATA,
         :FL_NET_TERM_ID,
         :FL_PAN,
         :FL_RETRIEVAL_REF_NO,
         :FL_TRAN_TYPE_ID,
         :FL_SYS_TRACE_AUDIT_NO,
         :FL_ACT_CODE,
         :FL_AUTH_BY,
         :FL_CARD_ACPT_TERM_ID;
*/

{
#line 5009 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 5009 "CXOSD206.sqx"
  sqlaaloc(2,10,7,0L);
    {
      struct sqla_setdata_list sql_setdlist[10];
#line 5009 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 15;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FL_TSTAMP_LOCAL;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 31;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FL_MAPPED_DUP_DATA;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 9;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FL_NET_TERM_ID;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 29;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FL_PAN;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 13;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FL_RETRIEVAL_REF_NO;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 11;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FL_TRAN_TYPE_ID;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 7;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FL_SYS_TRACE_AUDIT_NO;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 4;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FL_ACT_CODE;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 2;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FL_AUTH_BY;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 17;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)FL_CARD_ACPT_TERM_ID;
#line 5009 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 5009 "CXOSD206.sqx"
      sqlasetdata(2,0,10,sql_setdlist,0L,0L);
    }
#line 5009 "CXOSD206.sqx"
  sqlacall((unsigned short)26,2,2,0,0L);
#line 5009 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 5009 "CXOSD206.sqx"

   }

   State hState(UDBAddFinancialCommand::SUCCESS);

   char *p;
   switch (sqlca.sqlcode)
   {
      case 100:
         hState = UDBAddFinancialCommand::PREPARE_INSERT_FIN_L;
         break;
      case 0:
         break;
      case -514:
      case -518:
         p = strstr(FL_SELECT.data,"FIN_L");
         memcpy(p + 5,"YYYYMM",6);
         hState = UDBAddFinancialCommand::PREPARE_SELECT_FIN_L;
         break;
      case -911:
      case -913:
         UseCase::add("DEADLOCK");
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"selectLocator/1");
         hState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         UseCase::add("CONNECT");
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"selectLocator/2");
         hState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
         break;
      default:
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"selectLocator/3");
         if (sqlca.sqlcode > 0)
            break;
         else
         {
            hState = UDBAddFinancialCommand::DATABASE_FAILURE;
            break;
         }
   }

   if (hState == UDBAddFinancialCommand::SUCCESS)
   {
   if (memcmp(FL_ACT_CODE,"400",3)==0)
   {
      
/*
EXEC SQL FETCH D1
         INTO
            :FR_TSTAMP_TRANS,
            :FL_FIN_TYPE,
            :FR_UNIQUENESS_KEY;
*/

{
#line 5062 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 5062 "CXOSD206.sqx"
  sqlaaloc(3,3,8,0L);
    {
      struct sqla_setdata_list sql_setdlist[3];
#line 5062 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 17;
#line 5062 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_TSTAMP_TRANS;
#line 5062 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5062 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 5062 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FL_FIN_TYPE;
#line 5062 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5062 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 500; sql_setdlist[2].sqllen = 2;
#line 5062 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)&FR_UNIQUENESS_KEY;
#line 5062 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5062 "CXOSD206.sqx"
      sqlasetdata(3,0,3,sql_setdlist,0L,0L);
    }
#line 5062 "CXOSD206.sqx"
  sqlacall((unsigned short)25,1,0,3,0L);
#line 5062 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 5062 "CXOSD206.sqx"

    }
    else
   {
      
/*
EXEC SQL FETCH D2
         INTO
            :FR_TSTAMP_TRANS,
            :FL_FIN_TYPE,
            :FR_UNIQUENESS_KEY;
*/

{
#line 5070 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 5070 "CXOSD206.sqx"
  sqlaaloc(3,3,9,0L);
    {
      struct sqla_setdata_list sql_setdlist[3];
#line 5070 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 17;
#line 5070 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_TSTAMP_TRANS;
#line 5070 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5070 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 5070 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FL_FIN_TYPE;
#line 5070 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5070 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 500; sql_setdlist[2].sqllen = 2;
#line 5070 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)&FR_UNIQUENESS_KEY;
#line 5070 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5070 "CXOSD206.sqx"
      sqlasetdata(3,0,3,sql_setdlist,0L,0L);
    }
#line 5070 "CXOSD206.sqx"
  sqlacall((unsigned short)25,2,0,3,0L);
#line 5070 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 5070 "CXOSD206.sqx"

    }

      switch (sqlca.sqlcode)
      {
         case 100:
            hState = UDBAddFinancialCommand::PREPARE_INSERT_FIN_L;
            break;
         case 0:
            break;
         case -514:
         case -518:
            p = strstr(FL_SELECT.data,"FIN_L");
            memcpy(p + 5,"YYYYMM",6);
            hState = UDBAddFinancialCommand::PREPARE_SELECT_FIN_L;
            break;
         case -911:
         case -913:
            UseCase::add("DEADLOCK");
            Database::instance()->traceSQLError((void*)&sqlca, m_sID,"selectLocator/4");
            hState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
            break;
         case -900:
         case -923:
         case -924:
         case -991:
         case -1024:
            UseCase::add("CONNECT");
            Database::instance()->traceSQLError((void*)&sqlca, m_sID,"selectLocator/5");
            hState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
            break;
         default:
            Database::instance()->traceSQLError((void*)&sqlca, m_sID,"selectLocator/6");
            if (sqlca.sqlcode > 0)
               break;
            else
            {
               hState = UDBAddFinancialCommand::DATABASE_FAILURE;
               break;
            }
      }
   }
      if (memcmp(FL_ACT_CODE,"400",3) == 0)
     
/*
EXEC SQL CLOSE D1;
*/

{
#line 5113 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 5113 "CXOSD206.sqx"
  sqlacall((unsigned short)20,1,0,0,0L);
#line 5113 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 5113 "CXOSD206.sqx"

   else
     
/*
EXEC SQL CLOSE D2;
*/

{
#line 5115 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 5115 "CXOSD206.sqx"
  sqlacall((unsigned short)20,2,0,0,0L);
#line 5115 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 5115 "CXOSD206.sqx"


   if (hState != SUCCESS)
      return hState;

   switch (sqlca.sqlcode)
   {
      case 0:
         break;
      case -514:
      case -518:
         p = strstr(FL_SELECT.data,"FIN_L");
         memcpy(p + 5,"YYYYMM",6);
         return UDBAddFinancialCommand::PREPARE_SELECT_FIN_L;
      case -911:
      case -913:
         UseCase::add("DEADLOCK");
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"selectLocator/7");
         return UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         UseCase::add("CONNECT");
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"selectLocator/8");
         return UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"selectLocator/9");
         if (sqlca.sqlcode > 0)
            break;
         else
            return UDBAddFinancialCommand::DATABASE_FAILURE;
   }
   if (memcmp(FinancialBaseSegment::instance()->zFIN_TYPE(),FL_FIN_TYPE,3) > 0)
   {
      memcpy(FL_FIN_TYPE,FinancialBaseSegment::instance()->zFIN_TYPE(),sizeof(FL_FIN_TYPE));
      return UDBAddFinancialCommand::PREPARE_UPDATE_FIN_L;
   }
    //********* trace duplicates for debug purposes ***** - mep 10-15-2004
   char szDupMsg[512];
   string strDupMsg("UDBAddFinancialCommand::selectLocator() **DUPLICATE**");
   strDupMsg.append("tran found with TSTAMP_TRANS = %s, UNIQUENESS_ID = %d ");
   strDupMsg.append("TSTAMP_LOCAL = %s, MAPPED_DUP_DATA = %s, ");
   strDupMsg.append("NET_TERM_ID = %s, PAN = %s, RETRIEVAL_REF_NO = %s,");
   strDupMsg.append("TRAN_TYPE_ID = %s, ");
   strDupMsg.append("SYS_TRACE_AUDIT_NO = %s, ACT_CODE = %s, AUTH_BY = %s,");
   strDupMsg.append("CARD_ACPT_TERM_ID = %s");
   int iLen = snprintf(szDupMsg,sizeof(szDupMsg),strDupMsg.data(),
                        FinancialBaseSegment::instance()->zTSTAMP_TRANS(),
                        FinancialBaseSegment::instance()->getUNIQUENESS_KEY(),
                        FinancialBaseSegment::instance()->zTSTAMP_LOCAL(),
                        FinancialBaseSegment::instance()->zMAPPED_DUP_DATA(),
                        FinancialBaseSegment::instance()->zNET_TERM_ID(),
                        FinancialBaseSegment::instance()->zPAN(),
                        FinancialBaseSegment::instance()->zRETRIEVAL_REF_NO(),
                  FinancialBaseSegment::instance()->zTRAN_TYPE_ID(),
                        FinancialBaseSegment::instance()->zSYS_TRACE_AUDIT_NO(),
                        FinancialBaseSegment::instance()->zACT_CODE(),
                        FinancialBaseSegment::instance()->zAUTH_BY(),
                        FinancialBaseSegment::instance()->zCARD_ACPT_TERM_ID());
   Trace::put(szDupMsg,iLen,true);
    //********* trace duplicates for debug purposes ***** - mep 10-15-2004
   UseCase::add("DUPLICAT");
   return UDBAddFinancialCommand::SUCCESS;
  //## end dndb2database::UDBAddFinancialCommand::selectLocator%4915EAB20010.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::updateFinancial ()
{
  //## begin dndb2database::UDBAddFinancialCommand::updateFinancial%4915EAB2001F.body preserve=yes
   State nState;

   
/*
EXEC SQL EXECUTE D2U2 USING
      :FR_ACCT_ID_1,
      :FR_ACCT_ID_2,
      :FR_ACCT_ID_3,
      :FR_ACCT_TYPES_ISS,
      :FR_ACQ_PLAT_PROD_ID,
      :FR_AMT_CARD_BILL,
      :FR_AMT_RECON_NET,
      :FR_AMT_TRAN,
      :FR_CARD_ACPT_BUS_CODE,
      :FR_CARD_ACPT_COUNTRY,
      :FR_CARD_ACPT_NAME_LOC,
      :FR_CARD_ACPT_PST_CODE,
      :FR_CARD_ACPT_REGION,
      :FR_CARD_SEQ_NO,
      :FR_CED_BUILD_NO,
      :FR_CIRC_ID_ACQ,
      :FR_CIRC_ID_ISS,
      :FR_COUNTRY_ACQ_INST,
      :FR_COUNTRY_ISS_INST,
      :FR_CUR_CARD_BILL,
      :FR_CUR_RECON_NET,
      :FR_CUR_TRAN,
      :FR_DATE_RECON_ACQ,
      :FR_FUNC_CODE,
      :FR_MERCH_TYPE,
      :FR_MSG_RESON_CODE_ACQ,
      :FR_MSG_RESON_CODE_ISS,
      :FR_NET_ID_ACQ,
      :FR_NET_ID_ISS,
      :FR_POS_CRDHLDR_A_METH,
      :FR_REIMBURSEMENT_ATTR,
      :FR_REV_BY,
      :FR_TRAN_DISPOSITION,
      :FR_TSTAMP_TRANS,
      :FR_ACCT_QUAL_1,
      :FR_ACCT_QUAL_2,
      :FR_ADL_DATA_PRIV_ACQ,
      :FR_ADL_RESP_DATA,
      :FR_AMT_RECON_ACQ,
      :FR_AMT_RECON_ISS,
      :FR_AP_FLG,
      :FR_CAN_ITEM_VALUE0,
      :FR_CAN_ITEM_VALUE1,
      :FR_CAN_ITEM_VALUE2,
      :FR_CAN_ITEM_VALUE3,
      :FR_CAN_ITEM_VALUE4,
      :FR_CAN_ITEM_VALUE5,
      :FR_CAN_ITEM_VALUE6,
      :FR_CAN_ITEM_VALUE7,
      :FR_CAN_NO_ITEMS_DISP0,
      :FR_CAN_NO_ITEMS_DISP1,
      :FR_CAN_NO_ITEMS_DISP2,
      :FR_CAN_NO_ITEMS_DISP3,
      :FR_CAN_NO_ITEMS_DISP4,
      :FR_CAN_NO_ITEMS_DISP5,
      :FR_CAN_NO_ITEMS_DISP6,
      :FR_CAN_NO_ITEMS_DISP7,
      :FR_CAN_ORIG_NO_ITEMS0,
      :FR_CAN_ORIG_NO_ITEMS1,
      :FR_CAN_ORIG_NO_ITEMS2,
      :FR_CAN_ORIG_NO_ITEMS3,
      :FR_CAN_ORIG_NO_ITEMS4,
      :FR_CAN_ORIG_NO_ITEMS5,
      :FR_CAN_ORIG_NO_ITEMS6,
      :FR_CAN_ORIG_NO_ITEMS7,
      :FR_CARD_ACPT_ID,
      :FR_CARD_OWNER,
      :FR_CARD_TYPE,
      :FR_CAVV_RESULT,
      :FR_CNV_CRD_BIL_DE_POS,
      :FR_CNV_CRD_BIL_RATE,
      :FR_CNV_RCN_ACQ_DE_POS,
      :FR_CNV_RCN_ACQ_RATE,
      :FR_CNV_RCN_ISS_DE_POS,
      :FR_CNV_RCN_ISS_RATE,
      :FR_CNV_RCN_NET_DE_POS,
      :FR_CNV_RCN_NET_RATE,
      :FR_CRD_ACP_NAM_FMTFLG,
      :FR_CUR_RECON_ACQ,
      :FR_CUR_RECON_ISS,
      :FR_CUR_TYPE,
      :FR_CVV_CVC_RESULT,
      :FR_CVV2_CVC2_RESULT,
      :FR_DATA_PRIV_ACQ,
      :FR_DATA_PRIV_ACQ_FMT,
      :FR_DATA_PRIV_ISS,
      :FR_DATA_PRIV_ISS_FMT,
      :FR_DATE_EXP,
      :FR_DATE_RECON_ISS,
      :FR_DRAFT_CAPTURE_FLG,
      :FR_EXCHG_MASTER,
      :FR_EXCHG_SETL,
      :FR_F_ADL_DEC_POS0,
      :FR_F_ADL_DEC_POS1,
      :FR_F_ADL_DEC_POS2,
      :FR_F_ADL_DEC_POS3,
      :FR_F_ADL_DEC_POS4,
      :FR_F_ADL_DEC_POS5,
      :FR_F_AMT0,
      :FR_F_AMT1,
      :FR_F_AMT2,
      :FR_F_AMT3,
      :FR_F_AMT4,
      :FR_F_AMT5,
      :FR_F_AMT_RECON_ACQ0,
      :FR_F_AMT_RECON_ACQ1,
      :FR_F_AMT_RECON_ACQ2,
      :FR_F_AMT_RECON_ACQ3,
      :FR_F_AMT_RECON_ACQ4,
      :FR_F_AMT_RECON_ACQ5,
      :FR_F_AMT_RECON_ISS0,
      :FR_F_AMT_RECON_ISS1,
      :FR_F_AMT_RECON_ISS2,
      :FR_F_AMT_RECON_ISS3,
      :FR_F_AMT_RECON_ISS4,
      :FR_F_AMT_RECON_ISS5,
      :FR_F_AMT_RECON_NET0,
      :FR_F_AMT_RECON_NET1,
      :FR_F_AMT_RECON_NET2,
      :FR_F_AMT_RECON_NET3,
      :FR_F_AMT_RECON_NET4,
      :FR_F_AMT_RECON_NET5,
      :FR_F_CNV_ACQ_DEC_POS0,
      :FR_F_CNV_ACQ_DEC_POS1,
      :FR_F_CNV_ACQ_DEC_POS2,
      :FR_F_CNV_ACQ_DEC_POS3,
      :FR_F_CNV_ACQ_DEC_POS4,
      :FR_F_CNV_ACQ_DEC_POS5,
      :FR_F_CNV_ACQ_RATE0,
      :FR_F_CNV_ACQ_RATE1,
      :FR_F_CNV_ACQ_RATE2,
      :FR_F_CNV_ACQ_RATE3,
      :FR_F_CNV_ACQ_RATE4,
      :FR_F_CNV_ACQ_RATE5,
      :FR_F_CNV_ISS_DEC_POS0,
      :FR_F_CNV_ISS_DEC_POS1,
      :FR_F_CNV_ISS_DEC_POS2,
      :FR_F_CNV_ISS_DEC_POS3,
      :FR_F_CNV_ISS_DEC_POS4,
      :FR_F_CNV_ISS_DEC_POS5,
      :FR_F_CNV_ISS_RATE0,
      :FR_F_CNV_ISS_RATE1,
      :FR_F_CNV_ISS_RATE2,
      :FR_F_CNV_ISS_RATE3,
      :FR_F_CNV_ISS_RATE4,
      :FR_F_CNV_ISS_RATE5,
      :FR_F_CUR_CODE0,
      :FR_F_CUR_CODE1,
      :FR_F_CUR_CODE2,
      :FR_F_CUR_CODE3,
      :FR_F_CUR_CODE4,
      :FR_F_CUR_CODE5,
      :FR_F_CUR_RECON_ACQ0,
      :FR_F_CUR_RECON_ACQ1,
      :FR_F_CUR_RECON_ACQ2,
      :FR_F_CUR_RECON_ACQ3,
      :FR_F_CUR_RECON_ACQ4,
      :FR_F_CUR_RECON_ACQ5,
      :FR_F_CUR_RECON_ISS0,
      :FR_F_CUR_RECON_ISS1,
      :FR_F_CUR_RECON_ISS2,
      :FR_F_CUR_RECON_ISS3,
      :FR_F_CUR_RECON_ISS4,
      :FR_F_CUR_RECON_ISS5,
      :FR_F_INITIATOR0,
      :FR_F_INITIATOR1,
      :FR_F_INITIATOR2,
      :FR_F_INITIATOR3,
      :FR_F_INITIATOR4,
      :FR_F_INITIATOR5,
      :FR_F_MEMO0,
      :FR_F_MEMO1,
      :FR_F_MEMO2,
      :FR_F_MEMO3,
      :FR_F_MEMO4,
      :FR_F_MEMO5,
      :FR_F_TYPE0,
      :FR_F_TYPE1,
      :FR_F_TYPE2,
      :FR_F_TYPE3,
      :FR_F_TYPE4,
      :FR_F_TYPE5,
      :FR_HOST_RECV_FLG,
      :FR_HOST_SENT_FLG,
      :FR_MCI_AAV_RESULT_COD,
      :FR_MCI_ECS_LVL_IND,
      :FR_MCI_UCAF_DATA,
      :FR_MTI,
      :FR_MERCH_TIER_ID,
      :FR_OAR_RQST_FLG,
      :FR_PAYEE,
      :FR_POS_CARD_CAPT_CAP,
      :FR_POS_CARD_PRES,
      :FR_POS_CRDHLDR_AUTH,
      :FR_POS_CRDHLDR_AUTH_C,
      :FR_POS_CRDHLDR_PRESNT,
      :FR_POS_CRD_DAT_IN_CAP,
      :FR_POS_CRD_DAT_IN_MOD,
      :FR_POS_CRD_DAT_OT_CAP,
      :FR_POS_OPER_ENV,
      :FR_POS_PIN_CAPT_CAP,
      :FR_POS_TERM_OUT_CAP,
      :FR_PRINT_MASK_ID,
      :FR_REF_DATA_ACQ,
      :FR_REF_DATA_ACQ_FMT,
      :FR_REF_DATA_ISS,
      :FR_REF_DATA_ISS_FMT,
      :FR_TERM_CLASS,
      :FR_TIME_AT_AP,
      :FR_TIME_AT_ISS,
      :FR_TIME_AT_RESP_QUE,
      :FR_TIME_AT_RESP_SWTCH,
      :FR_TIME_AT_RQST_QUE,
      :FR_TIME_AT_RQST_SWTCH,
      :FR_TRACK_2_DATA,
      :FR_TRAN_DESC,
      :FR_TRAN_UNIQUE_DATA,
      :FR_TRAN_UNIQ_DATA_FMT,
      :FR_ADL_DATA_PRIV_ISS,
      :FR_BIN_EXCLUSION_GRP,
      :FR_CARD_LOGO_ID,
      :FR_NET_INTRCHG_TIER,
      :FR_INST_TIER,
      :FR_CARD_INTRCHG_ID,
      :FR_PROGRAM_ID,
      :FR_PIN_FLG,
      :FR_ADL_DATA_NATIONAL,
      :FR_MULTI_CLEAR_SEQ_NO,
      :FR_MULTI_CLEAR_COUNT,
      :FR_ACCT_TYPE_1,
      :FR_ACCT_TYPE_2,
      :FR_ACCT_TYPE_3,
      :FR_ADL_RESP_ACCT_IDX0,
      :FR_ADL_RESP_ACCT_IDX1,
      :FR_ADL_RESP_ACCT_IDX2,
      :FR_ADL_RESP_ACCT_IDX3,
      :FR_ADL_RESP_ACCT_IDX4,
      :FR_ADL_RESP_ACCT_IDX5,
      :FR_ADL_RESP_ACCT_TYP0,
      :FR_ADL_RESP_ACCT_TYP1,
      :FR_ADL_RESP_ACCT_TYP2,
      :FR_ADL_RESP_ACCT_TYP3,
      :FR_ADL_RESP_ACCT_TYP4,
      :FR_ADL_RESP_ACCT_TYP5,
      :FR_ADL_RESP_AMT0,
      :FR_ADL_RESP_AMT1,
      :FR_ADL_RESP_AMT2,
      :FR_ADL_RESP_AMT3,
      :FR_ADL_RESP_AMT4,
      :FR_ADL_RESP_AMT5,
      :FR_ADL_RESP_AMT_TYP0,
      :FR_ADL_RESP_AMT_TYP1,
      :FR_ADL_RESP_AMT_TYP2,
      :FR_ADL_RESP_AMT_TYP3,
      :FR_ADL_RESP_AMT_TYP4,
      :FR_ADL_RESP_AMT_TYP5,
      :FR_ADL_RESP_CUR_CODE0,
      :FR_ADL_RESP_CUR_CODE1,
      :FR_ADL_RESP_CUR_CODE2,
      :FR_ADL_RESP_CUR_CODE3,
      :FR_ADL_RESP_CUR_CODE4,
      :FR_ADL_RESP_CUR_CODE5,
      :FR_ADL_RQST_ACCT_IDX0,
      :FR_ADL_RQST_ACCT_IDX1,
      :FR_ADL_RQST_ACCT_IDX2,
      :FR_ADL_RQST_ACCT_IDX3,
      :FR_ADL_RQST_ACCT_IDX4,
      :FR_ADL_RQST_ACCT_IDX5,
      :FR_ADL_RQST_ACCT_TYP0,
      :FR_ADL_RQST_ACCT_TYP1,
      :FR_ADL_RQST_ACCT_TYP2,
      :FR_ADL_RQST_ACCT_TYP3,
      :FR_ADL_RQST_ACCT_TYP4,
      :FR_ADL_RQST_ACCT_TYP5,
      :FR_ADL_RQST_AMT0,
      :FR_ADL_RQST_AMT1,
      :FR_ADL_RQST_AMT2,
      :FR_ADL_RQST_AMT3,
      :FR_ADL_RQST_AMT4,
      :FR_ADL_RQST_AMT5,
      :FR_ADL_RQST_AMT_TYP0,
      :FR_ADL_RQST_AMT_TYP1,
      :FR_ADL_RQST_AMT_TYP2,
      :FR_ADL_RQST_AMT_TYP3,
      :FR_ADL_RQST_AMT_TYP4,
      :FR_ADL_RQST_AMT_TYP5,
      :FR_ADL_RQST_CUR_CODE0,
      :FR_ADL_RQST_CUR_CODE1,
      :FR_ADL_RQST_CUR_CODE2,
      :FR_ADL_RQST_CUR_CODE3,
      :FR_ADL_RQST_CUR_CODE4,
      :FR_ADL_RQST_CUR_CODE5,
      :FR_ALT_ROUTE_FLG,
      :FR_AP_APPROVAL_CODE,
      :FR_AP_CARD_GRP,
      :FR_AP_DATA,
      :FR_AP_ERROR_NO,
      :FR_AP_ERROR_TRACE_LOC,
      :FR_AP_REJ_REASON_CODE,
      :FR_AUTH_LCYCLE_TCODE,
      :FR_AUTH_LIFECYCLE_INT,
      :FR_AUTH_RQST_TIMEOUT,
      :FR_CARD_ACPT_COUNTY,
      :FR_CARD_ACPT_SPNSR_ID,
      :FR_CARD_CAPT_FLG,
      :FR_CLERK_ID,
      :FR_CNTRY_RCN_ACQ_INST,
      :FR_CNTRY_RCN_ISS_INST,
      :FR_DATE_ACTION,
      :FR_DATE_CAPTURE,
      :FR_DATE_CNV_ACQ,
      :FR_DATE_CNV_ISS,
      :FR_DATE_EFFECTIVE,
      :FR_DATE_RECON_NET,
      :FR_DEPOSIT_ONLY_FLG,
      :FR_EXTENDED_PAY_DATA,
      :FR_PIN_DATA_FMT,
      :FR_PIN_RESULT,
      :FR_PMC_ERROR,
      :FR_PREAUTH_COMP_OPT,
      :FR_PROC_BILLING_FLGS1,
      :FR_PROC_BILLING_FLGS2,
      :FR_PROC_BILLING_FLGS3,
      :FR_PROC_BILLING_FLGS4,
      :FR_PROC_FLGS1,
      :FR_PROC_FLGS2,
      :FR_PROC_FLGS3,
      :FR_PROC_FLGS4,
      :FR_RECON_IND_ACQ,
      :FR_RESTRIC_INTCHG_GRP,
      :FR_SOURCE_ROUTE_ID,
      :FR_SRV_GRP_INTCHG_IND,
      :FR_SRV_GRP_SERV_CODE,
      :FR_STANDIN_ACT,
      :FR_STANDIN_OPTION,
      :FR_TRACINF_KEYTRAC_NO,
      :FR_TRACK_INFO_KEY_ID,
      :FR_TRAN_FROM_ACCT_FLG,
      :FR_TRAN_TO_ACCT_FLG,
      :FR_USAGE_UPDATE_BITS,
      :FR_PAN_TOKEN,
      :FR_TOKEN_ASSURANCE,
      :FR_TOKEN_REQUESTOR_ID,
      :FR_PAN_INDICATOR,
      :FR_PAN_RANGE,
      :FR_TOKEN_EXP_DATE,
      :FR_TOKEN_REF_NUMBER,
      :FR_TOKEN_SER_PROVIDER,
      :FR_TOKEN_STATUS,
      :FR_TOKEN_TRANID,
      :FR_TOKEN_TYPE,
      :FR_UNFORMATTED_MICR_DATA,
      :FR_ACQ_ROUTING_NO,
      :FR_ISS_ROUTING_NO,
      :FR_TRANS_ROUTING_NO,
      :FR_DEST_ROUTING_NO,
      :FR_AUTH_LCYCLE_TRACE,
      :FR_HCE_ACTIVATE_RESULT,
      :FR_AAM_VELOCITY_RESULT,
      :FR_LUK_ELAPSED_TIME,
      :FR_LUK_TRAN_COUNT,
      :FR_LUK_AMT_TRAN,
      :FR_TOKEN_DEVICE_TYPE,
      :FR_TOKEN_DEVICE_LOC,
      :FR_TOKEN_CARD_SEQ_NO,
      :FR_TOKEN_VERSION,
      :FR_NETWORK_PROGRAM,
      :FR_WEIGHTED_AVE_FLG,
      :FR_TOKEN_REF_NUMBER_EXT,
      :FR_ADDL_TRAN_DISP,
      :FR_ADDL_TRAN_RESULT,
      :FR_SWIFT_CODE,
      :FR_IFSC_CODE,
      :FR_LOCAL_RETRIEVAL_REF_NO,
      :FR_TOKEN_ACT_CODE,
      :FR_TOKEN_STATUS_CODE,
      :FR_TOKEN_ISSUER_PROC,
      :FR_TOKEN_REQ_TSTAMP,
      :FR_TOKEN_RESP_TSTAMP,
      :FR_TOKEN_TIME_AT_TSP,
      :FR_VISA_ATM_TRAN_ID,
      :FR_DOMAIN_CTL_RESTR,
      :FR_PGRM_PROTOCOL,
      :FR_DIR_SERV_TRAN_ID,
      :FR_TRAN_INT_CLASS,
      :FR_ACL_ECOM_IND,
      :FR_P1C_ACCT_TOKEN,
      :FR_P1C_ADL_RESP_DATA,
      :FR_P1C_CRDHLDR_TOKEN,
      :FR_PRM_ADL_RESP_DATA,
      :FR_SAP_ADL_RESP_DATA,
      :FR_ECOM_DATA,
      :FR_INST_ID_FRWD,
      :FR_TOKEN_DEVICE_NAME,
      :FR_TOKEN_ENTITY,
      :FR_FO_AMT0,
      :FR_FO_AMT1,
      :FR_FO_AMT2,
      :FR_FO_AMT3,
      :FR_FO_AMT4,
      :FR_FO_AMT5,
      :FR_FO_AMT_RECON_ACQ0,
      :FR_FO_AMT_RECON_ACQ1,
      :FR_FO_AMT_RECON_ACQ2,
      :FR_FO_AMT_RECON_ACQ3,
      :FR_FO_AMT_RECON_ACQ4,
      :FR_FO_AMT_RECON_ACQ5,
      :FR_FO_AMT_RECON_ISS0,
      :FR_FO_AMT_RECON_ISS1,
      :FR_FO_AMT_RECON_ISS2,
      :FR_FO_AMT_RECON_ISS3,
      :FR_FO_AMT_RECON_ISS4,
      :FR_FO_AMT_RECON_ISS5,
      :FR_FO_AMT_RECON_NET0,
      :FR_FO_AMT_RECON_NET1,
      :FR_FO_AMT_RECON_NET2,
      :FR_FO_AMT_RECON_NET3,
      :FR_FO_AMT_RECON_NET4,
      :FR_FO_AMT_RECON_NET5,
      :FR_FO_CNV_ACQ_DE_POS0,
      :FR_FO_CNV_ACQ_DE_POS1,
      :FR_FO_CNV_ACQ_DE_POS2,
      :FR_FO_CNV_ACQ_DE_POS3,
      :FR_FO_CNV_ACQ_DE_POS4,
      :FR_FO_CNV_ACQ_DE_POS5,
      :FR_FO_CNV_ACQ_RATE0,
      :FR_FO_CNV_ACQ_RATE1,
      :FR_FO_CNV_ACQ_RATE2,
      :FR_FO_CNV_ACQ_RATE3,
      :FR_FO_CNV_ACQ_RATE4,
      :FR_FO_CNV_ACQ_RATE5,
      :FR_FO_CNV_ISS_DE_POS0,
      :FR_FO_CNV_ISS_DE_POS1,
      :FR_FO_CNV_ISS_DE_POS2,
      :FR_FO_CNV_ISS_DE_POS3,
      :FR_FO_CNV_ISS_DE_POS4,
      :FR_FO_CNV_ISS_DE_POS5,
      :FR_FO_CNV_ISS_RATE0,
      :FR_FO_CNV_ISS_RATE1,
      :FR_FO_CNV_ISS_RATE2,
      :FR_FO_CNV_ISS_RATE3,
      :FR_FO_CNV_ISS_RATE4,
      :FR_FO_CNV_ISS_RATE5,
      :FR_FO_CUR_CODE0,
      :FR_FO_CUR_CODE1,
      :FR_FO_CUR_CODE2,
      :FR_FO_CUR_CODE3,
      :FR_FO_CUR_CODE4,
      :FR_FO_CUR_CODE5,
      :FR_FO_CUR_RECON_ACQ0,
      :FR_FO_CUR_RECON_ACQ1,
      :FR_FO_CUR_RECON_ACQ2,
      :FR_FO_CUR_RECON_ACQ3,
      :FR_FO_CUR_RECON_ACQ4,
      :FR_FO_CUR_RECON_ACQ5,
      :FR_FO_CUR_RECON_ISS0,
      :FR_FO_CUR_RECON_ISS1,
      :FR_FO_CUR_RECON_ISS2,
      :FR_FO_CUR_RECON_ISS3,
      :FR_FO_CUR_RECON_ISS4,
      :FR_FO_CUR_RECON_ISS5,
      :FR_FO_DEC_POS0,
      :FR_FO_DEC_POS1,
      :FR_FO_DEC_POS2,
      :FR_FO_DEC_POS3,
      :FR_FO_DEC_POS4,
      :FR_FO_DEC_POS5,
      :FR_FO_INITIATOR0,
      :FR_FO_INITIATOR1,
      :FR_FO_INITIATOR2,
      :FR_FO_INITIATOR3,
      :FR_FO_INITIATOR4,
      :FR_FO_INITIATOR5,
      :FR_FO_MEMO0,
      :FR_FO_MEMO1,
      :FR_FO_MEMO2,
      :FR_FO_MEMO3,
      :FR_FO_MEMO4,
      :FR_FO_MEMO5,
      :FR_FO_TYPE0,
      :FR_FO_TYPE1,
      :FR_FO_TYPE2,
      :FR_FO_TYPE3,
      :FR_FO_TYPE4,
      :FR_FO_TYPE5,
      :FR_O_AMT_CARD_BILL,
      :FR_O_AMT_RECON_ACQ,
      :FR_O_AMT_RECON_ISS,
      :FR_O_AMT_RECON_NET,
      :FR_O_AMT_TRAN,
      :FR_ODE_INST_ID_ACQ,
      :FR_ODE_MTI,
      :FR_ODE_SYS_TRA_AUD_NO,
      :FR_ODE_TSTAMP_LOCL_TR,
      :FR_TSTAMP_REV_CREATED,
      :FR_ADTL_DATA_FEE,
      :FR_ISS_ACQ_TYPE_FEE,
      :FR_NET_UNIQUE_DAT_FEE,
      :FR_BRANCH_ID_ACQ,
      :FR_CNTRY_REC_INST_ADJ,
      :FR_CNTRY_REQ_INST_ADJ,
      :FR_INST_ID_REC_ADJ,
      :FR_INST_ID_REQ_ADJ,
      :FR_NET_IND_ADJ,
      :FR_ORIG_AMT_TRAN_ADJ,
      :FR_REQ_ACQ_ISS_IND,
      :FR_TRACE_DATA_ADJ,
      :FR_TSTAMP_LOCAL_ADJ,
      :FR_TSTAMP_TRANS_ADJ,
      :FR_EXTENSION_DATA_ADJ,
      :FR_BRIDGE_ACQ_FLG,
      :FR_BRIDGE_ISS_FLG,
      :FR_BIN_LENGTH,
      :FR_PAN_IDENTIFIER,
      :FR_PYMT_ACCT_REF,
      :FR_MERCH_DISP_NAME,
      :FR_EMV_3D_CAVV_VER_BY,
      :FR_EMV_3D_TRAN_ID,
      :FR_COOPER_SCORE,
      :FR_COOPER_REASON,
      :FR_AMX_FRAUD_DATA,
      :FR_ISSUER_SCRIPT_FLG,
      :FR_SELLER_EMAIL,
      :FR_SELLER_PHONE,
      :FR_SELLER_ID,
      :FR_FORCE_POST_DROP_IND,
      :FR_FP_HOLD_MATCH_FLG,
      :FR_ODE_INST_ID_FRWD,
      :FR_ODE_DATE_TIME_XMIT,
      :FR_DATE_TIME_XMIT,
      :FR_PAN_TOKEN_BIN_LEN,
      :FR_TOKEN_DEVICE_ID,
      :FR_WALLET_REASON, 
      :FR_TSTAMP_TRANS,
      :FR_UNIQUENESS_KEY;
*/

{
#line 5723 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 5723 "CXOSD206.sqx"
  sqlaaloc(2,535,10,0L);
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 29;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_ACCT_ID_1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 29;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FR_ACCT_ID_2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 29;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_ACCT_ID_3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FR_ACCT_TYPES_ISS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_ACQ_PLAT_PROD_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 480; sql_setdlist[5].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)&FR_AMT_CARD_BILL;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 480; sql_setdlist[6].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)&FR_AMT_RECON_NET;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 480; sql_setdlist[7].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)&FR_AMT_TRAN;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FR_CARD_ACPT_BUS_CODE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)FR_CARD_ACPT_COUNTRY;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 448; sql_setdlist[10].sqllen = 84;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)&FR_CARD_ACPT_NAME_LOC;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 11;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)FR_CARD_ACPT_PST_CODE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)FR_CARD_ACPT_REGION;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 6;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)FR_CARD_SEQ_NO;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 496; sql_setdlist[14].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)&FR_CED_BUILD_NO;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FR_CIRC_ID_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FR_CIRC_ID_ISS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FR_COUNTRY_ACQ_INST;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FR_COUNTRY_ISS_INST;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)FR_CUR_CARD_BILL;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FR_CUR_RECON_NET;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 460; sql_setdlist[21].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)FR_CUR_TRAN;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 460; sql_setdlist[22].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)FR_DATE_RECON_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 460; sql_setdlist[23].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)FR_FUNC_CODE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 460; sql_setdlist[24].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)FR_MERCH_TYPE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FR_MSG_RESON_CODE_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FR_MSG_RESON_CODE_ISS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FR_NET_ID_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FR_NET_ID_ISS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FR_POS_CRDHLDR_A_METH;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FR_REIMBURSEMENT_ATTR;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 460; sql_setdlist[31].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)FR_REV_BY;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 460; sql_setdlist[32].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)FR_TRAN_DISPOSITION;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 17;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FR_TSTAMP_TRANS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 460; sql_setdlist[34].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)FR_ACCT_QUAL_1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 460; sql_setdlist[35].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)FR_ACCT_QUAL_2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 448; sql_setdlist[36].sqllen = 255;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)&FR_ADL_DATA_PRIV_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 448; sql_setdlist[37].sqllen = 99;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)&FR_ADL_RESP_DATA;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 480; sql_setdlist[38].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)&FR_AMT_RECON_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 480; sql_setdlist[39].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)&FR_AMT_RECON_ISS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 460; sql_setdlist[40].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)FR_AP_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 496; sql_setdlist[41].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)&FR_CAN_ITEM_VALUE0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 496; sql_setdlist[42].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)&FR_CAN_ITEM_VALUE1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 496; sql_setdlist[43].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)&FR_CAN_ITEM_VALUE2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 496; sql_setdlist[44].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)&FR_CAN_ITEM_VALUE3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 496; sql_setdlist[45].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)&FR_CAN_ITEM_VALUE4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 496; sql_setdlist[46].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)&FR_CAN_ITEM_VALUE5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 496; sql_setdlist[47].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)&FR_CAN_ITEM_VALUE6;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 496; sql_setdlist[48].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)&FR_CAN_ITEM_VALUE7;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 500; sql_setdlist[49].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 500; sql_setdlist[50].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 500; sql_setdlist[51].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 500; sql_setdlist[52].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 500; sql_setdlist[53].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 500; sql_setdlist[54].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 500; sql_setdlist[55].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP6;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 500; sql_setdlist[56].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)&FR_CAN_NO_ITEMS_DISP7;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 500; sql_setdlist[57].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 500; sql_setdlist[58].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 500; sql_setdlist[59].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 500; sql_setdlist[60].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 500; sql_setdlist[61].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 500; sql_setdlist[62].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 500; sql_setdlist[63].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS6;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sqlasetdata(2,0,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 500; sql_setdlist[0].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)&FR_CAN_ORIG_NO_ITEMS7;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 16;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FR_CARD_ACPT_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_CARD_OWNER;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FR_CARD_TYPE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_CAVV_RESULT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 480; sql_setdlist[5].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)&FR_CNV_CRD_BIL_DE_POS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 480; sql_setdlist[6].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)&FR_CNV_CRD_BIL_RATE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 480; sql_setdlist[7].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)&FR_CNV_RCN_ACQ_DE_POS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 480; sql_setdlist[8].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)&FR_CNV_RCN_ACQ_RATE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 480; sql_setdlist[9].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)&FR_CNV_RCN_ISS_DE_POS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 480; sql_setdlist[10].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)&FR_CNV_RCN_ISS_RATE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 480; sql_setdlist[11].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)&FR_CNV_RCN_NET_DE_POS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 480; sql_setdlist[12].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)&FR_CNV_RCN_NET_RATE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)FR_CRD_ACP_NAM_FMTFLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)FR_CUR_RECON_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FR_CUR_RECON_ISS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 500; sql_setdlist[16].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)&FR_CUR_TYPE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FR_CVV_CVC_RESULT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FR_CVV2_CVC2_RESULT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 448; sql_setdlist[19].sqllen = 100;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)&FR_DATA_PRIV_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 500; sql_setdlist[20].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)&FR_DATA_PRIV_ACQ_FMT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 448; sql_setdlist[21].sqllen = 100;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)&FR_DATA_PRIV_ISS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 500; sql_setdlist[22].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)&FR_DATA_PRIV_ISS_FMT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 460; sql_setdlist[23].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)FR_DATE_EXP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 460; sql_setdlist[24].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)FR_DATE_RECON_ISS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FR_DRAFT_CAPTURE_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FR_EXCHG_MASTER;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FR_EXCHG_SETL;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 480; sql_setdlist[28].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)&FR_F_ADL_DEC_POS0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 480; sql_setdlist[29].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)&FR_F_ADL_DEC_POS1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 480; sql_setdlist[30].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)&FR_F_ADL_DEC_POS2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 480; sql_setdlist[31].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)&FR_F_ADL_DEC_POS3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 480; sql_setdlist[32].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)&FR_F_ADL_DEC_POS4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 480; sql_setdlist[33].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)&FR_F_ADL_DEC_POS5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 496; sql_setdlist[34].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)&FR_F_AMT0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 496; sql_setdlist[35].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)&FR_F_AMT1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 496; sql_setdlist[36].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)&FR_F_AMT2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 496; sql_setdlist[37].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)&FR_F_AMT3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 496; sql_setdlist[38].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)&FR_F_AMT4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 496; sql_setdlist[39].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)&FR_F_AMT5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 496; sql_setdlist[40].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)&FR_F_AMT_RECON_ACQ0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 496; sql_setdlist[41].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)&FR_F_AMT_RECON_ACQ1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 496; sql_setdlist[42].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)&FR_F_AMT_RECON_ACQ2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 496; sql_setdlist[43].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)&FR_F_AMT_RECON_ACQ3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 496; sql_setdlist[44].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)&FR_F_AMT_RECON_ACQ4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 496; sql_setdlist[45].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)&FR_F_AMT_RECON_ACQ5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 496; sql_setdlist[46].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)&FR_F_AMT_RECON_ISS0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 496; sql_setdlist[47].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)&FR_F_AMT_RECON_ISS1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 496; sql_setdlist[48].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)&FR_F_AMT_RECON_ISS2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 496; sql_setdlist[49].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)&FR_F_AMT_RECON_ISS3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 496; sql_setdlist[50].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)&FR_F_AMT_RECON_ISS4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 496; sql_setdlist[51].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)&FR_F_AMT_RECON_ISS5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 496; sql_setdlist[52].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)&FR_F_AMT_RECON_NET0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 496; sql_setdlist[53].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)&FR_F_AMT_RECON_NET1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 496; sql_setdlist[54].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)&FR_F_AMT_RECON_NET2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 496; sql_setdlist[55].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)&FR_F_AMT_RECON_NET3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 496; sql_setdlist[56].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)&FR_F_AMT_RECON_NET4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 496; sql_setdlist[57].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)&FR_F_AMT_RECON_NET5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 480; sql_setdlist[58].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)&FR_F_CNV_ACQ_DEC_POS0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 480; sql_setdlist[59].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)&FR_F_CNV_ACQ_DEC_POS1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 480; sql_setdlist[60].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)&FR_F_CNV_ACQ_DEC_POS2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 480; sql_setdlist[61].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)&FR_F_CNV_ACQ_DEC_POS3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 480; sql_setdlist[62].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)&FR_F_CNV_ACQ_DEC_POS4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 480; sql_setdlist[63].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)&FR_F_CNV_ACQ_DEC_POS5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sqlasetdata(2,64,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 480; sql_setdlist[0].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)&FR_F_CNV_ACQ_RATE0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 480; sql_setdlist[1].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)&FR_F_CNV_ACQ_RATE1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 480; sql_setdlist[2].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)&FR_F_CNV_ACQ_RATE2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 480; sql_setdlist[3].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)&FR_F_CNV_ACQ_RATE3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 480; sql_setdlist[4].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)&FR_F_CNV_ACQ_RATE4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 480; sql_setdlist[5].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)&FR_F_CNV_ACQ_RATE5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 480; sql_setdlist[6].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)&FR_F_CNV_ISS_DEC_POS0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 480; sql_setdlist[7].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)&FR_F_CNV_ISS_DEC_POS1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 480; sql_setdlist[8].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)&FR_F_CNV_ISS_DEC_POS2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 480; sql_setdlist[9].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)&FR_F_CNV_ISS_DEC_POS3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 480; sql_setdlist[10].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)&FR_F_CNV_ISS_DEC_POS4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 480; sql_setdlist[11].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)&FR_F_CNV_ISS_DEC_POS5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 480; sql_setdlist[12].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)&FR_F_CNV_ISS_RATE0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 480; sql_setdlist[13].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)&FR_F_CNV_ISS_RATE1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 480; sql_setdlist[14].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)&FR_F_CNV_ISS_RATE2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 480; sql_setdlist[15].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)&FR_F_CNV_ISS_RATE3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 480; sql_setdlist[16].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)&FR_F_CNV_ISS_RATE4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 480; sql_setdlist[17].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)&FR_F_CNV_ISS_RATE5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FR_F_CUR_CODE0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)FR_F_CUR_CODE1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FR_F_CUR_CODE2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 460; sql_setdlist[21].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)FR_F_CUR_CODE3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 460; sql_setdlist[22].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)FR_F_CUR_CODE4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 460; sql_setdlist[23].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)FR_F_CUR_CODE5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 460; sql_setdlist[24].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)FR_F_CUR_RECON_ACQ0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FR_F_CUR_RECON_ACQ1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FR_F_CUR_RECON_ACQ2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FR_F_CUR_RECON_ACQ3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FR_F_CUR_RECON_ACQ4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FR_F_CUR_RECON_ACQ5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FR_F_CUR_RECON_ISS0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 460; sql_setdlist[31].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)FR_F_CUR_RECON_ISS1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 460; sql_setdlist[32].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)FR_F_CUR_RECON_ISS2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FR_F_CUR_RECON_ISS3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 460; sql_setdlist[34].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)FR_F_CUR_RECON_ISS4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 460; sql_setdlist[35].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)FR_F_CUR_RECON_ISS5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 460; sql_setdlist[36].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)FR_F_INITIATOR0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 460; sql_setdlist[37].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)FR_F_INITIATOR1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 460; sql_setdlist[38].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)FR_F_INITIATOR2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 460; sql_setdlist[39].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)FR_F_INITIATOR3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 460; sql_setdlist[40].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)FR_F_INITIATOR4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 460; sql_setdlist[41].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)FR_F_INITIATOR5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 460; sql_setdlist[42].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)FR_F_MEMO0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 460; sql_setdlist[43].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)FR_F_MEMO1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 460; sql_setdlist[44].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)FR_F_MEMO2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 460; sql_setdlist[45].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)FR_F_MEMO3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 460; sql_setdlist[46].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)FR_F_MEMO4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 460; sql_setdlist[47].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)FR_F_MEMO5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 460; sql_setdlist[48].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)FR_F_TYPE0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 460; sql_setdlist[49].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)FR_F_TYPE1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 460; sql_setdlist[50].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)FR_F_TYPE2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 460; sql_setdlist[51].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)FR_F_TYPE3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 460; sql_setdlist[52].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)FR_F_TYPE4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 460; sql_setdlist[53].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)FR_F_TYPE5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 460; sql_setdlist[54].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)FR_HOST_RECV_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 460; sql_setdlist[55].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)FR_HOST_SENT_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 460; sql_setdlist[56].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)FR_MCI_AAV_RESULT_COD;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 460; sql_setdlist[57].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)FR_MCI_ECS_LVL_IND;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 460; sql_setdlist[58].sqllen = 33;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)FR_MCI_UCAF_DATA;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 460; sql_setdlist[59].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)FR_MTI;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 460; sql_setdlist[60].sqllen = 15;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)FR_MERCH_TIER_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 460; sql_setdlist[61].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)FR_OAR_RQST_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 460; sql_setdlist[62].sqllen = 26;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)FR_PAYEE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 460; sql_setdlist[63].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)FR_POS_CARD_CAPT_CAP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sqlasetdata(2,128,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_POS_CARD_PRES;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FR_POS_CRDHLDR_AUTH;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_POS_CRDHLDR_AUTH_C;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FR_POS_CRDHLDR_PRESNT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_POS_CRD_DAT_IN_CAP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FR_POS_CRD_DAT_IN_MOD;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FR_POS_CRD_DAT_OT_CAP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FR_POS_OPER_ENV;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FR_POS_PIN_CAPT_CAP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)FR_POS_TERM_OUT_CAP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 460; sql_setdlist[10].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)FR_PRINT_MASK_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 448; sql_setdlist[11].sqllen = 99;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)&FR_REF_DATA_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 500; sql_setdlist[12].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)&FR_REF_DATA_ACQ_FMT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 448; sql_setdlist[13].sqllen = 99;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)&FR_REF_DATA_ISS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 500; sql_setdlist[14].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)&FR_REF_DATA_ISS_FMT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FR_TERM_CLASS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 500; sql_setdlist[16].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)&FR_TIME_AT_AP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 500; sql_setdlist[17].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)&FR_TIME_AT_ISS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 500; sql_setdlist[18].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)&FR_TIME_AT_RESP_QUE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 500; sql_setdlist[19].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)&FR_TIME_AT_RESP_SWTCH;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 500; sql_setdlist[20].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)&FR_TIME_AT_RQST_QUE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 500; sql_setdlist[21].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)&FR_TIME_AT_RQST_SWTCH;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 448; sql_setdlist[22].sqllen = 40;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)&FR_TRACK_2_DATA;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 448; sql_setdlist[23].sqllen = 100;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)&FR_TRAN_DESC;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 448; sql_setdlist[24].sqllen = 50;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)&FR_TRAN_UNIQUE_DATA;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FR_TRAN_UNIQ_DATA_FMT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 448; sql_setdlist[26].sqllen = 255;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)&FR_ADL_DATA_PRIV_ISS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FR_BIN_EXCLUSION_GRP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FR_CARD_LOGO_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 6;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FR_NET_INTRCHG_TIER;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FR_INST_TIER;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 460; sql_setdlist[31].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)FR_CARD_INTRCHG_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 460; sql_setdlist[32].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)FR_PROGRAM_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FR_PIN_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 448; sql_setdlist[34].sqllen = 999;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)&FR_ADL_DATA_NATIONAL;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 460; sql_setdlist[35].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)FR_MULTI_CLEAR_SEQ_NO;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 460; sql_setdlist[36].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)FR_MULTI_CLEAR_COUNT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 460; sql_setdlist[37].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)FR_ACCT_TYPE_1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 460; sql_setdlist[38].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)FR_ACCT_TYPE_2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 460; sql_setdlist[39].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)FR_ACCT_TYPE_3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 500; sql_setdlist[40].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)&FR_ADL_RESP_ACCT_IDX0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 500; sql_setdlist[41].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)&FR_ADL_RESP_ACCT_IDX1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 500; sql_setdlist[42].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)&FR_ADL_RESP_ACCT_IDX2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 500; sql_setdlist[43].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)&FR_ADL_RESP_ACCT_IDX3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 500; sql_setdlist[44].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)&FR_ADL_RESP_ACCT_IDX4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 500; sql_setdlist[45].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)&FR_ADL_RESP_ACCT_IDX5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 460; sql_setdlist[46].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)FR_ADL_RESP_ACCT_TYP0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 460; sql_setdlist[47].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)FR_ADL_RESP_ACCT_TYP1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 460; sql_setdlist[48].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)FR_ADL_RESP_ACCT_TYP2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 460; sql_setdlist[49].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)FR_ADL_RESP_ACCT_TYP3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 460; sql_setdlist[50].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)FR_ADL_RESP_ACCT_TYP4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 460; sql_setdlist[51].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)FR_ADL_RESP_ACCT_TYP5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 480; sql_setdlist[52].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)&FR_ADL_RESP_AMT0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 480; sql_setdlist[53].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)&FR_ADL_RESP_AMT1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 480; sql_setdlist[54].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)&FR_ADL_RESP_AMT2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 480; sql_setdlist[55].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)&FR_ADL_RESP_AMT3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 480; sql_setdlist[56].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)&FR_ADL_RESP_AMT4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 480; sql_setdlist[57].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)&FR_ADL_RESP_AMT5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 460; sql_setdlist[58].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)FR_ADL_RESP_AMT_TYP0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 460; sql_setdlist[59].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)FR_ADL_RESP_AMT_TYP1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 460; sql_setdlist[60].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)FR_ADL_RESP_AMT_TYP2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 460; sql_setdlist[61].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)FR_ADL_RESP_AMT_TYP3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 460; sql_setdlist[62].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)FR_ADL_RESP_AMT_TYP4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 460; sql_setdlist[63].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)FR_ADL_RESP_AMT_TYP5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sqlasetdata(2,192,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_ADL_RESP_CUR_CODE0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FR_ADL_RESP_CUR_CODE1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_ADL_RESP_CUR_CODE2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FR_ADL_RESP_CUR_CODE3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_ADL_RESP_CUR_CODE4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FR_ADL_RESP_CUR_CODE5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 500; sql_setdlist[6].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)&FR_ADL_RQST_ACCT_IDX0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 500; sql_setdlist[7].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)&FR_ADL_RQST_ACCT_IDX1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 500; sql_setdlist[8].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)&FR_ADL_RQST_ACCT_IDX2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 500; sql_setdlist[9].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)&FR_ADL_RQST_ACCT_IDX3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 500; sql_setdlist[10].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)&FR_ADL_RQST_ACCT_IDX4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 500; sql_setdlist[11].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)&FR_ADL_RQST_ACCT_IDX5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)FR_ADL_RQST_ACCT_TYP0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)FR_ADL_RQST_ACCT_TYP1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)FR_ADL_RQST_ACCT_TYP2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FR_ADL_RQST_ACCT_TYP3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FR_ADL_RQST_ACCT_TYP4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FR_ADL_RQST_ACCT_TYP5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 480; sql_setdlist[18].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)&FR_ADL_RQST_AMT0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 480; sql_setdlist[19].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)&FR_ADL_RQST_AMT1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 480; sql_setdlist[20].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)&FR_ADL_RQST_AMT2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 480; sql_setdlist[21].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)&FR_ADL_RQST_AMT3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 480; sql_setdlist[22].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)&FR_ADL_RQST_AMT4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 480; sql_setdlist[23].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)&FR_ADL_RQST_AMT5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 460; sql_setdlist[24].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)FR_ADL_RQST_AMT_TYP0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FR_ADL_RQST_AMT_TYP1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FR_ADL_RQST_AMT_TYP2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FR_ADL_RQST_AMT_TYP3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FR_ADL_RQST_AMT_TYP4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FR_ADL_RQST_AMT_TYP5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FR_ADL_RQST_CUR_CODE0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 460; sql_setdlist[31].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)FR_ADL_RQST_CUR_CODE1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 460; sql_setdlist[32].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)FR_ADL_RQST_CUR_CODE2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FR_ADL_RQST_CUR_CODE3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 460; sql_setdlist[34].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)FR_ADL_RQST_CUR_CODE4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 460; sql_setdlist[35].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)FR_ADL_RQST_CUR_CODE5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 460; sql_setdlist[36].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)FR_ALT_ROUTE_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 460; sql_setdlist[37].sqllen = 7;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)FR_AP_APPROVAL_CODE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 460; sql_setdlist[38].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)FR_AP_CARD_GRP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 460; sql_setdlist[39].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)FR_AP_DATA;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 500; sql_setdlist[40].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)&FR_AP_ERROR_NO;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 500; sql_setdlist[41].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)&FR_AP_ERROR_TRACE_LOC;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 500; sql_setdlist[42].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)&FR_AP_REJ_REASON_CODE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 460; sql_setdlist[43].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)FR_AUTH_LCYCLE_TCODE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 480; sql_setdlist[44].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)&FR_AUTH_LIFECYCLE_INT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 500; sql_setdlist[45].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)&FR_AUTH_RQST_TIMEOUT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 460; sql_setdlist[46].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)FR_CARD_ACPT_COUNTY;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 460; sql_setdlist[47].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)FR_CARD_ACPT_SPNSR_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 460; sql_setdlist[48].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)FR_CARD_CAPT_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 460; sql_setdlist[49].sqllen = 29;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)FR_CLERK_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 460; sql_setdlist[50].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)FR_CNTRY_RCN_ACQ_INST;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 460; sql_setdlist[51].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)FR_CNTRY_RCN_ISS_INST;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 460; sql_setdlist[52].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)FR_DATE_ACTION;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 460; sql_setdlist[53].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)FR_DATE_CAPTURE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 460; sql_setdlist[54].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)FR_DATE_CNV_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 460; sql_setdlist[55].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)FR_DATE_CNV_ISS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 460; sql_setdlist[56].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)FR_DATE_EFFECTIVE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 460; sql_setdlist[57].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)FR_DATE_RECON_NET;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 460; sql_setdlist[58].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)FR_DEPOSIT_ONLY_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 460; sql_setdlist[59].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)FR_EXTENDED_PAY_DATA;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 500; sql_setdlist[60].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)&FR_PIN_DATA_FMT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 500; sql_setdlist[61].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)&FR_PIN_RESULT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 500; sql_setdlist[62].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)&FR_PMC_ERROR;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 500; sql_setdlist[63].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)&FR_PREAUTH_COMP_OPT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sqlasetdata(2,256,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 448; sql_setdlist[0].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)&FR_PROC_BILLING_FLGS1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 448; sql_setdlist[1].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)&FR_PROC_BILLING_FLGS2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 448; sql_setdlist[2].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)&FR_PROC_BILLING_FLGS3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 448; sql_setdlist[3].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)&FR_PROC_BILLING_FLGS4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 448; sql_setdlist[4].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)&FR_PROC_FLGS1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 448; sql_setdlist[5].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)&FR_PROC_FLGS2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 448; sql_setdlist[6].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)&FR_PROC_FLGS3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 448; sql_setdlist[7].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)&FR_PROC_FLGS4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 7;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FR_RECON_IND_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)FR_RESTRIC_INTCHG_GRP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 460; sql_setdlist[10].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)FR_SOURCE_ROUTE_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)FR_SRV_GRP_INTCHG_IND;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)FR_SRV_GRP_SERV_CODE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)FR_STANDIN_ACT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)FR_STANDIN_OPTION;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FR_TRACINF_KEYTRAC_NO;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FR_TRACK_INFO_KEY_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FR_TRAN_FROM_ACCT_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FR_TRAN_TO_ACCT_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 496; sql_setdlist[19].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)&FR_USAGE_UPDATE_BITS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 20;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FR_PAN_TOKEN;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 460; sql_setdlist[21].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)FR_TOKEN_ASSURANCE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 460; sql_setdlist[22].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)FR_TOKEN_REQUESTOR_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 460; sql_setdlist[23].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)FR_PAN_INDICATOR;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 460; sql_setdlist[24].sqllen = 20;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)FR_PAN_RANGE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FR_TOKEN_EXP_DATE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 49;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FR_TOKEN_REF_NUMBER;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FR_TOKEN_SER_PROVIDER;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FR_TOKEN_STATUS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 448; sql_setdlist[29].sqllen = 99;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)&FR_TOKEN_TRANID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FR_TOKEN_TYPE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 448; sql_setdlist[31].sqllen = 48;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)&FR_UNFORMATTED_MICR_DATA;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 460; sql_setdlist[32].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)FR_ACQ_ROUTING_NO;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FR_ISS_ROUTING_NO;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 460; sql_setdlist[34].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)FR_TRANS_ROUTING_NO;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 460; sql_setdlist[35].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)FR_DEST_ROUTING_NO;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 460; sql_setdlist[36].sqllen = 16;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)FR_AUTH_LCYCLE_TRACE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 460; sql_setdlist[37].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)FR_HCE_ACTIVATE_RESULT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 460; sql_setdlist[38].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)FR_AAM_VELOCITY_RESULT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 500; sql_setdlist[39].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)&FR_LUK_ELAPSED_TIME;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 500; sql_setdlist[40].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)&FR_LUK_TRAN_COUNT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 480; sql_setdlist[41].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)&FR_LUK_AMT_TRAN;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 460; sql_setdlist[42].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)FR_TOKEN_DEVICE_TYPE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 460; sql_setdlist[43].sqllen = 26;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)FR_TOKEN_DEVICE_LOC;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 460; sql_setdlist[44].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)FR_TOKEN_CARD_SEQ_NO;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 460; sql_setdlist[45].sqllen = 7;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)FR_TOKEN_VERSION;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 460; sql_setdlist[46].sqllen = 11;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)FR_NETWORK_PROGRAM;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 460; sql_setdlist[47].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)FR_WEIGHTED_AVE_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 460; sql_setdlist[48].sqllen = 17;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)FR_TOKEN_REF_NUMBER_EXT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 460; sql_setdlist[49].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)FR_ADDL_TRAN_DISP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 448; sql_setdlist[50].sqllen = 90;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)&FR_ADDL_TRAN_RESULT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 460; sql_setdlist[51].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)FR_SWIFT_CODE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 460; sql_setdlist[52].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)FR_IFSC_CODE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 460; sql_setdlist[53].sqllen = 13;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)FR_LOCAL_RETRIEVAL_REF_NO;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 460; sql_setdlist[54].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)FR_TOKEN_ACT_CODE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 460; sql_setdlist[55].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)FR_TOKEN_STATUS_CODE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 460; sql_setdlist[56].sqllen = 9;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)FR_TOKEN_ISSUER_PROC;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 460; sql_setdlist[57].sqllen = 17;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)FR_TOKEN_REQ_TSTAMP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 460; sql_setdlist[58].sqllen = 17;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)FR_TOKEN_RESP_TSTAMP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 460; sql_setdlist[59].sqllen = 6;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)FR_TOKEN_TIME_AT_TSP;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 460; sql_setdlist[60].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)FR_VISA_ATM_TRAN_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 460; sql_setdlist[61].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)FR_DOMAIN_CTL_RESTR;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 460; sql_setdlist[62].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)FR_PGRM_PROTOCOL;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 460; sql_setdlist[63].sqllen = 37;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)FR_DIR_SERV_TRAN_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sqlasetdata(2,320,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_TRAN_INT_CLASS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FR_ACL_ECOM_IND;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 21;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_P1C_ACCT_TOKEN;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FR_P1C_ADL_RESP_DATA;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 21;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_P1C_CRDHLDR_TOKEN;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FR_PRM_ADL_RESP_DATA;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FR_SAP_ADL_RESP_DATA;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 448; sql_setdlist[7].sqllen = 99;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)&FR_ECOM_DATA;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FR_INST_ID_FRWD;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 26;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)FR_TOKEN_DEVICE_NAME;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 460; sql_setdlist[10].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)FR_TOKEN_ENTITY;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 496; sql_setdlist[11].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)&FR_FO_AMT0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 496; sql_setdlist[12].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)&FR_FO_AMT1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 496; sql_setdlist[13].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)&FR_FO_AMT2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 496; sql_setdlist[14].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)&FR_FO_AMT3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 496; sql_setdlist[15].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)&FR_FO_AMT4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 496; sql_setdlist[16].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)&FR_FO_AMT5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 496; sql_setdlist[17].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)&FR_FO_AMT_RECON_ACQ0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 496; sql_setdlist[18].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)&FR_FO_AMT_RECON_ACQ1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 496; sql_setdlist[19].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)&FR_FO_AMT_RECON_ACQ2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 496; sql_setdlist[20].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)&FR_FO_AMT_RECON_ACQ3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 496; sql_setdlist[21].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)&FR_FO_AMT_RECON_ACQ4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 496; sql_setdlist[22].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)&FR_FO_AMT_RECON_ACQ5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 496; sql_setdlist[23].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)&FR_FO_AMT_RECON_ISS0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 496; sql_setdlist[24].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)&FR_FO_AMT_RECON_ISS1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 496; sql_setdlist[25].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)&FR_FO_AMT_RECON_ISS2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 496; sql_setdlist[26].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)&FR_FO_AMT_RECON_ISS3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 496; sql_setdlist[27].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)&FR_FO_AMT_RECON_ISS4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 496; sql_setdlist[28].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)&FR_FO_AMT_RECON_ISS5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 496; sql_setdlist[29].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)&FR_FO_AMT_RECON_NET0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 496; sql_setdlist[30].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)&FR_FO_AMT_RECON_NET1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 496; sql_setdlist[31].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)&FR_FO_AMT_RECON_NET2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 496; sql_setdlist[32].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)&FR_FO_AMT_RECON_NET3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 496; sql_setdlist[33].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)&FR_FO_AMT_RECON_NET4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 496; sql_setdlist[34].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)&FR_FO_AMT_RECON_NET5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 480; sql_setdlist[35].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)&FR_FO_CNV_ACQ_DE_POS0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 480; sql_setdlist[36].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)&FR_FO_CNV_ACQ_DE_POS1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 480; sql_setdlist[37].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)&FR_FO_CNV_ACQ_DE_POS2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 480; sql_setdlist[38].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)&FR_FO_CNV_ACQ_DE_POS3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 480; sql_setdlist[39].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)&FR_FO_CNV_ACQ_DE_POS4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 480; sql_setdlist[40].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)&FR_FO_CNV_ACQ_DE_POS5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 496; sql_setdlist[41].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)&FR_FO_CNV_ACQ_RATE0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 496; sql_setdlist[42].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)&FR_FO_CNV_ACQ_RATE1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 496; sql_setdlist[43].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)&FR_FO_CNV_ACQ_RATE2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 496; sql_setdlist[44].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)&FR_FO_CNV_ACQ_RATE3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 496; sql_setdlist[45].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)&FR_FO_CNV_ACQ_RATE4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 496; sql_setdlist[46].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)&FR_FO_CNV_ACQ_RATE5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 480; sql_setdlist[47].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)&FR_FO_CNV_ISS_DE_POS0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 480; sql_setdlist[48].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)&FR_FO_CNV_ISS_DE_POS1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 480; sql_setdlist[49].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)&FR_FO_CNV_ISS_DE_POS2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 480; sql_setdlist[50].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)&FR_FO_CNV_ISS_DE_POS3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 480; sql_setdlist[51].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)&FR_FO_CNV_ISS_DE_POS4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 480; sql_setdlist[52].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)&FR_FO_CNV_ISS_DE_POS5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 496; sql_setdlist[53].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)&FR_FO_CNV_ISS_RATE0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 496; sql_setdlist[54].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)&FR_FO_CNV_ISS_RATE1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 496; sql_setdlist[55].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)&FR_FO_CNV_ISS_RATE2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 496; sql_setdlist[56].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)&FR_FO_CNV_ISS_RATE3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 496; sql_setdlist[57].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)&FR_FO_CNV_ISS_RATE4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 496; sql_setdlist[58].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)&FR_FO_CNV_ISS_RATE5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 460; sql_setdlist[59].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)FR_FO_CUR_CODE0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 460; sql_setdlist[60].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)FR_FO_CUR_CODE1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 460; sql_setdlist[61].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)FR_FO_CUR_CODE2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 460; sql_setdlist[62].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)FR_FO_CUR_CODE3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 460; sql_setdlist[63].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)FR_FO_CUR_CODE4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sqlasetdata(2,384,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[64];
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_FO_CUR_CODE5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FR_FO_CUR_RECON_ACQ0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_FO_CUR_RECON_ACQ1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FR_FO_CUR_RECON_ACQ2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_FO_CUR_RECON_ACQ3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FR_FO_CUR_RECON_ACQ4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FR_FO_CUR_RECON_ACQ5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FR_FO_CUR_RECON_ISS0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FR_FO_CUR_RECON_ISS1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)FR_FO_CUR_RECON_ISS2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 460; sql_setdlist[10].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)FR_FO_CUR_RECON_ISS3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)FR_FO_CUR_RECON_ISS4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)FR_FO_CUR_RECON_ISS5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 480; sql_setdlist[13].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)&FR_FO_DEC_POS0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 480; sql_setdlist[14].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)&FR_FO_DEC_POS1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 480; sql_setdlist[15].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)&FR_FO_DEC_POS2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 480; sql_setdlist[16].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)&FR_FO_DEC_POS3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 480; sql_setdlist[17].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)&FR_FO_DEC_POS4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 480; sql_setdlist[18].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)&FR_FO_DEC_POS5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)FR_FO_INITIATOR0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FR_FO_INITIATOR1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 460; sql_setdlist[21].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)FR_FO_INITIATOR2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 460; sql_setdlist[22].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)FR_FO_INITIATOR3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 460; sql_setdlist[23].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)FR_FO_INITIATOR4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 460; sql_setdlist[24].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)FR_FO_INITIATOR5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FR_FO_MEMO0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FR_FO_MEMO1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FR_FO_MEMO2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FR_FO_MEMO3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FR_FO_MEMO4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FR_FO_MEMO5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 460; sql_setdlist[31].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)FR_FO_TYPE0;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 460; sql_setdlist[32].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)FR_FO_TYPE1;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FR_FO_TYPE2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 460; sql_setdlist[34].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)FR_FO_TYPE3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 460; sql_setdlist[35].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)FR_FO_TYPE4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 460; sql_setdlist[36].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)FR_FO_TYPE5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 480; sql_setdlist[37].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)&FR_O_AMT_CARD_BILL;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 480; sql_setdlist[38].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)&FR_O_AMT_RECON_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 480; sql_setdlist[39].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)&FR_O_AMT_RECON_ISS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 480; sql_setdlist[40].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)&FR_O_AMT_RECON_NET;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 480; sql_setdlist[41].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)&FR_O_AMT_TRAN;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 460; sql_setdlist[42].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)FR_ODE_INST_ID_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 460; sql_setdlist[43].sqllen = 5;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)FR_ODE_MTI;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 460; sql_setdlist[44].sqllen = 7;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)FR_ODE_SYS_TRA_AUD_NO;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 460; sql_setdlist[45].sqllen = 15;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)FR_ODE_TSTAMP_LOCL_TR;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 460; sql_setdlist[46].sqllen = 17;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)FR_TSTAMP_REV_CREATED;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 448; sql_setdlist[47].sqllen = 254;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)&FR_ADTL_DATA_FEE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqltype = 460; sql_setdlist[48].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqldata = (void*)FR_ISS_ACQ_TYPE_FEE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[48].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqltype = 448; sql_setdlist[49].sqllen = 80;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqldata = (void*)&FR_NET_UNIQUE_DAT_FEE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[49].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqltype = 460; sql_setdlist[50].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqldata = (void*)FR_BRANCH_ID_ACQ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[50].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqltype = 460; sql_setdlist[51].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqldata = (void*)FR_CNTRY_REC_INST_ADJ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[51].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqltype = 460; sql_setdlist[52].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqldata = (void*)FR_CNTRY_REQ_INST_ADJ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[52].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqltype = 460; sql_setdlist[53].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqldata = (void*)FR_INST_ID_REC_ADJ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[53].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqltype = 460; sql_setdlist[54].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqldata = (void*)FR_INST_ID_REQ_ADJ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[54].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqltype = 460; sql_setdlist[55].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqldata = (void*)FR_NET_IND_ADJ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[55].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqltype = 480; sql_setdlist[56].sqllen = 8;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqldata = (void*)&FR_ORIG_AMT_TRAN_ADJ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[56].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqltype = 460; sql_setdlist[57].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqldata = (void*)FR_REQ_ACQ_ISS_IND;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[57].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqltype = 460; sql_setdlist[58].sqllen = 24;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqldata = (void*)FR_TRACE_DATA_ADJ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[58].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqltype = 460; sql_setdlist[59].sqllen = 15;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqldata = (void*)FR_TSTAMP_LOCAL_ADJ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[59].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqltype = 460; sql_setdlist[60].sqllen = 17;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqldata = (void*)FR_TSTAMP_TRANS_ADJ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[60].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqltype = 448; sql_setdlist[61].sqllen = 400;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqldata = (void*)&FR_EXTENSION_DATA_ADJ;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[61].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqltype = 460; sql_setdlist[62].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqldata = (void*)FR_BRIDGE_ACQ_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[62].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqltype = 460; sql_setdlist[63].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqldata = (void*)FR_BRIDGE_ISS_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[63].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sqlasetdata(2,448,64,sql_setdlist,0L,0L);
    }
    {
      struct sqla_setdata_list sql_setdlist[23];
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 500; sql_setdlist[0].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)&FR_BIN_LENGTH;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 26;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FR_PAN_IDENTIFIER;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 30;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_PYMT_ACCT_REF;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 448; sql_setdlist[3].sqllen = 100;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)&FR_MERCH_DISP_NAME;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_EMV_3D_CAVV_VER_BY;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 37;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FR_EMV_3D_TRAN_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 4;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FR_COOPER_SCORE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 3;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FR_COOPER_REASON;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 448; sql_setdlist[8].sqllen = 52;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)&FR_AMX_FRAUD_DATA;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)FR_ISSUER_SCRIPT_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 448; sql_setdlist[10].sqllen = 40;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)&FR_SELLER_EMAIL;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 448; sql_setdlist[11].sqllen = 20;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)&FR_SELLER_PHONE;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 448; sql_setdlist[12].sqllen = 20;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)&FR_SELLER_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)FR_FORCE_POST_DROP_IND;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)FR_FP_HOLD_MATCH_FLG;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 12;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FR_ODE_INST_ID_FRWD;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 11;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FR_ODE_DATE_TIME_XMIT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 11;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FR_DATE_TIME_XMIT;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 500; sql_setdlist[18].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)&FR_PAN_TOKEN_BIN_LEN;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 448; sql_setdlist[19].sqllen = 48;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)&FR_TOKEN_DEVICE_ID;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 7;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FR_WALLET_REASON;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 460; sql_setdlist[21].sqllen = 17;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)FR_TSTAMP_TRANS;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 500; sql_setdlist[22].sqllen = 2;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)&FR_UNIQUENESS_KEY;
#line 5723 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 5723 "CXOSD206.sqx"
      sqlasetdata(2,512,23,sql_setdlist,0L,0L);
    }
#line 5723 "CXOSD206.sqx"
  sqlacall((unsigned short)24,8,2,0,0L);
#line 5723 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 5723 "CXOSD206.sqx"


   int nColumnNumber=0;
   char *p;
   switch (sqlca.sqlcode)
   {
      case 0:
         UseCase::addItem();
         m_iPrevColumnNumber=0;
         return UDBAddFinancialCommand::SUCCESS;
      case -514:
      case -518:
         p = strstr(FINU_UPDATE.data,"FIN_RECORD");
         memcpy(p + 10,"YYYYMM",6);
         return UDBAddFinancialCommand::PREPARE_UPDATE_FIN_RECORD;
      case -302:
         /*
         Database::instance()->traceSQLError((void*)&sqlca,m_sID, "captureColumnNumber");
         nColumnNumber=atoi((char*)((struct sqlca*)&sqlca)->sqlerrmc);
         if (nColumnNumber!=m_iPrevColumnNumber)
         {
            m_iPrevColumnNumber=nColumnNumber;
            if (nColumnNumber <= m_iTotalUpdateFinancialColumns)  //Leave out FR_TSTAMP_TRANS and FR_UNIQUENESS_KEY
            {
               int i=1;
               while ((i < m_hOptLogic.size()) && (nColumnNumber > m_hOptLogic[i].first))
               {
                  nColumnNumber = nColumnNumber - m_hOptLogic[i].first;
                  i++;
               }
               m_hOptLogic[i].second->repair(nColumnNumber-1);
               copyMemberToHost();
               nState=UDBAddFinancialCommand::UPDATE_FIN_RECORD;
            }
         }
         else
         */
         {
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
         break;
      case -204:
      case  204:
      case -205:
      case -206:
      case  206:
      case -289:
      case -818:
      case -904:
         nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
         break;
      case -911:
      case -913:
         nState = UDBAddFinancialCommand::INSERT_DEADLOCK_TIMEOUT;
         Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            m_iPrevColumnNumber=0;
            nState = UDBAddFinancialCommand::SUCCESS;
         }
         else
         {
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,
      "updateMonthlyFinancial");
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::updateFinancial%4915EAB2001F.body
}

UDBAddFinancialCommand::State UDBAddFinancialCommand::updateLocator ()
{
  //## begin dndb2database::UDBAddFinancialCommand::updateLocator%4915EAB2002E.body preserve=yes
   UseCase hUseCase("DR","## DR09 UPDATE FINANCIAL");
   State nState;
   if (m_bUpdate)
   {
      
/*
EXEC SQL EXECUTE D2U1 USING
         :FR_ACCT_ID_1,
         :FR_AMT_RECON_NET,
         :FR_CUR_RECON_NET,
         :FR_FUNC_CODE,
         :FR_MERCH_TYPE,
         :FR_DATE_RECON_ACQ,
         :FR_DATE_RECON_ISS,
         :FR_PAN_TOKEN,
         :FR_CARD_ACPT_BUS_CODE,
         :FR_COUNTRY_ACQ_INST,
         :FR_TRAN_DISPOSITION,
         :FR_CARD_ACPT_ID,
         :FR_POS_CRD_DAT_IN_MOD,
         :FL_ACT_CODE,
         :FL_APPROVAL_CODE,
         :FL_AUTH_BY,
         :FL_CARD_ACPT_TERM_ID,
         :FL_FIN_TYPE,
         :FL_INST_ID_ACQ,
         :FL_INST_ID_ISS,
         :FL_INST_ID_RECN_ACQ_B,
         :FL_INST_ID_RECN_ISS_B,
         :FL_INST_ID_RECON_ACQ,
         :FL_INST_ID_RECON_ISS,
         :FL_MAPPED_DUP_DATA,
         :FL_NET_TERM_ID,
         :FL_PAN,
         :FL_PROC_GRP_ID_ACQ_B,
         :FL_PROC_GRP_ID_ISS_B,
         :FL_PROC_ID_ACQ,
         :FL_PROC_ID_ACQ_B,
         :FL_PROC_ID_ISS,
         :FL_PROC_ID_ISS_B,
         :FL_RETRIEVAL_REF_NO,
         :FL_RPT_LVL_ID_B,
         :FL_SUBSCRIBER_IND,
         :FL_SYS_TRACE_AUDIT_NO,
         :FL_TRAN_CLASS,
         :FL_TRAN_TYPE_ID,
         :FL_TSTAMP_LOCAL,
         :FL_PAN_PREFIX,
         :FL_INV_ORDER_NO,
         :FL_PAN_SUFFIX,
         :FL_PAN_TOKEN_PREFIX,
         :FL_PAN_TOKEN_SUFFIX,
         :FL_TRANSACTION_ID,
         :FR_TSTAMP_TRANS,
         :FR_UNIQUENESS_KEY;
*/

{
#line 5860 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 5860 "CXOSD206.sqx"
  sqlaaloc(2,48,11,0L);
    {
      struct sqla_setdata_list sql_setdlist[48];
#line 5860 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 29;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_ACCT_ID_1;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 480; sql_setdlist[1].sqllen = 8;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)&FR_AMT_RECON_NET;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 4;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_CUR_RECON_NET;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 4;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)FR_FUNC_CODE;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 5;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[4].sqldata = (void*)FR_MERCH_TYPE;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 9;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[5].sqldata = (void*)FR_DATE_RECON_ACQ;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 9;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[6].sqldata = (void*)FR_DATE_RECON_ISS;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 20;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[7].sqldata = (void*)FR_PAN_TOKEN;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 5;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[8].sqldata = (void*)FR_CARD_ACPT_BUS_CODE;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 4;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[9].sqldata = (void*)FR_COUNTRY_ACQ_INST;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[10].sqltype = 460; sql_setdlist[10].sqllen = 2;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[10].sqldata = (void*)FR_TRAN_DISPOSITION;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 16;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[11].sqldata = (void*)FR_CARD_ACPT_ID;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 2;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[12].sqldata = (void*)FR_POS_CRD_DAT_IN_MOD;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 4;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[13].sqldata = (void*)FL_ACT_CODE;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 7;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[14].sqldata = (void*)FL_APPROVAL_CODE;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 2;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[15].sqldata = (void*)FL_AUTH_BY;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 17;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[16].sqldata = (void*)FL_CARD_ACPT_TERM_ID;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 4;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[17].sqldata = (void*)FL_FIN_TYPE;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 12;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[18].sqldata = (void*)FL_INST_ID_ACQ;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 12;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[19].sqldata = (void*)FL_INST_ID_ISS;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 12;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[20].sqldata = (void*)FL_INST_ID_RECN_ACQ_B;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[21].sqltype = 460; sql_setdlist[21].sqllen = 12;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[21].sqldata = (void*)FL_INST_ID_RECN_ISS_B;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[21].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[22].sqltype = 460; sql_setdlist[22].sqllen = 12;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[22].sqldata = (void*)FL_INST_ID_RECON_ACQ;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[22].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[23].sqltype = 460; sql_setdlist[23].sqllen = 12;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[23].sqldata = (void*)FL_INST_ID_RECON_ISS;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[23].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[24].sqltype = 460; sql_setdlist[24].sqllen = 31;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[24].sqldata = (void*)FL_MAPPED_DUP_DATA;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[24].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[25].sqltype = 460; sql_setdlist[25].sqllen = 9;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[25].sqldata = (void*)FL_NET_TERM_ID;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[25].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[26].sqltype = 460; sql_setdlist[26].sqllen = 29;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[26].sqldata = (void*)FL_PAN;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[26].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[27].sqltype = 460; sql_setdlist[27].sqllen = 9;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[27].sqldata = (void*)FL_PROC_GRP_ID_ACQ_B;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[27].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[28].sqltype = 460; sql_setdlist[28].sqllen = 9;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[28].sqldata = (void*)FL_PROC_GRP_ID_ISS_B;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[28].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[29].sqltype = 460; sql_setdlist[29].sqllen = 9;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[29].sqldata = (void*)FL_PROC_ID_ACQ;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[29].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[30].sqltype = 460; sql_setdlist[30].sqllen = 9;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[30].sqldata = (void*)FL_PROC_ID_ACQ_B;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[30].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[31].sqltype = 460; sql_setdlist[31].sqllen = 9;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[31].sqldata = (void*)FL_PROC_ID_ISS;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[31].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[32].sqltype = 460; sql_setdlist[32].sqllen = 9;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[32].sqldata = (void*)FL_PROC_ID_ISS_B;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[32].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[33].sqltype = 460; sql_setdlist[33].sqllen = 13;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[33].sqldata = (void*)FL_RETRIEVAL_REF_NO;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[33].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[34].sqltype = 460; sql_setdlist[34].sqllen = 17;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[34].sqldata = (void*)FL_RPT_LVL_ID_B;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[34].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[35].sqltype = 460; sql_setdlist[35].sqllen = 2;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[35].sqldata = (void*)FL_SUBSCRIBER_IND;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[35].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[36].sqltype = 460; sql_setdlist[36].sqllen = 7;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[36].sqldata = (void*)FL_SYS_TRACE_AUDIT_NO;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[36].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[37].sqltype = 460; sql_setdlist[37].sqllen = 4;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[37].sqldata = (void*)FL_TRAN_CLASS;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[37].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[38].sqltype = 460; sql_setdlist[38].sqllen = 11;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[38].sqldata = (void*)FL_TRAN_TYPE_ID;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[38].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[39].sqltype = 460; sql_setdlist[39].sqllen = 15;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[39].sqldata = (void*)FL_TSTAMP_LOCAL;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[39].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[40].sqltype = 460; sql_setdlist[40].sqllen = 13;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[40].sqldata = (void*)FL_PAN_PREFIX;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[40].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[41].sqltype = 460; sql_setdlist[41].sqllen = 16;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[41].sqldata = (void*)FL_INV_ORDER_NO;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[41].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[42].sqltype = 460; sql_setdlist[42].sqllen = 5;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[42].sqldata = (void*)FL_PAN_SUFFIX;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[42].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[43].sqltype = 460; sql_setdlist[43].sqllen = 13;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[43].sqldata = (void*)FL_PAN_TOKEN_PREFIX;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[43].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[44].sqltype = 460; sql_setdlist[44].sqllen = 5;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[44].sqldata = (void*)FL_PAN_TOKEN_SUFFIX;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[44].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[45].sqltype = 460; sql_setdlist[45].sqllen = 37;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[45].sqldata = (void*)FL_TRANSACTION_ID;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[45].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[46].sqltype = 460; sql_setdlist[46].sqllen = 17;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[46].sqldata = (void*)FR_TSTAMP_TRANS;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[46].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[47].sqltype = 500; sql_setdlist[47].sqllen = 2;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[47].sqldata = (void*)&FR_UNIQUENESS_KEY;
#line 5860 "CXOSD206.sqx"
      sql_setdlist[47].sqlind = 0L;
#line 5860 "CXOSD206.sqx"
      sqlasetdata(2,0,48,sql_setdlist,0L,0L);
    }
#line 5860 "CXOSD206.sqx"
  sqlacall((unsigned short)24,9,2,0,0L);
#line 5860 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 5860 "CXOSD206.sqx"

   }
   else
   {
      
/*
EXEC SQL EXECUTE D2U1 USING
         :FR_ACCT_ID_1,
         :FL_FIN_TYPE,
         :FR_TSTAMP_TRANS,
         :FR_UNIQUENESS_KEY;
*/

{
#line 5868 "CXOSD206.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 5868 "CXOSD206.sqx"
  sqlaaloc(2,4,12,0L);
    {
      struct sqla_setdata_list sql_setdlist[4];
#line 5868 "CXOSD206.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 29;
#line 5868 "CXOSD206.sqx"
      sql_setdlist[0].sqldata = (void*)FR_ACCT_ID_1;
#line 5868 "CXOSD206.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 5868 "CXOSD206.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 5868 "CXOSD206.sqx"
      sql_setdlist[1].sqldata = (void*)FL_FIN_TYPE;
#line 5868 "CXOSD206.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 5868 "CXOSD206.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 17;
#line 5868 "CXOSD206.sqx"
      sql_setdlist[2].sqldata = (void*)FR_TSTAMP_TRANS;
#line 5868 "CXOSD206.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 5868 "CXOSD206.sqx"
      sql_setdlist[3].sqltype = 500; sql_setdlist[3].sqllen = 2;
#line 5868 "CXOSD206.sqx"
      sql_setdlist[3].sqldata = (void*)&FR_UNIQUENESS_KEY;
#line 5868 "CXOSD206.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 5868 "CXOSD206.sqx"
      sqlasetdata(2,0,4,sql_setdlist,0L,0L);
    }
#line 5868 "CXOSD206.sqx"
  sqlacall((unsigned short)24,9,2,0,0L);
#line 5868 "CXOSD206.sqx"
  sqlastop(0L);
}

#line 5868 "CXOSD206.sqx"

   }
   // force trace
   int nColumnNumber=0;
   switch (sqlca.sqlcode)
   {
      case 0:
         m_iPrevColumnNumber=0;
         return UDBAddFinancialCommand::PREPARE_UPDATE_FIN_RECORD;
      case -302:
         Database::instance()->traceSQLError((void*)&sqlca,m_sID, "captureColumnNumber");
         nColumnNumber=atoi((char*)((struct sqlca*)&sqlca)->sqlerrmc);
         if ((m_bUpdate) && (nColumnNumber!=m_iPrevColumnNumber))
         {
            m_iPrevColumnNumber=nColumnNumber;
            //Leave out FR_TSTAMP_TRANS, FR_UNIQUENESS_KEY, FR_ACCT_ID_1, FR_AMOUNT_RECON_NET, FR_CUR_RECON_NET, FR_FUNC_CODE, FR_MERCH_TYPE,
            //FL_PAN_PREFIX, FL_INV_ORDER_NO, FL_PAN_SUFFIX, FL_PAN_TOKEN_PREFIX, FL_PAN_TOKEN_SUFFIX
            //Restrict between ACT_CODE and TSTAMP_LOCAL from RS13, ACT_CODE is offset 36 in RS13
            if ((nColumnNumber > 5) && (nColumnNumber < 33))
            {
               int offset = nColumnNumber+30;
               if (nColumnNumber==9) offset=103;                        //CARD_ACPT_TERM_ID
               FinancialBaseSegment::instance()->repair(offset);
               copyMemberToHost();                                      //FL_FIN_TYPE is the only one that is not copied among FL members
               nState=UDBAddFinancialCommand::UPDATE_FIN_L;
            }
         }
         else
         {
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
         break;
      case -204:
      case  204:
      case -205:
      case -206:
      case  206:
      case -289:
      case -818:
      case -904:
         nState = UDBAddFinancialCommand::RESOURCE_UNAVAILABLE_ERROR;
         break;
      case -911:
      case -913:
         nState = UDBAddFinancialCommand::UPDATE_DEADLOCK_TIMEOUT;
         Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         nState = UDBAddFinancialCommand::DATABASE_CONNECTION_ERROR;
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
            m_iPrevColumnNumber=0;
            nState = UDBAddFinancialCommand::PREPARE_UPDATE_FIN_RECORD;
         }
         else
         {
            nState = UDBAddFinancialCommand::DATABASE_FAILURE;
            Transaction::instance()->setReturnCode(Transaction::DATABASE_FAILURE);
         }
   }
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,
      "updateLocator");
   UseCase::setSuccess(false);
   return nState;
  //## end dndb2database::UDBAddFinancialCommand::updateLocator%4915EAB2002E.body
}

// Additional Declarations
  //## begin dndb2database::UDBAddFinancialCommand%4915E99F001F.declarations preserve=yes
#ifdef MVS
bool UDBAddFinancialCommand::checkForBusinessDuplicate(const char* pszTSTAMP_TRANS)
{
   Trace::put((const char*)sqlca.sqlerrmc,sqlca.sqlerrml,true);
   if (memcmp((const char*)sqlca.sqlerrmc,"X2",2) == 0)
      return true;
   return false;
}
#endif
  //## end dndb2database::UDBAddFinancialCommand%4915E99F001F.declarations
} // namespace dndb2database

//## begin module%4915EB0E01D4.epilog preserve=yes
//## end module%4915EB0E01D4.epilog
