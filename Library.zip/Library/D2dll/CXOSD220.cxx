static char sqla_program_id[292] = 
{
 '\xac','\x0','\x41','\x45','\x41','\x56','\x41','\x49','\x45','\x42','\x79','\x33','\x52','\x48','\x49','\x6f','\x30','\x31','\x31','\x31',
 '\x31','\x20','\x32','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x8','\x0','\x44','\x4e','\x53','\x45','\x52','\x56',
 '\x45','\x52','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x8','\x0','\x43','\x58','\x4f','\x53','\x44','\x32','\x32','\x30','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0'
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {'C',' ',' ',' '}};


static const short sqlIsLiteral   = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "CXOSD220.sqx"
//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%365B049F0399.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%365B049F0399.cm

//## begin module%365B049F0399.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%365B049F0399.cp

//## Module: CXOSD220%365B049F0399; Package body
//## Subsystem: D2DLL%3597E8A6029B
// .
//## Source file: C:\Pvcswork\Dn\Server\Library\D2DLL\CXOSD220.sqx

//## begin module%365B049F0399.additionalIncludes preserve=no
//## end module%365B049F0399.additionalIncludes

//## begin module%365B049F0399.includes preserve=yes
// $Date:   Aug 30 2016 15:11:02  $ $Author:   e1009652  $ $Revision:   1.36  $
#include "CXODRU24.hpp"
#include "CXODRU29.hpp"
#include "CXODMN05.hpp"
#include "CXODDB01.hpp"
#include "CXODIF03.hpp"
#include "CXODIF08.hpp"
#include "CXODIF16.hpp"
//## end module%365B049F0399.includes

#ifndef CXOSD220_h
#include "CXODD220.hpp"
#endif
//## begin module%365B049F0399.declarations preserve=no
//## end module%365B049F0399.declarations

//## begin module%365B049F0399.additionalDeclarations preserve=yes
#ifdef MVS

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
struct sqlca sqlca;


#line 42 "CXOSD220.sqx"

#else
#include "sqlca.h"
extern struct sqlca sqlca;
#endif


/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 48 "CXOSD220.sqx"

   char PD_TABLE_NAME[19];
   short  PD_PART_NUMBER;
   char PD_PART_STATUS[2];
   char PD_TSTAMP_START[17];
   char PD_TSTAMP_END[17];
   char PD_TSTAMP_UPDATE[17];
   short  PD_PARTITIONS;
   char PD_QUALIFIER[9];
   char PD_DBNAME[9];
   short PD_INDICATOR;

/*
EXEC SQL END DECLARE SECTION;
*/

#line 59 "CXOSD220.sqx"

//## end module%365B049F0399.additionalDeclarations


//## Modelname: DataNavigator Foundation::DB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin db2database%346CAA2702B3.initialDeclarations preserve=yes
//## end db2database%346CAA2702B3.initialDeclarations

// Class db2database::DB2PartitionDeallocator


DB2PartitionDeallocator::DB2PartitionDeallocator()
  //## begin DB2PartitionDeallocator::DB2PartitionDeallocator%34C1095E03BB_const.hasinit preserve=no
  //## end DB2PartitionDeallocator::DB2PartitionDeallocator%34C1095E03BB_const.hasinit
  //## begin DB2PartitionDeallocator::DB2PartitionDeallocator%34C1095E03BB_const.initialization preserve=yes
  //## end DB2PartitionDeallocator::DB2PartitionDeallocator%34C1095E03BB_const.initialization
{
  //## begin db2database::DB2PartitionDeallocator::DB2PartitionDeallocator%34C1095E03BB_const.body preserve=yes
   memcpy(m_sID,"D220",4);
  //## end db2database::DB2PartitionDeallocator::DB2PartitionDeallocator%34C1095E03BB_const.body
}


DB2PartitionDeallocator::~DB2PartitionDeallocator()
{
  //## begin db2database::DB2PartitionDeallocator::~DB2PartitionDeallocator%34C1095E03BB_dest.body preserve=yes
  //## end db2database::DB2PartitionDeallocator::~DB2PartitionDeallocator%34C1095E03BB_dest.body
}



//## Other Operations (implementation)
bool DB2PartitionDeallocator::available (int* piPartitionCount)
{
  //## begin db2database::DB2PartitionDeallocator::available%34C3C60401B5.body preserve=yes
   CriticalSection hCriticalSection("CATALOG");
   if (Database::instance()->getDormant())
      Database::instance()->connect();
   strcpy(PD_QUALIFIER,Database::instance()->qualifier().c_str());
   strcpy(PD_DBNAME,Database::instance()->getName().c_str());
   if(m_strTableName.length() < sizeof(PD_TABLE_NAME))
      strcpy(PD_TABLE_NAME,m_strTableName.c_str());
   m_nState = DB2PartitionDeallocator::START;
   int iRetry = 0;
   while (iRetry < 5)
   {
      switch (m_nState)
      {
         case DB2PartitionDeallocator::START:
            m_nState = selectCatalog();
            *piPartitionCount = PD_PARTITIONS;
            break;
         case DB2PartitionDeallocator::SELECT:
            m_nState = selectCount();
            break;
         case DB2PartitionDeallocator::SUCCESS:
            *piPartitionCount -= PD_PARTITIONS;
            Database::instance()->commit();
            return true;
         case DB2PartitionDeallocator::DEADLOCK_TIMEOUT:
            UseCase::add("DEADLOCK");
            Database::instance()->rollback();
            iRetry++;
            m_nState = DB2PartitionDeallocator::START;
            break;
         case DB2PartitionDeallocator::DATABASE_FAILURE:
            UseCase::add("DBERROR");
            Database::instance()->rollback();
            return false;
         case DB2PartitionDeallocator::DATABASE_CONNECTION_ERROR:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            return false;
      }
   }
   UseCase::setSuccess(false);
   Database::instance()->rollback();
   return false;
  //## end db2database::DB2PartitionDeallocator::available%34C3C60401B5.body
}

bool DB2PartitionDeallocator::deallocate (int iPartitionNumber)
{
  //## begin db2database::DB2PartitionDeallocator::deallocate%34C3C60802DD.body preserve=yes
   UseCase hUseCase("DR","## DR18 FREE PARTITION");
   CriticalSection hCriticalSection("CATALOG");
   if (Database::instance()->getDormant())
      Database::instance()->connect();
   if(m_strTableName.length() < sizeof(PD_TABLE_NAME))
      strcpy(PD_TABLE_NAME,m_strTableName.c_str());
   PD_PART_NUMBER = iPartitionNumber;
   strcpy(PD_TSTAMP_START," ");
   strcpy(PD_TSTAMP_END," ");
   IString strDate;
   DateTime hDateTime;
   hDateTime.setCurrent(strDate);
   strcpy(PD_TSTAMP_UPDATE,strDate);
   m_nState = DB2PartitionDeallocator::START;
   int iRetry = 0;
   while (iRetry < 5)
   {
      switch (m_nState)
      {
         case DB2PartitionDeallocator::START:
            m_nState = update();
            break;
         case DB2PartitionDeallocator::SUCCESS:
            Database::instance()->commit();
            notify();
            return true;
         case DB2PartitionDeallocator::DEADLOCK_TIMEOUT:
            UseCase::add("DEADLOCK");
            Database::instance()->rollback();
            iRetry++;
            m_nState = DB2PartitionDeallocator::START;
            break;
         case DB2PartitionDeallocator::DATABASE_FAILURE:
            UseCase::add("DBERROR");
            Database::instance()->rollback();
            return false;
         case DB2PartitionDeallocator::DATABASE_CONNECTION_ERROR:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            return false;
      }
   }
   Database::instance()->rollback();
   return false;
  //## end db2database::DB2PartitionDeallocator::deallocate%34C3C60802DD.body
}

bool DB2PartitionDeallocator::oldest (IString& strTimestampStart, IString& strTimestampEnd, int* piPartitionNumber)
{
  //## begin db2database::DB2PartitionDeallocator::oldest%34C3C60D0096.body preserve=yes
   CriticalSection hCriticalSection("CATALOG");
   if (Database::instance()->getDormant())
      Database::instance()->connect();
   if(m_strTableName.length() < sizeof(PD_TABLE_NAME))
      strcpy(PD_TABLE_NAME,m_strTableName.c_str());
   m_nState = DB2PartitionDeallocator::START;
   int iRetry = 0;
   while (iRetry < 5)
   {
      switch (m_nState)
      {
         case DB2PartitionDeallocator::START:
            m_nState = selectOldest();
            break;
         case DB2PartitionDeallocator::SUCCESS:
            strTimestampStart = PD_TSTAMP_START;
            strTimestampEnd = PD_TSTAMP_END;
            *piPartitionNumber = PD_PART_NUMBER;
            Database::instance()->commit();
            return true;
         case DB2PartitionDeallocator::DEADLOCK_TIMEOUT:
            UseCase::add("DEADLOCK");
            Database::instance()->rollback();
            iRetry++;
            m_nState = DB2PartitionDeallocator::START;
            break;
         case DB2PartitionDeallocator::DATABASE_FAILURE:
            UseCase::add("DBERROR");
            Database::instance()->rollback();
            return false;
         case DB2PartitionDeallocator::DATABASE_CONNECTION_ERROR:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            return false;
      }
   }
   Database::instance()->rollback();
   return false;
  //## end db2database::DB2PartitionDeallocator::oldest%34C3C60D0096.body
}

DB2PartitionDeallocator::State DB2PartitionDeallocator::selectCatalog ()
{
  //## begin db2database::DB2PartitionDeallocator::selectCatalog%3D36BFE00177.body preserve=yes
   Trace::put("selectCatalog");
   Trace::put(PD_QUALIFIER);
   Trace::put(PD_DBNAME);
   Trace::put(PD_TABLE_NAME);
   PD_PARTITIONS = 0;
   sqlca.sqlcode = 0;
   string strPartitions;
   if (Extract::instance()->getSpec("PARTS   ",strPartitions))
      PD_PARTITIONS = atoi(strPartitions.c_str());
   if (PD_PARTITIONS == 0)
   {
#ifdef MVS

      XXEC SQL
         SELECT
               PARTITIONS
            INTO
               :PD_PARTITIONS
            FROM SYSIBM.SYSTABLES TA
            INNER JOIN SYSIBM.SYSTABLESPACE TS
               ON  TA.DBNAME = TS.DBNAME
               AND TA.TSNAME = TS.NAME
            WHERE TA.CREATOR = :PD_QUALIFIER
              AND TA.DBNAME = :PD_DBNAME
              AND TA.NAME = :PD_TABLE_NAME;
#else
      PD_PARTITIONS = 32;
#endif
   }
   switch (sqlca.sqlcode)
   {
      case 0:
         return DB2PartitionDeallocator::SELECT;
      case -911:
      case -913:
         return DB2PartitionDeallocator::DEADLOCK_TIMEOUT;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         return DB2PartitionDeallocator::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"selectCatalog");
         if (sqlca.sqlcode > 0)
           return DB2PartitionDeallocator::SELECT;
   }
   return DB2PartitionDeallocator::DATABASE_FAILURE;
  //## end db2database::DB2PartitionDeallocator::selectCatalog%3D36BFE00177.body
}

DB2PartitionDeallocator::State DB2PartitionDeallocator::selectCount ()
{
  //## begin db2database::DB2PartitionDeallocator::selectCount%3D36BFEC00DA.body preserve=yes
   PD_PARTITIONS = 0;
   
/*
EXEC SQL
      SELECT
         COUNT(*)
      INTO
         :PD_PARTITIONS INDICATOR :PD_INDICATOR
      FROM PARTITION_CONTROL
      WHERE TABLE_NAME = :PD_TABLE_NAME
        AND PART_STAT <> 'R';
*/

{
#line 300 "CXOSD220.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 300 "CXOSD220.sqx"
  sqlaaloc(2,1,1,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 300 "CXOSD220.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 19;
#line 300 "CXOSD220.sqx"
      sql_setdlist[0].sqldata = (void*)PD_TABLE_NAME;
#line 300 "CXOSD220.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 300 "CXOSD220.sqx"
      sqlasetdata(2,0,1,sql_setdlist,0L,0L);
    }
#line 300 "CXOSD220.sqx"
  sqlaaloc(3,1,2,0L);
    {
      struct sqla_setdata_list sql_setdlist[1];
#line 300 "CXOSD220.sqx"
      sql_setdlist[0].sqltype = 501; sql_setdlist[0].sqllen = 2;
#line 300 "CXOSD220.sqx"
      sql_setdlist[0].sqldata = (void*)&PD_PARTITIONS;
#line 300 "CXOSD220.sqx"
      sql_setdlist[0].sqlind = &PD_INDICATOR;
#line 300 "CXOSD220.sqx"
      sqlasetdata(3,0,1,sql_setdlist,0L,0L);
    }
#line 300 "CXOSD220.sqx"
  sqlacall((unsigned short)24,1,2,3,0L);
#line 300 "CXOSD220.sqx"
  sqlastop(0L);
}

#line 300 "CXOSD220.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
      case 100:
         return DB2PartitionDeallocator::SUCCESS;
      case -911:
      case -913:
         return DB2PartitionDeallocator::DEADLOCK_TIMEOUT;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         return DB2PartitionDeallocator::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"selectCount");
         if (sqlca.sqlcode > 0)
           return DB2PartitionDeallocator::SUCCESS;
   }
   return DB2PartitionDeallocator::DATABASE_FAILURE;
  //## end db2database::DB2PartitionDeallocator::selectCount%3D36BFEC00DA.body
}

DB2PartitionDeallocator::State DB2PartitionDeallocator::selectOldest ()
{
  //## begin db2database::DB2PartitionDeallocator::selectOldest%3D36BFEC0203.body preserve=yes
   
/*
EXEC SQL
      SELECT
         TSTAMP_START,
         TSTAMP_END,
         PART_NUMBER
      INTO
         :PD_TSTAMP_START,
         :PD_TSTAMP_END,
         :PD_PART_NUMBER
      FROM PARTITION_CONTROL
      WHERE TABLE_NAME = :PD_TABLE_NAME
        AND TSTAMP_END = (SELECT MIN(TSTAMP_END)
                             FROM PARTITION_CONTROL
                             WHERE TABLE_NAME = :PD_TABLE_NAME
                               AND PART_STAT = 'A');
*/

{
#line 342 "CXOSD220.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 342 "CXOSD220.sqx"
  sqlaaloc(2,2,3,0L);
    {
      struct sqla_setdata_list sql_setdlist[2];
#line 342 "CXOSD220.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 19;
#line 342 "CXOSD220.sqx"
      sql_setdlist[0].sqldata = (void*)PD_TABLE_NAME;
#line 342 "CXOSD220.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 342 "CXOSD220.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 19;
#line 342 "CXOSD220.sqx"
      sql_setdlist[1].sqldata = (void*)PD_TABLE_NAME;
#line 342 "CXOSD220.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 342 "CXOSD220.sqx"
      sqlasetdata(2,0,2,sql_setdlist,0L,0L);
    }
#line 342 "CXOSD220.sqx"
  sqlaaloc(3,3,4,0L);
    {
      struct sqla_setdata_list sql_setdlist[3];
#line 342 "CXOSD220.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 17;
#line 342 "CXOSD220.sqx"
      sql_setdlist[0].sqldata = (void*)PD_TSTAMP_START;
#line 342 "CXOSD220.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 342 "CXOSD220.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 17;
#line 342 "CXOSD220.sqx"
      sql_setdlist[1].sqldata = (void*)PD_TSTAMP_END;
#line 342 "CXOSD220.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 342 "CXOSD220.sqx"
      sql_setdlist[2].sqltype = 500; sql_setdlist[2].sqllen = 2;
#line 342 "CXOSD220.sqx"
      sql_setdlist[2].sqldata = (void*)&PD_PART_NUMBER;
#line 342 "CXOSD220.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 342 "CXOSD220.sqx"
      sqlasetdata(3,0,3,sql_setdlist,0L,0L);
    }
#line 342 "CXOSD220.sqx"
  sqlacall((unsigned short)24,2,2,3,0L);
#line 342 "CXOSD220.sqx"
  sqlastop(0L);
}

#line 342 "CXOSD220.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         return DB2PartitionDeallocator::SUCCESS;
      case -911:
      case -913:
         return DB2PartitionDeallocator::DEADLOCK_TIMEOUT;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         return DB2PartitionDeallocator::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"selectOldest");
         if (sqlca.sqlcode > 0)
           return DB2PartitionDeallocator::SUCCESS;
   }
   return DB2PartitionDeallocator::DATABASE_FAILURE;
  //## end db2database::DB2PartitionDeallocator::selectOldest%3D36BFEC0203.body
}

DB2PartitionDeallocator::State DB2PartitionDeallocator::update ()
{
  //## begin db2database::DB2PartitionDeallocator::update%3D36BFEC030D.body preserve=yes
   
/*
EXEC SQL
      UPDATE PARTITION_CONTROL
         SET
            PART_STAT = 'R',
            TSTAMP_START = :PD_TSTAMP_START,
            TSTAMP_END = :PD_TSTAMP_END,
            TSTAMP_UPDATE = :PD_TSTAMP_UPDATE
         WHERE TABLE_NAME = :PD_TABLE_NAME
           AND PART_NUMBER = :PD_PART_NUMBER
           AND PART_STAT = 'A';
*/

{
#line 378 "CXOSD220.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 378 "CXOSD220.sqx"
  sqlaaloc(2,5,5,0L);
    {
      struct sqla_setdata_list sql_setdlist[5];
#line 378 "CXOSD220.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 17;
#line 378 "CXOSD220.sqx"
      sql_setdlist[0].sqldata = (void*)PD_TSTAMP_START;
#line 378 "CXOSD220.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 378 "CXOSD220.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 17;
#line 378 "CXOSD220.sqx"
      sql_setdlist[1].sqldata = (void*)PD_TSTAMP_END;
#line 378 "CXOSD220.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 378 "CXOSD220.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 17;
#line 378 "CXOSD220.sqx"
      sql_setdlist[2].sqldata = (void*)PD_TSTAMP_UPDATE;
#line 378 "CXOSD220.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 378 "CXOSD220.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 19;
#line 378 "CXOSD220.sqx"
      sql_setdlist[3].sqldata = (void*)PD_TABLE_NAME;
#line 378 "CXOSD220.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 378 "CXOSD220.sqx"
      sql_setdlist[4].sqltype = 500; sql_setdlist[4].sqllen = 2;
#line 378 "CXOSD220.sqx"
      sql_setdlist[4].sqldata = (void*)&PD_PART_NUMBER;
#line 378 "CXOSD220.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 378 "CXOSD220.sqx"
      sqlasetdata(2,0,5,sql_setdlist,0L,0L);
    }
#line 378 "CXOSD220.sqx"
  sqlacall((unsigned short)24,3,2,0,0L);
#line 378 "CXOSD220.sqx"
  sqlastop(0L);
}

#line 378 "CXOSD220.sqx"


   switch (sqlca.sqlcode)
   {
      case 0:
         return DB2PartitionDeallocator::SUCCESS;
      case 100:
         break;
      case -911:
      case -913:
         return DB2PartitionDeallocator::DEADLOCK_TIMEOUT;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         return DB2PartitionDeallocator::DATABASE_CONNECTION_ERROR;
      default:
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"update");
         if (sqlca.sqlcode > 0)
           return DB2PartitionDeallocator::SUCCESS;
   }
   return DB2PartitionDeallocator::DATABASE_FAILURE;
  //## end db2database::DB2PartitionDeallocator::update%3D36BFEC030D.body
}

// Additional Declarations
  //## begin db2database::DB2PartitionDeallocator%34C1095E03BB.declarations preserve=yes
  //## end db2database::DB2PartitionDeallocator%34C1095E03BB.declarations

} // namespace dndb2database

//## begin module%365B049F0399.epilog preserve=yes
//## end module%365B049F0399.epilog
