//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40719CE400EA.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40719CE400EA.cm

//## begin module%40719CE400EA.cp preserve=no
//	Copyright (c) 1998 - 2003
//	eFunds Corporation
//## end module%40719CE400EA.cp

//## Module: CXOSD245%40719CE400EA; Package specification
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXODD245.hpp

#ifndef CXOSD245_h
#define CXOSD245_h 1

//## begin module%40719CE400EA.additionalIncludes preserve=no
//## end module%40719CE400EA.additionalIncludes

//## begin module%40719CE400EA.includes preserve=yes
//## end module%40719CE400EA.includes

#ifndef CXOSST35_h
#include "CXODST35.hpp"
#endif
//## begin module%40719CE400EA.declarations preserve=no
//## end module%40719CE400EA.declarations

//## begin module%40719CE400EA.additionalDeclarations preserve=yes
//## end module%40719CE400EA.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

//## begin dndb2database::DB2AggregatorPOSRisk%40719C640138.preface preserve=yes
//## end dndb2database::DB2AggregatorPOSRisk%40719C640138.preface

//## Class: DB2AggregatorPOSRisk%40719C640138
//## Category: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
//## Subsystem: D2DLL%3597E8A6029B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4072F1960399;database::Database { -> F}
//## Uses: <unnamed>%4072F22C029F;monitor::UseCase { -> F}

class DllExport DB2AggregatorPOSRisk : public settlement::AggregatorPOSRisk  //## Inherits: <unnamed>%40719C9203C8
{
  //## begin dndb2database::DB2AggregatorPOSRisk%40719C640138.initialDeclarations preserve=yes
  //## end dndb2database::DB2AggregatorPOSRisk%40719C640138.initialDeclarations

  public:
    //## Constructors (generated)
      DB2AggregatorPOSRisk();

    //## Destructor (generated)
      virtual ~DB2AggregatorPOSRisk();


    //## Other Operations (specified)
      //## Operation: tableInsert%407416F501A5
      virtual bool tableInsert ();

      //## Operation: tableUpdate%4074170001C5
      virtual int tableUpdate ();

    // Additional Public Declarations
      //## begin dndb2database::DB2AggregatorPOSRisk%40719C640138.public preserve=yes
      //## end dndb2database::DB2AggregatorPOSRisk%40719C640138.public

  protected:
    // Additional Protected Declarations
      //## begin dndb2database::DB2AggregatorPOSRisk%40719C640138.protected preserve=yes
      //## end dndb2database::DB2AggregatorPOSRisk%40719C640138.protected

  private:

    //## Other Operations (specified)
      //## Operation: checkResult%4072EFAC009C
      int checkResult ();

    // Additional Private Declarations
      //## begin dndb2database::DB2AggregatorPOSRisk%40719C640138.private preserve=yes
      //## end dndb2database::DB2AggregatorPOSRisk%40719C640138.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dndb2database::DB2AggregatorPOSRisk%40719C640138.implementation preserve=yes
      //## end dndb2database::DB2AggregatorPOSRisk%40719C640138.implementation

};

//## begin dndb2database::DB2AggregatorPOSRisk%40719C640138.postscript preserve=yes
//## end dndb2database::DB2AggregatorPOSRisk%40719C640138.postscript

} // namespace dndb2database

//## begin module%40719CE400EA.epilog preserve=yes
//## end module%40719CE400EA.epilog


#endif
