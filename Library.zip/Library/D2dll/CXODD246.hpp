//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4091105E0196.cm preserve=no
//	$Date:   Aug 26 2009 15:39:24  $ $Author:   D02405  $
//	$Revision:   1.4  $
//## end module%4091105E0196.cm

//## begin module%4091105E0196.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%4091105E0196.cp

//## Module: CXOSD246%4091105E0196; Package specification
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXODD246.hpp

#ifndef CXOSD246_h
#define CXOSD246_h 1

//## begin module%4091105E0196.additionalIncludes preserve=no
//## end module%4091105E0196.additionalIncludes

//## begin module%4091105E0196.includes preserve=yes
//## end module%4091105E0196.includes

#ifndef CXOSST34_h
#include "CXODST34.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class Accumulator;

} // namespace settlement

//## begin module%4091105E0196.declarations preserve=no
//## end module%4091105E0196.declarations

//## begin module%4091105E0196.additionalDeclarations preserve=yes
//## end module%4091105E0196.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

//## begin dndb2database::DB2AggregatorMIS%409110150213.preface preserve=yes
//## end dndb2database::DB2AggregatorMIS%409110150213.preface

//## Class: DB2AggregatorMIS%409110150213
//## Category: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
//## Subsystem: D2DLL%3597E8A6029B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4091114F037A;database::Database { -> F}
//## Uses: <unnamed>%409111660119;monitor::UseCase { -> F}
//## Uses: <unnamed>%4091999202CE;settlement::FinancialTransaction { -> F}
//## Uses: <unnamed>%409199C60399;settlement::Accumulator { -> F}

class DllExport DB2AggregatorMIS : public settlement::AggregatorMIS  //## Inherits: <unnamed>%40913758038A
{
  //## begin dndb2database::DB2AggregatorMIS%409110150213.initialDeclarations preserve=yes
  //## end dndb2database::DB2AggregatorMIS%409110150213.initialDeclarations

  public:
    //## Constructors (generated)
      DB2AggregatorMIS();

    //## Destructor (generated)
      virtual ~DB2AggregatorMIS();


    //## Other Operations (specified)
      //## Operation: tableInsert%4091118703A9
      virtual bool tableInsert (bool bSubtractFromTotals = false);

      //## Operation: tableUpdate%4091119400AB
      virtual int tableUpdate (bool bSubtractFromTotals = false);

    // Additional Public Declarations
      //## begin dndb2database::DB2AggregatorMIS%409110150213.public preserve=yes
      //## end dndb2database::DB2AggregatorMIS%409110150213.public

  protected:
    // Additional Protected Declarations
      //## begin dndb2database::DB2AggregatorMIS%409110150213.protected preserve=yes
      //## end dndb2database::DB2AggregatorMIS%409110150213.protected

  private:

    //## Other Operations (specified)
      //## Operation: checkResult%40911182029F
      int checkResult ();

      //## Operation: lockTables%42261ED90242
      void lockTables ();

    // Additional Private Declarations
      //## begin dndb2database::DB2AggregatorMIS%409110150213.private preserve=yes
      //## end dndb2database::DB2AggregatorMIS%409110150213.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Transaction%42261C12029F
      //## begin dndb2database::DB2AggregatorMIS::Transaction%42261C12029F.attr preserve=no  private: int {U} -1
      int m_lTransaction;
      //## end dndb2database::DB2AggregatorMIS::Transaction%42261C12029F.attr

    // Additional Implementation Declarations
      //## begin dndb2database::DB2AggregatorMIS%409110150213.implementation preserve=yes
      //## end dndb2database::DB2AggregatorMIS%409110150213.implementation

};

//## begin dndb2database::DB2AggregatorMIS%409110150213.postscript preserve=yes
//## end dndb2database::DB2AggregatorMIS%409110150213.postscript

} // namespace dndb2database

//## begin module%4091105E0196.epilog preserve=yes
//## end module%4091105E0196.epilog


#endif
