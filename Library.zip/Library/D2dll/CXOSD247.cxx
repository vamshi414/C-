static char sqla_program_id[292] = 
{
 '\xac','\x0','\x41','\x45','\x41','\x56','\x41','\x49','\x30','\x41','\x33','\x34','\x52','\x48','\x49','\x6f','\x30','\x31','\x31','\x31',
 '\x31','\x20','\x32','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x8','\x0','\x44','\x4e','\x53','\x45','\x52','\x56',
 '\x45','\x52','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x8','\x0','\x43','\x58','\x4f','\x53','\x44','\x32','\x34','\x37','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0'
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {'C',' ',' ',' '}};


static const short sqlIsLiteral   = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "CXOSD247.sqx"
//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5E826585020E.cm preserve=no
//   $Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//   $Revision:   1.27  $
//## end module%5E826585020E.cm

//## begin module%5E826585020E.cp preserve=no
//   Copyright (c) 1997 - 2012
//   FIS
//## end module%5E826585020E.cp

//## Module: CXOSD247%5E826585020E; Package body
//## Subsystem: D2DLL%3597E8A6029B
//   .
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\D2dll\CXOSD247.sqx

//## begin module%5E826585020E.additionalIncludes preserve=no
//## end module%5E826585020E.additionalIncludes

//## begin module%5E826585020E.includes preserve=yes
#include "CXODIF16.hpp"
//## end module%5E826585020E.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
#ifndef CXOSST03_h
#include "CXODST03.hpp"
#endif
#ifndef CXOSST08_h
#include "CXODST08.hpp"
#endif
#ifndef CXOSD247_h
#include "CXODD247.hpp"
#endif


//## begin module%5E826585020E.declarations preserve=no
//## end module%5E826585020E.declarations

//## begin module%5E826585020E.additionalDeclarations preserve=yes
#ifdef MVS

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
struct sqlca sqlca;


#line 53 "CXOSD247.sqx"

#else
#include "sqlca.h"
extern struct sqlca sqlca;
#endif

/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 58 "CXOSD247.sqx"

   char AMS_ATTRIBUTES[32];
   char AMS1_TSTAMP_START[512][11];
   char AMS1_INTERVAL_TYPE[512][2];
   sqlint32 AMS1_T_FIN_ENTITY_ID[512];
   char AMS1_T_MIS_MCC[512][5];
   sqlint32 AMS1_CATEGORY_ID[512];
   double AMS1_AMT_TRAN[512];
   double AMS1_AMT_SURCHARGE[512];
   double AMS1_AMT_POS_REIMBURSE[512];
   double AMS1_CASHBACK_AMT[512];
   sqlint32 AMS1_TRAN_COUNT[512];
   sqlint32 AMS1_PARTITION_KEY[512];
   double AMS1_TIME_AT_ISS[512];
   double AMS1_TIME_AT_RQST_SWTCH[512];
   double AMS1_AMT_FEE[512];
   sqlint32 AMS1_SYNC_INTERVAL_NO[512];
   char AMS1_BIN[512][12];
   sqlint32 AMS1_ROWS;
   struct
   {
      short length;
      char data[2048];
   } AMS1_MERGE;
   char AMS2_TSTAMP_START[512][11];
   char AMS2_INTERVAL_TYPE[512][2];
   sqlint32 AMS2_T_FIN_ENTITY_ID[512];
   sqlint32 AMS2_T_FIN_ENTITY_ID_2[512];
   char AMS2_T_MIS_MCC[512][5];
   sqlint32 AMS2_CATEGORY_ID[512];
   double AMS2_AMT_TRAN[512];
   double AMS2_AMT_SURCHARGE[512];
   double AMS2_AMT_POS_REIMBURSE[512];
   double AMS2_CASHBACK_AMT[512];
   sqlint32 AMS2_TRAN_COUNT[512];
   sqlint32 AMS2_PARTITION_KEY[512];
   double AMS2_TIME_AT_ISS[512];
   double AMS2_TIME_AT_RQST_SWTCH[512];
   double AMS2_AMT_FEE[512];
   sqlint32 AMS2_SYNC_INTERVAL_NO[512];
   char AMS2_BIN[512][12];
   sqlint32 AMS2_ROWS;
   struct
   {
      short length;
      char data[2048];
   } AMS2_MERGE;

/*
EXEC SQL END DECLARE SECTION;
*/

#line 105 "CXOSD247.sqx"

//## end module%5E826585020E.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

// Class dndb2database::DB2AggregatorMIS2

DB2AggregatorMIS2::DB2AggregatorMIS2()
  //## begin DB2AggregatorMIS2::DB2AggregatorMIS2%5E826410015B_const.hasinit preserve=no
  //## end DB2AggregatorMIS2::DB2AggregatorMIS2%5E826410015B_const.hasinit
  //## begin DB2AggregatorMIS2::DB2AggregatorMIS2%5E826410015B_const.initialization preserve=yes
  //## end DB2AggregatorMIS2::DB2AggregatorMIS2%5E826410015B_const.initialization
{
  //## begin dndb2database::DB2AggregatorMIS2::DB2AggregatorMIS2%5E826410015B_const.body preserve=yes
   memcpy(m_sID,"D247",4);
#ifdef MVS
   strcpy(AMS_ATTRIBUTES,"FOR MULTIPLE ROWS");
#endif
   string strQualifier(Database::instance()->qualifier());
   AMS1_ROWS = 0;
   memcpy(AMS1_MERGE.data,"MERGE INTO ",11);
   memcpy(AMS1_MERGE.data + 11,strQualifier.data(),strQualifier.length());
   strcpy(AMS1_MERGE.data + 11 + strQualifier.length(),".T_MIS_TOTAL AS A USING"
      " (VALUES (?,?,?,NULL,?,?,?,?,?,?,?,?,?,?,?,?,?)"
#ifdef MVS
      " FOR ? ROWS"
#endif
      ") AS B"
      " (TSTAMP_START,INTERVAL_TYPE,T_FIN_ENTITY_ID,T_FIN_ENTITY_ID_2,"
      "T_MIS_MCC,CATEGORY_ID,PARTITION_KEY,AMT_TRAN,AMT_SURCHARGE,"
      "AMT_POS_REIMBURSE,CASHBACK_AMT,TRAN_COUNT,TIME_AT_ISS,"
      "TIME_AT_RQST_SWTCH,AMT_FEE,SYNC_INTERVAL_NO,BIN) ON"
      " A.TSTAMP_START = B.TSTAMP_START"
      " AND A.T_FIN_ENTITY_ID = B.T_FIN_ENTITY_ID"
      " AND A.T_FIN_ENTITY_ID_2 IS NULL"
      " AND A.T_MIS_MCC = B.T_MIS_MCC"
      " AND A.CATEGORY_ID = B.CATEGORY_ID"
      " AND A.INTERVAL_TYPE = B.INTERVAL_TYPE"
      " AND A.SYNC_INTERVAL_NO = B.SYNC_INTERVAL_NO"
      " AND A.BIN = B.BIN"
      " WHEN MATCHED THEN UPDATE SET"
      " A.AMT_TRAN = A.AMT_TRAN + B.AMT_TRAN,"
      " A.AMT_SURCHARGE = A.AMT_SURCHARGE + B.AMT_SURCHARGE,"
      " A.AMT_POS_REIMBURSE = A.AMT_POS_REIMBURSE + B.AMT_POS_REIMBURSE,"
      " A.CASHBACK_AMT = A.CASHBACK_AMT + B.CASHBACK_AMT,"
      " A.TRAN_COUNT = A.TRAN_COUNT + B.TRAN_COUNT,"
      " A.TIME_AT_ISS = A.TIME_AT_ISS + B.TIME_AT_ISS,"
      " A.TIME_AT_RQST_SWTCH = A.TIME_AT_RQST_SWTCH + B.TIME_AT_RQST_SWTCH,"
      " A.AMT_FEE = A.AMT_FEE + B.AMT_FEE"
      " WHEN NOT MATCHED THEN INSERT"
      " (TSTAMP_START,INTERVAL_TYPE,T_FIN_ENTITY_ID,T_FIN_ENTITY_ID_2,"
      "T_MIS_MCC,CATEGORY_ID,PARTITION_KEY,AMT_TRAN,AMT_SURCHARGE,"
      "AMT_POS_REIMBURSE,CASHBACK_AMT,TRAN_COUNT,TIME_AT_ISS,"
      "TIME_AT_RQST_SWTCH,AMT_FEE,SYNC_INTERVAL_NO,BIN) VALUES"
      " (B.TSTAMP_START,B.INTERVAL_TYPE,B.T_FIN_ENTITY_ID,B.T_FIN_ENTITY_ID_2,"
      "B.T_MIS_MCC,B.CATEGORY_ID,B.PARTITION_KEY,B.AMT_TRAN,B.AMT_SURCHARGE,"
      "B.AMT_POS_REIMBURSE,B.CASHBACK_AMT,B.TRAN_COUNT,B.TIME_AT_ISS,"
      "B.TIME_AT_RQST_SWTCH,B.AMT_FEE,B.SYNC_INTERVAL_NO,B.BIN)"
#ifdef MVS
      " NOT ATOMIC CONTINUE ON SQLEXCEPTION"
#endif
   );
   AMS1_MERGE.length = strlen(AMS1_MERGE.data);
   AMS2_ROWS = 0;
   memcpy(AMS2_MERGE.data,"MERGE INTO ",11);
   memcpy(AMS2_MERGE.data + 11,strQualifier.data(),strQualifier.length());
   strcpy(AMS2_MERGE.data + 11 + strQualifier.length(),".T_MIS_TOTAL AS A USING"
      " (VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
#ifdef MVS
      " FOR ? ROWS"
#endif
      ") AS B"
      " (TSTAMP_START,INTERVAL_TYPE,T_FIN_ENTITY_ID,T_FIN_ENTITY_ID_2,"
      "T_MIS_MCC,CATEGORY_ID,PARTITION_KEY,AMT_TRAN,AMT_SURCHARGE,"
      "AMT_POS_REIMBURSE,CASHBACK_AMT,TRAN_COUNT,TIME_AT_ISS,"
      "TIME_AT_RQST_SWTCH,AMT_FEE,SYNC_INTERVAL_NO,BIN) ON"
      " A.TSTAMP_START = B.TSTAMP_START"
      " AND A.T_FIN_ENTITY_ID = B.T_FIN_ENTITY_ID"
      " AND A.T_FIN_ENTITY_ID_2 = B.T_FIN_ENTITY_ID_2"
      " AND A.T_MIS_MCC = B.T_MIS_MCC"
      " AND A.CATEGORY_ID = B.CATEGORY_ID"
      " AND A.INTERVAL_TYPE = B.INTERVAL_TYPE"
      " AND A.SYNC_INTERVAL_NO = B.SYNC_INTERVAL_NO"
      " AND A.BIN = B.BIN"
      " WHEN MATCHED THEN UPDATE SET"
      " A.AMT_TRAN = A.AMT_TRAN + B.AMT_TRAN,"
      " A.AMT_SURCHARGE = A.AMT_SURCHARGE + B.AMT_SURCHARGE,"
      " A.AMT_POS_REIMBURSE = A.AMT_POS_REIMBURSE + B.AMT_POS_REIMBURSE,"
      " A.CASHBACK_AMT = A.CASHBACK_AMT + B.CASHBACK_AMT,"
      " A.TRAN_COUNT = A.TRAN_COUNT + B.TRAN_COUNT,"
      " A.TIME_AT_ISS = A.TIME_AT_ISS + B.TIME_AT_ISS,"
      " A.TIME_AT_RQST_SWTCH = A.TIME_AT_RQST_SWTCH + B.TIME_AT_RQST_SWTCH,"
      " A.AMT_FEE = A.AMT_FEE + B.AMT_FEE"
      " WHEN NOT MATCHED THEN INSERT"
      " (TSTAMP_START,INTERVAL_TYPE,T_FIN_ENTITY_ID,T_FIN_ENTITY_ID_2,"
      "T_MIS_MCC,CATEGORY_ID,PARTITION_KEY,AMT_TRAN,AMT_SURCHARGE,"
      "AMT_POS_REIMBURSE,CASHBACK_AMT,TRAN_COUNT,TIME_AT_ISS,"
      "TIME_AT_RQST_SWTCH,AMT_FEE,SYNC_INTERVAL_NO,BIN) VALUES"
      " (B.TSTAMP_START,B.INTERVAL_TYPE,B.T_FIN_ENTITY_ID,B.T_FIN_ENTITY_ID_2,"
      "B.T_MIS_MCC,B.CATEGORY_ID,B.PARTITION_KEY,B.AMT_TRAN,B.AMT_SURCHARGE,"
      "B.AMT_POS_REIMBURSE,B.CASHBACK_AMT,B.TRAN_COUNT,B.TIME_AT_ISS,"
      "B.TIME_AT_RQST_SWTCH,B.AMT_FEE,B.SYNC_INTERVAL_NO,B.BIN)"
#ifdef MVS
      " NOT ATOMIC CONTINUE ON SQLEXCEPTION"
#endif
   );
   AMS2_MERGE.length = strlen(AMS2_MERGE.data);
  //## end dndb2database::DB2AggregatorMIS2::DB2AggregatorMIS2%5E826410015B_const.body
}


DB2AggregatorMIS2::~DB2AggregatorMIS2()
{
  //## begin dndb2database::DB2AggregatorMIS2::~DB2AggregatorMIS2%5E826410015B_dest.body preserve=yes
  //## end dndb2database::DB2AggregatorMIS2::~DB2AggregatorMIS2%5E826410015B_dest.body
}



//## Other Operations (implementation)
bool DB2AggregatorMIS2::commit ()
{
  //## begin dndb2database::DB2AggregatorMIS2::commit%5E826750003A.body preserve=yes
   UseCase hUseCase("TOTALS","## D247 COMMIT MIS");
   bool b = true;
   if (AMS1_ROWS > 0)
   {
#ifdef MVS
      XXEC SQL PREPARE MERGE1
         ATTRIBUTES :AMS_ATTRIBUTES
         FROM :AMS1_MERGE;
#else
      
/*
EXEC SQL PREPARE MERGE1 FROM :AMS1_MERGE;
*/

{
#line 241 "CXOSD247.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 241 "CXOSD247.sqx"
  sqlastls( *(unsigned short *)&AMS1_MERGE,(const char*)&AMS1_MERGE+2,0L);
#line 241 "CXOSD247.sqx"
  sqlacall((unsigned short)27,1,0,0,0L);
#line 241 "CXOSD247.sqx"
  sqlastop(0L);
}

#line 241 "CXOSD247.sqx"

#endif
      switch (sqlca.sqlcode)
      {
         case 0:
            break;
         case -911:
         case -913:
            UseCase::add("DEADLOCK");
            b = false;
            break;
         case -900:
         case -923:
         case -924:
         case -991:
         case -1024:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            b = false;
            break;
         default:
            if (sqlca.sqlcode > 0)
               Database::instance()->traceSQLError((void*)&sqlca,m_sID,"PREPARE1");
            else
            {
               UseCase::add("DBERROR");
               b = false;
            }
      }
      if (!b)
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"PREPARE1");
         return UseCase::setSuccess(false);
      }
#ifdef MVS
      XXEC SQL
         EXECUTE MERGE1
            USING
               :AMS1_TSTAMP_START,
               :AMS1_INTERVAL_TYPE,
               :AMS1_T_FIN_ENTITY_ID,
               :AMS1_T_MIS_MCC,
               :AMS1_CATEGORY_ID,
               :AMS1_PARTITION_KEY,
               :AMS1_AMT_TRAN,
               :AMS1_AMT_SURCHARGE,
               :AMS1_AMT_POS_REIMBURSE,
               :AMS1_CASHBACK_AMT,
               :AMS1_TRAN_COUNT,
               :AMS1_TIME_AT_ISS,
               :AMS1_TIME_AT_RQST_SWTCH,
               :AMS1_AMT_FEE,
               :AMS1_SYNC_INTERVAL_NO,
               :AMS1_BIN,
               :AMS1_ROWS;
#else
      
/*
EXEC SQL
         EXECUTE MERGE1
            USING
               :AMS1_TSTAMP_START,
               :AMS1_INTERVAL_TYPE,
               :AMS1_T_FIN_ENTITY_ID,
               :AMS1_T_MIS_MCC,
               :AMS1_CATEGORY_ID,
               :AMS1_PARTITION_KEY,
               :AMS1_AMT_TRAN,
               :AMS1_AMT_SURCHARGE,
               :AMS1_AMT_POS_REIMBURSE,
               :AMS1_CASHBACK_AMT,
               :AMS1_TRAN_COUNT,
               :AMS1_TIME_AT_ISS,
               :AMS1_TIME_AT_RQST_SWTCH,
               :AMS1_AMT_FEE,
               :AMS1_SYNC_INTERVAL_NO,
               :AMS1_BIN
            FOR :AMS1_ROWS ROWS;
*/

{
#line 317 "CXOSD247.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 317 "CXOSD247.sqx"
  sqlaaloc(2,16,1,0L);
    {
      struct sqla_setdata_list sql_setdlist[16];
#line 317 "CXOSD247.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 11;
#line 317 "CXOSD247.sqx"
      sql_setdlist[0].sqldata = (void*)AMS1_TSTAMP_START;
#line 317 "CXOSD247.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 2;
#line 317 "CXOSD247.sqx"
      sql_setdlist[1].sqldata = (void*)AMS1_INTERVAL_TYPE;
#line 317 "CXOSD247.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[2].sqltype = 496; sql_setdlist[2].sqllen = 4;
#line 317 "CXOSD247.sqx"
      sql_setdlist[2].sqldata = (void*)AMS1_T_FIN_ENTITY_ID;
#line 317 "CXOSD247.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 5;
#line 317 "CXOSD247.sqx"
      sql_setdlist[3].sqldata = (void*)AMS1_T_MIS_MCC;
#line 317 "CXOSD247.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[4].sqltype = 496; sql_setdlist[4].sqllen = 4;
#line 317 "CXOSD247.sqx"
      sql_setdlist[4].sqldata = (void*)AMS1_CATEGORY_ID;
#line 317 "CXOSD247.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[5].sqltype = 496; sql_setdlist[5].sqllen = 4;
#line 317 "CXOSD247.sqx"
      sql_setdlist[5].sqldata = (void*)AMS1_PARTITION_KEY;
#line 317 "CXOSD247.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[6].sqltype = 480; sql_setdlist[6].sqllen = 8;
#line 317 "CXOSD247.sqx"
      sql_setdlist[6].sqldata = (void*)AMS1_AMT_TRAN;
#line 317 "CXOSD247.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[7].sqltype = 480; sql_setdlist[7].sqllen = 8;
#line 317 "CXOSD247.sqx"
      sql_setdlist[7].sqldata = (void*)AMS1_AMT_SURCHARGE;
#line 317 "CXOSD247.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[8].sqltype = 480; sql_setdlist[8].sqllen = 8;
#line 317 "CXOSD247.sqx"
      sql_setdlist[8].sqldata = (void*)AMS1_AMT_POS_REIMBURSE;
#line 317 "CXOSD247.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[9].sqltype = 480; sql_setdlist[9].sqllen = 8;
#line 317 "CXOSD247.sqx"
      sql_setdlist[9].sqldata = (void*)AMS1_CASHBACK_AMT;
#line 317 "CXOSD247.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[10].sqltype = 496; sql_setdlist[10].sqllen = 4;
#line 317 "CXOSD247.sqx"
      sql_setdlist[10].sqldata = (void*)AMS1_TRAN_COUNT;
#line 317 "CXOSD247.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[11].sqltype = 480; sql_setdlist[11].sqllen = 8;
#line 317 "CXOSD247.sqx"
      sql_setdlist[11].sqldata = (void*)AMS1_TIME_AT_ISS;
#line 317 "CXOSD247.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[12].sqltype = 480; sql_setdlist[12].sqllen = 8;
#line 317 "CXOSD247.sqx"
      sql_setdlist[12].sqldata = (void*)AMS1_TIME_AT_RQST_SWTCH;
#line 317 "CXOSD247.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[13].sqltype = 480; sql_setdlist[13].sqllen = 8;
#line 317 "CXOSD247.sqx"
      sql_setdlist[13].sqldata = (void*)AMS1_AMT_FEE;
#line 317 "CXOSD247.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[14].sqltype = 496; sql_setdlist[14].sqllen = 4;
#line 317 "CXOSD247.sqx"
      sql_setdlist[14].sqldata = (void*)AMS1_SYNC_INTERVAL_NO;
#line 317 "CXOSD247.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 12;
#line 317 "CXOSD247.sqx"
      sql_setdlist[15].sqldata = (void*)AMS1_BIN;
#line 317 "CXOSD247.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 317 "CXOSD247.sqx"
      sqlasetdata(2,0,16,sql_setdlist,0L,0L);
    }
#line 317 "CXOSD247.sqx"
    {
      struct sqlacall_spare_info sqla_spare_info;
      sqla_spare_info.uiVersion    = 1;
      sqla_spare_info.arrayInfo.uiArraySize  = AMS1_ROWS;
      sqla_spare_info.arrayInfo.bIsStruct    = 0;
      sqla_spare_info.arrayInfo.bIsStructInd = 0;
      sqla_spare_info.arrayInfo.uiStructSize = 0;
      sqlacall((unsigned short)24,1,2,0,&sqla_spare_info);
    }
#line 317 "CXOSD247.sqx"
  sqlastop(0L);
}

#line 317 "CXOSD247.sqx"

#endif
      switch (sqlca.sqlcode)
      {
         case 0:
            UseCase::addItem(AMS1_ROWS);
            break;
         case -911:
         case -913:
            UseCase::add("DEADLOCK");
            b = false;
            break;
         case -900:
         case -923:
         case -924:
         case -991:
         case -1024:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            b = false;
            break;
         default:
            if (sqlca.sqlcode > 0)
               Database::instance()->traceSQLError((void*)&sqlca,m_sID,"MERGE1");
            else
            {
               UseCase::add("DBERROR");
               b = false;
            }
      }
      AMS1_ROWS = 0;
      if (!b)
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"MERGE1");
         return UseCase::setSuccess(false);
      }
   }
   if (AMS2_ROWS > 0)
   {
#ifdef MVS
      XXEC SQL PREPARE MERGE2
         ATTRIBUTES :AMS_ATTRIBUTES
         FROM :AMS2_MERGE;
#else
      
/*
EXEC SQL PREPARE MERGE2 FROM :AMS2_MERGE;
*/

{
#line 362 "CXOSD247.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 362 "CXOSD247.sqx"
  sqlastls( *(unsigned short *)&AMS2_MERGE,(const char*)&AMS2_MERGE+2,0L);
#line 362 "CXOSD247.sqx"
  sqlacall((unsigned short)27,2,0,0,0L);
#line 362 "CXOSD247.sqx"
  sqlastop(0L);
}

#line 362 "CXOSD247.sqx"

#endif
      switch (sqlca.sqlcode)
      {
         case 0:
            break;
         case -911:
         case -913:
            UseCase::add("DEADLOCK");
            b = false;
            break;
         case -900:
         case -923:
         case -924:
         case -991:
         case -1024:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            b = false;
            break;
         default:
            if (sqlca.sqlcode > 0)
               Database::instance()->traceSQLError((void*)&sqlca,m_sID,"PREPARE2");
            else
            {
               UseCase::add("DBERROR");
               b = false;
            }
      }
      if (!b)
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"PREPARE2");
         return UseCase::setSuccess(false);
      }
#ifdef MVS
      XXEC SQL
         EXECUTE MERGE2
            USING
               :AMS2_TSTAMP_START,
               :AMS2_INTERVAL_TYPE,
               :AMS2_T_FIN_ENTITY_ID,
               :AMS2_T_FIN_ENTITY_ID_2,
               :AMS2_T_MIS_MCC,
               :AMS2_CATEGORY_ID,
               :AMS2_PARTITION_KEY,
               :AMS2_AMT_TRAN,
               :AMS2_AMT_SURCHARGE,
               :AMS2_AMT_POS_REIMBURSE,
               :AMS2_CASHBACK_AMT,
               :AMS2_TRAN_COUNT,
               :AMS2_TIME_AT_ISS,
               :AMS2_TIME_AT_RQST_SWTCH,
               :AMS2_AMT_FEE,
               :AMS2_SYNC_INTERVAL_NO,
               :AMS2_BIN,
               :AMS2_ROWS;
#else
      
/*
EXEC SQL
         EXECUTE MERGE2
            USING
               :AMS2_TSTAMP_START,
               :AMS2_INTERVAL_TYPE,
               :AMS2_T_FIN_ENTITY_ID,
               :AMS2_T_FIN_ENTITY_ID_2,
               :AMS2_T_MIS_MCC,
               :AMS2_CATEGORY_ID,
               :AMS2_PARTITION_KEY,
               :AMS2_AMT_TRAN,
               :AMS2_AMT_SURCHARGE,
               :AMS2_AMT_POS_REIMBURSE,
               :AMS2_CASHBACK_AMT,
               :AMS2_TRAN_COUNT,
               :AMS2_TIME_AT_ISS,
               :AMS2_TIME_AT_RQST_SWTCH,
               :AMS2_AMT_FEE,
               :AMS2_SYNC_INTERVAL_NO,
               :AMS2_BIN
            FOR :AMS2_ROWS ROWS;
*/

{
#line 440 "CXOSD247.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 440 "CXOSD247.sqx"
  sqlaaloc(2,17,2,0L);
    {
      struct sqla_setdata_list sql_setdlist[17];
#line 440 "CXOSD247.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 11;
#line 440 "CXOSD247.sqx"
      sql_setdlist[0].sqldata = (void*)AMS2_TSTAMP_START;
#line 440 "CXOSD247.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 2;
#line 440 "CXOSD247.sqx"
      sql_setdlist[1].sqldata = (void*)AMS2_INTERVAL_TYPE;
#line 440 "CXOSD247.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[2].sqltype = 496; sql_setdlist[2].sqllen = 4;
#line 440 "CXOSD247.sqx"
      sql_setdlist[2].sqldata = (void*)AMS2_T_FIN_ENTITY_ID;
#line 440 "CXOSD247.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[3].sqltype = 496; sql_setdlist[3].sqllen = 4;
#line 440 "CXOSD247.sqx"
      sql_setdlist[3].sqldata = (void*)AMS2_T_FIN_ENTITY_ID_2;
#line 440 "CXOSD247.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 5;
#line 440 "CXOSD247.sqx"
      sql_setdlist[4].sqldata = (void*)AMS2_T_MIS_MCC;
#line 440 "CXOSD247.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[5].sqltype = 496; sql_setdlist[5].sqllen = 4;
#line 440 "CXOSD247.sqx"
      sql_setdlist[5].sqldata = (void*)AMS2_CATEGORY_ID;
#line 440 "CXOSD247.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[6].sqltype = 496; sql_setdlist[6].sqllen = 4;
#line 440 "CXOSD247.sqx"
      sql_setdlist[6].sqldata = (void*)AMS2_PARTITION_KEY;
#line 440 "CXOSD247.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[7].sqltype = 480; sql_setdlist[7].sqllen = 8;
#line 440 "CXOSD247.sqx"
      sql_setdlist[7].sqldata = (void*)AMS2_AMT_TRAN;
#line 440 "CXOSD247.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[8].sqltype = 480; sql_setdlist[8].sqllen = 8;
#line 440 "CXOSD247.sqx"
      sql_setdlist[8].sqldata = (void*)AMS2_AMT_SURCHARGE;
#line 440 "CXOSD247.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[9].sqltype = 480; sql_setdlist[9].sqllen = 8;
#line 440 "CXOSD247.sqx"
      sql_setdlist[9].sqldata = (void*)AMS2_AMT_POS_REIMBURSE;
#line 440 "CXOSD247.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[10].sqltype = 480; sql_setdlist[10].sqllen = 8;
#line 440 "CXOSD247.sqx"
      sql_setdlist[10].sqldata = (void*)AMS2_CASHBACK_AMT;
#line 440 "CXOSD247.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[11].sqltype = 496; sql_setdlist[11].sqllen = 4;
#line 440 "CXOSD247.sqx"
      sql_setdlist[11].sqldata = (void*)AMS2_TRAN_COUNT;
#line 440 "CXOSD247.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[12].sqltype = 480; sql_setdlist[12].sqllen = 8;
#line 440 "CXOSD247.sqx"
      sql_setdlist[12].sqldata = (void*)AMS2_TIME_AT_ISS;
#line 440 "CXOSD247.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[13].sqltype = 480; sql_setdlist[13].sqllen = 8;
#line 440 "CXOSD247.sqx"
      sql_setdlist[13].sqldata = (void*)AMS2_TIME_AT_RQST_SWTCH;
#line 440 "CXOSD247.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[14].sqltype = 480; sql_setdlist[14].sqllen = 8;
#line 440 "CXOSD247.sqx"
      sql_setdlist[14].sqldata = (void*)AMS2_AMT_FEE;
#line 440 "CXOSD247.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[15].sqltype = 496; sql_setdlist[15].sqllen = 4;
#line 440 "CXOSD247.sqx"
      sql_setdlist[15].sqldata = (void*)AMS2_SYNC_INTERVAL_NO;
#line 440 "CXOSD247.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 12;
#line 440 "CXOSD247.sqx"
      sql_setdlist[16].sqldata = (void*)AMS2_BIN;
#line 440 "CXOSD247.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 440 "CXOSD247.sqx"
      sqlasetdata(2,0,17,sql_setdlist,0L,0L);
    }
#line 440 "CXOSD247.sqx"
    {
      struct sqlacall_spare_info sqla_spare_info;
      sqla_spare_info.uiVersion    = 1;
      sqla_spare_info.arrayInfo.uiArraySize  = AMS2_ROWS;
      sqla_spare_info.arrayInfo.bIsStruct    = 0;
      sqla_spare_info.arrayInfo.bIsStructInd = 0;
      sqla_spare_info.arrayInfo.uiStructSize = 0;
      sqlacall((unsigned short)24,2,2,0,&sqla_spare_info);
    }
#line 440 "CXOSD247.sqx"
  sqlastop(0L);
}

#line 440 "CXOSD247.sqx"

#endif
      switch (sqlca.sqlcode)
      {
         case 0:
            UseCase::addItem(AMS2_ROWS);
            break;
         case -911:
         case -913:
            UseCase::add("DEADLOCK");
            b = false;
            break;
         case -900:
         case -923:
         case -924:
         case -991:
         case -1024:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            b = false;
            break;
         default:
            if (sqlca.sqlcode > 0)
               Database::instance()->traceSQLError((void*)&sqlca,m_sID,"MERGE2");
            else
            {
               UseCase::add("DBERROR");
               b = false;
            }
      }
      AMS2_ROWS = 0;
      if (!b)
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError((void*)&sqlca, m_sID,"MERGE2");
      }
   }
   return UseCase::setSuccess(b);
  //## end dndb2database::DB2AggregatorMIS2::commit%5E826750003A.body
}

bool DB2AggregatorMIS2::tableInsert (bool bSubtractFromTotals)
{
  //## begin dndb2database::DB2AggregatorMIS2::tableInsert%5E8264C90047.body preserve=yes
   return true;
  //## end dndb2database::DB2AggregatorMIS2::tableInsert%5E8264C90047.body
}

int DB2AggregatorMIS2::tableUpdate (bool bSubtractFromTotals)
{
  //## begin dndb2database::DB2AggregatorMIS2::tableUpdate%5E8264CB00EF.body preserve=yes
   if (getENTITY_ID(1) == "~NULL!")
   {
      if (AMS1_ROWS >= 512)
         if (!commit())
            return -1;
      memcpy(AMS1_TSTAMP_START[AMS1_ROWS],getTSTAMP_START().data(),min((size_t)getTSTAMP_START().length(),sizeof(AMS1_TSTAMP_START[AMS1_ROWS])-1));
      AMS1_TSTAMP_START[AMS1_ROWS][min((size_t)getTSTAMP_START().length(),sizeof(AMS1_TSTAMP_START[AMS1_ROWS])-1)] = '\0';
      memcpy(AMS1_INTERVAL_TYPE[AMS1_ROWS],getINTERVAL_TYPE().data(),min((size_t)getINTERVAL_TYPE().length(),sizeof(AMS1_INTERVAL_TYPE[AMS1_ROWS])-1));
      AMS1_INTERVAL_TYPE[AMS1_ROWS][min((size_t)getINTERVAL_TYPE().length(),sizeof(AMS1_INTERVAL_TYPE[AMS1_ROWS])-1)] = '\0';
      memcpy(AMS1_BIN[AMS1_ROWS],getBIN().data(),min((size_t)getBIN().length(),sizeof(AMS1_BIN[AMS1_ROWS])-1));
      AMS1_BIN[AMS1_ROWS][min((size_t)getBIN().length(),sizeof(AMS1_BIN[AMS1_ROWS])-1)] = '\0';
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(0),getENTITY_ID(0),(int*)&AMS1_T_FIN_ENTITY_ID[AMS1_ROWS]);
      memcpy(AMS1_T_MIS_MCC[AMS1_ROWS],getT_MIS_MCC().data(),min((size_t)getT_MIS_MCC().length(),sizeof(AMS1_T_MIS_MCC[AMS1_ROWS])-1));
      AMS1_T_MIS_MCC[AMS1_ROWS][min((size_t)getT_MIS_MCC().length(),sizeof(AMS1_T_MIS_MCC[AMS1_ROWS])-1)] = '\0';
      AMS1_SYNC_INTERVAL_NO[AMS1_ROWS] = getSYNC_INTERVAL_NO();
      AMS1_CATEGORY_ID[AMS1_ROWS] = getCATEGORY_ID();
      if (Extract::instance()->getCustomCode() == "EFTPOS"
         || Extract::instance()->getCustomCode() == "NAB")
         AMS1_PARTITION_KEY[AMS1_ROWS] = (getINTERVAL_TYPE() == "M" || getINTERVAL_TYPE() == "Y") ? 0 : (int)(PartitionControl::instance()->partitionKey("T_MIS_TOTAL",FinancialTransaction::instance()->getDATE_RECON_ACQ().data(),"MISPARTS"));
      else
         AMS1_PARTITION_KEY[AMS1_ROWS] = (getINTERVAL_TYPE() == "M" || getINTERVAL_TYPE() == "Y") ? 0 : (int)(PartitionControl::instance()->partitionKey("T_MIS_TOTAL",FinancialTransaction::instance()->getTSTAMP_TRANS().data(),"MISPARTS"));
      AMS1_AMT_TRAN[AMS1_ROWS] = (bSubtractFromTotals) ? 0 - getAMT_TRAN() : getAMT_TRAN();
      AMS1_AMT_SURCHARGE[AMS1_ROWS] = (bSubtractFromTotals) ? 0 - getAMT_SURCHARGE() : getAMT_SURCHARGE();
      AMS1_AMT_POS_REIMBURSE[AMS1_ROWS] = (bSubtractFromTotals) ? 0 - getAMT_POS_REIMBURSE() : getAMT_POS_REIMBURSE();
      AMS1_CASHBACK_AMT[AMS1_ROWS] = (bSubtractFromTotals) ? 0 - getCASHBACK_AMT() : getCASHBACK_AMT();
      AMS1_TRAN_COUNT[AMS1_ROWS] = (bSubtractFromTotals) ? -1 : 1;
      AMS1_TIME_AT_ISS[AMS1_ROWS] = (bSubtractFromTotals) ? 0 - (double)getTIME_AT_ISS() : (double)getTIME_AT_ISS();
      AMS1_TIME_AT_RQST_SWTCH[AMS1_ROWS] = (bSubtractFromTotals) ? 0 - (double)getTIME_AT_RQST_SWTCH() : (double)getTIME_AT_RQST_SWTCH();
      AMS1_AMT_FEE[AMS1_ROWS] = (bSubtractFromTotals) ? 0 - getAMT_FEE() : getAMT_FEE();
      ++AMS1_ROWS;
   }
   else
   {
      if (AMS2_ROWS >= 512)
         if (!commit())
            return -1;
      memcpy(AMS2_TSTAMP_START[AMS2_ROWS],getTSTAMP_START().data(),min((size_t)getTSTAMP_START().length(),sizeof(AMS2_TSTAMP_START[AMS2_ROWS])-1));
      AMS2_TSTAMP_START[AMS2_ROWS][min((size_t)getTSTAMP_START().length(),sizeof(AMS2_TSTAMP_START[AMS2_ROWS])-1)] = '\0';
      memcpy(AMS2_INTERVAL_TYPE[AMS2_ROWS],getINTERVAL_TYPE().data(),min((size_t)getINTERVAL_TYPE().length(),sizeof(AMS2_INTERVAL_TYPE[AMS2_ROWS])-1));
      AMS2_INTERVAL_TYPE[AMS2_ROWS][min((size_t)getINTERVAL_TYPE().length(),sizeof(AMS2_INTERVAL_TYPE[AMS2_ROWS])-1)] = '\0';
      memcpy(AMS2_BIN[AMS2_ROWS],getBIN().data(),min((size_t)getBIN().length(),sizeof(AMS2_BIN[AMS2_ROWS])-1));
      AMS2_BIN[AMS2_ROWS][min((size_t)getBIN().length(),sizeof(AMS2_BIN[AMS2_ROWS])-1)] = '\0';
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(0),getENTITY_ID(0),(int*)&AMS2_T_FIN_ENTITY_ID[AMS2_ROWS]);
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(1),getENTITY_ID(1),(int*)&AMS2_T_FIN_ENTITY_ID_2[AMS2_ROWS]);
      memcpy(AMS2_T_MIS_MCC[AMS2_ROWS],getT_MIS_MCC().data(),min((size_t)getT_MIS_MCC().length(),sizeof(AMS2_T_MIS_MCC[AMS2_ROWS])-1));
      AMS2_T_MIS_MCC[AMS2_ROWS][min((size_t)getT_MIS_MCC().length(),sizeof(AMS2_T_MIS_MCC[AMS2_ROWS])-1)] = '\0';
      AMS2_SYNC_INTERVAL_NO[AMS2_ROWS] = getSYNC_INTERVAL_NO();
      AMS2_CATEGORY_ID[AMS2_ROWS] = getCATEGORY_ID();
      if (Extract::instance()->getCustomCode() == "EFTPOS"
         || Extract::instance()->getCustomCode() == "NAB")
         AMS2_PARTITION_KEY[AMS2_ROWS] = (getINTERVAL_TYPE() == "M" || getINTERVAL_TYPE() == "Y") ? 0 : (int)(PartitionControl::instance()->partitionKey("T_MIS_TOTAL",FinancialTransaction::instance()->getDATE_RECON_ACQ().data(),"MISPARTS"));
      else
         AMS2_PARTITION_KEY[AMS2_ROWS] = (getINTERVAL_TYPE() == "M" || getINTERVAL_TYPE() == "Y") ? 0 : (int)(PartitionControl::instance()->partitionKey("T_MIS_TOTAL",FinancialTransaction::instance()->getTSTAMP_TRANS().data(),"MISPARTS"));
      AMS2_AMT_TRAN[AMS2_ROWS] = (bSubtractFromTotals) ? 0 - getAMT_TRAN() : getAMT_TRAN();
      AMS2_AMT_SURCHARGE[AMS2_ROWS] = (bSubtractFromTotals) ? 0 - getAMT_SURCHARGE() : getAMT_SURCHARGE();
      AMS2_AMT_POS_REIMBURSE[AMS2_ROWS] = (bSubtractFromTotals) ? 0 - getAMT_POS_REIMBURSE() : getAMT_POS_REIMBURSE();
      AMS2_CASHBACK_AMT[AMS2_ROWS] = (bSubtractFromTotals) ? 0 - getCASHBACK_AMT() : getCASHBACK_AMT();
      AMS2_TRAN_COUNT[AMS2_ROWS] = (bSubtractFromTotals) ? -1 : 1;
      AMS2_TIME_AT_ISS[AMS2_ROWS] = (bSubtractFromTotals) ? 0 - (double)getTIME_AT_ISS() : (double)getTIME_AT_ISS();
      AMS2_TIME_AT_RQST_SWTCH[AMS2_ROWS] = (bSubtractFromTotals) ? 0 - (double)getTIME_AT_RQST_SWTCH() : (double)getTIME_AT_RQST_SWTCH();
      AMS2_AMT_FEE[AMS2_ROWS] = (bSubtractFromTotals) ? 0 - getAMT_FEE() : getAMT_FEE();
      ++AMS2_ROWS;
   }
   return 1;
  //## end dndb2database::DB2AggregatorMIS2::tableUpdate%5E8264CB00EF.body
}

// Additional Declarations
  //## begin dndb2database::DB2AggregatorMIS2%5E826410015B.declarations preserve=yes
  //## end dndb2database::DB2AggregatorMIS2%5E826410015B.declarations

} // namespace dndb2database

//## begin module%5E826585020E.epilog preserve=yes
//## end module%5E826585020E.epilog
