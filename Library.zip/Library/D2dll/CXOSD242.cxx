static char sqla_program_id[292] = 
{
 '\xac','\x0','\x41','\x45','\x41','\x56','\x41','\x49','\x6a','\x41','\x4f','\x34','\x52','\x48','\x49','\x6f','\x30','\x31','\x31','\x31',
 '\x31','\x20','\x32','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x8','\x0','\x44','\x4e','\x53','\x45','\x52','\x56',
 '\x45','\x52','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x8','\x0','\x43','\x58','\x4f','\x53','\x44','\x32','\x34','\x32','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0'
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo = 
{{'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {'C',' ',' ',' '}};


static const short sqlIsLiteral   = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "CXOSD242.sqx"
//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3A2D728103A7.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%3A2D728103A7.cm

//## begin module%3A2D728103A7.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%3A2D728103A7.cp

//## Module: CXOSD242%3A2D728103A7; Package body
//## Subsystem: D2DLL%3597E8A6029B
// .
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXOSD242.sqx

//## begin module%3A2D728103A7.additionalIncludes preserve=no
//## end module%3A2D728103A7.additionalIncludes

//## begin module%3A2D728103A7.includes preserve=yes
#include "CXODRU08.hpp"
#include "CXODDB02.hpp"
#include "CXODIF03.hpp"
//## end module%3A2D728103A7.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSST04_h
#include "CXODST04.hpp"
#endif
#ifndef CXOSST12_h
#include "CXODST12.hpp"
#endif
#ifndef CXOSST14_h
#include "CXODST14.hpp"
#endif
#ifndef CXOSST09_h
#include "CXODST09.hpp"
#endif
#ifndef CXOSST11_h
#include "CXODST11.hpp"
#endif
#ifndef CXOSST10_h
#include "CXODST10.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSD242_h
#include "CXODD242.hpp"
#endif


//## begin module%3A2D728103A7.declarations preserve=no
//## end module%3A2D728103A7.declarations

//## begin module%3A2D728103A7.additionalDeclarations preserve=yes
#ifdef MVS

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
struct sqlca sqlca;


#line 69 "CXOSD242.sqx"

#else
#include "sqlca.h"
extern struct sqlca sqlca;
#endif


/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 75 "CXOSD242.sqx"

   sqlint32 CTV_CATEGORY_ID;
   sqlint32 CTV_ENTITY_GROUP_ID;
   sqlint32 CTV_TRAN_COUNT;
   double CTV_AMT_RECON_NET;
   double CTV_AMT_TRAN;
   double CTV_AMT_CARD_BILL;
   double CTV_AMT_RECON_ACQ;
   double CTV_AMT_RECON_ISS;
   char CTV_TSTAMP_LAST_UPDATE[15];
   sqlint32 CTV_PERIOD_ID;
   sqlint32 CTV_T_FIN_ENTITY_ID;
   char CTV_TSTAMP_END[17];
   char CTV_TSTAMP_TRANS_FROM[17];
   char CTV_TSTAMP_TRANS_TO[17];
   char CTV_DATE_RECON[9];
   char CTV_TSTAMP_LAST_UPDATED[17];
   sqlint32 CTV_SYNC_INTERVAL_NO;
   short CTV_SEQUENCE_NO;
   char CTV_ENTITY_TYPE[3];
   char CTV_ENTITY_ID[29];
   char CTV_NET_ID_ACQ[4];
   char CTV_NET_ID_ISS[4];
   char CTV_FIN_TYPE[4];
   char CTV_TRAN_TYPE_ID[11];
   char CTV_ACT_CODE[4];
   char CTV_FUNC_CODE[4];
   char CTV_AUTH_BY[2];
   char CTV_REV_BY[2];
   char CTV_CUR_RECON_NET[4];
   char CTV_CUR_TRAN[4];
   char CTV_CUR_CARD_BILL[4];
   char CTV_CUR_RECON_ACQ[4];
   char CTV_CUR_RECON_ISS[4];
   char CTV_IMPACT_TO_ACQ[2];
   char CTV_IMPACT_TO_ISS[2];
   char CTV_TRAN_DISPOSITION[2];
   char CTV_TOTAL_TYPE[5];
   char CTV_TRAN_CLASS[4];
   char CTV_MERCH_TYPE[5];
   char CTV_NETWORK_PROGRAM[11];
   char CTV_IMAGEID[5];
   char CTV_TASKID[8];
   char CTV_CONTEXT_TYPE[2];
   char CTV_CONTEXT_KEY[33];
   char CTV_CONTEXT_DATA[101];

/*
EXEC SQL END DECLARE SECTION;
*/

#line 121 "CXOSD242.sqx"

//## end module%3A2D728103A7.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

// Class dndb2database::DB2CheckpointTotalsVisitor

DB2CheckpointTotalsVisitor::DB2CheckpointTotalsVisitor()
  //## begin DB2CheckpointTotalsVisitor::DB2CheckpointTotalsVisitor%3A2D711201AB_const.hasinit preserve=no
      : m_lTransaction(-1)
  //## end DB2CheckpointTotalsVisitor::DB2CheckpointTotalsVisitor%3A2D711201AB_const.hasinit
  //## begin DB2CheckpointTotalsVisitor::DB2CheckpointTotalsVisitor%3A2D711201AB_const.initialization preserve=yes
  //## end DB2CheckpointTotalsVisitor::DB2CheckpointTotalsVisitor%3A2D711201AB_const.initialization
{
  //## begin dndb2database::DB2CheckpointTotalsVisitor::DB2CheckpointTotalsVisitor%3A2D711201AB_const.body preserve=yes
   memcpy(m_sID,"D242",4);
   memcpy(CTV_IMAGEID,"I01/",4);
   CTV_IMAGEID[4] = '\0';
   memcpy(CTV_TASKID,Application::instance()->name().data(),Application::instance()->name().length());
   CTV_TASKID[Application::instance()->name().length()] = '\0';
   CTV_CONTEXT_TYPE[0] = ' ';
   CTV_CONTEXT_TYPE[1] = '\0';
   memcpy(CTV_CONTEXT_KEY,"LOAD ",5);
  //## end dndb2database::DB2CheckpointTotalsVisitor::DB2CheckpointTotalsVisitor%3A2D711201AB_const.body
}


DB2CheckpointTotalsVisitor::~DB2CheckpointTotalsVisitor()
{
  //## begin dndb2database::DB2CheckpointTotalsVisitor::~DB2CheckpointTotalsVisitor%3A2D711201AB_dest.body preserve=yes
  //## end dndb2database::DB2CheckpointTotalsVisitor::~DB2CheckpointTotalsVisitor%3A2D711201AB_dest.body
}



//## Other Operations (implementation)
bool DB2CheckpointTotalsVisitor::checkResult ()
{
  //## begin dndb2database::DB2CheckpointTotalsVisitor::checkResult%3A2D761F0178.body preserve=yes
   switch (sqlca.sqlcode)
   {
      case 0:
         UseCase::addItem();
         return true;
      case 100:
         UseCase::add("DBERROR");
         break;
      case -911:
      case -913:
         UseCase::add("DEADLOCK");
         break;
      case -900:
      case -923:
      case -924:
      case -991:
      case -1024:
         UseCase::add("CONNECT");
         Database::instance()->setState(Database::DISCONNECTED);
         break;
      default:
         if (sqlca.sqlcode > 0)
         {
           Database::instance()->traceSQLError((void*)&sqlca,m_sID,"UPDATE");
           UseCase::addItem();
           return true;
         }
         else
           UseCase::add("DBERROR");
   }
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,"UPDATE");
   return false;
  //## end dndb2database::DB2CheckpointTotalsVisitor::checkResult%3A2D761F0178.body
}

void DB2CheckpointTotalsVisitor::lockTables ()
{
  //## begin dndb2database::DB2CheckpointTotalsVisitor::lockTables%42273D21001F.body preserve=yes
   m_lTransaction = Database::instance()->transaction();
   
/*
EXEC SQL LOCK TABLE T_FIN_TOTAL IN EXCLUSIVE MODE;
*/

{
#line 204 "CXOSD242.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 204 "CXOSD242.sqx"
  sqlacall((unsigned short)24,1,0,0,0L);
#line 204 "CXOSD242.sqx"
  sqlastop(0L);
}

#line 204 "CXOSD242.sqx"

   if (sqlca.sqlcode == 0)
   {
      
/*
EXEC SQL LOCK TABLE T_FIN_PERIOD IN EXCLUSIVE MODE;
*/

{
#line 207 "CXOSD242.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 207 "CXOSD242.sqx"
  sqlacall((unsigned short)24,2,0,0,0L);
#line 207 "CXOSD242.sqx"
  sqlastop(0L);
}

#line 207 "CXOSD242.sqx"

      if (sqlca.sqlcode == 0)
      {
         
/*
EXEC SQL LOCK TABLE T_FIN_ENTITY_GROUP IN EXCLUSIVE MODE;
*/

{
#line 210 "CXOSD242.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 210 "CXOSD242.sqx"
  sqlacall((unsigned short)24,3,0,0,0L);
#line 210 "CXOSD242.sqx"
  sqlastop(0L);
}

#line 210 "CXOSD242.sqx"

         if (sqlca.sqlcode == 0)
            
/*
EXEC SQL LOCK TABLE T_FIN_E_GROUP_ITEM IN EXCLUSIVE MODE;
*/

{
#line 212 "CXOSD242.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 212 "CXOSD242.sqx"
  sqlacall((unsigned short)24,4,0,0,0L);
#line 212 "CXOSD242.sqx"
  sqlastop(0L);
}

#line 212 "CXOSD242.sqx"

      }
   }
   if (sqlca.sqlcode != 0)
   {
      Database::instance()->traceSQLError((void*)&sqlca,m_sID,"lockTables");
      if (sqlca.sqlcode == -911)
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   }
  //## end dndb2database::DB2CheckpointTotalsVisitor::lockTables%42273D21001F.body
}

void DB2CheckpointTotalsVisitor::visitAccumulator (Accumulator* pAccumulator)
{
  //## begin dndb2database::DB2CheckpointTotalsVisitor::visitAccumulator%3A2D9606030C.body preserve=yes
   if (Database::instance()->getDormant())
      Database::instance()->connect();
  //## end dndb2database::DB2CheckpointTotalsVisitor::visitAccumulator%3A2D9606030C.body
}

void DB2CheckpointTotalsVisitor::visitEntityGroup (settlement::EntityGroup* pEntityGroup)
{
  //## begin dndb2database::DB2CheckpointTotalsVisitor::visitEntityGroup%3A2D916B02F2.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   m_lENTITY_GROUP_ID = pEntityGroup->getENTITY_GROUP_ID();
   CTV_ENTITY_GROUP_ID = pEntityGroup->getENTITY_GROUP_ID();
   CTV_SYNC_INTERVAL_NO = pEntityGroup->getSYNC_INTERVAL_NO();
   if (m_lTransaction != Database::instance()->transaction())
      lockTables();
   
/*
EXEC SQL
      INSERT INTO T_FIN_ENTITY_GROUP
      (
         ENTITY_GROUP_ID,
         SYNC_INTERVAL_NO
      )
      VALUES
      (
         :CTV_ENTITY_GROUP_ID,
         :CTV_SYNC_INTERVAL_NO
      );
*/

{
#line 252 "CXOSD242.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 252 "CXOSD242.sqx"
  sqlaaloc(2,2,1,0L);
    {
      struct sqla_setdata_list sql_setdlist[2];
#line 252 "CXOSD242.sqx"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 252 "CXOSD242.sqx"
      sql_setdlist[0].sqldata = (void*)&CTV_ENTITY_GROUP_ID;
#line 252 "CXOSD242.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 252 "CXOSD242.sqx"
      sql_setdlist[1].sqltype = 496; sql_setdlist[1].sqllen = 4;
#line 252 "CXOSD242.sqx"
      sql_setdlist[1].sqldata = (void*)&CTV_SYNC_INTERVAL_NO;
#line 252 "CXOSD242.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 252 "CXOSD242.sqx"
      sqlasetdata(2,0,2,sql_setdlist,0L,0L);
    }
#line 252 "CXOSD242.sqx"
  sqlacall((unsigned short)24,5,2,0,0L);
#line 252 "CXOSD242.sqx"
  sqlastop(0L);
}

#line 252 "CXOSD242.sqx"

   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_ENTITY_GROUP %ld %ld",CTV_ENTITY_GROUP_ID,CTV_SYNC_INTERVAL_NO);
      Trace::put(szTemp,-1,true);
      return;
   }
   for (CTV_SEQUENCE_NO = 1;CTV_SEQUENCE_NO <= 7;++CTV_SEQUENCE_NO)
   {
      CTV_PERIOD_ID = pEntityGroup->getPERIOD_ID(CTV_SEQUENCE_NO);
      
/*
EXEC SQL
         INSERT INTO T_FIN_E_GROUP_ITEM
         (
            ENTITY_GROUP_ID,
            SEQUENCE_NO,
            PERIOD_ID
         )
         VALUES
         (
            :CTV_ENTITY_GROUP_ID,
            :CTV_SEQUENCE_NO,
            :CTV_PERIOD_ID
         );
*/

{
#line 275 "CXOSD242.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 275 "CXOSD242.sqx"
  sqlaaloc(2,3,2,0L);
    {
      struct sqla_setdata_list sql_setdlist[3];
#line 275 "CXOSD242.sqx"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 275 "CXOSD242.sqx"
      sql_setdlist[0].sqldata = (void*)&CTV_ENTITY_GROUP_ID;
#line 275 "CXOSD242.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 275 "CXOSD242.sqx"
      sql_setdlist[1].sqltype = 500; sql_setdlist[1].sqllen = 2;
#line 275 "CXOSD242.sqx"
      sql_setdlist[1].sqldata = (void*)&CTV_SEQUENCE_NO;
#line 275 "CXOSD242.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 275 "CXOSD242.sqx"
      sql_setdlist[2].sqltype = 496; sql_setdlist[2].sqllen = 4;
#line 275 "CXOSD242.sqx"
      sql_setdlist[2].sqldata = (void*)&CTV_PERIOD_ID;
#line 275 "CXOSD242.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 275 "CXOSD242.sqx"
      sqlasetdata(2,0,3,sql_setdlist,0L,0L);
    }
#line 275 "CXOSD242.sqx"
  sqlacall((unsigned short)24,6,2,0,0L);
#line 275 "CXOSD242.sqx"
  sqlastop(0L);
}

#line 275 "CXOSD242.sqx"

      if (!checkResult())
      {
         char szTemp[128];
         snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_E_GROUP_ITEM %ld %hd %ld",CTV_ENTITY_GROUP_ID,CTV_SEQUENCE_NO,CTV_PERIOD_ID);
         Trace::put(szTemp,-1,true);
         return;
      }
   }
  //## end dndb2database::DB2CheckpointTotalsVisitor::visitEntityGroup%3A2D916B02F2.body
}

void DB2CheckpointTotalsVisitor::visitRecoveryPoint (settlement::RecoveryPoint* pRecoveryPoint)
{
  //## begin dndb2database::DB2CheckpointTotalsVisitor::visitRecoveryPoint%3A2D916E0062.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   memcpy(CTV_CONTEXT_KEY + 5,pRecoveryPoint->getInterval().data(),pRecoveryPoint->getInterval().length());
   CTV_CONTEXT_KEY[pRecoveryPoint->getInterval().length() + 5] = '\0';
   snprintf(CTV_CONTEXT_DATA,sizeof(CTV_CONTEXT_DATA),"%d:%d",pRecoveryPoint->getStartTime(),pRecoveryPoint->getEndTime());
   if (pRecoveryPoint->getState() == PersistentObject::NEW)
   {
      
/*
EXEC SQL
         INSERT INTO TASK_CONTEXT
         (
            IMAGEID,
            TASKID,
            CONTEXT_TYPE,
            CONTEXT_KEY,
            CONTEXT_DATA
         )
         VALUES
         (
            :CTV_IMAGEID,
            :CTV_TASKID,
            :CTV_CONTEXT_TYPE,
            :CTV_CONTEXT_KEY,
            :CTV_CONTEXT_DATA
         );
*/

{
#line 313 "CXOSD242.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 313 "CXOSD242.sqx"
  sqlaaloc(2,5,3,0L);
    {
      struct sqla_setdata_list sql_setdlist[5];
#line 313 "CXOSD242.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 5;
#line 313 "CXOSD242.sqx"
      sql_setdlist[0].sqldata = (void*)CTV_IMAGEID;
#line 313 "CXOSD242.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 313 "CXOSD242.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 8;
#line 313 "CXOSD242.sqx"
      sql_setdlist[1].sqldata = (void*)CTV_TASKID;
#line 313 "CXOSD242.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 313 "CXOSD242.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 2;
#line 313 "CXOSD242.sqx"
      sql_setdlist[2].sqldata = (void*)CTV_CONTEXT_TYPE;
#line 313 "CXOSD242.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 313 "CXOSD242.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 33;
#line 313 "CXOSD242.sqx"
      sql_setdlist[3].sqldata = (void*)CTV_CONTEXT_KEY;
#line 313 "CXOSD242.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 313 "CXOSD242.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 101;
#line 313 "CXOSD242.sqx"
      sql_setdlist[4].sqldata = (void*)CTV_CONTEXT_DATA;
#line 313 "CXOSD242.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 313 "CXOSD242.sqx"
      sqlasetdata(2,0,5,sql_setdlist,0L,0L);
    }
#line 313 "CXOSD242.sqx"
  sqlacall((unsigned short)24,7,2,0,0L);
#line 313 "CXOSD242.sqx"
  sqlastop(0L);
}

#line 313 "CXOSD242.sqx"

   }
   else
   {
      
/*
EXEC SQL
         UPDATE TASK_CONTEXT
            SET
               CONTEXT_DATA = :CTV_CONTEXT_DATA
            WHERE
               IMAGEID = :CTV_IMAGEID
               AND TASKID = :CTV_TASKID
               AND CONTEXT_TYPE = :CTV_CONTEXT_TYPE
               AND CONTEXT_KEY = :CTV_CONTEXT_KEY;
*/

{
#line 325 "CXOSD242.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 325 "CXOSD242.sqx"
  sqlaaloc(2,5,4,0L);
    {
      struct sqla_setdata_list sql_setdlist[5];
#line 325 "CXOSD242.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 101;
#line 325 "CXOSD242.sqx"
      sql_setdlist[0].sqldata = (void*)CTV_CONTEXT_DATA;
#line 325 "CXOSD242.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 325 "CXOSD242.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 5;
#line 325 "CXOSD242.sqx"
      sql_setdlist[1].sqldata = (void*)CTV_IMAGEID;
#line 325 "CXOSD242.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 325 "CXOSD242.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 8;
#line 325 "CXOSD242.sqx"
      sql_setdlist[2].sqldata = (void*)CTV_TASKID;
#line 325 "CXOSD242.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 325 "CXOSD242.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 2;
#line 325 "CXOSD242.sqx"
      sql_setdlist[3].sqldata = (void*)CTV_CONTEXT_TYPE;
#line 325 "CXOSD242.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 325 "CXOSD242.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 33;
#line 325 "CXOSD242.sqx"
      sql_setdlist[4].sqldata = (void*)CTV_CONTEXT_KEY;
#line 325 "CXOSD242.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 325 "CXOSD242.sqx"
      sqlasetdata(2,0,5,sql_setdlist,0L,0L);
    }
#line 325 "CXOSD242.sqx"
  sqlacall((unsigned short)24,8,2,0,0L);
#line 325 "CXOSD242.sqx"
  sqlastop(0L);
}

#line 325 "CXOSD242.sqx"

   }
   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"       TASK_CONTEXT %s %s %s %s %s",CTV_IMAGEID,CTV_TASKID,CTV_CONTEXT_TYPE,CTV_CONTEXT_KEY,CTV_CONTEXT_DATA);
      if (pRecoveryPoint->getState() == PersistentObject::NEW)
         memcpy(szTemp,"INSERT",6);
      else
         memcpy(szTemp,"UPDATE",6);
      Trace::put(szTemp,-1,true);
      return;
   }
  //## end dndb2database::DB2CheckpointTotalsVisitor::visitRecoveryPoint%3A2D916E0062.body
}

void DB2CheckpointTotalsVisitor::visitReportingEntity (settlement::ReportingEntity* pReportingEntity)
{
  //## begin dndb2database::DB2CheckpointTotalsVisitor::visitReportingEntity%3A2D917002FA.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   m_lT_FIN_ENTITY_ID = pReportingEntity->getT_FIN_ENTITY_ID();
   if (pReportingEntity->getState() != PersistentObject::NEW)
      return;
   CTV_T_FIN_ENTITY_ID = pReportingEntity->getT_FIN_ENTITY_ID();
   memcpy(CTV_ENTITY_TYPE,pReportingEntity->getENTITY_TYPE().data(),pReportingEntity->getENTITY_TYPE().length());
   CTV_ENTITY_TYPE[pReportingEntity->getENTITY_TYPE().length()] = '\0';
   memcpy(CTV_ENTITY_ID,pReportingEntity->getENTITY_ID().data(),pReportingEntity->getENTITY_ID().length());
   CTV_ENTITY_ID[pReportingEntity->getENTITY_ID().length()] = '\0';
   
/*
EXEC SQL
      INSERT INTO T_FIN_ENTITY
      (
         T_FIN_ENTITY_ID,
         ENTITY_TYPE,
         ENTITY_ID
      )
      VALUES
      (
         :CTV_T_FIN_ENTITY_ID,
         :CTV_ENTITY_TYPE,
         :CTV_ENTITY_ID
      );
*/

{
#line 366 "CXOSD242.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 366 "CXOSD242.sqx"
  sqlaaloc(2,3,5,0L);
    {
      struct sqla_setdata_list sql_setdlist[3];
#line 366 "CXOSD242.sqx"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 366 "CXOSD242.sqx"
      sql_setdlist[0].sqldata = (void*)&CTV_T_FIN_ENTITY_ID;
#line 366 "CXOSD242.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 366 "CXOSD242.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 3;
#line 366 "CXOSD242.sqx"
      sql_setdlist[1].sqldata = (void*)CTV_ENTITY_TYPE;
#line 366 "CXOSD242.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 366 "CXOSD242.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 29;
#line 366 "CXOSD242.sqx"
      sql_setdlist[2].sqldata = (void*)CTV_ENTITY_ID;
#line 366 "CXOSD242.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 366 "CXOSD242.sqx"
      sqlasetdata(2,0,3,sql_setdlist,0L,0L);
    }
#line 366 "CXOSD242.sqx"
  sqlacall((unsigned short)24,9,2,0,0L);
#line 366 "CXOSD242.sqx"
  sqlastop(0L);
}

#line 366 "CXOSD242.sqx"

   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_ENTITY %ld %s %s",CTV_T_FIN_ENTITY_ID,CTV_ENTITY_TYPE,CTV_ENTITY_ID);
      Trace::put(szTemp,-1,true);
      return;
   }
  //## end dndb2database::DB2CheckpointTotalsVisitor::visitReportingEntity%3A2D917002FA.body
}

void DB2CheckpointTotalsVisitor::visitReportingPeriod (settlement::ReportingPeriod* pReportingPeriod)
{
  //## begin dndb2database::DB2CheckpointTotalsVisitor::visitReportingPeriod%3A2D9172036B.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   if (pReportingPeriod->getState() == ReportingPeriod::SAVED)
      return;
   CTV_PERIOD_ID = pReportingPeriod->getPERIOD_ID();
   CTV_T_FIN_ENTITY_ID = m_lT_FIN_ENTITY_ID;
   memcpy(CTV_TSTAMP_END,pReportingPeriod->getTSTAMP_END().data(),pReportingPeriod->getTSTAMP_END().length());
   CTV_TSTAMP_END[pReportingPeriod->getTSTAMP_END().length()] = '\0';
   memcpy(CTV_TSTAMP_TRANS_FROM,pReportingPeriod->getTSTAMP_TRANS_FROM().data(),pReportingPeriod->getTSTAMP_TRANS_FROM().length());
   CTV_TSTAMP_TRANS_FROM[pReportingPeriod->getTSTAMP_TRANS_FROM().length()] = '\0';
   memcpy(CTV_TSTAMP_TRANS_TO,pReportingPeriod->getTSTAMP_TRANS_TO().data(),pReportingPeriod->getTSTAMP_TRANS_TO().length());
   CTV_TSTAMP_TRANS_TO[pReportingPeriod->getTSTAMP_TRANS_TO().length()] = '\0';
   memcpy(CTV_DATE_RECON,pReportingPeriod->getDATE_RECON().data(),pReportingPeriod->getDATE_RECON().length());
   CTV_DATE_RECON[pReportingPeriod->getDATE_RECON().length()] = '\0';
   memcpy(CTV_TSTAMP_LAST_UPDATED,pReportingPeriod->getTSTAMP_LAST_UPDATE().data(),pReportingPeriod->getTSTAMP_LAST_UPDATE().length());
   CTV_TSTAMP_LAST_UPDATED[pReportingPeriod->getTSTAMP_LAST_UPDATE().length()] = '\0';
   if (m_lTransaction != Database::instance()->transaction())
      lockTables();
   if (pReportingPeriod->getState() == ReportingPeriod::NEW)
   {
      Table hTable("T_FIN_PERIOD");
      hTable.set("PERIOD_ID",pReportingPeriod->getPERIOD_ID(),true);
      hTable.set("T_FIN_ENTITY_ID",m_lT_FIN_ENTITY_ID);
      hTable.set("TSTAMP_END",pReportingPeriod->getTSTAMP_END());
      hTable.set("TSTAMP_TRANS_FROM",pReportingPeriod->getTSTAMP_TRANS_FROM());
      hTable.set("TSTAMP_TRANS_TO",pReportingPeriod->getTSTAMP_TRANS_TO());
      hTable.set("DATE_RECON",pReportingPeriod->getDATE_RECON());
      hTable.set("TSTAMP_LAST_UPDATE",pReportingPeriod->getTSTAMP_LAST_UPDATE());
      auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      if (!pInsertStatement->execute(hTable))
         return;
   }
   else
   {
      
/*
EXEC SQL
         UPDATE T_FIN_PERIOD
            SET
               TSTAMP_END = :CTV_TSTAMP_END,
               TSTAMP_TRANS_FROM = :CTV_TSTAMP_TRANS_FROM,
               TSTAMP_TRANS_TO = :CTV_TSTAMP_TRANS_TO,
               DATE_RECON = :CTV_DATE_RECON,
               TSTAMP_LAST_UPDATE = :CTV_TSTAMP_LAST_UPDATED
            WHERE
               PERIOD_ID = :CTV_PERIOD_ID;
*/

{
#line 423 "CXOSD242.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 423 "CXOSD242.sqx"
  sqlaaloc(2,6,6,0L);
    {
      struct sqla_setdata_list sql_setdlist[6];
#line 423 "CXOSD242.sqx"
      sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 17;
#line 423 "CXOSD242.sqx"
      sql_setdlist[0].sqldata = (void*)CTV_TSTAMP_END;
#line 423 "CXOSD242.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 423 "CXOSD242.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 17;
#line 423 "CXOSD242.sqx"
      sql_setdlist[1].sqldata = (void*)CTV_TSTAMP_TRANS_FROM;
#line 423 "CXOSD242.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 423 "CXOSD242.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 17;
#line 423 "CXOSD242.sqx"
      sql_setdlist[2].sqldata = (void*)CTV_TSTAMP_TRANS_TO;
#line 423 "CXOSD242.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 423 "CXOSD242.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 9;
#line 423 "CXOSD242.sqx"
      sql_setdlist[3].sqldata = (void*)CTV_DATE_RECON;
#line 423 "CXOSD242.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 423 "CXOSD242.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 17;
#line 423 "CXOSD242.sqx"
      sql_setdlist[4].sqldata = (void*)CTV_TSTAMP_LAST_UPDATED;
#line 423 "CXOSD242.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 423 "CXOSD242.sqx"
      sql_setdlist[5].sqltype = 496; sql_setdlist[5].sqllen = 4;
#line 423 "CXOSD242.sqx"
      sql_setdlist[5].sqldata = (void*)&CTV_PERIOD_ID;
#line 423 "CXOSD242.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 423 "CXOSD242.sqx"
      sqlasetdata(2,0,6,sql_setdlist,0L,0L);
    }
#line 423 "CXOSD242.sqx"
  sqlacall((unsigned short)24,10,2,0,0L);
#line 423 "CXOSD242.sqx"
  sqlastop(0L);
}

#line 423 "CXOSD242.sqx"

   }
   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"       T_FIN_PERIOD %ld %ld %s %s %s %s %s",
         CTV_PERIOD_ID,CTV_T_FIN_ENTITY_ID,CTV_TSTAMP_END,CTV_TSTAMP_TRANS_FROM,CTV_TSTAMP_TRANS_TO,CTV_DATE_RECON,CTV_TSTAMP_LAST_UPDATE);
      if (pReportingPeriod->getState() == ReportingPeriod::NEW)
         memcpy(szTemp,"INSERT",6);
      else
         memcpy(szTemp,"UPDATE",6);
      Trace::put(szTemp,-1,true);
      return;
   }
   pReportingPeriod->setState(ReportingPeriod::SAVED);
  //## end dndb2database::DB2CheckpointTotalsVisitor::visitReportingPeriod%3A2D9172036B.body
}

void DB2CheckpointTotalsVisitor::visitTotal (settlement::Total* pTotal)
{
  //## begin dndb2database::DB2CheckpointTotalsVisitor::visitTotal%3A2D7158018D.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   CTV_CATEGORY_ID = pTotal->getCATEGORY_ID();
   CTV_ENTITY_GROUP_ID = pTotal->getENTITY_GROUP_ID();
   CTV_TRAN_COUNT = pTotal->getTRAN_COUNT();;
   CTV_AMT_RECON_NET = pTotal->getAMT_RECON_NET();
   CTV_AMT_TRAN = pTotal->getAMT_TRAN();
   CTV_AMT_CARD_BILL = pTotal->getAMT_CARD_BILL();
   CTV_AMT_RECON_ACQ = pTotal->getAMT_RECON_ACQ();
   CTV_AMT_RECON_ISS = pTotal->getAMT_RECON_ISS();
   memcpy(CTV_TSTAMP_LAST_UPDATE,Clock::instance()->getYYYYMMDDHHMMSS().data(),14);
   CTV_TSTAMP_LAST_UPDATE[14] = '\0';
   if (m_lTransaction != Database::instance()->transaction())
      lockTables();
   char szFunction[7] = {"UPDATE"};
   
/*
EXEC SQL
      UPDATE T_FIN_TOTAL
         SET
            TRAN_COUNT = TRAN_COUNT + :CTV_TRAN_COUNT,
            AMT_RECON_NET = AMT_RECON_NET + :CTV_AMT_RECON_NET,
            AMT_TRAN = AMT_TRAN + :CTV_AMT_TRAN,
            AMT_CARD_BILL = AMT_CARD_BILL + :CTV_AMT_CARD_BILL,
            AMT_RECON_ACQ = AMT_RECON_ACQ + :CTV_AMT_RECON_ACQ,
            AMT_RECON_ISS = AMT_RECON_ISS + :CTV_AMT_RECON_ISS,
            TSTAMP_LAST_UPDATE = :CTV_TSTAMP_LAST_UPDATE
         WHERE
            CATEGORY_ID = :CTV_CATEGORY_ID
            AND ENTITY_GROUP_ID = :CTV_ENTITY_GROUP_ID;
*/

{
#line 471 "CXOSD242.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 471 "CXOSD242.sqx"
  sqlaaloc(2,9,7,0L);
    {
      struct sqla_setdata_list sql_setdlist[9];
#line 471 "CXOSD242.sqx"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 471 "CXOSD242.sqx"
      sql_setdlist[0].sqldata = (void*)&CTV_TRAN_COUNT;
#line 471 "CXOSD242.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 471 "CXOSD242.sqx"
      sql_setdlist[1].sqltype = 480; sql_setdlist[1].sqllen = 8;
#line 471 "CXOSD242.sqx"
      sql_setdlist[1].sqldata = (void*)&CTV_AMT_RECON_NET;
#line 471 "CXOSD242.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 471 "CXOSD242.sqx"
      sql_setdlist[2].sqltype = 480; sql_setdlist[2].sqllen = 8;
#line 471 "CXOSD242.sqx"
      sql_setdlist[2].sqldata = (void*)&CTV_AMT_TRAN;
#line 471 "CXOSD242.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 471 "CXOSD242.sqx"
      sql_setdlist[3].sqltype = 480; sql_setdlist[3].sqllen = 8;
#line 471 "CXOSD242.sqx"
      sql_setdlist[3].sqldata = (void*)&CTV_AMT_CARD_BILL;
#line 471 "CXOSD242.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 471 "CXOSD242.sqx"
      sql_setdlist[4].sqltype = 480; sql_setdlist[4].sqllen = 8;
#line 471 "CXOSD242.sqx"
      sql_setdlist[4].sqldata = (void*)&CTV_AMT_RECON_ACQ;
#line 471 "CXOSD242.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 471 "CXOSD242.sqx"
      sql_setdlist[5].sqltype = 480; sql_setdlist[5].sqllen = 8;
#line 471 "CXOSD242.sqx"
      sql_setdlist[5].sqldata = (void*)&CTV_AMT_RECON_ISS;
#line 471 "CXOSD242.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 471 "CXOSD242.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 15;
#line 471 "CXOSD242.sqx"
      sql_setdlist[6].sqldata = (void*)CTV_TSTAMP_LAST_UPDATE;
#line 471 "CXOSD242.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 471 "CXOSD242.sqx"
      sql_setdlist[7].sqltype = 496; sql_setdlist[7].sqllen = 4;
#line 471 "CXOSD242.sqx"
      sql_setdlist[7].sqldata = (void*)&CTV_CATEGORY_ID;
#line 471 "CXOSD242.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 471 "CXOSD242.sqx"
      sql_setdlist[8].sqltype = 496; sql_setdlist[8].sqllen = 4;
#line 471 "CXOSD242.sqx"
      sql_setdlist[8].sqldata = (void*)&CTV_ENTITY_GROUP_ID;
#line 471 "CXOSD242.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 471 "CXOSD242.sqx"
      sqlasetdata(2,0,9,sql_setdlist,0L,0L);
    }
#line 471 "CXOSD242.sqx"
  sqlacall((unsigned short)24,11,2,0,0L);
#line 471 "CXOSD242.sqx"
  sqlastop(0L);
}

#line 471 "CXOSD242.sqx"

   if (sqlca.sqlcode == 100)
   {
      memcpy(szFunction,"INSERT",6);
      
/*
EXEC SQL
         INSERT INTO T_FIN_TOTAL
         (
            CATEGORY_ID,
            ENTITY_GROUP_ID,
            TRAN_COUNT,
            AMT_RECON_NET,
            AMT_TRAN,
            AMT_CARD_BILL,
            AMT_RECON_ACQ,
            AMT_RECON_ISS,
            TSTAMP_LAST_UPDATE
         )
         VALUES
         (
            :CTV_CATEGORY_ID,
            :CTV_ENTITY_GROUP_ID,
            :CTV_TRAN_COUNT,
            :CTV_AMT_RECON_NET,
            :CTV_AMT_TRAN,
            :CTV_AMT_CARD_BILL,
            :CTV_AMT_RECON_ACQ,
            :CTV_AMT_RECON_ISS,
            :CTV_TSTAMP_LAST_UPDATE
         );
*/

{
#line 499 "CXOSD242.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 499 "CXOSD242.sqx"
  sqlaaloc(2,9,8,0L);
    {
      struct sqla_setdata_list sql_setdlist[9];
#line 499 "CXOSD242.sqx"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 499 "CXOSD242.sqx"
      sql_setdlist[0].sqldata = (void*)&CTV_CATEGORY_ID;
#line 499 "CXOSD242.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 499 "CXOSD242.sqx"
      sql_setdlist[1].sqltype = 496; sql_setdlist[1].sqllen = 4;
#line 499 "CXOSD242.sqx"
      sql_setdlist[1].sqldata = (void*)&CTV_ENTITY_GROUP_ID;
#line 499 "CXOSD242.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 499 "CXOSD242.sqx"
      sql_setdlist[2].sqltype = 496; sql_setdlist[2].sqllen = 4;
#line 499 "CXOSD242.sqx"
      sql_setdlist[2].sqldata = (void*)&CTV_TRAN_COUNT;
#line 499 "CXOSD242.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 499 "CXOSD242.sqx"
      sql_setdlist[3].sqltype = 480; sql_setdlist[3].sqllen = 8;
#line 499 "CXOSD242.sqx"
      sql_setdlist[3].sqldata = (void*)&CTV_AMT_RECON_NET;
#line 499 "CXOSD242.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 499 "CXOSD242.sqx"
      sql_setdlist[4].sqltype = 480; sql_setdlist[4].sqllen = 8;
#line 499 "CXOSD242.sqx"
      sql_setdlist[4].sqldata = (void*)&CTV_AMT_TRAN;
#line 499 "CXOSD242.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 499 "CXOSD242.sqx"
      sql_setdlist[5].sqltype = 480; sql_setdlist[5].sqllen = 8;
#line 499 "CXOSD242.sqx"
      sql_setdlist[5].sqldata = (void*)&CTV_AMT_CARD_BILL;
#line 499 "CXOSD242.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 499 "CXOSD242.sqx"
      sql_setdlist[6].sqltype = 480; sql_setdlist[6].sqllen = 8;
#line 499 "CXOSD242.sqx"
      sql_setdlist[6].sqldata = (void*)&CTV_AMT_RECON_ACQ;
#line 499 "CXOSD242.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 499 "CXOSD242.sqx"
      sql_setdlist[7].sqltype = 480; sql_setdlist[7].sqllen = 8;
#line 499 "CXOSD242.sqx"
      sql_setdlist[7].sqldata = (void*)&CTV_AMT_RECON_ISS;
#line 499 "CXOSD242.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 499 "CXOSD242.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 15;
#line 499 "CXOSD242.sqx"
      sql_setdlist[8].sqldata = (void*)CTV_TSTAMP_LAST_UPDATE;
#line 499 "CXOSD242.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 499 "CXOSD242.sqx"
      sqlasetdata(2,0,9,sql_setdlist,0L,0L);
    }
#line 499 "CXOSD242.sqx"
  sqlacall((unsigned short)24,12,2,0,0L);
#line 499 "CXOSD242.sqx"
  sqlastop(0L);
}

#line 499 "CXOSD242.sqx"

   }
   if (!checkResult())
   {
      char szTemp[5 * PERCENTF + 3 * PERCENTLD + 2 * PERCENTS];
      snprintf(szTemp,sizeof(szTemp),"%s T_FIN_TOTAL %ld %ld %ld %f %f %f %f %f %s",
         szFunction,CTV_CATEGORY_ID,CTV_ENTITY_GROUP_ID,CTV_TRAN_COUNT,
         CTV_AMT_RECON_NET,CTV_AMT_TRAN,CTV_AMT_CARD_BILL,CTV_AMT_RECON_ACQ,
         CTV_AMT_RECON_ISS,CTV_TSTAMP_LAST_UPDATE);
      Trace::put(szTemp,-1,true);
   }
  //## end dndb2database::DB2CheckpointTotalsVisitor::visitTotal%3A2D7158018D.body
}

void DB2CheckpointTotalsVisitor::visitTotalsCategory (settlement::TotalsCategory* pTotalsCategory)
{
  //## begin dndb2database::DB2CheckpointTotalsVisitor::visitTotalsCategory%3A2D917402D7.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   CTV_CATEGORY_ID = pTotalsCategory->getCATEGORY_ID();
   memcpy(CTV_NET_ID_ACQ,pTotalsCategory->getNET_ID_ACQ().data(),pTotalsCategory->getNET_ID_ACQ().length());
   CTV_NET_ID_ACQ[pTotalsCategory->getNET_ID_ACQ().length()] = '\0';
   memcpy(CTV_NET_ID_ISS,pTotalsCategory->getNET_ID_ISS().data(),pTotalsCategory->getNET_ID_ISS().length());
   CTV_NET_ID_ISS[pTotalsCategory->getNET_ID_ISS().length()] = '\0';
   memcpy(CTV_FIN_TYPE,pTotalsCategory->getFIN_TYPE().data(),pTotalsCategory->getFIN_TYPE().length());
   CTV_FIN_TYPE[pTotalsCategory->getFIN_TYPE().length()] = '\0';
   memcpy(CTV_TRAN_TYPE_ID,pTotalsCategory->getTRAN_TYPE_ID().data(),pTotalsCategory->getTRAN_TYPE_ID().length());
   CTV_TRAN_TYPE_ID[pTotalsCategory->getTRAN_TYPE_ID().length()] = '\0';
   memcpy(CTV_ACT_CODE,pTotalsCategory->getACT_CODE().data(),pTotalsCategory->getACT_CODE().length());
   CTV_ACT_CODE[pTotalsCategory->getACT_CODE().length()] = '\0';
   memcpy(CTV_FUNC_CODE,pTotalsCategory->getFUNC_CODE().data(),pTotalsCategory->getFUNC_CODE().length());
   CTV_FUNC_CODE[pTotalsCategory->getFUNC_CODE().length()] = '\0';
   memcpy(CTV_AUTH_BY,pTotalsCategory->getAUTH_BY().data(),pTotalsCategory->getAUTH_BY().length());
   CTV_AUTH_BY[pTotalsCategory->getAUTH_BY().length()] = '\0';
   memcpy(CTV_REV_BY,pTotalsCategory->getREV_BY().data(),pTotalsCategory->getREV_BY().length());
   CTV_REV_BY[pTotalsCategory->getREV_BY().length()] = '\0';
   memcpy(CTV_CUR_RECON_NET,pTotalsCategory->getCUR_RECON_NET().data(),pTotalsCategory->getCUR_RECON_NET().length());
   CTV_CUR_RECON_NET[pTotalsCategory->getCUR_RECON_NET().length()] = '\0';
   memcpy(CTV_CUR_TRAN,pTotalsCategory->getCUR_TRAN().data(),pTotalsCategory->getCUR_TRAN().length());
   CTV_CUR_TRAN[pTotalsCategory->getCUR_TRAN().length()] = '\0';
   memcpy(CTV_CUR_CARD_BILL,pTotalsCategory->getCUR_CARD_BILL().data(),pTotalsCategory->getCUR_CARD_BILL().length());
   CTV_CUR_CARD_BILL[pTotalsCategory->getCUR_CARD_BILL().length()] = '\0';
   memcpy(CTV_CUR_RECON_ACQ,pTotalsCategory->getCUR_RECON_ACQ().data(),pTotalsCategory->getCUR_RECON_ACQ().length());
   CTV_CUR_RECON_ACQ[pTotalsCategory->getCUR_RECON_ACQ().length()] = '\0';
   memcpy(CTV_CUR_RECON_ISS,pTotalsCategory->getCUR_RECON_ISS().data(),pTotalsCategory->getCUR_RECON_ISS().length());
   CTV_CUR_RECON_ISS[pTotalsCategory->getCUR_RECON_ISS().length()] = '\0';
   memcpy(CTV_IMPACT_TO_ACQ,pTotalsCategory->getIMPACT_TO_ACQ().data(),pTotalsCategory->getIMPACT_TO_ACQ().length());
   CTV_IMPACT_TO_ACQ[pTotalsCategory->getIMPACT_TO_ACQ().length()] = '\0';
   memcpy(CTV_IMPACT_TO_ISS,pTotalsCategory->getIMPACT_TO_ISS().data(),pTotalsCategory->getIMPACT_TO_ISS().length());
   CTV_IMPACT_TO_ISS[pTotalsCategory->getIMPACT_TO_ISS().length()] = '\0';
   memcpy(CTV_TRAN_DISPOSITION,pTotalsCategory->getTRAN_DISPOSITION().data(),pTotalsCategory->getTRAN_DISPOSITION().length());
   CTV_TRAN_DISPOSITION[pTotalsCategory->getTRAN_DISPOSITION().length()] = '\0';
   memcpy(CTV_TOTAL_TYPE,pTotalsCategory->getTOTAL_TYPE().data(),pTotalsCategory->getTOTAL_TYPE().length());
   CTV_TOTAL_TYPE[pTotalsCategory->getTOTAL_TYPE().length()] = '\0';
   memcpy(CTV_TRAN_CLASS,pTotalsCategory->getTRAN_CLASS().data(),pTotalsCategory->getTRAN_CLASS().length());
   CTV_TRAN_CLASS[pTotalsCategory->getTRAN_CLASS().length()] = '\0';
   memcpy(CTV_MERCH_TYPE,pTotalsCategory->getMERCH_TYPE().data(),pTotalsCategory->getMERCH_TYPE().length());
   CTV_MERCH_TYPE[pTotalsCategory->getMERCH_TYPE().length()] = '\0';
   memcpy(CTV_NETWORK_PROGRAM,pTotalsCategory->getNETWORK_PROGRAM().data(),pTotalsCategory->getNETWORK_PROGRAM().length());
   CTV_NETWORK_PROGRAM[pTotalsCategory->getNETWORK_PROGRAM().length()] = '\0';
   
/*
EXEC SQL
      INSERT INTO T_FIN_CATEGORY
      (
         CATEGORY_ID,
         NET_ID_ACQ,
         NET_ID_ISS,
         FIN_TYPE,
         TRAN_TYPE_ID,
         ACT_CODE,
         FUNC_CODE,
         AUTH_BY,
         REV_BY,
         CUR_RECON_NET,
         CUR_TRAN,
         CUR_CARD_BILL,
         CUR_RECON_ACQ,
         CUR_RECON_ISS,
         IMPACT_TO_ACQ,
         IMPACT_TO_ISS,
         TRAN_DISPOSITION,
         TOTAL_TYPE,
         TRAN_CLASS,
         MERCH_TYPE,
         NETWORK_PROGRAM
      )
      VALUES
      (
         :CTV_CATEGORY_ID,
         :CTV_NET_ID_ACQ,
         :CTV_NET_ID_ISS,
         :CTV_FIN_TYPE,
         :CTV_TRAN_TYPE_ID,
         :CTV_ACT_CODE,
         :CTV_FUNC_CODE,
         :CTV_AUTH_BY,
         :CTV_REV_BY,
         :CTV_CUR_RECON_NET,
         :CTV_CUR_TRAN,
         :CTV_CUR_CARD_BILL,
         :CTV_CUR_RECON_ACQ,
         :CTV_CUR_RECON_ISS,
         :CTV_IMPACT_TO_ACQ,
         :CTV_IMPACT_TO_ISS,
         :CTV_TRAN_DISPOSITION,
         :CTV_TOTAL_TYPE,
         :CTV_TRAN_CLASS,
         :CTV_MERCH_TYPE,
         :CTV_NETWORK_PROGRAM
      );
*/

{
#line 607 "CXOSD242.sqx"
  sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 607 "CXOSD242.sqx"
  sqlaaloc(2,21,9,0L);
    {
      struct sqla_setdata_list sql_setdlist[21];
#line 607 "CXOSD242.sqx"
      sql_setdlist[0].sqltype = 496; sql_setdlist[0].sqllen = 4;
#line 607 "CXOSD242.sqx"
      sql_setdlist[0].sqldata = (void*)&CTV_CATEGORY_ID;
#line 607 "CXOSD242.sqx"
      sql_setdlist[0].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 607 "CXOSD242.sqx"
      sql_setdlist[1].sqldata = (void*)CTV_NET_ID_ACQ;
#line 607 "CXOSD242.sqx"
      sql_setdlist[1].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 4;
#line 607 "CXOSD242.sqx"
      sql_setdlist[2].sqldata = (void*)CTV_NET_ID_ISS;
#line 607 "CXOSD242.sqx"
      sql_setdlist[2].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[3].sqltype = 460; sql_setdlist[3].sqllen = 4;
#line 607 "CXOSD242.sqx"
      sql_setdlist[3].sqldata = (void*)CTV_FIN_TYPE;
#line 607 "CXOSD242.sqx"
      sql_setdlist[3].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 11;
#line 607 "CXOSD242.sqx"
      sql_setdlist[4].sqldata = (void*)CTV_TRAN_TYPE_ID;
#line 607 "CXOSD242.sqx"
      sql_setdlist[4].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 4;
#line 607 "CXOSD242.sqx"
      sql_setdlist[5].sqldata = (void*)CTV_ACT_CODE;
#line 607 "CXOSD242.sqx"
      sql_setdlist[5].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[6].sqltype = 460; sql_setdlist[6].sqllen = 4;
#line 607 "CXOSD242.sqx"
      sql_setdlist[6].sqldata = (void*)CTV_FUNC_CODE;
#line 607 "CXOSD242.sqx"
      sql_setdlist[6].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[7].sqltype = 460; sql_setdlist[7].sqllen = 2;
#line 607 "CXOSD242.sqx"
      sql_setdlist[7].sqldata = (void*)CTV_AUTH_BY;
#line 607 "CXOSD242.sqx"
      sql_setdlist[7].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[8].sqltype = 460; sql_setdlist[8].sqllen = 2;
#line 607 "CXOSD242.sqx"
      sql_setdlist[8].sqldata = (void*)CTV_REV_BY;
#line 607 "CXOSD242.sqx"
      sql_setdlist[8].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[9].sqltype = 460; sql_setdlist[9].sqllen = 4;
#line 607 "CXOSD242.sqx"
      sql_setdlist[9].sqldata = (void*)CTV_CUR_RECON_NET;
#line 607 "CXOSD242.sqx"
      sql_setdlist[9].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[10].sqltype = 460; sql_setdlist[10].sqllen = 4;
#line 607 "CXOSD242.sqx"
      sql_setdlist[10].sqldata = (void*)CTV_CUR_TRAN;
#line 607 "CXOSD242.sqx"
      sql_setdlist[10].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[11].sqltype = 460; sql_setdlist[11].sqllen = 4;
#line 607 "CXOSD242.sqx"
      sql_setdlist[11].sqldata = (void*)CTV_CUR_CARD_BILL;
#line 607 "CXOSD242.sqx"
      sql_setdlist[11].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[12].sqltype = 460; sql_setdlist[12].sqllen = 4;
#line 607 "CXOSD242.sqx"
      sql_setdlist[12].sqldata = (void*)CTV_CUR_RECON_ACQ;
#line 607 "CXOSD242.sqx"
      sql_setdlist[12].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[13].sqltype = 460; sql_setdlist[13].sqllen = 4;
#line 607 "CXOSD242.sqx"
      sql_setdlist[13].sqldata = (void*)CTV_CUR_RECON_ISS;
#line 607 "CXOSD242.sqx"
      sql_setdlist[13].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[14].sqltype = 460; sql_setdlist[14].sqllen = 2;
#line 607 "CXOSD242.sqx"
      sql_setdlist[14].sqldata = (void*)CTV_IMPACT_TO_ACQ;
#line 607 "CXOSD242.sqx"
      sql_setdlist[14].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[15].sqltype = 460; sql_setdlist[15].sqllen = 2;
#line 607 "CXOSD242.sqx"
      sql_setdlist[15].sqldata = (void*)CTV_IMPACT_TO_ISS;
#line 607 "CXOSD242.sqx"
      sql_setdlist[15].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[16].sqltype = 460; sql_setdlist[16].sqllen = 2;
#line 607 "CXOSD242.sqx"
      sql_setdlist[16].sqldata = (void*)CTV_TRAN_DISPOSITION;
#line 607 "CXOSD242.sqx"
      sql_setdlist[16].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[17].sqltype = 460; sql_setdlist[17].sqllen = 5;
#line 607 "CXOSD242.sqx"
      sql_setdlist[17].sqldata = (void*)CTV_TOTAL_TYPE;
#line 607 "CXOSD242.sqx"
      sql_setdlist[17].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[18].sqltype = 460; sql_setdlist[18].sqllen = 4;
#line 607 "CXOSD242.sqx"
      sql_setdlist[18].sqldata = (void*)CTV_TRAN_CLASS;
#line 607 "CXOSD242.sqx"
      sql_setdlist[18].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[19].sqltype = 460; sql_setdlist[19].sqllen = 5;
#line 607 "CXOSD242.sqx"
      sql_setdlist[19].sqldata = (void*)CTV_MERCH_TYPE;
#line 607 "CXOSD242.sqx"
      sql_setdlist[19].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sql_setdlist[20].sqltype = 460; sql_setdlist[20].sqllen = 11;
#line 607 "CXOSD242.sqx"
      sql_setdlist[20].sqldata = (void*)CTV_NETWORK_PROGRAM;
#line 607 "CXOSD242.sqx"
      sql_setdlist[20].sqlind = 0L;
#line 607 "CXOSD242.sqx"
      sqlasetdata(2,0,21,sql_setdlist,0L,0L);
    }
#line 607 "CXOSD242.sqx"
  sqlacall((unsigned short)24,13,2,0,0L);
#line 607 "CXOSD242.sqx"
  sqlastop(0L);
}

#line 607 "CXOSD242.sqx"

   if (!checkResult())
   {
      char szTemp[133];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_CATEGORY %ld %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
         CTV_CATEGORY_ID,CTV_NET_ID_ACQ,CTV_NET_ID_ISS,CTV_FIN_TYPE,CTV_TRAN_TYPE_ID,
         CTV_ACT_CODE,CTV_FUNC_CODE,CTV_AUTH_BY,CTV_REV_BY,CTV_CUR_RECON_NET,CTV_CUR_TRAN,
         CTV_CUR_CARD_BILL,CTV_CUR_RECON_ACQ,CTV_CUR_RECON_ISS,CTV_IMPACT_TO_ACQ,
         CTV_IMPACT_TO_ISS,CTV_TRAN_DISPOSITION,CTV_TOTAL_TYPE,CTV_TRAN_CLASS,CTV_MERCH_TYPE,CTV_NETWORK_PROGRAM);
      Trace::put(szTemp,-1,true);
      return;
   }
  //## end dndb2database::DB2CheckpointTotalsVisitor::visitTotalsCategory%3A2D917402D7.body
}

// Additional Declarations
  //## begin dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.declarations preserve=yes
  //## end dndb2database::DB2CheckpointTotalsVisitor%3A2D711201AB.declarations

} // namespace dndb2database

//## begin module%3A2D728103A7.epilog preserve=yes
//## end module%3A2D728103A7.epilog
