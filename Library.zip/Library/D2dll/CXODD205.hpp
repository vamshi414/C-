//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%405A25B00399.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%405A25B00399.cm

//## begin module%405A25B00399.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%405A25B00399.cp

//## Module: CXOSD205%405A25B00399; Package specification
//## Subsystem: D2DLL%3597E8A6029B
//	.
//## Source file: C:\Devel\Dn\Server\Library\D2DLL\CXODD205.hpp

#ifndef CXOSD205_h
#define CXOSD205_h 1

//## begin module%405A25B00399.additionalIncludes preserve=no
//## end module%405A25B00399.additionalIncludes

//## begin module%405A25B00399.includes preserve=yes
// $Date:   Jun 30 2006 12:15:44  $ $Author:   D02405  $ $Revision:   1.2  $
//## end module%405A25B00399.includes

#ifndef CXOSDB03_h
#include "CXODDB03.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class SiteSpecification;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;

} // namespace timer

//## begin module%405A25B00399.declarations preserve=no
//## end module%405A25B00399.declarations

//## begin module%405A25B00399.additionalDeclarations preserve=yes
//## end module%405A25B00399.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
//## begin dndb2database%346CAA2702B3.initialDeclarations preserve=yes
//## end dndb2database%346CAA2702B3.initialDeclarations

//## begin dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.preface preserve=yes
//## end dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.preface

//## Class: DB2MaintenanceProcedure%405A1E2D03D8
//## Category: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
//## Subsystem: D2DLL%3597E8A6029B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%405B08ED01B5;IF::SiteSpecification { -> F}
//## Uses: <unnamed>%405B6D1C0167;timer::Date { -> F}

class DllExport DB2MaintenanceProcedure : public database::MaintenanceProcedure  //## Inherits: <unnamed>%405A1E5E005D
{
  //## begin dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.initialDeclarations preserve=yes
  //## end dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.initialDeclarations

  public:
    //## Constructors (generated)
      DB2MaintenanceProcedure();

    //## Destructor (generated)
      virtual ~DB2MaintenanceProcedure();


    //## Other Operations (specified)
      //## Operation: review%405A1E900119
      virtual void review (const char* pszText);

    // Additional Public Declarations
      //## begin dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.public preserve=yes
      //## end dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.public

  protected:
    // Additional Protected Declarations
      //## begin dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.protected preserve=yes
      //## end dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.protected

  private:
    // Additional Private Declarations
      //## begin dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.private preserve=yes
      //## end dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: FreePages%405AF6B00138
      //## begin dndb2database::DB2MaintenanceProcedure::FreePages%405AF6B00138.attr preserve=no  private: int {V} 0
      int m_lFreePages;
      //## end dndb2database::DB2MaintenanceProcedure::FreePages%405AF6B00138.attr

      //## Attribute: Name%405AF68401C5
      //## begin dndb2database::DB2MaintenanceProcedure::Name%405AF68401C5.attr preserve=no  private: string {V} 
      string m_strName;
      //## end dndb2database::DB2MaintenanceProcedure::Name%405AF68401C5.attr

      //## Attribute: TotalPages%405AF69B030D
      //## begin dndb2database::DB2MaintenanceProcedure::TotalPages%405AF69B030D.attr preserve=no  private: int {V} 0
      int m_lTotalPages;
      //## end dndb2database::DB2MaintenanceProcedure::TotalPages%405AF69B030D.attr

      //## Attribute: UsedPages%405AF6B0004E
      //## begin dndb2database::DB2MaintenanceProcedure::UsedPages%405AF6B0004E.attr preserve=no  private: int {V} 0
      int m_lUsedPages;
      //## end dndb2database::DB2MaintenanceProcedure::UsedPages%405AF6B0004E.attr

    // Additional Implementation Declarations
      //## begin dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.implementation preserve=yes
      //## end dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.implementation

};

//## begin dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.postscript preserve=yes
//## end dndb2database::DB2MaintenanceProcedure%405A1E2D03D8.postscript

} // namespace dndb2database

//## begin module%405A25B00399.epilog preserve=yes
using namespace dndb2database;
//## end module%405A25B00399.epilog


#endif
