//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4B1559350217.cm preserve=no
//	$Date:   Sep 07 2010 14:15:54  $ $Author:   d08878  $
//	$Revision:   1.4  $
//## end module%4B1559350217.cm

//## begin module%4B1559350217.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4B1559350217.cp

//## Module: CXOSDZ05%4B1559350217; Package specification
//## Subsystem: DZDLL%4085142703C8
//## Source file: C:\Devel\Dn\Server\Library\Dzdll\CXODDZ05.hpp

#ifndef CXOSDZ05_h
#define CXOSDZ05_h 1

//## begin module%4B1559350217.additionalIncludes preserve=no
//## end module%4B1559350217.additionalIncludes

//## begin module%4B1559350217.includes preserve=yes
//## end module%4B1559350217.includes

#ifndef CXOSIF56_h
#include "CXODIF56.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Memory;
class ZosFile;
class WindowsFile;
class UnixFile;
class File;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class ZosEncryptedFile;

} // namespace database

//## begin module%4B1559350217.declarations preserve=no
//## end module%4B1559350217.declarations

//## begin module%4B1559350217.additionalDeclarations preserve=yes
//## end module%4B1559350217.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

//## begin dnplatform::DataSetFactory%4B1558EA01F4.preface preserve=yes
//## end dnplatform::DataSetFactory%4B1558EA01F4.preface

//## Class: DataSetFactory%4B1558EA01F4
//## Category: DataNavigator Foundation::DNPlatform_CAT%408511960157
//## Subsystem: DZDLL%4085142703C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4B15617D0161;IF::ZosFile { -> F}
//## Uses: <unnamed>%4B15617F0178;database::ZosEncryptedFile { -> F}
//## Uses: <unnamed>%4B156181013F;IF::UnixFile { -> F}
//## Uses: <unnamed>%4B15618302A1;IF::WindowsFile { -> F}
//## Uses: <unnamed>%4B156DEF0082;IF::File { -> F}
//## Uses: <unnamed>%4B1574EC023B;IF::Memory { -> F}
//## Uses: <unnamed>%4C86887F00D6;IF::Trace { -> F}
//## Uses: <unnamed>%4C8688A102BC;reusable::Buffer { -> F}

class DllExport DataSetFactory : public IF::OperatingSystemFileFactory  //## Inherits: <unnamed>%4B15590B00F0
{
  //## begin dnplatform::DataSetFactory%4B1558EA01F4.initialDeclarations preserve=yes
  //## end dnplatform::DataSetFactory%4B1558EA01F4.initialDeclarations

  public:
    //## Constructors (generated)
      DataSetFactory();

    //## Destructor (generated)
      virtual ~DataSetFactory();


    //## Other Operations (specified)
      //## Operation: create%4B156C02001B
      virtual IF::File* create ();

      //## Operation: create%4B156C020039
      virtual IF::File* create (const char* pszName);

      //## Operation: create%4B156C02004D
      virtual IF::File* create (const char* pszName, const char* pszMember);

    // Additional Public Declarations
      //## begin dnplatform::DataSetFactory%4B1558EA01F4.public preserve=yes
      //## end dnplatform::DataSetFactory%4B1558EA01F4.public

  protected:
    // Additional Protected Declarations
      //## begin dnplatform::DataSetFactory%4B1558EA01F4.protected preserve=yes
      //## end dnplatform::DataSetFactory%4B1558EA01F4.protected

  private:

    //## Other Operations (specified)
      //## Operation: initialize%4C4DBE140310
      void initialize ();

    // Additional Private Declarations
      //## begin dnplatform::DataSetFactory%4B1558EA01F4.private preserve=yes
      //## end dnplatform::DataSetFactory%4B1558EA01F4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: FileMap%4C4DD5C902D1
      //## begin dnplatform::DataSetFactory::FileMap%4C4DD5C902D1.attr preserve=no  private: map<string, pair<int, int>, less<string> > {V} 
      map<string, pair<int, int>, less<string> > m_hFileMap;
      //## end dnplatform::DataSetFactory::FileMap%4C4DD5C902D1.attr

      //## Attribute: Initialized%4C72DF90009A
      //## begin dnplatform::DataSetFactory::Initialized%4C72DF90009A.attr preserve=no  public: bool {U} false
      bool m_bInitialized;
      //## end dnplatform::DataSetFactory::Initialized%4C72DF90009A.attr

    // Additional Implementation Declarations
      //## begin dnplatform::DataSetFactory%4B1558EA01F4.implementation preserve=yes
      //## end dnplatform::DataSetFactory%4B1558EA01F4.implementation

};

//## begin dnplatform::DataSetFactory%4B1558EA01F4.postscript preserve=yes
//## end dnplatform::DataSetFactory%4B1558EA01F4.postscript

} // namespace dnplatform

//## begin module%4B1559350217.epilog preserve=yes
//## end module%4B1559350217.epilog


#endif
