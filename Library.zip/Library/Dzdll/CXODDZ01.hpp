//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40851444031C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40851444031C.cm

//## begin module%40851444031C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40851444031C.cp

//## Module: CXOSDZ01%40851444031C; Package specification
//## Subsystem: DZDLL%4085142703C8
//## Source file: C:\Devel\Dn\Server\Library\Dzdll\CXODDZ01.hpp

#ifndef CXOSDZ01_h
#define CXOSDZ01_h 1

//## begin module%40851444031C.additionalIncludes preserve=no
//## end module%40851444031C.additionalIncludes

//## begin module%40851444031C.includes preserve=yes
// $Date:   Jul 23 2004 08:39:48  $ $Author:   D92186  $ $Revision:   1.2  $
//## end module%40851444031C.includes

#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif

//## Modelname: DataNavigator Foundation::DNDB2Database_CAT%346CAA2702B3
namespace dndb2database {
class DNDB2DatabaseFactory;
} // namespace dndb2database

//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
class DNODBCDatabaseFactory;
} // namespace dnodbcdatabase

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%40851444031C.declarations preserve=no
//## end module%40851444031C.declarations

//## begin module%40851444031C.additionalDeclarations preserve=yes
//## end module%40851444031C.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

//## begin dnplatform::DNPlatform%408511E3005D.preface preserve=yes
//## end dnplatform::DNPlatform%408511E3005D.preface

//## Class: DNPlatform%408511E3005D
//## Category: DataNavigator Foundation::DNPlatform_CAT%408511960157
//## Subsystem: DZDLL%4085142703C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4085127702CE;IF::Extract { -> F}
//## Uses: <unnamed>%4085127A03D8;database::Database { -> F}
//## Uses: <unnamed>%4085128B0280;dndb2database::DNDB2DatabaseFactory { -> F}
//## Uses: <unnamed>%4100143401E4;dnodbcdatabase::DNODBCDatabaseFactory { -> F}

class DllExport DNPlatform : public platform::Platform  //## Inherits: <unnamed>%408512A60186
{
  //## begin dnplatform::DNPlatform%408511E3005D.initialDeclarations preserve=yes
  //## end dnplatform::DNPlatform%408511E3005D.initialDeclarations

  public:
    //## Constructors (generated)
      DNPlatform();

    //## Destructor (generated)
      virtual ~DNPlatform();


    //## Other Operations (specified)
      //## Operation: createDatabaseFactory%40851224000F
      virtual void createDatabaseFactory ();

    // Additional Public Declarations
      //## begin dnplatform::DNPlatform%408511E3005D.public preserve=yes
      //## end dnplatform::DNPlatform%408511E3005D.public

  protected:
    // Additional Protected Declarations
      //## begin dnplatform::DNPlatform%408511E3005D.protected preserve=yes
      //## end dnplatform::DNPlatform%408511E3005D.protected

  private:
    // Additional Private Declarations
      //## begin dnplatform::DNPlatform%408511E3005D.private preserve=yes
      //## end dnplatform::DNPlatform%408511E3005D.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dnplatform::DNPlatform%408511E3005D.implementation preserve=yes
      //## end dnplatform::DNPlatform%408511E3005D.implementation

};

//## begin dnplatform::DNPlatform%408511E3005D.postscript preserve=yes
//## end dnplatform::DNPlatform%408511E3005D.postscript

} // namespace dnplatform

//## begin module%40851444031C.epilog preserve=yes
using namespace dnplatform;
//## end module%40851444031C.epilog


#endif
