//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5B8854B80275.cm preserve=no
//## end module%5B8854B80275.cm

//## begin module%5B8854B80275.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5B8854B80275.cp

//## Module: CXOSDZ08%5B8854B80275; Package body
//## Subsystem: DZDLL%4085142703C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Dzdll\CXOSDZ08.cpp

//## begin module%5B8854B80275.additionalIncludes preserve=no
//## end module%5B8854B80275.additionalIncludes

//## begin module%5B8854B80275.includes preserve=yes
//## end module%5B8854B80275.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDZ08_h
#include "CXODDZ08.hpp"
#endif
#ifndef CXOSME45_h
#include "CXODME45.hpp"
#endif


//## begin module%5B8854B80275.declarations preserve=no
//## end module%5B8854B80275.declarations

//## begin module%5B8854B80275.additionalDeclarations preserve=yes
#ifndef CXOSVE45_h
#include "CXODVE45.hpp"
#endif
//## end module%5B8854B80275.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

// Class dnplatform::APIQueueExportFactory 

//## begin dnplatform::APIQueueExportFactory::APIQueueExport%6675F6A60120.attr preserve=no  private: static map<string, command::APIExport*, less<string> >* {U} 0
map<string, command::APIExport*, less<string> >* APIQueueExportFactory::m_pAPIQueueExport = 0;
//## end dnplatform::APIQueueExportFactory::APIQueueExport%6675F6A60120.attr

APIQueueExportFactory::APIQueueExportFactory()
  //## begin APIQueueExportFactory::APIQueueExportFactory%5B8854730054_const.hasinit preserve=no
  //## end APIQueueExportFactory::APIQueueExportFactory%5B8854730054_const.hasinit
  //## begin APIQueueExportFactory::APIQueueExportFactory%5B8854730054_const.initialization preserve=yes
  //## end APIQueueExportFactory::APIQueueExportFactory%5B8854730054_const.initialization
{
  //## begin dnplatform::APIQueueExportFactory::APIQueueExportFactory%5B8854730054_const.body preserve=yes
   memcpy(m_sID, "DZ08", 4);
#define CLASSES 2
   const char* pszClass[CLASSES] =
   {
      "MCI",
      "VCR"
   };
   if (!m_pAPIQueueExport)
   {
      m_pAPIQueueExport = new map<string, command::APIExport*, less<string> >;
      for (int i = 0; i < CLASSES; ++i)
         switch (i)
         {
         case 0:
            m_pAPIQueueExport->insert(map<string, command::APIExport*, less<string> >::value_type(string(pszClass[i]), new mastercardexception::MasterComAPIQueueExport));
            break;
         case 1:
            m_pAPIQueueExport->insert(map<string, command::APIExport*, less<string> >::value_type(string(pszClass[i]), new visaexception::VisaQueueExport));
            break;
         }
   }
  //## end dnplatform::APIQueueExportFactory::APIQueueExportFactory%5B8854730054_const.body
}


APIQueueExportFactory::~APIQueueExportFactory()
{
  //## begin dnplatform::APIQueueExportFactory::~APIQueueExportFactory%5B8854730054_dest.body preserve=yes
  //## end dnplatform::APIQueueExportFactory::~APIQueueExportFactory%5B8854730054_dest.body
}



//## Other Operations (implementation)
command::APIExport* APIQueueExportFactory::create (const char* pszAPIType)
{
  //## begin dnplatform::APIQueueExportFactory::create%5B8858750167.body preserve=yes
   Trace::put("DZ08");
   string strClass(pszAPIType, 3);
   Trace::put(strClass.c_str());
   map<string, command::APIExport*, less<string> >::iterator pClass = m_pAPIQueueExport->find(strClass);
   if (pClass == m_pAPIQueueExport->end())
   {
      pair<map<string, command::APIExport*, less<string> >::iterator, bool> hResult;
      hResult = m_pAPIQueueExport->insert(map<string, command::APIExport*, less<string> >::value_type(strClass, new command::APIExport));
      return (*hResult.first).second;
   }
   Trace::put("found class");
   return (*pClass).second;
  //## end dnplatform::APIQueueExportFactory::create%5B8858750167.body
}

// Additional Declarations
  //## begin dnplatform::APIQueueExportFactory%5B8854730054.declarations preserve=yes
  //## end dnplatform::APIQueueExportFactory%5B8854730054.declarations

} // namespace dnplatform

//## begin module%5B8854B80275.epilog preserve=yes
//## end module%5B8854B80275.epilog
