//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%49E370590138.cm preserve=no
//	$Date:   Sep 10 2020 08:36:26  $ $Author:   e1009652  $
//	$Revision:   1.23  $
//## end module%49E370590138.cm

//## begin module%49E370590138.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%49E370590138.cp

//## Module: CXOSDZ02%49E370590138; Package body
//## Subsystem: DZDLL%4085142703C8
//## Source file: C:\DevelVCR\Dn\Server\Library\Dzdll\CXOSDZ02.cpp

//## begin module%49E370590138.additionalIncludes preserve=no
//## end module%49E370590138.additionalIncludes

//## begin module%49E370590138.includes preserve=yes
#ifndef CXOSVE37_h
#include "CXODVE37.hpp"
#endif
#ifndef CXOSVE38_h
#include "CXODVE38.hpp"
#endif
#ifndef CXOSME46_h
#include "CXODME46.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSEX81_h
#include "CXODEX81.hpp"
#endif
#include "CXODEE11.hpp"
#include "CXODEX89.hpp"
#include "CXODEX90.hpp"
#include "CXODEX94.hpp"
//## end module%49E370590138.includes

#ifndef CXOSRA02_h
#include "CXODRA02.hpp"
#endif
#ifndef CXOSRA06_h
#include "CXODRA06.hpp"
#endif
#ifndef CXOSRL18_h
#include "CXODRL18.hpp"
#endif
#ifndef CXOSRA04_h
#include "CXODRA04.hpp"
#endif
#ifndef CXOSEX59_h
#include "CXODEX59.hpp"
#endif
#ifndef CXOSEX64_h
#include "CXODEX64.hpp"
#endif
#ifndef CXOSME24_h
#include "CXODME24.hpp"
#endif
#ifndef CXOSNE04_h
#include "CXODNE04.hpp"
#endif
#ifndef CXOSSE08_h
#include "CXODSE08.hpp"
#endif
#ifndef CXOSVE19_h
#include "CXODVE19.hpp"
#endif
#ifndef CXOSSE09_h
#include "CXODSE09.hpp"
#endif
#ifndef CXOSVE33_h
#include "CXODVE33.hpp"
#endif
#ifndef CXOSEX74_h
#include "CXODEX74.hpp"
#endif
#ifndef CXOSME36_h
#include "CXODME36.hpp"
#endif
#ifndef CXOSEX72_h
#include "CXODEX72.hpp"
#endif
#ifndef CXOSEX83_h
#include "CXODEX83.hpp"
#endif
#ifndef CXOSEX84_h
#include "CXODEX84.hpp"
#endif
#ifndef CXOSDZ02_h
#include "CXODDZ02.hpp"
#endif


//## begin module%49E370590138.declarations preserve=no
//## end module%49E370590138.declarations

//## begin module%49E370590138.additionalDeclarations preserve=yes
#ifndef CXOSEX81_h
#include "CXODEX81.hpp"
#endif
//## end module%49E370590138.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

// Class dnplatform::ActionFactory 

ActionFactory::ActionFactory()
  //## begin ActionFactory::ActionFactory%49E36E450177_const.hasinit preserve=no
  //## end ActionFactory::ActionFactory%49E36E450177_const.hasinit
  //## begin ActionFactory::ActionFactory%49E36E450177_const.initialization preserve=yes
  //## end ActionFactory::ActionFactory%49E36E450177_const.initialization
{
  //## begin dnplatform::ActionFactory::ActionFactory%49E36E450177_const.body preserve=yes
   memcpy(m_sID,"DZ02",4);
  //## end dnplatform::ActionFactory::ActionFactory%49E36E450177_const.body
}


ActionFactory::~ActionFactory()
{
  //## begin dnplatform::ActionFactory::~ActionFactory%49E36E450177_dest.body preserve=yes
  //## end dnplatform::ActionFactory::~ActionFactory%49E36E450177_dest.body
}



//## Other Operations (implementation)
rules::Function* ActionFactory::create (const char* pszClass, const char* pszValue)
{
  //## begin dnplatform::ActionFactory::create%49E3711A030D.body preserve=yes
   Trace::put("DZ02create1");
   if(m_hClasses.size() == 0)
   {
      #define CLASSES 38
      const char* pszClass[CLASSES] =
      {
         "IDM",               //0
         "SYS_DOC001",        //1
         "SYS_DOC002",        //2
         "SYS_DOC003",        //3
         "SYS_DOC004",        //4
         "EXP_VROL",          //5
         "EXP_VROL_F",        //6
         "EXP_VROL_Q",        //7
         "SETAPF",            //8
         "USAGE_CD",          //9
         "EXP_MCP",           //10
         "SETEXCPTYP",        //11
         "SETADJFLG",         //12
         "SETCHBCODE",        //13
         "SYS_DOC007",        //14
         "EXP_VCR",           //15
         "DEL_ATRN",          //16
         "DEL_VCR",           //17
         "VCR_BILL",          //18
         "CHECKDOCS",         //19
         "CHKFORCHB",         //20
         "EXP_MCI",           //21
         "DEL_MCI",           //22
         "EXP_MCDOC",         //23
         "SEND_PROV",         //24
         "SET_RSNCD",         //25
         "SYS_DOC010",        //26
         "SYS_DOC012",        //27
         "SYS_DOC014",        //28
         "SYS_DOC022",        //29
         "SYS_DOC025",        //30
         "SYS_DOC016",        //31
         "SYS_DOC017",        //32
         "SYS_DOC023",        //33
         "EXP_EHB",           //34
         "AUDIT",             //35
         "LTR_CODE",          //36
         "SET_MMT"            //37
      };
      for (int i = 0; i < CLASSES; ++i)
         m_hClasses.insert(map<string,int,less<string> >::value_type(string(pszClass[i]),i));
   }
   Trace::put("DZ02create2");
   map<string,int,less<string> >::iterator pClass = m_hClasses.find(string(pszClass));
   if (pClass == m_hClasses.end())
      return 0;
   Trace::put("DZ02create3");
   rules::Function* pFunction = 0;
   switch ((*pClass).second)
   {
      case 0:
         pFunction = new regionsapi::ProvisionalCredit();
         break;
      case 1:
      case 2:
      case 3:
      case 4:
      case 14:
         pFunction = new regionsapi::BulkPrintAction();
         break;
      case 5:
      case 6:
      case 7:
         pFunction = new regionsapi::VROLAction();
         break;
      case 8:
         pFunction = new ems::SetAccountingProcessedFlag();
         break;
      case 9:
         pFunction = new ems::SetUsageCode();
         break;
      case 10:
      case 23:
         pFunction = new mastercardexception::MasterCommProExportAction();
         break;
      case 11:
         pFunction = new nyceexception::SetNyceExceptionType();
         break;
      case 12:
         pFunction = new starexception::SetStarAdjustmentType();
         break;
      case 13:
         pFunction = new starexception::SetChargebackReasonPrefix();
         break;
      case 15:
         pFunction = new visaexception::VCRExportAction();
         break;
      case 16:
         pFunction = new ems::DeleteAssociatedTrans();
         break;
      case 17:
         pFunction = new visaexception::VCRDeleteAction();
         break;
      case 18:
         pFunction = new ems::APIBilling();
         break;
      case 19:
         pFunction = new visaexception::CheckForDocsToSend();
         break;
      case 20:
         pFunction = new visaexception::CheckForChargeback();
         break;
      case 21:
         Trace::put("DZ02create4");
         pFunction = new mastercardexception::MasterComAPIExportAction();
         break;
      case 22:
         pFunction = new mastercardexception::MasterComAPIDeleteAction();
         break;
      case 24:
         pFunction = new ems::ProvisionalCredit();
         break;
      case 25:
         pFunction = new ems::PhaseReasonCode(); 
         break;
      case 26:
      case 27:
      case 28:
      case 29:
      case 30:
      case 31:
      case 32:
      case 33:
         pFunction = new ems::SECUSystemDocs();
         break;
      case 34:
         pFunction = new eftposexception::EFTPosExportAction();
         break;
      case 35:
         pFunction = new ems::AuditAction();
         break;
      case 36:
         pFunction = new ems::LetterCodeAction();
         break;
      case 37:
         pFunction = new ems::MMTAction();
         break;
   }
   Trace::put("DZ02create5");
   return pFunction;
  //## end dnplatform::ActionFactory::create%49E3711A030D.body
}

// Additional Declarations
  //## begin dnplatform::ActionFactory%49E36E450177.declarations preserve=yes
  //## end dnplatform::ActionFactory%49E36E450177.declarations

} // namespace dnplatform

//## begin module%49E370590138.epilog preserve=yes
//## end module%49E370590138.epilog
