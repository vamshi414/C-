//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4ADF120D03B9.cm preserve=no
//## end module%4ADF120D03B9.cm

//## begin module%4ADF120D03B9.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4ADF120D03B9.cp

//## Module: CXOSDZ03%4ADF120D03B9; Package specification
//## Subsystem: DZDLL%4085142703C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Dzdll\CXODDZ03.hpp

#ifndef CXOSDZ03_h
#define CXOSDZ03_h 1

//## begin module%4ADF120D03B9.additionalIncludes preserve=no
//## end module%4ADF120D03B9.additionalIncludes

//## begin module%4ADF120D03B9.includes preserve=yes
//## end module%4ADF120D03B9.includes

#ifndef CXOSBC30_h
#include "CXODBC30.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::GenericException_CAT%4ADF1B4C003E
namespace genericexception {
class RepresentmentQuestionnaire;
} // namespace genericexception

//## Modelname: Transaction Research and Adjustments::VisaException_CAT%4097A16101D4
namespace visaexception {
class DisputeResponse;
class TranInquiryResponse;
class VisaChargebackAdvice;
} // namespace visaexception

//## Modelname: Transaction Research and Adjustments::MasterCardException_CAT%4242FC56001F
namespace mastercardexception {
class RepresentmentDocumentation;
class ChargebackDocumentation;
class RetrievalRuling;
class RetrievalFulfillment;
class IPMExceptionReject;
class IPMFeeCollection;
class RetrievalRequest;
} // namespace mastercardexception

namespace genericexception {
class ChargebackQuestionnaire;
class RFCNonFulfillment;
class RFCFulfillment;
class RFCAdvice;
} // namespace genericexception

namespace mastercardexception {
class FeeCollection;
} // namespace mastercardexception

namespace genericexception {
class ChargebackFinancial;
} // namespace genericexception

//## Modelname: Transaction Research and Adjustments::RegionalException_CAT (RG)%4CC5F99C02E9
namespace regionalexception {
class CaseFilingRuling;
class RetrievalRequest;
} // namespace regionalexception

namespace genericexception {
class CaseFilingCompliance;
class CaseFilingArbitration;
class ArbitrationResponse;
class Arbitration;
class ComplianceResponse;
class Compliance;
class FraudUploadReport;
class RFCRejectReturn;
class RepresentmentReversal;
class RejectionLetter;
class PreComplianceResponse;
class PreArbitrationResponse;
class ChargebackReversal;
class FraudRejectReturn;
class FraudReport;
class MiscellaneousFee;
class FinalDecisionLetter;
class ContactMessage;
class AcknowledgementLetter;
class PreCompliance;
class PreArbitration;
class AdjustmentReject;
class Adjustment;
class RepresentmentAdvice;
class RepresentmentReject;
class ChargebackReject;
class RepresentmentFinancial;
class FeeCollectionReject;
class PreComplianceReject;
class PreArbitrationReject;
class ChargebackReversalReject;
class DocumentAdd;
class ChargebackHold;
class PreComplianceRecall;
class PreArbitrationRecall;
class UnworkedCase;
class RepresentmentQuestionnaireWithFinancialInfo;
class ChargebackQuestionnaireWithFinancialInfo;
class FundDisbursement;
class FeeCollection;
class CaseFilingResponseUpload;
class Comment;
} // namespace genericexception

namespace regionalexception {
class GoodFaith;
class MerchantAuthorizedTransaction;
class DepositCorrection;
class ChargebackFinancial;
class UnworkedCase;
class ArbitrationResponse;
class UpdateStatus;
class AdjustmentReversal;
class Adjustment;
class CorrectionResponse;
class CorrectionRequest;
class GoodFaithResponse;
class FreeFormResponse;
class FreeFormRequest;
class SecondChargeback;
} // namespace regionalexception

//## Modelname: Transaction Research and Adjustments::CUPException_CAT%4E2ED9570266
namespace cupexception {
class CupSecondChargeback;
class CupRepresentmentFinancial;
class CupAdjustment;
class CupChargebackFinancial;
} // namespace cupexception

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Event;

} // namespace command

//## begin module%4ADF120D03B9.declarations preserve=no
//## end module%4ADF120D03B9.declarations

//## begin module%4ADF120D03B9.additionalDeclarations preserve=yes
//## end module%4ADF120D03B9.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

//## begin dnplatform::ExceptionFactory%4ADF118A0261.preface preserve=yes
//## end dnplatform::ExceptionFactory%4ADF118A0261.preface

//## Class: ExceptionFactory%4ADF118A0261
//## Category: DataNavigator Foundation::DNPlatform_CAT%408511960157
//## Subsystem: DZDLL%4085142703C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4ADF11EC0196;command::Event { -> F}
//## Uses: <unnamed>%4AE19DE40251;visaexception::VisaChargebackAdvice { -> F}
//## Uses: <unnamed>%4AEB10210186;genericexception::RFCAdvice { -> F}
//## Uses: <unnamed>%4AEEF91B0280;genericexception::RFCFulfillment { -> F}
//## Uses: <unnamed>%4AEEF91E009C;genericexception::RFCNonFulfillment { -> F}
//## Uses: <unnamed>%4AF823E601D4;genericexception::ChargebackQuestionnaire { -> F}
//## Uses: <unnamed>%4AF823E902BF;genericexception::RepresentmentQuestionnaire { -> F}
//## Uses: <unnamed>%4AF832F1037A;genericexception::ChargebackFinancial { -> F}
//## Uses: <unnamed>%4AF832F502AF;genericexception::ChargebackReject { -> F}
//## Uses: <unnamed>%4AF832F80196;genericexception::RepresentmentAdvice { -> F}
//## Uses: <unnamed>%4AF832FA03C8;genericexception::RepresentmentFinancial { -> F}
//## Uses: <unnamed>%4AF832FD037A;genericexception::RepresentmentReject { -> F}
//## Uses: <unnamed>%4AF83CD5034B;genericexception::Adjustment { -> F}
//## Uses: <unnamed>%4AF83CD802AF;genericexception::AdjustmentReject { -> F}
//## Uses: <unnamed>%4AF8400A0280;genericexception::PreArbitration { -> F}
//## Uses: <unnamed>%4AF8400D0261;genericexception::PreCompliance { -> F}
//## Uses: <unnamed>%4AF84D6F005D;genericexception::AcknowledgementLetter { -> F}
//## Uses: <unnamed>%4AF84D740232;genericexception::ContactMessage { -> F}
//## Uses: <unnamed>%4AF84D77033C;genericexception::FinalDecisionLetter { -> F}
//## Uses: <unnamed>%4AF86EA501A5;genericexception::MiscellaneousFee { -> F}
//## Uses: <unnamed>%4AF86EA80232;genericexception::FraudReport { -> F}
//## Uses: <unnamed>%4AF86EAC000F;genericexception::FraudRejectReturn { -> F}
//## Uses: <unnamed>%4AF87C2203D8;genericexception::PreArbitrationResponse { -> F}
//## Uses: <unnamed>%4AF87C250232;genericexception::PreComplianceResponse { -> F}
//## Uses: <unnamed>%4AF8838B034B;genericexception::RejectionLetter { -> F}
//## Uses: <unnamed>%4AF95FD500BB;genericexception::RFCRejectReturn { -> F}
//## Uses: <unnamed>%4B0D73AF000F;genericexception::FraudUploadReport { -> F}
//## Uses: <unnamed>%4B5783650249;genericexception::Compliance { -> F}
//## Uses: <unnamed>%4B5783690229;genericexception::Arbitration { -> F}
//## Uses: <unnamed>%4B57837300F0;genericexception::ArbitrationResponse { -> F}
//## Uses: <unnamed>%4B5783770091;genericexception::ComplianceResponse { -> F}
//## Uses: <unnamed>%4B7D726D0392;genericexception::ChargebackReversal { -> F}
//## Uses: <unnamed>%4B7D727B03B1;genericexception::RepresentmentReversal { -> F}
//## Uses: <unnamed>%4B8598D0013B;genericexception::FeeCollection { -> F}
//## Uses: <unnamed>%4B8598D30264;genericexception::FundDisbursement { -> F}
//## Uses: <unnamed>%4B9947D4009C;genericexception::RepresentmentQuestionnaireWithFinancialInfo { -> F}
//## Uses: <unnamed>%4B9947D60128;genericexception::ChargebackQuestionnaireWithFinancialInfo { -> F}
//## Uses: <unnamed>%4B9947FC038A;genericexception::CaseFilingArbitration { -> F}
//## Uses: <unnamed>%4B9947FF0138;genericexception::CaseFilingCompliance { -> F}
//## Uses: <unnamed>%4B99484A0241;genericexception::CaseFilingResponseUpload { -> F}
//## Uses: <unnamed>%4D0134AF0278;regionalexception::SecondChargeback { -> F}
//## Uses: <unnamed>%4D0134B20006;regionalexception::GoodFaithResponse { -> F}
//## Uses: <unnamed>%4D0134B70257;regionalexception::Adjustment { -> F}
//## Uses: <unnamed>%4D0134D902DB;regionalexception::FreeFormRequest { -> F}
//## Uses: <unnamed>%4D0134DC00E6;regionalexception::FreeFormResponse { -> F}
//## Uses: <unnamed>%4E78B91D0226;genericexception::UnworkedCase { -> F}
//## Uses: <unnamed>%4E78B925038C;genericexception::PreComplianceRecall { -> F}
//## Uses: <unnamed>%4E78B92C009D;genericexception::PreArbitrationRecall { -> F}
//## Uses: <unnamed>%4E78B9ED0120;regionalexception::CorrectionRequest { -> F}
//## Uses: <unnamed>%4E78B9F5018C;regionalexception::CorrectionResponse { -> F}
//## Uses: <unnamed>%4EBD5C7E03B6;cupexception::CupAdjustment { -> F}
//## Uses: <unnamed>%4EBD5C810392;cupexception::CupChargebackFinancial { -> F}
//## Uses: <unnamed>%4EBD5C840246;cupexception::CupRepresentmentFinancial { -> F}
//## Uses: <unnamed>%4EBD5C8701C4;cupexception::CupSecondChargeback { -> F}
//## Uses: <unnamed>%50A109DE0099;regionalexception::AdjustmentReversal { -> F}
//## Uses: <unnamed>%50A109EE038C;regionalexception::UpdateStatus { -> F}
//## Uses: <unnamed>%50A10A0801D8;regionalexception::ArbitrationResponse { -> F}
//## Uses: <unnamed>%51AF26AF02D3;mastercardexception::IPMFeeCollection { -> F}
//## Uses: <unnamed>%51AF26B30211;mastercardexception::RetrievalRequest { -> F}
//## Uses: <unnamed>%524F2B7D0350;mastercardexception::IPMExceptionReject { -> F}
//## Uses: <unnamed>%5294CA0E035F;mastercardexception::RetrievalFulfillment { -> F}
//## Uses: <unnamed>%52B881F70230;mastercardexception::RetrievalRuling { -> F}
//## Uses: <unnamed>%52CD99F2001F;regionalexception::UnworkedCase { -> F}
//## Uses: <unnamed>%52FB95070181;mastercardexception::ChargebackDocumentation { -> F}
//## Uses: <unnamed>%53039D6700C7;mastercardexception::RepresentmentDocumentation { -> F}
//## Uses: <unnamed>%53D8D8230323;genericexception::ChargebackHold { -> F}
//## Uses: <unnamed>%53E9021602D4;genericexception::DocumentAdd { -> F}
//## Uses: <unnamed>%541AE502013C;genericexception::ChargebackReversalReject { -> F}
//## Uses: <unnamed>%541AE9A102DC;genericexception::PreArbitrationReject { -> F}
//## Uses: <unnamed>%541AE9A4019D;genericexception::PreComplianceReject { -> F}
//## Uses: <unnamed>%5489D5F1022D;regionalexception::ChargebackFinancial { -> F}
//## Uses: <unnamed>%55E6D33F02C4;regionalexception::DepositCorrection { -> F}
//## Uses: <unnamed>%55E6D35D0158;regionalexception::MerchantAuthorizedTransaction { -> F}
//## Uses: <unnamed>%578E75A202BF;regionalexception::GoodFaith { -> F}
//## Uses: <unnamed>%578E75B20095;regionalexception::RetrievalRequest { -> F}
//## Uses: <unnamed>%57B6829D000A;regionalexception::CaseFilingRuling { -> F}
//## Uses: <unnamed>%589A5229032C;visaexception::TranInquiryResponse { -> F}
//## Uses: <unnamed>%58C30B310012;visaexception::DisputeResponse { -> F}
//## Uses: <unnamed>%611D69670304;genericexception::Comment { -> F}
//## Uses: <unnamed>%611D6E2803C3;mastercardexception::FeeCollection { -> F}
//## Uses: <unnamed>%611D6E71031F;genericexception::FeeCollectionReject { -> F}

class DllExport ExceptionFactory : public command::EventFactory  //## Inherits: <unnamed>%4ADF11A700AB
{
  //## begin dnplatform::ExceptionFactory%4ADF118A0261.initialDeclarations preserve=yes
  //## end dnplatform::ExceptionFactory%4ADF118A0261.initialDeclarations

  public:
    //## Constructors (generated)
      ExceptionFactory();

    //## Destructor (generated)
      virtual ~ExceptionFactory();


    //## Other Operations (specified)
      //## Operation: create%4ADF11B303A9
      virtual command::Event* create (const char* pszFileName, const char* pszNetwork, const char* pszClass, const char* pszValue = 0);

    // Additional Public Declarations
      //## begin dnplatform::ExceptionFactory%4ADF118A0261.public preserve=yes
      //## end dnplatform::ExceptionFactory%4ADF118A0261.public

  protected:
    // Additional Protected Declarations
      //## begin dnplatform::ExceptionFactory%4ADF118A0261.protected preserve=yes
      //## end dnplatform::ExceptionFactory%4ADF118A0261.protected

  private:
    // Additional Private Declarations
      //## begin dnplatform::ExceptionFactory%4ADF118A0261.private preserve=yes
      //## end dnplatform::ExceptionFactory%4ADF118A0261.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dnplatform::ExceptionFactory%4ADF118A0261.implementation preserve=yes
      //## end dnplatform::ExceptionFactory%4ADF118A0261.implementation

};

//## begin dnplatform::ExceptionFactory%4ADF118A0261.postscript preserve=yes
//## end dnplatform::ExceptionFactory%4ADF118A0261.postscript

} // namespace dnplatform

//## begin module%4ADF120D03B9.epilog preserve=yes
//## end module%4ADF120D03B9.epilog


#endif
