//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4AEF0F7A007D.cm preserve=no
//	$Date:   Dec 04 2018 13:38:28  $ $Author:   e1089842  $
//	$Revision:   1.7.1.1  $
//## end module%4AEF0F7A007D.cm

//## begin module%4AEF0F7A007D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4AEF0F7A007D.cp

//## Module: CXOSDZ04%4AEF0F7A007D; Package body
//## Subsystem: DZDLL%4085142703C8
//## Source file: C:\bV02.5B.R001\Windows\Build\Dn\Server\Library\Dzdll\CXOSDZ04.cpp

//## begin module%4AEF0F7A007D.additionalIncludes preserve=no
//## end module%4AEF0F7A007D.additionalIncludes

//## begin module%4AEF0F7A007D.includes preserve=yes
#include "CXODEE01.hpp"
//## end module%4AEF0F7A007D.includes

#ifndef CXOSVE18_h
#include "CXODVE18.hpp"
#endif
#ifndef CXOSRG01_h
#include "CXODRG01.hpp"
#endif
#ifndef CXOSME07_h
#include "CXODME07.hpp"
#endif
#ifndef CXOSNE05_h
#include "CXODNE05.hpp"
#endif
#ifndef CXOSSE05_h
#include "CXODSE05.hpp"
#endif
#ifndef CXOSDZ04_h
#include "CXODDZ04.hpp"
#endif


//## begin module%4AEF0F7A007D.declarations preserve=no
//## end module%4AEF0F7A007D.declarations

//## begin module%4AEF0F7A007D.additionalDeclarations preserve=yes
#ifndef CXOSCE06_h
#include "CXODCE06.hpp"
#endif
//## end module%4AEF0F7A007D.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

// Class dnplatform::NetworkFactory 

NetworkFactory::NetworkFactory()
  //## begin NetworkFactory::NetworkFactory%4AEF0F2203C8_const.hasinit preserve=no
  //## end NetworkFactory::NetworkFactory%4AEF0F2203C8_const.hasinit
  //## begin NetworkFactory::NetworkFactory%4AEF0F2203C8_const.initialization preserve=yes
  //## end NetworkFactory::NetworkFactory%4AEF0F2203C8_const.initialization
{
  //## begin dnplatform::NetworkFactory::NetworkFactory%4AEF0F2203C8_const.body preserve=yes
   memcpy(m_sID,"DZ04",4);
#define CLASSES 14
   const char* pszClass[CLASSES] =
   {
      "GEN",
      "VNT",
      "ILK",
      "PLS",
      "RGN",
      "RTS",
      "CRS",
      "MAP",
      "MCI",
      "CUP",
      "NYC",
      "STR",
      "AXS",
      "EHB"
   };		
   for (int i = 0;i < CLASSES;++i)
      m_hClasses.insert(map<string,int,less<string> >::value_type(string(pszClass[i]),i));
  //## end dnplatform::NetworkFactory::NetworkFactory%4AEF0F2203C8_const.body
}


NetworkFactory::~NetworkFactory()
{
  //## begin dnplatform::NetworkFactory::~NetworkFactory%4AEF0F2203C8_dest.body preserve=yes
  //## end dnplatform::NetworkFactory::~NetworkFactory%4AEF0F2203C8_dest.body
}



//## Other Operations (implementation)
command::Network* NetworkFactory::create (const char* pszNetwork, const char* pszValue)
{
  //## begin dnplatform::NetworkFactory::create%4AEF0F4D03C8.body preserve=yes
   string strClass(pszNetwork,3);
   map<string,int,less<string> >::iterator pClass = m_hClasses.find(strClass);
   if (pClass == m_hClasses.end())
      return new genericexception::Network;
   command::Network* pNetwork = 0;
   switch ((*pClass).second)
   {
      case 0:
         pNetwork = new genericexception::Network;
         break;
      case 1:
      case 2:
      case 3:
         pNetwork = new visaexception::VisaNetwork;
         break;
      case 4: 
         pNetwork = new regionalexception::RegionalNetwork;
         break;
      case 5:
      case 6:
      case 7:
      case 8:
         pNetwork = new mastercardexception::MasterCardNetwork;
         break;
      case 9: 
         pNetwork = new cupexception::CupNetwork;
         break;
      case 10:
         pNetwork = new nyceexception::NyceNetwork;
         break;
      case 11:
      case 12:
         pNetwork = new starexception::StarNetwork;
         break;
      case 13:
         pNetwork = new eftposexception::EFTPOSNetwork;
         break;
   }
   return pNetwork;
  //## end dnplatform::NetworkFactory::create%4AEF0F4D03C8.body
}

// Additional Declarations
  //## begin dnplatform::NetworkFactory%4AEF0F2203C8.declarations preserve=yes
  //## end dnplatform::NetworkFactory%4AEF0F2203C8.declarations

} // namespace dnplatform

//## begin module%4AEF0F7A007D.epilog preserve=yes
//## end module%4AEF0F7A007D.epilog
