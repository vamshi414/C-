//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5B8854B700C2.cm preserve=no
//## end module%5B8854B700C2.cm

//## begin module%5B8854B700C2.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5B8854B700C2.cp

//## Module: CXOSDZ08%5B8854B700C2; Package specification
//## Subsystem: DZDLL%4085142703C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Dzdll\CXODDZ08.hpp

#ifndef CXOSDZ08_h
#define CXOSDZ08_h 1

//## begin module%5B8854B700C2.additionalIncludes preserve=no
//## end module%5B8854B700C2.additionalIncludes

//## begin module%5B8854B700C2.includes preserve=yes
//## end module%5B8854B700C2.includes

#ifndef CXOSBC56_h
#include "CXODBC56.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;

} // namespace IF

//## begin module%5B8854B700C2.declarations preserve=no
//## end module%5B8854B700C2.declarations

//## begin module%5B8854B700C2.additionalDeclarations preserve=yes
//## end module%5B8854B700C2.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

//## begin dnplatform::APIQueueExportFactory%5B8854730054.preface preserve=yes
//## end dnplatform::APIQueueExportFactory%5B8854730054.preface

//## Class: APIQueueExportFactory%5B8854730054
//## Category: DataNavigator Foundation::DNPlatform_CAT%408511960157
//## Subsystem: DZDLL%4085142703C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5B88585902CC; { -> F}
//## Uses: <unnamed>%6675F7290366;IF::Trace { -> F}

class DllExport APIQueueExportFactory : public command::APIQueueExportFactory  //## Inherits: <unnamed>%5B885856039C
{
  //## begin dnplatform::APIQueueExportFactory%5B8854730054.initialDeclarations preserve=yes
  //## end dnplatform::APIQueueExportFactory%5B8854730054.initialDeclarations

  public:
    //## Constructors (generated)
      APIQueueExportFactory();

    //## Destructor (generated)
      virtual ~APIQueueExportFactory();


    //## Other Operations (specified)
      //## Operation: create%5B8858750167
      virtual command::APIExport* create (const char* pszAPIType);

    // Additional Public Declarations
      //## begin dnplatform::APIQueueExportFactory%5B8854730054.public preserve=yes
      //## end dnplatform::APIQueueExportFactory%5B8854730054.public

  protected:
    // Additional Protected Declarations
      //## begin dnplatform::APIQueueExportFactory%5B8854730054.protected preserve=yes
      //## end dnplatform::APIQueueExportFactory%5B8854730054.protected

  private:
    // Additional Private Declarations
      //## begin dnplatform::APIQueueExportFactory%5B8854730054.private preserve=yes
      //## end dnplatform::APIQueueExportFactory%5B8854730054.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: APIQueueExport%6675F6A60120
      //## begin dnplatform::APIQueueExportFactory::APIQueueExport%6675F6A60120.attr preserve=no  private: static map<string, command::APIExport*, less<string> >* {U} 0
      static map<string, command::APIExport*, less<string> >* m_pAPIQueueExport;
      //## end dnplatform::APIQueueExportFactory::APIQueueExport%6675F6A60120.attr

    // Additional Implementation Declarations
      //## begin dnplatform::APIQueueExportFactory%5B8854730054.implementation preserve=yes
      //## end dnplatform::APIQueueExportFactory%5B8854730054.implementation

};

//## begin dnplatform::APIQueueExportFactory%5B8854730054.postscript preserve=yes
//## end dnplatform::APIQueueExportFactory%5B8854730054.postscript

} // namespace dnplatform

//## begin module%5B8854B700C2.epilog preserve=yes
//## end module%5B8854B700C2.epilog


#endif
