//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4AEF0F780222.cm preserve=no
//	$Date:   Aug 21 2016 07:21:28  $ $Author:   e1009674  $
//	$Revision:   1.4  $
//## end module%4AEF0F780222.cm

//## begin module%4AEF0F780222.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4AEF0F780222.cp

//## Module: CXOSDZ04%4AEF0F780222; Package specification
//## Subsystem: DZDLL%4085142703C8
//## Source file: C:\bV02.5B.R001\Windows\Build\Dn\Server\Library\Dzdll\CXODDZ04.hpp

#ifndef CXOSDZ04_h
#define CXOSDZ04_h 1

//## begin module%4AEF0F780222.additionalIncludes preserve=no
//## end module%4AEF0F780222.additionalIncludes

//## begin module%4AEF0F780222.includes preserve=yes
//## end module%4AEF0F780222.includes

#ifndef CXOSBC32_h
#include "CXODBC32.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::VisaException_CAT%4097A16101D4
namespace visaexception {
class VisaNetwork;
} // namespace visaexception

//## Modelname: Transaction Research and Adjustments::MasterCardException_CAT%4242FC56001F
namespace mastercardexception {
class MasterCardNetwork;
} // namespace mastercardexception

//## Modelname: Transaction Research and Adjustments::StarException_CAT%4242FC630251
namespace starexception {
class StarNetwork;
} // namespace starexception

//## Modelname: Transaction Research and Adjustments::RegionalException_CAT (RG)%4CC5F99C02E9
namespace regionalexception {
class RegionalNetwork;
} // namespace regionalexception

//## Modelname: Transaction Research and Adjustments::NyceException_CAT%55BF69210380
namespace nyceexception {
class NyceNetwork;

} // namespace nyceexception

//## begin module%4AEF0F780222.declarations preserve=no
//## end module%4AEF0F780222.declarations

//## begin module%4AEF0F780222.additionalDeclarations preserve=yes
//## end module%4AEF0F780222.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

//## begin dnplatform::NetworkFactory%4AEF0F2203C8.preface preserve=yes
//## end dnplatform::NetworkFactory%4AEF0F2203C8.preface

//## Class: NetworkFactory%4AEF0F2203C8
//## Category: DataNavigator Foundation::DNPlatform_CAT%408511960157
//## Subsystem: DZDLL%4085142703C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4AEF10A800DA;visaexception::VisaNetwork { -> F}
//## Uses: <unnamed>%4D01546D00CA;regionalexception::RegionalNetwork { -> F}
//## Uses: <unnamed>%4E78C9F90367;mastercardexception::MasterCardNetwork { -> F}
//## Uses: <unnamed>%574F2BF9027A;nyceexception::NyceNetwork { -> F}
//## Uses: <unnamed>%5788E4700285;starexception::StarNetwork { -> F}

class DllExport NetworkFactory : public command::NetworkFactory  //## Inherits: <unnamed>%4AEF0F3500DA
{
  //## begin dnplatform::NetworkFactory%4AEF0F2203C8.initialDeclarations preserve=yes
  //## end dnplatform::NetworkFactory%4AEF0F2203C8.initialDeclarations

  public:
    //## Constructors (generated)
      NetworkFactory();

    //## Destructor (generated)
      virtual ~NetworkFactory();


    //## Other Operations (specified)
      //## Operation: create%4AEF0F4D03C8
      virtual command::Network* create (const char* pszNetwork, const char* pszValue = 0);

    // Additional Public Declarations
      //## begin dnplatform::NetworkFactory%4AEF0F2203C8.public preserve=yes
      //## end dnplatform::NetworkFactory%4AEF0F2203C8.public

  protected:
    // Additional Protected Declarations
      //## begin dnplatform::NetworkFactory%4AEF0F2203C8.protected preserve=yes
      //## end dnplatform::NetworkFactory%4AEF0F2203C8.protected

  private:
    // Additional Private Declarations
      //## begin dnplatform::NetworkFactory%4AEF0F2203C8.private preserve=yes
      //## end dnplatform::NetworkFactory%4AEF0F2203C8.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dnplatform::NetworkFactory%4AEF0F2203C8.implementation preserve=yes
      //## end dnplatform::NetworkFactory%4AEF0F2203C8.implementation

};

//## begin dnplatform::NetworkFactory%4AEF0F2203C8.postscript preserve=yes
//## end dnplatform::NetworkFactory%4AEF0F2203C8.postscript

} // namespace dnplatform

//## begin module%4AEF0F780222.epilog preserve=yes
//## end module%4AEF0F780222.epilog


#endif
