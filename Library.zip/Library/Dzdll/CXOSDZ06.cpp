//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5888F5340123.cm preserve=no
//## end module%5888F5340123.cm

//## begin module%5888F5340123.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5888F5340123.cp

//## Module: CXOSDZ06%5888F5340123; Package body
//## Subsystem: DZDLL%4085142703C8
//## Source file: C:\Repos\DataNavigatorserver\Windows\Build\Dn\Server\Library\Dzdll\CXOSDZ06.cpp

//## begin module%5888F5340123.additionalIncludes preserve=no
//## end module%5888F5340123.additionalIncludes

//## begin module%5888F5340123.includes preserve=yes
//## end module%5888F5340123.includes

#ifndef CXOSVE20_h
#include "CXODVE20.hpp"
#endif
#ifndef CXOSME37_h
#include "CXODME37.hpp"
#endif
#ifndef CXOSEE12_h
#include "CXODEE12.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDZ06_h
#include "CXODDZ06.hpp"
#endif


//## begin module%5888F5340123.declarations preserve=no
//## end module%5888F5340123.declarations

//## begin module%5888F5340123.additionalDeclarations preserve=yes
//## end module%5888F5340123.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

// Class dnplatform::APIExportFactory 

//## begin dnplatform::APIExportFactory::APIExport%6675F0B100A7.attr preserve=no  public: static map<string, command::APIExport*, less<string> >* {U} 0
map<string, command::APIExport*, less<string> >* APIExportFactory::m_pAPIExport = 0;
//## end dnplatform::APIExportFactory::APIExport%6675F0B100A7.attr

APIExportFactory::APIExportFactory()
  //## begin APIExportFactory::APIExportFactory%5888F05801BE_const.hasinit preserve=no
  //## end APIExportFactory::APIExportFactory%5888F05801BE_const.hasinit
  //## begin APIExportFactory::APIExportFactory%5888F05801BE_const.initialization preserve=yes
  //## end APIExportFactory::APIExportFactory%5888F05801BE_const.initialization
{
  //## begin dnplatform::APIExportFactory::APIExportFactory%5888F05801BE_const.body preserve=yes
   memcpy(m_sID, "DZ06", 4);
#define CLASSES 3
   const char* pszClass[CLASSES] =
   {
      "VCR",
	   "MCI",
      "EHB"
   };
   if (!m_pAPIExport)
   {
      m_pAPIExport = new map<string, command::APIExport*, less<string> >;
      for (int i = 0; i < CLASSES; ++i)
         switch (i)
         {
         case 0:
            m_pAPIExport->insert(map<string, command::APIExport*, less<string> >::value_type(string(pszClass[i]), new visaexception::VCRExport));
            break;
         case 1:
            m_pAPIExport->insert(map<string, command::APIExport*, less<string> >::value_type(string(pszClass[i]), new mastercardexception::MasterComAPIExport));
            break;
         case 2:
            m_pAPIExport->insert(map<string, command::APIExport*, less<string> >::value_type(string(pszClass[i]), new eftposexception::EHBExport));
            break;
         }
   }
  //## end dnplatform::APIExportFactory::APIExportFactory%5888F05801BE_const.body
}


APIExportFactory::~APIExportFactory()
{
  //## begin dnplatform::APIExportFactory::~APIExportFactory%5888F05801BE_dest.body preserve=yes
  //## end dnplatform::APIExportFactory::~APIExportFactory%5888F05801BE_dest.body
}



//## Other Operations (implementation)
command::APIExport* APIExportFactory::create (const char* pszAPIType)
{
  //## begin dnplatform::APIExportFactory::create%5888F63D02D9.body preserve=yes
   Trace::put("DZ06");
   string strClass(pszAPIType, 3);
   Trace::put(strClass.c_str());
   map<string, command::APIExport*, less<string> >::iterator pClass = m_pAPIExport->find(strClass);
   if (pClass == m_pAPIExport->end())
   {
      pair<map<string, command::APIExport*, less<string> >::iterator, bool> hResult;
      hResult = m_pAPIExport->insert(map<string, command::APIExport*, less<string> >::value_type(strClass, new command::APIExport));
      return (*hResult.first).second;
   }
   Trace::put("found class");
   return (*pClass).second;
  //## end dnplatform::APIExportFactory::create%5888F63D02D9.body
}

// Additional Declarations
  //## begin dnplatform::APIExportFactory%5888F05801BE.declarations preserve=yes
  //## end dnplatform::APIExportFactory%5888F05801BE.declarations

} // namespace dnplatform

//## begin module%5888F5340123.epilog preserve=yes
//## end module%5888F5340123.epilog
