//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4B1559370007.cm preserve=no
// $Date:   Oct 04 2017 16:48:54  $ $Author:   e1009652  $
// $Revision:   1.16  $
//## end module%4B1559370007.cm

//## begin module%4B1559370007.cp preserve=no
// Copyright (c) 1998 - 2010
// FIS
//## end module%4B1559370007.cp

//## Module: CXOSDZ05%4B1559370007; Package body
//## Subsystem: DZDLL%4085142703C8
//## Source file: C:\Devel\Dn\Server\Library\Dzdll\CXOSDZ05.cpp

//## begin module%4B1559370007.additionalIncludes preserve=no
//## end module%4B1559370007.additionalIncludes

//## begin module%4B1559370007.includes preserve=yes
#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
//## end module%4B1559370007.includes
#ifdef MVS
#ifndef CXOSIF53_h
#include "CXODIF53.hpp"
#endif
#ifndef CXOSDB40_h
#include "CXODDB40.hpp"
#endif
#ifndef CXOSDB41_h
#include "CXODDB41.hpp"
#endif
#endif
#ifdef _UNIX
#ifndef CXOSIF51_h
#include "CXODIF51.hpp"
#endif
#ifndef CXOSDB55_h
#include "CXODDB55.hpp"
#endif
#endif
#ifdef _WIN32
#ifndef CXOSIF52_h
#include "CXODIF52.hpp"
#endif
#ifndef CXOSDB42_h
#include "CXODDB42.hpp"
#endif
#endif
#ifndef CXOSIF50_h
#include "CXODIF50.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSDZ05_h
#include "CXODDZ05.hpp"
#endif


//## begin module%4B1559370007.declarations preserve=no
//## end module%4B1559370007.declarations

//## begin module%4B1559370007.additionalDeclarations preserve=yes
//## end module%4B1559370007.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

// Class dnplatform::DataSetFactory

DataSetFactory::DataSetFactory()
  //## begin DataSetFactory::DataSetFactory%4B1558EA01F4_const.hasinit preserve=no
      : m_bInitialized(false)
  //## end DataSetFactory::DataSetFactory%4B1558EA01F4_const.hasinit
  //## begin DataSetFactory::DataSetFactory%4B1558EA01F4_const.initialization preserve=yes
  //## end DataSetFactory::DataSetFactory%4B1558EA01F4_const.initialization
{
  //## begin dnplatform::DataSetFactory::DataSetFactory%4B1558EA01F4_const.body preserve=yes
   memcpy(m_sID,"DZ05",4);
  //## end dnplatform::DataSetFactory::DataSetFactory%4B1558EA01F4_const.body
}


DataSetFactory::~DataSetFactory()
{
  //## begin dnplatform::DataSetFactory::~DataSetFactory%4B1558EA01F4_dest.body preserve=yes
  //## end dnplatform::DataSetFactory::~DataSetFactory%4B1558EA01F4_dest.body
}



//## Other Operations (implementation)
IF::File* DataSetFactory::create ()
{
  //## begin dnplatform::DataSetFactory::create%4B156C02001B.body preserve=yes
#ifdef _WIN32
   return new WindowsFile();
#endif
#ifdef _UNIX
   return new UnixFile();
#endif
#ifdef MVS
   return new ZosFile();
#endif
  //## end dnplatform::DataSetFactory::create%4B156C02001B.body
}

IF::File* DataSetFactory::create (const char* pszName)
{
  //## begin dnplatform::DataSetFactory::create%4B156C020039.body preserve=yes
   File* pFile = 0;
   if ((strcmp(pszName,"EDB     ") != 0) && !m_bInitialized)
      initialize();
#ifdef _WIN32
   map<string,pair<int,int>,less<string> >::iterator p;
   p = m_hFileMap.find(pszName);
   if (p != m_hFileMap.end())
   {
      switch ((*p).second.first)
      {
         case -1:
            pFile = new WindowsFile(pszName); //not ready for this yet
            break;
         default:
            pFile = new database::WindowsEncryptedFile(pszName);
            ((database::WindowsEncryptedFile*)pFile)->setEncryptOffset((*p).second.first);
            ((database::WindowsEncryptedFile*)pFile)->setEncryptLength((*p).second.second);
      }
   }
   else
      pFile = new WindowsFile(pszName);
#endif
#ifdef _UNIX
   map<string,pair<int,int>,less<string> >::iterator p;
   p = m_hFileMap.find(pszName);
   if (p != m_hFileMap.end())
   {
      switch ((*p).second.first)
      {
      case -1:
         pFile = new UnixFile(pszName);
         break;
      default:
         pFile = new database::UnixEncryptedFile(pszName);
         ((database::UnixEncryptedFile*)pFile)->setEncryptOffset((*p).second.first);
         ((database::UnixEncryptedFile*)pFile)->setEncryptLength((*p).second.second);
      }
   }
   else
      pFile = new UnixFile(pszName);
#endif
#ifdef MVS
   map<string,pair<int,int>,less<string> >::iterator p;
   p = m_hFileMap.find(pszName);
   if (p != m_hFileMap.end())
   {
      switch ((*p).second.first)
      {
         case -1:
            pFile = new database::ZosXMLEncryptedFile(pszName);
            break;
         default:
            pFile = new database::ZosEncryptedFile(pszName);
            ((database::ZosEncryptedFile*)pFile)->setEncryptOffset((*p).second.first);
            ((database::ZosEncryptedFile*)pFile)->setEncryptLength((*p).second.second);
      }
   }
   else
      pFile = new ZosFile(pszName);
#endif
   return pFile;
  //## end dnplatform::DataSetFactory::create%4B156C020039.body
}

IF::File* DataSetFactory::create (const char* pszName, const char* pszMember)
{
  //## begin dnplatform::DataSetFactory::create%4B156C02004D.body preserve=yes
   File* pFile = 0;
   if ((strcmp(pszName,"EDB     ") != 0) && !m_bInitialized)
      initialize();
#ifdef _WIN32
   map<string,pair<int,int>,less<string> >::iterator p;
   p = m_hFileMap.find(pszName);
   if (p != m_hFileMap.end())
   {
      switch ((*p).second.first)
      {
         case -1:
            pFile = new WindowsFile(pszName,pszMember); //not ready for this yet
            break;
         default:
            pFile = new database::WindowsEncryptedFile(pszName, pszMember);
            ((database::WindowsEncryptedFile*)pFile)->setEncryptOffset((*p).second.first);
            ((database::WindowsEncryptedFile*)pFile)->setEncryptLength((*p).second.second);
      }
   }
   else
      pFile = new WindowsFile(pszName,pszMember);
#endif
#ifdef _UNIX
   map<string,pair<int,int>,less<string> >::iterator p;
   p = m_hFileMap.find(pszName);
   if (p != m_hFileMap.end())
   {
      switch ((*p).second.first)
      {
      case -1:
         pFile = new UnixFile(pszName, pszMember);
         break;
      default:
         pFile = new database::UnixEncryptedFile(pszName, pszMember);
         ((database::UnixEncryptedFile*)pFile)->setEncryptOffset((*p).second.first);
         ((database::UnixEncryptedFile*)pFile)->setEncryptLength((*p).second.second);
      }
   }
   else
      pFile = new UnixFile(pszName,pszMember);
#endif
#ifdef MVS
   map<string,pair<int,int>,less<string> >::iterator p = m_hFileMap.find(pszName);
   if (p != m_hFileMap.end())
   {
      switch ((*p).second.first)
      {
         case -1:
            pFile = new database::ZosXMLEncryptedFile(pszName,pszMember);
            break;
         default:
            pFile = new database::ZosEncryptedFile(pszName,pszMember);
            ((database::ZosEncryptedFile*)pFile)->setEncryptOffset((*p).second.first);
            ((database::ZosEncryptedFile*)pFile)->setEncryptLength((*p).second.second);
      }
   }
   else
      pFile = new ZosFile(pszName,pszMember);
#endif
   return pFile;
  //## end dnplatform::DataSetFactory::create%4B156C02004D.body
}

void DataSetFactory::initialize ()
{
  //## begin dnplatform::DataSetFactory::initialize%4C4DBE140310.body preserve=yes
   m_bInitialized = true;
   string strENCRFILE;
   string strRecord;
   size_t pos = string::npos;
   int i = 0;
   while (Extract::instance()->getRecord(i++,strRecord))
   {
      if (strRecord.substr(0,8) == "DSPEC   "
         && strRecord.substr(8,8) == "ENCRFILE")
      {
         strENCRFILE.append(strRecord.substr(16));
         pos = strENCRFILE.find_last_not_of(" ");
         if (pos != string::npos)
            strENCRFILE.erase(pos + 1);
         strENCRFILE += " ";
      }
   }
   if (strENCRFILE.find("ALL") != string::npos)
   {
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("AISOIN",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("ATMDEP",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("BAMSA1",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("BAMSIC",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("BAMSIN",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("BAMSOUT",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("BAMSRC",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("BAMSRJ",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("BAMSRP",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("ECIN",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("ECOUT",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("EFEMCC",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("EFEMCI",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("EMSACT",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("EVEXG",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("EX0410",make_pair(265,24)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("FRDIN",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("FRDOUT",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("IBMLOG",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("ILKIN",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("ILKOUT",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("MCIN",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("MCINOFLN",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("MCOUT",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("MCPEXP",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("MC410",make_pair(265,24)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("STRIN",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("STROUT",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("TXNACT",make_pair(25,24)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("VRBDM3",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("VRRDM3",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("VRRDM5",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("VRRUA5",make_pair(0,0)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("ZAPACT",make_pair(32,16)));
      m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type("NYCEXP",make_pair(34,19)));
   }
   vector<string> hFileType;
   if (Buffer::parse(strENCRFILE," ",hFileType) >= 1)
   {
      vector<string> hOffset;
      vector<string>::iterator pIter;
      for (pIter = hFileType.begin();pIter != hFileType.end();pIter++)
      {
         if (Buffer::parse(*pIter,"(-)",hOffset) == 3)
            m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type(hOffset[0],make_pair(atoi(hOffset[1].c_str()),atoi(hOffset[2].c_str()))));
         if (Buffer::parse(*pIter,"(-)",hOffset) == 2)
         {
            if (hOffset[1].substr(0,1) == "X")
               m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type(hOffset[0],make_pair(-1,-1)));
            else
            {
               IF::Trace::put("Invalid encrypt format in spec");
               return;
            }
         }
         if (i = Buffer::parse(*pIter,"(-)",hOffset) == 1)
            m_hFileMap.insert(map<string,pair<int,int>,less<string> >::value_type(hOffset[0],make_pair(0,0)));
      }
   }
  //## end dnplatform::DataSetFactory::initialize%4C4DBE140310.body
}

// Additional Declarations
  //## begin dnplatform::DataSetFactory%4B1558EA01F4.declarations preserve=yes
  //## end dnplatform::DataSetFactory%4B1558EA01F4.declarations

} // namespace dnplatform

//## begin module%4B1559370007.epilog preserve=yes
//## end module%4B1559370007.epilog
