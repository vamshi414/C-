//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%408514460280.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%408514460280.cm

//## begin module%408514460280.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%408514460280.cp

//## Module: CXOSDZ01%408514460280; Package body
//## Subsystem: DZDLL%4085142703C8
//## Source file: C:\Devel\Dn\Server\Library\Dzdll\CXOSDZ01.cpp

//## begin module%408514460280.additionalIncludes preserve=no
//## end module%408514460280.additionalIncludes

//## begin module%408514460280.includes preserve=yes
#ifdef CS
#include "CXODDB02.hpp"
#else
#ifdef MVS
#include "CXODP202.hpp"
#endif
#endif
#ifdef _WIN32
#include "CXODDQ01.hpp"
#include "CXODDO01.hpp"
#include "CXODDG01.hpp"
#include "CXODD202.hpp"
#else
#ifdef SOLARISAMD64
#include "CXODDO01.hpp"
#else
#ifdef _AIX
#ifdef _ORACLE
#include "CXODDO01.hpp"
#else
#include "CXODP202.hpp"
#endif
#else
#include <dlfcn.h>
#endif
#endif
#endif
#include "CXODDZ05.hpp"
#include "CXODNS29.hpp"
#include "CXODIF03.hpp"
//## end module%408514460280.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSD202_h
#include "CXODD202.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif


//## begin module%408514460280.declarations preserve=no
//## end module%408514460280.declarations

//## begin module%408514460280.additionalDeclarations preserve=yes
//## end module%408514460280.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

// Class dnplatform::DNPlatform

DNPlatform::DNPlatform()
  //## begin DNPlatform::DNPlatform%408511E3005D_const.hasinit preserve=no
  //## end DNPlatform::DNPlatform%408511E3005D_const.hasinit
  //## begin DNPlatform::DNPlatform%408511E3005D_const.initialization preserve=yes
  //## end DNPlatform::DNPlatform%408511E3005D_const.initialization
{
  //## begin dnplatform::DNPlatform::DNPlatform%408511E3005D_const.body preserve=yes
   memcpy(m_sID,"DZ01",4);
   new DataSetFactory();
  //## end dnplatform::DNPlatform::DNPlatform%408511E3005D_const.body
}


DNPlatform::~DNPlatform()
{
  //## begin dnplatform::DNPlatform::~DNPlatform%408511E3005D_dest.body preserve=yes
  //## end dnplatform::DNPlatform::~DNPlatform%408511E3005D_dest.body
}



//## Other Operations (implementation)
void DNPlatform::createDatabaseFactory ()
{
  //## begin dnplatform::DNPlatform::createDatabaseFactory%40851224000F.body preserve=yes
#ifndef MVS
   string strTemp;
   Extract::instance()->getSpec("DBVENDOR",strTemp);
#endif
#ifdef MVS
   new DNDB2DatabaseFactory();
#elif _WIN32
   if (strTemp == "SQLSERVER")
      new dnodbcdatabase::DNODBCDatabaseFactory(strTemp);
   else
   if (strTemp == "ORACLE")
      new dnoracledatabase::DNOracleDatabaseFactory();
   else   
   if (strTemp == "POSTGRES")
      new dnpostgresqldatabase::DNPostgreSQLDatabaseFactory(); 
   else
      new DNDB2DatabaseFactory();
#elif SOLARISAMD64
   new dnoracledatabase::DNOracleDatabaseFactory();
#elif _AIX
#ifdef _ORACLE
   new dnoracledatabase::DNOracleDatabaseFactory();
#else
   new DNDB2DatabaseFactory();
#endif
#else
#include <dlfcn.h>
   string strLib;
   if (strTemp == "POSTGRES")
      strLib = "./libCXOPDG00.so";
   else
   if (strTemp == "ORACLE")
      strLib = "./libCXOPDO00.so";
   // load the database library
   void* handle = dlopen(strLib.c_str(), RTLD_LAZY);
   if (!handle)
   {
      IF::Trace::put("Cannot load shared library", -1, true);
      return;
   }
   // reset errors
   dlerror();
   // load the symbols
   typedef void (*create_t)();
   create_t create = (create_t)dlsym(handle, "create");
   const char* dlsym_error = dlerror();
   if (dlsym_error)
   {
      IF::Trace::put("Cannot load symbol create", -1, true);
      return;
   }
   // create an instance of the DatabaseFactory
   create();
#endif
   createKeyFactory();
   Customer::instance();
  //## end dnplatform::DNPlatform::createDatabaseFactory%40851224000F.body
}

// Additional Declarations
  //## begin dnplatform::DNPlatform%408511E3005D.declarations preserve=yes
  //## end dnplatform::DNPlatform%408511E3005D.declarations

} // namespace dnplatform

//## begin module%408514460280.epilog preserve=yes
//## end module%408514460280.epilog
