//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%49E370570290.cm preserve=no
//	$Date:   Dec 23 2019 00:15:24  $ $Author:   e3018367  $
//	$Revision:   1.11  $
//## end module%49E370570290.cm

//## begin module%49E370570290.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%49E370570290.cp

//## Module: CXOSDZ02%49E370570290; Package specification
//## Subsystem: DZDLL%4085142703C8
//## Source file: D:\SECU\DN\Server\Library\Dzdll\CXODDZ02.hpp

#ifndef CXOSDZ02_h
#define CXOSDZ02_h 1

//## begin module%49E370570290.additionalIncludes preserve=no
//## end module%49E370570290.additionalIncludes

//## begin module%49E370570290.includes preserve=yes
//## end module%49E370570290.includes

#ifndef CXOSRL17_h
#include "CXODRL17.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class SetUsageCode;
class SetAccountingProcessedFlag;
class SECUSystemDocs;
class PhaseReasonCode;
class APIBilling;
class DeleteAssociatedTrans;
class ProvisionalCredit;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::VisaException_CAT%4097A16101D4
namespace visaexception {
class VCRExportAction;
class VCRDeleteAction;
} // namespace visaexception

//## Modelname: Transaction Research and Adjustments::MasterCardException_CAT%4242FC56001F
namespace mastercardexception {
class MasterComAPIExportAction;
class MasterCommProExportAction;
} // namespace mastercardexception

//## Modelname: Transaction Research and Adjustments::StarException_CAT%4242FC630251
namespace starexception {
class SetChargebackReasonPrefix;
class SetStarAdjustmentType;
} // namespace starexception

//## Modelname: Transaction Research and Adjustments::NyceException_CAT%55BF69210380
namespace nyceexception {
class SetNyceExceptionType;
} // namespace nyceexception

//## Modelname: Connex Library::Rules_CAT (RLDLL)%3EB810F40157
namespace rules {
class Function;
} // namespace rules

//## Modelname: Platform \: Regions::RegionsAPI%49C79DB0002E
namespace regionsapi {
class BulkPrintAction;
class VROLAction;
class ProvisionalCredit;

} // namespace regionsapi

//## begin module%49E370570290.declarations preserve=no
//## end module%49E370570290.declarations

//## begin module%49E370570290.additionalDeclarations preserve=yes
//## end module%49E370570290.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

//## begin dnplatform::ActionFactory%49E36E450177.preface preserve=yes
//## end dnplatform::ActionFactory%49E36E450177.preface

//## Class: ActionFactory%49E36E450177
//## Category: DataNavigator Foundation::DNPlatform_CAT%408511960157
//## Subsystem: DZDLL%4085142703C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%49E3819D035B;regionsapi::ProvisionalCredit { -> F}
//## Uses: <unnamed>%4A2387200257;regionsapi::VROLAction { -> F}
//## Uses: <unnamed>%4A7308160304;rules::Function { -> F}
//## Uses: <unnamed>%4A82D8A80389;regionsapi::BulkPrintAction { -> F}
//## Uses: <unnamed>%4A82DBA800FA;ems::SetAccountingProcessedFlag { -> F}
//## Uses: <unnamed>%4F27FEB1023D;ems::SetUsageCode { -> F}
//## Uses: <unnamed>%52B0685101D3;mastercardexception::MasterCommProExportAction { -> F}
//## Uses: <unnamed>%55E842EC0357;nyceexception::SetNyceExceptionType { -> F}
//## Uses: <unnamed>%57A8C46D016A;starexception::SetStarAdjustmentType { -> F}
//## Uses: <unnamed>%5889082603A1;visaexception::VCRExportAction { -> F}
//## Uses: <unnamed>%589A25D40140;starexception::SetChargebackReasonPrefix { -> F}
//## Uses: <unnamed>%5A2A2F6001EE;visaexception::VCRDeleteAction { -> F}
//## Uses: <unnamed>%5A7408F8017B;ems::APIBilling { -> F}
//## Uses: <unnamed>%5B587C77003F;mastercardexception::MasterComAPIExportAction { -> F}
//## Uses: <unnamed>%5D1B2329037A;ems::DeleteAssociatedTrans { -> F}
//## Uses: <unnamed>%5D971070032D;ems::PhaseReasonCode { -> F}
//## Uses: <unnamed>%5DFB24F60364;ems::SECUSystemDocs { -> F}

class DllExport ActionFactory : public rules::FunctionFactory  //## Inherits: <unnamed>%49E37103004E
{
  //## begin dnplatform::ActionFactory%49E36E450177.initialDeclarations preserve=yes
  //## end dnplatform::ActionFactory%49E36E450177.initialDeclarations

  public:
    //## Constructors (generated)
      ActionFactory();

    //## Destructor (generated)
      virtual ~ActionFactory();


    //## Other Operations (specified)
      //## Operation: create%49E3711A030D
      virtual rules::Function* create (const char* pszClass, const char* pszValue = 0);

    // Additional Public Declarations
      //## begin dnplatform::ActionFactory%49E36E450177.public preserve=yes
      //## end dnplatform::ActionFactory%49E36E450177.public

  protected:
    // Additional Protected Declarations
      //## begin dnplatform::ActionFactory%49E36E450177.protected preserve=yes
      //## end dnplatform::ActionFactory%49E36E450177.protected

  private:
    // Additional Private Declarations
      //## begin dnplatform::ActionFactory%49E36E450177.private preserve=yes
      //## end dnplatform::ActionFactory%49E36E450177.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dnplatform::ActionFactory%49E36E450177.implementation preserve=yes
      //## end dnplatform::ActionFactory%49E36E450177.implementation

};

//## begin dnplatform::ActionFactory%49E36E450177.postscript preserve=yes
//## end dnplatform::ActionFactory%49E36E450177.postscript

} // namespace dnplatform

//## begin module%49E370570290.epilog preserve=yes
//## end module%49E370570290.epilog


#endif
