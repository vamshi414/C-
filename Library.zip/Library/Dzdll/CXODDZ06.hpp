//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5888F532033F.cm preserve=no
//## end module%5888F532033F.cm

//## begin module%5888F532033F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5888F532033F.cp

//## Module: CXOSDZ06%5888F532033F; Package specification
//## Subsystem: DZDLL%4085142703C8
//## Source file: C:\Repos\DataNavigatorserver\Windows\Build\Dn\Server\Library\Dzdll\CXODDZ06.hpp

#ifndef CXOSDZ06_h
#define CXOSDZ06_h 1

//## begin module%5888F532033F.additionalIncludes preserve=no
//## end module%5888F532033F.additionalIncludes

//## begin module%5888F532033F.includes preserve=yes
//## end module%5888F532033F.includes

#ifndef CXOSBC52_h
#include "CXODBC52.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::VisaException_CAT%4097A16101D4
namespace visaexception {
class VCRExport;
} // namespace visaexception

//## Modelname: Transaction Research and Adjustments::MasterCardException_CAT%4242FC56001F
namespace mastercardexception {
class MasterComAPIExport;
} // namespace mastercardexception

//## Modelname: Transaction Research and Adjustments::EFTPOSException_CAT%59B03AF40271
namespace eftposexception {
class EHBExport;
} // namespace eftposexception

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;

} // namespace IF

//## begin module%5888F532033F.declarations preserve=no
//## end module%5888F532033F.declarations

//## begin module%5888F532033F.additionalDeclarations preserve=yes
//## end module%5888F532033F.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

//## begin dnplatform::APIExportFactory%5888F05801BE.preface preserve=yes
//## end dnplatform::APIExportFactory%5888F05801BE.preface

//## Class: APIExportFactory%5888F05801BE
//## Category: DataNavigator Foundation::DNPlatform_CAT%408511960157
//## Subsystem: DZDLL%4085142703C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5888F62900A9;visaexception::VCRExport { -> F}
//## Uses: <unnamed>%5B587A760120;mastercardexception::MasterComAPIExport { -> F}
//## Uses: <unnamed>%6675F1DC0341;eftposexception::EHBExport { -> F}
//## Uses: <unnamed>%6675F4530118;IF::Trace { -> F}

class DllExport APIExportFactory : public command::APIExportFactory  //## Inherits: <unnamed>%5888F50D000C
{
  //## begin dnplatform::APIExportFactory%5888F05801BE.initialDeclarations preserve=yes
  //## end dnplatform::APIExportFactory%5888F05801BE.initialDeclarations

  public:
    //## Constructors (generated)
      APIExportFactory();

    //## Destructor (generated)
      virtual ~APIExportFactory();


    //## Other Operations (specified)
      //## Operation: create%5888F63D02D9
      virtual command::APIExport* create (const char* pszAPIType);

    // Additional Public Declarations
      //## begin dnplatform::APIExportFactory%5888F05801BE.public preserve=yes
      //## end dnplatform::APIExportFactory%5888F05801BE.public

  protected:
    // Additional Protected Declarations
      //## begin dnplatform::APIExportFactory%5888F05801BE.protected preserve=yes
      //## end dnplatform::APIExportFactory%5888F05801BE.protected

  private:
    // Additional Private Declarations
      //## begin dnplatform::APIExportFactory%5888F05801BE.private preserve=yes
      //## end dnplatform::APIExportFactory%5888F05801BE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: APIExport%6675F0B100A7
      //## begin dnplatform::APIExportFactory::APIExport%6675F0B100A7.attr preserve=no  public: static map<string, command::APIExport*, less<string> >* {U} 0
      static map<string, command::APIExport*, less<string> >* m_pAPIExport;
      //## end dnplatform::APIExportFactory::APIExport%6675F0B100A7.attr

    // Additional Implementation Declarations
      //## begin dnplatform::APIExportFactory%5888F05801BE.implementation preserve=yes
      //## end dnplatform::APIExportFactory%5888F05801BE.implementation

};

//## begin dnplatform::APIExportFactory%5888F05801BE.postscript preserve=yes
//## end dnplatform::APIExportFactory%5888F05801BE.postscript

} // namespace dnplatform

//## begin module%5888F532033F.epilog preserve=yes
//## end module%5888F532033F.epilog


#endif
