//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4ADF120F0232.cm preserve=no
//## end module%4ADF120F0232.cm

//## begin module%4ADF120F0232.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4ADF120F0232.cp

//## Module: CXOSDZ03%4ADF120F0232; Package body
//## Subsystem: DZDLL%4085142703C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Dzdll\CXOSDZ03.cpp

//## begin module%4ADF120F0232.additionalIncludes preserve=no
//## end module%4ADF120F0232.additionalIncludes

//## begin module%4ADF120F0232.includes preserve=yes
#include "CXODGE76.hpp"
#include "CXODGE77.hpp"
#include "CXODGE78.hpp"
#include "CXODGE79.hpp"
#include "CXODGE80.hpp"
#include "CXODGE81.hpp"
#include "CXODGE82.hpp"
#include "CXODGE86.hpp"
#include "CXODME31.hpp"
#include "CXODME32.hpp"
#include "CXODME33.hpp"
#include "CXODME34.hpp"
#include "CXODME35.hpp"
#include "CXODRG19.hpp"
#include "CXODVE25.hpp"
#include "CXODVE26.hpp"
#include "CXODVE27.hpp"
#include "CXODVE28.hpp"
#include "CXODVE29.hpp"
#include "CXODVE30.hpp"
#include "CXODVE32.hpp"
#include "CXODVE34.hpp"
#include "CXODVE35.hpp"
#include "CXODVE36.hpp"
#include "CXODVE39.hpp"
#include "CXODVE40.hpp"
#include "CXODVE41.hpp"
#include "CXODVE43.hpp"
#include "CXODVE50.hpp"
#include "CXODVE51.hpp"
#include "CXODVE54.hpp"
#include "CXODGE87.hpp"
#include "CXODME38.hpp"
#include "CXODME41.hpp"
#include "CXODME42.hpp"
#include "CXODME43.hpp"
#include "CXODME51.hpp"
#include "CXODME52.hpp"
#include "CXODME53.hpp"
#include "CXODRG20.hpp"
#include "CXODME55.hpp"
#include "CXODME56.hpp"
#include "CXODME57.hpp"
#include "CXODME59.hpp"
#include "CXODME60.hpp"
#include "CXODME61.hpp"
#include "CXODME62.hpp"
#include "CXODME64.hpp"
#include "CXODME70.hpp"
#include "CXODME72.hpp"
#include "CXODME73.hpp"
#include "CXODME74.hpp"
#include "CXODME75.hpp"
#include "CXODME76.hpp"
#include "CXODME77.hpp"
#include "CXODGE89.hpp"
#include "CXODGE90.hpp"
#include "CXODGE91.hpp"
#include "CXODRG21.hpp"
#include "CXODRG22.hpp"
#include "CXODVE52.hpp"
#include "CXODEE02.hpp"
#include "CXODEE03.hpp"
#include "CXODEE04.hpp"
#include "CXODEE05.hpp"
#include "CXODEE06.hpp"
#include "CXODEE14.hpp"
#include "CXODEE15.hpp"
#include "CXODEE16.hpp"
#include "CXODEE17.hpp"
#include "CXODEE18.hpp"
#include "CXODEE07.hpp"
#include "CXODRG23.hpp"
#include "CXODIF10.hpp"
#include "CXODDZ09.hpp"
#include "CXODME80.hpp"
#include "CXODRG24.hpp"
#include "CXODRG25.hpp"
#include "CXODRG26.hpp"
#include "CXODRG27.hpp"
#include "CXODVE55.hpp"
#include "CXODVE56.hpp"
#include "CXODVE57.hpp"
#include "CXODVE58.hpp"
#include "CXODVE59.hpp"
#include "CXODME81.hpp"
#include "CXODME82.hpp"
#include "CXODME83.hpp"
#include "CXODME84.hpp"
#include "CXODME86.hpp"
#include "CXODGE98.hpp"
#include "CXODVE61.hpp"
//## end module%4ADF120F0232.includes

#ifndef CXOSBC29_h
#include "CXODBC29.hpp"
#endif
#ifndef CXOSVE16_h
#include "CXODVE16.hpp"
#endif
#ifndef CXOSGE09_h
#include "CXODGE09.hpp"
#endif
#ifndef CXOSGE11_h
#include "CXODGE11.hpp"
#endif
#ifndef CXOSGE12_h
#include "CXODGE12.hpp"
#endif
#ifndef CXOSGE14_h
#include "CXODGE14.hpp"
#endif
#ifndef CXOSGE15_h
#include "CXODGE15.hpp"
#endif
#ifndef CXOSGE16_h
#include "CXODGE16.hpp"
#endif
#ifndef CXOSGE18_h
#include "CXODGE18.hpp"
#endif
#ifndef CXOSGE20_h
#include "CXODGE20.hpp"
#endif
#ifndef CXOSGE17_h
#include "CXODGE17.hpp"
#endif
#ifndef CXOSGE19_h
#include "CXODGE19.hpp"
#endif
#ifndef CXOSGE21_h
#include "CXODGE21.hpp"
#endif
#ifndef CXOSGE22_h
#include "CXODGE22.hpp"
#endif
#ifndef CXOSGE23_h
#include "CXODGE23.hpp"
#endif
#ifndef CXOSGE24_h
#include "CXODGE24.hpp"
#endif
#ifndef CXOSGE26_h
#include "CXODGE26.hpp"
#endif
#ifndef CXOSGE28_h
#include "CXODGE28.hpp"
#endif
#ifndef CXOSGE29_h
#include "CXODGE29.hpp"
#endif
#ifndef CXOSGE30_h
#include "CXODGE30.hpp"
#endif
#ifndef CXOSGE31_h
#include "CXODGE31.hpp"
#endif
#ifndef CXOSGE32_h
#include "CXODGE32.hpp"
#endif
#ifndef CXOSGE34_h
#include "CXODGE34.hpp"
#endif
#ifndef CXOSGE35_h
#include "CXODGE35.hpp"
#endif
#ifndef CXOSGE36_h
#include "CXODGE36.hpp"
#endif
#ifndef CXOSGE38_h
#include "CXODGE38.hpp"
#endif
#ifndef CXOSGE40_h
#include "CXODGE40.hpp"
#endif
#ifndef CXOSGE43_h
#include "CXODGE43.hpp"
#endif
#ifndef CXOSGE45_h
#include "CXODGE45.hpp"
#endif
#ifndef CXOSGE46_h
#include "CXODGE46.hpp"
#endif
#ifndef CXOSGE44_h
#include "CXODGE44.hpp"
#endif
#ifndef CXOSGE33_h
#include "CXODGE33.hpp"
#endif
#ifndef CXOSGE37_h
#include "CXODGE37.hpp"
#endif
#ifndef CXOSGE54_h
#include "CXODGE54.hpp"
#endif
#ifndef CXOSGE55_h
#include "CXODGE55.hpp"
#endif
#ifndef CXOSGE57_h
#include "CXODGE57.hpp"
#endif
#ifndef CXOSGE56_h
#include "CXODGE56.hpp"
#endif
#ifndef CXOSGE50_h
#include "CXODGE50.hpp"
#endif
#ifndef CXOSGE51_h
#include "CXODGE51.hpp"
#endif
#ifndef CXOSGE53_h
#include "CXODGE53.hpp"
#endif
#ifndef CXOSRG02_h
#include "CXODRG02.hpp"
#endif
#ifndef CXOSRG05_h
#include "CXODRG05.hpp"
#endif
#ifndef CXOSRG08_h
#include "CXODRG08.hpp"
#endif
#ifndef CXOSRG03_h
#include "CXODRG03.hpp"
#endif
#ifndef CXOSRG04_h
#include "CXODRG04.hpp"
#endif
#ifndef CXOSGE60_h
#include "CXODGE60.hpp"
#endif
#ifndef CXOSGE62_h
#include "CXODGE62.hpp"
#endif
#ifndef CXOSGE61_h
#include "CXODGE61.hpp"
#endif
#ifndef CXOSRG06_h
#include "CXODRG06.hpp"
#endif
#ifndef CXOSRG07_h
#include "CXODRG07.hpp"
#endif
#ifndef CXOSCE03_h
#include "CXODCE03.hpp"
#endif
#ifndef CXOSCE02_h
#include "CXODCE02.hpp"
#endif
#ifndef CXOSCE04_h
#include "CXODCE04.hpp"
#endif
#ifndef CXOSCE05_h
#include "CXODCE05.hpp"
#endif
#ifndef CXOSRG09_h
#include "CXODRG09.hpp"
#endif
#ifndef CXOSRG11_h
#include "CXODRG11.hpp"
#endif
#ifndef CXOSRG10_h
#include "CXODRG10.hpp"
#endif
#ifndef CXOSME13_h
#include "CXODME13.hpp"
#endif
#ifndef CXOSME12_h
#include "CXODME12.hpp"
#endif
#ifndef CXOSME16_h
#include "CXODME16.hpp"
#endif
#ifndef CXOSME20_h
#include "CXODME20.hpp"
#endif
#ifndef CXOSME21_h
#include "CXODME21.hpp"
#endif
#ifndef CXOSRG12_h
#include "CXODRG12.hpp"
#endif
#ifndef CXOSME26_h
#include "CXODME26.hpp"
#endif
#ifndef CXOSME25_h
#include "CXODME25.hpp"
#endif
#ifndef CXOSGE65_h
#include "CXODGE65.hpp"
#endif
#ifndef CXOSGE66_h
#include "CXODGE66.hpp"
#endif
#ifndef CXOSGE67_h
#include "CXODGE67.hpp"
#endif
#ifndef CXOSGE68_h
#include "CXODGE68.hpp"
#endif
#ifndef CXOSGE69_h
#include "CXODGE69.hpp"
#endif
#ifndef CXOSRG13_h
#include "CXODRG13.hpp"
#endif
#ifndef CXOSRG14_h
#include "CXODRG14.hpp"
#endif
#ifndef CXOSRG15_h
#include "CXODRG15.hpp"
#endif
#ifndef CXOSRG16_h
#include "CXODRG16.hpp"
#endif
#ifndef CXOSRG17_h
#include "CXODRG17.hpp"
#endif
#ifndef CXOSRG18_h
#include "CXODRG18.hpp"
#endif
#ifndef CXOSVE23_h
#include "CXODVE23.hpp"
#endif
#ifndef CXOSVE24_h
#include "CXODVE24.hpp"
#endif
#ifndef CXOSGE93_h
#include "CXODGE93.hpp"
#endif
#ifndef CXOSME63_h
#include "CXODME63.hpp"
#endif
#ifndef CXOSGE88_h
#include "CXODGE88.hpp"
#endif
#ifndef CXOSDZ03_h
#include "CXODDZ03.hpp"
#endif


//## begin module%4ADF120F0232.declarations preserve=no
//## end module%4ADF120F0232.declarations

//## begin module%4ADF120F0232.additionalDeclarations preserve=yes
#ifndef CXOSME67_h
#include "CXODME67.hpp"
#endif
#ifndef CXOSME68_h
#include "CXODME68.hpp"
#endif
#ifndef CXOSGE63_h
#include "CXODGE63.hpp"
#endif
#ifndef CXOSGE83_h
#include "CXODGE83.hpp"
#endif
#ifndef CXOSGE84_h
#include "CXODGE84.hpp"
#endif
#ifndef CXOSGE92_h
#include "CXODGE92.hpp"
#endif
#ifndef CXOSVE60_h
#include "CXODVE60.hpp"
#endif
//## end module%4ADF120F0232.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
//## begin dnplatform%408511960157.initialDeclarations preserve=yes
//## end dnplatform%408511960157.initialDeclarations

// Class dnplatform::ExceptionFactory 

ExceptionFactory::ExceptionFactory()
  //## begin ExceptionFactory::ExceptionFactory%4ADF118A0261_const.hasinit preserve=no
  //## end ExceptionFactory::ExceptionFactory%4ADF118A0261_const.hasinit
  //## begin ExceptionFactory::ExceptionFactory%4ADF118A0261_const.initialization preserve=yes
  //## end ExceptionFactory::ExceptionFactory%4ADF118A0261_const.initialization
{
  //## begin dnplatform::ExceptionFactory::ExceptionFactory%4ADF118A0261_const.body preserve=yes
   memcpy(m_sID,"DZ03",4);
   int iClassEntries = sizeof(pszClass) / sizeof(char*);
   for (int i = 0; i < iClassEntries; ++i)
   {
      char szText[4] = {"000"};
      memcpy(szText,pszClass[i],3);
      m_hClasses.insert(map<string,int,less<string> >::value_type(string(pszClass[i] + 3),atoi(szText)));
   }
   FlatFile hFlatFile("SOURCE","CXODDZ09"); 
   if (hFlatFile.open(FlatFile::CX_OPEN_INPUT))
   {
      char pszBuffer[256];
      size_t m = 0;
      while (hFlatFile.read(pszBuffer,256,&m))
      {
         string strBuffer(pszBuffer,m);
         size_t iPos= strBuffer.find_first_of("\"",0,1);
         if (iPos != string::npos)
         {
            strBuffer.erase(0,iPos + 1);
            if ((iPos = strBuffer.find_last_of("\"",-1,1)) != string::npos)
            {
               strBuffer.erase(iPos);
               m_hClasses[string(strBuffer.data()+3)] = atoi(strBuffer.data());
            }
         }
      }
   }
  //## end dnplatform::ExceptionFactory::ExceptionFactory%4ADF118A0261_const.body
}


ExceptionFactory::~ExceptionFactory()
{
  //## begin dnplatform::ExceptionFactory::~ExceptionFactory%4ADF118A0261_dest.body preserve=yes
  //## end dnplatform::ExceptionFactory::~ExceptionFactory%4ADF118A0261_dest.body
}



//## Other Operations (implementation)
Event* ExceptionFactory::create (const char* pszFileName, const char* pszNetwork, const char* pszClass, const char* pszValue)
{
  //## begin dnplatform::ExceptionFactory::create%4ADF11B303A9.body preserve=yes
   string strClass(pszFileName,3);
   strClass.append(pszNetwork,3);
   strClass += pszClass;
   if (strClass.substr(0,3) == "UA5")
      strClass.replace(6,8,"********");
   map<string,int,less<string> >::iterator pClass = m_hClasses.find(strClass);
   if (pClass == m_hClasses.end())
   {
      string strTemp(strClass);
      strClass.replace(3,3,"GEN");
      pClass = m_hClasses.find(strClass);
      if (pClass == m_hClasses.end()
         && (strClass.substr(0, 3) == "DM5" 
            || strClass.substr(0, 3) == "VCR"
            || strClass.substr(0,3) == "MCM"
            || strClass.substr(0, 3) == "KES"))
      {         
         strTemp.replace(6,8,"********");
         pClass = m_hClasses.find(strTemp);
         if (pClass == m_hClasses.end())
         {
            strClass.replace(6,8,"********");
            if (strClass.length() > 16 && strClass.substr(14,3) == "ADJ")
               strClass.replace(17,1," ");            
            pClass = m_hClasses.find(strClass);
         }
      }                              
   }
   if (pClass == m_hClasses.end())
      return 0;
   command::Event* pEvent = 0;
   switch ((*pClass).second)
   {
      case 5:
         pEvent = new genericexception::ChargebackAdvice;
         break;
      case 9:
         pEvent = new genericexception::RFCAdvice;
         break;
      case 11:
         pEvent = new genericexception::RFCFulfillment;
         break;
      case 12:
         pEvent = new genericexception::RFCNonFulfillment;
         break;
      case 14:
         pEvent = new genericexception::ChargebackQuestionnaire;
         break;
      case 15:
         pEvent = new genericexception::RepresentmentQuestionnaire;
         break;
      case 16:
         pEvent = new genericexception::ChargebackFinancial;
         break;
      case 17:
         pEvent = new genericexception::RepresentmentFinancial;
         break;
      case 18:
         pEvent = new genericexception::ChargebackReject;
         break;
      case 19:
         pEvent = new genericexception::RepresentmentReject;
         break;
      case 20:
         pEvent = new genericexception::RepresentmentAdvice;
         break;
      case 21:
         pEvent = new genericexception::Adjustment;
         break;
      case 22:
         pEvent = new genericexception::AdjustmentReject;
         break;
      case 23:
         pEvent = new genericexception::PreArbitration;
         break;
      case 24:
         pEvent = new genericexception::PreCompliance;
         break;
      case 26:
         pEvent = new genericexception::AcknowledgementLetter;
         break;
      case 28:
         pEvent = new genericexception::ContactMessage;
         break;
      case 29:
         pEvent = new genericexception::FinalDecisionLetter;
         break;
      case 31:
         pEvent = new genericexception::FraudReport;
         break;
      case 32:
         pEvent = new genericexception::FraudRejectReturn;
         break;
      case 33:
         pEvent = new genericexception::ChargebackReversal;
         break;
      case 34:
         pEvent = new genericexception::PreArbitrationResponse;
         break;
      case 35:
         pEvent = new genericexception::PreComplianceResponse;
         break;
      case 36:
         pEvent = new genericexception::RejectionLetter;
         break;
      case 37:
         pEvent= new genericexception::RepresentmentReversal;
         break;
      case 38:
         pEvent = new genericexception::RFCRejectReturn;
         break;
      case 40:
         pEvent = new genericexception::FraudUploadReport;
         break;
      case 43:
         pEvent = new genericexception::Compliance;
         break;
      case 44:
         pEvent = new genericexception::ComplianceResponse;
         break;
      case 45:
         pEvent = new genericexception::Arbitration;
         break;
      case 46:
         pEvent = new genericexception::ArbitrationResponse;
         break;
      case 50:
         pEvent = new genericexception::CaseFilingArbitration;
         break;
      case 51:
         pEvent = new genericexception::CaseFilingCompliance;
         break;
      case 53:
         pEvent = new genericexception::CaseFilingResponseUpload;
         break;
      case 54:
         pEvent = new genericexception::FeeCollection;
         break;
      case 55:
         pEvent = new genericexception::FundDisbursement;
         break;
      case 56:
         pEvent = new genericexception::ChargebackQuestionnaireWithFinancialInfo;
         break;
      case 57:
         pEvent = new genericexception::RepresentmentQuestionnaireWithFinancialInfo;
         break;
      case 60:
         pEvent = new genericexception::UnworkedCase;
         break;
      case 61:
         pEvent = new genericexception::PreArbitrationRecall;
         break;
      case 62:
         pEvent = new genericexception::PreComplianceRecall;
         break;
      case 63:
         pEvent = new genericexception::PreArbitrationClose;
         break;
      case 65:
         pEvent = new genericexception::ChargebackHold;
         break;
      case 66:
         pEvent = new genericexception::DocumentAdd;
         break;
      case 67:
         pEvent = new genericexception::ChargebackReversalReject;
         break;
      case 68:
         pEvent = new genericexception::PreArbitrationReject;
         break;
      case 69:
         pEvent = new genericexception::PreComplianceReject;
         break;
      case 89:
         pEvent = new genericexception::ArbitrationReject;
         break;
      case 90:
         pEvent = new genericexception::ArbitrationRecall;
         break;
      case 91:
         pEvent = new genericexception::FundDisbursementReject;
         break;
      case 93:
         pEvent = new genericexception::Comment;
         break;
      case 99:
         pEvent = new visaexception::VisaChargebackAdvice;
         break;
      case 102:
         pEvent = new regionalexception::SecondChargeback;
         break;
      case 103:
         pEvent = new regionalexception::FreeFormRequest;
         break;
      case 104:
         pEvent = new regionalexception::FreeFormResponse;
         break;
      case 105:
         pEvent = new regionalexception::GoodFaithResponse; 
         break;
      case 106:
         pEvent = new regionalexception::CorrectionRequest; 
         break;
      case 107:
         pEvent = new regionalexception::CorrectionResponse; 
         break;
      case 108:
         pEvent = new regionalexception::Adjustment; 
         break;
      case 109:
         pEvent = new cupexception::CupAdjustment; 
         break;
      case 110:
         pEvent = new cupexception::CupChargebackFinancial; 
         break;
      case 111:
         pEvent = new cupexception::CupSecondChargeback; 
         break;
      case 112:
         pEvent = new cupexception::CupRepresentmentFinancial; 
         break;
      case 113:
         pEvent = new regionalexception::AdjustmentReversal; 
         break;
      case 114:
         pEvent = new regionalexception::UpdateStatus; 
         break;
      case 115:
         pEvent = new regionalexception::ArbitrationResponse; 
         break;
      case 116:
         pEvent = new mastercardexception::IPMFeeCollection; 
         break;
      case 117:
         pEvent = new mastercardexception::RetrievalRequest; 
         break;
      case 118:
         pEvent = new mastercardexception::IPMExceptionReject; 
         break;
      case 119:
         pEvent = new regionalexception::UnworkedCase;
         break;
      case 120:
         pEvent = new mastercardexception::RetrievalFulfillment; 
         break; 
      case 121:
         pEvent = new mastercardexception::RetrievalRuling; 
         break; 
      case 122:
         pEvent = new mastercardexception::ChargebackDocumentation; 
         break; 
      case 123:
         pEvent = new mastercardexception::RepresentmentDocumentation; 
         break; 
      case 124:
         pEvent = new regionalexception::ChargebackFinancial; 
         break; 
      case 125:
         pEvent = new regionalexception::DepositCorrection; 
         break; 
      case 126:
         pEvent = new regionalexception::MerchantAuthorizedTransaction; 
         break; 
      case 127:
         pEvent = new regionalexception::GoodFaith;
         break;
      case 128:
         pEvent = new regionalexception::RetrievalRequest;
         break;
      case 129:
         pEvent = new regionalexception::CaseFilingRuling;
         break;
      case 130:
         pEvent = new genericexception::ChargebackDocumentationReject;
         break;
      case 131:
         pEvent = new genericexception::SecondChargebackReject ;
         break;
      case 132:
         pEvent = new genericexception::SecondChargebackDocumentationReject;
         break;
      case 133:
         pEvent = new genericexception::ProvisionalCredit;
         break;
      case 134:
         pEvent = new genericexception::ProvisionalDebit;
         break;
      case 135:
         pEvent = new genericexception::ChargebackDocumentation;
         break;
      case 136:
         pEvent = new mastercardexception::PreArbitration;
         break;
      case 137:
         pEvent = new mastercardexception::ArbitrationResponse;
         break;
      case 138:
         pEvent = new mastercardexception::Compliance;
         break;
      case 139:
         pEvent = new mastercardexception::ComplianceResponse;
         break;
      case 140:
         pEvent = new mastercardexception::CaseFilingRuling;
         break;
      case 141:
         pEvent = new genericexception::SecondChargebackReversal;
         break;
      case 142:
         pEvent = new genericexception::AddComment;
         break;
      case 143:
         pEvent = new genericexception::ProvisionalCreditReview;
         break;
      case 144:
         pEvent = new visaexception::TranInquiryResponse;
         break;
      case 145:
         pEvent = new genericexception::SendAssociatedTrans;
         break;
      case 146:
         pEvent = new visaexception::DisputeResponse;
         break;
      case 147:
         pEvent = new visaexception::AssociatedTranListResponse;
         break;
      case 148:
         pEvent = new visaexception::AssociateTransactions;
         break;
      case 149:
         pEvent = new visaexception::DisputeQuestionnaireResponse;
         break;
      case 150:
         pEvent = new regionalexception::SecondRepresentment;
         break;
      case 151:
         pEvent = new visaexception::PreArbitration;
         break;
      case 152:
         pEvent = new visaexception::PreArbitrationResponse;
         break;
      case 153:
         pEvent = new visaexception::ChangeStatus;
         break;
      case 154:
         pEvent = new visaexception::AcceptDispute;
         break;
      case 155:
         pEvent = new visaexception::AssociatedTranSelectionResponse;
         break;
      case 156:
         pEvent = new visaexception::UploadImageResponse;
         break;
      case 157:
         pEvent = new visaexception::DisputeResponseResponse;
         break;
      case 158:
         pEvent = new genericexception::RepresentmentDocumentationReject;
         break;
      case 159:
         pEvent = new mastercardexception::MasterComTransactionInquiryResponse;
         break;
      case 160:
         pEvent = new mastercardexception::MasterComClaimCreateResponse;
         break;
      case 161:
         pEvent = new mastercardexception::MasterComRetrievalResponse;
         break;
      case 162:
         pEvent = new mastercardexception::MasterComChargebackResponse;
         break;
      case 163:
         pEvent = new mastercardexception::MasterComWorkedQueue;
         break;
      case 164:
         pEvent = new mastercardexception::MasterComRejectQueue;
         break;
      case 165:
         pEvent = new mastercardexception::MasterComClaimDetailsResponse;
         break;
      case 166:
         pEvent = new regionalexception::Arbitration;
         break;
      case 167:
         pEvent = new mastercardexception::MasterComReversalResponse;
         break;
      case 168:
         pEvent = new mastercardexception::MasterComDocumentResponse;
         break;
      case 169:
         pEvent = new mastercardexception::MasterComCBGetDocumentResponse;
	      break;
      case 170:
         pEvent = new mastercardexception::MasterComClaimAcknowledgment;
         break;
      case 171:
         pEvent = new mastercardexception::MasterComChargebackStatusResponse;
         break;
      case 172:
         pEvent = new mastercardexception::MasterComFeesCreateResponse;
         break;
      case 173:
         pEvent = new mastercardexception::MasterComDocStatusResponse;
         break;
      case 174:
         pEvent = new visaexception::AdjustmentResponse;
         break;
      case 175:
         pEvent = new visaexception::RFCResponse;
         break;
      case 176:
         pEvent = new visaexception::CreateCaseResponse;
         break;
      case 177:
         pEvent = new visaexception::FeeResponse;
         break;
      case 178:
         pEvent = new visaexception::SiGetQueueResponse;
         break;
      case 179:
         pEvent = new visaexception::SIGetDisputeDetailsResponse;
         break;
      case 180:
         pEvent = new mastercardexception::MasterComClrTranDetailResponse;
         break;
      case 181:
         pEvent = new mastercardexception::MasterComCaseFilingResponse;
         break;
      case 182:
         pEvent = new mastercardexception::MasterComCaseFilingStatusResponse;
         break;
      case 183:
         pEvent = new mastercardexception::SenderCaseFilingQueue;
         break;
      case 184:
         pEvent = new mastercardexception::ReceiverCaseFilingQueue;
         break;
      case 185:
         pEvent = new mastercardexception::MasterComCaseFilingUpdateResponse;
         break;
      case 186:
         pEvent = new mastercardexception::MasterCardCBVoucherResponse;
         break;
      case 187:
         pEvent = new mastercardexception::VoucherResponse;
         break;
      case 188:
         pEvent = new regionalexception::PartialPreArbitrationResponse;
         break;
      case 189:
         pEvent = new regionalexception::NetworkRuling;
         break;
      case 190:
         pEvent = new mastercardexception::FeeCollection;
         break;
      case 191:
         pEvent = new genericexception::FeeCollectionReject;
         break;
      case 192:
         pEvent = new mastercardexception::FeeCollectionReversal;
         break;
      case 193:
         pEvent = new mastercardexception::FeeCollectionReturn;
         break;
      case 194:
         pEvent = new visaexception::SICloseTransactionResponse;
         break;
      case 195:
         pEvent = new genericexception::DM5Documentation;
         break;
      case 196:
         pEvent = new visaexception::GetTransDetailsResponse;
         break;
      case 197:
         pEvent = new eftposexception::ExtendDispute;
         break;
      case 198:
         pEvent = new eftposexception::AcceptDisputeReject;
         break;
      case 199:
         pEvent = new eftposexception::ExtendDisputeReject;
         break;
      case 200:
         pEvent = new eftposexception::AcceptDispute;
         break;
      case 201:
         pEvent = new eftposexception::Arbitration;
         break;
      case 202:
         pEvent = new eftposexception::ChargebackFinancial;
         break;
      case 203:
         pEvent = new eftposexception::EFTPOSAPIResponse;
         break;
      case 204:
         pEvent = new eftposexception::PreArbitrationResponse;
         break;
      case 205:
         pEvent = new eftposexception::CloseDispute;
         break;
      case 206:
         pEvent = new eftposexception::RepresentmentFinancial;
         break;
      case 207:
         pEvent = new eftposexception::UnmatchedImport;
         break;
      case 208:
         pEvent = new regionalexception::RepresentmentResponse;
         break;
      case 209:
         pEvent = new mastercardexception::CollaborationResponse;
         break;
      case 210:
         pEvent = new regionalexception::Appeal;
         break;
      case 211:
         pEvent = new regionalexception::Reversal;
         break;
      case 212:
         pEvent = new visaexception::SIGetDisputeFilingDetailsResponse;
         break;
      case 213:
         pEvent = new visaexception::Appeal;
         break;
      case 214:
         pEvent = new visaexception::Compliance;
         break;
      case 215:
         pEvent = new visaexception::HyperSearchResponse;
         break;
      case 216:
         pEvent = new visaexception::SIGetDisputeFinancialDetailsResponse;
         break;
      case 217:
         pEvent = new visaexception::Collaboration;
         break;
      case 218:
         pEvent = new mastercardexception::PreCompliance;
         break;
      case 219:
         pEvent = new mastercardexception::PreComplianceResponse;
         break;
      case 220:
         pEvent = new mastercardexception::ComplianceRecall;
         break;
      case 221:
         pEvent = new mastercardexception::PreComplianceRecall;
         break;
      case 222:
         pEvent = new regionalexception::StarDispute;
         break;
      case 223:
         pEvent = new regionalexception::ReceiveDocument;
         break;
      case 224:
         pEvent = new mastercardexception::FraudResponse;
         break;
      case 225:
         pEvent = new genericexception::ExceptionReview;
         break;
      case 226:
         pEvent = new visaexception::SIGetImageResponse;
         break;
   }
   return pEvent;
  //## end dnplatform::ExceptionFactory::create%4ADF11B303A9.body
}

// Additional Declarations
  //## begin dnplatform::ExceptionFactory%4ADF118A0261.declarations preserve=yes
  //## end dnplatform::ExceptionFactory%4ADF118A0261.declarations

} // namespace dnplatform

//## begin module%4ADF120F0232.epilog preserve=yes
//## end module%4ADF120F0232.epilog
