//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3EC3AD7F035B.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3EC3AD7F035B.cm

//## begin module%3EC3AD7F035B.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3EC3AD7F035B.cp

//## Module: CXOSEC15%3EC3AD7F035B; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC15.hpp

#ifndef CXOSEC15_h
#define CXOSEC15_h 1

//## begin module%3EC3AD7F035B.additionalIncludes preserve=no
//## end module%3EC3AD7F035B.additionalIncludes

//## begin module%3EC3AD7F035B.includes preserve=yes
// $Date:   Apr 09 2004 12:32:50  $ $Author:   D02405  $ $Revision:   1.1  $
//## end module%3EC3AD7F035B.includes

#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;

} // namespace ems

//## begin module%3EC3AD7F035B.declarations preserve=no
//## end module%3EC3AD7F035B.declarations

//## begin module%3EC3AD7F035B.additionalDeclarations preserve=yes
//## end module%3EC3AD7F035B.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseMMTListCommand%3EC3ACD8000F.preface preserve=yes
//## end emscommand::CaseMMTListCommand%3EC3ACD8000F.preface

//## Class: CaseMMTListCommand%3EC3ACD8000F
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3EC4E6400109;reusable::Row { -> F}
//## Uses: <unnamed>%3EC4E6690242;monitor::UseCase { -> F}
//## Uses: <unnamed>%3EC4E67A02FD;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%3EC4E68F01C5;ems::Case { -> F}

class DllExport CaseMMTListCommand : public command::ClientListCommand  //## Inherits: <unnamed>%3EC3ACFB02DE
{
  //## begin emscommand::CaseMMTListCommand%3EC3ACD8000F.initialDeclarations preserve=yes
  //## end emscommand::CaseMMTListCommand%3EC3ACD8000F.initialDeclarations

  public:
    //## Constructors (generated)
      CaseMMTListCommand();

    //## Constructors (specified)
      //## Operation: CaseMMTListCommand%3EC3AE0A0399
      CaseMMTListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseMMTListCommand();


    //## Other Operations (specified)
      //## Operation: update%3EC3AE230186
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::CaseMMTListCommand%3EC3ACD8000F.public preserve=yes
      //## end emscommand::CaseMMTListCommand%3EC3ACD8000F.public

  protected:

    //## Other Operations (specified)
      //## Operation: retrieve%3EC3AE1D0213
      virtual bool retrieve ();

    // Data Members for Class Attributes

      //## Attribute: szBuffer%3EC3AE2B01A5
      //## begin emscommand::CaseMMTListCommand::szBuffer%3EC3AE2B01A5.attr preserve=no  public: char* {U} 
      char* m_pszBuffer;
      //## end emscommand::CaseMMTListCommand::szBuffer%3EC3AE2B01A5.attr

    // Additional Protected Declarations
      //## begin emscommand::CaseMMTListCommand%3EC3ACD8000F.protected preserve=yes
      //## end emscommand::CaseMMTListCommand%3EC3ACD8000F.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseMMTListCommand%3EC3ACD8000F.private preserve=yes
      //## end emscommand::CaseMMTListCommand%3EC3ACD8000F.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin emscommand::CaseMMTListCommand%3EC3ACD8000F.implementation preserve=yes
      //## end emscommand::CaseMMTListCommand%3EC3ACD8000F.implementation

};

//## begin emscommand::CaseMMTListCommand%3EC3ACD8000F.postscript preserve=yes
//## end emscommand::CaseMMTListCommand%3EC3ACD8000F.postscript

} // namespace emscommand

//## begin module%3EC3AD7F035B.epilog preserve=yes
//## end module%3EC3AD7F035B.epilog


#endif
