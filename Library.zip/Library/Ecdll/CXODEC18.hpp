//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3FC3821C0399.cm preserve=no
//	$Date:   Apr 09 2012 06:17:26  $ $Author:   E3003354  $
//	$Revision:   1.5  $
//## end module%3FC3821C0399.cm

//## begin module%3FC3821C0399.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3FC3821C0399.cp

//## Module: CXOSEC18%3FC3821C0399; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC18.hpp

#ifndef CXOSEC18_h
#define CXOSEC18_h 1

//## begin module%3FC3821C0399.additionalIncludes preserve=no
//## end module%3FC3821C0399.additionalIncludes

//## begin module%3FC3821C0399.includes preserve=yes
// $Date:   Apr 09 2012 06:17:26  $ $Author:   E3003354  $ $Revision:   1.5  $
//## end module%3FC3821C0399.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseSegment;
} // namespace emssegment

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialSettlementSegment;

} // namespace repositorysegment

//## begin module%3FC3821C0399.declarations preserve=no
//## end module%3FC3821C0399.declarations

//## begin module%3FC3821C0399.additionalDeclarations preserve=yes
//## end module%3FC3821C0399.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.preface preserve=yes
//## end emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.preface

//## Class: CaseRetrieveRuleSetCommand%3FC382FF03A9
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FC389A00399;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%3FC389A20242;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%3FC389C2001F;IF::Message { -> F}
//## Uses: <unnamed>%3FC389C40128;monitor::UseCase { -> F}
//## Uses: <unnamed>%3FC389F60128;segment::InformationSegment { -> F}
//## Uses: <unnamed>%3FC38FBD01C5;repositorysegment::FinancialBaseSegment { -> F}
//## Uses: <unnamed>%3FC50A6702AF;emssegment::CaseNetRuleUseSegment { -> F}
//## Uses: <unnamed>%3FCB4CEA032C;ems::EMSNetRuleUseTable { -> F}
//## Uses: <unnamed>%4017DC9300CB;ems::EMSNetRuleUse { -> F}
//## Uses: <unnamed>%436F44FA0119;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%4F7AD12C02A7;repositorysegment::FinancialSettlementSegment { -> F}

class DllExport CaseRetrieveRuleSetCommand : public command::ClientCommand  //## Inherits: <unnamed>%3FC38422000F
{
  //## begin emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.initialDeclarations preserve=yes
  //## end emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.initialDeclarations

  public:
    //## Constructors (generated)
      CaseRetrieveRuleSetCommand();

    //## Constructors (specified)
      //## Operation: CaseRetrieveRuleSetCommand%3FC385D9034B
      CaseRetrieveRuleSetCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseRetrieveRuleSetCommand();


    //## Other Operations (specified)
      //## Operation: execute%3FC385DD0157
      //	Perform the functions of this command.
      virtual bool execute ();

    // Additional Public Declarations
      //## begin emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.public preserve=yes
      //## end emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.protected preserve=yes
      //## end emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.private preserve=yes
      //## end emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.implementation preserve=yes
      //## end emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.implementation

};

//## begin emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.postscript preserve=yes
//## end emscommand::CaseRetrieveRuleSetCommand%3FC382FF03A9.postscript

} // namespace emscommand

//## begin module%3FC3821C0399.epilog preserve=yes
//## end module%3FC3821C0399.epilog


#endif
