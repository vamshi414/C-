//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E89E8C20242.cm preserve=no
//	$Date:   Mar 25 2013 11:29:30  $ $Author:   e1009839  $
//	$Revision:   1.4  $
//## end module%3E89E8C20242.cm

//## begin module%3E89E8C20242.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3E89E8C20242.cp

//## Module: CXOSEC12%3E89E8C20242; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\bV02.3B.R001\Windows\Build\Dn\Server\Library\Ecdll\CXODEC12.hpp

#ifndef CXOSEC12_h
#define CXOSEC12_h 1

//## begin module%3E89E8C20242.additionalIncludes preserve=no
//## end module%3E89E8C20242.additionalIncludes

//## begin module%3E89E8C20242.includes preserve=yes
//## end module%3E89E8C20242.includes

#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class Case;
} // namespace ems

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Row;

} // namespace reusable

//## begin module%3E89E8C20242.declarations preserve=no
//## end module%3E89E8C20242.declarations

//## begin module%3E89E8C20242.additionalDeclarations preserve=yes
//## end module%3E89E8C20242.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.preface preserve=yes
//## end emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.preface

//## Class: CaseAvailablePhaseListCommand%3E89EB3A031C
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E8A19F900BB;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%3E8B050800DA;monitor::UseCase { -> F}
//## Uses: <unnamed>%3E8B12CB01D4;reusable::Row { -> F}
//## Uses: <unnamed>%3ED6344D0138;ems::Case { -> F}

class DllExport CaseAvailablePhaseListCommand : public command::ClientListCommand  //## Inherits: <unnamed>%3E89EB6F0261
{
  //## begin emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.initialDeclarations preserve=yes
  //## end emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.initialDeclarations

  public:
    //## Constructors (generated)
      CaseAvailablePhaseListCommand();

    //## Constructors (specified)
      //## Operation: CaseAvailablePhaseListCommand%3E8AF4F500DA
      CaseAvailablePhaseListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseAvailablePhaseListCommand();


    //## Other Operations (specified)
      //## Operation: update%3E8C8D620232
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.public preserve=yes
      //## end emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.public

  protected:

    //## Other Operations (specified)
      //## Operation: retrieve%3E89EC0E032C
      virtual bool retrieve ();

    // Data Members for Class Attributes

      //## Attribute: szBuffer%3E8A1A560148
      //## begin emscommand::CaseAvailablePhaseListCommand::szBuffer%3E8A1A560148.attr preserve=no  public: char* {U} 
      char* m_pszBuffer;
      //## end emscommand::CaseAvailablePhaseListCommand::szBuffer%3E8A1A560148.attr

    // Additional Protected Declarations
      //## begin emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.protected preserve=yes
      //## end emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.private preserve=yes
      //## end emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.implementation preserve=yes
      //## end emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.implementation

};

//## begin emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.postscript preserve=yes
//## end emscommand::CaseAvailablePhaseListCommand%3E89EB3A031C.postscript

} // namespace emscommand

//## begin module%3E89E8C20242.epilog preserve=yes
//## end module%3E89E8C20242.epilog


#endif
