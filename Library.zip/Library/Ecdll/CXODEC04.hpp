//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%35B639290320.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%35B639290320.cm

//## begin module%35B639290320.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%35B639290320.cp

//## Module: CXOSEC04%35B639290320; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Pvcswork\Dn\Server\Library\Ecdll\CXODEC04.hpp

#ifndef CXOSEC04_h
#define CXOSEC04_h 1

//## begin module%35B639290320.additionalIncludes preserve=no
//## end module%35B639290320.additionalIncludes

//## begin module%35B639290320.includes preserve=yes
// $Date:   Apr 09 2004 12:32:52  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%35B639290320.includes

#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif
#ifndef CXOSES04_h
#include "CXODES04.hpp"
#endif

//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: DataNavigator Foundation::UserSegment_CAT%394E272B01EC
namespace usersegment {
class RelationshipSegment;
} // namespace usersegment

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Row;
} // namespace reusable

//## Modelname: Connex Foundation::Segment_CAT%3471F0BE0219
namespace segment {
class PrimaryKeySegment;
} // namespace segment

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Message;

} // namespace IF

//## begin module%35B639290320.declarations preserve=no
//## end module%35B639290320.declarations

//## begin module%35B639290320.additionalDeclarations preserve=yes
//## end module%35B639290320.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseChangeListCommand%35B634FA0258.preface preserve=yes
//## end emscommand::CaseChangeListCommand%35B634FA0258.preface

//## Class: CaseChangeListCommand%35B634FA0258
//	QEMLDCHG - retrieve list of maintenance audit trail for
//	an EMS case.
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%36BF2D1801FB;IF::Message { -> F}
//## Uses: <unnamed>%36BF306E0040;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%36BF3116022D;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%37F0E0EF0191;usersegment::RelationshipSegment { -> F}
//## Uses: <unnamed>%3958D465028A;reusable::Row { -> F}
//## Uses: <unnamed>%3A01B64E0373;monitor::UseCase { -> F}

class DllExport CaseChangeListCommand : public command::ClientListCommand  //## Inherits: <unnamed>%3958CAD403E7
{
  //## begin emscommand::CaseChangeListCommand%35B634FA0258.initialDeclarations preserve=yes
  //## end emscommand::CaseChangeListCommand%35B634FA0258.initialDeclarations

  public:
    //## Constructors (generated)
      CaseChangeListCommand();

    //## Constructors (specified)
      //## Operation: CaseChangeListCommand%3731EE76023F
      CaseChangeListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseChangeListCommand();


    //## Other Operations (specified)
      //## Operation: retrieve%3958CD6B0123
      bool retrieve ();

      //## Operation: update%36BF1BA6004A
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::CaseChangeListCommand%35B634FA0258.public preserve=yes
      //## end emscommand::CaseChangeListCommand%35B634FA0258.public

  protected:
    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Foundation::Command_CAT::<unnamed>%35B73A4D0043
      //## Role: CaseChangeListCommand::<m_pPrimaryKeySegment>%35B73A4E01A3
      segment::PrimaryKeySegment * getPrimaryKeySegment ()
      {
        //## begin emscommand::CaseChangeListCommand::getPrimaryKeySegment%35B73A4E01A3.get preserve=no
        return m_pPrimaryKeySegment;
        //## end emscommand::CaseChangeListCommand::getPrimaryKeySegment%35B73A4E01A3.get
      }


    // Additional Protected Declarations
      //## begin emscommand::CaseChangeListCommand%35B634FA0258.protected preserve=yes
      //## end emscommand::CaseChangeListCommand%35B634FA0258.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseChangeListCommand%35B634FA0258.private preserve=yes
      //## end emscommand::CaseChangeListCommand%35B634FA0258.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: szBuffer%39590E5B00C3
      //## begin emscommand::CaseChangeListCommand::szBuffer%39590E5B00C3.attr preserve=no  private: char* {U} 
      char* m_pszBuffer;
      //## end emscommand::CaseChangeListCommand::szBuffer%39590E5B00C3.attr

    // Data Members for Associations

      //## Association: Connex Foundation::Command_CAT::<unnamed>%35B73A4D0043
      //## begin emscommand::CaseChangeListCommand::<m_pPrimaryKeySegment>%35B73A4E01A3.role preserve=no  protected: segment::PrimaryKeySegment { -> RFHgN}
      segment::PrimaryKeySegment *m_pPrimaryKeySegment;
      //## end emscommand::CaseChangeListCommand::<m_pPrimaryKeySegment>%35B73A4E01A3.role

      //## Association: Connex Foundation::Command_CAT::<unnamed>%373816DB01D1
      //## Role: CaseChangeListCommand::<m_hCaseChangeSegment>%373816DC00C4
      //## begin emscommand::CaseChangeListCommand::<m_hCaseChangeSegment>%373816DC00C4.role preserve=no  public: emssegment::CaseChangeSegment { -> VHgN}
      emssegment::CaseChangeSegment m_hCaseChangeSegment;
      //## end emscommand::CaseChangeListCommand::<m_hCaseChangeSegment>%373816DC00C4.role

    // Additional Implementation Declarations
      //## begin emscommand::CaseChangeListCommand%35B634FA0258.implementation preserve=yes
      //## end emscommand::CaseChangeListCommand%35B634FA0258.implementation

};

//## begin emscommand::CaseChangeListCommand%35B634FA0258.postscript preserve=yes
//## end emscommand::CaseChangeListCommand%35B634FA0258.postscript

} // namespace emscommand

//## begin module%35B639290320.epilog preserve=yes
using namespace emscommand;
//## end module%35B639290320.epilog


#endif
