//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4999BFC6008C.cm preserve=no
//	$Date:   May 31 2019 03:51:48  $ $Author:   e5558744  $
//	$Revision:   1.2  $
//## end module%4999BFC6008C.cm

//## begin module%4999BFC6008C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4999BFC6008C.cp

//## Module: CXOSEC23%4999BFC6008C; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: D:\V02.9D.R001\Dn\Server\Library\Ecdll\CXODEC23.hpp

#ifndef CXOSEC23_h
#define CXOSEC23_h 1

//## begin module%4999BFC6008C.additionalIncludes preserve=no
//## end module%4999BFC6008C.additionalIncludes

//## begin module%4999BFC6008C.includes preserve=yes
//## end module%4999BFC6008C.includes

#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif
#ifndef CXOSES62_h
#include "CXODES62.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseSegment;
} // namespace emssegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
class SelectStatement;
class Row;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class PrimaryKeySegment;
} // namespace segment

//## Modelname: Connex Library::Rules_CAT (RLDLL)%3EB810F40157
namespace rules {
class RulesEngine;

} // namespace rules

//## begin module%4999BFC6008C.declarations preserve=no
//## end module%4999BFC6008C.declarations

//## begin module%4999BFC6008C.additionalDeclarations preserve=yes
//## end module%4999BFC6008C.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::RelatedCasesCommand%4999B15C0186.preface preserve=yes
//## end emscommand::RelatedCasesCommand%4999B15C0186.preface

//## Class: RelatedCasesCommand%4999B15C0186
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4999C0AC0271;reusable::Query { -> F}
//## Uses: <unnamed>%4999C0BD02BF;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4999C0CC02AF;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4999C0EC0000;reusable::Row { -> F}
//## Uses: <unnamed>%4999C0FD0290;monitor::UseCase { -> F}
//## Uses: <unnamed>%4999D1F5004E;segment::InformationSegment { -> F}
//## Uses: <unnamed>%4999D7A7009C;rules::RulesEngine { -> F}
//## Uses: <unnamed>%4BBDDC8C018E;emssegment::CaseSegment { -> F}

class DllExport RelatedCasesCommand : public command::ClientListCommand  //## Inherits: <unnamed>%4999BF6E004E
{
  //## begin emscommand::RelatedCasesCommand%4999B15C0186.initialDeclarations preserve=yes
  //## end emscommand::RelatedCasesCommand%4999B15C0186.initialDeclarations

  public:
    //## Constructors (generated)
      RelatedCasesCommand();

    //## Constructors (specified)
      //## Operation: RelatedCasesCommand%4999C1440290
      RelatedCasesCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~RelatedCasesCommand();


    //## Other Operations (specified)
      //## Operation: cleanup%5CE39B1B0167
      void cleanup ();

      //## Operation: update%4999C122035B
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::RelatedCasesCommand%4999B15C0186.public preserve=yes
      //## end emscommand::RelatedCasesCommand%4999B15C0186.public

  protected:

    //## Other Operations (specified)
      //## Operation: retrieve%4999C11E0128
      virtual bool retrieve ();

    // Additional Protected Declarations
      //## begin emscommand::RelatedCasesCommand%4999B15C0186.protected preserve=yes
      //## end emscommand::RelatedCasesCommand%4999B15C0186.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::RelatedCasesCommand%4999B15C0186.private preserve=yes
      //## end emscommand::RelatedCasesCommand%4999B15C0186.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: AMT_TRAN%4999DB1B002E
      //## begin emscommand::RelatedCasesCommand::AMT_TRAN%4999DB1B002E.attr preserve=no  private: double {U} 
      double m_dAMT_TRAN;
      //## end emscommand::RelatedCasesCommand::AMT_TRAN%4999DB1B002E.attr

      //## Attribute: Buffer%4999CDC0031C
      //## begin emscommand::RelatedCasesCommand::Buffer%4999CDC0031C.attr preserve=no  private: char* {U} 
      char* m_pszBuffer;
      //## end emscommand::RelatedCasesCommand::Buffer%4999CDC0031C.attr

      //## Attribute: NET_RULES%4BBDD9ED0366
      //## begin emscommand::RelatedCasesCommand::NET_RULES%4BBDD9ED0366.attr preserve=no  private: string {U} 
      string m_strNET_RULES;
      //## end emscommand::RelatedCasesCommand::NET_RULES%4BBDD9ED0366.attr

      //## Attribute: PAN%4999DB3C0157
      //## begin emscommand::RelatedCasesCommand::PAN%4999DB3C0157.attr preserve=no  private: string {U} 
      string m_strPAN;
      //## end emscommand::RelatedCasesCommand::PAN%4999DB3C0157.attr

      //## Attribute: RETRIEVAL_REF_NO%4999DAEF02FD
      //## begin emscommand::RelatedCasesCommand::RETRIEVAL_REF_NO%4999DAEF02FD.attr preserve=no  private: string {U} 
      string m_strRETRIEVAL_REF_NO;
      //## end emscommand::RelatedCasesCommand::RETRIEVAL_REF_NO%4999DAEF02FD.attr

      //## Attribute: StateDescription%4999D73E01C5
      //## begin emscommand::RelatedCasesCommand::StateDescription%4999D73E01C5.attr preserve=no  private: string {U} 
      string m_strStateDescription;
      //## end emscommand::RelatedCasesCommand::StateDescription%4999D73E01C5.attr

      //## Attribute: SYS_TRACE_AUDIT_NO%4999DB080177
      //## begin emscommand::RelatedCasesCommand::SYS_TRACE_AUDIT_NO%4999DB080177.attr preserve=no  private: string {U} 
      string m_strSYS_TRACE_AUDIT_NO;
      //## end emscommand::RelatedCasesCommand::SYS_TRACE_AUDIT_NO%4999DB080177.attr

      //## Attribute: TSTAMP_TRANS%4999DACF0251
      //## begin emscommand::RelatedCasesCommand::TSTAMP_TRANS%4999DACF0251.attr preserve=no  private: string {U} 
      string m_strTSTAMP_TRANS;
      //## end emscommand::RelatedCasesCommand::TSTAMP_TRANS%4999DACF0251.attr

      //## Attribute: UNIQUENESS_KEY%4999DADF0177
      //## begin emscommand::RelatedCasesCommand::UNIQUENESS_KEY%4999DADF0177.attr preserve=no  private: short {U} 
      short m_siUNIQUENESS_KEY;
      //## end emscommand::RelatedCasesCommand::UNIQUENESS_KEY%4999DADF0177.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4999BF9602EE
      //## Role: RelatedCasesCommand::<m_hRelatedCaseSegment>%4999BF9701D4
      //## begin emscommand::RelatedCasesCommand::<m_hRelatedCaseSegment>%4999BF9701D4.role preserve=no  public: emssegment::RelatedCaseSegment { -> VHgN}
      emssegment::RelatedCaseSegment m_hRelatedCaseSegment;
      //## end emscommand::RelatedCasesCommand::<m_hRelatedCaseSegment>%4999BF9701D4.role

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4999C07801F4
      //## Role: RelatedCasesCommand::<m_pPrimaryKeySegment>%4999C0790109
      //## begin emscommand::RelatedCasesCommand::<m_pPrimaryKeySegment>%4999C0790109.role preserve=no  public: segment::PrimaryKeySegment { -> RFHgN}
      segment::PrimaryKeySegment *m_pPrimaryKeySegment;
      //## end emscommand::RelatedCasesCommand::<m_pPrimaryKeySegment>%4999C0790109.role

    // Additional Implementation Declarations
      //## begin emscommand::RelatedCasesCommand%4999B15C0186.implementation preserve=yes
      //## end emscommand::RelatedCasesCommand%4999B15C0186.implementation

};

//## begin emscommand::RelatedCasesCommand%4999B15C0186.postscript preserve=yes
//## end emscommand::RelatedCasesCommand%4999B15C0186.postscript

} // namespace emscommand

//## begin module%4999BFC6008C.epilog preserve=yes
using namespace emscommand;
//## end module%4999BFC6008C.epilog


#endif
