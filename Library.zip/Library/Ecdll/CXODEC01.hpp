//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35758F660121.cm preserve=no
//	$Date:   Sep 18 2020 02:34:52  $ $Author:   e3022417  $
//	$Revision:   1.39  $
//## end module%35758F660121.cm

//## begin module%35758F660121.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%35758F660121.cp

//## Module: CXOSEC01%35758F660121; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel_July\Dn\Server\Library\Ecdll\CXODEC01.hpp

#ifndef CXOSEC01_h
#define CXOSEC01_h 1

//## begin module%35758F660121.additionalIncludes preserve=no
//## end module%35758F660121.additionalIncludes

//## begin module%35758F660121.includes preserve=yes
// $Date:   Sep 18 2020 02:34:52  $ $Author:   e3022417  $ $Revision:   1.39  $
#include <set>
//## end module%35758F660121.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif
#ifndef CXOSES18_h
#include "CXODES18.hpp"
#endif
#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class LineitemSegment;
class CaseZappSegment;
class CasePhaseVisaVROLSegment;
class CaseIntegratedCircuitCardSegment;
class CaseDocumentExtensionSegment;
class CaseSmartFormSegment;
} // namespace emssegment

//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
class ArchiveRetriever;
} // namespace archive

//## Modelname: DataNavigator Foundation::EntityCommand_CAT%394E2706012A
namespace entitycommand {
class CardholderAddress;
} // namespace entitycommand

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Context;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class PersistentSegment;
class ListSegment;

} // namespace segment

//## begin module%35758F660121.declarations preserve=no
//## end module%35758F660121.declarations

//## begin module%35758F660121.additionalDeclarations preserve=yes
//## end module%35758F660121.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseCreateCommand%357453C2017E.preface preserve=yes
//## end emscommand::CaseCreateCommand%357453C2017E.preface

//## Class: CaseCreateCommand%357453C2017E
//	QEMCCASE - create a new EMS case.
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%359CF57E00EA;segment::InformationSegment { -> }
//## Uses: <unnamed>%359CF7A2012E;segment::CommonHeaderSegment { -> }
//## Uses: <unnamed>%359CF8380025;reusable::Table { -> }
//## Uses: <unnamed>%361D11E100FF;database::DatabaseFactory { -> }
//## Uses: <unnamed>%361D120302F2;reusable::Query { -> }
//## Uses: <unnamed>%361D12070230;reusable::SelectStatement { -> }
//## Uses: <unnamed>%370A76ED038E;IF::Message { -> }
//## Uses: <unnamed>%3736E86201DB;database::Database { -> }
//## Uses: <unnamed>%3736E86500A9;IF::Queue { -> }
//## Uses: <unnamed>%3737210F0314;reusable::Statement { -> }
//## Uses: <unnamed>%373B3B5701CE;emssegment::CaseTransitionSegment { -> }
//## Uses: <unnamed>%373B3B5D00F1;emssegment::CaseSegment { -> }
//## Uses: <unnamed>%373B432601DD;timer::Clock { -> }
//## Uses: <unnamed>%3743F76F030C;ems::Case { -> }
//## Uses: <unnamed>%378CDE67007C;emssegment::CaseCommentSegment { -> }
//## Uses: <unnamed>%37B2E8F1018B;repositorycommand::FinancialUpdateFinTypeCommand { -> }
//## Uses: <unnamed>%37F0E0BA01F9;usersegment::RelationshipSegment { -> }
//## Uses: <unnamed>%3857ACAA0083;reusable::Transaction { -> }
//## Uses: <unnamed>%3A01B7AF02EF;monitor::UseCase { -> }
//## Uses: <unnamed>%3BFECAA10111;repositorysegment::FinancialBaseSegment { -> }
//## Uses: <unnamed>%3BFECFD300B9;timer::Date { -> }
//## Uses: <unnamed>%3BFEDA6900CA;IF::Extract { -> }
//## Uses: <unnamed>%3C0526200262;IF::Trace { -> }
//## Uses: <unnamed>%3C1A63950232;configuration::ConfigurationRepository { -> }
//## Uses: <unnamed>%3C1A6DC40157;reusable::CriticalSection { -> }
//## Uses: <unnamed>%3C46E2E20142;IF::EMailMessage { -> }
//## Uses: <unnamed>%3C48A3CA0243;repositorysegment::FinancialSettlementSegment { -> }
//## Uses: <unnamed>%3C7412AB0055;archive::ArchiveRetriever { -> F}
//## Uses: <unnamed>%3E3159D601F4;repositorysegment::CardholderInformationSegment { -> F}
//## Uses: <unnamed>%3E315A20005D;ems::CaseNotification { -> F}
//## Uses: <unnamed>%3E4CFC500186;database::DisputeProcessor { -> F}
//## Uses: <unnamed>%3E4D00DE03A9;emssegment::CaseNationalNetworkSegment { -> F}
//## Uses: <unnamed>%3E6632160000;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%3EA00460036B;emssegment::CasePhaseNetworkUniqueSegment { -> F}
//## Uses: <unnamed>%3EA004660186;emssegment::CaseNetworkUniqueSegment { -> F}
//## Uses: <unnamed>%3EA004C3033C;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%3EA42E8701C5;ems::CaseAddEventVisitor { -> F}
//## Uses: <unnamed>%3EA4301B000F;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%3EC23B2D02DE;emssegment::CaseDocumentSegment { -> F}
//## Uses: <unnamed>%3EC924AA0148;segment::PersistentSegment { -> F}
//## Uses: <unnamed>%40717C0103B9;emssegment::CaseAccountHistorySegment { -> F}
//## Uses: <unnamed>%4073041F002E;ems::AccountEntry { -> F}
//## Uses: <unnamed>%464C242D021A;emssegment::CasePhaseVisaVROLSegment { -> F}
//## Uses: <unnamed>%4692263501FA;emssegment::CaseIntegratedCircuitCardSegment { -> F}
//## Uses: <unnamed>%4A1EC526034B;database::Context { -> F}
//## Uses: <unnamed>%5523AB40024E;emssegment::LineitemSegment { -> F}
//## Uses: <unnamed>%5523ACA40223;emssegment::CaseZappSegment { -> F}
//## Uses: <unnamed>%5CCA7F8302D5;emssegment::CaseSmartFormSegment { -> F}
//## Uses: <unnamed>%5E7B07790270;emssegment::CaseDocumentExtensionSegment { -> F}
//## Uses: <unnamed>%5F6461970035;entitycommand::CardholderAddress { -> F}

class DllExport CaseCreateCommand : public command::ClientCommand  //## Inherits: <unnamed>%35978AB0025D
{
  //## begin emscommand::CaseCreateCommand%357453C2017E.initialDeclarations preserve=yes
  //## end emscommand::CaseCreateCommand%357453C2017E.initialDeclarations

  public:
    //## Constructors (generated)
      CaseCreateCommand();

    //## Constructors (specified)
      //## Operation: CaseCreateCommand%3731DCC30258
      CaseCreateCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseCreateCommand();


    //## Other Operations (specified)
      //## Operation: calculateSurcharge%5149FB5E0227
      void calculateSurcharge ();

      //## Operation: createAcqCase%4E3827B001AE
      bool createAcqCase (const string& strCustomer, const string& strQualifier, const string& strNetwork);

      //## Operation: createIssCase%4E382702027F
      bool createIssCase (const string& strCustomer, const string& strQualifier, const string& strNetwork);

      //## Operation: execute%35994C4B01B7
      //	Perform the functions of this command.
      //## Postconditions:
      //	<body>
      //	<title>CG
      //	<h1>EM
      //	<h2>FO
      //	<h3>Case
      //	<p>
      //	Cases are created in the following tables:
      //	<ul>
      //	<li><i>custqual</i>.EMS_CASE
      //	<li><i>custqual</i>.EMS_CASE_AFN
      //	<li><i>custqual</i>.EMS_CASE_AUS
      //	<li><i>custqual</i>.EMS_CASE_CRS
      //	<li><i>custqual</i>.EMS_CASE_CSH
      //	<li><i>custqual</i>.EMS_CASE_HNR
      //	<li><i>custqual</i>.EMS_CASE_ILK
      //	<li><i>custqual</i>.EMS_CASE_MAC
      //	<li><i>custqual</i>.EMS_CASE_MCI
      //	<li><i>custqual</i>.EMS_CASE_NYC
      //	<li><i>custqual</i>.EMS_CASE_PLS
      //	<li><i>custqual</i>.EMS_CASE_PUL
      //	<li><i>custqual</i>.EMS_CASE_STR
      //	<li><i>custqual</i>.EMS_CASE_VNT
      //	<li><i>custqual</i>.EMS_TRANSITION
      //	<li><i>custqual</i>.EMS_PHASE
      //	<li><i>custqual</i>.EMS_PHASE_AUS
      //	<li><i>custqual</i>.EMS_PHASE_CRS
      //	<li><i>custqual</i>.EMS_PHASE_CSH
      //	<li><i>custqual</i>.EMS_PHASE_ILK
      //	<li><i>custqual</i>.EMS_PHASE_MAC
      //	<li><i>custqual</i>.EMS_PHASE_MCI
      //	<li><i>custqual</i>.EMS_PHASE_NYC
      //	<li><i>custqual</i>.EMS_PHASE_PUL
      //	<li><i>custqual</i>.EMS_PHASE_STR
      //	<li><i>custqual</i>.EMS_PHASE_VNT
      //	<li><i>custqual</i>.EMS_COMMENT
      //	<li><i>custqual</i>.EMS_CASE_CONTEXT
      //	<li><i>custqual</i>.EMS_DATA_CHG
      //	<li><i>custqual</i>.EMS_DOCUMENT
      //	<li><i>custqual</i>.EMS_NATIONAL_NET
      //	<li><i>custqual</i>.EMS_FRAUD
      //	<li><i>custqual</i>.EMS_FRAUD_MCI
      //	<li><i>custqual</i>.EMS_FRAUD_VNT
      //	</ul>
      //	</p>
      //	</body>
      virtual bool execute ();

      //## Operation: findAcqProc%4E38269E0232
      bool findAcqProc (string& strNetwork);

      //## Operation: findIssProc%4E3825100111
      bool findIssProc (string& strNetwork);

      //## Operation: getMaxCaseID%5F6460FA023A
      bool getMaxCaseID ();

      //## Operation: insertDocExtSegment%5E7B06DC0358
      bool insertDocExtSegment (const string &strQUESTION_FIELDS);

      //## Operation: insertSmartFormSegment%5CCA7E8B0333
      bool insertSmartFormSegment (const string &strQUESTION_FIELDS);

      //## Operation: insertVROLSegment%47173EA300FA
      bool insertVROLSegment (string strQUESTION_FIELDS);

      //## Operation: instance%4B9F90080354
      static CaseCreateCommand* instance ();

      //## Operation: parse%375E7B7D02AB
      //	Parse this command into segments.
      //## Semantics:
      //	1. Verify the message length.
      //	2. Reset all segments.
      //	3. Import the available segments.
      virtual int parse ();

      //## Operation: replicate%4B74047D02FD
      virtual bool replicate ();

      //## Operation: replicateOtherCase%4E70CB07017C
      void replicateOtherCase ();

      //## Operation: setCaseCountryISS%4CCD58FF0060
      void setCaseCountryISS ();

      //## Operation: update%3731DCBA0197
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

      //## Operation: validDuplicate%495E140F0280
      bool validDuplicate ();

    //## Get and Set Operations for Associations (generated)

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%3EC4F7120213
      //## Role: CaseCreateCommand::<m_pListSegment>%3EC4F713002E
      segment::ListSegment * getListSegment (int index)
      {
        //## begin emscommand::CaseCreateCommand::getListSegment%3EC4F713002E.get preserve=no
        return m_pListSegment[index];
        //## end emscommand::CaseCreateCommand::getListSegment%3EC4F713002E.get
      }


    // Additional Public Declarations
      //## begin emscommand::CaseCreateCommand%357453C2017E.public preserve=yes
      //## end emscommand::CaseCreateCommand%357453C2017E.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::CaseCreateCommand%357453C2017E.protected preserve=yes
      //## end emscommand::CaseCreateCommand%357453C2017E.protected

  private:

    //## Other Operations (specified)
      //## Operation: createCase%3BFE765C0297
      bool createCase (bool bFirstCase);

      //## Operation: insertSegment%3EC9085402AF
      bool insertSegment (segment::PersistentSegment* pPersistentSegment);

      //## Operation: mapStarTRAN_CODE%3D53C6800242
      void mapStarTRAN_CODE ();

    // Additional Private Declarations
      //## begin emscommand::CaseCreateCommand%357453C2017E.private preserve=yes
      //## end emscommand::CaseCreateCommand%357453C2017E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CUST_ID%3BFED9FA0319
      //## begin emscommand::CaseCreateCommand::CUST_ID%3BFED9FA0319.attr preserve=no  private: string {U} 
      string m_strCUST_ID;
      //## end emscommand::CaseCreateCommand::CUST_ID%3BFED9FA0319.attr

      //## Attribute: OCS%473AE7870040
      //## begin emscommand::CaseCreateCommand::OCS%473AE7870040.attr preserve=no  private: bool {U} 
      bool m_bOCS;
      //## end emscommand::CaseCreateCommand::OCS%473AE7870040.attr

      //## Attribute: Instance%4B9F8E980263
      //## begin emscommand::CaseCreateCommand::Instance%4B9F8E980263.attr preserve=no  private: static CaseCreateCommand* {V} 0
      static CaseCreateCommand* m_pInstance;
      //## end emscommand::CaseCreateCommand::Instance%4B9F8E980263.attr

      //## Attribute: USTerritories%5149FE7F0053
      //## begin emscommand::CaseCreateCommand::USTerritories%5149FE7F0053.attr preserve=no  public: set<string, less<string> > {U} 
      set<string, less<string> > m_hUSTerritories;
      //## end emscommand::CaseCreateCommand::USTerritories%5149FE7F0053.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%3EC4F7120213
      //## begin emscommand::CaseCreateCommand::<m_pListSegment>%3EC4F713002E.role preserve=no  public: segment::ListSegment { -> 4RFHgN}
      segment::ListSegment *m_pListSegment[4];
      //## end emscommand::CaseCreateCommand::<m_pListSegment>%3EC4F713002E.role

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4E414AFD02CD
      //## Role: CaseCreateCommand::<m_hCaseSegment>%4E414AFE019E
      //## begin emscommand::CaseCreateCommand::<m_hCaseSegment>%4E414AFE019E.role preserve=no  public: emssegment::CaseSegment { -> 2VHgN}
      emssegment::CaseSegment m_hCaseSegment[2];
      //## end emscommand::CaseCreateCommand::<m_hCaseSegment>%4E414AFE019E.role

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4E41758C0299
      //## Role: CaseCreateCommand::<m_hCasePhaseSegment>%4E41758D028D
      //## begin emscommand::CaseCreateCommand::<m_hCasePhaseSegment>%4E41758D028D.role preserve=no  public: emssegment::CasePhaseSegment { -> 2VHgN}
      emssegment::CasePhaseSegment m_hCasePhaseSegment[2];
      //## end emscommand::CaseCreateCommand::<m_hCasePhaseSegment>%4E41758D028D.role

    // Additional Implementation Declarations
      //## begin emscommand::CaseCreateCommand%357453C2017E.implementation preserve=yes
      //## end emscommand::CaseCreateCommand%357453C2017E.implementation

};

//## begin emscommand::CaseCreateCommand%357453C2017E.postscript preserve=yes
//## end emscommand::CaseCreateCommand%357453C2017E.postscript

} // namespace emscommand

//## begin module%35758F660121.epilog preserve=yes
using namespace emscommand;
//## end module%35758F660121.epilog


#endif
