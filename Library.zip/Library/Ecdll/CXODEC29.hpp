//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4AC36A6602AB.cm preserve=no
//	$Date:   Oct 26 2009 10:57:54  $ $Author:   D93482  $
//	$Revision:   1.0  $
//## end module%4AC36A6602AB.cm

//## begin module%4AC36A6602AB.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%4AC36A6602AB.cp

//## Module: CXOSEC29%4AC36A6602AB; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC29.hpp

#ifndef CXOSEC29_h
#define CXOSEC29_h 1

//## begin module%4AC36A6602AB.additionalIncludes preserve=no
//## end module%4AC36A6602AB.additionalIncludes

//## begin module%4AC36A6602AB.includes preserve=yes
//## end module%4AC36A6602AB.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
class CaseCreateCommand;
} // namespace emscommand

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class DisputedAuthorization;
} // namespace ems

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ResponseTimeSegment;
class PrimaryKeySegment;
class CommonHeaderSegment;
class InformationSegment;

} // namespace segment

//## begin module%4AC36A6602AB.declarations preserve=no
//## end module%4AC36A6602AB.declarations

//## begin module%4AC36A6602AB.additionalDeclarations preserve=yes
//## end module%4AC36A6602AB.additionalDeclarations


namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::AuthorizationFlagCommand%4AC36A1B00E6.preface preserve=yes
//## end emscommand::AuthorizationFlagCommand%4AC36A1B00E6.preface

//## Class: AuthorizationFlagCommand%4AC36A1B00E6
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4AC3774502C7;IF::Message { -> F}
//## Uses: <unnamed>%4AC377B70265;monitor::UseCase { -> F}
//## Uses: <unnamed>%4AC377DA0041;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%4AC377FC0012;segment::InformationSegment { -> F}
//## Uses: <unnamed>%4AC37809006F;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%4AC39FE7001C;ems::DisputedAuthorization { -> F}
//## Uses: <unnamed>%4ACA3C9300B6;CaseCreateCommand { -> F}

class DllExport AuthorizationFlagCommand : public command::ClientCommand  //## Inherits: <unnamed>%4AC36BB80372
{
  //## begin emscommand::AuthorizationFlagCommand%4AC36A1B00E6.initialDeclarations preserve=yes
  //## end emscommand::AuthorizationFlagCommand%4AC36A1B00E6.initialDeclarations

  public:
    //## Constructors (generated)
      AuthorizationFlagCommand();

    //## Constructors (specified)
      //## Operation: AuthorizationFlagCommand%4AC36D660066
      AuthorizationFlagCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~AuthorizationFlagCommand();


    //## Other Operations (specified)
      //## Operation: execute%4AC36C060302
      //	Perform the functions of this command.
      virtual bool execute ();

    // Additional Public Declarations
      //## begin emscommand::AuthorizationFlagCommand%4AC36A1B00E6.public preserve=yes
      //## end emscommand::AuthorizationFlagCommand%4AC36A1B00E6.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::AuthorizationFlagCommand%4AC36A1B00E6.protected preserve=yes
      //## end emscommand::AuthorizationFlagCommand%4AC36A1B00E6.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::AuthorizationFlagCommand%4AC36A1B00E6.private preserve=yes
      //## end emscommand::AuthorizationFlagCommand%4AC36A1B00E6.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4AC36FD00032
      //## Role: AuthorizationFlagCommand::<m_pPrimaryKeySegment>%4AC36FD002F1
      //## begin emscommand::AuthorizationFlagCommand::<m_pPrimaryKeySegment>%4AC36FD002F1.role preserve=no  public: segment::PrimaryKeySegment { -> RFHgN}
      segment::PrimaryKeySegment *m_pPrimaryKeySegment;
      //## end emscommand::AuthorizationFlagCommand::<m_pPrimaryKeySegment>%4AC36FD002F1.role

    // Additional Implementation Declarations
      //## begin emscommand::AuthorizationFlagCommand%4AC36A1B00E6.implementation preserve=yes
      //## end emscommand::AuthorizationFlagCommand%4AC36A1B00E6.implementation

};

//## begin emscommand::AuthorizationFlagCommand%4AC36A1B00E6.postscript preserve=yes
//## end emscommand::AuthorizationFlagCommand%4AC36A1B00E6.postscript

} // namespace emscommand

//## begin module%4AC36A6602AB.epilog preserve=yes
//## end module%4AC36A6602AB.epilog


#endif
