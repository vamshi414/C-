//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%373453BF02A6.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%373453BF02A6.cm

//## begin module%373453BF02A6.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%373453BF02A6.cp

//## Module: CXOSEC08%373453BF02A6; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Pvcswork\Dn\Server\Library\Ecdll\CXODEC08.hpp

#ifndef CXOSEC08_h
#define CXOSEC08_h 1

//## begin module%373453BF02A6.additionalIncludes preserve=no
//## end module%373453BF02A6.additionalIncludes

//## begin module%373453BF02A6.includes preserve=yes
// $Date:   Apr 09 2004 12:32:52  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%373453BF02A6.includes

#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseCommentSegment;
} // namespace emssegment

//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: DataNavigator Foundation::UserSegment_CAT%394E272B01EC
namespace usersegment {
class RelationshipSegment;
} // namespace usersegment

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Row;
} // namespace reusable

//## Modelname: Connex Foundation::Segment_CAT%3471F0BE0219
namespace segment {
class PrimaryKeySegment;
} // namespace segment

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Message;

} // namespace IF

//## begin module%373453BF02A6.declarations preserve=no
//## end module%373453BF02A6.declarations

//## begin module%373453BF02A6.additionalDeclarations preserve=yes
//## end module%373453BF02A6.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseCommentListCommand%37344FDA0053.preface preserve=yes
//## end emscommand::CaseCommentListCommand%37344FDA0053.preface

//## Class: CaseCommentListCommand%37344FDA0053
//	QEMLCOM - retrieve the comments for an EMS case.
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3736E60B03B0;IF::Message { -> F}
//## Uses: <unnamed>%3738582503AB;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%378CE1BE00C2;emssegment::CaseCommentSegment { -> F}
//## Uses: <unnamed>%37F0E144028E;usersegment::RelationshipSegment { -> F}
//## Uses: <unnamed>%39525322037A;reusable::Row { -> F}
//## Uses: <unnamed>%395277CA0310;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3A01BA6A002D;monitor::UseCase { -> F}

class DllExport CaseCommentListCommand : public command::ClientListCommand  //## Inherits: <unnamed>%39525ADC022A
{
  //## begin emscommand::CaseCommentListCommand%37344FDA0053.initialDeclarations preserve=yes
  //## end emscommand::CaseCommentListCommand%37344FDA0053.initialDeclarations

  public:
    //## Constructors (generated)
      CaseCommentListCommand();

    //## Constructors (specified)
      //## Operation: CaseCommentListCommand%37345E7C0281
      CaseCommentListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseCommentListCommand();


    //## Other Operations (specified)
      //## Operation: retrieve%395233B80268
      virtual bool retrieve ();

      //## Operation: update%37345EA1032E
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::CaseCommentListCommand%37344FDA0053.public preserve=yes
      //## end emscommand::CaseCommentListCommand%37344FDA0053.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::CaseCommentListCommand%37344FDA0053.protected preserve=yes
      //## end emscommand::CaseCommentListCommand%37344FDA0053.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseCommentListCommand%37344FDA0053.private preserve=yes
      //## end emscommand::CaseCommentListCommand%37344FDA0053.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%39524D710393
      //## begin emscommand::CaseCommentListCommand::Buffer%39524D710393.attr preserve=no  private: char* {U} 
      char* m_pszBuffer;
      //## end emscommand::CaseCommentListCommand::Buffer%39524D710393.attr

    // Data Members for Associations

      //## Association: Connex Foundation::Command_CAT::<unnamed>%373856DC00CD
      //## Role: CaseCommentListCommand::<m_pPrimaryKeySegment>%373856DC0268
      //## begin emscommand::CaseCommentListCommand::<m_pPrimaryKeySegment>%373856DC0268.role preserve=no  public: segment::PrimaryKeySegment { -> RFHgN}
      segment::PrimaryKeySegment *m_pPrimaryKeySegment;
      //## end emscommand::CaseCommentListCommand::<m_pPrimaryKeySegment>%373856DC0268.role

    // Additional Implementation Declarations
      //## begin emscommand::CaseCommentListCommand%37344FDA0053.implementation preserve=yes
      //## end emscommand::CaseCommentListCommand%37344FDA0053.implementation

};

//## begin emscommand::CaseCommentListCommand%37344FDA0053.postscript preserve=yes
//## end emscommand::CaseCommentListCommand%37344FDA0053.postscript

} // namespace emscommand

//## begin module%373453BF02A6.epilog preserve=yes
using namespace emscommand;
//## end module%373453BF02A6.epilog


#endif
