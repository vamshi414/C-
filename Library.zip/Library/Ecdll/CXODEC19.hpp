//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40570F1302CE.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40570F1302CE.cm

//## begin module%40570F1302CE.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40570F1302CE.cp

//## Module: CXOSEC19%40570F1302CE; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC19.hpp

#ifndef CXOSEC19_h
#define CXOSEC19_h 1

//## begin module%40570F1302CE.additionalIncludes preserve=no
//## end module%40570F1302CE.additionalIncludes

//## begin module%40570F1302CE.includes preserve=yes
//## end module%40570F1302CE.includes

#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif
//## begin module%40570F1302CE.declarations preserve=no
//## end module%40570F1302CE.declarations

//## begin module%40570F1302CE.additionalDeclarations preserve=yes
//## end module%40570F1302CE.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseClientAccountingListCommand%40570F85029F.preface preserve=yes
//## end emscommand::CaseClientAccountingListCommand%40570F85029F.preface

//## Class: CaseClientAccountingListCommand%40570F85029F
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40571B5500DA;IF::Message { -> F}
//## Uses: <unnamed>%40571B6501B5;monitor::UseCase { -> F}
//## Uses: <unnamed>%40571B700186;emssegment::CaseAccountHistorySegment { -> F}
//## Uses: <unnamed>%40571BC201C5;segment::InformationSegment { -> F}
//## Uses: <unnamed>%40646E5403B9;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%40646E57008C;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%406C3CD603D8;ems::Case { -> F}
//## Uses: <unnamed>%407A97C30261;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%407A9879004E;reusable::Row { -> F}

class DllExport CaseClientAccountingListCommand : public command::ClientListCommand  //## Inherits: <unnamed>%407A9802035B
{
  //## begin emscommand::CaseClientAccountingListCommand%40570F85029F.initialDeclarations preserve=yes
  //## end emscommand::CaseClientAccountingListCommand%40570F85029F.initialDeclarations

  public:
    //## Constructors (generated)
      CaseClientAccountingListCommand();

    //## Constructors (specified)
      //## Operation: CaseClientAccountingListCommand%40570FFB0280
      CaseClientAccountingListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseClientAccountingListCommand();


    //## Other Operations (specified)
      //## Operation: update%407A92BE02EE
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::CaseClientAccountingListCommand%40570F85029F.public preserve=yes
      //## end emscommand::CaseClientAccountingListCommand%40570F85029F.public

  protected:

    //## Other Operations (specified)
      //## Operation: retrieve%407A92BE02DE
      virtual bool retrieve ();

    // Data Members for Class Attributes

      //## Attribute: szBuffer%407A9850000F
      //## begin emscommand::CaseClientAccountingListCommand::szBuffer%407A9850000F.attr preserve=no  public: char* {U} 
      char* m_pszBuffer;
      //## end emscommand::CaseClientAccountingListCommand::szBuffer%407A9850000F.attr

    // Additional Protected Declarations
      //## begin emscommand::CaseClientAccountingListCommand%40570F85029F.protected preserve=yes
      //## end emscommand::CaseClientAccountingListCommand%40570F85029F.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseClientAccountingListCommand%40570F85029F.private preserve=yes
      //## end emscommand::CaseClientAccountingListCommand%40570F85029F.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin emscommand::CaseClientAccountingListCommand%40570F85029F.implementation preserve=yes
      //## end emscommand::CaseClientAccountingListCommand%40570F85029F.implementation

};

//## begin emscommand::CaseClientAccountingListCommand%40570F85029F.postscript preserve=yes
//## end emscommand::CaseClientAccountingListCommand%40570F85029F.postscript

} // namespace emscommand

//## begin module%40570F1302CE.epilog preserve=yes
using namespace emscommand;
//## end module%40570F1302CE.epilog


#endif
