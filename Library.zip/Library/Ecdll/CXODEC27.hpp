//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4A379AF2008C.cm preserve=no
//	$Date:   Nov 16 2010 08:07:02  $ $Author:   e3002327  $
//	$Revision:   1.3  $
//## end module%4A379AF2008C.cm

//## begin module%4A379AF2008C.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4A379AF2008C.cp

//## Module: CXOSEC27%4A379AF2008C; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC27.hpp

#ifndef CXOSEC27_h
#define CXOSEC27_h 1

//## begin module%4A379AF2008C.additionalIncludes preserve=no
//## end module%4A379AF2008C.additionalIncludes

//## begin module%4A379AF2008C.includes preserve=yes
//## end module%4A379AF2008C.includes

#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif
#ifndef CXOSES57_h
#include "CXODES57.hpp"
#endif

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Row;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class PrimaryKeySegment;
class MultipleRowContextSegment;

} // namespace segment

//## begin module%4A379AF2008C.declarations preserve=no
//## end module%4A379AF2008C.declarations

//## begin module%4A379AF2008C.additionalDeclarations preserve=yes
//## end module%4A379AF2008C.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.preface preserve=yes
//## end emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.preface

//## Class: NetworkAvailableReasonCodeListCommand%4A379952037A
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4A37C3A8036B;IF::Extract { -> F}
//## Uses: <unnamed>%4A37C3D00157;monitor::UseCase { -> F}
//## Uses: <unnamed>%4A37C49003C8;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4A37C4D0034B;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4A37CBE00167;reusable::Row { -> F}
//## Uses: <unnamed>%4C6CC353011B;timer::Clock { -> F}

class DllExport NetworkAvailableReasonCodeListCommand : public command::ClientListCommand  //## Inherits: <unnamed>%4A379D92005D
{
  //## begin emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.initialDeclarations preserve=yes
  //## end emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.initialDeclarations

  public:
    //## Constructors (generated)
      NetworkAvailableReasonCodeListCommand();

    //## Constructors (specified)
      //## Operation: NetworkAvailableReasonCodeListCommand%4A37A15101F4
      NetworkAvailableReasonCodeListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~NetworkAvailableReasonCodeListCommand();


    //## Other Operations (specified)
      //## Operation: determineRULE_SET_ID%4A78705C0286
      int determineRULE_SET_ID (const string& strCUST_ID);

      //## Operation: determineBaseRULE_SET_ID%4A786F28018E
      string determineBaseRULE_SET_ID (const string& strRULE_SET_ID);

      //## Operation: determineNetworkRules%4A786E390160
      int determineNetworkRules (const string& strCUST_ID, const string& strNetworkName, const string& strUserRole);

      //## Operation: update%4A37B1A80399
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.public preserve=yes
      //## end emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.public

  protected:

    //## Other Operations (specified)
      //## Operation: retrieve%4A37A4640213
      virtual bool retrieve ();

    // Additional Protected Declarations
      //## begin emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.protected preserve=yes
      //## end emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.private preserve=yes
      //## end emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%4A37B23A0251
      //## begin emscommand::NetworkAvailableReasonCodeListCommand::Buffer%4A37B23A0251.attr preserve=no  private: char* {U} 0
      char* m_pszBuffer;
      //## end emscommand::NetworkAvailableReasonCodeListCommand::Buffer%4A37B23A0251.attr

      //## Attribute: DESCRIPTION_TEXT%4A37D2C8004E
      //## begin emscommand::NetworkAvailableReasonCodeListCommand::DESCRIPTION_TEXT%4A37D2C8004E.attr preserve=no  private: string {U} 
      string m_strDESCRIPTION_TEXT;
      //## end emscommand::NetworkAvailableReasonCodeListCommand::DESCRIPTION_TEXT%4A37D2C8004E.attr

      //## Attribute: RESN_CODE_ID%4A37D2AB0232
      //## begin emscommand::NetworkAvailableReasonCodeListCommand::RESN_CODE_ID%4A37D2AB0232.attr preserve=no  private: string {U} 
      string m_strRESN_CODE_ID;
      //## end emscommand::NetworkAvailableReasonCodeListCommand::RESN_CODE_ID%4A37D2AB0232.attr

      //## Attribute: RULE_SET_ID%4A7872FF02C0
      //## begin emscommand::NetworkAvailableReasonCodeListCommand::RULE_SET_ID%4A7872FF02C0.attr preserve=no  private: string {U} 
      string m_strRULE_SET_ID;
      //## end emscommand::NetworkAvailableReasonCodeListCommand::RULE_SET_ID%4A7872FF02C0.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4A37A2E002DE
      //## Role: NetworkAvailableReasonCodeListCommand::<m_pPrimaryKeySegment>%4A37A2E101A5
      //## begin emscommand::NetworkAvailableReasonCodeListCommand::<m_pPrimaryKeySegment>%4A37A2E101A5.role preserve=no  public: segment::PrimaryKeySegment { -> RFHgN}
      segment::PrimaryKeySegment *m_pPrimaryKeySegment;
      //## end emscommand::NetworkAvailableReasonCodeListCommand::<m_pPrimaryKeySegment>%4A37A2E101A5.role

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4A37A409032C
      //## Role: NetworkAvailableReasonCodeListCommand::<m_hCaseReasonCodeSegment>%4A37A40A02AF
      //## begin emscommand::NetworkAvailableReasonCodeListCommand::<m_hCaseReasonCodeSegment>%4A37A40A02AF.role preserve=no  public: emssegment::CaseReasonCodeSegment { -> VHgN}
      emssegment::CaseReasonCodeSegment m_hCaseReasonCodeSegment;
      //## end emscommand::NetworkAvailableReasonCodeListCommand::<m_hCaseReasonCodeSegment>%4A37A40A02AF.role

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4A393B29030D
      //## Role: NetworkAvailableReasonCodeListCommand::<m_pMultipleRowContextSegment>%4A393B2A029F
      //## begin emscommand::NetworkAvailableReasonCodeListCommand::<m_pMultipleRowContextSegment>%4A393B2A029F.role preserve=no  public: segment::MultipleRowContextSegment { -> RFHgN}
      segment::MultipleRowContextSegment *m_pMultipleRowContextSegment;
      //## end emscommand::NetworkAvailableReasonCodeListCommand::<m_pMultipleRowContextSegment>%4A393B2A029F.role

    // Additional Implementation Declarations
      //## begin emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.implementation preserve=yes
      string m_strNETWORK_RULES;
      //## end emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.implementation
};

//## begin emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.postscript preserve=yes
//## end emscommand::NetworkAvailableReasonCodeListCommand%4A379952037A.postscript

} // namespace emscommand

//## begin module%4A379AF2008C.epilog preserve=yes
//## end module%4A379AF2008C.epilog


#endif
