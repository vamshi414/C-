//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%37A6F27500BB.cm preserve=no
//	$Date:   Jan 25 2016 12:00:42  $ $Author:   e1009591  $
//	$Revision:   1.6  $
//## end module%37A6F27500BB.cm

//## begin module%37A6F27500BB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%37A6F27500BB.cp

//## Module: CXOSEC09%37A6F27500BB; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\bV02.5B.R011\Windows\Build\Dn\Server\Library\Ecdll\CXODEC09.hpp

#ifndef CXOSEC09_h
#define CXOSEC09_h 1

//## begin module%37A6F27500BB.additionalIncludes preserve=no
//## end module%37A6F27500BB.additionalIncludes

//## begin module%37A6F27500BB.includes preserve=yes
// $Date:   Jan 25 2016 12:00:42  $ $Author:   e1009591  $ $Revision:   1.6  $
//## end module%37A6F27500BB.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif
#ifndef CXOSVS18_h
#include "CXODVS18.hpp"
#endif
#ifndef CXOSVS01_h
#include "CXODVS01.hpp"
#endif
#ifndef CXOSVS02_h
#include "CXODVS02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class PrimaryKeySegment;
class ListSegment;
class CommonHeaderSegment;

} // namespace segment

//## begin module%37A6F27500BB.declarations preserve=no
//## end module%37A6F27500BB.declarations

//## begin module%37A6F27500BB.additionalDeclarations preserve=yes
//## end module%37A6F27500BB.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseWorkQueueListCommand%37A6E040020E.preface preserve=yes
//## end emscommand::CaseWorkQueueListCommand%37A6E040020E.preface

//## Class: CaseWorkQueueListCommand%37A6E040020E
//	QEMLWRKQ - retrieve the list of work queues that an EMS
//	case is currently on.
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%37B2F21A0013;segment::InformationSegment { -> F}
//## Uses: <unnamed>%37B2F26401DC;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%37B2F2A101D9;IF::Message { -> F}
//## Uses: <unnamed>%37B2F2B8029B;segment::ListSegment { -> F}
//## Uses: <unnamed>%37B2F2E8009B;reusable::Query { -> F}
//## Uses: <unnamed>%37B2F2EC00AB;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%37B2F41F025B;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%37B2F4FB0094;database::Database { -> F}
//## Uses: <unnamed>%3A42640201FC;monitor::UseCase { -> F}

class DllExport CaseWorkQueueListCommand : public command::ClientCommand  //## Inherits: <unnamed>%37A6E060014B
{
  //## begin emscommand::CaseWorkQueueListCommand%37A6E040020E.initialDeclarations preserve=yes
  //## end emscommand::CaseWorkQueueListCommand%37A6E040020E.initialDeclarations

  public:
    //## Constructors (generated)
      CaseWorkQueueListCommand();

    //## Constructors (specified)
      //## Operation: CaseWorkQueueListCommand%37A701790285
      CaseWorkQueueListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseWorkQueueListCommand();


    //## Other Operations (specified)
      //## Operation: execute%37A701930138
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%37A701950131
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::CaseWorkQueueListCommand%37A6E040020E.public preserve=yes
      //## end emscommand::CaseWorkQueueListCommand%37A6E040020E.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::CaseWorkQueueListCommand%37A6E040020E.protected preserve=yes
      //## end emscommand::CaseWorkQueueListCommand%37A6E040020E.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseWorkQueueListCommand%37A6E040020E.private preserve=yes
      //## end emscommand::CaseWorkQueueListCommand%37A6E040020E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CASE_ID%37B2F31A0274
      //## begin emscommand::CaseWorkQueueListCommand::CASE_ID%37B2F31A0274.attr preserve=no  private: int {U} 0
      int m_lCASE_ID;
      //## end emscommand::CaseWorkQueueListCommand::CASE_ID%37B2F31A0274.attr

      //## Attribute: Count%37B2F49C0002
      //## begin emscommand::CaseWorkQueueListCommand::Count%37B2F49C0002.attr preserve=no  private: int {U} 0
      int m_iCount;
      //## end emscommand::CaseWorkQueueListCommand::Count%37B2F49C0002.attr

      //## Attribute: Queues%37B2F47D0011
      //## begin emscommand::CaseWorkQueueListCommand::Queues%37B2F47D0011.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hQueues;
      //## end emscommand::CaseWorkQueueListCommand::Queues%37B2F47D0011.attr

      //## Attribute: Query%37B2F32D00CC
      //## begin emscommand::CaseWorkQueueListCommand::Query%37B2F32D00CC.attr preserve=no  private: int  {U} 0
      int  m_iQuery;
      //## end emscommand::CaseWorkQueueListCommand::Query%37B2F32D00CC.attr

      //## Attribute: AccessDenied%386BCECE0166
      //## begin emscommand::CaseWorkQueueListCommand::AccessDenied%386BCECE0166.attr preserve=no  private: bool {U} false
      bool m_bAccessDenied;
      //## end emscommand::CaseWorkQueueListCommand::AccessDenied%386BCECE0166.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%37B2F20302B8
      //## Role: CaseWorkQueueListCommand::<m_pPrimaryKeySegment>%37B2F20500EF
      //## begin emscommand::CaseWorkQueueListCommand::<m_pPrimaryKeySegment>%37B2F20500EF.role preserve=no  public: segment::PrimaryKeySegment { -> RFHgN}
      segment::PrimaryKeySegment *m_pPrimaryKeySegment;
      //## end emscommand::CaseWorkQueueListCommand::<m_pPrimaryKeySegment>%37B2F20500EF.role

      //## Association: Connex Library::Command_CAT::<unnamed>%386BCDDF023F
      //## Role: CaseWorkQueueListCommand::<m_hWorkQueue>%386BCDE10116
      //## begin emscommand::CaseWorkQueueListCommand::<m_hWorkQueue>%386BCDE10116.role preserve=no  public: viewsegment::WorkQueue { -> VHgN}
      viewsegment::WorkQueue m_hWorkQueue;
      //## end emscommand::CaseWorkQueueListCommand::<m_hWorkQueue>%386BCDE10116.role

      //## Association: Connex Library::Command_CAT::<unnamed>%386BCE4C020A
      //## Role: CaseWorkQueueListCommand::<m_hWorkQueueSegment>%386BCE4D01A7
      //## begin emscommand::CaseWorkQueueListCommand::<m_hWorkQueueSegment>%386BCE4D01A7.role preserve=no  public: viewsegment::WorkQueueSegment { -> VHgN}
      viewsegment::WorkQueueSegment m_hWorkQueueSegment;
      //## end emscommand::CaseWorkQueueListCommand::<m_hWorkQueueSegment>%386BCE4D01A7.role

      //## Association: Connex Library::Command_CAT::<unnamed>%386BCE5401BB
      //## Role: CaseWorkQueueListCommand::<m_hWorkQueueUserSegment>%386BCE560060
      //## begin emscommand::CaseWorkQueueListCommand::<m_hWorkQueueUserSegment>%386BCE560060.role preserve=no  public: viewsegment::WorkQueueUserSegment { -> VHgN}
      viewsegment::WorkQueueUserSegment m_hWorkQueueUserSegment;
      //## end emscommand::CaseWorkQueueListCommand::<m_hWorkQueueUserSegment>%386BCE560060.role

    // Additional Implementation Declarations
      //## begin emscommand::CaseWorkQueueListCommand%37A6E040020E.implementation preserve=yes
      //## end emscommand::CaseWorkQueueListCommand%37A6E040020E.implementation

};

//## begin emscommand::CaseWorkQueueListCommand%37A6E040020E.postscript preserve=yes
//## end emscommand::CaseWorkQueueListCommand%37A6E040020E.postscript

} // namespace emscommand

//## begin module%37A6F27500BB.epilog preserve=yes
using namespace emscommand;
//## end module%37A6F27500BB.epilog


#endif
