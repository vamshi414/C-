//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E8C90B201F4.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E8C90B201F4.cm

//## begin module%3E8C90B201F4.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3E8C90B201F4.cp

//## Module: CXOSEC14%3E8C90B201F4; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC14.hpp

#ifndef CXOSEC14_h
#define CXOSEC14_h 1

//## begin module%3E8C90B201F4.additionalIncludes preserve=no
//## end module%3E8C90B201F4.additionalIncludes

//## begin module%3E8C90B201F4.includes preserve=yes
// $Date:   Apr 09 2004 12:57:36  $ $Author:   D02405  $ $Revision:   1.4  $
//## end module%3E8C90B201F4.includes

#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class Case;
} // namespace ems

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class PrimaryKeySegment;
class ListSegment;

} // namespace segment

//## begin module%3E8C90B201F4.declarations preserve=no
//## end module%3E8C90B201F4.declarations

//## begin module%3E8C90B201F4.additionalDeclarations preserve=yes
//## end module%3E8C90B201F4.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::ActionDetailListCommand%3E8C911F0128.preface preserve=yes
//## end emscommand::ActionDetailListCommand%3E8C911F0128.preface

//## Class: ActionDetailListCommand%3E8C911F0128
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E8C91C700EA;reusable::Row { -> F}
//## Uses: <unnamed>%3E8C91D70138;segment::PrimaryKeySegment { -> F}
//## Uses: <unnamed>%3E8C927F0222;monitor::UseCase { -> F}
//## Uses: <unnamed>%3E8C938E0290;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%3E8C9392004E;emssegment::CaseNetworkUniqueSegment { -> F}
//## Uses: <unnamed>%3E8C939401A5;emssegment::CaseNationalNetworkSegment { -> F}
//## Uses: <unnamed>%3E8C93960261;emssegment::CasePhaseNetworkUniqueSegment { -> F}
//## Uses: <unnamed>%3E8C939802AF;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%3E8C954D02FD;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%3ED6348702EE;ems::Case { -> F}

class DllExport ActionDetailListCommand : public command::ClientListCommand  //## Inherits: <unnamed>%3E8C914000FA
{
  //## begin emscommand::ActionDetailListCommand%3E8C911F0128.initialDeclarations preserve=yes
  //## end emscommand::ActionDetailListCommand%3E8C911F0128.initialDeclarations

  public:
    //## Constructors (generated)
      ActionDetailListCommand();

    //## Constructors (specified)
      //## Operation: ActionDetailListCommand%3E8C92D4004E
      ActionDetailListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~ActionDetailListCommand();


    //## Other Operations (specified)
      //## Operation: update%3E8C91940251
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::ActionDetailListCommand%3E8C911F0128.public preserve=yes
      //## end emscommand::ActionDetailListCommand%3E8C911F0128.public

  protected:

    //## Other Operations (specified)
      //## Operation: retrieve%3E8C9198029F
      virtual bool retrieve ();

    // Data Members for Class Attributes

      //## Attribute: szBuffer%3E8C92A00000
      //## begin emscommand::ActionDetailListCommand::szBuffer%3E8C92A00000.attr preserve=no  public: char* {U} 
      char* m_pszBuffer;
      //## end emscommand::ActionDetailListCommand::szBuffer%3E8C92A00000.attr

    // Additional Protected Declarations
      //## begin emscommand::ActionDetailListCommand%3E8C911F0128.protected preserve=yes
      //## end emscommand::ActionDetailListCommand%3E8C911F0128.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::ActionDetailListCommand%3E8C911F0128.private preserve=yes
      //## end emscommand::ActionDetailListCommand%3E8C911F0128.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%3E8C9485035B
      //## Role: ActionDetailListCommand::<m_pPrimaryKeySegment>%3E8C948601A5
      //## begin emscommand::ActionDetailListCommand::<m_pPrimaryKeySegment>%3E8C948601A5.role preserve=no  public: segment::PrimaryKeySegment { -> RFHgN}
      segment::PrimaryKeySegment *m_pPrimaryKeySegment;
      //## end emscommand::ActionDetailListCommand::<m_pPrimaryKeySegment>%3E8C948601A5.role

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%406D85CD02AF
      //## Role: ActionDetailListCommand::<m_pListSegment>%406D85CE00FA
      //## begin emscommand::ActionDetailListCommand::<m_pListSegment>%406D85CE00FA.role preserve=no  public: segment::ListSegment { -> RFHgN}
      segment::ListSegment *m_pListSegment;
      //## end emscommand::ActionDetailListCommand::<m_pListSegment>%406D85CE00FA.role

    // Additional Implementation Declarations
      //## begin emscommand::ActionDetailListCommand%3E8C911F0128.implementation preserve=yes
      //## end emscommand::ActionDetailListCommand%3E8C911F0128.implementation

};

//## begin emscommand::ActionDetailListCommand%3E8C911F0128.postscript preserve=yes
//## end emscommand::ActionDetailListCommand%3E8C911F0128.postscript

} // namespace emscommand

//## begin module%3E8C90B201F4.epilog preserve=yes
//## end module%3E8C90B201F4.epilog


#endif
