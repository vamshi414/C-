//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4A563A0501C5.cm preserve=no
//	$Date:   Aug 25 2009 12:17:02  $ $Author:   E1024360  $
//	$Revision:   1.1  $
//## end module%4A563A0501C5.cm

//## begin module%4A563A0501C5.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%4A563A0501C5.cp

//## Module: CXOSEC28%4A563A0501C5; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC28.hpp

#ifndef CXOSEC28_h
#define CXOSEC28_h 1

//## begin module%4A563A0501C5.additionalIncludes preserve=no
//## end module%4A563A0501C5.additionalIncludes

//## begin module%4A563A0501C5.includes preserve=yes
#define STS_MISSING_CARDHOLDER_SEGMENT 405
//## end module%4A563A0501C5.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class CardholderInformationSegment;
} // namespace repositorysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
} // namespace segment

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

namespace segment {
class ResponseTimeSegment;
class InformationSegment;

} // namespace segment

//## begin module%4A563A0501C5.declarations preserve=no
//## end module%4A563A0501C5.declarations

//## begin module%4A563A0501C5.additionalDeclarations preserve=yes
//## end module%4A563A0501C5.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseCardholderUpdateCommand%4A5639A703B9.preface preserve=yes
//## end emscommand::CaseCardholderUpdateCommand%4A5639A703B9.preface

//## Class: CaseCardholderUpdateCommand%4A5639A703B9
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4A56426E0109;segment::InformationSegment { -> F}
//## Uses: <unnamed>%4A56452300EA;monitor::UseCase { -> F}
//## Uses: <unnamed>%4A5645400128;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%4A5645700157;reusable::Query { -> F}
//## Uses: <unnamed>%4A56458E0109;reusable::Table { -> F}
//## Uses: <unnamed>%4A56459701C5;reusable::Statement { -> F}
//## Uses: <unnamed>%4A5645BD01B5;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4A56464E007D;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4A5741F0033C;IF::Message { -> F}
//## Uses: <unnamed>%4A57426D0399;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%4A93E54B0237;reusable::Transaction { -> F}

class DllExport CaseCardholderUpdateCommand : public command::ClientCommand  //## Inherits: <unnamed>%4A56411D0280
{
  //## begin emscommand::CaseCardholderUpdateCommand%4A5639A703B9.initialDeclarations preserve=yes
  //## end emscommand::CaseCardholderUpdateCommand%4A5639A703B9.initialDeclarations

  public:
    //## Constructors (generated)
      CaseCardholderUpdateCommand();

    //## Constructors (specified)
      //## Operation: CaseCardholderUpdateCommand%4A56413F0167
      CaseCardholderUpdateCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseCardholderUpdateCommand();


    //## Other Operations (specified)
      //## Operation: execute%4A56417F0290
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: insert%4A56419301A5
      bool insert ();

    // Additional Public Declarations
      //## begin emscommand::CaseCardholderUpdateCommand%4A5639A703B9.public preserve=yes
      //## end emscommand::CaseCardholderUpdateCommand%4A5639A703B9.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::CaseCardholderUpdateCommand%4A5639A703B9.protected preserve=yes
      //## end emscommand::CaseCardholderUpdateCommand%4A5639A703B9.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseCardholderUpdateCommand%4A5639A703B9.private preserve=yes
      //## end emscommand::CaseCardholderUpdateCommand%4A5639A703B9.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4A56434E035B
      //## Role: CaseCardholderUpdateCommand::<m_pCardholderInformationSegment>%4A56434F0261
      //## begin emscommand::CaseCardholderUpdateCommand::<m_pCardholderInformationSegment>%4A56434F0261.role preserve=no  public: repositorysegment::CardholderInformationSegment { -> RFHgN}
      repositorysegment::CardholderInformationSegment *m_pCardholderInformationSegment;
      //## end emscommand::CaseCardholderUpdateCommand::<m_pCardholderInformationSegment>%4A56434F0261.role

    // Additional Implementation Declarations
      //## begin emscommand::CaseCardholderUpdateCommand%4A5639A703B9.implementation preserve=yes
      //## end emscommand::CaseCardholderUpdateCommand%4A5639A703B9.implementation

};

//## begin emscommand::CaseCardholderUpdateCommand%4A5639A703B9.postscript preserve=yes
//## end emscommand::CaseCardholderUpdateCommand%4A5639A703B9.postscript

} // namespace emscommand

//## begin module%4A563A0501C5.epilog preserve=yes
//## end module%4A563A0501C5.epilog


#endif
