//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3E8B114601F4.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E8B114601F4.cm

//## begin module%3E8B114601F4.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3E8B114601F4.cp

//## Module: CXOSEC13%3E8B114601F4; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC13.hpp

#ifndef CXOSEC13_h
#define CXOSEC13_h 1

//## begin module%3E8B114601F4.additionalIncludes preserve=no
//## end module%3E8B114601F4.additionalIncludes

//## begin module%3E8B114601F4.includes preserve=yes
// $Date:   Apr 09 2004 12:32:48  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%3E8B114601F4.includes

#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Row;
} // namespace reusable

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class Case;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CasePhaseSegment;
class CaseSegment;
class CasePhaseNetworkUniqueSegment;
class CaseNetworkUniqueSegment;
class CaseNationalNetworkSegment;

} // namespace emssegment

//## begin module%3E8B114601F4.declarations preserve=no
//## end module%3E8B114601F4.declarations

//## begin module%3E8B114601F4.additionalDeclarations preserve=yes
//## end module%3E8B114601F4.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.preface preserve=yes
//## end emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.preface

//## Class: CaseAvailableReasonCodeListCommand%3E8B11F102BF
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E8B1217029F;monitor::UseCase { -> F}
//## Uses: <unnamed>%3E8B121901C5;reusable::Row { -> F}
//## Uses: <unnamed>%3E8B121F00AB;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%3E8B12220251;emssegment::CaseNetworkUniqueSegment { -> F}
//## Uses: <unnamed>%3E8B122402FD;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%3E8B1226031C;emssegment::CaseNationalNetworkSegment { -> F}
//## Uses: <unnamed>%3E8B1229003E;emssegment::CasePhaseNetworkUniqueSegment { -> F}
//## Uses: <unnamed>%3E8B16080109;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%3ED6346800EA;ems::Case { -> F}

class DllExport CaseAvailableReasonCodeListCommand : public command::ClientListCommand  //## Inherits: <unnamed>%3E8B1208030D
{
  //## begin emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.initialDeclarations preserve=yes
  //## end emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.initialDeclarations

  public:
    //## Constructors (generated)
      CaseAvailableReasonCodeListCommand();

    //## Constructors (specified)
      //## Operation: CaseAvailableReasonCodeListCommand%3E8B131200BB
      CaseAvailableReasonCodeListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseAvailableReasonCodeListCommand();


    //## Other Operations (specified)
      //## Operation: update%3E8C8E370109
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.public preserve=yes
      //## end emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.public

  protected:

    //## Other Operations (specified)
      //## Operation: retrieve%3E8B131200CB
      virtual bool retrieve ();

    // Data Members for Class Attributes

      //## Attribute: szBuffer%3E8B130901C5
      //## begin emscommand::CaseAvailableReasonCodeListCommand::szBuffer%3E8B130901C5.attr preserve=no  public: char* {U} 
      char* m_pszBuffer;
      //## end emscommand::CaseAvailableReasonCodeListCommand::szBuffer%3E8B130901C5.attr

    // Additional Protected Declarations
      //## begin emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.protected preserve=yes
      //## end emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.private preserve=yes
      //## end emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.implementation preserve=yes
      //## end emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.implementation

};

//## begin emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.postscript preserve=yes
//## end emscommand::CaseAvailableReasonCodeListCommand%3E8B11F102BF.postscript

} // namespace emscommand

//## begin module%3E8B114601F4.epilog preserve=yes
//## end module%3E8B114601F4.epilog


#endif
