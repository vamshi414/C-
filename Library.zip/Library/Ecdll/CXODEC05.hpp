//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%373452E7022D.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%373452E7022D.cm

//## begin module%373452E7022D.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%373452E7022D.cp

//## Module: CXOSEC05%373452E7022D; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC05.hpp

#ifndef CXOSEC05_h
#define CXOSEC05_h 1

//## begin module%373452E7022D.additionalIncludes preserve=no
//## end module%373452E7022D.additionalIncludes

//## begin module%373452E7022D.includes preserve=yes
// $Date:   Apr 09 2004 12:32:44  $ $Author:   D02405  $ $Revision:   1.7  $
//## end module%373452E7022D.includes

#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Row;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
class PersistentSegment;
class InformationSegment;
class ResponseTimeSegment;
class PrimaryKeySegment;

} // namespace segment

//## begin module%373452E7022D.declarations preserve=no
//## end module%373452E7022D.declarations

//## begin module%373452E7022D.additionalDeclarations preserve=yes
//## end module%373452E7022D.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseRulesDescriptionListCommand%37344F0F025A.preface preserve=yes
//## end emscommand::CaseRulesDescriptionListCommand%37344F0F025A.preface

//## Class: CaseRulesDescriptionListCommand%37344F0F025A
//	QEMLRULE - retrieve the ((phasees,statuses,actions) and
//	their descriptions) and the network list 3)
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3736E71201E2;database::Database { -> F}
//## Uses: <unnamed>%3736E71500C3;IF::Message { -> F}
//## Uses: <unnamed>%3738289101DB;segment::InformationSegment { -> F}
//## Uses: <unnamed>%3738289401B7;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%373829BF0077;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%37382A110309;reusable::Query { -> F}
//## Uses: <unnamed>%37382ADE0282;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%3A01B94302E6;monitor::UseCase { -> F}
//## Uses: <unnamed>%3E83160D02AF;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3E8B423603D8;segment::ListSegment { -> F}
//## Uses: <unnamed>%3E8C57B10242;reusable::Row { -> F}
//## Uses: <unnamed>%3E9EF4DB005D;ems::EMSNetRuleUse { -> F}
//## Uses: <unnamed>%3EA01A350232;ems::EMSNetRuleUseTable { -> F}

class DllExport CaseRulesDescriptionListCommand : public command::ClientListCommand  //## Inherits: <unnamed>%3E8B58A501A5
{
  //## begin emscommand::CaseRulesDescriptionListCommand%37344F0F025A.initialDeclarations preserve=yes
  //## end emscommand::CaseRulesDescriptionListCommand%37344F0F025A.initialDeclarations

  public:
    //## Constructors (generated)
      CaseRulesDescriptionListCommand();

    //## Constructors (specified)
      //## Operation: CaseRulesDescriptionListCommand%3E91BC6B0271
      CaseRulesDescriptionListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseRulesDescriptionListCommand();


    //## Other Operations (specified)
      //## Operation: import%4017DDB703A9
      //	Parse a command message into its individual segments.
      //## Semantics:
      //	1. Call Segment::reset for each segment in the
      //	collection.
      //	2. Parse the buffer by calling Segment::import for each
      //	segment that is present in the buffer.
      //	3. Return true if the parse is successful; else false.
      bool import (char** ppsBuffer);

      //## Operation: retrieve%37345BF6015F
      //	Perform the functions of this command.
      virtual bool retrieve ();

      //## Operation: update%37345BFB0153
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ID%3E9DFED100CB
      const string& getID () const
      {
        //## begin emscommand::CaseRulesDescriptionListCommand::getID%3E9DFED100CB.get preserve=no
        return m_strID;
        //## end emscommand::CaseRulesDescriptionListCommand::getID%3E9DFED100CB.get
      }

      void setID (const string& value)
      {
        //## begin emscommand::CaseRulesDescriptionListCommand::setID%3E9DFED100CB.set preserve=no
        m_strID = value;
        //## end emscommand::CaseRulesDescriptionListCommand::setID%3E9DFED100CB.set
      }


      //## Attribute: DESCRIPTION%3E9DFF0A0148
      const string& getDESCRIPTION () const
      {
        //## begin emscommand::CaseRulesDescriptionListCommand::getDESCRIPTION%3E9DFF0A0148.get preserve=no
        return m_strDESCRIPTION;
        //## end emscommand::CaseRulesDescriptionListCommand::getDESCRIPTION%3E9DFF0A0148.get
      }

      void setDESCRIPTION (const string& value)
      {
        //## begin emscommand::CaseRulesDescriptionListCommand::setDESCRIPTION%3E9DFF0A0148.set preserve=no
        m_strDESCRIPTION = value;
        //## end emscommand::CaseRulesDescriptionListCommand::setDESCRIPTION%3E9DFF0A0148.set
      }


    // Additional Public Declarations
      //## begin emscommand::CaseRulesDescriptionListCommand%37344F0F025A.public preserve=yes
      //## end emscommand::CaseRulesDescriptionListCommand%37344F0F025A.public

  protected:
    // Data Members for Class Attributes

      //## begin emscommand::CaseRulesDescriptionListCommand::ID%3E9DFED100CB.attr preserve=no  public: string {U} 
      string m_strID;
      //## end emscommand::CaseRulesDescriptionListCommand::ID%3E9DFED100CB.attr

      //## begin emscommand::CaseRulesDescriptionListCommand::DESCRIPTION%3E9DFF0A0148.attr preserve=no  public: string {U} 
      string m_strDESCRIPTION;
      //## end emscommand::CaseRulesDescriptionListCommand::DESCRIPTION%3E9DFF0A0148.attr

    // Additional Protected Declarations
      //## begin emscommand::CaseRulesDescriptionListCommand%37344F0F025A.protected preserve=yes
      //## end emscommand::CaseRulesDescriptionListCommand%37344F0F025A.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseRulesDescriptionListCommand%37344F0F025A.private preserve=yes
      //## end emscommand::CaseRulesDescriptionListCommand%37344F0F025A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: szBuffer%3E8C506D00CB
      //## begin emscommand::CaseRulesDescriptionListCommand::szBuffer%3E8C506D00CB.attr preserve=no  private: char* {U} 
      char* m_pszBuffer;
      //## end emscommand::CaseRulesDescriptionListCommand::szBuffer%3E8C506D00CB.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%3E8B4278001F
      //## Role: CaseRulesDescriptionListCommand::<m_hGenericSegment>%3E8B42780261
      //## begin emscommand::CaseRulesDescriptionListCommand::<m_hGenericSegment>%3E8B42780261.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end emscommand::CaseRulesDescriptionListCommand::<m_hGenericSegment>%3E8B42780261.role

      //## Association: Connex Library::Command_CAT::<unnamed>%37381C0F024F
      //## Role: CaseRulesDescriptionListCommand::<m_pPrimaryKeySegment>%37381C100110
      //## begin emscommand::CaseRulesDescriptionListCommand::<m_pPrimaryKeySegment>%37381C100110.role preserve=no  public: segment::PrimaryKeySegment { -> RFHgN}
      segment::PrimaryKeySegment *m_pPrimaryKeySegment;
      //## end emscommand::CaseRulesDescriptionListCommand::<m_pPrimaryKeySegment>%37381C100110.role

      //## Association: Connex Library::Command_CAT::<unnamed>%37CB213602B5
      //## Role: CaseRulesDescriptionListCommand::<m_pPersistentSegment>%37CB2137019E
      //## begin emscommand::CaseRulesDescriptionListCommand::<m_pPersistentSegment>%37CB2137019E.role preserve=no  public: segment::PersistentSegment { -> RFHgN}
      segment::PersistentSegment *m_pPersistentSegment;
      //## end emscommand::CaseRulesDescriptionListCommand::<m_pPersistentSegment>%37CB2137019E.role

    // Additional Implementation Declarations
      //## begin emscommand::CaseRulesDescriptionListCommand%37344F0F025A.implementation preserve=yes
      //## end emscommand::CaseRulesDescriptionListCommand%37344F0F025A.implementation

};

//## begin emscommand::CaseRulesDescriptionListCommand%37344F0F025A.postscript preserve=yes
//## end emscommand::CaseRulesDescriptionListCommand%37344F0F025A.postscript

} // namespace emscommand

//## begin module%373452E7022D.epilog preserve=yes
using namespace emscommand;
//## end module%373452E7022D.epilog


#endif
