//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%53188D500144.cm preserve=no
//	$Date:   May 29 2020 01:44:28  $ $Author:   e3028298  $
//	$Revision:   1.2  $
//## end module%53188D500144.cm

//## begin module%53188D500144.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%53188D500144.cp

//## Module: CXOSEC30%53188D500144; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: D:\Devel\V03.1A.R002\Dn\Server\Library\Ecdll\CXODEC30.hpp

#ifndef CXOSEC30_h
#define CXOSEC30_h 1

//## begin module%53188D500144.additionalIncludes preserve=no
//## end module%53188D500144.additionalIncludes

//## begin module%53188D500144.includes preserve=yes
//## end module%53188D500144.includes

#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseDocumentSegment;
class CasePhaseVisaVROLSegment;
class CaseSmartFormSegment;
} // namespace emssegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Row;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class PersistentSegment;
class InformationSegment;
class PrimaryKeySegment;
class CommonHeaderSegment;
} // namespace segment

namespace emssegment {
class CaseDocumentExtensionSegment;

} // namespace emssegment

//## begin module%53188D500144.declarations preserve=no
//## end module%53188D500144.declarations

//## begin module%53188D500144.additionalDeclarations preserve=yes
//## end module%53188D500144.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseDocumentListCommand%53188BD40042.preface preserve=yes
//## end emscommand::CaseDocumentListCommand%53188BD40042.preface

//## Class: CaseDocumentListCommand%53188BD40042
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%531DF99E02D3;database::Database { -> F}
//## Uses: <unnamed>%531EE10A0309;monitor::UseCase { -> F}
//## Uses: <unnamed>%531EE1A60164;emssegment::CasePhaseVisaVROLSegment { -> F}
//## Uses: <unnamed>%531EE1D501FB;emssegment::CaseDocumentSegment { -> F}
//## Uses: <unnamed>%531EE22F03C1;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%531EE2D200AA;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%531EE37702A0;reusable::Row { -> F}
//## Uses: <unnamed>%531EE45C0123;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%531EE4F90249;segment::InformationSegment { -> F}
//## Uses: <unnamed>%5CF1063700C0;emssegment::CaseSmartFormSegment { -> F}
//## Uses: <unnamed>%5E7B0F1B0184;emssegment::CaseDocumentExtensionSegment { -> F}

class DllExport CaseDocumentListCommand : public command::ClientListCommand  //## Inherits: <unnamed>%531DE781029C
{
  //## begin emscommand::CaseDocumentListCommand%53188BD40042.initialDeclarations preserve=yes
  //## end emscommand::CaseDocumentListCommand%53188BD40042.initialDeclarations

  public:
    //## Constructors (generated)
      CaseDocumentListCommand();

    //## Constructors (specified)
      //## Operation: CaseDocumentListCommand%5318940C03AC
      CaseDocumentListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseDocumentListCommand();


    //## Other Operations (specified)
      //## Operation: cleanup%531ED4AA021A
      void cleanup ();

      //## Operation: retrieve%531892B70010
      virtual bool retrieve ();

      //## Operation: update%5318945A00A3
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::CaseDocumentListCommand%53188BD40042.public preserve=yes
      //## end emscommand::CaseDocumentListCommand%53188BD40042.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::CaseDocumentListCommand%53188BD40042.protected preserve=yes
      //## end emscommand::CaseDocumentListCommand%53188BD40042.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseDocumentListCommand%53188BD40042.private preserve=yes
      //## end emscommand::CaseDocumentListCommand%53188BD40042.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: SEQ_NO%531ECBF90102
      //## begin emscommand::CaseDocumentListCommand::SEQ_NO%531ECBF90102.attr preserve=no  private: short {U} 
      short m_siSEQ_NO;
      //## end emscommand::CaseDocumentListCommand::SEQ_NO%531ECBF90102.attr

      //## Attribute: szBuffer%531ED52C036E
      //## begin emscommand::CaseDocumentListCommand::szBuffer%531ED52C036E.attr preserve=no  private: char * {U} 
      char *m_pszBuffer;
      //## end emscommand::CaseDocumentListCommand::szBuffer%531ED52C036E.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%531DF7DD0010
      //## Role: CaseDocumentListCommand::<m_pPrimaryKeySegment>%531DF7DD03B1
      //## begin emscommand::CaseDocumentListCommand::<m_pPrimaryKeySegment>%531DF7DD03B1.role preserve=no  public: segment::PrimaryKeySegment { -> RFHgN}
      segment::PrimaryKeySegment *m_pPrimaryKeySegment;
      //## end emscommand::CaseDocumentListCommand::<m_pPrimaryKeySegment>%531DF7DD03B1.role

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%531DF8D70145
      //## Role: CaseDocumentListCommand::<m_pPersistentSegment>%531DF8D80080
      //## begin emscommand::CaseDocumentListCommand::<m_pPersistentSegment>%531DF8D80080.role preserve=no  public: segment::PersistentSegment { -> RFHgN}
      segment::PersistentSegment *m_pPersistentSegment;
      //## end emscommand::CaseDocumentListCommand::<m_pPersistentSegment>%531DF8D80080.role

    // Additional Implementation Declarations
      //## begin emscommand::CaseDocumentListCommand%53188BD40042.implementation preserve=yes
      map<short,string, less<short> > m_hQuestionFields;
      //## end emscommand::CaseDocumentListCommand%53188BD40042.implementation
};

//## begin emscommand::CaseDocumentListCommand%53188BD40042.postscript preserve=yes
//## end emscommand::CaseDocumentListCommand%53188BD40042.postscript

} // namespace emscommand

//## begin module%53188D500144.epilog preserve=yes
//## end module%53188D500144.epilog


#endif
