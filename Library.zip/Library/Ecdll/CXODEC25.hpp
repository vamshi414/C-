//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4A099D2201F4.cm preserve=no
//	$Date:   Jun 29 2009 15:00:34  $ $Author:   D96312  $
//	$Revision:   1.2  $
//## end module%4A099D2201F4.cm

//## begin module%4A099D2201F4.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%4A099D2201F4.cp

//## Module: CXOSEC25%4A099D2201F4; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC25.hpp

#ifndef CXOSEC25_h
#define CXOSEC25_h 1

//## begin module%4A099D2201F4.additionalIncludes preserve=no
//## end module%4A099D2201F4.additionalIncludes

//## begin module%4A099D2201F4.includes preserve=yes
//## end module%4A099D2201F4.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseLockSegment;
} // namespace emssegment

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Timestamp;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

namespace IF {
class Message;
class DateTime;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class Timer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class ResponseTimeSegment;
class CommonHeaderSegment;

} // namespace segment

//## begin module%4A099D2201F4.declarations preserve=no
//## end module%4A099D2201F4.declarations

//## begin module%4A099D2201F4.additionalDeclarations preserve=yes
//## end module%4A099D2201F4.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseLockCommand%4A099CAE0399.preface preserve=yes
//## end emscommand::CaseLockCommand%4A099CAE0399.preface

//## Class: CaseLockCommand%4A099CAE0399
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4A09AD0D00AB;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%4A0B1C7E01E4;reusable::Query { -> F}
//## Uses: <unnamed>%4A0B1C8E01C5;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4A0B1CA601E4;reusable::Statement { -> F}
//## Uses: <unnamed>%4A0B1CBC03B9;reusable::Table { -> F}
//## Uses: <unnamed>%4A0B1D430128;monitor::UseCase { -> F}
//## Uses: <unnamed>%4A0B1EF40280;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%4A0B1EF801A5;segment::InformationSegment { -> F}
//## Uses: <unnamed>%4A0B22140290;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4A0B28E90186;IF::Extract { -> F}
//## Uses: <unnamed>%4A0B308C0119;timer::Clock { -> F}
//## Uses: <unnamed>%4A0B30BC007D;IF::Timestamp { -> F}
//## Uses: <unnamed>%4A0B379B0177;IF::DateTime { -> F}
//## Uses: <unnamed>%4A0C77EC033C;timer::Timer { -> F}
//## Uses: <unnamed>%4A26D5CB02EE;IF::Message { -> F}

class DllExport CaseLockCommand : public command::ClientCommand  //## Inherits: <unnamed>%4A09ACDA01B5
{
  //## begin emscommand::CaseLockCommand%4A099CAE0399.initialDeclarations preserve=yes
  //## end emscommand::CaseLockCommand%4A099CAE0399.initialDeclarations

  public:
    //## Constructors (generated)
      CaseLockCommand();

    //## Constructors (specified)
      //## Operation: CaseLockCommand%4A09B08300CB
      CaseLockCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseLockCommand();


    //## Other Operations (specified)
      //## Operation: calculateUpdatedLockTime%4A0C455602BF
      string calculateUpdatedLockTime ();

      //## Operation: execute%4A09B1CA009C
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: process%4A09C25F0177
      bool process ();

      //## Operation: unlock%4A0C72A203A9
      bool unlock (const string& strUSER_ID);

    // Additional Public Declarations
      //## begin emscommand::CaseLockCommand%4A099CAE0399.public preserve=yes
      //## end emscommand::CaseLockCommand%4A099CAE0399.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::CaseLockCommand%4A099CAE0399.protected preserve=yes
      //## end emscommand::CaseLockCommand%4A099CAE0399.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseLockCommand%4A099CAE0399.private preserve=yes
      //## end emscommand::CaseLockCommand%4A099CAE0399.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Lock_Time%4A0B269F0251
      //	This is the default value (in seconds) for which a case
      //	will be locked. This value can be overridden if LOCKTIME
      //	is specified in the extract file.
      //## begin emscommand::CaseLockCommand::Lock_Time%4A0B269F0251.attr preserve=no  private: int {U} 600
      int m_iLock_Time;
      //## end emscommand::CaseLockCommand::Lock_Time%4A0B269F0251.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4A09AF9F0186
      //## Role: CaseLockCommand::<m_pCaseLockSegment>%4A09AFA00196
      //## begin emscommand::CaseLockCommand::<m_pCaseLockSegment>%4A09AFA00196.role preserve=no  public: emssegment::CaseLockSegment { -> RFHgN}
      emssegment::CaseLockSegment *m_pCaseLockSegment;
      //## end emscommand::CaseLockCommand::<m_pCaseLockSegment>%4A09AFA00196.role

    // Additional Implementation Declarations
      //## begin emscommand::CaseLockCommand%4A099CAE0399.implementation preserve=yes
      //## end emscommand::CaseLockCommand%4A099CAE0399.implementation

};

//## begin emscommand::CaseLockCommand%4A099CAE0399.postscript preserve=yes
//## end emscommand::CaseLockCommand%4A099CAE0399.postscript

} // namespace emscommand

//## begin module%4A099D2201F4.epilog preserve=yes
//## end module%4A099D2201F4.epilog


#endif
