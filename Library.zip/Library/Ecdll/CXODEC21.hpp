//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%45EE5E630205.cm preserve=no
//	$Date:   Apr 05 2007 10:49:00  $ $Author:   D08048  $
//	$Revision:   1.0  $
//## end module%45EE5E630205.cm

//## begin module%45EE5E630205.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%45EE5E630205.cp

//## Module: CXOSEC21%45EE5E630205; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC21.hpp

#ifndef CXOSEC21_h
#define CXOSEC21_h 1

//## begin module%45EE5E630205.additionalIncludes preserve=no
//## end module%45EE5E630205.additionalIncludes

//## begin module%45EE5E630205.includes preserve=yes
//## end module%45EE5E630205.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseSegment;
} // namespace emssegment

//## Modelname: DataNavigator Foundation::RepositoryCommand_CAT%394E267C0078
namespace repositorycommand {
class FinancialUpdateFinTypeCommand;
} // namespace repositorycommand

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MinuteTimer;
} // namespace timer

namespace database {
class GlobalContext;
class Context;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%45EE5E630205.declarations preserve=no
//## end module%45EE5E630205.declarations

//## begin module%45EE5E630205.additionalDeclarations preserve=yes
//## end module%45EE5E630205.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseFinLocatorUpdate%45EE5DD703E6.preface preserve=yes
//## end emscommand::CaseFinLocatorUpdate%45EE5DD703E6.preface

//## Class: CaseFinLocatorUpdate%45EE5DD703E6
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%45EE6142011E;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%45EE616301B9;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%45EE61830032;monitor::UseCase { -> F}
//## Uses: <unnamed>%45EE61E70251;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%45EE621E0114;repositorycommand::FinancialUpdateFinTypeCommand { -> F}
//## Uses: <unnamed>%45EE79160147;reusable::Query { -> F}
//## Uses: <unnamed>%45EEA1440270;database::GlobalContext { -> F}
//## Uses: <unnamed>%45EFC0F6001B;database::Database { -> F}
//## Uses: <unnamed>%45EFDB7C020C;IF::Trace { -> F}
//## Uses: <unnamed>%45EFEAFC0299;process::Application { -> F}
//## Uses: <unnamed>%45EFEB9B01C1;database::Context { -> F}
//## Uses: <unnamed>%45F4E98E0308;reusable::Table { -> F}
//## Uses: <unnamed>%45F4EE1600F6;reusable::Statement { -> F}
//## Uses: <unnamed>%45F7CD480330;timer::MinuteTimer { -> F}

class DllExport CaseFinLocatorUpdate : public reusable::Observer  //## Inherits: <unnamed>%45EE60C801ED
{
  //## begin emscommand::CaseFinLocatorUpdate%45EE5DD703E6.initialDeclarations preserve=yes
  //## end emscommand::CaseFinLocatorUpdate%45EE5DD703E6.initialDeclarations

  public:
    //## Constructors (generated)
      CaseFinLocatorUpdate();

    //## Destructor (generated)
      virtual ~CaseFinLocatorUpdate();


    //## Other Operations (specified)
      //## Operation: execute%45EE6556021A
      bool  execute ();

      //## Operation: reset%45F5173602C1
      bool reset ();

      //## Operation: update%45EE652A03A9
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: InProgress%45F520C70031
      const bool& getInProgress () const
      {
        //## begin emscommand::CaseFinLocatorUpdate::getInProgress%45F520C70031.get preserve=no
        return m_bInProgress;
        //## end emscommand::CaseFinLocatorUpdate::getInProgress%45F520C70031.get
      }

      void setInProgress (const bool& value)
      {
        //## begin emscommand::CaseFinLocatorUpdate::setInProgress%45F520C70031.set preserve=no
        m_bInProgress = value;
        //## end emscommand::CaseFinLocatorUpdate::setInProgress%45F520C70031.set
      }


    // Additional Public Declarations
      //## begin emscommand::CaseFinLocatorUpdate%45EE5DD703E6.public preserve=yes
      //## end emscommand::CaseFinLocatorUpdate%45EE5DD703E6.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::CaseFinLocatorUpdate%45EE5DD703E6.protected preserve=yes
      //## end emscommand::CaseFinLocatorUpdate%45EE5DD703E6.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseFinLocatorUpdate%45EE5DD703E6.private preserve=yes
      //## end emscommand::CaseFinLocatorUpdate%45EE5DD703E6.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BeginMonth%45F7C3D80374
      //## begin emscommand::CaseFinLocatorUpdate::BeginMonth%45F7C3D80374.attr preserve=no  protected: string {U} 
      string m_strBeginMonth;
      //## end emscommand::CaseFinLocatorUpdate::BeginMonth%45F7C3D80374.attr

      //## Attribute: CASE_ID%45EF9F310372
      //## begin emscommand::CaseFinLocatorUpdate::CASE_ID%45EF9F310372.attr preserve=no  protected: int {U} 
      int m_iCASE_ID;
      //## end emscommand::CaseFinLocatorUpdate::CASE_ID%45EF9F310372.attr

      //## Attribute: CARD_ACPT_TERM_ID%45EFFDA0015A
      //## begin emscommand::CaseFinLocatorUpdate::CARD_ACPT_TERM_ID%45EFFDA0015A.attr preserve=no  private: string {U} 
      string m_strCARD_ACPT_TERM_ID;
      //## end emscommand::CaseFinLocatorUpdate::CARD_ACPT_TERM_ID%45EFFDA0015A.attr

      //## Attribute: CASE_NO%45F5227602DB
      //## begin emscommand::CaseFinLocatorUpdate::CASE_NO%45F5227602DB.attr preserve=no  private: string {U} 
      string m_strCASE_NO;
      //## end emscommand::CaseFinLocatorUpdate::CASE_NO%45F5227602DB.attr

      //## begin emscommand::CaseFinLocatorUpdate::InProgress%45F520C70031.attr preserve=no  public: bool {U} false
      bool m_bInProgress;
      //## end emscommand::CaseFinLocatorUpdate::InProgress%45F520C70031.attr

      //## Attribute: NET_TERM_ID%45EFF9F401E3
      //## begin emscommand::CaseFinLocatorUpdate::NET_TERM_ID%45EFF9F401E3.attr preserve=no  private: string {U} 
      string m_strNET_TERM_ID;
      //## end emscommand::CaseFinLocatorUpdate::NET_TERM_ID%45EFF9F401E3.attr

      //## Attribute: MinCASE_ID%45EE65FA01F2
      //## begin emscommand::CaseFinLocatorUpdate::MinCASE_ID%45EE65FA01F2.attr preserve=no  protected: int {U} -1
      int m_iMinCASE_ID;
      //## end emscommand::CaseFinLocatorUpdate::MinCASE_ID%45EE65FA01F2.attr

      //## Attribute: MaxCASE_ID%45EE66070271
      //## begin emscommand::CaseFinLocatorUpdate::MaxCASE_ID%45EE66070271.attr preserve=no  protected: int {U} -1
      int m_iMaxCASE_ID;
      //## end emscommand::CaseFinLocatorUpdate::MaxCASE_ID%45EE66070271.attr

      //## Attribute: PAN%45EFFA2B03D8
      //## begin emscommand::CaseFinLocatorUpdate::PAN%45EFFA2B03D8.attr preserve=no  private: string {U} 
      string m_strPAN;
      //## end emscommand::CaseFinLocatorUpdate::PAN%45EFFA2B03D8.attr

      //## Attribute: REQUEST_TYPE%45F511230395
      //## begin emscommand::CaseFinLocatorUpdate::REQUEST_TYPE%45F511230395.attr preserve=no  private: string {U} 
      string m_strREQUEST_TYPE;
      //## end emscommand::CaseFinLocatorUpdate::REQUEST_TYPE%45F511230395.attr

      //## Attribute: RETRIEVAL_REF_NO%45EFFA63009E
      //## begin emscommand::CaseFinLocatorUpdate::RETRIEVAL_REF_NO%45EFFA63009E.attr preserve=no  private: string {U} 
      string m_strRETRIEVAL_REF_NO;
      //## end emscommand::CaseFinLocatorUpdate::RETRIEVAL_REF_NO%45EFFA63009E.attr

      //## Attribute: SYS_TRACE_AUDIT_NO%45EFFA91036E
      //## begin emscommand::CaseFinLocatorUpdate::SYS_TRACE_AUDIT_NO%45EFFA91036E.attr preserve=no  private: string {U} 
      string m_strSYS_TRACE_AUDIT_NO;
      //## end emscommand::CaseFinLocatorUpdate::SYS_TRACE_AUDIT_NO%45EFFA91036E.attr

      //## Attribute: TRAN_TYPE_ID%45EFFA7F007F
      //## begin emscommand::CaseFinLocatorUpdate::TRAN_TYPE_ID%45EFFA7F007F.attr preserve=no  private: string {U} 
      string m_strTRAN_TYPE_ID;
      //## end emscommand::CaseFinLocatorUpdate::TRAN_TYPE_ID%45EFFA7F007F.attr

      //## Attribute: TSTAMP_TRANS%45EF9F48033D
      //## begin emscommand::CaseFinLocatorUpdate::TSTAMP_TRANS%45EF9F48033D.attr preserve=no  private: string {U} 
      string m_strTSTAMP_TRANS;
      //## end emscommand::CaseFinLocatorUpdate::TSTAMP_TRANS%45EF9F48033D.attr

      //## Attribute: TSTAMP_LOCAL%45EFF9D301E2
      //## begin emscommand::CaseFinLocatorUpdate::TSTAMP_LOCAL%45EFF9D301E2.attr preserve=no  private: string {U} 
      string m_strTSTAMP_LOCAL;
      //## end emscommand::CaseFinLocatorUpdate::TSTAMP_LOCAL%45EFF9D301E2.attr

    // Additional Implementation Declarations
      //## begin emscommand::CaseFinLocatorUpdate%45EE5DD703E6.implementation preserve=yes
      //## end emscommand::CaseFinLocatorUpdate%45EE5DD703E6.implementation

};

//## begin emscommand::CaseFinLocatorUpdate%45EE5DD703E6.postscript preserve=yes
//## end emscommand::CaseFinLocatorUpdate%45EE5DD703E6.postscript

} // namespace emscommand

//## begin module%45EE5E630205.epilog preserve=yes
using namespace emscommand;
//## end module%45EE5E630205.epilog


#endif
