//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4A300DCD029A.cm preserve=no
//	$Date:   Aug 12 2010 10:28:26  $ $Author:   e3002905  $
//	$Revision:   1.2  $
//## end module%4A300DCD029A.cm

//## begin module%4A300DCD029A.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4A300DCD029A.cp

//## Module: CXOSEC26%4A300DCD029A; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC26.hpp

#ifndef CXOSEC26_h
#define CXOSEC26_h 1

//## begin module%4A300DCD029A.additionalIncludes preserve=no
//## end module%4A300DCD029A.additionalIncludes

//## begin module%4A300DCD029A.includes preserve=yes
//## end module%4A300DCD029A.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

namespace reusable {
class SearchCondition;
class Table;
class Statement;
class SelectStatement;
} // namespace reusable

namespace IF {
class Console;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%4A300DCD029A.declarations preserve=no
//## end module%4A300DCD029A.declarations

//## begin module%4A300DCD029A.additionalDeclarations preserve=yes
//## end module%4A300DCD029A.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::ExceptionRepair%4A300D27018D.preface preserve=yes
//## end emscommand::ExceptionRepair%4A300D27018D.preface

//## Class: ExceptionRepair%4A300D27018D
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4A300D870073;monitor::UseCase { -> F}
//## Uses: <unnamed>%4A300D89021A;database::Database { -> F}
//## Uses: <unnamed>%4A300D8B029F;reusable::Query { -> F}
//## Uses: <unnamed>%4A300D8D02D4;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4A300D8F0395;reusable::Table { -> F}
//## Uses: <unnamed>%4A31345E031F;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4A31347E03CF;reusable::Statement { -> F}
//## Uses: <unnamed>%4A3139000125;timer::Clock { -> F}
//## Uses: <unnamed>%4A31443203BB;IF::Console { -> F}
//## Uses: <unnamed>%4A314455013B;IF::Trace { -> F}
//## Uses: <unnamed>%4C63975000AD;reusable::SearchCondition { -> F}

class DllExport ExceptionRepair : public reusable::Observer  //## Inherits: <unnamed>%4A300D45037B
{
  //## begin emscommand::ExceptionRepair%4A300D27018D.initialDeclarations preserve=yes
  //## end emscommand::ExceptionRepair%4A300D27018D.initialDeclarations

  public:
    //## Constructors (generated)
      ExceptionRepair();

    //## Destructor (generated)
      virtual ~ExceptionRepair();


    //## Other Operations (specified)
      //## Operation: errorMessage%4A313BB6039A
      void errorMessage (const string& strMessage);

      //## Operation: onResume%4A300ED3012E
      bool onResume ();

      //## Operation: update%4A312B5A0398
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::ExceptionRepair%4A300D27018D.public preserve=yes
      //## end emscommand::ExceptionRepair%4A300D27018D.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::ExceptionRepair%4A300D27018D.protected preserve=yes
      //## end emscommand::ExceptionRepair%4A300D27018D.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::ExceptionRepair%4A300D27018D.private preserve=yes
      //## end emscommand::ExceptionRepair%4A300D27018D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: LastErrorMsg%4A31BD9700EB
      //## begin emscommand::ExceptionRepair::LastErrorMsg%4A31BD9700EB.attr preserve=no  private: int {U} 0
      int m_iLastErrorMsg;
      //## end emscommand::ExceptionRepair::LastErrorMsg%4A31BD9700EB.attr

      //## Attribute: CASE_ID%4C63968E01ED
      //## begin emscommand::ExceptionRepair::CASE_ID%4C63968E01ED.attr preserve=no  private: int {U} 0
      int m_iCASE_ID;
      //## end emscommand::ExceptionRepair::CASE_ID%4C63968E01ED.attr

      //## Attribute: PAN%4C6396960374
      //## begin emscommand::ExceptionRepair::PAN%4C6396960374.attr preserve=no  private: string {U} 
      string m_strPAN;
      //## end emscommand::ExceptionRepair::PAN%4C6396960374.attr

      //## Attribute: PAN_PREFIX%4C63969803D2
      //## begin emscommand::ExceptionRepair::PAN_PREFIX%4C63969803D2.attr preserve=no  private: string {U} 
      string m_strPAN_PREFIX;
      //## end emscommand::ExceptionRepair::PAN_PREFIX%4C63969803D2.attr

    // Additional Implementation Declarations
      //## begin emscommand::ExceptionRepair%4A300D27018D.implementation preserve=yes
      short m_siBIN_LENGTH;
      //## end emscommand::ExceptionRepair%4A300D27018D.implementation

};

//## begin emscommand::ExceptionRepair%4A300D27018D.postscript preserve=yes
//## end emscommand::ExceptionRepair%4A300D27018D.postscript

} // namespace emscommand

//## begin module%4A300DCD029A.epilog preserve=yes
//## end module%4A300DCD029A.epilog


#endif
