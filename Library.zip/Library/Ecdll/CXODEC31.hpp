//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%55B90B350257.cm preserve=no
//	$Date:   Jul 31 2015 10:48:40  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%55B90B350257.cm

//## begin module%55B90B350257.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%55B90B350257.cp

//## Module: CXOSEC31%55B90B350257; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\bV02.5B.R001\Windows\Build\Dn\Server\Library\Ecdll\CXODEC31.hpp

#ifndef CXOSEC31_h
#define CXOSEC31_h 1

//## begin module%55B90B350257.additionalIncludes preserve=no
//## end module%55B90B350257.additionalIncludes

//## begin module%55B90B350257.includes preserve=yes
#ifndef CXOSRU20_h
#include "CXODRU20.hpp"
#endif
#ifndef CXOSBS19_h
#include "CXODBS19.hpp"
#endif
#ifndef CXOSBC16_h
#include "CXODBC16.hpp"
#endif
//## end module%55B90B350257.includes

#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseDocumentSegment;
} // namespace emssegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SearchCondition;
class Table;
class Statement;
class SelectStatement;
class Row;
class Query;
class Key;
class KeyRing;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class DateTime;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class TextSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class XMLText;
class XMLDocument;

} // namespace command

//## begin module%55B90B350257.declarations preserve=no
//## end module%55B90B350257.declarations

//## begin module%55B90B350257.additionalDeclarations preserve=yes
//## end module%55B90B350257.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::DocSecure%55B90AF70297.preface preserve=yes
//## end emscommand::DocSecure%55B90AF70297.preface

//## Class: DocSecure%55B90AF70297
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%55B90C8802FC;command::XMLDocument { -> F}
//## Uses: <unnamed>%55B90C8B007E;segment::TextSegment { -> F}
//## Uses: <unnamed>%55B90C8E00BE;command::XMLText { -> F}
//## Uses: <unnamed>%55B90C90027E;reusable::Query { -> F}
//## Uses: <unnamed>%55B90C9201D6;reusable::Row { -> F}
//## Uses: <unnamed>%55B90CD60100;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%55B90CD801DE;database::GlobalContext { -> F}
//## Uses: <unnamed>%55B90CDB00C8;database::Database { -> F}
//## Uses: <unnamed>%55B90D0C0049;monitor::UseCase { -> F}
//## Uses: <unnamed>%55B90D0E0309;segment::TextSegment { -> F}
//## Uses: <unnamed>%55B90D4202FC;timer::Clock { -> F}
//## Uses: <unnamed>%55B90D450012;timer::Date { -> F}
//## Uses: <unnamed>%55B90D47038E;IF::Trace { -> F}
//## Uses: <unnamed>%55B90D8E0334;IF::DateTime { -> F}
//## Uses: <unnamed>%55B90E34033C;reusable::SearchCondition { -> F}
//## Uses: <unnamed>%55B90E37009F;reusable::KeyRing { -> F}
//## Uses: <unnamed>%55B90E56013B;reusable::Key { -> F}
//## Uses: <unnamed>%55B90E5A0113;emssegment::CaseDocumentSegment { -> F}
//## Uses: <unnamed>%55B90E6901B9;reusable::Table { -> F}
//## Uses: <unnamed>%55B919BB004C;reusable::Statement { -> F}
//## Uses: <unnamed>%55B919BE027A;reusable::SelectStatement { -> F}

class DllExport DocSecure : public database::ExportFile  //## Inherits: <unnamed>%55B90B0702FD
{
  //## begin emscommand::DocSecure%55B90AF70297.initialDeclarations preserve=yes
  //## end emscommand::DocSecure%55B90AF70297.initialDeclarations

  public:
    //## Constructors (generated)
      DocSecure();

    //## Constructors (specified)
      //## Operation: DocSecure%55B917A000FD
      DocSecure (const string& strAction);

    //## Destructor (generated)
      virtual ~DocSecure();


    //## Other Operations (specified)
      //## Operation: computePendingKey%55B90F1102B4
      string computePendingKey (const string& strTSTAMP);

      //## Operation: exportXMLDocList%55B90F3B00C6
      bool exportXMLDocList (const string& strKEY_ID, int lCount);

      //## Operation: initialize%55B90EB10208
      bool initialize ();

      //## Operation: onResume%55B910030033
      int onResume ();

      //## Operation: processDate%55B90F4C0382
      int processDate (const string& strTSTAMP);

      //## Operation: retrieveOldestDocumentDate%55B90EC201BA
      bool retrieveOldestDocumentDate ();

      //## Operation: start%55B90ED70332
      int start ();

      //## Operation: stop%55B90EDE019C
      int stop ();

      //## Operation: timeLimitExpired%55B90EEF0119
      bool timeLimitExpired ();

      //## Operation: update%55B90FDF019C
      virtual void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: CONTEXT_KEY%55B9103A0376
      const string& getCONTEXT_KEY () const
      {
        //## begin emscommand::DocSecure::getCONTEXT_KEY%55B9103A0376.get preserve=no
        return m_strCONTEXT_KEY;
        //## end emscommand::DocSecure::getCONTEXT_KEY%55B9103A0376.get
      }

      void setCONTEXT_KEY (const string& value)
      {
        //## begin emscommand::DocSecure::setCONTEXT_KEY%55B9103A0376.set preserve=no
        m_strCONTEXT_KEY = value;
        //## end emscommand::DocSecure::setCONTEXT_KEY%55B9103A0376.set
      }


    // Additional Public Declarations
      //## begin emscommand::DocSecure%55B90AF70297.public preserve=yes
      //## end emscommand::DocSecure%55B90AF70297.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::DocSecure%55B90AF70297.protected preserve=yes
      //## end emscommand::DocSecure%55B90AF70297.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::DocSecure%55B90AF70297.private preserve=yes
      //## end emscommand::DocSecure%55B90AF70297.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin emscommand::DocSecure::CONTEXT_KEY%55B9103A0376.attr preserve=no  public: string {V} 
      string m_strCONTEXT_KEY;
      //## end emscommand::DocSecure::CONTEXT_KEY%55B9103A0376.attr

      //## Attribute: Action%55B9153100F9
      //## begin emscommand::DocSecure::Action%55B9153100F9.attr preserve=no  private: string {U} 
      string m_strAction;
      //## end emscommand::DocSecure::Action%55B9153100F9.attr

      //## Attribute: CASE_ID%55B916860260
      //## begin emscommand::DocSecure::CASE_ID%55B916860260.attr preserve=no  private: int {U} 0
      int m_lCASE_ID;
      //## end emscommand::DocSecure::CASE_ID%55B916860260.attr

      //## Attribute: ExpiredKeys%55B916EB0073
      //## begin emscommand::DocSecure::ExpiredKeys%55B916EB0073.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hExpiredKeys;
      //## end emscommand::DocSecure::ExpiredKeys%55B916EB0073.attr

      //## Attribute: KEY_ID%55B915670162
      //## begin emscommand::DocSecure::KEY_ID%55B915670162.attr preserve=no  private: string {U} 
      string m_strKEY_ID;
      //## end emscommand::DocSecure::KEY_ID%55B915670162.attr

      //## Attribute: zProgress%55B9105B0128
      //## begin emscommand::DocSecure::zProgress%55B9105B0128.attr preserve=no  private: char[95] {U} 
      char m_szProgress[95];
      //## end emscommand::DocSecure::zProgress%55B9105B0128.attr

      //## Attribute: Progress%55B914E001B3
      //## begin emscommand::DocSecure::Progress%55B914E001B3.attr preserve=no  private: string {U} 
      string m_strProgress;
      //## end emscommand::DocSecure::Progress%55B914E001B3.attr

      //## Attribute: Query%55B9158A00EA
      //## begin emscommand::DocSecure::Query%55B9158A00EA.attr preserve=no  private: reusable::Query {U} 
      reusable::Query m_hQuery;
      //## end emscommand::DocSecure::Query%55B9158A00EA.attr

      //## Attribute: Row%55B9161403AA
      //## begin emscommand::DocSecure::Row%55B9161403AA.attr preserve=no  private: reusable::Row {U} 
      reusable::Row m_hRow;
      //## end emscommand::DocSecure::Row%55B9161403AA.attr

      //## Attribute: SEQ_NO%55B916A601F4
      //## begin emscommand::DocSecure::SEQ_NO%55B916A601F4.attr preserve=no  private: short {U} 0
      short m_siSEQ_NO;
      //## end emscommand::DocSecure::SEQ_NO%55B916A601F4.attr

      //## Attribute: TextSegment%55B9197702A0
      //## begin emscommand::DocSecure::TextSegment%55B9197702A0.attr preserve=no  private: segment::TextSegment {U} 
      segment::TextSegment m_hTextSegment;
      //## end emscommand::DocSecure::TextSegment%55B9197702A0.attr

      //## Attribute: TSTAMP_CREATED%55B915300279
      //## begin emscommand::DocSecure::TSTAMP_CREATED%55B915300279.attr preserve=no  private: string {U} 
      string m_strTSTAMP_CREATED;
      //## end emscommand::DocSecure::TSTAMP_CREATED%55B915300279.attr

      //## Attribute: XMLDocument%55B9164F017B
      //## begin emscommand::DocSecure::XMLDocument%55B9164F017B.attr preserve=no  private: command::XMLDocument* {U} 
      command::XMLDocument* m_pXMLDocument;
      //## end emscommand::DocSecure::XMLDocument%55B9164F017B.attr

      //## Attribute: XMLText%55B9163102E1
      //## begin emscommand::DocSecure::XMLText%55B9163102E1.attr preserve=no  private: command::XMLText {U} 
      command::XMLText m_hXMLText;
      //## end emscommand::DocSecure::XMLText%55B9163102E1.attr

    // Additional Implementation Declarations
      //## begin emscommand::DocSecure%55B90AF70297.implementation preserve=yes
      //## end emscommand::DocSecure%55B90AF70297.implementation

};

//## begin emscommand::DocSecure%55B90AF70297.postscript preserve=yes
//## end emscommand::DocSecure%55B90AF70297.postscript

} // namespace emscommand

//## begin module%55B90B350257.epilog preserve=yes
//## end module%55B90B350257.epilog


#endif
