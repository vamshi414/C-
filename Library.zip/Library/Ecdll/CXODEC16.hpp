//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3F43719D02CE.cm preserve=no
//	$Date:   Aug 20 2014 12:08:20  $ $Author:   e1014316  $
//	$Revision:   1.9  $
//## end module%3F43719D02CE.cm

//## begin module%3F43719D02CE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3F43719D02CE.cp

//## Module: CXOSEC16%3F43719D02CE; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\bV02.4B.R009\Build\Dn\Server\Library\Ecdll\CXODEC16.hpp

#ifndef CXOSEC16_h
#define CXOSEC16_h 1

//## begin module%3F43719D02CE.additionalIncludes preserve=no
//## end module%3F43719D02CE.additionalIncludes

//## begin module%3F43719D02CE.includes preserve=yes
// $Date:   Aug 20 2014 12:08:20  $ $Author:   e1014316  $ $Revision:   1.9  $
//## end module%3F43719D02CE.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseFraudMCSegment;
class CasePaymentSegment;
class CreditSegment;
class CaseIntegratedCircuitCardSegment;
} // namespace emssegment

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class InstitutionBinSegment;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::UserCommand_CAT%394E26E302E3
namespace usercommand {
class GetPreauthTranCommand;
} // namespace usercommand

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
class Statement;

} // namespace reusable

//## begin module%3F43719D02CE.declarations preserve=no
//## end module%3F43719D02CE.declarations

//## begin module%3F43719D02CE.additionalDeclarations preserve=yes
//## end module%3F43719D02CE.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::RechainCaseCommand%3F43712E02BF.preface preserve=yes
//## end emscommand::RechainCaseCommand%3F43712E02BF.preface

//## Class: RechainCaseCommand%3F43712E02BF
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%407550990119;ems::Case { -> F}
//## Uses: <unnamed>%407550CD02AF;monitor::UseCase { -> F}
//## Uses: <unnamed>%407550EA02AF;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%40755103031C;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%40755126036B;IF::Message { -> F}
//## Uses: <unnamed>%4075514302DE;database::Database { -> F}
//## Uses: <unnamed>%40755155030D;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%4075517800CB;segment::InformationSegment { -> F}
//## Uses: <unnamed>%4078DEC301F4;segment::PersistentSegment { -> F}
//## Uses: <unnamed>%4078DF1103B9;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%4078E02A031C;repositorysegment::FinancialSettlementSegment { -> F}
//## Uses: <unnamed>%4078E02D01A5;repositorysegment::FinancialBaseSegment { -> F}
//## Uses: <unnamed>%4078E02F0167;emssegment::CaseNationalNetworkSegment { -> F}
//## Uses: <unnamed>%4078E03300DA;emssegment::CasePreAuthSegment { -> F}
//## Uses: <unnamed>%4078EE1C00CB;repositorysegment::GetPreauthTranSegment { -> F}
//## Uses: <unnamed>%40878F15001F;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%40878F1701E4;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%43D4C5E6005D;archive::ArchiveRetriever { -> F}
//## Uses: <unnamed>%469619300157;emssegment::CaseIntegratedCircuitCardSegment { -> F}
//## Uses: <unnamed>%46C154A60342;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%4CCD20410322;emssegment::CaseFraudMCSegment { -> F}
//## Uses: <unnamed>%4CCD20EA01CF;entitysegment::InstitutionBinSegment { -> F}
//## Uses: <unnamed>%4CCD21F40147;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%4CCE822F013B;reusable::Transaction { -> F}
//## Uses: <unnamed>%4D74ED900384;reusable::Statement { -> F}
//## Uses: <unnamed>%52FA4E1E0392;emssegment::CreditSegment { -> F}
//## Uses: <unnamed>%53E61675000F;emssegment::CasePaymentSegment { -> F}

class DllExport RechainCaseCommand : public command::ClientCommand  //## Inherits: <unnamed>%3F4371610167
{
  //## begin emscommand::RechainCaseCommand%3F43712E02BF.initialDeclarations preserve=yes
  //## end emscommand::RechainCaseCommand%3F43712E02BF.initialDeclarations

  public:
    //## Constructors (generated)
      RechainCaseCommand();

    //## Constructors (specified)
      //## Operation: RechainCaseCommand%4075501101E4
      RechainCaseCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~RechainCaseCommand();


    //## Other Operations (specified)
      //## Operation: canCreateCase%40F3DA280271
      //	Depending upon Request Type and Transaction details,
      //	decides whether requested type of case could be raised
      //	against the transaction.
      bool canCreateCase ();

      //## Operation: execute%40754FE30128
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%40754FE30148
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

      //## Operation: setCaseCountryISS%4CCD1D66024B
      void setCaseCountryISS ();

    // Additional Public Declarations
      //## begin emscommand::RechainCaseCommand%3F43712E02BF.public preserve=yes
      //## end emscommand::RechainCaseCommand%3F43712E02BF.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::RechainCaseCommand%3F43712E02BF.protected preserve=yes
      //## end emscommand::RechainCaseCommand%3F43712E02BF.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::RechainCaseCommand%3F43712E02BF.private preserve=yes
      //## end emscommand::RechainCaseCommand%3F43712E02BF.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%407FA4EE0177
      //## Role: RechainCaseCommand::<m_pGetPreauthTranCommand>%407FA4EF0109
      //## begin emscommand::RechainCaseCommand::<m_pGetPreauthTranCommand>%407FA4EF0109.role preserve=no  public: usercommand::GetPreauthTranCommand { -> RFHgN}
      usercommand::GetPreauthTranCommand *m_pGetPreauthTranCommand;
      //## end emscommand::RechainCaseCommand::<m_pGetPreauthTranCommand>%407FA4EF0109.role

    // Additional Implementation Declarations
      //## begin emscommand::RechainCaseCommand%3F43712E02BF.implementation preserve=yes
      //## end emscommand::RechainCaseCommand%3F43712E02BF.implementation

};

//## begin emscommand::RechainCaseCommand%3F43712E02BF.postscript preserve=yes
//## end emscommand::RechainCaseCommand%3F43712E02BF.postscript

} // namespace emscommand

//## begin module%3F43719D02CE.epilog preserve=yes
//## end module%3F43719D02CE.epilog


#endif
