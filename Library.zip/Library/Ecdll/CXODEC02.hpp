//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35ACB5CD022A.cm preserve=no
//## end module%35ACB5CD022A.cm

//## begin module%35ACB5CD022A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%35ACB5CD022A.cp

//## Module: CXOSEC02%35ACB5CD022A; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Ecdll\CXODEC02.hpp

#ifndef CXOSEC02_h
#define CXOSEC02_h 1

//## begin module%35ACB5CD022A.additionalIncludes preserve=no
//## end module%35ACB5CD022A.additionalIncludes

//## begin module%35ACB5CD022A.includes preserve=yes
// $Date:   May 29 2020 01:23:32  $ $Author:   e3028298  $ $Revision:   1.31  $
#include <set>
//## end module%35ACB5CD022A.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif
#ifndef CXOSEX01_h
#include "CXODEX01.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CasePhaseVisaVROLSegment;
class CaseDocumentExtensionSegment;
class CaseSmartFormSegment;
} // namespace emssegment

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ListSegment;

} // namespace segment

//## begin module%35ACB5CD022A.declarations preserve=no
//## end module%35ACB5CD022A.declarations

//## begin module%35ACB5CD022A.additionalDeclarations preserve=yes
//## end module%35ACB5CD022A.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseUpdateCommand%35ACB26A01AB.preface preserve=yes
//## end emscommand::CaseUpdateCommand%35ACB26A01AB.preface

//## Class: CaseUpdateCommand%35ACB26A01AB
//	QEMUCASE - update an EMS case.
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%35ACB3650043;reusable::Table { -> }
//## Uses: <unnamed>%35ACB36A0159;segment::CommonHeaderSegment { -> }
//## Uses: <unnamed>%35ACB36F02B5;segment::InformationSegment { -> }
//## Uses: <unnamed>%35AE022A014A;IF::DateTime { -> }
//## Uses: <unnamed>%370A27E3022A;IF::ResourceUsage { -> }
//## Uses: <unnamed>%3736EE520367;IF::Message { -> }
//## Uses: <unnamed>%3736EE5501D1;IF::Queue { -> }
//## Uses: <unnamed>%3736EF30038E;database::Database { -> }
//## Uses: <unnamed>%373ABC36010F;reusable::Statement { -> }
//## Uses: <unnamed>%373ABC520029;database::DatabaseFactory { -> }
//## Uses: <unnamed>%373C81230084;emssegment::CaseSegment { -> }
//## Uses: <unnamed>%373C81D100FC;emssegment::CaseTransitionSegment { -> }
//## Uses: <unnamed>%3741C78302E9;reusable::Query { -> }
//## Uses: <unnamed>%3741C7910203;reusable::SelectStatement { -> }
//## Uses: <unnamed>%374D85D503AA;ems::Case { -> }
//## Uses: <unnamed>%378CDE4D03A0;emssegment::CaseCommentSegment { -> }
//## Uses: <unnamed>%37F0E0CC03CC;usersegment::RelationshipSegment { -> }
//## Uses: <unnamed>%3A01B88001B9;monitor::UseCase { -> }
//## Uses: <unnamed>%3AC0EE9E0220;reusable::Transaction { -> }
//## Uses: <unnamed>%3C1538BE007C;IF::Extract { -> }
//## Uses: <unnamed>%3C1E18420160;reusable::CriticalSection { -> }
//## Uses: <unnamed>%3C46E82F00B7;IF::EMailMessage { -> }
//## Uses: <unnamed>%3E315D730167;repositorysegment::CardholderInformationSegment { -> F}
//## Uses: <unnamed>%3E315DA502FD;ems::CaseNotification { -> F}
//## Uses: <unnamed>%3E4CFC7302EE;emssegment::CaseNationalNetworkSegment { -> F}
//## Uses: <unnamed>%3E66316C007D;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%3EA42EA60148;ems::CaseAddEventVisitor { -> F}
//## Uses: <unnamed>%3EA4306B001F;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%3EADA6810167;emssegment::CasePhaseNetworkUniqueSegment { -> F}
//## Uses: <unnamed>%3EADA68300EA;emssegment::CaseNetworkUniqueSegment { -> F}
//## Uses: <unnamed>%3EADA758032C;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%3EC23C1A0186;emssegment::CaseDocumentSegment { -> F}
//## Uses: <unnamed>%40717C4E03C8;emssegment::CaseAccountHistorySegment { -> F}
//## Uses: <unnamed>%407305D20242;ems::AccountEntry { -> F}
//## Uses: <unnamed>%4652C6A80016;emssegment::CasePhaseVisaVROLSegment { -> F}
//## Uses: <unnamed>%5CF63DF70341;emssegment::CaseSmartFormSegment { -> F}
//## Uses: <unnamed>%5E7B0ACF0389;emssegment::CaseDocumentExtensionSegment { -> F}

class DllExport CaseUpdateCommand : public command::ClientCommand  //## Inherits: <unnamed>%35ACB27F0237
{
  //## begin emscommand::CaseUpdateCommand%35ACB26A01AB.initialDeclarations preserve=yes
  //## end emscommand::CaseUpdateCommand%35ACB26A01AB.initialDeclarations

  public:
    //## Constructors (generated)
      CaseUpdateCommand();

    //## Constructors (specified)
      //## Operation: CaseUpdateCommand%3731EA80029B
      CaseUpdateCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseUpdateCommand();


    //## Other Operations (specified)
      //## Operation: calculateSurcharge%511918410115
      void calculateSurcharge ();

      //## Operation: deleteDocExtension%5E7B0C480299
      bool deleteDocExtension ();

      //## Operation: deleteSmartForm%5CFF47080164
      bool deleteSmartForm ();

      //## Operation: execute%35ACB45F02E2
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: insertDocExtensionSegment%5E7B0B08015A
      bool insertDocExtensionSegment (const string &strQUESTION_FIELDS);

      //## Operation: insertSmartFormSegment%5CFE5A8B0370
      bool insertSmartFormSegment (const string &strQUESTION_FIELDS);

      //## Operation: insertVROLSegment%47173B460040
      bool insertVROLSegment (string strQUESTION_FIELDS);

      //## Operation: instance%40A26CF801A5
      static CaseUpdateCommand* instance ();

      //## Operation: parse%375E7B6200CB
      //	Parse this command into segments.
      //## Semantics:
      //	1. Verify the message length.
      //	2. Reset all segments.
      //	3. Import the available segments.
      virtual int parse ();

      //## Operation: processBatchDocumentList%4F171B2601C4
      bool processBatchDocumentList (int iListNumber);

      //## Operation: processDocumentSegmentList%4E0251D6025B
      bool processDocumentSegmentList (int iListNumber, bool bFirstPass = false);

      //## Operation: replicate%4B74045A032C
      virtual bool replicate ();

      //## Operation: replicateOtherCase%4E73577E0334
      void replicateOtherCase ();

      //## Operation: update%3731EA9C01E7
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

      //## Operation: checkUserAccess%652D637E01A7
      bool checkUserAccess (const string &strValidUser);

    //## Get and Set Operations for Associations (generated)

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%3EC91F870000
      //## Role: CaseUpdateCommand::<m_pListSegment>%3EC91F870271
      segment::ListSegment * getListSegment (int index)
      {
        //## begin emscommand::CaseUpdateCommand::getListSegment%3EC91F870271.get preserve=no
        return m_pListSegment[index];
        //## end emscommand::CaseUpdateCommand::getListSegment%3EC91F870271.get
      }


    // Additional Public Declarations
      //## begin emscommand::CaseUpdateCommand%35ACB26A01AB.public preserve=yes
      //## end emscommand::CaseUpdateCommand%35ACB26A01AB.public
  protected:
    // Data Members for Class Attributes

      //## Attribute: RCChanged%3EADA69B01A5
      //## begin emscommand::CaseUpdateCommand::RCChanged%3EADA69B01A5.attr preserve=no  public: bool {U} false
      bool m_bRCChanged;
      //## end emscommand::CaseUpdateCommand::RCChanged%3EADA69B01A5.attr

    // Additional Protected Declarations
      //## begin emscommand::CaseUpdateCommand%35ACB26A01AB.protected preserve=yes
      //## end emscommand::CaseUpdateCommand%35ACB26A01AB.protected

  private:

    //## Other Operations (specified)
      //## Operation: deleteNonExportedQuestionnaire%4DB704A5006C
      bool deleteNonExportedQuestionnaire ();

      //## Operation: updateCase%3C04FF210131
      bool updateCase (bool bFirstCase);

      //## Operation: updateDocumentSegment%4DB6CE8A02CE
      bool updateDocumentSegment ();

      //## Operation: updateSegment%3EC908DD0222
      bool updateSegment (segment::PersistentSegment* pPersistentSegment, bool bSamePhase = true);

    // Additional Private Declarations
      //## begin emscommand::CaseUpdateCommand%35ACB26A01AB.private preserve=yes
      //## end emscommand::CaseUpdateCommand%35ACB26A01AB.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CUST_ID%3C1535FB029C
      //## begin emscommand::CaseUpdateCommand::CUST_ID%3C1535FB029C.attr preserve=no  private: string {V} 
      string m_strCUST_ID;
      //## end emscommand::CaseUpdateCommand::CUST_ID%3C1535FB029C.attr

      //## Attribute: DBQuestionnaire%5171815D01DD
      //## begin emscommand::CaseUpdateCommand::DBQuestionnaire%5171815D01DD.attr preserve=no  private: string {U} 
      string m_strDBQuestionnaire;
      //## end emscommand::CaseUpdateCommand::DBQuestionnaire%5171815D01DD.attr

      //## Attribute: DocExt%5E7B0B8E028B
      //## begin emscommand::CaseUpdateCommand::DocExt%5E7B0B8E028B.attr preserve=no  private: bool {U} false
      bool m_bDocExt;
      //## end emscommand::CaseUpdateCommand::DocExt%5E7B0B8E028B.attr

      //## Attribute: Instance%40A26CD9034B
      //## begin emscommand::CaseUpdateCommand::Instance%40A26CD9034B.attr preserve=no  private: static CaseUpdateCommand* {V} 0
      static CaseUpdateCommand* m_pInstance;
      //## end emscommand::CaseUpdateCommand::Instance%40A26CD9034B.attr

      //## Attribute: QUESTION_FIELDS%51718348027F
      //## begin emscommand::CaseUpdateCommand::QUESTION_FIELDS%51718348027F.attr preserve=no  private: string {U} 
      string m_strQUESTION_FIELDS;
      //## end emscommand::CaseUpdateCommand::QUESTION_FIELDS%51718348027F.attr

      //## Attribute: QuestionnaireUpdated%517185380374
      //## begin emscommand::CaseUpdateCommand::QuestionnaireUpdated%517185380374.attr preserve=no  private: bool {U} false
      bool m_bQuestionnaireUpdated;
      //## end emscommand::CaseUpdateCommand::QuestionnaireUpdated%517185380374.attr

      //## Attribute: USTerritories%511A6A76007C
      //## begin emscommand::CaseUpdateCommand::USTerritories%511A6A76007C.attr preserve=no  public: set<string, less<string> > {U} 
      set<string, less<string> > m_hUSTerritories;
      //## end emscommand::CaseUpdateCommand::USTerritories%511A6A76007C.attr

      //## Attribute: SmartForm%5CFF647F023F
      //## begin emscommand::CaseUpdateCommand::SmartForm%5CFF647F023F.attr preserve=no  private: bool {U} 
      bool m_bSmartForm;
      //## end emscommand::CaseUpdateCommand::SmartForm%5CFF647F023F.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%3EC91F870000
      //## begin emscommand::CaseUpdateCommand::<m_pListSegment>%3EC91F870271.role preserve=no  public: segment::ListSegment { -> 4RFHgN}
      segment::ListSegment *m_pListSegment[4];
      //## end emscommand::CaseUpdateCommand::<m_pListSegment>%3EC91F870271.role

    // Additional Implementation Declarations
      //## begin emscommand::CaseUpdateCommand%35ACB26A01AB.implementation preserve=yes
      //## end emscommand::CaseUpdateCommand%35ACB26A01AB.implementation

};

//## begin emscommand::CaseUpdateCommand%35ACB26A01AB.postscript preserve=yes
//## end emscommand::CaseUpdateCommand%35ACB26A01AB.postscript

} // namespace emscommand

//## begin module%35ACB5CD022A.epilog preserve=yes
using namespace emscommand;
//## end module%35ACB5CD022A.epilog


#endif
