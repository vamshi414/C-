//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3734532D01C0.cm preserve=no
//	$Date:   Apr 13 2015 13:02:20  $ $Author:   e3003354  $
//	$Revision:   1.18  $
//## end module%3734532D01C0.cm

//## begin module%3734532D01C0.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3734532D01C0.cp

//## Module: CXOSEC06%3734532D01C0; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC06.hpp

#ifndef CXOSEC06_h
#define CXOSEC06_h 1

//## begin module%3734532D01C0.additionalIncludes preserve=no
//## end module%3734532D01C0.additionalIncludes

//## begin module%3734532D01C0.includes preserve=yes
// $Date:   Apr 13 2015 13:02:20  $ $Author:   e3003354  $ $Revision:   1.18  $
//## end module%3734532D01C0.includes

#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CasePhaseAffnSegment;
class CasePhaseAustraliaSegment;
class CasePhaseCashStationSegment;
class CasePhaseCirrusSegment;
class CasePhaseMacSegment;
class CasePhaseNyceSegment;
class CasePhasePulseSegment;
class CasePhaseSegment;
class CasePhaseStarSegment;
class CasePhaseVisaSegment;
class CaseTransitionSegment;
class CaseIntegratedCircuitCardSegment;
class CasePreAuthSegment;
class CaseFraudMCSegment;
class CaseFraudSegment;
class CasePhaseInterlinkSegment;
class LineitemSegment;
class CasePaymentSegment;
class RelatedChbSegment;
} // namespace emssegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Row;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
} // namespace segment

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class RelationshipSegment;
} // namespace usersegment

namespace segment {
class PersistentSegment;
class InformationSegment;
class ResponseTimeSegment;
class PrimaryKeySegment;
class ListSegment;

} // namespace segment

//## begin module%3734532D01C0.declarations preserve=no
//## end module%3734532D01C0.declarations

//## begin module%3734532D01C0.additionalDeclarations preserve=yes
//## end module%3734532D01C0.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CasePhaseListCommand%37344F5B01B9.preface preserve=yes
//## end emscommand::CasePhaseListCommand%37344F5B01B9.preface

//## Class: CasePhaseListCommand%37344F5B01B9
//	QEMLPHS - retrieve the list of phases for an EMS case.
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3736E6BA014F;database::Database { -> F}
//## Uses: <unnamed>%3736E6BD02A8;IF::Message { -> F}
//## Uses: <unnamed>%3736E6BF0369;IF::Queue { -> F}
//## Uses: <unnamed>%3739E38E012F;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%3739E3A4025D;segment::InformationSegment { -> F}
//## Uses: <unnamed>%3739E40303B8;segment::ListSegment { -> F}
//## Uses: <unnamed>%3739E42002F1;reusable::Query { -> F}
//## Uses: <unnamed>%3739E4E00275;emssegment::CasePhaseVisaSegment { -> F}
//## Uses: <unnamed>%3739E4E3008F;emssegment::CasePhasePulseSegment { -> F}
//## Uses: <unnamed>%3739E4E502EB;emssegment::CasePhaseNyceSegment { -> F}
//## Uses: <unnamed>%3739E4E80245;emssegment::CasePhaseCashStationSegment { -> F}
//## Uses: <unnamed>%3739E6D3007E;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%3739E72200F0;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%3739E7930323;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3739E7B203AA;emssegment::CaseTransitionSegment { -> F}
//## Uses: <unnamed>%3739E8CA010E;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%3740644F014C;emssegment::CasePhaseAffnSegment { -> F}
//## Uses: <unnamed>%3745B6CC01B9;emssegment::CasePhaseStarSegment { -> F}
//## Uses: <unnamed>%37CB1ED702E5;emssegment::CasePhaseMacSegment { -> F}
//## Uses: <unnamed>%37F0E13201CA;usersegment::RelationshipSegment { -> F}
//## Uses: <unnamed>%38594F2F008B;emssegment::CasePhaseCirrusSegment { -> F}
//## Uses: <unnamed>%3A01BB0D0244;emssegment::CasePhaseAustraliaSegment { -> F}
//## Uses: <unnamed>%3A01BB18024A;monitor::UseCase { -> F}
//## Uses: <unnamed>%3AC0CC8A0095;emssegment::CasePhaseInterlinkSegment { -> F}
//## Uses: <unnamed>%3C5716720166;emssegment::CaseSegment { -> }
//## Uses: <unnamed>%3E39510902FD;repositorysegment::CardholderInformationSegment { -> F}
//## Uses: <unnamed>%3E4D01800157;emssegment::CaseNationalNetworkSegment { -> F}
//## Uses: <unnamed>%3E4D4D6F000F;emssegment::CasePhaseNetworkUniqueSegment { -> F}
//## Uses: <unnamed>%3E4D4E6B03B9;ems::Case { -> F}
//## Uses: <unnamed>%3EF86D2D0128;emssegment::CaseFraudSegment { -> F}
//## Uses: <unnamed>%3EF9C4F4005D;emssegment::CaseFraudMCSegment { -> }
//## Uses: <unnamed>%3FD739580157;emssegment::CaseFraudVNTSegment { -> F}
//## Uses: <unnamed>%4051F7920280;emssegment::CaseAccountHistorySegment { -> F}
//## Uses: <unnamed>%407410B30203;emssegment::CasePreAuthSegment { -> F}
//## Uses: <unnamed>%46963CF7028F;emssegment::CaseIntegratedCircuitCardSegment { -> F}
//## Uses: <unnamed>%5315E8700363;reusable::Row { -> F}
//## Uses: <unnamed>%53E61B94015C;emssegment::CasePaymentSegment { -> F}
//## Uses: <unnamed>%55141F0E0347;emssegment::LineitemSegment { -> F}

class DllExport CasePhaseListCommand : public command::ClientListCommand  //## Inherits: <unnamed>%530F10E40347
{
  //## begin emscommand::CasePhaseListCommand%37344F5B01B9.initialDeclarations preserve=yes
  //## end emscommand::CasePhaseListCommand%37344F5B01B9.initialDeclarations

  public:
    //## Constructors (generated)
      CasePhaseListCommand();

    //## Constructors (specified)
      //## Operation: CasePhaseListCommand%37345C9E0003
      CasePhaseListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CasePhaseListCommand();


    //## Other Operations (specified)
      //## Operation: cleanup%531843E001B6
      void cleanup ();

      //## Operation: getRelatedCaseCHBInfo%4B7414F303A1
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void getRelatedCaseCHBInfo ();

      //## Operation: retrieve%530F11E803C8
      virtual bool retrieve ();

      //## Operation: update%37345CBC0024
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::CasePhaseListCommand%37344F5B01B9.public preserve=yes
      //## end emscommand::CasePhaseListCommand%37344F5B01B9.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::CasePhaseListCommand%37344F5B01B9.protected preserve=yes
      //## end emscommand::CasePhaseListCommand%37344F5B01B9.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CasePhaseListCommand%37344F5B01B9.private preserve=yes
      //## end emscommand::CasePhaseListCommand%37344F5B01B9.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: SEQ_NO%471884B4026F
      //## begin emscommand::CasePhaseListCommand::SEQ_NO%471884B4026F.attr preserve=no  private: short {U} 
      short m_siSEQ_NO;
      //## end emscommand::CasePhaseListCommand::SEQ_NO%471884B4026F.attr

      //## Attribute: szBuffer%530F14040328
      //## begin emscommand::CasePhaseListCommand::szBuffer%530F14040328.attr preserve=no  private: char* {U} 
      char* m_pszBuffer;
      //## end emscommand::CasePhaseListCommand::szBuffer%530F14040328.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%3EF9B887000F
      //## Role: CasePhaseListCommand::<m_pCaseFraudMCSegment>%3EF9B88701F4
      //## begin emscommand::CasePhaseListCommand::<m_pCaseFraudMCSegment>%3EF9B88701F4.role preserve=no  public: emssegment::CaseFraudMCSegment { -> RFHgN}
      emssegment::CaseFraudMCSegment *m_pCaseFraudMCSegment;
      //## end emscommand::CasePhaseListCommand::<m_pCaseFraudMCSegment>%3EF9B88701F4.role

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4B7414D000C0
      //## Role: CasePhaseListCommand::<m_pRelatedChbSegment>%4B7414D20209
      //## begin emscommand::CasePhaseListCommand::<m_pRelatedChbSegment>%4B7414D20209.role preserve=no  public: emssegment::RelatedChbSegment { -> RFHgN}
      emssegment::RelatedChbSegment *m_pRelatedChbSegment;
      //## end emscommand::CasePhaseListCommand::<m_pRelatedChbSegment>%4B7414D20209.role

      //## Association: Connex Library::Command_CAT::<unnamed>%3739E35D0201
      //## Role: CasePhaseListCommand::<m_pPrimaryKeySegment>%3739E35E014E
      //## begin emscommand::CasePhaseListCommand::<m_pPrimaryKeySegment>%3739E35E014E.role preserve=no  public: segment::PrimaryKeySegment { -> RFHgN}
      segment::PrimaryKeySegment *m_pPrimaryKeySegment;
      //## end emscommand::CasePhaseListCommand::<m_pPrimaryKeySegment>%3739E35E014E.role

      //## Association: Connex Library::Command_CAT::<unnamed>%37CB2180032A
      //## Role: CasePhaseListCommand::<m_pPersistentSegment>%37CB218101EB
      //## begin emscommand::CasePhaseListCommand::<m_pPersistentSegment>%37CB218101EB.role preserve=no  public: segment::PersistentSegment { -> RFHgN}
      segment::PersistentSegment *m_pPersistentSegment;
      //## end emscommand::CasePhaseListCommand::<m_pPersistentSegment>%37CB218101EB.role

    // Additional Implementation Declarations
      //## begin emscommand::CasePhaseListCommand%37344F5B01B9.implementation preserve=yes
      //## end emscommand::CasePhaseListCommand%37344F5B01B9.implementation

};

//## begin emscommand::CasePhaseListCommand%37344F5B01B9.postscript preserve=yes
//## end emscommand::CasePhaseListCommand%37344F5B01B9.postscript

} // namespace emscommand

//## begin module%3734532D01C0.epilog preserve=yes
using namespace emscommand;
//## end module%3734532D01C0.epilog


#endif
