//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%49849E8603B9.cm preserve=no
//	$Date:   Jun 18 2019 15:04:32  $ $Author:   e1089842  $
//	$Revision:   1.17  $
//## end module%49849E8603B9.cm

//## begin module%49849E8603B9.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%49849E8603B9.cp

//## Module: CXOSEC24%49849E8603B9; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\bV03.0A.R006\Windows\Build\Dn\Server\Library\Ecdll\CXODEC24.hpp

#ifndef CXOSEC24_h
#define CXOSEC24_h 1

//## begin module%49849E8603B9.additionalIncludes preserve=no
//## end module%49849E8603B9.additionalIncludes

//## begin module%49849E8603B9.includes preserve=yes
#include "CXODBS01.hpp"
//## end module%49849E8603B9.includes

#ifndef CXOSBC19_h
#include "CXODBC19.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSNetRuleUseTable;
class EMSNetRuleUse;
class Case;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
class CaseCreateCommand;
class CaseUpdateCommand;
} // namespace emscommand

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseDocumentSegment;
class CaseCommentSegment;
class CasePhaseSegment;
class CasePhaseVisaSegment;
class CaseSegment;
class CaseTransitionSegment;
class CasePaymentSegment;
class CasePreAuthSegment;
class CaseAccountHistorySegment;
class CaseFraudVNTSegment;
class CaseFraudMCSegment;
class CaseFraudSegment;
class CasePhaseMCSegment;
class CaseNationalNetworkSegment;
class CaseEBTSegment;
} // namespace emssegment

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class ContactSegment;
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::EntityHierarchy_CAT%394E27190055
namespace entityhierarchy {
class Contact;
} // namespace entityhierarchy

//## Modelname: DataNavigator Foundation::UserCommand_CAT%394E26E302E3
namespace usercommand {
class GetPreauthTranCommand;
} // namespace usercommand

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class PrimaryKeySegment;
class ListSegment;
class CommonHeaderSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Audit;

} // namespace command

//## begin module%49849E8603B9.declarations preserve=no
//## end module%49849E8603B9.declarations

//## begin module%49849E8603B9.additionalDeclarations preserve=yes
//## end module%49849E8603B9.additionalDeclarations


namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::BatchItem%49849D88030D.preface preserve=yes
//## end emscommand::BatchItem%49849D88030D.preface

//## Class: BatchItem%49849D88030D
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4984B13303D8;monitor::UseCase { -> F}
//## Uses: <unnamed>%4984B15C0128;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%4984B26602DE;command::Audit { -> F}
//## Uses: <unnamed>%4984B6BC01E4;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%4984B6BF0222;emssegment::CaseTransitionSegment { -> F}
//## Uses: <unnamed>%4984B6D402BF;entityhierarchy::Contact { -> F}
//## Uses: <unnamed>%4984B6E400AB;entitysegment::ContactSegment { -> F}
//## Uses: <unnamed>%4984B704031C;entitysegment::Customer { -> F}
//## Uses: <unnamed>%49983C54004E;reusable::Query { -> F}
//## Uses: <unnamed>%49983C65000F;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%49983C7702DE;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%49983D0C03C8;ems::Case { -> F}
//## Uses: <unnamed>%49E5D54500CB;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%4A1C24EF03A9;ems::EMSNetRuleUse { -> F}
//## Uses: <unnamed>%4A1C2533033C;ems::EMSNetRuleUseTable { -> F}
//## Uses: <unnamed>%4A1C25CE009C;emssegment::CasePreAuthSegment { -> F}
//## Uses: <unnamed>%4A1C261B006D;emssegment::CaseNationalNetworkSegment { -> F}
//## Uses: <unnamed>%4A1C26660290;emssegment::CaseFraudSegment { -> F}
//## Uses: <unnamed>%4A1C26DE00AB;emssegment::CaseFraudMCSegment { -> F}
//## Uses: <unnamed>%4A1C27EF02EE;emssegment::CaseFraudVNTSegment { -> F}
//## Uses: <unnamed>%4AA96D330103;database::Database { -> F}
//## Uses: <unnamed>%4AE717E20193;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%4C52D36F00EF;emssegment::CaseDocumentSegment { -> F}
//## Uses: <unnamed>%4C603F4300D4;emssegment::CasePhaseVisaSegment { -> F}
//## Uses: <unnamed>%4C603F5500C4;emssegment::CasePhaseMCSegment { -> F}
//## Uses: <unnamed>%4C603F8C00F2;emssegment::CaseCommentSegment { -> F}
//## Uses: <unnamed>%4D7539A90307;reusable::Statement { -> F}
//## Uses: <unnamed>%53D6C063034C;emssegment::CaseAccountHistorySegment { -> F}
//## Uses: <unnamed>%5404782D0182;emssegment::CasePaymentSegment { -> F}
//## Uses: <unnamed>%5CDA7B520357;IF::Extract { -> F}
//## Uses: <unnamed>%5D0916F10085;emssegment::CaseEBTSegment { -> F}
//## Uses: <unnamed>%5D09176602C3;timer::Date { -> F}

class DllExport BatchItem : public command::ImportTransaction  //## Inherits: <unnamed>%49849DB400BB
{
  //## begin emscommand::BatchItem%49849D88030D.initialDeclarations preserve=yes
  //## end emscommand::BatchItem%49849D88030D.initialDeclarations

  public:
    //## Constructors (generated)
      BatchItem();

    //## Destructor (generated)
      virtual ~BatchItem();


    //## Other Operations (specified)
      //## Operation: addSegments%4984B08E02AF
      virtual void addSegments (command::Audit& hAudit);

      //## Operation: calculateDisputeAmount%5AFBDA9600F3
      bool calculateDisputeAmount ();

      //## Operation: createCase%4A1C058B0290
      bool createCase ();

      //## Operation: instance%4984A8C3033C
      static BatchItem* instance ();

      //## Operation: parse%49849DEB0271
      virtual bool parse (const vector<string>& hDATA_BUFFER);

      //## Operation: relatedFraudCase%53237CF00196
      bool relatedFraudCase ();

      //## Operation: replicate%4D5ADB2603A0
      bool replicate ();

      //## Operation: setCaseCountryIss%4D7537460073
      void setCaseCountryIss ();

      //## Operation: setENTITY_ID%5176A171035C
      virtual void setENTITY_ID ();

      //## Operation: update%5B03AF1B0333
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

      //## Operation: updateCase%4998432901F4
      bool updateCase (const string& strUSER_ID);

      //## Operation: updateFraudCase%53237DDB02A0
      bool updateFraudCase ();

      //## Operation: writeError%4CD032E6019D
      void writeError (int iInfoIDNumber = 0);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Buffe1Len%4FB2811001C4
      const int& getBuffe1Len () const
      {
        //## begin emscommand::BatchItem::getBuffe1Len%4FB2811001C4.get preserve=no
        return m_lBuffe1Len;
        //## end emscommand::BatchItem::getBuffe1Len%4FB2811001C4.get
      }


      //## Attribute: Buffe2Len%4FB2812B0213
      const int& getBuffe2Len () const
      {
        //## begin emscommand::BatchItem::getBuffe2Len%4FB2812B0213.get preserve=no
        return m_lBuffe2Len;
        //## end emscommand::BatchItem::getBuffe2Len%4FB2812B0213.get
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%49A2B88E02CE
      //## Role: BatchItem::<m_pCaseCreateCommand>%49A2B88F0167
      void setCaseCreateCommand (CaseCreateCommand * value)
      {
        //## begin emscommand::BatchItem::setCaseCreateCommand%49A2B88F0167.set preserve=no
        m_pCaseCreateCommand = value;
        //## end emscommand::BatchItem::setCaseCreateCommand%49A2B88F0167.set
      }


      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%49A2B8950109
      //## Role: BatchItem::<m_pCaseUpdateCommand>%49A2B8960000
      void setCaseUpdateCommand (CaseUpdateCommand * value)
      {
        //## begin emscommand::BatchItem::setCaseUpdateCommand%49A2B8960000.set preserve=no
        m_pCaseUpdateCommand = value;
        //## end emscommand::BatchItem::setCaseUpdateCommand%49A2B8960000.set
      }


    // Additional Public Declarations
      //## begin emscommand::BatchItem%49849D88030D.public preserve=yes
      //## end emscommand::BatchItem%49849D88030D.public

  protected:
    // Data Members for Class Attributes

      //## begin emscommand::BatchItem::Buffe1Len%4FB2811001C4.attr preserve=no  public: int {V} 0
      int m_lBuffe1Len;
      //## end emscommand::BatchItem::Buffe1Len%4FB2811001C4.attr

      //## begin emscommand::BatchItem::Buffe2Len%4FB2812B0213.attr preserve=no  public: int {V} 0
      int m_lBuffe2Len;
      //## end emscommand::BatchItem::Buffe2Len%4FB2812B0213.attr

      //## Attribute: Segments%4C4F375F039C
      //## begin emscommand::BatchItem::Segments%4C4F375F039C.attr preserve=no  protected: vector<Segment*> {UA} 
      vector<Segment*> m_hSegments;
      //## end emscommand::BatchItem::Segments%4C4F375F039C.attr

    // Additional Protected Declarations
      //## begin emscommand::BatchItem%49849D88030D.protected preserve=yes
      //## end emscommand::BatchItem%49849D88030D.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::BatchItem%49849D88030D.private preserve=yes
      //## end emscommand::BatchItem%49849D88030D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%4C4F36F802AE
      //## begin emscommand::BatchItem::Buffer%4C4F36F802AE.attr preserve=no  private: char* {U} 0
      char* m_pBuffer;
      //## end emscommand::BatchItem::Buffer%4C4F36F802AE.attr

      //## Attribute: Buffer1%4FB280E70216
      //## begin emscommand::BatchItem::Buffer1%4FB280E70216.attr preserve=no  private: char* {U} 0
      char* m_pBuffer1;
      //## end emscommand::BatchItem::Buffer1%4FB280E70216.attr

      //## Attribute: Buffer2%4FB280E901E0
      //## begin emscommand::BatchItem::Buffer2%4FB280E901E0.attr preserve=no  private: char* {U} 0
      char* m_pBuffer2;
      //## end emscommand::BatchItem::Buffer2%4FB280E901E0.attr

      //## Attribute: FraudCaseNo%532B3BBB03B7
      //## begin emscommand::BatchItem::FraudCaseNo%532B3BBB03B7.attr preserve=no  private: string {V} 
      string m_strFraudCaseNo;
      //## end emscommand::BatchItem::FraudCaseNo%532B3BBB03B7.attr

      //## Attribute: Instance%4984A8B003A9
      //## begin emscommand::BatchItem::Instance%4984A8B003A9.attr preserve=no  private: static BatchItem* {V} 0
      static BatchItem* m_pInstance;
      //## end emscommand::BatchItem::Instance%4984A8B003A9.attr

      //## Attribute: QuestionnaireFields%5CDA7AE80399
      //## begin emscommand::BatchItem::QuestionnaireFields%5CDA7AE80399.attr preserve=no  private: string {U} 
      string m_strQuestionnaireFields;
      //## end emscommand::BatchItem::QuestionnaireFields%5CDA7AE80399.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%49A2B88E02CE
      //## begin emscommand::BatchItem::<m_pCaseCreateCommand>%49A2B88F0167.role preserve=no  public: emscommand::CaseCreateCommand { -> RFHgN}
      CaseCreateCommand *m_pCaseCreateCommand;
      //## end emscommand::BatchItem::<m_pCaseCreateCommand>%49A2B88F0167.role

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%49A2B8950109
      //## begin emscommand::BatchItem::<m_pCaseUpdateCommand>%49A2B8960000.role preserve=no  public: emscommand::CaseUpdateCommand { -> RFHgN}
      CaseUpdateCommand *m_pCaseUpdateCommand;
      //## end emscommand::BatchItem::<m_pCaseUpdateCommand>%49A2B8960000.role

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4C502C61034D
      //## Role: BatchItem::<m_pPrimaryKeySegment>%4C502C620243
      //## begin emscommand::BatchItem::<m_pPrimaryKeySegment>%4C502C620243.role preserve=no  public: segment::PrimaryKeySegment { -> RFHgN}
      segment::PrimaryKeySegment *m_pPrimaryKeySegment;
      //## end emscommand::BatchItem::<m_pPrimaryKeySegment>%4C502C620243.role

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4F2022CA02E3
      //## Role: BatchItem::<m_pGetPreauthTranCommand>%4F2022CB0225
      //## begin emscommand::BatchItem::<m_pGetPreauthTranCommand>%4F2022CB0225.role preserve=no  public: usercommand::GetPreauthTranCommand { -> RFHgN}
      usercommand::GetPreauthTranCommand *m_pGetPreauthTranCommand;
      //## end emscommand::BatchItem::<m_pGetPreauthTranCommand>%4F2022CB0225.role

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%5CDA7A0101C4
      //## Role: BatchItem::<m_pListSegment>%5CDA7A02007C
      //## begin emscommand::BatchItem::<m_pListSegment>%5CDA7A02007C.role preserve=no  public: segment::ListSegment { -> 1RFHgN}
      segment::ListSegment *m_pListSegment;
      //## end emscommand::BatchItem::<m_pListSegment>%5CDA7A02007C.role

    // Additional Implementation Declarations
      //## begin emscommand::BatchItem%49849D88030D.implementation preserve=yes
      //## end emscommand::BatchItem%49849D88030D.implementation

};

//## begin emscommand::BatchItem%49849D88030D.postscript preserve=yes
//## end emscommand::BatchItem%49849D88030D.postscript

} // namespace emscommand

//## begin module%49849E8603B9.epilog preserve=yes
//## end module%49849E8603B9.epilog


#endif
