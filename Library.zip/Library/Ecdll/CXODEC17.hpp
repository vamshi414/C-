//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3F7AEF0C0261.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3F7AEF0C0261.cm

//## begin module%3F7AEF0C0261.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3F7AEF0C0261.cp

//## Module: CXOSEC17%3F7AEF0C0261; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC17.hpp

#ifndef CXOSEC17_h
#define CXOSEC17_h 1

//## begin module%3F7AEF0C0261.additionalIncludes preserve=no
//## end module%3F7AEF0C0261.additionalIncludes

//## begin module%3F7AEF0C0261.includes preserve=yes
// $Date:   Apr 09 2004 12:32:46  $ $Author:   D02405  $ $Revision:   1.1  $
//## end module%3F7AEF0C0261.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class PrimaryKeySegment;

} // namespace segment

//## begin module%3F7AEF0C0261.declarations preserve=no
//## end module%3F7AEF0C0261.declarations

//## begin module%3F7AEF0C0261.additionalDeclarations preserve=yes
//## end module%3F7AEF0C0261.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.preface preserve=yes
//## end emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.preface

//## Class: CaseFeeControlNumberCommand%3F7AFCB001D4
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3F7B02EB00DA;monitor::UseCase { -> F}
//## Uses: <unnamed>%3F7B039900BB;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%3F7B03A60128;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%3F7B03BD02BF;reusable::Query { -> F}
//## Uses: <unnamed>%3F7B03E6037A;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%3F7B041601E4;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3F7B048D01E4;segment::InformationSegment { -> F}
//## Uses: <unnamed>%3F7B1AD3002E;segment::GenericSegment { -> F}
//## Uses: <unnamed>%3F7B1BF50251;ems::NationalException { -> F}
//## Uses: <unnamed>%3F7C4C70031C;IF::Message { -> F}

class DllExport CaseFeeControlNumberCommand : public command::ClientCommand  //## Inherits: <unnamed>%3F7AFD9800DA
{
  //## begin emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.initialDeclarations preserve=yes
  //## end emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.initialDeclarations

  public:
    //## Constructors (generated)
      CaseFeeControlNumberCommand();

    //## Constructors (specified)
      //## Operation: CaseFeeControlNumberCommand%3F7B01840251
      CaseFeeControlNumberCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseFeeControlNumberCommand();


    //## Other Operations (specified)
      //## Operation: execute%3F7B01840271
      //	Perform the functions of this command.
      virtual bool execute ();

    // Additional Public Declarations
      //## begin emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.public preserve=yes
      //## end emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.protected preserve=yes
      //## end emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.private preserve=yes
      //## end emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%3F7AFE6E0196
      //## Role: CaseFeeControlNumberCommand::<m_pPrimaryKeySegment>%3F7AFE6E03D8
      //## begin emscommand::CaseFeeControlNumberCommand::<m_pPrimaryKeySegment>%3F7AFE6E03D8.role preserve=no  public: segment::PrimaryKeySegment { -> RFHgN}
      segment::PrimaryKeySegment *m_pPrimaryKeySegment;
      //## end emscommand::CaseFeeControlNumberCommand::<m_pPrimaryKeySegment>%3F7AFE6E03D8.role

    // Additional Implementation Declarations
      //## begin emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.implementation preserve=yes
      //## end emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.implementation

};

//## begin emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.postscript preserve=yes
//## end emscommand::CaseFeeControlNumberCommand%3F7AFCB001D4.postscript

} // namespace emscommand

//## begin module%3F7AEF0C0261.epilog preserve=yes
//## end module%3F7AEF0C0261.epilog


#endif
