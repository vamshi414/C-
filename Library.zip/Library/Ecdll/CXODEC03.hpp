//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35BF3BB901C2.cm preserve=no
//	$Date:   Jan 25 2016 12:00:32  $ $Author:   e1009591  $
//	$Revision:   1.19  $
//## end module%35BF3BB901C2.cm

//## begin module%35BF3BB901C2.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%35BF3BB901C2.cp

//## Module: CXOSEC03%35BF3BB901C2; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\bV02.5B.R011\Windows\Build\Dn\Server\Library\Ecdll\CXODEC03.hpp

#ifndef CXOSEC03_h
#define CXOSEC03_h 1

//## begin module%35BF3BB901C2.additionalIncludes preserve=no
//## end module%35BF3BB901C2.additionalIncludes

//## begin module%35BF3BB901C2.includes preserve=yes
// $Date:   Jan 25 2016 12:00:32  $ $Author:   e1009591  $ $Revision:   1.19  $
//## end module%35BF3BB901C2.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;
class Case;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
class CaseHighlightCommand;
} // namespace emscommand

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CasePhaseSegment;
class CaseSegment;
class CaseLockSegment;
} // namespace emssegment

//## Modelname: DataNavigator Foundation::EntityHierarchy_CAT%394E27190055
namespace entityhierarchy {
class ReportingHierarchy;
} // namespace entityhierarchy

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;
class Message;
class Memory;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class ResponseTimeSegment;
class MultipleRowContextSegment;
class ListSegment;
class CommonHeaderSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class SOAPCommand;
} // namespace command

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class RelationshipSegment;
} // namespace usersegment

//## Modelname: Connex Library::ViewSegment_CAT%394E276801C1
namespace viewsegment {
class WorkQueue;
class ReportOptionSegment;

} // namespace viewsegment

//## begin module%35BF3BB901C2.declarations preserve=no
//## end module%35BF3BB901C2.declarations

//## begin module%35BF3BB901C2.additionalDeclarations preserve=yes
//## end module%35BF3BB901C2.additionalDeclarations


namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseListCommand%357EC619002A.preface preserve=yes
//## end emscommand::CaseListCommand%357EC619002A.preface

//## Class: CaseListCommand%357EC619002A
//	QEMLCASE - retrieve a list of EMS cases.
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%35BF3CC900AB;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%35BF5D7C03A1;segment::InformationSegment { -> F}
//## Uses: <unnamed>%36C08CE90259;IF::Message { -> F}
//## Uses: <unnamed>%36C08D0C012D;reusable::Query { -> F}
//## Uses: <unnamed>%36C0ADEE022C;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%36C0AE2201F4;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%36C0AE730133;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3736EF6A00CB;database::Database { -> F}
//## Uses: <unnamed>%3736EFB0011B;IF::Queue { -> F}
//## Uses: <unnamed>%373C38F400B5;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%373C39150329;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%3741C70C0284;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%37F0E0DF01E8;usersegment::RelationshipSegment { -> F}
//## Uses: <unnamed>%388F0C130199;viewsegment::WorkQueue { -> F}
//## Uses: <unnamed>%3A00932B0198;monitor::UseCase { -> F}
//## Uses: <unnamed>%3A01B6010098;entityhierarchy::ReportingHierarchy { -> F}
//## Uses: <unnamed>%3A75992501C3;timer::Date { -> F}
//## Uses: <unnamed>%3C34A73B01BD;viewsegment::ReportOptionSegment { -> F}
//## Uses: <unnamed>%3F74516201E4;reusable::FormatSelectVisitor { -> F}
//## Uses: <unnamed>%40D0676E005D;CaseHighlightCommand { -> F}
//## Uses: <unnamed>%40D067E90222;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%4AF32FE8021A;ems::Case { -> F}

class DllExport CaseListCommand : public command::ClientCommand  //## Inherits: <unnamed>%35978AE500BE
{
  //## begin emscommand::CaseListCommand%357EC619002A.initialDeclarations preserve=yes
  //## end emscommand::CaseListCommand%357EC619002A.initialDeclarations

  public:
    //## Constructors (generated)
      CaseListCommand();

    //## Constructors (specified)
      //## Operation: CaseListCommand%3731DA1B0065
      CaseListCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseListCommand();


    //## Other Operations (specified)
      //## Operation: bindExtraTables%52C5C0F50098
      virtual void bindExtraTables (reusable::Query& hQuery);

      //## Operation: execute%36C0832F019A
      //	Perform the functions of this command.
      bool execute ();

      //## Operation: formatSQL%36C097550179
      void formatSQL (Query& hQuery);

      //## Operation: getRelatedCases%49AC020000DA
      void getRelatedCases ();

      //## Operation: joinExtraTables%52C5C0DB0128
      virtual void joinExtraTables (reusable::Query& hQuery);

      //## Operation: parse%35BF3C48004B
      virtual int parse ();

      //## Operation: update%36C083320235
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::CaseListCommand%357EC619002A.public preserve=yes
      //## end emscommand::CaseListCommand%357EC619002A.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: CASE_NO%40CD92A1035B
      //## begin emscommand::CaseListCommand::CASE_NO%40CD92A1035B.attr preserve=no  public: string {U} 
      string m_strCASE_NO;
      //## end emscommand::CaseListCommand::CASE_NO%40CD92A1035B.attr

      //## Attribute: DiscardRecords%40CD95B8000F
      //## begin emscommand::CaseListCommand::DiscardRecords%40CD95B8000F.attr preserve=no  public: bool {U} 
      bool m_bDiscardRecords;
      //## end emscommand::CaseListCommand::DiscardRecords%40CD95B8000F.attr

      //## Attribute: PhaseCursor%373C3A1F0277
      //## begin emscommand::CaseListCommand::PhaseCursor%373C3A1F0277.attr preserve=no  public: char {R} 0
      char *m_pPhaseCursor;
      //## end emscommand::CaseListCommand::PhaseCursor%373C3A1F0277.attr

      //## Attribute: RecordsReturnedThisMessage%36C0B13D0085
      //## begin emscommand::CaseListCommand::RecordsReturnedThisMessage%36C0B13D0085.attr preserve=no  public: int {U} 0
      int m_lRecordsReturnedThisMessage;
      //## end emscommand::CaseListCommand::RecordsReturnedThisMessage%36C0B13D0085.attr

      //## Attribute: TotalRecordsFound%36C0B11F0032
      //## begin emscommand::CaseListCommand::TotalRecordsFound%36C0B11F0032.attr preserve=no  public: int {U} 0
      int m_lTotalRecordsFound;
      //## end emscommand::CaseListCommand::TotalRecordsFound%36C0B11F0032.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%4A3AA5E90280
      //## Role: CaseListCommand::<m_pCaseLockSegment>%4A3AA5EA035B
      //## begin emscommand::CaseListCommand::<m_pCaseLockSegment>%4A3AA5EA035B.role preserve=no  public: emssegment::CaseLockSegment { -> RFHgN}
      emssegment::CaseLockSegment *m_pCaseLockSegment;
      //## end emscommand::CaseListCommand::<m_pCaseLockSegment>%4A3AA5EA035B.role

    // Additional Protected Declarations
      //## begin emscommand::CaseListCommand%357EC619002A.protected preserve=yes
      segment::MultipleRowContextSegment *m_pMultipleRowContextSegment;
      //## end emscommand::CaseListCommand%357EC619002A.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseListCommand%357EC619002A.private preserve=yes
      //## end emscommand::CaseListCommand%357EC619002A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: OrderByClause%40CD9CFB0242
      //## begin emscommand::CaseListCommand::OrderByClause%40CD9CFB0242.attr preserve=no  private: string {U} 
      string m_strOrderByClause;
      //## end emscommand::CaseListCommand::OrderByClause%40CD9CFB0242.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%3C34A7A40006
      //## Role: CaseListCommand::<m_pListSegment>%3C34A7A5004D
      //## begin emscommand::CaseListCommand::<m_pListSegment>%3C34A7A5004D.role preserve=no  public: segment::ListSegment { -> RFHgN}
      segment::ListSegment *m_pListSegment;
      //## end emscommand::CaseListCommand::<m_pListSegment>%3C34A7A5004D.role

      //## Association: Transaction Research and Adjustments::EMSCommand_CAT::<unnamed>%55705DF9009E
      //## Role: CaseListCommand::<m_pSOAPCommand>%55705DFA0041
      //## begin emscommand::CaseListCommand::<m_pSOAPCommand>%55705DFA0041.role preserve=no  public: command::SOAPCommand { -> RFHgN}
      command::SOAPCommand *m_pSOAPCommand;
      //## end emscommand::CaseListCommand::<m_pSOAPCommand>%55705DFA0041.role

      //## Association: Connex Library::Command_CAT::<unnamed>%35BF3D2100A7
      //## Role: CaseListCommand::<m_pMultipleRowContextSegment>%35BF3D2201AD
      //## begin emscommand::CaseListCommand::<m_pMultipleRowContextSegment>%35BF3D2201AD.role preserve=no  protected: segment::MultipleRowContextSegment { -> RFHgN}
      //## end emscommand::CaseListCommand::<m_pMultipleRowContextSegment>%35BF3D2201AD.role

      //## Association: Connex Library::Command_CAT::<unnamed>%373C3086021A
      //## Role: CaseListCommand::<m_pMemory>%373C30870276
      //## begin emscommand::CaseListCommand::<m_pMemory>%373C30870276.role preserve=no  public: IF::Memory { -> RFHgN}
      IF::Memory *m_pMemory;
      //## end emscommand::CaseListCommand::<m_pMemory>%373C30870276.role

    // Additional Implementation Declarations
      //## begin emscommand::CaseListCommand%357EC619002A.implementation preserve=yes
      //## end emscommand::CaseListCommand%357EC619002A.implementation

};

//## begin emscommand::CaseListCommand%357EC619002A.postscript preserve=yes
//## end emscommand::CaseListCommand%357EC619002A.postscript

} // namespace emscommand

//## begin module%35BF3BB901C2.epilog preserve=yes
using namespace emscommand;
//## end module%35BF3BB901C2.epilog


#endif
