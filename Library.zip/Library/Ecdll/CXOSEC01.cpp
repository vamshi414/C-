//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35758F6B03D2.cm preserve=no
//	$Date:   Feb 05 2021 04:34:54  $ $Author:   e3028298  $
//	$Revision:   1.173.1.18.1.3  $
//## end module%35758F6B03D2.cm

//## begin module%35758F6B03D2.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%35758F6B03D2.cp

//## Module: CXOSEC01%35758F6B03D2; Package body
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel_July\Dn\Server\Library\Ecdll\CXOSEC01.cpp

//## begin module%35758F6B03D2.additionalIncludes preserve=no
//## end module%35758F6B03D2.additionalIncludes

//## begin module%35758F6B03D2.includes preserve=yes
#include "CXODES96.hpp"
#include "CXODES28.hpp"
#include "CXODES33.hpp"
#include "CXODES41.hpp"
#include "CXODRS51.hpp"
#include "CXODIF03.hpp"
#include "CXODIF25.hpp"
#include "CXODDB27.hpp"
#include "CXODDB06.hpp"
#include "CXODDB46.hpp"
#include "CXODNS29.hpp"
#include "CXODEX69.hpp"
#include "CXODEX91.hpp"
#include "CXODRU28.hpp"
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%35758F6B03D2.includes

#ifndef CXOSAR03_h
#include "CXODAR03.hpp"
#endif
#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif
#ifndef CXOSES61_h
#include "CXODES61.hpp"
#endif
#ifndef CXOSES60_h
#include "CXODES60.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSES76_h
#include "CXODES76.hpp"
#endif
#ifndef CXOSES72_h
#include "CXODES72.hpp"
#endif
#ifndef CXOSES91_h
#include "CXODES91.hpp"
#endif
#ifndef CXOSES94_h
#include "CXODES94.hpp"
#endif
#ifndef CXOSNC32_h
#include "CXODNC32.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSEX01_h
#include "CXODEX01.hpp"
#endif
#ifndef CXOSES02_h
#include "CXODES02.hpp"
#endif
#ifndef CXOSRC05_h
#include "CXODRC05.hpp"
#endif
#ifndef CXOSUS05_h
#include "CXODUS05.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSIF36_h
#include "CXODIF36.hpp"
#endif
#ifndef CXOSRS36_h
#include "CXODRS36.hpp"
#endif
#ifndef CXOSEX03_h
#include "CXODEX03.hpp"
#endif
#ifndef CXOSDB17_h
#include "CXODDB17.hpp"
#endif
#ifndef CXOSES34_h
#include "CXODES34.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSES38_h
#include "CXODES38.hpp"
#endif
#ifndef CXOSES37_h
#include "CXODES37.hpp"
#endif
#ifndef CXOSES18_h
#include "CXODES18.hpp"
#endif
#ifndef CXOSEX27_h
#include "CXODEX27.hpp"
#endif
#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOSES36_h
#include "CXODES36.hpp"
#endif
#ifndef CXOSES45_h
#include "CXODES45.hpp"
#endif
#ifndef CXOSEX36_h
#include "CXODEX36.hpp"
#endif
#ifndef CXOSEX15_h
#include "CXODEX15.hpp"
#endif
#ifndef CXOSEX16_h
#include "CXODEX16.hpp"
#endif
#ifndef CXOSEC01_h
#include "CXODEC01.hpp"
#endif


//## begin module%35758F6B03D2.declarations preserve=no
//## end module%35758F6B03D2.declarations

//## begin module%35758F6B03D2.additionalDeclarations preserve=yes
#define STS_MISSING_CASE_PHASE_SEGMENT             42
#define STS_MISSING_TRANSITION_SEGMENT             43
#define STS_CASE_CHANGED_FROM_MANUAL               77
#define STS_CASE_CHANGED_FROM_MANUAL_2ND_NOT_FOUND 78
#define STS_CASE_ADDED_2ND_NOT_FOUND               79
#define STS_CASE_CHANGED_FROM_MANUAL_2ND_DUPLICATE 80
#define STS_CASE_ADDED_2ND_DUPLICATE               81
#define STS_CANNOT_ADD_2ND_CASE                    82
#define STS_CASE_CHANGED_FROM_MANUAL_2ND_ADDED     83
#define STS_2ND_CASE_CONTACT_NOT_FOUND             86
#define MAXRECORD 2000
//## end module%35758F6B03D2.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

// Class emscommand::CaseCreateCommand 

//## begin emscommand::CaseCreateCommand::Instance%4B9F8E980263.attr preserve=no  private: static emscommand::CaseCreateCommand* {V} 0
emscommand::CaseCreateCommand* CaseCreateCommand::m_pInstance = 0;
//## end emscommand::CaseCreateCommand::Instance%4B9F8E980263.attr

CaseCreateCommand::CaseCreateCommand()
  //## begin CaseCreateCommand::CaseCreateCommand%357453C2017E_const.hasinit preserve=no
  //## end CaseCreateCommand::CaseCreateCommand%357453C2017E_const.hasinit
  //## begin CaseCreateCommand::CaseCreateCommand%357453C2017E_const.initialization preserve=yes
  : ClientCommand("S0003D"),m_bOCS(false)
  //## end CaseCreateCommand::CaseCreateCommand%357453C2017E_const.initialization
{
  //## begin emscommand::CaseCreateCommand::CaseCreateCommand%357453C2017E_const.body preserve=yes
   memcpy(m_sID,"EC01",4);
   IString strRecord;
   if (Extract::instance()->get("DUSER   ",strRecord))
      m_bOCS = (strRecord.indexOf("OCS") > 0);
   Extract::instance()->getSpec("CUSTOMER",m_strCUST_ID);
   Case::addCaseCommandSegments(m_hSegments);
   m_pListSegment[0] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[0]);
   m_pListSegment[1] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[1]);
   m_pListSegment[2] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[2]);
   m_pListSegment[3] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[3]);
   m_pInstance = this;
   m_hUSTerritories.insert("USA");
   m_hUSTerritories.insert("GUM");
   m_hUSTerritories.insert("ASM");
   m_hUSTerritories.insert("MNP");
   m_hUSTerritories.insert("UMI");
   m_hUSTerritories.insert("PRI");
   m_hUSTerritories.insert("VIR");
  //## end emscommand::CaseCreateCommand::CaseCreateCommand%357453C2017E_const.body
}

CaseCreateCommand::CaseCreateCommand (Handler* pSuccessor)
  //## begin emscommand::CaseCreateCommand::CaseCreateCommand%3731DCC30258.hasinit preserve=no
  //## end emscommand::CaseCreateCommand::CaseCreateCommand%3731DCC30258.hasinit
  //## begin emscommand::CaseCreateCommand::CaseCreateCommand%3731DCC30258.initialization preserve=yes
  : ClientCommand("S0003D", "@##EMCCASE"), m_bOCS(false)
  //## end emscommand::CaseCreateCommand::CaseCreateCommand%3731DCC30258.initialization
{
  //## begin emscommand::CaseCreateCommand::CaseCreateCommand%3731DCC30258.body preserve=yes
   memcpy(m_sID,"EC01",4);
   IString strRecord;
   if (Extract::instance()->get("DUSER   ",strRecord))
      m_bOCS = (strRecord.indexOf("OCS") > 0);
   Extract::instance()->getSpec("CUSTOMER",m_strCUST_ID);
   m_pSuccessor = pSuccessor;
   Case::addCaseCommandSegments(m_hSegments);
   m_pListSegment[0] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[0]);
   m_pListSegment[1] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[1]);
   m_pListSegment[2] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[2]);
   m_pListSegment[3] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[3]);
   m_hUSTerritories.insert("USA");
   m_hUSTerritories.insert("GUM");
   m_hUSTerritories.insert("ASM");
   m_hUSTerritories.insert("MNP");
   m_hUSTerritories.insert("UMI");
   m_hUSTerritories.insert("PRI");
   m_hUSTerritories.insert("VIR");
   m_pInstance = this;
  //## end emscommand::CaseCreateCommand::CaseCreateCommand%3731DCC30258.body
}


CaseCreateCommand::~CaseCreateCommand()
{
  //## begin emscommand::CaseCreateCommand::~CaseCreateCommand%357453C2017E_dest.body preserve=yes
   Database::instance()->detach(this);
   delete m_pListSegment[0];
   delete m_pListSegment[1];
   delete m_pListSegment[2];
   delete m_pListSegment[3];
  //## end emscommand::CaseCreateCommand::~CaseCreateCommand%357453C2017E_dest.body
}



//## Other Operations (implementation)
void CaseCreateCommand::calculateSurcharge ()
{
  //## begin emscommand::CaseCreateCommand::calculateSurcharge%5149FB5E0227.body preserve=yes
   if (CaseSegment::instance()->getMERCHANT_CAT_CODE() != "6011" 
      && m_hUSTerritories.find(CaseSegment::instance()->getCARD_ACPT_COUNTRY()) == m_hUSTerritories.end())
      return;
   string strTRAN_TYPE_ID(CaseSegment::instance()->getTRAN_TYPE_ID());
   double dAMT_SURCHARGE_FEE = CaseSegment::instance()->getAMT_SURCHARGE_FEE();
   double dAMT_RECON_NET = CaseSegment::instance()->getAMT_RECON_NET();
   double dAMT_ADJUSTMENT = CasePhaseSegment::instance()->getAMT_ADJUSTMENT();
   bool bFull=true;
            
   if (strTRAN_TYPE_ID.length() > 1 && strTRAN_TYPE_ID.substr(0,2) == "01"      // withdrawal
      && dAMT_ADJUSTMENT < (dAMT_RECON_NET - dAMT_SURCHARGE_FEE))
      bFull = false;
   if (strTRAN_TYPE_ID.length() > 1 && strTRAN_TYPE_ID.substr(0,2) != "01")     
   {
      if (CaseTransitionSegment::instance()->getREQUEST_TYPE_NEXT().substr(0,3) == "ADJ")
      {
         if (dAMT_ADJUSTMENT != dAMT_RECON_NET)  //adj amt can be > tran amt
            bFull = false;
      }
      else if (dAMT_ADJUSTMENT < dAMT_RECON_NET)
         bFull = false;
   }
   if(bFull)  // both chb and adj comes here
      CasePhaseSegment::instance()->setAMT_SURCHARGE(CaseSegment::instance()->getAMT_SURCHARGE_FEE());
   else
   { // make zero surcharge internally also
      if (CaseSegment::instance()->getMERCHANT_CAT_CODE() == "6011")
         CasePhaseSegment::instance()->setAMT_SURCHARGE(0);
      else if (dAMT_RECON_NET != 0)
         CasePhaseSegment::instance()->setAMT_SURCHARGE(dAMT_SURCHARGE_FEE * (dAMT_ADJUSTMENT/(dAMT_RECON_NET-dAMT_SURCHARGE_FEE)));
   }
  //## end emscommand::CaseCreateCommand::calculateSurcharge%5149FB5E0227.body
}

bool CaseCreateCommand::createAcqCase (const string& strCustomer, const string& strQualifier, const string& strNetwork)
{
  //## begin emscommand::CaseCreateCommand::createAcqCase%4E3827B001AE.body preserve=yes
   CaseSegment::instance()->setTSTAMP_TRANS("");
   bool bSuccess = true;
   string strRecord;
   string strBegin("000000");
   string strEnd("000000");
   if (!Case::instance()->findLocator(" ",strBegin,strEnd))
      return false;
   if (Case::instance()->retrieveTransaction("I",true,true,true,"*","A") == false)
      return false;
   ArchiveRetriever::instance()->closeArchive();
   int lCASE_ID(CaseSegment::instance()->getCASE_ID());
   CaseSegment::instance()->setISS_CASE_NO(CaseSegment::instance()->getCASE_NO());
   CaseSegment::instance()->setISS_CUST_ID(strCustomer);
   Transaction::instance()->setCustomer(strNetwork);
   if (Extract::instance()->getRecord("DSPEC   EC01    RESETRULE~", strRecord) && strRecord.length() >= 30
      && (memcmp(strNetwork.data(), strRecord.data() + 26, 4) == 0))
   {
      EMSNetRuleUse hEMSNetRuleUse(true);
      if (EMSNetRuleUseTable::instance()->get(hEMSNetRuleUse, reusable::Transaction::instance()->getCustomer()))
         CaseSegment::instance()->setNET_RULES(hEMSNetRuleUse.getNETWORK_RULES());
   }
   bSuccess = createCase(false);
   if (m_lInfoIDNumber == STS_DUPLICATE_RECORD)
      bSuccess = true;
   CaseSegment hCaseSegment(*CaseSegment::instance());
   if (bSuccess)
   {  
      replicateOtherCase();
      *CaseSegment::instance() = hCaseSegment;
   }
   Transaction::instance()->setQualifier(strQualifier);
   Transaction::instance()->setCustomer(strCustomer);
   if (bSuccess)
   {
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      Table hTable("EMS_CASE");
      hTable.set("CASE_ID",lCASE_ID,true);
      hTable.set("ACQ_CASE_NO",CaseSegment::instance()->getCASE_NO());
      hTable.set("ACQ_CUST_ID",strNetwork);
      bSuccess = pUpdateStatement->execute(hTable);
      m_hCaseSegment[0].setACQ_CASE_NO(CaseSegment::instance()->getCASE_NO());
      m_hCaseSegment[0].setACQ_CUST_ID(strNetwork);
   }
   else
      Transaction::instance()->setText(strNetwork);
   return bSuccess;
  //## end emscommand::CaseCreateCommand::createAcqCase%4E3827B001AE.body
}

bool CaseCreateCommand::createCase (bool bFirstCase)
{
  //## begin emscommand::CaseCreateCommand::createCase%3BFE765C0297.body preserve=yes
//ICS CONVERSION - start
   bool bConversionCase(false);
   if (Extract::instance()->getCustomCode() == "EBT" && CaseSegment::instance()->getCaseSource() == "X")
   {
      if (PanPrefixSegment::instance()->getINST_ID().empty()
         && !EMSRulesEngine::instance()->getPanPrefix(CaseSegment::instance()->getPAN(), CaseSegment::instance()->getNET_ID_EMS()))
      {
         Trace::put("CaseCreateCommand::createCase - Unable to retrieve INST_ID for PAN prefix",CaseSegment::instance()->getPAN_PREFIX());
      }
      else
      {
         CardholderInformationSegment::instance()->setCARD_ISS_INST_ID(PanPrefixSegment::instance()->getINST_ID());
         CardholderInformationSegment::instance()->setCUST_ID(Transaction::instance()->getCustomer());
         CardholderInformationSegment::instance()->setCUST_STAT(" ");
         CardholderInformationSegment::instance()->setINST_STAT(" ");
         CardholderInformationSegment hCardholderInformationSegment(*CardholderInformationSegment::instance());
         Query hQuery;
         auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
         CardholderInformationSegment::instance()->bind(hQuery);
         hQuery.setBasicPredicate("CARDHOLDER", "PAN", "=", CaseSegment::instance()->getPAN().c_str());
         if (pSelectStatement->execute(hQuery) == false)
            return false;
         CardholderInformationSegment::instance()->merge(hCardholderInformationSegment);
         CardholderInformationSegment::instance()->setPresence(true);
      }
   }
   if (!strcmp(CaseSegment::instance()->getISS_USER_ID().c_str(),"CONVERT") ||
       !strcmp(CaseSegment::instance()->getACQ_USER_ID().c_str(),"CONVERT"))
      if (!strcmp(CaseTransitionSegment::instance()->getREQUEST_TYPE_PREV().c_str(),"INIT"))
         if (!strcmp(CaseTransitionSegment::instance()->getSTATUS_PREV().c_str(),"TEMP"))
            bConversionCase = true;
   // Set the INST_ID_ACQ and INST_ID_ISS in EMS_CASE table with their corresponding
   // RECON values if INST_ID_ACQ and INST_ID_ISS are empty
   if (CaseSegment::instance()->getINST_ID_ACQ().length()== 0)
       CaseSegment::instance()->setINST_ID_ACQ
       (CaseSegment::instance()->getINST_ID_RECON_ACQ());
   if (CaseSegment::instance()->getINST_ID_ISS().length()== 0)
       CaseSegment::instance()->setINST_ID_ISS
       (CaseSegment::instance()->getINST_ID_RECON_ISS());
//ICS CONVERSION - end
   int lCASE_ID = 1;
   char psCASE_NO[15];
   memcpy(psCASE_NO, Clock::instance()->getYYYYMMDDHHMMSS().data(), 8);
   snprintf(&psCASE_NO[8],sizeof(psCASE_NO)-8, "%06ld", 1);
   string strCASE_NO(psCASE_NO);
   short iNull;
   Query hQuery;
   hQuery.bind("EMS_CASE","CASE_ID",Column::LONG,&lCASE_ID,&iNull,"MAX");
   hQuery.setBasicPredicate("EMS_CASE","CASE_ID","<","1999000000",true);
   if (1) // Done so only 3 SelectStatements are present later in the code
   {
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
      if (iNull != -1)
      {
         hQuery.reset();
         hQuery.bind("EMS_CASE","CASE_NO",Column::STRING,&strCASE_NO, &iNull,"MAX");
         hQuery.setBasicPredicate("EMS_CASE","CASE_NO",">=",strCASE_NO.c_str());
         if (!pSelectStatement->execute(hQuery))
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
         }
          lCASE_ID++;
         if(strCASE_NO.length())
         {
             char szTemp[PERCENTD];
             snprintf(szTemp,sizeof(szTemp), "%06d", atoi(strCASE_NO.substr(8,6).c_str()) + 1);
             memcpy(psCASE_NO+8,szTemp,6);
         }
         strCASE_NO.assign(psCASE_NO,14);
      }
   }
   CaseSegment::instance()->setCASE_ID(lCASE_ID);   
//ICS CONVERSION - start
   if (!bConversionCase)
//ICS CONVERSION - end
   CaseSegment::instance()->setCASE_NO(strCASE_NO);
   m_lInfoIDNumber = Case::instance()->mapInst();
   if (m_lInfoIDNumber != 0)
      return false;
   if (CaseSegment::instance()->getUSER_ROLE().length() == 0)
      CaseSegment::instance()->setUSER_ROLE();
   m_iResultCode = 0;
   if (CaseSegment::instance()->getTSTAMP_TRANS().length())
   {
      string strREL_CASE_NO("");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (CasePhaseSegment::instance()->getFEE_REL_CASE_NO().length() == 0 &&
         CaseSegment::instance()->getCASE_TYPE_IND() != "ET")
      {
         string strREL_CASE_NO("");
         string strTSTAMP_CREATED("");
         hQuery.reset() ;
         hQuery.join("EMS_PHASE","INNER","EMS_CASE","CASE_ID");
         hQuery.bind("EMS_CASE","CASE_NO",Column::STRING,&strREL_CASE_NO);
         hQuery.bind("EMS_PHASE","TSTAMP_CREATED",Column::STRING,&strTSTAMP_CREATED);
         hQuery.setBasicPredicate("EMS_CASE","TSTAMP_TRANS","=",CaseSegment::instance()->getTSTAMP_TRANS().c_str());
         if (CaseSegment::instance()->getCASE_TYPE_IND()[0] == 'E')
            hQuery.setBasicPredicate("EMS_CASE","CASE_TYPE_IND","=","X");
         else
            hQuery.setBasicPredicate("EMS_CASE","CASE_TYPE_IND","LIKE","E%");
         if (!pSelectStatement->execute(hQuery))
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
         }
         if (strREL_CASE_NO.length())
         {
            CasePhaseSegment::instance()->setFEE_REL_CASE_NO(strREL_CASE_NO);
            CasePhaseSegment::instance()->setFEE_REL_TSTAMP(strTSTAMP_CREATED);
            string strChbRefno("");
            hQuery.reset();
            hQuery.join("EMS_CASE","INNER","EMS_PHASE","CASE_ID");
            if (CaseSegment::instance()->getCASE_EXTENSION() == "MCI")
            {
                hQuery.join("EMS_PHASE","INNER","EMS_PHASE_MCI","CASE_ID");
                hQuery.join("EMS_PHASE","INNER","EMS_PHASE_MCI","TSTAMP_CREATED");
                hQuery.setBasicPredicate("EMS_CASE","CASE_NO","=",strREL_CASE_NO.c_str());
                hQuery.setBasicPredicate("EMS_PHASE","REQUEST_TYPE","=","CHB1");
                hQuery.bind("EMS_PHASE_MCI","CARD_ISS_REF_DATA",Column::STRING,&strChbRefno);
                hQuery.setOrderByClause("EMS_PHASE.TSTAMP_CREATED ASC");
                if (!pSelectStatement->execute(hQuery))
                {
                    m_iResultCode = STS_QUERY_ERROR;
                    m_lInfoIDNumber = STS_DATABASE_FAILURE;
                    return false;
                }
                if (pSelectStatement->getRows() > 0)
                    CasePhaseMCSegment::instance()->setCARD_ISS_REF_DATA(strChbRefno);
            }
            else if (CaseSegment::instance()->getCASE_EXTENSION() == "VNT")
            {
                hQuery.join("EMS_PHASE","INNER","EMS_PHASE_VNT","CASE_ID");
                hQuery.join("EMS_PHASE","INNER","EMS_PHASE_VNT","TSTAMP_CREATED");
                hQuery.setBasicPredicate("EMS_CASE","CASE_NO","=",strREL_CASE_NO.c_str());
                hQuery.setBasicPredicate("EMS_PHASE","REQUEST_TYPE","=","CHB1");
                hQuery.bind("EMS_PHASE_VNT","CHB_REF_NO",Column::STRING,&strChbRefno);
                hQuery.setOrderByClause("EMS_PHASE.TSTAMP_CREATED ASC");
                if (!pSelectStatement->execute(hQuery))
                {
                    m_iResultCode = STS_QUERY_ERROR;
                    m_lInfoIDNumber = STS_DATABASE_FAILURE;
                    return false;
                }
                if (pSelectStatement->getRows() > 0)
                    CasePhaseVisaSegment::instance()->setCHB_REF_NO(strChbRefno);
            }
         }
      }
   }
   if (Extract::instance()->getCustomCode() == "DGMC")
   {
      if ((ConfigurationRepository::instance()->verify("X_XML_PROC_NETID", CaseSegment::instance()->getPROC_ID_ACQ_B())) ||
         (ConfigurationRepository::instance()->verify("X_XML_PROC_NETID", CaseSegment::instance()->getPROC_ID_ISS_B())))
         CaseSegment::instance()->setONUS_IND("N");
      else
         CaseSegment::instance()->setONUS_IND("Y");
   }
   else
      CaseSegment::instance()->setONUS_IND("");
   if (!CaseSegment::instance()->getDATE_NOTIFY().empty() && CaseSegment::instance()->getDATE_NOTIFY().length() > 7)
      Case::instance()->setRegEDates();
    // insert case recrods except phase, phase extension and transition
   vector<Segment*>::iterator ppSegment;
   for (ppSegment = m_hSegments.begin();ppSegment != m_hSegments.end();++ppSegment)
   {
      if ((*ppSegment)->presence() && (*ppSegment)->persistent()
          && (*ppSegment)->segmentID() != (const char*)"S211"
          && (*ppSegment)->segmentID() != (const char*)"S214"
            && (*ppSegment)->segmentID() != (const char*)"S276"
            && (*ppSegment)->segmentID() != (const char*)"S282" // Account Entry
            && (*ppSegment)->segmentID() != (const char*)"ELIN")
      {
         if (CaseSegment::instance()->getOTHER_CUST_ID() == "XPRT"
          && ((*ppSegment)->segmentID() == (const char*)"S278" || (*ppSegment)->segmentID() == (const char*)"S279")
          && (CaseSegment::instance()->getCASE_TYPE_IND() == "D" && CaseFraudSegment::instance()->presence() == false))
         {
            CaseFraudSegment::instance()->setPresence(true);
            CaseFraudSegment::instance()->reset();
            if (!insertSegment((PersistentSegment*)(CaseFraudSegment::instance())))
               return false;
         }
        if (!insertSegment((PersistentSegment*)(*ppSegment)))
           return false;
      }
   }
   if (CaseCommentSegment::instance()->presence() &&
       (CaseSegment::instance()->getCaseSource() == "I"
       || CaseSegment::instance()->getCaseSource() == "X"
       || CaseSegment::instance()->getCaseSource() == "B"))
      if (m_lInfoIDNumber = Case::addComment(0))
      {
         m_iResultCode = STS_ERROR;
         return false;
      }

   for(int i = 0; i < 4; i++)
   {
      if(!m_pListSegment[i]->presence())
         break;
      char* p = (char*)*m_pListSegment[i];
      if (!memcmp(p,(const char*)"S214",4))
         m_lInfoIDNumber = Case::instance()->addComments(m_pListSegment[i]);
      else if (!memcmp(p,(const char*)"S282",4))
      {
         AccountEntry hAccountEntry;
         for (int j = 0;j < m_pListSegment[i]->itemCount();++j)
         {
            if ((m_lInfoIDNumber = CaseAccountHistorySegment::instance()->import(&p)) == 0)
            {
               if ((m_lInfoIDNumber = hAccountEntry.process(CaseAccountHistorySegment::instance())) != 0)
                  break;
            }
            else
                 break;
         }
         CaseAccountHistorySegment::instance()->setPresence(false);
      }
      if (memcmp(p,(const char*)"S276",4) == 0)
      {
         for (int j = 0;j < m_pListSegment[i]->itemCount();++j)
         {
            m_lInfoIDNumber = CaseDocumentSegment::instance()->import(&p);
            if (m_lInfoIDNumber == 0)
            {
               if (CaseDocumentSegment::instance()->getDOC_TYPE().find("QTN_") == string::npos
                  && CaseDocumentSegment::instance()->getDOC_TYPE().find("DCF_") == string::npos
                  && CaseDocumentSegment::instance()->getDOC_TYPE() != "SMART_FORM"
                  && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) != "REQ_PARB_"
                  && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 8) != "REQ_ARB_"
                  && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) != "REQ_PCMP_"
                  && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) != "REQ_COMP_"
                  && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) != "REQ_PRSP_"
                  && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) != "REQ_CRSP_"
                  && CaseDocumentSegment::instance()->getDOC_TYPE() != "REQ_CBRS")
                  if (!insertSegment(CaseDocumentSegment::instance()))
                     break;
            }
         }
      }
      if (memcmp(p,(const char*)"ELIN",4) == 0)
      {
         for (int j = 0;j < m_pListSegment[i]->itemCount();++j)
         {
            if ((m_lInfoIDNumber = LineitemSegment::instance()->import(&p)) == 0)
            {
               if (!insertSegment(LineitemSegment::instance()))
                  break;
            }
         }
      }
      if (m_lInfoIDNumber != 0)
      {
         m_iResultCode = STS_QUERY_ERROR;
         return false;
      }
   }
   CaseTransitionSegment::instance()->setACTION_TO_CARDHLDR(CasePhaseSegment::instance()->getACTION_TO_CARDHLDR());
   CaseTransitionSegment::instance()->setREASON_CODE(CasePhaseSegment::instance()->getREASON_CODE());
   CaseTransitionSegment::instance()->setAMT_ADJUSTMENT(CasePhaseSegment::instance()->getAMT_ADJUSTMENT());
   CaseTransitionSegment::instance()->setLETTER_CODE(CasePhaseSegment::instance()->getLETTER_CODE());
   // perform the requested transition
   if (m_lInfoIDNumber = Case::instance()->transition(true,false,bFirstCase))
   {
      m_iResultCode = STS_QUERY_ERROR;
      return false;
   }
   else
   {
      if (CaseCommentSegment::instance()->getEMS_COMMENT().length() > 0 )
      {
         Table hTable;
         hTable.setName("EMS_COMMENT");
         hTable.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
         hTable.set("TSTAMP_CREATED",Transaction::instance()->getTimeStamp(),false,true);
         hTable.set("TSTAMP_PHASE",CasePhaseSegment::instance()->getTSTAMP_CREATED());
         auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
         if (pUpdateStatement->execute(hTable) == false)
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
         }
      }
   }
   for(int i = 0; i < 4; i++)
   {
      if(!m_pListSegment[i]->presence())
         break;
      char* p = (char*)*m_pListSegment[i];
      if (!memcmp(p,(const char*)"S276",4))
      {
         for (int j = 0;j < m_pListSegment[i]->itemCount();++j)
         {
            if ((m_lInfoIDNumber = CaseDocumentSegment::instance()->import(&p)) == 0)
            {
               if (CaseDocumentSegment::instance()->getDOC_TYPE().find("QTN_") != string::npos
                  || CaseDocumentSegment::instance()->getDOC_TYPE().find("DCF_") != string::npos
                  || CaseDocumentSegment::instance()->getDOC_TYPE() == "SMART_FORM"
                  || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_PARB_"
                  || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 8) == "REQ_ARB_"
                  || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_PCMP_"
                  || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_COMP_"
                  || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_PRSP_"
                  || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_CRSP_"
                  || CaseDocumentSegment::instance()->getDOC_TYPE() == "REQ_CBRS")
                  if (!insertSegment(CaseDocumentSegment::instance()))
                     break;
            }
         }
      }
      if (m_lInfoIDNumber != 0)
      {
         m_iResultCode = STS_QUERY_ERROR;
         return false;
      }
   }
   // update FIN_TYPE on original transaction to indicate case pending
   if(CaseSegment::instance()->getTSTAMP_TRANS().length() != 0)
   {
      string strBegin("000000");
      string strEnd("000000");
      if ((bFirstCase && Case::instance()->findLocator(CaseSegment::instance()->getTSTAMP_TRANS().substr(0,6), strBegin, strEnd))
         || !bFirstCase)
      {
         char cFIN_TYPE('1');
         if (!FinancialUpdateFinTypeCommand::setFIN_TYPE(CaseSegment::instance()->getTSTAMP_TRANS(),CaseSegment::instance()->getUNIQUENESS_KEY(),cFIN_TYPE))
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
         }
      }
   }
   if (CaseAccountHistorySegment::instance()->presence())
   {
      AccountEntry hAccountEntry;
      m_lInfoIDNumber = hAccountEntry.process(CaseAccountHistorySegment::instance());
      if (m_lInfoIDNumber != 0)
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         m_iResultCode = STS_QUERY_ERROR;
         return false;
      }
   }
//ICS CONVERSION - start
   if (!bConversionCase && CaseTransitionSegment::instance()->getACTION().empty())
   {
//ICS CONVERSION - end
   vector<ActionDetail> hActionDetails;
   EMSRulesEngine::instance()->getRCActions(hActionDetails);
   m_lInfoIDNumber = Case::instance()->processActions(hActionDetails);
//ICS CONVERSION - start
   }
//ICS CONVERSION - end
   if (m_lInfoIDNumber != 0)
      return false;
   string strTSTAMP_CREATED("");
   lCASE_ID = 0;
   
   if(CaseSegment::instance()->getTSTAMP_TRANS().length() > 0 && CaseSegment::instance()->getCASE_TYPE_IND()[0] == 'E')
   {
      hQuery.reset();
      hQuery.join("EMS_PHASE","INNER","EMS_CASE","CASE_ID");
      hQuery.bind("EMS_PHASE","CASE_ID",Column::LONG,&lCASE_ID);
      hQuery.bind("EMS_PHASE","TSTAMP_CREATED",Column::STRING,&strTSTAMP_CREATED);
      hQuery.setBasicPredicate("EMS_CASE","TSTAMP_TRANS","=",CaseSegment::instance()->getTSTAMP_TRANS().c_str());
      hQuery.setBasicPredicate("EMS_CASE","UNIQUENESS_KEY","=",CaseSegment::instance()->getUNIQUENESS_KEY());
      hQuery.setBasicPredicate("EMS_CASE","CASE_TYPE_IND","=","D");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
      if (lCASE_ID != 0 )
      {
         Table hTable;
         hTable.setName("EMS_PHASE");
         hTable.set("CASE_ID",lCASE_ID,true);
         hTable.set("TSTAMP_CREATED",strTSTAMP_CREATED,false,true);
         hTable.set("FEE_REL_CASE_NO",CaseSegment::instance()->getCASE_NO());
         hTable.set("FEE_REL_TSTAMP",CasePhaseSegment::instance()->getTSTAMP_CREATED());
         auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
         if (pUpdateStatement->execute(hTable) == false)
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
         }
      }
   }

   if (CasePhaseSegment::instance()->getFEE_REL_CASE_NO().length() != 0)
   {
     if (CaseSegment::instance()->getCASE_TYPE_IND() != "D")
     {
        hQuery.reset();
        hQuery.join("EMS_CASE","INNER","EMS_PHASE","CASE_ID");
        hQuery.bind("EMS_PHASE","CASE_ID",Column::LONG,&lCASE_ID);
        hQuery.bind("EMS_PHASE","TSTAMP_CREATED",Column::STRING,&strTSTAMP_CREATED);
        hQuery.setBasicPredicate("EMS_PHASE","TSTAMP_CREATED","=",CasePhaseSegment::instance()->getFEE_REL_TSTAMP().c_str());
        hQuery.setBasicPredicate("EMS_CASE","CASE_NO","=",CasePhaseSegment::instance()->getFEE_REL_CASE_NO().c_str());
        auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
        if (!pSelectStatement->execute(hQuery))
        {
           m_iResultCode = STS_QUERY_ERROR;
           m_lInfoIDNumber = STS_DATABASE_FAILURE;
           return false;
        }
     	Table hTable;
	 	hTable.setName("EMS_PHASE");
	 	hTable.set("CASE_ID",lCASE_ID,true);
	 	hTable.set("TSTAMP_CREATED",strTSTAMP_CREATED,false,true);
	 	hTable.set("FEE_REL_CASE_NO",CaseSegment::instance()->getCASE_NO());
	 	hTable.set("FEE_REL_TSTAMP",CasePhaseSegment::instance()->getTSTAMP_CREATED());
	 	auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
	 	if (pUpdateStatement->execute(hTable) == false)
	 	{
	 		m_iResultCode = STS_QUERY_ERROR;
	 		m_lInfoIDNumber = STS_DATABASE_FAILURE;
	 		return false;
	 	}
     } 
   }
	//Case to Case imported cases needs to be saved with OTHER_CUST_ID = IPRT.
   if(CaseSegment::instance()->getOTHER_CUST_ID() == "XPRT")
   {
      CaseSegment::instance()->setOTHER_CUST_ID("IPRT");
      Table hTable;
      hTable.setName("EMS_CASE");
      hTable.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
       hTable.set("OTHER_CUST_ID","IPRT");
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      if (pUpdateStatement->execute(hTable) == false)
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
   }
   m_lInfoIDNumber = Case::instance()->updateCaseGroup();
   if (m_lInfoIDNumber)
   {
      m_iResultCode = STS_QUERY_ERROR;
      return false;
   }
   CardholderInformationSegment hCardholderInformationSegment;
   if (entitycommand::CardholderAddress::instance()->getAddress(CaseSegment::instance()->getPAN(), CaseSegment::instance()->getINST_ID_ISS(), &hCardholderInformationSegment)
         == SYNC_QUERY_FAILED)
   {
      m_iResultCode = STS_QUERY_ERROR;
      m_lInfoIDNumber = STS_DATABASE_FAILURE;
      return false;
   }
   return true;
  //## end emscommand::CaseCreateCommand::createCase%3BFE765C0297.body
}

bool CaseCreateCommand::createIssCase (const string& strCustomer, const string& strQualifier, const string& strNetwork)
{
  //## begin emscommand::CaseCreateCommand::createIssCase%4E382702027F.body preserve=yes
   CaseSegment::instance()->setTSTAMP_TRANS("");
   bool bSuccess = true;
   string strRecord;
   string strBegin("000000");
   string strEnd("000000");
   if (!Case::instance()->findLocator(" ",strBegin,strEnd))
      return false;
   if (Case::instance()->retrieveTransaction("I",true,true,true,"*","I") == false)
      return false;
   ArchiveRetriever::instance()->closeArchive(); //** Check on this while reviewing the code.
   int lCASE_ID(CaseSegment::instance()->getCASE_ID());
   CaseSegment::instance()->setACQ_CASE_NO(CaseSegment::instance()->getCASE_NO());
   CaseSegment::instance()->setACQ_CUST_ID(strCustomer);
   Transaction::instance()->setCustomer(strNetwork);
   if (Extract::instance()->getRecord("DSPEC   EC01    RESETRULE~", strRecord) && strRecord.length() >= 30
      && (memcmp(strNetwork.data(), strRecord.data() + 26, 4) == 0))
   {
      EMSNetRuleUse hEMSNetRuleUse(true);
      if (EMSNetRuleUseTable::instance()->get(hEMSNetRuleUse, reusable::Transaction::instance()->getCustomer()))
         CaseSegment::instance()->setNET_RULES(hEMSNetRuleUse.getNETWORK_RULES());
   }
   bSuccess = createCase(false);
   if (m_lInfoIDNumber == STS_DUPLICATE_RECORD)
      bSuccess = true;
   CaseSegment hCaseSegment(*CaseSegment::instance());
   if (bSuccess)
   {  
      replicateOtherCase();
      *CaseSegment::instance() = hCaseSegment;
   }
   Transaction::instance()->setQualifier(strQualifier);
   Transaction::instance()->setCustomer(strCustomer);
   if (bSuccess)
   {
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      Table hTable("EMS_CASE");
      hTable.set("CASE_ID",lCASE_ID,true);
      hTable.set("ISS_CASE_NO",CaseSegment::instance()->getCASE_NO());
      hTable.set("ISS_CUST_ID",strNetwork);
      bSuccess = pUpdateStatement->execute(hTable);
      m_hCaseSegment[0].setISS_CASE_NO(CaseSegment::instance()->getCASE_NO());
      m_hCaseSegment[0].setISS_CUST_ID(strNetwork);
   }
   else
      Transaction::instance()->setText(strNetwork);
   return bSuccess;
  //## end emscommand::CaseCreateCommand::createIssCase%4E382702027F.body
}

bool CaseCreateCommand::execute ()
{
  //## begin emscommand::CaseCreateCommand::execute%35994C4B01B7.body preserve=yes
   Trace::put("CaseCreateCommand::execute");
   Case::instance()->setCustAbbr();
   int lInfoIDNumber(0);
   m_lInfoIDNumber = 0;
   if (CaseSegment::instance()->getOTHER_CUST_ID() == "XPRT")
   {
      if (Extract::instance()->getCustomCode() == "JHA"
         && CaseSegment::instance()->getTSTAMP_TRANS().length())
         CaseSegment::instance()->setTSTAMP_TRANS("");
      if (CaseSegment::instance()->getCaseSource() == "B")
         CasePhaseSegment::instance()->setREQUEST_TYPE(CaseTransitionSegment::instance()->getREQUEST_TYPE_PREV());
   }
  if (CaseSegment::instance()->getTSTAMP_TRANS().length() == 0
     && CaseSegment::instance()->getCaseSource() != "X")
   {
      if (!(CaseSegment::instance()->getCaseSource() == "I" &&
         CaseSegment::instance()->getNET_ID_EMS() == "STR" ))
      {
         if (CaseSegment::instance()->getOTHER_CUST_ID() == "XPRT")
         {
            Query hQuery;
            CaseSegment pCaseSegment;
            pCaseSegment.bind(hQuery);
            auto_ptr<SelectStatement>pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
            hQuery.setBasicPredicate("EMS_CASE","PAN","=",CaseSegment::instance()->getPAN().c_str());
            hQuery.setBasicPredicate("EMS_CASE","RETRIEVAL_REF_NO","=",CaseSegment::instance()->getRETRIEVAL_REF_NO().c_str());
            hQuery.setBasicPredicate("EMS_CASE","TSTAMP_LOCAL","=",CaseSegment::instance()->getTSTAMP_LOCAL().c_str());
            hQuery.setBasicPredicate("EMS_CASE","AMT_TRAN","=",CaseSegment::instance()->getAMT_TRAN());

            if (!pSelectStatement->execute(hQuery))
            {
               m_iResultCode = STS_QUERY_ERROR;
               m_lInfoIDNumber = STS_DATABASE_FAILURE;
               return false;
            }
            if(pSelectStatement->getRows() != 0 && pCaseSegment.getTSTAMP_TRANS().length() > 0)
            {
               string strBegin("000000");
               string strEnd("000000");
               if (!Case::instance()->findLocator(pCaseSegment.getTSTAMP_TRANS().substr(0,6), strBegin, strEnd))
               {
                  m_lInfoIDNumber = STS_RECORD_NOT_FOUND;
                  return false;
               }
               CaseSegment::instance()->setTSTAMP_TRANS(pCaseSegment.getTSTAMP_TRANS());
               CaseSegment::instance()->setUNIQUENESS_KEY(pCaseSegment.getUNIQUENESS_KEY());
            }
            if (Case::instance()->retrieveTransaction(CasePhaseSegment::instance()->getUSER_ROLE()))
               lInfoIDNumber = STS_CASE_CHANGED_FROM_MANUAL;
         }
         else
         {
            if (Case::instance()->retrieveTransaction())
               lInfoIDNumber = STS_CASE_CHANGED_FROM_MANUAL;
         }
      }
   }
   if (CaseSegment::instance()->getTSTAMP_TRANS().length() == 0)
   {
      // Don't rechain if it is star import or coming from a third party that
      // does not have entity info in the file (i.e., BAMS).  The case will be
      // in a held status and the user will need to select a term id when they update it.
      if (!(CaseSegment::instance()->getCaseSource() == "I" &&
            (CaseSegment::instance()->getNET_ID_EMS() == "STR"
            || CaseSegment::instance()->getREQUEST_TYPE().substr(0,2) == "FE"
            || CaseSegment::instance()->getACQ_USER_ID() == "TPPIMPRT")))
      {
         if(!m_bOCS && CaseTransitionSegment::instance()->getSTATUS_NEXT() != "CLUN")
         {
            m_lInfoIDNumber = Case::instance()->rechain();
            if (m_lInfoIDNumber != 0)
               return false;
         }
      }
   }
   if (CaseSegment::instance()->getCaseSource() == "W" && 
       CaseSegment::instance()->getOTHER_CUST_ID() != "XPRT")
   {
      int iReturn = ExceptionSecurity::secureUserForCase();
      if (iReturn == 0)
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
      else if (iReturn == -1)
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_ACCESS_TO_DATA_DENIED;
         return false;
      }
   }
   //Four lists come in, determine which one is a list of Reason Codes
    for(int j = 0; j < 4; j++)
    {
        if(!m_pListSegment[j]->presence())
            break;
       char* p = (char*)*m_pListSegment[j];
        if (!memcmp(p,(const char*)"S273",4))
            m_lInfoIDNumber = Case::instance()->verifyReasonCodeList(m_pListSegment[j]);
        if (m_lInfoIDNumber != 0)
        {
            m_iResultCode = STS_QUERY_ERROR;
            return false;
        }
    }

    if (CaseSegment::instance()->getCASE_EXTENSION() == "VNT")
    {
       string strValue;
       IF::Extract::instance()->getSpec("VCRDATE", strValue);
       if (Clock::instance()->getYYYYMMDDHHMMSS(true).substr(0, 8) >= APR_2018_MU
          || Clock::instance()->getYYYYMMDDHHMMSS(true).substr(0, 8) >= strValue)
          CaseVisaSegment::instance()->setVCR_IND("Y");
       if (CaseTransitionSegment::instance()->getREQUEST_TYPE_NEXT().substr(0, 3) == "ADJ"
          && CaseTransitionSegment::instance()->getSTATUS_NEXT() == "FWRD")
          calculateSurcharge();
    }
    /*string strCriticalSection(Extract::instance()->getName().c_str(), 2);
    strCriticalSection.append("EMS", 3);
   CriticalSection hCriticalSection(strCriticalSection.c_str());*/
   if (!createCase(true))
      return false;
   string strNetwork;
   m_hCaseSegment[0] = (*CaseSegment::instance());
   m_hCasePhaseSegment[0]= (*CasePhaseSegment::instance());
   CaseSegment::instance()->setTSTAMP_TRANS("");
   bool bSuccess(true);
   if (findAcqProc(strNetwork))
   {
      Trace::put("Found Acquirer qualifier: ");
      Trace::put(Transaction::instance()->getQualifier().c_str());
      string strQualifier(Transaction::instance()->getQualifier());
      string strCustomer(strNetwork);
      if (createAcqCase(m_strCUST_ID,"CUSTQUAL",strNetwork))
      {
         if (findAcqProc(strNetwork) && CaseSegment::instance()->getTSTAMP_TRANS().length() > 0)
         {
            m_hCaseSegment[1] = m_hCaseSegment[0];
            m_hCasePhaseSegment[1] = m_hCasePhaseSegment[0];
            m_hCaseSegment[0] = (*CaseSegment::instance());
            m_hCasePhaseSegment[0]= (*CasePhaseSegment::instance());
            Trace::put("Found Acq in ACQ qualifier: ");
            Trace::put(Transaction::instance()->getQualifier().c_str());
            if (createAcqCase(strCustomer,strQualifier,strNetwork) == false)
            {
               if (m_lInfoIDNumber == STS_REQUESTER_CONTACT_NOT_FOUND ||
                   m_lInfoIDNumber == STS_RECEIVER_CONTACT_NOT_FOUND)
                  lInfoIDNumber = STS_2ND_CASE_CONTACT_NOT_FOUND;
               else
                  lInfoIDNumber = STS_CANNOT_ADD_2ND_CASE;
            }
            m_hCaseSegment[0] = m_hCaseSegment[1];
            m_hCasePhaseSegment[0] = m_hCasePhaseSegment[1];
         }
      } 
      else 
      {
         if (m_lInfoIDNumber == STS_REQUESTER_CONTACT_NOT_FOUND ||
             m_lInfoIDNumber == STS_RECEIVER_CONTACT_NOT_FOUND)
            lInfoIDNumber = STS_2ND_CASE_CONTACT_NOT_FOUND;
         else
            lInfoIDNumber = STS_CANNOT_ADD_2ND_CASE;
      }         
      Transaction::instance()->setQualifier("CUSTQUAL");
      Transaction::instance()->setCustomer(m_strCUST_ID);
      Case::instance()->setCustAbbr();
   }
   *CaseSegment::instance() = m_hCaseSegment[0];
   *CasePhaseSegment::instance() = m_hCasePhaseSegment[0];
   CaseSegment::instance()->setTSTAMP_TRANS("");
   if (findIssProc(strNetwork))
   {
      Trace::put("Found Issuer qualifier: ");
      Trace::put(Transaction::instance()->getQualifier().c_str());
      string strQualifier(Transaction::instance()->getQualifier());
      string strCustomer(strNetwork);
      if (createIssCase(m_strCUST_ID,"CUSTQUAL",strNetwork))
      {
         if (findIssProc(strNetwork) && CaseSegment::instance()->getTSTAMP_TRANS().length() > 0)
         {
            m_hCaseSegment[1] = m_hCaseSegment[0];
            m_hCasePhaseSegment[1] = m_hCasePhaseSegment[0];
            m_hCaseSegment[0] = (*CaseSegment::instance());
            m_hCasePhaseSegment[0]= (*CasePhaseSegment::instance());            
            Trace::put("Found Iss in Iss qualifier: ");
            Trace::put(Transaction::instance()->getQualifier().c_str());
            if (createIssCase(strCustomer,strQualifier,strNetwork) == false)
            {
               if (m_lInfoIDNumber == STS_REQUESTER_CONTACT_NOT_FOUND ||
                   m_lInfoIDNumber == STS_RECEIVER_CONTACT_NOT_FOUND)
                  lInfoIDNumber = STS_2ND_CASE_CONTACT_NOT_FOUND;
               else
                  lInfoIDNumber = STS_CANNOT_ADD_2ND_CASE;
            }
            m_hCaseSegment[0] = m_hCaseSegment[1];
            m_hCasePhaseSegment[0] = m_hCasePhaseSegment[1];
         }
      }
      else 
      {
         if (m_lInfoIDNumber == STS_REQUESTER_CONTACT_NOT_FOUND ||
             m_lInfoIDNumber == STS_RECEIVER_CONTACT_NOT_FOUND)
            lInfoIDNumber = STS_2ND_CASE_CONTACT_NOT_FOUND;
         else
            lInfoIDNumber = STS_CANNOT_ADD_2ND_CASE;
      }         
      Transaction::instance()->setQualifier("CUSTQUAL");
      Transaction::instance()->setCustomer(m_strCUST_ID);
      Case::instance()->setCustAbbr();
   }
   *CaseSegment::instance() = m_hCaseSegment[0];
   *CasePhaseSegment::instance() = m_hCasePhaseSegment[0];
   if (!Case::instance()->getAdditionalTransitionData().empty())
   {
      Database::instance()->commit();
      reusable::Transaction::instance()->begin();
      reusable::Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
      CBACompliance hCBACompliance;
      if (!hCBACompliance.execute(CaseSegment::instance()->getCASE_ID()))
         return false;
      while (CaseSegment::instance()->getREQUEST_TYPE() == "CHB1"
         && !Case::instance()->getAdditionalTransitionData().empty())
      {
         if (Case::instance()->processAdditionalTransition(m_lInfoIDNumber, m_iResultCode) == false)
            return false;
      }
   }
   if(!EMailMessage::sendAll())
   {
      m_lInfoIDNumber = STS_SMTP_OPEN_FAILURE;
      return false;
   }
   int i = CasePhaseSegment::instance()->totals();
   if (i!=0)
    {
      m_lInfoIDNumber=i;
      return false;
    }
   m_lInfoIDNumber = lInfoIDNumber;
   return true;
  //## end emscommand::CaseCreateCommand::execute%35994C4B01B7.body
}

bool CaseCreateCommand::findAcqProc (string& strNetwork)
{
  //## begin emscommand::CaseCreateCommand::findAcqProc%4E38269E0232.body preserve=yes
   string strProc(CaseSegment::instance()->getPROC_ID_ACQ());
   Trace::put("Acquirer Proc");
   Trace::put(strProc.c_str());
   return(Case::instance()->setQualifierFromProc(strProc, strNetwork));
  //## end emscommand::CaseCreateCommand::findAcqProc%4E38269E0232.body
}

bool CaseCreateCommand::findIssProc (string& strNetwork)
{
  //## begin emscommand::CaseCreateCommand::findIssProc%4E3825100111.body preserve=yes
   string strProc(CaseSegment::instance()->getPROC_ID_ISS());
   Trace::put("Issuer Proc");
   Trace::put(strProc.c_str());
   return (Case::instance()->setQualifierFromProc(strProc, strNetwork));
  //## end emscommand::CaseCreateCommand::findIssProc%4E3825100111.body
}

bool CaseCreateCommand::getMaxCaseID ()
{
  //## begin emscommand::CaseCreateCommand::getMaxCaseID%5F6460FA023A.body preserve=yes
   Table hTable;
   auto_ptr<Statement> pInsertStatement1((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   for (int i = 0; i < 10; i++)
   {
       if (i > 0)
           Sleep::goTo("00000100");
       int lCASE_ID = 1;
       char psCASE_NO[15];
       memcpy(psCASE_NO, Clock::instance()->getYYYYMMDDHHMMSS().data(), 8);
       snprintf(&psCASE_NO[8], sizeof(psCASE_NO)-8, "%06ld", 1);
       string strCASE_NO(psCASE_NO);
       short iNull;
       Query hQuery;
       hQuery.bind("EMS_CASE", "CASE_ID", Column::LONG, &lCASE_ID, &iNull, "MAX");
       hQuery.setBasicPredicate("EMS_CASE", "CASE_ID", "<", "1999000000", true);
       if (!pSelectStatement->execute(hQuery))
       {
           m_iResultCode = STS_QUERY_ERROR;
           m_lInfoIDNumber = STS_DATABASE_FAILURE;
           return false;
       }
       if (iNull != -1)
       {
           hQuery.reset();
           hQuery.bind("EMS_CASE", "CASE_NO", Column::STRING, &strCASE_NO, &iNull, "MAX");
           hQuery.setBasicPredicate("EMS_CASE", "CASE_NO", ">=", strCASE_NO.c_str());
           if (!pSelectStatement->execute(hQuery))
           {
               m_iResultCode = STS_QUERY_ERROR;
               m_lInfoIDNumber = STS_DATABASE_FAILURE;
               return false;
           }
           lCASE_ID++;
           if (strCASE_NO.length())
           {
               char szTemp[PERCENTD];
               snprintf(szTemp, sizeof(szTemp), "%06d", atoi(strCASE_NO.substr(8, 6).c_str()) + 1);
               memcpy(psCASE_NO + 8, szTemp, 6);
           }
           strCASE_NO.assign(psCASE_NO, 14);
       }
       CaseSegment::instance()->setCASE_ID(lCASE_ID);
       CaseSegment::instance()->setCASE_NO(strCASE_NO);
       CaseSegment::instance()->setColumns(hTable);
       if (pInsertStatement1->execute(hTable) == false
           && pInsertStatement1->getInfoIDNumber() != STS_DUPLICATE_RECORD)
       {
           m_iResultCode = STS_QUERY_ERROR;
           m_lInfoIDNumber = STS_DATABASE_FAILURE;
           return false;
       }
       if (pInsertStatement1->getInfoIDNumber() == 0)
           return true;
   }
   short iNull;
   string strCASE_NO;
   Query hQuery;
   hQuery.reset();
   hQuery.bind("EMS_CASE", "CASE_NO", Column::STRING, &strCASE_NO, &iNull);
   hQuery.setBasicPredicate("EMS_CASE", "NET_ID_ACQ", "=", CaseSegment::instance()->getNET_ID_ACQ().c_str());
   hQuery.setBasicPredicate("EMS_CASE", "NET_ID_ISS", "=", CaseSegment::instance()->getNET_ID_ISS().c_str());
   hQuery.setBasicPredicate("EMS_CASE", "CASE_TYPE_IND", "=", CaseSegment::instance()->getCASE_TYPE_IND().c_str());
   hQuery.setBasicPredicate("EMS_CASE", "DUP_SEQ_NO", "=", CaseSegment::instance()->getDUP_SEQ_NO());
   hQuery.setBasicPredicate("EMS_CASE", "PAN", "=", CaseSegment::instance()->getPAN().c_str());
   hQuery.setBasicPredicate("EMS_CASE", "RETRIEVAL_REF_NO", "=", CaseSegment::instance()->getRETRIEVAL_REF_NO().c_str());
   hQuery.setBasicPredicate("EMS_CASE", "TSTAMP_LOCAL", "=", CaseSegment::instance()->getTSTAMP_LOCAL().c_str());
   hQuery.setBasicPredicate("EMS_CASE", "TSTAMP_TRANS", "=", CaseSegment::instance()->getTSTAMP_TRANS().c_str());
   hQuery.setBasicPredicate("EMS_CASE", "UNIQUENESS_KEY", "=", CaseSegment::instance()->getUNIQUENESS_KEY());
   hQuery.setBasicPredicate("EMS_CASE", "SYS_TRACE_AUDIT_NO", "=", CaseSegment::instance()->getSYS_TRACE_AUDIT_NO().c_str());
   if (pSelectStatement->execute(hQuery) && iNull != -1)
       Transaction::instance()->setText(strCASE_NO);
   return false;
  //## end emscommand::CaseCreateCommand::getMaxCaseID%5F6460FA023A.body
}

bool CaseCreateCommand::insertDocExtSegment (const string &strQUESTION_FIELDS)
{
  //## begin emscommand::CaseCreateCommand::insertDocExtSegment%5E7B06DC0358.body preserve=yes
    Table hTable;
    auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
    int iQuestionLength = 0;
    iQuestionLength = strQUESTION_FIELDS.length();
    short siStart = 0;
    short siSEQ_NO = 1;
    while (siStart < iQuestionLength)
    {
        int iMaxRecord = 3800;
        if (siStart + 3800  < iQuestionLength)
        while (strQUESTION_FIELDS[siStart + iMaxRecord - 1] == ' ')
            iMaxRecord--;
        CaseDocumentExtensionSegment::instance()->setCASE_ID(CaseSegment::instance()->getCASE_ID());
        CaseDocumentExtensionSegment::instance()->setSEQ_NO(siSEQ_NO++);
        CaseDocumentExtensionSegment::instance()->setDOC_SEQ_NO(CaseDocumentSegment::instance()->getSEQ_NO());
        CaseDocumentExtensionSegment::instance()->setDATA_BUFFER(strQUESTION_FIELDS.substr(siStart, iMaxRecord));
        CaseDocumentExtensionSegment::instance()->setColumns(hTable);
        if (!pInsertStatement->execute(hTable))
        {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
        }
        siStart += iMaxRecord;
        hTable.reset();
    }
    return true;
  //## end emscommand::CaseCreateCommand::insertDocExtSegment%5E7B06DC0358.body
}

bool CaseCreateCommand::insertSegment (segment::PersistentSegment* pPersistentSegment)
{
  //## begin emscommand::CaseCreateCommand::insertSegment%3EC9085402AF.body preserve=yes
   Table hTable;
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   string strQUESTION_FIELDS;
   if (((pPersistentSegment)->segmentID() == (const char*)"S276") && (CaseDocumentSegment::instance()->getCASE_ID() == -1 ))
	   CaseDocumentSegment::instance()->setCASE_ID(CaseSegment::instance()->getCASE_ID());

   if ((pPersistentSegment)->segmentID() == (const char*)"S276"
      && (CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,4) == "QTN_"
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 3) == "DCF")
      && CaseSegment::instance()->getCASE_EXTENSION() == "VNT")
   {
      strQUESTION_FIELDS = CaseDocumentSegment::instance()->getDOC_PATH();
      size_t nPos1 = 0;
      size_t nPos2 = 0;
      size_t nPos3 = 0;
      nPos1 = strQUESTION_FIELDS.find("<ChargebackRefNum>");
      nPos2 = strQUESTION_FIELDS.find("</ChargebackRefNum>");
      if (nPos1 != string::npos)
      {
         nPos3 = nPos2 - (nPos1+18);
         strQUESTION_FIELDS.replace(nPos1+18, nPos3,CasePhaseVisaSegment::instance()->getCHB_REF_NO());
      }
      nPos1 = strQUESTION_FIELDS.find("<MemberMsgEditText>");
      nPos2 = strQUESTION_FIELDS.find("</MemberMsgEditText>");
      if (nPos1 != string::npos)
      {
         nPos3 = nPos2 - (nPos1+19);
         strQUESTION_FIELDS.replace(nPos1+19, nPos3, CasePhaseVisaSegment::instance()->getVISA_MMT());         
      }
      CaseDocumentSegment::instance()->setDOC_PATH(" ");
   }
   if ((pPersistentSegment)->segmentID() == (const char*)"S276"
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,4) != "QTN_"
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) != "REQ_PARB_"
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 8) != "REQ_ARB_"
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) != "REQ_PCMP_"
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) != "REQ_COMP_"
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) != "REQ_PRSP_"
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) != "REQ_CRSP_"
      && CaseDocumentSegment::instance()->getDOC_TYPE() != "REQ_CBRS"
      && (CaseSegment::instance()->getCASE_EXTENSION() == "MCI" || CaseSegment::instance()->getCASE_EXTENSION() == "VNT"))
   {
      string strDOC_PATH(CaseDocumentSegment::instance()->getDOC_PATH());
      string strTemp;
      size_t nPos1 = strDOC_PATH.find(CaseSegment::instance()->getCASE_EXTENSION());
      if (nPos1 != string::npos)
      {
         strTemp.assign(strDOC_PATH,0,nPos1-1); 
         if ((strTemp != Case::instance()->getDOC_PATH(0)
            && strTemp != Case::instance()->getDOC_PATH(1))
            && (Case::instance()->getDOC_PATH(0).length() != 0 ||
                Case::instance()->getDOC_PATH(1).length() != 0 ))
         {
            strDOC_PATH.replace(0,nPos1-1,Case::instance()->getDOC_PATH(1).length() != 0 ? Case::instance()->getDOC_PATH(1) : Case::instance()->getDOC_PATH(0));
            CaseDocumentSegment::instance()->setDOC_PATH(strDOC_PATH);
         }
      }
   }
   if ((pPersistentSegment)->segmentID() == (const char*)"S276"
      && (CaseDocumentSegment::instance()->getDOC_TYPE() == "SMART_FORM"
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_PARB_"
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,8) == "REQ_ARB_"
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_PCMP_"
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_COMP_"
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_PRSP_"
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_CRSP_"
      || CaseDocumentSegment::instance()->getDOC_TYPE() == "REQ_CBRS"))
   {
      strQUESTION_FIELDS = CaseDocumentSegment::instance()->getDOC_PATH();
      CaseDocumentSegment::instance()->setDOC_PATH("");
   }
   if ((pPersistentSegment)->segmentID() == (const char*) "S208")
   {
      string strBUSINESS_CALENDAR = database::EMSBusinessDate::instance()->getBusinessCalendar(CaseSegment::instance()->getCUR_RECON_NET().c_str(),CaseSegment::instance()->getCUR_TRAN().c_str(),CasePhaseSegment::instance()->getUSER_ROLE(),Customer::instance()->getCUST_ID(),Customer::instance()->getEMS_CALENDAR_DFLT());
      CaseSegment::instance()->setBUSINESS_CALENDAR(strBUSINESS_CALENDAR);
   }
   pPersistentSegment->setColumns(hTable);
   // Phase records will be added in Case::transition
   if (hTable.getName().find("EMS_PHASE") != -1)
       return true;
   if ((hTable.getName() == "CARDHOLDER") && (Extract::instance()->getCustomCode() == "SECU" ) )
      return true;
   if (pInsertStatement->execute(hTable) == false)
   {
      if ((pInsertStatement->getInfoIDNumber() == STS_DUPLICATE_RECORD)
         && ((pPersistentSegment)->segmentID() == (const char*)"S269"))
      {
         auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
         if (pUpdateStatement->execute(hTable)==false)
         {
            m_lInfoIDNumber = pUpdateStatement->getInfoIDNumber();
            if (m_lInfoIDNumber != STS_RECORD_NOT_FOUND)
               return false;
         }
         return true;
      }
      m_lInfoIDNumber = pInsertStatement->getInfoIDNumber();
      m_iResultCode = STS_QUERY_ERROR;
      if (m_lInfoIDNumber == STS_DUPLICATE_RECORD
         && validDuplicate())
      {
         Query hQuery;
         int lDUP_SEQ_NO = 0;
         short iNull = -1;
         auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
         hQuery.bind("EMS_CASE","DUP_SEQ_NO",Column::LONG,&lDUP_SEQ_NO,&iNull,"MAX");
         hQuery.setBasicPredicate("EMS_CASE","NET_ID_ACQ","=",CaseSegment::instance()->getNET_ID_ACQ().c_str());
         hQuery.setBasicPredicate("EMS_CASE","NET_ID_ISS","=",CaseSegment::instance()->getNET_ID_ISS().c_str());
         hQuery.setBasicPredicate("EMS_CASE","CASE_TYPE_IND","=",CaseSegment::instance()->getCASE_TYPE_IND().c_str());
         hQuery.setBasicPredicate("EMS_CASE","PAN","=",CaseSegment::instance()->getPAN().c_str());
         hQuery.setBasicPredicate("EMS_CASE","RETRIEVAL_REF_NO","=",CaseSegment::instance()->getRETRIEVAL_REF_NO().c_str());
         hQuery.setBasicPredicate("EMS_CASE","TSTAMP_LOCAL","=",CaseSegment::instance()->getTSTAMP_LOCAL().c_str());
         hQuery.setBasicPredicate("EMS_CASE","TSTAMP_TRANS","=",CaseSegment::instance()->getTSTAMP_TRANS().c_str());
         hQuery.setBasicPredicate("EMS_CASE","UNIQUENESS_KEY","=",CaseSegment::instance()->getUNIQUENESS_KEY());
         Query hQuery1(hQuery);
         hQuery.setBasicPredicate("EMS_CASE","SYS_TRACE_AUDIT_NO","=",CaseSegment::instance()->getSYS_TRACE_AUDIT_NO().c_str());
         if (!pSelectStatement->execute(hQuery))
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
         }
         if (pSelectStatement->getRows() == 0)
         {
            if (!pSelectStatement->execute(hQuery1))
            {
               m_iResultCode = STS_QUERY_ERROR;
               m_lInfoIDNumber = STS_DATABASE_FAILURE;
               return false;
            }
         }
         hTable.set("DUP_SEQ_NO",++lDUP_SEQ_NO);
         pInsertStatement->execute(hTable);
         m_lInfoIDNumber = pInsertStatement->getInfoIDNumber();
         if (m_lInfoIDNumber == 0)
         {
            CaseSegment::instance()->setDUP_SEQ_NO(lDUP_SEQ_NO);
            return true;
         }
      }
      if (m_lInfoIDNumber == STS_DUPLICATE_RECORD)
      {
         auto_ptr<Statement> pInsertStatement1((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         if (pInsertStatement->getErrorType() == 1 && (pPersistentSegment)->segmentID() == (const char*) "S208")
         {
            if (getMaxCaseID() == false)
                return false;
         }
         else
         {
            auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
            short iNull;
            string strCASE_NO;
            Query hQuery;
            hQuery.reset();
            hQuery.bind("EMS_CASE", "CASE_NO", Column::STRING, &strCASE_NO, &iNull);
            hQuery.setBasicPredicate("EMS_CASE", "NET_ID_ACQ", "=", CaseSegment::instance()->getNET_ID_ACQ().c_str());
            hQuery.setBasicPredicate("EMS_CASE", "NET_ID_ISS", "=", CaseSegment::instance()->getNET_ID_ISS().c_str());
            hQuery.setBasicPredicate("EMS_CASE", "CASE_TYPE_IND", "=", CaseSegment::instance()->getCASE_TYPE_IND().c_str());
            hQuery.setBasicPredicate("EMS_CASE", "DUP_SEQ_NO", "=", CaseSegment::instance()->getDUP_SEQ_NO());
            hQuery.setBasicPredicate("EMS_CASE", "PAN", "=", CaseSegment::instance()->getPAN().c_str());
            hQuery.setBasicPredicate("EMS_CASE", "RETRIEVAL_REF_NO", "=", CaseSegment::instance()->getRETRIEVAL_REF_NO().c_str());
            hQuery.setBasicPredicate("EMS_CASE", "TSTAMP_LOCAL", "=", CaseSegment::instance()->getTSTAMP_LOCAL().c_str());
            hQuery.setBasicPredicate("EMS_CASE", "TSTAMP_TRANS", "=", CaseSegment::instance()->getTSTAMP_TRANS().c_str());
            hQuery.setBasicPredicate("EMS_CASE", "UNIQUENESS_KEY", "=", CaseSegment::instance()->getUNIQUENESS_KEY());
            hQuery.setBasicPredicate("EMS_CASE", "SYS_TRACE_AUDIT_NO", "=", CaseSegment::instance()->getSYS_TRACE_AUDIT_NO().c_str());
            if (pSelectStatement->execute(hQuery) && iNull != -1)
               Transaction::instance()->setText(strCASE_NO);
            return false;
         }
      }
      if (m_lInfoIDNumber == STS_DATABASE_FAILURE)
          return false;
   }
   if (strQUESTION_FIELDS.length() > 0)
   {
      if (CaseDocumentSegment::instance()->getDOC_TYPE() == "SMART_FORM")
         return insertSmartFormSegment(strQUESTION_FIELDS);
      else
      if (CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_PARB_"
          || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 8) == "REQ_ARB_"
          || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_PCMP_"
          || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_COMP_"
          || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_PRSP_"
          || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 9) == "REQ_CRSP_"
          || CaseDocumentSegment::instance()->getDOC_TYPE() == "REQ_CBRS")
         return insertDocExtSegment(strQUESTION_FIELDS);
      else
         return insertVROLSegment(strQUESTION_FIELDS);
   }
   if (CaseSegment::instance()->getCASE_TYPE_IND() == "D"
      && CaseTransitionSegment::instance()->getREQUEST_TYPE_NEXT().substr(0,3) == "FDR")
   {
      if (!CaseSegment::instance()->setTstampFirstFraud())
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
      if (CaseCardholderSegment::instance()->getTSTAMP_FIRST_FRAUD().empty()
         || CaseSegment::instance()->getTstampFirstFraud() < CaseCardholderSegment::instance()->getTSTAMP_FIRST_FRAUD())
      {
         SearchCondition hSearchCondition;
         Table hTable("EMS_CARDHOLDER");
         hTable.set("PAN",CaseSegment::instance()->getPAN(),false,true,false,2);
         hTable.set("TSTAMP_UPDATED",Transaction::instance()->getTimeStamp());
         if (CaseSegment::instance()->getTstampFirstFraud().empty())
            hTable.set("TSTAMP_FIRST_FRAUD"," ");
         else
            hTable.set("TSTAMP_FIRST_FRAUD",CaseSegment::instance()->getTstampFirstFraud());
         hTable.set("CHB_COUNTER",CaseCardholderSegment::instance()->getCHB_COUNTER());
         hTable.set("NET_ID",CaseSegment::instance()->getNET_ID_EMS());
         string strTemp = "(' ','" + CaseSegment::instance()->getNET_ID_EMS() + "')";
         hSearchCondition.setBasicPredicate("EMS_CARDHOLDER","NET_ID","IN",strTemp.c_str());
         if (CaseSegment::instance()->getCASE_EXTENSION() == "MCI")
         {
            hTable.set("DATE_EXPIRY",CasePhaseSegment::instance()->getDATE_EXPIRATION());
            hSearchCondition.setBasicPredicate("EMS_CARDHOLDER","DATE_EXPIRY","=",CasePhaseSegment::instance()->getDATE_EXPIRATION().empty() ? " " : CasePhaseSegment::instance()->getDATE_EXPIRATION().c_str());
         }
         else
            hSearchCondition.setBasicPredicate("EMS_CARDHOLDER","DATE_EXPIRY","="," ");
         auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
         if (pUpdateStatement->execute(hTable,hSearchCondition.getText()) == false && pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
         {
            auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
            if (pInsertStatement->execute(hTable) == false)
            {
               m_iResultCode = STS_QUERY_ERROR;
               m_lInfoIDNumber = STS_DATABASE_FAILURE;
               return false;
            }
         }
      }
   }
   return true;
  //## end emscommand::CaseCreateCommand::insertSegment%3EC9085402AF.body
}

bool CaseCreateCommand::insertSmartFormSegment (const string &strQUESTION_FIELDS)
{
  //## begin emscommand::CaseCreateCommand::insertSmartFormSegment%5CCA7E8B0333.body preserve=yes
   Table hTable;
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   int iQuestionLength = 0;
   iQuestionLength = strQUESTION_FIELDS.length();
   short siStart = 0;
   short siSEQ_NO = 1;
   while (siStart < iQuestionLength)
   {
      int iMaxRecord = MAXRECORD;
      if (siStart + MAXRECORD  < iQuestionLength)
      while (strQUESTION_FIELDS[siStart + iMaxRecord - 1] == ' ')
         iMaxRecord--;
      CaseSmartFormSegment::instance()->setCASE_ID(CaseSegment::instance()->getCASE_ID());
      CaseSmartFormSegment::instance()->setSEQ_NO(siSEQ_NO++);
      CaseSmartFormSegment::instance()->setDOC_SEQ_NO(CaseDocumentSegment::instance()->getSEQ_NO());
      CaseSmartFormSegment::instance()->setQUESTION_FIELDS(strQUESTION_FIELDS.substr(siStart, iMaxRecord));
      CaseSmartFormSegment::instance()->setColumns(hTable);
      if (!pInsertStatement->execute(hTable))
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
      siStart += iMaxRecord;
      hTable.reset();
   }
   return true;
  //## end emscommand::CaseCreateCommand::insertSmartFormSegment%5CCA7E8B0333.body
}

bool CaseCreateCommand::insertVROLSegment (string strQUESTION_FIELDS)
{
  //## begin emscommand::CaseCreateCommand::insertVROLSegment%47173EA300FA.body preserve=yes
   Table hTable;
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   int iQuestionLength = 0;
   iQuestionLength = strQUESTION_FIELDS.length();
   short siStart = 0;
   short siSEQ_NO = 1;
   while (siStart < iQuestionLength)
   {
      int iMaxRecord = MAXRECORD;
      if (siStart + MAXRECORD  < iQuestionLength)
         while ( strQUESTION_FIELDS[siStart+iMaxRecord-1] == ' ')
            iMaxRecord--;
      CasePhaseVisaVROLSegment::instance()->setSEQ_NO(siSEQ_NO++);
      CasePhaseVisaVROLSegment::instance()->setDOC_SEQ_NO(CaseDocumentSegment::instance()->getSEQ_NO());
      CasePhaseVisaVROLSegment::instance()->setQUESTION_FIELDS(strQUESTION_FIELDS.substr(siStart,iMaxRecord));
      CasePhaseVisaVROLSegment::instance()->setColumns(hTable);
      if(!pInsertStatement->execute(hTable))
      {
         Database::instance()->rollback();
         return UseCase::setSuccess(false);
      }
      siStart += iMaxRecord;
      hTable.reset();
   }
   CaseDocumentSegment::instance()->setDOC_PATH(strQUESTION_FIELDS);
   return true;
  //## end emscommand::CaseCreateCommand::insertVROLSegment%47173EA300FA.body
}

CaseCreateCommand* CaseCreateCommand::instance ()
{
  //## begin emscommand::CaseCreateCommand::instance%4B9F90080354.body preserve=yes
   if (!m_pInstance)
      new CaseCreateCommand();
   return m_pInstance;  
  //## end emscommand::CaseCreateCommand::instance%4B9F90080354.body
}

void CaseCreateCommand::mapStarTRAN_CODE ()
{
  //## begin emscommand::CaseCreateCommand::mapStarTRAN_CODE%3D53C6800242.body preserve=yes
   char* pszProcCode[30] =
   {
   "000000","001000","002000","003000","200000","200010","200020","200030",
   "010000","011000","012000","013000","061000","062000","063000","090000",
   "092000","210010","210020","500000","501000","502000","503000","FE",
   "FF",    "08",    "14",    "19",    "~"
   };
   char* pszTRAN_CODE[30] =
   {
   "DFPF",  "DFPS",  "DFPC",  "DFPCR", "CFMF",  "CFMS",  "CFMC",  "CFMCR",
   "DFWF",  "DFWS",  "DFWC",  "DFWCR", "DFTS",  "DFTC",  "DFTCR", "DFPC",
   "DFPC",  "CFDS",  "CFDC",  "DFPPF", "DFPPS", "DFPPC", "DFPPR", "DFPEB",
   "CFPRB", "CFMR",  "DFCWO", "DFTCO", "~"
   };
   string strTRAN_TYPE_ID(CaseSegment::instance()->getTRAN_TYPE_ID().substr(0,6));
   int i = 0;
   while (strcmp(pszProcCode[i],"~"))
   {
      strTRAN_TYPE_ID.resize(strlen(pszProcCode[i]));
      if (strTRAN_TYPE_ID == pszProcCode[i])
      {
         CaseStarSegment::instance()->setTRAN_CODE(pszTRAN_CODE[i]);
         break;
      }
      ++i;
   }
  //## end emscommand::CaseCreateCommand::mapStarTRAN_CODE%3D53C6800242.body
}

int CaseCreateCommand::parse ()
{
  //## begin emscommand::CaseCreateCommand::parse%375E7B7D02AB.body preserve=yes
   int iRC;
   if ((iRC = Command::parse()) != 0)
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,iRC);
      return -1;
   }
   if (!CommonHeaderSegment::instance()->presence())
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_COMMON_HEADER_SEGMENT);
      return -1;
   }
   if (!CaseSegment::instance()->presence())
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_CASE_SEGMENT);
      return -1;
   }
   if (!CasePhaseSegment::instance()->presence())
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_CASE_PHASE_SEGMENT);
      return -1;
   }
   if (!CaseTransitionSegment::instance()->presence())
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_TRANSITION_SEGMENT);
      return -1;
   }
   return 0;
  //## end emscommand::CaseCreateCommand::parse%375E7B7D02AB.body
}

bool CaseCreateCommand::replicate ()
{
  //## begin emscommand::CaseCreateCommand::replicate%4B74047D02FD.body preserve=yes
   string strPROC_DEST_ID;
   string strPROC_ID(CaseSegment::instance()->getPROC_ID_ACQ());
   bool bReplicate(false);
   if ((bReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECOUT','ECHIST'",strPROC_DEST_ID)) == false)
   {
      strPROC_ID = CaseSegment::instance()->getPROC_ID_ISS();
      if ((bReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECOUT'",strPROC_DEST_ID)) == false)
      {
         strPROC_ID = CaseSegment::instance()->getPROC_ID_ACQ_B();
         if ((bReplicate=DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECOUT'",strPROC_DEST_ID)) == false)
         {
            strPROC_ID = CaseSegment::instance()->getPROC_ID_ISS_B();
            if ((bReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECOUT'",strPROC_DEST_ID)) == false)
            {
               strPROC_ID = CaseSegment::instance()->getPROC_GRP_ID_ACQ_B();
               if ((bReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECOUT'",strPROC_DEST_ID)) == false)
               {
                  strPROC_ID = CaseSegment::instance()->getPROC_GRP_ID_ISS_B();
                  bReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECOUT'",strPROC_DEST_ID);
               }
            }
         }
      }
   }
   if (CaseSegment::instance()->getOTHER_CASE_NO().length())
      return true;
   Case::instance()->backupSegments();
   string strCASE_NO(CaseSegment::instance()->getCASE_NO());
   int lCASE_ID = CaseSegment::instance()->getCASE_ID();
   string strINST_DEST_ID;
   bool bInstReplicate(false);
   if (DataControl::instance()->getLevel(DataControl::I))
   {
      string strINST_ID(CaseSegment::instance()->getINST_ID_RECN_ACQ_B());
      if ((bInstReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getInstitutionDestination(strINST_ID,"'ECOUT'",strINST_DEST_ID)) == false)
      {
         strINST_ID = CaseSegment::instance()->getINST_ID_RECON_ISS();
         bInstReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getInstitutionDestination(strINST_ID,"'ECOUT'",strINST_DEST_ID);
      }
   }
   if (bReplicate || bInstReplicate)
   {
      CommonHeaderSegment::instance()->setPROC_DEST_ID(strPROC_DEST_ID);
      CaseSegment::instance()->setReplicatedCASE_ID(CaseSegment::instance()->getCASE_ID());
      CaseSegment::instance()->setReplicatedCASE_NO(CaseSegment::instance()->getCASE_NO());
      if ((CaseSegment::instance()->getNET_ID_EMS() == "ILK" || CaseSegment::instance()->getNET_ID_EMS() == "PLS")
         && CaseSegment::instance()->getTSTAMP_TRANS().length())
      {
         Case::instance()->retrieveTransaction();
         CaseSegment::instance()->setReplicatedRETRIEVAL_REF_NO(FinancialBaseSegment::instance()->getRETRIEVAL_REF_NO());
         CaseSegment::instance()->setReplicatedSYS_TRACE_AUDIT_NO(FinancialBaseSegment::instance()->getSYS_TRACE_AUDIT_NO());
      }
      Command::replicate();
      if (bInstReplicate)
      {
         if (CaseSegment::instance()->getINST_ID_RECN_ACQ_B() != CaseSegment::instance()->getINST_ID_RECON_ISS())
         {
            DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*I", CaseSegment::instance()->getINST_ID_RECN_ACQ_B());
            DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*I", CaseSegment::instance()->getINST_ID_RECON_ISS());
         }
         else
            DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*I", CaseSegment::instance()->getINST_ID_RECN_ACQ_B());
      }
      if (bReplicate)
      {
      if (CaseSegment::instance()->getPROC_ID_ACQ() != CaseSegment::instance()->getPROC_ID_ISS())
         DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*P",CaseSegment::instance()->getPROC_ID_ISS());
      if (CaseSegment::instance()->getPROC_ID_ACQ() != CaseSegment::instance()->getPROC_ID_ACQ_B())
         DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*P",CaseSegment::instance()->getPROC_ID_ACQ_B());
      DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*P",CaseSegment::instance()->getPROC_ID_ACQ());
      if (CaseSegment::instance()->getPROC_ID_ISS() != CaseSegment::instance()->getPROC_ID_ISS_B())
         DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*P",CaseSegment::instance()->getPROC_ID_ISS_B());
      if (CaseSegment::instance()->getPROC_GRP_ID_ACQ_B() != CaseSegment::instance()->getPROC_GRP_ID_ISS_B())
         DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*G", CaseSegment::instance()->getPROC_GRP_ID_ISS_B());
      DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*G", CaseSegment::instance()->getPROC_GRP_ID_ACQ_B());
      }
   }
   if (Customer::instance()->getFUNDS_PROC_ID().empty() == false)
   {
       if (bReplicate == false)
       {
           if ((CaseSegment::instance()->getNET_ID_EMS() == "ILK" || CaseSegment::instance()->getNET_ID_EMS() == "PLS")
               && CaseSegment::instance()->getTSTAMP_TRANS().length())
           {
               Case::instance()->retrieveTransaction();
               CaseSegment::instance()->setReplicatedRETRIEVAL_REF_NO(FinancialBaseSegment::instance()->getRETRIEVAL_REF_NO());
               CaseSegment::instance()->setReplicatedSYS_TRACE_AUDIT_NO(FinancialBaseSegment::instance()->getSYS_TRACE_AUDIT_NO());
           }
       }
       strPROC_ID.assign(Customer::instance()->getFUNDS_PROC_ID());
       if (!DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID, "'ECOUT'", strPROC_DEST_ID))
           CaseSegment::instance()->setCASE_NO(strCASE_NO);
       else
       {
           CommonHeaderSegment::instance()->setPROC_DEST_ID(strPROC_DEST_ID);
           CaseSegment::instance()->setReplicatedCASE_ID(CaseSegment::instance()->getCASE_ID());
           CaseSegment::instance()->setReplicatedCASE_NO(CaseSegment::instance()->getCASE_NO());
           Command::replicate();
           DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*P", strPROC_ID);
       }
   }
   if (Case::instance()->checkInstId(CaseSegment::instance()->getINST_ID_RECON_ISS()))
   {
      strPROC_ID.assign(Customer::instance()->getFUNDS_PROC_ID());
      if (!DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECHIST'",strPROC_DEST_ID))
      {
         Case::instance()->restoreSegments();
         CaseSegment::instance()->setCASE_ID(lCASE_ID);
         CaseSegment::instance()->setCASE_NO(strCASE_NO);
         return true;
      }
      CommonHeaderSegment::instance()->setPROC_DEST_ID(strPROC_DEST_ID);
      CaseSegment::instance()->setReplicatedCASE_NO(CaseSegment::instance()->getCASE_NO());
      CaseSegment::instance()->setReplicatedCASE_ID(CaseSegment::instance()->getCASE_ID());
      Command::replicate();
      DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*P",strPROC_ID);
   }
   Case::instance()->restoreSegments();
   CaseSegment::instance()->setCASE_NO(strCASE_NO);
   CaseSegment::instance()->setCASE_ID(lCASE_ID);
   return true;
  //## end emscommand::CaseCreateCommand::replicate%4B74047D02FD.body
}

void CaseCreateCommand::replicateOtherCase ()
{
  //## begin emscommand::CaseCreateCommand::replicateOtherCase%4E70CB07017C.body preserve=yes
   *Message::instance(Message::INBOUND) = *Message::instance(Message::OUTBOUND);
   char pszLength[9] = {"        "};
   char* psBuffer = Message::instance(Message::OUTBOUND)->data() + 8;
   char* pEndOfMessage = Message::instance(Message::OUTBOUND)->data() + Message::instance(Message::OUTBOUND)->dataLength();
   vector<Segment*>::iterator ppSegment;
   int iRC = 0;
   while (psBuffer < pEndOfMessage)
   {
      if (memcmp(psBuffer,"S208",4) == 0)
      {
         CaseSegment::instance()->deport(&psBuffer);
         break;
      }
      memcpy(pszLength,psBuffer + 8,8);
      psBuffer += atoi(pszLength);
   }
   string strClientVersion(CommonHeaderSegment::instance()->getClientVersion());
   replicate();
   CommonHeaderSegment::instance()->setClientVersion(strClientVersion);
   *Message::instance(Message::OUTBOUND) = *Message::instance(Message::INBOUND);
  //## end emscommand::CaseCreateCommand::replicateOtherCase%4E70CB07017C.body
}

void CaseCreateCommand::setCaseCountryISS ()
{
  //## begin emscommand::CaseCreateCommand::setCaseCountryISS%4CCD58FF0060.body preserve=yes
   InstitutionBinSegment hInstitutionBinSegment;
   if (EMSRulesEngine::instance()->getInstitutionBIN(CaseSegment::instance()->getPAN(), Transaction::instance()->getCustomer(),hInstitutionBinSegment))
   {
      if (hInstitutionBinSegment.getCURRENCY_CODE().empty() && !(CaseSegment::instance()->getCOUNTRY_ISS().empty()))
      {
         Table hTable("INSTITUTION_BIN");
         hTable.setQualifier("QUALIFY");
         hTable.set("CURRENCY_CODE",CaseSegment::instance()->getCOUNTRY_ISS().c_str());
         hTable.set("BIN",hInstitutionBinSegment.getBIN().c_str(),false,true);
         hTable.set("INST_ID",hInstitutionBinSegment.getINST_ID().c_str(),false,true);
         auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
         if (pUpdateStatement->execute(hTable) == true)
            EMSRulesEngine::instance()->updateInstitutionBIN(hInstitutionBinSegment.getBIN(), Transaction::instance()->getCustomer(),CaseSegment::instance()->getCOUNTRY_ISS().c_str());      
      }               
   }   
   else if (CaseSegment::instance()->getINST_ID_RECON_ISS().length())
   {
      InstitutionBinSegment::instance()->reset();
      if (CaseSegment::instance()->getCOUNTRY_ISS().empty())
      {
         if (Customer::instance()->getCUST_COUNTRY_CODE().empty())
            return;
         else
         {
            CaseSegment::instance()->setCOUNTRY_ISS(Customer::instance()->getCUST_COUNTRY_CODE());
            InstitutionBinSegment::instance()->setCURRENCY_CODE(Customer::instance()->getCUST_COUNTRY_CODE());
         }
      }
      else
         InstitutionBinSegment::instance()->setCURRENCY_CODE(CaseSegment::instance()->getCOUNTRY_ISS());
      if (!EMSRulesEngine::instance()->getPanPrefix(CaseSegment::instance()->getPAN(),CaseSegment::instance()->getNET_ID_EMS()))
      {   
         if (CaseSegment::instance()->getCASE_EXTENSION() == "VNT"
            && !CaseVisaSegment::instance()->getISS_BIN().empty())
            InstitutionBinSegment::instance()->setBIN(CaseVisaSegment::instance()->getISS_BIN());
         else
            return;
      }
      else
         InstitutionBinSegment::instance()->setBIN(PanPrefixSegment::instance()->getNET_INST_ID_CODE());
      InstitutionBinSegment::instance()->setINST_ID(CaseSegment::instance()->getINST_ID_RECON_ISS());
      InstitutionBinSegment::instance()->setNET_ID(CaseSegment::instance()->getNET_ID_EMS());
      InstitutionBinSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
      InstitutionBinSegment::instance()->setCC_CHANGE_GRP_ID("~NULL!");
      InstitutionBinSegment::instance()->setCC_LAST_OPERATION("INS");
      InstitutionBinSegment::instance()->setCC_STATE("A");
      InstitutionBinSegment::instance()->setCC_USER_ID("SYSTEM");
      InstitutionBinSegment::instance()->setCC_TSTAMP_CHANGE(Transaction::instance()->getTimeStamp().substr(0,14));
      Table hTable;
      auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      InstitutionBinSegment::instance()->setColumns(hTable);
      if (pInsertStatement->execute(hTable) == false)
      {
         if (pInsertStatement->getInfoIDNumber() == STS_DUPLICATE_RECORD)
         {
            auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
            if (pUpdateStatement->execute(hTable) == false)
               EMSRulesEngine::instance()->updateInstitutionBIN(InstitutionBinSegment::instance()->getBIN(), Transaction::instance()->getCustomer(),CaseSegment::instance()->getCOUNTRY_ISS());      
         }
      }
      else
         EMSRulesEngine::instance()->updateInstitutionBIN(InstitutionBinSegment::instance()->getBIN(), Transaction::instance()->getCustomer(),CaseSegment::instance()->getCOUNTRY_ISS(),true);      
   }
  //## end emscommand::CaseCreateCommand::setCaseCountryISS%4CCD58FF0060.body
}

void CaseCreateCommand::update (Subject* pSubject)
{
  //## begin emscommand::CaseCreateCommand::update%3731DCBA0197.body preserve=yes
   if (pSubject == Message::instance(Message::INBOUND)
      && Message::instance(Message::INBOUND)->messageID() == "S0003D")
   {
      char* p = ((Message*)pSubject)->data() + 24;
      if (strncmp(p,"QEMCCASE",8) == 0)
      {
         // CL18: Client_Adds_Case_To_DB
         UseCase hUseCase("CLIENT","## CL18 ADD CASE");
         *Message::instance(Message::OUTBOUND) = *Message::instance(Message::INBOUND);
         if (parse() != 0)
         {
            UseCase::setSuccess(false);
            return;
         }
         bool bSuccess = execute();
         if (bSuccess)
            setCaseCountryISS();            
         Transaction::instance()->setQualifier("CUSTQUAL");
         Transaction::instance()->setCustomer(m_strCUST_ID);
         if (!bSuccess)
         {
            if (m_iResultCode == 0)
               m_iResultCode = STS_ERROR;
            EMailMessage::eraseAll();
            Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            sendError(m_iResultCode,STS_ERROR,m_lInfoIDNumber);
            UseCase::setSuccess(false);
            return;
         }
         if (CardholderInformationSegment::instance()->presence())
         {
            string strTSTAMP_LAST_UPDATE;
            Query hQuery;
            hQuery.setQualifier("QUALIFY","CARDHOLDER");
            hQuery.bind("CARDHOLDER","TSTAMP_LAST_UPDATE",Column::STRING,&strTSTAMP_LAST_UPDATE);
            hQuery.setBasicPredicate("CARDHOLDER","PAN","=",CardholderInformationSegment::instance()->getPAN().c_str());
            auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
            pSelectStatement->execute(hQuery);
            CardholderInformationSegment::instance()->setTSTAMP_LAST_UPDATE(strTSTAMP_LAST_UPDATE);
         }
         
         if (CasePhaseSegment::instance()->getFEE_REL_CASE_NO().length() != 0 || Case::instance()->checkFraudCase())
            CaseSegment::instance()->setRelatedCases("Y");
         Database::instance()->setTransactionState(Database::COMMITREQUIRED);
         Message::instance(Message::INBOUND)->reset("EMSCI ","S0003R");
         m_pDataBuffer = ((Message*)pSubject)->data() + 8;
         CommonHeaderSegment::instance()->deport(&m_pDataBuffer);
         vector<Segment*>::iterator ppSegment;
         for (ppSegment = m_hSegments.begin();ppSegment != m_hSegments.end();++ppSegment)
         {
            if ((*ppSegment)->presence() && (((*ppSegment)->segmentID() != (const char*)"L001")&&
                    ((*ppSegment)->segmentID() != (const char*)"S053") &&
                    ((*ppSegment)->segmentID() != (const char*)"S912") &&
                    ((*ppSegment)->segmentID() != (const char*)"S001") &&
                    ((*ppSegment)->segmentID() != (const char*)"S400")))
                        (*ppSegment)->deport(&m_pDataBuffer);
         }
         InformationSegment hInformationSegment;
         if (m_lInfoIDNumber != 0)
            hInformationSegment.setError(STS_INFORMATION,m_lInfoIDNumber);
         getResponseTimeSegment()->deport(&m_pDataBuffer);
         Message hMessage(*(Message::instance(Message::INBOUND)));
         replicate();
         *(Message::instance(Message::INBOUND)) = hMessage;
         if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
         {
            m_iResultCode = STS_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            sendError(m_iResultCode,STS_ERROR,m_lInfoIDNumber,false);
            return;
         }
         reply();
         CardholderInformationSegment::instance()->wipe("PAN");
      }
      else
      if (m_pSuccessor)
         m_pSuccessor->update(pSubject);
      return;
   }
   ClientCommand::update(pSubject);
   
  //## end emscommand::CaseCreateCommand::update%3731DCBA0197.body
}

bool CaseCreateCommand::validDuplicate ()
{
  //## begin emscommand::CaseCreateCommand::validDuplicate%495E140F0280.body preserve=yes
   Trace::put("validDuplicate");
   string strREQUEST_TYPE_NEXT(CaseTransitionSegment::instance()->getREQUEST_TYPE_NEXT());
   string strSTATUS_NEXT(CaseTransitionSegment::instance()->getSTATUS_NEXT());
   string strValue;
   Trace::put(strREQUEST_TYPE_NEXT.c_str());
   Trace::put(strSTATUS_NEXT.c_str());
   Trace::put(CaseSegment::instance()->getCASE_EXTENSION().c_str());
   Trace::put(CasePhaseSegment::instance()->getUSER_ROLE().c_str());
   if (Extract::instance()->getCustomCode() == "EBT" )
   {
      Query hQuery;
      string strREQUEST_TYPE;
      string strSTATUS;
      hQuery.bind("EMS_CASE","REQUEST_TYPE",Column::STRING,&strREQUEST_TYPE);
      hQuery.bind("EMS_CASE","STATUS",Column::STRING,&strSTATUS);
      hQuery.setBasicPredicate("EMS_CASE","TSTAMP_TRANS","=",CaseSegment::instance()->getTSTAMP_TRANS().c_str());
      hQuery.setBasicPredicate("EMS_CASE","UNIQUENESS_KEY","=",CaseSegment::instance()->getUNIQUENESS_KEY());
      hQuery.setOrderByClause("CASE_ID");
      auto_ptr<SelectStatement>pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
         return false;
      if (strREQUEST_TYPE == "ARB" && strSTATUS == "CLOS")
         return true;
   }
   if (IF::Extract::instance()->getRecord("DSPEC   GE10    MULTICHB~Y", strValue)
      || CaseSegment::instance()->getCASE_TYPE_IND() == "E0")
      return true;
   else
   if (CaseSegment::instance()->getCASE_EXTENSION() == "MCI")
   {
      if ((CasePhaseSegment::instance()->getUSER_ROLE() == "I"
         || CasePhaseSegment::instance()->getUSER_ROLE() == "*")
         && CaseSegment::instance()->getMERCHANT_CAT_CODE() != "6011")
      {
         if (strREQUEST_TYPE_NEXT == "CHB1" && strSTATUS_NEXT == "FWRD"
            && CasePhaseSegment::instance()->getAMT_ADJUSTMENT() < CaseSegment::instance()->getAMT_TRAN()
            || (strREQUEST_TYPE_NEXT == "FEEZ" && strSTATUS_NEXT == "SDRC"))
            return true;
      }
      else
      if (CasePhaseSegment::instance()->getUSER_ROLE() == "A" || CasePhaseSegment::instance()->getUSER_ROLE() == "*")
      {
         if ((strREQUEST_TYPE_NEXT == "DOCR" && (strSTATUS_NEXT == "SDRC"
            || strSTATUS_NEXT == "HOLD" || strSTATUS_NEXT == "CLUN" || strSTATUS_NEXT == "GETT"))
            || (strREQUEST_TYPE_NEXT == "CHB1" && (strSTATUS_NEXT == "SDRC"
            || strSTATUS_NEXT == "HOLD" || strSTATUS_NEXT == "CLUN" || strSTATUS_NEXT == "GETT"))
            || (strREQUEST_TYPE_NEXT == "FEEZ" && strSTATUS_NEXT == "SDRC" ))
               //&& CaseSegment::instance()->getPAN()[0] == ' '
               return true;
      }
   }
   else
   if (CaseSegment::instance()->getCASE_EXTENSION() == "VNT")
   {
      if ((CasePhaseSegment::instance()->getUSER_ROLE() == "I"
         || CasePhaseSegment::instance()->getUSER_ROLE() == "*")
         && (CaseSegment::instance()->getNET_ID_EMS() != "ILK"
         && CaseSegment::instance()->getNET_ID_EMS().substr(0,2) != "PL"))
      {
         if (strREQUEST_TYPE_NEXT == "CHB1" && strSTATUS_NEXT == "FWRD"
            && CasePhaseSegment::instance()->getAMT_ADJUSTMENT() < CaseSegment::instance()->getAMT_TRAN())
            return true;
      }
      else
      if (CasePhaseSegment::instance()->getUSER_ROLE() == "A" || CasePhaseSegment::instance()->getUSER_ROLE() == "*")
      {
         if ((strREQUEST_TYPE_NEXT == "DOCR" && (strSTATUS_NEXT == "SDRC"
            || strSTATUS_NEXT == "HOLD" || strSTATUS_NEXT == "CLUN"))
            || (strREQUEST_TYPE_NEXT == "CHB1" && (strSTATUS_NEXT == "SDRC"
            || strSTATUS_NEXT == "HOLD" || strSTATUS_NEXT == "CLUN")))
            return true;
      }
   }
   else
   if (CaseSegment::instance()->getCASE_EXTENSION() == "ZAP")
   {
      Query hQuery;
      CaseZappSegment pCaseZappSegment;
      pCaseZappSegment.bind(hQuery);
      auto_ptr<SelectStatement>pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      hQuery.setBasicPredicate("EMS_CASE_ZAP","BATCHID","=",CaseZappSegment::instance()->getBATCHID().c_str());
      if ((!pSelectStatement->execute(hQuery)) || (pSelectStatement->getRows() != 0))
         return false;
	  else
         return true;
   }
   else if (CaseSegment::instance()->getTSTAMP_TRANS().length() == 0)
      return true;
   return false;
  //## end emscommand::CaseCreateCommand::validDuplicate%495E140F0280.body
}

// Additional Declarations
  //## begin emscommand::CaseCreateCommand%357453C2017E.declarations preserve=yes
  //## end emscommand::CaseCreateCommand%357453C2017E.declarations

} // namespace emscommand

//## begin module%35758F6B03D2.epilog preserve=yes
//## end module%35758F6B03D2.epilog
