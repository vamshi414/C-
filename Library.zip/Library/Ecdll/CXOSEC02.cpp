//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35ACB5CF0114.cm preserve=no
//## end module%35ACB5CF0114.cm

//## begin module%35ACB5CF0114.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%35ACB5CF0114.cp

//## Module: CXOSEC02%35ACB5CF0114; Package body
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Ecdll\CXOSEC02.cpp

//## begin module%35ACB5CF0114.additionalIncludes preserve=no
//## end module%35ACB5CF0114.additionalIncludes

//## begin module%35ACB5CF0114.includes preserve=yes
#include "CXODES96.hpp"
#include "CXODDB05.hpp"
#include "CXODPS01.hpp"
#include "CXODEX77.hpp"
#include "CXODEX76.hpp"
#include "CXODIF03.hpp"
#include "CXODIF11.hpp"
#include "CXODIF13.hpp"
#include "CXODDB27.hpp"
#include "CXODDB06.hpp"
#include "CXODRU28.hpp"
#include "CXODNS29.hpp"
#include "CXODEX69.hpp"
#include "CXODES83.hpp"
#include "CXODES90.hpp"
#include "CXODEX91.hpp"
#include "CXODTM04.hpp"
#include <CXODBC27.hpp>
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%35ACB5CF0114.includes

#ifndef CXOSES61_h
#include "CXODES61.hpp"
#endif
#ifndef CXOSES91_h
#include "CXODES91.hpp"
#endif
#ifndef CXOSES94_h
#include "CXODES94.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF35_h
#include "CXODIF35.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSES02_h
#include "CXODES02.hpp"
#endif
#ifndef CXOSUS05_h
#include "CXODUS05.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSIF36_h
#include "CXODIF36.hpp"
#endif
#ifndef CXOSRS51_h
#include "CXODRS51.hpp"
#endif
#ifndef CXOSEX03_h
#include "CXODEX03.hpp"
#endif
#ifndef CXOSES34_h
#include "CXODES34.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSEX27_h
#include "CXODEX27.hpp"
#endif
#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOSES38_h
#include "CXODES38.hpp"
#endif
#ifndef CXOSES37_h
#include "CXODES37.hpp"
#endif
#ifndef CXOSES18_h
#include "CXODES18.hpp"
#endif
#ifndef CXOSES36_h
#include "CXODES36.hpp"
#endif
#ifndef CXOSES45_h
#include "CXODES45.hpp"
#endif
#ifndef CXOSEX36_h
#include "CXODEX36.hpp"
#endif
#ifndef CXOSEC02_h
#include "CXODEC02.hpp"
#endif


//## begin module%35ACB5CF0114.declarations preserve=no
//## end module%35ACB5CF0114.declarations

//## begin module%35ACB5CF0114.additionalDeclarations preserve=yes
#define MAXRECORD 2000
//## end module%35ACB5CF0114.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

// Class emscommand::CaseUpdateCommand 

//## begin emscommand::CaseUpdateCommand::Instance%40A26CD9034B.attr preserve=no  private: static emscommand::CaseUpdateCommand* {V} 0
emscommand::CaseUpdateCommand* CaseUpdateCommand::m_pInstance = 0;
//## end emscommand::CaseUpdateCommand::Instance%40A26CD9034B.attr

CaseUpdateCommand::CaseUpdateCommand()
  //## begin CaseUpdateCommand::CaseUpdateCommand%35ACB26A01AB_const.hasinit preserve=no
      : m_bDocExt(false),
        m_bQuestionnaireUpdated(false),
        m_bRCChanged(false)
  //## end CaseUpdateCommand::CaseUpdateCommand%35ACB26A01AB_const.hasinit
  //## begin CaseUpdateCommand::CaseUpdateCommand%35ACB26A01AB_const.initialization preserve=yes
   ,ClientCommand("S0003D")
  //## end CaseUpdateCommand::CaseUpdateCommand%35ACB26A01AB_const.initialization
{
  //## begin emscommand::CaseUpdateCommand::CaseUpdateCommand%35ACB26A01AB_const.body preserve=yes
   memcpy(m_sID,"EC02",4);
   Extract::instance()->getSpec("CUSTOMER",m_strCUST_ID);
   Case::addCaseCommandSegments(m_hSegments);
   m_pListSegment[0] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[0]);
   m_pListSegment[1] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[1]);
   m_pListSegment[2] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[2]);
   m_pListSegment[3] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[3]);
   m_hUSTerritories.insert("USA");
   m_hUSTerritories.insert("GUM");
   m_hUSTerritories.insert("ASM");
   m_hUSTerritories.insert("MNP");
   m_hUSTerritories.insert("UMI");
   m_hUSTerritories.insert("PRI");
   m_hUSTerritories.insert("VIR");
   m_pInstance = this;
  //## end emscommand::CaseUpdateCommand::CaseUpdateCommand%35ACB26A01AB_const.body
}

CaseUpdateCommand::CaseUpdateCommand (Handler* pSuccessor)
  //## begin emscommand::CaseUpdateCommand::CaseUpdateCommand%3731EA80029B.hasinit preserve=no
      : m_bDocExt(false),
        m_bQuestionnaireUpdated(false),
        m_bRCChanged(false)
  //## end emscommand::CaseUpdateCommand::CaseUpdateCommand%3731EA80029B.hasinit
  //## begin emscommand::CaseUpdateCommand::CaseUpdateCommand%3731EA80029B.initialization preserve=yes
   , ClientCommand("S0003D","@##EMUCASE")
  //## end emscommand::CaseUpdateCommand::CaseUpdateCommand%3731EA80029B.initialization
{
  //## begin emscommand::CaseUpdateCommand::CaseUpdateCommand%3731EA80029B.body preserve=yes
   memcpy(m_sID,"EC02",4);
   Extract::instance()->getSpec("CUSTOMER",m_strCUST_ID);
   m_pSuccessor = pSuccessor;
   Case::addCaseCommandSegments(m_hSegments);
   m_pListSegment[0] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[0]);
   m_pListSegment[1] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[1]);
   m_pListSegment[2] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[2]);
   m_pListSegment[3] = new ListSegment();
   m_hSegments.push_back(m_pListSegment[3]);
   m_hUSTerritories.insert("USA");
   m_hUSTerritories.insert("GUM");
   m_hUSTerritories.insert("ASM");
   m_hUSTerritories.insert("MNP");
   m_hUSTerritories.insert("UMI");
   m_hUSTerritories.insert("PRI");
   m_hUSTerritories.insert("VIR");
   m_pInstance = this;
  //## end emscommand::CaseUpdateCommand::CaseUpdateCommand%3731EA80029B.body
}


CaseUpdateCommand::~CaseUpdateCommand()
{
  //## begin emscommand::CaseUpdateCommand::~CaseUpdateCommand%35ACB26A01AB_dest.body preserve=yes
   Database::instance()->detach(this);
   delete m_pListSegment[0];
   delete m_pListSegment[1];
   delete m_pListSegment[2];
   delete m_pListSegment[3];
   m_hUSTerritories.erase(m_hUSTerritories.begin(),m_hUSTerritories.end());
  //## end emscommand::CaseUpdateCommand::~CaseUpdateCommand%35ACB26A01AB_dest.body
}



//## Other Operations (implementation)
void CaseUpdateCommand::calculateSurcharge ()
{
  //## begin emscommand::CaseUpdateCommand::calculateSurcharge%511918410115.body preserve=yes
   Trace::put("calculatesurcharge");
   if (CaseSegment::instance()->getMERCHANT_CAT_CODE() != "6011" 
      && m_hUSTerritories.find(CaseSegment::instance()->getCARD_ACPT_COUNTRY()) == m_hUSTerritories.end())
      return;
   string strTRAN_TYPE_ID(CaseSegment::instance()->getTRAN_TYPE_ID());
   double dAMT_SURCHARGE_FEE = CaseSegment::instance()->getAMT_SURCHARGE_FEE();
   double dAMT_RECON_NET = CaseSegment::instance()->getAMT_RECON_NET();
   double dAMT_ADJUSTMENT = CasePhaseSegment::instance()->getAMT_ADJUSTMENT();
   bool bFull=true;
            
   if (strTRAN_TYPE_ID.length() > 1 && strTRAN_TYPE_ID.substr(0,2) == "01"      // withdrawal
      && dAMT_ADJUSTMENT < (dAMT_RECON_NET - dAMT_SURCHARGE_FEE))
      bFull = false;
   if (strTRAN_TYPE_ID.length() > 1 && strTRAN_TYPE_ID.substr(0,2) != "01")     
   {
      if ((CaseTransitionSegment::instance()->presence() 
         && CaseTransitionSegment::instance()->getREQUEST_TYPE_NEXT().substr(0,3) == "ADJ")
         || CaseSegment::instance()->getREQUEST_TYPE().substr(0,3) == "ADJ")
      {
         if (dAMT_ADJUSTMENT != dAMT_RECON_NET)  //adj amt can be > tran amt
            bFull = false;
      }
      else if (dAMT_ADJUSTMENT < dAMT_RECON_NET)
         bFull = false;
   }
   if(bFull)  // both chb and adj comes here
   {
      Trace::put("full chb adj or rep");
      CasePhaseSegment::instance()->setAMT_SURCHARGE(CaseSegment::instance()->getAMT_SURCHARGE_FEE());
   }
   else
   { // make zero surcharge internally also
      Trace::put("partial chb adj rep");
      if (CaseSegment::instance()->getMERCHANT_CAT_CODE() == "6011")
         CasePhaseSegment::instance()->setAMT_SURCHARGE(0);
      else if (dAMT_RECON_NET != 0)
         CasePhaseSegment::instance()->setAMT_SURCHARGE(dAMT_SURCHARGE_FEE * (dAMT_ADJUSTMENT/(dAMT_RECON_NET-dAMT_SURCHARGE_FEE)));
   }
  //## end emscommand::CaseUpdateCommand::calculateSurcharge%511918410115.body
}

bool CaseUpdateCommand::deleteDocExtension ()
{
  //## begin emscommand::CaseUpdateCommand::deleteDocExtension%5E7B0C480299.body preserve=yes
   short siDOC_SEQ_NO = 0;
   Query hQuery;
   hQuery.bind("EMS_DOCUMENT","SEQ_NO",Column::SHORT,&siDOC_SEQ_NO);
   hQuery.setBasicPredicate("EMS_DOCUMENT","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
   hQuery.getSearchCondition().append(" AND ");
   hQuery.getSearchCondition().append("(");
   hQuery.setBasicPredicate("EMS_DOCUMENT","DOC_TYPE","LIKE","REQ_PARB_%");
   hQuery.setBasicPredicate("EMS_DOCUMENT","DOC_TYPE","LIKE","REQ_ARB_%",false,false);
   hQuery.setBasicPredicate("EMS_DOCUMENT","DOC_TYPE","LIKE","REQ_PCMP_%",false,false);
   hQuery.setBasicPredicate("EMS_DOCUMENT","DOC_TYPE","LIKE","REQ_COMP_%",false,false);
   hQuery.setBasicPredicate("EMS_DOCUMENT","DOC_TYPE","LIKE","REQ_PRSP_%",false,false);
   hQuery.setBasicPredicate("EMS_DOCUMENT","DOC_TYPE","LIKE","REQ_CRSP_%",false,false);
   hQuery.setBasicPredicate("EMS_DOCUMENT", "DOC_TYPE", "=", "REQ_CBRS", false, false);
   hQuery.getSearchCondition().append(")");
   hQuery.setBasicPredicate("EMS_DOCUMENT", "EXPORT_IND", "=", "R");
   hQuery.setBasicPredicate("EMS_DOCUMENT", "DELETE_FLG", "=", "N");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
   {
      m_iResultCode = STS_QUERY_ERROR;
      m_lInfoIDNumber = STS_DATABASE_FAILURE;
      return false;
   }
   if (pSelectStatement->getRows())
   {
      hQuery.reset();
      hQuery.attach(this);
      hQuery.bind("EMS_DOCUMENT_EXT","DATA_BUFFER",Column::STRING, &m_strQUESTION_FIELDS);
      hQuery.setBasicPredicate("EMS_DOCUMENT_EXT","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
      hQuery.setBasicPredicate("EMS_DOCUMENT_EXT","DOC_SEQ_NO", "=",siDOC_SEQ_NO);
      if (!pSelectStatement->execute(hQuery))
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
      hQuery.reset();
      hQuery.setBasicPredicate("EMS_DOCUMENT_EXT","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
      hQuery.setBasicPredicate("EMS_DOCUMENT_EXT","DOC_SEQ_NO","=",siDOC_SEQ_NO);
      auto_ptr<reusable::SelectStatement> pDeleteStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("DeleteStatement"));
      if (!pDeleteStatement->execute(hQuery))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         m_iResultCode = STS_QUERY_ERROR;
         return false;
      }
      hQuery.reset();
      hQuery.setBasicPredicate("EMS_DOCUMENT","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
      hQuery.setBasicPredicate("EMS_DOCUMENT","SEQ_NO","=",siDOC_SEQ_NO);
      if (!pDeleteStatement->execute(hQuery))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         m_iResultCode = STS_QUERY_ERROR;
         return false;
      }
   }
   return true;
  //## end emscommand::CaseUpdateCommand::deleteDocExtension%5E7B0C480299.body
}

bool CaseUpdateCommand::deleteNonExportedQuestionnaire ()
{
  //## begin emscommand::CaseUpdateCommand::deleteNonExportedQuestionnaire%4DB704A5006C.body preserve=yes
   short siDOC_SEQ_NO = 0;
   if ( CaseSegment::instance()->getCASE_EXTENSION() == "VNT"
      && ((CaseTransitionSegment::instance()->getUSER_ID() == "SYSTEM"
      && CaseSegment::instance()->getOTHER_CUST_ID() == "XPRT")
      || CaseTransitionSegment::instance()->getUSER_ID() != "SYSTEM"))
   {
      Query hQuery; 
      hQuery.bind("EMS_DOCUMENT","SEQ_NO",Column::SHORT,&siDOC_SEQ_NO);
      hQuery.setBasicPredicate("EMS_DOCUMENT","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
      hQuery.getSearchCondition().append(" AND ");
      hQuery.getSearchCondition().append("(");
      hQuery.setBasicPredicate("EMS_DOCUMENT", "DOC_TYPE", "LIKE", "QTN_%");
      hQuery.setBasicPredicate("EMS_DOCUMENT", "DOC_TYPE", "LIKE", "DCF%", false, false);
	  hQuery.setBasicPredicate("EMS_DOCUMENT", "DOC_TYPE", "=", "PI_DATA", false, false);
      hQuery.getSearchCondition().append(")");
      hQuery.setBasicPredicate("EMS_DOCUMENT", "EXPORT_IND", "=", "R");
      hQuery.setBasicPredicate("EMS_DOCUMENT", "DELETE_FLG", "=", "N");
      auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
      if(pSelectStatement->getRows())
      {
         hQuery.reset();
         hQuery.attach(this);
         hQuery.bind("EMS_PHASE_VNT_VROL", "QUESTION_FIELDS",Column::STRING,&m_strQUESTION_FIELDS);
         hQuery.setBasicPredicate("EMS_PHASE_VNT_VROL", "CASE_ID", "=", CaseSegment::instance()->getCASE_ID());
         hQuery.setBasicPredicate("EMS_PHASE_VNT_VROL", "DOC_SEQ_NO", "=", siDOC_SEQ_NO);
         if (!pSelectStatement->execute(hQuery))
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
         }
         hQuery.reset();
         hQuery.setBasicPredicate("EMS_PHASE_VNT_VROL", "CASE_ID", "=", CaseSegment::instance()->getCASE_ID());
         hQuery.setBasicPredicate("EMS_PHASE_VNT_VROL", "DOC_SEQ_NO", "=", siDOC_SEQ_NO);
         auto_ptr<reusable::SelectStatement> pDeleteStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("DeleteStatement"));
         if (!pDeleteStatement->execute(hQuery))
         {
            Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            m_iResultCode = STS_QUERY_ERROR;
            return false;  
         }
         hQuery.reset();
         hQuery.setBasicPredicate("EMS_DOCUMENT","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
         hQuery.setBasicPredicate("EMS_DOCUMENT","SEQ_NO","=",siDOC_SEQ_NO);
         if (!pDeleteStatement->execute(hQuery))
         {
            Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            m_iResultCode = STS_QUERY_ERROR;
            return false;              
         }          
      }               
   }
   return true;
  //## end emscommand::CaseUpdateCommand::deleteNonExportedQuestionnaire%4DB704A5006C.body
}

bool CaseUpdateCommand::deleteSmartForm ()
{
  //## begin emscommand::CaseUpdateCommand::deleteSmartForm%5CFF47080164.body preserve=yes
   short siDOC_SEQ_NO = 0;
   Query hQuery;
   hQuery.bind("EMS_DOCUMENT", "SEQ_NO", Column::SHORT, &siDOC_SEQ_NO);
   hQuery.setBasicPredicate("EMS_DOCUMENT", "CASE_ID", "=", CaseSegment::instance()->getCASE_ID());
   hQuery.setBasicPredicate("EMS_DOCUMENT", "DOC_TYPE", "=", "SMART_FORM");
   hQuery.setBasicPredicate("EMS_DOCUMENT", "EXPORT_IND", "=", "X"); // Needed ?
   hQuery.setBasicPredicate("EMS_DOCUMENT", "DELETE_FLG", "=", "N");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
   {
      m_iResultCode = STS_QUERY_ERROR;
      m_lInfoIDNumber = STS_DATABASE_FAILURE;
      return false;
   }
   if (pSelectStatement->getRows())
   {
      hQuery.reset();
      hQuery.attach(this);
      hQuery.bind("EMS_SMARTFORM", "QUESTION_FIELDS", Column::STRING, &m_strQUESTION_FIELDS);
      hQuery.setBasicPredicate("EMS_SMARTFORM", "CASE_ID", "=", CaseSegment::instance()->getCASE_ID());
      hQuery.setBasicPredicate("EMS_SMARTFORM", "DOC_SEQ_NO", "=", siDOC_SEQ_NO);
      if (!pSelectStatement->execute(hQuery))
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
      hQuery.reset();
      hQuery.setBasicPredicate("EMS_SMARTFORM", "CASE_ID", "=", CaseSegment::instance()->getCASE_ID());
      hQuery.setBasicPredicate("EMS_SMARTFORM", "DOC_SEQ_NO", "=", siDOC_SEQ_NO);
      auto_ptr<reusable::SelectStatement> pDeleteStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("DeleteStatement"));
      if (!pDeleteStatement->execute(hQuery))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         m_iResultCode = STS_QUERY_ERROR;
         return false;
      }
      hQuery.reset();
      hQuery.setBasicPredicate("EMS_DOCUMENT", "CASE_ID", "=", CaseSegment::instance()->getCASE_ID());
      hQuery.setBasicPredicate("EMS_DOCUMENT", "SEQ_NO", "=", siDOC_SEQ_NO);
      if (!pDeleteStatement->execute(hQuery))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         m_iResultCode = STS_QUERY_ERROR;
         return false;
      }
   }
   return true;
  //## end emscommand::CaseUpdateCommand::deleteSmartForm%5CFF47080164.body
}

bool CaseUpdateCommand::execute ()
{
  //## begin emscommand::CaseUpdateCommand::execute%35ACB45F02E2.body preserve=yes
   CaseSegment* pCaseSegment = CaseSegment::instance();
   string strACQ_USER_ID("");
   string strOTHER_CASE_NO("");
   string strOTHER_CUST_ID("");
   string strCaseSource(pCaseSegment->getCaseSource());

   string strCaseCASE_ID;
   string strCaseCASE_NO;
   string strACQ_CASE_NO;
   string strACQ_CUST_ID;
   string strISS_CASE_NO;
   string strISS_CUST_ID;
   string strCaseNET_RULES;
   string strCaseNET_ID_EMS;
   string strCaseREQUEST_TYPE;
   string strCaseSTATUS;
   string strCaseSTATE_TSTAMP;
   string strCaseCASE_EXTENSION;
   string strCaseTSTAMP_UPDATED;
   string strPhaseREQUEST_TYPE;
   string strPhaseREASON_CODE;
   string strPhaseTSTAMP_CREATED;
   string strPhaseUSER_ROLE;
   string strPhaseREQ_CONTACT_NAME;
   string strPhaseREQ_CONTACT_PHONE;
   string strPhaseREQ_CONTACT_FAX;
   string strCaseBUSINESS_CALENDAR;
	string strCaseDATE_NOTIFY;
   {
   Query hQuery;
   hQuery.join("EMS_CASE","INNER","EMS_TRANSITION","CASE_ID");
   hQuery.join("EMS_CASE","INNER","EMS_TRANSITION","STATE_TSTAMP","TSTAMP_CREATED");
   hQuery.join("EMS_TRANSITION","INNER","EMS_PHASE","CASE_ID");
   hQuery.join("EMS_TRANSITION","INNER","EMS_PHASE","PHASE_TSTAMP","TSTAMP_CREATED");
   hQuery.bind("EMS_CASE","BUSINESS_CALENDAR",Column::STRING,&strCaseBUSINESS_CALENDAR);
	hQuery.bind("EMS_CASE", "DATE_NOTIFY",Column::STRING, &strCaseDATE_NOTIFY);
   hQuery.bind("EMS_PHASE","REQUEST_TYPE",Column::STRING,&strPhaseREQUEST_TYPE);
   hQuery.bind("EMS_PHASE","REASON_CODE",Column::STRING,&strPhaseREASON_CODE);
   hQuery.bind("EMS_PHASE","TSTAMP_CREATED",Column::STRING,&strPhaseTSTAMP_CREATED);
   hQuery.bind("EMS_PHASE","USER_ROLE",Column::STRING,&strPhaseUSER_ROLE);
   hQuery.bind("EMS_PHASE","REQ_CONTACT_NAME",Column::STRING,&strPhaseREQ_CONTACT_NAME);
   hQuery.bind("EMS_PHASE","REQ_CONTACT_PHONE",Column::STRING,&strPhaseREQ_CONTACT_PHONE);
   hQuery.bind("EMS_PHASE","REQ_CONTACT_FAX",Column::STRING,&strPhaseREQ_CONTACT_FAX);
   if(pCaseSegment->getOTHER_CUST_ID() == "XPRT") // c2c import
   {
      strACQ_USER_ID = CaseSegment::instance()->getACQ_USER_ID();
      strOTHER_CUST_ID = CaseSegment::instance()->getOTHER_CUST_ID();
      // if USPS does a create and then an update in the same day, we need to get the
      // FISB case that was created by searching on FISB's OTHER_CASE_NO since we
      // don't have FISB's CASE_NO in the update message coming into us.
      if (CaseSegment::instance()->getCASE_NO().length())
      {
         strOTHER_CASE_NO = CaseSegment::instance()->getOTHER_CASE_NO();
         pCaseSegment->bind(hQuery);
         hQuery.setBasicPredicate("EMS_CASE","CASE_NO","=",pCaseSegment->getCASE_NO().c_str());
      }
      else
      {
         strOTHER_CASE_NO = CaseSegment::instance()->getOTHER_CASE_NO();
         pCaseSegment->bind(hQuery);
         hQuery.setBasicPredicate("EMS_CASE","OTHER_CASE_NO","=",pCaseSegment->getOTHER_CASE_NO().c_str());
         hQuery.setBasicPredicate("EMS_CASE","OTHER_CUST_ID","=","IPRT");
      }
   }
   else
   {
      hQuery.bind("EMS_CASE","CASE_ID",Column::STRING,&strCaseCASE_ID);
      hQuery.bind("EMS_CASE","CASE_NO",Column::STRING,&strCaseCASE_NO);
      hQuery.bind("EMS_CASE","NET_RULES",Column::STRING,&strCaseNET_RULES);
      hQuery.bind("EMS_CASE","NET_ID_EMS",Column::STRING,&strCaseNET_ID_EMS);
      hQuery.bind("EMS_CASE","REQUEST_TYPE",Column::STRING,&strCaseREQUEST_TYPE);
      hQuery.bind("EMS_CASE","STATUS",Column::STRING,&strCaseSTATUS);
      hQuery.bind("EMS_CASE","STATE_TSTAMP",Column::STRING,&strCaseSTATE_TSTAMP);
      hQuery.bind("EMS_CASE","CASE_EXTENSION",Column::STRING,&strCaseCASE_EXTENSION);
      hQuery.bind("EMS_CASE","TSTAMP_UPDATED",Column::STRING,&strCaseTSTAMP_UPDATED);
      hQuery.setBasicPredicate("EMS_CASE","CASE_ID","=",pCaseSegment->getCASE_ID());
   }

   auto_ptr<SelectStatement>pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
   {
      m_iResultCode = STS_QUERY_ERROR;
      m_lInfoIDNumber = STS_DATABASE_FAILURE;
      return false;
   }
   if(pSelectStatement->getRows() == 0)
   {
      m_lInfoIDNumber = STS_ACTION_FAILED_RECORD_MODIFIED;
      return false;
   }
   }
   if (CaseSegment::instance()->getDATE_NOTIFY() != strCaseDATE_NOTIFY && !CaseSegment::instance()->getDATE_NOTIFY().empty() && CaseSegment::instance()->getDATE_NOTIFY().length() > 7)
   {
       Case::instance()->setRegEDates();
   }
   if(strOTHER_CUST_ID == "XPRT") // c2c import
   {
      pCaseSegment->setACQ_USER_ID(strACQ_USER_ID);
      pCaseSegment->setOTHER_CUST_ID(strOTHER_CUST_ID);
      pCaseSegment->setOTHER_CASE_NO(strOTHER_CASE_NO);
      pCaseSegment->setCaseSource(strCaseSource);
      CasePhaseSegment::instance()->setTSTAMP_CREATED(strPhaseTSTAMP_CREATED);
   }
   else
   {
      if (CaseSegment::instance()->getTSTAMP_UPDATED() != strCaseTSTAMP_UPDATED)
      {
         m_lInfoIDNumber = STS_ACTION_FAILED_RECORD_MODIFIED;
         m_iResultCode = STS_QUERY_ERROR;
         return false;
      }
   }
   if ((pCaseSegment->getTSTAMP_TRANS().length() == 0 && 
        CaseTransitionSegment::instance()->getUSER_ID() != "SYSTEM" ) ||
       (pCaseSegment->getCaseSource() == "I" && strCaseSTATUS == "HOLD"))
   {
      Trace::put("Update rechain required");
      if ((m_lInfoIDNumber = Case::instance()->rechain()) != 0)
         return false;
      m_lInfoIDNumber = Case::instance()->mapInst();
      if (m_lInfoIDNumber != 0)
         return false;
      if (CaseSegment::instance()->getCaseSource() == "W" &&        
         CaseSegment::instance()->getOTHER_CUST_ID() != "XPRT")
      {
         int iReturn = ExceptionSecurity::secureUserForCase();
         if (iReturn == 0)
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
         }
         else if (iReturn == -1)
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_ACCESS_TO_DATA_DENIED;
            return false;
         }
      }
   }
   if(strOTHER_CUST_ID != "XPRT") // c2c import
   {
      // disallow changes to certain fields
      pCaseSegment->setNET_RULES(strCaseNET_RULES);
      pCaseSegment->setNET_ID_EMS(strCaseNET_ID_EMS);
      pCaseSegment->setREQUEST_TYPE(strCaseREQUEST_TYPE);
      pCaseSegment->setSTATUS(strCaseSTATUS);
      pCaseSegment->setSTATE_TSTAMP(strCaseSTATE_TSTAMP);
      pCaseSegment->setCASE_EXTENSION(strCaseCASE_EXTENSION);
   }
   CasePhaseSegment::instance()->setREQUEST_TYPE(strPhaseREQUEST_TYPE);
   m_bRCChanged = strPhaseREASON_CODE == CasePhaseSegment::instance()->getREASON_CODE();
   if (strCaseSTATUS == "FWRD"
      && (CaseSegment::instance()->getUSER_ROLE() != "*"
         && CaseSegment::instance()->getUSER_ROLE() != strPhaseUSER_ROLE))
   {
      CasePhaseSegment::instance()->setUSER_ROLE(strPhaseUSER_ROLE);
      CasePhaseSegment::instance()->setREQ_CONTACT_FAX(strPhaseREQ_CONTACT_FAX);
      CasePhaseSegment::instance()->setREQ_CONTACT_NAME(strPhaseREQ_CONTACT_NAME);
      CasePhaseSegment::instance()->setREQ_CONTACT_PHONE(strPhaseREQ_CONTACT_PHONE);
   }

   //Four lists come in, determine which one is a list of Documents,
   //Comments and Reason Codes
   m_lInfoIDNumber = 0;
   for(int i = 0; i < 4; i++)
    {
        if(!m_pListSegment[i]->presence())
            break;
       char* p = (char*)*m_pListSegment[i];
        if (!memcmp(p,(const char*)"S273",4))
            m_lInfoIDNumber = Case::instance()->verifyReasonCodeList(m_pListSegment[i]);
        if (m_lInfoIDNumber != 0)
        {
            m_iResultCode = STS_QUERY_ERROR;
            return false;
        }
    }

   string strREQUEST_TYPE;
   string strSTATUS;
   if (CaseTransitionSegment::instance()->presence())
   {
      strREQUEST_TYPE = CaseTransitionSegment::instance()->getREQUEST_TYPE_NEXT();
      strSTATUS = CaseTransitionSegment::instance()->getSTATUS_PREV();
   }
   else
   {
      strREQUEST_TYPE = CaseSegment::instance()->getREQUEST_TYPE();
      strSTATUS = CaseSegment::instance()->getSTATUS();
   }
            
   if ((CaseSegment::instance()->getNET_ID_EMS() == "MCI" || CaseSegment::instance()->getCASE_EXTENSION() == "VNT")
      && ((strREQUEST_TYPE.substr(0,3) == "ADJ" || strREQUEST_TYPE == "REP1"||
      strREQUEST_TYPE == "CHB1" || strREQUEST_TYPE == "CHB2") 
      && (CaseSegment::instance()->getMERCHANT_CAT_CODE() == "6011" 
      || (CaseSegment::instance()->getMERCHANT_CAT_CODE() != "6011" && strSTATUS != "REJR"))))
      calculateSurcharge();

   CaseSegment::instance()->setBUSINESS_CALENDAR(strCaseBUSINESS_CALENDAR);
//   string strCriticalSection(Extract::instance()->getName().c_str(), 2);
//   strCriticalSection.append("EMS", 3);
//   CriticalSection hCriticalSection(strCriticalSection.c_str());
   if (!updateCase(true))
      return false;

   if((CaseTransitionSegment::instance()->getSTATUS_PREV().substr(0,2) == "CL" &&
       CaseTransitionSegment::instance()->getSTATUS_NEXT().substr(0,2) != "CL") ||
       CaseTransitionSegment::instance()->getSTATUS_NEXT() == "REOP")
   {
      int iRows = 0;
      Query hQuery;
      string strUSER_ID;
      {
         hQuery.bind("EMS_ASSIGNMENT", "USER_ID", Column::STRING, &strUSER_ID);
         hQuery.setBasicPredicate("EMS_ASSIGNMENT", "CASE_ID", "=", CaseSegment::instance()->getCASE_ID());
         auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
         if (pSelectStatement->execute(hQuery))
            iRows = pSelectStatement->getRows();
         else
         {
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            m_iResultCode = STS_QUERY_ERROR;
            return false;
         }
      }
      if(iRows > 0)
      {
         if(CaseAssignmentUsers::instance()->load() &&
            !CaseAssignmentUsers::instance()->isUserInRotation(strUSER_ID))
         {
            string strNextUser(CaseAssignmentUsers::instance()->nextUserInRotation());
            vector<string>::iterator pItUsers = find(CaseAssignmentUsers::instance()->getUsers().begin(), CaseAssignmentUsers::instance()->getUsers().end(), strNextUser);
            int iCount = 0;
            while (!checkUserAccess(*pItUsers))
            {
               if (++iCount >= CaseAssignmentUsers::instance()->getUsers().size())
                  break;
               if (pItUsers == CaseAssignmentUsers::instance()->getUsers().end())
                  pItUsers = CaseAssignmentUsers::instance()->getUsers().begin();
               else
               {
                  pItUsers++;
                  if (pItUsers == CaseAssignmentUsers::instance()->getUsers().end())
                     pItUsers = CaseAssignmentUsers::instance()->getUsers().begin();
               }
            }
            strNextUser.assign(*pItUsers);
            if (iCount >= CaseAssignmentUsers::instance()->getUsers().size())
               strNextUser.erase();
            Table hTable("EMS_ASSIGNMENT");
            hTable.setAudit(true);
            hTable.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
            hTable.set("USER_ID",strNextUser);
            auto_ptr<reusable::Statement> pUpdateStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("UpdateStatement"));
            if(!pUpdateStatement->execute(hTable))
            {
               m_iResultCode = STS_QUERY_ERROR;
               m_lInfoIDNumber = STS_DATABASE_FAILURE;
               return false;
            }
            Table hEMSCaseDataChg("EMS_DATA_CHG");
            auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
            ems::CaseAddEventVisitor hCaseAddEventVisitor(&hEMSCaseDataChg,pInsertStatement.get());
            hEMSCaseDataChg.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
            hEMSCaseDataChg.set("USER_ID","SYSTEM");
            hEMSCaseDataChg.set("TSTAMP_CREATED",reusable::Transaction::instance()->getTimeStamp());
            hTable.accept(hCaseAddEventVisitor);
            if(!hCaseAddEventVisitor.successful())
            {
               m_lInfoIDNumber = STS_DATABASE_FAILURE;
               m_iResultCode = STS_QUERY_ERROR;
               return false;
            }
            Context hContext(Application::instance()->image(),Application::instance()->name());
            if(!hContext.put("LAST ASSIGNED USER ID",strNextUser.c_str()))
            {
               m_lInfoIDNumber = STS_DATABASE_FAILURE;
               m_iResultCode = STS_QUERY_ERROR;
               return false;
            }
         }
      }
   }
   
   if ((pCaseSegment->getACQ_CUST_ID().length() > 0) &&
       (pCaseSegment->getACQ_CASE_NO().length() > 0))
   {
      Trace::put("Looking for cust id: ");
      Trace::put(pCaseSegment->getACQ_CUST_ID().c_str());
      if (Case::instance()->setQualifierFromNetwork(pCaseSegment->getACQ_CUST_ID()))
      {
         CaseSegment hCaseSegment(*CaseSegment::instance());
         Transaction::instance()->setCustomer(pCaseSegment->getACQ_CUST_ID());
         Trace::put("Found Qualifier: ");
         Trace::put(Transaction::instance()->getQualifier().c_str());
         string strPRIORITY(pCaseSegment->getPRIORITY());
         string strINSTITUTION_NAME(pCaseSegment->getINSTITUTION_NAME());
         string strUSER_ROLE(pCaseSegment->getUSER_ROLE());
         {
         Query hQuery;
         hQuery.setBasicPredicate("EMS_CASE","CASE_NO","=",pCaseSegment->getACQ_CASE_NO().c_str());
         pCaseSegment->bind(hQuery);
         auto_ptr<SelectStatement>pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));   
         if ((pSelectStatement->execute(hQuery) == false) ||
             (pSelectStatement->getRows() == 0))
         {
            Trace::put("Fail 2nd case select.",-1,true);
            Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            m_iResultCode = STS_QUERY_ERROR;
            Case::instance()->setQualifierFromNetwork(m_strCUST_ID);
            return false;
         }
         }
         pCaseSegment->setCaseSource(strCaseSource);
         pCaseSegment->setUSER_ROLE(strUSER_ROLE);
         pCaseSegment->setPRIORITY(strPRIORITY);
         pCaseSegment->setINSTITUTION_NAME(strINSTITUTION_NAME);
         bool bSuccess = updateCase(false);
         string strCASE_NO;
         string strCUST_ID;
         if (bSuccess)
            replicateOtherCase();
         if (bSuccess
            && pCaseSegment->getACQ_CUST_ID().length() > 0
            && pCaseSegment->getACQ_CASE_NO().length() > 0
            && Case::instance()->setQualifierFromNetwork(pCaseSegment->getACQ_CUST_ID()) == true)
         {
            Transaction::instance()->setCustomer(pCaseSegment->getACQ_CUST_ID());
            Trace::put("Found Qualifier: ");
            Trace::put(Transaction::instance()->getQualifier().c_str());
            {
            Query hQuery;
            hQuery.setBasicPredicate("EMS_CASE","CASE_NO","=",pCaseSegment->getACQ_CASE_NO().c_str());
            pCaseSegment->bind(hQuery);
            auto_ptr<SelectStatement>pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));   
            if ((pSelectStatement->execute(hQuery) == false) ||
               (pSelectStatement->getRows() == 0))
            {
               Trace::put("Fail 2nd case select.",-1,true);
               Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
               m_lInfoIDNumber = STS_DATABASE_FAILURE;
               m_iResultCode = STS_QUERY_ERROR;
               Case::instance()->setQualifierFromNetwork(m_strCUST_ID);
               return false;
            }
            }
            pCaseSegment->setCaseSource(strCaseSource);
            bool bSuccess = updateCase(false);
            if (bSuccess)
               replicateOtherCase();
         }
         *CaseSegment::instance() = hCaseSegment;
         Transaction::instance()->setCustomer(m_strCUST_ID);
         Transaction::instance()->setQualifier("CUSTQUAL");
         Case::instance()->setCustAbbr();
         if (!bSuccess)
         {
            Trace::put("Failed 2nd update.",-1,true);
            return false;
         }
      }
      else
      {
         Trace::put("Qualifier not found",-1,true);
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         m_iResultCode = STS_QUERY_ERROR;
         Transaction::instance()->setCustomer(m_strCUST_ID);
         Transaction::instance()->setQualifier("CUSTQUAL");
         Case::instance()->setCustAbbr();
         return false;
      }
   }
   if ((pCaseSegment->getISS_CUST_ID().length() > 0) &&
       (pCaseSegment->getISS_CASE_NO().length() > 0))
   {
      Trace::put("Looking for cust id: ");
      Trace::put(pCaseSegment->getISS_CUST_ID().c_str());
      if (Case::instance()->setQualifierFromNetwork(pCaseSegment->getISS_CUST_ID()))
      {
         CaseSegment hCaseSegment(*CaseSegment::instance());
         Transaction::instance()->setCustomer(pCaseSegment->getISS_CUST_ID());
         Trace::put("Found Qualifier: ");
         Trace::put(Transaction::instance()->getQualifier().c_str());
         string strPRIORITY(pCaseSegment->getPRIORITY());
         string strINSTITUTION_NAME(pCaseSegment->getINSTITUTION_NAME());
         string strUSER_ROLE(pCaseSegment->getUSER_ROLE());
         {
         Query hQuery;
         hQuery.setBasicPredicate("EMS_CASE","CASE_NO","=",pCaseSegment->getISS_CASE_NO().c_str());
         pCaseSegment->bind(hQuery);
         auto_ptr<SelectStatement>pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));   
         if ((pSelectStatement->execute(hQuery) == false) ||
             (pSelectStatement->getRows() == 0))
         {
            Trace::put("Fail 2nd case select.",-1,true);
            Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            m_iResultCode = STS_QUERY_ERROR;
            Case::instance()->setQualifierFromNetwork(m_strCUST_ID);
            return false;
         }
         }
         pCaseSegment->setCaseSource(strCaseSource);
         pCaseSegment->setUSER_ROLE(strUSER_ROLE);
         pCaseSegment->setPRIORITY(strPRIORITY);
         pCaseSegment->setINSTITUTION_NAME(strINSTITUTION_NAME);
         bool bSuccess = updateCase(false);
         if (bSuccess)
            replicateOtherCase();
         if (bSuccess
            && pCaseSegment->getISS_CUST_ID().length() > 0
            && pCaseSegment->getISS_CASE_NO().length() > 0
            && Case::instance()->setQualifierFromNetwork(pCaseSegment->getISS_CUST_ID())== true)
         {
            Transaction::instance()->setCustomer(pCaseSegment->getISS_CUST_ID());
            Trace::put("Found Qualifier: ");
            Trace::put(Transaction::instance()->getQualifier().c_str());
            string strPRIORITY(pCaseSegment->getPRIORITY());
            string strINSTITUTION_NAME(pCaseSegment->getINSTITUTION_NAME());
            string strUSER_ROLE(pCaseSegment->getUSER_ROLE());
            {
            Query hQuery;
            hQuery.setBasicPredicate("EMS_CASE","CASE_NO","=",pCaseSegment->getISS_CASE_NO().c_str());
            pCaseSegment->bind(hQuery);
            auto_ptr<SelectStatement>pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));   
            if ((pSelectStatement->execute(hQuery) == false) ||
               (pSelectStatement->getRows() == 0))
            {
               Trace::put("Fail 2nd case select.",-1,true);
               Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
               m_lInfoIDNumber = STS_DATABASE_FAILURE;
               m_iResultCode = STS_QUERY_ERROR;
               Case::instance()->setQualifierFromNetwork(m_strCUST_ID);
               return false;
            }
            }
            pCaseSegment->setCaseSource(strCaseSource);
            bool bSuccess = updateCase(false);
            if (bSuccess)
               replicateOtherCase();
         }
         *CaseSegment::instance() = hCaseSegment;
         Transaction::instance()->setCustomer(m_strCUST_ID);
         Transaction::instance()->setQualifier("CUSTQUAL");
         Case::instance()->setCustAbbr();
         if (!bSuccess)
         {
            Trace::put("Failed 2nd update.",-1,true);
            return false;
         }
      }
      else
      {
         Trace::put("Qualifier not found",-1,true);
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         m_iResultCode = STS_QUERY_ERROR;
         Transaction::instance()->setCustomer(m_strCUST_ID);
         Transaction::instance()->setQualifier("CUSTQUAL");
         Case::instance()->setCustAbbr();
         return false;
      }
   }
   if (!Case::instance()->getAdditionalTransitionData().empty())
   {
      if (CaseSegment::instance()->getCOMPLIANCE_IND() == "Y")
      {
         Database::instance()->commit();
         reusable::Transaction::instance()->begin();
         reusable::Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
         CBACompliance hCBACompliance;
         if (!hCBACompliance.execute(CaseSegment::instance()->getCASE_ID()))
            return false;
      }
      else
      {
         if (Case::instance()->processAdditionalTransition(m_lInfoIDNumber,m_iResultCode) == false)
            return false;
      }
   }
   size_t pos = CaseTransitionSegment::instance()->getACTION().find("EMAIL");
   if (pos == string::npos)
   {
      if (CaseCommentSegment::instance()->getEMAIL_STATUS() != "R")
      {
         Query hQuery;
         CaseCommentSegment::instance()->reset();
         CaseCommentSegment::instance()->bind(hQuery);
         hQuery.setBasicPredicate("EMS_COMMENT","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
         hQuery.setBasicPredicate("EMS_COMMENT","EMAIL_STATUS","=","R");
         hQuery.setOrderByClause
         ("EMS_COMMENT.TSTAMP_CREATED ASC,EMS_COMMENT.SEQ_NO DESC");
         auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
         pSelectStatement->execute(hQuery);
      }

      CaseNotification hCaseNotification;
      hCaseNotification.setCaseUpdateMailFlg(true);
      m_lInfoIDNumber = hCaseNotification.execute("01");
   }
   if(!EMailMessage::sendAll() && CaseTransitionSegment::instance()->getUSER_ID() != "SYSTEM")
   {
      m_lInfoIDNumber = STS_SMTP_OPEN_FAILURE;
      Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
      return false;
   }
   if (strPhaseREQUEST_TYPE != CasePhaseSegment::instance()->getREQUEST_TYPE())
   {
      int i = CasePhaseSegment::instance()->totals();
      if (i!=0)
      {
         m_lInfoIDNumber=i;
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         return false;
      }
   }
   Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   return true;
  //## end emscommand::CaseUpdateCommand::execute%35ACB45F02E2.body
}

bool CaseUpdateCommand::insertDocExtensionSegment (const string &strQUESTION_FIELDS)
{
  //## begin emscommand::CaseUpdateCommand::insertDocExtensionSegment%5E7B0B08015A.body preserve=yes
   Table hTable;
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   int iQuestionLength = 0;
   iQuestionLength = strQUESTION_FIELDS.length();
   short siStart = 0;
   short siSEQ_NO = 1;
   while (siStart < iQuestionLength)
   {
      int iMaxRecord = 3800;
      if (siStart + 3800  < iQuestionLength)
      while (strQUESTION_FIELDS[siStart + iMaxRecord - 1] == ' ')
         iMaxRecord--;
      CaseDocumentExtensionSegment::instance()->setCASE_ID(CaseSegment::instance()->getCASE_ID());
      CaseDocumentExtensionSegment::instance()->setSEQ_NO(siSEQ_NO++);
      CaseDocumentExtensionSegment::instance()->setDOC_SEQ_NO(CaseDocumentSegment::instance()->getSEQ_NO());
      CaseDocumentExtensionSegment::instance()->setDATA_BUFFER(strQUESTION_FIELDS.substr(siStart,iMaxRecord));
      CaseDocumentExtensionSegment::instance()->setColumns(hTable);
      if (!pInsertStatement->execute(hTable))
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
      siStart += iMaxRecord;
      hTable.reset();
   }
   return true;
  //## end emscommand::CaseUpdateCommand::insertDocExtensionSegment%5E7B0B08015A.body
}

bool CaseUpdateCommand::insertSmartFormSegment (const string &strQUESTION_FIELDS)
{
  //## begin emscommand::CaseUpdateCommand::insertSmartFormSegment%5CFE5A8B0370.body preserve=yes
   Table hTable;
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   int iQuestionLength = 0;
   iQuestionLength = strQUESTION_FIELDS.length();
   short siStart = 0;
   short siSEQ_NO = 1;
   while (siStart < iQuestionLength)
   {
      int iMaxRecord = MAXRECORD;
      if (siStart + MAXRECORD  < iQuestionLength)
      while (strQUESTION_FIELDS[siStart + iMaxRecord - 1] == ' ')
         iMaxRecord--;
      CaseSmartFormSegment::instance()->setCASE_ID(CaseSegment::instance()->getCASE_ID());
      CaseSmartFormSegment::instance()->setSEQ_NO(siSEQ_NO++);
      CaseSmartFormSegment::instance()->setDOC_SEQ_NO(CaseDocumentSegment::instance()->getSEQ_NO());
      CaseSmartFormSegment::instance()->setQUESTION_FIELDS(strQUESTION_FIELDS.substr(siStart, iMaxRecord));
      CaseSmartFormSegment::instance()->setColumns(hTable);
      if (!pInsertStatement->execute(hTable))
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
      siStart += iMaxRecord;
      hTable.reset();
   }
   return true;
  //## end emscommand::CaseUpdateCommand::insertSmartFormSegment%5CFE5A8B0370.body
}

bool CaseUpdateCommand::insertVROLSegment (string strQUESTION_FIELDS)
{
  //## begin emscommand::CaseUpdateCommand::insertVROLSegment%47173B460040.body preserve=yes
   Table hTable;
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   int iQuestionLength = 0;
   iQuestionLength = strQUESTION_FIELDS.length();
   int siStart = 0;
   int siSEQ_NO = 1;

   while(siStart < iQuestionLength)
   {
      int iMaxRecord = MAXRECORD;
      if (siStart + MAXRECORD  < iQuestionLength)
         while ( strQUESTION_FIELDS[siStart+iMaxRecord-1] == ' ')
            iMaxRecord--;
      CasePhaseVisaVROLSegment::instance()->setSEQ_NO(siSEQ_NO++);
      CasePhaseVisaVROLSegment::instance()->setDOC_SEQ_NO(CaseDocumentSegment::instance()->getSEQ_NO());
      CasePhaseVisaVROLSegment::instance()->setQUESTION_FIELDS(strQUESTION_FIELDS.substr(siStart,iMaxRecord));
      CasePhaseVisaVROLSegment::instance()->setColumns(hTable);
      if(!pInsertStatement->execute(hTable))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);         
         m_iResultCode = STS_QUERY_ERROR;  
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         UseCase::setSuccess(false);
         return false;
      }
      siStart += iMaxRecord;
      hTable.reset();
   }
   CaseDocumentSegment::instance()->setDOC_PATH(strQUESTION_FIELDS);
   CasePhaseVisaVROLSegment::instance()->setQUESTION_FIELDS(strQUESTION_FIELDS);
   return true;
  //## end emscommand::CaseUpdateCommand::insertVROLSegment%47173B460040.body
}

CaseUpdateCommand* CaseUpdateCommand::instance ()
{
  //## begin emscommand::CaseUpdateCommand::instance%40A26CF801A5.body preserve=yes
   if (!m_pInstance)
      new CaseUpdateCommand();
   return m_pInstance;
  //## end emscommand::CaseUpdateCommand::instance%40A26CF801A5.body
}

int CaseUpdateCommand::parse ()
{
  //## begin emscommand::CaseUpdateCommand::parse%375E7B6200CB.body preserve=yes
   int iRC;
   if ((iRC = Command::parse()) != 0)
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,iRC);
      return -1;
   }
   if (!CommonHeaderSegment::instance()->presence())
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_COMMON_HEADER_SEGMENT);
      return -1;
   }
   if (!CaseSegment::instance()->presence())
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_CASE_SEGMENT);
      return -1;
   }
   return 0;
  //## end emscommand::CaseUpdateCommand::parse%375E7B6200CB.body
}

bool CaseUpdateCommand::processBatchDocumentList (int iListNumber)
{
  //## begin emscommand::CaseUpdateCommand::processBatchDocumentList%4F171B2601C4.body preserve=yes
   char* p = (char*)*m_pListSegment[iListNumber]; 
   for (int j = 0;j < m_pListSegment[iListNumber]->itemCount();++j)
   {
      CaseDocumentSegment::instance()->reset();
      m_lInfoIDNumber = CaseDocumentSegment::instance()->import(&p);
      if (m_lInfoIDNumber != 0)
         return false;
      if (CaseDocumentSegment::instance()->getEXPORT_IND() == "S")
         continue;
      if(updateDocumentSegment() == false)
         return false;   
   }
   return true;
  //## end emscommand::CaseUpdateCommand::processBatchDocumentList%4F171B2601C4.body
}

bool CaseUpdateCommand::processDocumentSegmentList (int iListNumber, bool bFirstPass)
{
  //## begin emscommand::CaseUpdateCommand::processDocumentSegmentList%4E0251D6025B.body preserve=yes
   Query hQuery;
   string strDELETE_FLG;
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   Table hTable("EMS_DOCUMENT");
   char* p = (char*)*m_pListSegment[iListNumber];
   if (bFirstPass)
   {
      for (int j = 1; j <= m_pListSegment[iListNumber]->itemCount(); j++)
      {
         CaseDocumentSegment::instance()->reset();
         m_lInfoIDNumber = CaseDocumentSegment::instance()->import(&p);
         if (CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_PARB_"
            || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,8) == "REQ_ARB_"
            || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_PCMP_"
            || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_COMP_"
            || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_PRSP_"
            || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_CRSP_"
            || CaseDocumentSegment::instance()->getDOC_TYPE() == "REQ_CBRS")
            m_bDocExt = true;
         else
         if (CaseDocumentSegment::instance()->getDOC_TYPE() == "SMART_FORM")
            m_bSmartForm = true;
         if (m_lInfoIDNumber != 0)
            return false;
         hQuery.reset();
         hQuery.bind("EMS_DOCUMENT", "DELETE_FLG", Column::STRING, &strDELETE_FLG);
         hQuery.setBasicPredicate("EMS_DOCUMENT", "CASE_ID", "=", CaseSegment::instance()->getCASE_ID());
         hQuery.setBasicPredicate("EMS_DOCUMENT", "SEQ_NO", "=", CaseDocumentSegment::instance()->getSEQ_NO());
         auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
         if (!pSelectStatement->execute(hQuery))
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
         }
         //docs coming in the import will not be present in the db
         if (pSelectStatement->getRows() > 0  
            && CaseDocumentSegment::instance()->getDELETE_FLG() != strDELETE_FLG)
         {
            hTable.setAudit(true);
            hTable.set("CASE_ID", CaseSegment::instance()->getCASE_ID(), true);
            hTable.set("SEQ_NO", CaseDocumentSegment::instance()->getSEQ_NO(), true);
            hTable.set("DELETE_FLG", CaseDocumentSegment::instance()->getDELETE_FLG());
            if (pUpdateStatement->execute(hTable) == false)
            {
               Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
               m_lInfoIDNumber = STS_DATABASE_FAILURE;
               m_iResultCode = STS_QUERY_ERROR;
               return false;
            }

            Table hEMSCaseDataChg("EMS_DATA_CHG");
            auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
            ems::CaseAddEventVisitor hCaseAddEventVisitor(&hEMSCaseDataChg, pInsertStatement.get());
            hEMSCaseDataChg.set("CASE_ID", CaseSegment::instance()->getCASE_ID(), true);
            hEMSCaseDataChg.set("USER_ID", CommonHeaderSegment::instance()->getUserID());
            hEMSCaseDataChg.set("TSTAMP_CREATED", reusable::Transaction::instance()->getTimeStamp());
            hTable.accept(hCaseAddEventVisitor);
            if (!hCaseAddEventVisitor.successful())
            {
               Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
               m_lInfoIDNumber = STS_DATABASE_FAILURE;
               m_iResultCode = STS_QUERY_ERROR;
               return false;
            }
         }
      }
   }
   if (deleteNonExportedQuestionnaire() == false)
      return false;
   if (m_bSmartForm && !deleteSmartForm())
      return false;
   if (m_bDocExt && !deleteDocExtension())
      return false;
   p = (char*)*m_pListSegment[iListNumber];
   for (int j = 1; j <= m_pListSegment[iListNumber]->itemCount(); j++)
   {
      CaseDocumentSegment::instance()->reset();
      m_lInfoIDNumber = CaseDocumentSegment::instance()->import(&p);
      if (m_lInfoIDNumber != 0)
         return false;
      if (CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 3) != "QTN"
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 3) != "DCF"
         && CaseDocumentSegment::instance()->getDOC_TYPE() != "SMART_FORM"
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_PARB_"
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,8) != "REQ_ARB_"
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_PCMP_"
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_COMP_"
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_PRSP_"
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_CRSP_"
         && CaseDocumentSegment::instance()->getDOC_TYPE() != "REQ_CBRS"
         && CaseDocumentSegment::instance()->getDOC_TYPE() != "PI_DATA"
         && !bFirstPass)
         continue;
      if (CaseDocumentSegment::instance()->getEXPORT_IND() == "S")
         continue;
      string strEXPORT_IND;
      hQuery.reset();
      hQuery.bind("EMS_DOCUMENT", "DELETE_FLG", Column::STRING, &strDELETE_FLG);
      hQuery.bind("EMS_DOCUMENT", "EXPORT_IND", Column::STRING, &strEXPORT_IND);
      hQuery.setBasicPredicate("EMS_DOCUMENT", "CASE_ID", "=", CaseSegment::instance()->getCASE_ID());
      hQuery.setBasicPredicate("EMS_DOCUMENT", "SEQ_NO", "=", CaseDocumentSegment::instance()->getSEQ_NO());
      auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
      if(CaseTransitionSegment::instance()->getACTION().find("UPD_DOCFLG") != string::npos)
      {
         if (CaseTransitionSegment::instance()->getMANUAL_OVERRIDE() == "Y")  //assuming EX01::processActions took care of it
            CaseDocumentSegment::instance()->setEXPORT_IND(strEXPORT_IND);
         else if (CaseDocumentSegment::instance()->getEXPORT_IND() == "P")
         {
            if (CaseSegment::instance()->getSTATUS() == "REJR")
               CaseDocumentSegment::instance()->setEXPORT_IND("R");
            else
               CaseDocumentSegment::instance()->setEXPORT_IND("S");
         }
      }
      if((pSelectStatement->getRows() && CaseSegment::instance()->getCaseSource() == "X" && strDELETE_FLG == "Y")
         || CaseDocumentSegment::instance()->getSEQ_NO() == 0)
      {
         hQuery.reset();
         short siDOC_SEQ_NO;
         hQuery.bind("EMS_DOCUMENT","SEQ_NO",Column::SHORT,&siDOC_SEQ_NO,0,"MAX");
         hQuery.setBasicPredicate("EMS_DOCUMENT","CASE_ID","=",CaseSegment::instance()->getCASE_ID());                 
         if (!pSelectStatement->execute(hQuery))
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
         }
         siDOC_SEQ_NO++;
         CaseDocumentSegment::instance()->setSEQ_NO(siDOC_SEQ_NO);
      }
      CaseDocumentSegment::instance()->setExportIndDM5();
      pSelectStatement.reset();
      if (updateDocumentSegment() == false)
         return false;
   }
   return true;
  //## end emscommand::CaseUpdateCommand::processDocumentSegmentList%4E0251D6025B.body
}

bool CaseUpdateCommand::replicate ()
{
  //## begin emscommand::CaseUpdateCommand::replicate%4B74045A032C.body preserve=yes
   string strPROC_DEST_ID;
   string strPROC_ID(CaseSegment::instance()->getPROC_ID_ACQ());
   bool bReplicate(false);
   if ((bReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECOUT'",strPROC_DEST_ID)) == false)
   {
      strPROC_ID = CaseSegment::instance()->getPROC_ID_ISS();
      if ((bReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECOUT'",strPROC_DEST_ID)) == false)
      {
         strPROC_ID = CaseSegment::instance()->getPROC_ID_ACQ_B();
         if ((bReplicate=DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECOUT'",strPROC_DEST_ID)) == false)
         {
            strPROC_ID = CaseSegment::instance()->getPROC_ID_ISS_B();
            if ((bReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECOUT'",strPROC_DEST_ID)) == false)
            {
               strPROC_ID = CaseSegment::instance()->getPROC_GRP_ID_ACQ_B();
               if ((bReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECOUT'",strPROC_DEST_ID)) == false)
               {
                  strPROC_ID = CaseSegment::instance()->getPROC_GRP_ID_ISS_B();
                  bReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECOUT'",strPROC_DEST_ID);
               }
            }
         }
      }
   }
   string strCASE_NO(CaseSegment::instance()->getCASE_NO());
   string strINST_DEST_ID;
   bool bInstReplicate(false);
   if (DataControl::instance()->getLevel(DataControl::I))
   {
      string strINST_ID(CaseSegment::instance()->getINST_ID_RECN_ACQ_B());
      if ((bInstReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getInstitutionDestination(strINST_ID,"'ECOUT'",strINST_DEST_ID)) == false)
      {
         strINST_ID = CaseSegment::instance()->getINST_ID_RECON_ISS();
         bInstReplicate = DataControl::instance(Transaction::instance()->getQualifier().c_str())->getInstitutionDestination(strINST_ID,"'ECOUT'",strINST_DEST_ID);
      }
   }
   Case::instance()->backupSegments();
   if (bReplicate || bInstReplicate)
   {
      if (CaseSegment::instance()->getNET_ID_EMS() == "ILK" || CaseSegment::instance()->getNET_ID_EMS() == "PLS")
      {
         CaseSegment::instance()->setReplicatedRETRIEVAL_REF_NO(CaseSegment::instance()->getRETRIEVAL_REF_NO());
         CaseSegment::instance()->setReplicatedSYS_TRACE_AUDIT_NO(CaseSegment::instance()->getSYS_TRACE_AUDIT_NO());
      }   
      CommonHeaderSegment::instance()->setPROC_DEST_ID(strPROC_DEST_ID);
      CaseSegment::instance()->setReplicatedCASE_NO(CaseSegment::instance()->getCASE_NO());
      Command::replicate();
      if (bInstReplicate)
      {
         if (CaseSegment::instance()->getINST_ID_RECN_ACQ_B() != CaseSegment::instance()->getINST_ID_RECON_ISS())
         {
            DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*I", CaseSegment::instance()->getINST_ID_RECN_ACQ_B());
            DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*I", CaseSegment::instance()->getINST_ID_RECON_ISS());
         }
         else
            DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*I", CaseSegment::instance()->getINST_ID_RECN_ACQ_B());
      }
      if (bReplicate)
      {
      if (CaseSegment::instance()->getPROC_ID_ACQ() != CaseSegment::instance()->getPROC_ID_ISS())
         DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*P",CaseSegment::instance()->getPROC_ID_ISS());
      if (CaseSegment::instance()->getPROC_ID_ACQ() != CaseSegment::instance()->getPROC_ID_ACQ_B())
         DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*P",CaseSegment::instance()->getPROC_ID_ACQ_B());
      DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*P",CaseSegment::instance()->getPROC_ID_ACQ());
      if (CaseSegment::instance()->getPROC_ID_ISS() != CaseSegment::instance()->getPROC_ID_ISS_B())
         DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*P",CaseSegment::instance()->getPROC_ID_ISS_B());
      if (CaseSegment::instance()->getPROC_GRP_ID_ACQ_B() != CaseSegment::instance()->getPROC_GRP_ID_ISS_B())
         DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*G", CaseSegment::instance()->getPROC_GRP_ID_ISS_B());
      DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*G", CaseSegment::instance()->getPROC_GRP_ID_ACQ_B());
      }

   }
   if (Customer::instance()->getFUNDS_PROC_ID().empty() == false)
   {
       if (bReplicate == false)
       {
           if (CaseSegment::instance()->getNET_ID_EMS() == "ILK" || CaseSegment::instance()->getNET_ID_EMS() == "PLS")
           {
               CaseSegment::instance()->setReplicatedRETRIEVAL_REF_NO(CaseSegment::instance()->getRETRIEVAL_REF_NO());
               CaseSegment::instance()->setReplicatedSYS_TRACE_AUDIT_NO(CaseSegment::instance()->getSYS_TRACE_AUDIT_NO());
           }
       }
      strPROC_ID.assign(Customer::instance()->getFUNDS_PROC_ID());
      if (!DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID, "'ECOUT'", strPROC_DEST_ID))
         CaseSegment::instance()->setCASE_NO(strCASE_NO);
      else
      {
         CommonHeaderSegment::instance()->setPROC_DEST_ID(strPROC_DEST_ID);
         CaseSegment::instance()->setReplicatedCASE_NO(CaseSegment::instance()->getCASE_NO());
         Command::replicate();
         DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*P", strPROC_ID);
      }
   }
   if (Case::instance()->checkInstId(CaseSegment::instance()->getINST_ID_RECON_ISS()))
   {
      strPROC_ID.assign(Customer::instance()->getFUNDS_PROC_ID());
      if (!DataControl::instance(Transaction::instance()->getQualifier().c_str())->getDestination(strPROC_ID,"'ECHIST'",strPROC_DEST_ID))
      {
         Case::instance()->restoreSegments();
         CaseSegment::instance()->setCASE_NO(strCASE_NO);
         return true;
      }
      CommonHeaderSegment::instance()->setPROC_DEST_ID(strPROC_DEST_ID);
      CaseSegment::instance()->setReplicatedCASE_NO(CaseSegment::instance()->getCASE_NO());
      Command::replicate();
      DataControl::instance(Transaction::instance()->getQualifier().c_str())->replicate("*P",strPROC_ID);
   }
   Case::instance()->restoreSegments();
   CaseSegment::instance()->setCASE_NO(strCASE_NO);
   return true;
  //## end emscommand::CaseUpdateCommand::replicate%4B74045A032C.body
}

void CaseUpdateCommand::replicateOtherCase ()
{
  //## begin emscommand::CaseUpdateCommand::replicateOtherCase%4E73577E0334.body preserve=yes
   *Message::instance(Message::INBOUND) = *Message::instance(Message::OUTBOUND);
   char pszLength[9] = {"        "};
   char* psBuffer = Message::instance(Message::OUTBOUND)->data() + 8;
   char* pEndOfMessage = Message::instance(Message::OUTBOUND)->data() + Message::instance(Message::OUTBOUND)->dataLength();
   vector<Segment*>::iterator ppSegment;
   int iRC = 0;
   while (psBuffer < pEndOfMessage)
   {
      if (memcmp(psBuffer,"S208",4) == 0)
      {
         CaseSegment::instance()->deport(&psBuffer);
         break;
      }
      memcpy(pszLength,psBuffer + 8,8);
      psBuffer += atoi(pszLength);
   }
   string strClientVersion(CommonHeaderSegment::instance()->getClientVersion());
   replicate();
   CommonHeaderSegment::instance()->setClientVersion(strClientVersion);
   *Message::instance(Message::OUTBOUND) = *Message::instance(Message::INBOUND);
  //## end emscommand::CaseUpdateCommand::replicateOtherCase%4E73577E0334.body
}

void CaseUpdateCommand::update (Subject* pSubject)
{
  //## begin emscommand::CaseUpdateCommand::update%3731EA9C01E7.body preserve=yes
   if (pSubject == Message::instance(Message::INBOUND)
      && Message::instance(Message::INBOUND)->messageID() == "S0003D")
   {
      char* p = ((Message*)pSubject)->data() + 24;
      if (strncmp(p,"QEMUCASE",8) == 0)
      {
         // CL19: Client_Updates_Case_On_DB
         UseCase hUseCase("CLIENT","## CL19 UPDATE CASE");
         *Message::instance(Message::OUTBOUND) = *Message::instance(Message::INBOUND);
         if (parse() != 0)
         {
            UseCase::setSuccess(false);
            return;
         }
         bool bSuccess = execute();
         Transaction::instance()->setCustomer(m_strCUST_ID);
         Transaction::instance()->setQualifier("CUSTQUAL");
         if (CaseSegment::instance()->getUSER_ROLE().length() == 0
            || CaseSegment::instance()->getCaseSource() == "D")
            CaseSegment::instance()->setUSER_ROLE();
         if (!bSuccess)
         {
            EMailMessage::eraseAll();
            Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            sendError(m_iResultCode,STS_ERROR,m_lInfoIDNumber);
            UseCase::setSuccess(false);
            return;
         }
         if (CardholderInformationSegment::instance()->presence())
         {
            string strTSTAMP_LAST_UPDATE;
            Query hQuery;
            hQuery.setQualifier("QUALIFY","CARDHOLDER");
            hQuery.bind("CARDHOLDER","TSTAMP_LAST_UPDATE",Column::STRING,&strTSTAMP_LAST_UPDATE);
            hQuery.setBasicPredicate("CARDHOLDER","PAN","=",CardholderInformationSegment::instance()->getPAN().c_str());
            auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
            pSelectStatement->execute(hQuery);
            CardholderInformationSegment::instance()->setTSTAMP_LAST_UPDATE(strTSTAMP_LAST_UPDATE);
         }
         CaseSegment::instance()->setTSTAMP_UPDATED(Transaction::instance()->getTimeStamp());
         Database::instance()->setTransactionState(Database::COMMITREQUIRED);
         Message::instance(Message::INBOUND)->reset("EMSCI ","S0003R");
         m_pDataBuffer = ((Message*)pSubject)->data() + 8;
         CommonHeaderSegment::instance()->deport(&m_pDataBuffer);
         vector<Segment*>::iterator ppSegment;
         for (ppSegment = m_hSegments.begin();ppSegment != m_hSegments.end();++ppSegment)
         {
             if((*ppSegment)->presence() && (((*ppSegment)->segmentID() != (const char*)"L001")&&
                    ((*ppSegment)->segmentID() != (const char*)"S053") &&
                    ((*ppSegment)->segmentID() != (const char*)"S912") &&
                    ((*ppSegment)->segmentID() != (const char*)"S001") &&
                    ((*ppSegment)->segmentID() != (const char*)"S400")))
                        (*ppSegment)->deport(&m_pDataBuffer);
         }
         getResponseTimeSegment()->deport(&m_pDataBuffer);
         Message hMessage(*(Message::instance(Message::INBOUND)));
         replicate();
         *(Message::instance(Message::INBOUND)) = hMessage;
         if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
         {
            m_iResultCode = STS_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            sendError(m_iResultCode,STS_ERROR,m_lInfoIDNumber,false);
            return;
         }
         reply();
         CardholderInformationSegment::instance()->wipe("PAN");
      }
      else
      if (m_pSuccessor)
         m_pSuccessor->update(pSubject);
      return;
   }
   ClientCommand::update(pSubject);
  //## end emscommand::CaseUpdateCommand::update%3731EA9C01E7.body
}

bool CaseUpdateCommand::updateCase (bool bFirstCase)
{
  //## begin emscommand::CaseUpdateCommand::updateCase%3C04FF210131.body preserve=yes
   // update case, case extension, phase, phase extension and transition
   if (CaseSegment::instance()->getUSER_ROLE().length() == 0)
      CaseSegment::instance()->setUSER_ROLE();
   bool bSamePhase(true);
   if (CaseTransitionSegment::instance()->presence())
   {
      bSamePhase = CaseSegment::instance()->getREQUEST_TYPE() == CaseTransitionSegment::instance()->getREQUEST_TYPE_NEXT();
         if (bSamePhase && (CaseTransitionSegment::instance()->getREQUEST_TYPE_NEXT() == "ADJM"))
            bSamePhase = false;
   }
   // do update and insert functions
   vector<Segment*>::iterator ppSegment;
   for (ppSegment = m_hSegments.begin();ppSegment != m_hSegments.end();++ppSegment)
   {
      if ((*ppSegment)->presence() && (*ppSegment)->persistent()
          && (*ppSegment)->segmentID() != (const char*)"S211"
          && (*ppSegment)->segmentID() != (const char*)"S214"
            && (*ppSegment)->segmentID() != (const char*)"S276"
            && (*ppSegment)->segmentID() != (const char*)"S282") // Account Entry
      {
         if(!updateSegment((PersistentSegment*)(*ppSegment),bSamePhase))
            return false;
      }
   }

   if (CaseCommentSegment::instance()->presence() &&
       (CaseSegment::instance()->getCaseSource() == "I" 
       || CaseSegment::instance()->getCaseSource() == "X"))

   {
      m_lInfoIDNumber = Case::addComment(0);
      if (m_lInfoIDNumber != 0)
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         m_iResultCode = STS_ERROR;
         return false;
      }
   }
   
   for(int i = 0; i < 4; i++)
   {
      if(!m_pListSegment[i]->presence())
         break; 
      char* p = (char*)*m_pListSegment[i];     
      if (!memcmp(p,(const char*)"S214",4))
         m_lInfoIDNumber = Case::instance()->addComments(m_pListSegment[i]);
      else if (!memcmp(p,(const char*)"S282",4))
      {
         AccountEntry hAccountEntry;
         for (int j = 0;j < m_pListSegment[i]->itemCount();++j)
         {
            if ((m_lInfoIDNumber = CaseAccountHistorySegment::instance()->import(&p)) == 0)
            {
               if ((m_lInfoIDNumber = hAccountEntry.process(CaseAccountHistorySegment::instance())) != 0) 
                  break;
            }
            else
                 break;
         }
         CaseAccountHistorySegment::instance()->setPresence(false);  
      }
      else if (!memcmp(p, (const char*)"AVNT", 4))
      {
         for (int j = 0; j < m_pListSegment[i]->itemCount(); ++j)
         {
            if ((m_lInfoIDNumber = AssociatedTranVNTSegment::instance()->import(&p)) == 0)
            {
               if (!updateSegment((PersistentSegment*)(AssociatedTranVNTSegment::instance()), bSamePhase))
                  break;
            }
            else
               break;
         }
      }
      else if (!memcmp(p, (const char*)"AMCI", 4))
      {
         for (int j = 0; j < m_pListSegment[i]->itemCount(); ++j)
         {
            if ((m_lInfoIDNumber = AssociatedTranMCISegment::instance()->import(&p)) == 0)
            {
               if (!updateSegment((PersistentSegment*)(AssociatedTranMCISegment::instance()), bSamePhase))
                  break;
            }
            else
               break;
         }
      }
      //if we have a list of documents, don't go through the document list if we've already sent the case.
      Trace::put("1st pass");
      if (!memcmp(p,(const char*)"S276",4))
      {
         if (CaseSegment::instance()->getCaseSource() == "B")
            processBatchDocumentList(i);
         else 
            processDocumentSegmentList(i,true);
      }
      if (m_lInfoIDNumber != 0)
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         m_iResultCode = STS_QUERY_ERROR;
         return false;
      }
   }
   if (Extract::instance()->getCustomCode() == "REGIONS" && CaseAccountHistorySegment::instance()->presence())
   {
      AccountEntry hAccountEntry;
      m_lInfoIDNumber = hAccountEntry.process(CaseAccountHistorySegment::instance());
      if (m_lInfoIDNumber != 0)
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         m_iResultCode = STS_QUERY_ERROR;
         return false;
      }
   }
   string strTSTAMP_CREATED;
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   // perform the requested transition
   if (CaseTransitionSegment::instance()->presence())
   {
      if (CaseTransitionSegment::instance()->getMANUAL_OVERRIDE() == "Y" || CaseTransitionSegment::instance()->getSTATUS_NEXT() == "CLOC")
      {
         Table hTable("EMS_CASE_CONTEXT");
         hTable.set("PROCESSED_FLG","D",false,false);
         hTable.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
         SearchCondition hSearchCondition;
         hSearchCondition.setBasicPredicate("EMS_CASE_CONTEXT","PROCESSED_FLG","=","N");
         hSearchCondition.setBasicPredicate("EMS_CASE_CONTEXT","CONTEXT_TYPE","LIKE","EXP%");
         auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
         if (!pUpdateStatement->execute(hTable, hSearchCondition.getText()))
            if (pUpdateStatement->getInfoIDNumber() != STS_RECORD_NOT_FOUND)
            {
               Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);         
               m_iResultCode = STS_QUERY_ERROR;  
               return false;
            }         
      }
      m_lInfoIDNumber = Case::instance()->transition(true,true,bFirstCase);
      if (m_lInfoIDNumber != 0)
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         m_iResultCode = STS_QUERY_ERROR;
         return false;
      }
      strTSTAMP_CREATED = CaseTransitionSegment::instance()->getTSTAMP_CREATED();
      //Transition is successful. Update the comment segments to ensure that they are associated with the right phase.
      if (CaseCommentSegment::instance()->presence()
         && CaseCommentSegment::instance()->getEMS_COMMENT().length() > 0)
      {
         Table hTable;
         hTable.setName("EMS_COMMENT");
         hTable.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
         hTable.set("TSTAMP_CREATED",Transaction::instance()->getTimeStamp(),false,true);
         hTable.set("TSTAMP_PHASE",CasePhaseSegment::instance()->getTSTAMP_CREATED());
         if (pUpdateStatement->execute(hTable) == false 
            && pUpdateStatement->getInfoIDNumber() != STS_RECORD_NOT_FOUND)
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
         }
      }
      
      //Transition is successful. Now process the documents to ensure that they are associated with the right phase.
      for(int i = 0; i < 4; i++)
      {
         if(!m_pListSegment[i]->presence())
            break; 
         char* p = (char*)*m_pListSegment[i];     
         if (!memcmp(p,(const char*)"S276",4))
         {
            bool bReturn = false;
            if (CaseSegment::instance()->getCaseSource() == "B")
            {
               deleteNonExportedQuestionnaire();
               bReturn = processBatchDocumentList(i);
            }
            else
               bReturn = processDocumentSegmentList(i);
            if (!bReturn)
            {
               Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
               m_iResultCode = STS_QUERY_ERROR;
               return false;
            }
         }
      }
   }
   else
   {
      Query hQuery;
      short iNull = -1;
      hQuery.bind("EMS_TRANSITION","TSTAMP_CREATED",Column::STRING,&strTSTAMP_CREATED,&iNull,"MAX");
      hQuery.setBasicPredicate("EMS_TRANSITION","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
   }
   if (CaseSegment::instance()->getCASE_TYPE_IND() == "D"
      && CaseSegment::instance()->getREQUEST_TYPE().substr(0,3) == "FDR")
   {
      if (!CaseSegment::instance()->setTstampFirstFraud())
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
      if (CaseCardholderSegment::instance()->getTSTAMP_FIRST_FRAUD().empty()
         || CaseSegment::instance()->getTstampFirstFraud() < CaseCardholderSegment::instance()->getTSTAMP_FIRST_FRAUD())
      {
         SearchCondition hSearchCondition;
         Table hTable("EMS_CARDHOLDER");
         hTable.set("PAN",CaseSegment::instance()->getPAN(),false,true,false,2);
         hTable.set("TSTAMP_UPDATED",Transaction::instance()->getTimeStamp());
         if (CaseSegment::instance()->getTstampFirstFraud().empty())
            hTable.set("TSTAMP_FIRST_FRAUD"," ");
         else
            hTable.set("TSTAMP_FIRST_FRAUD",CaseSegment::instance()->getTstampFirstFraud());
         hTable.set("CHB_COUNTER",CaseCardholderSegment::instance()->getCHB_COUNTER());
         hTable.set("NET_ID",CaseSegment::instance()->getNET_ID_EMS());
         string strTemp = "(' ','" + CaseSegment::instance()->getNET_ID_EMS() + "')";
         hSearchCondition.setBasicPredicate("EMS_CARDHOLDER","NET_ID","IN",strTemp.c_str());
         if (CaseSegment::instance()->getCASE_EXTENSION() == "MCI")
         {
            hTable.set("DATE_EXPIRY",CasePhaseSegment::instance()->getDATE_EXPIRATION());
            hSearchCondition.setBasicPredicate("EMS_CARDHOLDER", "DATE_EXPIRY", "=",CasePhaseSegment::instance()->getDATE_EXPIRATION().empty() ? " " : CasePhaseSegment::instance()->getDATE_EXPIRATION().c_str());
         }
         else
            hSearchCondition.setBasicPredicate("EMS_CARDHOLDER","DATE_EXPIRY","="," ");
         auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
         if (pUpdateStatement->execute(hTable,hSearchCondition.getText()) == false && pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
         {
            auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
            if (pInsertStatement->execute(hTable) == false)
            {
               m_iResultCode = STS_QUERY_ERROR;
               m_lInfoIDNumber = STS_DATABASE_FAILURE;
               return false;
            }
         }
      }
   }

      if (m_bQuestionnaireUpdated)
      {
         Table hTable("EMS_DATA_CHG");
         auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         short siSEQ_NO = 0;
         Query hQuery;
         hQuery.bind("EMS_DATA_CHG","SEQ_NO",Column::SHORT,&siSEQ_NO,0,"MAX");
         hQuery.setBasicPredicate("EMS_DATA_CHG","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
         hQuery.setBasicPredicate("EMS_DATA_CHG","TSTAMP_CREATED","=",Transaction::instance()->getTimeStamp().c_str());
         auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
         if (!pSelectStatement->execute(hQuery))
            return false;
         hTable.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
         hTable.set("USER_ID",CommonHeaderSegment::instance()->getUserID());
         hTable.set("SEQ_NO",++siSEQ_NO);
         hTable.set("TSTAMP_CREATED",Transaction::instance()->getTimeStamp());
         if (m_bDocExt)
         {
            hTable.set("TABLE_CHANGED", "EMS_DOCUMENT_EXT");
            hTable.set("COLUMN_CHANGED", "DATA_BUFFER");
         }
         else
         {
            if (m_bSmartForm)
               hTable.set("TABLE_CHANGED","EMS_SMARTFORM");
            else
               hTable.set("TABLE_CHANGED","EMS_PHASE_VNT_VROL");
            hTable.set("COLUMN_CHANGED","QUESTION_FIELDS");
         }
         hTable.set("COLUMN_OLD_VALUE","Xml data not available");
         hTable.set("COLUMN_NEW_VALUE","Xml data not available");
         if (!pInsertStatement->execute(hTable))
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
         }
         m_bQuestionnaireUpdated = false;
         m_bSmartForm = false;
         m_bDocExt = false;
      }

// This was initially put in so that the TSTAMP_AUTO_TRANS would get re-calculated if the
//user updated some field on the case that the Auto Days went off of.  The user is not
//transitioning the case...just updating it.  We feel this is not needed anymore and may be
//the cause of Voca's current problem.  This has probably not been seen very well at the
//DataCenter since the only real setting we do is same day.

//   else  
//      Case::setTSTAMP_AUTO_TRANS(true,true);

   if (Extract::instance()->getCustomCode() != "REGIONS" && CaseAccountHistorySegment::instance()->presence())
   {
      AccountEntry hAccountEntry;
      m_lInfoIDNumber = hAccountEntry.process(CaseAccountHistorySegment::instance());
      if (m_lInfoIDNumber != 0)
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         m_iResultCode = STS_QUERY_ERROR;
         return false;
      }
   }

   if (m_bRCChanged && CaseTransitionSegment::instance()->getACTION().empty())
   {
      vector<ActionDetail> hActionDetails;
      EMSRulesEngine::instance()->getRCActions(hActionDetails);
      m_lInfoIDNumber = Case::instance()->processActions(hActionDetails);
      if (m_lInfoIDNumber != 0)
         return false;
   }
   //Save any changes to ACTION_TO_CARDHDLR,REASON_CODE and USER_ROLE to transition
   Table hTable;
   hTable.setAudit(true);
   hTable.setName("EMS_TRANSITION");
   hTable.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
   hTable.set("TSTAMP_CREATED",strTSTAMP_CREATED,false,true);
   hTable.set("ACTION_TO_CARDHLDR",CasePhaseSegment::instance()->getACTION_TO_CARDHLDR());
   hTable.set("REASON_CODE",CasePhaseSegment::instance()->getREASON_CODE());
   hTable.set("AMT_ADJUSTMENT",CasePhaseSegment::instance()->getAMT_ADJUSTMENT());
   hTable.set("AMT_ACPT_NET",CasePhaseSegment::instance()->getAMT_ACPT_NET());
   hTable.set("AMT_ACPT_TRAN",CasePhaseSegment::instance()->getAMT_ACPT_TRAN());
   hTable.set("LETTER_CODE", CasePhaseSegment::instance()->getLETTER_CODE());
   if (pUpdateStatement->execute(hTable) == false)
      return false;

   Table hEMSCaseDataChg("EMS_DATA_CHG");
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   CaseAddEventVisitor hCaseAddEventVisitor(&hEMSCaseDataChg,pInsertStatement.get());
   hEMSCaseDataChg.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
   if (CommonHeaderSegment::instance()->presence())
      hEMSCaseDataChg.set("USER_ID",CommonHeaderSegment::instance()->getUserID().c_str());
   else
      hEMSCaseDataChg.set("USER_ID","SYSTEM");
   hEMSCaseDataChg.set("TSTAMP_CREATED",Transaction::instance()->getTimeStamp());
   hTable.accept(hCaseAddEventVisitor);
   if (!hCaseAddEventVisitor.successful())
      return false;

   //Case to Case imported cases needs to be saved with IPRT.
   if(CaseSegment::instance()->getOTHER_CUST_ID() == "XPRT")
   {
      CaseSegment::instance()->setOTHER_CUST_ID("IPRT");
      Table hTable;
      hTable.setName("EMS_CASE");
      hTable.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
       hTable.set("OTHER_CUST_ID","IPRT");
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      if (pUpdateStatement->execute(hTable) == false)
      {
         m_iResultCode = STS_QUERY_ERROR;
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         return false;
      }
   }
   m_lInfoIDNumber = Case::instance()->updateCaseGroup();
   if (m_lInfoIDNumber)
   {
      m_iResultCode = STS_QUERY_ERROR;
      return false;
   }
   return true;
  //## end emscommand::CaseUpdateCommand::updateCase%3C04FF210131.body
}

bool CaseUpdateCommand::updateDocumentSegment ()
{
  //## begin emscommand::CaseUpdateCommand::updateDocumentSegment%4DB6CE8A02CE.body preserve=yes
   string strQUESTION_FIELDS;
   if (CaseDocumentSegment::instance()->getDOC_TYPE().find("QTN_") == string::npos
      && CaseDocumentSegment::instance()->getEXPORT_IND() == "E" )
         CaseDocumentSegment::instance()->setEXPORT_IND("P");

   if (CaseDocumentSegment::instance()->getEXPORT_IND() == "P" 
       || CaseDocumentSegment::instance()->getEXPORT_IND() == "S" )
   {
      // if the document is not a questionnaire, we need to see what the export_ind is in the database
      if (CaseDocumentSegment::instance()->getDOC_TYPE().find("QTN_") == string::npos
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 3) != "DCF"
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_PARB_"
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,8) != "REQ_ARB_"
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_PCMP_"
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_COMP_"
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_PRSP_"
         && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_CRSP_"
         && CaseDocumentSegment::instance()->getDOC_TYPE() != "PI_DATA"
         && CaseDocumentSegment::instance()->getDOC_TYPE() != "REQ_CBRS")
      {
         Query hQuery;
         string strEXPORT_IND;
         hQuery.bind("EMS_DOCUMENT","EXPORT_IND",Column::STRING,&strEXPORT_IND);
         hQuery.setBasicPredicate("EMS_DOCUMENT","CASE_ID","=",CaseSegment::instance()->getCASE_ID());
         hQuery.setBasicPredicate("EMS_DOCUMENT","SEQ_NO","=",CaseDocumentSegment::instance()->getSEQ_NO());                
         auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));  
         if (!pSelectStatement->execute(hQuery))
         {
            m_iResultCode = STS_QUERY_ERROR;
            m_lInfoIDNumber = STS_DATABASE_FAILURE;
            return false;
         }
         if( strEXPORT_IND == CaseDocumentSegment::instance()->getEXPORT_IND())
            return true;
      }
   }
   // retrieve the questionnaire text that has come as part of the document segment
   if(((CaseDocumentSegment::instance()->getDOC_TYPE().length()>3
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,4) == "QTN_") 
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 3) == "DCF")
      && CaseSegment::instance()->getCASE_EXTENSION() == "VNT")
   {
      if (CaseDocumentSegment::instance()->getEXPORT_IND() != "P" 
         && CaseDocumentSegment::instance()->getEXPORT_IND() != "S")
      {
         strQUESTION_FIELDS = CaseDocumentSegment::instance()->getDOC_PATH();
         size_t nPos1 = 0;
         size_t nPos2 = 0;
         size_t nPos3 = 0;
         nPos1 = strQUESTION_FIELDS.find("<ChargebackRefNum>");
         nPos2 = strQUESTION_FIELDS.find("</ChargebackRefNum>");
         if (nPos1 != string::npos)
         {         
            nPos3 = nPos2 - (nPos1+18);
            strQUESTION_FIELDS.replace(nPos1+18, nPos3,CasePhaseVisaSegment::instance()->getCHB_REF_NO());
         }
         nPos1 = strQUESTION_FIELDS.find("<MemberMsgEditText>");
         nPos2 = strQUESTION_FIELDS.find("</MemberMsgEditText>");
         if (nPos1 != string::npos)
         {         
            nPos3 = nPos2 - (nPos1+19);
            strQUESTION_FIELDS.replace(nPos1+19, nPos3, CasePhaseVisaSegment::instance()->getVISA_MMT());            
         }
         nPos1 = strQUESTION_FIELDS.find("<ExplanationOfCreditPresented>");
         nPos2 = strQUESTION_FIELDS.find("</ExplanationOfCreditPresented>");
         if (nPos1 != string::npos)
         {
            nPos3 = nPos2 - (nPos1+30);
            strQUESTION_FIELDS.replace(nPos1+30, nPos3, CasePhaseVisaSegment::instance()->getNOT_ASSOC_REASON());
         }
      }
      if (m_strQUESTION_FIELDS != strQUESTION_FIELDS)
         m_bQuestionnaireUpdated = true;
      CaseDocumentSegment::instance()->setDOC_PATH(" ");
   }
   if ((CaseDocumentSegment::instance()->getDOC_TYPE().length()>3
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,4) != "QTN_")
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0, 3) != "DCF"
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_PARB_"
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,8) != "REQ_ARB_"
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_PCMP_"
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_COMP_"
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_PRSP_"
      && CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) != "REQ_CRSP_"
      && CaseDocumentSegment::instance()->getDOC_TYPE() != "PI_DATA"
      && CaseDocumentSegment::instance()->getDOC_TYPE() != "REQ_CBRS"
      && (CaseSegment::instance()->getCASE_EXTENSION() == "MCI" || CaseSegment::instance()->getCASE_EXTENSION() == "VNT"))
   {
      string strDOC_PATH(CaseDocumentSegment::instance()->getDOC_PATH());
      string strTemp;
      size_t nPos1 = strDOC_PATH.find(CaseSegment::instance()->getCASE_EXTENSION());
      if (nPos1 != string::npos)
      {
         strTemp.assign(strDOC_PATH,0,nPos1-1); 
         if ((strTemp != Case::instance()->getDOC_PATH(0)
            && strTemp != Case::instance()->getDOC_PATH(1))
            && (Case::instance()->getDOC_PATH(0).length() != 0 ||
                Case::instance()->getDOC_PATH(1).length() != 0 ))
         {
            strDOC_PATH.replace(0,nPos1-1,Case::instance()->getDOC_PATH(1).length() != 0 ? Case::instance()->getDOC_PATH(1) : Case::instance()->getDOC_PATH(0));
            CaseDocumentSegment::instance()->setDOC_PATH(strDOC_PATH);
         }
      }
   }
   if (CaseDocumentSegment::instance()->getDOC_TYPE() == "SMART_FORM"
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_PARB_"
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,8) == "REQ_ARB_"
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_PCMP_"
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_COMP_"
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_PRSP_"
      || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_CRSP_"
      || CaseDocumentSegment::instance()->getDOC_TYPE() == "REQ_CBRS"
      || CaseDocumentSegment::instance()->getDOC_TYPE() == "PI_DATA")
   {
      strQUESTION_FIELDS = CaseDocumentSegment::instance()->getDOC_PATH();
      if (m_strQUESTION_FIELDS != strQUESTION_FIELDS)
         m_bQuestionnaireUpdated = true;
      CaseDocumentSegment::instance()->setDOC_PATH("");
   }
   auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   Table hTable; 
   // if the document that is being added is a questionnaire
   if (strQUESTION_FIELDS.length() > 0 
      && CaseDocumentSegment::instance()->getEXPORT_IND() != "P" 
       && CaseDocumentSegment::instance()->getEXPORT_IND() != "S")
   {
      if (CaseDocumentSegment::instance()->getEXPORT_IND() == "E")
         CaseDocumentSegment::instance()->setEXPORT_IND("P");
      hTable.setAudit(true);
      CaseDocumentSegment::instance()->setColumns(hTable);
      if (pInsertStatement->execute(hTable) == true)
      {
         if (CaseDocumentSegment::instance()->getDOC_TYPE() == "SMART_FORM")
            return insertSmartFormSegment(strQUESTION_FIELDS);
         else 
         if (CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_PARB_"
            || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,8) == "REQ_ARB_"
            || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_PCMP_"
            || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_COMP_"
            || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_PRSP_"
            || CaseDocumentSegment::instance()->getDOC_TYPE().substr(0,9) == "REQ_CRSP_"
            || CaseDocumentSegment::instance()->getDOC_TYPE() == "REQ_CBRS")
            return insertDocExtensionSegment(strQUESTION_FIELDS);
         else
            return insertVROLSegment(strQUESTION_FIELDS);
      }
      else if (pUpdateStatement->execute(hTable) == false)
         return false;
   }
   else
   {
      hTable.setAudit(true);
      CaseDocumentSegment::instance()->setColumns(hTable);
      if (pUpdateStatement->execute(hTable) == false)
      {
         if (pInsertStatement->execute(hTable) == false)
            return false;
      }
   }
   Table hEMSCaseDataChg("EMS_DATA_CHG");
   CaseAddEventVisitor hCaseAddEventVisitor(&hEMSCaseDataChg,pInsertStatement.get());
   hEMSCaseDataChg.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
   if (CommonHeaderSegment::instance()->presence())
      hEMSCaseDataChg.set("USER_ID",CommonHeaderSegment::instance()->getUserID().c_str());
   else
      hEMSCaseDataChg.set("USER_ID","SYSTEM");
   hEMSCaseDataChg.set("TSTAMP_CREATED",Transaction::instance()->getTimeStamp());
   hTable.accept(hCaseAddEventVisitor);
   if (!hCaseAddEventVisitor.successful())
      return false;
   return true;
  //## end emscommand::CaseUpdateCommand::updateDocumentSegment%4DB6CE8A02CE.body
}

bool CaseUpdateCommand::updateSegment (segment::PersistentSegment* pPersistentSegment, bool bSamePhase)
{
  //## begin emscommand::CaseUpdateCommand::updateSegment%3EC908DD0222.body preserve=yes
   Table hTable;
   (pPersistentSegment)->setColumns(hTable);

   // Update all of the  segments when the phase request type does not change.
   // Update the segments that do not have "EMS_PHASE" as part of the table
   // name if the request type changes.
   if (bSamePhase || hTable.getName().find("EMS_PHASE") == -1)
   {
      hTable.setAudit(true);
      auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      if (pUpdateStatement->execute(hTable) == false)
      {
         if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND
            && ((pPersistentSegment)->segmentID() == (const char*)"S269" 
             || (pPersistentSegment)->segmentID() == (const char*)"CPAY")
             && pInsertStatement->execute(hTable))
                return true;
         if (hTable.getName().find("EMS_PHASE_") == -1)
            if (hTable.getName().find("EMS_CASE_") == -1)
            {
               string strValue;
               if (pUpdateStatement->getInfoIDNumber() == STS_DUPLICATE_RECORD)
               {
                  Query hQuery;
                  int lDUP_SEQ_NO = 0;
                  short iNull = -1;
                  auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
                  hQuery.bind("EMS_CASE", "DUP_SEQ_NO", Column::LONG, &lDUP_SEQ_NO, &iNull, "MAX");
                  hQuery.setBasicPredicate("EMS_CASE","NET_ID_ACQ","=",CaseSegment::instance()->getNET_ID_ACQ().c_str());
                  hQuery.setBasicPredicate("EMS_CASE","NET_ID_ISS","=",CaseSegment::instance()->getNET_ID_ISS().c_str());
                  hQuery.setBasicPredicate("EMS_CASE","CASE_TYPE_IND","=",CaseSegment::instance()->getCASE_TYPE_IND().c_str());
                  hQuery.setBasicPredicate("EMS_CASE","PAN","=",CaseSegment::instance()->getPAN().c_str());
                  hQuery.setBasicPredicate("EMS_CASE","RETRIEVAL_REF_NO","=",CaseSegment::instance()->getRETRIEVAL_REF_NO().c_str());
                  hQuery.setBasicPredicate("EMS_CASE","TSTAMP_LOCAL","=",CaseSegment::instance()->getTSTAMP_LOCAL().c_str());
                  hQuery.setBasicPredicate("EMS_CASE","TSTAMP_TRANS","=",CaseSegment::instance()->getTSTAMP_TRANS().c_str());
                  hQuery.setBasicPredicate("EMS_CASE","UNIQUENESS_KEY","=",CaseSegment::instance()->getUNIQUENESS_KEY());
                  hQuery.setBasicPredicate("EMS_CASE","SYS_TRACE_AUDIT_NO","=",CaseSegment::instance()->getSYS_TRACE_AUDIT_NO().c_str());
                  if (!pSelectStatement->execute(hQuery) || iNull == -1)
                  {
                     m_iResultCode = STS_QUERY_ERROR;
                     m_lInfoIDNumber = STS_DATABASE_FAILURE;
                     return false;
                  }
                  hTable.set("DUP_SEQ_NO",++lDUP_SEQ_NO);
                  pUpdateStatement->execute(hTable);
                  m_lInfoIDNumber = pUpdateStatement->getInfoIDNumber();
                  if (m_lInfoIDNumber == 0)
                  {
                     CaseSegment::instance()->setDUP_SEQ_NO(lDUP_SEQ_NO);
                     Table hEMSCaseDataChg("EMS_DATA_CHG");
                     CaseAddEventVisitor hCaseAddEventVisitor(&hEMSCaseDataChg,pInsertStatement.get());
                     hEMSCaseDataChg.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
                     hEMSCaseDataChg.set("USER_ID",CommonHeaderSegment::instance()->getUserID().c_str());
                     hEMSCaseDataChg.set("TSTAMP_CREATED",Transaction::instance()->getTimeStamp());
                     hTable.accept(hCaseAddEventVisitor);
                     if (!hCaseAddEventVisitor.successful())
                     {
                        Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
                        m_lInfoIDNumber = STS_DATABASE_FAILURE;
                        m_iResultCode = STS_QUERY_ERROR;
                        return false;
                     }
                     return true;
                  }
               }
               Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
               m_lInfoIDNumber = (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND) ? STS_ACTION_FAILED_RECORD_MODIFIED : pUpdateStatement->getInfoIDNumber();
               m_iResultCode = STS_QUERY_ERROR;
               return false;
            }

         // If the update failed and the table is an extension of the PHASE or
         // CASE tables, then attempt to insert the row into the table.  The row
         // is most likely missing because the record was added using an older
         // version of the client that did not send in the segment for us to
         // add the row.
         if (pInsertStatement->execute(hTable) == false)
         {
            Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            m_lInfoIDNumber = pInsertStatement->getInfoIDNumber();
            m_iResultCode = STS_QUERY_ERROR;
            return false;
         }
         return true;
      }
   
      Table hEMSCaseDataChg("EMS_DATA_CHG");
      CaseAddEventVisitor hCaseAddEventVisitor(&hEMSCaseDataChg,pInsertStatement.get());
      hEMSCaseDataChg.set("CASE_ID",CaseSegment::instance()->getCASE_ID(),true);
      hEMSCaseDataChg.set("USER_ID",CommonHeaderSegment::instance()->getUserID().c_str());
      hEMSCaseDataChg.set("TSTAMP_CREATED",Transaction::instance()->getTimeStamp());
      hTable.accept(hCaseAddEventVisitor);
      if (!hCaseAddEventVisitor.successful())
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         m_lInfoIDNumber = STS_DATABASE_FAILURE;
         m_iResultCode = STS_QUERY_ERROR;
         return false;
      }
   }
   return true;
  //## end emscommand::CaseUpdateCommand::updateSegment%3EC908DD0222.body
}

bool CaseUpdateCommand::checkUserAccess (const string &strValidUser)
{
  //## begin emscommand::CaseUpdateCommand::checkUserAccess%652D637E01A7.body preserve=yes
   string strUSER_ID(CommonHeaderSegment::instance()->getUserID());
   string strCUST_ID(CommonHeaderSegment::instance()->getCUST_ID());
   CommonHeaderSegment::instance()->setUserID(strValidUser);
   CommonHeaderSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   char cRole = command::DNSecurity::instance()->getUserRole((PersistentSegment*)CaseSegment::instance());
   CommonHeaderSegment::instance()->setUserID(strUSER_ID);
   CommonHeaderSegment::instance()->setCUST_ID(strCUST_ID);
   return (cRole != 'N');
  //## end emscommand::CaseUpdateCommand::checkUserAccess%652D637E01A7.body
}

// Additional Declarations
  //## begin emscommand::CaseUpdateCommand%35ACB26A01AB.declarations preserve=yes
  //## end emscommand::CaseUpdateCommand%35ACB26A01AB.declarations
} // namespace emscommand

//## begin module%35ACB5CF0114.epilog preserve=yes
//## end module%35ACB5CF0114.epilog
