//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%37345373004E.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%37345373004E.cm

//## begin module%37345373004E.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%37345373004E.cp

//## Module: CXOSEC07%37345373004E; Package specification
//## Subsystem: ECDLL%394E1F94006B
//## Source file: C:\Devel\Dn\Server\Library\Ecdll\CXODEC07.hpp

#ifndef CXOSEC07_h
#define CXOSEC07_h 1

//## begin module%37345373004E.additionalIncludes preserve=no
//## end module%37345373004E.additionalIncludes

//## begin module%37345373004E.includes preserve=yes
// $Date:   Apr 09 2004 12:32:50  $ $Author:   D02405  $ $Revision:   1.5  $
//## end module%37345373004E.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Foundation::Segment_CAT%3471F0BE0219
namespace segment {
class ResponseTimeSegment;
class ListSegment;
} // namespace segment

//## Modelname: Connex Foundation::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Queue;
class Message;
} // namespace IF

//## Modelname: Connex Foundation::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

namespace segment {
class CommonHeaderSegment;
class InformationSegment;
} // namespace segment

namespace database {
class Database;
} // namespace database

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseCommentSegment;

} // namespace emssegment

//## begin module%37345373004E.declarations preserve=no
//## end module%37345373004E.declarations

//## begin module%37345373004E.additionalDeclarations preserve=yes
//## end module%37345373004E.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
//## begin emscommand%394E266C015B.initialDeclarations preserve=yes
//## end emscommand%394E266C015B.initialDeclarations

//## begin emscommand::CaseCommentCreateCommand%37344F960363.preface preserve=yes
//## end emscommand::CaseCommentCreateCommand%37344F960363.preface

//## Class: CaseCommentCreateCommand%37344F960363
//	QEMCCOM - add comments to an EMS case.
//## Category: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
//## Subsystem: ECDLL%394E1F94006B
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3736E667033A;database::Database { -> F}
//## Uses: <unnamed>%3736E66A00F0;IF::Message { -> F}
//## Uses: <unnamed>%3736E66C0319;IF::Queue { -> F}
//## Uses: <unnamed>%37384FA70369;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%37384FAA0165;segment::InformationSegment { -> F}
//## Uses: <unnamed>%37384FAD032C;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%37384FBE011E;reusable::Query { -> F}
//## Uses: <unnamed>%37384FCF03C1;reusable::Statement { -> F}
//## Uses: <unnamed>%3738508C037D;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%37385229024A;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%373C72F301D6;timer::Clock { -> F}
//## Uses: <unnamed>%378CE1A7035E;emssegment::CaseCommentSegment { -> F}
//## Uses: <unnamed>%3A4263BD01DF;monitor::UseCase { -> F}
//## Uses: <unnamed>%3E316BEC0138;ems::CaseNotification { -> F}

class DllExport CaseCommentCreateCommand : public command::ClientCommand  //## Inherits: <unnamed>%37344FB30102
{
  //## begin emscommand::CaseCommentCreateCommand%37344F960363.initialDeclarations preserve=yes
  //## end emscommand::CaseCommentCreateCommand%37344F960363.initialDeclarations

  public:
    //## Constructors (generated)
      CaseCommentCreateCommand();

    //## Constructors (specified)
      //## Operation: CaseCommentCreateCommand%37345D4E02C3
      CaseCommentCreateCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~CaseCommentCreateCommand();


    //## Other Operations (specified)
      //## Operation: execute%37345D7D0085
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%37345D800242
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin emscommand::CaseCommentCreateCommand%37344F960363.public preserve=yes
      //## end emscommand::CaseCommentCreateCommand%37344F960363.public

  protected:
    // Additional Protected Declarations
      //## begin emscommand::CaseCommentCreateCommand%37344F960363.protected preserve=yes
      //## end emscommand::CaseCommentCreateCommand%37344F960363.protected

  private:
    // Additional Private Declarations
      //## begin emscommand::CaseCommentCreateCommand%37344F960363.private preserve=yes
      //## end emscommand::CaseCommentCreateCommand%37344F960363.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Foundation::Command_CAT::<unnamed>%37384F790237
      //## Role: CaseCommentCreateCommand::<m_pListSegment>%37384F7A02CE
      //## begin emscommand::CaseCommentCreateCommand::<m_pListSegment>%37384F7A02CE.role preserve=no  public: segment::ListSegment { -> RFHgN}
      segment::ListSegment *m_pListSegment;
      //## end emscommand::CaseCommentCreateCommand::<m_pListSegment>%37384F7A02CE.role

    // Additional Implementation Declarations
      //## begin emscommand::CaseCommentCreateCommand%37344F960363.implementation preserve=yes
      //## end emscommand::CaseCommentCreateCommand%37344F960363.implementation

};

//## begin emscommand::CaseCommentCreateCommand%37344F960363.postscript preserve=yes
//## end emscommand::CaseCommentCreateCommand%37344F960363.postscript

} // namespace emscommand

//## begin module%37345373004E.epilog preserve=yes
using namespace emscommand;
//## end module%37345373004E.epilog


#endif
