   char sDateTime[16];
   char sDateCC[2];
      // |<tr><td>ACQ_PLAT_PROD_ID     <td>'B'
   m_hFinancialBaseSegment.setACQ_PLAT_PROD_ID("B",1);
      // |<tr><td>AUTH_BY     <td>cResponder
   switch (pB24Record->cResponder)
   {
      case '1':
      case '2':
         m_hFinancialBaseSegment.setAUTH_BY("A",1);
         break;
      case '3':
      case '4':
      case '6':
         m_hFinancialBaseSegment.setAUTH_BY("S",1);
         break;
      case '5':
         m_hFinancialBaseSegment.setAUTH_BY("I",1);
         break;
      case '7':
         m_hFinancialBaseSegment.setAUTH_BY("N",1);
         break;
   }
      // |<tr><td>BRANCH_ID_ACQ     <td>sBrchId
   m_hFinancialAdjustmentSegment.setBRANCH_ID_ACQ(pB24Record->sBrchId,4);
      // |<tr><td>CARD_SEQ_NO    <td>sCrdMbrNum
   m_hFinancialBaseSegment.setCARD_SEQ_NO(pB24Record->sCrdMbrNum,3);
      // |<tr><td>CNV_RCN_NET_DE_POS      <td>sMultCrncyAuthConvRate 1+7
   m_hFinancialSettlementSegment.setCNV_RCN_NET_DE_POS(pB24Record->sMultCrncyAuthConvRate,1);
   m_hFinancialSettlementSegment.setCNV_RCN_NET_RATE (pB24Record->sMultCrncyAuthConvRate+1,7);
      // |<tr><td>CUR_CARD_BILL     <td>sOrigCrncyCde
   m_hFinancialBaseSegment.setCUR_CARD_BILL(pB24Record->sOrigCrncyCde,3);
      // |<tr><td>CUR_RECON_NET     <td>sOrigCrncyCde
   m_hFinancialBaseSegment.setCUR_RECON_NET(pB24Record->sOrigCrncyCde,3);
      // |<tr><td>CUR_TRAN    <td>sOrigCrncyCde
   m_hFinancialBaseSegment.setCUR_TRAN(pB24Record->sOrigCrncyCde,3);
      // |<tr><td>CUR_RECON_ACQ     <td>sOrigCrncyCde
   m_hFinancialSettlementSegment.setCUR_RECON_ACQ(pB24Record->sOrigCrncyCde,3);
      // |<tr><td>CUR_RECON_ISS     <td>sOrigCrncyCde
   m_hFinancialSettlementSegment.setCUR_RECON_ISS(pB24Record->sOrigCrncyCde,3);
      //|<tr><td>DATA_PRIV_ACQ_FMT          <td>77
   m_hFinancialSettlementSegment.setDATA_PRIV_ACQ_FMT(77);
      // |<tr><td>DATE_RECON_ACQ          <td>sAcqIchgSetlDatYY+8
   memset(sDateTime, ' ',sizeof(sDateTime));
   DateTime::calcCentury(pB24Record->sAcqIchgSetlDatYY,sDateCC);
   memcpy(sDateTime,sDateCC,2);
   memcpy(sDateTime+2,pB24Record->sAcqIchgSetlDatYY,6);
   if (memcmp(sDateTime,"00000000",8)== 0)
   {
      DateTime::calcCentury(pB24Record->sPostDatYY,sDateCC);
      memcpy(sDateTime,sDateCC,2);
      memcpy(sDateTime+2,pB24Record->sPostDatYY,6);
   }
   m_hFinancialBaseSegment.setDATE_RECON_ACQ(sDateTime,8);
      // |<tr><td>DATE_RECON_ISS          <td>sIssIchgSetlDatYY
   memset(sDateTime, ' ',sizeof(sDateTime));
   DateTime::calcCentury(pB24Record->sIssIchgSetlDatYY,sDateCC);
   memcpy(sDateTime,sDateCC,2);
   memcpy(sDateTime+2,pB24Record->sIssIchgSetlDatYY,6);
   m_hFinancialSettlementSegment.setDATE_RECON_ISS(sDateTime,8);
      // |<tr><td>DATE_RECON_NET          <td>sPostDatYY+8
   memset(sDateTime, ' ',sizeof(sDateTime));
   DateTime::calcCentury(pB24Record->sPostDatYY,sDateCC);
   memcpy(sDateTime,sDateCC,2);
   memcpy(sDateTime+2,pB24Record->sPostDatYY,6);
   m_hFinancialUserSegment.setDATE_RECON_NET(sDateTime,8);
      // |<tr><td>FIN_TYPE          <td>sRecTyp
   if (memcmp(pB24Record->sRecTyp, "01",2) == 0)
   {
      if (m_bReversal)
         m_hFinancialBaseSegment.setFIN_TYPE("020",3);
      else
         m_hFinancialBaseSegment.setFIN_TYPE("010",3);
   }
   else
      m_hFinancialBaseSegment.setFIN_TYPE("080",3);
      // |<tr><td>INST_ID_ACQ          <td>sAcqInstIdNum
   m_hFinancialBaseSegment.setINST_ID_ACQ(pB24Record->sAcqInstIdNum,sizeof(pB24Record->sAcqInstIdNum));
      // |<tr><td>INST_ID_ISS          <td>sRcvInstIdNum
   m_hFinancialBaseSegment.setINST_ID_ISS(pB24Record->sRcvInstIdNum,sizeof(pB24Record->sRcvInstIdNum));
      // |<tr><td>INST_ID_RECON_ACQ          <td>sTermId
   m_hFinancialBaseSegment.setINST_ID_RECON_ACQ(pB24Record->sTermFiid,sizeof(pB24Record->sTermFiid));
      // |<tr><td>INST_ID_RECON_ISS    <td>sCrdFiid
   m_hFinancialBaseSegment.setINST_ID_RECON_ISS(pB24Record->sCrdFiid,sizeof(pB24Record->sCrdFiid));
      // |<tr><td>INST_ID_RECN_ISS_B    <td>sCrdFiid
   m_hFinancialBaseSegment.setINST_ID_RECN_ISS_B(pB24Record->sCrdFiid,sizeof(pB24Record->sCrdFiid));
   // |<tr><td>MTI          <td>sTyp
   if (memcmp(pB24Record->sTyp,"0110",4) == 0)
      m_hFinancialSettlementSegment.setMTI("1110",4);
   else if (memcmp(pB24Record->sTyp,"0120",4) == 0)
      m_hFinancialSettlementSegment.setMTI("1140",4);
   else if (memcmp(pB24Record->sTyp,"0210",4) == 0)
      m_hFinancialSettlementSegment.setMTI("1210",4);
   else if (memcmp(pB24Record->sTyp,"0220",4) == 0)
      m_hFinancialSettlementSegment.setMTI("1240",4);
   else if (memcmp(pB24Record->sTyp,"0420",4) == 0)
      m_hFinancialSettlementSegment.setMTI("1440",4);
      // |<tr><td>ODE_TSTAMP_LOCL_TR          <td>sAcqIchgSetlDatYY
   memset(sDateTime, ' ',sizeof(sDateTime));
   if (memcmp(pB24Record->sOrigTranDat,"    ",4) != 0)
   {
      if (memcmp(pB24Record->sOrigB24PostDat,pB24Record->sTranDatYY,2) == 0)
         memcpy(sDateTime,pB24Record->sTranDatYY,2);// take the year from tstamp_local
      else
      {
         char sYY[3] = {"  "};
         memcpy(sYY,pB24Record->sTranDatYY,2);// take the year from tstamp_local
         snprintf(sDateTime,sizeof(sDateTime),"%02d",atoi(sYY)-1);  // previous year
      }
      memcpy(sDateTime+2,pB24Record->sOrigTranDat,4);
      DateTime::calcCentury(sDateTime,sDateCC);
      memcpy(sDateTime,sDateCC,2);
      memcpy(sDateTime+2,pB24Record->sOrigTranDat,4);
      memcpy(sDateTime+8,pB24Record->sOrigTranTimHH,6);
      m_hFinancialReversalSegment.setODE_TSTAMP_LOCL_TR(sDateTime,14);
   }
      // |<tr><td>ODE_SYS_TRA_AUD_NO          <td>sOrigSeqNum+6
   m_hFinancialReversalSegment.setODE_SYS_TRA_AUD_NO(pB24Record->sOrigSeqNum,6);
      // |<tr><td>PAN          <td>sCrdPan
   if (Customer::instance()->getTest())
      memcpy(pB24Record->sCrdPan + 6,"999999",6);
   m_hFinancialBaseSegment.setPAN(pB24Record->sCrdPan,sizeof(pB24Record->sCrdPan));
      // |<tr><td>PROC_ID_ACQ          <td>sTermId
   m_hFinancialBaseSegment.setPROC_ID_ACQ(pB24Record->sTermFiid,sizeof(pB24Record->sTermFiid));
      // |<tr><td>PROC_ID_ACQ_B          <td>PROC_ID_ACQ
   m_hFinancialBaseSegment.setPROC_ID_ACQ_B(pB24Record->sTermFiid,sizeof(pB24Record->sTermFiid));
      // |<tr><td>PROC_ID_ISS    <td>sCrdFiid
   m_hFinancialBaseSegment.setPROC_ID_ISS(pB24Record->sCrdFiid,sizeof(pB24Record->sCrdFiid));
      // |<tr><td>PROC_ID_ISS_B    <td>PROC_ID_ISS
   m_hFinancialBaseSegment.setPROC_ID_ISS_B(pB24Record->sCrdFiid,sizeof(pB24Record->sCrdFiid));
      //|<tr><td>REF_DATA_ACQ_FMT          <td>4
   m_hFinancialSettlementSegment.setREF_DATA_ACQ_FMT(4);
      // |<tr><td>RPT_LVL_ID_B          <td>INST_ID_RECON_ACQ
   m_hFinancialBaseSegment.setRPT_LVL_ID_B(pB24Record->sTermFiid,sizeof(pB24Record->sTermFiid));
      // |<tr><td>REV_BY          <td>cOriginator
   if (m_bReversal)
   {
      switch (pB24Record->cOriginator)
      {
         case '1':
         case '2':
            m_hFinancialBaseSegment.setREV_BY("A",1);
            break;
         case '3':
         case '4':
         case '6':
            m_hFinancialBaseSegment.setREV_BY("S",1);
            break;
         case '5':
            m_hFinancialBaseSegment.setREV_BY("I",1);
            break;
         case '7':
            m_hFinancialBaseSegment.setREV_BY("N",1);
            break;
      }
   }
      // |<tr><td>SUBSCRIBER_IND          <td>'Y'
   m_hFinancialBaseSegment.setSUBSCRIBER_IND("Y",1);
      // |<tr><td>TSTAMP_LOCAL          <td>sTranDatYY+14
   memset(sDateTime, ' ',sizeof(sDateTime));
   DateTime::calcCentury(pB24Record->sTranDatYY,sDateCC);
   memcpy(sDateTime,sDateCC,2);
   memcpy(sDateTime+2,pB24Record->sTranDatYY,12);
   m_hFinancialBaseSegment.setTSTAMP_LOCAL(sDateTime,14);
   IString strTstampTrans1;
   DateTime hDateTime1;
   unsigned int iB24Time1=ntohl(pB24Record->lEntryTim[0]);
   unsigned int iB24Time2=ntohl(pB24Record->lEntryTim[1]);
   if (iB24Time1 != 0)
      hDateTime1.setFromB24(iB24Time1,iB24Time2,strTstampTrans1);
   if (strTstampTrans1.data()[0] == '1' || strTstampTrans1.size() != 16 )
      return false;
   string strGMT(strTstampTrans1,16);
   if (m_iGMTOffset != 0)
#ifdef MVS
      GMT::instance()->asLocal(strGMT,m_iGMTOffset,m_bDST,m_strDSTBeginEnd.c_str());
#else
      Timestamp::gmtToLocal(strGMT);
#endif
      // |<tr><td>TSTAMP_TRANS          <td>lEntryTim[0]
   m_hFinancialBaseSegment.setTSTAMP_TRANS(strGMT.data(),16);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strGMT.substr(8,8);
      m_hFinancialBaseSegment.setTSTAMP_TRANS(strTemp.data(),16);
      char sLocalTimestamp[14];
      memcpy(sLocalTimestamp,m_hFinancialBaseSegment.zTSTAMP_LOCAL(),14);
      memcpy(sLocalTimestamp,getTestDate().data(),8);
      m_hFinancialBaseSegment.setTSTAMP_LOCAL(sLocalTimestamp,14);
   }
   IString strTstampEntryTim, strTstampReEntryTim, strTstampExitTim;
   DateTime hEntryTime, hReEntryTime, hExitTime;
   hEntryTime.setFromB24(ntohl(pB24Record->lEntryTim[0]),
      ntohl(pB24Record->lEntryTim[1]),strTstampEntryTim);
   hReEntryTime.setFromB24(ntohl(pB24Record->lReEntryTim[0]),
      ntohl(pB24Record->lReEntryTim[1]),strTstampReEntryTim);
   hExitTime.setFromB24(ntohl(pB24Record->lExitTim[0]),
      ntohl(pB24Record->lExitTim[1]),strTstampExitTim);
      // |<tr><td>TIME_AT_ISS          <td>lEntryTim , lReEntryTime
   m_hFinancialSettlementSegment.setTIME_AT_ISS(
      (short)hEntryTime.calcQueueTime(hReEntryTime));
      // |<tr><td>TIME_AT_RESP_QUE     <td>lReEntryTim, lExitTime
   m_hFinancialSettlementSegment.setTIME_AT_RESP_QUE(
      (short)hReEntryTime.calcQueueTime(hExitTime));
      // |<tr><td>TIME_AT_RQST_QUE     <td>lEntryTim, lExitTime
   m_hFinancialSettlementSegment.setTIME_AT_RQST_QUE(
      (short)hEntryTime.calcQueueTime(hExitTime));
      // |<tr><td>NET_TERM_ID          <td>sTermId
   m_hFinancialBaseSegment.setNET_TERM_ID(pB24Record->sTermId,8);
      // |<tr><td>DATE_CAPTURE          <td>sAcqIchgSetlDatMM+4
   m_hFinancialUserSegment.setDATE_CAPTURE(pB24Record->sAcqIchgSetlDatMM,4);   // MMDD
      // |<tr><td>INST_ID_RECN_ACQ_B      <td>INST_ID_RECN_ACQ
   m_hFinancialBaseSegment.setINST_ID_RECN_ACQ_B(pB24Record->sTermFiid,sizeof(pB24Record->sTermFiid));
      // |<tr><td>PROC_GRP_ID_ACQ_B      <td>Customer
   m_hFinancialBaseSegment.setPROC_GRP_ID_ACQ_B(Customer::instance()->getCUST_ID().data(),4);
      // |<tr><td>PROC_GRP_ID_ISS_B      <td>Customer
   m_hFinancialBaseSegment.setPROC_GRP_ID_ISS_B(Customer::instance()->getCUST_ID().data(),4);
      // |<tr><td>COUNTRY_CODE        <td>COUNTRY_CODE2to3[strCountry2]
   strTranslateInValue.assign(pB24Record->sTermCntryCde,2);
   strTranslateOutValue.assign(pB24Record->sTermCntryCde,2);
   ConfigurationRepository::instance()->translate("COUNTRY_CODE2to3",
      strTranslateInValue,strTranslateOutValue ," "," ",-1,false);
   m_hFinancialBaseSegment.setCARD_ACPT_COUNTRY(strTranslateOutValue.data(),3);
      // |<tr><td>COUNTRY_ACQ_INST     <td>sTermCntryCde
   m_hFinancialBaseSegment.setCOUNTRY_ACQ_INST(strTranslateOutValue.data()+3,3);
      // |<tr><td>MSG_RESON_CODE_ACQ          <td>X_B24_REV_CODE[sRvrlCde]
   if (m_bReversal)
   {
      strTranslateInValue.assign(pB24Record->sRvrlCde,2);
      strTranslateOutValue.erase();
      if (ConfigurationRepository::instance()->translate
         ("X_B24_REV_CODE",strTranslateInValue,strTranslateOutValue,
         "FIN_RECORD", "MSG_RESON_CODE_ACQ", 0))
      {
         m_hFinancialBaseSegment.setMSG_RESON_CODE_ACQ(strTranslateOutValue.data(),4);
      }
   }
   // eye catcher
   //REF_DATA_ACQ   and ADL_DATA_PRIV_ACQ memset and populate for later use
   char sREF_DATA_ACQ[99];
   char sADL_DATA_PRIV_ACQ[255];
   memset(sADL_DATA_PRIV_ACQ,' ',sizeof(sADL_DATA_PRIV_ACQ));
   memset(sREF_DATA_ACQ,' ',sizeof(sREF_DATA_ACQ));
   struct visasms::segADL_DATA_PRIV_ACQ* pADL_DATA_PRIV_ACQ_sms =
      (struct visasms::segADL_DATA_PRIV_ACQ*)sADL_DATA_PRIV_ACQ;
   struct visasms::segREF_DATA_ACQ* pREF_DATA_ACQ_sms =
      (struct visasms::segREF_DATA_ACQ*)sREF_DATA_ACQ;
   memcpy(sADL_DATA_PRIV_ACQ,"VP",2);
   m_hFinancialBaseSegment.setPOS_CRDHLDR_A_METH("0",1);


#ifdef MVS
   CodeTable::translate(pEyeCatcher->sEyeCatcher,2,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   if (pEyeCatcher->sEyeCatcher[0] == '&')
   {
      short siWorkingLength = 0;

      hTokenHeader* pTokenHeader = (hTokenHeader*)(char*)pEyeCatcher;
      short siDataLength = ntohs(pTokenHeader->siTokenDataLength);
      pEyeCatcher = (hFinancialSegEyeCatcher*)((char*)pEyeCatcher + 6);
      siDataLength -= 6;
      while (siDataLength > 0)
      {
#ifdef MVS
         CodeTable::translate(pEyeCatcher->sEyeCatcher,4,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
         if (pEyeCatcher->sEyeCatcher[0] == '!')
         {
            short siTokenLength = ntohs(pEyeCatcher->siTokenLength);
#ifdef MVS
            if (memcmp(pEyeCatcher->sToken,"25",2) == 0
               || memcmp(pEyeCatcher->sToken,"30",2) == 0
               || memcmp(pEyeCatcher->sToken,"B2",2) == 0
               || memcmp(pEyeCatcher->sToken,"B3",2) == 0
               || memcmp(pEyeCatcher->sToken,"BD",2) == 0
               || memcmp(pEyeCatcher->sToken,"BE",2) == 0
               || memcmp(pEyeCatcher->sToken,"PB",2) == 0
               || memcmp(pEyeCatcher->sToken,"PK",2) == 0
               || memcmp(pEyeCatcher->sToken,"PL",2) == 0
               || memcmp(pEyeCatcher->sToken,"PN",2) == 0)
               ;
            else
               CodeTable::translate(pEyeCatcher->sTokenValue,siTokenLength,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
            string strTemp(pEyeCatcher->sTokenValue,siTokenLength);
            if (memcmp(pEyeCatcher->sToken,"09",2) == 0)
            {
               //      N/A
            }
            else if (memcmp(pEyeCatcher->sToken,"13",2) == 0)
            {
               m_hFinancialUserSegment.setACCT_TYPE_1(strTemp.data(),siTokenLength > 4   ?   4 : siTokenLength);
            }
            else if (memcmp(pEyeCatcher->sToken,"17",2) == 0)
            {
               //17 PTLF    TRAN-ID                                  sTRAN_IDENTIFIER   (offset 30 of REF_DATA_ACQ)
               //17 PTLF    MKT-SPFC-DATA-ID                         cMARKET_FLG (offset   14   of   ADL_DATA_PRIV_ACQ)
               memcpy(pREF_DATA_ACQ_sms->sTRAN_IDENTIFIER,
                  strTemp.data()+1,siTokenLength >   sizeof(pREF_DATA_ACQ_sms->sTRAN_IDENTIFIER) ?
siTokenLength :   sizeof(pREF_DATA_ACQ_sms->sTRAN_IDENTIFIER));
               m_hFinancialSettlementSegment.setREF_DATA_ACQ(sREF_DATA_ACQ,sizeof(struct visasms::segREF_DATA_ACQ));
               m_hFinancialSettlementSegment.setADL_DATA_PRIV_ACQ(sADL_DATA_PRIV_ACQ,
                  sizeof(struct visasms::segADL_DATA_PRIV_ACQ)   );
            }
            else if (memcmp(pEyeCatcher->sToken,"18",2) == 0)
            {
               m_hFinancialSettlementSegment.setACCT_QUAL_1(strTemp.data(),3);
               m_hFinancialSettlementSegment.setACCT_QUAL_2(strTemp.data()+3,3);
            }
            else if (memcmp(pEyeCatcher->sToken,"19",2) == 0)
            {
               //19 PTLF    PUR-ID     1+25                          sPURCHASE_IND (offset   19   of   ADL_DATA_PRIV_ACQ)
               //19 PTLF    CHK-DAT    6                                cCheck_In_Out_Date   (offset 44 of ADL_DATA_PRIV_ACQ)
               //19 PTLF    NO-SHW-IND       1                          cNo_Show_Ind   (offset 50 of ADL_DATA_PRIV_ACQ)
               //19 PTLF    EXTRA-CHRGS    6                          sEXTRA_CHARGES_IND   (offset 51 of ADL_DATA_PRIV_ACQ)
               memcpy(&pADL_DATA_PRIV_ACQ_sms->cPRCH_ID_FRMT_FLG,strTemp.data(),1);
               memcpy(pADL_DATA_PRIV_ACQ_sms->sPURCHASE_IND,strTemp.data()+1,25);
               memcpy(pADL_DATA_PRIV_ACQ_sms->sEventDate,strTemp.data()+26,6);
               memcpy(&pADL_DATA_PRIV_ACQ_sms->cNo_Show_Ind,strTemp.data()+31,1);
               memcpy(pADL_DATA_PRIV_ACQ_sms->sEXTRA_CHARGES_IND,strTemp.data()+32,6);
               m_hFinancialSettlementSegment.setADL_DATA_PRIV_ACQ(sADL_DATA_PRIV_ACQ,
                  sizeof(struct visasms::segADL_DATA_PRIV_ACQ)   );
               //19 PTLF    MULT-CLRNG-SEQ-NUM     2                 sMULTI_CLR_SEQ_NO (offset 45 of REF_DATA_ACQ)
               //19 PTLF    MULT-CLRNG-SEQ-CNT     2                 sMULTI_CLR_SEQ_CNT   (offset 47 of REF_DATA_ACQ)
               //19 PTLF    RSTRCTD-TCKT-IND    1                       cRestr_Ticket_Ind (offset 57 of ADL_DATA_PRIV_ACQ)
               //19 PTLF    RQSTD-PYMNT-SRVC     1                    cREQ_PAYM_SERV_IND   (offset 58 of ADL_DATA_PRIV_ACQ)
               //19 PTLF    CHRGBCK-RGHTS   IND  2                    sCHB_RIGHTS_IND   (offset 59 of ADL_DATA_PRIV_ACQ)
               memcpy(&pADL_DATA_PRIV_ACQ_sms->cRestr_Ticket_Ind,strTemp.data()+42,1);
               memcpy(&pADL_DATA_PRIV_ACQ_sms->cREQ_PAYM_SERV_IND,strTemp.data()+54,1);
               memcpy(pADL_DATA_PRIV_ACQ_sms->sCHB_RIGHTS_IND,strTemp.data()+55,2);
               m_hFinancialSettlementSegment.setREF_DATA_ACQ(sREF_DATA_ACQ,sizeof(struct visasms::segREF_DATA_ACQ));
            }
            else if (memcmp(pEyeCatcher->sToken,"20",2) == 0)
            {
               //20 PTLF    LIFE-CYCLE-IND                         AUTH_LCYCLE_TCODE
               m_hFinancialUserSegment.setAUTH_LCYCLE_TCODE(strTemp.data(),1);
            }
            else if (memcmp(pEyeCatcher->sToken,"21",2) == 0)
            {
               //21 TLF       TRAN-ID                                  sTRAN_IDENTIFIER   (offset 30 of REF_DATA_ACQ)
               memcpy(pREF_DATA_ACQ_sms->sTRAN_IDENTIFIER,strTemp.data(),
                  siTokenLength > sizeof(pREF_DATA_ACQ_sms->sTRAN_IDENTIFIER) ?
                  siTokenLength :
                  sizeof(pREF_DATA_ACQ_sms->sTRAN_IDENTIFIER));
               m_hFinancialSettlementSegment.setREF_DATA_ACQ(sREF_DATA_ACQ,sizeof(struct visasms::segREF_DATA_ACQ));
            }
            else if ( (memcmp(pEyeCatcher->sToken,"24",2) == 0) && m_bExpirationDate)
            {
               //24 TLF       EXP-DAT                                  DATE_EXP (optional)
               m_hFinancialSettlementSegment.setDATE_EXP(strTemp.data(),siTokenLength > 4 ? 4 : siTokenLength);
               m_hFinancialBaseSegment.setDATE_EXP(strTemp);
            }
            else if (memcmp(pEyeCatcher->sToken,"25",2) == 0)
            {
               //25 GEN       TRAN-FEE                               F_AMT_RECON_NET0; set F_TYPE0 =   �70� and   set F_MEMO0   = �N'.
               struct hAmount1
               {
                  int lAmt1[2];
                  int lAmt2[2];
                  char sOtherData1[6];
                  int lOtherAmt[2];
                  char sOtherData2[4];
               };
               hAmount1   * pAmount= (hAmount1*)((char *)pEyeCatcher->sTokenValue);
               double dAmt1 =   Segment::lltof(ntohl(pAmount->lAmt1[0]),ntohl(pAmount->lAmt1[1]));
               applyBounds(dAmt1);
               double dAmt2 =   Segment::lltof(ntohl(pAmount->lAmt2[0]),ntohl(pAmount->lAmt2[1]));
               applyBounds(dAmt2);
               m_hFinancialSettlementSegment.setF_AMT_RECON_NETn(m_bReversal ? dAmt2 :   dAmt1,0);
               m_hFinancialSettlementSegment.setF_TYPEn("70",2,0);
               m_hFinancialSettlementSegment.setF_MEMOn("N",1,0);
            }
            else if (memcmp(pEyeCatcher->sToken,"27",2) == 0)
            {
               m_hFinancialBaseSegment.setCARD_ACPT_PST_CODE(strTemp.data(),siTokenLength   > 10 ? 10 :   siTokenLength );
            }
            else if (memcmp(pEyeCatcher->sToken,"30",2) == 0)
            {
               //30 GEN       TRAN-FEE    ???      Issuer fee   amt or rebate fee   amt (more analysis needed)
            }
            else if (memcmp(pEyeCatcher->sToken,"A6",2) == 0)
            {
               //A6 TLF       LIFE-CYCLE-IND                         AUTH_LCYCLE_TCODE
               m_hFinancialUserSegment.setAUTH_LCYCLE_TCODE(strTemp.data(),1);
            }
            else if (memcmp(pEyeCatcher->sToken,"AB",2) == 0)
            {
               //AB TLF       ACCT-CRNCY-CDE                         CUR_CARD_BILL   CUR_RECON_NET
               //AB TLF       TXN-CRNCY-CDE                            CUR_TRAN
               m_hFinancialBaseSegment.setCUR_CARD_BILL(strTemp.data()+34,3);
               m_hFinancialBaseSegment.setCUR_RECON_NET(strTemp.data()+34,3);
               m_hFinancialBaseSegment.setCUR_TRAN(strTemp.data()+37,3);
            }
            else if (memcmp(pEyeCatcher->sToken,"B9",2) == 0)
            {
               //B9 GEN       ACQ-DESCR-TAG     ISS-DESCR-TAG          TRAN_DESC
               m_hFinancialSettlementSegment.setTRAN_DESC(strTemp.data(),60);
            }
            else if (memcmp(pEyeCatcher->sToken,"BD",2) == 0) // ???
            {
               //BD GEN       TXN-AMT-1                               AMT_TRAN
               //BD GEN       TXN-CRNCY-CDE                            CUR_TRAN
               //BD GEN       CRNCY.AMT-1                            AMT_RECON_ACQ   or   AMT_RECON_ISS
               //BD GEN       CRNCY.CRNCY-CDE                         CUR_RECON_ACQ   or   CUR_RECON_ISS
               //BD GEN       CRNCY.CONV-RATE                         CNV_RCN_ACQ_DE_POS and   RATE or CNV_RCN_ISS_DE_POS   and RATE
               //BD GEN       CRNCY.CONV-DATE                         DATE_CNV_ACQ or DATE_CNV_ISS
               double dAmt1 =0;
               struct hAmount1
               {
                  int lAmt1[2];
               };
               hAmount1   * pAmount= (hAmount1*)((char *)pEyeCatcher->sTokenValue);
               dAmt1   = Segment::lltof(ntohl(pAmount->lAmt1[0]),ntohl(pAmount->lAmt1[1]));
               applyBounds(dAmt1);
               m_hFinancialBaseSegment.setAMT_TRAN(dAmt1);
               m_hFinancialBaseSegment.setCUR_TRAN(strTemp.data()+16,3);
               struct hsLen
               {
                  short   siLen;
               };
               hsLen   * psiLen= (hsLen*)((char *)pEyeCatcher->sTokenValue+30);
               if   ( (psiLen->siLen > 5) && siTokenLength   > (48+6*32))
               {
                  struct hCurrSegArray
                  {
                     int lAmt1[2];
                     int lAmt2[2];
                     char sCurrencyCode[3];
                     char sCurrencyRate[8];
                     char sCurrencyDate[4];
                     char cUserFld2[8];
                  };
                  hCurrSegArray * pCurrArray   = (hCurrSegArray*)((char *)pEyeCatcher->sTokenValue+32+2*32);
                  dAmt1   = Segment::lltof(ntohl(pCurrArray->lAmt1[0]),ntohl(pCurrArray->lAmt1[1]));
                  applyBounds(dAmt1);
                  m_hFinancialSettlementSegment.setAMT_RECON_ACQ(dAmt1);
                  m_hFinancialSettlementSegment.setCUR_RECON_ACQ(pCurrArray->sCurrencyCode,3);
                  m_hFinancialSettlementSegment.setCNV_RCN_ACQ_DE_POS(pCurrArray->sCurrencyRate,1);
                  m_hFinancialSettlementSegment.setCNV_RCN_ACQ_RATE (pCurrArray->sCurrencyRate+1,7);
                  m_hFinancialUserSegment.setDATE_CNV_ACQ(pCurrArray->sCurrencyDate,4);

                  pCurrArray = (hCurrSegArray*)((char   *)pEyeCatcher->sTokenValue+32+5*32);
                  dAmt1   = Segment::lltof(ntohl(pCurrArray->lAmt1[0]),ntohl(pCurrArray->lAmt1[1]));
                  applyBounds(dAmt1);
                  m_hFinancialSettlementSegment.setAMT_RECON_ACQ(dAmt1);
                  m_hFinancialSettlementSegment.setCUR_RECON_ACQ(pCurrArray->sCurrencyCode,3);
                  m_hFinancialSettlementSegment.setCNV_RCN_ACQ_DE_POS(pCurrArray->sCurrencyRate,1);
                  m_hFinancialSettlementSegment.setCNV_RCN_ACQ_RATE (pCurrArray->sCurrencyRate+1,7);
                  m_hFinancialUserSegment.setDATE_CNV_ACQ(pCurrArray->sCurrencyDate,4);
               }
            }
            else if (memcmp(pEyeCatcher->sToken,"BE",2) == 0)
            {
               double dAmt1 =0;
               struct hOrigCurrTokenDef
               {
                  int lAmt1[2];
                  int lAmt2[2];
                  char sCurrencyCode[3];
                  char sConvRate[8];
                  char sConvDate[4];
                  char cUserFld1[8];
               };
               hOrigCurrTokenDef* pOrigCurrTokenDef = (hOrigCurrTokenDef*)((char *)pEyeCatcher->sTokenValue);
               dAmt1 = Segment::lltof(ntohl(pOrigCurrTokenDef->lAmt1[0]),ntohl(pOrigCurrTokenDef->lAmt1[1]));
               applyBounds(dAmt1);
               m_hFinancialBaseSegment.setAMT_TRAN(dAmt1);
#ifdef MVS
               CodeTable::translate(pOrigCurrTokenDef->sCurrencyCode,23,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
               m_hFinancialBaseSegment.setCUR_TRAN(pOrigCurrTokenDef->sCurrencyCode,3);
            }
            else if (memcmp(pEyeCatcher->sToken,"BH",2) == 0)
            {
               //BH GEN       TXN-DATE    TXN-TIM                  MULT-CRNCY-TKN      TSTAMP_REV_CREATED
               m_hFinancialReversalSegment.setTSTAMP_REV_CREATED(strTemp.data(),16);
            }
            else if (memcmp(pEyeCatcher->sToken,"BJ",2) == 0)
            {
               //BJ GEN       All????                                     ICC fields   (needs more   detailed   work)
            }
            else if (memcmp(pEyeCatcher->sToken,"BO",2) == 0)
            {
               //BO GEN       TXN-DL_RESP_AMTn
               //FinancialUserSegment::setADL_RESP_AMTn   0   ???
               //FinancialUserSegment::setADL_RESP_AMTn   1
               /*
               int iAmt= ntohl((int) pEyeCatcher->sTokenValue);
               m_hFinancialUserSegment.setADL_RESP_AMTn(iAmt,0);
               m_hFinancialUserSegment.setADL_RESP_AMT_TYPn("02",2,0);
               iAmt=   ntohl((int)   pEyeCatcher->sTokenValue+sizeof(int));
               m_hFinancialUserSegment.setADL_RESP_AMTn(iAmt,1);
               m_hFinancialUserSegment.setADL_RESP_AMT_TYPn("01",2,1); */
            }
            else if (memcmp(pEyeCatcher->sToken,"BY",2) == 0)
            {
               if ( memcmp(m_strMCIFiid.data(),pB24Record->sTermFiid,m_strMCIFiid.length()) == 0   )
               {
                  m_hFinancialBaseSegment.setRETRIEVAL_REF_NO(strTemp.data()+6,siTokenLength > 18 ?   12   : siTokenLength -   6 );
               }
            }
            else if (memcmp(pEyeCatcher->sToken,"C0",2) == 0)
            {
               //C0 PTLF    MOTO-FLG         sMOTO_IND (offset   91   of   ADL_DATA_PRIV_ACQ)
               memcpy(&pADL_DATA_PRIV_ACQ_sms->sMOTO_IND,strTemp.data()+18,1);
               memcpy(&pADL_DATA_PRIV_ACQ_sms->cCAVV_RESULT,strTemp.data()+25,1);
               m_hFinancialSettlementSegment.setADL_DATA_PRIV_ACQ(sADL_DATA_PRIV_ACQ,
                  sizeof(struct visasms::segADL_DATA_PRIV_ACQ)   );
            }
            else if (memcmp(pEyeCatcher->sToken,"CA",2) == 0)
            {
               //CA PTLF    KEY-SERIAL-NUM                         MAPPED_DUP_DATA
               m_hFinancialBaseSegment.setMAPPED_DUP_DATA(strTemp.data(),siTokenLength   > 20 ? 20 :   siTokenLength );
            }
            else if (memcmp(pEyeCatcher->sToken,"CB",2) == 0)
            {
               //CB PTLF    ACCT-CRNCY-CDE                         CUR_CARD_BILL   CUR_RECON_NET     CUR_TRAN
               m_hFinancialBaseSegment.setCUR_CARD_BILL(strTemp.data()+16,3);
               m_hFinancialBaseSegment.setCUR_RECON_NET(strTemp.data()+16,3);
               m_hFinancialBaseSegment.setCUR_TRAN(strTemp.data()+19,3);
            }
            else if (memcmp(pEyeCatcher->sToken,"CH",2) == 0)
            {
               //CH PTLF    RECUR-PMNT-IND                          (offset 61 of ADL_DATA_PRIV_ACQ)
               memcpy(&pADL_DATA_PRIV_ACQ_sms->cRecurringPaymentIndicator,strTemp.data()+15,1);
               m_hFinancialSettlementSegment.setADL_DATA_PRIV_ACQ(sADL_DATA_PRIV_ACQ,
                  sizeof(struct visasms::segADL_DATA_PRIV_ACQ)   );
            }
            else if (memcmp(pEyeCatcher->sToken,"CI",2) == 0)
            {
               //CI PTLF    E-COMM-GOODS-IND                         sECOM_GOODS_IND (offset 61 of ADL_DATA_PRIV_ACQ)
               memcpy(&pADL_DATA_PRIV_ACQ_sms->sECOM_GOODS_IND,strTemp.data(),2);
               m_hFinancialSettlementSegment.setADL_DATA_PRIV_ACQ(sADL_DATA_PRIV_ACQ,
                  sizeof(struct visasms::segADL_DATA_PRIV_ACQ)   );
            }
            else if (memcmp(pEyeCatcher->sToken,"P6",2) == 0 && m_bReversal == false)
            {
               m_hFinancialSettlementSegment.setCUR_TYPE(1);
               for (int   i = 0;i <= 3;++i)
               {
                  if   (strTemp.length()   >=   2)
                  {
                     m_hFinancialSettlementSegment.setCAN_ITEM_VALUEn(m_hCanisterValues[i],i);
                     m_hFinancialSettlementSegment.setCAN_NO_ITEMS_DISPn(atoi(strTemp.substr(0,2).c_str()),i);
                     strTemp.erase(0,2);
                  }
               }
            }
            else if (memcmp(pEyeCatcher->sToken,"P7",2) == 0)
            {
               //P7 CAVV_RESULT     MCI_UCAF_DATA                     CAVR   UCAF-VALUE
               if (pEyeCatcher->sTokenValue[0] == 'V')
               {
                  m_hFinancialSettlementSegment.setCAVV_RESULT(strTemp.data()+49,1);
               }
               if (pEyeCatcher->sTokenValue[0] == 'M')
               {
                  char sLen[4];
                  memset(sLen,'\0',sizeof(sLen));
                  memcpy(sLen,strTemp.data()+4,2);
                  m_hFinancialSettlementSegment.setMCI_UCAF_DATA (strTemp.data()+6,atoi(sLen));
               }
            }
            else
            if (memcmp(m_sID,"BP03",4) == 0)
            {
               if (memcmp(pEyeCatcher->sToken,"PK",2) == 0)
               {
                  struct hNotes
                  {
                     short siVal;
                     short siCount;
                  };
                  struct hNoteDep
                  {
                     hNotes Notes[5];
                     char sAmt[12];
                  };
                  hNoteDep *pNoteDep = (hNoteDep*)(pEyeCatcher->sTokenValue);
                  CashDepositSegment::instance()->reset();
                  m_hFinancialDepositSegment.setPresence(true);
                  CashDepositSegment::instance()->setPresence(true);
                  m_hFinancialDepositSegment.setDEPOSIT_TYPE("N",1);
                  for(int i = 0; i < 5; i++)
                  {
                     CashDepositSegment::instance()->setITEM_VALUE(ntohs(pNoteDep->Notes[i].siVal));
                     CashDepositSegment::instance()->setITEM_COUNT(ntohs(pNoteDep->Notes[i].siCount));
                     m_hCashDepositSegment.push_back(*(CashDepositSegment::instance()));
                  }
               }
               else if ((memcmp(pEyeCatcher->sToken,"PN",2) == 0))
               {
#ifdef _WIN32
#pragma pack(push)
#endif
#pragma pack(1)
                  struct hCoin
                  {
                     short siVal;
                     int siCount;
                  };
#ifdef MVS
#pragma pack(reset)
#endif
#ifdef _WIN32
#pragma pack(pop)
#endif
#ifdef _UNIX
#pragma pack()
#endif
                  struct hCoinDep
                  {
                     hCoin Coin[6];
                     char sHopperID[6];
                     char sAcceptedAmt[12];
                     char sRejectedAmt[12];
                  };
                  hCoinDep *pCoinDep = (hCoinDep*)(pEyeCatcher->sTokenValue);
                  CashDepositSegment::instance()->reset();
                  m_hFinancialDepositSegment.setPresence(true);
                  CashDepositSegment::instance()->setPresence(true);
                  m_hFinancialDepositSegment.setDEPOSIT_TYPE("C",1);
                  for(int i = 0; i < 6; i++)
                  {
                     CashDepositSegment::instance()->setITEM_VALUE(ntohs(pCoinDep->Coin[i].siVal));
                     CashDepositSegment::instance()->setITEM_COUNT(ntohl(pCoinDep->Coin[i].siCount));
                     m_hCashDepositSegment.push_back(*(CashDepositSegment::instance()));
                  }
#ifdef MVS
                  CodeTable::translate(pCoinDep->sHopperID,30,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
                  m_hFinancialDepositSegment.setHOPPER_ID(pCoinDep->sHopperID,sizeof(pCoinDep->sHopperID));
                  m_hFinancialDepositSegment.setCOINS_REJECTED(atoi(pCoinDep->sRejectedAmt));
               }
               else if ((memcmp(pEyeCatcher->sToken,"PL",2) == 0))
               {
                  struct hCheckDep
                  {
                     short siChqToRtn;
                     short siCount;
                     int iTotalCusAmt[2];
                     char sChequeTotalAmt[12];
                     char  sChequeDetail [4];
                  };
                  struct hChequeDetail
                  {
                     char sChequeAmt[12];
                     char sChqNo[9];
                     char sChqBSB[6];
                     char sChqAccNo[10];
                     char cChqAmtFlg;
                  };

                  hCheckDep *pCheckDep = (hCheckDep*)(pEyeCatcher->sTokenValue);
                  CheckDepositSegment::instance()->reset();
                  m_hFinancialDepositSegment.setPresence(true);
                  CheckDepositSegment::instance()->setPresence(true);
                  hChequeDetail *pChequeDetail = (hChequeDetail*)(pCheckDep->sChequeDetail);

                  m_hFinancialDepositSegment.setDEPOSIT_TYPE("Q",1);
                  m_hFinancialDepositSegment.setCHECKS_ACCEPTED(ntohs(pCheckDep->siCount));
                  m_hFinancialDepositSegment.setCHECKS_RETURNED(ntohs(pCheckDep->siChqToRtn));
                  int iRead = sizeof(hCheckDep) + sizeof(hChequeDetail) - 4;
                  while(iRead <= siTokenLength && pChequeDetail->sChequeAmt[0] != 0x20)
                  {
#ifdef MVS
                     CodeTable::translate(pChequeDetail->sChequeAmt,sizeof(hChequeDetail),CodeTable::CX_ASCII_TO_EBCDIC);
#endif
                     CheckDepositSegment::instance()->setAMT_CHECK(atoi(string(pChequeDetail->sChequeAmt,sizeof(pChequeDetail->sChequeAmt)).c_str()));
                     CheckDepositSegment::instance()->setCHECK_NO(pChequeDetail->sChqNo,sizeof(pChequeDetail->sChqNo));
                     CheckDepositSegment::instance()->setINST_ID_ISS(pChequeDetail->sChqBSB,sizeof(pChequeDetail->sChqBSB));
                     CheckDepositSegment::instance()->setACCT_ID(pChequeDetail->sChqAccNo,sizeof(pChequeDetail->sChqAccNo));
                     CheckDepositSegment::instance()->setAMT_OVERRIDE(&pChequeDetail->cChqAmtFlg,sizeof(pChequeDetail->cChqAmtFlg));
                     m_hCheckDepositSegment.push_back(*(CheckDepositSegment::instance()));
                     pChequeDetail = (hChequeDetail*)((char*)pChequeDetail + sizeof(hChequeDetail));
                     iRead += sizeof(hChequeDetail);
                  }
               }
            }
            siDataLength -= (siTokenLength + 6);
            pEyeCatcher = (hFinancialSegEyeCatcher*)((char*)pEyeCatcher + siTokenLength + 6);
         }
         else
            siDataLength = 0;
      } // end   of   while
   }// end of if Eye Catcher
   Message::instance(Message::INBOUND)->reset("AI LE ","S0002D");
   char *psBuffer = Message::instance(Message::INBOUND)->data();
   m_hAuditSegment.setHashValue(ntohl(pB24Record->lHdrHash[1]));
   m_hAuditSegment.setSourceID(Application::instance()->name());
   m_hAuditSegment.write(&psBuffer);
   m_hFinancialBaseSegment.write(&psBuffer);
   m_hFinancialSettlementSegment.write(&psBuffer);
   m_hFinancialAdjustmentSegment.write(&psBuffer);
   if (m_bReversal)
      m_hFinancialReversalSegment.write(&psBuffer);
   if (m_hIntegratedCircuitCardSegment.presence())
      m_hIntegratedCircuitCardSegment.write(&psBuffer);
   m_hFinancialUserSegment.write(&psBuffer);

   if(m_hFinancialDepositSegment.presence())
   {
      m_hFinancialDepositSegment.write(&psBuffer);
      char* p = psBuffer + 4;
      ListSegment hListSegment;
      hListSegment.write(&psBuffer);
      if(m_hCashDepositSegment.size())
      {
         for(int i = 0; i < m_hCashDepositSegment.size(); i++)
         {
            *(CashDepositSegment::instance()) = m_hCashDepositSegment[i];
            CashDepositSegment::instance()->write(&psBuffer);
         }
         hListSegment.update(p,m_hCashDepositSegment.size(),(int)(psBuffer - p));
         m_hCashDepositSegment.erase(m_hCashDepositSegment.begin(),m_hCashDepositSegment.end());
      }
      else
      {
         for(int i = 0; i < m_hCheckDepositSegment.size(); i++)
         {
            *(CheckDepositSegment::instance()) = m_hCheckDepositSegment[i];
            CheckDepositSegment::instance()->write(&psBuffer);
         }
         hListSegment.update(p,m_hCheckDepositSegment.size(),(int)(psBuffer - p));
         m_hCheckDepositSegment.erase(m_hCheckDepositSegment.begin(),m_hCheckDepositSegment.end());
      }
   }
   ConfigurationRepository::instance()->write(&psBuffer,
      m_hFinancialBaseSegment.zTSTAMP_TRANS(),m_hFinancialBaseSegment.getUNIQUENESS_KEY());
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - Message::instance(Message::INBOUND)->data());
   return true;
