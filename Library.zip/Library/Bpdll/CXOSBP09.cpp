//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%390DAF8E02D1.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%390DAF8E02D1.cm

//## begin module%390DAF8E02D1.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%390DAF8E02D1.cp

//## Module: CXOSBP09%390DAF8E02D1; Package body
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Pvcswork\Dn\Server\Library\BPDLL\CXOSBP09.cpp

//## begin module%390DAF8E02D1.additionalIncludes preserve=no
//## end module%390DAF8E02D1.additionalIncludes

//## begin module%390DAF8E02D1.includes preserve=yes
// $Date:   Apr 09 2004 12:38:40  $ $Author:   D02405  $ $Revision:   1.5  $
#include "CXODIF11.hpp"
//## end module%390DAF8E02D1.includes

#ifndef CXOSBP09_h
#include "CXODBP09.hpp"
#endif
//## begin module%390DAF8E02D1.declarations preserve=no
//## end module%390DAF8E02D1.declarations

//## begin module%390DAF8E02D1.additionalDeclarations preserve=yes
//## end module%390DAF8E02D1.additionalDeclarations


//## Modelname: Platform \: Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

// Class b24messageprocessor::B24PTLFAdmin 



B24PTLFAdmin::B24PTLFAdmin()
  //## begin B24PTLFAdmin::B24PTLFAdmin%390DAE4B0218_const.hasinit preserve=no
  //## end B24PTLFAdmin::B24PTLFAdmin%390DAE4B0218_const.hasinit
  //## begin B24PTLFAdmin::B24PTLFAdmin%390DAE4B0218_const.initialization preserve=yes
   : B24Message("ADMIN","A001")
  //## end B24PTLFAdmin::B24PTLFAdmin%390DAE4B0218_const.initialization
{
  //## begin b24messageprocessor::B24PTLFAdmin::B24PTLFAdmin%390DAE4B0218_const.body preserve=yes
   memcpy(m_sID,"BP09",4);
  //## end b24messageprocessor::B24PTLFAdmin::B24PTLFAdmin%390DAE4B0218_const.body
}


B24PTLFAdmin::~B24PTLFAdmin()
{
  //## begin b24messageprocessor::B24PTLFAdmin::~B24PTLFAdmin%390DAE4B0218_dest.body preserve=yes
  //## end b24messageprocessor::B24PTLFAdmin::~B24PTLFAdmin%390DAE4B0218_dest.body
}



//## Other Operations (implementation)
bool B24PTLFAdmin::insert (Message& hMessage)
{
  //## begin b24messageprocessor::B24PTLFAdmin::insert%390DAEE10282.body preserve=yes
   return true;
  //## end b24messageprocessor::B24PTLFAdmin::insert%390DAEE10282.body
}

void B24PTLFAdmin::translateAscii ()
{
  //## begin b24messageprocessor::B24PTLFAdmin::translateAscii%3916CEF2016D.body preserve=yes
  //## end b24messageprocessor::B24PTLFAdmin::translateAscii%3916CEF2016D.body
}

// Additional Declarations
  //## begin b24messageprocessor::B24PTLFAdmin%390DAE4B0218.declarations preserve=yes
  //## end b24messageprocessor::B24PTLFAdmin%390DAE4B0218.declarations

} // namespace b24messageprocessor

//## begin module%390DAF8E02D1.epilog preserve=yes
//## end module%390DAF8E02D1.epilog
