//	Copyright (c) 1998 - 2012
//	FIS
// $Date:   Feb 01 2012 14:06:24  $ $Author:   e1009839  $ $Revision:   1.15  $

#ifndef CXODBP07_HPP
#define CXODBP07_HPP

#include "CXODRU32.hpp"
struct hB24TLFTransaction
{
 // Standard B24 TLF Header Layout - same for all records from the TLF (ATM) files
   int lHdrHash[2];               // Use second 4 bytes for hashing
   char sRecTyp[2];         // 01, 20, 21, 22
   char sAuthPpd[4];
   char sTermLn[4];
   char sTermFiid[4];
   char sTermId[16];
   char sCrdLn[4];
   char sCrdFiid[4];
   char sCrdPan[19];
   char sCrdMbrNum[3];
   char sBrchId[4];
   char sRegnId[4];
 // B24 TLF Transaction Record Detail
   char sTypCde[2];
   char sTyp[4];
   char sRteStat[2];
   char cOriginator;
   char cResponder;
   unsigned int lEntryTim[2];           // int int in TANDEM format - 64 bit binary
   int lExitTim[2];            // int int in TANDEM format - 64 bit binary
   int lReEntryTim[2];     // int int in TANDEM format - 64 bit binary
   char sTranDatYY[2];
   char sTranDatMM[2];
   char sTranDatDD[2];
   char sTranTimHH[2];
   char sTranTimMM[2];
   char sTranTimSS[2];
   char sTranTimTT[2];
   char sPostDatYY[2];
   char sPostDatMM[2];
   char sPostDatDD[2];
   char sAcqIchgSetlDatYY[2];
   char sAcqIchgSetlDatMM[2];
   char sAcqIchgSetlDatDD[2];
   char sIssIchgSetlDatYY[2];
   char sIssIchgSetlDatMM[2];
   char sIssIchgSetlDatDD[2];
   char sSeqNum[12];
   char sTermTyp[2];
   short siTimOfst;
   char sAcqInstIdNum[11];
   char sRcvInstIdNum[11];
   char sTranCde[2];
   char sTranCdeFrom[2];
   char sTranCdeTo[2];
   char sFromAcctNum[19];
   char cUserFld1;
   char sToAcctNum[19];
   char cMultAcct;
   int lAmt1[2];               // int int in TANDEM format - 64 bit binary
   int lAmt2[2];               // int int in TANDEM format - 64 bit binary
   int lAmt3[2];               // int int in TANDEM format - 64 bit binary
   int lDepBalCr;
   char cDepTyp;
   char sRespCde[3];
   char sTermNameLoc[25];
   char sTermOwnerName[22];
   char sTermCity[13];
   char sTermSt[3];
   char sTermCntryCde[2];
   char sOrigSeqNum[12];
   char sOrigTranDat[4];
   char sOrigTranTimHH[2];
   char sOrigTranTimMM[2];
   char sOrigTranTimSS[2];
   char sOrigTranTimTT[2];
   char sOrigB24PostDat[4];
   char sOrigCrncyCde[3];
   char sMultCrncyAuthCrncyCde[3];
   char sMultCrncyAuthConvRate[8];
   char sMultCrncySetlCrncyCde[3];
   char sMultCrncySetlConvRate[8];
   char sMultCrncyConvDatTim[8];    // int int in TANDEM format - 64 bit binary
   char sRvrlCde[2];
   char sPinOfst[16];
   char cShrgGrp;
   char cDestOrder;
   char sAuthIdResp[6];
   char cRefrImpInd;
   char sRefrAvailImp[2];
   char sRefrLedgImp[2];
   char sRefrHldAmtImp[2];
   char cRefrCafRefrInd;
   char cRefrUserFld3;
   char cDepSetlImpFlg;
   char cAdjSetlImpFlg;
   char cRefrIndPbf1;
   char cRefrIndPbf2;
   char cRefrIndPbf3;
   char cRefrIndPbf4;
   char sUserFld4[16];
   char sFrwdInstIdNum[11];
   char sCrdAccptIdNum[11];
   char sCrdIssIdNum[11];
   //Filler field + Surcharge data token   // TEST CHANGE - extra fields
};
#include "CXODRU33.hpp"
#endif
