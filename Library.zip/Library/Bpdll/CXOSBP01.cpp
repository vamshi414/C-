//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38FB39E702E5.cm preserve=no
//	$Date:   Mar 30 2021 20:03:54  $ $Author:   e1009510  $
//	$Revision:   1.29.1.5  $
//## end module%38FB39E702E5.cm

//## begin module%38FB39E702E5.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%38FB39E702E5.cp

//## Module: CXOSBP01%38FB39E702E5; Package body
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Devel\Dn\Server\Library\BPDLL\CXOSBP01.cpp

//## begin module%38FB39E702E5.additionalIncludes preserve=no
//## end module%38FB39E702E5.additionalIncludes

//## begin module%38FB39E702E5.includes preserve=yes
// $Date:   Mar 30 2021 20:03:54  $ $Author:   e1009510  $ $Revision:   1.29.1.5  $
#ifdef _WIN32
#include <winsock.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#include "CXODRU24.hpp"
#include "CXODIF02.hpp"                  // Log
#include "CXODIF11.hpp"                  // Message
#include "CXODIF16.hpp"                  // Extract
#include "CXODBP02.hpp"                  // B24Message
#include "CXODBP06.hpp"                  // B24LogHeader structure
#include "CXODSI01.hpp"                  // SwitchInterface
#include "CXODSI05.hpp"                  // Hash
#include "CXODDB01.hpp"                  // DataBase
#include "CXODIF03.hpp"
//## end module%38FB39E702E5.includes

#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSBP01_h
#include "CXODBP01.hpp"
#endif


//## begin module%38FB39E702E5.declarations preserve=no
//## end module%38FB39E702E5.declarations

//## begin module%38FB39E702E5.additionalDeclarations preserve=yes
#include "CXODTM12.hpp"
//## end module%38FB39E702E5.additionalDeclarations


//## Modelname: Platform \: ACI Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

// Class b24messageprocessor::B24MessageProcessor 

//## begin b24messageprocessor::B24MessageProcessor::Instance%38FB2C6B0237.attr preserve=no  private: static b24messageprocessor::B24MessageProcessor* {V} 0
b24messageprocessor::B24MessageProcessor* B24MessageProcessor::m_pInstance = 0;
//## end b24messageprocessor::B24MessageProcessor::Instance%38FB2C6B0237.attr

B24MessageProcessor::B24MessageProcessor()
  //## begin B24MessageProcessor::B24MessageProcessor%38FB16B80059_const.hasinit preserve=no
  //## end B24MessageProcessor::B24MessageProcessor%38FB16B80059_const.hasinit
  //## begin B24MessageProcessor::B24MessageProcessor%38FB16B80059_const.initialization preserve=yes
  //## end B24MessageProcessor::B24MessageProcessor%38FB16B80059_const.initialization
{
  //## begin b24messageprocessor::B24MessageProcessor::B24MessageProcessor%38FB16B80059_const.body preserve=yes
   memcpy(m_sID,"BP01",4);
   m_pInstance = this;
  //## end b24messageprocessor::B24MessageProcessor::B24MessageProcessor%38FB16B80059_const.body
}


B24MessageProcessor::~B24MessageProcessor()
{
  //## begin b24messageprocessor::B24MessageProcessor::~B24MessageProcessor%38FB16B80059_dest.body preserve=yes
   m_pInstance = 0;
  //## end b24messageprocessor::B24MessageProcessor::~B24MessageProcessor%38FB16B80059_dest.body
}



//## Other Operations (implementation)
int B24MessageProcessor::dispatch ()
{
  //## begin b24messageprocessor::B24MessageProcessor::dispatch%38FB2C1C00F3.body preserve=yes
   string strMessageID;
   if (m_lFileType == ATM_INPUT)
      strMessageID = "TLF";
   if (m_lFileType == POS_INPUT)
      strMessageID = "PTLF";
   hB24LogHeader* pHeader = (hB24LogHeader*)Message::instance(Message::INBOUND)->data();
#ifdef MVS
      CodeTable::translate(pHeader->sRecTyp,2,
         CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   strMessageID.append(pHeader->sRecTyp,sizeof(pHeader->sRecTyp));
   MessageList::iterator p;
   p = m_hMessages.find(strMessageID);
   Trace::put(strMessageID.c_str());
   if (p != m_hMessages.end())
   {
      B24Message* pMessage = (B24Message*)(*p).second;
      if (pMessage->insert(*Message::instance(Message::INBOUND)))
      {
         if (ConfigurationRepository::instance()->loadFailure())
         {
            Trace::put("call rejectBatch start");
            Hash::instance()->rejectBatch();
         }
         else
         {
            int lRC;
            string strQueueName;
            ((SwitchInterface*)Application::instance())->getLoadEngine(pMessage->getSegmentID(),strQueueName);
            lRC = Message::instance(Message::INBOUND)->send(strQueueName.c_str());
            if (lRC)
            {
               Trace::put("dropLoadEngine");
               ((SwitchInterface*)Application::instance())->dropLoadEngine(strQueueName);
               Hash::instance()->rejectBatch();
            }
            else
            {
               Hash::instance()->incrementTranSentCnt();
               Trace::put("incrementTranSentCnt");
            }
         }
      }
      else
      {
         Hash::instance()->incrementDropTotal(ntohl(pHeader->lHdrHash[1]));
         Trace::put("incrementDropTotal1");
      }
   }
   else
   {
      strMessageID.insert(0,"## BP01 DROP REC TYP ");
      Hash::instance()->incrementDropTotal(ntohl(pHeader->lHdrHash[1]));
      UseCase hUseCase("B24",strMessageID.c_str(),false);
      Trace::put("incrementDropTotal2");
   }
   if (Database::instance()->transactionState() == Database::COMMITREQUIRED)
      Database::instance()->commit();
   else
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
       Database::instance()->rollback();
   return 0;
  //## end b24messageprocessor::B24MessageProcessor::dispatch%38FB2C1C00F3.body
}

int B24MessageProcessor::initialization ()
{
  //## begin b24messageprocessor::B24MessageProcessor::initialization%38FB2C1C0144.body preserve=yes
   IString strBuffer;
   Extract::instance()->get("DUSER   ",strBuffer);
   if (strBuffer.indexOf("B24ATM"))
      m_lFileType = ATM_INPUT;
   else
   if (strBuffer.indexOf("B24POS"))
      m_lFileType = POS_INPUT;
   bool bAsciiInput = true;
   if (strBuffer.indexOf("EBCDIC"))
      bAsciiInput = false;
   m_hB24TLFFinancial.setB24AsciiInput(bAsciiInput);
   m_hB24PTLFFinancial.setB24AsciiInput(bAsciiInput);
   int iGMTOffset = 0;
   bool bDST=false;
   string strRecord;
   Extract::instance()->getRecord("DUSER",strRecord);
   size_t pos = strRecord.find("GMT");
// |<tr><td>DUSER GMT in minutes <td>+NNNN  or -NNNN for DayLight Saving-NNNND or +NNNND
   char szOffset[7] = {"      "};
   if (pos != string::npos)
   {
      memcpy(szOffset,strRecord.data() + pos + 3,6);
      bDST = szOffset[5] == 'D';
      szOffset[5] = '\0';
      iGMTOffset = atoi(szOffset + 1);
      if (szOffset[0] == '-')
         iGMTOffset = 0 - iGMTOffset;
      m_hB24TLFFinancial.setDSTBeginEnd(strRecord.substr(pos + 9 ,6));
      m_hB24PTLFFinancial.setDSTBeginEnd(m_hB24TLFFinancial.getDSTBeginEnd());
   }
   else if (Extract::instance()->getSpec("GMT",strRecord))
   {
      if(strRecord.length() >= 12)
      {
         m_hB24TLFFinancial.setDSTBeginEnd(strRecord.substr(9 ,6));
         m_hB24PTLFFinancial.setDSTBeginEnd(m_hB24TLFFinancial.getDSTBeginEnd());
      }
      else
         strRecord.resize(6,' ');
      bDST = strRecord[5] == 'D';
      iGMTOffset = atoi(strRecord.substr(0,5).c_str());
   }
   m_hB24TLFFinancial.setDST(bDST);
   m_hB24TLFFinancial.setGMTOffset(iGMTOffset);
   m_hB24PTLFFinancial.setDST(bDST);
   m_hB24PTLFFinancial.setGMTOffset(iGMTOffset);

   Extract::instance()->getRecord("DUSER   ",strRecord);
   bool bExpirationDate = strRecord.find("DATE_EXP") != string::npos;
   m_hB24TLFFinancial.m_bExpirationDate = bExpirationDate; 
   m_hB24PTLFFinancial.m_bExpirationDate = bExpirationDate; 

   m_hB24PTLFFinancial.setTrack2(strRecord.find("TRACK2") != string::npos);
   
   if (Extract::instance()->getSpec("CAN_VAL",strRecord))
   {
      vector <string> hTokens;
      Buffer::parse(strRecord,",",hTokens);
      if (hTokens.size() == 4 )
      {
         m_hB24TLFFinancial.m_hCanisterValues.clear();
         m_hB24PTLFFinancial.m_hCanisterValues.clear();
         vector<string>::iterator p;
         for(p = hTokens.begin(); p != hTokens.end(); p++)
         {
            m_hB24TLFFinancial.m_hCanisterValues.push_back(atoi((*p).c_str()));
            m_hB24PTLFFinancial.m_hCanisterValues.push_back(atoi((*p).c_str()));
         }
      }
   }
   if (Extract::instance()->getSpec("VNTFIID",strRecord))
   {
       m_hB24PTLFFinancial.setVNTFiid(strRecord);
   }
   else
       m_hB24PTLFFinancial.setVNTFiid("VISA");

   if (Extract::instance()->getSpec("MCIFIID",strRecord))
   {
       m_hB24PTLFFinancial.setMCIFiid(strRecord);
   }
   else
       m_hB24PTLFFinancial.setMCIFiid("APC");
   m_hMessages.insert(m_hMessages.begin(), MessageList::value_type("TLF01", &m_hB24TLFFinancial));
   m_hMessages.insert(m_hMessages.begin(), MessageList::value_type("TLF20", &m_hB24TLFFinancial));
   m_hMessages.insert(m_hMessages.begin(), MessageList::value_type("TLF21", &m_hB24TLFFinancial));
   m_hMessages.insert(m_hMessages.begin(), MessageList::value_type("PTLF01", &m_hB24PTLFFinancial));
   m_hMessages.insert(m_hMessages.begin(), MessageList::value_type("PTLF20", &m_hB24PTLFFinancial));
   m_hMessages.insert(m_hMessages.begin(), MessageList::value_type("PTLF21", &m_hB24PTLFFinancial));
   m_hMessages.insert(m_hMessages.begin(), MessageList::value_type("PTLF22", &m_hB24PTLFFinancial));
   m_hMessages.insert(m_hMessages.begin(), MessageList::value_type("PTLF23", &m_hB24PTLFFinancial));
   return 0;
  //## end b24messageprocessor::B24MessageProcessor::initialization%38FB2C1C0144.body
}

b24messageprocessor::B24MessageProcessor* B24MessageProcessor::instance ()
{
  //## begin b24messageprocessor::B24MessageProcessor::instance%38FB2C1C01BC.body preserve=yes
   return m_pInstance;
  //## end b24messageprocessor::B24MessageProcessor::instance%38FB2C1C01BC.body
}

int B24MessageProcessor::reset ()
{
  //## begin b24messageprocessor::B24MessageProcessor::reset%38FB2C1C023E.body preserve=yes
   char szTestDate[9];
   memset(szTestDate,'\0',sizeof(szTestDate));
   size_t pos;
   string strContext((char*)Message::instance(Message::INBOUND)->context());
   if (strContext.find("TESTDATEOFF") != string::npos)
      B24Message::setTestDate(szTestDate);
   else
      if ((pos = strContext.find("TESTDATE=")) != string::npos)
   {
      memcpy(szTestDate,strContext.data() + pos + 9,8);
      B24Message::setTestDate(szTestDate);
   }
   else
      ConfigurationRepository::instance()->reset();
   return 0;
  //## end b24messageprocessor::B24MessageProcessor::reset%38FB2C1C023E.body
}

// Additional Declarations
  //## begin b24messageprocessor::B24MessageProcessor%38FB16B80059.declarations preserve=yes
  //## end b24messageprocessor::B24MessageProcessor%38FB16B80059.declarations

} // namespace b24messageprocessor

//## begin module%38FB39E702E5.epilog preserve=yes
//## end module%38FB39E702E5.epilog
