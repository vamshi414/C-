//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%38FB57660329.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%38FB57660329.cm

//## begin module%38FB57660329.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%38FB57660329.cp

//## Module: CXOSBP05%38FB57660329; Package body
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Devel\Dn\Server\Library\BPDLL\CXOSBP05.cpp

//## begin module%38FB57660329.additionalIncludes preserve=no
//## end module%38FB57660329.additionalIncludes

//## begin module%38FB57660329.includes preserve=yes
// $Date:   Apr 09 2004 12:38:38  $ $Author:   D02405  $ $Revision:   1.6  $
#include "CXODIF11.hpp"
//## end module%38FB57660329.includes

#ifndef CXOSBP05_h
#include "CXODBP05.hpp"
#endif
//## begin module%38FB57660329.declarations preserve=no
//## end module%38FB57660329.declarations

//## begin module%38FB57660329.additionalDeclarations preserve=yes
//## end module%38FB57660329.additionalDeclarations


//## Modelname: Platform \: Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

// Class b24messageprocessor::B24Status 



B24Status::B24Status()
  //## begin B24Status::B24Status%38FB371800C5_const.hasinit preserve=no
  //## end B24Status::B24Status%38FB371800C5_const.hasinit
  //## begin B24Status::B24Status%38FB371800C5_const.initialization preserve=yes
   : B24Message("STATUS","S907")
  //## end B24Status::B24Status%38FB371800C5_const.initialization
{
  //## begin b24messageprocessor::B24Status::B24Status%38FB371800C5_const.body preserve=yes
   memcpy(m_sID,"BP05",4);
  //## end b24messageprocessor::B24Status::B24Status%38FB371800C5_const.body
}


B24Status::~B24Status()
{
  //## begin b24messageprocessor::B24Status::~B24Status%38FB371800C5_dest.body preserve=yes
  //## end b24messageprocessor::B24Status::~B24Status%38FB371800C5_dest.body
}



//## Other Operations (implementation)
bool B24Status::insert (Message& hMessage)
{
  //## begin b24messageprocessor::B24Status::insert%38FB38650395.body preserve=yes
   return true;
  //## end b24messageprocessor::B24Status::insert%38FB38650395.body
}

void B24Status::translateAscii ()
{
  //## begin b24messageprocessor::B24Status::translateAscii%3916CDE802DD.body preserve=yes
  //## end b24messageprocessor::B24Status::translateAscii%3916CDE802DD.body
}

// Additional Declarations
  //## begin b24messageprocessor::B24Status%38FB371800C5.declarations preserve=yes
  //## end b24messageprocessor::B24Status%38FB371800C5.declarations

} // namespace b24messageprocessor

//## begin module%38FB57660329.epilog preserve=yes
//## end module%38FB57660329.epilog
