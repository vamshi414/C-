//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%38FB55620345.cm preserve=no
//	$Date:   Nov 06 2013 11:25:58  $ $Author:   e1014316  $
//	$Revision:   1.18  $
//## end module%38FB55620345.cm

//## begin module%38FB55620345.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%38FB55620345.cp

//## Module: CXOSBP03%38FB55620345; Package specification
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Devel\DN\Server\Library\Bpdll\CXODBP03.hpp

#ifndef CXOSBP03_h
#define CXOSBP03_h 1

//## begin module%38FB55620345.additionalIncludes preserve=no
//## end module%38FB55620345.additionalIncludes

//## begin module%38FB55620345.includes preserve=yes
// $Date:   Nov 06 2013 11:25:58  $ $Author:   e1014316  $ $Revision:   1.18  $
//## end module%38FB55620345.includes

#ifndef CXOSBP02_h
#include "CXODBP02.hpp"
#endif
#ifndef CXOSRS89_h
#include "CXODRS89.hpp"
#endif
#ifndef CXOSRS88_h
#include "CXODRS88.hpp"
#endif
#ifndef CXOSRS87_h
#include "CXODRS87.hpp"
#endif
#ifndef CXOSRS70_h
#include "CXODRS70.hpp"
#endif
#ifndef CXOSRS40_h
#include "CXODRS40.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSRS39_h
#include "CXODRS39.hpp"
#endif
#ifndef CXOSRS37_h
#include "CXODRS37.hpp"
#endif
#ifndef CXOSRS36_h
#include "CXODRS36.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class SwitchInterface;
} // namespace switchinterface

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
class EvidenceSegment;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Timestamp;
class CodeTable;
class Message;
class DateTime;
class Trace;
class Log;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class GMT;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ListSegment;

} // namespace segment

//## begin module%38FB55620345.declarations preserve=no
//## end module%38FB55620345.declarations

//## begin module%38FB55620345.additionalDeclarations preserve=yes
//## end module%38FB55620345.additionalDeclarations


//## Modelname: Platform \: ACI Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

//## begin b24messageprocessor::B24TLFFinancial%38FB16EB0048.preface preserve=yes
//## end b24messageprocessor::B24TLFFinancial%38FB16EB0048.preface

//## Class: B24TLFFinancial%38FB16EB0048
//	The B24TLFFinancial class encapsulates the functions
//	that process a financial message from an ACI Base24
//	online switch in preparation for adding it to the Data
//	Navigator repository.
//## Category: Platform \: ACI Base 24::B24MessageProcessor_CAT%38F232BC039B
//## Subsystem: BPDLL%38FB203D0324
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%392E8F15011B;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%392EA4B701FB;IF::Log { -> F}
//## Uses: <unnamed>%392EA4D201A9;IF::Trace { -> F}
//## Uses: <unnamed>%392EC4BC000D;IF::CodeTable { -> F}
//## Uses: <unnamed>%392EC5AD012B;IF::DateTime { -> F}
//## Uses: <unnamed>%392EC605029B;IF::Message { -> F}
//## Uses: <unnamed>%392EC6FD02A1;switchinterface::SwitchInterface { -> F}
//## Uses: <unnamed>%4C10B9F0028E;IF::Trace { -> F}
//## Uses: <unnamed>%4C10BA0A024E;monitor::UseCase { -> F}
//## Uses: <unnamed>%4C10BA7601FA;entitysegment::Customer { -> F}
//## Uses: <unnamed>%4C2B27AD002A;IF::Timestamp { -> F}
//## Uses: <unnamed>%4C2B27DB01DC;timer::GMT { -> F}
//## Uses: <unnamed>%4CC9242C036B;reusable::Buffer { -> F}
//## Uses: <unnamed>%4D7519420057;configuration::EvidenceSegment { -> F}
//## Uses: <unnamed>%5231C5610162;segment::ListSegment { -> F}

class DllExport B24TLFFinancial : public B24Message  //## Inherits: <unnamed>%38FB2B100062
{
  //## begin b24messageprocessor::B24TLFFinancial%38FB16EB0048.initialDeclarations preserve=yes
  //## end b24messageprocessor::B24TLFFinancial%38FB16EB0048.initialDeclarations

  public:
    //## Constructors (generated)
      B24TLFFinancial();

    //## Destructor (generated)
      virtual ~B24TLFFinancial();


    //## Other Operations (specified)
      //## Operation: insert%38FB2F2F011D
      //	This method contains all the logic required to convert
      //	an IBM financial record into an STS transaction.
      virtual bool insert (Message& hMessage);

      //## Operation: translateAscii%3916CB890244
      //	This method contains all the logic required to translate
      //	all ASCII fields within an IBM financial record to
      //	EBCDIC format.
      virtual void translateAscii ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: B24AsciiInput%4C10D5C10179
      const bool& getB24AsciiInput () const
      {
        //## begin b24messageprocessor::B24TLFFinancial::getB24AsciiInput%4C10D5C10179.get preserve=no
        return m_bB24AsciiInput;
        //## end b24messageprocessor::B24TLFFinancial::getB24AsciiInput%4C10D5C10179.get
      }

      void setB24AsciiInput (const bool& value)
      {
        //## begin b24messageprocessor::B24TLFFinancial::setB24AsciiInput%4C10D5C10179.set preserve=no
        m_bB24AsciiInput = value;
        //## end b24messageprocessor::B24TLFFinancial::setB24AsciiInput%4C10D5C10179.set
      }


      //## Attribute: DST%4C2B25740398
      const bool& getDST () const
      {
        //## begin b24messageprocessor::B24TLFFinancial::getDST%4C2B25740398.get preserve=no
        return m_bDST;
        //## end b24messageprocessor::B24TLFFinancial::getDST%4C2B25740398.get
      }

      void setDST (const bool& value)
      {
        //## begin b24messageprocessor::B24TLFFinancial::setDST%4C2B25740398.set preserve=no
        m_bDST = value;
        //## end b24messageprocessor::B24TLFFinancial::setDST%4C2B25740398.set
      }


      //## Attribute: DSTBeginEnd%4CA32F5D01A4
      const string& getDSTBeginEnd () const
      {
        //## begin b24messageprocessor::B24TLFFinancial::getDSTBeginEnd%4CA32F5D01A4.get preserve=no
        return m_strDSTBeginEnd;
        //## end b24messageprocessor::B24TLFFinancial::getDSTBeginEnd%4CA32F5D01A4.get
      }

      void setDSTBeginEnd (const string& value)
      {
        //## begin b24messageprocessor::B24TLFFinancial::setDSTBeginEnd%4CA32F5D01A4.set preserve=no
        m_strDSTBeginEnd = value;
        //## end b24messageprocessor::B24TLFFinancial::setDSTBeginEnd%4CA32F5D01A4.set
      }


      //## Attribute: GMTOffset%4C2B258E0209
      const int& getGMTOffset () const
      {
        //## begin b24messageprocessor::B24TLFFinancial::getGMTOffset%4C2B258E0209.get preserve=no
        return m_iGMTOffset;
        //## end b24messageprocessor::B24TLFFinancial::getGMTOffset%4C2B258E0209.get
      }

      void setGMTOffset (const int& value)
      {
        //## begin b24messageprocessor::B24TLFFinancial::setGMTOffset%4C2B258E0209.set preserve=no
        m_iGMTOffset = value;
        //## end b24messageprocessor::B24TLFFinancial::setGMTOffset%4C2B258E0209.set
      }


    // Data Members for Class Attributes

      //## begin b24messageprocessor::B24TLFFinancial::B24AsciiInput%4C10D5C10179.attr preserve=no  public: bool {V} 
      bool m_bB24AsciiInput;
      //## end b24messageprocessor::B24TLFFinancial::B24AsciiInput%4C10D5C10179.attr

      //## begin b24messageprocessor::B24TLFFinancial::DST%4C2B25740398.attr preserve=no  public: bool {V} 
      bool m_bDST;
      //## end b24messageprocessor::B24TLFFinancial::DST%4C2B25740398.attr

      //## Attribute: ExpirationDate%4C10D1B90234
      //## begin b24messageprocessor::B24TLFFinancial::ExpirationDate%4C10D1B90234.attr preserve=no  public: bool {V} 
      bool m_bExpirationDate;
      //## end b24messageprocessor::B24TLFFinancial::ExpirationDate%4C10D1B90234.attr

      //## begin b24messageprocessor::B24TLFFinancial::GMTOffset%4C2B258E0209.attr preserve=no  public: int {V} 
      int m_iGMTOffset;
      //## end b24messageprocessor::B24TLFFinancial::GMTOffset%4C2B258E0209.attr

    // Additional Public Declarations
      //## begin b24messageprocessor::B24TLFFinancial%38FB16EB0048.public preserve=yes
      //## end b24messageprocessor::B24TLFFinancial%38FB16EB0048.public

  protected:
    // Additional Protected Declarations
      //## begin b24messageprocessor::B24TLFFinancial%38FB16EB0048.protected preserve=yes
      //## end b24messageprocessor::B24TLFFinancial%38FB16EB0048.protected

  private:

    //## Other Operations (specified)
      //## Operation: reset%393E9EA300D0
      //	This method resets all segments and boolean error flags
      //	ready to process a new message
      void reset ();

    // Additional Private Declarations
      //## begin b24messageprocessor::B24TLFFinancial%38FB16EB0048.private preserve=yes
      //## end b24messageprocessor::B24TLFFinancial%38FB16EB0048.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin b24messageprocessor::B24TLFFinancial::DSTBeginEnd%4CA32F5D01A4.attr preserve=no  public: string {U} 
      string m_strDSTBeginEnd;
      //## end b24messageprocessor::B24TLFFinancial::DSTBeginEnd%4CA32F5D01A4.attr

      //## Attribute: Reversal%393EA0210075
      //## begin b24messageprocessor::B24TLFFinancial::Reversal%393EA0210075.attr preserve=no  private: bool {V} 
      bool m_bReversal;
      //## end b24messageprocessor::B24TLFFinancial::Reversal%393EA0210075.attr

    // Data Members for Associations

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%3BB234FC01F4
      //## Role: B24TLFFinancial::<m_hFinancialUserSegment>%3BB234FD01D4
      //## begin b24messageprocessor::B24TLFFinancial::<m_hFinancialUserSegment>%3BB234FD01D4.role preserve=no  public: repositorysegment::FinancialUserSegment { -> VHgN}
      repositorysegment::FinancialUserSegment m_hFinancialUserSegment;
      //## end b24messageprocessor::B24TLFFinancial::<m_hFinancialUserSegment>%3BB234FD01D4.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%3BB23D58005D
      //## Role: B24TLFFinancial::<m_hFinancialSettlementSegment>%3BB23D58033C
      //## begin b24messageprocessor::B24TLFFinancial::<m_hFinancialSettlementSegment>%3BB23D58033C.role preserve=no  public: repositorysegment::FinancialSettlementSegment { -> VHgN}
      repositorysegment::FinancialSettlementSegment m_hFinancialSettlementSegment;
      //## end b24messageprocessor::B24TLFFinancial::<m_hFinancialSettlementSegment>%3BB23D58033C.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%3BB23D5A0196
      //## Role: B24TLFFinancial::<m_hFinancialReversalSegment>%3BB23D5B008C
      //## begin b24messageprocessor::B24TLFFinancial::<m_hFinancialReversalSegment>%3BB23D5B008C.role preserve=no  public: repositorysegment::FinancialReversalSegment { -> VHgN}
      repositorysegment::FinancialReversalSegment m_hFinancialReversalSegment;
      //## end b24messageprocessor::B24TLFFinancial::<m_hFinancialReversalSegment>%3BB23D5B008C.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%3BB23D5C0251
      //## Role: B24TLFFinancial::<m_hFinancialBaseSegment>%3BB23D5D0157
      //## begin b24messageprocessor::B24TLFFinancial::<m_hFinancialBaseSegment>%3BB23D5D0157.role preserve=no  public: repositorysegment::FinancialBaseSegment { -> VHgN}
      repositorysegment::FinancialBaseSegment m_hFinancialBaseSegment;
      //## end b24messageprocessor::B24TLFFinancial::<m_hFinancialBaseSegment>%3BB23D5D0157.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%4C10B572030F
      //## Role: B24TLFFinancial::<m_hIntegratedCircuitCardSegment>%4C10B573035D
      //## begin b24messageprocessor::B24TLFFinancial::<m_hIntegratedCircuitCardSegment>%4C10B573035D.role preserve=no  public: repositorysegment::IntegratedCircuitCardSegment { -> VHgN}
      repositorysegment::IntegratedCircuitCardSegment m_hIntegratedCircuitCardSegment;
      //## end b24messageprocessor::B24TLFFinancial::<m_hIntegratedCircuitCardSegment>%4C10B573035D.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%4C10B6530256
      //## Role: B24TLFFinancial::<m_hFinancialAdjustmentSegment>%4C10B654012D
      //## begin b24messageprocessor::B24TLFFinancial::<m_hFinancialAdjustmentSegment>%4C10B654012D.role preserve=no  public: repositorysegment::FinancialAdjustmentSegment { -> VHgN}
      repositorysegment::FinancialAdjustmentSegment m_hFinancialAdjustmentSegment;
      //## end b24messageprocessor::B24TLFFinancial::<m_hFinancialAdjustmentSegment>%4C10B654012D.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%5231BDEF00D1
      //## Role: B24TLFFinancial::<m_hCheckDepositSegment>%5231BDF00359
      //## begin b24messageprocessor::B24TLFFinancial::<m_hCheckDepositSegment>%5231BDF00359.role preserve=no  public: repositorysegment::CheckDepositSegment { -> 0..nVHgN}
      vector<repositorysegment::CheckDepositSegment> m_hCheckDepositSegment;
      //## end b24messageprocessor::B24TLFFinancial::<m_hCheckDepositSegment>%5231BDF00359.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%5231BDF4001A
      //## Role: B24TLFFinancial::<m_hCashDepositSegment>%5231BDF601E4
      //## begin b24messageprocessor::B24TLFFinancial::<m_hCashDepositSegment>%5231BDF601E4.role preserve=no  public: repositorysegment::CashDepositSegment { -> 0..nVHgN}
      vector<repositorysegment::CashDepositSegment> m_hCashDepositSegment;
      //## end b24messageprocessor::B24TLFFinancial::<m_hCashDepositSegment>%5231BDF601E4.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%524934860131
      //## Role: B24TLFFinancial::<m_hFinancialDepositSegment>%524934870284
      //## begin b24messageprocessor::B24TLFFinancial::<m_hFinancialDepositSegment>%524934870284.role preserve=no  public: repositorysegment::FinancialDepositSegment { -> VHgN}
      repositorysegment::FinancialDepositSegment m_hFinancialDepositSegment;
      //## end b24messageprocessor::B24TLFFinancial::<m_hFinancialDepositSegment>%524934870284.role

    // Additional Implementation Declarations
      //## begin b24messageprocessor::B24TLFFinancial%38FB16EB0048.implementation preserve=yes
      //## end b24messageprocessor::B24TLFFinancial%38FB16EB0048.implementation

};

//## begin b24messageprocessor::B24TLFFinancial%38FB16EB0048.postscript preserve=yes
//## end b24messageprocessor::B24TLFFinancial%38FB16EB0048.postscript

} // namespace b24messageprocessor

//## begin module%38FB55620345.epilog preserve=yes
using namespace b24messageprocessor;
//## end module%38FB55620345.epilog


#endif
