//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38FB39E202A2.cm preserve=no
//	$Date:   Oct 20 2020 02:33:44  $ $Author:   e1014059  $
//	$Revision:   1.12.1.0  $
//## end module%38FB39E202A2.cm

//## begin module%38FB39E202A2.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%38FB39E202A2.cp

//## Module: CXOSBP01%38FB39E202A2; Package specification
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Devel\Dn\Server\Library\BPDLL\CXODBP01.hpp

#ifndef CXOSBP01_h
#define CXOSBP01_h 1

//## begin module%38FB39E202A2.additionalIncludes preserve=no
//## end module%38FB39E202A2.additionalIncludes

//## begin module%38FB39E202A2.includes preserve=yes
// $Date:   Oct 20 2020 02:33:44  $ $Author:   e1014059  $ $Revision:   1.12.1.0  $
#include <map>
#ifndef CXOSBP02_h
#include "CXODBP02.hpp"
#endif
//## end module%38FB39E202A2.includes

#ifndef CXOSBP09_h
#include "CXODBP09.hpp"
#endif
#ifndef CXOSBP08_h
#include "CXODBP08.hpp"
#endif
#ifndef CXOSBP05_h
#include "CXODBP05.hpp"
#endif
#ifndef CXOSBP04_h
#include "CXODBP04.hpp"
#endif
#ifndef CXOSBP03_h
#include "CXODBP03.hpp"
#endif
#ifndef CXOSSI02_h
#include "CXODSI02.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;

} // namespace IF

//## begin module%38FB39E202A2.declarations preserve=no
//## end module%38FB39E202A2.declarations

//## begin module%38FB39E202A2.additionalDeclarations preserve=yes
#define ATM_INPUT 0
#define POS_INPUT 1
#define STAT_INPUT 2
//## end module%38FB39E202A2.additionalDeclarations


//## Modelname: Platform \: ACI Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

//## begin b24messageprocessor::B24MessageProcessor%38FB16B80059.preface preserve=yes
//## end b24messageprocessor::B24MessageProcessor%38FB16B80059.preface

//## Class: B24MessageProcessor%38FB16B80059
//	The B24MessageProcessor class encapsulates the functions
//	that process the messages from an ACI Base24 online
//	switch in preparation for adding them to the Data
//	Navigator repository.
//## Category: Platform \: ACI Base 24::B24MessageProcessor_CAT%38F232BC039B
//## Subsystem: BPDLL%38FB203D0324
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39355C40034E;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%4C2B325B0101;IF::CodeTable { -> F}
//## Uses: <unnamed>%4C43EACA00DB;monitor::UseCase { -> F}
//## Uses: <unnamed>%4CC927ED0359;reusable::Buffer { -> F}

class DllExport B24MessageProcessor : public switchinterface::MessageProcessor  //## Inherits: <unnamed>%38FB2AB5031E
{
  //## begin b24messageprocessor::B24MessageProcessor%38FB16B80059.initialDeclarations preserve=yes
  //## end b24messageprocessor::B24MessageProcessor%38FB16B80059.initialDeclarations

  public:
    //## Constructors (generated)
      B24MessageProcessor();

    //## Destructor (generated)
      virtual ~B24MessageProcessor();


    //## Other Operations (specified)
      //## Operation: dispatch%38FB2C1C00F3
      //	This method routes the ACI Base24 logged record message
      //	to the appropriate subroutine (class) for reformatting
      //	into the DataNavigator standard fields.
      int dispatch ();

      //## Operation: initialization%38FB2C1C0144
      //	Method assigns initialization values to class variables.
      virtual int initialization ();

      //## Operation: instance%38FB2C1C01BC
      //	This method returns the static instance pointer to this
      //	object.
      static B24MessageProcessor* instance ();

      //## Operation: reset%38FB2C1C023E
      //	Method sets the test date value to be used..
      virtual int reset ();

    // Additional Public Declarations
      //## begin b24messageprocessor::B24MessageProcessor%38FB16B80059.public preserve=yes
      //## end b24messageprocessor::B24MessageProcessor%38FB16B80059.public

  protected:
    // Additional Protected Declarations
      //## begin b24messageprocessor::B24MessageProcessor%38FB16B80059.protected preserve=yes
      //## end b24messageprocessor::B24MessageProcessor%38FB16B80059.protected

  private:
    // Additional Private Declarations
      //## begin b24messageprocessor::B24MessageProcessor%38FB16B80059.private preserve=yes
     typedef map<string, B24Message*, less<string> > MessageList;
      //## end b24messageprocessor::B24MessageProcessor%38FB16B80059.private
  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: FileType%3907182C0184
      //## begin b24messageprocessor::B24MessageProcessor::FileType%3907182C0184.attr preserve=no  private: int {V} 
      int m_lFileType;
      //## end b24messageprocessor::B24MessageProcessor::FileType%3907182C0184.attr

      //## Attribute: Instance%38FB2C6B0237
      //## begin b24messageprocessor::B24MessageProcessor::Instance%38FB2C6B0237.attr preserve=no  private: static B24MessageProcessor* {V} 0
      static B24MessageProcessor* m_pInstance;
      //## end b24messageprocessor::B24MessageProcessor::Instance%38FB2C6B0237.attr

      //## Attribute: Messages%38FB2C6B0346
      //## begin b24messageprocessor::B24MessageProcessor::Messages%38FB2C6B0346.attr preserve=no  private: MessageList {V} 
      MessageList m_hMessages;
      //## end b24messageprocessor::B24MessageProcessor::Messages%38FB2C6B0346.attr

    // Data Members for Associations

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%38FB6ABE00DB
      //## Role: B24MessageProcessor::<m_hB24TLFFinancial>%38FB6ABF00F1
      //## begin b24messageprocessor::B24MessageProcessor::<m_hB24TLFFinancial>%38FB6ABF00F1.role preserve=no  public: b24messageprocessor::B24TLFFinancial { -> VHgN}
      B24TLFFinancial m_hB24TLFFinancial;
      //## end b24messageprocessor::B24MessageProcessor::<m_hB24TLFFinancial>%38FB6ABF00F1.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%38FB6AC302EB
      //## Role: B24MessageProcessor::<m_hB24TLFAdmin>%38FB6AC40198
      //## begin b24messageprocessor::B24MessageProcessor::<m_hB24TLFAdmin>%38FB6AC40198.role preserve=no  public: b24messageprocessor::B24TLFAdmin { -> VHgN}
      B24TLFAdmin m_hB24TLFAdmin;
      //## end b24messageprocessor::B24MessageProcessor::<m_hB24TLFAdmin>%38FB6AC40198.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%38FB6AC8027A
      //## Role: B24MessageProcessor::<m_hB24Status>%38FB6AC900B9
      //## begin b24messageprocessor::B24MessageProcessor::<m_hB24Status>%38FB6AC900B9.role preserve=no  public: b24messageprocessor::B24Status { -> VHgN}
      B24Status m_hB24Status;
      //## end b24messageprocessor::B24MessageProcessor::<m_hB24Status>%38FB6AC900B9.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%391C56E901AB
      //## Role: B24MessageProcessor::<m_hB24PTLFFinancial>%391C56EB037B
      //## begin b24messageprocessor::B24MessageProcessor::<m_hB24PTLFFinancial>%391C56EB037B.role preserve=no  public: b24messageprocessor::B24PTLFFinancial { -> VHgN}
      B24PTLFFinancial m_hB24PTLFFinancial;
      //## end b24messageprocessor::B24MessageProcessor::<m_hB24PTLFFinancial>%391C56EB037B.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%391C5AD50321
      //## Role: B24MessageProcessor::<m_hB24PTLFAdmin>%391C5AD6020B
      //## begin b24messageprocessor::B24MessageProcessor::<m_hB24PTLFAdmin>%391C5AD6020B.role preserve=no  public: b24messageprocessor::B24PTLFAdmin { -> VHgN}
      B24PTLFAdmin m_hB24PTLFAdmin;
      //## end b24messageprocessor::B24MessageProcessor::<m_hB24PTLFAdmin>%391C5AD6020B.role

    // Additional Implementation Declarations
      //## begin b24messageprocessor::B24MessageProcessor%38FB16B80059.implementation preserve=yes
      //## end b24messageprocessor::B24MessageProcessor%38FB16B80059.implementation

};

//## begin b24messageprocessor::B24MessageProcessor%38FB16B80059.postscript preserve=yes
//## end b24messageprocessor::B24MessageProcessor%38FB16B80059.postscript

} // namespace b24messageprocessor

//## begin module%38FB39E202A2.epilog preserve=yes
using namespace b24messageprocessor;
//## end module%38FB39E202A2.epilog


#endif
