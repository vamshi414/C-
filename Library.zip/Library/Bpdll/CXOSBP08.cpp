//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%390DAD0E0154.cm preserve=no
//	$Date:   Jun 21 2017 13:44:12  $ $Author:   e1009839  $
//	$Revision:   1.29.1.0  $
//## end module%390DAD0E0154.cm

//## begin module%390DAD0E0154.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%390DAD0E0154.cp

//## Module: CXOSBP08%390DAD0E0154; Package body
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Devel\DN\Server\Library\Bpdll\CXOSBP08.cpp

//## begin module%390DAD0E0154.additionalIncludes preserve=no
//## end module%390DAD0E0154.additionalIncludes

//## begin module%390DAD0E0154.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#include "CXODIF11.hpp"
#include "CXODBP11.hpp"
#include "CXODRS66.hpp"
//## end module%390DAD0E0154.includes

#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSSI01_h
#include "CXODSI01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSTM12_h
#include "CXODTM12.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSBP08_h
#include "CXODBP08.hpp"
#endif


//## begin module%390DAD0E0154.declarations preserve=no
//## end module%390DAD0E0154.declarations

//## begin module%390DAD0E0154.additionalDeclarations preserve=yes
//## end module%390DAD0E0154.additionalDeclarations


//## Modelname: Platform \: ACI Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

// Class b24messageprocessor::B24PTLFFinancial 

B24PTLFFinancial::B24PTLFFinancial()
  //## begin B24PTLFFinancial::B24PTLFFinancial%390DA89F00E4_const.hasinit preserve=no
      : m_bTrack2(false)
  //## end B24PTLFFinancial::B24PTLFFinancial%390DA89F00E4_const.hasinit
  //## begin B24PTLFFinancial::B24PTLFFinancial%390DA89F00E4_const.initialization preserve=yes
    ,B24Message("FINANCIAL","S200")
  //## end B24PTLFFinancial::B24PTLFFinancial%390DA89F00E4_const.initialization
{
  //## begin b24messageprocessor::B24PTLFFinancial::B24PTLFFinancial%390DA89F00E4_const.body preserve=yes
   memcpy(m_sID,"BP08",4);
  //## end b24messageprocessor::B24PTLFFinancial::B24PTLFFinancial%390DA89F00E4_const.body
}


B24PTLFFinancial::~B24PTLFFinancial()
{
  //## begin b24messageprocessor::B24PTLFFinancial::~B24PTLFFinancial%390DA89F00E4_dest.body preserve=yes
  //## end b24messageprocessor::B24PTLFFinancial::~B24PTLFFinancial%390DA89F00E4_dest.body
}



//## Other Operations (implementation)
bool B24PTLFFinancial::insert (Message& hMessage)
{
  //## begin b24messageprocessor::B24PTLFFinancial::insert%390DA8D900D3.body preserve=yes
#include "CXODBP14.hpp"
#include "CXODBP12.hpp"
  //## end b24messageprocessor::B24PTLFFinancial::insert%390DA8D900D3.body
}

void B24PTLFFinancial::reset ()
{
  //## begin b24messageprocessor::B24PTLFFinancial::reset%3936D9F00196.body preserve=yes
   m_bReversal=false;
   m_hAuditSegment.reset();
   m_hFinancialBaseSegment.reset();
   m_hFinancialSettlementSegment.reset();
   m_hFinancialUserSegment.reset();
   m_hFinancialReversalSegment.reset();
   m_hFinancialAdjustmentSegment.reset();
   m_hIntegratedCircuitCardSegment.reset();
   translateAscii();
  //## end b24messageprocessor::B24PTLFFinancial::reset%3936D9F00196.body
}

void B24PTLFFinancial::translateAscii ()
{
  //## begin b24messageprocessor::B24PTLFFinancial::translateAscii%3916CECF0253.body preserve=yes
   hB24PTLFTransaction* p = (hB24PTLFTransaction*)Message::instance(Message::INBOUND)->data();
#ifdef MVS
   unsigned int j = 0;
   unsigned int k = 0;
   if (m_bB24AsciiInput)
   {
      j = offsetof(hB24PTLFTransaction,lEntryTim[0]);
      k = offsetof(hB24PTLFTransaction,sCrdLn);
      CodeTable::translate(p->sCrdLn,j - k,CodeTable::CX_ASCII_TO_EBCDIC);
      j = offsetof(hB24PTLFTransaction,siTermTimOfst);
      k = offsetof(hB24PTLFTransaction,sTranDatYY);
      CodeTable::translate(p->sTranDatYY,j - k,CodeTable::CX_ASCII_TO_EBCDIC);
      j = offsetof(hB24PTLFTransaction,lAmt1[0]);
      k = offsetof(hB24PTLFTransaction,sAcqInstIdNum);
      CodeTable::translate(p->sAcqInstIdNum,j - k,CodeTable::CX_ASCII_TO_EBCDIC);
      j = offsetof(hB24PTLFTransaction,siUserDataLen);
      k = offsetof(hB24PTLFTransaction,sExpDat);
      CodeTable::translate(p->sExpDat,j - k,CodeTable::CX_ASCII_TO_EBCDIC);
   }
#endif
  //## end b24messageprocessor::B24PTLFFinancial::translateAscii%3916CECF0253.body
}

// Additional Declarations
  //## begin b24messageprocessor::B24PTLFFinancial%390DA89F00E4.declarations preserve=yes
  //## end b24messageprocessor::B24PTLFFinancial%390DA89F00E4.declarations

} // namespace b24messageprocessor

//## begin module%390DAD0E0154.epilog preserve=yes
//## end module%390DAD0E0154.epilog
