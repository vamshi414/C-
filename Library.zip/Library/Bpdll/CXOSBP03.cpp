//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%38FB55640384.cm preserve=no
//	$Date:   Jun 21 2017 13:45:14  $ $Author:   e1009839  $
//	$Revision:   1.39.1.0  $
//## end module%38FB55640384.cm

//## begin module%38FB55640384.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%38FB55640384.cp

//## Module: CXOSBP03%38FB55640384; Package body
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Devel\DN\Server\Library\Bpdll\CXOSBP03.cpp

//## begin module%38FB55640384.additionalIncludes preserve=no
//## end module%38FB55640384.additionalIncludes

//## begin module%38FB55640384.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#include "CXODRU24.hpp"
#include "CXODIF11.hpp"
#include "CXODBP07.hpp"
#include "CXODRS66.hpp"
//## end module%38FB55640384.includes

#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSSI01_h
#include "CXODSI01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSTM12_h
#include "CXODTM12.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSBP03_h
#include "CXODBP03.hpp"
#endif


//## begin module%38FB55640384.declarations preserve=no
//## end module%38FB55640384.declarations

//## begin module%38FB55640384.additionalDeclarations preserve=yes
//## end module%38FB55640384.additionalDeclarations


//## Modelname: Platform \: ACI Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

// Class b24messageprocessor::B24TLFFinancial 

B24TLFFinancial::B24TLFFinancial()
  //## begin B24TLFFinancial::B24TLFFinancial%38FB16EB0048_const.hasinit preserve=no
  //## end B24TLFFinancial::B24TLFFinancial%38FB16EB0048_const.hasinit
  //## begin B24TLFFinancial::B24TLFFinancial%38FB16EB0048_const.initialization preserve=yes
  : B24Message("FINANCIAL","S200")
  //## end B24TLFFinancial::B24TLFFinancial%38FB16EB0048_const.initialization
{
  //## begin b24messageprocessor::B24TLFFinancial::B24TLFFinancial%38FB16EB0048_const.body preserve=yes
   memcpy(m_sID,"BP03",4);
  //## end b24messageprocessor::B24TLFFinancial::B24TLFFinancial%38FB16EB0048_const.body
}


B24TLFFinancial::~B24TLFFinancial()
{
  //## begin b24messageprocessor::B24TLFFinancial::~B24TLFFinancial%38FB16EB0048_dest.body preserve=yes
  //## end b24messageprocessor::B24TLFFinancial::~B24TLFFinancial%38FB16EB0048_dest.body
}



//## Other Operations (implementation)
bool B24TLFFinancial::insert (Message& hMessage)
{
  //## begin b24messageprocessor::B24TLFFinancial::insert%38FB2F2F011D.body preserve=yes
#include "CXODBP13.hpp"
#include "CXODBP12.hpp"
  //## end b24messageprocessor::B24TLFFinancial::insert%38FB2F2F011D.body
}

void B24TLFFinancial::reset ()
{
  //## begin b24messageprocessor::B24TLFFinancial::reset%393E9EA300D0.body preserve=yes
   m_bReversal = false;
   m_hAuditSegment.reset();
   m_hFinancialBaseSegment.reset();
   m_hFinancialSettlementSegment.reset();
   m_hFinancialUserSegment.reset();
   m_hFinancialReversalSegment.reset();
   m_hFinancialAdjustmentSegment.reset();
   m_hIntegratedCircuitCardSegment.reset();
   m_hFinancialDepositSegment.reset();
   translateAscii();
  //## end b24messageprocessor::B24TLFFinancial::reset%393E9EA300D0.body
}

void B24TLFFinancial::translateAscii ()
{
  //## begin b24messageprocessor::B24TLFFinancial::translateAscii%3916CB890244.body preserve=yes
   hB24TLFTransaction* p = (hB24TLFTransaction*)Message::instance(Message::INBOUND)->data();
#ifdef MVS
   unsigned int j = 0;
   unsigned int k = 0;
   if (m_bB24AsciiInput)
   {
      j = offsetof(hB24TLFTransaction,lEntryTim[0]);
      k = offsetof(hB24TLFTransaction,sAuthPpd);
      CodeTable::translate(p->sAuthPpd,j - k,CodeTable::CX_ASCII_TO_EBCDIC);
      j = offsetof(hB24TLFTransaction,siTimOfst);
      k = offsetof(hB24TLFTransaction,sTranDatYY);
      CodeTable::translate(p->sTranDatYY,j - k,CodeTable::CX_ASCII_TO_EBCDIC);
      j = offsetof(hB24TLFTransaction,lAmt1[0]);
      k = offsetof(hB24TLFTransaction,sAcqInstIdNum);
      CodeTable::translate(p->sAcqInstIdNum,j - k,CodeTable::CX_ASCII_TO_EBCDIC);
      j = offsetof(hB24TLFTransaction,sCrdIssIdNum) + 11;
      k = offsetof(hB24TLFTransaction,cDepTyp);
      CodeTable::translate(&p->cDepTyp,j - k,CodeTable::CX_ASCII_TO_EBCDIC);
   }
#endif
  //## end b24messageprocessor::B24TLFFinancial::translateAscii%3916CB890244.body
}

// Additional Declarations
  //## begin b24messageprocessor::B24TLFFinancial%38FB16EB0048.declarations preserve=yes
  //## end b24messageprocessor::B24TLFFinancial%38FB16EB0048.declarations

} // namespace b24messageprocessor

//## begin module%38FB55640384.epilog preserve=yes
//## end module%38FB55640384.epilog
