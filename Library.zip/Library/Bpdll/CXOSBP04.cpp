//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%38FB56C901A7.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%38FB56C901A7.cm

//## begin module%38FB56C901A7.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%38FB56C901A7.cp

//## Module: CXOSBP04%38FB56C901A7; Package body
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Pvcswork\Dn\Server\Library\BPDLL\CXOSBP04.cpp

//## begin module%38FB56C901A7.additionalIncludes preserve=no
//## end module%38FB56C901A7.additionalIncludes

//## begin module%38FB56C901A7.includes preserve=yes
// $Date:   Apr 09 2004 12:38:40  $ $Author:   D02405  $ $Revision:   1.5  $
#include "CXODIF11.hpp"
//## end module%38FB56C901A7.includes

#ifndef CXOSBP04_h
#include "CXODBP04.hpp"
#endif
//## begin module%38FB56C901A7.declarations preserve=no
//## end module%38FB56C901A7.declarations

//## begin module%38FB56C901A7.additionalDeclarations preserve=yes
//## end module%38FB56C901A7.additionalDeclarations


//## Modelname: Platform \: Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

// Class b24messageprocessor::B24TLFAdmin 



B24TLFAdmin::B24TLFAdmin()
  //## begin B24TLFAdmin::B24TLFAdmin%38FB17000125_const.hasinit preserve=no
  //## end B24TLFAdmin::B24TLFAdmin%38FB17000125_const.hasinit
  //## begin B24TLFAdmin::B24TLFAdmin%38FB17000125_const.initialization preserve=yes
   : B24Message("ADMIN","A001")
  //## end B24TLFAdmin::B24TLFAdmin%38FB17000125_const.initialization
{
  //## begin b24messageprocessor::B24TLFAdmin::B24TLFAdmin%38FB17000125_const.body preserve=yes
  //## end b24messageprocessor::B24TLFAdmin::B24TLFAdmin%38FB17000125_const.body
}


B24TLFAdmin::~B24TLFAdmin()
{
  //## begin b24messageprocessor::B24TLFAdmin::~B24TLFAdmin%38FB17000125_dest.body preserve=yes
  //## end b24messageprocessor::B24TLFAdmin::~B24TLFAdmin%38FB17000125_dest.body
}



//## Other Operations (implementation)
bool B24TLFAdmin::insert (Message& hMessage)
{
  //## begin b24messageprocessor::B24TLFAdmin::insert%38FB35EC01FA.body preserve=yes
   return true;
  //## end b24messageprocessor::B24TLFAdmin::insert%38FB35EC01FA.body
}

void B24TLFAdmin::translateAscii ()
{
  //## begin b24messageprocessor::B24TLFAdmin::translateAscii%3916CD5C02AA.body preserve=yes
  //## end b24messageprocessor::B24TLFAdmin::translateAscii%3916CD5C02AA.body
}

// Additional Declarations
  //## begin b24messageprocessor::B24TLFAdmin%38FB17000125.declarations preserve=yes
  //## end b24messageprocessor::B24TLFAdmin%38FB17000125.declarations

} // namespace b24messageprocessor

//## begin module%38FB56C901A7.epilog preserve=yes
//## end module%38FB56C901A7.epilog
