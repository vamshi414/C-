//	Copyright (c) 1998 - 2004
//	eFunds Corporation
// $Date:   Jul 26 2010 13:43:18  $ $Author:   E1009610  $ $Revision:   1.6  $

#ifndef CXODBP10_HPP
#define CXODBP10_HPP

#include "CXODRU32.hpp"

struct hB24hTermHopperData
{
   char sContents[2];
   char sBegCash[8];         // int int in TANDEM format - 64 bit binary 
   char sCashIncr[8];        // int int in TANDEM format - 64 bit binary
   char sCashDecr[8];        // int int in TANDEM format - 64 bit binary
   char sCashOut[8];         // int int in TANDEM format - 64 bit binary
   char sEndCash[8];         // int int in TANDEM format - 64 bit binary
   char crncyCde[3];
   char userFld5;
};
      

struct hB24TLFTerminalSettlement
{
   // Standard B24 PTLF Header Layout - same for all records from the TLF (ATM) files
   char sTypeRec[2];         // DR,TR or CF added by Extract process or by online feed process
   char sFiller[4];         // Dat_tim - 64 bit binary
   int lHdrHash;           // Use second 4 bytes for hashing
   char sRecTyp[2];         // 01, 20, 21, 22
   char sAuthPpd[4];
   char sTermLn[4];
   char sTermFiid[4];
   char sTermId[16];
   char sCrdLn[4];
   char sCrdFiid[4];
   char sCrdPan[19];
   char sCrdMbrNum[3];
   char sBrchId[4];
   char sRegnId[4];
   // B24 TLF Terminal Settlement Record Detail
   char sAdminDatYY[2];
   char sAdminDatMM[2];
   char sAdminDatDD[2];
   char sAdminTimHH[2];
   char sAdminTimMM[2];
   char sAdminTimSS[2];
   char sAdminTimTT[2];
   char sAdminCde[2];
   hB24hTermHopperData TermHopperData[6];
   short siNumDep;
   char sAmtDep[8];         // int int in TANDEM format - 64 bit binary      
   short siNumCmrclDep;
   char sAmtCmrclDep[8];    // int int in TANDEM format - 64 bit binary
   short siNumPay;
   char sAmtPay[8];         // int int in TANDEM format - 64 bit binary
   short siNumMsg;
   short siNumChk;
   char sAmtChk[8];         // int int in TANDEM format - 64 bit binary
   short siNumLogonly;
   short siTtlEnv;
   short siCrdsRet;
   char sSetlCrncyCde[3];
   char cUserFld7;
   short siTimOfst;
   char sSetlArea[20];
};      

#include "CXODRU33.hpp"

#endif
