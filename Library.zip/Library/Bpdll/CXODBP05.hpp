//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%38FB57640359.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%38FB57640359.cm

//## begin module%38FB57640359.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%38FB57640359.cp

//## Module: CXOSBP05%38FB57640359; Package specification
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Devel\Dn\Server\Library\BPDLL\CXODBP05.hpp

#ifndef CXOSBP05_h
#define CXOSBP05_h 1

//## begin module%38FB57640359.additionalIncludes preserve=no
//## end module%38FB57640359.additionalIncludes

//## begin module%38FB57640359.includes preserve=yes
// $Date:   Apr 09 2004 12:38:38  $ $Author:   D02405  $ $Revision:   1.7  $
//## end module%38FB57640359.includes

#ifndef CXOSBP02_h
#include "CXODBP02.hpp"
#endif
#ifndef CXOSRS43_h
#include "CXODRS43.hpp"
#endif
//## begin module%38FB57640359.declarations preserve=no
//## end module%38FB57640359.declarations

//## begin module%38FB57640359.additionalDeclarations preserve=yes
//## end module%38FB57640359.additionalDeclarations


//## Modelname: Platform \: Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

//## begin b24messageprocessor::B24Status%38FB371800C5.preface preserve=yes
//## end b24messageprocessor::B24Status%38FB371800C5.preface

//## Class: B24Status%38FB371800C5
//	The B24Status class encapsulates the functions that
//	process a status message from an ACI Base24 online
//	switch in preparation for adding it to the DataNavigator
//	repository.
//## Category: Platform \: Base 24::B24MessageProcessor_CAT%38F232BC039B
//## Subsystem: BPDLL%38FB203D0324
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class DllExport B24Status : public B24Message  //## Inherits: <unnamed>%38FB37D70106
{
  //## begin b24messageprocessor::B24Status%38FB371800C5.initialDeclarations preserve=yes
  //## end b24messageprocessor::B24Status%38FB371800C5.initialDeclarations

  public:
    //## Constructors (generated)
      B24Status();

    //## Destructor (generated)
      virtual ~B24Status();


    //## Other Operations (specified)
      //## Operation: insert%38FB38650395
      //	This method contains all the logic required to convert
      //	an IBM network management record into an STS transaction.
      virtual bool insert (Message& hMessage);

      //## Operation: translateAscii%3916CDE802DD
      //	This method contains all the logic required to translate
      //	all ASCII fields within an IBM Network status record to
      //	EBCDIC format.
      virtual void translateAscii ();

    // Additional Public Declarations
      //## begin b24messageprocessor::B24Status%38FB371800C5.public preserve=yes
      //## end b24messageprocessor::B24Status%38FB371800C5.public

  protected:
    // Additional Protected Declarations
      //## begin b24messageprocessor::B24Status%38FB371800C5.protected preserve=yes
      //## end b24messageprocessor::B24Status%38FB371800C5.protected

  private:
    // Additional Private Declarations
      //## begin b24messageprocessor::B24Status%38FB371800C5.private preserve=yes
      //## end b24messageprocessor::B24Status%38FB371800C5.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: Base 24::B24MessageProcessor_CAT::<unnamed>%3DB92AD20119
      //## Role: B24Status::<m_hEntityStatusSegment>%3DB92AD2036B
      //## begin b24messageprocessor::B24Status::<m_hEntityStatusSegment>%3DB92AD2036B.role preserve=no  public: repositorysegment::EntityStatusSegment { -> VHgN}
      repositorysegment::EntityStatusSegment m_hEntityStatusSegment;
      //## end b24messageprocessor::B24Status::<m_hEntityStatusSegment>%3DB92AD2036B.role

    // Additional Implementation Declarations
      //## begin b24messageprocessor::B24Status%38FB371800C5.implementation preserve=yes
      //## end b24messageprocessor::B24Status%38FB371800C5.implementation

};

//## begin b24messageprocessor::B24Status%38FB371800C5.postscript preserve=yes
//## end b24messageprocessor::B24Status%38FB371800C5.postscript

} // namespace b24messageprocessor

//## begin module%38FB57640359.epilog preserve=yes
using namespace b24messageprocessor;
//## end module%38FB57640359.epilog


#endif
