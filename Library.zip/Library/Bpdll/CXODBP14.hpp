   //B24PTLFFinancial POS insert
   // |<html>
   // |<body>
   // |<title>CG</title>
   // |<h1>BI
   // |<h2>FI
   // |<h3>Base24 Financial Message
   // |<p>
   // |The DataNavigator financial transaction is populated from
   // |<p>
   // |<table border = "1">
   // |<tr><th>DataNavigator     <th>Base24 message
   UseCase hUseCase("B24","## BP14 READ B24 POS FINANCIAL",false);
   hB24PTLFTransaction* pB24Record = (hB24PTLFTransaction*)Message::instance(Message::INBOUND)->data();

   struct hTokenHeader
   {
      char sEyeCatcher[2];
      unsigned short siTokenCount;
      unsigned short siTokenDataLength;
   };

   struct hFinancialSegEyeCatcher
   {
      char sEyeCatcher[2];
      char sToken[2];
      unsigned short siTokenLength;
      char sTokenValue[2];
   };
   string strTranslateInValue;
   string strTranslateOutValue;
   size_t pos;
   reset();
   hFinancialSegEyeCatcher* pEyeCatcher = 0;
   if (pB24Record->cDataFlag == '1')
      pEyeCatcher = (hFinancialSegEyeCatcher*)((char*)pB24Record + 788 + ntohs(pB24Record->siUserDataLen));
   else
      pEyeCatcher = (hFinancialSegEyeCatcher*)((char*)pB24Record + 786);
   double dAmt1 = Segment::lltof(ntohl(pB24Record->lAmt1[0]),ntohl(pB24Record->lAmt1[1]));
   applyBounds(dAmt1);
   double dAmt2 = Segment::lltof(ntohl(pB24Record->lAmt2[0]),ntohl(pB24Record->lAmt2[1]));
   applyBounds(dAmt2);
   m_bReversal = (memcmp(pB24Record->sTyp,"0420",4) == 0);
      // |<tr><td>ACCT_ID_1<td>sAcctNum
   if (memcmp(pB24Record->sAcctNum,"0000000000000000000",19) != 0)
      m_hFinancialBaseSegment.setACCT_ID_1(pB24Record->sAcctNum,sizeof(pB24Record->sAcctNum));
      // |<tr><td>ACCT_TYPE_1<td>sTranCdeTc
   if (memcmp(pB24Record->sTranCdeTc,"76",2) == 0)
      m_hFinancialUserSegment.setACCT_TYPE_2("DDA",3);
   else
   if (memcmp(pB24Record->sTranCdeTc,"77",2) == 0 )
      m_hFinancialUserSegment.setACCT_TYPE_2("SAV",3);
   else
   if (memcmp(pB24Record->sTranCdeTc,"78",2) == 0 )
      m_hFinancialUserSegment.setACCT_TYPE_2("CRD",3);
   // |<tr><td>ACCT_TYPE_1<td>sTranCdeAa
   if (memcmp(pB24Record->sTranCdeAa,"00",2) == 0)
      m_hFinancialUserSegment.setACCT_TYPE_1("OTH",3);
   if (memcmp(pB24Record->sTranCdeAa,"01",2) == 0 )
      m_hFinancialUserSegment.setACCT_TYPE_1("DDA",3);
   else
   if (memcmp(pB24Record->sTranCdeAa,"11",2) == 0 )
      m_hFinancialUserSegment.setACCT_TYPE_1("SAV",3);
   else
   if (memcmp(pB24Record->sTranCdeAa,"31",2) == 0 )
      m_hFinancialUserSegment.setACCT_TYPE_1("CRD",3);
      // |<tr><td>APPROVAL_CODE  <td>sApprvCde
   m_hFinancialBaseSegment.setAPPROVAL_CODE(pB24Record->sApprvCde,6);
      // |<tr><td>CARD_ACPT_ID   <td>sRetlKyId
   m_hFinancialSettlementSegment.setCARD_ACPT_ID(pB24Record->sRetlKyId,15);
      // |<tr><td>CARD_ACPT_BUS_CODE   <td>sRetlSicCde
   m_hFinancialBaseSegment.setCARD_ACPT_BUS_CODE(pB24Record->sRetlSicCde,sizeof(pB24Record->sRetlSicCde));
      // |<tr><td>CARD_ACPT_NAME_LOC      <td>sTermNameLoc+sTermCity+sTermSt
   char sCardAcptInfo[85];
   memset(sCardAcptInfo,' ',sizeof(sCardAcptInfo));
   memcpy(sCardAcptInfo,pB24Record->sTermOwnerName,sizeof(pB24Record->sTermOwnerName));
   memcpy(sCardAcptInfo+26,pB24Record->sTermCity,sizeof(pB24Record->sTermCity));
   memcpy(sCardAcptInfo+39,pB24Record->sTermSt,3);
   m_hFinancialBaseSegment.setCARD_ACPT_NAME_LOC(sCardAcptInfo,84);
      // |<tr><td>CARD_ACPT_TERM_ID <td>sRetlTermId
   strTranslateInValue.assign(pB24Record->sRetlTermId,16);
   if ((pos = strTranslateInValue.find_first_of(' ')) != string::npos)
      strTranslateInValue.erase(pos);
   if(strTranslateInValue.length() > 0)
      m_hFinancialBaseSegment.setCARD_ACPT_TERM_ID(strTranslateInValue.data(),strTranslateInValue.length());
      // |<tr><td>CARD_TYPE<td>sTranCdeTc
   if(pB24Record->cTranCdeT == '2')
      m_hFinancialSettlementSegment.setCARD_TYPE("D",1);
   else
      m_hFinancialSettlementSegment.setCARD_TYPE("C",1);
      // |<tr><td>CLERK_ID <td>sTkeyClerkId
   m_hFinancialUserSegment.setCLERK_ID(pB24Record->sTkeyClerkId,6);
      // |<tr><td>DATE_EXP    <td>sExpDat
   if (m_bExpirationDate)
      m_hFinancialSettlementSegment.setDATE_EXP(pB24Record->sExpDat,sizeof(pB24Record->sExpDat));
      // |<tr><td>DRAFT_CAPTURE_FLG <td>cDftCaptureFlg
   m_hFinancialSettlementSegment.setDRAFT_CAPTURE_FLG(&pB24Record->cDftCaptureFlg,1);
      // |<tr><td>MERCH_TYPE      <td>sRetlSicCde
   m_hFinancialBaseSegment.setMERCH_TYPE(pB24Record->sRetlSicCde,sizeof(pB24Record->sRetlSicCde));
   if(m_bReversal)
   {
      // |<tr><td>O_AMT_RECON_NET      <td>Amt1 for reversal only
      m_hFinancialReversalSegment.setO_AMT_RECON_NET(dAmt1);
      // |<tr><td>ODE_MTI      <td>sOrigTranTimMM for reversal only
      m_hFinancialReversalSegment.setODE_MTI(pB24Record->sOrigMsgTyp,4);
   }
       // |<tr><td>POS_CARD_CAPT_CAP     <td>sPtSrvEntryMde
   if (memcmp(pB24Record->sPtSrvEntryMde,"02",2) == 0)
      m_hFinancialSettlementSegment.setPOS_CARD_CAPT_CAP("1",1);
   else
      m_hFinancialSettlementSegment.setPOS_CARD_CAPT_CAP("0",1);

   if (memcmp(pB24Record->sPtSrvEntryMde,"02",2) == 0)
      m_hFinancialSettlementSegment.setPOS_CRDHLDR_AUTH("2",1);
   else
   if (memcmp(pB24Record->sPtSrvEntryMde,"05",2) == 0)
      m_hFinancialSettlementSegment.setPOS_CRDHLDR_AUTH("1",1);
   else
      m_hFinancialSettlementSegment.setPOS_CRDHLDR_AUTH("0",1);
       // |<tr><td>POS_CRDHLDR_AUTH_C     <td>sPtSrvEntryMde
    if ((memcmp(pB24Record->sPtSrvEntryMde,"001",3) == 0) ||
        (memcmp(pB24Record->sPtSrvEntryMde,"011",3) == 0) ||
        (memcmp(pB24Record->sPtSrvEntryMde,"021",3) == 0) ||
        (memcmp(pB24Record->sPtSrvEntryMde,"031",3) == 0) ||
        (memcmp(pB24Record->sPtSrvEntryMde,"041",3) == 0) ||
        (memcmp(pB24Record->sPtSrvEntryMde,"051",3) == 0))
      m_hFinancialSettlementSegment.setPOS_CRDHLDR_AUTH_C("1",1);
   else
      m_hFinancialSettlementSegment.setPOS_CRDHLDR_AUTH_C("0",1);
   // |<tr><td>POS_CRDHLDR_PRESNT   <td>sPtSrvCondCde
   if (memcmp(pB24Record->sTrack2,";",1)==0)
   {
      m_hFinancialSettlementSegment.setPOS_CRDHLDR_PRESNT("0",1);
      m_hFinancialSettlementSegment.setPOS_CARD_PRES("1",1);
   }
   else if (memcmp(pB24Record->sTrack2,"M",1)==0)
   {
      m_hFinancialSettlementSegment.setPOS_CRDHLDR_PRESNT("1",1);
      m_hFinancialSettlementSegment.setPOS_CARD_PRES("0",1);
   }
   // |<tr><td>POS_OPER_ENV   <td>sPtSrvCondCde
   if ((memcmp(pB24Record->sPtSrvCondCde,"01",2) == 0) ||
       (memcmp(pB24Record->sPtSrvCondCde,"07",2) == 0) ||
       (memcmp(pB24Record->sPtSrvCondCde,"08",2) == 0))
       m_hFinancialSettlementSegment.setPOS_OPER_ENV("0",1);
   else
   if ((memcmp(pB24Record->sPtSrvCondCde,"02",2) == 0) ||
       (memcmp(pB24Record->sPtSrvCondCde,"14",2) == 0))
      m_hFinancialSettlementSegment.setPOS_OPER_ENV("2",1);
   else
   if (memcmp(pB24Record->sPtSrvCondCde,"15",2) == 0)
      m_hFinancialSettlementSegment.setPOS_OPER_ENV("5",1);
   else
      m_hFinancialSettlementSegment.setPOS_OPER_ENV("1",1);
      // |<tr><td>POS_TERM_OUT_CAP   <td>sPtSrvCondCde
   if ((memcmp(pB24Record->sPtSrvCondCde,"00",2) == 0) ||
       (memcmp(pB24Record->sPtSrvCondCde,"02",2) == 0) ||
       (memcmp(pB24Record->sPtSrvCondCde,"04",2) == 0) ||
       (memcmp(pB24Record->sPtSrvCondCde,"27",2) == 0))
      m_hFinancialSettlementSegment.setPOS_TERM_OUT_CAP("4",1);
   else
   if ((memcmp(pB24Record->sPtSrvCondCde,"07",2) == 0) ||
       (memcmp(pB24Record->sPtSrvCondCde,"08",2) == 0))
      m_hFinancialSettlementSegment.setPOS_TERM_OUT_CAP("1",1);
   else
      m_hFinancialSettlementSegment.setPOS_TERM_OUT_CAP("0",1);
      // |<tr><td>POS_CRD_DAT_IN_MOD      <td>sPtSrvEntryMde
   if (memcmp(pB24Record->sPtSrvEntryMde,"01",2) == 0)
      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("1",1);
   else
   if (memcmp(pB24Record->sPtSrvEntryMde,"02",2) == 0)
      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("2",1);
   else
   if (memcmp(pB24Record->sPtSrvEntryMde,"03",2) == 0)
      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("3",1);
   else
   if (memcmp(pB24Record->sPtSrvEntryMde,"04",2) == 0)
      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("4",1);
   else
   if (memcmp(pB24Record->sPtSrvEntryMde,"05",2) == 0
      || memcmp(pB24Record->sPtSrvEntryMde,"95",2) == 0)
      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("5",1);
   else
   if (memcmp(pB24Record->sPtSrvEntryMde,"06",2) == 0
      || memcmp(pB24Record->sPtSrvEntryMde,"07",2) == 0
      || memcmp(pB24Record->sPtSrvEntryMde,"08",2) == 0
      || memcmp(pB24Record->sPtSrvEntryMde,"92",2) == 0)
      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("M",1);
   else
   if (memcmp(pB24Record->sPtSrvEntryMde,"79",2) == 0)
      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("B",1);
   else
   if (memcmp(pB24Record->sPtSrvEntryMde,"80",2) == 0)
      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("C",1);
   else
   if (memcmp(pB24Record->sPtSrvEntryMde,"91",2) == 0)
      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("A",1);
   else
      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("0",1);
   // |<tr><td>POS_PIN_CAPT_CAP     <td>sPtSrvEntryMde
   if (memcmp(pB24Record->sPtSrvEntryMde+2,"2",1) == 0)
      m_hFinancialSettlementSegment.setPOS_PIN_CAPT_CAP("0",1);
   else
      m_hFinancialSettlementSegment.setPOS_PIN_CAPT_CAP("C",1);
   // |<tr><td>TRAN_CLASS     <td>POS
   if(memcmp(pB24Record->sRetlSicCde,"6011",4) == 0)
      m_hFinancialBaseSegment.setTRAN_CLASS("ATM",3);
   else
      m_hFinancialBaseSegment.setTRAN_CLASS("POS",3);
     // |<tr><td>FUNC_CODE      <td>sTyp
   if (memcmp(pB24Record->sTyp,"0110",4) == 0)
   {
      if ((memcmp(pB24Record->sTranCdeTc,"10",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"12",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"13",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"14",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"15",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"18",2) == 0))
      {
         m_hFinancialBaseSegment.setFUNC_CODE("100",3);
      }
      else
      if ((memcmp(pB24Record->sTranCdeTc,"16",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"17",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"19",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"20",2) == 0))
      {
         m_hFinancialBaseSegment.setFUNC_CODE("108",3);
      }
      else
      if (memcmp(pB24Record->sTranCdeTc,"11",2) == 0)
      {
         m_hFinancialBaseSegment.setFUNC_CODE("101",3);
      }
      else
      if (memcmp(pB24Record->sTranCdeTc,"2",1) == 0)
      {
         if (dAmt1 == dAmt2)
            m_hFinancialBaseSegment.setFUNC_CODE("100",3);
         else
            m_hFinancialBaseSegment.setFUNC_CODE("102",3);
      }
   }
   else
   if ((memcmp(pB24Record->sTyp,"0210",4) == 0) ||
       (memcmp(pB24Record->sTyp,"0220",4) == 0))
   {
      if ((memcmp(pB24Record->sTranCdeTc,"10",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"11",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"13",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"14",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"15",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"18",2) == 0))
      {
         m_hFinancialBaseSegment.setFUNC_CODE("200",3);
      }
      else
      if ((memcmp(pB24Record->sTranCdeTc,"16",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"17",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"19",2) == 0) ||
          (memcmp(pB24Record->sTranCdeTc,"20",2) == 0))
         m_hFinancialBaseSegment.setFUNC_CODE("108",3);
      else
      if (memcmp(pB24Record->sTranCdeTc,"12",2) == 0)
         m_hFinancialBaseSegment.setFUNC_CODE("202",3);
      else
      if (memcmp(pB24Record->sTranCdeTc,"2",1) == 0)
      {
         if (dAmt1 == dAmt2)
            m_hFinancialBaseSegment.setFUNC_CODE("201",3);
         else
            m_hFinancialBaseSegment.setFUNC_CODE("202",3);
      }
   }
   else
   if ((memcmp(pB24Record->sTyp,"0412",4) == 0) ||
       (memcmp(pB24Record->sTyp,"0420",4) == 0))
   {
      if (dAmt1 == dAmt2)
         m_hFinancialBaseSegment.setFUNC_CODE("400",3);
      else
         m_hFinancialBaseSegment.setFUNC_CODE("401",3);
   }
   if(memcmp(pB24Record->sTranCdeTc,"18",2) == 0) // cash back
   {
      m_hFinancialBaseSegment.setAMT_RECON_NET(dAmt1);
      m_hFinancialBaseSegment.setAMT_RECON_NET(dAmt1);
      m_hFinancialBaseSegment.setAMT_TRAN(dAmt1);
      m_hFinancialBaseSegment.setAMT_CARD_BILL(dAmt1);
      m_hFinancialSettlementSegment.setAMT_RECON_ACQ(dAmt1);
      m_hFinancialSettlementSegment.setAMT_RECON_ISS(dAmt1);
      m_hFinancialUserSegment.setADL_RQST_AMTn(ntohl(dAmt2),0);
      m_hFinancialUserSegment.setADL_RQST_AMT_TYPn("40",2,0);
      m_hFinancialUserSegment.setADL_RQST_CUR_CODEn(pB24Record->sOrigCrncyCde,3,0);

   }
   else
   if((memcmp(pB24Record->sTranCdeTc,"21",2) == 0) ||
      (memcmp(pB24Record->sTranCdeTc,"22",2) == 0) ||
      (memcmp(pB24Record->sTranCdeTc,"23",2) == 0) ||
      (memcmp(pB24Record->sTranCdeTc,"24",2) == 0) )
   {
      m_hFinancialAdjustmentSegment.setORIG_AMT_TRAN_ADJ(dAmt1);
      m_hFinancialBaseSegment.setAMT_RECON_NET(dAmt2);
      m_hFinancialBaseSegment.setAMT_RECON_NET(dAmt2);
      m_hFinancialBaseSegment.setAMT_TRAN(dAmt2);
      m_hFinancialBaseSegment.setAMT_CARD_BILL(dAmt2);
      m_hFinancialSettlementSegment.setAMT_RECON_ACQ(dAmt2);
      m_hFinancialSettlementSegment.setAMT_RECON_ISS(dAmt2);
   }
   else
   {
      m_hFinancialBaseSegment.setAMT_RECON_NET(dAmt1);
      m_hFinancialBaseSegment.setAMT_RECON_NET(dAmt1);
      m_hFinancialBaseSegment.setAMT_TRAN(dAmt1);
      m_hFinancialBaseSegment.setAMT_CARD_BILL(dAmt1);
      m_hFinancialSettlementSegment.setAMT_RECON_ACQ(dAmt1);
      m_hFinancialSettlementSegment.setAMT_RECON_ISS(dAmt1);
   }
      // |<tr><td>TERM_CLASS                  <td>sPtSrvCondCde
   if (memcmp(pB24Record->sPtSrvCondCde,"16",2) == 0)
      m_hFinancialSettlementSegment.setTERM_CLASS("00",2);
   else if (memcmp(pB24Record->sPtSrvCondCde,"42",2) == 0)
      m_hFinancialSettlementSegment.setTERM_CLASS("01",2);
   else if (memcmp(pB24Record->sPtSrvCondCde,"00",2) == 0)
      m_hFinancialSettlementSegment.setTERM_CLASS("01",2);
   else if (memcmp(pB24Record->sPtSrvCondCde,"41",2) == 0)
      m_hFinancialSettlementSegment.setTERM_CLASS("02",2);
   else if (memcmp(pB24Record->sPtSrvCondCde,"15",2) == 0)
      m_hFinancialSettlementSegment.setTERM_CLASS("03",2);
   else if (memcmp(pB24Record->sPtSrvCondCde,"04",2) == 0)
      m_hFinancialSettlementSegment.setTERM_CLASS("04",2);
   else if (memcmp(pB24Record->sPtSrvCondCde,"08",2) == 0)
      m_hFinancialSettlementSegment.setTERM_CLASS("05",2);
   else if (memcmp(pB24Record->sPtSrvCondCde,"43",2) == 0)
      m_hFinancialSettlementSegment.setTERM_CLASS("07",2);
   else if (memcmp(pB24Record->sPtSrvCondCde,"59",2) == 0)
      m_hFinancialSettlementSegment.setTERM_CLASS("25",2);
   else
      m_hFinancialSettlementSegment.setTERM_CLASS("01",2);
   if ((pB24Record->cOriginator == '6' ||
       pB24Record->cOriginator == '7' &&
       !(
         memcmp(m_strVNTFiid.data(),pB24Record->sTermFiid,m_strVNTFiid.length()) == 0 ||
         memcmp(m_strMCIFiid.data(),pB24Record->sTermFiid,m_strMCIFiid.length()) == 0
         )
       ) ||
       pB24Record->cOriginator == '1' ||
       pB24Record->cOriginator == '2' )
   {
      // |<tr><td>RETRIEVAL_REF_NO          <td>sInvoiceNum
      m_hFinancialBaseSegment.setRETRIEVAL_REF_NO(pB24Record->sInvoiceNum,sizeof(pB24Record->sInvoiceNum));
      // |<tr><td>SYS_TRACE_AUDIT_NO          <td>sSeqNum
      m_hFinancialBaseSegment.setSYS_TRACE_AUDIT_NO(pB24Record->sSeqNum+6,6);
   }
   else if(memcmp(m_strVNTFiid.data(),pB24Record->sTermFiid,m_strVNTFiid.length()) == 0)
   {
      // |<tr><td>RETRIEVAL_REF_NO          <td>sSeqNum
      m_hFinancialBaseSegment.setRETRIEVAL_REF_NO(pB24Record->sSeqNum,sizeof(pB24Record->sSeqNum));
      // |<tr><td>SYS_TRACE_AUDIT_NO          <td>sInvoiceNum
      m_hFinancialBaseSegment.setSYS_TRACE_AUDIT_NO(pB24Record->sInvoiceNum,6);
   }
   else if( memcmp(m_strMCIFiid.data(),pB24Record->sTermFiid,m_strMCIFiid.length()) == 0 )
   {
      // |<tr><td>SYS_TRACE_AUDIT_NO          <td>sSeqNum
      m_hFinancialBaseSegment.setSYS_TRACE_AUDIT_NO(pB24Record->sSeqNum,6);
   }
   // all translated values
      // |<tr><td>TRAN_TYPE_ID <td>X_B24_RESP_COD_POS[sTranCdeTc]
   strTranslateOutValue.erase();
   strTranslateInValue.assign(pB24Record->sTranCdeTc,6);   // sTranCdeTc + cTranCdeT + sTranCdeAa + cTranCdeC
   if (ConfigurationRepository::instance()->translate
         ("X_B24_PROC_COD_POS",strTranslateInValue,strTranslateOutValue,
         "FIN_LOCATOR", "TRAN_TYPE_ID", 0))
      m_hFinancialBaseSegment.setTRAN_TYPE_ID(strTranslateOutValue.data(),10);
      // |<tr><td>ACT_CODE <td>X_B24_RESP_COD_POS[sRespCde]
      // |</table>
      // |</body>
   if (m_bReversal)
   {
      m_hFinancialBaseSegment.setACT_CODE(
         memcmp(pB24Record->sRespCde,"000",3) == 0 ? "400" : "480",3);
   }
   else
   {
      strTranslateInValue.assign(pB24Record->sRespCde,3);
      strTranslateOutValue.erase();
      if (ConfigurationRepository::instance()->translate("X_B24_RESP_COD_POS",strTranslateInValue,strTranslateOutValue,
         "FIN_LOCATOR", "ACT_CODE", 0,false))
         m_hFinancialBaseSegment.setACT_CODE(strTranslateOutValue.data(),3);
      else
      {
         EvidenceSegment hEvidenceSegment;
         hEvidenceSegment.setSUSPECT_TABLE("X_B24_RESP_COD_POS");
         hEvidenceSegment.setPROBLEM_TABLE("FIN_LOCATOR");
         hEvidenceSegment.setPROBLEM_COLUMN("ACT_CODE");
         hEvidenceSegment.setSOURCE_VALUE(strTranslateInValue);
         hEvidenceSegment.setREASON_CODE(EVIDENCE_ACT_CODE_TRANSLATE_FAILURE);
         hEvidenceSegment.setTSTAMP_TRANS(m_hFinancialBaseSegment.zTSTAMP_TRANS());
         ConfigurationRepository::instance()->addEvidenceSegment(hEvidenceSegment);
      }
   }
      // |<tr><td>TRAN_DISPOSITION     <td>sRecTyp sRespCde reversal
   if (  memcmp(pB24Record->sRecTyp,"01",2) != 0  &&
         memcmp(pB24Record->sRecTyp,"20",2) != 0 )
      m_hFinancialBaseSegment.setTRAN_DISPOSITION("2",1);
   else if (m_bReversal)
      m_hFinancialBaseSegment.setTRAN_DISPOSITION("3",1);
   else if (m_hFinancialBaseSegment.zACT_CODE()[0] != '\0')
   {
      m_hFinancialBaseSegment.setTRAN_DISPOSITION(m_hFinancialBaseSegment.zACT_CODE()[0]== '0' ? "1" : "2",1);
   }
   // |<tr><td>TRACK_2_DATA<td>sTrack2
   if (m_bTrack2)
      m_hFinancialSettlementSegment.setTRACK_2_DATA(pB24Record->sTrack2,40);
   char szTRACK_2_DATA[41];
   memcpy(szTRACK_2_DATA,pB24Record->sTrack2,40);
   szTRACK_2_DATA[40] = '\0';
   char* psSRV_GRP_INTCHG_IND = strchr(szTRACK_2_DATA,'=');
   if (psSRV_GRP_INTCHG_IND)
   {
      psSRV_GRP_INTCHG_IND += 5;
      if (memcmp(psSRV_GRP_INTCHG_IND,"000",3) >= 0
         && memcmp(psSRV_GRP_INTCHG_IND,"999",3) <= 0)
      {
         m_hFinancialUserSegment.setSRV_GRP_INTCHG_IND(psSRV_GRP_INTCHG_IND,1);
         m_hFinancialUserSegment.setSRV_GRP_SERV_CODE(psSRV_GRP_INTCHG_IND + 1,2);
      }
   }


   struct hTag
   {
      unsigned char cTag;
      unsigned char cLength;
      char sValue[2];
   };
   unsigned char* psTag;
   unsigned char* psEnd;
   unsigned char cTag0 = 0;
   struct hTag* pTag;

   m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_CAP("0",1);

   char sEyeCatch[4];
   memset(sEyeCatch,' ',4);
   memcpy(sEyeCatch,pEyeCatcher->sEyeCatcher,2);
#ifdef MVS
   CodeTable::translate(sEyeCatch,2,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   if (sEyeCatch[0] == '&')
   {
      short siWorkingLength = 0;
      hTokenHeader* pTokenHeader = (hTokenHeader*)(char*)pEyeCatcher;
      short siDataLength = ntohs(pTokenHeader->siTokenDataLength);
      pEyeCatcher = (hFinancialSegEyeCatcher*)((char*)pEyeCatcher + 6);
      siDataLength -= 6;
      while (siDataLength > 0)
      {
         memcpy(sEyeCatch,pEyeCatcher->sEyeCatcher,4);
#ifdef MVS
         CodeTable::translate(sEyeCatch,4,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
         if (sEyeCatch[0] == '!')
         {
            short siTokenLength = ntohs(pEyeCatcher->siTokenLength);
#ifdef MVS
            if (  memcmp(sEyeCatch+2,"B4",2) == 0
               || memcmp(sEyeCatch+2,"B5",2) == 0
               || memcmp(sEyeCatch+2,"B6",2) == 0
               || memcmp(sEyeCatch+2,"PG",2) == 0
               || memcmp(sEyeCatch+2,"PS",2) == 0)
               CodeTable::translate(pEyeCatcher->sTokenValue,siTokenLength,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
            string strTemp(pEyeCatcher->sTokenValue,siTokenLength);
            if (memcmp(sEyeCatch+2,"B2",2) == 0)
            {
               ;
            }
            else if (memcmp(sEyeCatch+2,"B3",2) == 0)
            {
               //B3 GEN       CVM-RSLTS    ???
               char sBitMap[4];
               char psBits[4];
               int nFieldNum=0, nFixedPos=4;
               short   siVDFieldLen[8] =   {4+8,8,4,8,2,4,6,4+32};
               memcpy(sBitMap,strTemp.data(),4);
               for (int   i = 2; i<3;   i++)
               {
                  for (int   j = 0;j <= 3;++j)     // four fields per   byte
                  {
                     nFieldNum++;
                     if   (psBits[j] == '0')      //bit   is   set off
                        continue;
                     switch (nFieldNum)
                     {
                     case 7:
                        int iValue=   ntohl(*((int*)   (pEyeCatcher->sTokenValue + nFixedPos)));
                        if (iValue == 1)
                           m_hFinancialSettlementSegment.setCVV_CVC_RESULT("F",1);
                        if (iValue == 2)
                           m_hFinancialSettlementSegment.setCVV_CVC_RESULT("P",1);
                        if (iValue == 0)
                           m_hFinancialSettlementSegment.setCVV_CVC_RESULT("N",1);
                        //   needs   more findings ???
                        break;
                     } // end   of   case
                     nFixedPos += siVDFieldLen[nFieldNum];
                  }
               }
            }// end of B3
            else if (memcmp(sEyeCatch+2,"B4",2) == 0)
            {
               //B4 GEN       TERM-ENTRY_CAP                         ????? not needed
            }
            else if (memcmp(sEyeCatch+2,"B5",2) == 0)
            {
               //ISS_AUTH_DATA  - len Data
               char sLen[5];
               memset(sLen,'\0',sizeof(sLen));
               memcpy(sLen,strTemp.data(),2);
               m_hIntegratedCircuitCardSegment.setISS_AUTH_DATA(strTemp.data()+2,atoi(sLen));
               m_hIntegratedCircuitCardSegment.setPresence(true);
            }
            else if (memcmp(sEyeCatch+2,"B6",2) == 0)
            {
               //ISS_SCRIPT1_DATA len data max 128
               char sLen[5];
               memset(sLen,'\0',sizeof(sLen));
               memcpy(sLen,strTemp.data(),2);
               m_hIntegratedCircuitCardSegment.setISS_SCRIPT1_DATA(strTemp.data()+2,atoi(sLen));
               m_hIntegratedCircuitCardSegment.setPresence(true);
            }
            else if (memcmp(sEyeCatch+2,"PB",2) == 0)
            {
               m_hIntegratedCircuitCardSegment.setPresence(true);
               psTag = (unsigned char*)pEyeCatcher->sTokenValue + 3;
               char szLength[4] = {"   "};
               memcpy(szLength,pEyeCatcher->sTokenValue,3);
#ifdef MVS
               CodeTable::translate(szLength,3,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
               psEnd = (unsigned char*)pEyeCatcher + atoi(szLength) + 9;
               pTag = (struct hTag*)psTag;
               while (psTag < psEnd && *psTag != 0x00)
               {
                  cTag0 = *psTag;
                  if (*psTag == 0x5F)
                  {
                     ++psTag;
                     pTag = (struct hTag*)psTag;
                  }
                  else
                  if (*psTag == 0x9F)
                  {
                     ++psTag;
                     pTag = (struct hTag*)psTag;
                  }
                  else
                  {
                     cTag0 = 0;
                     pTag = (struct hTag*)psTag;
                  }
                  psTag += (pTag->cLength + 2);
                  switch (cTag0)
                  {
                     case 0x5F:
                        switch (pTag->cTag)
                        {
                           case 0x2A:
                              siWorkingLength = pTag->cLength > 2 ? 2 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setTRAN_CURRENCY_CODE(hexToChar(pTag->sValue,siWorkingLength).data() + 1,3);
                              break;
                        }
                     case 0x9F:
                        switch (pTag->cTag)
                        {
                           case 0x33:
                              siWorkingLength = pTag->cLength > 3 ? 3 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setTERM_CAPABILITIES(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x37:
                              siWorkingLength = pTag->cLength > 5 ? 5 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setUNPREDICTABLE_NO(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x1E:
                              siWorkingLength = pTag->cLength > 4 ? 4 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setTERM_SERIAL_NO(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x10:
                              siWorkingLength = pTag->cLength > 32 ? 32 : pTag->cLength;
                              if (*psTag == 0x9F)
                                 m_hIntegratedCircuitCardSegment.
                                    setISS_APPL_DATA(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              else
                              {
                                 m_hIntegratedCircuitCardSegment.
                                    setISS_APPL_DATA(hexToChar(pTag->sValue + 1,siWorkingLength).data(),siWorkingLength * 2);
                                 siWorkingLength = pTag->sValue[0] > 32 ? 32 : pTag->sValue[0];
                                 m_hIntegratedCircuitCardSegment.
                                    setISS_DISCR_DATA(hexToChar(pTag->sValue + 1 + pTag->cLength,siWorkingLength).data(),siWorkingLength * 2);
                                 psTag += (1 + pTag->sValue[0]);
                              }
                              break;
                           case 0x26:
                              siWorkingLength = pTag->cLength > 8 ? 8 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setAPPL_CRYPTOGRAM(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x36:
                              siWorkingLength = pTag->cLength > 2 ? 2 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setAPPL_TRAN_COUNTER(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x5B:
                              siWorkingLength = pTag->cLength > 20 ? 20 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setISS_SCRIPT_RESULT(hexToChar(pTag->sValue,siWorkingLength).c_str(),siWorkingLength * 2);
                              break;
                           case 0x1A:
                              siWorkingLength = pTag->cLength > 2 ? 2 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setTERM_COUNTRY_CODE(hexToChar(pTag->sValue,siWorkingLength).data() + 1,3);
                              break;
                           case 0x02:
                              siWorkingLength = pTag->cLength > 6 ? 6 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setCRYPTOGRAM_AMOUNT(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x03:
                              siWorkingLength = pTag->cLength > 6 ? 6 : pTag->cLength;
                              if (memcmp(pTag->sValue,"202020202020",siWorkingLength))
                                 m_hIntegratedCircuitCardSegment.
                                 setAMOUNT_OTHER(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x27:
                              siWorkingLength = pTag->cLength > 1 ? 1 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setCRYPT_INFO_DATA(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x34:
                              siWorkingLength = pTag->cLength > 3 ? 3 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setCARDH_VER_RESULT(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x35:
                              siWorkingLength = pTag->cLength > 1 ? 1 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setTERMINAL_TYPE(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x09:
                              siWorkingLength = pTag->cLength > 2 ? 2 : pTag->cLength;
                              if (memcmp(pTag->sValue,"2020",siWorkingLength))
                                 m_hIntegratedCircuitCardSegment.
                                    setAPPL_VERSION_NO(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x41:
                              siWorkingLength = pTag->cLength > 4 ? 4 : pTag->cLength;
                              if (memcmp(pTag->sValue,"20202020",siWorkingLength))
                                 m_hIntegratedCircuitCardSegment.
                                    setTRAN_SEQ_COUNTER(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x53:
                              siWorkingLength = pTag->cLength > 1 ? 1 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setTRAN_CATEGORY_CODE(hexToChar(pTag->sValue,siWorkingLength).data() + 1,1);
                              break;
                        }
                     case 0x00:
                        switch (pTag->cTag)
                        {
                           case 0x95:
                              siWorkingLength = pTag->cLength > 5 ? 5 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setTERM_VERIFY_RESULT(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x82:
                              siWorkingLength = pTag->cLength > 2 ? 2 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setAPPL_INTRCHG_PROF(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x91:
                              siWorkingLength = pTag->cLength > 16 ? 16 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setISS_AUTH_DATA(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x71:
                              siWorkingLength = pTag->cLength > 255 ? 255 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setISS_SCRIPT1_DATA(hexToChar(pTag->sValue,siWorkingLength).c_str(),siWorkingLength * 2);
                              break;
                           case 0x9C:
                              siWorkingLength = pTag->cLength > 1 ? 1 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setTRAN_TYPE(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x9A:
                              siWorkingLength = pTag->cLength > 3 ? 3 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setTRAN_DATE(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x84:
                              siWorkingLength = pTag->cLength > 8 ? 8 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setDEDICATED_FILE_NAM(hexToChar(pTag->sValue,siWorkingLength).data(),siWorkingLength * 2);
                              break;
                           case 0x72:
                              siWorkingLength = pTag->cLength > 255 ? 255 : pTag->cLength;
                              m_hIntegratedCircuitCardSegment.
                                 setISS_SCRIPT2_DATA(hexToChar(pTag->sValue,siWorkingLength).c_str(),siWorkingLength * 2);
                              break;
                        }

                  }
               }
            }
            else if (memcmp(sEyeCatch+2,"PG",2) == 0)
            {
               // |<tr><td>POS_CRDHLDR_A_METH<td>PG token CVF^FLAG
               m_hFinancialBaseSegment.setPOS_CRDHLDR_A_METH(pEyeCatcher->sTokenValue + 1,1);
               // |<tr><td>POS_CRD_DAT_IN_CAP     <td>sPtSrvEntryMde
               if (pEyeCatcher->sTokenValue[2] == '1')
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_CAP("1",1);
               else
               if (pEyeCatcher->sTokenValue[2] == '2')
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_CAP("2",1);
               else
               if (pEyeCatcher->sTokenValue[2] == '3'
                  || pEyeCatcher->sTokenValue[2] == '4')
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_CAP("A",1);
               else
               if (pEyeCatcher->sTokenValue[2] == '5')
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_CAP("5",1);
               else
               if (pEyeCatcher->sTokenValue[2] == '8')
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_CAP("M",1);
            }
            else if (memcmp(sEyeCatch+2,"PS",2) == 0)
            {
               struct hPanTokenInfo
               {
                  char sTokenIndicator[1];
                  char sAcctNumIndicator[1];
				  char sAccoutNumber[19];
				  char sExpireDate[4];
				  char sTokenAssuranceLvl[2];
				  char sTokenRequestorID[11];
				  char sVisaAKMResult[2];
               };
               hPanTokenInfo * pPanTokenInfo   = (hPanTokenInfo*)((char *)pEyeCatcher->sTokenValue);
               m_hFinancialUserSegment.setPAN_TOKEN(pPanTokenInfo->sAccoutNumber,sizeof(pPanTokenInfo->sAccoutNumber));
               m_hFinancialUserSegment.setTOKEN_EXP_DATE(pPanTokenInfo->sExpireDate,sizeof(pPanTokenInfo->sExpireDate));
               m_hFinancialUserSegment.setTOKEN_ASSURANCE(pPanTokenInfo->sTokenAssuranceLvl,sizeof(pPanTokenInfo->sTokenAssuranceLvl));
               m_hFinancialUserSegment.setTOKEN_REQUESTOR_ID(pPanTokenInfo->sTokenRequestorID,sizeof(pPanTokenInfo->sTokenRequestorID));
			   if (memcmp(m_hFinancialSettlementSegment.zPOS_CRD_DAT_IN_MOD(),"0",1) == 0)
			      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("7",1);
               else if (memcmp(m_hFinancialSettlementSegment.zPOS_CRD_DAT_IN_MOD(),"1",1) == 0)
			      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("8",1);
               else if (memcmp(m_hFinancialSettlementSegment.zPOS_CRD_DAT_IN_MOD(),"2",1) == 0)
			      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("O",1);
               else if (memcmp(m_hFinancialSettlementSegment.zPOS_CRD_DAT_IN_MOD(),"3",1) == 0)
			      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("P",1);
               else if (memcmp(m_hFinancialSettlementSegment.zPOS_CRD_DAT_IN_MOD(),"4",1) == 0)
			      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("Q",1);
               else if (memcmp(m_hFinancialSettlementSegment.zPOS_CRD_DAT_IN_MOD(),"5",1) == 0)
			      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("X",1);
               else if (memcmp(m_hFinancialSettlementSegment.zPOS_CRD_DAT_IN_MOD(),"A",1) == 0)
			      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("D",1);
               else if (memcmp(m_hFinancialSettlementSegment.zPOS_CRD_DAT_IN_MOD(),"B",1) == 0)
			      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("E",1);
               else if (memcmp(m_hFinancialSettlementSegment.zPOS_CRD_DAT_IN_MOD(),"C",1) == 0)
			      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("F",1);
               else if (memcmp(m_hFinancialSettlementSegment.zPOS_CRD_DAT_IN_MOD(),"M",1) == 0)
			      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("G",1);
            }
            siDataLength -= (siTokenLength + 6);
            pEyeCatcher = (hFinancialSegEyeCatcher*)((char*)pEyeCatcher + siTokenLength + 6);
         }
         else
            siDataLength = 0;
      } // end   of   while
   }// end of if Eye Catcher

	//Reset pEyeCatcher for BP12
   if (pB24Record->cDataFlag == '1')
      pEyeCatcher = (hFinancialSegEyeCatcher*)((char*)pB24Record + 788 + ntohs(pB24Record->siUserDataLen));
   else
      pEyeCatcher = (hFinancialSegEyeCatcher*)((char*)pB24Record + 786);