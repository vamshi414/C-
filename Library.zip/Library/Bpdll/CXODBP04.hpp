//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%38FB56C70226.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%38FB56C70226.cm

//## begin module%38FB56C70226.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%38FB56C70226.cp

//## Module: CXOSBP04%38FB56C70226; Package specification
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Pvcswork\Dn\Server\Library\BPDLL\CXODBP04.hpp

#ifndef CXOSBP04_h
#define CXOSBP04_h 1

//## begin module%38FB56C70226.additionalIncludes preserve=no
//## end module%38FB56C70226.additionalIncludes

//## begin module%38FB56C70226.includes preserve=yes
// $Date:   Apr 09 2004 12:38:42  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%38FB56C70226.includes

#ifndef CXOSBP02_h
#include "CXODBP02.hpp"
#endif
#ifndef CXOSRS09_h
#include "CXODRS09.hpp"
#endif
//## begin module%38FB56C70226.declarations preserve=no
//## end module%38FB56C70226.declarations

//## begin module%38FB56C70226.additionalDeclarations preserve=yes
//## end module%38FB56C70226.additionalDeclarations


//## Modelname: Platform \: Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

//## begin b24messageprocessor::B24TLFAdmin%38FB17000125.preface preserve=yes
//## end b24messageprocessor::B24TLFAdmin%38FB17000125.preface

//## Class: B24TLFAdmin%38FB17000125
//	The B24TLFAdmin class encapsulates the functions that
//	process a network management message from an ACI Base24
//	online switch in preparation for adding it to the Data
//	Navigator repository.
//## Category: Platform \: Base 24::B24MessageProcessor_CAT%38F232BC039B
//## Subsystem: BPDLL%38FB203D0324
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class DllExport B24TLFAdmin : public B24Message  //## Inherits: <unnamed>%38FB2B130124
{
  //## begin b24messageprocessor::B24TLFAdmin%38FB17000125.initialDeclarations preserve=yes
  //## end b24messageprocessor::B24TLFAdmin%38FB17000125.initialDeclarations

  public:
    //## Constructors (generated)
      B24TLFAdmin();

    //## Destructor (generated)
      virtual ~B24TLFAdmin();


    //## Other Operations (specified)
      //## Operation: insert%38FB35EC01FA
      //	This method contains all the logic required to convert
      //	an IBM network management record into an STS transaction.
      virtual bool insert (Message& hMessage);

      //## Operation: translateAscii%3916CD5C02AA
      //	This method contains all the logic required to translate
      //	all ASCII fields within an IBM Network management record
      //	to EBCDIC format.
      virtual void translateAscii ();

    // Additional Public Declarations
      //## begin b24messageprocessor::B24TLFAdmin%38FB17000125.public preserve=yes
      //## end b24messageprocessor::B24TLFAdmin%38FB17000125.public

  protected:
    // Additional Protected Declarations
      //## begin b24messageprocessor::B24TLFAdmin%38FB17000125.protected preserve=yes
      //## end b24messageprocessor::B24TLFAdmin%38FB17000125.protected

  private:
    // Additional Private Declarations
      //## begin b24messageprocessor::B24TLFAdmin%38FB17000125.private preserve=yes
      //## end b24messageprocessor::B24TLFAdmin%38FB17000125.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: Base 24::B24MessageProcessor_CAT::<unnamed>%38FB610D0282
      //## Role: B24TLFAdmin::<m_hCutoffSegment>%38FB610E0161
      //## begin b24messageprocessor::B24TLFAdmin::<m_hCutoffSegment>%38FB610E0161.role preserve=no  public: repositorysegment::CutoffSegment { -> VHgN}
      repositorysegment::CutoffSegment m_hCutoffSegment;
      //## end b24messageprocessor::B24TLFAdmin::<m_hCutoffSegment>%38FB610E0161.role

    // Additional Implementation Declarations
      //## begin b24messageprocessor::B24TLFAdmin%38FB17000125.implementation preserve=yes
      //## end b24messageprocessor::B24TLFAdmin%38FB17000125.implementation

};

//## begin b24messageprocessor::B24TLFAdmin%38FB17000125.postscript preserve=yes
//## end b24messageprocessor::B24TLFAdmin%38FB17000125.postscript

} // namespace b24messageprocessor

//## begin module%38FB56C70226.epilog preserve=yes
using namespace b24messageprocessor;
//## end module%38FB56C70226.epilog


#endif
