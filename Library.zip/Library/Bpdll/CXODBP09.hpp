//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%390DAF8C02F6.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%390DAF8C02F6.cm

//## begin module%390DAF8C02F6.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%390DAF8C02F6.cp

//## Module: CXOSBP09%390DAF8C02F6; Package specification
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Pvcswork\Dn\Server\Library\BPDLL\CXODBP09.hpp

#ifndef CXOSBP09_h
#define CXOSBP09_h 1

//## begin module%390DAF8C02F6.additionalIncludes preserve=no
//## end module%390DAF8C02F6.additionalIncludes

//## begin module%390DAF8C02F6.includes preserve=yes
// $Date:   Apr 09 2004 12:38:42  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%390DAF8C02F6.includes

#ifndef CXOSBP02_h
#include "CXODBP02.hpp"
#endif
#ifndef CXOSRS09_h
#include "CXODRS09.hpp"
#endif
//## begin module%390DAF8C02F6.declarations preserve=no
//## end module%390DAF8C02F6.declarations

//## begin module%390DAF8C02F6.additionalDeclarations preserve=yes
//## end module%390DAF8C02F6.additionalDeclarations


//## Modelname: Platform \: Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

//## begin b24messageprocessor::B24PTLFAdmin%390DAE4B0218.preface preserve=yes
//## end b24messageprocessor::B24PTLFAdmin%390DAE4B0218.preface

//## Class: B24PTLFAdmin%390DAE4B0218
//	The B24PTLFAdmin class encapsulates the functions that
//	process a network management message from an ACI Base24
//	online switch in preparation for adding it to the Data
//	Navigator repository.
//## Category: Platform \: Base 24::B24MessageProcessor_CAT%38F232BC039B
//## Subsystem: BPDLL%38FB203D0324
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class DllExport B24PTLFAdmin : public B24Message  //## Inherits: <unnamed>%390DAEA9008D
{
  //## begin b24messageprocessor::B24PTLFAdmin%390DAE4B0218.initialDeclarations preserve=yes
  //## end b24messageprocessor::B24PTLFAdmin%390DAE4B0218.initialDeclarations

  public:
    //## Constructors (generated)
      B24PTLFAdmin();

    //## Destructor (generated)
      virtual ~B24PTLFAdmin();


    //## Other Operations (specified)
      //## Operation: insert%390DAEE10282
      //	This method contains all the logic required to convert
      //	an IBM network management record into an STS transaction.
      virtual bool insert (Message& hMessage);

      //## Operation: translateAscii%3916CEF2016D
      //	This method contains all the logic required to translate
      //	all ASCII fields within an IBM Network management record
      //	to EBCDIC format.
      virtual void translateAscii ();

    // Additional Public Declarations
      //## begin b24messageprocessor::B24PTLFAdmin%390DAE4B0218.public preserve=yes
      //## end b24messageprocessor::B24PTLFAdmin%390DAE4B0218.public

  protected:
    // Additional Protected Declarations
      //## begin b24messageprocessor::B24PTLFAdmin%390DAE4B0218.protected preserve=yes
      //## end b24messageprocessor::B24PTLFAdmin%390DAE4B0218.protected

  private:
    // Additional Private Declarations
      //## begin b24messageprocessor::B24PTLFAdmin%390DAE4B0218.private preserve=yes
      //## end b24messageprocessor::B24PTLFAdmin%390DAE4B0218.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: Base 24::B24MessageProcessor_CAT::<unnamed>%390DAF2E005C
      //## Role: B24PTLFAdmin::<m_hCutoffSegment>%390DAF2E0283
      //## begin b24messageprocessor::B24PTLFAdmin::<m_hCutoffSegment>%390DAF2E0283.role preserve=no  public: repositorysegment::CutoffSegment { -> VHgN}
      repositorysegment::CutoffSegment m_hCutoffSegment;
      //## end b24messageprocessor::B24PTLFAdmin::<m_hCutoffSegment>%390DAF2E0283.role

    // Additional Implementation Declarations
      //## begin b24messageprocessor::B24PTLFAdmin%390DAE4B0218.implementation preserve=yes
      //## end b24messageprocessor::B24PTLFAdmin%390DAE4B0218.implementation

};

//## begin b24messageprocessor::B24PTLFAdmin%390DAE4B0218.postscript preserve=yes
//## end b24messageprocessor::B24PTLFAdmin%390DAE4B0218.postscript

} // namespace b24messageprocessor

//## begin module%390DAF8C02F6.epilog preserve=yes
using namespace b24messageprocessor;
//## end module%390DAF8C02F6.epilog


#endif
