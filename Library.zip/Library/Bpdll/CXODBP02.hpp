//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38FB3C7C0079.cm preserve=no
//	$Date:   Aug 30 2013 05:05:48  $ $Author:   e3003354  $
//	$Revision:   1.13  $
//## end module%38FB3C7C0079.cm

//## begin module%38FB3C7C0079.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%38FB3C7C0079.cp

//## Module: CXOSBP02%38FB3C7C0079; Package specification
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Devel\Dn\Server\Library\Bpdll\CXODBP02.hpp

#ifndef CXOSBP02_h
#define CXOSBP02_h 1

//## begin module%38FB3C7C0079.additionalIncludes preserve=no
//## end module%38FB3C7C0079.additionalIncludes

//## begin module%38FB3C7C0079.includes preserve=yes
//## end module%38FB3C7C0079.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSRS10_h
#include "CXODRS10.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;

} // namespace IF

//## begin module%38FB3C7C0079.declarations preserve=no
//## end module%38FB3C7C0079.declarations

//## begin module%38FB3C7C0079.additionalDeclarations preserve=yes
//## end module%38FB3C7C0079.additionalDeclarations


//## Modelname: Platform \: ACI Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

//## begin b24messageprocessor::B24Message%38FB16E00332.preface preserve=yes
//## end b24messageprocessor::B24Message%38FB16E00332.preface

//## Class: B24Message%38FB16E00332
//	The B24Message class encapsulates the functions that
//	process all messages from an ACI Base24 online switch in
//	preparation for adding them to the DataNavigator
//	repository.
//## Category: Platform \: ACI Base 24::B24MessageProcessor_CAT%38F232BC039B
//## Subsystem: BPDLL%38FB203D0324
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C6921B203C8;IF::Message { -> F}
//## Uses: <unnamed>%4CC921F700EC;reusable::Buffer { -> F}
//## Uses: <unnamed>%4F22F44A0351;IF::CodeTable { -> F}

class DllExport B24Message : public reusable::Object  //## Inherits: <unnamed>%38FB20CF00DF
{
  //## begin b24messageprocessor::B24Message%38FB16E00332.initialDeclarations preserve=yes
  //## end b24messageprocessor::B24Message%38FB16E00332.initialDeclarations

  public:
    //## Constructors (generated)
      B24Message();

    //## Constructors (specified)
      //## Operation: B24Message%38FB21F50042
      B24Message (const char* pszTranType, const char* pszSegmentID);

    //## Destructor (generated)
      virtual ~B24Message();


    //## Other Operations (specified)
      //## Operation: convertBitMap%521CB8A301B5
      void convertBitMap (const char cCharBit, char* psBits);

      //## Operation: hexToChar%4F22D7750251
      string hexToChar (const char* psBuffer, int iLength);

      //## Operation: insert%38FB21E601EF
      //	virtual method to be re-implemented
      virtual bool insert (IF::Message& hMessage);

      //## Operation: translateAscii%3916CA4F03DD
      //	virtual method to be re-implemented
      virtual void translateAscii ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: SegmentID%3C69213501F4
      const string& getSegmentID () const
      {
        //## begin b24messageprocessor::B24Message::getSegmentID%3C69213501F4.get preserve=no
        return m_strSegmentID;
        //## end b24messageprocessor::B24Message::getSegmentID%3C69213501F4.get
      }


      //## Attribute: TestDate%3C692022032C
      static const string& getTestDate ();
      static void setTestDate (const string& value);

      //## Attribute: MCIFiid%4DECA8970167
      const string& getMCIFiid () const
      {
        //## begin b24messageprocessor::B24Message::getMCIFiid%4DECA8970167.get preserve=no
        return m_strMCIFiid;
        //## end b24messageprocessor::B24Message::getMCIFiid%4DECA8970167.get
      }

      void setMCIFiid (const string& value)
      {
        //## begin b24messageprocessor::B24Message::setMCIFiid%4DECA8970167.set preserve=no
        m_strMCIFiid = value;
        //## end b24messageprocessor::B24Message::setMCIFiid%4DECA8970167.set
      }


      //## Attribute: VNTFiid%4DECA8970177
      const string& getVNTFiid () const
      {
        //## begin b24messageprocessor::B24Message::getVNTFiid%4DECA8970177.get preserve=no
        return m_strVNTFiid;
        //## end b24messageprocessor::B24Message::getVNTFiid%4DECA8970177.get
      }

      void setVNTFiid (const string& value)
      {
        //## begin b24messageprocessor::B24Message::setVNTFiid%4DECA8970177.set preserve=no
        m_strVNTFiid = value;
        //## end b24messageprocessor::B24Message::setVNTFiid%4DECA8970177.set
      }


    // Data Members for Class Attributes

      //## begin b24messageprocessor::B24Message::MCIFiid%4DECA8970167.attr preserve=no  public: string {U} 
      string m_strMCIFiid;
      //## end b24messageprocessor::B24Message::MCIFiid%4DECA8970167.attr

      //## begin b24messageprocessor::B24Message::VNTFiid%4DECA8970177.attr preserve=no  public: string {U} 
      string m_strVNTFiid;
      //## end b24messageprocessor::B24Message::VNTFiid%4DECA8970177.attr

    // Additional Public Declarations
      //## begin b24messageprocessor::B24Message%38FB16E00332.public preserve=yes
      vector<int> m_hCanisterValues;
      //## end b24messageprocessor::B24Message%38FB16E00332.public
  protected:

    //## Other Operations (specified)
      //## Operation: applyBounds%4E1FDC5E0202
      //	virtual method to be re-implemented
      virtual void applyBounds (double &dAmount);

    // Data Members for Class Attributes

      //## Attribute: UniquenessKey%3C691FE2005D
      //## begin b24messageprocessor::B24Message::UniquenessKey%3C691FE2005D.attr preserve=no  protected: short {VA} 0
      short m_siUniquenessKey;
      //## end b24messageprocessor::B24Message::UniquenessKey%3C691FE2005D.attr

    // Data Members for Associations

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%3C698A1203B9
      //## Role: B24Message::<m_hAuditSegment>%3C698A130280
      //## begin b24messageprocessor::B24Message::<m_hAuditSegment>%3C698A130280.role preserve=no  protected: repositorysegment::AuditSegment { -> VHgAN}
      repositorysegment::AuditSegment m_hAuditSegment;
      //## end b24messageprocessor::B24Message::<m_hAuditSegment>%3C698A130280.role

    // Additional Protected Declarations
      //## begin b24messageprocessor::B24Message%38FB16E00332.protected preserve=yes
      //## end b24messageprocessor::B24Message%38FB16E00332.protected

  private:
    // Additional Private Declarations
      //## begin b24messageprocessor::B24Message%38FB16E00332.private preserve=yes
      //## end b24messageprocessor::B24Message%38FB16E00332.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin b24messageprocessor::B24Message::SegmentID%3C69213501F4.attr preserve=no  public: string {V} 
      string m_strSegmentID;
      //## end b24messageprocessor::B24Message::SegmentID%3C69213501F4.attr

      //## begin b24messageprocessor::B24Message::TestDate%3C692022032C.attr preserve=no  public: static string {U} 
      static string m_strTestDate;
      //## end b24messageprocessor::B24Message::TestDate%3C692022032C.attr

      //## Attribute: TranType%38FB21C001F4
      //## begin b24messageprocessor::B24Message::TranType%38FB21C001F4.attr preserve=no  public: string {V} 
      string m_strTranType;
      //## end b24messageprocessor::B24Message::TranType%38FB21C001F4.attr

    // Additional Implementation Declarations
      //## begin b24messageprocessor::B24Message%38FB16E00332.implementation preserve=yes
      //## end b24messageprocessor::B24Message%38FB16E00332.implementation

};

//## begin b24messageprocessor::B24Message%38FB16E00332.postscript preserve=yes
//## end b24messageprocessor::B24Message%38FB16E00332.postscript

} // namespace b24messageprocessor

//## begin module%38FB3C7C0079.epilog preserve=yes
using namespace b24messageprocessor;
//## end module%38FB3C7C0079.epilog


#endif
