//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%390DAD0A027B.cm preserve=no
//	$Date:   Nov 06 2013 11:26:00  $ $Author:   e1014316  $
//	$Revision:   1.17  $
//## end module%390DAD0A027B.cm

//## begin module%390DAD0A027B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%390DAD0A027B.cp

//## Module: CXOSBP08%390DAD0A027B; Package specification
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Devel\DN\Server\Library\Bpdll\CXODBP08.hpp

#ifndef CXOSBP08_h
#define CXOSBP08_h 1

//## begin module%390DAD0A027B.additionalIncludes preserve=no
//## end module%390DAD0A027B.additionalIncludes

//## begin module%390DAD0A027B.includes preserve=yes
// $Date:   Nov 06 2013 11:26:00  $ $Author:   e1014316  $ $Revision:   1.17  $
//## end module%390DAD0A027B.includes

#ifndef CXOSBP02_h
#include "CXODBP02.hpp"
#endif
#ifndef CXOSRS89_h
#include "CXODRS89.hpp"
#endif
#ifndef CXOSRS88_h
#include "CXODRS88.hpp"
#endif
#ifndef CXOSRS87_h
#include "CXODRS87.hpp"
#endif
#ifndef CXOSRS70_h
#include "CXODRS70.hpp"
#endif
#ifndef CXOSRS40_h
#include "CXODRS40.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSRS39_h
#include "CXODRS39.hpp"
#endif
#ifndef CXOSRS37_h
#include "CXODRS37.hpp"
#endif
#ifndef CXOSRS36_h
#include "CXODRS36.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class SwitchInterface;
} // namespace switchinterface

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
class EvidenceSegment;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Timestamp;
class CodeTable;
class Message;
class DateTime;
class Trace;
class Log;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class GMT;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ListSegment;

} // namespace segment

//## begin module%390DAD0A027B.declarations preserve=no
//## end module%390DAD0A027B.declarations

//## begin module%390DAD0A027B.additionalDeclarations preserve=yes
//## end module%390DAD0A027B.additionalDeclarations


//## Modelname: Platform \: ACI Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

//## begin b24messageprocessor::B24PTLFFinancial%390DA89F00E4.preface preserve=yes
//## end b24messageprocessor::B24PTLFFinancial%390DA89F00E4.preface

//## Class: B24PTLFFinancial%390DA89F00E4
//	The B24PTLFFinancial class encapsulates the functions
//	that process a financial message from an ACI Base24
//	online switch in preparation for adding it to the Data
//	Navigator repository.
//## Category: Platform \: ACI Base 24::B24MessageProcessor_CAT%38F232BC039B
//## Subsystem: BPDLL%38FB203D0324
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3936D0210203;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3936D04B025E;IF::Log { -> F}
//## Uses: <unnamed>%3936D05002FB;IF::Trace { -> F}
//## Uses: <unnamed>%3936D054024C;IF::CodeTable { -> F}
//## Uses: <unnamed>%3936D0580298;IF::DateTime { -> F}
//## Uses: <unnamed>%3936D05C0384;IF::Message { -> F}
//## Uses: <unnamed>%3936D06202B1;switchinterface::SwitchInterface { -> F}
//## Uses: <unnamed>%4C10BA1500B7;monitor::UseCase { -> F}
//## Uses: <unnamed>%4C10BA610372;entitysegment::Customer { -> F}
//## Uses: <unnamed>%4C2B2785009B;IF::Timestamp { -> F}
//## Uses: <unnamed>%4C2B27E5014E;timer::GMT { -> F}
//## Uses: <unnamed>%4CC92407019E;reusable::Buffer { -> F}
//## Uses: <unnamed>%4D7511000382;configuration::EvidenceSegment { -> F}
//## Uses: <unnamed>%5231C5770364;segment::ListSegment { -> F}

class DllExport B24PTLFFinancial : public B24Message  //## Inherits: <unnamed>%390DAB79002F
{
  //## begin b24messageprocessor::B24PTLFFinancial%390DA89F00E4.initialDeclarations preserve=yes
  //## end b24messageprocessor::B24PTLFFinancial%390DA89F00E4.initialDeclarations

  public:
    //## Constructors (generated)
      B24PTLFFinancial();

    //## Destructor (generated)
      virtual ~B24PTLFFinancial();


    //## Other Operations (specified)
      //## Operation: insert%390DA8D900D3
      //	This method contains all the logic required to convert
      //	an IBM financial record into an STS transaction.
      virtual bool insert (Message& hMessage);

      //## Operation: translateAscii%3916CECF0253
      //	This method contains all the logic required to translate
      //	all ASCII fields within an IBM financial record to
      //	EBCDIC format.
      virtual void translateAscii ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: B24AsciiInput%4C10D5D9033C
      const bool& getB24AsciiInput () const
      {
        //## begin b24messageprocessor::B24PTLFFinancial::getB24AsciiInput%4C10D5D9033C.get preserve=no
        return m_bB24AsciiInput;
        //## end b24messageprocessor::B24PTLFFinancial::getB24AsciiInput%4C10D5D9033C.get
      }

      void setB24AsciiInput (const bool& value)
      {
        //## begin b24messageprocessor::B24PTLFFinancial::setB24AsciiInput%4C10D5D9033C.set preserve=no
        m_bB24AsciiInput = value;
        //## end b24messageprocessor::B24PTLFFinancial::setB24AsciiInput%4C10D5D9033C.set
      }


      //## Attribute: DST%4C2B264D02E3
      const bool& getDST () const
      {
        //## begin b24messageprocessor::B24PTLFFinancial::getDST%4C2B264D02E3.get preserve=no
        return m_bDST;
        //## end b24messageprocessor::B24PTLFFinancial::getDST%4C2B264D02E3.get
      }

      void setDST (const bool& value)
      {
        //## begin b24messageprocessor::B24PTLFFinancial::setDST%4C2B264D02E3.set preserve=no
        m_bDST = value;
        //## end b24messageprocessor::B24PTLFFinancial::setDST%4C2B264D02E3.set
      }


      //## Attribute: DSTBeginEnd%4CA3314C031F
      const string& getDSTBeginEnd () const
      {
        //## begin b24messageprocessor::B24PTLFFinancial::getDSTBeginEnd%4CA3314C031F.get preserve=no
        return m_strDSTBeginEnd;
        //## end b24messageprocessor::B24PTLFFinancial::getDSTBeginEnd%4CA3314C031F.get
      }

      void setDSTBeginEnd (const string& value)
      {
        //## begin b24messageprocessor::B24PTLFFinancial::setDSTBeginEnd%4CA3314C031F.set preserve=no
        m_strDSTBeginEnd = value;
        //## end b24messageprocessor::B24PTLFFinancial::setDSTBeginEnd%4CA3314C031F.set
      }


      //## Attribute: GMTOffset%4C2B264D02F2
      const int& getGMTOffset () const
      {
        //## begin b24messageprocessor::B24PTLFFinancial::getGMTOffset%4C2B264D02F2.get preserve=no
        return m_iGMTOffset;
        //## end b24messageprocessor::B24PTLFFinancial::getGMTOffset%4C2B264D02F2.get
      }

      void setGMTOffset (const int& value)
      {
        //## begin b24messageprocessor::B24PTLFFinancial::setGMTOffset%4C2B264D02F2.set preserve=no
        m_iGMTOffset = value;
        //## end b24messageprocessor::B24PTLFFinancial::setGMTOffset%4C2B264D02F2.set
      }


      //## Attribute: Track2%4CBEFB50007A
      void setTrack2 (const bool& value)
      {
        //## begin b24messageprocessor::B24PTLFFinancial::setTrack2%4CBEFB50007A.set preserve=no
        m_bTrack2 = value;
        //## end b24messageprocessor::B24PTLFFinancial::setTrack2%4CBEFB50007A.set
      }


    // Data Members for Class Attributes

      //## begin b24messageprocessor::B24PTLFFinancial::B24AsciiInput%4C10D5D9033C.attr preserve=no  public: bool {V} 
      bool m_bB24AsciiInput;
      //## end b24messageprocessor::B24PTLFFinancial::B24AsciiInput%4C10D5D9033C.attr

      //## begin b24messageprocessor::B24PTLFFinancial::DST%4C2B264D02E3.attr preserve=no  public: bool {V} 
      bool m_bDST;
      //## end b24messageprocessor::B24PTLFFinancial::DST%4C2B264D02E3.attr

      //## Attribute: ExpirationDate%4C10CED40333
      //## begin b24messageprocessor::B24PTLFFinancial::ExpirationDate%4C10CED40333.attr preserve=no  public: bool {V} 
      bool m_bExpirationDate;
      //## end b24messageprocessor::B24PTLFFinancial::ExpirationDate%4C10CED40333.attr

      //## begin b24messageprocessor::B24PTLFFinancial::GMTOffset%4C2B264D02F2.attr preserve=no  public: int {V} 
      int m_iGMTOffset;
      //## end b24messageprocessor::B24PTLFFinancial::GMTOffset%4C2B264D02F2.attr

    // Additional Public Declarations
      //## begin b24messageprocessor::B24PTLFFinancial%390DA89F00E4.public preserve=yes
      //## end b24messageprocessor::B24PTLFFinancial%390DA89F00E4.public

  protected:
    // Additional Protected Declarations
      //## begin b24messageprocessor::B24PTLFFinancial%390DA89F00E4.protected preserve=yes
      //## end b24messageprocessor::B24PTLFFinancial%390DA89F00E4.protected

  private:

    //## Other Operations (specified)
      //## Operation: reset%3936D9F00196
      //	This method resets all segments and boolean error flags
      //	ready to process a new message
      void reset ();

    // Additional Private Declarations
      //## begin b24messageprocessor::B24PTLFFinancial%390DA89F00E4.private preserve=yes
      //## end b24messageprocessor::B24PTLFFinancial%390DA89F00E4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin b24messageprocessor::B24PTLFFinancial::DSTBeginEnd%4CA3314C031F.attr preserve=no  public: string {U} 
      string m_strDSTBeginEnd;
      //## end b24messageprocessor::B24PTLFFinancial::DSTBeginEnd%4CA3314C031F.attr

      //## Attribute: Reversal%3936E42301B8
      //## begin b24messageprocessor::B24PTLFFinancial::Reversal%3936E42301B8.attr preserve=no  private: bool {V} 
      bool m_bReversal;
      //## end b24messageprocessor::B24PTLFFinancial::Reversal%3936E42301B8.attr

      //## begin b24messageprocessor::B24PTLFFinancial::Track2%4CBEFB50007A.attr preserve=no  public: bool {V} false
      bool m_bTrack2;
      //## end b24messageprocessor::B24PTLFFinancial::Track2%4CBEFB50007A.attr

    // Data Members for Associations

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%3BB2324F033C
      //## Role: B24PTLFFinancial::<m_hFinancialBaseSegment>%3BB2325001C5
      //## begin b24messageprocessor::B24PTLFFinancial::<m_hFinancialBaseSegment>%3BB2325001C5.role preserve=no  public: repositorysegment::FinancialBaseSegment { -> VHgN}
      repositorysegment::FinancialBaseSegment m_hFinancialBaseSegment;
      //## end b24messageprocessor::B24PTLFFinancial::<m_hFinancialBaseSegment>%3BB2325001C5.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%3BB23252007D
      //## Role: B24PTLFFinancial::<m_hFinancialReversalSegment>%3BB2325203A9
      //## begin b24messageprocessor::B24PTLFFinancial::<m_hFinancialReversalSegment>%3BB2325203A9.role preserve=no  public: repositorysegment::FinancialReversalSegment { -> VHgN}
      repositorysegment::FinancialReversalSegment m_hFinancialReversalSegment;
      //## end b24messageprocessor::B24PTLFFinancial::<m_hFinancialReversalSegment>%3BB2325203A9.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%3BB232540232
      //## Role: B24PTLFFinancial::<m_hFinancialSettlementSegment>%3BB232550148
      //## begin b24messageprocessor::B24PTLFFinancial::<m_hFinancialSettlementSegment>%3BB232550148.role preserve=no  public: repositorysegment::FinancialSettlementSegment { -> VHgN}
      repositorysegment::FinancialSettlementSegment m_hFinancialSettlementSegment;
      //## end b24messageprocessor::B24PTLFFinancial::<m_hFinancialSettlementSegment>%3BB232550148.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%3BB2325700CB
      //## Role: B24PTLFFinancial::<m_hFinancialUserSegment>%3BB232580196
      //## begin b24messageprocessor::B24PTLFFinancial::<m_hFinancialUserSegment>%3BB232580196.role preserve=no  public: repositorysegment::FinancialUserSegment { -> VHgN}
      repositorysegment::FinancialUserSegment m_hFinancialUserSegment;
      //## end b24messageprocessor::B24PTLFFinancial::<m_hFinancialUserSegment>%3BB232580196.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%4C10B5F40048
      //## Role: B24PTLFFinancial::<m_hIntegratedCircuitCardSegment>%4C10B5F403C3
      //## begin b24messageprocessor::B24PTLFFinancial::<m_hIntegratedCircuitCardSegment>%4C10B5F403C3.role preserve=no  public: repositorysegment::IntegratedCircuitCardSegment { -> VHgN}
      repositorysegment::IntegratedCircuitCardSegment m_hIntegratedCircuitCardSegment;
      //## end b24messageprocessor::B24PTLFFinancial::<m_hIntegratedCircuitCardSegment>%4C10B5F403C3.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%4C10B694032D
      //## Role: B24PTLFFinancial::<m_hFinancialAdjustmentSegment>%4C10B69502FE
      //## begin b24messageprocessor::B24PTLFFinancial::<m_hFinancialAdjustmentSegment>%4C10B69502FE.role preserve=no  public: repositorysegment::FinancialAdjustmentSegment { -> VHgN}
      repositorysegment::FinancialAdjustmentSegment m_hFinancialAdjustmentSegment;
      //## end b24messageprocessor::B24PTLFFinancial::<m_hFinancialAdjustmentSegment>%4C10B69502FE.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%5231BBD802E9
      //## Role: B24PTLFFinancial::<m_hCashDepositSegment>%5231BBDA0362
      //## begin b24messageprocessor::B24PTLFFinancial::<m_hCashDepositSegment>%5231BBDA0362.role preserve=no  public: repositorysegment::CashDepositSegment { -> 0..nVHgN}
      vector<repositorysegment::CashDepositSegment> m_hCashDepositSegment;
      //## end b24messageprocessor::B24PTLFFinancial::<m_hCashDepositSegment>%5231BBDA0362.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%5231BD530202
      //## Role: B24PTLFFinancial::<m_hCheckDepositSegment>%5231BD5503DE
      //## begin b24messageprocessor::B24PTLFFinancial::<m_hCheckDepositSegment>%5231BD5503DE.role preserve=no  public: repositorysegment::CheckDepositSegment { -> 0..nVHgN}
      vector<repositorysegment::CheckDepositSegment> m_hCheckDepositSegment;
      //## end b24messageprocessor::B24PTLFFinancial::<m_hCheckDepositSegment>%5231BD5503DE.role

      //## Association: Platform \: ACI Base 24::B24MessageProcessor_CAT::<unnamed>%52493417002D
      //## Role: B24PTLFFinancial::<m_hFinancialDepositSegment>%524934180366
      //## begin b24messageprocessor::B24PTLFFinancial::<m_hFinancialDepositSegment>%524934180366.role preserve=no  public: repositorysegment::FinancialDepositSegment { -> VHgN}
      repositorysegment::FinancialDepositSegment m_hFinancialDepositSegment;
      //## end b24messageprocessor::B24PTLFFinancial::<m_hFinancialDepositSegment>%524934180366.role

    // Additional Implementation Declarations
      //## begin b24messageprocessor::B24PTLFFinancial%390DA89F00E4.implementation preserve=yes
      //## end b24messageprocessor::B24PTLFFinancial%390DA89F00E4.implementation

};

//## begin b24messageprocessor::B24PTLFFinancial%390DA89F00E4.postscript preserve=yes
//## end b24messageprocessor::B24PTLFFinancial%390DA89F00E4.postscript

} // namespace b24messageprocessor

//## begin module%390DAD0A027B.epilog preserve=yes
using namespace b24messageprocessor;
//## end module%390DAD0A027B.epilog


#endif
