//	Copyright (c) 1998 - 2004
//	eFunds Corporation
// $Date:   Jul 06 2010 01:19:02  $ $Author:   D02684  $ $Revision:   1.9  $

#ifndef CXODBP06_HPP
#define CXODBP06_HPP

#include "CXODRU32.hpp"
struct hB24ControlHeader
{
   char sTypeRec[2];           // CH added by DD process or by online feed process
   char sLoggerName[6];
   char sLogOpenTime[16];
};
struct hB24ControlMessage
{
   char sTypeRec[2];           // CR added by DD process or by online feed process
   char sLoggerName[6];
   char sLogOpenTime[16];
   int lUnloadRecordCount;
   int lUnloadTstampHash[2];
};

struct hB24LogHeader
{
   // Standard B24 Header Layout
   //char sTypeRec[2];           // DR,TR or CF added by Extract process or by online feed process
   //char sFiller[4];            // Dat_Tim field is binary 64.
   int lHdrHash[2];               // Second 4 bytes used for hashing
   char sRecTyp[2];            // 01, 04, 20, 21, 22 etc.
};
#include "CXODRU33.hpp"

#endif
