//	Copyright (c) 1998 - 2004
//	eFunds Corporation
// $Date:   Jun 17 2011 06:54:38  $ $Author:   D02684  $ $Revision:   1.12  $

#ifndef CXODBP11_HPP
#define CXODBP11_HPP

#include "CXODRU32.hpp"

struct hB24PTLFTransaction
{
   // Standard B24 PTLF Header Layout - same for all records from the PTLF (POS) files
   int lHdrHash[2];                    // 0000
   char sRecTyp[2];                    // 0008
   char sCrdLn[4];                     // 0010
   char sCrdFiid[4];                   // 0014
   char sCrdPan[19];                   // 0018
   char sCrdMbrNum[3];                 // 0037
   char sRetlKyLn[4];                  // 0040
   char sRetlKyFiid[4];                // 0044
   char sRetlKyGrp[4];                 // 0048
   char sRetlKyRegn[4];                // 0052
   char sRetlKyId[19];                 // 0056
   char sRetlTermId[16];               // 0075
   char sRetlShiftNum[3];              // 0091
   char sRetlBatchNum[3];              // 0094
   char sTermLn[4];                    // 0097
   char sTermFiid[4];                  // 0101
   char sTermId[16];                   // 0105
   char sTermTimHH[2];                 // 0121
   char sTermTimMM[2];                 // 0123
   char sTermTimSS[2];                 // 0125
   char sTermTimTT[2];                 // 0127
   char sTkeyTermId[16];               // 0129
   char sTkeyRecFrmt;                  // 0145
   char sTkeyRetailerId[19];           // 0146
   char sTkeyClerkId[6];               // 0165
   char cDataFlag;                     // 0171
   char sTyp[4];                       // 0172
   char sRteStat[2];                   // 0176
   char cOriginator;                   // 0178
   char cResponder;                    // 0179
   char sIssCde[2];                    // 0180
   int lEntryTim[2];                   // 0182
   int lExitTim[2];                    // 0190
   int lReEntryTim[2];                 // 0198
   char sTranDatYY[2];                 // 0206
   char sTranDatMM[2];                 // 0208
   char sTranDatDD[2];                 // 0210
   char sTranTimHH[2];                 // 0212
   char sTranTimMM[2];                 // 0214
   char sTranTimSS[2];                 // 0216
   char sTranTimTT[2];                 // 0218
   char sPostDatYY[2];                 // 0220
   char sPostDatMM[2];                 // 0222
   char sPostDatDD[2];                 // 0224
   char sAcqIchgSetlDatYY[2];          // 0226
   char sAcqIchgSetlDatMM[2];          // 0228
   char sAcqIchgSetlDatDD[2];          // 0230
   char sIssIchgSetlDatYY[2];          // 0232
   char sIssIchgSetlDatMM[2];          // 0234
   char sIssIchgSetlDatDD[2];          // 0236
   char sSeqNum[12];                   // 0238
   char sTermNameLoc[25];              // 0250
   char sTermOwnerName[22];            // 0275
   char sTermCity[13];                 // 0297
   char sTermSt[3];                    // 0310
   char sTermCntryCde[2];              // 0313
   char sBrchId[4];                    // 0315
   char sUserFld2[3];                  // 0319
   short siTermTimOfst;                // 0322
   char sAcqInstIdNum[11];             // 0324
   char sRcvInstIdNum[11];             // 0335
   char sTermTyp[2];                   // 0346
   char sClerkId[6];                   // 0348
   char sCrtAuthGrp[4];                // 0354
   char sCrtAuthUserId[8];             // 0358
   char sRetlSicCde[4];                // 0366
   char sOrig[4];                      // 0370
   char sDest[4];                      // 0374
   char sTranCdeTc[2];                 // 0378
   char cTranCdeT;                     // 0380
   char sTranCdeAa[2];                 // 0381
   char cTranCdeC;                     // 0383
   char sCrdTyp[2];                    // 0384
   char sAcctNum[19];                  // 0386
   char sRespCde[3];                   // 0405
   int lAmt1[2];                       // 0408
   int lAmt2[2];                       // 0416
   char sExpDat[4];                    // 0424
   char sTrack2[40];                   // 0428
   char sPinOfst[16];                  // 0468
   char sPreAuthSeqNum[12];            // 0484
   char sInvoiceNum[10];               // 0496
   char sOrigInvoiceNum[10];           // 0506
   char sAuthorizer[16];               // 0516
   char cAuthInd;                      // 0532
   char sShiftNum[3];                  // 0533
   char sBatchSeqNum[3];               // 0536
   char sApprvCde[8];                  // 0539
   char cApprvCdeLgth;                 // 0547
   char sIchgResp[8];                  // 0548
   char sPseudoTermId[4];              // 0556
   char cRfrlPhone[20];                // 0560
   char cDftCaptureFlg;                // 0580
   char cSetlFlag;                     // 0581
   char sRvrlCde[2];                   // 0582
   char sReaForChrgbck[2];             // 0584
   char cNumOfChrgbck;                 // 0586
   char sPtSrvCondCde[2];              // 0587
   char sPtSrvEntryMde[3];             // 0589
   char cAuthInd2;                     // 0592
   char sOrigCrncyCde[3];              // 0593
   char sMultCrncyAuthCrncyCde[3];     // 0596
   char sMultCrncyAuthConvRate[8];     // 0599
   char sMultCrncySetlCrncyCde[3];     // 0607
   char sMultCrncySetlConvRate[8];     // 0610
   char sMultCrncyConvDatTim[8];       // 0618
   char refr[6];                       // 0626
   char cAdjSetlImpactFlg;             // 0632
   char cRefrIndPbf1;                  // 0633
   char cRefrIndPbf2;                  // 0634
   char cRefrIndPbf3;                  // 0635
   char cRefrIndPbf4;                  // 0636
   char sFrwdInstIdNum[11];            // 0637
   char sCrdAccptIdNum[11];            // 0648
   char sCrdIssIdNum[11];              // 0659
   char sOrigMsgTyp[4];                // 0670
   char sOrigTranTimHH[2];             // 0674
   char sOrigTranTimMM[2];             // 0676
   char sOrigTranTimSS[2];             // 0678
   char sOrigTranTimTT[2];             // 0680
   char sOrigTranDat[4];               // 0682
   char sOrigSeqNum[12];               // 0686
   char sOrigB24PostDat[4];            // 0698
   char sExcpRsnCde[3];                // 0702
   char cOvrrdeFlg;                    // 0705
   char sAddr[20];                     // 0706
   char sZipCde[9];                    // 0726
   char cAddrVrfyStat;                 // 0735
   char cPinInd;                       // 0736
   char cPinTries;                     // 0737
   char sPreAuthTsDatYY[2];            // 0738
   char sPreAuthTsDatMM[2];            // 0740
   char sPreAuthTsDatDD[2];            // 0742
   char sPreAuthTsTimHH[2];            // 0744
   char sPreAuthTsTimMM[2];            // 0746
   char sPreAuthTsTimSS[2];            // 0748
   char sPreAuthTsTimTT[2];            // 0750
   char cPreAuthHldsLvl;               // 0752
   char sUserFld5[33];                 // 0753
   short siUserDataLen;                // 0786
};

#include "CXODRU33.hpp"

#endif
