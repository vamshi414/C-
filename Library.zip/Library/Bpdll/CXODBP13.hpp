   //B24TLFFinancial ATM insert
   // |<html>
   // |<body>
   // |<title>CG</title>
   // |<h1>BI
   // |<h2>FI
   // |<h3>Base24 Financial Message
   // |<p>
   // |The DataNavigator financial transaction is populated from 
   // |<p>
   // |<table border = "1">
   // |<tr><th>DataNavigator     <th>Base24 message
   Trace::put("B13 Insert start");

   UseCase hUseCase("B24","## BP13 READ B24 ATM FINANCIAL",false);
   hB24TLFTransaction* pB24Record = (hB24TLFTransaction*)Message::instance(Message::INBOUND)->data();

   struct hTokenHeader
   {
      char sEyeCatcher[2];
      unsigned short siTokenCount;
      unsigned short siTokenDataLength;
   };

   struct hFinancialSegEyeCatcher
   {
      char  sEyeCatcher [2];
      char  sToken[2];
      unsigned short  siTokenLength;
      char  sTokenValue [2];
   };

   string strTranslateInValue;
   string strTranslateOutValue;
   size_t pos;
   reset();
   hFinancialSegEyeCatcher* pEyeCatcher = (hFinancialSegEyeCatcher*)((char *)pB24Record + sizeof(hB24TLFTransaction));
   double dAmt1 = Segment::lltof(ntohl(pB24Record->lAmt1[0]),ntohl(pB24Record->lAmt1[1]));
   applyBounds(dAmt1);
   double dAmt2 = Segment::lltof(ntohl(pB24Record->lAmt2[0]),ntohl(pB24Record->lAmt2[1]));
   applyBounds(dAmt2);
   double dAmt3 = Segment::lltof(ntohl(pB24Record->lAmt3[0]),ntohl(pB24Record->lAmt3[1]));
   applyBounds(dAmt3);
   m_bReversal = (memcmp(pB24Record->sTyp,"0420",4) == 0);
      // |<tr><td>ACCT_ID_1          <td>sFromAcctNum
   if (memcmp(pB24Record->sFromAcctNum,"0000000000000000000",19) != 0)
      m_hFinancialBaseSegment.setACCT_ID_1(pB24Record->sFromAcctNum, 19);
      // |<tr><td>ACCT_ID_2          <td>sToAcctNum
   if (memcmp(pB24Record->sToAcctNum,"0000000000000000000",19) != 0)
      m_hFinancialBaseSegment.setACCT_ID_2(pB24Record->sToAcctNum, 19);
      // |<tr><td>ACCT_TYPE_1          <td>sTranCdeFrom
   if (memcmp(pB24Record->sTranCdeFrom,"01",2) == 0)
      m_hFinancialUserSegment.setACCT_TYPE_1("DDA",3);
   else
   if (memcmp(pB24Record->sTranCdeFrom,"11",2) == 0)
      m_hFinancialUserSegment.setACCT_TYPE_1("SAV",3);
   else
   if (memcmp(pB24Record->sTranCdeFrom,"31",2) == 0)
      m_hFinancialUserSegment.setACCT_TYPE_1("CRD",3);
   else
      m_hFinancialUserSegment.setACCT_TYPE_1("OTH",3);
      // |<tr><td>APPROVAL_CODE          <td>sAuthIdResp
   m_hFinancialBaseSegment.setAPPROVAL_CODE(pB24Record->sAuthIdResp,6);
      // |<tr><td>CARD_ACPT_BUS_CODE          <td>6011
   m_hFinancialBaseSegment.setCARD_ACPT_BUS_CODE("6011",4);
      // |<tr><td>CARD_ACPT_NAME_LOC      <td>sTermNameLoc+sTermCity+sTermSt
   char sCardAcptInfo[85];
   memset(sCardAcptInfo,' ',sizeof(sCardAcptInfo));
   memcpy(sCardAcptInfo,pB24Record->sTermNameLoc,sizeof(pB24Record->sTermNameLoc));
   memcpy(sCardAcptInfo+26,pB24Record->sTermCity,sizeof(pB24Record->sTermCity));
   memcpy(sCardAcptInfo+39,pB24Record->sTermSt,3);
   m_hFinancialBaseSegment.setCARD_ACPT_NAME_LOC(sCardAcptInfo,84);
      // |<tr><td>CARD_ACPT_TERM_ID <td>sTermId
   strTranslateInValue.assign(pB24Record->sTermId,16);
   if ((pos = strTranslateInValue.find_first_of(' ')) != string::npos)
      strTranslateInValue.erase(pos);
   if(strTranslateInValue.length() > 0)
      m_hFinancialBaseSegment.setCARD_ACPT_TERM_ID(strTranslateInValue.data(),strTranslateInValue.length());
      // |<tr><td>TRAN_CLASS          <td>ATM
   m_hFinancialBaseSegment.setTRAN_CLASS("ATM",3);
      // |<tr><td>AMT_RECON_NET          <td>lAmt1
   m_hFinancialBaseSegment.setAMT_RECON_NET(dAmt1);
      // |<tr><td>AMT_TRAN          <td>lAmt1
   m_hFinancialBaseSegment.setAMT_TRAN(dAmt1);
      // |<tr><td>AMT_CARD_BILL <td>lAmt1
   m_hFinancialBaseSegment.setAMT_CARD_BILL(dAmt1);
      // |<tr><td>AMT_RECON_ACQ  <td>lAmt1
   m_hFinancialSettlementSegment.setAMT_RECON_ACQ(dAmt1);
      // |<tr><td>AMT_RECON_NET          <td>lAmt1
   m_hFinancialSettlementSegment.setAMT_RECON_ISS(dAmt1);
      // |<tr><td>FUNC_CODE   <td>sTyp
   if ((memcmp(pB24Record->sTyp,"0210",4) == 0) ||
       (memcmp(pB24Record->sTyp,"0220",4) == 0)) 
   {
      if ((memcmp(pB24Record->sTranCde,"03",2) == 0) ||
          (memcmp(pB24Record->sTranCde,"04",2) == 0) ||
          (memcmp(pB24Record->sTranCde,"30",2) == 0) ||
          (memcmp(pB24Record->sTranCde,"70",2) == 0))
      {
         m_hFinancialBaseSegment.setFUNC_CODE("108",3);
      }
      else
      if ((memcmp(pB24Record->sTranCde,"10",2) == 0) ||
          (memcmp(pB24Record->sTranCde,"11",2) == 0) ||
          (memcmp(pB24Record->sTranCde,"20",2) == 0) ||
          (memcmp(pB24Record->sTranCde,"24",2) == 0) ||
          (memcmp(pB24Record->sTranCde,"40",2) == 0) ||
          (memcmp(pB24Record->sTranCde,"50",2) == 0) ||
          (memcmp(pB24Record->sTranCde,"51",2) == 0))
      {
         m_hFinancialBaseSegment.setFUNC_CODE("200",3);
      }
      else
      if ((memcmp(pB24Record->sTranCde,"60",2) == 0) ||
          (memcmp(pB24Record->sTranCde,"61",2) == 0) ||
          (memcmp(pB24Record->sTranCde,"62",2) == 0) ||
          (memcmp(pB24Record->sTranCde,"81",2) == 0))
      {
         m_hFinancialBaseSegment.setFUNC_CODE("180",3);
      }
   }
   else
   if (memcmp(pB24Record->sTyp,"0420",4) == 0)
   {
      if ((memcmp(pB24Record->sTranCde,"10",2) == 0) || 
          (memcmp(pB24Record->sTranCde,"11",2) == 0))
      {
         if (dAmt1 == dAmt2)
            m_hFinancialBaseSegment.setFUNC_CODE("400",3);   
         else
            m_hFinancialBaseSegment.setFUNC_CODE("401",3);
      }
      else
      if (memcmp(pB24Record->sTranCde,"24",2) == 0)
      {
         if (dAmt2 != dAmt3)
            m_hFinancialBaseSegment.setFUNC_CODE("401",3);   
         else
            m_hFinancialBaseSegment.setFUNC_CODE("400",3);
      }
      else
      {
         m_hFinancialBaseSegment.setFUNC_CODE("400",3);   
      }
   }
   else
   if (memcmp(pB24Record->sTyp,"5400",4) == 0)
   {
      if (dAmt1 == dAmt2)
         m_hFinancialBaseSegment.setFUNC_CODE("201",3);
      else
         m_hFinancialBaseSegment.setFUNC_CODE("202",3);
   }
      // |<tr><td>MERCH_TYPE  <td>6011
   m_hFinancialBaseSegment.setMERCH_TYPE("6011",4);
      // |<tr><td>RETRIEVAL_REF_NO          <td>sSeqNum
   m_hFinancialBaseSegment.setRETRIEVAL_REF_NO(pB24Record->sSeqNum,sizeof(pB24Record->sSeqNum));
      // |<tr><td>SYS_TRACE_AUDIT_NO          <td>sSeqNum
   m_hFinancialBaseSegment.setSYS_TRACE_AUDIT_NO(pB24Record->sSeqNum,6);
   // all translated values
   // |<tr><td>TRAN_TYPE_ID <td>X_B24_RESP_COD_ATM[sTranCdeTc]
   strTranslateInValue.assign(pB24Record->sTranCde,6);   // sTranCdeTc + cTranCdeT + sTranCdeAa + cTranCdeC
   strTranslateOutValue.erase();
   if (ConfigurationRepository::instance()->translate
         ("X_B24_PROC_COD_ATM",strTranslateInValue,strTranslateOutValue,   
         "FIN_LOCATOR", "TRAN_TYPE_ID", 0))
      m_hFinancialBaseSegment.setTRAN_TYPE_ID(strTranslateOutValue.data(),10);
      // |<tr><td>ACT_CODE <td>X_B24_RESP_COD_ATM[sRespCde]
      // |</table>
      // |</body>
   if (m_bReversal)
   {
      m_hFinancialBaseSegment.setACT_CODE(
         memcmp(pB24Record->sRespCde,"000",3) == 0 ? "400" : "480",3);
   }
   else
   {
      strTranslateInValue.assign(pB24Record->sRespCde,3);
      strTranslateOutValue.erase();
      if (ConfigurationRepository::instance()->translate("X_B24_RESP_COD_ATM",strTranslateInValue,strTranslateOutValue,
         "FIN_LOCATOR", "ACT_CODE", 0,false))
         m_hFinancialBaseSegment.setACT_CODE(strTranslateOutValue.data(),3);
      else
      {
         EvidenceSegment hEvidenceSegment;
         hEvidenceSegment.setSUSPECT_TABLE("X_B24_RESP_COD_ATM");
         hEvidenceSegment.setPROBLEM_TABLE("FIN_LOCATOR");
         hEvidenceSegment.setPROBLEM_COLUMN("ACT_CODE");
         hEvidenceSegment.setSOURCE_VALUE(strTranslateInValue);
         hEvidenceSegment.setREASON_CODE(EVIDENCE_ACT_CODE_TRANSLATE_FAILURE);
         hEvidenceSegment.setTSTAMP_TRANS(m_hFinancialBaseSegment.zTSTAMP_TRANS());
         ConfigurationRepository::instance()->addEvidenceSegment(hEvidenceSegment);
      }
   }
      // |<tr><td>TRAN_DISPOSITION     <td>sRecTyp sRespCde reversal
   if (  memcmp(pB24Record->sRecTyp,"01",2) != 0  &&
         memcmp(pB24Record->sRecTyp,"20",2) != 0 )  
      m_hFinancialBaseSegment.setTRAN_DISPOSITION("2",1);
   else if (m_bReversal)
      m_hFinancialBaseSegment.setTRAN_DISPOSITION("3",1); 
   else if (m_hFinancialBaseSegment.zACT_CODE()[0] != '\0')
   {
      m_hFinancialBaseSegment.setTRAN_DISPOSITION(m_hFinancialBaseSegment.zACT_CODE()[0]== '0' ? "1" : "2",1);
   }
   
   m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("2",1);
   m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_CAP("2",1);   
   if(pB24Record->sUserFld4[7] == 'O')
   {
      unsigned char sPROC_FLGSn[2] = {0x80,0x00};
      m_hFinancialUserSegment.setPROC_FLGSn((char*)sPROC_FLGSn,2,0);
   }
   char sEyeCatch[4];
   memset(sEyeCatch,' ',4);
   memcpy(sEyeCatch,pEyeCatcher->sEyeCatcher,2);
#ifdef MVS
   CodeTable::translate(sEyeCatch,2,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   if (sEyeCatch[0] == '&')
   {
      hTokenHeader* pTokenHeader = (hTokenHeader*)(char*)pEyeCatcher;
      short siDataLength = ntohs(pTokenHeader->siTokenDataLength);
      pEyeCatcher = (hFinancialSegEyeCatcher*)((char*)pEyeCatcher + 6);
      siDataLength -= 6;
      short siWorkingLength = 0;
      while (siDataLength > 0)
      {
         memcpy(sEyeCatch,pEyeCatcher->sEyeCatcher,4);
#ifdef MVS
         CodeTable::translate(sEyeCatch,4,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
         if (sEyeCatch[0] == '!')
         {
            short siTokenLength = ntohs(pEyeCatcher->siTokenLength);
            string strTemp(pEyeCatcher->sTokenValue,siTokenLength);
            if (memcmp(sEyeCatch+2,"B2",2) == 0)
            {
               m_hIntegratedCircuitCardSegment.setPresence(true);
               string strBitMap=hexToChar(strTemp.data(),2);
               char psBits[4];
               int nFieldNum=0;
               int nFixedPos=2; 
               short   siVDFieldLen[17] =   {0,2,1,5,8,6,6,2,2,2,2,3,1,4,0,0,0};
               for (int i=0; i<=3; i++)
               {
                  convertBitMap(strBitMap.data()[i],psBits);
                  for (int j=0; j<=3; ++j) 
                  {
                     nFieldNum++;
                     if (psBits[j] == '1') 
                     {
                        switch (nFieldNum)
                        {
                           case 1:
                           {
                              //do nothing
                           }
                           break;
                           case 2:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setCRYPT_INFO_DATA(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),siWorkingLength*2);
                           }
                           break;
                           case 3:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setTERM_VERIFY_RESULT(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),siWorkingLength*2);
                           }
                           break;
                           case 4:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setAPPL_CRYPTOGRAM(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),siWorkingLength*2);
                           }
                           break;
                           case 5:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setCRYPTOGRAM_AMOUNT(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),siWorkingLength*2);
                           }
                           break;
                           case 6:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setAMOUNT_OTHER(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),siWorkingLength*2);
                           }
                           break;
                           case 7:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setAPPL_INTRCHG_PROF(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),siWorkingLength*2);
                           }
                           break;
                           case 8:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setAPPL_TRAN_COUNTER(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),siWorkingLength*2);
                           }
                           break;
                           case 9:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setTERM_COUNTRY_CODE(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data()+1,3);
                           }
                           break;
                           case 10:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setTRAN_CURRENCY_CODE(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data()+1,3);
                           }
                           break;
                           case 11:
                           { 
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setTRAN_DATE(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),siWorkingLength*2);
                           }
                           break;
                           case 12:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setTRAN_TYPE(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),siWorkingLength*2);
                           }
                           break;
                           case 13:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setUNPREDICTABLE_NO(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),siWorkingLength*2);
                           }
                           break;
                           case 14:
                           case 15:
                           {
                              //do nothing
                           }
                           break;
                           case 16:
                           {
                              char sLen[3];
                              memset(sLen,'\0',sizeof(sLen));
                              memcpy(sLen,strTemp.data()+nFixedPos,2);
                              siWorkingLength=ntohs(* (short*) sLen);
                              m_hIntegratedCircuitCardSegment.setISS_APPL_DATA(hexToChar(strTemp.data()+nFixedPos+2,siWorkingLength).data(),siWorkingLength > 32 ? 64 : siWorkingLength*2);
                           }
                           break;
                        } 
                     }
                     nFixedPos += siVDFieldLen[nFieldNum];
                  }
               }
            }
            else if (memcmp(sEyeCatch+2,"B3",2) == 0)
            {
               m_hIntegratedCircuitCardSegment.setPresence(true);
               string strBitMap=hexToChar(strTemp.data(),2);
               char psBits[4];
               int nFieldNum=0;
               int nFixedPos=2;  
               short   siVDFieldLen[9] =   {0,8,4,2,4,1,2,3,0};
               for (int i=0; i<=1; i++)
               {
                  convertBitMap(strBitMap.data()[i],psBits);
                  for (int j=0; j<=3; ++j)  
                  {
                     nFieldNum++;
                     if (psBits[j] == '1') 
                     {
                        switch (nFieldNum)
                        {
                           case 1:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
#ifdef MVS
                              CodeTable::translate((char*)strTemp.data()+nFixedPos,siWorkingLength,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
                              m_hIntegratedCircuitCardSegment.setTERM_SERIAL_NO(strTemp.data()+nFixedPos,siWorkingLength);
                           }
                           break;
                           case 2:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setTERM_CAPABILITIES(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),(siWorkingLength-1)*2);
                           }
                           break;
                           case 3:
                           case 4:
                           {
                              // do nothing
                           }
                           break;
                           case 5:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setTERMINAL_TYPE(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),siWorkingLength*2);
                           }
                           break;
                           case 6:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setAPPL_VERSION_NO(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),siWorkingLength*2);
                           }
                           break;
                           case 7:
                           {
                              siWorkingLength=siVDFieldLen[nFieldNum];
                              m_hIntegratedCircuitCardSegment.setCARDH_VER_RESULT(hexToChar(strTemp.data()+nFixedPos,siWorkingLength).data(),siWorkingLength*2);
                           }
                           break;
                           case 8:
                           {
                              char sLen[3];
                              memset(sLen,'\0',sizeof(sLen));
                              memcpy(sLen,strTemp.data()+nFixedPos,2);
                              siWorkingLength=ntohs(* (short*) sLen);
                              m_hIntegratedCircuitCardSegment.setDEDICATED_FILE_NAM(hexToChar(strTemp.data()+nFixedPos+2,siWorkingLength).data(),siWorkingLength > 8 ? 16 :siWorkingLength*2);
                           }
                           break;
                        }
                     }
                     nFixedPos += siVDFieldLen[nFieldNum];
                  }
               }
            }
            else if (memcmp(sEyeCatch+2,"B4",2) == 0)
            {
#ifdef MVS
               CodeTable::translate((char*)strTemp.data(),4,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
               if (memcmp(strTemp.data(),"00",2) == 0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("0",1);
               else if (memcmp(strTemp.data(),"01",2) == 0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("1",1);
               else if (memcmp(strTemp.data(),"02",2) == 0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("2",1);
               else if (memcmp(strTemp.data(),"05",2) == 0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("5",1);
               else if (memcmp(strTemp.data(),"06",2) == 0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("M",1);
               else if (memcmp(strTemp.data(),"07",2) == 0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("M",1);
               else if (memcmp(strTemp.data(),"08",2) == 0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("M",1);
               else if (memcmp(strTemp.data(),"79",2) == 0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("B",1);
               else if (memcmp(strTemp.data(),"80",2) == 0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("C",1);
               else if (memcmp(strTemp.data(),"91",2) == 0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("A",1);
               else if (memcmp(strTemp.data(),"92",2) == 0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("M",1);
               else if (memcmp(strTemp.data(),"95",2) == 0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("5",1);

               if (memcmp(strTemp.data()+3,"0",1)==0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_CAP("0",1);
               else if (memcmp(strTemp.data()+3,"2",1)==0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_CAP("2",1);
               else if (memcmp(strTemp.data()+3,"3",1)==0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_CAP("A",1);
               else if (memcmp(strTemp.data()+3,"4",1)==0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_CAP("A",1);
               else if (memcmp(strTemp.data()+3,"5",1)==0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_CAP("5",1);
               else if (memcmp(strTemp.data()+3,"8",1)==0)
                  m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_CAP("M",1);
            }
            else if (memcmp(sEyeCatch+2,"B5",2) == 0)
            {
               m_hIntegratedCircuitCardSegment.setPresence(true);
               char sLen[3];
               memset(sLen,'\0',sizeof(sLen));
               memcpy(sLen,strTemp.data(),2);
               siWorkingLength=ntohs(* (short*) sLen);
               m_hIntegratedCircuitCardSegment.setISS_AUTH_DATA(hexToChar(strTemp.data()+2,siWorkingLength).data(), siWorkingLength > 16 ? 32 : siWorkingLength*2);
            }
            else if (memcmp(sEyeCatch+2,"B6",2) == 0)
            {
               m_hIntegratedCircuitCardSegment.setPresence(true);
               char sLen[3];
               memset(sLen,'\0',sizeof(sLen));
               memcpy(sLen,strTemp.data(),2);
               siWorkingLength=ntohs(* (short*) sLen);
               m_hIntegratedCircuitCardSegment.setISS_SCRIPT1_DATA(hexToChar(strTemp.data()+2,siWorkingLength).data(), siWorkingLength > 128 ? 256 : siWorkingLength*2);
               m_hIntegratedCircuitCardSegment.setISS_SCRIPT2_DATA(hexToChar(strTemp.data()+2,siWorkingLength).data(), siWorkingLength > 128 ? 256 : siWorkingLength*2);
            }
            else if (memcmp(sEyeCatch+2,"BJ",2) == 0)
            {
               m_hIntegratedCircuitCardSegment.setPresence(true);
               char sLen[2];
               memset(sLen,'\0',sizeof(sLen));
               memcpy(sLen,strTemp.data(),1);
               siWorkingLength=ntohs(* (short*) sLen);
               m_hIntegratedCircuitCardSegment.setISS_SCRIPT_RESULT(hexToChar(strTemp.data()+2,siWorkingLength).data(),siWorkingLength > 2 ? 40 : siWorkingLength*20);
            }
            siDataLength -= (siTokenLength+6);
            pEyeCatcher = (hFinancialSegEyeCatcher*)((char*)pEyeCatcher + siTokenLength + 6);
         }
         else
            siDataLength=0;
      }
   }
   if (memcmp(pB24Record->sUserFld4+6,"E",1) == 0)
      m_hFinancialSettlementSegment.setPOS_CRD_DAT_IN_MOD("W",1);   // override for SGB cardless transactions
   pEyeCatcher = (hFinancialSegEyeCatcher*)((char *)pB24Record + sizeof(hB24TLFTransaction));
   Trace::put("B13 Insert end");