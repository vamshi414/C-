//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38FB3C7F00CD.cm preserve=no
//	$Date:   Aug 30 2013 05:13:06  $ $Author:   e3003354  $
//	$Revision:   1.11  $
//## end module%38FB3C7F00CD.cm

//## begin module%38FB3C7F00CD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%38FB3C7F00CD.cp

//## Module: CXOSBP02%38FB3C7F00CD; Package body
//## Subsystem: BPDLL%38FB203D0324
//## Source file: C:\Devel\Dn\Server\Library\Bpdll\CXOSBP02.cpp

//## begin module%38FB3C7F00CD.additionalIncludes preserve=no
//## end module%38FB3C7F00CD.additionalIncludes

//## begin module%38FB3C7F00CD.includes preserve=yes
#include "CXODIF11.hpp"
//## end module%38FB3C7F00CD.includes

#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSBP02_h
#include "CXODBP02.hpp"
#endif


//## begin module%38FB3C7F00CD.declarations preserve=no
//## end module%38FB3C7F00CD.declarations

//## begin module%38FB3C7F00CD.additionalDeclarations preserve=yes
//## end module%38FB3C7F00CD.additionalDeclarations


//## Modelname: Platform \: ACI Base 24::B24MessageProcessor_CAT%38F232BC039B
namespace b24messageprocessor {
//## begin b24messageprocessor%38F232BC039B.initialDeclarations preserve=yes
//## end b24messageprocessor%38F232BC039B.initialDeclarations

// Class b24messageprocessor::B24Message 

//## begin b24messageprocessor::B24Message::TestDate%3C692022032C.attr preserve=no  public: static string {U} 
string B24Message::m_strTestDate;
//## end b24messageprocessor::B24Message::TestDate%3C692022032C.attr

B24Message::B24Message()
  //## begin B24Message::B24Message%38FB16E00332_const.hasinit preserve=no
      : m_siUniquenessKey(0)
  //## end B24Message::B24Message%38FB16E00332_const.hasinit
  //## begin B24Message::B24Message%38FB16E00332_const.initialization preserve=yes
  //## end B24Message::B24Message%38FB16E00332_const.initialization
{
  //## begin b24messageprocessor::B24Message::B24Message%38FB16E00332_const.body preserve=yes
   m_hCanisterValues.push_back(1000);
   m_hCanisterValues.push_back(2000);
   m_hCanisterValues.push_back(5000);
   m_hCanisterValues.push_back(10000);
  //## end b24messageprocessor::B24Message::B24Message%38FB16E00332_const.body
}

B24Message::B24Message (const char* pszTranType, const char* pszSegmentID)
  //## begin b24messageprocessor::B24Message::B24Message%38FB21F50042.hasinit preserve=no
      : m_siUniquenessKey(0)
  //## end b24messageprocessor::B24Message::B24Message%38FB21F50042.hasinit
  //## begin b24messageprocessor::B24Message::B24Message%38FB21F50042.initialization preserve=yes
   ,m_strTranType(pszTranType)
   ,m_strSegmentID(pszSegmentID)
  //## end b24messageprocessor::B24Message::B24Message%38FB21F50042.initialization
{
  //## begin b24messageprocessor::B24Message::B24Message%38FB21F50042.body preserve=yes
   m_hCanisterValues.push_back(1000);
   m_hCanisterValues.push_back(2000);
   m_hCanisterValues.push_back(5000);
   m_hCanisterValues.push_back(10000);
  //## end b24messageprocessor::B24Message::B24Message%38FB21F50042.body
}


B24Message::~B24Message()
{
  //## begin b24messageprocessor::B24Message::~B24Message%38FB16E00332_dest.body preserve=yes
  //## end b24messageprocessor::B24Message::~B24Message%38FB16E00332_dest.body
}



//## Other Operations (implementation)
void B24Message::applyBounds (double &dAmount)
{
  //## begin b24messageprocessor::B24Message::applyBounds%4E1FDC5E0202.body preserve=yes
   if (dAmount < -999999999999999e+0)
      dAmount = -999999999999999e+0;
   if (dAmount > 999999999999999e+0)
      dAmount = 999999999999999e+0;
  //## end b24messageprocessor::B24Message::applyBounds%4E1FDC5E0202.body
}

void B24Message::convertBitMap (const char cCharBit, char* psBits)
{
  //## begin b24messageprocessor::B24Message::convertBitMap%521CB8A301B5.body preserve=yes
   char sBits[65] = {"0000000100100011010001010110011110001001101010111100110111101111"};
   char pszHex [17] = {"0123456789ABCDEF"};
   char* p = strchr(pszHex,cCharBit);
   if (!p)
      memcpy(psBits,sBits,4);
   else
      memcpy(psBits,sBits + ((p-pszHex) * 4),4);
  //## end b24messageprocessor::B24Message::convertBitMap%521CB8A301B5.body
}

string B24Message::hexToChar (const char* psBuffer, int iLength)
{
  //## begin b24messageprocessor::B24Message::hexToChar%4F22D7750251.body preserve=yes
   string strTemp;
   CodeTable::nibbleToByte(psBuffer,iLength,strTemp);
   return strTemp;
  //## end b24messageprocessor::B24Message::hexToChar%4F22D7750251.body
}

bool B24Message::insert (IF::Message& hMessage)
{
  //## begin b24messageprocessor::B24Message::insert%38FB21E601EF.body preserve=yes
   return true;
  //## end b24messageprocessor::B24Message::insert%38FB21E601EF.body
}

void B24Message::translateAscii ()
{
  //## begin b24messageprocessor::B24Message::translateAscii%3916CA4F03DD.body preserve=yes
  //## end b24messageprocessor::B24Message::translateAscii%3916CA4F03DD.body
}

//## Get and Set Operations for Class Attributes (implementation)

const string& B24Message::getTestDate ()
{
  //## begin b24messageprocessor::B24Message::getTestDate%3C692022032C.get preserve=no
  return m_strTestDate;
  //## end b24messageprocessor::B24Message::getTestDate%3C692022032C.get
}

void B24Message::setTestDate (const string& value)
{
  //## begin b24messageprocessor::B24Message::setTestDate%3C692022032C.set preserve=no
  m_strTestDate = value;
  //## end b24messageprocessor::B24Message::setTestDate%3C692022032C.set
}

// Additional Declarations
  //## begin b24messageprocessor::B24Message%38FB16E00332.declarations preserve=yes
  //## end b24messageprocessor::B24Message%38FB16E00332.declarations

} // namespace b24messageprocessor

//## begin module%38FB3C7F00CD.epilog preserve=yes
//## end module%38FB3C7F00CD.epilog
