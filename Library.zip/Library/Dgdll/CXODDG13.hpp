//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%611E79AB020C.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%611E79AB020C.cm

//## begin module%611E79AB020C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%611E79AB020C.cp

//## Module: CXOSDG13%611E79AB020C; Package specification
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\bV03.1A.R011\Windows\Build\Dn\Server\Library\Dgdll\CXODDG13.hpp

#ifndef CXOSDG13_h
#define CXOSDG13_h 1

//## begin module%611E79AB020C.additionalIncludes preserve=no
//## end module%611E79AB020C.additionalIncludes

//## begin module%611E79AB020C.includes preserve=yes
//## end module%611E79AB020C.includes

#ifndef CXOSST34_h
#include "CXODST34.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class FinancialTransaction;
class Accumulator;
} // namespace settlement

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::PostgreSQLDatabase_CAT%604A21800240
namespace postgresqldatabase {
class PostgreSQLDatabase;

} // namespace postgresqldatabase

//## begin module%611E79AB020C.declarations preserve=no
//## end module%611E79AB020C.declarations

//## begin module%611E79AB020C.additionalDeclarations preserve=yes
//## end module%611E79AB020C.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

//## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.preface preserve=yes
//## end dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.preface

//## Class: PostgreSQLAggregatorMIS%611E792F0385
//## Category: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
//## Subsystem: DGDLL%611293FE02A0
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%611EAD7B01DB;database::Database { -> F}
//## Uses: <unnamed>%611EAD7E0188;settlement::FinancialTransaction { -> F}
//## Uses: <unnamed>%611EAD8102DB;settlement::Accumulator { -> F}
//## Uses: <unnamed>%611EAD850079;monitor::UseCase { -> F}
//## Uses: <unnamed>%611EAD970080;postgresqldatabase::PostgreSQLDatabase { -> F}

class DllExport PostgreSQLAggregatorMIS : public settlement::AggregatorMIS  //## Inherits: <unnamed>%611E794D00A9
{
  //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.initialDeclarations preserve=yes
public:
   enum State
   {
      INTERPRET_DUPLICATE = 20,
      DEADLOCK_TIMEOUT,
      DATABASE_FAILURE,
      DATABASE_CONNECTION_ERROR,
      RESOURCE_UNAVAILABLE_ERROR,
      ROW_NOT_FOUND,
      UNDEFINED_NAME,
      SUCCESS,
      CONNECT,
      EXIT
   };
  //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.initialDeclarations

  public:
    //## Constructors (generated)
      PostgreSQLAggregatorMIS();

    //## Destructor (generated)
      virtual ~PostgreSQLAggregatorMIS();


    //## Other Operations (specified)
      //## Operation: tableInsert%611EAE15017E
      virtual bool tableInsert (bool bSubtractFromTotals = false);

      //## Operation: tableUpdate%611EAE150193
      virtual int tableUpdate (bool bSubtractFromTotals = false);

    // Additional Public Declarations
      //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.public preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.public

  protected:
    // Additional Protected Declarations
      //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.protected preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.protected

  private:

    //## Other Operations (specified)
      //## Operation: checkResult%611EAE15014F
      int checkResult ();

      //## Operation: lockTables%611EAE150169
      void lockTables ();

    // Additional Private Declarations
      //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.private preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DBAccess%611EAE03039F
      //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS::DBAccess%611EAE03039F.attr preserve=no  private: string {U} 
      string m_strDBAccess;
      //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS::DBAccess%611EAE03039F.attr

      //## Attribute: Transaction%611EAE0303D8
      //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS::Transaction%611EAE0303D8.attr preserve=no  private: long {U} -1
      long m_lTransaction;
      //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS::Transaction%611EAE0303D8.attr

    // Additional Implementation Declarations
      //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.implementation preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.implementation

};

//## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.postscript preserve=yes
//## end dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.postscript

} // namespace dnpostgresqldatabase

//## begin module%611E79AB020C.epilog preserve=yes
//## end module%611E79AB020C.epilog


#endif
