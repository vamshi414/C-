/* Processed by ecpg (14.1) */
/* These include files are added by the preprocessor */
#include <ecpglib.h>
#include <ecpgerrno.h>
#include <sqlca.h>
/* End of automatic include section */

#line 1 "CXOSDG13.sqx"
//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%611E79C00229.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%611E79C00229.cm

//## begin module%611E79C00229.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%611E79C00229.cp

//## Module: CXOSDG13%611E79C00229; Package body
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\bV03.1A.R011\Windows\Build\Dn\Server\Library\Dgdll\CXOSDG13.sqx

//## begin module%611E79C00229.additionalIncludes preserve=no
//## end module%611E79C00229.additionalIncludes

//## begin module%611E79C00229.includes preserve=yes
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif

#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#include "CXODST08.hpp"
//## end module%611E79C00229.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
#ifndef CXOSST03_h
#include "CXODST03.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSPG01_h
#include "CXODPG01.hpp"
#endif
#ifndef CXOSDG13_h
#include "CXODDG13.hpp"
#endif


//## begin module%611E79C00229.declarations preserve=no
//## end module%611E79C00229.declarations

//## begin module%611E79C00229.additionalDeclarations preserve=yes
/* exec sql begin declare section */
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

#line 61 "CXOSDG13.sqx"
 char AMS_TSTAMP_START [ 11 ] ;
 
#line 62 "CXOSDG13.sqx"
 char AMS_INTERVAL_TYPE [ 2 ] ;
 
#line 63 "CXOSDG13.sqx"
 int AMS_T_FIN_ENTITY_ID ;
 
#line 64 "CXOSDG13.sqx"
 int AMS_T_FIN_ENTITY_ID_2 ;
 
#line 65 "CXOSDG13.sqx"
 char AMS_T_MIS_MCC [ 5 ] ;
 
#line 66 "CXOSDG13.sqx"
 int AMS_CATEGORY_ID ;
 
#line 67 "CXOSDG13.sqx"
 double AMS_AMT_TRAN ;
 
#line 68 "CXOSDG13.sqx"
 double AMS_AMT_SURCHARGE ;
 
#line 69 "CXOSDG13.sqx"
 double AMS_AMT_POS_REIMBURSE ;
 
#line 70 "CXOSDG13.sqx"
 double AMS_CASHBACK_AMT ;
 
#line 71 "CXOSDG13.sqx"
 int AMS_TRAN_COUNT ;
 
#line 72 "CXOSDG13.sqx"
 short AMS_PARTITION_KEY ;
 
#line 73 "CXOSDG13.sqx"
 short AMS_NULL ;
 
#line 74 "CXOSDG13.sqx"
 double AMS_TIME_AT_ISS ;
 
#line 75 "CXOSDG13.sqx"
 double AMS_TIME_AT_RQST_SWTCH ;
 
#line 76 "CXOSDG13.sqx"
 double AMS_AMT_FEE ;
 
#line 77 "CXOSDG13.sqx"
 int AMS_SYNC_INTERVAL_NO ;
 
#line 78 "CXOSDG13.sqx"
 char AMS_BIN [ 12 ] ;
/* exec sql end declare section */
#line 79 "CXOSDG13.sqx"

//## end module%611E79C00229.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

// Class dnpostgresqldatabase::PostgreSQLAggregatorMIS 

PostgreSQLAggregatorMIS::PostgreSQLAggregatorMIS()
  //## begin PostgreSQLAggregatorMIS::PostgreSQLAggregatorMIS%611E792F0385_const.hasinit preserve=no
      : m_lTransaction(-1)
  //## end PostgreSQLAggregatorMIS::PostgreSQLAggregatorMIS%611E792F0385_const.hasinit
  //## begin PostgreSQLAggregatorMIS::PostgreSQLAggregatorMIS%611E792F0385_const.initialization preserve=yes
  //## end PostgreSQLAggregatorMIS::PostgreSQLAggregatorMIS%611E792F0385_const.initialization
{
  //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS::PostgreSQLAggregatorMIS%611E792F0385_const.body preserve=yes
   memcpy(m_sID,"DG13",4);
  //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS::PostgreSQLAggregatorMIS%611E792F0385_const.body
}


PostgreSQLAggregatorMIS::~PostgreSQLAggregatorMIS()
{
  //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS::~PostgreSQLAggregatorMIS%611E792F0385_dest.body preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS::~PostgreSQLAggregatorMIS%611E792F0385_dest.body
}



//## Other Operations (implementation)
int PostgreSQLAggregatorMIS::checkResult ()
{
  //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS::checkResult%611EAE15014F.body preserve=yes
   int iInfoIDNumber;
   State nState = (PostgreSQLAggregatorMIS::State)((postgresqldatabase::PostgreSQLDatabase*)Database::instance())->evaluateState(sqlca.sqlcode,sqlca.sqlstate,&iInfoIDNumber);
   if(nState == PostgreSQLAggregatorMIS::SUCCESS)
      return 1;
   else 
   if(nState == PostgreSQLAggregatorMIS::ROW_NOT_FOUND)
      return 0;
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca, m_sID,m_strDBAccess.c_str());
   return -1;
  //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS::checkResult%611EAE15014F.body
}

void PostgreSQLAggregatorMIS::lockTables ()
{
  //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS::lockTables%611EAE150169.body preserve=yes
   if (m_lTransaction == Database::instance()->transaction())
      return;
   m_lTransaction = Database::instance()->transaction();
   { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "lock table T_MIS_TOTAL in exclusive mode", ECPGt_EOIT, ECPGt_EORT);}
#line 134 "CXOSDG13.sqx"

   if (sqlca.sqlcode != 0)
   {
      Database::instance()->traceSQLError((void*)&sqlca,m_sID,"lockTables");
      if (sqlca.sqlcode == -51 || sqlca.sqlcode == -54 || sqlca.sqlcode == -99999913)
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   }
  //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS::lockTables%611EAE150169.body
}

bool PostgreSQLAggregatorMIS::tableInsert (bool bSubtractFromTotals)
{
  //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS::tableInsert%611EAE15017E.body preserve=yes
   AMS_NULL = (AMS_T_FIN_ENTITY_ID_2 == -1) ? -1 : 0;
   m_strDBAccess = "INSERT";
   { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "insert into T_MIS_TOTAL ( TSTAMP_START , INTERVAL_TYPE , T_FIN_ENTITY_ID , T_FIN_ENTITY_ID_2 , T_MIS_MCC , CATEGORY_ID , PARTITION_KEY , AMT_TRAN , AMT_SURCHARGE , AMT_POS_REIMBURSE , CASHBACK_AMT , TRAN_COUNT , TIME_AT_ISS , TIME_AT_RQST_SWTCH , AMT_FEE , SYNC_INTERVAL_NO , BIN ) values ( $1  , $2  , $3  , $4  , $5  , $6  , $7  , $8  , $9  , $10  , $11  , $12  , $13  , $14  , $15  , $16  , $17  )", 
	ECPGt_char,(AMS_TSTAMP_START),(long)11,(long)1,(11)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(AMS_INTERVAL_TYPE),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_T_FIN_ENTITY_ID),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_T_FIN_ENTITY_ID_2),(long)1,(long)1,sizeof(int), 
	ECPGt_short,&(AMS_NULL),(long)1,(long)1,sizeof(short), 
	ECPGt_char,(AMS_T_MIS_MCC),(long)5,(long)1,(5)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_CATEGORY_ID),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_short,&(AMS_PARTITION_KEY),(long)1,(long)1,sizeof(short), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_AMT_TRAN),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_AMT_SURCHARGE),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_AMT_POS_REIMBURSE),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_CASHBACK_AMT),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_TRAN_COUNT),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_TIME_AT_ISS),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_TIME_AT_RQST_SWTCH),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_AMT_FEE),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_SYNC_INTERVAL_NO),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(AMS_BIN),(long)12,(long)1,(12)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 189 "CXOSDG13.sqx"

   if (checkResult() == -1)
   {
      char szTemp[5 * PERCENTLD + 7 * PERCENTF + 3 * PERCENTS];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_MIS_TOTAL %s %ld %ld %s %ld %.0f %.0f %.0f %.0f %ld %.0f %.0f %.0f %ld %s",
         AMS_TSTAMP_START,AMS_T_FIN_ENTITY_ID,AMS_T_FIN_ENTITY_ID_2,AMS_T_MIS_MCC,AMS_CATEGORY_ID,AMS_AMT_TRAN,AMS_AMT_SURCHARGE,
         AMS_AMT_POS_REIMBURSE,AMS_CASHBACK_AMT,AMS_TRAN_COUNT,AMS_TIME_AT_ISS,AMS_TIME_AT_RQST_SWTCH,AMS_AMT_FEE,AMS_SYNC_INTERVAL_NO,AMS_BIN);
      Trace::put(szTemp);
      return false;
   }
   return true;
  //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS::tableInsert%611EAE15017E.body
}

int PostgreSQLAggregatorMIS::tableUpdate (bool bSubtractFromTotals)
{
  //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS::tableUpdate%611EAE150193.body preserve=yes
   memcpy(AMS_TSTAMP_START,getTSTAMP_START().data(),min((size_t)getTSTAMP_START().length(),sizeof(AMS_TSTAMP_START)-1));
   AMS_TSTAMP_START[min((size_t)getTSTAMP_START().length(),sizeof(AMS_TSTAMP_START)-1)] = '\0';
   memcpy(AMS_INTERVAL_TYPE,getINTERVAL_TYPE().data(),min((size_t)getINTERVAL_TYPE().length(),sizeof(AMS_INTERVAL_TYPE)-1));
   AMS_INTERVAL_TYPE[min((size_t)getINTERVAL_TYPE().length(),sizeof(AMS_INTERVAL_TYPE)-1)] = '\0';
   memcpy(AMS_BIN,getBIN().data(),min((size_t)getBIN().length(),sizeof(AMS_BIN)-1));
   AMS_BIN[min((size_t)getBIN().length(),sizeof(AMS_BIN)-1)] = '\0';
   int iT_FIN_ENTITY_ID = 0;
   RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(0).c_str(),getENTITY_ID(0).c_str(),&iT_FIN_ENTITY_ID);
   AMS_T_FIN_ENTITY_ID = iT_FIN_ENTITY_ID;
   int iT_FIN_ENTITY_ID_2 = -1;
   if (getENTITY_ID(1) != "~NULL!")
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(1).c_str(),getENTITY_ID(1).c_str(),&iT_FIN_ENTITY_ID_2);
   AMS_T_FIN_ENTITY_ID_2 = iT_FIN_ENTITY_ID_2;
   if (getT_MIS_MCC().length() == 0)
   {
      AMS_T_MIS_MCC[0] = ' ';
      AMS_T_MIS_MCC[1] = '\0';
   }
   else
   {
      memcpy(AMS_T_MIS_MCC,getT_MIS_MCC().data(),min((size_t)getT_MIS_MCC().length(),sizeof(AMS_T_MIS_MCC)-1));
      AMS_T_MIS_MCC[min((size_t)getT_MIS_MCC().length(),sizeof(AMS_T_MIS_MCC)-1)] = '\0';
   }
   AMS_SYNC_INTERVAL_NO = getSYNC_INTERVAL_NO();
   AMS_CATEGORY_ID = getCATEGORY_ID();
   AMS_AMT_TRAN = (bSubtractFromTotals) ? 0 - getAMT_TRAN() : getAMT_TRAN();
   AMS_AMT_SURCHARGE = (bSubtractFromTotals) ? 0 - getAMT_SURCHARGE() : getAMT_SURCHARGE();
   AMS_AMT_POS_REIMBURSE = (bSubtractFromTotals) ? 0 - getAMT_POS_REIMBURSE() : getAMT_POS_REIMBURSE();
   AMS_CASHBACK_AMT = (bSubtractFromTotals) ? 0 - getCASHBACK_AMT() : getCASHBACK_AMT();
   AMS_TRAN_COUNT = (bSubtractFromTotals) ? -1 : 1;
   AMS_TIME_AT_ISS = (bSubtractFromTotals) ? 0 - (double)getTIME_AT_ISS() : (double)getTIME_AT_ISS();
   AMS_TIME_AT_RQST_SWTCH = (bSubtractFromTotals) ? 0 - (double)getTIME_AT_RQST_SWTCH() : (double)getTIME_AT_RQST_SWTCH();
   AMS_AMT_FEE = (bSubtractFromTotals) ? 0 - getAMT_FEE() : getAMT_FEE();
   lockTables();
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return -1;
   m_strDBAccess = "UPDATE";
   if (AMS_T_FIN_ENTITY_ID_2 == -1)
      { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "update T_MIS_TOTAL set AMT_TRAN = AMT_TRAN + $1  , AMT_SURCHARGE = AMT_SURCHARGE + $2  , AMT_POS_REIMBURSE = AMT_POS_REIMBURSE + $3  , CASHBACK_AMT = CASHBACK_AMT + $4  , TRAN_COUNT = TRAN_COUNT + $5  , TIME_AT_ISS = TIME_AT_ISS + $6  , TIME_AT_RQST_SWTCH = TIME_AT_RQST_SWTCH + $7  , AMT_FEE = AMT_FEE + $8  where TSTAMP_START = $9  and T_FIN_ENTITY_ID = $10  and T_FIN_ENTITY_ID_2 is null and T_MIS_MCC = $11  and CATEGORY_ID = $12  and INTERVAL_TYPE = $13  and ( SYNC_INTERVAL_NO = $14  or SYNC_INTERVAL_NO is null ) and BIN = $15 ", 
	ECPGt_double,&(AMS_AMT_TRAN),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_AMT_SURCHARGE),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_AMT_POS_REIMBURSE),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_CASHBACK_AMT),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_TRAN_COUNT),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_TIME_AT_ISS),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_TIME_AT_RQST_SWTCH),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_AMT_FEE),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(AMS_TSTAMP_START),(long)11,(long)1,(11)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_T_FIN_ENTITY_ID),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(AMS_T_MIS_MCC),(long)5,(long)1,(5)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_CATEGORY_ID),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(AMS_INTERVAL_TYPE),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_SYNC_INTERVAL_NO),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(AMS_BIN),(long)12,(long)1,(12)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 264 "CXOSDG13.sqx"

   else
      { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "update T_MIS_TOTAL set AMT_TRAN = AMT_TRAN + $1  , AMT_SURCHARGE = AMT_SURCHARGE + $2  , AMT_POS_REIMBURSE = AMT_POS_REIMBURSE + $3  , CASHBACK_AMT = CASHBACK_AMT + $4  , TRAN_COUNT = TRAN_COUNT + $5  , TIME_AT_ISS = TIME_AT_ISS + $6  , TIME_AT_RQST_SWTCH = TIME_AT_RQST_SWTCH + $7  , AMT_FEE = AMT_FEE + $8  where TSTAMP_START = $9  and T_FIN_ENTITY_ID = $10  and T_FIN_ENTITY_ID_2 = $11  and T_MIS_MCC = $12  and CATEGORY_ID = $13  and INTERVAL_TYPE = $14  and ( SYNC_INTERVAL_NO = $15  or SYNC_INTERVAL_NO is null ) and BIN = $16 ", 
	ECPGt_double,&(AMS_AMT_TRAN),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_AMT_SURCHARGE),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_AMT_POS_REIMBURSE),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_CASHBACK_AMT),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_TRAN_COUNT),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_TIME_AT_ISS),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_TIME_AT_RQST_SWTCH),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(AMS_AMT_FEE),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(AMS_TSTAMP_START),(long)11,(long)1,(11)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_T_FIN_ENTITY_ID),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_T_FIN_ENTITY_ID_2),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(AMS_T_MIS_MCC),(long)5,(long)1,(5)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_CATEGORY_ID),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(AMS_INTERVAL_TYPE),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(AMS_SYNC_INTERVAL_NO),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(AMS_BIN),(long)12,(long)1,(12)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 286 "CXOSDG13.sqx"

   int iRC = checkResult();
   if (iRC == -1)
   {
      char szTemp[5 * PERCENTLD + 7 * PERCENTF + 3 * PERCENTS];
      snprintf(szTemp,sizeof(szTemp),"UPDATE T_MIS_TOTAL %s %ld %ld %s %ld %.0f %.0f %.0f %.0f %ld %.0f %.0f %.0f %ld %s",
         AMS_TSTAMP_START,AMS_T_FIN_ENTITY_ID,AMS_T_FIN_ENTITY_ID_2,AMS_T_MIS_MCC,AMS_CATEGORY_ID,AMS_AMT_TRAN,AMS_AMT_SURCHARGE,
         AMS_AMT_POS_REIMBURSE,AMS_CASHBACK_AMT,AMS_TRAN_COUNT,AMS_TIME_AT_ISS,AMS_TIME_AT_RQST_SWTCH,AMS_AMT_FEE,AMS_SYNC_INTERVAL_NO,AMS_BIN);
      Trace::put(szTemp);
   }
   return iRC;
  //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS::tableUpdate%611EAE150193.body
}

// Additional Declarations
  //## begin dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.declarations preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLAggregatorMIS%611E792F0385.declarations

} // namespace dnpostgresqldatabase

//## begin module%611E79C00229.epilog preserve=yes
//## end module%611E79C00229.epilog
