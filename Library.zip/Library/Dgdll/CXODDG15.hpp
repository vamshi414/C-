//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%611EBFF8030F.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%611EBFF8030F.cm

//## begin module%611EBFF8030F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%611EBFF8030F.cp

//## Module: CXOSDG15%611EBFF8030F; Package specification
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\bV03.1A.R011\Windows\Build\Dn\Server\Library\Dgdll\CXODDG15.hpp

#ifndef CXOSDG15_h
#define CXOSDG15_h 1

//## begin module%611EBFF8030F.additionalIncludes preserve=no
//## end module%611EBFF8030F.additionalIncludes

//## begin module%611EBFF8030F.includes preserve=yes
//## end module%611EBFF8030F.includes

#ifndef CXOSST80_h
#include "CXODST80.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::PostgreSQLDatabase_CAT%604A21800240
namespace postgresqldatabase {
class PostgreSQLDatabase;

} // namespace postgresqldatabase

//## begin module%611EBFF8030F.declarations preserve=no
//## end module%611EBFF8030F.declarations

//## begin module%611EBFF8030F.additionalDeclarations preserve=yes
//## end module%611EBFF8030F.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

//## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.preface preserve=yes
//## end dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.preface

//## Class: PostgreSQLMonthlyTotals%611EBEE4024E
//## Category: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
//## Subsystem: DGDLL%611293FE02A0
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%611EC2E4009F;monitor::UseCase { -> F}
//## Uses: <unnamed>%611EC2E60368;IF::Trace { -> F}
//## Uses: <unnamed>%611EC2EA0044;postgresqldatabase::PostgreSQLDatabase { -> F}

class DllExport PostgreSQLMonthlyTotals : public settlement::MonthlyTotal  //## Inherits: <unnamed>%611EBF010326
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.initialDeclarations preserve=yes
public:
   enum State
   {
      INTERPRET_DUPLICATE = 20,
      DEADLOCK_TIMEOUT,
      DATABASE_FAILURE,
      DATABASE_CONNECTION_ERROR,
      RESOURCE_UNAVAILABLE_ERROR,
      ROW_NOT_FOUND,
      UNDEFINED_NAME,
      SUCCESS,
      CONNECT,
      EXIT
   };
  //## end dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.initialDeclarations

  public:
    //## Constructors (generated)
      PostgreSQLMonthlyTotals();

    //## Destructor (generated)
      virtual ~PostgreSQLMonthlyTotals();


    //## Other Operations (specified)
      //## Operation: checkResult%611EC31D005B
      int checkResult ();

      //## Operation: commit%611EC31D0067
      virtual bool commit ();

      //## Operation: lockTables%611EC31D0072
      void lockTables ();

      //## Operation: tableUpdate%611EC31D0080
      virtual int tableUpdate ();

    // Additional Public Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.public preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.public
  protected:
    // Additional Protected Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.protected preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.protected

  private:
    // Additional Private Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.private preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.implementation preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.implementation

};

//## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.postscript preserve=yes
//## end dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.postscript

} // namespace dnpostgresqldatabase

//## begin module%611EBFF8030F.epilog preserve=yes
//## end module%611EBFF8030F.epilog


#endif
