/* Processed by ecpg (14.1) */
/* These include files are added by the preprocessor */
#include <ecpglib.h>
#include <ecpgerrno.h>
#include <sqlca.h>
/* End of automatic include section */

#line 1 "CXOSDG10.sqx"
//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%611EAF2E02C2.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%611EAF2E02C2.cm

//## begin module%611EAF2E02C2.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%611EAF2E02C2.cp

//## Module: CXOSDG10%611EAF2E02C2; Package body
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\bV03.1A.R011\Windows\Build\Dn\Server\Library\Dgdll\CXOSDG10.sqx

//## begin module%611EAF2E02C2.additionalIncludes preserve=no
//## end module%611EAF2E02C2.additionalIncludes

//## begin module%611EAF2E02C2.includes preserve=yes
//## end module%611EAF2E02C2.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSST12_h
#include "CXODST12.hpp"
#endif
#ifndef CXOSST04_h
#include "CXODST04.hpp"
#endif
#ifndef CXOSST14_h
#include "CXODST14.hpp"
#endif
#ifndef CXOSST09_h
#include "CXODST09.hpp"
#endif
#ifndef CXOSST11_h
#include "CXODST11.hpp"
#endif
#ifndef CXOSST10_h
#include "CXODST10.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSPG01_h
#include "CXODPG01.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDG10_h
#include "CXODDG10.hpp"
#endif


//## begin module%611EAF2E02C2.declarations preserve=no
//## end module%611EAF2E02C2.declarations

//## begin module%611EAF2E02C2.additionalDeclarations preserve=yes
/* exec sql begin declare section */
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

#line 72 "CXOSDG10.sqx"
 int CTV_CATEGORY_ID [ 128 ] ;
 
#line 73 "CXOSDG10.sqx"
 int CTV_ENTITY_GROUP_ID [ 128 ] ;
 
#line 74 "CXOSDG10.sqx"
 int CTV_TRAN_COUNT [ 128 ] ;
 
#line 75 "CXOSDG10.sqx"
 double CTV_AMT_RECON_NET [ 128 ] ;
 
#line 76 "CXOSDG10.sqx"
 double CTV_AMT_TRAN [ 128 ] ;
 
#line 77 "CXOSDG10.sqx"
 double CTV_AMT_CARD_BILL [ 128 ] ;
 
#line 78 "CXOSDG10.sqx"
 double CTV_AMT_RECON_ACQ [ 128 ] ;
 
#line 79 "CXOSDG10.sqx"
 double CTV_AMT_RECON_ISS [ 128 ] ;
 
#line 80 "CXOSDG10.sqx"
 char CTV_TSTAMP_LAST_UPDATE [ 128 ] [ 15 ] ;
 
#line 81 "CXOSDG10.sqx"
 int CTV_T_FIN_ENTITY_ID ;
 
#line 82 "CXOSDG10.sqx"
 char CTV_ENTITY_TYPE [ 3 ] ;
 
#line 83 "CXOSDG10.sqx"
 char CTV_ENTITY_ID [ 29 ] ;
 
#line 84 "CXOSDG10.sqx"
 int CTV_SYNC_INTERVAL_NO ;
 
#line 85 "CXOSDG10.sqx"
 short CTV_SEQUENCE_NO ;
 
#line 86 "CXOSDG10.sqx"
 int CTV_PERIOD_ID ;
 
#line 87 "CXOSDG10.sqx"
 char CTV_TSTAMP_END [ 17 ] ;
 
#line 88 "CXOSDG10.sqx"
 char CTV_TSTAMP_TRANS_FROM [ 17 ] ;
 
#line 89 "CXOSDG10.sqx"
 char CTV_TSTAMP_TRANS_TO [ 17 ] ;
 
#line 90 "CXOSDG10.sqx"
 char CTV_DATE_RECON [ 9 ] ;
 
#line 91 "CXOSDG10.sqx"
 char CTV_TSTAMP_LAST_UPDATED [ 17 ] ;
 
#line 92 "CXOSDG10.sqx"
 char CTV_NET_ID_ACQ [ 4 ] ;
 
#line 93 "CXOSDG10.sqx"
 char CTV_NET_ID_ISS [ 4 ] ;
 
#line 94 "CXOSDG10.sqx"
 char CTV_FIN_TYPE [ 4 ] ;
 
#line 95 "CXOSDG10.sqx"
 char CTV_TRAN_TYPE_ID [ 11 ] ;
 
#line 96 "CXOSDG10.sqx"
 char CTV_ACT_CODE [ 4 ] ;
 
#line 97 "CXOSDG10.sqx"
 char CTV_FUNC_CODE [ 4 ] ;
 
#line 98 "CXOSDG10.sqx"
 char CTV_AUTH_BY [ 2 ] ;
 
#line 99 "CXOSDG10.sqx"
 char CTV_REV_BY [ 2 ] ;
 
#line 100 "CXOSDG10.sqx"
 char CTV_CUR_RECON_NET [ 4 ] ;
 
#line 101 "CXOSDG10.sqx"
 char CTV_CUR_TRAN [ 4 ] ;
 
#line 102 "CXOSDG10.sqx"
 char CTV_CUR_CARD_BILL [ 4 ] ;
 
#line 103 "CXOSDG10.sqx"
 char CTV_CUR_RECON_ACQ [ 4 ] ;
 
#line 104 "CXOSDG10.sqx"
 char CTV_CUR_RECON_ISS [ 4 ] ;
 
#line 105 "CXOSDG10.sqx"
 char CTV_IMPACT_TO_ACQ [ 2 ] ;
 
#line 106 "CXOSDG10.sqx"
 char CTV_IMPACT_TO_ISS [ 2 ] ;
 
#line 107 "CXOSDG10.sqx"
 char CTV_TRAN_DISPOSITION [ 2 ] ;
 
#line 108 "CXOSDG10.sqx"
 char CTV_TOTAL_TYPE [ 5 ] ;
 
#line 109 "CXOSDG10.sqx"
 char CTV_TRAN_CLASS [ 4 ] ;
 
#line 110 "CXOSDG10.sqx"
 char CTV_MERCH_TYPE [ 5 ] ;
 
#line 111 "CXOSDG10.sqx"
 char CTV_NETWORK_PROGRAM [ 11 ] ;
 
#line 112 "CXOSDG10.sqx"
 char CTV_IMAGEID [ 5 ] ;
 
#line 113 "CXOSDG10.sqx"
 char CTV_TASKID [ 8 ] ;
 
#line 114 "CXOSDG10.sqx"
 char CTV_CONTEXT_TYPE [ 2 ] ;
 
#line 115 "CXOSDG10.sqx"
 char CTV_CONTEXT_KEY [ 33 ] ;
 
#line 116 "CXOSDG10.sqx"
 char CTV_CONTEXT_DATA [ 101 ] ;
/* exec sql end declare section */
#line 117 "CXOSDG10.sqx"

//## end module%611EAF2E02C2.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

// Class dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor 

PostgreSQLCheckpointTotalsVisitor::PostgreSQLCheckpointTotalsVisitor()
  //## begin PostgreSQLCheckpointTotalsVisitor::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1_const.hasinit preserve=no
  //## end PostgreSQLCheckpointTotalsVisitor::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1_const.hasinit
  //## begin PostgreSQLCheckpointTotalsVisitor::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1_const.initialization preserve=yes
  //## end PostgreSQLCheckpointTotalsVisitor::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1_const.initialization
{
  //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1_const.body preserve=yes
   memcpy(m_sID,"DG10",4);
   //m_pContext = ((OracleDatabase*)Database::instance())->getContext();
   //EXEC SQL CONTEXT USE :m_pContext;
   memcpy(CTV_IMAGEID,Application::instance()->image().data(),Application::instance()->image().length());
   CTV_IMAGEID[Application::instance()->image().length()] = '\0';
   memcpy(CTV_TASKID,Application::instance()->name().data(),Application::instance()->name().length());
   CTV_TASKID[Application::instance()->name().length()] = '\0';
   CTV_CONTEXT_TYPE[0] = ' ';
   CTV_CONTEXT_TYPE[1] = '\0';
   memcpy(CTV_CONTEXT_KEY,"LOAD ",5);
  //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1_const.body
}


PostgreSQLCheckpointTotalsVisitor::~PostgreSQLCheckpointTotalsVisitor()
{
  //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::~PostgreSQLCheckpointTotalsVisitor%611EAEC102F1_dest.body preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::~PostgreSQLCheckpointTotalsVisitor%611EAEC102F1_dest.body
}



//## Other Operations (implementation)
bool PostgreSQLCheckpointTotalsVisitor::checkResult ()
{
  //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::checkResult%611EAFD903C1.body preserve=yes
   int iInfoIDNumber;
   State nState = (PostgreSQLCheckpointTotalsVisitor::State)((postgresqldatabase::PostgreSQLDatabase*)Database::instance())->evaluateState(sqlca.sqlcode,sqlca.sqlstate,&iInfoIDNumber);
   if(nState == PostgreSQLCheckpointTotalsVisitor::SUCCESS)
      return true;
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca,m_sID,m_strDBAccess.c_str());
   return false;
  //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::checkResult%611EAFD903C1.body
}

void PostgreSQLCheckpointTotalsVisitor::lockTables ()
{
  //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::lockTables%611EAFD903C4.body preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::lockTables%611EAFD903C4.body
}

void PostgreSQLCheckpointTotalsVisitor::visitAccumulator (Accumulator* pAccumulator)
{
  //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitAccumulator%611EAFD903C7.body preserve=yes
   if (Database::instance()->getDormant())
      Database::instance()->connect();
  //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitAccumulator%611EAFD903C7.body
}

void PostgreSQLCheckpointTotalsVisitor::visitEntityGroup (EntityGroup* pEntityGroup)
{
  //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitEntityGroup%611EAFD903CC.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   m_lENTITY_GROUP_ID = pEntityGroup->getENTITY_GROUP_ID();
   CTV_ENTITY_GROUP_ID[0] = pEntityGroup->getENTITY_GROUP_ID();
   CTV_SYNC_INTERVAL_NO = pEntityGroup->getSYNC_INTERVAL_NO();
   m_strDBAccess = "INSERT";
   { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "insert into T_FIN_ENTITY_GROUP ( ENTITY_GROUP_ID , SYNC_INTERVAL_NO ) values ( $1  , $2  )", 
	ECPGt_int,&(CTV_ENTITY_GROUP_ID[0]),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(CTV_SYNC_INTERVAL_NO),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 204 "CXOSDG10.sqx"

   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_ENTITY_GROUP %ld %ld",CTV_ENTITY_GROUP_ID[0],CTV_SYNC_INTERVAL_NO);
      Trace::put(szTemp,-1,true);
      return;
   }
   for (CTV_SEQUENCE_NO = 1;CTV_SEQUENCE_NO <= 7;++CTV_SEQUENCE_NO)
   {
      CTV_PERIOD_ID = pEntityGroup->getPERIOD_ID(CTV_SEQUENCE_NO);
      { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "insert into T_FIN_E_GROUP_ITEM ( ENTITY_GROUP_ID , SEQUENCE_NO , PERIOD_ID ) values ( $1  , $2  , $3  )", 
	ECPGt_int,&(CTV_ENTITY_GROUP_ID[0]),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_short,&(CTV_SEQUENCE_NO),(long)1,(long)1,sizeof(short), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(CTV_PERIOD_ID),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 227 "CXOSDG10.sqx"

      if (!checkResult())
      {
         char szTemp[128];
         snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_E_GROUP_ITEM %ld %hd %ld",CTV_ENTITY_GROUP_ID[0],CTV_SEQUENCE_NO,CTV_PERIOD_ID);
         Trace::put(szTemp,-1,true);
         return;
      }
   }
  //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitEntityGroup%611EAFD903CC.body
}

void PostgreSQLCheckpointTotalsVisitor::visitRecoveryPoint (RecoveryPoint* pRecoveryPoint)
{
  //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitRecoveryPoint%611EAFD903D0.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   memcpy(CTV_CONTEXT_KEY + 5,pRecoveryPoint->getInterval().data(),pRecoveryPoint->getInterval().length());
   CTV_CONTEXT_KEY[pRecoveryPoint->getInterval().length() + 5] = '\0';
   snprintf(CTV_CONTEXT_DATA,sizeof(CTV_CONTEXT_DATA),"%d:%d",pRecoveryPoint->getStartTime(),pRecoveryPoint->getEndTime());
   if (pRecoveryPoint->getState() == PersistentObject::NEW)
   {
      m_strDBAccess = "INSERT";
      { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "insert into TASK_CONTEXT ( IMAGEID , TASKID , CONTEXT_TYPE , CONTEXT_KEY , CONTEXT_DATA ) values ( $1  , $2  , $3  , $4  , $5  )", 
	ECPGt_char,(CTV_IMAGEID),(long)5,(long)1,(5)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TASKID),(long)8,(long)1,(8)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_CONTEXT_TYPE),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_CONTEXT_KEY),(long)33,(long)1,(33)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_CONTEXT_DATA),(long)101,(long)1,(101)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 266 "CXOSDG10.sqx"

   }
   else
   {
      m_strDBAccess = "UPDATE";
      { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "update TASK_CONTEXT set CONTEXT_DATA = $1  where IMAGEID = $2  and TASKID = $3  and CONTEXT_TYPE = $4  and CONTEXT_KEY = $5 ", 
	ECPGt_char,(CTV_CONTEXT_DATA),(long)101,(long)1,(101)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_IMAGEID),(long)5,(long)1,(5)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TASKID),(long)8,(long)1,(8)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_CONTEXT_TYPE),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_CONTEXT_KEY),(long)33,(long)1,(33)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 279 "CXOSDG10.sqx"

   }
   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"%s TASK_CONTEXT %s %s %s %s %s",m_strDBAccess.c_str(),
         CTV_IMAGEID,CTV_TASKID,CTV_CONTEXT_TYPE,CTV_CONTEXT_KEY,CTV_CONTEXT_DATA);
      Trace::put(szTemp,-1,true);
      return;
   }
  //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitRecoveryPoint%611EAFD903D0.body
}

void PostgreSQLCheckpointTotalsVisitor::visitReportingEntity (ReportingEntity* pReportingEntity)
{
  //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitReportingEntity%611EAFD903D3.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   m_lT_FIN_ENTITY_ID = pReportingEntity->getT_FIN_ENTITY_ID();
   if (pReportingEntity->getState() != PersistentObject::NEW)
      return;
   CTV_T_FIN_ENTITY_ID = pReportingEntity->getT_FIN_ENTITY_ID();
   memcpy(CTV_ENTITY_TYPE,pReportingEntity->getENTITY_TYPE().data(),pReportingEntity->getENTITY_TYPE().length());
   CTV_ENTITY_TYPE[pReportingEntity->getENTITY_TYPE().length()] = '\0';
   if (pReportingEntity->getENTITY_ID().length() == 0)
   {
      memcpy(CTV_ENTITY_ID," ",1);
      CTV_ENTITY_ID[1] = '\0';
   }
   else
   {
      memcpy(CTV_ENTITY_ID,pReportingEntity->getENTITY_ID().data(),pReportingEntity->getENTITY_ID().length());
      CTV_ENTITY_ID[pReportingEntity->getENTITY_ID().length()] = '\0';
   }
   m_strDBAccess = "INSERT";
   { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "insert into T_FIN_ENTITY ( T_FIN_ENTITY_ID , ENTITY_TYPE , ENTITY_ID ) values ( $1  , $2  , $3  )", 
	ECPGt_int,&(CTV_T_FIN_ENTITY_ID),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_ENTITY_TYPE),(long)3,(long)1,(3)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_ENTITY_ID),(long)29,(long)1,(29)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 326 "CXOSDG10.sqx"

   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_ENTITY %ld %s %s",CTV_T_FIN_ENTITY_ID,CTV_ENTITY_TYPE,CTV_ENTITY_ID);
      Trace::put(szTemp,-1,true);
      return;
   }
  //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitReportingEntity%611EAFD903D3.body
}

void PostgreSQLCheckpointTotalsVisitor::visitReportingPeriod (ReportingPeriod* pReportingPeriod)
{
  //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitReportingPeriod%611EAFD903D6.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   if (pReportingPeriod->getState() == ReportingPeriod::SAVED)
      return;
   CTV_PERIOD_ID = pReportingPeriod->getPERIOD_ID();
   CTV_T_FIN_ENTITY_ID = m_lT_FIN_ENTITY_ID;
   char szSpace[2] = {" "};
   if (!pReportingPeriod->getTSTAMP_END().empty())
   {
      memcpy(CTV_TSTAMP_END,pReportingPeriod->getTSTAMP_END().data(),pReportingPeriod->getTSTAMP_END().length());
      CTV_TSTAMP_END[pReportingPeriod->getTSTAMP_END().length()] = '\0';
   }
   else
      memcpy(CTV_TSTAMP_END,szSpace,2);
   if (!pReportingPeriod->getTSTAMP_TRANS_FROM().empty())
   {
      memcpy(CTV_TSTAMP_TRANS_FROM,pReportingPeriod->getTSTAMP_TRANS_FROM().data(),pReportingPeriod->getTSTAMP_TRANS_FROM().length());
      CTV_TSTAMP_TRANS_FROM[pReportingPeriod->getTSTAMP_TRANS_FROM().length()] = '\0';
   }
   else
      memcpy(CTV_TSTAMP_TRANS_FROM,szSpace,2);
   if (!pReportingPeriod->getTSTAMP_TRANS_TO().empty())
   {
      memcpy(CTV_TSTAMP_TRANS_TO,pReportingPeriod->getTSTAMP_TRANS_TO().data(),pReportingPeriod->getTSTAMP_TRANS_TO().length());
      CTV_TSTAMP_TRANS_TO[pReportingPeriod->getTSTAMP_TRANS_TO().length()] = '\0';
   }
   else
      memcpy(CTV_TSTAMP_TRANS_TO,szSpace,2);
   if (!pReportingPeriod->getDATE_RECON().empty())
   {
      memcpy(CTV_DATE_RECON,pReportingPeriod->getDATE_RECON().data(),pReportingPeriod->getDATE_RECON().length());
      CTV_DATE_RECON[pReportingPeriod->getDATE_RECON().length()] = '\0';
   }
   else
      memcpy(CTV_DATE_RECON,szSpace,2);
   if (!pReportingPeriod->getTSTAMP_LAST_UPDATE().empty())
   {
      memcpy(CTV_TSTAMP_LAST_UPDATED,pReportingPeriod->getTSTAMP_LAST_UPDATE().data(),pReportingPeriod->getTSTAMP_LAST_UPDATE().length());
      CTV_TSTAMP_LAST_UPDATED[pReportingPeriod->getTSTAMP_LAST_UPDATE().length()] = '\0';
   }
   else
      memcpy(CTV_TSTAMP_LAST_UPDATED,szSpace,2);
   m_strDBAccess = "INSERT";
   if (pReportingPeriod->getState() == ReportingPeriod::NEW)
   {
      { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "insert into T_FIN_PERIOD ( PERIOD_ID , T_FIN_ENTITY_ID , TSTAMP_END , TSTAMP_TRANS_FROM , TSTAMP_TRANS_TO , DATE_RECON , TSTAMP_LAST_UPDATE ) values ( $1  , $2  , $3  , $4  , $5  , $6  , $7  )", 
	ECPGt_int,&(CTV_PERIOD_ID),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(CTV_T_FIN_ENTITY_ID),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TSTAMP_END),(long)17,(long)1,(17)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TSTAMP_TRANS_FROM),(long)17,(long)1,(17)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TSTAMP_TRANS_TO),(long)17,(long)1,(17)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_DATE_RECON),(long)9,(long)1,(9)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TSTAMP_LAST_UPDATED),(long)17,(long)1,(17)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 405 "CXOSDG10.sqx"

   }
   else
   {
      m_strDBAccess = "UPDATE";
      { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "update T_FIN_PERIOD set TSTAMP_END = $1  , TSTAMP_TRANS_FROM = $2  , TSTAMP_TRANS_TO = $3  , DATE_RECON = $4  , TSTAMP_LAST_UPDATE = $5  where PERIOD_ID = $6 ", 
	ECPGt_char,(CTV_TSTAMP_END),(long)17,(long)1,(17)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TSTAMP_TRANS_FROM),(long)17,(long)1,(17)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TSTAMP_TRANS_TO),(long)17,(long)1,(17)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_DATE_RECON),(long)9,(long)1,(9)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TSTAMP_LAST_UPDATED),(long)17,(long)1,(17)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(CTV_PERIOD_ID),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 419 "CXOSDG10.sqx"

   }
   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"%s T_FIN_PERIOD %ld %ld %s %s %s %s %s",m_strDBAccess.c_str(),
         CTV_PERIOD_ID,CTV_T_FIN_ENTITY_ID,CTV_TSTAMP_END,CTV_TSTAMP_TRANS_FROM,CTV_TSTAMP_TRANS_TO,CTV_DATE_RECON,CTV_TSTAMP_LAST_UPDATE);
      Trace::put(szTemp,-1,true);
      return;
   }
   pReportingPeriod->setState(ReportingPeriod::SAVED);
  //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitReportingPeriod%611EAFD903D6.body
}

void PostgreSQLCheckpointTotalsVisitor::visitTotal (Total* pTotal)
{
  //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitTotal%611EAFD903DB.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   int i = reusable::Thread::getNumber();
   CTV_CATEGORY_ID[i] = pTotal->getCATEGORY_ID();
   CTV_ENTITY_GROUP_ID[i] = pTotal->getENTITY_GROUP_ID();
   CTV_TRAN_COUNT[i] = pTotal->getTRAN_COUNT();;
   CTV_AMT_RECON_NET[i] = pTotal->getAMT_RECON_NET();
   CTV_AMT_TRAN[i] = pTotal->getAMT_TRAN();
   CTV_AMT_CARD_BILL[i] = pTotal->getAMT_CARD_BILL();
   CTV_AMT_RECON_ACQ[i] = pTotal->getAMT_RECON_ACQ();
   CTV_AMT_RECON_ISS[i] = pTotal->getAMT_RECON_ISS();
   memcpy(CTV_TSTAMP_LAST_UPDATE[i],Clock::instance()->getYYYYMMDDHHMMSS().data(),14);
   CTV_TSTAMP_LAST_UPDATE[i][14] = '\0';
   m_strDBAccess = "UPDATE";
   { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "update T_FIN_TOTAL set TRAN_COUNT = TRAN_COUNT + $1  , AMT_RECON_NET = AMT_RECON_NET + $2  , AMT_TRAN = AMT_TRAN + $3  , AMT_CARD_BILL = AMT_CARD_BILL + $4  , AMT_RECON_ACQ = AMT_RECON_ACQ + $5  , AMT_RECON_ISS = AMT_RECON_ISS + $6  , TSTAMP_LAST_UPDATE = $7  where CATEGORY_ID = $8  and ENTITY_GROUP_ID = $9 ", 
	ECPGt_int,&(CTV_TRAN_COUNT[i]),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(CTV_AMT_RECON_NET[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(CTV_AMT_TRAN[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(CTV_AMT_CARD_BILL[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(CTV_AMT_RECON_ACQ[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(CTV_AMT_RECON_ISS[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TSTAMP_LAST_UPDATE[i]),(long)15,(long)1,(15)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(CTV_CATEGORY_ID[i]),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(CTV_ENTITY_GROUP_ID[i]),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 462 "CXOSDG10.sqx"

   if (sqlca.sqlcode == 100 || sqlca.sqlcode == 1403)
   {
      m_strDBAccess = "INSERT";
      { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "insert into T_FIN_TOTAL ( CATEGORY_ID , ENTITY_GROUP_ID , TRAN_COUNT , AMT_RECON_NET , AMT_TRAN , AMT_CARD_BILL , AMT_RECON_ACQ , AMT_RECON_ISS , TSTAMP_LAST_UPDATE ) values ( $1  , $2  , $3  , $4  , $5  , $6  , $7  , $8  , $9  )", 
	ECPGt_int,&(CTV_CATEGORY_ID[i]),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(CTV_ENTITY_GROUP_ID[i]),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(CTV_TRAN_COUNT[i]),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(CTV_AMT_RECON_NET[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(CTV_AMT_TRAN[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(CTV_AMT_CARD_BILL[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(CTV_AMT_RECON_ACQ[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(CTV_AMT_RECON_ISS[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TSTAMP_LAST_UPDATE[i]),(long)15,(long)1,(15)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 490 "CXOSDG10.sqx"

   }
   if (!checkResult())
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"%s T_FIN_TOTAL %ld %ld %ld %f %f %f %f %f %s",
         m_strDBAccess.c_str(),CTV_CATEGORY_ID[i],CTV_ENTITY_GROUP_ID[i],CTV_TRAN_COUNT[i],
         CTV_AMT_RECON_NET[i],CTV_AMT_TRAN[i],CTV_AMT_CARD_BILL[i],CTV_AMT_RECON_ACQ[i],
         CTV_AMT_RECON_ISS[i],CTV_TSTAMP_LAST_UPDATE[i]);
      Trace::put(szTemp,-1,true);
   }
  //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitTotal%611EAFD903DB.body
}

void PostgreSQLCheckpointTotalsVisitor::visitTotalsCategory (TotalsCategory* pTotalsCategory)
{
  //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitTotalsCategory%611EAFD903DF.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   CTV_CATEGORY_ID[0] = pTotalsCategory->getCATEGORY_ID();
   char szSpace[2] = {" "};
   if (!pTotalsCategory->getNET_ID_ACQ().empty())
   {
      memcpy(CTV_NET_ID_ACQ,pTotalsCategory->getNET_ID_ACQ().data(),pTotalsCategory->getNET_ID_ACQ().length());
      CTV_NET_ID_ACQ[pTotalsCategory->getNET_ID_ACQ().length()] = '\0';
   }
   else
      memcpy(CTV_NET_ID_ACQ,szSpace,2);
   if (!pTotalsCategory->getNET_ID_ISS().empty())
   {
      memcpy(CTV_NET_ID_ISS,pTotalsCategory->getNET_ID_ISS().data(),pTotalsCategory->getNET_ID_ISS().length());
      CTV_NET_ID_ISS[pTotalsCategory->getNET_ID_ISS().length()] = '\0';
   }
   else
      memcpy(CTV_NET_ID_ISS,szSpace,2);
   if (!pTotalsCategory->getFIN_TYPE().empty())
   {
      memcpy(CTV_FIN_TYPE,pTotalsCategory->getFIN_TYPE().data(),pTotalsCategory->getFIN_TYPE().length());
      CTV_FIN_TYPE[pTotalsCategory->getFIN_TYPE().length()] = '\0';
   }
   else
      memcpy(CTV_FIN_TYPE,szSpace,2);
   if (!pTotalsCategory->getTRAN_TYPE_ID().empty())
   {
      memcpy(CTV_TRAN_TYPE_ID,pTotalsCategory->getTRAN_TYPE_ID().data(),pTotalsCategory->getTRAN_TYPE_ID().length());
      CTV_TRAN_TYPE_ID[pTotalsCategory->getTRAN_TYPE_ID().length()] = '\0';
   }
   else
      memcpy(CTV_TRAN_TYPE_ID,szSpace,2);
   if (!pTotalsCategory->getACT_CODE().empty())
   {
      memcpy(CTV_ACT_CODE,pTotalsCategory->getACT_CODE().data(),pTotalsCategory->getACT_CODE().length());
      CTV_ACT_CODE[pTotalsCategory->getACT_CODE().length()] = '\0';
   }
   else
      memcpy(CTV_ACT_CODE,szSpace,2);
   if (!pTotalsCategory->getFUNC_CODE().empty())
   {
      memcpy(CTV_FUNC_CODE,pTotalsCategory->getFUNC_CODE().data(),pTotalsCategory->getFUNC_CODE().length());
      CTV_FUNC_CODE[pTotalsCategory->getFUNC_CODE().length()] = '\0';
   }
   else
      memcpy(CTV_FUNC_CODE,szSpace,2);
   if (!pTotalsCategory->getAUTH_BY().empty())
   {
      memcpy(CTV_AUTH_BY,pTotalsCategory->getAUTH_BY().data(),pTotalsCategory->getAUTH_BY().length());
      CTV_AUTH_BY[pTotalsCategory->getAUTH_BY().length()] = '\0';
   }
   else
      memcpy(CTV_AUTH_BY,szSpace,2);
   if (!pTotalsCategory->getREV_BY().empty())
   {
      memcpy(CTV_REV_BY,pTotalsCategory->getREV_BY().data(),pTotalsCategory->getREV_BY().length());
      CTV_REV_BY[pTotalsCategory->getREV_BY().length()] = '\0';
   }
   else
      memcpy(CTV_REV_BY,szSpace,2);
   if (!pTotalsCategory->getCUR_RECON_NET().empty())
   {
      memcpy(CTV_CUR_RECON_NET,pTotalsCategory->getCUR_RECON_NET().data(),pTotalsCategory->getCUR_RECON_NET().length());
      CTV_CUR_RECON_NET[pTotalsCategory->getCUR_RECON_NET().length()] = '\0';
   }
   else
      memcpy(CTV_CUR_RECON_NET,szSpace,2);
   if (!pTotalsCategory->getCUR_TRAN().empty())
   {
      memcpy(CTV_CUR_TRAN,pTotalsCategory->getCUR_TRAN().data(),pTotalsCategory->getCUR_TRAN().length());
      CTV_CUR_TRAN[pTotalsCategory->getCUR_TRAN().length()] = '\0';
   }
   else
      memcpy(CTV_CUR_TRAN,szSpace,2);
   if (!pTotalsCategory->getCUR_CARD_BILL().empty())
   {
      memcpy(CTV_CUR_CARD_BILL,pTotalsCategory->getCUR_CARD_BILL().data(),pTotalsCategory->getCUR_CARD_BILL().length());
      CTV_CUR_CARD_BILL[pTotalsCategory->getCUR_CARD_BILL().length()] = '\0';
   }
   else
      memcpy(CTV_CUR_CARD_BILL,szSpace,2);
   if (!pTotalsCategory->getCUR_RECON_ACQ().empty())
   {
      memcpy(CTV_CUR_RECON_ACQ,pTotalsCategory->getCUR_RECON_ACQ().data(),pTotalsCategory->getCUR_RECON_ACQ().length());
      CTV_CUR_RECON_ACQ[pTotalsCategory->getCUR_RECON_ACQ().length()] = '\0';
   }
   else
      memcpy(CTV_CUR_RECON_ACQ,szSpace,2);
   if (!pTotalsCategory->getCUR_RECON_ISS().empty())
   {
      memcpy(CTV_CUR_RECON_ISS,pTotalsCategory->getCUR_RECON_ISS().data(),pTotalsCategory->getCUR_RECON_ISS().length());
      CTV_CUR_RECON_ISS[pTotalsCategory->getCUR_RECON_ISS().length()] = '\0';
   }
   else
      memcpy(CTV_CUR_RECON_ISS,szSpace,2);
   if (!pTotalsCategory->getIMPACT_TO_ACQ().empty())
   {
      memcpy(CTV_IMPACT_TO_ACQ,pTotalsCategory->getIMPACT_TO_ACQ().data(),pTotalsCategory->getIMPACT_TO_ACQ().length());
      CTV_IMPACT_TO_ACQ[pTotalsCategory->getIMPACT_TO_ACQ().length()] = '\0';
   }
   else
      memcpy(CTV_IMPACT_TO_ACQ,szSpace,2);
   if (!pTotalsCategory->getIMPACT_TO_ISS().empty())
   {
      memcpy(CTV_IMPACT_TO_ISS,pTotalsCategory->getIMPACT_TO_ISS().data(),pTotalsCategory->getIMPACT_TO_ISS().length());
      CTV_IMPACT_TO_ISS[pTotalsCategory->getIMPACT_TO_ISS().length()] = '\0';
   }
   else
      memcpy(CTV_IMPACT_TO_ISS,szSpace,2);
   if (!pTotalsCategory->getTRAN_DISPOSITION().empty())
   {
      memcpy(CTV_TRAN_DISPOSITION,pTotalsCategory->getTRAN_DISPOSITION().data(),pTotalsCategory->getTRAN_DISPOSITION().length());
      CTV_TRAN_DISPOSITION[pTotalsCategory->getTRAN_DISPOSITION().length()] = '\0';
   }
   else
      memcpy(CTV_TRAN_DISPOSITION,szSpace,2);
   if (!pTotalsCategory->getTOTAL_TYPE().empty())
   {
      memcpy(CTV_TOTAL_TYPE,pTotalsCategory->getTOTAL_TYPE().data(),pTotalsCategory->getTOTAL_TYPE().length());
      CTV_TOTAL_TYPE[pTotalsCategory->getTOTAL_TYPE().length()] = '\0';
   }
   else
      memcpy(CTV_TOTAL_TYPE,szSpace,2);
   if (!pTotalsCategory->getTRAN_CLASS().empty())
   {
      memcpy(CTV_TRAN_CLASS,pTotalsCategory->getTRAN_CLASS().data(),pTotalsCategory->getTRAN_CLASS().length());
      CTV_TRAN_CLASS[pTotalsCategory->getTRAN_CLASS().length()] = '\0';
   }
   else
      memcpy(CTV_TRAN_CLASS,szSpace,2);
   if (!pTotalsCategory->getMERCH_TYPE().empty())
   {
      memcpy(CTV_MERCH_TYPE,pTotalsCategory->getMERCH_TYPE().data(),pTotalsCategory->getMERCH_TYPE().length());
      CTV_MERCH_TYPE[pTotalsCategory->getMERCH_TYPE().length()] = '\0';
   }
   else
      memcpy(CTV_MERCH_TYPE,szSpace,2);
   if (!pTotalsCategory->getNETWORK_PROGRAM().empty())
   {
      memcpy(CTV_NETWORK_PROGRAM,pTotalsCategory->getNETWORK_PROGRAM().data(),pTotalsCategory->getNETWORK_PROGRAM().length());
      CTV_NETWORK_PROGRAM[pTotalsCategory->getNETWORK_PROGRAM().length()] = '\0';
   }
   else
      memcpy(CTV_NETWORK_PROGRAM,szSpace,2);
   m_strDBAccess = "INSERT";
   { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "insert into T_FIN_CATEGORY ( CATEGORY_ID , NET_ID_ACQ , NET_ID_ISS , FIN_TYPE , TRAN_TYPE_ID , ACT_CODE , FUNC_CODE , AUTH_BY , REV_BY , CUR_RECON_NET , CUR_TRAN , CUR_CARD_BILL , CUR_RECON_ACQ , CUR_RECON_ISS , IMPACT_TO_ACQ , IMPACT_TO_ISS , TRAN_DISPOSITION , TOTAL_TYPE , TRAN_CLASS , MERCH_TYPE , NETWORK_PROGRAM ) values ( $1  , $2  , $3  , $4  , $5  , $6  , $7  , $8  , $9  , $10  , $11  , $12  , $13  , $14  , $15  , $16  , $17  , $18  , $19  , $20  , $21  )", 
	ECPGt_int,&(CTV_CATEGORY_ID[0]),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_NET_ID_ACQ),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_NET_ID_ISS),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_FIN_TYPE),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TRAN_TYPE_ID),(long)11,(long)1,(11)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_ACT_CODE),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_FUNC_CODE),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_AUTH_BY),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_REV_BY),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_CUR_RECON_NET),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_CUR_TRAN),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_CUR_CARD_BILL),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_CUR_RECON_ACQ),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_CUR_RECON_ISS),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_IMPACT_TO_ACQ),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_IMPACT_TO_ISS),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TRAN_DISPOSITION),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TOTAL_TYPE),(long)5,(long)1,(5)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_TRAN_CLASS),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_MERCH_TYPE),(long)5,(long)1,(5)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(CTV_NETWORK_PROGRAM),(long)11,(long)1,(11)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 700 "CXOSDG10.sqx"

   if (!checkResult())
   {
      char szTemp[133];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_CATEGORY %ld %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
         CTV_CATEGORY_ID[0],CTV_NET_ID_ACQ,CTV_NET_ID_ISS,CTV_FIN_TYPE,CTV_TRAN_TYPE_ID,
         CTV_ACT_CODE,CTV_FUNC_CODE,CTV_AUTH_BY,CTV_REV_BY,CTV_CUR_RECON_NET,CTV_CUR_TRAN,
         CTV_CUR_CARD_BILL,CTV_CUR_RECON_ACQ,CTV_CUR_RECON_ISS,CTV_IMPACT_TO_ACQ,
         CTV_IMPACT_TO_ISS,CTV_TRAN_DISPOSITION,CTV_TOTAL_TYPE,CTV_TRAN_CLASS,CTV_MERCH_TYPE,CTV_NETWORK_PROGRAM);
      Trace::put(szTemp,-1,true);
      return;
   }
  //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::visitTotalsCategory%611EAFD903DF.body
}

// Additional Declarations
  //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.declarations preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.declarations

} // namespace dnpostgresqldatabase

//## begin module%611EAF2E02C2.epilog preserve=yes
//## end module%611EAF2E02C2.epilog
