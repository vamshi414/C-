//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%611EC07703C3.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%611EC07703C3.cm

//## begin module%611EC07703C3.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%611EC07703C3.cp

//## Module: CXOSDG16%611EC07703C3; Package specification
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\bV03.1A.R011\Windows\Build\Dn\Server\Library\Dgdll\CXODDG16.hpp

#ifndef CXOSDG16_h
#define CXOSDG16_h 1

//## begin module%611EC07703C3.additionalIncludes preserve=no
//## end module%611EC07703C3.additionalIncludes

//## begin module%611EC07703C3.includes preserve=yes
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
//## end module%611EC07703C3.includes

#ifndef CXOSST81_h
#include "CXODST81.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class FinancialTransaction;
} // namespace settlement

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class QMRInstitution;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class NPI;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::PostgreSQLDatabase_CAT%604A21800240
namespace postgresqldatabase {
class PostgreSQLDatabase;

} // namespace postgresqldatabase

//## begin module%611EC07703C3.declarations preserve=no
//## end module%611EC07703C3.declarations

//## begin module%611EC07703C3.additionalDeclarations preserve=yes
//## end module%611EC07703C3.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

//## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.preface preserve=yes
//## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.preface

//## Class: PostgreSQLMonthlyCardHolder%611EBEB9036E
//## Category: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
//## Subsystem: DGDLL%611293FE02A0
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%611EC1B703D2;postgresqldatabase::PostgreSQLDatabase { -> F}
//## Uses: <unnamed>%611EC1BB03CA;monitor::UseCase { -> F}
//## Uses: <unnamed>%611EC1BE0371;IF::Trace { -> F}
//## Uses: <unnamed>%611EC26E0004;configuration::QMRInstitution { -> F}
//## Uses: <unnamed>%611EC271024E;reusable::NPI { -> F}
//## Uses: <unnamed>%611EC27500AB;settlement::FinancialTransaction { -> F}

class DllExport PostgreSQLMonthlyCardHolder : public settlement::MonthlyCardHolder  //## Inherits: <unnamed>%611EBEDB0329
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.initialDeclarations preserve=yes
public:
   enum State
   {
      INTERPRET_DUPLICATE = 20,
      DEADLOCK_TIMEOUT,
      DATABASE_FAILURE,
      DATABASE_CONNECTION_ERROR,
      RESOURCE_UNAVAILABLE_ERROR,
      ROW_NOT_FOUND,
      UNDEFINED_NAME,
      SUCCESS,
      CONNECT,
      EXIT
   };
  //## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.initialDeclarations

  public:
    //## Constructors (generated)
      PostgreSQLMonthlyCardHolder();

    //## Destructor (generated)
      virtual ~PostgreSQLMonthlyCardHolder();


    //## Other Operations (specified)
      //## Operation: add%611EC2AF0124
      virtual bool add (const FinancialTransaction& hFinancialTransaction);

      //## Operation: checkResult%611EC2AF012F
      int checkResult ();

      //## Operation: commit%611EC2AF0151
      virtual bool commit ();

      //## Operation: lockTables%611EC2AF015D
      void lockTables ();

    // Additional Public Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.public preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.public

  protected:
    // Additional Protected Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.protected preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.protected

  private:
    // Additional Private Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.private preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.implementation preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.implementation

};

//## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.postscript preserve=yes
//## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.postscript

} // namespace dnpostgresqldatabase

//## begin module%611EC07703C3.epilog preserve=yes
//## end module%611EC07703C3.epilog


#endif
