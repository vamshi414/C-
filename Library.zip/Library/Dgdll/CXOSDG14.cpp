//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%611EBF7B002A.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%611EBF7B002A.cm

//## begin module%611EBF7B002A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%611EBF7B002A.cp

//## Module: CXOSDG14%611EBF7B002A; Package body
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\bV03.1A.R011\Windows\Build\Dn\Server\Library\Dgdll\CXOSDG14.cpp

//## begin module%611EBF7B002A.additionalIncludes preserve=no
//## end module%611EBF7B002A.additionalIncludes

//## begin module%611EBF7B002A.includes preserve=yes
//## end module%611EBF7B002A.includes

#ifndef CXOSIF44_h
#include "CXODIF44.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDG14_h
#include "CXODDG14.hpp"
#endif


//## begin module%611EBF7B002A.declarations preserve=no
//## end module%611EBF7B002A.declarations

//## begin module%611EBF7B002A.additionalDeclarations preserve=yes
//## end module%611EBF7B002A.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

// Class dnpostgresqldatabase::PostgreSQLMaintenanceProcedure 

PostgreSQLMaintenanceProcedure::PostgreSQLMaintenanceProcedure()
  //## begin PostgreSQLMaintenanceProcedure::PostgreSQLMaintenanceProcedure%611EBE89037D_const.hasinit preserve=no
      : m_lFreePages(0),
        m_lTotalPages(0),
        m_lUsedPages(0)
  //## end PostgreSQLMaintenanceProcedure::PostgreSQLMaintenanceProcedure%611EBE89037D_const.hasinit
  //## begin PostgreSQLMaintenanceProcedure::PostgreSQLMaintenanceProcedure%611EBE89037D_const.initialization preserve=yes
  //## end PostgreSQLMaintenanceProcedure::PostgreSQLMaintenanceProcedure%611EBE89037D_const.initialization
{
  //## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::PostgreSQLMaintenanceProcedure%611EBE89037D_const.body preserve=yes
   memcpy(m_sID,"DG14",4);
  //## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::PostgreSQLMaintenanceProcedure%611EBE89037D_const.body
}


PostgreSQLMaintenanceProcedure::~PostgreSQLMaintenanceProcedure()
{
  //## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::~PostgreSQLMaintenanceProcedure%611EBE89037D_dest.body preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::~PostgreSQLMaintenanceProcedure%611EBE89037D_dest.body
}



//## Other Operations (implementation)
void PostgreSQLMaintenanceProcedure::review (const char* pszText)
{
  //## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::review%611EC16D0074.body preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::review%611EC16D0074.body
}

// Additional Declarations
  //## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.declarations preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.declarations

} // namespace dnpostgresqldatabase

//## begin module%611EBF7B002A.epilog preserve=yes
//## end module%611EBF7B002A.epilog
