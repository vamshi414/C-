//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6112942800D2.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%6112942800D2.cm

//## begin module%6112942800D2.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%6112942800D2.cp

//## Module: CXOSDG01%6112942800D2; Package specification
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\bV03.1A.R011\Windows\Build\Dn\Server\Library\Dgdll\CXODDG01.hpp

#ifndef CXOSDG01_h
#define CXOSDG01_h 1

//## begin module%6112942800D2.additionalIncludes preserve=no
//## end module%6112942800D2.additionalIncludes

//## begin module%6112942800D2.includes preserve=yes
//## end module%6112942800D2.includes

#ifndef CXOSPG02_h
#include "CXODPG02.hpp"
#endif

//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
class ODBCAggregatorMIS;
class ODBCAggregatorPOSRisk;
class ODBCTransactionRemover;
class ODBCAddFinancialCommand;
class ODBCPartitionAllocator;
class ODBCPartitionDeallocator;
class ODBCLocator;
} // namespace dnodbcdatabase

//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
class PostgreSQLMonthlyTotals;
class PostgreSQLMonthlyCardHolder;
class PostgreSQLMaintenanceProcedure;
class PostgreSQLCheckpointTotalsVisitor;
class PostgreSQLAggregatorMIS;

} // namespace dnpostgresqldatabase

//## begin module%6112942800D2.declarations preserve=no
//## end module%6112942800D2.declarations

//## begin module%6112942800D2.additionalDeclarations preserve=yes
//## end module%6112942800D2.additionalDeclarations


namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

//## begin dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.preface preserve=yes
//## end dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.preface

//## Class: DNPostgreSQLDatabaseFactory%611293B7008D
//## Category: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
//## Subsystem: DGDLL%611293FE02A0
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%611E6EBD01CE;dnodbcdatabase::ODBCAggregatorPOSRisk { -> F}
//## Uses: <unnamed>%611E6EC0021D;dnodbcdatabase::ODBCAddFinancialCommand { -> F}
//## Uses: <unnamed>%611E6EC401FB;dnodbcdatabase::ODBCAggregatorMIS { -> F}
//## Uses: <unnamed>%611E6ECA033F;dnodbcdatabase::ODBCLocator { -> F}
//## Uses: <unnamed>%611E6ECF02B3;dnodbcdatabase::ODBCPartitionAllocator { -> F}
//## Uses: <unnamed>%611E6EDB036B;dnodbcdatabase::ODBCPartitionDeallocator { -> F}
//## Uses: <unnamed>%611E6EDF03D9;dnodbcdatabase::ODBCTransactionRemover { -> F}
//## Uses: <unnamed>%611ECA7D032D;PostgreSQLMaintenanceProcedure { -> F}
//## Uses: <unnamed>%611ECA8100EC;PostgreSQLMonthlyTotals { -> F}
//## Uses: <unnamed>%611ECA840097;PostgreSQLMonthlyCardHolder { -> F}
//## Uses: <unnamed>%611ECC270347;PostgreSQLAggregatorMIS { -> F}
//## Uses: <unnamed>%611ECC2B01B4;PostgreSQLCheckpointTotalsVisitor { -> F}

class DllExport DNPostgreSQLDatabaseFactory : public postgresqldatabase::PostgreSQLDatabaseFactory  //## Inherits: <unnamed>%611E6E920123
{
  //## begin dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.initialDeclarations preserve=yes
  //## end dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.initialDeclarations

  public:
    //## Constructors (generated)
      DNPostgreSQLDatabaseFactory();

    //## Destructor (generated)
      virtual ~DNPostgreSQLDatabaseFactory();


    //## Other Operations (specified)
      //## Operation: create%611E6F2B016A
      virtual Object* create (const char* pszClass, const char* pszValue = 0);

    // Additional Public Declarations
      //## begin dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.public preserve=yes
      //## end dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.public

  protected:
    // Additional Protected Declarations
      //## begin dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.protected preserve=yes
      //## end dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.protected

  private:
    // Additional Private Declarations
      //## begin dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.private preserve=yes
      //## end dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Classes%611E6F6602C9
      //## begin dnpostgresqldatabase::DNPostgreSQLDatabaseFactory::Classes%611E6F6602C9.attr preserve=no  private: map<string,int,less<string> > {U} 
      map<string,int,less<string> > m_hClasses;
      //## end dnpostgresqldatabase::DNPostgreSQLDatabaseFactory::Classes%611E6F6602C9.attr

    // Additional Implementation Declarations
      //## begin dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.implementation preserve=yes
      //## end dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.implementation

};

//## begin dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.postscript preserve=yes
//## end dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.postscript

} // namespace dnpostgresqldatabase

//## begin module%6112942800D2.epilog preserve=yes
//## end module%6112942800D2.epilog


#endif
