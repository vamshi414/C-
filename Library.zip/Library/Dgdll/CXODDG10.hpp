//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%611EAF2C0178.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%611EAF2C0178.cm

//## begin module%611EAF2C0178.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%611EAF2C0178.cp

//## Module: CXOSDG10%611EAF2C0178; Package specification
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\bV03.1A.R011\Windows\Build\Dn\Server\Library\Dgdll\CXODDG10.hpp

#ifndef CXOSDG10_h
#define CXOSDG10_h 1

//## begin module%611EAF2C0178.additionalIncludes preserve=no
//## end module%611EAF2C0178.additionalIncludes

//## begin module%611EAF2C0178.includes preserve=yes
#define SQLCA_NONE
#include "sqlca.h"
//## end module%611EAF2C0178.includes

#ifndef CXOSST06_h
#include "CXODST06.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class RecoveryPoint;
class EntityGroup;
class ReportingPeriod;
class TotalsCategory;
class ReportingEntity;
class Total;
} // namespace settlement

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::PostgreSQLDatabase_CAT%604A21800240
namespace postgresqldatabase {
class PostgreSQLDatabase;

} // namespace postgresqldatabase

//## begin module%611EAF2C0178.declarations preserve=no
//## end module%611EAF2C0178.declarations

//## begin module%611EAF2C0178.additionalDeclarations preserve=yes
//## end module%611EAF2C0178.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

//## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.preface preserve=yes
//## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.preface

//## Class: PostgreSQLCheckpointTotalsVisitor%611EAEC102F1
//## Category: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
//## Subsystem: DGDLL%611293FE02A0
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%611EB01601C2;database::Database { -> F}
//## Uses: <unnamed>%611EB0190131;monitor::UseCase { -> F}
//## Uses: <unnamed>%611EB01C00E6;timer::Clock { -> F}
//## Uses: <unnamed>%611EB01F0304;settlement::EntityGroup { -> F}
//## Uses: <unnamed>%611EB024000D;settlement::Total { -> F}
//## Uses: <unnamed>%611EB02702F4;settlement::RecoveryPoint { -> F}
//## Uses: <unnamed>%611EB03601AE;settlement::ReportingEntity { -> F}
//## Uses: <unnamed>%611EB03902CE;settlement::ReportingPeriod { -> F}
//## Uses: <unnamed>%611EB03C02A8;settlement::TotalsCategory { -> F}
//## Uses: <unnamed>%611EB03F0311;process::Application { -> F}
//## Uses: <unnamed>%611FDC6C0132;postgresqldatabase::PostgreSQLDatabase { -> F}
//## Uses: <unnamed>%611FDCD303B9;IF::Trace { -> F}

class DllExport PostgreSQLCheckpointTotalsVisitor : public settlement::CheckpointTotalsVisitor  //## Inherits: <unnamed>%611EAEEE000A
{
  //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.initialDeclarations preserve=yes
public:
   enum State
   {
      INTERPRET_DUPLICATE = 20,
      DEADLOCK_TIMEOUT,
      DATABASE_FAILURE,
      DATABASE_CONNECTION_ERROR,
      RESOURCE_UNAVAILABLE_ERROR,
      ROW_NOT_FOUND,
      UNDEFINED_NAME,
      SUCCESS,
      CONNECT,
      EXIT
   };
  //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.initialDeclarations

  public:
    //## Constructors (generated)
      PostgreSQLCheckpointTotalsVisitor();

    //## Destructor (generated)
      virtual ~PostgreSQLCheckpointTotalsVisitor();


    //## Other Operations (specified)
      //## Operation: visitAccumulator%611EAFD903C7
      virtual void visitAccumulator (Accumulator* pAccumulator);

      //## Operation: visitEntityGroup%611EAFD903CC
      virtual void visitEntityGroup (EntityGroup* pEntityGroup);

      //## Operation: visitRecoveryPoint%611EAFD903D0
      virtual void visitRecoveryPoint (RecoveryPoint* pRecoveryPoint);

      //## Operation: visitReportingEntity%611EAFD903D3
      virtual void visitReportingEntity (ReportingEntity* pReportingEntity);

      //## Operation: visitReportingPeriod%611EAFD903D6
      virtual void visitReportingPeriod (ReportingPeriod* pReportingPeriod);

      //## Operation: visitTotal%611EAFD903DB
      virtual void visitTotal (Total* pTotal);

      //## Operation: visitTotalsCategory%611EAFD903DF
      virtual void visitTotalsCategory (TotalsCategory* pTotalsCategory);

    // Additional Public Declarations
      //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.public preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.public

  protected:
    // Additional Protected Declarations
      //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.protected preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.protected

  private:

    //## Other Operations (specified)
      //## Operation: checkResult%611EAFD903C1
      bool checkResult ();

      //## Operation: lockTables%611EAFD903C4
      void lockTables ();

    // Additional Private Declarations
      //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.private preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DBAccess%61313BCF0115
      //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::DBAccess%61313BCF0115.attr preserve=no  private: string {U} 
      string m_strDBAccess;
      //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor::DBAccess%61313BCF0115.attr

    // Additional Implementation Declarations
      //## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.implementation preserve=yes
      //struct sqlca sqlca;
      //## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.implementation
};

//## begin dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.postscript preserve=yes
//## end dnpostgresqldatabase::PostgreSQLCheckpointTotalsVisitor%611EAEC102F1.postscript

} // namespace dnpostgresqldatabase

//## begin module%611EAF2C0178.epilog preserve=yes
//## end module%611EAF2C0178.epilog


#endif
