//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%611EBF78036B.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%611EBF78036B.cm

//## begin module%611EBF78036B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%611EBF78036B.cp

//## Module: CXOSDG14%611EBF78036B; Package specification
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\bV03.1A.R011\Windows\Build\Dn\Server\Library\Dgdll\CXODDG14.hpp

#ifndef CXOSDG14_h
#define CXOSDG14_h 1

//## begin module%611EBF78036B.additionalIncludes preserve=no
//## end module%611EBF78036B.additionalIncludes

//## begin module%611EBF78036B.includes preserve=yes
//## end module%611EBF78036B.includes

#ifndef CXOSDB03_h
#include "CXODDB03.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class SiteSpecification;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;

} // namespace timer

//## begin module%611EBF78036B.declarations preserve=no
//## end module%611EBF78036B.declarations

//## begin module%611EBF78036B.additionalDeclarations preserve=yes
//## end module%611EBF78036B.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

//## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.preface preserve=yes
//## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.preface

//## Class: PostgreSQLMaintenanceProcedure%611EBE89037D
//## Category: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
//## Subsystem: DGDLL%611293FE02A0
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%611EC1450132;IF::SiteSpecification { -> F}
//## Uses: <unnamed>%611EC14801D0;timer::Date { -> F}

class DllExport PostgreSQLMaintenanceProcedure : public database::MaintenanceProcedure  //## Inherits: <unnamed>%611EBEB10329
{
  //## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.initialDeclarations preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.initialDeclarations

  public:
    //## Constructors (generated)
      PostgreSQLMaintenanceProcedure();

    //## Destructor (generated)
      virtual ~PostgreSQLMaintenanceProcedure();


    //## Other Operations (specified)
      //## Operation: review%611EC16D0074
      virtual void review (const char* pszText);

    // Additional Public Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.public preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.public

  protected:
    // Additional Protected Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.protected preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.protected

  private:
    // Additional Private Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.private preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: FreePages%611EC16001B9
      //## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::FreePages%611EC16001B9.attr preserve=no  private: long {V} 0
      long m_lFreePages;
      //## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::FreePages%611EC16001B9.attr

      //## Attribute: Name%611EC16001C4
      //## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::Name%611EC16001C4.attr preserve=no  private: string {V} 
      string m_strName;
      //## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::Name%611EC16001C4.attr

      //## Attribute: TotalPages%611EC16001D0
      //## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::TotalPages%611EC16001D0.attr preserve=no  private: long {V} 0
      long m_lTotalPages;
      //## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::TotalPages%611EC16001D0.attr

      //## Attribute: UsedPages%611EC16001DA
      //## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::UsedPages%611EC16001DA.attr preserve=no  private: long {V} 0
      long m_lUsedPages;
      //## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure::UsedPages%611EC16001DA.attr

    // Additional Implementation Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.implementation preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.implementation

};

//## begin dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.postscript preserve=yes
//## end dnpostgresqldatabase::PostgreSQLMaintenanceProcedure%611EBE89037D.postscript

} // namespace dnpostgresqldatabase

//## begin module%611EBF78036B.epilog preserve=yes
//## end module%611EBF78036B.epilog


#endif
