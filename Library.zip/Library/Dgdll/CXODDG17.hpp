//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63105E7F01A6.cm preserve=no
//## end module%63105E7F01A6.cm

//## begin module%63105E7F01A6.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63105E7F01A6.cp

//## Module: CXOSDG17%63105E7F01A6; Package specification
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Dgdll\CXODDG17.hpp

#ifndef CXOSDG17_h
#define CXOSDG17_h 1

//## begin module%63105E7F01A6.additionalIncludes preserve=no
//## end module%63105E7F01A6.additionalIncludes

//## begin module%63105E7F01A6.includes preserve=yes
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
//## end module%63105E7F01A6.includes

#ifndef CXOSST87_h
#include "CXODST87.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class FinancialTransaction;
} // namespace settlement

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class NPI;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::PostgreSQLDatabase_CAT%604A21800240
namespace postgresqldatabase {
class PostgreSQLDatabase;

} // namespace postgresqldatabase

//## begin module%63105E7F01A6.declarations preserve=no
//## end module%63105E7F01A6.declarations

//## begin module%63105E7F01A6.additionalDeclarations preserve=yes
//## end module%63105E7F01A6.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

//## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.preface preserve=yes
//## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.preface

//## Class: PostgreSQLMISMonthlyCardHolder%63105F850166
//## Category: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
//## Subsystem: DGDLL%611293FE02A0
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%631061290300;monitor::UseCase { -> F}
//## Uses: <unnamed>%6310612F01F1;IF::Trace { -> F}
//## Uses: <unnamed>%63106131032E;postgresqldatabase::PostgreSQLDatabase { -> F}
//## Uses: <unnamed>%6310613400F1;settlement::FinancialTransaction { -> F}
//## Uses: <unnamed>%63106137024F;reusable::NPI { -> F}

class DllExport PostgreSQLMISMonthlyCardHolder : public settlement::MISMonthlyCardHolder  //## Inherits: <unnamed>%631061230218
{
  //## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.initialDeclarations preserve=yes
public:
   enum State
   {
      INTERPRET_DUPLICATE = 20,
      DEADLOCK_TIMEOUT,
      DATABASE_FAILURE,
      DATABASE_CONNECTION_ERROR,
      RESOURCE_UNAVAILABLE_ERROR,
      ROW_NOT_FOUND,
      UNDEFINED_NAME,
      SUCCESS,
      CONNECT,
      EXIT
   };
  //## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.initialDeclarations

  public:
    //## Constructors (generated)
      PostgreSQLMISMonthlyCardHolder();

    //## Destructor (generated)
      virtual ~PostgreSQLMISMonthlyCardHolder();


    //## Other Operations (specified)
      //## Operation: add%6310614E0304
      virtual bool add (const FinancialTransaction& hFinancialTransaction);

      //## Operation: checkResult%6310617E0342
      int checkResult ();

      //## Operation: commit%63106195014B
      virtual bool commit ();

      //## Operation: lockTables%631061AE01CC
      void lockTables ();

    // Additional Public Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.public preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.public

  protected:
    // Additional Protected Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.protected preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.protected

  private:
    // Additional Private Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.private preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.implementation preserve=yes
      //## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.implementation

};

//## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.postscript preserve=yes
//## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.postscript

} // namespace dnpostgresqldatabase

//## begin module%63105E7F01A6.epilog preserve=yes
//## end module%63105E7F01A6.epilog


#endif
