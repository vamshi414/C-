/* Processed by ecpg (14.1) */
/* These include files are added by the preprocessor */
#include <ecpglib.h>
#include <ecpgerrno.h>
#include <sqlca.h>
/* End of automatic include section */

#line 1 "CXOSDG16.sqx"
//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%611EC079026F.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%611EC079026F.cm

//## begin module%611EC079026F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%611EC079026F.cp

//## Module: CXOSDG16%611EC079026F; Package body
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\bV03.1A.R011\Windows\Build\Dn\Server\Library\Dgdll\CXOSDG16.sqx

//## begin module%611EC079026F.additionalIncludes preserve=no
//## end module%611EC079026F.additionalIncludes

//## begin module%611EC079026F.includes preserve=yes
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
//## end module%611EC079026F.includes

#ifndef CXOSPG01_h
#include "CXODPG01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSCFB7_h
#include "CXODCFB7.hpp"
#endif
#ifndef CXOSRU48_h
#include "CXODRU48.hpp"
#endif
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
#ifndef CXOSDG16_h
#include "CXODDG16.hpp"
#endif


//## begin module%611EC079026F.declarations preserve=no
//## end module%611EC079026F.declarations

//## begin module%611EC079026F.additionalDeclarations preserve=yes
/* exec sql begin declare section */
    
    
    
    
           
     

#line 56 "CXOSDG16.sqx"
 char QMR_CARDHOLDER_YEAR_MONTH [ 512 ] [ 7 ] ;
 
#line 57 "CXOSDG16.sqx"
 char QMR_CARDHOLDER_INST_ID [ 512 ] [ 12 ] ;
 
#line 58 "CXOSDG16.sqx"
 char QMR_CARDHOLDER_PAN [ 512 ] [ 29 ] ;
 
#line 59 "CXOSDG16.sqx"
 char QMR_CARDHOLDER_NETWORK_ID [ 512 ] [ 4 ] ;
 
#line 60 "CXOSDG16.sqx"
 char QMR_CARDHOLDER_BIN [ 512 ] [ 12 ] ;
 
#line 61 "CXOSDG16.sqx"
 int QMR_CARDHOLDER_ROWS ;
/* exec sql end declare section */
#line 62 "CXOSDG16.sqx"

//## end module%611EC079026F.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

// Class dnpostgresqldatabase::PostgreSQLMonthlyCardHolder 

PostgreSQLMonthlyCardHolder::PostgreSQLMonthlyCardHolder()
  //## begin PostgreSQLMonthlyCardHolder::PostgreSQLMonthlyCardHolder%611EBEB9036E_const.hasinit preserve=no
  //## end PostgreSQLMonthlyCardHolder::PostgreSQLMonthlyCardHolder%611EBEB9036E_const.hasinit
  //## begin PostgreSQLMonthlyCardHolder::PostgreSQLMonthlyCardHolder%611EBEB9036E_const.initialization preserve=yes
  //## end PostgreSQLMonthlyCardHolder::PostgreSQLMonthlyCardHolder%611EBEB9036E_const.initialization
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder::PostgreSQLMonthlyCardHolder%611EBEB9036E_const.body preserve=yes
   memcpy(m_sID,"DG16",4);
   QMR_CARDHOLDER_ROWS =0;
  //## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder::PostgreSQLMonthlyCardHolder%611EBEB9036E_const.body
}


PostgreSQLMonthlyCardHolder::~PostgreSQLMonthlyCardHolder()
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder::~PostgreSQLMonthlyCardHolder%611EBEB9036E_dest.body preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder::~PostgreSQLMonthlyCardHolder%611EBEB9036E_dest.body
}



//## Other Operations (implementation)
bool PostgreSQLMonthlyCardHolder::add (const FinancialTransaction& hFinancialTransaction)
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder::add%611EC2AF0124.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return false;
   if (hFinancialTransaction.getTRAN_DISPOSITION() == "2")
      return true;
   if (QMR_CARDHOLDER_ROWS >= 512)
      if (!commit())
         return false;
   int iBIN_LENGTH;
   string strNETWORK_ID;
   string strBIN(hFinancialTransaction.getPAN().c_str(), 11);
   if (QMRInstitution::getBinDetails(hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN),
      strBIN,iBIN_LENGTH,strNETWORK_ID) == false)
      return true;
   strBIN.resize(iBIN_LENGTH);
   char szSpace[2] = {" "};
   string strPAN(hFinancialTransaction.getPAN());
   NPI::instance(2)->protect(strPAN);
   if(!hFinancialTransaction.getTSTAMP_TRANS().empty())
   {
      memcpy(QMR_CARDHOLDER_YEAR_MONTH[QMR_CARDHOLDER_ROWS],hFinancialTransaction.getTSTAMP_TRANS().data(),6);
      QMR_CARDHOLDER_YEAR_MONTH[QMR_CARDHOLDER_ROWS][6] = '\0';
   }
   else
      memcpy(QMR_CARDHOLDER_YEAR_MONTH[QMR_CARDHOLDER_ROWS],szSpace,2);
   if(!strPAN.empty())
   {
      memcpy(QMR_CARDHOLDER_PAN[QMR_CARDHOLDER_ROWS] ,strPAN.data(),strPAN.length());
      QMR_CARDHOLDER_PAN[QMR_CARDHOLDER_ROWS][strPAN.length()] = '\0';
   }
   else
      memcpy(QMR_CARDHOLDER_PAN[QMR_CARDHOLDER_ROWS],szSpace,2);
   if(!hFinancialTransaction.getINST_ID_ISS().empty())
   {
      memcpy(QMR_CARDHOLDER_INST_ID[QMR_CARDHOLDER_ROWS] ,hFinancialTransaction.getINST_ID_ISS().data(),
         hFinancialTransaction.getINST_ID_ISS().length());
      QMR_CARDHOLDER_INST_ID[QMR_CARDHOLDER_ROWS][hFinancialTransaction.getINST_ID_ISS().length()] = '\0';
   }
   else
      memcpy(QMR_CARDHOLDER_INST_ID[QMR_CARDHOLDER_ROWS],szSpace,2);
   if(!hFinancialTransaction.getNET_ID_ACQ().empty())
   {
      memcpy(QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS] ,hFinancialTransaction.getNET_ID_ACQ().data(),
         hFinancialTransaction.getNET_ID_ACQ().length());
      QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS][hFinancialTransaction.getNET_ID_ACQ().length()] = '\0';
   }
   else if (!strNETWORK_ID.empty())
   {
      memcpy(QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS], strNETWORK_ID.data(),strNETWORK_ID.length());
      QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS][strNETWORK_ID.length()] = '\0';
   }
   else
      memcpy(QMR_CARDHOLDER_NETWORK_ID[QMR_CARDHOLDER_ROWS],szSpace,2);
   if(!strBIN.empty())
   {
      memcpy(QMR_CARDHOLDER_BIN[QMR_CARDHOLDER_ROWS] ,strBIN.data(),strBIN.length());
      QMR_CARDHOLDER_BIN[QMR_CARDHOLDER_ROWS][strBIN.length()] = '\0';
   }
   else
      memcpy(QMR_CARDHOLDER_BIN[QMR_CARDHOLDER_ROWS],szSpace,2);
   QMR_CARDHOLDER_ROWS++;
   return true;
  //## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder::add%611EC2AF0124.body
}

int PostgreSQLMonthlyCardHolder::checkResult ()
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder::checkResult%611EC2AF012F.body preserve=yes
   int iInfoIDNumber;
   State nState = (PostgreSQLMonthlyCardHolder::State)((postgresqldatabase::PostgreSQLDatabase*)Database::instance())->evaluateState(sqlca.sqlcode,sqlca.sqlstate,&iInfoIDNumber);
   if(nState == PostgreSQLMonthlyCardHolder::SUCCESS || 
      nState == PostgreSQLMonthlyCardHolder::ROW_NOT_FOUND ||
      nState == PostgreSQLMonthlyCardHolder::INTERPRET_DUPLICATE);
      return 1;
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca, m_sID,"MERGE");
   return -1;
  //## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder::checkResult%611EC2AF012F.body
}

bool PostgreSQLMonthlyCardHolder::commit ()
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder::commit%611EC2AF0151.body preserve=yes
   if(QMR_CARDHOLDER_ROWS ==0)
      return true;
   int iNumRows = QMR_CARDHOLDER_ROWS;
   for(int i = 0; i < iNumRows; i++)
   {
      { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "insert into T_QMR_CARDHOLDER ( YEAR_MONTH , INST_ID , PAN , NETWORK_ID , BIN ) values ( $1  , $2  , $3  , $4  , $5  )", 
	ECPGt_char,(QMR_CARDHOLDER_YEAR_MONTH[i]),(long)7,(long)1,(7)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_CARDHOLDER_INST_ID[i]),(long)12,(long)1,(12)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_CARDHOLDER_PAN[i]),(long)29,(long)1,(29)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_CARDHOLDER_NETWORK_ID[i]),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_CARDHOLDER_BIN[i]),(long)12,(long)1,(12)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 201 "CXOSDG16.sqx"

/*//uncomment this section for postgresql versions 9.5 and higher
         ON CONFLICT
         (
            YEAR_MONTH,
            INST_ID,   
            PAN,       
            NETWORK_ID,
            BIN        
         )
         DO NOTHING;
*/
      int iRC= checkResult();
      if(iRC == -1)
      {
         char szTemp[81];
         for(int i=0;i < QMR_CARDHOLDER_ROWS; i++)
         {
            snprintf(szTemp, sizeof(szTemp), "MERGE INTO  %s %s %s %s %s ",
            QMR_CARDHOLDER_YEAR_MONTH[i],
            QMR_CARDHOLDER_INST_ID[i],
            QMR_CARDHOLDER_PAN[i],
            QMR_CARDHOLDER_NETWORK_ID[i],
            QMR_CARDHOLDER_BIN[i]);
            Trace::put(szTemp);
         }
         QMR_CARDHOLDER_ROWS = 0;
         return false;
      }    
   }
   QMR_CARDHOLDER_ROWS = 0;
   Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   return true;
  //## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder::commit%611EC2AF0151.body
}

void PostgreSQLMonthlyCardHolder::lockTables ()
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder::lockTables%611EC2AF015D.body preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder::lockTables%611EC2AF015D.body
}

// Additional Declarations
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.declarations preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLMonthlyCardHolder%611EBEB9036E.declarations

} // namespace dnpostgresqldatabase

//## begin module%611EC079026F.epilog preserve=yes
//## end module%611EC079026F.epilog
