/* Processed by ecpg (14.1) */
/* These include files are added by the preprocessor */
#include <ecpglib.h>
#include <ecpgerrno.h>
#include <sqlca.h>
/* End of automatic include section */

#line 1 "CXOSDG15.sqx"
//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%611EBFFA0285.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%611EBFFA0285.cm

//## begin module%611EBFFA0285.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%611EBFFA0285.cp

//## Module: CXOSDG15%611EBFFA0285; Package body
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\bV03.1A.R011\Windows\Build\Dn\Server\Library\Dgdll\CXOSDG15.sqx

//## begin module%611EBFFA0285.additionalIncludes preserve=no
//## end module%611EBFFA0285.additionalIncludes

//## begin module%611EBFFA0285.includes preserve=yes
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
//## end module%611EBFFA0285.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSPG01_h
#include "CXODPG01.hpp"
#endif
#ifndef CXOSDG15_h
#include "CXODDG15.hpp"
#endif


//## begin module%611EBFFA0285.declarations preserve=no
//## end module%611EBFFA0285.declarations

//## begin module%611EBFFA0285.additionalDeclarations preserve=yes
/* exec sql begin declare section */
              
    
                    
                     
      
              
              
           
          
               
                
              
                  
                  
                          
                     
                
                          
                          
    
                          
       
                          
       
                     
    
    

#line 47 "CXOSDG15.sqx"
 char QMR_YEAR_MONTH [ 512 ] [ 7 ] ;
 
#line 48 "CXOSDG15.sqx"
 char QMR_INST_ID [ 512 ] [ 12 ] ;
 
#line 49 "CXOSDG15.sqx"
 char QMR_ENTITY_ROLE [ 512 ] [ 2 ] ;
 
#line 50 "CXOSDG15.sqx"
 char QMR_BIN [ 512 ] [ 12 ] ;
 
#line 51 "CXOSDG15.sqx"
 char QMR_TOKEN_REQUESTOR_ID [ 512 ] [ 12 ] ;
 
#line 52 "CXOSDG15.sqx"
 char QMR_NETWORK_ID [ 512 ] [ 4 ] ;
 
#line 53 "CXOSDG15.sqx"
 char QMR_NETWORK_TRAN_TYPE [ 512 ] [ 3 ] ;
 
#line 54 "CXOSDG15.sqx"
 char QMR_FUNCTION_TYPE [ 512 ] [ 3 ] ;
 
#line 55 "CXOSDG15.sqx"
 char QMR_ACCT_TYPES_ISS [ 512 ] [ 5 ] ;
 
#line 56 "CXOSDG15.sqx"
 char QMR_MSG_CLASS [ 512 ] [ 2 ] ;
 
#line 57 "CXOSDG15.sqx"
 char QMR_PRE_AUTH [ 512 ] [ 2 ] ;
 
#line 58 "CXOSDG15.sqx"
 char QMR_TERM_CLASS [ 512 ] [ 3 ] ;
 
#line 59 "CXOSDG15.sqx"
 char QMR_COUNTRY_ISS_INST [ 512 ] [ 4 ] ;
 
#line 60 "CXOSDG15.sqx"
 char QMR_COUNTRY_ACQ_INST [ 512 ] [ 4 ] ;
 
#line 61 "CXOSDG15.sqx"
 char QMR_ONUS_FLG [ 512 ] [ 2 ] ;
 
#line 62 "CXOSDG15.sqx"
 char QMR_AUTHENTICATED [ 512 ] [ 2 ] ;
 
#line 63 "CXOSDG15.sqx"
 char QMR_POS_CRD_DAT_IN_MOD [ 512 ] [ 2 ] ;
 
#line 64 "CXOSDG15.sqx"
 char QMR_CUR_TRAN [ 512 ] [ 4 ] ;
 
#line 65 "CXOSDG15.sqx"
 char QMR_CUR_CASHBACK [ 512 ] [ 4 ] ;
 
#line 66 "CXOSDG15.sqx"
 char QMR_MERCH_TYPE [ 512 ] [ 5 ] ;
 
#line 67 "CXOSDG15.sqx"
 double QMR_AMT_TRAN [ 512 ] ;
 
#line 68 "CXOSDG15.sqx"
 int QMR_TRAN_COUNT [ 512 ] ;
 
#line 69 "CXOSDG15.sqx"
 double QMR_AMT_CASHBACK [ 512 ] ;
 
#line 70 "CXOSDG15.sqx"
 int QMR_CASHBACK_COUNT [ 512 ] ;
 
#line 71 "CXOSDG15.sqx"
 int QMR_ROWS ;
 
#line 72 "CXOSDG15.sqx"
 char VERSION [ 100 ] ;
 
#line 73 "CXOSDG15.sqx"
 char MERGE [ 3000 ] ;
/* exec sql end declare section */
#line 74 "CXOSDG15.sqx"

//EXEC SQL DECLARE QMR_STATEMENT STATEMENT;
//## end module%611EBFFA0285.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

// Class dnpostgresqldatabase::PostgreSQLMonthlyTotals 

PostgreSQLMonthlyTotals::PostgreSQLMonthlyTotals()
  //## begin PostgreSQLMonthlyTotals::PostgreSQLMonthlyTotals%611EBEE4024E_const.hasinit preserve=no
  //## end PostgreSQLMonthlyTotals::PostgreSQLMonthlyTotals%611EBEE4024E_const.hasinit
  //## begin PostgreSQLMonthlyTotals::PostgreSQLMonthlyTotals%611EBEE4024E_const.initialization preserve=yes
  //## end PostgreSQLMonthlyTotals::PostgreSQLMonthlyTotals%611EBEE4024E_const.initialization
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals::PostgreSQLMonthlyTotals%611EBEE4024E_const.body preserve=yes
   memcpy(m_sID,"DG15",4);
  //## end dnpostgresqldatabase::PostgreSQLMonthlyTotals::PostgreSQLMonthlyTotals%611EBEE4024E_const.body
}


PostgreSQLMonthlyTotals::~PostgreSQLMonthlyTotals()
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals::~PostgreSQLMonthlyTotals%611EBEE4024E_dest.body preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLMonthlyTotals::~PostgreSQLMonthlyTotals%611EBEE4024E_dest.body
}



//## Other Operations (implementation)
int PostgreSQLMonthlyTotals::checkResult ()
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals::checkResult%611EC31D005B.body preserve=yes
   int iInfoIDNumber;
   State nState = (PostgreSQLMonthlyTotals::State)((postgresqldatabase::PostgreSQLDatabase*)Database::instance())->evaluateState(sqlca.sqlcode,sqlca.sqlstate,&iInfoIDNumber);
   if(nState == PostgreSQLMonthlyTotals::SUCCESS || nState == PostgreSQLMonthlyTotals::ROW_NOT_FOUND)
      return 1;
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca, m_sID,"MERGE");
   return -1;
  //## end dnpostgresqldatabase::PostgreSQLMonthlyTotals::checkResult%611EC31D005B.body
}

bool PostgreSQLMonthlyTotals::commit ()
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals::commit%611EC31D0067.body preserve=yes
   if(QMR_ROWS ==0)
      return true;
   int iNumRows = QMR_ROWS;
   for(int i = 0; i < iNumRows; i++)
   {
      //This version must be used with PostgreSQL versions less than 9.5 
      { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "with upsert as ( update T_QMR_TOTAL set AMT_TRAN = AMT_TRAN + $1  , TRAN_COUNT = TRAN_COUNT + $2  , AMT_CASHBACK = AMT_CASHBACK + $3  , CASHBACK_COUNT = CASHBACK_COUNT + $4  where YEAR_MONTH = $5  and INST_ID = $6  and ENTITY_ROLE = $7  and BIN = $8  and TOKEN_REQUESTOR_ID = $9  and NETWORK_ID = $10  and NETWORK_TRAN_TYPE = $11  and FUNCTION_TYPE = $12  and ACCT_TYPES_ISS = $13  and MSG_CLASS = $14  and PRE_AUTH = $15  and TERM_CLASS = $16  and COUNTRY_ISS_INST = $17  and COUNTRY_ACQ_INST = $18  and ONUS_FLG = $19  and AUTHENTICATED = $20  and POS_CRD_DAT_IN_MOD = $21  and MERCH_TYPE = $22  and CUR_TRAN = $23  and CUR_CASHBACK = $24  returning * ) insert into T_QMR_TOTAL ( YEAR_MONTH , INST_ID , ENTITY_ROLE , BIN , TOKEN_REQUESTOR_ID , NETWORK_ID , NETWORK_TRAN_TYPE , FUNCTION_TYPE , ACCT_TYPES_ISS , MSG_CLASS , PRE_AUTH , TERM_CLASS , COUNTRY_ISS_INST , COUNTRY_ACQ_INST , ONUS_FLG , AUTHENTICATED , POS_CRD_DAT_IN_MOD , MERCH_TYPE , CUR_TRAN , CUR_CASHBACK , AMT_TRAN , TRAN_COUNT , AMT_CASHBACK , CASHBACK_COUNT ) select $25  , $26  , $27  , $28  , $29  , $30  , $31  , $32  , $33  , $34  , $35  , $36  , $37  , $38  , $39  , $40  , $41  , $42  , $43  , $44  , $45  , $46  , $47  , $48  where not exists ( select 1 from upsert )", 
	ECPGt_double,&(QMR_AMT_TRAN[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(QMR_TRAN_COUNT[i]),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(QMR_AMT_CASHBACK[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(QMR_CASHBACK_COUNT[i]),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_YEAR_MONTH[i]),(long)7,(long)1,(7)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_INST_ID[i]),(long)12,(long)1,(12)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_ENTITY_ROLE[i]),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_BIN[i]),(long)12,(long)1,(12)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_TOKEN_REQUESTOR_ID[i]),(long)12,(long)1,(12)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_NETWORK_ID[i]),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_NETWORK_TRAN_TYPE[i]),(long)3,(long)1,(3)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_FUNCTION_TYPE[i]),(long)3,(long)1,(3)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_ACCT_TYPES_ISS[i]),(long)5,(long)1,(5)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_MSG_CLASS[i]),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_PRE_AUTH[i]),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_TERM_CLASS[i]),(long)3,(long)1,(3)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_COUNTRY_ISS_INST[i]),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_COUNTRY_ACQ_INST[i]),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_ONUS_FLG[i]),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_AUTHENTICATED[i]),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_POS_CRD_DAT_IN_MOD[i]),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_MERCH_TYPE[i]),(long)5,(long)1,(5)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_CUR_TRAN[i]),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_CUR_CASHBACK[i]),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_YEAR_MONTH[i]),(long)7,(long)1,(7)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_INST_ID[i]),(long)12,(long)1,(12)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_ENTITY_ROLE[i]),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_BIN[i]),(long)12,(long)1,(12)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_TOKEN_REQUESTOR_ID[i]),(long)12,(long)1,(12)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_NETWORK_ID[i]),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_NETWORK_TRAN_TYPE[i]),(long)3,(long)1,(3)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_FUNCTION_TYPE[i]),(long)3,(long)1,(3)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_ACCT_TYPES_ISS[i]),(long)5,(long)1,(5)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_MSG_CLASS[i]),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_PRE_AUTH[i]),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_TERM_CLASS[i]),(long)3,(long)1,(3)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_COUNTRY_ISS_INST[i]),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_COUNTRY_ACQ_INST[i]),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_ONUS_FLG[i]),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_AUTHENTICATED[i]),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_POS_CRD_DAT_IN_MOD[i]),(long)2,(long)1,(2)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_MERCH_TYPE[i]),(long)5,(long)1,(5)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_CUR_TRAN[i]),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(QMR_CUR_CASHBACK[i]),(long)4,(long)1,(4)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(QMR_AMT_TRAN[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(QMR_TRAN_COUNT[i]),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_double,&(QMR_AMT_CASHBACK[i]),(long)1,(long)1,sizeof(double), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_int,&(QMR_CASHBACK_COUNT[i]),(long)1,(long)1,sizeof(int), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 212 "CXOSDG15.sqx"

/* //This version should be used with PostgreSQL version 9.5 and higher
         EXEC SQL
         INSERT INTO T_QMR_TOTAL AS A
            (
               YEAR_MONTH,
               INST_ID,
               ENTITY_ROLE,
               BIN,
               TOKEN_REQUESTOR_ID,
               NETWORK_ID,
               NETWORK_TRAN_TYPE,
               FUNCTION_TYPE,
               ACCT_TYPES_ISS,
               MSG_CLASS,
               PRE_AUTH,
               TERM_CLASS,
               COUNTRY_ISS_INST,
               COUNTRY_ACQ_INST,
               ONUS_FLG,
               AUTHENTICATED,
               POS_CRD_DAT_IN_MOD,
               CUR_TRAN,
               MERCH_TYPE,
               AMT_TRAN,
               TRAN_COUNT,
               CUR_CASHBACK,
               AMT_CASHBACK,
               CASHBACK_COUNT
            )
            VALUES
            (
              :QMR_YEAR_MONTH[i],
              :QMR_INST_ID[i],
              :QMR_ENTITY_ROLE[i],
              :QMR_BIN[i],
              :QMR_TOKEN_REQUESTOR_ID[i],
              :QMR_NETWORK_ID[i],
              :QMR_NETWORK_TRAN_TYPE[i],
              :QMR_FUNCTION_TYPE[i],
              :QMR_ACCT_TYPES_ISS[i],
              :QMR_MSG_CLASS[i],
              :QMR_PRE_AUTH[i],
              :QMR_TERM_CLASS[i],
              :QMR_COUNTRY_ISS_INST[i],
              :QMR_COUNTRY_ACQ_INST[i],
              :QMR_ONUS_FLG[i],
              :QMR_AUTHENTICATED[i],
              :QMR_POS_CRD_DAT_IN_MOD[i],
              :QMR_CUR_TRAN[i],
              :QMR_MERCH_TYPE[i],
              :QMR_AMT_TRAN[i],
              :QMR_TRAN_COUNT[i],
              :QMR_CUR_CASHBACK[i],
              :QMR_AMT_CASHBACK[i],
              :QMR_CASHBACK_COUNT[i]
             ) 
             ON CONFLICT
             (
               YEAR_MONTH, INST_ID,ENTITY_ROLE, BIN, TOKEN_REQUESTOR_ID, NETWORK_ID,FUNCTION_TYPE, 
               ACCT_TYPES_ISS,MSG_CLASS,PRE_AUTH,TERM_CLASS,COUNTRY_ISS_INST,COUNTRY_ACQ_INST,ONUS_FLG,AUTHENTICATED,POS_CRD_DAT_IN_MOD,MERCH_TYPE,
               NETWORK_TRAN_TYPE,CUR_TRAN,CUR_CASHBACK
             )
             DO
               UPDATE SET 
                  AMT_TRAN = A.AMT_TRAN + :QMR_AMT_TRAN[i],
                  TRAN_COUNT = A.TRAN_COUNT + :QMR_TRAN_COUNT[i],
                  AMT_CASHBACK = A.AMT_CASHBACK + :QMR_AMT_CASHBACK[i],
                  CASHBACK_COUNT = A.CASHBACK_COUNT + :QMR_CASHBACK_COUNT[i];
*/
      int iRC= checkResult();
      if(iRC == -1)
      {
         char szTemp[104 + (2 * PERCENTLD) + (2 * PERCENTF)];
         for(int i=0;i < QMR_ROWS; i++)
         {
            snprintf(szTemp, sizeof(szTemp), "MERGE INTO %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %f %d %s %f %d",
               QMR_YEAR_MONTH[i],
               QMR_INST_ID[i],
               QMR_ENTITY_ROLE[i],
               QMR_BIN[i],
               QMR_TOKEN_REQUESTOR_ID[i],
               QMR_NETWORK_ID[i],
               QMR_NETWORK_TRAN_TYPE[i],
               QMR_FUNCTION_TYPE[i],
               QMR_ACCT_TYPES_ISS[i],
               QMR_MSG_CLASS[i],
               QMR_PRE_AUTH[i],
               QMR_TERM_CLASS[i],
               QMR_COUNTRY_ISS_INST[i],
               QMR_COUNTRY_ACQ_INST[i],
               QMR_ONUS_FLG[i],
               QMR_AUTHENTICATED[i],
               QMR_POS_CRD_DAT_IN_MOD[i],
               QMR_CUR_TRAN[i],
               QMR_MERCH_TYPE[i],
               QMR_AMT_TRAN[i],
               QMR_TRAN_COUNT[i],
               QMR_CUR_CASHBACK[i],
               QMR_AMT_CASHBACK[i],
               QMR_CASHBACK_COUNT[i]);
            Trace::put(szTemp);
         }
         QMR_ROWS = 0;
         return false;
      }    
   }
   Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   QMR_ROWS = 0;
   return true;
  //## end dnpostgresqldatabase::PostgreSQLMonthlyTotals::commit%611EC31D0067.body
}

void PostgreSQLMonthlyTotals::lockTables ()
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals::lockTables%611EC31D0072.body preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLMonthlyTotals::lockTables%611EC31D0072.body
}

int PostgreSQLMonthlyTotals::tableUpdate ()
{
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals::tableUpdate%611EC31D0080.body preserve=yes
   if (getENTITY_ROLE().empty())
      return 0;
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return -1;
   if (QMR_ROWS >= 512)
         if (!commit())
            return -1;
   char szSpace[2] = {" "};
   if(!getACCT_TYPES_ISS().empty())
   {
      memcpy(QMR_ACCT_TYPES_ISS[QMR_ROWS], getACCT_TYPES_ISS().data(), getACCT_TYPES_ISS().length());
      QMR_ACCT_TYPES_ISS[QMR_ROWS][getACCT_TYPES_ISS().length()] = '\0';
   }
   else
      memcpy(QMR_ACCT_TYPES_ISS[QMR_ROWS],szSpace,2);
   QMR_AMT_TRAN[QMR_ROWS] = getAMT_TRAN();
   QMR_AMT_CASHBACK[QMR_ROWS] = getAMT_CASHBACK();
   if(!getAUTHENTICATED().empty())
   {
      memcpy(QMR_AUTHENTICATED[QMR_ROWS],getAUTHENTICATED().data(),getAUTHENTICATED().length());
      QMR_AUTHENTICATED[QMR_ROWS][getAUTHENTICATED().length()] = '\0';
   }
   else
      memcpy(QMR_AUTHENTICATED[QMR_ROWS],szSpace,2);
   if(!getBIN().empty())
   {
      memcpy(QMR_BIN[QMR_ROWS], getBIN().data(), getBIN().length());
      QMR_BIN[QMR_ROWS][getBIN().length()] = '\0';
   }
   else
      memcpy(QMR_BIN[QMR_ROWS],szSpace,2);
   if(!getCOUNTRY_ACQ_INST().empty())
   {
      memcpy(QMR_COUNTRY_ACQ_INST[QMR_ROWS], getCOUNTRY_ACQ_INST().data(), getCOUNTRY_ACQ_INST().length());
      QMR_COUNTRY_ACQ_INST[QMR_ROWS][getCOUNTRY_ACQ_INST().length()] = '\0';
   }
   else
      memcpy(QMR_COUNTRY_ACQ_INST[QMR_ROWS],szSpace,2);
   if(!getCOUNTRY_ISS_INST().empty())
   {
      memcpy(QMR_COUNTRY_ISS_INST[QMR_ROWS], getCOUNTRY_ISS_INST().data(), getCOUNTRY_ISS_INST().length());
      QMR_COUNTRY_ISS_INST[QMR_ROWS][getCOUNTRY_ISS_INST().length()] = '\0';
   }
   else
      memcpy(QMR_COUNTRY_ISS_INST[QMR_ROWS],szSpace,2);
   if(!getCUR_TRAN().empty())
   {
      memcpy(QMR_CUR_TRAN[QMR_ROWS], getCUR_TRAN().data(), getCUR_TRAN().length());
      QMR_CUR_TRAN[QMR_ROWS][getCUR_TRAN().length()] = '\0';
   }
   else
      memcpy(QMR_CUR_TRAN[QMR_ROWS],szSpace,2);
   if(!getCUR_CASHBACK().empty())
   {
      memcpy(QMR_CUR_CASHBACK[QMR_ROWS], getCUR_CASHBACK().data(), getCUR_CASHBACK().length());
      QMR_CUR_CASHBACK[QMR_ROWS][getCUR_CASHBACK().length()] = '\0';
   }
   else
      memcpy(QMR_CUR_CASHBACK[QMR_ROWS],szSpace,2);
   if(!getFUNCTION_TYPE().empty())
   {
      memcpy(QMR_FUNCTION_TYPE[QMR_ROWS], getFUNCTION_TYPE().data(), getFUNCTION_TYPE().length());
      QMR_FUNCTION_TYPE[QMR_ROWS][getFUNCTION_TYPE().length()] = '\0';
   }
   else
      memcpy(QMR_FUNCTION_TYPE[QMR_ROWS],szSpace,2);
   if(!getINST_ID().empty())
   {
      memcpy(QMR_INST_ID[QMR_ROWS],getINST_ID().data(), getINST_ID().length());
      QMR_INST_ID[QMR_ROWS][getINST_ID().length()] = '\0';
   }
   else
      memcpy(QMR_INST_ID[QMR_ROWS],szSpace,2);
   if(!getMSG_CLASS().empty())
   {
      memcpy(QMR_MSG_CLASS[QMR_ROWS], getMSG_CLASS().data(), getMSG_CLASS().length());
      QMR_MSG_CLASS[QMR_ROWS][getMSG_CLASS().length()] = '\0';
   }
   else
      memcpy(QMR_MSG_CLASS[QMR_ROWS],szSpace,2);
   if(!getNETWORK_ID().empty())
   {
      memcpy(QMR_NETWORK_ID[QMR_ROWS], getNETWORK_ID().data(), getNETWORK_ID().length());
      QMR_NETWORK_ID[QMR_ROWS][getNETWORK_ID().length()] = '\0';
   }
   else
      memcpy(QMR_NETWORK_ID[QMR_ROWS],szSpace,2);
   if(!getNETWORK_TRAN_TYPE().empty())
   {
      memcpy(QMR_NETWORK_TRAN_TYPE[QMR_ROWS], getNETWORK_TRAN_TYPE().data(), getNETWORK_TRAN_TYPE().length());
      QMR_NETWORK_TRAN_TYPE[QMR_ROWS][getNETWORK_TRAN_TYPE().length()] = '\0';
   }
   else
      memcpy(QMR_NETWORK_TRAN_TYPE[QMR_ROWS],szSpace,2);
   if(!getONUS_FLG().empty())
   {
      memcpy(QMR_ONUS_FLG[QMR_ROWS], getONUS_FLG().data(), getONUS_FLG().length());
      QMR_ONUS_FLG[QMR_ROWS][getONUS_FLG().length()] = '\0';
   }
   else
      memcpy(QMR_ONUS_FLG[QMR_ROWS],szSpace,2);
   if(!getPOS_CRD_DAT_IN_MOD().empty())
   {
      memcpy(QMR_POS_CRD_DAT_IN_MOD[QMR_ROWS], getPOS_CRD_DAT_IN_MOD().data(), getPOS_CRD_DAT_IN_MOD().length());
      QMR_POS_CRD_DAT_IN_MOD[QMR_ROWS][getPOS_CRD_DAT_IN_MOD().length()] = '\0';
   }
   else
      memcpy(QMR_POS_CRD_DAT_IN_MOD[QMR_ROWS],szSpace,2);
   if(!getPRE_AUTH().empty())
   {
      memcpy(QMR_PRE_AUTH[QMR_ROWS], getPRE_AUTH().data(), getPRE_AUTH().length());
      QMR_PRE_AUTH[QMR_ROWS][getPRE_AUTH().length()] = '\0';
   }
   else
      memcpy(QMR_PRE_AUTH[QMR_ROWS],szSpace,2);
   if(!getENTITY_ROLE().empty())
   {
      memcpy(QMR_ENTITY_ROLE[QMR_ROWS], getENTITY_ROLE().data(), getENTITY_ROLE().length());
      QMR_ENTITY_ROLE[QMR_ROWS][getENTITY_ROLE().length()] = '\0';
   }
   else
      memcpy(QMR_ENTITY_ROLE[QMR_ROWS],szSpace,2);
   if(!getTERM_CLASS().empty())
   {
      memcpy(QMR_TERM_CLASS[QMR_ROWS], getTERM_CLASS().data(), getTERM_CLASS().length());
      QMR_TERM_CLASS[QMR_ROWS][getTERM_CLASS().length()] = '\0';
   }
   else
      memcpy(QMR_TERM_CLASS[QMR_ROWS],szSpace,2);
   if(!getTOKEN_REQUESTOR_ID().empty())
   {
      memcpy(QMR_TOKEN_REQUESTOR_ID[QMR_ROWS], getTOKEN_REQUESTOR_ID().data(), getTOKEN_REQUESTOR_ID().length());
      QMR_TOKEN_REQUESTOR_ID[QMR_ROWS][getTOKEN_REQUESTOR_ID().length()] = '\0';
   }
   else
      memcpy(QMR_TOKEN_REQUESTOR_ID[QMR_ROWS],szSpace,2);
   QMR_TRAN_COUNT[QMR_ROWS] = getTRAN_COUNT();
   QMR_CASHBACK_COUNT[QMR_ROWS] = getCASHBACK_COUNT();
   if(!getYEAR_MONTH().empty())
   {
      memcpy(QMR_YEAR_MONTH[QMR_ROWS], getYEAR_MONTH().data(), getYEAR_MONTH().length());
      QMR_YEAR_MONTH[QMR_ROWS][getYEAR_MONTH().length()] = '\0';
   }
   else
      memcpy(QMR_YEAR_MONTH[QMR_ROWS],szSpace,2);
   if(!getMERCH_TYPE().empty())
   {
      memcpy(QMR_MERCH_TYPE[QMR_ROWS], getMERCH_TYPE().data(), getMERCH_TYPE().length());
      QMR_MERCH_TYPE[QMR_ROWS][getMERCH_TYPE().length()] = '\0';
   }
   else
      memcpy(QMR_MERCH_TYPE[QMR_ROWS],szSpace,2);  
   QMR_ROWS++;
   return 0;
  //## end dnpostgresqldatabase::PostgreSQLMonthlyTotals::tableUpdate%611EC31D0080.body
}

// Additional Declarations
  //## begin dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.declarations preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLMonthlyTotals%611EBEE4024E.declarations
} // namespace dnpostgresqldatabase

//## begin module%611EBFFA0285.epilog preserve=yes
//## end module%611EBFFA0285.epilog
