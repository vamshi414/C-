/* Processed by ecpg (14.1) */
/* These include files are added by the preprocessor */
#include <ecpglib.h>
#include <ecpgerrno.h>
#include <sqlca.h>
/* End of automatic include section */

#line 1 "CXOSDG17.sqx"
//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63105E8100D9.cm preserve=no
//## end module%63105E8100D9.cm

//## begin module%63105E8100D9.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63105E8100D9.cp

//## Module: CXOSDG17%63105E8100D9; Package body
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Dgdll\CXOSDG17.sqx

//## begin module%63105E8100D9.additionalIncludes preserve=no
//## end module%63105E8100D9.additionalIncludes

//## begin module%63105E8100D9.includes preserve=yes
#define SQLCA_STORAGE_CLASS extern
#include "sqlca.h"
//## end module%63105E8100D9.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSPG01_h
#include "CXODPG01.hpp"
#endif
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
#ifndef CXOSRU48_h
#include "CXODRU48.hpp"
#endif
#ifndef CXOSDG17_h
#include "CXODDG17.hpp"
#endif


//## begin module%63105E8100D9.declarations preserve=no
//## end module%63105E8100D9.declarations

//## begin module%63105E8100D9.additionalDeclarations preserve=yes
/* exec sql begin declare section */
    
    
    
    
     

#line 51 "CXOSDG17.sqx"
 char MIS_CARDHOLDER_YEAR_MONTH [ 512 ] [ 7 ] ;
 
#line 52 "CXOSDG17.sqx"
 char MIS_CARDHOLDER_INST_ID [ 512 ] [ 12 ] ;
 
#line 53 "CXOSDG17.sqx"
 char MIS_CARDHOLDER_PAN [ 512 ] [ 29 ] ;
 
#line 54 "CXOSDG17.sqx"
 char MIS_CARDHOLDER_BIN [ 512 ] [ 12 ] ;
 
#line 55 "CXOSDG17.sqx"
 int MIS_CARDHOLDER_ROWS ;
/* exec sql end declare section */
#line 56 "CXOSDG17.sqx"

//## end module%63105E8100D9.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

// Class dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder 

PostgreSQLMISMonthlyCardHolder::PostgreSQLMISMonthlyCardHolder()
  //## begin PostgreSQLMISMonthlyCardHolder::PostgreSQLMISMonthlyCardHolder%63105F850166_const.hasinit preserve=no
  //## end PostgreSQLMISMonthlyCardHolder::PostgreSQLMISMonthlyCardHolder%63105F850166_const.hasinit
  //## begin PostgreSQLMISMonthlyCardHolder::PostgreSQLMISMonthlyCardHolder%63105F850166_const.initialization preserve=yes
  //## end PostgreSQLMISMonthlyCardHolder::PostgreSQLMISMonthlyCardHolder%63105F850166_const.initialization
{
  //## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder::PostgreSQLMISMonthlyCardHolder%63105F850166_const.body preserve=yes
   memcpy(m_sID,"DG17",4);
   MIS_CARDHOLDER_ROWS =0;
  //## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder::PostgreSQLMISMonthlyCardHolder%63105F850166_const.body
}


PostgreSQLMISMonthlyCardHolder::~PostgreSQLMISMonthlyCardHolder()
{
  //## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder::~PostgreSQLMISMonthlyCardHolder%63105F850166_dest.body preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder::~PostgreSQLMISMonthlyCardHolder%63105F850166_dest.body
}



//## Other Operations (implementation)
bool PostgreSQLMISMonthlyCardHolder::add (const FinancialTransaction& hFinancialTransaction)
{
  //## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder::add%6310614E0304.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return false;
   if (MIS_CARDHOLDER_ROWS >= 512)
      if (!commit())
         return false;
   string strBIN;
   string strPAN(hFinancialTransaction.getPAN());
   NPI::instance(2)->protect(strPAN);
   if(hFinancialTransaction.getBIN_LENGTH() > 0)
      strBIN = hFinancialTransaction.getPAN().substr(0, hFinancialTransaction.getBIN_LENGTH());
   else
      strBIN = hFinancialTransaction.getPAN().substr(0, 6);
   if(!hFinancialTransaction.getTSTAMP_TRANS().empty())
   {
      memcpy(MIS_CARDHOLDER_YEAR_MONTH[MIS_CARDHOLDER_ROWS],hFinancialTransaction.getTSTAMP_TRANS().data(),6);
      MIS_CARDHOLDER_YEAR_MONTH[MIS_CARDHOLDER_ROWS][6] = '\0';
   }
   else
      return true;
   if(!strPAN.empty())
   {
      memcpy(MIS_CARDHOLDER_PAN[MIS_CARDHOLDER_ROWS] ,strPAN.data(),strPAN.length());
      MIS_CARDHOLDER_PAN[MIS_CARDHOLDER_ROWS][strPAN.length()] = '\0';
      memcpy(MIS_CARDHOLDER_BIN[MIS_CARDHOLDER_ROWS] ,strBIN.data(),strBIN.length());
      MIS_CARDHOLDER_BIN[MIS_CARDHOLDER_ROWS][strBIN.length()] = '\0';
   }
   else
      return true;
   if(!hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).empty())
   {
      memcpy(MIS_CARDHOLDER_INST_ID[MIS_CARDHOLDER_ROWS] ,hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).data(),
         hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).length());
      MIS_CARDHOLDER_INST_ID[MIS_CARDHOLDER_ROWS][hFinancialTransaction.getINST_ID_RECN_ISS_B(FinancialTransaction::FIN).length()] = '\0';
   }
   else
      return true;
   MIS_CARDHOLDER_ROWS++;
   return true;
  //## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder::add%6310614E0304.body
}

int PostgreSQLMISMonthlyCardHolder::checkResult ()
{
  //## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder::checkResult%6310617E0342.body preserve=yes
   int iInfoIDNumber;
   State nState = (PostgreSQLMISMonthlyCardHolder::State)((postgresqldatabase::PostgreSQLDatabase*)Database::instance())->evaluateState(sqlca.sqlcode,sqlca.sqlstate,&iInfoIDNumber);
   if(nState == PostgreSQLMISMonthlyCardHolder::SUCCESS || 
      nState == PostgreSQLMISMonthlyCardHolder::ROW_NOT_FOUND ||
      nState == PostgreSQLMISMonthlyCardHolder::INTERPRET_DUPLICATE);
      return 1;
   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   Database::instance()->traceSQLError((void*)&sqlca, m_sID,"MERGE");
   return -1;
  //## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder::checkResult%6310617E0342.body
}

bool PostgreSQLMISMonthlyCardHolder::commit ()
{
  //## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder::commit%63106195014B.body preserve=yes
   if(MIS_CARDHOLDER_ROWS ==0)
      return true;
   int iNumRows = MIS_CARDHOLDER_ROWS;
   for(int i = 0; i < iNumRows; i++)
   {
      { ECPGdo(__LINE__, 0, 1, NULL, 0, ECPGst_normal, "insert into T_MIS_CARDHOLDER ( YEAR_MONTH , INST_ID , PAN , BIN ) values ( $1  , $2  , $3  , $4  )", 
	ECPGt_char,(MIS_CARDHOLDER_YEAR_MONTH[i]),(long)7,(long)1,(7)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(MIS_CARDHOLDER_INST_ID[i]),(long)12,(long)1,(12)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(MIS_CARDHOLDER_PAN[i]),(long)29,(long)1,(29)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, 
	ECPGt_char,(MIS_CARDHOLDER_BIN[i]),(long)12,(long)1,(12)*sizeof(char), 
	ECPGt_NO_INDICATOR, NULL , 0L, 0L, 0L, ECPGt_EOIT, ECPGt_EORT);}
#line 170 "CXOSDG17.sqx"

/*//uncomment this section for postgresql versions 9.5 and higher
         ON CONFLICT
         (
            YEAR_MONTH,
            INST_ID,   
            PAN,       
            BIN        
         )
         DO NOTHING;
*/
      int iRC= checkResult();
      if(iRC == -1)
      {
         char szTemp[76];
         for(int i=0;i < MIS_CARDHOLDER_ROWS; i++)
         {
            snprintf(szTemp, sizeof(szTemp), "MERGE INTO  %s %s %s %s ",
            MIS_CARDHOLDER_YEAR_MONTH[i],
            MIS_CARDHOLDER_INST_ID[i],
            MIS_CARDHOLDER_PAN[i],
            MIS_CARDHOLDER_BIN[i]);
            Trace::put(szTemp);
         }
         MIS_CARDHOLDER_ROWS = 0;
         return false;
      }    
   }
   MIS_CARDHOLDER_ROWS = 0;
   Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   return true;
  //## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder::commit%63106195014B.body
}

void PostgreSQLMISMonthlyCardHolder::lockTables ()
{
  //## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder::lockTables%631061AE01CC.body preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder::lockTables%631061AE01CC.body
}

// Additional Declarations
  //## begin dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.declarations preserve=yes
  //## end dnpostgresqldatabase::PostgreSQLMISMonthlyCardHolder%63105F850166.declarations

} // namespace dnpostgresqldatabase

//## begin module%63105E8100D9.epilog preserve=yes
//## end module%63105E8100D9.epilog
