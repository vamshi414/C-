//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6112942A01E6.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%6112942A01E6.cm

//## begin module%6112942A01E6.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%6112942A01E6.cp

//## Module: CXOSDG01%6112942A01E6; Package body
//## Subsystem: DGDLL%611293FE02A0
//## Source file: C:\bV03.1A.R011\Windows\Build\Dn\Server\Library\Dgdll\CXOSDG01.cpp

//## begin module%6112942A01E6.additionalIncludes preserve=no
//## end module%6112942A01E6.additionalIncludes

//## begin module%6112942A01E6.includes preserve=yes
#ifndef CXOSDG17_h
#include "CXODDG17.hpp"
#endif
//## end module%6112942A01E6.includes

#ifndef CXOSDQ12_h
#include "CXODDQ12.hpp"
#endif
#ifndef CXOSDQ04_h
#include "CXODDQ04.hpp"
#endif
#ifndef CXOSDQ13_h
#include "CXODDQ13.hpp"
#endif
#ifndef CXOSDQ02_h
#include "CXODDQ02.hpp"
#endif
#ifndef CXOSDQ07_h
#include "CXODDQ07.hpp"
#endif
#ifndef CXOSDQ08_h
#include "CXODDQ08.hpp"
#endif
#ifndef CXOSDQ09_h
#include "CXODDQ09.hpp"
#endif
#ifndef CXOSDG14_h
#include "CXODDG14.hpp"
#endif
#ifndef CXOSDG15_h
#include "CXODDG15.hpp"
#endif
#ifndef CXOSDG16_h
#include "CXODDG16.hpp"
#endif
#ifndef CXOSDG13_h
#include "CXODDG13.hpp"
#endif
#ifndef CXOSDG10_h
#include "CXODDG10.hpp"
#endif
#ifndef CXOSDG01_h
#include "CXODDG01.hpp"
#endif


//## begin module%6112942A01E6.declarations preserve=no
//## end module%6112942A01E6.declarations

//## begin module%6112942A01E6.additionalDeclarations preserve=yes
//## end module%6112942A01E6.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNPostgreSQLDatabase_CAT%611292FF0009
namespace dnpostgresqldatabase {
//## begin dnpostgresqldatabase%611292FF0009.initialDeclarations preserve=yes
extern "C" DatabaseFactory * create()
{
   return new DNPostgreSQLDatabaseFactory;
}
//## end dnpostgresqldatabase%611292FF0009.initialDeclarations

// Class dnpostgresqldatabase::DNPostgreSQLDatabaseFactory 

DNPostgreSQLDatabaseFactory::DNPostgreSQLDatabaseFactory()
  //## begin DNPostgreSQLDatabaseFactory::DNPostgreSQLDatabaseFactory%611293B7008D_const.hasinit preserve=no
  //## end DNPostgreSQLDatabaseFactory::DNPostgreSQLDatabaseFactory%611293B7008D_const.hasinit
  //## begin DNPostgreSQLDatabaseFactory::DNPostgreSQLDatabaseFactory%611293B7008D_const.initialization preserve=yes
  //## end DNPostgreSQLDatabaseFactory::DNPostgreSQLDatabaseFactory%611293B7008D_const.initialization
{
  //## begin dnpostgresqldatabase::DNPostgreSQLDatabaseFactory::DNPostgreSQLDatabaseFactory%611293B7008D_const.body preserve=yes
   memcpy(m_sID,"DG01",4);
#define CLASSES 12
   const char* pszPostgreSQLClass[CLASSES] =
   {
      "AddFinancialCommand",
      "AggregatorMIS",
      "AggregatorPOSRisk",
      "CheckpointTotalsVisitor",
      "Locator",
      "MaintenanceProcedure",
      "PartitionAllocator",
      "PartitionDeallocator",
      "TransactionRemover",
      "MonthlyTotal",
      "MonthlyCardHolder",
      "MISMonthlyCardHolder"
   };
   string strClass;
   for (int m = 0; m < CLASSES; ++m)
   {
      strClass = pszPostgreSQLClass[m];
      m_hClasses.insert(map<string,int,less<string> >::value_type(strClass,m));
   }
  //## end dnpostgresqldatabase::DNPostgreSQLDatabaseFactory::DNPostgreSQLDatabaseFactory%611293B7008D_const.body
}


DNPostgreSQLDatabaseFactory::~DNPostgreSQLDatabaseFactory()
{
  //## begin dnpostgresqldatabase::DNPostgreSQLDatabaseFactory::~DNPostgreSQLDatabaseFactory%611293B7008D_dest.body preserve=yes
  //## end dnpostgresqldatabase::DNPostgreSQLDatabaseFactory::~DNPostgreSQLDatabaseFactory%611293B7008D_dest.body
}



//## Other Operations (implementation)
Object* DNPostgreSQLDatabaseFactory::create (const char* pszClass, const char* pszValue)
{
  //## begin dnpostgresqldatabase::DNPostgreSQLDatabaseFactory::create%611E6F2B016A.body preserve=yes
   string strClass(pszClass);
   map<string,int,less<string> >::iterator pClass = m_hClasses.find(strClass);
   if (pClass == m_hClasses.end())
      return PostgreSQLDatabaseFactory::create(pszClass,pszValue);
   Object* pObject = 0;
   switch ((*pClass).second)
   {
   case 0:
      pObject = new ODBCAddFinancialCommand();
      break;
   case 1:
      pObject = new PostgreSQLAggregatorMIS();
      break;
   case 2:
      pObject = new ODBCAggregatorPOSRisk();
      break;
   case 3:
      pObject = new PostgreSQLCheckpointTotalsVisitor();
      break;
   case 4:
      pObject = new ODBCLocator();
      break;
   case 5:
      pObject = new PostgreSQLMaintenanceProcedure();
      break;
   case 6:
      pObject = new ODBCPartitionAllocator();
      break;
   case 7:
      pObject = new ODBCPartitionDeallocator();
      break;
   case 8:
      pObject = new ODBCTransactionRemover();
      break;
   case 9:
      pObject = new PostgreSQLMonthlyTotals();
      break;
   case 10:
      pObject = new PostgreSQLMonthlyCardHolder();
      break;
   case 11:
      pObject = new PostgreSQLMISMonthlyCardHolder();
      break;
   }
   return pObject;
  //## end dnpostgresqldatabase::DNPostgreSQLDatabaseFactory::create%611E6F2B016A.body
}

// Additional Declarations
  //## begin dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.declarations preserve=yes
  //## end dnpostgresqldatabase::DNPostgreSQLDatabaseFactory%611293B7008D.declarations

} // namespace dnpostgresqldatabase

//## begin module%6112942A01E6.epilog preserve=yes
//## end module%6112942A01E6.epilog
