//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4EBC423A002E.cm preserve=no
//	$Date:   Nov 15 2011 14:12:14  $ $Author:   D93482  $
//	$Revision:   1.0  $
//## end module%4EBC423A002E.cm

//## begin module%4EBC423A002E.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%4EBC423A002E.cp

//## Module: CXOSCE04%4EBC423A002E; Package specification
//## Subsystem: CEDLL%4E2ED9F5004D
//## Source file: C:\Devel\Dn\Server\Library\CEDLL\CXODCE04.hpp

#ifndef CXOSCE04_h
#define CXOSCE04_h 1

//## begin module%4EBC423A002E.additionalIncludes preserve=no
//## end module%4EBC423A002E.additionalIncludes

//## begin module%4EBC423A002E.includes preserve=yes
//## end module%4EBC423A002E.includes

#ifndef CXOSGE17_h
#include "CXODGE17.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseSegment;
class CaseTransitionSegment;

} // namespace emssegment

//## begin module%4EBC423A002E.declarations preserve=no
//## end module%4EBC423A002E.declarations

//## begin module%4EBC423A002E.additionalDeclarations preserve=yes
//## end module%4EBC423A002E.additionalDeclarations


//## Modelname: Platform\:\:CUP::CUP%4E2ED9570266
namespace cupexception {
//## begin cupexception%4E2ED9570266.initialDeclarations preserve=yes
//## end cupexception%4E2ED9570266.initialDeclarations

//## begin cupexception::CupRepresentmentFinancial%4EBC41170022.preface preserve=yes
//## end cupexception::CupRepresentmentFinancial%4EBC41170022.preface

//## Class: CupRepresentmentFinancial%4EBC41170022
//## Category: Platform\:\:CUP::CUP%4E2ED9570266
//## Subsystem: CEDLL%4E2ED9F5004D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4EBD70D0003C;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%4EBD70DC0039;emssegment::CaseTransitionSegment { -> F}

class DllExport CupRepresentmentFinancial : public genericexception::RepresentmentFinancial  //## Inherits: <unnamed>%4EBC412F0250
{
  //## begin cupexception::CupRepresentmentFinancial%4EBC41170022.initialDeclarations preserve=yes
  //## end cupexception::CupRepresentmentFinancial%4EBC41170022.initialDeclarations

  public:
    //## Constructors (generated)
      CupRepresentmentFinancial();

    //## Destructor (generated)
      virtual ~CupRepresentmentFinancial();


    //## Other Operations (specified)
      //## Operation: import%4EBD38A503C5
      virtual bool import ();

      //## Operation: unmatchedImport%4EBD38A90333
      virtual bool unmatchedImport ();

    // Additional Public Declarations
      //## begin cupexception::CupRepresentmentFinancial%4EBC41170022.public preserve=yes
      //## end cupexception::CupRepresentmentFinancial%4EBC41170022.public

  protected:
    // Additional Protected Declarations
      //## begin cupexception::CupRepresentmentFinancial%4EBC41170022.protected preserve=yes
      //## end cupexception::CupRepresentmentFinancial%4EBC41170022.protected

  private:
    // Additional Private Declarations
      //## begin cupexception::CupRepresentmentFinancial%4EBC41170022.private preserve=yes
      //## end cupexception::CupRepresentmentFinancial%4EBC41170022.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cupexception::CupRepresentmentFinancial%4EBC41170022.implementation preserve=yes
      //## end cupexception::CupRepresentmentFinancial%4EBC41170022.implementation

};

//## begin cupexception::CupRepresentmentFinancial%4EBC41170022.postscript preserve=yes
//## end cupexception::CupRepresentmentFinancial%4EBC41170022.postscript

} // namespace cupexception

//## begin module%4EBC423A002E.epilog preserve=yes
//## end module%4EBC423A002E.epilog


#endif
