//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4E2EDA2C03DD.cm preserve=no
//	$Date:   May 26 2020 09:58:24  $ $Author:   e1009510  $
//	$Revision:   1.8  $
//## end module%4E2EDA2C03DD.cm

//## begin module%4E2EDA2C03DD.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%4E2EDA2C03DD.cp

//## Module: CXOSCE01%4E2EDA2C03DD; Package body
//## Subsystem: CEDLL%4E2ED9F5004D
//## Source file: C:\Devel\Dn\Server\Library\CEDLL\CXOSCE01.cpp

//## begin module%4E2EDA2C03DD.additionalIncludes preserve=no
//## end module%4E2EDA2C03DD.additionalIncludes

//## begin module%4E2EDA2C03DD.includes preserve=yes
#ifndef CXOSES66_h
#include "CXODES66.hpp"
#endif
//## end module%4E2EDA2C03DD.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSGE02_h
#include "CXODGE02.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSBS24_h
#include "CXODBS24.hpp"
#endif
#ifndef CXOSES67_h
#include "CXODES67.hpp"
#endif
#ifndef CXOSCE01_h
#include "CXODCE01.hpp"
#endif


//## begin module%4E2EDA2C03DD.declarations preserve=no
//## end module%4E2EDA2C03DD.declarations

//## begin module%4E2EDA2C03DD.additionalDeclarations preserve=yes
struct segCDRS
{
   char acquiring_institution_id[11];  //Seq no. 01, Field no. 32
   char space01;
   char forwarding_institution_id[11]; //Seq no. 02, Field no. 33
   char space02;        
   char system_trace_number[6];        //Seq no. 03, Field no. 11   
   char space03;        
   char transmission_date_time[10];    //Seq no. 04, Field no. 07
   char space04;        
   char pan[19];                       //Seq no. 05, Field no. 02
   char space05;        
   char transaction_amount[12];        //Seq no. 06, Field no. 04 
   char space06;        
   char message_type[4];               //Seq no. 07, Field no.  
   char space07;        
   char processing_code[6];            //Seq no. 08, Field no. 03
   char space08;        
   char merchant_type[4];              //Seq no. 09, Field no. 18
   char space09;        
   char card_accpt_term_id[8];         //Seq no. 10, Field no. 41
   char space10;        
   char card_accpt_ident_code[15];      //Seq no. 11, Field no. 42
   char space11;        
   char card_acpt_name_loc[40];        //Seq no. 12, Field no. 43
   char space12;        
   char retrieval_ref_no[12];          //Seq no. 13, Field no. 37
   char space13;        
   char pos_cond_code[2];              //Seq no. 14, Field no. 25
   char space14;        
   char auth_ident_response[6];        //Seq no. 15, Field no. 38
   char space15;        
   char receiving_inst_id[11];         //Seq no. 16, Field no. 100
   char space16;        
   char orig_sys_trace_no[6];          //Seq no. 17, Field no. 90.2
   char space17;        
   char response_code[2];              //Seq no. 18, Field no. 39
   char space18;        
   char tran_cur_code[3];              //Seq no. 19, Field no. 49
   char space19;        
   char pos_entry_mode[3];             //Seq no. 20, Field no. 22
   char space20;        
   char settle_cur_code[3];            //Seq no. 21, Field no. 50
   char space21;        
   char settle_amount[12];             //Seq no. 22, Field no. 05
   char space22;        
   char settle_conversion[8];          //Seq no. 23, Field no. 09
   char space23;        
   char settle_date[4];                //Seq no. 24, Field no. 15
   char space24;        
   char conversion_date[4];            //Seq no. 25, Field no. 16
   char space25;        
   char commission_receivable[12];     //Seq no. 26, Field no. 
   char space26;        
   char commission_payable[12];        //Seq no. 27, Field no. 
   char space27;        
   char interchg_service_fee[12];      //Seq no. 28, Field no.     (X+n11)
   char space28;        
   char cardholder_tran_fee[12];       //Seq no. 29, Field no. 28
   char space29;        
   char orig_tran_date_time[10];       //Seq no. 30, Field no. 90.3
   char space30;        
   char orig_tran_proc_code[6];        //Seq no. 31, Field no. 03
   char space31;        
   //Reserved for use: AAABC..................DEEEESS
   //(2) AAA stands for card sequence number of Field 23;
   //(3) B stands for terminal read capability of Field 60.2.2;
   //(4) C stands for IC card's condition code of Field 60.2.3;
   //(6) D is the identifier of dispute resolution initiator, indicating who initiates the dispute resolution transaction. The definitions are as follows:
   //     Space-Not defined;
   //     Initiated by UnionPay
   //     Initiated by the Participant
   //(7) EEEE stands for dispute resolution reason code;
   //(8) SS stands for installment payment terms. 
   // For example, 06 means six terms, 
   //              12 means twelve terms and 
   //              a space means it is a none-installment payment transaction.
   char card_seq_no[3];                      //AAA field 23;
   char term_read_cap;                       //B field 60.2.2;
   char IC_card_cond_code[1];                //C field 60.2.3;
   char reserved[18];
   char dispute_resolution_initiator_id;     //D 
   char dispute_resolution_reason_code[4];   //EEEE 
   char installment_payment_terms[2];        //SS
};
//## end module%4E2EDA2C03DD.additionalDeclarations


//## Modelname: Platform\:\:CUP::CUP%4E2ED9570266
namespace cupexception {
//## begin cupexception%4E2ED9570266.initialDeclarations preserve=yes
//## end cupexception%4E2ED9570266.initialDeclarations

// Class cupexception::CupTransaction 

CupTransaction::CupTransaction()
  //## begin CupTransaction::CupTransaction%4E2ED97102AA_const.hasinit preserve=no
  //## end CupTransaction::CupTransaction%4E2ED97102AA_const.hasinit
  //## begin CupTransaction::CupTransaction%4E2ED97102AA_const.initialization preserve=yes
  //## end CupTransaction::CupTransaction%4E2ED97102AA_const.initialization
{
  //## begin cupexception::CupTransaction::CupTransaction%4E2ED97102AA_const.body preserve=yes
   memcpy(m_sID,"CE01",4);
  //## end cupexception::CupTransaction::CupTransaction%4E2ED97102AA_const.body
}


CupTransaction::~CupTransaction()
{
  //## begin cupexception::CupTransaction::~CupTransaction%4E2ED97102AA_dest.body preserve=yes
  //## end cupexception::CupTransaction::~CupTransaction%4E2ED97102AA_dest.body
}



//## Other Operations (implementation)
void CupTransaction::addSegments (Audit& hAudit)
{
  //## begin cupexception::CupTransaction::addSegments%4E4C2E7C00A2.body preserve=yes
  //## end cupexception::CupTransaction::addSegments%4E4C2E7C00A2.body
}

string CupTransaction::determineDisputeType (int iMsgType, int iProcessCode, int iPOSCC)
{
  //## begin cupexception::CupTransaction::determineDisputeType%4EBD722C0123.body preserve=yes
   //Note: iPprocessCode is defined in method in case it is needed in the future.
   switch (iPOSCC) 
   {
      case 0:  
      case 83: 
         switch (iProcessCode) 
         {
            case 22:  
               if(iMsgType == 422) //credit adjustment to acq (ADJ)
                  genericexception::CaseManifest::instance()->add("CardholderAction","D");               
               else //iMsgType == 220 - credit adjustment to issuer (ADJC)
                  genericexception::CaseManifest::instance()->add("CardholderAction","C");               
               break;
            case 2:   
               if(iMsgType == 422) //debit adjustment to acq (ADJC)
                  genericexception::CaseManifest::instance()->add("CardholderAction","C");               
               else //iMsgType == 220 //debit adjustment to issuer (ADJ)
                  genericexception::CaseManifest::instance()->add("CardholderAction","D");               
               break;
         }
         return "Adjustment";
      case 13: 
         return "RepresentmentFinancial";
      case 17: 
         return "ChargebackFinancial";
      case 41: 
         return "SecondChargeback";
      default:
         return "UnknownDisputeType";
   }
  //## end cupexception::CupTransaction::determineDisputeType%4EBD722C0123.body
}

bool CupTransaction::endAudit (int lTSTAMP_RETRY_COUNT)
{
  //## begin cupexception::CupTransaction::endAudit%4E70B4DF00D5.body preserve=yes
   if(ImportTransaction::endAudit(lTSTAMP_RETRY_COUNT))                   
   {                                                                      
      genericexception::CaseManifest::instance()->endAudit();             
      return true;                                                        
   }                                                                      
   return false;                                                          
  //## end cupexception::CupTransaction::endAudit%4E70B4DF00D5.body
}

bool CupTransaction::parse (const vector<string>& hDATA_BUFFER)
{
  //## begin cupexception::CupTransaction::parse%4E4C2E36021D.body preserve=yes
   UseCase hUseCase("DR","## DR93 IMPORT CUPIN",true,true);
   genericexception::CaseManifest::instance()->reset();
   if( genericexception::CaseManifest::instance()->getAudit() == 0 )
   {	
      CaseManifestSegment::instance()->reset();
      CaseManifestSegment::instance()->setTitle("CUP Import");
      CaseManifestSegment::instance()->setPath(ImportReportAuditSegment::instance()->getPATH());
      CaseManifestSegment::instance()->setFile("CUPIN");
      int lGMTOffset = 6; // !!!
      char szTIMESTAMP[26] = {""};
      snprintf(szTIMESTAMP,sizeof(szTIMESTAMP),"%d-%02d-%02dT%02d:%02d:%02d-%02d:00",
         Clock::instance()->getYear(),Clock::instance()->getMonth(),Clock::instance()->getDay(),
         Clock::instance()->getHour(),Clock::instance()->getMinute(),Clock::instance()->getSecond(),
         lGMTOffset);
      emssegment::BatchDescriptorSegment::instance()->setTIMESTAMP(szTIMESTAMP);
 
      genericexception::CaseManifest::instance()->beginImportAudit("CUPIN");
   }
   string strClass;
   vector<string>::const_iterator pItr;
   pItr = hDATA_BUFFER.begin();
   bool bSuccess = true;
   char szDATA_BUFFER[sizeof(struct segCDRS)];
   memset(szDATA_BUFFER,' ',sizeof(struct segCDRS));
   memcpy(szDATA_BUFFER,(*pItr).data(),
        (*pItr).length() < sizeof(struct segCDRS) ? (*pItr).length():sizeof(struct segCDRS) );
   struct segCDRS* p = (struct segCDRS*)szDATA_BUFFER;
   genericexception::CaseManifest::instance()->add("CaseManifest memberRole","A");               
   genericexception::CaseManifest::instance()->add("SystemTraceAuditNumber",string(p->orig_sys_trace_no,6));        
   genericexception::CaseManifest::instance()->add("AccountNumber",string(p->pan,19));                       
   
   //Cannot rely on amount field to always contain amount of original transaction so set to 0
   genericexception::CaseManifest::instance()->add("Amount",string("0",1));
   genericexception::CaseManifest::instance()->add("RetrievalReferenceNumber",string(p->retrieval_ref_no,12));          

   //construct original transaction date and time (local TSTAMP_TRANS)
   string strMMDDHH(p->orig_tran_date_time,6);
   int iYear = Clock::instance()->getYear();
   int iCurMonth = Clock::instance()->getMonth();
   int iTxnMonth = atoi(strMMDDHH.substr(0,2).c_str());
   if(iTxnMonth > iCurMonth)
      iYear -= 1;
   char szDateTime[11] = {"          "};
   string strTSTAMP_LOCAL(szDateTime,snprintf(szDateTime,sizeof(szDateTime),"%04d%s",iYear,
      strMMDDHH.c_str())); //limit to 10 bytes
   genericexception::CaseManifest::instance()->add("TranDate",strTSTAMP_LOCAL);       
   genericexception::CaseManifest::instance()->add("TransactionDate",strTSTAMP_LOCAL);       

   genericexception::CaseManifest::instance()->add("MCC",string(p->merchant_type,4));       
   genericexception::CaseManifest::instance()->add("CardAcptTermID",string(p->card_accpt_term_id,8));       
   genericexception::CaseManifest::instance()->add("AdjustmentReasonCode",string(p->dispute_resolution_reason_code,4));       
   genericexception::CaseManifest::instance()->add("DisputeAmt",string(p->transaction_amount,12));       
   genericexception::CaseManifest::instance()->add("DisputeAmt currency",string(p->tran_cur_code,3));       
   genericexception::CaseManifest::instance()->add("AdjustmentAmount",string(p->settle_amount,12));       
   genericexception::CaseManifest::instance()->add("AdjustmentAmountcurrency",string(p->settle_cur_code,3));       

   int iMsgType = atoi(string(p->message_type,4).c_str());
   int iProcessCode = atoi(string(p->processing_code,2).c_str());
   int iPOSCC = atoi(string(p->pos_cond_code,2).c_str());
   strClass = determineDisputeType(iMsgType,iProcessCode,iPOSCC);
   genericexception::CaseManifest::instance()->setClass(strClass);
   genericexception::CaseManifest::instance()->add("NetworkID",string("005",3)); //005 = CUP
   if(!genericexception::CaseManifest::instance()->import())
      return UseCase::setSuccess(false);
   UseCase::addItem();
   return true;
  //## end cupexception::CupTransaction::parse%4E4C2E36021D.body
}

string CupTransaction::processReasonCode (int iReasonCode)
{
  //## begin cupexception::CupTransaction::processReasonCode%4E4C25F4004A.body preserve=yes
   switch (iReasonCode) 
   {
      //1st Chargebacks (Debit Cards)
      case 4501: //CHB1	Non or ParialDisbursement of Cash
      case 4502: //CHB1	Purchase Not Completed
      case 4503: //CHB1	Dispute on Debit Adjustment
      case 4507: //CHB1	Transaction Amoount Differs
      case 4508: //CHB1	Exceeds Limited or Authorised Amount
      case 4512: //CHB1	Duplicate Processing
      case 4514: //CHB1	Fraudulent Multiple Transactions
      case 4515: //CHB1	Transaction Not Recognised
      case 4522: //CHB1	Declined Authorisation
      case 4526: //CHB1	Illegible Fullfilment
      case 4527: //CHB1	Fulfillment Not Received or Code 04
      case 4528: //CHB1	Cancelled pre-Authorisation
      case 4531: //CHB1	Questionable Trasnaction Receipt
      case 4532: //CHB1	Refund Not Processed
      case 4544: //CHB1	Cancelled Transaction
      case 4562: //CHB1	Counterfeit Card
      case 4752: //CHB1	Fees Refund for Unsuccessful Balance Inquiry
      case 4802: //CHB1	High Risk Merchant
      case 4803: //CHB1	Prohibited Mechant
      case 4806: //CHB1	Paid by Other Means
      case 4810: //CHB1	Trasnaction Not Recognised - non face to face
         return "ChargebackFinancial";
         break;
      //2nd Chargebacks (Credit Cards Only)
      //case 4526: //CHB2	Supporting Documents Not Received, Incomplete and Illegible
      case 4570: //CHB2	Invalid Representment
      case 4571: //CHB2	New Documentation Provided
      case 4572: //CHB2	Chargeback Reason Adjusted
         return "SecondChargebackFinancial";
         break;
      //Representments (Credit Cards Only)
      case 2000: //REP1	Refund or Credit Adjustment Processed
      case 2001: //REP1	Incorrect Trace No in Chargeback
      case 2002: //REP1	Non Receipt of Supporting Documents
      case 2003: //REP1	Correct Transaction Date Provided
      case 2005: //REP1	Correct Merchant Location Provided
      case 2008: //REP1	Transaction Authorized by Issuer
      case 2702: //REP1	Invalid First Chargeback
      case 2704: //REP1	Legible Transaction Receipt Provided
      case 2706: //REP1	Acquirer Can Prove that Transaction is correct
      case 2707: //REP1	Illegible Supporting Documentation for Chargeback
         return "RepresentmentFinancial";
         break;
      //ADJC Credit Adjustment
      case 9600: //ADJC	Transaction Cancelled by Cardholder
      case 9601: //ADJC	Surplus Identified by Acquirer
      case 9602: //ADJC	Non Disbursement of Cash at ATM
      case 9603: //ADJC	Partial Disbursement of Cash at ATM
         return "Adjustment";
         break;
      //ADJ Debit Adjustment 
      case 9650: //ADJ Transaction Amount Differs - Purchase
      case 9651: //ADJ Transaction Amount Differs - ATM
      case 9652: //ADJ Incorrect Credit Adjustment
      case 9653: //ADJ Time Frame for Pre-Auth completion exceeded
      case 9654: //ADJ Abnormal Reversal Transaction
      case 9655: //ADJ Abnormal Cancellation
      case 9656: //ADJ Transaction Amount Differs - Purchase due to system malfunction
      case 9657: //ADJ Incorrect Credit Adjustment, Manual Refund or credit Voucher
         return "Adjustment";
         break;
		//ADJR Special Adjustment
		case 9700: //ADJR	Incorrect Credit Adjustment
      case 9701: //ADJR	Questionable First Chargeback on Debit Card
      case 9702: //ADJR	Deficit of Transaction Amt at Acquirer
      case 9703: //ADJR	Time Frame Exceeded
      case 9704: //ADJR	General Dispute Cycle Ended
      case 9705: //ADJR	Transaction Record Not Found in CUP System
      case 9706: //ADJR	OtherMutually Agreed Payment
         return "AdjustmentReject";
         break;
      default :
         return "*****************";
   } 

  //## end cupexception::CupTransaction::processReasonCode%4E4C25F4004A.body
}

void CupTransaction::update (Subject* pSubject)
{
  //## begin cupexception::CupTransaction::update%4E4C2E42019B.body preserve=yes
   ImportTransaction::update(pSubject);
  //## end cupexception::CupTransaction::update%4E4C2E42019B.body
}

// Additional Declarations
  //## begin cupexception::CupTransaction%4E2ED97102AA.declarations preserve=yes
  //## end cupexception::CupTransaction%4E2ED97102AA.declarations

} // namespace cupexception

//## begin module%4E2EDA2C03DD.epilog preserve=yes
//## end module%4E2EDA2C03DD.epilog
