//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4EBC3B120300.cm preserve=no
//	$Date:   Jan 18 2012 13:57:44  $ $Author:   E1009652  $
//	$Revision:   1.3  $
//## end module%4EBC3B120300.cm

//## begin module%4EBC3B120300.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%4EBC3B120300.cp

//## Module: CXOSCE02%4EBC3B120300; Package body
//## Subsystem: CEDLL%4E2ED9F5004D
//## Source file: C:\Devel\Dn\Server\Library\CEDLL\CXOSCE02.cpp

//## begin module%4EBC3B120300.additionalIncludes preserve=no
//## end module%4EBC3B120300.additionalIncludes

//## begin module%4EBC3B120300.includes preserve=yes
//## end module%4EBC3B120300.includes

#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSCE02_h
#include "CXODCE02.hpp"
#endif


//## begin module%4EBC3B120300.declarations preserve=no
//## end module%4EBC3B120300.declarations

//## begin module%4EBC3B120300.additionalDeclarations preserve=yes
#include "CXODGE02.hpp"
//## end module%4EBC3B120300.additionalDeclarations


//## Modelname: Platform\:\:CUP::CUP%4E2ED9570266
namespace cupexception {
//## begin cupexception%4E2ED9570266.initialDeclarations preserve=yes
//## end cupexception%4E2ED9570266.initialDeclarations

// Class cupexception::CupChargebackFinancial 

CupChargebackFinancial::CupChargebackFinancial()
  //## begin CupChargebackFinancial::CupChargebackFinancial%4EBC3BA602B0_const.hasinit preserve=no
  //## end CupChargebackFinancial::CupChargebackFinancial%4EBC3BA602B0_const.hasinit
  //## begin CupChargebackFinancial::CupChargebackFinancial%4EBC3BA602B0_const.initialization preserve=yes
  //## end CupChargebackFinancial::CupChargebackFinancial%4EBC3BA602B0_const.initialization
{
  //## begin cupexception::CupChargebackFinancial::CupChargebackFinancial%4EBC3BA602B0_const.body preserve=yes
  //## end cupexception::CupChargebackFinancial::CupChargebackFinancial%4EBC3BA602B0_const.body
}


CupChargebackFinancial::~CupChargebackFinancial()
{
  //## begin cupexception::CupChargebackFinancial::~CupChargebackFinancial%4EBC3BA602B0_dest.body preserve=yes
  //## end cupexception::CupChargebackFinancial::~CupChargebackFinancial%4EBC3BA602B0_dest.body
}



//## Other Operations (implementation)
bool CupChargebackFinancial::import ()
{
  //## begin cupexception::CupChargebackFinancial::import%4EBD3892003C.body preserve=yes
   CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT("CHB1");
   CaseTransitionSegment::instance()->setSTATUS_NEXT("SDRC");
   if(CaseTransitionSegment::instance()->getSTATUS_PREV().empty() &&
      CaseTransitionSegment::instance()->getREQUEST_TYPE_PREV().empty())  
      genericexception::CaseManifest::instance()->add("CardholderAction","C");               
   return transition();
  //## end cupexception::CupChargebackFinancial::import%4EBD3892003C.body
}

bool CupChargebackFinancial::unmatchedImport ()
{
  //## begin cupexception::CupChargebackFinancial::unmatchedImport%4EBD389503A1.body preserve=yes
   CaseSegment::instance()->setREQUEST_TYPE("INIT");
   CaseSegment::instance()->setSTATUS("TEMP");
   CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT("CHB1");
   CaseTransitionSegment::instance()->setREQUEST_TYPE_PREV("INIT");
   CaseTransitionSegment::instance()->setSTATUS_NEXT("CLUN");
   CaseTransitionSegment::instance()->setSTATUS_PREV("TEMP");
   return transition();
   //return genericexception::ChargebackFinancial::unmatchedImport();
  //## end cupexception::CupChargebackFinancial::unmatchedImport%4EBD389503A1.body
}

// Additional Declarations
  //## begin cupexception::CupChargebackFinancial%4EBC3BA602B0.declarations preserve=yes
  //## end cupexception::CupChargebackFinancial%4EBC3BA602B0.declarations

} // namespace cupexception

//## begin module%4EBC3B120300.epilog preserve=yes
//## end module%4EBC3B120300.epilog
