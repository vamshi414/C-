//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4EBC423B01B3.cm preserve=no
//	$Date:   Jan 18 2012 13:57:48  $ $Author:   E1009652  $
//	$Revision:   1.3  $
//## end module%4EBC423B01B3.cm

//## begin module%4EBC423B01B3.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%4EBC423B01B3.cp

//## Module: CXOSCE04%4EBC423B01B3; Package body
//## Subsystem: CEDLL%4E2ED9F5004D
//## Source file: C:\Devel\Dn\Server\Library\CEDLL\CXOSCE04.cpp

//## begin module%4EBC423B01B3.additionalIncludes preserve=no
//## end module%4EBC423B01B3.additionalIncludes

//## begin module%4EBC423B01B3.includes preserve=yes
//## end module%4EBC423B01B3.includes

#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSCE04_h
#include "CXODCE04.hpp"
#endif


//## begin module%4EBC423B01B3.declarations preserve=no
//## end module%4EBC423B01B3.declarations

//## begin module%4EBC423B01B3.additionalDeclarations preserve=yes
#include "CXODGE02.hpp"
//## end module%4EBC423B01B3.additionalDeclarations


//## Modelname: Platform\:\:CUP::CUP%4E2ED9570266
namespace cupexception {
//## begin cupexception%4E2ED9570266.initialDeclarations preserve=yes
//## end cupexception%4E2ED9570266.initialDeclarations

// Class cupexception::CupRepresentmentFinancial 

CupRepresentmentFinancial::CupRepresentmentFinancial()
  //## begin CupRepresentmentFinancial::CupRepresentmentFinancial%4EBC41170022_const.hasinit preserve=no
  //## end CupRepresentmentFinancial::CupRepresentmentFinancial%4EBC41170022_const.hasinit
  //## begin CupRepresentmentFinancial::CupRepresentmentFinancial%4EBC41170022_const.initialization preserve=yes
  //## end CupRepresentmentFinancial::CupRepresentmentFinancial%4EBC41170022_const.initialization
{
  //## begin cupexception::CupRepresentmentFinancial::CupRepresentmentFinancial%4EBC41170022_const.body preserve=yes
  //## end cupexception::CupRepresentmentFinancial::CupRepresentmentFinancial%4EBC41170022_const.body
}


CupRepresentmentFinancial::~CupRepresentmentFinancial()
{
  //## begin cupexception::CupRepresentmentFinancial::~CupRepresentmentFinancial%4EBC41170022_dest.body preserve=yes
  //## end cupexception::CupRepresentmentFinancial::~CupRepresentmentFinancial%4EBC41170022_dest.body
}



//## Other Operations (implementation)
bool CupRepresentmentFinancial::import ()
{
  //## begin cupexception::CupRepresentmentFinancial::import%4EBD38A503C5.body preserve=yes
   CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT("REP1");
   CaseTransitionSegment::instance()->setSTATUS_NEXT("SDRC");
   if(CaseTransitionSegment::instance()->getSTATUS_PREV().empty() &&
      CaseTransitionSegment::instance()->getREQUEST_TYPE_PREV().empty())  
      genericexception::CaseManifest::instance()->add("CardholderAction","D");               
   return transition();
  //## end cupexception::CupRepresentmentFinancial::import%4EBD38A503C5.body
}

bool CupRepresentmentFinancial::unmatchedImport ()
{
  //## begin cupexception::CupRepresentmentFinancial::unmatchedImport%4EBD38A90333.body preserve=yes
   CaseSegment::instance()->setREQUEST_TYPE("INIT");
   CaseSegment::instance()->setSTATUS("TEMP");
   CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT("REP1");
   CaseTransitionSegment::instance()->setREQUEST_TYPE_PREV("INIT");
   CaseTransitionSegment::instance()->setSTATUS_NEXT("CLUN");
   CaseTransitionSegment::instance()->setSTATUS_PREV("TEMP");
   genericexception::CaseManifest::instance()->add("CardholderAction","D");               
   return transition();
   //return genericexception::RepresentmentFinancial::unmatchedImport();
  //## end cupexception::CupRepresentmentFinancial::unmatchedImport%4EBD38A90333.body
}

// Additional Declarations
  //## begin cupexception::CupRepresentmentFinancial%4EBC41170022.declarations preserve=yes
  //## end cupexception::CupRepresentmentFinancial%4EBC41170022.declarations

} // namespace cupexception

//## begin module%4EBC423B01B3.epilog preserve=yes
//## end module%4EBC423B01B3.epilog
