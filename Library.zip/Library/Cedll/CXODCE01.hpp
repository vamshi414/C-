//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4E2EDA2B00E2.cm preserve=no
//	$Date:   Nov 23 2011 11:38:56  $ $Author:   E1009652  $
//	$Revision:   1.3  $
//## end module%4E2EDA2B00E2.cm

//## begin module%4E2EDA2B00E2.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%4E2EDA2B00E2.cp

//## Module: CXOSCE01%4E2EDA2B00E2; Package specification
//## Subsystem: CEDLL%4E2ED9F5004D
//## Source file: C:\Devel\Dn\Server\Library\CEDLL\CXODCE01.hpp

#ifndef CXOSCE01_h
#define CXOSCE01_h 1

//## begin module%4E2EDA2B00E2.additionalIncludes preserve=no
//## end module%4E2EDA2B00E2.additionalIncludes

//## begin module%4E2EDA2B00E2.includes preserve=yes
//## end module%4E2EDA2B00E2.includes

#ifndef CXOSBC19_h
#include "CXODBC19.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseManifestSegment;
} // namespace emssegment

//## Modelname: Transaction Research and Adjustments::GenericException_CAT%4ADF1B4C003E
namespace genericexception {
class CaseManifest;
} // namespace genericexception

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ImportReportAuditSegment;

} // namespace segment

//## begin module%4E2EDA2B00E2.declarations preserve=no
//## end module%4E2EDA2B00E2.declarations

//## begin module%4E2EDA2B00E2.additionalDeclarations preserve=yes
//## end module%4E2EDA2B00E2.additionalDeclarations


//## Modelname: Platform\:\:CUP::CUP%4E2ED9570266
namespace cupexception {
//## begin cupexception%4E2ED9570266.initialDeclarations preserve=yes
//## end cupexception%4E2ED9570266.initialDeclarations

//## begin cupexception::CupTransaction%4E2ED97102AA.preface preserve=yes
//## end cupexception::CupTransaction%4E2ED97102AA.preface

//## Class: CupTransaction%4E2ED97102AA
//## Category: Platform\:\:CUP::CUP%4E2ED9570266
//## Subsystem: CEDLL%4E2ED9F5004D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4E4C3D7601CF;monitor::UseCase { -> F}
//## Uses: <unnamed>%4E4C3DC302CC;genericexception::CaseManifest { -> F}
//## Uses: <unnamed>%4E70E72D0306;timer::Clock { -> F}
//## Uses: <unnamed>%4E70E7A70071;segment::ImportReportAuditSegment { -> F}
//## Uses: <unnamed>%4E70E821024F;emssegment::CaseManifestSegment { -> F}

class DllExport CupTransaction : public command::ImportTransaction  //## Inherits: <unnamed>%4E2F0D8E0016
{
  //## begin cupexception::CupTransaction%4E2ED97102AA.initialDeclarations preserve=yes
  //## end cupexception::CupTransaction%4E2ED97102AA.initialDeclarations

  public:
    //## Constructors (generated)
      CupTransaction();

    //## Destructor (generated)
      virtual ~CupTransaction();


    //## Other Operations (specified)
      //## Operation: addSegments%4E4C2E7C00A2
      virtual void addSegments (Audit& hAudit);

      //## Operation: parse%4E4C2E36021D
      virtual bool parse (const vector<string>& hDATA_BUFFER);

      //## Operation: update%4E4C2E42019B
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin cupexception::CupTransaction%4E2ED97102AA.public preserve=yes
      //## end cupexception::CupTransaction%4E2ED97102AA.public

  protected:

    //## Other Operations (specified)
      //## Operation: endAudit%4E70B4DF00D5
      virtual bool endAudit (int lTSTAMP_RETRY_COUNT);

    // Additional Protected Declarations
      //## begin cupexception::CupTransaction%4E2ED97102AA.protected preserve=yes
      //## end cupexception::CupTransaction%4E2ED97102AA.protected

  private:

    //## Other Operations (specified)
      //## Operation: determineDisputeType%4EBD722C0123
      string determineDisputeType (int iMsgType, int iProcessCode, int iPOSCC);

      //## Operation: processReasonCode%4E4C25F4004A
      string processReasonCode (int iReasonCode);

    // Additional Private Declarations
      //## begin cupexception::CupTransaction%4E2ED97102AA.private preserve=yes
      //## end cupexception::CupTransaction%4E2ED97102AA.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cupexception::CupTransaction%4E2ED97102AA.implementation preserve=yes
      //## end cupexception::CupTransaction%4E2ED97102AA.implementation

};

//## begin cupexception::CupTransaction%4E2ED97102AA.postscript preserve=yes
//## end cupexception::CupTransaction%4E2ED97102AA.postscript

} // namespace cupexception

//## begin module%4E2EDA2B00E2.epilog preserve=yes
//## end module%4E2EDA2B00E2.epilog


#endif
