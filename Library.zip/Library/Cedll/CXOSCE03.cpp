//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4EBC41C3003B.cm preserve=no
//	$Date:   Nov 23 2011 11:39:04  $ $Author:   E1009652  $
//	$Revision:   1.1  $
//## end module%4EBC41C3003B.cm

//## begin module%4EBC41C3003B.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%4EBC41C3003B.cp

//## Module: CXOSCE03%4EBC41C3003B; Package body
//## Subsystem: CEDLL%4E2ED9F5004D
//## Source file: C:\Devel\Dn\Server\Library\CEDLL\CXOSCE03.cpp

//## begin module%4EBC41C3003B.additionalIncludes preserve=no
//## end module%4EBC41C3003B.additionalIncludes

//## begin module%4EBC41C3003B.includes preserve=yes
//## end module%4EBC41C3003B.includes

#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSGE02_h
#include "CXODGE02.hpp"
#endif
#ifndef CXOSCE03_h
#include "CXODCE03.hpp"
#endif


//## begin module%4EBC41C3003B.declarations preserve=no
//## end module%4EBC41C3003B.declarations

//## begin module%4EBC41C3003B.additionalDeclarations preserve=yes
//## end module%4EBC41C3003B.additionalDeclarations


//## Modelname: Platform\:\:CUP::CUP%4E2ED9570266
namespace cupexception {
//## begin cupexception%4E2ED9570266.initialDeclarations preserve=yes
//## end cupexception%4E2ED9570266.initialDeclarations

// Class cupexception::CupAdjustment 

CupAdjustment::CupAdjustment()
  //## begin CupAdjustment::CupAdjustment%4EBC40CF031B_const.hasinit preserve=no
  //## end CupAdjustment::CupAdjustment%4EBC40CF031B_const.hasinit
  //## begin CupAdjustment::CupAdjustment%4EBC40CF031B_const.initialization preserve=yes
  //## end CupAdjustment::CupAdjustment%4EBC40CF031B_const.initialization
{
  //## begin cupexception::CupAdjustment::CupAdjustment%4EBC40CF031B_const.body preserve=yes
  //## end cupexception::CupAdjustment::CupAdjustment%4EBC40CF031B_const.body
}


CupAdjustment::~CupAdjustment()
{
  //## begin cupexception::CupAdjustment::~CupAdjustment%4EBC40CF031B_dest.body preserve=yes
  //## end cupexception::CupAdjustment::~CupAdjustment%4EBC40CF031B_dest.body
}



//## Other Operations (implementation)
bool CupAdjustment::import ()
{
  //## begin cupexception::CupAdjustment::import%4EBD3809007A.body preserve=yes
   if(CasePhaseSegment::instance()->getACTION_TO_CARDHLDR() == "C")
      CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT("ADJC");
   else
      CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT("ADJ");
   CaseTransitionSegment::instance()->setSTATUS_NEXT("SDRC");
   return transition();
  //## end cupexception::CupAdjustment::import%4EBD3809007A.body
}

bool CupAdjustment::unmatchedImport ()
{
  //## begin cupexception::CupAdjustment::unmatchedImport%4EBD380E010E.body preserve=yes
   CaseSegment::instance()->setREQUEST_TYPE("INIT");
   CaseSegment::instance()->setSTATUS("TEMP");
   if(CasePhaseSegment::instance()->getACTION_TO_CARDHLDR() == "C")
      CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT("ADJC");
   else
      CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT("ADJ");
   CaseTransitionSegment::instance()->setREQUEST_TYPE_PREV("INIT");
   CaseTransitionSegment::instance()->setSTATUS_NEXT("CLUN");
   CaseTransitionSegment::instance()->setSTATUS_PREV("TEMP");
   return transition();
   //return genericexception::Adjustment::unmatchedImport();
  //## end cupexception::CupAdjustment::unmatchedImport%4EBD380E010E.body
}

// Additional Declarations
  //## begin cupexception::CupAdjustment%4EBC40CF031B.declarations preserve=yes
  //## end cupexception::CupAdjustment%4EBC40CF031B.declarations

} // namespace cupexception

//## begin module%4EBC41C3003B.epilog preserve=yes
//## end module%4EBC41C3003B.epilog
