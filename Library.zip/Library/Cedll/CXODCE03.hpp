//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4EBC41C003C9.cm preserve=no
//	$Date:   Nov 15 2011 14:12:10  $ $Author:   D93482  $
//	$Revision:   1.0  $
//## end module%4EBC41C003C9.cm

//## begin module%4EBC41C003C9.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%4EBC41C003C9.cp

//## Module: CXOSCE03%4EBC41C003C9; Package specification
//## Subsystem: CEDLL%4E2ED9F5004D
//## Source file: C:\Devel\Dn\Server\Library\CEDLL\CXODCE03.hpp

#ifndef CXOSCE03_h
#define CXOSCE03_h 1

//## begin module%4EBC41C003C9.additionalIncludes preserve=no
//## end module%4EBC41C003C9.additionalIncludes

//## begin module%4EBC41C003C9.includes preserve=yes
//## end module%4EBC41C003C9.includes

#ifndef CXOSGE21_h
#include "CXODGE21.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseSegment;
class CaseTransitionSegment;
} // namespace emssegment

//## Modelname: Transaction Research and Adjustments::GenericException_CAT%4ADF1B4C003E
namespace genericexception {
class CaseManifest;

} // namespace genericexception

//## begin module%4EBC41C003C9.declarations preserve=no
//## end module%4EBC41C003C9.declarations

//## begin module%4EBC41C003C9.additionalDeclarations preserve=yes
//## end module%4EBC41C003C9.additionalDeclarations


//## Modelname: Platform\:\:CUP::CUP%4E2ED9570266
namespace cupexception {
//## begin cupexception%4E2ED9570266.initialDeclarations preserve=yes
//## end cupexception%4E2ED9570266.initialDeclarations

//## begin cupexception::CupAdjustment%4EBC40CF031B.preface preserve=yes
//## end cupexception::CupAdjustment%4EBC40CF031B.preface

//## Class: CupAdjustment%4EBC40CF031B
//## Category: Platform\:\:CUP::CUP%4E2ED9570266
//## Subsystem: CEDLL%4E2ED9F5004D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4EBD6FDE0088;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%4EBD70190240;emssegment::CaseTransitionSegment { -> F}
//## Uses: <unnamed>%4EC2BD540265;genericexception::CaseManifest { -> F}

class DllExport CupAdjustment : public genericexception::Adjustment  //## Inherits: <unnamed>%4EBD3D9100B2
{
  //## begin cupexception::CupAdjustment%4EBC40CF031B.initialDeclarations preserve=yes
  //## end cupexception::CupAdjustment%4EBC40CF031B.initialDeclarations

  public:
    //## Constructors (generated)
      CupAdjustment();

    //## Destructor (generated)
      virtual ~CupAdjustment();


    //## Other Operations (specified)
      //## Operation: import%4EBD3809007A
      virtual bool import ();

      //## Operation: unmatchedImport%4EBD380E010E
      virtual bool unmatchedImport ();

    // Additional Public Declarations
      //## begin cupexception::CupAdjustment%4EBC40CF031B.public preserve=yes
      //## end cupexception::CupAdjustment%4EBC40CF031B.public

  protected:
    // Additional Protected Declarations
      //## begin cupexception::CupAdjustment%4EBC40CF031B.protected preserve=yes
      //## end cupexception::CupAdjustment%4EBC40CF031B.protected

  private:
    // Additional Private Declarations
      //## begin cupexception::CupAdjustment%4EBC40CF031B.private preserve=yes
      //## end cupexception::CupAdjustment%4EBC40CF031B.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cupexception::CupAdjustment%4EBC40CF031B.implementation preserve=yes
      //## end cupexception::CupAdjustment%4EBC40CF031B.implementation

};

//## begin cupexception::CupAdjustment%4EBC40CF031B.postscript preserve=yes
//## end cupexception::CupAdjustment%4EBC40CF031B.postscript

} // namespace cupexception

//## begin module%4EBC41C003C9.epilog preserve=yes
//## end module%4EBC41C003C9.epilog


#endif
