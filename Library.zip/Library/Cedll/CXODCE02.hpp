//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4EBC40120097.cm preserve=no
//	$Date:   Nov 15 2011 14:12:06  $ $Author:   D93482  $
//	$Revision:   1.0  $
//## end module%4EBC40120097.cm

//## begin module%4EBC40120097.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%4EBC40120097.cp

//## Module: CXOSCE02%4EBC40120097; Package specification
//## Subsystem: CEDLL%4E2ED9F5004D
//## Source file: C:\Devel\Dn\Server\Library\CEDLL\CXODCE02.hpp

#ifndef CXOSCE02_h
#define CXOSCE02_h 1

//## begin module%4EBC40120097.additionalIncludes preserve=no
//## end module%4EBC40120097.additionalIncludes

//## begin module%4EBC40120097.includes preserve=yes
//## end module%4EBC40120097.includes

#ifndef CXOSGE16_h
#include "CXODGE16.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseSegment;
class CaseTransitionSegment;

} // namespace emssegment

//## begin module%4EBC40120097.declarations preserve=no
//## end module%4EBC40120097.declarations

//## begin module%4EBC40120097.additionalDeclarations preserve=yes
//## end module%4EBC40120097.additionalDeclarations


//## Modelname: Platform\:\:CUP::CUP%4E2ED9570266
namespace cupexception {
//## begin cupexception%4E2ED9570266.initialDeclarations preserve=yes
//## end cupexception%4E2ED9570266.initialDeclarations

//## begin cupexception::CupChargebackFinancial%4EBC3BA602B0.preface preserve=yes
//## end cupexception::CupChargebackFinancial%4EBC3BA602B0.preface

//## Class: CupChargebackFinancial%4EBC3BA602B0
//## Category: Platform\:\:CUP::CUP%4E2ED9570266
//## Subsystem: CEDLL%4E2ED9F5004D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4EBD7087004A;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%4EBD70920299;emssegment::CaseTransitionSegment { -> F}

class DllExport CupChargebackFinancial : public genericexception::ChargebackFinancial  //## Inherits: <unnamed>%4EBC3C9D03D8
{
  //## begin cupexception::CupChargebackFinancial%4EBC3BA602B0.initialDeclarations preserve=yes
  //## end cupexception::CupChargebackFinancial%4EBC3BA602B0.initialDeclarations

  public:
    //## Constructors (generated)
      CupChargebackFinancial();

    //## Destructor (generated)
      virtual ~CupChargebackFinancial();


    //## Other Operations (specified)
      //## Operation: import%4EBD3892003C
      virtual bool import ();

      //## Operation: unmatchedImport%4EBD389503A1
      virtual bool unmatchedImport ();

    // Additional Public Declarations
      //## begin cupexception::CupChargebackFinancial%4EBC3BA602B0.public preserve=yes
      //## end cupexception::CupChargebackFinancial%4EBC3BA602B0.public

  protected:
    // Additional Protected Declarations
      //## begin cupexception::CupChargebackFinancial%4EBC3BA602B0.protected preserve=yes
      //## end cupexception::CupChargebackFinancial%4EBC3BA602B0.protected

  private:
    // Additional Private Declarations
      //## begin cupexception::CupChargebackFinancial%4EBC3BA602B0.private preserve=yes
      //## end cupexception::CupChargebackFinancial%4EBC3BA602B0.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cupexception::CupChargebackFinancial%4EBC3BA602B0.implementation preserve=yes
      //## end cupexception::CupChargebackFinancial%4EBC3BA602B0.implementation

};

//## begin cupexception::CupChargebackFinancial%4EBC3BA602B0.postscript preserve=yes
//## end cupexception::CupChargebackFinancial%4EBC3BA602B0.postscript

} // namespace cupexception

//## begin module%4EBC40120097.epilog preserve=yes
//## end module%4EBC40120097.epilog


#endif
