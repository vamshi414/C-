//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4ECA9B750347.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%4ECA9B750347.cm

//## begin module%4ECA9B750347.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4ECA9B750347.cp

//## Module: CXOSCE06%4ECA9B750347; Package body
//## Subsystem: CEDLL%4E2ED9F5004D
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cedll\CXOSCE06.cpp

//## begin module%4ECA9B750347.additionalIncludes preserve=no
//## end module%4ECA9B750347.additionalIncludes

//## begin module%4ECA9B750347.includes preserve=yes
//## end module%4ECA9B750347.includes

#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSGE08_h
#include "CXODGE08.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSES65_h
#include "CXODES65.hpp"
#endif
#ifndef CXOSCE06_h
#include "CXODCE06.hpp"
#endif


//## begin module%4ECA9B750347.declarations preserve=no
//## end module%4ECA9B750347.declarations

//## begin module%4ECA9B750347.additionalDeclarations preserve=yes
//## end module%4ECA9B750347.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::CUPException_CAT%4E2ED9570266
namespace cupexception {
//## begin cupexception%4E2ED9570266.initialDeclarations preserve=yes
//## end cupexception%4E2ED9570266.initialDeclarations

// Class cupexception::CupNetwork 

CupNetwork::CupNetwork()
  //## begin CupNetwork::CupNetwork%4ECA9AB1003B_const.hasinit preserve=no
  //## end CupNetwork::CupNetwork%4ECA9AB1003B_const.hasinit
  //## begin CupNetwork::CupNetwork%4ECA9AB1003B_const.initialization preserve=yes
  //## end CupNetwork::CupNetwork%4ECA9AB1003B_const.initialization
{
  //## begin cupexception::CupNetwork::CupNetwork%4ECA9AB1003B_const.body preserve=yes
  //## end cupexception::CupNetwork::CupNetwork%4ECA9AB1003B_const.body
}


CupNetwork::~CupNetwork()
{
  //## begin cupexception::CupNetwork::~CupNetwork%4ECA9AB1003B_dest.body preserve=yes
  //## end cupexception::CupNetwork::~CupNetwork%4ECA9AB1003B_dest.body
}



//## Other Operations (implementation)
void CupNetwork::bind (reusable::Query& hQuery)
{
  //## begin cupexception::CupNetwork::bind%4ECA9F4E02E0.body preserve=yes
  //## end cupexception::CupNetwork::bind%4ECA9F4E02E0.body
}

bool CupNetwork::createCase ()
{
  //## begin cupexception::CupNetwork::createCase%4ECA9F4E02FF.body preserve=yes
   return true;
  //## end cupexception::CupNetwork::createCase%4ECA9F4E02FF.body
}

int CupNetwork::findCase (Observer* pObserver)
{
  //## begin cupexception::CupNetwork::findCase%4ECA9F4E030F.body preserve=yes
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery;
   if (pObserver != 0)
      hQuery.attach(pObserver);
   genericexception::Case::instance()->bind(hQuery);
   hQuery.setBasicPredicate("EMS_CASE","PAN","=",CaseSegment::instance()->getPAN().c_str());
   hQuery.setBasicPredicate("EMS_CASE","RETRIEVAL_REF_NO","=",CaseSegment::instance()->getRETRIEVAL_REF_NO().c_str());
   if(CaseSegment::instance()->getSYS_TRACE_AUDIT_NO().length())
      hQuery.setBasicPredicate("EMS_CASE","SYS_TRACE_AUDIT_NO","=",CaseSegment::instance()->getSYS_TRACE_AUDIT_NO().c_str());
   //if(CaseSegment::instance()->getAMT_TRAN() > 0)
   //   hQuery.setBasicPredicate("EMS_CASE","AMT_TRAN","=",CaseSegment::instance()->getAMT_TRAN());
   string strTSTAMP_LOCAL(CaseSegment::instance()->getTSTAMP_LOCAL().data(),8);
   strTSTAMP_LOCAL += "%";
   hQuery.setBasicPredicate("EMS_CASE","TSTAMP_LOCAL","LIKE",strTSTAMP_LOCAL.c_str());
   hQuery.setOrderByClause("EMS_CASE.CASE_ID DESC");  
   if (!pSelectStatement->execute(hQuery))
   {
      UnmatchedMessageSegment::instance()->setMSG_ID("RO04");
      return -1;
   }
   if (pObserver != 0)
   {
      if (hQuery.getAbort() && pSelectStatement->getRows() > 0)
         return 1;
      return 0;
   }
   return pSelectStatement->getRows(); 
  //## end cupexception::CupNetwork::findCase%4ECA9F4E030F.body
}

void CupNetwork::join (reusable::Query& hQuery)
{
  //## begin cupexception::CupNetwork::join%4ECA9F4E0311.body preserve=yes
  //## end cupexception::CupNetwork::join%4ECA9F4E0311.body
}

void CupNetwork::update (Subject* pSubject)
{
  //## begin cupexception::CupNetwork::update%4ECA9F4E031F.body preserve=yes
  //## end cupexception::CupNetwork::update%4ECA9F4E031F.body
}

void CupNetwork::updateCase ()
{
  //## begin cupexception::CupNetwork::updateCase%4ECA9F4E032F.body preserve=yes
  //## end cupexception::CupNetwork::updateCase%4ECA9F4E032F.body
}

// Additional Declarations
  //## begin cupexception::CupNetwork%4ECA9AB1003B.declarations preserve=yes
  //## end cupexception::CupNetwork%4ECA9AB1003B.declarations

} // namespace cupexception

//## begin module%4ECA9B750347.epilog preserve=yes
//## end module%4ECA9B750347.epilog
