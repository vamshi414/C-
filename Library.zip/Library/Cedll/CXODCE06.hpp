//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4ECA9B6D020C.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%4ECA9B6D020C.cm

//## begin module%4ECA9B6D020C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4ECA9B6D020C.cp

//## Module: CXOSCE06%4ECA9B6D020C; Package specification
//## Subsystem: CEDLL%4E2ED9F5004D
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Cedll\CXODCE06.hpp

#ifndef CXOSCE06_h
#define CXOSCE06_h 1

//## begin module%4ECA9B6D020C.additionalIncludes preserve=no
//## end module%4ECA9B6D020C.additionalIncludes

//## begin module%4ECA9B6D020C.includes preserve=yes
//## end module%4ECA9B6D020C.includes

#ifndef CXOSGE94_h
#include "CXODGE94.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseSegment;
class UnmatchedMessageSegment;
} // namespace emssegment

//## Modelname: Transaction Research and Adjustments::GenericException_CAT%4ADF1B4C003E
namespace genericexception {
class Case;
} // namespace genericexception

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%4ECA9B6D020C.declarations preserve=no
//## end module%4ECA9B6D020C.declarations

//## begin module%4ECA9B6D020C.additionalDeclarations preserve=yes
//## end module%4ECA9B6D020C.additionalDeclarations


//## Modelname: Transaction Research and Adjustments::CUPException_CAT%4E2ED9570266
namespace cupexception {
//## begin cupexception%4E2ED9570266.initialDeclarations preserve=yes
//## end cupexception%4E2ED9570266.initialDeclarations

//## begin cupexception::CupNetwork%4ECA9AB1003B.preface preserve=yes
//## end cupexception::CupNetwork%4ECA9AB1003B.preface

//## Class: CupNetwork%4ECA9AB1003B
//## Category: Transaction Research and Adjustments::CUPException_CAT%4E2ED9570266
//## Subsystem: CEDLL%4E2ED9F5004D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4ECAA3A100B6;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4ECAA3C400BD;reusable::Query { -> F}
//## Uses: <unnamed>%4ECAA41A015C;genericexception::Case { -> F}
//## Uses: <unnamed>%4ECAB7D7001C;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4ECABC9D0174;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%4ECABCDA03DF;emssegment::UnmatchedMessageSegment { -> F}

class DllExport CupNetwork : public genericexception::Network  //## Inherits: <unnamed>%61D8DF7E0363
{
  //## begin cupexception::CupNetwork%4ECA9AB1003B.initialDeclarations preserve=yes
  //## end cupexception::CupNetwork%4ECA9AB1003B.initialDeclarations

  public:
    //## Constructors (generated)
      CupNetwork();

    //## Destructor (generated)
      virtual ~CupNetwork();


    //## Other Operations (specified)
      //## Operation: bind%4ECA9F4E02E0
      virtual void bind (reusable::Query& hQuery);

      //## Operation: createCase%4ECA9F4E02FF
      virtual bool createCase ();

      //## Operation: findCase%4ECA9F4E030F
      virtual int findCase (Observer* pObserver = 0	// Instance of the Subject that has changed state.
      );

      //## Operation: join%4ECA9F4E0311
      virtual void join (reusable::Query& hQuery);

      //## Operation: update%4ECA9F4E031F
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

      //## Operation: updateCase%4ECA9F4E032F
      virtual void updateCase ();

    // Additional Public Declarations
      //## begin cupexception::CupNetwork%4ECA9AB1003B.public preserve=yes
      //## end cupexception::CupNetwork%4ECA9AB1003B.public

  protected:
    // Additional Protected Declarations
      //## begin cupexception::CupNetwork%4ECA9AB1003B.protected preserve=yes
      //## end cupexception::CupNetwork%4ECA9AB1003B.protected

  private:
    // Additional Private Declarations
      //## begin cupexception::CupNetwork%4ECA9AB1003B.private preserve=yes
      //## end cupexception::CupNetwork%4ECA9AB1003B.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cupexception::CupNetwork%4ECA9AB1003B.implementation preserve=yes
      //## end cupexception::CupNetwork%4ECA9AB1003B.implementation

};

//## begin cupexception::CupNetwork%4ECA9AB1003B.postscript preserve=yes
//## end cupexception::CupNetwork%4ECA9AB1003B.postscript

} // namespace cupexception

//## begin module%4ECA9B6D020C.epilog preserve=yes
//## end module%4ECA9B6D020C.epilog


#endif
