//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4EBC429D00E4.cm preserve=no
//	$Date:   Nov 15 2011 14:12:20  $ $Author:   D93482  $
//	$Revision:   1.0  $
//## end module%4EBC429D00E4.cm

//## begin module%4EBC429D00E4.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%4EBC429D00E4.cp

//## Module: CXOSCE05%4EBC429D00E4; Package specification
//## Subsystem: CEDLL%4E2ED9F5004D
//## Source file: C:\Devel\Dn\Server\Library\CEDLL\CXODCE05.hpp

#ifndef CXOSCE05_h
#define CXOSCE05_h 1

//## begin module%4EBC429D00E4.additionalIncludes preserve=no
//## end module%4EBC429D00E4.additionalIncludes

//## begin module%4EBC429D00E4.includes preserve=yes
//## end module%4EBC429D00E4.includes

#ifndef CXOSRG02_h
#include "CXODRG02.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseSegment;
class CaseTransitionSegment;

} // namespace emssegment

//## begin module%4EBC429D00E4.declarations preserve=no
//## end module%4EBC429D00E4.declarations

//## begin module%4EBC429D00E4.additionalDeclarations preserve=yes
//## end module%4EBC429D00E4.additionalDeclarations


//## Modelname: Platform\:\:CUP::CUP%4E2ED9570266
namespace cupexception {
//## begin cupexception%4E2ED9570266.initialDeclarations preserve=yes
//## end cupexception%4E2ED9570266.initialDeclarations

//## begin cupexception::CupSecondChargeback%4EBC41560226.preface preserve=yes
//## end cupexception::CupSecondChargeback%4EBC41560226.preface

//## Class: CupSecondChargeback%4EBC41560226
//## Category: Platform\:\:CUP::CUP%4E2ED9570266
//## Subsystem: CEDLL%4E2ED9F5004D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4EBD70F1019E;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%4EBD70FE01D8;emssegment::CaseTransitionSegment { -> F}

class DllExport CupSecondChargeback : public regionalexception::SecondChargeback  //## Inherits: <unnamed>%4EBC417900CA
{
  //## begin cupexception::CupSecondChargeback%4EBC41560226.initialDeclarations preserve=yes
  //## end cupexception::CupSecondChargeback%4EBC41560226.initialDeclarations

  public:
    //## Constructors (generated)
      CupSecondChargeback();

    //## Destructor (generated)
      virtual ~CupSecondChargeback();


    //## Other Operations (specified)
      //## Operation: import%4EBD38BA020E
      bool import ();

      //## Operation: unmatchedImport%4EBD38BF038C
      virtual bool unmatchedImport ();

    // Additional Public Declarations
      //## begin cupexception::CupSecondChargeback%4EBC41560226.public preserve=yes
      //## end cupexception::CupSecondChargeback%4EBC41560226.public

  protected:
    // Additional Protected Declarations
      //## begin cupexception::CupSecondChargeback%4EBC41560226.protected preserve=yes
      //## end cupexception::CupSecondChargeback%4EBC41560226.protected

  private:
    // Additional Private Declarations
      //## begin cupexception::CupSecondChargeback%4EBC41560226.private preserve=yes
      //## end cupexception::CupSecondChargeback%4EBC41560226.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cupexception::CupSecondChargeback%4EBC41560226.implementation preserve=yes
      //## end cupexception::CupSecondChargeback%4EBC41560226.implementation

};

//## begin cupexception::CupSecondChargeback%4EBC41560226.postscript preserve=yes
//## end cupexception::CupSecondChargeback%4EBC41560226.postscript

} // namespace cupexception

//## begin module%4EBC429D00E4.epilog preserve=yes
//## end module%4EBC429D00E4.epilog


#endif
