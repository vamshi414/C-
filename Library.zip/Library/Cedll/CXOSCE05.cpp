//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4EBC429E01BD.cm preserve=no
//	$Date:   Nov 23 2011 11:39:08  $ $Author:   E1009652  $
//	$Revision:   1.1  $
//## end module%4EBC429E01BD.cm

//## begin module%4EBC429E01BD.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%4EBC429E01BD.cp

//## Module: CXOSCE05%4EBC429E01BD; Package body
//## Subsystem: CEDLL%4E2ED9F5004D
//## Source file: C:\Devel\Dn\Server\Library\CEDLL\CXOSCE05.cpp

//## begin module%4EBC429E01BD.additionalIncludes preserve=no
//## end module%4EBC429E01BD.additionalIncludes

//## begin module%4EBC429E01BD.includes preserve=yes
//## end module%4EBC429E01BD.includes

#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSCE05_h
#include "CXODCE05.hpp"
#endif


//## begin module%4EBC429E01BD.declarations preserve=no
//## end module%4EBC429E01BD.declarations

//## begin module%4EBC429E01BD.additionalDeclarations preserve=yes
//## end module%4EBC429E01BD.additionalDeclarations


//## Modelname: Platform\:\:CUP::CUP%4E2ED9570266
namespace cupexception {
//## begin cupexception%4E2ED9570266.initialDeclarations preserve=yes
//## end cupexception%4E2ED9570266.initialDeclarations

// Class cupexception::CupSecondChargeback 

CupSecondChargeback::CupSecondChargeback()
  //## begin CupSecondChargeback::CupSecondChargeback%4EBC41560226_const.hasinit preserve=no
  //## end CupSecondChargeback::CupSecondChargeback%4EBC41560226_const.hasinit
  //## begin CupSecondChargeback::CupSecondChargeback%4EBC41560226_const.initialization preserve=yes
  //## end CupSecondChargeback::CupSecondChargeback%4EBC41560226_const.initialization
{
  //## begin cupexception::CupSecondChargeback::CupSecondChargeback%4EBC41560226_const.body preserve=yes
  //## end cupexception::CupSecondChargeback::CupSecondChargeback%4EBC41560226_const.body
}


CupSecondChargeback::~CupSecondChargeback()
{
  //## begin cupexception::CupSecondChargeback::~CupSecondChargeback%4EBC41560226_dest.body preserve=yes
  //## end cupexception::CupSecondChargeback::~CupSecondChargeback%4EBC41560226_dest.body
}



//## Other Operations (implementation)
bool CupSecondChargeback::import ()
{
  //## begin cupexception::CupSecondChargeback::import%4EBD38BA020E.body preserve=yes
   CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT("CHB2");
   CaseTransitionSegment::instance()->setSTATUS_NEXT("SDRC");
   return transition();
  //## end cupexception::CupSecondChargeback::import%4EBD38BA020E.body
}

bool CupSecondChargeback::unmatchedImport ()
{
  //## begin cupexception::CupSecondChargeback::unmatchedImport%4EBD38BF038C.body preserve=yes
   CaseSegment::instance()->setREQUEST_TYPE("INIT");
   CaseSegment::instance()->setSTATUS("TEMP");
   CaseTransitionSegment::instance()->setREQUEST_TYPE_NEXT("CHB2");
   CaseTransitionSegment::instance()->setREQUEST_TYPE_PREV("INIT");
   CaseTransitionSegment::instance()->setSTATUS_NEXT("CLUN");
   CaseTransitionSegment::instance()->setSTATUS_PREV("TEMP");
   return transition();
   //return regionalexception::SecondChargeback::unmatchedImport();
  //## end cupexception::CupSecondChargeback::unmatchedImport%4EBD38BF038C.body
}

// Additional Declarations
  //## begin cupexception::CupSecondChargeback%4EBC41560226.declarations preserve=yes
  //## end cupexception::CupSecondChargeback%4EBC41560226.declarations

} // namespace cupexception

//## begin module%4EBC429E01BD.epilog preserve=yes
//## end module%4EBC429E01BD.epilog
