//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E3099B0399.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40E3099B0399.cm

//## begin module%40E3099B0399.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40E3099B0399.cp

//## Module: CXOSDQ12%40E3099B0399; Package specification
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXODDQ12.hpp

#ifndef CXOSDQ12_h
#define CXOSDQ12_h 1

//## begin module%40E3099B0399.additionalIncludes preserve=no
//## end module%40E3099B0399.additionalIncludes

//## begin module%40E3099B0399.includes preserve=yes
// $Date:   Jul 20 2005 06:43:52  $ $Author:   D92374  $ $Revision:   1.5  $
//## end module%40E3099B0399.includes

#ifndef CXOSST35_h
#include "CXODST35.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;

} // namespace segment

//## begin module%40E3099B0399.declarations preserve=no
//## end module%40E3099B0399.declarations

//## begin module%40E3099B0399.additionalDeclarations preserve=yes
//## end module%40E3099B0399.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

//## begin dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.preface preserve=yes
//## end dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.preface

//## Class: ODBCAggregatorPOSRisk%40E3078602BF
//## Category: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
//## Subsystem: DQDLL%40852BF400DA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40E30C2703A9;database::Database { -> F}
//## Uses: <unnamed>%40E30C2A0138;monitor::UseCase { -> F}
//## Uses: <unnamed>%41014C5E032C;IF::Trace { -> F}
//## Uses: <unnamed>%41014C6502AF;reusable::Table { -> F}
//## Uses: <unnamed>%41014C68000F;reusable::Statement { -> F}
//## Uses: <unnamed>%41014C6A0128;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%42D66D540222;segment::InformationSegment { -> F}

class DllExport ODBCAggregatorPOSRisk : public settlement::AggregatorPOSRisk  //## Inherits: <unnamed>%40E30C250232
{
  //## begin dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.initialDeclarations preserve=yes
  //## end dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.initialDeclarations

  public:
    //## Constructors (generated)
      ODBCAggregatorPOSRisk();

    //## Destructor (generated)
      virtual ~ODBCAggregatorPOSRisk();


    //## Other Operations (specified)
      //## Operation: tableInsert%40E30C460280
      virtual bool tableInsert ();

      //## Operation: tableUpdate%40E30C460290
      virtual int tableUpdate ();

    // Additional Public Declarations
      //## begin dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.public preserve=yes
      //## end dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.public

  protected:
    // Additional Protected Declarations
      //## begin dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.protected preserve=yes
      //## end dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.protected

  private:
    // Additional Private Declarations
      //## begin dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.private preserve=yes
      //## end dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: APR_ROW_TYPE%410138E40186
      //## begin dnodbcdatabase::ODBCAggregatorPOSRisk::APR_ROW_TYPE%410138E40186.attr preserve=no  private: string {U} 
      string m_strAPR_ROW_TYPE;
      //## end dnodbcdatabase::ODBCAggregatorPOSRisk::APR_ROW_TYPE%410138E40186.attr

    // Additional Implementation Declarations
      //## begin dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.implementation preserve=yes
      //## end dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.implementation

};

//## begin dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.postscript preserve=yes
//## end dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.postscript

} // namespace dnodbcdatabase

//## begin module%40E3099B0399.epilog preserve=yes
using namespace dnodbcdatabase;
//## end module%40E3099B0399.epilog


#endif
