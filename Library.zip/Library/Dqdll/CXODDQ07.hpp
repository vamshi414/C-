//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E3057E0167.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40E3057E0167.cm

//## begin module%40E3057E0167.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40E3057E0167.cp

//## Module: CXOSDQ07%40E3057E0167; Package specification
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXODDQ07.hpp

#ifndef CXOSDQ07_h
#define CXOSDQ07_h 1

//## begin module%40E3057E0167.additionalIncludes preserve=no
//## end module%40E3057E0167.additionalIncludes

//## begin module%40E3057E0167.includes preserve=yes
//## end module%40E3057E0167.includes

#ifndef CXOSPC03_h
#include "CXODPC03.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CriticalSection;
class Transaction;
class Statement;
class SelectStatement;
class Query;
class FormatSelectVisitor;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Console;
class DateTime;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%40E3057E0167.declarations preserve=no
//## end module%40E3057E0167.declarations

//## begin module%40E3057E0167.additionalDeclarations preserve=yes
//## end module%40E3057E0167.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

//## begin dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.preface preserve=yes
//## end dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.preface

//## Class: ODBCPartitionAllocator%40E301D300BB
//## Category: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
//## Subsystem: DQDLL%40852BF400DA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40E3020D0196;database::Database { -> F}
//## Uses: <unnamed>%40E3020F0290;monitor::UseCase { -> F}
//## Uses: <unnamed>%40E3021400DA;IF::DateTime { -> F}
//## Uses: <unnamed>%40E30218033C;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%40E3021D008C;IF::Extract { -> F}
//## Uses: <unnamed>%40E3022202DE;IF::Console { -> F}
//## Uses: <unnamed>%4113C1780186;odbcdatabase::ODBCSQLStatement { -> }
//## Uses: <unnamed>%4113C2A8033C;reusable::Transaction { -> F}
//## Uses: <unnamed>%4113C32D0196;IF::Trace { -> F}
//## Uses: <unnamed>%4113C9C202EE;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4113CA170261;reusable::Query { -> F}
//## Uses: <unnamed>%4113CA1A00FA;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4113EADC0196;reusable::FormatSelectVisitor { -> F}
//## Uses: <unnamed>%4113EB1D0148;reusable::Statement { -> F}
//## Uses: <unnamed>%4118E766007D;odbcdatabase::ODBCDatabase { -> }

class DllExport ODBCPartitionAllocator : public partition::PartitionAllocator  //## Inherits: <unnamed>%40E3020B01B5
{
  //## begin dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.initialDeclarations preserve=yes
   enum State
   {
      START,
      SELECT,
      SUCCESS,
      UPDATE,
      SYNC,
      LOCK_DEADLOCK_TIMEOUT,
      DATABASE_FAILURE,
      DATABASE_CONNECTION_ERROR
   };
  //## end dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.initialDeclarations

  public:
    //## Constructors (generated)
      ODBCPartitionAllocator();

    //## Destructor (generated)
      virtual ~ODBCPartitionAllocator();


    //## Other Operations (specified)
      //## Operation: allocate%411395B1004E
      //	Provides the key value if a partition can be allocated
      //	for the table and date provided.
      //
      //	If an existing partition is found, return 0.
      //	If a new partition is allocated, return 1.
      //	If a partition cannot be allocated, return -1.
      //## Semantics:
      //	1. Enqueue the partition control table.
      //	2. Query the partition control table for a row that
      //	matches the table name and date.
      //	3. If found:
      //	    Copy the partition key and return 0.
      //	4. If not found, query the partition control table for
      //	empty partitions.
      //	5. If no empty partitions are found:
      //	    Copy -1 to the new key and return -1.
      //	6. Update one empty partition by setting the status to
      //	in-use and the date to the date provided.
      //	7. Copy the newly allocated partition key and return 1.
      //
      //	In all cases, before returning:
      //
      //	1. Commit changes to the database.
      //	2. Dequeue the partition control table.
      virtual int allocate (const char* pszTable, const char* pszDate, short int* piKey, const char* pszPartTable);

      //## Operation: reportError%4113EE2803A9
      void reportError (string strMessage);

    // Additional Public Declarations
      //## begin dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.public preserve=yes
      //## end dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.public

  protected:
    // Additional Protected Declarations
      //## begin dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.protected preserve=yes
      //## end dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.protected

  private:

    //## Other Operations (specified)
      //## Operation: lockTable%40E30254001F
      ODBCPartitionAllocator::State lockTable ();

      //## Operation: select%40E30254002E
      ODBCPartitionAllocator::State select (short int* piKey);

      //## Operation: sync%40E30254003E
      ODBCPartitionAllocator::State sync (short int* piKey, const char* pszPartTable);

      //## Operation: update%40E30254004E
      ODBCPartitionAllocator::State update (short int* piKey, const char* pszPartTable);

    // Additional Private Declarations
      //## begin dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.private preserve=yes
      //## end dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: State%40E3024C02BF
      //## begin dnodbcdatabase::ODBCPartitionAllocator::State%40E3024C02BF.attr preserve=no  private: State {V} 
      State m_nState;
      //## end dnodbcdatabase::ODBCPartitionAllocator::State%40E3024C02BF.attr

      //## Attribute: LastPartitionAllocated%40E3024C02CE
      //## begin dnodbcdatabase::ODBCPartitionAllocator::LastPartitionAllocated%40E3024C02CE.attr preserve=no  private: bool {U} false
      bool m_bLastPartitionAllocated;
      //## end dnodbcdatabase::ODBCPartitionAllocator::LastPartitionAllocated%40E3024C02CE.attr

      //## Attribute: PC_TABLE_NAME%4113C5BF0177
      //## begin dnodbcdatabase::ODBCPartitionAllocator::PC_TABLE_NAME%4113C5BF0177.attr preserve=no  private: char[19] {U} 
      char m_psPC_TABLE_NAME[19];
      //## end dnodbcdatabase::ODBCPartitionAllocator::PC_TABLE_NAME%4113C5BF0177.attr

      //## Attribute: PC_PART_STATUS%4113C67D0271
      //## begin dnodbcdatabase::ODBCPartitionAllocator::PC_PART_STATUS%4113C67D0271.attr preserve=no  private: char[2] {U} 
      char m_psPC_PART_STATUS[2];
      //## end dnodbcdatabase::ODBCPartitionAllocator::PC_PART_STATUS%4113C67D0271.attr

      //## Attribute: PC_TSTAMP_START%4113C68D006D
      //## begin dnodbcdatabase::ODBCPartitionAllocator::PC_TSTAMP_START%4113C68D006D.attr preserve=no  private: char[17] {U} 
      char m_psPC_TSTAMP_START[17];
      //## end dnodbcdatabase::ODBCPartitionAllocator::PC_TSTAMP_START%4113C68D006D.attr

      //## Attribute: PC_TSTAMP_END%4113C6A10222
      //## begin dnodbcdatabase::ODBCPartitionAllocator::PC_TSTAMP_END%4113C6A10222.attr preserve=no  private: char[17] {U} 
      char m_psPC_TSTAMP_END[17];
      //## end dnodbcdatabase::ODBCPartitionAllocator::PC_TSTAMP_END%4113C6A10222.attr

      //## Attribute: PC_TSTAMP_UPDATE%4113C6B10222
      //## begin dnodbcdatabase::ODBCPartitionAllocator::PC_TSTAMP_UPDATE%4113C6B10222.attr preserve=no  private: char[17] {U} 
      char m_psPC_TSTAMP_UPDATE[17];
      //## end dnodbcdatabase::ODBCPartitionAllocator::PC_TSTAMP_UPDATE%4113C6B10222.attr

      //## Attribute: PC_QUALIFIER%4113C6C200DA
      //## begin dnodbcdatabase::ODBCPartitionAllocator::PC_QUALIFIER%4113C6C200DA.attr preserve=no  private: char[9] {U} 
      char m_psPC_QUALIFIER[9];
      //## end dnodbcdatabase::ODBCPartitionAllocator::PC_QUALIFIER%4113C6C200DA.attr

      //## Attribute: PC_DBNAME%4113C6CE0271
      //## begin dnodbcdatabase::ODBCPartitionAllocator::PC_DBNAME%4113C6CE0271.attr preserve=no  private: char[9] {U} 
      char m_psPC_DBNAME[9];
      //## end dnodbcdatabase::ODBCPartitionAllocator::PC_DBNAME%4113C6CE0271.attr

      //## Attribute: PC_PART_NUMBER%4113C6EC0261
      //## begin dnodbcdatabase::ODBCPartitionAllocator::PC_PART_NUMBER%4113C6EC0261.attr preserve=no  private: short int {U} 
      short int m_siPC_PART_NUMBER;
      //## end dnodbcdatabase::ODBCPartitionAllocator::PC_PART_NUMBER%4113C6EC0261.attr

      //## Attribute: PC_INDICATOR%4113C6FE005D
      //## begin dnodbcdatabase::ODBCPartitionAllocator::PC_INDICATOR%4113C6FE005D.attr preserve=no  private: short int {U} 
      short int m_siPC_INDICATOR;
      //## end dnodbcdatabase::ODBCPartitionAllocator::PC_INDICATOR%4113C6FE005D.attr

      //## Attribute: PC_ACTIVE_PARTITIONS%4113C7250186
      //## begin dnodbcdatabase::ODBCPartitionAllocator::PC_ACTIVE_PARTITIONS%4113C7250186.attr preserve=no  private: short int {U} 
      short int m_siPC_ACTIVE_PARTITIONS;
      //## end dnodbcdatabase::ODBCPartitionAllocator::PC_ACTIVE_PARTITIONS%4113C7250186.attr

    // Additional Implementation Declarations
      //## begin dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.implementation preserve=yes
      //## end dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.implementation

};

//## begin dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.postscript preserve=yes
//## end dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.postscript

} // namespace dnodbcdatabase

//## begin module%40E3057E0167.epilog preserve=yes
//## end module%40E3057E0167.epilog


#endif
