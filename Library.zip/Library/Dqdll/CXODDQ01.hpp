//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%40852C24008C.cm preserve=no
//## end module%40852C24008C.cm

//## begin module%40852C24008C.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%40852C24008C.cp

//## Module: CXOSDQ01%40852C24008C; Package specification
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Dqdll\CXODDQ01.hpp

#ifndef CXOSDQ01_h
#define CXOSDQ01_h 1

//## begin module%40852C24008C.additionalIncludes preserve=no
//## end module%40852C24008C.additionalIncludes

//## begin module%40852C24008C.includes preserve=yes
// $Date:   Feb 06 2020 15:58:20  $ $Author:   e1009839  $ $Revision:   1.8  $
#include <map>
//## end module%40852C24008C.includes

#ifndef CXOSPQ01_h
#include "CXODPQ01.hpp"
#endif

//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
class ODBCMaintenanceProcedure;
class ODBCAggregatorMIS;
class ODBCAggregatorPOSRisk;
class ODBCCheckpointTotalsVisitor;
class ODBCTransactionRemover;
class ODBCAddFinancialCommand;
class ODBCPartitionAllocator;
class ODBCPartitionDeallocator;
class ODBCLocator;
} // namespace dnodbcdatabase

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

namespace dnodbcdatabase {
class ODBCAggregatorMIS2;

} // namespace dnodbcdatabase

//## begin module%40852C24008C.declarations preserve=no
//## end module%40852C24008C.declarations

//## begin module%40852C24008C.additionalDeclarations preserve=yes
//## end module%40852C24008C.additionalDeclarations


namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

//## begin dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.preface preserve=yes
//## end dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.preface

//## Class: DNODBCDatabaseFactory%40852B7B038A
//## Category: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
//## Subsystem: DQDLL%40852BF400DA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%410010120128;ODBCCheckpointTotalsVisitor { -> F}
//## Uses: <unnamed>%41001014037A;ODBCAddFinancialCommand { -> F}
//## Uses: <unnamed>%4100101D035B;ODBCLocator { -> F}
//## Uses: <unnamed>%410010200167;ODBCAggregatorMIS { -> F}
//## Uses: <unnamed>%410010230119;ODBCAggregatorPOSRisk { -> F}
//## Uses: <unnamed>%410010250290;ODBCMaintenanceProcedure { -> F}
//## Uses: <unnamed>%4100102702CE;ODBCPartitionAllocator { -> F}
//## Uses: <unnamed>%41001029029F;ODBCTransactionRemover { -> F}
//## Uses: <unnamed>%4100102C01C5;ODBCPartitionDeallocator { -> F}
//## Uses: <unnamed>%65454E1002B8;ODBCAggregatorMIS2 { -> F}
//## Uses: <unnamed>%65454E7F009B;IF::Extract { -> F}

class DllExport DNODBCDatabaseFactory : public odbcdatabase::ODBCDatabaseFactory  //## Inherits: <unnamed>%40852F2302AF
{
  //## begin dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.initialDeclarations preserve=yes
  //## end dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.initialDeclarations

  public:
    //## Constructors (generated)
      DNODBCDatabaseFactory();

    //## Constructors (specified)
      //## Operation: DNODBCDatabaseFactory%4110F08B00BB
      DNODBCDatabaseFactory (reusable::string strDBVendor);

    //## Destructor (generated)
      virtual ~DNODBCDatabaseFactory();


    //## Other Operations (specified)
      //## Operation: create%40852BA80232
      virtual Object* create (const char* pszClass, const char* pszValue = 0);

    // Additional Public Declarations
      //## begin dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.public preserve=yes
      //## end dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.public

  protected:
    // Additional Protected Declarations
      //## begin dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.protected preserve=yes
      //## end dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.protected

  private:

    //## Other Operations (specified)
      //## Operation: init%4141ADB30271
      void init (reusable::string strDBVendor);

    // Additional Private Declarations
      //## begin dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.private preserve=yes
      //## end dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Classes%40852BD101D4
      //## begin dnodbcdatabase::DNODBCDatabaseFactory::Classes%40852BD101D4.attr preserve=no  private: map<string,int,less<string> > {V} 
      map<string,int,less<string> > m_hClasses;
      //## end dnodbcdatabase::DNODBCDatabaseFactory::Classes%40852BD101D4.attr

    // Additional Implementation Declarations
      //## begin dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.implementation preserve=yes
      //## end dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.implementation

};

//## begin dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.postscript preserve=yes
//## end dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.postscript

} // namespace dnodbcdatabase

//## begin module%40852C24008C.epilog preserve=yes
//## end module%40852C24008C.epilog


#endif
