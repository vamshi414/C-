//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E305D10167.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40E305D10167.cm

//## begin module%40E305D10167.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40E305D10167.cp

//## Module: CXOSDQ08%40E305D10167; Package body
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXOSDQ08.cpp

//## begin module%40E305D10167.additionalIncludes preserve=no
//## end module%40E305D10167.additionalIncludes

//## begin module%40E305D10167.includes preserve=yes
#define STS_RECORD_NOT_FOUND 14
//## end module%40E305D10167.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSPQ02_h
#include "CXODPQ02.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDQ08_h
#include "CXODDQ08.hpp"
#endif


//## begin module%40E305D10167.declarations preserve=no
//## end module%40E305D10167.declarations

//## begin module%40E305D10167.additionalDeclarations preserve=yes
//## end module%40E305D10167.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

// Class dnodbcdatabase::ODBCPartitionDeallocator 

ODBCPartitionDeallocator::ODBCPartitionDeallocator()
  //## begin ODBCPartitionDeallocator::ODBCPartitionDeallocator%40E3018D029F_const.hasinit preserve=no
  //## end ODBCPartitionDeallocator::ODBCPartitionDeallocator%40E3018D029F_const.hasinit
  //## begin ODBCPartitionDeallocator::ODBCPartitionDeallocator%40E3018D029F_const.initialization preserve=yes
  //## end ODBCPartitionDeallocator::ODBCPartitionDeallocator%40E3018D029F_const.initialization
{
  //## begin dnodbcdatabase::ODBCPartitionDeallocator::ODBCPartitionDeallocator%40E3018D029F_const.body preserve=yes
   memcpy(m_sID,"DQ08",4);
  //## end dnodbcdatabase::ODBCPartitionDeallocator::ODBCPartitionDeallocator%40E3018D029F_const.body
}


ODBCPartitionDeallocator::~ODBCPartitionDeallocator()
{
  //## begin dnodbcdatabase::ODBCPartitionDeallocator::~ODBCPartitionDeallocator%40E3018D029F_dest.body preserve=yes
  //## end dnodbcdatabase::ODBCPartitionDeallocator::~ODBCPartitionDeallocator%40E3018D029F_dest.body
}



//## Other Operations (implementation)
bool ODBCPartitionDeallocator::available (int* piPartitionCount)
{
  //## begin dnodbcdatabase::ODBCPartitionDeallocator::available%40E303140399.body preserve=yes
   CriticalSection hCriticalSection("CATALOG");
   if (Database::instance()->getDormant())
      Database::instance()->connect();
   strcpy(m_pszPD_QUALIFIER,Database::instance()->qualifier().c_str());
   strcpy(m_pszPD_DBNAME,Database::instance()->getName().c_str());
   strcpy(m_pszPD_TABLE_NAME,m_strTableName.c_str());
   m_nState = ODBCPartitionDeallocator::START;
   int iRetry = 0;
   while (iRetry < 5)
   {
      switch (m_nState)
      {
         case ODBCPartitionDeallocator::START:
            m_nState = selectCatalog();
            *piPartitionCount = m_siPD_PARTITIONS;
            break;
         case ODBCPartitionDeallocator::SELECT:
            m_nState = selectCount();
            break;
         case ODBCPartitionDeallocator::SUCCESS:
            *piPartitionCount -= m_siPD_PARTITIONS;
            Database::instance()->commit();
            return true;
         case ODBCPartitionDeallocator::DEADLOCK_TIMEOUT:
            UseCase::add("DEADLOCK");
            Database::instance()->rollback();
            iRetry++;
            m_nState = ODBCPartitionDeallocator::START;
            break;
         case ODBCPartitionDeallocator::DATABASE_FAILURE:
            UseCase::add("DBERROR");
            Database::instance()->rollback();
            return false;
         case ODBCPartitionDeallocator::DATABASE_CONNECTION_ERROR:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            return false;
      }
   }
   UseCase::setSuccess(false);
   Database::instance()->rollback();
   return false;
  //## end dnodbcdatabase::ODBCPartitionDeallocator::available%40E303140399.body
}

bool ODBCPartitionDeallocator::deallocate (int iPartitionNumber)
{
  //## begin dnodbcdatabase::ODBCPartitionDeallocator::deallocate%40E30314039B.body preserve=yes
   UseCase hUseCase("DR","## DR18 FREE PARTITION");
   CriticalSection hCriticalSection("CATALOG");
   if (Database::instance()->getDormant())
      Database::instance()->connect();
   strcpy(m_pszPD_TABLE_NAME,m_strTableName.c_str());
   m_siPD_PART_NUMBER = iPartitionNumber;
   strcpy(m_pszPD_TSTAMP_START," ");
   strcpy(m_pszPD_TSTAMP_END," ");
   IString strDate;
   DateTime hDateTime;
   hDateTime.setCurrent(strDate);
   strcpy(m_pszPD_TSTAMP_UPDATE,strDate);
   m_nState = ODBCPartitionDeallocator::START;
   int iRetry = 0;
   while (iRetry < 5)
   {
      switch (m_nState)
      {
         case ODBCPartitionDeallocator::START:
            m_nState = update();
            break;
         case ODBCPartitionDeallocator::SUCCESS:
            Database::instance()->commit();
            notify();
            return true;
         case ODBCPartitionDeallocator::DEADLOCK_TIMEOUT:
            UseCase::add("DEADLOCK");
            Database::instance()->rollback();
            iRetry++;
            m_nState = ODBCPartitionDeallocator::START;
            break;
         case ODBCPartitionDeallocator::DATABASE_FAILURE:
            UseCase::add("DBERROR");
            Database::instance()->rollback();
            return false;
         case ODBCPartitionDeallocator::DATABASE_CONNECTION_ERROR:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            return false;
      }
   }
   Database::instance()->rollback();
   return false;

  //## end dnodbcdatabase::ODBCPartitionDeallocator::deallocate%40E30314039B.body
}

bool ODBCPartitionDeallocator::oldest (IString& strTimestampStart, IString& strTimestampEnd, int* piPartitionNumber)
{
  //## begin dnodbcdatabase::ODBCPartitionDeallocator::oldest%40E3031403C8.body preserve=yes
   CriticalSection hCriticalSection("CATALOG");
   if (Database::instance()->getDormant())
      Database::instance()->connect();
   strcpy(m_pszPD_TABLE_NAME,m_strTableName.c_str());
   m_nState = ODBCPartitionDeallocator::START;
   int iRetry = 0;
   while (iRetry < 5)
   {
      switch (m_nState)
      {
         case ODBCPartitionDeallocator::START:
            m_nState = selectOldest();
            break;
         case ODBCPartitionDeallocator::SUCCESS:
            strTimestampStart = m_pszPD_TSTAMP_START;
            strTimestampEnd = m_pszPD_TSTAMP_END;
            *piPartitionNumber = m_siPD_PART_NUMBER;
            Database::instance()->commit();
            return true;
         case ODBCPartitionDeallocator::DEADLOCK_TIMEOUT:
            UseCase::add("DEADLOCK");
            Database::instance()->rollback();
            iRetry++;
            m_nState = ODBCPartitionDeallocator::START;
            break;
         case ODBCPartitionDeallocator::DATABASE_FAILURE:
            UseCase::add("DBERROR");
            Database::instance()->rollback();
            return false;
         case ODBCPartitionDeallocator::DATABASE_CONNECTION_ERROR:
            UseCase::add("CONNECT");
            Database::instance()->setState(Database::DISCONNECTED);
            return false;
      }
   }
   Database::instance()->rollback();
   return false;

  //## end dnodbcdatabase::ODBCPartitionDeallocator::oldest%40E3031403C8.body
}

ODBCPartitionDeallocator::State ODBCPartitionDeallocator::selectCatalog ()
{
  //## begin dnodbcdatabase::ODBCPartitionDeallocator::selectCatalog%40E3031403D8.body preserve=yes
   Trace::put("selectCatalog");
   Trace::put(m_pszPD_QUALIFIER);
   Trace::put(m_pszPD_DBNAME);
   Trace::put(m_pszPD_TABLE_NAME);
   m_siPD_PARTITIONS = 0;
   string strPartitions;
   if (Extract::instance()->getSpec("PARTS   ",strPartitions))
      m_siPD_PARTITIONS = atoi(strPartitions.c_str());
   if (m_siPD_PARTITIONS == 0)
   {
      m_siPD_PARTITIONS = 32;
   }

   return ODBCPartitionDeallocator::SELECT;
  //## end dnodbcdatabase::ODBCPartitionDeallocator::selectCatalog%40E3031403D8.body
}

ODBCPartitionDeallocator::State ODBCPartitionDeallocator::selectCount ()
{
  //## begin dnodbcdatabase::ODBCPartitionDeallocator::selectCount%40E303150000.body preserve=yes
   m_siPD_PARTITIONS = 0;
   
/*
EXEC SQL
      SELECT
         COUNT(*)
      INTO
         :PD_PARTITIONS INDICATOR :PD_INDICATOR
      FROM PARTITION_CONTROL
      WHERE TABLE_NAME = :PD_TABLE_NAME
        AND PART_STAT <> 'R';
*/


   Query hQuery;
   int m = 0;
   short iNull;
   hQuery.bind("PARTITION_CONTROL","*",Column::LONG,&m,&iNull,"COUNT");
   hQuery.setBasicPredicate("PARTITION_CONTROL","TABLE_NAME","=",m_pszPD_TABLE_NAME);
   hQuery.setBasicPredicate("PARTITION_CONTROL","PART_STAT","<>","R");
   hQuery.setQualifier("CUSTQUAL", "PARTITION_CONTROL");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   bool bReturn = pSelectStatement->execute(hQuery);
   m_siPD_PARTITIONS = m;
   if(bReturn)
   {
      return ODBCPartitionDeallocator::SUCCESS;
   }
   else
   {
      if(pSelectStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      {
         return ODBCPartitionDeallocator::SUCCESS;
      }
      string strMessage = "Error in ODBCPartitionDeallocator::selectCount - executing SELECT COUNT(*) FROM PARTITION_CONTROL";
      Database::instance()->traceSQLError(strMessage);
      return ODBCPartitionDeallocator::DATABASE_FAILURE;
   }
  //## end dnodbcdatabase::ODBCPartitionDeallocator::selectCount%40E303150000.body
}

ODBCPartitionDeallocator::State ODBCPartitionDeallocator::selectOldest ()
{
  //## begin dnodbcdatabase::ODBCPartitionDeallocator::selectOldest%40E303150001.body preserve=yes
/*
EXEC SQL
      SELECT
         TSTAMP_START,
         TSTAMP_END,
         PART_NUMBER
      INTO
         :PD_TSTAMP_START,
         :PD_TSTAMP_END,
         :PD_PART_NUMBER
      FROM PARTITION_CONTROL
      WHERE TABLE_NAME = :PD_TABLE_NAME
        AND TSTAMP_END = (SELECT MIN(TSTAMP_END)
                             FROM PARTITION_CONTROL
                             WHERE TABLE_NAME = :PD_TABLE_NAME
                               AND PART_STAT = 'A');
*/
   string strTSTAMP_START;
   string strTSTAMP_END;

   Query hQuery;
   hQuery.setSubSelect(true);
   hQuery.bind("PARTITION_CONTROL","TSTAMP_END",Column::STRING,&strTSTAMP_END,0,"MIN");
   hQuery.setBasicPredicate("PARTITION_CONTROL","TABLE_NAME","=",m_pszPD_TABLE_NAME);
   hQuery.setBasicPredicate("PARTITION_CONTROL","PART_STAT","=","A");
   auto_ptr<reusable::FormatSelectVisitor>pFormatSelectVisitor
      ((reusable::FormatSelectVisitor*)database::DatabaseFactory::instance()->create("FormatSelectVisitor"));
   hQuery.accept(*pFormatSelectVisitor);
   string strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ")";

   hQuery.reset();
   hQuery.setSubSelect(false);
   hQuery.bind("PARTITION_CONTROL","TSTAMP_START",Column::STRING,&strTSTAMP_START);
   hQuery.bind("PARTITION_CONTROL","TSTAMP_END",Column::STRING,&strTSTAMP_END);
   hQuery.bind("PARTITION_CONTROL","PART_NUMBER",Column::SHORT,&m_siPD_PART_NUMBER);
   hQuery.setBasicPredicate("PARTITION_CONTROL","TABLE_NAME","=",m_pszPD_TABLE_NAME);
   hQuery.setBasicPredicate("PARTITION_CONTROL","TSTAMP_END","IN",strSubSelect.c_str());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if(pSelectStatement->execute(hQuery))
   {
      memcpy(m_pszPD_TSTAMP_START,strTSTAMP_START.data(),strTSTAMP_START.length());
      m_pszPD_TSTAMP_START[strTSTAMP_START.length()] = '\0';
      memcpy(m_pszPD_TSTAMP_END,strTSTAMP_END.data(),strTSTAMP_END.length());
      m_pszPD_TSTAMP_END[strTSTAMP_END.length()] = '\0';
      return ODBCPartitionDeallocator::SUCCESS;
   }
   else
   {
      string strErrorMsg = "Error in ODBCPartitionDeallocator::selectOldest() executing -";
      strErrorMsg += "SELECT TSTAMP_START,TSTAMP_END,PART_NUMBER FROM PARTITION_CONTROL WHERE TABLE_NAME = ? AND TSTAMP_END =(SELECT(MIN(TSTAMP_END))....";
      Database::instance()->traceSQLError(strErrorMsg);
      return ODBCPartitionDeallocator::DATABASE_FAILURE;
   }

  //## end dnodbcdatabase::ODBCPartitionDeallocator::selectOldest%40E303150001.body
}

ODBCPartitionDeallocator::State ODBCPartitionDeallocator::update ()
{
  //## begin dnodbcdatabase::ODBCPartitionDeallocator::update%40E30315000F.body preserve=yes
/*
EXEC SQL
      UPDATE PARTITION_CONTROL
         SET
            PART_STAT = 'R',
            TSTAMP_START = :PD_TSTAMP_START,
            TSTAMP_END = :PD_TSTAMP_END,
            TSTAMP_UPDATE = :PD_TSTAMP_UPDATE
         WHERE TABLE_NAME = :PD_TABLE_NAME
           AND PART_NUMBER = :PD_PART_NUMBER
           AND PART_STAT = 'A';
*/
   strcpy(m_pszPD_PART_STATUS,"R");
   m_pszPD_PART_STATUS[1] = '\0';

   Table hTable;
   hTable.setName("PARTITION_CONTROL");
   hTable.setQualifier("CUSTQUAL");
   //set
   hTable.set("PART_STAT",m_pszPD_PART_STATUS,false,false);
   hTable.set("TSTAMP_START",m_pszPD_TSTAMP_START,false,false);
   hTable.set("TSTAMP_END",m_pszPD_TSTAMP_END,false,false);
   hTable.set("TSTAMP_UPDATE",m_pszPD_TSTAMP_UPDATE,false,false);
   //where
   hTable.set("TABLE_NAME",m_pszPD_TABLE_NAME,false,true);
   hTable.set("PART_NUMBER",(int)m_siPD_PART_NUMBER,true);
   string strSearchCondition = " AND PART_STAT = 'A'";
   auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if(pUpdateStatement->execute(hTable,strSearchCondition))
   {
      return ODBCPartitionDeallocator::SUCCESS;
   }
   else
   {
      string strErrorMsg = "Error in ODBCPartitionAllocator::update() executing ";
      strErrorMsg += "UPDATE PARTITION_CONTROL SET...";
      Database::instance()->traceSQLError(strErrorMsg);
      return ODBCPartitionDeallocator::DATABASE_FAILURE;
   }

  //## end dnodbcdatabase::ODBCPartitionDeallocator::update%40E30315000F.body
}

// Additional Declarations
  //## begin dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.declarations preserve=yes
  //## end dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.declarations

} // namespace dnodbcdatabase

//## begin module%40E305D10167.epilog preserve=yes
//## end module%40E305D10167.epilog
