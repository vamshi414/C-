//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E30A3D000F.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40E30A3D000F.cm

//## begin module%40E30A3D000F.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40E30A3D000F.cp

//## Module: CXOSDQ14%40E30A3D000F; Package body
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXOSDQ14.cpp

//## begin module%40E30A3D000F.additionalIncludes preserve=no
//## end module%40E30A3D000F.additionalIncludes

//## begin module%40E30A3D000F.includes preserve=yes
//## end module%40E30A3D000F.includes

#ifndef CXOSIF44_h
#include "CXODIF44.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDQ14_h
#include "CXODDQ14.hpp"
#endif


//## begin module%40E30A3D000F.declarations preserve=no
//## end module%40E30A3D000F.declarations

//## begin module%40E30A3D000F.additionalDeclarations preserve=yes
//## end module%40E30A3D000F.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

// Class dnodbcdatabase::ODBCMaintenanceProcedure 

ODBCMaintenanceProcedure::ODBCMaintenanceProcedure()
  //## begin ODBCMaintenanceProcedure::ODBCMaintenanceProcedure%40E307CB003E_const.hasinit preserve=no
      : m_lFreePages(0),
        m_lTotalPages(0),
        m_lUsedPages(0)
  //## end ODBCMaintenanceProcedure::ODBCMaintenanceProcedure%40E307CB003E_const.hasinit
  //## begin ODBCMaintenanceProcedure::ODBCMaintenanceProcedure%40E307CB003E_const.initialization preserve=yes
  //## end ODBCMaintenanceProcedure::ODBCMaintenanceProcedure%40E307CB003E_const.initialization
{
  //## begin dnodbcdatabase::ODBCMaintenanceProcedure::ODBCMaintenanceProcedure%40E307CB003E_const.body preserve=yes
   memcpy(m_sID,"DQ14",4);
  //## end dnodbcdatabase::ODBCMaintenanceProcedure::ODBCMaintenanceProcedure%40E307CB003E_const.body
}


ODBCMaintenanceProcedure::~ODBCMaintenanceProcedure()
{
  //## begin dnodbcdatabase::ODBCMaintenanceProcedure::~ODBCMaintenanceProcedure%40E307CB003E_dest.body preserve=yes
  //## end dnodbcdatabase::ODBCMaintenanceProcedure::~ODBCMaintenanceProcedure%40E307CB003E_dest.body
}



//## Other Operations (implementation)
void ODBCMaintenanceProcedure::review (const char* pszText)
{
  //## begin dnodbcdatabase::ODBCMaintenanceProcedure::review%40E30D16035B.body preserve=yes
   if (m_strMember != "CXOXDB00")
      return;
   string strValue;
   const char* p = strstr(pszText," = ");
   if (p)
      strValue.assign(p + 3);
   if (memcmp(pszText," Name ",6) == 0)
      m_strName = strValue;
   else
   if (memcmp(pszText," Total pages ",13) == 0)
      m_lTotalPages = atoi(strValue.c_str());
   else
   if (memcmp(pszText," Used pages ",12) == 0)
      m_lUsedPages = atoi(strValue.c_str());
   else
   if (memcmp(pszText," Free pages ",12) == 0)
      m_lFreePages = atoi(strValue.c_str());
   else
   if (memcmp(pszText," Page size ",11) == 0)
   {
      int lPageSize = atoi(strValue.c_str());
      if (m_lFreePages > 0) // i.e. not Not Applicable
      {
         int lTargetPercentFree = 20;
         size_t pYear = m_strName.find("20");
         if (pYear != string::npos)
         {
            char szTemp[7] = {"      "};
            memcpy(szTemp,m_strName.data() + pYear,6);
            int iMonth = atoi(szTemp + 4);
            szTemp[4] = '\0';
            int iYear = atoi(szTemp);
            Date hDate(Date::today());
            if (hDate.getYear() != iYear)
               return;
            if (hDate.getMonth() != iMonth)
               return;
            int iDay = hDate.getDay();
            int iDays = Date::daysInMonth(hDate.getYear(),hDate.getMonth());
            int iDaysRemaining = (iDays - iDay) + 1;
            if (iDaysRemaining < 5)
               lTargetPercentFree = iDaysRemaining * 4;
         }
         int lTargetFreePages = (m_lTotalPages * lTargetPercentFree) / 100;
         if (m_lFreePages < lTargetFreePages)
         {
            int lNeedPages = lTargetFreePages - m_lFreePages;
            int lAlter = (lNeedPages * lPageSize) / 1024000;
            if (lAlter < 1)
               lAlter = 1;
            char szTemp[16];
            snprintf(szTemp,sizeof(szTemp),"%d",lAlter);
            //Job::submit("CXOXDB01","&TS     ",m_strName.c_str(),"&ALTER ",szTemp);
            string strTS("TS");
            SiteSpecification::instance()->add(strTS,m_strName);
            string strALTER("ALTER");
            string strValue(szTemp);
            SiteSpecification::instance()->add(strALTER,strValue);
            ODBCMaintenanceProcedure hMaintenanceProcedure;
            hMaintenanceProcedure.execute("CXOXDB01");
         }
      }
   }
  //## end dnodbcdatabase::ODBCMaintenanceProcedure::review%40E30D16035B.body
}

// Additional Declarations
  //## begin dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.declarations preserve=yes
  //## end dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.declarations

} // namespace dnodbcdatabase

//## begin module%40E30A3D000F.epilog preserve=yes
//## end module%40E30A3D000F.epilog
