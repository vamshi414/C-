//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E309E7005D.cm preserve=no
//	$Date:   May 26 2020 17:45:28  $ $Author:   e1009510  $
//	$Revision:   1.24  $
//## end module%40E309E7005D.cm

//## begin module%40E309E7005D.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%40E309E7005D.cp

//## Module: CXOSDQ13%40E309E7005D; Package body
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXOSDQ13.cpp

//## begin module%40E309E7005D.additionalIncludes preserve=no
//## end module%40E309E7005D.additionalIncludes

//## begin module%40E309E7005D.includes preserve=yes
#include "CXODIF16.hpp"
#include "CXODST08.hpp"
//## end module%40E309E7005D.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
#ifndef CXOSST03_h
#include "CXODST03.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSDQ13_h
#include "CXODDQ13.hpp"
#endif


//## begin module%40E309E7005D.declarations preserve=no
//## end module%40E309E7005D.declarations

//## begin module%40E309E7005D.additionalDeclarations preserve=yes
//## end module%40E309E7005D.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

// Class dnodbcdatabase::ODBCAggregatorMIS

ODBCAggregatorMIS::ODBCAggregatorMIS()
  //## begin ODBCAggregatorMIS::ODBCAggregatorMIS%40E307AA0119_const.hasinit preserve=no
  //## end ODBCAggregatorMIS::ODBCAggregatorMIS%40E307AA0119_const.hasinit
  //## begin ODBCAggregatorMIS::ODBCAggregatorMIS%40E307AA0119_const.initialization preserve=yes
  //## end ODBCAggregatorMIS::ODBCAggregatorMIS%40E307AA0119_const.initialization
{
  //## begin dnodbcdatabase::ODBCAggregatorMIS::ODBCAggregatorMIS%40E307AA0119_const.body preserve=yes
   memcpy(m_sID,"DQ13",4);
  //## end dnodbcdatabase::ODBCAggregatorMIS::ODBCAggregatorMIS%40E307AA0119_const.body
}


ODBCAggregatorMIS::~ODBCAggregatorMIS()
{
  //## begin dnodbcdatabase::ODBCAggregatorMIS::~ODBCAggregatorMIS%40E307AA0119_dest.body preserve=yes
  //## end dnodbcdatabase::ODBCAggregatorMIS::~ODBCAggregatorMIS%40E307AA0119_dest.body
}



//## Other Operations (implementation)
bool ODBCAggregatorMIS::tableInsert (bool bSubtractFromTotals)
{
  //## begin dnodbcdatabase::ODBCAggregatorMIS::tableInsert%40E30CB0000F.body preserve=yes
   int lPARTITION_KEY = 0;
   if (Extract::instance()->getCustomCode() == "EFTPOS")
      lPARTITION_KEY = (getINTERVAL_TYPE() == "M" || getINTERVAL_TYPE() == "Y") ? 0 : (int)(PartitionControl::instance()->partitionKey("T_MIS_TOTAL",FinancialTransaction::instance()->getDATE_RECON_ACQ().data(),"MISPARTS"));
   else
      lPARTITION_KEY = (getINTERVAL_TYPE() == "M" || getINTERVAL_TYPE() == "Y") ? 0 : (int)(PartitionControl::instance()->partitionKey("T_MIS_TOTAL",FinancialTransaction::instance()->getTSTAMP_TRANS().data(),"MISPARTS"));
   int lT_FIN_ENTITY_ID = 0;
   int lT_FIN_ENTITY_ID_2 = -1;
   RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(0).c_str(),getENTITY_ID(0).c_str(),&lT_FIN_ENTITY_ID);
   Table hTable("T_MIS_TOTAL");
   hTable.set("TSTAMP_START",getTSTAMP_START());
   hTable.set("INTERVAL_TYPE",getINTERVAL_TYPE());
   hTable.set("BIN", getBIN());
   hTable.set("T_FIN_ENTITY_ID",lT_FIN_ENTITY_ID);
   if (getENTITY_ID(1) != "~NULL!")
   {
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(1).c_str(),getENTITY_ID(1).c_str(),&lT_FIN_ENTITY_ID_2);
      hTable.set("T_FIN_ENTITY_ID_2",lT_FIN_ENTITY_ID_2);
   }
   hTable.set("T_MIS_MCC",getT_MIS_MCC());
   hTable.set("CATEGORY_ID",(int)getCATEGORY_ID());
   hTable.set("PARTITION_KEY",lPARTITION_KEY);
   hTable.set("SYNC_INTERVAL_NO",getSYNC_INTERVAL_NO());
   if (bSubtractFromTotals)
   {
      hTable.set("AMT_TRAN",0 - getAMT_TRAN());
      hTable.set("AMT_SURCHARGE",0 - getAMT_SURCHARGE());
      hTable.set("AMT_POS_REIMBURSE",0 - getAMT_POS_REIMBURSE());
      hTable.set("CASHBACK_AMT",0 - getCASHBACK_AMT());
      hTable.set("TRAN_COUNT",(int)-1);
      hTable.set("TIME_AT_ISS",0 - (double)getTIME_AT_ISS());
      hTable.set("TIME_AT_RQST_SWTCH",0 - (double)getTIME_AT_RQST_SWTCH());
      hTable.set("AMT_FEE",0 - getAMT_FEE());
   }
   else
   {
      hTable.set("AMT_TRAN",getAMT_TRAN());
      hTable.set("AMT_SURCHARGE",getAMT_SURCHARGE());
      hTable.set("AMT_POS_REIMBURSE",getAMT_POS_REIMBURSE());
      hTable.set("CASHBACK_AMT",getCASHBACK_AMT());
      hTable.set("TRAN_COUNT",(int)1);
      hTable.set("TIME_AT_ISS",(double)getTIME_AT_ISS());
      hTable.set("TIME_AT_RQST_SWTCH",(double)getTIME_AT_RQST_SWTCH());
      hTable.set("AMT_FEE",getAMT_FEE());
   }
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   if (!pInsertStatement->execute(hTable))
   {
      char szTemp[2 * PERCENTS + 7 * PERCENTF + 5 * PERCENTD];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_MIS_TOTAL %s %d %d %s %d %f %f %f %f %d %f %f %f %d",
         getTSTAMP_START().c_str(),lT_FIN_ENTITY_ID,lT_FIN_ENTITY_ID_2,getT_MIS_MCC().c_str(),getCATEGORY_ID(),getAMT_TRAN(),
         getAMT_SURCHARGE(),getAMT_POS_REIMBURSE(),getCASHBACK_AMT(),(int)1,(double)getTIME_AT_ISS(),(double)getTIME_AT_RQST_SWTCH(),
         getAMT_FEE(),getSYNC_INTERVAL_NO());
      Trace::put(szTemp);
      return false;
   }
   UseCase::addItem();
   return true;
  //## end dnodbcdatabase::ODBCAggregatorMIS::tableInsert%40E30CB0000F.body
}

int ODBCAggregatorMIS::tableUpdate (bool bSubtractFromTotals)
{
  //## begin dnodbcdatabase::ODBCAggregatorMIS::tableUpdate%40E30CB0001F.body preserve=yes
   int lT_FIN_ENTITY_ID = 0;
   int lT_FIN_ENTITY_ID_2 = -1;
   RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(0).c_str(),getENTITY_ID(0).c_str(),&lT_FIN_ENTITY_ID);
   Table hTable("T_MIS_TOTAL");
   hTable.set("TSTAMP_START",getTSTAMP_START(),false,true);
   hTable.set("T_FIN_ENTITY_ID",lT_FIN_ENTITY_ID,true);
   if (getENTITY_ID(1) != "~NULL!")
   {
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(1).c_str(),getENTITY_ID(1).c_str(),&lT_FIN_ENTITY_ID_2);
      hTable.set("T_FIN_ENTITY_ID_2",lT_FIN_ENTITY_ID_2,true);
   }
   else
      hTable.set("T_FIN_ENTITY_ID_2",getENTITY_ID(1),true);
   hTable.set("T_MIS_MCC",getT_MIS_MCC(),false,true);
   hTable.set("CATEGORY_ID",(int)getCATEGORY_ID(),true);
   hTable.set("INTERVAL_TYPE",getINTERVAL_TYPE(),false,true);
   hTable.set("BIN", getBIN(), false, true);
   if (bSubtractFromTotals)
   {
      hTable.set("AMT_TRAN",getAMT_TRAN(),false,"-");
      hTable.set("AMT_SURCHARGE",getAMT_SURCHARGE(),false,"-");
      hTable.set("AMT_POS_REIMBURSE",getAMT_POS_REIMBURSE(),false,"-");
      hTable.set("CASHBACK_AMT",getCASHBACK_AMT(),false,"-");
      hTable.set("TRAN_COUNT",(int)1,false,"-");
      hTable.set("TIME_AT_ISS",(double)getTIME_AT_ISS(),false,"-");
      hTable.set("TIME_AT_RQST_SWTCH",(double)getTIME_AT_RQST_SWTCH(),false,"-");
      hTable.set("AMT_FEE",getAMT_FEE(),false,"-");
   }
   else
   {
      hTable.set("AMT_TRAN",getAMT_TRAN(),false,"+");
      hTable.set("AMT_SURCHARGE",getAMT_SURCHARGE(),false,"+");
      hTable.set("AMT_POS_REIMBURSE",getAMT_POS_REIMBURSE(),false,"+");
      hTable.set("CASHBACK_AMT",getCASHBACK_AMT(),false,"+");
      hTable.set("TRAN_COUNT",(int)1,false,"+");
      hTable.set("TIME_AT_ISS",(double)getTIME_AT_ISS(),false,"+");
      hTable.set("TIME_AT_RQST_SWTCH",(double)getTIME_AT_RQST_SWTCH(),false,"+");
      hTable.set("AMT_FEE",getAMT_FEE(),false,"+");
   }
   char szTemp[PERCENTD];
   hTable.getSearchCondition().append(" AND ((");
   hTable.getSearchCondition().append("SYNC_INTERVAL_NO = ");
   hTable.getSearchCondition().append(szTemp,snprintf(szTemp,sizeof(szTemp),"%04d",getSYNC_INTERVAL_NO()));
   hTable.getSearchCondition().append(") OR (");
   hTable.getSearchCondition().append("SYNC_INTERVAL_NO IS NULL");
   hTable.getSearchCondition().append("))");
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if (!pUpdateStatement->execute(hTable))
   {
      if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
         return 0;
      char szTemp[7 * PERCENTF + 5 * PERCENTD + 2 * PERCENTS];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_MIS_TOTAL %s %d %d %s %d %f %f %f %f %d %f %f %f %d",
         getTSTAMP_START().c_str(),lT_FIN_ENTITY_ID,lT_FIN_ENTITY_ID_2,getT_MIS_MCC().c_str(),getCATEGORY_ID(),getAMT_TRAN(),
         getAMT_SURCHARGE(),getAMT_POS_REIMBURSE(),getCASHBACK_AMT(),(int)1,(double)getTIME_AT_ISS(),(double)getTIME_AT_RQST_SWTCH(),
         getAMT_FEE(),getSYNC_INTERVAL_NO());
      Trace::put(szTemp);
      return -1;
   }
   UseCase::addItem();
   return 1;
  //## end dnodbcdatabase::ODBCAggregatorMIS::tableUpdate%40E30CB0001F.body
}

// Additional Declarations
  //## begin dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.declarations preserve=yes
  //## end dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.declarations

} // namespace dnodbcdatabase

//## begin module%40E309E7005D.epilog preserve=yes
//## end module%40E309E7005D.epilog
