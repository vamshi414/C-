//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E308FB01A5.cm preserve=no
//	$Date:   Sep 25 2007 13:16:40  $ $Author:   D02405  $
//	$Revision:   1.5  $
//## end module%40E308FB01A5.cm

//## begin module%40E308FB01A5.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%40E308FB01A5.cp

//## Module: CXOSDQ10%40E308FB01A5; Package specification
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXODDQ10.hpp

#ifndef CXOSDQ10_h
#define CXOSDQ10_h 1

//## begin module%40E308FB01A5.additionalIncludes preserve=no
//## end module%40E308FB01A5.additionalIncludes

//## begin module%40E308FB01A5.includes preserve=yes
//## end module%40E308FB01A5.includes

#ifndef CXOSST06_h
#include "CXODST06.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class RecoveryPoint;
class EntityGroup;
class ReportingPeriod;
class TotalsCategory;
class ReportingEntity;
class Total;
} // namespace settlement

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::ODBCDatabase_CAT%4085256E03A9
namespace odbcdatabase {
class ODBCDatabase;

} // namespace odbcdatabase

//## begin module%40E308FB01A5.declarations preserve=no
//## end module%40E308FB01A5.declarations

//## begin module%40E308FB01A5.additionalDeclarations preserve=yes
//## end module%40E308FB01A5.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

//## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.preface preserve=yes
//## end dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.preface

//## Class: ODBCCheckpointTotalsVisitor%40E30728029F
//## Category: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
//## Subsystem: DQDLL%40852BF400DA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40E30B070399;database::Database { -> F}
//## Uses: <unnamed>%40E30B0A0119;monitor::UseCase { -> F}
//## Uses: <unnamed>%40E30B110222;timer::Clock { -> F}
//## Uses: <unnamed>%40E30B15037A;settlement::EntityGroup { -> F}
//## Uses: <unnamed>%40E30B180157;settlement::Total { -> F}
//## Uses: <unnamed>%40E30B250213;settlement::ReportingEntity { -> F}
//## Uses: <unnamed>%40E30B27036B;settlement::ReportingPeriod { -> F}
//## Uses: <unnamed>%40E30B2A0177;settlement::TotalsCategory { -> F}
//## Uses: <unnamed>%40E30B2E03D8;process::Application { -> F}
//## Uses: <unnamed>%40E30B4303D8;settlement::RecoveryPoint { -> F}
//## Uses: <unnamed>%41190569035B;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%411905CD006D;odbcdatabase::ODBCDatabase { -> F}
//## Uses: <unnamed>%411905E00148;reusable::Table { -> F}
//## Uses: <unnamed>%4119062B0119;IF::Trace { -> F}

class DllExport ODBCCheckpointTotalsVisitor : public settlement::CheckpointTotalsVisitor  //## Inherits: <unnamed>%40E30B05007D
{
  //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.initialDeclarations preserve=yes
  //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.initialDeclarations

  public:
    //## Constructors (generated)
      ODBCCheckpointTotalsVisitor();

    //## Destructor (generated)
      virtual ~ODBCCheckpointTotalsVisitor();


    //## Other Operations (specified)
      //## Operation: visitAccumulator%40E30B8600AB
      virtual void visitAccumulator (Accumulator* pAccumulator);

      //## Operation: visitEntityGroup%40E30B8600BB
      virtual void visitEntityGroup (settlement::EntityGroup* pEntityGroup);

      //## Operation: visitRecoveryPoint%40E30B8600CB
      virtual void visitRecoveryPoint (settlement::RecoveryPoint* pRecoveryPoint);

      //## Operation: visitReportingEntity%40E30B8600EA
      virtual void visitReportingEntity (settlement::ReportingEntity* pReportingEntity);

      //## Operation: visitReportingPeriod%40E30B8600FA
      virtual void visitReportingPeriod (settlement::ReportingPeriod* pReportingPeriod);

      //## Operation: visitTotal%40E30B860109
      virtual void visitTotal (settlement::Total* pTotal);

      //## Operation: visitTotalsCategory%40E30B860119
      virtual void visitTotalsCategory (settlement::TotalsCategory* pTotalsCategory);

    // Additional Public Declarations
      //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.public preserve=yes
      //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.public

  protected:
    // Additional Protected Declarations
      //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.protected preserve=yes
      //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.protected

  private:

    //## Other Operations (specified)
      //## Operation: diagnoseResult%41B7176D0119
      string diagnoseResult (int lInfoIDNumber);

    // Additional Private Declarations
      //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.private preserve=yes
      //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::DNODBCDatabase_CAT::<unnamed>%46C1F9C4032C
      //## Role: ODBCCheckpointTotalsVisitor::<m_pInsertStatement>%46C1F9C502AF
      //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor::<m_pInsertStatement>%46C1F9C502AF.role preserve=no  public: reusable::Statement { -> RFHgN}
      reusable::Statement *m_pInsertStatement;
      //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor::<m_pInsertStatement>%46C1F9C502AF.role

      //## Association: DataNavigator Foundation::DNODBCDatabase_CAT::<unnamed>%46C1F9DE003E
      //## Role: ODBCCheckpointTotalsVisitor::<m_pUpdateStatement>%46C1F9DE035B
      //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor::<m_pUpdateStatement>%46C1F9DE035B.role preserve=no  public: reusable::Statement { -> RFHgN}
      reusable::Statement *m_pUpdateStatement;
      //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor::<m_pUpdateStatement>%46C1F9DE035B.role

    // Additional Implementation Declarations
      //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.implementation preserve=yes
      //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.implementation

};

//## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.postscript preserve=yes
//## end dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.postscript

} // namespace dnodbcdatabase

//## begin module%40E308FB01A5.epilog preserve=yes
//## end module%40E308FB01A5.epilog


#endif
