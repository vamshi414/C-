//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%654542BB006D.cm preserve=no
//## end module%654542BB006D.cm

//## begin module%654542BB006D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%654542BB006D.cp

//## Module: CXOSDQ15%654542BB006D; Package specification
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Dqdll\CXODDQ15.hpp

#ifndef CXOSDQ15_h
#define CXOSDQ15_h 1

//## begin module%654542BB006D.additionalIncludes preserve=no
//## end module%654542BB006D.additionalIncludes

//## begin module%654542BB006D.includes preserve=yes
//## end module%654542BB006D.includes

#ifndef CXOSST34_h
#include "CXODST34.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class RulesMediator;
} // namespace settlement

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
} // namespace segment

namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%654542BB006D.declarations preserve=no
//## end module%654542BB006D.declarations

//## begin module%654542BB006D.additionalDeclarations preserve=yes
//## end module%654542BB006D.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

//## begin dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.preface preserve=yes
//## end dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.preface

//## Class: ODBCAggregatorMIS2%65454592010F
//## Category: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
//## Subsystem: DQDLL%40852BF400DA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%65454816015E;database::Database { -> F}
//## Uses: <unnamed>%6545481A023B;monitor::UseCase { -> F}
//## Uses: <unnamed>%6545483F030F;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%654548430240;reusable::Table { -> F}
//## Uses: <unnamed>%654548540271;reusable::Statement { -> F}
//## Uses: <unnamed>%6545486101AF;IF::Trace { -> F}
//## Uses: <unnamed>%65454874027F;segment::InformationSegment { -> F}
//## Uses: <unnamed>%65454C9500DB;settlement::RulesMediator { -> F}

class DllExport ODBCAggregatorMIS2 : public settlement::AggregatorMIS  //## Inherits: <unnamed>%654545CB020A
{
  //## begin dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.initialDeclarations preserve=yes
  //## end dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.initialDeclarations

  public:
    //## Constructors (generated)
      ODBCAggregatorMIS2();

    //## Destructor (generated)
      virtual ~ODBCAggregatorMIS2();


    //## Other Operations (specified)
      //## Operation: commit%6545461F01B1
      virtual bool commit ();

      //## Operation: tableInsert%65454BFA0321
      virtual bool tableInsert (bool bSubtractFromTotals = false);

      //## Operation: tableUpdate%65454BFA0324
      virtual int tableUpdate (bool bSubtractFromTotals = false);

    // Additional Public Declarations
      //## begin dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.public preserve=yes
      //## end dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.public

  protected:
    // Additional Protected Declarations
      //## begin dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.protected preserve=yes
      //## end dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.protected

  private:
    // Additional Private Declarations
      //## begin dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.private preserve=yes
      //## end dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Transaction%654547D80328
      //## begin dnodbcdatabase::ODBCAggregatorMIS2::Transaction%654547D80328.attr preserve=no  private: long {U} 
      long m_iTransaction;
      //## end dnodbcdatabase::ODBCAggregatorMIS2::Transaction%654547D80328.attr

    // Additional Implementation Declarations
      //## begin dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.implementation preserve=yes
      reusable::Table m_hTable;
      //## end dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.implementation
};

//## begin dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.postscript preserve=yes
//## end dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.postscript

} // namespace dnodbcdatabase

//## begin module%654542BB006D.epilog preserve=yes
//## end module%654542BB006D.epilog


#endif
