//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E309E50222.cm preserve=no
//	$Date:   Aug 26 2009 15:39:24  $ $Author:   D02405  $
//	$Revision:   1.7  $
//## end module%40E309E50222.cm

//## begin module%40E309E50222.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%40E309E50222.cp

//## Module: CXOSDQ13%40E309E50222; Package specification
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXODDQ13.hpp

#ifndef CXOSDQ13_h
#define CXOSDQ13_h 1

//## begin module%40E309E50222.additionalIncludes preserve=no
//## end module%40E309E50222.additionalIncludes

//## begin module%40E309E50222.includes preserve=yes
// $Date:   Aug 26 2009 15:39:24  $ $Author:   D02405  $ $Revision:   1.7  $
//## end module%40E309E50222.includes

#ifndef CXOSST34_h
#include "CXODST34.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class Accumulator;
class FinancialTransaction;
} // namespace settlement

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
} // namespace segment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace database {
class Database;

} // namespace database

//## begin module%40E309E50222.declarations preserve=no
//## end module%40E309E50222.declarations

//## begin module%40E309E50222.additionalDeclarations preserve=yes
//## end module%40E309E50222.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

//## begin dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.preface preserve=yes
//## end dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.preface

//## Class: ODBCAggregatorMIS%40E307AA0119
//## Category: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
//## Subsystem: DQDLL%40852BF400DA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40E30C6B01F4;database::Database { -> F}
//## Uses: <unnamed>%40E30C6E0128;monitor::UseCase { -> F}
//## Uses: <unnamed>%40E30C7B01C5;settlement::FinancialTransaction { -> F}
//## Uses: <unnamed>%40E30C7D030D;settlement::Accumulator { -> F}
//## Uses: <unnamed>%41012B0A0000;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%41012B0C0196;reusable::Statement { -> F}
//## Uses: <unnamed>%41012B110271;reusable::Table { -> F}
//## Uses: <unnamed>%410131F2036B;IF::Trace { -> F}
//## Uses: <unnamed>%42D666420261;segment::InformationSegment { -> F}

class DllExport ODBCAggregatorMIS : public settlement::AggregatorMIS  //## Inherits: <unnamed>%40E30C68001F
{
  //## begin dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.initialDeclarations preserve=yes
  //## end dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.initialDeclarations

  public:
    //## Constructors (generated)
      ODBCAggregatorMIS();

    //## Destructor (generated)
      virtual ~ODBCAggregatorMIS();


    //## Other Operations (specified)
      //## Operation: tableInsert%40E30CB0000F
      virtual bool tableInsert (bool bSubtractFromTotals = false);

      //## Operation: tableUpdate%40E30CB0001F
      virtual int tableUpdate (bool bSubtractFromTotals = false);

    // Additional Public Declarations
      //## begin dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.public preserve=yes
      //## end dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.public

  protected:
    // Additional Protected Declarations
      //## begin dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.protected preserve=yes
      //## end dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.protected

  private:
    // Additional Private Declarations
      //## begin dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.private preserve=yes
      //## end dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.implementation preserve=yes
      //## end dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.implementation

};

//## begin dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.postscript preserve=yes
//## end dnodbcdatabase::ODBCAggregatorMIS%40E307AA0119.postscript

} // namespace dnodbcdatabase

//## begin module%40E309E50222.epilog preserve=yes
using namespace dnodbcdatabase;
//## end module%40E309E50222.epilog


#endif
