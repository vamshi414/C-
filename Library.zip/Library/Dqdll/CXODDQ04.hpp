//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%40E303C70186.cm preserve=no
//	$Date:   Jul 22 2019 15:19:58  $ $Author:   e1009839  $
//	$Revision:   1.16  $
//## end module%40E303C70186.cm

//## begin module%40E303C70186.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%40E303C70186.cp

//## Module: CXOSDQ04%40E303C70186; Package specification
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXODDQ04.hpp

#ifndef CXOSDQ04_h
#define CXOSDQ04_h 1

//## begin module%40E303C70186.additionalIncludes preserve=no
//## end module%40E303C70186.additionalIncludes

//## begin module%40E303C70186.includes preserve=yes
#include "CXODRU06.hpp"
//## end module%40E303C70186.includes

#ifndef CXOSRC01_h
#include "CXODRC01.hpp"
#endif

//## Modelname: DataNavigator Foundation::Partition_CAT%346B9162029B
namespace partition {
class PartitionControl;
} // namespace partition

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialBaseSegment;
class FinancialSettlementSegment;
class FinancialReversalSegment;
class FinancialFeeSegment;
class FinancialAdjustmentSegment;
class FinancialUserSegment;
class FinancialAdjustmentExtensionSegment;
class MultipleRouteSegment;
class FraudBlockSegment;
class IntegratedCircuitCardSegment;
} // namespace repositorysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
class InsertSequenceNumber;
class UniquenessKey;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ListSegment;

} // namespace segment

//## begin module%40E303C70186.declarations preserve=no
//## end module%40E303C70186.declarations

//## begin module%40E303C70186.additionalDeclarations preserve=yes
//## end module%40E303C70186.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

//## begin dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.preface preserve=yes
//## end dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.preface

//## Class: ODBCAddFinancialCommand%40E30434001F
//## Category: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
//## Subsystem: DQDLL%40852BF400DA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40E30DF70251;database::Database { -> F}
//## Uses: <unnamed>%40E30DFA0148;partition::PartitionControl { -> F}
//## Uses: <unnamed>%40E30DFF0222;timer::Clock { -> F}
//## Uses: <unnamed>%40E30E01037A;IF::Trace { -> F}
//## Uses: <unnamed>%40E30E0401D4;monitor::UseCase { -> F}
//## Uses: <unnamed>%40E30E09032C;IF::Extract { -> F}
//## Uses: <unnamed>%40E30E0B037A;repositorysegment::FinancialFeeSegment { -> F}
//## Uses: <unnamed>%40E30E0E0280;repositorysegment::FinancialAdjustmentSegment { -> F}
//## Uses: <unnamed>%40E30E1B03B9;repositorysegment::FinancialAdjustmentExtensionSegment { -> F}
//## Uses: <unnamed>%40E30E1E009C;repositorysegment::FinancialUserSegment { -> F}
//## Uses: <unnamed>%40E30E2602BF;repositorysegment::FinancialReversalSegment { -> F}
//## Uses: <unnamed>%40E30E28031C;repositorysegment::FinancialSettlementSegment { -> F}
//## Uses: <unnamed>%40E30E2B01C5;repositorysegment::FinancialBaseSegment { -> F}
//## Uses: <unnamed>%40FFF6A5008C;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%40FFF7140290;reusable::Query { -> F}
//## Uses: <unnamed>%40FFF8700148;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%40FFF8A30280;segment::ListSegment { -> F}
//## Uses: <unnamed>%40FFFD7101D4;database::InsertSequenceNumber { -> F}
//## Uses: <unnamed>%464938BB02CF;repositorysegment::IntegratedCircuitCardSegment { -> F}
//## Uses: <unnamed>%4C0CDCF20363;repositorysegment::FraudBlockSegment { -> F}
//## Uses: <unnamed>%5182713502F2;repositorysegment::MultipleRouteSegment { -> F}
//## Uses: <unnamed>%546B75DC0270;database::UniquenessKey { -> F}

class DllExport ODBCAddFinancialCommand : public repositorycommand::AddFinancialCommand  //## Inherits: <unnamed>%40E30DED0242
{
  //## begin dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.initialDeclarations preserve=yes
  enum TableName
  {
     FIN_L,
     FIN_ICC,
     FIN_ROUTE,
     FIN_FRAUD_RULE,
     FIN_RECORD
  };
  //## end dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.initialDeclarations

  public:
    //## Constructors (generated)
      ODBCAddFinancialCommand();

    //## Destructor (generated)
      virtual ~ODBCAddFinancialCommand();


    //## Other Operations (specified)
      //## Operation: execute%40E30EF60232
      //	Perform the functions of this command.
      virtual bool execute ();

    // Additional Public Declarations
      //## begin dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.public preserve=yes
      //## end dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.public

  protected:
    // Additional Protected Declarations
      //## begin dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.protected preserve=yes
      //## end dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.protected

  private:

    //## Other Operations (specified)
      //## Operation: insertRecord%40FEBC740157
      int insertRecord ();

      //## Operation: selectRecord%40FEBC490109
      bool selectRecord ();

      //## Operation: updateRecord%40FEBC670399
      bool updateRecord ();

    // Additional Private Declarations
      //## begin dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.private preserve=yes
      //## end dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ACCT_ID_1%467C1B8A0167
      //## begin dnodbcdatabase::ODBCAddFinancialCommand::ACCT_ID_1%467C1B8A0167.attr preserve=no  private: char[29] {U}
      char m_pzACCT_ID_1[29];
      //## end dnodbcdatabase::ODBCAddFinancialCommand::ACCT_ID_1%467C1B8A0167.attr

      //## Attribute: FIN_INSERT_SEQUENCE_NO%40FFFC1902CE
      //## begin dnodbcdatabase::ODBCAddFinancialCommand::FIN_INSERT_SEQUENCE_NO%40FFFC1902CE.attr preserve=no  private: int {U} 0
      int m_lFIN_INSERT_SEQUENCE_NO;
      //## end dnodbcdatabase::ODBCAddFinancialCommand::FIN_INSERT_SEQUENCE_NO%40FFFC1902CE.attr

      //## Attribute: FIN_PARTITION_KEY%40FFC7B703A9
      //## begin dnodbcdatabase::ODBCAddFinancialCommand::FIN_PARTITION_KEY%40FFC7B703A9.attr preserve=no  private: short int {U}
      short int m_lFIN_PARTITION_KEY;
      //## end dnodbcdatabase::ODBCAddFinancialCommand::FIN_PARTITION_KEY%40FFC7B703A9.attr

      //## Attribute: FIN_TYPE%40FFC9B10261
      //## begin dnodbcdatabase::ODBCAddFinancialCommand::FIN_TYPE%40FFC9B10261.attr preserve=no  private: char[4] {U}
      char m_pzFIN_TYPE[4];
      //## end dnodbcdatabase::ODBCAddFinancialCommand::FIN_TYPE%40FFC9B10261.attr

      //## Attribute: TSTAMP_TRANS%40FFF1BA01B5
      //## begin dnodbcdatabase::ODBCAddFinancialCommand::TSTAMP_TRANS%40FFF1BA01B5.attr preserve=no  private: string {U}
      string m_strTSTAMP_TRANS;
      //## end dnodbcdatabase::ODBCAddFinancialCommand::TSTAMP_TRANS%40FFF1BA01B5.attr

      //## Attribute: UNIQUENESS_KEY%40FFC65003B9
      //## begin dnodbcdatabase::ODBCAddFinancialCommand::UNIQUENESS_KEY%40FFC65003B9.attr preserve=no  private: short int {U}
      short int m_lUNIQUENESS_KEY;
      //## end dnodbcdatabase::ODBCAddFinancialCommand::UNIQUENESS_KEY%40FFC65003B9.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::DNODBCDatabase_CAT::<unnamed>%517E9B3101B3
      //## Role: ODBCAddFinancialCommand::<m_hTable>%517E9B32012A
      //## begin dnodbcdatabase::ODBCAddFinancialCommand::<m_hTable>%517E9B32012A.role preserve=no  public: reusable::Table { -> 5VFHgN}
      reusable::Table m_hTable[5];
      //## end dnodbcdatabase::ODBCAddFinancialCommand::<m_hTable>%517E9B32012A.role

      //## Association: DataNavigator Foundation::DNODBCDatabase_CAT::<unnamed>%517E9B62012A
      //## Role: ODBCAddFinancialCommand::<m_pInsertStatement>%517E9B630242
      //## begin dnodbcdatabase::ODBCAddFinancialCommand::<m_pInsertStatement>%517E9B630242.role preserve=no  public: reusable::Statement { -> 3RFHgN}
      reusable::Statement *m_pInsertStatement[3];
      //## end dnodbcdatabase::ODBCAddFinancialCommand::<m_pInsertStatement>%517E9B630242.role

      //## Association: DataNavigator Foundation::DNODBCDatabase_CAT::<unnamed>%517E9B7A009E
      //## Role: ODBCAddFinancialCommand::<m_pUpdateStatement>%517E9B7B000E
      //## begin dnodbcdatabase::ODBCAddFinancialCommand::<m_pUpdateStatement>%517E9B7B000E.role preserve=no  public: reusable::Statement { -> RFHgN}
      reusable::Statement *m_pUpdateStatement;
      //## end dnodbcdatabase::ODBCAddFinancialCommand::<m_pUpdateStatement>%517E9B7B000E.role

    // Additional Implementation Declarations
      //## begin dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.implementation preserve=yes
      string m_strCodeLevel;
      //## end dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.implementation

};

//## begin dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.postscript preserve=yes
//## end dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.postscript

} // namespace dnodbcdatabase

//## begin module%40E303C70186.epilog preserve=yes
//## end module%40E303C70186.epilog


#endif
