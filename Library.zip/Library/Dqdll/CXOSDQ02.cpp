//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E412A5029F.cm preserve=no
//	$Date:   Apr 06 2006 14:35:30  $ $Author:   D02405  $
//	$Revision:   1.5  $
//## end module%40E412A5029F.cm

//## begin module%40E412A5029F.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%40E412A5029F.cp

//## Module: CXOSDQ02%40E412A5029F; Package body
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXOSDQ02.cpp

//## begin module%40E412A5029F.additionalIncludes preserve=no
//## end module%40E412A5029F.additionalIncludes

//## begin module%40E412A5029F.includes preserve=yes
//## end module%40E412A5029F.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSDB10_h
#include "CXODDB10.hpp"
#endif
#ifndef CXOSDQ02_h
#include "CXODDQ02.hpp"
#endif


//## begin module%40E412A5029F.declarations preserve=no
//## end module%40E412A5029F.declarations

//## begin module%40E412A5029F.additionalDeclarations preserve=yes
//## end module%40E412A5029F.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

// Class dnodbcdatabase::ODBCLocator 

ODBCLocator::ODBCLocator()
  //## begin ODBCLocator::ODBCLocator%40E2FB9C03B9_const.hasinit preserve=no
  //## end ODBCLocator::ODBCLocator%40E2FB9C03B9_const.hasinit
  //## begin ODBCLocator::ODBCLocator%40E2FB9C03B9_const.initialization preserve=yes
  //## end ODBCLocator::ODBCLocator%40E2FB9C03B9_const.initialization
{
  //## begin dnodbcdatabase::ODBCLocator::ODBCLocator%40E2FB9C03B9_const.body preserve=yes
   memcpy(m_sID,"DQ02",4);
  //## end dnodbcdatabase::ODBCLocator::ODBCLocator%40E2FB9C03B9_const.body
}


ODBCLocator::~ODBCLocator()
{
  //## begin dnodbcdatabase::ODBCLocator::~ODBCLocator%40E2FB9C03B9_dest.body preserve=yes
  //## end dnodbcdatabase::ODBCLocator::~ODBCLocator%40E2FB9C03B9_dest.body
}



//## Other Operations (implementation)
bool ODBCLocator::synchronize ()
{
  //## begin dnodbcdatabase::ODBCLocator::synchronize%40E2FC5801B5.body preserve=yes
   //CriticalSection hCriticalSection("CATALOG");
   m_lCount = 0;
   string strName(m_strTableName);
   strName += '%';
   auto_ptr<DatabaseCatalog> pDatabaseCatalog((DatabaseCatalog*)DatabaseFactory::instance()->create("DatabaseCatalog"));
   if(!pDatabaseCatalog->getTable(strName,"MIN",m_strMinName))
      return false;
   
   if(!pDatabaseCatalog->getTable(strName,"MAX",m_strMaxName))
      return false;

   m_lCount = pDatabaseCatalog->getTableCount(strName);

   return archive::Locator::synchronize();
  //## end dnodbcdatabase::ODBCLocator::synchronize%40E2FC5801B5.body
}

// Additional Declarations
  //## begin dnodbcdatabase::ODBCLocator%40E2FB9C03B9.declarations preserve=yes
  //## end dnodbcdatabase::ODBCLocator%40E2FB9C03B9.declarations

} // namespace dnodbcdatabase

//## begin module%40E412A5029F.epilog preserve=yes
//## end module%40E412A5029F.epilog
