//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E305CF00BB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40E305CF00BB.cm

//## begin module%40E305CF00BB.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40E305CF00BB.cp

//## Module: CXOSDQ08%40E305CF00BB; Package specification
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXODDQ08.hpp

#ifndef CXOSDQ08_h
#define CXOSDQ08_h 1

//## begin module%40E305CF00BB.additionalIncludes preserve=no
//## end module%40E305CF00BB.additionalIncludes

//## begin module%40E305CF00BB.includes preserve=yes
//## end module%40E305CF00BB.includes

#ifndef CXOSPC05_h
#include "CXODPC05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CriticalSection;
class Statement;
class SelectStatement;
class Query;
class FormatSelectVisitor;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DateTime;
class Trace;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::ODBCDatabase_CAT%4085256E03A9
namespace odbcdatabase {
class ODBCDatabase;

} // namespace odbcdatabase

//## begin module%40E305CF00BB.declarations preserve=no
//## end module%40E305CF00BB.declarations

//## begin module%40E305CF00BB.additionalDeclarations preserve=yes
//## end module%40E305CF00BB.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

//## begin dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.preface preserve=yes
//## end dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.preface

//## Class: ODBCPartitionDeallocator%40E3018D029F
//## Category: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
//## Subsystem: DQDLL%40852BF400DA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%41192B07030D;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%41192B0C02AF;monitor::UseCase { -> F}
//## Uses: <unnamed>%41192B0E033C;IF::DateTime { -> F}
//## Uses: <unnamed>%41192B10037A;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%41192B130157;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%41192B17000F;reusable::Query { -> F}
//## Uses: <unnamed>%41192B390280;reusable::FormatSelectVisitor { -> F}
//## Uses: <unnamed>%41192B630261;odbcdatabase::ODBCDatabase { -> F}
//## Uses: <unnamed>%41192B670232;reusable::Statement { -> F}
//## Uses: <unnamed>%41192B8E00CB;IF::Extract { -> F}
//## Uses: <unnamed>%41192BA202EE;IF::Trace { -> F}

class DllExport ODBCPartitionDeallocator : public partition::PartitionDeallocator  //## Inherits: <unnamed>%40E302EE007D
{
  //## begin dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.initialDeclarations preserve=yes
   enum State
   {
      START,
      SELECT,
      SUCCESS,
      DEADLOCK_TIMEOUT,
      DATABASE_FAILURE,
      DATABASE_CONNECTION_ERROR
   };
  //## end dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.initialDeclarations

  public:
    //## Constructors (generated)
      ODBCPartitionDeallocator();

    //## Destructor (generated)
      virtual ~ODBCPartitionDeallocator();


    //## Other Operations (specified)
      //## Operation: available%40E303140399
      //	Return the number of available partitions for an STS
      //	table.
      //## Semantics:
      //	1. SELECT
      //	        PARTITIONS
      //	        FROM SYSIBM.SYSTABLES TA,
      //	            SYSIBM.SYSTABLESPACE TS
      //	         WHERE TA.DBNAME =
      //	Database::instance()->qualifier()
      //	            AND TS.DBNAME =
      //	Database::instance()->qualifier()
      //	            AND TA.NAME = m_strTableName
      //	            AND TS.NAME = TA.TSNAME.
      //	2. SELECT
      //	        COUNT(*)
      //	        FROM PARTITION_CONTROL
      //	        WHERE TABLE_NAME = m_strTableName
      //	            AND PART_STAT NOT = 'R'.
      //	3. *piPartitionCount = result1 - result2.
      //	4. Return true if successful; else false.
      virtual bool available (int* piPartitionCount);

      //## Operation: deallocate%40E30314039B
      //	Deallocate a partition for a table in the STS repository.
      //## Semantics:
      //	1. UPDATE PARTITION_CONTROL SET
      //	        PART_STAT = 'R',
      //	        TSTAMP_START = ' ',
      //	        TSTAMP_END = ' ',
      //	        TSTAMP_UPDATE = current timestamp,
      //	        WHERE
      //	            TABLE_NAME = m_strTableName
      //	            AND PART_NUMBER = iPartitionNumber
      //	            AND PART_STAT = 'C'. /* Mark : who is
      //	setting this in 1.8 ? */
      //	2. Call SharedResource::notify.
      //	2. Return true if successful; else false.
      virtual bool deallocate (int iPartitionNumber);

      //## Operation: oldest%40E3031403C8
      //	Return the starting timestamp, ending timestamp, and
      //	partition number of the oldest partition for a table in
      //	the STS repository.
      //## Semantics:
      //	1. SELECT TSTAMP_START, TSTAMP_END, PART_NUMBER
      //	        FROM PARTITION_CONTROL
      //	        WHERE TSTAMP_END =
      //	            (SELECT MIN(TSTAMP_END)
      //	                FROM PARTITION_CONTROL
      //	                WHERE TABLE_NAME = m_strTableName.
      //	2. Return true if successful; else false.
      virtual bool oldest (IString& strTimestampStart, IString& strTimestampEnd, int* piPartitionNumber);

    // Additional Public Declarations
      //## begin dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.public preserve=yes
      //## end dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.public

  protected:
    // Additional Protected Declarations
      //## begin dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.protected preserve=yes
      //## end dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.protected

  private:

    //## Other Operations (specified)
      //## Operation: selectCatalog%40E3031403D8
      ODBCPartitionDeallocator::State selectCatalog ();

      //## Operation: selectCount%40E303150000
      ODBCPartitionDeallocator::State selectCount ();

      //## Operation: selectOldest%40E303150001
      ODBCPartitionDeallocator::State selectOldest ();

      //## Operation: update%40E30315000F
      ODBCPartitionDeallocator::State update ();

    // Additional Private Declarations
      //## begin dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.private preserve=yes
      //## end dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: State%40E30303008C
      //## begin dnodbcdatabase::ODBCPartitionDeallocator::State%40E30303008C.attr preserve=no  private: State {V} 
      State m_nState;
      //## end dnodbcdatabase::ODBCPartitionDeallocator::State%40E30303008C.attr

    // Additional Implementation Declarations
      //## begin dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.implementation preserve=yes
      char        m_pszPD_TABLE_NAME[19];
      short int   m_siPD_PART_NUMBER;
      char        m_pszPD_PART_STATUS[2];
      char        m_pszPD_TSTAMP_START[17];
      char        m_pszPD_TSTAMP_END[17];
      char        m_pszPD_TSTAMP_UPDATE[17];
      short int   m_siPD_PARTITIONS;
      char        m_pszPD_QUALIFIER[9];
      char        m_pszPD_DBNAME[9];
      short       m_sPD_INDICATOR;
      //## end dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.implementation
};

//## begin dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.postscript preserve=yes
//## end dnodbcdatabase::ODBCPartitionDeallocator%40E3018D029F.postscript

} // namespace dnodbcdatabase

//## begin module%40E305CF00BB.epilog preserve=yes
//## end module%40E305CF00BB.epilog


#endif
