//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E30A3B0186.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40E30A3B0186.cm

//## begin module%40E30A3B0186.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40E30A3B0186.cp

//## Module: CXOSDQ14%40E30A3B0186; Package specification
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXODDQ14.hpp

#ifndef CXOSDQ14_h
#define CXOSDQ14_h 1

//## begin module%40E30A3B0186.additionalIncludes preserve=no
//## end module%40E30A3B0186.additionalIncludes

//## begin module%40E30A3B0186.includes preserve=yes
//## end module%40E30A3B0186.includes

#ifndef CXOSDB03_h
#include "CXODDB03.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class SiteSpecification;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;

} // namespace timer

//## begin module%40E30A3B0186.declarations preserve=no
//## end module%40E30A3B0186.declarations

//## begin module%40E30A3B0186.additionalDeclarations preserve=yes
//## end module%40E30A3B0186.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

//## begin dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.preface preserve=yes
//## end dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.preface

//## Class: ODBCMaintenanceProcedure%40E307CB003E
//## Category: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
//## Subsystem: DQDLL%40852BF400DA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40E30CDB038A;IF::SiteSpecification { -> F}
//## Uses: <unnamed>%40E30CDE008C;timer::Date { -> F}

class DllExport ODBCMaintenanceProcedure : public database::MaintenanceProcedure  //## Inherits: <unnamed>%40E30CD9035B
{
  //## begin dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.initialDeclarations preserve=yes
  //## end dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.initialDeclarations

  public:
    //## Constructors (generated)
      ODBCMaintenanceProcedure();

    //## Destructor (generated)
      virtual ~ODBCMaintenanceProcedure();


    //## Other Operations (specified)
      //## Operation: review%40E30D16035B
      virtual void review (const char* pszText);

    // Additional Public Declarations
      //## begin dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.public preserve=yes
      //## end dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.public

  protected:
    // Additional Protected Declarations
      //## begin dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.protected preserve=yes
      //## end dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.protected

  private:
    // Additional Private Declarations
      //## begin dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.private preserve=yes
      //## end dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: FreePages%40E30D01002E
      //## begin dnodbcdatabase::ODBCMaintenanceProcedure::FreePages%40E30D01002E.attr preserve=no  private: int {V} 0
      int m_lFreePages;
      //## end dnodbcdatabase::ODBCMaintenanceProcedure::FreePages%40E30D01002E.attr

      //## Attribute: Name%40E30D01003E
      //## begin dnodbcdatabase::ODBCMaintenanceProcedure::Name%40E30D01003E.attr preserve=no  private: string {V} 
      string m_strName;
      //## end dnodbcdatabase::ODBCMaintenanceProcedure::Name%40E30D01003E.attr

      //## Attribute: TotalPages%40E30D01004E
      //## begin dnodbcdatabase::ODBCMaintenanceProcedure::TotalPages%40E30D01004E.attr preserve=no  private: int {V} 0
      int m_lTotalPages;
      //## end dnodbcdatabase::ODBCMaintenanceProcedure::TotalPages%40E30D01004E.attr

      //## Attribute: UsedPages%40E30D01005D
      //## begin dnodbcdatabase::ODBCMaintenanceProcedure::UsedPages%40E30D01005D.attr preserve=no  private: int {V} 0
      int m_lUsedPages;
      //## end dnodbcdatabase::ODBCMaintenanceProcedure::UsedPages%40E30D01005D.attr

    // Additional Implementation Declarations
      //## begin dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.implementation preserve=yes
      //## end dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.implementation

};

//## begin dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.postscript preserve=yes
//## end dnodbcdatabase::ODBCMaintenanceProcedure%40E307CB003E.postscript

} // namespace dnodbcdatabase

//## begin module%40E30A3B0186.epilog preserve=yes
//## end module%40E30A3B0186.epilog


#endif
