//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%654542BC03BE.cm preserve=no
//## end module%654542BC03BE.cm

//## begin module%654542BC03BE.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%654542BC03BE.cp

//## Module: CXOSDQ15%654542BC03BE; Package body
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Dqdll\CXOSDQ15.cpp

//## begin module%654542BC03BE.additionalIncludes preserve=no
//## end module%654542BC03BE.additionalIncludes

//## begin module%654542BC03BE.includes preserve=yes
//## end module%654542BC03BE.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSST08_h
#include "CXODST08.hpp"
#endif
#ifndef CXOSDQ15_h
#include "CXODDQ15.hpp"
#endif


//## begin module%654542BC03BE.declarations preserve=no
//## end module%654542BC03BE.declarations

//## begin module%654542BC03BE.additionalDeclarations preserve=yes
char AMS1_TSTAMP_START[512][11];
char AMS1_INTERVAL_TYPE[512][2];
int AMS1_T_FIN_ENTITY_ID[512];
char AMS1_T_MIS_MCC[512][5];
int AMS1_CATEGORY_ID[512];
int AMS1_PARTITION_KEY[512];
double AMS1_AMT_TRAN[512];
double AMS1_AMT_SURCHARGE[512];
double AMS1_AMT_POS_REIMBURSE[512];
double AMS1_CASHBACK_AMT[512];
int AMS1_TRAN_COUNT[512];
double AMS1_TIME_AT_ISS[512];
double AMS1_TIME_AT_RQST_SWTCH[512];
double AMS1_AMT_FEE[512];
int AMS1_SYNC_INTERVAL_NO[512];
char AMS1_BIN[512][12];
int AMS1_ROWS;
char AMS1_MERGE[2048];

char AMS2_TSTAMP_START[512][11];
char AMS2_INTERVAL_TYPE[512][2];
int AMS2_T_FIN_ENTITY_ID[512];
int AMS2_T_FIN_ENTITY_ID_2[512];
char AMS2_T_MIS_MCC[512][5];
int AMS2_CATEGORY_ID[512];
int AMS2_PARTITION_KEY[512];
double AMS2_AMT_TRAN[512];
double AMS2_AMT_SURCHARGE[512];
double AMS2_AMT_POS_REIMBURSE[512];
double AMS2_CASHBACK_AMT[512];
int AMS2_TRAN_COUNT[512];
double AMS2_TIME_AT_ISS[512];
double AMS2_TIME_AT_RQST_SWTCH[512];
double AMS2_AMT_FEE[512];
int AMS2_SYNC_INTERVAL_NO[512];
char AMS2_BIN[512][12];
int AMS2_ROWS;
char AMS2_MERGE[2048];
//## end module%654542BC03BE.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

// Class dnodbcdatabase::ODBCAggregatorMIS2 

ODBCAggregatorMIS2::ODBCAggregatorMIS2()
  //## begin ODBCAggregatorMIS2::ODBCAggregatorMIS2%65454592010F_const.hasinit preserve=no
  //## end ODBCAggregatorMIS2::ODBCAggregatorMIS2%65454592010F_const.hasinit
  //## begin ODBCAggregatorMIS2::ODBCAggregatorMIS2%65454592010F_const.initialization preserve=yes
   : m_iTransaction(-1)
  //## end ODBCAggregatorMIS2::ODBCAggregatorMIS2%65454592010F_const.initialization
{
  //## begin dnodbcdatabase::ODBCAggregatorMIS2::ODBCAggregatorMIS2%65454592010F_const.body preserve=yes
   memcpy(m_sID, "DQ15", 4);
   AMS1_ROWS = 0;
   AMS2_ROWS = 0;
   string strQualifier(Database::instance()->qualifier());
  //## end dnodbcdatabase::ODBCAggregatorMIS2::ODBCAggregatorMIS2%65454592010F_const.body
}


ODBCAggregatorMIS2::~ODBCAggregatorMIS2()
{
  //## begin dnodbcdatabase::ODBCAggregatorMIS2::~ODBCAggregatorMIS2%65454592010F_dest.body preserve=yes
  //## end dnodbcdatabase::ODBCAggregatorMIS2::~ODBCAggregatorMIS2%65454592010F_dest.body
}



//## Other Operations (implementation)
bool ODBCAggregatorMIS2::commit ()
{
  //## begin dnodbcdatabase::ODBCAggregatorMIS2::commit%6545461F01B1.body preserve=yes
   if (AMS1_ROWS > 0)
   {
      m_hTable.reset();
      m_hTable.setName("T_MIS_TOTAL");
      auto_ptr<Statement> pMergeStatement((Statement*)DatabaseFactory::instance()->create("MergeStatement"));
      for (int i = 0; i < AMS1_ROWS; i++)
      {
         m_hTable.set("TSTAMP_START", 11, AMS1_TSTAMP_START[i], false, true, false, 0, 11);
         m_hTable.set("INTERVAL_TYPE", 2, AMS1_INTERVAL_TYPE[i], false, true, false, 0, 2);
         m_hTable.set("T_FIN_ENTITY_ID", (int)AMS1_T_FIN_ENTITY_ID[i], true);
         m_hTable.set("T_MIS_MCC", 5, AMS1_T_MIS_MCC[i], false, true, false, 0, 5);
         m_hTable.set("CATEGORY_ID", (int)AMS1_CATEGORY_ID[i], true);
         m_hTable.set("PARTITION_KEY", (int)AMS1_PARTITION_KEY[i]);//need to remove
         m_hTable.set("AMT_TRAN", AMS1_AMT_TRAN[i], false, "+");
         m_hTable.set("AMT_SURCHARGE", AMS1_AMT_SURCHARGE[i], false, "+");
         m_hTable.set("AMT_POS_REIMBURSE", AMS1_AMT_POS_REIMBURSE[i], false, "+");
         m_hTable.set("CASHBACK_AMT", AMS1_CASHBACK_AMT[i], false, "+");
         m_hTable.set("TRAN_COUNT", AMS1_TRAN_COUNT[i], false, "+");
         m_hTable.set("TIME_AT_ISS", AMS1_TIME_AT_ISS[i], false, "+");
         m_hTable.set("TIME_AT_RQST_SWTCH", AMS1_TIME_AT_RQST_SWTCH[i], false, "+");
         m_hTable.set("AMT_FEE", AMS1_AMT_FEE[i], false, "+");
         m_hTable.set("SYNC_INTERVAL_NO", AMS1_SYNC_INTERVAL_NO[i], true);
         m_hTable.set("BIN", 12, AMS1_BIN[i], false, false, false, 0, 5);//need to remove from thing. 
         if (!pMergeStatement->execute(m_hTable))
         {
            return false;
         }
      }
      AMS1_ROWS = 0;
   }
   if (AMS2_ROWS > 0)
   {
      m_hTable.reset();
      m_hTable.setName("T_MIS_TOTAL");
      auto_ptr<Statement> pMergeStatement((Statement*)DatabaseFactory::instance()->create("MergeStatement"));
      for (int i = 0; i < AMS2_ROWS; i++)
      {
         m_hTable.set("TSTAMP_START", 11, AMS2_TSTAMP_START[i], false, true, false, 0, 11);//char
         m_hTable.set("INTERVAL_TYPE", 2, AMS2_INTERVAL_TYPE[i], false, true, false, 0, 2);//char
         m_hTable.set("T_FIN_ENTITY_ID", (int)AMS2_T_FIN_ENTITY_ID[i], true);
         m_hTable.set("T_MIS_MCC", 5, AMS2_T_MIS_MCC[i], false, true, false, 0, 5);//char
         m_hTable.set("CATEGORY_ID", (int)AMS2_CATEGORY_ID[i], true);
         m_hTable.set("PARTITION_KEY", (int)AMS2_PARTITION_KEY[i]);
         m_hTable.set("AMT_TRAN", AMS2_AMT_TRAN[i], false, "+");
         m_hTable.set("AMT_SURCHARGE", AMS2_AMT_SURCHARGE[i], false, "+");
         m_hTable.set("AMT_POS_REIMBURSE", AMS2_AMT_POS_REIMBURSE[i], false, "+");
         m_hTable.set("CASHBACK_AMT", AMS2_CASHBACK_AMT[i], false, "+");
         m_hTable.set("TRAN_COUNT", AMS2_TRAN_COUNT[i], false, "+");
         m_hTable.set("TIME_AT_ISS", AMS2_TIME_AT_ISS[i], false, "+");
         m_hTable.set("TIME_AT_RQST_SWTCH", AMS2_TIME_AT_RQST_SWTCH[i], false, "+");
         m_hTable.set("AMT_FEE", AMS2_AMT_FEE[i], false, "+");
         m_hTable.set("SYNC_INTERVAL_NO", AMS2_SYNC_INTERVAL_NO[i], true);
         m_hTable.set("BIN", 12, AMS2_BIN[i], false, false, false, 0, 5);//char
         if (!pMergeStatement->execute(m_hTable))
         {
            return false;
         }
      }
      AMS1_ROWS = 0;
   }
   Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   return true;
  //## end dnodbcdatabase::ODBCAggregatorMIS2::commit%6545461F01B1.body
}

bool ODBCAggregatorMIS2::tableInsert (bool bSubtractFromTotals)
{
  //## begin dnodbcdatabase::ODBCAggregatorMIS2::tableInsert%65454BFA0321.body preserve=yes
   return true;
  //## end dnodbcdatabase::ODBCAggregatorMIS2::tableInsert%65454BFA0321.body
}

int ODBCAggregatorMIS2::tableUpdate (bool bSubtractFromTotals)
{
  //## begin dnodbcdatabase::ODBCAggregatorMIS2::tableUpdate%65454BFA0324.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return -1;
   char szSpace[2] = { " " };
   if (getENTITY_ID(1) == "~NULL!")
   {
      if (AMS1_ROWS >= 1)
         if (!commit())
            return -1;
      if (!getTSTAMP_START().empty())
      {
         memcpy(AMS1_TSTAMP_START[AMS1_ROWS], getTSTAMP_START().data(), getTSTAMP_START().length());
         AMS1_TSTAMP_START[AMS1_ROWS][getTSTAMP_START().length()] = '\0';
      }
      else
         memcpy(AMS1_TSTAMP_START[AMS1_ROWS], szSpace, 2);
      if (!getINTERVAL_TYPE().empty())
      {
         memcpy(AMS1_INTERVAL_TYPE[AMS1_ROWS], getINTERVAL_TYPE().data(), getINTERVAL_TYPE().length());
         AMS1_INTERVAL_TYPE[AMS1_ROWS][getINTERVAL_TYPE().length()] = '\0';
      }
      else
         memcpy(AMS1_INTERVAL_TYPE[AMS1_ROWS], szSpace, 2);
      if (!getBIN().empty())
      {
         memcpy(AMS1_BIN[AMS1_ROWS], getBIN().data(), getBIN().length());
         AMS1_BIN[AMS1_ROWS][getBIN().length()] = '\0';
      }
      else
         memcpy(AMS1_BIN[AMS1_ROWS], szSpace, 2);
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(0), getENTITY_ID(0), &AMS1_T_FIN_ENTITY_ID[AMS1_ROWS]);
      if (!getT_MIS_MCC().empty())
      {
         memcpy(AMS1_T_MIS_MCC[AMS1_ROWS], getT_MIS_MCC().data(), getT_MIS_MCC().length());
         AMS1_T_MIS_MCC[AMS1_ROWS][getT_MIS_MCC().length()] = '\0';
      }
      memcpy(AMS1_T_MIS_MCC[AMS1_ROWS], szSpace, 2);
      AMS1_SYNC_INTERVAL_NO[AMS1_ROWS] = getSYNC_INTERVAL_NO();
      AMS1_CATEGORY_ID[AMS1_ROWS] = getCATEGORY_ID();
      int iSign = (bSubtractFromTotals ? -1 : 1);
      AMS1_AMT_TRAN[AMS1_ROWS] = getAMT_TRAN() * iSign;
      AMS1_AMT_SURCHARGE[AMS1_ROWS] = getAMT_SURCHARGE() * iSign;
      AMS1_AMT_POS_REIMBURSE[AMS1_ROWS] = getAMT_POS_REIMBURSE() * iSign;
      AMS1_CASHBACK_AMT[AMS1_ROWS] = getCASHBACK_AMT() * iSign;
      AMS1_TRAN_COUNT[AMS1_ROWS] = iSign;
      AMS1_TIME_AT_ISS[AMS1_ROWS] = getTIME_AT_ISS() * iSign;
      AMS1_TIME_AT_RQST_SWTCH[AMS1_ROWS] = getTIME_AT_RQST_SWTCH() * iSign;
      AMS1_AMT_FEE[AMS1_ROWS] = getAMT_FEE() * iSign;
      AMS1_ROWS++;
   }
   else
   {
      if (AMS2_ROWS >= 5)
         if (!commit())
            return -1;
      if (!getTSTAMP_START().empty())
      {
         memcpy(AMS2_TSTAMP_START[AMS2_ROWS], getTSTAMP_START().data(), getTSTAMP_START().length());
         AMS2_TSTAMP_START[AMS2_ROWS][getTSTAMP_START().length()] = '\0';
      }
      else
         memcpy(AMS2_TSTAMP_START[AMS2_ROWS], szSpace, 2);
      if (!getINTERVAL_TYPE().empty())
      {
         memcpy(AMS2_INTERVAL_TYPE[AMS2_ROWS], getINTERVAL_TYPE().data(), getINTERVAL_TYPE().length());
         AMS2_INTERVAL_TYPE[AMS2_ROWS][getINTERVAL_TYPE().length()] = '\0';
      }
      else
         memcpy(AMS2_INTERVAL_TYPE[AMS2_ROWS], szSpace, 2);
      if (!getBIN().empty())
      {
         memcpy(AMS2_BIN[AMS2_ROWS], getBIN().data(), getBIN().length());
         AMS2_BIN[AMS2_ROWS][getBIN().length()] = '\0';
      }
      else
         memcpy(AMS2_BIN[AMS2_ROWS], szSpace, 2);
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(0), getENTITY_ID(0), &AMS2_T_FIN_ENTITY_ID[AMS2_ROWS]);
      RulesMediator::instance()->getT_FIN_ENTITY_ID(getENTITY_TYPE(1), getENTITY_ID(1), &AMS2_T_FIN_ENTITY_ID_2[AMS2_ROWS]);
      if (!getT_MIS_MCC().empty())
      {
         memcpy(AMS2_T_MIS_MCC[AMS2_ROWS], getT_MIS_MCC().data(), getT_MIS_MCC().length());
         AMS2_T_MIS_MCC[AMS2_ROWS][getT_MIS_MCC().length()] = '\0';
      }
      else
         memcpy(AMS2_T_MIS_MCC[AMS2_ROWS], szSpace, 2);
      AMS2_SYNC_INTERVAL_NO[AMS2_ROWS] = getSYNC_INTERVAL_NO();
      AMS2_CATEGORY_ID[AMS2_ROWS] = getCATEGORY_ID();
      int iSign = (bSubtractFromTotals ? -1 : 1);
      AMS2_AMT_TRAN[AMS2_ROWS] = getAMT_TRAN() * iSign;
      AMS2_AMT_SURCHARGE[AMS2_ROWS] = getAMT_SURCHARGE() * iSign;
      AMS2_AMT_POS_REIMBURSE[AMS2_ROWS] = getAMT_POS_REIMBURSE() * iSign;
      AMS2_CASHBACK_AMT[AMS2_ROWS] = getCASHBACK_AMT() * iSign;
      AMS2_TRAN_COUNT[AMS2_ROWS] = iSign;
      AMS2_TIME_AT_ISS[AMS2_ROWS] = getTIME_AT_ISS() * iSign;
      AMS2_TIME_AT_RQST_SWTCH[AMS2_ROWS] = getTIME_AT_RQST_SWTCH() * iSign;
      AMS2_AMT_FEE[AMS2_ROWS] = getAMT_FEE() * iSign;
      AMS2_ROWS++;
   }
   return 1;
  //## end dnodbcdatabase::ODBCAggregatorMIS2::tableUpdate%65454BFA0324.body
}

// Additional Declarations
  //## begin dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.declarations preserve=yes
  //## end dnodbcdatabase::ODBCAggregatorMIS2%65454592010F.declarations

} // namespace dnodbcdatabase

//## begin module%654542BC03BE.epilog preserve=yes
//## end module%654542BC03BE.epilog
