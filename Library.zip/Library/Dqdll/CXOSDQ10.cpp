//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E308FD0000.cm preserve=no
//	$Date:   Aug 19 2021 23:36:04  $ $Author:   e1014059  $
//	$Revision:   1.7.1.5  $
//## end module%40E308FD0000.cm

//## begin module%40E308FD0000.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%40E308FD0000.cp

//## Module: CXOSDQ10%40E308FD0000; Package body
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXOSDQ10.cpp

//## begin module%40E308FD0000.additionalIncludes preserve=no
//## end module%40E308FD0000.additionalIncludes

//## begin module%40E308FD0000.includes preserve=yes
//## end module%40E308FD0000.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSST12_h
#include "CXODST12.hpp"
#endif
#ifndef CXOSST04_h
#include "CXODST04.hpp"
#endif
#ifndef CXOSST09_h
#include "CXODST09.hpp"
#endif
#ifndef CXOSST11_h
#include "CXODST11.hpp"
#endif
#ifndef CXOSST10_h
#include "CXODST10.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSST14_h
#include "CXODST14.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSPQ02_h
#include "CXODPQ02.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDQ10_h
#include "CXODDQ10.hpp"
#endif


//## begin module%40E308FD0000.declarations preserve=no
//## end module%40E308FD0000.declarations

//## begin module%40E308FD0000.additionalDeclarations preserve=yes
#define STS_DEADLOCK_TIMEOUT 73
#define STS_RECORD_NOT_FOUND 14
#define STS_DUPLICATE_RECORD 35
#define STS_DATABASE_FAILURE 15
//## end module%40E308FD0000.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

// Class dnodbcdatabase::ODBCCheckpointTotalsVisitor

ODBCCheckpointTotalsVisitor::ODBCCheckpointTotalsVisitor()
  //## begin ODBCCheckpointTotalsVisitor::ODBCCheckpointTotalsVisitor%40E30728029F_const.hasinit preserve=no
  //## end ODBCCheckpointTotalsVisitor::ODBCCheckpointTotalsVisitor%40E30728029F_const.hasinit
  //## begin ODBCCheckpointTotalsVisitor::ODBCCheckpointTotalsVisitor%40E30728029F_const.initialization preserve=yes
  //## end ODBCCheckpointTotalsVisitor::ODBCCheckpointTotalsVisitor%40E30728029F_const.initialization
{
  //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor::ODBCCheckpointTotalsVisitor%40E30728029F_const.body preserve=yes
   memcpy(m_sID,"DQ10",4);
   m_pInsertStatement = (Statement*)DatabaseFactory::instance()->create("InsertStatement");
   m_pUpdateStatement = (Statement*)DatabaseFactory::instance()->create("UpdateStatement");
  //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor::ODBCCheckpointTotalsVisitor%40E30728029F_const.body
}


ODBCCheckpointTotalsVisitor::~ODBCCheckpointTotalsVisitor()
{
  //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor::~ODBCCheckpointTotalsVisitor%40E30728029F_dest.body preserve=yes
   delete m_pUpdateStatement;
   delete m_pInsertStatement;
  //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor::~ODBCCheckpointTotalsVisitor%40E30728029F_dest.body
}



//## Other Operations (implementation)
string ODBCCheckpointTotalsVisitor::diagnoseResult (int lInfoIDNumber)
{
  //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor::diagnoseResult%41B7176D0119.body preserve=yes
   string strMsgPart1("ODBCCheckpointTotalsVisitor encountered a");
   string strMsgPart2("while executing the following sql statement: ");
   string strInfoId;
   if (lInfoIDNumber == STS_DUPLICATE_RECORD)
      strInfoId = "Duplicate Record";
   else
   if (lInfoIDNumber == STS_DATABASE_FAILURE)
      strInfoId = "Database Failure";
   else
   if (lInfoIDNumber == STS_DEADLOCK_TIMEOUT)
      strInfoId = "Deadlock timeout";
   else
   if (lInfoIDNumber == STS_RECORD_NOT_FOUND)
      strInfoId = "Record Not Found";
   else
      strInfoId = "Unknown Error";
   char szTemp[512];
   int lLength = snprintf(szTemp,sizeof(szTemp),"%s,%s,%s",strMsgPart1.c_str(),strInfoId.c_str(),strMsgPart2.c_str());
   string strReturn(szTemp,lLength);
   return strReturn;
  //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor::diagnoseResult%41B7176D0119.body
}

void ODBCCheckpointTotalsVisitor::visitAccumulator (Accumulator* pAccumulator)
{
  //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitAccumulator%40E30B8600AB.body preserve=yes
   if (Database::instance()->getDormant())
      Database::instance()->connect();
  //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitAccumulator%40E30B8600AB.body
}

void ODBCCheckpointTotalsVisitor::visitEntityGroup (settlement::EntityGroup* pEntityGroup)
{
  //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitEntityGroup%40E30B8600BB.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   m_lENTITY_GROUP_ID = pEntityGroup->getENTITY_GROUP_ID();
   Table hTable("T_FIN_ENTITY_GROUP");
   hTable.set("ENTITY_GROUP_ID",m_lENTITY_GROUP_ID);
   hTable.set("SYNC_INTERVAL_NO",pEntityGroup->getSYNC_INTERVAL_NO());
   if (!m_pInsertStatement->execute(hTable))
   {
      Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
      Database::instance()->traceSQLError(diagnoseResult(m_pInsertStatement->getInfoIDNumber()));
      char szTemp[128];
      Trace::put(szTemp,snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_ENTITY_GROUP %d %d",m_lENTITY_GROUP_ID,pEntityGroup->getSYNC_INTERVAL_NO()),true);
      return;
   }
   UseCase::addItem();
   int iSEQUENCE_NO = 0;
   for (iSEQUENCE_NO = 1;iSEQUENCE_NO <= 7;++iSEQUENCE_NO)
   {
      hTable.reset();
      hTable.setName("T_FIN_E_GROUP_ITEM");
      hTable.set("ENTITY_GROUP_ID",m_lENTITY_GROUP_ID);
      hTable.set("SEQUENCE_NO",iSEQUENCE_NO);
      hTable.set("PERIOD_ID",pEntityGroup->getPERIOD_ID(iSEQUENCE_NO));
      if (!m_pInsertStatement->execute(hTable))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError(diagnoseResult(m_pInsertStatement->getInfoIDNumber()));
         char szTemp[128];
         int lLength = snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_E_GROUP_ITEM %d %hd %d",m_lENTITY_GROUP_ID,iSEQUENCE_NO,pEntityGroup->getPERIOD_ID(iSEQUENCE_NO));
         Trace::put(szTemp,lLength,true);
         return;
      }
      UseCase::addItem();
   }
  //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitEntityGroup%40E30B8600BB.body
}

void ODBCCheckpointTotalsVisitor::visitRecoveryPoint (settlement::RecoveryPoint* pRecoveryPoint)
{
  //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitRecoveryPoint%40E30B8600CB.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   char szCTV_CONTEXT_KEY[33];
   memcpy(szCTV_CONTEXT_KEY,"LOAD ",5);
   memcpy(szCTV_CONTEXT_KEY + 5,pRecoveryPoint->getInterval().data(),pRecoveryPoint->getInterval().length());
   szCTV_CONTEXT_KEY[pRecoveryPoint->getInterval().length() + 5] = '\0';
   char szCTV_CONTEXT_DATA[101];
   snprintf(szCTV_CONTEXT_DATA,sizeof(szCTV_CONTEXT_DATA),"%d:%d",pRecoveryPoint->getStartTime(),pRecoveryPoint->getEndTime());
   string strCONTEXT_TYPE(" ");
   if (pRecoveryPoint->getState() == PersistentObject::NEW)
   {
      Table hTable("TASK_CONTEXT");
      hTable.set("IMAGEID", "I01/",false,true);
      hTable.set("TASKID",Application::instance()->name(),false,true);
      hTable.set("CONTEXT_TYPE",strCONTEXT_TYPE,false,true);
      hTable.set("CONTEXT_KEY",szCTV_CONTEXT_KEY,false,true);
      hTable.set("CONTEXT_DATA",szCTV_CONTEXT_DATA);
      if (!m_pInsertStatement->execute(hTable))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError(diagnoseResult(m_pInsertStatement->getInfoIDNumber()));
         char szTemp[512];
         int lLength = snprintf(szTemp,sizeof(szTemp),"INSERT TASK_CONTEXT %s %s %s %s %s",
            Application::instance()->image().c_str(),Application::instance()->name().c_str(),strCONTEXT_TYPE.c_str(),szCTV_CONTEXT_KEY,szCTV_CONTEXT_DATA);
         Trace::put(szTemp,lLength,true);
      }
      else
         UseCase::addItem();
   }
   else
   {
      Table hTable("TASK_CONTEXT");
      hTable.set("CONTEXT_DATA",szCTV_CONTEXT_DATA,false,false);
      hTable.set("IMAGEID", "I01/",false,true);
      hTable.set("TASKID",Application::instance()->name(),false,true);
      hTable.set("CONTEXT_TYPE",strCONTEXT_TYPE,false,true);
      hTable.set("CONTEXT_KEY",szCTV_CONTEXT_KEY,false,true);
      if (!m_pUpdateStatement->execute(hTable))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError(diagnoseResult(m_pUpdateStatement->getInfoIDNumber()));
         char szTemp[512];
         int lLength = snprintf(szTemp,sizeof(szTemp),"UPDATE TASK_CONTEXT %s %s %s %s %s",
            Application::instance()->image().c_str(),Application::instance()->name().c_str(),strCONTEXT_TYPE.c_str(),szCTV_CONTEXT_KEY,szCTV_CONTEXT_DATA);
         Trace::put(szTemp,lLength,true);
      }
      else
         UseCase::addItem();
   }
  //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitRecoveryPoint%40E30B8600CB.body
}

void ODBCCheckpointTotalsVisitor::visitReportingEntity (settlement::ReportingEntity* pReportingEntity)
{
  //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitReportingEntity%40E30B8600EA.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   m_lT_FIN_ENTITY_ID = pReportingEntity->getT_FIN_ENTITY_ID();
   if (pReportingEntity->getState() != PersistentObject::NEW)
      return;
   Table hTable("T_FIN_ENTITY");
   hTable.set("T_FIN_ENTITY_ID",m_lT_FIN_ENTITY_ID);
   hTable.set("ENTITY_TYPE",pReportingEntity->getENTITY_TYPE());
   hTable.set("ENTITY_ID",pReportingEntity->getENTITY_ID());
   if (!m_pInsertStatement->execute(hTable))
   {
      Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
      Database::instance()->traceSQLError(diagnoseResult(m_pInsertStatement->getInfoIDNumber()));
      char szTemp[128];
      int lLength = snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_ENTITY %d %s %s",m_lT_FIN_ENTITY_ID,pReportingEntity->getENTITY_TYPE().c_str(),pReportingEntity->getENTITY_ID().c_str());
      Trace::put(szTemp,lLength,true);
      return;
   }
   UseCase::addItem();
  //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitReportingEntity%40E30B8600EA.body
}

void ODBCCheckpointTotalsVisitor::visitReportingPeriod (settlement::ReportingPeriod* pReportingPeriod)
{
  //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitReportingPeriod%40E30B8600FA.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   if (pReportingPeriod->getState() == ReportingPeriod::SAVED)
      return;
   Table hTable("T_FIN_PERIOD");
   hTable.set("T_FIN_ENTITY_ID",m_lT_FIN_ENTITY_ID);
   hTable.set("TSTAMP_END",pReportingPeriod->getTSTAMP_END());
   hTable.set("TSTAMP_TRANS_FROM",pReportingPeriod->getTSTAMP_TRANS_FROM());
   hTable.set("TSTAMP_TRANS_TO",pReportingPeriod->getTSTAMP_TRANS_TO());
   hTable.set("DATE_RECON",pReportingPeriod->getDATE_RECON());
   hTable.set("TSTAMP_LAST_UPDATE",pReportingPeriod->getTSTAMP_LAST_UPDATE());
   hTable.set("PERIOD_ID",pReportingPeriod->getPERIOD_ID(),true);
   if (pReportingPeriod->getState() == ReportingPeriod::NEW)
   {
      if (!m_pInsertStatement->execute(hTable))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError(diagnoseResult(m_pInsertStatement->getInfoIDNumber()));
         char szTemp[128];
         int lLength = snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_PERIOD %d %d %s %s %s %s %s",pReportingPeriod->getPERIOD_ID(),m_lT_FIN_ENTITY_ID,pReportingPeriod->getTSTAMP_END().c_str(),pReportingPeriod->getTSTAMP_TRANS_FROM().c_str(),pReportingPeriod->getTSTAMP_TRANS_TO().c_str(),pReportingPeriod->getDATE_RECON().c_str(),pReportingPeriod->getTSTAMP_LAST_UPDATE().c_str());
         Trace::put(szTemp,lLength,true);
         return;
      }
   }
   else
   {
      if (!m_pUpdateStatement->execute(hTable))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError(diagnoseResult(m_pUpdateStatement->getInfoIDNumber()));
         char szTemp[128];
         int lLength = snprintf(szTemp,sizeof(szTemp),"UPDATE T_FIN_PERIOD %d %d %s %s %s %s %s",pReportingPeriod->getPERIOD_ID(),m_lT_FIN_ENTITY_ID,pReportingPeriod->getTSTAMP_END().c_str(),pReportingPeriod->getTSTAMP_TRANS_FROM().c_str(),pReportingPeriod->getTSTAMP_TRANS_TO().c_str(),pReportingPeriod->getDATE_RECON().c_str(),pReportingPeriod->getTSTAMP_LAST_UPDATE().c_str());
         Trace::put(szTemp,lLength,true);
         return;
      }
   }
   UseCase::addItem();
   pReportingPeriod->setState(ReportingPeriod::SAVED);
  //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitReportingPeriod%40E30B8600FA.body
}

void ODBCCheckpointTotalsVisitor::visitTotal (settlement::Total* pTotal)
{
  //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitTotal%40E30B860109.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   Table hTable("T_FIN_TOTAL");
   hTable.set("ENTITY_GROUP_ID",pTotal->getENTITY_GROUP_ID(),true);
   hTable.set("CATEGORY_ID",pTotal->getCATEGORY_ID(),true);
   hTable.set("TRAN_COUNT",pTotal->getTRAN_COUNT(),false,"+");
   hTable.set("AMT_RECON_NET",pTotal->getAMT_RECON_NET(),false,"+");
   hTable.set("AMT_TRAN",pTotal->getAMT_TRAN(),false,"+");
   hTable.set("AMT_CARD_BILL",pTotal->getAMT_CARD_BILL(),false,"+");
   hTable.set("AMT_RECON_ACQ",pTotal->getAMT_RECON_ACQ(),false,"+");
   hTable.set("AMT_RECON_ISS",pTotal->getAMT_RECON_ISS(),false,"+");
   hTable.set("TSTAMP_LAST_UPDATE",Clock::instance()->getYYYYMMDDHHMMSS());
   bool b = m_pUpdateStatement->execute(hTable);
   if (m_pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
   {
      if (!m_pInsertStatement->execute(hTable))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         Database::instance()->traceSQLError(diagnoseResult(m_pInsertStatement->getInfoIDNumber()));
         char szTemp[5 * PERCENTF + 3 * PERCENTD + PERCENTS];
         int lLength = snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_TOTAL %d %d %d %f %f %f %f %f %s",
            pTotal->getCATEGORY_ID(),m_lENTITY_GROUP_ID,pTotal->getTRAN_COUNT(),pTotal->getAMT_RECON_NET(),pTotal->getAMT_TRAN(),
            pTotal->getAMT_CARD_BILL(),pTotal->getAMT_RECON_ACQ(),pTotal->getAMT_RECON_ISS(),Clock::instance()->getYYYYMMDDHHMMSS().c_str());
         Trace::put(szTemp,lLength,true);
         return;
      }
      UseCase::addItem();
      return;
   }
   if (!b)
   {
      Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
      Database::instance()->traceSQLError(diagnoseResult(m_pUpdateStatement->getInfoIDNumber()));
      char szTemp[5 * PERCENTF + 3 * PERCENTD + PERCENTS];
      int lLength = snprintf(szTemp,sizeof(szTemp),"UPDATE T_FIN_TOTAL %d %d %d %f %f %f %f %f %s",
         pTotal->getCATEGORY_ID(),m_lENTITY_GROUP_ID,pTotal->getTRAN_COUNT(),pTotal->getAMT_RECON_NET(),pTotal->getAMT_TRAN(),
         pTotal->getAMT_CARD_BILL(),pTotal->getAMT_RECON_ACQ(),pTotal->getAMT_RECON_ISS(),Clock::instance()->getYYYYMMDDHHMMSS().c_str());
      Trace::put(szTemp,lLength,true);
      return;
   }
   UseCase::addItem();
  //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitTotal%40E30B860109.body
}

void ODBCCheckpointTotalsVisitor::visitTotalsCategory (settlement::TotalsCategory* pTotalsCategory)
{
  //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitTotalsCategory%40E30B860119.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      return;
   Table hTable("T_FIN_CATEGORY");
   hTable.set("CATEGORY_ID",pTotalsCategory->getCATEGORY_ID());
   hTable.set("NET_ID_ACQ",pTotalsCategory->getNET_ID_ACQ());
   hTable.set("NET_ID_ISS",pTotalsCategory->getNET_ID_ISS());
   hTable.set("FIN_TYPE",pTotalsCategory->getFIN_TYPE());
   hTable.set("TRAN_TYPE_ID",pTotalsCategory->getTRAN_TYPE_ID());
   hTable.set("ACT_CODE",pTotalsCategory->getACT_CODE());
   hTable.set("FUNC_CODE",pTotalsCategory->getFUNC_CODE());
   hTable.set("AUTH_BY",pTotalsCategory->getAUTH_BY());
   hTable.set("REV_BY",pTotalsCategory->getREV_BY());
   hTable.set("CUR_RECON_NET",pTotalsCategory->getCUR_RECON_NET());
   hTable.set("CUR_TRAN",pTotalsCategory->getCUR_TRAN());
   hTable.set("CUR_CARD_BILL",pTotalsCategory->getCUR_CARD_BILL());
   hTable.set("CUR_RECON_ACQ",pTotalsCategory->getCUR_RECON_ACQ());
   hTable.set("CUR_RECON_ISS",pTotalsCategory->getCUR_RECON_ISS());
   hTable.set("IMPACT_TO_ACQ",pTotalsCategory->getIMPACT_TO_ACQ());
   hTable.set("IMPACT_TO_ISS",pTotalsCategory->getIMPACT_TO_ISS());
   hTable.set("TRAN_DISPOSITION",pTotalsCategory->getTRAN_DISPOSITION());
   hTable.set("TOTAL_TYPE",pTotalsCategory->getTOTAL_TYPE());
   hTable.set("TRAN_CLASS",pTotalsCategory->getTRAN_CLASS());
   hTable.set("MERCH_TYPE",pTotalsCategory->getMERCH_TYPE());
   hTable.set("NETWORK_PROGRAM", pTotalsCategory->getNETWORK_PROGRAM());
   if (!m_pInsertStatement->execute(hTable))
   {
      Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
      Database::instance()->traceSQLError(diagnoseResult(m_pInsertStatement->getInfoIDNumber()));
      char szTemp[133];
      int lLength = snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_CATEGORY %d %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
         pTotalsCategory->getCATEGORY_ID(),pTotalsCategory->getNET_ID_ACQ().c_str(),pTotalsCategory->getNET_ID_ISS().c_str(),pTotalsCategory->getFIN_TYPE().c_str(),pTotalsCategory->getTRAN_TYPE_ID().c_str(),
         pTotalsCategory->getACT_CODE().c_str(),pTotalsCategory->getFUNC_CODE().c_str(),pTotalsCategory->getAUTH_BY().c_str(),pTotalsCategory->getREV_BY().c_str(),pTotalsCategory->getCUR_RECON_NET().c_str(),pTotalsCategory->getCUR_TRAN().c_str(),
         pTotalsCategory->getCUR_CARD_BILL().c_str(),pTotalsCategory->getCUR_RECON_ACQ().c_str(),pTotalsCategory->getCUR_RECON_ISS().c_str(),pTotalsCategory->getIMPACT_TO_ACQ().c_str(),
         pTotalsCategory->getIMPACT_TO_ISS().c_str(),pTotalsCategory->getTRAN_DISPOSITION().c_str(),pTotalsCategory->getTOTAL_TYPE().c_str(),pTotalsCategory->getTRAN_CLASS().c_str(),pTotalsCategory->getMERCH_TYPE().c_str(),
         pTotalsCategory->getNETWORK_PROGRAM().c_str());
      Trace::put(szTemp,lLength,true);
      return;
   }
   UseCase::addItem();
  //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor::visitTotalsCategory%40E30B860119.body
}

// Additional Declarations
  //## begin dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.declarations preserve=yes
  //## end dnodbcdatabase::ODBCCheckpointTotalsVisitor%40E30728029F.declarations

} // namespace dnodbcdatabase

//## begin module%40E308FD0000.epilog preserve=yes
//## end module%40E308FD0000.epilog
