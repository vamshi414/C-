//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E3099D01F4.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40E3099D01F4.cm

//## begin module%40E3099D01F4.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40E3099D01F4.cp

//## Module: CXOSDQ12%40E3099D01F4; Package body
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXOSDQ12.cpp

//## begin module%40E3099D01F4.additionalIncludes preserve=no
//## end module%40E3099D01F4.additionalIncludes

//## begin module%40E3099D01F4.includes preserve=yes
// $Date:   May 26 2020 17:40:32  $ $Author:   e1009510  $ $Revision:   1.8  $
//## end module%40E3099D01F4.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSDQ12_h
#include "CXODDQ12.hpp"
#endif


//## begin module%40E3099D01F4.declarations preserve=no
//## end module%40E3099D01F4.declarations

//## begin module%40E3099D01F4.additionalDeclarations preserve=yes
//## end module%40E3099D01F4.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

// Class dnodbcdatabase::ODBCAggregatorPOSRisk 

ODBCAggregatorPOSRisk::ODBCAggregatorPOSRisk()
  //## begin ODBCAggregatorPOSRisk::ODBCAggregatorPOSRisk%40E3078602BF_const.hasinit preserve=no
  //## end ODBCAggregatorPOSRisk::ODBCAggregatorPOSRisk%40E3078602BF_const.hasinit
  //## begin ODBCAggregatorPOSRisk::ODBCAggregatorPOSRisk%40E3078602BF_const.initialization preserve=yes
  //## end ODBCAggregatorPOSRisk::ODBCAggregatorPOSRisk%40E3078602BF_const.initialization
{
  //## begin dnodbcdatabase::ODBCAggregatorPOSRisk::ODBCAggregatorPOSRisk%40E3078602BF_const.body preserve=yes
   memcpy(m_sID,"DQ12",4);
   m_strAPR_ROW_TYPE = "PK";
  //## end dnodbcdatabase::ODBCAggregatorPOSRisk::ODBCAggregatorPOSRisk%40E3078602BF_const.body
}


ODBCAggregatorPOSRisk::~ODBCAggregatorPOSRisk()
{
  //## begin dnodbcdatabase::ODBCAggregatorPOSRisk::~ODBCAggregatorPOSRisk%40E3078602BF_dest.body preserve=yes
  //## end dnodbcdatabase::ODBCAggregatorPOSRisk::~ODBCAggregatorPOSRisk%40E3078602BF_dest.body
}



//## Other Operations (implementation)
bool ODBCAggregatorPOSRisk::tableInsert ()
{
  //## begin dnodbcdatabase::ODBCAggregatorPOSRisk::tableInsert%40E30C460280.body preserve=yes
   Table hTable("T_FIN_COUNT");
   hTable.set("ROW_TYPE",m_strAPR_ROW_TYPE);
   hTable.set("TSTAMP_PERIOD",getTSTAMP_PERIOD());
   hTable.set("T_FIN_ENTITY_ID",(int)getT_FIN_ENTITY_ID());
   hTable.set("COUNT_1",(int)1);
   hTable.set("COUNT_2",(int)getCOUNT_2());
   hTable.set("COUNT_3",(int)getCOUNT_3());
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   if (!pInsertStatement->execute(hTable))
   {
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"INSERT T_FIN_COUNT %s %s %d %d %d %d",
         m_strAPR_ROW_TYPE.c_str(),getTSTAMP_PERIOD().c_str(),getT_FIN_ENTITY_ID(),(int)1,getCOUNT_2(),getCOUNT_3());
      Trace::put(szTemp);
      return false;
   }
   return true;
  //## end dnodbcdatabase::ODBCAggregatorPOSRisk::tableInsert%40E30C460280.body
}

int ODBCAggregatorPOSRisk::tableUpdate ()
{
  //## begin dnodbcdatabase::ODBCAggregatorPOSRisk::tableUpdate%40E30C460290.body preserve=yes
   Table hTable("T_FIN_COUNT");
   hTable.set("ROW_TYPE",m_strAPR_ROW_TYPE,false,true);
   hTable.set("TSTAMP_PERIOD",getTSTAMP_PERIOD(),false,true);
   hTable.set("T_FIN_ENTITY_ID",(int)getT_FIN_ENTITY_ID(),true);
   hTable.set("COUNT_1",(int)1,false,"+");
   hTable.set("COUNT_2",(int)getCOUNT_2(),false,"+");
   hTable.set("COUNT_3",(int)getCOUNT_3(),false,"+");
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if (!pUpdateStatement->execute(hTable))
   {
      if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
         return 0;
      char szTemp[128];
      snprintf(szTemp,sizeof(szTemp),"UPDATE T_FIN_COUNT %s %s %d %d %d %d",
         m_strAPR_ROW_TYPE.c_str(),getTSTAMP_PERIOD().c_str(),getT_FIN_ENTITY_ID(),(int)1,getCOUNT_2(),getCOUNT_3());
      Trace::put(szTemp);
      return -1;
   }
   return 1;
  //## end dnodbcdatabase::ODBCAggregatorPOSRisk::tableUpdate%40E30C460290.body
}

// Additional Declarations
  //## begin dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.declarations preserve=yes
  //## end dnodbcdatabase::ODBCAggregatorPOSRisk%40E3078602BF.declarations

} // namespace dnodbcdatabase

//## begin module%40E3099D01F4.epilog preserve=yes
//## end module%40E3099D01F4.epilog
