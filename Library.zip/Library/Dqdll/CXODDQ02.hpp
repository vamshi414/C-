//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E412A3031C.cm preserve=no
//	$Date:   Mar 30 2006 18:40:46  $ $Author:   D92186  $
//	$Revision:   1.3  $
//## end module%40E412A3031C.cm

//## begin module%40E412A3031C.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%40E412A3031C.cp

//## Module: CXOSDQ02%40E412A3031C; Package specification
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXODDQ02.hpp

#ifndef CXOSDQ02_h
#define CXOSDQ02_h 1

//## begin module%40E412A3031C.additionalIncludes preserve=no
//## end module%40E412A3031C.additionalIncludes

//## begin module%40E412A3031C.includes preserve=yes
//## end module%40E412A3031C.includes

#ifndef CXOSAR05_h
#include "CXODAR05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CriticalSection;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
class DatabaseCatalog;

} // namespace database

//## begin module%40E412A3031C.declarations preserve=no
//## end module%40E412A3031C.declarations

//## begin module%40E412A3031C.additionalDeclarations preserve=yes
//## end module%40E412A3031C.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

//## begin dnodbcdatabase::ODBCLocator%40E2FB9C03B9.preface preserve=yes
//## end dnodbcdatabase::ODBCLocator%40E2FB9C03B9.preface

//## Class: ODBCLocator%40E2FB9C03B9
//## Category: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
//## Subsystem: DQDLL%40852BF400DA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40E2FC0E03A9;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%40E2FC11038A;database::Database { -> F}
//## Uses: <unnamed>%40E2FC15005D;reusable::Query { -> F}
//## Uses: <unnamed>%40E2FC190399;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%40E2FC200213;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%442C362802F8;database::DatabaseCatalog { -> F}

class DllExport ODBCLocator : public archive::Locator  //## Inherits: <unnamed>%40E2FC27034B
{
  //## begin dnodbcdatabase::ODBCLocator%40E2FB9C03B9.initialDeclarations preserve=yes
  //## end dnodbcdatabase::ODBCLocator%40E2FB9C03B9.initialDeclarations

  public:
    //## Constructors (generated)
      ODBCLocator();

    //## Destructor (generated)
      virtual ~ODBCLocator();


    //## Other Operations (specified)
      //## Operation: synchronize%40E2FC5801B5
      virtual bool synchronize ();

    // Additional Public Declarations
      //## begin dnodbcdatabase::ODBCLocator%40E2FB9C03B9.public preserve=yes
      //## end dnodbcdatabase::ODBCLocator%40E2FB9C03B9.public

  protected:
    // Additional Protected Declarations
      //## begin dnodbcdatabase::ODBCLocator%40E2FB9C03B9.protected preserve=yes
      //## end dnodbcdatabase::ODBCLocator%40E2FB9C03B9.protected

  private:
    // Additional Private Declarations
      //## begin dnodbcdatabase::ODBCLocator%40E2FB9C03B9.private preserve=yes
      //## end dnodbcdatabase::ODBCLocator%40E2FB9C03B9.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin dnodbcdatabase::ODBCLocator%40E2FB9C03B9.implementation preserve=yes
      //## end dnodbcdatabase::ODBCLocator%40E2FB9C03B9.implementation

};

//## begin dnodbcdatabase::ODBCLocator%40E2FB9C03B9.postscript preserve=yes
//## end dnodbcdatabase::ODBCLocator%40E2FB9C03B9.postscript

} // namespace dnodbcdatabase

//## begin module%40E412A3031C.epilog preserve=yes
//## end module%40E412A3031C.epilog


#endif
