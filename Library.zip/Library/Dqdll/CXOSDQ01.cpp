//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%40852C250222.cm preserve=no
//## end module%40852C250222.cm

//## begin module%40852C250222.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%40852C250222.cp

//## Module: CXOSDQ01%40852C250222; Package body
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Dqdll\CXOSDQ01.cpp

//## begin module%40852C250222.additionalIncludes preserve=no
//## end module%40852C250222.additionalIncludes

//## begin module%40852C250222.includes preserve=yes
// $Date:   Apr 01 2021 04:15:44  $ $Author:   e3027760  $ $Revision:   1.11  $
//## end module%40852C250222.includes

#ifndef CXOSDQ10_h
#include "CXODDQ10.hpp"
#endif
#ifndef CXOSDQ04_h
#include "CXODDQ04.hpp"
#endif
#ifndef CXOSDQ02_h
#include "CXODDQ02.hpp"
#endif
#ifndef CXOSDQ13_h
#include "CXODDQ13.hpp"
#endif
#ifndef CXOSDQ12_h
#include "CXODDQ12.hpp"
#endif
#ifndef CXOSDQ14_h
#include "CXODDQ14.hpp"
#endif
#ifndef CXOSDQ07_h
#include "CXODDQ07.hpp"
#endif
#ifndef CXOSDQ09_h
#include "CXODDQ09.hpp"
#endif
#ifndef CXOSDQ08_h
#include "CXODDQ08.hpp"
#endif
#ifndef CXOSDQ15_h
#include "CXODDQ15.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDQ01_h
#include "CXODDQ01.hpp"
#endif


//## begin module%40852C250222.declarations preserve=no
//## end module%40852C250222.declarations

//## begin module%40852C250222.additionalDeclarations preserve=yes
#ifndef CXOSST80_h
#include "CXODST80.hpp"
#endif
#ifndef CXOSST81_h
#include "CXODST81.hpp"
#endif
#ifndef CXOSST87_h
#include "CXODST87.hpp"
#endif
//## end module%40852C250222.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

// Class dnodbcdatabase::DNODBCDatabaseFactory 

DNODBCDatabaseFactory::DNODBCDatabaseFactory()
  //## begin DNODBCDatabaseFactory::DNODBCDatabaseFactory%40852B7B038A_const.hasinit preserve=no
  //## end DNODBCDatabaseFactory::DNODBCDatabaseFactory%40852B7B038A_const.hasinit
  //## begin DNODBCDatabaseFactory::DNODBCDatabaseFactory%40852B7B038A_const.initialization preserve=yes
  //## end DNODBCDatabaseFactory::DNODBCDatabaseFactory%40852B7B038A_const.initialization
{
  //## begin dnodbcdatabase::DNODBCDatabaseFactory::DNODBCDatabaseFactory%40852B7B038A_const.body preserve=yes
   memcpy(m_sID,"DQ01",4);
   init("SQLSERVER");
  //## end dnodbcdatabase::DNODBCDatabaseFactory::DNODBCDatabaseFactory%40852B7B038A_const.body
}

DNODBCDatabaseFactory::DNODBCDatabaseFactory (reusable::string strDBVendor)
  //## begin dnodbcdatabase::DNODBCDatabaseFactory::DNODBCDatabaseFactory%4110F08B00BB.hasinit preserve=no
  //## end dnodbcdatabase::DNODBCDatabaseFactory::DNODBCDatabaseFactory%4110F08B00BB.hasinit
  //## begin dnodbcdatabase::DNODBCDatabaseFactory::DNODBCDatabaseFactory%4110F08B00BB.initialization preserve=yes
  //## end dnodbcdatabase::DNODBCDatabaseFactory::DNODBCDatabaseFactory%4110F08B00BB.initialization
{
  //## begin dnodbcdatabase::DNODBCDatabaseFactory::DNODBCDatabaseFactory%4110F08B00BB.body preserve=yes
   memcpy(m_sID,"DQ01",4);
   init(strDBVendor);
  //## end dnodbcdatabase::DNODBCDatabaseFactory::DNODBCDatabaseFactory%4110F08B00BB.body
}


DNODBCDatabaseFactory::~DNODBCDatabaseFactory()
{
  //## begin dnodbcdatabase::DNODBCDatabaseFactory::~DNODBCDatabaseFactory%40852B7B038A_dest.body preserve=yes
  //## end dnodbcdatabase::DNODBCDatabaseFactory::~DNODBCDatabaseFactory%40852B7B038A_dest.body
}



//## Other Operations (implementation)
Object* DNODBCDatabaseFactory::create (const char* pszClass, const char* pszValue)
{
  //## begin dnodbcdatabase::DNODBCDatabaseFactory::create%40852BA80232.body preserve=yes
   string strClass(pszClass);
   map<string,int,less<string> >::iterator pClass = m_hClasses.find(strClass);
   if (pClass == m_hClasses.end())
      return ODBCDatabaseFactory::create(pszClass,pszValue);
   Object* pObject = 0;
   vector<string > hValue;
   vector<string >::iterator p;
   int iMIS = 2;
   switch ((*pClass).second)
   {
   case 0:
      pObject = new ODBCAddFinancialCommand();
      break;
   case 1:
      Extract::instance()->getSpec("DQ01", hValue);
      for (p = hValue.begin(); p != hValue.end(); ++p)
      {
         if ((*p).length() > 4
            && (*p).substr(0, 5) == "MIS~1")
            iMIS = 1;
      }
      if (iMIS != 1)
         pObject = new ODBCAggregatorMIS2();
      else
         pObject = new ODBCAggregatorMIS();
      break;
      case 2:
         pObject = new ODBCAggregatorPOSRisk();
         break;
      case 3:
         pObject = new ODBCCheckpointTotalsVisitor();
         break;
      case 4:
         pObject = new ODBCLocator();
         break;
      case 5:
         pObject = new ODBCMaintenanceProcedure();
         break;
      case 6:
         pObject = new ODBCPartitionAllocator();
         break;
      case 7:
         pObject = new ODBCPartitionDeallocator();
         break;
      case 8:
         pObject = new ODBCTransactionRemover();
         break;
      case 9:
         pObject = new MonthlyTotal();
         break;
      case 10:
         pObject = new MonthlyCardHolder();
         break;
      case 11:
         pObject = new MISMonthlyCardHolder();
         break;
   }
   return pObject;
  //## end dnodbcdatabase::DNODBCDatabaseFactory::create%40852BA80232.body
}

void DNODBCDatabaseFactory::init (reusable::string strDBVendor)
{
  //## begin dnodbcdatabase::DNODBCDatabaseFactory::init%4141ADB30271.body preserve=yes
   setDBVendor(strDBVendor);
   #define CLASSES 12
   const char* pszDB2Class[CLASSES] =
   {
      "AddFinancialCommand",
      "AggregatorMIS",
      "AggregatorPOSRisk",
      "CheckpointTotalsVisitor",
      "Locator",
      "MaintenanceProcedure",
      "PartitionAllocator",
      "PartitionDeallocator",
      "TransactionRemover",
      "MonthlyTotal",
      "MonthlyCardHolder",
      "MISMonthlyCardHolder"
   };
   string strClass;
   for (int m = 0;m < CLASSES;++m)
   {
      strClass = pszDB2Class[m];
      m_hClasses.insert(map<string,int,less<string> >::value_type(strClass,m));
   }
  //## end dnodbcdatabase::DNODBCDatabaseFactory::init%4141ADB30271.body
}

// Additional Declarations
  //## begin dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.declarations preserve=yes
  //## end dnodbcdatabase::DNODBCDatabaseFactory%40852B7B038A.declarations

} // namespace dnodbcdatabase

//## begin module%40852C250222.epilog preserve=yes
//## end module%40852C250222.epilog
