//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E308970222.cm preserve=no
//	$Date:   Sep 05 2007 10:10:50  $ $Author:   D98369  $
//	$Revision:   1.7  $
//## end module%40E308970222.cm

//## begin module%40E308970222.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%40E308970222.cp

//## Module: CXOSDQ09%40E308970222; Package body
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXOSDQ09.cpp

//## begin module%40E308970222.additionalIncludes preserve=no
//## end module%40E308970222.additionalIncludes

//## begin module%40E308970222.includes preserve=yes
//## end module%40E308970222.includes

#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSDQ09_h
#include "CXODDQ09.hpp"
#endif


//## begin module%40E308970222.declarations preserve=no
//## end module%40E308970222.declarations

//## begin module%40E308970222.additionalDeclarations preserve=yes
//## end module%40E308970222.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

// Class dnodbcdatabase::ODBCTransactionRemover 

ODBCTransactionRemover::ODBCTransactionRemover()
  //## begin ODBCTransactionRemover::ODBCTransactionRemover%40E30661009C_const.hasinit preserve=no
      : m_iMinutes(1),
        m_iTransactions(2000)
  //## end ODBCTransactionRemover::ODBCTransactionRemover%40E30661009C_const.hasinit
  //## begin ODBCTransactionRemover::ODBCTransactionRemover%40E30661009C_const.initialization preserve=yes
  //## end ODBCTransactionRemover::ODBCTransactionRemover%40E30661009C_const.initialization
{
  //## begin dnodbcdatabase::ODBCTransactionRemover::ODBCTransactionRemover%40E30661009C_const.body preserve=yes
   memcpy(m_sID,"DQ09",4);
   m_pTimestampCursor = new GlobalContext("##DELETED");
  //## end dnodbcdatabase::ODBCTransactionRemover::ODBCTransactionRemover%40E30661009C_const.body
}


ODBCTransactionRemover::~ODBCTransactionRemover()
{
  //## begin dnodbcdatabase::ODBCTransactionRemover::~ODBCTransactionRemover%40E30661009C_dest.body preserve=yes
   delete m_pTimestampCursor;
  //## end dnodbcdatabase::ODBCTransactionRemover::~ODBCTransactionRemover%40E30661009C_dest.body
}



//## Other Operations (implementation)
int ODBCTransactionRemover::remove ()
{
  //## begin dnodbcdatabase::ODBCTransactionRemover::remove%41192F3F01C5.body preserve=yes
   if (Database::instance()->getDormant())
      Database::instance()->connect();
   IString strTimestampEnd(m_strTimestampStart);
   if (UseCase::getInterval() > 30000)
   {
      // target less than 30 seconds elapsed time per DELETE
      m_iMinutes = (int)((double)(30000 / (double)UseCase::getInterval()) * (double)m_iMinutes);
   }
   else
   {
      // target 2000 rows per DELETE if under 30 seconds
      if (m_iTransactions == 0)
         m_iMinutes = 60;
      else
         m_iMinutes = (int)((double)(2000 / (double)m_iTransactions) * (double)m_iMinutes);
   }
   if (m_iMinutes < 1)
      m_iMinutes = 1;
   else
   if (m_iMinutes > 60)
      m_iMinutes = 60;
   string strDate(strTimestampEnd.data(),8);
   strDate += "000";
   string strTime(strTimestampEnd.data() + 8,6);
   Timestamp::adjustGMT(strDate,strTime,m_iMinutes);
   strTimestampEnd = strDate.substr(0,8).c_str();
   strTimestampEnd += strTime.c_str();
   strTimestampEnd += m_strTimestampEnd.subString(15,2);
   if (strTimestampEnd > m_strTimestampEnd)
      strTimestampEnd = m_strTimestampEnd;   
   string strTemp("'");
   strTemp += m_strTimestampStart;
   strTemp += "' AND '";
   strTemp += strTimestampEnd;
   strTemp += "'";
   reusable::Query hQuery;
   hQuery.setBasicPredicate((char*)m_strTableName,"TSTAMP_TRANS","BETWEEN",strTemp.c_str());   
   hQuery.setBasicPredicate((char*)m_strTableName,"UNIQUENESS_KEY",">",-1);
   auto_ptr<reusable::SelectStatement> pDeleteStatement
      ((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("DeleteStatement"));
   if (pDeleteStatement->execute(hQuery))
   {
      Database::instance()->commit();
      m_pTimestampCursor->put(strTimestampEnd,m_cType);
      if (strncmp(strTimestampEnd.subString(9,2),m_strTimestampStart.subString(9,2),2) != 0)
      {
         string strConsoleText(&m_cType,1);
         strConsoleText += " THROUGH TIMESTAMP: ";
         strConsoleText += strTimestampEnd;
         Console::display("ST114",strConsoleText.c_str());
         // ST114 - "DELETED TYPE: @ THROUGH TIMESTAMP: @@@@@@@@@@@@@@"
      }
      m_strTimestampStart = strTimestampEnd;
      return (strTimestampEnd == m_strTimestampEnd) ? 1 : 0;
   }
   else
   {
      Database::instance()->rollback();
      return -1;
   }
  //## end dnodbcdatabase::ODBCTransactionRemover::remove%41192F3F01C5.body
}

void ODBCTransactionRemover::setTimeRange (const char* pszTimestampStart, const char* pszTimestampEnd)
{
  //## begin dnodbcdatabase::ODBCTransactionRemover::setTimeRange%41192F3F01C6.body preserve=yes
   m_strTimestampStart = pszTimestampStart;
   m_strTimestampEnd = pszTimestampEnd;   
   string strTimestamp;
   if (m_pTimestampCursor->get(strTimestamp,m_cType))
      if (strTimestamp.length() > 0)
         m_strTimestampStart = strTimestamp.substr(0,16).c_str();
  //## end dnodbcdatabase::ODBCTransactionRemover::setTimeRange%41192F3F01C6.body
}

// Additional Declarations
  //## begin dnodbcdatabase::ODBCTransactionRemover%40E30661009C.declarations preserve=yes
  //## end dnodbcdatabase::ODBCTransactionRemover%40E30661009C.declarations

} // namespace dnodbcdatabase

//## begin module%40E308970222.epilog preserve=yes
//## end module%40E308970222.epilog
