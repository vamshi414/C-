//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E3089501A5.cm preserve=no
//	$Date:   Sep 06 2006 06:40:06  $ $Author:   D02405  $
//	$Revision:   1.3  $
//## end module%40E3089501A5.cm

//## begin module%40E3089501A5.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%40E3089501A5.cp

//## Module: CXOSDQ09%40E3089501A5; Package specification
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXODDQ09.hpp

#ifndef CXOSDQ09_h
#define CXOSDQ09_h 1

//## begin module%40E3089501A5.additionalIncludes preserve=no
//## end module%40E3089501A5.additionalIncludes

//## begin module%40E3089501A5.includes preserve=yes
//## end module%40E3089501A5.includes

#ifndef CXOSDB07_h
#include "CXODDB07.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Timestamp;
class Console;
} // namespace IF

namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace database {
class GlobalContext;
class DatabaseFactory;

} // namespace database

//## begin module%40E3089501A5.declarations preserve=no
//## end module%40E3089501A5.declarations

//## begin module%40E3089501A5.additionalDeclarations preserve=yes
//## end module%40E3089501A5.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

//## begin dnodbcdatabase::ODBCTransactionRemover%40E30661009C.preface preserve=yes
//## end dnodbcdatabase::ODBCTransactionRemover%40E30661009C.preface

//## Class: ODBCTransactionRemover%40E30661009C
//## Category: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
//## Subsystem: DQDLL%40852BF400DA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40E306900157;IF::Timestamp { -> F}
//## Uses: <unnamed>%40E30692029F;monitor::UseCase { -> F}
//## Uses: <unnamed>%40E306950138;database::Database { -> F}
//## Uses: <unnamed>%40E30699033C;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%40E306A00242;IF::Trace { -> F}
//## Uses: <unnamed>%40E306A2032C;IF::Console { -> F}
//## Uses: <unnamed>%411937D300AB;reusable::Transaction { -> F}
//## Uses: <unnamed>%44E9B1750128;reusable::Query { -> F}
//## Uses: <unnamed>%44E9B1760167;reusable::SelectStatement { -> F}

class DllExport ODBCTransactionRemover : public database::TransactionRemover  //## Inherits: <unnamed>%40E3068E01D4
{
  //## begin dnodbcdatabase::ODBCTransactionRemover%40E30661009C.initialDeclarations preserve=yes
  //## end dnodbcdatabase::ODBCTransactionRemover%40E30661009C.initialDeclarations

  public:
    //## Constructors (generated)
      ODBCTransactionRemover();

    //## Destructor (generated)
      virtual ~ODBCTransactionRemover();


    //## Other Operations (specified)
      //## Operation: remove%41192F3F01C5
      //	Remove the next set of transactions within the specified
      //	time range.  Return:
      //
      //	    -1 if there is a failure.
      //	    0 if there are more rows to delete.
      //	    1 if there are no more rows to delete.
      //## Semantics:
      //	1. strTimestampEnd = m_strTimestampStart + 1 minute.
      //	2. If strTimestampEnd > m_strTimestampEnd:
      //	        strTimestampEnd = m_strTimestampEnd.
      //	3. EXEC SQL DELETE
      //	        FROM Database::qualifer . m_strTableName
      //	        WHERE TSTAMP_TRANS BETWEEN m_strTimestampStart
      //	AND strTimestampEnd.
      //	4. If unsuccessful, return -1.
      //	5. m_pTimestampCursor->put(strTimestampEnd).
      //	6. m_strTimestampStart = strTimestampEnd.
      //	7. Return (strTimestampEnd == m_strTimestampEnd) ? 1 : 0.
      virtual int remove ();

      //## Operation: setTimeRange%41192F3F01C6
      //	Establish the start and end timestamps for the current
      //	remove process.
      //## Semantics:
      //	1. Call TransactionRemover::setTimeRange(pszTimestamp
      //	Start,pszTimestampEnd).
      //	2. If m_pTimestampCursor == 0:
      //	        IString strName = "REMOVE_" + m_strTableName.
      //	        m_pTimestampCursor = Database
      //	Factory::instance()->createGlobalContext(strName).
      //	3. If m_pTimestampCursor->get(strTimestamp):
      //	        m_strTimestampStart = strTimestamp.
      virtual void setTimeRange (const char* pszTimestampStart, const char* pszTimestampEnd);

    // Additional Public Declarations
      //## begin dnodbcdatabase::ODBCTransactionRemover%40E30661009C.public preserve=yes
      //## end dnodbcdatabase::ODBCTransactionRemover%40E30661009C.public

  protected:
    // Additional Protected Declarations
      //## begin dnodbcdatabase::ODBCTransactionRemover%40E30661009C.protected preserve=yes
      //## end dnodbcdatabase::ODBCTransactionRemover%40E30661009C.protected

  private:
    // Additional Private Declarations
      //## begin dnodbcdatabase::ODBCTransactionRemover%40E30661009C.private preserve=yes
      //## end dnodbcdatabase::ODBCTransactionRemover%40E30661009C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Minutes%41192F54036B
      //## begin dnodbcdatabase::ODBCTransactionRemover::Minutes%41192F54036B.attr preserve=no  private: int {V} 1
      int m_iMinutes;
      //## end dnodbcdatabase::ODBCTransactionRemover::Minutes%41192F54036B.attr

      //## Attribute: Transactions%41192F54036D
      //## begin dnodbcdatabase::ODBCTransactionRemover::Transactions%41192F54036D.attr preserve=no  private: int {V} 2000
      int m_iTransactions;
      //## end dnodbcdatabase::ODBCTransactionRemover::Transactions%41192F54036D.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::DNODBCDatabase_CAT::<unnamed>%40E306D503B9
      //## Role: ODBCTransactionRemover::<m_pTimestampCursor>%40E306D602AF
      //## begin dnodbcdatabase::ODBCTransactionRemover::<m_pTimestampCursor>%40E306D602AF.role preserve=no  public: database::GlobalContext { -> RFHgN}
      database::GlobalContext *m_pTimestampCursor;
      //## end dnodbcdatabase::ODBCTransactionRemover::<m_pTimestampCursor>%40E306D602AF.role

    // Additional Implementation Declarations
      //## begin dnodbcdatabase::ODBCTransactionRemover%40E30661009C.implementation preserve=yes
      //## end dnodbcdatabase::ODBCTransactionRemover%40E30661009C.implementation

};

//## begin dnodbcdatabase::ODBCTransactionRemover%40E30661009C.postscript preserve=yes
//## end dnodbcdatabase::ODBCTransactionRemover%40E30661009C.postscript

} // namespace dnodbcdatabase

//## begin module%40E3089501A5.epilog preserve=yes
using namespace dnodbcdatabase;
//## end module%40E3089501A5.epilog


#endif
