//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E3058002CE.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%40E3058002CE.cm

//## begin module%40E3058002CE.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%40E3058002CE.cp

//## Module: CXOSDQ07%40E3058002CE; Package body
//## Subsystem: DQDLL%40852BF400DA
//## Source file: C:\Devel\Dn\Server\Library\Dqdll\CXOSDQ07.cpp

//## begin module%40E3058002CE.additionalIncludes preserve=no
//## end module%40E3058002CE.additionalIncludes

//## begin module%40E3058002CE.includes preserve=yes
//## end module%40E3058002CE.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSPQ13_h
#include "CXODPQ13.hpp"
#endif
#ifndef CXOSPQ02_h
#include "CXODPQ02.hpp"
#endif
#ifndef CXOSDQ07_h
#include "CXODDQ07.hpp"
#endif


//## begin module%40E3058002CE.declarations preserve=no
//## end module%40E3058002CE.declarations

//## begin module%40E3058002CE.additionalDeclarations preserve=yes
//## end module%40E3058002CE.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

// Class dnodbcdatabase::ODBCPartitionAllocator

ODBCPartitionAllocator::ODBCPartitionAllocator()
  //## begin ODBCPartitionAllocator::ODBCPartitionAllocator%40E301D300BB_const.hasinit preserve=no
      : m_bLastPartitionAllocated(false)
  //## end ODBCPartitionAllocator::ODBCPartitionAllocator%40E301D300BB_const.hasinit
  //## begin ODBCPartitionAllocator::ODBCPartitionAllocator%40E301D300BB_const.initialization preserve=yes
  //## end ODBCPartitionAllocator::ODBCPartitionAllocator%40E301D300BB_const.initialization
{
  //## begin dnodbcdatabase::ODBCPartitionAllocator::ODBCPartitionAllocator%40E301D300BB_const.body preserve=yes
   memcpy(m_sID,"DQ07",4);
  //## end dnodbcdatabase::ODBCPartitionAllocator::ODBCPartitionAllocator%40E301D300BB_const.body
}


ODBCPartitionAllocator::~ODBCPartitionAllocator()
{
  //## begin dnodbcdatabase::ODBCPartitionAllocator::~ODBCPartitionAllocator%40E301D300BB_dest.body preserve=yes
  //## end dnodbcdatabase::ODBCPartitionAllocator::~ODBCPartitionAllocator%40E301D300BB_dest.body
}



//## Other Operations (implementation)
int ODBCPartitionAllocator::allocate (const char* pszTable, const char* pszDate, short int* piKey, const char* pszPartTable)
{
  //## begin dnodbcdatabase::ODBCPartitionAllocator::allocate%411395B1004E.body preserve=yes
   UseCase hUseCase("DR","## DR08 ALLOCATE PARTITION");
   CriticalSection hCriticalSection("CATALOG");
   if (Database::instance()->getDormant())
      Database::instance()->connect();
   *piKey = PartitionAllocator::allocate(pszTable,pszDate,piKey,pszPartTable);
   if (*piKey < 0)
      return *piKey;
   *piKey = -1;
   int i = 0;
   if (Database::instance()->state() == Database::DISCONNECTED)
   {
      UseCase::add("CONNECT");
      UseCase::setSuccess(false);
      return -1;
   }
   strcpy(m_psPC_TABLE_NAME,pszTable);
   strcpy(m_psPC_TSTAMP_START,pszDate);
   strcpy(m_psPC_TSTAMP_START + 8,"00000000");
   strcpy(m_psPC_TSTAMP_END,pszDate);
   strcpy(m_psPC_TSTAMP_END + 8,"23595999");
   m_nState = ODBCPartitionAllocator::START;
   for (;;)
   {
      switch (m_nState)
      {
         case ODBCPartitionAllocator::START:
            i = 0;
            m_nState = lockTable();
            break;
         case ODBCPartitionAllocator::SELECT:
            m_nState = select(piKey);
            break;
         case ODBCPartitionAllocator::SUCCESS:
            return i;
         case ODBCPartitionAllocator::UPDATE:
            i = 1;
            m_nState = update(piKey,pszPartTable);
            break;
         case ODBCPartitionAllocator::SYNC:
            m_nState = sync(piKey,pszPartTable);
            break;
         case ODBCPartitionAllocator::DATABASE_FAILURE:
            UseCase::add("DBERROR");
            UseCase::setSuccess(false);
            return -1;
      }
   }
   UseCase::setSuccess(false);
   return -1;
  //## end dnodbcdatabase::ODBCPartitionAllocator::allocate%411395B1004E.body
}

ODBCPartitionAllocator::State ODBCPartitionAllocator::lockTable ()
{
  //## begin dnodbcdatabase::ODBCPartitionAllocator::lockTable%40E30254001F.body preserve=yes
   // handled by CriticalSection
   return ODBCPartitionAllocator::SELECT;
  //## end dnodbcdatabase::ODBCPartitionAllocator::lockTable%40E30254001F.body
}

ODBCPartitionAllocator::State ODBCPartitionAllocator::select (short int* piKey)
{
  //## begin dnodbcdatabase::ODBCPartitionAllocator::select%40E30254002E.body preserve=yes
   m_siPC_PART_NUMBER = -1;
   Query hQuery;
   hQuery.reset();
   string strPART_NUMBER;
   hQuery.setQualifier("CUSTQUAL", "PARTITION_CONTROL");
   hQuery.bind( "PARTITION_CONTROL","PART_NUMBER",Column::SHORT, &m_siPC_PART_NUMBER);
   hQuery.setBasicPredicate( "PARTITION_CONTROL","TSTAMP_START","=", m_psPC_TSTAMP_START);
   hQuery.setBasicPredicate( "PARTITION_CONTROL","TABLE_NAME","=", m_psPC_TABLE_NAME);
   hQuery.setBasicPredicate( "PARTITION_CONTROL","PART_STAT","=", "A");
   auto_ptr<SelectStatement> pSelectStatement ((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
   {
      string strErrorMsg = "Error in ODBCPartitionAllocator::select() executing ";
      strErrorMsg += "SELECT PART_NUMBER FROM PARTITION_CONTROL...";
      reportError(strErrorMsg);
      return ODBCPartitionAllocator::DATABASE_FAILURE;
   }
   else
   {
      if (m_siPC_PART_NUMBER == -1)
         return ODBCPartitionAllocator::UPDATE;
      else
      {
         *piKey = m_siPC_PART_NUMBER;
         return ODBCPartitionAllocator::SUCCESS;
      }
   }
  //## end dnodbcdatabase::ODBCPartitionAllocator::select%40E30254002E.body
}

ODBCPartitionAllocator::State ODBCPartitionAllocator::sync (short int* piKey, const char* pszPartTable)
{
  //## begin dnodbcdatabase::ODBCPartitionAllocator::sync%40E30254003E.body preserve=yes
   short int siPC_PARTITIONS = 0;
   string strPartitions;
   if (Extract::instance()->getSpec(pszPartTable,strPartitions))
      siPC_PARTITIONS = atoi(strPartitions.c_str());
   if (siPC_PARTITIONS == 0)
      siPC_PARTITIONS = 183;
   m_siPC_PART_NUMBER = 0;
   Query hQuery;
   hQuery.reset();
   string strPART_NUMBER;
   hQuery.setQualifier("CUSTQUAL","PARTITION_CONTROL");
   hQuery.bind("PARTITION_CONTROL","PART_NUMBER",Column::SHORT,&m_siPC_PART_NUMBER,0,"MAX");
   hQuery.setBasicPredicate("PARTITION_CONTROL","TABLE_NAME","=", m_psPC_TABLE_NAME);
   auto_ptr<SelectStatement> pSelectStatement ((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
   {
      string strErrorMsg = "Error in ODBCPartitionAllocator::sync() executing ";
      strErrorMsg += "SELECT MAX(PART_NUMBER) INTO PC_PART_NUMBER FROM PARTITION_CONTROL...";
      reportError(strErrorMsg);
      return ODBCPartitionAllocator::DATABASE_FAILURE;
   }
   if (!(m_siPC_PART_NUMBER < siPC_PARTITIONS))
      return ODBCPartitionAllocator::DATABASE_FAILURE;
   ++m_siPC_PART_NUMBER;
   IString strDate;
   DateTime hDateTime;
   hDateTime.setCurrent(strDate);
   strcpy(m_psPC_TSTAMP_UPDATE,strDate);
   Table hTable("PARTITION_CONTROL");
 	hTable.setQualifier("CUSTQUAL");
   hTable.set("TABLE_QUALIFIER",1," ");
   hTable.set("TABLE_NAME",strlen(m_psPC_TABLE_NAME),m_psPC_TABLE_NAME);
   hTable.set("PART_NUMBER",(int)m_siPC_PART_NUMBER);
   hTable.set("PART_STAT",1,"A");
   hTable.set("TSTAMP_START",strlen(m_psPC_TSTAMP_START),m_psPC_TSTAMP_START);
   hTable.set("TSTAMP_END",strlen(m_psPC_TSTAMP_END),m_psPC_TSTAMP_END);
   hTable.set("TSTAMP_UPDATE",strlen(m_psPC_TSTAMP_UPDATE),m_psPC_TSTAMP_UPDATE);
   auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   if (!pInsertStatement->execute(hTable))
   {
      string strErrorMsg = "Error in ODBCPartitionAllocator::sync() executing ";
      strErrorMsg += "INSERT INTO PARTITION_CONTROL";
      reportError(strErrorMsg);
      return ODBCPartitionAllocator::DATABASE_FAILURE;
   }
   else
   {
      *piKey = m_siPC_PART_NUMBER;
      Database::instance()->commit();
      return ODBCPartitionAllocator::SUCCESS;
   }
   return ODBCPartitionAllocator::DATABASE_FAILURE;
  //## end dnodbcdatabase::ODBCPartitionAllocator::sync%40E30254003E.body
}

ODBCPartitionAllocator::State ODBCPartitionAllocator::update (short int* piKey, const char* pszPartTable)
{
  //## begin dnodbcdatabase::ODBCPartitionAllocator::update%40E30254004E.body preserve=yes
   m_siPC_ACTIVE_PARTITIONS = 0;
   string strPartitions;
   int lPartitions = 0;
   Query hQuery;
   int m = 0;
   short iNull;
   hQuery.bind("PARTITION_CONTROL","*",Column::LONG,&m,&iNull,"COUNT");
   hQuery.setBasicPredicate("PARTITION_CONTROL","TABLE_NAME","=",m_psPC_TABLE_NAME);
   hQuery.setBasicPredicate("PARTITION_CONTROL","PART_STAT","=","A");
   hQuery.setQualifier("CUSTQUAL","PARTITION_CONTROL");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   bool bReturn = pSelectStatement->execute(hQuery);
   m_siPC_ACTIVE_PARTITIONS = m;
   if (bReturn)
   {
      if (Extract::instance()->getSpec(pszPartTable,strPartitions))
         lPartitions = atoi(strPartitions.c_str());
      if ((m_siPC_ACTIVE_PARTITIONS + 1) == lPartitions)
         Console::display("ST135",m_psPC_TABLE_NAME);
   }
   else
   {
      string strErrorMsg = "Error in ODBCPartitionAllocator::update() executing ";
      strErrorMsg += "SELECT COUNT(*) FROM PARTITION_CONTROL";
      reportError(strErrorMsg);
      return ODBCPartitionAllocator::DATABASE_FAILURE;
   }
   m_siPC_PART_NUMBER = -1;
   hQuery.reset();
   hQuery.setSubSelect(true);
   hQuery.bind("PARTITION_CONTROL","PART_NUMBER",Column::SHORT,&m_siPC_PART_NUMBER,0,"MIN");
   hQuery.setBasicPredicate("PARTITION_CONTROL","TABLE_NAME","=",m_psPC_TABLE_NAME);
   hQuery.setBasicPredicate("PARTITION_CONTROL","PART_STAT","=","R");
   if (pSelectStatement->execute(hQuery))
   {
      //check for not found condition
      if (m_siPC_PART_NUMBER <= 0)
         return ODBCPartitionAllocator::SYNC;
   }
   else
   {
      string strErrorMsg("Error in ODBCPartitionAllocator::update() executing ");
      strErrorMsg += "SELECT MIN(PART_NUMBER) FROM PARTITION_CONTROL WHERE TABLE_NAME = ?";
      reportError(strErrorMsg);
      return ODBCPartitionAllocator::DATABASE_FAILURE;
   }
   IString strDate;
   DateTime hDateTime;
   hDateTime.setCurrent(strDate);
   strcpy(m_psPC_TSTAMP_UPDATE,strDate);
   Table hTable;
   hTable.setName("PARTITION_CONTROL");
   hTable.setQualifier("CUSTQUAL");
   hTable.set("PART_STAT","A",false,false);
   hTable.set("TSTAMP_START",m_psPC_TSTAMP_START,false,false);
   hTable.set("TSTAMP_END",m_psPC_TSTAMP_END,false,false);
   hTable.set("TSTAMP_UPDATE",m_psPC_TSTAMP_UPDATE,false,false);
   hTable.set("TABLE_NAME",m_psPC_TABLE_NAME,false,true);
   hTable.set("PART_NUMBER",(int)m_siPC_PART_NUMBER,true);
   auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if (pUpdateStatement->execute(hTable))
   {
      *piKey = m_siPC_PART_NUMBER;
      Database::instance()->commit();
      return ODBCPartitionAllocator::SUCCESS;
   }
   else
   {
      string strErrorMsg("Error in ODBCPartitionAllocator::update() executing ");
      strErrorMsg += "UPDATE PARTITION_CONTROL SET...";
      reportError(strErrorMsg);
      return ODBCPartitionAllocator::DATABASE_FAILURE;
   }
  //## end dnodbcdatabase::ODBCPartitionAllocator::update%40E30254004E.body
}

void ODBCPartitionAllocator::reportError (string strMessage)
{
  //## begin dnodbcdatabase::ODBCPartitionAllocator::reportError%4113EE2803A9.body preserve=yes
   Database::instance()->traceSQLError(strMessage);
  //## end dnodbcdatabase::ODBCPartitionAllocator::reportError%4113EE2803A9.body
}

// Additional Declarations
  //## begin dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.declarations preserve=yes
  //## end dnodbcdatabase::ODBCPartitionAllocator%40E301D300BB.declarations

} // namespace dnodbcdatabase

//## begin module%40E3058002CE.epilog preserve=yes
//## end module%40E3058002CE.epilog
