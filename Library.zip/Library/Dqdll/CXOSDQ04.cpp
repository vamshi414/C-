//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%40E303C9008C.cm preserve=no
//	$Date:   Sep 30 2021 10:04:40  $ $Author:   e3019097  $
//	$Revision:   1.69  $
//## end module%40E303C9008C.cm

//## begin module%40E303C9008C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%40E303C9008C.cp

//## Module: CXOSDQ04%40E303C9008C; Package body
//## Subsystem: DQDLL%40852BF400DA
//## Source file: c:\Library\Dqdll\CXOSDQ04.cpp

//## begin module%40E303C9008C.additionalIncludes preserve=no
//## end module%40E303C9008C.additionalIncludes

//## begin module%40E303C9008C.includes preserve=yes
#define STS_DUPLICATE_RECORD 35
#define PRIMARY_KEY_DUPLICATE 1
#define STS_UNDEFINED_NAME 92
#include "CXODRU54.hpp"
#include "CXODRSC2.hpp"
//## end module%40E303C9008C.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSPC01_h
#include "CXODPC01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRS38_h
#include "CXODRS38.hpp"
#endif
#ifndef CXOSRS39_h
#include "CXODRS39.hpp"
#endif
#ifndef CXOSRS41_h
#include "CXODRS41.hpp"
#endif
#ifndef CXOSRS40_h
#include "CXODRS40.hpp"
#endif
#ifndef CXOSRS37_h
#include "CXODRS37.hpp"
#endif
#ifndef CXOSRS36_h
#include "CXODRS36.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSDB30_h
#include "CXODDB30.hpp"
#endif
#ifndef CXOSRS70_h
#include "CXODRS70.hpp"
#endif
#ifndef CXOSRS76_h
#include "CXODRS76.hpp"
#endif
#ifndef CXOSRS80_h
#include "CXODRS80.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDQ04_h
#include "CXODDQ04.hpp"
#endif


//## begin module%40E303C9008C.declarations preserve=no
//## end module%40E303C9008C.declarations

//## begin module%40E303C9008C.additionalDeclarations preserve=yes
//## end module%40E303C9008C.additionalDeclarations


//## Modelname: DataNavigator Foundation::DNODBCDatabase_CAT%40852B18035B
namespace dnodbcdatabase {
//## begin dnodbcdatabase%40852B18035B.initialDeclarations preserve=yes
//## end dnodbcdatabase%40852B18035B.initialDeclarations

// Class dnodbcdatabase::ODBCAddFinancialCommand

ODBCAddFinancialCommand::ODBCAddFinancialCommand()
  //## begin ODBCAddFinancialCommand::ODBCAddFinancialCommand%40E30434001F_const.hasinit preserve=no
      : m_lFIN_INSERT_SEQUENCE_NO(0)
  //## end ODBCAddFinancialCommand::ODBCAddFinancialCommand%40E30434001F_const.hasinit
  //## begin ODBCAddFinancialCommand::ODBCAddFinancialCommand%40E30434001F_const.initialization preserve=yes
  //## end ODBCAddFinancialCommand::ODBCAddFinancialCommand%40E30434001F_const.initialization
{
  //## begin dnodbcdatabase::ODBCAddFinancialCommand::ODBCAddFinancialCommand%40E30434001F_const.body preserve=yes
   memcpy(m_sID,"DQ04",4);
   m_lUNIQUENESS_KEY = 0;
   m_lFIN_PARTITION_KEY = 0;
   memset(m_pzACCT_ID_1, '\0', sizeof(m_pzACCT_ID_1));
   memset(m_pzFIN_TYPE, '\0', sizeof(m_pzFIN_TYPE));
   m_pInsertStatement[0] = ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   m_pInsertStatement[1] = ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   m_pInsertStatement[2] = ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   m_pUpdateStatement = ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
  //## end dnodbcdatabase::ODBCAddFinancialCommand::ODBCAddFinancialCommand%40E30434001F_const.body
}


ODBCAddFinancialCommand::~ODBCAddFinancialCommand()
{
  //## begin dnodbcdatabase::ODBCAddFinancialCommand::~ODBCAddFinancialCommand%40E30434001F_dest.body preserve=yes
   delete m_pUpdateStatement;
   delete m_pInsertStatement[2];
   delete m_pInsertStatement[1];
   delete m_pInsertStatement[0];
  //## end dnodbcdatabase::ODBCAddFinancialCommand::~ODBCAddFinancialCommand%40E30434001F_dest.body
}



//## Other Operations (implementation)
bool ODBCAddFinancialCommand::execute ()
{
  //## begin dnodbcdatabase::ODBCAddFinancialCommand::execute%40E30EF60232.body preserve=yes
   if (Database::instance()->getDormant())
      Database::instance()->connect();
   if (Database::instance()->state() == Database::DISCONNECTED)
   {
      UseCase::add("CONNECT");
      return false;
   }
   FinancialBaseSegment* pBaseSegment = FinancialBaseSegment::instance();
   bool bLateReversal = false;
   if (memcmp(DataModel::instance()->getCurrent().data(),pBaseSegment->zTSTAMP_TRANS(),6) > 0 &&
      (memcmp(pBaseSegment->zTRAN_DISPOSITION(), "3", 1) == 0 || memcmp(pBaseSegment->zACT_CODE(), "4", 1) == 0))
   {
      pBaseSegment->setTSTAMP_TRANS(Clock::instance()->getYYYYMMDDHHMMSSHN(true).data(),16);
      bLateReversal = true;
   }
   FinancialAdjustmentSegment* pFinancialAdjustmentSegment = FinancialAdjustmentSegment::instance();
   FinancialAdjustmentExtensionSegment* pFinancialAdjustmentExtensionSegment =  FinancialAdjustmentExtensionSegment::instance();
   FinancialFeeSegment* pFinancialFeeSegment = FinancialFeeSegment::instance();
   FinancialReversalSegment* pFinancialReversalSegment = FinancialReversalSegment::instance();
   FinancialSettlementSegment* pFinancialSettlementSegment = FinancialSettlementSegment::instance();
   FinancialUserSegment* pFinancialUserSegment = FinancialUserSegment::instance();
   IntegratedCircuitCardSegment* pIntegratedCircuitCardSegment = IntegratedCircuitCardSegment::instance();
   MultipleRouteSegment* pMultipleRouteSegment = MultipleRouteSegment::instance();
   if (!pFinancialAdjustmentSegment->presence())
      pFinancialAdjustmentSegment->reset();
   if (!pFinancialAdjustmentExtensionSegment->presence())
      pFinancialAdjustmentExtensionSegment->reset();
   if (!pFinancialFeeSegment->presence())
      pFinancialFeeSegment->reset();
   if (!pFinancialReversalSegment->presence())
      pFinancialReversalSegment->reset();
   if (!pFinancialSettlementSegment->presence())
      pFinancialSettlementSegment->reset();
   if (!pFinancialUserSegment->presence())
      FinancialUserSegment::instance()->reset();
   if (!pIntegratedCircuitCardSegment->presence())
      IntegratedCircuitCardSegment::instance()->reset();
   if (!pMultipleRouteSegment->presence())
      MultipleRouteSegment::instance()->reset();
   pBaseSegment->reverseShift();
   pFinancialAdjustmentSegment->reverseShift();
   pFinancialAdjustmentExtensionSegment->reverseShift();
   pFinancialFeeSegment->reverseShift();
   pFinancialReversalSegment->reverseShift();
   pFinancialSettlementSegment->reverseShift();
   pFinancialUserSegment->reverseShift();
   pIntegratedCircuitCardSegment->reverseShift();
   pMultipleRouteSegment->reverseShift();
   // manually shift MAPPED_DUP_DATA
   string strMAPPED_DUP_DATA(pBaseSegment->zMAPPED_DUP_DATA());
   pBaseSegment->setMAPPED_DUP_DATA(strMAPPED_DUP_DATA);
   // manually shift WLT_ID
   string strWLT_ID(pFinancialUserSegment->zWLT_ID());
   pFinancialUserSegment->setWLT_ID(strWLT_ID);
   char szDate[9] = {"        "};
   memcpy(szDate,pBaseSegment->zTSTAMP_TRANS(),8);
   m_lFIN_PARTITION_KEY = atoi(szDate + 6);
   if (pBaseSegment->getUNIQUENESS_KEY() == 0)
   {
      if (m_lUNIQUENESS_KEY >= 32767)
         m_lUNIQUENESS_KEY = 1;
      else
         ++m_lUNIQUENESS_KEY;
   }
   else
      m_lUNIQUENESS_KEY = pBaseSegment->getUNIQUENESS_KEY();
   // sequence indicates minute load operation occurred
   // format is yyydddhhmm where yyy is year relative to 1997
   // value is zero if Evidence list is present
   // if Evidence list is present and ACQ_PLAT_PROD_ID = 'V' (TC57) then value is -2
   // if Evidence list is not present and ACQ_PLAT_PROD_ID == 'V' then value is -1
   // if Evidence list is present and ACQ_PLAT_PROD_ID != 'V' then value is 0
   // if Evidence list is not present and ACQ_PLAT_PROD_ID != 'V' then assign valid sequence number
   bool bEvidencepresent = m_pListSegment[2]->presence();
   if (!bEvidencepresent)
   {
      for (int i = 0; i < 2; i++)
      {
         if (m_pListSegment[i]->presence())
         {
            char* p = (char*)*m_pListSegment[i];
            if (!memcmp(p, (const char*)"S235",4))
            {
               bEvidencepresent = true;
               break;
            }
         }
      }
   }
   string strCustomCode = Extract::instance()->getCustomCode();
   if (bEvidencepresent)
   {
      if (!memcmp(pBaseSegment->zACQ_PLAT_PROD_ID(),"V",1) && (strCustomCode == "USPS" || strCustomCode == "KFH"))
         m_lFIN_INSERT_SEQUENCE_NO = -2;
      else
         m_lFIN_INSERT_SEQUENCE_NO = 0;
   }
   else
   {
      if (!memcmp(pBaseSegment->zACQ_PLAT_PROD_ID(),"V",1) && (strCustomCode == "USPS" || strCustomCode == "KFH"))
         m_lFIN_INSERT_SEQUENCE_NO = -1;
      else
      if (bLateReversal)
         m_lFIN_INSERT_SEQUENCE_NO = 0;
      else
         m_lFIN_INSERT_SEQUENCE_NO = InsertSequenceNumber::getYYYDDDHHMM((char * const)pBaseSegment->zTSTAMP_TRANS());
   }
   if (( memcmp(pBaseSegment->zFIN_TYPE(),"800",3) < 0
      && memcmp(pBaseSegment->zFIN_TYPE(),"025",3) > 0)
      || (memcmp(pBaseSegment->zTRAN_DISPOSITION(),"3",1) == 0)
      || m_bUpdate)
   {
      //test if record already exists
      if (selectRecord())
      {
         if ((memcmp(FinancialBaseSegment::instance()->zFIN_TYPE(),m_pzFIN_TYPE,3) > 0)
            || m_bUpdate)
         {
            memcpy(m_pzFIN_TYPE,FinancialBaseSegment::instance()->zFIN_TYPE(),sizeof(m_pzFIN_TYPE));
            memcpy(m_pzACCT_ID_1,FinancialBaseSegment::instance()->zACCT_ID_1(),sizeof(m_pzACCT_ID_1));
            if (updateRecord()) // do an update instead of insert
            {
               UseCase::addItem();
               return true;
            }
            else
            {
               char szErrorMsg[256];
               int iLen = snprintf(szErrorMsg,sizeof(szErrorMsg),"ODBCAddFinancialCommand::execute() - updateRecord() failed for transaction with TSTAMP_TRANS = %s, UNIQUENESS_KEY = %hd",
                  pBaseSegment->zTSTAMP_TRANS(),pBaseSegment->getUNIQUENESS_KEY());
               Trace::put(szErrorMsg,iLen,true);
               UseCase::add("DBERROR");
               log("LE FAILURE","P0000");
               return true;
            }
         }
         else
         {
            char szDupMsg[512];
            int iLen = snprintf(szDupMsg,sizeof(szDupMsg),
               "ODBCAddFinancialCommand::execute() - updateRecord() **DUPLICATE** transaction found with TSTAMP_TRANS = %s, UNIQUENESS_KEY = %hd "
               "TSTAMP_LOCAL = %s, MAPPED_DUP_DATA = %s, NET_TERM_ID = %s, PAN = %s, RETRIEVAL_REF_NO = %s, TRAN_TYPE_ID = %s "
               "SYS_TRACE_AUDIT_NO = %s, TRAN_DISPOSITION = %s, AUTH_BY = %s, CARD_ACPT_TERM_ID = %s",
               pBaseSegment->zTSTAMP_TRANS(),
               pBaseSegment->getUNIQUENESS_KEY(),
               pBaseSegment->getTSTAMP_LOCAL().c_str(),
               pBaseSegment->getMAPPED_DUP_DATA().c_str(),
               pBaseSegment->getNET_TERM_ID().c_str(),
               pBaseSegment->getPAN().c_str(),
               pBaseSegment->getRETRIEVAL_REF_NO().c_str(),
               pBaseSegment->getTRAN_TYPE_ID().c_str(),
               pBaseSegment->getSYS_TRACE_AUDIT_NO().c_str(),
               pBaseSegment->getTRAN_DISPOSITION().c_str(),
               pBaseSegment->getAUTH_BY().c_str(),
               pBaseSegment->getCARD_ACPT_TERM_ID().c_str());
            Trace::put(szDupMsg,iLen,true);
            UseCase::add("DUPLICAT");
            return true;
         }
      }
   }
   // do insert of record
   pBaseSegment->setUNIQUENESS_KEY(m_lUNIQUENESS_KEY);
   m_nTransaction = Database::instance()->transaction();
   int iLoop = 0;
   while (iLoop++ < 32768)
   {
      int i = insertRecord();
      if (i == 1)
         return true;
      if (i == -1)
      {
         char szErrorMsg[256];
         int iLen = snprintf(szErrorMsg,sizeof(szErrorMsg),"ODBCAddFinancialCommand::execute() - insertRecord() failed for transaction with TSTAMP_TRANS = %s, UNIQUENESS_KEY = %hd",pBaseSegment->zTSTAMP_TRANS(),m_lUNIQUENESS_KEY);
         Trace::put(szErrorMsg,iLen,true);
         UseCase::add("DBERROR");
         return UseCase::setSuccess(false);
      }
   }
   return UseCase::setSuccess(false);
  //## end dnodbcdatabase::ODBCAddFinancialCommand::execute%40E30EF60232.body
}

int ODBCAddFinancialCommand::insertRecord ()
{
  //## begin dnodbcdatabase::ODBCAddFinancialCommand::insertRecord%40FEBC740157.body preserve=yes
   FinancialBaseSegment* pBaseSegment = FinancialBaseSegment::instance();
   // FIN_Lyyyymm
   char szTableName[32] = {"FIN_L"};
   memcpy(szTableName + 5,pBaseSegment->getTSTAMP_TRANS().data(),6);
   szTableName[11] = '\0';
   m_hTable[FIN_L].setName(szTableName);
   pBaseSegment->setColumns(m_hTable[FIN_L],true);
   m_hTable[FIN_L].set("ACCT_ID_1",pBaseSegment->getACCT_ID_1());
   m_hTable[FIN_L].set("MERCH_TYPE",pBaseSegment->getMERCH_TYPE());
   m_hTable[FIN_L].set("DATE_RECON_ACQ",pBaseSegment->getDATE_RECON_ACQ());
   m_hTable[FIN_L].set("DATE_RECON_ISS",FinancialSettlementSegment::instance()->getDATE_RECON_ISS());
   m_hTable[FIN_L].set("PAN_TOKEN",FinancialUserSegment::instance()->getPAN_TOKEN());
   m_hTable[FIN_L].set("CARD_ACPT_BUS_CODE",pBaseSegment->getCARD_ACPT_BUS_CODE());
   m_hTable[FIN_L].set("COUNTRY_ACQ_INST",pBaseSegment->getCOUNTRY_ACQ_INST());
   m_hTable[FIN_L].set("TRAN_DISPOSITION",pBaseSegment->getTRAN_DISPOSITION());
   m_hTable[FIN_L].set("CARD_ACPT_ID",FinancialSettlementSegment::instance()->getCARD_ACPT_ID());
   m_hTable[FIN_L].set("POS_CRD_DAT_IN_MOD",FinancialSettlementSegment::instance()->getPOS_CRD_DAT_IN_MOD());
   int iBIN_LENGTH = FinancialUserSegment::instance()->getBIN_LENGTH();
   int iPAN_TOKEN_BIN_LEN = FinancialUserSegment::instance()->getPAN_TOKEN_BIN_LEN();
   string strPAN(pBaseSegment->getPAN());
   rtrim(strPAN);
   if (strPAN.length() > 6)
   {
       if (iBIN_LENGTH > 6 && iBIN_LENGTH <= 8)
           m_hTable[FIN_L].set("PAN_PREFIX",strPAN.substr(0,iBIN_LENGTH));
      else
         m_hTable[FIN_L].set("PAN_PREFIX",strPAN.substr(0,6));
   }
   else
      m_hTable[FIN_L].set("PAN_PREFIX",strPAN);
   if (strPAN.length() > 4)
      m_hTable[FIN_L].set("PAN_SUFFIX",strPAN.substr(strPAN.length() - 4,4));
   else
      m_hTable[FIN_L].set("PAN_SUFFIX","9999");
   string strPAN_TOKEN(FinancialUserSegment::instance()->getPAN_TOKEN());
   rtrim(strPAN_TOKEN);
   if (!strPAN_TOKEN.empty())
   {
      if (strPAN_TOKEN.length() > 6)
      {
         if (iPAN_TOKEN_BIN_LEN > 6 && iPAN_TOKEN_BIN_LEN <= 8)
            m_hTable[FIN_L].set("PAN_TOKEN_PREFIX",strPAN_TOKEN.substr(0,iPAN_TOKEN_BIN_LEN));
         else
            m_hTable[FIN_L].set("PAN_TOKEN_PREFIX",strPAN_TOKEN.substr(0,6));
      }
      else
         m_hTable[FIN_L].set("PAN_TOKEN_PREFIX",strPAN_TOKEN);
      if (strPAN_TOKEN.length() > 4)
         m_hTable[FIN_L].set("PAN_TOKEN_SUFFIX",strPAN_TOKEN.substr(strPAN_TOKEN.length() - 4,4));
      else
         m_hTable[FIN_L].set("PAN_TOKEN_SUFFIX","9999");
   }
   else
   {
      m_hTable[FIN_L].set("PAN_TOKEN_PREFIX","");
      m_hTable[FIN_L].set("PAN_TOKEN_SUFFIX","");
   }
   string strINV_ORDER_NO;
   if (FinancialSettlementSegment::instance()->getSizeofTRAN_DESC() >= 5
      && memcmp(FinancialSettlementSegment::instance()->zTRAN_DESC(),"72  ",4) == 0)
   {
      int i = FinancialSettlementSegment::instance()->getSizeofTRAN_DESC() - 4;
      if (i > 15)
         i = 15;
      strINV_ORDER_NO.assign(FinancialSettlementSegment::instance()->zTRAN_DESC() + 4,i);
   }
   m_hTable[FIN_L].set("INV_ORDER_NO",strINV_ORDER_NO);
   if (!m_pInsertStatement[0]->execute(m_hTable[FIN_L]))
   {
      if (m_pInsertStatement[0]->getInfoIDNumber() == STS_DUPLICATE_RECORD)
      {
         if (m_pInsertStatement[0]->getErrorType() == PRIMARY_KEY_DUPLICATE)
         {
            if (m_lUNIQUENESS_KEY >= 32767)
               m_lUNIQUENESS_KEY = 1;
            else
               ++m_lUNIQUENESS_KEY;
            pBaseSegment->setUNIQUENESS_KEY(m_lUNIQUENESS_KEY);
            return 0;
         }
         return 1;
      }
      else
      if (m_pInsertStatement[0]->getInfoIDNumber() == STS_UNDEFINED_NAME )
      {
         if (pBaseSegment->getTSTAMP_TRANS() == Clock::instance()->getYYYYMMDDHHMMSSHN(false))
            return -1;
         pBaseSegment->setTSTAMP_TRANS(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
         pBaseSegment->setTSTAMP_TRANS(pBaseSegment->getTSTAMP_TRANS().data(),16);
         m_lFIN_INSERT_SEQUENCE_NO = 0;
         return 0;
      }
      return -1;
   }
   // FIN_ICCyyyymm
   if (IntegratedCircuitCardSegment::instance()->presence())
   {
      memcpy(szTableName,"FIN_ICC",7);
      memcpy(szTableName + 7,pBaseSegment->getTSTAMP_TRANS().data(),6);
      szTableName[13] = '\0';
      m_hTable[FIN_ICC].setName(szTableName);
      m_hTable[FIN_ICC].setQualifier(Database::instance()->qualifier());
      IntegratedCircuitCardSegment::instance()->setColumns(m_hTable[FIN_ICC],false);
      m_hTable[FIN_ICC].set("TSTAMP_TRANS",pBaseSegment->getTSTAMP_TRANS());
      m_hTable[FIN_ICC].set("UNIQUENESS_KEY",(int)m_lUNIQUENESS_KEY);
      if (!m_pInsertStatement[2]->execute(m_hTable[FIN_ICC]))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         return -1;
      }
   }
   if (MultipleRouteSegment::instance()->presence())
   {
      memcpy(szTableName,"FIN_ROUTE",9);
      memcpy(szTableName + 9,pBaseSegment->getTSTAMP_TRANS().data(),6);
      szTableName[15] = '\0';
      m_hTable[FIN_ROUTE].setName(szTableName);
      MultipleRouteSegment::instance()->setColumns(m_hTable[FIN_ROUTE],false);
      m_hTable[FIN_ROUTE].set("TSTAMP_TRANS",pBaseSegment->getTSTAMP_TRANS());
      m_hTable[FIN_ROUTE].set("UNIQUENESS_KEY",(int)m_lUNIQUENESS_KEY);
      if (!m_pInsertStatement[2]->execute(m_hTable[FIN_ROUTE]))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         return -1;
      }
   }
   //FIN_FRAUD_RULE_yyyymm
   if (m_pListSegment[0]->presence())
   {
      char* p = (char*)*m_pListSegment[0];
      if (!memcmp(p,(const char*)"S231",4))
      {
         FraudBlockSegment hFraudBlockSegment;
         memcpy(szTableName,"FIN_FRAUD_RULE_",15);
         memcpy(szTableName + 15,pBaseSegment->getTSTAMP_TRANS().data(),6);
         szTableName[21] = '\0';
         m_hTable[FIN_FRAUD_RULE].setName(szTableName);
         char* psBuffer = (char*)*(m_pListSegment[0]);
         for (int i = 0;i < m_pListSegment[0]->itemCount();++i)
         {
            if (hFraudBlockSegment.read(&psBuffer))
            {
               return -1;
            }
            hFraudBlockSegment.setUNIQUENESS_KEY(m_lUNIQUENESS_KEY);
            hFraudBlockSegment.setColumns(m_hTable[FIN_FRAUD_RULE],false);
            if (!m_pInsertStatement[2]->execute(m_hTable[FIN_FRAUD_RULE]))
            {
               Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
               return -1;
            }
         }
      }
   }
   // FIN_RECORDyyyymm
   memcpy(szTableName,"FIN_RECORD",10);
   memcpy(szTableName + 10,pBaseSegment->getTSTAMP_TRANS().data(),6);
   szTableName[16] = '\0';
   m_hTable[FIN_RECORD].setName(szTableName);
   pBaseSegment->setColumns(m_hTable[FIN_RECORD],false);
   // manually set columns that are contained in locator record
   m_strTSTAMP_TRANS = pBaseSegment->getTSTAMP_TRANS();
   m_hTable[FIN_RECORD].set("AMT_RECON_NET",pBaseSegment->getAMT_RECON_NET());
   m_hTable[FIN_RECORD].set("CUR_RECON_NET",pBaseSegment->getCUR_RECON_NET());
   m_hTable[FIN_RECORD].set("FUNC_CODE",pBaseSegment->getFUNC_CODE()),
   m_hTable[FIN_RECORD].set("TSTAMP_TRANS",m_strTSTAMP_TRANS);
   // manually set INSERT_SEQUENCE_NO,UNIQUENESS_KEY, and PARTITION_KEY
   // because they are generated fields
   m_hTable[FIN_RECORD].set("INSERT_SEQUENCE_NO",m_lFIN_INSERT_SEQUENCE_NO);
   m_hTable[FIN_RECORD].set("UNIQUENESS_KEY",(int)m_lUNIQUENESS_KEY);
   m_hTable[FIN_RECORD].set("PARTITION_KEY",(int)m_lFIN_PARTITION_KEY);
   // set the rest of the columns from the other segments
   FinancialSettlementSegment::instance()->setColumns(m_hTable[FIN_RECORD],false);
   FinancialUserSegment::instance()->setColumns(m_hTable[FIN_RECORD],false);
   FinancialReversalSegment::instance()->setColumns(m_hTable[FIN_RECORD],false);
   FinancialFeeSegment::instance()->setColumns(m_hTable[FIN_RECORD],false);
   FinancialAdjustmentSegment::instance()->setColumns(m_hTable[FIN_RECORD],false);
   FinancialAdjustmentExtensionSegment::instance()->setColumns(m_hTable[FIN_RECORD],false);
   if (m_pInsertStatement[1]->execute(m_hTable[FIN_RECORD]) == false
      || AddFinancialCommand::execute() == false)
   {
      Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
      return -1;
   }
   return 1;
  //## end dnodbcdatabase::ODBCAddFinancialCommand::insertRecord%40FEBC740157.body
}

bool ODBCAddFinancialCommand::selectRecord ()
{
  //## begin dnodbcdatabase::ODBCAddFinancialCommand::selectRecord%40FEBC490109.body preserve=yes
   FinancialBaseSegment* pBaseSegment = FinancialBaseSegment::instance();
   string strTableName("FIN_L");
   strTableName += pBaseSegment->getTSTAMP_TRANS().substr(0,6);
   Query hQuery;
   string strFIN_TYPE;
   string strACCT_ID_1;
   short int lUNIQUENESS_KEY = 0;
   hQuery.setQualifier("CUSTQUAL",strTableName.c_str());
   hQuery.bind(strTableName.c_str(),"TSTAMP_TRANS",Column::STRING,&m_strTSTAMP_TRANS);
   hQuery.bind(strTableName.c_str(),"FIN_TYPE",Column::STRING,&strFIN_TYPE);
   hQuery.bind(strTableName.c_str(),"ACCT_ID_1",Column::STRING,&strACCT_ID_1);
   hQuery.bind(strTableName.c_str(),"UNIQUENESS_KEY",Column::SHORT,&lUNIQUENESS_KEY);
   hQuery.setBasicPredicate(strTableName.c_str(),"TSTAMP_LOCAL","=", pBaseSegment->getTSTAMP_LOCAL().c_str());
   hQuery.setBasicPredicate(strTableName.c_str(),"MAPPED_DUP_DATA","=", pBaseSegment->getMAPPED_DUP_DATA().c_str());
   hQuery.setBasicPredicate(strTableName.c_str(),"NET_TERM_ID","=", pBaseSegment->getNET_TERM_ID().c_str());
   hQuery.setBasicPredicate(strTableName.c_str(),"PAN","=", pBaseSegment->getPAN().c_str());
   hQuery.setBasicPredicate(strTableName.c_str(),"RETRIEVAL_REF_NO","=", pBaseSegment->getRETRIEVAL_REF_NO().c_str());
   if (pBaseSegment->getACT_CODE() != "400")
      hQuery.setBasicPredicate(strTableName.c_str(),"TRAN_TYPE_ID","=", pBaseSegment->getTRAN_TYPE_ID().c_str());
   hQuery.setBasicPredicate(strTableName.c_str(),"SYS_TRACE_AUDIT_NO","=", pBaseSegment->getSYS_TRACE_AUDIT_NO().c_str());
   hQuery.setBasicPredicate(strTableName.c_str(),"TRAN_DISPOSITION","=", pBaseSegment->getTRAN_DISPOSITION().c_str());
   hQuery.setBasicPredicate(strTableName.c_str(),"AUTH_BY","=", pBaseSegment->getAUTH_BY().c_str());
   hQuery.setBasicPredicate(strTableName.c_str(),"CARD_ACPT_TERM_ID","=", pBaseSegment->getCARD_ACPT_TERM_ID().c_str());
   hQuery.setBasicPredicate(strTableName.c_str(),"AMT_RECON_NET", "=", pBaseSegment->getAMT_RECON_NET());
   auto_ptr<SelectStatement> pSelectStatement ((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == false
      || pSelectStatement->getRows() == 0)
      return false;
   pBaseSegment->setUNIQUENESS_KEY(lUNIQUENESS_KEY);
   memset(m_pzFIN_TYPE,' ',3);
   memcpy(m_pzFIN_TYPE,strFIN_TYPE.data(),strFIN_TYPE.length());
   m_pzFIN_TYPE[3] = '\0';
   memset(m_pzACCT_ID_1,' ',28);
   memcpy(m_pzACCT_ID_1,strACCT_ID_1.data(),strACCT_ID_1.length());
   m_pzACCT_ID_1[28] = '\0';
   return true;
  //## end dnodbcdatabase::ODBCAddFinancialCommand::selectRecord%40FEBC490109.body
}

bool ODBCAddFinancialCommand::updateRecord ()
{
  //## begin dnodbcdatabase::ODBCAddFinancialCommand::updateRecord%40FEBC670399.body preserve=yes
   UseCase hUseCase("DR","## DR09 UPDATE FINANCIAL");
   FinancialBaseSegment* pBaseSegment = FinancialBaseSegment::instance();
   // update the locator
   string strTableName("FIN_L");
   strTableName += pBaseSegment->getTSTAMP_TRANS().substr(0,6);
   Table hTable(strTableName.c_str());
   hTable.setQualifier(Database::instance()->qualifier());
   if (m_bUpdate)
   {
      pBaseSegment->setColumns(hTable,true);
      string strPAN(pBaseSegment->getPAN());
      if (strPAN.length() > 6)
         hTable.set("PAN_PREFIX", strPAN.substr(0, 6));
      else
         hTable.set("PAN_PREFIX", strPAN);
      if (strPAN.length() > 4)
         hTable.set("PAN_SUFFIX", strPAN.substr(strPAN.length() - 4, 4));
      else
         hTable.set("PAN_SUFFIX", "9999");
      string strPAN_TOKEN(FinancialUserSegment::instance()->getPAN_TOKEN());
      if (!strPAN_TOKEN.empty())
      {
         if (strPAN_TOKEN.length() > 6)
            hTable.set("PAN_TOKEN_PREFIX", strPAN_TOKEN.substr(0, 6));
         else
            hTable.set("PAN_TOKEN_PREFIX", strPAN_TOKEN);
         if (strPAN_TOKEN.length() > 4)
            hTable.set("PAN_TOKEN_SUFFIX", strPAN_TOKEN.substr(strPAN_TOKEN.length() - 4, 4));
         else
            hTable.set("PAN_TOKEN_SUFFIX", "9999");
      }
      else
      {
         hTable.set("PAN_TOKEN_PREFIX","");
         hTable.set("PAN_TOKEN_SUFFIX","");
      }
   }
   hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int)pBaseSegment->getUNIQUENESS_KEY(),true);
   hTable.set("FIN_TYPE",m_pzFIN_TYPE);
   hTable.set("ACCT_ID_1",m_pzACCT_ID_1);
   if(pBaseSegment->getMEMBER_ID().length())
      hTable.set("MEMBER_ID",pBaseSegment->getMEMBER_ID());
   if (m_pUpdateStatement->execute(hTable) == false
   && m_pUpdateStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
      return UseCase::setSuccess(false);
   // update the financial record
   hTable.reset();
   strTableName = "FIN_RECORD";
   strTableName += pBaseSegment->getTSTAMP_TRANS().substr(0,6);
   hTable.setName(strTableName);
   hTable.setQualifier(Database::instance()->qualifier());
   pBaseSegment->setColumns(hTable,false);
   // manually set AMT_RECON_NET, and TSTAMP_TRANS columns
   // because they are not handled by setColumns() because they
   // are also contained in the locator record.
   hTable.set("AMT_RECON_NET",pBaseSegment->getAMT_RECON_NET(),0);
   hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
   //manually set PARTITION_KEY and UNIQUENESS_KEY because they are generated fields
   hTable.set("PARTITION_KEY",(int)m_lFIN_PARTITION_KEY);
   hTable.set("UNIQUENESS_KEY",(int)pBaseSegment->getUNIQUENESS_KEY(),true);
   // set the rest of the columns from the other segments
   hTable.set("ACCT_ID_1",m_pzACCT_ID_1);
   FinancialSettlementSegment::instance()->setColumns(hTable,false);
   FinancialUserSegment::instance()->setColumns(hTable,false);
   FinancialReversalSegment::instance()->setColumns(hTable,false);
   FinancialFeeSegment::instance()->setColumns(hTable,false);
   FinancialAdjustmentSegment::instance()->setColumns(hTable,false);
   FinancialAdjustmentExtensionSegment::instance()->setColumns(hTable,false);
   if (!m_pUpdateStatement->execute(hTable))
   {
      Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
      return UseCase::setSuccess(false);
   }
   if (FinancialAPSegment::instance()->presence())
   {
      FinancialAPSegment::instance()->reverseShift();
      string strTableName = "FIN_AP" + pBaseSegment->getTSTAMP_TRANS().substr(0, 6);
      Table hTable(strTableName.data());
      FinancialAPSegment::instance()->setColumns(hTable, false);
      hTable.set("TSTAMP_TRANS", pBaseSegment->getTSTAMP_TRANS(), false, true);
      hTable.set("UNIQUENESS_KEY", pBaseSegment->getUNIQUENESS_KEY(), true);
      auto_ptr<Statement> pMergeStatement((Statement*)DatabaseFactory::instance()->create("MergeStatement"));
      if (!pMergeStatement->execute(hTable))
         return UseCase::setSuccess(false);
   }
   return true;
  //## end dnodbcdatabase::ODBCAddFinancialCommand::updateRecord%40FEBC670399.body
}

// Additional Declarations
  //## begin dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.declarations preserve=yes
  //## end dnodbcdatabase::ODBCAddFinancialCommand%40E30434001F.declarations

} // namespace dnodbcdatabase

//## begin module%40E303C9008C.epilog preserve=yes
//## end module%40E303C9008C.epilog
