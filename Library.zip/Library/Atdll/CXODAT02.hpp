//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C49C83C00B7.cm preserve=no
//	$Date:   Jan 29 2020 16:20:42  $ $Author:   e1009839  $
//	$Revision:   1.6  $
//## end module%5C49C83C00B7.cm

//## begin module%5C49C83C00B7.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C49C83C00B7.cp

//## Module: CXOSAT02%5C49C83C00B7; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Atdll\CXODAT02.hpp

#ifndef CXOSAT02_h
#define CXOSAT02_h 1

//## begin module%5C49C83C00B7.additionalIncludes preserve=no
//## end module%5C49C83C00B7.additionalIncludes

//## begin module%5C49C83C00B7.includes preserve=yes
//## end module%5C49C83C00B7.includes

#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif
#ifndef CXOSAT03_h
#include "CXODAT03.hpp"
#endif

//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
class ATMBusinessDayVisitor;

} // namespace atm

//## begin module%5C49C83C00B7.declarations preserve=no
//## end module%5C49C83C00B7.declarations

//## begin module%5C49C83C00B7.additionalDeclarations preserve=yes
//## end module%5C49C83C00B7.additionalDeclarations


namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::ATMEvent%5C49C6A00245.preface preserve=yes
//## end atm::ATMEvent%5C49C6A00245.preface

//## Class: ATMEvent%5C49C6A00245
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5C49EB88009B;ATMBusinessDayVisitor { -> F}

class DllExport ATMEvent : public segment::PersistentSegment  //## Inherits: <unnamed>%5C4B841300E2
{
  //## begin atm::ATMEvent%5C49C6A00245.initialDeclarations preserve=yes
  //## end atm::ATMEvent%5C49C6A00245.initialDeclarations

  public:
    //## Constructors (generated)
      ATMEvent();

      ATMEvent(const ATMEvent &right);

    //## Destructor (generated)
      virtual ~ATMEvent();

    //## Assignment Operation (generated)
      ATMEvent & operator=(const ATMEvent &right);

    //## Equality Operations (generated)
      bool operator==(const ATMEvent &right) const;

      bool operator!=(const ATMEvent &right) const;


    //## Other Operations (specified)
      //## Operation: accept%5C49ED1801B2
      void accept (atm::ATMBusinessDayVisitor& hATMBusinessDayVisitor);

      //## Operation: getCASSETTEn_BEGIN%5D0275D802F1
      double getCASSETTEn_BEGIN (int iIndex);

      //## Operation: getCASSETTEn_CUR_CODE%5DB88C8B0004
      const reusable::string& getCASSETTEn_CUR_CODE (int iIndex);

      //## Operation: getCASSETTEn_CUR_TYPE%5DB88CB30181
      short int getCASSETTEn_CUR_TYPE (int iIndex);

      //## Operation: getCASSETTEn_END%5D0275FE0074
      double getCASSETTEn_END (int iIndex);

      //## Operation: getCASSETTEn_VALUE%5DB88CC5029F
      int getCASSETTEn_VALUE (int iIndex);

      //## Operation: getCassetteCount%5DBC3849026F
      int getCassetteCount (int iIndex);

      //## Operation: fields%5C4B84B60198
      virtual struct  Fields* fields () const;

      //## Operation: setCASSETTEn_BEGIN%5D02770902A8
      void setCASSETTEn_BEGIN (int iIndex, double dCASSETTEn_BEGIN);

      //## Operation: setCASSETTEn_CUR_CODE%5DB88D1D021D
      void setCASSETTEn_CUR_CODE (int iIndex, const reusable::string& strCASSETTEn_CUR_CODE);

      //## Operation: setCASSETTEn_CUR_TYPE%5DB88D29025F
      void setCASSETTEn_CUR_TYPE (int iIndex, short int siCASSETTEn_CUR_TYPE);

      //## Operation: setCASSETTEn_END%5D02A0D801C2
      void setCASSETTEn_END (int iIndex, double dCASSETTEn_END);

      //## Operation: setCASSETTEn_VALUE%5DB88D33019E
      void setCASSETTEn_VALUE (int iIndex, int iCASSETTEn_VALUE);

      //## Operation: setCassetteCount%5DBC90D1016C
      void setCassetteCount (int iIndex, int iCassetteCount);

      //## Operation: setFields%5D7915D1014A
      void setFields ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: AE_STATE%5C4F5B5E0008
      const reusable::string& getAE_STATE () const
      {
        //## begin atm::ATMEvent::getAE_STATE%5C4F5B5E0008.get preserve=no
        return m_strAE_STATE;
        //## end atm::ATMEvent::getAE_STATE%5C4F5B5E0008.get
      }

      void setAE_STATE (const reusable::string& value)
      {
        //## begin atm::ATMEvent::setAE_STATE%5C4F5B5E0008.set preserve=no
        m_strAE_STATE = value;
        //## end atm::ATMEvent::setAE_STATE%5C4F5B5E0008.set
      }


      //## Attribute: CASH_BEGIN%5C49DBCD005C
      const double& getCASH_BEGIN () const
      {
        //## begin atm::ATMEvent::getCASH_BEGIN%5C49DBCD005C.get preserve=no
        return m_dCASH_BEGIN;
        //## end atm::ATMEvent::getCASH_BEGIN%5C49DBCD005C.get
      }

      void setCASH_BEGIN (const double& value)
      {
        //## begin atm::ATMEvent::setCASH_BEGIN%5C49DBCD005C.set preserve=no
        m_dCASH_BEGIN = value;
        //## end atm::ATMEvent::setCASH_BEGIN%5C49DBCD005C.set
      }


      //## Attribute: CASH_END%5C49DBE203C5
      const double& getCASH_END () const
      {
        //## begin atm::ATMEvent::getCASH_END%5C49DBE203C5.get preserve=no
        return m_dCASH_END;
        //## end atm::ATMEvent::getCASH_END%5C49DBE203C5.get
      }

      void setCASH_END (const double& value)
      {
        //## begin atm::ATMEvent::setCASH_END%5C49DBE203C5.set preserve=no
        m_dCASH_END = value;
        //## end atm::ATMEvent::setCASH_END%5C49DBE203C5.set
      }


      //## Attribute: CASSETTES_BEGIN%5C5DDC12010E
      const double& getCASSETTES_BEGIN () const
      {
        //## begin atm::ATMEvent::getCASSETTES_BEGIN%5C5DDC12010E.get preserve=no
        return m_dCASSETTES_BEGIN;
        //## end atm::ATMEvent::getCASSETTES_BEGIN%5C5DDC12010E.get
      }

      void setCASSETTES_BEGIN (const double& value)
      {
        //## begin atm::ATMEvent::setCASSETTES_BEGIN%5C5DDC12010E.set preserve=no
        m_dCASSETTES_BEGIN = value;
        //## end atm::ATMEvent::setCASSETTES_BEGIN%5C5DDC12010E.set
      }


      //## Attribute: CASSETTES_END%5C5DDC1300EB
      const double& getCASSETTES_END () const
      {
        //## begin atm::ATMEvent::getCASSETTES_END%5C5DDC1300EB.get preserve=no
        return m_dCASSETTES_END;
        //## end atm::ATMEvent::getCASSETTES_END%5C5DDC1300EB.get
      }

      void setCASSETTES_END (const double& value)
      {
        //## begin atm::ATMEvent::setCASSETTES_END%5C5DDC1300EB.set preserve=no
        m_dCASSETTES_END = value;
        //## end atm::ATMEvent::setCASSETTES_END%5C5DDC1300EB.set
      }


      //## Attribute: CHECK_BEGIN%5C5DDC130295
      const double& getCHECK_BEGIN () const
      {
        //## begin atm::ATMEvent::getCHECK_BEGIN%5C5DDC130295.get preserve=no
        return m_dCHECK_BEGIN;
        //## end atm::ATMEvent::getCHECK_BEGIN%5C5DDC130295.get
      }

      void setCHECK_BEGIN (const double& value)
      {
        //## begin atm::ATMEvent::setCHECK_BEGIN%5C5DDC130295.set preserve=no
        m_dCHECK_BEGIN = value;
        //## end atm::ATMEvent::setCHECK_BEGIN%5C5DDC130295.set
      }


      //## Attribute: CHECK_END%5C5DDC140080
      const double& getCHECK_END () const
      {
        //## begin atm::ATMEvent::getCHECK_END%5C5DDC140080.get preserve=no
        return m_dCHECK_END;
        //## end atm::ATMEvent::getCHECK_END%5C5DDC140080.get
      }

      void setCHECK_END (const double& value)
      {
        //## begin atm::ATMEvent::setCHECK_END%5C5DDC140080.set preserve=no
        m_dCHECK_END = value;
        //## end atm::ATMEvent::setCHECK_END%5C5DDC140080.set
      }


      //## Attribute: CUR_CODE%5C49DBC1010A
      const reusable::string& getCUR_CODE () const
      {
        //## begin atm::ATMEvent::getCUR_CODE%5C49DBC1010A.get preserve=no
        return m_strCUR_CODE;
        //## end atm::ATMEvent::getCUR_CODE%5C49DBC1010A.get
      }

      void setCUR_CODE (const reusable::string& value)
      {
        //## begin atm::ATMEvent::setCUR_CODE%5C49DBC1010A.set preserve=no
        m_strCUR_CODE = value;
        //## end atm::ATMEvent::setCUR_CODE%5C49DBC1010A.set
      }


      //## Attribute: DATE_RECON_ACQ%5C51A4AE03CE
      const reusable::string& getDATE_RECON_ACQ () const
      {
        //## begin atm::ATMEvent::getDATE_RECON_ACQ%5C51A4AE03CE.get preserve=no
        return m_strDATE_RECON_ACQ;
        //## end atm::ATMEvent::getDATE_RECON_ACQ%5C51A4AE03CE.get
      }

      void setDATE_RECON_ACQ (const reusable::string& value)
      {
        //## begin atm::ATMEvent::setDATE_RECON_ACQ%5C51A4AE03CE.set preserve=no
        m_strDATE_RECON_ACQ = value;
        //## end atm::ATMEvent::setDATE_RECON_ACQ%5C51A4AE03CE.set
      }


      //## Attribute: FUNCTION_CODE%5C49CE7C038A
      const reusable::string& getFUNCTION_CODE () const
      {
        //## begin atm::ATMEvent::getFUNCTION_CODE%5C49CE7C038A.get preserve=no
        return m_strFUNCTION_CODE;
        //## end atm::ATMEvent::getFUNCTION_CODE%5C49CE7C038A.get
      }

      void setFUNCTION_CODE (const reusable::string& value)
      {
        //## begin atm::ATMEvent::setFUNCTION_CODE%5C49CE7C038A.set preserve=no
        m_strFUNCTION_CODE = value;
        //## end atm::ATMEvent::setFUNCTION_CODE%5C49CE7C038A.set
      }


      //## Attribute: NET_TERM_ID%5C51A4AF00BB
      const reusable::string& getNET_TERM_ID () const
      {
        //## begin atm::ATMEvent::getNET_TERM_ID%5C51A4AF00BB.get preserve=no
        return m_strNET_TERM_ID;
        //## end atm::ATMEvent::getNET_TERM_ID%5C51A4AF00BB.get
      }

      void setNET_TERM_ID (const reusable::string& value)
      {
        //## begin atm::ATMEvent::setNET_TERM_ID%5C51A4AF00BB.set preserve=no
        m_strNET_TERM_ID = value;
        //## end atm::ATMEvent::setNET_TERM_ID%5C51A4AF00BB.set
      }


      //## Attribute: TELLER_BEGIN%5E318E790161
      const double& getTELLER_BEGIN () const
      {
        //## begin atm::ATMEvent::getTELLER_BEGIN%5E318E790161.get preserve=no
        return m_dTELLER_BEGIN;
        //## end atm::ATMEvent::getTELLER_BEGIN%5E318E790161.get
      }

      void setTELLER_BEGIN (const double& value)
      {
        //## begin atm::ATMEvent::setTELLER_BEGIN%5E318E790161.set preserve=no
        m_dTELLER_BEGIN = value;
        //## end atm::ATMEvent::setTELLER_BEGIN%5E318E790161.set
      }


      //## Attribute: TELLER_END%5E318E7B02EB
      const double& getTELLER_END () const
      {
        //## begin atm::ATMEvent::getTELLER_END%5E318E7B02EB.get preserve=no
        return m_dTELLER_END;
        //## end atm::ATMEvent::getTELLER_END%5E318E7B02EB.get
      }

      void setTELLER_END (const double& value)
      {
        //## begin atm::ATMEvent::setTELLER_END%5E318E7B02EB.set preserve=no
        m_dTELLER_END = value;
        //## end atm::ATMEvent::setTELLER_END%5E318E7B02EB.set
      }


      //## Attribute: TASK_TOTALED%5DF394680354
      const reusable::string& getTASK_TOTALED () const
      {
        //## begin atm::ATMEvent::getTASK_TOTALED%5DF394680354.get preserve=no
        return m_strTASK_TOTALED;
        //## end atm::ATMEvent::getTASK_TOTALED%5DF394680354.get
      }

      void setTASK_TOTALED (const reusable::string& value)
      {
        //## begin atm::ATMEvent::setTASK_TOTALED%5DF394680354.set preserve=no
        m_strTASK_TOTALED = value;
        //## end atm::ATMEvent::setTASK_TOTALED%5DF394680354.set
      }


      //## Attribute: TSTAMP_TOTALED%5DF39469025D
      const reusable::string& getTSTAMP_TOTALED () const
      {
        //## begin atm::ATMEvent::getTSTAMP_TOTALED%5DF39469025D.get preserve=no
        return m_strTSTAMP_TOTALED;
        //## end atm::ATMEvent::getTSTAMP_TOTALED%5DF39469025D.get
      }

      void setTSTAMP_TOTALED (const reusable::string& value)
      {
        //## begin atm::ATMEvent::setTSTAMP_TOTALED%5DF39469025D.set preserve=no
        m_strTSTAMP_TOTALED = value;
        //## end atm::ATMEvent::setTSTAMP_TOTALED%5DF39469025D.set
      }


      //## Attribute: TSTAMP_TRANS%5C49CEA000F6
      const reusable::string& getTSTAMP_TRANS () const
      {
        //## begin atm::ATMEvent::getTSTAMP_TRANS%5C49CEA000F6.get preserve=no
        return m_strTSTAMP_TRANS;
        //## end atm::ATMEvent::getTSTAMP_TRANS%5C49CEA000F6.get
      }

      void setTSTAMP_TRANS (const reusable::string& value)
      {
        //## begin atm::ATMEvent::setTSTAMP_TRANS%5C49CEA000F6.set preserve=no
        m_strTSTAMP_TRANS = value;
        //## end atm::ATMEvent::setTSTAMP_TRANS%5C49CEA000F6.set
      }


      //## Attribute: UNIQUENESS_KEY%5C49DC0501D1
      const short& getUNIQUENESS_KEY () const
      {
        //## begin atm::ATMEvent::getUNIQUENESS_KEY%5C49DC0501D1.get preserve=no
        return m_siUNIQUENESS_KEY;
        //## end atm::ATMEvent::getUNIQUENESS_KEY%5C49DC0501D1.get
      }

      void setUNIQUENESS_KEY (const short& value)
      {
        //## begin atm::ATMEvent::setUNIQUENESS_KEY%5C49DC0501D1.set preserve=no
        m_siUNIQUENESS_KEY = value;
        //## end atm::ATMEvent::setUNIQUENESS_KEY%5C49DC0501D1.set
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Totals Management::TotalsCommand_CAT::<unnamed>%5C49DA3501D4
      //## Role: ATMEvent::<m_hATMActivity>%5C49DA36013B
      vector<ATMActivity>& getATMActivity ()
      {
        //## begin atm::ATMEvent::getATMActivity%5C49DA36013B.get preserve=no
        return m_hATMActivity;
        //## end atm::ATMEvent::getATMActivity%5C49DA36013B.get
      }


    // Additional Public Declarations
      //## begin atm::ATMEvent%5C49C6A00245.public preserve=yes
      //## end atm::ATMEvent%5C49C6A00245.public

  protected:
    // Additional Protected Declarations
      //## begin atm::ATMEvent%5C49C6A00245.protected preserve=yes
      //## end atm::ATMEvent%5C49C6A00245.protected

  private:
    // Additional Private Declarations
      //## begin atm::ATMEvent%5C49C6A00245.private preserve=yes
      //## end atm::ATMEvent%5C49C6A00245.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin atm::ATMEvent::AE_STATE%5C4F5B5E0008.attr preserve=no  public: reusable::string {V} "TW"
      reusable::string m_strAE_STATE;
      //## end atm::ATMEvent::AE_STATE%5C4F5B5E0008.attr

      //## begin atm::ATMEvent::CASH_BEGIN%5C49DBCD005C.attr preserve=no  public: double {V} 0
      double m_dCASH_BEGIN;
      //## end atm::ATMEvent::CASH_BEGIN%5C49DBCD005C.attr

      //## begin atm::ATMEvent::CASH_END%5C49DBE203C5.attr preserve=no  public: double {V} 0
      double m_dCASH_END;
      //## end atm::ATMEvent::CASH_END%5C49DBE203C5.attr

      //## begin atm::ATMEvent::CASSETTES_BEGIN%5C5DDC12010E.attr preserve=no  public: double {V} 0
      double m_dCASSETTES_BEGIN;
      //## end atm::ATMEvent::CASSETTES_BEGIN%5C5DDC12010E.attr

      //## begin atm::ATMEvent::CASSETTES_END%5C5DDC1300EB.attr preserve=no  public: double {V} 0
      double m_dCASSETTES_END;
      //## end atm::ATMEvent::CASSETTES_END%5C5DDC1300EB.attr

      //## Attribute: CASSETTEn_BEGIN%5D026CF9014B
      //## begin atm::ATMEvent::CASSETTEn_BEGIN%5D026CF9014B.attr preserve=no  public: double[8] {V} 
      double m_dCASSETTEn_BEGIN[8];
      //## end atm::ATMEvent::CASSETTEn_BEGIN%5D026CF9014B.attr

      //## Attribute: CASSETTEn_CUR_CODE%5DB88B810307
      //## begin atm::ATMEvent::CASSETTEn_CUR_CODE%5DB88B810307.attr preserve=no  public: reusable::string[8] {V} 
      reusable::string m_strCASSETTEn_CUR_CODE[8];
      //## end atm::ATMEvent::CASSETTEn_CUR_CODE%5DB88B810307.attr

      //## Attribute: CASSETTEn_CUR_TYPE%5DB88B810001
      //## begin atm::ATMEvent::CASSETTEn_CUR_TYPE%5DB88B810001.attr preserve=no  public: short int[8] {V} 
      short int m_siCASSETTEn_CUR_TYPE[8];
      //## end atm::ATMEvent::CASSETTEn_CUR_TYPE%5DB88B810001.attr

      //## Attribute: CASSETTEn_END%5D026CFB02EF
      //## begin atm::ATMEvent::CASSETTEn_END%5D026CFB02EF.attr preserve=no  public: double[8] {V} 
      double m_dCASSETTEn_END[8];
      //## end atm::ATMEvent::CASSETTEn_END%5D026CFB02EF.attr

      //## Attribute: CASSETTEn_VALUE%5DB88B7F03C2
      //## begin atm::ATMEvent::CASSETTEn_VALUE%5DB88B7F03C2.attr preserve=no  public: int[8] {V} 
      int m_iCASSETTEn_VALUE[8];
      //## end atm::ATMEvent::CASSETTEn_VALUE%5DB88B7F03C2.attr

      //## Attribute: CassetteCount%5DB99CB002E0
      //## begin atm::ATMEvent::CassetteCount%5DB99CB002E0.attr preserve=no  public: int[8] {V} 
      int m_iCassetteCount[8];
      //## end atm::ATMEvent::CassetteCount%5DB99CB002E0.attr

      //## begin atm::ATMEvent::CHECK_BEGIN%5C5DDC130295.attr preserve=no  public: double {V} 0
      double m_dCHECK_BEGIN;
      //## end atm::ATMEvent::CHECK_BEGIN%5C5DDC130295.attr

      //## begin atm::ATMEvent::CHECK_END%5C5DDC140080.attr preserve=no  public: double {V} 0
      double m_dCHECK_END;
      //## end atm::ATMEvent::CHECK_END%5C5DDC140080.attr

      //## begin atm::ATMEvent::CUR_CODE%5C49DBC1010A.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strCUR_CODE;
      //## end atm::ATMEvent::CUR_CODE%5C49DBC1010A.attr

      //## begin atm::ATMEvent::DATE_RECON_ACQ%5C51A4AE03CE.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strDATE_RECON_ACQ;
      //## end atm::ATMEvent::DATE_RECON_ACQ%5C51A4AE03CE.attr

      //## begin atm::ATMEvent::FUNCTION_CODE%5C49CE7C038A.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strFUNCTION_CODE;
      //## end atm::ATMEvent::FUNCTION_CODE%5C49CE7C038A.attr

      //## begin atm::ATMEvent::NET_TERM_ID%5C51A4AF00BB.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strNET_TERM_ID;
      //## end atm::ATMEvent::NET_TERM_ID%5C51A4AF00BB.attr

      //## begin atm::ATMEvent::TELLER_BEGIN%5E318E790161.attr preserve=no  public: double {V} 0
      double m_dTELLER_BEGIN;
      //## end atm::ATMEvent::TELLER_BEGIN%5E318E790161.attr

      //## begin atm::ATMEvent::TELLER_END%5E318E7B02EB.attr preserve=no  public: double {V} 0
      double m_dTELLER_END;
      //## end atm::ATMEvent::TELLER_END%5E318E7B02EB.attr

      //## begin atm::ATMEvent::TASK_TOTALED%5DF394680354.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strTASK_TOTALED;
      //## end atm::ATMEvent::TASK_TOTALED%5DF394680354.attr

      //## begin atm::ATMEvent::TSTAMP_TOTALED%5DF39469025D.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strTSTAMP_TOTALED;
      //## end atm::ATMEvent::TSTAMP_TOTALED%5DF39469025D.attr

      //## begin atm::ATMEvent::TSTAMP_TRANS%5C49CEA000F6.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strTSTAMP_TRANS;
      //## end atm::ATMEvent::TSTAMP_TRANS%5C49CEA000F6.attr

      //## begin atm::ATMEvent::UNIQUENESS_KEY%5C49DC0501D1.attr preserve=no  public: short {V} 0
      short m_siUNIQUENESS_KEY;
      //## end atm::ATMEvent::UNIQUENESS_KEY%5C49DC0501D1.attr

    // Data Members for Associations

      //## Association: Totals Management::TotalsCommand_CAT::<unnamed>%5C49DA3501D4
      //## begin atm::ATMEvent::<m_hATMActivity>%5C49DA36013B.role preserve=no  public: atm::ATMActivity { -> 0..nVHgN}
      vector<ATMActivity> m_hATMActivity;
      //## end atm::ATMEvent::<m_hATMActivity>%5C49DA36013B.role

    // Additional Implementation Declarations
      //## begin atm::ATMEvent%5C49C6A00245.implementation preserve=yes
      //## end atm::ATMEvent%5C49C6A00245.implementation

};

//## begin atm::ATMEvent%5C49C6A00245.postscript preserve=yes
//## end atm::ATMEvent%5C49C6A00245.postscript

} // namespace atm

//## begin module%5C49C83C00B7.epilog preserve=yes
//## end module%5C49C83C00B7.epilog


#endif
