//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C49C7EB029C.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%5C49C7EB029C.cm

//## begin module%5C49C7EB029C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C49C7EB029C.cp

//## Module: CXOSAT01%5C49C7EB029C; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Atdll\CXOSAT01.cpp

//## begin module%5C49C7EB029C.additionalIncludes preserve=no
//## end module%5C49C7EB029C.additionalIncludes

//## begin module%5C49C7EB029C.includes preserve=yes
//## end module%5C49C7EB029C.includes

#ifndef CXOSAT04_h
#include "CXODAT04.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU28_h
#include "CXODRU28.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSNS01_h
#include "CXODNS01.hpp"
#endif
#ifndef CXOSNS02_h
#include "CXODNS02.hpp"
#endif
#ifndef CXOSNS03_h
#include "CXODNS03.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSAT01_h
#include "CXODAT01.hpp"
#endif


//## begin module%5C49C7EB029C.declarations preserve=no
//## end module%5C49C7EB029C.declarations

//## begin module%5C49C7EB029C.additionalDeclarations preserve=yes
//## end module%5C49C7EB029C.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::ATMBusinessDay 

//## begin atm::ATMBusinessDay::Instance%5C49C7B901CA.attr preserve=no  private: static atm::ATMBusinessDay* {V} 0
atm::ATMBusinessDay* ATMBusinessDay::m_pInstance = 0;
//## end atm::ATMBusinessDay::Instance%5C49C7B901CA.attr

ATMBusinessDay::ATMBusinessDay()
  //## begin ATMBusinessDay::ATMBusinessDay%5C49C69101AC_const.hasinit preserve=no
  //## end ATMBusinessDay::ATMBusinessDay%5C49C69101AC_const.hasinit
  //## begin ATMBusinessDay::ATMBusinessDay%5C49C69101AC_const.initialization preserve=yes
  //## end ATMBusinessDay::ATMBusinessDay%5C49C69101AC_const.initialization
{
  //## begin atm::ATMBusinessDay::ATMBusinessDay%5C49C69101AC_const.body preserve=yes
   memcpy(m_sID,"AT01",4);
  //## end atm::ATMBusinessDay::ATMBusinessDay%5C49C69101AC_const.body
}


ATMBusinessDay::~ATMBusinessDay()
{
  //## begin atm::ATMBusinessDay::~ATMBusinessDay%5C49C69101AC_dest.body preserve=yes
  //## end atm::ATMBusinessDay::~ATMBusinessDay%5C49C69101AC_dest.body
}



//## Other Operations (implementation)
void ATMBusinessDay::accept (atm::ATMBusinessDayVisitor& hATMBusinessDayVisitor)
{
  //## begin atm::ATMBusinessDay::accept%5C49EBAD0218.body preserve=yes
   hATMBusinessDayVisitor.visitATMBusinessDay(this);
   for (int i = 0;i < m_hATMEvents.size();++i)
      m_hATMEvents[i].accept(hATMBusinessDayVisitor);
  //## end atm::ATMBusinessDay::accept%5C49EBAD0218.body
}

atm::ATMEvent* ATMBusinessDay::getATMEvent (int iCursor)
{
  //## begin atm::ATMBusinessDay::getATMEvent%5C49C77C01AC.body preserve=yes
   if (iCursor < m_hATMEvents.size())
      return &m_hATMEvents[iCursor];
   return 0;
  //## end atm::ATMBusinessDay::getATMEvent%5C49C77C01AC.body
}

atm::ATMBusinessDay* ATMBusinessDay::instance ()
{
  //## begin atm::ATMBusinessDay::instance%5C49C7A602EC.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ATMBusinessDay();
   return m_pInstance;
  //## end atm::ATMBusinessDay::instance%5C49C7A602EC.body
}

bool ATMBusinessDay::reset (const reusable::string& strNET_TERM_ID, const reusable::string& strDATE_RECON_ACQ)
{
  //## begin atm::ATMBusinessDay::reset%5C85A0200133.body preserve=yes
   Table hTable("T_ATM_EVENT");
   hTable.set("AE_STATE","TW");
   SearchCondition hSearchCondition;
   hSearchCondition.setBasicPredicate("T_ATM_EVENT","NET_TERM_ID","=",strNET_TERM_ID.c_str());
   hSearchCondition.setBasicPredicate("T_ATM_EVENT","DATE_RECON_ACQ","=",strDATE_RECON_ACQ.c_str());
   hSearchCondition.setBasicPredicate("T_ATM_EVENT","FUNCTION_CODE","IN","('572','ATM','AUT','RMT','999')");
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   return pUpdateStatement->execute(hTable,hSearchCondition.getText());
  //## end atm::ATMBusinessDay::reset%5C85A0200133.body
}

bool ATMBusinessDay::retrieve (const reusable::string& strNET_TERM_ID, const reusable::string& strDATE_RECON_ACQ, const char* pszFUNCTION_CODE, const char* pszDATE_RECON_ACQ_end)
{
  //## begin atm::ATMBusinessDay::retrieve%5C49C74400DD.body preserve=yes
   m_hATMEvents.erase(m_hATMEvents.begin(),m_hATMEvents.end());
   string strFUNCTION_CODE;
   Query hQuery;
   hQuery.attach(this);
   hQuery.setQualifier("QUALIFY","PROCESSOR");
   hQuery.setQualifier("QUALIFY","INSTITUTION");
   hQuery.setQualifier("QUALIFY","DEVICE_COURIER");
   hQuery.join("PROCESSOR","INNER","INSTITUTION","PROC_ID");
   hQuery.join("PROCESSOR","INNER","INSTITUTION","CUST_ID");
   hQuery.join("INSTITUTION","LEFT OUTER","DEVICE_COURIER","INST_ID");
   hQuery.join("INSTITUTION","LEFT OUTER","DEVICE_COURIER","CUST_ID");
   hQuery.join("INSTITUTION","INNER","DEVICE","INST_ID");
   hQuery.join("INSTITUTION","INNER","DEVICE","CUST_ID");
   hQuery.join("DEVICE","INNER","T_ATM_EVENT","DEVICE_ID","NET_TERM_ID");
   hQuery.join("T_ATM_EVENT","LEFT OUTER","T_ATM_ACTIVITY","NET_TERM_ID");
   hQuery.join("T_ATM_EVENT","LEFT OUTER","T_ATM_ACTIVITY","DATE_RECON_ACQ");
   hQuery.join("T_ATM_EVENT","LEFT OUTER","T_ATM_ACTIVITY","TSTAMP_TRANS");
   hQuery.join("T_ATM_EVENT","LEFT OUTER","T_ATM_ACTIVITY","UNIQUENESS_KEY");
   hQuery.join("T_ATM_EVENT","LEFT OUTER","T_ATM_ACTIVITY","FUNCTION_CODE");
   CRProcessorSegment::instance()->bind(hQuery);
   CRInstitutionSegment::instance()->bind(hQuery);
   CRDeviceSegment::instance()->bind(hQuery);
   m_hATMEvent.bind(hQuery);
   hQuery.bind("T_ATM_EVENT","FUNCTION_CODE FUNCTION_CODE2",Column::STRING,&strFUNCTION_CODE,0,"CASE,'ATM','572','AUT','572','RMT','572',FUNCTION_CODE");
   m_hATMActivity.bind(hQuery);
   hQuery.setBasicPredicate("T_ATM_EVENT","NET_TERM_ID","=",strNET_TERM_ID.c_str());
   if (pszDATE_RECON_ACQ_end)
   {
      string strBetweenClause;
      strBetweenClause = "'" + strDATE_RECON_ACQ + "' AND '" + pszDATE_RECON_ACQ_end + "'";
      hQuery.setBasicPredicate("T_ATM_EVENT", "DATE_RECON_ACQ", "BETWEEN", strBetweenClause.c_str());
   }
   else
       hQuery.setBasicPredicate("T_ATM_EVENT", "DATE_RECON_ACQ", "=", strDATE_RECON_ACQ.c_str());
   
   if (pszFUNCTION_CODE)
      hQuery.setBasicPredicate("T_ATM_EVENT","FUNCTION_CODE","=",pszFUNCTION_CODE);
   else
      hQuery.setBasicPredicate("T_ATM_EVENT","FUNCTION_CODE","<>","998");
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.setBasicPredicate("PROCESSOR","CUST_ID","=",strCUST_ID.c_str());
   hQuery.setBasicPredicate("PROCESSOR","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("PROCESSOR","CC_STATE","=","A");
   hQuery.setBasicPredicate("INSTITUTION","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("INSTITUTION","CC_STATE","=","A");
   hQuery.setBasicPredicate("DEVICE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("DEVICE","CC_STATE","=","A");
   hQuery.setOrderByClause("TSTAMP_TRANS,FUNCTION_CODE2,UNIQUENESS_KEY,ACTIVITY_GROUP,ACTIVITY_TYPE,TRAN_DISPOSITION,CUR_TYPE");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == false || hQuery.getAbort())
      return false;
   return true;
  //## end atm::ATMBusinessDay::retrieve%5C49C74400DD.body
}

void ATMBusinessDay::update (Subject* pSubject)
{
  //## begin atm::ATMBusinessDay::update%5C49C7210240.body preserve=yes
   if (m_hATMEvent.getAE_STATE() != "TC")
   {
      ((Query*)pSubject)->setAbort(true);
      return;
   }
   if (m_hATMEvents.empty()
      || m_hATMEvent != m_hATMEvents.back())
      m_hATMEvents.push_back(m_hATMEvent);
   if(m_hATMActivity.getACTIVITY_GROUP() != ATMActivity::NONE)
      m_hATMEvents.back().getATMActivity().push_back(m_hATMActivity);
  //## end atm::ATMBusinessDay::update%5C49C7210240.body
}

// Additional Declarations
  //## begin atm::ATMBusinessDay%5C49C69101AC.declarations preserve=yes
  //## end atm::ATMBusinessDay%5C49C69101AC.declarations

} // namespace atm

//## begin module%5C49C7EB029C.epilog preserve=yes
//## end module%5C49C7EB029C.epilog
