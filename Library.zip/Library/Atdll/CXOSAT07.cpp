//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C5C2CE8009F.cm preserve=no
//	$Date:   Jul 23 2021 14:18:58  $ $Author:   e1009839  $
//	$Revision:   1.15  $
//## end module%5C5C2CE8009F.cm

//## begin module%5C5C2CE8009F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C5C2CE8009F.cp

//## Module: CXOSAT07%5C5C2CE8009F; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Atdll\CXOSAT07.cpp

//## begin module%5C5C2CE8009F.additionalIncludes preserve=no
//## end module%5C5C2CE8009F.additionalIncludes

//## begin module%5C5C2CE8009F.includes preserve=yes
//## end module%5C5C2CE8009F.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSAT03_h
#include "CXODAT03.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSDB16_h
#include "CXODDB16.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSAT02_h
#include "CXODAT02.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSAT07_h
#include "CXODAT07.hpp"
#endif


//## begin module%5C5C2CE8009F.declarations preserve=no
//## end module%5C5C2CE8009F.declarations

//## begin module%5C5C2CE8009F.additionalDeclarations preserve=yes
namespace
{
#define FIELDS 16
Fields ATMTransaction_Fields[FIELDS + 1] =
{
   "d%-18.0f  ","AMT_CHECK",0,0,
   "d%-18.0f  ","AMT_RECON_NET",0,0,
   "d%-18.0f  ","CashDebit",0,0,
   "d%-18.0f  ","CashCredit",0,0,
   "d%-18.0f  ","CashDepositDebit",0,0,
   "d%-18.0f  ","CashDepositCredit",0,0,
   "d%-18.0f  ","CheckDepositDebit",0,0,
   "d%-18.0f  ","CheckDepositCredit",0,0,
   "a         ","CUR_RECON_NET",0,0,
   "a         ","INST_ID_RECN_ACQ_B",0,0,
   "a         ","INST_ID_RECN_ISS_B",0,0,
   "l         ","ITEM_COUNT",0,0,
   "l         ","ITEM_VALUE",0,0,
   "a         ","STATUS",0,0,
   "a         ","TRAN_DISPOSITION",0,0,
   "a         ","TRAN_TYPE_ID",0,0,
   "~","~",0,0,
};
}
//## end module%5C5C2CE8009F.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::ATMTransaction

ATMTransaction::ATMTransaction()
  //## begin ATMTransaction::ATMTransaction%5C5C2BD20292_const.hasinit preserve=no
      : m_iACTIVITY_GROUP(0),
        m_iACTIVITY_TYPE(0),
        m_dAMT_CHECK(0),
        m_dAMT_RECON_NET(0),
        m_dAMT_TELLER(0),
        m_dAMT_TRAN(0),
        m_dAMT_USER(0),
        m_dO_AMT_TRAN(0)
  //## end ATMTransaction::ATMTransaction%5C5C2BD20292_const.hasinit
  //## begin ATMTransaction::ATMTransaction%5C5C2BD20292_const.initialization preserve=yes
   ,PersistentSegment("XXXX","FIN_Lyyyymm")
  //## end ATMTransaction::ATMTransaction%5C5C2BD20292_const.initialization
{
  //## begin atm::ATMTransaction::ATMTransaction%5C5C2BD20292_const.body preserve=yes
   memcpy(m_sID,"ST76",4);
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_dAMT_CHECK;
   m_pField[1] = &m_dAMT_RECON_NET;
   m_pField[2] = &m_dDebit[CASSETTES];
   m_pField[3] = &m_dCredit[CASSETTES];
   m_pField[4] = &m_dDebit[CASH];
   m_pField[5] = &m_dCredit[CASH];
   m_pField[6] = &m_dDebit[CHECK];
   m_pField[7] = &m_dCredit[CHECK];
   m_pField[8] = &m_strCUR_RECON_NET;
   m_pField[9] = &m_strINST_ID_RECN_ACQ_B;
   m_pField[10] = &m_strINST_ID_RECN_ISS_B;
   m_pField[11] = &m_iITEM_COUNT[0];
   m_pField[12] = &m_iITEM_VALUE[0];
   m_pField[13] = &m_strSTATUS;
   m_pField[14] = &m_strTRAN_DISPOSITION;
   m_pField[15] = &m_strTRAN_TYPE_ID;
   reset();
   m_hACTIVITY_TYPE["WTHD"] = make_pair((int)atm::ATMActivity::WITHDRAWAL,CASSETTES);
   m_hACTIVITY_TYPE["DEP "] = make_pair((int)atm::ATMActivity::ENVELOPE,-1);
   m_hACTIVITY_TYPE["DEPE"] = make_pair((int)atm::ATMActivity::ENVELOPE,-1);
   m_hACTIVITY_TYPE["DEPA"] = make_pair((int)atm::ATMActivity::CASH,CASH);
   m_hACTIVITY_TYPE["DEPC"] = make_pair((int)atm::ATMActivity::CHECK,CHECK);
   m_hACTIVITY_TYPE["TRAN"] = make_pair((int)atm::ATMActivity::TRANSFER,-1);
   m_hACTIVITY_TYPE["PAYT"] = make_pair((int)atm::ATMActivity::PAYMENT_TO,-1);
   m_hACTIVITY_TYPE["PAYF"] = make_pair((int)atm::ATMActivity::PAYMENT_FROM,-1);
   m_hACTIVITY_TYPE["INQ "] = make_pair((int)atm::ATMActivity::INQUIRY,-1);
   m_hACTIVITY_TYPE["MISC"] = make_pair((int)atm::ATMActivity::OTHER,-1);
  //## end atm::ATMTransaction::ATMTransaction%5C5C2BD20292_const.body
}


ATMTransaction::~ATMTransaction()
{
  //## begin atm::ATMTransaction::~ATMTransaction%5C5C2BD20292_dest.body preserve=yes
  //## end atm::ATMTransaction::~ATMTransaction%5C5C2BD20292_dest.body
}



//## Other Operations (implementation)
void ATMTransaction::bind (Query& hQuery, const reusable::string& strTable)
{
  //## begin atm::ATMTransaction::bind%5C5C39D90290.body preserve=yes
   hQuery.bind(strTable.c_str(),"AMT_RECON_NET",Column::DOUBLE,&m_dAMT_RECON_NET);
   hQuery.bind(strTable.c_str(),"CUR_RECON_NET",Column::STRING,&m_strCUR_RECON_NET);
   hQuery.bind(strTable.c_str(),"INST_ID_RECN_ACQ_B",Column::STRING,&m_strINST_ID_RECN_ACQ_B);
   hQuery.bind(strTable.c_str(),"INST_ID_RECN_ISS_B",Column::STRING,&m_strINST_ID_RECN_ISS_B);
   hQuery.bind(strTable.c_str(),"TRAN_TYPE_ID",Column::STRING,&m_strTRAN_TYPE_ID);
   hQuery.bind(strTable.c_str(),"NET_TERM_ID",Column::STRING,&m_strNET_TERM_ID);
   hQuery.bind(strTable.c_str(),"FUNC_CODE",Column::STRING,&m_strFUNC_CODE);
   hQuery.bind("FIN_RECORD","TRAN_DISPOSITION",Column::STRING,&m_strTRAN_DISPOSITION);
   hQuery.bind("FIN_RECORD","CUR_TYPE",Column::SHORT,&m_siCUR_TYPE[0]);
   hQuery.bind("FIN_RECORD","AMT_TRAN",Column::DOUBLE,&m_dAMT_TRAN);
   hQuery.bind("FIN_RECORD","O_AMT_TRAN",Column::DOUBLE,&m_dO_AMT_TRAN);
   string strF_AMTn("F_AMTn");
   string strF_TYPEn("F_TYPEn");
   char szTemp[9] = {"01234567"};
   for (int i = 0;i < 6;++i)
   {
      strF_AMTn.replace(5,1,&szTemp[i],1);
      hQuery.bind("FIN_RECORD",strF_AMTn.c_str(),Column::LONG,&m_iF_AMTn[i]);
      strF_TYPEn.replace(6,1,&szTemp[i],1);
      hQuery.bind("FIN_RECORD",strF_TYPEn.c_str(),Column::STRING,&m_strF_TYPEn[i]);
   }
   string strCAN_ITEM_VALUEn("CAN_ITEM_VALUEn");
   string strCAN_NO_ITEMS_DISPn("CAN_NO_ITEMS_DISPn");
   string strCAN_ORIG_NO_ITEMSn("CAN_ORIG_NO_ITEMSn");
   for (int i = 0;i < 8;++i)
   {
      strCAN_ITEM_VALUEn.replace(14,1,&szTemp[i],1);
      hQuery.bind("FIN_RECORD",strCAN_ITEM_VALUEn.c_str(),Column::LONG,&m_iCAN_ITEM_VALUEn[i]);
      strCAN_ORIG_NO_ITEMSn.replace(17,1,&szTemp[i],1);
      hQuery.bind("FIN_RECORD",strCAN_ORIG_NO_ITEMSn.c_str(),Column::SHORT,&m_siCAN_ORIG_NO_ITEMSn[i]);
      strCAN_NO_ITEMS_DISPn.replace(17,1,&szTemp[i],1);
      hQuery.bind("FIN_RECORD",strCAN_NO_ITEMS_DISPn.c_str(),Column::SHORT,&m_siCAN_NO_ITEMS_DISPn[i]);
   }
  //## end atm::ATMTransaction::bind%5C5C39D90290.body
}

void ATMTransaction::bind (Query& hQuery, const reusable::string& strTable, const string& strChildTable)
{
  //## begin atm::ATMTransaction::bind%5C5CAF1D0372.body preserve=yes
   hQuery.join(strTable.c_str(),"INNER",strChildTable.c_str(),"TSTAMP_TRANS");
   hQuery.join(strTable.c_str(),"INNER",strChildTable.c_str(),"UNIQUENESS_KEY");
   bind(hQuery,strTable);
   if (hQuery.getIndex() == 2)
   {
      hQuery.bind(strChildTable.c_str(),"ITEM_COUNT",Column::LONG,&m_iITEM_COUNT[0]);
      hQuery.bind(strChildTable.c_str(),"ITEM_VALUE",Column::LONG,&m_iITEM_VALUE[0]);
   }
   else
   {
      hQuery.bind(strChildTable.c_str(),"AMT_CHECK",Column::DOUBLE,&m_dAMT_CHECK);
      hQuery.bind(strChildTable.c_str(),"AMT_TELLER",Column::DOUBLE,&m_dAMT_TELLER);
      hQuery.bind(strChildTable.c_str(),"AMT_USER",Column::DOUBLE,&m_dAMT_USER);
      hQuery.bind(strChildTable.c_str(),"STATUS",Column::STRING,&m_strSTATUS);
   }
  //## end atm::ATMTransaction::bind%5C5CAF1D0372.body
}

struct  Fields* ATMTransaction::fields () const
{
  //## begin atm::ATMTransaction::fields%5C5C2C1C0356.body preserve=yes
   return &ATMTransaction_Fields[0];
  //## end atm::ATMTransaction::fields%5C5C2C1C0356.body
}

int ATMTransaction::getAMT_SURCHARGE ()
{
  //## begin atm::ATMTransaction::getAMT_SURCHARGE%5C64C212029B.body preserve=yes
   for (int i = 0;i < 6;++i)
      if (m_strF_TYPEn[i] == "70")
         return m_iF_AMTn[i];
   return 0;
  //## end atm::ATMTransaction::getAMT_SURCHARGE%5C64C212029B.body
}

void ATMTransaction::reset ()
{
  //## begin atm::ATMTransaction::reset%5D03B4E0038C.body preserve=yes
   PersistentSegment::reset();
   for (int i = 0;i < 8;++i)
   {
      m_iCAN_ITEM_VALUEn[i] = 0;
      m_siCAN_NO_ITEMS_DISPn[i] = 0;
      m_siCAN_ORIG_NO_ITEMSn[i] = 0;
   }
   for (int i = 0;i <= CASSETTE8;++i)
      m_iITEM_COUNT[i] = 0;
   for (int i = 0;i <= TOTAL_CASSETTE8;++i)
   {
      m_dCredit[i] = 0;
      m_strCUR_CODE[i].erase();
      m_siCUR_TYPE[i] = 0;
      m_dDebit[i] = 0;
      m_iITEM_VALUE[i] = 0;
   }
  //## end atm::ATMTransaction::reset%5D03B4E0038C.body
}

void ATMTransaction::setActivity (int iIndex, reusable::Table& hTable, atm::ATMEvent* pATMEvent)
{
  //## begin atm::ATMTransaction::setActivity%5C5C920B0116.body preserve=yes
   for (int i = CASSETTE1;i <= CASSETTE8;++i)
   {
      m_dCredit[i] = 0;
      m_strCUR_CODE[i].erase();
      m_siCUR_TYPE[i] = 0;
      m_dDebit[i] = 0;
      m_iITEM_COUNT[i] = 0;
      m_iITEM_VALUE[i] = 0;
   }
   m_iACTIVITY_GROUP = m_strINST_ID_RECN_ACQ_B == m_strINST_ID_RECN_ISS_B ? (int)atm::ATMActivity::ACTIVITY_ONUS : (int)atm::ATMActivity::ACTIVITY_FOREIGN;
   hTable.set("ACTIVITY_GROUP",m_iACTIVITY_GROUP,true);
   hTable.set("TRAN_DISPOSITION",m_strTRAN_DISPOSITION,false,true);
   hTable.set("CUR_RECON_NET",m_strCUR_RECON_NET);
   hTable.set("CUR_TYPE",(int)0);
   map<string,pair<int,int>,less<string> >::iterator p = m_hACTIVITY_TYPE.end();
   char szFirst[16 + PERCENTHD];
   string strFirst;
   string strSecond;
   switch (iIndex)
   {
      case 0:
      case 1:
         database::CRTransactionTypeIndicator::getImpact(m_strTRAN_TYPE_ID,strFirst,strSecond);
         if (m_strTRAN_DISPOSITION == "3")
         {
            if (strFirst == "1")
               strFirst = "2";
            else
            if (strFirst == "2")
               strFirst = "1";
         }
         database::CRTransactionTypeIndicator::getTranGroup(m_strTRAN_TYPE_ID,strSecond);
         if (strSecond == "DEP ")
         {
            string strDEPOSITORY_IND;
            if (database::CRTransactionTypeIndicator::getDepositoryInd(m_strTRAN_TYPE_ID,strDEPOSITORY_IND))
               strSecond[3] = strDEPOSITORY_IND[0];
         }
         p = m_hACTIVITY_TYPE.find(strSecond);
         if (p != m_hACTIVITY_TYPE.end())
         {
            m_iACTIVITY_TYPE = (*p).second.first;
            if (m_strTRAN_DISPOSITION != "2")
            {
               if ((*p).second.second != -1)
               {
                  if (strFirst == "1")
                     m_dDebit[(*p).second.second] += m_dAMT_RECON_NET;
                  else
                     m_dCredit[(*p).second.second] += m_dAMT_RECON_NET;
                  if (strSecond == "WTHD")
                     setWithdrawal(strFirst,pATMEvent);
               }
            }
         }
         else
            m_iACTIVITY_TYPE = (int)atm::ATMActivity::OTHER;
         hTable.set("ACTIVITY_TYPE",m_iACTIVITY_TYPE,true);
         hTable.set("IMPACT_TO_ACQ",strFirst);
         if(m_strTRAN_DISPOSITION == "2")
            hTable.set("AMT_RECON_NET",m_dAMT_TRAN,false,"+");
         else
            hTable.set("AMT_RECON_NET",m_dAMT_RECON_NET,false,"+");
         hTable.set("AMT_SURCHARGE",(double)getAMT_SURCHARGE());
         hTable.set("TRAN_COUNT",(int)1,false,"+");
         hTable.set("ITEM_VALUE",(int)0);
         hTable.set("ITEM_COUNT",(int)0);
         break;
      case 2:
         strFirst.assign(szFirst,snprintf(szFirst,sizeof(szFirst),"DENOMINATION%s%hd",m_strCUR_RECON_NET.c_str(),m_iITEM_VALUE[0]));
         ConfigurationRepository::instance()->translate("~X_GENERIC",strFirst,strSecond," "," ",-1,false);
         m_iACTIVITY_TYPE = ((int)atm::ATMActivity::CASH) + ::atoi(strSecond.c_str());
         hTable.set("ACTIVITY_TYPE",m_iACTIVITY_TYPE,true);
         hTable.set("IMPACT_TO_ACQ",string(" "));
         hTable.set("AMT_RECON_NET",double(0));
         hTable.set("AMT_SURCHARGE",double(0));
         hTable.set("TRAN_COUNT",(int)0);
         hTable.set("ITEM_VALUE",m_iITEM_VALUE[0]);
         hTable.set("ITEM_COUNT",m_iITEM_COUNT[0]);
         break;
      case 3:
         m_iACTIVITY_TYPE = m_strSTATUS == "V" ? (int)atm::ATMActivity::CHECK_ONUS_ORIGINAL : (int)atm::ATMActivity::CHECK_TRANSIT_ORIGINAL;
         hTable.set("ACTIVITY_TYPE",m_iACTIVITY_TYPE,true);
         hTable.set("IMPACT_TO_ACQ",string(" "));
         if (m_dAMT_TELLER != 0)
            hTable.set("AMT_RECON_NET",m_dAMT_TELLER,false,"+");
         else
         if (m_dAMT_USER != 0)
            hTable.set("AMT_RECON_NET",m_dAMT_USER,false,"+");
         else
            hTable.set("AMT_RECON_NET",m_dAMT_CHECK,false,"+");
         hTable.set("AMT_SURCHARGE",double(0));
         hTable.set("TRAN_COUNT",(int)0);
         hTable.set("ITEM_VALUE",(int)0);
         hTable.set("ITEM_COUNT",(int)1,false,"+");
   }
  //## end atm::ATMTransaction::setActivity%5C5C920B0116.body
}

void ATMTransaction::setWithdrawal (const reusable::string& strIMPACT_TO_ACQ, atm::ATMEvent* pATMEvent)
{
  //## begin atm::ATMTransaction::setWithdrawal%5DF90698027C.body preserve=yes
   int i = 0;
   if (m_dAMT_TRAN > 0)
   {
      int j = 0;
      for (i = 0;i < 8;++i)
         if (m_iCAN_ITEM_VALUEn[i] > 0)
            j = 1;
      if (j == 0)
      {
         ATMEvent x;
         if (!pATMEvent)
         {
            Query hQuery;
            x.bind(hQuery);
            hQuery.setBasicPredicate("T_ATM_EVENT","NET_TERM_ID","=",m_strNET_TERM_ID.c_str());
            hQuery.setBasicPredicate("T_ATM_EVENT","AE_STATE","=","TC");
            hQuery.setBasicPredicate("T_ATM_EVENT","FUNCTION_CODE","=","999");
            hQuery.setOrderByClause("TSTAMP_TRANS");
            auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
            if (!pSelectStatement->execute(hQuery))
               return;
            pATMEvent = &x;
         }
         // set canister dispense values if not logged by switch
         map<int,int,less<int> > hDenomination;
         for (i = 0;i < 8;++i)
            if (pATMEvent->getCASSETTEn_VALUE(i) > 0)
               hDenomination.insert(map<int,int,less<int> >::value_type(pATMEvent->getCASSETTEn_VALUE(i),i));
         int iAMT_TRAN = (int)m_dAMT_TRAN;
         if (m_strFUNC_CODE == "400"
            || m_strFUNC_CODE == "401")
            iAMT_TRAN = iAMT_TRAN - (int)m_dAMT_RECON_NET;
         int iO_AMT_TRAN = (int)m_dO_AMT_TRAN;
         for (map<int,int,less<int> >::reverse_iterator r = hDenomination.rbegin();r != hDenomination.rend();++r)
         {
            if (iAMT_TRAN > 0)
            {
               m_siCAN_NO_ITEMS_DISPn[(*r).second] = iAMT_TRAN / (*r).first;
               if (m_siCAN_NO_ITEMS_DISPn[(*r).second] > 0)
               {
                  m_iCAN_ITEM_VALUEn[(*r).second] = (*r).first;
                  iAMT_TRAN = iAMT_TRAN % (*r).first;
               }
            }
            if (iO_AMT_TRAN > 0)
            {
               m_siCAN_ORIG_NO_ITEMSn[(*r).second] = iO_AMT_TRAN / (*r).first;
               if (m_siCAN_ORIG_NO_ITEMSn[(*r).second] > 0)
               {
                  m_iCAN_ITEM_VALUEn[(*r).second] = (*r).first;
                  iO_AMT_TRAN = iO_AMT_TRAN % (*r).first;
               }
            }
            if (iAMT_TRAN == 0 && iO_AMT_TRAN == 0)
               break;
         }
      }
   }
   for (i = 0;i < 8;++i)
   {
      if (m_iCAN_ITEM_VALUEn[i] > 0)
      {
         if (strIMPACT_TO_ACQ == "1")
         {
            if (m_dAMT_RECON_NET > 0)
            {
               m_dDebit[i + CASSETTE1] += (m_siCAN_ORIG_NO_ITEMSn[i] - m_siCAN_NO_ITEMS_DISPn[i]) * m_iCAN_ITEM_VALUEn[i];
               m_dDebit[i + TOTAL_CASSETTE1] += (m_siCAN_ORIG_NO_ITEMSn[i] - m_siCAN_NO_ITEMS_DISPn[i]) * m_iCAN_ITEM_VALUEn[i];
               m_iITEM_COUNT[i + CASSETTE1] -= (m_siCAN_ORIG_NO_ITEMSn[i] - m_siCAN_NO_ITEMS_DISPn[i]);
            }
         }
         else
         {
            m_dCredit[i + CASSETTE1] += m_siCAN_NO_ITEMS_DISPn[i] * m_iCAN_ITEM_VALUEn[i];
            m_dCredit[i + TOTAL_CASSETTE1] += m_siCAN_NO_ITEMS_DISPn[i] * m_iCAN_ITEM_VALUEn[i];
            m_iITEM_COUNT[i + CASSETTE1] += m_siCAN_NO_ITEMS_DISPn[i];
         }
         m_iITEM_VALUE[i + CASSETTE1] = m_iCAN_ITEM_VALUEn[i];
         m_siCUR_TYPE[i + CASSETTE1] = m_siCUR_TYPE[0];
         m_strCUR_CODE[i + CASSETTE1] = m_strCUR_RECON_NET;
         m_iITEM_VALUE[i + TOTAL_CASSETTE1] = m_iCAN_ITEM_VALUEn[i];
         m_siCUR_TYPE[i + TOTAL_CASSETTE1] = m_siCUR_TYPE[0];
         m_strCUR_CODE[i + TOTAL_CASSETTE1] = m_strCUR_RECON_NET;
      }
   }
  //## end atm::ATMTransaction::setWithdrawal%5DF90698027C.body
}

// Additional Declarations
  //## begin atm::ATMTransaction%5C5C2BD20292.declarations preserve=yes
  //## end atm::ATMTransaction%5C5C2BD20292.declarations

} // namespace atm

//## begin module%5C5C2CE8009F.epilog preserve=yes
//## end module%5C5C2CE8009F.epilog
