//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C49C83E0241.cm preserve=no
//	$Date:   Jan 15 2021 15:07:32  $ $Author:   e1009652  $
//	$Revision:   1.7  $
//## end module%5C49C83E0241.cm

//## begin module%5C49C83E0241.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C49C83E0241.cp

//## Module: CXOSAT02%5C49C83E0241; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Atdll\CXOSAT02.cpp

//## begin module%5C49C83E0241.additionalIncludes preserve=no
//## end module%5C49C83E0241.additionalIncludes

//## begin module%5C49C83E0241.includes preserve=yes
//## end module%5C49C83E0241.includes

#ifndef CXOSAT04_h
#include "CXODAT04.hpp"
#endif
#ifndef CXOSAT02_h
#include "CXODAT02.hpp"
#endif


//## begin module%5C49C83E0241.declarations preserve=no
//## end module%5C49C83E0241.declarations

//## begin module%5C49C83E0241.additionalDeclarations preserve=yes
namespace
{
#define FIELDS 65
Fields ATMEvent_Fields[FIELDS + 1] =
{
   "a         ","AE_STATE",0,0,
   "d%-18.0f  ","CASH_BEGIN",0,0,
   "d%-18.0f  ","CASH_END",0,0,
   "d%-18.0f  ","CASSETTES_BEGIN",0,0,
   "d%-18.0f  ","CASSETTES_END",0,0,
   "l%d       ","CASSETTE1_VALUE",0,0,
   "s%hd      ","CASSETTE1_CUR_TYPE",0,0,
   "a         ","CASSETTE1_CUR_CODE",0,0,
   "d%-18.0f  ","CASSETTE1_BEGIN",0,0,
   "d%-18.0f  ","CASSETTE1_END",0,0,
   "l%d      X","Cassette1Count",0,0,
   "l%d       ","CASSETTE2_VALUE",0,0,
   "s%hd      ","CASSETTE2_CUR_TYPE",0,0,
   "a         ","CASSETTE2_CUR_CODE",0,0,
   "d%-18.0f  ","CASSETTE2_BEGIN",0,0,
   "d%-18.0f  ","CASSETTE2_END",0,0,
   "l%d      X","Cassette2Count",0,0,
   "l%d       ","CASSETTE3_VALUE",0,0,
   "s%hd      ","CASSETTE3_CUR_TYPE",0,0,
   "a         ","CASSETTE3_CUR_CODE",0,0,
   "d%-18.0f  ","CASSETTE3_BEGIN",0,0,
   "d%-18.0f  ","CASSETTE3_END",0,0,
   "l%d      X","Cassette3Count",0,0,
   "l%d       ","CASSETTE4_VALUE",0,0,
   "s%hd      ","CASSETTE4_CUR_TYPE",0,0,
   "a         ","CASSETTE4_CUR_CODE",0,0,
   "d%-18.0f  ","CASSETTE4_BEGIN",0,0,
   "d%-18.0f  ","CASSETTE4_END",0,0,
   "l%d      X","Cassette4Count",0,0,
   "l%d       ","CASSETTE5_VALUE",0,0,
   "s%hd      ","CASSETTE5_CUR_TYPE",0,0,
   "a         ","CASSETTE5_CUR_CODE",0,0,
   "d%-18.0f  ","CASSETTE5_BEGIN",0,0,
   "d%-18.0f  ","CASSETTE5_END",0,0,
   "l%d      X","Cassette5Count",0,0,
   "l%d       ","CASSETTE6_VALUE",0,0,
   "s%hd      ","CASSETTE6_CUR_TYPE",0,0,
   "a         ","CASSETTE6_CUR_CODE",0,0,
   "d%-18.0f  ","CASSETTE6_BEGIN",0,0,
   "d%-18.0f  ","CASSETTE6_END",0,0,
   "l%d      X","Cassette6Count",0,0,
   "l%d       ","CASSETTE7_VALUE",0,0,
   "s%hd      ","CASSETTE7_CUR_TYPE",0,0,
   "a         ","CASSETTE7_CUR_CODE",0,0,
   "d%-18.0f  ","CASSETTE7_BEGIN",0,0,
   "d%-18.0f  ","CASSETTE7_END",0,0,
   "l%d      X","Cassette7Count",0,0,
   "l%d       ","CASSETTE8_VALUE",0,0,
   "s%hd      ","CASSETTE8_CUR_TYPE",0,0,
   "a         ","CASSETTE8_CUR_CODE",0,0,
   "d%-18.0f  ","CASSETTE8_BEGIN",0,0,
   "d%-18.0f  ","CASSETTE8_END",0,0,
   "l%d      X","Cassette8Count",0,0,
   "d%-18.0f  ","CHECK_BEGIN",0,0,
   "d%-18.0f  ","CHECK_END",0,0,
   "a         ","CUR_CODE",0,0,
   "a         ","DATE_RECON_ACQ",0,0,
   "a        K","FUNCTION_CODE",0,0,
   "a        K","NET_TERM_ID",0,0,
   "d%-18.0f  ","TELLER_BEGIN",0,0,
   "d%-18.0f  ","TELLER_END",0,0,
   "a         ","TASK_TOTALED",0,0,
   "a         ","TSTAMP_TOTALED",0,0,
   "a        K","TSTAMP_TRANS",0,0,
   "s%hd     K","UNIQUENESS_KEY",0,0,
   "~","~",0,0,
};
}
//## end module%5C49C83E0241.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::ATMEvent

ATMEvent::ATMEvent()
  //## begin ATMEvent::ATMEvent%5C49C6A00245_const.hasinit preserve=no
      : m_strAE_STATE("TW"),
        m_dCASH_BEGIN(0),
        m_dCASH_END(0),
        m_dCASSETTES_BEGIN(0),
        m_dCASSETTES_END(0),
        m_dCHECK_BEGIN(0),
        m_dCHECK_END(0),
        m_dTELLER_BEGIN(0),
        m_dTELLER_END(0),
        m_siUNIQUENESS_KEY(0)
  //## end ATMEvent::ATMEvent%5C49C6A00245_const.hasinit
  //## begin ATMEvent::ATMEvent%5C49C6A00245_const.initialization preserve=yes
   ,PersistentSegment("XXXX","T_ATM_EVENT")
  //## end ATMEvent::ATMEvent%5C49C6A00245_const.initialization
{
  //## begin atm::ATMEvent::ATMEvent%5C49C6A00245_const.body preserve=yes
   memcpy(m_sID,"AT02",4);
   for (int i = 0; i < 8; ++i)
   {
      m_iCASSETTEn_VALUE[i] = 0;
      m_siCASSETTEn_CUR_TYPE[i] = 0;
      m_dCASSETTEn_BEGIN[i] = 0;
      m_dCASSETTEn_END[i] = 0;
      m_iCassetteCount[i] = 0;
   }
   setFields();
  //## end atm::ATMEvent::ATMEvent%5C49C6A00245_const.body
}

ATMEvent::ATMEvent(const ATMEvent &right)
  //## begin ATMEvent::ATMEvent%5C49C6A00245_copy.hasinit preserve=no
  //## end ATMEvent::ATMEvent%5C49C6A00245_copy.hasinit
  //## begin ATMEvent::ATMEvent%5C49C6A00245_copy.initialization preserve=yes
   : PersistentSegment(right)
   ,m_strAE_STATE(right.m_strAE_STATE)
   ,m_strCUR_CODE(right.m_strCUR_CODE)
   ,m_strDATE_RECON_ACQ(right.m_strDATE_RECON_ACQ)
   ,m_strFUNCTION_CODE(right.m_strFUNCTION_CODE)
   ,m_strNET_TERM_ID(right.m_strNET_TERM_ID)
   ,m_strTASK_TOTALED(right.m_strTASK_TOTALED)
   ,m_strTSTAMP_TOTALED(right.m_strTSTAMP_TOTALED)
   ,m_strTSTAMP_TRANS(right.m_strTSTAMP_TRANS)
  //## end ATMEvent::ATMEvent%5C49C6A00245_copy.initialization
{
  //## begin atm::ATMEvent::ATMEvent%5C49C6A00245_copy.body preserve=yes
   setFields();
   m_dCASH_BEGIN = right.m_dCASH_BEGIN;
   m_dCASH_END = right.m_dCASH_END;
   m_dCASSETTES_BEGIN = right.m_dCASSETTES_BEGIN;
   m_dCASSETTES_END = right.m_dCASSETTES_END;
   for (int i = 0;i < 8;++i)
   {
      m_dCASSETTEn_BEGIN[i] = right.m_dCASSETTEn_BEGIN[i];
      m_strCASSETTEn_CUR_CODE[i] = right.m_strCASSETTEn_CUR_CODE[i];
      m_siCASSETTEn_CUR_TYPE[i] = right.m_siCASSETTEn_CUR_TYPE[i];
      m_dCASSETTEn_END[i] = right.m_dCASSETTEn_END[i];
      m_iCASSETTEn_VALUE[i] = right.m_iCASSETTEn_VALUE[i];
      m_iCassetteCount[i] = right.m_iCassetteCount[i];
   }
   m_dCHECK_BEGIN = right.m_dCHECK_BEGIN;
   m_dCHECK_END = right.m_dCHECK_END;
   m_dTELLER_BEGIN = right.m_dTELLER_BEGIN;
   m_dTELLER_END = right.m_dTELLER_END;
   m_siUNIQUENESS_KEY = right.m_siUNIQUENESS_KEY;
   m_hATMActivity = right.m_hATMActivity;
  //## end atm::ATMEvent::ATMEvent%5C49C6A00245_copy.body
}


ATMEvent::~ATMEvent()
{
  //## begin atm::ATMEvent::~ATMEvent%5C49C6A00245_dest.body preserve=yes
  //## end atm::ATMEvent::~ATMEvent%5C49C6A00245_dest.body
}


ATMEvent & ATMEvent::operator=(const ATMEvent &right)
{
  //## begin atm::ATMEvent::operator=%5C49C6A00245_assign.body preserve=yes
   if (&right == this)
      return *this;
   PersistentSegment::operator=(right);
   setFields();
   m_dCASH_BEGIN = right.m_dCASH_BEGIN;
   m_dCASH_END = right.m_dCASH_END;
   m_dCASSETTES_BEGIN = right.m_dCASSETTES_BEGIN;
   m_dCASSETTES_END = right.m_dCASSETTES_END;
   for (int i = 0;i < 8;++i)
   {
      m_dCASSETTEn_BEGIN[i] = right.m_dCASSETTEn_BEGIN[i];
      m_strCASSETTEn_CUR_CODE[i] = right.m_strCASSETTEn_CUR_CODE[i];
      m_siCASSETTEn_CUR_TYPE[i] = right.m_siCASSETTEn_CUR_TYPE[i];
      m_dCASSETTEn_END[i] = right.m_dCASSETTEn_END[i];
      m_iCASSETTEn_VALUE[i] = right.m_iCASSETTEn_VALUE[i];
      m_iCassetteCount[i] = right.m_iCassetteCount[i];
   }
   m_dCHECK_BEGIN = right.m_dCHECK_BEGIN;
   m_dCHECK_END = right.m_dCHECK_END;
   m_strCUR_CODE = right.m_strCUR_CODE;
   m_strDATE_RECON_ACQ = right.m_strDATE_RECON_ACQ;
   m_strFUNCTION_CODE = right.m_strFUNCTION_CODE;
   m_strNET_TERM_ID = right.m_strNET_TERM_ID;
   m_dTELLER_BEGIN = right.m_dTELLER_BEGIN;
   m_dTELLER_END = right.m_dTELLER_END;
   m_strTASK_TOTALED = right.m_strTASK_TOTALED;
   m_strTSTAMP_TOTALED = right.m_strTSTAMP_TOTALED;
   m_strTSTAMP_TRANS = right.m_strTSTAMP_TRANS;
   m_siUNIQUENESS_KEY = right.m_siUNIQUENESS_KEY;
   m_hATMActivity = right.m_hATMActivity;
   return *this;
  //## end atm::ATMEvent::operator=%5C49C6A00245_assign.body
}


bool ATMEvent::operator==(const ATMEvent &right) const
{
  //## begin atm::ATMEvent::operator==%5C49C6A00245_eq.body preserve=yes
   return (m_strNET_TERM_ID == right.m_strNET_TERM_ID
      && m_strDATE_RECON_ACQ == right.m_strDATE_RECON_ACQ
      && m_strTSTAMP_TRANS == right.m_strTSTAMP_TRANS
      && m_siUNIQUENESS_KEY == right.m_siUNIQUENESS_KEY
      && m_strFUNCTION_CODE == right.m_strFUNCTION_CODE);
  //## end atm::ATMEvent::operator==%5C49C6A00245_eq.body
}

bool ATMEvent::operator!=(const ATMEvent &right) const
{
  //## begin atm::ATMEvent::operator!=%5C49C6A00245_neq.body preserve=yes
   return !operator==(right);
  //## end atm::ATMEvent::operator!=%5C49C6A00245_neq.body
}



//## Other Operations (implementation)
void ATMEvent::accept (atm::ATMBusinessDayVisitor& hATMBusinessDayVisitor)
{
  //## begin atm::ATMEvent::accept%5C49ED1801B2.body preserve=yes
   hATMBusinessDayVisitor.visitATMEvent(this);
   for (int i = 0;i < m_hATMActivity.size();++i)
      m_hATMActivity[i].accept(hATMBusinessDayVisitor);
  //## end atm::ATMEvent::accept%5C49ED1801B2.body
}

double ATMEvent::getCASSETTEn_BEGIN (int iIndex)
{
  //## begin atm::ATMEvent::getCASSETTEn_BEGIN%5D0275D802F1.body preserve=yes
   return m_dCASSETTEn_BEGIN[iIndex];
  //## end atm::ATMEvent::getCASSETTEn_BEGIN%5D0275D802F1.body
}

const reusable::string& ATMEvent::getCASSETTEn_CUR_CODE (int iIndex)
{
  //## begin atm::ATMEvent::getCASSETTEn_CUR_CODE%5DB88C8B0004.body preserve=yes
   return m_strCASSETTEn_CUR_CODE[iIndex];
  //## end atm::ATMEvent::getCASSETTEn_CUR_CODE%5DB88C8B0004.body
}

short int ATMEvent::getCASSETTEn_CUR_TYPE (int iIndex)
{
  //## begin atm::ATMEvent::getCASSETTEn_CUR_TYPE%5DB88CB30181.body preserve=yes
   return m_siCASSETTEn_CUR_TYPE[iIndex];
  //## end atm::ATMEvent::getCASSETTEn_CUR_TYPE%5DB88CB30181.body
}

double ATMEvent::getCASSETTEn_END (int iIndex)
{
  //## begin atm::ATMEvent::getCASSETTEn_END%5D0275FE0074.body preserve=yes
   return m_dCASSETTEn_END[iIndex];
  //## end atm::ATMEvent::getCASSETTEn_END%5D0275FE0074.body
}

int ATMEvent::getCASSETTEn_VALUE (int iIndex)
{
  //## begin atm::ATMEvent::getCASSETTEn_VALUE%5DB88CC5029F.body preserve=yes
   return m_iCASSETTEn_VALUE[iIndex];
  //## end atm::ATMEvent::getCASSETTEn_VALUE%5DB88CC5029F.body
}

int ATMEvent::getCassetteCount (int iIndex)
{
  //## begin atm::ATMEvent::getCassetteCount%5DBC3849026F.body preserve=yes
   return m_iCassetteCount[iIndex];
  //## end atm::ATMEvent::getCassetteCount%5DBC3849026F.body
}

struct  Fields* ATMEvent::fields () const
{
  //## begin atm::ATMEvent::fields%5C4B84B60198.body preserve=yes
   return &ATMEvent_Fields[0];
  //## end atm::ATMEvent::fields%5C4B84B60198.body
}

void ATMEvent::setCASSETTEn_BEGIN (int iIndex, double dCASSETTEn_BEGIN)
{
  //## begin atm::ATMEvent::setCASSETTEn_BEGIN%5D02770902A8.body preserve=yes
   m_dCASSETTEn_BEGIN[iIndex] = dCASSETTEn_BEGIN;
  //## end atm::ATMEvent::setCASSETTEn_BEGIN%5D02770902A8.body
}

void ATMEvent::setCASSETTEn_CUR_CODE (int iIndex, const reusable::string& strCASSETTEn_CUR_CODE)
{
  //## begin atm::ATMEvent::setCASSETTEn_CUR_CODE%5DB88D1D021D.body preserve=yes
   m_strCASSETTEn_CUR_CODE[iIndex] = strCASSETTEn_CUR_CODE;
  //## end atm::ATMEvent::setCASSETTEn_CUR_CODE%5DB88D1D021D.body
}

void ATMEvent::setCASSETTEn_CUR_TYPE (int iIndex, short int siCASSETTEn_CUR_TYPE)
{
  //## begin atm::ATMEvent::setCASSETTEn_CUR_TYPE%5DB88D29025F.body preserve=yes
   m_siCASSETTEn_CUR_TYPE[iIndex] = siCASSETTEn_CUR_TYPE;
  //## end atm::ATMEvent::setCASSETTEn_CUR_TYPE%5DB88D29025F.body
}

void ATMEvent::setCASSETTEn_END (int iIndex, double dCASSETTEn_END)
{
  //## begin atm::ATMEvent::setCASSETTEn_END%5D02A0D801C2.body preserve=yes
   m_dCASSETTEn_END[iIndex] = dCASSETTEn_END;
  //## end atm::ATMEvent::setCASSETTEn_END%5D02A0D801C2.body
}

void ATMEvent::setCASSETTEn_VALUE (int iIndex, int iCASSETTEn_VALUE)
{
  //## begin atm::ATMEvent::setCASSETTEn_VALUE%5DB88D33019E.body preserve=yes
   m_iCASSETTEn_VALUE[iIndex] = iCASSETTEn_VALUE;
  //## end atm::ATMEvent::setCASSETTEn_VALUE%5DB88D33019E.body
}

void ATMEvent::setCassetteCount (int iIndex, int iCassetteCount)
{
  //## begin atm::ATMEvent::setCassetteCount%5DBC90D1016C.body preserve=yes
   m_iCassetteCount[iIndex] = iCassetteCount;
  //## end atm::ATMEvent::setCassetteCount%5DBC90D1016C.body
}

void ATMEvent::setFields ()
{
  //## begin atm::ATMEvent::setFields%5D7915D1014A.body preserve=yes
   m_lNumberOfFields = FIELDS;
   delete [] m_pField;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strAE_STATE;
   m_pField[1] = &m_dCASH_BEGIN;
   m_pField[2] = &m_dCASH_END;
   m_pField[3] = &m_dCASSETTES_BEGIN;
   m_pField[4] = &m_dCASSETTES_END;
   int j = 4;
   for (int i = 0;i < 8;++i)
   {
      m_pField[++j] = &m_iCASSETTEn_VALUE[i];
      m_pField[++j] = &m_siCASSETTEn_CUR_TYPE[i];
      m_pField[++j] = &m_strCASSETTEn_CUR_CODE[i];
      m_pField[++j] = &m_dCASSETTEn_BEGIN[i];
      m_pField[++j] = &m_dCASSETTEn_END[i];
      m_pField[++j] = &m_iCassetteCount[i];
   }
   m_pField[53] = &m_dCHECK_BEGIN;
   m_pField[54] = &m_dCHECK_END;
   m_pField[55] = &m_strCUR_CODE;
   m_pField[56] = &m_strDATE_RECON_ACQ;
   m_pField[57] = &m_strFUNCTION_CODE;
   m_pField[58] = &m_strNET_TERM_ID;
   m_pField[59] = &m_dTELLER_BEGIN;
   m_pField[60] = &m_dTELLER_END;
   m_pField[61] = &m_strTASK_TOTALED;
   m_pField[62] = &m_strTSTAMP_TOTALED;
   m_pField[63] = &m_strTSTAMP_TRANS;
   m_pField[64] = &m_siUNIQUENESS_KEY;
  //## end atm::ATMEvent::setFields%5D7915D1014A.body
}

// Additional Declarations
  //## begin atm::ATMEvent%5C49C6A00245.declarations preserve=yes
  //## end atm::ATMEvent%5C49C6A00245.declarations

} // namespace atm

//## begin module%5C49C83E0241.epilog preserve=yes
//## end module%5C49C83E0241.epilog
