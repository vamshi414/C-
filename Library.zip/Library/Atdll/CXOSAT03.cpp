//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C49D1CD02F8.cm preserve=no
//	$Date:   Mar 05 2019 13:45:38  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%5C49D1CD02F8.cm

//## begin module%5C49D1CD02F8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C49D1CD02F8.cp

//## Module: CXOSAT03%5C49D1CD02F8; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Library\Atdll\CXOSAT03.cpp

//## begin module%5C49D1CD02F8.additionalIncludes preserve=no
//## end module%5C49D1CD02F8.additionalIncludes

//## begin module%5C49D1CD02F8.includes preserve=yes
//## end module%5C49D1CD02F8.includes

#ifndef CXOSAT04_h
#include "CXODAT04.hpp"
#endif
#ifndef CXOSAT02_h
#include "CXODAT02.hpp"
#endif
#ifndef CXOSAT03_h
#include "CXODAT03.hpp"
#endif


//## begin module%5C49D1CD02F8.declarations preserve=no
//## end module%5C49D1CD02F8.declarations

//## begin module%5C49D1CD02F8.additionalDeclarations preserve=yes
namespace
{
#define FIELDS 11
Fields ATMActivity_Fields[FIELDS + 1] =
{
   "l         ","ACTIVITY_GROUP",0,0,
   "l         ","ACTIVITY_TYPE",0,0,
   "d%-18.0f  ","AMT_RECON_NET",0,0,
   "d%-18.0f  ","AMT_SURCHARGE",0,0,
   "a         ","CUR_RECON_NET",0,0,
   "s%hd      ","CUR_TYPE",0,0,
   "a         ","IMPACT_TO_ACQ",0,0,
   "l%d       ","ITEM_COUNT",0,0,
   "l%d       ","ITEM_VALUE",0,0,
   "l%d       ","TRAN_COUNT",0,0,
   "a         ","TRAN_DISPOSITION",0,0,
   "~","~",0,0,
};
}
//## end module%5C49D1CD02F8.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::ATMActivity 

ATMActivity::ATMActivity()
  //## begin ATMActivity::ATMActivity%5C49D1A50341_const.hasinit preserve=no
      : m_nACTIVITY_TYPE(ATMActivity::WITHDRAWAL),
        m_dAMT_RECON_NET(0),
        m_dAMT_SURCHARGE(0),
        m_siCUR_TYPE(0),
        m_iITEM_COUNT(0),
        m_iITEM_VALUE(0),
        m_iTRAN_COUNT(0)
  //## end ATMActivity::ATMActivity%5C49D1A50341_const.hasinit
  //## begin ATMActivity::ATMActivity%5C49D1A50341_const.initialization preserve=yes
   ,PersistentSegment("XXXX","T_ATM_ACTIVITY")
  //## end ATMActivity::ATMActivity%5C49D1A50341_const.initialization
{
  //## begin atm::ATMActivity::ATMActivity%5C49D1A50341_const.body preserve=yes
   memcpy(m_sID,"ST72",4);
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_nACTIVITY_GROUP;
   m_pField[1] = &m_nACTIVITY_TYPE;
   m_pField[2] = &m_dAMT_RECON_NET;
   m_pField[3] = &m_dAMT_SURCHARGE;
   m_pField[4] = &m_strCUR_RECON_NET;
   m_pField[5] = &m_siCUR_TYPE;
   m_pField[6] = &m_strIMPACT_TO_ACQ;
   m_pField[7] = &m_iITEM_COUNT;
   m_pField[8] = &m_iITEM_VALUE;
   m_pField[9] = &m_iTRAN_COUNT;
   m_pField[10] = &m_strTRAN_DISPOSITION;
  //## end atm::ATMActivity::ATMActivity%5C49D1A50341_const.body
}

ATMActivity::ATMActivity(const ATMActivity &right)
  //## begin ATMActivity::ATMActivity%5C49D1A50341_copy.hasinit preserve=no
  //## end ATMActivity::ATMActivity%5C49D1A50341_copy.hasinit
  //## begin ATMActivity::ATMActivity%5C49D1A50341_copy.initialization preserve=yes
   : PersistentSegment(right)
   ,m_strCUR_RECON_NET(right.m_strCUR_RECON_NET)
   ,m_strIMPACT_TO_ACQ(right.m_strIMPACT_TO_ACQ)
   ,m_strTRAN_DISPOSITION(right.m_strTRAN_DISPOSITION)
  //## end ATMActivity::ATMActivity%5C49D1A50341_copy.initialization
{
  //## begin atm::ATMActivity::ATMActivity%5C49D1A50341_copy.body preserve=yes
   m_nACTIVITY_GROUP = right.m_nACTIVITY_GROUP;
   m_nACTIVITY_TYPE = right.m_nACTIVITY_TYPE;
   m_dAMT_RECON_NET = right.m_dAMT_RECON_NET;
   m_dAMT_SURCHARGE = right.m_dAMT_SURCHARGE;
   m_siCUR_TYPE = right.m_siCUR_TYPE;
   m_iITEM_COUNT = right.m_iITEM_COUNT;
   m_iITEM_VALUE = right.m_iITEM_VALUE;
   m_iTRAN_COUNT = right.m_iTRAN_COUNT;
  //## end atm::ATMActivity::ATMActivity%5C49D1A50341_copy.body
}


ATMActivity::~ATMActivity()
{
  //## begin atm::ATMActivity::~ATMActivity%5C49D1A50341_dest.body preserve=yes
  //## end atm::ATMActivity::~ATMActivity%5C49D1A50341_dest.body
}


ATMActivity & ATMActivity::operator=(const ATMActivity &right)
{
  //## begin atm::ATMActivity::operator=%5C49D1A50341_assign.body preserve=yes
   if (&right == this)
      return *this;
   PersistentSegment::operator=(right);
   m_nACTIVITY_GROUP = right.m_nACTIVITY_GROUP;
   m_nACTIVITY_TYPE = right.m_nACTIVITY_TYPE;
   m_dAMT_RECON_NET = right.m_dAMT_RECON_NET;
   m_dAMT_SURCHARGE = right.m_dAMT_SURCHARGE;
   m_strCUR_RECON_NET = right.m_strCUR_RECON_NET;
   m_siCUR_TYPE = right.m_siCUR_TYPE;
   m_strIMPACT_TO_ACQ = right.m_strIMPACT_TO_ACQ;
   m_iITEM_COUNT = right.m_iITEM_COUNT;
   m_iITEM_VALUE = right.m_iITEM_VALUE;
   m_iTRAN_COUNT = right.m_iTRAN_COUNT;
   m_strTRAN_DISPOSITION = right.m_strTRAN_DISPOSITION;
   return *this;
  //## end atm::ATMActivity::operator=%5C49D1A50341_assign.body
}



//## Other Operations (implementation)
void ATMActivity::accept (atm::ATMBusinessDayVisitor& hATMBusinessDayVisitor)
{
  //## begin atm::ATMActivity::accept%5C49ED1A0074.body preserve=yes
   hATMBusinessDayVisitor.visitATMActivity(this);
  //## end atm::ATMActivity::accept%5C49ED1A0074.body
}

struct  Fields* ATMActivity::fields () const
{
  //## begin atm::ATMActivity::fields%5C4B87B000D1.body preserve=yes
   return &ATMActivity_Fields[0];
  //## end atm::ATMActivity::fields%5C4B87B000D1.body
}

// Additional Declarations
  //## begin atm::ATMActivity%5C49D1A50341.declarations preserve=yes
  //## end atm::ATMActivity%5C49D1A50341.declarations

} // namespace atm

//## begin module%5C49D1CD02F8.epilog preserve=yes
//## end module%5C49D1CD02F8.epilog
