//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39AFA30D0247.cm preserve=no
//	$Date:   Jul 23 2021 14:19:00  $ $Author:   e1009839  $
//	$Revision:   1.4  $
//## end module%39AFA30D0247.cm

//## begin module%39AFA30D0247.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39AFA30D0247.cp

//## Module: CXOSAT09%39AFA30D0247; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Atdll\CXOSAT09.cpp

//## begin module%39AFA30D0247.additionalIncludes preserve=no
//## end module%39AFA30D0247.additionalIncludes

//## begin module%39AFA30D0247.includes preserve=yes
//## end module%39AFA30D0247.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSAT03_h
#include "CXODAT03.hpp"
#endif
#ifndef CXOSAT09_h
#include "CXODAT09.hpp"
#endif


//## begin module%39AFA30D0247.declarations preserve=no
//## end module%39AFA30D0247.declarations

//## begin module%39AFA30D0247.additionalDeclarations preserve=yes
//## end module%39AFA30D0247.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::AdminMessage 

AdminMessage::AdminMessage()
  //## begin AdminMessage::AdminMessage%39AF966903AD_const.hasinit preserve=no
      : m_dDEVICE_AMT(0),
        m_iDEVICE_CUR_TYPE(0),
        m_iNull(0),
        m_iUNIQUENESS_KEY(0)
  //## end AdminMessage::AdminMessage%39AF966903AD_const.hasinit
  //## begin AdminMessage::AdminMessage%39AF966903AD_const.initialization preserve=yes
  //## end AdminMessage::AdminMessage%39AF966903AD_const.initialization
{
  //## begin atm::AdminMessage::AdminMessage%39AF966903AD_const.body preserve=yes
   memcpy(m_sID,"AT09",4);
   for (int i = 0;i <= 7;++i)
   {
      m_siCAN_CUR_TYPEn[i] = 0;
      m_dCAN_ITEM_AMTn[i] = 0;
      m_iCAN_ITEM_COUNTn[i] = 0;
      m_iCAN_ITEM_VALUEn[i] = 0;
   }
   for (int i = 0;i < 12;++i)
      m_iITEM_COUNT[i] = 0;
   for (int i = 0;i <= TOTAL_CASSETTE8;++i)
   {
      m_dCredit[i] = 0;
      m_siCUR_TYPE[i] = 0;
      m_dDebit[i] = 0;
      m_iITEM_VALUE[i] = 0;
   }
  //## end atm::AdminMessage::AdminMessage%39AF966903AD_const.body
}


AdminMessage::~AdminMessage()
{
  //## begin atm::AdminMessage::~AdminMessage%39AF966903AD_dest.body preserve=yes
  //## end atm::AdminMessage::~AdminMessage%39AF966903AD_dest.body
}



//## Other Operations (implementation)
void AdminMessage::bind (Query& hQuery, string& strLocator)
{
  //## begin atm::AdminMessage::bind%39AFA13002B9.body preserve=yes
   hQuery.bind(strLocator.c_str(),"FUNCTION_CODE",Column::STRING,&m_strFUNCTION_CODE,&m_iNull);
   hQuery.bind(strLocator.c_str(),"NET_TERM_ID",Column::STRING,&m_strNET_TERM_ID);
   char szTemp[9] = {"01234567"};
   char x2[2] = {" "};
   string strCAN_CUR_CODEn("CAN_CUR_CODEn");
   string strCAN_CUR_TYPEn("CAN_CUR_TYPEn");
   string strCAN_ITEM_AMTn("CAN_ITEM_AMTn");
   string strCAN_ITEM_COUNTn("CAN_ITEM_COUNTn");
   string strCAN_ITEM_VALUEn("CAN_ITEM_VALUEn");
   for (int i = 0;i <= 7;++i)
   {
      x2[0] = szTemp[i];
      strCAN_CUR_CODEn.replace(12,1,x2);
      strCAN_CUR_TYPEn.replace(12,1,x2);
      strCAN_ITEM_AMTn.replace(12,1,x2);
      strCAN_ITEM_COUNTn.replace(14,1,x2);
      strCAN_ITEM_VALUEn.replace(14,1,x2);
      hQuery.bind("DEV_ADMIN",strCAN_CUR_CODEn.c_str(),Column::STRING,&m_strCAN_CUR_CODEn[i]);
      hQuery.bind("DEV_ADMIN",strCAN_CUR_TYPEn.c_str(),Column::SHORT,&m_siCAN_CUR_TYPEn[i]);
      hQuery.bind("DEV_ADMIN",strCAN_ITEM_AMTn.c_str(),Column::DOUBLE,&m_dCAN_ITEM_AMTn[i]);
      hQuery.bind("DEV_ADMIN",strCAN_ITEM_COUNTn.c_str(),Column::LONG,&m_iCAN_ITEM_COUNTn[i]);
      hQuery.bind("DEV_ADMIN",strCAN_ITEM_VALUEn.c_str(),Column::LONG,&m_iCAN_ITEM_VALUEn[i]);
   }
   hQuery.bind("DEV_ADMIN","CLERK_ID",Column::STRING,&m_strCLERK_ID);
   hQuery.bind("DEV_ADMIN","DEVICE_CUR_TRAN",Column::STRING,&m_strDEVICE_CUR_TRAN);
   hQuery.bind("DEV_ADMIN","DEVICE_CUR_TYPE",Column::SHORT,&m_iDEVICE_CUR_TYPE);
   hQuery.bind("DEV_ADMIN","DEVICE_AMT",Column::DOUBLE,&m_dDEVICE_AMT);
   hQuery.bind("DEV_ADMIN","RECON_IND_ACQ",Column::STRING,&m_strRECON_IND_ACQ);
   hQuery.bind("DEV_ADMIN","TSTAMP_TRANS",Column::STRING,&m_strTSTAMP_TRANS);
   hQuery.bind("DEV_ADMIN","UNIQUENESS_KEY",Column::SHORT,&m_iUNIQUENESS_KEY);
  //## end atm::AdminMessage::bind%39AFA13002B9.body
}

double AdminMessage::getCredit (int iIndex) const
{
  //## begin atm::AdminMessage::getCredit%5DE90974010C.body preserve=yes
   return m_dCredit[iIndex];
  //## end atm::AdminMessage::getCredit%5DE90974010C.body
}

double AdminMessage::getDebit (int iIndex) const
{
  //## begin atm::AdminMessage::getDebit%5DE909740171.body preserve=yes
   return m_dDebit[iIndex];
  //## end atm::AdminMessage::getDebit%5DE909740171.body
}

bool AdminMessage::getLocatorColumns ()
{
  //## begin atm::AdminMessage::getLocatorColumns%5C4F19AE02A5.body preserve=yes
   Query hQuery;
   m_strLocator = "DEV_ADMIN_L";
   m_strLocator += m_strTSTAMP_TRANS.substr(0,6);
   hQuery.bind(m_strLocator.c_str(),"FUNCTION_CODE",Column::STRING,&m_strFUNCTION_CODE);
   hQuery.bind(m_strLocator.c_str(),"NET_TERM_ID",Column::STRING,&m_strNET_TERM_ID);
   hQuery.setBasicPredicate(m_strLocator.c_str(),"TSTAMP_TRANS","=",m_strTSTAMP_TRANS.c_str());
   hQuery.setBasicPredicate(m_strLocator.c_str(),"UNIQUENESS_KEY","=",m_iUNIQUENESS_KEY);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   return pSelectStatement->execute(hQuery);
  //## end atm::AdminMessage::getLocatorColumns%5C4F19AE02A5.body
}

void AdminMessage::reset ()
{
  //## begin atm::AdminMessage::reset%5DE91E9101F5.body preserve=yes
   for (int i = 0;i <= CASSETTE8;++i)
      m_iITEM_COUNT[i] = 0;
   for (int i = 0;i <= TOTAL_CASSETTE8;++i)
   {
      m_dCredit[i] = 0;
      m_strCUR_CODE[i].erase();
      m_siCUR_TYPE[i] = 0;
      m_dDebit[i] = 0;
      m_iITEM_VALUE[i] = 0;
   }
  //## end atm::AdminMessage::reset%5DE91E9101F5.body
}

void AdminMessage::setActivity (reusable::Table& hTable)
{
  //## begin atm::AdminMessage::setActivity%5DE8231B03B4.body preserve=yes
   for (int i = CASSETTE1;i <= CASSETTE8;++i)
   {
      m_iITEM_COUNT[i] = 0;
      m_iITEM_VALUE[i] = 0;
      m_siCUR_TYPE[i] = 0;
      m_dDebit[i] = 0;
      m_dCredit[i] = 0;
   }
   hTable.set("ACTIVITY_GROUP",(int)atm::ATMActivity::ACTIVITY_ONUS,true);
   hTable.set("TRAN_DISPOSITION","1",false,true);
   hTable.set("CUR_RECON_NET",m_strDEVICE_CUR_TRAN);
   hTable.set("CUR_TYPE",(int)0);
   if (m_strFUNCTION_CODE == "595")
   {
      hTable.set("ACTIVITY_TYPE",(int)atm::ATMActivity::TELLER_DEPOSIT,true);
      m_dDebit[TELLER] += m_dDEVICE_AMT;
      for (int i = 0; i < 8; ++i)
      {
         m_dDebit[TELLER] += m_dCAN_ITEM_AMTn[i];
         m_dDEVICE_AMT += m_dCAN_ITEM_AMTn[i];
      }
      hTable.set("IMPACT_TO_ACQ","1");
   }
   else
   {
      hTable.set("ACTIVITY_TYPE",(int)atm::ATMActivity::TELLER_WITHDRAWAL,true);
      m_dDEVICE_AMT = 0;
      for (int i = 0;i < 8;++i)
      {
          if (m_iCAN_ITEM_VALUEn[i] > 0
             && m_iCAN_ITEM_COUNTn[i] > 0)
          {
             m_dCredit[i + CASSETTE1] += m_iCAN_ITEM_COUNTn[i] * m_iCAN_ITEM_VALUEn[i];
             m_dCredit[i + TOTAL_CASSETTE1] += m_iCAN_ITEM_COUNTn[i] * m_iCAN_ITEM_VALUEn[i];
             m_dDEVICE_AMT += m_iCAN_ITEM_COUNTn[i] * m_iCAN_ITEM_VALUEn[i];
             m_iITEM_COUNT[i + CASSETTE1] += m_iCAN_ITEM_COUNTn[i];
             m_strCUR_CODE[i + CASSETTE1] = m_strCAN_CUR_CODEn[i];
             m_iITEM_VALUE[i + CASSETTE1] = m_iCAN_ITEM_VALUEn[i];
             m_siCUR_TYPE[i + CASSETTE1] = 1;
             m_strCUR_CODE[i + TOTAL_CASSETTE1] = m_strCAN_CUR_CODEn[i];
             m_iITEM_VALUE[i + TOTAL_CASSETTE1] = m_iCAN_ITEM_VALUEn[i];
             m_siCUR_TYPE[i + TOTAL_CASSETTE1] = 1;
          }
      }
      hTable.set("IMPACT_TO_ACQ","2");
   }
   hTable.set("AMT_RECON_NET",m_dDEVICE_AMT,false,"+");
   hTable.set("AMT_SURCHARGE",(double)0);
   hTable.set("TRAN_COUNT",(int)1,false,"+");
   hTable.set("ITEM_VALUE",(int)0);
   hTable.set("ITEM_COUNT",(int)0);
  //## end atm::AdminMessage::setActivity%5DE8231B03B4.body
}

// Additional Declarations
  //## begin atm::AdminMessage%39AF966903AD.declarations preserve=yes
  //## end atm::AdminMessage%39AF966903AD.declarations

} // namespace atm

//## begin module%39AFA30D0247.epilog preserve=yes
//## end module%39AFA30D0247.epilog
