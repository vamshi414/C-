//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5DE689C102FC.cm preserve=no
//	$Date:   Dec 11 2019 09:59:06  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5DE689C102FC.cm

//## begin module%5DE689C102FC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5DE689C102FC.cp

//## Module: CXOSAT11%5DE689C102FC; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Atdll\CXODAT11.hpp

#ifndef CXOSAT11_h
#define CXOSAT11_h 1

//## begin module%5DE689C102FC.additionalIncludes preserve=no
//## end module%5DE689C102FC.additionalIncludes

//## begin module%5DE689C102FC.includes preserve=yes
//## end module%5DE689C102FC.includes

#ifndef CXOSAT04_h
#include "CXODAT04.hpp"
#endif

//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
class ATMActivity;
class ATMEvent;
} // namespace atm

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class GenericSegment;

} // namespace segment

//## begin module%5DE689C102FC.declarations preserve=no
//## end module%5DE689C102FC.declarations

//## begin module%5DE689C102FC.additionalDeclarations preserve=yes
//## end module%5DE689C102FC.additionalDeclarations


namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::SettlementReportVisitor%5DE689280229.preface preserve=yes
//## end atm::SettlementReportVisitor%5DE689280229.preface

//## Class: SettlementReportVisitor%5DE689280229
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5DE689630257;segment::GenericSegment { -> F}
//## Uses: <unnamed>%5DE689660310;ATMActivity { -> F}

class DllExport SettlementReportVisitor : public ATMBusinessDayVisitor  //## Inherits: <unnamed>%5DE689600076
{
  //## begin atm::SettlementReportVisitor%5DE689280229.initialDeclarations preserve=yes
  //## end atm::SettlementReportVisitor%5DE689280229.initialDeclarations

  public:
    //## Constructors (generated)
      SettlementReportVisitor();

    //## Destructor (generated)
      virtual ~SettlementReportVisitor();


    //## Other Operations (specified)
      //## Operation: instance%5DE6899E02C3
      static atm::SettlementReportVisitor* instance ();

      //## Operation: load%5DE6899E0300
      void load (const vector<string>& hTemplate);

      //## Operation: populate%5DE6899E031A
      void populate (segment::GenericSegment& hGenericSegment);

      //## Operation: visitATMActivity%5DE6899E032B
      virtual void visitATMActivity (atm::ATMActivity* pATMActivity);

      //## Operation: visitATMEvent%5DE6899E033C
      virtual void visitATMEvent (atm::ATMEvent* pATMEvent);

    // Additional Public Declarations
      //## begin atm::SettlementReportVisitor%5DE689280229.public preserve=yes
      //## end atm::SettlementReportVisitor%5DE689280229.public

  protected:
    // Additional Protected Declarations
      //## begin atm::SettlementReportVisitor%5DE689280229.protected preserve=yes
      //## end atm::SettlementReportVisitor%5DE689280229.protected

  private:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: TSTAMP_TRANS%5DE689AA00D8
      const reusable::string& getTSTAMP_TRANS () const
      {
        //## begin atm::SettlementReportVisitor::getTSTAMP_TRANS%5DE689AA00D8.get preserve=no
        return m_strTSTAMP_TRANS;
        //## end atm::SettlementReportVisitor::getTSTAMP_TRANS%5DE689AA00D8.get
      }

      void setTSTAMP_TRANS (const reusable::string& value)
      {
        //## begin atm::SettlementReportVisitor::setTSTAMP_TRANS%5DE689AA00D8.set preserve=no
        m_strTSTAMP_TRANS = value;
        //## end atm::SettlementReportVisitor::setTSTAMP_TRANS%5DE689AA00D8.set
      }


    // Additional Private Declarations
      //## begin atm::SettlementReportVisitor%5DE689280229.private preserve=yes
      //## end atm::SettlementReportVisitor%5DE689280229.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Amount%5DE689AA006C
      //## begin atm::SettlementReportVisitor::Amount%5DE689AA006C.attr preserve=no  private: map<string,vector<double>,less<string> > {V} 
      map<string,vector<double>,less<string> > m_hAmount;
      //## end atm::SettlementReportVisitor::Amount%5DE689AA006C.attr

      //## Attribute: Count%5DE689AA0080
      //## begin atm::SettlementReportVisitor::Count%5DE689AA0080.attr preserve=no  private: map<string,vector<int>,less<string> > {V} 
      map<string,vector<int>,less<string> > m_hCount;
      //## end atm::SettlementReportVisitor::Count%5DE689AA0080.attr

      //## Attribute: Instance%5DE689AA0095
      //## begin atm::SettlementReportVisitor::Instance%5DE689AA0095.attr preserve=no  private: static atm::SettlementReportVisitor* {V} 0
      static atm::SettlementReportVisitor* m_pInstance;
      //## end atm::SettlementReportVisitor::Instance%5DE689AA0095.attr

      //## Attribute: Sum%5DE689AA00C0
      //## begin atm::SettlementReportVisitor::Sum%5DE689AA00C0.attr preserve=no  private: multimap<short,string,less<short> > {U} 
      multimap<short,string,less<short> > m_hSum;
      //## end atm::SettlementReportVisitor::Sum%5DE689AA00C0.attr

      //## begin atm::SettlementReportVisitor::TSTAMP_TRANS%5DE689AA00D8.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTSTAMP_TRANS;
      //## end atm::SettlementReportVisitor::TSTAMP_TRANS%5DE689AA00D8.attr

    // Data Members for Associations

      //## Association: Totals Management::ATM_CAT::<unnamed>%5DE68986023B
      //## Role: SettlementReportVisitor::<m_pATMEvent>%5DE6898701E1
      //## begin atm::SettlementReportVisitor::<m_pATMEvent>%5DE6898701E1.role preserve=no  public: atm::ATMEvent { -> RFHgN}
      ATMEvent *m_pATMEvent;
      //## end atm::SettlementReportVisitor::<m_pATMEvent>%5DE6898701E1.role

    // Additional Implementation Declarations
      //## begin atm::SettlementReportVisitor%5DE689280229.implementation preserve=yes
      //## end atm::SettlementReportVisitor%5DE689280229.implementation

};

//## begin atm::SettlementReportVisitor%5DE689280229.postscript preserve=yes
//## end atm::SettlementReportVisitor%5DE689280229.postscript

} // namespace atm

//## begin module%5DE689C102FC.epilog preserve=yes
//## end module%5DE689C102FC.epilog


#endif
