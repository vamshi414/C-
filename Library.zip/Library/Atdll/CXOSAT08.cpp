//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C6568700295.cm preserve=no
//	$Date:   Feb 27 2020 13:38:26  $ $Author:   e1009839  $
//	$Revision:   1.11  $
//## end module%5C6568700295.cm

//## begin module%5C6568700295.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C6568700295.cp

//## Module: CXOSAT08%5C6568700295; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Atdll\CXOSAT08.cpp

//## begin module%5C6568700295.additionalIncludes preserve=no
//## end module%5C6568700295.additionalIncludes

//## begin module%5C6568700295.includes preserve=yes
#include "CXODTM03.hpp"
#include "CXODNS29.hpp"
//## end module%5C6568700295.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSAT02_h
#include "CXODAT02.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSAT08_h
#include "CXODAT08.hpp"
#endif


//## begin module%5C6568700295.declarations preserve=no
//## end module%5C6568700295.declarations

//## begin module%5C6568700295.additionalDeclarations preserve=yes
#define STS_DUPLICATE_RECORD 35
//## end module%5C6568700295.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::ATMInstitution

//## begin atm::ATMInstitution::Instance%5C6569010004.attr preserve=no  private: static atm::ATMInstitution* {V} 0
atm::ATMInstitution* ATMInstitution::m_pInstance = 0;
//## end atm::ATMInstitution::Instance%5C6569010004.attr

ATMInstitution::ATMInstitution()
  //## begin ATMInstitution::ATMInstitution%5C65681E026B_const.hasinit preserve=no
  //## end ATMInstitution::ATMInstitution%5C65681E026B_const.hasinit
  //## begin ATMInstitution::ATMInstitution%5C65681E026B_const.initialization preserve=yes
  //## end ATMInstitution::ATMInstitution%5C65681E026B_const.initialization
{
  //## begin atm::ATMInstitution::ATMInstitution%5C65681E026B_const.body preserve=yes
   memcpy(m_sID,"AT08",4);
  //## end atm::ATMInstitution::ATMInstitution%5C65681E026B_const.body
}


ATMInstitution::~ATMInstitution()
{
  //## begin atm::ATMInstitution::~ATMInstitution%5C65681E026B_dest.body preserve=yes
  //## end atm::ATMInstitution::~ATMInstitution%5C65681E026B_dest.body
}



//## Other Operations (implementation)
bool ATMInstitution::addEndOfDay (atm::ATMEvent& hATMEvent, int iRows)
{
  //## begin atm::ATMInstitution::addEndOfDay%5C6568D30379.body preserve=yes
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (iRows == 0)
   {
      // prevent trigger if this ATM is inactive
      string strDate(hATMEvent.getDATE_RECON_ACQ());
      Date hDate(strDate.c_str());
      hDate -= 30;
      strDate = hDate.asString("%Y%m%d");
      string strDATE_RECON_ACQ;
      Query hQuery;
      hQuery.bind("T_ATM_EVENT","DATE_RECON_ACQ",Column::STRING,&strDATE_RECON_ACQ,0,"MIN");
      hQuery.setBasicPredicate("T_ATM_EVENT","NET_TERM_ID","=",hATMEvent.getNET_TERM_ID().c_str());
      if (!pSelectStatement->execute(hQuery))
         return false;
      if (strDATE_RECON_ACQ < strDate)
      {
         int i = 0;
         Query hQuery;
         hQuery.bind("T_ATM_ACTIVITY","*",Column::LONG,&i,0,"COUNT");
         hQuery.setBasicPredicate("T_ATM_ACTIVITY","NET_TERM_ID","=",hATMEvent.getNET_TERM_ID().c_str());
         hQuery.setBasicPredicate("T_ATM_ACTIVITY","DATE_RECON_ACQ",">",strDate.c_str());
         hQuery.setBasicPredicate("T_ATM_ACTIVITY","ACTIVITY_GROUP","IN","(100,200)");
         if (!pSelectStatement->execute(hQuery))
            return false;
         if (i == 0)
            return true;
      }
   }
   string strCUTOFF_IND[2];
   string strCUTOFF_TIME[2];
   Query hQuery;
   hQuery.setQualifier("QUALIFY","DEVICE");
   hQuery.setQualifier("QUALIFY","INSTITUTION");
   hQuery.join("DEVICE","INNER","INSTITUTION","INST_ID");
   hQuery.bind("DEVICE","CUTOFF_IND",Column::STRING,&strCUTOFF_IND[0]);
   hQuery.bind("DEVICE","CUTOFF_TIME",Column::STRING,&strCUTOFF_TIME[0]);
   hQuery.bind("INSTITUTION","CUTOFF_IND",Column::STRING,&strCUTOFF_IND[1]);
   hQuery.bind("INSTITUTION","CUTOFF_TIME",Column::STRING,&strCUTOFF_TIME[1]);
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.setBasicPredicate("DEVICE","DEVICE_ID","=",hATMEvent.getNET_TERM_ID().c_str());
   hQuery.setBasicPredicate("DEVICE","CUST_ID","=",strCUST_ID.c_str());
   hQuery.setBasicPredicate("DEVICE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("DEVICE","CC_STATE","=","A");
   hQuery.setBasicPredicate("INSTITUTION","CUST_ID","=",strCUST_ID.c_str());
   hQuery.setBasicPredicate("INSTITUTION","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("INSTITUTION","CC_STATE","=","A");
   if (!pSelectStatement->execute(hQuery))
      return false;
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   string strDate(hATMEvent.getDATE_RECON_ACQ());
   Date hDate(strDate.c_str());
   for (int i = 0;i < 3;++i)
   {
      Table hTable("T_ATM_EVENT");
      ATMEvent x;
      x.setNET_TERM_ID(hATMEvent.getNET_TERM_ID());
      x.setDATE_RECON_ACQ(strDate);
      strDate.resize(16,'0');
      x.setUNIQUENESS_KEY(0);
      x.setCUR_CODE(hATMEvent.getCUR_CODE());
      for (int j = 0;j < 2;++j)
         if (strCUTOFF_IND[j] == "1")
         {
            strDate.replace(8,strCUTOFF_TIME[j].length(),strCUTOFF_TIME[j].data(),strCUTOFF_TIME[j].length());
            x.setTSTAMP_TRANS(strDate);
            x.setFUNCTION_CODE(j == 0 ? "572" : "999");
            {
               // handle changes to CUTOFF_TIME
               auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
               Query hQuery;
               hQuery.setBasicPredicate("T_ATM_EVENT","NET_TERM_ID","=",hATMEvent.getNET_TERM_ID().c_str());
               hQuery.setBasicPredicate("T_ATM_EVENT","DATE_RECON_ACQ",">",entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(0).c_str());
               string strValue(strDate);
               strValue.replace(0,8,"________",8);
               hQuery.setBasicPredicate("T_ATM_EVENT","TSTAMP_TRANS","NOT LIKE",strValue.c_str());
               hQuery.setBasicPredicate("T_ATM_EVENT","FUNCTION_CODE","=",x.getFUNCTION_CODE().c_str());
               hQuery.setBasicPredicate("T_ATM_EVENT","AE_STATE","=","TW");
               pDeleteStatement->execute(hQuery);
            }
            x.setColumns(hTable);
            if (pInsertStatement->execute(hTable) == false
               && pInsertStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
               return false;
            if (j == 1)
            {
               strDate.replace(8,8,"23595999",8);
               x.setTSTAMP_TRANS(strDate);
               x.setFUNCTION_CODE("998");
               x.setColumns(hTable);
               if (pInsertStatement->execute(hTable) == false
                  && pInsertStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
                  return false;
            }
         }
      hDate += 1;
      strDate = hDate.asString("%Y%m%d");
   }
   if (hATMEvent.getFUNCTION_CODE() != "999")
      return true;
   Table hTable("T_ATM_EVENT");
   hTable.set("NET_TERM_ID",hATMEvent.getNET_TERM_ID(),false,true);
   strDate = hATMEvent.getDATE_RECON_ACQ();
   Date xDate(strDate.c_str());
   xDate += 1;
   strDate = xDate.asString("%Y%m%d");
   hTable.set("DATE_RECON_ACQ",strDate,false,true);
   strDate.replace(8,8,"23595999",8);
   hTable.set("TSTAMP_TRANS",strDate,false,true);
   hTable.set("UNIQUENESS_KEY",(short)0,true);
   hTable.set("FUNCTION_CODE",string("998"),false,true);
   hTable.set("CASH_END",hATMEvent.getCASH_END(),false,"+");
   hTable.set("CHECK_END",hATMEvent.getCHECK_END(),false,"+");
   hTable.set("CASSETTES_END",hATMEvent.getCASSETTES_END(),false,"+");
   char szTemp[9] = {"12345678"};
   char szCASSETTEn_END[14] = {"CASSETTEn_END"};
   char szCASSETTEn_VALUE[16] = {"CASSETTEn_VALUE"};
   char szCASSETTEn_CUR_TYPE[19] = {"CASSETTEn_CUR_TYPE"};
   char szCASSETTEn_CUR_CODE[19] = {"CASSETTEn_CUR_CODE"};
   for (int i = 0;i < 8;++i)
   {
       szCASSETTEn_END[8] = szTemp[i];
       hTable.set(szCASSETTEn_END,hATMEvent.getCASSETTEn_END(i),false,"+");
       szCASSETTEn_VALUE[8] = szTemp[i];
       hTable.set(szCASSETTEn_VALUE,hATMEvent.getCASSETTEn_VALUE(i));
       szCASSETTEn_CUR_TYPE[8] = szTemp[i];
       hTable.set(szCASSETTEn_CUR_TYPE,hATMEvent.getCASSETTEn_CUR_TYPE(i));
       szCASSETTEn_CUR_CODE[8] = szTemp[i];
       hTable.set(szCASSETTEn_CUR_CODE,hATMEvent.getCASSETTEn_CUR_CODE(i));
   }
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   return pUpdateStatement->execute(hTable);
  //## end atm::ATMInstitution::addEndOfDay%5C6568D30379.body
}

atm::ATMInstitution* ATMInstitution::instance ()
{
  //## begin atm::ATMInstitution::instance%5C656919023A.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ATMInstitution();
   return m_pInstance;
  //## end atm::ATMInstitution::instance%5C656919023A.body
}

// Additional Declarations
  //## begin atm::ATMInstitution%5C65681E026B.declarations preserve=yes
  //## end atm::ATMInstitution%5C65681E026B.declarations

} // namespace atm

//## begin module%5C6568700295.epilog preserve=yes
//## end module%5C6568700295.epilog
