//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5DCC5B2402AF.cm preserve=no
//	$Date:   Nov 14 2019 08:23:36  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5DCC5B2402AF.cm

//## begin module%5DCC5B2402AF.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5DCC5B2402AF.cp

//## Module: CXOSAT10%5DCC5B2402AF; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Atdll\CXODAT10.hpp

#ifndef CXOSAT10_h
#define CXOSAT10_h 1

//## begin module%5DCC5B2402AF.additionalIncludes preserve=no
//## end module%5DCC5B2402AF.additionalIncludes

//## begin module%5DCC5B2402AF.includes preserve=yes
//## end module%5DCC5B2402AF.includes

#ifndef CXOSRU46_h
#include "CXODRU46.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class WitchingHour;
} // namespace timer

namespace database {
class Cache;

} // namespace database

//## begin module%5DCC5B2402AF.declarations preserve=no
//## end module%5DCC5B2402AF.declarations

//## begin module%5DCC5B2402AF.additionalDeclarations preserve=yes
//## end module%5DCC5B2402AF.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::Hierarchy%5DCC32BB03CC.preface preserve=yes
//## end atm::Hierarchy%5DCC32BB03CC.preface

//## Class: Hierarchy%5DCC32BB03CC
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5DCC617F0239;IF::Extract { -> F}
//## Uses: <unnamed>%5DCC61820120;reusable::Query { -> F}
//## Uses: <unnamed>%5DCC61840049;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5DCC61860180;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5DCD5CBF0295;timer::WitchingHour { -> F}
//## Uses: <unnamed>%5DCD5D650002;database::Cache { -> F}

class DllExport Hierarchy : public reusable::Cache  //## Inherits: <unnamed>%5DCC363B0291
{
  //## begin atm::Hierarchy%5DCC32BB03CC.initialDeclarations preserve=yes
  //## end atm::Hierarchy%5DCC32BB03CC.initialDeclarations

  public:
    //## Constructors (generated)
      Hierarchy();

    //## Destructor (generated)
      virtual ~Hierarchy();


    //## Other Operations (specified)
      //## Operation: instance%5DCD568902F4
      static Hierarchy* instance ();

      //## Operation: isPseudoTerminal%5DCC5CC200EB
      bool isPseudoTerminal (const reusable::string& strDEVICE_ID);

      //## Operation: load%5DCC391801F0
      virtual bool load ();

      //## Operation: update%5DCC391A0105
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin atm::Hierarchy%5DCC32BB03CC.public preserve=yes
      //## end atm::Hierarchy%5DCC32BB03CC.public

  protected:
    // Additional Protected Declarations
      //## begin atm::Hierarchy%5DCC32BB03CC.protected preserve=yes
      //## end atm::Hierarchy%5DCC32BB03CC.protected

  private:
    // Additional Private Declarations
      //## begin atm::Hierarchy%5DCC32BB03CC.private preserve=yes
      //## end atm::Hierarchy%5DCC32BB03CC.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DEVICE_ID%5DCC619D039B
      //## begin atm::Hierarchy::DEVICE_ID%5DCC619D039B.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strDEVICE_ID;
      //## end atm::Hierarchy::DEVICE_ID%5DCC619D039B.attr

      //## Attribute: Instance%5DCD56A600FA
      //## begin atm::Hierarchy::Instance%5DCD56A600FA.attr preserve=no  private: static Hierarchy* {V} 0
      static Hierarchy* m_pInstance;
      //## end atm::Hierarchy::Instance%5DCD56A600FA.attr

      //## Attribute: PseudoTerminal%5DCC5BE3024E
      //## begin atm::Hierarchy::PseudoTerminal%5DCC5BE3024E.attr preserve=no  private: set<string,less<string> > {V} 
      set<string,less<string> > m_hPseudoTerminal;
      //## end atm::Hierarchy::PseudoTerminal%5DCC5BE3024E.attr

    // Additional Implementation Declarations
      //## begin atm::Hierarchy%5DCC32BB03CC.implementation preserve=yes
      //## end atm::Hierarchy%5DCC32BB03CC.implementation

};

//## begin atm::Hierarchy%5DCC32BB03CC.postscript preserve=yes
//## end atm::Hierarchy%5DCC32BB03CC.postscript

} // namespace atm

//## begin module%5DCC5B2402AF.epilog preserve=yes
//## end module%5DCC5B2402AF.epilog


#endif
