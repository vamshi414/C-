//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C49D1C90069.cm preserve=no
//	$Date:   Jan 23 2020 10:26:54  $ $Author:   e1009839  $
//	$Revision:   1.3  $
//## end module%5C49D1C90069.cm

//## begin module%5C49D1C90069.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C49D1C90069.cp

//## Module: CXOSAT03%5C49D1C90069; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Library\Atdll\CXODAT03.hpp

#ifndef CXOSAT03_h
#define CXOSAT03_h 1

//## begin module%5C49D1C90069.additionalIncludes preserve=no
//## end module%5C49D1C90069.additionalIncludes

//## begin module%5C49D1C90069.includes preserve=yes
//## end module%5C49D1C90069.includes

#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif

//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
class ATMEvent;
class ATMBusinessDayVisitor;

} // namespace atm

//## begin module%5C49D1C90069.declarations preserve=no
//## end module%5C49D1C90069.declarations

//## begin module%5C49D1C90069.additionalDeclarations preserve=yes
//## end module%5C49D1C90069.additionalDeclarations


namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::ATMActivity%5C49D1A50341.preface preserve=yes
//## end atm::ATMActivity%5C49D1A50341.preface

//## Class: ATMActivity%5C49D1A50341
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5C49EB9C03BC;ATMBusinessDayVisitor { -> F}
//## Uses: <unnamed>%5C532C290375;ATMEvent { -> F}

class DllExport ATMActivity : public segment::PersistentSegment  //## Inherits: <unnamed>%5C4B83E00233
{
  //## begin atm::ATMActivity%5C49D1A50341.initialDeclarations preserve=yes
  public:
      enum ActivityGroup
      {
         NONE = 0,
         UNKNOWN = 1,
         ACTIVITY_ONUS = 100,
         ACTIVITY_FOREIGN = 200,
         CASH_SUBTRACT = 300,
         CASH_ADD = 400,
         TERMINAL_SETTLE_ONUS = 500,
         TERMINAL_SETTLE_FOREIGN = 600,
         EOD_SUSPENSE_ONUS = 700,
         EOD_SUSPENSE_FOREIGN = 800,
         DEPOSIT_SWEEP = 900
      };
      enum ActivityType
      {
         WITHDRAWAL = 1,
         DEVICE = 10,
         CANISTER1,
         CANISTER2,
         CANISTER3,
         CANISTER4,
         CANISTER5,
         CANISTER6,
         CANISTER7,
         CANISTER8,
         ENVELOPE = 20,
         CASH = 30,
         CASH_DENOMINATION1,
         CASH_DENOMINATION2,
         CASH_DENOMINATION3,
         CASH_DENOMINATION4,
         CASH_DENOMINATION5,
         CASH_DENOMINATION6,
         CASH_DENOMINATION7,
         CASH_DENOMINATION8,
         CASH_DENOMINATION9,
         CASH_DENOMINATION10,
         CASH_DENOMINATION11,
         CASH_DENOMINATION12,
         CASH_DENOMINATION13,
         CASH_DENOMINATION14,
         CASH_DENOMINATION15,
         CASH_DENOMINATION16,
         CASH_DENOMINATION17,
         CASH_DENOMINATION18,
         CASH_DENOMINATION19,
         CASH_DENOMINATION20,
         CHECK = 60,
         CHECK_ONUS_ORIGINAL,
         CHECK_ONUS_ADJUSTMENT,
         CHECK_TRANSIT_ORIGINAL,
         CHECK_TRANSIT_ADJUSTMENT,
         TRANSFER = 70,
         PAYMENT_TO,
         PAYMENT_FROM,
         INQUIRY,
         OTHER,
         TELLER_WITHDRAWAL = 80,
         TELLER_CANISTER1,
         TELLER_CANISTER2,
         TELLER_CANISTER3,
         TELLER_CANISTER4,
         TELLER_CANISTER5,
         TELLER_CANISTER6,
         TELLER_CANISTER7,
         TELLER_CANISTER8,
         TELLER_DEPOSIT = 90
      };
  //## end atm::ATMActivity%5C49D1A50341.initialDeclarations

  public:
    //## Constructors (generated)
      ATMActivity();

      ATMActivity(const ATMActivity &right);

    //## Destructor (generated)
      virtual ~ATMActivity();

    //## Assignment Operation (generated)
      ATMActivity & operator=(const ATMActivity &right);


    //## Other Operations (specified)
      //## Operation: accept%5C49ED1A0074
      void accept (atm::ATMBusinessDayVisitor& hATMBusinessDayVisitor);

      //## Operation: fields%5C4B87B000D1
      virtual struct  Fields* fields () const;

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ACTIVITY_GROUP%5C4B36B303BF
      const enum ActivityGroup getACTIVITY_GROUP () const
      {
        //## begin atm::ATMActivity::getACTIVITY_GROUP%5C4B36B303BF.get preserve=no
        return m_nACTIVITY_GROUP;
        //## end atm::ATMActivity::getACTIVITY_GROUP%5C4B36B303BF.get
      }

      void setACTIVITY_GROUP (enum ActivityGroup value)
      {
        //## begin atm::ATMActivity::setACTIVITY_GROUP%5C4B36B303BF.set preserve=no
        m_nACTIVITY_GROUP = value;
        //## end atm::ATMActivity::setACTIVITY_GROUP%5C4B36B303BF.set
      }


      //## Attribute: ACTIVITY_TYPE%5C49F2EE0136
      const enum ActivityType getACTIVITY_TYPE () const
      {
        //## begin atm::ATMActivity::getACTIVITY_TYPE%5C49F2EE0136.get preserve=no
        return m_nACTIVITY_TYPE;
        //## end atm::ATMActivity::getACTIVITY_TYPE%5C49F2EE0136.get
      }

      void setACTIVITY_TYPE (enum ActivityType value)
      {
        //## begin atm::ATMActivity::setACTIVITY_TYPE%5C49F2EE0136.set preserve=no
        m_nACTIVITY_TYPE = value;
        //## end atm::ATMActivity::setACTIVITY_TYPE%5C49F2EE0136.set
      }


      //## Attribute: AMT_RECON_NET%5C49D36501DE
      const double& getAMT_RECON_NET () const
      {
        //## begin atm::ATMActivity::getAMT_RECON_NET%5C49D36501DE.get preserve=no
        return m_dAMT_RECON_NET;
        //## end atm::ATMActivity::getAMT_RECON_NET%5C49D36501DE.get
      }

      void setAMT_RECON_NET (const double& value)
      {
        //## begin atm::ATMActivity::setAMT_RECON_NET%5C49D36501DE.set preserve=no
        m_dAMT_RECON_NET = value;
        //## end atm::ATMActivity::setAMT_RECON_NET%5C49D36501DE.set
      }


      //## Attribute: AMT_SURCHARGE%5C631C47001F
      const double& getAMT_SURCHARGE () const
      {
        //## begin atm::ATMActivity::getAMT_SURCHARGE%5C631C47001F.get preserve=no
        return m_dAMT_SURCHARGE;
        //## end atm::ATMActivity::getAMT_SURCHARGE%5C631C47001F.get
      }

      void setAMT_SURCHARGE (const double& value)
      {
        //## begin atm::ATMActivity::setAMT_SURCHARGE%5C631C47001F.set preserve=no
        m_dAMT_SURCHARGE = value;
        //## end atm::ATMActivity::setAMT_SURCHARGE%5C631C47001F.set
      }


      //## Attribute: CUR_RECON_NET%5C49D3350005
      const reusable::string& getCUR_RECON_NET () const
      {
        //## begin atm::ATMActivity::getCUR_RECON_NET%5C49D3350005.get preserve=no
        return m_strCUR_RECON_NET;
        //## end atm::ATMActivity::getCUR_RECON_NET%5C49D3350005.get
      }

      void setCUR_RECON_NET (const reusable::string& value)
      {
        //## begin atm::ATMActivity::setCUR_RECON_NET%5C49D3350005.set preserve=no
        m_strCUR_RECON_NET = value;
        //## end atm::ATMActivity::setCUR_RECON_NET%5C49D3350005.set
      }


      //## Attribute: CUR_TYPE%5C49D38E01DA
      const short& getCUR_TYPE () const
      {
        //## begin atm::ATMActivity::getCUR_TYPE%5C49D38E01DA.get preserve=no
        return m_siCUR_TYPE;
        //## end atm::ATMActivity::getCUR_TYPE%5C49D38E01DA.get
      }

      void setCUR_TYPE (const short& value)
      {
        //## begin atm::ATMActivity::setCUR_TYPE%5C49D38E01DA.set preserve=no
        m_siCUR_TYPE = value;
        //## end atm::ATMActivity::setCUR_TYPE%5C49D38E01DA.set
      }


      //## Attribute: IMPACT_TO_ACQ%5C5DDAB1033F
      const reusable::string& getIMPACT_TO_ACQ () const
      {
        //## begin atm::ATMActivity::getIMPACT_TO_ACQ%5C5DDAB1033F.get preserve=no
        return m_strIMPACT_TO_ACQ;
        //## end atm::ATMActivity::getIMPACT_TO_ACQ%5C5DDAB1033F.get
      }

      void setIMPACT_TO_ACQ (const reusable::string& value)
      {
        //## begin atm::ATMActivity::setIMPACT_TO_ACQ%5C5DDAB1033F.set preserve=no
        m_strIMPACT_TO_ACQ = value;
        //## end atm::ATMActivity::setIMPACT_TO_ACQ%5C5DDAB1033F.set
      }


      //## Attribute: ITEM_COUNT%5C4B88DB0060
      const int& getITEM_COUNT () const
      {
        //## begin atm::ATMActivity::getITEM_COUNT%5C4B88DB0060.get preserve=no
        return m_iITEM_COUNT;
        //## end atm::ATMActivity::getITEM_COUNT%5C4B88DB0060.get
      }

      void setITEM_COUNT (const int& value)
      {
        //## begin atm::ATMActivity::setITEM_COUNT%5C4B88DB0060.set preserve=no
        m_iITEM_COUNT = value;
        //## end atm::ATMActivity::setITEM_COUNT%5C4B88DB0060.set
      }


      //## Attribute: ITEM_VALUE%5C49D3C303C7
      const int& getITEM_VALUE () const
      {
        //## begin atm::ATMActivity::getITEM_VALUE%5C49D3C303C7.get preserve=no
        return m_iITEM_VALUE;
        //## end atm::ATMActivity::getITEM_VALUE%5C49D3C303C7.get
      }

      void setITEM_VALUE (const int& value)
      {
        //## begin atm::ATMActivity::setITEM_VALUE%5C49D3C303C7.set preserve=no
        m_iITEM_VALUE = value;
        //## end atm::ATMActivity::setITEM_VALUE%5C49D3C303C7.set
      }


      //## Attribute: TRAN_COUNT%5C49D38B02A3
      const int& getTRAN_COUNT () const
      {
        //## begin atm::ATMActivity::getTRAN_COUNT%5C49D38B02A3.get preserve=no
        return m_iTRAN_COUNT;
        //## end atm::ATMActivity::getTRAN_COUNT%5C49D38B02A3.get
      }

      void setTRAN_COUNT (const int& value)
      {
        //## begin atm::ATMActivity::setTRAN_COUNT%5C49D38B02A3.set preserve=no
        m_iTRAN_COUNT = value;
        //## end atm::ATMActivity::setTRAN_COUNT%5C49D38B02A3.set
      }


      //## Attribute: TRAN_DISPOSITION%5C4B118F018D
      const reusable::string& getTRAN_DISPOSITION () const
      {
        //## begin atm::ATMActivity::getTRAN_DISPOSITION%5C4B118F018D.get preserve=no
        return m_strTRAN_DISPOSITION;
        //## end atm::ATMActivity::getTRAN_DISPOSITION%5C4B118F018D.get
      }

      void setTRAN_DISPOSITION (const reusable::string& value)
      {
        //## begin atm::ATMActivity::setTRAN_DISPOSITION%5C4B118F018D.set preserve=no
        m_strTRAN_DISPOSITION = value;
        //## end atm::ATMActivity::setTRAN_DISPOSITION%5C4B118F018D.set
      }


    // Additional Public Declarations
      //## begin atm::ATMActivity%5C49D1A50341.public preserve=yes
      //## end atm::ATMActivity%5C49D1A50341.public

  protected:
    // Additional Protected Declarations
      //## begin atm::ATMActivity%5C49D1A50341.protected preserve=yes
      //## end atm::ATMActivity%5C49D1A50341.protected

  private:
    // Additional Private Declarations
      //## begin atm::ATMActivity%5C49D1A50341.private preserve=yes
      //## end atm::ATMActivity%5C49D1A50341.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin atm::ATMActivity::ACTIVITY_GROUP%5C4B36B303BF.attr preserve=no  public: enum ActivityGroup {V}
      enum ActivityGroup m_nACTIVITY_GROUP;
      //## end atm::ATMActivity::ACTIVITY_GROUP%5C4B36B303BF.attr

      //## begin atm::ATMActivity::ACTIVITY_TYPE%5C49F2EE0136.attr preserve=no  public: enum ActivityType {V} ActivityType::WITHDRAWAL
      enum ActivityType m_nACTIVITY_TYPE;
      //## end atm::ATMActivity::ACTIVITY_TYPE%5C49F2EE0136.attr

      //## begin atm::ATMActivity::AMT_RECON_NET%5C49D36501DE.attr preserve=no  public: double {V} 0
      double m_dAMT_RECON_NET;
      //## end atm::ATMActivity::AMT_RECON_NET%5C49D36501DE.attr

      //## begin atm::ATMActivity::AMT_SURCHARGE%5C631C47001F.attr preserve=no  public: double {V} 0
      double m_dAMT_SURCHARGE;
      //## end atm::ATMActivity::AMT_SURCHARGE%5C631C47001F.attr

      //## begin atm::ATMActivity::CUR_RECON_NET%5C49D3350005.attr preserve=no  public: reusable::string {V}
      reusable::string m_strCUR_RECON_NET;
      //## end atm::ATMActivity::CUR_RECON_NET%5C49D3350005.attr

      //## begin atm::ATMActivity::CUR_TYPE%5C49D38E01DA.attr preserve=no  public: short {V} 0
      short m_siCUR_TYPE;
      //## end atm::ATMActivity::CUR_TYPE%5C49D38E01DA.attr

      //## begin atm::ATMActivity::IMPACT_TO_ACQ%5C5DDAB1033F.attr preserve=no  public: reusable::string {V}
      reusable::string m_strIMPACT_TO_ACQ;
      //## end atm::ATMActivity::IMPACT_TO_ACQ%5C5DDAB1033F.attr

      //## begin atm::ATMActivity::ITEM_COUNT%5C4B88DB0060.attr preserve=no  public: int {V} 0
      int m_iITEM_COUNT;
      //## end atm::ATMActivity::ITEM_COUNT%5C4B88DB0060.attr

      //## begin atm::ATMActivity::ITEM_VALUE%5C49D3C303C7.attr preserve=no  public: int {V} 0
      int m_iITEM_VALUE;
      //## end atm::ATMActivity::ITEM_VALUE%5C49D3C303C7.attr

      //## begin atm::ATMActivity::TRAN_COUNT%5C49D38B02A3.attr preserve=no  public: int {V} 0
      int m_iTRAN_COUNT;
      //## end atm::ATMActivity::TRAN_COUNT%5C49D38B02A3.attr

      //## begin atm::ATMActivity::TRAN_DISPOSITION%5C4B118F018D.attr preserve=no  public: reusable::string {V}
      reusable::string m_strTRAN_DISPOSITION;
      //## end atm::ATMActivity::TRAN_DISPOSITION%5C4B118F018D.attr

    // Additional Implementation Declarations
      //## begin atm::ATMActivity%5C49D1A50341.implementation preserve=yes
      //## end atm::ATMActivity%5C49D1A50341.implementation

};

//## begin atm::ATMActivity%5C49D1A50341.postscript preserve=yes
//## end atm::ATMActivity%5C49D1A50341.postscript

} // namespace atm

//## begin module%5C49D1C90069.epilog preserve=yes
//## end module%5C49D1C90069.epilog


#endif
