//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C50A1B201F5.cm preserve=no
//	$Date:   Feb 26 2019 16:05:04  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5C50A1B201F5.cm

//## begin module%5C50A1B201F5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C50A1B201F5.cp

//## Module: CXOSAT05%5C50A1B201F5; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Library\Atdll\CXOSAT05.cpp

//## begin module%5C50A1B201F5.additionalIncludes preserve=no
//## end module%5C50A1B201F5.additionalIncludes

//## begin module%5C50A1B201F5.includes preserve=yes
//## end module%5C50A1B201F5.includes

#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOSAT06_h
#include "CXODAT06.hpp"
#endif
#ifndef CXOSAT05_h
#include "CXODAT05.hpp"
#endif


//## begin module%5C50A1B201F5.declarations preserve=no
//## end module%5C50A1B201F5.declarations

//## begin module%5C50A1B201F5.additionalDeclarations preserve=yes
//## end module%5C50A1B201F5.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::ATMTotal 

ATMTotal::ATMTotal()
  //## begin ATMTotal::ATMTotal%5C508A1D018B_const.hasinit preserve=no
      : m_pATMMediator(0)
  //## end ATMTotal::ATMTotal%5C508A1D018B_const.hasinit
  //## begin ATMTotal::ATMTotal%5C508A1D018B_const.initialization preserve=yes
  //## end ATMTotal::ATMTotal%5C508A1D018B_const.initialization
{
  //## begin atm::ATMTotal::ATMTotal%5C508A1D018B_const.body preserve=yes
   memcpy(m_sID,"ST74",4);
  //## end atm::ATMTotal::ATMTotal%5C508A1D018B_const.body
}


ATMTotal::~ATMTotal()
{
  //## begin atm::ATMTotal::~ATMTotal%5C508A1D018B_dest.body preserve=yes
  //## end atm::ATMTotal::~ATMTotal%5C508A1D018B_dest.body
}



//## Other Operations (implementation)
bool ATMTotal::initialize ()
{
  //## begin atm::ATMTotal::initialize%5C50AB5A03B3.body preserve=yes
   m_pATMMediator = new ATMMediator;
   return Thread::initialize();
  //## end atm::ATMTotal::initialize%5C50AB5A03B3.body
}

bool ATMTotal::run (bool bSleep)
{
  //## begin atm::ATMTotal::run%5C508A4401B9.body preserve=yes
   if (!m_pATMMediator->total())
      Sleep::goTo("00010000");
   return Thread::run();
  //## end atm::ATMTotal::run%5C508A4401B9.body
}

// Additional Declarations
  //## begin atm::ATMTotal%5C508A1D018B.declarations preserve=yes
  //## end atm::ATMTotal%5C508A1D018B.declarations

} // namespace atm

//## begin module%5C50A1B201F5.epilog preserve=yes
//## end module%5C50A1B201F5.epilog
