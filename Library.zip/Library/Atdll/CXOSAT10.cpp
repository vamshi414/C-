//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5DCC5B270098.cm preserve=no
//	$Date:   Nov 14 2019 08:23:56  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5DCC5B270098.cm

//## begin module%5DCC5B270098.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5DCC5B270098.cp

//## Module: CXOSAT10%5DCC5B270098; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Atdll\CXOSAT10.cpp

//## begin module%5DCC5B270098.additionalIncludes preserve=no
//## end module%5DCC5B270098.additionalIncludes

//## begin module%5DCC5B270098.includes preserve=yes
//## end module%5DCC5B270098.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSTM15_h
#include "CXODTM15.hpp"
#endif
#ifndef CXOSDB43_h
#include "CXODDB43.hpp"
#endif
#ifndef CXOSAT10_h
#include "CXODAT10.hpp"
#endif


//## begin module%5DCC5B270098.declarations preserve=no
//## end module%5DCC5B270098.declarations

//## begin module%5DCC5B270098.additionalDeclarations preserve=yes
//## end module%5DCC5B270098.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::Hierarchy 

//## begin atm::Hierarchy::Instance%5DCD56A600FA.attr preserve=no  private: static atm::Hierarchy* {V} 0
atm::Hierarchy* Hierarchy::m_pInstance = 0;
//## end atm::Hierarchy::Instance%5DCD56A600FA.attr

Hierarchy::Hierarchy()
  //## begin Hierarchy::Hierarchy%5DCC32BB03CC_const.hasinit preserve=no
  //## end Hierarchy::Hierarchy%5DCC32BB03CC_const.hasinit
  //## begin Hierarchy::Hierarchy%5DCC32BB03CC_const.initialization preserve=yes
  //## end Hierarchy::Hierarchy%5DCC32BB03CC_const.initialization
{
  //## begin atm::Hierarchy::Hierarchy%5DCC32BB03CC_const.body preserve=yes
   memcpy(m_sID,"AT10",4);
   timer::WitchingHour::instance()->attach(this);
  //## end atm::Hierarchy::Hierarchy%5DCC32BB03CC_const.body
}


Hierarchy::~Hierarchy()
{
  //## begin atm::Hierarchy::~Hierarchy%5DCC32BB03CC_dest.body preserve=yes
   timer::WitchingHour::instance()->detach(this);
  //## end atm::Hierarchy::~Hierarchy%5DCC32BB03CC_dest.body
}



//## Other Operations (implementation)
atm::Hierarchy* Hierarchy::instance ()
{
  //## begin atm::Hierarchy::instance%5DCD568902F4.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new Hierarchy();
   return m_pInstance;
  //## end atm::Hierarchy::instance%5DCD568902F4.body
}

bool Hierarchy::isPseudoTerminal (const reusable::string& strDEVICE_ID)
{
  //## begin atm::Hierarchy::isPseudoTerminal%5DCC5CC200EB.body preserve=yes
   return m_hPseudoTerminal.find(strDEVICE_ID) != m_hPseudoTerminal.end();
  //## end atm::Hierarchy::isPseudoTerminal%5DCC5CC200EB.body
}

bool Hierarchy::load ()
{
  //## begin atm::Hierarchy::load%5DCC391801F0.body preserve=yes
   m_hPseudoTerminal.erase(m_hPseudoTerminal.begin(),m_hPseudoTerminal.end());
   Query hQuery;
   hQuery.attach(this);
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.setQualifier("QUALIFY","DEVICE");
   hQuery.bind("DEVICE","DEVICE_ID",Column::STRING,&m_strDEVICE_ID);
   hQuery.setBasicPredicate("DEVICE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("DEVICE","CC_STATE","=","A");
   string strTemp = "('" + strCUST_ID + "','****')";
   hQuery.setBasicPredicate("DEVICE","CUST_ID","IN",strTemp.c_str());
   hQuery.setBasicPredicate("DEVICE","PSEUDO_TERM_FLG","=","Y");
   hQuery.setOrderByClause("DEVICE_ID");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   return pSelectStatement->execute(hQuery);
  //## end atm::Hierarchy::load%5DCC391801F0.body
}

void Hierarchy::update (Subject* pSubject)
{
  //## begin atm::Hierarchy::update%5DCC391A0105.body preserve=yes
   if (pSubject == timer::WitchingHour::instance())
   {
      database::Cache::reload(this);
      return;
   }
   m_hPseudoTerminal.insert(m_strDEVICE_ID);
  //## end atm::Hierarchy::update%5DCC391A0105.body
}

// Additional Declarations
  //## begin atm::Hierarchy%5DCC32BB03CC.declarations preserve=yes
  //## end atm::Hierarchy%5DCC32BB03CC.declarations

} // namespace atm

//## begin module%5DCC5B270098.epilog preserve=yes
//## end module%5DCC5B270098.epilog
