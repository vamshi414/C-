//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%609D917C01EB.cm preserve=no
//	$Date:   May 25 2021 14:45:10  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%609D917C01EB.cm

//## begin module%609D917C01EB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%609D917C01EB.cp

//## Module: CXOSAT14%609D917C01EB; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Atdll\CXODAT14.hpp

#ifndef CXOSAT14_h
#define CXOSAT14_h 1

//## begin module%609D917C01EB.additionalIncludes preserve=no
//## end module%609D917C01EB.additionalIncludes

//## begin module%609D917C01EB.includes preserve=yes
//## end module%609D917C01EB.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
class ATMEvent;
} // namespace atm

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%609D917C01EB.declarations preserve=no
//## end module%609D917C01EB.declarations

//## begin module%609D917C01EB.additionalDeclarations preserve=yes
//## end module%609D917C01EB.additionalDeclarations


namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::Reconciliation%609D911701D4.preface preserve=yes
//## end atm::Reconciliation%609D911701D4.preface

//## Class: Reconciliation%609D911701D4
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%609D921E0355;ATMEvent { -> F}
//## Uses: <unnamed>%60ACF45802AF;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%60ACF45B02A0;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%60ACF45E0377;reusable::Query { -> F}
//## Uses: <unnamed>%60AD01AF01D3;IF::Extract { -> F}
//## Uses: <unnamed>%60AD01B202DB;IF::Trace { -> F}
//## Uses: <unnamed>%60AD02FB0207;monitor::UseCase { -> F}

class DllExport Reconciliation : public reusable::Observer  //## Inherits: <unnamed>%609D914D005D
{
  //## begin atm::Reconciliation%609D911701D4.initialDeclarations preserve=yes
  //## end atm::Reconciliation%609D911701D4.initialDeclarations

  public:
    //## Constructors (generated)
      Reconciliation();

    //## Destructor (generated)
      virtual ~Reconciliation();


    //## Other Operations (specified)
      //## Operation: check%609D91EB032E
      bool check (atm::ATMEvent& hATMEvent);

      //## Operation: instance%60ACF3F203CF
      static Reconciliation* instance ();

      //## Operation: update%609D9151030C
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin atm::Reconciliation%609D911701D4.public preserve=yes
      //## end atm::Reconciliation%609D911701D4.public

  protected:
    // Additional Protected Declarations
      //## begin atm::Reconciliation%609D911701D4.protected preserve=yes
      //## end atm::Reconciliation%609D911701D4.protected

  private:
    // Additional Private Declarations
      //## begin atm::Reconciliation%609D911701D4.private preserve=yes
      //## end atm::Reconciliation%609D911701D4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Disable%60AD01B703E4
      //## begin atm::Reconciliation::Disable%60AD01B703E4.attr preserve=no  private: bool {V} false
      bool m_bDisable;
      //## end atm::Reconciliation::Disable%60AD01B703E4.attr

      //## Attribute: Instance%60ACF3D9003D
      //## begin atm::Reconciliation::Instance%60ACF3D9003D.attr preserve=no  private: static Reconciliation* {V} 0
      static Reconciliation* m_pInstance;
      //## end atm::Reconciliation::Instance%60ACF3D9003D.attr

      //## Attribute: LINE_AMOUNT%60ACF4BB0142
      //## begin atm::Reconciliation::LINE_AMOUNT%60ACF4BB0142.attr preserve=no  private: double[9] {V} 
      double m_dLINE_AMOUNT[9];
      //## end atm::Reconciliation::LINE_AMOUNT%60ACF4BB0142.attr

      //## Attribute: LINE_DESCRIPTION%60ACFE7902CF
      //## begin atm::Reconciliation::LINE_DESCRIPTION%60ACFE7902CF.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strLINE_DESCRIPTION;
      //## end atm::Reconciliation::LINE_DESCRIPTION%60ACFE7902CF.attr

    // Additional Implementation Declarations
      //## begin atm::Reconciliation%609D911701D4.implementation preserve=yes
      //## end atm::Reconciliation%609D911701D4.implementation

};

//## begin atm::Reconciliation%609D911701D4.postscript preserve=yes
//## end atm::Reconciliation%609D911701D4.postscript

} // namespace atm

//## begin module%609D917C01EB.epilog preserve=yes
//## end module%609D917C01EB.epilog


#endif
