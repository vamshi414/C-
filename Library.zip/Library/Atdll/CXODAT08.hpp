//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C65686E0110.cm preserve=no
//	$Date:   Jan 09 2020 13:04:00  $ $Author:   e1009839  $
//	$Revision:   1.3  $
//## end module%5C65686E0110.cm

//## begin module%5C65686E0110.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C65686E0110.cp

//## Module: CXOSAT08%5C65686E0110; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Atdll\CXODAT08.hpp

#ifndef CXOSAT08_h
#define CXOSAT08_h 1

//## begin module%5C65686E0110.additionalIncludes preserve=no
//## end module%5C65686E0110.additionalIncludes

//## begin module%5C65686E0110.includes preserve=yes
//## end module%5C65686E0110.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
class ATMEvent;
} // namespace atm

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
class Query;
class Table;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;

} // namespace timer

//## begin module%5C65686E0110.declarations preserve=no
//## end module%5C65686E0110.declarations

//## begin module%5C65686E0110.additionalDeclarations preserve=yes
//## end module%5C65686E0110.additionalDeclarations


namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::ATMInstitution%5C65681E026B.preface preserve=yes
//## end atm::ATMInstitution%5C65681E026B.preface

//## Class: ATMInstitution%5C65681E026B
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5C656BA400CF;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5C656BA501A0;reusable::Statement { -> F}
//## Uses: <unnamed>%5C656BA602B8;reusable::Table { -> F}
//## Uses: <unnamed>%5C656BA80078;ATMEvent { -> F}
//## Uses: <unnamed>%5C656BEF01CF;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%5C6578E0021A;reusable::Query { -> F}
//## Uses: <unnamed>%5C6578E3038A;IF::Extract { -> F}
//## Uses: <unnamed>%5C6578E70134;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5DBB362C0261;timer::Date { -> F}

class DllExport ATMInstitution : public reusable::Object  //## Inherits: <unnamed>%5C6568410244
{
  //## begin atm::ATMInstitution%5C65681E026B.initialDeclarations preserve=yes
  //## end atm::ATMInstitution%5C65681E026B.initialDeclarations

  public:
    //## Constructors (generated)
      ATMInstitution();

    //## Destructor (generated)
      virtual ~ATMInstitution();


    //## Other Operations (specified)
      //## Operation: addEndOfDay%5C6568D30379
      bool addEndOfDay (atm::ATMEvent& hATMEvent, int iRows = -1);

      //## Operation: instance%5C656919023A
      static ATMInstitution* instance ();

    // Additional Public Declarations
      //## begin atm::ATMInstitution%5C65681E026B.public preserve=yes
      //## end atm::ATMInstitution%5C65681E026B.public

  protected:
    // Additional Protected Declarations
      //## begin atm::ATMInstitution%5C65681E026B.protected preserve=yes
      //## end atm::ATMInstitution%5C65681E026B.protected

  private:
    // Additional Private Declarations
      //## begin atm::ATMInstitution%5C65681E026B.private preserve=yes
      //## end atm::ATMInstitution%5C65681E026B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5C6569010004
      //## begin atm::ATMInstitution::Instance%5C6569010004.attr preserve=no  private: static ATMInstitution* {V} 0
      static ATMInstitution* m_pInstance;
      //## end atm::ATMInstitution::Instance%5C6569010004.attr

    // Additional Implementation Declarations
      //## begin atm::ATMInstitution%5C65681E026B.implementation preserve=yes
      //## end atm::ATMInstitution%5C65681E026B.implementation

};

//## begin atm::ATMInstitution%5C65681E026B.postscript preserve=yes
//## end atm::ATMInstitution%5C65681E026B.postscript

} // namespace atm

//## begin module%5C65686E0110.epilog preserve=yes
//## end module%5C65686E0110.epilog


#endif
