//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%609D918000CC.cm preserve=no
//	$Date:   Jun 22 2021 14:57:04  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%609D918000CC.cm

//## begin module%609D918000CC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%609D918000CC.cp

//## Module: CXOSAT14%609D918000CC; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Atdll\CXOSAT14.cpp

//## begin module%609D918000CC.additionalIncludes preserve=no
//## end module%609D918000CC.additionalIncludes

//## begin module%609D918000CC.includes preserve=yes
#include <sstream>
//## end module%609D918000CC.includes

#ifndef CXOSAT02_h
#include "CXODAT02.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSAT14_h
#include "CXODAT14.hpp"
#endif


//## begin module%609D918000CC.declarations preserve=no
//## end module%609D918000CC.declarations

//## begin module%609D918000CC.additionalDeclarations preserve=yes
//## end module%609D918000CC.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::Reconciliation

//## begin atm::Reconciliation::Instance%60ACF3D9003D.attr preserve=no  private: static atm::Reconciliation* {V} 0
atm::Reconciliation* Reconciliation::m_pInstance = 0;
//## end atm::Reconciliation::Instance%60ACF3D9003D.attr

Reconciliation::Reconciliation()
  //## begin Reconciliation::Reconciliation%609D911701D4_const.hasinit preserve=no
      : m_bDisable(false)
  //## end Reconciliation::Reconciliation%609D911701D4_const.hasinit
  //## begin Reconciliation::Reconciliation%609D911701D4_const.initialization preserve=yes
  //## end Reconciliation::Reconciliation%609D911701D4_const.initialization
{
  //## begin atm::Reconciliation::Reconciliation%609D911701D4_const.body preserve=yes
   memcpy(m_sID,"AT14",4);
   for (int i = 0;i < 9;++i)
      m_dLINE_AMOUNT[i] = -1;
   string strRecord;
   m_bDisable = IF::Extract::instance()->getRecord("DSPEC   AT14    DISABLE",strRecord);
  //## end atm::Reconciliation::Reconciliation%609D911701D4_const.body
}


Reconciliation::~Reconciliation()
{
  //## begin atm::Reconciliation::~Reconciliation%609D911701D4_dest.body preserve=yes
  //## end atm::Reconciliation::~Reconciliation%609D911701D4_dest.body
}



//## Other Operations (implementation)
bool Reconciliation::check (atm::ATMEvent& hATMEvent)
{
  //## begin atm::Reconciliation::check%609D91EB032E.body preserve=yes
   if (m_bDisable)
      return true;
   UseCase hUseCase("TOTALS","## AT14 C1 END RECON");
   for (int i = 0;i < 9;++i)
      m_dLINE_AMOUNT[i] = -1;
   string strATM_RECEIPT("ATM_RECEIPTyyyymm");
   strATM_RECEIPT.replace(11,6,hATMEvent.getTSTAMP_TRANS().data(),6);
   string strATM_ENTRY("ATM_ENTRYyyyymm");
   strATM_ENTRY.replace(9,6,hATMEvent.getTSTAMP_TRANS().data(),6);
   Query hQuery;
   hQuery.attach(this);
   hQuery.join(strATM_RECEIPT.c_str(),"INNER",strATM_ENTRY.c_str(),"NET_TERM_ID");
   hQuery.join(strATM_RECEIPT.c_str(),"INNER",strATM_ENTRY.c_str(),"TSTAMP_LOCAL");
   hQuery.join(strATM_RECEIPT.c_str(),"INNER",strATM_ENTRY.c_str(),"FUNC_CODE");
   hQuery.bind(strATM_ENTRY.c_str(),"LINE_DESCRIPTION",Column::STRING,&m_strLINE_DESCRIPTION);
   hQuery.bind(strATM_ENTRY.c_str(),"LINE_AMOUNT",Column::DOUBLE,&m_dLINE_AMOUNT[8]);
   hQuery.setBasicPredicate(strATM_RECEIPT.c_str(),"NET_TERM_ID","=",hATMEvent.getNET_TERM_ID().c_str());
   hQuery.setBasicPredicate(strATM_RECEIPT.c_str(),"TSTAMP_TRANS","=",hATMEvent.getTSTAMP_TRANS().c_str());
   hQuery.setBasicPredicate(strATM_RECEIPT.c_str(),"FUNC_CODE","=","572");
   hQuery.getSearchCondition().append(" AND (");
   hQuery.setBasicPredicate(strATM_ENTRY.c_str(),"LINE_DESCRIPTION","LIKE","C_ END%");
   hQuery.setBasicPredicate(strATM_ENTRY.c_str(),"LINE_DESCRIPTION","LIKE","COH%",false,false);
   hQuery.getSearchCondition().append(")");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return UseCase::setSuccess(false);
   for (int i = 0;i < 8;++i)
      if (m_dLINE_AMOUNT[i] != -1
         && hATMEvent.getCASSETTEn_END(i) != m_dLINE_AMOUNT[i])
      {
         std::ostringstream oss;
         oss << hATMEvent.getNET_TERM_ID() << " change cassette " << i + 1 << " from " << std::fixed << hATMEvent.getCASSETTEn_END(i) << " to " << m_dLINE_AMOUNT[i];
         Trace::put(oss.str().data(),oss.str().length(),true);
         hATMEvent.setCASSETTES_END(hATMEvent.getCASSETTES_END() + (m_dLINE_AMOUNT[i] - hATMEvent.getCASSETTEn_END(i)));
         hATMEvent.setCASSETTEn_END(i,m_dLINE_AMOUNT[i]);
         if (m_dLINE_AMOUNT[i] == 0)
            hATMEvent.setCASSETTEn_VALUE(i,0);
         UseCase::addItem();
      }
   return true;
  //## end atm::Reconciliation::check%609D91EB032E.body
}

Reconciliation* Reconciliation::instance ()
{
  //## begin atm::Reconciliation::instance%60ACF3F203CF.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new Reconciliation();
   return m_pInstance;
  //## end atm::Reconciliation::instance%60ACF3F203CF.body
}

void Reconciliation::update (Subject* pSubject)
{
  //## begin atm::Reconciliation::update%609D9151030C.body preserve=yes
   int i = m_strLINE_DESCRIPTION[1] == 'O' ? 3 : 1;
   m_dLINE_AMOUNT[m_strLINE_DESCRIPTION[i] - '1'] = m_dLINE_AMOUNT[8];
  //## end atm::Reconciliation::update%609D9151030C.body
}

// Additional Declarations
  //## begin atm::Reconciliation%609D911701D4.declarations preserve=yes
  //## end atm::Reconciliation%609D911701D4.declarations

} // namespace atm

//## begin module%609D918000CC.epilog preserve=yes
//## end module%609D918000CC.epilog
