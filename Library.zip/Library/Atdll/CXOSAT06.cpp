//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C50A39601B8.cm preserve=no
//	$Date:   Oct 21 2021 09:53:22  $ $Author:   e1009839  $
//	$Revision:   1.42  $
//## end module%5C50A39601B8.cm

//## begin module%5C50A39601B8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C50A39601B8.cp

//## Module: CXOSAT06%5C50A39601B8; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Atdll\CXOSAT06.cpp

//## begin module%5C50A39601B8.additionalIncludes preserve=no
//## end module%5C50A39601B8.additionalIncludes

//## begin module%5C50A39601B8.includes preserve=yes
#include <sstream>
#include "CXODIF28.hpp"
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSDB30_h
#include "CXODDB30.hpp"
#endif
//## end module%5C50A39601B8.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB08_h
#include "CXODDB08.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU28_h
#include "CXODRU28.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSAT02_h
#include "CXODAT02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSAT08_h
#include "CXODAT08.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSAT12_h
#include "CXODAT12.hpp"
#endif
#ifndef CXOSAT13_h
#include "CXODAT13.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSAT14_h
#include "CXODAT14.hpp"
#endif
#ifndef CXOSAT06_h
#include "CXODAT06.hpp"
#endif


//## begin module%5C50A39601B8.declarations preserve=no
//## end module%5C50A39601B8.declarations

//## begin module%5C50A39601B8.additionalDeclarations preserve=yes
//## end module%5C50A39601B8.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::ATMMediator

ATMMediator::ATMMediator()
  //## begin ATMMediator::ATMMediator%5C50A3130199_const.hasinit preserve=no
      : m_iDays(0),
        m_bPrimary(false),
        m_iRows(-1)
  //## end ATMMediator::ATMMediator%5C50A3130199_const.hasinit
  //## begin ATMMediator::ATMMediator%5C50A3130199_const.initialization preserve=yes
  //## end ATMMediator::ATMMediator%5C50A3130199_const.initialization
{
  //## begin atm::ATMMediator::ATMMediator%5C50A3130199_const.body preserve=yes
   memcpy(m_sID,"AT06",4);
   m_hQuery[0].attach(this);
   m_hQuery[1].attach(this);
  //## end atm::ATMMediator::ATMMediator%5C50A3130199_const.body
}


ATMMediator::~ATMMediator()
{
  //## begin atm::ATMMediator::~ATMMediator%5C50A3130199_dest.body preserve=yes
  //## end atm::ATMMediator::~ATMMediator%5C50A3130199_dest.body
}



//## Other Operations (implementation)
void ATMMediator::age ()
{
  //## begin atm::ATMMediator::age%5D6698430026.body preserve=yes
   Query hQuery;
   string strDATE_RECON_ACQ;
   short iNull = -1;
   hQuery.bind("T_ATM_EVENT","DATE_RECON_ACQ",Column::STRING,&strDATE_RECON_ACQ,&iNull,"MIN");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == false
      || iNull == -1)
      return;
   Date hDate(entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(0).c_str());
   if (m_iDays == 0)
   {
      string strRecord;
      if (Extract::instance()->getRecord("DSPEC   AT06    AGE~",strRecord))
         m_iDays = atoi(strRecord.substr(20).c_str());
      if (m_iDays < 30)
         m_iDays = 30;
   }
   hDate -= m_iDays;
   string strDate(hDate.asString("%Y%m%d"));
   if (strDate > strDATE_RECON_ACQ)
   {
      auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
      hQuery.reset();
      hQuery.setQualifier("CUSTQUAL","T_ATM_ACTIVITY");
      hQuery.setBasicPredicate("T_ATM_ACTIVITY","DATE_RECON_ACQ","=",strDATE_RECON_ACQ.c_str());
      pDeleteStatement->execute(hQuery);
      hQuery.reset();
      hQuery.setQualifier("CUSTQUAL","T_ATM_EVENT");
      hQuery.setBasicPredicate("T_ATM_EVENT","DATE_RECON_ACQ","=",strDATE_RECON_ACQ.c_str());
      pDeleteStatement->execute(hQuery);
   }
   Database::instance()->commit();
  //## end atm::ATMMediator::age%5D6698430026.body
}

bool ATMMediator::cashAddSubtractReplace ()
{
  //## begin atm::ATMMediator::cashAddSubtractReplace%5C646D02025D.body preserve=yes
   memset(m_c585,'N',8);
   // select recent add/subtract activity
   m_vATMActivity.erase(m_vATMActivity.begin(),m_vATMActivity.end());
   if (m_hATMEvent[0].getFUNCTION_CODE() == "583"
      || m_hATMEvent[0].getFUNCTION_CODE() == "584")
   {
      m_hQuery[1].reset();
      m_hQuery[1].setIndex(11);
      m_hATMActivity.bind(m_hQuery[1]);
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","NET_TERM_ID","=",m_hATMEvent[0].getNET_TERM_ID().c_str());
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","DATE_RECON_ACQ","=",m_hATMEvent[0].getDATE_RECON_ACQ().c_str());
      string strDate(m_hATMEvent[0].getTSTAMP_TRANS().data(),8);
      string strTime(m_hATMEvent[0].getTSTAMP_TRANS().data() + 8,8);
      Timestamp::adjustGMT(strDate,strTime,-15);
      strDate.resize(8);
      strDate.append(strTime);
      strDate.append("00",2);
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","TSTAMP_TRANS",">=",strDate.c_str());
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","TSTAMP_TRANS","<",m_hATMEvent[0].getTSTAMP_TRANS().c_str());
      if (m_hATMEvent[0].getFUNCTION_CODE() == "583")
         m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","FUNCTION_CODE","=","584");
      else
         m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","FUNCTION_CODE","=","583");
      m_hQuery[1].setOrderByClause("TSTAMP_TRANS DESC");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(m_hQuery[1]))
         return false;
   }
   // select amounts to calculate cassettes_end
   m_hQuery[1].reset();
   m_hQuery[1].setIndex(6);
   m_hATMActivity.bind(m_hQuery[1]);
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","NET_TERM_ID","=",m_hATMEvent[0].getNET_TERM_ID().c_str());
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","TSTAMP_TRANS","=",m_hATMEvent[0].getTSTAMP_TRANS().c_str());
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","UNIQUENESS_KEY","=",m_hATMEvent[0].getUNIQUENESS_KEY());
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","FUNCTION_CODE","IN","('583','584','585')");
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","ACTIVITY_GROUP","IN","(300,400)");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(m_hQuery[1]);
   if (!b)
      return false;
   if (pSelectStatement->getRows() > 0
      || m_hATMEvent[0].getFUNCTION_CODE() != "585")
      return true;
   // cash zap of all cassettes to zero
   m_hATMActivity.setACTIVITY_GROUP(atm::ATMActivity::CASH_ADD);
   m_hATMActivity.setAMT_RECON_NET(0);
   m_hATMActivity.setAMT_SURCHARGE(0);
   m_hATMActivity.setIMPACT_TO_ACQ("");
   m_hATMActivity.setITEM_COUNT(0);
   m_hATMActivity.setTRAN_COUNT(0);
   m_hATMActivity.setTRAN_DISPOSITION("1");
   int j = 0;
   for (int i = 0;i < 8;++i)
   {
      if (m_hATMEvent[0].getCASSETTEn_BEGIN(i) > 0)
      {
         m_hATMActivity.setACTIVITY_TYPE((atm::ATMActivity::ActivityType)(i + atm::ATMActivity::CANISTER1));
         m_hATMActivity.setCUR_RECON_NET(m_hATMEvent[0].getCASSETTEn_CUR_CODE(i));
         m_hATMActivity.setCUR_TYPE(m_hATMEvent[0].getCASSETTEn_CUR_TYPE(i));
         m_hATMActivity.setITEM_VALUE(m_hATMEvent[0].getCASSETTEn_VALUE(i));
         if (!cashReplace())
            return false;
         j = 1;
      }
   }
   if (j == 0)
   {
      m_hATMActivity.setACTIVITY_TYPE(atm::ATMActivity::DEVICE);
      m_hATMActivity.setCUR_RECON_NET(m_hATMEvent[0].getCUR_CODE());
      m_hATMActivity.setCUR_TYPE(1);
      m_hATMActivity.setITEM_VALUE(0);
      b = cashReplace();
   }
   return b;
  //## end atm::ATMMediator::cashAddSubtractReplace%5C646D02025D.body
}

bool ATMMediator::cashReplace ()
{
  //## begin atm::ATMMediator::cashReplace%5C646CD401FA.body preserve=yes
   m_hTable.set("ACTIVITY_GROUP",(int)atm::ATMActivity::CASH_SUBTRACT,true);
   m_hTable.set("ACTIVITY_TYPE",m_hATMActivity.getACTIVITY_TYPE(),true);
   m_hTable.set("TRAN_DISPOSITION","1",false,true);
   m_hTable.set("CUR_RECON_NET",m_hATMActivity.getCUR_RECON_NET());
   if (m_hATMActivity.getACTIVITY_TYPE() == atm::ATMActivity::DEVICE)
      m_hTable.set("AMT_RECON_NET",m_hATMEvent[0].getCASSETTES_BEGIN());
   else
      m_hTable.set("AMT_RECON_NET",m_hATMEvent[0].getCASSETTEn_BEGIN(m_hATMActivity.getACTIVITY_TYPE() - 11));
   m_hTable.set("AMT_SURCHARGE",(int)0);
   m_hTable.set("TRAN_COUNT",(int)0);
   m_hTable.set("ITEM_VALUE",(int)0);
   m_hTable.set("ITEM_COUNT",(int)0);
   m_hTable.set("CUR_TYPE",m_hATMActivity.getCUR_TYPE());
   m_hTable.set("IMPACT_TO_ACQ"," ");
   if (!updateActivity())
      return false;
   bool b = true;
   if (m_hATMActivity.getACTIVITY_TYPE() != atm::ATMActivity::DEVICE)
   {
      m_hATMActivity.setACTIVITY_GROUP(atm::ATMActivity::CASH_SUBTRACT);
      double d = m_hATMActivity.getAMT_RECON_NET();
      m_hATMActivity.setAMT_RECON_NET(m_hATMEvent[0].getCASSETTEn_BEGIN(m_hATMActivity.getACTIVITY_TYPE() - 11));
      b = ATMLog::instance()->applyTo998(m_hATMEvent[0],m_hATMActivity);
      m_hATMActivity.setACTIVITY_GROUP(atm::ATMActivity::CASH_ADD);
      m_hATMActivity.setAMT_RECON_NET(d);
   }
   return b;
  //## end atm::ATMMediator::cashReplace%5C646CD401FA.body
}

bool ATMMediator::depositSweep ()
{
  //## begin atm::ATMMediator::depositSweep%5C644FD302C5.body preserve=yes
   // find prior deposit sweep
   Query hQuery;
   m_hATMEvent[2].reset();
   m_hATMEvent[2].bind(hQuery);
   hQuery.setBasicPredicate("T_ATM_EVENT","NET_TERM_ID","=",m_hATMEvent[0].getNET_TERM_ID().c_str());
   hQuery.setBasicPredicate("T_ATM_EVENT","TSTAMP_TRANS","<",m_hATMEvent[0].getTSTAMP_TRANS().c_str());
   hQuery.setBasicPredicate("T_ATM_EVENT","FUNCTION_CODE","=","593");
   hQuery.setOrderByClause("TSTAMP_TRANS ASC");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return UseCase::setSuccess(false);
   // retrieve all deposit transaction activity to sum cash and checks deposited
   m_hQuery[1].reset();
   m_hQuery[1].setIndex(7);
   m_hATMActivity.bind(m_hQuery[1]);
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","NET_TERM_ID","=",m_hATMEvent[0].getNET_TERM_ID().c_str());
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","FUNCTION_CODE","<>","998");
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","ACTIVITY_GROUP","IN","(100,200)");
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","ACTIVITY_TYPE","BETWEEN","20 AND 64");
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","TRAN_DISPOSITION","<>","2");
   if (pSelectStatement->getRows() > 0)
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","TSTAMP_TRANS",">",m_hATMEvent[2].getTSTAMP_TRANS().c_str());
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","TSTAMP_TRANS","<=",m_hATMEvent[0].getTSTAMP_TRANS().c_str());
   return pSelectStatement->execute(m_hQuery[1]);
  //## end atm::ATMMediator::depositSweep%5C644FD302C5.body
}

bool ATMMediator::getWaitingEvents ()
{
  //## begin atm::ATMMediator::getWaitingEvents%5E79610400B7.body preserve=yes
   string strName(Application::instance()->name().data(),4);
   strName.replace(2, 2, "TE");
   Context hContext(Application::instance()->image(), strName);
   string strTransactionProgress;
   if (!hContext.get("TRANSACTION PROGRESS", strTransactionProgress))
      return true;
   string strDate(strTransactionProgress.data(), 11);
   string strTime(strTransactionProgress.data() + 11, 4);
   strTime.append("00",2);
   Timestamp::adjustGMT(strDate, strTime, 10);
   strTransactionProgress = strDate;
   strTransactionProgress.append(strTime.data(), 4);
   if (strTransactionProgress < InsertSequenceNumber::getYYYYMMDDJJJHHMM())
      return true;
   string strFirst("X");
   string strSecond;
   ConfigurationRepository::instance()->translate("~X_GENERIC", strFirst, strSecond, " ", " ", -1, false);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (m_strDate.empty())
   {
      Query hQuery;
      short iNull = -1;
      hQuery.bind("T_ATM_EVENT","TSTAMP_TRANS",Column::STRING,&m_strDate,&iNull,"MIN");
      hQuery.setBasicPredicate("T_ATM_EVENT","AE_STATE","IN","('TI','TW')");
      hQuery.setBasicPredicate("T_ATM_EVENT","FUNCTION_CODE","<>","998");
      hQuery.setBasicPredicate("T_ATM_EVENT","TSTAMP_TRANS","<=",database::SwitchClock::instance()->getYYYYMMDDHHMMSSHN().c_str());
      if (pSelectStatement->execute(hQuery) == false
         || iNull == -1)
         return true;
      m_strDate.replace(8,8,"23595999");
      if (m_strDate > database::SwitchClock::instance()->getYYYYMMDDHHMMSSHN())
         m_strDate.assign("9999123123595999",16);
   }
   vector<string>::iterator p;
   for (p = atm::TerminalSet::instance()->getNET_TERM_IDs().begin(); p != atm::TerminalSet::instance()->getNET_TERM_IDs().end(); ++p)
   {
      string strFUNCTION_CODE;
      m_hQuery[0].reset();
      m_hQuery[0].setRetainCursor(true);
      m_hATMEvent[0].bind(m_hQuery[0]);
      m_hQuery[0].bind("T_ATM_EVENT", "FUNCTION_CODE FUNCTION_CODE2", Column::STRING, &strFUNCTION_CODE, 0, "CASE,'ATM','572','AUT','572','RMT','572',FUNCTION_CODE");
      if (m_strDate < database::SwitchClock::instance()->getYYYYMMDDHHMMSSHN())
         m_hQuery[0].setBasicPredicate("T_ATM_EVENT", "TSTAMP_TRANS", "<=", m_strDate.c_str()); // one day at a time until caught up to switch clock
      else
         m_hQuery[0].setBasicPredicate("T_ATM_EVENT", "TSTAMP_TRANS", "<=", database::SwitchClock::instance()->getYYYYMMDDHHMMSSHN().c_str());
      m_hQuery[0].setBasicPredicate("T_ATM_EVENT", "FUNCTION_CODE", "<>", "998");
      m_hQuery[0].setBasicPredicate("T_ATM_EVENT", "AE_STATE", "IN", "('TI','TW')");
      if ((*p) != "('*')")
         m_hQuery[0].setBasicPredicate("T_ATM_EVENT", "NET_TERM_ID", "IN", (*p).data());
      m_hQuery[0].setOrderByClause("TSTAMP_TRANS,NET_TERM_ID,FUNCTION_CODE2");
      if (pSelectStatement->execute(m_hQuery[0]) == false
          || m_hQuery[0].getAbort())
          return true;
   }
   if (m_strDate < database::SwitchClock::instance()->getYYYYMMDDHHMMSSHN())
   {
      Date hDate(m_strDate.c_str());
      hDate += 1;
      m_strDate = hDate.asString("%Y%m%d23595999");
      if (m_strDate > database::SwitchClock::instance()->getYYYYMMDDHHMMSSHN())
         m_strDate.assign("9999123123595999",16);
      return false; // keep running
   }
   return true;
  //## end atm::ATMMediator::getWaitingEvents%5E79610400B7.body
}

bool ATMMediator::reset (bool bMT, bool bPrimary)
{
  //## begin atm::ATMMediator::reset%5C50AF1700C9.body preserve=yes
   string strFirst("X");
   string strSecond;
   ConfigurationRepository::instance()->translate("~X_GENERIC",strFirst,strSecond," "," ",-1,false);
   m_bPrimary = bPrimary;
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   Table hTable("T_ATM_EVENT");
   hTable.set("AE_STATE","TW");
   SearchCondition hSearchCondition;
   hSearchCondition.setBasicPredicate("T_ATM_EVENT","AE_STATE","=","TI");
   hSearchCondition.setBasicPredicate("T_ATM_EVENT","TASK_TOTALED","=",process::Application::instance()->name().c_str());
   pUpdateStatement->execute(hTable,hSearchCondition.getText());
   int lInfoIDNumber = pUpdateStatement->getInfoIDNumber();
   if (!bMT)
      MinuteTimer::instance()->attach(this);
   return (!(lInfoIDNumber != 0 && lInfoIDNumber != STS_RECORD_NOT_FOUND));
  //## end atm::ATMMediator::reset%5C50AF1700C9.body
}

bool ATMMediator::retrieve (short siIndex)
{
  //## begin atm::ATMMediator::retrieve%5C5C336503DD.body preserve=yes
   string strTable[2];
   strTable[0].assign("FIN_Lyyyymm L",13);
   strTable[0].replace(5,6,m_hATMEvent[1].getTSTAMP_TRANS().data(),6);
   strTable[1].assign("FIN_Lyyyymm L",13);
   strTable[1].replace(5,6,m_hATMEvent[0].getTSTAMP_TRANS().data(),6);
   char szTable[PERCENTD * 2 + 8];
   memcpy(szTable,strTable[0].data() + 5,6);
   szTable[6] = '\0';
   int iMonth = atoi(szTable + 4);
   szTable[4] = '\0';
   int iYear = atoi(szTable);
   strcpy(szTable,strTable[0].c_str());
   do
   {
      m_hQuery[1].reset();
      m_hQuery[1].setIndex(siIndex);
      m_hQuery[1].join(szTable,"INNER","FIN_RECORD","TSTAMP_TRANS");
      m_hQuery[1].join(szTable,"INNER","FIN_RECORD","UNIQUENESS_KEY");
      if (siIndex == 1)
         m_hATMTransaction.bind(m_hQuery[1],szTable);
      else
      if (siIndex == 2)
      {
         string strTable("FIN_DEP_CASHyyyymm");
         strTable.replace(12,6,szTable + 5,6);
         m_hQuery[1].join(szTable,"INNER",strTable.c_str(),"TSTAMP_TRANS");
         m_hQuery[1].join(szTable,"INNER",strTable.c_str(),"UNIQUENESS_KEY");
         m_hATMTransaction.bind(m_hQuery[1],szTable,strTable);
      }
      else
      {
         string strTable("FIN_DEP_CHKyyyymm");
         strTable.replace(11,6,szTable + 5,6);
         m_hQuery[1].join(szTable,"INNER",strTable.c_str(),"TSTAMP_TRANS");
         m_hQuery[1].join(szTable,"INNER",strTable.c_str(),"UNIQUENESS_KEY");
         m_hATMTransaction.bind(m_hQuery[1],szTable,strTable);
      }
      m_hQuery[1].setBasicPredicate(szTable,"NET_TERM_ID","=",m_hATMEvent[0].getNET_TERM_ID().c_str());
      m_hQuery[1].setBasicPredicate(szTable,"TSTAMP_TRANS",">",m_hATMEvent[1].getTSTAMP_TRANS().c_str());
      m_hQuery[1].setBasicPredicate(szTable,"TSTAMP_TRANS","<=",m_hATMEvent[0].getTSTAMP_TRANS().c_str());
      if (++iMonth > 12)
      {
         iMonth = 1;
         ++iYear;
      }
      std::ostringstream oss;
      oss << "FIN_L" << iYear << setfill('0') << setw(2) << right << iMonth << " L" << '\0';
      memcpy(szTable,oss.str().data(),oss.str().length());
      auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
      if (pSelectStatement->execute(m_hQuery[1]) == false
         || m_hQuery[1].getAbort()
         || Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
         return UseCase::setSuccess(false);
   }
   while (strTable[1] >= szTable);
   return true;
  //## end atm::ATMMediator::retrieve%5C5C336503DD.body
}

bool ATMMediator::retrieveTeller ()
{
  //## begin atm::ATMMediator::retrieveTeller%5DE8151E03B8.body preserve=yes
   string strTable[2];
   strTable[0].assign("DEV_ADMIN_Lyyyymm L",19);
   strTable[0].replace(11,6,m_hATMEvent[1].getTSTAMP_TRANS().data(),6);
   strTable[1].assign("DEV_ADMIN_Lyyyymm L",19);
   strTable[1].replace(11,6,m_hATMEvent[0].getTSTAMP_TRANS().data(),6);
   char szTable[PERCENTD * 2 + 14];
   memcpy(szTable,strTable[0].data() + 11,6);
   szTable[6] = '\0';
   int iMonth = atoi(szTable + 4);
   szTable[4] = '\0';
   int iYear = atoi(szTable);
   strcpy(szTable,strTable[0].c_str());
   do
   {
      m_hQuery[1].reset();
      m_hQuery[1].setIndex(9);
      m_hQuery[1].join(szTable,"INNER","DEV_ADMIN","TSTAMP_TRANS");
      m_hQuery[1].join(szTable,"INNER","DEV_ADMIN","UNIQUENESS_KEY");
      string strTemp(szTable);
      m_hAdminMessage.bind(m_hQuery[1],strTemp);
      m_hQuery[1].setBasicPredicate(szTable,"NET_TERM_ID","=",m_hATMEvent[0].getNET_TERM_ID().c_str());
      m_hQuery[1].setBasicPredicate(szTable,"FUNCTION_CODE","IN","('584','595')");
      m_hQuery[1].setBasicPredicate(szTable,"TSTAMP_TRANS",">",m_hATMEvent[1].getTSTAMP_TRANS().c_str());
      m_hQuery[1].setBasicPredicate(szTable,"TSTAMP_TRANS","<=",m_hATMEvent[0].getTSTAMP_TRANS().c_str());
      if (++iMonth > 12)
      {
         iMonth = 1;
         ++iYear;
      }
      std::ostringstream oss;
      oss << "DEV_ADMIN_L" << iYear << setfill('0') << setw(2) << right << iMonth << " L" << '\0';
      memcpy(szTable,oss.str().data(),oss.str().length());
      auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
      if (pSelectStatement->execute(m_hQuery[1]) == false
         || m_hQuery[1].getAbort()
         || Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
         return UseCase::setSuccess(false);
   }
   while (strTable[1] >= szTable);
   return true;
  //## end atm::ATMMediator::retrieveTeller%5DE8151E03B8.body
}

bool ATMMediator::setState (const char* pszAE_STATE)
{
  //## begin atm::ATMMediator::setState%5C5C30270216.body preserve=yes
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      Database::instance()->rollback();
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   Table hTable("T_ATM_EVENT");
   if (!memcmp(pszAE_STATE,"TC",2))
   {
      m_hATMEvent[0].setColumns(hTable);
   }
   else
   {
      hTable.set("NET_TERM_ID",m_hATMEvent[0].getNET_TERM_ID(),false,true);
      hTable.set("TSTAMP_TRANS",m_hATMEvent[0].getTSTAMP_TRANS(),false,true);
      hTable.set("UNIQUENESS_KEY",(int)m_hATMEvent[0].getUNIQUENESS_KEY(),true);
      hTable.set("FUNCTION_CODE",m_hATMEvent[0].getFUNCTION_CODE(),false,true);
   }
   hTable.set("TASK_TOTALED",process::Application::instance()->name());
   hTable.set("TSTAMP_TOTALED",timer::Clock::instance()->getYYYYMMDDHHMMSSHN());
   hTable.set("AE_STATE",pszAE_STATE);
   if (!pUpdateStatement->execute(hTable))
      return UseCase::setSuccess(false);
   Database::instance()->commit();
   return UseCase::setSuccess(strcmp(pszAE_STATE,"TW") != 0);
  //## end atm::ATMMediator::setState%5C5C30270216.body
}

bool ATMMediator::settle ()
{
  //## begin atm::ATMMediator::settle%5C646F6E000A.body preserve=yes
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (m_strTSTAMP_TRANS[1].empty())
   {
      // select prior end of day suspense to add to:
      //    572 settlement totals
      //    999 end of day new suspense
      m_hQuery[1].reset();
      m_hQuery[1].setIndex(5);
      m_hATMActivity.bind(m_hQuery[1]);
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","NET_TERM_ID","=",m_hATMEvent[0].getNET_TERM_ID().c_str());
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","FUNCTION_CODE","=","999");
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","ACTIVITY_GROUP","IN","(700,800)");
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","TSTAMP_TRANS","=",m_strTSTAMP_TRANS[0].c_str());
      if (!pSelectStatement->execute(m_hQuery[1]))
         return UseCase::setSuccess(false);
   }
   // select prior activity to add to 572 or 999
   m_hQuery[1].reset();
   m_hQuery[1].setIndex(5);
   m_hATMActivity.bind(m_hQuery[1]);
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","NET_TERM_ID","=",m_hATMEvent[0].getNET_TERM_ID().c_str());
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","ACTIVITY_GROUP","IN","(100,200)");
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","FUNCTION_CODE","<>","998");
   int i = m_strTSTAMP_TRANS[1].empty() ? 0 : 1;
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","TSTAMP_TRANS",">",m_strTSTAMP_TRANS[i].c_str());
   m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","TSTAMP_TRANS","<",m_hATMEvent[0].getTSTAMP_TRANS().c_str());
   bool b = pSelectStatement->execute(m_hQuery[1]);
   m_iRows = pSelectStatement->getRows();
   return b;
  //## end atm::ATMMediator::settle%5C646F6E000A.body
}

bool ATMMediator::total ()
{
  //## begin atm::ATMMediator::total%5C50A49601F8.body preserve=yes
   UseCase hUseCase("TOTALS","## AT06 TOTAL ATM ACTIVITY");
   bool bRetotal = m_hATMEvent[0].getTASK_TOTALED().empty() == false;
   // redo any subsequent TC events (due to out of order DEV_ADMIN.INSERT_SEQUENCE_NO values)
   Table hTable("T_ATM_EVENT");
   hTable.set("NET_TERM_ID",m_hATMEvent[0].getNET_TERM_ID(),false,true);
   SearchCondition hSearchCondition;
   hSearchCondition.setBasicPredicate("T_ATM_EVENT","AE_STATE","=","TC");
   hSearchCondition.setBasicPredicate("T_ATM_EVENT","TSTAMP_TRANS",">",m_hATMEvent[0].getTSTAMP_TRANS().c_str());
   hTable.set("AE_STATE","TW");
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if (pUpdateStatement->execute(hTable,hSearchCondition.getText()) == false
      && pUpdateStatement->getInfoIDNumber() != STS_RECORD_NOT_FOUND)
      return UseCase::setSuccess(false);
   if (!setState("TI"))
      return UseCase::setSuccess(false);
   m_iRows = -1;
   // look for prior EOD and settle event
   m_strTSTAMP_TRANS[0].erase();
   m_strTSTAMP_TRANS[1].erase();
   string strFUNCTION_CODE;
   m_hQuery[1].reset();
   m_hQuery[1].setIndex(4);
   m_hATMEvent[1].bind(m_hQuery[1]);
   m_hQuery[1].bind("T_ATM_EVENT","FUNCTION_CODE FUNCTION_CODE2",Column::STRING,&strFUNCTION_CODE,0,"CASE,'ATM','572','AUT','572','RMT','572',FUNCTION_CODE");
   m_hQuery[1].setBasicPredicate("T_ATM_EVENT","NET_TERM_ID","=",m_hATMEvent[0].getNET_TERM_ID().c_str());
   Date hDate(m_hATMEvent[0].getDATE_RECON_ACQ().c_str());
   hDate -= 1;
   string strDATE_RECON_ACQ(hDate.asString("%Y%m%d"));
   m_hQuery[1].setBasicPredicate("T_ATM_EVENT","DATE_RECON_ACQ",">=",strDATE_RECON_ACQ.c_str());
   m_hQuery[1].setBasicPredicate("T_ATM_EVENT","TSTAMP_TRANS","<=",m_hATMEvent[0].getTSTAMP_TRANS().c_str());
   m_hQuery[1].setBasicPredicate("T_ATM_EVENT","AE_STATE","=","TC");
   m_hQuery[1].setBasicPredicate("T_ATM_EVENT","FUNCTION_CODE","<>","998");
   m_hQuery[1].setOrderByClause("TSTAMP_TRANS,FUNCTION_CODE2");
   {
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(m_hQuery[1]))
      return setState("TW");
   if (pSelectStatement->getRows() == 0)
   {
      m_hATMEvent[1].reset();
      m_hATMEvent[1].setDATE_RECON_ACQ(strDATE_RECON_ACQ);
      m_hATMEvent[1].setFUNCTION_CODE("999");
      m_hATMEvent[1].setTSTAMP_TRANS(m_hATMEvent[0].getTSTAMP_TRANS());
   }
   }
   /*
   if (m_hATMEvent[0].getFUNCTION_CODE() == "572"
      && m_strTSTAMP_TRANS[1].empty() == false)
   {
      string strCUTOFF_IND;
      string strCUTOFF_TIME;
      Query hQuery;
      hQuery.setQualifier("QUALIFY","DEVICE");
      hQuery.bind("DEVICE","CUTOFF_IND",Column::STRING,&strCUTOFF_IND);
      hQuery.bind("DEVICE","CUTOFF_TIME",Column::STRING,&strCUTOFF_TIME);
      string strCUST_ID;
      Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
      hQuery.setBasicPredicate("DEVICE","DEVICE_ID","=",m_hATMEvent[0].getNET_TERM_ID().c_str());
      hQuery.setBasicPredicate("DEVICE","CUST_ID","=",strCUST_ID.c_str());
      hQuery.setBasicPredicate("DEVICE","CC_CHANGE_GRP_ID","IS NULL");
      hQuery.setBasicPredicate("DEVICE","CC_STATE","=","A");
      if (!pSelectStatement->execute(hQuery))
         return setState("TW");
      if (strCUTOFF_IND[0] == '1'
         && strCUTOFF_TIME != m_strTSTAMP_TRANS[1].substr(8,8)
         && strCUTOFF_TIME == m_hATMEvent[0].getTSTAMP_TRANS().substr(8,8))
      {
         // delete this event as device was already manually settled today
         Query hQuery;
         hQuery.setQualifier("CUSTQUAL","T_ATM_EVENT");
         hQuery.setBasicPredicate("T_ATM_EVENT","NET_TERM_ID","=",m_hATMEvent[0].getNET_TERM_ID().c_str());
         hQuery.setBasicPredicate("T_ATM_EVENT","DATE_RECON_ACQ","=",m_hATMEvent[0].getDATE_RECON_ACQ().c_str());
         hQuery.setBasicPredicate("T_ATM_EVENT","TSTAMP_TRANS","=",m_hATMEvent[0].getTSTAMP_TRANS().c_str());
         hQuery.setBasicPredicate("T_ATM_EVENT","UNIQUENESS_KEY","=",m_hATMEvent[0].getUNIQUENESS_KEY());
         hQuery.setBasicPredicate("T_ATM_EVENT","FUNCTION_CODE","=","572");
         auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
         if (!pDeleteStatement->execute(hQuery))
            return setState("TW");
         return Database::instance()->commit();
      }
   }
   */
   m_hATMTransaction.reset();
   // set begin values from prior end values
   m_hATMEvent[0].setCASSETTES_BEGIN(m_hATMEvent[1].getCASSETTES_END());
   m_hATMEvent[0].setCASSETTES_END(0);
   for (int i = 0;i < 8;++i)
   {
      if (m_hATMEvent[1].getCASSETTEn_VALUE(i) != 0)
      {
         m_hATMEvent[0].setCASSETTEn_VALUE(i,m_hATMEvent[1].getCASSETTEn_VALUE(i));
         m_hATMEvent[0].setCASSETTEn_CUR_CODE(i,m_hATMEvent[1].getCASSETTEn_CUR_CODE(i));
         m_hATMEvent[0].setCASSETTEn_CUR_TYPE(i,m_hATMEvent[1].getCASSETTEn_CUR_TYPE(i));
      }
      m_hATMEvent[0].setCASSETTEn_BEGIN(i,m_hATMEvent[1].getCASSETTEn_END(i));
      m_hATMEvent[0].setCASSETTEn_END(i,0);
   }
   m_hATMEvent[0].setCASH_BEGIN(m_hATMEvent[1].getCASH_END());
   m_hATMEvent[0].setCASH_END(0);
   m_hATMEvent[0].setCHECK_BEGIN(m_hATMEvent[1].getCHECK_END());
   m_hATMEvent[0].setCHECK_END(0);
   m_hATMEvent[0].setTELLER_BEGIN(m_hATMEvent[1].getTELLER_END());
   m_hATMEvent[0].setTELLER_END(0);
   // reverse prior 583,584,585 subtract/add if any
   if (bRetotal
      && (m_hATMEvent[0].getFUNCTION_CODE() == "583"
      || m_hATMEvent[0].getFUNCTION_CODE() == "584"
      || m_hATMEvent[0].getFUNCTION_CODE() == "585"))
   {
      m_hQuery[1].reset();
      m_hQuery[1].setIndex(10);
      m_hATMActivity.bind(m_hQuery[1]);
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","NET_TERM_ID","=",m_hATMEvent[0].getNET_TERM_ID().c_str());
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","TSTAMP_TRANS","=",m_hATMEvent[0].getTSTAMP_TRANS().c_str());
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","UNIQUENESS_KEY","=",m_hATMEvent[0].getUNIQUENESS_KEY());
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","FUNCTION_CODE","=",m_hATMEvent[0].getFUNCTION_CODE().c_str());
      m_hQuery[1].setBasicPredicate("T_ATM_ACTIVITY","ACTIVITY_GROUP","IN","(300,400)");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(m_hQuery[1]))
         return setState("TW");
   }
   // erase existing T_ATM_ACTIVITY rows
   Query hQuery;
   hQuery.setQualifier("CUSTQUAL","T_ATM_ACTIVITY");
   hQuery.setBasicPredicate("T_ATM_ACTIVITY","NET_TERM_ID","=",m_hATMEvent[0].getNET_TERM_ID().c_str());
   hQuery.setBasicPredicate("T_ATM_ACTIVITY","DATE_RECON_ACQ","=",m_hATMEvent[0].getDATE_RECON_ACQ().c_str());
   hQuery.setBasicPredicate("T_ATM_ACTIVITY","TSTAMP_TRANS","=",m_hATMEvent[0].getTSTAMP_TRANS().c_str());
   hQuery.setBasicPredicate("T_ATM_ACTIVITY","UNIQUENESS_KEY","=",m_hATMEvent[0].getUNIQUENESS_KEY());
   hQuery.setBasicPredicate("T_ATM_ACTIVITY","FUNCTION_CODE","=",m_hATMEvent[0].getFUNCTION_CODE().c_str());
   if (m_hATMEvent[0].getFUNCTION_CODE() == "583"
      || m_hATMEvent[0].getFUNCTION_CODE() == "585")
      hQuery.setBasicPredicate("T_ATM_ACTIVITY","ACTIVITY_GROUP","<>",(int)atm::ATMActivity::CASH_ADD);
   if (m_hATMEvent[0].getFUNCTION_CODE() == "584")
      hQuery.setBasicPredicate("T_ATM_ACTIVITY","ACTIVITY_GROUP","<>",(int)atm::ATMActivity::CASH_SUBTRACT);
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   if (!pDeleteStatement->execute(hQuery))
      return setState("TW");
   m_hTable.setName("T_ATM_ACTIVITY");
   m_hTable.set("NET_TERM_ID",m_hATMEvent[0].getNET_TERM_ID(),false,true);
   m_hTable.set("DATE_RECON_ACQ",m_hATMEvent[0].getDATE_RECON_ACQ(),false,true);
   m_hTable.set("TSTAMP_TRANS",m_hATMEvent[0].getTSTAMP_TRANS(),false,true);
   m_hTable.set("UNIQUENESS_KEY",m_hATMEvent[0].getUNIQUENESS_KEY(),true);
   m_hTable.set("FUNCTION_CODE",m_hATMEvent[0].getFUNCTION_CODE(),false,true);
   if (m_hATMEvent[0].getFUNCTION_CODE() == "572"
      || m_hATMEvent[0].getFUNCTION_CODE() == "ATM"
      || m_hATMEvent[0].getFUNCTION_CODE() == "AUT"
      || m_hATMEvent[0].getFUNCTION_CODE() == "RMT"
      || m_hATMEvent[0].getFUNCTION_CODE() == "999")
      if (!settle())
         return setState("TW");
   if (m_hATMEvent[0].getFUNCTION_CODE() == "583"
      || m_hATMEvent[0].getFUNCTION_CODE() == "584"
      || m_hATMEvent[0].getFUNCTION_CODE() == "585")
      if (!cashAddSubtractReplace())
         return setState("TW");
   // retrieve cardholder transactions prior to this event
   m_hATMTransaction.reset();
   if (!retrieve(1))
      return setState("TW");
   if (!retrieve(2))
      return setState("TW");
   if (!retrieve(3))
      return setState("TW");
   // retrieve teller deposits and withdrawals prior to this event
   m_hAdminMessage.reset();
   if (!retrieveTeller())
      return setState("TW");
   if (m_hATMEvent[0].getFUNCTION_CODE() == "593")
      if (!depositSweep())
         return setState("TW");
   if (m_hATMEvent[0].getFUNCTION_CODE() == "585"
      && m_hATMEvent[0].getCASSETTES_END() != 0)
      ; // device level reset ; leave canister ends as zero
   else
   if ((m_hATMEvent[0].getFUNCTION_CODE() == "584"
      || m_hATMEvent[0].getFUNCTION_CODE() == "585")
      && m_hATMEvent[0].getCASSETTEn_END(0) == 0
      && m_hATMEvent[0].getCASSETTEn_END(1) == 0
      && m_hATMEvent[0].getCASSETTEn_END(2) == 0
      && m_hATMEvent[0].getCASSETTEn_END(3) == 0
      && m_hATMEvent[0].getCASSETTEn_END(4) == 0
      && m_hATMEvent[0].getCASSETTEn_END(5) == 0
      && m_hATMEvent[0].getCASSETTEn_END(6) == 0
      && m_hATMEvent[0].getCASSETTEn_END(7) == 0)
      ; // device level subtract or zap to zeros ; set device and canister ends as zero
   else
   {
      for (int i = 0;i < 8;++i)
      {
         if (m_hATMEvent[0].getFUNCTION_CODE() == "585"
            && m_hATMEvent[0].getCASSETTEn_END(i) != 0)
            m_hATMEvent[0].setCASSETTES_END(m_hATMEvent[0].getCASSETTES_END() + m_hATMEvent[0].getCASSETTEn_END(i));
         else
         {
            // detect cash zap done as cash add/subtract or cash subtract/add
            bool bAddSubtract = false;
            vector<ATMActivity>::iterator p;
            if (m_hATMEvent[0].getFUNCTION_CODE() == "583"
               && m_hATMEvent[0].getCASSETTEn_END(i) != 0
               && m_vATMActivity.empty() == false)
               for (p = m_vATMActivity.begin();p != m_vATMActivity.end();++p)
                  if ((*p).getACTIVITY_TYPE() == i + atm::ATMActivity::CANISTER1)
                  {
                     // just leave CASSETTEn_END as is from the add
                     bAddSubtract = true;
                     break;
                  }
            if (m_hATMEvent[0].getFUNCTION_CODE() == "584"
               && m_hATMEvent[0].getCASSETTEn_END(i) != 0
               && m_vATMActivity.empty() == false)
               for (p = m_vATMActivity.begin();p != m_vATMActivity.end();++p)
                  if ((*p).getACTIVITY_TYPE() == i + atm::ATMActivity::CANISTER1)
                  {
                     // set CASSETTEn_END from the corresponding add
                     m_hATMEvent[0].setCASSETTEn_END(i,(*p).getAMT_RECON_NET());
                     bAddSubtract = true;
                     break;
                  }
            if (!bAddSubtract)
               m_hATMEvent[0].setCASSETTEn_END(i,m_hATMEvent[0].getCASSETTEn_BEGIN(i) + m_hATMEvent[0].getCASSETTEn_END(i)
                  + m_hATMTransaction.getDebit(i + atm::ATMTransaction::TOTAL_CASSETTE1) - m_hATMTransaction.getCredit(i + atm::ATMTransaction::TOTAL_CASSETTE1)
                  + m_hAdminMessage.getDebit(i + atm::AdminMessage::TOTAL_CASSETTE1) - m_hAdminMessage.getCredit(i + atm::AdminMessage::TOTAL_CASSETTE1));
            if (m_hATMTransaction.getDebit(i + atm::ATMTransaction::TOTAL_CASSETTE1) != 0
               || m_hATMTransaction.getCredit(i + atm::ATMTransaction::TOTAL_CASSETTE1) != 0)
            {
               m_hATMEvent[0].setCASSETTEn_VALUE(i,m_hATMTransaction.getITEM_VALUE(i + atm::ATMTransaction::TOTAL_CASSETTE1));
               m_hATMEvent[0].setCASSETTEn_CUR_CODE(i,m_hATMTransaction.getCUR_CODE(i + atm::ATMTransaction::TOTAL_CASSETTE1));
               m_hATMEvent[0].setCASSETTEn_CUR_TYPE(i,m_hATMTransaction.getCUR_TYPE(i + atm::ATMTransaction::TOTAL_CASSETTE1));
            }
            else
            if (m_hAdminMessage.getDebit(i + atm::AdminMessage::TOTAL_CASSETTE1) != 0
               || m_hAdminMessage.getCredit(i + atm::AdminMessage::TOTAL_CASSETTE1) != 0)
            {
               m_hATMEvent[0].setCASSETTEn_VALUE(i,m_hAdminMessage.getITEM_VALUE(i + atm::AdminMessage::TOTAL_CASSETTE1));
               m_hATMEvent[0].setCASSETTEn_CUR_CODE(i,m_hAdminMessage.getCUR_CODE(i + atm::AdminMessage::TOTAL_CASSETTE1));
               m_hATMEvent[0].setCASSETTEn_CUR_TYPE(i,m_hAdminMessage.getCUR_TYPE(i + atm::AdminMessage::TOTAL_CASSETTE1));
            }
            if (m_hATMEvent[0].getCASSETTEn_END(i) < 0)
            {
               if (m_hATMEvent[0].getCASSETTES_END() == 0)
                  m_hATMEvent[0].setCASSETTES_END(m_hATMEvent[0].getCASSETTES_BEGIN());
               m_hATMEvent[0].setCASSETTES_END(m_hATMEvent[0].getCASSETTES_END() + (m_hATMEvent[0].getCASSETTEn_END(i) - m_hATMEvent[1].getCASSETTEn_END(i)));
            }
            else
               m_hATMEvent[0].setCASSETTES_END(m_hATMEvent[0].getCASSETTES_END() + m_hATMEvent[0].getCASSETTEn_END(i));
         }
      }
      if (m_hATMEvent[0].getFUNCTION_CODE() == "584"
         && m_hATMEvent[0].getCASSETTEn_END(0) == 0
         && m_hATMEvent[0].getCASSETTEn_END(1) == 0
         && m_hATMEvent[0].getCASSETTEn_END(2) == 0
         && m_hATMEvent[0].getCASSETTEn_END(3) == 0
         && m_hATMEvent[0].getCASSETTEn_END(4) == 0
         && m_hATMEvent[0].getCASSETTEn_END(5) == 0
         && m_hATMEvent[0].getCASSETTEn_END(6) == 0
         && m_hATMEvent[0].getCASSETTEn_END(7) == 0)
         ; // canister level subtract ; all canisters now zero
      else
      if (m_hATMEvent[0].getCASSETTES_END() == 0)
         m_hATMEvent[0].setCASSETTES_END(m_hATMEvent[0].getCASSETTES_BEGIN());
   }
   if (m_hATMEvent[0].getCASSETTES_END() < 0)
   {
      for (int i = 0;i < 8;++i)
         m_hATMEvent[0].setCASSETTEn_END(i,0);
      m_hATMEvent[0].setCASSETTES_END(0);
   }
   if (m_hATMEvent[0].getFUNCTION_CODE() == "593")
   {
      m_hATMEvent[0].setCASH_END(0);
      m_hATMEvent[0].setCHECK_END(0);
   }
   else
   {
      m_hATMEvent[0].setCASH_END(m_hATMEvent[0].getCASH_BEGIN()
         + m_hATMTransaction.getDebit(atm::ATMTransaction::CASH) - m_hATMTransaction.getCredit(atm::ATMTransaction::CASH)
         + m_hAdminMessage.getDebit(atm::AdminMessage::CASH) - m_hAdminMessage.getCredit(atm::AdminMessage::CASH));
      m_hATMEvent[0].setCHECK_END(m_hATMEvent[0].getCHECK_BEGIN() + m_hATMTransaction.getDebit(atm::ATMTransaction::CHECK) - m_hATMTransaction.getCredit(atm::ATMTransaction::CHECK));
      m_hATMEvent[0].setTELLER_END(m_hATMEvent[0].getTELLER_BEGIN() + m_hAdminMessage.getDebit(atm::AdminMessage::TELLER) - m_hAdminMessage.getCredit(atm::AdminMessage::TELLER));
   }
   if (m_hATMEvent[0].getFUNCTION_CODE() == "572"
      || m_hATMEvent[0].getFUNCTION_CODE() == "ATM"
      || m_hATMEvent[0].getFUNCTION_CODE() == "AUT"
      || m_hATMEvent[0].getFUNCTION_CODE() == "RMT")
      atm::Reconciliation::instance()->check(m_hATMEvent[0]);
   atm::ATMInstitution::instance()->addEndOfDay(m_hATMEvent[0],m_iRows);
   return setState(Database::instance()->transactionState() == Database::ROLLBACKREQUIRED ? "TW" : "TC");
  //## end atm::ATMMediator::total%5C50A49601F8.body
}

void ATMMediator::update (Subject* pSubject)
{
  //## begin atm::ATMMediator::update%5C50A3FA035C.body preserve=yes
   if (pSubject == MinuteTimer::instance())
   {
      entitysegment::SwitchBusinessDay::instance()->update(MidnightAlarm::instance());
      if (m_bPrimary)
         age();
      Application::instance()->setQueueWaitOption(getWaitingEvents());
      return;
   }
   if (pSubject == &m_hQuery[0])
   {
      if (!total())
      {
         Database::instance()->commit();
         m_hQuery[0].setAbort(true);
      }
      return;
   }
   if (m_hQuery[1].getIndex() == 4)
   {
      if (m_hATMEvent[1].getFUNCTION_CODE() == "999")
         m_strTSTAMP_TRANS[0] = m_hATMEvent[1].getTSTAMP_TRANS();
      if ((m_hATMEvent[1].getFUNCTION_CODE() == "572"
         || m_hATMEvent[1].getFUNCTION_CODE() == "ATM"
         || m_hATMEvent[1].getFUNCTION_CODE() == "AUT"
         || m_hATMEvent[1].getFUNCTION_CODE() == "RMT")
         && (m_hATMEvent[0].getDATE_RECON_ACQ() == m_hATMEvent[1].getDATE_RECON_ACQ()
         || (m_strTSTAMP_TRANS[0].empty() == false
         && m_hATMEvent[1].getTSTAMP_TRANS() > m_strTSTAMP_TRANS[0])))
         m_strTSTAMP_TRANS[1] = m_hATMEvent[1].getTSTAMP_TRANS();
      return;
   }
   if (m_hQuery[1].getIndex() == 5)
   {
      if (m_hATMEvent[0].getFUNCTION_CODE() == "572"
         || m_hATMEvent[0].getFUNCTION_CODE() == "ATM"
         || m_hATMEvent[0].getFUNCTION_CODE() == "AUT"
         || m_hATMEvent[0].getFUNCTION_CODE() == "RMT")
      {
         if (m_hATMActivity.getACTIVITY_GROUP() <= atm::ATMActivity::ACTIVITY_FOREIGN)
            // add activity to settled
            m_hTable.set("ACTIVITY_GROUP",m_hATMActivity.getACTIVITY_GROUP() == atm::ATMActivity::ACTIVITY_ONUS ? (int)atm::ATMActivity::TERMINAL_SETTLE_ONUS : (int)atm::ATMActivity::TERMINAL_SETTLE_FOREIGN,true);
         else
            // add suspense to settled
            m_hTable.set("ACTIVITY_GROUP",m_hATMActivity.getACTIVITY_GROUP() == atm::ATMActivity::EOD_SUSPENSE_ONUS ? (int)atm::ATMActivity::TERMINAL_SETTLE_ONUS : (int)atm::ATMActivity::TERMINAL_SETTLE_FOREIGN,true);
      }
      else
      {
         if (m_hATMActivity.getACTIVITY_GROUP() <= atm::ATMActivity::ACTIVITY_FOREIGN)
            // add activity to suspense
            m_hTable.set("ACTIVITY_GROUP",m_hATMActivity.getACTIVITY_GROUP() == atm::ATMActivity::ACTIVITY_ONUS ? (int)atm::ATMActivity::EOD_SUSPENSE_ONUS : (int)atm::ATMActivity::EOD_SUSPENSE_FOREIGN,true);
         else
            m_hTable.set("ACTIVITY_GROUP",(int)m_hATMActivity.getACTIVITY_GROUP(),true);
      }
      m_hTable.set("ACTIVITY_TYPE",m_hATMActivity.getACTIVITY_TYPE(),true);
      m_hTable.set("TRAN_DISPOSITION",m_hATMActivity.getTRAN_DISPOSITION(),false,true);
      m_hTable.set("IMPACT_TO_ACQ",m_hATMActivity.getIMPACT_TO_ACQ());
      m_hTable.set("CUR_RECON_NET",m_hATMActivity.getCUR_RECON_NET());
      m_hTable.set("AMT_RECON_NET",m_hATMActivity.getAMT_RECON_NET(),false,"+");
      m_hTable.set("AMT_SURCHARGE",m_hATMActivity.getAMT_SURCHARGE(),false,"+");
      m_hTable.set("TRAN_COUNT",m_hATMActivity.getTRAN_COUNT(),false,"+");
      m_hTable.set("ITEM_VALUE",m_hATMActivity.getITEM_VALUE());
      m_hTable.set("ITEM_COUNT",m_hATMActivity.getITEM_COUNT());
      m_hTable.set("CUR_TYPE",m_hATMActivity.getCUR_TYPE());
      updateActivity();
      return;
   }
   if (m_hQuery[1].getIndex() == 6)
   {
      // adjust cassettes_end using 583, 584 and 585 amounts
      if (m_hATMActivity.getACTIVITY_GROUP() == atm::ATMActivity::CASH_SUBTRACT)
      {
         if (m_hATMActivity.getACTIVITY_TYPE() != atm::ATMActivity::DEVICE)
            m_hATMEvent[0].setCASSETTEn_END(m_hATMActivity.getACTIVITY_TYPE() - 11,0 - m_hATMActivity.getAMT_RECON_NET());
      }
      else
      if (m_hATMEvent[0].getFUNCTION_CODE() == "585")
      {
         if (m_hATMActivity.getACTIVITY_TYPE() == atm::ATMActivity::DEVICE)
            m_hATMEvent[0].setCASSETTES_END(m_hATMActivity.getAMT_RECON_NET());
         else
         {
            m_hATMEvent[0].setCASSETTEn_END(m_hATMActivity.getACTIVITY_TYPE() - 11,m_hATMActivity.getAMT_RECON_NET());
            m_c585[m_hATMActivity.getACTIVITY_TYPE() - 11] = 'Y';
         }
         cashReplace();
      }
      else
      {
         if (m_hATMActivity.getACTIVITY_TYPE() == atm::ATMActivity::DEVICE)
            m_hATMEvent[0].setCASSETTES_END(m_hATMEvent[0].getCASSETTES_BEGIN() + m_hATMActivity.getAMT_RECON_NET());
         else
            m_hATMEvent[0].setCASSETTEn_END(m_hATMActivity.getACTIVITY_TYPE() - 11,m_hATMActivity.getAMT_RECON_NET());
      }
      if (m_hATMActivity.getACTIVITY_TYPE() != atm::ATMActivity::DEVICE
         && m_hATMActivity.getITEM_VALUE() != 0)
      {
         m_hATMEvent[0].setCASSETTEn_CUR_CODE(m_hATMActivity.getACTIVITY_TYPE() - 11,m_hATMActivity.getCUR_RECON_NET());
         m_hATMEvent[0].setCASSETTEn_CUR_TYPE(m_hATMActivity.getACTIVITY_TYPE() - 11,m_hATMActivity.getCUR_TYPE());
         m_hATMEvent[0].setCASSETTEn_VALUE(m_hATMActivity.getACTIVITY_TYPE() - 11,m_hATMActivity.getITEM_VALUE());
      }
      ATMLog::instance()->applyTo998(m_hATMEvent[0],m_hATMActivity);
      return;
   }
   if (m_hQuery[1].getIndex() == 7)
   {
      m_hTable.set("ACTIVITY_GROUP",(int)atm::ATMActivity::DEPOSIT_SWEEP,true);
      m_hTable.set("ACTIVITY_TYPE",m_hATMActivity.getACTIVITY_TYPE(),true);
      m_hTable.set("TRAN_DISPOSITION",m_hATMActivity.getTRAN_DISPOSITION(),false,true);
      m_hTable.set("IMPACT_TO_ACQ",m_hATMActivity.getIMPACT_TO_ACQ());
      m_hTable.set("CUR_RECON_NET",m_hATMActivity.getCUR_RECON_NET());
      m_hTable.set("AMT_RECON_NET",m_hATMActivity.getAMT_RECON_NET(),false,"+");
      m_hTable.set("AMT_SURCHARGE",m_hATMActivity.getAMT_SURCHARGE(),false,"+");
      m_hTable.set("TRAN_COUNT",m_hATMActivity.getTRAN_COUNT(),false,"+");
      m_hTable.set("ITEM_VALUE",m_hATMActivity.getITEM_VALUE());
      m_hTable.set("ITEM_COUNT",m_hATMActivity.getITEM_COUNT());
      m_hTable.set("CUR_TYPE",m_hATMActivity.getCUR_TYPE());
      updateActivity();
      return;
   }
   if (m_hQuery[1].getIndex() == 9)
   {
      updateAdmin();
      return;
   }
   if (m_hQuery[1].getIndex() == 10)
   {
      if (m_hATMActivity.getACTIVITY_GROUP() == atm::ATMActivity::CASH_ADD)
         m_hATMActivity.setACTIVITY_GROUP(atm::ATMActivity::CASH_SUBTRACT);
      else
         m_hATMActivity.setACTIVITY_GROUP(atm::ATMActivity::CASH_ADD);
      ATMLog::instance()->applyTo998(m_hATMEvent[0],m_hATMActivity);
      return;
   }
   if (m_hQuery[1].getIndex() == 11)
   {
      if (m_hATMActivity.getACTIVITY_GROUP() != 300
         && m_hATMActivity.getACTIVITY_GROUP() != 400)
         m_hQuery[1].setAbort(true);
      else
         m_vATMActivity.push_back(m_hATMActivity);
      return;
   }
   updateTransaction();
  //## end atm::ATMMediator::update%5C50A3FA035C.body
}

bool ATMMediator::updateActivity ()
{
  //## begin atm::ATMMediator::updateActivity%5C617E110398.body preserve=yes
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if (!pUpdateStatement->execute(m_hTable))
   {
      if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      {
         auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         if (!pInsertStatement->execute(m_hTable))
            m_hQuery[1].setAbort(true);
      }
      else
         m_hQuery[1].setAbort(true);
   }
   return !m_hQuery[1].getAbort();
  //## end atm::ATMMediator::updateActivity%5C617E110398.body
}

void ATMMediator::updateAdmin ()
{
  //## begin atm::ATMMediator::updateAdmin%5DE92DD80035.body preserve=yes
   if (m_hAdminMessage.getFUNCTION_CODE() == "584"
      && (m_hAdminMessage.getCLERK_ID().empty()
      || m_hAdminMessage.getCLERK_ID()[0] != 'T'))
      return;
   m_hAdminMessage.setActivity(m_hTable);
   updateActivity();
   if (m_hATMEvent[0].getFUNCTION_CODE() == "572"
      || m_hATMEvent[0].getFUNCTION_CODE() == "ATM"
      || m_hATMEvent[0].getFUNCTION_CODE() == "AUT"
      || m_hATMEvent[0].getFUNCTION_CODE() == "RMT")
   {
      // add activity to settled
      m_hTable.set("ACTIVITY_GROUP",(int)atm::ATMActivity::TERMINAL_SETTLE_ONUS,true);
      updateActivity();
      updateAdminCassettes();
   }
   else
   if (m_hATMEvent[0].getFUNCTION_CODE() == "585"
      && m_hATMActivity.getACTIVITY_TYPE() == atm::ATMActivity::DEVICE
      && m_hATMTransaction.getACTIVITY_TYPE() == atm::ATMActivity::TELLER_WITHDRAWAL)
   {
      // subtract from cash subtract : device if withdrawal
      m_hTable.set("ACTIVITY_GROUP",(int)atm::ATMActivity::CASH_SUBTRACT,true);
      m_hTable.set("ACTIVITY_TYPE",(int)atm::ATMActivity::DEVICE,true);
      m_hTable.set("TRAN_DISPOSITION","1",false,true);
      m_hTable.set("IMPACT_TO_ACQ"," ");
      m_hTable.set("AMT_RECON_NET",m_hAdminMessage.getDEVICE_AMT(),false,"-");
      m_hTable.set("AMT_SURCHARGE",(int)0);
      m_hTable.set("TRAN_COUNT",(int)0);
      m_hTable.set("ITEM_VALUE",(int)0);
      m_hTable.set("ITEM_COUNT",(int)0);
      m_hTable.set("CUR_TYPE",(int)1);
      updateActivity();
   }
   else
   if (m_hATMEvent[0].getFUNCTION_CODE() == "999")
   {
      // add activity to suspense
      m_hTable.set("ACTIVITY_GROUP",(int)atm::ATMActivity::EOD_SUSPENSE_ONUS,true);
      updateActivity();
      updateAdminCassettes();
   }
   m_hTable.set("ACTIVITY_GROUP",(int)atm::ATMActivity::ACTIVITY_ONUS,true);
   updateAdminCassettes();
   if (m_hATMEvent[0].getFUNCTION_CODE() == "585"
      && m_hATMActivity.getACTIVITY_TYPE() != atm::ATMActivity::DEVICE
      && m_hATMTransaction.getACTIVITY_TYPE() == atm::ATMActivity::WITHDRAWAL)
   {
      int i = (int)m_hATMActivity.getACTIVITY_TYPE() - 11;
      if (m_hAdminMessage.getITEM_VALUE(i + atm::ATMTransaction::CASSETTE1) > 0)
      {
         // subtract from cash subtract : cassette if withdrawal
         m_hTable.set("ACTIVITY_GROUP",(int)atm::ATMActivity::CASH_SUBTRACT,true);
         m_hTable.set("ACTIVITY_TYPE",m_hATMActivity.getACTIVITY_TYPE(),true);
         m_hTable.set("TRAN_DISPOSITION","1",false,true);
         m_hTable.set("IMPACT_TO_ACQ"," ");
         if (m_hATMTransaction.getTRAN_DISPOSITION() == "1")
            m_hTable.set("AMT_RECON_NET",m_hAdminMessage.getDEVICE_AMT(),false,"-");
         else
            m_hTable.set("AMT_RECON_NET",m_hAdminMessage.getDEVICE_AMT(),false,"+");
         m_hTable.set("AMT_SURCHARGE",(int)0);
         m_hTable.set("TRAN_COUNT",(int)0);
         m_hTable.set("ITEM_VALUE",(int)0);
         m_hTable.set("ITEM_COUNT",(int)0);
         m_hTable.set("CUR_TYPE",(int)1);
         updateActivity();
      }
   }
  //## end atm::ATMMediator::updateAdmin%5DE92DD80035.body
}

void ATMMediator::updateAdminCassettes ()
{
  //## begin atm::ATMMediator::updateAdminCassettes%5DE92F2600ED.body preserve=yes
   m_hTable.set("TRAN_DISPOSITION"," ",false,true);
   m_hTable.set("IMPACT_TO_ACQ",string(" "));
   m_hTable.set("AMT_SURCHARGE",(double)0);
   m_hTable.set("TRAN_COUNT",(int)0);
   for (int i = 0;i < 8;++i)
      if (m_hAdminMessage.getITEM_VALUE(i + atm::AdminMessage::CASSETTE1) > 0
         && m_hAdminMessage.getITEM_COUNT(i + atm::AdminMessage::CASSETTE1) > 0)
      {
         m_hTable.set("ACTIVITY_TYPE",i + 81,true);
         m_hTable.set("AMT_RECON_NET",m_hAdminMessage.getCredit(i + atm::AdminMessage::CASSETTE1) - m_hAdminMessage.getDebit(i + atm::AdminMessage::CASSETTE1),false,"+");
         m_hTable.set("ITEM_VALUE",m_hAdminMessage.getITEM_VALUE(i + atm::AdminMessage::CASSETTE1));
         m_hTable.set("ITEM_COUNT",m_hAdminMessage.getITEM_COUNT(i + atm::AdminMessage::CASSETTE1),false,"+");
         m_hTable.set("CUR_TYPE",m_hAdminMessage.getCUR_TYPE(i + atm::AdminMessage::CASSETTE1));
         updateActivity();
      }
  //## end atm::ATMMediator::updateAdminCassettes%5DE92F2600ED.body
}

void ATMMediator::updateTransaction ()
{
  //## begin atm::ATMMediator::updateTransaction%5DE92DD900B4.body preserve=yes
   m_hATMTransaction.setActivity(m_hQuery[1].getIndex(),m_hTable,&m_hATMEvent[0]);
   updateActivity();
   if (m_hATMEvent[0].getFUNCTION_CODE() == "572"
      || m_hATMEvent[0].getFUNCTION_CODE() == "ATM"
      || m_hATMEvent[0].getFUNCTION_CODE() == "AUT"
      || m_hATMEvent[0].getFUNCTION_CODE() == "RMT")
   {
      // add activity to settled
      m_hTable.set("ACTIVITY_GROUP",m_hATMTransaction.getACTIVITY_GROUP() == atm::ATMActivity::ACTIVITY_ONUS ? (int)atm::ATMActivity::TERMINAL_SETTLE_ONUS : (int)atm::ATMActivity::TERMINAL_SETTLE_FOREIGN,true);
      updateActivity();
      updateTransactionCassettes();
   }
   else
   if (m_hATMEvent[0].getFUNCTION_CODE() == "585"
      && m_hATMActivity.getACTIVITY_TYPE() == atm::ATMActivity::DEVICE
      && m_hATMTransaction.getACTIVITY_TYPE() == atm::ATMActivity::WITHDRAWAL)
   {
      // subtract from cash subtract : device if withdrawal
      m_hTable.set("ACTIVITY_GROUP",(int)atm::ATMActivity::CASH_SUBTRACT,true);
      m_hTable.set("ACTIVITY_TYPE",(int)atm::ATMActivity::DEVICE,true);
      m_hTable.set("TRAN_DISPOSITION","1",false,true);
      m_hTable.set("IMPACT_TO_ACQ"," ");
      if (m_hATMTransaction.getTRAN_DISPOSITION() == "1")
         m_hTable.set("AMT_RECON_NET",m_hATMTransaction.getAMT_RECON_NET(),false,"-");
      else
         m_hTable.set("AMT_RECON_NET",m_hATMTransaction.getAMT_RECON_NET(),false,"+");
      m_hTable.set("AMT_SURCHARGE",(int)0);
      m_hTable.set("TRAN_COUNT",(int)0);
      m_hTable.set("ITEM_VALUE",(int)0);
      m_hTable.set("ITEM_COUNT",(int)0);
      m_hTable.set("CUR_TYPE",(int)1);
      updateActivity();
   }
   else
   if (m_hATMEvent[0].getFUNCTION_CODE() == "999")
   {
      // add activity to suspense
      m_hTable.set("ACTIVITY_GROUP",m_hATMTransaction.getACTIVITY_GROUP() == (int)atm::ATMActivity::ACTIVITY_ONUS ? (int)atm::ATMActivity::EOD_SUSPENSE_ONUS : (int)atm::ATMActivity::EOD_SUSPENSE_FOREIGN,true);
      updateActivity();
      updateTransactionCassettes();
   }
   m_hTable.set("ACTIVITY_GROUP",m_hATMTransaction.getACTIVITY_GROUP(),true);
   updateTransactionCassettes();
   if (m_hATMEvent[0].getFUNCTION_CODE() == "585"
      && m_hATMActivity.getACTIVITY_TYPE() != atm::ATMActivity::DEVICE
      && m_hATMTransaction.getACTIVITY_TYPE() == atm::ATMActivity::WITHDRAWAL)
   {
      for (int i = 0;i < 8;++i)
      {
         if (m_c585[i] == 'Y'
            && m_hATMTransaction.getCAN_ITEM_VALUEn(i) > 0)
         {
            // subtract from cash subtract : cassette if withdrawal
            m_hTable.set("ACTIVITY_GROUP",(int)atm::ATMActivity::CASH_SUBTRACT,true);
            m_hTable.set("ACTIVITY_TYPE",i + 11,true);
            m_hTable.set("TRAN_DISPOSITION","1",false,true);
            m_hTable.set("IMPACT_TO_ACQ"," ");
            if (m_hATMTransaction.getTRAN_DISPOSITION() == "1")
            {
               double d = m_hATMTransaction.getCAN_ITEM_VALUEn(i) * m_hATMTransaction.getCAN_NO_ITEMS_DISPn(i);
               m_hTable.set("AMT_RECON_NET",d,false,"-");
            }
            else
            {
               double d = (m_hATMTransaction.getCAN_ORIG_NO_ITEMSn(i) - m_hATMTransaction.getCAN_NO_ITEMS_DISPn(i)) * m_hATMTransaction.getCAN_ITEM_VALUEn(i);
               m_hTable.set("AMT_RECON_NET",d,false,"+");
            }
            m_hTable.set("AMT_SURCHARGE",(int)0);
            m_hTable.set("TRAN_COUNT",(int)0);
            m_hTable.set("ITEM_VALUE",(int)0);
            m_hTable.set("ITEM_COUNT",(int)0);
            m_hTable.set("CUR_TYPE",(int)1);
            updateActivity();
         }
      }
   }
  //## end atm::ATMMediator::updateTransaction%5DE92DD900B4.body
}

void ATMMediator::updateTransactionCassettes ()
{
  //## begin atm::ATMMediator::updateTransactionCassettes%5DDE903F03BD.body preserve=yes
   m_hTable.set("TRAN_DISPOSITION"," ",false,true);
   m_hTable.set("IMPACT_TO_ACQ",string(" "));
   m_hTable.set("AMT_SURCHARGE",(double)0);
   m_hTable.set("TRAN_COUNT",(int)0);
   for (int i = 0;i < 8;++i)
      if (m_hATMTransaction.getITEM_VALUE(i + atm::ATMTransaction::CASSETTE1) > 0)
      {
         m_hTable.set("ACTIVITY_TYPE",i + 11,true);
         m_hTable.set("AMT_RECON_NET",m_hATMTransaction.getCredit(i + atm::ATMTransaction::CASSETTE1) - m_hATMTransaction.getDebit(i + atm::ATMTransaction::CASSETTE1),false,"+");
         m_hTable.set("ITEM_VALUE",m_hATMTransaction.getITEM_VALUE(i + atm::ATMTransaction::CASSETTE1));
         m_hTable.set("ITEM_COUNT",m_hATMTransaction.getITEM_COUNT(i + atm::ATMTransaction::CASSETTE1),false,"+");
         m_hTable.set("CUR_TYPE",m_hATMTransaction.getCUR_TYPE(i + atm::ATMTransaction::CASSETTE1));
         updateActivity();
      }
  //## end atm::ATMMediator::updateTransactionCassettes%5DDE903F03BD.body
}

// Additional Declarations
  //## begin atm::ATMMediator%5C50A3130199.declarations preserve=yes
  //## end atm::ATMMediator%5C50A3130199.declarations

} // namespace atm

//## begin module%5C50A39601B8.epilog preserve=yes
//## end module%5C50A39601B8.epilog
