//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5E79FB6000EC.cm preserve=no
//## end module%5E79FB6000EC.cm

//## begin module%5E79FB6000EC.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5E79FB6000EC.cp

//## Module: CXOSAT13%5E79FB6000EC; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Atdll\CXODAT13.hpp

#ifndef CXOSAT13_h
#define CXOSAT13_h 1

//## begin module%5E79FB6000EC.additionalIncludes preserve=no
//## end module%5E79FB6000EC.additionalIncludes

//## begin module%5E79FB6000EC.includes preserve=yes
//## end module%5E79FB6000EC.includes

#ifndef CXOSDB43_h
#include "CXODDB43.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class HourAlarm;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%5E79FB6000EC.declarations preserve=no
//## end module%5E79FB6000EC.declarations

//## begin module%5E79FB6000EC.additionalDeclarations preserve=yes
//## end module%5E79FB6000EC.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::TerminalSet%5E796FF40390.preface preserve=yes
//## end atm::TerminalSet%5E796FF40390.preface

//## Class: TerminalSet%5E796FF40390
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5E79723802EE;reusable::Query { -> F}
//## Uses: <unnamed>%5E79723C02BE;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5E7972400352;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5E7A018C0033;process::Application { -> F}
//## Uses: <unnamed>%5E7A55130170;timer::HourAlarm { -> F}

class DllExport TerminalSet : public database::Cache  //## Inherits: <unnamed>%5E79701302D7
{
  //## begin atm::TerminalSet%5E796FF40390.initialDeclarations preserve=yes
  //## end atm::TerminalSet%5E796FF40390.initialDeclarations

  public:
    //## Constructors (generated)
      TerminalSet();

    //## Destructor (generated)
      virtual ~TerminalSet();


    //## Other Operations (specified)
      //## Operation: instance%5E79704B027E
      static TerminalSet* instance ();

      //## Operation: load%5E79701F0340
      virtual bool load ();

      //## Operation: update%5E79725D0173
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: NET_TERM_ID%5E79726C03E2
      const string& getNET_TERM_ID () const
      {
        //## begin atm::TerminalSet::getNET_TERM_ID%5E79726C03E2.get preserve=no
        return m_strNET_TERM_ID;
        //## end atm::TerminalSet::getNET_TERM_ID%5E79726C03E2.get
      }


      //## Attribute: NET_TERM_IDs%62A83B350098
      vector<string>& getNET_TERM_IDs ()
      {
        //## begin atm::TerminalSet::getNET_TERM_IDs%62A83B350098.get preserve=no
        return m_hNET_TERM_IDs;
        //## end atm::TerminalSet::getNET_TERM_IDs%62A83B350098.get
      }


    // Additional Public Declarations
      //## begin atm::TerminalSet%5E796FF40390.public preserve=yes
      //## end atm::TerminalSet%5E796FF40390.public

  protected:
    // Additional Protected Declarations
      //## begin atm::TerminalSet%5E796FF40390.protected preserve=yes
      //## end atm::TerminalSet%5E796FF40390.protected

  private:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ENTITY_ID%5E7A08040123
      const string& getENTITY_ID () const
      {
        //## begin atm::TerminalSet::getENTITY_ID%5E7A08040123.get preserve=no
        return m_strENTITY_ID;
        //## end atm::TerminalSet::getENTITY_ID%5E7A08040123.get
      }


    // Additional Private Declarations
      //## begin atm::TerminalSet%5E796FF40390.private preserve=yes
      //## end atm::TerminalSet%5E796FF40390.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin atm::TerminalSet::ENTITY_ID%5E7A08040123.attr preserve=no  private: string {V} 
      string m_strENTITY_ID;
      //## end atm::TerminalSet::ENTITY_ID%5E7A08040123.attr

      //## Attribute: Instance%5E7970300117
      //## begin atm::TerminalSet::Instance%5E7970300117.attr preserve=no  private: static TerminalSet* {V} 0
      static TerminalSet* m_pInstance;
      //## end atm::TerminalSet::Instance%5E7970300117.attr

      //## begin atm::TerminalSet::NET_TERM_ID%5E79726C03E2.attr preserve=no  public: string {V} 
      string m_strNET_TERM_ID;
      //## end atm::TerminalSet::NET_TERM_ID%5E79726C03E2.attr

      //## Attribute: Count%62A83AFB0186
      //## begin atm::TerminalSet::Count%62A83AFB0186.attr preserve=no  private: int {U} 0
      int m_iCount;
      //## end atm::TerminalSet::Count%62A83AFB0186.attr

      //## begin atm::TerminalSet::NET_TERM_IDs%62A83B350098.attr preserve=no  public: vector<string> {U} 
      vector<string> m_hNET_TERM_IDs;
      //## end atm::TerminalSet::NET_TERM_IDs%62A83B350098.attr

    // Additional Implementation Declarations
      //## begin atm::TerminalSet%5E796FF40390.implementation preserve=yes
      //## end atm::TerminalSet%5E796FF40390.implementation

};

//## begin atm::TerminalSet%5E796FF40390.postscript preserve=yes
//## end atm::TerminalSet%5E796FF40390.postscript

} // namespace atm

//## begin module%5E79FB6000EC.epilog preserve=yes
//## end module%5E79FB6000EC.epilog


#endif
