//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5DE7AD38035D.cm preserve=no
//	$Date:   Mar 12 2021 10:59:46  $ $Author:   e1009839  $
//	$Revision:   1.3  $
//## end module%5DE7AD38035D.cm

//## begin module%5DE7AD38035D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5DE7AD38035D.cp

//## Module: CXOSAT12%5DE7AD38035D; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV03.1B.R001\Windows\Build\Dn\Server\Library\Atdll\CXODAT12.hpp

#ifndef CXOSAT12_h
#define CXOSAT12_h 1

//## begin module%5DE7AD38035D.additionalIncludes preserve=no
//## end module%5DE7AD38035D.additionalIncludes

//## begin module%5DE7AD38035D.includes preserve=yes
//## end module%5DE7AD38035D.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSAT03_h
#include "CXODAT03.hpp"
#endif

//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
class ATMTransaction;
class ATMInstitution;
class ATMEvent;
class Hierarchy;
class AdminMessage;
} // namespace atm

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;

} // namespace segment

//## begin module%5DE7AD38035D.declarations preserve=no
//## end module%5DE7AD38035D.declarations

//## begin module%5DE7AD38035D.additionalDeclarations preserve=yes
//## end module%5DE7AD38035D.additionalDeclarations


namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::ATMLog%5DE7AC130214.preface preserve=yes
//## end atm::ATMLog%5DE7AC130214.preface

//## Class: ATMLog%5DE7AC130214
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5DE7AE1503D1;ATMTransaction { -> F}
//## Uses: <unnamed>%5DE7AE30019A;Hierarchy { -> F}
//## Uses: <unnamed>%5DE7AE440222;reusable::Table { -> F}
//## Uses: <unnamed>%5DE7AE5403A9;reusable::Statement { -> F}
//## Uses: <unnamed>%5DE7AE580123;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5DE7AEB00012;ATMEvent { -> F}
//## Uses: <unnamed>%5DE7AEDD0070;AdminMessage { -> F}
//## Uses: <unnamed>%5DE7AF590132;segment::InformationSegment { -> F}
//## Uses: <unnamed>%5DE7AF990092;ATMInstitution { -> F}
//## Uses: <unnamed>%5DE7AFBE011F;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%5DE7AFF600E2;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%5FA9DF7A0330;reusable::Query { -> F}
//## Uses: <unnamed>%5FA9DF7E03DA;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5FA9E06800E3;IF::Extract { -> F}
//## Uses: <unnamed>%604B8BD30169;timer::Date { -> F}

class DllExport ATMLog : public reusable::Object  //## Inherits: <unnamed>%5DE7AC6D024A
{
  //## begin atm::ATMLog%5DE7AC130214.initialDeclarations preserve=yes
  //## end atm::ATMLog%5DE7AC130214.initialDeclarations

  public:
    //## Constructors (generated)
      ATMLog();

    //## Destructor (generated)
      virtual ~ATMLog();


    //## Other Operations (specified)
      //## Operation: add%5DE7AC8903A8
      bool add (const reusable::string& strNET_TERM_ID, const reusable::string& strDATE_RECON_ACQ, ATMTransaction& hATMTransaction);

      //## Operation: apply%5DE7AC9B02D0
      bool apply (const atm::AdminMessage& hAdminMessage);

      //## Operation: applyTo998%5DF118710157
      bool applyTo998 (const atm::AdminMessage& hAdminMessage, const reusable::string& strDATE_RECON_ACQ);

      //## Operation: applyTo998%5EFB3D290029
      bool applyTo998 (const atm::ATMEvent& hATMEvent, const atm::ATMActivity& hATMActivity);

      //## Operation: instance%5DE7AC9F01F7
      static ATMLog* instance ();

    // Additional Public Declarations
      //## begin atm::ATMLog%5DE7AC130214.public preserve=yes
      //## end atm::ATMLog%5DE7AC130214.public

  protected:
    // Additional Protected Declarations
      //## begin atm::ATMLog%5DE7AC130214.protected preserve=yes
      //## end atm::ATMLog%5DE7AC130214.protected

  private:
    // Additional Private Declarations
      //## begin atm::ATMLog%5DE7AC130214.private preserve=yes
      //## end atm::ATMLog%5DE7AC130214.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5DE7AC81025B
      //## begin atm::ATMLog::Instance%5DE7AC81025B.attr preserve=no  private: static ATMLog* {V} 0
      static ATMLog* m_pInstance;
      //## end atm::ATMLog::Instance%5DE7AC81025B.attr

    // Data Members for Associations

      //## Association: Totals Management::ATM_CAT::<unnamed>%5DF39FD90285
      //## Role: ATMLog::<m_hATMActivity>%5DF39FDA0111
      //## begin atm::ATMLog::<m_hATMActivity>%5DF39FDA0111.role preserve=no  public: atm::ATMActivity { -> VHgN}
      ATMActivity m_hATMActivity;
      //## end atm::ATMLog::<m_hATMActivity>%5DF39FDA0111.role

    // Additional Implementation Declarations
      //## begin atm::ATMLog%5DE7AC130214.implementation preserve=yes
      //## end atm::ATMLog%5DE7AC130214.implementation

};

//## begin atm::ATMLog%5DE7AC130214.postscript preserve=yes
//## end atm::ATMLog%5DE7AC130214.postscript

} // namespace atm

//## begin module%5DE7AD38035D.epilog preserve=yes
//## end module%5DE7AD38035D.epilog


#endif
