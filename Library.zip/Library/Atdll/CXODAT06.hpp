//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C50A39400C0.cm preserve=no
//	$Date:   May 25 2021 14:20:48  $ $Author:   e1009839  $
//	$Revision:   1.12  $
//## end module%5C50A39400C0.cm

//## begin module%5C50A39400C0.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C50A39400C0.cp

//## Module: CXOSAT06%5C50A39400C0; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Atdll\CXODAT06.hpp

#ifndef CXOSAT06_h
#define CXOSAT06_h 1

//## begin module%5C50A39400C0.additionalIncludes preserve=no
//## end module%5C50A39400C0.additionalIncludes

//## begin module%5C50A39400C0.includes preserve=yes
#include <vector>
//## end module%5C50A39400C0.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSAT09_h
#include "CXODAT09.hpp"
#endif
#ifndef CXOSAT07_h
#include "CXODAT07.hpp"
#endif
#ifndef CXOSAT03_h
#include "CXODAT03.hpp"
#endif
#ifndef CXOSAT02_h
#include "CXODAT02.hpp"
#endif

//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
class Reconciliation;
class TerminalSet;
class ATMLog;
class ATMInstitution;
} // namespace atm

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class FormatSelectVisitor;
class CriticalSection;
class SearchCondition;
class Statement;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

namespace database {
class SwitchClock;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;

} // namespace segment

//## begin module%5C50A39400C0.declarations preserve=no
//## end module%5C50A39400C0.declarations

//## begin module%5C50A39400C0.additionalDeclarations preserve=yes
//## end module%5C50A39400C0.additionalDeclarations


namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::ATMMediator%5C50A3130199.preface preserve=yes
//## end atm::ATMMediator%5C50A3130199.preface

//## Class: ATMMediator%5C50A3130199
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5C50A6230287;monitor::UseCase { -> F}
//## Uses: <unnamed>%5C50A72C0224;database::SwitchClock { -> F}
//## Uses: <unnamed>%5C50B17102FD;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%5C51117301E1;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%5C5B165F0097;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5C5B16620210;reusable::Statement { -> F}
//## Uses: <unnamed>%5C5B1743008D;reusable::SearchCondition { -> F}
//## Uses: <unnamed>%5C5B17CF013E;reusable::Table { -> F}
//## Uses: <unnamed>%5C5B18660385;segment::InformationSegment { -> F}
//## Uses: <unnamed>%5C5B3EF001E6;ATMEvent { -> F}
//## Uses: <unnamed>%5C5B403902EA;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5C5B4A8902A6;database::Database { -> F}
//## Uses: <unnamed>%5C617A4E0230;timer::Date { -> F}
//## Uses: <unnamed>%5C656C9F0305;ATMInstitution { -> F}
//## Uses: <unnamed>%5D3856BB02DA;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%5D65ED830078;process::Application { -> F}
//## Uses: <unnamed>%5DA48122020E;timer::Clock { -> F}
//## Uses: <unnamed>%5DA4D5500367;IF::Extract { -> F}
//## Uses: <unnamed>%604B8EA700E0;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%604B8EEB0261;ATMLog { -> F}
//## Uses: <unnamed>%604B8EF000B2;TerminalSet { -> F}
//## Uses: <unnamed>%604B8F1202DB;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%604B8F450363;reusable::FormatSelectVisitor { -> F}
//## Uses: <unnamed>%60ACF1AB0264;Reconciliation { -> F}

class DllExport ATMMediator : public reusable::Observer  //## Inherits: <unnamed>%5C511983020E
{
  //## begin atm::ATMMediator%5C50A3130199.initialDeclarations preserve=yes
  //## end atm::ATMMediator%5C50A3130199.initialDeclarations

  public:
    //## Constructors (generated)
      ATMMediator();

    //## Destructor (generated)
      virtual ~ATMMediator();


    //## Other Operations (specified)
      //## Operation: reset%5C50AF1700C9
      bool reset (bool bMT, bool bPrimary);

      //## Operation: total%5C50A49601F8
      bool total ();

      //## Operation: update%5C50A3FA035C
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin atm::ATMMediator%5C50A3130199.public preserve=yes
      //## end atm::ATMMediator%5C50A3130199.public

  protected:
    // Additional Protected Declarations
      //## begin atm::ATMMediator%5C50A3130199.protected preserve=yes
      //## end atm::ATMMediator%5C50A3130199.protected

  private:

    //## Other Operations (specified)
      //## Operation: age%5D6698430026
      void age ();

      //## Operation: cashAddSubtractReplace%5C646D02025D
      bool cashAddSubtractReplace ();

      //## Operation: cashReplace%5C646CD401FA
      bool cashReplace ();

      //## Operation: depositSweep%5C644FD302C5
      bool depositSweep ();

      //## Operation: getWaitingEvents%5E79610400B7
      bool getWaitingEvents ();

      //## Operation: retrieve%5C5C336503DD
      bool retrieve (short siIndex);

      //## Operation: retrieveTeller%5DE8151E03B8
      bool retrieveTeller ();

      //## Operation: setState%5C5C30270216
      bool setState (const char* pszAE_STATE);

      //## Operation: settle%5C646F6E000A
      bool settle ();

      //## Operation: updateActivity%5C617E110398
      bool updateActivity ();

      //## Operation: updateAdmin%5DE92DD80035
      void updateAdmin ();

      //## Operation: updateAdminCassettes%5DE92F2600ED
      void updateAdminCassettes ();

      //## Operation: updateTransaction%5DE92DD900B4
      void updateTransaction ();

      //## Operation: updateTransactionCassettes%5DDE903F03BD
      void updateTransactionCassettes ();

    // Additional Private Declarations
      //## begin atm::ATMMediator%5C50A3130199.private preserve=yes
      //## end atm::ATMMediator%5C50A3130199.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: c585%604B8FF7037A
      //## begin atm::ATMMediator::c585%604B8FF7037A.attr preserve=no  private: char[8] {V} 
      char m_c585[8];
      //## end atm::ATMMediator::c585%604B8FF7037A.attr

      //## Attribute: Date%5E7A18340390
      //## begin atm::ATMMediator::Date%5E7A18340390.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strDate;
      //## end atm::ATMMediator::Date%5E7A18340390.attr

      //## Attribute: Days%5DA4D5F20077
      //## begin atm::ATMMediator::Days%5DA4D5F20077.attr preserve=no  private: int {V} 0
      int m_iDays;
      //## end atm::ATMMediator::Days%5DA4D5F20077.attr

      //## Attribute: Primary%5DA4839B00DB
      //## begin atm::ATMMediator::Primary%5DA4839B00DB.attr preserve=no  private: bool {V} false
      bool m_bPrimary;
      //## end atm::ATMMediator::Primary%5DA4839B00DB.attr

      //## Attribute: Rows%5E15317E0060
      //## begin atm::ATMMediator::Rows%5E15317E0060.attr preserve=no  private: int {V} -1
      int m_iRows;
      //## end atm::ATMMediator::Rows%5E15317E0060.attr

      //## Attribute: TSTAMP_TRANS%5C62E1D7033F
      //## begin atm::ATMMediator::TSTAMP_TRANS%5C62E1D7033F.attr preserve=no  private: reusable::string[2] {V} 
      reusable::string m_strTSTAMP_TRANS[2];
      //## end atm::ATMMediator::TSTAMP_TRANS%5C62E1D7033F.attr

    // Data Members for Associations

      //## Association: Totals Management::ATM_CAT::<unnamed>%5D9DFEF3027B
      //## Role: ATMMediator::<m_hQuery>%5D9DFEF40129
      //## begin atm::ATMMediator::<m_hQuery>%5D9DFEF40129.role preserve=no  public: reusable::Query { -> 2VHgN}
      reusable::Query m_hQuery[2];
      //## end atm::ATMMediator::<m_hQuery>%5D9DFEF40129.role

      //## Association: Totals Management::ATM_CAT::<unnamed>%5DE81E4701A1
      //## Role: ATMMediator::<m_hAdminMessage>%5DE81E4800B0
      //## begin atm::ATMMediator::<m_hAdminMessage>%5DE81E4800B0.role preserve=no  public: atm::AdminMessage { -> VHgN}
      AdminMessage m_hAdminMessage;
      //## end atm::ATMMediator::<m_hAdminMessage>%5DE81E4800B0.role

      //## Association: Totals Management::Settlement_CAT::<unnamed>%5C5C2E30005F
      //## Role: ATMMediator::<m_hATMTransaction>%5C5C2E30032F
      //## begin atm::ATMMediator::<m_hATMTransaction>%5C5C2E30032F.role preserve=no  public: atm::ATMTransaction { -> VHgN}
      ATMTransaction m_hATMTransaction;
      //## end atm::ATMMediator::<m_hATMTransaction>%5C5C2E30032F.role

      //## Association: Totals Management::Settlement_CAT::<unnamed>%5C5C33950288
      //## Role: ATMMediator::<m_hATMEvent>%5C5C33960198
      //## begin atm::ATMMediator::<m_hATMEvent>%5C5C33960198.role preserve=no  public: atm::ATMEvent { -> 3VHgN}
      ATMEvent m_hATMEvent[3];
      //## end atm::ATMMediator::<m_hATMEvent>%5C5C33960198.role

      //## Association: Totals Management::Settlement_CAT::<unnamed>%5C5C4F0B0239
      //## Role: ATMMediator::<m_hTable>%5C5C4F0C027D
      //## begin atm::ATMMediator::<m_hTable>%5C5C4F0C027D.role preserve=no  public: reusable::Table { -> VHgN}
      reusable::Table m_hTable;
      //## end atm::ATMMediator::<m_hTable>%5C5C4F0C027D.role

      //## Association: Totals Management::Settlement_CAT::<unnamed>%5C5C4E9F00DC
      //## Role: ATMMediator::<m_hATMActivity>%5C5C4EA00010
      //## begin atm::ATMMediator::<m_hATMActivity>%5C5C4EA00010.role preserve=no  public: atm::ATMActivity { -> VHgN}
      ATMActivity m_hATMActivity;
      //## end atm::ATMMediator::<m_hATMActivity>%5C5C4EA00010.role

    // Additional Implementation Declarations
      //## begin atm::ATMMediator%5C50A3130199.implementation preserve=yes
      vector<ATMActivity> m_vATMActivity;
      //## end atm::ATMMediator%5C50A3130199.implementation
};

//## begin atm::ATMMediator%5C50A3130199.postscript preserve=yes
//## end atm::ATMMediator%5C50A3130199.postscript

} // namespace atm

//## begin module%5C50A39400C0.epilog preserve=yes
//## end module%5C50A39400C0.epilog


#endif
