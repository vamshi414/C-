//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C50A1AF03A4.cm preserve=no
//	$Date:   Feb 26 2019 16:04:52  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5C50A1AF03A4.cm

//## begin module%5C50A1AF03A4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C50A1AF03A4.cp

//## Module: CXOSAT05%5C50A1AF03A4; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Library\Atdll\CXODAT05.hpp

#ifndef CXOSAT05_h
#define CXOSAT05_h 1

//## begin module%5C50A1AF03A4.additionalIncludes preserve=no
//## end module%5C50A1AF03A4.additionalIncludes

//## begin module%5C50A1AF03A4.includes preserve=yes
//## end module%5C50A1AF03A4.includes

#ifndef CXOSPS10_h
#include "CXODPS10.hpp"
#endif

//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
class ATMMediator;
} // namespace atm

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Sleep;

} // namespace IF

//## begin module%5C50A1AF03A4.declarations preserve=no
//## end module%5C50A1AF03A4.declarations

//## begin module%5C50A1AF03A4.additionalDeclarations preserve=yes
//## end module%5C50A1AF03A4.additionalDeclarations


namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::ATMTotal%5C508A1D018B.preface preserve=yes
//## end atm::ATMTotal%5C508A1D018B.preface

//## Class: ATMTotal%5C508A1D018B
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5C50ABEA03BC;IF::Sleep { -> F}

class DllExport ATMTotal : public process::Thread  //## Inherits: <unnamed>%5C508A3102B6
{
  //## begin atm::ATMTotal%5C508A1D018B.initialDeclarations preserve=yes
  //## end atm::ATMTotal%5C508A1D018B.initialDeclarations

  public:
    //## Constructors (generated)
      ATMTotal();

    //## Destructor (generated)
      virtual ~ATMTotal();


    //## Other Operations (specified)
      //## Operation: initialize%5C50AB5A03B3
      virtual bool initialize ();

      //## Operation: run%5C508A4401B9
      virtual bool run (bool bSleep = true);

    // Additional Public Declarations
      //## begin atm::ATMTotal%5C508A1D018B.public preserve=yes
      //## end atm::ATMTotal%5C508A1D018B.public

  protected:
    // Additional Protected Declarations
      //## begin atm::ATMTotal%5C508A1D018B.protected preserve=yes
      //## end atm::ATMTotal%5C508A1D018B.protected

  private:
    // Additional Private Declarations
      //## begin atm::ATMTotal%5C508A1D018B.private preserve=yes
      //## end atm::ATMTotal%5C508A1D018B.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Totals Management::Settlement_CAT::<unnamed>%5C50AB2703C7
      //## Role: ATMTotal::<m_pATMMediator>%5C50AB280204
      //## begin atm::ATMTotal::<m_pATMMediator>%5C50AB280204.role preserve=no  public: atm::ATMMediator { -> RFHgN}
      ATMMediator *m_pATMMediator;
      //## end atm::ATMTotal::<m_pATMMediator>%5C50AB280204.role

    // Additional Implementation Declarations
      //## begin atm::ATMTotal%5C508A1D018B.implementation preserve=yes
      //## end atm::ATMTotal%5C508A1D018B.implementation

};

//## begin atm::ATMTotal%5C508A1D018B.postscript preserve=yes
//## end atm::ATMTotal%5C508A1D018B.postscript

} // namespace atm

//## begin module%5C50A1AF03A4.epilog preserve=yes
//## end module%5C50A1AF03A4.epilog


#endif
