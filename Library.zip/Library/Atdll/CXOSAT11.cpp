//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5DE689C302F8.cm preserve=no
//	$Date:   Dec 11 2019 09:59:08  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5DE689C302F8.cm

//## begin module%5DE689C302F8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5DE689C302F8.cp

//## Module: CXOSAT11%5DE689C302F8; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Atdll\CXOSAT11.cpp

//## begin module%5DE689C302F8.additionalIncludes preserve=no
//## end module%5DE689C302F8.additionalIncludes

//## begin module%5DE689C302F8.includes preserve=yes
//## end module%5DE689C302F8.includes

#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSAT03_h
#include "CXODAT03.hpp"
#endif
#ifndef CXOSAT02_h
#include "CXODAT02.hpp"
#endif
#ifndef CXOSAT11_h
#include "CXODAT11.hpp"
#endif


//## begin module%5DE689C302F8.declarations preserve=no
//## end module%5DE689C302F8.declarations

//## begin module%5DE689C302F8.additionalDeclarations preserve=yes
//## end module%5DE689C302F8.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::SettlementReportVisitor 

//## begin atm::SettlementReportVisitor::Instance%5DE689AA0095.attr preserve=no  private: static atm::SettlementReportVisitor* {V} 0
atm::SettlementReportVisitor* SettlementReportVisitor::m_pInstance = 0;
//## end atm::SettlementReportVisitor::Instance%5DE689AA0095.attr

SettlementReportVisitor::SettlementReportVisitor()
  //## begin SettlementReportVisitor::SettlementReportVisitor%5DE689280229_const.hasinit preserve=no
  //## end SettlementReportVisitor::SettlementReportVisitor%5DE689280229_const.hasinit
  //## begin SettlementReportVisitor::SettlementReportVisitor%5DE689280229_const.initialization preserve=yes
  //## end SettlementReportVisitor::SettlementReportVisitor%5DE689280229_const.initialization
{
  //## begin atm::SettlementReportVisitor::SettlementReportVisitor%5DE689280229_const.body preserve=yes
   memcpy(m_sID,"AT11",4);
  //## end atm::SettlementReportVisitor::SettlementReportVisitor%5DE689280229_const.body
}


SettlementReportVisitor::~SettlementReportVisitor()
{
  //## begin atm::SettlementReportVisitor::~SettlementReportVisitor%5DE689280229_dest.body preserve=yes
  //## end atm::SettlementReportVisitor::~SettlementReportVisitor%5DE689280229_dest.body
}



//## Other Operations (implementation)
atm::SettlementReportVisitor* SettlementReportVisitor::instance ()
{
  //## begin atm::SettlementReportVisitor::instance%5DE6899E02C3.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new SettlementReportVisitor();
   return m_pInstance;
  //## end atm::SettlementReportVisitor::instance%5DE6899E02C3.body
}

void SettlementReportVisitor::load (const vector<string>& hTemplate)
{
  //## begin atm::SettlementReportVisitor::load%5DE6899E0300.body preserve=yes
   m_hSum.erase(m_hSum.begin(),m_hSum.end());
   char szFirst[4] = {"   "};
   string strSecond;
   for (int i = 0;i < hTemplate.size();++i)
      if (hTemplate[i].length() > 7
         && memcmp(hTemplate[i].data(),"SU ",3) == 0)
      {
         memcpy(szFirst,hTemplate[i].data() + 3,3);
         strSecond.assign(hTemplate[i].data() + 7,hTemplate[i].length() - 7);
         m_hSum.insert(multimap<short,string,less<short> >::value_type(short(atoi(szFirst)),strSecond));
      }
  //## end atm::SettlementReportVisitor::load%5DE6899E0300.body
}

void SettlementReportVisitor::populate (segment::GenericSegment& hGenericSegment)
{
  //## begin atm::SettlementReportVisitor::populate%5DE6899E031A.body preserve=yes
   hGenericSegment.reset();
   hGenericSegment.set("TSTAMP_TRANS",m_strTSTAMP_TRANS);
   char szTRAN_DISPOSITION[4] = {"ADR"};
   for (map<string,vector<double>,less<string> >::iterator pAmount = m_hAmount.begin();pAmount != m_hAmount.end();++pAmount)
      for (int i = 0;i < 3;++i)
         if ((*pAmount).second[i] != 0)
         {
            string strFirst((*pAmount).first);
            strFirst.append(&szTRAN_DISPOSITION[i],1);
            hGenericSegment.set(strFirst.c_str(),(*pAmount).second[i]);
         }
   for (map<string,vector<int>,less<string> >::iterator pCount = m_hCount.begin();pCount != m_hCount.end();++pCount)
      for (int i = 0;i < 3;++i)
         if ((*pCount).second[i] != 0)
         {
            string strFirst((*pCount).first);
            strFirst.append(&szTRAN_DISPOSITION[i],1);
            hGenericSegment.set(strFirst.c_str(),(*pCount).second[i]);
         }
  //## end atm::SettlementReportVisitor::populate%5DE6899E031A.body
}

void SettlementReportVisitor::visitATMActivity (atm::ATMActivity* pATMActivity)
{
  //## begin atm::SettlementReportVisitor::visitATMActivity%5DE6899E032B.body preserve=yes
   pair<multimap<short,string,less<short> >::iterator,multimap<short,string,less<short> >::iterator> hRange = m_hSum.equal_range(pATMActivity->getACTIVITY_GROUP() + pATMActivity->getACTIVITY_TYPE());
   if (hRange.first == hRange.second)
      return;
   for (multimap<short,string,less<short> >::iterator pSum = hRange.first;pSum != hRange.second;++pSum)
   {
      string strFirst((*pSum).second);
      strFirst.append("A",1);
      map<string,vector<int>,less<string> >::iterator pCount;
      map<string,vector<double>,less<string> >::iterator pFee;
      map<string,vector<double>,less<string> >::iterator pAmount = m_hAmount.find(strFirst);
      if (pAmount == m_hAmount.end())
      {
         vector<double> d(3,0);
         pair<map<string,vector<double>,less<string> >::iterator,bool> hResult1 = m_hAmount.insert(map<string,vector<double>,less<string> >::value_type(strFirst,d));
         pAmount = hResult1.first;
         strFirst[strFirst.length() - 1] = 'F';
         hResult1 = m_hAmount.insert(map<string,vector<double>,less<string> >::value_type(strFirst,d));
         pFee = hResult1.first;
         strFirst.resize(strFirst.length() - 1);
         vector<int> i(3,0);
         pair<map<string,vector<int>,less<string> >::iterator,bool> hResult2 = m_hCount.insert(map<string,vector<int>,less<string> >::value_type(strFirst,i));
         pCount = hResult2.first;
      }
      else
      {
         strFirst[strFirst.length() - 1] = 'F';
         pFee = m_hAmount.find(strFirst);
         strFirst.resize(strFirst.length() - 1);
         pCount = m_hCount.find(strFirst);
      }
      int j = atoi(pATMActivity->getTRAN_DISPOSITION().c_str()) - 1;
      if (j >= 0 && j <= 2)
      {
         (*pAmount).second[j] += pATMActivity->getAMT_RECON_NET();
         (*pFee).second[j] += pATMActivity->getAMT_SURCHARGE();
         (*pCount).second[j] += pATMActivity->getTRAN_COUNT();
      }
   }
  //## end atm::SettlementReportVisitor::visitATMActivity%5DE6899E032B.body
}

void SettlementReportVisitor::visitATMEvent (atm::ATMEvent* pATMEvent)
{
  //## begin atm::SettlementReportVisitor::visitATMEvent%5DE6899E033C.body preserve=yes
   m_pATMEvent = pATMEvent;
   m_strTSTAMP_TRANS = pATMEvent->getTSTAMP_TRANS();
   m_hAmount.erase(m_hAmount.begin(),m_hAmount.end());
   m_hCount.erase(m_hCount.begin(),m_hCount.end());
  //## end atm::SettlementReportVisitor::visitATMEvent%5DE6899E033C.body
}

// Additional Declarations
  //## begin atm::SettlementReportVisitor%5DE689280229.declarations preserve=yes
  //## end atm::SettlementReportVisitor%5DE689280229.declarations

} // namespace atm

//## begin module%5DE689C302F8.epilog preserve=yes
//## end module%5DE689C302F8.epilog
