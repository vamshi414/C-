//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C49E9CA03B1.cm preserve=no
//	$Date:   Feb 26 2019 16:04:52  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5C49E9CA03B1.cm

//## begin module%5C49E9CA03B1.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C49E9CA03B1.cp

//## Module: CXOSAT04%5C49E9CA03B1; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Library\Atdll\CXODAT04.hpp

#ifndef CXOSAT04_h
#define CXOSAT04_h 1

//## begin module%5C49E9CA03B1.additionalIncludes preserve=no
//## end module%5C49E9CA03B1.additionalIncludes

//## begin module%5C49E9CA03B1.includes preserve=yes
//## end module%5C49E9CA03B1.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
class ATMEvent;
class ATMBusinessDay;
class ATMActivity;

} // namespace atm

//## begin module%5C49E9CA03B1.declarations preserve=no
//## end module%5C49E9CA03B1.declarations

//## begin module%5C49E9CA03B1.additionalDeclarations preserve=yes
//## end module%5C49E9CA03B1.additionalDeclarations


namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::ATMBusinessDayVisitor%5C49E97C01AB.preface preserve=yes
//## end atm::ATMBusinessDayVisitor%5C49E97C01AB.preface

//## Class: ATMBusinessDayVisitor%5C49E97C01AB
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5C49EB260232;ATMBusinessDay { -> F}
//## Uses: <unnamed>%5C49EB290142;ATMEvent { -> F}
//## Uses: <unnamed>%5C49EB2D020A;ATMActivity { -> F}

class DllExport ATMBusinessDayVisitor : public reusable::Object  //## Inherits: <unnamed>%5C49E993013F
{
  //## begin atm::ATMBusinessDayVisitor%5C49E97C01AB.initialDeclarations preserve=yes
  //## end atm::ATMBusinessDayVisitor%5C49E97C01AB.initialDeclarations

  public:
    //## Constructors (generated)
      ATMBusinessDayVisitor();

    //## Destructor (generated)
      virtual ~ATMBusinessDayVisitor();


    //## Other Operations (specified)
      //## Operation: visitATMActivity%5C49EA780243
      virtual void visitATMActivity (atm::ATMActivity* pATMActivity);

      //## Operation: visitATMBusinessDay%5C49EA4603BC
      virtual void visitATMBusinessDay (atm::ATMBusinessDay* pATMBusinessDay);

      //## Operation: visitATMEvent%5C49EA780188
      virtual void visitATMEvent (atm::ATMEvent* pATMEvent);

    // Additional Public Declarations
      //## begin atm::ATMBusinessDayVisitor%5C49E97C01AB.public preserve=yes
      //## end atm::ATMBusinessDayVisitor%5C49E97C01AB.public

  protected:
    // Additional Protected Declarations
      //## begin atm::ATMBusinessDayVisitor%5C49E97C01AB.protected preserve=yes
      //## end atm::ATMBusinessDayVisitor%5C49E97C01AB.protected

  private:
    // Additional Private Declarations
      //## begin atm::ATMBusinessDayVisitor%5C49E97C01AB.private preserve=yes
      //## end atm::ATMBusinessDayVisitor%5C49E97C01AB.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin atm::ATMBusinessDayVisitor%5C49E97C01AB.implementation preserve=yes
      //## end atm::ATMBusinessDayVisitor%5C49E97C01AB.implementation

};

//## begin atm::ATMBusinessDayVisitor%5C49E97C01AB.postscript preserve=yes
//## end atm::ATMBusinessDayVisitor%5C49E97C01AB.postscript

} // namespace atm

//## begin module%5C49E9CA03B1.epilog preserve=yes
//## end module%5C49E9CA03B1.epilog


#endif
