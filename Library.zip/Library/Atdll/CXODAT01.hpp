//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C49C7E90083.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%5C49C7E90083.cm

//## begin module%5C49C7E90083.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C49C7E90083.cp

//## Module: CXOSAT01%5C49C7E90083; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Atdll\CXODAT01.hpp

#ifndef CXOSAT01_h
#define CXOSAT01_h 1

//## begin module%5C49C7E90083.additionalIncludes preserve=no
//## end module%5C49C7E90083.additionalIncludes

//## begin module%5C49C7E90083.includes preserve=yes
//## end module%5C49C7E90083.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSAT03_h
#include "CXODAT03.hpp"
#endif
#ifndef CXOSAT02_h
#include "CXODAT02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
class ATMBusinessDayVisitor;
} // namespace atm

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class CRDeviceSegment;
class CRInstitutionSegment;
class CRProcessorSegment;
} // namespace entitysegment

namespace reusable {
class SearchCondition;
class Table;
class Statement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;

} // namespace segment

//## begin module%5C49C7E90083.declarations preserve=no
//## end module%5C49C7E90083.declarations

//## begin module%5C49C7E90083.additionalDeclarations preserve=yes
//## end module%5C49C7E90083.additionalDeclarations


namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::ATMBusinessDay%5C49C69101AC.preface preserve=yes
//## end atm::ATMBusinessDay%5C49C69101AC.preface

//## Class: ATMBusinessDay%5C49C69101AC
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5C49EB900346;ATMBusinessDayVisitor { -> F}
//## Uses: <unnamed>%5C4B8AF4025F;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5C4B8AF80130;reusable::Query { -> F}
//## Uses: <unnamed>%5C4F1AEF0208;reusable::Table { -> F}
//## Uses: <unnamed>%5C4F1AFA02A8;reusable::Statement { -> F}
//## Uses: <unnamed>%5C75A7AB00EE;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5C85AB410101;reusable::SearchCondition { -> F}
//## Uses: <unnamed>%5C912FC50176;IF::Extract { -> F}
//## Uses: <unnamed>%5C912FC60386;entitysegment::CRDeviceSegment { -> F}
//## Uses: <unnamed>%5C912FC800D6;entitysegment::CRInstitutionSegment { -> F}
//## Uses: <unnamed>%5C912FCA0006;entitysegment::CRProcessorSegment { -> F}
//## Uses: <unnamed>%5D38559D0384;segment::InformationSegment { -> F}

class DllExport ATMBusinessDay : public reusable::Observer  //## Inherits: <unnamed>%5C49C71B00F1
{
  //## begin atm::ATMBusinessDay%5C49C69101AC.initialDeclarations preserve=yes
  //## end atm::ATMBusinessDay%5C49C69101AC.initialDeclarations

  public:
    //## Constructors (generated)
      ATMBusinessDay();

    //## Destructor (generated)
      virtual ~ATMBusinessDay();


    //## Other Operations (specified)
      //## Operation: accept%5C49EBAD0218
      void accept (atm::ATMBusinessDayVisitor& hATMBusinessDayVisitor);

      //## Operation: getATMEvent%5C49C77C01AC
      atm::ATMEvent* getATMEvent (int iCursor);

      //## Operation: instance%5C49C7A602EC
      static ATMBusinessDay* instance ();

      //## Operation: reset%5C85A0200133
      static bool reset (const reusable::string& strNET_TERM_ID, const reusable::string& strDATE_RECON_ACQ);

      //## Operation: retrieve%5C49C74400DD
      bool retrieve (const reusable::string& strNET_TERM_ID, const reusable::string& strDATE_RECON_ACQ, const char* pszFUNCTION_CODE = 0, const char* pszDATE_RECON_ACQ_end = 0);

      //## Operation: update%5C49C7210240
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin atm::ATMBusinessDay%5C49C69101AC.public preserve=yes
      //## end atm::ATMBusinessDay%5C49C69101AC.public

  protected:
    // Additional Protected Declarations
      //## begin atm::ATMBusinessDay%5C49C69101AC.protected preserve=yes
      //## end atm::ATMBusinessDay%5C49C69101AC.protected

  private:
    // Additional Private Declarations
      //## begin atm::ATMBusinessDay%5C49C69101AC.private preserve=yes
      //## end atm::ATMBusinessDay%5C49C69101AC.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5C49C7B901CA
      //## begin atm::ATMBusinessDay::Instance%5C49C7B901CA.attr preserve=no  private: static ATMBusinessDay* {V} 0
      static ATMBusinessDay* m_pInstance;
      //## end atm::ATMBusinessDay::Instance%5C49C7B901CA.attr

    // Data Members for Associations

      //## Association: Totals Management::TotalsCommand_CAT::<unnamed>%5C4B8BC801B8
      //## Role: ATMBusinessDay::<m_hATMEvent>%5C4B8BC90068
      //## begin atm::ATMBusinessDay::<m_hATMEvent>%5C4B8BC90068.role preserve=no  public: atm::ATMEvent { -> VHgN}
      ATMEvent m_hATMEvent;
      //## end atm::ATMBusinessDay::<m_hATMEvent>%5C4B8BC90068.role

      //## Association: Totals Management::TotalsCommand_CAT::<unnamed>%5C49C6D30064
      //## Role: ATMBusinessDay::<m_hATMEvents>%5C49C6D40081
      //## begin atm::ATMBusinessDay::<m_hATMEvents>%5C49C6D40081.role preserve=no  public: atm::ATMEvent { -> 0..nVHgN}
      vector<ATMEvent> m_hATMEvents;
      //## end atm::ATMBusinessDay::<m_hATMEvents>%5C49C6D40081.role

      //## Association: Totals Management::TotalsCommand_CAT::<unnamed>%5C4B8C26037F
      //## Role: ATMBusinessDay::<m_hATMActivity>%5C4B8C270230
      //## begin atm::ATMBusinessDay::<m_hATMActivity>%5C4B8C270230.role preserve=no  public: atm::ATMActivity { -> VHgN}
      ATMActivity m_hATMActivity;
      //## end atm::ATMBusinessDay::<m_hATMActivity>%5C4B8C270230.role

    // Additional Implementation Declarations
      //## begin atm::ATMBusinessDay%5C49C69101AC.implementation preserve=yes
      //## end atm::ATMBusinessDay%5C49C69101AC.implementation

};

//## begin atm::ATMBusinessDay%5C49C69101AC.postscript preserve=yes
//## end atm::ATMBusinessDay%5C49C69101AC.postscript

} // namespace atm

//## begin module%5C49C7E90083.epilog preserve=yes
//## end module%5C49C7E90083.epilog


#endif
