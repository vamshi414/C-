//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C49E9CD0164.cm preserve=no
//	$Date:   Feb 26 2019 16:05:04  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5C49E9CD0164.cm

//## begin module%5C49E9CD0164.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C49E9CD0164.cp

//## Module: CXOSAT04%5C49E9CD0164; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Library\Atdll\CXOSAT04.cpp

//## begin module%5C49E9CD0164.additionalIncludes preserve=no
//## end module%5C49E9CD0164.additionalIncludes

//## begin module%5C49E9CD0164.includes preserve=yes
//## end module%5C49E9CD0164.includes

#ifndef CXOSAT01_h
#include "CXODAT01.hpp"
#endif
#ifndef CXOSAT02_h
#include "CXODAT02.hpp"
#endif
#ifndef CXOSAT03_h
#include "CXODAT03.hpp"
#endif
#ifndef CXOSAT04_h
#include "CXODAT04.hpp"
#endif


//## begin module%5C49E9CD0164.declarations preserve=no
//## end module%5C49E9CD0164.declarations

//## begin module%5C49E9CD0164.additionalDeclarations preserve=yes
//## end module%5C49E9CD0164.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::ATMBusinessDayVisitor 

ATMBusinessDayVisitor::ATMBusinessDayVisitor()
  //## begin ATMBusinessDayVisitor::ATMBusinessDayVisitor%5C49E97C01AB_const.hasinit preserve=no
  //## end ATMBusinessDayVisitor::ATMBusinessDayVisitor%5C49E97C01AB_const.hasinit
  //## begin ATMBusinessDayVisitor::ATMBusinessDayVisitor%5C49E97C01AB_const.initialization preserve=yes
  //## end ATMBusinessDayVisitor::ATMBusinessDayVisitor%5C49E97C01AB_const.initialization
{
  //## begin atm::ATMBusinessDayVisitor::ATMBusinessDayVisitor%5C49E97C01AB_const.body preserve=yes
  //## end atm::ATMBusinessDayVisitor::ATMBusinessDayVisitor%5C49E97C01AB_const.body
}


ATMBusinessDayVisitor::~ATMBusinessDayVisitor()
{
  //## begin atm::ATMBusinessDayVisitor::~ATMBusinessDayVisitor%5C49E97C01AB_dest.body preserve=yes
  //## end atm::ATMBusinessDayVisitor::~ATMBusinessDayVisitor%5C49E97C01AB_dest.body
}



//## Other Operations (implementation)
void ATMBusinessDayVisitor::visitATMActivity (atm::ATMActivity* pATMActivity)
{
  //## begin atm::ATMBusinessDayVisitor::visitATMActivity%5C49EA780243.body preserve=yes
  //## end atm::ATMBusinessDayVisitor::visitATMActivity%5C49EA780243.body
}

void ATMBusinessDayVisitor::visitATMBusinessDay (atm::ATMBusinessDay* pATMBusinessDay)
{
  //## begin atm::ATMBusinessDayVisitor::visitATMBusinessDay%5C49EA4603BC.body preserve=yes
  //## end atm::ATMBusinessDayVisitor::visitATMBusinessDay%5C49EA4603BC.body
}

void ATMBusinessDayVisitor::visitATMEvent (atm::ATMEvent* pATMEvent)
{
  //## begin atm::ATMBusinessDayVisitor::visitATMEvent%5C49EA780188.body preserve=yes
  //## end atm::ATMBusinessDayVisitor::visitATMEvent%5C49EA780188.body
}

// Additional Declarations
  //## begin atm::ATMBusinessDayVisitor%5C49E97C01AB.declarations preserve=yes
  //## end atm::ATMBusinessDayVisitor%5C49E97C01AB.declarations

} // namespace atm

//## begin module%5C49E9CD0164.epilog preserve=yes
//## end module%5C49E9CD0164.epilog
