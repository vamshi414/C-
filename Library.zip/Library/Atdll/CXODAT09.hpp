//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39AFA30C0033.cm preserve=no
//	$Date:   Jul 23 2021 14:18:56  $ $Author:   e1009839  $
//	$Revision:   1.4  $
//## end module%39AFA30C0033.cm

//## begin module%39AFA30C0033.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39AFA30C0033.cp

//## Module: CXOSAT09%39AFA30C0033; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Library\Atdll\CXODAT09.hpp

#ifndef CXOSAT09_h
#define CXOSAT09_h 1

//## begin module%39AFA30C0033.additionalIncludes preserve=no
//## end module%39AFA30C0033.additionalIncludes

//## begin module%39AFA30C0033.includes preserve=yes
// $Date:   Jul 23 2021 14:18:56  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%39AFA30C0033.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
class ATMActivity;
} // namespace atm

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%39AFA30C0033.declarations preserve=no
//## end module%39AFA30C0033.declarations

//## begin module%39AFA30C0033.additionalDeclarations preserve=yes
//## end module%39AFA30C0033.additionalDeclarations


namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::AdminMessage%39AF966903AD.preface preserve=yes
//## end atm::AdminMessage%39AF966903AD.preface

//## Class: AdminMessage%39AF966903AD
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39AFA1860082;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%39AFA18802C0;reusable::Query { -> F}
//## Uses: <unnamed>%39AFA18B0292;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5DE8235A0088;reusable::Table { -> F}
//## Uses: <unnamed>%5DE82B730011;ATMActivity { -> F}

class DllExport AdminMessage : public reusable::Object  //## Inherits: <unnamed>%39AF96870107
{
  //## begin atm::AdminMessage%39AF966903AD.initialDeclarations preserve=yes
  public:
      enum SumType
      {
         CASSETTES = 0,
         CASH,
         CHECK,
         TELLER,
         CASSETTE1,
         CASSETTE2,
         CASSETTE3,
         CASSETTE4,
         CASSETTE5,
         CASSETTE6,
         CASSETTE7,
         CASSETTE8,
         TOTAL_CASSETTE1,
         TOTAL_CASSETTE2,
         TOTAL_CASSETTE3,
         TOTAL_CASSETTE4,
         TOTAL_CASSETTE5,
         TOTAL_CASSETTE6,
         TOTAL_CASSETTE7,
         TOTAL_CASSETTE8
      };
  //## end atm::AdminMessage%39AF966903AD.initialDeclarations

  public:
    //## Constructors (generated)
      AdminMessage();

    //## Destructor (generated)
      virtual ~AdminMessage();


    //## Other Operations (specified)
      //## Operation: bind%39AFA13002B9
      void bind (Query& hQuery, string& strLocator);

      //## Operation: getCredit%5DE90974010C
      double getCredit (int iIndex) const;

      //## Operation: getCUR_CODE%5DE9226A02AC
      const reusable::string& getCUR_CODE (int iIndex = 0) const
      {
        //## begin atm::AdminMessage::getCUR_CODE%5DE9226A02AC.body preserve=yes
         return m_strCUR_CODE[iIndex];
        //## end atm::AdminMessage::getCUR_CODE%5DE9226A02AC.body
      }

      //## Operation: getCUR_TYPE%5DE9097E007B
      int getCUR_TYPE (int iIndex = 0) const
      {
        //## begin atm::AdminMessage::getCUR_TYPE%5DE9097E007B.body preserve=yes
         return m_siCUR_TYPE[iIndex];
        //## end atm::AdminMessage::getCUR_TYPE%5DE9097E007B.body
      }

      //## Operation: getDebit%5DE909740171
      double getDebit (int iIndex) const;

      //## Operation: getITEM_COUNT%5DE9097401B4
      int getITEM_COUNT (int iIndex = 0) const
      {
        //## begin atm::AdminMessage::getITEM_COUNT%5DE9097401B4.body preserve=yes
         return m_iITEM_COUNT[iIndex];
        //## end atm::AdminMessage::getITEM_COUNT%5DE9097401B4.body
      }

      //## Operation: getITEM_VALUE%5DE9097401EB
      int getITEM_VALUE (int iIndex = 0) const
      {
        //## begin atm::AdminMessage::getITEM_VALUE%5DE9097401EB.body preserve=yes
         return m_iITEM_VALUE[iIndex];
        //## end atm::AdminMessage::getITEM_VALUE%5DE9097401EB.body
      }

      //## Operation: getLocatorColumns%5C4F19AE02A5
      bool getLocatorColumns ();

      //## Operation: reset%5DE91E9101F5
      void reset ();

      //## Operation: setActivity%5DE8231B03B4
      void setActivity (reusable::Table& hTable);

      //## Operation: setCAN_CUR_CODEn%5DF1542101F2
      void setCAN_CUR_CODEn (const reusable::string& strCAN_CUR_CODEn, int iIndex)
      {
        //## begin atm::AdminMessage::setCAN_CUR_CODEn%5DF1542101F2.body preserve=yes
         m_strCAN_CUR_CODEn[iIndex] = strCAN_CUR_CODEn;
        //## end atm::AdminMessage::setCAN_CUR_CODEn%5DF1542101F2.body
      }

      //## Operation: setCAN_CUR_TYPEn%5DF1542A014B
      void setCAN_CUR_TYPEn (short siCAN_CUR_TYPEn, int iIndex)
      {
        //## begin atm::AdminMessage::setCAN_CUR_TYPEn%5DF1542A014B.body preserve=yes
         m_siCAN_CUR_TYPEn[iIndex] = siCAN_CUR_TYPEn;
        //## end atm::AdminMessage::setCAN_CUR_TYPEn%5DF1542A014B.body
      }

      //## Operation: setCAN_ITEM_AMTn%5DF153ED020E
      void setCAN_ITEM_AMTn (double dCAN_ITEM_AMTn, int iIndex)
      {
        //## begin atm::AdminMessage::setCAN_ITEM_AMTn%5DF153ED020E.body preserve=yes
         m_dCAN_ITEM_AMTn[iIndex] = dCAN_ITEM_AMTn;
        //## end atm::AdminMessage::setCAN_ITEM_AMTn%5DF153ED020E.body
      }

      //## Operation: setCAN_ITEM_COUNTn%5DF1542801F0
      void setCAN_ITEM_COUNTn (int iCAN_ITEM_COUNTn, int iIndex)
      {
        //## begin atm::AdminMessage::setCAN_ITEM_COUNTn%5DF1542801F0.body preserve=yes
         m_iCAN_ITEM_COUNTn[iIndex] = iCAN_ITEM_COUNTn;
        //## end atm::AdminMessage::setCAN_ITEM_COUNTn%5DF1542801F0.body
      }

      //## Operation: setCAN_ITEM_VALUEn%5DF154240141
      void setCAN_ITEM_VALUEn (int iCAN_ITEM_VALUEn, int iIndex)
      {
        //## begin atm::AdminMessage::setCAN_ITEM_VALUEn%5DF154240141.body preserve=yes
         m_iCAN_ITEM_VALUEn[iIndex] = iCAN_ITEM_VALUEn;
        //## end atm::AdminMessage::setCAN_ITEM_VALUEn%5DF154240141.body
      }

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: CAN_ITEM_AMTn%39AF9F2F037A
      const double* getCAN_ITEM_AMTn () const
      {
        //## begin atm::AdminMessage::getCAN_ITEM_AMTn%39AF9F2F037A.get preserve=no
        return m_dCAN_ITEM_AMTn;
        //## end atm::AdminMessage::getCAN_ITEM_AMTn%39AF9F2F037A.get
      }


      //## Attribute: CAN_ITEM_COUNTn%39AF9F300046
      const int* getCAN_ITEM_COUNTn () const
      {
        //## begin atm::AdminMessage::getCAN_ITEM_COUNTn%39AF9F300046.get preserve=no
        return m_iCAN_ITEM_COUNTn;
        //## end atm::AdminMessage::getCAN_ITEM_COUNTn%39AF9F300046.get
      }


      //## Attribute: CAN_ITEM_VALUEn%39AF9F30015F
      const int* getCAN_ITEM_VALUEn () const
      {
        //## begin atm::AdminMessage::getCAN_ITEM_VALUEn%39AF9F30015F.get preserve=no
        return m_iCAN_ITEM_VALUEn;
        //## end atm::AdminMessage::getCAN_ITEM_VALUEn%39AF9F30015F.get
      }


      //## Attribute: CAN_CUR_CODEn%39AF9F2F013F
      const string* getCAN_CUR_CODEn () const
      {
        //## begin atm::AdminMessage::getCAN_CUR_CODEn%39AF9F2F013F.get preserve=no
        return m_strCAN_CUR_CODEn;
        //## end atm::AdminMessage::getCAN_CUR_CODEn%39AF9F2F013F.get
      }


      //## Attribute: CAN_CUR_TYPEn%39AF9F2F0230
      const short* getCAN_CUR_TYPEn () const
      {
        //## begin atm::AdminMessage::getCAN_CUR_TYPEn%39AF9F2F0230.get preserve=no
        return m_siCAN_CUR_TYPEn;
        //## end atm::AdminMessage::getCAN_CUR_TYPEn%39AF9F2F0230.get
      }


      //## Attribute: CLERK_ID%5DE7C60602B5
      const reusable::string& getCLERK_ID () const
      {
        //## begin atm::AdminMessage::getCLERK_ID%5DE7C60602B5.get preserve=no
        return m_strCLERK_ID;
        //## end atm::AdminMessage::getCLERK_ID%5DE7C60602B5.get
      }


      //## Attribute: DEVICE_AMT%39AF9F2E01C0
      const double getDEVICE_AMT () const
      {
        //## begin atm::AdminMessage::getDEVICE_AMT%39AF9F2E01C0.get preserve=no
        return m_dDEVICE_AMT;
        //## end atm::AdminMessage::getDEVICE_AMT%39AF9F2E01C0.get
      }

      void setDEVICE_AMT (double value)
      {
        //## begin atm::AdminMessage::setDEVICE_AMT%39AF9F2E01C0.set preserve=no
        m_dDEVICE_AMT = value;
        //## end atm::AdminMessage::setDEVICE_AMT%39AF9F2E01C0.set
      }


      //## Attribute: DEVICE_CUR_TRAN%39AF9F2C0326
      const reusable::string& getDEVICE_CUR_TRAN () const
      {
        //## begin atm::AdminMessage::getDEVICE_CUR_TRAN%39AF9F2C0326.get preserve=no
        return m_strDEVICE_CUR_TRAN;
        //## end atm::AdminMessage::getDEVICE_CUR_TRAN%39AF9F2C0326.get
      }

      void setDEVICE_CUR_TRAN (const reusable::string& value)
      {
        //## begin atm::AdminMessage::setDEVICE_CUR_TRAN%39AF9F2C0326.set preserve=no
        m_strDEVICE_CUR_TRAN = value;
        //## end atm::AdminMessage::setDEVICE_CUR_TRAN%39AF9F2C0326.set
      }


      //## Attribute: DEVICE_CUR_TYPE%39AF9F2D00B0
      const short getDEVICE_CUR_TYPE () const
      {
        //## begin atm::AdminMessage::getDEVICE_CUR_TYPE%39AF9F2D00B0.get preserve=no
        return m_iDEVICE_CUR_TYPE;
        //## end atm::AdminMessage::getDEVICE_CUR_TYPE%39AF9F2D00B0.get
      }

      void setDEVICE_CUR_TYPE (short value)
      {
        //## begin atm::AdminMessage::setDEVICE_CUR_TYPE%39AF9F2D00B0.set preserve=no
        m_iDEVICE_CUR_TYPE = value;
        //## end atm::AdminMessage::setDEVICE_CUR_TYPE%39AF9F2D00B0.set
      }


      //## Attribute: FUNCTION_CODE%39AF9F2A030F
      const reusable::string& getFUNCTION_CODE () const
      {
        //## begin atm::AdminMessage::getFUNCTION_CODE%39AF9F2A030F.get preserve=no
        return m_strFUNCTION_CODE;
        //## end atm::AdminMessage::getFUNCTION_CODE%39AF9F2A030F.get
      }

      void setFUNCTION_CODE (const reusable::string& value)
      {
        //## begin atm::AdminMessage::setFUNCTION_CODE%39AF9F2A030F.set preserve=no
        m_strFUNCTION_CODE = value;
        //## end atm::AdminMessage::setFUNCTION_CODE%39AF9F2A030F.set
      }


      //## Attribute: Locator%39AFA10D01FB
      const reusable::string& getLocator () const
      {
        //## begin atm::AdminMessage::getLocator%39AFA10D01FB.get preserve=no
        return m_strLocator;
        //## end atm::AdminMessage::getLocator%39AFA10D01FB.get
      }


      //## Attribute: NET_TERM_ID%39AF9F2A0124
      const reusable::string& getNET_TERM_ID () const
      {
        //## begin atm::AdminMessage::getNET_TERM_ID%39AF9F2A0124.get preserve=no
        return m_strNET_TERM_ID;
        //## end atm::AdminMessage::getNET_TERM_ID%39AF9F2A0124.get
      }

      void setNET_TERM_ID (const reusable::string& value)
      {
        //## begin atm::AdminMessage::setNET_TERM_ID%39AF9F2A0124.set preserve=no
        m_strNET_TERM_ID = value;
        //## end atm::AdminMessage::setNET_TERM_ID%39AF9F2A0124.set
      }


      //## Attribute: Null%39AFA11B02C3
      const short getNull () const
      {
        //## begin atm::AdminMessage::getNull%39AFA11B02C3.get preserve=no
        return m_iNull;
        //## end atm::AdminMessage::getNull%39AFA11B02C3.get
      }


      //## Attribute: RECON_IND_ACQ%5CC6DB8600B9
      const reusable::string& getRECON_IND_ACQ () const
      {
        //## begin atm::AdminMessage::getRECON_IND_ACQ%5CC6DB8600B9.get preserve=no
        return m_strRECON_IND_ACQ;
        //## end atm::AdminMessage::getRECON_IND_ACQ%5CC6DB8600B9.get
      }


      //## Attribute: TSTAMP_TRANS%39AF96D70379
      const reusable::string& getTSTAMP_TRANS () const
      {
        //## begin atm::AdminMessage::getTSTAMP_TRANS%39AF96D70379.get preserve=no
        return m_strTSTAMP_TRANS;
        //## end atm::AdminMessage::getTSTAMP_TRANS%39AF96D70379.get
      }

      void setTSTAMP_TRANS (const reusable::string& value)
      {
        //## begin atm::AdminMessage::setTSTAMP_TRANS%39AF96D70379.set preserve=no
        m_strTSTAMP_TRANS = value;
        //## end atm::AdminMessage::setTSTAMP_TRANS%39AF96D70379.set
      }


      //## Attribute: UNIQUENESS_KEY%39AF9F27017A
      const short getUNIQUENESS_KEY () const
      {
        //## begin atm::AdminMessage::getUNIQUENESS_KEY%39AF9F27017A.get preserve=no
        return m_iUNIQUENESS_KEY;
        //## end atm::AdminMessage::getUNIQUENESS_KEY%39AF9F27017A.get
      }


    // Additional Public Declarations
      //## begin atm::AdminMessage%39AF966903AD.public preserve=yes
      //## end atm::AdminMessage%39AF966903AD.public

  protected:
    // Additional Protected Declarations
      //## begin atm::AdminMessage%39AF966903AD.protected preserve=yes
      //## end atm::AdminMessage%39AF966903AD.protected

  private:
    // Additional Private Declarations
      //## begin atm::AdminMessage%39AF966903AD.private preserve=yes
      //## end atm::AdminMessage%39AF966903AD.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin atm::AdminMessage::CAN_ITEM_AMTn%39AF9F2F037A.attr preserve=no  public: double[8] {V} 
      double m_dCAN_ITEM_AMTn[8];
      //## end atm::AdminMessage::CAN_ITEM_AMTn%39AF9F2F037A.attr

      //## begin atm::AdminMessage::CAN_ITEM_COUNTn%39AF9F300046.attr preserve=no  public: int[8] {V} 
      int m_iCAN_ITEM_COUNTn[8];
      //## end atm::AdminMessage::CAN_ITEM_COUNTn%39AF9F300046.attr

      //## begin atm::AdminMessage::CAN_ITEM_VALUEn%39AF9F30015F.attr preserve=no  public: int[8] {V} 
      int m_iCAN_ITEM_VALUEn[8];
      //## end atm::AdminMessage::CAN_ITEM_VALUEn%39AF9F30015F.attr

      //## begin atm::AdminMessage::CAN_CUR_CODEn%39AF9F2F013F.attr preserve=no  public: string[8] {V} 
      string m_strCAN_CUR_CODEn[8];
      //## end atm::AdminMessage::CAN_CUR_CODEn%39AF9F2F013F.attr

      //## begin atm::AdminMessage::CAN_CUR_TYPEn%39AF9F2F0230.attr preserve=no  public: short[8] {V} 
      short m_siCAN_CUR_TYPEn[8];
      //## end atm::AdminMessage::CAN_CUR_TYPEn%39AF9F2F0230.attr

      //## begin atm::AdminMessage::CLERK_ID%5DE7C60602B5.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strCLERK_ID;
      //## end atm::AdminMessage::CLERK_ID%5DE7C60602B5.attr

      //## Attribute: Credit%5DE82975038A
      //## begin atm::AdminMessage::Credit%5DE82975038A.attr preserve=no  public: double[20] {V} 
      double m_dCredit[20];
      //## end atm::AdminMessage::Credit%5DE82975038A.attr

      //## Attribute: CUR_CODE%5DE922F20190
      //## begin atm::AdminMessage::CUR_CODE%5DE922F20190.attr preserve=no  public: reusable::string[20] {V} 
      reusable::string m_strCUR_CODE[20];
      //## end atm::AdminMessage::CUR_CODE%5DE922F20190.attr

      //## Attribute: CUR_TYPE%5DE8297503B2
      //## begin atm::AdminMessage::CUR_TYPE%5DE8297503B2.attr preserve=no  public: short[20] {V} 
      short m_siCUR_TYPE[20];
      //## end atm::AdminMessage::CUR_TYPE%5DE8297503B2.attr

      //## Attribute: Debit%5DE829750334
      //## begin atm::AdminMessage::Debit%5DE829750334.attr preserve=no  public: double[20] {V} 
      double m_dDebit[20];
      //## end atm::AdminMessage::Debit%5DE829750334.attr

      //## begin atm::AdminMessage::DEVICE_AMT%39AF9F2E01C0.attr preserve=no  public: double {V} 0
      double m_dDEVICE_AMT;
      //## end atm::AdminMessage::DEVICE_AMT%39AF9F2E01C0.attr

      //## begin atm::AdminMessage::DEVICE_CUR_TRAN%39AF9F2C0326.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strDEVICE_CUR_TRAN;
      //## end atm::AdminMessage::DEVICE_CUR_TRAN%39AF9F2C0326.attr

      //## begin atm::AdminMessage::DEVICE_CUR_TYPE%39AF9F2D00B0.attr preserve=no  public: short {V} 0
      short m_iDEVICE_CUR_TYPE;
      //## end atm::AdminMessage::DEVICE_CUR_TYPE%39AF9F2D00B0.attr

      //## begin atm::AdminMessage::FUNCTION_CODE%39AF9F2A030F.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strFUNCTION_CODE;
      //## end atm::AdminMessage::FUNCTION_CODE%39AF9F2A030F.attr

      //## Attribute: ITEM_COUNT%5DE8297503DB
      //## begin atm::AdminMessage::ITEM_COUNT%5DE8297503DB.attr preserve=no  public: int[12] {V} 
      int m_iITEM_COUNT[12];
      //## end atm::AdminMessage::ITEM_COUNT%5DE8297503DB.attr

      //## Attribute: ITEM_VALUE%5DE82976001E
      //## begin atm::AdminMessage::ITEM_VALUE%5DE82976001E.attr preserve=no  public: int[20] {V} 
      int m_iITEM_VALUE[20];
      //## end atm::AdminMessage::ITEM_VALUE%5DE82976001E.attr

      //## begin atm::AdminMessage::Locator%39AFA10D01FB.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strLocator;
      //## end atm::AdminMessage::Locator%39AFA10D01FB.attr

      //## begin atm::AdminMessage::NET_TERM_ID%39AF9F2A0124.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strNET_TERM_ID;
      //## end atm::AdminMessage::NET_TERM_ID%39AF9F2A0124.attr

      //## begin atm::AdminMessage::Null%39AFA11B02C3.attr preserve=no  public: short {V} 0
      short m_iNull;
      //## end atm::AdminMessage::Null%39AFA11B02C3.attr

      //## begin atm::AdminMessage::RECON_IND_ACQ%5CC6DB8600B9.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strRECON_IND_ACQ;
      //## end atm::AdminMessage::RECON_IND_ACQ%5CC6DB8600B9.attr

      //## begin atm::AdminMessage::TSTAMP_TRANS%39AF96D70379.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strTSTAMP_TRANS;
      //## end atm::AdminMessage::TSTAMP_TRANS%39AF96D70379.attr

      //## begin atm::AdminMessage::UNIQUENESS_KEY%39AF9F27017A.attr preserve=no  public: short {V} 0
      short m_iUNIQUENESS_KEY;
      //## end atm::AdminMessage::UNIQUENESS_KEY%39AF9F27017A.attr

    // Additional Implementation Declarations
      //## begin atm::AdminMessage%39AF966903AD.implementation preserve=yes
      //## end atm::AdminMessage%39AF966903AD.implementation

};

//## begin atm::AdminMessage%39AF966903AD.postscript preserve=yes
//## end atm::AdminMessage%39AF966903AD.postscript

} // namespace atm

//## begin module%39AFA30C0033.epilog preserve=yes
using namespace atm;
//## end module%39AFA30C0033.epilog


#endif
