//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5E79FB6300FA.cm preserve=no
//## end module%5E79FB6300FA.cm

//## begin module%5E79FB6300FA.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5E79FB6300FA.cp

//## Module: CXOSAT13%5E79FB6300FA; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Library\Atdll\CXOSAT13.cpp

//## begin module%5E79FB6300FA.additionalIncludes preserve=no
//## end module%5E79FB6300FA.additionalIncludes

//## begin module%5E79FB6300FA.includes preserve=yes
#include "CXODRU19.hpp"
//## end module%5E79FB6300FA.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSTM13_h
#include "CXODTM13.hpp"
#endif
#ifndef CXOSAT13_h
#include "CXODAT13.hpp"
#endif


//## begin module%5E79FB6300FA.declarations preserve=no
//## end module%5E79FB6300FA.declarations

//## begin module%5E79FB6300FA.additionalDeclarations preserve=yes
//## end module%5E79FB6300FA.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::TerminalSet 

//## begin atm::TerminalSet::Instance%5E7970300117.attr preserve=no  private: static atm::TerminalSet* {V} 0
atm::TerminalSet* TerminalSet::m_pInstance = 0;
//## end atm::TerminalSet::Instance%5E7970300117.attr

TerminalSet::TerminalSet()
  //## begin TerminalSet::TerminalSet%5E796FF40390_const.hasinit preserve=no
      : m_iCount(0)
  //## end TerminalSet::TerminalSet%5E796FF40390_const.hasinit
  //## begin TerminalSet::TerminalSet%5E796FF40390_const.initialization preserve=yes
  //## end TerminalSet::TerminalSet%5E796FF40390_const.initialization
{
  //## begin atm::TerminalSet::TerminalSet%5E796FF40390_const.body preserve=yes
   memcpy(m_sID,"AT13",4);
   timer::HourAlarm::instance()->attach(this);
  //## end atm::TerminalSet::TerminalSet%5E796FF40390_const.body
}


TerminalSet::~TerminalSet()
{
  //## begin atm::TerminalSet::~TerminalSet%5E796FF40390_dest.body preserve=yes
   timer::HourAlarm::instance()->detach(this);
  //## end atm::TerminalSet::~TerminalSet%5E796FF40390_dest.body
}



//## Other Operations (implementation)
TerminalSet* TerminalSet::instance ()
{
  //## begin atm::TerminalSet::instance%5E79704B027E.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new TerminalSet();
   return m_pInstance;
  //## end atm::TerminalSet::instance%5E79704B027E.body
}

bool TerminalSet::load ()
{
  //## begin atm::TerminalSet::load%5E79701F0340.body preserve=yes
   m_strNET_TERM_ID.erase();
   m_hNET_TERM_IDs.clear();
   string strTASKID;
   int iDivisor = 0;
   short int iNull = 0;
   Query hQuery;
   hQuery.setQualifier("QUALIFY","CRTASKT");
   hQuery.bind("CRTASKT","*",Column::LONG,&iDivisor,&iNull,"COUNT");
   string strName(Application::instance()->name());
   int iRemainder = atoi(strName.substr(4).c_str());
   strName.resize(4);
   strName += '%';
   hQuery.setBasicPredicate("CRTASKT","TASKID","LIKE",strName.c_str());
   hQuery.setBasicPredicate("CRTASKT","CC_STATE","=","A");
   hQuery.setBasicPredicate("CRTASKT","CC_CHANGE_GRP_ID","IS NULL");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == false
      || iNull == -1)
      return false;
   if (iDivisor == 1) // one TP task will do all terminals
   {
      m_strNET_TERM_ID.assign("('*')");
      m_hNET_TERM_IDs.push_back(m_strNET_TERM_ID);
      return true;
   }
   string strNET_TERM_ID;
   hQuery.reset();
   hQuery.setSubSelect(true);
   hQuery.setDistinct(true);
   hQuery.bind("T_ATM_EVENT","NET_TERM_ID",Column::STRING,&strNET_TERM_ID);
   auto_ptr<reusable::FormatSelectVisitor>pFormatSelectVisitor((reusable::FormatSelectVisitor*)database::DatabaseFactory::instance()->create("FormatSelectVisitor"));
   hQuery.accept(*pFormatSelectVisitor);
   string strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ") ";
   hQuery.reset();
   hQuery.bind("T_FIN_ENTITY","*",Column::LONG,&m_iCount,&iNull,"COUNT");
   char szDivisor[PERCENTD];
   sprintf(szDivisor,"%d",iDivisor);
   hQuery.setBasicPredicate("T_FIN_ENTITY","T_FIN_ENTITY_ID","=",iRemainder,true,"MOD",szDivisor);
   hQuery.setBasicPredicate("T_FIN_ENTITY","ENTITY_TYPE","=","AT");
   hQuery.setBasicPredicate("T_FIN_ENTITY","ENTITY_ID","IN",strSubSelect.c_str());
   if (!pSelectStatement->execute(hQuery))
      return false;
   if (m_iCount == 0)
   {
      m_strNET_TERM_ID.assign("('~')"); // no terminals for this TP task yet
      m_hNET_TERM_IDs.push_back(m_strNET_TERM_ID);
      return true;
   }
   m_strNET_TERM_ID.reserve(min(512,m_iCount) * 11);
   m_iCount = 0;
   m_strNET_TERM_ID += '(';
   hQuery.reset();
   hQuery.attach(this);
   hQuery.bind("T_FIN_ENTITY","ENTITY_ID",Column::STRING,&m_strENTITY_ID);
   hQuery.setBasicPredicate("T_FIN_ENTITY","T_FIN_ENTITY_ID","=",iRemainder,true,"MOD",szDivisor);
   hQuery.setBasicPredicate("T_FIN_ENTITY","ENTITY_TYPE","=","AT");
   hQuery.setBasicPredicate("T_FIN_ENTITY","ENTITY_ID","IN",strSubSelect.c_str());
   hQuery.setOrderByClause("ENTITY_ID");
   if (!pSelectStatement->execute(hQuery))
      return false;
   m_strNET_TERM_ID += ')';
   if (m_strNET_TERM_ID.length() > 2)
      m_hNET_TERM_IDs.push_back(m_strNET_TERM_ID);
   return true;
  //## end atm::TerminalSet::load%5E79701F0340.body
}

void TerminalSet::update (Subject* pSubject)
{
  //## begin atm::TerminalSet::update%5E79725D0173.body preserve=yes
   if (pSubject == timer::HourAlarm::instance())
   {
      database::Cache::reload(this);
      return;
   }
   if (m_strNET_TERM_ID.length() > 1)
      m_strNET_TERM_ID += ',';
   m_strNET_TERM_ID += '\'';
   m_strNET_TERM_ID += m_strENTITY_ID;
   m_strNET_TERM_ID += '\'';
   m_iCount++;
   if (m_iCount == 512)
   {
      m_strNET_TERM_ID += ')';
      m_hNET_TERM_IDs.push_back(m_strNET_TERM_ID);
      m_iCount = 0;
      m_strNET_TERM_ID.erase();
      m_strNET_TERM_ID += '(';
   }
  //## end atm::TerminalSet::update%5E79725D0173.body
}

// Additional Declarations
  //## begin atm::TerminalSet%5E796FF40390.declarations preserve=yes
  //## end atm::TerminalSet%5E796FF40390.declarations

} // namespace atm

//## begin module%5E79FB6300FA.epilog preserve=yes
//## end module%5E79FB6300FA.epilog
