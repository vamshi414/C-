//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5DE7AD3A0380.cm preserve=no
//	$Date:   Sep 23 2021 21:26:50  $ $Author:   e1009839  $
//	$Revision:   1.12  $
//## end module%5DE7AD3A0380.cm

//## begin module%5DE7AD3A0380.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5DE7AD3A0380.cp

//## Module: CXOSAT12%5DE7AD3A0380; Package body
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV03.1B.R001\Windows\Build\Dn\Server\Library\Atdll\CXOSAT12.cpp

//## begin module%5DE7AD3A0380.additionalIncludes preserve=no
//## end module%5DE7AD3A0380.additionalIncludes

//## begin module%5DE7AD3A0380.includes preserve=yes
//## end module%5DE7AD3A0380.includes

#ifndef CXOSAT07_h
#include "CXODAT07.hpp"
#endif
#ifndef CXOSAT10_h
#include "CXODAT10.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSAT02_h
#include "CXODAT02.hpp"
#endif
#ifndef CXOSAT09_h
#include "CXODAT09.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSAT08_h
#include "CXODAT08.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSAT12_h
#include "CXODAT12.hpp"
#endif


//## begin module%5DE7AD3A0380.declarations preserve=no
//## end module%5DE7AD3A0380.declarations

//## begin module%5DE7AD3A0380.additionalDeclarations preserve=yes
//## end module%5DE7AD3A0380.additionalDeclarations


//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

// Class atm::ATMLog

//## begin atm::ATMLog::Instance%5DE7AC81025B.attr preserve=no  private: static atm::ATMLog* {V} 0
atm::ATMLog* ATMLog::m_pInstance = 0;
//## end atm::ATMLog::Instance%5DE7AC81025B.attr

ATMLog::ATMLog()
  //## begin ATMLog::ATMLog%5DE7AC130214_const.hasinit preserve=no
  //## end ATMLog::ATMLog%5DE7AC130214_const.hasinit
  //## begin ATMLog::ATMLog%5DE7AC130214_const.initialization preserve=yes
  //## end ATMLog::ATMLog%5DE7AC130214_const.initialization
{
  //## begin atm::ATMLog::ATMLog%5DE7AC130214_const.body preserve=yes
   memcpy(m_sID,"AT12",4);
  //## end atm::ATMLog::ATMLog%5DE7AC130214_const.body
}


ATMLog::~ATMLog()
{
  //## begin atm::ATMLog::~ATMLog%5DE7AC130214_dest.body preserve=yes
  //## end atm::ATMLog::~ATMLog%5DE7AC130214_dest.body
}



//## Other Operations (implementation)
bool ATMLog::add (const reusable::string& strNET_TERM_ID, const reusable::string& strDATE_RECON_ACQ, ATMTransaction& hATMTransaction)
{
  //## begin atm::ATMLog::add%5DE7AC8903A8.body preserve=yes
   if (hATMTransaction.getTRAN_DISPOSITION() == "2"
      || Hierarchy::instance()->isPseudoTerminal(strNET_TERM_ID))
      return true;
   string strDate(strDATE_RECON_ACQ);
   if (strDate == "99991231")
      strDate = entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(1);
   Table hTable[2];
   hTable[0].setName("T_ATM_EVENT");
   hTable[1].setName("T_ATM_ACTIVITY");
   string strTSTAMP_TRANS(strDate);
   strTSTAMP_TRANS.append("23595999");
   for (int i = 0;i < 2;++i)
   {
      hTable[i].set("NET_TERM_ID",strNET_TERM_ID,false,true);
      hTable[i].set("DATE_RECON_ACQ",strDate,false,true);
      hTable[i].set("TSTAMP_TRANS",strTSTAMP_TRANS,false,true);
      hTable[i].set("UNIQUENESS_KEY",(int)0,true);
      hTable[i].set("FUNCTION_CODE","998",false,true);
   }
   hATMTransaction.setActivity(0,hTable[1]);
   if (hATMTransaction.getACTIVITY_TYPE() != 1
      && hATMTransaction.getACTIVITY_TYPE() != 30
      && hATMTransaction.getACTIVITY_TYPE() != 60)
      return true;
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   char szTemp[9] = {"12345678"};
   double dCASSETTES_END = 0;
   for (int i = -1;i < 8;++i)
   {
      if (i == -1
         || hATMTransaction.getCAN_NO_ITEMS_DISPn(i) > 0
         || hATMTransaction.getCAN_ORIG_NO_ITEMSn(i) > 0)
      {
         if (i > -1)
         {
            hTable[1].set("ACTIVITY_TYPE",i + 11,true);
            hTable[1].set("IMPACT_TO_ACQ",string(" "));
            hTable[1].set("AMT_RECON_NET",double(0));
            hTable[1].set("AMT_SURCHARGE",double(0));
            hTable[1].set("TRAN_COUNT",(int)0);
            hTable[1].set("CUR_TYPE",hATMTransaction.getCUR_TYPE(atm::ATMTransaction::CASSETTES));
            hTable[1].set("ITEM_VALUE",hATMTransaction.getCAN_ITEM_VALUEn(i));
            char szCASSETTEn_END[14] = {"CASSETTEn_END"};
            szCASSETTEn_END[8] = szTemp[i];
            if (hATMTransaction.getTRAN_DISPOSITION() == "3")
            {
               if (hATMTransaction.getAMT_RECON_NET() > 0)
                  hTable[1].set("ITEM_COUNT",hATMTransaction.getCAN_ORIG_NO_ITEMSn(i) - hATMTransaction.getCAN_NO_ITEMS_DISPn(i),false,"-");
               else
                  hTable[1].set("ITEM_COUNT",(int)0,false,"+");
               double dAMT_RECON_NET = hATMTransaction.getCAN_ITEM_VALUEn(i) * (hATMTransaction.getCAN_ORIG_NO_ITEMSn(i) - hATMTransaction.getCAN_NO_ITEMS_DISPn(i));
               hTable[0].set(szCASSETTEn_END,dAMT_RECON_NET,false,"+");
               dCASSETTES_END -= dAMT_RECON_NET;
            }
            else
            {
               hTable[1].set("ITEM_COUNT",hATMTransaction.getCAN_NO_ITEMS_DISPn(i),false,"+");
               double dAMT_RECON_NET = hATMTransaction.getCAN_ITEM_VALUEn(i) * hATMTransaction.getCAN_NO_ITEMS_DISPn(i);
               hTable[0].set(szCASSETTEn_END,dAMT_RECON_NET,false,"-");
               dCASSETTES_END += dAMT_RECON_NET;
            }
            char szCASSETTEn_VALUE[16] = {"CASSETTEn_VALUE"};
            szCASSETTEn_VALUE[8] = szTemp[i];
            hTable[0].set(szCASSETTEn_VALUE,hATMTransaction.getCAN_ITEM_VALUEn(i));
            char szCASSETTEn_CUR_TYPE[19] = {"CASSETTEn_CUR_TYPE"};
            szCASSETTEn_CUR_TYPE[8] = szTemp[i];
            hTable[0].set(szCASSETTEn_CUR_TYPE,hATMTransaction.getCUR_TYPE(atm::ATMTransaction::CASSETTES));
            char szCASSETTEn_CUR_CODE[19] = {"CASSETTEn_CUR_CODE"};
            szCASSETTEn_CUR_CODE[8] = szTemp[i];
            hTable[0].set(szCASSETTEn_CUR_CODE,hATMTransaction.getCUR_CODE(atm::ATMTransaction::CASSETTES));
         }
         if (!pUpdateStatement->execute(hTable[1]))
         {
            if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
            {
               {
                  Table hTable("T_ATM_EVENT");
                  ATMEvent hATMEvent;
                  hATMEvent.setNET_TERM_ID(strNET_TERM_ID);
                  hATMEvent.setDATE_RECON_ACQ(strDate);
                  hATMEvent.setUNIQUENESS_KEY(0);
                  hATMEvent.setTSTAMP_TRANS(strTSTAMP_TRANS);
                  hATMEvent.setFUNCTION_CODE("998");
                  hATMEvent.setCUR_CODE("840"); // !!!
                  hATMEvent.setColumns(hTable);
                  if (pInsertStatement->execute(hTable) == false
                     && pInsertStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
                     return false;
                  if (pInsertStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
                     atm::ATMInstitution::instance()->addEndOfDay(hATMEvent);
               }
               if (pInsertStatement->execute(hTable[1]))
                  continue;
            }
            return false;
         }
      }
   }
   if (hATMTransaction.getACTIVITY_TYPE() == 1)
      hTable[0].set("CASSETTES_END",dCASSETTES_END,false,"-");
   else
   if (hATMTransaction.getACTIVITY_TYPE() == 30)
      hTable[0].set("CASH_END",hATMTransaction.getAMT_RECON_NET(),false,"+");
   else
   if (hATMTransaction.getACTIVITY_TYPE() == 60)
      hTable[0].set("CHECK_END",hATMTransaction.getAMT_RECON_NET(),false,"+");
   return pUpdateStatement->execute(hTable[0]);
  //## end atm::ATMLog::add%5DE7AC8903A8.body
}

bool ATMLog::apply (const atm::AdminMessage& hAdminMessage)
{
  //## begin atm::ATMLog::apply%5DE7AC9B02D0.body preserve=yes
   if (hAdminMessage.getFUNCTION_CODE() != "572"
      && hAdminMessage.getFUNCTION_CODE() != "583"
      && hAdminMessage.getFUNCTION_CODE() != "584"
      && hAdminMessage.getFUNCTION_CODE() != "585"
      && hAdminMessage.getFUNCTION_CODE() != "593")
      return true;
   entitysegment::SwitchBusinessDay::instance()->update(MidnightAlarm::instance());
   string strCUTOFF_IND[2];
   string strCUTOFF_TIME[2];
   Query hQuery;
   hQuery.setQualifier("QUALIFY","DEVICE");
   hQuery.setQualifier("QUALIFY","INSTITUTION");
   hQuery.join("DEVICE","INNER","INSTITUTION","INST_ID");
   hQuery.bind("DEVICE","CUTOFF_IND",Column::STRING,&strCUTOFF_IND[0]);
   hQuery.bind("DEVICE","CUTOFF_TIME",Column::STRING,&strCUTOFF_TIME[0]);
   hQuery.bind("INSTITUTION","CUTOFF_IND",Column::STRING,&strCUTOFF_IND[1]);
   hQuery.bind("INSTITUTION","CUTOFF_TIME",Column::STRING,&strCUTOFF_TIME[1]);
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.setBasicPredicate("DEVICE","DEVICE_ID","=",hAdminMessage.getNET_TERM_ID().c_str());
   hQuery.setBasicPredicate("DEVICE","CUST_ID","=",strCUST_ID.c_str());
   hQuery.setBasicPredicate("DEVICE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("DEVICE","CC_STATE","=","A");
   hQuery.setBasicPredicate("INSTITUTION","CUST_ID","=",strCUST_ID.c_str());
   hQuery.setBasicPredicate("INSTITUTION","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("INSTITUTION","CC_STATE","=","A");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   string strDATE_RECON_ACQ;
   if (strCUTOFF_IND[0][0] == '1'
      && strCUTOFF_TIME[0] > hAdminMessage.getTSTAMP_TRANS().substr(8,8))
      strDATE_RECON_ACQ.assign(hAdminMessage.getTSTAMP_TRANS().data(),8);
   else
      if (strCUTOFF_IND[1][0] == '1'
         && strCUTOFF_TIME[1] < hAdminMessage.getTSTAMP_TRANS().substr(8,8))
      {
         Date hDate(hAdminMessage.getTSTAMP_TRANS().data());
         hDate += 1;
         strDATE_RECON_ACQ = hDate.asString("%Y%m%d");
      }
      else
         strDATE_RECON_ACQ = entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(hAdminMessage.getTSTAMP_TRANS());
   if (hAdminMessage.getFUNCTION_CODE() == "584"
      && hAdminMessage.getCLERK_ID().empty() == false
      && hAdminMessage.getCLERK_ID()[0] == 'T')
   {
      atm::ATMTransaction hATMTransaction;
      hATMTransaction.setNET_TERM_ID(hAdminMessage.getNET_TERM_ID());
      hATMTransaction.setTRAN_DISPOSITION("1");
      hATMTransaction.setCUR_RECON_NET(hAdminMessage.getDEVICE_CUR_TRAN());
      hATMTransaction.setTRAN_TYPE_ID("0100002000");
      hATMTransaction.setFUNC_CODE("200");
      hATMTransaction.setCUR_TYPE((int)1);
      hATMTransaction.setCUR_CODE(hAdminMessage.getDEVICE_CUR_TRAN());
      double d = 0;
      for (int i = 0;i < 8;++i)
      {
         hATMTransaction.setCAN_ITEM_VALUEn(hAdminMessage.getCAN_ITEM_VALUEn()[i],i);
         hATMTransaction.setCAN_NO_ITEMS_DISPn(hAdminMessage.getCAN_ITEM_COUNTn()[i],i);
         d += hAdminMessage.getCAN_ITEM_VALUEn()[i] * hAdminMessage.getCAN_ITEM_COUNTn()[i];
      }
      hATMTransaction.setAMT_RECON_NET(d);
      hATMTransaction.setAMT_TRAN(d);
      return add(hAdminMessage.getNET_TERM_ID(),strDATE_RECON_ACQ,hATMTransaction);
   }
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   {
      Table hTable("T_ATM_EVENT");
      ATMEvent hATMEvent;
      hATMEvent.setNET_TERM_ID(hAdminMessage.getNET_TERM_ID());
     hATMEvent.setDATE_RECON_ACQ(strDATE_RECON_ACQ);
      hATMEvent.setTSTAMP_TRANS(hAdminMessage.getTSTAMP_TRANS());
      hATMEvent.setUNIQUENESS_KEY(hAdminMessage.getUNIQUENESS_KEY());
      if (hAdminMessage.getRECON_IND_ACQ() == "ATM"
         || hAdminMessage.getRECON_IND_ACQ() == "AUT"
         || hAdminMessage.getRECON_IND_ACQ() == "RMT")
         hATMEvent.setFUNCTION_CODE(hAdminMessage.getRECON_IND_ACQ());
      else
         hATMEvent.setFUNCTION_CODE(hAdminMessage.getFUNCTION_CODE());
      hATMEvent.setCUR_CODE(hAdminMessage.getDEVICE_CUR_TRAN());
      hATMEvent.setColumns(hTable);
      if (pInsertStatement->execute(hTable) == false
         && pInsertStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
         return false;
   }
   if (hAdminMessage.getFUNCTION_CODE() == "572"
      || hAdminMessage.getFUNCTION_CODE() == "593")
      return true;
   Table hTable("T_ATM_ACTIVITY");
   hTable.set("NET_TERM_ID",hAdminMessage.getNET_TERM_ID());
   hTable.set("DATE_RECON_ACQ",strDATE_RECON_ACQ);
   hTable.set("TSTAMP_TRANS",hAdminMessage.getTSTAMP_TRANS());
   hTable.set("UNIQUENESS_KEY",hAdminMessage.getUNIQUENESS_KEY());
   hTable.set("FUNCTION_CODE",hAdminMessage.getFUNCTION_CODE());
   m_hATMActivity.reset();
   m_hATMActivity.setACTIVITY_GROUP((hAdminMessage.getFUNCTION_CODE() == "584") ? ATMActivity::CASH_SUBTRACT : ATMActivity::CASH_ADD);
   m_hATMActivity.setTRAN_DISPOSITION("1");
   m_hATMActivity.setTRAN_COUNT(0);
   for (int i = 0;i <= 7;++i)
      if (hAdminMessage.getCAN_ITEM_AMTn()[i] != 0)
      {
         m_hATMActivity.setACTIVITY_TYPE((const ATMActivity::ActivityType)(ATMActivity::DEVICE + i + 1));
         m_hATMActivity.setCUR_RECON_NET(hAdminMessage.getCAN_CUR_CODEn()[i]);
         m_hATMActivity.setAMT_RECON_NET(hAdminMessage.getCAN_ITEM_AMTn()[i]);
         m_hATMActivity.setITEM_VALUE(hAdminMessage.getCAN_ITEM_VALUEn()[i]);
         m_hATMActivity.setITEM_COUNT(hAdminMessage.getCAN_ITEM_COUNTn()[i]);
         m_hATMActivity.setCUR_TYPE(hAdminMessage.getCAN_CUR_TYPEn()[i]);
         m_hATMActivity.setColumns(hTable);
         if (pInsertStatement->execute(hTable) == false
            && pInsertStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
            return false;
      }
   if (hAdminMessage.getDEVICE_AMT() != 0)
   {
      m_hATMActivity.setACTIVITY_TYPE(ATMActivity::DEVICE);
      m_hATMActivity.setCUR_RECON_NET(hAdminMessage.getDEVICE_CUR_TRAN());
      m_hATMActivity.setAMT_RECON_NET(hAdminMessage.getDEVICE_AMT());
      m_hATMActivity.setITEM_VALUE(0);
      m_hATMActivity.setITEM_COUNT(0);
      m_hATMActivity.setCUR_TYPE(hAdminMessage.getDEVICE_CUR_TYPE());
      m_hATMActivity.setColumns(hTable);
      if (pInsertStatement->execute(hTable) == false
         && pInsertStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
         return false;
   }
   if (hAdminMessage.getDEVICE_AMT() != 0
      && hAdminMessage.getFUNCTION_CODE() == "585")
      return applyTo998(hAdminMessage,strDATE_RECON_ACQ);
   return true;
  //## end atm::ATMLog::apply%5DE7AC9B02D0.body
}

bool ATMLog::applyTo998 (const atm::AdminMessage& hAdminMessage, const reusable::string& strDATE_RECON_ACQ)
{
  //## begin atm::ATMLog::applyTo998%5DF118710157.body preserve=yes
   Table hTable("T_ATM_EVENT");
   hTable.set("NET_TERM_ID",hAdminMessage.getNET_TERM_ID(),false,true);
   hTable.set("DATE_RECON_ACQ",strDATE_RECON_ACQ,false,true);
   string strTSTAMP_TRANS(strDATE_RECON_ACQ);
   strTSTAMP_TRANS.append("23595999",8);
   hTable.set("TSTAMP_TRANS",strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int)0,true);
   hTable.set("FUNCTION_CODE",string("998"),false,true);
   char szTemp[9] = {"12345678"};
   double dCASSETTES_END = 0;
   for (int i = 0;i <= 7;++i)
   {
      char szName[14] = {"CASSETTEn_END"};
      szName[8] = szTemp[i];
      hTable.set(szName,(int)0);
   }
   hTable.set("CASSETTES_END",hAdminMessage.getDEVICE_AMT());
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   bool b = pUpdateStatement->execute(hTable);
   if (b
      || pUpdateStatement->getInfoIDNumber() != STS_RECORD_NOT_FOUND)
      return b;
   {
   ATMEvent hATMEvent;
   Table hTable("T_ATM_EVENT");
   hATMEvent.setColumns(hTable);
   hTable.set("NET_TERM_ID",hAdminMessage.getNET_TERM_ID(),false,true);
   hTable.set("DATE_RECON_ACQ",strDATE_RECON_ACQ,false,true);
   hTable.set("TSTAMP_TRANS",strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int)0,true);
   hTable.set("FUNCTION_CODE",string("998"),false,true);
   hTable.set("CUR_CODE",string("840"));
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   if (!pInsertStatement->execute(hTable)
      && pInsertStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
      return false;
   }
   b = pUpdateStatement->execute(hTable);
   if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      return true;
   return b;
  //## end atm::ATMLog::applyTo998%5DF118710157.body
}

bool ATMLog::applyTo998 (const atm::ATMEvent& hATMEvent, const atm::ATMActivity& hATMActivity)
{
  //## begin atm::ATMLog::applyTo998%5EFB3D290029.body preserve=yes
   if (hATMEvent.getFUNCTION_CODE() == "585"
      && hATMActivity.getACTIVITY_TYPE() == atm::ATMActivity::DEVICE)
      return true; // device level zap already handled by TE
   Table hTable("T_ATM_EVENT");
   hTable.set("NET_TERM_ID",hATMEvent.getNET_TERM_ID(),false,true);
   hTable.set("DATE_RECON_ACQ",hATMEvent.getDATE_RECON_ACQ(),false,true);
   string strTSTAMP_TRANS(hATMEvent.getDATE_RECON_ACQ());
   strTSTAMP_TRANS.append("23595999",8);
   hTable.set("TSTAMP_TRANS",strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int)0,true);
   hTable.set("FUNCTION_CODE",string("998"),false,true);
   char szTemp[9] = {"12345678"};
   char szName[14] = {"CASSETTEn_END"};
   int i = hATMActivity.getACTIVITY_TYPE() - 11;
   if (i > -1)
   {
      szName[8] = szTemp[i];
      char szCASSETTEn_VALUE[16] = {"CASSETTEn_VALUE"};
      szCASSETTEn_VALUE[8] = szTemp[i];
      hTable.set(szCASSETTEn_VALUE,hATMActivity.getITEM_VALUE());
      char szCASSETTEn_CUR_TYPE[19] = {"CASSETTEn_CUR_TYPE"};
      szCASSETTEn_CUR_TYPE[8] = szTemp[i];
      hTable.set(szCASSETTEn_CUR_TYPE,hATMActivity.getCUR_TYPE());
      char szCASSETTEn_CUR_CODE[19] = {"CASSETTEn_CUR_CODE"};
      szCASSETTEn_CUR_CODE[8] = szTemp[i];
      hTable.set(szCASSETTEn_CUR_CODE,hATMEvent.getCUR_CODE());
      if (hATMActivity.getACTIVITY_GROUP() == atm::ATMActivity::CASH_SUBTRACT)
         hTable.set(szName,hATMActivity.getAMT_RECON_NET(),false,"-");
      else
         hTable.set(szName,hATMActivity.getAMT_RECON_NET(),false,"+");
   }
   if (hATMActivity.getACTIVITY_GROUP() == atm::ATMActivity::CASH_SUBTRACT)
      hTable.set("CASSETTES_END",hATMActivity.getAMT_RECON_NET(),false,"-");
   else
      hTable.set("CASSETTES_END",hATMActivity.getAMT_RECON_NET(),false,"+");
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   bool b = pUpdateStatement->execute(hTable);
   if (b
      || pUpdateStatement->getInfoIDNumber() != STS_RECORD_NOT_FOUND)
      return b;
   {
   ATMEvent hATMEvent;
   Table hTable("T_ATM_EVENT");
   hATMEvent.setColumns(hTable);
   hTable.set("NET_TERM_ID",hATMEvent.getNET_TERM_ID(),false,true);
   hTable.set("DATE_RECON_ACQ",hATMEvent.getDATE_RECON_ACQ(),false,true);
   hTable.set("TSTAMP_TRANS",strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int)0,true);
   hTable.set("FUNCTION_CODE",string("998"),false,true);
   hTable.set("CUR_CODE",string("840"));
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   if (pInsertStatement->execute(hTable) == false
      && pInsertStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
      return false;
   }
   b = pUpdateStatement->execute(hTable);
   if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      return true;
   return b;
  //## end atm::ATMLog::applyTo998%5EFB3D290029.body
}

atm::ATMLog* ATMLog::instance ()
{
  //## begin atm::ATMLog::instance%5DE7AC9F01F7.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ATMLog();
   return m_pInstance;
  //## end atm::ATMLog::instance%5DE7AC9F01F7.body
}

// Additional Declarations
  //## begin atm::ATMLog%5DE7AC130214.declarations preserve=yes
  //## end atm::ATMLog%5DE7AC130214.declarations

} // namespace atm

//## begin module%5DE7AD3A0380.epilog preserve=yes
//## end module%5DE7AD3A0380.epilog
