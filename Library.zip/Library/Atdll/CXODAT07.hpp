//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C5C2CE600CD.cm preserve=no
//	$Date:   Jan 29 2020 16:15:34  $ $Author:   e1009839  $
//	$Revision:   1.11  $
//## end module%5C5C2CE600CD.cm

//## begin module%5C5C2CE600CD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C5C2CE600CD.cp

//## Module: CXOSAT07%5C5C2CE600CD; Package specification
//## Subsystem: ATDLL%5C759BDE0325
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Library\Atdll\CXODAT07.hpp

#ifndef CXOSAT07_h
#define CXOSAT07_h 1

//## begin module%5C5C2CE600CD.additionalIncludes preserve=no
//## end module%5C5C2CE600CD.additionalIncludes

//## begin module%5C5C2CE600CD.includes preserve=yes
//## end module%5C5C2CE600CD.includes

#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif

//## Modelname: Totals Management::ATM_CAT%5C7593D900D9
namespace atm {
class ATMEvent;
class ATMActivity;
} // namespace atm

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class CRTransactionTypeIndicator;
class DatabaseFactory;

} // namespace database

//## begin module%5C5C2CE600CD.declarations preserve=no
//## end module%5C5C2CE600CD.declarations

//## begin module%5C5C2CE600CD.additionalDeclarations preserve=yes
//## end module%5C5C2CE600CD.additionalDeclarations


namespace atm {
//## begin atm%5C7593D900D9.initialDeclarations preserve=yes
//## end atm%5C7593D900D9.initialDeclarations

//## begin atm::ATMTransaction%5C5C2BD20292.preface preserve=yes
//## end atm::ATMTransaction%5C5C2BD20292.preface

//## Class: ATMTransaction%5C5C2BD20292
//## Category: Totals Management::ATM_CAT%5C7593D900D9
//## Subsystem: ATDLL%5C759BDE0325
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5C5C3A1C0077;reusable::Query { -> F}
//## Uses: <unnamed>%5C5C92C4028E;ATMActivity { -> F}
//## Uses: <unnamed>%5C5C92E00307;reusable::Table { -> F}
//## Uses: <unnamed>%5C5C9548014C;database::CRTransactionTypeIndicator { -> F}
//## Uses: <unnamed>%5C5D7FFF0359;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%5DF90DD102DA;ATMEvent { -> F}
//## Uses: <unnamed>%5DFA52D001D0;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5DFA52D302F8;reusable::SelectStatement { -> F}

class DllExport ATMTransaction : public segment::PersistentSegment  //## Inherits: <unnamed>%5C5C2C0E014E
{
  //## begin atm::ATMTransaction%5C5C2BD20292.initialDeclarations preserve=yes
  public:
      enum SumType
      {
         CASSETTES = 0,
         CASH,
         CHECK,
         TELLER,
         CASSETTE1,
         CASSETTE2,
         CASSETTE3,
         CASSETTE4,
         CASSETTE5,
         CASSETTE6,
         CASSETTE7,
         CASSETTE8,
         TOTAL_CASSETTE1,
         TOTAL_CASSETTE2,
         TOTAL_CASSETTE3,
         TOTAL_CASSETTE4,
         TOTAL_CASSETTE5,
         TOTAL_CASSETTE6,
         TOTAL_CASSETTE7,
         TOTAL_CASSETTE8
      };
  //## end atm::ATMTransaction%5C5C2BD20292.initialDeclarations

  public:
    //## Constructors (generated)
      ATMTransaction();

    //## Destructor (generated)
      virtual ~ATMTransaction();


    //## Other Operations (specified)
      //## Operation: bind%5C5C39D90290
      void bind (Query& hQuery, const reusable::string& strTable);

      //## Operation: bind%5C5CAF1D0372
      void bind (Query& hQuery, const reusable::string& strTable, const string& strChildTable);

      //## Operation: fields%5C5C2C1C0356
      virtual struct  Fields* fields () const;

      //## Operation: getAMT_SURCHARGE%5C64C212029B
      int getAMT_SURCHARGE ();

      //## Operation: getCAN_ITEM_VALUEn%5D5D50E00334
      int getCAN_ITEM_VALUEn (int iIndex)
      {
        //## begin atm::ATMTransaction::getCAN_ITEM_VALUEn%5D5D50E00334.body preserve=yes
         return m_iCAN_ITEM_VALUEn[iIndex];
        //## end atm::ATMTransaction::getCAN_ITEM_VALUEn%5D5D50E00334.body
      }

      //## Operation: getCAN_NO_ITEMS_DISPn%5D5D50F702A4
      short getCAN_NO_ITEMS_DISPn (int iIndex)
      {
        //## begin atm::ATMTransaction::getCAN_NO_ITEMS_DISPn%5D5D50F702A4.body preserve=yes
         return m_siCAN_NO_ITEMS_DISPn[iIndex];
        //## end atm::ATMTransaction::getCAN_NO_ITEMS_DISPn%5D5D50F702A4.body
      }

      //## Operation: getCAN_ORIG_NO_ITEMSn%5D5D50FF028F
      short getCAN_ORIG_NO_ITEMSn (int iIndex)
      {
        //## begin atm::ATMTransaction::getCAN_ORIG_NO_ITEMSn%5D5D50FF028F.body preserve=yes
         return m_siCAN_ORIG_NO_ITEMSn[iIndex];
        //## end atm::ATMTransaction::getCAN_ORIG_NO_ITEMSn%5D5D50FF028F.body
      }

      //## Operation: getCredit%5C5DE1530309
      double getCredit (int iIndex)
      {
        //## begin atm::ATMTransaction::getCredit%5C5DE1530309.body preserve=yes
         return m_dCredit[iIndex];
        //## end atm::ATMTransaction::getCredit%5C5DE1530309.body
      }

      //## Operation: getCUR_CODE%5DB89F0C0354
      const reusable::string& getCUR_CODE (int iIndex = 0)
      {
        //## begin atm::ATMTransaction::getCUR_CODE%5DB89F0C0354.body preserve=yes
         return m_strCUR_CODE[iIndex];
        //## end atm::ATMTransaction::getCUR_CODE%5DB89F0C0354.body
      }

      //## Operation: getCUR_TYPE%5D93C826027B
      int getCUR_TYPE (int iIndex = 0)
      {
        //## begin atm::ATMTransaction::getCUR_TYPE%5D93C826027B.body preserve=yes
         return m_siCUR_TYPE[iIndex];
        //## end atm::ATMTransaction::getCUR_TYPE%5D93C826027B.body
      }

      //## Operation: getDebit%5C5DE0D00110
      double getDebit (int iIndex)
      {
        //## begin atm::ATMTransaction::getDebit%5C5DE0D00110.body preserve=yes
         return m_dDebit[iIndex];
        //## end atm::ATMTransaction::getDebit%5C5DE0D00110.body
      }

      //## Operation: getITEM_COUNT%5D93F9C70345
      int getITEM_COUNT (int iIndex = 0)
      {
        //## begin atm::ATMTransaction::getITEM_COUNT%5D93F9C70345.body preserve=yes
         return m_iITEM_COUNT[iIndex];
        //## end atm::ATMTransaction::getITEM_COUNT%5D93F9C70345.body
      }

      //## Operation: getITEM_VALUE%5D93F9C90061
      int getITEM_VALUE (int iIndex = 0)
      {
        //## begin atm::ATMTransaction::getITEM_VALUE%5D93F9C90061.body preserve=yes
         return m_iITEM_VALUE[iIndex];
        //## end atm::ATMTransaction::getITEM_VALUE%5D93F9C90061.body
      }

      //## Operation: reset%5D03B4E0038C
      virtual void reset ();

      //## Operation: setActivity%5C5C920B0116
      void setActivity (int iIndex, reusable::Table& hTable, atm::ATMEvent* pATMEvent = 0);

      //## Operation: setCAN_ITEM_VALUEn%5D52D6170236
      void setCAN_ITEM_VALUEn (int iCAN_ITEM_VALUEn, int iIndex)
      {
        //## begin atm::ATMTransaction::setCAN_ITEM_VALUEn%5D52D6170236.body preserve=yes
         m_iCAN_ITEM_VALUEn[iIndex] = iCAN_ITEM_VALUEn;
        //## end atm::ATMTransaction::setCAN_ITEM_VALUEn%5D52D6170236.body
      }

      //## Operation: setCAN_NO_ITEMS_DISPn%5D52D6550211
      void setCAN_NO_ITEMS_DISPn (short siCAN_NO_ITEMS_DISPn, int iIndex)
      {
        //## begin atm::ATMTransaction::setCAN_NO_ITEMS_DISPn%5D52D6550211.body preserve=yes
         m_siCAN_NO_ITEMS_DISPn[iIndex] = siCAN_NO_ITEMS_DISPn;
        //## end atm::ATMTransaction::setCAN_NO_ITEMS_DISPn%5D52D6550211.body
      }

      //## Operation: setCAN_ORIG_NO_ITEMSn%5D52D6580388
      void setCAN_ORIG_NO_ITEMSn (short siCAN_ORIG_NO_ITEMSn, int iIndex)
      {
        //## begin atm::ATMTransaction::setCAN_ORIG_NO_ITEMSn%5D52D6580388.body preserve=yes
         m_siCAN_ORIG_NO_ITEMSn[iIndex] = siCAN_ORIG_NO_ITEMSn;
        //## end atm::ATMTransaction::setCAN_ORIG_NO_ITEMSn%5D52D6580388.body
      }

      //## Operation: setCredit%5C5DE15502E1
      void setCredit (int iIndex, double dValue)
      {
        //## begin atm::ATMTransaction::setCredit%5C5DE15502E1.body preserve=yes
         m_dCredit[iIndex] = dValue;
        //## end atm::ATMTransaction::setCredit%5C5DE15502E1.body
      }

      //## Operation: setCUR_CODE%5DEEA51D0266
      void setCUR_CODE (const reusable::string& strCUR_CODE, int iIndex = 0)
      {
        //## begin atm::ATMTransaction::setCUR_CODE%5DEEA51D0266.body preserve=yes
         m_strCUR_CODE[iIndex] = strCUR_CODE;
        //## end atm::ATMTransaction::setCUR_CODE%5DEEA51D0266.body
      }

      //## Operation: setCUR_TYPE%5D93C81B0152
      void setCUR_TYPE (short siCUR_TYPE, int iIndex = 0)
      {
        //## begin atm::ATMTransaction::setCUR_TYPE%5D93C81B0152.body preserve=yes
         m_siCUR_TYPE[iIndex] = siCUR_TYPE;
        //## end atm::ATMTransaction::setCUR_TYPE%5D93C81B0152.body
      }

      //## Operation: setDebit%5C5DE0D900A6
      void setDebit (int iIndex, double dValue)
      {
        //## begin atm::ATMTransaction::setDebit%5C5DE0D900A6.body preserve=yes
         m_dDebit[iIndex] = dValue;
        //## end atm::ATMTransaction::setDebit%5C5DE0D900A6.body
      }

      //## Operation: setF_AMTn%5DEEA2C10389
      void setF_AMTn (int iF_AMTn, int iIndex)
      {
        //## begin atm::ATMTransaction::setF_AMTn%5DEEA2C10389.body preserve=yes
         m_iF_AMTn[iIndex] = iF_AMTn;
        //## end atm::ATMTransaction::setF_AMTn%5DEEA2C10389.body
      }

      //## Operation: setF_TYPEn%5DEEA255018A
      void setF_TYPEn (const reusable::string& strF_TYPEn, int iIndex)
      {
        //## begin atm::ATMTransaction::setF_TYPEn%5DEEA255018A.body preserve=yes
         m_strF_TYPEn[iIndex] = strF_TYPEn;
        //## end atm::ATMTransaction::setF_TYPEn%5DEEA255018A.body
      }

      //## Operation: setWithdrawal%5DF90698027C
      void setWithdrawal (const reusable::string& strIMPACT_TO_ACQ, atm::ATMEvent* pATMEvent);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ACTIVITY_GROUP%5C61804101B0
      const int& getACTIVITY_GROUP () const
      {
        //## begin atm::ATMTransaction::getACTIVITY_GROUP%5C61804101B0.get preserve=no
        return m_iACTIVITY_GROUP;
        //## end atm::ATMTransaction::getACTIVITY_GROUP%5C61804101B0.get
      }

      void setACTIVITY_GROUP (const int& value)
      {
        //## begin atm::ATMTransaction::setACTIVITY_GROUP%5C61804101B0.set preserve=no
        m_iACTIVITY_GROUP = value;
        //## end atm::ATMTransaction::setACTIVITY_GROUP%5C61804101B0.set
      }


      //## Attribute: ACTIVITY_TYPE%5C61F1050037
      const int& getACTIVITY_TYPE () const
      {
        //## begin atm::ATMTransaction::getACTIVITY_TYPE%5C61F1050037.get preserve=no
        return m_iACTIVITY_TYPE;
        //## end atm::ATMTransaction::getACTIVITY_TYPE%5C61F1050037.get
      }

      void setACTIVITY_TYPE (const int& value)
      {
        //## begin atm::ATMTransaction::setACTIVITY_TYPE%5C61F1050037.set preserve=no
        m_iACTIVITY_TYPE = value;
        //## end atm::ATMTransaction::setACTIVITY_TYPE%5C61F1050037.set
      }


      //## Attribute: AMT_CHECK%5C5CAE45020C
      const double& getAMT_CHECK () const
      {
        //## begin atm::ATMTransaction::getAMT_CHECK%5C5CAE45020C.get preserve=no
        return m_dAMT_CHECK;
        //## end atm::ATMTransaction::getAMT_CHECK%5C5CAE45020C.get
      }

      void setAMT_CHECK (const double& value)
      {
        //## begin atm::ATMTransaction::setAMT_CHECK%5C5CAE45020C.set preserve=no
        m_dAMT_CHECK = value;
        //## end atm::ATMTransaction::setAMT_CHECK%5C5CAE45020C.set
      }


      //## Attribute: AMT_RECON_NET%5C5C2D840043
      const double& getAMT_RECON_NET () const
      {
        //## begin atm::ATMTransaction::getAMT_RECON_NET%5C5C2D840043.get preserve=no
        return m_dAMT_RECON_NET;
        //## end atm::ATMTransaction::getAMT_RECON_NET%5C5C2D840043.get
      }

      void setAMT_RECON_NET (const double& value)
      {
        //## begin atm::ATMTransaction::setAMT_RECON_NET%5C5C2D840043.set preserve=no
        m_dAMT_RECON_NET = value;
        //## end atm::ATMTransaction::setAMT_RECON_NET%5C5C2D840043.set
      }


      //## Attribute: AMT_TELLER%5D77EB820003
      const double& getAMT_TELLER () const
      {
        //## begin atm::ATMTransaction::getAMT_TELLER%5D77EB820003.get preserve=no
        return m_dAMT_TELLER;
        //## end atm::ATMTransaction::getAMT_TELLER%5D77EB820003.get
      }

      void setAMT_TELLER (const double& value)
      {
        //## begin atm::ATMTransaction::setAMT_TELLER%5D77EB820003.set preserve=no
        m_dAMT_TELLER = value;
        //## end atm::ATMTransaction::setAMT_TELLER%5D77EB820003.set
      }


      //## Attribute: AMT_TRAN%5DF949270250
      const double& getAMT_TRAN () const
      {
        //## begin atm::ATMTransaction::getAMT_TRAN%5DF949270250.get preserve=no
        return m_dAMT_TRAN;
        //## end atm::ATMTransaction::getAMT_TRAN%5DF949270250.get
      }

      void setAMT_TRAN (const double& value)
      {
        //## begin atm::ATMTransaction::setAMT_TRAN%5DF949270250.set preserve=no
        m_dAMT_TRAN = value;
        //## end atm::ATMTransaction::setAMT_TRAN%5DF949270250.set
      }


      //## Attribute: AMT_USER%5D77EB830319
      const double& getAMT_USER () const
      {
        //## begin atm::ATMTransaction::getAMT_USER%5D77EB830319.get preserve=no
        return m_dAMT_USER;
        //## end atm::ATMTransaction::getAMT_USER%5D77EB830319.get
      }

      void setAMT_USER (const double& value)
      {
        //## begin atm::ATMTransaction::setAMT_USER%5D77EB830319.set preserve=no
        m_dAMT_USER = value;
        //## end atm::ATMTransaction::setAMT_USER%5D77EB830319.set
      }


      //## Attribute: CUR_RECON_NET%5C5C52C701CC
      const reusable::string& getCUR_RECON_NET () const
      {
        //## begin atm::ATMTransaction::getCUR_RECON_NET%5C5C52C701CC.get preserve=no
        return m_strCUR_RECON_NET;
        //## end atm::ATMTransaction::getCUR_RECON_NET%5C5C52C701CC.get
      }

      void setCUR_RECON_NET (const reusable::string& value)
      {
        //## begin atm::ATMTransaction::setCUR_RECON_NET%5C5C52C701CC.set preserve=no
        m_strCUR_RECON_NET = value;
        //## end atm::ATMTransaction::setCUR_RECON_NET%5C5C52C701CC.set
      }


      //## Attribute: FUNC_CODE%5DFA71ED011F
      const reusable::string& getFUNC_CODE () const
      {
        //## begin atm::ATMTransaction::getFUNC_CODE%5DFA71ED011F.get preserve=no
        return m_strFUNC_CODE;
        //## end atm::ATMTransaction::getFUNC_CODE%5DFA71ED011F.get
      }

      void setFUNC_CODE (const reusable::string& value)
      {
        //## begin atm::ATMTransaction::setFUNC_CODE%5DFA71ED011F.set preserve=no
        m_strFUNC_CODE = value;
        //## end atm::ATMTransaction::setFUNC_CODE%5DFA71ED011F.set
      }


      //## Attribute: INST_ID_RECN_ACQ_B%5C5C93A80087
      const reusable::string& getINST_ID_RECN_ACQ_B () const
      {
        //## begin atm::ATMTransaction::getINST_ID_RECN_ACQ_B%5C5C93A80087.get preserve=no
        return m_strINST_ID_RECN_ACQ_B;
        //## end atm::ATMTransaction::getINST_ID_RECN_ACQ_B%5C5C93A80087.get
      }

      void setINST_ID_RECN_ACQ_B (const reusable::string& value)
      {
        //## begin atm::ATMTransaction::setINST_ID_RECN_ACQ_B%5C5C93A80087.set preserve=no
        m_strINST_ID_RECN_ACQ_B = value;
        //## end atm::ATMTransaction::setINST_ID_RECN_ACQ_B%5C5C93A80087.set
      }


      //## Attribute: INST_ID_RECN_ISS_B%5C5C93A80121
      const reusable::string& getINST_ID_RECN_ISS_B () const
      {
        //## begin atm::ATMTransaction::getINST_ID_RECN_ISS_B%5C5C93A80121.get preserve=no
        return m_strINST_ID_RECN_ISS_B;
        //## end atm::ATMTransaction::getINST_ID_RECN_ISS_B%5C5C93A80121.get
      }

      void setINST_ID_RECN_ISS_B (const reusable::string& value)
      {
        //## begin atm::ATMTransaction::setINST_ID_RECN_ISS_B%5C5C93A80121.set preserve=no
        m_strINST_ID_RECN_ISS_B = value;
        //## end atm::ATMTransaction::setINST_ID_RECN_ISS_B%5C5C93A80121.set
      }


      //## Attribute: NET_TERM_ID%5DFA51A80210
      const reusable::string& getNET_TERM_ID () const
      {
        //## begin atm::ATMTransaction::getNET_TERM_ID%5DFA51A80210.get preserve=no
        return m_strNET_TERM_ID;
        //## end atm::ATMTransaction::getNET_TERM_ID%5DFA51A80210.get
      }

      void setNET_TERM_ID (const reusable::string& value)
      {
        //## begin atm::ATMTransaction::setNET_TERM_ID%5DFA51A80210.set preserve=no
        m_strNET_TERM_ID = value;
        //## end atm::ATMTransaction::setNET_TERM_ID%5DFA51A80210.set
      }


      //## Attribute: O_AMT_TRAN%5DF949560329
      const double& getO_AMT_TRAN () const
      {
        //## begin atm::ATMTransaction::getO_AMT_TRAN%5DF949560329.get preserve=no
        return m_dO_AMT_TRAN;
        //## end atm::ATMTransaction::getO_AMT_TRAN%5DF949560329.get
      }

      void setO_AMT_TRAN (const double& value)
      {
        //## begin atm::ATMTransaction::setO_AMT_TRAN%5DF949560329.set preserve=no
        m_dO_AMT_TRAN = value;
        //## end atm::ATMTransaction::setO_AMT_TRAN%5DF949560329.set
      }


      //## Attribute: STATUS%5C5CAE5602B8
      const reusable::string& getSTATUS () const
      {
        //## begin atm::ATMTransaction::getSTATUS%5C5CAE5602B8.get preserve=no
        return m_strSTATUS;
        //## end atm::ATMTransaction::getSTATUS%5C5CAE5602B8.get
      }

      void setSTATUS (const reusable::string& value)
      {
        //## begin atm::ATMTransaction::setSTATUS%5C5CAE5602B8.set preserve=no
        m_strSTATUS = value;
        //## end atm::ATMTransaction::setSTATUS%5C5CAE5602B8.set
      }


      //## Attribute: TRAN_DISPOSITION%5C5C2D7900D7
      const reusable::string& getTRAN_DISPOSITION () const
      {
        //## begin atm::ATMTransaction::getTRAN_DISPOSITION%5C5C2D7900D7.get preserve=no
        return m_strTRAN_DISPOSITION;
        //## end atm::ATMTransaction::getTRAN_DISPOSITION%5C5C2D7900D7.get
      }

      void setTRAN_DISPOSITION (const reusable::string& value)
      {
        //## begin atm::ATMTransaction::setTRAN_DISPOSITION%5C5C2D7900D7.set preserve=no
        m_strTRAN_DISPOSITION = value;
        //## end atm::ATMTransaction::setTRAN_DISPOSITION%5C5C2D7900D7.set
      }


      //## Attribute: TRAN_TYPE_ID%5C5C2D540164
      const reusable::string& getTRAN_TYPE_ID () const
      {
        //## begin atm::ATMTransaction::getTRAN_TYPE_ID%5C5C2D540164.get preserve=no
        return m_strTRAN_TYPE_ID;
        //## end atm::ATMTransaction::getTRAN_TYPE_ID%5C5C2D540164.get
      }

      void setTRAN_TYPE_ID (const reusable::string& value)
      {
        //## begin atm::ATMTransaction::setTRAN_TYPE_ID%5C5C2D540164.set preserve=no
        m_strTRAN_TYPE_ID = value;
        //## end atm::ATMTransaction::setTRAN_TYPE_ID%5C5C2D540164.set
      }


    // Additional Public Declarations
      //## begin atm::ATMTransaction%5C5C2BD20292.public preserve=yes
      //## end atm::ATMTransaction%5C5C2BD20292.public

  protected:
    // Additional Protected Declarations
      //## begin atm::ATMTransaction%5C5C2BD20292.protected preserve=yes
      //## end atm::ATMTransaction%5C5C2BD20292.protected

  private:
    // Additional Private Declarations
      //## begin atm::ATMTransaction%5C5C2BD20292.private preserve=yes
      //## end atm::ATMTransaction%5C5C2BD20292.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin atm::ATMTransaction::ACTIVITY_GROUP%5C61804101B0.attr preserve=no  public: int {V} 0
      int m_iACTIVITY_GROUP;
      //## end atm::ATMTransaction::ACTIVITY_GROUP%5C61804101B0.attr

      //## begin atm::ATMTransaction::ACTIVITY_TYPE%5C61F1050037.attr preserve=no  public: int {V} 0
      int m_iACTIVITY_TYPE;
      //## end atm::ATMTransaction::ACTIVITY_TYPE%5C61F1050037.attr

      //## Attribute: hACTIVITY_TYPE%5C5C95B90309
      //## begin atm::ATMTransaction::hACTIVITY_TYPE%5C5C95B90309.attr preserve=no  private: map<string,pair<int,int>,less<string> > {V} 
      map<string,pair<int,int>,less<string> > m_hACTIVITY_TYPE;
      //## end atm::ATMTransaction::hACTIVITY_TYPE%5C5C95B90309.attr

      //## begin atm::ATMTransaction::AMT_CHECK%5C5CAE45020C.attr preserve=no  public: double {V} 0
      double m_dAMT_CHECK;
      //## end atm::ATMTransaction::AMT_CHECK%5C5CAE45020C.attr

      //## begin atm::ATMTransaction::AMT_RECON_NET%5C5C2D840043.attr preserve=no  public: double {V} 0
      double m_dAMT_RECON_NET;
      //## end atm::ATMTransaction::AMT_RECON_NET%5C5C2D840043.attr

      //## begin atm::ATMTransaction::AMT_TELLER%5D77EB820003.attr preserve=no  public: double {V} 0
      double m_dAMT_TELLER;
      //## end atm::ATMTransaction::AMT_TELLER%5D77EB820003.attr

      //## begin atm::ATMTransaction::AMT_TRAN%5DF949270250.attr preserve=no  public: double {V} 0
      double m_dAMT_TRAN;
      //## end atm::ATMTransaction::AMT_TRAN%5DF949270250.attr

      //## begin atm::ATMTransaction::AMT_USER%5D77EB830319.attr preserve=no  public: double {V} 0
      double m_dAMT_USER;
      //## end atm::ATMTransaction::AMT_USER%5D77EB830319.attr

      //## Attribute: Debit%5C5DB28500DC
      //## begin atm::ATMTransaction::Debit%5C5DB28500DC.attr preserve=no  public: double[20] {V} 
      double m_dDebit[20];
      //## end atm::ATMTransaction::Debit%5C5DB28500DC.attr

      //## Attribute: CAN_ITEM_VALUEn%5D02629A0134
      //## begin atm::ATMTransaction::CAN_ITEM_VALUEn%5D02629A0134.attr preserve=no  public: int[8] {V} 
      int m_iCAN_ITEM_VALUEn[8];
      //## end atm::ATMTransaction::CAN_ITEM_VALUEn%5D02629A0134.attr

      //## Attribute: CAN_NO_ITEMS_DISPn%5D0262BC00FA
      //## begin atm::ATMTransaction::CAN_NO_ITEMS_DISPn%5D0262BC00FA.attr preserve=no  public: short[8] {V} 
      short m_siCAN_NO_ITEMS_DISPn[8];
      //## end atm::ATMTransaction::CAN_NO_ITEMS_DISPn%5D0262BC00FA.attr

      //## Attribute: CAN_ORIG_NO_ITEMSn%5D12320E0288
      //## begin atm::ATMTransaction::CAN_ORIG_NO_ITEMSn%5D12320E0288.attr preserve=no  public: short[8] {V} 
      short m_siCAN_ORIG_NO_ITEMSn[8];
      //## end atm::ATMTransaction::CAN_ORIG_NO_ITEMSn%5D12320E0288.attr

      //## Attribute: Credit%5C5DB28D01A4
      //## begin atm::ATMTransaction::Credit%5C5DB28D01A4.attr preserve=no  public: double[20] {V} 
      double m_dCredit[20];
      //## end atm::ATMTransaction::Credit%5C5DB28D01A4.attr

      //## Attribute: CUR_CODE%5DB89EC80345
      //## begin atm::ATMTransaction::CUR_CODE%5DB89EC80345.attr preserve=no  public: reusable::string[20] {V} 
      reusable::string m_strCUR_CODE[20];
      //## end atm::ATMTransaction::CUR_CODE%5DB89EC80345.attr

      //## begin atm::ATMTransaction::CUR_RECON_NET%5C5C52C701CC.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strCUR_RECON_NET;
      //## end atm::ATMTransaction::CUR_RECON_NET%5C5C52C701CC.attr

      //## Attribute: CUR_TYPE%5D54603E018C
      //## begin atm::ATMTransaction::CUR_TYPE%5D54603E018C.attr preserve=no  public: short[20] {V} 
      short m_siCUR_TYPE[20];
      //## end atm::ATMTransaction::CUR_TYPE%5D54603E018C.attr

      //## Attribute: F_AMTn%5C64BBD200A5
      //## begin atm::ATMTransaction::F_AMTn%5C64BBD200A5.attr preserve=no  public: int[6] {V} 
      int m_iF_AMTn[6];
      //## end atm::ATMTransaction::F_AMTn%5C64BBD200A5.attr

      //## Attribute: F_TYPEn%5C64BB760047
      //## begin atm::ATMTransaction::F_TYPEn%5C64BB760047.attr preserve=no  public: reusable::string[6] {V} 
      reusable::string m_strF_TYPEn[6];
      //## end atm::ATMTransaction::F_TYPEn%5C64BB760047.attr

      //## begin atm::ATMTransaction::FUNC_CODE%5DFA71ED011F.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strFUNC_CODE;
      //## end atm::ATMTransaction::FUNC_CODE%5DFA71ED011F.attr

      //## begin atm::ATMTransaction::INST_ID_RECN_ACQ_B%5C5C93A80087.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strINST_ID_RECN_ACQ_B;
      //## end atm::ATMTransaction::INST_ID_RECN_ACQ_B%5C5C93A80087.attr

      //## begin atm::ATMTransaction::INST_ID_RECN_ISS_B%5C5C93A80121.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strINST_ID_RECN_ISS_B;
      //## end atm::ATMTransaction::INST_ID_RECN_ISS_B%5C5C93A80121.attr

      //## Attribute: ITEM_COUNT%5C5CAD1103B2
      //## begin atm::ATMTransaction::ITEM_COUNT%5C5CAD1103B2.attr preserve=no  public: int[12] {V} 
      int m_iITEM_COUNT[12];
      //## end atm::ATMTransaction::ITEM_COUNT%5C5CAD1103B2.attr

      //## Attribute: ITEM_VALUE%5C5CACF6025F
      //## begin atm::ATMTransaction::ITEM_VALUE%5C5CACF6025F.attr preserve=no  public: int[20] {V} 
      int m_iITEM_VALUE[20];
      //## end atm::ATMTransaction::ITEM_VALUE%5C5CACF6025F.attr

      //## begin atm::ATMTransaction::NET_TERM_ID%5DFA51A80210.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strNET_TERM_ID;
      //## end atm::ATMTransaction::NET_TERM_ID%5DFA51A80210.attr

      //## begin atm::ATMTransaction::O_AMT_TRAN%5DF949560329.attr preserve=no  public: double {V} 0
      double m_dO_AMT_TRAN;
      //## end atm::ATMTransaction::O_AMT_TRAN%5DF949560329.attr

      //## begin atm::ATMTransaction::STATUS%5C5CAE5602B8.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strSTATUS;
      //## end atm::ATMTransaction::STATUS%5C5CAE5602B8.attr

      //## begin atm::ATMTransaction::TRAN_DISPOSITION%5C5C2D7900D7.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strTRAN_DISPOSITION;
      //## end atm::ATMTransaction::TRAN_DISPOSITION%5C5C2D7900D7.attr

      //## begin atm::ATMTransaction::TRAN_TYPE_ID%5C5C2D540164.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strTRAN_TYPE_ID;
      //## end atm::ATMTransaction::TRAN_TYPE_ID%5C5C2D540164.attr

    // Additional Implementation Declarations
      //## begin atm::ATMTransaction%5C5C2BD20292.implementation preserve=yes
      //## end atm::ATMTransaction%5C5C2BD20292.implementation

};

//## begin atm::ATMTransaction%5C5C2BD20292.postscript preserve=yes
//## end atm::ATMTransaction%5C5C2BD20292.postscript

} // namespace atm

//## begin module%5C5C2CE600CD.epilog preserve=yes
//## end module%5C5C2CE600CD.epilog


#endif
