//quicksort

int arr[] = { };
int n = sizeof(arr)/sizeof(arr[0]);

quicksort(arr,0,n-1);


void display(int arr[],int size)
{
   for(int i=0;i<size;i++)
   {
      cout << arr[i] << " " ;
   }
}


void swap(int *a,int *b)
{
  int temp = *a;
  *a  = *b;
  *b = temp;
}

void quicksort(int arr[],int low, int high)
{
   if(low < high)
   {
       int pi = partition(arr,low,high);
	   
	   quicksort(arr,low,pi-1);
	   quicksort(arr,pi+1,high);
   }
}

int partition(int arr[],int low,int high)
{
   int pivot = arr[high];
   int i = low-1;
   for(int j=0;j<=high-1;j++)
   {
      if(arr[j] <= pivot)
	  { 
	     i++;
		 swap(&arr[i], &arr[j]);
	  }
   }
   swap(&arr[i+1],&arr[high]);
   return(i+1);
}




//sum of pair indexes

int arr[] = {1,5,7,-1,5};
int n = sizeof(arr)/sizeof(arr[0]);
int sum =6;

sumofpairs(arr,n,sum);

int sumofpairs(int arr[],int n,int sum)
{
   for(int i=0;i<n;i++)
     for(int j=i+1;j<n;j++)
	   if(arr[i] + arr[j] == sum)
	      cout << "(" << arr[i] << " "
		              << arr[j] << ")" << endl;
}




// reverseword and strrev

strrev:

char str[];
char rev[];
int count=0;
int begin, end;

while(str[count] != '\0')
    count++;

	end = count -1;
	for(begin=0;begin<end;begin++)
	{
	   rev[begin] = str[end];
	   end--;
	}
	rev[begin] = '\0';

	
//reverseword:


string reverseword(string str)
{
   int i = str.length()-1;
   int start, end= i+1;
   string result=" ";
   
   while(i >0)
   {
      if(str[i] == ' ')
	  {
	      start = i+1;
		  while(start != end)
		   result += str[start++];
		 
		 result += ' ';
		 end = i;
	  }
	  i--;
	}
	start =0;
	while(start != end)
	  result += str[start++];
	
	return result;
}

//reverse string

char str[];
char rev[];
int start,end;
int count=0;

while(str[count] !=  '\0')
   count++;
   
   end = count-1;
   
   for(start=0;start<count;start++)
   {
      rev[start] = str[end];
	  end--;
   }
   rev[start] = '\0';

   

   
// Is Tree balanced r not

bool is balanced(node *root, int height)
{
   int lh = 0,rh=0;
   int l=0,r=0;
   
   if(root == NULL)
   {
       height = 0;
	   return 1;
   }
   
   l = isbalanced(root->left,&lh);
   r = isbalanced(root->right,&rh);
   
   height = (lh > rh ? lh : rh) + 1;
   
   if(lh -rh >= 2)
      return 0;

	else
	 return l && r;
}

   
   
//remove duplicates in string

char *removeduplicates(char str[], int n)
{
   int index=0;
   
   for(int i=0;i<n;i++)
   {
       for(int j=0;j<n;j++)
	   
	      if(str[i] == str[j] )
		    break;
		
		if(j == i)
		str[index++] = str[i];
	}
	retrun str;
}



   
   
   
