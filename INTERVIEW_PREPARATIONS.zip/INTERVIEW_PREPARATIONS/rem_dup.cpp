#include<iostream>
#include<string.h>

using namespace std;



void non_repeat()
{
     char str[] = "xyzxyzabcde";
	 int i,j,k;
	 
	 cout << str << endl;
	 for(i=0;i<strlen(str); i++)
	 {
	 	   for(j=i+1;str[j]!= '\0'; j++)
	 	   {
	 	       if(str[i] ==  str[j])	
	 	       {
	 	            for(k=j;str[k] != '\0'; k++)
					{
					    str[k] = str[k+1];
					}	
			   }
		   }
	 }
	 
	 
	 cout << str << endl;

}


int main()
{
	non_repeat();
	
}
