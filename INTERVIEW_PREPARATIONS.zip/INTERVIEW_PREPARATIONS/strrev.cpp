#include<iostream>
/*  
string reverseword(string str)
{
    int i   = str.length() -1;
    int start, end = i+1;
    string result = " ";
    
    while(i > 0)
    {
        if(str[i] == ' ')
        {
           start = i+1;
           while(start != end)
            result += str[start++];
          
          result += ' ';
          end  = i;
        }
        i--;
    }
    start=0;
    while(start != end)
    result += str[start++];
    
  return result;
*/
using namespace std;

int main()
{
	char str[100] = "vamshi krishna";
	int count =0;
	char rev[100];
	int begin, end;
	
	
	while(str[count] != '\0')
	   count++;
	   
	end = count -1;
	
	for(begin=0;begin <count;begin++)
	{
		rev[begin]  = str[end];
		end--; 
	}
	
	rev[begin] = '\0';
	
	cout << rev << endl;
}
