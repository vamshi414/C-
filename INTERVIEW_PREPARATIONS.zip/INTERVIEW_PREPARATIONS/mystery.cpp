#include<iostream>

using namespace std;

int revnumber(int n)
{
	 int rev=0,reminder;
 
     while( n != 0)
     {
     	 reminder  = n % 10;
     	 rev = rev * 10 + reminder;
     	 n/= 10;
	 }
	 return rev;
}

bool mysterynum(int num)
{
	
	for(int i=1; i<= num/2; i++)
	{
		int j = revnumber(i);
		
		if (i+j == num)
		{
			 cout << i << " " << j << endl;
			 cout << "mystery number" << endl;
			 return true;
		}
		
	}

	cout << "Not Mystery number" << endl;
	return false;
}


int main()
{
	int num = 121;	
	mysterynum(num);
	
}



