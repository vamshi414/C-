// program to keep tracking stack max value

#include<iostream>
#include<stack>
using namespace std;

class Stackmaxvalue {
	
	stack<int> mainstack;
	
	stack<int> trackstack;
	
	public:
		
		void push(int x)
		{
			mainstack.push(x);
			
			if(mainstack.size() == 1)
			{
				trackstack.push(x);
				return;
			}
			
			if( x > trackstack.top())
			{
				trackstack.push(x);
			}
			else
			{
				trackstack.push(trackstack.top());
			}
		}
		
		int getmax()
		{
			return trackstack.top();
		}
		
		int pop()
		{
			 mainstack.pop();
			 trackstack.pop();
		}
};


int main()
{
	Stackmaxvalue s;
	
	s.push(20);
	
	//cout << s.getmax() << endl;
	
	s.push(10);
	//cout << s.getmax() << endl;
	
	//s = s.pop(20);
	s.push(100);
	cout << s.getmax() << endl;
}


