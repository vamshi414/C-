// palindrome string
#include<iostream>
#include<string.h>

using namespace std;


void ispalindrome(char str[])
{
	int l=0;
	int h = strlen(str)- 1;
	
	while(h > l)
	{
		 if(str[l++] != str[h--])
		 {
		 	cout << "Not palindrome" << endl;
		 	return;
		 }
	}
	
	cout << "Palindrome" << endl;
}

int main()
{
	ispalindrome("");
}
