#include<iostream>

using namespace std;

class String {
     int size_;
     char *ptr;

     int strlen(char *str)
     {
         char *p = (char*)str;
         int len=0;
         while(*p++)
           len++;
         return len;
     }

     char *strcpy(char *dest, const char *src)
     {
         char *s = (char*)src;
         char *d = (char*)dest;
        
         while(*d++ = *s++); 
         return dest;
     }

     char *strcat(char *dest, const char *src)
     {
         char *s = (char*)src;
         char *d = (char*)dest;
 
         while(*d)
             d++;
         while(*d++ = *s++);
            return dest;
     }

     public:
        
        String() : size_(1), ptr(new char[1]) { *ptr = '\0'; }
       ~String() { delete[] ptr; }
  
 
        int size() const
        {
           return size_;
        }
 
        const char *c_str() const
        {
           return ptr;
        }

        String(char *str)
        {
            size_ = strlen(str);
            ptr = new char[size_];
            strcpy(ptr,str);
        }

        String(const String& string)
        {
           size_ = string.size();
           ptr = new char[size_];
           strcpy(ptr,string.c_str());
        }

        String& operator = (const String& string)
        {
            if(this == &string)
            {
                cout << "skipping if address r same" << endl;
                return *this;
            }
            delete[] ptr; 
            size_ = string.size();
            ptr = new char[size_];
            strcpy(ptr,string.c_str());
        }


       String operator + (const String& string)
       {
           String temp;
           temp.size_ = size_ + string.size_;
           delete[] temp.ptr;
           temp.ptr = new char[temp.size_];

          strcpy(temp.ptr,ptr); 
          strcat(temp.ptr, string.c_str());
          return temp;
       }

       void display()
       {
           cout << ptr << endl;
       }
};


int main()
{
   String s1 = (char*)"vamshi";
   String s2 = (char*)"Rangam";

   s1.display();
   s2.display();
  
   String s3 = s2;
   s3.display();
 
  String s4 = s1+s2;
  s4.display();
} 
