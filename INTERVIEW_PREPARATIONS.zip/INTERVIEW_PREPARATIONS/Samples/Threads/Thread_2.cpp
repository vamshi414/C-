// C++11 Threads
// Join(), detach(), Joinable() 

// if we detached thread and main function is returning then the detached thread execution is suspended
//JOIN:
//once a thread is started we wait for this thread to finish by calling join() on thread object
//double join will result the termination
//if needed, we should check whether it is joinable r not using {joinable() function}
//DETACH:
//this is used to detach newly created thread from the parent thread
//always check before detaching a thread it is joinable otherwise it results the double detachble and results the termination
//if we detach the thread and main function is returned , then the detached thread execution is suspeneded.
// After creating the thread, we should call either join() or Detach() otherwise during thread objects disctructor
//it will terminate the pgm,in desctructor it checked whether it is joinable, if yes, then program terminates.


#include<iostream>
#include<thread>
#include<chrono>

using namespace std;


void func1(int x)
{
	while(x --> 0)
	{
		cout << "Hello" << x << endl;
	   // std::this_thread::sleep_for(chrono::seconds(3));
	    cout << "thread finished" << endl;
	}
}

int main()
{
	std::thread t1(func1,10);
	cout << "in main()" << endl;
	//t1.join();
	
	t1.detach();
	if(t1.joinable())
	{
	
	t1.detach();
	}
	/*if(t1.joinable())
	{
		 t1.join();
	}  */
	
	
	cout << "main() after" << endl;
	std::this_thread::sleep_for(chrono::seconds(3));
}
