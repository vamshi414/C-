// lock_guard n c++11 
// (std::lock_guard<mutex> lock(m1))
// it is wrapper for owning the mutex  on scope basis
// it removes the lock once it goes out of scope

#include<iostream>
#include<thread>
#include<mutex>

using namespace std;

std::mutex m1;
int buffer=0;

void task(const char *threadnumber, int loop)
{
	//m1.lock();
	std::lock_guard<mutex> lock(m1);
	for(int i=0;i<loop;i++)
	{
		buffer++;
		cout << threadnumber << ":" << buffer << endl;
	}
	m1.unlock();
}

int main()
{
	std::thread t1(task, "T1", 2);
	std::thread t2(task, "T2", 2);
	
	t1.join();
	t2.join();
}
