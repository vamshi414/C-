// Mutex in c++11 Threading
//Why mutex: mutual exclusion
// what is Race Condition and how to solve it
// what is critical section/region

//Race Condition:
// It is a sitution where two r more threads trying to change the common data at same time.
//this is called race condition and trying to protect this condition is called critical section/region

//Mutex is used to avoid Race condition
// we use lock() and unlock() on mutex to avoid Race condition

#include<iostream>
#include<thread>
#include<mutex>

using namespace std;

int myamount=0;
std::mutex m;

void addmoney()
{
	m.lock();
    ++myamount;
	m.unlock();	
}

int main()
{
	std::thread t1(addmoney);
	std::thread t2(addmoney);
	
	t1.join();
	t2.join();
	
	cout << "myamount: \t" << myamount << endl;
}

