// Threads

// introduction to threads in C++ 11
//what do you understand by threads ?

// in every application there is a default thread which is main, inside main we can create  other threads
// A thread is liht in weiht, idea is  to acheive parallelism  by diving a process into mulitple threads
//ways to create threads in c++ : function pointer, function objects, lamda, member functions, functors

#include<iostream>
#include<thread>
#include<chrono>
#include<algorithm>

using namespace std;
using namespace std::chrono;

typedef unsigned long long ull;

ull oddsum=0;
ull evensum=0;




void findodd(ull start, ull end)
{
for(ull i=start;i<= end;i++)
{
  if((i & 1) == 1)
  {
    oddsum += i;
  }
}  
}



void findeven(ull start, ull end)
{
 for(ull i=start;i<=end; i++)
 {
    if((i&1) == 0)
    {
       evensum += i;
    }
 }
}



int main()
{
ull start=0, end=1900000000;

auto starttime = high_resolution_clock::now();

std::thread t1(findodd, start, end);
std::thread t2(findeven, start, end);

t1.join();
t2.join();

//findodd(start,end);
//findeven(start,end);

auto stoptime = high_resolution_clock::now();

auto duration = duration_cast<microseconds>(stoptime - starttime );

cout << "oddsum:" << oddsum << endl;
cout << "evensum:" << evensum << endl;
cout << "Time Taken:" << duration.count()/1000000 << endl;
}
