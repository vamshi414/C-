// Recursive_mutes c++11

#include<iostream>
#include<thread>
#include<mutex>

using namespace std;

std::recursive_mutex m1;
int buffer=0;

void recursion(char c, int loop)
{
	if(loop < 0)
	  return ;
	  
	  m1.lock();
	  cout << "Thread ID:" << c <<  "\t" <<  buffer++ << endl;
	  recursion(c,--loop);
	  m1.unlock();
	  cout << "Unlock by thread" << c << endl;
}

int main()
{
	std::thread t1(recursion,'O', 2);
	std::thread t2(recursion,'1', 2);
 
    t1.join();
    t2.join();
}
