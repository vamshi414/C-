// Factory Design Pattern
// Factory :  A utility class that creates an instance of class from a family of derived class
// Abstract Factory : a utility class that creates an instance of serval famlies of classes.it can also return a factory  for certian group
// pblm: we want to decide at run time what object is to be created based on some config.when we write the code , we r not sure which class is initiated
// solution: Define an interface r abtstact class for creating an object, let sub classess decide which class to inititate.

#include<iostream>
#include<memory>
#include<string>

using namespace std;

class Connection {
	
	protected:
		std::string cls;
	public:
		virtual void connect() = 0;
		virtual void write(std::string msg) = 0;
		virtual void read() = 0;
		virtual void disconnect() = 0;
};

class Usb: public Connection {
	Usb() { }
	void connect() override 
	{
		 cout << __func__ << endl;
	}
	void write(std::string msg) override
	{
		cout << __func__ << endl;
	}
	void disconnect()
	{
		cout << __func__ << endl;
	}
	void read()
	{
		cout << __func__ << endl;
	}
};

class Wifi: public Connection {
	Wifi()  { }
	void connect() override 
	{
		cout << __func__ << endl;
	}
	void write(std::string msg) override
    {
    	cout << __func__ << endl;
	}
	void disconnect()
	{
		cout << __func__ << endl;
	}
	void read() override
	{
		cout << __func__ << endl;
	}
};


class Connectionfactory {
	
	public:
		enum Connectionprotocol
		{
			USB,
			WIFI,
			ETHERNET,
			GPRS,
			SERIAL
		};
		
		std::unique_ptr<Connection> get_connection(Connectionfactory::Connectionprotocol protocol)
		{
			switch(protocol)
			{
				
				case Connectionprotocol::USB :  return std::make_unique<Usb>();
				case Connectionprotocol::WIFI : return std::make_unique<Wifi>();
				
				default:   throw "undefined";
			}
		}
};


int main()
{
	auto Connect_factory = std::make_unique<Connectionfactory>();
	auto connection = Connect_factory->
}
