#include<iostream>
//#include<string>

using namespace std;

class String {
	
  private:
	int size_;
	char *ptr;
	
	int strlen(char* str)
	{
		char *p = (char*)str;
		int len=0;
		while(*p++)
		   len++;
		return len;
	}
	
	char *strcpy(char *dest,const char *src)
	{
		char *s = (char*)src;
		char *d = (char*)dest;
		
		while(*d++ = *s++);
		   return dest;
	}
	
	char *strcat(char *dest, const char *src)
	{
		char *s = (char*)src;
		char *d = (char*)dest;
		
		while(*d)
		   d++;
		while(*d++ = *s++);
		   return dest;
	}
	
	public:
		String() : size_(1), ptr(new char[1]) { *ptr = '\0'; }
        //~String() { delete[] ptr; }

		int size() const
		{
			  return size_;
		}
		
		const char *c_str() const
		{
			return ptr;
		}
		
		
		String(char *str)
		{
			size_ = strlen(str);
			size_++;
			ptr = new char[size_];
			strcpy(ptr,str);
		}
		
        String(const String& string)
        {
            size_ = string.size();
            ptr = new char[size_];
            strcpy(ptr, string.c_str());
        }
	
		String& operator = (const String& string)
		{
		  
		    if(this == &string)
			{
		      return *this;		
			}	
			
			size_ = string.size();
			ptr = new char[size_];
			strcpy(ptr,string.c_str());
		}
		
		
        String operator + (const String& string)
        {
            String tmp;
            tmp.size_ = size_ + string.size_;
            delete[] tmp.ptr;
            
            tmp.ptr = new char[tmp.size_];
            strcpy(tmp.ptr, ptr);
            std::cout << __func__ << " 1 : " << tmp.ptr << std::endl;
            strcat(tmp.ptr, string.c_str());
            std::cout << __func__ << " 2 : " << tmp.ptr << std::endl;
            
            return tmp;
        }
 		
		void display() { std::cout << ptr << std::endl; }	
		
};


int main()
{
	
	String s1 = "Vamshi";
	String s2 = "Rangam";
	
	s1.display();
	s2.display();
	
	String s3 = s2;
	s3.display();
	String s4 = s1 + s2;
    s4.display();
}
