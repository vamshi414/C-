#include<iostream>
#include<typeinfo>
using namespace std;


struct SA
{
		virtual ~SA(){}
};
struct SB : SA
{
};
struct SC : SB
{
};
//*******************
void fun(SA* p)
{
	cout<<typeid(*p).name()<<endl;
}
//*******************
int main()
{
	fun(new SB);
}
