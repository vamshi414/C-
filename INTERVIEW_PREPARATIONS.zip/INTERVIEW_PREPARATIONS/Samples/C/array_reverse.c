#include<stdio.h>


void reversearray(int arr[],int start,int end)
{
	int temp;
	while(start<end)
	{
		temp = arr[start];
		arr[start] = arr[end];
		arr[end] = temp;
		start++;
		end--;
	}
}

void printarry(int arr[], int size)
{
	int i=0;
	for(i=0;i<size;i++)
	{
		printf("%d \t", arr[i]);
	}
	printf("\n");
}

int main()
{
	
	int arr[5] = {10,20,30,40,50};
	int i=0;
	int x,y=0,temp;
	int size = sizeof(arr)/ sizeof(arr[0]);
	
	printarry(arr,size);
	reversearray(arr,0,size-1);
	
	printarry(arr,size);

	
}
