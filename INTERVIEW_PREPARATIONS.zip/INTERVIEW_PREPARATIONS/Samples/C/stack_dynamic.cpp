#include<iostream>

using namespace std;

class Stack{
	
	  int totalsize;
	  int currentsize;
	  int *arr;
	  
	  public:
	  	Stack(int size)
	  	{
	  	   this->totalsize = size;
		   this->currentsize = 0;
		   this->arr = new int[this->totalsize];	
		}
		
		bool empty()
		{
			return this->currentsize == 0;
		}
		
		bool isfull()
		{
			return this->currentsize == this->totalsize;
		}
		
		void push(int value)
		{
			if(isfull())
			{
				cout << "Stack is full " << endl;
				
				
			}
			else
			{
				
				this->arr[this->currentsize] = value;
				this->currentsize++;
			}
		}
		
		int pop()
		{
			if(empty())
			{
				cout << "Stack is empty" << endl;
				return -1;
			}
			else
			{
				this->currentsize--;
				return this->arr[this->currentsize];
			}
		}
		
		int peek()
		{
		   if(empty())	
		   {
		   	cout << "No stack to return" << endl;
		   	return -1;
		   }
		   else
		   {
		   	  return this->arr[this->currentsize];
		   }
		}
		
};

int main()
{
	Stack *newstack = new Stack(3);
	newstack->push(5);
	newstack->push(3);
	
	while(!newstack->empty())
	{
		int data = newstack->pop();
		printf("%d \t", data);
	}
	return 0;
}
