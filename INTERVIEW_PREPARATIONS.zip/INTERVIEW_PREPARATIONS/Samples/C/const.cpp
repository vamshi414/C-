// const C++

#include<iostream>

using namespace std;

int main()
{
	
	const int i=10;
	const int j = i+10;  // This works
	
	cout << "i:" << i << "j: " << j << endl;
	
	i++;   // leads to compile error
	
	cout << "i: " << endl;
}
