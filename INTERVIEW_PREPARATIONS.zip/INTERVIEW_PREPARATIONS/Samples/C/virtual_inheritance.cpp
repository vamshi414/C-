// virutal inheritance
// To prevent multiple instances of a given class

#include<iostream>
using namespace std;
class A
{
	public:
		void show()
		{
			cout << "print" << endl;
		}
};

class B: virtual public A
{
};

class C: virtual public A
{
};

class D:public C, public B
{
};

int main()
{
	D object;
	object.show();
}
