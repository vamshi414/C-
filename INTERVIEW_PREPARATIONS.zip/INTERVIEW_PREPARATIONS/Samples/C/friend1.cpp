// Friend class
// A friend class can have access private and protected members of other class which it declared as friend
// a friend class doesnt suport inheritance


#include<iostream>

using namespace std;


class A {
	private:
	  int a;
	public:
	A() 
	{
	  	a=0;
	}
	friend class B;
};

class B
{
   private:
   	 int b;
   public:
   	 
		 void show(A& x)
		 {
		    cout << x.a;	
		 }	
	
};

int main()
{
	A a;
	B b;
	b.show(a);
}
