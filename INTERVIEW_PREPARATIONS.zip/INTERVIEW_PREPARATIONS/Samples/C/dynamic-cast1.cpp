// dynamic_casting
// this is used at run time to acheive the correct down-cast
// for this we need atleast one virtual function in base class
//syntax:  std::dynamic_cast<new_type> (expression);

#include<iostream>
#include<exception>
using namespace std;


class Base {
	
	public:
		virtual void print()
		{
			cout << "Base" << endl;
		}
};

class Derived1:public Base {
	
	public:
		  void print()
		  {
		  	cout << "Derived1" << endl;
		  }
	
};

class Derived2:public Base {
	
	public:
		void print()
		{
			cout << "Derived2" << endl;
		}
};


int main()
{
	Derived1 d1;
	
	Base *bp = dynamic_cast<Base*>(&d1);
	
	Derived1 *d2 = dynamic_cast<Derived1*>(bp);
	
	if(d2 == nullptr)
	{
		cout << "NULL" << endl;
	}
	else
	{
		 cout << "Not NULL" << endl;
	}
	
	try {
		
		Derived2 &r1 = dynamic_cast<Derived2&>(d1);
	}
	catch(std::exception& e) {
		cout << e.what() << endl;
	}
}
