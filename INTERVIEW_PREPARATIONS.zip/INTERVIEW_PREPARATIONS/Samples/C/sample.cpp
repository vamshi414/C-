#include<iostream>

using namespace std;

class Test {
	
	float val;
	public:
		Test () {
		}
		Test(float var) : val(var) {
		}
		
		/*operator float() const
		{
			return val;
		} */
};

int main()
{
	Test obj(10.5);
	
	float b = obj;
	
	cout << b << endl;
}
