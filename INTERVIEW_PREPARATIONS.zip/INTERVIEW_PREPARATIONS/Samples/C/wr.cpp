#include<iostream>
#include<string.h>
#include<stdio.h>
using namespace std;


int strlen1(char s[])
{
	int i;
	while(s[i] != '\0')
	  i++;
	  
	return i;
}


int main()
{
	
	char s1[100],rev[100];
	int index, i,ws,we;
	index=0;
//	cout << "Enter the string" << endl;
//	cin >> s1;
//	cout << endl;
	
	printf("enter string:\n");
	gets(s1);
//	int len;
//	len = strlen(s1);
	
//	ws = len-1;
//	we = len-1;
	ws = strlen1(s1) - 1;
	we = strlen1(s1) - 1;
	
	while(ws > 0)
	{
		
		if(s1[ws] == ' ')
		{
			i = ws+1;
			while(i<=we)
			{
				rev[index] = s1[i];
				index++;
				i++;
			}
			rev[index++] = ' ';
			we = ws-1;
		}
		ws--;
    }
    
    for(i=0;i<=we;i++)
    {
    	rev[index] = s1[i];
    	index++;
	}
     rev[index] = '\0';
     
  //   cout << rev << endl;
   //  cout << s1 << endl;

   printf("%s\n", rev);
   printf("%s\n", s1);
	
}

