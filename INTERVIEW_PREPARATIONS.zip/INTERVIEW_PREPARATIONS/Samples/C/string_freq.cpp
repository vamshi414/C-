#include<iostream>
#include<stdio.h>
#include<string.h>

using namespace std;
int freqcount(char *s1, char *s2);

int main()
{
	char s1[100], s2[100];
	int count=0;
	
	printf("Enter any string: ");
    gets(s1);
    printf("Enter word to search occurrences: ");
    gets(s2);
	
	count  = freqcount(s1,s2);
	
	cout << count << endl;
}

int strlen1(char *s1)
{
	int i;
	while(s1[i] != '\0')
	  i++;
	  
	return i;
}

int strlen2(char *s2)
{
	int j;
	while(s2[j] != '\0')
	  j++;
	  
	return j;
}

int freqcount(char *s1, char *s2)
{
	
	int i,j,found,count=0;
	int M,N;
	
	M = strlen1(s1) ;
	N = strlen2(s2) ;
	cout << M << endl;
	cout << N << endl;
	
	for(i=0;i<=M-N;i++)
	{
		found=1;
		for(j=0;j<N;j++)
		{
			if(s1[i+j] != s2[j])
			{
			    found=0;
				break;	
			}
		}
		
		if(found == 1)
		{
			 count++;
		}
	}
	
	return count;
	
}
