// matrix

#include<iostream>
#define N 2


using namespace std;


int identical(int M1[N][N], int M2[N][N] )
{
	 int i,j;
	 for(i=0;i<N;i++)
	    for(j=0;j<N;j++)
	     
	        if(M1[i][j] != M2[i][j])
	        return 0;
	return 1;
}

void Add(int M1[][N], int M2[][N], int Add[][N] )
{
	int i,j,k;
	
	 for(i=0;i<N;i++) 
	    for(j=0;j<N;j++)
	       Add[i][j] = M1[i][j] + M2[i][j];
}
void multiply(int M1[][N], int M2[][N], int res[][N] )
{
	int i,j,k;
	for(i=0;i<N;i++) {
	   for(j=0;j<N;j++) {
	    res[i][j] =0;
	    for(k=0;k<N;k++)
	       res[i][j] += M1[i][k] * M2[k][j];
      }
   }   
}


int main()
{
	int M1[N][N] = { {1,2},
	                 {3,4} };
	
	int M2[N][N] = { {1,2},
	                 {3,4} };
	                 
    int res[N][N];
    int add[N][N];
    int i,j;
    multiply(M1, M2, res);
					     
	cout <<  "result of matrix:" << endl;
	 
	 for(i=0;i<N;i++)
	    for(j=0;j<N;j++)
		 {
		 			 cout << res[i][j] << endl;			 

		 }
  cout << endl;
  
  
  if(identical(M1,M2))
  {
  	  cout << "indentical" << endl;
  }
  else
  {
  	cout << "Not identical" << endl;
  }
  
  Add(M1,M2,add);
  
  	cout <<  "result of addition matrix:" << endl;
	 
	 for(i=0;i<N;i++)
	    for(j=0;j<N;j++)
		 {
		 			 cout << add[i][j] << endl;			 

		 }
  cout << endl;

}
