// Binary Search Tree
// The elements  stored in the right subtree of Node X are less than X and left subtree of Node X are greater than X

#include<stdio.h>
#include<stdlib.h>


typedef struct BST {
	
	int data;
	struct BST *left;
	struct BST *right;
}node;

node *create();
void insert(node *, node *);
void preorder(node *);

node* create()
{
	
	node *temp;
	printf("enter data\n");
	temp = (node*) malloc(sizeof(node));
	scanf("%d", &temp->data);
	temp->left=temp->right=NULL;
	return temp;
}


void insert( node *root, node *temp )  
{
	if(temp->data < root->data)
	{
		  	if(root->left != NULL)
		  	 insert(root->left,temp);
		  	else
		  	   root->left = temp;
	}
	
	if(temp->data > root->data)
	{
		   if(root->right != NULL)
		      insert(root->right,temp);
		   else
		     root->right = temp;
	}
}

void preorder(node * root)
{
  /* if(root!= NULL)
   {
      printf("%d-->", root->data);
	  preorder(root->left);
	  preorder(root->right);	
   } */
   
   if( root == NULL )
   {
      printf("no elements to display in tree\n");	
      return ;
   }	
   
   printf("%d-->", root->data);
   if(root->left != NULL)
   {
   	   
   	   preorder(root->left);
   	   //preorder(root->right);
   }
   
   if(root->right != NULL)
   {
   	  preorder(root->right);
   }
   
}

int main()
{
	char ch;
	node *root=NULL,*temp;
	
	do
	{
		temp = create();
		if(root == NULL)
		    root = temp;
		else
		   insert(root,temp);
		   
		printf("do u want to enter more(y/n)?:\n");
		getchar();
		scanf("%c", &ch);
		
	} while(ch=='y' || ch == 'Y');
	
	printf("\n Prorder Traversal\n");
	preorder(root);
}


