#include<stdio.h>
int main(void) 
{ 
unsigned int x = 0xFFFFFFFF; 
x= x>>4; 
printf("0x%x", x); 
return 0; 
}
