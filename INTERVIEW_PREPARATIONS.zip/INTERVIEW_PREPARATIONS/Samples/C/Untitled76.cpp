vector Vs List
1> Insertion and Deletion : 
in List it is very efficient as compared to vector, to insert element in list
at start,middle and end, just a couple of pointers are swapped.
whereas in vector, to insert r delete element will make elements to shift by one
2. Random access: Vector is for Random access
3. Iterator Invalidation:

