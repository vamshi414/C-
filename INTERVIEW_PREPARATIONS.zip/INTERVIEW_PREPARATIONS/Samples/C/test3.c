#include<stdio.h>

int main() 
{ 
unsigned int n = 1; 
char *c = (char*)&n;
 printf(c);
 if (*c) 
 
 printf("1"); 
 else 
 printf("0"); 
 return 0; 
}
