#include<iostream>

using namespace std;

int main()
{
	int size;
	int *arr = new int[size];
	
	cout << "enter the number size" << endl;
	cin >> size;
	
	cout << endl;
	
	
	for(int i=0;i<size;i++)
	{
		cin >> arr[i];
	}
	
	cout << endl;
	
	for(int i=0;i<size;i++)
	{
		cout << arr[i] << endl;
	}
	
	
	delete arr;
	
	
}
