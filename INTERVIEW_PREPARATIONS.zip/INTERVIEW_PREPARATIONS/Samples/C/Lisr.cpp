// LIST
//it is a DLL, and SLL is forward_list

#include<iostream>
#include<algorithm>
#include<list>

using namespace std;



void showlist(list<int> g)
{
	std::list<int> ::iterator it;
	
	for(it = g.begin(); it != g.end(); it++)
	{
		cout << *it << " \t";
	}
    cout << endl;
}



int main()
{
	
	std::list<int> g1,g2;
	
	for(int i=0;i<10; i++)
	{
		g1.push_back(i*2);
	//	g2.push_back(i*3);
	}
	
	showlist(g1);
	cout << endl;
//	showlist(g2);
	
	
//	g1.sort();
//	showlist(g1);
	
//	g1.reverse();
//	showlist(g1);
	
//	g1.pop_back();
//	showlist(g1);

   g1.push_front(50);
   
   showlist(g1);
   
   auto it = g1.begin();
   
   std::advance(it,3);
   
   g1.insert(it,200);
   
   showlist(g1);
	
	
}
