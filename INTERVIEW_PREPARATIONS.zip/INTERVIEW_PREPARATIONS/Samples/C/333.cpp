//DLL
#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node *next;
	struct Node *prev;
}
struct Node *head =NULL;

void Insertathead(int x)
{
	sturct Node *newnode = getnewnode(x);
	if(head == NULL)
	{
		 head = newnode;
		 return;
	}
	
	head->prev = newnode;
	newnode->next = head;
	head = newnode;
}
void getnewnode(int x)
{
	struct Node *newnode;
	Newnode = (strut Node *) malloc(sizeof(struct Node));
	Newnode->data = x;
	Newnode->next = NULL;
	Newnode->prev = NULL;
	return Newnode;
	
}

void print()
{
	struct Node *temp  = head;
	
	
}
int main()
{
  	
}
