// Friend it can access the private and protected data members of other class in which it is declared as friend
#include<iostream>
using namespace std;

class CA
{
public:
	virtual void fun()
	{
		cout<<"CA fun"<<endl;
	}
	void DoWork()
	{
		fun();
	}
};

class CB : public CA
{
public:
	void fun()
	{
		cout<<"CB fun"<<endl;
	}
};
int main()
{
	CB obj;

	obj.DoWork(); 
}

