// Visitor Pattern
In this Pattern we use visitor class which changes the executing algorithm of an element class
by this execution of element can vary when visitor varies. as per this pattern element object has
to accept visitor object handles the operation of element

// Decorator

This pattern allows user to add new funcionliaty to the existing object without altering structure.
this pattern acts as wrapper to the existing class. This pattern creates decorator class which wraps
the original class and provides the additional funcioniality and kepping class methods signature intact.



// Singleton

this is one simplest pattern  this pattern involves a single class which is responsible to create an object
while make sure that only single object is created.this object can have whole access in the exucetion of code.

