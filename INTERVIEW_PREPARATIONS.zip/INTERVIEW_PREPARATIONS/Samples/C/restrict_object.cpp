// how to restrict a object to be created in stack r heap

#include<iostream>

using namespace std;

class A {
	
	void *operator new(size_t size);
	
	public:
		A()
		{
			
		}
		
		void display()
		{
			cout<<"No dynamic memory allocation is allowed for this class !!!"<<"\n"; 	
		}
};

int main()
{
	A obj;
	obj.display();
}
