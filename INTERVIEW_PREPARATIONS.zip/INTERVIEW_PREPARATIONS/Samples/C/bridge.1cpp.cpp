// Bridge Pattern
// It allows to seperate the abstraction from implementation


#include<iostream>
#include<string>

using namespace std;

class Icolor {
	public:
		  virtual string color() = 0;
		  
};

class redcolor:public Icolor
{
	public:
		 string color()
         {
         	return "redcolor" ;
		 }
};

class bluecolor:public Icolor
{
	 public:
	 	  string color()
	 	  {
	 	  	return "bluecolor";
		  }
};


class Icarmodel {
	public:
		 virtual string mytype() = 0;
};

class Model_A :  public Icarmodel
{
	Icolor *mycolor;
	public:
		 Model_A(Icolor* obj) : mycolor(obj) {
		 }
		 
		 string mytype()
		 {
		 	 return "model" + mycolor->color();
		 }
		 
};

class Model_B : public Icarmodel
{ 
    Icolor *mycolor;
    public:
    	  Model_B(Icolor* obj) : mycolor(obj) {
		  }
		  
		  string mytype()
		  {
		  	  return "model" + mycolor->color();
		  }
		
};


int main()
{
	 Icolor* red = new redcolor();
	 Icolor* blue = new bluecolor();
	 
	 Icarmodel* modelA = new Model_A(red);
	 Icarmodel* modelB = new Model_B(blue);
	 
	 cout << modelA->mytype() <<endl;
	 cout << modelB->mytype() << endl;
}
