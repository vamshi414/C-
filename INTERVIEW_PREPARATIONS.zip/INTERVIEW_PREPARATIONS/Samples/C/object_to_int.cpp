// How to assign any object to primitive data type//
// we need to define operator int() to allow the conversion from object to int

#include<iostream>

using namespace std;

class Base
{
	char var;
	public:
		Base() { }
		Base(char val) : var{val} { }
		
		operator char() const
		{
			return var;
		}
};

int main()
{
	Base obj('V');
	char temp = obj;
	cout << temp << endl;
}
