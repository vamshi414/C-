// How to call Base class function from Derived object

#include<iostream>

using namespace std;

class Base {
	
	public:
		void fun() {
		
		cout << "Base" << endl; }
};

class Derived :public Base {
     public:
     	void fun() {
		 
	   cout << "Derived" << endl;	 }
};


int main()
{
	Derived obj;
//	obj.fun();
//	obj.Base::fun();
	
	Base b = static_cast<Base>(obj);
	b.fun();
}
