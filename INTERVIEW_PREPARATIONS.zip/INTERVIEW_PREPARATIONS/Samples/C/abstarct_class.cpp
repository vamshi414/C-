#include<iostream>

using namespace std;

class Animal {
	public:
		virtual void eat() = 0;
		
};

class Cow : public Animal
{
	public:
		void eat()
		{
			cout << "eat veg " << endl;
		}
};

class Cat : public Animal
{
	public:
		void eat()
		{
			cout << "eat non-veg" << endl;
		}
};

int main()
{
	//Animal *a = new Cow();
	
	//a->eat();
	
	Cow c;
	Animal &a = c;
	
	a.eat();
}
