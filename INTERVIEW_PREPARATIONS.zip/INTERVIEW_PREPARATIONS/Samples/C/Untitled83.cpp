// FDP
// Define an interface or an abstart class for creating an object but let the subclasses decide which class to initiate


#include<iostream>

using namespace std;

#include "Toyfactory.cpp"

int main()
{
	
	int type;
	while(1)
	{
		cout << "enter type or zero to exit" << endl;
		cin >> type;
		
		if(!type)
		   break;
		
		Toy *v = ToyFactory::createToy(type);
		if(v)
		{
			v->showProduct();
			delete v;
		}
	}
	
	cout << "Exit..." << endl;
}

+++++

#include<iostream>
using namespace std;

#include "object.cpp"

class ToyFactory
{
	
	public:
		static Toy *createToy(int type) 
		{
			
			Toy *toy = NUll;
			
			switch(type)
			{
				
				case 1:
				  {
				  
					toy = new Car;
					break;
			      }
			    case 2:
			     {
			     	toy = new Bike;
			     	break;
				 }
				 case 3:
				  {
				  	 toy = new Plane;
				  	 break;
				  }
				  default:
				  	{
				  	  cout << "invalid toy type please re-enter valid one" << endl;
						return NULL;	
					}
			}
			
			toy->prepareParts();
			toy->combineParts();
			toy->assemblePart();
			toy->applyLabel();
			return toy;
		}
	
};

+++++++++++++++++++
#include<iostream>
using namespace std;

class Toy
{
   protected:
      string name;
	  float price;
   public:
      virtual void prepareParts() = 0;
	  virtual void combineParts() = 0;
	  virtual void assemblePart() = 0;
	  virtual void applyLabel() =   0;
	  virtual void showproduct() =  0; 	

};


class Car : public Toy
{
	
	public:
		void prepareParts()
		{
			cout << "Preparing car parts" << endl;
		}
		void combineParts()
		{
			cout << "combine car parts" << endl;
		}
		
		void assemblePart()
		{
			cout << "assemble car parts" << endl;
		}
		
		void applyLabel()
		{
			cout << "apply Label" << endl;
			name = "car";
			price = 10;
		}
};

class Bike : public Toy
{
	
	
};


