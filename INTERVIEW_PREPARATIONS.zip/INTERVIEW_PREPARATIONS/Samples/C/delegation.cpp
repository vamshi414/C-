// calling a constrcutor to call another constcrutor with in the same class is called Constructor delegation

#include<iostream>

using namespace std;

class A {
	
	int x,y,z;
public:	
	A()
	{
		x=0;
		y=0;
		z=0;
	}
	
	A(int z) : A()
	{
		//x=0;
	   //y=0;
		this->z = z;
	
	}
	
	void show()
	{
		cout << "x:" << x << "\t"
		     << "y:" << y << "\t"
		     << "z:" << z << endl;
	}
};

int main()
{
	A obj(3);
	obj.show();
	
}
