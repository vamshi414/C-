// Method overloading
// method overriding

overloading:

class Add {
	
	public:
		void sum(int a, int b)
		{
		   cout << a+b;
		}
		
		void sum(int a,int b, int c)
		{
			cout << a+b+c;
		}
};

int main()
{
	Add obj;
	obj.sum(10,20);
	obj.sum(10,20,30);
}


overriding:

class Base
{
	public:
		void show()
		{
			cout << "base class";
		}
};

class Derived:public Base
{
	
   public:
      void show()
	  {
	     cout << "derived class";  	
	  }	
};

int main()
{
	Base b;
	Derived d;
	b->show();
	d->show();
}
