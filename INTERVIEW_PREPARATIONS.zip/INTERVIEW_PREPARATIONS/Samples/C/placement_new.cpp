// Placement New : using to call destructor explicitly

#include<iostream>

using namespace std;

class Base {
	
	int a;
	public:
		Base()
		{
			cout << "Base constrcutor" << endl;
		}
		
		~Base()
		{
			cout << "Base desctructor" << endl;
		}
		
};

int main()
{
	Base *obj = new Base();
	delete obj;

 
    int *memory = new int[10*sizeof(Base)];
    Base *obj1 = new (&memory[0])  Base();
    Base *obj2 = new (&memory[4])  Base();
    
    obj1->~Base();
    obj2->~Base();
    
    delete[] memory;
    
}
