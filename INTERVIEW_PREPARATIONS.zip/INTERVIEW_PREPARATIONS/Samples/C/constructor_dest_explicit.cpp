//constructor and Destrcutro call explicitily

#include<iostream>

using namespace std;

class Base {
	
	int _basevariable;
	public:
		Base()
		{
			cout << "base constructror" << endl;
		}
		~Base()
		{
			cout << "base destructor" << endl;
		}
};

int main()
{
	Base();
	//Base obj;
	//obj.~Base();
	cout << "Vamshi" << endl;
	
	
}
