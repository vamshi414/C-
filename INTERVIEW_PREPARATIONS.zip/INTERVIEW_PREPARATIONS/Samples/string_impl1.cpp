#include <thread>
#include <chrono>
#include <iostream>

 

class String {
    private:
        int size_;
        char *ptr_;
        
    int Strlen(const char* str)
    {
        char *p = (char *)str;
        
        int len = 0;
        while(*p++)
            len++;
        return len;
    }
    
    char *Strcpy(char *dst, const char*src)
    {
        char *s = (char *)src;
        char *d = dst;
        
        while(*d++ = *s++)
            ;
            
        return dst;
    }
    
    char *Strcat(char *dst, const char*src)
    {
        char *s = (char *)src;
        char *d = dst;
        
        while(*d)
            d++;
            
        while(*d++ = *s++)
            ;
            
        return dst;
    }
        
    public:
        String() : size_(1), ptr_(new char[1]) { *ptr_ = '\0'; }
        ~String() { delete[] ptr_ ; }
        
        int size() const { return size_; }
        const char *c_str() const { return ptr_; }
        
        String(char *str)
        {
            size_ = Strlen(str);
            size_++; // +1 for NULL
            ptr_ = new char[size_];
            Strcpy(ptr_, str);
        }
        
        String(const String& string)
        {
            size_ = string.size();
            ptr_ = new char[size_];
            Strcpy(ptr_, string.c_str());
        }
        
        String& operator = (const String& string)
        {
            if ( this == &string)
            {
                std::cout << __func__ << "assigning same address, will be skipped" << std::endl;
                return *this;
            }
            
            delete[] ptr_;
            size_ = string.size();
            ptr_ = new char[size_];
            Strcpy(ptr_, string.c_str());
        }
        
        String operator + (const String& string)
        {
            String tmp;
            tmp.size_ = size_ + string.size_;
            delete[] tmp.ptr_;
            
            tmp.ptr_ = new char[tmp.size_];
            Strcpy(tmp.ptr_, ptr_);
            std::cout << __func__ << " 1 : " << tmp.ptr_ << std::endl;
            Strcat(tmp.ptr_, string.c_str());
            std::cout << __func__ << " 2 : " << tmp.ptr_ << std::endl;
            
            return tmp;
        }
        
        void display() { std::cout << ptr_ << std::endl; }
};

 

int main()
{
  String s1 = "Test string";
  String s2 = "Sample String";
  s1.display();
  s2.display();
  //std::this_thread::sleep_for(std::chrono::seconds(2));
  String s3 = s2;
  s3.display();
  //std::this_thread::sleep_for(std::chrono::seconds(2));
  
  String s4 = s1 + s2;
  s4.display();
  
  //std::this_thread::sleep_for(std::chrono::seconds(2));
  s1 = s2;
  std::cout << "------------" << std::endl;
  s1.display();
  s2.display();
  s3.display();
  s4.display();
}
