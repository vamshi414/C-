// Reverse word
#include<iostream>
#include<vector>
#include<string>

using namespace std;

void reverseword(string s)
{
	
	std::vector<string> temp;
    string str = "";
    
    for(int i=0;i<s.length();i++)
    {
    	if(s[i] == ' ')
    	{
    		temp.push_back(str);
    		str = "";
		}
		else
		{
			str += s[i];
		}
	}
	
	temp.push_back(str);
	
	for(int i=temp.size()-1;i>0;i--)
	{
		 cout << temp[i] << " ";
	}
	
	cout <<  temp[0] << endl;

}


int strlen1(string s)
{
   int c=0;
   while(s[c])
   c++;
   
   return c;
}

int main()
{
	string s = "vamshi krishna rangam";
	reverseword(s);
    int len = strlen1(s);
    cout << len << endl;
}
