#include<iostream>

using namespace std;


class String {
	
	private:
		int size;
		char *ptr_;
		
	int strlen(const char *str)
	{
	   char *p = (char*)str;
	   int len=0;
	   
	   while(*p++)
	   {
	      len++;	
	   }
	   return len;	
	}
	
	char *strcpy(char *dest, char *src)
	{
		char *s = (char*)src;
		char *d = dest;
		
		while(*d++ = *s++);
		return dest;
	}
	
	char *strcat(char *dst, char *src)
	{
		char *s = (char *)src;
		char *d = dst;
		
		while(*d)
		    d++;
		while(*d++ = *s++);
		
		return dst;
	}
	
	public:
		
	//	String() : size(1), ptr_(new char[1]) { *ptr_ = '\0'; }
    //    ~String() { delete[] ptr_ ; }

		
		int size() const
		{
			return size;
		}
		
		String(char *str)
		{
			size = strlen(str);
			size++;
			ptr_ = new char[size];
			strcpy(ptr_, str);
		}
		
		String(const String& string)
		{
			size = string.size();
			//size++;
			ptr_ = new char[size];
			strcpy(ptr_,string.c_str());
		}
		
		void display()
		{
			cout << ptr_ << endl;
		}
		
};

int main()
{
	String s1 = "vamshi";
	String s2 = "krishna";
    s1.display();
    s2.display();
    
    String s3 = s2;
    s3.display();
}
