#include<iostream>

using namespace std;


class Myfunctor {
	
	private:
		int m;
	public:
		Myfunctor(int x) : m(x) {  }
		
		int operator() (int val) const
		{
			return m+val;
		}
	
};


int main()
{
	int i=4;
	int j=5;
	
	Myfunctor obj(10);
	

	
	cout << obj(i) << endl;
	cout << obj(j) << endl;
}
