#include<iostream>
//#include<>

using namespace std;
class Node
{
    public:
	   int data;
	   Node *next;
};
Node *head=NULL;

void push(Node **head_ref, int ndata)
{
   Node *new_node = new Node(); //allocate node
   
   new_node->data = ndata;
   new_node->next = (*head_ref);
   (*head_ref) = new_node;
}

void fun(Node *head)
{
    while(head != NULL)
	{
	    
	cout << head->data << endl;
	head = head->next;
    } 

}

void fun1(Node *head)
{
  if(head == NULL)
   return;
   
   fun1(head->next);
   cout << head->data<< endl;
}


void reverse()
{
    Node *current = head;
	Node *prev=NULL, *next=NULL;
	
	while(current != NULL)
	{
	   next = current->next;
	   
	   current->next = prev;
	   
	   prev = current;
	   current = next;	
	}	
	
	   head = prev;
}

void fun2(Node *head)
{
	if(head==NULL)
	 return;
	 cout << head->data << " ";
	 
	 if(head->next != NULL)
	    fun2(head->next->next);
	
	   cout << head->data << " ";
}

main()
{
   
   
   push(&head,1);
   push(&head,2);
   push(&head,3);
   push(&head,4);
   push(&head,5);
   
   
   fun(head);
   cout << endl;
   fun1(head);
   
   cout << endl;
   
   fun2(head);
   cout << endl;
   reverse();
   
   fun(head);
}
   
