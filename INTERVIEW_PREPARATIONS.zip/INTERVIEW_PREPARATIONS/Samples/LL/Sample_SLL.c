#include<stdio.h>
#include<stdlib.h>


struct Node
{
	int data;
	struct Node *next;
};

struct Node *head = NULL;

void delete(struct Node **head_ref)
{
    struct Node *current = *head_ref;
	struct Node *next;
	
	while(current != NULL)
	{
	   
	   next = current->next;
	   free(current);
	   current = next;	
    }	
	
	*head_ref = NULL;
}


void display(struct Node *temp)
{
	while(temp != NULL )
	{
		printf("%d==>", temp->data);
		temp = temp->next;
	}
  	
}


void Insert(struct Node **head_ref, int data)
{
	struct Node *new_node = (struct Node *) malloc(sizeof(struct Node));
    new_node->data = data;
	new_node->next = (*head_ref);
	(*head_ref) = new_node;	
	
}

int main()
{
	
	Insert(&head,10);
	Insert(&head,20);
	Insert(&head,30);
	
	display(head);
	printf("\n");
	printf("LInk list is deleting\n");
	delete(&head);
	printf("Link list is deleted\n");
	
	
	
}
