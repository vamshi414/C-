#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node *next;
};

struct Node *head = NULL;


void display(struct Node *ptr)
{
	while(ptr != NULL)
	{
		printf("%d==>", ptr->data);
		ptr = ptr->next;
	}
}


int checklistcount(struct Node *head)
{
    while(head && head->next)
	{
	   head = head->next->next;	
	}
	
	if(!head)
	{
		return 0;
	}
	return 1;
}

void delete(struct Node **head_ref, int position)
{
    if(*head_ref == NULL)	
	  return;
	  
	struct Node *temp = *head_ref;
	
	if(position == 0)
	{
		(*head_ref) = temp->next;
		free(temp);
		return;
	}
	int i;
	for( i=0; temp!= NULL && i<position-1; i++)
	{
		temp = temp->next;
	}
	
	if(temp == NULL || temp->next == NULL)
	  return;
	  
	  struct Node *next = temp->next->next;
	  free(temp->next);
	  temp->next = next;
}


void delete1(struct Node **head_ref)
{
    struct Node *current  = *head_ref;
    struct Node *next=NULL;
    
    while(current != NULL)
    {
    	next = current->next;
    	free(current);
    	current = next;
	}
}


void insertAfter(struct Node* prev_node, int new_data) 
{ 
    /*1. check if the given prev_node is NULL */
    if (prev_node == NULL) 
    { 
      printf("the given previous node cannot be NULL"); 
      return; 
    } 
  
    /* 2. allocate new node */
    struct Node* new_node =(struct Node*) malloc(sizeof(struct Node)); 
  
    /* 3. put in the data  */
    new_node->data  = new_data; 
  
    /* 4. Make next of new node as next of prev_node */
    new_node->next = prev_node->next; 
  
    /* 5. move the next of prev_node as new_node */
    prev_node->next = new_node; 
} 

void push(struct Node **head_ref, int data)
{
	struct Node *new_node = (struct Node*)malloc(sizeof(struct Node));
	
	new_node->data  = data;
	new_node->next = (*head_ref);
	(*head_ref) = new_node;
	
}
void append(struct Node **head_ref, int data)
{
	struct Node *new_node = (struct Node *) malloc(sizeof(struct Node));
	struct Node *last = *head_ref;
	
	new_node->data =  data;
	new_node->next = NULL;
	
	if( *head_ref == NULL  )
	{
		*head_ref = new_node;
	 	 return;
	}
	
	
	while(last->next != NULL)
	  last= last->next;
	  
	last->next = new_node;
	return;
}

int main()
{
	struct Node *head = NULL;
	
	append(&head, 01);
	display(head);
	printf("\n");
	push(&head,02);
	display(head);
	printf("\n");
	
	push(&head,03);
	display(head);
	
	printf("\n");
	
	push(&head,04);
	display(head);
	
	printf("\n"); 
	
	insertAfter(head->next->next->next, 8);
	display(head);
	
	
	int check  = checklistcount(head);
	printf("\n");
	if(check == 0)
	{
		printf("even\n");
	
	}
	else
	{
		printf("odd\n");
	}
	
	printf("List is Deleting\n");
	//delete(&head);
	
	printf("List is Deleted\n");
	
	delete(&head,1);
	display(head);
}
