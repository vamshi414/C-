#include<stdio.h>
#include<stdlib.h>


struct Node 
{
	int data;
	struct Node *next;
	struct Node *prev;
};

struct Node *head = NULL;


void Insert(struct Node **head_ref, int data)
{
	struct Node *new_node = (struct Node *) malloc(sizeof(struct Node));
	
	new_node->data = data;
	new_node->next = (*head_ref);
	
	new_node->prev = NULL;
	if((*head_ref) != NULL )
	   (*head_ref) ->prev = new_node;
	   
	(*head_ref) = new_node;
}

void display(struct Node *node)
{
   struct Node *last;
   while(node != NULL)
   {
      printf("%d==>", node->data);
	  last = node;
	  node = node->next;
	  	
   }	
   
   printf("\n");
   while(last != NULL)
   {
   	 printf("%d==>", last->data);
   	 last = last->prev;
   }
}

int main()
{
	 Insert(&head,10);
	 Insert(&head,20);
	 Insert(&head,30);
	 
	 display(head);
}
