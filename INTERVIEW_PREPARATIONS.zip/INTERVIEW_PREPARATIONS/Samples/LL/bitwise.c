#include<stdio.h>

int main()
{
	unsigned int i= 0xF1;
	printf("0X%x\n", i << 1);
}
