#include<stdio.h>
#include<stdlib.h>


struct Node
{
	int data;
	struct Node *next;
	struct Node *prev;
};

struct Node *head=NULL;

int checklistlength(struct Node *head)
{
    while( head && head->next)
	{
	     head = head->next->next;	
    } 
	if(!head)
	{
	   return 1;	
    }  	
    return 0;
} 

void Insert(struct Node **head_ref, int data)
{
	struct Node *new_node = (struct Node *) malloc(sizeof(struct Node));
	
	new_node->data = data;
	new_node->next  = (*head_ref);
	
	new_node->prev = NULL;
	
	if((*head_ref) != NULL )
	   (*head_ref) ->prev = new_node;
	   
	(*head_ref) = new_node;
}

void display(struct Node *ptr)
{
	struct Node *last;
	printf("In Forward Direction\n");
	while( ptr != NULL)
	{
		
		printf("%d==>", ptr->data);
		last = ptr;
		ptr = ptr->next;
	}
	
	printf("\n");
	printf("In Reverse Direction\n");
	while(last != NULL )
	{
		printf("%d==>", last->data);
		last = last->prev;
	}
}

int main()
{
	//struct Node *head;
	
	Insert(&head,01);
	Insert(&head,02);
	Insert(&head,03);
	Insert(&head,04);
	display(head);
	
	int check = checklistlength(head);
	printf("\nLIST IS:");
	if(check == 0)
	{
		printf("even\n");
	}
	
	else
	{
		printf("odd\n");
	}
}
