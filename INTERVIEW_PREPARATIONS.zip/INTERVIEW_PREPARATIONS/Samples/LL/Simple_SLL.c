#include<stdio.h>
#include<stdlib.h>

struct Node
{
	int data;
	struct Node *next;
	
};

struct Node *head=NULL;


void display()
{
	struct Node *temp =head;
	
	while(temp != NULL)
	{
		printf("%d==>", temp->data);
		temp = temp->next;
	}
	printf("null\n");
}

void insert(int data)
{
	struct Node *temp = (struct Node *) malloc(sizeof(struct Node));
	
	if(temp == NULL)
	{
		printf("memory not allocated\n");
	}
	else
	{
	
	temp->data = data;
	
	temp->next = head;
	head = temp;
   }
}

int main()
{
   insert(100);
   insert(200);
   insert(300);
   
   display();	
}
