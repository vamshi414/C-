#include <iostream>


 

using namespace std;


 

class A
{
public : virtual void show ()
{
cout <<" Base Class";
}
};


 

class B : public A
{
public: void show()
{
cout<<" derived class\n";
}

};


 

class MyArray
{
int *array;
public : MyArray ( int noOfbytes)
{
// allocate the memory for array pointer
}
MyArray ( MyArray &a )
{

}
MyArray* operator = ( MyArray *arr1, Myarray *arr2 )
{

return arr1;
}
};


 

int main ()
{
A a;
B b;
a = b;
a.show();

MyArray *a1 = new MyArray(10);
MyArray *a2 = new MyArray(15);

MyArray *a3 = new MyArray(a1);
MyArray *a4 = new MyArray(3);

int *i1 = 5;
int *i2;

a4 = a2;
*a4 = *a2;

return 0;
}
