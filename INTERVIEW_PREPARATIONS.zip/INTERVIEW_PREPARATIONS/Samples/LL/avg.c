#include<stdio.h>

int main()
{
	int marks[100],  total,  i;
	float f;
	int c=0;
	for(i=0;;i++)
	{
		scanf("%d", &marks[i]);
		if(marks[i] <= 0)
		{
			break;
		}
		c++;
		total += marks[i];
	}
	
	f = (float)total/ (float)c ;
	
	printf("%f\n", f);
}
