#include <vector>
#include <algorithm>
#include <iostream>

template <typename Iterator>
Iterator one_of_duplicates(Iterator first, Iterator last) {
    // requires a sorted input
    auto current = first;
    while (true) {
        // find a duplicated element, move it behind 'first' 
        // and find the next different element
        current = std::adjacent_find(current, last);
        if (current == last) return first;
        *first++ = std::move(*current);
        std::cerr << *current << std::endl;
        current = std::adjacent_find(current, last, std::not_equal_to<>());
    }
}


int main() {

    std::vector<int> data = { 0, 1, 2, 3, 4, 5, 1, 2, 2, 3, 5, 5, 5 };
    std::sort(data.begin(), data.end());
    data.erase(one_of_duplicates(data.begin(), data.end()), data.end());
    for (auto i : data) std::cout << i << ',';

