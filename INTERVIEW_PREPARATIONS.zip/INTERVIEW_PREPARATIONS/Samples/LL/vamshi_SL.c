#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
struct Node
{
	int data;
	struct Node *next;
};

struct Node *head = NULL;

void push(struct Node **head_Ref, int data)
{
	
	struct Node *temp = (struct Node *)malloc(sizeof(struct Node));
	
	temp->data = data;
	temp->next = (*head_Ref);
	(*head_Ref) = temp;
}

bool search(struct  Node *head,int x)
{
	
	struct Node *current = head;
	while(current != NULL)
	{
		if(current->data == x)
		     return true;
		current = current->next;
	}
	return false;
}

void display(struct Node *temp)
{
	while(temp != NULL)
	{
		printf("%d==>", temp->data);
		temp = temp->next;
	}
}


int main()
{
    struct Node *head = NULL;
	push(&head, 10);
	push(&head, 20);
	push(&head, 30);
	push(&head, 40);
	
	
	display(head);
	printf("\n");
	search(head, 40) ? printf("yes") : printf("No");
}
