// reverse word
#include<iostream>
#include <bits/stdc++.h> 

using namespace std;


string reversestring(string str)
{
	
	reverse(str.begin(), str.end());
	str.insert(str.end(), ' ');
	
	int n=str.length();
	int j=0;
	
	for(int i=0;i<n;i++)
	{
		  if(str[i] == ' ')
		  {
		  	  reverse(str.begin()+i,str.begin()+j);
		  	  j = i+1;
		  }
	}
	
	str.pop_back();
	
	return str;
}

int main()
{
	 string str = "Vamshi Krishna Rangam";
	 string rev= reversestring(str);
     
     cout << rev << endl;
}
