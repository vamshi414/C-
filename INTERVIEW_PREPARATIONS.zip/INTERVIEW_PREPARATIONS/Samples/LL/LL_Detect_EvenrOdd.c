#include<stdio.h>
#include<stdlib.h>


struct Node
{
	int data;
	struct Node *next;
};
struct Node *head = NULL;

void reverselist(struct Node **head_ref)
{
	struct Node *current = *head_ref;
	struct Node *prev = NULL;
	struct Node *next = NULL;
	
	while( current != NULL )
	{
		next = current->next;
		
		current->next = prev;
		
		
		prev = current;
		current = next;
	}
	*head_ref = prev;
	
}

void Insert(struct Node **head_ref, int data)
{
	struct Node *new_node = (struct node *)malloc(sizeof(struct Node));
	
	new_node->data = data;
	new_node->next = (*head_ref);
	/*  
	  new_node->prev = NULL;
	  if((*head_ref) != NULL)
	    (*head_ref)->prev = new_node;
	 */
	(*head_ref) = new_node;
}

void displaylist(struct Node *ptr)
{
   
   while( ptr != NULL)
   {
   	  printf("%d==>", ptr->data);
   	  ptr = ptr->next;
   }
   printf("NULL");
}

int checklistlength(struct Node *head)
{
    	while(head && head->next)
    	{
    		head = head->next->next;
		}
		if(!head)
		{
			return 0;
		}
		return 1;
}


int main()
{
	struct Node *head = NULL;
	
	Insert(&head,10);
	Insert(&head,20);
	Insert(&head,30);
	displaylist(head);
	int check = checklistlength(head);
	printf("\n");
	if( check == 0)
	{
		printf("List is Even\n");
	}
	else
	{
		printf("List is Odd\n");
	}
	
	
	reverselist(&head);
	
	displaylist(head);
}
