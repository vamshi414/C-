#include<iostream>

using namespace std;


int add(int x,int y)
{
	return x+y;
}

int sub(int x,int y)
{
   return x-y;	
}

typedef int(*mathfun)(int,int);

mathfun fun(int type)
{
	 if(type ==1)
	   return add;
	if(type == 2)
	   return sub;
}

int main()
{
	//int (*fun)(int,int) = add;
	//int c = (*fun)(1,2);
	
	//cout << c << endl;
	
	int(*somefun)(int,int);
	somefun = fun(1);
	
	int d = somefun(1,2);
	
	printf("%d\n", d);	
	
}
