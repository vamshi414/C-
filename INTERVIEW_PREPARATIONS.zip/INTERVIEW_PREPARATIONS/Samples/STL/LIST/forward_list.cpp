#include<iostream>
#include<forward_list>
#include<algorithm>

using namespace std;

int main()
{
	std::forward_list<int> flist1;
	std::forward_list<int> flist2;
	
    flist1.assign( {1,2,3 } );
    
    flist2.assign( { 4,5 } ) ;

    for(int a:flist1)
    {
    	cout << "a:" <<  a << "\t" << " ";
	}
   
    cout << endl;
    for(int b:flist2)
    {
    	cout << "b:" <<  b << "\t" << " ";
	}
    
	flist1.pop_front();
	flist2.pop_front();
	
	cout << endl;
	cout << "After Popping" << endl;
	for(int a:flist1)
    {
    	cout << "a:" <<  a << "\t" << " ";
	}
   
    cout << endl;
    for(int b:flist2)
    {
    	cout << "b:" <<  b << "\t" << " ";
	}
    
    flist1.push_front(100);
    flist2.push_front(200);
    
    cout << endl;
    cout << "AFter Push Front" << endl;
    
    for(int a:flist1)
    {
    	cout << "a:" << a << "\t" << "";
	}
	cout << endl;
	for(int b:flist2)
	{
		cout << "b:" << b << "\t" << "";
	}
	
	flist1.insert_after( flist1.begin(), {4,5} );
	cout << endl;
	cout << "Insert Ater 1st position" << endl;
	for(int a:flist1)
    {
    	cout << "a:" << a << "\t" << "";
	}

    cout << " MERGE LISTS:" << endl;
    
    std::forward_list<int> vlist1 = {4,5,6};
    
    std::forward_list<int> vlist2;
    
    cout << "Vlist1 Data:" << endl;
    for(int i:vlist1)
    {
    	 cout << i << "\t" << "";
	}
	cout << endl;
    vlist2 = vlist1;
    
    cout << "Vlist2 Data:" << endl;
    for(int i:vlist2)
    {
    	 cout << i << "\t" << "";
	}
 
    vlist1.merge(vlist2);
	cout << endl;
	
	for(int i:vlist1)
    {
    	 cout << i << "\t" << "";
	}
	cout << endl;

}

