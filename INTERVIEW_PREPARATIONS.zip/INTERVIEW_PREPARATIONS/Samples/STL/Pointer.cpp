// Pointers in C++
//  Pointers are used for accessing the resources which are external from the program we call it as Heap Memory, so to access the Heap memory we need pointers
// worst example of ignoring to delete the object by developer

#include<iostream>

using namespace std;

class Rect{
	
	private:
		int length;
		int breadth;

};


void fun()
{
	Rect *p = new Rect();
	cout << "Creating new object" << endl;
	delete p;
}

int main()
{
	while(1)
	{
		fun();
		
		
	}
}
