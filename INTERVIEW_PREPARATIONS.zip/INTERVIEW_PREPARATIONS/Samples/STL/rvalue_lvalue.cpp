//lvalues and rvalues references
// l-value refers to a memory location which identifies an object
// r-value refers to data value that is stored at some address in memory
// int a=10,  int &ref = a {l-value},  int &&ref = a {r-value ref}
// uses of l-value : used alias of an existing object and call by reference
// uses of r-value : move constructor and move assignment, 

// copy-constructors works with l-value references  means {copying the actual object to other object rather then making the another object
//  to point to already exisiting object in heap
// while move constructors work on the r-value references and it is pointing to the already exisiting object in memory

// move constructor moves the data to the Heap, where as copy constructor will the copy of exisiting object to new object, where as move
//constructor will just makes the pointer to thealready existing 
#include<iostream>

using namespace std;


void swap(int &x, int &y)
{
    int temp;
	temp = x;
	x = y;
	y = temp;
}

void referncervalue(int &&y)
{
	cout << y << endl;
}

void referncevalue(int &x)
{
	cout << x << endl;
}

int main()
{
//	int a{10};
	
//	int &b=a;
	
//	cout <<boolalpha;
//	cout << (&b == &a) << endl;

/*   int a=10;
   int &lref = a;
   cout << a << endl;
   cout << lref << endl;
   
   int &&rref = 20;
   cout << rref << endl;
   
   lref = 30;
   
   cout << lref << endl;
   cout << a << endl;

   rref = 40;
   
   cout << rref << endl;   */
   
   
   int a{10}, b{20};
   
   cout << "a:" << a  << "\t" 
        << "b:" << b << endl;

   swap(a,b);
   
   cout << "a:" << a  << "\t" 
        << "b:" << b << endl;
  

   int x{40};
   
   referncevalue(x);
        
   int y{50};
   
   referncervalue(100);
}





