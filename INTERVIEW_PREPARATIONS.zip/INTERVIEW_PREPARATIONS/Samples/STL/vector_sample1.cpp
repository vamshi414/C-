#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;


int main()
{
	std::vector<int> vecitems{27,21,43,34,67,86};
	std::vector<int> copyvect{1,2,3,4,5,6,7,8};

 /*   for(int i=vecitems.size()-1; i>=0; i--)
    {
    	 cout << vecitems[i] << "\t" ;             // iterration 1st way
	}
	
	*/ 
	
/*	vector<int>::reverse_iterator it = vecitems.rbegin();
	
	while( it != vecitems.rend() )
	{
		cout << *it << "\t" ;
		it++;
	}
 */
 
   int sum=0;
   cout << accumulate( vecitems.begin(), vecitems.end(), sum );
   
   sort(vecitems.begin(), vecitems.end());
   
   cout << endl;
   
   for(int i=0;i<vecitems.size();i++)
   {
   	 cout  << vecitems[i] << "\t";
   	 
   }
   
   cout << endl;
   
   auto pos = vecitems.begin() + 3;
   vecitems.insert(pos,100);
   
   for(auto &it:vecitems)
   {
   	   cout << it << "\t" ;
   }
   cout << endl;
   
   auto newvect = vecitems.insert(vecitems.begin() + 3, copyvect.begin(), copyvect.end() );
   
   
   for(auto &newvect:vecitems)
   {
   	  cout << newvect << "\t";
   }
   
   cout << endl;
   
   
  // cout << sum << endl;
   /*for_each (    vecitems.rbegin(), 
                 vecitems.rend() , 
				 [] (auto &elem) {
                 cout << elem << " ,";
            } ); */

}
