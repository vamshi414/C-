#include<stdio.h>
/*int main(){
 int i = 5;
 void *vptr; 
 vptr = &i;
 printf("\nValue of iptr = %d ", *(int *)vptr);
 return 0;
 */
 int main()
{
    int aiData[3] = {100, 200,300};
    void *pvData = &aiData[1]; //address of 200
    
    pvData += sizeof(int);
    
    printf("%d", *(int *)pvData);
    
    return 0;

}
