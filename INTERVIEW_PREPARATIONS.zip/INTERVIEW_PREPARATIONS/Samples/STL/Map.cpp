#include<iostream>
#include<map>
#include<functional>

using namespace std;

int main()
{
	std::map<string,int> map1;
	map1["Vamshi"] = 123456;
	map1["Latha"] = 654321;
	map1.insert(std::make_pair("Jahnavi", 123451));
	
	for(auto e1:map1)
	{
		cout << e1.first << " " << e1.second << endl;
	}
	
	cout << map1["Vamshi"] << endl;
}
