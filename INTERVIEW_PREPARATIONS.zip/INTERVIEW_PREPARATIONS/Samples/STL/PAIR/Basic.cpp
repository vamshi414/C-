// PAIR in STL
// which consists of two data elements r objects.
//it used to store hetrogenouss data as single unit 
#include<iostream>
#include<utility>

using namespace std;

int main()
{
	std::pair<int, char> PAIR1;
	
	PAIR1.first = 100;
	PAIR1.second = 'R';
	
	cout << "PAIR1:" << PAIR1.first << " ";
	cout << PAIR1.second << endl;
	
	std::pair<string, double> PAIRD("VAMMSHI", 100.00);
	cout << "PAIRD:" << PAIRD.first << " ";
	cout << PAIRD.second << endl;
	
	
	std::pair<int, int>PAIRA;
	
	cout << "PAIRA: " << PAIRA.first << " ";
	cout << PAIRA.second << endl;
	
	
	std::pair<string,string>PAIRE;
	
	PAIRE = make_pair("VAMSHI", "RANGAM");
	
	cout << "PAIRE:" << PAIRE.first << " ";
	cout << PAIRE.second << endl;
	
	std::pair<string,string>PAIRB;
	
	PAIRB = make_pair("LATHA", "RANGAM");
	
	cout << "PAIRB:" << PAIRB.first << " ";
	cout << PAIRB.second << endl;
	
	PAIRE.swap(PAIRB);
	
	cout << "PAIRE:" << PAIRE.first << " ";
	cout << PAIRE.second << endl;

	cout << "PAIRB:" << PAIRB.first << " ";
	cout << PAIRB.second << endl;

}
