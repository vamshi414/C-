#include<iostream>
#include<set>
#include<algorithm>
#include<string>
#include<functional>

using namespace std;
class Person
{
	public:
		float age;
		string name;
		
	bool operator< (const Person &rhs) const { return age < rhs.age; }
	
	bool operator> (const Person &obj) const { return age > obj.age; }
};

int main()O
{
	std::set<Person, std::greater<Person>> Set = { {30,"Vamshi"}, {25, "Latha"}, {02,"Jahnavi" } };

     for( auto e: Set)
    {
       cout << e.age << " " << e.name << endl;  	
	}
}
