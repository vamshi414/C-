#include<stdio.h>
int main()
{
	unsigned char temp=150;
	int c;
	 int count;
	for(c=0;c<2*temp;++c)
	{
		printf("hello\n");
		count++;
		printf("%d", count);
	}
}
