#include<stdio.h>
#include<stdlib.h>


struct Node
{
	int data;
	struct Node *next;
};

//struct Node *last = NULL;


struct Node *addtoempty(struct Node *last,int var)
{
	if(last != NULL)
	  return last;
	
	struct Node *temp = (struct Node *)malloc(sizeof(struct Node));
	temp->data = var;
	last = temp;
	
	last->next = last;
	return last;
	
	
}

struct Node *addtobegin(struct Node *last,int var)
{
	
   if(last == NULL)
      addtoempty(last,var);
	  
	struct Node *temp = (struct Node *)malloc(sizeof(struct Node));
	
	temp->data= var;
	temp->next = last->next;
	last->next = temp;
	
	return last;	
}


struct  Node *addtolast(struct Node *last, int var)
{
    if(last == NULL)
	  addtoempty(last , var);
	  
	  struct Node *temp = (struct Node *)malloc(sizeof(struct Node));
	  
	  temp->data = var;
	  temp->next = last->next;
	  last->next = temp;
	  last = temp;
	  
	  return last;	
	
}


void printlist(struct Node *last)
{
	struct Node *p ;
	
	if(last == NULL)
	{
		printf("list is  empty\n");
		return ;
	}
	
	p = last->next;
	do
	{
		printf("%d==>", p->data);
		p = p->next;
	} while(p!= last->next);
	
}


int main()
{
	struct Node *last=NULL;
	
	last = addtoempty(last,6);
	
	printlist(last);

   last = addtobegin(last , 7);
   
   printf("\n");
   printlist(last);
   
   last =  addtolast(last,8);
   
   printf("\n");
   
   printlist(last);
}
