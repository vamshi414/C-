// Singleton Sample Application

#include<iostream>
#include<string>

using namespace std;

class Gamesetting
{
	static Gamesetting* _instance;
	int _brightness;
	int _width;
	int _height;
	
	Gamesetting()
	{
		_brightness = 100;
		_width = 500;
		_height = 1000;
	}
	
	public:
		static Gamesetting *getinstance()
		{
			if(_instance == NULL)
			{
				_instance = new Gamesetting;
				return _instance;
			}
		}
	
	    void setbrightness(int brightness)
	    {
	    	_brightness = brightness;
		}
		void setwidth(int width)
		{
			_width = width;
		}
		void setheight(int height)
		{
			_height = height;
		}
		
		int getbrightness()
		{
			return _brightness;
		}
		int getwidth()
		{
			return _width;
		}
		int getheight()
		{
			return _height;
		}
		
		void display()
		{
			cout << "brightness:" << _brightness << endl;
			cout << "width:"      << _width << endl;
			cout << "height:"     << _height << endl;
		}
		
		
};

Gamesetting *Gamesetting::_instance = 0;

void clone_Gamesetting()
{
	Gamesetting *setting =  Gamesetting::getinstance();
	setting->display();
}
int main()
{
	Gamesetting *setting = Gamesetting::getinstance();
    setting->display();
    cout << endl;
    setting->setbrightness(200);
    setting->setheight(2000);
    setting->setwidth(750);
    clone_Gamesetting();
}
