// Singleton Design Pattern
//It is a creational design pattern encrures you that the class had only one instance which provides global access point to this instance.
//there is a situation : Imagine you created new object,after a while decided to create one more new object, instead of receiving fresh object
// you can get the one which u created earlier. so this behaviour is impossible with regular constructor, 
//since constructor call must always returns a object by desgin.
// let say some global variables used to store those objects, as it is handy any code can potentially overwrite the contents of code
// so, singleton pattern let you access one object from code, it will always protects that instance being overwritten by other code

//Implementation:
//Make the defualt constructor always private , to prevent other objects using the new operator with singleton

#include<iostream>
#include<algorithm>
#include<String>

using namespace std;
class Singleton
{
	static Singleton *instance;
	int data;
	
	Singleton()
	{
		data=0;
	}
	
	public:
		static Singleton *getInstance()
		{
			if(!instance)
			{
				instance = new Singleton;
				return instance;
			}
		}
		
		int getdata()
		{
			return this->data;
		}
		
		void setdata(int data)
		{
			this->data = data;
		}
};

Singleton *Singleton::instance = 0;

int main()
{
	Singleton *setting = Singleton::getInstance();
	cout << setting->getdata() << endl;
	setting->setdata(100);
	cout << setting->getdata() << endl;
}

