#include<stdio.h>

int main()
{
	int num;
	int i,temp;
	int flag=0;
	printf("enter number\n");
	scanf("%d", &num);

    temp = num/2;
   
    for(i=2;i<temp;i++)
    {
    	if(num%i == 0)
    	{
    		printf("it is not prime\n");
    		flag=1;
    		break;
		}
	}
	
	if(flag==0)
	{
		printf("it is prime\n");
	}
}




