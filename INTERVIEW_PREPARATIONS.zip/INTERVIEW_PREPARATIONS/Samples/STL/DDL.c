#include<stdio.h>
#include<stdlib.h>


struct Node
{
	int data;
	struct Node *next;
	struct Node *prev;
};

struct Node *head=NULL;

void insert(struct Node **head_ref, int data)
{
	struct Node *new_node = (struct Node *)malloc(sizeof(struct Node));
	
	new_node->data = data;
	new_node->next = (*head_ref);
	
	new_node->prev = NULL;
	
	if((*head_ref) != NULL)
	{
		(*head_ref)->prev = new_node;
	}
	
	(*head_ref) = new_node;
}

void push(struct Node *prev_node, int data1)
{
	if(prev_node == NULL)
	{
		printf("prev node cant be NULL\n");
		return -1;
	}
	
	struct Node *new_node = (struct Node *)malloc(sizeof(struct Node));
	
	new_node->data = data1;
	new_node->next = prev_node->next;
	prev_node->next = new_node;
	new_node->prev = prev_node;
	
	if(new_node->next != NULL)
	  new_node->next->prev = new_node;
}

void append(struct Node **head_ref, int new_data)
{
     struct Node *new_node = (struct Node *)malloc(sizeof(struct Node));
	 
	 struct Node *last = *head_ref;
	 
	 new_node->data = new_data;
	 new_node->next = NULL;
	 
	if (*head_ref == NULL)
	 {
	     new_node->prev = NULL;
		 *head_ref = new_node;	
	 }	
	 
	 while(last->next != NULL)
	    last = last->next;
	    
	 last->next = new_node;
	 
	 new_node->prev = last;
	
}

void display(struct Node *node)
{
   	
   	struct Node *last=NULL;
   	printf("print in forward direction\n");
   	while(node != NULL)
   	{
   	    	
   		printf("%d==>", node->data);
	    last = node;
	    node = node->next;
	}
	printf("\n");
	printf("print in reverse direction\n");
	
	while(last != NULL)
	{
		printf("%d==>", last->data);
		last = last->prev;
	}
}


int main()
{
	insert(&head,10);
	insert(&head,20);
	insert(&head,30);
	
	append(&head,80);
	push(head->next,70);
	display(head);
	
}
