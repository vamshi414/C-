#include<iostream>
/*

  factorial logic:
  
  int factorial(int num )
  {
      
      if(num == 0)
      {
         return 1;
      }
      else
      {
          return (num * factorial(num-1));
      }
  
  }
  
*/
using namespace std;

int main()
{
	 int num,b=0,flag=0,i;
	 
	 cout << "enter number:" << endl;
	 cin >> num;
	 
	 b = num/2;
	 
	 for(i=2;i<=b;i++)
	 {
	 	 if(num%i == 0)
	 	 {
	 	    cout << "not prime number" << endl;
			flag=1;
			break;	
		 }
	 }
	 
	 if(flag== 0)
	 {
	 	 cout << "primt number" << endl;
	 }
}
