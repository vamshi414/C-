#include<iostream>

using namespace std;
int strlen1(char s[])
{
   int c=0;
   while(s[c])
   c++;
   
   return c;
}

void reverse(char s[])
{
    int i;
	for(i=strlen1(s)-1;i>=0;i--)
	 cout << s[i];	
}

int main()
{
	 char s[] = "vamshi krishna";
	 reverse(s);
}
