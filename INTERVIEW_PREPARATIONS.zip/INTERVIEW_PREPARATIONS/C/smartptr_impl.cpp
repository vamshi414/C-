// pointer implementation
// using template

template<class T>
class smartptr {
	T *ptr;
	public:
		explicit smartptr(T *p = NULL)
		{
			ptr = p;
		}
		
		~smartptr()
		{
			delete ptr;
		}
		
		T& operator*()
		{
			return *ptr;
		}
		
		T* operator->()
		{
			return ptr;
		}
};

main()
{
	 smartptr<int> ptr(new int())
	 *ptr = 20;
	 cout << *ptr;
}




class smartptr {
	
	int *ptr;
	
	public:
		explicit smartptr(int *p = NULL)
		{
			ptr = p;
		}
   
        ~smartptr()
        {
        	delete ptr;
		}
		
		int& operator*()
		{
			return *ptr;
		}

};

main()
{
	smartptr ptr(new int());
	*ptr = 20;
	cout << *ptr;
}
