// BST level order traversal


// LL insertion
// LL deletion

void deletewithouthead(Node *pos)
{
	if(pos == NULL)
	{
		 return;
	}
	else
	{
		 if(pos->next == NULL)
		 {
		 	 return;
		 }
	}
	
	Node *temp = pos->next;
	pos->data = pos->next->data;
	pos->next = pos->next->next;
	
	free(temp);
}


void delete(Node** head_ref)
{
	Node *current = *head_ref;
	Node *next;
	
	while(current != NULL)
	{
		next  = current->next;
		free(current);
		current = next;
	}
	
	*head_ref = NULL;
	
}


void insertafter(Node* prev_node, int new_data)
{
	 if(prev_node == NULL)
	 {
	 	return;
	 }
	 
	 Node* new_node = new Node();
	 new_node->data = new_data;
	 new_node->next = prev_node->next;
	 prev_node->next = new_node;
}

void insertend(Node** head_ref, int new_data)
{
	 Node *new_node = new Node();
	 
	 Node *last = head_ref;
	 
	 new_node->data = new_data;
	 new_node->next = NULL;
	 
	 if(*head_ref == NULL)
	 {
	 	  *head_ref = new_node;
	 	  return;
	 }
	 
	 while(last->next!= NULL)
	 {
	 	 last = last->next;
	 }
	 last->next = new_node;
	 
}

int looplength(Node *head)
{
	Node *slow = head;
	Node *fast = head;
	
	while(slow && fast && fast->next)
	{
		slow = slow->next;
		fast = fast->next->next;
		if(slow == fast)
		{
		
		  node *temp = slow;
		  temp = temp->next;
		   count =1;
	    
		  while(temp != slow)
		  {
		  	 count++;
		  	 temp = temp->next;
		  }
		  return count;
		}
		
	}
	return 0;
}

void reverse()
{
	Node * current = head;
	Node *next=null,*prev=null;
	
	while(current != NULL)
	{
		  next = current->next;
		  current->next = prev;
		  
		  prev = current;
		  current = next;
	}
	head = prev;
}

void printorder(node* root)
{
	 int h = height(root);
	 int i;
	 for(i=1;i<h;i++)
	 {
	 	  printlorder(root,i);
	 }
}


void printlorder(node* root, int level)
{
	if(root == NULL)
	{
		 return;
	}
	if(level ==1 )
	{
		  cout << root->data <<  " ";
	}
	else if (level > 1)
	{
		  printlorder(root->left,level-1);
		  printlorder(root->right,level-1);
	}
}

int height(node *root)
{
	  if(root == null)
	  {
	  	return 0;
	  }
	  
	  else
	  {
	  	 int lheight = height(root->left);
	  	 int rheight = height(root->right)
	  	 
	   if(lheight > rheight)
	       return (lheight + 1);
	   else
	      return (rheight +1);
	  }
}
