//scope 

#include<iostream>
using namespace std;

int c=10;

int main()
{
	 int c=12;
	 cout << "c:" << c<< endl;
	 cout << "C:" << ::c << endl;
}
