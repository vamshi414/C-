// length of loop in lL
// reverse of LL

void reverse()
{
    Node* current = head;
    Nod* prev,next=NULL;
    
    while(current != NULL)
    {
    	   next = current->next;
    	   current->next = prev;
    	   
    	   prev = current;
    	   current = next;
    	   
	}
     head = prev;
}

class Node
{
	  public:
	  	int data;
	  	Node *next;
};

Node *newnode(int k)
{
	Node *temp  = (Node*)malloc(sizeof(Node));
	temp->data = k;
	temp->next = NULL;
	return temp;
}

int looplength(Node *head)
{
	Node* slow = head, *fast = head;
	while(slow && fast && fast->next)
	{
		    slow = slow->next;
		    fast = fast->next->next;
		    
		    if(fast = slow)
		    {
		    	 Node *temp  = slow;
		    	 temp = temp->next;
		    	 int count=1;
		    	 while(temp != slow)
		    	 {
		    	 	  count++;
		    	 	  temp = temp->next;
				 }
				 return count;
			}
	}
	return 0;
	 
}
