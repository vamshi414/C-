//array c++

#include<iostream>
#include<array>
#include<vector>
#include<map>

using namespace std;

int main()
{
	array<int,3>  arr = {1,2,3};
	
	cout << arr.size() << endl;
	for(int i:arr)
	
	   cout << i << "\t" ;
	   cout << endl;
	vector<int> v = {1,2,3,4,5,6,7,8,9,10};
	
	for(int i:v)
	    cout << i << "\t";
	    
	cout << endl;
	
	
	map<int,int> m = { {1,1}, {2,2}, {3,3} };
	
	for(auto i: m)
	   cout << "{" << i.first << " ,"
	               << i.second << "}" <<  endl;
}
