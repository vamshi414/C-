// Any function when accompanying the keyword "Virtual" exhibits the behaviour of a virtual function
// unlike normal functions it called  with type of pointer r reference 
//
#include<iostream>

using namespace std;

class Base
{

   public:
    virtual void show()
    {
     cout << "Base class" << endl; 
    }
};

class Derived:public Base
{
   public:
    void show()
    {
       cout << "Derived class" << endl;
    }
};

int main()
{
   Base *bp = new Derived;
   bp->show();
}
