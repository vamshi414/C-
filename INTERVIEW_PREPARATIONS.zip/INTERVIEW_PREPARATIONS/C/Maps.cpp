// Maps are the associative containers that stores element by a combination of key and value
// std::map<key_type,val_type> map_name;
// 


#include<iostream>
#include<iterator>
#include<map>

using namespace std;

int main()
{
	
	std::map<int,int> marks;
		
	std::map<int,string> students { {001,"Vamshi"}, {002, "Rangam"}      };
	
	//students.insert(pair<int,string>(0001,"Vamshi"));
	//students.insert(pair<int,string>(0002,"Rangam"));
	//students.insert(pair<int,string>(0003,"VR"));
	//students.insert(pair<int,string>(0004,"Krish"));
	
	
	for(auto m:students)
	{
		  cout << m.first 
		       << "\t " << m.second << endl;
	}
	
	cout << endl;
	
	std::map<int,string>::iterator itf = students.find('V');
	
	if(itf == students.end())
	{
		cout << "not matching" << endl;
	}
	else
	{
		cout << itf->first
		     << "\t" << itf->second << endl;
	}
	
	marks.insert(pair<int,int>(100,90));
	marks.insert(pair<int,int>(101,91));
	marks.insert(pair<int,int>(102,92));
	marks.insert(pair<int,int>(103,90));
	marks.insert(pair<int,int>(104,90));
	marks.insert(pair<int,int>(105,95));
	
	std::map<int,int>::iterator it1;
	cout << "ROLL ID: \tMarks" << endl;
	for(it1 = marks.begin(); it1 != marks.end(); it1++)
	{
		cout << it1->first
		     << "\t\t" << it1->second << endl;
	}
	
	
	int num;
	num = marks.erase(105);
	
	
	cout << "deleted field" << num << endl;
	
	for(it1 = marks.begin(); it1 != marks.end(); it1++)
	{
		cout << it1->first
		     << "\t" << it1->second << endl;
	}


cout << "searching" << endl;
   std::map<int,int>::iterator it2 = marks.find(90);
   
   if(it2 == marks.end())
   {
   	cout << "Key-value pair not present in map" ;
   }
   	else {
	   
   	  cout << it2->first
   	       << "\t" << it2->second << endl;
   }
}
