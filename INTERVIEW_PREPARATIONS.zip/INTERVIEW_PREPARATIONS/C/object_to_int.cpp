// How to assign any object to primitive data type//
// we need to define operator int() to allow the conversion from object to int

#include<iostream>

using namespace std;

class Base
{
	char var;
	int data;
        public:
		Base() { }
		Base(char val) : var{val} { }
		
		operator char() const
		{
			return var;
		}

               Base(int val1) :  data{val1} { }

               operator int() const
               {
                    return data;
               }

};

int main()
{
	Base obj('V');
	char temp = obj;
	cout << temp << endl;

        Base obj1(10);
        int temp1 = obj1;

       cout << temp1 << endl;
}
