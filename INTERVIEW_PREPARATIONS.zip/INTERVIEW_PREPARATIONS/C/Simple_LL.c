#include<stdio.h>
#include<stdlib.h>


struct node
{
	int data;
	struct node *next;
};

struct node *head= NULL; //*middle,*last;
int len;

void print()
{
	struct node *temp = head;
	
	while(temp != NULL)
	{
		printf("List is: %d\t", temp->data);
		temp= temp->next;
	}
	printf("\n");
}
void insert(int x)
{
	struct node *temp = (struct node*)malloc(sizeof(struct node));
	temp->data = x;
	temp->next = head;
	head = temp;
}

int length()
{
	int count=0;
	struct node *temp = head;
	
	while(temp != NULL)
	{
		count++;
		temp = temp->next;
	}
	
	return count;
	
}

void reverse()
{
	struct node *current = head;
	struct node *prev=NULL;
	struct node *next  = NULL;
	
	while(current != NULL)
	{
		next= current->next;
		current->next = prev;
		
		prev = current;
		current = next;
		
	}
	head = prev;
}
int main()
{
	
//	head = malloc(sizeof(struct node));
//	middle = malloc(sizeof(struct node));
//	last = malloc(sizeof(struct node));
	
//	head->data=10;
//	head->next = middle;
//  middle->data=20;
//	middle->next = last;
//	last->data=30;
//	last->next = NULL;

  int x;
  printf("enter the numebr of link list:\n");
  scanf("%d", &x);
  int i;
  for(i=0;i<=x;i++)
  {
  	  //printf("enter the number\n");
  	 // scanf("%d", &i);
  	  insert(i);
  	 // i++;
  }
	
	print();
	
	reverse();

	print();
	
	len = length();
	
	printf("%d\n", len);
}
