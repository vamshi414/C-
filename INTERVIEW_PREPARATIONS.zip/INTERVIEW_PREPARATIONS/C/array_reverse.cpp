#include<stdio.h>

int main()
{
	
	char arr[5] = {10,20,30,40,50};
	int i=0;
	
	for(i=0;i<5;i++)
	{
		printf("%d \t", arr[i]);
	}
	
}
