// Adding a node at speciified node
// DLL

struct node
{
	int data;
	struct node *next;
	struct node *prev;
};

struct node *head = NULL;

void addatafter()
{
	int loc;
	struct node *temp = (struct node *)malloc(sizeof(struct node)), *p;
    int len,i=1;	
	printf("enter the location to add");
    scanf("%d", &loc);	
    len =length();
    if(loc > len)
    {
    	printf("invalid location");
    	printf("the nodes available are: %d\n", len);
    	
   	}
   	else
   	{
   	     printf("enter node data\n");
		 scanf("%d", &temp->data);
		 temp->left = NULL;
		 temp->right = NULL;
		 p = root;
		 while(i<loc)
		 {
		 	p =  p>right;
		 	i++;
		 }
		 	
		temp->right =   p->right;
		p->right->left  =   temp;
		temp->left = p;
		 p->right  =  temp;
    }
   	
   
   

}

