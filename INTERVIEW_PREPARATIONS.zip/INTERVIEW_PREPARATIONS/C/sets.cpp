// Sets
// the elements are unique, and in sorted manner, insertion and deletion, edition cant happen and it is a BST implementation

#include<iostream>
#include<set>

using namespace std;

int main()
{
	set<int,greater<int> > s1 = {5,7,8,10,11,10};
	 
	set<int> :: iterator it1;
	 
	 for(it1 = s1.begin(); it1 != s1.end(); it1++)
	 {
	 	 cout << *it1 << " ";
	 }
	 cout << endl;
	 s1.erase(5);
	 for(it1 = s1.begin(); it1 != s1.end(); it1++)
	 {
	 	 cout << *it1 << " ";
	 }
	 cout << endl;
	 
	 s1.erase(12);
	 for(it1 = s1.begin(); it1 != s1.end(); it1++)
	 {
	 	 cout << *it1 << " ";
	 }
	 cout << endl;

	 
}
