// Data structrues is a set of algorithm used to structure the information
//Algorithms --> Array, structure, link list, tree, graph, stack and queues
// algorithsms are of two types : Linear and Non linera Data structures
// linear: arranged in sequenetial manner : Arrays and Linked list, stacks and queeus
// non-linear :   arranged not in sequential manner :  Trees and Graphs
// to implement algorithms in c - > must aware in { functions,arrays,structures,pointers and DMA }

Arrays:
	->It holds more than one element
	-> it is homogenous {same date type}
	-> it is indexed based {which is much faster}
	-> derived data type 
	-> no algorithm here

arr[3] = *(arr+3 * sizeof(int));


Stacks: 
       Algorithm :  LIFO
       creation of static :  static/Dynamic
       operations in stack : 
         creation of stack
         push {Insertion}
         pop {Deletion}
         isempty
         isfull
         traverse
         length
         
Implement a stack using static:
==============================

1) Stack Creation :   
     #define  capacity  5 {global}  {size of stack}
     int stack[capacity];
     int top = -1;
	 	 
	 	

       
       
       
       
       
       
       
       
       

