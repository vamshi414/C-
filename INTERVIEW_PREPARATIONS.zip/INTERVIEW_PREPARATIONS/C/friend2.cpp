// A friend class can access the private and protected members of other class when it is declared as friend.
// friends should be used for limited purpose, it misleads to encapsulation feature
// friends cant be mutual here
// friend not inhertied

#include<iostream>

using namespace std;

class A {
	
	int a;
	public:
		A() 
		{
			a=0;
		}
	friend class B;
};

class B {
	
	public:
	void showA(A& x)
	{
		cout << x.a << endl;
	}
};

int main()
{
	  A a;
	  B b;
	  b.showA(a);
}
