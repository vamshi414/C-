#include<stdio.h>
#include<conio.h>

int main()
{
	int a,b=0,i,flag=0;
	
	printf("enter the number\n");
	scanf("%d", &a);
	
	b = a/2;
	
	for(i=2;i<=b;i++)
	{
		if(a % i == 0)
		{
			printf("enter number is not prime\n");
			flag=1;
			break;
		}
	}
	
	if(flag == 0)
	{
		printf("enter number is prime\n");
	}
}
