GDB:
g++ filename -g
gdb a.out
gdb a.out core
check ulimit -a
ulimit -a unlimited
bt
b linenum/function name
i b
until <line>
finish
delete
kill

Pointer:
++++++++++
a pointer is a variable that holds the address of another variable
A pointer can be initialized to any value anytime after it is declared.
A pointer can be assigned to point to a NULL value.
Pointers need to be dereferenced with a *.
A pointer can be changed to point to any variable of the same type.

Reference:
+++++++++
a reference is an alias for an already exisisting variable,once ref is initiliaze a varible, it cant be chnaged to other variable
A reference must be initialized when it is declared.
References cannot be NULL.
References can be used simply by name.
Once a reference is initialized to a variable, it cannot be changed to refer to a variable object.


select,poll and epoll

: simple solution to create thread for each client,block on read until  a 
request is sent and write a response, this is fine with small of amount of clients

if it scale to hundreds of clients, creating a thread for each client is bad idea.

IO multiplexing

the solution is to use a kernel mechanism  for polling over a set of file descriptors.

select,poll, epoll, three to create a set of file descriptors,
tell the kernel what do with each file desc,and use one thread to block on
one function call 

// empty class 1 byte:
1 byte is allocated by compiler for unique address identification
when we create an object of empty class in c++, it needs to store
for that it reserved 1byte 

// default constructor and copy constructor
in C++, compiler creates  default constructor, if we dont define our own constructor,
compiler creates default constructor has empty body, it doesnt assign default values to data members

compiler also creates a copy constructor, if we dont write our own copy constructor
unlike default const,body of copy const created by compiler is not empty,it copies all
data members to the obj which is being created.

++++++++++++++++++
Threads and Process:
Process --> process is a heavy weight or resource intensive
threads --> thread is light weight, 
process -->  switching needs interaction with OS, threads doesnt needs
interaction with OS
if one process is blocked, then no other process can  excute until the frst is
unblocked, whereas in thread, while one thread is blocked and waiting, second thread 
can run
-->a process means a program is in execution where as thread means segment of a process
-->process is not light weightm whereas thread is lightweight
-->process takes more time to terminate and threads takes less time to terminate
-->in process context switching is more where as in thread it is less
-->a process is isolated, whereas in thread is shared memory
-->process do not share the data, whereas threads share data each other




static and Non-static members :
static members :  
non-static members : 
	

singleton is not a factory, because it always return same instance
factory method  -> a method which wil create variety of instance
abstract factory -> a method/class which will create variety of factory instance, again using that factory instace we will create required instance
		
// singleton 
// Thread safe
// applications : -> logger, database connections, load balance...
//only 1 instance across the application
// it should be globally accessible
// keep const and dest in private so that instance cant be copied
// expose a wrapper static method, which is used to create and access the instance
// it can eb don e early r laazy init

class Database  {
	static unsigned int req_count;
	static Database database[5];
	
	Database() { }
	Database(const Database &database) { }
	Database& operator = (const Database &database) { }
	~Database()  { }
	
	public:
		static Database *get_instance()
		{
			 int id = req_count++ %5;
			 if(database[id] == nullptr)
			 {
			 	database[id] = new Database();
			 }
			 return database[id];
		}
};


unisgned int Database::req_count = 0;
Database *Database::database[5] = nullptr;

main()
{
	for (int i=0;i< 22; i++)
	{
		Database *database = Database::get_instance();
	}
}










class Singleton {
	
	private:
		Singleton() {}
		Singleton(const Singleton&) { }
		Singleton& operator =(const Singleton&) { }
	public:
		static Singleton &getinstance();
};

Singleton& singleton::getinstance()
{
	 static singleton instance;
	 return instance;
}

main()
{
	Singleton &s1 = Singleton::getinstance();
	
}



class Singleton {
	
	private:
		Singleton() { }
		Singleton(const Singleton&) { }
		Singleton &operator = (const Singleton &) { }
		~Singleton() { }
		static Singleton *instance;
	public:
		static Singleton *getinstance();
};

Singleton *singleton::instance = 0;

Singleton *singleton::getinstance()
{
	if(intance == NULL)
	{
		 instance = new Singleton();
		 return instance;
	}
}

main()
{
	 Singleton *s1 = Singleton::getinstance();
	 
}




mutex:
Mutex is a locking mechanism.
Mutex is an object.
Mutex allow multiple program thread to access a single resource but not simultaneously.
Mutex object lock is released only by the process that has acquired the lock on it.
Mutex is not categorized further.
Mutex object is locked or unlocked by the process requesting or releasing the resource.
If a mutex object is already locked, the process requesting for resources waits and queued by the system till lock is released.


Semaphore :

Semaphore is a signalling mechanism.
Semaphore is an integer variable.
Semaphore allow multiple program threads to access a finite instance of resources.
Semaphore value can be changed by any process acquiring or releasing the resource.
Semaphore can be categorized into counting semaphore and binary semaphore.
Semaphore value is modified using wait() and signal() operation.
If all resources are being used, the process requesting for resource performs wait() operation and block itself till semaphore count become greater than one.




