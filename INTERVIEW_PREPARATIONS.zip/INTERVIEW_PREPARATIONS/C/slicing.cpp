// object slicing  happens when derived class 

#include<iostream>

using namespace std;


class A {
	
	public:
		int var;
		A() {
		cout << "base constructor" << endl;
	    }
	    ~A() {
	    	cout << "base destructor" << endl;
		}
		
};

class B:public A {
	
	public:
		int var1;
		B()
		{
			cout << "derived constructor" << endl;
		}
		~B()
		{
			cout << "derived destrcutor" << endl;
		}
};


int main()
{
	B obj1;
	A obj2=obj1;
	
	cout << sizeof(obj1) << endl;
	cout << sizeof(obj2) << endl;
}
