#include<iostream>
#include<memory>

using namespace std;

class Rect
{
   int length;
   int breadth;

   public:
     Rect(int l, int b)
     {
         length = l;
         breadth = b;
     }

     int area()
     {
       return length * breadth;
     }
};

int main()
{
   std::unique_ptr<Rect> P1=std::make_unique<Rect>(10,5);
   //std::unique_ptr<Rect> P1(new Rect(10,5));
   cout << P1->area() << endl;

   std::unique_ptr<Rect> P2;
   P2 = move(P1);
   cout << P2->area() << endl;
}
