#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

#define CAPACITY 5
int stack[CAPACITY];
int top=-1;

int isfull()
{
	 if(top == CAPACITY)
	 {
	 	return 1;
	 }
	 else
	 {
	 	return 0;
	 }
	 
}
int isempty()
{
	if ( top == -1)
	  return 1;
	else
	   return 0;
}

int POP()
{
   int  data;
   if(isempty())
   {
      printf("stack is empty\n");  	
   }	
   else
   {
   	  data = stack[top];
   	  top--;
   	  return data;
   }
}


void PUSH(int x)
{
   if(isfull())
   {
   	 printf("stack is full\n");
   }	
   else
   {
   	  top++;
   	  stack[top] = x;
   }
}
int peek()
{
	 return stack[top];
}

int main()
{
	PUSH(10);
	PUSH(20);
	PUSH(30);
	PUSH(40);
	PUSH(50);
	PUSH(60);
	PUSH(70);
	
	printf("element at top of stack: %d", peek());
	printf("\n");
	
	while(!isempty())
	{
		int data = POP();
		printf("%d \t", data);
	}
    printf("\n");
	printf("element at top of stack %d:", peek());	
	
}
