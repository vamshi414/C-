#include<stdio.h>

int main()
{
	 char *str = "VamshiR";
	 printf("%c\n", *((str--+20)+1)-3);
	 printf("%c\n", *(--str+3)-32);
	 printf("%c\n",*(++str+2)+4);
}
