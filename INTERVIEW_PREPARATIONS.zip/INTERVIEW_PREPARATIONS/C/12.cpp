//double linked list
// in SLL : control in forward direction
// in DLL :  move forward and backward direction
// Add a node at begin in DLL
// Adding a node at specified node

struct node
{
	int data;
	struct node *next;
	struct node *prev;
};

struct node *head=NULL;

void addatbegin()
{
	struct node *temp = (struct node*) malloc(sizeof(struct node));  // creates the node
	
	printf("enter the node data");
	scanf("%d", &temp->data);
	
	temp->left = NULL;
	temp->right = NULL;
	
	if( head == NULL )  //there is no nodes in the list.
	{
		head = temp;
		
	}
	else
	{
	 temp->right= root;
	 head->left = temp;
	 head = temp;
	}
	
	
}
void display()
{
    struct node *temp = (struct node *) malloc(sizeof(struct node));
   
    while(temp != NULL)
    {
    	temp->data;
    	temp = temp->right;
	}
	
}

int length()
{
   struct node *temp = (struct node *) malloc(sizeof(struct node));
   
   temp = head;
   int count=0;
   
   while(temp != NULL)
   {
   	   count++;
   	   temp = temp->right;
   }
   
   return count;
   
}
