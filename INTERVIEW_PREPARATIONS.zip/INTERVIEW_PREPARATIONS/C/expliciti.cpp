// explicit constructor
// use for this :  It avoids implicit call to the constructor

#include<iostream>

using namespace std;

class Base {
	
	int b_var;
	
	public:
	   Base() {
	   }
	  explicit  Base(int var) : b_var(var) { 
	   }
	   
	   void display()
	   {
	   	   cout << b_var << endl;
       }  
};

void fun(Base b)
{
   b.display();	
}

int main()
{
	Base obj1(10) ;     // Normal 
	Base obj2 = Base(30);     // implicit
	
	fun(obj1);         //  Normal
	fun(obj2);           // implicit
}




