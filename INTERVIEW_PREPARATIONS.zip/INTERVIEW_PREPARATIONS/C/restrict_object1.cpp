#include<iostream>

using namespace std;

class Test {
	
	void *operator new(size_t size);
	int x;
	
	public:
		Test() {
			x= 9;
			cout << "constructor called" << endl;
		}
		
		void display()
		{
			cout << x << endl;
		}
		
		~Test()
		{
			 cout << "Destrcutor called" << endl;
		}
};


int main()
{
	Test obj;
	obj.display();
}
