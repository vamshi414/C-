// Virtual Functions
// to acheive the dynamic polymorphism, it is the ability to call derived class using base class pointer  r refrence
// The Base class should be as virtual and overriding that function in derived class
// virtual functions shouldnt be static and also cannot be friend of another class
// A class can have virtual distructor but not virtual constructor
// there r two types of virtual functions in c++ :  virutal and pure virtual function.

#include<iostream>

using namespace std;

class Base {
	
	public:
		virtual void fun()
		{
			cout << "Base" << endl;
		}
		virtual void fun1() = 0;
		
};

class Derived : public Base
{	
	public:
		void fun()
		{
			cout << "Derived" << endl;
		}
		void fun1()// { }
		
		{
			cout << "fun1" << endl;
		}
};

int main()
{
 	Derived d;
	Base &b = d; // new Derived();
	b.fun();
	b.fun1(); 
//	Derived d;
//	Base b1;
}
