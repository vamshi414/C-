// Templates
// The simple idea  is to pass the data type as parameter, so that we cant rewrite the code.
// syntax template<typename T>


#include<iostream>
using namespace std;

template<typename Vam>
Vam Max(Vam x, Vam y)
{
	return (x>y) ? x : y;
}

int main()
{
	cout << Max(10,20) << endl;
	cout << Max(1.5,2.5) << endl;
}
