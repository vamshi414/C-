// height and traverse order BST
// Bubble sorting 


void bubblesort(int arr[], int n)
{
	int i,j;
	bool swapped;
	
	for(i=0;i<n-1;i++)
	{
		  swapped = false;
		  for(j=0;j<n-i-1;j++)
		  {
		  	 if(arr[j] > arr[j+1])
		  	 swap(&arr[j],&arr[j+1]);
		  	 swapped=true;
		  }
	}
	
	if(swapped==false)
	break;
	
}

void bubblesort(int arr[],int n)
{
	 int i,j;
	 for(i=0;i<n-1;i++)
	    for(j=0;j<n-i-1;j++)
	    if(arr[j] > arr[j+1])
	    swap(&arr[j], &arr[j+1]);
}

void swap(int *x, int *y)
{
	int temp = *x;
	    *x   = *y;
	    *y   = temp;
}

void display(int arr[], int n)
{
	 for(int i=0;i<n;i++)
	 {
	 	  cout << arr[i] << " ";
	 }
}

+++++++++++++++++++++++++++++++++++++++++++++++
void printorder(Node* root)
{
	int h = height(root);
	for(int i=1;i<=h;i++)
	{
		printlorder(root,i);
	}
}

void printlorder(Node* root, int index)
{
   if(root == NULL)
   {
   	   return 0;
   }
   
   if(index == 1)
   {
   	   cout << root->data <<  " ";
   }
   
   else if(index > 1)
   {
   	   printlorder(root->left,index-1);
   	   printlorder(root->right,index-1);
   }
}

int height(Node* root)
{
	 if(root == NULL)
	 {
	 	 return 1;
	 }
	 else
	 {
	 	  int lheight = height(root->left);
	 	  int rheight = height(root->right);
	 	  
	 	  
	 }
	 
	 if(lheight > rheight)
	 {
	 	 return(lheight+1);
	 }
	 else
	 {
	 	 return(rheight+1);
	 }
}
