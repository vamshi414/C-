#include <iostream>
#include <vector>
#include <algorithm>
#include <utility>
#include <string>

 

 

std::vector<int> split(const std::string& s, char delimeter ) {

 


std::vector<int> v;
int idx = 0;
int eidx = 0;
int len = s.length();

 


while ( idx < len ) {

 


eidx = s.find(delimeter, idx );

 


if ( eidx != std::string::npos ) {
if ( idx != eidx ) // if token found in the same idx, just increment the idx and continue
v.push_back ( std::stoi(s.substr(idx, eidx - idx)) );
idx = eidx + 1;
} else {
if ( idx < len )
v.push_back(std::stoi(s.substr(idx)));
idx = len;
}
}

return v;
}

 

 

std::pair<int, int> find_idx_pair(std::vector<int>& v)
{

std::pair<int, int> idx_pair;

int max_distance = 0;
int lesser_j = 0;

    for(int idx1 = 0; idx1 < v.size(); ++idx1) {
        int idx2 = idx1+1;
            for_each(v.begin() + idx1 + 1 , v.end(), [&idx1, &idx2, &max_distance, &lesser_j, &v, &idx_pair](auto height){
                if ( v[idx1] <= height) {
                    int distance = idx2 - idx1;
                    // process only if current pair distance is greater than previous pair distance
                    if ( distance >= max_distance ) {
                        if ( distance > max_distance ) {
                            max_distance = distance;
                            idx_pair = std::pair<int, int>(idx1, idx2);
                            lesser_j = idx2;
                        } else {
                            if ( idx2 < lesser_j ) {
                                lesser_j = idx2;
                                idx_pair = std::pair<int, int>(idx1, idx2);
                            }
                           
                        }
                       
                    }
                }
        ++idx2;
    });
}

 


return idx_pair;
}

 

 

int main(int argc, char **argv) {

std::string str = "3 1 4 2";
auto vec = split(str, ' ');
auto idx_pair = find_idx_pair(vec);
std::cout << "output -> " << idx_pair.first << " : " << idx_pair.second << std::endl;

/*str = "2 1 1 2";
vec = split(str, ' ');
idx_pair = find_idx_pair(vec);
std::cout << "output -> " << idx_pair.first << " : " << idx_pair.second << std::endl;*/
}

