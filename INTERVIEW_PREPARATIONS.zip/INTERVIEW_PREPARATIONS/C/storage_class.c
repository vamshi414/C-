#include<stdio.h>
 int a=20;
void check();

void check()
{
	
	printf("a is %d\n", a);
}

int main()
{
	
	{
		int a=10;
		printf("Value of a: %d\n", a);
	}
	printf("a is %d\n", a);
	    static int b;
	    printf("Value of a :%d\n", a);
	    check();
while(1);
}


