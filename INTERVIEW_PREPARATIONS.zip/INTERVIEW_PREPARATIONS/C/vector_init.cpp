// Vector initiate 
#include<iostream>
#include<vector>
using namespace std;

int main()
{
	std::vector<int>v;
	v.push_back(10);
	v.push_back(20);
	v.push_back(30);
	
	for(int x:v)
	{
		cout << x << "\t" ;
	}
	cout << endl;

   int n=3;
   std::vector<int>V(n,10);
   for(int x:V)
   {
   	cout << x << "\t";
   }
   cout << endl;
   
   std::vector<int>Vect{10,20,30};
   for(int x:Vect)
   {
   	 cout << x << "\t";
   }
   cout << endl;
   
   std::vector<int> Vect1{10,20,30};
   std::vector<int>Vect2 ( Vect1.begin(), Vect1.end());
   
   for(int x:Vect2)
   {
   	 cout << x << "\t";
   }
   cout << endl;
   
   
   
}
