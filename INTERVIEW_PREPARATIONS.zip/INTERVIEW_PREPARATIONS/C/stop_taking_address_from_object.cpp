// Overload & operator make as private
// delete & operator from your class

#include<iostream>

using namespace std;

class Base {
  
      private:
        int x;

      public:
         Base() { }
         Base(int x) : x{x} { }
  /*  private:
      Base *operator & ()
      {
          cout << "enter" << endl;
          return this;
      }
        */
     Base *operator & () = delete;
};


int main()
{
    Base b;
    Base *bp=&b;
   
   cout << &b << endl;
   cout << bp << endl;
}
