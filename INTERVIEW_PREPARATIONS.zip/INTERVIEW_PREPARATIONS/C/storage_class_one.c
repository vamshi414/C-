#include<stdio.h>

void fun();
//static int a=5;
int main()
{
	fun();
	fun();
	fun();
	//while(1);
}

void fun()
{
	static int a=5;
	a+=2;
	printf("a : %d:\n", a);
}


