// Placement New : using to call destructor explicitly
// Normal new allocates memory in heap and constructs objects whereas using placement new object construction can be done at known addresses
// with normal new, it is not known that what address or memory it is pointing to where using new placement we can know where the memoery it points to
// with new usually we can use delete but here there is no placement delete ,if needed we can do with help of destructor

#include<iostream>

using namespace std;

class Base {
	
	int a;
	public:
		Base()
		{
			cout << "Base constrcutor" << endl;
		}
		
		~Base()
		{
			cout << "Base desctructor" << endl;
		}
		
};

int main()
{
	Base *obj = new Base();
	delete obj;

 
    int *memory = new int[10*sizeof(Base)];
    Base *obj1 = new (&memory[0])  Base();
    Base *obj2 = new (&memory[4])  Base();
    
    obj1->~Base();
    obj2->~Base();
    
    delete[] memory;
    
}
