// How to stop someone to inheriting from your class

#include<iostream>

using namespace std;

class Base final {
	
	private:
		int b_var;
	public:
		Base() {
		}
		Base(int var) : b_var(var) { }
		
		void display()
		{
			cout << b_var << endl;
		}
};

class Derived : public Base {

	
	private:
		int d_var;
	public:
		Derived() { }
		Derived(int a, int b) : Base(a), d_var(b) { }
		
	void display()
	{
		cout  << d_var << endl;
	}
};

int main()
{
	Base B(10);
	Derived D(10,20);
   
    B.display();
    D.display();
	
}
