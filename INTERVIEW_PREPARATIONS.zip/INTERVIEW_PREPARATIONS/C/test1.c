#include<stdio.h>
#include<string.h>
#include<stdlib.h>

void function(char* str) 
{ 
 str = ( char *) malloc(sizeof(str));
strcpy(str, "World"); 
}


int main() 
{ 
char* str = "Hello"; 
function(str); 
printf(str);
 return 0; 
}
