#include<stdio.h>
#include<conio.h>

int factorial(int n)
{
	if(n==0)
	 return 1;
	 else
	 return ( n * factorial(n-1));
}

int main()
{
	int x,fact=0;
	printf("enter the number\n");
	scanf("%d", &x);
	fact = factorial(x);
	printf("%d", fact);
}
