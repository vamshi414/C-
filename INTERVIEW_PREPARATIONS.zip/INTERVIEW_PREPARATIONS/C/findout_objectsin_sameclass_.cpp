// How to findout the objects belongs to same class in c++
// Answer : using typeid and header is <typeinfo>


#include<iostream>
#include<typeinfo>

using namespace std;

class A {
};

class B {
};

int main()
{
	A a1,a2;
	B b1,b2;
	
	if( typeid(a1) == typeid(b1) )
	{
		cout << "equal" << endl;
	}
	else
	{
		cout << "Not equal" << endl;
	}
	
	if( typeid(b1) == typeid(b2) )
	{
		cout << "equal" << endl;
	}
	else
	{
		cout << "not equal" << endl;
	}
	
	if(&b1 == &b2) 
	{
		 cout << "equal" << endl;
	}
	else
	{
		cout << "Not equal" << endl;
	}
}
