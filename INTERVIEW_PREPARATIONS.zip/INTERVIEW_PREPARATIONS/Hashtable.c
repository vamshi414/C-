#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TABLE_SIZE 100000

typedef struct entry_t
{
   char *key;
   char *value;
   struct entry_t *next;
}entry_t;

typedef struct 
{
  entry_t **entries
}ht_t;

ht_t *ht_create(void)
{
    ht_t *hashtable = malloc(sizeof(ht_t));
    
    hashtable->entries = malloc(sizeof(entry_t*) * TABLE_SIZE);

   int i=0;
   for(;i<TABLE_SIZE;i++)
   {
     hashtable->entries[i] = NULL;
   }
   return hashtable;
}

unsigned int Hash(const char *key)
{
   unsigned int long value=0;
   unsigned int i=0;
   unsigned int key_len = strlen(key);
   
   for(i=0;i<key_len;i++)
   {
      value = value * 37 + key[i];
   
   }

   value %= TABLE_SIZE;
  return value;

  
}

int main(int argc, char **argv)
{
    ht_t *ht = ht_create();

    printf("%d\n", Hash("Vamshi"));  
}
