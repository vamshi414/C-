#include<iostream>
#include<string>

using namespace std;

int maxsum(int arr[],int size)
{
	int sum=0,msum	;
	
	for(int i=0;i<size;i++)
	{
		 if(i ==0)
		 {
		 	sum = arr[i];
		 	msum = sum;
		 }
		 else
		 {
		 	sum = max(sum+arr[i], arr[i]);
		 	msum = max(sum,msum);
		 }
	}
	
	return msum;
}


int main()
{
	 int arr[] = {-2 ,1, -3, 4 ,-1, 2, 1, -5, 4};
	 int size = sizeof(arr)/sizeof(arr[0]);
	 
	 for(int i=0;i<size;i++)
	 {
	 	 cout << arr[i] << "\t";
	 }
	 cout << endl;
	 
	 cout << maxsum(arr,size) << endl;
}
