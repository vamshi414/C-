// TIMED_MUTEX is blocked till timeout_time or the lock is aqcuired and returns true otherwise false
// lock,unlock(),try_lock, try_lock_for, try_lock_until
//try_lock_for


#include<iostream>
#include<thread>
#include<mutex>

using namespace std;

int myamount=0;
std::timed_mutex m;

void increment(int i)
{
    auto now = std::chrono::steady_clock::now();
    if(m.try_lock_until( now + std::chrono::seconds(1)))
//	if(m.try_lock_for(std::chrono::seconds(1)))
	{
		++myamount;
		std::this_thread::sleep_for(std::chrono::seconds(0));
		m.unlock();
		cout << "Thread:::" << i << "Could Enter" << endl;
	}
	else
	{
		cout << "Thread:::" << i << "Couldnt Enter" << endl;
	}
}

int main()
{
	std::thread t1(increment,1);
	std::thread t2(increment,2);
	
	t1.join();
	t2.join();
	
	cout << "MyAmount" << myamount << endl;
}
