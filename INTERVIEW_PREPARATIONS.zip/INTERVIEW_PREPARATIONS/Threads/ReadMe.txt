sed -i -e 's/\r//g'
g++ Thread.cpp -o Thread -pthread -std=c++11


valgrind --tool=memcheck --leak-check=yes --show-reachable=yes --num-callers=10 --track-fds=yes ./lock_guard




 
