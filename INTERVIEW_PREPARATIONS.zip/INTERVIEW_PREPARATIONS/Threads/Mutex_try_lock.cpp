// Mutex c++11 , try_lock
//there r many try_lock function
/*
std::try_lock
std::mutex::try_lock
std::shared_lock::try_lock
std::unique_lock::try_lock
std::timed_mutex::try_lock
std::shared_mutex::try_lock
std::recursive_mutex::try_lock
std::shared_timed_mutex::try_lock
std::recursive_timed_mutex::try_lock
*/

//try_lock :  It tries to lock the mutex and returns immediately , on sucessfull acquisiton it returns true otherwise returns false
// if try_lock is not able to lock the mutex, then it wont get blocked, thats why it called "non-blocking"
// if try_lock is called again by the same thread which owns the mutex, then behaviour is undefined
// It is a dead lock situation{if you want to lock the same mutex by same thread, then to go for recursive_mutex}


#include<iostream>
#include<thread>
#include<mutex>

using namespace std;
int counter=0;
std::mutex m;

void incrementcounterfor100000time()
{
   for(unsigned int i=0;i<100000;++i)
   {
   	  if(m.try_lock() )
   	  {
   	  	++counter;
   	  	m.unlock();
	  }
   }
}

int main()
{
  std::thread t1(incrementcounterfor100000time);
  std::thread t2(incrementcounterfor100000time);
  
  t1.join();
  t2.join();
  
  cout << "counter value:" << counter << endl;	
}
