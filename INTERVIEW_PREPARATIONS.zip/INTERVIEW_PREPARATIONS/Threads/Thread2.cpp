// Way to create threads in C++11
// 5 ways to create threads in C++11
// 1. using function pointer
// 2. using Lamda function :  we can directly inject lamda at thread creation time
// 3. functor { function object}
// 4. Non-static member function
// 5. static member function


#include <iostream>
#include<thread>

using namespace std;


void fun(int x)
{
    while(x --> 0)
	{
      cout << x << endl;		
    }	 
}

class Base {
	
	public:
		
		 void operator() (int x) 
		 {
		 	while( x --> 0)
		 	{
		 		cout << x << endl;
			}
		 }
		 
		 static void run(int x)
		 {
		 	while( x -->0 )
		 	{
			 cout << x << endl; 
			}
		 }
};

int main()
{
	//std::thread t(fun,10);
	//t.join();
	
/*	auto fun = [](int x) {
		while(x --> 0)
		{
			cout << x << endl;
		}
	};
	
	std::thread t1( [] (int x) {
		while(x --> 0)
		{
			cout << x << endl;
		}
	}, 10); 
	
	
	//std::thread t1(fun,20);
	t1.join();  */
	
	//std::thread t1( Base(), 10);  // functor
	Base b;
	std::thread t1( &Base::run, 10  );
	t1.join();
	return 0;
}
