// searching thru iteration and recursive


#include<iostream>
#include<string>

//recursive


int binarysearch(int arr[], int start, int end, int element)
{
	   while(end >= start)
	   {
	   	    int middle = start + (end-start)/2;
	   	    
	   	    if(arr[middle] == element)
	   	    {
	   	        return middle;	
			}
			
			if(arr[middle] > element)
			{
				return binarysearch(arr,start,middle-1,element);
				
			}	
	   }
	
}


int binarysearch(int arr[],int start, int end,int element)
{
	while(start <= end)
	{
		  int middle = start + (end-start)/2;
		  
		  if(arr[middle] == element)
		  {
		  	   return middle;
		  }
		  if(arr[middle] <=  element)
		  {
		  	   start = middle+1; 
		  }
		  else
		  {
		  	  end = middle-1;
		  }
	}
	
}

int main()
{
	  int arr[]  = {1,2,3,4,5,6,7,8,9,10};
	  
	  int n = sizeof(arr)/ sizeof(arr[0]);
	  int element = 8;
	  
	  int found = binarysearch(arr,0,n,element);
	  
	  if(found == -1 ) {
      printf("Element not found in the array ");
   }
   else {
      printf("Element found at index : %d",found);
   }
}
