#ifndef BST_H
#define BST_H

node *create();
void insert(node*, node*);
void preorder(node *);
void postorder(node *);
void inorder(node *);
int BST(node *);
int BSTutil(node*, int, int);
int maxdepth(node*);

#endif

