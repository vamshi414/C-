//palindrome r not

#include<iostream>

using namespace std;

int revnumber(int num)
{
	int rem;
	int rev=0;
	while(num != 0)
	{
		 rem = num % 10;
		 rev = rev * 10 + rem;
		 num/= 10;
	}
	
	return rev;
}

int main()
{
	int num = 1223;
	int res;
	
	res = revnumber(num);
	
	if( num == res)
	  cout << "palindrome" << endl;
	else
	  cout << "not palindrome" << endl;
}
