#include<iostream>

using namespace std;

char *removeduplicate(char arr[],int n)
{
	int index=0;
	
	for(int i=0;i<n;i++)
	{
		int j;
		 for(j=0;j<i;j++)
		   
		    if(arr[i] == arr[j])
		      break;
		
		 if(j == i)
		 arr[index++] = arr[i];
	}
	
	return arr;
}

int main()
{
	 char arr[] = "vamshi krishna rangam";
	 int n = sizeof(arr)/sizeof(arr[0]);
	 
	 cout << removeduplicate(arr,n);
}
