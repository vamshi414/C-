#include<iostream>

//#pragma pack(1)

using namespace std;


int main()
{
	 struct base
	 {
	 	int a;
	 	char b;
	 	double d;
	 }__attribute__((packed)); ;
	 
	 struct base b;
	 cout << sizeof(b);
	 
}
