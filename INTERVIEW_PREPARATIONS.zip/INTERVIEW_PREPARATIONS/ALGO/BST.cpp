// BST
#include<iostream>
#include<stdio.h>
#include<limits.h>
//#include "BST.h"


using namespace std;

typedef struct BST
{
   int data;
   struct BST *left;
   struct BST *right;
}node;

node *create();
void insert(node*, node*);
void preorder(node *);
void postorder(node *);
void inorder(node *);
int BST(node *);
int BSTutil(node*, int, int);
int maxdepth(node*);
void levelorder(node *);
void printorder(noed *, int level);


void levelorder(node *root)
{
	int h = maxdepth(root);
	for(int i=1;i<h;i++)
	{
		printorder(root,i);
	}
}


void printorder(node *root, int level)
{
	if( root == NULL)
	{
		 return;
	}
	
	if(level == 1)
	{
		 cout << root->data << " ";
	}
	
	else if(level > 1)
	{
		printorder(root->left,level-1);
		printorder(root->right,level-1);
	}
}

int maxdepth(node* root)
{
    int ldepth;
    int rdepth;
    
    if(root == NULL)
      return 0;
    else
       ldepth = maxdepth(root->left);
       rdepth = maxdepth(root->right);
 
    if(ldepth > rdepth)
       return (ldepth+1);
    else
      return (rdepth+1);   

} 

int BST(node* root)
{
    return (BSTutil(root,INT_MIN,INT_MAX));
}

int BSTutil(node* root,int min, int max)
{
   if(root == NULL)
   {
      return 1;
   }
   if(root->data < min || root->data > max)
   {
       return 0;
   }

   return BSTutil(root->left,min,root->data-1) && BSTutil(root->right,root->data+1,max);
}


void preorder(node* root)
{
    if(root == NULL)
    {
        cout << "No Elements in BST Tree" << endl;
    }
    
    cout << root->data << "==>" ;
    if(root->left != NULL)
    {
        preorder(root->left);
    }
    if(root->right != NULL)
    {
       preorder(root->right);
    }
}

void postorder(node* root)
{
    if(root== NULL)
    {
        cout << "No Elements in BST Tree" << endl;
    }
   
   if(root->left != NULL)
   {
       postorder(root->left);
   }
   if(root->right != NULL)
   {
      postorder(root->right);
   }
   cout << root->data << "==>";
}

void inorder(node *root)
{
     if(root== NULL)
     {
         cout << "No Elements in BST Tree" << endl;
     }

     if(root->left != NULL)
     {
         inorder(root->left);
     }
     cout << root->data << "==>";
     
     if(root->right!= NULL)
     {
        inorder(root->right); 
     }


}


void insert(node* root, node* temp)
{
     if(temp->data < root->data)
     {
         if(root->left != NULL)
         {
             insert(root->left,temp);
         }
         else
         {
             root->left = temp;
         }
    }

    if(temp->data > root->data)
    {
        if(root->right != NULL)
        {
            insert(root->right,temp);
        }
        else
        {
            root->right = temp;
        }
    }

}


node *create()
{
    node *temp;
    cout << "Enter the Data" << endl;
    temp = new node;
    cin >> temp->data;
    temp->left = temp->right = NULL;
    return temp;
}


int main()
{
   char ch;
   node* root=NULL,*temp;

  do
  {
     temp = create();
     if(root == NULL)
     {
         root = temp;
     }
     else
     {
         insert(root,temp);
     }
     cout << "Do you want to continue:(y/n)?"<< endl; 
     getchar();
     cin >> ch;
  }while(ch == 'y' || ch == 'Y');

  cout << endl;
  preorder(root);
  cout << endl;
  postorder(root);
  cout << endl;
  inorder(root);
  cout << endl;

  if(BST(root))
  {
    cout << "IS BST" << endl;
  }
  else
  {
     cout << "NOT BST" << endl;
  }


  int height = maxdepth(root);
  cout << "Depth:" << height << endl; 


  
} 
