// Hash table --> an array that calls with hash function
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX_NAME 100
#define TABLE_SIZE 10

typedef struct
{
   char name[MAX_NAME];
   int age;
}person;


unsigned int hash(char *name)
{
   int length = strnlen(name,MAX_NAME);
   unsigned int hash_value=0;
    int i=0; 
   for(i=0;i<length;i++)
   {
      hash_value += name[i];
      hash_value = (hash_value * name[i]) % TABLE_SIZE;  
   }  
  
  return hash_value; 
}

int main()
{
   printf("vamshi==> %u\n", hash("vamshi"));
   printf("latha==> %u\n", hash("latha"));
   printf("Jhanu==> %u\n", hash("Jhanu")); 
   printf("Ram==> %u\n", hash("Ram"));
   printf("empty==> %u\n", hash("empty"));
  

}


