void ctest1(int *i)
{
   *i=5;
}
