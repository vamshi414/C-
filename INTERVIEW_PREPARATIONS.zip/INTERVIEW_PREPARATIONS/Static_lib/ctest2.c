void ctest2(int *i)
{
   *i=100;
}
