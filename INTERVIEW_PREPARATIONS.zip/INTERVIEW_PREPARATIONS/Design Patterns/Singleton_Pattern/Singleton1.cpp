#include<iostream>

using namespace std;

class Singleton {

      private:
          Singleton() { }
          ~Singleton() { }
         static Singleton *instance;
      public:
         static Singleton* getinstance();
};


Singleton* Singleton::instance=0;

Singleton* Singleton::getinstance()
{
    if(instance == NULL)
    {
        instance = new Singleton();
        cout << "getinstance(): First Instance" << endl;
        return instance;
    }
    else
    {
        cout << "getinstance(): Second Instance" << endl;
    }
}

int main()
{
   Singleton *s1 = Singleton::getinstance();
   Singleton *s2 = Singleton::getinstance();
} 
