#include<iostream>

using namespace std;


class Singleton {

     private:
       Singleton() {
         cout << "const" << endl; }
       ~Singleton()  {
         cout << "dest" << endl;  }
      Singleton(const Singleton&);
      const Singleton& operator=(const Singleton&);
    
    public:
      static Singleton& getinstance();
};


Singleton& Singleton::getinstance()
{
    static Singleton instance;
    return instance;
}

int main()
{
   Singleton &s1 = Singleton::getinstance();
   Singleton &s2 = Singleton::getinstance();
}




