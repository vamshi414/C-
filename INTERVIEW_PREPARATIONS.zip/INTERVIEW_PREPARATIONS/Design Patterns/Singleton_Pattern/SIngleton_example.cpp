// Singleton Sample

#include<iostream>
#include<string>

using namespace std;


class Gamesetting 
{
    static Gamesetting *_instance;
    int _brightness;
    int _height;
    int _width;
    //Gamesetting() :  _width(786), _height(1200), _brightness(70) { }
	Gamesetting()
	{
		_width = 786;
		_height=1200;
		_brightness=70;
	}
    public:
    	static Gamesetting *getinstance()
    	{
    		if( _instance == NULL )
    		{
    			_instance = new Gamesetting;
    			return _instance;
			}
		}
		
		void setbrightness(int brightness)
		{
			_brightness = brightness;
		}
		void setheight(int height)
		{
			_height = height;
		}
		void setwidth(int width)
		{
			_width = width;
		}
		
		int getbrightness()
		{
			return _brightness;
		}
		int getheight()
		{
			return _height;
		}
		int getwidth()
		{
			return _width;
		}

	    void display()
	    {
	    	cout << "brightness:" << _brightness << endl;
	    	cout << "width:" << _width << endl;
	    	cout << "height:" << _height << endl;
		}
		
};
Gamesetting *Gamesetting::_instance=0;
void somefunction()
{
	Gamesetting *setting = Gamesetting::getinstance();
	setting->display();
	
}
int main()
{
	Gamesetting *setting = Gamesetting::getinstance();
	setting->display();
	
	somefunction();
		
}
