// Bridge pattern allows you to seperate the abstraction from the implementation
//2 Parts in Bridge Pattern
// abstraction and implementation
//Decouple the abstraction from its implementation,so that two vary independently, when required we can use combine..

#include<iostream>
#include<string>


using namespace std;

class Icolor
{
   public:
      virtual string color() = 0;
};

class Redcolor: public Icolor
{
   public:
     string color()
     {
         return  "Red color";
     }
};

class Bluecolor:public Icolor
{
    public:
      string color()
      {
         return "Blue color";
      }
};

class Icarmodel
{
    public:
      virtual string mytype() = 0;
};

class Model_A:public Icarmodel
{
    Icolor *mycolor;
    public:
      Model_A(Icolor *obj) : mycolor(obj) { }

    string mytype()
    {
        return "model" + mycolor->color();
    }
};

class Model_B:public Icarmodel
{
    Icolor *mycolor;
    public:
       Model_B(Icolor *obj) : mycolor(obj) { }
    string mytype()
    {
       return "model" + mycolor->color();
    }
};


int main()
{
   Icolor* red = new Redcolor();
   Icolor* blue = new Bluecolor();
 
   Icarmodel* modelA = new Model_A(red);
   Icarmodel* modelB = new Model_B(blue);

   cout << modelA->mytype() << endl;
   cout << modelB->mytype() << endl;
}    														
