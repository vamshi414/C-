#include <bits/stdc++.h>
using namespace std; 
int main() 
{ 
    vector<int> vec{ 1,9,4,3,2,8,5,7}; 
   
    sort(vec.begin(), vec.end()); 
   
    for (auto x : vec) 
        cout << x << "" ""; 
   
    return 0; 
} 
