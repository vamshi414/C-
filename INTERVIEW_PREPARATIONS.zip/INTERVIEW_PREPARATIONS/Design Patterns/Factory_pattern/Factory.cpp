// Factory pattern
// Factory:Define an interface for creating an object, but let sub classes decide which class has to instantiate

#include<iostream>
#include<string>
#include<stdio.h>
#include<string.h>

using namespace std;


class Button {

      public:
          virtual void print() = 0;
};

class Macbutton:public Button
{
     public:
        void print()
        {
           cout << "OSMac Button" << endl;
        }
};

class Windowsbutton:public Button
{
     public:
        void print()
        {
            cout << "Windows Button" << endl;
        }
};


class GUIfactory
{
     public:
        virtual Button *createbutton(char *) = 0;
};


class Factory :public  GUIfactory
{
    public:
        Button *createbutton(char *type)
        {
            if(strcmp(type,"OSMac") == 0)
            {
                return new Macbutton;
            }
            else if(strcmp(type,"Windows") == 0) 
            {
                 return new Windowsbutton;
            }
        }
};


int main()
{
     GUIfactory*  guifactory;
     Button *btn;
     
    guifactory = new Factory;
    btn = guifactory->createbutton("OSMac");
    btn->print();
    btn = guifactory->createbutton("Windows");
    btn->print();
} 
