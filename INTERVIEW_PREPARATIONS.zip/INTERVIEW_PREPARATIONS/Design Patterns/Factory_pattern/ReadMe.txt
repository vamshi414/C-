// Factory pattern
// Factory:Define an interface for creating an object, but let sub classes decide which class has to instantiate
#include<iostream>

