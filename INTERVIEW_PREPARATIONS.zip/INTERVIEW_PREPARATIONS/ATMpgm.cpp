// ATM denomination pgm

#include<iostream>
#define SIZE 9
using namespace std;


void countcurrency(int amount)
{
	int notes[9]  = {2000,500,200,100,50,20,10,5,1};
	int notecounter[9] = { 0 };
	
	for(int i=0;i<SIZE;i++)
	{
		 if(amount >= notes[i])
		 {
		 	notecounter[i] = amount/notes[i];
		 	amount = amount-notecounter[i] * notes[i];
		 }
	}
	
	
	cout << "currency notes-> " << endl;
	
	for(int i=0;i<SIZE;i++)
	{
		if(notecounter[i] != 0)
		{
			cout << notes[i] << "  "
			     << notecounter[i] << endl;
		}
	}
}

int main()
{
	 int amount=968;
	 countcurrency(amount);
}
