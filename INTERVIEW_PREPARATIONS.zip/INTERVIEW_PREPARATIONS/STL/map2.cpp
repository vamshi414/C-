#include<iostream>
#include<map>
#include<algorithm>

using namespace std;

int main()
{
	map<int, string> students;
	
	students.insert(std::pair<int,string>(10,"Vamshi")  );
	
	for(auto &res:students)
	{
		cout << res.first << " " << res.second << endl;
	}
}
