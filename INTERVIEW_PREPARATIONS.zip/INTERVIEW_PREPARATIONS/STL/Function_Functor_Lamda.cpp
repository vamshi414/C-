// demo for Funtion,functor and Lamda

#include<iostream>
#include<algorithm>
#include<stdlib.h>

using namespace std;


class Functor
{
	public:
		int operator() (int a)
		{
			return a+3;
		}
};


int function(int a)
{
	return a+3;
}


int main()
{
	auto lamda = [] (int a) { return a+3; };
	
	Functor functor;
	
	 int i1 = function(5);
    cout << "i1:" << i1 << endl;
	 int i2 = functor(5);
    cout << "i2:" << i2 << endl;
	 int i3 = lamda(5);
	cout << "i3:" <<  i3 << endl;
	
	
}
