// define multiple ways to inititiate the List STL
// Creating & Initializing a List with c++11�s initializer_list
// initiate the list using vectors
//inititate the list using arrays

#include<iostream>
#include<list>
#include<algorithm>

using namespace std;

int main()
{
  /* std::list<int> listofints;
   
   for(int i=0;i<10;i++)  //iterate the list
   {
      listofints.push_back(i);	
   }	
   
   for(int elem:listofints)   //print the list
   { 
      cout << elem << "\t" << "" ;
   }
   
   cout << endl;
   
   std::list<int> listinitiate(5,600);
   
   for(int elem:listinitiate)
   {
   	   cout << elem << "\t" << "" ;
   }   */
   
   
  /* std::list<int> listofints( {1,2,3,4,5,6,7,8,9} );
   
   for(int i:listofints)
   {
   	 cout << i << "\t" << "";
   }  */
   
//  inititate list using vectors   
   /*std::vector<int> vectofints( {1,2,3,4,5,6,7,8,9} );
   std::list<int> listofints( vectofints.begin(), vectofints.end() );
   
   for(int elem: listofints)
   {
     cout << elem << "\t" << " " ;  	
   }   */
   
   
   // inittiate the list using arrays
   
   int arr[] = {1,2,3,4,5,6};
   
   std::list<int> listofints ( arr, arr+sizeof(arr) / sizeof(int) ) ;
   
   for(int i:listofints)
   {
      cout << i << "\t" << " "; 	
   }  
   
   
} 
