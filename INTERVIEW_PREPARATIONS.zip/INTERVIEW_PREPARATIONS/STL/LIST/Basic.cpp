#include<iostream>
#include<list>

using namespace std;

template<typename T>
void showlist(T &Vam)
{
	for(auto elem:Vam)
	{
		cout << elem << "\t";
	}
	
	cout << endl;
}

int main()
{
	list<int>g1,g2;
	
	for(int i=0;i<=10;i++)
	{
		g1.push_back(i*2);
		g2.push_back(i*3);
	}

    cout << "List of g1" << endl;
    showlist(g1);
    
    cout <<"List of g2" << endl;
    showlist(g2);
    
    cout << "Push Front" << endl;
    g1.push_front(100);
	showlist(g1);
    
    cout << "pop front" << endl;
    g1.pop_front();
    showlist(g1);
    
    cout << "pop back" << endl;
    g2.pop_back();
	showlist(g2);
	
	    
    cout << "sort" << endl;
    g1.sort();
    showlist(g1);
    
    cout << "reverse" << endl;
    g2.reverse();
    showlist(g2);
}
