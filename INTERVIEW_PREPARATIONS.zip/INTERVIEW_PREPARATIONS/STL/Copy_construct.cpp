// copy-constructors works with l-value references  means {copying the actual object to other object rather then making the another object
//  to point to already exisiting object in heap
// while move constructors work on the r-value references and it is pointing to the already exisiting object in memory

// move constructor moves the data to the Heap, where as copy constructor will the copy of exisiting object to new object, where as move
//constructor will just makes the pointer to thealready existing object in heap. so here the unnecessary creating copys will avoid.

//object_name(object_name&&obj)   // Move constructor
//           :data{obj.data}

#include<iostream>
#include<vector>

using namespace std;

class Move
{
	
	private:
		 int *data;
		
	public:
		 Move(int d)
		 {
		 	data = new int;
		 	*data = d;
		 	
		 	cout << "constrcutor is called for"
		 	     <<  d << endl;
		 }
		 
		 Move(const Move& source)
	         :Move{ *source.data }
	     {
	     	cout << "Copyng constrcutor is called for"
	     	     << "deep copy"
	     	     << *source.data
	     	     << endl;
	     	
		 }  
		 
		 Move(Move&& source)
		     :data{source.data}
		 {
		 	
		 	cout << "Moving Constructor is called for"
		 	     << *source.data << endl;
		 	     
		 	     source.data = nullptr;
		 }
		 
		 ~Move()
		 {
		 	 if(data != nullptr)
		 	 {
		 	    cout << "destrcutor is called for"
				     << *data << endl;	
		     }  
		     
		     else
		     {
		     	 cout << "destructor is called for"
		     	      <<  "nullptr"
		     	      <<   endl;
			 }
			 delete data;
		 }
};

int main()
{
	std::vector<Move> vec;
	
	vec.push_back(Move{10});
	vec.push_back(Move{20});
}


