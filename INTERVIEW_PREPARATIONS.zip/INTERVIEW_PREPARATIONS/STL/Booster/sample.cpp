#include<iostream>
#include <boost/multiprecision/cpp_int.hpp>
using namespace boost::multiprecison;
using namespace std;

int128_t large_prodct(long long n1, long long n2)
{
	int128_t ans = (int128_t)n1*n2;
	return ans;
}

int main()
{
	long long num1 = 98745636214564698;
	long long num2 = 7459874565236544789;
	
	cout << "Answer:" << endl;
	large_prodct(num1 * num2);
}
