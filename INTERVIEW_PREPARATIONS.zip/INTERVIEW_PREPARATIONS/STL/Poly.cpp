#include<iostream>

using namespace std;

class Base {
	
	public:
		
		virtual void show_val()
		{
			cout << "base class" << endl;
		}
	
};

class Derived : public Base
{
	
	public:
		void show_val()
		{
			cout << "derived class" << endl;
		}
};


int main()
{
	
//	A base;
//	B derived;
//	base.show_val();
//	derived.show_val();
	
    Base *b;
    Derived d;
    
    b = &d;
    b->show_val();

}

