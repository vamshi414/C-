//Stack

#include<iostream>
#include<stack>

using namespace std;

void showstack( std::stack<int> Data )
{
	while(!Data.empty() ) 
	{
		cout << "\t" << Data.top();
	    Data.pop();
	}
	
	cout << "\n" << endl;
	
}

int main()
{
   std::stack<int>Data;
   
   Data.push(100);
   Data.push(200);
   Data.push(50);
   Data.push(25);
   Data.push(10);
   Data.push(1);
   
   
   cout << "The Stack is:" << endl;
   cout << endl;
   showstack(Data);
   
   cout << "stack size is:" << Data.size();
   cout << endl;
   cout << "top element is:" << Data.top();
   
   cout << endl;
   cout << "After popping out one:"  << endl;
   
   Data.pop();
   
   showstack(Data);   
}
