// Queue

#include<iostream>
#include<queue>

using namespace std;

void showdata(std::queue<int> Data )
{
	while(!Data.empty() )
	{
		cout << "\t" << Data.front();
		Data.pop();
	}
	
	cout << endl;
}

int main()
{
	
	std::queue<int> Data;
	
	Data.push(10);
	Data.push(20);
	Data.push(30);
	Data.push(40);
	Data.push(50);
	Data.push(60);
	Data.push(70);
	Data.push(80);
	Data.push(1000);
	cout << "The Queue Data is:" << endl;
	
	showdata(Data);
	
	cout << "Size of Queue is: " << Data.size() << endl;
	cout << "first element in Queue: " << Data.front() << endl;
	cout << "Last element in Queue: " << Data.back() << endl;
	
	cout << endl;
	
	Data.pop();
	
	showdata(Data);

   cout << "using iterators:" << endl;
   for(auto i=Data.front(); i!= Data.back(); i++ )
   {
   	  cout << i << "\t" << endl;
   }
}
