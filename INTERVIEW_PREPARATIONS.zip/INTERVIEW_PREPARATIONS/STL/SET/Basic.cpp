// set, : it contains only unique elements
//

#include<iostream>
#include<set>

using namespace std;

int main()
{
	
	std::set<std::string> setofdata;
	
	setofdata.insert("VAMSHI");
	setofdata.insert("LATHA");
	setofdata.insert("JAHNAVI");
	setofdata.insert("RAM");
	setofdata.insert("VAMSHI");
	
	for(string st:setofdata)
	{
		cout << st << endl;
	}
	
	std::set<int>intdata;
	
	intdata.insert(10);
	intdata.insert(20);
	intdata.insert(30);
	intdata.insert(10);
	
	for(int i:intdata)
	{
		cout << i << endl;
	}
	
	intdata.erase(20);
	for(int i:intdata)
	{
		cout << i << endl;
	}
	
	set<int> s2(intdata.begin(), intdata.end() );
	
	cout << endl;
	
	for(int i:s2)
	{
		cout << i << endl;
	}
}
