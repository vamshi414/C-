// STL :
// containers,iterators,algorithm
// STD::ARRAY
// this container around the fixed of arrays and also dont lose the information of its length when decyaed to pointer

#include<iostream>
#include<array>
#include<algorithm>
#include<string>

using namespace std;

int main()
{
  std::array<int,5> ar1 = {1,2,3,4,5};
  std::array<float,5> ar2 = {1.1,2.2,3.3,4.4,5.5};
  
  std::array<string,2> ar3 = { {string("VAMSHI"), ("LATHA") } };
  
  cout << ar1.size() << endl;
  cout << ar2.size() << endl;
  cout << ar3.size() << endl;
  cout << endl;	
  for(int i:ar1)
  {
  	 cout << i << endl;
  }
  cout << endl;
  for(float i:ar2)
  { 
     cout << i << endl;
  }
  
  ar1.fill(10);
    cout << endl;	
  for(int i:ar1)
  {
  	 cout << i << endl;
  }


  for(string s:ar3)
  {
  	 cout << s << "\t" << endl;
  }
  
}

