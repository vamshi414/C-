// The class which has only one instance, and provides a global point access to tat instance
// one and only one instance,global access,No ownership and lazy init
// save memoery -> only one is required so why to create many
// Single access point -> Logger and Database connection
// Multi threaded-> threadpool
// Logging in DB
// config settings:  game settings
// to create singleton -> static member, private constructor, static function
// 


#include<iostream>
#include<string>

using namespace std;

class Gamesetting {
	
	static Gamesetting *_instance;
	int _brightness;
	int _width;
	int _height;
	Gamesetting() : _brightness(100), _width(50), _height(25) {
	}
	
	public:
		static Gamesetting *getinstance()
		{
			if(_instance == NULL)
			{
				_instance = new Gamesetting();
				return _instance;
			}
		}
     
    void setwidth(int width)
    {
    	_width = width;
	}
	
	void setheight(int height)
	{
		_height = height;
		
	}
	
	void setbrightness(int brightness)
	{
		_brightness = brightness;
	}
	
	int getwidth()
	{
		return _width;
	}
	
	int getheight()
	{
		return _height;
	}
	
	int getbrightness()
	{
		return _brightness;
	}

   void display()
   {
   	
   	  cout << "brightness:" << _brightness << endl;
   	  cout << "height:" << _height << endl;
   	  cout << "width:" << _width << endl;
   }
};


Gamesetting *Gamesetting::_instance = NULL;


void fun1()
{
   Gamesetting *setting1 = Gamesetting::getinstance();
   
   setting1->setwidth(200);
   setting1->setbrightness(100);
   setting1->setheight(300);
   setting1->display() ;
}


int main()
{
	
	Gamesetting *setting = Gamesetting::getinstance();
	
	setting->display();
	
	cout << endl;
	
	fun1();
	
}
