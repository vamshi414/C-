// continous sub array

int maxsum(int arr[],int size)
{

int sum,msum=0;

for(int i=0;i<size;i++)
{
	  if(i ==0)
	  {
	  	sum = arr[i];
	  	msum = sum;
	  }
	  else
	  {
	  	 sum = max(sum+a[i], a[i]);
	  	 msum = max(sum,msum);
	  }
	  
}
     return msum;
}


//find unique non-repeating value:

void nonrepeat(int arr[],int n)
{
	  unordered_map<int,int>data;
	  
	  for(int i=0;i<n;i++)
	      data[arr[i]]++;
	      
	 for(auto x:data)
	     if(x.second == 1)
	     cout << x.first << " "; 
}




