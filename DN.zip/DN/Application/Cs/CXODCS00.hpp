//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3DE26F5A0186.cm preserve=no
//	$Date:   Oct 16 2018 13:25:18  $ $Author:   e1009652  $ $Revision:   1.8  $
//## end module%3DE26F5A0186.cm

//## begin module%3DE26F5A0186.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%3DE26F5A0186.cp

//## Module: CXOPCS00%3DE26F5A0186; Package specification
//## Subsystem: CS%3DE26E9D009C
//## Source file: C:\Devel\ConnexPlatform\Server\Application\Cs\CXODCS00.hpp

#ifndef CXOPCS00_h
#define CXOPCS00_h 1

//## begin module%3DE26F5A0186.additionalIncludes preserve=no
//## end module%3DE26F5A0186.additionalIncludes

//## begin module%3DE26F5A0186.includes preserve=yes
// $Date:   Oct 16 2018 13:25:18  $ $Author:   e1009652  $ $Revision:   1.8  $
#include <set>
#include <vector>
//## end module%3DE26F5A0186.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Sleep;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
} // namespace timer

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;
} // namespace platform

class SynchronousSocket;

//## begin module%3DE26F5A0186.declarations preserve=no
//## end module%3DE26F5A0186.declarations

//## begin module%3DE26F5A0186.additionalDeclarations preserve=yes
//## end module%3DE26F5A0186.additionalDeclarations


//## begin ClientSimulator%3DE26ED802EE.preface preserve=yes
//## end ClientSimulator%3DE26ED802EE.preface

//## Class: ClientSimulator%3DE26ED802EE
//## Category: Connex Application::ClientSimulator_CAT%3DE26E74034B
//## Subsystem: CS%3DE26E9D009C
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3DE28F36000F;SynchronousSocket { -> F}
//## Uses: <unnamed>%3E1DAD8C0138;IF::Extract { -> F}
//## Uses: <unnamed>%3E1DC8EA0261;IF::Sleep { -> F}
//## Uses: <unnamed>%3E1DD32B0399;IF::Trace { -> F}
//## Uses: <unnamed>%43CA611300FA;platform::Platform { -> F}
//## Uses: <unnamed>%48C90FEA0333;monitor::UseCase { -> F}

class ClientSimulator : public process::Application  //## Inherits: <unnamed>%3E1B57AE0177
{
  //## begin ClientSimulator%3DE26ED802EE.initialDeclarations preserve=yes
  //## end ClientSimulator%3DE26ED802EE.initialDeclarations

  public:
    //## Constructors (generated)
      ClientSimulator();

    //## Constructors (specified)
      //## Operation: ClientSimulator%3DE295CA005D
      ClientSimulator (const char* pszConnection, const char* pszUserID, const char* pszPassword, const char* pszResponse);

    //## Destructor (generated)
      virtual ~ClientSimulator();


    //## Other Operations (specified)
      //## Operation: initialize%3DE26F1B007D
      int initialize ();

      //## Operation: onQuiesce%3E50E348029F
      //	Responds to the quiesce request from FaultManager to
      //	indicate that the Application has quiesced.
      virtual int onQuiesce ();

      //## Operation: transact%3E1DC6E502FD
      void transact (const string& strMessage);

    // Additional Public Declarations
      //## begin ClientSimulator%3DE26ED802EE.public preserve=yes
      //## end ClientSimulator%3DE26ED802EE.public

  protected:

    //## Other Operations (specified)
      //## Operation: onResume%3E1DC61A009C
      virtual int onResume (Message& hMessage);

      //## Operation: shutdown%3E1DC941002E
      //	Marks the Application as shutdown.
      virtual int shutdown ();

    // Additional Protected Declarations
      //## begin ClientSimulator%3DE26ED802EE.protected preserve=yes
      //## end ClientSimulator%3DE26ED802EE.protected

  private:

    //## Other Operations (specified)
      //## Operation: interpretResponse%4059A4BD009C
      void interpretResponse (const string& strReply);

      //## Operation: modifyRequest%4059AADF0232
      void modifyRequest (string& strRequest);

    // Additional Private Declarations
      //## begin ClientSimulator%3DE26ED802EE.private preserve=yes
      //## end ClientSimulator%3DE26ED802EE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Char%4059C26A0232
      //## begin ClientSimulator::Char%4059C26A0232.attr preserve=no  private: int {V} 0
      int m_nChar;
      //## end ClientSimulator::Char%4059C26A0232.attr

      //## Attribute: Connection%3DE270790222
      //## begin ClientSimulator::Connection%3DE270790222.attr preserve=no  private: string {U} 
      string m_strConnection;
      //## end ClientSimulator::Connection%3DE270790222.attr

      //## Attribute: Delay%3E1DFA8C005D
      //## begin ClientSimulator::Delay%3E1DFA8C005D.attr preserve=no  private: string {V} 
      string m_strDelay;
      //## end ClientSimulator::Delay%3E1DFA8C005D.attr

      //## Attribute: Hour%4059D63A02DE
      //## begin ClientSimulator::Hour%4059D63A02DE.attr preserve=no  private: int {V} 0
      int m_iHour;
      //## end ClientSimulator::Hour%4059D63A02DE.attr

      //## Attribute: Index%3E50F65202BF
      //## begin ClientSimulator::Index%3E50F65202BF.attr preserve=no  private: int {V} 1
      int m_nIndex;
      //## end ClientSimulator::Index%3E50F65202BF.attr

      //## Attribute: Numeric%4059C26A03C8
      //## begin ClientSimulator::Numeric%4059C26A03C8.attr preserve=no  private: int {V} 0
      int m_nNumeric;
      //## end ClientSimulator::Numeric%4059C26A03C8.attr

      //## Attribute: Password%3DE2707602CE
      //## begin ClientSimulator::Password%3DE2707602CE.attr preserve=no  private: string {V} 
      string m_strPassword;
      //## end ClientSimulator::Password%3DE2707602CE.attr

      //## Attribute: Requests%3DE2707E008C
      //## begin ClientSimulator::Requests%3DE2707E008C.attr preserve=no  private: FILE* {V} 0
      FILE* m_pRequests;
      //## end ClientSimulator::Requests%3DE2707E008C.attr

      //## Attribute: Response%3DE27077002E
      //## begin ClientSimulator::Response%3DE27077002E.attr preserve=no  private: string {V} 
      string m_strResponse;
      //## end ClientSimulator::Response%3DE27077002E.attr

      //## Attribute: Responses%3DE2707E0167
      //## begin ClientSimulator::Responses%3DE2707E0167.attr preserve=no  private: FILE* {V} 0
      FILE* m_pResponses;
      //## end ClientSimulator::Responses%3DE2707E0167.attr

      //## Attribute: SecurityData%3E1DC82600EA
      //## begin ClientSimulator::SecurityData%3E1DC82600EA.attr preserve=no  private: string {V} 
      string m_strSecurityData;
      //## end ClientSimulator::SecurityData%3E1DC82600EA.attr

      //## Attribute: Timestamps%3E1DC839003E
      //## begin ClientSimulator::Timestamps%3E1DC839003E.attr preserve=no  private: string {V} 
      string m_strTimestamps;
      //## end ClientSimulator::Timestamps%3E1DC839003E.attr

      //## Attribute: UserID%3DE26F360148
      //## begin ClientSimulator::UserID%3DE26F360148.attr preserve=no  private: string {V} 
      string m_strUserID;
      //## end ClientSimulator::UserID%3DE26F360148.attr

    // Data Members for Associations

      //## Association: Connex Application::ClientSimulator_CAT::<unnamed>%4059D2E20119
      //## Role: ClientSimulator::<m_hDate>%4059D2E2035B
      //## begin ClientSimulator::<m_hDate>%4059D2E2035B.role preserve=no  public: timer::Date { -> VFHgN}
      timer::Date m_hDate;
      //## end ClientSimulator::<m_hDate>%4059D2E2035B.role

    // Additional Implementation Declarations
      //## begin ClientSimulator%3DE26ED802EE.implementation preserve=yes
      vector<string> m_hRequests;
      set<string>::iterator m_pProcessor;
      set<string>::iterator m_pInstitution;
      set<string>::iterator m_pReportingLevel;
      set<string>::iterator m_pDevice;
      set<string>::iterator m_pPAN;
      set<string> m_hProcessors;
      set<string> m_hInstitutions;
      set<string> m_hReportingLevels;
      set<string> m_hDevices;
      set<string> m_hPANs;
      string m_strStartDate;
      string m_strEndDate;
      int    m_iStartHour;
      //## end ClientSimulator%3DE26ED802EE.implementation
};

//## begin ClientSimulator%3DE26ED802EE.postscript preserve=yes
//## end ClientSimulator%3DE26ED802EE.postscript

//## begin module%3DE26F5A0186.epilog preserve=yes
//## end module%3DE26F5A0186.epilog


#endif
