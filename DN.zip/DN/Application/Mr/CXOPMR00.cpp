//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%515498940177.cm preserve=no
//	$Date:   Mar 02 2017 13:19:10  $ $Author:   e1009839  $ $Revision:   1.1  $
//## end module%515498940177.cm

//## begin module%515498940177.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%515498940177.cp

//## Module: CXOPMR00%515498940177; Package body
//## Subsystem: MR%5154986F000E
//## Source file: C:\bV02.4B.R001\Build\ConnexPlatform\Server\Application\Mr\CXOPMR00.cpp

//## begin module%515498940177.additionalIncludes preserve=no
//## end module%515498940177.additionalIncludes

//## begin module%515498940177.includes preserve=yes
//## end module%515498940177.includes

#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF39_h
#include "CXODIF39.hpp"
#endif
#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOPMR00_h
#include "CXODMR00.hpp"
#endif


//## begin module%515498940177.declarations preserve=no
//## end module%515498940177.declarations

//## begin module%515498940177.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new MailRelay();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%515498940177.additionalDeclarations


// Class MailRelay 

MailRelay::MailRelay()
  //## begin MailRelay::MailRelay%515497CC0035_const.hasinit preserve=no
  //## end MailRelay::MailRelay%515497CC0035_const.hasinit
  //## begin MailRelay::MailRelay%515497CC0035_const.initialization preserve=yes
  //## end MailRelay::MailRelay%515497CC0035_const.initialization
{
  //## begin MailRelay::MailRelay%515497CC0035_const.body preserve=yes
   memcpy(m_sID,"MR00",4);
  //## end MailRelay::MailRelay%515497CC0035_const.body
}


MailRelay::~MailRelay()
{
  //## begin MailRelay::~MailRelay%515497CC0035_dest.body preserve=yes
  //## end MailRelay::~MailRelay%515497CC0035_dest.body
}



//## Other Operations (implementation)
int MailRelay::getThreadId (IF::Message& hMessage)
{
  //## begin MailRelay::getThreadId%530508A802ED.body preserve=yes
   IString strThread = hMessage.getCorrelId();
   if(strThread.length() < 8)
      return 0;
   char sHex[17] = {"0123456789abcdef"};
   int j = 1;
   int iThreadId = 0;
   for(int i = 8; i > 0; i--)
   {
      iThreadId += (strchr(sHex,strThread[i]) - sHex) * j;
      j *= 16;
   }
   return iThreadId;
  //## end MailRelay::getThreadId%530508A802ED.body
}

int MailRelay::initialize ()
{
  //## begin MailRelay::initialize%515497FE03B4.body preserve=yes
   new platform::Platform();
   int iRC = Application::initialize();
   UseCase hUseCase("FD","## FDnn START MR");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   ((SocketQueue*)getQueue())->setInterface(SocketQueue::CRLF);
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->connect();
   return 0;
  //## end MailRelay::initialize%515497FE03B4.body
}

int MailRelay::onConnect (Message& hMessage)
{
  //## begin MailRelay::onConnect%5159A350036A.body preserve=yes
   char* p = hMessage.buffer();
   memcpy(p,"220 \n",5);
   hMessage.setMessageLength(5);
   Queue::reply(getThreadId(hMessage),&hMessage);
   m_strResponse.assign("221 \n",5);
   return 0;
  //## end MailRelay::onConnect%5159A350036A.body
}

int MailRelay::onMessage (Message& hMessage)
{
  //## begin MailRelay::onMessage%515498010103.body preserve=yes
   char* p = hMessage.buffer();
   if (m_strResponse.empty())
   {
      if (memcmp(p,".\r\n",3) == 0)
         m_strResponse.assign("250 \n",5);
   }
   else
   {
      if (memcmp(p,"HELO",4) == 0
         || memcmp(p,"MAIL",4) == 0
         || memcmp(p,"RCPT",4) == 0)
         m_strResponse.assign("250 \n",5);
      else
      if (memcmp(p,"DATA",4) == 0)
         m_strResponse.assign("354 \n",5);
      else
      if (memcmp(p,"QUIT",4) == 0)
         m_strResponse.assign("221 \n",5);
   }
   if (!m_strResponse.empty())
   {
      memcpy(p,m_strResponse.data(),5);
      hMessage.setMessageLength(5);
      Queue::reply(getThreadId(hMessage),&hMessage);
      if (m_strResponse == "354 \n")
         m_strResponse.erase();
      if (m_strResponse == "221 \n")
      {
         Sleep::goTo("00000100");
         Queue::close(string((char*)hMessage.getCorrelId(),8));
      }
   }
   return 0;
  //## end MailRelay::onMessage%515498010103.body
}

// Additional Declarations
  //## begin MailRelay%515497CC0035.declarations preserve=yes
  //## end MailRelay%515497CC0035.declarations

//## begin module%515498940177.epilog preserve=yes
//## end module%515498940177.epilog
