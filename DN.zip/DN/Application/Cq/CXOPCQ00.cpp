//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36ED89160344.cm preserve=no
//	$Date:   Mar 20 2017 12:07:52  $ $Author:   e1094689  $ $Revision:   1.17.1.0  $
//## end module%36ED89160344.cm

//## begin module%36ED89160344.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%36ED89160344.cp

//## Module: CXOPCQ00%36ED89160344; Package body
//## Subsystem: AS%36ED88CA0313
//## Source file: C:\bV02.3B.R001\Windows\Build\ConnexPlatform\Server\Application\Cq\CXOPCQ00.cpp

//## begin module%36ED89160344.additionalIncludes preserve=no
//## end module%36ED89160344.additionalIncludes

//## begin module%36ED89160344.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),ENVAR('TASK=CQ'))
#endif
//## end module%36ED89160344.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF23_h
#include "CXODIF23.hpp"
#endif
#ifndef CXOSBC07_h
#include "CXODBC07.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSBC08_h
#include "CXODBC08.hpp"
#endif
#ifndef CXOSBC27_h
#include "CXODBC27.hpp"
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
#ifndef CXOSBC04_h
#include "CXODBC04.hpp"
#endif
#ifndef CXOSBC05_h
#include "CXODBC05.hpp"
#endif
#ifndef CXOSBC03_h
#include "CXODBC03.hpp"
#endif
#ifndef CXOSBC12_h
#include "CXODBC12.hpp"
#endif
#ifndef CXOSBC13_h
#include "CXODBC13.hpp"
#endif
#ifndef CXOSBC09_h
#include "CXODBC09.hpp"
#endif
#ifndef CXOSBC10_h
#include "CXODBC10.hpp"
#endif
#ifndef CXOSBC14_h
#include "CXODBC14.hpp"
#endif
#ifndef CXOSBC11_h
#include "CXODBC11.hpp"
#endif
#ifndef CXOSBC24_h
#include "CXODBC24.hpp"
#endif
#ifndef CXOSBC28_h
#include "CXODBC28.hpp"
#endif
#ifndef CXOPCQ00_h
#include "CXODCQ00.hpp"
#endif


//## begin module%36ED89160344.declarations preserve=no
//## end module%36ED89160344.declarations

//## begin module%36ED89160344.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new AccessSecurity();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%36ED89160344.additionalDeclarations


// Class AccessSecurity 

AccessSecurity::AccessSecurity()
  //## begin AccessSecurity::AccessSecurity%3ABCB25C0384_const.hasinit preserve=no
      : m_pLogonCommand(0),
        m_pLogoffCommand(0),
        m_pDynamicSQLCommand(0),
        m_pGetCustomizationCommand(0),
        m_pGetCustomizationStatusCommand(0),
        m_pGetProfileCommand(0),
        m_pGetRelationshipCommand(0),
        m_pGetUserIdListCommand(0),
        m_pUpdateCustomizationCommand(0),
        m_pCommandWatch(0),
        m_pKeyXchgCommand(0)
  //## end AccessSecurity::AccessSecurity%3ABCB25C0384_const.hasinit
  //## begin AccessSecurity::AccessSecurity%3ABCB25C0384_const.initialization preserve=yes
  //## end AccessSecurity::AccessSecurity%3ABCB25C0384_const.initialization
{
  //## begin AccessSecurity::AccessSecurity%3ABCB25C0384_const.body preserve=yes
   memcpy(m_sID,"CQ00",4);
  //## end AccessSecurity::AccessSecurity%3ABCB25C0384_const.body
}


AccessSecurity::~AccessSecurity()
{
  //## begin AccessSecurity::~AccessSecurity%3ABCB25C0384_dest.body preserve=yes
   UserSession::terminate();
   delete m_pCommandWatch;
   delete m_pLogonCommand;
   delete m_pLogoffCommand;
   delete m_pKeyXchgCommand;
   delete m_pGetProfileCommand;
   delete m_pGetRelationshipCommand;
   delete m_pGetCustomizationStatusCommand;
   delete m_pGetCustomizationCommand;
   delete m_pUpdateCustomizationCommand;
  //## end AccessSecurity::~AccessSecurity%3ABCB25C0384_dest.body
}



//## Other Operations (implementation)
int AccessSecurity::initialize ()
{
  //## begin AccessSecurity::initialize%3ABCB308016E.body preserve=yes
   new platform::Platform();
   new segment::AuditEvent;
   int i = Application::initialize();
   // CL08: Operator_Starts_CRQueryServer
   UseCase hUseCase("CLIENT","## CL08 START CRQ");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
#ifndef CS
   platform::Platform::instance()->createDatabaseFactory();
#endif
   Database::instance()->attach(this);
#ifndef CS
   m_pUpdateCustomizationCommand = new UpdateCustomizationCommand(0);
   m_pGetCustomizationCommand = new GetCustomizationCommand(m_pUpdateCustomizationCommand);
   m_pGetCustomizationStatusCommand = new GetCustomizationStatusCommand(m_pGetCustomizationCommand);
   m_pGetRelationshipCommand = new GetRelationshipCommand(m_pGetCustomizationStatusCommand);
   m_pGetProfileCommand = new GetProfileCommand(m_pGetRelationshipCommand);
#ifndef MVS
   Database::instance()->attach(new DNSecurity());
#endif
#endif
#ifdef MVS
   string strSecurity;
   Extract::instance()->getSpec("SECURITY",strSecurity);
   if (strSecurity == "OPEN")
   {
      Database::instance()->attach(new DNSecurity());
      Security::instance()->setSecurityType(strSecurity);
   }
#endif
   m_pKeyXchgCommand = new KeyXchgCommand(m_pGetProfileCommand);
   m_pLogoffCommand = new LogoffCommand(m_pKeyXchgCommand);
   m_pLogonCommand = new LogonCommand(m_pLogoffCommand);
   m_pCommandWatch = new CommandWatch();
   Database::instance()->connect();
   return 0;
  //## end AccessSecurity::initialize%3ABCB308016E.body
}

int AccessSecurity::onMessage (IF::Message& hMessage)
{
  //## begin AccessSecurity::onMessage%3ABCB30B0385.body preserve=yes
   if (hMessage.messageID() == "H5050D")
   {
      DynamicSQLCommand hDynamicSQLCommand;
      hDynamicSQLCommand.execute();
      Database::instance()->commit();
   }
   else
   if (hMessage.messageID() == "C4611R")
      UserPool::instance()->securityResponse(hMessage);
   else
   {
      Transaction::instance()->begin();
      m_pLogonCommand->update(Message::instance(Message::INBOUND));
      if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
         Database::instance()->rollback();
      else
         Database::instance()->commit();
      Transaction::instance()->commit();
   }
   return 0;
  //## end AccessSecurity::onMessage%3ABCB30B0385.body
}

void AccessSecurity::update (Subject* pSubject)
{
  //## begin AccessSecurity::update%3EA0227C0138.body preserve=yes
#ifdef MVS
   if (pSubject == Database::instance())
      if (Database::instance()->state() == Database::CONNECTED)
         Queue::attach("@CRQ    ",Queue::CX_SELECTION_QUEUE);
#endif
   Application::update(pSubject);
  //## end AccessSecurity::update%3EA0227C0138.body
}

// Additional Declarations
  //## begin AccessSecurity%3ABCB25C0384.declarations preserve=yes
  //## end AccessSecurity%3ABCB25C0384.declarations

//## begin module%36ED89160344.epilog preserve=yes
//## end module%36ED89160344.epilog
