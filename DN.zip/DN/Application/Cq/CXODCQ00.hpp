//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36ED89150176.cm preserve=no
//	$Date:   Jul 15 2013 15:54:50  $ $Author:   e1009652  $ $Revision:   1.9  $
//## end module%36ED89150176.cm

//## begin module%36ED89150176.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%36ED89150176.cp

//## Module: CXOPCQ00%36ED89150176; Package specification
//## Subsystem: AS%36ED88CA0313
//## Source file: C:\bV02.3B.R001\Windows\Build\ConnexPlatform\Server\Application\Cq\CXODCQ00.hpp

#ifndef CXOPCQ00_h
#define CXOPCQ00_h 1

//## begin module%36ED89150176.additionalIncludes preserve=no
//## end module%36ED89150176.additionalIncludes

//## begin module%36ED89150176.includes preserve=yes
// $Date:   Jul 15 2013 15:54:50  $ $Author:   e1009652  $ $Revision:   1.9  $
//## end module%36ED89150176.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Extract;
class QueueFactory;
class Session;
class Queue;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class AuditEvent;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class DNSecurity;
class CommandWatch;
class GetUserIdListCommand;
class GetRelationshipCommand;
class GetProfileCommand;
class UpdateCustomizationCommand;
class GetCustomizationStatusCommand;
class GetCustomizationCommand;
class UserSession;
class UserPool;
class LogoffCommand;
class LogonCommand;
class DynamicSQLCommand;
class KeyXchgCommand;
} // namespace command

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;

} // namespace platform

//## begin module%36ED89150176.declarations preserve=no
//## end module%36ED89150176.declarations

//## begin module%36ED89150176.additionalDeclarations preserve=yes
//## end module%36ED89150176.additionalDeclarations


//## begin AccessSecurity%3ABCB25C0384.preface preserve=yes
//## end AccessSecurity%3ABCB25C0384.preface

//## Class: AccessSecurity%3ABCB25C0384
//	<body>
//	<title>IG
//	<h1>HS
//	<h2>AB
//	<h3>Setup
//	<p>
//	The CR Client for DataNavigator Security is installed
//	for each security administrator.
//	</p>
//	<ol>
//	<li>Start ... Programs ... IBM DB2 ... Set-up Tools ...
//	Configuration Assistant
//	<li>Establish a connection to the DataNavigator database
//	<li>Install the CR Client for DataNavigator Security
//	using the CR Client CD
//	<li>Start ... Programs ... CR Client ... DataNavigator
//	Security
//	</ol>
//	<h2>FI
//	<h3>Installation prerequisites
//	<p>
//	The CR Client for DataNavigator Security requires the
//	following:
//	<ul>
//	<li>Microsoft Windows 2000 or XP
//	<li>IBM UDB Version 8 Client Software
//	</ul>
//	<h2>FO
//	<h3>Results of installation
//	<p>
//	The following items are established during installation:
//	<ol>
//	<li>Connection to the DataNavigator database
//	<li>Program group: CR Client
//	<li>C:\Program Files\eFunds\CR Client
//	</ol>
//	</body>
//	<body>
//	<title>CG
//	<h1>CQ
//	<h2>AB
//	<p>
//	The CR Client for DataNavigator Security is used to
//	define the end users that have web client access to Data
//	Navigator.
//	Each user is defined with a password and profile
//	information that limits their access to specific
//	functionality and data.
//	DataNavigator supports an LDAP interface to IBM RACF for
//	password authentication.
//	<p>
//	<!-- release V02.2B.R001 -->
//	The DataNavigator web client can be integrated with your
//	existing web portal using SiteMinder.
//	With this integration, the web client logs in with a
//	digital signature instead of a password.
//	The user ID must still be defined to DataNavigator with
//	the appropriate profile information.
//	<!-- /release -->
//	<h3>System Flow
//	<p>
//	All requests from end users flow through the Client
//	Interface service.
//	The logon and profile retrieval requests are processed
//	by the Access Security service.
//	<p>
//	Access Security provides:
//	<ul>
//	<li>Authentication of user IDs and passwords
//	<li>Verification of access to business functions
//	<li>Verification of access to transactions
//	</ul>
//	</p>
//	<img src=CXOCCQ00.gif>
//	<h2>MS
//	<h3>Batch Load
//	<p>
//	For DataNavigator on the IBM z/OS platform, users can be
//	added to Access Security using a batch process.
//	The procedure adds users to the Connex VSAM security
//	file and the DataNavigator user and profile tables in
//	DB2.
//	All user IDs are assumed to be in RACF.
//	This procedure does not delete any existing user IDs or
//	profiles.
//	<p>
//	The input file <i>node001.qualify</i>.USERS contains the
//	following information:
//	<ul>
//	<li>User ID
//	<li>User name
//	<li>Entity ID
//	<li>Profile ID
//	</ul>
//	<p>
//	All entity and profile values must be established in
//	Access Security before running the batch load.
//	<p>
//	Review the following job
//	'<i>node001.qualify</i>.USER.CNTL(ASLOAD)' for more
//	details:
//	<p>
//	#include dn\platform\ibmzos\template\CXOXASLD.txt
//	<p>
//	<h2>MS
//	<h3>LDAP
//	<p>
//	To use the optional LDAP interface to IBM RACF, the Site
//	Specification custom table data for Access Security must
//	include LDAPHN1 (host name), LDAPPN1 (port number) and
//	LDAPDN (distinguished name) entries for the IBM LDAP
//	server.
//	<p>
//	Sample entries from an Access Security extract file:
//	<p>
//	<ul>
//	<li>DSPEC LDAPHN1 111.222.333.444
//	<li>DSPEC LDAPPN1 389
//	<li>DSPEC LDAPDN
//	racfid=XXXXXXXX,profiletype=user,sysplex=zosa3,o=ibm
//	</ul>
//	An alternative LDAP host can be configured using entries
//	named LDAPHN2 (host name) and LDAPPN2 (port number).
//	Custom Table Data definitions are in the Custom Tables
//	folder in the CR Client for the DataNavigator Server.
//	</body>
//	<body>
//	<title>OG
//	<h1>CQ
//	<h2>AB
//	<h3>System Flow
//	<p>
//	All requests from end users flow through the Client
//	Interface service.
//	Logon and data access requests are processed by Access
//	Security.
//	<p>
//	Access Security provides:
//	<ul>
//	<li>Authentication of user IDs and passwords
//	<li>Verification of access to business functions
//	<li>Verification of access to transactions
//	</ul>
//	</p>
//	<img src=CXOOCQ00.gif>
//	</p>
//	<h2>TS
//	<h3>DataNavigator Client
//	<p>
//	<b>Issue:</b>  End user reporting problems with services
//	provided by Access Security.
//	<p>
//	<b>Resolution:</b>  Refer to the Troubleshooting tips
//	for the Client Interface in the <i>DataNavigator Server
//	Operations Guide: Foundation</i> manual.
//	</p>
//	</body>
//## Category: Connex Application::AccessSecurity_CAT%3ABCB2250294
//## Subsystem: AS%36ED88CA0313
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3ABCB43800A3;monitor::UseCase { -> F}
//## Uses: <unnamed>%3ABCB4610016;IF::QueueFactory { -> F}
//## Uses: <unnamed>%3ABCB47D01B1;IF::Message { -> F}
//## Uses: <unnamed>%3E8B1D79038A;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3E8B43B402FD;database::Database { -> F}
//## Uses: <unnamed>%3E8B63AE02AF;IF::Session { -> F}
//## Uses: <unnamed>%3EA01842033C;command::UserPool { -> F}
//## Uses: <unnamed>%3EA02331002E;IF::Extract { -> F}
//## Uses: <unnamed>%3EA0235903C8;reusable::Transaction { -> F}
//## Uses: <unnamed>%3EA985B400FA;IF::Queue { -> F}
//## Uses: <unnamed>%40AA5AFB002E;platform::Platform { -> F}
//## Uses: <unnamed>%427F60510000;command::UserSession { -> F}
//## Uses: <unnamed>%51E460BF039D;command::DNSecurity { -> F}
//## Uses: <unnamed>%51E460DA02A3;segment::AuditEvent { -> F}

class AccessSecurity : public process::Application  //## Inherits: <unnamed>%3EAA5E33006D
{
  //## begin AccessSecurity%3ABCB25C0384.initialDeclarations preserve=yes
  //## end AccessSecurity%3ABCB25C0384.initialDeclarations

  public:
    //## Constructors (generated)
      AccessSecurity();

    //## Destructor (generated)
      virtual ~AccessSecurity();


    //## Other Operations (specified)
      //## Operation: initialize%3ABCB308016E
      virtual int initialize ();

      //## Operation: update%3EA0227C0138
      //	Interprets the inbound Message and calls:
      //
      //	   Application::onConfirm
      //	   Application::onMessage
      //	   Application::onNotify
      //	   Application::onQuiesce
      //	   Application::onRefresh
      //	   Application::onReset
      //	   Application::shutdown
      //	   Timer::elapsed
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin AccessSecurity%3ABCB25C0384.public preserve=yes
      //## end AccessSecurity%3ABCB25C0384.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%3ABCB30B0385
      virtual int onMessage (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin AccessSecurity%3ABCB25C0384.protected preserve=yes
      //## end AccessSecurity%3ABCB25C0384.protected

  private:
    // Additional Private Declarations
      //## begin AccessSecurity%3ABCB25C0384.private preserve=yes
      //## end AccessSecurity%3ABCB25C0384.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Application::AccessSecurity_CAT::<unnamed>%3E9AD4E70242
      //## Role: AccessSecurity::<m_pLogonCommand>%3E9AD4E8029F
      //## begin AccessSecurity::<m_pLogonCommand>%3E9AD4E8029F.role preserve=no  public: command::LogonCommand { -> RFHgN}
      command::LogonCommand *m_pLogonCommand;
      //## end AccessSecurity::<m_pLogonCommand>%3E9AD4E8029F.role

      //## Association: Connex Application::AccessSecurity_CAT::<unnamed>%3E9AD4EB01E4
      //## Role: AccessSecurity::<m_pLogoffCommand>%3E9AD4EC0177
      //## begin AccessSecurity::<m_pLogoffCommand>%3E9AD4EC0177.role preserve=no  public: command::LogoffCommand { -> RFHgN}
      command::LogoffCommand *m_pLogoffCommand;
      //## end AccessSecurity::<m_pLogoffCommand>%3E9AD4EC0177.role

      //## Association: Connex Application::AccessSecurity_CAT::<unnamed>%3EA018480186
      //## Role: AccessSecurity::<m_pDynamicSQLCommand>%3EA018490177
      //## begin AccessSecurity::<m_pDynamicSQLCommand>%3EA018490177.role preserve=no  public: command::DynamicSQLCommand { -> RFHgN}
      command::DynamicSQLCommand *m_pDynamicSQLCommand;
      //## end AccessSecurity::<m_pDynamicSQLCommand>%3EA018490177.role

      //## Association: Connex Application::AccessSecurity_CAT::<unnamed>%3EA0184F00CB
      //## Role: AccessSecurity::<m_pGetCustomizationCommand>%3EA01850000F
      //## begin AccessSecurity::<m_pGetCustomizationCommand>%3EA01850000F.role preserve=no  public: command::GetCustomizationCommand { -> RFHgN}
      command::GetCustomizationCommand *m_pGetCustomizationCommand;
      //## end AccessSecurity::<m_pGetCustomizationCommand>%3EA01850000F.role

      //## Association: Connex Application::AccessSecurity_CAT::<unnamed>%3EA018520109
      //## Role: AccessSecurity::<m_pGetCustomizationStatusCommand>%3EA018530128
      //## begin AccessSecurity::<m_pGetCustomizationStatusCommand>%3EA018530128.role preserve=no  public: command::GetCustomizationStatusCommand { -> RFHgN}
      command::GetCustomizationStatusCommand *m_pGetCustomizationStatusCommand;
      //## end AccessSecurity::<m_pGetCustomizationStatusCommand>%3EA018530128.role

      //## Association: Connex Application::AccessSecurity_CAT::<unnamed>%3EA01856002E
      //## Role: AccessSecurity::<m_pGetProfileCommand>%3EA018570148
      //## begin AccessSecurity::<m_pGetProfileCommand>%3EA018570148.role preserve=no  public: command::GetProfileCommand { -> RFHgN}
      command::GetProfileCommand *m_pGetProfileCommand;
      //## end AccessSecurity::<m_pGetProfileCommand>%3EA018570148.role

      //## Association: Connex Application::AccessSecurity_CAT::<unnamed>%3EA0185A0213
      //## Role: AccessSecurity::<m_pGetRelationshipCommand>%3EA0185B0167
      //## begin AccessSecurity::<m_pGetRelationshipCommand>%3EA0185B0167.role preserve=no  public: command::GetRelationshipCommand { -> RFHgN}
      command::GetRelationshipCommand *m_pGetRelationshipCommand;
      //## end AccessSecurity::<m_pGetRelationshipCommand>%3EA0185B0167.role

      //## Association: Connex Application::AccessSecurity_CAT::<unnamed>%3EA0185D01F4
      //## Role: AccessSecurity::<m_pGetUserIdListCommand>%3EA0185F0196
      //## begin AccessSecurity::<m_pGetUserIdListCommand>%3EA0185F0196.role preserve=no  public: command::GetUserIdListCommand { -> RFHgN}
      command::GetUserIdListCommand *m_pGetUserIdListCommand;
      //## end AccessSecurity::<m_pGetUserIdListCommand>%3EA0185F0196.role

      //## Association: Connex Application::AccessSecurity_CAT::<unnamed>%3EA01A150148
      //## Role: AccessSecurity::<m_pUpdateCustomizationCommand>%3EA01A170119
      //## begin AccessSecurity::<m_pUpdateCustomizationCommand>%3EA01A170119.role preserve=no  public: command::UpdateCustomizationCommand { -> RFHgN}
      command::UpdateCustomizationCommand *m_pUpdateCustomizationCommand;
      //## end AccessSecurity::<m_pUpdateCustomizationCommand>%3EA01A170119.role

      //## Association: Connex Application::AccessSecurity_CAT::<unnamed>%4668394F00EA
      //## Role: AccessSecurity::<m_pCommandWatch>%466839500148
      //## begin AccessSecurity::<m_pCommandWatch>%466839500148.role preserve=no  public: command::CommandWatch { -> RFHgN}
      command::CommandWatch *m_pCommandWatch;
      //## end AccessSecurity::<m_pCommandWatch>%466839500148.role

      //## Association: Connex Application::AccessSecurity_CAT::<unnamed>%490B63FD01CB
      //## Role: AccessSecurity::<m_pKeyXchgCommand>%490B63FE02A9
      //## begin AccessSecurity::<m_pKeyXchgCommand>%490B63FE02A9.role preserve=no  public: command::KeyXchgCommand { -> RFHgN}
      command::KeyXchgCommand *m_pKeyXchgCommand;
      //## end AccessSecurity::<m_pKeyXchgCommand>%490B63FE02A9.role

    // Additional Implementation Declarations
      //## begin AccessSecurity%3ABCB25C0384.implementation preserve=yes
      //## end AccessSecurity%3ABCB25C0384.implementation

};

//## begin AccessSecurity%3ABCB25C0384.postscript preserve=yes
//## end AccessSecurity%3ABCB25C0384.postscript

//## begin module%36ED89150176.epilog preserve=yes
//## end module%36ED89150176.epilog


#endif
