//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3D82386302FD.cm preserve=no
//	$Date:   Jun 24 2021 05:07:36  $ $Author:   e3027760  $ $Revision:   1.48.1.5  $
//## end module%3D82386302FD.cm

//## begin module%3D82386302FD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3D82386302FD.cp

//## Module: CXOPFM00%3D82386302FD; Package body
//## Subsystem: FM%3D8238430271
//## Source file: C:\bv03.2A.R005\ConnexPlatform\Server\Application\Fm\CXOPFM00.cpp

//## begin module%3D82386302FD.additionalIncludes preserve=no
//## end module%3D82386302FD.additionalIncludes

//## begin module%3D82386302FD.includes preserve=yes
#include <algorithm>
#ifdef _WIN32
#include "CXODPS04.hpp"
#else
#ifdef _UNIX
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <errno.h>
#endif
#include "CXODPS09.hpp"
#endif
#ifndef CXOSBS30_h
#include "CXODBS30.hpp"
#endif
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
//## end module%3D82386302FD.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF39_h
#include "CXODIF39.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
#ifndef CXOSDB44_h
#include "CXODDB44.hpp"
#endif
#ifndef CXOSDB52_h
#include "CXODDB52.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBC25_h
#include "CXODBC25.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOPFM00_h
#include "CXODFM00.hpp"
#endif


//## begin module%3D82386302FD.declarations preserve=no
//## end module%3D82386302FD.declarations

//## begin module%3D82386302FD.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new FaultManager();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%3D82386302FD.additionalDeclarations


// Class FaultManager 

FaultManager::FaultManager()
  //## begin FaultManager::FaultManager%3D8237E60261_const.hasinit preserve=no
      : m_bSetup(false)
  //## end FaultManager::FaultManager%3D8237E60261_const.hasinit
  //## begin FaultManager::FaultManager%3D8237E60261_const.initialization preserve=yes
  //## end FaultManager::FaultManager%3D8237E60261_const.initialization
{
  //## begin FaultManager::FaultManager%3D8237E60261_const.body preserve=yes
   memcpy(m_sID,"FM00",4);
  //## end FaultManager::FaultManager%3D8237E60261_const.body
}


FaultManager::~FaultManager()
{
  //## begin FaultManager::~FaultManager%3D8237E60261_dest.body preserve=yes
   MinuteTimer::instance()->detach(this);
   MidnightAlarm::instance()->detach(this);
  //## end FaultManager::~FaultManager%3D8237E60261_dest.body
}



//## Other Operations (implementation)
bool FaultManager::checkStatus (const string& strIMAGE_ID, const string& strTASKID, const string& strCONTEXT_DATA, const int iCount)
{
  //## begin FaultManager::checkStatus%60C85E640352.body preserve=yes
   int i = 0;
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery;
   hQuery.setQualifier("QUALIFY", "TASK_CONTEXT_COMN");
   hQuery.bind("TASK_CONTEXT_COMN", "*", Column::LONG, &i, 0, "COUNT");
   if(strTASKID.length() >0)
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "TASK_ID", "IN", strTASKID.c_str());
   hQuery.setBasicPredicate("TASK_CONTEXT_COMN","TASK_ID","<>","MMC");
   hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "CONTEXT_KEY", "=", "STATE");
   hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "IMAGE_ID", "=", strIMAGE_ID.c_str());
   hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "CONTEXT_DATA", "LIKE", strCONTEXT_DATA.c_str());
   return (pSelectStatement->execute(hQuery) && iCount == i);
  //## end FaultManager::checkStatus%60C85E640352.body
}

int FaultManager::initialize ()
{
  //## begin FaultManager::initialize%3D8238160119.body preserve=yes
   if (m_bSetup)
   {
      if (!Extract::instance()->setup())
         return -1;
      string strName;
      if (!Extract::instance()->getSpec("SERVICE",strName))
         return -1;
      strName += " FM";
      string strPath;
      strPath += getPath();
      strPath += "\\CXOPFM00.exe";
#ifdef _WIN32
      process::Service hTask(strName.c_str(),strPath.c_str(),false,"FM");
      hTask.start();
#else
      //process::Daemon hTask(strName.c_str(),strPath.c_str(),false);
      //hTask.start();
#endif
      return -1;
   }
   char sBuffer[_MAX_PATH] = {"_getcwd error"};
   //_getcwd(sBuffer,_MAX_PATH);
   //int d = _chdrive(3);
   //_chdir("\\Temp");
   //system("dir >>C:\\Temp\\dir.txt");
   new platform::Platform();
   new segment::AuditEvent;
   if (Application::initialize() != 0)
      return -1;
   if (!Extract::instance()->getSpec("SERVICE",m_strService))
      return -1;
   m_strService += ' ';
   bool bStart = false;
   int i = 0;
   string strRecord;
   string strName;
   string strPath;
   size_t pos = string::npos;
   while (Extract::instance()->getRecord(i++,strRecord))
   {
      strRecord.resize(38,' ');
      if (strRecord.substr(0,8) == "DQUEUE  "
         && strRecord.substr(32,4) != "MMC "
         && strRecord.substr(32,4) != "SMTP")
      {
         if (strRecord.substr(32,4) == "FM  ")
         {
            string strAddressSpace(strRecord.data() + 8,8);
            pos = strAddressSpace.find_first_of(' ');
            if (pos != string::npos)
               strAddressSpace.erase(pos);
            string strHost;
            bStart = (Extract::instance()->getHost(strAddressSpace,strHost)
               && (strHost == Extract::instance()->getHost()
               || strHost == Extract::instance()->getAlias()
               || strHost == SocketQueue::getAddress()
               || strHost == "LOCALHOST"));
         }
         else
         {
            if (bStart)
            {
               string strType(strRecord.data() + 32,4);
               rtrim(strType);
               bool bDefer = (strRecord[37] == 'D') ? true : false;
#ifdef _WIN32
               strName = m_strService;
               strName.append(strRecord.data() + 8,8);
               rtrim(strName);
               strPath = Application::getPath();
               strPath += "\\";
               strPath.append(strRecord.data() + 24,8);
               strPath += ".exe";
               Task* pTask = new process::Service(strName.c_str(),strPath.c_str(),bDefer,strType.c_str());
#else
               Trace::put(strRecord.c_str());
               strName = strRecord.substr(8,8);
               pos = strName.find_last_not_of(" ");
               if (pos != string::npos)
                  strName.erase(pos + 1);
               strPath = strRecord.substr(24,8);
               strPath += ".a";
               Trace::put(strName.c_str());
               Trace::put(strPath.c_str());
               Task* pTask = new process::Daemon(strName.c_str(),strPath.c_str(),bDefer,strType.c_str());
               signal(SIGCHLD, SIG_IGN); //prevent <defunct> zombie children
#endif
               if (strRecord[36] == 'T')
                  pTask->setTrace(true);
               m_hTask.insert(map<string, Task*, less<string> >::value_type(strName, pTask));
            }
         }
      }
   }
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->attach(this);
   Database::instance()->connect();
   setQueueWaitOption(false);
   MinuteTimer::instance()->attach(this);
   MidnightAlarm::instance()->attach(this);
   m_hQuery.attach(this);
   m_hQuery.setQualifier("QUALIFY","TASK_CONTEXT_COMN");
   m_hQuery.bind("TASK_CONTEXT_COMN","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA);
   m_hQuery.bind("TASK_CONTEXT_COMN","TASK_ID",Column::STRING,&m_strTASKID);
   m_hQuery.setBasicPredicate("TASK_CONTEXT_COMN","CONTEXT_KEY","=","STATE");
   m_hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "IMAGE_ID", "=", Application::instance()->image().c_str());
   m_hQuery.setBasicPredicate("TASK_CONTEXT_COMN","TASK_ID","<>","MMC");
   m_hQuery.setOrderByClause("TASK_ID");
   Trace::setEnable(true);
   m_hIMAGE_ID.push_back(string(Application::instance()->image().data(), 3));
   return 0;
  //## end FaultManager::initialize%3D8238160119.body
}

void FaultManager::monitor ()
{
  //## begin FaultManager::monitor%59DE0DED01F5.body preserve=yes
   m_hQuery.setIndex(0);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   pSelectStatement->execute(m_hQuery);
   Database::instance()->commit();
   if (getState() == Application::TASK_IN_SHUTDOWN || getState() == Application::TASK_IN_QUIESCE)
      return;
   CommonContext hContext(Application::instance()->image(), Application::instance()->name());
   string strCONTEXT_DATA;
   hContext.get(IF::Extract::instance()->getHost().c_str(), strCONTEXT_DATA,'T');
   if (!strCONTEXT_DATA.empty())
   {
      int iCount = 0;
      string strTASKID;
      map<string, process::Task*>::iterator p;
      for (p = m_hTask.begin(); p != m_hTask.end(); ++p)
      {
         if ((*p).second->getIMAGE_ID() == Application::instance()->image().substr(0, 3) && (*p).second->getDefer() == false)
         {
            iCount++;
            if (strTASKID.empty())
               strTASKID = "('" + (*p).second->getName() + "')";
            else
            {
               strTASKID.insert(1, "',");
               strTASKID.insert(1, (*p).second->getName());
               strTASKID.insert(1, "'");
            }
         }
      }
      if (!checkStatus(strCONTEXT_DATA, strTASKID, "Started%", 0) ||
         !checkStatus(strCONTEXT_DATA, strTASKID, "Quiesced%", 0))
         return;
      startupTasks();
      if (checkStatus(Application::instance()->image(), strTASKID, "Started%", iCount))
      {
         hContext.put(IF::Extract::instance()->getHost().c_str(), "", 'T');
         Database::instance()->commit();
      }
   }
   FILE* stream;
   const int max_buffer = 256;
   char buffer[max_buffer];
#ifdef _WIN32
   stream = _popen("tasklist /FI \"IMAGENAME eq CXOP*\" /NH /SVC 2>&1", "r");  //_popen for Windows
#else
   stream = popen("ps -eo pid,args | grep CXOP 2>&1", "r");  //popen for linux
#endif
   if (stream)
   {
      while (!feof(stream))
      {
         if (fgets(buffer, max_buffer, stream) != NULL)
         {
            string strTaskID;
            vector<string> hTokens;
            Buffer::parse(buffer, " \n", hTokens);
#ifdef _WIN32
            if (hTokens.size() > 3 && hTokens[0].length() > 4 && memcmp(hTokens[0].data(),"CXOP",4) == 0 )
            {
               strTaskID = hTokens[2];
               for (int i = 3;i < hTokens.size();++i)
               {
                  strTaskID.append(" ",1);
                  strTaskID += hTokens[i];
               }
            }
#else
            if (hTokens.size() >= 8 && hTokens[1].length() > 4 && memcmp(hTokens[1].data(), "CXOP", 4) == 0)
            {
               strTaskID = hTokens[3];
            }
#endif
            else
               continue;
            map<string, process::Task*>::iterator p = m_hTask.find(strTaskID);
            if (p != m_hTask.end())
            {
#ifdef _WIN32
               if ((*p).second->getState() == Task::STARTED && (*p).second->getProcessID() == hTokens[1])
#else
               if ((*p).second->getState() == Task::STARTED && (*p).second->getProcessID() == hTokens[0])
#endif
                  (*p).second->setState(Task::STARTED_CONFIRMED);
            }
         }
      }
#ifdef _WIN32
      _pclose(stream);
#else
      pclose(stream);
#endif
   }
   //find all tasks in STARTED state that have not been confirmed
   //reset STARTED_CONFIRMED back to STARTED
   map<string, process::Task*>::iterator p;
   string strEmailTaskList;
   for (p = m_hTask.begin(); p != m_hTask.end(); ++p)
   {
      if ((*p).second->getState() == Task::STARTED_CONFIRMED)
      {
         (*p).second->setState(Task::STARTED);
         continue;
      }
      if ((*p).second->getState() == Task::STARTED)
      {
#ifdef _WIN32
         string strTaskID = ((*p).second->getName()).substr(m_strService.length(), ((*p).second->getName().length()) - m_strService.length());
#else
         string strTaskID = (*p).second->getName();
#endif
         int iSecondsSinceLastRestart = 0;
         if ((*p).second->getRestartTimestamp() != "" && (*p).second->getRestartTimestamp().length() >= 14)
         {
            Clock hClock((*p).second->getRestartTimestamp());
            iSecondsSinceLastRestart = *Clock::instance() - hClock;
         }
         if ((*p).second->getRestartCount() == 0 || iSecondsSinceLastRestart > 1800) //1800 seconds = 30 minutes
         {
            Console::display("ST138", strTaskID.c_str()); // ST138 - TASK @@@@@@@@ HAS TERMINATED, WILL BE RE-STARTED
            (*p).second->incrementRestartCount();
            (*p).second->setRestartTimestamp(Clock::instance()->getYYYYMMDDHHMMSS());
            (*p).second->start();
         }
         else
         {
            Console::display("ST139", strTaskID.c_str()); // ST139 - TASK @@@@@@@@ HAS TERMINATED, WILL NOT BE RE-STARTED
            (*p).second->setState(Task::SHUTDOWN);
            (*p).second->setRestartCount(0);
            (*p).second->setRestartTimestamp("");
            CommonContext hContext(Application::instance()->image(), strTaskID);
            hContext.put("STATE", "Stopped", ' ');
            Database::instance()->commit();
            strEmailTaskList.append("," + strTaskID);
         }
      }
   }
   if (!strEmailTaskList.empty())
   {
      string strTIME_STAMP = Clock::instance()->getYYYYMMDDHHMMSS(false);
      command::Email hEmail("CXOEFM01");
      string strCustomerID;
      Extract::instance()->getSpec("CUSTOMER", strCustomerID);
      Query hQuery;
      segment::ContactSegment::instance(segment::ContactSegment::SENDER)->bind(hQuery);
      hQuery.setQualifier("QUALIFY", "CONTACT_TYPE");
      hQuery.setBasicPredicate("CONTACT_TYPE", "CONTACT_TYPE", "=", "ASG");
      hQuery.setBasicPredicate("CONTACT_TYPE", "CONTACT_METHOD", "=", "E");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (pSelectStatement->execute(hQuery) == false || pSelectStatement->getRows() == 0)
         return;
      hEmail.add('C', segment::ContactSegment::instance(segment::ContactSegment::SENDER));
      usersegment::EmailSegment::instance()->reset();
      usersegment::EmailSegment::instance()->setField("TASK_LIST", strEmailTaskList);
      usersegment::EmailSegment::instance()->setField("TIME_STAMP", strTIME_STAMP);
      usersegment::EmailSegment::instance()->setField("CUSTOMER", strCustomerID);
      hEmail.add('Z', usersegment::EmailSegment::instance());
      hEmail.report('C');
      hEmail.report('H');
      hEmail.getFlatFile().close();
   }
  //## end FaultManager::monitor%59DE0DED01F5.body
}

int FaultManager::onMessage (Message& hMessage)
{
  //## begin FaultManager::onMessage%3F1D8C7401B5.body preserve=yes
   if ((hMessage.type() == START
      || hMessage.type() == STARTWTR)
      && hMessage.context().length() > 0)
   {
      string strName;
#ifdef _WIN32
      strName = m_strService;
#endif
      string strTask((char*)hMessage.context(),hMessage.context().length());
      size_t pos = strTask.find_last_not_of(" ");
      if (pos != string::npos)
         strTask.erase(pos + 1);
      strName += strTask;
      Trace::put(strName.data(),strName.length());
      map<string, process::Task*>::iterator p = m_hTask.find(strName);
      if (p != m_hTask.end())
      {
         if ((*p).second->getName() == strName)
         {
            if (hMessage.type() == STARTWTR)
               Application::setState("Start with trace",strTask.c_str());
            (*p).second->setRestartCount(0);
            (*p).second->start();
         }
      }
   }
   return 0;
  //## end FaultManager::onMessage%3F1D8C7401B5.body
}

int FaultManager::onQuiesce ()
{
  //## begin FaultManager::onQuiesce%3E4E7A1A01D4.body preserve=yes
   if (m_hTask.empty())
      Application::shutdown();
   else
   {
      m_pRevIter = m_hTask.rbegin();
      setQueueWaitOption(false);
   }
   return 0;
  //## end FaultManager::onQuiesce%3E4E7A1A01D4.body
}

int FaultManager::onReset (Message& hMessage)
{
  //## begin FaultManager::onReset%60C869CB0166.body preserve=yes
   string strIMAGE_ID;
   if (hMessage.context().length() >= 12)
      strIMAGE_ID.assign(hMessage.context().subString(9));
   trim(strIMAGE_ID);
   if (strIMAGE_ID.length() >= 3)
   {
      bool bImage1 = (Application::instance()->image().substr(0, 3) == "I01" && strIMAGE_ID == "I01");
      if (memcmp(strIMAGE_ID.data(), Application::instance()->image().data(), 3) == 0 && !bImage1)
         return 0;
      vector<string>::iterator pIMAGE_ID = find(m_hIMAGE_ID.begin(), m_hIMAGE_ID.end(), strIMAGE_ID);
      char szTemp[PERCENTF];
      if (memcmp((char*)hMessage.context(), "TAKEOVER", 8) == 0)
      {
         if (!bImage1)
         {
         if (pIMAGE_ID != m_hIMAGE_ID.end())
         {
            Trace::put(szTemp, 
               snprintf(szTemp, sizeof(szTemp), "Image %s already taken over.", strIMAGE_ID.c_str()), true);
            return 0;
         }
         m_hIMAGE_ID.push_back(strIMAGE_ID.substr(0,3));
         takeOver();
      }
         else
            startupTasks();
      }
      else if (memcmp((char*)hMessage.context(), "TAKEBACK", 8) == 0 &&
         m_hIMAGE_ID.size() >= 1)
      {
         if (pIMAGE_ID == m_hIMAGE_ID.end())
         {
            Trace::put(szTemp, 
               snprintf(szTemp, sizeof(szTemp), "Image %s not running on this Server", strIMAGE_ID.c_str()), true);
            return 0;
         }
         if(memcmp(m_hIMAGE_ID.back().data(), strIMAGE_ID.data(),3) !=0)
            rotate(pIMAGE_ID, pIMAGE_ID + 1, m_hIMAGE_ID.end());
         Query hQuery(m_hQuery);
         takeBack();
         m_hQuery = hQuery;
         m_hIMAGE_ID.pop_back();
      }
   }
   return 0;
  //## end FaultManager::onReset%60C869CB0166.body
}

int FaultManager::onResume (Message& hMessage)
{
  //## begin FaultManager::onResume%3D82381900DA.body preserve=yes
   if (getState() == Application::TASK_IN_QUIESCE)
   {
      while (m_hIMAGE_ID.size() > 1)
         m_hIMAGE_ID.pop_back();
      monitor();
      quiesceTasks();
   }
   else
   if (getState() == Application::TASK_IN_SHUTDOWN)
   {
      monitor();
      shutdownTasks();
   }
   else
   {
      map<string, process::Task*>::iterator p;
      for (p = m_hTask.begin();p != m_hTask.end();++p)
      {
#ifdef _WIN32
        string strTaskID = ((*p).second->getName()).substr(m_strService.length(),((*p).second->getName().length()) - m_strService.length());
#else
        string strTaskID = (*p).second->getName();
#endif
        auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
        Query hQuery;
        hQuery.setQualifier("QUALIFY","TASK_CONTEXT_COMN");
        hQuery.setBasicPredicate("TASK_CONTEXT_COMN","CONTEXT_KEY","=","STATE");
        hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "IMAGE_ID", "=", Application::instance()->image().c_str());
        hQuery.setBasicPredicate("TASK_CONTEXT_COMN","TASK_ID","=",strTaskID.c_str());
        pDeleteStatement->execute(hQuery);
      }
      Database::instance()->commit();
      startupTasks();
      for (p = m_hTask.begin();p != m_hTask.end();++p)
         start(p);
      Database::instance()->commit();
      setQueueWaitOption(true);
      Console::display("ST145",Extract::instance()->getHost().c_str());
      // ST145 - "STARTUP COMPLETED FOR SERVER @@@@@@@@@@@"
   }
   return 0;
  //## end FaultManager::onResume%3D82381900DA.body
}

void FaultManager::parseCommandLine (int iArgc, char** ppArgv)
{
  //## begin FaultManager::parseCommandLine%3DC92B7802BF.body preserve=yes
   setName("FM");
#ifdef _UNIX
   for (int i = 1;i < iArgc;++i)
      if (!strcmp(ppArgv[i],"-i"))
         m_bSetup = true;
   return Application::parseCommandLine(iArgc,ppArgv);
#else
   int j = 0;
   for (int i = 1;i < iArgc;++i)
   {
      switch (j)
      {
         case 0:
            if (!strcmp(ppArgv[i],"-p"))
               j = 1;
            else
            if (!strcmp(ppArgv[i],"-t"))
               Trace::setEnable(true);
            break;
         case 1:
            m_bSetup = true;
            // If users invokes program with "x:\folder\", the final \" comes
            // through as " which needs to be removed.
            char* q = strchr(ppArgv[i],'"');
            if (q)
               *q = '\0';
            Extract::instance()->setNode001(ppArgv[i]);
            j = 0;
            break;
      }
   }
#endif
  //## end FaultManager::parseCommandLine%3DC92B7802BF.body
}

int FaultManager::quiesceTasks ()
{
  //## begin FaultManager::quiesceTasks%59A96AA302E5.body preserve=yes
   FlatFile hScript("SOURCE","QUIESCE");
   if (!hScript.open() )
      return -1;
   char* psBuffer = new char[4096];
   size_t m = 0;
   string strTASKID;
   int iCount = 0;
   while (hScript.read(psBuffer,4094,&m))
   {
      if (memcmp(psBuffer,"QUIESCE",7) == 0)
      {
         string strBuffer(psBuffer,m);
         vector<string> hTokens;
         Buffer::parse(strBuffer," =",hTokens);
         if (hTokens.size() > 1)
         {
#ifdef _WIN32
            string strName(m_strService + hTokens[1]);
#else
            string strName(hTokens[1]);
#endif
            string strType;
            if (hTokens.size() >= 3
               && hTokens[1] == "TYPE")
               strType = hTokens[2];
            map<string, process::Task*>::iterator p;
            for (p = m_hTask.begin();p != m_hTask.end();++p)
            {
               if (((*p).second->getName() == strName
                  || (*p).second->getType() == strType)
                  && (*p).second->getState() == Task::STARTED 
                  && (memcmp(m_hIMAGE_ID.back().data(), Application::instance()->image().data(), 3) == 0
                  || (*p).second->getIMAGE_ID() == m_hIMAGE_ID.back()))
               {
                  (*p).second->quiesce();
                  {
                     ++iCount;
                     string strBuffer((*p).second->getName());
                     vector<string> hTokens;
                     Buffer::parse(strBuffer," ",hTokens);
                     if (strTASKID.empty())
                        strTASKID = "('" + hTokens[hTokens.size() - 1] + "')";
                     else
                     {
                        strTASKID.insert(1,"',");
                        strTASKID.insert(1,hTokens[hTokens.size() - 1]);
                        strTASKID.insert(1,"'");
                     }
                  }
               }
            }
         }
      }
      else
      if (memcmp(psBuffer,"WAIT",4) == 0)
      {
         wait(strTASKID,"Quiesced%",iCount);
         strTASKID.erase();
         iCount = 0;
      }
   }
   if (iCount > 0)
      wait(strTASKID,"Quiesced%",iCount);
   delete [] psBuffer;
   m_pRevIter = m_hTask.rbegin();
   do
   {
      if ((*m_pRevIter).second->getState() == Task::STARTED
         && (memcmp(m_hIMAGE_ID.back().data(), Application::instance()->image().data(), 3) == 0
            || (*m_pRevIter).second->getIMAGE_ID() == m_hIMAGE_ID.back()))
         (*m_pRevIter).second->quiesce();
      ++m_pRevIter;
   }while (m_pRevIter != m_hTask.rend());
   Sleep::goTo("00001000");
   if (memcmp(m_hIMAGE_ID.back().data(), Application::instance()->image().data(), 3) == 0)
      m_nState = Application::TASK_IN_SHUTDOWN;
   return 0;
  //## end FaultManager::quiesceTasks%59A96AA302E5.body
}

void FaultManager::setState (const char*  pszCONTEXT_DATA, const char*  pszTaskID)
{
  //## begin FaultManager::setState%466818B50290.body preserve=yes
   bool bDatabaseIdle = (Database::instance()->transactionState() == Database::IDLE) ? true : false;
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   Table hTable("TASK_CONTEXT_COMN");
   hTable.setQualifier("QUALIFY");
   hTable.set("IMAGE_ID",Application::instance()->image(),false,true);
   hTable.set("TASK_ID",Application::instance()->name(),false,true);
   hTable.set("CONTEXT_TYPE","S",false,true);
   hTable.set("CONTEXT_KEY",IF::Extract::instance()->getHost(),false,true);
   string strCONTEXT_DATA(pszCONTEXT_DATA);
   size_t pos = strCONTEXT_DATA.find_first_of(",");
   if (pos != string::npos)
      strCONTEXT_DATA = strCONTEXT_DATA.substr(0,pos);
   hTable.set("CONTEXT_DATA",strCONTEXT_DATA.c_str());
   if (pUpdateStatement->execute(hTable) == false)
   {
     if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
     {
        auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
        if (pInsertStatement->execute(hTable) == false)
        {
          Console::display("ST202");
          // ST202 - "CANNOT INITIALIZE CHECKPOINT DATA"
          Database::instance()->rollback();
        }
        else
        if (bDatabaseIdle)
           Database::instance()->commit();
     }
     else
     {
       Console::display("ST202");
       // ST202 - "CANNOT INITIALIZE CHECKPOINT DATA"
       Database::instance()->rollback();
     }
   }
   else
   if (bDatabaseIdle)
      Database::instance()->commit();
  //## end FaultManager::setState%466818B50290.body
}

int FaultManager::shutdown ()
{
  //## begin FaultManager::shutdown%59BA7308011F.body preserve=yes
   m_nState = Application::TASK_IN_QUIESCE;
   setQueueWaitOption(false);
   return 0;
  //## end FaultManager::shutdown%59BA7308011F.body
}

int FaultManager::shutdownTasks ()
{
  //## begin FaultManager::shutdownTasks%43EF689B0251.body preserve=yes
   FlatFile hScript("SOURCE","SHUTDOWN");
   if (!hScript.open())
      return -1;
   char* psBuffer = new char[4096];
   size_t m = 0;
   string strTASKID;
   int iCount = 0;
   while (hScript.read(psBuffer,4094,&m))
   {
      if (memcmp(psBuffer,"SHUTDOWN",7) == 0)
      {
         string strBuffer(psBuffer,m);
         vector<string> hTokens;
         Buffer::parse(strBuffer," =",hTokens);
         if (hTokens.size() > 1)
         {
#ifdef _WIN32
            string strName(m_strService + hTokens[1]);
#else
            string strName(hTokens[1]);
#endif
            string strType;
            switch (hTokens.size())
            {
            case 5:
            case 3:
               if (hTokens[1] == "TYPE")
                  strType = hTokens[2];
               break;
            }
            map<string, process::Task*>::iterator p;
            for (p = m_hTask.begin();p != m_hTask.end();++p)
            {
               if (((*p).second->getName() == strName
                  || (*p).second->getType() == strType)
                  && (*p).second->getState() == Task::QUIESCED) 
               {
                  if ((*p).second->stop())
                  {
                     ++iCount;
                     string strBuffer((*p).second->getName());
                     vector<string> hTokens;
                     Buffer::parse(strBuffer," ",hTokens);
                     if (strTASKID.empty())
                        strTASKID = "('" + hTokens[hTokens.size() - 1] + "')";
                     else
                     {
                        strTASKID.insert(1,"',");
                        strTASKID.insert(1,hTokens[hTokens.size() - 1]);
                        strTASKID.insert(1,"'");
                     }
                  }
               }
            }
         }
      }
      else
      if (memcmp(psBuffer,"WAIT",4) == 0)
      {
         wait(strTASKID,"Stopped%",iCount);
         strTASKID.erase();
         iCount = 0;
      }
   }
   if (iCount > 0)
      wait(strTASKID,"Stopped%",iCount);
   delete [] psBuffer;
   m_pRevIter = m_hTask.rbegin();
   do
   {
      if ((*m_pRevIter).second->getState() == Task::QUIESCED)
         (*m_pRevIter).second->stop();
      ++m_pRevIter;
   } while (m_pRevIter != m_hTask.rend());
   if (memcmp(m_hIMAGE_ID.back().data(), Application::instance()->image().data(), 3) == 0)
   {
#ifdef _WIN32
      Service::setStatus(SERVICE_STOP_PENDING); // repeat that FM is stopping
#endif
      Application::shutdown();
   }
   return 1;
  //## end FaultManager::shutdownTasks%43EF689B0251.body
}

bool FaultManager::start (map<string, process::Task *, less<string> >::iterator p)
{
  //## begin FaultManager::start%5995B6EF02D3.body preserve=yes
   if ((*p).second->getState() == Task::STARTED)
      return true;
   
   if (!(*p).second->getDefer()  
      && ((*p).second->getIMAGE_ID().empty()
         || (*p).second->getIMAGE_ID() == m_hIMAGE_ID.back()))
   {
      database::AuditEvent::capture("", 104, 0, "START", (*p).second->getName());
      if (!(*p).second->start())
      { //did start fail because it is already started?
         verifyStatus(p);
      }
   }
   else
   {
#ifdef _WIN32
      string strTaskID = ((*p).second->getName()).substr(m_strService.length(), ((*p).second->getName().length()) - m_strService.length());
#else
      string strTaskID = (*p).second->getName();
#endif
      auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      Table hTable("TASK_CONTEXT_COMN");
      hTable.setQualifier("QUALIFY");
      hTable.set("IMAGE_ID",image(),false,true);
      hTable.set("TASK_ID",strTaskID,false,true);
      hTable.set("CONTEXT_TYPE"," ",false,true);
      hTable.set("CONTEXT_KEY","STATE",false,true);
      hTable.set("CONTEXT_DATA","Deferred");
      pInsertStatement->execute(hTable);
      Database::instance()->commit();
      return false;
   }
   return true;
  //## end FaultManager::start%5995B6EF02D3.body
}

int FaultManager::startupTasks ()
{
  //## begin FaultManager::startupTasks%59A967F90385.body preserve=yes
   FlatFile hScript("SOURCE","STARTUP");
   if (!hScript.open())
      return -1;
   char* psBuffer = new char[4096];
   size_t m = 0;
   string strTASKID;
   int iCount = 0;
   while (hScript.read(psBuffer,4094,&m))
   {
      if (memcmp(psBuffer,"ATTACH",6) == 0)
      {
         string strBuffer(psBuffer,m);
         vector<string> hTokens;
         Buffer::parse(strBuffer," =",hTokens);
         if (hTokens.size() > 1)
         {
#ifdef _WIN32
            string strName(m_strService + hTokens[1]);
#else
            string strName(hTokens[1]);
#endif
            string strType;
            string strIMAGE_ID;
            switch (hTokens.size())
            {
            case 5:
               if (hTokens[3] == "IMAGE")
                  strIMAGE_ID.assign(hTokens[4]);
            case 3:
               if(hTokens[1] == "TYPE")
                  strType = hTokens[2];
               break;
            case 4:
               if (hTokens[2] == "IMAGE")
                  strIMAGE_ID.assign(hTokens[3]);
               break;
            }
            map<string, process::Task*>::iterator p;
            for (p = m_hTask.begin();p != m_hTask.end();++p)
            {
               if ((*p).second->getName() == strName
                  || (*p).second->getType() == strType)
               {
                  (*p).second->setIMAGE_ID(strIMAGE_ID);
                  if (start(p))
                  {
                     ++iCount;
                     string strBuffer((*p).second->getName());
                     vector<string> hTokens;
                     Buffer::parse(strBuffer," ",hTokens);
                     if (strTASKID.empty())
                        strTASKID = "('" + hTokens[hTokens.size() - 1] + "')";
                     else
                     {
                        strTASKID.insert(1,"',");
                        strTASKID.insert(1,hTokens[hTokens.size() - 1]);
                        strTASKID.insert(1,"'");
                     }
                  }
               }
            }
         }
      }
      else
      if (memcmp(psBuffer,"WAIT",4) == 0)
      {
         wait(strTASKID,"Started%",iCount);
         strTASKID.erase();
         iCount = 0;
      }
   }
   delete [] psBuffer;
   return 1;
  //## end FaultManager::startupTasks%59A967F90385.body
}

void FaultManager::takeBack ()
{
  //## begin FaultManager::takeBack%60C85E9501DE.body preserve=yes
   monitor();
   quiesceTasks();
   shutdownTasks();
   string strTASKID;
   string strIMAGEID(m_hIMAGE_ID.back());
   strIMAGEID.append("/");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery.reset();
   m_hQuery.setIndex(1);
   m_hQuery.setQualifier("QUALIFY", "TASK_CONTEXT_COMN");
   m_hQuery.bind("TASK_CONTEXT_COMN", "CONTEXT_KEY", Column::STRING, &m_strCONTEXT_KEY);
   m_hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "TASK_ID", "=", Application::instance()->name().c_str());
   m_hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "IMAGE_ID", "=", strIMAGEID.c_str());
   m_hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "CONTEXT_KEY", "<>", IF::Extract::instance()->getHost().c_str());
   m_hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "CONTEXT_DATA", "=", "Started");
   m_hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "CONTEXT_TYPE", "=", "S");
   if (!pSelectStatement->execute(m_hQuery))
      return;
   Database::instance()->commit();
  //## end FaultManager::takeBack%60C85E9501DE.body
}
void FaultManager::takeOver ()
{
  //## begin FaultManager::takeOver%60C85E2D0115.body preserve=yes
   string strTASKID;
   string strIMAGE_ID(m_hIMAGE_ID.back().data(), 3);
   strIMAGE_ID.append("/");
   if (!checkStatus(strIMAGE_ID, strTASKID, "Started%", 0) ||
      !checkStatus(strIMAGE_ID, strTASKID, "Quiesced%", 0))
   {
      Trace::put("Tasks are still running on the other Image:", strIMAGE_ID.c_str(), true);
      m_hIMAGE_ID.pop_back();
      return;
   }
   startupTasks();
  //## end FaultManager::takeOver%60C85E2D0115.body
}

void FaultManager::update (Subject* pSubject)
{
  //## begin FaultManager::update%3F1D7A360232.body preserve=yes
   if (pSubject == Message::instance(Message::INBOUND)
      && Message::instance(Message::INBOUND)->type() == SHUTDOWN)
   {
      Application::stop();
      return;
   }
   if (pSubject == &m_hQuery)
   {
      if (m_hQuery.getIndex() != 1)
      {
#ifdef _WIN32
      string strName(m_strService + m_strTASKID);
#else
      string strName(m_strTASKID);
#endif
      map<string, process::Task*>::iterator p = m_hTask.find(strName);
      if (p != m_hTask.end())
         (*p).second->setState(m_strCONTEXT_DATA);
      }
      else
      {
         string strIMAGE_ID(m_hIMAGE_ID.back());
         strIMAGE_ID.append("/");
         CommonContext hContext(strIMAGE_ID, Application::instance()->name());
         hContext.put(m_strCONTEXT_KEY.c_str(), Application::instance()->image().c_str(), 'T');
      }
      return;
   }
   if (pSubject == MinuteTimer::instance()
      && getState() != Application::TASK_IN_QUIESCE
      && getState() != Application::TASK_IN_SHUTDOWN)
      monitor();
   if (pSubject == MidnightAlarm::instance())
   {
      // purge files from one week ago
      Date hDate(MidnightAlarm::instance()->getYesterday().c_str());
      hDate -= 7;
      string strDate(hDate.asString("%Y%m%d"));
      string strPurgeDate;
      strPurgeDate = strDate.substr(0, 4);
      strPurgeDate += "-";
      strPurgeDate += strDate.substr(4, 2);
      strPurgeDate += "-";
      strPurgeDate += strDate.substr(6, 2);
      FlatFile::purge("Logs\\Closed", strPurgeDate);
      FlatFile::purge("Trace", strPurgeDate);
      // purge console messages
      string strDATE_TIME(hDate.asString("%Y%m%d00000000"));
      Query hQuery;
      hQuery.setQualifier("QUALIFY", "CONSOLE_MSG");
      hQuery.setBasicPredicate("CONSOLE_MSG", "DATE_TIME", "<", strDATE_TIME.c_str());
      auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
      pDeleteStatement->execute(hQuery);
      Database::instance()->commit();
      // purge files from prior month
      hDate -= 31;
      strDate = hDate.asString("%Y%m%d");
      strPurgeDate = strDate.substr(0, 4);
      strPurgeDate += "-";
      strPurgeDate += strDate.substr(4, 2);
      FlatFile::purge("Logs\\Closed", strPurgeDate);
      for (int i = 1; i < 32; ++i)
      {
         char szDay[4];
         snprintf(szDay, sizeof(szDay), "-%02d", i);
         FlatFile::purge("Trace", string(strPurgeDate + szDay));
      }
   }
   Application::update(pSubject);
  //## end FaultManager::update%3F1D7A360232.body
}

bool FaultManager::verifyStatus (map<string, process::Task *, less<string> >::iterator p)
{
  //## begin FaultManager::verifyStatus%5AA944BE0040.body preserve=yes
   FILE* stream;
   const int max_buffer = 256;
   char buffer[max_buffer];
   bool bFound = false;
#ifdef _WIN32
   stream = _popen("tasklist /FI \"IMAGENAME eq CXOP*\" /NH /SVC 2>&1", "r");  //_popen for Windows
#else
   stream = popen("ps -eo pid,args | grep CXOP 2>&1", "r");  //popen for linux
#endif
   if (stream)
   {
      while (!feof(stream))
      {
         if (fgets(buffer, max_buffer, stream) != NULL)
         {
            string strTaskID;
            string strName;
            vector<string> hTokens;
            Buffer::parse(buffer, " \n", hTokens);
#ifdef _WIN32
            if (hTokens.size() > 3 && hTokens[0].length() > 4 && memcmp(hTokens[0].data(), "CXOP", 4) == 0)
            {
               strTaskID = hTokens[3];
               strName = m_strService + hTokens[3];
            }
#else
            if (hTokens.size() >= 8 && hTokens[1].length() > 4 && memcmp(hTokens[1].data(), "CXOP", 4) == 0)
            {
               strTaskID = hTokens[3];
               strName = strTaskID;
            }
#endif
            else
               continue;
            if ((*p).first == strName)
            {
               bFound = true;
               string strCONTEXT_DATA("Started,");
               if ((*p).second->getTrace())
                  strCONTEXT_DATA.append("On,");
               else
                  strCONTEXT_DATA.append("Off,");
#ifdef _WIN32
               strCONTEXT_DATA.append(hTokens[1]);
#else
               strCONTEXT_DATA.append(hTokens[0]);
#endif
               CommonContext hContext(Application::instance()->image(), strTaskID);
               hContext.put("STATE", strCONTEXT_DATA.c_str(), ' ');
               Database::instance()->commit();
               (*p).second->setState(Task::STARTED);
               break;
            }
         }
      }
#ifdef _WIN32
      _pclose(stream);
#else
      pclose(stream);
#endif
      if (!bFound)
      {
         CommonContext hContext(Application::instance()->image(), (*p).first);
         hContext.put("STATE", "Stopped", ' ');
         Database::instance()->commit();
         (*p).second->setState(Task::SHUTDOWN);
      }
   }
   return true;
  //## end FaultManager::verifyStatus%5AA944BE0040.body
}

bool FaultManager::wait (const string& strTASKID, const char* pszCONTEXT_DATA, int iCount)
{
  //## begin FaultManager::wait%5995F6E50338.body preserve=yes
   int i = 0;
   int j = 0;
   while (i < iCount && ++j <= 60)
   {
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      Query hQuery;
      hQuery.setQualifier("QUALIFY", "TASK_CONTEXT_COMN");
      hQuery.bind("TASK_CONTEXT_COMN", "*", Column::LONG, &i, 0, "COUNT");
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "TASK_ID", "IN", strTASKID.c_str());
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN","CONTEXT_KEY","=","STATE");
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "IMAGE_ID", "=", Application::instance()->image().c_str());
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN","CONTEXT_DATA","LIKE",pszCONTEXT_DATA);
      if (!pSelectStatement->execute(hQuery))
         return false;
      Database::instance()->commit();
      Sleep::goTo("00000100");
   }
   return true;
  //## end FaultManager::wait%5995F6E50338.body
}

// Additional Declarations
  //## begin FaultManager%3D8237E60261.declarations preserve=yes
  //## end FaultManager%3D8237E60261.declarations

//## begin module%3D82386302FD.epilog preserve=yes
//## end module%3D82386302FD.epilog
