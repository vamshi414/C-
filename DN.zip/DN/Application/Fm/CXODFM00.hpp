//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3D82386200EA.cm preserve=no
//	$Date:   Aug 25 2021 21:29:16  $ $Author:   e1014059  $ $Revision:   1.19  $
//## end module%3D82386200EA.cm

//## begin module%3D82386200EA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3D82386200EA.cp

//## Module: CXOPFM00%3D82386200EA; Package specification
//## Subsystem: FM%3D8238430271
//## Source file: C:\bv03.2A.R008\ConnexPlatform\Server\Application\Fm\CXODFM00.hpp

#ifndef CXOPFM00_h
#define CXOPFM00_h 1

//## begin module%3D82386200EA.additionalIncludes preserve=no
//## end module%3D82386200EA.additionalIncludes

//## begin module%3D82386200EA.includes preserve=yes
//## end module%3D82386200EA.includes

#ifndef CXOSPS08_h
#include "CXODPS08.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Message;
class DateTime;
class FlatFile;
} // namespace IF

namespace reusable {
class Buffer;
} // namespace reusable

namespace IF {
class SocketQueue;
class Extract;
class Sleep;
class Console;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
class CommonContext;
class AuditEvent;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class AuditEvent;
class GenericSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Email;
} // namespace command

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;

} // namespace platform

//## begin module%3D82386200EA.declarations preserve=no
//## end module%3D82386200EA.declarations

//## begin module%3D82386200EA.additionalDeclarations preserve=yes
//## end module%3D82386200EA.additionalDeclarations


//## begin FaultManager%3D8237E60261.preface preserve=yes
//## end FaultManager%3D8237E60261.preface

//## Class: FaultManager%3D8237E60261; protected
//	<body>
//	<title>CG
//	<h1>FM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Fault Manager service (FM) starts, monitors and
//	stops services running on a DataNavigator Application
//	Server.
//	</p>
//	<img src=CXOCFM00.gif>
//	</body>
//
//	<body>
//	<title>OG
//	<h1>FM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	One instance of the Fault Manager service executes on
//	each Unix or Microsoft Windows server in your
//	configuration.
//	The Fault Manager service (FM) starts and stops services
//	running on the server.
//	</p>
//	<img src=CXOOFM00.gif>
//	</p>
//	<h2>CD
//	<h3>System startup on Unix
//	<p>
//	To start the DataNavigator server:
//	<ul>
//	<li>Run a command line shell
//	<br>cd <i>node001</i>/Alpha/Bin
//	<br>./startDN
//	</ul>
//	<p>
//	The Fault Manager task will run and then start all other
//	tasks.
//	</p>
//	<h3>System shutdown on Unix
//	<p>
//	To shutdown the DataNavigator server:
//	<ul>
//	<li>Run a command line shell
//	<li>cd <i>node001</i>/Alpha/Bin
//	<li>./stopDN FM
//	</ul>
//	<li>The Fault Manager task will terminate all other
//	tasks before stopping itself.
//	</p>
//	<h3>System startup on Microsoft Windows
//	<p>
//	To start the DataNavigator server:
//	<ul>
//	<li>Open the Microsoft Services console application.
//	<br>Start : DataNavigator FM.
//	</ul>
//	The Fault Manager service will run and then start all
//	other services.
//	<p>
//	Note:  The Fault Manager service (FM) can be configured
//	to start automatically each time the Windows server
//	starts.
//	</p>
//	<h3>System shutdown on Microsoft Windows
//	<p>
//	To shutdown the DataNavigator server:
//	<ul>
//	<li>Open the Microsoft Services console application.
//	<li>Stop : DataNavigator FM.
//	</ul>
//	<p>
//	The Fault Manager service will stop all other services
//	before stopping itself.
//	</p>
//	</body>
//## Category: Connex Application::FaultManager_CAT%3D8237C100CB
//## Subsystem: FM%3D8238430271
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3D8249110290;IF::Message { -> F}
//## Uses: <unnamed>%3D878B7D008C;IF::Extract { -> F}
//## Uses: <unnamed>%3DA3172B0290;IF::Sleep { -> F}
//## Uses: <unnamed>%3F1D7F27007D;database::Database { -> F}
//## Uses: <unnamed>%3F1D81EE038A;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%40AA608E006D;platform::Platform { -> F}
//## Uses: <unnamed>%48C915970047;IF::Message { -> F}
//## Uses: <unnamed>%48C915A80326;monitor::UseCase { -> F}
//## Uses: <unnamed>%5995B926019D;reusable::Buffer { -> F}
//## Uses: <unnamed>%5995EE840153;IF::SocketQueue { -> F}
//## Uses: <unnamed>%5995EEAF010C;IF::Console { -> F}
//## Uses: <unnamed>%5995EEC4028C;IF::Trace { -> F}
//## Uses: <unnamed>%5995EED90185;IF::FlatFile { -> F}
//## Uses: <unnamed>%5995EEEC0026;IF::DateTime { -> F}
//## Uses: <unnamed>%5995EF1803AF;reusable::Statement { -> F}
//## Uses: <unnamed>%5995EF3D0180;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5995EF550079;timer::Clock { -> F}
//## Uses: <unnamed>%5995EF680049;segment::InformationSegment { -> F}
//## Uses: <unnamed>%5995EF890094;segment::AuditEvent { -> F}
//## Uses: <unnamed>%5995EFAC03D4;database::AuditEvent { -> F}
//## Uses: <unnamed>%5AA6D6D3028A;database::CommonContext { -> F}
//## Uses: <unnamed>%5AA6D6D6021E;segment::GenericSegment { -> F}
//## Uses: <unnamed>%5AA6D6D9019D;command::Email { -> F}
//## Uses: <unnamed>%600999890306;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%600999E001DD;timer::Date { -> F}
//## Uses: <unnamed>%600A6C1C026E;database::DatabaseFactory { -> F}

class FaultManager : public process::Application  //## Inherits: <unnamed>%3D8237FE0280
{
  //## begin FaultManager%3D8237E60261.initialDeclarations preserve=yes
  //## end FaultManager%3D8237E60261.initialDeclarations

  public:
    //## Constructors (generated)
      FaultManager();

    //## Destructor (generated)
      virtual ~FaultManager();


    //## Other Operations (specified)
      //## Operation: checkStatus%60C85E640352
      bool checkStatus (const string& strIMAGE_ID, const string& strTASKID, const string& strCONTEXT_DATA, const int iCount);

      //## Operation: initialize%3D8238160119
      //	<body>
      //	<title>IG
      //	<h1>HN
      //	<h2>AB
      //	<h3>Setup
      //	<p>
      //	The Application Server software is installed on one or
      //	more servers that will host DataNavigator services.
      //	The following instructions apply to the primary
      //	application server.
      //	</p>
      //	<ol>
      //	<li>Plan your disk configuration; for example:
      //	<ul>
      //	<li>C: drive for Windows
      //	<li>D: drive for DataNavigator Server software and file
      //	system
      //	</ul>
      //	<li>Add a new local user (db2admin) for server
      //	installation
      //	<li>Add the new user (db2admin) to the Administrators
      //	group
      //	<li>Log Off from Windows
      //	<li>Log In to Windows as db2admin
      //	<li>Install IBM UDB Version 8.1 Client Software on D:
      //	<li>Install IBM Websphere MQ Software on D:
      //	<li>For IBM Websphere MQ, add MUSR_MQADMIN to the
      //	Administrators group
      //	<li>Start ... Programs ... IBM DB2 ... Set-up Tools ...
      //	Configuration Assistant
      //	<li>Establish a connection to the DataNavigator database
      //	<li>Install the Application Server using the Data
      //	Navigator Server CD
      //	</ol>
      //	Grant access to the file system (<i>node001</i>):
      //	<ol>
      //	<li>In Windows Explorer:
      //	<ul>
      //	<li>Share <i>node001</i> as eFunds
      //	<li>Add ANONYMOUS LOGON to the new eFunds share with
      //	Full Control access
      //	</ul>
      //	<li>Start ... Programs ... Administrative Tools ...
      //	Local Security Policy
      //	<ul>
      //	<li>Add the new eFunds share to Network access: Shares
      //	that can be accessed anonymously
      //	</ul>
      //	<li>Start ... Settings ... Control Panel ... System
      //	<ul>
      //	<li>Add <i>node001</i>\Alpha\Bin to the Path environment
      //	variable.
      //	</ul>
      //	</ol>
      //	<p>
      //	Create the installation scripts:
      //	<ol>
      //	<li>Start ... Programs ... Accessories ... Command Prompt
      //	<li>D:
      //	<li>cd <i>node001</i>\Alpha\Bin
      //	<li>dndb2 -f +CXOXSLST -p "<i>node001</i>" -n -d
      //	yyyymm=<i>yyyymm</i>
      //	</ol>
      //	<p>
      //	In the following steps, scripts will be executed.
      //	Use the following command syntax:
      //	<ul>
      //	<li>db2 -f
      //	"<i>node001</i>\alpha\dnbuild\<i>script</i>.txt" -tvz
      //	"<i>node001</i>\Trace\<i>script</i>.txt"
      //	</ul>
      //	<p>
      //	On the application server, execute the following scripts
      //	(supplying the password from the database server):
      //	<table>
      //	<tr>
      //	<th>Script
      //	<th>Purpose
      //	<tr>
      //	<td>CATNODE
      //	<td>Creates TCP/IP node for instance connection
      //	<tr>
      //	<td>DBCREATE
      //	<td>Catalogs the database
      //	<tr>
      //	<td>CREATEBP
      //	<td>Creates buffer pools
      //	<tr>
      //	<td>CRTBLSPC
      //	<td>Creates common database table spaces
      //	<tr>
      //	<td>COBUILD
      //	<td>Creates Connex CR tables
      //	<tr>
      //	<td>CRBUILD
      //	<td>Creates common database tables
      //	<tr>
      //	<td>CRTBLSPD
      //	<td>Creates customer database table spaces
      //	<tr>
      //	<td>DRBUILD
      //	<td>Creates customer database tables
      //	<tr>
      //	<td>GRANTDB
      //	<td>Grants authority to the DataNavigator application
      //	server
      //	<tr>
      //	<td>GRANTBAU
      //	<td>Grant bind authority
      //	</table>
      //	<p>
      //	On the database server, map a network drive (e.g. F:) in
      //	Windows Explorer to the eFunds share on the application
      //	server.
      //	<p>
      //	Create the directories to hold the database logs and
      //	database backups:
      //	<ol>
      //	<li>Start ... Programs ... IBM DB2 ... Command Line
      //	Tools ... Command Window
      //	<li>F:
      //	<li>cd Alpha\DNBuild
      //	<li>rename MAKEDRS.txt MAKEDRS.cmd
      //	<li>MAKEDRS
      //	</ol>
      //	<p>
      //	On the database server, execute the following scripts in
      //	the DB2 Command Window:
      //	<table>
      //	<tr>
      //	<th>Script
      //	<th>Purpose
      //	<tr>
      //	<td>CFGDBMGR
      //	<td>Set database manager configuration parameters
      //	<tr>
      //	<td>CFGDB
      //	<td>Set database configuration parameters
      //	<tr>
      //	<td>BACKUPOF
      //	<td>Backup the database
      //	</table>
      //	<p>
      //	Stop and restart the database instance.
      //	On the database server in the DB2 command window, enter:
      //	<ol>
      //	<li>db2 stop dbm force
      //	<li>db2 start dbm
      //	<li>db2 restart db <i>dbname</i>
      //	</ol>
      //	<p>
      //	A database package must be created for use by the
      //	application server.
      //	On the application server in the DB2 command window:
      //	<ol>
      //	<li>cd <i>node001</i>\alpha\bin
      //	<li>db2 connect to <i>udbdb</i> user <i>useridbi</i>
      //	<li>db2 bind @CXOPD200.lst qualifier <i>custqual</i>
      //	collection <i>plan</i>
      //	</ol>
      //	<p>
      //	Start the DataNavigator Fault Manager from the command
      //	line:
      //	<ol>
      //	<li>Start ... Programs ... Accessories ... Command Prompt
      //	<li>D:
      //	<li>cd "\Program Files\eFunds\Server\Alpha\Bin"
      //	<li>CXOPFM00 -p <i>"node001"</i>
      //	</ol>
      //	The Fault Manager will define and restart itself as a
      //	Windows service.
      //	Use the Microsoft Services MMC snap-in to verify that
      //	the following services are now running:
      //	<ol>
      //	<li>DataNavigator FM
      //	<li>DataNavigator HM
      //	<li>DataNavigator XT
      //	</ol>
      //	<p>
      //	The DataNavigator XT service populates your
      //	configuration repository using load scripts,
      //	site specification parameters and data supplied by e
      //	Funds.
      //	To verify successful initialization, start the Data
      //	Navigator console:
      //	<ol>
      //	<li>Start ... Run ... mmc
      //	<li>Add the DataNavigator Management snap-in to your MMC
      //	console
      //	<li>Save your console as DataNavigator.msc
      //	<li>Open the Health folder
      //	<li>Select the Configuration folder
      //	<li>Verify that the XT CR47 POPULATE CR use case was
      //	successful (Total = 1 and Failure = 0)
      //	<li>Select the Change Management folder
      //	<li>Rollin the INITIAL1 change group (use right click
      //	menu)
      //	<li>Select the Messages folder
      //	<li>Verify that message ST600 CHANGE ID INITIAL1 ROLL IN
      //	SUCCESSFUL is displayed
      //	<li>Exit from the MMC console
      //	</ol>
      //	<p>
      //	Use the Microsoft Windows Services MMC snap-in to
      //	shutdown DataNavigator FM.
      //	<p>
      //	Roll in the first set of extract files:
      //	<ol>
      //	<li>copy <i>node001\qualify</i>\Pprod\*.* to
      //	<i>node001\qualify</i>\Pprev
      //	<li>copy <i>node001\qualify</i>\Pstage\*.* to
      //	<i>node001\qualify</i>\Pprod
      //	</ol>
      //	<p>
      //	Copy configuration data for your EFT platform for import
      //	into DataNavigator.
      //	For example, for eFunds Advantage customers, copy the
      //	Advantage CED to <i>node001\custqual</i>\CED.txt.
      //	<p>
      //	Use the Microsoft Windows Services dialog to start Data
      //	Navigator FM.
      //	All services in your configuration should now start on
      //	the application server.
      //	This can be verified using the Microsoft Services MMC
      //	snap-in.
      //	</p>
      //	Start the DataNavigator console:
      //	<ol>
      //	<li>Start ... Program Files ... Administrative Tools ...
      //	DataNavigator.msc
      //	<li>Select the Change Management folder
      //	<li>Rollin the INITIAL2 change group (use right click
      //	menu)
      //	<li>Select the Messages folder
      //	<li>Verify that message ST600 CHANGE ID INITIAL2 ROLL IN
      //	SUCCESSFUL is displayed
      //	</ol>
      //	<p>
      //	Roll in the second set of extract files:
      //	<ol>
      //	<li>copy <i>node001\qualify</i>\Pprod\*.* to
      //	<i>node001\qualify</i>\Pprev
      //	<li>copy <i>node001\qualify</i>\Pstage\*.* to
      //	<i>node001\qualify</i>\Pprod
      //	</ol>
      //	<p>
      //	The DataNavigator server is now ready to begin loading
      //	your EFT transactions.
      //	Refer to Log Reader (for batch loading) or Queue Reader
      //	(for continuous feed) in the Configuration Guides for
      //	setup instructions.
      //	<h2>FI
      //	<h3>Installation prerequisites
      //	<p>
      //	The Application Server requires the following:
      //	<ul>
      //	<li>Microsoft Windows 2003
      //	<li>IBM UDB Version 8.1 Client Software
      //	<li>IBM Websphere MQ
      //	</ul>
      //	<h2>FO
      //	<h3>InstallShield setup
      //	<p>
      //	The following items are established during installation:
      //	<ol>
      //	<li>Connection to the DataNavigator database
      //	<li>D:\Program Files\eFunds\Server\Alpha\Bin
      //	<ul>
      //	<li>CXOPnnnn.dll
      //	<li>CXOPnnnn.exe
      //	<li>CXOSnnnn.bnd
      //	<li>CXOPD200.lst
      //	<li>msvcp70.dll
      //	<li>msvcr70.dll
      //	</ul>
      //	<li>D:\<i>node001</i>\Alpha\Source
      //	<ul>
      //	<li>CXOXnnnn.txt files
      //	</ul>
      //	<li>D:\<i>node001</i>\Setup
      //	<ul>
      //	<li>CUSTSPEC.txt
      //	<li>SITESPEC.txt
      //	</ul>
      //	</ol>
      //	</body>
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>FM
      //	<h2>MS
      //	<h3>Scalability
      //	<p>
      //	The configuration of your DataNavigator Application
      //	Server reflects the DataNavigator product structure.
      //	The services within a product component are logically
      //	grouped together.
      //	This structure provides a starting point for deploying
      //	DataNavigator to multiple Microsoft Windows or Unix
      //	servers.
      //	<p>
      //	Each component (e.g. Totals) in the structure is
      //	associated with a Region in the Configuration Repository.
      //	The DataNavigator server installation creates the
      //	following Regions:
      //	<p>
      //	<table>
      //	<tr>
      //	<th>Region
      //	<th>DataNavigator Component
      //	<tr>
      //	<td>DNDN00
      //	<td>Foundation (except Client Interface)
      //	<td>
      //	<tr>
      //	<td><i>ca</i>DN00
      //	<td>Transaction Processing
      //	<td>
      //	<tr>
      //	<td><i>ca</i>DN01
      //	<td>Client Interface
      //	<td>
      //	<tr>
      //	<td><i>ca</i>DN03
      //	<td>Continuous Feed
      //	<td>
      //	<tr>
      //	<td><i>ca</i>DN04
      //	<td>Transaction Research and Adjustments
      //	<td>
      //	<tr>
      //	<td><i>ca</i>DN05
      //	<td>Totals
      //	<td>
      //	<tr>
      //	<td><i>ca</i>DN06
      //	<td>Utilities
      //	<td>
      //	<tr>
      //	<td><i>ca</i>DN08
      //	<td>Device Services
      //	<td>
      //	<tr>
      //	<td><i>ca</i>DN09
      //	<td>Reconciliation
      //	<td>
      //	<tr>
      //	<td><i>ca</i>DN10
      //	<td>Data Distribution
      //	<td>
      //	</table>
      //	<p>
      //	All Regions are initially associated with a single
      //	Microsoft Windows or Unix server.
      //	Here are recommended configurations assuming 2, 3 or 4
      //	available servers:
      //	<table>
      //	<tr>
      //	<th>Servers
      //	<th>Server
      //	<th>Configuration
      //	<tr>
      //	<td>2
      //	<td>A
      //	<td>DNDN00, <i>ca</i>DN00, <i>ca</i>DN03, <i>ca</i>DN05,
      //	<i>ca</i>DN09 and <i>ca</i>DN10
      //	<tr>
      //	<td>
      //	<td>B
      //	<td><i>ca</i>DN01, <i>ca</i>DN04, <i>ca</i>DN06 and
      //	<i>ca</i>DN08
      //	<tr>
      //	<td>3
      //	<td>A
      //	<td>DNDN00, <i>ca</i>DN05, <i>ca</i>DN09 and
      //	<i>ca</i>DN10
      //	<tr>
      //	<td>
      //	<td>B
      //	<td><i>ca</i>DN01, <i>ca</i>DN04, <i>ca</i>DN06 and
      //	<i>ca</i>DN08
      //	<tr>
      //	<td>
      //	<td>C
      //	<td><i>ca</i>DN00 and <i>ca</i>DN03
      //	<tr>
      //	<td>4
      //	<td>A
      //	<td>DNDN00
      //	<tr>
      //	<td>
      //	<td>B
      //	<td><i>ca</i>DN01, <i>ca</i>DN04, <i>ca</i>DN06 and
      //	<i>ca</i>DN08
      //	<tr>
      //	<td>
      //	<td>C
      //	<td><i>ca</i>DN00 and <i>ca</i>DN03
      //	<tr>
      //	<td>
      //	<td>D
      //	<td><i>ca</i>DN05, <i>ca</i>DN09 and <i>ca</i>DN10
      //	</table>
      //	<p>
      //	Each Region is associated with a physical server by
      //	specifying the server name in the Description field.
      //	<p>
      //	<img src=CXOCFM01.gif>
      //	<p>
      //	Regions are in the Task Configuration folder in the CR
      //	Client for the DataNavigator Server.
      //	</p>
      //	<h1>FM
      //	<h2>MS
      //	<h3>TCP/IP Port Number
      //	<p>
      //	The services in the DataNavigator Server communicate via
      //	TCP/IP.
      //	By default, the Fault Manager service accepts
      //	connections on port 52000.
      //	The port numbers for all other services (except the
      //	Client Interface) in your configuration are derived off
      //	of the value for Fault Manager (e.g. 52001, 52002, etc).
      //	The base value (i.e. 52000) is specified in the
      //	Application ID in the Task definition for the Fault
      //	Manager service.
      //	<p>
      //	<img src=CXOCFM02.gif>
      //	<p>
      //	If desired, use the CR Client for the DataNavigator
      //	Server to change this value to comply with your
      //	installation standards.
      //	</body>
      virtual int initialize ();

      //## Operation: monitor%59DE0DED01F5
      void monitor ();

      //## Operation: onQuiesce%3E4E7A1A01D4
      //	Responds to the quiesce request from FaultManager to
      //	indicate that the Application has quiesced.
      virtual int onQuiesce ();

      //## Operation: parseCommandLine%3DC92B7802BF
      virtual void parseCommandLine (int iArgc, char** ppArgv);

      //## Operation: quiesceTasks%59A96AA302E5
      int quiesceTasks ();

      //## Operation: setState%466818B50290
      virtual void setState (const char*  pszCONTEXT_DATA, const char*  pszTaskID = 0);

      //## Operation: shutdownTasks%43EF689B0251
      //	Marks the Application as shutdown.
      int shutdownTasks ();

      //## Operation: start%5995B6EF02D3
      bool start (map<string, process::Task *, less<string> >::iterator p);

      //## Operation: startupTasks%59A967F90385
      int startupTasks ();

      //## Operation: takeBack%60C85E9501DE
      void takeBack ();

      //## Operation: takeOver%60C85E2D0115
      void takeOver ();

      //## Operation: update%3F1D7A360232
      //## Semantics:
      //	1. Call m_pSettledDate->get to get the last settled
      //	timestamp.
      //	2. Call TransactionIterator::setEndTimestamp.
      virtual void update (Subject* pSubject);

      //## Operation: verifyStatus%5AA944BE0040
      bool verifyStatus (map<string, process::Task *, less<string> >::iterator p);

      //## Operation: wait%5995F6E50338
      bool wait (const string& strTASKID, const char* pszCONTEXT_DATA, int iCount);

    // Additional Public Declarations
      //## begin FaultManager%3D8237E60261.public preserve=yes
      //## end FaultManager%3D8237E60261.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%3F1D8C7401B5
      virtual int onMessage (Message& hMessage);

      //## Operation: onReset%60C869CB0166
      virtual int onReset (Message& hMessage);

      //## Operation: onResume%3D82381900DA
      virtual int onResume (Message& hMessage);

      //## Operation: shutdown%59BA7308011F
      //	Marks the Application as shutdown.
      virtual int shutdown ();

    // Additional Protected Declarations
      //## begin FaultManager%3D8237E60261.protected preserve=yes
      //## end FaultManager%3D8237E60261.protected

  private:
    // Additional Private Declarations
      //## begin FaultManager%3D8237E60261.private preserve=yes
      //## end FaultManager%3D8237E60261.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CONTEXT_DATA%59DE1002001B
      //## begin FaultManager::CONTEXT_DATA%59DE1002001B.attr preserve=no  private: string {V} 
      string m_strCONTEXT_DATA;
      //## end FaultManager::CONTEXT_DATA%59DE1002001B.attr

      //## Attribute: CONTEXT_KEY%61258DB6012A
      //## begin FaultManager::CONTEXT_KEY%61258DB6012A.attr preserve=no  private: string {V} 
      string m_strCONTEXT_KEY;
      //## end FaultManager::CONTEXT_KEY%61258DB6012A.attr

      //## Attribute: Service%3F1D970802DE
      //## begin FaultManager::Service%3F1D970802DE.attr preserve=no  private: string {V} 
      string m_strService;
      //## end FaultManager::Service%3F1D970802DE.attr

      //## Attribute: Setup%3E6E1C480203
      //	True if started from the command line during setup.
      //## begin FaultManager::Setup%3E6E1C480203.attr preserve=no  private: bool {V} false
      bool m_bSetup;
      //## end FaultManager::Setup%3E6E1C480203.attr

      //## Attribute: TASKID%59DE100201DD
      //## begin FaultManager::TASKID%59DE100201DD.attr preserve=no  private: string {V} 
      string m_strTASKID;
      //## end FaultManager::TASKID%59DE100201DD.attr

      //## Attribute: IMAGE_ID%60C86BF6019F
      //## begin FaultManager::IMAGE_ID%60C86BF6019F.attr preserve=no  private: string {V} 
      string m_strIMAGE_ID;
      //## end FaultManager::IMAGE_ID%60C86BF6019F.attr

    // Data Members for Associations

      //## Association: Connex Application::FaultManager_CAT::<unnamed>%43CA40780186
      //## Role: FaultManager::<m_hTask>%43CA407900CB
      //## Qualifier: strName%5AA15F4A024B; string
      //## begin FaultManager::<m_hTask>%43CA407900CB.role preserve=no  public: process::Task {1 -> 1RHgN}
      map<string, process::Task *, less<string> > m_hTask;
      //## end FaultManager::<m_hTask>%43CA407900CB.role

      //## Association: Connex Application::FaultManager_CAT::<unnamed>%59DE0F360365
      //## Role: FaultManager::<m_hQuery>%59DE0F37025D
      //## begin FaultManager::<m_hQuery>%59DE0F37025D.role preserve=no  public: reusable::Query { -> VFHgN}
      reusable::Query m_hQuery;
      //## end FaultManager::<m_hQuery>%59DE0F37025D.role

    // Additional Implementation Declarations
      //## begin FaultManager%3D8237E60261.implementation preserve=yes
      map<string, process::Task*>::reverse_iterator m_pRevIter;
      vector<string> m_hIMAGE_ID;
      //## end FaultManager%3D8237E60261.implementation
};

//## begin FaultManager%3D8237E60261.postscript preserve=yes
//## end FaultManager%3D8237E60261.postscript

//## begin module%3D82386200EA.epilog preserve=yes
//## end module%3D82386200EA.epilog


#endif
