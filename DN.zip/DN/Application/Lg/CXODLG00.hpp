//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E97251301F4.cm preserve=no
//	$Date:   Jun 26 2008 10:42:10  $ $Author:   D02405  $ $Revision:   1.5  $
//## end module%3E97251301F4.cm

//## begin module%3E97251301F4.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%3E97251301F4.cp

//## Module: CXOPLG00%3E97251301F4; Package specification
//## Subsystem: LG%3E97204A009C
//## Source file: C:\Devel\ConnexPlatform\Server\Application\Lg\CXODLG00.hpp

#ifndef CXOPLG00_h
#define CXOPLG00_h 1

//## begin module%3E97251301F4.additionalIncludes preserve=no
//## end module%3E97251301F4.additionalIncludes

//## begin module%3E97251301F4.includes preserve=yes
//## end module%3E97251301F4.includes

#ifndef CXOSLG01_h
#include "CXODLG01.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;

} // namespace platform

//## begin module%3E97251301F4.declarations preserve=no
//## end module%3E97251301F4.declarations

//## begin module%3E97251301F4.additionalDeclarations preserve=yes
//## end module%3E97251301F4.additionalDeclarations


//## begin Logger%3E97214A035B.preface preserve=yes
//## end Logger%3E97214A035B.preface

//## Class: Logger%3E97214A035B
//	<body>
//	<title>CG
//	<h1>LG
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server logs all end user activity.
//	The logs contain:
//	<ul>
//	<li>Each request message received from an end user
//	<li>Each response message returned to an end user
//	</ul>
//	<p>
//	The formats of the request and response messages are in
//	the <i>DataNavigator External Interface Message
//	Specification Guide</i>.
//	<p>
//	Dual logging is provided by the primary (LOGP) and
//	secondary (LOGS) logger services.
//	<p>
//	<img src=CXOCLG00.gif>
//	</body>
//	<body>
//	<title>OG
//	<h1>LG
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server logs all end user activity.
//	The logs can be used to troubleshoot issues reported by
//	end users.
//	All messages between the DataNavigator server and the
//	DataNavigator clients are logged.
//	The formats of the messages are in the <i>DataNavigator
//	External Interface Message Specification Guide</i>.
//	<p>
//	<img src=CXOOLG00.gif>
//	</body>
//	<body>
//	<title>CG
//	<h1>QL
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server can optionally log all messages
//	received by the Queue Reader service.
//	The replicated logs can be used as input to other back
//	office applications.
//	<p>
//	Dual logging is provided by the primary (<i>ca</i>LGP)
//	and secondary (<i>ca</i>LGS) logger services.
//	<p>
//	<img src=CXOCQL00.gif>
//	</body>
//	<body>
//	<title>OG
//	<h1>QL
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server can optionally log all messages
//	received by the Queue Reader service.
//	The replicated logs can be used as input to other back
//	office applications.
//	<p>
//	<img src=CXOOQL00.gif>
//	<h2>SH
//	<h3>Statistics
//	<p>
//	See the Logger service in the <i>DataNavigator
//	Operations Guide : Foundation</i> manual.
//	</body>
//## Category: Connex Application::Logger_CAT%3E972028034B
//## Subsystem: LG%3E97204A009C
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E9AC0C80177;monitor::UseCase { -> F}
//## Uses: <unnamed>%3E9ACB46008C;IF::Message { -> F}
//## Uses: <unnamed>%3F337E0B03D8;database::Database { -> F}
//## Uses: <unnamed>%40AA63BD0280;platform::Platform { -> F}
//## Uses: <unnamed>%4862A413034B;timer::MidnightAlarm { -> F}

class DllExport Logger : public process::Application  //## Inherits: <unnamed>%3E97222701C5
{
  //## begin Logger%3E97214A035B.initialDeclarations preserve=yes
  //## end Logger%3E97214A035B.initialDeclarations

  public:
    //## Constructors (generated)
      Logger();

    //## Destructor (generated)
      virtual ~Logger();


    //## Other Operations (specified)
      //## Operation: initialize%3E97272C01D4
      int initialize ();

      //## Operation: onQuiesce%3FA0A549010A
      //	Responds to the quiesce request from FaultManager to
      //	indicate that the Application has quiesced.
      virtual int onQuiesce ();

      //## Operation: update%4862A4470109
      //	Interprets the inbound Message and calls:
      //
      //	   Application::onConfirm
      //	   Application::onMessage
      //	   Application::onNotify
      //	   Application::onQuiesce
      //	   Application::onRefresh
      //	   Application::onReset
      //	   Application::shutdown
      //	   Timer::elapsed
      //## Postconditions:
      //	<body>
      //	<title>CG
      //	<h1>FM
      //	<h2>FO
      //	<h3>Messages
      //	<p>
      //	Messages displayed by the DataNavigator services are
      //	saved in:
      //	<ul>
      //	<li><i>qualify</i>.CONSOLE_MSG
      //	</ul>
      //	</body>
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin Logger%3E97214A035B.public preserve=yes
      //## end Logger%3E97214A035B.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%3E97273601F4
      virtual int onMessage (IF::Message& hMessage);

      //## Operation: onReset%3FA0A55B0279
      virtual int onReset (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin Logger%3E97214A035B.protected preserve=yes
      //## end Logger%3E97214A035B.protected

  private:
    // Additional Private Declarations
      //## begin Logger%3E97214A035B.private preserve=yes
      //## end Logger%3E97214A035B.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Application::Logger_CAT::<unnamed>%3FA0C6BF032E
      //## Role: Logger::<m_hLogfile>%3FA0C6C0027C
      //## begin Logger::<m_hLogfile>%3FA0C6C0027C.role preserve=no  public: Logfile { -> VHgN}
      Logfile m_hLogfile;
      //## end Logger::<m_hLogfile>%3FA0C6C0027C.role

    // Additional Implementation Declarations
      //## begin Logger%3E97214A035B.implementation preserve=yes
      //## end Logger%3E97214A035B.implementation

};

//## begin Logger%3E97214A035B.postscript preserve=yes
//## end Logger%3E97214A035B.postscript

//## begin module%3E97251301F4.epilog preserve=yes
//## end module%3E97251301F4.epilog


#endif
