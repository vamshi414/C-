//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3FA0B7FB010C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3FA0B7FB010C.cm

//## begin module%3FA0B7FB010C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3FA0B7FB010C.cp

//## Module: CXOSLG01%3FA0B7FB010C; Package body
//## Subsystem: LG%3E97204A009C
//## Source file: C:\Devel\ConnexPlatform\Server\Application\Lg\CXOSLG01.cpp

//## begin module%3FA0B7FB010C.additionalIncludes preserve=no
//## end module%3FA0B7FB010C.additionalIncludes

//## begin module%3FA0B7FB010C.includes preserve=yes
// $Date:   May 13 2020 12:26:06  $ $Author:   e1009510  $ $Revision:   1.13  $
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%3FA0B7FB010C.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIF41_h
#include "CXODIF41.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSLG01_h
#include "CXODLG01.hpp"
#endif


//## begin module%3FA0B7FB010C.declarations preserve=no
//## end module%3FA0B7FB010C.declarations

//## begin module%3FA0B7FB010C.additionalDeclarations preserve=yes
//## end module%3FA0B7FB010C.additionalDeclarations


// Class Logfile

Logfile::Logfile()
  //## begin Logfile::Logfile%3FA0B19B010F_const.hasinit preserve=no
      : m_iCounter(0),
        m_pFile(0)
  //## end Logfile::Logfile%3FA0B19B010F_const.hasinit
  //## begin Logfile::Logfile%3FA0B19B010F_const.initialization preserve=yes
  //## end Logfile::Logfile%3FA0B19B010F_const.initialization
{
  //## begin Logfile::Logfile%3FA0B19B010F_const.body preserve=yes
   memcpy(m_sID,"LG01",4);
  //## end Logfile::Logfile%3FA0B19B010F_const.body
}


Logfile::~Logfile()
{
  //## begin Logfile::~Logfile%3FA0B19B010F_dest.body preserve=yes
   close();
   delete m_pFile;
  //## end Logfile::~Logfile%3FA0B19B010F_dest.body
}



//## Other Operations (implementation)
bool Logfile::close ()
{
  //## begin Logfile::close%3FA0B9720378.body preserve=yes
   UseCase hUseCase("FD","## LG01 CLOSE LOGFILE");
   if (!m_pFile)
      return true;
   bool b = flush();
   Console::display("ST140",m_pFile->getName().c_str());
   m_pFile->move("..\\Closed");
   return b;
  //## end Logfile::close%3FA0B9720378.body
}

bool Logfile::flush ()
{
  //## begin Logfile::flush%3FA0B97F0056.body preserve=yes
   UseCase hUseCase("FD","## LG01 FLUSH LOGFILE");
   if (!m_pFile)
      return true;
   bool b = m_pFile->flush();
   if (b)
      sendConfirmations();
   else
   {
      Console::display("ST142",m_pFile->getName().c_str());
      UseCase::setSuccess(false);
   }
   m_hConfirmations.erase(m_hConfirmations.begin(),m_hConfirmations.end());
   m_iCounter = 0;
   return b;
  //## end Logfile::flush%3FA0B97F0056.body
}

bool Logfile::open ()
{
  //## begin Logfile::open%3FA0B96601D6.body preserve=yes
   UseCase hUseCase("FD","## LG01 OPEN LOGFILE");
   if (m_pFile == 0)
   {
      if ((Application::instance()->name().substr(0,4) == "LOGP") ||
         (Application::instance()->name().substr(0,4) == "LOGS"))
         m_pFile = new IF::FlatFile("LOGFILE");
      else
         m_pFile = new IF::VariableBlockFile("LOGFILE");
   }
   m_pFile->setName("LOGFILE");
   if (m_pFile->open(FlatFile::CX_OPEN_OUTPUT))
   {
      Console::display("ST141",m_pFile->getName().c_str());
      return true;
   }
   Console::display("ST142",m_pFile->getName().c_str());
   UseCase::setSuccess(false);
   return false;
  //## end Logfile::open%3FA0B96601D6.body
}

void Logfile::sendConfirmations ()
{
  //## begin Logfile::sendConfirmations%3FA0B99E0123.body preserve=yes
   if (Application::instance()->name().find("LOGP") == string::npos)
      return;
   UseCase hUseCase("FD","## LG01 SEND CONFIRMATIONS");
   char szTemp[128];
   vector<pair<string,pair<void*,double> > >::iterator q;
   for (q = m_hConfirmations.begin();q != m_hConfirmations.end();q++)
   {
      Trace::put(szTemp,snprintf(szTemp,sizeof(szTemp),"Sending confirmation: Source=%s,CB Address=%ld,STCK=%ld",(*q).first.c_str(),(*q).second.first,(*q).second.second));
      Message::instance(Message::OUTBOUND)->reset("LOG   ","H6000R",false);
      Message::instance(Message::OUTBOUND)->setReceiverCBAddress((*q).second.first);
      Message::instance(Message::OUTBOUND)->setReceiverSTCKValue((char*)&(*q).second.second);
      char* p = Message::instance(Message::OUTBOUND)->data();
      *p = 'X';
      Message::instance(Message::OUTBOUND)->setDataLength(1);
      Queue::send((*q).first.c_str(),Message::instance(Message::OUTBOUND),Queue::REQUEST);
      hUseCase.addItem();
   }
  //## end Logfile::sendConfirmations%3FA0B99E0123.body
}

bool Logfile::swap ()
{
  //## begin Logfile::swap%3FA0B98B0374.body preserve=yes
   UseCase hUseCase("FD","## LG01 SWAP LOGFILE");
   return (close() && open());
  //## end Logfile::swap%3FA0B98B0374.body
}

bool Logfile::write (IF::Message& hMessage)
{
  //## begin Logfile::write%3FA0B51801FA.body preserve=yes
   UseCase hUseCase("FD","## LG01 WRITE LOGFILE");
   hStandardHeader* pHeader = (hStandardHeader*)hMessage.buffer();
   if (strncmp(pHeader->sSenderSTCKValue,"        ",8) != 0
      && Application::instance()->name().find("LOGP") != string::npos)
   {
      string strSource(hMessage.getSource());
      double dSTCK = *(double*)&pHeader->sSenderSTCKValue;
      void* pCBAddress = pHeader->pSenderCBAddress;
      pair<void*,double> hTemp(pCBAddress,dSTCK);
      pair<string,pair<void*,double> > hTemp2(strSource,hTemp);
      m_hConfirmations.push_back(hTemp2);
   }
   if (m_pFile->write(hMessage.data(),hMessage.dataLength()))
      if (++m_iCounter == 50
         || Application::instance()->getQueueDepth() == 0)
         if (flush())
            return true;
         else
            ;
      else
         return true;
   Console::display("ST142",m_pFile->getName().c_str());
   swap();
   m_hConfirmations.erase(m_hConfirmations.begin(),m_hConfirmations.end());
   return UseCase::setSuccess(false);
  //## end Logfile::write%3FA0B51801FA.body
}

// Additional Declarations
  //## begin Logfile%3FA0B19B010F.declarations preserve=yes
  //## end Logfile%3FA0B19B010F.declarations

//## begin module%3FA0B7FB010C.epilog preserve=yes
//## end module%3FA0B7FB010C.epilog
