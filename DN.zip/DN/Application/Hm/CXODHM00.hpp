//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E6CF8B600EA.cm preserve=no
//## end module%3E6CF8B600EA.cm

//## begin module%3E6CF8B600EA.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3E6CF8B600EA.cp

//## Module: CXOPHM00%3E6CF8B600EA; Package specification
//## Subsystem: HM%3E6CAD66037A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Application\Hm\CXODHM00.hpp

#ifndef CXOPHM00_h
#define CXOPHM00_h 1

//## begin module%3E6CF8B600EA.additionalIncludes preserve=no
//## end module%3E6CF8B600EA.additionalIncludes

//## begin module%3E6CF8B600EA.includes preserve=yes
//## end module%3E6CF8B600EA.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace IF {
class Sleep;
class Queue;
class Message;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class HealthMonitorSegment;
} // namespace segment

namespace database {
class Database;
} // namespace database

namespace segment {
class InformationSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Count;
} // namespace command

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;

} // namespace platform

//## begin module%3E6CF8B600EA.declarations preserve=no
//## end module%3E6CF8B600EA.declarations

//## begin module%3E6CF8B600EA.additionalDeclarations preserve=yes
//## end module%3E6CF8B600EA.additionalDeclarations


//## begin HealthMonitor%3E6CF6FF0196.preface preserve=yes
//## end HealthMonitor%3E6CF6FF0196.preface

//## Class: HealthMonitor%3E6CF6FF0196
//	<body>
//	<title>CG
//	<h1>HM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	Each service in the DataNavigator Application Server
//	counts:
//	<ul>
//	<li>Execution of each business function
//	<li>Success or failure of the function
//	<li>Subordinate counts
//	<li>Instances of database issues (e.g. deadlocks,
//	connection failures, resource issues)
//	</ul>
//	The counts are sent from each service to the System
//	Health Monitor once per minute.
//	System Health Monitor accumulates the counts on an
//	hourly basis in the data repository.
//	These counts can be viewed at the Operator Console to
//	see both current and historical activity in the server.
//	</p>
//	<img src=CXOCHM00.gif>
//	<title>OG
//	<h1>HM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	Each service in the DataNavigator Application Server
//	counts:
//	<ul>
//	<li>Execution of each business function
//	<li>Success or failure of the function
//	<li>Subordinate counts
//	<li>Instances of database issues (e.g. deadlocks,
//	connection failures, resource issues)
//	</ul>
//	<p>
//	The information in System Health Monitor is organized in
//	the following domain areas:
//	<table>
//	<tr>
//	<th>Domain
//	<th>Purpose
//	<tr>
//	<td>Server
//	<td>Foundation service (e.g. Event Manager) processing
//	<tr>
//	<td>Data Repository
//	<td>Transaction loading and removal
//	<tr>
//	<td>Problems
//	<td>Problem Transaction Manager processing
//	<tr>
//	<td>Configuration
//	<td>Translation or verification done by the Transaction
//	Interface or the Problem Transaction Manager
//	<tr>
//	<td>Client
//	<td>All end user (GUI or Web) activity
//	<tr>
//	<td>Logs
//	<td>Processing of transactions (batch or live feed) from
//	the acquiring EFT platform
//	<tr>
//	<td>eFunds Advantage
//	<td>Processing of transactions or CED data from an e
//	Funds Advantage platform
//	<tr>
//	<td>eFunds Connex on IBM
//	<td>Processing of transactions or MTF data from an e
//	Funds Connex on IBM platform
//	<tr>
//	<td>EFT Platform
//	<td>Processing of transactions or configuration data
//	from other platforms
//	<tr>
//	<td>Totals
//	<td>Near real time calculation of transaction totals
//	</table>
//	<p>
//	The statistics available from each service are listed in
//	the Operations Guides under System Health Monitor
//	Interface.
//	<p>
//	The counts are sent from each service to the System
//	Health Monitor once per minute.
//	System Health Monitor accumulates the counts on an
//	hourly basis in the data repository.
//	These counts can be viewed at the Operator Console to
//	see both current and historical activity in the server.
//	</p>
//	<img src=CXOOHM00.gif>
//	</body>
//## Category: Connex Application::HealthMonitor_CAT%3E6CAD23009C
//## Subsystem: HM%3E6CAD66037A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E70B9FE005D;IF::Message { -> F}
//## Uses: Database%3E70BA11002E;database::Database { -> F}
//## Uses: <unnamed>%3E70BA13030D;IF::Trace { -> F}
//## Uses: <unnamed>%3E70BA1E0138;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3E773B100399;segment::HealthMonitorSegment { -> F}
//## Uses: <unnamed>%3E7777100203;segment::InformationSegment { -> F}
//## Uses: <unnamed>%3E806A460119;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%3E8084ED0128;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%3E80854B008C;timer::Date { -> F}
//## Uses: <unnamed>%3EB6B5980290;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%408439630290;platform::Platform { -> F}
//## Uses: <unnamed>%48D0E8EB03A4;monitor::UseCase { -> F}
//## Uses: <unnamed>%5436F5B50338;IF::Queue { -> F}
//## Uses: <unnamed>%5436F5FC002C;reusable::Buffer { -> F}
//## Uses: <unnamed>%543D6C400027;IF::Sleep { -> F}
//## Uses: <unnamed>%6437026A0224;command::Count { -> F}

class DllExport HealthMonitor : public process::Application  //## Inherits: <unnamed>%3E6CF79E000F
{
  //## begin HealthMonitor%3E6CF6FF0196.initialDeclarations preserve=yes
  //## end HealthMonitor%3E6CF6FF0196.initialDeclarations

  public:
    //## Constructors (generated)
      HealthMonitor();

    //## Destructor (generated)
      virtual ~HealthMonitor();


    //## Other Operations (specified)
      //## Operation: initialize%3E6D0711035B
      int initialize ();

      //## Operation: update%3E6D072900EA
      //## Semantics:
      //	1. Call m_pSettledDate->get to get the last settled
      //	timestamp.
      //	2. Call TransactionIterator::setEndTimestamp.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin HealthMonitor%3E6CF6FF0196.public preserve=yes
      //## end HealthMonitor%3E6CF6FF0196.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%3E7207030109
      //## Postconditions:
      //	<body>
      //	<title>CG
      //	<h1>HM
      //	<h2>FO
      //	<h3>Statistics
      //	<p>
      //	System Health Monitor records hourly statistics in the
      //	following table:
      //	<ul>
      //	<li><i>qualify</i>.SYS_HEALTH_MON
      //	</ul>
      //	Statistics are automatically deleted after seven days.
      //	</p>
      //	</body>
      virtual int onMessage (Message& hMessage);

    // Additional Protected Declarations
      //## begin HealthMonitor%3E6CF6FF0196.protected preserve=yes
      //## end HealthMonitor%3E6CF6FF0196.protected

  private:

    //## Other Operations (specified)
      //## Operation: trace%477CFAFE0119
      void trace ();

    // Additional Private Declarations
      //## begin HealthMonitor%3E6CF6FF0196.private preserve=yes
      //## end HealthMonitor%3E6CF6FF0196.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ACTION%477CFB4A0119
      //## begin HealthMonitor::ACTION%477CFB4A0119.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strACTION;
      //## end HealthMonitor::ACTION%477CFB4A0119.attr

      //## Attribute: DATE_TIME%477CFB340128
      //## begin HealthMonitor::DATE_TIME%477CFB340128.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strDATE_TIME;
      //## end HealthMonitor::DATE_TIME%477CFB340128.attr

      //## Attribute: DESCRIPTION%477CFB4A003E
      //## begin HealthMonitor::DESCRIPTION%477CFB4A003E.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strDESCRIPTION;
      //## end HealthMonitor::DESCRIPTION%477CFB4A003E.attr

      //## Attribute: Messages%3EB13C1702CE
      //## begin HealthMonitor::Messages%3EB13C1702CE.attr preserve=no  private: int {U} 0
      int m_lMessages;
      //## end HealthMonitor::Messages%3EB13C1702CE.attr

      //## Attribute: MSG_ID%477CFB49000F
      //## begin HealthMonitor::MSG_ID%477CFB49000F.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strMSG_ID;
      //## end HealthMonitor::MSG_ID%477CFB49000F.attr

      //## Attribute: MSG_PARMS%477CFB4900DA
      //## begin HealthMonitor::MSG_PARMS%477CFB4900DA.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strMSG_PARMS;
      //## end HealthMonitor::MSG_PARMS%477CFB4900DA.attr

      //## Attribute: SEVERITY%477CFB4A01F4
      //## begin HealthMonitor::SEVERITY%477CFB4A01F4.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strSEVERITY;
      //## end HealthMonitor::SEVERITY%477CFB4A01F4.attr

      //## Attribute: TASKID%477CFB48032C
      //## begin HealthMonitor::TASKID%477CFB48032C.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTASKID;
      //## end HealthMonitor::TASKID%477CFB48032C.attr

      //## Attribute: TEXT%477CFB49036B
      //## begin HealthMonitor::TEXT%477CFB49036B.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTEXT;
      //## end HealthMonitor::TEXT%477CFB49036B.attr

      //## Attribute: TSTAMP_UPDATED%477CFB4901A5
      //## begin HealthMonitor::TSTAMP_UPDATED%477CFB4901A5.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTSTAMP_UPDATED;
      //## end HealthMonitor::TSTAMP_UPDATED%477CFB4901A5.attr

      //## Attribute: USER_ID%477CFB490280
      //## begin HealthMonitor::USER_ID%477CFB490280.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strUSER_ID;
      //## end HealthMonitor::USER_ID%477CFB490280.attr

    // Data Members for Associations

      //## Association: Connex Application::HealthMonitor_CAT::<unnamed>%477CFAB70109
      //## Role: HealthMonitor::<m_hQuery>%477CFAB8004E
      //## begin HealthMonitor::<m_hQuery>%477CFAB8004E.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end HealthMonitor::<m_hQuery>%477CFAB8004E.role

    // Additional Implementation Declarations
      //## begin HealthMonitor%3E6CF6FF0196.implementation preserve=yes
      //## end HealthMonitor%3E6CF6FF0196.implementation

};

//## begin HealthMonitor%3E6CF6FF0196.postscript preserve=yes
//## end HealthMonitor%3E6CF6FF0196.postscript

//## begin module%3E6CF8B600EA.epilog preserve=yes
//## end module%3E6CF8B600EA.epilog


#endif
