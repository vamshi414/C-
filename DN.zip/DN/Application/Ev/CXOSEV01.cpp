//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3DDE459C00DA.cm preserve=no
//	$Date:   Sep 27 2018 08:13:46  $ $Author:   e1009839  $ $Revision:   1.21  $
//## end module%3DDE459C00DA.cm

//## begin module%3DDE459C00DA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3DDE459C00DA.cp

//## Module: CXOSEV01%3DDE459C00DA; Package body
//## Subsystem: EV%3DDE417A02EE
//## Source file: C:\bV02.9D.R001\Windows\Build\ConnexPlatform\Server\Application\Ev\CXOSEV01.cpp

//## begin module%3DDE459C00DA.additionalIncludes preserve=no
//## end module%3DDE459C00DA.additionalIncludes

//## begin module%3DDE459C00DA.includes preserve=yes
//## end module%3DDE459C00DA.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSIF42_h
#include "CXODIF42.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSEV01_h
#include "CXODEV01.hpp"
#endif


//## begin module%3DDE459C00DA.declarations preserve=no
//## end module%3DDE459C00DA.declarations

//## begin module%3DDE459C00DA.additionalDeclarations preserve=yes
//## end module%3DDE459C00DA.additionalDeclarations


// Class Event

Event::Event()
  //## begin Event::Event%3DDE468E034B_const.hasinit preserve=no
  //## end Event::Event%3DDE468E034B_const.hasinit
  //## begin Event::Event%3DDE468E034B_const.initialization preserve=yes
  //## end Event::Event%3DDE468E034B_const.initialization
{
  //## begin Event::Event%3DDE468E034B_const.body preserve=yes
   memcpy(m_sID,"EV01",4);
  //## end Event::Event%3DDE468E034B_const.body
}

Event::Event(const Event &right)
  //## begin Event::Event%3DDE468E034B_copy.hasinit preserve=no
  //## end Event::Event%3DDE468E034B_copy.hasinit
  //## begin Event::Event%3DDE468E034B_copy.initialization preserve=yes
  : m_strAUTOREC(right.m_strAUTOREC)
   ,m_strEVCLID(right.m_strEVCLID)
   ,m_strEVNTDAY(right.m_strEVNTDAY)
   ,m_strEVNTTIME(right.m_strEVNTTIME)
   ,m_strNETCMD(right.m_strNETCMD)
   ,m_strNETCOPT1(right.m_strNETCOPT1)
   ,m_strNETCOPT2(right.m_strNETCOPT2)
   ,m_strNETCOPT3(right.m_strNETCOPT3)
   ,m_strNETCOPT4(right.m_strNETCOPT4)
   ,m_strNETCOPT5(right.m_strNETCOPT5)
   ,m_strNETCOPT6(right.m_strNETCOPT6)
   ,m_strNETCOPT7(right.m_strNETCOPT7)
   ,m_strNETCOPT8(right.m_strNETCOPT8)
   ,m_strPROCID(right.m_strPROCID)
  //## end Event::Event%3DDE468E034B_copy.initialization
{
  //## begin Event::Event%3DDE468E034B_copy.body preserve=yes
   m_strTSTAMP_NEXT[0] = right.m_strTSTAMP_NEXT[0];
   m_strTSTAMP_NEXT[1] = right.m_strTSTAMP_NEXT[1];
  //## end Event::Event%3DDE468E034B_copy.body
}


Event::~Event()
{
  //## begin Event::~Event%3DDE468E034B_dest.body preserve=yes
  //## end Event::~Event%3DDE468E034B_dest.body
}


Event & Event::operator=(const Event &right)
{
  //## begin Event::operator=%3DDE468E034B_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_strAUTOREC = right.m_strAUTOREC;
   m_strEVCLID = right.m_strEVCLID;
   m_strEVNTDAY = right.m_strEVNTDAY;
   m_strEVNTTIME = right.m_strEVNTTIME;
   m_strNETCMD = right.m_strNETCMD;
   m_strNETCOPT1 = right.m_strNETCOPT1;
   m_strNETCOPT2 = right.m_strNETCOPT2;
   m_strNETCOPT3 = right.m_strNETCOPT3;
   m_strNETCOPT4 = right.m_strNETCOPT4;
   m_strNETCOPT5 = right.m_strNETCOPT5;
   m_strNETCOPT6 = right.m_strNETCOPT6;
   m_strNETCOPT7 = right.m_strNETCOPT7;
   m_strNETCOPT8 = right.m_strNETCOPT8;
   m_strPROCID = right.m_strPROCID;
   m_strTSTAMP_NEXT[0] = right.m_strTSTAMP_NEXT[0];
   m_strTSTAMP_NEXT[1] = right.m_strTSTAMP_NEXT[1];
   return *this;
  //## end Event::operator=%3DDE468E034B_assign.body
}



//## Other Operations (implementation)
void Event::bind (reusable::Query& hQuery)
{
  //## begin Event::bind%47288D0D0271.body preserve=yes
   hQuery.bind("CREVCDT","EVCLID",Column::STRING,&m_strEVCLID);
   hQuery.bind("CREVCDT","EVNTTIME",Column::STRING,&m_strEVNTTIME);
   hQuery.bind("CREVCDT","EVNTDAY",Column::STRING,&m_strEVNTDAY);
   hQuery.bind("CREVNTT","AUTOREC",Column::STRING,&m_strAUTOREC);
   hQuery.bind("CREVNTT","NETCMD",Column::STRING,&m_strNETCMD);
   hQuery.bind("CREVNTT","PROCID",Column::STRING,&m_strPROCID);
   hQuery.bind("CREVNTT","NETCOPT1",Column::STRING,&m_strNETCOPT1);
   hQuery.bind("CREVNTT","NETCOPT2",Column::STRING,&m_strNETCOPT2);
   hQuery.bind("CREVNTT","NETCOPT3",Column::STRING,&m_strNETCOPT3);
   hQuery.bind("CREVNTT","NETCOPT4",Column::STRING,&m_strNETCOPT4);
   hQuery.bind("CREVNTT","NETCOPT5",Column::STRING,&m_strNETCOPT5);
   hQuery.bind("CREVNTT","NETCOPT6",Column::STRING,&m_strNETCOPT6);
   hQuery.bind("CREVNTT","NETCOPT7",Column::STRING,&m_strNETCOPT7);
   hQuery.bind("CREVNTT","NETCOPT8",Column::STRING,&m_strNETCOPT8);
  //## end Event::bind%47288D0D0271.body
}

void Event::bind2 (reusable::Query& hQuery)
{
  //## begin Event::bind2%4728D9DE00CB.body preserve=yes
   hQuery.bind("EVENT_CNTL","TSTAMP_NEXT",Column::STRING,&m_strTSTAMP_NEXT[0],0,"MIN");
   hQuery.bind("EVENT_CNTL","COMMAND",Column::STRING,&m_strCOMMAND);
  //## end Event::bind2%4728D9DE00CB.body
}

bool Event::execute ()
{
  //## begin Event::execute%47289E2E0280.body preserve=yes
   UseCase hUseCase("FD","## EV01 PROCESS EVENT");
   if (m_strNETCMD == "SYSTEM")
   {
      string strCommand(m_strPROCID);
      strCommand.resize(8,' ');
      strCommand.append(m_strNETCOPT1);
      strCommand.resize(16,' ');
      strCommand.append(m_strNETCOPT2);
      strCommand.resize(24,' ');
      strCommand.append(m_strNETCOPT3);
      strCommand.resize(32,' ');
      strCommand.append(m_strNETCOPT4);
      strCommand.resize(40,' ');
      strCommand.append(m_strNETCOPT5);
      strCommand.resize(48,' ');
      strCommand.append(m_strNETCOPT6);
      strCommand.resize(56,' ');
      strCommand.append(m_strNETCOPT7);
      strCommand.resize(64,' ');
      strCommand.append(m_strNETCOPT8);
      strCommand.resize(72,' ');
      int iResult = system(strCommand.c_str());
      hUseCase.setSuccess((iResult == 0) ? true: false);
   }
   else
   {
      string strData2(m_strNETCOPT1);
      strData2.resize(8,' ');
      strData2 += m_strNETCOPT2;
      strData2.resize(16,' ');
      strData2 += m_strNETCOPT3;
      strData2.resize(24,' ');
      string strQueueName(m_strPROCID);
      if (m_strNETCMD == "START")
         IF::Extract::instance()->getAddressSpace(m_strPROCID,strQueueName);
      size_t pos;
      if (((pos = strData2.find("DATE+")) != string::npos
         || (pos = strData2.find("DATE-")) != string::npos)
         && strData2.length() > pos + 4)
      {
         Date hDate(Date::today());
         if (strData2[pos + 4] == '+')
            hDate += atoi(strData2.substr(pos + 5).c_str());
         else
            hDate -= atoi(strData2.substr(pos + 5).c_str());
         strData2.erase(pos);
         strData2.append(hDate.asString("%Y%m%d"));
      }
      CommandMessage hCommandMessage(m_strNETCMD, strData2);
      hUseCase.setSuccess(hCommandMessage.execute(strQueueName.c_str()));
   }
   if (hUseCase.getSuccess())
      m_strTSTAMP_NEXT[1] = Clock::instance()->getYYYYMMDDHHMMSSHN(true);
   return hUseCase.getSuccess();
  //## end Event::execute%47289E2E0280.body
}

bool Event::recover ()
{
  //## begin Event::recover%4728DADE01E4.body preserve=yes
   m_strCOMMAND.resize(80,' ');
   m_strNETCMD.assign(m_strCOMMAND.data(),8);
   m_strPROCID.assign(m_strCOMMAND.data() + 8,8);
   m_strNETCOPT1.assign(m_strCOMMAND.data() + 16,8);
   m_strNETCOPT2.assign(m_strCOMMAND.data() + 24,8);
   m_strNETCOPT3.assign(m_strCOMMAND.data() + 32,8);
   m_strNETCOPT4.assign(m_strCOMMAND.data() + 40,8);
   m_strNETCOPT5.assign(m_strCOMMAND.data() + 48,8);
   m_strNETCOPT6.assign(m_strCOMMAND.data() + 56,8);
   m_strNETCOPT7.assign(m_strCOMMAND.data() + 64,8);
   m_strNETCOPT8.assign(m_strCOMMAND.data() + 72,8);
   return execute();
  //## end Event::recover%4728DADE01E4.body
}

bool Event::reschedule ()
{
  //## begin Event::reschedule%5BA8FA1D033B.body preserve=yes
   UseCase hUseCase("FD","## EV01 RESCHEDULE EVENT");
   string strTemp(m_strTSTAMP_NEXT[0]);
   Table hTable("EVENT_CNTL");
   set(hTable);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if (!pUpdateStatement->execute(hTable))
   {
      m_strTSTAMP_NEXT[0] = strTemp;
      Database::instance()->rollback();
      return UseCase::setSuccess(false);
   }
   Database::instance()->commit();
   return true;
  //## end Event::reschedule%5BA8FA1D033B.body
}

bool Event::schedule ()
{
  //## begin Event::schedule%3DE27BF702AF.body preserve=yes
   UseCase hUseCase("FD","## EV01 SCHEDULE EVENT");
   Table hTable("EVENT_CNTL");
   set(hTable);
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   return UseCase::setSuccess(pInsertStatement->execute(hTable));
  //## end Event::schedule%3DE27BF702AF.body
}

void Event::set (reusable::Table& hTable)
{
  //## begin Event::set%5BA8EA9A00B6.body preserve=yes
   Date hDate(Date::today());
   if (m_strEVNTTIME < Clock::instance()->getTime())
      hDate += 1;
   if (m_strEVNTDAY != "E")
   {
      int iEVNTDAY = atoi(m_strEVNTDAY.c_str());
      int iDay = atoi(hDate.asString("%w").c_str());
      hDate += (iDay <= iEVNTDAY) ? (iEVNTDAY - iDay) : (iEVNTDAY - iDay) + 7;
   }
   m_strTSTAMP_NEXT[0] = hDate.asString("%Y%m%d");
   m_strTSTAMP_NEXT[0] += m_strEVNTTIME;
   hTable.setQualifier("QUALIFY");
   hTable.set("EVCLID",m_strEVCLID,false,true);
   hTable.set("TSTAMP_NEXT",m_strTSTAMP_NEXT[0]);
   hTable.set("AUTO_RECOVERY_FLG",m_strAUTOREC);
   m_strCOMMAND = m_strNETCMD;
   m_strCOMMAND.resize(8,' ');
   m_strCOMMAND.append(m_strPROCID);
   m_strCOMMAND.resize(16,' ');
   m_strCOMMAND.append(m_strNETCOPT1);
   m_strCOMMAND.resize(24,' ');
   m_strCOMMAND.append(m_strNETCOPT2);
   m_strCOMMAND.resize(32,' ');
   m_strCOMMAND.append(m_strNETCOPT3);
   m_strCOMMAND.resize(40,' ');
   m_strCOMMAND.append(m_strNETCOPT4);
   m_strCOMMAND.resize(48,' ');
   m_strCOMMAND.append(m_strNETCOPT5);
   m_strCOMMAND.resize(56,' ');
   m_strCOMMAND.append(m_strNETCOPT6);
   m_strCOMMAND.resize(64,' ');
   m_strCOMMAND.append(m_strNETCOPT7);
   m_strCOMMAND.resize(72,' ');
   m_strCOMMAND.append(m_strNETCOPT8);
   m_strCOMMAND.resize(80,' ');
   hTable.set("COMMAND",m_strCOMMAND);
  //## end Event::set%5BA8EA9A00B6.body
}

// Additional Declarations
  //## begin Event%3DDE468E034B.declarations preserve=yes
  //## end Event%3DDE468E034B.declarations

//## begin module%3DDE459C00DA.epilog preserve=yes
//## end module%3DDE459C00DA.epilog
