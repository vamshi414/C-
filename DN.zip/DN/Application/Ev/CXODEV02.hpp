//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%47288B3F030D.cm preserve=no
//	$Date:   Jul 13 2018 07:11:50  $ $Author:   e5558744  $ $Revision:   1.1  $
//## end module%47288B3F030D.cm

//## begin module%47288B3F030D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%47288B3F030D.cp

//## Module: CXOSEV02%47288B3F030D; Package specification
//## Subsystem: EV%3DDE417A02EE
//## Source file: D:\V02.9A.R007\ConnexPlatform\Server\Application\Ev\CXODEV02.hpp

#ifndef CXOSEV02_h
#define CXOSEV02_h 1

//## begin module%47288B3F030D.additionalIncludes preserve=no
//## end module%47288B3F030D.additionalIncludes

//## begin module%47288B3F030D.includes preserve=yes
//## end module%47288B3F030D.includes

#ifndef CXOSDB43_h
#include "CXODDB43.hpp"
#endif
#ifndef CXOSEV01_h
#include "CXODEV01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MinuteTimer;
} // namespace timer

namespace database {
class Database;

} // namespace database

//## begin module%47288B3F030D.declarations preserve=no
//## end module%47288B3F030D.declarations

//## begin module%47288B3F030D.additionalDeclarations preserve=yes
//## end module%47288B3F030D.additionalDeclarations


//## begin Calendar%47288AFF004E.preface preserve=yes
//## end Calendar%47288AFF004E.preface

//## Class: Calendar%47288AFF004E
//## Category: Connex Application::EventManager_CAT (EV)%3DDE3FFD031C
//## Subsystem: EV%3DDE417A02EE
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%47288F140167;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%47288F150261;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%47288F16035B;reusable::Query { -> F}
//## Uses: <unnamed>%47288F210242;database::Database { -> F}
//## Uses: <unnamed>%47289D050271;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%47289E9A031C;timer::Clock { -> F}
//## Uses: <unnamed>%4728A38201B5;IF::Trace { -> F}
//## Uses: <unnamed>%4728E38C007D;monitor::UseCase { -> F}

class DllExport Calendar : public database::Cache  //## Inherits: <unnamed>%5B2CBC6B0225
{
  //## begin Calendar%47288AFF004E.initialDeclarations preserve=yes
  //## end Calendar%47288AFF004E.initialDeclarations

  public:
    //## Constructors (generated)
      Calendar();

    //## Destructor (generated)
      virtual ~Calendar();


    //## Other Operations (specified)
      //## Operation: load%47288C920186
      bool load ();

      //## Operation: process%47289D3E038A
      void process ();

      //## Operation: update%47288B9703D8
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin Calendar%47288AFF004E.public preserve=yes
      //## end Calendar%47288AFF004E.public

  protected:
    // Additional Protected Declarations
      //## begin Calendar%47288AFF004E.protected preserve=yes
      //## end Calendar%47288AFF004E.protected

  private:
    // Additional Private Declarations
      //## begin Calendar%47288AFF004E.private preserve=yes
      //## end Calendar%47288AFF004E.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Application::EventManager_CAT (EV)::<unnamed>%47288C2400BB
      //## Role: Calendar::<m_hEvents>%47288C25003E
      //## Qualifier: Name%47288C4F037A; string
      //## begin Calendar::<m_hEvents>%47288C25003E.role preserve=no  public: Event { -> VHgN}
      map<string, Event, less<string> > m_hEvents;
      //## end Calendar::<m_hEvents>%47288C25003E.role

      //## Association: Connex Application::EventManager_CAT (EV)::<unnamed>%47288E0103C8
      //## Role: Calendar::<m_hEvent>%47288E020242
      //## begin Calendar::<m_hEvent>%47288E020242.role preserve=no  public: Event { -> VFHgN}
      Event m_hEvent;
      //## end Calendar::<m_hEvent>%47288E020242.role

    // Additional Implementation Declarations
      //## begin Calendar%47288AFF004E.implementation preserve=yes
      //## end Calendar%47288AFF004E.implementation

};

//## begin Calendar%47288AFF004E.postscript preserve=yes
//## end Calendar%47288AFF004E.postscript

//## begin module%47288B3F030D.epilog preserve=yes
//## end module%47288B3F030D.epilog


#endif
