//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%47288B43036B.cm preserve=no
//   $Date:   May 13 2020 12:17:08  $ $Author:   e1009510  $ $Revision:   1.11  $
//## end module%47288B43036B.cm

//## begin module%47288B43036B.cp preserve=no
//   Copyright (c) 1997 - 2012
//   FIS
//## end module%47288B43036B.cp

//## Module: CXOSEV02%47288B43036B; Package body
//## Subsystem: EV%3DDE417A02EE
//## Source file: D:\V02.9A.R007\ConnexPlatform\Server\Application\Ev\CXOSEV02.cpp

//## begin module%47288B43036B.additionalIncludes preserve=no
//## end module%47288B43036B.additionalIncludes

//## begin module%47288B43036B.includes preserve=yes
//## end module%47288B43036B.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSEV01_h
#include "CXODEV01.hpp"
#endif
#ifndef CXOSEV02_h
#include "CXODEV02.hpp"
#endif


//## begin module%47288B43036B.declarations preserve=no
//## end module%47288B43036B.declarations

//## begin module%47288B43036B.additionalDeclarations preserve=yes
//## end module%47288B43036B.additionalDeclarations


// Class Calendar

Calendar::Calendar()
  //## begin Calendar::Calendar%47288AFF004E_const.hasinit preserve=no
  //## end Calendar::Calendar%47288AFF004E_const.hasinit
  //## begin Calendar::Calendar%47288AFF004E_const.initialization preserve=yes
  //## end Calendar::Calendar%47288AFF004E_const.initialization
{
  //## begin Calendar::Calendar%47288AFF004E_const.body preserve=yes
   memcpy(m_sID,"EV02",4);
   MinuteTimer::instance()->attach(this);
  //## end Calendar::Calendar%47288AFF004E_const.body
}


Calendar::~Calendar()
{
  //## begin Calendar::~Calendar%47288AFF004E_dest.body preserve=yes
   MinuteTimer::instance()->detach(this);
  //## end Calendar::~Calendar%47288AFF004E_dest.body
}



//## Other Operations (implementation)
bool Calendar::load ()
{
  //## begin Calendar::load%47288C920186.body preserve=yes
   UseCase hUseCase("FD","## EV02 LOAD EVENTS");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   for (;;)
   {
      Query hQuery;
      hQuery.setQualifier("QUALIFY","EVENT_CNTL");
      m_hEvent.bind2(hQuery);
      hQuery.setBasicPredicate("EVENT_CNTL","AUTO_RECOVERY_FLG","=","Y");
      hQuery.setBasicPredicate("EVENT_CNTL","TSTAMP_NEXT","<",Clock::instance()->getYYYYMMDDHHMMSSHN().c_str());
      hQuery.setGroupByClause("COMMAND");
      hQuery.setOrderByClause("TSTAMP_NEXT DESC");
      if (!pSelectStatement->execute(hQuery))
         return UseCase::setSuccess(false);
      if (pSelectStatement->getRows() == 0)
         break;
      if (!m_hEvent.recover())
         return UseCase::setSuccess(false);
      hQuery.reset();
      hQuery.setQualifier("QUALIFY","EVENT_CNTL");
      string strCOMMAND(m_hEvent.getCOMMAND());
      rtrim(strCOMMAND);
      hQuery.setBasicPredicate("EVENT_CNTL","COMMAND","=",strCOMMAND.c_str());
      auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
      if (!pDeleteStatement->execute(hQuery))
         return UseCase::setSuccess(false);
      Database::instance()->commit();
   }
   {
      Query hQuery;
      hQuery.setQualifier("QUALIFY","EVENT_CNTL");
      auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
      if (!pDeleteStatement->execute(hQuery))
         return UseCase::setSuccess(false);
      Database::instance()->commit();
   }
   m_hEvents.erase(m_hEvents.begin(),m_hEvents.end());
   Query hQuery;
   hQuery.attach(this);
   hQuery.setQualifier("QUALIFY","CREVCDT");
   hQuery.setQualifier("QUALIFY","CREVNTT");
   hQuery.join("CREVCDT","INNER","CREVNTT","EVCLID");
   m_hEvent.bind(hQuery);
   hQuery.setBasicPredicate("CREVNTT","NETCMD","<>"," ");
   hQuery.setBasicPredicate("CREVNTT","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("CREVNTT","CC_STATE","=","A");
   hQuery.setOrderByClause("EVCLID,EVNTDAY,EVNTTIME");
   if (pSelectStatement->execute(hQuery) == false
      || hQuery.getAbort())
      return UseCase::setSuccess(false);
   Database::instance()->commit();
   return true;
  //## end Calendar::load%47288C920186.body
}

void Calendar::process ()
{
  //## begin Calendar::process%47289D3E038A.body preserve=yes
   map<string,Event,less<string> >::iterator p;
   for (p = m_hEvents.begin();p != m_hEvents.end();++p)
      if (Clock::instance()->getYYYYMMDDHHMMSSHN(true) > (*p).second.getTSTAMP_NEXT(0))
      {
         if (((*p).second.getTSTAMP_NEXT(0)) > ((*p).second.getTSTAMP_NEXT(1)))
         {
            if ((*p).second.execute())
               ((*p).second.reschedule());
         }
         else
            ((*p).second.reschedule());
      }
  //## end Calendar::process%47289D3E038A.body
}

void Calendar::update (Subject* pSubject)
{
  //## begin Calendar::update%47288B9703D8.body preserve=yes
   if (pSubject == MinuteTimer::instance())
   {
      process();
      return;
   }
   string strFirst(m_hEvent.getEVCLID());
   strFirst.resize(8,' ');
   strFirst += m_hEvent.getEVNTDAY();
   strFirst += m_hEvent.getEVNTTIME();
   strFirst += m_hEvent.getNETCMD();
   strFirst += m_hEvent.getNETCOPT1();
   char szEVCLID[PERCENTD];
   snprintf(szEVCLID,sizeof(szEVCLID),"%d",m_hEvents.size());
   m_hEvent.setEVCLID(szEVCLID);
   if (!m_hEvent.schedule())
   {
      ((Query*)pSubject)->setAbort(true);
      return;
   }
   m_hEvents.insert(map<string,Event,less<string> >::value_type(strFirst,m_hEvent));
  //## end Calendar::update%47288B9703D8.body
}

// Additional Declarations
  //## begin Calendar%47288AFF004E.declarations preserve=yes
  //## end Calendar%47288AFF004E.declarations

//## begin module%47288B43036B.epilog preserve=yes
//## end module%47288B43036B.epilog
