//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%370F71610162.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%370F71610162.cm

//## begin module%370F71610162.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%370F71610162.cp

//## Module: CXOSJM03%370F71610162; Package body
//## Subsystem: JM%370F6722014C
//## Source file: C:\Pvcswork\Dn\Server\Application\Jm\CXOSJM03.cpp

//## begin module%370F71610162.additionalIncludes preserve=no
//## end module%370F71610162.additionalIncludes

//## begin module%370F71610162.includes preserve=yes
// $Date:   Apr 07 2004 15:15:32  $ $Author:   D98833  $ $Revision:   1.3  $
//## end module%370F71610162.includes

#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSJM03_h
#include "CXODJM03.hpp"
#endif


//## begin module%370F71610162.declarations preserve=no
//## end module%370F71610162.declarations

//## begin module%370F71610162.additionalDeclarations preserve=yes
//## end module%370F71610162.additionalDeclarations


// Class LogUnload 

LogUnload::LogUnload()
  //## begin LogUnload::LogUnload%370F70C502D0_const.hasinit preserve=no
  //## end LogUnload::LogUnload%370F70C502D0_const.hasinit
  //## begin LogUnload::LogUnload%370F70C502D0_const.initialization preserve=yes
  //## end LogUnload::LogUnload%370F70C502D0_const.initialization
{
  //## begin LogUnload::LogUnload%370F70C502D0_const.body preserve=yes
   memcpy(m_sID,"JM03",4);
  //## end LogUnload::LogUnload%370F70C502D0_const.body
}

LogUnload::LogUnload (const string& strName)
  //## begin LogUnload::LogUnload%37177354029C.hasinit preserve=no
  //## end LogUnload::LogUnload%37177354029C.hasinit
  //## begin LogUnload::LogUnload%37177354029C.initialization preserve=yes
   : BatchJob(strName)
  //## end LogUnload::LogUnload%37177354029C.initialization
{
  //## begin LogUnload::LogUnload%37177354029C.body preserve=yes
   memcpy(m_sID,"JM03",4);
  //## end LogUnload::LogUnload%37177354029C.body
}


LogUnload::~LogUnload()
{
  //## begin LogUnload::~LogUnload%370F70C502D0_dest.body preserve=yes
  //## end LogUnload::~LogUnload%370F70C502D0_dest.body
}



//## Other Operations (implementation)
void LogUnload::submit ()
{
  //## begin LogUnload::submit%370F726A027B.body preserve=yes
   Job::submit(m_strName.c_str());
  //## end LogUnload::submit%370F726A027B.body
}

// Additional Declarations
  //## begin LogUnload%370F70C502D0.declarations preserve=yes
  //## end LogUnload%370F70C502D0.declarations

//## begin module%370F71610162.epilog preserve=yes
//## end module%370F71610162.epilog
