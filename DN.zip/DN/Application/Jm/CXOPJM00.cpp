//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%370F675002CF.cm preserve=no
// $Date:   Sep 12 2008 15:42:54  $ $Author:   D02405  $ $Revision:   1.7  $
//## end module%370F675002CF.cm

//## begin module%370F675002CF.cp preserve=no
// Copyright (c) 1998 - 2005
// eFunds Corporation
//## end module%370F675002CF.cp

//## Module: CXOPJM00%370F675002CF; Package body
//## Subsystem: JM%370F6722014C
//## Source file: C:\Devel\ConnexPlatform\Server\Application\Jm\CXOPJM00.cpp

//## begin module%370F675002CF.additionalIncludes preserve=no
//## end module%370F675002CF.additionalIncludes

//## begin module%370F675002CF.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
//## end module%370F675002CF.includes

#ifndef CXOSJM02_h
#include "CXODJM02.hpp"
#endif
#ifndef CXOSJM03_h
#include "CXODJM03.hpp"
#endif
#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSJM01_h
#include "CXODJM01.hpp"
#endif
#ifndef CXOPJM00_h
#include "CXODJM00.hpp"
#endif


//## begin module%370F675002CF.declarations preserve=no
//## end module%370F675002CF.declarations

//## begin module%370F675002CF.additionalDeclarations preserve=yes

#include "CXODPS06.hpp"
   pApplication = new JobManager();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%370F675002CF.additionalDeclarations


// Class JobManager

JobManager::JobManager()
  //## begin JobManager::JobManager%370F66D7005E_const.hasinit preserve=no
  //## end JobManager::JobManager%370F66D7005E_const.hasinit
  //## begin JobManager::JobManager%370F66D7005E_const.initialization preserve=yes
  //## end JobManager::JobManager%370F66D7005E_const.initialization
{
  //## begin JobManager::JobManager%370F66D7005E_const.body preserve=yes
   memcpy(m_sID,"JM00",4);
  //## end JobManager::JobManager%370F66D7005E_const.body
}


JobManager::~JobManager()
{
  //## begin JobManager::~JobManager%370F66D7005E_dest.body preserve=yes
   map<string,BatchJob*,less<string> >::iterator pBatchJob;
   for (pBatchJob = m_hBatchJob.begin();pBatchJob != m_hBatchJob.end();++pBatchJob)
      delete (*pBatchJob).second;
   m_hBatchJob.erase(m_hBatchJob.begin(),m_hBatchJob.end());
  //## end JobManager::~JobManager%370F66D7005E_dest.body
}



//## Other Operations (implementation)
int JobManager::initialize ()
{
  //## begin JobManager::initialize%370F75B9011A.body preserve=yes
   new platform::Platform();
   int iRC = Application::initialize();
   UseCase hUseCase("FD","## FD24 START JM");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   Queue::attach("@DUMPER");
   return iRC;
  //## end JobManager::initialize%370F75B9011A.body
}

int JobManager::onMessage (IF::Message& hMessage)
{
  //## begin JobManager::onMessage%3CADAB32031C.body preserve=yes
   if (hMessage.messageID() == "C8002D")
   {
      string strJobName(hMessage.buffer() + 78,8);
      char cType = *(hMessage.buffer() + 60);
      BatchJob* pJob = 0;
      map<string,BatchJob*,less<string> >::iterator pBatchJob = m_hBatchJob.find(strJobName);
      if (pBatchJob == m_hBatchJob.end())
      {
         if (cType == 'L')
            pJob = new LogUnload(strJobName);
         else
         if (cType == 'T')
            pJob = new TracePrint(strJobName);
         m_hBatchJob.insert(map<string,BatchJob *,less<string> >::value_type(strJobName,pJob));
      }
      else
         pJob = (*pBatchJob).second;
      string strImage;
      string strDataSetName;
      if (cType == 'L')
      {
         strImage.assign(hMessage.buffer() + 65,2);
         strDataSetName.assign(hMessage.buffer() + 86,44);
         pJob->addImage(strImage,strDataSetName);
      }
      else
      if (cType == 'T')
      {
         strImage.assign(hMessage.buffer() + 63,2);
         strDataSetName.assign(hMessage.buffer() + 86,44);
         pJob->addImage(strImage,strDataSetName);
      }
   }
   return 0;
  //## end JobManager::onMessage%3CADAB32031C.body
}

// Additional Declarations
  //## begin JobManager%370F66D7005E.declarations preserve=yes
  //## end JobManager%370F66D7005E.declarations

//## begin module%370F675002CF.epilog preserve=yes
//## end module%370F675002CF.epilog
