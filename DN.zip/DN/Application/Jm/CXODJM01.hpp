//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%370F6983027E.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%370F6983027E.cm

//## begin module%370F6983027E.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%370F6983027E.cp

//## Module: CXOSJM01%370F6983027E; Package specification
//## Subsystem: JM%370F6722014C
//## Source file: C:\Devel\ConnexPlatform\Server\Application\Jm\CXODJM01.hpp

#ifndef CXOSJM01_h
#define CXOSJM01_h 1

//## begin module%370F6983027E.additionalIncludes preserve=no
//## end module%370F6983027E.additionalIncludes

//## begin module%370F6983027E.includes preserve=yes
// $Date:   Apr 07 2004 15:15:30  $ $Author:   D98833  $ $Revision:   1.5  $
// $Date:   Apr 07 2004 15:15:30  $ $Author:   D98833  $ $Revision:   1.5  $
#include <map>
//## end module%370F6983027E.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif

//## Modelname: Connex Platform::Reusable_CAT%3453F15C01AA
namespace reusable {
   class CriticalSection;
} // namespace reusable

//## Modelname: Connex Platform::IF_CAT%3451F55F009E
namespace IF {
   class Extract;
   class Console;
   class Trace;

} // namespace IF

//## begin module%370F6983027E.declarations preserve=no
//## end module%370F6983027E.declarations

//## begin module%370F6983027E.additionalDeclarations preserve=yes
//## end module%370F6983027E.additionalDeclarations


//## begin BatchJob%370F68CF0347.preface preserve=yes
//## end BatchJob%370F68CF0347.preface

//## Class: BatchJob%370F68CF0347
//	The BatchJob class is a common base class for jobs
//	submitted by the  JobManager process.
//
//	CXODJM01.hpp
//	CXOSJM01.cpp
//## Category: Connex Platform::JobManager_CAT%370F66980324
//## Subsystem: JM%370F6722014C
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%384FC7F30096;IF::Extract { -> F}
//## Uses: <unnamed>%3860CA980060;IF::Trace { -> F}
//## Uses: <unnamed>%386123010209;IF::Console { -> F}
//## Uses: <unnamed>%3DAABAA4038A;reusable::CriticalSection { -> F}

class BatchJob : public reusable::Observer  //## Inherits: <unnamed>%370F68FE0313
{
  //## begin BatchJob%370F68CF0347.initialDeclarations preserve=yes
  //## end BatchJob%370F68CF0347.initialDeclarations

  public:
    //## Constructors (generated)
      BatchJob();

    //## Constructors (specified)
      //## Operation: BatchJob%371329CE0330
      BatchJob (const string& strName);

    //## Destructor (generated)
      virtual ~BatchJob();


    //## Other Operations (specified)
      //## Operation: addImage%370F734201BD
      //	Maintain a list of the images that have submitted this
      //	job.
      //## Semantics:
      //	1. If the image is already in the collection, submit the
      //	job.
      //	2. Add the image to the collection (the key is the image
      //	name, the data is the dataset name).
      //	3. If this is the first image in the collection, set the
      //	submit timer.
      void addImage (const string& strImage, const string& strDatasetName);

      //## Operation: submit%370F720603B8
      virtual void submit () = 0;

      //## Operation: update%370F7021007B
      //	Callback function that is invoked when the timer elapses.
      //## Semantics:
      //	1. Submit this job.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin BatchJob%370F68CF0347.public preserve=yes
      //## end BatchJob%370F68CF0347.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Name%370F6D9E026B
      //## begin BatchJob::Name%370F6D9E026B.attr preserve=no  private: string {U} 
      string m_strName;
      //## end BatchJob::Name%370F6D9E026B.attr

    // Additional Protected Declarations
      //## begin BatchJob%370F68CF0347.protected preserve=yes
      map<string,string,less<string> > m_hImages;
      //## end BatchJob%370F68CF0347.protected
  private:
    // Additional Private Declarations
      //## begin BatchJob%370F68CF0347.private preserve=yes
      //## end BatchJob%370F68CF0347.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Platform::JobManager_CAT::<unnamed>%3713379A0311
      //## Role: BatchJob::<m_hTimer>%3713379B0312
      //## begin BatchJob::<m_hTimer>%3713379B0312.role preserve=no  public: timer::Timer { -> VHgN}
      timer::Timer m_hTimer;
      //## end BatchJob::<m_hTimer>%3713379B0312.role

    // Additional Implementation Declarations
      //## begin BatchJob%370F68CF0347.implementation preserve=yes
      //## end BatchJob%370F68CF0347.implementation

};

//## begin BatchJob%370F68CF0347.postscript preserve=yes
//## end BatchJob%370F68CF0347.postscript

//## begin module%370F6983027E.epilog preserve=yes
//## end module%370F6983027E.epilog


#endif
