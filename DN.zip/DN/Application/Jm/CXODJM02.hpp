//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%370F710E0375.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%370F710E0375.cm

//## begin module%370F710E0375.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%370F710E0375.cp

//## Module: CXOSJM02%370F710E0375; Package specification
//## Subsystem: JM%370F6722014C
//## Source file: C:\Pvcswork\Dn\Server\Application\Jm\CXODJM02.hpp

#ifndef CXOSJM02_h
#define CXOSJM02_h 1

//## begin module%370F710E0375.additionalIncludes preserve=no
//## end module%370F710E0375.additionalIncludes

//## begin module%370F710E0375.includes preserve=yes
// $Date:   Apr 07 2004 15:15:30  $ $Author:   D98833  $ $Revision:   1.3  $
//## end module%370F710E0375.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSJM01_h
#include "CXODJM01.hpp"
#endif

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Memory;

} // namespace IF

//## begin module%370F710E0375.declarations preserve=no
//## end module%370F710E0375.declarations

//## begin module%370F710E0375.additionalDeclarations preserve=yes
//## end module%370F710E0375.additionalDeclarations


//## begin TracePrint%370F709403CA.preface preserve=yes
//## end TracePrint%370F709403CA.preface

//## Class: TracePrint%370F709403CA
//	The TracePrint class generates the job stream that
//	prints the trace files produced by each Connex image.
//
//	CXODJM02.hpp
//	CXOSJM02.cpp
//## Category: Connex Foundation::JobManager_CAT%370F66980324
//## Subsystem: JM%370F6722014C
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%384FCF8D0170;IF::Extract { -> F}

class TracePrint : public BatchJob  //## Inherits: <unnamed>%370F70A20095
{
  //## begin TracePrint%370F709403CA.initialDeclarations preserve=yes
  //## end TracePrint%370F709403CA.initialDeclarations

  public:
    //## Constructors (generated)
      TracePrint();

    //## Constructors (specified)
      //## Operation: TracePrint%371773340340
      TracePrint (const string& strName);

    //## Destructor (generated)
      virtual ~TracePrint();


    //## Other Operations (specified)
      //## Operation: submit%370F7241034E
      //	Submit the trace print job.
      virtual void submit ();

    // Additional Public Declarations
      //## begin TracePrint%370F709403CA.public preserve=yes
      //## end TracePrint%370F709403CA.public

  protected:
    // Additional Protected Declarations
      //## begin TracePrint%370F709403CA.protected preserve=yes
      //## end TracePrint%370F709403CA.protected

  private:

    //## Other Operations (specified)
      //## Operation: writeRecord%38623EF502BA
      void writeRecord (const string& strLine);

    // Additional Private Declarations
      //## begin TracePrint%370F709403CA.private preserve=yes
      //## end TracePrint%370F709403CA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: TraceRecords%385A51390124
      //## begin TracePrint::TraceRecords%385A51390124.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hTraceRecords;
      //## end TracePrint::TraceRecords%385A51390124.attr

    // Data Members for Associations

      //## Association: Connex Foundation::JobManager_CAT::<unnamed>%386243C801CF
      //## Role: TracePrint::<m_hFlatFile>%386243C90090
      //## begin TracePrint::<m_hFlatFile>%386243C90090.role preserve=no  public: IF::FlatFile { -> VHgN}
      IF::FlatFile m_hFlatFile;
      //## end TracePrint::<m_hFlatFile>%386243C90090.role

      //## Association: Connex Foundation::JobManager_CAT::<unnamed>%386270570254
      //## Role: TracePrint::<m_pMemory>%38627058036E
      //## begin TracePrint::<m_pMemory>%38627058036E.role preserve=no  public: IF::Memory { -> RFHgN}
      IF::Memory *m_pMemory;
      //## end TracePrint::<m_pMemory>%38627058036E.role

    // Additional Implementation Declarations
      //## begin TracePrint%370F709403CA.implementation preserve=yes
      //## end TracePrint%370F709403CA.implementation

};

//## begin TracePrint%370F709403CA.postscript preserve=yes
//## end TracePrint%370F709403CA.postscript

//## begin module%370F710E0375.epilog preserve=yes
//## end module%370F710E0375.epilog


#endif
