//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%370F711003AA.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%370F711003AA.cm

//## begin module%370F711003AA.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%370F711003AA.cp

//## Module: CXOSJM02%370F711003AA; Package body
//## Subsystem: JM%370F6722014C
//## Source file: C:\Pvcswork\Dn\Server\Application\Jm\CXOSJM02.cpp

//## begin module%370F711003AA.additionalIncludes preserve=no
//## end module%370F711003AA.additionalIncludes

//## begin module%370F711003AA.includes preserve=yes
// $Date:   May 13 2020 12:24:44  $ $Author:   e1009510  $ $Revision:   1.6  $
#include "CXODRU24.hpp"
//## end module%370F711003AA.includes

#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSJM02_h
#include "CXODJM02.hpp"
#endif


//## begin module%370F711003AA.declarations preserve=no
//## end module%370F711003AA.declarations

//## begin module%370F711003AA.additionalDeclarations preserve=yes
//## end module%370F711003AA.additionalDeclarations


// Class TracePrint 




TracePrint::TracePrint()
  //## begin TracePrint::TracePrint%370F709403CA_const.hasinit preserve=no
  //## end TracePrint::TracePrint%370F709403CA_const.hasinit
  //## begin TracePrint::TracePrint%370F709403CA_const.initialization preserve=yes
  : m_hFlatFile("INTRDR")
  //## end TracePrint::TracePrint%370F709403CA_const.initialization
{
  //## begin TracePrint::TracePrint%370F709403CA_const.body preserve=yes
   memcpy(m_sID,"JM02",4);
  //## end TracePrint::TracePrint%370F709403CA_const.body
}

TracePrint::TracePrint (const string& strName)
  //## begin TracePrint::TracePrint%371773340340.hasinit preserve=no
  //## end TracePrint::TracePrint%371773340340.hasinit
  //## begin TracePrint::TracePrint%371773340340.initialization preserve=yes
   : BatchJob(strName)
   ,m_hFlatFile("INTRDR")
  //## end TracePrint::TracePrint%371773340340.initialization
{
  //## begin TracePrint::TracePrint%371773340340.body preserve=yes
   memcpy(m_sID,"JM02",4);
   m_pMemory = new Memory(80);
  //## end TracePrint::TracePrint%371773340340.body
}


TracePrint::~TracePrint()
{
  //## begin TracePrint::~TracePrint%370F709403CA_dest.body preserve=yes
   delete m_pMemory;
  //## end TracePrint::~TracePrint%370F709403CA_dest.body
}



//## Other Operations (implementation)
void TracePrint::submit ()
{
  //## begin TracePrint::submit%370F7241034E.body preserve=yes
   int pos1, pos2, pos3, pos4, pos5;
   size_t lRecordLength;
   FlatFile hInputFile("JCL","TRACE");
   while (hInputFile.read((char*)*m_pMemory,80,&lRecordLength))
      m_hTraceRecords.push_back(string((char*)*m_pMemory,lRecordLength));
   string strLine;
   // replace substitutions and write to the output file
   vector<string>::const_iterator pString, pTempString;
   for (pString = m_hTraceRecords.begin();pString != m_hTraceRecords.end();++pString)
   {
      pTempString = pString;
      strLine = *pString;
      pos1 = pString->find("IN@@");
      pos2 = pString->find("&&FILE@@");
      pos3 = pString->find("OUT@@");
      if ((pos1 != string::npos) 
         || (pos2 != string::npos) 
         || (pos3 != string::npos))
      {
         map<string,string,less<string> >::iterator pImage;
         for (pImage = m_hImages.begin();pImage != m_hImages.end();++pImage)
         {
            pString = pTempString;
            strLine = *pString;
            if (pos1 != string::npos)
               strLine.replace(pos1+2, 2, (*pImage).first);
            if (pos3 != string::npos)
               strLine.replace(pos3+3, 2, (*pImage).first);
            if (pos2 != string::npos) 
               strLine.replace(pos2+6,2,(*pImage).first);
            if ((pImage != m_hImages.begin()) &&  (pos5 = pString->find("SORTIN") != string::npos))
            {
               pos5 = pString->find("DD ");
               for (int x(2); x < pos5; ++x)
                  strLine.replace(x, 1, " ");
            }
            writeRecord(strLine);
            for (++pString; pString != m_hTraceRecords.end();++pString)
            {
               strLine = *pString;
               if ((pos4 = pString->find("// ")) != string::npos) 
               {
                  if ((pos4 = pString->find("&&DSN")) != string::npos)
                     strLine.replace(pos4,6,(*pImage).second);
                  writeRecord(strLine);
               }
               else
                  break;
            }
            pString--;
         }
      }
      else
         writeRecord(strLine);
   }
   m_hFlatFile.close();
   m_hTraceRecords.erase(m_hTraceRecords.begin(), m_hTraceRecords.end());
   BatchJob::submit();
   // close the JCL file last ... releases the ENQ that serializes access to JCL and INTRDR
   hInputFile.close();
  //## end TracePrint::submit%370F7241034E.body
}

void TracePrint::writeRecord (const string& strLine)
{
  //## begin TracePrint::writeRecord%38623EF502BA.body preserve=yes
   memset((char*)*m_pMemory,' ',80);
   if (strLine.length() < 80)
      memcpy((char*)*m_pMemory,strLine.data(),strLine.length());
   else
      memcpy((char*)*m_pMemory,strLine.data(),80);
   m_hFlatFile.write((char*)*m_pMemory,80);
  //## end TracePrint::writeRecord%38623EF502BA.body
}

// Additional Declarations
  //## begin TracePrint%370F709403CA.declarations preserve=yes
  //## end TracePrint%370F709403CA.declarations

//## begin module%370F711003AA.epilog preserve=yes
//## end module%370F711003AA.epilog
