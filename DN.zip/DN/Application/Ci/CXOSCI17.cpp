//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A7C52EA0087.cm preserve=no
//	$Date:   Jun 22 2017 08:03:50  $ $Author:   e1009839  $ $Revision:   1.6  $
//## end module%3A7C52EA0087.cm

//## begin module%3A7C52EA0087.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A7C52EA0087.cp

//## Module: CXOSCI17%3A7C52EA0087; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI17.cpp

//## begin module%3A7C52EA0087.additionalIncludes preserve=no
//## end module%3A7C52EA0087.additionalIncludes

//## begin module%3A7C52EA0087.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%3A7C52EA0087.includes

#ifndef CXOSCI17_h
#include "CXODCI17.hpp"
#endif
//## begin module%3A7C52EA0087.declarations preserve=no
//## end module%3A7C52EA0087.declarations

//## begin module%3A7C52EA0087.additionalDeclarations preserve=yes
#include "CXODRU32.hpp"
struct sTrace
{
   char sText[65];
   short int iNull0;
};
#include "CXODRU33.hpp"
//## end module%3A7C52EA0087.additionalDeclarations


// Class ClientDisplayTrace 

ClientDisplayTrace::ClientDisplayTrace()
  //## begin ClientDisplayTrace::ClientDisplayTrace%3A7C513E01FE_const.hasinit preserve=no
      : m_psDescription(0)
  //## end ClientDisplayTrace::ClientDisplayTrace%3A7C513E01FE_const.hasinit
  //## begin ClientDisplayTrace::ClientDisplayTrace%3A7C513E01FE_const.initialization preserve=yes
  //## end ClientDisplayTrace::ClientDisplayTrace%3A7C513E01FE_const.initialization
{
  //## begin ClientDisplayTrace::ClientDisplayTrace%3A7C513E01FE_const.body preserve=yes
   memcpy(m_sID,"CI17",4);
#include "CXODRU32.hpp"
   struct hDescription
   {
      char sColumnName[18];
      short int nDataType;
      int nPrecision;
      short int nScale;
   };
#include "CXODRU33.hpp"
   int j = 1;
   char* pszColumnName[1] = {"TEXT"};
   int nPrecision[1] = {65};
   int k = 4 + (j * sizeof(struct hDescription));
   m_psDescription = new char[k];
   memset(m_psDescription,' ',k);
   memcpy(m_psDescription,&j,sizeof(int));
   hDescription* p = (hDescription*)(m_psDescription + 4);
   for (int i = 0;i < j;++i)
   {
      memcpy(p->sColumnName,pszColumnName[i],strlen(pszColumnName[i]));
      p->nDataType = htons(1);
      p->nPrecision = htonl(nPrecision[i]);
      p->nScale = htons(0);
      ++p;
   }
  //## end ClientDisplayTrace::ClientDisplayTrace%3A7C513E01FE_const.body
}


ClientDisplayTrace::~ClientDisplayTrace()
{
  //## begin ClientDisplayTrace::~ClientDisplayTrace%3A7C513E01FE_dest.body preserve=yes
   m_hResultSet.close();
   delete [] m_psDescription;
  //## end ClientDisplayTrace::~ClientDisplayTrace%3A7C513E01FE_dest.body
}



//## Other Operations (implementation)
void ClientDisplayTrace::visitTrace (string* pText)
{
  //## begin ClientDisplayTrace::visitTrace%3A7C515703D1.body preserve=yes
   struct sTrace hTrace;
   memset((char*)&hTrace,' ',sizeof(struct sTrace));
   memcpy(hTrace.sText,pText->data(),pText->length());
   m_hResultSet.addRow(m_psDescription,(char*)&hTrace);
  //## end ClientDisplayTrace::visitTrace%3A7C515703D1.body
}

// Additional Declarations
  //## begin ClientDisplayTrace%3A7C513E01FE.declarations preserve=yes
  //## end ClientDisplayTrace%3A7C513E01FE.declarations

//## begin module%3A7C52EA0087.epilog preserve=yes
//## end module%3A7C52EA0087.epilog

