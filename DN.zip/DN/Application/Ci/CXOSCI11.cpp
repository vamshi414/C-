//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A608AF00088.cm preserve=no
//	$Date:   Jun 26 2017 07:46:44  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3A608AF00088.cm

//## begin module%3A608AF00088.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A608AF00088.cp

//## Module: CXOSCI11%3A608AF00088; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI11.cpp

//## begin module%3A608AF00088.additionalIncludes preserve=no
//## end module%3A608AF00088.additionalIncludes

//## begin module%3A608AF00088.includes preserve=yes
//## end module%3A608AF00088.includes

#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSCI11_h
#include "CXODCI11.hpp"
#endif


//## begin module%3A608AF00088.declarations preserve=no
//## end module%3A608AF00088.declarations

//## begin module%3A608AF00088.additionalDeclarations preserve=yes
//## end module%3A608AF00088.additionalDeclarations


// Class QueuedRequest 

QueuedRequest::QueuedRequest()
  //## begin QueuedRequest::QueuedRequest%3A608996035B_const.hasinit preserve=no
      : m_dTicks(0)
  //## end QueuedRequest::QueuedRequest%3A608996035B_const.hasinit
  //## begin QueuedRequest::QueuedRequest%3A608996035B_const.initialization preserve=yes
   ,m_hMessage(1024)
  //## end QueuedRequest::QueuedRequest%3A608996035B_const.initialization
{
  //## begin QueuedRequest::QueuedRequest%3A608996035B_const.body preserve=yes
   memcpy(m_sID,"CI11",4);
   m_dTicks = Clock::instance()->getTicks();
   m_strTimestamp = Clock::instance()->getYYYYMMDDHHMMSS();
  //## end QueuedRequest::QueuedRequest%3A608996035B_const.body
}

QueuedRequest::QueuedRequest(const QueuedRequest &right)
  //## begin QueuedRequest::QueuedRequest%3A608996035B_copy.hasinit preserve=no
  //## end QueuedRequest::QueuedRequest%3A608996035B_copy.hasinit
  //## begin QueuedRequest::QueuedRequest%3A608996035B_copy.initialization preserve=yes
  //## end QueuedRequest::QueuedRequest%3A608996035B_copy.initialization
{
  //## begin QueuedRequest::QueuedRequest%3A608996035B_copy.body preserve=yes
   memcpy(m_sID,"CI11",4);
   m_hMessage = right.m_hMessage;
   m_strQueueName = right.m_strQueueName;
   m_strServiceName = right.m_strServiceName;
   m_dTicks = right.m_dTicks;
   m_strTimestamp = right.m_strTimestamp;
   m_strUserID = right.m_strUserID;
  //## end QueuedRequest::QueuedRequest%3A608996035B_copy.body
}


QueuedRequest::~QueuedRequest()
{
  //## begin QueuedRequest::~QueuedRequest%3A608996035B_dest.body preserve=yes
  //## end QueuedRequest::~QueuedRequest%3A608996035B_dest.body
}


QueuedRequest & QueuedRequest::operator=(const QueuedRequest &right)
{
  //## begin QueuedRequest::operator=%3A608996035B_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_hMessage = right.m_hMessage;
   m_strQueueName = right.m_strQueueName;
   m_strServiceName = right.m_strServiceName;
   m_dTicks = right.m_dTicks;
   m_strTimestamp = right.m_strTimestamp;
   m_strUserID = right.m_strUserID;
   return *this;
  //## end QueuedRequest::operator=%3A608996035B_assign.body
}



//## Other Operations (implementation)
void QueuedRequest::accept (ClientInterfaceVisitor& hClientInterfaceVisitor)
{
  //## begin QueuedRequest::accept%3A608BDF0186.body preserve=yes
   hClientInterfaceVisitor.visitQueuedRequest(this);
  //## end QueuedRequest::accept%3A608BDF0186.body
}

int QueuedRequest::getQueueTime ()
{
  //## begin QueuedRequest::getQueueTime%3A6F12BF0108.body preserve=yes
   double d = (Clock::instance()->getTicks() - m_dTicks) / 4294967.296;
   return (int)d;
  //## end QueuedRequest::getQueueTime%3A6F12BF0108.body
}

bool QueuedRequest::send (const char* pszQueue)
{
  //## begin QueuedRequest::send%3A608BC4037C.body preserve=yes
   return (m_hMessage.send(pszQueue) == 0);
  //## end QueuedRequest::send%3A608BC4037C.body
}

// Additional Declarations
  //## begin QueuedRequest%3A608996035B.declarations preserve=yes
  //## end QueuedRequest%3A608996035B.declarations

//## begin module%3A608AF00088.epilog preserve=yes
//## end module%3A608AF00088.epilog
