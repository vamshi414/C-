//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A7C52E80323.cm preserve=no
//	$Date:   Jun 22 2017 07:43:34  $ $Author:   e1009839  $ $Revision:   1.3  $
//## end module%3A7C52E80323.cm

//## begin module%3A7C52E80323.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A7C52E80323.cp

//## Module: CXOSCI17%3A7C52E80323; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI17.hpp

#ifndef CXOSCI17_h
#define CXOSCI17_h 1

//## begin module%3A7C52E80323.additionalIncludes preserve=no
//## end module%3A7C52E80323.additionalIncludes

//## begin module%3A7C52E80323.includes preserve=yes
//## end module%3A7C52E80323.includes

#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSIF37_h
#include "CXODIF37.hpp"
#endif
//## begin module%3A7C52E80323.declarations preserve=no
//## end module%3A7C52E80323.declarations

//## begin module%3A7C52E80323.additionalDeclarations preserve=yes
//## end module%3A7C52E80323.additionalDeclarations


//## begin ClientDisplayTrace%3A7C513E01FE.preface preserve=yes
//## end ClientDisplayTrace%3A7C513E01FE.preface

//## Class: ClientDisplayTrace%3A7C513E01FE
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class ClientDisplayTrace : public ClientInterfaceVisitor  //## Inherits: <unnamed>%3A7C515300E6
{
  //## begin ClientDisplayTrace%3A7C513E01FE.initialDeclarations preserve=yes
  //## end ClientDisplayTrace%3A7C513E01FE.initialDeclarations

  public:
    //## Constructors (generated)
      ClientDisplayTrace();

    //## Destructor (generated)
      virtual ~ClientDisplayTrace();


    //## Other Operations (specified)
      //## Operation: visitTrace%3A7C515703D1
      virtual void visitTrace (string* pText);

    // Additional Public Declarations
      //## begin ClientDisplayTrace%3A7C513E01FE.public preserve=yes
      //## end ClientDisplayTrace%3A7C513E01FE.public

  protected:
    // Additional Protected Declarations
      //## begin ClientDisplayTrace%3A7C513E01FE.protected preserve=yes
      //## end ClientDisplayTrace%3A7C513E01FE.protected

  private:
    // Additional Private Declarations
      //## begin ClientDisplayTrace%3A7C513E01FE.private preserve=yes
      //## end ClientDisplayTrace%3A7C513E01FE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Description%3A7C516B0181
      //## begin ClientDisplayTrace::Description%3A7C516B0181.attr preserve=no  private: char* {U} 0
      char* m_psDescription;
      //## end ClientDisplayTrace::Description%3A7C516B0181.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%3A7C51A0035E
      //## Role: ClientDisplayTrace::<m_hResultSet>%3A7C51A10233
      //## begin ClientDisplayTrace::<m_hResultSet>%3A7C51A10233.role preserve=no  public: IF::ResultSet { -> VHgN}
      IF::ResultSet m_hResultSet;
      //## end ClientDisplayTrace::<m_hResultSet>%3A7C51A10233.role

    // Additional Implementation Declarations
      //## begin ClientDisplayTrace%3A7C513E01FE.implementation preserve=yes
      //## end ClientDisplayTrace%3A7C513E01FE.implementation

};

//## begin ClientDisplayTrace%3A7C513E01FE.postscript preserve=yes
//## end ClientDisplayTrace%3A7C513E01FE.postscript

//## begin module%3A7C52E80323.epilog preserve=yes
//## end module%3A7C52E80323.epilog


#endif
