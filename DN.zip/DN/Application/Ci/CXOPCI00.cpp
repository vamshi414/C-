//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3680026400D4.cm preserve=no
//## end module%3680026400D4.cm

//## begin module%3680026400D4.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3680026400D4.cp

//## Module: CXOPCI00%3680026400D4; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOPCI00.cpp

//## begin module%3680026400D4.additionalIncludes preserve=no
//## end module%3680026400D4.additionalIncludes

//## begin module%3680026400D4.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#ifndef MVS
#include "CXODRU39.hpp"
#endif
#include "CXODBS13.hpp"
#include "CXODUS13.hpp"
#define STS_INVALID_SERVICE_NAME 5
#define STS_INVALID_SEGMENT_SET 7
#define STS_MISSING_LOGON_SEGMENT 8
#define STS_NOT_LOGGED_ON 19
#define STS_ACCESS_SECURITY_UNAVAILABLE 25
#define STS_SYSTEM_IN_SHUTDOWN 29
#define STS_DUPLICATE_QUERY 104
#define STS_DATA_UNAVAILABLE 108
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),POSIX(ON),ENVAR('TASK=CI'))
#endif
//## end module%3680026400D4.includes

#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSCI05_h
#include "CXODCI05.hpp"
#endif
#ifndef CXOSCI06_h
#include "CXODCI06.hpp"
#endif
#ifndef CXOSCI07_h
#include "CXODCI07.hpp"
#endif
#ifndef CXOSCI08_h
#include "CXODCI08.hpp"
#endif
#ifndef CXOSCI10_h
#include "CXODCI10.hpp"
#endif
#ifndef CXOSCI12_h
#include "CXODCI12.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSCI13_h
#include "CXODCI13.hpp"
#endif
#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSCI15_h
#include "CXODCI15.hpp"
#endif
#ifndef CXOSCI16_h
#include "CXODCI16.hpp"
#endif
#ifndef CXOSCI17_h
#include "CXODCI17.hpp"
#endif
#ifndef CXOSUS15_h
#include "CXODUS15.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSCI03_h
#include "CXODCI03.hpp"
#endif
#ifndef CXOSIF37_h
#include "CXODIF37.hpp"
#endif
#ifndef CXOSVS07_h
#include "CXODVS07.hpp"
#endif
#ifndef CXOSRU37_h
#include "CXODRU37.hpp"
#endif
#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF81_h
#include "CXODIF81.hpp"
#endif
#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSDB32_h
#include "CXODDB32.hpp"
#endif
#ifndef CXOSIF48_h
#include "CXODIF48.hpp"
#endif
#ifndef CXOSRU15_h
#include "CXODRU15.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSUS03_h
#include "CXODUS03.hpp"
#endif
#ifndef CXOSBS10_h
#include "CXODBS10.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSUS25_h
#include "CXODUS25.hpp"
#endif
#ifndef CXOSUS23_h
#include "CXODUS23.hpp"
#endif
#ifndef CXOSBS19_h
#include "CXODBS19.hpp"
#endif
#ifndef CXOSCI02_h
#include "CXODCI02.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOSIF39_h
#include "CXODIF39.hpp"
#endif
#ifndef CXOPCI00_h
#include "CXODCI00.hpp"
#endif


//## begin module%3680026400D4.declarations preserve=no
//## end module%3680026400D4.declarations

//## begin module%3680026400D4.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new ClientInterface();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%3680026400D4.additionalDeclarations


// Class ClientInterface 

ClientInterface::ClientInterface()
  //## begin ClientInterface::ClientInterface%34567BA302DE_const.hasinit preserve=no
      : m_bASCII(false),
        m_lHours(0),
        m_pSegmentID(0),
        m_pInformationSegment(0),
        m_pLogonSegment(0),
        m_pMultipleRowContextSegment(0),
        m_pResponseTimeSegment(0),
        m_pKeyExchangeSegment(0),
        m_pAuthenticateSegment(0),
        m_pTextSegment(0),
        m_pConfigurationFile(0)
  //## end ClientInterface::ClientInterface%34567BA302DE_const.hasinit
  //## begin ClientInterface::ClientInterface%34567BA302DE_const.initialization preserve=yes
  //## end ClientInterface::ClientInterface%34567BA302DE_const.initialization
{
  //## begin ClientInterface::ClientInterface%34567BA302DE_const.body preserve=yes
   memcpy(m_sID,"CI00",4);
   m_pSocketQueue[0] = 0;
   m_pSocketQueue[1] = 0;
   m_pSocketSignal[0] = 0;
   m_pSocketSignal[1] = 0;
   MidnightAlarm::instance()->attach(this);
  //## end ClientInterface::ClientInterface%34567BA302DE_const.body
}


ClientInterface::~ClientInterface()
{
  //## begin ClientInterface::~ClientInterface%34567BA302DE_dest.body preserve=yes
   MidnightAlarm::instance()->detach(this);
   delete m_pInformationSegment;
   delete m_pResponseTimeSegment;
   delete m_pMultipleRowContextSegment;
   delete m_pLogonSegment;
   delete m_pAuthenticateSegment;
   delete m_pKeyExchangeSegment;
   delete CommonHeaderSegment::instance();
   delete m_pConfigurationFile;
   delete m_pTextSegment;
   for (int i = 0;i <= 1;++i)
      if (m_pSocketQueue[i])
      {
         m_pSocketQueue[i]->close();
         delete m_pSocketQueue[i];
         delete m_pSocketSignal[i];
      }
  //## end ClientInterface::~ClientInterface%34567BA302DE_dest.body
}



//## Other Operations (implementation)
void ClientInterface::accept (ClientInterfaceVisitor& hClientInterfaceVisitor)
{
  //## begin ClientInterface::accept%3A5CB7D60006.body preserve=yes
   hClientInterfaceVisitor.visitClientInterface(this);
   ClientPool::instance()->accept(hClientInterfaceVisitor);
  //## end ClientInterface::accept%3A5CB7D60006.body
}

int ClientInterface::forceLogoff (Message& hMessage)
{
  //## begin ClientInterface::forceLogoff%3DDE315E0196.body preserve=yes
   // CL112: DM_Forced_User_Logoff
   UseCase hUseCase("CLIENT","## CL112 FORCE LOGOFF");
   Message hSaveMessage = hMessage;
   string strUserID(CommonHeaderSegment::instance()->getAlias());
   if (!ClientPool::instance()->isLoggedOn())
      return sendError(hMessage,STS_SESSION_ERROR,STS_ERROR,STS_NOT_LOGGED_ON);
   if (!ClientPool::instance()->logoff(strUserID))
      return sendError(hMessage,STS_SECURITY_ERROR,STS_SEVERE_ERROR,STS_ACCESS_SECURITY_UNAVAILABLE);
   ServerPool::instance()->logoff(strUserID);
   hMessage = hSaveMessage;
   ResultSet hResultSet;
   hResultSet.close();
   char sConversationID[9] = {"        "};
   char sSymDestName[9] = {"        "};
   memcpy(sConversationID,hMessage.getCorrelId().data(),8);
   int m = 0;
   sscanf(sConversationID,"%08x",&m);
   snprintf(sSymDestName,sizeof(sSymDestName),"%d",m);
   Queue::send(sSymDestName,&hMessage);
   return 0;
  //## end ClientInterface::forceLogoff%3DDE315E0196.body
}

int ClientInterface::initialize ()
{
  //## begin ClientInterface::initialize%37D954BF0270.body preserve=yes
   new platform::Platform();
   int iRC = Application::initialize();
   UseCase hUseCase("CLIENT","## CL01 START CI");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
#ifndef MVS
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->attach(this);
   Database::instance()->connect();
#else
   CriticalSection::setEnable(0);
#endif
   string strRecord;
   if (Extract::instance()->getRecord("DUSER",strRecord)
      && strRecord.length() >= 18)
   {
      vector<string> hTokens;
      Buffer::parse(strRecord.substr(17),",! ",hTokens);
      if (hTokens.size() >= 3)
      {
         m_pSocketSignal[0] = new Signal(hTokens[0].c_str());
         if (hTokens[0] == "SSL" && ((AESKeyManager*)KeyManager::instance())->loadSSLEnvironment())
            m_pSocketQueue[0] = (SocketQueue*)QueueFactory::instance()->create("SecureQueue",hTokens[0].c_str());
         else
#ifdef MVS
            m_pSocketQueue[0] = new SocketQueue(hTokens[0].c_str());
#else
            m_pSocketQueue[0] = (SocketQueue*)QueueFactory::instance()->create("Queue",hTokens[0].c_str());
#endif
         m_pSocketQueue[0]->setSignal(m_pSocketSignal[0]);
         m_pSocketSignal[0]->attach(m_pSocketQueue[0]);
         while (true)
         {
            if (m_pSocketQueue[0]->open(hTokens[1].c_str(),hTokens[2].c_str()))
            {
               enable(m_pSocketSignal[0]);
               break;
            }
            else
            {
               char szBuf[60];
               IF::Trace::put(szBuf, snprintf(szBuf,sizeof(szBuf), "Unable to open port: %s:%s:%s", hTokens[0].c_str(), hTokens[1].c_str(), hTokens[2].c_str()), true);
               IF::Sleep::goTo("00000500");
               continue;
            }
         }
      }
   }
   string strHTTP;
   if (Extract::instance()->getSpec("HTTP",strHTTP))
   {
      vector<string> hTokens;
      Buffer::parse(strHTTP,",",hTokens);
      if (hTokens.size() >= 2)
      {
         m_pSocketSignal[1] = (Signal*)QueueFactory::instance()->create("Signal","HTTP");
         m_pSocketQueue[1] = (SocketQueue*)QueueFactory::instance()->create("Queue","HTTP");
         m_pSocketQueue[1]->setSignal(m_pSocketSignal[1]);
         m_pSocketSignal[1]->attach(m_pSocketQueue[1]);
         enable(m_pSocketSignal[1]);
         m_pSocketQueue[1]->setInterface(SocketQueue::POST);
         if (!m_pSocketQueue[1]->open(hTokens[0].c_str(),hTokens[1].c_str()))
         {
            UseCase::setSuccess(false);
            return -1;
         }
      }
   }
   update(Extract::instance());
   m_pConfigurationFile = new ConfigurationFile();
   m_pLogonSegment = new LogonSegment();
   m_pAuthenticateSegment = new AuthenticateSegment();
   m_pMultipleRowContextSegment = new MultipleRowContextSegment();
   m_pResponseTimeSegment = new ResponseTimeSegment();
   m_pInformationSegment = new InformationSegment();
   m_pKeyExchangeSegment = KeyExchangeSegment::instance();
   m_pTextSegment = new TextSegment();
   m_hSegments.push_back(m_pLogonSegment);
   m_hSegments.push_back(m_pAuthenticateSegment);
   m_hSegments.push_back(m_pMultipleRowContextSegment);
   m_hSegments.push_back(m_pResponseTimeSegment);
   m_hSegments.push_back(m_pKeyExchangeSegment);
   m_hSegments.push_back(m_pTextSegment);
   ServerPool::instance();
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   string strAlias("@");
   strAlias += strCUST_ID;
   //Queue::attach(strAlias.c_str());
   // request list of services from all servers
   Message::instance(Message::OUTBOUND)->reset("CI SRV","S0004D",false);
   Message::instance(Message::OUTBOUND)->setDataLength(0);
   string strBuffer;
#ifdef MVS
   Message::instance(Message::OUTBOUND)->send("@##SERVER");
#else
   int i = 0;
   string strQueue;
   while (Extract::instance()->getRecord(i,strBuffer))
   {
      if (strBuffer.length() > 33
         && strBuffer.substr(0,8) == "DQUEUE  ")
      {
         string strType(strBuffer.data() + 28,2);
         if ((strBuffer.substr(32,2) == "CI"
            || (strType == "AM"
            || strType == "CM"
            || strType == "CQ"
            || strType == "DI"
            || strType == "EA"
            || strType == "EM"
            || strType == "EQ"
            || strType == "GM"
            || strType == "QE"
            || strType == "RE"
            || strType == "TI"))
            && strBuffer.substr(32,4) != "CICI"
            && strBuffer.substr(8,2) == name().substr(0,2))
            Message::instance(Message::OUTBOUND)->send(strBuffer.substr(8,8).c_str());
      }
      ++i;
   }
#endif
    if ((m_lHours = Extract::instance()->getTimer("AGEOUT")) != -1)
    {
        m_hTimer.set(m_lHours);
        m_hTimer.attach(this);
    }
    char szS200[5] = { "S200" };
    char szS208[5] = { "S208" };
    char szE001[5] = { "E001" };
    char szS269[5] = { "S269" };
#ifdef MVS
    CodeTable::translate(szS200, 4, CodeTable::CX_EBCDIC_TO_ASCII);
    CodeTable::translate(szS208, 4, CodeTable::CX_EBCDIC_TO_ASCII);
    CodeTable::translate(szS269, 4, CodeTable::CX_EBCDIC_TO_ASCII);
    CodeTable::translate(szE001, 4, CodeTable::CX_EBCDIC_TO_ASCII);
#endif
   return 0;
  //## end ClientInterface::initialize%37D954BF0270.body
}

int ClientInterface::onDisconnect (IF::Message& hMessage)
{
  //## begin ClientInterface::onDisconnect%38E26AED039F.body preserve=yes
   return ServerPool::instance()->onDisconnect(hMessage);
  //## end ClientInterface::onDisconnect%38E26AED039F.body
}

int ClientInterface::onMessage (Message& hMessage)
{
  //## begin ClientInterface::onMessage%37D954DD0350.body preserve=yes
   if (memcmp(hMessage.buffer(),"POST",4) == 0
      || memcmp(hMessage.buffer(),"GET",3) == 0
      || memcmp(hMessage.buffer(),"PUT",3) == 0
      || memcmp(hMessage.buffer(),"DELETE",6) == 0
      || memcmp(hMessage.buffer(),"OPTIONS",7) == 0)
   {
      *Message::instance(Message::OUTBOUND) = hMessage;
      Message::instance(Message::OUTBOUND)->reserve(Message::instance(Message::OUTBOUND)->messageLength() + 1);
      Message::instance(Message::OUTBOUND)->buffer()[Message::instance(Message::OUTBOUND)->messageLength()] = '\0';
      char* p = Message::instance(Message::OUTBOUND)->buffer();
      string strPOST(p,Message::instance(Message::OUTBOUND)->messageLength());
      vector<string> hLines;
      Buffer::parse(strPOST,"\n",hLines);
      char* q = strchr(p,'<');
      if (!q)
         q = strchr(p,'{');
      if (!q)
         return 0;
      string strBuffer(q,Message::instance(Message::OUTBOUND)->messageLength() - (q - p));
      vector<string> hTokens;
      if (*q == '<')
         Buffer::parse(strBuffer,"<>",hTokens);
      else
         Buffer::parse(strBuffer,"{}:,\r\n ",hTokens);
      hTokens.push_back("x");
      hTokens.push_back("y");
      hTokens.push_back("z");
      string strUsrId;
      string strPswrd;
      string strSession;
      string strServId;
      m_strServId.erase();
      string strCUST_ID;
      Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
      CommonHeaderSegment::instance()->setCUST_ID(strCUST_ID);
      for (int j = 0;j < hTokens.size();++j)
      {
         if ((hTokens[j] == "UsrId"
            && hTokens[j + 2] == "/UsrId")
            || hTokens[j] == "\"userId\"")
            strUsrId = hTokens[j + 1];
         else
         if ((hTokens[j] == "Pswrd"
            && hTokens[j + 2] == "/Pswrd")
            || (hTokens[j] == "\"password\""
            && hTokens[j - 1] != "\"password\""))
            strPswrd = hTokens[j + 1];
         else
         if (hTokens[j] == "ServId"
            || hTokens[j] == "service")
         {
            strServId = hTokens[j + 1];
            if (hTokens[j] == "ServId")
               m_strServId = strServId;
         }
         else
         if (hTokens[j] == "\"session\"")
            strSession = hTokens[j + 1];
      }
      for (int j = 0;j < hLines.size();++j)
      {
         if (hLines[j].size() > 21
            && memcmp(hLines[j].data(),"Authorization: Basic ",21) == 0)
         {
            unsigned char szCiphertext[109];
            memset(szCiphertext,' ',108);
            szCiphertext[108] = '\0';
            unsigned char szBase64text[109];
            memset(szBase64text,' ',108);
            memcpy(szBase64text,hLines[j].data() + 21,hLines[j].length() - 21);
            szBase64text[108] = '\0';
            int k = securitywrapper::SecurityWrapper::EVP_DecodeBlock((unsigned char*)szCiphertext, szBase64text, hLines[j].length() - 21);
            if (k > 0)
            {
               string strText((char*)szCiphertext);
               rtrim(strText);
               vector<string> hToken;
               Buffer::parse(strText,":",hToken);
               if (hToken.size() == 2)
               {
                  strUsrId = hToken[0];
                  strPswrd = hToken[1];
               }
            }
         }
         if (hLines[j].size() > 9
            && memcmp(hLines[j].data(),"session: ",9) == 0)
         {
            unsigned char szCiphertext[109];
            memset(szCiphertext,' ',108);
            szCiphertext[108] = '\0';
            unsigned char szBase64text[109];
            memset(szBase64text,' ',108);
            memcpy(szBase64text,hLines[j].data() + 9,hLines[j].length() - 9);
            szBase64text[108] = '\0';
            int k = securitywrapper::SecurityWrapper::EVP_DecodeBlock((unsigned char*)szCiphertext,szBase64text,hLines[j].length() - 9);
            if (k > 0)
            {
               string strText((char*)szCiphertext);
               rtrim(strText);
               vector<string> hToken;
               Buffer::parse(strText,":",hToken);
               if (hToken.size() == 2)
               {
                  strSession = hToken[0];
                  strSession.resize(8,' ');
                  strSession += ":";
                  strSession += hToken[1];
               }
            }
         }
      }
      std::replace(strUsrId.begin(),strUsrId.end(),'\"',' ');
      strUsrId.trim();
      std::replace(strPswrd.begin(),strPswrd.end(),'\"',' ');
      strPswrd.trim();
      std::replace(strServId.begin(),strServId.end(),'\"',' ');
      strServId.trim();
      std::replace(strSession.begin(),strSession.end(),'\"',' ');
      strSession.trim();
      p = hMessage.buffer() + 8;
      CommonHeaderSegment::instance()->deport(&p);
      if (!strSession.empty())
      {
         strUsrId.assign(strSession.data(),8);
         strUsrId.trim();
         CommonHeaderSegment::instance()->setAlias(strUsrId);
         memcpy(hMessage.buffer() + 32,strSession.data(),strSession.length());
         CommonHeaderSegment::instance()->setSecurityData(strSession);
         if (!ClientPool::instance()->isLoggedOn())
            return 0;
      }
      else
      {
         memset(hMessage.buffer() + 32,' ',8);
         memcpy(hMessage.buffer() + 32,strUsrId.data(),strUsrId.length());
      }
      map<string,string,less<string> >::iterator u = m_hURL.end();
      if (!hMessage.getDestination().empty())
         u = m_hURL.find(hMessage.getDestination());
      if (hMessage.getDestination() == "/rest/datanavigator/configure/crlist/v1.0.0")
         strServId = "JLCR";
      else
      if (hMessage.getDestination() == "/rest/datanavigator/configure/crread/v1.0.0")
         strServId = "JRCR";
      else
      if (hMessage.getDestination() == "/rest/datanavigator/configure/crupdate/v1.0.0")
         strServId = "JUCR";
      else
      {
         if (u != m_hURL.end())
            strServId = (*u).second;
         else
         if (strServId[0] == 'J')
            strServId.assign("HTTP  ",6);
      }
      strServId.resize(6,' ');
      memcpy(hMessage.buffer() + 24,"Q       ",8);
      memcpy(hMessage.buffer() + 25,strServId.data(),6);
      m_pTextSegment->reset();
      m_pTextSegment->setText(strPOST);
      m_pTextSegment->deport(&p);
      char szLength[9];
      snprintf(szLength,sizeof(szLength),"%08d",p - hMessage.buffer());
      memcpy(hMessage.buffer(),szLength,8);
      hMessage.setMessageLength(p - hMessage.buffer());
      int iParse = parse(hMessage);
      if (strServId == "JLCR  "
         || strServId == "JRCR  "
         || strServId == "JUCR  ")
         return requestXT(hMessage);
      else
         return requestHTTP(hMessage);
   }
   // request from Dialog Manager
   if (hMessage.messageID() == "H5050D")
   {
      if (!strncmp(hMessage.data(),"SERVERS.LIST",12))
      {
         ClientDisplayServers hClientDisplayServers;
         ServerPool::instance()->accept(hClientDisplayServers);
         hClientDisplayServers.setBusy(false);
         ServerPool::instance()->accept(hClientDisplayServers);
      }
      else
      if (!strncmp(hMessage.data(),"QUEUE.LIST",10))
      {
         ClientDisplayQueue hClientDisplayQueue;
         ServerPool::instance()->accept(hClientDisplayQueue);
      }
      else
      if (!strncmp(hMessage.data(),"TRACE.LIST",10))
      {
         ClientDisplayTrace hClientDisplayTrace;
         ServerPool::instance()->accept(hClientDisplayTrace);
      }
      else
      if (!strncmp(hMessage.data(),"USERS.LIST",10))
      {
         ClientDisplayUsers hClientDisplayUsers;
         accept(hClientDisplayUsers);
      }
      else
      if (!strncmp(hMessage.data(),"SLOW.LIST",9))
      {
         ClientDisplaySlowRequests hClientDisplaySlowRequests;
         ServerPool::instance()->accept(hClientDisplaySlowRequests);
      }
      else
      {
         string strDomain(hMessage.data(),hMessage.dataLength());
         size_t pos = strDomain.find('(');
         if (pos == string::npos)
            return 0;
         string strMember(strDomain.substr(pos + 1));
         strDomain.erase(pos);
         pos = strMember.find(')');
         if (pos == string::npos)
            return 0;
         string strFunction(strMember.substr(pos + 2));
         strMember.erase(pos);
         if (strDomain == "SERVER")
         {
            if (strFunction == "SQL")
            {
               ClientDisplayServerSQL hClientDisplayServerSQL;
               ServerPool::instance()->acceptServer(strMember,hClientDisplayServerSQL);
            }
            else
            {
               ClientDisplayServerRequest hClientDisplayServerRequest;
               ServerPool::instance()->acceptServer(strMember,hClientDisplayServerRequest);
            }
         }
         else
         if (strDomain == "QUEUE")
         {
            //ClientDisplayQueueRequest hClientDisplayQueueRequest();
            //ServerPool::instance()->accept(strMember,hClientDisplayQueueRequest);
         }
         else
         if (strDomain == "USERS")
         {
            if (strFunction == "LOGOFF")
            {
               CommonHeaderSegment::instance()->setUserID(strMember);
               forceLogoff(hMessage);
            }
         }
         else
         if (strDomain == "SLOW")
         {
            ClientDisplaySlowSQL hClientDisplaySlowSQL;
            ServerPool::instance()->acceptRequest(strMember,hClientDisplaySlowSQL);
         }
      }
   }
   else
   // response from Query Engine
   if (hMessage.messageID() == "S0003R")
   {
      sendToClient(hMessage);
      ServerPool::instance()->update(Message::instance(Message::INBOUND));
   }
   else
   // response from CR Server
   if (hMessage.messageID() == "S0005R")
   {
      saveRelationship(hMessage);
      sendToClient(hMessage);
   }
   else
   if (hMessage.messageID() == "S0003D"
      || hMessage.messageID() == "S0004R"
      || hMessage.messageID() == "S0008D"
      || hMessage.messageID() == "S0009R"
      || hMessage.messageID() == "S0010D")
   {
      ServerPool::instance()->update(Message::instance(Message::INBOUND));
   }
   else
   if (hMessage.messageID() == "S0013R")
   {
      string strService(hMessage.data() + 1,7);
      string strURL(hMessage.data() + 8,hMessage.dataLength() - 8);
      m_hURL[strURL] = strService;
   }
   else
   if (hMessage.messageID() == "S0011D")
      m_pConfigurationFile->parse(hMessage);
   else
   {
      int iParse = parse(hMessage);
      string strServiceName(CommonHeaderSegment::instance()->getServiceName());
      if (iParse != -1)
#ifdef CS
      if (strServiceName == "QLOGON") //only log QLOGON for CS
#endif
         Log::put(hMessage.buffer(),hMessage.messageLength(),"S0000",strServiceName.c_str());

      switch (iParse)
      {
         case 2:
            requestCRData(hMessage);
            break;
         case 3:
            if (strServiceName == "QJLCR"
               || strServiceName == "QJRCR"
               || strServiceName == "QJUCR")
               requestXT(hMessage);
            else
            if (strServiceName == "QHTTP")
               requestHTTP(hMessage);
            else
               requestOther(hMessage);
            break;
         case 4:
            requestResource(hMessage);
            break;
         case 0:
            if (strServiceName == "QHTTP")
               requestHTTP(hMessage);
            else
            if (strServiceName == "QLOGON")
               requestLogon(hMessage);
            else
            if (strServiceName == "QLOGOFF")
               requestLogoff(hMessage);
            else
            if (strServiceName == "QHANDSHK")
               requestHandshake(hMessage);
            else
            if (strServiceName == "QGETCRDT")
               requestConfigurationData(hMessage);
            else
            if (strServiceName == "QGETAPPL"
               || strServiceName == "QGETDEND")
               requestSecurityData(hMessage);
            else
            if (strServiceName == "QKEYXCHG")
               requestKeyExchange(hMessage);
            else
            if (strServiceName == "QXRKEY")
               requestKey(hMessage);
            break;
         default:
            break;
      }
   }
   return 0;
  //## end ClientInterface::onMessage%37D954DD0350.body
}

int ClientInterface::onNotify (const char* pszQueueName)
{
  //## begin ClientInterface::onNotify%3A69B9D001A6.body preserve=yes
   //ServerPool::instance()->drop(pszQueueName);
   return 0;
  //## end ClientInterface::onNotify%3A69B9D001A6.body
}

int ClientInterface::parse (Message& hMessage)
{
  //## begin ClientInterface::parse%351908960291.body preserve=yes
   // convert ASCII to EBCDIC
#ifdef MVS
   if (*(hMessage.buffer()) < '0')
   {
      m_hMessage = hMessage; // save ASCII message
      CodeTable::translate(hMessage.buffer(),hMessage.messageLength(),CodeTable::CX_ASCII_TO_EBCDIC);
      m_bASCII = true;
   }
   else
      m_bASCII = false;
#endif
   // validate the length
   CommonHeaderSegment::instance()->reset();
   char* pSegmentID = hMessage.buffer() + 8;
   char pszSegmentID[5] = {"    "};
   memcpy(pszSegmentID,pSegmentID,4);
   int iRC = CommonHeaderSegment::instance()->import(&pSegmentID);
   char szLength[9] = {"        "};
   snprintf(szLength,sizeof(szLength),"%08ld",hMessage.messageLength());
   if (strncmp(hMessage.buffer(), szLength, 8))
      return -1;

   // validate the common header segment
   if (CommonHeaderSegment::instance()->segmentID() != (const char*)pszSegmentID)
      return -1;

   // parse the common header segment
   if (iRC != 0)
      return -1;

   if (hMessage.buffer()[24] != 'Q')
      return sendError(hMessage,STS_PARSE_ERROR,STS_ERROR,STS_INVALID_SERVICE_NAME);

   if (Application::instance()->getState() == Application::QUIESCED)
      return sendError(hMessage,STS_SESSION_ERROR,STS_ERROR,STS_SYSTEM_IN_SHUTDOWN);
   string strServiceName(CommonHeaderSegment::instance()->getServiceName());
   // validate the service name
   if (strServiceName == "QGETDATA"
      || strServiceName == "QGETUSER"
      || strServiceName == "QGCUSTAT"
      || strServiceName == "QGETCUST"
      || strServiceName == "QUPDCUST")
      return 2;
   if (strServiceName == "QASLRES")
      return 4;
   if (strServiceName != (const char*)"QLOGON"
      && strServiceName != (const char*)"QLOGOFF"
      && strServiceName != (const char*)"QHANDSHK"
      && strServiceName != (const char*)"QGETCRDT"
      && strServiceName != (const char*)"QGETAPPL"
      && strServiceName != (const char*)"QGETDEND"
      && strServiceName != (const char*)"QKEYXCHG"
      && strServiceName != (const char*)"QXRKEY"
      && strServiceName != (const char*)"QHTTP")
   {
      if (strServiceName == (const char*)"QDNLTRAN" || strServiceName == (const char*)"QEMLCASE")
      {
         //parse S220 segments to mask pans
         char* p = hMessage.buffer() + 8;
         char* pEndOfMessage = hMessage.buffer() + hMessage.messageLength();
         while((p+=atoi(string(p+8,8).c_str())) < pEndOfMessage)
         {
            if (memcmp(p,"L001",4)==0)
            {
               int iCount = atoi(string(p+16,4).c_str());
               p+=26;
               for(int i = 0; i < iCount; i++)
               {
                  if (memcmp(p,"S220",4) == 0)
                  {
                     ReportOptionSegment hReportOptionSegment;
                     hReportOptionSegment.import(&p);
                  }
                  else
                     p+= atoi(string(p+8,8).c_str());
               }
               break;
            }
         }
      }
      return 3;
   }

   // reset all segments
   vector<Segment*>::iterator ppSegment;
   for (ppSegment = m_hSegments.begin();ppSegment != m_hSegments.end();++ppSegment)
      (*ppSegment)->reset();

   // parse the remaining segments
   char* pEndOfMessage = hMessage.buffer() + hMessage.messageLength();
   iRC = 0;
   while ((pSegmentID < pEndOfMessage) && (iRC == 0))
   {
      // assume invalid segment ID
      iRC = STS_INVALID_SEGMENT_ID;
      strncpy(pszSegmentID,pSegmentID,4);
      for (ppSegment = m_hSegments.begin();ppSegment != m_hSegments.end();++ppSegment)
      {
         if ((*ppSegment)->segmentID() == (const char*)pszSegmentID)
         {
            iRC = (*ppSegment)->import(&pSegmentID);
            break;
         }
      }
   }
   if (iRC != 0)
      return sendError(hMessage,STS_PARSE_ERROR,STS_ERROR,iRC);
   return 0;
  //## end ClientInterface::parse%351908960291.body
}

int ClientInterface::requestConfigurationData (Message& hMessage)
{
  //## begin ClientInterface::requestConfigurationData%3519089B034C.body preserve=yes
   // CL03: Client_Gets_Configuration_Control_Data
   UseCase hUseCase("CLIENT","## CL03 READ CONFIGURATION");
   if (m_pMultipleRowContextSegment->presence() == false)
      return sendError(hMessage,STS_PARSE_ERROR,STS_ERROR,STS_MISSING_MULTIPLEROWCONTEXT_SEGMENT);
   if (!ClientPool::instance()->isLoggedOn())
      return sendError(hMessage,STS_SESSION_ERROR,STS_ERROR,STS_NOT_LOGGED_ON);
   char szContextData[24] = {"        ***************"};
   m_pSegmentID = hMessage.buffer() + 8;
   m_pConfigurationFile->read(&m_pSegmentID,*CommonHeaderSegment::instance(),*m_pMultipleRowContextSegment,*m_pResponseTimeSegment);
   UseCase::addItem(m_pMultipleRowContextSegment->recordsReturnedThisMessage());
   return respond(hMessage);
  //## end ClientInterface::requestConfigurationData%3519089B034C.body
}

int ClientInterface::requestCRData (Message& hMessage)
{
  //## begin ClientInterface::requestCRData%351908A202A2.body preserve=yes
   if (!ClientPool::instance()->isLoggedOn())
      return sendError(hMessage,STS_SESSION_ERROR,STS_ERROR,STS_NOT_LOGGED_ON);
   // add Connex headers to request message
   int m = hMessage.messageLength();
   char* pTemp = new char[m];
   memcpy(pTemp,hMessage.buffer(),m);
   hMessage.reset("CI ACS","S0005D",false);
   // set sender context value to client session / conversation ID
   hMessage.setSenderCBAddress(ClientPool::instance()->getSession(CommonHeaderSegment::instance()->getAlias()));
   hMessage.setSenderSTCKValue(hMessage.getCorrelId().data());
   memcpy(hMessage.data(),pTemp,m);
   delete [] pTemp;
   hMessage.setDataLength(m);
   if (Queue::send("CRQ     ",&hMessage) == false)
      return sendError(hMessage,STS_PARSE_ERROR,STS_ERROR,STS_ACCESS_SECURITY_UNAVAILABLE);
   ClientPool::instance()->setASCII(CommonHeaderSegment::instance()->getAlias(),m_bASCII);
   return 0;
  //## end ClientInterface::requestCRData%351908A202A2.body
}

int ClientInterface::requestHandshake (Message& hMessage)
{
  //## begin ClientInterface::requestHandshake%351908AB015A.body preserve=yes
   UseCase hUseCase("CLIENT","## CL06 HANDSHAKE");
   if (!ClientPool::instance()->isLoggedOn())
      return sendError(hMessage,STS_SESSION_ERROR,STS_ERROR,STS_NOT_LOGGED_ON);
   m_pSegmentID = hMessage.buffer() + 8;
   CommonHeaderSegment::instance()->deport(&m_pSegmentID);
   m_pResponseTimeSegment->deport(&m_pSegmentID);
   return respond(hMessage);
  //## end ClientInterface::requestHandshake%351908AB015A.body
}

int ClientInterface::requestHTTP (Message& hMessage)
{
  //## begin ClientInterface::requestHTTP%652ED75B01A5.body preserve=yes
   UseCase hUseCase("CLIENT","## CI00 HTTP REQUEST");
   string strURL;
   string strLine(m_pTextSegment->getText());
   string strSecurityData;
   string strUsrId;
   if (strLine.length() > 7
      && (memcmp(strLine.data(),"POST ",5) == 0
      || memcmp(strLine.data(),"GET ",4) == 0
      || memcmp(strLine.data(),"PUT ",4) == 0
      || memcmp(strLine.data(),"DELETE ",7) == 0
      || memcmp(strLine.data(),"OPTIONS ",8) == 0))
   {
      size_t pos = strLine.find(' ',5);
      if (pos == string::npos)
         return 0;
      strURL.assign(strLine.data() + 5,pos - 5);
      string strPswrd;
      string strSession;
      vector<string> hLines;
      Buffer::parse(strLine,"\n",hLines);
      for (int j = 0; j < hLines.size(); ++j)
      {
         if (hLines[j].size() > 21
            && memcmp(hLines[j].data(),"Authorization: Basic ",21) == 0)
         {
            unsigned char szCiphertext[109];
            memset(szCiphertext,' ',108);
            szCiphertext[108] = '\0';
            unsigned char szBase64text[109];
            memset(szBase64text,' ',108);
            memcpy(szBase64text,hLines[j].data() + 21,hLines[j].length() - 21);
            szBase64text[108] = '\0';
            int k = securitywrapper::SecurityWrapper::EVP_DecodeBlock((unsigned char*)szCiphertext,szBase64text, hLines[j].length() - 21);
            if (k > 0)
            {
               string strText((char*)szCiphertext);
               rtrim(strText);
               vector<string> hToken;
               Buffer::parse(strText,":",hToken);
               if (hToken.size() == 2)
               {
                  strUsrId = hToken[0];
                  strPswrd = hToken[1];
               }
            }
         }
         if (hLines[j].size() > 9
            && memcmp(hLines[j].data(),"session: ",9) == 0)
         {
            unsigned char szCiphertext[109];
            memset(szCiphertext,' ',108);
            szCiphertext[108] = '\0';
            unsigned char szBase64text[109];
            memset(szBase64text,' ',108);
            memcpy(szBase64text,hLines[j].data() + 9,hLines[j].length() - 9);
            szBase64text[108] = '\0';
            int k = securitywrapper::SecurityWrapper::EVP_DecodeBlock((unsigned char*)szCiphertext,szBase64text,hLines[j].length() - 9);
            if (k > 0)
            {
               strSecurityData.assign((char*)szCiphertext);
               rtrim(strSecurityData);
               CommonHeaderSegment::instance()->setSecurityData(strSecurityData);
               vector<string> hToken;
               Buffer::parse(strSecurityData,":",hToken);
               if (hToken.size() == 2)
               {
                  strUsrId = hToken[0];
                  strSession = hToken[0];
                  strSession.resize(8,' ');
                  strSession += ":";
                  strSession += hToken[1];
               }
               ClientPool::instance()->logon(hToken[0],CommonHeaderSegment::instance());
            }
         }
      }
      char* p = hMessage.buffer() + 168;
      m_pTextSegment->deport(&p);
      char szLength[9];
      snprintf(szLength,sizeof(szLength),"%08d",p - hMessage.buffer());
      memcpy(hMessage.buffer(),szLength,8);
      hMessage.setMessageLength(p - hMessage.buffer());
      Trace::put(hMessage.buffer(),hMessage.messageLength(),true);
   }
   if (m_strServId.empty())
   {
      string strServId("J");
      map<string,string,less<string> >::iterator p = m_hURL.find(strURL);
      if (p == m_hURL.end())
         return 0; // need to respond with service unavailable here
      strServId = (*p).second;
      strServId.resize(6,' ');
      memcpy(hMessage.buffer() + 24,"Q       ",8);
      memcpy(hMessage.buffer() + 25,strServId.data(),6);
      strServId.insert(0,1,'Q');
      CommonHeaderSegment::instance()->setServiceName(strServId);
   }
   else
   {
      m_strServId.insert(0,1,'Q');
      CommonHeaderSegment::instance()->setServiceName(m_strServId);
   }
   rtrim(strUsrId);
   if(!strUsrId.empty())
      CommonHeaderSegment::instance()->setAlias(strUsrId);
   segCommonHeaderSegment* q = (segCommonHeaderSegment*)(hMessage.buffer() + 8);
   memcpy(q->sCUST_ID,m_strCustomerID.data(),m_strCustomerID.length());
   if (!strSecurityData.empty())
      memcpy(q->sSecurityData,strSecurityData.data(),strSecurityData.length());
   else if(!strUsrId.empty())
      memcpy(q->sSecurityData,strUsrId.data(),strUsrId.length());
   return requestOther(hMessage);
  //## end ClientInterface::requestHTTP%652ED75B01A5.body
}

int ClientInterface::requestKey (Message& hMessage)
{
  //## begin ClientInterface::requestKey%556E0B0400E7.body preserve=yes
   UseCase hUseCase("CLIENT","## CL08 KEY EXCHANGE");
   int m = hMessage.messageLength();
   char* pTemp = new char[m];
   memcpy(pTemp,hMessage.buffer(),m);
   hMessage.reset("CI GM","S0005D",false);
   hMessage.setSenderSTCKValue(hMessage.getCorrelId().data());
   memcpy(hMessage.data(),pTemp,m);
   delete [] pTemp;
   segCommonHeaderSegment* p = (segCommonHeaderSegment*)(hMessage.data() + 8);
   memcpy(p->sCUST_ID,m_strCustomerID.data(),m_strCustomerID.length());
   hMessage.setDataLength(m);
   string strName(name().data(),2);
   strName.append("GM    ",6);
   if (Queue::send(strName.c_str(),&hMessage) == false)
      return sendError(hMessage,STS_PARSE_ERROR,STS_ERROR,STS_ACCESS_SECURITY_UNAVAILABLE);
   return 0;
  //## end ClientInterface::requestKey%556E0B0400E7.body
}

int ClientInterface::requestKeyExchange (Message& hMessage)
{
  //## begin ClientInterface::requestKeyExchange%490B4A5E0210.body preserve=yes
   UseCase hUseCase("CLIENT","## CL05 KEY EXCHANGE");
   int m = hMessage.messageLength();
   char* pTemp = new char[m];
   memcpy(pTemp,hMessage.buffer(),m);
   hMessage.reset("CI ACS","S0005D",false);
   hMessage.setSenderSTCKValue(hMessage.getCorrelId().data());
   memcpy(hMessage.data(),pTemp,m);
   delete [] pTemp;
   segCommonHeaderSegment* p = (segCommonHeaderSegment*)(hMessage.data() + 8);
   memcpy(p->sCUST_ID,m_strCustomerID.data(),m_strCustomerID.length());
   hMessage.setDataLength(m);
   if (Queue::send("CRQ     ",&hMessage) == false)
      return sendError(hMessage,STS_PARSE_ERROR,STS_ERROR,STS_ACCESS_SECURITY_UNAVAILABLE);
   return 0;
  //## end ClientInterface::requestKeyExchange%490B4A5E0210.body
}

int ClientInterface::requestLogoff (Message& hMessage)
{
  //## begin ClientInterface::requestLogoff%351908B103DA.body preserve=yes
   UseCase hUseCase("CLIENT","## CL07 LOGOFF");
   if (!ClientPool::instance()->isLoggedOn())
      return sendError(hMessage,STS_SESSION_ERROR,STS_ERROR,STS_NOT_LOGGED_ON);
   return requestCRData(hMessage);
  //## end ClientInterface::requestLogoff%351908B103DA.body
}

int ClientInterface::requestLogon (Message& hMessage)
{
  //## begin ClientInterface::requestLogon%351908B700D5.body preserve=yes
   UseCase hUseCase("CLIENT","## CL02 LOGON");
   int m = hMessage.messageLength();
   char* pTemp = new char[m];
   memcpy(pTemp,hMessage.buffer(),m);
   hMessage.reset("CI ACS","S0005D",false);
   hMessage.setSenderSTCKValue(hMessage.getCorrelId().data());
   memcpy(hMessage.data(),pTemp,m);
   delete [] pTemp;
   segCommonHeaderSegment* p = (segCommonHeaderSegment*)(hMessage.data() + 8);
   memcpy(p->sCUST_ID,m_strCustomerID.data(),m_strCustomerID.length());
#ifdef MVS
   // Get the ASCII message that was previously saved.
   segLogonSegment* pLogon1 = (segLogonSegment*)(hMessage.data() + 8 + sizeof(segCommonHeaderSegment));
   if (memcmp(pLogon1->sSegmentID,"S050",4) == 0 &&
       memcmp(pLogon1->sSegmentVersion,"0102",4) >= 0)
   {
      segLogonSegment* pLogon2 = (segLogonSegment*)(m_hMessage.buffer() + 8 + sizeof(segCommonHeaderSegment)); // saved ASCII message from ::parse
      memcpy(pLogon1->sPassword,pLogon2->sPassword,16);
      memcpy(pLogon1->sNewPassword,pLogon2->sNewPassword,16);
   }
#endif
   hMessage.setDataLength(m);
   if (Queue::send("CRQ     ",&hMessage) == false)
      return sendError(hMessage,STS_PARSE_ERROR,STS_ERROR,STS_ACCESS_SECURITY_UNAVAILABLE);
   return 0;
  //## end ClientInterface::requestLogon%351908B700D5.body
}

int ClientInterface::requestOther (Message& hMessage)
{
  //## begin ClientInterface::requestOther%37D9539E026B.body preserve=yes
   string strUserID(CommonHeaderSegment::instance()->getAlias());
   if (CommonHeaderSegment::instance()->getServiceName() != "QJAUSER")
   {
      if (CommonHeaderSegment::instance()->getServiceName().length() > 1
         && (CommonHeaderSegment::instance()->getServiceName()[1] == 'J'
         || CommonHeaderSegment::instance()->getServiceName()[1] == 'X'))
      {
         hMessage.buffer()[143] = 'E';
         hMessage.buffer()[hMessage.messageLength()] = '\0';
         if (strstr(hMessage.buffer(),"<UsrId>")
            || strstr(hMessage.buffer(),"<userId>")
            || strstr(hMessage.buffer(), "\"userId\":"))
            ClientPool::instance()->logon(strUserID,CommonHeaderSegment::instance());
      }
      if (!ClientPool::instance()->isLoggedOn())
      {
         if (CommonHeaderSegment::instance()->getServiceName()[1] == 'J')
            CommonHeaderSegment::instance()->setServiceName("RHTTP");
         return sendError(hMessage,STS_SESSION_ERROR,STS_ERROR,STS_NOT_LOGGED_ON);
      }
   }
   struct segRelationshipSegment *pRelationshipSegment = (segRelationshipSegment*)ClientPool::instance()->getRelationship(strUserID);
   string strServiceName(CommonHeaderSegment::instance()->getServiceName());
   // find the multiple row context segment (if any)
   m_pMultipleRowContextSegment->reset();
   char* pSegmentID = hMessage.buffer() + 8;
   char szTemp[9] = {"        "};
   char* pEndOfMessage = pSegmentID + hMessage.messageLength() - 8;
   Trace::put((char*)&pSegmentID,4);
   int i = 0;
   while (pSegmentID < pEndOfMessage)
   {
      Trace::put(pSegmentID,4);
      if (memcmp(pSegmentID,"S002",4) == 0)
      {
         int iRC = m_pMultipleRowContextSegment->import(&pSegmentID);
         if (iRC != 0)
            return sendError(hMessage,STS_PARSE_ERROR,STS_ERROR,STS_NOT_LOGGED_ON);
         break;
      }
      memcpy(szTemp,pSegmentID + 8,8);
      pSegmentID += atoi(szTemp);
      if (++i > 16)
         break;
   }
   char* p = 0;
   bool bQuery = false;
   if (m_pMultipleRowContextSegment->presence())
   {
      //Trace::put(string(m_pMultipleRowContextSegment->clientStateIndicator()).data(),1);
      switch (m_pMultipleRowContextSegment->clientStateIndicator())
      {
         case 'I':
            // add STCK value to security data in common header
            char szSecurityData[96];
            memset(szSecurityData,' ',64);
            i = CommonHeaderSegment::instance()->getSecurityData().length();
            if (i > 64)
               i = 64;
            memcpy(szSecurityData,CommonHeaderSegment::instance()->getSecurityData().data(),i);
            char szTemp[PERCENTF];
            snprintf(szTemp,sizeof(szTemp),"%020.0f",Clock::instance()->getTicks());
            memcpy(szSecurityData + 43,szTemp,20);
            szSecurityData[63] = '\0';
            CommonHeaderSegment::instance()->setSecurityData(szSecurityData);
            p = hMessage.buffer() + 8;
            CommonHeaderSegment::instance()->deport(&p);
            p = hMessage.buffer() + 24;
            *p = 'Q';
            break;
         case 'C':
            bQuery = ((strServiceName == (const char*)"QDNLTRAN")
               || (strServiceName == (const char*)"QDNLFTRN")
               || (strServiceName == (const char*)"QEMLCASE")
               || (strServiceName == (const char*)"QGETSTAT")
               || (strServiceName == (const char*)"QSUMTRAN")
               || (strServiceName == (const char*)"QDNLINST")
               || (strServiceName == (const char*)"QTMLADMN")
               || (strServiceName == (const char*)"QDNLRLVL" && strstr(pSegmentID,"S242")));
         case 'P':
            // if STCK value found in common header, get remaining results from session
            char sConversationID[9] = {"        "};
            char sSymDestName[9] = {"        "};
            memcpy(sConversationID,Message::instance(Message::INBOUND)->getCorrelId().data(),8);
            int m = 0;
            sscanf(sConversationID,"%08x",&m);
            snprintf(sSymDestName,sizeof(sSymDestName),"%d",m);
            string strQueueName(sSymDestName);
            if (ClientPool::instance()->pop(strUserID,strQueueName,
               CommonHeaderSegment::instance()->getExternalContextData(),
               m_pMultipleRowContextSegment->clientStateIndicator() == 'C',bQuery))
               return Queue::send(sSymDestName,Message::instance(Message::INBOUND));
            if (bQuery == false)
            {
               if (m_pMultipleRowContextSegment->clientStateIndicator() == 'P')
                  return sendError(hMessage,STS_SESSION_ERROR,STS_ERROR,STS_DATA_UNAVAILABLE);
               return 0;
            }
      }
   }
   // add Connex headers to request message
   int m = hMessage.messageLength();
   char* pTemp = new char[m];
   memcpy(pTemp,hMessage.buffer(),m);
   hMessage.reset("CI SRV","S0003D",false);
   // set sender context value to client session / conversation ID
   hMessage.setSenderCBAddress(ClientPool::instance()->getSession(strUserID));
   hMessage.setSenderSTCKValue(hMessage.getCorrelId().data());
   memcpy(hMessage.data(),pTemp,m);
   p = ClientPool::instance()->getRelationship(strUserID);
   string strServer = ServerPool::instance()->getServerName(strServiceName);
   if (p && (strServer.length() > 3
      && strServer.substr(2,2) != "EM" && strServer.substr(2,2) != "EQ"))
   {
      if (m + strlen(p) > MAX_MESSAGE_SIZE)
      {
         delete [] pTemp;
         return sendError(hMessage,STS_SESSION_ERROR,STS_ERROR,STS_INVALID_LENGTH);
      }
      strcpy(hMessage.data() + m,p);
      m += strlen(p);
      snprintf(pTemp,9,"%08d",m);
      memcpy(hMessage.data(),pTemp,8);
   }
   char szQueue[11] = {"@         "};
   strncpy(szQueue + 1,name().data(),2);
   memcpy(szQueue + 3,pTemp + 25,7);
   ResourceListSegment* pResources = ClientPool::instance()->getResourceListSegment(strUserID);
   char* pTemp2 = hMessage.data();
   pTemp2 += m;
   int n = 0;
   if (pResources)
      n = pResources->exportAsChar(&pTemp2);
   hMessage.setDataLength(m + n);
   snprintf(pTemp,9,"%08d",m + n);
   memcpy(hMessage.data(),pTemp,8);
   delete [] pTemp;
   ClientPool::instance()->setASCII(strUserID,m_bASCII);
   if (!ServerPool::instance()->queue(strUserID,strServiceName,hMessage))
      return sendError(hMessage,STS_SESSION_ERROR,STS_ERROR,STS_DUPLICATE_QUERY);
   return 0;
  //## end ClientInterface::requestOther%37D9539E026B.body
}

int ClientInterface::requestResource (Message &hMessage)
{
  //## begin ClientInterface::requestResource%3B5D6AE90232.body preserve=yes
   UseCase hUseCase("CLIENT","## CL96 GET RESOURCE LIST");
   string strUserID(CommonHeaderSegment::instance()->getAlias());
   if (!ClientPool::instance()->isLoggedOn())
      return sendError(hMessage,STS_SESSION_ERROR,STS_ERROR,STS_NOT_LOGGED_ON);
   m_pSegmentID = hMessage.buffer() + 8;
   CommonHeaderSegment::instance()->deport(&m_pSegmentID);
   ResourceListSegment* pResources = ClientPool::instance()->getResourceListSegment(strUserID);
   if (pResources)
      pResources->exportAsXML(&m_pSegmentID);
   return respond(hMessage);
  //## end ClientInterface::requestResource%3B5D6AE90232.body
}

int ClientInterface::requestSecurityData (Message& hMessage)
{
  //## begin ClientInterface::requestSecurityData%351908BC010F.body preserve=yes
   char szSection[9];
   char* pszMember;
   string strServiceName(CommonHeaderSegment::instance()->getServiceName());
   if (strServiceName == "QGETAPPL")
   {
      strcpy(szSection,"DWIDGT  ");
      pszMember = "## CL04 READ SECURITY";
   }
   else
   {
      strcpy(szSection,"DPERMS  ");
      pszMember = "## CL05 READ APPEARANCE";
   }
   UseCase hUseCase("CLIENT",pszMember);
   if (m_pMultipleRowContextSegment->presence() == false)
      return sendError(hMessage,STS_PARSE_ERROR,STS_ERROR,STS_MISSING_MULTIPLEROWCONTEXT_SEGMENT);
   if (!ClientPool::instance()->isLoggedOn())
      return sendError(hMessage,STS_SESSION_ERROR,STS_ERROR,STS_NOT_LOGGED_ON);
   char szContextData[24] = {"CLNTSEC ***************"};
   strncpy(szContextData,m_strClientSecurity.data(),8);
   m_pMultipleRowContextSegment->setSTSContextData(szContextData);
   m_pSegmentID = hMessage.buffer() + 8;
   m_pConfigurationFile->read(szSection,&m_pSegmentID,*CommonHeaderSegment::instance(),*m_pMultipleRowContextSegment,*m_pResponseTimeSegment);
   UseCase::addItem(m_pMultipleRowContextSegment->recordsReturnedThisMessage());
   return respond(hMessage);
  //## end ClientInterface::requestSecurityData%351908BC010F.body
}

int ClientInterface::requestXT (Message& hMessage)
{
  //## begin ClientInterface::requestXT%64B543570324.body preserve=yes
   string strUserID(CommonHeaderSegment::instance()->getAlias());
   hMessage.buffer()[143] = 'E';
   hMessage.buffer()[hMessage.messageLength()] = '\0';
   if (strstr(hMessage.buffer(),"<UsrId>")
      || strstr(hMessage.buffer(),"<userId>")
      || strstr(hMessage.buffer(),"\"userId\""))
      ClientPool::instance()->logon(strUserID,CommonHeaderSegment::instance());
   if (!ClientPool::instance()->isLoggedOn())
      return sendError(hMessage,STS_SESSION_ERROR,STS_ERROR,STS_NOT_LOGGED_ON);
   int m = hMessage.messageLength();
   char* pTemp = new char[m];
   memcpy(pTemp,hMessage.buffer(),m);
   hMessage.reset("CI XT ","S0005D",false);
   hMessage.setSenderCBAddress(ClientPool::instance()->getSession(CommonHeaderSegment::instance()->getAlias()));
   hMessage.setSenderSTCKValue(hMessage.getCorrelId().data());
   memcpy(hMessage.data(),pTemp,m);
   delete[] pTemp;
   hMessage.setDataLength(m);
   if (Queue::send("XT      ",&hMessage) == false)
      return sendError(hMessage,STS_PARSE_ERROR,STS_ERROR,STS_ACCESS_SECURITY_UNAVAILABLE);
   ClientPool::instance()->setASCII(CommonHeaderSegment::instance()->getAlias(),m_bASCII);
   return 0;
  //## end ClientInterface::requestXT%64B543570324.body
}

bool ClientInterface::respond (Message& hMessage)
{
  //## begin ClientInterface::respond%37D954E800DF.body preserve=yes
   int m = m_pSegmentID - hMessage.buffer();
   char szTemp[9];
   snprintf(szTemp,sizeof(szTemp),"%08ld",m);
   memcpy(hMessage.buffer(),szTemp,8);
   Trace::put(hMessage.buffer(),m);
   hMessage.setMessageLength(m);
#ifdef MVS
   if (m_bASCII)
      CodeTable::translate(hMessage.buffer(),hMessage.messageLength(),CodeTable::CX_EBCDIC_TO_ASCII);
#endif
   unsigned char* p = (unsigned char*)hMessage.buffer();
   for (int i = 0;i < m;++i)
   {
       if (*p < 0x20
          && *p != 0x0A)
          *p = 0x20;
       ++p;
   }
   char sConversationID[9] = {"        "};
   char sSymDestName[9] = {"        "};
   memcpy(sConversationID,hMessage.getCorrelId().data(),8);
   m = 0;
   sscanf(sConversationID,"%08x",&m);
   snprintf(sSymDestName,sizeof(sSymDestName),"%d",m);
   return Queue::send(sSymDestName,&hMessage);
  //## end ClientInterface::respond%37D954E800DF.body
}

void ClientInterface::saveRelationship (Message& hMessage)
{
  //## begin ClientInterface::saveRelationship%37D953F2022F.body preserve=yes
   ClientPool::instance()->saveRelationship(hMessage);
  //## end ClientInterface::saveRelationship%37D953F2022F.body
}

bool ClientInterface::send (const char* psConversationID, Message& hMessage)
{
  //## begin ClientInterface::send%3E9EAAF90261.body preserve=yes
#ifdef MVS
   if (m_bASCII)
      CodeTable::translate(hMessage.buffer(),hMessage.messageLength(),CodeTable::CX_EBCDIC_TO_ASCII);
#endif
   unsigned char* p = (unsigned char*)hMessage.buffer();
   for (int i = 0;i < hMessage.messageLength();++i)
   {
       if (*p < 0x20
          && *p != 0x0A)
          *p = 0x20;
       ++p;
   }
   char sSymDestName[9] = {"        "};
   int m = 0;
   sscanf(psConversationID,"%08x",&m);
   snprintf(sSymDestName,sizeof(sSymDestName),"%d",m);
   return Queue::send(sSymDestName,&hMessage);
  //## end ClientInterface::send%3E9EAAF90261.body
}

int ClientInterface::sendError (Message& hMessage, int iResultCode, char sSeverityLevel, int lInfoIDNumber)
{
  //## begin ClientInterface::sendError%351908D2021F.body preserve=yes
   UseCase::setSuccess(false);
   CommonHeaderSegment::instance()->setResultCode(iResultCode);
   m_pInformationSegment->setError(sSeverityLevel,lInfoIDNumber);
   m_pSegmentID = hMessage.buffer() + 8;
   CommonHeaderSegment::instance()->deport(&m_pSegmentID);
   m_pInformationSegment->deport(&m_pSegmentID);
   m_pResponseTimeSegment->deport(&m_pSegmentID);
   respond(hMessage);
   return -1;
  //## end ClientInterface::sendError%351908D2021F.body
}

int ClientInterface::sendToClient (Message& hMessage)
{
  //## begin ClientInterface::sendToClient%351908D80169.body preserve=yes
   // get client conversation ID from receiver context value
   IString strConversationID = hMessage.receiverSTCKValue();
   //ClientSession* pSession = (ClientSession*)hMessage.receiverCBAddress();
//#ifndef MVS
//   if (getDebug())
//    pSession = &((*(m_hClientSession.begin())).second);
//#endif
   // verify the Session pointer
   // remove Connex headers from response message
   int m = hMessage.dataLength();
   char* pTemp = new char[m];
   memcpy(pTemp,hMessage.data(),m);
   memcpy(hMessage.buffer(),pTemp,m);
   hMessage.setMessageLength(m);
   delete [] pTemp;
   char* pSegmentID = hMessage.buffer() + 8;
   Trace::put("Received from server:");
   Trace::putHex(hMessage.buffer(),m);
   char* q = hMessage.buffer();
   *(q + m) = '\0';
   CommonHeaderSegment::instance()->import(&pSegmentID);
   string strUserID(CommonHeaderSegment::instance()->getAlias());
   Trace::put(CommonHeaderSegment::instance()->getServiceName().c_str());
   if (CommonHeaderSegment::instance()->getServiceName() == "RLOGON"
      || (CommonHeaderSegment::instance()->getServiceName() == "RHTTP"
      && (strstr(hMessage.buffer(),"Password Expiry")
      || strstr(hMessage.buffer(),"Authentication failure"))))
   {
      if (CommonHeaderSegment::instance()->getResultCode() != 0
         || strstr(hMessage.buffer(),"Authentication failure"))
      {
         char* x = strstr(hMessage.buffer(),"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
         if (x)
            memset(x,' ',36);
         segCommonHeaderSegment* p = (segCommonHeaderSegment*)(hMessage.buffer() + 8);
         memset(p->sCUST_ID,' ',4);
         memset(p->sSecurityData,' ',64);
         Log::put(hMessage.buffer(),hMessage.messageLength(),"S0000",CommonHeaderSegment::instance()->getServiceName().c_str());
         return send(strConversationID,hMessage);
      }
#ifdef MVS
      ResourceListSegment::instance()->import(&pSegmentID);
#endif
      if (CommonHeaderSegment::instance()->getServiceName() == "RHTTP")
      {
         char szSecurityData[64];
         memset(szSecurityData,' ',64);
         int i = CommonHeaderSegment::instance()->getSecurityData().length();
         if (i > 64)
            i = 64;
         memcpy(szSecurityData,CommonHeaderSegment::instance()->getSecurityData().data(),i);
         szSecurityData[8] = ':';
         char szTemp[PERCENTF];
         snprintf(szTemp,sizeof(szTemp),"%020.0f",Clock::instance()->getTicks());
         memcpy(szSecurityData + 9,szTemp,16);
         szSecurityData[63] = '\0';
         CommonHeaderSegment::instance()->setSecurityData(szSecurityData);

      }
      int lInfoIDNumber = ClientPool::instance()->logon(strUserID,CommonHeaderSegment::instance());
      if (lInfoIDNumber != 0)
      {
         CommonHeaderSegment::instance()->setResultCode(STS_SECURITY_ERROR);
         m_pInformationSegment->setError(STS_ERROR,lInfoIDNumber);
         m_pSegmentID = hMessage.buffer() + 8;
         CommonHeaderSegment::instance()->deport(&m_pSegmentID);
         segCommonHeaderSegment* p = (segCommonHeaderSegment*)(hMessage.buffer() + 8);
         memset(p->sCUST_ID,' ',4);
         memset(p->sSecurityData,' ',64);
         m_pInformationSegment->deport(&m_pSegmentID);
         m_pResponseTimeSegment->deport(&m_pSegmentID);
         int m = m_pSegmentID - hMessage.buffer();
         char szTemp[9];
         snprintf(szTemp,sizeof(szTemp),"%08ld",m);
         memcpy(hMessage.buffer(),szTemp,8);
         hMessage.setMessageLength(m);
         Trace::put("logon failed in ClientPool");
         Trace::put(hMessage.buffer(),m);
         Log::put(hMessage.buffer(),hMessage.messageLength(),"S0000",CommonHeaderSegment::instance()->getServiceName().c_str());
         return send(strConversationID,hMessage);
      }
      else
      {
         Trace::put("logon succeeded in ClientPool");
         char* pSegmentID = hMessage.buffer() + 8;
         CommonHeaderSegment::instance()->deport(&pSegmentID);
      }
   }
   else
   if (CommonHeaderSegment::instance()->getServiceName() == "RLOGOFF")
   {
      if (CommonHeaderSegment::instance()->getResultCode() == 0)
      {
         ClientPool::instance()->logoff(strUserID);
         ServerPool::instance()->logoff(strUserID);
      }
      Log::put(hMessage.buffer(),hMessage.messageLength(),"S0000",CommonHeaderSegment::instance()->getServiceName().c_str());
      return send(strConversationID,hMessage);
   }
   else
   if (CommonHeaderSegment::instance()->getServiceName() == "RKEYXCHG")
   {
      Log::put(hMessage.buffer(),hMessage.messageLength(),"S0000",CommonHeaderSegment::instance()->getServiceName().c_str());
      return send(strConversationID,hMessage);
   }
   if (CommonHeaderSegment::instance()->getServiceName() == "RXRKEY")
   {
      Log::put(hMessage.buffer(),hMessage.messageLength(),"S0000",CommonHeaderSegment::instance()->getServiceName().c_str());
      return send(strConversationID,hMessage);
   }
   if (!ClientPool::instance()->isLoggedOn())
      return -1;
   int lTotalRecordsFound = 0;
   if (memcmp(pSegmentID,"S002",4) == 0)
   {
      m_pMultipleRowContextSegment->import(&pSegmentID);
      lTotalRecordsFound = m_pMultipleRowContextSegment->totalRecordsFound();
      if (m_pMultipleRowContextSegment->serverStateIndicator() != 'O')
         ClientPool::instance()->push(strUserID,hMessage,lTotalRecordsFound,strConversationID != IString("        "));
   }
   // send reply messages if conversation ID is valid (client is waiting)
   if (strConversationID != IString("        "))
   {
#ifndef CS
      Log::put(hMessage.buffer(),hMessage.messageLength(),"S0000",CommonHeaderSegment::instance()->getServiceName().c_str());
#endif
      char* p = strstr(hMessage.buffer(),"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
      if (p)
      {
         string strSecurityData(CommonHeaderSegment::instance()->getSecurityData());
         strSecurityData.resize(25,' ');
         memset(p,' ',36);
         unsigned char szCiphertext[109];
         memset(szCiphertext,' ',108);
         szCiphertext[108] = '\0';
         memcpy(szCiphertext,strSecurityData.data(),strSecurityData.length());
         memcpy(szCiphertext,CommonHeaderSegment::instance()->getUserID().data(),CommonHeaderSegment::instance()->getUserID().length());
         unsigned char szBase64text[109];
         memset(szBase64text,' ',108);
         szBase64text[108] = '\0';
         int i = securitywrapper::SecurityWrapper::EVP_EncodeBlock((unsigned char*)szBase64text,szCiphertext,25);
         memcpy(p,szBase64text,i);
      }
      return send(strConversationID,hMessage);
   }
   return 0;
  //## end ClientInterface::sendToClient%351908D80169.body
}

void ClientInterface::update (Subject* pSubject)
{
  //## begin ClientInterface::update%37D954D10384.body preserve=yes
   if (pSubject == Extract::instance())
   {
      m_strClientSecurity = "CLNTSEC ";
#ifdef MVS
      string strRecord;
      if (Extract::instance()->getRecord("DFILES  CLNTSEC ",strRecord))
         m_strClientSecurity = strRecord.substr(16,8);
#endif
      Extract::instance()->getSpec("CUSTOMER",m_strCustomerID);
      return;
   }
   else
   if (pSubject == &m_hTimer)
   {
      ClientPool::instance()->ageout();
      ClientRequest::purgeFreePool();
      m_hTimer.set(m_lHours);
      return;
   }
   else
   if (pSubject == MidnightAlarm::instance())
      ClientRequest::purgeFreePool();
   Application::update(pSubject);
  //## end ClientInterface::update%37D954D10384.body
}

// Additional Declarations
  //## begin ClientInterface%34567BA302DE.declarations preserve=yes
  //## end ClientInterface%34567BA302DE.declarations

//## begin module%3680026400D4.epilog preserve=yes
//## end module%3680026400D4.epilog
