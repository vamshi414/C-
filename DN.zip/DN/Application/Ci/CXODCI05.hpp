//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A5CB4800153.cm preserve=no
//	$Date:   Jun 22 2017 07:50:42  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3A5CB4800153.cm

//## begin module%3A5CB4800153.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A5CB4800153.cp

//## Module: CXOSCI05%3A5CB4800153; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI05.hpp

#ifndef CXOSCI05_h
#define CXOSCI05_h 1

//## begin module%3A5CB4800153.additionalIncludes preserve=no
//## end module%3A5CB4800153.additionalIncludes

//## begin module%3A5CB4800153.includes preserve=yes
//## end module%3A5CB4800153.includes

#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSIF37_h
#include "CXODIF37.hpp"
#endif

class ClientRequest;
class ClientInterface;
class ClientSession;

//## begin module%3A5CB4800153.declarations preserve=no
//## end module%3A5CB4800153.declarations

//## begin module%3A5CB4800153.additionalDeclarations preserve=yes
//## end module%3A5CB4800153.additionalDeclarations


//## begin ClientDisplayUsers%3A5CB30A001F.preface preserve=yes
//## end ClientDisplayUsers%3A5CB30A001F.preface

//## Class: ClientDisplayUsers%3A5CB30A001F
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3A5CB37001A2;ClientInterface { -> F}
//## Uses: <unnamed>%3A5CB3730016;ClientRequest { -> F}
//## Uses: <unnamed>%3A5CB3760010;ClientSession { -> F}

class ClientDisplayUsers : public ClientInterfaceVisitor  //## Inherits: <unnamed>%3A5CB3200233
{
  //## begin ClientDisplayUsers%3A5CB30A001F.initialDeclarations preserve=yes
  //## end ClientDisplayUsers%3A5CB30A001F.initialDeclarations

  public:
    //## Constructors (generated)
      ClientDisplayUsers();

    //## Destructor (generated)
      virtual ~ClientDisplayUsers();


    //## Other Operations (specified)
      //## Operation: visitClientInterface%3A5CB3350283
      virtual void visitClientInterface (ClientInterface* pClientInterface);

      //## Operation: visitClientRequest%3A5CB337036D
      virtual void visitClientRequest (ClientRequest* pClientRequest);

      //## Operation: visitClientSession%3A5CB3390315
      virtual void visitClientSession (ClientSession* pClientSession);

    // Additional Public Declarations
      //## begin ClientDisplayUsers%3A5CB30A001F.public preserve=yes
      //## end ClientDisplayUsers%3A5CB30A001F.public

  protected:
    // Additional Protected Declarations
      //## begin ClientDisplayUsers%3A5CB30A001F.protected preserve=yes
      //## end ClientDisplayUsers%3A5CB30A001F.protected

  private:
    // Additional Private Declarations
      //## begin ClientDisplayUsers%3A5CB30A001F.private preserve=yes
      //## end ClientDisplayUsers%3A5CB30A001F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Description%3A5CBEB301D9
      //## begin ClientDisplayUsers::Description%3A5CBEB301D9.attr preserve=no  private: char* {V} 0
      char* m_psDescription;
      //## end ClientDisplayUsers::Description%3A5CBEB301D9.attr

      //## Attribute: Rows%3A7A07610193
      //## begin ClientDisplayUsers::Rows%3A7A07610193.attr preserve=no  private: int {V} 0
      int m_lRows;
      //## end ClientDisplayUsers::Rows%3A7A07610193.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%3A5CBA2702D0
      //## Role: ClientDisplayUsers::<m_hResultSet>%3A5CBA2802B3
      //## begin ClientDisplayUsers::<m_hResultSet>%3A5CBA2802B3.role preserve=no  public: IF::ResultSet { -> VHgN}
      IF::ResultSet m_hResultSet;
      //## end ClientDisplayUsers::<m_hResultSet>%3A5CBA2802B3.role

    // Additional Implementation Declarations
      //## begin ClientDisplayUsers%3A5CB30A001F.implementation preserve=yes
      //## end ClientDisplayUsers%3A5CB30A001F.implementation

};

//## begin ClientDisplayUsers%3A5CB30A001F.postscript preserve=yes
//## end ClientDisplayUsers%3A5CB30A001F.postscript

//## begin module%3A5CB4800153.epilog preserve=yes
//## end module%3A5CB4800153.epilog


#endif
