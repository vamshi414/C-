//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A79C20C000B.cm preserve=no
//	$Date:   Jun 22 2017 07:41:58  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3A79C20C000B.cm

//## begin module%3A79C20C000B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A79C20C000B.cp

//## Module: CXOSCI16%3A79C20C000B; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI16.hpp

#ifndef CXOSCI16_h
#define CXOSCI16_h 1

//## begin module%3A79C20C000B.additionalIncludes preserve=no
//## end module%3A79C20C000B.additionalIncludes

//## begin module%3A79C20C000B.includes preserve=yes
//## end module%3A79C20C000B.includes

#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSIF37_h
#include "CXODIF37.hpp"
#endif

class SlowQuery;

//## begin module%3A79C20C000B.declarations preserve=no
//## end module%3A79C20C000B.declarations

//## begin module%3A79C20C000B.additionalDeclarations preserve=yes
//## end module%3A79C20C000B.additionalDeclarations


//## begin ClientDisplaySlowSQL%3A79C1070100.preface preserve=yes
//## end ClientDisplaySlowSQL%3A79C1070100.preface

//## Class: ClientDisplaySlowSQL%3A79C1070100
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3A79CAA800E6;SlowQuery { -> F}

class ClientDisplaySlowSQL : public ClientInterfaceVisitor  //## Inherits: <unnamed>%3A79C128007B
{
  //## begin ClientDisplaySlowSQL%3A79C1070100.initialDeclarations preserve=yes
  //## end ClientDisplaySlowSQL%3A79C1070100.initialDeclarations

  public:
    //## Constructors (generated)
      ClientDisplaySlowSQL();

    //## Destructor (generated)
      virtual ~ClientDisplaySlowSQL();


    //## Other Operations (specified)
      //## Operation: visitSlowQuery%3A79C2D30089
      virtual void visitSlowQuery (SlowQuery* pSlowQuery);

    // Additional Public Declarations
      //## begin ClientDisplaySlowSQL%3A79C1070100.public preserve=yes
      //## end ClientDisplaySlowSQL%3A79C1070100.public

  protected:
    // Additional Protected Declarations
      //## begin ClientDisplaySlowSQL%3A79C1070100.protected preserve=yes
      //## end ClientDisplaySlowSQL%3A79C1070100.protected

  private:
    // Additional Private Declarations
      //## begin ClientDisplaySlowSQL%3A79C1070100.private preserve=yes
      //## end ClientDisplaySlowSQL%3A79C1070100.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Description%3A79C2BC0393
      //## begin ClientDisplaySlowSQL::Description%3A79C2BC0393.attr preserve=no  private: char* {V} 0
      char* m_psDescription;
      //## end ClientDisplaySlowSQL::Description%3A79C2BC0393.attr

      //## Attribute: Rows%3A7ADCDB02AB
      //## begin ClientDisplaySlowSQL::Rows%3A7ADCDB02AB.attr preserve=no  private: int {V} 0
      int m_lRows;
      //## end ClientDisplaySlowSQL::Rows%3A7ADCDB02AB.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%3A79C27301CB
      //## Role: ClientDisplaySlowSQL::<m_hResultSet>%3A79C274008C
      //## begin ClientDisplaySlowSQL::<m_hResultSet>%3A79C274008C.role preserve=no  public: IF::ResultSet { -> VHgN}
      IF::ResultSet m_hResultSet;
      //## end ClientDisplaySlowSQL::<m_hResultSet>%3A79C274008C.role

    // Additional Implementation Declarations
      //## begin ClientDisplaySlowSQL%3A79C1070100.implementation preserve=yes
      //## end ClientDisplaySlowSQL%3A79C1070100.implementation

};

//## begin ClientDisplaySlowSQL%3A79C1070100.postscript preserve=yes
//## end ClientDisplaySlowSQL%3A79C1070100.postscript

//## begin module%3A79C20C000B.epilog preserve=yes
//## end module%3A79C20C000B.epilog


#endif
