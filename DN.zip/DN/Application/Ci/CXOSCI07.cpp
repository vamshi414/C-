//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A5F24CE00FD.cm preserve=no
//	$Date:   Jun 22 2017 07:57:34  $ $Author:   e1009839  $ $Revision:   1.5  $
//## end module%3A5F24CE00FD.cm

//## begin module%3A5F24CE00FD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A5F24CE00FD.cp

//## Module: CXOSCI07%3A5F24CE00FD; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI07.cpp

//## begin module%3A5F24CE00FD.additionalIncludes preserve=no
//## end module%3A5F24CE00FD.additionalIncludes

//## begin module%3A5F24CE00FD.includes preserve=yes
//## end module%3A5F24CE00FD.includes

#ifndef CXOSCI01_h
#include "CXODCI01.hpp"
#endif
#ifndef CXOSCI09_h
#include "CXODCI09.hpp"
#endif
#ifndef CXOSCI07_h
#include "CXODCI07.hpp"
#endif


//## begin module%3A5F24CE00FD.declarations preserve=no
//## end module%3A5F24CE00FD.declarations

//## begin module%3A5F24CE00FD.additionalDeclarations preserve=yes
#include "CXODRU32.hpp"
   struct sServerSQL
   {
      char sName[9];
      short int iNull1;
      char sMessage[65];
      short int iNull2;
   };
#include "CXODRU33.hpp"
//## end module%3A5F24CE00FD.additionalDeclarations


// Class ClientDisplayServerSQL 

ClientDisplayServerSQL::ClientDisplayServerSQL()
  //## begin ClientDisplayServerSQL::ClientDisplayServerSQL%3A5F231D0372_const.hasinit preserve=no
      : m_psDescription(0),
        m_lRows(0)
  //## end ClientDisplayServerSQL::ClientDisplayServerSQL%3A5F231D0372_const.hasinit
  //## begin ClientDisplayServerSQL::ClientDisplayServerSQL%3A5F231D0372_const.initialization preserve=yes
  //## end ClientDisplayServerSQL::ClientDisplayServerSQL%3A5F231D0372_const.initialization
{
  //## begin ClientDisplayServerSQL::ClientDisplayServerSQL%3A5F231D0372_const.body preserve=yes
   memcpy(m_sID,"CI07",4);
#include "CXODRU32.hpp"
   struct hDescription
   {
      char sColumnName[18];
      short int nDataType;
      int nPrecision;
      short int nScale;
   };
#include "CXODRU33.hpp"
   int j = 2;
   char* pszColumnName[2] = {"NAME","SQL"};
   int nPrecision[2] = {9,65};
   int k = 4 + (j * sizeof(struct hDescription));
   m_psDescription = new char[k];
   memset(m_psDescription,' ',k);
   memcpy(m_psDescription,&j,sizeof(int));
   hDescription* p = (hDescription*)(m_psDescription + 4);
   for (int i = 0;i < j;++i)
   {
      memcpy(p->sColumnName,pszColumnName[i],strlen(pszColumnName[i]));
      p->nDataType = 1;
      p->nPrecision = nPrecision[i];
      p->nScale = 0;
      ++p;
   }
  //## end ClientDisplayServerSQL::ClientDisplayServerSQL%3A5F231D0372_const.body
}


ClientDisplayServerSQL::~ClientDisplayServerSQL()
{
  //## begin ClientDisplayServerSQL::~ClientDisplayServerSQL%3A5F231D0372_dest.body preserve=yes
   if (m_lRows == 0)
   {
      struct sServerSQL hServerSQL;
      memset((char*)&hServerSQL,' ',sizeof(struct sServerSQL));
      memcpy(hServerSQL.sName,"NONE",4);
      m_hResultSet.addRow(m_psDescription,(char*)&hServerSQL);
   }
   m_hResultSet.close();
   delete [] m_psDescription;
  //## end ClientDisplayServerSQL::~ClientDisplayServerSQL%3A5F231D0372_dest.body
}



//## Other Operations (implementation)
void ClientDisplayServerSQL::visitServer (Server* pServer)
{
  //## begin ClientDisplayServerSQL::visitServer%3A6621BB00EC.body preserve=yes
   struct sServerSQL hServerSQL;
   int k = (pServer->getName().length() > 8) ? 8 : pServer->getName().length();
   int j;
   size_t pos = 0;
   int i = pServer->getSQL().length();
   while (i > 0)
   {
      memset((char*)&hServerSQL,' ',sizeof(struct sServerSQL));
      memcpy(hServerSQL.sName,pServer->getName().data(),k);
      j = (i > 64) ? 64 : i;
      memcpy(hServerSQL.sMessage,pServer->getSQL().data() + pos,j);
      m_hResultSet.addRow(m_psDescription,(char*)&hServerSQL);
      ++m_lRows;
      pos += j;
      i -= j;
   }
  //## end ClientDisplayServerSQL::visitServer%3A6621BB00EC.body
}

// Additional Declarations
  //## begin ClientDisplayServerSQL%3A5F231D0372.declarations preserve=yes
  //## end ClientDisplayServerSQL%3A5F231D0372.declarations

//## begin module%3A5F24CE00FD.epilog preserve=yes
//## end module%3A5F24CE00FD.epilog
