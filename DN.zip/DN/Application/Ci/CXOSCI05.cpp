//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A5CB48102EF.cm preserve=no
//	$Date:   Jun 23 2017 16:08:46  $ $Author:   e1009839  $ $Revision:   1.8  $
//## end module%3A5CB48102EF.cm

//## begin module%3A5CB48102EF.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A5CB48102EF.cp

//## Module: CXOSCI05%3A5CB48102EF; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI05.cpp

//## begin module%3A5CB48102EF.additionalIncludes preserve=no
//## end module%3A5CB48102EF.additionalIncludes

//## begin module%3A5CB48102EF.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%3A5CB48102EF.includes

#ifndef CXOPCI00_h
#include "CXODCI00.hpp"
#endif
#ifndef CXOSCI03_h
#include "CXODCI03.hpp"
#endif
#ifndef CXOSCI01_h
#include "CXODCI01.hpp"
#endif
#ifndef CXOSCI05_h
#include "CXODCI05.hpp"
#endif


//## begin module%3A5CB48102EF.declarations preserve=no
//## end module%3A5CB48102EF.declarations

//## begin module%3A5CB48102EF.additionalDeclarations preserve=yes
#include "CXODRU32.hpp"
   struct sSession
   {
      char sLastRequest[12];
      short int iNull0;
      char sUserID[9];
      short int iNull1;
      int lRequests;
      short int iNull2;
      int lQueueTime;
      short int iNull3;
      int lProcessTime;
      short int iNull4;
      int lCacheCount;
      short int iNull5;
      int lCacheSize;
      short int iNull6;
   };
#include "CXODRU33.hpp"
//## end module%3A5CB48102EF.additionalDeclarations


// Class ClientDisplayUsers 

ClientDisplayUsers::ClientDisplayUsers()
  //## begin ClientDisplayUsers::ClientDisplayUsers%3A5CB30A001F_const.hasinit preserve=no
      : m_psDescription(0),
        m_lRows(0)
  //## end ClientDisplayUsers::ClientDisplayUsers%3A5CB30A001F_const.hasinit
  //## begin ClientDisplayUsers::ClientDisplayUsers%3A5CB30A001F_const.initialization preserve=yes
  //## end ClientDisplayUsers::ClientDisplayUsers%3A5CB30A001F_const.initialization
{
  //## begin ClientDisplayUsers::ClientDisplayUsers%3A5CB30A001F_const.body preserve=yes
   memcpy(m_sID,"CI05",4);
#include "CXODRU32.hpp"
   struct hDescription
   {
      char sColumnName[18];
      short int nDataType;
      int nPrecision;
      short int nScale;
   };
#include "CXODRU33.hpp"
   int j = 7;
   char* pszColumnName[7] = {"LASTREQUEST","USERID","REQUESTS","QUEUE","PROCESS","CACHECOUNT","CACHESIZE"};
   int nPrecision[7] = {12,9,0,0,0,0,0};
   int k = 4 + (j * sizeof(struct hDescription));
   m_psDescription = new char[k];
   memset(m_psDescription,' ',k);
   memcpy(m_psDescription,&j,sizeof(int));
   hDescription* p = (hDescription*)(m_psDescription + 4);
   for (int i = 0;i < j;++i)
   {
      memcpy(p->sColumnName,pszColumnName[i],strlen(pszColumnName[i]));
      if (nPrecision[i] == 0)
      {
         p->nDataType = htons(4);
         p->nPrecision = htonl(4);
      }
      else
      {
         p->nDataType = htons(1);
         p->nPrecision = htonl(nPrecision[i]);
      }
      p->nScale = htons(0);
      ++p;
   }
  //## end ClientDisplayUsers::ClientDisplayUsers%3A5CB30A001F_const.body
}


ClientDisplayUsers::~ClientDisplayUsers()
{
  //## begin ClientDisplayUsers::~ClientDisplayUsers%3A5CB30A001F_dest.body preserve=yes
   if (m_lRows == 0)
   {
      struct sSession hSession;
      memset((char*)&hSession,' ',sizeof(struct sSession));
      memcpy(hSession.sUserID,"NONE",4);
      hSession.lRequests = htonl(0);
      hSession.lQueueTime = htonl(0);
      hSession.lProcessTime = htonl(0);
      hSession.lCacheCount = htonl(0);
      hSession.lCacheSize = htonl(0);
      m_hResultSet.addRow(m_psDescription,(char*)&hSession);
   }
   m_hResultSet.close();
   delete [] m_psDescription;
  //## end ClientDisplayUsers::~ClientDisplayUsers%3A5CB30A001F_dest.body
}



//## Other Operations (implementation)
void ClientDisplayUsers::visitClientInterface (ClientInterface* pClientInterface)
{
  //## begin ClientDisplayUsers::visitClientInterface%3A5CB3350283.body preserve=yes
  //## end ClientDisplayUsers::visitClientInterface%3A5CB3350283.body
}

void ClientDisplayUsers::visitClientRequest (ClientRequest* pClientRequest)
{
  //## begin ClientDisplayUsers::visitClientRequest%3A5CB337036D.body preserve=yes
  //## end ClientDisplayUsers::visitClientRequest%3A5CB337036D.body
}

void ClientDisplayUsers::visitClientSession (ClientSession* pClientSession)
{
  //## begin ClientDisplayUsers::visitClientSession%3A5CB3390315.body preserve=yes
   struct sSession hSession;
   memset((char*)&hSession,' ',sizeof(struct sSession));
   string strDateTime(pClientSession->getLastRequestTimestamp().data()+4,8);
   strDateTime.insert(2, "/", 1);
   strDateTime.insert(5, " ", 1);
   strDateTime.insert(8, ":", 1);
   memcpy(hSession.sLastRequest,strDateTime.data(),11);
   int i = (pClientSession->getUserID().length() > 8) ? 8 : pClientSession->getUserID().length();
   memcpy(hSession.sUserID,pClientSession->getUserID().data(),i);
   hSession.lRequests = htonl(pClientSession->getRequests());
   if (hSession.lRequests > 0)
   {
      hSession.lQueueTime = htonl(pClientSession->getQueueTime() / hSession.lRequests);
      hSession.lProcessTime = htonl(pClientSession->getProcessTime() / hSession.lRequests);
   }
   else
   {
      hSession.lQueueTime = htonl(0);
      hSession.lProcessTime = htonl(0);
   }
   hSession.lCacheCount = htonl(pClientSession->getCacheCount());
   hSession.lCacheSize = htonl(pClientSession->getCacheSize());
   m_hResultSet.addRow(m_psDescription,(char*)&hSession);
   ++m_lRows;
  //## end ClientDisplayUsers::visitClientSession%3A5CB3390315.body
}

// Additional Declarations
  //## begin ClientDisplayUsers%3A5CB30A001F.declarations preserve=yes
  //## end ClientDisplayUsers%3A5CB30A001F.declarations

//## begin module%3A5CB48102EF.epilog preserve=yes
//## end module%3A5CB48102EF.epilog

