//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3A5CB0E10359.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3A5CB0E10359.cm

//## begin module%3A5CB0E10359.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3A5CB0E10359.cp

//## Module: CXOSCI04%3A5CB0E10359; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ci\CXODCI04.hpp

#ifndef CXOSCI04_h
#define CXOSCI04_h 1

//## begin module%3A5CB0E10359.additionalIncludes preserve=no
//## end module%3A5CB0E10359.additionalIncludes

//## begin module%3A5CB0E10359.includes preserve=yes
// $Date:   Apr 07 2004 15:03:06  $ $Author:   D98833  $ $Revision:   1.3  $
//## end module%3A5CB0E10359.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%3A5CB0E10359.declarations preserve=no
//## end module%3A5CB0E10359.declarations

//## begin module%3A5CB0E10359.additionalDeclarations preserve=yes
//## end module%3A5CB0E10359.additionalDeclarations


//## begin ClientInterfaceVisitor%3A5CB08D039E.preface preserve=yes
class ClientInterface;
class ClientPool;
class ClientRequest;
class ClientSession;
class QueuedRequest;
class Server;
class ServerPool;
class SlowQuery;
//## end ClientInterfaceVisitor%3A5CB08D039E.preface

//## Class: ClientInterfaceVisitor%3A5CB08D039E
//## Category: DataNavigator Foundation::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class ClientInterfaceVisitor : public reusable::Object  //## Inherits: <unnamed>%3A5CB0A803A7
{
  //## begin ClientInterfaceVisitor%3A5CB08D039E.initialDeclarations preserve=yes
  //## end ClientInterfaceVisitor%3A5CB08D039E.initialDeclarations

  public:
    //## Constructors (generated)
      ClientInterfaceVisitor();

    //## Destructor (generated)
      virtual ~ClientInterfaceVisitor();


    //## Other Operations (specified)
      //## Operation: visitClientInterface%3A5CB19A0015
      virtual void visitClientInterface (ClientInterface* pClientInterface);

      //## Operation: visitClientPool%3A6C81670258
      void visitClientPool (ClientPool* pClientPool);

      //## Operation: visitClientRequest%3A5CB1EE00D4
      virtual void visitClientRequest (ClientRequest* pClientRequest);

      //## Operation: visitClientSession%3A5CB20B01EF
      virtual void visitClientSession (ClientSession* pClientSession);

      //## Operation: visitQueuedRequest%3A608C170277
      virtual void visitQueuedRequest (QueuedRequest* pQueuedRequest);

      //## Operation: visitServer%3A606894009E
      virtual void visitServer (Server* pServer);

      //## Operation: visitServerPool%3A60689D008D
      virtual void visitServerPool (ServerPool* pServerPool);

      //## Operation: visitSlowQuery%3A7996000332
      virtual void visitSlowQuery (SlowQuery* pSlowQuery);

      //## Operation: visitTrace%3A7C4FAB02D1
      virtual void visitTrace (string* pText);

    // Additional Public Declarations
      //## begin ClientInterfaceVisitor%3A5CB08D039E.public preserve=yes
      //## end ClientInterfaceVisitor%3A5CB08D039E.public

  protected:
    // Additional Protected Declarations
      //## begin ClientInterfaceVisitor%3A5CB08D039E.protected preserve=yes
      //## end ClientInterfaceVisitor%3A5CB08D039E.protected

  private:
    // Additional Private Declarations
      //## begin ClientInterfaceVisitor%3A5CB08D039E.private preserve=yes
      //## end ClientInterfaceVisitor%3A5CB08D039E.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin ClientInterfaceVisitor%3A5CB08D039E.implementation preserve=yes
      //## end ClientInterfaceVisitor%3A5CB08D039E.implementation

};

//## begin ClientInterfaceVisitor%3A5CB08D039E.postscript preserve=yes
//## end ClientInterfaceVisitor%3A5CB08D039E.postscript

//## begin module%3A5CB0E10359.epilog preserve=yes
//## end module%3A5CB0E10359.epilog


#endif
