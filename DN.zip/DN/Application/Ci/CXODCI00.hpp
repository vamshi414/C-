//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3680026201FE.cm preserve=no
//## end module%3680026201FE.cm

//## begin module%3680026201FE.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3680026201FE.cp

//## Module: CXOPCI00%3680026201FE; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI00.hpp

#ifndef CXOPCI00_h
#define CXOPCI00_h 1

//## begin module%3680026201FE.additionalIncludes preserve=no
//## end module%3680026201FE.additionalIncludes

//## begin module%3680026201FE.includes preserve=yes
#include <map>
#include <vector>
#define CM_SEND_AND_DEALLOCATE 0
#define CM_SEND_AND_PREP_TO_RECEIVE 0
//## end module%3680026201FE.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
} // namespace segment

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Mask;
class Buffer;
class CriticalSection;
class Signal;
class Format;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Log;
} // namespace IF

namespace timer {
class Clock;
} // namespace timer

namespace IF {
class Sleep;
class ResultSet;
class QueueFactory;
class Queue;
class CodeTable;
class DateTime;
class AdvancedEncryptionStandard;
class SocketQueue;
class Extract;
class SecureSocketQueue;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace segment {
class TextSegment;
} // namespace segment

namespace database {
class DatabaseFactory;
class AESKeyManager;
} // namespace database

namespace segment {
class Segment;
class ResponseTimeSegment;
class MultipleRowContextSegment;
class CommonHeaderSegment;
} // namespace segment

//## Modelname: Connex Library::ViewSegment_CAT%394E276801C1
namespace viewsegment {
class ReportOptionSegment;
} // namespace viewsegment

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class LogonSegment;
class KeyExchangeSegment;
class AuthenticateSegment;
class ResourceListSegment;
} // namespace usersegment

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;
} // namespace platform

class ClientDisplayTrace;
class ClientDisplaySlowSQL;
class ClientDisplaySlowRequests;
class ClientPool;
class ClientDisplayQueue;
class ClientDisplayServers;
class ServerPool;
class ClientDisplayServerSQL;
class ClientDisplayServerRequest;
class ClientDisplayUsers;
class ClientInterfaceVisitor;
class ClientRequest;
class ConfigurationFile;

//## begin module%3680026201FE.declarations preserve=no
//## end module%3680026201FE.declarations

//## begin module%3680026201FE.additionalDeclarations preserve=yes
#ifndef MVS
namespace IF {
class SocketQueue;
} // namespace IF
#endif
//## end module%3680026201FE.additionalDeclarations


//## begin ClientInterface%34567BA302DE.preface preserve=yes
//## end ClientInterface%34567BA302DE.preface

//## Class: ClientInterface%34567BA302DE
//	<body>
//	<title>IG
//	<h1>HG
//	<h2>AB
//	<h3>Setup
//	<p>
//	The DataNavigator Client is installed for each end user
//	of DataNavigator.
//	<ol>
//	<li>Install the DataNavigator Client using the Data
//	Navigator Client CD
//	<li>Start ... Programs ... DataNavigator ... Data
//	Navigator
//	<li>Use the Connections ... dialog to define a
//	connection:
//	<ul>
//	<li>Connection Name: <i>customer</i>
//	<li>Connection ID: <i>customer</i>
//	<li>Server Name: <i>proc</i>
//	<li>Server Port: <i>portprod</i>
//	</ul>
//	<li>Logon to DataNavigator specifying the User ID and
//	Password established in Security
//	</ol>
//	</p>
//	<h2>FI
//	<h3>Installation prerequisites
//	<p>
//	The DataNavigator Client requires the following:
//	<ul>
//	<li>Microsoft Windows 2000 or XP
//	<li>End user defined in DataNavigator Security
//	</ul>
//	</p>
//	<h2>FO
//	<h3>Results of installation
//	<p>
//	The following items are established during installation:
//	<ul>
//	<li>Program group: DataNavigator
//	<li>C:\Program Files\eFunds\DataNavigator
//	<li>C:\Program Files\eFunds\DataNavigator\<i>customer</i>
//	</ul>
//	</p>
//	<title>CG
//	<h1>CI
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Client Interface service (<i>ca</i>CI01) provides
//	the gateway to all end user services provided by the Data
//	Navigator Server.
//	</p>
//	<img src=CXOCCI00.gif>
//	<title>OG
//	<h1>CI
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Client Interface service (<i>ca</i>CI01) provides
//	the gateway to all end user services provided by the Data
//	Navigator Server.
//	<p>
//	All services (e.g. Generic Maintenance) that process
//	client requests publish those requests to allow the
//	Client Interface to distribute work as it is received.
//	Requests from end users are queued and dispatched by the
//	Client Interface based on the current state of each
//	available service.
//	<p>
//	The services that are available to the Client Interface
//	are shown in the <i>customer</i> : Clients : Services
//	folder in the Operator Console:
//	</p>
//	<img src=CXOOCI00.gif>
//	<h2>TS
//	<h3>Tips
//	<p>
//	Use the Operator Console to verify the state of the
//	Client Interface service:
//	<p>
//	<table>
//	<tr>
//	<th>Operator Console
//	<th>Symptom
//	<th>Resolution
//	<tr>
//	<td>Services
//	<td><i>ca</i>CI01 State: STOPPED or UNKNOWN
//	<td>Start the service
//	<tr>
//	<td>Clients : <i>customer</i> : Services
//	<td>A service (e.g. <i>ca</i>GM) missing from the list
//	<td>Start the missing service
//	<tr>
//	<td>Health : Client
//	<td>Any <i>ca</i>CI01 statistic with a non-zero Failure
//	count
//	<td>Trace the service to determine the cause
//	</table>
//	</body>
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1



//## Uses: <unnamed>%37D963BD0251;IF::CodeTable { -> F}
//## Uses: <unnamed>%37D963C60330;IF::DateTime { -> F}
//## Uses: <unnamed>%37D963CC014E;IF::Extract { -> F}
//## Uses: <unnamed>%37D963CF00C6;IF::Message { -> F}
//## Uses: <unnamed>%37D963D80097;IF::Trace { -> F}
//## Uses: <unnamed>%37D9765601FD;IF::Log { -> F}
//## Uses: <unnamed>%37DFC17700FA;timer::Clock { -> F}
//## Uses: <unnamed>%37E12D54030E;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%3A26A2B400F2;monitor::UseCase { -> F}
//## Uses: <unnamed>%3A5CB5130385;ClientDisplayUsers { -> F}
//## Uses: <unnamed>%3A5F3389009C;ClientDisplayServerRequest { -> F}
//## Uses: <unnamed>%3A5F338B01B7;ClientDisplayServerSQL { -> F}
//## Uses: <unnamed>%3A605CDC03D9;ServerPool { -> F}
//## Uses: <unnamed>%3A6070A50025;ClientDisplayServers { -> F}
//## Uses: <unnamed>%3A62FD7E0231;ClientDisplayQueue { -> F}
//## Uses: <unnamed>%3A69B9C9034B;IF::Queue { -> F}
//## Uses: <unnamed>%3A6DB4A80133;ClientPool { -> F}
//## Uses: <unnamed>%3A6DB5640093;ClientInterfaceVisitor { -> F}
//## Uses: <unnamed>%3A79CDF5002D;ClientDisplaySlowRequests { -> F}
//## Uses: <unnamed>%3A79D2FA0107;ClientDisplaySlowSQL { -> F}
//## Uses: <unnamed>%3A7C5542013E;ClientDisplayTrace { -> F}
//## Uses: <unnamed>%3B5D6AC401B5;usersegment::ResourceListSegment { -> F}
//## Uses: <unnamed>%3E8B536A030D;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%3F6A0E9B002B;database::Database { -> F}
//## Uses: <unnamed>%3F6A0EAE0155;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%40AA6DD903C8;platform::Platform { -> F}
//## Uses: <unnamed>%45B63436032C;ClientRequest { -> F}
//## Uses: <unnamed>%4E9845060141;IF::ResultSet { -> F}
//## Uses: <unnamed>%4E9845390345;viewsegment::ReportOptionSegment { -> F}
//## Uses: <unnamed>%4E9845520180;reusable::Mask { -> F}
//## Uses: <unnamed>%4E984823012A;IF::QueueFactory { -> F}
//## Uses: <unnamed>%4E98484B03BB;reusable::Buffer { -> F}
//## Uses: <unnamed>%651C0CE60363;IF::SecureSocketQueue { -> F}
//## Uses: <unnamed>%651C0D07006C;IF::Sleep { -> F}
//## Uses: <unnamed>%651C0D4A01AC;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%651C0D83034C;database::AESKeyManager { -> F}
//## Uses: <unnamed>%651C0DF4010D;IF::AdvancedEncryptionStandard { -> F}
//## Uses: <unnamed>%652FC7E7018F;reusable::Format { -> F}

class ClientInterface : public process::Application  //## Inherits: <unnamed>%59359F410007
{
  //## begin ClientInterface%34567BA302DE.initialDeclarations preserve=yes
  //## end ClientInterface%34567BA302DE.initialDeclarations

  public:
    //## Constructors (generated)
      ClientInterface();

    //## Destructor (generated)
      virtual ~ClientInterface();


    //## Other Operations (specified)
      //## Operation: accept%3A5CB7D60006
      void accept (ClientInterfaceVisitor& hClientInterfaceVisitor);

      //## Operation: initialize%37D954BF0270
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>CI
      //	<h2>MS
      //	<h3>TCP/IP Port Number
      //	<p>
      //	By default, the Client Interface service accepts
      //	connections from DataNavigator clients on port 51000.
      //	This value is specified in the Application ID in the
      //	Task definition for the Client Interface service.
      //	<p>
      //	<img src=CXOCCI01.gif>
      //	<p>
      //	If desired, use the CR Client for the DataNavigator
      //	Server to change this value to comply with your
      //	installation standards.
      //	For a multiple switch configuration:  if more than one
      //	Client Interface service executes on the same
      //	application server, each must have a unique port number.
      //	<h3>Virtual LAN
      //	<p>
      //	By default, the Client Interface service listens on a
      //	single port at one TCP/IP address.
      //	This port is used for connection from the DataNavigator
      //	web client, the MMC console and other DataNavigator
      //	server tasks (e.g. Query Engine(s)).
      //	You can configure a second TCP/IP address and port
      //	number to listen separately for connections from the Data
      //	Navigator web client.
      //	This value is specified in the User Data in the Task
      //	definition for the Client Interface service.
      //	It must contain three comma-delimited values:
      //	<ol>
      //	<li>Name
      //	<li>TCP/IP address or DNS name
      //	<li>Port number
      //	</ol>
      //	For example:  VLAN,10.20.30.40,51000
      //	<p>
      //	<img src=CXOCCI01.gif>
      //	<p>
      //	If desired, use the CR Client for the DataNavigator
      //	Server to configure the virtual LAN TCP/IP address and
      //	port number.
      //	</body>
      virtual int initialize ();

      //## Operation: respond%37D954E800DF
      virtual bool respond (Message& hMessage);

      //## Operation: send%3E9EAAF90261
      bool send (const char* psConversationID, Message& hMessage);

      //## Operation: update%37D954D10384
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin ClientInterface%34567BA302DE.public preserve=yes
      //## end ClientInterface%34567BA302DE.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%37D954DD0350
      //## Postconditions:
      //	<body>
      //	<title>OG
      //	<h1>CI
      //	<h2>TS
      //	<h3>Client Messages
      //	<p>
      //	The Client Interface logs all messages that are
      //	exchanged between the DataNavigator server and end users.
      //	The logged messages can be used to help solve problems
      //	reported by end users.
      //	<p>
      //	See the description of the Logger service in the
      //	Foundation Configuration guide for more information on
      //	log files.
      //	</p>
      //	</body>
      virtual int onMessage (Message& hMessage);

      //## Operation: onNotify%3A69B9D001A6
      virtual int onNotify (const char* pszQueueName);

    // Additional Protected Declarations
      //## begin ClientInterface%34567BA302DE.protected preserve=yes
      //## end ClientInterface%34567BA302DE.protected

  private:

    //## Other Operations (specified)
      //## Operation: forceLogoff%3DDE315E0196
      int forceLogoff (Message& hMessage);

      //## Operation: onDisconnect%38E26AED039F
      virtual int onDisconnect (IF::Message& hMessage);

      //## Operation: parse%351908960291
      int parse (Message& hMessage);

      //## Operation: requestConfigurationData%3519089B034C
      int requestConfigurationData (Message& hMessage);

      //## Operation: requestCRData%351908A202A2
      int requestCRData (Message& hMessage);

      //## Operation: requestHandshake%351908AB015A
      int requestHandshake (Message& hMessage);

      //## Operation: requestHTTP%652ED75B01A5
      int requestHTTP (Message& hMessage);

      //## Operation: requestKey%556E0B0400E7
      int requestKey (Message& hMessage);

      //## Operation: requestKeyExchange%490B4A5E0210
      int requestKeyExchange (Message& hMessage);

      //## Operation: requestLogoff%351908B103DA
      int requestLogoff (Message& hMessage);

      //## Operation: requestLogon%351908B700D5
      int requestLogon (Message& hMessage);

      //## Operation: requestOther%37D9539E026B
      int requestOther (Message& hMessage);

      //## Operation: requestResource%3B5D6AE90232
      int requestResource (Message &hMessage);

      //## Operation: requestSecurityData%351908BC010F
      int requestSecurityData (Message& hMessage);

      //## Operation: requestXT%64B543570324
      int requestXT (Message& hMessage);

      //## Operation: saveRelationship%37D953F2022F
      void saveRelationship (Message& hMessage);

      //## Operation: sendError%351908D2021F
      int sendError (Message& hMessage, int iResultCode, char sSeverityLevel, int lInfoIDNumber);

      //## Operation: sendToClient%351908D80169
      int sendToClient (Message& hMessage);

    // Additional Private Declarations
      //## begin ClientInterface%34567BA302DE.private preserve=yes
      //## end ClientInterface%34567BA302DE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ASCII%3532132803DB
      //## begin ClientInterface::ASCII%3532132803DB.attr preserve=no  private: bool {V} false
      bool m_bASCII;
      //## end ClientInterface::ASCII%3532132803DB.attr

      //## Attribute: ClientSecurity%353212CC020C
      //## begin ClientInterface::ClientSecurity%353212CC020C.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strClientSecurity;
      //## end ClientInterface::ClientSecurity%353212CC020C.attr

      //## Attribute: CustomerID%37D95D0C0153
      //## begin ClientInterface::CustomerID%37D95D0C0153.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strCustomerID;
      //## end ClientInterface::CustomerID%37D95D0C0153.attr

      //## Attribute: Hours%3DFF6FA003C8
      //## begin ClientInterface::Hours%3DFF6FA003C8.attr preserve=no  private: int {U} 0
      int m_lHours;
      //## end ClientInterface::Hours%3DFF6FA003C8.attr

      //## Attribute: SegmentID%3532132D039C
      //## begin ClientInterface::SegmentID%3532132D039C.attr preserve=no  private: char {R} 0
      char *m_pSegmentID;
      //## end ClientInterface::SegmentID%3532132D039C.attr

      //## Attribute: URL%651C0C7100E8
      //## begin ClientInterface::URL%651C0C7100E8.attr preserve=no  private: map<string,string,less<string> > {V} 
      map<string,string,less<string> > m_hURL;
      //## end ClientInterface::URL%651C0C7100E8.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%37D95E490145
      //## Role: ClientInterface::<m_hSegments>%37D95E49039E
      //## begin ClientInterface::<m_hSegments>%37D95E49039E.role preserve=no  public: segment::Segment {1 -> 0..nRFHgN}
      vector<segment::Segment*> m_hSegments;
      //## end ClientInterface::<m_hSegments>%37D95E49039E.role

      //## Association: Connex Application::Client_CAT::<unnamed>%37D961DB0370
      //## Role: ClientInterface::<m_pInformationSegment>%37D961DC019B
      //## begin ClientInterface::<m_pInformationSegment>%37D961DC019B.role preserve=no  public: segment::InformationSegment { -> RFHgN}
      segment::InformationSegment *m_pInformationSegment;
      //## end ClientInterface::<m_pInformationSegment>%37D961DC019B.role

      //## Association: Connex Application::Client_CAT::<unnamed>%37D961DE0220
      //## Role: ClientInterface::<m_pLogonSegment>%37D961DF00AF
      //## begin ClientInterface::<m_pLogonSegment>%37D961DF00AF.role preserve=no  public: usersegment::LogonSegment { -> RFHgN}
      usersegment::LogonSegment *m_pLogonSegment;
      //## end ClientInterface::<m_pLogonSegment>%37D961DF00AF.role

      //## Association: Connex Application::Client_CAT::<unnamed>%37D961E103B5
      //## Role: ClientInterface::<m_pMultipleRowContextSegment>%37D961E20258
      //## begin ClientInterface::<m_pMultipleRowContextSegment>%37D961E20258.role preserve=no  public: segment::MultipleRowContextSegment { -> RFHgN}
      segment::MultipleRowContextSegment *m_pMultipleRowContextSegment;
      //## end ClientInterface::<m_pMultipleRowContextSegment>%37D961E20258.role

      //## Association: Connex Application::Client_CAT::<unnamed>%37D963940003
      //## Role: ClientInterface::<m_pResponseTimeSegment>%37D9639402B6
      //## begin ClientInterface::<m_pResponseTimeSegment>%37D9639402B6.role preserve=no  public: segment::ResponseTimeSegment { -> RFHgN}
      segment::ResponseTimeSegment *m_pResponseTimeSegment;
      //## end ClientInterface::<m_pResponseTimeSegment>%37D9639402B6.role

      //## Association: Connex Application::Client_CAT::<unnamed>%3DF4EAD4037A
      //## Role: ClientInterface::<m_hTimer>%3DF4EAD502DE
      //## begin ClientInterface::<m_hTimer>%3DF4EAD502DE.role preserve=no  public: timer::Timer { -> VHgN}
      timer::Timer m_hTimer;
      //## end ClientInterface::<m_hTimer>%3DF4EAD502DE.role

      //## Association: Connex Application::Client_CAT::<unnamed>%432BBDD2007D
      //## Role: ClientInterface::<m_hMessage>%432BBDD203A9
      //## begin ClientInterface::<m_hMessage>%432BBDD203A9.role preserve=no  public: IF::Message { -> VHgN}
      IF::Message m_hMessage;
      //## end ClientInterface::<m_hMessage>%432BBDD203A9.role

      //## Association: Connex Application::Client_CAT::<unnamed>%490F3B880122
      //## Role: ClientInterface::<m_pKeyExchangeSegment>%490F3B8903A4
      //## begin ClientInterface::<m_pKeyExchangeSegment>%490F3B8903A4.role preserve=no  public: usersegment::KeyExchangeSegment { -> RFHgN}
      usersegment::KeyExchangeSegment *m_pKeyExchangeSegment;
      //## end ClientInterface::<m_pKeyExchangeSegment>%490F3B8903A4.role

      //## Association: Connex Application::Client_CAT::<unnamed>%497F6DCA00B1
      //## Role: ClientInterface::<m_pAuthenticateSegment>%497F6DCB00BD
      //## begin ClientInterface::<m_pAuthenticateSegment>%497F6DCB00BD.role preserve=no  public: usersegment::AuthenticateSegment { -> RFHgN}
      usersegment::AuthenticateSegment *m_pAuthenticateSegment;
      //## end ClientInterface::<m_pAuthenticateSegment>%497F6DCB00BD.role

      //## Association: Connex Application::Client_CAT::<unnamed>%556E06F6007E
      //## Role: ClientInterface::<m_pTextSegment>%556E06F701BF
      //## begin ClientInterface::<m_pTextSegment>%556E06F701BF.role preserve=no  public: segment::TextSegment { -> RFHgN}
      segment::TextSegment *m_pTextSegment;
      //## end ClientInterface::<m_pTextSegment>%556E06F701BF.role

      //## Association: Connex Application::Client_CAT::<unnamed>%5B50D17F00DA
      //## Role: ClientInterface::<m_pConfigurationFile>%5B50D180013D
      //## begin ClientInterface::<m_pConfigurationFile>%5B50D180013D.role preserve=no  public: ConfigurationFile { -> RFHgN}
      ConfigurationFile *m_pConfigurationFile;
      //## end ClientInterface::<m_pConfigurationFile>%5B50D180013D.role

      //## Association: Connex Application::Client_CAT::<unnamed>%64B543E00172
      //## Role: ClientInterface::<m_pSocketSignal>%64B543E10250
      //## begin ClientInterface::<m_pSocketSignal>%64B543E10250.role preserve=no  public: reusable::Signal { -> 2RFHgN}
      reusable::Signal *m_pSocketSignal[2];
      //## end ClientInterface::<m_pSocketSignal>%64B543E10250.role

      //## Association: Connex Application::Client_CAT::<unnamed>%64B543E900CF
      //## Role: ClientInterface::<m_pSocketQueue>%64B543EA0196
      //## begin ClientInterface::<m_pSocketQueue>%64B543EA0196.role preserve=no  public: IF::SocketQueue { -> 2RFHgN}
      IF::SocketQueue *m_pSocketQueue[2];
      //## end ClientInterface::<m_pSocketQueue>%64B543EA0196.role

    // Additional Implementation Declarations
      //## begin ClientInterface%34567BA302DE.implementation preserve=yes
      string m_strServId;
      //## end ClientInterface%34567BA302DE.implementation

};

//## begin ClientInterface%34567BA302DE.postscript preserve=yes
//## end ClientInterface%34567BA302DE.postscript

//## begin module%3680026201FE.epilog preserve=yes
//## end module%3680026201FE.epilog


#endif
