//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%37DE6F4002DF.cm preserve=no
//	$Date$ $Author$ $Revision$
//## end module%37DE6F4002DF.cm

//## begin module%37DE6F4002DF.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%37DE6F4002DF.cp

//## Module: CXOSCI03%37DE6F4002DF; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI03.hpp

#ifndef CXOSCI03_h
#define CXOSCI03_h 1

//## begin module%37DE6F4002DF.additionalIncludes preserve=no
//## end module%37DE6F4002DF.additionalIncludes

//## begin module%37DE6F4002DF.includes preserve=yes
#include <vector>
#include "CXODIF11.hpp"
//## end module%37DE6F4002DF.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;
class CodeTable;
class Message;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class MultipleRowContextSegment;
} // namespace segment

class ClientInterfaceVisitor;

//## begin module%37DE6F4002DF.declarations preserve=no
//## end module%37DE6F4002DF.declarations

//## begin module%37DE6F4002DF.additionalDeclarations preserve=yes
//## end module%37DE6F4002DF.additionalDeclarations


//## begin ClientRequest%37DE6D170103.preface preserve=yes
//## end ClientRequest%37DE6D170103.preface

//## Class: ClientRequest%37DE6D170103
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%37F907D5020E;segment::MultipleRowContextSegment { -> F}
//## Uses: <unnamed>%37FB270900EE;IF::CodeTable { -> F}
//## Uses: <unnamed>%3A5CB83C012F;ClientInterfaceVisitor { -> F}
//## Uses: <unnamed>%3E85D324000F;timer::Clock { -> F}
//## Uses: <unnamed>%3E9ECB2B005D;IF::Trace { -> F}
//## Uses: <unnamed>%45B6318003B9;IF::Message { -> F}
//## Uses: <unnamed>%5939498A03C9;IF::Queue { -> F}

class ClientRequest : public reusable::Object  //## Inherits: <unnamed>%37DE6D34021D
{
  //## begin ClientRequest%37DE6D170103.initialDeclarations preserve=yes
  //## end ClientRequest%37DE6D170103.initialDeclarations

  public:
    //## Constructors (generated)
      ClientRequest();

      ClientRequest(const ClientRequest &right);

    //## Destructor (generated)
      virtual ~ClientRequest();

    //## Assignment Operation (generated)
      ClientRequest & operator=(const ClientRequest &right);


    //## Other Operations (specified)
      //## Operation: accept%3A5CB820027A
      void accept (ClientInterfaceVisitor& hClientInterfaceVisitor);

      //## Operation: getCacheSize%42C45C3E01C5
      int getCacheSize ();

      //## Operation: next%37DEA00102D2
      bool next ();

      //## Operation: previous%3E9EBD070148
      bool previous ();

      //## Operation: purgeFreePool%3E8B57B900BB
      static void purgeFreePool ();

      //## Operation: push%37DE6E440124
      bool push (Message& hMessage, int lTotalRecordsFound, bool bASCII, bool bSend = false);

      //## Operation: trace%3E9ECB1901A5
      void trace ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ExternalContextData%37EF8CB10374
      const string& getExternalContextData () const
      {
        //## begin ClientRequest::getExternalContextData%37EF8CB10374.get preserve=no
        return m_strExternalContextData;
        //## end ClientRequest::getExternalContextData%37EF8CB10374.get
      }

      void setExternalContextData (const string& value)
      {
        //## begin ClientRequest::setExternalContextData%37EF8CB10374.set preserve=no
        m_strExternalContextData = value;
        //## end ClientRequest::setExternalContextData%37EF8CB10374.set
      }


      //## Attribute: QueueName%5939467D037F
      const string& getQueueName () const
      {
        //## begin ClientRequest::getQueueName%5939467D037F.get preserve=no
        return m_strQueueName;
        //## end ClientRequest::getQueueName%5939467D037F.get
      }

      void setQueueName (const string& value)
      {
        //## begin ClientRequest::setQueueName%5939467D037F.set preserve=no
        m_strQueueName = value;
        //## end ClientRequest::setQueueName%5939467D037F.set
      }


      //## Attribute: Ticks%3E85C19D035B
      const double& getTicks () const
      {
        //## begin ClientRequest::getTicks%3E85C19D035B.get preserve=no
        return m_dTicks;
        //## end ClientRequest::getTicks%3E85C19D035B.get
      }


    // Additional Public Declarations
      //## begin ClientRequest%37DE6D170103.public preserve=yes
      //## end ClientRequest%37DE6D170103.public

  protected:
    // Additional Protected Declarations
      //## begin ClientRequest%37DE6D170103.protected preserve=yes
      //## end ClientRequest%37DE6D170103.protected

  private:
    // Additional Private Declarations
      //## begin ClientRequest%37DE6D170103.private preserve=yes
      //## end ClientRequest%37DE6D170103.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Cursor%3E9EA0AD0213
      //## begin ClientRequest::Cursor%3E9EA0AD0213.attr preserve=no  private: int {V} -1
      int m_lCursor;
      //## end ClientRequest::Cursor%3E9EA0AD0213.attr

      //## begin ClientRequest::ExternalContextData%37EF8CB10374.attr preserve=no  public: string {V} 
      string m_strExternalContextData;
      //## end ClientRequest::ExternalContextData%37EF8CB10374.attr

      //## Attribute: FreePool%45B631600251
      //## begin ClientRequest::FreePool%45B631600251.attr preserve=no  private: static vector<IF::Message*>* {V} 0
      static vector<IF::Message*>* m_pFreePool;
      //## end ClientRequest::FreePool%45B631600251.attr

      //## begin ClientRequest::QueueName%5939467D037F.attr preserve=no  public: string {V} 
      string m_strQueueName;
      //## end ClientRequest::QueueName%5939467D037F.attr

      //## begin ClientRequest::Ticks%3E85C19D035B.attr preserve=no  public: double {V} 0
      double m_dTicks;
      //## end ClientRequest::Ticks%3E85C19D035B.attr

      //## Attribute: TotalRecordsFound%37F8F4CB0287
      //## begin ClientRequest::TotalRecordsFound%37F8F4CB0287.attr preserve=no  private: int {V} 0
      int m_lTotalRecordsFound;
      //## end ClientRequest::TotalRecordsFound%37F8F4CB0287.attr

    // Additional Implementation Declarations
      //## begin ClientRequest%37DE6D170103.implementation preserve=yes
      vector<IF::Message*> m_hMessage;
      //## end ClientRequest%37DE6D170103.implementation
};

//## begin ClientRequest%37DE6D170103.postscript preserve=yes
//## end ClientRequest%37DE6D170103.postscript

//## begin module%37DE6F4002DF.epilog preserve=yes
//## end module%37DE6F4002DF.epilog


#endif
