//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A5F2454006C.cm preserve=no
//	$Date:   Jun 22 2017 07:35:38  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3A5F2454006C.cm

//## begin module%3A5F2454006C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A5F2454006C.cp

//## Module: CXOSCI06%3A5F2454006C; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI06.hpp

#ifndef CXOSCI06_h
#define CXOSCI06_h 1

//## begin module%3A5F2454006C.additionalIncludes preserve=no
//## end module%3A5F2454006C.additionalIncludes

//## begin module%3A5F2454006C.includes preserve=yes
//## end module%3A5F2454006C.includes

#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSIF37_h
#include "CXODIF37.hpp"
#endif

class Server;

//## begin module%3A5F2454006C.declarations preserve=no
//## end module%3A5F2454006C.declarations

//## begin module%3A5F2454006C.additionalDeclarations preserve=yes
//## end module%3A5F2454006C.additionalDeclarations


//## begin ClientDisplayServerRequest%3A5F22450028.preface preserve=yes
//## end ClientDisplayServerRequest%3A5F22450028.preface

//## Class: ClientDisplayServerRequest%3A5F22450028
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3A6629AD00F1;Server { -> F}

class ClientDisplayServerRequest : public ClientInterfaceVisitor  //## Inherits: <unnamed>%3A5F225B017E
{
  //## begin ClientDisplayServerRequest%3A5F22450028.initialDeclarations preserve=yes
  //## end ClientDisplayServerRequest%3A5F22450028.initialDeclarations

  public:
    //## Constructors (generated)
      ClientDisplayServerRequest();

    //## Destructor (generated)
      virtual ~ClientDisplayServerRequest();


    //## Other Operations (specified)
      //## Operation: visitServer%3A6629140277
      virtual void visitServer (Server* pServer);

    // Additional Public Declarations
      //## begin ClientDisplayServerRequest%3A5F22450028.public preserve=yes
      //## end ClientDisplayServerRequest%3A5F22450028.public

  protected:
    // Additional Protected Declarations
      //## begin ClientDisplayServerRequest%3A5F22450028.protected preserve=yes
      //## end ClientDisplayServerRequest%3A5F22450028.protected

  private:
    // Additional Private Declarations
      //## begin ClientDisplayServerRequest%3A5F22450028.private preserve=yes
      //## end ClientDisplayServerRequest%3A5F22450028.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Description%3A5F25C002A0
      //## begin ClientDisplayServerRequest::Description%3A5F25C002A0.attr preserve=no  private: char* {V} 0
      char* m_psDescription;
      //## end ClientDisplayServerRequest::Description%3A5F25C002A0.attr

      //## Attribute: Rows%3A7A07270103
      //## begin ClientDisplayServerRequest::Rows%3A7A07270103.attr preserve=no  private: int {V} 0
      int m_lRows;
      //## end ClientDisplayServerRequest::Rows%3A7A07270103.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%3A5F227501FD
      //## Role: ClientDisplayServerRequest::<m_hResultSet>%3A5F2276023B
      //## begin ClientDisplayServerRequest::<m_hResultSet>%3A5F2276023B.role preserve=no  public: IF::ResultSet { -> VHgN}
      IF::ResultSet m_hResultSet;
      //## end ClientDisplayServerRequest::<m_hResultSet>%3A5F2276023B.role

    // Additional Implementation Declarations
      //## begin ClientDisplayServerRequest%3A5F22450028.implementation preserve=yes
      //## end ClientDisplayServerRequest%3A5F22450028.implementation

};

//## begin ClientDisplayServerRequest%3A5F22450028.postscript preserve=yes
//## end ClientDisplayServerRequest%3A5F22450028.postscript

//## begin module%3A5F2454006C.epilog preserve=yes
//## end module%3A5F2454006C.epilog


#endif
