//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A6C470B0219.cm preserve=no
//	$Date:   Jun 26 2017 07:46:34  $ $Author:   e1009839  $ $Revision:   1.14  $
//## end module%3A6C470B0219.cm

//## begin module%3A6C470B0219.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A6C470B0219.cp

//## Module: CXOSCI13%3A6C470B0219; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI13.hpp

#ifndef CXOSCI13_h
#define CXOSCI13_h 1

//## begin module%3A6C470B0219.additionalIncludes preserve=no
//## end module%3A6C470B0219.additionalIncludes

//## begin module%3A6C470B0219.includes preserve=yes
//## end module%3A6C470B0219.includes

#ifndef CXOSCI01_h
#include "CXODCI01.hpp"
#endif
#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Message;
class Trace;
class Log;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
class InformationSegment;
class ResponseTimeSegment;
} // namespace segment

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class ResourceListSegment;
} // namespace usersegment

class ClientInterfaceVisitor;

//## begin module%3A6C470B0219.declarations preserve=no
//## end module%3A6C470B0219.declarations

//## begin module%3A6C470B0219.additionalDeclarations preserve=yes
//## end module%3A6C470B0219.additionalDeclarations


//## begin ClientPool%3A6C46B0013C.preface preserve=yes
//## end ClientPool%3A6C46B0013C.preface

//## Class: ClientPool%3A6C46B0013C
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3A6C521603B9;ClientInterfaceVisitor { -> F}
//## Uses: <unnamed>%3A6C7F6202B9;IF::Message { -> F}
//## Uses: <unnamed>%3A6DB3530010;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%3A6DB35501EA;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%3A6DB8E30217;segment::InformationSegment { -> F}
//## Uses: <unnamed>%3A6DBDC90115;IF::Extract { -> F}
//## Uses: <unnamed>%3A6DBE0500D6;IF::Log { -> F}
//## Uses: <unnamed>%3B5D6BBE01D4;usersegment::ResourceListSegment { -> F}
//## Uses: <unnamed>%3E85C4DB02FD;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%3E85D7C2005D;monitor::UseCase { -> F}
//## Uses: <unnamed>%3E9EB7AB029F;timer::Clock { -> F}
//## Uses: <unnamed>%3E9EB7AE03B9;IF::Trace { -> F}

class ClientPool : public reusable::Observer  //## Inherits: <unnamed>%3A6C46D80310
{
  //## begin ClientPool%3A6C46B0013C.initialDeclarations preserve=yes
  //## end ClientPool%3A6C46B0013C.initialDeclarations

  public:
    //## Constructors (generated)
      ClientPool();

    //## Destructor (generated)
      virtual ~ClientPool();


    //## Other Operations (specified)
      //## Operation: accept%3A6C52260113
      void accept (ClientInterfaceVisitor& hClientInterfaceVisitor);

      //## Operation: addProcessTime%3A705C1700EF
      void addProcessTime (const string& strUserID, int lProcessTime);

      //## Operation: addQueueTime%3A705BCD01F7
      void addQueueTime (const string& strUserID, int lQueueTime);

      //## Operation: addRequest%3A6F10EB0296
      void addRequest (const string& strUserID);

      //## Operation: ageout%3DF493E3036B
      //	<body>
      //	<title>CG
      //	<h1>CI
      //	<h2>MS
      //	<!-- ClientPool : ageout : General -->
      //	<h3>Client Inactivity
      //	<p>
      //	The Client Interface will optionally age inactive users
      //	by terminating their sessions.
      //	To enable aging, configure an AGEOUT timer in the Client
      //	Interface Task definition specifying the frequency (e.g.
      //	every 15 minutes) for checking for inactivity.
      //	A client is considered inactive if no requests have been
      //	received by the server in the prior hour.
      //	<p>
      //	Task definitions are in the Task Configuration folder in
      //	the CR Client for the DataNavigator Server.
      //	</body>
      void ageout ();

      //## Operation: getApplicationName%3B5D6BDC037A
      bool getApplicationName (const string &strUserID, string& strApplicationName);

      //## Operation: getRelationship%3A6D92330252
      char* getRelationship (const string& strUserID);

      //## Operation: getResourceListSegment%3B5D6C250186
      ResourceListSegment * getResourceListSegment (const string &strUserID);

      //## Operation: getSession%3A6C920703DE
      void* getSession (const string& strUserID);

      //## Operation: instance%3A6C4DCC02E8
      static ClientPool* instance ();

      //## Operation: isLoggedOn%3A6C7AC2025C
      bool isLoggedOn ();

      //## Operation: logoff%3A6C82A601E9
      bool logoff (const string& strUserID);

      //## Operation: logon%3A6C7C5E010A
      int logon (const string& strUserID, segment::CommonHeaderSegment* pCommonHeaderSegment);

      //## Operation: pop%3A6D9DA70276
      bool pop (const string& strUserID, const string& strQueueName, const string& strExternalContextData, bool bForward = true, bool bQuery = false);

      //## Operation: push%3A6DB26700CF
      bool push (const string& strUserID, Message& hMessage, int lTotalRecordsFound, bool bSend = false);

      //## Operation: saveRelationship%3A6C7F6B01C1
      void saveRelationship (Message& hMessage);

      //## Operation: setASCII%3A6C9A6F0307
      void setASCII (const string& strUserID, bool bASCII);

      //## Operation: trace%3E9EE24302CE
      void trace ();

      //## Operation: update%3A6C4DE20145
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin ClientPool%3A6C46B0013C.public preserve=yes
      //## end ClientPool%3A6C46B0013C.public

  protected:
    // Additional Protected Declarations
      //## begin ClientPool%3A6C46B0013C.protected preserve=yes
      //## end ClientPool%3A6C46B0013C.protected

  private:
    // Additional Private Declarations
      //## begin ClientPool%3A6C46B0013C.private preserve=yes
      //## end ClientPool%3A6C46B0013C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CustomerID%3A6DBDD00210
      //## begin ClientPool::CustomerID%3A6DBDD00210.attr preserve=no  private: string {V} 
      string m_strCustomerID;
      //## end ClientPool::CustomerID%3A6DBDD00210.attr

      //## Attribute: Instance%3A6C4DAF02F0
      //## begin ClientPool::Instance%3A6C4DAF02F0.attr preserve=no  private: static ClientPool* {V} 0
      static ClientPool* m_pInstance;
      //## end ClientPool::Instance%3A6C4DAF02F0.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%3A6C4BEC02A1
      //## Role: ClientPool::<m_hClientSession>%3A6C4BED0249
      //## Qualifier: UserID%3A6C4C1C00AC; string
      //## begin ClientPool::<m_hClientSession>%3A6C4BED0249.role preserve=no  public: ClientSession { -> VHgN}
      map<string, ClientSession, less<string> > m_hClientSession;
      //## end ClientPool::<m_hClientSession>%3A6C4BED0249.role

    // Additional Implementation Declarations
      //## begin ClientPool%3A6C46B0013C.implementation preserve=yes
      //## end ClientPool%3A6C46B0013C.implementation

};

//## begin ClientPool%3A6C46B0013C.postscript preserve=yes
//## end ClientPool%3A6C46B0013C.postscript

//## begin module%3A6C470B0219.epilog preserve=yes
//## end module%3A6C470B0219.epilog


#endif
