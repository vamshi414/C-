//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A5F24550366.cm preserve=no
//	$Date:   Jan 02 2018 08:21:16  $ $Author:   e1009839  $ $Revision:   1.8  $
//## end module%3A5F24550366.cm

//## begin module%3A5F24550366.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A5F24550366.cp

//## Module: CXOSCI06%3A5F24550366; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI06.cpp

//## begin module%3A5F24550366.additionalIncludes preserve=no
//## end module%3A5F24550366.additionalIncludes

//## begin module%3A5F24550366.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%3A5F24550366.includes

#ifndef CXOSCI09_h
#include "CXODCI09.hpp"
#endif
#ifndef CXOSCI06_h
#include "CXODCI06.hpp"
#endif


//## begin module%3A5F24550366.declarations preserve=no
//## end module%3A5F24550366.declarations

//## begin module%3A5F24550366.additionalDeclarations preserve=yes
#include "CXODRU32.hpp"
   struct sSession
   {
      char sName[9];
      short int iNull1;
      char sMessage[65];
      short int iNull2;
   };
#include "CXODRU33.hpp"
//## end module%3A5F24550366.additionalDeclarations


// Class ClientDisplayServerRequest 

ClientDisplayServerRequest::ClientDisplayServerRequest()
  //## begin ClientDisplayServerRequest::ClientDisplayServerRequest%3A5F22450028_const.hasinit preserve=no
      : m_psDescription(0),
        m_lRows(0)
  //## end ClientDisplayServerRequest::ClientDisplayServerRequest%3A5F22450028_const.hasinit
  //## begin ClientDisplayServerRequest::ClientDisplayServerRequest%3A5F22450028_const.initialization preserve=yes
  //## end ClientDisplayServerRequest::ClientDisplayServerRequest%3A5F22450028_const.initialization
{
  //## begin ClientDisplayServerRequest::ClientDisplayServerRequest%3A5F22450028_const.body preserve=yes
   memcpy(m_sID,"CI06",4);
#include "CXODRU32.hpp"
   struct hDescription
   {
      char sColumnName[18];
      short int nDataType;
      int nPrecision;
      short int nScale;
   };
#include "CXODRU33.hpp"
   int j = 2;
   char* pszColumnName[2] = {"NAME","MESSAGE"};
   int nPrecision[2] = {9,65};
   int k = 4 + (j * sizeof(struct hDescription));
   m_psDescription = new char[k];
   memset(m_psDescription,' ',k);
   memcpy(m_psDescription,&j,sizeof(int));
   hDescription* p = (hDescription*)(m_psDescription + 4);
   for (int i = 0;i < j;++i)
   {
      memcpy(p->sColumnName,pszColumnName[i],strlen(pszColumnName[i]));
      p->nDataType = 1;
      p->nPrecision = nPrecision[i];
      p->nScale = 0;
      ++p;
   }
  //## end ClientDisplayServerRequest::ClientDisplayServerRequest%3A5F22450028_const.body
}


ClientDisplayServerRequest::~ClientDisplayServerRequest()
{
  //## begin ClientDisplayServerRequest::~ClientDisplayServerRequest%3A5F22450028_dest.body preserve=yes
   if (m_lRows == 0)
   {
      struct sSession hSession;
      memset((char*)&hSession,' ',sizeof(struct sSession));
      memcpy(hSession.sName,"NONE",4);
      m_hResultSet.addRow(m_psDescription,(char*)&hSession);
   }
   m_hResultSet.close();
   delete [] m_psDescription;
  //## end ClientDisplayServerRequest::~ClientDisplayServerRequest%3A5F22450028_dest.body
}



//## Other Operations (implementation)
void ClientDisplayServerRequest::visitServer (Server* pServer)
{
  //## begin ClientDisplayServerRequest::visitServer%3A6629140277.body preserve=yes
   if (pServer->getMessage().bufferLength() == 0)
      return;
   struct sSession hSession;
   int k = (pServer->getName().length() > 8) ? 8 : pServer->getName().length();
   int j;
   char* p = pServer->getMessage().data();
   unsigned int i = pServer->getMessage().dataLength();
   while (i > 0)
   {
      memset((char*)&hSession,' ',sizeof(struct sSession));
      memcpy(hSession.sName,pServer->getName().data(),k);
      j = (i > 64) ? 64 : i;
      memcpy(hSession.sMessage,p,j);
      m_hResultSet.addRow(m_psDescription,(char*)&hSession);
      ++m_lRows;
      p += j;
      i -= j;
   }
  //## end ClientDisplayServerRequest::visitServer%3A6629140277.body
}

// Additional Declarations
  //## begin ClientDisplayServerRequest%3A5F22450028.declarations preserve=yes
  //## end ClientDisplayServerRequest%3A5F22450028.declarations

//## begin module%3A5F24550366.epilog preserve=yes
//## end module%3A5F24550366.epilog
