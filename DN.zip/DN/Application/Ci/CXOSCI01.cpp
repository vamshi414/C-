//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%368002CA0243.cm preserve=no
//	$Date:   May 13 2020 10:52:10  $ $Author:   e1009510  $ $Revision:   1.42  $
//## end module%368002CA0243.cm

//## begin module%368002CA0243.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%368002CA0243.cp

//## Module: CXOSCI01%368002CA0243; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI01.cpp

//## begin module%368002CA0243.additionalIncludes preserve=no
//## end module%368002CA0243.additionalIncludes

//## begin module%368002CA0243.includes preserve=yes
#include "CXODIF11.hpp"
//## end module%368002CA0243.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSCI03_h
#include "CXODCI03.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSCI01_h
#include "CXODCI01.hpp"
#endif


//## begin module%368002CA0243.declarations preserve=no
//## end module%368002CA0243.declarations

//## begin module%368002CA0243.additionalDeclarations preserve=yes
//## end module%368002CA0243.additionalDeclarations


// Class ClientSession 

//## begin ClientSession::AliasCount%3CFF9AA20399.attr preserve=no  public: static int {V} 0
int ClientSession::m_lAliasCount = 0;
//## end ClientSession::AliasCount%3CFF9AA20399.attr

//## begin ClientSession::ClientRequest%45B62F510148.attr preserve=no  private: static map<string,ClientRequest,less<string> >* {V} 0
map<string,ClientRequest,less<string> >* ClientSession::m_pClientRequest = 0;
//## end ClientSession::ClientRequest%45B62F510148.attr

//## begin ClientSession::Ticks%3E85E7E3001F.attr preserve=no  private: static double {V} 0
double ClientSession::m_dTicks = 0;
//## end ClientSession::Ticks%3E85E7E3001F.attr

ClientSession::ClientSession()
  //## begin ClientSession::ClientSession%345407AF0053_const.hasinit preserve=no
      : m_bASCII(false),
        m_lProcessTime(0),
        m_lQueueTime(0),
        m_pRelationshipSegment(0),
        m_lRequests(0),
        m_pCommonHeaderSegment(0)
  //## end ClientSession::ClientSession%345407AF0053_const.hasinit
  //## begin ClientSession::ClientSession%345407AF0053_const.initialization preserve=yes
   ,m_hMessage(1024)
  //## end ClientSession::ClientSession%345407AF0053_const.initialization
{
  //## begin ClientSession::ClientSession%345407AF0053_const.body preserve=yes
   memcpy(m_sID,"CI01",4);
   initialize();
   m_hResourceListSegment = *ResourceListSegment::instance();
  //## end ClientSession::ClientSession%345407AF0053_const.body
}

ClientSession::ClientSession(const ClientSession &right)
  //## begin ClientSession::ClientSession%345407AF0053_copy.hasinit preserve=no
  //## end ClientSession::ClientSession%345407AF0053_copy.hasinit
  //## begin ClientSession::ClientSession%345407AF0053_copy.initialization preserve=yes
   : m_hMessage(1024)
  //## end ClientSession::ClientSession%345407AF0053_copy.initialization
{
  //## begin ClientSession::ClientSession%345407AF0053_copy.body preserve=yes
   memcpy(m_sID,"CI01",4);
   initialize();
   m_strApplicationName = right.m_strApplicationName;
   m_strTimestamp = right.m_strTimestamp;
   m_hResourceListSegment = right.m_hResourceListSegment;
   m_strUserID = right.m_strUserID;
  //## end ClientSession::ClientSession%345407AF0053_copy.body
}


ClientSession::~ClientSession()
{
  //## begin ClientSession::~ClientSession%345407AF0053_dest.body preserve=yes
   delete [] m_pRelationshipSegment;
   delete m_pCommonHeaderSegment;
   if (m_pClientRequest)
   {
      map<string,string,less<string> >::iterator p;
      for (p = m_hClientRequestKey.begin();p != m_hClientRequestKey.end();++p)
      {
         map<string,ClientRequest,less<string> >::iterator pClientRequest = m_pClientRequest->find((*p).second);
         if (pClientRequest != m_pClientRequest->end())
            m_pClientRequest->erase(pClientRequest);
      }
   }
  //## end ClientSession::~ClientSession%345407AF0053_dest.body
}


ClientSession & ClientSession::operator=(const ClientSession &right)
{
  //## begin ClientSession::operator=%345407AF0053_assign.body preserve=yes
   initialize();
   m_strApplicationName = right.m_strApplicationName;
   m_hMessage = right.m_hMessage;
   m_strTimestamp = right.m_strTimestamp;
   m_hResourceListSegment = right.m_hResourceListSegment;
   return *this;
  //## end ClientSession::operator=%345407AF0053_assign.body
}



//## Other Operations (implementation)
void ClientSession::accept (ClientInterfaceVisitor& hClientInterfaceVisitor)
{
  //## begin ClientSession::accept%3A5CB84C002E.body preserve=yes
   hClientInterfaceVisitor.visitClientSession(this);
  //## end ClientSession::accept%3A5CB84C002E.body
}

string ClientSession::getAlias ()
{
  //## begin ClientSession::getAlias%3CFF9D850280.body preserve=yes
   char szTemp[9];
   snprintf(szTemp,sizeof(szTemp),"@%07ld",m_lAliasCount);
   return string(szTemp,8);
  //## end ClientSession::getAlias%3CFF9D850280.body
}

int ClientSession::getCacheCount ()
{
  //## begin ClientSession::getCacheCount%42C45A060196.body preserve=yes
   return (m_pClientRequest) ? m_pClientRequest->size() : 0;
  //## end ClientSession::getCacheCount%42C45A060196.body
}

int ClientSession::getCacheSize ()
{
  //## begin ClientSession::getCacheSize%42C45A0E0242.body preserve=yes
   int lCacheSize = 0;
   if (m_pClientRequest)
   {
      map<string,ClientRequest,less<string> >::iterator pClientRequest;
      for (pClientRequest = m_pClientRequest->begin();pClientRequest != m_pClientRequest->end();++pClientRequest)
         lCacheSize += (*pClientRequest).second.getCacheSize();
   }
   return lCacheSize;
  //## end ClientSession::getCacheSize%42C45A0E0242.body
}

ResourceListSegment * ClientSession::getResourceListSegment ()
{
  //## begin ClientSession::getResourceListSegment%3B5D6A0E03A9.body preserve=yes
   return &m_hResourceListSegment;
  //## end ClientSession::getResourceListSegment%3B5D6A0E03A9.body
}

void ClientSession::initialize ()
{
  //## begin ClientSession::initialize%352B7A3E0096.body preserve=yes
   m_bASCII = false;
   m_lProcessTime = 0;
   m_lQueueTime = 0;
   m_pRelationshipSegment = 0;
   m_lRequests = 0;
   m_pCommonHeaderSegment = new CommonHeaderSegment();
   *m_pCommonHeaderSegment = *CommonHeaderSegment::instance();
  //## end ClientSession::initialize%352B7A3E0096.body
}

const string& ClientSession::key () const
{
  //## begin ClientSession::key%352B7A4302EC.body preserve=yes
   return (m_pCommonHeaderSegment->getSecurityData());
  //## end ClientSession::key%352B7A4302EC.body
}

bool ClientSession::pop (const string& strQueueName, const char* pszExternalContextData, bool bForward, bool bQuery)
{
  //## begin ClientSession::pop%37DE93C700C8.body preserve=yes
   string strClientRequestKey;
   if (CommonHeaderSegment::instance()->getSecurityData().length() == 64)
   {
      strClientRequestKey.assign(CommonHeaderSegment::instance()->getSecurityData().data() + 43,20);
      strClientRequestKey.append(CommonHeaderSegment::instance()->getSecurityData().data(),43);
   }
   if (!m_pClientRequest)
      m_pClientRequest = new map<string,ClientRequest,less<string> >;
   map<string,ClientRequest,less<string> >::iterator pClientRequest = m_pClientRequest->find(strClientRequestKey);
   if (pClientRequest == m_pClientRequest->end())
   {
      ClientRequest hClientRequest;
      m_pClientRequest->insert(map<string,ClientRequest,less<string> >::value_type(strClientRequestKey,hClientRequest));
      pClientRequest = m_pClientRequest->find(strClientRequestKey);
   }
   if (!(bForward ? (*pClientRequest).second.next() : (*pClientRequest).second.previous()))
   {
      if (bForward == true && bQuery == false)
      {
         // client must wait for next response from server
         (*pClientRequest).second.setQueueName(strQueueName);
         (*pClientRequest).second.setExternalContextData(pszExternalContextData);
      }
      return false;
   }
   char* p = Message::instance(Message::INBOUND)->buffer() + 96;
   memset(p,' ',32);
   memcpy(p,pszExternalContextData,strlen(pszExternalContextData));
#ifdef MVS
   if (m_bASCII)
      CodeTable::translate(Message::instance(Message::INBOUND)->buffer(),Message::instance(Message::INBOUND)->messageLength(),CodeTable::CX_EBCDIC_TO_ASCII);
#endif
   return true;
  //## end ClientSession::pop%37DE93C700C8.body
}

void ClientSession::purgeCache ()
{
  //## begin ClientSession::purgeCache%3E85C8DF01D4.body preserve=yes
   if (m_pClientRequest
      && m_dTicks > 0)
   {
      double dTicks = Clock::instance()->getTicks();
      dTicks -= ((dTicks - m_dTicks) * 10);
      map<string,ClientRequest,less<string> >::iterator pClientRequest;
      while (!m_pClientRequest->empty())
      {
         pClientRequest = m_pClientRequest->begin();
         if ((*pClientRequest).second.getTicks() > dTicks)
         {
            m_dTicks = Clock::instance()->getTicks();
            return;
         }
         (*pClientRequest).second.trace();
         m_pClientRequest->erase(pClientRequest);
      }
   }
   m_dTicks = Clock::instance()->getTicks();
  //## end ClientSession::purgeCache%3E85C8DF01D4.body
}

bool ClientSession::push (Message& hMessage, int lTotalRecordsFound, bool bSend)
{
  //## begin ClientSession::push%37DE6E0D0161.body preserve=yes
   string strClientRequestKey;
   if (CommonHeaderSegment::instance()->getSecurityData().length() == 64)
   {
      strClientRequestKey.assign(CommonHeaderSegment::instance()->getSecurityData().data() + 43,20);
      strClientRequestKey.append(CommonHeaderSegment::instance()->getSecurityData().data(),43);
   }
   if (!m_pClientRequest)
      m_pClientRequest = new map<string,ClientRequest,less<string> >;
   map<string,ClientRequest,less<string> >::iterator pClientRequest;
   map<string,string,less<string> >::iterator p = m_hClientRequestKey.find(CommonHeaderSegment::instance()->getServiceName());
   if (p == m_hClientRequestKey.end())
   {
      string strEmpty;
      pair<map<string,string,less<string> >::iterator,bool> hResult = m_hClientRequestKey.insert(map<string,string,less<string> >::value_type(CommonHeaderSegment::instance()->getServiceName(),strEmpty));
      p = hResult.first;
   }
   if (strClientRequestKey != (*p).second)
   {
      if (!(*p).second.empty())
      {
         pClientRequest = m_pClientRequest->find((*p).second);
         if (pClientRequest != m_pClientRequest->end())
            m_pClientRequest->erase(pClientRequest);
      }
      m_hClientRequestKey[CommonHeaderSegment::instance()->getServiceName()] = strClientRequestKey;
   }
   pClientRequest = m_pClientRequest->find(strClientRequestKey);
   if (pClientRequest == m_pClientRequest->end())
   {
      ClientRequest hClientRequest;
      m_pClientRequest->insert(map<string,ClientRequest,less<string> >::value_type(strClientRequestKey,hClientRequest));
      pClientRequest = m_pClientRequest->find(strClientRequestKey);
   }
   return (*pClientRequest).second.push(hMessage,lTotalRecordsFound,m_bASCII,bSend);
  //## end ClientSession::push%37DE6E0D0161.body
}

void ClientSession::queue (const Message& hMessage)
{
  //## begin ClientSession::queue%3A5F10A70312.body preserve=yes
   m_hMessage = hMessage;
  //## end ClientSession::queue%3A5F10A70312.body
}

void ClientSession::setCommonHeaderSegment (segment::CommonHeaderSegment* pCommonHeaderSegment)
{
  //## begin ClientSession::setCommonHeaderSegment%3EA3DC8A00FA.body preserve=yes
   *m_pCommonHeaderSegment = *pCommonHeaderSegment;
  //## end ClientSession::setCommonHeaderSegment%3EA3DC8A00FA.body
}

void ClientSession::setRelationshipSegment (char* pRelationshipSegment)
{
  //## begin ClientSession::setRelationshipSegment%352BE2400056.body preserve=yes
   char szTemp[9] = {"        "};
   memcpy(szTemp,pRelationshipSegment + 8,8);
   int i = atoi(szTemp);
   delete [] m_pRelationshipSegment;
   m_pRelationshipSegment = new char[i + 1];
   memcpy(m_pRelationshipSegment,pRelationshipSegment,i);
   m_pRelationshipSegment[i] = '\0';
  //## end ClientSession::setRelationshipSegment%352BE2400056.body
}

void ClientSession::trace ()
{
  //## begin ClientSession::trace%3E9ECAFB038A.body preserve=yes
   string strTemp(m_strUserID);
   strTemp += " : ";
   strTemp += key();
   Trace::put(strTemp.c_str());
  //## end ClientSession::trace%3E9ECAFB038A.body
}

void ClientSession::traceCache ()
{
  //## begin ClientSession::traceCache%3E9EE3E00261.body preserve=yes
   if (m_pClientRequest)
   {
      map<string,ClientRequest,less<string> >::iterator pClientRequest;
      for (pClientRequest = m_pClientRequest->begin();pClientRequest != m_pClientRequest->end();++pClientRequest)
      {
         Trace::put((*pClientRequest).first.c_str());
         (*pClientRequest).second.trace();
      }
   }
  //## end ClientSession::traceCache%3E9EE3E00261.body
}

// Additional Declarations
  //## begin ClientSession%345407AF0053.declarations preserve=yes
  //## end ClientSession%345407AF0053.declarations

//## begin module%368002CA0243.epilog preserve=yes
//## end module%368002CA0243.epilog
