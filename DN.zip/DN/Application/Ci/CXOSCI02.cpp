//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3680031B03E4.cm preserve=no
//	$Date:   May 13 2020 10:33:20  $ $Author:   e1009510  $ $Revision:   1.24  $
//## end module%3680031B03E4.cm

//## begin module%3680031B03E4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3680031B03E4.cp

//## Module: CXOSCI02%3680031B03E4; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.3B.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI02.cpp

//## begin module%3680031B03E4.additionalIncludes preserve=no
//## end module%3680031B03E4.additionalIncludes

//## begin module%3680031B03E4.includes preserve=yes
// $Date:   May 13 2020 10:33:20  $ $Author:   e1009510  $ $Revision:   1.24  $
#include "CXODRU24.hpp"
#ifndef CXODIF11_h
#include "CXODIF11.hpp"
#endif
//## end module%3680031B03E4.includes

#ifndef CXOSUS17_h
#include "CXODUS17.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBS10_h
#include "CXODBS10.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSCI02_h
#include "CXODCI02.hpp"
#endif


//## begin module%3680031B03E4.declarations preserve=no
//## end module%3680031B03E4.declarations

//## begin module%3680031B03E4.additionalDeclarations preserve=yes
#define STS_MEMBER_NOT_FOUND 27
//## end module%3680031B03E4.additionalDeclarations


// Class ConfigurationFile 

ConfigurationFile::ConfigurationFile()
  //## begin ConfigurationFile::ConfigurationFile%352B87AF0292_const.hasinit preserve=no
  //## end ConfigurationFile::ConfigurationFile%352B87AF0292_const.hasinit
  //## begin ConfigurationFile::ConfigurationFile%352B87AF0292_const.initialization preserve=yes
  //## end ConfigurationFile::ConfigurationFile%352B87AF0292_const.initialization
{
  //## begin ConfigurationFile::ConfigurationFile%352B87AF0292_const.body preserve=yes
   memcpy(m_sID,"CI02",4);
  //## end ConfigurationFile::ConfigurationFile%352B87AF0292_const.body
}


ConfigurationFile::~ConfigurationFile()
{
  //## begin ConfigurationFile::~ConfigurationFile%352B87AF0292_dest.body preserve=yes
  //## end ConfigurationFile::~ConfigurationFile%352B87AF0292_dest.body
}



//## Other Operations (implementation)
void ConfigurationFile::parse (const Message& hMessage)
{
  //## begin ConfigurationFile::parse%5184046802FB.body preserve=yes
   m_strEXTRACT_GRP_ID[0].assign(hMessage.data(),8);
   m_strCC_TSTAMP_CHANGE[0].assign(hMessage.data() + 8,12);
   m_strEXTRACT_GRP_ID[1].assign(hMessage.data() + 20,8);
   m_strCC_TSTAMP_CHANGE[1].assign(hMessage.data() + 28,12);
   return;
  //## end ConfigurationFile::parse%5184046802FB.body
}

int ConfigurationFile::read (char** ppSegmentID, segment::CommonHeaderSegment& hCommonHeaderSegment, segment::MultipleRowContextSegment& hMultipleRowContextSegment, segment::ResponseTimeSegment& hResponseTimeSegment)
{
  //## begin ConfigurationFile::read%352B898C02AC.body preserve=yes
   hCommonHeaderSegment.deport(ppSegmentID);
   char* pMRC = *ppSegmentID;
   hMultipleRowContextSegment.deport(ppSegmentID);
   ConfigurationDataSegment hConfigurationDataSegment;
   // the message specification for Customer ID is 15-bytes
   // but the extract files are 4-bytes
   string strCustomerID((char*)hMultipleRowContextSegment.STSContextData().subString(9,4));
   string strName((char*)hMultipleRowContextSegment.STSContextData().subString(1,8));
   m_pExtract = new FlatFile(strName.c_str());
   m_pExtract->setName(strName.c_str());
   char cServerStateIndicator = ' ';
   char szCustomerID[16];
   char szTable[16];
   szTable[15] = '\0';
   int lRecordsReturnedThisMessage = 0;
   int lRecordNumberLastReturned = 0;
   int lMaxBytesToFetch = hMultipleRowContextSegment.maxRowsToFetch() * 1000;
   if (lMaxBytesToFetch > (MAX_MESSAGE_SIZE - 1000))
      lMaxBytesToFetch = MAX_MESSAGE_SIZE - 1000;
   if (m_pExtract->open())
   {
      char* pCDS = 0;
      int lCount = 0;
      int lSize = 0;
      bool bMatch;
      bool bFirstCont = false;
      int iCMatch;
      char* psBuffer = new char[256];
      size_t m;
      if (hMultipleRowContextSegment.clientStateIndicator() == 'C')
      {
         int n = hMultipleRowContextSegment.recordNumberLastReturned();
         lRecordNumberLastReturned = n;
         while ((n > 0) && m_pExtract->read(psBuffer,256,&m))
            --n;
         bFirstCont = true;
      }
      int i,j;
      char sTemp[24];
      char sHex[17] = {"0123456789ABCDEF"};
      while (m_pExtract->read(psBuffer,256,&m))
      {
         if ((psBuffer[0] == 'C')
            || (psBuffer[0] == 'D' && strncmp(szTable,psBuffer + 13,15)
            && lCount > 0) || bFirstCont)
         {
            if (pCDS)
               hConfigurationDataSegment.update(pCDS,szTable,szCustomerID,lCount,lSize);
            pCDS = *ppSegmentID;
            lCount = 0;
            iCMatch = 0;
            bFirstCont = false;
         }
         if (psBuffer[0] == 'D')
         {
            bMatch = (strncmp(psBuffer + 8,strCustomerID.data(),4) == 0);
            if (bMatch)
            {
               if (lCount == 0)
               {
                  hConfigurationDataSegment.deport(ppSegmentID);
                  if (hCommonHeaderSegment.getServiceName() == "RGETCRDT")
                     strncpy(pCDS,"S9080101",8);
                  else
                  if (hCommonHeaderSegment.getServiceName() == "RGETUSER")
                     strncpy(pCDS,"S911",4);
               }
               ++iCMatch;
               if (strName == "CLNTCNTL")
                  lSize = 40;
               else
                  lSize = m - 29;
               if (((*ppSegmentID + lSize) - pMRC) > lMaxBytesToFetch)
               {
                  cServerStateIndicator =	(hMultipleRowContextSegment.clientStateIndicator() == 'I') ? 'F' : 'M';
                  break;
               }
               strncpy(szCustomerID,psBuffer + 8,4);
               szCustomerID[4] = '\0';
               if (strName == "CLNTCNTL")
               {
                  strncpy(szTable,"EXTRACTMEMBERS ",15);
                  strncpy(*ppSegmentID,psBuffer + 13,8);
                  strncpy(*ppSegmentID + 8,psBuffer + 22,8);
                  i = 0;
                  if (m_strCC_TSTAMP_CHANGE[0].length() > 0) 
                  {
                     if (memcmp(psBuffer + 13,m_strEXTRACT_GRP_ID[0].data(),8) == 0)
                        memcpy(psBuffer + 31,m_strCC_TSTAMP_CHANGE[0].data(),12);
                     if (memcmp(psBuffer + 13,m_strEXTRACT_GRP_ID[1].data(),8) == 0)
                        memcpy(psBuffer + 31,m_strCC_TSTAMP_CHANGE[1].data(),12);
                  }
                  for (j = 31;j < 43;++j)
                  {
                     sTemp[i] = psBuffer[j];
                     sTemp[i] = sTemp[i] >> 4;
                     sTemp[i] = sHex[sTemp[i]];
                     ++i;
                     sTemp[i] = psBuffer[j] & 0x0F;
                     sTemp[i] = sHex[sTemp[i]];
                     ++i;
                  }
                  strncpy(*ppSegmentID + 16,(const char*)sTemp,24);
               }
               else
               {
                  strncpy(szTable,psBuffer + 13,15);
                  strncpy(*ppSegmentID,psBuffer + 29,lSize);
               }
               *ppSegmentID += lSize;
               ++lCount;
               ++lRecordsReturnedThisMessage;
            }
         }
         ++lRecordNumberLastReturned;
      }
      delete [] psBuffer;
      if (pCDS)
         hConfigurationDataSegment.update(pCDS,szTable,szCustomerID,lCount,lSize);
      hMultipleRowContextSegment.setTotalRecordsFound(0);
      hMultipleRowContextSegment.setRecordsReturnedThisMessage(lRecordsReturnedThisMessage);
      hMultipleRowContextSegment.setRecordNumberLastReturned(lRecordNumberLastReturned);
      if (cServerStateIndicator == ' ')
         cServerStateIndicator =	(hMultipleRowContextSegment.clientStateIndicator() == 'I') ? 'O' : 'L';
      hMultipleRowContextSegment.setServerStateIndicator(cServerStateIndicator);
      hMultipleRowContextSegment.deport(&pMRC);
   }
   else
   {
      InformationSegment hInformationSegment;
      hInformationSegment.setError(STS_SEVERE_ERROR,STS_MEMBER_NOT_FOUND);
      hInformationSegment.deport(ppSegmentID);
   }
   hResponseTimeSegment.deport(ppSegmentID);
	delete m_pExtract;
   return 0;
  //## end ConfigurationFile::read%352B898C02AC.body
}

int ConfigurationFile::read (const char* pszSection, char** ppSegmentID, segment::CommonHeaderSegment& hCommonHeaderSegment, segment::MultipleRowContextSegment& hMultipleRowContextSegment, segment::ResponseTimeSegment& hResponseTimeSegment)
{
  //## begin ConfigurationFile::read%352B89900262.body preserve=yes
   char szTable[16];
   strcpy(szTable,hCommonHeaderSegment.getServiceName().c_str());
   hCommonHeaderSegment.deport(ppSegmentID);
   char* pMRC = *ppSegmentID;
   hMultipleRowContextSegment.deport(ppSegmentID);
   ConfigurationDataSegment hConfigurationDataSegment;
	m_pExtract = new FlatFile(hMultipleRowContextSegment.STSContextData().subString(1,8));
   m_pExtract->setName(hMultipleRowContextSegment.STSContextData().subString(1,8));
   char cServerStateIndicator = ' ';
   int lRecordsReturnedThisMessage = 0;
   int lRecordNumberLastReturned = 0;
   int lMaxBytesToFetch =	hMultipleRowContextSegment.maxRowsToFetch() * 1000;
   if (m_pExtract->open())
   {
      char* pCDS = 0;
      int lCount = 0;
      int lSize = 0;
      char* psBuffer = new char[256];
      size_t m;
      if (hMultipleRowContextSegment.clientStateIndicator() == 'C')
      {
         int n = hMultipleRowContextSegment.recordNumberLastReturned();
         lRecordNumberLastReturned = n;
         while ((n > 0) && m_pExtract->read(psBuffer,256,&m))
            --n;
      }
      pCDS = *ppSegmentID;
      lCount = 0;
      hConfigurationDataSegment.deport(ppSegmentID);
      if (hCommonHeaderSegment.getServiceName() == "RGETAPPL")
         strncpy(pCDS,"S909",4);
      else
      if (hCommonHeaderSegment.getServiceName() == "RGETDEND")
         strncpy(pCDS,"S910",4);
      while (m_pExtract->read(psBuffer,256,&m))
      {
         if (psBuffer[0] == 'D')
         {
            if (!strncmp(psBuffer,pszSection,8))
            {
               lSize = m - 8;
               if (((*ppSegmentID + lSize) - pMRC) > lMaxBytesToFetch)
               {
                  cServerStateIndicator =	(hMultipleRowContextSegment.clientStateIndicator() == 'I') ? 'F' : 'M';
                  break;
               }
               strncpy(*ppSegmentID,psBuffer + 8,lSize);
               *ppSegmentID += lSize;
               ++lCount;
               ++lRecordsReturnedThisMessage;
            }
         }
         ++lRecordNumberLastReturned;
      }
      delete [] psBuffer;
      if (pCDS)
         hConfigurationDataSegment.update(pCDS,szTable,"***************",lCount,lSize);
      hMultipleRowContextSegment.setTotalRecordsFound(0);
      hMultipleRowContextSegment.setRecordsReturnedThisMessage(lRecordsReturnedThisMessage);
      hMultipleRowContextSegment.setRecordNumberLastReturned(lRecordNumberLastReturned);
      if (cServerStateIndicator == ' ')
         cServerStateIndicator =	(hMultipleRowContextSegment.clientStateIndicator() == 'I') ? 'O' : 'L';
      hMultipleRowContextSegment.setServerStateIndicator(cServerStateIndicator);
      hMultipleRowContextSegment.deport(&pMRC);
   }
   else
   {
      InformationSegment hInformationSegment;
      hInformationSegment.setError(STS_SEVERE_ERROR,STS_MEMBER_NOT_FOUND);
      hInformationSegment.deport(ppSegmentID);
   }
   hResponseTimeSegment.deport(ppSegmentID);
	delete m_pExtract;
   return 0;
  //## end ConfigurationFile::read%352B89900262.body
}

// Additional Declarations
  //## begin ConfigurationFile%352B87AF0292.declarations preserve=yes
  //## end ConfigurationFile%352B87AF0292.declarations

//## begin module%3680031B03E4.epilog preserve=yes
//## end module%3680031B03E4.epilog
