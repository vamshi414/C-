//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3A7994470048.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3A7994470048.cm

//## begin module%3A7994470048.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3A7994470048.cp

//## Module: CXOSCI14%3A7994470048; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ci\CXODCI14.hpp

#ifndef CXOSCI14_h
#define CXOSCI14_h 1

//## begin module%3A7994470048.additionalIncludes preserve=no
//## end module%3A7994470048.additionalIncludes

//## begin module%3A7994470048.includes preserve=yes
// $Date:   Apr 07 2004 15:03:08  $ $Author:   D98833  $ $Revision:   1.3  $
//## end module%3A7994470048.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

class ClientInterfaceVisitor;
//## Modelname: Connex Foundation::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Log;

} // namespace IF

//## begin module%3A7994470048.declarations preserve=no
//## end module%3A7994470048.declarations

//## begin module%3A7994470048.additionalDeclarations preserve=yes
//## end module%3A7994470048.additionalDeclarations


//## begin SlowQuery%3A79911C0309.preface preserve=yes
//## end SlowQuery%3A79911C0309.preface

//## Class: SlowQuery%3A79911C0309
//## Category: DataNavigator Foundation::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3A79958E0360;ClientInterfaceVisitor { -> F}
//## Uses: <unnamed>%3A7995A30189;timer::Clock { -> F}
//## Uses: <unnamed>%3A87F1770261;IF::Log { -> F}

class SlowQuery : public reusable::Object  //## Inherits: <unnamed>%3A79913A00D2
{
  //## begin SlowQuery%3A79911C0309.initialDeclarations preserve=yes
  //## end SlowQuery%3A79911C0309.initialDeclarations

  public:
    //## Constructors (generated)
      SlowQuery();

      SlowQuery(const SlowQuery &right);

    //## Destructor (generated)
      virtual ~SlowQuery();

    //## Assignment Operation (generated)
      SlowQuery & operator=(const SlowQuery &right);


    //## Other Operations (specified)
      //## Operation: accept%3A79955D0319
      void accept (ClientInterfaceVisitor& hClientInterfaceVisitor);

      //## Operation: log%3A87EE340039
      void log ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ServiceName%3A799526039C
      const string& getServiceName () const
      {
        //## begin SlowQuery::getServiceName%3A799526039C.get preserve=no
        return m_strServiceName;
        //## end SlowQuery::getServiceName%3A799526039C.get
      }

      void setServiceName (const string& value)
      {
        //## begin SlowQuery::setServiceName%3A799526039C.set preserve=no
        m_strServiceName = value;
        //## end SlowQuery::setServiceName%3A799526039C.set
      }


      //## Attribute: SQL%3A79952B0353
      const string& getSQL () const
      {
        //## begin SlowQuery::getSQL%3A79952B0353.get preserve=no
        return m_strSQL;
        //## end SlowQuery::getSQL%3A79952B0353.get
      }

      void setSQL (const string& value)
      {
        //## begin SlowQuery::setSQL%3A79952B0353.set preserve=no
        m_strSQL = value;
        //## end SlowQuery::setSQL%3A79952B0353.set
      }


      //## Attribute: Ticks%3A79952F0287
      const double getTicks () const
      {
        //## begin SlowQuery::getTicks%3A79952F0287.get preserve=no
        return m_dTicks;
        //## end SlowQuery::getTicks%3A79952F0287.get
      }

      void setTicks (double value)
      {
        //## begin SlowQuery::setTicks%3A79952F0287.set preserve=no
        m_dTicks = value;
        //## end SlowQuery::setTicks%3A79952F0287.set
      }


      //## Attribute: Timestamp%3A79953203B8
      const string& getTimestamp () const
      {
        //## begin SlowQuery::getTimestamp%3A79953203B8.get preserve=no
        return m_strTimestamp;
        //## end SlowQuery::getTimestamp%3A79953203B8.get
      }

      void setTimestamp (const string& value)
      {
        //## begin SlowQuery::setTimestamp%3A79953203B8.set preserve=no
        m_strTimestamp = value;
        //## end SlowQuery::setTimestamp%3A79953203B8.set
      }


      //## Attribute: UserID%3A7995360042
      const string& getUserID () const
      {
        //## begin SlowQuery::getUserID%3A7995360042.get preserve=no
        return m_strUserID;
        //## end SlowQuery::getUserID%3A7995360042.get
      }

      void setUserID (const string& value)
      {
        //## begin SlowQuery::setUserID%3A7995360042.set preserve=no
        m_strUserID = value;
        //## end SlowQuery::setUserID%3A7995360042.set
      }


    // Additional Public Declarations
      //## begin SlowQuery%3A79911C0309.public preserve=yes
      //## end SlowQuery%3A79911C0309.public

  protected:
    // Additional Protected Declarations
      //## begin SlowQuery%3A79911C0309.protected preserve=yes
      //## end SlowQuery%3A79911C0309.protected

  private:
    // Additional Private Declarations
      //## begin SlowQuery%3A79911C0309.private preserve=yes
      //## end SlowQuery%3A79911C0309.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin SlowQuery::ServiceName%3A799526039C.attr preserve=no  public: string {V} 
      string m_strServiceName;
      //## end SlowQuery::ServiceName%3A799526039C.attr

      //## begin SlowQuery::SQL%3A79952B0353.attr preserve=no  public: string {V} 
      string m_strSQL;
      //## end SlowQuery::SQL%3A79952B0353.attr

      //## begin SlowQuery::Ticks%3A79952F0287.attr preserve=no  public: double {V} 0
      double m_dTicks;
      //## end SlowQuery::Ticks%3A79952F0287.attr

      //## begin SlowQuery::Timestamp%3A79953203B8.attr preserve=no  public: string {V} 
      string m_strTimestamp;
      //## end SlowQuery::Timestamp%3A79953203B8.attr

      //## begin SlowQuery::UserID%3A7995360042.attr preserve=no  public: string {V} 
      string m_strUserID;
      //## end SlowQuery::UserID%3A7995360042.attr

    // Additional Implementation Declarations
      //## begin SlowQuery%3A79911C0309.implementation preserve=yes
      //## end SlowQuery%3A79911C0309.implementation

};

//## begin SlowQuery%3A79911C0309.postscript preserve=yes
//## end SlowQuery%3A79911C0309.postscript

//## begin module%3A7994470048.epilog preserve=yes
//## end module%3A7994470048.epilog


#endif
