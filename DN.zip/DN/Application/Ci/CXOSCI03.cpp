//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%37DE6F4200C5.cm preserve=no
//	$Date$ $Author$ $Revision$
//## end module%37DE6F4200C5.cm

//## begin module%37DE6F4200C5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%37DE6F4200C5.cp

//## Module: CXOSCI03%37DE6F4200C5; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI03.cpp

//## begin module%37DE6F4200C5.additionalIncludes preserve=no
//## end module%37DE6F4200C5.additionalIncludes

//## begin module%37DE6F4200C5.includes preserve=yes
#include "CXODRU24.hpp"
#include "CXODIF03.hpp"
//#include "CXODIF14.hpp"
//## end module%37DE6F4200C5.includes

#ifndef CXOSBS10_h
#include "CXODBS10.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSCI03_h
#include "CXODCI03.hpp"
#endif


//## begin module%37DE6F4200C5.declarations preserve=no
//## end module%37DE6F4200C5.declarations

//## begin module%37DE6F4200C5.additionalDeclarations preserve=yes
//## end module%37DE6F4200C5.additionalDeclarations


// Class ClientRequest 

//## begin ClientRequest::FreePool%45B631600251.attr preserve=no  private: static vector<IF::Message*>* {V} 0
vector<IF::Message*>* ClientRequest::m_pFreePool = 0;
//## end ClientRequest::FreePool%45B631600251.attr

ClientRequest::ClientRequest()
  //## begin ClientRequest::ClientRequest%37DE6D170103_const.hasinit preserve=no
      : m_lCursor(-1),
        m_dTicks(0),
        m_lTotalRecordsFound(0)
  //## end ClientRequest::ClientRequest%37DE6D170103_const.hasinit
  //## begin ClientRequest::ClientRequest%37DE6D170103_const.initialization preserve=yes
  //## end ClientRequest::ClientRequest%37DE6D170103_const.initialization
{
  //## begin ClientRequest::ClientRequest%37DE6D170103_const.body preserve=yes
   memcpy(m_sID,"CI03",4);
  //## end ClientRequest::ClientRequest%37DE6D170103_const.body
}

ClientRequest::ClientRequest(const ClientRequest &right)
  //## begin ClientRequest::ClientRequest%37DE6D170103_copy.hasinit preserve=no
  //## end ClientRequest::ClientRequest%37DE6D170103_copy.hasinit
  //## begin ClientRequest::ClientRequest%37DE6D170103_copy.initialization preserve=yes
  //## end ClientRequest::ClientRequest%37DE6D170103_copy.initialization
{
  //## begin ClientRequest::ClientRequest%37DE6D170103_copy.body preserve=yes
   m_strExternalContextData = right.m_strExternalContextData;
   m_lCursor = right.m_lCursor;
   // m_hMessage = right.m_hMessage; !!! ???
   m_dTicks = right.m_dTicks;
   m_lTotalRecordsFound = right.m_lTotalRecordsFound;
  //## end ClientRequest::ClientRequest%37DE6D170103_copy.body
}


ClientRequest::~ClientRequest()
{
  //## begin ClientRequest::~ClientRequest%37DE6D170103_dest.body preserve=yes
   if (!m_pFreePool)
      m_pFreePool = new vector<Message*>;
   vector<Message*>::iterator p;
   for (p = m_hMessage.begin();p != m_hMessage.end();++p)
      if (m_pFreePool->size() < 64)
         m_pFreePool->push_back(*p);
      else
         delete (*p);
   m_hMessage.erase(m_hMessage.begin(),m_hMessage.end());
  //## end ClientRequest::~ClientRequest%37DE6D170103_dest.body
}


ClientRequest & ClientRequest::operator=(const ClientRequest &right)
{
  //## begin ClientRequest::operator=%37DE6D170103_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_strExternalContextData = right.m_strExternalContextData;
   m_lCursor = right.m_lCursor;
   // m_hMessage = right.m_hMessage; !!! ???
   m_dTicks = right.m_dTicks;
   m_lTotalRecordsFound = right.m_lTotalRecordsFound;
   return *this;
  //## end ClientRequest::operator=%37DE6D170103_assign.body
}



//## Other Operations (implementation)
void ClientRequest::accept (ClientInterfaceVisitor& hClientInterfaceVisitor)
{
  //## begin ClientRequest::accept%3A5CB820027A.body preserve=yes
   hClientInterfaceVisitor.visitClientRequest(this);
  //## end ClientRequest::accept%3A5CB820027A.body
}

int ClientRequest::getCacheSize ()
{
  //## begin ClientRequest::getCacheSize%42C45C3E01C5.body preserve=yes
   int lCacheSize = 0;
   vector<Message*>::iterator p;
   for (p = m_hMessage.begin();p != m_hMessage.end();++p)
      lCacheSize += (*p)->bufferLength();
   return lCacheSize;
  //## end ClientRequest::getCacheSize%42C45C3E01C5.body
}

bool ClientRequest::next ()
{
  //## begin ClientRequest::next%37DEA00102D2.body preserve=yes
   m_dTicks = Clock::instance()->getTicks();
   if ((m_lCursor + 1) >= m_hMessage.size())
      return false;
   ++m_lCursor;
   Message* pMessage = m_hMessage[m_lCursor];
   *Message::instance(Message::INBOUND) = *pMessage;
   char* pSegmentID = Message::instance(Message::INBOUND)->buffer() + 8;
   char szTemp[9] = {"        "};
   char* pEndOfMessage = pSegmentID + Message::instance(Message::INBOUND)->messageLength() - 8;
   int i = 0;
   while (pSegmentID < pEndOfMessage)
   {
      if (++i > 5)
         break;
      if (!strncmp(pSegmentID,"S002",4))
      {
         MultipleRowContextSegment::update(pSegmentID,m_lTotalRecordsFound);
         break;
      }
      memcpy(szTemp,pSegmentID + 8,8);
      pSegmentID += atoi(szTemp);
   }
   snprintf(szTemp,sizeof(szTemp),"%04ld",m_lCursor);
   string strTemp(szTemp);
   strTemp += " Cache next  ";
   strTemp.append(Message::instance(Message::INBOUND)->buffer(),168);
   Trace::put(strTemp.data(),strTemp.length());
   return true;
  //## end ClientRequest::next%37DEA00102D2.body
}

bool ClientRequest::previous ()
{
  //## begin ClientRequest::previous%3E9EBD070148.body preserve=yes
   m_dTicks = Clock::instance()->getTicks();
   if (m_lCursor < 1)
      return false;
   --m_lCursor;
   Message* pMessage = m_hMessage[m_lCursor];
   *Message::instance(Message::INBOUND) = *pMessage;
   char szTemp[16];
   snprintf(szTemp,sizeof(szTemp),"%04ld",m_lCursor);
   string strTemp(szTemp);
   strTemp += " Cache previous  ";
   strTemp.append(Message::instance(Message::INBOUND)->buffer(),168);
   Trace::put(strTemp.data(),strTemp.length());
   return true;
  //## end ClientRequest::previous%3E9EBD070148.body
}

void ClientRequest::purgeFreePool ()
{
  //## begin ClientRequest::purgeFreePool%3E8B57B900BB.body preserve=yes
   if (!m_pFreePool)
      m_pFreePool = new vector<Message*>;
   while (!m_pFreePool->empty())
   {
      Message* pMessage = m_pFreePool->back();
      m_pFreePool->pop_back();
      delete pMessage;
   }
  //## end ClientRequest::purgeFreePool%3E8B57B900BB.body
}

bool ClientRequest::push (Message& hMessage, int lTotalRecordsFound, bool bASCII, bool bSend)
{
  //## begin ClientRequest::push%37DE6E440124.body preserve=yes
   m_dTicks = Clock::instance()->getTicks();
   bool bReturn = true;
   if (!m_strQueueName.empty())
   {
      char* p = hMessage.buffer() + 96;
      memcpy(p,m_strExternalContextData.data(),m_strExternalContextData.length());
#ifdef MVS
      if (bASCII)
         CodeTable::translate(hMessage.buffer(),hMessage.messageLength(),CodeTable::CX_EBCDIC_TO_ASCII);
#endif
      bReturn = Queue::send(m_strQueueName.c_str(),&hMessage);
      m_strQueueName.erase();
      ++m_lCursor;
   }
   if (!m_pFreePool)
      m_pFreePool = new vector<Message*>;
   if (m_pFreePool->empty())
      m_hMessage.push_back(new Message(hMessage));
   else
   {
      Message* pMessage = m_pFreePool->back();
      m_pFreePool->pop_back();
      *pMessage = hMessage;
      m_hMessage.push_back(pMessage);
   }
   if (bSend)
      m_lCursor = m_hMessage.size() - 1; // manual continuation (e.g. QDNLTRAN)
   else
   if (m_hMessage.size() == 1)
      m_lCursor = 0; // first response returned with initial request
   char szTemp[16];
   snprintf(szTemp,sizeof(szTemp),"%04ld",(int)m_hMessage.size());
   string strTemp(szTemp);
   strTemp += " Cache push ";
   strTemp.append(hMessage.buffer(),168);
   Trace::put(strTemp.data(),strTemp.length());
   m_lTotalRecordsFound = lTotalRecordsFound;
   return bReturn;
  //## end ClientRequest::push%37DE6E440124.body
}

void ClientRequest::trace ()
{
  //## begin ClientRequest::trace%3E9ECB1901A5.body preserve=yes
   Trace::put("ClientRequest::trace");
   vector<Message*>::iterator p;
   for (p = m_hMessage.begin();p != m_hMessage.end();++p)
      Trace::put((*p)->buffer(),256);
  //## end ClientRequest::trace%3E9ECB1901A5.body
}

// Additional Declarations
  //## begin ClientRequest%37DE6D170103.declarations preserve=yes
  //## end ClientRequest%37DE6D170103.declarations

//## begin module%37DE6F4200C5.epilog preserve=yes
//## end module%37DE6F4200C5.epilog
