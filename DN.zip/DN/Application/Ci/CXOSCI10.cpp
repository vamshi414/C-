//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A607040019C.cm preserve=no
//	$Date:   Jun 22 2017 07:56:24  $ $Author:   e1009839  $ $Revision:   1.7  $
//## end module%3A607040019C.cm

//## begin module%3A607040019C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A607040019C.cp

//## Module: CXOSCI10%3A607040019C; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI10.cpp

//## begin module%3A607040019C.additionalIncludes preserve=no
//## end module%3A607040019C.additionalIncludes

//## begin module%3A607040019C.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%3A607040019C.includes

#ifndef CXOSCI09_h
#include "CXODCI09.hpp"
#endif
#ifndef CXOSCI08_h
#include "CXODCI08.hpp"
#endif
#ifndef CXOSCI10_h
#include "CXODCI10.hpp"
#endif


//## begin module%3A607040019C.declarations preserve=no
//## end module%3A607040019C.declarations

//## begin module%3A607040019C.additionalDeclarations preserve=yes
#include "CXODRU32.hpp"
   struct sServer
   {
      char sName[9];
      short int iNull0;
      char sBusy[2];
      short int iNull1;
      char sServiceName[9];
      short int iNull2;
      char sUserID[9];
      short int iNull3;
      char sSQL[7];
      short int iNull4;
      int lTicks;
   };
#include "CXODRU33.hpp"
//## end module%3A607040019C.additionalDeclarations


// Class ClientDisplayServers 

ClientDisplayServers::ClientDisplayServers()
  //## begin ClientDisplayServers::ClientDisplayServers%3A606E48024C_const.hasinit preserve=no
      : m_bBusy(true),
        m_psDescription(0),
        m_lRows(0)
  //## end ClientDisplayServers::ClientDisplayServers%3A606E48024C_const.hasinit
  //## begin ClientDisplayServers::ClientDisplayServers%3A606E48024C_const.initialization preserve=yes
  //## end ClientDisplayServers::ClientDisplayServers%3A606E48024C_const.initialization
{
  //## begin ClientDisplayServers::ClientDisplayServers%3A606E48024C_const.body preserve=yes
   memcpy(m_sID,"CI10",4);
#include "CXODRU32.hpp"
   struct hDescription
   {
      char sColumnName[18];
      short int nDataType;
      int nPrecision;
      short int nScale;
   };
#include "CXODRU33.hpp"
   int j = 6;
   char* pszColumnName[6] = {"NAME","BUSY","SERVICE","USERID","SQL","TICKS"};
   int nPrecision[6] = {9,2,9,9,7,0};
   int k = 4 + (j * sizeof(struct hDescription));
   m_psDescription = new char[k];
   memset(m_psDescription,' ',k);
   memcpy(m_psDescription,&j,sizeof(int));
   hDescription* p = (hDescription*)(m_psDescription + 4);
   for (int i = 0;i < j;++i)
   {
      memcpy(p->sColumnName,pszColumnName[i],strlen(pszColumnName[i]));
      if (nPrecision[i] == 0)
      {
         p->nDataType = htons(4);
         p->nPrecision = htonl(4);
      }
      else
      {
         p->nDataType = htons(1);
         p->nPrecision = htonl(nPrecision[i]);
      }
      p->nScale = htons(0);
      ++p;
   }
  //## end ClientDisplayServers::ClientDisplayServers%3A606E48024C_const.body
}


ClientDisplayServers::~ClientDisplayServers()
{
  //## begin ClientDisplayServers::~ClientDisplayServers%3A606E48024C_dest.body preserve=yes
   if (m_lRows == 0)
   {
      struct sServer hServer;
      memset((char*)&hServer,' ',sizeof(struct sServer));
      memcpy(hServer.sName,"NONE",4);
      hServer.lTicks = htonl(0);
      m_hResultSet.addRow(m_psDescription,(char*)&hServer);
   }
   m_hResultSet.close();
   delete [] m_psDescription;
  //## end ClientDisplayServers::~ClientDisplayServers%3A606E48024C_dest.body
}



//## Other Operations (implementation)
void ClientDisplayServers::visitServer (Server* pServer)
{
  //## begin ClientDisplayServers::visitServer%3A606E6D0213.body preserve=yes
   if (pServer->getBusy() == m_bBusy)
   {
      struct sServer hServer;
      memset((char*)&hServer,' ',sizeof(struct sServer));
      int i = (pServer->getName().length() > 8) ? 8 : pServer->getName().length();
      memcpy(hServer.sName,pServer->getName().data(),i);
      hServer.sBusy[0] = (pServer->getBusy()) ? 'Y' : 'N';
      memcpy(hServer.sServiceName,pServer->getServiceName().data(),pServer->getServiceName().length());
      memcpy(hServer.sUserID,pServer->getUserID().data(),pServer->getUserID().length());
      if (pServer->getSQL().length() > 0)
         memcpy(hServer.sSQL,pServer->getSQL().data(),6);
      hServer.lTicks = htonl(pServer->getProcessTime());
      m_hResultSet.addRow(m_psDescription,(char*)&hServer);
      ++m_lRows;
   }
  //## end ClientDisplayServers::visitServer%3A606E6D0213.body
}

void ClientDisplayServers::visitServerPool (ServerPool* pServerPool)
{
  //## begin ClientDisplayServers::visitServerPool%3A606E6B0379.body preserve=yes
  //## end ClientDisplayServers::visitServerPool%3A606E6B0379.body
}

// Additional Declarations
  //## begin ClientDisplayServers%3A606E48024C.declarations preserve=yes
  //## end ClientDisplayServers%3A606E48024C.declarations

//## begin module%3A607040019C.epilog preserve=yes
//## end module%3A607040019C.epilog

