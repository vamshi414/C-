//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A62F95D03AE.cm preserve=no
//	$Date:   Jun 22 2017 07:53:42  $ $Author:   e1009839  $ $Revision:   1.5  $
//## end module%3A62F95D03AE.cm

//## begin module%3A62F95D03AE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A62F95D03AE.cp

//## Module: CXOSCI12%3A62F95D03AE; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI12.cpp

//## begin module%3A62F95D03AE.additionalIncludes preserve=no
//## end module%3A62F95D03AE.additionalIncludes

//## begin module%3A62F95D03AE.includes preserve=yes
//## end module%3A62F95D03AE.includes

#ifndef CXOSCI11_h
#include "CXODCI11.hpp"
#endif
#ifndef CXOSCI12_h
#include "CXODCI12.hpp"
#endif


//## begin module%3A62F95D03AE.declarations preserve=no
//## end module%3A62F95D03AE.declarations

//## begin module%3A62F95D03AE.additionalDeclarations preserve=yes
#include "CXODRU32.hpp"
   struct sQueuedRequest
   {
      char sUserID[9];
      short int iNull0;
      char sServiceName[9];
      short int iNull1;
      char sDate[9];
      short int iNull2;
      char sTime[9];
      short int iNull3;
      int lTicks;
      short int iNull4;
   };
#include "CXODRU33.hpp"
//## end module%3A62F95D03AE.additionalDeclarations


// Class ClientDisplayQueue 

ClientDisplayQueue::ClientDisplayQueue()
  //## begin ClientDisplayQueue::ClientDisplayQueue%3A62F87C00D0_const.hasinit preserve=no
      : m_psDescription(0),
        m_lRows(0)
  //## end ClientDisplayQueue::ClientDisplayQueue%3A62F87C00D0_const.hasinit
  //## begin ClientDisplayQueue::ClientDisplayQueue%3A62F87C00D0_const.initialization preserve=yes
  //## end ClientDisplayQueue::ClientDisplayQueue%3A62F87C00D0_const.initialization
{
  //## begin ClientDisplayQueue::ClientDisplayQueue%3A62F87C00D0_const.body preserve=yes
   memcpy(m_sID,"CI12",4);
#include "CXODRU32.hpp"
   struct hDescription
   {
      char sColumnName[18];
      short int nDataType;
      int nPrecision;
      short int nScale;
   };
#include "CXODRU33.hpp"
   int j = 5;
   char* pszColumnName[5] = {"USERID","SERVICE","DATE","TIME","TICKS"};
   int nPrecision[5] = {9,9,9,9,0};
   int k = 4 + (j * sizeof(struct hDescription));
   m_psDescription = new char[k];
   memset(m_psDescription,' ',k);
   memcpy(m_psDescription,&j,sizeof(int));
   hDescription* p = (hDescription*)(m_psDescription + 4);
   for (int i = 0;i < j;++i)
   {
      memcpy(p->sColumnName,pszColumnName[i],strlen(pszColumnName[i]));
      if (nPrecision[i] == 0)
      {
         p->nDataType = 4;
         p->nPrecision = 4;
      }
      else
      {
         p->nDataType = 1;
         p->nPrecision = nPrecision[i];
      }
      p->nScale = 0;
      ++p;
   }
  //## end ClientDisplayQueue::ClientDisplayQueue%3A62F87C00D0_const.body
}


ClientDisplayQueue::~ClientDisplayQueue()
{
  //## begin ClientDisplayQueue::~ClientDisplayQueue%3A62F87C00D0_dest.body preserve=yes
   if (m_lRows == 0)
   {
      struct sQueuedRequest hQueuedRequest;
      memset((char*)&hQueuedRequest,' ',sizeof(struct sQueuedRequest));
      memcpy(hQueuedRequest.sUserID,"NONE",4);
      hQueuedRequest.lTicks = 0;
      m_hResultSet.addRow(m_psDescription,(char*)&hQueuedRequest);
   }
   m_hResultSet.close();
   delete [] m_psDescription;
  //## end ClientDisplayQueue::~ClientDisplayQueue%3A62F87C00D0_dest.body
}



//## Other Operations (implementation)
void ClientDisplayQueue::visitQueuedRequest (QueuedRequest* pQueuedRequest)
{
  //## begin ClientDisplayQueue::visitQueuedRequest%3A62F8D000DA.body preserve=yes
   struct sQueuedRequest hQueuedRequest;
   memset((char*)&hQueuedRequest,' ',sizeof(struct sQueuedRequest));
   memcpy(hQueuedRequest.sUserID,pQueuedRequest->getUserID().data(),pQueuedRequest->getUserID().length());
   memcpy(hQueuedRequest.sServiceName,pQueuedRequest->getServiceName().data(),pQueuedRequest->getServiceName().length());
   memcpy(hQueuedRequest.sDate,pQueuedRequest->getTimestamp().data(),8);
   memcpy(hQueuedRequest.sTime,pQueuedRequest->getTimestamp().data() + 8,8);
   hQueuedRequest.lTicks = pQueuedRequest->getQueueTime();
   m_hResultSet.addRow(m_psDescription,(char*)&hQueuedRequest);
   ++m_lRows;
  //## end ClientDisplayQueue::visitQueuedRequest%3A62F8D000DA.body
}

// Additional Declarations
  //## begin ClientDisplayQueue%3A62F87C00D0.declarations preserve=yes
  //## end ClientDisplayQueue%3A62F87C00D0.declarations

//## begin module%3A62F95D03AE.epilog preserve=yes
//## end module%3A62F95D03AE.epilog
