//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A608AEE0342.cm preserve=no
//	$Date:   Jun 26 2017 07:46:32  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3A608AEE0342.cm

//## begin module%3A608AEE0342.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A608AEE0342.cp

//## Module: CXOSCI11%3A608AEE0342; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI11.hpp

#ifndef CXOSCI11_h
#define CXOSCI11_h 1

//## begin module%3A608AEE0342.additionalIncludes preserve=no
//## end module%3A608AEE0342.additionalIncludes

//## begin module%3A608AEE0342.includes preserve=yes
//## end module%3A608AEE0342.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

class ClientInterfaceVisitor;

//## begin module%3A608AEE0342.declarations preserve=no
//## end module%3A608AEE0342.declarations

//## begin module%3A608AEE0342.additionalDeclarations preserve=yes
//## end module%3A608AEE0342.additionalDeclarations


//## begin QueuedRequest%3A608996035B.preface preserve=yes
//## end QueuedRequest%3A608996035B.preface

//## Class: QueuedRequest%3A608996035B
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3A608C050253;ClientInterfaceVisitor { -> F}
//## Uses: <unnamed>%3A6097B003B7;timer::Clock { -> F}

class QueuedRequest : public reusable::Object  //## Inherits: <unnamed>%3A6089B20045
{
  //## begin QueuedRequest%3A608996035B.initialDeclarations preserve=yes
  //## end QueuedRequest%3A608996035B.initialDeclarations

  public:
    //## Constructors (generated)
      QueuedRequest();

      QueuedRequest(const QueuedRequest &right);

    //## Destructor (generated)
      virtual ~QueuedRequest();

    //## Assignment Operation (generated)
      QueuedRequest & operator=(const QueuedRequest &right);


    //## Other Operations (specified)
      //## Operation: accept%3A608BDF0186
      void accept (ClientInterfaceVisitor& hClientInterfaceVisitor);

      //## Operation: getQueueTime%3A6F12BF0108
      int getQueueTime ();

      //## Operation: send%3A608BC4037C
      bool send (const char* pszQueue);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: QueueName%3A76D91503CF
      const string& getQueueName () const
      {
        //## begin QueuedRequest::getQueueName%3A76D91503CF.get preserve=no
        return m_strQueueName;
        //## end QueuedRequest::getQueueName%3A76D91503CF.get
      }

      void setQueueName (const string& value)
      {
        //## begin QueuedRequest::setQueueName%3A76D91503CF.set preserve=no
        m_strQueueName = value;
        //## end QueuedRequest::setQueueName%3A76D91503CF.set
      }


      //## Attribute: ServiceName%3A60929E00E9
      const string& getServiceName () const
      {
        //## begin QueuedRequest::getServiceName%3A60929E00E9.get preserve=no
        return m_strServiceName;
        //## end QueuedRequest::getServiceName%3A60929E00E9.get
      }

      void setServiceName (const string& value)
      {
        //## begin QueuedRequest::setServiceName%3A60929E00E9.set preserve=no
        m_strServiceName = value;
        //## end QueuedRequest::setServiceName%3A60929E00E9.set
      }


      //## Attribute: Timestamp%3A6097500278
      const string& getTimestamp () const
      {
        //## begin QueuedRequest::getTimestamp%3A6097500278.get preserve=no
        return m_strTimestamp;
        //## end QueuedRequest::getTimestamp%3A6097500278.get
      }


      //## Attribute: UserID%3A608B6D00CE
      const string& getUserID () const
      {
        //## begin QueuedRequest::getUserID%3A608B6D00CE.get preserve=no
        return m_strUserID;
        //## end QueuedRequest::getUserID%3A608B6D00CE.get
      }

      void setUserID (const string& value)
      {
        //## begin QueuedRequest::setUserID%3A608B6D00CE.set preserve=no
        m_strUserID = value;
        //## end QueuedRequest::setUserID%3A608B6D00CE.set
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Application::Client_CAT::<unnamed>%3A6089CC02C3
      //## Role: QueuedRequest::<m_hMessage>%3A6089CD01E8
      IF::Message& getMessage ()
      {
        //## begin QueuedRequest::getMessage%3A6089CD01E8.get preserve=no
        return m_hMessage;
        //## end QueuedRequest::getMessage%3A6089CD01E8.get
      }

      void setMessage (const IF::Message& value)
      {
        //## begin QueuedRequest::setMessage%3A6089CD01E8.set preserve=no
        m_hMessage = value;
        //## end QueuedRequest::setMessage%3A6089CD01E8.set
      }


    // Additional Public Declarations
      //## begin QueuedRequest%3A608996035B.public preserve=yes
      //## end QueuedRequest%3A608996035B.public

  protected:
    // Additional Protected Declarations
      //## begin QueuedRequest%3A608996035B.protected preserve=yes
      //## end QueuedRequest%3A608996035B.protected

  private:
    // Additional Private Declarations
      //## begin QueuedRequest%3A608996035B.private preserve=yes
      //## end QueuedRequest%3A608996035B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin QueuedRequest::QueueName%3A76D91503CF.attr preserve=no  public: string {V} 
      string m_strQueueName;
      //## end QueuedRequest::QueueName%3A76D91503CF.attr

      //## begin QueuedRequest::ServiceName%3A60929E00E9.attr preserve=no  public: string {V} 
      string m_strServiceName;
      //## end QueuedRequest::ServiceName%3A60929E00E9.attr

      //## Attribute: Ticks%3A6F137C01C8
      //## begin QueuedRequest::Ticks%3A6F137C01C8.attr preserve=no  private: double {V} 0
      double m_dTicks;
      //## end QueuedRequest::Ticks%3A6F137C01C8.attr

      //## begin QueuedRequest::Timestamp%3A6097500278.attr preserve=no  public: string {V} 
      string m_strTimestamp;
      //## end QueuedRequest::Timestamp%3A6097500278.attr

      //## begin QueuedRequest::UserID%3A608B6D00CE.attr preserve=no  public: string {V} 
      string m_strUserID;
      //## end QueuedRequest::UserID%3A608B6D00CE.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%3A6089CC02C3
      //## begin QueuedRequest::<m_hMessage>%3A6089CD01E8.role preserve=no  public: IF::Message { -> VHgN}
      IF::Message m_hMessage;
      //## end QueuedRequest::<m_hMessage>%3A6089CD01E8.role

    // Additional Implementation Declarations
      //## begin QueuedRequest%3A608996035B.implementation preserve=yes
      //## end QueuedRequest%3A608996035B.implementation

};

//## begin QueuedRequest%3A608996035B.postscript preserve=yes
//## end QueuedRequest%3A608996035B.postscript

//## begin module%3A608AEE0342.epilog preserve=yes
//## end module%3A608AEE0342.epilog


#endif
