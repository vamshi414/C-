//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A4E21AC0392.cm preserve=no
//	$Date:   May 13 2020 12:27:16  $ $Author:   e1009510  $ $Revision:   1.2  $
//## end module%5A4E21AC0392.cm

//## begin module%5A4E21AC0392.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A4E21AC0392.cp

//## Module: CXOSMT01%5A4E21AC0392; Package body
//## Subsystem: MT%3F28FFC50138
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Application\Mt\CXOSMT01.cpp

//## begin module%5A4E21AC0392.additionalIncludes preserve=no
//## end module%5A4E21AC0392.additionalIncludes

//## begin module%5A4E21AC0392.includes preserve=yes
#ifdef _WIN32
#define _WINSOCKAPI_
#include <windows.h>
#endif
#include "CXODIF16.hpp"
//## end module%5A4E21AC0392.includes

#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSMT01_h
#include "CXODMT01.hpp"
#endif


//## begin module%5A4E21AC0392.declarations preserve=no
//## end module%5A4E21AC0392.declarations

//## begin module%5A4E21AC0392.additionalDeclarations preserve=yes
//## end module%5A4E21AC0392.additionalDeclarations


// Class Fax 

Fax::Fax()
  //## begin Fax::Fax%5A4E212A01FA_const.hasinit preserve=no
  //## end Fax::Fax%5A4E212A01FA_const.hasinit
  //## begin Fax::Fax%5A4E212A01FA_const.initialization preserve=yes
  //## end Fax::Fax%5A4E212A01FA_const.initialization
{
  //## begin Fax::Fax%5A4E212A01FA_const.body preserve=yes
   memcpy(m_sID,"MT01",4);
   MinuteTimer::instance()->attach(this);
  //## end Fax::Fax%5A4E212A01FA_const.body
}


Fax::~Fax()
{
  //## begin Fax::~Fax%5A4E212A01FA_dest.body preserve=yes
   MinuteTimer::instance()->detach(this);
  //## end Fax::~Fax%5A4E212A01FA_dest.body
}



//## Other Operations (implementation)
bool Fax::move (const string& strFolder)
{
  //## begin Fax::move%5A4E249700EC.body preserve=yes
#ifdef _WIN32
   string strNewFileName(m_strName);
   size_t pos = strNewFileName.find("Inbox");
   if (pos == string::npos)
      return false;
   strNewFileName.replace(pos,5,strFolder);
   Trace::put(strNewFileName.c_str());
   bool b = CopyFile(m_strName.c_str(),strNewFileName.c_str(),false);
   if (!b)
   {
      char szBuffer[32];
      Trace::put(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"CopyFile failure: %ld",GetLastError()));
      return false;
   }
   b = DeleteFile(m_strName.c_str());
   if (b == false
      && GetLastError() != 2)
   {
      char szBuffer[64];
      Trace::put(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"DeleteFile (New) failure: %ld",GetLastError()));
      return false;
   }
#else
   string strCommand("mv ");
   strCommand += m_strName;
   strCommand += " ";
   strCommand += Extract::instance()->getNode001();
   strCommand += "/Fax/";
   strCommand += strFolder;
   strCommand += "/.";
   Trace::put(strCommand.data(),strCommand.length());
   system(strCommand.c_str());
#endif
   return true;
  //## end Fax::move%5A4E249700EC.body
}

void Fax::update (Subject* pSubject)
{
  //## begin Fax::update%5A4E214F0021.body preserve=yes
   for (;;)
   {
      FlatFile hFlatFile("FAX");
      if (!hFlatFile.open())
         return;
      UseCase hUseCase("FD","## MT01 SEND FAX");
      m_strName = hFlatFile.getDatasetName();
      hFlatFile.close();
      string strCommand("ExecuteFAX ");
      strCommand += m_strName;
      strCommand += " 1>>\"FAX~Results.txt\"";
#ifdef _WIN32
      strCommand += " 2>>&1";
#else
      strCommand += " 2>>\"FAX~Results.txt\"";
#endif
      system(strCommand.c_str());
      if (!move(string("Outbox")))
      {
         UseCase::setSuccess(false);
         return;
      }
   }
  //## end Fax::update%5A4E214F0021.body
}

// Additional Declarations
  //## begin Fax%5A4E212A01FA.declarations preserve=yes
  //## end Fax%5A4E212A01FA.declarations

//## begin module%5A4E21AC0392.epilog preserve=yes
//## end module%5A4E21AC0392.epilog
