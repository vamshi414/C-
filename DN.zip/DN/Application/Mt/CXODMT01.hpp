//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A4E21AB0153.cm preserve=no
//	$Date:   Jan 04 2018 09:17:46  $ $Author:   e1009839  $ $Revision:   1.0  $
//## end module%5A4E21AB0153.cm

//## begin module%5A4E21AB0153.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A4E21AB0153.cp

//## Module: CXOSMT01%5A4E21AB0153; Package specification
//## Subsystem: MT%3F28FFC50138
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Application\Mt\CXODMT01.hpp

#ifndef CXOSMT01_h
#define CXOSMT01_h 1

//## begin module%5A4E21AB0153.additionalIncludes preserve=no
//## end module%5A4E21AB0153.additionalIncludes

//## begin module%5A4E21AB0153.includes preserve=yes
//## end module%5A4E21AB0153.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MinuteTimer;

} // namespace timer

//## begin module%5A4E21AB0153.declarations preserve=no
//## end module%5A4E21AB0153.declarations

//## begin module%5A4E21AB0153.additionalDeclarations preserve=yes
//## end module%5A4E21AB0153.additionalDeclarations


//## begin Fax%5A4E212A01FA.preface preserve=yes
//## end Fax%5A4E212A01FA.preface

//## Class: Fax%5A4E212A01FA
//## Category: Connex Application::MailTransferAgent_CAT%3F28FF05004E
//## Subsystem: MT%3F28FFC50138
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5A4E2166037F;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%5A4E231803DB;IF::FlatFile { -> F}
//## Uses: <unnamed>%5A4E259901FF;IF::Trace { -> F}
//## Uses: <unnamed>%5A4E36F60260;monitor::UseCase { -> F}

class DllExport Fax : public reusable::Observer  //## Inherits: <unnamed>%5A4E214A0120
{
  //## begin Fax%5A4E212A01FA.initialDeclarations preserve=yes
  //## end Fax%5A4E212A01FA.initialDeclarations

  public:
    //## Constructors (generated)
      Fax();

    //## Destructor (generated)
      virtual ~Fax();


    //## Other Operations (specified)
      //## Operation: move%5A4E249700EC
      bool move (const string& strFolder);

      //## Operation: update%5A4E214F0021
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin Fax%5A4E212A01FA.public preserve=yes
      //## end Fax%5A4E212A01FA.public

  protected:
    // Additional Protected Declarations
      //## begin Fax%5A4E212A01FA.protected preserve=yes
      //## end Fax%5A4E212A01FA.protected

  private:
    // Additional Private Declarations
      //## begin Fax%5A4E212A01FA.private preserve=yes
      //## end Fax%5A4E212A01FA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Name%5A4E24740356
      //## begin Fax::Name%5A4E24740356.attr preserve=no  private: string {V} 
      string m_strName;
      //## end Fax::Name%5A4E24740356.attr

    // Additional Implementation Declarations
      //## begin Fax%5A4E212A01FA.implementation preserve=yes
      //## end Fax%5A4E212A01FA.implementation

};

//## begin Fax%5A4E212A01FA.postscript preserve=yes
//## end Fax%5A4E212A01FA.postscript

//## begin module%5A4E21AB0153.epilog preserve=yes
//## end module%5A4E21AB0153.epilog


#endif
