//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%51DBF9A600C2.cm preserve=no
//## end module%51DBF9A600C2.cm

//## begin module%51DBF9A600C2.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%51DBF9A600C2.cp

//## Module: CXOPFS00%51DBF9A600C2; Package specification
//## Subsystem: FS%51DBF988009A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Application\Fs\CXODFS00.hpp

#ifndef CXOPFS00_h
#define CXOPFS00_h 1

//## begin module%51DBF9A600C2.additionalIncludes preserve=no
//## end module%51DBF9A600C2.additionalIncludes

//## begin module%51DBF9A600C2.includes preserve=yes
//## end module%51DBF9A600C2.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
} // namespace IF

namespace reusable {
class Table;
} // namespace reusable

namespace IF {
class Extract;
class Job;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Context;
class DatabaseFactory;
class Database;
class AuditEvent;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class AuditEventSegment;
class AuditEvent;
} // namespace segment

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;
} // namespace platform

//## Modelname: Connex Library::SecurityWrapper_CAT (SWDLL)%4A09A922013D
namespace securitywrapper {
class SecurityWrapper;

} // namespace securitywrapper

//## begin module%51DBF9A600C2.declarations preserve=no
//## end module%51DBF9A600C2.declarations

//## begin module%51DBF9A600C2.additionalDeclarations preserve=yes
//## end module%51DBF9A600C2.additionalDeclarations


//## begin FileScan%51DBF9660065.preface preserve=yes
//## end FileScan%51DBF9660065.preface

//## Class: FileScan%51DBF9660065
//## Category: Connex Application::FileScan_CAT%51DBF93F02B7
//## Subsystem: FS%51DBF988009A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%51DBFA2A016B;platform::Platform { -> F}
//## Uses: <unnamed>%51DBFA2C030D;monitor::UseCase { -> F}
//## Uses: <unnamed>%51DBFA2F02C3;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%51DBFA54016D;IF::Job { -> F}
//## Uses: <unnamed>%51DBFC2501EB;timer::Clock { -> F}
//## Uses: <unnamed>%51DBFC9D0259;database::Database { -> F}
//## Uses: <unnamed>%51DBFDF6003B;IF::Extract { -> F}
//## Uses: <unnamed>%51DC10F503D5;IF::FlatFile { -> F}
//## Uses: <unnamed>%51DC81C002EE;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%51DC81D30007;reusable::Table { -> F}
//## Uses: <unnamed>%51DC81F1024A;reusable::Statement { -> F}
//## Uses: <unnamed>%51DC82CB02E4;segment::AuditEventSegment { -> F}
//## Uses: <unnamed>%51DC83260193;database::AuditEvent { -> F}
//## Uses: <unnamed>%6259C83B022C;database::Context { -> F}
//## Uses: <unnamed>%6259C89B0374;securitywrapper::SecurityWrapper { -> F}
//## Uses: <unnamed>%625D83C40166;segment::AuditEvent { -> F}

class DllExport FileScan : public process::Application  //## Inherits: <unnamed>%51DBF97E016F
{
  //## begin FileScan%51DBF9660065.initialDeclarations preserve=yes
  //## end FileScan%51DBF9660065.initialDeclarations

  public:
    //## Constructors (generated)
      FileScan();

    //## Destructor (generated)
      virtual ~FileScan();


    //## Other Operations (specified)
      //## Operation: initialize%51DBFA3503A2
      virtual int initialize ();

      //## Operation: update%51DBFA3A01BB
      //	Interprets the inbound Message and calls:
      //
      //	   Application::onConfirm
      //	   Application::onMessage
      //	   Application::onNotify
      //	   Application::onQuiesce
      //	   Application::onRefresh
      //	   Application::onReset
      //	   Application::shutdown
      //	   Timer::elapsed
      //## Postconditions:
      //	<body>
      //	<title>CG
      //	<h1>FM
      //	<h2>FO
      //	<h3>Messages
      //	<p>
      //	Messages displayed by the DataNavigator services are
      //	saved in:
      //	<ul>
      //	<li><i>qualify</i>.CONSOLE_MSG
      //	</ul>
      //	</body>
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin FileScan%51DBF9660065.public preserve=yes
      //## end FileScan%51DBF9660065.public

  protected:
    // Additional Protected Declarations
      //## begin FileScan%51DBF9660065.protected preserve=yes
      //## end FileScan%51DBF9660065.protected

  private:

    //## Other Operations (specified)
      //## Operation: generateDigest%6259C49702EB
      const reusable::string generateDigest (const string& strDFILE);

      //## Operation: readAuditFile%51DC821D0327
      bool readAuditFile ();

      //## Operation: verifyDigest%6255CD03015C
      void verifyDigest ();

    // Additional Private Declarations
      //## begin FileScan%51DBF9660065.private preserve=yes
      //## end FileScan%51DBF9660065.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: LastTstamp%51DD989900AA
      //## begin FileScan::LastTstamp%51DD989900AA.attr preserve=no  private: string {U} 
      string m_strLastTstamp;
      //## end FileScan::LastTstamp%51DD989900AA.attr

      //## Attribute: Buffer%6259C62A03D0
      //## begin FileScan::Buffer%6259C62A03D0.attr preserve=no  private: char* {U} 0
      char* m_pBuffer;
      //## end FileScan::Buffer%6259C62A03D0.attr

      //## Attribute: ComputedDigest%6259C5780018
      //## begin FileScan::ComputedDigest%6259C5780018.attr preserve=no  private: string {U} 
      string m_strComputedDigest[3];
      //## end FileScan::ComputedDigest%6259C5780018.attr

      //## Attribute: CONTEXT_DATA%6255CE19003D
      //## begin FileScan::CONTEXT_DATA%6255CE19003D.attr preserve=no  private: string {U} 
      string m_strCONTEXT_DATA;
      //## end FileScan::CONTEXT_DATA%6255CE19003D.attr

      //## Attribute: CONTEXT_KEY%6255CE2E0046
      //## begin FileScan::CONTEXT_KEY%6255CE2E0046.attr preserve=no  private: string {U} 
      string m_strCONTEXT_KEY[3];
      //## end FileScan::CONTEXT_KEY%6255CE2E0046.attr

      //## Attribute: DFILES%6259CBC10356
      //## begin FileScan::DFILES%6259CBC10356.attr preserve=no  private: string {U} 
      string m_strDFILES[3];
      //## end FileScan::DFILES%6259CBC10356.attr

      //## Attribute: FileName%6259C61300AC
      //## begin FileScan::FileName%6259C61300AC.attr preserve=no  private: string {U} 
      string m_strFileName[3];
      //## end FileScan::FileName%6259C61300AC.attr

      //## Attribute: Resource%6259C6BD0037
      //## begin FileScan::Resource%6259C6BD0037.attr preserve=no  private: string {U} 
      string m_strResource[3];
      //## end FileScan::Resource%6259C6BD0037.attr

      //## Attribute: SavedDigest%6259C5FB01D0
      //## begin FileScan::SavedDigest%6259C5FB01D0.attr preserve=no  private: string {U} 
      string m_strSavedDigest[3];
      //## end FileScan::SavedDigest%6259C5FB01D0.attr

      //## Attribute: SEQ_NO%51DD9A23010B
      //## begin FileScan::SEQ_NO%51DD9A23010B.attr preserve=no  private: int {U} 1
      int m_iSEQ_NO;
      //## end FileScan::SEQ_NO%51DD9A23010B.attr

    // Additional Implementation Declarations
      //## begin FileScan%51DBF9660065.implementation preserve=yes
      //## end FileScan%51DBF9660065.implementation

};

//## begin FileScan%51DBF9660065.postscript preserve=yes
//## end FileScan%51DBF9660065.postscript

//## begin module%51DBF9A600C2.epilog preserve=yes
//## end module%51DBF9A600C2.epilog


#endif
