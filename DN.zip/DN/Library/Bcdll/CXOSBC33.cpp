//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4C23C86601B5.cm preserve=no
//	$Date:   Jan 25 2021 14:52:18  $ $Author:   e1009591  $ $Revision:   1.26  $
//## end module%4C23C86601B5.cm

//## begin module%4C23C86601B5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4C23C86601B5.cp

//## Module: CXOSBC33%4C23C86601B5; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.8A.R005\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC33.cpp

//## begin module%4C23C86601B5.additionalIncludes preserve=no
//## end module%4C23C86601B5.additionalIncludes

//## begin module%4C23C86601B5.includes preserve=yes
#ifdef _WIN32
#include "xercesc\framework\MemBufInputSource.hpp"
#include "xercesc\util\PlatformUtils.hpp"
#include "xercesc\parsers\SAXParser.hpp"
#else
#include "xercesc/framework/MemBufInputSource.hpp"
#include "xercesc/util/PlatformUtils.hpp"
#include "xercesc/parsers/SAXParser.hpp"
#endif

#include "CXODBS09.hpp"
//## end module%4C23C86601B5.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSBC35_h
#include "CXODBC35.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF39_h
#include "CXODIF39.hpp"
#endif
#ifndef CXOSBC34_h
#include "CXODBC34.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOSBS04_h
#include "CXODBS04.hpp"
#endif
#ifndef CXOSBC33_h
#include "CXODBC33.hpp"
#endif


//## begin module%4C23C86601B5.declarations preserve=no
//## end module%4C23C86601B5.declarations

//## begin module%4C23C86601B5.additionalDeclarations preserve=yes
#ifndef CXOSIF81_h
#include "CXODIF81.hpp"
#endif
//## end module%4C23C86601B5.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::SOAPService

//## begin command::SOAPService::<m_pSignal>%4CC6EE460096.role preserve=no  public: static reusable::Signal { -> RFHgN}
reusable::Signal *SOAPService::m_pSignal = 0;
//## end command::SOAPService::<m_pSignal>%4CC6EE460096.role

SOAPService::SOAPService()
  //## begin SOAPService::SOAPService%4C23C7D40167_const.hasinit preserve=no
      : m_pXMLItem(0)
  //## end SOAPService::SOAPService%4C23C7D40167_const.hasinit
  //## begin SOAPService::SOAPService%4C23C7D40167_const.initialization preserve=yes
  //## end SOAPService::SOAPService%4C23C7D40167_const.initialization
{
  //## begin command::SOAPService::SOAPService%4C23C7D40167_const.body preserve=yes
   memcpy_s(m_sID,4,"BC33",4);
   XMLPlatformUtils::Initialize();
   m_strThread.assign("00000000",8);
  //## end command::SOAPService::SOAPService%4C23C7D40167_const.body
}


SOAPService::~SOAPService()
{
  //## begin command::SOAPService::~SOAPService%4C23C7D40167_dest.body preserve=yes
   XMLPlatformUtils::Terminate();
   IF::Message::instance(IF::Message::INBOUND)->detach(this);
  //## end command::SOAPService::~SOAPService%4C23C7D40167_dest.body
}



//## Other Operations (implementation)
bool SOAPService::post (const char* pszName, Command* pCommand, bool bHTTPS, bool bHTTP)
{
  //## begin command::SOAPService::post%4C23C94F0186.body preserve=yes
   m_strText.erase();
#ifdef MVS
   CodeTable::translate(IF::Message::instance(Message::OUTBOUND)->buffer(),IF::Message::instance(IF::Message::OUTBOUND)->messageLength(),CodeTable::CX_EBCDIC_TO_ASCII);
#endif
   SocketQueue* p = 0;
   if (bHTTPS)
   {
      p = new SecureSocketQueue(pszName);
      if (!((SecureSocketQueue*)p)->initialize(pszName))
      {
         delete p;
         return false;
      }
   }
   else
      p = new SocketQueue(pszName);
   if (!m_pSignal)
      m_pSignal = new Signal(pszName);
   p->setSignal(m_pSignal);
   m_pSignal->attach(p);
   if(bHTTP)
      p->setInterface(SocketQueue::HTTP);
   else
      p->setInterface(SocketQueue::POST);
   string strTimeout;
   if (Extract::instance()->getSpec("TIMEOUT",strTimeout))
      p->setTimeout(atoi(strTimeout.c_str()));
   if (p->poll(pszName) == 0)
   {
      delete p;
      return false;
   }
   char sCorrelId[PERCENTF];
   m_strThread.assign(sCorrelId,snprintf(sCorrelId,sizeof(sCorrelId),"%08x",p->getThread()));
   if (m_strThread == "00000000")
      m_strThread.assign("00000001",8);
   m_pCommand = pCommand;
   IF::Message::instance(IF::Message::INBOUND)->attach(this);
   Application::instance()->enable(m_pSignal);
#ifdef MVS
   Queue::insert(pszName,p);
#endif
   return (IF::Message::instance(IF::Message::OUTBOUND)->send(pszName,IF::Message::instance(IF::Message::OUTBOUND)->messageLength()) == 0);
  //## end command::SOAPService::post%4C23C94F0186.body
}

void SOAPService::update (Subject* pSubject)
{
  //## begin command::SOAPService::update%4C59A0900003.body preserve=yes
   if (Message::instance(Message::INBOUND)->getSource() == "HTTP"
      || Message::instance(Message::INBOUND)->getSource() == "POST")
   {
      if (m_strThread == "00000000")
         return; // subject not waiting for response
#ifdef _WIN32
      if (memcmp(Message::instance(Message::INBOUND)->getCorrelId().data(),m_strThread.data(),8) != 0)
         return; // subject waiting for different response parallel sessions
#endif
      m_strThread.assign("00000000",8); // clear so not waiting for another response until another send
      if (memcmp(Message::instance(Message::INBOUND)->buffer(),"TIMEOUT",7) == 0 
             || memcmp(Message::instance(Message::INBOUND)->buffer(), "SOCKERR", 7) == 0)
      {
         if(memcmp(Message::instance(Message::INBOUND)->buffer(), "TIMEOUT", 7) == 0)
            m_strText = "Timeout waiting for a response from SOAP service";
         else
            m_strText = "Remote host closed connection";
         m_pCommand->setInfoIDNumber(73);
         m_pCommand->reply();
         return;
      }

      string strBuffer(Message::instance(Message::INBOUND)->buffer(),Message::instance(Message::INBOUND)->messageLength());
      char c = 0x0a;
      string strDelimiters(&c,1);
      vector<string> hTokens;
      Buffer::parse(strBuffer,strDelimiters,hTokens);
      vector<string>::iterator p;
      for (p = hTokens.begin();p != hTokens.end();++p)
         Trace::put((*p).data(),(*p).length());
      if (m_pXMLItem)
      {
         XMLCh sBufld[2] = {1,0};
         MemBufInputSource hMemBufInputSource((XMLByte*)hTokens.back().c_str(),(unsigned int)hTokens.back().length(),&sBufld[0]);
         m_pXMLItem->resetToken();
         SAXParser hSAXParser;
         XMLHandler* pXMLHandler = new XMLHandler(m_pXMLItem);
         hSAXParser.setDocumentHandler(pXMLHandler);
         hSAXParser.setErrorHandler(pXMLHandler);
         hSAXParser.parse(hMemBufInputSource);
         int lInfoIDNumber = 0;
         string strValue;
         m_pXMLItem->get("ApplMsgErrInd",strValue);
         if (strValue == "Y")
         {
            m_pXMLItem->get("ApplMsgNbr",strValue);
            lInfoIDNumber = atoi(strValue.c_str());
            if (lInfoIDNumber == 0)
               lInfoIDNumber = STS_INVALID_CONTEXT_DATA;
            m_pXMLItem->get("ApplMsgTxt",m_strText);
         }
         else
         {
            m_pXMLItem->get("ErrMsg",m_strText);
            if (!m_strText.empty())
            {
               m_pXMLItem->get("ErrCde",strValue);
               lInfoIDNumber = atoi(strValue.c_str());
            }
         }
         delete pXMLHandler;
         m_pCommand->setInfoIDNumber(lInfoIDNumber);
      }
      m_pCommand->reply();
   }
  //## end command::SOAPService::update%4C59A0900003.body
}

// Additional Declarations
  //## begin command::SOAPService%4C23C7D40167.declarations preserve=yes
  //## end command::SOAPService%4C23C7D40167.declarations

} // namespace command

//## begin module%4C23C86601B5.epilog preserve=yes
//## end module%4C23C86601B5.epilog
