//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4F44F3C803A3.cm preserve=no
//## end module%4F44F3C803A3.cm

//## begin module%4F44F3C803A3.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4F44F3C803A3.cp

//## Module: CXOSBC37%4F44F3C803A3; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC37.cpp

//## begin module%4F44F3C803A3.additionalIncludes preserve=no
//## end module%4F44F3C803A3.additionalIncludes

//## begin module%4F44F3C803A3.includes preserve=yes
//## end module%4F44F3C803A3.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSBC37_h
#include "CXODBC37.hpp"
#endif


//## begin module%4F44F3C803A3.declarations preserve=no
//## end module%4F44F3C803A3.declarations

//## begin module%4F44F3C803A3.additionalDeclarations preserve=yes
//## end module%4F44F3C803A3.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::TemplateToken 

TemplateToken::TemplateToken()
  //## begin TemplateToken::TemplateToken%4F44F17E033D_const.hasinit preserve=no
      : m_pAddress(0),
        m_bHexToChar(false),
        m_iIndex(0),
        m_iLength(0),
        m_cLengthType(' '),
        m_iOffset(0),
        m_bSigned(true),
        m_iSize(0),
        m_bTrim(false),
        m_cType(' '),
        m_bVarChar(false),
        m_pSegment(0)
  //## end TemplateToken::TemplateToken%4F44F17E033D_const.hasinit
  //## begin TemplateToken::TemplateToken%4F44F17E033D_const.initialization preserve=yes
  //## end TemplateToken::TemplateToken%4F44F17E033D_const.initialization
{
  //## begin command::TemplateToken::TemplateToken%4F44F17E033D_const.body preserve=yes
   memcpy(m_sID,"BC37",4);
  //## end command::TemplateToken::TemplateToken%4F44F17E033D_const.body
}

TemplateToken::TemplateToken(const TemplateToken &right)
  //## begin TemplateToken::TemplateToken%4F44F17E033D_copy.hasinit preserve=no
  //## end TemplateToken::TemplateToken%4F44F17E033D_copy.hasinit
  //## begin TemplateToken::TemplateToken%4F44F17E033D_copy.initialization preserve=yes
  //## end TemplateToken::TemplateToken%4F44F17E033D_copy.initialization
{
  //## begin command::TemplateToken::TemplateToken%4F44F17E033D_copy.body preserve=yes
   memcpy(m_sID,"BC37",4);
   m_pAddress = right.m_pAddress;
   m_bHexToChar = right.m_bHexToChar;
   m_iIndex = right.m_iIndex;
   m_iLength = right.m_iLength;
   m_strLengthAttribute = right.m_strLengthAttribute;
   m_cLengthType = right.m_cLengthType;
   m_strName = right.m_strName;
   m_iOffset = right.m_iOffset;
   m_pSegment = right.m_pSegment;
   m_bSigned = right.m_bSigned;
   m_iSize = right.m_iSize;
   m_strTable = right.m_strTable;
   m_bTrim = right.m_bTrim;
   m_cType = right.m_cType;
   m_bVarChar = right.m_bVarChar;
   m_strFunctionName = right.m_strFunctionName;
   m_strXMLTag = right.m_strXMLTag;
  //## end command::TemplateToken::TemplateToken%4F44F17E033D_copy.body
}

TemplateToken::TemplateToken (segment::Segment* pSegment, const string& strName, int iOffset, int iLength, char cType, void* pAddress, int iSize, char cLengthType, const char* pszLengthAttribute, const char* pszFunctionName, const char* pszXMLTag)
  //## begin command::TemplateToken::TemplateToken%4F4502F0013D.hasinit preserve=no
      : m_pAddress(0),
        m_bHexToChar(false),
        m_iIndex(0),
        m_iLength(0),
        m_cLengthType(' '),
        m_iOffset(0),
        m_bSigned(true),
        m_iSize(0),
        m_bTrim(false),
        m_cType(' '),
        m_bVarChar(false),
        m_pSegment(0)
  //## end command::TemplateToken::TemplateToken%4F4502F0013D.hasinit
  //## begin command::TemplateToken::TemplateToken%4F4502F0013D.initialization preserve=yes
  //## end command::TemplateToken::TemplateToken%4F4502F0013D.initialization
{
  //## begin command::TemplateToken::TemplateToken%4F4502F0013D.body preserve=yes
   memcpy(m_sID,"BC37",4);
   m_iIndex = 0;
   m_pSegment = pSegment;
   m_strName = strName;
   m_iOffset = iOffset;
   m_iLength = iLength;
   m_cType = cType;
   m_pAddress = pAddress;
   m_iSize = iSize;
   if (pszLengthAttribute)
   {
      m_cLengthType = cLengthType;
      m_strLengthAttribute.assign(pszLengthAttribute);
   }
   if (pszFunctionName)
      m_strFunctionName.assign(pszFunctionName);
   if (pszXMLTag)
      m_strXMLTag.assign(pszXMLTag);
  //## end command::TemplateToken::TemplateToken%4F4502F0013D.body
}


TemplateToken::~TemplateToken()
{
  //## begin command::TemplateToken::~TemplateToken%4F44F17E033D_dest.body preserve=yes
  //## end command::TemplateToken::~TemplateToken%4F44F17E033D_dest.body
}


TemplateToken & TemplateToken::operator=(const TemplateToken &right)
{
  //## begin command::TemplateToken::operator=%4F44F17E033D_assign.body preserve=yes
   if (&right == this)
      return *this;
   m_pAddress = right.m_pAddress;
   m_bHexToChar = right.m_bHexToChar;
   m_iIndex = right.m_iIndex;
   m_iLength = right.m_iLength;
   m_strLengthAttribute = right.m_strLengthAttribute;
   m_cLengthType = right.m_cLengthType;
   m_strName = right.m_strName;
   m_iOffset = right.m_iOffset;
   m_pSegment = right.m_pSegment;
   m_bSigned = right.m_bSigned;
   m_iSize = right.m_iSize;
   m_strTable = right.m_strTable;
   m_bTrim = right.m_bTrim;
   m_cType = right.m_cType;
   m_bVarChar = right.m_bVarChar;
   m_strFunctionName = right.m_strFunctionName;
   m_strXMLTag = right.m_strXMLTag;
   return *this;
  //## end command::TemplateToken::operator=%4F44F17E033D_assign.body
}


// Additional Declarations
  //## begin command::TemplateToken%4F44F17E033D.declarations preserve=yes
  //## end command::TemplateToken%4F44F17E033D.declarations

} // namespace command

//## begin module%4F44F3C803A3.epilog preserve=yes
//## end module%4F44F3C803A3.epilog
