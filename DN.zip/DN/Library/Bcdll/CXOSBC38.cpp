//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4F6B4103034C.cm preserve=no
//	$Date:   May 14 2020 16:29:58  $ $Author:   e1009510  $
//	$Revision:   1.9  $
//## end module%4F6B4103034C.cm

//## begin module%4F6B4103034C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4F6B4103034C.cp

//## Module: CXOSBC38%4F6B4103034C; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC38.cpp

//## begin module%4F6B4103034C.additionalIncludes preserve=no
//## end module%4F6B4103034C.additionalIncludes

//## begin module%4F6B4103034C.includes preserve=yes
#include "CXODIF03.hpp"
//## end module%4F6B4103034C.includes

#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSBC38_h
#include "CXODBC38.hpp"
#endif


//## begin module%4F6B4103034C.declarations preserve=no
//## end module%4F6B4103034C.declarations

//## begin module%4F6B4103034C.additionalDeclarations preserve=yes
//## end module%4F6B4103034C.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::Template 

Template::Template()
  //## begin Template::Template%4F6B3DC901A1_const.hasinit preserve=no
  //## end Template::Template%4F6B3DC901A1_const.hasinit
  //## begin Template::Template%4F6B3DC901A1_const.initialization preserve=yes
  //## end Template::Template%4F6B3DC901A1_const.initialization
{
  //## begin command::Template::Template%4F6B3DC901A1_const.body preserve=yes
   memcpy(m_sID,"BC38",4);
  //## end command::Template::Template%4F6B3DC901A1_const.body
}


Template::~Template()
{
  //## begin command::Template::~Template%4F6B3DC901A1_dest.body preserve=yes
  //## end command::Template::~Template%4F6B3DC901A1_dest.body
}



//## Other Operations (implementation)
map<string, TemplateToken, less<string> >* Template::getList ()
{
  //## begin command::Template::getList%4F72D02E03B4.body preserve=yes
   return &m_hTemplateToken;
  //## end command::Template::getList%4F72D02E03B4.body
}

segment::Segment* Template::getSegment (char cType)
{
  //## begin command::Template::getSegment%4F6B4F820194.body preserve=yes
   return 0;
  //## end command::Template::getSegment%4F6B4F820194.body
}

int Template::mapToken (const string& strToken, string& strValue)
{
  //## begin command::Template::mapToken%4F6B3DC901A2.body preserve=yes
   if (m_hTemplateToken.empty())
      if (!read())
         return -1;
   map<string,TemplateToken,less <string> >::iterator p = m_hTemplateToken.find(strToken);
   string strBuffer(strToken);
   if (p == m_hTemplateToken.end())
   {
      strBuffer += " not mapped : ";
      strBuffer += strValue;
      Trace::put(strBuffer.data(),strBuffer.length());
      return 0;
   }
   strBuffer += " -> ";
   strBuffer += (*p).second.getName();
   strBuffer += " : ";
   strBuffer += strValue;
   Trace::put(strBuffer.data(),strBuffer.length());
   return mapToken(p,strValue);
  //## end command::Template::mapToken%4F6B3DC901A2.body
}

int Template::mapToken (map<string,TemplateToken,less <string> >::iterator pToken, string& strValue)
{
  //## begin command::Template::mapToken%4F71948500FC.body preserve=yes
   //strValue can be changed by this method especially  if the token can be trimmed 
   // based on the specifications in the template
   if (!pToken->second.getSegment())
      return 0;
   int iLength = 0;
   switch ((*pToken).second.getType())
   {
      case 's':
         *(short int*)(*pToken).second.getAddress() = atoi(strValue.c_str());
         break;
      case 'l':
         *(int*)(*pToken).second.getAddress() = atoi(strValue.c_str());
         break;
      case 'd':
         *(double*)(*pToken).second.getAddress() = atof(strValue.c_str());
         break;
      case '#':
         if ((*pToken).second.getTrim())
            trim(strValue);
         *(string*)(*pToken).second.getAddress() = strValue;
         break;
      case 'U':
         if ((*pToken).second.getTrim())
            trim(strValue);
         memcpy((char*)(*pToken).second.getAddress() + (*pToken).second.getOffset(),strValue.data(),strValue.length());
         break;
      default:
         if ((*pToken).second.getTrim())
            trim(strValue);
         iLength = strValue.length();
         if((*pToken).second.getSize() > 0)
         {
            if (iLength > (*pToken).second.getSize() - (*pToken).second.getOffset())
               iLength = (*pToken).second.getSize() - (*pToken).second.getOffset();
         }
         memcpy((char*)(*pToken).second.getAddress() + (*pToken).second.getOffset(),strValue.data(),iLength);
   }
   return 1;
  //## end command::Template::mapToken%4F71948500FC.body
}

bool Template::read ()
{
  //## begin command::Template::read%4F6B3DC901C3.body preserve=yes
#ifdef MVS
   FlatFile  hTemplateFile("JCL",m_strMember.c_str());
#else
   FlatFile hTemplateFile("SOURCE",m_strMember.c_str());
#endif
   if (!hTemplateFile.open())
      return false;
   char* psBuffer = new char[256];
   memset(psBuffer,' ',256);
   size_t m = 0;
   char cSegment = ' ';
   string strName;
   string strToken;
   while (hTemplateFile.read(psBuffer,256,&m))
   {
      if (psBuffer[0] == '.')
      {
         char* pRcdType = psBuffer + 1;
         char* pFieldID = strchr(pRcdType,'.');
         if (pFieldID)
         {
            *pFieldID = '\0';
            ++pFieldID;
            char* s = strchr(pFieldID,'.');
            if (s)
            {
               *s = '\0';
               ++s;
            }
            char* q = strchr(s,'~');
            if (q)
            {
               *q = '\0';
               ++q;
               cSegment = *q;
            }
            q += 2;
            char* p = strchr(q,'.');
            if (p)
            {
               *p = '\0';
               strName.assign(q);
            }
            strToken.assign(pRcdType);
            strToken += pFieldID;
            int iOffset = 0;
            int iLength = 256;
            bool bTrim = false;
            if (strName.length() > 6
               && memcmp(strName.data(),"SUBSTR(",7) == 0)
            {
               vector<string> hTokens;
               Buffer::parse(strName,"(,).",hTokens);
               if (hTokens.size() == 4)
               {
                  strName = hTokens[1];
                  iOffset = atoi(hTokens[2].c_str());
                  iLength = atoi(hTokens[3].c_str());
               }
            }
            if (strName.length() > 4
               && memcmp(strName.data(),"TRIM(",5) == 0)
            {
               bTrim = true;
               vector<string> hTokens;
               Buffer::parse(strName,"()",hTokens);
               if (hTokens.size() == 2)
                  strName = hTokens[1];
            }
            Segment* pSegment = getSegment(cSegment);
            int iIndex = 0;
            const char* pcType = 0;
            char cType = ' ';
            void* pAddress = 0;
            short int i = 0;
            short int iSize = 0;
            if (pSegment
               && pSegment->_address(strName.c_str(),&pAddress,&pcType,true)
               && pSegment->offset(strName.c_str(),i,iSize))
            {
               if (pAddress)
                  cType = *pcType;
               else
               {
                  pSegment->_address(strName.c_str(),&pAddress,&pcType,false);
                  cType = '#';
               }
               TemplateToken hTemplateToken(pSegment,strName,iOffset,iLength,cType,pAddress,iSize);
               if (bTrim)
                  hTemplateToken.setTrim(true);
               m_hTemplateToken.insert(map<string,TemplateToken,less<string> >::value_type(strToken,hTemplateToken));
            }
         }
      }
   }
   delete [] psBuffer;
   return true;
  //## end command::Template::read%4F6B3DC901C3.body
}

void Template::trim (string& strValue)
{
  //## begin command::Template::trim%4FEC9984001C.body preserve=yes
   while (strValue.length() > 1
      && (strValue[0] == '0' || strValue[0] == ' '))
      strValue.erase(0,1);
   size_t pos = strValue.find_last_not_of(' ');
   if (pos == string::npos)
      strValue.erase();
   else
      strValue.erase(pos + 1);
  //## end command::Template::trim%4FEC9984001C.body
}

void Template::update (Subject* pSubject)
{
  //## begin command::Template::update%57EEA02800B9.body preserve=yes
  //## end command::Template::update%57EEA02800B9.body
}

// Additional Declarations
  //## begin command::Template%4F6B3DC901A1.declarations preserve=yes
  //## end command::Template%4F6B3DC901A1.declarations

} // namespace command

//## begin module%4F6B4103034C.epilog preserve=yes
//## end module%4F6B4103034C.epilog
