//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5625E37C01B5.cm preserve=no
//	$Date:   Oct 09 2020 12:10:40  $ $Author:   e3028298  $
//	$Revision:   1.1  $
//## end module%5625E37C01B5.cm

//## begin module%5625E37C01B5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5625E37C01B5.cp

//## Module: CXOSBC46%5625E37C01B5; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: D:\Devel\V03.1A.R007\ConnexPlatform\Server\Library\Bcdll\CXOSBC46.cpp

//## begin module%5625E37C01B5.additionalIncludes preserve=no
//## end module%5625E37C01B5.additionalIncludes

//## begin module%5625E37C01B5.includes preserve=yes
//## end module%5625E37C01B5.includes

#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSBC46_h
#include "CXODBC46.hpp"
#endif


//## begin module%5625E37C01B5.declarations preserve=no
//## end module%5625E37C01B5.declarations

//## begin module%5625E37C01B5.additionalDeclarations preserve=yes
//## end module%5625E37C01B5.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::CriteriaData 

CriteriaData::CriteriaData()
  //## begin CriteriaData::CriteriaData%5625E23803D9_const.hasinit preserve=no
      : m_pTokens(0)
  //## end CriteriaData::CriteriaData%5625E23803D9_const.hasinit
  //## begin CriteriaData::CriteriaData%5625E23803D9_const.initialization preserve=yes
  //## end CriteriaData::CriteriaData%5625E23803D9_const.initialization
{
  //## begin command::CriteriaData::CriteriaData%5625E23803D9_const.body preserve=yes
     memcpy(m_sID,"BC46",4);
  //## end command::CriteriaData::CriteriaData%5625E23803D9_const.body
}

CriteriaData::CriteriaData(const CriteriaData &right)
  //## begin CriteriaData::CriteriaData%5625E23803D9_copy.hasinit preserve=no
  //## end CriteriaData::CriteriaData%5625E23803D9_copy.hasinit
  //## begin CriteriaData::CriteriaData%5625E23803D9_copy.initialization preserve=yes
  :m_pTokens(0)
  //## end CriteriaData::CriteriaData%5625E23803D9_copy.initialization
{
  //## begin command::CriteriaData::CriteriaData%5625E23803D9_copy.body preserve=yes
   memcpy(m_sID,"BC46",4);
   if (right.getTokens())
   {
      m_pTokens = new set<string>;
      *m_pTokens = *right.m_pTokens;
   }
   m_strField = right.m_strField;
   m_strTable = right.m_strTable;
   m_strOperator = right.m_strOperator;
   m_strValue = right.m_strValue;
   m_strSubStringAttribute = right.m_strSubStringAttribute;
   m_strFunctionAttribute = right.m_strFunctionAttribute;
  //## end command::CriteriaData::CriteriaData%5625E23803D9_copy.body
}


CriteriaData::~CriteriaData()
{
  //## begin command::CriteriaData::~CriteriaData%5625E23803D9_dest.body preserve=yes
   delete m_pTokens;
  //## end command::CriteriaData::~CriteriaData%5625E23803D9_dest.body
}



//## Other Operations (implementation)
void CriteriaData::applyFunction (string& strValue)
{
  //## begin command::CriteriaData::applyFunction%5F6CAF9100D4.body preserve=yes
   if (m_strFunctionAttribute == "TRIM")
      trim(strValue);
   if (m_strFunctionAttribute == "UPPER")
      transform(strValue.begin(),strValue.end(),strValue.begin(),::toupper);
   if (m_strFunctionAttribute == "LOWER")
      transform(strValue.begin(),strValue.end(),strValue.begin(),::tolower);
   if (m_strFunctionAttribute == "LENGTH")
   {
      char szTemp[PERCENTD];
      strValue.assign(szTemp,sprintf(szTemp,"%010d",(int)strValue.length()));
      m_strValue.assign(szTemp,sprintf(szTemp,"%010d",atoi(m_strValue.c_str())));
   }
   if (m_strFunctionAttribute.substr(0,8) == "variance")
   {
      vector<string> hTokens;
      if (Buffer::parse(m_strFunctionAttribute,"()",hTokens) == 2)
      {
         m_strOperator = (m_strOperator == "=") ? "BETWEEN" : "NOT BETWEEN";
         char szTemp[PERCENTF];
         double dAmount = atof(m_strValue.c_str()) / 100;
         m_strValue.assign(szTemp,sprintf(szTemp,"%018.2f-%018.2f",dAmount - atoi(hTokens[1].c_str()),
            dAmount + atoi(hTokens[1].c_str())));
         strValue.assign(szTemp,sprintf(szTemp,"%018.2f",atof(strValue.c_str())/100));
      }
   }
   if (m_strFunctionAttribute == "ATOI")
   {
      char szTemp[PERCENTD];
      strValue.assign(szTemp,sprintf(szTemp,"%d",atoi(strValue.c_str())));
   }
  //## end command::CriteriaData::applyFunction%5F6CAF9100D4.body
}

void CriteriaData::clear ()
{
  //## begin command::CriteriaData::clear%5628B41B02D7.body preserve=yes
   setValue("");
   m_strField.erase();
   m_strOperator.erase();
   m_strTable.erase();
   m_strSubStringAttribute.erase();
   m_strFunctionAttribute.erase();
  //## end command::CriteriaData::clear%5628B41B02D7.body
}

bool CriteriaData::compareValue (const string& strValue) const
{
  //## begin command::CriteriaData::compareValue%5628F8AC00D7.body preserve=yes
   string strTemp = strValue;
   vector<string> hTokens;
   if (!m_strSubStringAttribute.empty())
   {
      if (Buffer::parse(m_strSubStringAttribute,",",hTokens) == 2 
         && strValue.length() > atoi(hTokens[0].c_str()))
         strTemp = strTemp.substr(atoi(hTokens[0].c_str()),atoi(hTokens[1].c_str()));
   }
   if (m_strOperator == "=")
      return strTemp == m_strValue;
   if (m_strOperator == "!=" || m_strOperator == "<>")
      return strTemp != m_strValue;
   if (m_strOperator == "<")
      return strTemp < m_strValue;
   if (m_strOperator == "<=")
      return strTemp <= m_strValue;
   if (m_strOperator == ">=")
      return strTemp >= m_strValue;
   if (m_strOperator == "BETWEEN" || m_strOperator == "NOT BETWEEN")
   {
      bool bResult = false;
      if (Buffer::parse(m_strValue,"-",hTokens) == 2)
        ;
      else
      if (hTokens.size() == 3
         && hTokens[0].empty())
      {
         hTokens[0] = '-' + hTokens[1];
         hTokens[1] = hTokens[2];
      }
      else
         return bResult;
      bResult = (strTemp >= trim(hTokens[0]) && strTemp <= trim(hTokens[1]));
      if (memcmp(m_strOperator.c_str(),"NOT",3) == 0)
         bResult = !bResult;
      return bResult;
   }
   if(!m_pTokens)
      return false;
   if(m_strOperator == "IN")
      return m_pTokens->find(strTemp) != m_pTokens->end();
   if (m_strOperator == "NOT IN")
      return m_pTokens->find(strTemp) == m_pTokens->end();
   if (m_strOperator == "IN RANGE" 
      || m_strOperator == "NOT IN RANGE")
   {
      bool bResult = false;
      for (set<string>::iterator p = m_pTokens->begin(); p != m_pTokens->end(); p++)
      {
         if (Buffer::parse((*p),"-",hTokens) != 2)
            return false;
         if (strTemp >= trim(hTokens[0]) && strTemp <= trim(hTokens[1]))
         {
            bResult = true;
            break;
         }
      }
      if (memcmp(m_strOperator.c_str(),"NOT",3) == 0)
         bResult = !bResult;
      return bResult;
   }
   return false;
  //## end command::CriteriaData::compareValue%5628F8AC00D7.body
}

void CriteriaData::setValue (const string& strValue)
{
  //## begin command::CriteriaData::setValue%5628A3EC03DC.body preserve=yes
   m_strValue.erase();
   if (m_pTokens)
      m_pTokens->erase(m_pTokens->begin(),m_pTokens->end());
   if (strValue.size())
   {
      vector <string> hTokens;
      int i = Buffer::parse(strValue," ,",hTokens);
      if (i > 1 &&
         (m_strOperator == "IN" || m_strOperator == "NOT IN"
         || m_strOperator == "IN RANGE" || m_strOperator == "NOT IN RANGE"))
      {
         if (!m_pTokens)
            m_pTokens = new set<string>;
         while (i > 0)
            m_pTokens->insert(hTokens[--i]);
      }
      else
         m_strValue = strValue;
   }
  //## end command::CriteriaData::setValue%5628A3EC03DC.body
}

// Additional Declarations
  //## begin command::CriteriaData%5625E23803D9.declarations preserve=yes
  //## end command::CriteriaData%5625E23803D9.declarations

} // namespace command

//## begin module%5625E37C01B5.epilog preserve=yes
//## end module%5625E37C01B5.epilog
