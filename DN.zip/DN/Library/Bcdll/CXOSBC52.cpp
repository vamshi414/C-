//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5888E996016B.cm preserve=no
//	$Date:   Jun 09 2017 18:15:32  $ $Author:   e1009510  $ $Revision:   1.0  $
//## end module%5888E996016B.cm

//## begin module%5888E996016B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5888E996016B.cp

//## Module: CXOSBC52%5888E996016B; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC52.cpp

//## begin module%5888E996016B.additionalIncludes preserve=no
//## end module%5888E996016B.additionalIncludes

//## begin module%5888E996016B.includes preserve=yes
//## end module%5888E996016B.includes

#ifndef CXOSBC51_h
#include "CXODBC51.hpp"
#endif
#ifndef CXOSBC52_h
#include "CXODBC52.hpp"
#endif


//## begin module%5888E996016B.declarations preserve=no
//## end module%5888E996016B.declarations

//## begin module%5888E996016B.additionalDeclarations preserve=yes
//## end module%5888E996016B.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::APIExportFactory 

//## begin command::APIExportFactory::Instance%5888E92500E0.attr preserve=no  private: static command::APIExportFactory* {V} 0
command::APIExportFactory* APIExportFactory::m_pInstance = 0;
//## end command::APIExportFactory::Instance%5888E92500E0.attr

APIExportFactory::APIExportFactory()
  //## begin APIExportFactory::APIExportFactory%5888E8470150_const.hasinit preserve=no
  //## end APIExportFactory::APIExportFactory%5888E8470150_const.hasinit
  //## begin APIExportFactory::APIExportFactory%5888E8470150_const.initialization preserve=yes
  //## end APIExportFactory::APIExportFactory%5888E8470150_const.initialization
{
  //## begin command::APIExportFactory::APIExportFactory%5888E8470150_const.body preserve=yes
   m_pInstance = this;
  //## end command::APIExportFactory::APIExportFactory%5888E8470150_const.body
}


APIExportFactory::~APIExportFactory()
{
  //## begin command::APIExportFactory::~APIExportFactory%5888E8470150_dest.body preserve=yes
   m_pInstance = 0;
  //## end command::APIExportFactory::~APIExportFactory%5888E8470150_dest.body
}



//## Other Operations (implementation)
command::APIExportFactory* APIExportFactory::instance ()
{
  //## begin command::APIExportFactory::instance%5888E9580036.body preserve=yes
   return m_pInstance;
  //## end command::APIExportFactory::instance%5888E9580036.body
}

// Additional Declarations
  //## begin command::APIExportFactory%5888E8470150.declarations preserve=yes
  //## end command::APIExportFactory%5888E8470150.declarations

} // namespace command

//## begin module%5888E996016B.epilog preserve=yes
//## end module%5888E996016B.epilog
