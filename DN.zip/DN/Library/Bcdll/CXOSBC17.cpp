//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6436F248018B.cm preserve=no
//## end module%6436F248018B.cm

//## begin module%6436F248018B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6436F248018B.cp

//## Module: CXOSBC17%6436F248018B; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC17.cpp

//## begin module%6436F248018B.additionalIncludes preserve=no
//## end module%6436F248018B.additionalIncludes

//## begin module%6436F248018B.includes preserve=yes
#include <math.h>
//## end module%6436F248018B.includes

#ifndef CXOSBS22_h
#include "CXODBS22.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSBC17_h
#include "CXODBC17.hpp"
#endif


//## begin module%6436F248018B.declarations preserve=no
//## end module%6436F248018B.declarations

//## begin module%6436F248018B.additionalDeclarations preserve=yes
#define STS_RECORD_NOT_FOUND 14
//## end module%6436F248018B.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::Count 

//## begin command::Count::Instance%64381E2E02C3.attr preserve=no  private: static command::Count* {V} 0
command::Count* Count::m_pInstance = 0;
//## end command::Count::Instance%64381E2E02C3.attr

Count::Count()
  //## begin Count::Count%6436D7AB03A7_const.hasinit preserve=no
  //## end Count::Count%6436D7AB03A7_const.hasinit
  //## begin Count::Count%6436D7AB03A7_const.initialization preserve=yes
  //## end Count::Count%6436D7AB03A7_const.initialization
{
  //## begin command::Count::Count%6436D7AB03A7_const.body preserve=yes
   memcpy(m_sID,"BC17",4);
  //## end command::Count::Count%6436D7AB03A7_const.body
}


Count::~Count()
{
  //## begin command::Count::~Count%6436D7AB03A7_dest.body preserve=yes
  //## end command::Count::~Count%6436D7AB03A7_dest.body
}



//## Other Operations (implementation)
bool Count::apply (segment::HealthMonitorSegment& hHealthMonitorSegment)
{
  //## begin command::Count::apply%6436F39F0047.body preserve=yes
   hHealthMonitorSegment.setTIME_PERIOD(Clock::instance()->getYYYYMMDDHHMMSS().substr(0,10));
   hHealthMonitorSegment.setIMAGE_ID(Application::instance()->image());
   Table hTable;
   hHealthMonitorSegment.setColumns(hTable);
   if (hHealthMonitorSegment.getOperator() == "S")
      ;
   else
   if (hHealthMonitorSegment.getOperator() == "I")
      hTable.set("ITEM_COUNT",hHealthMonitorSegment.getITEM_COUNT(),false,"+");
   else
      return false;
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if (!pUpdateStatement->execute(hTable))
   {
      if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      {
         hTable.reset();
         hHealthMonitorSegment.setColumns(hTable);
         auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         return pInsertStatement->execute(hTable);
      }
      return false;
   }
   return true;
  //## end command::Count::apply%6436F39F0047.body
}

bool Count::commit ()
{
  //## begin command::Count::commit%64381E0201A2.body preserve=yes
   bool b = true;
   HealthMonitorSegment* p = HealthMonitorSegment::instance();
   map<string,int,less<string> >::iterator q;
   for (q = m_hBUCKET.begin();q != m_hBUCKET.end();++q)
   {
      p->setDOMAIN_NAME((*q).first.substr(0,8));
      p->setMEMBER_NAME((*q).first.substr(8,32));
      p->setBUCKET((*q).first.substr(40,8));
      p->setOperator("I");
      p->setITEM_COUNT((*q).second);
      if (!apply(*p))
         b = false;
      (*q).second = 0;
   }
   m_hBUCKET.erase(m_hBUCKET.begin(),m_hBUCKET.end());
   return b;
  //## end command::Count::commit%64381E0201A2.body
}

void Count::increment (const reusable::string& strDOMAIN_NAME, const reusable::string& strMEMBER_NAME, const reusable::string& strBUCKET, int iITEM_COUNT)
{
  //## begin command::Count::increment%6436D7C80311.body preserve=yes
   HealthMonitorSegment* p = HealthMonitorSegment::instance();
   char szFirst[49] = {"                                                "};
   memcpy(szFirst,strDOMAIN_NAME.data(),min(size_t(8),strDOMAIN_NAME.length()));
   memcpy(szFirst + 8,strMEMBER_NAME.data(),min(size_t(32),strMEMBER_NAME.length()));
   memcpy(szFirst + 40,strBUCKET.data(),min(size_t(8),strBUCKET.length()));
   string strFirst(szFirst,48);
   map<string,int,less<string> >::iterator q = m_hBUCKET.find(strFirst);
   if (q == m_hBUCKET.end())
   {
      m_hBUCKET.insert(map<string,int,less<string> >::value_type(strFirst,iITEM_COUNT));
      return;
   }
   (*q).second += iITEM_COUNT;
  //## end command::Count::increment%6436D7C80311.body
}

Count* Count::instance ()
{
  //## begin command::Count::instance%64381E130383.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new Count();
   return m_pInstance;
  //## end command::Count::instance%64381E130383.body
}

bool Count::set (const reusable::string& strDOMAIN_NAME, const reusable::string& strMEMBER_NAME, const reusable::string& strBUCKET, int iITEM_COUNT)
{
  //## begin command::Count::set%6436D8B8028A.body preserve=yes
   HealthMonitorSegment* p = HealthMonitorSegment::instance();
   p->setDOMAIN_NAME(strDOMAIN_NAME);
   p->setMEMBER_NAME(strMEMBER_NAME);
   p->setBUCKET(strBUCKET);
   p->setOperator("S");
   p->setITEM_COUNT(iITEM_COUNT);
   return apply(*p);
  //## end command::Count::set%6436D8B8028A.body
}

// Additional Declarations
  //## begin command::Count%6436D7AB03A7.declarations preserve=yes
  //## end command::Count%6436D7AB03A7.declarations

} // namespace command

//## begin module%6436F248018B.epilog preserve=yes
//## end module%6436F248018B.epilog
