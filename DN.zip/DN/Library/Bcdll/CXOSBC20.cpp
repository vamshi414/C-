//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%44E387D601E4.cm preserve=no
//	$Date:   Jul 12 2019 16:00:56  $ $Author:   e1089842  $ $Revision:   1.10  $
//## end module%44E387D601E4.cm

//## begin module%44E387D601E4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%44E387D601E4.cp

//## Module: CXOSBC20%44E387D601E4; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV03.0A.R006\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC20.cpp

//## begin module%44E387D601E4.additionalIncludes preserve=no
//## end module%44E387D601E4.additionalIncludes

//## begin module%44E387D601E4.includes preserve=yes
//## end module%44E387D601E4.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSBC20_h
#include "CXODBC20.hpp"
#endif


//## begin module%44E387D601E4.declarations preserve=no
//## end module%44E387D601E4.declarations

//## begin module%44E387D601E4.additionalDeclarations preserve=yes
//## end module%44E387D601E4.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::Audit 

Audit::Audit()
  //## begin Audit::Audit%442D8AA50222_const.hasinit preserve=no
      : m_pExportFile(0)
  //## end Audit::Audit%442D8AA50222_const.hasinit
  //## begin Audit::Audit%442D8AA50222_const.initialization preserve=yes
  //## end Audit::Audit%442D8AA50222_const.initialization
{
  //## begin command::Audit::Audit%442D8AA50222_const.body preserve=yes
  //## end command::Audit::Audit%442D8AA50222_const.body
}

Audit::Audit (database::ExportFile* pExportFile)
  //## begin command::Audit::Audit%47F2220C03E7.hasinit preserve=no
      : m_pExportFile(0)
  //## end command::Audit::Audit%47F2220C03E7.hasinit
  //## begin command::Audit::Audit%47F2220C03E7.initialization preserve=yes
  //## end command::Audit::Audit%47F2220C03E7.initialization
{
  //## begin command::Audit::Audit%47F2220C03E7.body preserve=yes
   m_pExportFile = pExportFile;
  //## end command::Audit::Audit%47F2220C03E7.body
}

Audit::Audit (const string& strDX_FILE_TYPE, const string& strENTITY_TYPE, const string& strENTITY_ID, const string& strDATE_RECON, const string& strSCHED_TIME)
  //## begin command::Audit::Audit%442D8B8A037A.hasinit preserve=no
      : m_pExportFile(0)
  //## end command::Audit::Audit%442D8B8A037A.hasinit
  //## begin command::Audit::Audit%442D8B8A037A.initialization preserve=yes
  //## end command::Audit::Audit%442D8B8A037A.initialization
{
  //## begin command::Audit::Audit%442D8B8A037A.body preserve=yes
   m_pExportFile = new ExportFile(strDX_FILE_TYPE,strENTITY_TYPE,strENTITY_ID,strDATE_RECON,strSCHED_TIME);
  //## end command::Audit::Audit%442D8B8A037A.body
}


Audit::~Audit()
{
  //## begin command::Audit::~Audit%442D8AA50222_dest.body preserve=yes
   if (m_pExportFile)
      delete m_pExportFile;
  //## end command::Audit::~Audit%442D8AA50222_dest.body
}



//## Other Operations (implementation)
void Audit::add (const char cSegment, segment::Segment* pSegment)
{
  //## begin command::Audit::add%442D8BAA0177.body preserve=yes
   m_hXMLText.add(cSegment,pSegment);
  //## end command::Audit::add%442D8BAA0177.body
}

bool Audit::complete ()
{
  //## begin command::Audit::complete%446C7F7600CF.body preserve=yes
   return m_pExportFile->complete();
  //## end command::Audit::complete%446C7F7600CF.body
}

bool Audit::empty ()
{
  //## begin command::Audit::empty%456F069F00EA.body preserve=yes
   return (m_pExportFile->getCount() == 0);
  //## end command::Audit::empty%456F069F00EA.body
}

const int& Audit::getDX_FILE_ID ()
{
  //## begin command::Audit::getDX_FILE_ID%5D28C9F20006.body preserve=yes
   return (m_pExportFile->getDX_FILE_ID());
  //## end command::Audit::getDX_FILE_ID%5D28C9F20006.body
}

const string& Audit::getDX_FILE_TYPE ()
{
  //## begin command::Audit::getDX_FILE_TYPE%5D28CABB03C1.body preserve=yes
   return (m_pExportFile->getDX_FILE_TYPE());
  //## end command::Audit::getDX_FILE_TYPE%5D28CABB03C1.body
}

bool Audit::isPresent ()
{
  //## begin command::Audit::isPresent%45AA937F009C.body preserve=yes
   return m_pExportFile->isPresent();
  //## end command::Audit::isPresent%45AA937F009C.body
}

bool Audit::read (int iSEQ_NO, string& strDATA_BUFFER)
{
  //## begin command::Audit::read%4D093A2E03D0.body preserve=yes
   return m_pExportFile->read(iSEQ_NO,strDATA_BUFFER);
  //## end command::Audit::read%4D093A2E03D0.body
}

void Audit::release ()
{
  //## begin command::Audit::release%480F275000C4.body preserve=yes
   m_pExportFile = NULL;
  //## end command::Audit::release%480F275000C4.body
}

bool Audit::replace (int lSEQ_NO, const string& strDATA_BUFFER)
{
  //## begin command::Audit::replace%4468083B0271.body preserve=yes
   return m_pExportFile->replace(lSEQ_NO,strDATA_BUFFER);
  //## end command::Audit::replace%4468083B0271.body
}

bool Audit::report (const char cType)
{
  //## begin command::Audit::report%442D8BE10280.body preserve=yes
   vector<string>::iterator p;
   for (p = m_hTemplate.begin();p != m_hTemplate.end();++p)
   {
      if ((*p)[0] == cType)
      {
         string strText((*p).data() + 1,(*p).length() - 1);
         m_hXMLText.substitute(strText);
         if (!m_pExportFile->write(strText.data(),(int)strText.length()))
            return false;
      }
   }
   return true;
  //## end command::Audit::report%442D8BE10280.body
}

void Audit::setTemplate (const char** ppszTemplate)
{
  //## begin command::Audit::setTemplate%442D8BB40148.body preserve=yes
   int i = 0;
   while (ppszTemplate[i])
      m_hTemplate.push_back(string(ppszTemplate[i++]));
  //## end command::Audit::setTemplate%442D8BB40148.body
}

bool Audit::write (char *szDATA_BUFFER, int iBufferLen, int iSEQ_NO)
{
  //## begin command::Audit::write%4D097DAE002E.body preserve=yes
   if (m_pExportFile->replace(iSEQ_NO,string(szDATA_BUFFER,iBufferLen)))
      return true;
   return m_pExportFile->write(szDATA_BUFFER,iBufferLen,iSEQ_NO);
  //## end command::Audit::write%4D097DAE002E.body
}

// Additional Declarations
  //## begin command::Audit%442D8AA50222.declarations preserve=yes
  //## end command::Audit%442D8AA50222.declarations

} // namespace command

//## begin module%44E387D601E4.epilog preserve=yes
//## end module%44E387D601E4.epilog
