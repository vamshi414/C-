//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4AEF0E5E036B.cm preserve=no
//	$Date:   Nov 06 2009 15:18:56  $ $Author:   D02405  $
//	$Revision:   1.0  $
//## end module%4AEF0E5E036B.cm

//## begin module%4AEF0E5E036B.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4AEF0E5E036B.cp

//## Module: CXOSBC32%4AEF0E5E036B; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC32.cpp

//## begin module%4AEF0E5E036B.additionalIncludes preserve=no
//## end module%4AEF0E5E036B.additionalIncludes

//## begin module%4AEF0E5E036B.includes preserve=yes
//## end module%4AEF0E5E036B.includes

#ifndef CXOSBC31_h
#include "CXODBC31.hpp"
#endif
#ifndef CXOSBC32_h
#include "CXODBC32.hpp"
#endif


//## begin module%4AEF0E5E036B.declarations preserve=no
//## end module%4AEF0E5E036B.declarations

//## begin module%4AEF0E5E036B.additionalDeclarations preserve=yes
//## end module%4AEF0E5E036B.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::NetworkFactory 

//## begin command::NetworkFactory::Instance%4AEF0BB403A9.attr preserve=no  private: static command::NetworkFactory* {V} 0
command::NetworkFactory* NetworkFactory::m_pInstance = 0;
//## end command::NetworkFactory::Instance%4AEF0BB403A9.attr

NetworkFactory::NetworkFactory()
  //## begin NetworkFactory::NetworkFactory%4AEF0B5A036B_const.hasinit preserve=no
  //## end NetworkFactory::NetworkFactory%4AEF0B5A036B_const.hasinit
  //## begin NetworkFactory::NetworkFactory%4AEF0B5A036B_const.initialization preserve=yes
  //## end NetworkFactory::NetworkFactory%4AEF0B5A036B_const.initialization
{
  //## begin command::NetworkFactory::NetworkFactory%4AEF0B5A036B_const.body preserve=yes
   m_pInstance = this;
  //## end command::NetworkFactory::NetworkFactory%4AEF0B5A036B_const.body
}


NetworkFactory::~NetworkFactory()
{
  //## begin command::NetworkFactory::~NetworkFactory%4AEF0B5A036B_dest.body preserve=yes
   m_pInstance = 0;
  //## end command::NetworkFactory::~NetworkFactory%4AEF0B5A036B_dest.body
}



//## Other Operations (implementation)
command::NetworkFactory* NetworkFactory::instance ()
{
  //## begin command::NetworkFactory::instance%4AEF0BA30280.body preserve=yes
   return m_pInstance;
  //## end command::NetworkFactory::instance%4AEF0BA30280.body
}

// Additional Declarations
  //## begin command::NetworkFactory%4AEF0B5A036B.declarations preserve=yes
  //## end command::NetworkFactory%4AEF0B5A036B.declarations

} // namespace command

//## begin module%4AEF0E5E036B.epilog preserve=yes
//## end module%4AEF0E5E036B.epilog
