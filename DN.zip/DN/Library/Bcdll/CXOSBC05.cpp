//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3E9AD3BB0203.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E9AD3BB0203.cm

//## begin module%3E9AD3BB0203.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3E9AD3BB0203.cp

//## Module: CXOSBC05%3E9AD3BB0203; Package body
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC05.cpp

//## begin module%3E9AD3BB0203.additionalIncludes preserve=no
//## end module%3E9AD3BB0203.additionalIncludes

//## begin module%3E9AD3BB0203.includes preserve=yes
// $Date:   Jun 30 2006 11:35:10  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%3E9AD3BB0203.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBC07_h
#include "CXODBC07.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBC05_h
#include "CXODBC05.hpp"
#endif


//## begin module%3E9AD3BB0203.declarations preserve=no
//## end module%3E9AD3BB0203.declarations

//## begin module%3E9AD3BB0203.additionalDeclarations preserve=yes
#define STS_ACCESS_SECURITY_UNAVAILABLE 25
//## end module%3E9AD3BB0203.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::LogoffCommand 

LogoffCommand::LogoffCommand()
  //## begin LogoffCommand::LogoffCommand%3E9AD37E02DE_const.hasinit preserve=no
  //## end LogoffCommand::LogoffCommand%3E9AD37E02DE_const.hasinit
  //## begin LogoffCommand::LogoffCommand%3E9AD37E02DE_const.initialization preserve=yes
  : ClientCommand("S0005D","@LOGOFF ")
  //## end LogoffCommand::LogoffCommand%3E9AD37E02DE_const.initialization
{
  //## begin command::LogoffCommand::LogoffCommand%3E9AD37E02DE_const.body preserve=yes
   memcpy(m_sID,"BC05",4);
  //## end command::LogoffCommand::LogoffCommand%3E9AD37E02DE_const.body
}

LogoffCommand::LogoffCommand (Handler* pSuccessor)
  //## begin command::LogoffCommand::LogoffCommand%3E9C022D03B9.hasinit preserve=no
  //## end command::LogoffCommand::LogoffCommand%3E9C022D03B9.hasinit
  //## begin command::LogoffCommand::LogoffCommand%3E9C022D03B9.initialization preserve=yes
  : ClientCommand("S0005D","@LOGOFF ")
  //## end command::LogoffCommand::LogoffCommand%3E9C022D03B9.initialization
{
  //## begin command::LogoffCommand::LogoffCommand%3E9C022D03B9.body preserve=yes
   memcpy(m_sID,"BC05",4);
   m_pSuccessor = pSuccessor;
  //## end command::LogoffCommand::LogoffCommand%3E9C022D03B9.body
}


LogoffCommand::~LogoffCommand()
{
  //## begin command::LogoffCommand::~LogoffCommand%3E9AD37E02DE_dest.body preserve=yes
  //## end command::LogoffCommand::~LogoffCommand%3E9AD37E02DE_dest.body
}



//## Other Operations (implementation)
bool LogoffCommand::execute ()
{
  //## begin command::LogoffCommand::execute%3E9AD6FB00AB.body preserve=yes
   UseCase hUseCase("CLIENT","## CL07 LOGOFF");
   int iRC;
   if ((iRC = Command::parse()) != 0)
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,iRC);
      return false;
   }
   if (!UserPool::instance()->logoffRequest(*Message::instance(Message::INBOUND),CommonHeaderSegment::instance(),getResponseTimeSegment()))
   {
      sendError(STS_SECURITY_ERROR,STS_SEVERE_ERROR,STS_ACCESS_SECURITY_UNAVAILABLE);
      return false;
   }
   return true;
  //## end command::LogoffCommand::execute%3E9AD6FB00AB.body
}

// Additional Declarations
  //## begin command::LogoffCommand%3E9AD37E02DE.declarations preserve=yes
  //## end command::LogoffCommand%3E9AD37E02DE.declarations

} // namespace command

//## begin module%3E9AD3BB0203.epilog preserve=yes
//## end module%3E9AD3BB0203.epilog
