//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4242F9AA0251.cm preserve=no
//	$Date:   May 14 2020 16:29:56  $ $Author:   e1009510  $
//	$Revision:   1.29  $
//## end module%4242F9AA0251.cm

//## begin module%4242F9AA0251.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4242F9AA0251.cp

//## Module: CXOSBC19%4242F9AA0251; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.3B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC19.cpp

//## begin module%4242F9AA0251.additionalIncludes preserve=no
//## end module%4242F9AA0251.additionalIncludes

//## begin module%4242F9AA0251.includes preserve=yes
#include "CXODIF28.hpp"
#include "CXODRU10.hpp" //Transaction
//## end module%4242F9AA0251.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC20_h
#include "CXODBC20.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSBS24_h
#include "CXODBS24.hpp"
#endif
#ifndef CXOSRU28_h
#include "CXODRU28.hpp"
#endif
#ifndef CXOSBC19_h
#include "CXODBC19.hpp"
#endif


//## begin module%4242F9AA0251.declarations preserve=no
//## end module%4242F9AA0251.declarations

//## begin module%4242F9AA0251.additionalDeclarations preserve=yes
//## end module%4242F9AA0251.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::ImportTransaction 

ImportTransaction::ImportTransaction()
  //## begin ImportTransaction::ImportTransaction%4242F95E03D8_const.hasinit preserve=no
      : m_lDI_FILE_ID(0),
        m_siSEQ_NO(0),
        m_lTRANSACTION_NO(0),
        m_lTSTAMP_RETRY_COUNT(0)
  //## end ImportTransaction::ImportTransaction%4242F95E03D8_const.hasinit
  //## begin ImportTransaction::ImportTransaction%4242F95E03D8_const.initialization preserve=yes
  //## end ImportTransaction::ImportTransaction%4242F95E03D8_const.initialization
{
  //## begin command::ImportTransaction::ImportTransaction%4242F95E03D8_const.body preserve=yes
  //## end command::ImportTransaction::ImportTransaction%4242F95E03D8_const.body
}

ImportTransaction::ImportTransaction(const ImportTransaction &right)
  //## begin ImportTransaction::ImportTransaction%4242F95E03D8_copy.hasinit preserve=no
      : m_lDI_FILE_ID(0),
        m_siSEQ_NO(0),
        m_lTRANSACTION_NO(0),
        m_lTSTAMP_RETRY_COUNT(0)
  //## end ImportTransaction::ImportTransaction%4242F95E03D8_copy.hasinit
  //## begin ImportTransaction::ImportTransaction%4242F95E03D8_copy.initialization preserve=yes
   ,Observer(right)
  //## end ImportTransaction::ImportTransaction%4242F95E03D8_copy.initialization
{
  //## begin command::ImportTransaction::ImportTransaction%4242F95E03D8_copy.body preserve=yes
   memcpy_s(m_sID,4,"BC19",4);
   m_lDI_FILE_ID = right.getDI_FILE_ID();
   m_lTRANSACTION_NO = right.getTRANSACTION_NO();
   m_lTSTAMP_RETRY_COUNT = right.getTSTAMP_RETRY_COUNT();
   m_strDI_FILE_TYPE = right.getDI_FILE_TYPE();
   m_strDX_FILE_TYPE = right.getDI_FILE_TYPE();
   m_strTSTAMP_INITIATED = right.getTSTAMP_INITIATED();
   m_strSCHED_TIME = right.getSCHED_TIME();
   m_hDATA_BUFFER = right.m_hDATA_BUFFER;
   m_strDI_PATH = right.getDI_PATH();
  //## end command::ImportTransaction::ImportTransaction%4242F95E03D8_copy.body
}

ImportTransaction::ImportTransaction (const char* pszDX_FILE_TYPE)
  //## begin command::ImportTransaction::ImportTransaction%4720E6D3038A.hasinit preserve=no
      : m_lDI_FILE_ID(0),
        m_siSEQ_NO(0),
        m_lTRANSACTION_NO(0),
        m_lTSTAMP_RETRY_COUNT(0)
  //## end command::ImportTransaction::ImportTransaction%4720E6D3038A.hasinit
  //## begin command::ImportTransaction::ImportTransaction%4720E6D3038A.initialization preserve=yes
   ,m_strDX_FILE_TYPE(pszDX_FILE_TYPE)
   ,m_strHeading("HTransaction,Sequence,Key,Result,")
   ,m_strDetail("D~Z.TRANSACTION_NO.,~Z.SEQ_NO.,~Z.IMPORT_KEY.,"
    "~Z.REJECT_CODES.,") 
  //## end command::ImportTransaction::ImportTransaction%4720E6D3038A.initialization
{
  //## begin command::ImportTransaction::ImportTransaction%4720E6D3038A.body preserve=yes
  //## end command::ImportTransaction::ImportTransaction%4720E6D3038A.body
}


ImportTransaction::~ImportTransaction()
{
  //## begin command::ImportTransaction::~ImportTransaction%4242F95E03D8_dest.body preserve=yes
  //## end command::ImportTransaction::~ImportTransaction%4242F95E03D8_dest.body
}


ImportTransaction & ImportTransaction::operator=(const ImportTransaction &right)
{
  //## begin command::ImportTransaction::operator=%4242F95E03D8_assign.body preserve=yes
   if (this == &right)
      return *this;
   Observer::operator=(right);
   m_lDI_FILE_ID = right.getDI_FILE_ID();
   m_lTRANSACTION_NO = right.getTRANSACTION_NO();
   m_lTSTAMP_RETRY_COUNT = right.getTSTAMP_RETRY_COUNT();
   m_strDI_FILE_TYPE = right.getDI_FILE_TYPE();
   m_strDX_FILE_TYPE = right.getDI_FILE_TYPE();
   m_strTSTAMP_INITIATED = right.getTSTAMP_INITIATED();
   m_strSCHED_TIME = right.getSCHED_TIME();
   m_hDATA_BUFFER = right.m_hDATA_BUFFER;
   m_strDI_PATH = right.getDI_PATH();
   return *this;
  //## end command::ImportTransaction::operator=%4242F95E03D8_assign.body
}



//## Other Operations (implementation)
void ImportTransaction::addSegments (command::Audit& hAudit)
{
  //## begin command::ImportTransaction::addSegments%47234655033C.body preserve=yes
  //## end command::ImportTransaction::addSegments%47234655033C.body
}

void ImportTransaction::bind (reusable::Query& hQuery)
{
  //## begin command::ImportTransaction::bind%50479A5C0293.body preserve=yes
   m_hDATA_BUFFER.erase(m_hDATA_BUFFER.begin(),m_hDATA_BUFFER.end());
   hQuery.bind("DI_DATA","DI_FILE_ID",Column::LONG,&m_lDI_FILE_ID);
   hQuery.bind("DI_DATA","TRANSACTION_NO",Column::LONG,&m_lTRANSACTION_NO);
   hQuery.bind("DI_DATA","TSTAMP_RETRY_COUNT",Column::LONG,&m_lTSTAMP_RETRY_COUNT);
   hQuery.bind("DI_DATA_CONTROL","DI_FILE_TYPE",Column::STRING,&m_strDI_FILE_TYPE);
   hQuery.bind("DI_DATA_CONTROL","TSTAMP_INITIATED",Column::STRING,&m_strTSTAMP_INITIATED);
   hQuery.bind("DI_DATA_CONTROL","DI_PATH",Column::STRING,&m_strDI_PATH);
  //## end command::ImportTransaction::bind%50479A5C0293.body
}

bool ImportTransaction::endAudit (int lTSTAMP_RETRY_COUNT)
{
  //## begin command::ImportTransaction::endAudit%45824B09035F.body preserve=yes
   int iCount[4] = {0,0,0,0};
   // remaining in current pass
   Query hQuery;
   hQuery.bind("DI_DATA","*",Column::LONG,&iCount[0],0,"COUNT");
   hQuery.setBasicPredicate("DI_DATA","DI_STATE","<>","IC");
   hQuery.setBasicPredicate("DI_DATA","TSTAMP_RETRY_COUNT","=",lTSTAMP_RETRY_COUNT);
   hQuery.setBasicPredicate("DI_DATA","DI_FILE_ID","=",m_lDI_FILE_ID);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   pSelectStatement->execute(hQuery);
   if (iCount[0] != 0)
      return false;
   setENTITY_ID();
   Audit hAudit(m_strDX_FILE_TYPE,"CU",m_strENTITY_ID,getDATE_RECON(),getSCHED_TIME());
   short iNull = -1;
   // success
   hQuery.reset();
   hQuery.bind("DI_DATA","*",Column::LONG,&iCount[1],0,"COUNT");
   hQuery.setBasicPredicate("DI_DATA","DI_STATE","=","IC");
   hQuery.setBasicPredicate("DI_DATA","DI_FILE_ID","=",m_lDI_FILE_ID);
   pSelectStatement->execute(hQuery);
   // total in file
   hQuery.reset();
   hQuery.bind("DI_DATA","*",Column::LONG,&iCount[2],0,"COUNT");
   hQuery.setBasicPredicate("DI_DATA","DI_FILE_ID","=",m_lDI_FILE_ID);
   pSelectStatement->execute(hQuery);
   ImportReportAuditSegment hImportReportAuditSegment;
   hImportReportAuditSegment.setPass(m_lTSTAMP_RETRY_COUNT + 1);
   hImportReportAuditSegment.setCount(iCount[2],0);
   hImportReportAuditSegment.setCount(iCount[1],1);
   // failure
   iCount[3] = iCount[2] - iCount[1];
   hImportReportAuditSegment.setCount(iCount[3],2);
   const char* pszAudit[] =
   {
      "T",
      "TPass    ,~A.Pass. of 6",
      "T",
      "TTotal   ,~A.Total.",
      "TSuccess ,~A.Success.",
      "TFailure ,~A.Failure.",
      0
   };
   hAudit.setTemplate(&pszAudit[0]);
   hAudit.add('A',&hImportReportAuditSegment);
   hAudit.report('T');
   hAudit.complete();
   char szERRORS[5] = {""};
   snprintf(szERRORS,sizeof(szERRORS),"%04d",iCount[3]);
   // ST275 - PROCESSING OF IMPORT FILE RECORDS COMPLETED WITH @ ERRORS 
   Console::display("ST275",szERRORS);
   return true;
  //## end command::ImportTransaction::endAudit%45824B09035F.body
}

bool ImportTransaction::execute (const command::ImportTransaction& hImportTransaction)
{
  //## begin command::ImportTransaction::execute%42482E110222.body preserve=yes
   *this = hImportTransaction;
   m_strDATE_RECON.assign(m_strTSTAMP_INITIATED,0,8);
   int lTSTAMP_RETRY_COUNT = m_lTSTAMP_RETRY_COUNT;
   ImportReportAuditSegment::instance()->setTRANSACTION_NO(m_lTRANSACTION_NO);
   m_hIMPORT_KEY.erase(m_hIMPORT_KEY.begin(),m_hIMPORT_KEY.end());
   m_hREJECT_CODES.erase(m_hREJECT_CODES.begin(),m_hREJECT_CODES.end());
   string strEmpty;
   int i = 0;
   for (i = 0;i < m_hDATA_BUFFER.size();++i)
   {
      m_hIMPORT_KEY.push_back(strEmpty);
      m_hREJECT_CODES.push_back(strEmpty);
   }
   m_siSEQ_NO = 0;
   // boolean b holds the return value of only import and not Audit.  
   // Audit failure is checked based on database transaction state.
   bool b = parse(m_hDATA_BUFFER);
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
   {
      Database::instance()->rollback();
      b = false;
   }
   m_lTSTAMP_RETRY_COUNT++;
   Transaction::instance()->setQualifier("CUSTQUAL");
   for (m_siSEQ_NO = 0;m_siSEQ_NO < m_hDATA_BUFFER.size();++m_siSEQ_NO)
   {
      reusable::Table hTable("DI_DATA");
      hTable.set("DI_FILE_ID",m_lDI_FILE_ID,true);
      hTable.set("DI_STATE",(b) ? "IC" : "IF");
      hTable.set("IMPORT_KEY",m_hIMPORT_KEY[m_siSEQ_NO]);
      hTable.set("REJECT_CODES",m_hREJECT_CODES[m_siSEQ_NO]);
      hTable.set("TRANSACTION_NO",m_lTRANSACTION_NO,true);
      hTable.set("SEQ_NO",m_siSEQ_NO + 1,true);
      hTable.set("TSTAMP_PARSED",Clock::instance()->getYYYYMMDDHHMMSSHN());
      if (b)
         hTable.set("TSTAMP_NEXT_PARSE","");
      else
      {
         string strDate(Clock::instance()->getDate());
         string strTime(Clock::instance()->getTime().substr(0,6));
         Timestamp::adjust(strDate,strTime,60);
         string strTSTAMP_NEXT_PARSE = strDate.substr(0,8);
         strTSTAMP_NEXT_PARSE += strTime;
         strTSTAMP_NEXT_PARSE += "00";
         hTable.set("TSTAMP_NEXT_PARSE",strTSTAMP_NEXT_PARSE);
      }
      hTable.set("TSTAMP_RETRY_COUNT",m_lTSTAMP_RETRY_COUNT);
      auto_ptr<reusable::Statement> pUpdateStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("UpdateStatement"));
      if (!pUpdateStatement->execute(hTable))
         return false;
   
   }
   if (m_strDX_FILE_TYPE != "DNBTCH")
      endAudit(lTSTAMP_RETRY_COUNT);
   return true;
  //## end command::ImportTransaction::execute%42482E110222.body
}

const string& ImportTransaction::getIMPORT_KEY (short int siSEQ_NO)
{
  //## begin command::ImportTransaction::getIMPORT_KEY%47208B7603C8.body preserve=yes
   return m_hIMPORT_KEY[siSEQ_NO];
  //## end command::ImportTransaction::getIMPORT_KEY%47208B7603C8.body
}

const string& ImportTransaction::getREJECT_CODES (short int siSEQ_NO)
{
  //## begin command::ImportTransaction::getREJECT_CODES%471CC399029F.body preserve=yes
   return m_hREJECT_CODES[siSEQ_NO];
  //## end command::ImportTransaction::getREJECT_CODES%471CC399029F.body
}

bool ImportTransaction::parse (const vector<string>& hDATA_BUFFER)
{
  //## begin command::ImportTransaction::parse%4242FDDC02CE.body preserve=yes
   return false;
  //## end command::ImportTransaction::parse%4242FDDC02CE.body
}

void ImportTransaction::setDetail (const char* pszDetail)
{
  //## begin command::ImportTransaction::setDetail%472347EA02FD.body preserve=yes
   m_strDetail.append(pszDetail);
  //## end command::ImportTransaction::setDetail%472347EA02FD.body
}

void ImportTransaction::setENTITY_ID ()
{
  //## begin command::ImportTransaction::setENTITY_ID%5176A0A102E0.body preserve=yes
   Extract::instance()->getSpec("CUSTOMER",m_strENTITY_ID);
  //## end command::ImportTransaction::setENTITY_ID%5176A0A102E0.body
}

void ImportTransaction::setHeading (const char* pszHeading)
{
  //## begin command::ImportTransaction::setHeading%472347D901F4.body preserve=yes
   m_strHeading.append(pszHeading);
  //## end command::ImportTransaction::setHeading%472347D901F4.body
}

void ImportTransaction::setIMPORT_KEY (const string& strIMPORT_KEY, short int siSEQ_NO)
{
  //## begin command::ImportTransaction::setIMPORT_KEY%47208B840271.body preserve=yes
   m_hIMPORT_KEY[siSEQ_NO] = strIMPORT_KEY;
  //## end command::ImportTransaction::setIMPORT_KEY%47208B840271.body
}

void ImportTransaction::setREJECT_CODES (const string& strREJECT_CODES, short int siSEQ_NO)
{
  //## begin command::ImportTransaction::setREJECT_CODES%471CC33D02DE.body preserve=yes
   m_hREJECT_CODES[siSEQ_NO] = strREJECT_CODES;
  //## end command::ImportTransaction::setREJECT_CODES%471CC33D02DE.body
}

void ImportTransaction::update (Subject* pSubject)
{
  //## begin command::ImportTransaction::update%45E49D6F00B3.body preserve=yes
  //## end command::ImportTransaction::update%45E49D6F00B3.body
}

bool ImportTransaction::writeAudit ()
{
  //## begin command::ImportTransaction::writeAudit%47210559037A.body preserve=yes
   ImportReportAuditSegment::instance()->setSEQ_NO(m_siSEQ_NO + 1);
   ImportReportAuditSegment::instance()->setIMPORT_KEY(getIMPORT_KEY(m_siSEQ_NO));
   ImportReportAuditSegment::instance()->setREJECT_CODES(getREJECT_CODES(m_siSEQ_NO));
   setENTITY_ID();
   Audit hAudit(getDX_FILE_TYPE(),"CU",m_strENTITY_ID,getDATE_RECON(),getSCHED_TIME());
   const char* pszAudit[] =
   {
      "CHELO ~Z.PROC.",
      "CMAIL FROM:<~Y.EMAIL_ADDRESS.>",
      "CRCPT TO:<~Y.EMAIL_ADDRESS.>",
      "CDATA",
      "CTO:<~Y.EMAIL_ADDRESS.>",
      "CSUBJECT:DataNavigator Import ~Z.FILE.",
      "H",
      "HDataNavigator Import ~Z.FILE.",
      "H",
      "HDate    ,~Z.DATE_RECON.",
      "HRun Time,~Z.TIMESTAMP.",
      "HFile    ,~Z.FILE. (~Z.DI_FILE_ID.)",
      "HPath    ,~Z.PATH.",
      "HReceived,~Z.TSTAMP_INITIATED.",
      "H",
      "H<heading>",
      "D<detail>",
       0
   };
   pszAudit[15] = m_strHeading.c_str();
   pszAudit[16] = m_strDetail.c_str();
   hAudit.setTemplate(&pszAudit[0]);
   hAudit.add('Z',ImportReportAuditSegment::instance());
   addSegments(hAudit);
   if (hAudit.empty())
   {
      string strValue;
      if (!Extract::instance()->getSpec("HELO",strValue))
         Extract::instance()->getSpec("PROC",strValue);
      ImportReportAuditSegment::instance()->setServer(strValue);
      ImportReportAuditSegment::instance()->setFILE(getDX_FILE_TYPE());
      ImportReportAuditSegment::instance()->setDATE_RECON(getDATE_RECON());
      ImportReportAuditSegment::instance()->setTIMESTAMP(Timestamp::format(Clock::instance()->getYYYYMMDDHHMMSS()));
      if (!hAudit.report('C'))
         return false;
      if (!hAudit.report('H'))
         return false;
   }
   return (hAudit.report('D'));
  //## end command::ImportTransaction::writeAudit%47210559037A.body
}

// Additional Declarations
  //## begin command::ImportTransaction%4242F95E03D8.declarations preserve=yes
  //## end command::ImportTransaction%4242F95E03D8.declarations
} // namespace command

//## begin module%4242F9AA0251.epilog preserve=yes
//## end module%4242F9AA0251.epilog
