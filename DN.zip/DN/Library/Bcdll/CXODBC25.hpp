//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%477522A5037A.cm preserve=no
//  $Date:   Dec 02 2016 16:57:04  $ $Author:   e1009839  $ $Revision:   1.5  $
//## end module%477522A5037A.cm

//## begin module%477522A5037A.cp preserve=no
//  Copyright (c) 1997 - 2012
//  FIS
//## end module%477522A5037A.cp

//## Module: CXOSBC25%477522A5037A; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC25.hpp

#ifndef CXOSBC25_h
#define CXOSBC25_h 1

//## begin module%477522A5037A.additionalIncludes preserve=no
//## end module%477522A5037A.additionalIncludes

//## begin module%477522A5037A.includes preserve=yes
//## end module%477522A5037A.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSBC16_h
#include "CXODBC16.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Memory;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class ExportFile;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;
} // namespace segment

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;

} // namespace usersegment

//## begin module%477522A5037A.declarations preserve=no
//## end module%477522A5037A.declarations

//## begin module%477522A5037A.additionalDeclarations preserve=yes
//## end module%477522A5037A.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::Email%477521BC0271.preface preserve=yes
//## end command::Email%477521BC0271.preface

//## Class: Email%477521BC0271
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%47752288003E;segment::Segment { -> F}
//## Uses: <unnamed>%501158C001F9;IF::Memory { -> F}
//## Uses: <unnamed>%537F3FB20192;timer::Clock { -> F}
//## Uses: <unnamed>%537F3FCB0041;IF::Extract { -> F}
//## Uses: <unnamed>%537F3FE302A9;usersegment::EmailSegment { -> F}

class DllExport Email : public reusable::Observer  //## Inherits: <unnamed>%547CE7C403D9
{
  //## begin command::Email%477521BC0271.initialDeclarations preserve=yes
  //## end command::Email%477521BC0271.initialDeclarations

  public:
    //## Constructors (generated)
      Email();

    //## Constructors (specified)
      //## Operation: Email%477524B300EA
      Email (const string& strDX_FILE_TYPE, const string& strENTITY_TYPE, const string& strENTITY_ID, const string& strDATE_RECON, const string& strSCHED_TIME);

      //## Operation: Email%501154C20280
      Email (const string& strDX_FILE_TYPE, const string& strENTITY_TYPE, const string& strENTITY_ID, const string& strDATE_RECON, const string& strSCHED_TIME, const string& strTemplate);

      //## Operation: Email%537F3E26036E
      Email (const string& strTemplate);

    //## Destructor (generated)
      virtual ~Email();


    //## Other Operations (specified)
      //## Operation: add%4775238B0232
      void add (const char cSegment, segment::Segment* pSegment);

      //## Operation: report%4775239400CB
      bool report (const char cType);

      //## Operation: report%537F3E67037A
      static bool report (const string& strText);

      //## Operation: report%537F4C61030F
      static bool report (const char cType, const string& strText1);

      //## Operation: report%537F4CD801E9
      static bool report (const char cType, const string& strText1, const string& strText2);

      //## Operation: report%537F4D88019E
      static bool report (const char cType, const string& strText1, const string& strText2, const string& strText3);

      //## Operation: report%537F4CE8034B
      static bool report (const char cType, const string& strText1, const string& strText2, const string& strText3, const string& strText4);

      //## Operation: report%537F4D0E0267
      static bool report (const char cType, const string& strText1, const string& strText2, const string& strText3, const string& strText4, const string& strText5);

      //## Operation: setTemplate%477523970138
      void setTemplate (const char** ppszTemplate);

      //## Operation: update%547CE7E202F1
      virtual void update (Subject* pSubject    // Instance of the Subject that has changed state.
      );

    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::Command_CAT::<unnamed>%477522540203
      //## Role: Email::<m_hFlatFile>%47752255007D
      IF::FlatFile& getFlatFile ()
      {
        //## begin command::Email::getFlatFile%47752255007D.get preserve=no
        return m_hFlatFile;
        //## end command::Email::getFlatFile%47752255007D.get
      }


      //## Association: Connex Library::Command_CAT::<unnamed>%4F97C0640328
      //## Role: Email::<m_pExportFile>%4F97C0660152
      database::ExportFile * getExportFile ()
      {
        //## begin command::Email::getExportFile%4F97C0660152.get preserve=no
        return m_pExportFile;
        //## end command::Email::getExportFile%4F97C0660152.get
      }


    // Additional Public Declarations
      //## begin command::Email%477521BC0271.public preserve=yes
      virtual void complete ();
      //## end command::Email%477521BC0271.public

  protected:
    // Additional Protected Declarations
      //## begin command::Email%477521BC0271.protected preserve=yes
      //## end command::Email%477521BC0271.protected

  private:
    // Additional Private Declarations
      //## begin command::Email%477521BC0271.private preserve=yes
      //## end command::Email%477521BC0271.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%537F649000EE
      //## begin command::Email::Instance%537F649000EE.attr preserve=no  private: static Email* {V} 0
      static Email* m_pInstance;
      //## end command::Email::Instance%537F649000EE.attr

      //## Attribute: Template%4775237F0177
      //## begin command::Email::Template%4775237F0177.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hTemplate;
      //## end command::Email::Template%4775237F0177.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%4775222700AB
      //## Role: Email::<m_hXMLText>%477522280000
      //## begin command::Email::<m_hXMLText>%477522280000.role preserve=no  public: command::XMLText { -> VHgN}
      XMLText m_hXMLText;
      //## end command::Email::<m_hXMLText>%477522280000.role

      //## Association: Connex Library::Command_CAT::<unnamed>%477522540203
      //## begin command::Email::<m_hFlatFile>%47752255007D.role preserve=no  public: IF::FlatFile { -> VHgN}
      IF::FlatFile m_hFlatFile;
      //## end command::Email::<m_hFlatFile>%47752255007D.role

      //## Association: Connex Library::Command_CAT::<unnamed>%4F97C0640328
      //## begin command::Email::<m_pExportFile>%4F97C0660152.role preserve=no  public: database::ExportFile { -> RFHgN}
      database::ExportFile *m_pExportFile;
      //## end command::Email::<m_pExportFile>%4F97C0660152.role

    // Additional Implementation Declarations
      //## begin command::Email%477521BC0271.implementation preserve=yes
      void read(const string& strTemplate);
      //## end command::Email%477521BC0271.implementation

};

//## begin command::Email%477521BC0271.postscript preserve=yes
//## end command::Email%477521BC0271.postscript

} // namespace command

//## begin module%477522A5037A.epilog preserve=yes
//## end module%477522A5037A.epilog


#endif
