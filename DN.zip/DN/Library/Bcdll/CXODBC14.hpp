//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%370DECB00219.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%370DECB00219.cm

//## begin module%370DECB00219.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%370DECB00219.cp

//## Module: CXOSBC14%370DECB00219; Package specification
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC14.hpp

#ifndef CXOSBC14_h
#define CXOSBC14_h 1

//## begin module%370DECB00219.additionalIncludes preserve=no
//## end module%370DECB00219.additionalIncludes

//## begin module%370DECB00219.includes preserve=yes
// $Date:   Apr 08 2004 11:17:20  $ $Author:   D02405  $ $Revision:   1.1  $
//## end module%370DECB00219.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;

} // namespace reusable

//## begin module%370DECB00219.declarations preserve=no
//## end module%370DECB00219.declarations

//## begin module%370DECB00219.additionalDeclarations preserve=yes
//## end module%370DECB00219.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::GetUserIdListCommand%370DEB8701F4.preface preserve=yes
//## end command::GetUserIdListCommand%370DEB8701F4.preface

//## Class: GetUserIdListCommand%370DEB8701F4
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%370DF3400084;reusable::Query { -> F}
//## Uses: <unnamed>%370E043002CE;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%370E0A6D0003;IF::ResourceUsage { -> F}

class DllExport GetUserIdListCommand : public reusable::Observer  //## Inherits: <unnamed>%370DEC2F0228
{
  //## begin command::GetUserIdListCommand%370DEB8701F4.initialDeclarations preserve=yes
  //## end command::GetUserIdListCommand%370DEB8701F4.initialDeclarations

  public:
    //## Constructors (generated)
      GetUserIdListCommand();

    //## Destructor (generated)
      virtual ~GetUserIdListCommand();


    //## Other Operations (specified)
      //## Operation: execute%370DEFA702E3
      bool execute (SelectStatement *pSelectStatement);

      //## Operation: update%370DEFB101CF
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin command::GetUserIdListCommand%370DEB8701F4.public preserve=yes
      //## end command::GetUserIdListCommand%370DEB8701F4.public

  protected:
    // Additional Protected Declarations
      //## begin command::GetUserIdListCommand%370DEB8701F4.protected preserve=yes
      //## end command::GetUserIdListCommand%370DEB8701F4.protected

  private:
    // Additional Private Declarations
      //## begin command::GetUserIdListCommand%370DEB8701F4.private preserve=yes
      //## end command::GetUserIdListCommand%370DEB8701F4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: m_strCUST_ID%37162EC50210
      //## begin command::GetUserIdListCommand::m_strCUST_ID%37162EC50210.attr preserve=no  private: string {U} 
      string m_strCUST_ID;
      //## end command::GetUserIdListCommand::m_strCUST_ID%37162EC50210.attr

      //## Attribute: m_strINST_ID%37162EE5032F
      //## begin command::GetUserIdListCommand::m_strINST_ID%37162EE5032F.attr preserve=no  private: string {U} 
      string m_strINST_ID;
      //## end command::GetUserIdListCommand::m_strINST_ID%37162EE5032F.attr

      //## Attribute: m_strINST_PROC_ID%3717283B0020
      //## begin command::GetUserIdListCommand::m_strINST_PROC_ID%3717283B0020.attr preserve=no  private: string {U} 
      string m_strINST_PROC_ID;
      //## end command::GetUserIdListCommand::m_strINST_PROC_ID%3717283B0020.attr

      //## Attribute: m_strPROC_GRP_ID%37162F120301
      //## begin command::GetUserIdListCommand::m_strPROC_GRP_ID%37162F120301.attr preserve=no  private: string {U} 
      string m_strPROC_GRP_ID;
      //## end command::GetUserIdListCommand::m_strPROC_GRP_ID%37162F120301.attr

      //## Attribute: m_strPROC_ID%37162EFA03A7
      //## begin command::GetUserIdListCommand::m_strPROC_ID%37162EFA03A7.attr preserve=no  private: string {U} 
      string m_strPROC_ID;
      //## end command::GetUserIdListCommand::m_strPROC_ID%37162EFA03A7.attr

      //## Attribute: m_strPROC_PROC_GRP_ID%371725250006
      //## begin command::GetUserIdListCommand::m_strPROC_PROC_GRP_ID%371725250006.attr preserve=no  private: string {U} 
      string m_strPROC_PROC_GRP_ID;
      //## end command::GetUserIdListCommand::m_strPROC_PROC_GRP_ID%371725250006.attr

      //## Attribute: m_strTIMEOUT_MINS%370DEEC90316
      //## begin command::GetUserIdListCommand::m_strTIMEOUT_MINS%370DEEC90316.attr preserve=no  private: string {U} 
      string m_strTIMEOUT_MINS;
      //## end command::GetUserIdListCommand::m_strTIMEOUT_MINS%370DEEC90316.attr

      //## Attribute: m_strUSER_ID%370DEDE5014B
      //## begin command::GetUserIdListCommand::m_strUSER_ID%370DEDE5014B.attr preserve=no  private: string {U} 
      string m_strUSER_ID;
      //## end command::GetUserIdListCommand::m_strUSER_ID%370DEDE5014B.attr

      //## Attribute: m_strUSER_NAME%370DEDF5032F
      //## begin command::GetUserIdListCommand::m_strUSER_NAME%370DEDF5032F.attr preserve=no  private: string {U} 
      string m_strUSER_NAME;
      //## end command::GetUserIdListCommand::m_strUSER_NAME%370DEDF5032F.attr

      //## Attribute: m_strUSER_PASSWORD%370DEE0E00D2
      //## begin command::GetUserIdListCommand::m_strUSER_PASSWORD%370DEE0E00D2.attr preserve=no  private: string {U} 
      string m_strUSER_PASSWORD;
      //## end command::GetUserIdListCommand::m_strUSER_PASSWORD%370DEE0E00D2.attr

    // Additional Implementation Declarations
      //## begin command::GetUserIdListCommand%370DEB8701F4.implementation preserve=yes
      //## end command::GetUserIdListCommand%370DEB8701F4.implementation

};

//## begin command::GetUserIdListCommand%370DEB8701F4.postscript preserve=yes
//## end command::GetUserIdListCommand%370DEB8701F4.postscript

} // namespace command

//## begin module%370DECB00219.epilog preserve=yes
using namespace command;
//## end module%370DECB00219.epilog


#endif
