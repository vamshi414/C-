//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%462DCEEA0133.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%462DCEEA0133.cm

//## begin module%462DCEEA0133.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%462DCEEA0133.cp

//## Module: CXOSBC23%462DCEEA0133; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\ConnexPlatform\Server\Library\Bcdll\CXOSBC23.cpp

//## begin module%462DCEEA0133.additionalIncludes preserve=no
//## end module%462DCEEA0133.additionalIncludes

//## begin module%462DCEEA0133.includes preserve=yes
#ifndef CXOSBC23_h
#include "CXODBC23.hpp"
#endif
#undef SUPPORTLDAP
#ifdef _WIN32
#define SUPPORTLDAP
#include "winber.h"
#endif
#ifdef SOLARISAMD64
#include "ldap.h"
#define SUPPORTLDAP
#endif
#ifdef _UNIX
#ifndef _AIX
#define SUPPORTLDAP
#define LDAP_DEPRECATED 1
#include "ldap.h"
#endif
#endif
//## end module%462DCEEA0133.includes

#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBC26_h
#include "CXODBC26.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSIF48_h
#include "CXODIF48.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif


//## begin module%462DCEEA0133.declarations preserve=no
//## end module%462DCEEA0133.declarations

//## begin module%462DCEEA0133.additionalDeclarations preserve=yes
#define LDAP_CON_ERROR          "SE200"  // SE200 is Account Suspended or Access Security unavailable or DB error
#define LDAP_AUTH_ERROR         "SE001"  // temporary error - will be translated prior to return
#define LDAP_INVALID_CREDENTIAL "SE119"  // password mismatch
#define LDAP_ID_REVOKED         "SE135"  // ID revoked
#define LDAP_UNKNOWN_USER       "SE114"  // unknown user
#define LDAP_AUTH_SUCCESS       ""

//## end module%462DCEEA0133.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::OpenLDAP 

//## begin command::OpenLDAP::Instance%462DD24C0129.attr preserve=no  private: static command::OpenLDAP* {V} 0
command::OpenLDAP* OpenLDAP::m_pInstance = 0;
//## end command::OpenLDAP::Instance%462DD24C0129.attr

OpenLDAP::OpenLDAP()
  //## begin OpenLDAP::OpenLDAP%462DCEB90092_const.hasinit preserve=no
  //## end OpenLDAP::OpenLDAP%462DCEB90092_const.hasinit
  //## begin OpenLDAP::OpenLDAP%462DCEB90092_const.initialization preserve=yes
  //## end OpenLDAP::OpenLDAP%462DCEB90092_const.initialization
{
  //## begin command::OpenLDAP::OpenLDAP%462DCEB90092_const.body preserve=yes
   memcpy_s(m_sID, 4, "BC23", 4);
#ifdef SUPPORTLDAP
   vector<string> hExtractValues;
   //map<string, string, less<string> >::iterator pLdap;
   Extract::instance()->getSpec("BC23", hExtractValues);
   getSpec(hExtractValues, "LDAPHN1", m_strHostName);
   m_bActive = (!m_strHostName.empty());
   if (!m_bActive)
      return;

   string strPortNumber;
   string strTempDNEntry;
   string strPWDInterval;
   getSpec(hExtractValues, "LDAPPORT", strPortNumber);
   m_iPortNumber = atoi(strPortNumber.c_str()) > 0 ? atoi(strPortNumber.c_str()) : LDAP_PORT;
   getSpec(hExtractValues, "LDAPADN1", m_strDNEntry);
   getSpec(hExtractValues, "LDAPADN2", strTempDNEntry);
   m_strDNEntry += strTempDNEntry;
   getSpec(hExtractValues, "LDAPFLAT", m_strFilterAttribute);
   getSpec(hExtractValues, "LDAPFLTR", m_strFilter);
   if (m_strFilter.empty())
      m_strFilter = "objectClass=*";
   getSpec(hExtractValues, "LDAPINTR", strPWDInterval);
   m_iPWDInterval = atoi(strPWDInterval.c_str());
   getSpec(hExtractValues, "LDAPATTR", m_strADAttribute);
   getSpec(hExtractValues, "LDAPBASE", m_strDNBase);
   getSpec(hExtractValues, "LDAPADPW", m_strLdAdminPassword);
   getSpec(hExtractValues, "LDAPSTLS", m_strStartTLSFlag);
   getSpec(hExtractValues, "LDAPSECU", m_strSecureFlag);

#ifdef _UNIX
   // backward compatible for linux custs who don't have URI in host value yet
   if (m_strHostName.find(":") == string::npos)
      if (m_iPortNumber == 636)
         m_strHostName = "ldaps://" + m_strHostName + ":" + strPortNumber;
      else
         m_strHostName = "ldap://" + m_strHostName + ":" + strPortNumber;
#endif

#else
   m_bActive = false;
#endif
  //## end command::OpenLDAP::OpenLDAP%462DCEB90092_const.body
}


OpenLDAP::~OpenLDAP()
{
  //## begin command::OpenLDAP::~OpenLDAP%462DCEB90092_dest.body preserve=yes
  //## end command::OpenLDAP::~OpenLDAP%462DCEB90092_dest.body
}



//## Other Operations (implementation)
bool OpenLDAP::closeAndGetResult (LDAP* pLDAP, const string& strMessage, const string strResult, const int iResultCode, string& strFinalResult)
{
  //## begin command::OpenLDAP::closeAndGetResult%5C8A2C160127.body preserve=yes
#ifdef SUPPORTLDAP
   if (pLDAP != 0)
   {
      Trace::put("ldap_unbind_s call initated");
      ldap_unbind_s(pLDAP);
   }

   string strLDAPErrorText = "";
   strFinalResult = strResult;
   if (strResult != LDAP_AUTH_SUCCESS)
   {
      if (iResultCode > 0)
         strLDAPErrorText = ldap_err2string(iResultCode);
      if (strResult == LDAP_AUTH_ERROR)
         if (iResultCode == 49) // invalid credentials
            strFinalResult = LDAP_INVALID_CREDENTIAL;
         else if (iResultCode == 50) // userid revoked
            strFinalResult = LDAP_ID_REVOKED;
         else
            strFinalResult = LDAP_CON_ERROR;   // general error
   }

   char szTrace[3 * PERCENTS + PERCENTD + 200];   // MJK remove p from start of varname.
   Trace::put(szTrace,
      sprintf(szTrace, "%s - result:%s rc:%d ldap:%s", strMessage.c_str(), strFinalResult.c_str(), iResultCode, strLDAPErrorText.c_str()));
   UseCase::setSuccess(strFinalResult == LDAP_AUTH_SUCCESS);
#endif
   return true;
  //## end command::OpenLDAP::closeAndGetResult%5C8A2C160127.body
}

void OpenLDAP::getSpec (vector<string>& hExtractValues, const reusable::string&  strParam, reusable::string& strValue)
{
  //## begin command::OpenLDAP::getSpec%621807DF024E.body preserve=yes
   strValue = "";
   //map<string, string, less<string> >::iterator pLdap;
   vector<string>::iterator p;
   for (p = hExtractValues.begin();p != hExtractValues.end();++p)
   {
      if ((*p).length() >= strParam.length()
         && (*p).substr(0, strParam.length()) == strParam)
      {
         // front of string matches
         if ((*p).length() == strParam.length())
            return;   // param is just keyword, no ~ or value
         else if ((*p).substr(strParam.length(), 1) == "~")
            if ((*p).length() == (strParam.length() + 1))
               return;   // param is just keyword with ~ and no value
            else
            {
               strValue = (*p).substr(strParam.length() + 1, (*p).length() - strParam.length() - 1);  // param match with value after tilde
               strValue.erase(std::find(strValue.begin(), strValue.end(), '\0'), strValue.end());   // Extract module returns strings with nulls so need to do this
               return;
            }
      }
   }
  //## end command::OpenLDAP::getSpec%621807DF024E.body
}

reusable::string OpenLDAP::getLDAPPasswordExpirationDate (const string& strAdPwdExp)
{
  //## begin command::OpenLDAP::getLDAPPasswordExpirationDate%5C7D0F1001E2.body preserve=yes
#ifdef SUPPORTLDAP
   if (m_iPWDInterval <= 0)
      return "";
   else if (strAdPwdExp.empty() || strAdPwdExp == "0")
      return "";
   else
   {
      char szTemp[30];
      Trace::put(szTemp, snprintf(szTemp, sizeof(szTemp), "pwdSet: %s", strAdPwdExp.c_str()));
      time_t rawtime = atoll(strAdPwdExp.substr(0, strAdPwdExp.length() - 7).data()) - 11644473600;
      struct tm* timeinfo;
      timeinfo = localtime(&rawtime);
      timeinfo->tm_mon++;
      timeinfo->tm_year += 1900;
      Date hDatePasswordExpires(timeinfo->tm_year, timeinfo->tm_mon, timeinfo->tm_mday);
      hDatePasswordExpires += m_iPWDInterval;
      return hDatePasswordExpires.asString("%Y%m%d").c_str();
   }
#else
   return "";
#endif
  //## end command::OpenLDAP::getLDAPPasswordExpirationDate%5C7D0F1001E2.body
}

command::OpenLDAP* OpenLDAP::instance ()
{
  //## begin command::OpenLDAP::instance%462DD1CA02DD.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new OpenLDAP();
   return m_pInstance;
  //## end command::OpenLDAP::instance%462DD1CA02DD.body
}

bool OpenLDAP::logon (const string &strUSER_ID, const string &strPassword, const string &strNewPassword, string &strResult)
{
  //## begin command::OpenLDAP::logon%462DD56F00CE.body preserve=yes
#ifdef SUPPORTLDAP
   if (!m_bActive)
      return false;
   UseCase hUseCase("CLIENT", "## CL04 LOGON LDAP RACF");
   LDAP* pLDAP = 0;
   short siFAILED_LOGON_COUNT = 0;
   char szTemp[PERCENTD + 50];

   Trace::put(m_strHostName.c_str());
   Trace::put(strUSER_ID.c_str());
   Trace::put(m_strDNEntry.c_str());
#ifdef _WIN32
   Trace::put(szTemp, snprintf(szTemp, sizeof(szTemp), "port: %d", m_iPortNumber));
   Trace::put("ldap_init function call initated ");
   if ((pLDAP = ldap_init((char*)m_strHostName.c_str(), m_iPortNumber)) == 0)
      return closeAndGetResult(pLDAP, "ldap_init failure", LDAP_CON_ERROR, 0, strResult);
#else
   Trace::put("ldap_initialize function call initated ");
   if (int iRc = ldap_initialize(&pLDAP, (char*)m_strHostName.c_str()) != LDAP_SUCCESS)
      return closeAndGetResult(pLDAP, "ldap_initialize failure", LDAP_CON_ERROR, iRc, strResult);
#endif

   int iVersion = LDAP_VERSION3;
   if (int iRc = ldap_set_option(pLDAP, LDAP_OPT_PROTOCOL_VERSION, &iVersion) != LDAP_SUCCESS)
      return closeAndGetResult(pLDAP, "ldap_set_option() - version failure", LDAP_CON_ERROR, iRc, strResult);

   if (int iRc = ldap_set_option(pLDAP, LDAP_OPT_REFERRALS, 0) != LDAP_SUCCESS)
      return closeAndGetResult(pLDAP, "ldap_set_option() - version failure", LDAP_CON_ERROR, iRc, strResult);

#ifdef _WIN32
   if (m_strSecureFlag == "Y" || m_iPortNumber == 636)
   if (int iRc = ldap_set_option(pLDAP, LDAP_OPT_SSL, LDAP_OPT_ON) != LDAP_SUCCESS)
      return closeAndGetResult(pLDAP, "ldap_set_option() - set SSL failure", LDAP_CON_ERROR, iRc, strResult);
#endif

   if (m_strStartTLSFlag == "Y")
   {
      Trace::put("ldap_start_tls_s TLS encryption function call initated ");
   #ifdef _WIN32
      if (int iRc = ldap_start_tls_s(pLDAP, 0, 0, 0, 0) != LDAP_SUCCESS)
   #else
      if (int iRc = ldap_start_tls_s(pLDAP, 0, 0) != LDAP_SUCCESS)
   #endif
         return closeAndGetResult(pLDAP, "ldap_start_tls_s TLS encryption function call failure", LDAP_CON_ERROR, iRc, strResult);
   }
 
   Trace::put("ldap_simple_bind_s admin authentication call initated");
   string strLdAdminPassword = m_strLdAdminPassword;
   AdvancedEncryptionStandard::decrypt(strLdAdminPassword);
   if (int iRc = ldap_simple_bind_s(pLDAP, (char*)m_strDNEntry.c_str(), (char*)strLdAdminPassword.c_str()) != LDAP_SUCCESS)
   {
      strLdAdminPassword.clear();    // clear in memory password in the clear
      return closeAndGetResult(pLDAP, "ldap_simple_bind_s admin authentication failure", LDAP_CON_ERROR, iRc, strResult);
   }

   strLdAdminPassword.clear();    // clear in memory password in the clear
   m_strDatePasswordExpires.erase();
   char szPasswordChangeDate[32];
   LDAPMessage* pLDAPResult = 0;
   LDAPMessage* pLDAPEntry = 0;
   BerElement* pLDAPBer = 0;
   char* pszAttribute = 0;   // MJK should name be pszAttribute?  Otherwise looks like a pointer to an Attribute class.
   char** ppszLDAPvals;
   string strDNEntry;
   string strFilterTemp;
   
   memset(szPasswordChangeDate, 0, sizeof(szPasswordChangeDate));   
   strFilterTemp = "(&(" + m_strFilter + ")(" + m_strFilterAttribute + "=" + strUSER_ID + "))";

   Trace::put("ldap_search_ext_s call initated");
   if (int iRc = ldap_search_ext_s(pLDAP, (char*)m_strDNBase.c_str(), LDAP_SCOPE_SUBTREE, (char*)strFilterTemp.c_str(), 0, 0, 0, 0, LDAP_NO_LIMIT, LDAP_NO_LIMIT, &pLDAPResult) != LDAP_SUCCESS)
      return closeAndGetResult(pLDAP, "ldap_search_ext_s failure", LDAP_CON_ERROR, iRc, strResult);
  
   pLDAPEntry = ldap_first_entry(pLDAP, pLDAPResult);
   if (pLDAPEntry == 0)
      return closeAndGetResult(pLDAP, "ldap_search_ext_s failure - LDAPentry not found", LDAP_UNKNOWN_USER, -1, strResult);

   strDNEntry = ldap_get_dn(pLDAP, pLDAPEntry);
   if (strDNEntry.empty())
   {
      ldap_msgfree(pLDAPResult);
      return closeAndGetResult(pLDAP, "ldap_get_dn failure", LDAP_UNKNOWN_USER, -2, strResult);
   }

   for (pszAttribute = ldap_first_attribute(pLDAP, pLDAPEntry, &pLDAPBer); pszAttribute != 0; pszAttribute = ldap_next_attribute(pLDAP, pLDAPEntry, pLDAPBer))
   {
      if ((ppszLDAPvals = ldap_get_values(pLDAP, pLDAPEntry, pszAttribute)) != 0)
      {
         for (int i = 0; ppszLDAPvals[i] != 0; i++)
         {
            size_t iLen = strlen(ppszLDAPvals[i]);
            if (strcmp(pszAttribute, m_strADAttribute.c_str()) == 0)
               memcpy_s(szPasswordChangeDate,sizeof(szPasswordChangeDate), ppszLDAPvals[i], iLen);
         }
         ldap_value_free(ppszLDAPvals);
      }
      ldap_memfree(pszAttribute);
   }
   ber_free(pLDAPBer, 0);   
   ldap_msgfree(pLDAPResult);

   Trace::put(strDNEntry.c_str());
   Trace::put("ldap_simple_bind_s authentication call initated");
   int iRc = ldap_simple_bind_s(pLDAP, (char*)strDNEntry.c_str(), (char*)strPassword.c_str());
   if (iRc == 0)
   {
      m_strDatePasswordExpires = getLDAPPasswordExpirationDate((string)szPasswordChangeDate);
      return closeAndGetResult(pLDAP, "ldap_simple_bind_s successful", LDAP_AUTH_SUCCESS, 0, strResult);
   }
   else
   {
      // auth failed
      if (iRc == 49)   // update DB only on invalid password
      {
         reusable::Query hQuery;
         auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
         hQuery.setQualifier("QUALIFY", "AS_USER_LOGON");
         hQuery.bind("AS_USER_LOGON", "FAILED_LOGON_COUNT", Column::SHORT, &siFAILED_LOGON_COUNT);
         hQuery.setBasicPredicate("AS_USER_LOGON", "USER_ID", "=", strUSER_ID.c_str());
         if (!pSelectStatement->execute(hQuery))
            Database::instance()->rollback();
         siFAILED_LOGON_COUNT += 1;
         reusable::Table hTable("AS_USER_LOGON");
         hTable.setQualifier("QUALIFY");
         hTable.set("USER_ID", strUSER_ID.c_str(), false, true);
         hTable.set("FAILED_LOGON_COUNT", siFAILED_LOGON_COUNT);
         auto_ptr<reusable::Statement> pUpdateStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("UpdateStatement"));
         if (!pUpdateStatement->execute(hTable))
            Trace::put("AS_USER_LOGON update for failed logon count failed");
      }
      return closeAndGetResult(pLDAP, "ldap_simple_bind_s failure", LDAP_AUTH_ERROR, iRc, strResult);
   }
    
#else
   return false;
#endif
  //## end command::OpenLDAP::logon%462DD56F00CE.body
}

// Additional Declarations
  //## begin command::OpenLDAP%462DCEB90092.declarations preserve=yes
  //## end command::OpenLDAP%462DCEB90092.declarations

} // namespace command

//## begin module%462DCEEA0133.epilog preserve=yes
//## end module%462DCEEA0133.epilog
