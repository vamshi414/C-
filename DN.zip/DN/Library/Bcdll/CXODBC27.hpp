//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%48BEBDBA03C7.cm preserve=no
//	$Date:   Jul 19 2018 10:49:56  $ $Author:   e1009652  $ $Revision:   1.5.1.0  $
//## end module%48BEBDBA03C7.cm

//## begin module%48BEBDBA03C7.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%48BEBDBA03C7.cp

//## Module: CXOSBC27%48BEBDBA03C7; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.8A.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC27.hpp

#ifndef CXOSBC27_h
#define CXOSBC27_h 1

//## begin module%48BEBDBA03C7.additionalIncludes preserve=no
//## end module%48BEBDBA03C7.additionalIncludes

//## begin module%48BEBDBA03C7.includes preserve=yes
//## end module%48BEBDBA03C7.includes

#ifndef CXOSBC26_h
#include "CXODBC26.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
class FormatSelectVisitor;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class PersistentSegment;
class CommonHeaderSegment;

} // namespace segment

//## begin module%48BEBDBA03C7.declarations preserve=no
//## end module%48BEBDBA03C7.declarations

//## begin module%48BEBDBA03C7.additionalDeclarations preserve=yes
//## end module%48BEBDBA03C7.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::DNSecurity%48BEBD7F0259.preface preserve=yes
//## end command::DNSecurity%48BEBD7F0259.preface

//## Class: DNSecurity%48BEBD7F0259
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%48C0343902B6;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%48C0343B02D7;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%48C034470157;reusable::Table { -> F}
//## Uses: <unnamed>%48C034520262;reusable::Statement { -> F}
//## Uses: <unnamed>%48C0345D009B;database::Database { -> F}
//## Uses: <unnamed>%4EF25608031B;IF::Extract { -> F}
//## Uses: <unnamed>%48C0344001CF;reusable::Query { -> F}
//## Uses: <unnamed>%5602BB020333;segment::PersistentSegment { -> F}
//## Uses: <unnamed>%5602BBDB035F;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%5602BBEE009D;reusable::FormatSelectVisitor { -> F}

class DllExport DNSecurity : public Security  //## Inherits: <unnamed>%48BEBD88009A
{
  //## begin command::DNSecurity%48BEBD7F0259.initialDeclarations preserve=yes
  //## end command::DNSecurity%48BEBD7F0259.initialDeclarations

  public:
    //## Constructors (generated)
      DNSecurity();

    //## Destructor (generated)
      virtual ~DNSecurity();


    //## Other Operations (specified)
      //## Operation: authenticateUser%48BED16400A4
      virtual int authenticateUser (const string& strUserid, const string& strPassword);

      //## Operation: checkUsers%48EB794B03CF
      void checkUsers ();

      //## Operation: getUserRole%5602BB210280
      virtual char getUserRole (segment::PersistentSegment* pSegment);

      //## Operation: hasWidgetId%4EE6798501CD
      virtual bool hasWidgetId (const string& strUserid, const string& strWidgetId);

      //## Operation: initializePasswordHistory%5B4F7BB203C0
      int initializePasswordHistory (const string& strUserid);

      //## Operation: instance%490B6921039A
      static command::Security* instance ();

      //## Operation: update%48BEC81B03B3
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin command::DNSecurity%48BEBD7F0259.public preserve=yes
      //## end command::DNSecurity%48BEBD7F0259.public

  protected:

    //## Other Operations (specified)
      //## Operation: validatePassword%48BED164009A
      virtual int validatePassword (const string& strUserid, const string& strPassword);

      //## Operation: validatePwdComplexity%48BED16400AA
      virtual int validatePwdComplexity (const string& strNewPassword);

    // Additional Protected Declarations
      //## begin command::DNSecurity%48BEBD7F0259.protected preserve=yes
      //## end command::DNSecurity%48BEBD7F0259.protected

  private:

    //## Other Operations (specified)
      //## Operation: convertUser%48C037B1006E
      int convertUser (const string& strUserid, const string& strPassword);

    // Additional Private Declarations
      //## begin command::DNSecurity%48BEBD7F0259.private preserve=yes
      //## end command::DNSecurity%48BEBD7F0259.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: USER_ID%48EB7AD6026E
      //## begin command::DNSecurity::USER_ID%48EB7AD6026E.attr preserve=no  private: string {U} 
      string m_strUSER_ID;
      //## end command::DNSecurity::USER_ID%48EB7AD6026E.attr

      //## Attribute: USER_PASSWORD%48EB7AF402A4
      //## begin command::DNSecurity::USER_PASSWORD%48EB7AF402A4.attr preserve=no  private: string {U} 
      string m_strUSER_PASSWORD;
      //## end command::DNSecurity::USER_PASSWORD%48EB7AF402A4.attr

    // Additional Implementation Declarations
      //## begin command::DNSecurity%48BEBD7F0259.implementation preserve=yes
      //## end command::DNSecurity%48BEBD7F0259.implementation

};

//## begin command::DNSecurity%48BEBD7F0259.postscript preserve=yes
//## end command::DNSecurity%48BEBD7F0259.postscript

} // namespace command

//## begin module%48BEBDBA03C7.epilog preserve=yes
//## end module%48BEBDBA03C7.epilog


#endif
