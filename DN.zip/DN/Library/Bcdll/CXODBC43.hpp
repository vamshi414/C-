//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52FB8D950220.cm preserve=no
//	$Date:   Feb 14 2014 16:29:56  $ $Author:   e1009839  $ $Revision:   1.0  $
//## end module%52FB8D950220.cm

//## begin module%52FB8D950220.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52FB8D950220.cp

//## Module: CXOSBC43%52FB8D950220; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.4B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC43.hpp

#ifndef CXOSBC43_h
#define CXOSBC43_h 1

//## begin module%52FB8D950220.additionalIncludes preserve=no
//## end module%52FB8D950220.additionalIncludes

//## begin module%52FB8D950220.includes preserve=yes
//## end module%52FB8D950220.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class GenericSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Constraint;

} // namespace command

//## begin module%52FB8D950220.declarations preserve=no
//## end module%52FB8D950220.declarations

//## begin module%52FB8D950220.additionalDeclarations preserve=yes
//## end module%52FB8D950220.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::Tag%52FB82C000F1.preface preserve=yes
//## end command::Tag%52FB82C000F1.preface

//## Class: Tag%52FB82C000F1
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%52FB843602C9;segment::GenericSegment { -> F}

class DllExport Tag : public reusable::Object  //## Inherits: <unnamed>%52FB82CD0284
{
  //## begin command::Tag%52FB82C000F1.initialDeclarations preserve=yes
  //## end command::Tag%52FB82C000F1.initialDeclarations

  public:
    //## Constructors (generated)
      Tag();

      Tag(const Tag &right);

    //## Constructors (specified)
      //## Operation: Tag%52FB8BE3007C
      Tag (const string& strName, int iOffset, int iLength, Constraint* pConstraint);

    //## Destructor (generated)
      virtual ~Tag();

    //## Assignment Operation (generated)
      Tag & operator=(const Tag &right);


    //## Other Operations (specified)
      //## Operation: _field%52FB83F6019A
      virtual bool _field (const segment::GenericSegment& hGenericSegment, string& strValue) const;

    // Additional Public Declarations
      //## begin command::Tag%52FB82C000F1.public preserve=yes
      //## end command::Tag%52FB82C000F1.public

  protected:
    // Additional Protected Declarations
      //## begin command::Tag%52FB82C000F1.protected preserve=yes
      //## end command::Tag%52FB82C000F1.protected

  private:
    // Additional Private Declarations
      //## begin command::Tag%52FB82C000F1.private preserve=yes
      //## end command::Tag%52FB82C000F1.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Length%52FB8375029A
      //## begin command::Tag::Length%52FB8375029A.attr preserve=no  private: int {V} 0
      int m_iLength;
      //## end command::Tag::Length%52FB8375029A.attr

      //## Attribute: Name%52FB83670078
      //## begin command::Tag::Name%52FB83670078.attr preserve=no  private: string {V} 
      string m_strName;
      //## end command::Tag::Name%52FB83670078.attr

      //## Attribute: Offset%52FB836E0080
      //## begin command::Tag::Offset%52FB836E0080.attr preserve=no  private: int {V} 0
      int m_iOffset;
      //## end command::Tag::Offset%52FB836E0080.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%52FB8C7900F2
      //## Role: Tag::<m_pConstraint>%52FB8C7903CD
      //## begin command::Tag::<m_pConstraint>%52FB8C7903CD.role preserve=no  public: command::Constraint { -> RFHgN}
      Constraint *m_pConstraint;
      //## end command::Tag::<m_pConstraint>%52FB8C7903CD.role

    // Additional Implementation Declarations
      //## begin command::Tag%52FB82C000F1.implementation preserve=yes
      //## end command::Tag%52FB82C000F1.implementation

};

//## begin command::Tag%52FB82C000F1.postscript preserve=yes
//## end command::Tag%52FB82C000F1.postscript

} // namespace command

//## begin module%52FB8D950220.epilog preserve=yes
//## end module%52FB8D950220.epilog


#endif
