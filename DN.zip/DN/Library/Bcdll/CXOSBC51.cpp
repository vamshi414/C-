//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5888C56A002E.cm preserve=no
//## end module%5888C56A002E.cm

//## begin module%5888C56A002E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5888C56A002E.cp

//## Module: CXOSBC51%5888C56A002E; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC51.cpp

//## begin module%5888C56A002E.additionalIncludes preserve=no
//## end module%5888C56A002E.additionalIncludes

//## begin module%5888C56A002E.includes preserve=yes
#include "CXODBS09.hpp"
#define PRIMARY_KEY_DUPLICATE           1
//## end module%5888C56A002E.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSBC51_h
#include "CXODBC51.hpp"
#endif


//## begin module%5888C56A002E.declarations preserve=no
//## end module%5888C56A002E.declarations

//## begin module%5888C56A002E.additionalDeclarations preserve=yes
//## end module%5888C56A002E.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::APIExport 

//## begin command::APIExport::Instance%5888C64A0274.attr preserve=no  private: static command::APIExport* {V} 0
command::APIExport* APIExport::m_pInstance = 0;
//## end command::APIExport::Instance%5888C64A0274.attr

//## begin command::APIExport::QUEUE_ID%5888DC6402F2.attr preserve=no  public: static int {U} 0
int APIExport::m_lQUEUE_ID = 0;
//## end command::APIExport::QUEUE_ID%5888DC6402F2.attr

APIExport::APIExport()
  //## begin APIExport::APIExport%5888C4F40151_const.hasinit preserve=no
  //## end APIExport::APIExport%5888C4F40151_const.hasinit
  //## begin APIExport::APIExport%5888C4F40151_const.initialization preserve=yes
  //## end APIExport::APIExport%5888C4F40151_const.initialization
{
  //## begin command::APIExport::APIExport%5888C4F40151_const.body preserve=yes
   m_pInstance = this;
  //## end command::APIExport::APIExport%5888C4F40151_const.body
}


APIExport::~APIExport()
{
  //## begin command::APIExport::~APIExport%5888C4F40151_dest.body preserve=yes
   m_pInstance = 0;
  //## end command::APIExport::~APIExport%5888C4F40151_dest.body
}



//## Other Operations (implementation)
int APIExport::insert (string& strREQ_TYPE, const string& strXMLRequest, const bool& bExportDocs)
{
  //## begin command::APIExport::insert%5888C79103C9.body preserve=yes
   short iNull = 0;
   Query hQuery;
   Table hTable;
   hQuery.bind("API_QUEUE_CONTROL", "QUEUE_ID", Column::LONG, &m_lQUEUE_ID, &iNull, "MAX");
   if (1) 
   {
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
         return STS_DATABASE_FAILURE;
   }
   m_pXMLDocument->write("");
   int iLoopCount = 0;
   auto_ptr<reusable::Statement> pInsertStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("InsertStatement"));
   while (iLoopCount < 1024)
   {
      short siRETRY_COUNT = -1;
      Table hTable("API_QUEUE_CONTROL");
      hTable.set("QUEUE_ID", ++m_lQUEUE_ID);
      hTable.set("TSTAMP_EVENT", Transaction::instance()->getTimeStamp());
      hTable.set("TSTAMP_CREATED", Transaction::instance()->getTimeStamp());
      hTable.set("API_STATE", "AW");
      hTable.set("API_TYPE", m_strAPI_TYPE);
      hTable.set("CASE_ID", m_lCASE_ID);
      hTable.set("REQ_TYPE", strREQ_TYPE);
      hTable.set("RETRY_COUNT", siRETRY_COUNT);
      hTable.set("API_RESULT", "");
      if (pInsertStatement->execute(hTable))
      {
         short siSEQ_NO = 0;
         hTable.reset();
         hTable.setName("API_QUEUE_REQUEST");
         hTable.set("QUEUE_ID", m_lQUEUE_ID, true);
         string strDATA_BUFFER;
         int m = m_strXMLTags.length();
         while (m > 0)
         {
            if (m > 3500)
               strDATA_BUFFER = m_strXMLTags.substr(0, 3500);
            else
               strDATA_BUFFER = m_strXMLTags;
            hTable.set("SEQ_NO", siSEQ_NO, true);
            hTable.set("DATA_BUFFER", strDATA_BUFFER);
            if (!pInsertStatement->execute(hTable))
               return STS_DATABASE_FAILURE;
            siSEQ_NO++;
            if (m > 3500)
               m_strXMLTags.erase(0, 3500);
            m -= 3500;
         }
         m_strXMLTags.erase();
         return 0;
      }
      if (pInsertStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
         break;
      if (pInsertStatement->getErrorType() != PRIMARY_KEY_DUPLICATE)
         break;
      
      ++iLoopCount;
   }
   m_lQUEUE_ID = -1;
   m_strXMLTags.erase();
   return pInsertStatement->getInfoIDNumber();
  //## end command::APIExport::insert%5888C79103C9.body
}

APIExport* APIExport::instance ()
{
  //## begin command::APIExport::instance%588B329B0202.body preserve=yes
   return m_pInstance;
  //## end command::APIExport::instance%588B329B0202.body
}

void APIExport::update (Subject* pSubject)
{
  //## begin command::APIExport::update%5888C67F03B4.body preserve=yes
   m_strXMLTags += m_hRow.getBuffer();
  //## end command::APIExport::update%5888C67F03B4.body
}

//## Get and Set Operations for Class Attributes (implementation)

const int& APIExport::getQUEUE_ID ()
{
  //## begin command::APIExport::getQUEUE_ID%5888DC6402F2.get preserve=no
  return m_lQUEUE_ID;
  //## end command::APIExport::getQUEUE_ID%5888DC6402F2.get
}

// Additional Declarations
  //## begin command::APIExport%5888C4F40151.declarations preserve=yes
  //## end command::APIExport%5888C4F40151.declarations

} // namespace command

//## begin module%5888C56A002E.epilog preserve=yes
//## end module%5888C56A002E.epilog
