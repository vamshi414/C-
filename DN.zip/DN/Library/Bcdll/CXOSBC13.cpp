//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%370A61C8030C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%370A61C8030C.cm

//## begin module%370A61C8030C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%370A61C8030C.cp

//## Module: CXOSBC13%370A61C8030C; Package body
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC13.cpp

//## begin module%370A61C8030C.additionalIncludes preserve=no
//## end module%370A61C8030C.additionalIncludes

//## begin module%370A61C8030C.includes preserve=yes
// $Date:   18 Jan 2018 13:53:00  $ $Author:   e1009839  $ $Revision:   1.5  $
#include "CXODRU24.hpp"
#define STS_MISSING_GETCUSTOMIZATIONSTATUS_SEGMENT 41
//## end module%370A61C8030C.includes

#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSUS07_h
#include "CXODUS07.hpp"
#endif
#ifndef CXOSUS08_h
#include "CXODUS08.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSUS10_h
#include "CXODUS10.hpp"
#endif
#ifndef CXOSBC13_h
#include "CXODBC13.hpp"
#endif


//## begin module%370A61C8030C.declarations preserve=no
//## end module%370A61C8030C.declarations

//## begin module%370A61C8030C.additionalDeclarations preserve=yes
//## end module%370A61C8030C.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::GetCustomizationStatusCommand 

GetCustomizationStatusCommand::GetCustomizationStatusCommand()
  //## begin GetCustomizationStatusCommand::GetCustomizationStatusCommand%370A604F0382_const.hasinit preserve=no
      : m_pGetCustomizationStatusSegment(0)
  //## end GetCustomizationStatusCommand::GetCustomizationStatusCommand%370A604F0382_const.hasinit
  //## begin GetCustomizationStatusCommand::GetCustomizationStatusCommand%370A604F0382_const.initialization preserve=yes
   ,ClientCommand("S0005D","@##GCUSTAT")
  //## end GetCustomizationStatusCommand::GetCustomizationStatusCommand%370A604F0382_const.initialization
{
  //## begin command::GetCustomizationStatusCommand::GetCustomizationStatusCommand%370A604F0382_const.body preserve=yes
   memcpy(m_sID,"UC05",4);
   m_pGetCustomizationStatusSegment = new GetCustomizationStatusSegment();
   m_hSegments.push_back(m_pGetCustomizationStatusSegment);
  //## end command::GetCustomizationStatusCommand::GetCustomizationStatusCommand%370A604F0382_const.body
}

GetCustomizationStatusCommand::GetCustomizationStatusCommand (Handler* pSuccessor)
  //## begin command::GetCustomizationStatusCommand::GetCustomizationStatusCommand%3E96B393036B.hasinit preserve=no
      : m_pGetCustomizationStatusSegment(0)
  //## end command::GetCustomizationStatusCommand::GetCustomizationStatusCommand%3E96B393036B.hasinit
  //## begin command::GetCustomizationStatusCommand::GetCustomizationStatusCommand%3E96B393036B.initialization preserve=yes
   ,ClientCommand("S0005D","@GCUSTAT")
  //## end command::GetCustomizationStatusCommand::GetCustomizationStatusCommand%3E96B393036B.initialization
{
  //## begin command::GetCustomizationStatusCommand::GetCustomizationStatusCommand%3E96B393036B.body preserve=yes
   memcpy(m_sID,"UC05",4);
   m_pSuccessor = pSuccessor;
   m_pGetCustomizationStatusSegment = new GetCustomizationStatusSegment();
   m_hSegments.push_back(m_pGetCustomizationStatusSegment);
  //## end command::GetCustomizationStatusCommand::GetCustomizationStatusCommand%3E96B393036B.body
}


GetCustomizationStatusCommand::~GetCustomizationStatusCommand()
{
  //## begin command::GetCustomizationStatusCommand::~GetCustomizationStatusCommand%370A604F0382_dest.body preserve=yes
   delete m_pGetCustomizationStatusSegment;
  //## end command::GetCustomizationStatusCommand::~GetCustomizationStatusCommand%370A604F0382_dest.body
}



//## Other Operations (implementation)
bool GetCustomizationStatusCommand::execute ()
{
  //## begin command::GetCustomizationStatusCommand::execute%370A635F02AD.body preserve=yes
   // CL20: Client_Requests_Customization_Status_From_DB
   UseCase hUseCase("CLIENT","## CL20 GET CUSTOM STATUS");
   int iRC;
   if ((iRC = Command::parse()) != 0)
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,iRC);
      UseCase::setSuccess(false);
      return false;
   }
   if (!CommonHeaderSegment::instance()->presence())
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_COMMON_HEADER_SEGMENT);
      UseCase::setSuccess(false);
      return false;
   }
   if (!m_pGetCustomizationStatusSegment->presence())
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_GETCUSTOMIZATIONSTATUS_SEGMENT);
      UseCase::setSuccess(false);
      return false;
   }

   Message::instance(Message::INBOUND)->reset("CRQCI ","S0005R");
   m_pDataBuffer = Message::instance(Message::INBOUND)->data() + 8;
   CommonHeaderSegment::instance()->deport(&m_pDataBuffer);

   Query hQuery;
   hQuery.setQualifier("QUALIFY","CLIENT_CUSTOM_DATA");
   int lCount = 0;
   short iNull;
   hQuery.bind("CLIENT_CUSTOM_DATA","*",Column::LONG,&lCount,&iNull,"COUNT");
   hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA","CUSTOMIZE_NODE","=",m_pGetCustomizationStatusSegment->getUserID().c_str());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   pSelectStatement->execute(hQuery);
   if (lCount != 0)
   {
      char* pList = m_pDataBuffer;
      ListSegment hListSegment;
      hListSegment.deport(&m_pDataBuffer);
      CustomizationSecuritySegment hCustomizationSecuritySegment;
      hCustomizationSecuritySegment.setCustomizeNode(m_pGetCustomizationStatusSegment->getUserID());
      hCustomizationSecuritySegment.deport(&m_pDataBuffer);
      hListSegment.update(pList,1,(int)(m_pDataBuffer - pList));

      pList = m_pDataBuffer;
      hListSegment.deport(&m_pDataBuffer);
      CustomizationStatusSegment hCustomizationStatusSegment;
      hCustomizationStatusSegment.setCustomizeNode(m_pGetCustomizationStatusSegment->getUserID());
      IString strCurrentDateTime;
      DateTime hDateTime;
      hDateTime.setCurrent(strCurrentDateTime);
      hCustomizationStatusSegment.setTimestampUpdated((char*)strCurrentDateTime);
      hCustomizationStatusSegment.deport(&m_pDataBuffer);
      hListSegment.update(pList,1,(int)(m_pDataBuffer-pList));
   }
   
   getResponseTimeSegment()->deport(&m_pDataBuffer);
   reply();
   return (lCount == 0);
  //## end command::GetCustomizationStatusCommand::execute%370A635F02AD.body
}

// Additional Declarations
  //## begin command::GetCustomizationStatusCommand%370A604F0382.declarations preserve=yes
  //## end command::GetCustomizationStatusCommand%370A604F0382.declarations

} // namespace command

//## begin module%370A61C8030C.epilog preserve=yes
//## end module%370A61C8030C.epilog
