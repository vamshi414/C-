//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3729EC2D0338.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3729EC2D0338.cm

//## begin module%3729EC2D0338.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3729EC2D0338.cp

//## Module: CXOSBC03%3729EC2D0338; Package body
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Pvcswork\Dn\Server\Library\Bcdll\CXOSBC03.cpp

//## begin module%3729EC2D0338.additionalIncludes preserve=no
//## end module%3729EC2D0338.additionalIncludes

//## begin module%3729EC2D0338.includes preserve=yes
// $Date:   Feb 26 2018 14:38:08  $ $Author:   e1009839  $ $Revision:   1.6  $
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#include "CXODIF12.hpp"
//## end module%3729EC2D0338.includes

#ifndef CXOSBC03_h
#include "CXODBC03.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif


//## begin module%3729EC2D0338.declarations preserve=no
//## end module%3729EC2D0338.declarations

//## begin module%3729EC2D0338.additionalDeclarations preserve=yes
//## end module%3729EC2D0338.additionalDeclarations


//## Modelname: Connex Foundation::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::DynamicSQLCommand




DynamicSQLCommand::DynamicSQLCommand()
  //## begin DynamicSQLCommand::DynamicSQLCommand%3729CAD90145_const.hasinit preserve=no
  //## end DynamicSQLCommand::DynamicSQLCommand%3729CAD90145_const.hasinit
  //## begin DynamicSQLCommand::DynamicSQLCommand%3729CAD90145_const.initialization preserve=yes
  //## end DynamicSQLCommand::DynamicSQLCommand%3729CAD90145_const.initialization
{
  //## begin command::DynamicSQLCommand::DynamicSQLCommand%3729CAD90145_const.body preserve=yes
   memcpy(m_sID,"BC03",4);
  //## end command::DynamicSQLCommand::DynamicSQLCommand%3729CAD90145_const.body
}


DynamicSQLCommand::~DynamicSQLCommand()
{
  //## begin command::DynamicSQLCommand::~DynamicSQLCommand%3729CAD90145_dest.body preserve=yes
  //## end command::DynamicSQLCommand::~DynamicSQLCommand%3729CAD90145_dest.body
}



//## Other Operations (implementation)
bool DynamicSQLCommand::execute ()
{
  //## begin command::DynamicSQLCommand::execute%3729CB2103B5.body preserve=yes
   UseCase hUseCase("CLIENT","## CL40 GET DB DIALOG RESULT");
   string strSQL(Message::instance(Message::INBOUND)->data(),Message::instance(Message::INBOUND)->dataLength());
   size_t pos;
   while ((pos = strSQL.find('"')) != string::npos)
      strSQL.replace(pos,1,"\'");
   string strBuffer;
   Extract::instance()->getSpec("CUSTQUAL",strBuffer);
   while ((pos = strSQL.find("&CUSTQUAL.")) != string::npos)
      strSQL.replace(pos,10,strBuffer);
   Extract::instance()->getSpec("QUALIFY",strBuffer);
   while ((pos = strSQL.find("&QUALIFY.")) != string::npos)
      strSQL.replace(pos,9,strBuffer);
   m_pSelectStatement = (SelectStatement*)DatabaseFactory::instance()->create("SelectStatement","## DYNAMIC SQL");
   m_pSelectStatement->execute(strSQL,this);
   m_hResultSet.close();
   delete m_pSelectStatement;
   return true;
  //## end command::DynamicSQLCommand::execute%3729CB2103B5.body
}

void DynamicSQLCommand::update (Subject* pSubject)
{
  //## begin command::DynamicSQLCommand::update%3729CB5B01B0.body preserve=yes
   if (m_pSelectStatement->getRows() < 10000)
      m_hResultSet.addRow(m_pSelectStatement->getDescription(),m_pSelectStatement->getRow());
   UseCase::addItem();
  //## end command::DynamicSQLCommand::update%3729CB5B01B0.body
}

// Additional Declarations
  //## begin command::DynamicSQLCommand%3729CAD90145.declarations preserve=yes
  //## end command::DynamicSQLCommand%3729CAD90145.declarations

} // namespace command

//## begin module%3729EC2D0338.epilog preserve=yes
//## end module%3729EC2D0338.epilog
