//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5F5FC49C016E.cm preserve=no
//	$Date:   Oct 13 2020 05:18:12  $ $Author:   e3023547  $
//	$Revision:   1.0  $
//## end module%5F5FC49C016E.cm

//## begin module%5F5FC49C016E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5F5FC49C016E.cp

//## Module: CXOSBC61%5F5FC49C016E; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: D:\Devel\V03.1A.R007\ConnexPlatform\Server\Library\Bcdll\CXOSBC61.cpp

//## begin module%5F5FC49C016E.additionalIncludes preserve=no
//## end module%5F5FC49C016E.additionalIncludes

//## begin module%5F5FC49C016E.includes preserve=yes
#ifdef _WIN32
#include "windows.h"
#include "xercesc\sax\AttributeList.hpp"
#else
#include "xercesc/sax/AttributeList.hpp"
#endif
//## end module%5F5FC49C016E.includes

#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSBC62_h
#include "CXODBC62.hpp"
#endif
#ifndef CXOSBC61_h
#include "CXODBC61.hpp"
#endif


//## begin module%5F5FC49C016E.declarations preserve=no
//## end module%5F5FC49C016E.declarations

//## begin module%5F5FC49C016E.additionalDeclarations preserve=yes
//## end module%5F5FC49C016E.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::GenericRuleXMLHandler 

GenericRuleXMLHandler::GenericRuleXMLHandler()
  //## begin GenericRuleXMLHandler::GenericRuleXMLHandler%5F5FC094023A_const.hasinit preserve=no
      : m_pGenericRule(0)
  //## end GenericRuleXMLHandler::GenericRuleXMLHandler%5F5FC094023A_const.hasinit
  //## begin GenericRuleXMLHandler::GenericRuleXMLHandler%5F5FC094023A_const.initialization preserve=yes
  //## end GenericRuleXMLHandler::GenericRuleXMLHandler%5F5FC094023A_const.initialization
{
  //## begin command::GenericRuleXMLHandler::GenericRuleXMLHandler%5F5FC094023A_const.body preserve=yes
  //## end command::GenericRuleXMLHandler::GenericRuleXMLHandler%5F5FC094023A_const.body
}

GenericRuleXMLHandler::GenericRuleXMLHandler (XMLItem* pXMLItem)
  //## begin command::GenericRuleXMLHandler::GenericRuleXMLHandler%5F5FCEE30382.hasinit preserve=no
      : m_pGenericRule(0)
  //## end command::GenericRuleXMLHandler::GenericRuleXMLHandler%5F5FCEE30382.hasinit
  //## begin command::GenericRuleXMLHandler::GenericRuleXMLHandler%5F5FCEE30382.initialization preserve=yes
  ,XMLHandler(pXMLItem)
  //## end command::GenericRuleXMLHandler::GenericRuleXMLHandler%5F5FCEE30382.initialization
{
  //## begin command::GenericRuleXMLHandler::GenericRuleXMLHandler%5F5FCEE30382.body preserve=yes
  //## end command::GenericRuleXMLHandler::GenericRuleXMLHandler%5F5FCEE30382.body
}


GenericRuleXMLHandler::~GenericRuleXMLHandler()
{
  //## begin command::GenericRuleXMLHandler::~GenericRuleXMLHandler%5F5FC094023A_dest.body preserve=yes
  //## end command::GenericRuleXMLHandler::~GenericRuleXMLHandler%5F5FC094023A_dest.body
}



//## Other Operations (implementation)
void GenericRuleXMLHandler::endElement (const XMLCh* const name)
{
  //## begin command::GenericRuleXMLHandler::endElement%5F5FCEB300F2.body preserve=yes
   if (m_hElement.size() > 2)
   {
      if (m_hElement[m_hElement.size() - 2] == "Criteria")
      {
         vector<string> hTokens;
         if (Buffer::parse(m_hElement.back(),".-",hTokens) == 3 )
         {
            m_hCriteriaData.setTable(hTokens[0]);
            if (hTokens[0] == "C")
               m_hCriteriaData.setField(hTokens[1]+'-'+hTokens[2]);
            if (hTokens[0] == "A")
            {
               m_hCriteriaData.setField(hTokens[2] + " AS " + hTokens[1] + '_' + hTokens[2]);
               m_pGenericRule->setQueryParameter(hTokens[1],m_hCriteriaData.getField());
            }
            if (getCharacters()[0] == '~'
               && Buffer::parse(getCharacters(),"~.-",hTokens) == 3)
            {
               Object::trim(hTokens[0]);
               Object::trim(hTokens[1]);
               Object::trim(hTokens[2]);
               if (hTokens[0] == "C")
                  m_hCriteriaData.setValue(hTokens[0] + '.' + hTokens[1] + '-' + hTokens[2]);
               if (hTokens[0] == "A")
               {
                  m_hCriteriaData.setValue(hTokens[0] + '.' + hTokens[2] + " AS " + hTokens[1] + '_' + hTokens[2]);
                  m_pGenericRule->setQueryParameter(hTokens[1],m_hCriteriaData.getValue().substr(2));
               }
            }
            else
               m_hCriteriaData.setValue(getCharacters());
            m_hCriteria.addCriteriaData(m_hCriteriaData);
            m_hCriteriaData.clear();
         }
      }
      else if (m_hElement[m_hElement.size() - 2] == "Rule")
      {
         if (m_hElement.back() == "Id")
            m_hFunction.setName(getCharacters());
         if (m_hElement.back() == "Name")
            m_hFunction.setName(m_hFunction.getName() +':' + getCharacters());
      }
   }
   if (m_hElement.back() == "Criteria")
   {
      m_hFunction.addCriteria(m_hCriteria);
      m_hCriteria.clear();
   }
   if (m_hElement.back() == "Rule" && m_pGenericRule)
   {
      m_pGenericRule->addRule(m_hFunction);
      m_hFunction.clear();
   }
   XMLHandler::endElement(name);
  //## end command::GenericRuleXMLHandler::endElement%5F5FCEB300F2.body
}

void GenericRuleXMLHandler::startElement (const XMLCh* const name, AttributeList& attributes)
{
  //## begin command::GenericRuleXMLHandler::startElement%5F5FCF19030F.body preserve=yes
   XMLHandler::startElement(name,attributes);
   if (m_hElement.size() > 2
      && m_hElement[m_hElement.size() - 2] == "Criteria")
   {
      const XMLCh* pType = attributes.getValue("operator");
      if (pType)
      {
         getToken("GenericFunctionXMLHandler::startElement operator= ",pType,XMLString::stringLen(pType));
         m_hCriteriaData.setOperator(getToken());
      }
      else
         m_hCriteriaData.setOperator("=");
      pType = attributes.getValue("substring");
      if (pType)
      {
         getToken("GenericFunctionXMLHandler::startElement substring= ",pType,XMLString::stringLen(pType));
         m_hCriteriaData.setSubStringAttribute(getToken());
      }
      pType = attributes.getValue("function");
      if (pType)
      {
         getToken("GenericFunctionXMLHandler::startElement function= ", pType, XMLString::stringLen(pType));
         m_hCriteriaData.setFunctionAttribute(getToken());
      }
   }
  //## end command::GenericRuleXMLHandler::startElement%5F5FCF19030F.body
}

// Additional Declarations
  //## begin command::GenericRuleXMLHandler%5F5FC094023A.declarations preserve=yes
  //## end command::GenericRuleXMLHandler%5F5FC094023A.declarations

} // namespace command

//## begin module%5F5FC49C016E.epilog preserve=yes
//## end module%5F5FC49C016E.epilog
