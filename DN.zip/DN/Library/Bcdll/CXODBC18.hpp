//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4242EBAE03D8.cm preserve=no
//	$Date:   Sep 12 2013 04:15:52  $ $Author:   e1014059  $ $Revision:   1.19  $
//## end module%4242EBAE03D8.cm

//## begin module%4242EBAE03D8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4242EBAE03D8.cp

//## Module: CXOSBC18%4242EBAE03D8; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC18.hpp

#ifndef CXOSBC18_h
#define CXOSBC18_h 1

//## begin module%4242EBAE03D8.additionalIncludes preserve=no
//## end module%4242EBAE03D8.additionalIncludes

//## begin module%4242EBAE03D8.includes preserve=yes
#include <map>
#include <deque>
#include "CXODBC19.hpp"
//## end module%4242EBAE03D8.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Timestamp;
class Console;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class HourAlarm;
class Date;
class Clock;
class Timer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

namespace database {
class GenerationDataGroup;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ImportReportAuditSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class ImportTransaction;
class ImportData;

} // namespace command

//## begin module%4242EBAE03D8.declarations preserve=no
//## end module%4242EBAE03D8.declarations

//## begin module%4242EBAE03D8.additionalDeclarations preserve=yes
//## end module%4242EBAE03D8.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::ImportFile%4242EB5F02FD.preface preserve=yes
//## end command::ImportFile%4242EB5F02FD.preface

//## Class: ImportFile%4242EB5F02FD
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4243238D034B;process::Application { -> F}
//## Uses: <unnamed>%42482184006D;timer::Clock { -> F}
//## Uses: <unnamed>%424821C602BF;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%424821CC03B9;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%424821CE01E4;reusable::Table { -> F}
//## Uses: <unnamed>%424821D000FA;reusable::Statement { -> F}
//## Uses: <unnamed>%424823C20261;monitor::UseCase { -> F}
//## Uses: <unnamed>%426686BB01B5;database::Database { -> F}
//## Uses: <unnamed>%4459F8A60109;ImportTransaction { -> F}
//## Uses: <unnamed>%44641B2D0134;segment::ImportReportAuditSegment { -> F}
//## Uses: <unnamed>%44641B7A02AD;reusable::Transaction { -> F}
//## Uses: <unnamed>%4464905B034D;IF::Extract { -> F}
//## Uses: <unnamed>%45CA497500A0;IF::Console { -> F}
//## Uses: <unnamed>%47235468008C;IF::Timestamp { -> F}
//## Uses: <unnamed>%47D781350205;timer::Date { -> F}
//## Uses: <unnamed>%517EE05E038C;ImportData { -> F}
//## Uses: <unnamed>%504A40ED0011;reusable::Query { -> F}

class DllExport ImportFile : public reusable::Observer  //## Inherits: <unnamed>%4242EB7F0138
{
  //## begin command::ImportFile%4242EB5F02FD.initialDeclarations preserve=yes
  //## end command::ImportFile%4242EB5F02FD.initialDeclarations

  public:
    //## Constructors (generated)
      ImportFile();

    //## Destructor (generated)
      virtual ~ImportFile();


    //## Other Operations (specified)
      //## Operation: add%4242FB4B009C
      void add (const char* pszGENNAM, command::ImportTransaction* pImportTransaction, ImportFile* pImportFile);

      //## Operation: age%47D77D7E004E
      static void age ();

      //## Operation: instance%424302B40213
      static ImportFile* instance ();

      //## Operation: onResume%4248272402FD
      void onResume ();

      //## Operation: read%424321DB035B
      bool read (const char* pszGENNAM, bool bTruncate = true);

      //## Operation: update%4242EB8403A9
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin command::ImportFile%4242EB5F02FD.public preserve=yes
      //## end command::ImportFile%4242EB5F02FD.public

  protected:

    //## Other Operations (specified)
      //## Operation: acceptRecord%45E361A50178
      virtual bool acceptRecord (char* pBuffer, int& m);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: VariableBlock%46F20C5802FA
      const bool& getVariableBlock () const
      {
        //## begin command::ImportFile::getVariableBlock%46F20C5802FA.get preserve=no
        return m_bVariableBlock;
        //## end command::ImportFile::getVariableBlock%46F20C5802FA.get
      }

      void setVariableBlock (const bool& value)
      {
        //## begin command::ImportFile::setVariableBlock%46F20C5802FA.set preserve=no
        m_bVariableBlock = value;
        //## end command::ImportFile::setVariableBlock%46F20C5802FA.set
      }


    // Data Members for Class Attributes

      //## Attribute: DI_FILE_ID%468B53FF02F5
      //## begin command::ImportFile::DI_FILE_ID%468B53FF02F5.attr preserve=no  protected: int {U} 0
      int m_iDI_FILE_ID;
      //## end command::ImportFile::DI_FILE_ID%468B53FF02F5.attr

      //## Attribute: FileName%458246BB02F0
      //## begin command::ImportFile::FileName%458246BB02F0.attr preserve=no  public: string {U} 
      string m_strFileName;
      //## end command::ImportFile::FileName%458246BB02F0.attr

      //## Attribute: SEQ_NO%522897660176
      //## begin command::ImportFile::SEQ_NO%522897660176.attr preserve=no  protected: int {U} 0
      int m_siSEQ_NO;
      //## end command::ImportFile::SEQ_NO%522897660176.attr

      //## Attribute: TRANSACTION_NO%4582470A01F2
      //## begin command::ImportFile::TRANSACTION_NO%4582470A01F2.attr preserve=no  protected: int {U} 0
      int m_iTRANSACTION_NO;
      //## end command::ImportFile::TRANSACTION_NO%4582470A01F2.attr

      //## Attribute: TranSeqNum%468B54340022
      //## begin command::ImportFile::TranSeqNum%468B54340022.attr preserve=no  protected: string {U} 
      string m_strTranSeqNum;
      //## end command::ImportFile::TranSeqNum%468B54340022.attr

      //## Attribute: TSTAMP_INITIATED%4582473E00C6
      //## begin command::ImportFile::TSTAMP_INITIATED%4582473E00C6.attr preserve=no  public: string {U} 
      string m_strTSTAMP_INITIATED;
      //## end command::ImportFile::TSTAMP_INITIATED%4582473E00C6.attr

      //## begin command::ImportFile::VariableBlock%46F20C5802FA.attr preserve=no  protected: bool {U} false
      bool m_bVariableBlock;
      //## end command::ImportFile::VariableBlock%46F20C5802FA.attr

    // Additional Protected Declarations
      //## begin command::ImportFile%4242EB5F02FD.protected preserve=yes
      //## end command::ImportFile%4242EB5F02FD.protected

  private:
    // Additional Private Declarations
      //## begin command::ImportFile%4242EB5F02FD.private preserve=yes
      //## end command::ImportFile%4242EB5F02FD.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DATA_BUFFER%42482ABE0203
      //## begin command::ImportFile::DATA_BUFFER%42482ABE0203.attr preserve=no  private: string {V} 
      string m_strDATA_BUFFER;
      //## end command::ImportFile::DATA_BUFFER%42482ABE0203.attr

      //## Attribute: hImportTransaction%5047C516012D
      //## begin command::ImportFile::hImportTransaction%5047C516012D.attr preserve=no  private: command::ImportTransaction {U} 
      command::ImportTransaction m_hImportTransaction;
      //## end command::ImportFile::hImportTransaction%5047C516012D.attr

      //## Attribute: ImportTransaction%4451C13D02A1
      //## begin command::ImportFile::ImportTransaction%4451C13D02A1.attr preserve=no  public: static map<string, pair<ImportTransaction *,ImportFile *>, less<string> >* {V} 0
      static map<string, pair<ImportTransaction *,ImportFile *>, less<string> >* m_pImportTransaction;
      //## end command::ImportFile::ImportTransaction%4451C13D02A1.attr

      //## Attribute: ImportTransactions%5047999F012B
      //## begin command::ImportFile::ImportTransactions%5047999F012B.attr preserve=no  private: deque<ImportTransaction> {U} 
      deque<ImportTransaction> m_hImportTransactions;
      //## end command::ImportFile::ImportTransactions%5047999F012B.attr

      //## Attribute: Instance%424302A002FD
      //## begin command::ImportFile::Instance%424302A002FD.attr preserve=no  private: static ImportFile* {V} 0
      static ImportFile* m_pInstance;
      //## end command::ImportFile::Instance%424302A002FD.attr

      //## Attribute: Timer%4C40AD1103AD
      //## begin command::ImportFile::Timer%4C40AD1103AD.attr preserve=no  private: static int {V} 60
      static int m_iTimer;
      //## end command::ImportFile::Timer%4C40AD1103AD.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%471DF99C03C8
      //## Role: ImportFile::<m_pGenerationDataGroup>%471DF99D02DE
      //## begin command::ImportFile::<m_pGenerationDataGroup>%471DF99D02DE.role preserve=no  public: database::GenerationDataGroup { -> RFHgN}
      database::GenerationDataGroup *m_pGenerationDataGroup;
      //## end command::ImportFile::<m_pGenerationDataGroup>%471DF99D02DE.role

      //## Association: Connex Library::Command_CAT::<unnamed>%4C40A7BF00B8
      //## Role: ImportFile::<m_pTimer>%4C40A7C0001C
      //## begin command::ImportFile::<m_pTimer>%4C40A7C0001C.role preserve=no  public: static timer::Timer { -> RFHgN}
      static timer::Timer *m_pTimer;
      //## end command::ImportFile::<m_pTimer>%4C40A7C0001C.role

      //## Association: Connex Library::Command_CAT::<unnamed>%5228958D0117
      //## Role: ImportFile::<m_pHourAlarm>%5228958F0216
      //## begin command::ImportFile::<m_pHourAlarm>%5228958F0216.role preserve=no  public: static timer::HourAlarm { -> RFHgN}
      static timer::HourAlarm *m_pHourAlarm;
      //## end command::ImportFile::<m_pHourAlarm>%5228958F0216.role

    // Additional Implementation Declarations
      //## begin command::ImportFile%4242EB5F02FD.implementation preserve=yes
      //## end command::ImportFile%4242EB5F02FD.implementation

};

//## begin command::ImportFile%4242EB5F02FD.postscript preserve=yes
//## end command::ImportFile%4242EB5F02FD.postscript

} // namespace command

//## begin module%4242EBAE03D8.epilog preserve=yes
using namespace command;
//## end module%4242EBAE03D8.epilog


#endif
