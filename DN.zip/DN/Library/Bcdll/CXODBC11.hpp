//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%370BADE60022.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%370BADE60022.cm

//## begin module%370BADE60022.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%370BADE60022.cp

//## Module: CXOSBC11%370BADE60022; Package specification
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC11.hpp

#ifndef CXOSBC11_h
#define CXOSBC11_h 1

//## begin module%370BADE60022.additionalIncludes preserve=no
//## end module%370BADE60022.additionalIncludes

//## begin module%370BADE60022.includes preserve=yes
// $Date:   Apr 08 2004 11:17:18  $ $Author:   D02405  $ $Revision:   1.1  $
//## end module%370BADE60022.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class CustomizationSegment;
} // namespace usersegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
class Query;
class Table;
} // namespace reusable

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class ResponseTimeSegment;
class ListSegment;
class CommonHeaderSegment;

} // namespace segment

//## begin module%370BADE60022.declarations preserve=no
//## end module%370BADE60022.declarations

//## begin module%370BADE60022.additionalDeclarations preserve=yes
//## end module%370BADE60022.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::UpdateCustomizationCommand%3708C9580294.preface preserve=yes
//## end command::UpdateCustomizationCommand%3708C9580294.preface

//## Class: UpdateCustomizationCommand%3708C9580294
//	QUPDCUST - save end user customization data.
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%370CD431015D;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%370CD45403DE;IF::Message { -> F}
//## Uses: <unnamed>%370CD4BE0278;segment::InformationSegment { -> F}
//## Uses: <unnamed>%370CD500022D;usersegment::CustomizationSegment { -> F}
//## Uses: <unnamed>%370CD52203D0;reusable::Query { -> F}
//## Uses: <unnamed>%370CD6CD0103;reusable::Table { -> F}
//## Uses: <unnamed>%370CEAFE03C3;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%370CEB1A03B9;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%370CEBC102C9;reusable::Statement { -> F}
//## Uses: <unnamed>%371F43AE03D4;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%3A0090AC012B;monitor::UseCase { -> F}

class DllExport UpdateCustomizationCommand : public ClientCommand  //## Inherits: <unnamed>%3708C970002C
{
  //## begin command::UpdateCustomizationCommand%3708C9580294.initialDeclarations preserve=yes
  //## end command::UpdateCustomizationCommand%3708C9580294.initialDeclarations

  public:
    //## Constructors (generated)
      UpdateCustomizationCommand();

    //## Constructors (specified)
      //## Operation: UpdateCustomizationCommand%3E96B3AE01A5
      UpdateCustomizationCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~UpdateCustomizationCommand();


    //## Other Operations (specified)
      //## Operation: execute%370CD149024D
      //	Perform the functions of this command.
      bool execute ();

    // Additional Public Declarations
      //## begin command::UpdateCustomizationCommand%3708C9580294.public preserve=yes
      //## end command::UpdateCustomizationCommand%3708C9580294.public

  protected:
    // Additional Protected Declarations
      //## begin command::UpdateCustomizationCommand%3708C9580294.protected preserve=yes
      //## end command::UpdateCustomizationCommand%3708C9580294.protected

  private:
    // Additional Private Declarations
      //## begin command::UpdateCustomizationCommand%3708C9580294.private preserve=yes
      //## end command::UpdateCustomizationCommand%3708C9580294.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%370CD47E0154
      //## Role: UpdateCustomizationCommand::<m_pListSegment>%370CD47F0213
      //## begin command::UpdateCustomizationCommand::<m_pListSegment>%370CD47F0213.role preserve=no  public: segment::ListSegment { -> RFHgN}
      segment::ListSegment *m_pListSegment;
      //## end command::UpdateCustomizationCommand::<m_pListSegment>%370CD47F0213.role

    // Additional Implementation Declarations
      //## begin command::UpdateCustomizationCommand%3708C9580294.implementation preserve=yes
      //## end command::UpdateCustomizationCommand%3708C9580294.implementation

};

//## begin command::UpdateCustomizationCommand%3708C9580294.postscript preserve=yes
//## end command::UpdateCustomizationCommand%3708C9580294.postscript

} // namespace command

//## begin module%370BADE60022.epilog preserve=yes
using namespace command;
//## end module%370BADE60022.epilog


#endif
