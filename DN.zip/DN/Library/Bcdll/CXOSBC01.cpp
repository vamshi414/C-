//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3597D5B600F1.cm preserve=no
//	$Date:   Apr 29 2020 17:13:56  $ $Author:   e1094689  $
//	$Revision:   1.21  $
//## end module%3597D5B600F1.cm

//## begin module%3597D5B600F1.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3597D5B600F1.cp

//## Module: CXOSBC01%3597D5B600F1; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC01.cpp

//## begin module%3597D5B600F1.additionalIncludes preserve=no
//## end module%3597D5B600F1.additionalIncludes

//## begin module%3597D5B600F1.includes preserve=yes
//## end module%3597D5B600F1.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSUS15_h
#include "CXODUS15.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSUS05_h
#include "CXODUS05.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif


//## begin module%3597D5B600F1.declarations preserve=no
//## end module%3597D5B600F1.declarations

//## begin module%3597D5B600F1.additionalDeclarations preserve=yes
//## end module%3597D5B600F1.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::ClientCommand

//## begin command::ClientCommand::SubSelect%5D1CA58B030C.attr preserve=no  private: static reusable::string {V}
reusable::string ClientCommand::m_strSubSelect;
//## end command::ClientCommand::SubSelect%5D1CA58B030C.attr

//## begin command::ClientCommand::<m_pGlobalContext>%49F75A52034B.role preserve=no  public: static database::GlobalContext { -> 2RFHgN}
database::GlobalContext *ClientCommand::m_pGlobalContext[2] = {0,0};
//## end command::ClientCommand::<m_pGlobalContext>%49F75A52034B.role

ClientCommand::ClientCommand()
  //## begin ClientCommand::ClientCommand%359787DE0100_const.hasinit preserve=no
      : m_pDataBuffer(0),
        m_iResultCode(0)
  //## end ClientCommand::ClientCommand%359787DE0100_const.hasinit
  //## begin ClientCommand::ClientCommand%359787DE0100_const.initialization preserve=yes
  //## end ClientCommand::ClientCommand%359787DE0100_const.initialization
{
  //## begin command::ClientCommand::ClientCommand%359787DE0100_const.body preserve=yes
   m_pResponseTimeSegment = 0;
  //## end command::ClientCommand::ClientCommand%359787DE0100_const.body
}

ClientCommand::ClientCommand (const char* pszMessageID, const char* pszQueue)
  //## begin command::ClientCommand::ClientCommand%3597EEDE0304.hasinit preserve=no
      : m_pDataBuffer(0),
        m_iResultCode(0)
  //## end command::ClientCommand::ClientCommand%3597EEDE0304.hasinit
  //## begin command::ClientCommand::ClientCommand%3597EEDE0304.initialization preserve=yes
   ,Command(pszMessageID)
  //## end command::ClientCommand::ClientCommand%3597EEDE0304.initialization
{
  //## begin command::ClientCommand::ClientCommand%3597EEDE0304.body preserve=yes
   m_hSegments.push_back(CommonHeaderSegment::instance());
   m_pResponseTimeSegment = new ResponseTimeSegment();
   m_hSegments.push_back(m_pResponseTimeSegment);
   m_hSegments.push_back(usersegment::RelationshipSegment::instance());
   m_pRelationshipSegment = usersegment::RelationshipSegment::instance();
   m_hSegments.push_back(usersegment::ResourceListSegment::instance());
   if (pszQueue)
   {
      m_strObjectName = pszQueue;
      m_strServiceName = "Q";
      if (strstr(m_strObjectName.data(),"##"))
         m_strServiceName += m_strObjectName.substr(3,m_strObjectName.length() - 3);
      else
         m_strServiceName += m_strObjectName.substr(1,m_strObjectName.length() - 1);
      publish();
   }
  //## end command::ClientCommand::ClientCommand%3597EEDE0304.body
}


ClientCommand::~ClientCommand()
{
  //## begin command::ClientCommand::~ClientCommand%359787DE0100_dest.body preserve=yes
   delete m_pResponseTimeSegment;
  //## end command::ClientCommand::~ClientCommand%359787DE0100_dest.body
}



//## Other Operations (implementation)
void ClientCommand::abort ()
{
  //## begin command::ClientCommand::abort%5D1CBAE30369.body preserve=yes
  //## end command::ClientCommand::abort%5D1CBAE30369.body
}

void ClientCommand::onResume ()
{
  //## begin command::ClientCommand::onResume%3A79CFED00F5.body preserve=yes
  //## end command::ClientCommand::onResume%3A79CFED00F5.body
}

int ClientCommand::parse ()
{
  //## begin command::ClientCommand::parse%4D1215480224.body preserve=yes
   m_lInfoIDNumber = 0;
   return Command::parse();
  //## end command::ClientCommand::parse%4D1215480224.body
}

bool ClientCommand::publish ()
{
  //## begin command::ClientCommand::publish%3AE977E9032E.body preserve=yes
   Message::instance(Message::OUTBOUND)->reset("SRVCLI","S0004R",false);
   char* p = Message::instance(Message::OUTBOUND)->data();
   memset(p,' ',9);
   memcpy_s(p,9,m_strServiceName.data(),(m_strServiceName.length() < 9)? m_strServiceName.length(): 8);
   *(p + 8) = 'Y';
   Message::instance(Message::OUTBOUND)->setDataLength(9);
   return (Message::instance(Message::OUTBOUND)->send("##CI01") == 0);
  //## end command::ClientCommand::publish%3AE977E9032E.body
}

int ClientCommand::reply ()
{
  //## begin command::ClientCommand::reply%3597D4EA024C.body preserve=yes
   int m = (int)(m_pDataBuffer - Message::instance(Message::INBOUND)->data());
   char szTemp[PERCENTD];
   snprintf(szTemp,sizeof(szTemp),"%08d",m);
   strncpy(Message::instance(Message::INBOUND)->data(),szTemp,8);
   Message::instance(Message::INBOUND)->setDataLength(m);
   Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   // RelationshipSegment::instance()->reset();
   return Message::instance(Message::INBOUND)->reply();
  //## end command::ClientCommand::reply%3597D4EA024C.body
}

const char* ClientCommand::secure (enum Entity nEntity)
{
  //## begin command::ClientCommand::secure%5D1CA5DF0303.body preserve=yes
   Query q;
   q.setDistinct(true);
   q.setSubSelect(true);
   q.setQualifier("QUALIFY","AS_USER_PROFILE");
   q.setQualifier("QUALIFY","AS_ENTITY_ROLE");
   q.setQualifier("QUALIFY","AS_ROLE_RELATION");
   q.join("AS_USER_PROFILE","INNER","AS_ENTITY_ROLE","ENTITY_ID");
   q.join("AS_ENTITY_ROLE","INNER","AS_ROLE_RELATION","ROLE_ID");
   q.bind("AS_ENTITY_ROLE","ONLINE_ENTITY_ID",Column::STRING,0);
   q.setBasicPredicate("AS_USER_PROFILE","USER_ID","=",CommonHeaderSegment::instance()->getUserID().c_str());
   q.setBasicPredicate("AS_USER_PROFILE","CUST_ID","=",CommonHeaderSegment::instance()->getCUST_ID().c_str());
   const char* pszValue[5] =
   {
      "NET_TERM%",
      "RPT%",
      "INST_ID%",
      "PROC_ID%",
      "PROC_GRP%"
   };
   if ((int)nEntity < 5)
      q.setBasicPredicate("AS_ROLE_RELATION","STS_TRAN_COL_NAME","LIKE",pszValue[(int)nEntity]);
   else
      q.setBasicPredicate("AS_ROLE_RELATION","STS_TRAN_COL_NAME","=","*");
   auto_ptr<reusable::FormatSelectVisitor>pFormatSelectVisitor((reusable::FormatSelectVisitor*)database::DatabaseFactory::instance()->create("FormatSelectVisitor"));
   q.accept(*pFormatSelectVisitor);
   m_strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ")";
   return m_strSubSelect.c_str();
  //## end command::ClientCommand::secure%5D1CA5DF0303.body
}

int ClientCommand::sendError (int iResultCode, char sSeverityLevel, int lInfoIDNumber, bool bReset, const char* pszText)
{
  //## begin command::ClientCommand::sendError%3597D4FA00A1.body preserve=yes
   if (m_strServiceName.length() > 3
        && m_strServiceName.substr(3,1) == "U"
        && lInfoIDNumber == STS_RECORD_NOT_FOUND)
              lInfoIDNumber = STS_ACTION_FAILED_RECORD_MODIFIED;
   CommonHeaderSegment::instance()->setResultCode(iResultCode);
   InformationSegment::instance()->setError(sSeverityLevel,lInfoIDNumber);
   if (pszText)
      InformationSegment::instance()->setText(pszText);
   if (bReset)
      Message::instance(Message::INBOUND)->reset("CDNCI ","S0003R");
   m_pDataBuffer = Message::instance(Message::INBOUND)->data() + 8;
   CommonHeaderSegment::instance()->deport(&m_pDataBuffer);
   InformationSegment::instance()->deport(&m_pDataBuffer);
   InformationSegment::instance()->setText("");
   m_pResponseTimeSegment->deport(&m_pDataBuffer);
   reply();
   if (iResultCode != 0)
   {
      UseCase::setSuccess(false);
      Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   }
   return -1;
  //## end command::ClientCommand::sendError%3597D4FA00A1.body
}

void ClientCommand::update (Subject* pSubject)
{
  //## begin command::ClientCommand::update%37AF0B69023B.body preserve=yes
   if (pSubject == Message::instance(Message::INBOUND))
   {
      if (Message::instance(Message::INBOUND)->messageID() == "S0004D")
      {
         publish();
         if (m_pSuccessor)
            m_pSuccessor->update(pSubject);
         return;
      }
      if (Message::instance(Message::INBOUND)->messageID() == "S0003D"
         || Message::instance(Message::INBOUND)->messageID() == "S0005D")
      {
         char* p = ((Message*)pSubject)->data() + 24;
         if (strncmp(p,m_strServiceName.data(),8) == 0)
            execute();
         else
         if (m_pSuccessor)
            m_pSuccessor->update(pSubject);
      }
      return;
   }
  //## end command::ClientCommand::update%37AF0B69023B.body
}

//## Get and Set Operations for Associations (implementation)

database::GlobalContext * ClientCommand::getGlobalContext (int index)
{
  //## begin command::ClientCommand::getGlobalContext%49F75A52034B.get preserve=no
  return m_pGlobalContext[index];
  //## end command::ClientCommand::getGlobalContext%49F75A52034B.get
}

void ClientCommand::setGlobalContext (int index, database::GlobalContext * value)
{
  //## begin command::ClientCommand::setGlobalContext%49F75A52034B.set preserve=no
  m_pGlobalContext[index] = value;
  //## end command::ClientCommand::setGlobalContext%49F75A52034B.set
}

// Additional Declarations
  //## begin command::ClientCommand%359787DE0100.declarations preserve=yes
  //## end command::ClientCommand%359787DE0100.declarations

} // namespace command

//## begin module%3597D5B600F1.epilog preserve=yes
//## end module%3597D5B600F1.epilog
