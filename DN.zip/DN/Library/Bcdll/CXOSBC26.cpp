//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%48BEBBEB0244.cm preserve=no
//## end module%48BEBBEB0244.cm

//## begin module%48BEBBEB0244.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%48BEBBEB0244.cp

//## Module: CXOSBC26%48BEBBEB0244; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC26.cpp

//## begin module%48BEBBEB0244.additionalIncludes preserve=no
//## end module%48BEBBEB0244.additionalIncludes

//## begin module%48BEBBEB0244.includes preserve=yes
#include "CXODTM04.hpp"
#include "CXODTM03.hpp"
#include "CXODTM06.hpp"
#include "CXODIF03.hpp"
#include "CXODIF04.hpp"
#include "CXODRU29.hpp"
#include "CXODBS06.hpp"
#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
#include <algorithm>
#include "CXODIF58.hpp"
//## end module%48BEBBEB0244.includes

#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSUS25_h
#include "CXODUS25.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSRU41_h
#include "CXODRU41.hpp"
#endif
#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif
#ifndef CXOSBC26_h
#include "CXODBC26.hpp"
#endif


//## begin module%48BEBBEB0244.declarations preserve=no
//## end module%48BEBBEB0244.declarations

//## begin module%48BEBBEB0244.additionalDeclarations preserve=yes
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSDB52_h
#include "CXODDB52.hpp"
#endif
#ifndef CXOSBC27_h
#include "CXODBC27.hpp"
#endif
//## end module%48BEBBEB0244.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::Security 

//## begin command::Security::Instance%490B6EFE0104.attr preserve=no  public: static command::Security* {V} 0
command::Security* Security::m_pInstance = 0;
//## end command::Security::Instance%490B6EFE0104.attr

Security::Security()
  //## begin Security::Security%48BEBB9F0137_const.hasinit preserve=no
      : m_siAP_PWD_EXPIRE_DAYS(365),
        m_strCUST_ID("****"),
        m_cDIGEST_METHOD('M'),
        m_bDIGIT_REQ_FLG(true),
        m_bLOWER_CASE_REQ_FLG(true),
        m_siMAX_FAIL_ATTEMPTS(3),
        m_siPWD_EXPIRE_DAYS(90),
        m_siPWD_HISTORY_COUNT(10),
        m_siPWD_MIN_LENGTH(8),
        m_bREPEATING_CHAR_FLG(false),
        m_bSPECIAL_REQ_FLG(true),
        m_bUPPER_CASE_REQ_FLG(true)
  //## end Security::Security%48BEBB9F0137_const.hasinit
  //## begin Security::Security%48BEBB9F0137_const.initialization preserve=yes
  //## end Security::Security%48BEBB9F0137_const.initialization
{
  //## begin command::Security::Security%48BEBB9F0137_const.body preserve=yes
   m_pInstance = this;
   m_cDIGEST_METHOD = 'A';
   MidnightAlarm::instance()->attach(this);
  //## end command::Security::Security%48BEBB9F0137_const.body
}


Security::~Security()
{
  //## begin command::Security::~Security%48BEBB9F0137_dest.body preserve=yes
   m_pInstance = 0;
  //## end command::Security::~Security%48BEBB9F0137_dest.body
}



//## Other Operations (implementation)
int Security::authenticateUser (const string& strUserid, const string& strPassword)
{
  //## begin command::Security::authenticateUser%48BECFC80323.body preserve=yes
   int iRC = IF::RACF::validatePassword(strUserid, strPassword);
   if (iRC > 0)
      return iRC;
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   reusable::Query hQuery;
   string strTemp;
   hQuery.bind("AS_USER_LOGON", "USER_ID", Column::STRING, &strTemp);
   hQuery.setQualifier("QUALIFY", "AS_USER_LOGON");
   hQuery.setBasicPredicate("AS_USER_LOGON", "USER_ID", "=", strUserid.c_str());
   hQuery.setBasicPredicate("AS_USER_LOGON", "USER_STATUS", "<>", "S");
   if (pSelectStatement->execute(hQuery) == true && pSelectStatement->getRows() > 0)
   {
      updateLastLogon(strUserid);
      return 0;
   }
   return 1;

  //## end command::Security::authenticateUser%48BECFC80323.body
}

int Security::changePassword (const string& strUserid, const string& strNewPassword)
{
  //## begin command::Security::changePassword%48BED0B401EC.body preserve=yes
   int iRC = validatePwdComplexity(strNewPassword);
   if (iRC != 0)
      return iRC;
   if (m_siPWD_HISTORY_COUNT > 0)
   {
      CriticalSection hCriticalSection;
      retrievePwdHistory(strUserid);
      iRC = validatePwdHistory(strNewPassword);
      if (iRC != 0)
         return iRC;
   }
   string strUSER_ID(strUserid);
   transform (strUSER_ID.begin(),strUSER_ID.end(), strUSER_ID.begin(), ::toupper);
   string strEncryptedPassword;
   string strSALT;
   generateSalt(strSALT);
   generateDigest(m_cDIGEST_METHOD,strNewPassword,strEncryptedPassword,strSALT);
   CodeTable::nibbleToByte(strEncryptedPassword.data(),strEncryptedPassword.length(),strEncryptedPassword);
   reusable::Table hTable("AS_USER_LOGON");
   hTable.setQualifier("QUALIFY");
   hTable.set("USER_ID",strUSER_ID.c_str(),false,true);
   hTable.set("USER_PASSWORD",string(""));
   hTable.set("USER_PWD_DIGEST",strEncryptedPassword);
   hTable.set("SALT",strSALT);
   hTable.set("DIGEST_METHOD",string(&m_cDIGEST_METHOD,1));
   hTable.set("USER_STATUS","A");
   hTable.set("FAILED_LOGON_COUNT",0);
   auto_ptr<reusable::Statement> pUpdateStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("UpdateStatement"));
   if (pUpdateStatement->execute(hTable) == false)
      return STS_DATABASE_FAILURE;
   hTable.reset();
   hTable.setName("AS_USER_HISTORY");
   hTable.setQualifier("QUALIFY");
   hTable.set("USER_ID",strUSER_ID.c_str(),false,true);
   hTable.set("TSTAMP_PASSWORD",Clock::instance()->getYYYYMMDDHHMMSS(true),false,true);
   hTable.set("NEW_PASSWORD",strEncryptedPassword);
   hTable.set("DIGEST_METHOD",string(&m_cDIGEST_METHOD,1));
   hTable.set("SALT",strSALT);
   auto_ptr<reusable::Statement> pInsertStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("InsertStatement"));
   if (pInsertStatement->execute(hTable) == false)
      return STS_DATABASE_FAILURE;
   map<string, string , less<string> >::iterator p = m_hPasswordExpiry.find(strUSER_ID);
   if (p != m_hPasswordExpiry.end())
      m_hPasswordExpiry.erase(p);
   return 0;
  //## end command::Security::changePassword%48BED0B401EC.body
}

bool Security::decrypt (string& strText, char* pHash)
{
  //## begin command::Security::decrypt%49A6A8CB00EB.body preserve=yes
   if (m_strKey.length() == 0 || strText.length() > 108)
      return false;
   if (pHash)
   {
      Trace::put("Client Hash",-1,true);
      Trace::put(pHash,4,true);
      Trace::put("Server Hash",-1,true);
      Trace::put(m_strHash.c_str(),4,true);
      if (memcmp(pHash,"    ",4) != 0 &&
         memcmp(pHash,m_strHash.data(),4) != 0)
         return false; //encrypted with obsolete key
   }
   unsigned char szCiphertext[109];
   memset(szCiphertext,' ',108);
   szCiphertext[108] = '\0';
   unsigned char* pszBase64text = new_unsigned_char(108,1); //returns buffer of filled with nulls
   char szPlaintext[109];
   memset( szPlaintext, 0, 108 );
   memcpy_s(pszBase64text,109,strText.data(),strText.length());

   //Base 64 uses '=' as the pad char discount them when calculating cipher len
   const char *pszPadCharPos = strchr( (const char*)pszBase64text, '=' );
   size_t iNumPadChars = 0;
   if ( pszPadCharPos != NULL )
      iNumPadChars = strlen( pszPadCharPos );
   size_t llCipherLen = (int)SecurityWrapper::EVP_DecodeBlock(szCiphertext,(const unsigned char*)pszBase64text,strText.length());
   delete[] pszBase64text;
   if(llCipherLen > iNumPadChars)
      llCipherLen -= iNumPadChars;
   if (llCipherLen > INT_MAX)
      return false;
   int iCipherLen = (int)llCipherLen;
   EVP_CIPHER_CTX* hEncCtx = EVP_CIPHER_CTX_new();
   const EVP_CIPHER* hCipher = SecurityWrapper::EVP_aes_256_cbc();
   unsigned char cInitVector[16];
   memcpy_s(cInitVector,sizeof(cInitVector),m_strKey.data(),16); //use 1st 16 bytes of key as iv
   SecurityWrapper::EVP_CIPHER_CTX_reset(hEncCtx);
   SecurityWrapper::EVP_DecryptInit_ex(hEncCtx,hCipher,0,(unsigned char *)m_strKey.c_str(),cInitVector);
   if (SecurityWrapper::EVP_DecryptUpdate( //decrypt most of the data
      hEncCtx,
      (unsigned char*)szPlaintext,
      &iCipherLen,
      szCiphertext,
      iCipherLen) < 0)
   {
      EVP_CIPHER_CTX_free(hEncCtx);
      return false; //error
   }
   strText.assign(szPlaintext, iCipherLen);
   iCipherLen = 32;
   if (SecurityWrapper::EVP_DecryptFinal_ex( //Add last block+padding:
      hEncCtx,
      (unsigned char*)szPlaintext,
      &iCipherLen) < 0)
   {
      EVP_CIPHER_CTX_free(hEncCtx);
      return false; //error
   }
   strText.append(szPlaintext,iCipherLen);
   SecurityWrapper::EVP_CIPHER_CTX_reset(hEncCtx);
   EVP_CIPHER_CTX_free(hEncCtx);
   return true; // Success
  //## end command::Security::decrypt%49A6A8CB00EB.body
}

void Security::incrementFailCount (const string& strUserid)
{
  //## begin command::Security::incrementFailCount%48C14BF703C4.body preserve=yes
   string strUSER_ID(strUserid);
   transform (strUSER_ID.begin(),strUSER_ID.end(), strUSER_ID.begin(), ::toupper);
   short siFAILED_LOGON_COUNT;
   reusable::Query hQuery;
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.setQualifier("QUALIFY","AS_USER_LOGON");
   hQuery.bind("AS_USER_LOGON","FAILED_LOGON_COUNT",Column::SHORT,&siFAILED_LOGON_COUNT);
   hQuery.setBasicPredicate("AS_USER_LOGON","USER_ID","=",strUSER_ID.c_str());
   if (!pSelectStatement->execute(hQuery))
      Database::instance()->rollback();
   siFAILED_LOGON_COUNT += 1;
   reusable::Table hTable("AS_USER_LOGON");
   hTable.setQualifier("QUALIFY");
   hTable.set("USER_ID",strUSER_ID.c_str(),false,true);
   if (m_siMAX_FAIL_ATTEMPTS > 0 && siFAILED_LOGON_COUNT >= m_siMAX_FAIL_ATTEMPTS)
      hTable.set("USER_STATUS","S");
   hTable.set("FAILED_LOGON_COUNT",siFAILED_LOGON_COUNT);
   auto_ptr<reusable::Statement> pUpdateStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("UpdateStatement"));
   if (pUpdateStatement->execute(hTable) == false)
      Database::instance()->rollback();
  //## end command::Security::incrementFailCount%48C14BF703C4.body
}

void Security::initialize ()
{
  //## begin command::Security::initialize%48BED54F0129.body preserve=yes
#ifdef CS
   return;
#endif
   //set defaults
   short siNull = -1;
   snprintf(m_sPwdRulesErrors,sizeof(m_sPwdRulesErrors),"NNNNN00NNNNNNN");
   char szUPPER_CASE_REQ_FLG[2] = {'N'};
   char szLOWER_CASE_REQ_FLG[2] = {'N'};
   char szDIGIT_REQ_FLG[2] = {'N'};
   char szSPECIAL_REQ_FLG[2] = {'N'};
   char szREPEATING_CHAR_FLG[2] = {'N'};
   Extract::instance()->getSpec("CUSTOMER",m_strCUST_ID);
   string strInClause("('****','");
   strInClause.append(m_strCUST_ID.data(),m_strCUST_ID.length());
   strInClause.append("')");
   reusable::Query hQuery;
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.setQualifier("QUALIFY","AS_LOGON_CNTL");
   hQuery.bind("AS_LOGON_CNTL","CUST_ID",Column::STRING,&m_strCUST_ID);
   hQuery.bind("AS_LOGON_CNTL","MAX_FAIL_ATTEMPTS",Column::SHORT,&m_siMAX_FAIL_ATTEMPTS);
   hQuery.bind("AS_LOGON_CNTL","PWD_EXPIRE_DAYS",Column::SHORT,&m_siPWD_EXPIRE_DAYS);
   hQuery.bind("AS_LOGON_CNTL","AP_PWD_EXPIRE_DAYS",Column::SHORT,&m_siAP_PWD_EXPIRE_DAYS,&siNull);
   hQuery.bind("AS_LOGON_CNTL","PWD_MIN_LENGTH",Column::SHORT,&m_siPWD_MIN_LENGTH);
   hQuery.bind("AS_LOGON_CNTL","PWD_HISTORY_COUNT",Column::SHORT,&m_siPWD_HISTORY_COUNT);
   hQuery.bind("AS_LOGON_CNTL","UPPER_CASE_REQ_FLG",Column::CHAR,szUPPER_CASE_REQ_FLG);
   hQuery.bind("AS_LOGON_CNTL","LOWER_CASE_REQ_FLG",Column::CHAR,szLOWER_CASE_REQ_FLG);
   hQuery.bind("AS_LOGON_CNTL","DIGIT_REQ_FLG",Column::CHAR,szDIGIT_REQ_FLG);
   hQuery.bind("AS_LOGON_CNTL","SPECIAL_REQ_FLG",Column::CHAR,szSPECIAL_REQ_FLG);
   hQuery.bind("AS_LOGON_CNTL","REPEATING_CHAR_FLG",Column::CHAR,szREPEATING_CHAR_FLG);
   hQuery.setBasicPredicate("AS_LOGON_CNTL","CUST_ID","IN",strInClause.c_str());
   hQuery.setOrderByClause("CUST_ID ASC");
   if (pSelectStatement->execute(hQuery) == true
      && pSelectStatement->getRows() > 0)
   {
      m_bUPPER_CASE_REQ_FLG = szUPPER_CASE_REQ_FLG[0] == 'Y' ? true : false;
      m_bLOWER_CASE_REQ_FLG = szLOWER_CASE_REQ_FLG[0] == 'Y' ? true : false;
      m_bDIGIT_REQ_FLG = szDIGIT_REQ_FLG[0] == 'Y' ? true : false;
      m_bSPECIAL_REQ_FLG = szSPECIAL_REQ_FLG[0] == 'Y' ? true : false;
      m_bREPEATING_CHAR_FLG = szREPEATING_CHAR_FLG[0] == 'Y' ? true : false;
      char szMsg[80];
      Trace::put("---AS_LOGON_CNTL----");
      Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"Min Pwd Length: %hd",m_siPWD_MIN_LENGTH));
      Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"Upper Required: %s",szUPPER_CASE_REQ_FLG));
      Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"Lower Required: %s",szLOWER_CASE_REQ_FLG));
      Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"Numeric Required: %s",szDIGIT_REQ_FLG));
      Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"Special Required: %s",szSPECIAL_REQ_FLG));
      Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"Repeating Restricted: %s",szREPEATING_CHAR_FLG));
      Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"Max Fail Attempts: %d",m_siMAX_FAIL_ATTEMPTS));
      Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"Pwd Expire Days: %d",m_siPWD_EXPIRE_DAYS));
      Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"Process id Pwd Expire Days: %hd",m_siAP_PWD_EXPIRE_DAYS));
      Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"Pwd History Cnt: %d",m_siPWD_HISTORY_COUNT));
      Trace::put("--------------------");
      //update m_sPwdRulesErrors with rules
      m_sPwdRulesErrors[14] = '\0';
      snprintf(szMsg,sizeof(szMsg),"%s%s%s%s%s%02dNNNNNNN",szUPPER_CASE_REQ_FLG,
         szLOWER_CASE_REQ_FLG,szDIGIT_REQ_FLG,szSPECIAL_REQ_FLG,
         szREPEATING_CHAR_FLG,m_siPWD_MIN_LENGTH);
      memcpy_s(m_sPwdRulesErrors,sizeof(m_sPwdRulesErrors),szMsg,14);
   }
   if (siNull == -1)
      m_siAP_PWD_EXPIRE_DAYS = 365;
   m_bCONSOLE_SECURITY_ENABLED = false;
   int lCount = 0;
   hQuery.reset();
   hQuery.bind("AS_WIDGET_RESTRICT","*",Column::LONG,&lCount,0,"COUNT");
   hQuery.join("AS_PROFILE_ENTRY","INNER","AS_USER_PROFILE","PROFILE_ID");
   hQuery.join("AS_WIDGET_RESTRICT","INNER","AS_PROFILE_ENTRY","PERMISSION_ID");
   hQuery.setQualifier("QUALIFY","AS_USER_PROFILE");
   hQuery.setQualifier("QUALIFY","AS_PROFILE_ENTRY");
   hQuery.setQualifier("QUALIFY","AS_WIDGET_RESTRICT");
   hQuery.setBasicPredicate("AS_USER_PROFILE","CUST_ID","=",m_strCUST_ID.c_str());
   hQuery.setBasicPredicate("AS_WIDGET_RESTRICT","WIDGET_ID","LIKE","CONSOLE_%");
   if (pSelectStatement->execute(hQuery) && lCount > 0)
      m_bCONSOLE_SECURITY_ENABLED = true;
  //## end command::Security::initialize%48BED54F0129.body
}

void Security::generateDigest (char cDigestMethod, const string& strPassword, string& strDigest, const string& strSalt)
{
  //## begin command::Security::generateDigest%48C01497033E.body preserve=yes
   const EVP_MD* md =SecurityWrapper::EVP_sha512();   //sha512 algorithm (64 char digest)
   if (cDigestMethod == 'M')
      md = SecurityWrapper::EVP_md5();   //md5 algorithm (16 char digest)
   else if (cDigestMethod == 'S')
      md = SecurityWrapper::EVP_sha1();   //sha1 algorithm (20 char digest)
   else if (cDigestMethod == 'A')
      md = SecurityWrapper::EVP_sha512();   //sha512 algorithm (64 char digest)
   else
      return;  //undefined digest method so do nothing
   EVP_MD_CTX* mdctx = EVP_MD_CTX_new();
   unsigned char md_value[EVP_MAX_MD_SIZE];
   unsigned int md_len;
   SecurityWrapper::EVP_MD_CTX_reset(mdctx);
   SecurityWrapper::EVP_DigestInit_ex(mdctx, md, NULL);
   if (cDigestMethod == 'A')
   {  //add salt algorithm here
      string strSaltedPassword = strPassword + strSalt;
      SecurityWrapper::EVP_DigestUpdate(mdctx,strSaltedPassword.c_str(),strSaltedPassword.length());
   }
   else
      SecurityWrapper::EVP_DigestUpdate(mdctx,strPassword.c_str(),strPassword.length());
   SecurityWrapper::EVP_DigestFinal_ex(mdctx, md_value, &md_len);
   SecurityWrapper::EVP_MD_CTX_reset(mdctx);
   strDigest.assign((const char*)md_value,md_len);
   EVP_MD_CTX_free(mdctx);
  //## end command::Security::generateDigest%48C01497033E.body
}

void Security::generateKey ()
{
  //## begin command::Security::generateKey%490F70550359.body preserve=yes
   //Because achieving enough entropy to produce a truly random key is difficult the
   //strategy being deployed here is to:
   // 1) use the openssl RSA_generate_key to generate a public/private key pair.
   // 2) use sha512 to hash the public key.
   // 3) convert the hash result to a printable hex representation.
   //The result is a 32 byte string.
   BIO *out = SecurityWrapper::BIO_new(SecurityWrapper::BIO_s_mem());
   RSA *rsa = NULL;
   rsa = SecurityWrapper::RSA_generate_key(2048,65537,NULL,NULL);
   if (rsa==NULL)
   {
      string strErr("Security::generateKey - ");
      strErr.append("Warning! Random key generation failed");
      Trace::put(strErr.c_str(),strErr.length(),true);
      return;
   }
   SecurityWrapper::PEM_write_bio_RSA_PUBKEY(out,rsa);
   SecurityWrapper::BIO_ctrl(out,BIO_CTRL_FLUSH,0,NULL);
   void* ptr = 0;
   long sz = SecurityWrapper::BIO_get_mem_data(out, &ptr);
   char psPublicKey[4096];
   memcpy_s(psPublicKey,sizeof(psPublicKey),ptr,sz);
   SecurityWrapper::BIO_ctrl(out,BIO_CTRL_SET_CLOSE,BIO_NOCLOSE,NULL);
   SecurityWrapper::BIO_free(out);
   string strDigest;
   generateDigest('A',string(psPublicKey,sz),strDigest);//creates a 64 byte sha512 digest
   m_strKey.assign("");
   char szTemp[3];
   unsigned char sDigest[64];
   memcpy_s(sDigest,sizeof(sDigest),strDigest.data(),64);
   for (int i = 0; i < 64; i++)
   {
      unsigned char c = sDigest[i];
      m_strKey.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%02x",c));
   }
   m_strKey.resize(32);
#ifdef MVS
   //convert key to ascii to prevent charset issues in java on web side
   CodeTable::translate((char*)m_strKey.data(),m_strKey.length(),CodeTable::CX_EBCDIC_TO_ASCII);
#endif
   generateDigest('A',m_strKey,m_strHash, "");//generates sha512 Hash value based on the 32 byte key
   string strHash;
   unsigned char sHash[64];
   memcpy_s(sHash,sizeof(sHash),m_strHash.data(),64);
   for (int i = 0; i < 64; i++)
   {
      unsigned char c = sHash[i];
      strHash.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%02x",c));
   }
   m_strHash.assign(strHash);
#ifdef MVS
   CodeTable::translate((char*)m_strHash.data(),m_strHash.length(),CodeTable::CX_EBCDIC_TO_ASCII);
#endif
   SecurityWrapper::base64Encode(m_strHash);
   if(m_strHash.length() >= 4)
   {//sub string for strHash. For even, gets middle 4. For odd, get middle 3 and 1 prior.
      m_strHash = m_strHash.substr((m_strHash.length()/2)-2,4);
   }
  //## end command::Security::generateKey%490F70550359.body
}

void Security::generateSalt (string& strSalt)
{
  //## begin command::Security::generateSalt%51ED847401F4.body preserve=yes
   SecurityWrapper::initializeRNG();
   unsigned int k;
   SecurityWrapper::RAND_bytes((unsigned char*)&k,4);
   char szBuffer[33];
   strSalt.assign(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"%u",k));
   strSalt.append(Clock::instance()->getYYYYMMDDHHMMSS());
  //## end command::Security::generateSalt%51ED847401F4.body
}

char Security::getAccountStatus (const string& strUserid)
{
  //## begin command::Security::getAccountStatus%48BEDEA90348.body preserve=yes
   string strUSER_ID = strUserid;
   transform (strUSER_ID.begin(),strUSER_ID.end(), strUSER_ID.begin(), ::toupper);
   char szUSER_STATUS[2] = {' '};
   reusable::Query hQuery;
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.setQualifier("QUALIFY","AS_USER_LOGON");
   hQuery.bind("AS_USER_LOGON","USER_STATUS",Column::CHAR,szUSER_STATUS);
   hQuery.setBasicPredicate("AS_USER_LOGON","USER_ID","=",strUSER_ID.c_str());
   if (pSelectStatement->execute(hQuery) == true && pSelectStatement->getRows() == 0)
      return 'E'; //user does not exist.
   return szUSER_STATUS[0];
  //## end command::Security::getAccountStatus%48BEDEA90348.body
}

string Security::getLastLogonDate (const string& strUserid)
{
  //## begin command::Security::getLastLogonDate%48BEDED70326.body preserve=yes
   string strUSER_ID = strUserid;
   transform (strUSER_ID.begin(),strUSER_ID.end(), strUSER_ID.begin(), ::toupper);
   string strLAST_LOGON_DATE;
   reusable::Query hQuery;
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.setQualifier("QUALIFY","AS_USER_LOGON");
   hQuery.bind("AS_USER_LOGON","LAST_LOGON_DATE",Column::STRING,&strLAST_LOGON_DATE);
   hQuery.setBasicPredicate("AS_USER_LOGON","USER_ID","=",strUSER_ID.c_str());
   if (pSelectStatement->execute(hQuery) == true
      && pSelectStatement->getRows() > 0)
      return strLAST_LOGON_DATE;
   return ""; //unavailable
  //## end command::Security::getLastLogonDate%48BEDED70326.body
}

string Security::getPasswordExpiration (const string& strUserid)
{
  //## begin command::Security::getPasswordExpiration%48BEDF06000C.body preserve=yes
   if (m_siPWD_EXPIRE_DAYS <= 0)
      return ""; //not enforcing password expirations
   string strUSER_ID = strUserid;
   transform (strUSER_ID.begin(),strUSER_ID.end(), strUSER_ID.begin(), ::toupper);
     //get last date that Password was changed
   map<string, string, less<string> >::iterator p = m_hPasswordExpiry.find(strUSER_ID);
   if (p != m_hPasswordExpiry.end())
      return (*p).second;
   string strTSTAMP_PASSWORD;
   reusable::Query hQuery;
   hQuery.setQualifier("QUALIFY","AS_USER_HISTORY");
   hQuery.bind("AS_USER_HISTORY","TSTAMP_PASSWORD",Column::STRING,&strTSTAMP_PASSWORD);
   hQuery.setBasicPredicate("AS_USER_HISTORY","USER_ID","=",strUSER_ID.c_str());
   hQuery.setOrderByClause("TSTAMP_PASSWORD ASC");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == true
      && pSelectStatement->getRows() > 0)
   {
      Date hDate(strTSTAMP_PASSWORD.c_str());
      if (CommonHeaderSegment::instance()->getSource() == "E")
         hDate += m_siAP_PWD_EXPIRE_DAYS;
      else
         hDate += m_siPWD_EXPIRE_DAYS;
      string strPaswordExpiry(hDate.asString("%Y%m%d"));
      return strPaswordExpiry;
   }
   return ""; //unavailable
  //## end command::Security::getPasswordExpiration%48BEDF06000C.body
}

char Security::getUserRole (segment::PersistentSegment* pSegment)
{
  //## begin command::Security::getUserRole%5602BC86009D.body preserve=yes
   return '*';
  //## end command::Security::getUserRole%5602BC86009D.body
}

Security* Security::instance ()
{
  //## begin command::Security::instance%490B6EE8013E.body preserve=yes
   if (!m_pInstance)
   {
#ifndef MVS
      new DNSecurity();
#else
      new Security();
#endif
      m_pInstance->initialize();
   }
   return m_pInstance;
  //## end command::Security::instance%490B6EE8013E.body
}

int Security::keyXchgRequest (const string& strKeyId)
{
  //## begin command::Security::keyXchgRequest%490B701803B2.body preserve=yes
   string strKey;
   if(strKeyId.empty())
   { //default request for userid/password key
      if (m_strKey.length() == 0)
      {
         string strContextData;
         auto_ptr<CommonContext> pCommonContext(new CommonContext(Application::instance()->image(), Application::instance()->name()));
         if (!pCommonContext->get("HASH", strContextData))
         {
            Trace::put("Security::keyXchgRequest - Context::get(HASH) failed.", true);
            Database::instance()->rollback();
            return 5;
         }
         while (true)
         {
            generateKey();
            if (m_strHash != strContextData)
            {
               if (!pCommonContext->put("HASH", m_strHash.c_str()))
               {
                  Trace::put("Security::keyXchgRequest - Context::put(HASH) failed.", true);
                  Database::instance()->rollback();
                  return 5;
               }
               Database::instance()->commit();
               break;
            }
         }
      }
      strKey.assign(m_strKey); 
   }
   else
   {  //request for a data key
      Key* pKey = 0;
      if(strKeyId.length() == 6 && memcmp(strKeyId.data(),"DK",2) == 0)
         pKey = KeyRing::instance()->getKey(strKeyId);
      else if(strKeyId == "DEFAULT")
         pKey = KeyRing::instance()->getKey(KeyRing::instance()->getDefaultAESDataKey());
      if(pKey)
         strKey = pKey->getKey();
      else
      {
         string strErr("Security::keyXchgRequest - ");
         strErr.append("Requested key id ");
         strErr.append(strKeyId.c_str());
         strErr.append(" does not exist");
         Trace::put(strErr.c_str(),strErr.length(),true);
         return 4;
      }
   }
   //read in client's PEM formatted public key
   usersegment::KeyExchangeSegment* pKeyExchangeSegment = usersegment::KeyExchangeSegment::instance();
   int iLen = atoi(pKeyExchangeSegment->getKeyLength().c_str());
   char psPublicKey[4096];
   string strKeyExchangeSegment(pKeyExchangeSegment->getKey().data(),iLen);
   Trace::putHex(strKeyExchangeSegment.data(),strKeyExchangeSegment.length());
   size_t pos = strKeyExchangeSegment.find('.');
   while(pos != string::npos)
   {
      strKeyExchangeSegment.replace(pos,1,1,'\n');
      pos = strKeyExchangeSegment.find('.');
   }
   memcpy_s(psPublicKey,sizeof(psPublicKey),strKeyExchangeSegment.data(),strKeyExchangeSegment.length());
   Trace::putHex(psPublicKey,strKeyExchangeSegment.length());
   BIO *in = SecurityWrapper::BIO_new_mem_buf(psPublicKey,4096);
   if (!in)
   {
      string strErr("Security::keyXchgRequest - ");
      strErr.append("Unable to create BIO input object");
      Trace::put(strErr.c_str(),strErr.length(),true);
      return 1;
   }
   EVP_PKEY *pkey = NULL;
   pkey=SecurityWrapper::PEM_read_bio_PUBKEY(in, NULL, NULL, NULL);
   (void)SecurityWrapper::BIO_free_all(in);
   if (!pkey)
   {
      string strErr("Security::keyXchgRequest - ");
      strErr.append("Unable to interpret PEM formmatted public key");
      Trace::put(strErr.c_str(),strErr.length(),true);
      return 2;
   }
   RSA* rsa = NULL;
   rsa = SecurityWrapper::EVP_PKEY_get1_RSA(pkey);
   SecurityWrapper::EVP_PKEY_free(pkey);
   if (!rsa)
   {
      string strErr("Security::keyXchgRequest - ");
      strErr.append("Unable to reconstruct rsa public key");
      Trace::put(strErr.c_str(),strErr.length(),true);
      return 3;
   }
   SecurityWrapper::RSA_up_ref(rsa);

   //use client's public key to encrypt the requested key
   unsigned char pad = RSA_PKCS1_OAEP_PADDING;
   unsigned char szEncryptedKey[1024];
   iLen = SecurityWrapper::RSA_public_encrypt(strKey.length(),(const unsigned char*)strKey.data(),
      szEncryptedKey,rsa,pad);
   //encode encrypted key as hexidecimal (printable) characters
   string strEncryptedKey;
   char szTemp[9];
   for(int i = 0; i < iLen; i++)
   {
      unsigned char c = szEncryptedKey[i];
      strEncryptedKey.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%02x",c));
   }
   pKeyExchangeSegment->setKey(strEncryptedKey);
   pKeyExchangeSegment->setKeyLength(string(szTemp,snprintf(szTemp,sizeof(szTemp),"%08d",strEncryptedKey.length())));
   return 0;
  //## end command::Security::keyXchgRequest%490B701803B2.body
}

string Security::processLogon (const string& strUserid, const string& strPassword, const string& strNewPassword, bool bReLogon)
{
  //## begin command::Security::processLogon%48BECF4D03D0.body preserve=yes
   string strUSER_ID = strUserid;
   transform (strUSER_ID.begin(),strUSER_ID.end(), strUSER_ID.begin(), ::toupper);
   initialize(); //reread AS_LOGON_CNTL record in case something changed.
   char cStatus = getAccountStatus(strUSER_ID);
   if (cStatus == 'S')
      return "SE200,account suspended"; //STS_USER_ID_REVOKED
   if (cStatus == 'R' && strNewPassword.length() == 0)
      return "SE144"; //STS_NEW_PASSWORD_REQUIRED
   else if (cStatus == 'E')
      return "SE114"; //STS_UNKNOWN_USER_ID
   Date hDate(Date::today());
   string strPasswordExpiration = getPasswordExpiration(strUSER_ID);
   if (strPasswordExpiration.length() > 0 &&
      strPasswordExpiration < hDate.asString("%Y%m%d000000") &&
      strNewPassword.length() == 0)
   {
      updateUserStatus(strUSER_ID,'R');
      Database::instance()->commit();
      return "SE144"; //STS_NEW_PASSWORD_REQUIRED
   }
   int iRC = authenticateUser(strUSER_ID,strPassword);
   if (iRC == 0 && strNewPassword.length() > 0)
      iRC = changePassword(strUSER_ID,strNewPassword);
   switch( iRC )
   {
      case 0:
         //updateLastLogon(strUSER_ID);        //moved to UserSession::logonResponse
         Database::instance()->commit();
         if (bReLogon)
            return "SE018";                   //18 user already logged on
         return "";
      case STS_DATABASE_FAILURE:             //15
         Database::instance()->rollback();
         return "SE200";
      case STS_PASSWORD_MISMATCH:            //22
         incrementFailCount(strUSER_ID);
         Database::instance()->commit();
         return "SE119";
      case STS_INVALID_NEW_PASSWORD:         //23
         return "SE137";
      case STS_INVALID_PASSWORD_HISTORY:     //111
         return "SE137";
//    case STS_LOGON_DENIED:                 //10
//       return "SE119";
//    case STS_UNKNOWN_USER_ID:              //20
//       return "SE114";
//    case STS_UNKNOWN_TERMINAL:             //21
//       return "SE115";
//    case STS_NEW_PASSWORD_REQUIRED:        //24
//       return "SE144";
//    case STS_ACCESS_SECURITY_UNAVAILABLE:  //25
//       return "SE200";
//    case STS_USER_ID_REVOKED:              //40
//       return "SE135";
   }
   return "";
  //## end command::Security::processLogon%48BECF4D03D0.body
}

void Security::retrievePwdHistory (const string& strUserid)
{
  //## begin command::Security::retrievePwdHistory%48C154450064.body preserve=yes
   string strUSER_ID = strUserid;
   transform (strUSER_ID.begin(),strUSER_ID.end(), strUSER_ID.begin(), ::toupper);
   m_hPwdHistory.erase(m_hPwdHistory.begin(),m_hPwdHistory.end());
   reusable::Query hQuery;
   hQuery.attach(this);
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.setQualifier("QUALIFY","AS_USER_HISTORY");
   hQuery.bind("AS_USER_HISTORY","NEW_PASSWORD",Column::STRING,&m_strNEW_PASSWORD);
   hQuery.bind("AS_USER_HISTORY","DIGEST_METHOD",Column::CHAR,&m_cHistoryDIGEST_METHOD);
   hQuery.bind("AS_USER_HISTORY","TSTAMP_PASSWORD", Column::STRING, &m_strTSTAMP_PASSWORD);
   hQuery.bind("AS_USER_HISTORY","SALT",Column::STRING,&m_strSALT);
   hQuery.setBasicPredicate("AS_USER_HISTORY","USER_ID","=",strUSER_ID.c_str());
   hQuery.setOrderByClause("TSTAMP_PASSWORD DESC");
   if (!pSelectStatement->execute(hQuery))
      Database::instance()->rollback();
  //## end command::Security::retrievePwdHistory%48C154450064.body
}

void Security::hash (const string& strInput, string& strOutput)
{
  //## begin command::Security::hash%4E0B4DEA036C.body preserve=yes
   generateDigest('A',strInput,strOutput);
  //## end command::Security::hash%4E0B4DEA036C.body
}

void Security::update (Subject* pSubject)
{
  //## begin command::Security::update%48C155A1024F.body preserve=yes
   if (pSubject == Database::instance()
      && Database::instance()->state() == Database::CONNECTED)
   {
      initialize();
      return;
   }
   else if (pSubject == MidnightAlarm::instance())
   {
      m_hPasswordExpiry.erase(m_hPasswordExpiry.begin(), m_hPasswordExpiry.end());
      return;
   }

   string strHistory(&m_cHistoryDIGEST_METHOD,1);
   strHistory.append(" ");
   strHistory.append(m_strNEW_PASSWORD);
   strHistory.append(" ");
   strHistory.append(m_strTSTAMP_PASSWORD,0,8);
   if (m_cHistoryDIGEST_METHOD == 'A')
   {
      strHistory.append(" ");
      strHistory.append(m_strSALT);
   }
   m_hPwdHistory.push_back(strHistory);
  //## end command::Security::update%48C155A1024F.body
}

void Security::updateLastLogon (const string& strUserid)
{
  //## begin command::Security::updateLastLogon%48C14BCC000B.body preserve=yes
   if (m_hPasswordExpiry.find(strUserid) != m_hPasswordExpiry.end())
      return;
   string strUSER_ID = strUserid;
   transform (strUSER_ID.begin(),strUSER_ID.end(), strUSER_ID.begin(), ::toupper);
   reusable::Table hTable("AS_USER_LOGON");
   hTable.setQualifier("QUALIFY");
   hTable.set("USER_ID",strUSER_ID.c_str(),false,true);
   hTable.set("USER_STATUS","A");
   hTable.set("FAILED_LOGON_COUNT",0);
   hTable.set("LAST_LOGON_DATE",Clock::instance()->getYYYYMMDDHHMMSS(true).substr(0,8));
   auto_ptr<reusable::Statement> pUpdateStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("UpdateStatement"));
   if (pUpdateStatement->execute(hTable) == false)
      Database::instance()->rollback();
  //## end command::Security::updateLastLogon%48C14BCC000B.body
}

void Security::updateUserStatus (const string& strUserid, const char& cStatus)
{
  //## begin command::Security::updateUserStatus%48C96BF20088.body preserve=yes
   string strUSER_ID = strUserid;
   transform (strUSER_ID.begin(),strUSER_ID.end(), strUSER_ID.begin(), ::toupper);
   reusable::Table hTable("AS_USER_LOGON");
   hTable.setQualifier("QUALIFY");
   hTable.set("USER_ID",strUSER_ID.c_str(),false,true);
   hTable.set("USER_STATUS","R");
   auto_ptr<reusable::Statement> pUpdateStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("UpdateStatement"));
   if (pUpdateStatement->execute(hTable) == false)
      Database::instance()->rollback();
  //## end command::Security::updateUserStatus%48C96BF20088.body
}

int Security::validatePassword (const string& strUserid, const string& strPassword)
{
  //## begin command::Security::validatePassword%48BEC5980098.body preserve=yes
   return STS_ACCESS_SECURITY_UNAVAILABLE;
  //## end command::Security::validatePassword%48BEC5980098.body
}

int Security::validatePwdComplexity (const string& strNewPassword)
{
  //## begin command::Security::validatePwdComplexity%48BED0F20399.body preserve=yes
   return STS_ACCESS_SECURITY_UNAVAILABLE;
  //## end command::Security::validatePwdComplexity%48BED0F20399.body
}

int Security::validatePwdHistory (const string& strNewPassword)
{
  //## begin command::Security::validatePwdHistory%48C15F61003B.body preserve=yes
   vector<string>::iterator p;
   int iCount = 1;
   for(p = m_hPwdHistory.begin(); p != m_hPwdHistory.end(); p++)
   {
      vector<string> hTokens;
      Buffer::parse((*p)," ",hTokens);
      if (hTokens.size() < 2)
         continue;
      if (hTokens.size() > 2
         && hTokens[2] == Clock::instance()->getYYYYMMDDHHMMSS(true).substr(0,8))
         return STS_INVALID_PASSWORD_HISTORY;
      char cDIGEST_METHOD = hTokens[0][0];
      string strHistoryPassword = hTokens[1];
      string strSalt;
      if (hTokens.size() == 4)
         strSalt = hTokens[3];
      string strEncryptedPassword;
      generateDigest(cDIGEST_METHOD,strNewPassword,strEncryptedPassword,strSalt);
      if (strHistoryPassword.length() >= 32)
         CodeTable::nibbleToByte(strEncryptedPassword.data(),strEncryptedPassword.length(),strEncryptedPassword);
      if (strEncryptedPassword == strHistoryPassword)
      {
         m_sPwdRulesErrors[PWD_HISTORY_ERR] = 'Y';
         return STS_INVALID_NEW_PASSWORD;
      }
      if (iCount++ >= m_siPWD_HISTORY_COUNT)
         break;
   }
   return 0;
  //## end command::Security::validatePwdHistory%48C15F61003B.body
}

// Additional Declarations
  //## begin command::Security%48BEBB9F0137.declarations preserve=yes
string Security::updateLastLogon2 (const string& strUserid)
{
   string strUSER_ID = strUserid;
   transform (strUSER_ID.begin(),strUSER_ID.end(), strUSER_ID.begin(), ::toupper);
   string strLastLogonDate = getLastLogonDate(strUserid);
   reusable::Table hTable("AS_USER_LOGON");
   hTable.setQualifier("QUALIFY");
   hTable.set("USER_ID",strUSER_ID.c_str(),false,true);
   hTable.set("USER_STATUS","A");
   hTable.set("FAILED_LOGON_COUNT",0);
   hTable.set("LAST_LOGON_DATE",Clock::instance()->getYYYYMMDDHHMMSS(true).substr(0,8));
   auto_ptr<reusable::Statement> pUpdateStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("UpdateStatement"));
   if (pUpdateStatement->execute(hTable) == false)
      Database::instance()->rollback();
   if (strLastLogonDate.length() == 0)
      strLastLogonDate = Clock::instance()->getYYYYMMDDHHMMSS().substr(0,8);
   return strLastLogonDate;
}
  //## end command::Security%48BEBB9F0137.declarations
} // namespace command

//## begin module%48BEBBEB0244.epilog preserve=yes
//## end module%48BEBBEB0244.epilog
