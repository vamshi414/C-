//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%40B3A90A00BB.cm preserve=no
//## end module%40B3A90A00BB.cm

//## begin module%40B3A90A00BB.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%40B3A90A00BB.cp

//## Module: CXOSBC15%40B3A90A00BB; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC15.hpp

#ifndef CXOSBC15_h
#define CXOSBC15_h 1

//## begin module%40B3A90A00BB.additionalIncludes preserve=no
//## end module%40B3A90A00BB.additionalIncludes

//## begin module%40B3A90A00BB.includes preserve=yes
#include "CXODRU61.hpp"
#include <map>
#include <set>
#include <vector>
//## end module%40B3A90A00BB.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Row;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class XMLText;

} // namespace command

//## begin module%40B3A90A00BB.declarations preserve=no
//## end module%40B3A90A00BB.declarations

//## begin module%40B3A90A00BB.additionalDeclarations preserve=yes
//## end module%40B3A90A00BB.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::XMLDocument%40B3A82E0280.preface preserve=yes
//## end command::XMLDocument%40B3A82E0280.preface

//## Class: XMLDocument%40B3A82E0280
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40B4F89603D8;IF::FlatFile { -> F}
//## Uses: <unnamed>%40B4F8A301B5;monitor::UseCase { -> F}
//## Uses: <unnamed>%441B0E6902DE;reusable::Row { -> F}
//## Uses: <unnamed>%5225EE0D02E6;IF::Trace { -> F}

class DllExport XMLDocument : public reusable::Object  //## Inherits: <unnamed>%40B4EBE60138
{
  //## begin command::XMLDocument%40B3A82E0280.initialDeclarations preserve=yes
  //## end command::XMLDocument%40B3A82E0280.initialDeclarations

  public:
    //## Constructors (generated)
      XMLDocument();

    //## Constructors (specified)
      //## Operation: XMLDocument%40B4F1400271
      XMLDocument (const char* pszInFile, const char* pszTemplate, reusable::Row* pRow, command::XMLText* pXMLText);

    //## Destructor (generated)
      virtual ~XMLDocument();


    //## Other Operations (specified)
      //## Operation: add%40B4E792004E
      bool add (const char* pszElement);

      //## Operation: add%5C58636D01EF
      bool add (const char* pszLocation, const char* pszElement);

      //## Operation: add%52BC66640069
      bool add (set<reusable::string>::const_iterator first, set<reusable::string>::const_iterator last);

      //## Operation: dump%5225EE3200EB
      void dump ();

      //## Operation: getMemberMap%5DD4237F00C2
      map<reusable::string,vector<reusable::string>,less<reusable::string> >* getMemberMap ()
      {
        //## begin command::XMLDocument::getMemberMap%5DD4237F00C2.body preserve=yes
         return &m_hMember;
        //## end command::XMLDocument::getMemberMap%5DD4237F00C2.body
      }

      //## Operation: recordCount%443EBF6A00A2
      int recordCount ();

      //## Operation: reset%56E1D3100067
      void reset ();

      //## Operation: revert%52FD35120325
      void revert ();

      //## Operation: save%52FD35070282
      void save ();

      //## Operation: setTagValue%5225EE5A0165
      void setTagValue (const char* pszTagName, const char* pszValue);

      //## Operation: size%4EAF0AC90299
      short size (const char* pszElement);

      //## Operation: size%4EAF0AF80328
      short size (const char* pszElement, const reusable::string& strTag);

      //## Operation: write%5DD48F1300C3
      void write (const char* pszElement);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: File%40B5FF52030D
      const reusable::Deque<reusable::string>& getFile () const
      {
        //## begin command::XMLDocument::getFile%40B5FF52030D.get preserve=no
        return m_hFile;
        //## end command::XMLDocument::getFile%40B5FF52030D.get
      }


      //## Attribute: Full%5DD421C30137
      const bool getFull () const
      {
        //## begin command::XMLDocument::getFull%5DD421C30137.get preserve=no
        return m_bFull;
        //## end command::XMLDocument::getFull%5DD421C30137.get
      }


      //## Attribute: MaximumSize%52BC640A01EE
      const int getMaximumSize () const
      {
        //## begin command::XMLDocument::getMaximumSize%52BC640A01EE.get preserve=no
        return m_iMaximumSize;
        //## end command::XMLDocument::getMaximumSize%52BC640A01EE.get
      }

      void setMaximumSize (int value)
      {
        //## begin command::XMLDocument::setMaximumSize%52BC640A01EE.set preserve=no
        m_iMaximumSize = value;
        //## end command::XMLDocument::setMaximumSize%52BC640A01EE.set
      }


      //## Attribute: Save%52FD34FA033C
      const reusable::Deque<reusable::string>& getSave () const
      {
        //## begin command::XMLDocument::getSave%52FD34FA033C.get preserve=no
        return m_hSave;
        //## end command::XMLDocument::getSave%52FD34FA033C.get
      }


      //## Attribute: SuppressEmptyTags%64B54EA60195
      void setSuppressEmptyTags (bool value)
      {
        //## begin command::XMLDocument::setSuppressEmptyTags%64B54EA60195.set preserve=no
        m_bSuppressEmptyTags = value;
        //## end command::XMLDocument::setSuppressEmptyTags%64B54EA60195.set
      }


    // Additional Public Declarations
      //## begin command::XMLDocument%40B3A82E0280.public preserve=yes
      //## end command::XMLDocument%40B3A82E0280.public

  protected:
    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%40B4FE1601C5
      //## Role: XMLDocument::<m_pXMLText>%40B4FE17001F
      //## begin command::XMLDocument::<m_pXMLText>%40B4FE17001F.role preserve=no  public: command::XMLText { -> RFHgN}
      XMLText *m_pXMLText;
      //## end command::XMLDocument::<m_pXMLText>%40B4FE17001F.role

    // Additional Protected Declarations
      //## begin command::XMLDocument%40B3A82E0280.protected preserve=yes
      //## end command::XMLDocument%40B3A82E0280.protected

  private:

    //## Other Operations (specified)
      //## Operation: findInclude%4418859000D0
      reusable::Deque<reusable::string>::Iterator findInclude (reusable::Deque<reusable::string>& hElement);

      //## Operation: isEndTag%44183EDC03C3
      bool isEndTag (reusable::string& strXML, const char* pszElement);

    // Additional Private Declarations
      //## begin command::XMLDocument%40B3A82E0280.private preserve=yes
      //## end command::XMLDocument%40B3A82E0280.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::XMLDocument::File%40B5FF52030D.attr preserve=no  public: reusable::Deque<reusable::string> {V} 
      reusable::Deque<reusable::string> m_hFile;
      //## end command::XMLDocument::File%40B5FF52030D.attr

      //## begin command::XMLDocument::Full%5DD421C30137.attr preserve=no  public: bool {V} false
      bool m_bFull;
      //## end command::XMLDocument::Full%5DD421C30137.attr

      //## begin command::XMLDocument::MaximumSize%52BC640A01EE.attr preserve=no  public: int {V} 0
      int m_iMaximumSize;
      //## end command::XMLDocument::MaximumSize%52BC640A01EE.attr

      //## Attribute: Member%40B5FF77037A
      //## begin command::XMLDocument::Member%40B5FF77037A.attr preserve=no  private: map<reusable::string,vector<reusable::string>,less<reusable::string> > {V} 
      map<reusable::string,vector<reusable::string>,less<reusable::string> > m_hMember;
      //## end command::XMLDocument::Member%40B5FF77037A.attr

      //## begin command::XMLDocument::Save%52FD34FA033C.attr preserve=no  public: reusable::Deque<reusable::string> {V} 
      reusable::Deque<reusable::string> m_hSave;
      //## end command::XMLDocument::Save%52FD34FA033C.attr

      //## Attribute: Size%52C2F7AE029B
      //## begin command::XMLDocument::Size%52C2F7AE029B.attr preserve=no  public: int {V} 0
      int m_iSize;
      //## end command::XMLDocument::Size%52C2F7AE029B.attr

      //## begin command::XMLDocument::SuppressEmptyTags%64B54EA60195.attr preserve=no  public: bool {V} true
      bool m_bSuppressEmptyTags;
      //## end command::XMLDocument::SuppressEmptyTags%64B54EA60195.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%441B139401A0
      //## Role: XMLDocument::<m_pRow>%441B13960076
      //## begin command::XMLDocument::<m_pRow>%441B13960076.role preserve=no  public: reusable::Row { -> RFHgN}
      reusable::Row *m_pRow;
      //## end command::XMLDocument::<m_pRow>%441B13960076.role

    // Additional Implementation Declarations
      //## begin command::XMLDocument%40B3A82E0280.implementation preserve=yes
      //## end command::XMLDocument%40B3A82E0280.implementation

};

//## begin command::XMLDocument%40B3A82E0280.postscript preserve=yes
//## end command::XMLDocument%40B3A82E0280.postscript

} // namespace command

//## begin module%40B3A90A00BB.epilog preserve=yes
using namespace command;
//## end module%40B3A90A00BB.epilog


#endif
