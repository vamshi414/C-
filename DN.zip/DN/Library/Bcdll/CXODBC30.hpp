//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4ADF0C3F0186.cm preserve=no
//	$Date:   Mar 16 2010 11:47:22  $ $Author:   D96312  $
//	$Revision:   1.2  $
//## end module%4ADF0C3F0186.cm

//## begin module%4ADF0C3F0186.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4ADF0C3F0186.cp

//## Module: CXOSBC30%4ADF0C3F0186; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC30.hpp

#ifndef CXOSBC30_h
#define CXOSBC30_h 1

//## begin module%4ADF0C3F0186.additionalIncludes preserve=no
//## end module%4ADF0C3F0186.additionalIncludes

//## begin module%4ADF0C3F0186.includes preserve=yes
#include <map>
//## end module%4ADF0C3F0186.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Event;

} // namespace command

//## begin module%4ADF0C3F0186.declarations preserve=no
//## end module%4ADF0C3F0186.declarations

//## begin module%4ADF0C3F0186.additionalDeclarations preserve=yes
//## end module%4ADF0C3F0186.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::EventFactory%4ADF0695031C.preface preserve=yes
//## end command::EventFactory%4ADF0695031C.preface

//## Class: EventFactory%4ADF0695031C
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4ADF0775033C;Event { -> F}

class DllExport EventFactory : public reusable::Object  //## Inherits: <unnamed>%4ADF06C40242
{
  //## begin command::EventFactory%4ADF0695031C.initialDeclarations preserve=yes
  //## end command::EventFactory%4ADF0695031C.initialDeclarations

  public:
    //## Constructors (generated)
      EventFactory();

    //## Destructor (generated)
      virtual ~EventFactory();


    //## Other Operations (specified)
      //## Operation: create%4ADF06D0035B
      virtual command::Event* create (const char* pszFileName, const char* pszNetwork, const char* pszClass, const char* pszValue = 0) = 0;

      //## Operation: instance%4ADF06D40157
      static EventFactory* instance ();

    // Additional Public Declarations
      //## begin command::EventFactory%4ADF0695031C.public preserve=yes
      //## end command::EventFactory%4ADF0695031C.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Classes%4ADF0727032C
      //## begin command::EventFactory::Classes%4ADF0727032C.attr preserve=no  public: map<string,int,less<string> > {V} 
      map<string,int,less<string> > m_hClasses;
      //## end command::EventFactory::Classes%4ADF0727032C.attr

    // Additional Protected Declarations
      //## begin command::EventFactory%4ADF0695031C.protected preserve=yes
      //## end command::EventFactory%4ADF0695031C.protected

  private:
    // Additional Private Declarations
      //## begin command::EventFactory%4ADF0695031C.private preserve=yes
      //## end command::EventFactory%4ADF0695031C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%4ADF0725007D
      //## begin command::EventFactory::Instance%4ADF0725007D.attr preserve=no  private: static EventFactory {R} 0
      static EventFactory *m_pInstance;
      //## end command::EventFactory::Instance%4ADF0725007D.attr

    // Additional Implementation Declarations
      //## begin command::EventFactory%4ADF0695031C.implementation preserve=yes
      //## end command::EventFactory%4ADF0695031C.implementation

};

//## begin command::EventFactory%4ADF0695031C.postscript preserve=yes
//## end command::EventFactory%4ADF0695031C.postscript

} // namespace command

//## begin module%4ADF0C3F0186.epilog preserve=yes
//## end module%4ADF0C3F0186.epilog


#endif
