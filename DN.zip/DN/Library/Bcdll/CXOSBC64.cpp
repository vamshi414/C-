//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64BF7BD402D7.cm preserve=no
//## end module%64BF7BD402D7.cm

//## begin module%64BF7BD402D7.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64BF7BD402D7.cp

//## Module: CXOSBC64%64BF7BD402D7; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC64.cpp

//## begin module%64BF7BD402D7.additionalIncludes preserve=no
//## end module%64BF7BD402D7.additionalIncludes

//## begin module%64BF7BD402D7.includes preserve=yes
#ifdef _WIN32
//#include "windows.h"
#include "xercesc\sax\AttributeList.hpp"
#else
#include "xercesc/sax/AttributeList.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
//## end module%64BF7BD402D7.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSBC63_h
#include "CXODBC63.hpp"
#endif
#ifndef CXOSBC64_h
#include "CXODBC64.hpp"
#endif


//## begin module%64BF7BD402D7.declarations preserve=no
//## end module%64BF7BD402D7.declarations

//## begin module%64BF7BD402D7.additionalDeclarations preserve=yes
//## end module%64BF7BD402D7.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::IndustryDataHandler 

IndustryDataHandler::IndustryDataHandler()
  //## begin IndustryDataHandler::IndustryDataHandler%64BF7E6E0066_const.hasinit preserve=no
      : m_iIndex(0),
        m_pIndustryData(0),
        m_pXMLItem(0)
  //## end IndustryDataHandler::IndustryDataHandler%64BF7E6E0066_const.hasinit
  //## begin IndustryDataHandler::IndustryDataHandler%64BF7E6E0066_const.initialization preserve=yes
#ifdef _UNIX
   , m_hXMLFormatter("UTF-8", &m_hMemBufFormatTarget)
#else
   , m_hXMLFormatter("LATIN1", &m_hMemBufFormatTarget)
#endif
  //## end IndustryDataHandler::IndustryDataHandler%64BF7E6E0066_const.initialization
{
  //## begin command::IndustryDataHandler::IndustryDataHandler%64BF7E6E0066_const.body preserve=yes
  //## end command::IndustryDataHandler::IndustryDataHandler%64BF7E6E0066_const.body
}

IndustryDataHandler::IndustryDataHandler (XMLItem* pXMLItem, IndustryData* pIndustryData)
  //## begin command::IndustryDataHandler::IndustryDataHandler%64BF84CE00AB.hasinit preserve=no
      : m_iIndex(0),
        m_pIndustryData(0),
        m_pXMLItem(0)
  //## end command::IndustryDataHandler::IndustryDataHandler%64BF84CE00AB.hasinit
  //## begin command::IndustryDataHandler::IndustryDataHandler%64BF84CE00AB.initialization preserve=yes
#ifdef _UNIX
   , m_hXMLFormatter("UTF-8", &m_hMemBufFormatTarget)
#else
   , m_hXMLFormatter("LATIN1", &m_hMemBufFormatTarget)
#endif
  //## end command::IndustryDataHandler::IndustryDataHandler%64BF84CE00AB.initialization
{
  //## begin command::IndustryDataHandler::IndustryDataHandler%64BF84CE00AB.body preserve=yes
   m_pIndustryData = pIndustryData;
   m_pXMLItem = pXMLItem;
  //## end command::IndustryDataHandler::IndustryDataHandler%64BF84CE00AB.body
}


IndustryDataHandler::~IndustryDataHandler()
{
  //## begin command::IndustryDataHandler::~IndustryDataHandler%64BF7E6E0066_dest.body preserve=yes
  //## end command::IndustryDataHandler::~IndustryDataHandler%64BF7E6E0066_dest.body
}



//## Other Operations (implementation)
void IndustryDataHandler::characters (const XMLCh* const chars, const XMLSIZE length)
{
  //## begin command::IndustryDataHandler::characters%64BF9B9B00E1.body preserve=yes
   getToken("XMLHandler::characters ", chars, length);
   m_strCharacters += m_strToken;
  //## end command::IndustryDataHandler::characters%64BF9B9B00E1.body
}

void IndustryDataHandler::endElement (const XMLCh* const name)
{
  //## begin command::IndustryDataHandler::endElement%64BF842C0306.body preserve=yes
   m_strData = getCharacters();
   string strElement(m_hElement.back().c_str()); // need null terminated char* ... Solaris sometimes returns trailing x'00' character
   Trace::put("BC64 endElement");
   Trace::put(strElement.c_str());
   string strKey;
   if (m_hElement.size() == 3)
   {
      strKey = m_hElement[m_hElement.size() - 2];
      strKey.append(":",1);
      strKey += strElement;
   }
   else if (m_hElement.size() == 4)
   {
       strKey = m_hElement[m_hElement.size() - 3];
       strKey.append(":", 1);
       strKey = m_hElement[m_hElement.size() - 2];
       strKey.append(":", 1);
       strKey += strElement;
   }
   else
   if (m_hElement.size() == 5)
   {
      strKey = m_hElement[m_hElement.size() - 4];
      strKey.append(":",1);
      strKey += m_hElement[m_hElement.size() - 2];
      strKey.append(":",1);
      strKey += strElement;
      char szKey[PERCENTD];
      strKey.append(szKey,snprintf(szKey,sizeof(szKey),"%02d",m_iIndex));
   }
   if (m_pXMLItem
      && strKey.empty() == false)
      m_pXMLItem->add(strKey.c_str(),m_strData);
   if (m_hElement.size() == 4)
      m_iIndex++;
   m_hElement.pop_back();
   if (m_hElement.size() <= 2)
      m_iIndex = 0;
  //## end command::IndustryDataHandler::endElement%64BF842C0306.body
}

void IndustryDataHandler::error (const SAXParseException& exc)
{
  //## begin command::IndustryDataHandler::error%64BF9D74016A.body preserve=yes
   IF::Trace::put("XMLHandler::error");
   char szBuffer[64];
   Trace::put(szBuffer, snprintf(szBuffer, sizeof(szBuffer), "DNHandlerBase::error line %d column %d", (int)exc.getLineNumber(), (int)exc.getColumnNumber()));
  //## end command::IndustryDataHandler::error%64BF9D74016A.body
}

void IndustryDataHandler::fatalError (const SAXParseException& exc)
{
  //## begin command::IndustryDataHandler::fatalError%64BF9DAC03DB.body preserve=yes
   IF::Trace::put("XMLHandler::fatalError");
   char szBuffer[64];
   Trace::put(szBuffer, snprintf(szBuffer, sizeof(szBuffer), "DNHandlerBase::fatalError line %d column %d", (int)exc.getLineNumber(), (int)exc.getColumnNumber()));
   getToken("XMLHandler::fatalError ", exc.getMessage(), XMLString::stringLen(exc.getMessage()));
   m_hElement.erase(m_hElement.begin(), m_hElement.end());
  //## end command::IndustryDataHandler::fatalError%64BF9DAC03DB.body
}

void IndustryDataHandler::getToken (const char* pszFunction, const XMLCh* const psBuffer, size_t lLength)
{
  //## begin command::IndustryDataHandler::getToken%64BF99B0035B.body preserve=yes
   if (psBuffer)
   {
      m_hXMLFormatter.formatBuf(psBuffer, lLength);
      char* p = new char[m_hMemBufFormatTarget.getLen()];
      Object::memcpy_s(p, m_hMemBufFormatTarget.getLen(), (char*)m_hMemBufFormatTarget.getRawBuffer(), m_hMemBufFormatTarget.getLen());
#ifdef MVS
      CodeTable::translate(p, m_hMemBufFormatTarget.getLen(), CodeTable::CX_ASCII_TO_EBCDIC);
#endif
      int m = m_hMemBufFormatTarget.getLen();
      m_strToken.assign(p, m);
      size_t pos = m_strToken.find('\0');
      if (pos != string::npos)
         m_strToken.erase(pos);
      m_hMemBufFormatTarget.reset();
      delete[] p;
   }
   else
      m_strToken.erase();
   string strBuffer(pszFunction);
   strBuffer += m_strToken;
   Trace::put(strBuffer.data(), strBuffer.length());
  //## end command::IndustryDataHandler::getToken%64BF99B0035B.body
}

void IndustryDataHandler::startElement (const XMLCh* const name, AttributeList& attributes)
{
  //## begin command::IndustryDataHandler::startElement%64BF8476033B.body preserve=yes
   getToken("XMLHandler::startElement ", name, XMLString::stringLen(name));
   m_hElement.push_back(m_strToken);
   m_strCharacters.erase();
   for (int i = 0; i < attributes.getLength(); ++i)
   {
      string strName(m_hElement.back());
      strName.append("_", 1);
      int j = strName.length();
      const XMLCh* pXMLCh = attributes.getName(i);
      getToken("XMLHandler::startElement ", pXMLCh, XMLString::stringLen(pXMLCh));
      strName += m_strToken;
      pXMLCh = attributes.getValue(i);
      getToken("XMLHandler::startElement ", pXMLCh, XMLString::stringLen(pXMLCh));
      string strKey;
      if (m_hElement.size() == 3)
      {
         strKey = m_hElement[m_hElement.size() - 2];
         strKey.append(":", 1);
         strKey += strName;
      }
      else
      if (m_hElement.size() == 5)
      {
         strKey = m_hElement[m_hElement.size() - 4];
         strKey.append(":", 1);
         strKey += m_hElement[m_hElement.size() - 2];
         strKey.append(":", 1);
         strKey += strName;
         char szKey[PERCENTD];
         strKey.append(szKey, snprintf(szKey, sizeof(szKey), "%02d", m_iIndex));
      }
      if (m_pXMLItem
         && strKey.empty() == false)
         m_pXMLItem->add(strKey.c_str(), m_strToken);
   }
  //## end command::IndustryDataHandler::startElement%64BF8476033B.body
}

// Additional Declarations
  //## begin command::IndustryDataHandler%64BF7E6E0066.declarations preserve=yes
  //## end command::IndustryDataHandler%64BF7E6E0066.declarations

} // namespace command

//## begin module%64BF7BD402D7.epilog preserve=yes
//## end module%64BF7BD402D7.epilog
