//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%444F20F00059.cm preserve=no
//## end module%444F20F00059.cm

//## begin module%444F20F00059.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%444F20F00059.cp

//## Module: CXOSBC21%444F20F00059; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC21.hpp

#ifndef CXOSBC21_h
#define CXOSBC21_h 1

//## begin module%444F20F00059.additionalIncludes preserve=no
//## end module%444F20F00059.additionalIncludes

//## begin module%444F20F00059.includes preserve=yes
#include <map>
#include <deque>
//## end module%444F20F00059.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
class Memory;
class Extract;
class Console;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class ExportFile;

} // namespace database

//## begin module%444F20F00059.declarations preserve=no
//## end module%444F20F00059.declarations

//## begin module%444F20F00059.additionalDeclarations preserve=yes
//## end module%444F20F00059.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::Report%444F1DBF03C9.preface preserve=yes
//## end command::Report%444F1DBF03C9.preface

//## Class: Report%444F1DBF03C9
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%444F46BF0153;IF::FlatFile { -> F}
//## Uses: <unnamed>%444F47ED03BB;IF::Console { -> F}
//## Uses: <unnamed>%45B5C56501EC;database::ExportFile { -> F}
//## Uses: <unnamed>%5D30D1B90356;IF::Extract { -> F}

class DllExport Report : public reusable::Object  //## Inherits: <unnamed>%444F1E1701C7
{
  //## begin command::Report%444F1DBF03C9.initialDeclarations preserve=yes
  //## end command::Report%444F1DBF03C9.initialDeclarations

  public:
    //## Constructors (generated)
      Report();

    //## Constructors (specified)
      //## Operation: Report%5C48C41C0142
      Report (int iRecordSize);

    //## Destructor (generated)
      virtual ~Report();


    //## Other Operations (specified)
      //## Operation: addCommas%5D2CC25E03B6
      void addCommas (char* pszBuffer, size_t iBufferSize);

      //## Operation: addCRDR%5D2CC2910299
      void addCRDR (char* pszBuffer, size_t iBufferSize);

      //## Operation: addSegment %444F1E6102AF
      void addSegment (const char cSegment, segment::Segment* pSegment);

      //## Operation: evaluate%5D2CC3670353
      bool evaluate (reusable::string& strColumnName, string& strValue, string& strFormat, string& strSymbol);

      //## Operation: finish%5D3710BF03E5
      void finish ();

      //## Operation: getLast%6349927D03A4
      const bool getLast (int ilines, vector<string>& hLines)
      {
        //## begin command::Report::getLast%6349927D03A4.body preserve=yes
         hLines.erase(hLines.begin(), hLines.end());
         deque<string>::const_reverse_iterator p;
         for (p = m_hFile.rbegin(); p != m_hFile.rend(), ilines > 0; p++, ilines--)
            hLines.push_back((*p));
         return hLines.size() > 0;
        //## end command::Report::getLast%6349927D03A4.body
      }

      //## Operation: getRecordCount%44696355033D
      int getRecordCount ();

      //## Operation: lines%5D30CA650278
      int lines (const reusable::string& strRecordType)
      {
        //## begin command::Report::lines%5D30CA650278.body preserve=yes
         map<string, int>::iterator q;
         if ((q = m_hSection.find(strRecordType)) != m_hSection.end())
            return (*q).second;
         return 0;
        //## end command::Report::lines%5D30CA650278.body
      }

      //## Operation: managePaging%5D30C8E6034F
      bool managePaging (const reusable::string& strRecordType);

      //## Operation: readTemplate%444F1EE80103
      bool readTemplate (const string& strTemplate);

      //## Operation: report%444F1EBB036C
      bool report (const reusable::string& strRecordType);

      //## Operation: report2%5D30C8E303A8
      bool report2 (const reusable::string& strRecordType);

      //## Operation: substitute%444F1F1A02A2
      void substitute (string&  strText);

      //## Operation: write%444F1F7400DE
      bool write (IF::FlatFile& hFile);

      //## Operation: write%45B5C5740330
      bool write (database::ExportFile& hFile, int iSEQ_NO = -1);

      //## Operation: writeBlankLines%5D30CA9702DE
      void writeBlankLines (int iLines);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: BlankZeroAmts%5F08B51900E8
      void setBlankZeroAmts (const bool& value)
      {
        //## begin command::Report::setBlankZeroAmts%5F08B51900E8.set preserve=no
        m_bBlankZeroAmts = value;
        //## end command::Report::setBlankZeroAmts%5F08B51900E8.set
      }


      //## Attribute: CurrentHeading%5F1092BF00C9
      const reusable::string& getCurrentHeading () const
      {
        //## begin command::Report::getCurrentHeading%5F1092BF00C9.get preserve=no
        return m_strCurrentHeading;
        //## end command::Report::getCurrentHeading%5F1092BF00C9.get
      }

      void setCurrentHeading (const reusable::string& value)
      {
        //## begin command::Report::setCurrentHeading%5F1092BF00C9.set preserve=no
        m_strCurrentHeading = value;
        //## end command::Report::setCurrentHeading%5F1092BF00C9.set
      }


      //## Attribute: CurrentLineCount%5D30C8A80177
      const int& getCurrentLineCount () const
      {
        //## begin command::Report::getCurrentLineCount%5D30C8A80177.get preserve=no
        return m_iCurrentLineCount;
        //## end command::Report::getCurrentLineCount%5D30C8A80177.get
      }


      //## Attribute: PageSize%5D30C87F03B2
      void setPageSize (const int& value)
      {
        //## begin command::Report::setPageSize%5D30C87F03B2.set preserve=no
        m_iPageSize = value;
        //## end command::Report::setPageSize%5D30C87F03B2.set
      }


      //## Attribute: Page%5D35C68D0372
      void setPage (const int& value)
      {
        //## begin command::Report::setPage%5D35C68D0372.set preserve=no
        m_iPage = value;
        //## end command::Report::setPage%5D35C68D0372.set
      }


      //## Attribute: Template%444F235A004B
      const  vector<string>& getTemplate () const
      {
        //## begin command::Report::getTemplate%444F235A004B.get preserve=no
        return m_hTemplate;
        //## end command::Report::getTemplate%444F235A004B.get
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::Command_CAT::<unnamed>%5D71582D0102
      //## Role: Report::<m_pMemory>%5D71582D02FD
      IF::Memory * getMemory ()
      {
        //## begin command::Report::getMemory%5D71582D02FD.get preserve=no
        return m_pMemory;
        //## end command::Report::getMemory%5D71582D02FD.get
      }


    // Additional Public Declarations
      //## begin command::Report%444F1DBF03C9.public preserve=yes
      //## end command::Report%444F1DBF03C9.public

  protected:
    // Additional Protected Declarations
      //## begin command::Report%444F1DBF03C9.protected preserve=yes
      //## end command::Report%444F1DBF03C9.protected

  private:
    // Additional Private Declarations
      //## begin command::Report%444F1DBF03C9.private preserve=yes
      //## end command::Report%444F1DBF03C9.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::Report::BlankZeroAmts%5F08B51900E8.attr preserve=no  public: bool {U} true
      bool m_bBlankZeroAmts;
      //## end command::Report::BlankZeroAmts%5F08B51900E8.attr

      //## begin command::Report::CurrentHeading%5F1092BF00C9.attr preserve=no  public: reusable::string {U} "FH"
      reusable::string m_strCurrentHeading;
      //## end command::Report::CurrentHeading%5F1092BF00C9.attr

      //## begin command::Report::CurrentLineCount%5D30C8A80177.attr preserve=no  public: int {U} 0
      int m_iCurrentLineCount;
      //## end command::Report::CurrentLineCount%5D30C8A80177.attr

      //## Attribute: File%444F229D022C
      //## begin command::Report::File%444F229D022C.attr preserve=no  private: deque<string> {U} 
      deque<string> m_hFile;
      //## end command::Report::File%444F229D022C.attr

      //## Attribute: Offset%6351BBD50173
      //## begin command::Report::Offset%6351BBD50173.attr preserve=no  private: int {U} 3
      int m_iOffset;
      //## end command::Report::Offset%6351BBD50173.attr

      //## begin command::Report::PageSize%5D30C87F03B2.attr preserve=no  public: int {U} 0
      int m_iPageSize;
      //## end command::Report::PageSize%5D30C87F03B2.attr

      //## begin command::Report::Page%5D35C68D0372.attr preserve=no  public: int {V} 0
      int m_iPage;
      //## end command::Report::Page%5D35C68D0372.attr

      //## Attribute: RecordSize%5C48C37D01F8
      //## begin command::Report::RecordSize%5C48C37D01F8.attr preserve=no  private: int {V} 97
      int m_iRecordSize;
      //## end command::Report::RecordSize%5C48C37D01F8.attr

      //## Attribute: Section%5D30C99800B0
      //## begin command::Report::Section%5D30C99800B0.attr preserve=no  private: map<string,int,less<string> > {U} 
      map<string,int,less<string> > m_hSection;
      //## end command::Report::Section%5D30C99800B0.attr

      //## Attribute: Segment%444F231B032D
      //## begin command::Report::Segment%444F231B032D.attr preserve=no  private: map<char, segment::Segment *, less<char> > {U} 
      map<char, segment::Segment *, less<char> > m_hSegment;
      //## end command::Report::Segment%444F231B032D.attr

      //## Attribute: Symbol%444F22EF0160
      //## begin command::Report::Symbol%444F22EF0160.attr preserve=no  private: map<string,pair<string,string>,less<string> > {U} 
      map<string,pair<string,string>,less<string> > m_hSymbol;
      //## end command::Report::Symbol%444F22EF0160.attr

      //## begin command::Report::Template%444F235A004B.attr preserve=no  public:  vector<string> {U} 
       vector<string> m_hTemplate;
      //## end command::Report::Template%444F235A004B.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%444F431203E6
      //## Role: Report::<m_pSegment>%444F4314007C
      //## begin command::Report::<m_pSegment>%444F4314007C.role preserve=no  public: segment::Segment { -> RHgN}
      segment::Segment *m_pSegment;
      //## end command::Report::<m_pSegment>%444F4314007C.role

      //## Association: Connex Library::Command_CAT::<unnamed>%5D71582D0102
      //## begin command::Report::<m_pMemory>%5D71582D02FD.role preserve=no  public: IF::Memory { -> RFHgN}
      IF::Memory *m_pMemory;
      //## end command::Report::<m_pMemory>%5D71582D02FD.role

    // Additional Implementation Declarations
      //## begin command::Report%444F1DBF03C9.implementation preserve=yes
      deque<pair<int, size_t> > m_hPANOffset;
      //## end command::Report%444F1DBF03C9.implementation

};

//## begin command::Report%444F1DBF03C9.postscript preserve=yes
//## end command::Report%444F1DBF03C9.postscript

} // namespace command

//## begin module%444F20F00059.epilog preserve=yes
//## end module%444F20F00059.epilog


#endif
