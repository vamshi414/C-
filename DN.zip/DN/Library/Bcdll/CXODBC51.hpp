//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5888C56801DC.cm preserve=no
//## end module%5888C56801DC.cm

//## begin module%5888C56801DC.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5888C56801DC.cp

//## Module: CXOSBC51%5888C56801DC; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC51.hpp

#ifndef CXOSBC51_h
#define CXOSBC51_h 1

//## begin module%5888C56801DC.additionalIncludes preserve=no
//## end module%5888C56801DC.additionalIncludes

//## begin module%5888C56801DC.includes preserve=yes
//## end module%5888C56801DC.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSRU20_h
#include "CXODRU20.hpp"
#endif
#ifndef CXOSBC16_h
#include "CXODBC16.hpp"
#endif
#ifndef CXOSBC15_h
#include "CXODBC15.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
class Query;
class Transaction;
class Table;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%5888C56801DC.declarations preserve=no
//## end module%5888C56801DC.declarations

//## begin module%5888C56801DC.additionalDeclarations preserve=yes
//## end module%5888C56801DC.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::APIExport%5888C4F40151.preface preserve=yes
//## end command::APIExport%5888C4F40151.preface

//## Class: APIExport%5888C4F40151
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5888C98A029E;reusable::Query { -> F}
//## Uses: <unnamed>%5888C99700F9;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5888C9A5024D;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5888C9CC01D5;reusable::Table { -> F}
//## Uses: <unnamed>%5888C9DA024D;reusable::Statement { -> F}
//## Uses: <unnamed>%5888E1FE02F7;reusable::Transaction { -> F}

class DllExport APIExport : public reusable::Observer  //## Inherits: <unnamed>%5888C52F022C
{
  //## begin command::APIExport%5888C4F40151.initialDeclarations preserve=yes
  //## end command::APIExport%5888C4F40151.initialDeclarations

  public:
    //## Constructors (generated)
      APIExport();

    //## Destructor (generated)
      virtual ~APIExport();


    //## Other Operations (specified)
      //## Operation: insert%5888C79103C9
      virtual int insert (string& strREQ_TYPE, const string& strXMLRequest, const bool& bExportDocs);

      //## Operation: instance%588B329B0202
      static APIExport* instance ();

      //## Operation: update%5888C67F03B4
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: API_TYPE%5888C53B0236
      const string& getAPI_TYPE () const
      {
        //## begin command::APIExport::getAPI_TYPE%5888C53B0236.get preserve=no
        return m_strAPI_TYPE;
        //## end command::APIExport::getAPI_TYPE%5888C53B0236.get
      }

      void setAPI_TYPE (const string& value)
      {
        //## begin command::APIExport::setAPI_TYPE%5888C53B0236.set preserve=no
        m_strAPI_TYPE = value;
        //## end command::APIExport::setAPI_TYPE%5888C53B0236.set
      }


      //## Attribute: CASE_ID%5888C5C0020D
      const int& getCASE_ID () const
      {
        //## begin command::APIExport::getCASE_ID%5888C5C0020D.get preserve=no
        return m_lCASE_ID;
        //## end command::APIExport::getCASE_ID%5888C5C0020D.get
      }

      void setCASE_ID (const int& value)
      {
        //## begin command::APIExport::setCASE_ID%5888C5C0020D.set preserve=no
        m_lCASE_ID = value;
        //## end command::APIExport::setCASE_ID%5888C5C0020D.set
      }


      //## Attribute: QUEUE_ID%5888DC6402F2
      static const int& getQUEUE_ID ();

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%5888C84D01BF
      //## Role: APIExport::<m_hRow>%5888C84E0007
      //## begin command::APIExport::<m_hRow>%5888C84E0007.role preserve=no  public: reusable::Row { -> VHgAN}
      reusable::Row m_hRow;
      //## end command::APIExport::<m_hRow>%5888C84E0007.role

      //## Association: Connex Library::Command_CAT::<unnamed>%5888C8A80060
      //## Role: APIExport::<m_hXMLText>%5888C8A8033A
      //## begin command::APIExport::<m_hXMLText>%5888C8A8033A.role preserve=no  public: command::XMLText { -> VHgAN}
      XMLText m_hXMLText;
      //## end command::APIExport::<m_hXMLText>%5888C8A8033A.role

      //## Association: Connex Library::Command_CAT::<unnamed>%5888C9190307
      //## Role: APIExport::<m_pXMLDocument>%5888C91A0181
      //## begin command::APIExport::<m_pXMLDocument>%5888C91A0181.role preserve=no  public: command::XMLDocument { -> RHgAN}
      XMLDocument *m_pXMLDocument;
      //## end command::APIExport::<m_pXMLDocument>%5888C91A0181.role

    // Additional Public Declarations
      //## begin command::APIExport%5888C4F40151.public preserve=yes
      //## end command::APIExport%5888C4F40151.public

  protected:
    // Additional Protected Declarations
      //## begin command::APIExport%5888C4F40151.protected preserve=yes
      //## end command::APIExport%5888C4F40151.protected

  private:
    // Additional Private Declarations
      //## begin command::APIExport%5888C4F40151.private preserve=yes
      //## end command::APIExport%5888C4F40151.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::APIExport::API_TYPE%5888C53B0236.attr preserve=no  public: string {U} 
      string m_strAPI_TYPE;
      //## end command::APIExport::API_TYPE%5888C53B0236.attr

      //## begin command::APIExport::CASE_ID%5888C5C0020D.attr preserve=no  public: int {U} 
      int m_lCASE_ID;
      //## end command::APIExport::CASE_ID%5888C5C0020D.attr

      //## Attribute: Instance%5888C64A0274
      //## begin command::APIExport::Instance%5888C64A0274.attr preserve=no  private: static APIExport* {V} 0
      static APIExport* m_pInstance;
      //## end command::APIExport::Instance%5888C64A0274.attr

      //## begin command::APIExport::QUEUE_ID%5888DC6402F2.attr preserve=no  public: static int {U} 0
      static int m_lQUEUE_ID;
      //## end command::APIExport::QUEUE_ID%5888DC6402F2.attr

      //## Attribute: XMLTags%5888C93C00FE
      //## begin command::APIExport::XMLTags%5888C93C00FE.attr preserve=no  private: string {U} 
      string m_strXMLTags;
      //## end command::APIExport::XMLTags%5888C93C00FE.attr

    // Additional Implementation Declarations
      //## begin command::APIExport%5888C4F40151.implementation preserve=yes
      //## end command::APIExport%5888C4F40151.implementation

};

//## begin command::APIExport%5888C4F40151.postscript preserve=yes
//## end command::APIExport%5888C4F40151.postscript

} // namespace command

//## begin module%5888C56801DC.epilog preserve=yes
//## end module%5888C56801DC.epilog


#endif
