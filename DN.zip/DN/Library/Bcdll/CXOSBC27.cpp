//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%48BEBDBC022F.cm preserve=no
//	$Date:   Jul 10 2019 08:22:16  $ $Author:   e5558747  $ $Revision:   1.23  $
//## end module%48BEBDBC022F.cm

//## begin module%48BEBDBC022F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%48BEBDBC022F.cp

//## Module: CXOSBC27%48BEBDBC022F; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.8A.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC27.cpp

//## begin module%48BEBDBC022F.additionalIncludes preserve=no
//## end module%48BEBDBC022F.additionalIncludes

//## begin module%48BEBDBC022F.includes preserve=yes
#include <algorithm>
#include "CXODDB23.hpp"
#include "CXODTM04.hpp"
#include "CXODIF03.hpp"
#include "CXODIF04.hpp"
#include "CXODPS01.hpp"
//## end module%48BEBDBC022F.includes

#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSBC27_h
#include "CXODBC27.hpp"
#endif


//## begin module%48BEBDBC022F.declarations preserve=no
//## end module%48BEBDBC022F.declarations

//## begin module%48BEBDBC022F.additionalDeclarations preserve=yes
#define STS_DUPLICATE_RECORD 35
//## end module%48BEBDBC022F.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::DNSecurity 

DNSecurity::DNSecurity()
  //## begin DNSecurity::DNSecurity%48BEBD7F0259_const.hasinit preserve=no
  //## end DNSecurity::DNSecurity%48BEBD7F0259_const.hasinit
  //## begin DNSecurity::DNSecurity%48BEBD7F0259_const.initialization preserve=yes
  //## end DNSecurity::DNSecurity%48BEBD7F0259_const.initialization
{
  //## begin command::DNSecurity::DNSecurity%48BEBD7F0259_const.body preserve=yes
  //## end command::DNSecurity::DNSecurity%48BEBD7F0259_const.body
}


DNSecurity::~DNSecurity()
{
  //## begin command::DNSecurity::~DNSecurity%48BEBD7F0259_dest.body preserve=yes
  //## end command::DNSecurity::~DNSecurity%48BEBD7F0259_dest.body
}



//## Other Operations (implementation)
int DNSecurity::authenticateUser (const string& strUserid, const string& strPassword)
{
  //## begin command::DNSecurity::authenticateUser%48BED16400A4.body preserve=yes
#ifdef MVS
   if (Security::instance()->getSecurityType() != "OPEN")
      return Security::authenticateUser(strUserid,strPassword);
#endif
   int iReturnCode = 0;
   if ((iReturnCode = validatePassword(strUserid, strPassword)) == 0 &&
      CommonHeaderSegment::instance()->getSource() == "E" && 
      getAP_PWD_EXPIRE_DAYS() > 0)
   {  //password expiration is being enforced
      string strPasswordExpirationDate = getPasswordExpiration(strUserid);
      if (strPasswordExpirationDate.empty())
      {  //if empty then was never initialized
         initializePasswordHistory(strUserid);
         strPasswordExpirationDate = getPasswordExpiration(strUserid);
      }
      if (strPasswordExpirationDate > Clock::instance()->getYYYYMMDDHHMMSS().substr(0, 8)
         && getAccountStatus(strUserid) == 'A')
      {
         updateLastLogon(strUserid);
         m_hPasswordExpiry.insert(map<string, string, less<string> >::value_type(strUserid, strPasswordExpirationDate));
         Database::instance()->commit();
      }
      else
         return 1;
   }
   return iReturnCode;
  //## end command::DNSecurity::authenticateUser%48BED16400A4.body
}

void DNSecurity::checkUsers ()
{
  //## begin command::DNSecurity::checkUsers%48EB794B03CF.body preserve=yes
   bool bSaveTraceOption = Trace::getEnable();
   Trace::setEnable(false); //turn off tracing during password conversion
   reusable::Query hQuery;
   hQuery.setIndex(1);
   hQuery.attach(this);
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.setQualifier("QUALIFY","AS_USER_LOGON");
   hQuery.bind("AS_USER_LOGON","USER_ID",Column::STRING,&m_strUSER_ID);
   hQuery.bind("AS_USER_LOGON","USER_PASSWORD",Column::STRING,&m_strUSER_PASSWORD);
   hQuery.setBasicPredicate("AS_USER_LOGON","DIGEST_METHOD","IS NULL");
   hQuery.setBasicPredicate("AS_USER_LOGON","DIGEST_METHOD","NOT IN",
      "('M','S','A')",false,false);
   pSelectStatement->execute(hQuery);
   Database::instance()->commit();
   Trace::setEnable(bSaveTraceOption);
  //## end command::DNSecurity::checkUsers%48EB794B03CF.body
}

int DNSecurity::convertUser (const string& strUserid, const string& strPassword)
{
  //## begin command::DNSecurity::convertUser%48C037B1006E.body preserve=yes
   string strUSER_PWD_DIGEST;
   string strSALT;
   generateSalt(strSALT);
   generateDigest(getDIGEST_METHOD(),strPassword,strUSER_PWD_DIGEST,strSALT);
   CodeTable::nibbleToByte(strUSER_PWD_DIGEST.data(),strUSER_PWD_DIGEST.length(),strUSER_PWD_DIGEST);
   reusable::Table hTable("AS_USER_LOGON");
   char cDIGEST_METHOD = getDIGEST_METHOD();
   string strDIGEST_METHOD(&cDIGEST_METHOD,1);
   hTable.setQualifier("QUALIFY");
   hTable.set("USER_ID",strUserid.c_str(),false,true);
   hTable.set("USER_PASSWORD",string(""));
   hTable.set("USER_PWD_DIGEST",strUSER_PWD_DIGEST);
   hTable.set("SALT",strSALT);
   hTable.set("DIGEST_METHOD",strDIGEST_METHOD);
   hTable.set("USER_STATUS","A");
   auto_ptr<reusable::Statement> pUpdateStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("UpdateStatement"));
   if (pUpdateStatement->execute(hTable) == false)
   {
      Database::instance()->rollback();
      return STS_DATABASE_FAILURE;
   }
   Database::instance()->commit();
   return initializePasswordHistory(strUserid);
  //## end command::DNSecurity::convertUser%48C037B1006E.body
}

char DNSecurity::getUserRole (segment::PersistentSegment* pSegment)
{
  //## begin command::DNSecurity::getUserRole%5602BB210280.body preserve=yes
   char cUserRole = 'N';
   CXString hValue;
   string strData;
   Query q;
   q.setDistinct(true);
   q.setQualifier("QUALIFY", "AS_USER_PROFILE");
   q.setQualifier("QUALIFY", "AS_ENTITY_ROLE");
   q.setQualifier("QUALIFY", "AS_ROLE_RELATION");
   q.join("AS_USER_PROFILE", "INNER", "AS_ENTITY_ROLE", "ENTITY_ID");
   q.join("AS_ENTITY_ROLE", "INNER", "AS_ROLE_RELATION", "ROLE_ID");
   q.bind("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", Column::STRING, 0);
   q.setBasicPredicate("AS_USER_PROFILE", "USER_ID", "=", CommonHeaderSegment::instance()->getUserID().c_str());
   q.setBasicPredicate("AS_USER_PROFILE", "CUST_ID", "=", CommonHeaderSegment::instance()->getCUST_ID().c_str());
   q.getSearchCondition().append(" AND ((");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "PROC_GRP_ID");
   pSegment->_field("PROC_GRP_ID_ACQ_B", hValue);
   strData.assign(hValue, hValue.length());
   q.setBasicPredicate("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", "=", strData.c_str());
   q.getSearchCondition().append(") OR (");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "PROC_ID_ACQ");
   pSegment->_field("PROC_ID_ACQ", hValue);
   strData.assign(hValue, hValue.length());
   q.setBasicPredicate("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", "=", strData.c_str());
   q.getSearchCondition().append(") OR (");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "PROC_ID_ACQ_B");
   pSegment->_field("PROC_ID_ACQ_B", hValue);
   strData.assign(hValue, hValue.length());
   q.setBasicPredicate("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", "=", strData.c_str());
   q.getSearchCondition().append(") OR (");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "INST_ID_RECON_ACQ");
   pSegment->_field("INST_ID_RECON_ACQ", hValue);
   strData.assign(hValue, hValue.length());
   q.setBasicPredicate("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", "=", strData.c_str());
   q.getSearchCondition().append(") OR (");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "INST_ID_RECN_ACQ_B");
   pSegment->_field("INST_ID_RECN_ACQ_B", hValue);
   strData.assign(hValue, hValue.length());
   q.setBasicPredicate("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", "=", strData.c_str());
   q.getSearchCondition().append(") OR (");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "RPT_LVL_ID_B");
   pSegment->_field("RPT_LVL_ID_B", hValue);
   strData.assign(hValue, hValue.length());
   q.setBasicPredicate("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", "=", strData.c_str());
   q.getSearchCondition().append(") OR (");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "NET_TERM_ID");
   pSegment->_field("NET_TERM_ID", hValue);
   strData.assign(hValue, hValue.length());
   q.setBasicPredicate("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", "=", strData.c_str());
   q.getSearchCondition().append(") OR (");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "*");
   q.getSearchCondition().append("))");
   auto_ptr<SelectStatement>pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(q))
      return cUserRole;
   if (pSelectStatement->getRows() > 0)
      cUserRole = 'A';
   //issuer
   q.reset();
   q.setDistinct(true);
   q.setQualifier("QUALIFY", "AS_USER_PROFILE");
   q.setQualifier("QUALIFY", "AS_ENTITY_ROLE");
   q.setQualifier("QUALIFY", "AS_ROLE_RELATION");
   q.join("AS_USER_PROFILE", "INNER", "AS_ENTITY_ROLE", "ENTITY_ID");
   q.join("AS_ENTITY_ROLE", "INNER", "AS_ROLE_RELATION", "ROLE_ID");
   q.bind("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", Column::STRING, 0);
   q.setBasicPredicate("AS_USER_PROFILE", "USER_ID", "=", CommonHeaderSegment::instance()->getUserID().c_str());
   q.setBasicPredicate("AS_USER_PROFILE", "CUST_ID", "=", CommonHeaderSegment::instance()->getCUST_ID().c_str());
   q.getSearchCondition().append(" AND ((");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "PROC_GRP_ID");
   pSegment->_field("PROC_GRP_ID_ISS_B", hValue);
   strData.assign(hValue, hValue.length());
   q.setBasicPredicate("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", "=", strData.c_str());
   q.getSearchCondition().append(") OR (");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "PROC_ID_ISS");
   pSegment->_field("PROC_ID_ISS", hValue);
   strData.assign(hValue, hValue.length());
   q.setBasicPredicate("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", "=", strData.c_str());
   q.getSearchCondition().append(") OR (");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "PROC_ID_ISS_B");
   pSegment->_field("PROC_ID_ISS_B", hValue);
   strData.assign(hValue, hValue.length());   
   q.setBasicPredicate("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", "=", strData.c_str());
   q.getSearchCondition().append(") OR (");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "INST_ID_RECON_ISS");
   pSegment->_field("INST_ID_RECON_ISS", hValue);
   strData.assign(hValue, hValue.length());
   q.setBasicPredicate("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", "=", strData.c_str());
   q.getSearchCondition().append(") OR (");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "INST_ID_RECN_ISS_B");
   pSegment->_field("INST_ID_RECN_ISS_B", hValue);
   strData.assign(hValue, hValue.length());
   q.setBasicPredicate("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", "=", strData.c_str());
   q.getSearchCondition().append(") OR (");
   q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "=", "*");
   q.getSearchCondition().append("))");
   if (!pSelectStatement->execute(q))
      return cUserRole;
   if (pSelectStatement->getRows() > 0)
      cUserRole = (cUserRole == 'A') ? '*' : 'I';

   if (cUserRole == '*')
   {
      string strTemp;
      if (Extract::instance()->getSpec("USERROLE", strTemp))
      {
         if (strTemp == "A" || strTemp == "I")
            cUserRole = strTemp[0];
      }
   }
   return cUserRole;
  //## end command::DNSecurity::getUserRole%5602BB210280.body
}

bool DNSecurity::hasWidgetId (const string& strUserid, const string& strWidgetId)
{
  //## begin command::DNSecurity::hasWidgetId%4EE6798501CD.body preserve=yes
   if(!getCONSOLE_SECURITY_ENABLED())
      return true;
   string strUSER_ID = strUserid;
   transform (strUSER_ID.begin(),strUSER_ID.end(), strUSER_ID.begin(), ::toupper);
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   int lCount = 0;
   Query hQuery;
   hQuery.bind("AS_WIDGET_RESTRICT","*",Column::LONG,&lCount,0,"COUNT");
   hQuery.join("AS_PROFILE_ENTRY","INNER","AS_USER_PROFILE","PROFILE_ID");
   hQuery.join("AS_WIDGET_RESTRICT","INNER","AS_PROFILE_ENTRY","PERMISSION_ID");
   hQuery.setQualifier("QUALIFY","AS_USER_PROFILE");
   hQuery.setQualifier("QUALIFY","AS_PROFILE_ENTRY");
   hQuery.setQualifier("QUALIFY","AS_WIDGET_RESTRICT");
   hQuery.setBasicPredicate("AS_USER_PROFILE","CUST_ID","=",strCUST_ID.c_str());
   hQuery.setBasicPredicate("AS_USER_PROFILE","USER_ID","=",strUSER_ID.c_str());
   hQuery.setBasicPredicate("AS_WIDGET_RESTRICT","WIDGET_ID","=",strWidgetId.c_str());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   if (lCount > 0)
      return true;
   return false;
  //## end command::DNSecurity::hasWidgetId%4EE6798501CD.body
}

int DNSecurity::initializePasswordHistory (const string& strUserid)
{
  //## begin command::DNSecurity::initializePasswordHistory%5B4F7BB203C0.body preserve=yes
   string strUSER_PWD_DIGEST;
   string strUSER_STATUS;
   string strUSER_PASSWORD;
   string strSALT;
   char cDIGEST_METHOD = ' ';
   reusable::Query hQuery;
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.setQualifier("QUALIFY", "AS_USER_LOGON");
   hQuery.bind("AS_USER_LOGON", "DIGEST_METHOD", Column::CHAR, &cDIGEST_METHOD);
   hQuery.bind("AS_USER_LOGON", "USER_PWD_DIGEST", Column::STRING, &strUSER_PWD_DIGEST);
   hQuery.bind("AS_USER_LOGON", "USER_STATUS", Column::STRING, &strUSER_STATUS);
   hQuery.bind("AS_USER_LOGON", "USER_PASSWORD", Column::STRING, &strUSER_PASSWORD);
   hQuery.bind("AS_USER_LOGON", "SALT", Column::STRING, &strSALT);
   hQuery.setBasicPredicate("AS_USER_LOGON", "USER_ID", "=", strUserid.c_str());
   if (!pSelectStatement->execute(hQuery) || pSelectStatement->getRows() == 0)
      return STS_DATABASE_FAILURE;
   Table hTable;
   hTable.setName("AS_USER_HISTORY");
   hTable.setQualifier("QUALIFY");
   hTable.set("USER_ID", strUserid.c_str(), false, true);
   string strTSTAMP_PASSWORD(Clock::instance()->getYYYYMMDDHHMMSS(true).data(), 14);
   strTSTAMP_PASSWORD.replace(8, 6, "000000");
   hTable.set("TSTAMP_PASSWORD", strTSTAMP_PASSWORD, false, true);
   hTable.set("NEW_PASSWORD", strUSER_PWD_DIGEST);
   hTable.set("DIGEST_METHOD", string(&cDIGEST_METHOD, 1));
   hTable.set("SALT", strSALT);
   auto_ptr<reusable::Statement> pInsertStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("InsertStatement"));
   if (!pInsertStatement->execute(hTable))
   {
      if (pInsertStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
      {
         Database::instance()->rollback();
         return STS_DATABASE_FAILURE;
      }
   }
   Database::instance()->commit();
   return 0;
  //## end command::DNSecurity::initializePasswordHistory%5B4F7BB203C0.body
}

Security* DNSecurity::instance ()
{
  //## begin command::DNSecurity::instance%490B6921039A.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new DNSecurity();
   return (Security*)m_pInstance;
  //## end command::DNSecurity::instance%490B6921039A.body
}

void DNSecurity::update (Subject* pSubject)
{
  //## begin command::DNSecurity::update%48BEC81B03B3.body preserve=yes
   if (pSubject == Database::instance() &&
       Database::instance()->state() == Database::CONNECTED)
   {
      Security::update(pSubject);
      if ((Application::instance()->name().length() > 2
      && Application::instance()->name().substr(0,3) == "CRQ"))
         checkUsers();
      return;
   }
   if(((Query*)pSubject)->getIndex() == 1)
   {
      if(m_strUSER_PASSWORD.length() > 8)
         Password::decrypt(m_strUSER_PASSWORD);
      convertUser(m_strUSER_ID,m_strUSER_PASSWORD);
   }
   else
      Security::update(pSubject);
  //## end command::DNSecurity::update%48BEC81B03B3.body
}

int DNSecurity::validatePassword (const string& strUserid, const string& strPassword)
{
  //## begin command::DNSecurity::validatePassword%48BED164009A.body preserve=yes
   //retrieve user's existing password and digest method from database
   if(strUserid.length() > 8)
      return STS_UNKNOWN_USER_ID;
   string strUSER_ID = strUserid;
   transform (strUSER_ID.begin(),strUSER_ID.end(), strUSER_ID.begin(), ::toupper);
   char cDIGEST_METHOD = 'D'; //default to old DN method
   string strUSER_PWD_DIGEST;
   string strUSER_STATUS;
   string strUSER_PASSWORD;
   string strSALT;
   reusable::Query hQuery;
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.setQualifier("QUALIFY","AS_USER_LOGON");
   hQuery.bind("AS_USER_LOGON","DIGEST_METHOD",Column::CHAR,&cDIGEST_METHOD);
   hQuery.bind("AS_USER_LOGON","USER_PWD_DIGEST",Column::STRING,&strUSER_PWD_DIGEST);
   hQuery.bind("AS_USER_LOGON","USER_STATUS",Column::STRING,&strUSER_STATUS);
   hQuery.bind("AS_USER_LOGON","USER_PASSWORD",Column::STRING,&strUSER_PASSWORD);
   hQuery.bind("AS_USER_LOGON","SALT",Column::STRING,&strSALT);
   hQuery.setBasicPredicate("AS_USER_LOGON","USER_ID","=",strUSER_ID.c_str());
   if (pSelectStatement->execute(hQuery) == true)
   {
      if (pSelectStatement->getRows() == 0)
         return STS_UNKNOWN_USER_ID;
   }
   else 
      return STS_ACCESS_SECURITY_UNAVAILABLE;
   if(cDIGEST_METHOD == 'D' && strUSER_PASSWORD.length() > 0)
   {
      //convert user password to new method of storing passwords
      if(strUSER_PASSWORD.length() > 8)
         Password::decrypt(strUSER_PASSWORD);
      int iRC = convertUser(strUSER_ID,strUSER_PASSWORD);
      if(iRC != 0)
         return iRC;
      return strPassword == strUSER_PASSWORD ? 0 : STS_PASSWORD_MISMATCH;
   }
   string strEncryptedPassword;
   if (Security::instance()->getSecurityType() == "OPEN" && strUSER_STATUS == "R")
   {
      CodeTable::translate((char*)strSALT.data(),strSALT.length(),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate((char*)strPassword.data(),strPassword.length(),CodeTable::CX_EBCDIC_TO_ASCII);
   }
   generateDigest(cDIGEST_METHOD,strPassword,strEncryptedPassword,strSALT);
   if(strUSER_PWD_DIGEST.length() >= 32)
      CodeTable::nibbleToByte(strEncryptedPassword.data(),strEncryptedPassword.length(),strEncryptedPassword);
   if(strEncryptedPassword != strUSER_PWD_DIGEST)
   {
      //convert password to upper case and try again in case user hasn't
      //changed password since conversion and client is now allowing
      //lower case entry.
      string strUpper(strPassword.data(),strPassword.length());
      transform (strUpper.begin(),strUpper.end(), strUpper.begin(), ::toupper);
      generateDigest(cDIGEST_METHOD,strUpper,strEncryptedPassword,strSALT);
      if(strUSER_PWD_DIGEST.length() >= 32)
         CodeTable::nibbleToByte(strEncryptedPassword.data(),strEncryptedPassword.length(),strEncryptedPassword);
      if(strEncryptedPassword != strUSER_PWD_DIGEST)
         return STS_PASSWORD_MISMATCH;
   }
   if(cDIGEST_METHOD != getDIGEST_METHOD())
      return convertUser(strUSER_ID,strPassword);
   return 0;
  //## end command::DNSecurity::validatePassword%48BED164009A.body
}

int DNSecurity::validatePwdComplexity (const string& strNewPassword)
{
  //## begin command::DNSecurity::validatePwdComplexity%48BED16400AA.body preserve=yes
   string strLowerCase("abcdefghijklmnopqrstuvwxyz");
   string strUpperCase("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
   string strDigit("0123456789");
   string strNotSpecial = strLowerCase + strUpperCase + strDigit;
   
   //reset all errors
   m_sPwdRulesErrors[PWD_UPPER_ERR] = 'N';  
   m_sPwdRulesErrors[PWD_LOWER_ERR] = 'N';  
   m_sPwdRulesErrors[PWD_DIGIT_ERR] = 'N';  
   m_sPwdRulesErrors[PWD_SPECIAL_ERR] = 'N'; 
   m_sPwdRulesErrors[PWD_REPEATING_ERR] = 'N'; 
   m_sPwdRulesErrors[PWD_MIN_LEN_ERR] = 'N';   
   m_sPwdRulesErrors[PWD_HISTORY_ERR] = 'N'; 
   if(strNewPassword.length() < getPWD_MIN_LENGTH()) //check min length
      m_sPwdRulesErrors[PWD_MIN_LEN_ERR] = 'Y';
   if(getREPEATING_CHAR_FLG())
   {
      for(int i = 0; i < strNewPassword.length()-1; i++)
      {
         if(strNewPassword.data()[i] == strNewPassword.data()[i+1])
         {
            m_sPwdRulesErrors[PWD_REPEATING_ERR] = 'Y';
            break;
         }
      }
   }
   if(getLOWER_CASE_REQ_FLG())
   {
      if(strNewPassword.find_first_of(strLowerCase) == string::npos)
      {
            m_sPwdRulesErrors[PWD_LOWER_ERR] = 'Y';
      }
   }
   if(getUPPER_CASE_REQ_FLG())
   {
      if(strNewPassword.find_first_of(strUpperCase) == string::npos)
      {
            m_sPwdRulesErrors[PWD_UPPER_ERR] = 'Y';
      }
   }
   if(getDIGIT_REQ_FLG())
   {
      if(strNewPassword.find_first_of(strDigit) == string::npos)
      {
            m_sPwdRulesErrors[PWD_DIGIT_ERR] = 'Y';
      }
   }
   if(getSPECIAL_REQ_FLG())
   {
      if(strNewPassword.find_first_not_of(strNotSpecial.c_str()) == string::npos)
      {
         m_sPwdRulesErrors[PWD_SPECIAL_ERR] = 'Y';
      }
   }
   string strSuccess(m_sPwdRulesErrors+7,7);
   if(strSuccess.find_first_of("Y") != string::npos)
      return STS_INVALID_NEW_PASSWORD;
   return 0;
  //## end command::DNSecurity::validatePwdComplexity%48BED16400AA.body
}

// Additional Declarations
  //## begin command::DNSecurity%48BEBD7F0259.declarations preserve=yes
  //## end command::DNSecurity%48BEBD7F0259.declarations

} // namespace command

//## begin module%48BEBDBC022F.epilog preserve=yes
//## end module%48BEBDBC022F.epilog
