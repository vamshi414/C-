//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5625E349030F.cm preserve=no
//	$Date:   Oct 09 2020 11:55:22  $ $Author:   e3028298  $
//	$Revision:   1.1  $
//## end module%5625E349030F.cm

//## begin module%5625E349030F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5625E349030F.cp

//## Module: CXOSBC46%5625E349030F; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: D:\Devel\V03.1A.R007\ConnexPlatform\Server\Library\Bcdll\CXODBC46.hpp

#ifndef CXOSBC46_h
#define CXOSBC46_h 1

//## begin module%5625E349030F.additionalIncludes preserve=no
//## end module%5625E349030F.additionalIncludes

//## begin module%5625E349030F.includes preserve=yes
#include<set>
//## end module%5625E349030F.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;

} // namespace reusable

//## begin module%5625E349030F.declarations preserve=no
//## end module%5625E349030F.declarations

//## begin module%5625E349030F.additionalDeclarations preserve=yes
//## end module%5625E349030F.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::CriteriaData%5625E23803D9.preface preserve=yes
//## end command::CriteriaData%5625E23803D9.preface

//## Class: CriteriaData%5625E23803D9
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5628AC0F02A2;reusable::Buffer { -> F}

class DllExport CriteriaData : public reusable::Object  //## Inherits: <unnamed>%5625E28F010E
{
  //## begin command::CriteriaData%5625E23803D9.initialDeclarations preserve=yes
  //## end command::CriteriaData%5625E23803D9.initialDeclarations

  public:
    //## Constructors (generated)
      CriteriaData();

      CriteriaData(const CriteriaData &right);

    //## Destructor (generated)
      virtual ~CriteriaData();


    //## Other Operations (specified)
      //## Operation: applyFunction%5F6CAF9100D4
      void applyFunction (string& strValue);

      //## Operation: clear%5628B41B02D7
      void clear ();

      //## Operation: compareValue%5628F8AC00D7
      bool compareValue (const string& strValue) const;

      //## Operation: setValue%5628A3EC03DC
      void setValue (const string& strValue);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Field%5625E3F302FC
      const string& getField () const
      {
        //## begin command::CriteriaData::getField%5625E3F302FC.get preserve=no
        return m_strField;
        //## end command::CriteriaData::getField%5625E3F302FC.get
      }

      void setField (const string& value)
      {
        //## begin command::CriteriaData::setField%5625E3F302FC.set preserve=no
        m_strField = value;
        //## end command::CriteriaData::setField%5625E3F302FC.set
      }


      //## Attribute: FunctionAttribute%5F6CAF0D03B5
      const string& getFunctionAttribute () const
      {
        //## begin command::CriteriaData::getFunctionAttribute%5F6CAF0D03B5.get preserve=no
        return m_strFunctionAttribute;
        //## end command::CriteriaData::getFunctionAttribute%5F6CAF0D03B5.get
      }

      void setFunctionAttribute (const string& value)
      {
        //## begin command::CriteriaData::setFunctionAttribute%5F6CAF0D03B5.set preserve=no
        m_strFunctionAttribute = value;
        //## end command::CriteriaData::setFunctionAttribute%5F6CAF0D03B5.set
      }


      //## Attribute: Operator%5625E41B01C3
      const string& getOperator () const
      {
        //## begin command::CriteriaData::getOperator%5625E41B01C3.get preserve=no
        return m_strOperator;
        //## end command::CriteriaData::getOperator%5625E41B01C3.get
      }

      void setOperator (const string& value)
      {
        //## begin command::CriteriaData::setOperator%5625E41B01C3.set preserve=no
        m_strOperator = value;
        //## end command::CriteriaData::setOperator%5625E41B01C3.set
      }


      //## Attribute: SubStringAttribute%5629F2D5023F
      const string& getSubStringAttribute () const
      {
        //## begin command::CriteriaData::getSubStringAttribute%5629F2D5023F.get preserve=no
        return m_strSubStringAttribute;
        //## end command::CriteriaData::getSubStringAttribute%5629F2D5023F.get
      }

      void setSubStringAttribute (const string& value)
      {
        //## begin command::CriteriaData::setSubStringAttribute%5629F2D5023F.set preserve=no
        m_strSubStringAttribute = value;
        //## end command::CriteriaData::setSubStringAttribute%5629F2D5023F.set
      }


      //## Attribute: Table%5625E2A601E6
      const string& getTable () const
      {
        //## begin command::CriteriaData::getTable%5625E2A601E6.get preserve=no
        return m_strTable;
        //## end command::CriteriaData::getTable%5625E2A601E6.get
      }

      void setTable (const string& value)
      {
        //## begin command::CriteriaData::setTable%5625E2A601E6.set preserve=no
        m_strTable = value;
        //## end command::CriteriaData::setTable%5625E2A601E6.set
      }


      //## Attribute: Tokens%5625E8D7030A
      const set<string>* getTokens () const
      {
        //## begin command::CriteriaData::getTokens%5625E8D7030A.get preserve=no
        return m_pTokens;
        //## end command::CriteriaData::getTokens%5625E8D7030A.get
      }


      //## Attribute: Value%5625E40400B0
      const string& getValue () const
      {
        //## begin command::CriteriaData::getValue%5625E40400B0.get preserve=no
        return m_strValue;
        //## end command::CriteriaData::getValue%5625E40400B0.get
      }


    // Additional Public Declarations
      //## begin command::CriteriaData%5625E23803D9.public preserve=yes
      //## end command::CriteriaData%5625E23803D9.public

  protected:
    // Additional Protected Declarations
      //## begin command::CriteriaData%5625E23803D9.protected preserve=yes
      //## end command::CriteriaData%5625E23803D9.protected

  private:
    // Additional Private Declarations
      //## begin command::CriteriaData%5625E23803D9.private preserve=yes
      //## end command::CriteriaData%5625E23803D9.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::CriteriaData::Field%5625E3F302FC.attr preserve=no  public: string {U} 
      string m_strField;
      //## end command::CriteriaData::Field%5625E3F302FC.attr

      //## begin command::CriteriaData::FunctionAttribute%5F6CAF0D03B5.attr preserve=no  public: string {U} 
      string m_strFunctionAttribute;
      //## end command::CriteriaData::FunctionAttribute%5F6CAF0D03B5.attr

      //## begin command::CriteriaData::Operator%5625E41B01C3.attr preserve=no  public: string {U} 
      string m_strOperator;
      //## end command::CriteriaData::Operator%5625E41B01C3.attr

      //## begin command::CriteriaData::SubStringAttribute%5629F2D5023F.attr preserve=no  public: string {U} 
      string m_strSubStringAttribute;
      //## end command::CriteriaData::SubStringAttribute%5629F2D5023F.attr

      //## begin command::CriteriaData::Table%5625E2A601E6.attr preserve=no  public: string {U} 
      string m_strTable;
      //## end command::CriteriaData::Table%5625E2A601E6.attr

      //## begin command::CriteriaData::Tokens%5625E8D7030A.attr preserve=no  public: set<string>* {U} 0
      set<string>* m_pTokens;
      //## end command::CriteriaData::Tokens%5625E8D7030A.attr

      //## begin command::CriteriaData::Value%5625E40400B0.attr preserve=no  public: string {U} 
      string m_strValue;
      //## end command::CriteriaData::Value%5625E40400B0.attr

    // Additional Implementation Declarations
      //## begin command::CriteriaData%5625E23803D9.implementation preserve=yes
      //## end command::CriteriaData%5625E23803D9.implementation
};

//## begin command::CriteriaData%5625E23803D9.postscript preserve=yes
//## end command::CriteriaData%5625E23803D9.postscript

} // namespace command

//## begin module%5625E349030F.epilog preserve=yes
//## end module%5625E349030F.epilog


#endif
