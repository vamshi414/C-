//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%660056EE0207.cm preserve=no
//## end module%660056EE0207.cm

//## begin module%660056EE0207.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%660056EE0207.cp

//## Module: CXOSBC66%660056EE0207; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC66.cpp

//## begin module%660056EE0207.additionalIncludes preserve=no
//## end module%660056EE0207.additionalIncludes

//## begin module%660056EE0207.includes preserve=yes
#include "CXODRU34.hpp"
#include "CXODRU47.hpp"
//## end module%660056EE0207.includes

#ifndef CXOSBC66_h
#include "CXODBC66.hpp"
#endif
//## begin module%660056EE0207.declarations preserve=no
//## end module%660056EE0207.declarations

//## begin module%660056EE0207.additionalDeclarations preserve=yes
//## end module%660056EE0207.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::TLVData 

//## begin command::TLVData::instance%660059D70249.attr preserve=no  private: static command::TLVData* {U} 0
command::TLVData* TLVData::m_pinstance = 0;
//## end command::TLVData::instance%660059D70249.attr

TLVData::TLVData()
  //## begin TLVData::TLVData%6600577900DA_const.hasinit preserve=no
  //## end TLVData::TLVData%6600577900DA_const.hasinit
  //## begin TLVData::TLVData%6600577900DA_const.initialization preserve=yes
  //## end TLVData::TLVData%6600577900DA_const.initialization
{
  //## begin command::TLVData::TLVData%6600577900DA_const.body preserve=yes
   memcpy(m_sID,"BC66",4);
  //## end command::TLVData::TLVData%6600577900DA_const.body
}


TLVData::~TLVData()
{
  //## begin command::TLVData::~TLVData%6600577900DA_dest.body preserve=yes
  //## end command::TLVData::~TLVData%6600577900DA_dest.body
}



//## Other Operations (implementation)
TLVData* TLVData::instance ()
{
  //## begin command::TLVData::instance%660057FD0264.body preserve=yes
   if (!m_pinstance)
      m_pinstance = new TLVData();
   return m_pinstance;
  //## end command::TLVData::instance%660057FD0264.body
}

bool TLVData::_field (const string& strTokenNo, const string& strDATA_BUFFER, string& strValue)
{
  //## begin command::TLVData::_field%660057C00129.body preserve=yes
   //strTokenNo format : [Token_id]~[sub_tag]~[sub_tag_level]~[sub_tag_sizeof_length]~[sub_tag_delim]
   int  iToken,iTokenLength;
   string strMainToken(strTokenNo);
   if (strValue.length())
      strValue.clear();
   vector<string> hSpec;
   int i = Buffer::parse(strTokenNo, "~", hSpec, 0, true);
   if (i > 0)
      strMainToken.assign(hSpec[0]);
   bool bReturn(false);
   if (!strDATA_BUFFER.empty())
   {
      hFinancialSeg24_TLV* pTLV = (hFinancialSeg24_TLV*) strDATA_BUFFER.data();
      int iSize = strDATA_BUFFER.length();
      while (iSize > 0)
      {
         iToken = atoi(string(pTLV->sToken,sizeof(pTLV->sToken)).c_str());
         iTokenLength = atoi(string(pTLV->sTokenLength,sizeof(pTLV->sTokenLength)).c_str());
         if (iToken == atoi(strMainToken.c_str()))
         {
            strValue.assign(pTLV->sTokenValue,iTokenLength);
            break;
         }
         iSize -= 8;
         iSize -= iTokenLength;
         pTLV = (hFinancialSeg24_TLV*)((char*)pTLV + iTokenLength + 8 );
      }
   }
   if (strValue.length())
   {
      if (i > 1)
      {
         string strSubTag(hSpec[1]);
         int iLevel(i > 2 && hSpec[2].length() ? atoi(hSpec[2].c_str()) : 1);
         int iSizeofLength(i > 3 && hSpec[3].length() ? atoi(hSpec[3].c_str()) : 2);
         string strSubTagDelim;
         if (i > 4 && hSpec[4].length())
            strSubTagDelim.assign(hSpec[4]);
         if (strSubTagDelim.length())
         {
            vector<string> hTokens;
            if (Buffer::parse(strValue, strSubTagDelim, hTokens) > 0)
            {
               for (int j = 0; j < hTokens.size(); j++)
               {
                  if (hTokens[j].length() > strSubTag.length() && memcmp(hTokens[j].data(), strSubTag.data(), strSubTag.length()) == 0)
                  {
                     strValue.assign(hTokens[j].data() + strSubTag.length(), hTokens[j].length() - strSubTag.length());
                     bReturn = true;
                     break;
                  }
               }
               if (!bReturn)
                  strValue.clear();
            }
         }
         else
         {
            map<string, string, less<string> > hTokenMap;
            Token::parse(strValue.length(), strValue, iLevel, hTokenMap, iSizeofLength);
            if (hTokenMap.find(strSubTag) != hTokenMap.end())
            {
               strValue.assign(hTokenMap[strSubTag]);
               bReturn = true;
            }
            else
               strValue.clear();
         }
      }
      else
         bReturn = true;
   }
   return bReturn;
  //## end command::TLVData::_field%660057C00129.body
}

// Additional Declarations
  //## begin command::TLVData%6600577900DA.declarations preserve=yes
  //## end command::TLVData%6600577900DA.declarations

} // namespace command

//## begin module%660056EE0207.epilog preserve=yes
//## end module%660056EE0207.epilog
