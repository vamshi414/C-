//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%660056F20030.cm preserve=no
//## end module%660056F20030.cm

//## begin module%660056F20030.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%660056F20030.cp

//## Module: CXOSBC66%660056F20030; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC66.hpp

#ifndef CXOSBC66_h
#define CXOSBC66_h 1

//## begin module%660056F20030.additionalIncludes preserve=no
//## end module%660056F20030.additionalIncludes

//## begin module%660056F20030.includes preserve=yes
//## end module%660056F20030.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%660056F20030.declarations preserve=no
//## end module%660056F20030.declarations

//## begin module%660056F20030.additionalDeclarations preserve=yes
//## end module%660056F20030.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::TLVData%6600577900DA.preface preserve=yes
struct hFinancialSeg24_TLV
{
   char sToken[4];
   char sTokenLength[4];
   char sTokenValue[3];
};
//## end command::TLVData%6600577900DA.preface

//## Class: TLVData%6600577900DA
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport TLVData : public reusable::Object  //## Inherits: <unnamed>%660057A20013
{
  //## begin command::TLVData%6600577900DA.initialDeclarations preserve=yes
  //## end command::TLVData%6600577900DA.initialDeclarations

  public:
    //## Constructors (generated)
      TLVData();

    //## Destructor (generated)
      virtual ~TLVData();


    //## Other Operations (specified)
      //## Operation: instance%660057FD0264
      static TLVData* instance ();

      //## Operation: _field%660057C00129
      virtual bool _field (const string& strTokenNo, const string& strDATA_BUFFER, string& strValue);

    // Additional Public Declarations
      //## begin command::TLVData%6600577900DA.public preserve=yes
      //## end command::TLVData%6600577900DA.public

  protected:
    // Additional Protected Declarations
      //## begin command::TLVData%6600577900DA.protected preserve=yes
      //## end command::TLVData%6600577900DA.protected

  private:
    // Additional Private Declarations
      //## begin command::TLVData%6600577900DA.private preserve=yes
      //## end command::TLVData%6600577900DA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: instance%660059D70249
      //## begin command::TLVData::instance%660059D70249.attr preserve=no  private: static TLVData* {U} 0
      static TLVData* m_pinstance;
      //## end command::TLVData::instance%660059D70249.attr

    // Additional Implementation Declarations
      //## begin command::TLVData%6600577900DA.implementation preserve=yes
      //## end command::TLVData%6600577900DA.implementation

};

//## begin command::TLVData%6600577900DA.postscript preserve=yes
//## end command::TLVData%6600577900DA.postscript

} // namespace command

//## begin module%660056F20030.epilog preserve=yes
//## end module%660056F20030.epilog


#endif
