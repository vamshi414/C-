//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52FB8DDE0197.cm preserve=no
//	$Date:   Dec 09 2014 15:13:10  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%52FB8DDE0197.cm

//## begin module%52FB8DDE0197.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52FB8DDE0197.cp

//## Module: CXOSBC44%52FB8DDE0197; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC44.hpp

#ifndef CXOSBC44_h
#define CXOSBC44_h 1

//## begin module%52FB8DDE0197.additionalIncludes preserve=no
//## end module%52FB8DDE0197.additionalIncludes

//## begin module%52FB8DDE0197.includes preserve=yes
#include <vector>
//## end module%52FB8DDE0197.includes

#ifndef CXOSBC45_h
#include "CXODBC45.hpp"
#endif
#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class GenericSegment;
} // namespace segment

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Column;

} // namespace database

//## begin module%52FB8DDE0197.declarations preserve=no
//## end module%52FB8DDE0197.declarations

//## begin module%52FB8DDE0197.additionalDeclarations preserve=yes
//## end module%52FB8DDE0197.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::Constraint%52FB8B0403D3.preface preserve=yes
//## end command::Constraint%52FB8B0403D3.preface

//## Class: Constraint%52FB8B0403D3
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%52FB8B600168;segment::GenericSegment { -> F}
//## Uses: <unnamed>%5485EC830267;database::Column { -> F}

class DllExport Constraint : public reusable::Object  //## Inherits: <unnamed>%52FB8B160194
{
  //## begin command::Constraint%52FB8B0403D3.initialDeclarations preserve=yes
  //## end command::Constraint%52FB8B0403D3.initialDeclarations

  public:
    //## Constructors (generated)
      Constraint();

    //## Destructor (generated)
      virtual ~Constraint();


    //## Other Operations (specified)
      //## Operation: addColumn%52FD48FA0200
      void addColumn (const string& strTag, multimap<string,database::Column,less<string> >& hTag);

      //## Operation: addPredicate%52FB9038013C
      void addPredicate (const char* pszBuffer);

      //## Operation: match%52FB8B3C0002
      bool match (const segment::GenericSegment& hGenericSegment);

    // Additional Public Declarations
      //## begin command::Constraint%52FB8B0403D3.public preserve=yes
      //## end command::Constraint%52FB8B0403D3.public

  protected:
    // Additional Protected Declarations
      //## begin command::Constraint%52FB8B0403D3.protected preserve=yes
      //## end command::Constraint%52FB8B0403D3.protected

  private:
    // Additional Private Declarations
      //## begin command::Constraint%52FB8B0403D3.private preserve=yes
      //## end command::Constraint%52FB8B0403D3.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%52FB8B76000A
      //## Role: Constraint::<m_hPredicate>%52FB8B770046
      //## begin command::Constraint::<m_hPredicate>%52FB8B770046.role preserve=no  public: command::Predicate {1 -> 0..nVHgN}
      vector<Predicate> m_hPredicate;
      //## end command::Constraint::<m_hPredicate>%52FB8B770046.role

    // Additional Implementation Declarations
      //## begin command::Constraint%52FB8B0403D3.implementation preserve=yes
      //## end command::Constraint%52FB8B0403D3.implementation

};

//## begin command::Constraint%52FB8B0403D3.postscript preserve=yes
//## end command::Constraint%52FB8B0403D3.postscript

} // namespace command

//## begin module%52FB8DDE0197.epilog preserve=yes
//## end module%52FB8DDE0197.epilog


#endif
