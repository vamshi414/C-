//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5625F7D903BA.cm preserve=no
//	$Date:   May 24 2016 11:03:16  $ $Author:   e1009510  $ $Revision:   1.0  $
//## end module%5625F7D903BA.cm

//## begin module%5625F7D903BA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5625F7D903BA.cp

//## Module: CXOSBC48%5625F7D903BA; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC48.cpp

//## begin module%5625F7D903BA.additionalIncludes preserve=no
//## end module%5625F7D903BA.additionalIncludes

//## begin module%5625F7D903BA.includes preserve=yes
//## end module%5625F7D903BA.includes

#ifndef CXOSBC48_h
#include "CXODBC48.hpp"
#endif
//## begin module%5625F7D903BA.declarations preserve=no
//## end module%5625F7D903BA.declarations

//## begin module%5625F7D903BA.additionalDeclarations preserve=yes
//## end module%5625F7D903BA.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::Function 

Function::Function()
  //## begin Function::Function%5625F72A0314_const.hasinit preserve=no
  //## end Function::Function%5625F72A0314_const.hasinit
  //## begin Function::Function%5625F72A0314_const.initialization preserve=yes
  //## end Function::Function%5625F72A0314_const.initialization
{
  //## begin command::Function::Function%5625F72A0314_const.body preserve=yes
   memcpy(m_sID,"BC48",4);
  //## end command::Function::Function%5625F72A0314_const.body
}


Function::~Function()
{
  //## begin command::Function::~Function%5625F72A0314_dest.body preserve=yes
  //## end command::Function::~Function%5625F72A0314_dest.body
}


bool Function::operator==(const Function &right) const
{
  //## begin command::Function::operator==%5625F72A0314_eq.body preserve=yes
   if (m_strName == right.m_strName)
      return true;
   return false;
  //## end command::Function::operator==%5625F72A0314_eq.body
}

bool Function::operator!=(const Function &right) const
{
  //## begin command::Function::operator!=%5625F72A0314_neq.body preserve=yes
   return !(operator == (right));
  //## end command::Function::operator!=%5625F72A0314_neq.body
}



//## Other Operations (implementation)
void Function::addCriteria (const Criteria& hCriteria)
{
  //## begin command::Function::addCriteria%5628AAC70013.body preserve=yes
   m_hCriteria.push_back(hCriteria);
  //## end command::Function::addCriteria%5628AAC70013.body
}

void Function::clear ()
{
  //## begin command::Function::clear%5628D64502A9.body preserve=yes
   m_strName.erase();
   m_hCriteria.clear();
  //## end command::Function::clear%5628D64502A9.body
}

vector<Criteria>& Function::getCriteria ()
{
  //## begin command::Function::getCriteria%5628EA56007A.body preserve=yes
   return m_hCriteria;
  //## end command::Function::getCriteria%5628EA56007A.body
}

// Additional Declarations
  //## begin command::Function%5625F72A0314.declarations preserve=yes
  //## end command::Function%5625F72A0314.declarations

} // namespace command

//## begin module%5625F7D903BA.epilog preserve=yes
//## end module%5625F7D903BA.epilog
