//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%36DF0071029C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DF0071029C.cm

//## begin module%36DF0071029C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DF0071029C.cp

//## Module: CXOSBC09%36DF0071029C; Package specification
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC09.hpp

#ifndef CXOSBC09_h
#define CXOSBC09_h 1

//## begin module%36DF0071029C.additionalIncludes preserve=no
//## end module%36DF0071029C.additionalIncludes

//## begin module%36DF0071029C.includes preserve=yes
// $Date:   Jun 30 2006 11:35:08  $ $Author:   D02405  $ $Revision:   1.2  $
//## end module%36DF0071029C.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS10_h
#include "CXODBS10.hpp"
#endif
#ifndef CXOSUS04_h
#include "CXODUS04.hpp"
#endif
#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class ResponseTimeSegment;
class CommonHeaderSegment;

} // namespace segment

//## begin module%36DF0071029C.declarations preserve=no
//## end module%36DF0071029C.declarations

//## begin module%36DF0071029C.additionalDeclarations preserve=yes
//## end module%36DF0071029C.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::GetProfileCommand%346475AF0080.preface preserve=yes
//## end command::GetProfileCommand%346475AF0080.preface

//## Class: GetProfileCommand%346475AF0080
//	QGETUSER - retrieve end user list of profiles.
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39491A2703D6;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%39491A2A00D7;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%39491A2C021A;IF::Message { -> F}
//## Uses: <unnamed>%39491A2E01F5;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%39491A3002D4;IF::Extract { -> F}
//## Uses: <unnamed>%39491A330166;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%39491A350209;segment::InformationSegment { -> F}
//## Uses: <unnamed>%39F452740053;monitor::UseCase { -> F}

class DllExport GetProfileCommand : public ClientCommand  //## Inherits: <unnamed>%35978819024F
{
  //## begin command::GetProfileCommand%346475AF0080.initialDeclarations preserve=yes
  //## end command::GetProfileCommand%346475AF0080.initialDeclarations

  public:
    //## Constructors (generated)
      GetProfileCommand();

    //## Constructors (specified)
      //## Operation: GetProfileCommand%3E96B3E30109
      GetProfileCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~GetProfileCommand();


    //## Other Operations (specified)
      //## Operation: execute%394918C50228
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: parse%394918C5037C
      //	Parse this command into segments.
      //## Semantics:
      //	1. Verify the message length.
      //	2. Reset all segments.
      //	3. Import the available segments.
      virtual int parse ();

      //## Operation: update%394918C503E1
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin command::GetProfileCommand%346475AF0080.public preserve=yes
      //## end command::GetProfileCommand%346475AF0080.public

  protected:
    // Additional Protected Declarations
      //## begin command::GetProfileCommand%346475AF0080.protected preserve=yes
      //## end command::GetProfileCommand%346475AF0080.protected

  private:
    // Additional Private Declarations
      //## begin command::GetProfileCommand%346475AF0080.private preserve=yes
      //## end command::GetProfileCommand%346475AF0080.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: RecordsReturnedThisMessage%394918D30192
      //## begin command::GetProfileCommand::RecordsReturnedThisMessage%394918D30192.attr preserve=no  private: int {U} 0
      int m_lRecordsReturnedThisMessage;
      //## end command::GetProfileCommand::RecordsReturnedThisMessage%394918D30192.attr

      //## Attribute: TotalRecordsFound%394918D30214
      //## begin command::GetProfileCommand::TotalRecordsFound%394918D30214.attr preserve=no  private: int {U} 0
      int m_lTotalRecordsFound;
      //## end command::GetProfileCommand::TotalRecordsFound%394918D30214.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%394919550149
      //## Role: GetProfileCommand::<m_pMultipleRowContextSegment>%3949195502F7
      //## begin command::GetProfileCommand::<m_pMultipleRowContextSegment>%3949195502F7.role preserve=no  public: segment::MultipleRowContextSegment { -> RHgN}
      segment::MultipleRowContextSegment *m_pMultipleRowContextSegment;
      //## end command::GetProfileCommand::<m_pMultipleRowContextSegment>%3949195502F7.role

      //## Association: Connex Library::Command_CAT::<unnamed>%394919580283
      //## Role: GetProfileCommand::<m_hQuery>%394919590018
      //## begin command::GetProfileCommand::<m_hQuery>%394919590018.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end command::GetProfileCommand::<m_hQuery>%394919590018.role

      //## Association: Connex Library::Command_CAT::<unnamed>%39491A37007B
      //## Role: GetProfileCommand::<m_hProfileSegment>%39491A370220
      //## begin command::GetProfileCommand::<m_hProfileSegment>%39491A370220.role preserve=no  public: usersegment::ProfileSegment { -> VHgN}
      usersegment::ProfileSegment m_hProfileSegment;
      //## end command::GetProfileCommand::<m_hProfileSegment>%39491A370220.role

    // Additional Implementation Declarations
      //## begin command::GetProfileCommand%346475AF0080.implementation preserve=yes
      //## end command::GetProfileCommand%346475AF0080.implementation

};

//## begin command::GetProfileCommand%346475AF0080.postscript preserve=yes
//## end command::GetProfileCommand%346475AF0080.postscript

} // namespace command

//## begin module%36DF0071029C.epilog preserve=yes
using namespace command;
//## end module%36DF0071029C.epilog


#endif
