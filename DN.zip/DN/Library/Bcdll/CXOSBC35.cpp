//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4C61BBE90035.cm preserve=no
//	$Date:   Sep 01 2021 01:41:06  $ $Author:   e3016938  $
//	$Revision:   1.22  $
//## end module%4C61BBE90035.cm

//## begin module%4C61BBE90035.cp preserve=no
//	Copyright (c) 1997 - 2018
//	FIS
//## end module%4C61BBE90035.cp

//## Module: CXOSBC35%4C61BBE90035; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC35.cpp

//## begin module%4C61BBE90035.additionalIncludes preserve=no
//## end module%4C61BBE90035.additionalIncludes

//## begin module%4C61BBE90035.includes preserve=yes
#ifdef _WIN32
//#include "windows.h"
#include "xercesc\sax\AttributeList.hpp"
#else
#include "xercesc/sax/AttributeList.hpp"
#endif
#include "CXODRU05.hpp"
#include "CXODIF48.hpp"
//## end module%4C61BBE90035.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSBC34_h
#include "CXODBC34.hpp"
#endif
#ifndef CXOSBC36_h
#include "CXODBC36.hpp"
#endif
#ifndef CXOSBC35_h
#include "CXODBC35.hpp"
#endif


//## begin module%4C61BBE90035.declarations preserve=no
//## end module%4C61BBE90035.declarations

//## begin module%4C61BBE90035.additionalDeclarations preserve=yes
//## end module%4C61BBE90035.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::XMLHandler

XMLHandler::XMLHandler()
  //## begin XMLHandler::XMLHandler%4C61BB7A012E_const.hasinit preserve=no
      : m_pXMLItem(0),
        m_pSOAPCommand(0)
  //## end XMLHandler::XMLHandler%4C61BB7A012E_const.hasinit
  //## begin XMLHandler::XMLHandler%4C61BB7A012E_const.initialization preserve=yes
 #ifdef _UNIX
   ,m_hXMLFormatter("UTF-8",&m_hMemBufFormatTarget)
#else
   ,m_hXMLFormatter("LATIN1",&m_hMemBufFormatTarget)
#endif
  //## end XMLHandler::XMLHandler%4C61BB7A012E_const.initialization
{
  //## begin command::XMLHandler::XMLHandler%4C61BB7A012E_const.body preserve=yes
  //## end command::XMLHandler::XMLHandler%4C61BB7A012E_const.body
}

XMLHandler::XMLHandler (command::XMLItem* pXMLItem)
  //## begin command::XMLHandler::XMLHandler%4C61BCFB02F6.hasinit preserve=no
      : m_pXMLItem(0),
        m_pSOAPCommand(0)
  //## end command::XMLHandler::XMLHandler%4C61BCFB02F6.hasinit
  //## begin command::XMLHandler::XMLHandler%4C61BCFB02F6.initialization preserve=yes
#ifdef _UNIX
   ,m_hXMLFormatter("UTF-8",&m_hMemBufFormatTarget)
#else
   ,m_hXMLFormatter("LATIN1",&m_hMemBufFormatTarget)
#endif
  //## end command::XMLHandler::XMLHandler%4C61BCFB02F6.initialization
{
  //## begin command::XMLHandler::XMLHandler%4C61BCFB02F6.body preserve=yes
   m_pXMLItem = pXMLItem;
  //## end command::XMLHandler::XMLHandler%4C61BCFB02F6.body
}

XMLHandler::XMLHandler (command::XMLItem* pXMLItem, command::SOAPCommand* pSOAPCommand)
  //## begin command::XMLHandler::XMLHandler%5B48B0C003BE.hasinit preserve=no
      : m_pXMLItem(0),
        m_pSOAPCommand(0)
  //## end command::XMLHandler::XMLHandler%5B48B0C003BE.hasinit
  //## begin command::XMLHandler::XMLHandler%5B48B0C003BE.initialization preserve=yes
#ifdef _UNIX
   ,m_hXMLFormatter("UTF-8",&m_hMemBufFormatTarget)
#else
   ,m_hXMLFormatter("LATIN1",&m_hMemBufFormatTarget)
#endif
  //## end command::XMLHandler::XMLHandler%5B48B0C003BE.initialization
{
  //## begin command::XMLHandler::XMLHandler%5B48B0C003BE.body preserve=yes
   m_pXMLItem = pXMLItem;
   m_pSOAPCommand = pSOAPCommand;
  //## end command::XMLHandler::XMLHandler%5B48B0C003BE.body
}


XMLHandler::~XMLHandler()
{
  //## begin command::XMLHandler::~XMLHandler%4C61BB7A012E_dest.body preserve=yes
  //## end command::XMLHandler::~XMLHandler%4C61BB7A012E_dest.body
}



//## Other Operations (implementation)
void XMLHandler::characters (const XMLCh* const chars, const XMLSIZE length)
{
  //## begin command::XMLHandler::characters%4C61BD3C03A2.body preserve=yes
   getToken("XMLHandler::characters ",chars,length);
   m_strCharacters += m_strToken;
  //## end command::XMLHandler::characters%4C61BD3C03A2.body
}

void XMLHandler::endDocument ()
{
  //## begin command::XMLHandler::endDocument%4C61BD4C0095.body preserve=yes
   IF::Trace::put("XMLHandler::endDocument");
   m_pXMLItem->import();
  //## end command::XMLHandler::endDocument%4C61BD4C0095.body
}

void XMLHandler::endElement (const XMLCh* const name)
{
  //## begin command::XMLHandler::endElement%4C64497601C8.body preserve=yes
   if (!m_strCharacters.empty())
   {
      if (m_hElement.back() == "ActyId")
         segment::SOAPSegment::instance()->setActyId(m_strCharacters);
      else
      if (m_hElement.back() == "MsgUuid"
         || m_hElement.back() == "uuid")
         segment::SOAPSegment::instance()->setMsgUuid(m_strCharacters);
      else
      if (m_hElement.back() == "ServVer")
         segment::SOAPSegment::instance()->setServVer(m_strCharacters);
      else
      if (m_hElement.back() == "UsrId"
         || m_hElement.back() == "userId")
      {
         m_strCharacters.trim();
         if (m_strCharacters.length() > 8)
            AdvancedEncryptionStandard::decrypt(m_strCharacters);
         segment::SOAPSegment::instance()->setUSER_ID(m_strCharacters);
      }
      else
      if (m_hElement.back() == "Pswrd"
         || m_hElement.back() == "password")
      {
         m_strCharacters.trim();
         if (m_strCharacters.length() > 8)
            AdvancedEncryptionStandard::decrypt(m_strCharacters);
         segment::SOAPSegment::instance()->setUSER_PASSWORD(m_strCharacters);
      }
      m_pXMLItem->add(m_hElement.back(), m_strCharacters);
   }
   if (m_pSOAPCommand)
      m_pSOAPCommand->endElement(m_hElement.back());
   m_hElement.pop_back();
  //## end command::XMLHandler::endElement%4C64497601C8.body
}

void XMLHandler::error (const SAXParseException& exc)
{
  //## begin command::XMLHandler::error%4C64497D017A.body preserve=yes
   IF::Trace::put("XMLHandler::error");
   char szBuffer[64];
   Trace::put(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"DNHandlerBase::error line %d column %d",(int)exc.getLineNumber(),(int)exc.getColumnNumber()));
  //## end command::XMLHandler::error%4C64497D017A.body
}

void XMLHandler::fatalError (const SAXParseException& exc)
{
  //## begin command::XMLHandler::fatalError%4C644983009F.body preserve=yes
   IF::Trace::put("XMLHandler::fatalError");
   char szBuffer[64];
   Trace::put(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"DNHandlerBase::fatalError line %d column %d",(int)exc.getLineNumber(),(int)exc.getColumnNumber()));
   string strTemp(szBuffer);
   strTemp.append(" ");
   getToken("XMLHandler::fatalError ",exc.getMessage(),XMLString::stringLen(exc.getMessage()));
   strTemp.append(m_strToken);
   SOAPSegment::instance()->setMsg("BC35.1","Parse Error",strTemp);
   m_hElement.erase(m_hElement.begin(),m_hElement.end());
   segment::SOAPSegment::instance()->setTxt("Parse failure");
   segment::SOAPSegment::instance()->setRtnCde('3');
  //## end command::XMLHandler::fatalError%4C644983009F.body
}

void XMLHandler::getToken (const char* pszFunction, const XMLCh* const psBuffer, size_t lLength)
{
  //## begin command::XMLHandler::getToken%4C6584390298.body preserve=yes
   if (psBuffer)
   {
      m_hXMLFormatter.formatBuf(psBuffer,lLength);
      char* p = new char[m_hMemBufFormatTarget.getLen()];
      Object::memcpy_s(p,m_hMemBufFormatTarget.getLen(),(char*)m_hMemBufFormatTarget.getRawBuffer(),m_hMemBufFormatTarget.getLen());
#ifdef MVS
      CodeTable::translate(p,m_hMemBufFormatTarget.getLen(),CodeTable::CX_ASCII_TO_EBCDIC);
#endif
      int m = m_hMemBufFormatTarget.getLen();
      m_strToken.assign(p,m);
      size_t pos = m_strToken.find('\0');
      if (pos != string::npos)
         m_strToken.erase(pos);
      m_hMemBufFormatTarget.reset();
      delete [] p;
   }
   else
      m_strToken.erase();
   string strBuffer(pszFunction);
   if (!m_hElement.empty() && m_hElement.back() == "Pswrd")
      strBuffer.append(m_strToken.length(), '*');
   else
      strBuffer += m_strToken;
   Trace::put(strBuffer.data(),strBuffer.length());
  //## end command::XMLHandler::getToken%4C6584390298.body
}

void XMLHandler::startElement (const XMLCh* const name, AttributeList& attributes)
{
  //## begin command::XMLHandler::startElement%4C6449910031.body preserve=yes
   getToken("XMLHandler::startElement ",name,XMLString::stringLen(name));
   m_hElement.push_back(m_strToken);
   m_strCharacters.erase();
   for (int i = 0;i < attributes.getLength();++i)
   {
      string strName(m_hElement.back());
      strName.append(" ",1);
      int j = strName.length();
      const XMLCh* pXMLCh = attributes.getName(i);
      getToken("XMLHandler::startElement ",pXMLCh,XMLString::stringLen(pXMLCh));
      strName += m_strToken;
      pXMLCh = attributes.getValue(i);
      getToken("XMLHandler::startElement ",pXMLCh,XMLString::stringLen(pXMLCh));
      m_pXMLItem->add(strName,m_strToken);
      if (m_pSOAPCommand)
         m_pSOAPCommand->attribute(m_hElement.back(),strName.substr(j),m_strToken);
   }
   if (m_pSOAPCommand)
      m_pSOAPCommand->startElement(m_hElement.back());
  //## end command::XMLHandler::startElement%4C6449910031.body
}

// Additional Declarations
  //## begin command::XMLHandler%4C61BB7A012E.declarations preserve=yes
  //## end command::XMLHandler%4C61BB7A012E.declarations

} // namespace command

//## begin module%4C61BBE90035.epilog preserve=yes
//## end module%4C61BBE90035.epilog
