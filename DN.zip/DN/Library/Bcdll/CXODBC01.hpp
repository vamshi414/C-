//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3597D5B2002D.cm preserve=no
//	$Date:   Jul 03 2019 14:06:14  $ $Author:   e1009839  $
//	$Revision:   1.14  $
//## end module%3597D5B2002D.cm

//## begin module%3597D5B2002D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3597D5B2002D.cp

//## Module: CXOSBC01%3597D5B2002D; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC01.hpp

#ifndef CXOSBC01_h
#define CXOSBC01_h 1

//## begin module%3597D5B2002D.additionalIncludes preserve=no
//## end module%3597D5B2002D.additionalIncludes

//## begin module%3597D5B2002D.includes preserve=yes
// $Date:   Jul 03 2019 14:06:14  $ $Author:   e1009839  $ $Revision:   1.14  $
//## end module%3597D5B2002D.includes

#ifndef CXOSBS04_h
#include "CXODBS04.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class FormatSelectVisitor;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class RelationshipSegment;
} // namespace usersegment

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class ResponseTimeSegment;
class CommonHeaderSegment;
} // namespace segment

namespace usersegment {
class ResourceListSegment;

} // namespace usersegment

//## begin module%3597D5B2002D.declarations preserve=no
//## end module%3597D5B2002D.declarations

//## begin module%3597D5B2002D.additionalDeclarations preserve=yes
//## end module%3597D5B2002D.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::ClientCommand%359787DE0100.preface preserve=yes
//## end command::ClientCommand%359787DE0100.preface

//## Class: ClientCommand%359787DE0100
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: reply%359CF09B02B7;IF::Message { -> F}
//## Uses: deport%359CF37702E2;segment::InformationSegment { -> F}
//## Uses: <unnamed>%37AF0D450272;database::Database { -> F}
//## Uses: <unnamed>%37AF0DA401EC;IF::Queue { -> F}
//## Uses: <unnamed>%37BB02AF028E;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%3A3BA1960192;monitor::UseCase { -> F}
//## Uses: <unnamed>%3BBEFF6E000F;usersegment::ResourceListSegment { -> F}
//## Uses: <unnamed>%5D1CA6990200;reusable::FormatSelectVisitor { -> F}
//## Uses: <unnamed>%5D1CA69F0017;reusable::Query { -> F}
//## Uses: <unnamed>%5D1CA6A201AF;database::DatabaseFactory { -> F}

class DllExport ClientCommand : public segment::Command  //## Inherits: <unnamed>%3597881F02A8
{
  //## begin command::ClientCommand%359787DE0100.initialDeclarations preserve=yes
  public:
      enum CONTEXT
      {
         BEGIN,
         END
      };
      enum Entity
      {
         Device,
         ReportingLevel,
         Institution,
         Processor,
         ProcessorGroup,
         All
      };
  //## end command::ClientCommand%359787DE0100.initialDeclarations

  public:
    //## Constructors (generated)
      ClientCommand();

    //## Constructors (specified)
      //## Operation: ClientCommand%3597EEDE0304
      ClientCommand (const char* pszMessageID, const char* pszQueue = 0);

    //## Destructor (generated)
      virtual ~ClientCommand();


    //## Other Operations (specified)
      //## Operation: abort%5D1CBAE30369
      virtual void abort ();

      //## Operation: onResume%3A79CFED00F5
      virtual void onResume ();

      //## Operation: parse%4D1215480224
      virtual int parse ();

      //## Operation: publish%3AE977E9032E
      //	Tell the CI that the task is up (ServiceName is
      //	available).
      //	Returns true if message is sent successfully.
      virtual bool publish ();

      //## Operation: reply%3597D4EA024C
      virtual int reply ();

      //## Operation: secure%5D1CA5DF0303
      const char* secure (enum Entity nEntity);

      //## Operation: sendError%3597D4FA00A1
      int sendError (int iResultCode, char sSeverityLevel, int lInfoIDNumber, bool bReset = true, const char* pszText = 0);

      //## Operation: update%37AF0B69023B
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ResultCode%375E6F68005E
      const int& getResultCode () const
      {
        //## begin command::ClientCommand::getResultCode%375E6F68005E.get preserve=no
        return m_iResultCode;
        //## end command::ClientCommand::getResultCode%375E6F68005E.get
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::Command_CAT::<unnamed>%49F75A5102AF
      //## Role: ClientCommand::<m_pGlobalContext>%49F75A52034B
      static database::GlobalContext * getGlobalContext (int index);
      static void setGlobalContext (int index, database::GlobalContext * value);

    // Additional Public Declarations
      //## begin command::ClientCommand%359787DE0100.public preserve=yes
      //## end command::ClientCommand%359787DE0100.public

  protected:
    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::Command_CAT::<unnamed>%359B7170008C
      //## Role: ClientCommand::<m_pResponseTimeSegment>%359B71710282
      segment::ResponseTimeSegment * getResponseTimeSegment ()
      {
        //## begin command::ClientCommand::getResponseTimeSegment%359B71710282.get preserve=no
        return m_pResponseTimeSegment;
        //## end command::ClientCommand::getResponseTimeSegment%359B71710282.get
      }


      //## Association: Connex Library::Command_CAT::<unnamed>%37B2C8B500E5
      //## Role: ClientCommand::<m_pRelationshipSegment>%37B2C8B50370
      usersegment::RelationshipSegment * getRelationshipSegment ()
      {
        //## begin command::ClientCommand::getRelationshipSegment%37B2C8B50370.get preserve=no
        return m_pRelationshipSegment;
        //## end command::ClientCommand::getRelationshipSegment%37B2C8B50370.get
      }


    // Data Members for Class Attributes

      //## Attribute: DataBuffer%3597F2FE01FE
      //## begin command::ClientCommand::DataBuffer%3597F2FE01FE.attr preserve=no  protected: char {RA} 0
      char *m_pDataBuffer;
      //## end command::ClientCommand::DataBuffer%3597F2FE01FE.attr

      //## begin command::ClientCommand::ResultCode%375E6F68005E.attr preserve=no  public: int {V} 0
      int m_iResultCode;
      //## end command::ClientCommand::ResultCode%375E6F68005E.attr

      //## Attribute: ServiceName%37AF0A270274
      //## begin command::ClientCommand::ServiceName%37AF0A270274.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strServiceName;
      //## end command::ClientCommand::ServiceName%37AF0A270274.attr

    // Additional Protected Declarations
      //## begin command::ClientCommand%359787DE0100.protected preserve=yes
      //## end command::ClientCommand%359787DE0100.protected

  private:
    // Additional Private Declarations
      //## begin command::ClientCommand%359787DE0100.private preserve=yes
      //## end command::ClientCommand%359787DE0100.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ObjectName%37AF0A4C03B8
      //## begin command::ClientCommand::ObjectName%37AF0A4C03B8.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strObjectName;
      //## end command::ClientCommand::ObjectName%37AF0A4C03B8.attr

      //## Attribute: SubSelect%5D1CA58B030C
      //## begin command::ClientCommand::SubSelect%5D1CA58B030C.attr preserve=no  private: static reusable::string {V} 
      static reusable::string m_strSubSelect;
      //## end command::ClientCommand::SubSelect%5D1CA58B030C.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%359B7170008C
      //## begin command::ClientCommand::<m_pResponseTimeSegment>%359B71710282.role preserve=no  protected: segment::ResponseTimeSegment { -> RFHgN}
      segment::ResponseTimeSegment *m_pResponseTimeSegment;
      //## end command::ClientCommand::<m_pResponseTimeSegment>%359B71710282.role

      //## Association: Connex Library::Command_CAT::<unnamed>%37B2C8B500E5
      //## begin command::ClientCommand::<m_pRelationshipSegment>%37B2C8B50370.role preserve=no  protected: usersegment::RelationshipSegment { -> RFHgN}
      usersegment::RelationshipSegment *m_pRelationshipSegment;
      //## end command::ClientCommand::<m_pRelationshipSegment>%37B2C8B50370.role

      //## Association: Connex Library::Command_CAT::<unnamed>%49F75A5102AF
      //## begin command::ClientCommand::<m_pGlobalContext>%49F75A52034B.role preserve=no  public: static database::GlobalContext { -> 2RFHgN}
      static database::GlobalContext *m_pGlobalContext[2];
      //## end command::ClientCommand::<m_pGlobalContext>%49F75A52034B.role

    // Additional Implementation Declarations
      //## begin command::ClientCommand%359787DE0100.implementation preserve=yes
      //## end command::ClientCommand%359787DE0100.implementation

};

//## begin command::ClientCommand%359787DE0100.postscript preserve=yes
//## end command::ClientCommand%359787DE0100.postscript

} // namespace command

//## begin module%3597D5B2002D.epilog preserve=yes
using namespace command;
//## end module%3597D5B2002D.epilog


#endif
