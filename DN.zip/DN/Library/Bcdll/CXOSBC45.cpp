//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52FB8E27029E.cm preserve=no
//	$Date:   Mar 19 2018 06:51:18  $ $Author:   e1009839  $
//	$Revision:   1.4  $
//## end module%52FB8E27029E.cm

//## begin module%52FB8E27029E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52FB8E27029E.cp

//## Module: CXOSBC45%52FB8E27029E; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC45.cpp

//## begin module%52FB8E27029E.additionalIncludes preserve=no
//## end module%52FB8E27029E.additionalIncludes

//## begin module%52FB8E27029E.includes preserve=yes
#include <algorithm>
//## end module%52FB8E27029E.includes

#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXODDB51_h
#include "CXODDB51.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBC45_h
#include "CXODBC45.hpp"
#endif


//## begin module%52FB8E27029E.declarations preserve=no
//## end module%52FB8E27029E.declarations

//## begin module%52FB8E27029E.additionalDeclarations preserve=yes
//## end module%52FB8E27029E.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::Predicate 

Predicate::Predicate()
  //## begin Predicate::Predicate%52FB85450346_const.hasinit preserve=no
  //## end Predicate::Predicate%52FB85450346_const.hasinit
  //## begin Predicate::Predicate%52FB85450346_const.initialization preserve=yes
  //## end Predicate::Predicate%52FB85450346_const.initialization
{
  //## begin command::Predicate::Predicate%52FB85450346_const.body preserve=yes
   memcpy(m_sID,"BC45",4);
  //## end command::Predicate::Predicate%52FB85450346_const.body
}

Predicate::Predicate(const Predicate &right)
  //## begin Predicate::Predicate%52FB85450346_copy.hasinit preserve=no
  //## end Predicate::Predicate%52FB85450346_copy.hasinit
  //## begin Predicate::Predicate%52FB85450346_copy.initialization preserve=yes
   : m_strName(right.m_strName)
   ,m_strOperator(right.m_strOperator)
   ,m_strParent(right.m_strParent)
   ,m_strValue(right.m_strValue)
   ,Object(right)
  //## end Predicate::Predicate%52FB85450346_copy.initialization
{
  //## begin command::Predicate::Predicate%52FB85450346_copy.body preserve=yes
  //## end command::Predicate::Predicate%52FB85450346_copy.body
}

Predicate::Predicate (const char* pszBuffer)
  //## begin command::Predicate::Predicate%52FB90800088.hasinit preserve=no
  //## end command::Predicate::Predicate%52FB90800088.hasinit
  //## begin command::Predicate::Predicate%52FB90800088.initialization preserve=yes
  //## end command::Predicate::Predicate%52FB90800088.initialization
{
  //## begin command::Predicate::Predicate%52FB90800088.body preserve=yes
   memcpy(m_sID,"BC45",4);
   string strBuffer(pszBuffer + 5);
   vector<string> hTokens;
   if (Buffer::parse(strBuffer," ",hTokens) > 2)
   {
      m_strName = hTokens[0];
      m_strOperator = hTokens[1];
      m_strValue = hTokens[2];
      if (m_strOperator == "LIKE")
         m_strValue.resize(m_strValue.length() - 1);
   }
  //## end command::Predicate::Predicate%52FB90800088.body
}

Predicate::Predicate (const string& strParent, const string& strName, const string& strOperator, const string& strValue)
  //## begin command::Predicate::Predicate%5AAAC596015B.hasinit preserve=no
  //## end command::Predicate::Predicate%5AAAC596015B.hasinit
  //## begin command::Predicate::Predicate%5AAAC596015B.initialization preserve=yes
   : m_strParent(strParent)
   ,m_strName(strName)
   ,m_strOperator(strOperator)
   ,m_strValue(strValue)
  //## end command::Predicate::Predicate%5AAAC596015B.initialization
{
  //## begin command::Predicate::Predicate%5AAAC596015B.body preserve=yes
   memcpy(m_sID,"BC45",4);
  //## end command::Predicate::Predicate%5AAAC596015B.body
}


Predicate::~Predicate()
{
  //## begin command::Predicate::~Predicate%52FB85450346_dest.body preserve=yes
  //## end command::Predicate::~Predicate%52FB85450346_dest.body
}


Predicate & Predicate::operator=(const Predicate &right)
{
  //## begin command::Predicate::operator=%52FB85450346_assign.body preserve=yes
   if (this == &right)
      return *this;
   Object::operator=(right);
   m_strName = right.m_strName;
   m_strOperator = right.m_strOperator;
   m_strParent = right.m_strParent;
   m_strValue = right.m_strValue;
   return *this;
  //## end command::Predicate::operator=%52FB85450346_assign.body
}



//## Other Operations (implementation)
void Predicate::addColumn (const string& strTag, multimap<string,database::Column,less<string> >& hTag)
{
  //## begin command::Predicate::addColumn%52FD4979030F.body preserve=yes
   if (m_strName != "CUSTOM")
      hTag.insert(multimap<string,database::Column,less<string> >::value_type(strTag,database::Column("FIN_RECORD",m_strName,0)));
  //## end command::Predicate::addColumn%52FD4979030F.body
}

bool Predicate::match (const segment::GenericSegment& hGenericSegment)
{
  //## begin command::Predicate::match%52FB85680254.body preserve=yes
   string strValue;
   if (m_strName == "CUSTOM")
      strValue = Extract::instance()->getCustomCode();
   else
   if (!hGenericSegment._field(m_strName.c_str(),strValue,false,false))
      return false;
   if (m_strOperator == "=")
      return m_strValue == strValue;
   if (m_strOperator == "LIKE"
      && m_strValue.length() <= strValue.length())
      return memcmp(m_strValue.data(),strValue.data(),m_strValue.length()) == 0;
   if (m_strOperator == "IN")
   {
      vector<string> hTokens;
      Buffer::parse(m_strValue,",",hTokens);
      return find(hTokens.begin(),hTokens.end(),strValue) != hTokens.end();
   }
   return false;
  //## end command::Predicate::match%52FB85680254.body
}

// Additional Declarations
  //## begin command::Predicate%52FB85450346.declarations preserve=yes
  //## end command::Predicate%52FB85450346.declarations

} // namespace command

//## begin module%52FB8E27029E.epilog preserve=yes
//## end module%52FB8E27029E.epilog
