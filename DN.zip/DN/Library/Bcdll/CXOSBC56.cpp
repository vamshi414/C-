//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5B85AB58013B.cm preserve=no
//	$Date:   Oct 30 2018 11:39:56  $ $Author:   e1009591  $ $Revision:   1.0  $
//## end module%5B85AB58013B.cm

//## begin module%5B85AB58013B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5B85AB58013B.cp

//## Module: CXOSBC56%5B85AB58013B; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.9A.R008\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC56.cpp

//## begin module%5B85AB58013B.additionalIncludes preserve=no
//## end module%5B85AB58013B.additionalIncludes

//## begin module%5B85AB58013B.includes preserve=yes
//## end module%5B85AB58013B.includes

#ifndef CXOSBC51_h
#include "CXODBC51.hpp"
#endif
#ifndef CXOSBC56_h
#include "CXODBC56.hpp"
#endif


//## begin module%5B85AB58013B.declarations preserve=no
//## end module%5B85AB58013B.declarations

//## begin module%5B85AB58013B.additionalDeclarations preserve=yes
//## end module%5B85AB58013B.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::APIQueueExportFactory 

//## begin command::APIQueueExportFactory::Instance%5B85AC4C0010.attr preserve=no  private: static command::APIQueueExportFactory* {V} 0
command::APIQueueExportFactory* APIQueueExportFactory::m_pInstance = 0;
//## end command::APIQueueExportFactory::Instance%5B85AC4C0010.attr

APIQueueExportFactory::APIQueueExportFactory()
  //## begin APIQueueExportFactory::APIQueueExportFactory%5B85A7030358_const.hasinit preserve=no
  //## end APIQueueExportFactory::APIQueueExportFactory%5B85A7030358_const.hasinit
  //## begin APIQueueExportFactory::APIQueueExportFactory%5B85A7030358_const.initialization preserve=yes
  //## end APIQueueExportFactory::APIQueueExportFactory%5B85A7030358_const.initialization
{
  //## begin command::APIQueueExportFactory::APIQueueExportFactory%5B85A7030358_const.body preserve=yes
   m_pInstance = this;
  //## end command::APIQueueExportFactory::APIQueueExportFactory%5B85A7030358_const.body
}


APIQueueExportFactory::~APIQueueExportFactory()
{
  //## begin command::APIQueueExportFactory::~APIQueueExportFactory%5B85A7030358_dest.body preserve=yes
  //## end command::APIQueueExportFactory::~APIQueueExportFactory%5B85A7030358_dest.body
}



//## Other Operations (implementation)
command::APIQueueExportFactory* APIQueueExportFactory::instance ()
{
  //## begin command::APIQueueExportFactory::instance%5B85ACE60215.body preserve=yes
   return m_pInstance;
  //## end command::APIQueueExportFactory::instance%5B85ACE60215.body
}

// Additional Declarations
  //## begin command::APIQueueExportFactory%5B85A7030358.declarations preserve=yes
  //## end command::APIQueueExportFactory%5B85A7030358.declarations

} // namespace command

//## begin module%5B85AB58013B.epilog preserve=yes
//## end module%5B85AB58013B.epilog
