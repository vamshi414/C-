//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52B49A4302FD.cm preserve=no
//	$Date:   Mar 01 2018 12:09:24  $ $Author:   e1094689  $ $Revision:   1.2  $
//## end module%52B49A4302FD.cm

//## begin module%52B49A4302FD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52B49A4302FD.cp

//## Module: CXOSBC41%52B49A4302FD; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.9A.R002\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC41.hpp

#ifndef CXOSBC41_h
#define CXOSBC41_h 1

//## begin module%52B49A4302FD.additionalIncludes preserve=no
//## end module%52B49A4302FD.additionalIncludes

//## begin module%52B49A4302FD.includes preserve=yes
//## end module%52B49A4302FD.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DateTime;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;

} // namespace database

//## begin module%52B49A4302FD.declarations preserve=no
//## end module%52B49A4302FD.declarations

//## begin module%52B49A4302FD.additionalDeclarations preserve=yes
//## end module%52B49A4302FD.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::TimeRange%52B4762303A8.preface preserve=yes
//## end command::TimeRange%52B4762303A8.preface

//## Class: TimeRange%52B4762303A8
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%52B4A6B30343;IF::DateTime { -> F}
//## Uses: <unnamed>%52B4A98503A3;timer::Date { -> F}
//## Uses: <unnamed>%52B86EB600B7;database::GlobalContext { -> F}
//## Uses: <unnamed>%52B86EF701FE;timer::Clock { -> F}

class DllExport TimeRange : public reusable::Object  //## Inherits: <unnamed>%52B4765B0359
{
  //## begin command::TimeRange%52B4762303A8.initialDeclarations preserve=yes
  public:
      enum Interval
      {
         BY_MINUTE,
         BY_HOUR,
         BY_MONTH
      };
  //## end command::TimeRange%52B4762303A8.initialDeclarations

  public:
    //## Constructors (generated)
      TimeRange();

    //## Destructor (generated)
      virtual ~TimeRange();


    //## Other Operations (specified)
      //## Operation: adjustEndDateTime%52B4A67A00DC
      bool adjustEndDateTime ();

      //## Operation: adjustStartDateTime%52B4A662003E
      void adjustStartDateTime ();

      //## Operation: instance%52B476A80298
      static TimeRange* instance ();

      //## Operation: reset%52B86B8A00DD
      void reset ();

      //## Operation: setEndDateTime%52B842780344
      void setEndDateTime (const string& value);

      //## Operation: setFinalDateTime%52B86DBE0086
      void setFinalDateTime ();

      //## Operation: setStartDateTime%52B844540164
      void setStartDateTime (const string& value);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: EndDateTime%52B4774B0371
      const string& getEndDateTime () const
      {
        //## begin command::TimeRange::getEndDateTime%52B4774B0371.get preserve=no
        return m_strEndDateTime;
        //## end command::TimeRange::getEndDateTime%52B4774B0371.get
      }


      //## Attribute: Interval%52B4A8370280
      const enum Interval& getInterval () const
      {
        //## begin command::TimeRange::getInterval%52B4A8370280.get preserve=no
        return m_hInterval;
        //## end command::TimeRange::getInterval%52B4A8370280.get
      }

      void setInterval (const enum Interval& value)
      {
        //## begin command::TimeRange::setInterval%52B4A8370280.set preserve=no
        m_hInterval = value;
        //## end command::TimeRange::setInterval%52B4A8370280.set
      }


      //## Attribute: Reverse%52B4A78E0141
      const bool getReverse () const
      {
        //## begin command::TimeRange::getReverse%52B4A78E0141.get preserve=no
        return m_bReverse;
        //## end command::TimeRange::getReverse%52B4A78E0141.get
      }


      //## Attribute: StartDateTime%52B4771503A2
      const string& getStartDateTime () const
      {
        //## begin command::TimeRange::getStartDateTime%52B4771503A2.get preserve=no
        return m_strStartDateTime;
        //## end command::TimeRange::getStartDateTime%52B4771503A2.get
      }


    // Additional Public Declarations
      //## begin command::TimeRange%52B4762303A8.public preserve=yes
      //## end command::TimeRange%52B4762303A8.public

  protected:
    // Additional Protected Declarations
      //## begin command::TimeRange%52B4762303A8.protected preserve=yes
      //## end command::TimeRange%52B4762303A8.protected

  private:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: FinalDateTime%52B4A9A700BE
      const string& getFinalDateTime () const
      {
        //## begin command::TimeRange::getFinalDateTime%52B4A9A700BE.get preserve=no
        return m_strFinalDateTime;
        //## end command::TimeRange::getFinalDateTime%52B4A9A700BE.get
      }

      void setFinalDateTime (const string& value)
      {
        //## begin command::TimeRange::setFinalDateTime%52B4A9A700BE.set preserve=no
        m_strFinalDateTime = value;
        //## end command::TimeRange::setFinalDateTime%52B4A9A700BE.set
      }


    // Additional Private Declarations
      //## begin command::TimeRange%52B4762303A8.private preserve=yes
      //## end command::TimeRange%52B4762303A8.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::TimeRange::EndDateTime%52B4774B0371.attr preserve=no  public: string {V} 
      string m_strEndDateTime;
      //## end command::TimeRange::EndDateTime%52B4774B0371.attr

      //## begin command::TimeRange::FinalDateTime%52B4A9A700BE.attr preserve=no  private: string {V} 
      string m_strFinalDateTime;
      //## end command::TimeRange::FinalDateTime%52B4A9A700BE.attr

      //## Attribute: Instance%52B4766701E9
      //## begin command::TimeRange::Instance%52B4766701E9.attr preserve=no  private: static TimeRange* {V} 0
      static TimeRange* m_pInstance;
      //## end command::TimeRange::Instance%52B4766701E9.attr

      //## begin command::TimeRange::Interval%52B4A8370280.attr preserve=no  public: enum Interval {V} BY_MINUTE
      enum Interval m_hInterval;
      //## end command::TimeRange::Interval%52B4A8370280.attr

      //## begin command::TimeRange::Reverse%52B4A78E0141.attr preserve=no  public: bool {V} false
      bool m_bReverse;
      //## end command::TimeRange::Reverse%52B4A78E0141.attr

      //## begin command::TimeRange::StartDateTime%52B4771503A2.attr preserve=no  public: string {V} 
      string m_strStartDateTime;
      //## end command::TimeRange::StartDateTime%52B4771503A2.attr

      //## Attribute: Year%52B4C6FC0277
      //## begin command::TimeRange::Year%52B4C6FC0277.attr preserve=no  private: int {V} 0
      int m_lYear;
      //## end command::TimeRange::Year%52B4C6FC0277.attr

      //## Attribute: Month%52B4C7120206
      //## begin command::TimeRange::Month%52B4C7120206.attr preserve=no  private: int {V} 0
      int m_lMonth;
      //## end command::TimeRange::Month%52B4C7120206.attr

      //## Attribute: Hour%52B4C7130003
      //## begin command::TimeRange::Hour%52B4C7130003.attr preserve=no  private: int {V} 0
      int m_lHour;
      //## end command::TimeRange::Hour%52B4C7130003.attr

    // Additional Implementation Declarations
      //## begin command::TimeRange%52B4762303A8.implementation preserve=yes
      //## end command::TimeRange%52B4762303A8.implementation

};

//## begin command::TimeRange%52B4762303A8.postscript preserve=yes
//## end command::TimeRange%52B4762303A8.postscript

} // namespace command

//## begin module%52B49A4302FD.epilog preserve=yes
//## end module%52B49A4302FD.epilog


#endif
