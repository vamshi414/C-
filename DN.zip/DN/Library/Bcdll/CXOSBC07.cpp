//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E9AF2CC0271.cm preserve=no
//	$Date:   Mar 24 2017 09:11:22  $ $Author:   e1094689  $ $Revision:   1.9.1.1  $
//## end module%3E9AF2CC0271.cm

//## begin module%3E9AF2CC0271.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%3E9AF2CC0271.cp

//## Module: CXOSBC07%3E9AF2CC0271; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC07.cpp

//## begin module%3E9AF2CC0271.additionalIncludes preserve=no
//## end module%3E9AF2CC0271.additionalIncludes

//## begin module%3E9AF2CC0271.includes preserve=yes
#include "CXODIF03.hpp"
#ifndef CXOSBC26_h
#include "CXODBC26.hpp"
#endif
//## end module%3E9AF2CC0271.includes

#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSUS03_h
#include "CXODUS03.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBC07_h
#include "CXODBC07.hpp"
#endif


//## begin module%3E9AF2CC0271.declarations preserve=no
//## end module%3E9AF2CC0271.declarations

//## begin module%3E9AF2CC0271.additionalDeclarations preserve=yes
#define STS_ALREADY_LOGGED_ON 18
#define STS_ACCESS_SECURITY_UNAVAILABLE 25
//## end module%3E9AF2CC0271.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::UserPool 

//## begin command::UserPool::Instance%3E9AFB3E031C.attr preserve=no  private: static command::UserPool* {V} 0
command::UserPool* UserPool::m_pInstance = 0;
//## end command::UserPool::Instance%3E9AFB3E031C.attr

UserPool::UserPool()
  //## begin UserPool::UserPool%3E9AF20F01F4_const.hasinit preserve=no
  //## end UserPool::UserPool%3E9AF20F01F4_const.hasinit
  //## begin UserPool::UserPool%3E9AF20F01F4_const.initialization preserve=yes
  //## end UserPool::UserPool%3E9AF20F01F4_const.initialization
{
  //## begin command::UserPool::UserPool%3E9AF20F01F4_const.body preserve=yes
   memcpy(m_sID,"BC07",4);
  //## end command::UserPool::UserPool%3E9AF20F01F4_const.body
}


UserPool::~UserPool()
{
  //## begin command::UserPool::~UserPool%3E9AF20F01F4_dest.body preserve=yes
  //## end command::UserPool::~UserPool%3E9AF20F01F4_dest.body
}



//## Other Operations (implementation)
command::UserPool* UserPool::instance ()
{
  //## begin command::UserPool::instance%3E9AFB2300FA.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new UserPool();
   return m_pInstance;
  //## end command::UserPool::instance%3E9AFB2300FA.body
}

bool UserPool::logoffRequest (IF::Message& hMessage, segment::CommonHeaderSegment* pCommonHeaderSegment, segment::ResponseTimeSegment* pResponseTimeSegment)
{
  //## begin command::UserPool::logoffRequest%3E9AF53C00EA.body preserve=yes
   Trace::put("UserPool::logoffRequest");
   string strUserID(pCommonHeaderSegment->getAlias());
   Trace::put(strUserID.c_str());
   map<string,UserSession,less<string> >::iterator pSession = m_hUserSession.find(strUserID);
   if (pSession != m_hUserSession.end())
      return false;
   UserSession hSession;
   pSession = m_hUserSession.insert(m_hUserSession.begin(),map<string,UserSession,less<string> >::value_type(strUserID,hSession));
   if (!(*pSession).second.logoffRequest(hMessage,pCommonHeaderSegment,pResponseTimeSegment))
      return false;
#ifndef MVS
   (*pSession).second.logoffResponse(hMessage);
   m_hUserSession.erase(pSession);
#else
   if (Security::instance()->getSecurityType() == "OPEN")
   {
      (*pSession).second.logoffResponse(hMessage);
      m_hUserSession.erase(pSession);
   }
#endif
   return true;
  //## end command::UserPool::logoffRequest%3E9AF53C00EA.body
}

int UserPool::logonRequest (IF::Message& hMessage, usersegment::LogonSegment* pLogonSegment, segment::ResponseTimeSegment* pResponseTimeSegment)
{
  //## begin command::UserPool::logonRequest%3E9AF5410157.body preserve=yes
   map<string,UserSession,less<string> >::iterator pSession = m_hUserSession.find(pLogonSegment->getUserID());
   if (pSession != m_hUserSession.end())
      return STS_ACCESS_SECURITY_UNAVAILABLE;
   string strTemp;
   if (CommonHeaderSegment::instance()->getSecurityData().empty()
      || CommonHeaderSegment::instance()->getSecurityData()[0] == ' ')
   {
      char szSecurityData[96];
      memset(szSecurityData,' ',64);
      szSecurityData[63] = 'y';
      szSecurityData[64] = '\0';
      memcpy(szSecurityData,pLogonSegment->getUserID().data(),pLogonSegment->getUserID().length());
      if (pLogonSegment->getCustomerID().length() > 0)
      {
         if (pLogonSegment->getCustomerID() != (const char*)"****"
            && pLogonSegment->getCustomerID() != CommonHeaderSegment::instance()->getCUST_ID())
            return STS_INVALID_CUST_ID;
      }
      strTemp = Clock::instance()->getYYYYMMDDHHMMSS();
      strTemp += "00";
      szSecurityData[8] = ':';
      memcpy(&szSecurityData[9],strTemp.data(),strTemp.length());
      CommonHeaderSegment::instance()->setSecurityData(szSecurityData);
   }
   else
      strTemp.assign(CommonHeaderSegment::instance()->getSecurityData().data() + 9,16);
   UserSession hSession;
   hSession.setTimestamp(strTemp.data());
   pSession = m_hUserSession.insert(m_hUserSession.begin(),
      map<string,UserSession,less<string> >::value_type(pLogonSegment->getUserID(),hSession));
   if (!(*pSession).second.logonRequest(hMessage,CommonHeaderSegment::instance(),pLogonSegment,pResponseTimeSegment))
   {
      m_hUserSession.erase(pSession);
      return STS_ACCESS_SECURITY_UNAVAILABLE;
   }
#ifdef MVS
   if (Security::instance()->getSecurityType() == "OPEN")
   {
      (*pSession).second.logonResponse(hMessage);
      m_hUserSession.erase(pSession);
   }
   else if (pLogonSegment->getSignature().length() > 0)
   {
      (*pSession).second.logonResponse(hMessage);
      m_hUserSession.erase(pSession);
   }
#else
   (*pSession).second.logonResponse(hMessage);
   m_hUserSession.erase(pSession);
#endif
   return 0;
  //## end command::UserPool::logonRequest%3E9AF5410157.body
}

bool UserPool::securityResponse (IF::Message& hMessage)
{
  //## begin command::UserPool::securityResponse%3E9AF5440177.body preserve=yes
#ifdef MVS
   Trace::put("UserPool::securityResponse");
   // get client conversation ID from receiver context value
   string strUserID(hMessage.buffer() + 152,8);
   size_t pos = strUserID.find_last_not_of(' ');
   if (pos == string::npos)
      strUserID.erase();
   else
      strUserID.erase(pos + 1);
   Trace::put(strUserID.c_str());
   map<string,UserSession,less<string> >::iterator pSession = m_hUserSession.find(strUserID);
   if (pSession == m_hUserSession.end())
      return false;
   (*pSession).second.securityResponse(hMessage);
   m_hUserSession.erase(pSession);
#endif
   return true;
  //## end command::UserPool::securityResponse%3E9AF5440177.body
}

// Additional Declarations
  //## begin command::UserPool%3E9AF20F01F4.declarations preserve=yes
  //## end command::UserPool%3E9AF20F01F4.declarations

} // namespace command

//## begin module%3E9AF2CC0271.epilog preserve=yes
//## end module%3E9AF2CC0271.epilog
