//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4DC02E8B01C1.cm preserve=no
//## end module%4DC02E8B01C1.cm

//## begin module%4DC02E8B01C1.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4DC02E8B01C1.cp

//## Module: CXOSBC36%4DC02E8B01C1; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC36.cpp

//## begin module%4DC02E8B01C1.additionalIncludes preserve=no
//## end module%4DC02E8B01C1.additionalIncludes

//## begin module%4DC02E8B01C1.includes preserve=yes
#ifdef _WIN32
#include "xercesc\framework\MemBufInputSource.hpp"
#include "xercesc\util\PlatformUtils.hpp"
#include "xercesc\parsers\SAXParser.hpp"
#else
#include "xercesc/framework/MemBufInputSource.hpp"
#include "xercesc/util/PlatformUtils.hpp"
#include "xercesc/parsers/SAXParser.hpp"
#endif
XERCES_CPP_NAMESPACE_USE
#include "CXODRU12.hpp"
#ifndef MVS
#include "CXODBC23.hpp"
#endif
//## end module%4DC02E8B01C1.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSBC26_h
#include "CXODBC26.hpp"
#endif
#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSUS27_h
#include "CXODUS27.hpp"
#endif
#ifndef CXOSRU15_h
#include "CXODRU15.hpp"
#endif
#ifndef CXOSBC40_h
#include "CXODBC40.hpp"
#endif
#ifndef CXOSBS19_h
#include "CXODBS19.hpp"
#endif
#ifndef CXOSBC35_h
#include "CXODBC35.hpp"
#endif
#ifndef CXOSBC36_h
#include "CXODBC36.hpp"
#endif


//## begin module%4DC02E8B01C1.declarations preserve=no
//## end module%4DC02E8B01C1.declarations

//## begin module%4DC02E8B01C1.additionalDeclarations preserve=yes
//## end module%4DC02E8B01C1.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
int SOAPCommand::m_iInstance = 0;
//## end command%3459269903E2.initialDeclarations

// Class command::SOAPCommand 

SOAPCommand::SOAPCommand()
  //## begin SOAPCommand::SOAPCommand%4DC02CEB0096_const.hasinit preserve=no
      : m_iMaxRows(100),
        m_iReplyLength(0),
        m_iRows(0),
        m_iSkipRows(0),
        m_iTotalRows(0),
        m_pZipText(0),
        m_pTextSegment(0),
        m_pXMLItem(0),
        m_pXMLHandler(0),
        m_pXMLDocument(0)
  //## end SOAPCommand::SOAPCommand%4DC02CEB0096_const.hasinit
  //## begin SOAPCommand::SOAPCommand%4DC02CEB0096_const.initialization preserve=yes
  //## end SOAPCommand::SOAPCommand%4DC02CEB0096_const.initialization
{
  //## begin command::SOAPCommand::SOAPCommand%4DC02CEB0096_const.body preserve=yes
  //## end command::SOAPCommand::SOAPCommand%4DC02CEB0096_const.body
}

SOAPCommand::SOAPCommand (const char* pszMessageID, const char* pszQueue)
  //## begin command::SOAPCommand::SOAPCommand%4DC04DAF03D3.hasinit preserve=no
      : m_iMaxRows(100),
        m_iReplyLength(0),
        m_iRows(0),
        m_iSkipRows(0),
        m_iTotalRows(0),
        m_pZipText(0),
        m_pTextSegment(0),
        m_pXMLItem(0),
        m_pXMLHandler(0),
        m_pXMLDocument(0)
  //## end command::SOAPCommand::SOAPCommand%4DC04DAF03D3.hasinit
  //## begin command::SOAPCommand::SOAPCommand%4DC04DAF03D3.initialization preserve=yes
   ,ClientCommand(pszMessageID,pszQueue)
  //## end command::SOAPCommand::SOAPCommand%4DC04DAF03D3.initialization
{
  //## begin command::SOAPCommand::SOAPCommand%4DC04DAF03D3.body preserve=yes
   memcpy(m_sID,"BC36",4);
   m_pTextSegment = new TextSegment();
   m_hSegments.push_back(m_pTextSegment);
   if (++m_iInstance == 1)
      XMLPlatformUtils::Initialize();
   string strRecord;
   m_hRow.attach(this);
  //## end command::SOAPCommand::SOAPCommand%4DC04DAF03D3.body
}


SOAPCommand::~SOAPCommand()
{
  //## begin command::SOAPCommand::~SOAPCommand%4DC02CEB0096_dest.body preserve=yes
   delete m_pTextSegment;
   delete m_pXMLItem;
   delete m_pXMLHandler;
   if (--m_iInstance == 0)
      XMLPlatformUtils::Terminate();
   delete m_pXMLDocument;
  //## end command::SOAPCommand::~SOAPCommand%4DC02CEB0096_dest.body
}



//## Other Operations (implementation)
void SOAPCommand::attribute (const string& strTag, const string& strAttribute, const string& strValue)
{
  //## begin command::SOAPCommand::attribute%5DDD341801E6.body preserve=yes
  //## end command::SOAPCommand::attribute%5DDD341801E6.body
}

bool SOAPCommand::endElement (const string& strTag)
{
  //## begin command::SOAPCommand::endElement%5B47CAFF023E.body preserve=yes
   if (strTag == "Pswrd"
      || strTag == "password")
   {
      int iRC = 0;
#ifndef MVS
      if (OpenLDAP::instance()->isActive())
      {
         string strResult;
         string strNewPassword;
         if ((OpenLDAP::instance()->logon(SOAPSegment::instance()->getUSER_ID(), SOAPSegment::instance()->getUSER_PASSWORD(), strNewPassword, strResult))
         && strResult == "")
            SOAPSegment::instance()->setRACFRtnCde(0);
         else
         {
            iRC = atoi(strResult.substr(2, 3).c_str());
            SOAPSegment::instance()->setRACFRtnCde(iRC);
         }
      }
      else
#endif
      {
         iRC = Security::instance()->authenticateUser(CommonHeaderSegment::instance()->getUserID(), SOAPSegment::instance()->getUSER_PASSWORD());
         SOAPSegment::instance()->setRACFRtnCde(iRC);
      }
      if (iRC > 0)
      {
         SOAPSegment::instance()->setMsg("BC36.1","Authentication","User is not authorized");
         SOAPSegment::instance()->setRtnCde('4');
         return false;
      }
#ifndef MVS
      if (OpenLDAP::instance()->isActive() == false)
#endif
      {
         SOAPSegment::instance()->setMsg("BC36.2", "Password Expiry", 
            Security::instance()->getPasswordExpiration(SOAPSegment::instance()->getUSER_ID()));
      }
   }
   return true;
  //## end command::SOAPCommand::endElement%5B47CAFF023E.body
}

int SOAPCommand::parse ()
{
  //## begin command::SOAPCommand::parse%4DC031CF0372.body preserve=yes
   SOAPSegment::instance()->reset();
   SOAPSegment::instance()->setRtnCde('0');
   m_iRows = 0;
   m_iMaxRows = 0;
   m_iSkipRows = 0;
   m_iTotalRows = 0;
   ClientCommand::parse();
   bool bContentBegin = false;
   string strRequest;
   if (!m_pTextSegment->presence())
   {
      segment::SOAPSegment::instance()->setTxt("Invalid request");
      return SOAPSegment::instance()->setRtnCde('3');
   }
   m_hHeader.erase(m_hHeader.begin(),m_hHeader.end());
   if (m_pTextSegment->getText().length() > 7
      && (memcmp(m_pTextSegment->getText().data(),"POST ",5) == 0
      || memcmp(m_pTextSegment->getText().data(),"GET ",4) == 0
      || memcmp(m_pTextSegment->getText().data(),"PUT ",4) == 0
      || memcmp(m_pTextSegment->getText().data(),"DELETE ",7) == 0
      || memcmp(m_pTextSegment->getText().data(),"OPTIONS ",8) == 0))
   {
      Buffer::parse(m_pTextSegment->getText(),"\n",m_hHeader);
      for (int j = 0;j < m_hHeader.size();++j)
      {
         if (m_hHeader[j].size() > 7
            && memcmp(m_hHeader[j].data(),"count: ",7) == 0)
         {
            m_iMaxRows = atoi(m_hHeader[j].c_str() + 7);
         }
         if (m_hHeader[j].size() > 7
            && memcmp(m_hHeader[j].data(),"index: ",7) == 0)
         {
            m_iSkipRows = atoi(m_hHeader[j].c_str() + 7);
         }
         if (m_hHeader[j].size() > 21
            && (memcmp(m_hHeader[j].data(),"Authorization: Basic ",21) == 0
            || memcmp(m_hHeader[j].data(),"authorization: Basic ",21) == 0))
         {
            unsigned char szCiphertext[109];
            memset(szCiphertext,' ',108);
            szCiphertext[108] = '\0';
            unsigned char szBase64text[109];
            memset(szBase64text,' ',108);
            memcpy(szBase64text,m_hHeader[j].data() + 21,m_hHeader[j].length() - 21);
            szBase64text[108] = '\0';
            int k = securitywrapper::SecurityWrapper::EVP_DecodeBlock((unsigned char*)szCiphertext,szBase64text, m_hHeader[j].length() - 21);
            if (k > 0)
            {
               string strText((char*)szCiphertext);
               rtrim(strText);
               vector<string> hToken;
               Buffer::parse(strText,":",hToken);
               if (hToken.size() == 2)
               {
                  segment::CommonHeaderSegment::instance()->setUserID(hToken[0]);
                  segment::SOAPSegment::instance()->setUSER_ID(hToken[0]);
                  segment::SOAPSegment::instance()->setUSER_PASSWORD(hToken[1]);
                  endElement("password");
               }
            }
            m_hHeader[j].assign("session: xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
         }
         if (m_hHeader[j].size() > 9
            && memcmp(m_hHeader[j].data(),"session: ",9) == 0)
         {
            unsigned char szCiphertext[109];
            memset(szCiphertext,' ',108);
            szCiphertext[108] = '\0';
            unsigned char szBase64text[109];
            memset(szBase64text,' ',108);
            memcpy(szBase64text,m_hHeader[j].data() + 9,m_hHeader[j].length() - 9);
            szBase64text[108] = '\0';
            int k = securitywrapper::SecurityWrapper::EVP_DecodeBlock((unsigned char*)szCiphertext,szBase64text,m_hHeader[j].length() - 9);
            if (k > 0)
            {
               string strSecurityData((char*)szCiphertext);
               rtrim(strSecurityData);
               vector<string> hToken;
               Buffer::parse(strSecurityData,":",hToken);
               if (hToken.size() == 2)
               {
                  segment::CommonHeaderSegment::instance()->setUserID(hToken[0]);
                  segment::SOAPSegment::instance()->setUSER_ID(hToken[0]);
               }
            }
         }
         ltrim(m_hHeader[j]);
         if(!strRequest.empty())
            strRequest += m_hHeader[j];
         else
         {
            if (bContentBegin
               && (m_hHeader[j][0] == '{'
               || m_hHeader[j][0] == '<'))
               strRequest.assign(m_hHeader[j]);
            else if (j > 1 && m_hHeader[j].empty() && m_hHeader[j-1].empty())
               bContentBegin = true;
         }
      }
      if (strRequest == "{}" || strRequest.empty())
      {
         string strEmpty;
         m_pTextSegment->setText(strEmpty);
      }
      else
      {
         if (strRequest[0] == '{')
            reusable::Format::JSONtoXML(strRequest);
         m_pTextSegment->setText(strRequest);
      }
   }
   if (m_pXMLItem == 0)
      m_pXMLItem = new XMLItem();
   m_pXMLItem->resetToken();
   if (m_pTextSegment->getText().empty())
   {
      m_hMessage = *Message::instance(Message::INBOUND);
      return SOAPSegment::instance()->getRtnCde()[0] - '0';
   }
   if (m_pXMLHandler == 0)
      m_pXMLHandler = new XMLHandler(m_pXMLItem,this);
   string strXML(m_pTextSegment->getText());
   XMLCh sBufld[2] = {1,0};
#ifdef MVS
   CodeTable::translate((char*)strXML.data(),(unsigned int)strXML.length(),CodeTable::CX_EBCDIC_TO_ASCII);
#endif
   for (int i = 0;i < strXML.length();++i)
      if (strXML[i] < 0x20)
         strXML[i] = 0x20;
   MemBufInputSource hMemBufInputSource((XMLByte*)strXML.data(),(unsigned int)strXML.length(),&sBufld[0]);
   SAXParser hSAXParser;
   hSAXParser.setDocumentHandler(m_pXMLHandler);
   hSAXParser.setErrorHandler(m_pXMLHandler);
   hSAXParser.setDisableDefaultEntityResolution(true); // protect against XXE attack
   bool bFound = false;
   size_t pos = strXML.find('!');
   while (pos != string::npos && pos + 7 < strXML.length())
   {
      if ((strXML[pos + 1] == 'D' || strXML[pos + 1] == 'd') &&
          (strXML[pos + 2] == 'O' || strXML[pos + 2] == 'o') &&
          (strXML[pos + 3] == 'C' || strXML[pos + 3] == 'c') &&
          (strXML[pos + 4] == 'T' || strXML[pos + 4] == 't') &&
          (strXML[pos + 5] == 'Y' || strXML[pos + 5] == 'y') &&
          (strXML[pos + 6] == 'P' || strXML[pos + 6] == 'p') &&
          (strXML[pos + 7] == 'E' || strXML[pos + 7] == 'e'))
      {
         SAXParseException exc(XMLString::transcode("Invalid tag <!DOCTYPE>"),XMLString::transcode("BC36"),XMLString::transcode("BC36"),0,0);
         m_pXMLHandler->fatalError(exc);
         bFound = true;
         break;
      }
      pos = strXML.find('!',pos + 1);
   }
   if (!bFound)
      hSAXParser.parse(hMemBufInputSource);
   m_hMessage = *Message::instance(Message::INBOUND);
   if (SOAPSegment::instance()->getRtnCde() == "3")
      return 3;
   if (SOAPSegment::instance()->getRtnCde() == "6")
      return 6;
   if (!m_pXMLItem->get("MaxRows").empty())
   {
      int iMaxRows = atoi(m_pXMLItem->get("MaxRows").c_str());
      setMaxRows(iMaxRows > 0 ? iMaxRows : 100);
   }
   else
   if (m_iMaxRows == 0)
      setMaxRows(100);
   if (!m_pXMLItem->get("MaxSize").empty())
   {
      int iMaxSize = atoi(m_pXMLItem->get("MaxSize").c_str());
      m_pXMLDocument->setMaximumSize(iMaxSize > 0 && iMaxSize <= 1000000 ? iMaxSize : 64000);
   }
   else
   if (m_pXMLDocument)
      m_pXMLDocument->setMaximumSize(64000);
   return SOAPSegment::instance()->getRtnCde()[0] - '0';
  //## end command::SOAPCommand::parse%4DC031CF0372.body
}

int SOAPCommand::reply ()
{
  //## begin command::SOAPCommand::reply%4DC81AAB00FF.body preserve=yes
   m_pXMLDocument->write("");
   string strTstInd;
   m_pXMLItem->get("TstInd",strTstInd);
   if (strTstInd == "Y")
      Database::instance()->rollback();
   else
      Database::instance()->commit();
   Message::instance(Message::INBOUND)->reserve(512 + m_strReply.length());
   *Message::instance(Message::INBOUND) = m_hMessage;
   Message::instance(Message::INBOUND)->reset("GM CI ","S0003R");
   m_pDataBuffer = Message::instance(Message::INBOUND)->data() + 8;
   CommonHeaderSegment::instance()->deport(&m_pDataBuffer);
   size_t pos = m_strReply.find("<RtnCde>");
   if(pos != string::npos)
      m_strReply[pos + 8] = segment::SOAPSegment::instance()->getRtnCde()[0];
   if(m_strReply.length() > 60
      && memcmp(m_strReply.data(),"</TransactionList></TransactionListOso></TransactionListRsp>",60) == 0)
   {
      m_strReply.erase(0,60);
      Trace::put("BC36 repair TransactionList",-1,true);
   }
   TextSegment hTextSegment;
   if (m_hHeader.size() > 1)
   {
      char szNewLine[2] = {" "};
      szNewLine[0] = 0x0A;
      string strResponse;
      if (segment::SOAPSegment::instance()->getRtnCde()[0] <= '2')
         strResponse.append("HTTP/1.1 200 OK");
      else
      if (segment::SOAPSegment::instance()->getRtnCde()[0] == '3')
         strResponse.append("HTTP/1.1 400 Bad Request");
      else
      if (segment::SOAPSegment::instance()->getRtnCde()[0] == '4')
         strResponse.append("HTTP/1.1 401 Unauthorized");
      else
         strResponse.append("HTTP/1.1 500 Internal Server Error");
      strResponse.append(szNewLine,1);
      strResponse.append("index: ");
      char szTemp[PERCENTD];
      strResponse.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%d",m_iRows));
      strResponse.append(szNewLine,1);
      strResponse.append("totalRecords: ");
      strResponse.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%d",m_iTotalRows));
      strResponse.append(szNewLine,1);
      for (int j = 0;j < m_hHeader.size();++j)
      {
         if ((m_hHeader[j].size() > 9
            && memcmp(m_hHeader[j].data(),"session: ",9) == 0)
            || (m_hHeader[j].size() > 6
            && memcmp(m_hHeader[j].data(),"uuid: ",6) == 0)
            || (m_hHeader[j].size() > 14
            && memcmp(m_hHeader[j].data(),"Content-Type: ",14) == 0))
         {
            strResponse += m_hHeader[j];
            strResponse.append(szNewLine,1);
         }
      }
      strResponse.append("Access-Control-Allow-Origin: *");
      strResponse.append(szNewLine,1);
      strResponse.append("Content-Length: ");
      char szLength[8];
      snprintf(szLength,sizeof(szLength),"%d",m_strReply.length());
      strResponse.append(szLength);
      strResponse.append(szNewLine,1);
      strResponse.append(szNewLine,1);
      strResponse += m_strReply;
      hTextSegment.setText(strResponse);
   }
   else
      hTextSegment.setText(m_strReply);
   m_strReply.erase();
   hTextSegment.deport(&m_pDataBuffer);
   return ClientCommand::reply();
  //## end command::SOAPCommand::reply%4DC81AAB00FF.body
}

void SOAPCommand::reset ()
{
  //## begin command::SOAPCommand::reset%4E983F9C0098.body preserve=yes
   segment::SOAPSegment::instance()->reset();
   m_strReply.erase();
   if (m_pXMLItem)
      m_pXMLItem->reset();
  //## end command::SOAPCommand::reset%4E983F9C0098.body
}

void SOAPCommand::revert ()
{
  //## begin command::SOAPCommand::revert%5DD4048101DD.body preserve=yes
   m_strReply.resize(m_iReplyLength);
   m_pXMLDocument->revert();
  //## end command::SOAPCommand::revert%5DD4048101DD.body
}

void SOAPCommand::save ()
{
  //## begin command::SOAPCommand::save%5DD404770353.body preserve=yes
   m_iReplyLength = m_strReply.length();
   m_pXMLDocument->save();
  //## end command::SOAPCommand::save%5DD404770353.body
}

void SOAPCommand::secure (reusable::Query& hQuery, const char* pszTable)
{
  //## begin command::SOAPCommand::secure%5412D9FB0108.body preserve=yes
   const set<string>& hEntityLevel = User::instance()->getEntityLevel();
   if (hEntityLevel.find("*") != hEntityLevel.end())
      return;
   if (hEntityLevel.empty())
   {
      SOAPSegment::instance()->setRtnCde('4');
      return;
   }
   usersegment::AsRoleRelation::instance(); //get load out of the way, interfers with static predicates
   Query q;
   auto_ptr<reusable::FormatSelectVisitor>pFormatSelectVisitor((reusable::FormatSelectVisitor*)database::DatabaseFactory::instance()->create("FormatSelectVisitor"));
   string strSubSelect;
   if (hEntityLevel.find("PROC") != hEntityLevel.end())
   {
      q.setDistinct(true);
      q.setSubSelect(true);
      q.setQualifier("QUALIFY", "AS_USER_PROFILE");
      q.setQualifier("QUALIFY", "AS_ENTITY_ROLE");
      q.setQualifier("QUALIFY", "AS_ROLE_RELATION");
      q.join("AS_USER_PROFILE", "INNER", "AS_ENTITY_ROLE", "ENTITY_ID");
      q.join("AS_ENTITY_ROLE", "INNER", "AS_ROLE_RELATION", "ROLE_ID");
      q.bind("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", Column::STRING, 0);
      q.setBasicPredicate("AS_USER_PROFILE", "USER_ID", "=", CommonHeaderSegment::instance()->getUserID().c_str());
      q.setBasicPredicate("AS_USER_PROFILE", "CUST_ID", "=", CommonHeaderSegment::instance()->getCUST_ID().c_str());
      q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "LIKE", "PROC_ID%");
      q.accept(*pFormatSelectVisitor);
      strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ")";
      if (!hQuery.getSearchCondition().empty())
         hQuery.getSearchCondition().append(" AND");
      hQuery.getSearchCondition().append(" (");
      usersegment::AsRoleRelation::instance()->setBasicPredicate(hQuery, pszTable, strSubSelect.c_str(), "PROC");
   }
   if (hEntityLevel.find("PROCGRP") != hEntityLevel.end())
   {
      q.reset();
      q.setDistinct(true);
      q.setSubSelect(true);
      q.setQualifier("QUALIFY", "AS_USER_PROFILE");
      q.setQualifier("QUALIFY", "AS_ENTITY_ROLE");
      q.setQualifier("QUALIFY", "AS_ROLE_RELATION");
      q.join("AS_USER_PROFILE", "INNER", "AS_ENTITY_ROLE", "ENTITY_ID");
      q.join("AS_ENTITY_ROLE", "INNER", "AS_ROLE_RELATION", "ROLE_ID");
      q.bind("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", Column::STRING, 0);
      q.setBasicPredicate("AS_USER_PROFILE", "USER_ID", "=", CommonHeaderSegment::instance()->getUserID().c_str());
      q.setBasicPredicate("AS_USER_PROFILE", "CUST_ID", "=", CommonHeaderSegment::instance()->getCUST_ID().c_str());
      q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "LIKE", "PROC_GRP%");
      q.accept(*pFormatSelectVisitor);
      if (strSubSelect.empty())
      {
         if (!hQuery.getSearchCondition().empty())
            hQuery.getSearchCondition().append(" AND");
         hQuery.getSearchCondition().append(" (");
      }
      strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ")";
      usersegment::AsRoleRelation::instance()->setBasicPredicate(hQuery, pszTable, strSubSelect.c_str(), "PROCGRP");
   }
   if (hEntityLevel.find("INST") != hEntityLevel.end())
   {
      q.reset();
      q.setDistinct(true);
      q.setSubSelect(true);
      q.setQualifier("QUALIFY", "AS_USER_PROFILE");
      q.setQualifier("QUALIFY", "AS_ENTITY_ROLE");
      q.setQualifier("QUALIFY", "AS_ROLE_RELATION");
      q.join("AS_USER_PROFILE", "INNER", "AS_ENTITY_ROLE", "ENTITY_ID");
      q.join("AS_ENTITY_ROLE", "INNER", "AS_ROLE_RELATION", "ROLE_ID");
      q.bind("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", Column::STRING, 0);
      q.setBasicPredicate("AS_USER_PROFILE", "USER_ID", "=", CommonHeaderSegment::instance()->getUserID().c_str());
      q.setBasicPredicate("AS_USER_PROFILE", "CUST_ID", "=", CommonHeaderSegment::instance()->getCUST_ID().c_str());
      q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "LIKE", "INST%");
      q.accept(*pFormatSelectVisitor);
      if (strSubSelect.empty())
      {
         if (!hQuery.getSearchCondition().empty())
            hQuery.getSearchCondition().append(" AND");
         hQuery.getSearchCondition().append(" (");
      }
      strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ")";
      usersegment::AsRoleRelation::instance()->setBasicPredicate(hQuery, pszTable, strSubSelect.c_str(), "INST");
   }

   if (hEntityLevel.find("RPTLVL") != hEntityLevel.end())
   {
      q.reset();
      q.setDistinct(true);
      q.setSubSelect(true);
      q.setQualifier("QUALIFY", "AS_USER_PROFILE");
      q.setQualifier("QUALIFY", "AS_ENTITY_ROLE");
      q.setQualifier("QUALIFY", "AS_ROLE_RELATION");
      q.join("AS_USER_PROFILE", "INNER", "AS_ENTITY_ROLE", "ENTITY_ID");
      q.join("AS_ENTITY_ROLE", "INNER", "AS_ROLE_RELATION", "ROLE_ID");
      q.bind("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", Column::STRING, 0);
      q.setBasicPredicate("AS_USER_PROFILE", "USER_ID", "=", CommonHeaderSegment::instance()->getUserID().c_str());
      q.setBasicPredicate("AS_USER_PROFILE", "CUST_ID", "=", CommonHeaderSegment::instance()->getCUST_ID().c_str());
      q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "LIKE", "RPT%");
      q.accept(*pFormatSelectVisitor);
      if (strSubSelect.empty())
      {
         if (!hQuery.getSearchCondition().empty())
            hQuery.getSearchCondition().append(" AND");
         hQuery.getSearchCondition().append(" (");
      }
      strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ")";
      hQuery.setBasicPredicate(pszTable, "RPT_LVL_ID_B", "IN", strSubSelect.c_str(), false, false);
   }
   if (hEntityLevel.find("DEVICE") != hEntityLevel.end())
   {
      q.reset();
      q.setDistinct(true);
      q.setSubSelect(true);
      q.setQualifier("QUALIFY", "AS_USER_PROFILE");
      q.setQualifier("QUALIFY", "AS_ENTITY_ROLE");
      q.setQualifier("QUALIFY", "AS_ROLE_RELATION");
      q.join("AS_USER_PROFILE", "INNER", "AS_ENTITY_ROLE", "ENTITY_ID");
      q.join("AS_ENTITY_ROLE", "INNER", "AS_ROLE_RELATION", "ROLE_ID");
      q.bind("AS_ENTITY_ROLE", "ONLINE_ENTITY_ID", Column::STRING, 0);
      q.setBasicPredicate("AS_USER_PROFILE", "USER_ID", "=", CommonHeaderSegment::instance()->getUserID().c_str());
      q.setBasicPredicate("AS_USER_PROFILE", "CUST_ID", "=", CommonHeaderSegment::instance()->getCUST_ID().c_str());
      q.setBasicPredicate("AS_ROLE_RELATION", "STS_TRAN_COL_NAME", "LIKE", "NET_TERM%");
      q.accept(*pFormatSelectVisitor);
      if (strSubSelect.empty())
      {
         if (!hQuery.getSearchCondition().empty())
            hQuery.getSearchCondition().append(" AND");
         hQuery.getSearchCondition().append(" (");
      }
      strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ")";
      hQuery.setBasicPredicate(pszTable, "NET_TERM_ID", "IN", strSubSelect.c_str(), false, false);
   }
   if (!strSubSelect.empty())
      hQuery.getSearchCondition().append(")");
   q.reset();  //erase static predicates
  //## end command::SOAPCommand::secure%5412D9FB0108.body
}

bool SOAPCommand::startElement (const string& strTag)
{
  //## begin command::SOAPCommand::startElement%5B4CECAB02BF.body preserve=yes
   return true;
  //## end command::SOAPCommand::startElement%5B4CECAB02BF.body
}

void SOAPCommand::update (Subject* pSubject)
{
  //## begin command::SOAPCommand::update%530509AA01AC.body preserve=yes
   if (pSubject == &m_hRow)
   {
      if (m_strReply.empty())
      {
         m_pXMLDocument->add("MsgLst");
         for (int i = 0, j = 0; i < SOAPSegment::instance()->getMsgCount(); i++)
         {
            SOAPSegment::instance()->setMsgCde(SOAPSegment::instance()->getMsg(j++));
            SOAPSegment::instance()->setTyp(SOAPSegment::instance()->getMsg(j++));
            SOAPSegment::instance()->setTxt(SOAPSegment::instance()->getMsg(j++));
            m_pXMLDocument->add("Msg");
         }
      }
      m_strReply.append(m_hRow.getBuffer());
      return;
   }
   ClientCommand::update (pSubject);
  //## end command::SOAPCommand::update%530509AA01AC.body
}

// Additional Declarations
  //## begin command::SOAPCommand%4DC02CEB0096.declarations preserve=yes
  //## end command::SOAPCommand%4DC02CEB0096.declarations

} // namespace command

//## begin module%4DC02E8B01C1.epilog preserve=yes
//## end module%4DC02E8B01C1.epilog
