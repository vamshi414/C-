//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%370BAD3B021B.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%370BAD3B021B.cm

//## begin module%370BAD3B021B.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%370BAD3B021B.cp

//## Module: CXOSBC12%370BAD3B021B; Package specification
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC12.hpp

#ifndef CXOSBC12_h
#define CXOSBC12_h 1

//## begin module%370BAD3B021B.additionalIncludes preserve=no
//## end module%370BAD3B021B.additionalIncludes

//## begin module%370BAD3B021B.includes preserve=yes
// $Date:   Apr 08 2004 11:17:20  $ $Author:   D02405  $ $Revision:   1.1  $
//## end module%370BAD3B021B.includes

#ifndef CXOSUS06_h
#include "CXODUS06.hpp"
#endif
#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Column;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class GetCustomizationSegment;
} // namespace usersegment

namespace reusable {
class SelectStatement;
class Query;
class Row;
} // namespace reusable

namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class ListSegment;

} // namespace segment

//## begin module%370BAD3B021B.declarations preserve=no
//## end module%370BAD3B021B.declarations

//## begin module%370BAD3B021B.additionalDeclarations preserve=yes
//## end module%370BAD3B021B.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::GetCustomizationCommand%3708C99A0235.preface preserve=yes
//## end command::GetCustomizationCommand%3708C99A0235.preface

//## Class: GetCustomizationCommand%3708C99A0235
//	QGETCUST - retrieve end user customization data.
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%370BBD3603AE;segment::InformationSegment { -> F}
//## Uses: <unnamed>%370BBEFC0375;IF::Message { -> F}
//## Uses: <unnamed>%370BBF4902D5;reusable::Query { -> F}
//## Uses: <unnamed>%370BBF4D00AA;reusable::Column { -> F}
//## Uses: <unnamed>%370BC58800C1;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%370BC5DB00E9;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%370CB2240108;usersegment::GetCustomizationSegment { -> F}
//## Uses: <unnamed>%370CBFF7027A;database::Database { -> F}
//## Uses: <unnamed>%3A008EBA008E;monitor::UseCase { -> F}
//## Uses: <unnamed>%3B682E38033C;reusable::Row { -> F}

class DllExport GetCustomizationCommand : public ClientListCommand  //## Inherits: <unnamed>%3B681E8701D4
{
  //## begin command::GetCustomizationCommand%3708C99A0235.initialDeclarations preserve=yes
  //## end command::GetCustomizationCommand%3708C99A0235.initialDeclarations

  public:
    //## Constructors (generated)
      GetCustomizationCommand();

    //## Constructors (specified)
      //## Operation: GetCustomizationCommand%3E96B33203C8
      GetCustomizationCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~GetCustomizationCommand();


    //## Other Operations (specified)
      //## Operation: update%370CBA750377
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin command::GetCustomizationCommand%3708C99A0235.public preserve=yes
      //## end command::GetCustomizationCommand%3708C99A0235.public

  protected:

    //## Other Operations (specified)
      //## Operation: retrieve%3B681EDC0280
      virtual bool retrieve ();

    // Additional Protected Declarations
      //## begin command::GetCustomizationCommand%3708C99A0235.protected preserve=yes
      //## end command::GetCustomizationCommand%3708C99A0235.protected

  private:
    // Additional Private Declarations
      //## begin command::GetCustomizationCommand%3708C99A0235.private preserve=yes
      //## end command::GetCustomizationCommand%3708C99A0235.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%371F2BAE03C5
      //## begin command::GetCustomizationCommand::Buffer%371F2BAE03C5.attr preserve=no  private: char* {V} 0
      char* m_pszBuffer;
      //## end command::GetCustomizationCommand::Buffer%371F2BAE03C5.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%370CC1260103
      //## Role: GetCustomizationCommand::<m_hCustomizationSegment>%370CC12700FA
      //## begin command::GetCustomizationCommand::<m_hCustomizationSegment>%370CC12700FA.role preserve=no  public: usersegment::CustomizationSegment { -> VHgN}
      usersegment::CustomizationSegment m_hCustomizationSegment;
      //## end command::GetCustomizationCommand::<m_hCustomizationSegment>%370CC12700FA.role

      //## Association: Connex Library::Command_CAT::<unnamed>%3EA01CDB00EA
      //## Role: GetCustomizationCommand::<m_pListSegment>%3EA01CDB02DE
      //## begin command::GetCustomizationCommand::<m_pListSegment>%3EA01CDB02DE.role preserve=no  public: segment::ListSegment { -> RFHgN}
      segment::ListSegment *m_pListSegment;
      //## end command::GetCustomizationCommand::<m_pListSegment>%3EA01CDB02DE.role

    // Additional Implementation Declarations
      //## begin command::GetCustomizationCommand%3708C99A0235.implementation preserve=yes
      //## end command::GetCustomizationCommand%3708C99A0235.implementation

};

//## begin command::GetCustomizationCommand%3708C99A0235.postscript preserve=yes
//## end command::GetCustomizationCommand%3708C99A0235.postscript

} // namespace command

//## begin module%370BAD3B021B.epilog preserve=yes
using namespace command;
//## end module%370BAD3B021B.epilog


#endif
