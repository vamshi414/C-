//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4C23C86402DE.cm preserve=no
//	$Date:   Jun 19 2017 14:32:34  $ $Author:   e1094689  $ $Revision:   1.10  $
//## end module%4C23C86402DE.cm

//## begin module%4C23C86402DE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4C23C86402DE.cp

//## Module: CXOSBC33%4C23C86402DE; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.8A.R005\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC33.hpp

#ifndef CXOSBC33_h
#define CXOSBC33_h 1

//## begin module%4C23C86402DE.additionalIncludes preserve=no
//## end module%4C23C86402DE.additionalIncludes

//## begin module%4C23C86402DE.includes preserve=yes
//## end module%4C23C86402DE.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Signal;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
class SocketQueue;
class Extract;
} // namespace IF

namespace reusable {
class Buffer;
} // namespace reusable

namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Command;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class XMLHandler;
class XMLItem;

} // namespace command

//## begin module%4C23C86402DE.declarations preserve=no
//## end module%4C23C86402DE.declarations

//## begin module%4C23C86402DE.additionalDeclarations preserve=yes
//## end module%4C23C86402DE.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::SOAPService%4C23C7D40167.preface preserve=yes
//## end command::SOAPService%4C23C7D40167.preface

//## Class: SOAPService%4C23C7D40167
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4C24DB6201E4;IF::Trace { -> F}
//## Uses: <unnamed>%4C24E6D00138;IF::Extract { -> F}
//## Uses: <unnamed>%4C59A2DF0186;IF::Message { -> F}
//## Uses: <unnamed>%4C62E7B70227;XMLHandler { -> F}
//## Uses: <unnamed>%4CC6EF6E0148;IF::CodeTable { -> F}
//## Uses: <unnamed>%4CC6F30001B2;process::Application { -> F}
//## Uses: <unnamed>%4D1262C10392;reusable::Buffer { -> F}
//## Uses: <unnamed>%4D13A82B0245;IF::SocketQueue { -> F}

class DllExport SOAPService : public reusable::Observer  //## Inherits: <unnamed>%4C59A07D03DB
{
  //## begin command::SOAPService%4C23C7D40167.initialDeclarations preserve=yes
  //## end command::SOAPService%4C23C7D40167.initialDeclarations

  public:
    //## Constructors (generated)
      SOAPService();

    //## Destructor (generated)
      virtual ~SOAPService();


    //## Other Operations (specified)
      //## Operation: post%4C23C94F0186
      virtual bool post (const char* pszName, segment::Command* pCommand, bool bHTTPS = false, bool bHTTP = true);

      //## Operation: update%4C59A0900003
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Text%4C60691D0101
      const string& getText () const
      {
        //## begin command::SOAPService::getText%4C60691D0101.get preserve=no
        return m_strText;
        //## end command::SOAPService::getText%4C60691D0101.get
      }


    // Additional Public Declarations
      //## begin command::SOAPService%4C23C7D40167.public preserve=yes
      //## end command::SOAPService%4C23C7D40167.public

  protected:
    // Data Members for Class Attributes

      //## begin command::SOAPService::Text%4C60691D0101.attr preserve=no  public: string {U} 
      string m_strText;
      //## end command::SOAPService::Text%4C60691D0101.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%4C62E516031A
      //## Role: SOAPService::<m_pXMLItem>%4C62E51703B6
      //## begin command::SOAPService::<m_pXMLItem>%4C62E51703B6.role preserve=no  public: command::XMLItem { -> RFHgN}
      XMLItem *m_pXMLItem;
      //## end command::SOAPService::<m_pXMLItem>%4C62E51703B6.role

    // Additional Protected Declarations
      //## begin command::SOAPService%4C23C7D40167.protected preserve=yes
      //## end command::SOAPService%4C23C7D40167.protected

  private:
    // Additional Private Declarations
      //## begin command::SOAPService%4C23C7D40167.private preserve=yes
      //## end command::SOAPService%4C23C7D40167.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%4CC6EE450142
      //## Role: SOAPService::<m_pSignal>%4CC6EE460096
      //## begin command::SOAPService::<m_pSignal>%4CC6EE460096.role preserve=no  public: static reusable::Signal { -> RFHgN}
      static reusable::Signal *m_pSignal;
      //## end command::SOAPService::<m_pSignal>%4CC6EE460096.role

      //## Association: Connex Library::Command_CAT::<unnamed>%559AD45000A7
      //## Role: SOAPService::<m_pCommand>%559AD451023D
      //## begin command::SOAPService::<m_pCommand>%559AD451023D.role preserve=no  public: segment::Command { -> RFHgN}
      segment::Command *m_pCommand;
      //## end command::SOAPService::<m_pCommand>%559AD451023D.role

    // Additional Implementation Declarations
      //## begin command::SOAPService%4C23C7D40167.implementation preserve=yes
      string m_strThread;
      //## end command::SOAPService%4C23C7D40167.implementation
};

//## begin command::SOAPService%4C23C7D40167.postscript preserve=yes
//## end command::SOAPService%4C23C7D40167.postscript

} // namespace command

//## begin module%4C23C86402DE.epilog preserve=yes
using namespace command;
//## end module%4C23C86402DE.epilog


#endif
