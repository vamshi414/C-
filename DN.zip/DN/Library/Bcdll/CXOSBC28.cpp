//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%48BEBE8A019F.cm preserve=no
//	$Date:   18 Jan 2018 13:53:08  $ $Author:   e1009839  $ $Revision:   1.3  $
//## end module%48BEBE8A019F.cm

//## begin module%48BEBE8A019F.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%48BEBE8A019F.cp

//## Module: CXOSBC28%48BEBE8A019F; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC28.cpp

//## begin module%48BEBE8A019F.additionalIncludes preserve=no
//## end module%48BEBE8A019F.additionalIncludes

//## begin module%48BEBE8A019F.includes preserve=yes
#include "CXODUS25.hpp"
//## end module%48BEBE8A019F.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBC26_h
#include "CXODBC26.hpp"
#endif
#ifndef CXOSBC28_h
#include "CXODBC28.hpp"
#endif


//## begin module%48BEBE8A019F.declarations preserve=no
//## end module%48BEBE8A019F.declarations

//## begin module%48BEBE8A019F.additionalDeclarations preserve=yes
//## end module%48BEBE8A019F.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::KeyXchgCommand 

KeyXchgCommand::KeyXchgCommand()
  //## begin KeyXchgCommand::KeyXchgCommand%48BEBE650264_const.hasinit preserve=no
      : m_pKeyExchangeSegment(0)
  //## end KeyXchgCommand::KeyXchgCommand%48BEBE650264_const.hasinit
  //## begin KeyXchgCommand::KeyXchgCommand%48BEBE650264_const.initialization preserve=yes
  ,ClientCommand("S0005D","@KEYXCHG" )
  //## end KeyXchgCommand::KeyXchgCommand%48BEBE650264_const.initialization
{
  //## begin command::KeyXchgCommand::KeyXchgCommand%48BEBE650264_const.body preserve=yes
   memcpy(m_sID,"BC28",4);
   m_pKeyExchangeSegment = new usersegment::KeyExchangeSegment();
   m_hSegments.push_back(m_pKeyExchangeSegment);
  //## end command::KeyXchgCommand::KeyXchgCommand%48BEBE650264_const.body
}

KeyXchgCommand::KeyXchgCommand (Handler* pSuccessor)
  //## begin command::KeyXchgCommand::KeyXchgCommand%490B65D70105.hasinit preserve=no
      : m_pKeyExchangeSegment(0)
  //## end command::KeyXchgCommand::KeyXchgCommand%490B65D70105.hasinit
  //## begin command::KeyXchgCommand::KeyXchgCommand%490B65D70105.initialization preserve=yes
  ,ClientCommand("S0005D","@KEYXCHG" )
  //## end command::KeyXchgCommand::KeyXchgCommand%490B65D70105.initialization
{
  //## begin command::KeyXchgCommand::KeyXchgCommand%490B65D70105.body preserve=yes
   memcpy(m_sID,"BC28",4);
   m_pSuccessor = pSuccessor;
   m_pKeyExchangeSegment = usersegment::KeyExchangeSegment::instance();
   m_hSegments.push_back(m_pKeyExchangeSegment);
  //## end command::KeyXchgCommand::KeyXchgCommand%490B65D70105.body
}


KeyXchgCommand::~KeyXchgCommand()
{
  //## begin command::KeyXchgCommand::~KeyXchgCommand%48BEBE650264_dest.body preserve=yes
  //## end command::KeyXchgCommand::~KeyXchgCommand%48BEBE650264_dest.body
}



//## Other Operations (implementation)
bool KeyXchgCommand::execute ()
{
  //## begin command::KeyXchgCommand::execute%490B62640169.body preserve=yes
   UseCase hUseCase("CLIENT","## CL05 KEY EXCHANGE");
   int iRC;
   if ((iRC = Command::parse()) != 0)
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,iRC);
      return false;
   }
   int lInfoIDNumber = Security::instance()->keyXchgRequest();
   if (lInfoIDNumber != 0)
   {
      sendError(STS_SECURITY_ERROR,STS_ERROR,lInfoIDNumber);
      return false;
   }
   Message::instance(Message::INBOUND)->reset("CRQCI ", "S0003R",true);
   m_pDataBuffer = Message::instance(Message::INBOUND)->data() + 8;
   CommonHeaderSegment::instance()->deport(&m_pDataBuffer);
   usersegment::KeyExchangeSegment::instance()->deport(&m_pDataBuffer);
   reply();
   return true;
  //## end command::KeyXchgCommand::execute%490B62640169.body
}

// Additional Declarations
  //## begin command::KeyXchgCommand%48BEBE650264.declarations preserve=yes
  //## end command::KeyXchgCommand%48BEBE650264.declarations

} // namespace command

//## begin module%48BEBE8A019F.epilog preserve=yes
//## end module%48BEBE8A019F.epilog
