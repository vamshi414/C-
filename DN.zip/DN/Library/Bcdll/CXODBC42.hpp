//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52FB8D450127.cm preserve=no
//	$Date:   Dec 09 2014 15:11:58  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%52FB8D450127.cm

//## begin module%52FB8D450127.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52FB8D450127.cp

//## Module: CXOSBC42%52FB8D450127; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC42.hpp

#ifndef CXOSBC42_h
#define CXOSBC42_h 1

//## begin module%52FB8D450127.additionalIncludes preserve=no
//## end module%52FB8D450127.additionalIncludes

//## begin module%52FB8D450127.includes preserve=yes
#include <map>
#include <vector>
//## end module%52FB8D450127.includes

#ifndef CXOSBC44_h
#include "CXODBC44.hpp"
#endif
#ifndef CXOSBC43_h
#include "CXODBC43.hpp"
#endif
#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class DeleteObject;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class GenericSegment;
} // namespace segment

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Column;

} // namespace database

//## begin module%52FB8D450127.declarations preserve=no
//## end module%52FB8D450127.declarations

//## begin module%52FB8D450127.additionalDeclarations preserve=yes
//## end module%52FB8D450127.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::LongData%52FB820303BB.preface preserve=yes
//## end command::LongData%52FB820303BB.preface

//## Class: LongData%52FB820303BB
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%52FB82ED00CD;Tag { -> }
//## Uses: <unnamed>%52FBA8BB0298;IF::FlatFile { -> F}
//## Uses: <unnamed>%52FD85C8006E;reusable::DeleteObject { -> F}
//## Uses: <unnamed>%5485E8C2003D;database::Column { -> F}
//## Uses: <unnamed>%5485E8CF01A6;segment::GenericSegment { -> F}

class DllExport LongData : public reusable::Object  //## Inherits: <unnamed>%52FB822500F6
{
  //## begin command::LongData%52FB820303BB.initialDeclarations preserve=yes
  //## end command::LongData%52FB820303BB.initialDeclarations

  public:
    //## Constructors (generated)
      LongData();

    //## Destructor (generated)
      virtual ~LongData();


    //## Other Operations (specified)
      //## Operation: _field%52FB89CE01BC
      bool _field (const segment::GenericSegment& hGenericSegment, const char* pszName, string& strValue);

      //## Operation: initialize%52FD3871032C
      void initialize (multimap<string,database::Column,less<string> >& hTag);

      //## Operation: instance%52FB8238002D
      static LongData* instance ();

    // Additional Public Declarations
      //## begin command::LongData%52FB820303BB.public preserve=yes
      //## end command::LongData%52FB820303BB.public

  protected:
    // Additional Protected Declarations
      //## begin command::LongData%52FB820303BB.protected preserve=yes
      //## end command::LongData%52FB820303BB.protected

  private:
    // Additional Private Declarations
      //## begin command::LongData%52FB820303BB.private preserve=yes
      //## end command::LongData%52FB820303BB.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%52FB82500207
      //## begin command::LongData::Instance%52FB82500207.attr preserve=no  private: static LongData* {V} 0
      static LongData* m_pInstance;
      //## end command::LongData::Instance%52FB82500207.attr

      //## Attribute: Tag%52FB82F3028F
      //## begin command::LongData::Tag%52FB82F3028F.attr preserve=no  private: multimap<string,Tag,less<string> > {V} 
      multimap<string,Tag,less<string> > m_hTag;
      //## end command::LongData::Tag%52FB82F3028F.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%52FB8F0E03E0
      //## Role: LongData::<m_hConstraint>%52FB8F0F0302
      //## begin command::LongData::<m_hConstraint>%52FB8F0F0302.role preserve=no  public: command::Constraint {1 -> 0..nRHgN}
      vector<Constraint*> m_hConstraint;
      //## end command::LongData::<m_hConstraint>%52FB8F0F0302.role

    // Additional Implementation Declarations
      //## begin command::LongData%52FB820303BB.implementation preserve=yes
      //## end command::LongData%52FB820303BB.implementation

};

//## begin command::LongData%52FB820303BB.postscript preserve=yes
//## end command::LongData%52FB820303BB.postscript

} // namespace command

//## begin module%52FB8D450127.epilog preserve=yes
//## end module%52FB8D450127.epilog


#endif
