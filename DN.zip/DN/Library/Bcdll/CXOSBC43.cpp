//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52FB8D960330.cm preserve=no
//	$Date:   Feb 14 2014 16:30:02  $ $Author:   e1009839  $ $Revision:   1.0  $
//## end module%52FB8D960330.cm

//## begin module%52FB8D960330.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52FB8D960330.cp

//## Module: CXOSBC43%52FB8D960330; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.4B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC43.cpp

//## begin module%52FB8D960330.additionalIncludes preserve=no
//## end module%52FB8D960330.additionalIncludes

//## begin module%52FB8D960330.includes preserve=yes
//## end module%52FB8D960330.includes

#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBC44_h
#include "CXODBC44.hpp"
#endif
#ifndef CXOSBC43_h
#include "CXODBC43.hpp"
#endif


//## begin module%52FB8D960330.declarations preserve=no
//## end module%52FB8D960330.declarations

//## begin module%52FB8D960330.additionalDeclarations preserve=yes
//## end module%52FB8D960330.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::Tag 

Tag::Tag()
  //## begin Tag::Tag%52FB82C000F1_const.hasinit preserve=no
      : m_iLength(0),
        m_iOffset(0),
        m_pConstraint(0)
  //## end Tag::Tag%52FB82C000F1_const.hasinit
  //## begin Tag::Tag%52FB82C000F1_const.initialization preserve=yes
  //## end Tag::Tag%52FB82C000F1_const.initialization
{
  //## begin command::Tag::Tag%52FB82C000F1_const.body preserve=yes
   memcpy(m_sID,"BC43",4);
  //## end command::Tag::Tag%52FB82C000F1_const.body
}

Tag::Tag(const Tag &right)
  //## begin Tag::Tag%52FB82C000F1_copy.hasinit preserve=no
  //## end Tag::Tag%52FB82C000F1_copy.hasinit
  //## begin Tag::Tag%52FB82C000F1_copy.initialization preserve=yes
   : m_strName(right.m_strName)
   ,Object(right)
  //## end Tag::Tag%52FB82C000F1_copy.initialization
{
  //## begin command::Tag::Tag%52FB82C000F1_copy.body preserve=yes
   m_iOffset = right.m_iOffset;
   m_iLength = right.m_iLength;
   m_pConstraint = right.m_pConstraint;
  //## end command::Tag::Tag%52FB82C000F1_copy.body
}

Tag::Tag (const string& strName, int iOffset, int iLength, Constraint* pConstraint)
  //## begin command::Tag::Tag%52FB8BE3007C.hasinit preserve=no
      : m_iLength(0),
        m_iOffset(0),
        m_pConstraint(0)
  //## end command::Tag::Tag%52FB8BE3007C.hasinit
  //## begin command::Tag::Tag%52FB8BE3007C.initialization preserve=yes
   ,m_strName(strName)
  //## end command::Tag::Tag%52FB8BE3007C.initialization
{
  //## begin command::Tag::Tag%52FB8BE3007C.body preserve=yes
   memcpy(m_sID,"BC43",4);
   m_iOffset = iOffset;
   m_iLength = iLength;
   m_pConstraint = pConstraint;
  //## end command::Tag::Tag%52FB8BE3007C.body
}


Tag::~Tag()
{
  //## begin command::Tag::~Tag%52FB82C000F1_dest.body preserve=yes
  //## end command::Tag::~Tag%52FB82C000F1_dest.body
}


Tag & Tag::operator=(const Tag &right)
{
  //## begin command::Tag::operator=%52FB82C000F1_assign.body preserve=yes
   if (this == &right)
      return *this;
   Object::operator=(right);
   m_strName = right.m_strName;
   m_iOffset = right.m_iOffset;
   m_iLength = right.m_iLength;
   m_pConstraint = right.m_pConstraint;
   return *this;
  //## end command::Tag::operator=%52FB82C000F1_assign.body
}



//## Other Operations (implementation)
bool Tag::_field (const segment::GenericSegment& hGenericSegment, string& strValue) const
{
  //## begin command::Tag::_field%52FB83F6019A.body preserve=yes
   if (m_pConstraint->match(hGenericSegment))
   {
      string strTemp;
      if (hGenericSegment._field(m_strName.c_str(),strTemp,false,false))
      {
         strTemp.resize(m_iOffset + m_iLength,' ');
         strValue.assign(strTemp.data() + m_iOffset,m_iLength);
         return true;
      }
   }
   return false;
  //## end command::Tag::_field%52FB83F6019A.body
}

// Additional Declarations
  //## begin command::Tag%52FB82C000F1.declarations preserve=yes
  //## end command::Tag%52FB82C000F1.declarations

} // namespace command

//## begin module%52FB8D960330.epilog preserve=yes
//## end module%52FB8D960330.epilog
