//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64BF7BD20258.cm preserve=no
//## end module%64BF7BD20258.cm

//## begin module%64BF7BD20258.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64BF7BD20258.cp

//## Module: CXOSBC64%64BF7BD20258; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC64.hpp

#ifndef CXOSBC64_h
#define CXOSBC64_h 1

//## begin module%64BF7BD20258.additionalIncludes preserve=no
//## end module%64BF7BD20258.additionalIncludes

//## begin module%64BF7BD20258.includes preserve=yes
#ifdef _WIN32
#include "xercesc\framework\XMLFormatter.hpp"
#include "xercesc\framework\MemBufFormatTarget.hpp"
#include "xercesc\sax\HandlerBase.hpp"
#else
#include "xercesc/framework/XMLFormatter.hpp"
#include "xercesc/framework/MemBufFormatTarget.hpp"
#include "xercesc/sax/HandlerBase.hpp"
#endif
XERCES_CPP_NAMESPACE_USE
#include <vector>
#ifdef MVS
#define XMLSIZE unsigned int
#else
#define XMLSIZE XMLSize_t
#endif
//## end module%64BF7BD20258.includes

#ifndef CXOSBC34_h
#include "CXODBC34.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class IndustryData;

} // namespace command

//## begin module%64BF7BD20258.declarations preserve=no
//## end module%64BF7BD20258.declarations

//## begin module%64BF7BD20258.additionalDeclarations preserve=yes
//## end module%64BF7BD20258.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::IndustryDataHandler%64BF7E6E0066.preface preserve=yes
//## end command::IndustryDataHandler%64BF7E6E0066.preface

//## Class: IndustryDataHandler%64BF7E6E0066
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%64BFA060023C;IF::Trace { -> F}

class DllExport IndustryDataHandler : public HandlerBase  //## Inherits: <unnamed>%64BF829402F5
{
  //## begin command::IndustryDataHandler%64BF7E6E0066.initialDeclarations preserve=yes
  //## end command::IndustryDataHandler%64BF7E6E0066.initialDeclarations

  public:
    //## Constructors (generated)
      IndustryDataHandler();

    //## Constructors (specified)
      //## Operation: IndustryDataHandler%64BF84CE00AB
      IndustryDataHandler (XMLItem* pXMLItem, IndustryData* pIndustryData);

    //## Destructor (generated)
      virtual ~IndustryDataHandler();


    //## Other Operations (specified)
      //## Operation: characters%64BF9B9B00E1
      virtual void characters (const XMLCh* const chars, const XMLSIZE length);

      //## Operation: endElement%64BF842C0306
      virtual void endElement (const XMLCh* const name);

      //## Operation: error%64BF9D74016A
      virtual void error (const SAXParseException& exc);

      //## Operation: fatalError%64BF9DAC03DB
      virtual void fatalError (const SAXParseException& exc);

      //## Operation: getToken%64BF99B0035B
      void getToken (const char* pszFunction, const XMLCh* const psBuffer, size_t lLength);

      //## Operation: startElement%64BF8476033B
      virtual void startElement (const XMLCh* const name, AttributeList& attributes);

    // Additional Public Declarations
      //## begin command::IndustryDataHandler%64BF7E6E0066.public preserve=yes
      //## end command::IndustryDataHandler%64BF7E6E0066.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Element%64BF9B3003B6
      //## begin command::IndustryDataHandler::Element%64BF9B3003B6.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hElement;
      //## end command::IndustryDataHandler::Element%64BF9B3003B6.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%64BF858E014E
      //## Role: IndustryDataHandler::<m_pIndustryData>%64BF858E03D9
      //## begin command::IndustryDataHandler::<m_pIndustryData>%64BF858E03D9.role preserve=no  protected: command::IndustryData { -> RFHgN}
      IndustryData *m_pIndustryData;
      //## end command::IndustryDataHandler::<m_pIndustryData>%64BF858E03D9.role

      //## Association: Connex Library::Command_CAT::<unnamed>%64D655CA02E7
      //## Role: IndustryDataHandler::<m_pXMLItem>%64D655CB00FA
      //## begin command::IndustryDataHandler::<m_pXMLItem>%64D655CB00FA.role preserve=no  public: command::XMLItem { -> RHgN}
      XMLItem *m_pXMLItem;
      //## end command::IndustryDataHandler::<m_pXMLItem>%64D655CB00FA.role

    // Additional Protected Declarations
      //## begin command::IndustryDataHandler%64BF7E6E0066.protected preserve=yes
      //## end command::IndustryDataHandler%64BF7E6E0066.protected

  private:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Characters%64BF855702D5
      const string& getCharacters () const
      {
        //## begin command::IndustryDataHandler::getCharacters%64BF855702D5.get preserve=no
        return m_strCharacters;
        //## end command::IndustryDataHandler::getCharacters%64BF855702D5.get
      }


      //## Attribute: Token%64BF9AD103A4
      const string& getToken () const
      {
        //## begin command::IndustryDataHandler::getToken%64BF9AD103A4.get preserve=no
        return m_strToken;
        //## end command::IndustryDataHandler::getToken%64BF9AD103A4.get
      }


    // Additional Private Declarations
      //## begin command::IndustryDataHandler%64BF7E6E0066.private preserve=yes
      //## end command::IndustryDataHandler%64BF7E6E0066.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::IndustryDataHandler::Characters%64BF855702D5.attr preserve=no  private: string {U} 
      string m_strCharacters;
      //## end command::IndustryDataHandler::Characters%64BF855702D5.attr

      //## Attribute: Data%64BFA1D801C7
      //## begin command::IndustryDataHandler::Data%64BFA1D801C7.attr preserve=no  private: string {U} 
      string m_strData;
      //## end command::IndustryDataHandler::Data%64BFA1D801C7.attr

      //## Attribute: Index%64DA56390293
      //## begin command::IndustryDataHandler::Index%64DA56390293.attr preserve=no  private: int {U} 0
      int m_iIndex;
      //## end command::IndustryDataHandler::Index%64DA56390293.attr

      //## Attribute: MemBufFormatTarget%64BF9AB3003F
      //## begin command::IndustryDataHandler::MemBufFormatTarget%64BF9AB3003F.attr preserve=no  private: MemBufFormatTarget {U} 
      MemBufFormatTarget m_hMemBufFormatTarget;
      //## end command::IndustryDataHandler::MemBufFormatTarget%64BF9AB3003F.attr

      //## begin command::IndustryDataHandler::Token%64BF9AD103A4.attr preserve=no  private: string {U} 
      string m_strToken;
      //## end command::IndustryDataHandler::Token%64BF9AD103A4.attr

      //## Attribute: XMLFormatter%64BF9AEA03E7
      //## begin command::IndustryDataHandler::XMLFormatter%64BF9AEA03E7.attr preserve=no  private: XMLFormatter {U} 
      XMLFormatter m_hXMLFormatter;
      //## end command::IndustryDataHandler::XMLFormatter%64BF9AEA03E7.attr

    // Additional Implementation Declarations
      //## begin command::IndustryDataHandler%64BF7E6E0066.implementation preserve=yes
      //## end command::IndustryDataHandler%64BF7E6E0066.implementation

};

//## begin command::IndustryDataHandler%64BF7E6E0066.postscript preserve=yes
//## end command::IndustryDataHandler%64BF7E6E0066.postscript

} // namespace command

//## begin module%64BF7BD20258.epilog preserve=yes
//## end module%64BF7BD20258.epilog


#endif
