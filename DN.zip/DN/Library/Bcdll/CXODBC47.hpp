//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5625F0AC0326.cm preserve=no
//	$Date:   May 24 2016 11:03:10  $ $Author:   e1009510  $ $Revision:   1.0  $
//## end module%5625F0AC0326.cm

//## begin module%5625F0AC0326.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5625F0AC0326.cp

//## Module: CXOSBC47%5625F0AC0326; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC47.hpp

#ifndef CXOSBC47_h
#define CXOSBC47_h 1

//## begin module%5625F0AC0326.additionalIncludes preserve=no
//## end module%5625F0AC0326.additionalIncludes

//## begin module%5625F0AC0326.includes preserve=yes
#include <vector>
//## end module%5625F0AC0326.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSBC46_h
#include "CXODBC46.hpp"
#endif
//## begin module%5625F0AC0326.declarations preserve=no
//## end module%5625F0AC0326.declarations

//## begin module%5625F0AC0326.additionalDeclarations preserve=yes
//## end module%5625F0AC0326.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::Criteria%5625F06B0359.preface preserve=yes
//## end command::Criteria%5625F06B0359.preface

//## Class: Criteria%5625F06B0359
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport Criteria : public reusable::Object  //## Inherits: <unnamed>%5625F096014D
{
  //## begin command::Criteria%5625F06B0359.initialDeclarations preserve=yes
  //## end command::Criteria%5625F06B0359.initialDeclarations

  public:
    //## Constructors (generated)
      Criteria();

    //## Destructor (generated)
      virtual ~Criteria();


    //## Other Operations (specified)
      //## Operation: addCriteriaData%5628B89E01E5
      void addCriteriaData (const CriteriaData& hCriteriaData);

      //## Operation: addResult%5628B982037C
      void addResult (const string& strAttribute, const string& strValue);

      //## Operation: clear%5628B11A00B8
      void clear ();

      //## Operation: getCriteriaData%5628EDA00328
      vector<CriteriaData>& getCriteriaData ();

      //## Operation: getResult%5628EDDF032E
      vector<pair<string,string> >& getResult ();

    // Additional Public Declarations
      //## begin command::Criteria%5625F06B0359.public preserve=yes
      //## end command::Criteria%5625F06B0359.public

  protected:
    // Additional Protected Declarations
      //## begin command::Criteria%5625F06B0359.protected preserve=yes
      //## end command::Criteria%5625F06B0359.protected

  private:
    // Additional Private Declarations
      //## begin command::Criteria%5625F06B0359.private preserve=yes
      //## end command::Criteria%5625F06B0359.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Result%5625F410018D
      //## begin command::Criteria::Result%5625F410018D.attr preserve=no  public: vector<pair<string,string> > {U} 
      vector<pair<string,string> > m_hResult;
      //## end command::Criteria::Result%5625F410018D.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%56289F530125
      //## Role: Criteria::<m_hCriteriaData>%56289F54025B
      //## begin command::Criteria::<m_hCriteriaData>%56289F54025B.role preserve=no  public: command::CriteriaData {1 -> 0..nVHgN}
      vector<CriteriaData> m_hCriteriaData;
      //## end command::Criteria::<m_hCriteriaData>%56289F54025B.role

    // Additional Implementation Declarations
      //## begin command::Criteria%5625F06B0359.implementation preserve=yes
      //## end command::Criteria%5625F06B0359.implementation

};

//## begin command::Criteria%5625F06B0359.postscript preserve=yes
//## end command::Criteria%5625F06B0359.postscript

} // namespace command

//## begin module%5625F0AC0326.epilog preserve=yes
//## end module%5625F0AC0326.epilog


#endif
