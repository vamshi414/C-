//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E9AF352034B.cm preserve=no
//	$Date:   Jan 12 2021 14:27:54  $ $Author:   e1009839  $ $Revision:   1.55.2.6  $
//## end module%3E9AF352034B.cm

//## begin module%3E9AF352034B.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%3E9AF352034B.cp

//## Module: CXOSBC08%3E9AF352034B; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC08.cpp

//## begin module%3E9AF352034B.additionalIncludes preserve=no
//## end module%3E9AF352034B.additionalIncludes

//## begin module%3E9AF352034B.includes preserve=yes
#ifndef _UNIX
// This product includes software written by Tim Hudson (tjh@cryptsoft.com)
#include "CXODSW01.hpp"
#endif
#ifndef MVS
#include "CXODBC23.hpp"
#endif
#include "CXODDB34.hpp"
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
#include "CXODRU37.hpp"
//## end module%3E9AF352034B.includes

#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSUS19_h
#include "CXODUS19.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB23_h
#include "CXODDB23.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSBC26_h
#include "CXODBC26.hpp"
#endif
#ifndef CXOSBC27_h
#include "CXODBC27.hpp"
#endif
#ifndef CXOSBC28_h
#include "CXODBC28.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSUS03_h
#include "CXODUS03.hpp"
#endif
#ifndef CXOSBC08_h
#include "CXODBC08.hpp"
#endif


//## begin module%3E9AF352034B.declarations preserve=no
//## end module%3E9AF352034B.declarations

//## begin module%3E9AF352034B.additionalDeclarations preserve=yes
//## end module%3E9AF352034B.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::UserSession

//## begin command::UserSession::AliasCount%3E9BF82D0399.attr preserve=no  public: static int {V} 0
int UserSession::m_lAliasCount = 0;
//## end command::UserSession::AliasCount%3E9BF82D0399.attr

//## begin command::UserSession::Key%427F619B0177.attr preserve=no  private: static void* {V} 0
void* UserSession::m_pKey = 0;
//## end command::UserSession::Key%427F619B0177.attr

UserSession::UserSession()
  //## begin UserSession::UserSession%3E9AF2520222_const.hasinit preserve=no
      : m_pBuffer(0),
        m_pRelationshipSegment(0),
        m_pCommonHeaderSegment(0),
        m_pResponseTimeSegment(0),
        m_pLogonSegment(0)
  //## end UserSession::UserSession%3E9AF2520222_const.hasinit
  //## begin UserSession::UserSession%3E9AF2520222_const.initialization preserve=yes
  //## end UserSession::UserSession%3E9AF2520222_const.initialization
{
  //## begin command::UserSession::UserSession%3E9AF2520222_const.body preserve=yes
   memcpy_s(m_sID,4,"BC08",4);
   m_pCommonHeaderSegment = new CommonHeaderSegment();
   m_pLogonSegment = new LogonSegment();
   m_pResponseTimeSegment = new ResponseTimeSegment();
  //## end command::UserSession::UserSession%3E9AF2520222_const.body
}

UserSession::UserSession(const UserSession &right)
  //## begin UserSession::UserSession%3E9AF2520222_copy.hasinit preserve=no
      : m_pBuffer(0),
        m_pRelationshipSegment(0),
        m_pCommonHeaderSegment(0),
        m_pResponseTimeSegment(0),
        m_pLogonSegment(0)
  //## end UserSession::UserSession%3E9AF2520222_copy.hasinit
  //## begin UserSession::UserSession%3E9AF2520222_copy.initialization preserve=yes
   ,Session(right)
  //## end UserSession::UserSession%3E9AF2520222_copy.initialization
{
  //## begin command::UserSession::UserSession%3E9AF2520222_copy.body preserve=yes
   memcpy_s(m_sID,4,"BC08",4);
   m_pCommonHeaderSegment = new CommonHeaderSegment();
   m_pLogonSegment = new LogonSegment();
   m_pResponseTimeSegment = new ResponseTimeSegment();
  //## end command::UserSession::UserSession%3E9AF2520222_copy.body
}


UserSession::~UserSession()
{
  //## begin command::UserSession::~UserSession%3E9AF2520222_dest.body preserve=yes
   delete m_pResponseTimeSegment;
   delete m_pLogonSegment;
   delete m_pCommonHeaderSegment;
  //## end command::UserSession::~UserSession%3E9AF2520222_dest.body
}


UserSession & UserSession::operator=(const UserSession &right)
{
  //## begin command::UserSession::operator=%3E9AF2520222_assign.body preserve=yes
   m_hMessage = right.m_hMessage;
   m_strTimestamp = right.m_strTimestamp;
   m_hResourceListSegment = right.m_hResourceListSegment;
   return *this;
  //## end command::UserSession::operator=%3E9AF2520222_assign.body
}



//## Other Operations (implementation)
string UserSession::getAlias ()
{
  //## begin command::UserSession::getAlias%3E9BFB2C00CB.body preserve=yes
   char szTemp[PERCENTD + 1];
   int i = m_lAliasCount; // Fortify bug workaround
   snprintf(szTemp, PERCENTD + 1,"@%07d",i);
   return string(szTemp,8);
  //## end command::UserSession::getAlias%3E9BFB2C00CB.body
}

const string& UserSession::key () const
{
  //## begin command::UserSession::key%3E9BF862007D.body preserve=yes
   return (m_pCommonHeaderSegment->getSecurityData());
  //## end command::UserSession::key%3E9BF862007D.body
}

bool UserSession::logoffRequest (Message& hMessage, CommonHeaderSegment* pCommonHeaderSegment, ResponseTimeSegment* pResponseTimeSegment)
{
  //## begin command::UserSession::logoffRequest%3E9AF5120399.body preserve=yes
   m_hMessage = hMessage;
   *m_pCommonHeaderSegment = *pCommonHeaderSegment;
   *m_pResponseTimeSegment = *pResponseTimeSegment;
   setUserID(pCommonHeaderSegment->getAlias());
#ifdef MVS
   if(Security::instance()->getSecurityType() != "OPEN")
   {
      string strConversationID;
      return Session::logoff(hMessage,strConversationID);
   }
   return true;
#else
   return true;
#endif
  //## end command::UserSession::logoffRequest%3E9AF5120399.body
}

bool UserSession::logoffResponse (Message& hMessage)
{
  //## begin command::UserSession::logoffResponse%3E9D912C0222.body preserve=yes
#define SIZESIZE 8
   char szTemp[SIZESIZE + 1];
   m_hMessage.reset("CRQCI ","S0005R",true);
   m_pBuffer = m_hMessage.data() + SIZESIZE;
   m_pCommonHeaderSegment->deport(&m_pBuffer);
   m_pResponseTimeSegment->deport(&m_pBuffer);
   int m = (int)(m_pBuffer - m_hMessage.data());
   snprintf(szTemp,sizeof(szTemp),"%08d",m);
   memcpy_s(m_hMessage.data(),(size_t)SIZESIZE,szTemp,(size_t)SIZESIZE);
   m_hMessage.setDataLength(m);
   m_hMessage.reply();
   database::AuditEvent::capture(m_hMessage);
   database::AuditEvent::commit(true);
#undef SIZESIZE
   return true;
  //## end command::UserSession::logoffResponse%3E9D912C0222.body
}

bool UserSession::logonRequest (Message& hMessage, CommonHeaderSegment* pCommonHeaderSegment, LogonSegment* pLogonSegment, ResponseTimeSegment* pResponseTimeSegment)
{
  //## begin command::UserSession::logonRequest%3E9AF51602AF.body preserve=yes
   m_hMessage = hMessage;
   *m_pCommonHeaderSegment = *pCommonHeaderSegment;
   *m_pLogonSegment = *pLogonSegment;
   *m_pResponseTimeSegment = *pResponseTimeSegment;
   setUserID(pLogonSegment->getUserID());
   setPassword(pLogonSegment->getPassword());
   setNewPassword(pLogonSegment->getNewPassword());
   setApplicationName(pLogonSegment->getApplicationName());
   bool bResult = false;
   char cUSER_STATUS = ' ';
#ifndef CS
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   reusable::Query hQuery;
   hQuery.setQualifier("QUALIFY","AS_USER_LOGON");
   hQuery.bind("AS_USER_LOGON","USER_NAME",Column::STRING,&m_strUSER_NAME);
   hQuery.setBasicPredicate("AS_USER_LOGON","USER_ID","=",getUserID().c_str());
   hQuery.bind("AS_USER_LOGON", "USER_STATUS", Column::CHAR, &cUSER_STATUS);
   bResult = pSelectStatement->execute(hQuery);
   if (bResult && pSelectStatement->getRows() == 0)
      cUSER_STATUS = 'E'; //user does not exist.
#endif
   if(Security::instance()->getSecurityType() != "OPEN")
   {
      if(pLogonSegment->getSignature().length() == 0)
      {
#ifdef MVS
#ifndef CS
         if (!bResult || cUSER_STATUS == 'E' || cUSER_STATUS == 'S')
         {
            if (cUSER_STATUS == 'E')
               setReturnCode("SE114");   // user not found
            else
               setReturnCode("SE200");   // user suspended.  SE200 also can mean DB/AS unavailable
            return false;
         }
#endif
         string strConversationID;
         return Session::logon(hMessage,strConversationID);
#endif
      }
   }
#ifndef MVS
   string ldapResult;
#endif
#ifndef CS
   if (bResult && cUSER_STATUS != 'E' && cUSER_STATUS != 'S')
   {
      if (pLogonSegment->getSignature().length() > 0)
      {
         if(getPassword().empty())
            validateSignatureSSO(getUserID(),pLogonSegment->getSignature());
         else
            validateSignature(getUserID(),pLogonSegment->getSignature());
      }
#ifndef MVS
      else
      if (OpenLDAP::instance()->logon(pLogonSegment->getUserID(), pLogonSegment->getPassword(), pLogonSegment->getNewPassword(), ldapResult))
         setReturnCode(ldapResult);
#endif
      else
      {
         // for now !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
         bool bReLogon = pCommonHeaderSegment->getSecurityData()[63] == 'x';
         setReturnCode(Security::instance()->processLogon(getUserID(),getPassword(),getNewPassword(),bReLogon));
      }
      if (m_strUSER_NAME == "MULTIPLELOGON"
         && getReturnCode().length() == 0)
         setAlias();
   }
   else
   {
      if (cUSER_STATUS == 'E')
         setReturnCode("SE114");   // user not found
      else
         setReturnCode("SE200");   // user suspended.  SE200 also can mean DB/AS unavailable
   }
   database::Database::instance()->commit();
#endif
   return true;
  //## end command::UserSession::logonRequest%3E9AF51602AF.body
}

bool UserSession::logonResponse (Message& hMessage)
{
  //## begin command::UserSession::logonResponse%3E9D912F01E4.body preserve=yes
#ifdef MVS
   if (Security::instance()->getSecurityType() != "OPEN")
   {
      if (getOn())
      {
         msgLogon* pLogon = (msgLogon*)hMessage.data();
         m_hResourceListSegment.importFromAccessSecurity(pLogon->sResourceCount,pLogon->sResourceName);
         string strTemp("CMULTIPLELOGON");
         if (m_hResourceListSegment.validate(&strTemp))
            setAlias();
      }
   }
#endif
#define SIZESIZE 8
   char szTemp[SIZESIZE + 1];
   if (getReturnCode().length() > 0)
      m_pCommonHeaderSegment->setResultCode(STS_SECURITY_ERROR);
   m_hMessage.reset("CRQCI ","S0005R",true);
   m_pBuffer = m_hMessage.data() + SIZESIZE;
   if (getReturnCode().length() == 0
      && m_pLogonSegment->getCustomerID() == "****")
      m_pCommonHeaderSegment->setResultCode(STS_SECURITY_ERROR);
   m_pCommonHeaderSegment->deport(&m_pBuffer);
   if (getReturnCode().length() == 0)
   {
      if (m_pLogonSegment->getCustomerID() == "****")
      {
         ListSegment hListSegment;
         char* pList = m_pBuffer;
         hListSegment.deport(&m_pBuffer);
         Query hQuery;
         hQuery.attach(this);
         hQuery.setDistinct(true);
         auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
         hQuery.setQualifier("QUALIFY","AS_USER_PROFILE");
         hQuery.bind("AS_USER_PROFILE","CUST_ID",Column::STRING,&m_strCUST_ID);
         hQuery.setBasicPredicate("AS_USER_PROFILE","USER_ID","=",m_pLogonSegment->getUserID().c_str());
         hQuery.setOrderByClause("CUST_ID");
         pSelectStatement->execute(hQuery);
         if (pSelectStatement->getRows() == 0)
         {
            m_pBuffer = pList;
            setReturnCode("SE200");
         }
         else
         if (pSelectStatement->getRows() == 1
            && m_strCUST_ID == m_pCommonHeaderSegment->getCUST_ID())
         {
            m_pBuffer = m_hMessage.data() + SIZESIZE;
            m_pCommonHeaderSegment->setResultCode(0);
            m_pCommonHeaderSegment->deport(&m_pBuffer);
         }
         else
         {
            hListSegment.update(pList,pSelectStatement->getRows(),(int)(m_pBuffer - pList));
            setReturnCode("SE201");
         }
      }
   }
   m_hResourceListSegment.exportAsXML(&m_pBuffer);
   m_pResponseTimeSegment->deport(&m_pBuffer);
   int iReturnCode=0;
   if (getReturnCode().length() > 0)
   {
      char szReturnCode[6] = {"     "};
      memcpy_s(szReturnCode,6,getReturnCode().data(),5);
      iReturnCode = atoi(szReturnCode + 2);
      InformationSegment hInformationSegment;
      switch (iReturnCode)
      {
         case 18:
            iReturnCode = STS_USER_ALREADY_LOGGED_ON;
            break;
         case 114:
            iReturnCode = STS_UNKNOWN_USER_ID;
            break;
         case 115:
            iReturnCode = STS_UNKNOWN_TERMINAL;
            break;
         case 119:
            iReturnCode = STS_PASSWORD_MISMATCH;
            break;
         case 137:
         case 138:
            iReturnCode = STS_INVALID_NEW_PASSWORD;
            break;
         case 144:
            iReturnCode = STS_NEW_PASSWORD_REQUIRED;
            break;
         case 135:
         case 136:
            iReturnCode = STS_USER_ID_REVOKED;
            break;
         case 200:
            iReturnCode = STS_ACCESS_SECURITY_UNAVAILABLE;
            break;
         case 201:
            iReturnCode = STS_INVALID_CUST_ID;
            break;
         default:
            iReturnCode = STS_LOGON_DENIED;
      }
      if(iReturnCode!=STS_INVALID_CUST_ID || getPassword() == "")
      {
         hInformationSegment.setError(STS_ERROR,iReturnCode,getReturnCode().c_str());
         hInformationSegment.deport(&m_pBuffer);
      }
   }
   if (iReturnCode <= 0 || iReturnCode==STS_INVALID_CUST_ID)
   {
      string strDateLastAccessed;
      if(iReturnCode==STS_INVALID_CUST_ID)
         strDateLastAccessed = Security::instance()->getLastLogonDate(m_pLogonSegment->getUserID());
      else
         strDateLastAccessed = Security::instance()->updateLastLogon2(m_pLogonSegment->getUserID());
      string strDatePasswordExpires;
      if(getPassword() != "")
      { //get pwd expiration date from security provider
#ifdef MVS
         msgLogon* pLogon = (msgLogon*)hMessage.data();
         if (memcmp(pLogon->sDatePasswordExpires,"        ",8))
            strDatePasswordExpires.assign(pLogon->sDatePasswordExpires,8);
#else
         strDatePasswordExpires = OpenLDAP::instance()->getDatePasswordExpires();
#endif
         if(strDatePasswordExpires.length() == 0)
            strDatePasswordExpires = Security::instance()->getPasswordExpiration(m_pLogonSegment->getUserID());
      }
      int iDays = -1;
      if (strDatePasswordExpires.length() == 8)
      {  //validate date for Vericode
         int iYear = atoi(strDatePasswordExpires.substr(0,4).c_str());
         int iMonth = atoi(strDatePasswordExpires.substr(4,2).c_str());
         int iDay = atoi(strDatePasswordExpires.substr(6,2).c_str());
         if ((iYear > 2000 && iYear < 3000) &&
            (iMonth > 0 && iMonth < 13) &&
            (iDay > 0 && iDay < 32))
         {
            Date hDatePasswordExpires(strDatePasswordExpires.c_str());
            int iJulianExpiration = atoi(hDatePasswordExpires.asString("%j").c_str());
            int iJulianToday = atoi(Date::today().asString("%j").c_str());
            int iYearExpiration = hDatePasswordExpires.getYear();
            int iYearToday = Date::today().getYear();
            if(iYearExpiration > 0 && iYearToday > 0 && iYearExpiration < 3000 && abs(iYearExpiration - iYearToday) < 10 )
               iDays = (iYearExpiration - iYearToday) * 365;
            if(iJulianExpiration && iJulianExpiration < 367 && iJulianToday > 0 && abs(iJulianToday - iJulianToday) < 367 )
               iDays += iJulianExpiration - iJulianToday;
         }
      }
      size_t n;
      while ((n = m_strUSER_NAME.find(",")) != string::npos)
         m_strUSER_NAME.replace(n,1,"~");
      char szText[63];
      if (iReturnCode==STS_INVALID_CUST_ID)
         snprintf(szText,sizeof(szText),"%s,%s,%s,%d,%s",getReturnCode().c_str(),strDateLastAccessed.c_str(),strDatePasswordExpires.c_str(),iDays,m_strUSER_NAME.c_str());
      else
         snprintf(szText, sizeof(szText),"SE144,%s,%s,%d,%s",strDateLastAccessed.c_str(),strDatePasswordExpires.c_str(),iDays,m_strUSER_NAME.c_str());
      InformationSegment hInformationSegment;
      if (m_pCommonHeaderSegment->getSecurityData()[63] == 'y')
         hInformationSegment.setError(STS_INFORMATION,iReturnCode,szText);
      else
         hInformationSegment.setError(STS_ERROR,18,szText);
      hInformationSegment.deport(&m_pBuffer);
   }
   int m = (int)(m_pBuffer - m_hMessage.data());
   snprintf(szTemp, sizeof(szTemp),"%08d",m);
   memcpy_s(m_hMessage.data(),(size_t)SIZESIZE,szTemp,(size_t)SIZESIZE);
   m_hMessage.setDataLength(m);
   m_hMessage.reply();
   database::AuditEvent::capture(m_hMessage);
   database::AuditEvent::commit(true);
   return true;
#undef SIZESIZE
  //## end command::UserSession::logonResponse%3E9D912F01E4.body
}

void UserSession::securityResponse (Message& hMessage)
{
  //## begin command::UserSession::securityResponse%3E9AF55D030D.body preserve=yes
#ifdef MVS
   Session::securityResponse(hMessage);
   if (m_pCommonHeaderSegment->getServiceName() == "QLOGON")
   {
      msgLogon* pLogon = (msgLogon*)hMessage.data();
      m_hResourceListSegment.importFromAccessSecurity(pLogon->sResourceCount,pLogon->sResourceName);
      logonResponse(hMessage);
   }
   else
      logoffResponse(hMessage);
#endif
  //## end command::UserSession::securityResponse%3E9AF55D030D.body
}

void UserSession::setAlias ()
{
  //## begin command::UserSession::setAlias%42CD3D2103A9.body preserve=yes
   m_lAliasCount++;
   char szSecurityData[96];
   memset(szSecurityData,' ',64);
   szSecurityData[64] = '\0';
   unsigned i = CommonHeaderSegment::instance()->getSecurityData().length();
   if (i > 64)
      i = 64;
   memcpy_s(szSecurityData,sizeof(szSecurityData),m_pCommonHeaderSegment->getSecurityData().data(),i);
   memcpy_s(szSecurityData + 26,sizeof(szSecurityData)-26,szSecurityData,8);
   memcpy_s(szSecurityData,sizeof(szSecurityData),getAlias().data(),getAlias().length());
   m_pCommonHeaderSegment->setSecurityData(szSecurityData);
   setUserID(getAlias());
  //## end command::UserSession::setAlias%42CD3D2103A9.body
}

void UserSession::terminate ()
{
  //## begin command::UserSession::terminate%427F60CB032C.body preserve=yes
#ifndef _UNIX
   if (m_pKey)
      SecurityWrapper::EVP_PKEY_free((EVP_PKEY*)m_pKey);
#endif
  //## end command::UserSession::terminate%427F60CB032C.body
}

void UserSession::update (Subject* pSubject)
{
  //## begin command::UserSession::update%3E9D859E0290.body preserve=yes
   ConnectionSegment::instance()->setCUST_ID(m_strCUST_ID);
   string strPTCPADD;
   string strPTCPPORT;
   Extract::instance()->getSpec(m_strCUST_ID.c_str(),strPTCPADD);
   size_t npos = strPTCPADD.find(' ');
   if (npos != string::npos)
   {
      strPTCPPORT = strPTCPADD.substr(npos + 1);
      strPTCPADD.erase(npos);
   }
   ConnectionSegment::instance()->setPTCPADD(strPTCPADD);
   ConnectionSegment::instance()->setPTCPPORT(strPTCPPORT);
   ConnectionSegment::instance()->deport(&m_pBuffer);
  //## end command::UserSession::update%3E9D859E0290.body
}

void UserSession::validatePassword (string& strUSER_PASSWORD)
{
  //## begin command::UserSession::validatePassword%427BD40B001F.body preserve=yes
#ifndef MVS
   bool b = true;
   if (strUSER_PASSWORD.length() == 16)
      b = Password::decrypt(strUSER_PASSWORD);
   if (b
      && getPassword() == strUSER_PASSWORD)
   {
      setOn(true);
      if (getNewPassword().size() > 0)
      {
         // Change password
         reusable::Table hTable("AS_USER_LOGON");
         hTable.setQualifier("QUALIFY");
         hTable.set("USER_ID",getUserID().c_str(),false,true);
         string strText(getNewPassword());
         if (strText.length() <= 8)
            Password::encrypt(strText);
         hTable.set("USER_PASSWORD",strText);
         auto_ptr<reusable::Statement> pUpdateStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("UpdateStatement"));
         if (pUpdateStatement->execute(hTable) == false)
            setReturnCode("SE109");
      }
   }
   else
      setReturnCode("SE119"); // Bad password
#endif
  //## end command::UserSession::validatePassword%427BD40B001F.body
}

void UserSession::validateSignature (const string& strUserID, const string& strSignature)
{
  //## begin command::UserSession::validateSignature%427BD41F0000.body preserve=yes
#ifndef _UNIX
   // UNIX !!!
   unsigned char sSignature[8192];
   int iSignature = 0;
   EVP_ENCODE_CTX* decCtx = EVP_ENCODE_CTX_new();
   SecurityWrapper::EVP_DecodeInit(decCtx);
   Trace::put((char*)strSignature.data(),strSignature.length());
   int iRC = SecurityWrapper::EVP_DecodeUpdate(decCtx,sSignature,&iSignature,(unsigned char*)strSignature.data(),(int)strSignature.length());
   EVP_ENCODE_CTX_free(decCtx);
   if (iRC < 0)
   {
      setReturnCode("SE202");
      return;
   }
   if (!m_pKey)
   {
      char sPublicKey[8192];
      char *p = sPublicKey;
      IF::FlatFile hFlatFile("PUBKEY");
      char* psBuffer = new char[256];
      memset(psBuffer,' ',256);
      size_t m = 0;
      while (hFlatFile.read(psBuffer,(size_t)256,&m))
      {
         if ((int)(p - sPublicKey) > m )
         {
            memcpy_s(p,sizeof(sPublicKey),psBuffer,m);
            p += m;
            *p = '\n';
            ++p;
         }
      }
      delete [] psBuffer;
      if (p == sPublicKey)
      {
         setReturnCode("SE203");
         return;
      }
      int n = (int)(p - sPublicKey);
      Trace::put(sPublicKey,n);
      BIO *pBIO = SecurityWrapper::BIO_new(SecurityWrapper::BIO_s_mem());
      SecurityWrapper::BIO_write(pBIO,sPublicKey,n);
      X509* pX509 = SecurityWrapper::PEM_read_bio_X509(pBIO,0,0,0);
      SecurityWrapper::BIO_free(pBIO);
      if (!pX509)
      {
         setReturnCode("SE204");
         return;
      }
      m_pKey = SecurityWrapper::X509_get_pubkey(pX509);
      if (!m_pKey)
      {
         setReturnCode("SE205");
         return;
      }
   }
   EVP_MD* md = (EVP_MD*)SecurityWrapper::EVP_sha1();
   EVP_MD_CTX* mdCtx = SecurityWrapper::EVP_MD_CTX_new();
   if (SecurityWrapper::EVP_VerifyInit(mdCtx,md) != 1)
   {
      SecurityWrapper::EVP_MD_CTX_free(mdCtx);
      setReturnCode("SE206");
      return;
   }
   char szUserID[8];
   int n = strUserID.length();
   memcpy_s(szUserID,sizeof(szUserID),strUserID.data(),n);
   Trace::put(szUserID,n);
#ifdef MVS
   CodeTable::translate(szUserID,n,CodeTable::CX_EBCDIC_TO_ASCII);
   Trace::put(szUserID,n);
#endif
   if (SecurityWrapper::EVP_VerifyUpdate(mdCtx,szUserID,n) != 1)
   {
      SecurityWrapper::EVP_MD_CTX_free(mdCtx);
      setReturnCode("SE207");
      return;
   }
   Trace::putHex((const char*)sSignature,iSignature);
   if (SecurityWrapper::EVP_VerifyFinal(mdCtx,sSignature,iSignature,(EVP_PKEY*)m_pKey) != 1)
      setReturnCode("SE208");
   SecurityWrapper::EVP_MD_CTX_free(mdCtx);
#endif
  //## end command::UserSession::validateSignature%427BD41F0000.body
}

void UserSession::validateSignatureSSO (const string& strUserID, const string& strSignature)
{
  //## begin command::UserSession::validateSignatureSSO%4E0B4FDA0368.body preserve=yes
   //compute a signature from strUserID and compare with strSignature:
   //1. generate a sha1 hash
   //2. encoded sha1 hash in base64
   //3. compare this value with strSignature

#ifdef MVS
   //Convert strUserID to ascii before computing signature
   CodeTable::translate((char*)strUserID.data(),strUserID.length(),CodeTable::CX_EBCDIC_TO_ASCII);
#endif

   //generate sha512 hash
   string strComputedSignature;
   Security::instance()->hash(strUserID,strComputedSignature);
   //compare with signature passed in message
   char szTemp[3];//buffer for adding 2 bytes to strKey
   string strTempSignature;
   unsigned char sTempSignature[64];
   memcpy_s(sTempSignature,sizeof(sTempSignature),strComputedSignature.data(),64);
   for (int i = 0; i < 64; i++)
   {
      unsigned char c = sTempSignature[i];
      strTempSignature.append(szTemp,snprintf(szTemp, sizeof(szTemp),"%02x",c));//adds 2 char at a time (minus null terminator to strKey)
   }
   strComputedSignature.assign(strTempSignature);
   if(strComputedSignature != strSignature)
      setReturnCode("SE208");
  //## end command::UserSession::validateSignatureSSO%4E0B4FDA0368.body
}

//## Get and Set Operations for Class Attributes (implementation)

const int UserSession::getAliasCount ()
{
  //## begin command::UserSession::getAliasCount%3E9BF82D0399.get preserve=no
  return m_lAliasCount;
  //## end command::UserSession::getAliasCount%3E9BF82D0399.get
}

void UserSession::setAliasCount (int value)
{
  //## begin command::UserSession::setAliasCount%3E9BF82D0399.set preserve=no
  m_lAliasCount = value;
  //## end command::UserSession::setAliasCount%3E9BF82D0399.set
}

// Additional Declarations
  //## begin command::UserSession%3E9AF2520222.declarations preserve=yes
  //## end command::UserSession%3E9AF2520222.declarations
} // namespace command

//## begin module%3E9AF352034B.epilog preserve=yes
//## end module%3E9AF352034B.epilog
