//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%444F20F202DA.cm preserve=no
//## end module%444F20F202DA.cm

//## begin module%444F20F202DA.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%444F20F202DA.cp

//## Module: CXOSBC21%444F20F202DA; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC21.cpp

//## begin module%444F20F202DA.additionalIncludes preserve=no
//## end module%444F20F202DA.additionalIncludes

//## begin module%444F20F202DA.includes preserve=yes
#include "CXODIF08.hpp"
#include "CXODBS23.hpp"
#include "CXODRU34.hpp"
#include "CXODRU40.hpp"
//## end module%444F20F202DA.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSBC21_h
#include "CXODBC21.hpp"
#endif


//## begin module%444F20F202DA.declarations preserve=no
//## end module%444F20F202DA.declarations

//## begin module%444F20F202DA.additionalDeclarations preserve=yes
#include "CXODIF03.hpp"
//## end module%444F20F202DA.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::Report 

Report::Report()
  //## begin Report::Report%444F1DBF03C9_const.hasinit preserve=no
      : m_bBlankZeroAmts(true),
        m_strCurrentHeading("FH"),
        m_iCurrentLineCount(0),
        m_iOffset(3),
        m_iPageSize(0),
        m_iPage(0),
        m_iRecordSize(97),
        m_pMemory(0)
  //## end Report::Report%444F1DBF03C9_const.hasinit
  //## begin Report::Report%444F1DBF03C9_const.initialization preserve=yes
  //## end Report::Report%444F1DBF03C9_const.initialization
{
  //## begin command::Report::Report%444F1DBF03C9_const.body preserve=yes
   memcpy_s(m_sID,4,"BC21",4);
   m_pMemory = new Memory(m_iRecordSize);
  //## end command::Report::Report%444F1DBF03C9_const.body
}

Report::Report (int iRecordSize)
  //## begin command::Report::Report%5C48C41C0142.hasinit preserve=no
      : m_bBlankZeroAmts(true),
        m_strCurrentHeading("FH"),
        m_iCurrentLineCount(0),
        m_iOffset(3),
        m_iPageSize(0),
        m_iPage(0),
        m_iRecordSize(97),
        m_pMemory(0)
  //## end command::Report::Report%5C48C41C0142.hasinit
  //## begin command::Report::Report%5C48C41C0142.initialization preserve=yes
  //## end command::Report::Report%5C48C41C0142.initialization
{
  //## begin command::Report::Report%5C48C41C0142.body preserve=yes
   memcpy_s(m_sID,4,"BC21",4);
   m_iRecordSize = iRecordSize;
   m_pMemory = new Memory(m_iRecordSize);
  //## end command::Report::Report%5C48C41C0142.body
}


Report::~Report()
{
  //## begin command::Report::~Report%444F1DBF03C9_dest.body preserve=yes
   delete m_pMemory;
  //## end command::Report::~Report%444F1DBF03C9_dest.body
}



//## Other Operations (implementation)
void Report::addCommas (char* pszBuffer, size_t iBufferSize)
{
  //## begin command::Report::addCommas%5D2CC25E03B6.body preserve=yes
   string strBuffer(pszBuffer);
   if (strBuffer.length() < 4 || strBuffer.length() > iBufferSize)
      return;
   size_t nOriginalLength = strBuffer.length();
   int iPos = strBuffer.length() - 1;
   int iCount = 0;
   while (iPos)
   {
      iCount++;
      if (!isdigit(strBuffer.data()[iPos])) //weed out blanks and decimal pt.
         iCount = 0;
      if (iCount == 4)
      {
         strBuffer.insert(iPos + 1,1,',');
         iCount = 1;
      }
      --iPos;
   }
   if (strBuffer.length() > nOriginalLength)
      strBuffer.erase(0,strBuffer.length() - nOriginalLength);
   if (iBufferSize > strBuffer.length())
   {
      memcpy(pszBuffer,strBuffer.data(),strBuffer.length());
      pszBuffer[strBuffer.length()] = '\0';
   }
  //## end command::Report::addCommas%5D2CC25E03B6.body
}

void Report::addCRDR (char* pszBuffer, size_t iBufferSize)
{
  //## begin command::Report::addCRDR%5D2CC2910299.body preserve=yes
   string strBuffer(pszBuffer);
   if (strBuffer.find(" 0.00") != string::npos)
      return;
   size_t pos;
   if ((pos = strBuffer.find('-')) != string::npos)
   {
      strBuffer.append(" DR");
      strBuffer.replace(pos,1," ");
   }
   else
      strBuffer.append(" CR");
   if (iBufferSize > strBuffer.length())
   {
      memcpy(pszBuffer, strBuffer.data(), strBuffer.length());
      pszBuffer[strBuffer.length()] = '\0';
   }
  //## end command::Report::addCRDR%5D2CC2910299.body
}

void Report::addSegment (const char cSegment, segment::Segment* pSegment)
{
  //## begin command::Report::addSegment %444F1E6102AF.body preserve=yes
   m_hSegment[cSegment] = pSegment;
  //## end command::Report::addSegment %444F1E6102AF.body
}

bool Report::evaluate (reusable::string& strColumnName, string& strValue, string& strFormat, string& strSymbol)
{
  //## begin command::Report::evaluate%5D2CC3670353.body preserve=yes
   size_t p = 0;
   if ((p = strColumnName.find("#") == string::npos))
      return false;
   char c[6] = { "+-/*<" };
   vector<double> hStack;
   size_t q = 0;
   size_t r = 0;
   while ((p = strColumnName.find("#")) != string::npos)
   {
      q = p + 1;
      while (q < strColumnName.length() && strColumnName[q] != '#')
         ++q;
      int k = 0;
      reusable::string strSymbolName(strColumnName.substr(p + 1,q - p - 1));
      while (k < 6 && c[k] != strSymbolName[0])
         k++;
      if (k == 6)
      {
         if (strSymbolName[1] == '.')
         {
            strSymbolName.assign(strColumnName.substr(p + 3,q - p - 3));
            reusable::string strSegmentCharacter(strColumnName.substr(p + 1,1));
            map<char,segment::Segment*,less<char> >::iterator pSegment;
            pSegment = m_hSegment.find(strSegmentCharacter[0]);
            strValue.assign("0");
            if (pSegment != m_hSegment.end())
               (*pSegment).second->_field((char*)strSymbolName.c_str(),strValue,false,false);
         }
         else
            strValue.assign(strSymbolName);
         hStack.push_back(atof(strValue.c_str()));
      }
      else
      {
         double d[2] = {0,0};
         d[0] = hStack.back();
         hStack.pop_back();
         //??? Unary
         if (hStack.size() > 0)
         {
            d[1] = hStack.back();
            hStack.pop_back();
         }
         switch (c[k])
         {
         case '+':
            hStack.push_back(d[0] + d[1]);
            break;
         case '-':
            hStack.push_back(d[1] - d[0]);
            break;
         case '*':
            hStack.push_back(d[0] * d[1]);
            break;
         case '/':
            if (d[0] == 0)
               hStack.push_back(double(0));
            else
               hStack.push_back(d[1] / d[0]);
            break;
         case '<':
            if (d[0] < 0)
               d[0] *= -1;
            hStack.push_back(d[0]);
         }
      }
      strColumnName.assign(strColumnName.substr(q));
   }
   char szTemp[PERCENTF];
   if (hStack.size() == 0)
      hStack.push_back(0);
   map<char,segment::Segment*,less<char> >::iterator pSegment = m_hSegment.find('Z');
   if (pSegment != m_hSegment.end())
      ((GenericSegment*)(*pSegment).second)->set(strSymbol.c_str(),hStack.back());
   strValue.assign(szTemp,snprintf(szTemp,sizeof(szTemp),"%f",hStack.back()));
   return true;
  //## end command::Report::evaluate%5D2CC3670353.body
}

void Report::finish ()
{
  //## begin command::Report::finish%5D3710BF03E5.body preserve=yes
   if (m_iCurrentLineCount == 0)
   {
      report(m_strCurrentHeading);
      report("ND");
   }
   if (m_iPageSize > 0 && m_iCurrentLineCount < m_iPageSize)
      writeBlankLines(m_iPageSize - m_iCurrentLineCount);
  //## end command::Report::finish%5D3710BF03E5.body
}

int Report::getRecordCount ()
{
  //## begin command::Report::getRecordCount%44696355033D.body preserve=yes
   return (int)m_hFile.size();
  //## end command::Report::getRecordCount%44696355033D.body
}

bool Report::managePaging (const reusable::string& strRecordType)
{
  //## begin command::Report::managePaging%5D30C8E6034F.body preserve=yes
   int iNumLines = lines(strRecordType);
   if (strRecordType == m_strCurrentHeading)
   {
      map<char,segment::Segment*,less<char> >::iterator pSegment = m_hSegment.find('Z');
      if (pSegment != m_hSegment.end())
         ((GenericSegment*)(*pSegment).second)->set("PAGE",++m_iPage);
      if (m_iCurrentLineCount > 0 && m_iCurrentLineCount <= m_iPageSize)
      {
         writeBlankLines(m_iPageSize - m_iCurrentLineCount);
         m_iCurrentLineCount = iNumLines;
         return report2(strRecordType);
      }
   }
   else
   if (iNumLines > m_iPageSize - m_iCurrentLineCount)
   {
      writeBlankLines(m_iPageSize - m_iCurrentLineCount);
      m_iCurrentLineCount = lines(m_strCurrentHeading);
      map<char,segment::Segment*,less<char> >::iterator pSegment = m_hSegment.find('Z');
      if (pSegment != m_hSegment.end())
         ((GenericSegment*)(*pSegment).second)->set("PAGE",++m_iPage);
      report2(m_strCurrentHeading);
      m_iCurrentLineCount += iNumLines;
      return report2(strRecordType);
   }
   m_iCurrentLineCount += iNumLines;
   return report2(strRecordType);
  //## end command::Report::managePaging%5D30C8E6034F.body
}

bool Report::readTemplate (const string& strTemplate)
{
  //## begin command::Report::readTemplate%444F1EE80103.body preserve=yes
   if (m_hTemplate.size() > 0)
      return true;
   char szTrace[140];
   Trace::put(szTrace,snprintf(szTrace,sizeof(szTrace),"Reading Template: %s",strTemplate.c_str()));
   string strRecord;
   Extract::instance()->getRecord("DSPEC   BC21    PAGESIZE~",strRecord);
   if (strRecord.length() > 25)
      m_iPageSize = max(56,atoi(strRecord.substr(25).c_str()));
#ifdef MVS
   FlatFile hTemplate("JCL",strTemplate.c_str());
#else
   FlatFile hTemplate("SOURCE",strTemplate.c_str());
#endif
   if (!hTemplate.open())
   {
      Trace::put(szTrace,snprintf(szTrace,sizeof(szTrace),"Unable to open Template: %s",strTemplate.c_str()),true);
      return false;
   }
   char* pszBuffer = new char[max(size_t(4096),size_t(m_iRecordSize + 512))];
   size_t nReadBytes = 0;
   char* psSymbol = 0;
   char* psMemberVariable = 0;
   char* psFormat = 0;
   string strFieldID;
   string strAttributes;
   string strValue;
   while (hTemplate.read(pszBuffer,size_t(m_iRecordSize + 1),&nReadBytes))
   {
      Trace::put(szTrace,snprintf(szTrace,sizeof(szTrace),"Reading record of length: %d",nReadBytes));
      int m = 79;
      while (nReadBytes == 80
         && pszBuffer[m] == '+')
      {
         hTemplate.read(pszBuffer + m,82,&nReadBytes);
         m += nReadBytes - 1;
      }
      while (m > 0 && pszBuffer[m] == ' ')
         --m;
      pszBuffer[m + 1] = '\0';
      if (memcmp(pszBuffer, "FH1", 3) == 0 && Extract::instance()->getRecord("DSPEC   BC21    ASA~YES", strValue))
      {
         m_iOffset = 2;
      }
      if (memcmp(pszBuffer,"SY",2) != 0)
      {
         if (strlen(pszBuffer) < 2 || pszBuffer[0] == '&' || pszBuffer[0] == '*' || pszBuffer[0] == ' ')
            continue;
         string strSection(pszBuffer,2);
         map<string,int,less<string> >::iterator q;
         if ((q = m_hSection.find(strSection)) != m_hSection.end())
            (*q).second++;
         else
            m_hSection.insert(map<string,int,less<string> >::value_type(strSection,1));
         m_hTemplate.push_back(string(pszBuffer));
         continue;
      }
      psSymbol = strchr(pszBuffer,'~');
      if (psSymbol)
      {
         ++psSymbol;
         psMemberVariable = strchr(psSymbol,'~');
         if (psMemberVariable)
         {
            *(psMemberVariable-1) = '\0';
            ++psMemberVariable;
            psFormat = strchr(psMemberVariable,' ');
            if (psFormat)
            {
               *psFormat = '\0';
               ++psFormat;
               m_hSymbol[string(psSymbol)] = make_pair(string(psMemberVariable),string(psFormat));
            }
         }
      }
   }
   Trace::put(szTrace,snprintf(szTrace,sizeof(szTrace),"Reading Template complete"));
   hTemplate.close();
   delete [] pszBuffer;
   return true;
  //## end command::Report::readTemplate%444F1EE80103.body
}

bool Report::report (const reusable::string& strRecordType)
{
  //## begin command::Report::report%444F1EBB036C.body preserve=yes
   if (m_iPageSize > 0)
      return managePaging(strRecordType);
   m_iCurrentLineCount += lines(strRecordType);
   if (strRecordType == m_strCurrentHeading)
   {
      map<char,segment::Segment*,less<char> >::iterator pSegment = m_hSegment.find('Z');
      if (pSegment != m_hSegment.end())
         ((GenericSegment*)(*pSegment).second)->set("PAGE",++m_iPage);
   }
   return report2(strRecordType);
  //## end command::Report::report%444F1EBB036C.body
}

bool Report::report2 (const reusable::string& strRecordType)
{
  //## begin command::Report::report2%5D30C8E303A8.body preserve=yes
   vector<string>::iterator p;
   for (p = m_hTemplate.begin();p != m_hTemplate.end();++p)
   {
      if (((*p).substr(0,2)) == strRecordType)
      {
         string strText((*p).data(),(*p).length());
         substitute(strText);
         strText.resize(m_iRecordSize,' ');
         m_hFile.push_back(strText.substr(m_iOffset, strText.length() - m_iOffset));
      }
   }
   return true;
  //## end command::Report::report2%5D30C8E303A8.body
}

void Report::substitute (string&  strText)
{
  //## begin command::Report::substitute%444F1F1A02A2.body preserve=yes
   reusable::string strValue;
   size_t p = 0;
   size_t q = 0;
   size_t r = 0;
   int iPANOffset = -1;
   size_t iPANLength = 0;
   while ((p = strText.find("~")) != string::npos)
   {
      strValue.assign(" ",1);
      q = p + 1;
      while (q < strText.length() && strText[q] != ' ' && strText[q] != '~')
         ++q;
      string strSymbolName(strText.substr(p + 1,q - p - 1));
      map<string,pair<string,string>,less<string> >::iterator pSymbol;
      pSymbol = m_hSymbol.find(strSymbolName);
      if (pSymbol == m_hSymbol.end())
         break;
      string strSegmentCharacter((*pSymbol).second.first.substr(0,1));
      string strColumnName((*pSymbol).second.first.substr(2));
      string strFormat((*pSymbol).second.second);
      string strSubstr;
      if (strColumnName.find(".SUB~") != string::npos)
      {
         strSubstr = strColumnName.substr(strColumnName.find(".SUB~")+5);
         strColumnName = strColumnName.substr(0,strColumnName.find("."));
      }
      char szReplace[PERCENTF] = {""};
      map<char,segment::Segment*,less<char> >::iterator pSegment;
      pSegment = m_hSegment.find(strSegmentCharacter[0]);
      bool bReturn =(pSegment == m_hSegment.end()) ? evaluate(strColumnName,strValue,strFormat,strSymbolName) : (*pSegment).second->_field((char*)strColumnName.c_str(),strValue,false,false);
      if (!bReturn)
         strValue.assign(" ",1);
      if (strColumnName == "PAN" && strValue.length() >= 16)
      {
         iPANOffset = p - m_iOffset;
         iPANLength = strValue.length();
      }
      if (strFormat.length() > 0)
      {
         if ((r = strFormat.find('t')) != string::npos)
         {
            string strTimeFormat(strFormat,r + 1);
            DateTime::format(strValue,strTimeFormat);
            strText.replace(p,snprintf(szReplace,sizeof(szReplace),strFormat.substr(0,r).c_str(),strValue.c_str()),szReplace);
         }
         else
         if (strFormat.find('d') != string::npos)
            strText.replace(p,snprintf(szReplace,sizeof(szReplace),strFormat.c_str(),atoi(strValue.c_str())),szReplace);
         else
         if (strFormat.find('f') != string::npos)
         {
            int numDecimalPlaces = 0;
            double dDenominator = 1;
            if (strFormat.find('.') != string::npos)
            {
               numDecimalPlaces = atoi(strFormat.substr(strFormat.find('.') + 1,1).c_str());
               while (numDecimalPlaces--)
                  dDenominator *= 10;
            }
            double d = atof(strValue.c_str());
            /*if (d < 0)
               strFormat.append("-",1);*/
            size_t pos;
            if ((pos = strFormat.find(',')) != string::npos)
            {
               strFormat.erase(pos,1);
               bool bAccountingFormat = false;
               if ((pos = strFormat.find('R')) != string::npos)
               {
                  bAccountingFormat = true;
                  strFormat.erase(pos,1);
               }
               bool bBlankZeros = false;
               if ((pos = strFormat.find('B')) != string::npos)
               {  //blank out 0.00
                  strFormat.erase(pos,1);
                  if (d == 0.0 && m_bBlankZeroAmts)
                     bBlankZeros = true;
               }
               if (bBlankZeros)
               {
                  pos = strFormat.find('f');
                  strFormat.replace(pos,1,"s");
                  strText.replace(p,snprintf(szReplace,sizeof(szReplace),strFormat.c_str()," "),szReplace);
               }
               else
               {
                  snprintf(szReplace,sizeof(szReplace),strFormat.c_str(),d / dDenominator);
                  addCommas(szReplace,PERCENTF);
                  if (bAccountingFormat)
                     addCRDR(szReplace,PERCENTF);
                  strText.replace(p,strlen(szReplace),szReplace);
               }
            }
            else
               strText.replace(p,snprintf(szReplace,sizeof(szReplace),strFormat.c_str(),d / dDenominator),szReplace);
         }
         else if (strFormat.find("%c") != string::npos)
         {
            strText.replace(p, snprintf(szReplace, sizeof(szReplace), strFormat.c_str(), strValue[0]), szReplace);
            p = p + 1;
            strText.erase(p, strSymbolName.length());
            continue;
         }
         else
         {
            if (!strSubstr.empty())
            {
               vector<string> hTokens;
               if (Buffer::parse(strSubstr,",",hTokens) >= 2)
                  strValue = atoi(hTokens[1].c_str()) <= strValue.length() ? strValue.substr(atoi(hTokens[0].c_str()),atoi(hTokens[1].c_str())) : strValue;
               else
                  strValue = atoi(hTokens[0].c_str()) <= strValue.length() ? strValue.substr(atoi(hTokens[0].c_str())) : strValue;
            }
            strText.replace(p,snprintf(szReplace,sizeof(szReplace),strFormat.c_str(),strValue.c_str()),szReplace);
         }
      }
      p = q;
   }
   m_hPANOffset.push_back(make_pair(iPANOffset, iPANLength));
  //## end command::Report::substitute%444F1F1A02A2.body
}

bool Report::write (IF::FlatFile& hFile)
{
  //## begin command::Report::write%444F1F7400DE.body preserve=yes
   while (m_hFile.size() > 0)
   {
      memset(*m_pMemory,' ',m_iRecordSize - m_iOffset);
      memcpy_s(*m_pMemory,m_iRecordSize,m_hFile.front().data(),min(m_hFile.front().length(),size_t(m_iRecordSize - m_iOffset)));
      if (!hFile.write((char*)*m_pMemory,m_iRecordSize - m_iOffset))
         return false;
      m_hFile.pop_front();
      m_hPANOffset.pop_front();
   }
   return true;
  //## end command::Report::write%444F1F7400DE.body
}

bool Report::write (database::ExportFile& hFile, int iSEQ_NO)
{
  //## begin command::Report::write%45B5C5740330.body preserve=yes
   while (m_hFile.size() > 0)
   {
      int iRecordSize = min(m_hFile.front().length(), size_t(m_iRecordSize - m_iOffset));
      memset(hFile.getDATA_BUFFER(),' ',iRecordSize);
      memcpy_s(hFile.getDATA_BUFFER(), 65536, m_hFile.front().data(), iRecordSize);
      if (m_hPANOffset.front().first != -1)
         KeyRing::instance()->mask(iRecordSize, hFile.getDATA_BUFFER(), m_hPANOffset.front().first, m_hPANOffset.front().second);
      if (!hFile.write(iRecordSize, iSEQ_NO, false, false))
         return false;
      if (iSEQ_NO > -1)
         ++iSEQ_NO;
      m_hFile.pop_front();
      m_hPANOffset.pop_front();
   }
   return true;
  //## end command::Report::write%45B5C5740330.body
}

void Report::writeBlankLines (int iLines)
{
  //## begin command::Report::writeBlankLines%5D30CA9702DE.body preserve=yes
   if (m_iOffset == 2)
      return;
   string strEmpty;
   for (int i = 0; i < iLines; i++)
   {
      m_hFile.push_back(strEmpty);
      m_hPANOffset.push_back(make_pair(-1, 0));
   }
  //## end command::Report::writeBlankLines%5D30CA9702DE.body
}

// Additional Declarations
  //## begin command::Report%444F1DBF03C9.declarations preserve=yes
  //## end command::Report%444F1DBF03C9.declarations

} // namespace command

//## begin module%444F20F202DA.epilog preserve=yes
//## end module%444F20F202DA.epilog
