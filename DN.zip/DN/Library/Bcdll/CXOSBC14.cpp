//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%370DECB70038.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%370DECB70038.cm

//## begin module%370DECB70038.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%370DECB70038.cp

//## Module: CXOSBC14%370DECB70038; Package body
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC14.cpp

//## begin module%370DECB70038.additionalIncludes preserve=no
//## end module%370DECB70038.additionalIncludes

//## begin module%370DECB70038.includes preserve=yes
// $Date:   Apr 08 2004 11:17:24  $ $Author:   D02405  $ $Revision:   1.1  $
//## end module%370DECB70038.includes

#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF35_h
#include "CXODIF35.hpp"
#endif
#ifndef CXOSBC14_h
#include "CXODBC14.hpp"
#endif


//## begin module%370DECB70038.declarations preserve=no
//## end module%370DECB70038.declarations

//## begin module%370DECB70038.additionalDeclarations preserve=yes
//## end module%370DECB70038.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::GetUserIdListCommand 

GetUserIdListCommand::GetUserIdListCommand()
  //## begin GetUserIdListCommand::GetUserIdListCommand%370DEB8701F4_const.hasinit preserve=no
  //## end GetUserIdListCommand::GetUserIdListCommand%370DEB8701F4_const.hasinit
  //## begin GetUserIdListCommand::GetUserIdListCommand%370DEB8701F4_const.initialization preserve=yes
  //## end GetUserIdListCommand::GetUserIdListCommand%370DEB8701F4_const.initialization
{
  //## begin command::GetUserIdListCommand::GetUserIdListCommand%370DEB8701F4_const.body preserve=yes
   memcpy(m_sID,"UC06",4);
  //## end command::GetUserIdListCommand::GetUserIdListCommand%370DEB8701F4_const.body
}


GetUserIdListCommand::~GetUserIdListCommand()
{
  //## begin command::GetUserIdListCommand::~GetUserIdListCommand%370DEB8701F4_dest.body preserve=yes
  //## end command::GetUserIdListCommand::~GetUserIdListCommand%370DEB8701F4_dest.body
}



//## Other Operations (implementation)
bool GetUserIdListCommand::execute (SelectStatement *pSelectStatement)
{
  //## begin command::GetUserIdListCommand::execute%370DEFA702E3.body preserve=yes
  Query hQuery;
  hQuery.attach(this);
  hQuery.join("AS_USER_LOGON","INNER","INSTITUTION","INST_ID");
  hQuery.join("INSTITUTION","INNER","PROCESSOR","PROC_ID");
  hQuery.bind("AS_USER_LOGON","USER_ID",Column::STRING,&m_strUSER_ID);
  hQuery.bind("AS_USER_LOGON","USER_NAME",Column::STRING,&m_strUSER_NAME);
  hQuery.bind("AS_USER_LOGON","USER_PASSWORD",Column::STRING,&m_strUSER_PASSWORD);
  hQuery.bind("AS_USER_LOGON","TIMEOUT_MINS",Column::SHORT,&m_strTIMEOUT_MINS);
  hQuery.bind("AS_USER_LOGON","CUST_ID",Column::STRING,&m_strCUST_ID);
  hQuery.bind("AS_USER_LOGON","PROC_GRP_ID",Column::STRING,&m_strPROC_GRP_ID);
  hQuery.bind("AS_USER_LOGON","PROC_ID",Column::STRING,&m_strPROC_ID);
  hQuery.bind("AS_USER_LOGON","INST_ID",Column::STRING,&m_strINST_ID);
  hQuery.bind("INSTITUTION","PROC_ID",Column::STRING,&m_strINST_PROC_ID);
  hQuery.bind("PROCESSOR","PROC_GRP_ID",Column::STRING,&m_strPROC_PROC_GRP_ID);
  hQuery.setBasicPredicate("AS_USER_LOGON","CUST_ID","IS NOT NULL");
  hQuery.setBasicPredicate("AS_USER_LOGON","INST_ID","IS NOT NULL");
  hQuery.setBasicPredicate("INSTITUTION","CC_CHANGE_GRP_ID","IS NULL");
  hQuery.setBasicPredicate("PROCESSOR","CC_CHANGE_GRP_ID","IS NULL");
  hQuery.setOrderByClause("AS_USER_LOGON.USER_ID ASC");
  pSelectStatement->execute(hQuery);
  m_strINST_ID.erase();
  hQuery.reset();
  hQuery.join("AS_USER_LOGON","INNER","PROCESSOR","PROC_ID");
  hQuery.bind("AS_USER_LOGON","USER_ID",Column::STRING,&m_strUSER_ID);
  hQuery.bind("AS_USER_LOGON","USER_NAME",Column::STRING,&m_strUSER_NAME);
  hQuery.bind("AS_USER_LOGON","USER_PASSWORD",Column::STRING,&m_strUSER_PASSWORD);
  hQuery.bind("AS_USER_LOGON","TIMEOUT_MINS",Column::SHORT,&m_strTIMEOUT_MINS);
  hQuery.bind("AS_USER_LOGON","CUST_ID",Column::STRING,&m_strCUST_ID);
  hQuery.bind("AS_USER_LOGON","PROC_GRP_ID",Column::STRING,&m_strPROC_GRP_ID);
  hQuery.bind("AS_USER_LOGON","PROC_ID",Column::STRING,&m_strPROC_ID);
  hQuery.bind("AS_USER_LOGON","INST_ID",Column::STRING,&m_strINST_ID);
  hQuery.bind("PROCESSOR","PROC_GRP_ID",Column::STRING,&m_strPROC_PROC_GRP_ID);
  hQuery.setBasicPredicate("AS_USER_LOGON","CUST_ID","IS NOT NULL");
  hQuery.setBasicPredicate("AS_USER_LOGON","PROC_ID","IS NOT NULL");
  hQuery.setBasicPredicate("AS_USER_LOGON","INST_ID","IS NULL");
  hQuery.setBasicPredicate("PROCESSOR","CC_CHANGE_GRP_ID","IS NULL");
  hQuery.setOrderByClause("AS_USER_LOGON.USER_ID ASC");
  pSelectStatement->execute(hQuery);
  m_strPROC_ID.erase();
  hQuery.reset();
  hQuery.bind("AS_USER_LOGON","USER_ID",Column::STRING,&m_strUSER_ID);
  hQuery.bind("AS_USER_LOGON","USER_NAME",Column::STRING,&m_strUSER_NAME);
  hQuery.bind("AS_USER_LOGON","USER_PASSWORD",Column::STRING,&m_strUSER_PASSWORD);
  hQuery.bind("AS_USER_LOGON","TIMEOUT_MINS",Column::SHORT,&m_strTIMEOUT_MINS);
  hQuery.bind("AS_USER_LOGON","CUST_ID",Column::STRING,&m_strCUST_ID);
  hQuery.bind("AS_USER_LOGON","PROC_GRP_ID",Column::STRING,&m_strPROC_GRP_ID);
  hQuery.bind("AS_USER_LOGON","PROC_ID",Column::STRING,&m_strPROC_ID);
  hQuery.bind("AS_USER_LOGON","INST_ID",Column::STRING,&m_strINST_ID);
  hQuery.setBasicPredicate("AS_USER_LOGON","CUST_ID","IS NOT NULL");
  hQuery.setBasicPredicate("AS_USER_LOGON","PROC_GRP_ID","IS NOT NULL");
  hQuery.setBasicPredicate("AS_USER_LOGON","PROC_ID","IS NULL");
  hQuery.setBasicPredicate("AS_USER_LOGON","INST_ID","IS NULL");
  hQuery.setOrderByClause("AS_USER_LOGON.USER_ID ASC");
  return pSelectStatement->execute(hQuery);
  //## end command::GetUserIdListCommand::execute%370DEFA702E3.body
}

void GetUserIdListCommand::update (Subject* pSubject)
{
  //## begin command::GetUserIdListCommand::update%370DEFB101CF.body preserve=yes
   char szUserID[9] = {"        "};
   char sEntityData[100];
   memset(sEntityData,' ',sizeof(sEntityData));
   if ((m_strINST_ID.length() == 0) && (m_strPROC_ID.length() == 0))
      ;
   else
   if (m_strINST_ID.length())
   {
      m_strPROC_ID = m_strINST_PROC_ID;
      m_strPROC_GRP_ID = m_strPROC_PROC_GRP_ID;
   }
   else
   {
      m_strPROC_GRP_ID = m_strPROC_PROC_GRP_ID;
   }
   memcpy(sEntityData,m_strINST_ID.data(),m_strINST_ID.length());
   memcpy(sEntityData+11,m_strPROC_ID.data(),m_strPROC_ID.length());
   memcpy(sEntityData+19,m_strPROC_GRP_ID.data(),m_strPROC_GRP_ID.length());
   memcpy(sEntityData+27,m_strCUST_ID.data(),m_strCUST_ID.length());
   memcpy(szUserID,m_strUSER_ID.data(),m_strUSER_ID.length());
   ResourceUsage::log("DN001","USER ID",szUserID,sEntityData," ",1," ",0);
  //## end command::GetUserIdListCommand::update%370DEFB101CF.body
}

// Additional Declarations
  //## begin command::GetUserIdListCommand%370DEB8701F4.declarations preserve=yes
  //## end command::GetUserIdListCommand%370DEB8701F4.declarations

} // namespace command

//## begin module%370DECB70038.epilog preserve=yes
//## end module%370DECB70038.epilog
