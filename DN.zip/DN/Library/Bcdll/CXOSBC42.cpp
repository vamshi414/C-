//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52FB8D4602EE.cm preserve=no
//	$Date:   Apr 20 2020 11:08:02  $ $Author:   e1009510  $ $Revision:   1.4  $
//## end module%52FB8D4602EE.cm

//## begin module%52FB8D4602EE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52FB8D4602EE.cp

//## Module: CXOSBC42%52FB8D4602EE; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC42.cpp

//## begin module%52FB8D4602EE.additionalIncludes preserve=no
//## end module%52FB8D4602EE.additionalIncludes

//## begin module%52FB8D4602EE.includes preserve=yes
#include <algorithm>
//## end module%52FB8D4602EE.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSRU31_h
#include "CXODRU31.hpp"
#endif
#ifndef CXODDB51_h
#include "CXODDB51.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSBC42_h
#include "CXODBC42.hpp"
#endif


//## begin module%52FB8D4602EE.declarations preserve=no
//## end module%52FB8D4602EE.declarations

//## begin module%52FB8D4602EE.additionalDeclarations preserve=yes
//## end module%52FB8D4602EE.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::LongData 

//## begin command::LongData::Instance%52FB82500207.attr preserve=no  private: static command::LongData* {V} 0
command::LongData* LongData::m_pInstance = 0;
//## end command::LongData::Instance%52FB82500207.attr

LongData::LongData()
  //## begin LongData::LongData%52FB820303BB_const.hasinit preserve=no
  //## end LongData::LongData%52FB820303BB_const.hasinit
  //## begin LongData::LongData%52FB820303BB_const.initialization preserve=yes
  //## end LongData::LongData%52FB820303BB_const.initialization
{
  //## begin command::LongData::LongData%52FB820303BB_const.body preserve=yes
   memcpy(m_sID,"BC42",4);
  //## end command::LongData::LongData%52FB820303BB_const.body
}


LongData::~LongData()
{
  //## begin command::LongData::~LongData%52FB820303BB_dest.body preserve=yes
   for_each(m_hConstraint.begin(),m_hConstraint.end(),reusable::DeleteObject());
   m_pInstance = 0;
  //## end command::LongData::~LongData%52FB820303BB_dest.body
}



//## Other Operations (implementation)
bool LongData::_field (const segment::GenericSegment& hGenericSegment, const char* pszName, string& strValue)
{
  //## begin command::LongData::_field%52FB89CE01BC.body preserve=yes
   string strName(pszName);
   pair<multimap<string,Tag,less<string> >::iterator,multimap<string,Tag,less<string> >::iterator> hRange = m_hTag.equal_range(strName);
   for (multimap<string,Tag,less<string> >::iterator pRange = hRange.first;pRange != hRange.second;++pRange)
      if ((*pRange).second._field(hGenericSegment,strValue))
         return true;
   return false;
  //## end command::LongData::_field%52FB89CE01BC.body
}

void LongData::initialize (multimap<string,database::Column,less<string> >& hTag)
{
  //## begin command::LongData::initialize%52FD3871032C.body preserve=yes
#ifdef MVS
   FlatFile hFlatFile("JCL","LONGDATA");
#else
   FlatFile hFlatFile("SOURCE","CXOXLONG");
#endif
   Constraint* pConstraint = 0;
   string strTag;
   string strName;
   int iOffset = 0;
   int iLength = 0;
   char szBuffer[81];
   size_t m = 0;
   while (hFlatFile.read(szBuffer,81,&m))
   {
      if (memcmp(szBuffer," /* @",5) == 0)
      {
         if (!pConstraint)
         {
            pConstraint = new Constraint;
            m_hConstraint.push_back(pConstraint);
         }
         pConstraint->addPredicate(szBuffer);
      }
      if (pConstraint)
      {
         if (memcmp(szBuffer,"struct seg",10) == 0)
         {
            strName.assign(szBuffer + 10,18);
            size_t pos = strName.find(" ");
            if (pos != string::npos)
               strName.erase(pos);
            pos = strName.find("ACQ_");
            if (pos != string::npos)
               strName.erase(pos + 3);
            pos = strName.find("ISS_");
            if (pos != string::npos)
               strName.erase(pos + 3);
            iOffset = 0;
         }
         if (memcmp(szBuffer," /* -",5) == 0)
         {
            strTag.assign(szBuffer + 5,m - 5);
            size_t pos = strTag.find(" */");
            if (pos != string::npos)
               strTag.erase(pos);
         }
         if (memcmp(szBuffer,"   char ",8) == 0)
         {
            char* p = strchr(szBuffer,'[');
            iLength = p ? atoi(p + 1) : 1;
            if (!strTag.empty())
            {
               Tag t(strName,iOffset,iLength,pConstraint);
               m_hTag.insert(map<string,Tag,less<string> >::value_type(strTag,t));
               strTag.insert(0,"Transaction:");
               pConstraint->addColumn(strTag,hTag);
               hTag.insert(multimap<string,database::Column,less<string> >::value_type(strTag,database::Column("FIN_RECORD",strName,0)));
               strTag.erase();
            }
            iOffset += iLength;
         }
         if (szBuffer[0] == '}')
            pConstraint = 0;
      }
   }
  //## end command::LongData::initialize%52FD3871032C.body
}

LongData* LongData::instance ()
{
  //## begin command::LongData::instance%52FB8238002D.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new LongData;
   return m_pInstance;
  //## end command::LongData::instance%52FB8238002D.body
}

// Additional Declarations
  //## begin command::LongData%52FB820303BB.declarations preserve=yes
  //## end command::LongData%52FB820303BB.declarations

} // namespace command

//## begin module%52FB8D4602EE.epilog preserve=yes
//## end module%52FB8D4602EE.epilog
