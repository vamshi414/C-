//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%56264E9000BB.cm preserve=no
//	$Date:   May 24 2016 11:03:12  $ $Author:   e1009510  $ $Revision:   1.0  $
//## end module%56264E9000BB.cm

//## begin module%56264E9000BB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%56264E9000BB.cp

//## Module: CXOSBC50%56264E9000BB; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC50.hpp

#ifndef CXOSBC50_h
#define CXOSBC50_h 1

//## begin module%56264E9000BB.additionalIncludes preserve=no
//## end module%56264E9000BB.additionalIncludes

//## begin module%56264E9000BB.includes preserve=yes
//## end module%56264E9000BB.includes

#ifndef CXOSBC48_h
#include "CXODBC48.hpp"
#endif
#ifndef CXOSBC47_h
#include "CXODBC47.hpp"
#endif
#ifndef CXOSBC46_h
#include "CXODBC46.hpp"
#endif
#ifndef CXOSBC35_h
#include "CXODBC35.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class GenericFunction;

} // namespace command

//## begin module%56264E9000BB.declarations preserve=no
//## end module%56264E9000BB.declarations

//## begin module%56264E9000BB.additionalDeclarations preserve=yes
//## end module%56264E9000BB.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::GenericFunctionXMLHandler%56264DEB024A.preface preserve=yes
//## end command::GenericFunctionXMLHandler%56264DEB024A.preface

//## Class: GenericFunctionXMLHandler%56264DEB024A
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5626547100AA;GenericFunction { -> F}
//## Uses: <unnamed>%562889B0023E;reusable::Buffer { -> F}

class DllExport GenericFunctionXMLHandler : public XMLHandler  //## Inherits: <unnamed>%56264DEB0259
{
  //## begin command::GenericFunctionXMLHandler%56264DEB024A.initialDeclarations preserve=yes
  //## end command::GenericFunctionXMLHandler%56264DEB024A.initialDeclarations

  public:
    //## Constructors (generated)
      GenericFunctionXMLHandler();

    //## Constructors (specified)
      //## Operation: GenericFunctionXMLHandler%5629D314036D
      GenericFunctionXMLHandler (XMLItem* pXMLItem);

    //## Destructor (generated)
      virtual ~GenericFunctionXMLHandler();


    //## Other Operations (specified)
      //## Operation: endElement%56264E55020A
      virtual void endElement (const XMLCh* const name);

      //## Operation: startElement%56264E55020C
      virtual void startElement (const XMLCh* const name, AttributeList& attributes);

    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::Command_CAT::<unnamed>%562654FF024D
      //## Role: GenericFunctionXMLHandler::<m_pGenericFunction>%5626550101EE
      void setGenericFunction (GenericFunction * value)
      {
        //## begin command::GenericFunctionXMLHandler::setGenericFunction%5626550101EE.set preserve=no
        m_pGenericFunction = value;
        //## end command::GenericFunctionXMLHandler::setGenericFunction%5626550101EE.set
      }


    // Additional Public Declarations
      //## begin command::GenericFunctionXMLHandler%56264DEB024A.public preserve=yes
      //## end command::GenericFunctionXMLHandler%56264DEB024A.public

  protected:
    // Additional Protected Declarations
      //## begin command::GenericFunctionXMLHandler%56264DEB024A.protected preserve=yes
      //## end command::GenericFunctionXMLHandler%56264DEB024A.protected

  private:
    // Additional Private Declarations
      //## begin command::GenericFunctionXMLHandler%56264DEB024A.private preserve=yes
      //## end command::GenericFunctionXMLHandler%56264DEB024A.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%562654FF024D
      //## begin command::GenericFunctionXMLHandler::<m_pGenericFunction>%5626550101EE.role preserve=no  public: command::GenericFunction { -> RFHgN}
      GenericFunction *m_pGenericFunction;
      //## end command::GenericFunctionXMLHandler::<m_pGenericFunction>%5626550101EE.role

      //## Association: Connex Library::Command_CAT::<unnamed>%562880AA0034
      //## Role: GenericFunctionXMLHandler::<m_hCriteriaData>%562880AB010D
      //## begin command::GenericFunctionXMLHandler::<m_hCriteriaData>%562880AB010D.role preserve=no  public: command::CriteriaData { -> VHgN}
      CriteriaData m_hCriteriaData;
      //## end command::GenericFunctionXMLHandler::<m_hCriteriaData>%562880AB010D.role

      //## Association: Connex Library::Command_CAT::<unnamed>%562880C60218
      //## Role: GenericFunctionXMLHandler::<m_hCriteria>%562880C70265
      //## begin command::GenericFunctionXMLHandler::<m_hCriteria>%562880C70265.role preserve=no  public: command::Criteria { -> VHgN}
      Criteria m_hCriteria;
      //## end command::GenericFunctionXMLHandler::<m_hCriteria>%562880C70265.role

      //## Association: Connex Library::Command_CAT::<unnamed>%562880D7024A
      //## Role: GenericFunctionXMLHandler::<m_hFunction>%562880D802E5
      //## begin command::GenericFunctionXMLHandler::<m_hFunction>%562880D802E5.role preserve=no  public: command::Function { -> VHgN}
      Function m_hFunction;
      //## end command::GenericFunctionXMLHandler::<m_hFunction>%562880D802E5.role

    // Additional Implementation Declarations
      //## begin command::GenericFunctionXMLHandler%56264DEB024A.implementation preserve=yes
      //## end command::GenericFunctionXMLHandler%56264DEB024A.implementation

};

//## begin command::GenericFunctionXMLHandler%56264DEB024A.postscript preserve=yes
//## end command::GenericFunctionXMLHandler%56264DEB024A.postscript

} // namespace command

//## begin module%56264E9000BB.epilog preserve=yes
//## end module%56264E9000BB.epilog


#endif
