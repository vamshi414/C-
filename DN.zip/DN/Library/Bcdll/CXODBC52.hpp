//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5888E9940251.cm preserve=no
//	$Date:   Jul 31 2020 15:01:50  $ $Author:   e1009510  $ $Revision:   1.1  $
//## end module%5888E9940251.cm

//## begin module%5888E9940251.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5888E9940251.cp

//## Module: CXOSBC52%5888E9940251; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC52.hpp

#ifndef CXOSBC52_h
#define CXOSBC52_h 1

//## begin module%5888E9940251.additionalIncludes preserve=no
//## end module%5888E9940251.additionalIncludes

//## begin module%5888E9940251.includes preserve=yes
#include <map>
//## end module%5888E9940251.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class APIExport;

} // namespace command

//## begin module%5888E9940251.declarations preserve=no
//## end module%5888E9940251.declarations

//## begin module%5888E9940251.additionalDeclarations preserve=yes
//## end module%5888E9940251.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::APIExportFactory%5888E8470150.preface preserve=yes
//## end command::APIExportFactory%5888E8470150.preface

//## Class: APIExportFactory%5888E8470150
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5888E8A40023;APIExport { -> F}

class DllExport APIExportFactory : public reusable::Object  //## Inherits: <unnamed>%5888E89702CC
{
  //## begin command::APIExportFactory%5888E8470150.initialDeclarations preserve=yes
  //## end command::APIExportFactory%5888E8470150.initialDeclarations

  public:
    //## Constructors (generated)
      APIExportFactory();

    //## Destructor (generated)
      virtual ~APIExportFactory();


    //## Other Operations (specified)
      //## Operation: create%5888E95400A4
      virtual command::APIExport* create (const char* pszAPIType) = 0;

      //## Operation: instance%5888E9580036
      static APIExportFactory* instance ();

    // Additional Public Declarations
      //## begin command::APIExportFactory%5888E8470150.public preserve=yes
      //## end command::APIExportFactory%5888E8470150.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Classes%5888E9410356
      //## begin command::APIExportFactory::Classes%5888E9410356.attr preserve=no  public: map<string,int,less<string> > {V} 
      map<string,int,less<string> > m_hClasses;
      //## end command::APIExportFactory::Classes%5888E9410356.attr

    // Additional Protected Declarations
      //## begin command::APIExportFactory%5888E8470150.protected preserve=yes
      //## end command::APIExportFactory%5888E8470150.protected

  private:
    // Additional Private Declarations
      //## begin command::APIExportFactory%5888E8470150.private preserve=yes
      //## end command::APIExportFactory%5888E8470150.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5888E92500E0
      //## begin command::APIExportFactory::Instance%5888E92500E0.attr preserve=no  private: static APIExportFactory* {V} 0
      static APIExportFactory* m_pInstance;
      //## end command::APIExportFactory::Instance%5888E92500E0.attr

    // Additional Implementation Declarations
      //## begin command::APIExportFactory%5888E8470150.implementation preserve=yes
      //## end command::APIExportFactory%5888E8470150.implementation

};

//## begin command::APIExportFactory%5888E8470150.postscript preserve=yes
//## end command::APIExportFactory%5888E8470150.postscript

} // namespace command

//## begin module%5888E9940251.epilog preserve=yes
//## end module%5888E9940251.epilog


#endif
