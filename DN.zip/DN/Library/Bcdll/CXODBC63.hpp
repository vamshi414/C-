//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64BF7B4D030D.cm preserve=no
//## end module%64BF7B4D030D.cm

//## begin module%64BF7B4D030D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64BF7B4D030D.cp

//## Module: CXOSBC63%64BF7B4D030D; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC63.hpp

#ifndef CXOSBC63_h
#define CXOSBC63_h 1

//## begin module%64BF7B4D030D.additionalIncludes preserve=no
//## end module%64BF7B4D030D.additionalIncludes

//## begin module%64BF7B4D030D.includes preserve=yes
//## end module%64BF7B4D030D.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class GenericSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class XMLItem;
class IndustryDataHandler;

} // namespace command

//## begin module%64BF7B4D030D.declarations preserve=no
//## end module%64BF7B4D030D.declarations

//## begin module%64BF7B4D030D.additionalDeclarations preserve=yes
//## end module%64BF7B4D030D.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::IndustryData%64BF7E630230.preface preserve=yes
//## end command::IndustryData%64BF7E630230.preface

//## Class: IndustryData%64BF7E630230
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%64DD0FF6018D;segment::GenericSegment { -> F}
//## Uses: <unnamed>%64DF952A03A4;reusable::Buffer { -> F}

class DllExport IndustryData : public reusable::Object  //## Inherits: <unnamed>%64BF822A03D9
{
  //## begin command::IndustryData%64BF7E630230.initialDeclarations preserve=yes
  //## end command::IndustryData%64BF7E630230.initialDeclarations

  public:
    //## Constructors (generated)
      IndustryData();

    //## Destructor (generated)
      virtual ~IndustryData();


    //## Other Operations (specified)
      //## Operation: get%64DCFAF702AC
      void get (const string& strXMLTag, vector<pair<string,string> >& hTags);

      //## Operation: parse%64BF82D203B9
      virtual bool parse (const string& strINDUSTRY_DATA);

      //## Operation: populate%64DD0E8301E3
      bool populate (segment::GenericSegment& hGenericSegment);

      //## Operation: instance%6585AF150170
      static IndustryData* instance ();

    // Additional Public Declarations
      //## begin command::IndustryData%64BF7E630230.public preserve=yes
      //## end command::IndustryData%64BF7E630230.public

  protected:
    // Additional Protected Declarations
      //## begin command::IndustryData%64BF7E630230.protected preserve=yes
      //## end command::IndustryData%64BF7E630230.protected

  private:
    // Additional Private Declarations
      //## begin command::IndustryData%64BF7E630230.private preserve=yes
      //## end command::IndustryData%64BF7E630230.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%6585AF61020F
      //## begin command::IndustryData::Instance%6585AF61020F.attr preserve=no  private: static IndustryData* {V} 0
      static IndustryData* m_pInstance;
      //## end command::IndustryData::Instance%6585AF61020F.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%64BF834201A5
      //## Role: IndustryData::<m_pIndustryDataHandler>%64BF834300DF
      //## begin command::IndustryData::<m_pIndustryDataHandler>%64BF834300DF.role preserve=no  private: command::IndustryDataHandler { -> RFHgN}
      IndustryDataHandler *m_pIndustryDataHandler;
      //## end command::IndustryData::<m_pIndustryDataHandler>%64BF834300DF.role

      //## Association: Connex Library::Command_CAT::<unnamed>%64D652C10064
      //## Role: IndustryData::<m_pXMLItem>%64D652C10353
      //## begin command::IndustryData::<m_pXMLItem>%64D652C10353.role preserve=no  public: command::XMLItem { -> RFHgN}
      XMLItem *m_pXMLItem;
      //## end command::IndustryData::<m_pXMLItem>%64D652C10353.role

    // Additional Implementation Declarations
      //## begin command::IndustryData%64BF7E630230.implementation preserve=yes
      //## end command::IndustryData%64BF7E630230.implementation

};

//## begin command::IndustryData%64BF7E630230.postscript preserve=yes
//## end command::IndustryData%64BF7E630230.postscript

} // namespace command

//## begin module%64BF7B4D030D.epilog preserve=yes
//## end module%64BF7B4D030D.epilog


#endif
