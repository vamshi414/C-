//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%466045E200D5.cm preserve=no
//	$Date:   Jun 07 2007 13:58:28  $ $Author:   D02405  $ $Revision:   1.2  $
//## end module%466045E200D5.cm

//## begin module%466045E200D5.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%466045E200D5.cp

//## Module: CXOSBC24%466045E200D5; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC24.hpp

#ifndef CXOSBC24_h
#define CXOSBC24_h 1

//## begin module%466045E200D5.additionalIncludes preserve=no
//## end module%466045E200D5.additionalIncludes

//## begin module%466045E200D5.includes preserve=yes
//## end module%466045E200D5.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class CommandMessage;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%466045E200D5.declarations preserve=no
//## end module%466045E200D5.declarations

//## begin module%466045E200D5.additionalDeclarations preserve=yes
//## end module%466045E200D5.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::CommandWatch%466030420035.preface preserve=yes
//## end command::CommandWatch%466030420035.preface

//## Class: CommandWatch%466030420035
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%466046C00373;IF::CommandMessage { -> F}
//## Uses: <unnamed>%466047CF007A;database::Database { -> F}
//## Uses: <unnamed>%466047D003D9;reusable::Table { -> F}
//## Uses: <unnamed>%466047D5032C;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%466052850272;process::Application { -> F}
//## Uses: <unnamed>%466052B500CC;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4660570F00B0;IF::Extract { -> F}
//## Uses: <unnamed>%46683D52000F;reusable::Query { -> F}
//## Uses: <unnamed>%4668421703D8;monitor::UseCase { -> F}

class DllExport CommandWatch : public reusable::Observer  //## Inherits: <unnamed>%46604A000334
{
  //## begin command::CommandWatch%466030420035.initialDeclarations preserve=yes
  //## end command::CommandWatch%466030420035.initialDeclarations

  public:
    //## Constructors (generated)
      CommandWatch();

    //## Destructor (generated)
      virtual ~CommandWatch();


    //## Other Operations (specified)
      //## Operation: update%46604A4802FB
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin command::CommandWatch%466030420035.public preserve=yes
      //## end command::CommandWatch%466030420035.public

  protected:
    // Additional Protected Declarations
      //## begin command::CommandWatch%466030420035.protected preserve=yes
      //## end command::CommandWatch%466030420035.protected

  private:
    // Additional Private Declarations
      //## begin command::CommandWatch%466030420035.private preserve=yes
      //## end command::CommandWatch%466030420035.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CONTEXT_DATA%466053D50120
      //## begin command::CommandWatch::CONTEXT_DATA%466053D50120.attr preserve=no  private: string {U} 
      string m_strCONTEXT_DATA;
      //## end command::CommandWatch::CONTEXT_DATA%466053D50120.attr

      //## Attribute: CONTEXT_KEY%466053BB0227
      //## begin command::CommandWatch::CONTEXT_KEY%466053BB0227.attr preserve=no  private: string {U} 
      string m_strCONTEXT_KEY;
      //## end command::CommandWatch::CONTEXT_KEY%466053BB0227.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%466840D300BB
      //## Role: CommandWatch::<m_hTimer>%466840D3038A
      //## begin command::CommandWatch::<m_hTimer>%466840D3038A.role preserve=no  public: timer::Timer { -> VHgN}
      timer::Timer m_hTimer;
      //## end command::CommandWatch::<m_hTimer>%466840D3038A.role

    // Additional Implementation Declarations
      //## begin command::CommandWatch%466030420035.implementation preserve=yes
      //## end command::CommandWatch%466030420035.implementation

};

//## begin command::CommandWatch%466030420035.postscript preserve=yes
//## end command::CommandWatch%466030420035.postscript

} // namespace command

//## begin module%466045E200D5.epilog preserve=yes
//## end module%466045E200D5.epilog


#endif
