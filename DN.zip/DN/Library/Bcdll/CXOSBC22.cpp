//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%456F2ED50271.cm preserve=no
//	$Date:   18 Jan 2018 13:53:04  $ $Author:   e1009839  $ $Revision:   1.5  $
//## end module%456F2ED50271.cm

//## begin module%456F2ED50271.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%456F2ED50271.cp

//## Module: CXOSBC22%456F2ED50271; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC22.cpp

//## begin module%456F2ED50271.additionalIncludes preserve=no
//## end module%456F2ED50271.additionalIncludes

//## begin module%456F2ED50271.includes preserve=yes
//## end module%456F2ED50271.includes

#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBC22_h
#include "CXODBC22.hpp"
#endif


//## begin module%456F2ED50271.declarations preserve=no
//## end module%456F2ED50271.declarations

//## begin module%456F2ED50271.additionalDeclarations preserve=yes
//## end module%456F2ED50271.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::HandshakeCommand 

//## begin command::HandshakeCommand::Instance%456F32120251.attr preserve=no  private: static command::HandshakeCommand* {V} 0
command::HandshakeCommand* HandshakeCommand::m_pInstance = 0;
//## end command::HandshakeCommand::Instance%456F32120251.attr

HandshakeCommand::HandshakeCommand()
  //## begin HandshakeCommand::HandshakeCommand%456F2E4E00AB_const.hasinit preserve=no
  //## end HandshakeCommand::HandshakeCommand%456F2E4E00AB_const.hasinit
  //## begin HandshakeCommand::HandshakeCommand%456F2E4E00AB_const.initialization preserve=yes
   :ClientCommand("S0005D","@HANDSHK")
  //## end HandshakeCommand::HandshakeCommand%456F2E4E00AB_const.initialization
{
  //## begin command::HandshakeCommand::HandshakeCommand%456F2E4E00AB_const.body preserve=yes
   memcpy(m_sID,"BC22",4);
  //## end command::HandshakeCommand::HandshakeCommand%456F2E4E00AB_const.body
}

HandshakeCommand::HandshakeCommand (Handler* pSuccessor)
  //## begin command::HandshakeCommand::HandshakeCommand%4574FB34015B.hasinit preserve=no
  //## end command::HandshakeCommand::HandshakeCommand%4574FB34015B.hasinit
  //## begin command::HandshakeCommand::HandshakeCommand%4574FB34015B.initialization preserve=yes
   :ClientCommand("S0005D","@HANDSHK")
  //## end command::HandshakeCommand::HandshakeCommand%4574FB34015B.initialization
{
  //## begin command::HandshakeCommand::HandshakeCommand%4574FB34015B.body preserve=yes
   memcpy(m_sID,"BC22",4);
   m_pSuccessor = pSuccessor;
  //## end command::HandshakeCommand::HandshakeCommand%4574FB34015B.body
}


HandshakeCommand::~HandshakeCommand()
{
  //## begin command::HandshakeCommand::~HandshakeCommand%456F2E4E00AB_dest.body preserve=yes
  //## end command::HandshakeCommand::~HandshakeCommand%456F2E4E00AB_dest.body
}



//## Other Operations (implementation)
bool HandshakeCommand::execute ()
{
  //## begin command::HandshakeCommand::execute%456F2F700186.body preserve=yes
   string strName(CommonHeaderSegment::instance()->getCUST_ID());
   strName += " VERSION";
   GlobalContext hGlobalContext(strName.c_str());
   return hGlobalContext.put(CommonHeaderSegment::instance()->getClientVersion().c_str());
  //## end command::HandshakeCommand::execute%456F2F700186.body
}

int HandshakeCommand::deport (char** ppsBuffer)
{
  //## begin command::HandshakeCommand::deport%4581C9940167.body preserve=yes
   CommonHeaderSegment::instance()->setServiceName(m_strServiceName);
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   CommonHeaderSegment::instance()->setUserID("SYSTEM");
   CommonHeaderSegment::instance()->setCUST_ID(strCUST_ID);
   string strVersion(LATEST_MU);
   CommonHeaderSegment::instance()->setClientVersion(strVersion);
   CommonHeaderSegment::instance()->deport(ppsBuffer);
   return 0;
  //## end command::HandshakeCommand::deport%4581C9940167.body
}

command::HandshakeCommand* HandshakeCommand::instance ()
{
  //## begin command::HandshakeCommand::instance%456F3206029F.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new HandshakeCommand();
   return m_pInstance;
  //## end command::HandshakeCommand::instance%456F3206029F.body
}

// Additional Declarations
  //## begin command::HandshakeCommand%456F2E4E00AB.declarations preserve=yes
  //## end command::HandshakeCommand%456F2E4E00AB.declarations

} // namespace command

//## begin module%456F2ED50271.epilog preserve=yes
//## end module%456F2ED50271.epilog
