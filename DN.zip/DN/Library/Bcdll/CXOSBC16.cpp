//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%40B3A98F0203.cm preserve=no
//## end module%40B3A98F0203.cm

//## begin module%40B3A98F0203.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%40B3A98F0203.cp

//## Module: CXOSBC16%40B3A98F0203; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC16.cpp

//## begin module%40B3A98F0203.additionalIncludes preserve=no
//## end module%40B3A98F0203.additionalIncludes

//## begin module%40B3A98F0203.includes preserve=yes
//## end module%40B3A98F0203.includes

#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSDB34_h
#include "CXODDB34.hpp"
#endif
#ifndef CXOSBC16_h
#include "CXODBC16.hpp"
#endif


//## begin module%40B3A98F0203.declarations preserve=no
//## end module%40B3A98F0203.declarations

//## begin module%40B3A98F0203.additionalDeclarations preserve=yes
const unsigned char CPToUTF8[92][4] = {
   {0xA0, 0xE0,0xB8,0x80},
   {0xA1, 0xE0,0xB8,0x81},
   {0xA2, 0xE0,0xB8,0x82},
   {0xA3, 0xE0,0xB8,0x83},
   {0xA4, 0xE0,0xB8,0x84},
   {0xA5, 0xE0,0xB8,0x85},
   {0xA6, 0xE0,0xB8,0x86},
   {0xA7, 0xE0,0xB8,0x87},
   {0xA8, 0xE0,0xB8,0x88},
   {0xA9, 0xE0,0xB8,0x89},
   {0xAA, 0xE0,0xB8,0x8A},
   {0xAB, 0xE0,0xB8,0x8B},
   {0xAC, 0xE0,0xB8,0x8C},
   {0xAD, 0xE0,0xB8,0x8D},
   {0xAE, 0xE0,0xB8,0x8E},
   {0xAF, 0xE0,0xB8,0x8F},
   {0xB0, 0xE0,0xB8,0x90},
   {0xB1, 0xE0,0xB8,0x91},
   {0xB2, 0xE0,0xB8,0x92},
   {0xB3, 0xE0,0xB8,0x93},
   {0xB4, 0xE0,0xB8,0x94},
   {0xB5, 0xE0,0xB8,0x95},
   {0xB6, 0xE0,0xB8,0x96},
   {0xB7, 0xE0,0xB8,0x97},
   {0xB8, 0xE0,0xB8,0x98},
   {0xB9, 0xE0,0xB8,0x99},
   {0xBA, 0xE0,0xB8,0x9A},
   {0xBB, 0xE0,0xB8,0x9B},
   {0xBC, 0xE0,0xB8,0x9C},
   {0xBD, 0xE0,0xB8,0x9D},
   {0xBE, 0xE0,0xB8,0x9E},
   {0xBF, 0xE0,0xB8,0x9F},
   {0xC0, 0xE0,0xB8,0xA0},
   {0xC1, 0xE0,0xB8,0xA1},
   {0xC2, 0xE0,0xB8,0xA2},
   {0xC3, 0xE0,0xB8,0xA3},
   {0xC4, 0xE0,0xB8,0xA4},
   {0xC5, 0xE0,0xB8,0xA5},
   {0xC6, 0xE0,0xB8,0xA6},
   {0xC7, 0xE0,0xB8,0xA7},
   {0xC8, 0xE0,0xB8,0xA8},
   {0xC9, 0xE0,0xB8,0xA9},
   {0xCA, 0xE0,0xB8,0xAA},
   {0xCB, 0xE0,0xB8,0xAB},
   {0xCC, 0xE0,0xB8,0xAC},
   {0xCD, 0xE0,0xB8,0xAD},
   {0xCE, 0xE0,0xB8,0xAE},
   {0xCF, 0xE0,0xB8,0xAF},
   {0xD0, 0xE0,0xB8,0xB0},
   {0xD1, 0xE0,0xB8,0xB1},
   {0xD2, 0xE0,0xB8,0xB2},
   {0xD3, 0xE0,0xB8,0xB3},
   {0xD4, 0xE0,0xB8,0xB4},
   {0xD5, 0xE0,0xB8,0xB5},
   {0xD6, 0xE0,0xB8,0xB6},
   {0xD7, 0xE0,0xB8,0xB7},
   {0xD8, 0xE0,0xB8,0xB8},
   {0xD9, 0xE0,0xB8,0xB9},
   {0xDA, 0xE0,0xB8,0xBA},
   {0xDB, 0xE0,0xB8,0xBB},
   {0xDC, 0xE0,0xB8,0xBC},
   {0xDD, 0xE0,0xB8,0xBD},
   {0xDE, 0xE0,0xB8,0xBE},
   {0xDF, 0xE0,0xB8,0xBF},
   {0xE0, 0xE0,0xB9,0x80},
   {0xE1, 0xE0,0xB9,0x81},
   {0xE2, 0xE0,0xB9,0x82},
   {0xE3, 0xE0,0xB9,0x83},
   {0xE4, 0xE0,0xB9,0x84},
   {0xE5, 0xE0,0xB9,0x85},
   {0xE6, 0xE0,0xB9,0x86},
   {0xE7, 0xE0,0xB9,0x87},
   {0xE8, 0xE0,0xB9,0x88},
   {0xE9, 0xE0,0xB9,0x89},
   {0xEA, 0xE0,0xB9,0x8A},
   {0xEB, 0xE0,0xB9,0x8B},
   {0xEC, 0xE0,0xB9,0x8C},
   {0xED, 0xE0,0xB9,0x8D},
   {0xEE, 0xE0,0xB9,0x8E},
   {0xEF, 0xE0,0xB9,0x8F},
   {0xF0, 0xE0,0xB9,0x90},
   {0xF1, 0xE0,0xB9,0x91},
   {0xF2, 0xE0,0xB9,0x92},
   {0xF3, 0xE0,0xB9,0x93},
   {0xF4, 0xE0,0xB9,0x94},
   {0xF5, 0xE0,0xB9,0x95},
   {0xF6, 0xE0,0xB9,0x96},
   {0xF7, 0xE0,0xB9,0x97},
   {0xF8, 0xE0,0xB9,0x98},
   {0xF9, 0xE0,0xB9,0x99},
   {0xFA, 0xE0,0xB9,0x9A},
   {0xFB, 0xE0,0xB9,0x9B},
};
//## end module%40B3A98F0203.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::XMLText 

XMLText::XMLText()
  //## begin XMLText::XMLText%40B3ABBB01D4_const.hasinit preserve=no
      : m_bHTML(true),
        m_bMask(true)
  //## end XMLText::XMLText%40B3ABBB01D4_const.hasinit
  //## begin XMLText::XMLText%40B3ABBB01D4_const.initialization preserve=yes
  //## end XMLText::XMLText%40B3ABBB01D4_const.initialization
{
  //## begin command::XMLText::XMLText%40B3ABBB01D4_const.body preserve=yes
   memcpy(m_sID,"BC16",4);
  //## end command::XMLText::XMLText%40B3ABBB01D4_const.body
}


XMLText::~XMLText()
{
  //## begin command::XMLText::~XMLText%40B3ABBB01D4_dest.body preserve=yes
  //## end command::XMLText::~XMLText%40B3ABBB01D4_dest.body
}



//## Other Operations (implementation)
void XMLText::add (const char cSegment, segment::Segment* pSegment)
{
  //## begin command::XMLText::add%40B4ED13007D.body preserve=yes
   m_hSegment[cSegment] = pSegment;
  //## end command::XMLText::add%40B4ED13007D.body
}

short XMLText::sizeOfEntry (const string& strText)
{
  //## begin command::XMLText::sizeOfEntry%4EAF091C01BC.body preserve=yes
   short siSizeOfEntry = 0;
   map<char,segment::Segment*,less<char> >::iterator pSegment;
   string strColumn;
   size_t p = 0;
   size_t q = 0;
   size_t r = 0;
   while ((p = strText.find("~",r)) != string::npos)
   {
      short siFieldLength = 0;
      short siOffset = 0;
      siSizeOfEntry += (p-r);
      q = p + 1;
      while (q < strText.length() && strText[q] != '.')
         ++q;
      r = q + 1;
      while (r < strText.length() && strText[r] != '.')
         ++r;
      pSegment = m_hSegment.find(strText[p + 1]);
      if (pSegment == m_hSegment.end())
         break;
      strColumn.assign(strText.data() + q + 1,r - q - 1);
      int i = (isalpha(*(char*)strColumn.c_str()) ? 0 : 1);
      (*pSegment).second->offset((char*)strColumn.c_str() + i,siOffset,siFieldLength);
      siSizeOfEntry += siFieldLength;
   }
   siSizeOfEntry += strText.length() - r;
   return siSizeOfEntry;
  //## end command::XMLText::sizeOfEntry%4EAF091C01BC.body
}

void XMLText::substitute (string& strText, bool bTruncate, bool bSuppressEmptyTags)
{
  //## begin command::XMLText::substitute%40B4EFE402FD.body preserve=yes
   map<char,segment::Segment*,less<char> >::iterator pSegment;
   string strColumn;
   string strValue;
   size_t p = 0;
   size_t q = 0;
   size_t r = 0;
   size_t s = 0;
   while ((p = strText.find("~",s)) != string::npos )
   {
      q = p + 1;
      while (q < strText.length() && strText[q] != '.')
         ++q;
      r = q + 1;
      while (r < strText.length() && strText[r] != '.')
         ++r;
      pSegment = m_hSegment.find(strText[p + 1]);
      if (pSegment == m_hSegment.end())
         break;
      strColumn.assign(strText.data() + q + 1,r - q - 1);
      int i = (strColumn == "*PAN" || strColumn == "*PAN_TOKEN" || strColumn == "*PAN_OR_TOKEN") ? 1 : 0;
      strValue.erase();
      if (strColumn.length() > 6
         && memcmp(strColumn.data(),"SUBSTR(",7) == 0)
      {
         vector<string> hTokens;
         Buffer::parse(strColumn,"(,).",hTokens);
         if (hTokens.size() == 4)
         {
            strColumn = hTokens[1];
            int iOffset = atoi(hTokens[2].c_str());
            int iLength = atoi(hTokens[3].c_str());
            (*pSegment).second->_field((char*)strColumn.c_str(),strValue);
            if (strValue.length() >= iOffset + iLength)
               strValue = strValue.substr(iOffset,iLength);
            else
               strValue.erase();
         }
      }
      else
      if (strColumn.length() > 7
         && memcmp(strColumn.data(),"SUPPRESS(",8) == 0)
      {
         vector<string> hTokens;
         Buffer::parse(strColumn,"().",hTokens);
         if (hTokens.size() == 2)
         {
            strColumn = hTokens[1];
            (*pSegment).second->_field((char*)strColumn.c_str(),strValue);
            if (strValue == "0")
               strValue.erase();
         }
      }
      else
      if (strColumn.length() > 4
         && memcmp(strColumn.data(),"DBCS(",5) == 0)
      {
         vector<string> hTokens;
         Buffer::parse(strColumn,"().",hTokens);
         if (hTokens.size() == 2)
         {
            strColumn = hTokens[1];
            (*pSegment).second->_field((char*)strColumn.c_str(),strValue);
            string strResult;
            CodeTable::nibbleToByte(strValue.data(),strValue.length(),strResult);
            strValue.erase();
            for (int i = 0;i < strResult.length();i += 4)
            {
               strValue += "&#x";
               strValue.append(strResult.data() + i,4);
            }
         }
      }
      else
      {
         (*pSegment).second->_field((char*)strColumn.c_str() + i,strValue);
         if (bSuppressEmptyTags == false
            && (strValue.empty()
            || strValue == " "))
            strValue.assign("\" \"",3);
      }
      // checking to see if the value is either blank or needs to be ignored
      if (strValue == "~")
      {
         strText.erase();
         strValue.erase();
         return;
      }
      if (Extract::instance()->getCustomCode() != "BBL" 
         && Extract::instance()->getCustomCode() != "SECU"
         && strColumn != "NetworkResponse")
      {
         for (i = 0;i < strValue.length();++i)
            if (strValue[i] == 0xAD)
               strValue.replace(i, 1, "&#x005B;", 8);
            else
            if (strValue[i] == 0xBD)
               strValue.replace(i, 1, "&#x005D;", 8);
            else
            if (isprint((int)(unsigned char)strValue[i]) == false)
               strValue[i] = '?';
      }
      if (strColumn.length() > 4
         && memcmp(strColumn.data(), "UTF8(", 5) == 0)
      {
         vector<string> hTokens;
         Buffer::parse(strColumn, "().", hTokens);
         if (hTokens.size() == 2)
         {
            strColumn = hTokens[1];
            (*pSegment).second->_field((char*)strColumn.c_str(), strValue);
            string strBuffer(strValue);
            strValue.erase();
            for (int i = 0;i < strBuffer.length();i++)
            {
               if (isprint((int)(unsigned char)strBuffer[i]) == false
                  || strBuffer[i] == 0xAD
                  || strBuffer[i] == 0xBD)
               {
                  for (int j = 0;j < 92;j++)
                  {
                     if (strBuffer[i] == CPToUTF8[j][0])
                     {
                        for (int k = 1;k < 4;k++)
                           strValue.push_back(CPToUTF8[j][k]);
                     }
                  }
               }
               else
                  strValue.push_back(strBuffer[i]);
            }
         }
      }
      if ((strValue.length() > 1
         && (strValue[0] == '<' && strValue[strValue.length() - 1] == '>'))
         || strText.find("Z.ERROR") != string::npos)
         ;
      else
      {
         if (m_bHTML && strColumn != "NetworkResponse")
         {
            size_t pos = strValue.find('&');
            while (pos != string::npos)
            {
               strValue.replace(pos, 1, "&amp;", 5);
               pos = strValue.find('&', pos + 1);
            }
            pos = strValue.find('<');
            while (pos != string::npos)
            {
               strValue.replace(pos, 1, "&lt;", 4);
               pos = strValue.find('<');
            }
            pos = strValue.find('>');
            while (pos != string::npos)
            {
               strValue.replace(pos, 1, "&gt;", 4);
               pos = strValue.find('>');
            }
#ifndef MVS
            for (int i = 0;i < strValue.length();++i)
               if ((unsigned char)strValue[i] > 127)
                  strValue[i] = '.';
#endif
         }
      }
      if (strColumn == "*PAN"
         || strColumn == "*PAN_TOKEN"
         || strColumn == "*PAN_OR_TOKEN")
      {
         size_t i = strValue.find(' ');
         if (i == string::npos)
            i = strValue.length();
         if (i > 10)
            strValue.replace(6, i - 10, i - 10, '*');
      }
      if (bTruncate)
         rtrim(strValue);
      if (strColumn == "VCRPAN"
         || strColumn == "VCRPAN_TOKEN")
      {
         KeyRing::instance()->detokenize(strValue);
         database::AESKey::encryptWithOneTimeKey(strValue);
      }
      if (strColumn == "TOTAL")
      {
         char szReplace[32] = { "" };
         double d = atof(strValue.c_str());
         snprintf(szReplace, sizeof(szReplace), "%18.2f", d / 100);
         addCommas(szReplace, sizeof(szReplace));
         strText.replace(p, strlen(szReplace), szReplace);
      }
      else
         strText.replace(p, r - p + 1, strValue);
      s = p + strValue.length();
      if (m_bMask
         && (strColumn == "PAN"
            || strColumn == "PAN_TOKEN"
            || strColumn == "PAN_OR_TOKEN"))
      {
         size_t j = strText.length();
		 if (j <= INT_MAX - 100)  //Use INT_MAX not SIZE_MAX due to MASK call below 
		 {
		    char* psBuffer = new_char(j + 100);
		    memcpy(psBuffer, strText.data(), strText.length());
		    KeyRing::instance()->mask((int &)j, psBuffer, p, strValue.length());
		    strText.assign(psBuffer, j);
		    delete[] psBuffer;
		 }
      }
   }
  //## end command::XMLText::substitute%40B4EFE402FD.body
}

// Additional Declarations
  //## begin command::XMLText%40B3ABBB01D4.declarations preserve=yes
void XMLText::addCommas(char* pszBuffer, size_t iBufferSize)
{
//## begin command::XMLText::addCommas%5D2CC25E03B6.body preserve=yes
   string strBuffer(pszBuffer);
   if (strBuffer.length() < 4 || strBuffer.length() > iBufferSize)
   return;
   size_t nOriginalLength = strBuffer.length();
   int iPos = strBuffer.length() - 1;
   int iCount = 0;
   while (iPos)
   {
      iCount++;
      if (!isdigit(strBuffer.data()[iPos])) //weed out blanks and decimal pt.
         iCount = 0;
      if (iCount == 4)
      {
         strBuffer.insert(iPos + 1, 1, ',');
         iCount = 1;
      }
      --iPos;
   }
   if (strBuffer.length() > nOriginalLength)
   strBuffer.erase(0, strBuffer.length() - nOriginalLength);
   if (iBufferSize > strBuffer.length())
   {
      memcpy(pszBuffer, strBuffer.data(), strBuffer.length());
      pszBuffer[strBuffer.length()] = '\0';
   }
//## end command::XMLText::addCommas%5D2CC25E03B6.body
}
  //## end command::XMLText%40B3ABBB01D4.declarations

} // namespace command

//## begin module%40B3A98F0203.epilog preserve=yes
//## end module%40B3A98F0203.epilog
