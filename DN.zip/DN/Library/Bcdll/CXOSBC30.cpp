//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4ADF0C40029F.cm preserve=no
//	$Date:   Nov 06 2009 15:18:54  $ $Author:   D02405  $
//	$Revision:   1.0  $
//## end module%4ADF0C40029F.cm

//## begin module%4ADF0C40029F.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4ADF0C40029F.cp

//## Module: CXOSBC30%4ADF0C40029F; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC30.cpp

//## begin module%4ADF0C40029F.additionalIncludes preserve=no
//## end module%4ADF0C40029F.additionalIncludes

//## begin module%4ADF0C40029F.includes preserve=yes
//## end module%4ADF0C40029F.includes

#ifndef CXOSBC29_h
#include "CXODBC29.hpp"
#endif
#ifndef CXOSBC30_h
#include "CXODBC30.hpp"
#endif


//## begin module%4ADF0C40029F.declarations preserve=no
//## end module%4ADF0C40029F.declarations

//## begin module%4ADF0C40029F.additionalDeclarations preserve=yes
//## end module%4ADF0C40029F.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::EventFactory 

//## begin command::EventFactory::Instance%4ADF0725007D.attr preserve=no  private: static command::EventFactory {R} 0
command::EventFactory *EventFactory::m_pInstance = 0;
//## end command::EventFactory::Instance%4ADF0725007D.attr

EventFactory::EventFactory()
  //## begin EventFactory::EventFactory%4ADF0695031C_const.hasinit preserve=no
  //## end EventFactory::EventFactory%4ADF0695031C_const.hasinit
  //## begin EventFactory::EventFactory%4ADF0695031C_const.initialization preserve=yes
  //## end EventFactory::EventFactory%4ADF0695031C_const.initialization
{
  //## begin command::EventFactory::EventFactory%4ADF0695031C_const.body preserve=yes
   m_pInstance = this;
  //## end command::EventFactory::EventFactory%4ADF0695031C_const.body
}


EventFactory::~EventFactory()
{
  //## begin command::EventFactory::~EventFactory%4ADF0695031C_dest.body preserve=yes
   m_pInstance = 0;
  //## end command::EventFactory::~EventFactory%4ADF0695031C_dest.body
}



//## Other Operations (implementation)
command::EventFactory* EventFactory::instance ()
{
  //## begin command::EventFactory::instance%4ADF06D40157.body preserve=yes
   return m_pInstance;
  //## end command::EventFactory::instance%4ADF06D40157.body
}

// Additional Declarations
  //## begin command::EventFactory%4ADF0695031C.declarations preserve=yes
  //## end command::EventFactory%4ADF0695031C.declarations

} // namespace command

//## begin module%4ADF0C40029F.epilog preserve=yes
//## end module%4ADF0C40029F.epilog
