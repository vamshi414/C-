//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%588D0B270384.cm preserve=no
//## end module%588D0B270384.cm

//## begin module%588D0B270384.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%588D0B270384.cp

//## Module: CXOSBC54%588D0B270384; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC54.hpp

#ifndef CXOSBC54_h
#define CXOSBC54_h 1

//## begin module%588D0B270384.additionalIncludes preserve=no
//## end module%588D0B270384.additionalIncludes

//## begin module%588D0B270384.includes preserve=yes
//## end module%588D0B270384.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
class Table;
class Statement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Timestamp;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%588D0B270384.declarations preserve=no
//## end module%588D0B270384.declarations

//## begin module%588D0B270384.additionalDeclarations preserve=yes
//## end module%588D0B270384.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::APIImportRecord%588D09DB0266.preface preserve=yes
//## end command::APIImportRecord%588D09DB0266.preface

//## Class: APIImportRecord%588D09DB0266
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%588D0FDE02CB;reusable::Table { -> F}
//## Uses: <unnamed>%588D0FF10019;reusable::Statement { -> F}
//## Uses: <unnamed>%588D10320234;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%589868280110;reusable::Query { -> F}
//## Uses: <unnamed>%589887C502BE;database::Database { -> F}
//## Uses: <unnamed>%589888F602FF;timer::Clock { -> F}
//## Uses: <unnamed>%5898895A00DF;IF::Timestamp { -> F}
//## Uses: <unnamed>%5899818302B1;reusable::Transaction { -> F}
//## Uses: <unnamed>%59A6EF8E02FA;IF::Extract { -> F}

class DllExport APIImportRecord : public reusable::Observer  //## Inherits: <unnamed>%588D0A56032E
{
  //## begin command::APIImportRecord%588D09DB0266.initialDeclarations preserve=yes
  //## end command::APIImportRecord%588D09DB0266.initialDeclarations

  public:
    //## Constructors (generated)
      APIImportRecord();

    //## Destructor (generated)
      virtual ~APIImportRecord();

    //## Assignment Operation (generated)
      APIImportRecord & operator=(const APIImportRecord &right);


    //## Other Operations (specified)
      //## Operation: bind%5898669E0273
      void bind (reusable::Query& hQuery);

      //## Operation: execute%588D106002FB
      bool execute (const APIImportRecord& hAPIImportRecord);

      //## Operation: parse%588D10CF0209
      virtual bool parse (const string& strDATA_BUFFER);

      //## Operation: update%588F52060321
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: CASE_ID%5897826800A3
      const int& getCASE_ID () const
      {
        //## begin command::APIImportRecord::getCASE_ID%5897826800A3.get preserve=no
        return m_lCASE_ID;
        //## end command::APIImportRecord::getCASE_ID%5897826800A3.get
      }


      //## Attribute: DATA_BUFFER%58A0BEA800ED
      const string& getDATA_BUFFER () const
      {
        //## begin command::APIImportRecord::getDATA_BUFFER%58A0BEA800ED.get preserve=no
        return m_strDATA_BUFFER;
        //## end command::APIImportRecord::getDATA_BUFFER%58A0BEA800ED.get
      }

      void setDATA_BUFFER (const string& value)
      {
        //## begin command::APIImportRecord::setDATA_BUFFER%58A0BEA800ED.set preserve=no
        m_strDATA_BUFFER = value;
        //## end command::APIImportRecord::setDATA_BUFFER%58A0BEA800ED.set
      }


      //## Attribute: QUEUE_ID%5897823602B8
      const int& getQUEUE_ID () const
      {
        //## begin command::APIImportRecord::getQUEUE_ID%5897823602B8.get preserve=no
        return m_lQUEUE_ID;
        //## end command::APIImportRecord::getQUEUE_ID%5897823602B8.get
      }

      void setQUEUE_ID (const int& value)
      {
        //## begin command::APIImportRecord::setQUEUE_ID%5897823602B8.set preserve=no
        m_lQUEUE_ID = value;
        //## end command::APIImportRecord::setQUEUE_ID%5897823602B8.set
      }


      //## Attribute: API_RESULT%588D0ADA02BD
      const string& getAPI_RESULT () const
      {
        //## begin command::APIImportRecord::getAPI_RESULT%588D0ADA02BD.get preserve=no
        return m_strAPI_RESULT;
        //## end command::APIImportRecord::getAPI_RESULT%588D0ADA02BD.get
      }

      void setAPI_RESULT (const string& value)
      {
        //## begin command::APIImportRecord::setAPI_RESULT%588D0ADA02BD.set preserve=no
        m_strAPI_RESULT = value;
        //## end command::APIImportRecord::setAPI_RESULT%588D0ADA02BD.set
      }


      //## Attribute: RETRY_COUNT%5898664F0224
      const short& getRETRY_COUNT () const
      {
        //## begin command::APIImportRecord::getRETRY_COUNT%5898664F0224.get preserve=no
        return m_siRETRY_COUNT;
        //## end command::APIImportRecord::getRETRY_COUNT%5898664F0224.get
      }

      void setRETRY_COUNT (const short& value)
      {
        //## begin command::APIImportRecord::setRETRY_COUNT%5898664F0224.set preserve=no
        m_siRETRY_COUNT = value;
        //## end command::APIImportRecord::setRETRY_COUNT%5898664F0224.set
      }


      //## Attribute: SEQ_NO%58986C260199
      const short& getSEQ_NO () const
      {
        //## begin command::APIImportRecord::getSEQ_NO%58986C260199.get preserve=no
        return m_siSEQ_NO;
        //## end command::APIImportRecord::getSEQ_NO%58986C260199.get
      }

      void setSEQ_NO (const short& value)
      {
        //## begin command::APIImportRecord::setSEQ_NO%58986C260199.set preserve=no
        m_siSEQ_NO = value;
        //## end command::APIImportRecord::setSEQ_NO%58986C260199.set
      }


      //## Attribute: TSTAMP_EVENT%5898663102DE
      const string& getTSTAMP_EVENT () const
      {
        //## begin command::APIImportRecord::getTSTAMP_EVENT%5898663102DE.get preserve=no
        return m_strTSTAMP_EVENT;
        //## end command::APIImportRecord::getTSTAMP_EVENT%5898663102DE.get
      }

      void setTSTAMP_EVENT (const string& value)
      {
        //## begin command::APIImportRecord::setTSTAMP_EVENT%5898663102DE.set preserve=no
        m_strTSTAMP_EVENT = value;
        //## end command::APIImportRecord::setTSTAMP_EVENT%5898663102DE.set
      }


      //## Attribute: API_STATE%633EB9E40011
      const string& getAPI_STATE () const
      {
        //## begin command::APIImportRecord::getAPI_STATE%633EB9E40011.get preserve=no
        return m_strAPI_STATE;
        //## end command::APIImportRecord::getAPI_STATE%633EB9E40011.get
      }

      void setAPI_STATE (const string& value)
      {
        //## begin command::APIImportRecord::setAPI_STATE%633EB9E40011.set preserve=no
        m_strAPI_STATE = value;
        //## end command::APIImportRecord::setAPI_STATE%633EB9E40011.set
      }


      //## Attribute: REQ_TYPE%633EBB0D021D
      const string& getREQ_TYPE () const
      {
        //## begin command::APIImportRecord::getREQ_TYPE%633EBB0D021D.get preserve=no
        return m_strREQ_TYPE;
        //## end command::APIImportRecord::getREQ_TYPE%633EBB0D021D.get
      }

      void setREQ_TYPE (const string& value)
      {
        //## begin command::APIImportRecord::setREQ_TYPE%633EBB0D021D.set preserve=no
        m_strREQ_TYPE = value;
        //## end command::APIImportRecord::setREQ_TYPE%633EBB0D021D.set
      }


      //## Attribute: API_TYPE%633EBBC30074
      const string& getAPI_TYPE () const
      {
        //## begin command::APIImportRecord::getAPI_TYPE%633EBBC30074.get preserve=no
        return m_strAPI_TYPE;
        //## end command::APIImportRecord::getAPI_TYPE%633EBBC30074.get
      }

      void setAPI_TYPE (const string& value)
      {
        //## begin command::APIImportRecord::setAPI_TYPE%633EBBC30074.set preserve=no
        m_strAPI_TYPE = value;
        //## end command::APIImportRecord::setAPI_TYPE%633EBBC30074.set
      }


    // Additional Public Declarations
      //## begin command::APIImportRecord%588D09DB0266.public preserve=yes
      //## end command::APIImportRecord%588D09DB0266.public

  protected:
    // Data Members for Class Attributes

      //## begin command::APIImportRecord::CASE_ID%5897826800A3.attr preserve=no  public: int {U} 
      int m_lCASE_ID;
      //## end command::APIImportRecord::CASE_ID%5897826800A3.attr

      //## begin command::APIImportRecord::DATA_BUFFER%58A0BEA800ED.attr preserve=no  public: string {U} 
      string m_strDATA_BUFFER;
      //## end command::APIImportRecord::DATA_BUFFER%58A0BEA800ED.attr

      //## begin command::APIImportRecord::QUEUE_ID%5897823602B8.attr preserve=no  public: int {U} 
      int m_lQUEUE_ID;
      //## end command::APIImportRecord::QUEUE_ID%5897823602B8.attr

      //## begin command::APIImportRecord::API_RESULT%588D0ADA02BD.attr preserve=no  public: string {U} 
      string m_strAPI_RESULT;
      //## end command::APIImportRecord::API_RESULT%588D0ADA02BD.attr

      //## begin command::APIImportRecord::RETRY_COUNT%5898664F0224.attr preserve=no  public: short {U} 
      short m_siRETRY_COUNT;
      //## end command::APIImportRecord::RETRY_COUNT%5898664F0224.attr

      //## Attribute: RETRY_MINUTES%5A1C3F280308
      //## begin command::APIImportRecord::RETRY_MINUTES%5A1C3F280308.attr preserve=no  public: int {U} 15
      int m_iRETRY_MINUTES;
      //## end command::APIImportRecord::RETRY_MINUTES%5A1C3F280308.attr

      //## begin command::APIImportRecord::SEQ_NO%58986C260199.attr preserve=no  public: short {U} 
      short m_siSEQ_NO;
      //## end command::APIImportRecord::SEQ_NO%58986C260199.attr

      //## begin command::APIImportRecord::TSTAMP_EVENT%5898663102DE.attr preserve=no  public: string {U} 
      string m_strTSTAMP_EVENT;
      //## end command::APIImportRecord::TSTAMP_EVENT%5898663102DE.attr

      //## begin command::APIImportRecord::API_STATE%633EB9E40011.attr preserve=no  public: string {U} 
      string m_strAPI_STATE;
      //## end command::APIImportRecord::API_STATE%633EB9E40011.attr

      //## begin command::APIImportRecord::REQ_TYPE%633EBB0D021D.attr preserve=no  public: string {U} 
      string m_strREQ_TYPE;
      //## end command::APIImportRecord::REQ_TYPE%633EBB0D021D.attr

      //## begin command::APIImportRecord::API_TYPE%633EBBC30074.attr preserve=no  public: string {U} 
      string m_strAPI_TYPE;
      //## end command::APIImportRecord::API_TYPE%633EBBC30074.attr

    // Additional Protected Declarations
      //## begin command::APIImportRecord%588D09DB0266.protected preserve=yes
      //## end command::APIImportRecord%588D09DB0266.protected

  private:
    // Additional Private Declarations
      //## begin command::APIImportRecord%588D09DB0266.private preserve=yes
      //## end command::APIImportRecord%588D09DB0266.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin command::APIImportRecord%588D09DB0266.implementation preserve=yes
      //## end command::APIImportRecord%588D09DB0266.implementation

};

//## begin command::APIImportRecord%588D09DB0266.postscript preserve=yes
//## end command::APIImportRecord%588D09DB0266.postscript

} // namespace command

//## begin module%588D0B270384.epilog preserve=yes
//## end module%588D0B270384.epilog


#endif
