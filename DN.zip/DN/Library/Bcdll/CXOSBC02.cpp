//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3922DED003AC.cm preserve=no
//	$Date:   18 Jan 2018 13:52:32  $ $Author:   e1009839  $ $Revision:   1.12  $
//## end module%3922DED003AC.cm

//## begin module%3922DED003AC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3922DED003AC.cp

//## Module: CXOSBC02%3922DED003AC; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\ConnexPlatform\Server\Library\Bcdll\CXOSBC02.cpp

//## begin module%3922DED003AC.additionalIncludes preserve=no
//## end module%3922DED003AC.additionalIncludes

//## begin module%3922DED003AC.includes preserve=yes
// $Date:   18 Jan 2018 13:52:32  $ $Author:   e1009839  $ $Revision:   1.12  $
#include "CXODBS16.hpp"
//## end module%3922DED003AC.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSBS10_h
#include "CXODBS10.hpp"
#endif
#ifndef CXOSRU20_h
#include "CXODRU20.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSBC02_h
#include "CXODBC02.hpp"
#endif


//## begin module%3922DED003AC.declarations preserve=no
//## end module%3922DED003AC.declarations

//## begin module%3922DED003AC.additionalDeclarations preserve=yes
//## end module%3922DED003AC.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::ClientListCommand 

//## begin command::ClientListCommand::<m_pGlobalContext>%581C583801AD.role preserve=no  public: static database::GlobalContext {1 -> 2UFHgN}
database::GlobalContext ClientListCommand::m_pGlobalContext[2];
//## end command::ClientListCommand::<m_pGlobalContext>%581C583801AD.role

ClientListCommand::ClientListCommand()
  //## begin ClientListCommand::ClientListCommand%3922DC500301_const.hasinit preserve=no
      : m_lCount(0),
        m_lTotalRecordsFound(0),
        m_pMultipleRowContextSegment(0),
        m_pRow(0)
  //## end ClientListCommand::ClientListCommand%3922DC500301_const.hasinit
  //## begin ClientListCommand::ClientListCommand%3922DC500301_const.initialization preserve=yes
  //## end ClientListCommand::ClientListCommand%3922DC500301_const.initialization
{
  //## begin command::ClientListCommand::ClientListCommand%3922DC500301_const.body preserve=yes
  //## end command::ClientListCommand::ClientListCommand%3922DC500301_const.body
}

ClientListCommand::ClientListCommand (const char* pszMessageID, const char* pszQueue, bool bCache)
  //## begin command::ClientListCommand::ClientListCommand%39DA369401F4.hasinit preserve=no
      : m_lCount(0),
        m_lTotalRecordsFound(0),
        m_pMultipleRowContextSegment(0),
        m_pRow(0)
  //## end command::ClientListCommand::ClientListCommand%39DA369401F4.hasinit
  //## begin command::ClientListCommand::ClientListCommand%39DA369401F4.initialization preserve=yes
   ,ClientCommand(pszMessageID,pszQueue)
   ,m_bCache(bCache)
  //## end command::ClientListCommand::ClientListCommand%39DA369401F4.initialization
{
  //## begin command::ClientListCommand::ClientListCommand%39DA369401F4.body preserve=yes
   m_pMultipleRowContextSegment = new MultipleRowContextSegment();
   m_hSegments.push_back(m_pMultipleRowContextSegment);
  //## end command::ClientListCommand::ClientListCommand%39DA369401F4.body
}


ClientListCommand::~ClientListCommand()
{
  //## begin command::ClientListCommand::~ClientListCommand%3922DC500301_dest.body preserve=yes
   delete m_pMultipleRowContextSegment;
  //## end command::ClientListCommand::~ClientListCommand%3922DC500301_dest.body
}



//## Other Operations (implementation)
bool ClientListCommand::execute ()
{
  //## begin command::ClientListCommand::execute%3922DCE70268.body preserve=yes
   int iRC;
   if ((iRC = Command::parse()) != 0)
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,iRC);
      return false;
   }
   if (!m_pMultipleRowContextSegment->presence())
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_MULTIPLEROWCONTEXT_SEGMENT);
      return false;
   }
   m_lCount = 0;
   m_lTotalRecordsFound = 0;
   m_hQuery.reset();
   Message::instance(Message::INBOUND)->reset("QE CI ","S0003R");
   m_pDataBuffer = Message::instance(Message::INBOUND)->data() + 8;
   CommonHeaderSegment::instance()->deport(&m_pDataBuffer);
   m_pMRC = m_pDataBuffer;
   m_pMultipleRowContextSegment->deport(&m_pDataBuffer);
   m_pList = m_pDataBuffer;
   exportList();
   bool bCache = m_bCache;
   retrieve();
   if (m_hQuery.getAbort())
   {
      if (m_lCount > 0)
      {
         InformationSegment hInformationSegment;
         hInformationSegment.setError(STS_WARNING,STS_DATABASE_FAILURE);
         hInformationSegment.deport(&m_pDataBuffer);
      }
      else 
      {
         m_bCache = bCache;
         return false;
      }
   }
   updateList();
   m_pMultipleRowContextSegment->setTotalRecordsFound(m_lTotalRecordsFound);
   m_pMultipleRowContextSegment->setRecordsReturnedThisMessage(m_lCount);
   int lRecordNumberLastReturned = m_pMultipleRowContextSegment->recordNumberLastReturned();
   lRecordNumberLastReturned += m_lCount;
   m_pMultipleRowContextSegment->setRecordNumberLastReturned(lRecordNumberLastReturned);
   char cServerStateIndicator;
   cServerStateIndicator = (m_pMultipleRowContextSegment->clientStateIndicator() == 'I') ? 'O' : 'L';
   m_pMultipleRowContextSegment->setServerStateIndicator(cServerStateIndicator);
   m_pMultipleRowContextSegment->deport(&m_pMRC);
   getResponseTimeSegment()->deport(&m_pDataBuffer);
   if (m_pMultipleRowContextSegment->clientStateIndicator() == 'C'
      && m_bCache)
      Message::instance(Message::INBOUND)->setReceiverSTCKValue("        ");
   reply();
   m_bCache = bCache;
   return true;
  //## end command::ClientListCommand::execute%3922DCE70268.body
}

void ClientListCommand::exportList ()
{
  //## begin command::ClientListCommand::exportList%3B8FB0D10280.body preserve=yes
   m_hListSegment.deport(&m_pDataBuffer);
  //## end command::ClientListCommand::exportList%3B8FB0D10280.body
}

void ClientListCommand::sendMessage ()
{
  //## begin command::ClientListCommand::sendMessage%3922DD200166.body preserve=yes
   m_pMultipleRowContextSegment->setTotalRecordsFound(m_lTotalRecordsFound);
   m_pMultipleRowContextSegment->setRecordsReturnedThisMessage(m_lCount);
   int lRecordNumberLastReturned = m_pMultipleRowContextSegment->recordNumberLastReturned();
   lRecordNumberLastReturned += m_lCount;
   m_pMultipleRowContextSegment->setRecordNumberLastReturned(lRecordNumberLastReturned);
   char cServerStateIndicator;
   cServerStateIndicator = (m_pMultipleRowContextSegment->clientStateIndicator() == 'I') ? 'F' : 'M';
   m_pMultipleRowContextSegment->setServerStateIndicator(cServerStateIndicator);
   char* p = m_pMRC;
   m_pMultipleRowContextSegment->deport(&p);
   updateList();
   getResponseTimeSegment()->deport(&m_pDataBuffer);
   if (m_pMultipleRowContextSegment->clientStateIndicator() == 'C' && m_bCache)
      Message::instance(Message::INBOUND)->setReceiverSTCKValue("        ");
   reply();
   m_pDataBuffer = m_pList;
   exportList();
   m_pMultipleRowContextSegment->setClientStateIndicator('C');
   m_lCount = 0;
  //## end command::ClientListCommand::sendMessage%3922DD200166.body
}

void ClientListCommand::update (Subject* pSubject)
{
  //## begin command::ClientListCommand::update%3922DCF30099.body preserve=yes
   if (pSubject == m_pRow)
   {
      m_lTotalRecordsFound++;
      if ((((m_pDataBuffer - Message::instance(Message::INBOUND)->data())
         + sizeof(segResponseTimeSegment) + m_pRow->getBuffer().length()) > MAX_MESSAGE_SIZE)
         || ((!m_bCache) && (m_lTotalRecordsFound >= m_pMultipleRowContextSegment->maxRowsToFetch() + 1))
         || m_lCount >= m_pMultipleRowContextSegment->maxRowsToFetch())
      {
         sendMessage();
         if (!m_bCache)
         {
            m_hQuery.setAbort(true);
            return;
         }
      }
      m_lCount++;
      memcpy(m_pDataBuffer,m_pRow->getBuffer().data(),m_pRow->getBuffer().length());
      m_pDataBuffer += m_pRow->getBuffer().length();
      UseCase::addItem();
      return;
   }
   ClientCommand::update(pSubject);
  //## end command::ClientListCommand::update%3922DCF30099.body
}

void ClientListCommand::updateList ()
{
  //## begin command::ClientListCommand::updateList%3B8FB0D900CB.body preserve=yes
   m_hListSegment.update(m_pList,m_lCount,(int)(m_pDataBuffer - m_pList));
  //## end command::ClientListCommand::updateList%3B8FB0D900CB.body
}

int ClientListCommand::sendError (int iResultCode, char sSeverityLevel, int lInfoIDNumber, bool bReset, const char* pszText)
{
  //## begin command::ClientListCommand::sendError%581C41D50039.body preserve=yes
   m_hQuery.setAbort(true);
   if (m_strServiceName.length() > 3
     && m_strServiceName.substr(3,1) == "U"
        && lInfoIDNumber == STS_RECORD_NOT_FOUND)
      lInfoIDNumber = STS_ACTION_FAILED_RECORD_MODIFIED;
  CommonHeaderSegment::instance()->setResultCode(iResultCode);
  InformationSegment::instance()->setError(sSeverityLevel,lInfoIDNumber);
  if (pszText)
     InformationSegment::instance()->setText(pszText);
  if (bReset)
     Message::instance(Message::INBOUND)->reset("CDNCI ","S0003R");
  m_pDataBuffer = Message::instance(Message::INBOUND)->data() + 8;
  CommonHeaderSegment::instance()->deport(&m_pDataBuffer);
  m_pMultipleRowContextSegment->setServerStateIndicator('L');
  m_pMultipleRowContextSegment->deport(&m_pDataBuffer);
  InformationSegment::instance()->deport(&m_pDataBuffer);
  InformationSegment::instance()->setText("");
  getResponseTimeSegment()->deport(&m_pDataBuffer);
  reply();
  if (iResultCode != 0)
   {
      UseCase::setSuccess(false);
      Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
   }
   return -1;
  //## end command::ClientListCommand::sendError%581C41D50039.body
}

// Additional Declarations
  //## begin command::ClientListCommand%3922DC500301.declarations preserve=yes
  //## end command::ClientListCommand%3922DC500301.declarations

} // namespace command

//## begin module%3922DED003AC.epilog preserve=yes
//## end module%3922DED003AC.epilog
