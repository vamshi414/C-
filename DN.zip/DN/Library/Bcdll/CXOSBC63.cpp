//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64BF7B50003B.cm preserve=no
//## end module%64BF7B50003B.cm

//## begin module%64BF7B50003B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64BF7B50003B.cp

//## Module: CXOSBC63%64BF7B50003B; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC63.cpp

//## begin module%64BF7B50003B.additionalIncludes preserve=no
//## end module%64BF7B50003B.additionalIncludes

//## begin module%64BF7B50003B.includes preserve=yes
#ifdef _WIN32
#include "xercesc\framework\MemBufInputSource.hpp"
#include "xercesc\util\PlatformUtils.hpp"
#include "xercesc\parsers\SAXParser.hpp"
#else
#include "xercesc/framework/MemBufInputSource.hpp"
#include "xercesc/util/PlatformUtils.hpp"
#include "xercesc/parsers/SAXParser.hpp"
#endif
#include <algorithm>
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
//## end module%64BF7B50003B.includes

#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSBC64_h
#include "CXODBC64.hpp"
#endif
#ifndef CXOSBC34_h
#include "CXODBC34.hpp"
#endif
#ifndef CXOSBC63_h
#include "CXODBC63.hpp"
#endif


//## begin module%64BF7B50003B.declarations preserve=no
//## end module%64BF7B50003B.declarations

//## begin module%64BF7B50003B.additionalDeclarations preserve=yes
//## end module%64BF7B50003B.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::IndustryData 

//## begin command::IndustryData::Instance%6585AF61020F.attr preserve=no  private: static command::IndustryData* {V} 0
command::IndustryData* IndustryData::m_pInstance = 0;
//## end command::IndustryData::Instance%6585AF61020F.attr

IndustryData::IndustryData()
  //## begin IndustryData::IndustryData%64BF7E630230_const.hasinit preserve=no
      : m_pIndustryDataHandler(0),
        m_pXMLItem(0)
  //## end IndustryData::IndustryData%64BF7E630230_const.hasinit
  //## begin IndustryData::IndustryData%64BF7E630230_const.initialization preserve=yes
  //## end IndustryData::IndustryData%64BF7E630230_const.initialization
{
  //## begin command::IndustryData::IndustryData%64BF7E630230_const.body preserve=yes
   memcpy(m_sID, "BC63", 4);
   XMLPlatformUtils::Initialize();
  //## end command::IndustryData::IndustryData%64BF7E630230_const.body
}


IndustryData::~IndustryData()
{
  //## begin command::IndustryData::~IndustryData%64BF7E630230_dest.body preserve=yes
   delete m_pIndustryDataHandler;
   delete m_pXMLItem;
   XMLPlatformUtils::Terminate();
  //## end command::IndustryData::~IndustryData%64BF7E630230_dest.body
}



//## Other Operations (implementation)
void IndustryData::get (const string& strXMLTag, vector<pair<string,string> >& hTags)
{
  //## begin command::IndustryData::get%64DCFAF702AC.body preserve=yes
   vector<string> hTokens;
   map<string, string, less<string> >::const_iterator p;
   for (p = m_pXMLItem->getToken().begin(); p != m_pXMLItem->getToken().end(); p++)
   {
      hTokens.clear();
      int i = Buffer::parse((*p).first, ":", hTokens);
      if (find(hTokens.begin(), hTokens.end(), strXMLTag) == hTokens.end())
         continue;
      hTags.push_back(make_pair(hTokens[i-1], (*p).second));
   }
  //## end command::IndustryData::get%64DCFAF702AC.body
}

bool IndustryData::parse (const string& strINDUSTRY_DATA)
{
  //## begin command::IndustryData::parse%64BF82D203B9.body preserve=yes
   unsigned  int lByteCount = strINDUSTRY_DATA.length();
   char* psMemBufInputSource = new_char(lByteCount, 1);
   char* p = psMemBufInputSource;
   memcpy(p, strINDUSTRY_DATA.data(), strINDUSTRY_DATA.length());
   if (m_pXMLItem == 0)
      m_pXMLItem = new XMLItem();
   m_pXMLItem->resetToken();
   if (m_pIndustryDataHandler == 0)
      m_pIndustryDataHandler = new IndustryDataHandler(m_pXMLItem,this);
   psMemBufInputSource[lByteCount] = '\0';
#ifdef MVS
   CodeTable::translate(psMemBufInputSource, lByteCount, CodeTable::CX_EBCDIC_TO_ASCII);
#endif
   for (int i = 0; i < lByteCount; i++)
   {
      if ((psMemBufInputSource[i] < 0x20) || (psMemBufInputSource[i] > 0x7E))
         psMemBufInputSource[i] = 0x20;
   }
   XMLCh sBufld[2] = { 1, 0 };
   MemBufInputSource hMemBufInputSource((XMLByte*)psMemBufInputSource, (unsigned int)lByteCount, &sBufld[0]);
   SAXParser hSAXParser;
   hSAXParser.setDocumentHandler(m_pIndustryDataHandler);
   hSAXParser.setErrorHandler(m_pIndustryDataHandler);
   hSAXParser.parse(hMemBufInputSource);
   delete[] psMemBufInputSource;
   return true;
  //## end command::IndustryData::parse%64BF82D203B9.body
}

bool IndustryData::populate (segment::GenericSegment& hGenericSegment)
{
  //## begin command::IndustryData::populate%64DD0E8301E3.body preserve=yes
   vector<string> hTokens;
   map<string, string, less<string> >::const_iterator p;
   for (p = m_pXMLItem->getToken().begin(); p != m_pXMLItem->getToken().end(); p++)
   {
      hTokens.clear();
      int i = Buffer::parse((*p).first, ":", hTokens);
      hGenericSegment.set(hTokens[i-1].c_str(), (*p).second);
   }
   return (m_pXMLItem->getToken().size() > 0);
  //## end command::IndustryData::populate%64DD0E8301E3.body
}

IndustryData* IndustryData::instance ()
{
  //## begin command::IndustryData::instance%6585AF150170.body preserve=yes
    if (!m_pInstance)
        m_pInstance = new IndustryData();
    return m_pInstance;
  //## end command::IndustryData::instance%6585AF150170.body
}

// Additional Declarations
  //## begin command::IndustryData%64BF7E630230.declarations preserve=yes
  //## end command::IndustryData%64BF7E630230.declarations

} // namespace command

//## begin module%64BF7B50003B.epilog preserve=yes
//## end module%64BF7B50003B.epilog
