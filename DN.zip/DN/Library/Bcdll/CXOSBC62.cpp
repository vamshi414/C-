//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5F5FBF22005F.cm preserve=no
//	$Date:   Mar 10 2021 08:16:52  $ $Author:   e3028298  $
//	$Revision:   1.3  $
//## end module%5F5FBF22005F.cm

//## begin module%5F5FBF22005F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5F5FBF22005F.cp

//## Module: CXOSBC62%5F5FBF22005F; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: D:\Devel\V03.1A.R007\ConnexPlatform\Server\Library\Bcdll\CXOSBC62.cpp

//## begin module%5F5FBF22005F.additionalIncludes preserve=no
//## end module%5F5FBF22005F.additionalIncludes

//## begin module%5F5FBF22005F.includes preserve=yes
#ifdef _WIN32
#include "xercesc\framework\MemBufInputSource.hpp"
#include "xercesc\util\PlatformUtils.hpp"
#include "xercesc\parsers\SAXParser.hpp"
#else
#include "xercesc/framework/MemBufInputSource.hpp"
#include "xercesc/util/PlatformUtils.hpp"
#include "xercesc/parsers/SAXParser.hpp"
#endif
#include<algorithm>
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#include "CXODRU34.hpp"
XERCES_CPP_NAMESPACE_USE
//## end module%5F5FBF22005F.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSBC34_h
#include "CXODBC34.hpp"
#endif
#ifndef CXOSBC61_h
#include "CXODBC61.hpp"
#endif
#ifndef CXOSBC62_h
#include "CXODBC62.hpp"
#endif


//## begin module%5F5FBF22005F.declarations preserve=no
//## end module%5F5FBF22005F.declarations

//## begin module%5F5FBF22005F.additionalDeclarations preserve=yes
//## end module%5F5FBF22005F.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::GenericRule 

//## begin command::GenericRule::instance%5F5FD13B0222.attr preserve=no  private: static command::GenericRule* {U} 0
command::GenericRule* GenericRule::m_pinstance = 0;
//## end command::GenericRule::instance%5F5FD13B0222.attr

GenericRule::GenericRule()
  //## begin GenericRule::GenericRule%5F5FBE4C0304_const.hasinit preserve=no
  //## end GenericRule::GenericRule%5F5FBE4C0304_const.hasinit
  //## begin GenericRule::GenericRule%5F5FBE4C0304_const.initialization preserve=yes
  //## end GenericRule::GenericRule%5F5FBE4C0304_const.initialization
{
  //## begin command::GenericRule::GenericRule%5F5FBE4C0304_const.body preserve=yes
   memcpy(m_sID,"BC62",4);
   m_hTranslateFields.insert(map<string,pair<string,string>,less<string> >::value_type("MerchDescription",make_pair("FIN_RECORD-MERCH_TYPE","BUSINESS_CODE")));
   XMLPlatformUtils::Initialize();
   m_pXMLItem = new XMLItem;
   m_pGenericRuleXMLHandler = new GenericRuleXMLHandler(m_pXMLItem);
   m_pGenericRuleXMLHandler->setGenericRule(this);
#ifdef MVS
   FlatFile hFlatFile("JCL","DNDNRULE");
#else
   FlatFile hFlatFile("SOURCE","CXOXRULE");
#endif
   string strXML;
   char sBuffer[256];
   size_t m = 0;
   while (hFlatFile.read(sBuffer,256,&m))
   {
      while (m > 0
         && sBuffer[m - 1] == ' ')
         --m;
      sBuffer[m] = '\0';
      if (!strstr(sBuffer,"ADD NAME="))
         strXML.append(sBuffer);
   }
   if (strXML.length() > 0)
   {
      XMLCh sBufld[2] = {1,0};
#ifdef MVS
      CodeTable::translate((char*)strXML.data(),(unsigned int)strXML.length(),CodeTable::CX_EBCDIC_TO_ASCII);
#endif
      for (int i = 0; i < strXML.length(); ++i)
      {
         if (strXML[i] < 0x20)
            strXML[i] = 0x20;
         if (strXML[i] == '<' && i > 0 
            && (strXML[i-1] == '\'' || strXML[i-1] == '"'))
            strXML.replace(i,1,"&lt;");
      }
      MemBufInputSource hMemBufInputSource((XMLByte*)strXML.data(),(unsigned int)strXML.length(),&sBufld[0]);
      SAXParser hSAXParser;
      hSAXParser.setDocumentHandler(m_pGenericRuleXMLHandler);
      hSAXParser.setErrorHandler(m_pGenericRuleXMLHandler);
      hSAXParser.parse(hMemBufInputSource);
   }
  //## end command::GenericRule::GenericRule%5F5FBE4C0304_const.body
}


GenericRule::~GenericRule()
{
  //## begin command::GenericRule::~GenericRule%5F5FBE4C0304_dest.body preserve=yes
   delete m_pXMLItem;
   delete m_pGenericRuleXMLHandler;
   XMLPlatformUtils::Terminate();
  //## end command::GenericRule::~GenericRule%5F5FBE4C0304_dest.body
}



//## Other Operations (implementation)
void GenericRule::addRule (const Function& hFunction)
{
  //## begin command::GenericRule::addRule%5F5FD1710240.body preserve=yes
   m_hFunction.push_back(hFunction);
  //## end command::GenericRule::addRule%5F5FD1710240.body
}

bool GenericRule::evaluateFields (vector<CriteriaData>& hCriteriaData)
{
  //## begin command::GenericRule::evaluateFields%5F5FD20900DC.body preserve=yes
   vector<CriteriaData>::iterator pCriteriaData;
   for (pCriteriaData = hCriteriaData.begin();pCriteriaData != hCriteriaData.end();pCriteriaData++)
   {
      map<string,Segment*>::iterator pSegment;
      string strValue ;
      vector<string> hTokens;
      if (Buffer::parse((*pCriteriaData).getValue(),".",hTokens) == 2)
      {  // To set Auth Field value from Segment
         pSegment = m_hSegment.find(hTokens[0]);
         if (pSegment != m_hSegment.end())
         {
            (*pSegment).second->_field(hTokens[1].c_str(),strValue);
            (*pCriteriaData).setValue(strValue);
         }
      }
      pSegment = m_hSegment.find((*pCriteriaData).getTable());
      if (pSegment == m_hSegment.end())
         return false;
      (*pSegment).second->_field((*pCriteriaData).getField().c_str(), strValue);
      (*pCriteriaData).applyFunction(strValue);
      if (!(*pCriteriaData).compareValue(strValue))
       return false;
   }
   return true;
  //## end command::GenericRule::evaluateFields%5F5FD20900DC.body
}

bool GenericRule::evaluateRules (vector<string>& hRuleNames)
{
  //## begin command::GenericRule::evaluateRules%5F5FD1AA008B.body preserve=yes
   vector<Function>::iterator pFunction;
   for (pFunction = m_hFunction.begin(); pFunction != m_hFunction.end(); pFunction++)
   {
      vector<Criteria>::iterator pCriteria;
      for (pCriteria = (*pFunction).getCriteria().begin();pCriteria != (*pFunction).getCriteria().end();pCriteria++)
      {
         if (evaluateFields((*pCriteria).getCriteriaData()))
         {
            vector<string> hTokens;
            if (Buffer::parse((*pFunction).getName(),"-.-",hTokens) == 4)
            {
               string strValue;
               trim(hTokens[2]);
               trim(hTokens[3]);
               getField(trim(hTokens[1]),hTokens[2]+'-'+hTokens[3],strValue);
               (*pFunction).setName(hTokens[0] + "- " + strValue);
            }
            hRuleNames.push_back((*pFunction).getName());
            break;
         }
      }
   }
   return (hRuleNames.size() > 0);
  //## end command::GenericRule::evaluateRules%5F5FD1AA008B.body
}

void GenericRule::getField (const string& strTable, const string& strField, string& strValue)
{
  //## begin command::GenericRule::getField%5F5FD23B0145.body preserve=yes
   map<string, Segment*>::iterator pSegment;
   pSegment = m_hSegment.find(strTable);
   if (pSegment == m_hSegment.end())
      return;
   (*pSegment).second->_field(strField.c_str(), strValue);
  //## end command::GenericRule::getField%5F5FD23B0145.body
}

GenericRule* GenericRule::instance ()
{
  //## begin command::GenericRule::instance%5F5FD28D03C8.body preserve=yes
   if (!m_pinstance)
      m_pinstance = new GenericRule();
   return m_pinstance;
  //## end command::GenericRule::instance%5F5FD28D03C8.body
}

void GenericRule::loadSegment (const string& strTable, Segment* pSegment)
{
  //## begin command::GenericRule::loadSegment%5F5FD2C00030.body preserve=yes
   m_hSegment.insert(map<string, Segment*>::value_type(strTable,pSegment));
  //## end command::GenericRule::loadSegment%5F5FD2C00030.body
}

void GenericRule::setQueryParameter (string strTable, string strColumn)
{
  //## begin command::GenericRule::setQueryParameter%5F6CBCC80174.body preserve=yes
   m_hBindParams.push_back(make_pair(strTable,strColumn));
   m_hJoinParams.insert(strTable);
  //## end command::GenericRule::setQueryParameter%5F6CBCC80174.body
}

void GenericRule::update (Subject* pSubject)
{
  //## begin command::GenericRule::update%5F5FD2FA0394.body preserve=yes
  //## end command::GenericRule::update%5F5FD2FA0394.body
}

// Additional Declarations
  //## begin command::GenericRule%5F5FBE4C0304.declarations preserve=yes
  //## end command::GenericRule%5F5FBE4C0304.declarations

} // namespace command

//## begin module%5F5FBF22005F.epilog preserve=yes
//## end module%5F5FBF22005F.epilog
