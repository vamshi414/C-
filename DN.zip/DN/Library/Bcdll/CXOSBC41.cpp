//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52B49A590108.cm preserve=no
//	$Date:   May 14 2020 16:20:18  $ $Author:   e1009510  $
//	$Revision:   1.5  $
//## end module%52B49A590108.cm

//## begin module%52B49A590108.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52B49A590108.cp

//## Module: CXOSBC41%52B49A590108; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.4B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC41.cpp

//## begin module%52B49A590108.additionalIncludes preserve=no
//## end module%52B49A590108.additionalIncludes

//## begin module%52B49A590108.includes preserve=yes
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
//## end module%52B49A590108.includes

#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSBC41_h
#include "CXODBC41.hpp"
#endif


//## begin module%52B49A590108.declarations preserve=no
//## end module%52B49A590108.declarations

//## begin module%52B49A590108.additionalDeclarations preserve=yes
//## end module%52B49A590108.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::TimeRange

//## begin command::TimeRange::Instance%52B4766701E9.attr preserve=no  private: static command::TimeRange* {V} 0
command::TimeRange* TimeRange::m_pInstance = 0;
//## end command::TimeRange::Instance%52B4766701E9.attr

TimeRange::TimeRange()
  //## begin TimeRange::TimeRange%52B4762303A8_const.hasinit preserve=no
      : m_hInterval(BY_MINUTE),
        m_bReverse(false),
        m_lYear(0),
        m_lMonth(0),
        m_lHour(0)
  //## end TimeRange::TimeRange%52B4762303A8_const.hasinit
  //## begin TimeRange::TimeRange%52B4762303A8_const.initialization preserve=yes
  //## end TimeRange::TimeRange%52B4762303A8_const.initialization
{
  //## begin command::TimeRange::TimeRange%52B4762303A8_const.body preserve=yes
   memcpy_s(m_sID,4,"BC41",4);
  //## end command::TimeRange::TimeRange%52B4762303A8_const.body
}


TimeRange::~TimeRange()
{
  //## begin command::TimeRange::~TimeRange%52B4762303A8_dest.body preserve=yes
  //## end command::TimeRange::~TimeRange%52B4762303A8_dest.body
}



//## Other Operations (implementation)
bool TimeRange::adjustEndDateTime ()
{
  //## begin command::TimeRange::adjustEndDateTime%52B4A67A00DC.body preserve=yes
   if (m_bReverse == false)
   {
      if (m_hInterval == BY_MINUTE)
      {
         m_strEndDateTime = m_strStartDateTime;
         DateTime::adjust(m_strEndDateTime,4);
         m_strEndDateTime.replace(12,4,"5999",4);
      }
      else
      if (m_hInterval == BY_HOUR)
         m_strEndDateTime = m_strStartDateTime.substr(0,10) + "595999";
      else
      {
         m_strEndDateTime = m_strStartDateTime.substr(0,6);
         int lEndMonth = atol(m_strEndDateTime.substr(4,2).c_str());
         int lEndDay = Date::daysInMonth(atol(m_strEndDateTime.substr(0,4).c_str()),lEndMonth);
         char szTemp[PERCENTD];
         snprintf(szTemp,sizeof(szTemp),"%02d",lEndDay);
         m_strEndDateTime = m_strEndDateTime.substr(0,6) + szTemp + "23595999";
      }
      if (m_strEndDateTime > m_strFinalDateTime)
         m_strEndDateTime = m_strFinalDateTime;
   }
   else
   {
      if (m_hInterval == BY_MINUTE)
      {
         m_strEndDateTime = m_strStartDateTime;
         DateTime::adjust(m_strEndDateTime,-4);
         m_strEndDateTime.replace(12,4,"0000",4);
      }
      else
      if (m_hInterval == BY_HOUR)
      {
         m_strEndDateTime = m_strStartDateTime.substr(0,10) + "000000";
      }
      else
      {
         m_strEndDateTime = m_strStartDateTime.substr(0,6);
         m_strEndDateTime += "0100000000";
      }
      if (m_strEndDateTime < m_strFinalDateTime)
         m_strEndDateTime = m_strFinalDateTime;
   }
   return m_strEndDateTime == m_strFinalDateTime;
  //## end command::TimeRange::adjustEndDateTime%52B4A67A00DC.body
}

void TimeRange::adjustStartDateTime ()
{
  //## begin command::TimeRange::adjustStartDateTime%52B4A662003E.body preserve=yes
   if (m_bReverse == false)
   {
      if (m_hInterval == BY_MINUTE)
      {
         m_strStartDateTime = m_strEndDateTime;
         DateTime::adjust(m_strStartDateTime,1);
         m_strStartDateTime.replace(12,4,"0000",4);
      }
      else
      if (m_hInterval == BY_HOUR)
      {
         if (m_lHour == 23)
         {
            m_lHour = 0;
            string strDateTime(m_strStartDateTime);
            DateTime::adjust(strDateTime,720);
            DateTime::adjust(strDateTime,720);
            m_strStartDateTime.assign(strDateTime.data(),8);
         }
         else
            ++m_lHour;
         char szTemp[PERCENTD + 6];
         snprintf(szTemp,sizeof(szTemp),"%02d000000",m_lHour);
         m_strStartDateTime = m_strStartDateTime.substr(0,8) + szTemp;
      }
      else
      {
         if (m_lMonth == 12)
         {
            m_lMonth = 1;
            ++m_lYear;
         }
         else
            ++m_lMonth;
         char szTemp[2 * PERCENTD + 8];
         snprintf(szTemp,sizeof(szTemp),"%04d%02d0100000000",m_lYear,m_lMonth);
         m_strStartDateTime = szTemp;
      }
   }
   else
   {
      if (m_hInterval == BY_MINUTE)
      {
         m_strStartDateTime = m_strEndDateTime;
         DateTime::adjust(m_strStartDateTime,-1);
         m_strStartDateTime.replace(12,4,"5999",4);
      }
      else
      if (m_hInterval == BY_HOUR)
      {
         if (m_lHour == 0)
         {
            m_lHour = 23;
            string strDateTime(m_strStartDateTime);
            DateTime::adjust(strDateTime,-720);
            DateTime::adjust(strDateTime,-720);
            m_strStartDateTime.assign(strDateTime.data(),8);
         }
         else
            --m_lHour;
         char szTemp[PERCENTD + 6];
         snprintf(szTemp,sizeof(szTemp),"%02d595999",m_lHour);
         m_strStartDateTime = m_strStartDateTime.substr(0,8) + szTemp;
      }
      else
      {
         if (m_lMonth == 1)
         {
            m_lMonth = 12;
            --m_lYear;
         }
         else
            --m_lMonth;
         int lEndDay = Date::daysInMonth(m_lYear,m_lMonth);
         char szTemp[3 * PERCENTD];
         snprintf(szTemp,sizeof(szTemp),"%04d%02d%02d23595999",m_lYear,m_lMonth,lEndDay);
         m_strStartDateTime = szTemp;
      }
   }
  //## end command::TimeRange::adjustStartDateTime%52B4A662003E.body
}

command::TimeRange* TimeRange::instance ()
{
  //## begin command::TimeRange::instance%52B476A80298.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new TimeRange();
   return m_pInstance;
  //## end command::TimeRange::instance%52B476A80298.body
}

void TimeRange::reset ()
{
  //## begin command::TimeRange::reset%52B86B8A00DD.body preserve=yes
   m_strEndDateTime.erase();
   m_strFinalDateTime.erase();
   m_hInterval = BY_MINUTE;
   m_bReverse = false;
   m_strStartDateTime.erase();
  //## end command::TimeRange::reset%52B86B8A00DD.body
}

void TimeRange::setEndDateTime (const string& value)
{
  //## begin command::TimeRange::setEndDateTime%52B842780344.body preserve=yes
   m_strEndDateTime = value;
   m_strEndDateTime.resize(16,'0');
   if (m_strStartDateTime.empty() == false
      && m_strEndDateTime.empty() == false)
      setFinalDateTime();
  //## end command::TimeRange::setEndDateTime%52B842780344.body
}

void TimeRange::setFinalDateTime ()
{
  //## begin command::TimeRange::setFinalDateTime%52B86DBE0086.body preserve=yes
   GlobalContext hBegin("##BEGIN");
   string strBegin;
   hBegin.get(strBegin,'F');
   string strEnd(Clock::instance()->getYYYYMMDDHHMMSS().data(),6);
   if (m_strStartDateTime < m_strEndDateTime)
   {
      if ((memcmp(strEnd.data(),m_strStartDateTime.data(),6) < 0)
         || (memcmp(strBegin.data(),m_strEndDateTime.data(),6) > 0))
      {
         SOAPSegment::instance()->setRtnCde('6');
         SOAPSegment::instance()->setMsg("BC41.1","DateRange Error","Fin Table not available");
         //sendError(STS_QUERY_ERROR,STS_ERROR,STS_INVALID_DATE_RANGE);
         //return false;
      }
      if (memcmp(strBegin.data(),m_strStartDateTime.data(),6) > 0)
         m_strStartDateTime = strBegin.substr(0,6) + "0100000000";
      if (memcmp(strEnd.data(),m_strEndDateTime.data(),6) < 0)
      {
         int lEndMonth = atol(strEnd.substr(4,2).c_str());
         int lEndDay = Date::daysInMonth(atol(strEnd.substr(0,4).c_str()),lEndMonth);
         char szTemp[PERCENTD];
         snprintf(szTemp,sizeof(szTemp), "%02d", lEndDay);
         m_strEndDateTime = strEnd.substr(0,6) + szTemp + "23595999";
      }
      m_bReverse = false;
   }
   else
   {
      if ((memcmp(strEnd.data(),m_strEndDateTime.data(),6) < 0)
         || (memcmp(strBegin.data(),m_strStartDateTime.data(),6) > 0))
      {
         SOAPSegment::instance()->setRtnCde('6');
         SOAPSegment::instance()->setMsg("BC41.1","DateRange Error","Fin Table not available");
         //sendError(STS_QUERY_ERROR,STS_ERROR,STS_INVALID_DATE_RANGE);
         //return false;
      }
      if (memcmp(strBegin.data(),m_strEndDateTime.data(),6) > 0)
         m_strEndDateTime = strBegin.substr(0,6) + "0100000000";
      if (memcmp(strEnd.data(),m_strStartDateTime.data(),6) < 0)
      {
         int lEndMonth = atol(strEnd.substr(4,2).c_str());
         int lEndDay = Date::daysInMonth(atol(strEnd.substr(0,4).c_str()),lEndMonth);
         char szTemp[PERCENTD];
         snprintf(szTemp,sizeof(szTemp), "%02d", lEndDay);
         m_strStartDateTime = strEnd.substr(0,6) + szTemp + "23595999";
      }
      m_bReverse = true;
   }
   m_strFinalDateTime = m_strEndDateTime;
   m_lYear = atol(m_strStartDateTime.substr(0,4).c_str());
   m_lMonth = atol(m_strStartDateTime.substr(4,2).c_str());
   m_lHour = atoi(m_strStartDateTime.substr(8,2).c_str());
  //## end command::TimeRange::setFinalDateTime%52B86DBE0086.body
}

void TimeRange::setStartDateTime (const string& value)
{
  //## begin command::TimeRange::setStartDateTime%52B844540164.body preserve=yes
   m_strStartDateTime = value;
   m_strStartDateTime.resize(16,'0');
   if (m_strStartDateTime.empty() == false
      && m_strEndDateTime.empty() == false)
      setFinalDateTime();
  //## end command::TimeRange::setStartDateTime%52B844540164.body
}

// Additional Declarations
  //## begin command::TimeRange%52B4762303A8.declarations preserve=yes
  //## end command::TimeRange%52B4762303A8.declarations

} // namespace command

//## begin module%52B49A590108.epilog preserve=yes
//## end module%52B49A590108.epilog
