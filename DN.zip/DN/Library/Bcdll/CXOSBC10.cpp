//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%36DF00BE009E.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DF00BE009E.cm

//## begin module%36DF00BE009E.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DF00BE009E.cp

//## Module: CXOSBC10%36DF00BE009E; Package body
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC10.cpp

//## begin module%36DF00BE009E.additionalIncludes preserve=no
//## end module%36DF00BE009E.additionalIncludes

//## begin module%36DF00BE009E.includes preserve=yes
// $Date:   May 14 2020 16:29:54  $ $Author:   e1009510  $ $Revision:   1.6  $
#include <stdio.h>
#include "CXODUS13.hpp"
#define STS_ACCESS_SECURITY_UNAVAILABLE 25
//## end module%36DF00BE009E.includes

#ifndef CXOSBS10_h
#include "CXODBS10.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBC10_h
#include "CXODBC10.hpp"
#endif


//## begin module%36DF00BE009E.declarations preserve=no
//## end module%36DF00BE009E.declarations

//## begin module%36DF00BE009E.additionalDeclarations preserve=yes
//## end module%36DF00BE009E.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::GetRelationshipCommand 

GetRelationshipCommand::GetRelationshipCommand()
  //## begin GetRelationshipCommand::GetRelationshipCommand%34636A8A01CD_const.hasinit preserve=no
      : m_lRecordsReturnedThisMessage(0),
        m_lTotalRecordsFound(0)
  //## end GetRelationshipCommand::GetRelationshipCommand%34636A8A01CD_const.hasinit
  //## begin GetRelationshipCommand::GetRelationshipCommand%34636A8A01CD_const.initialization preserve=yes
   ,ClientCommand("S0005D","@##GETDATA")
  //## end GetRelationshipCommand::GetRelationshipCommand%34636A8A01CD_const.initialization
{
  //## begin command::GetRelationshipCommand::GetRelationshipCommand%34636A8A01CD_const.body preserve=yes
   memcpy_s(m_sID,4,"UC02",4);
   m_pMultipleRowContextSegment = new MultipleRowContextSegment();
   m_hSegments.push_back(m_pMultipleRowContextSegment);
   m_hQuery.attach(this);
  //## end command::GetRelationshipCommand::GetRelationshipCommand%34636A8A01CD_const.body
}

GetRelationshipCommand::GetRelationshipCommand (Handler* pSuccessor)
  //## begin command::GetRelationshipCommand::GetRelationshipCommand%3E96B4010232.hasinit preserve=no
      : m_lRecordsReturnedThisMessage(0),
        m_lTotalRecordsFound(0)
  //## end command::GetRelationshipCommand::GetRelationshipCommand%3E96B4010232.hasinit
  //## begin command::GetRelationshipCommand::GetRelationshipCommand%3E96B4010232.initialization preserve=yes
   ,ClientCommand("S0005D","@GETDATA")
  //## end command::GetRelationshipCommand::GetRelationshipCommand%3E96B4010232.initialization
{
  //## begin command::GetRelationshipCommand::GetRelationshipCommand%3E96B4010232.body preserve=yes
   memcpy_s(m_sID,4,"UC02",4);
   m_pSuccessor = pSuccessor;
   m_pMultipleRowContextSegment = new MultipleRowContextSegment();
   m_hSegments.push_back(m_pMultipleRowContextSegment);
   m_hQuery.attach(this);
  //## end command::GetRelationshipCommand::GetRelationshipCommand%3E96B4010232.body
}


GetRelationshipCommand::~GetRelationshipCommand()
{
  //## begin command::GetRelationshipCommand::~GetRelationshipCommand%34636A8A01CD_dest.body preserve=yes
   delete m_pMultipleRowContextSegment;
  //## end command::GetRelationshipCommand::~GetRelationshipCommand%34636A8A01CD_dest.body
}



//## Other Operations (implementation)
bool GetRelationshipCommand::execute ()
{
  //## begin command::GetRelationshipCommand::execute%394532200133.body preserve=yes
   // CL10: Client_Gets_Data_Security_Data
   UseCase hUseCase("CLIENT","## CL10 GET DATA SECURITY DATA");
   int iRC;
   if ((iRC = parse()) != 0)
   {
      UseCase::setSuccess(false);
      return iRC;
   }
   string strCustomerID = string(m_pMultipleRowContextSegment->STSContextData().subString(9,4));
   m_lRecordsReturnedThisMessage = m_lTotalRecordsFound = 0;
   Message::instance(Message::INBOUND)->reset("CRQCI ", "S0005R");
   m_pDataBuffer = Message::instance(Message::INBOUND)->data() + 8;
   CommonHeaderSegment::instance()->deport(&m_pDataBuffer);
   char* pMRC = m_pDataBuffer;
   m_pMultipleRowContextSegment->deport(&m_pDataBuffer);
   segRelationshipSegment *pRelationshipSegment = (segRelationshipSegment*) m_pDataBuffer;
   m_hRelationshipSegment.deport(&m_pDataBuffer);
   m_hQuery.reset();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery.setQualifier("QUALIFY","AS_USER_PROFILE");
   m_hQuery.setQualifier("QUALIFY","AS_ENTITY_ROLE");
   m_hQuery.setQualifier("QUALIFY","AS_ROLE_RELATION");
   m_hRelationshipSegment.bind(m_hQuery);
   m_hQuery.setBasicPredicate("AS_USER_PROFILE","CUST_ID","=",strCustomerID.c_str());
   pSelectStatement->execute(m_hQuery);
   if (m_lTotalRecordsFound == 0)
   {
      sendError(STS_SECURITY_ERROR,STS_SEVERE_ERROR,STS_ACCESS_SECURITY_UNAVAILABLE,false);
      return false;
   }
   
   m_pMultipleRowContextSegment->setTotalRecordsFound(m_lTotalRecordsFound);
   m_pMultipleRowContextSegment->setRecordsReturnedThisMessage(m_lRecordsReturnedThisMessage);

   int lRecordNumberLastReturned = m_pMultipleRowContextSegment->recordNumberLastReturned();
   lRecordNumberLastReturned += m_lRecordsReturnedThisMessage;
   m_pMultipleRowContextSegment->setRecordNumberLastReturned(lRecordNumberLastReturned);

   char cServerStateIndicator;
   if (lRecordNumberLastReturned < m_pMultipleRowContextSegment->totalRecordsFound())
      cServerStateIndicator = (m_pMultipleRowContextSegment->clientStateIndicator() == 'I') ? 'F' : 'M';
   else
      cServerStateIndicator = (m_pMultipleRowContextSegment->clientStateIndicator() == 'I') ? 'O' : 'L';
   m_pMultipleRowContextSegment->setServerStateIndicator(cServerStateIndicator);
   m_pMultipleRowContextSegment->deport(&pMRC);

   char szTemp[9]; 
   snprintf(szTemp,sizeof(szTemp),"%04d",m_lRecordsReturnedThisMessage);
   memcpy_s(pRelationshipSegment->sItemCount,sizeof(pRelationshipSegment->sItemCount),szTemp, 4);
   snprintf(szTemp, sizeof(szTemp),"%08d",(int)(sizeof(segRelationshipSegment) +
      (m_lRecordsReturnedThisMessage * sizeof(segRelationshipEntry))));
   memcpy_s(pRelationshipSegment->sLengthOfSegment,sizeof(pRelationshipSegment->sLengthOfSegment),szTemp, 8);
   getResponseTimeSegment()->deport(&m_pDataBuffer);
   reply();
   return true;
  //## end command::GetRelationshipCommand::execute%394532200133.body
}

int GetRelationshipCommand::parse ()
{
  //## begin command::GetRelationshipCommand::parse%39453220016F.body preserve=yes
   int iRC;
   if ((iRC = Command::parse()) != 0)
      return sendError(STS_PARSE_ERROR,STS_ERROR,iRC);
   if (!CommonHeaderSegment::instance()->presence())
      return sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_COMMON_HEADER_SEGMENT);
   if (!m_pMultipleRowContextSegment->presence())
      return sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_MULTIPLEROWCONTEXT_SEGMENT);
   return 0;
  //## end command::GetRelationshipCommand::parse%39453220016F.body
}

void GetRelationshipCommand::update (Subject* pSubject)
{
  //## begin command::GetRelationshipCommand::update%3945322001AB.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      m_lTotalRecordsFound++;
      if (m_lRecordsReturnedThisMessage < 900)
      {
         m_lRecordsReturnedThisMessage++;
         m_hRelationshipSegment.exportItem(&m_pDataBuffer);
         UseCase::addItem();
      }
      else
         m_hQuery.setAbort(true);
      return;
   }
   ClientCommand::update(pSubject);
  //## end command::GetRelationshipCommand::update%3945322001AB.body
}

// Additional Declarations
  //## begin command::GetRelationshipCommand%34636A8A01CD.declarations preserve=yes
  //## end command::GetRelationshipCommand%34636A8A01CD.declarations

} // namespace command

//## begin module%36DF00BE009E.epilog preserve=yes
//## end module%36DF00BE009E.epilog
