//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52FB8DDF03A8.cm preserve=no
//	$Date:   Dec 09 2014 15:14:26  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%52FB8DDF03A8.cm

//## begin module%52FB8DDF03A8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52FB8DDF03A8.cp

//## Module: CXOSBC44%52FB8DDF03A8; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC44.cpp

//## begin module%52FB8DDF03A8.additionalIncludes preserve=no
//## end module%52FB8DDF03A8.additionalIncludes

//## begin module%52FB8DDF03A8.includes preserve=yes
//## end module%52FB8DDF03A8.includes

#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXODDB51_h
#include "CXODDB51.hpp"
#endif
#ifndef CXOSBC44_h
#include "CXODBC44.hpp"
#endif


//## begin module%52FB8DDF03A8.declarations preserve=no
//## end module%52FB8DDF03A8.declarations

//## begin module%52FB8DDF03A8.additionalDeclarations preserve=yes
//## end module%52FB8DDF03A8.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::Constraint 

Constraint::Constraint()
  //## begin Constraint::Constraint%52FB8B0403D3_const.hasinit preserve=no
  //## end Constraint::Constraint%52FB8B0403D3_const.hasinit
  //## begin Constraint::Constraint%52FB8B0403D3_const.initialization preserve=yes
  //## end Constraint::Constraint%52FB8B0403D3_const.initialization
{
  //## begin command::Constraint::Constraint%52FB8B0403D3_const.body preserve=yes
   memcpy(m_sID,"BC44",4);
  //## end command::Constraint::Constraint%52FB8B0403D3_const.body
}


Constraint::~Constraint()
{
  //## begin command::Constraint::~Constraint%52FB8B0403D3_dest.body preserve=yes
  //## end command::Constraint::~Constraint%52FB8B0403D3_dest.body
}



//## Other Operations (implementation)
void Constraint::addColumn (const string& strTag, multimap<string,database::Column,less<string> >& hTag)
{
  //## begin command::Constraint::addColumn%52FD48FA0200.body preserve=yes
   for (vector<Predicate>::iterator p = m_hPredicate.begin();p != m_hPredicate.end();++p)
      (*p).addColumn(strTag,hTag);
  //## end command::Constraint::addColumn%52FD48FA0200.body
}

void Constraint::addPredicate (const char* pszBuffer)
{
  //## begin command::Constraint::addPredicate%52FB9038013C.body preserve=yes
   Predicate hPredicate(pszBuffer);
   m_hPredicate.push_back(hPredicate);
  //## end command::Constraint::addPredicate%52FB9038013C.body
}

bool Constraint::match (const segment::GenericSegment& hGenericSegment)
{
  //## begin command::Constraint::match%52FB8B3C0002.body preserve=yes
   for (vector<Predicate>::iterator p = m_hPredicate.begin();p != m_hPredicate.end();++p)
      if (!(*p).match(hGenericSegment))
         return false;
   return true;
  //## end command::Constraint::match%52FB8B3C0002.body
}

// Additional Declarations
  //## begin command::Constraint%52FB8B0403D3.declarations preserve=yes
  //## end command::Constraint%52FB8B0403D3.declarations

} // namespace command

//## begin module%52FB8DDF03A8.epilog preserve=yes
//## end module%52FB8DDF03A8.epilog
