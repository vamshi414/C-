//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4AEF0E16004E.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%4AEF0E16004E.cm

//## begin module%4AEF0E16004E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4AEF0E16004E.cp

//## Module: CXOSBC31%4AEF0E16004E; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC31.cpp

//## begin module%4AEF0E16004E.additionalIncludes preserve=no
//## end module%4AEF0E16004E.additionalIncludes

//## begin module%4AEF0E16004E.includes preserve=yes
//## end module%4AEF0E16004E.includes

#ifndef CXOSBC15_h
#include "CXODBC15.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC31_h
#include "CXODBC31.hpp"
#endif


//## begin module%4AEF0E16004E.declarations preserve=no
//## end module%4AEF0E16004E.declarations

//## begin module%4AEF0E16004E.additionalDeclarations preserve=yes
//## end module%4AEF0E16004E.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::Network 

//## begin command::Network::Instance%4AEF0C4803A9.attr preserve=no  private: static command::Network* {V} 0
command::Network* Network::m_pInstance = 0;
//## end command::Network::Instance%4AEF0C4803A9.attr

Network::Network()
  //## begin Network::Network%4AEF0BDC0138_const.hasinit preserve=no
  //## end Network::Network%4AEF0BDC0138_const.hasinit
  //## begin Network::Network%4AEF0BDC0138_const.initialization preserve=yes
  //## end Network::Network%4AEF0BDC0138_const.initialization
{
  //## begin command::Network::Network%4AEF0BDC0138_const.body preserve=yes
   m_pInstance = this;
  //## end command::Network::Network%4AEF0BDC0138_const.body
}


Network::~Network()
{
  //## begin command::Network::~Network%4AEF0BDC0138_dest.body preserve=yes
   m_pInstance = 0;
  //## end command::Network::~Network%4AEF0BDC0138_dest.body
}



//## Other Operations (implementation)
void Network::bind (reusable::Query& hQuery)
{
  //## begin command::Network::bind%4AEF0C55030D.body preserve=yes
  //## end command::Network::bind%4AEF0C55030D.body
}

bool Network::createCase ()
{
  //## begin command::Network::createCase%4AEF3EFF0399.body preserve=yes
   return false;
  //## end command::Network::createCase%4AEF3EFF0399.body
}

bool Network::deport (command::XMLDocument* pXMLDocument)
{
  //## begin command::Network::deport%4B9177DD003B.body preserve=yes
   pXMLDocument->add("CaseMatchingInfo");
   return true; 
  //## end command::Network::deport%4B9177DD003B.body
}

void Network::deport (char** ppsBuffer)
{
  //## begin command::Network::deport%4DB09610013C.body preserve=yes
  //## end command::Network::deport%4DB09610013C.body
}

int Network::findCase (Observer* pObserver)
{
  //## begin command::Network::findCase%4AF1E12802BF.body preserve=yes
   return 0;
  //## end command::Network::findCase%4AF1E12802BF.body
}

Network* Network::instance ()
{
  //## begin command::Network::instance%4AEF0C3601A5.body preserve=yes
   return m_pInstance;
  //## end command::Network::instance%4AEF0C3601A5.body
}

void Network::join (reusable::Query& hQuery)
{
  //## begin command::Network::join%4AEF0C6703D8.body preserve=yes
  //## end command::Network::join%4AEF0C6703D8.body
}

void Network::merge ()
{
  //## begin command::Network::merge%4CC8759B03B3.body preserve=yes
  //## end command::Network::merge%4CC8759B03B3.body
}

void Network::reset ()
{
  //## begin command::Network::reset%538F1D140113.body preserve=yes
  //## end command::Network::reset%538F1D140113.body
}

bool Network::retrieveCase ()
{
  //## begin command::Network::retrieveCase%4B95153A0249.body preserve=yes
   return false;
  //## end command::Network::retrieveCase%4B95153A0249.body
}

void Network::update (Subject* pSubject)
{
  //## begin command::Network::update%4B95301E0016.body preserve=yes
  //## end command::Network::update%4B95301E0016.body
}

void Network::updateCase ()
{
  //## begin command::Network::updateCase%4B7C290C00D6.body preserve=yes
  //## end command::Network::updateCase%4B7C290C00D6.body
}

bool Network::updateDocument (string strEXPORT_IND)
{
  //## begin command::Network::updateDocument%538F1B6E026E.body preserve=yes
   return true;
  //## end command::Network::updateDocument%538F1B6E026E.body
}

reusable::string Network::getNetworkResp ()
{
  //## begin command::Network::getNetworkResp%61C0B8E1022F.body preserve=yes
   string strResp("");
   return strResp;
  //## end command::Network::getNetworkResp%61C0B8E1022F.body
}

// Additional Declarations
  //## begin command::Network%4AEF0BDC0138.declarations preserve=yes
  //## end command::Network%4AEF0BDC0138.declarations

} // namespace command

//## begin module%4AEF0E16004E.epilog preserve=yes
//## end module%4AEF0E16004E.epilog
