//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%370BADE700E1.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%370BADE700E1.cm

//## begin module%370BADE700E1.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%370BADE700E1.cp

//## Module: CXOSBC11%370BADE700E1; Package body
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC11.cpp

//## begin module%370BADE700E1.additionalIncludes preserve=no
//## end module%370BADE700E1.additionalIncludes

//## begin module%370BADE700E1.includes preserve=yes
// $Date:   18 Jan 2018 13:52:52  $ $Author:   e1009839  $ $Revision:   1.6  $
//## end module%370BADE700E1.includes

#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSUS06_h
#include "CXODUS06.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSBC11_h
#include "CXODBC11.hpp"
#endif


//## begin module%370BADE700E1.declarations preserve=no
//## end module%370BADE700E1.declarations

//## begin module%370BADE700E1.additionalDeclarations preserve=yes
//## end module%370BADE700E1.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::UpdateCustomizationCommand 

UpdateCustomizationCommand::UpdateCustomizationCommand()
  //## begin UpdateCustomizationCommand::UpdateCustomizationCommand%3708C9580294_const.hasinit preserve=no
      : m_pListSegment(0)
  //## end UpdateCustomizationCommand::UpdateCustomizationCommand%3708C9580294_const.hasinit
  //## begin UpdateCustomizationCommand::UpdateCustomizationCommand%3708C9580294_const.initialization preserve=yes
   ,ClientCommand("S0005D","@##UPDCUST")
  //## end UpdateCustomizationCommand::UpdateCustomizationCommand%3708C9580294_const.initialization
{
  //## begin command::UpdateCustomizationCommand::UpdateCustomizationCommand%3708C9580294_const.body preserve=yes
   memcpy(m_sID,"UC03",4);
   m_pListSegment = new ListSegment();
   m_hSegments.push_back(m_pListSegment);
  //## end command::UpdateCustomizationCommand::UpdateCustomizationCommand%3708C9580294_const.body
}

UpdateCustomizationCommand::UpdateCustomizationCommand (Handler* pSuccessor)
  //## begin command::UpdateCustomizationCommand::UpdateCustomizationCommand%3E96B3AE01A5.hasinit preserve=no
      : m_pListSegment(0)
  //## end command::UpdateCustomizationCommand::UpdateCustomizationCommand%3E96B3AE01A5.hasinit
  //## begin command::UpdateCustomizationCommand::UpdateCustomizationCommand%3E96B3AE01A5.initialization preserve=yes
   ,ClientCommand("S0005D","@UPDCUST")
  //## end command::UpdateCustomizationCommand::UpdateCustomizationCommand%3E96B3AE01A5.initialization
{
  //## begin command::UpdateCustomizationCommand::UpdateCustomizationCommand%3E96B3AE01A5.body preserve=yes
   memcpy(m_sID,"UC03",4);
   m_pSuccessor = pSuccessor;
   m_pListSegment = new ListSegment();
   m_hSegments.push_back(m_pListSegment);
  //## end command::UpdateCustomizationCommand::UpdateCustomizationCommand%3E96B3AE01A5.body
}


UpdateCustomizationCommand::~UpdateCustomizationCommand()
{
  //## begin command::UpdateCustomizationCommand::~UpdateCustomizationCommand%3708C9580294_dest.body preserve=yes
   delete m_pListSegment;
  //## end command::UpdateCustomizationCommand::~UpdateCustomizationCommand%3708C9580294_dest.body
}



//## Other Operations (implementation)
bool UpdateCustomizationCommand::execute ()
{
  //## begin command::UpdateCustomizationCommand::execute%370CD149024D.body preserve=yes
   // CL22: Client_Updates_Customization_On_DB
   UseCase hUseCase("CLIENT","## CL22 UPDATE CUSTOMIZATION");
   int iRC;
   if ((iRC = Command::parse()) != 0)
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,iRC);
      UseCase::setSuccess(false);
      return false;
   }
   if (!CommonHeaderSegment::instance()->presence())
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_COMMON_HEADER_SEGMENT);
      UseCase::setSuccess(false);
      return false;
   }
   if (!m_pListSegment->presence())
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_LIST_SEGMENT);
      UseCase::setSuccess(false);
      return false;
   }
   
   Table hTable("CLIENT_CUSTOM_DATA");
   hTable.setQualifier("QUALIFY");
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   Query hQuery;
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   char* pBuffer = (char*)*m_pListSegment;
   CustomizationSegment hCustomizationSegment;
   for (int i = 0;i < m_pListSegment->itemCount();i++)
   {
      UseCase::addItem();
      hCustomizationSegment.import(&pBuffer);
      hQuery.reset();
      hQuery.setQualifier("QUALIFY","CLIENT_CUSTOM_DATA");
      hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA","CUSTOMIZE_NODE","=",(hCustomizationSegment.getCustomizeNode()).c_str());
      hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA","FULL_CUSTOMIZE_NAM","=",(hCustomizationSegment.getFullCustomizeName()).c_str());
      hTable.set("CUSTOMIZE_NODE",hCustomizationSegment.getCustomizeNode(),false,true);
      hTable.set("FULL_CUSTOMIZE_NAM",hCustomizationSegment.getFullCustomizeName(),false,true);
      hTable.set("SEQUENCE_NO",(int)(hCustomizationSegment.getSequenceNo()),true);
      hTable.set("CUSTOMIZE_DATA",hCustomizationSegment.getCustomizeData());
      if (hCustomizationSegment.getService() == 'D')
      {
         if (pDeleteStatement->execute(hQuery) == false)
         {
            iRC = -1;
            break;
         }
      }
      else
      {
         if (hCustomizationSegment.getSequenceNo() == 1)
            if (pDeleteStatement->execute(hQuery) == false)
            {
               iRC = -1;
               break;
            }
         if (pInsertStatement->execute(hTable) == false)
         {
            iRC = -1;
            break;
         }
      }
   }
   Message::instance(Message::INBOUND)->reset("CRQCI ","S0005R");
   if (iRC == 0)
   {
      m_pDataBuffer = Message::instance(Message::INBOUND)->data() + 8;
      CommonHeaderSegment::instance()->deport(&m_pDataBuffer);
      getResponseTimeSegment()->deport(&m_pDataBuffer);
      reply();
   }
   else
   {
      sendError(STS_QUERY_ERROR,STS_ERROR,STS_DATABASE_FAILURE,false);
      UseCase::setSuccess(false);
   }
   return (iRC == 0);
  //## end command::UpdateCustomizationCommand::execute%370CD149024D.body
}

// Additional Declarations
  //## begin command::UpdateCustomizationCommand%3708C9580294.declarations preserve=yes
  //## end command::UpdateCustomizationCommand%3708C9580294.declarations

} // namespace command

//## begin module%370BADE700E1.epilog preserve=yes
//## end module%370BADE700E1.epilog
