//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E9AF3510167.cm preserve=no
//	$Date:   Jun 29 2011 11:23:44  $ $Author:   E1009652  $ $Revision:   1.14  $
//## end module%3E9AF3510167.cm

//## begin module%3E9AF3510167.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%3E9AF3510167.cp

//## Module: CXOSBC08%3E9AF3510167; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC08.hpp

#ifndef CXOSBC08_h
#define CXOSBC08_h 1

//## begin module%3E9AF3510167.additionalIncludes preserve=no
//## end module%3E9AF3510167.additionalIncludes

//## begin module%3E9AF3510167.includes preserve=yes
// $Date:   Jun 29 2011 11:23:44  $ $Author:   E1009652  $ $Revision:   1.14  $
//## end module%3E9AF3510167.includes

#ifndef CXOSIF23_h
#include "CXODIF23.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSUS15_h
#include "CXODUS15.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class FlatFile;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class ConnectionSegment;
} // namespace usersegment

namespace database {
class Password;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class ResponseTimeSegment;
class ListSegment;
class CommonHeaderSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class KeyXchgCommand;
class DNSecurity;
class Security;
} // namespace command

namespace usersegment {
class LogonSegment;

} // namespace usersegment

//## begin module%3E9AF3510167.declarations preserve=no
//## end module%3E9AF3510167.declarations

//## begin module%3E9AF3510167.additionalDeclarations preserve=yes
//## end module%3E9AF3510167.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::UserSession%3E9AF2520222.preface preserve=yes
//## end command::UserSession%3E9AF2520222.preface

//## Class: UserSession%3E9AF2520222
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E9C00250000;segment::InformationSegment { -> F}
//## Uses: <unnamed>%3E9D81D202CE;IF::Trace { -> F}
//## Uses: <unnamed>%3E9D94ED00CB;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3E9D94F1008C;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%3E9D94F403A9;reusable::Query { -> F}
//## Uses: <unnamed>%3E9D984E030D;usersegment::ConnectionSegment { -> F}
//## Uses: <unnamed>%3E9D9CB20186;IF::Extract { -> F}
//## Uses: <unnamed>%3E9D9F240242;segment::ListSegment { -> F}
//## Uses: <unnamed>%3EA03F1701C5;reusable::Table { -> F}
//## Uses: <unnamed>%3EA03F1A0109;reusable::Statement { -> F}
//## Uses: <unnamed>%3EA059AF002E;database::Database { -> F}
//## Uses: <unnamed>%3F904A64008C;database::Password { -> F}
//## Uses: <unnamed>%427FA11400FA;IF::FlatFile { -> F}
//## Uses: <unnamed>%44B6B0E402DE;timer::Date { -> F}
//## Uses: <unnamed>%463F383E0399;IF::CodeTable { -> F}
//## Uses: <unnamed>%48BEC2100305;Security { -> F}
//## Uses: <unnamed>%48BEC52600EE;DNSecurity { -> F}
//## Uses: <unnamed>%48BEC52801D7;KeyXchgCommand { -> F}

class DllExport UserSession : public IF::Session  //## Inherits: <unnamed>%3E9AF26C0109
{
  //## begin command::UserSession%3E9AF2520222.initialDeclarations preserve=yes
  //## end command::UserSession%3E9AF2520222.initialDeclarations

  public:
    //## Constructors (generated)
      UserSession();

      UserSession(const UserSession &right);

    //## Destructor (generated)
      virtual ~UserSession();

    //## Assignment Operation (generated)
      UserSession & operator=(const UserSession &right);


    //## Other Operations (specified)
      //## Operation: getAlias%3E9BFB2C00CB
      static string getAlias ();

      //## Operation: key%3E9BF862007D
      const string& key () const;

      //## Operation: logoffRequest%3E9AF5120399
      bool logoffRequest (Message& hMessage, CommonHeaderSegment* pCommonHeaderSegment, ResponseTimeSegment* pResponseTimeSegment);

      //## Operation: logoffResponse%3E9D912C0222
      bool logoffResponse (Message& hMessage);

      //## Operation: logonRequest%3E9AF51602AF
      bool logonRequest (Message& hMessage, CommonHeaderSegment* pCommonHeaderSegment, LogonSegment* pLogonSegment, ResponseTimeSegment* pResponseTimeSegment);

      //## Operation: logonResponse%3E9D912F01E4
      bool logonResponse (Message& hMessage);

      //## Operation: securityResponse%3E9AF55D030D
      void securityResponse (Message& hMessage);

      //## Operation: terminate%427F60CB032C
      static void terminate ();

      //## Operation: update%3E9D859E0290
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: AliasCount%3E9BF82D0399
      static const int getAliasCount ();
      static void setAliasCount (int value);

      //## Attribute: RelationshipSegment%3E9BF839005D
      char* relationshipSegment ()
      {
        //## begin command::UserSession::relationshipSegment%3E9BF839005D.get preserve=no
        return m_pRelationshipSegment;
        //## end command::UserSession::relationshipSegment%3E9BF839005D.get
      }


      //## Attribute: Timestamp%3E9BFB69031C
      const string& getTimestamp () const
      {
        //## begin command::UserSession::getTimestamp%3E9BFB69031C.get preserve=no
        return m_strTimestamp;
        //## end command::UserSession::getTimestamp%3E9BFB69031C.get
      }

      void setTimestamp (const string& value)
      {
        //## begin command::UserSession::setTimestamp%3E9BFB69031C.set preserve=no
        m_strTimestamp = value;
        //## end command::UserSession::setTimestamp%3E9BFB69031C.set
      }


    // Additional Public Declarations
      //## begin command::UserSession%3E9AF2520222.public preserve=yes
      //## end command::UserSession%3E9AF2520222.public

  protected:
    // Additional Protected Declarations
      //## begin command::UserSession%3E9AF2520222.protected preserve=yes
      //## end command::UserSession%3E9AF2520222.protected

  private:

    //## Other Operations (specified)
      //## Operation: setAlias%42CD3D2103A9
      void setAlias ();

      //## Operation: validatePassword%427BD40B001F
      void validatePassword (string& strUSER_PASSWORD);

      //## Operation: validateSignature%427BD41F0000
      void validateSignature (const string& strUserID, const string& strSignature);

      //## Operation: validateSignatureSSO%4E0B4FDA0368
      void validateSignatureSSO (const string& strUserID, const string& strSignature);

    // Additional Private Declarations
      //## begin command::UserSession%3E9AF2520222.private preserve=yes
      //## end command::UserSession%3E9AF2520222.private
  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::UserSession::AliasCount%3E9BF82D0399.attr preserve=no  public: static int {V} 0
      static int m_lAliasCount;
      //## end command::UserSession::AliasCount%3E9BF82D0399.attr

      //## Attribute: Buffer%3E9D993600FA
      //## begin command::UserSession::Buffer%3E9D993600FA.attr preserve=no  private: char* {V} 0
      char* m_pBuffer;
      //## end command::UserSession::Buffer%3E9D993600FA.attr

      //## Attribute: CUST_ID%3E9D98DF0251
      //## begin command::UserSession::CUST_ID%3E9D98DF0251.attr preserve=no  private: string {V} 
      string m_strCUST_ID;
      //## end command::UserSession::CUST_ID%3E9D98DF0251.attr

      //## Attribute: Key%427F619B0177
      //## begin command::UserSession::Key%427F619B0177.attr preserve=no  private: static void* {V} 0
      static void* m_pKey;
      //## end command::UserSession::Key%427F619B0177.attr

      //## begin command::UserSession::RelationshipSegment%3E9BF839005D.attr preserve=no  public: char* {V} 0
      char* m_pRelationshipSegment;
      //## end command::UserSession::RelationshipSegment%3E9BF839005D.attr

      //## begin command::UserSession::Timestamp%3E9BFB69031C.attr preserve=no  public: string {U} 
      string m_strTimestamp;
      //## end command::UserSession::Timestamp%3E9BFB69031C.attr

      //## Attribute: USER_NAME%4A9E999E013A
      //## begin command::UserSession::USER_NAME%4A9E999E013A.attr preserve=no  private: string {U} 
      string m_strUSER_NAME;
      //## end command::UserSession::USER_NAME%4A9E999E013A.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%3E9BFBEA00DA
      //## Role: UserSession::<m_hMessage>%3E9BFBEA035B
      //## begin command::UserSession::<m_hMessage>%3E9BFBEA035B.role preserve=no  public: IF::Message { -> VHgN}
      IF::Message m_hMessage;
      //## end command::UserSession::<m_hMessage>%3E9BFBEA035B.role

      //## Association: Connex Library::Command_CAT::<unnamed>%3E9BFC3E0232
      //## Role: UserSession::<m_hResourceListSegment>%3E9BFC3F00CB
      //## begin command::UserSession::<m_hResourceListSegment>%3E9BFC3F00CB.role preserve=no  public: usersegment::ResourceListSegment { -> VHgN}
      usersegment::ResourceListSegment m_hResourceListSegment;
      //## end command::UserSession::<m_hResourceListSegment>%3E9BFC3F00CB.role

      //## Association: Connex Library::Command_CAT::<unnamed>%3E9BFD3F03A9
      //## Role: UserSession::<m_pCommonHeaderSegment>%3E9BFD4001A5
      //## begin command::UserSession::<m_pCommonHeaderSegment>%3E9BFD4001A5.role preserve=no  public: segment::CommonHeaderSegment { -> RFHgN}
      segment::CommonHeaderSegment *m_pCommonHeaderSegment;
      //## end command::UserSession::<m_pCommonHeaderSegment>%3E9BFD4001A5.role

      //## Association: Connex Library::Command_CAT::<unnamed>%3E9BFE78029F
      //## Role: UserSession::<m_pResponseTimeSegment>%3E9BFE790119
      //## begin command::UserSession::<m_pResponseTimeSegment>%3E9BFE790119.role preserve=no  public: segment::ResponseTimeSegment { -> RFHgN}
      segment::ResponseTimeSegment *m_pResponseTimeSegment;
      //## end command::UserSession::<m_pResponseTimeSegment>%3E9BFE790119.role

      //## Association: Connex Library::Command_CAT::<unnamed>%3E9D9F5E0251
      //## Role: UserSession::<m_pLogonSegment>%3E9D9F5F02BF
      //## begin command::UserSession::<m_pLogonSegment>%3E9D9F5F02BF.role preserve=no  public: usersegment::LogonSegment { -> RFHgN}
      usersegment::LogonSegment *m_pLogonSegment;
      //## end command::UserSession::<m_pLogonSegment>%3E9D9F5F02BF.role

    // Additional Implementation Declarations
      //## begin command::UserSession%3E9AF2520222.implementation preserve=yes
      //## end command::UserSession%3E9AF2520222.implementation

};

//## begin command::UserSession%3E9AF2520222.postscript preserve=yes
//## end command::UserSession%3E9AF2520222.postscript

} // namespace command

//## begin module%3E9AF3510167.epilog preserve=yes
using namespace command;
//## end module%3E9AF3510167.epilog


#endif
