//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5625F9FE024C.cm preserve=no
//	$Date:   May 14 2020 16:20:18  $ $Author:   e1009510  $ $Revision:   1.4  $
//## end module%5625F9FE024C.cm

//## begin module%5625F9FE024C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5625F9FE024C.cp

//## Module: CXOSBC49%5625F9FE024C; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC49.cpp

//## begin module%5625F9FE024C.additionalIncludes preserve=no
//## end module%5625F9FE024C.additionalIncludes

//## begin module%5625F9FE024C.includes preserve=yes
#ifdef _WIN32
#include "xercesc\framework\MemBufInputSource.hpp"
#include "xercesc\util\PlatformUtils.hpp"
#include "xercesc\parsers\SAXParser.hpp"
#else
#include "xercesc/framework/MemBufInputSource.hpp"
#include "xercesc/util/PlatformUtils.hpp"
#include "xercesc/parsers/SAXParser.hpp"
#endif
#include<algorithm>
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
XERCES_CPP_NAMESPACE_USE
//## end module%5625F9FE024C.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSBC46_h
#include "CXODBC46.hpp"
#endif
#ifndef CXOSBC47_h
#include "CXODBC47.hpp"
#endif
#ifndef CXOSBC50_h
#include "CXODBC50.hpp"
#endif
#ifndef CXOSBC34_h
#include "CXODBC34.hpp"
#endif
#ifndef CXOSBC49_h
#include "CXODBC49.hpp"
#endif


//## begin module%5625F9FE024C.declarations preserve=no
//## end module%5625F9FE024C.declarations

//## begin module%5625F9FE024C.additionalDeclarations preserve=yes
//## end module%5625F9FE024C.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::GenericFunction 

//## begin command::GenericFunction::instance%562600330259.attr preserve=no  private: static command::GenericFunction* {U} 0
command::GenericFunction* GenericFunction::m_pinstance = 0;
//## end command::GenericFunction::instance%562600330259.attr

GenericFunction::GenericFunction()
  //## begin GenericFunction::GenericFunction%5625DB8C00A5_const.hasinit preserve=no
      : m_pGenericFunctionXMLHandler(0),
        m_pXMLItem(0)
  //## end GenericFunction::GenericFunction%5625DB8C00A5_const.hasinit
  //## begin GenericFunction::GenericFunction%5625DB8C00A5_const.initialization preserve=yes
  //## end GenericFunction::GenericFunction%5625DB8C00A5_const.initialization
{
  //## begin command::GenericFunction::GenericFunction%5625DB8C00A5_const.body preserve=yes
   memcpy(m_sID,"BC49",4);
   XMLPlatformUtils::Initialize();
   m_pXMLItem = new XMLItem;
   m_pGenericFunctionXMLHandler = new GenericFunctionXMLHandler(m_pXMLItem);
   m_pGenericFunctionXMLHandler->setGenericFunction(this);
#ifdef MVS
   FlatFile hFlatFile("JCL","DNDNGENR");
#else
   FlatFile hFlatFile("SOURCE","CXOXGENR");
#endif
   string strXML;
   char sBuffer[256];
   size_t m = 0;
   while (hFlatFile.read(sBuffer,255,&m))
   {
      int i = m;
      while (i > 0
         && sBuffer[i - 1] == ' ')
         --i;
      sBuffer[i] = '\0';
      if (!strstr(sBuffer,"ADD NAME="))
         strXML.append(sBuffer);
   }
   if (strXML.length() > 0)
   {
      XMLCh sBufld[2] = {1,0};
#ifdef MVS
      CodeTable::translate((char*)strXML.data(),(unsigned int)strXML.length(),CodeTable::CX_EBCDIC_TO_ASCII);
#endif
      for (int i = 0;i < strXML.length();++i)
         if (strXML[i] < 0x20)
            strXML[i] = 0x20;
      MemBufInputSource hMemBufInputSource((XMLByte*)strXML.data(),(unsigned int)strXML.length(),&sBufld[0]);
      SAXParser hSAXParser;
      hSAXParser.setDocumentHandler(m_pGenericFunctionXMLHandler);
      hSAXParser.setErrorHandler(m_pGenericFunctionXMLHandler);
      hSAXParser.parse(hMemBufInputSource);
   }
  //## end command::GenericFunction::GenericFunction%5625DB8C00A5_const.body
}


GenericFunction::~GenericFunction()
{
  //## begin command::GenericFunction::~GenericFunction%5625DB8C00A5_dest.body preserve=yes
   delete m_pXMLItem;
   delete m_pGenericFunctionXMLHandler;
   XMLPlatformUtils::Terminate();
  //## end command::GenericFunction::~GenericFunction%5625DB8C00A5_dest.body
}



//## Other Operations (implementation)
void GenericFunction::addFunction (const Function& hFunction)
{
  //## begin command::GenericFunction::addFunction%5628B2BC01BE.body preserve=yes
   m_hFunction.push_back(hFunction);
  //## end command::GenericFunction::addFunction%5628B2BC01BE.body
}

bool GenericFunction::evaluate (const string& strFunction, vector<pair<string,string> >& hResult)
{
  //## begin command::GenericFunction::evaluate%5626088B0290.body preserve=yes
   Function hFunction;
   hFunction.setName(strFunction);
   vector<Function>::iterator pFunction;
   pFunction = find(m_hFunction.begin(),m_hFunction.end(),hFunction);
   if (pFunction == m_hFunction.end())
      return false;
   hFunction = (*pFunction);
   vector<Criteria>::iterator pCriteria;
   for (pCriteria = hFunction.getCriteria().begin();pCriteria != hFunction.getCriteria().end();pCriteria++)
   {
      if (evaluateFields(pCriteria->getCriteriaData()))
      {
         hResult = pCriteria->getResult();
         return true;
      }
   }
   return false;
  //## end command::GenericFunction::evaluate%5626088B0290.body
}

bool GenericFunction::evaluateFields (vector<CriteriaData>& hCriteriaData)
{
  //## begin command::GenericFunction::evaluateFields%562608C10055.body preserve=yes
   vector<CriteriaData>::iterator pCriteriaData;
   for (pCriteriaData = hCriteriaData.begin();pCriteriaData != hCriteriaData.end();pCriteriaData++)
   {
      map<string,Segment*>::iterator pSegment;
      pSegment = m_hSegment.find(pCriteriaData->getTable());
      if (pSegment == m_hSegment.end())
         return false;
      string strValue ;
      (*pSegment).second->_field(pCriteriaData->getField().c_str(),strValue);
      if (!pCriteriaData->compareValue(strValue))
         return false;
   }
   return true;
  //## end command::GenericFunction::evaluateFields%562608C10055.body
}

void GenericFunction::getField (const string& strTable, const string& strField, string& strValue)
{
  //## begin command::GenericFunction::getField%5874ECDC017B.body preserve=yes
   map<string, Segment*>::iterator pSegment;
   pSegment = m_hSegment.find(strTable);
   if (pSegment == m_hSegment.end())
      strValue == "";
   (*pSegment).second->_field(strField.c_str(), strValue);
  //## end command::GenericFunction::getField%5874ECDC017B.body
}

GenericFunction* GenericFunction::instance ()
{
  //## begin command::GenericFunction::instance%5625FFA3023D.body preserve=yes
   if (!m_pinstance)
      m_pinstance = new GenericFunction();
   return m_pinstance;
  //## end command::GenericFunction::instance%5625FFA3023D.body
}

void GenericFunction::loadSegment (const string& strTable, Segment* pSegment)
{
  //## begin command::GenericFunction::loadSegment%5626086701A4.body preserve=yes
   m_hSegment.insert(map<string,Segment*>::value_type(strTable,pSegment));
  //## end command::GenericFunction::loadSegment%5626086701A4.body
}

void GenericFunction::update (Subject* pSubject)
{
  //## begin command::GenericFunction::update%5626015D00C0.body preserve=yes
  //## end command::GenericFunction::update%5626015D00C0.body
}

// Additional Declarations
  //## begin command::GenericFunction%5625DB8C00A5.declarations preserve=yes
  //## end command::GenericFunction%5625DB8C00A5.declarations

} // namespace command

//## begin module%5625F9FE024C.epilog preserve=yes
//## end module%5625F9FE024C.epilog
