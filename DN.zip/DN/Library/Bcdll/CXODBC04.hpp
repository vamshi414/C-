//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E9717B803A9.cm preserve=no
//	$Date:   18 Jan 2018 13:52:12  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3E9717B803A9.cm

//## begin module%3E9717B803A9.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%3E9717B803A9.cp

//## Module: CXOSBC04%3E9717B803A9; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC04.hpp

#ifndef CXOSBC04_h
#define CXOSBC04_h 1

//## begin module%3E9717B803A9.additionalIncludes preserve=no
//## end module%3E9717B803A9.additionalIncludes

//## begin module%3E9717B803A9.includes preserve=yes
// $Date:   18 Jan 2018 13:52:12  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3E9717B803A9.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class UserPool;
} // namespace command

namespace segment {
class InformationSegment;
} // namespace segment

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class LogonSegment;

} // namespace usersegment

//## begin module%3E9717B803A9.declarations preserve=no
//## end module%3E9717B803A9.declarations

//## begin module%3E9717B803A9.additionalDeclarations preserve=yes
#include "CXODUS23.hpp"
//## end module%3E9717B803A9.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::LogonCommand%3E971714032C.preface preserve=yes
//## end command::LogonCommand%3E971714032C.preface

//## Class: LogonCommand%3E971714032C
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E98323C01C5;monitor::UseCase { -> F}
//## Uses: <unnamed>%3E9BFBA702EE;IF::Message { -> F}
//## Uses: <unnamed>%3E9BFDAF033C;segment::InformationSegment { -> F}
//## Uses: <unnamed>%3E9BFE45038A;UserPool { -> F}
//## Uses: <unnamed>%463221940251;IF::Extract { -> F}
//## Uses: <unnamed>%463221B801B5;segment::CommonHeaderSegment { -> F}

class DllExport LogonCommand : public ClientCommand  //## Inherits: <unnamed>%3E9AFC77009C
{
  //## begin command::LogonCommand%3E971714032C.initialDeclarations preserve=yes
  //## end command::LogonCommand%3E971714032C.initialDeclarations

  public:
    //## Constructors (generated)
      LogonCommand();

    //## Constructors (specified)
      //## Operation: LogonCommand%3E9733FC0167
      LogonCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~LogonCommand();


    //## Other Operations (specified)
      //## Operation: execute%3E9AFCA302EE
      //	Perform the functions of this command.
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>CQ
      //	<h2>FI
      //	<h3>Configuration Repository Tables
      //	<p>
      //	The following tables are used by Access Security:
      //	<ul>
      //	<li><i>qualify</i>.AS_ENTITY
      //	<li><i>qualify</i>.AS_ENTITY_ROLE
      //	<li><i>qualify</i>.AS_PERMISSION
      //	<li><i>qualify</i>.AS_PROFILE
      //	<li><i>qualify</i>.AS_PROFILE_ENTRY
      //	<li><i>qualify</i>.AS_RELATIONSHIP
      //	<li><i>qualify</i>.AS_ROLE
      //	<li><i>qualify</i>.AS_ROLE_RELATION
      //	<li><i>qualify</i>.AS_USER_LOGON
      //	<li><i>qualify</i>.AS_USER_PROFILE
      //	</ul>
      //	<h2>MS
      //	<h3>Security Administration
      //	<p>
      //	Use the CR Client for DataNavigator Security to:
      //	<ul>
      //	<li>Add new end users to the system
      //	<li>Reset passwords
      //	<li>Grant access to DataNavigator data
      //	<li>Grant access to DataNavigator functionality
      //	</ul>
      //	Refer to the <i>eFunds DataNavigator Security Guide</i>
      //	for more information.
      //	</body>
      virtual bool execute ();

      //## Operation: deport%46321D88003E
      //	Export this command into a message buffer.
      //## Semantics:
      //	1. Call Segment::deport for each segment that is present
      //	in this command.
      //## Postconditions:
      //	1. The provided buffer pointer will point to the byte
      //	following the last segment exported.
      int deport (char** ppsBuffer);

    // Additional Public Declarations
      //## begin command::LogonCommand%3E971714032C.public preserve=yes
      //## end command::LogonCommand%3E971714032C.public

  protected:
    // Additional Protected Declarations
      //## begin command::LogonCommand%3E971714032C.protected preserve=yes
      //## end command::LogonCommand%3E971714032C.protected

  private:
    // Additional Private Declarations
      //## begin command::LogonCommand%3E971714032C.private preserve=yes
      //## end command::LogonCommand%3E971714032C.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%46326DD403A9
      //## Role: LogonCommand::<m_pLogonSegment>%46326DD5029F
      //## begin command::LogonCommand::<m_pLogonSegment>%46326DD5029F.role preserve=no  public: usersegment::LogonSegment { -> RFHgN}
      usersegment::LogonSegment *m_pLogonSegment;
      //## end command::LogonCommand::<m_pLogonSegment>%46326DD5029F.role

    // Additional Implementation Declarations
      //## begin command::LogonCommand%3E971714032C.implementation preserve=yes
      usersegment::AuthenticateSegment *m_pAuthenticateSegment;
      //## end command::LogonCommand%3E971714032C.implementation

};

//## begin command::LogonCommand%3E971714032C.postscript preserve=yes
//## end command::LogonCommand%3E971714032C.postscript

} // namespace command

//## begin module%3E9717B803A9.epilog preserve=yes
using namespace command;
//## end module%3E9717B803A9.epilog


#endif
