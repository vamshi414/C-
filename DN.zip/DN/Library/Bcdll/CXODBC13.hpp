//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%370A61C70133.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%370A61C70133.cm

//## begin module%370A61C70133.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%370A61C70133.cp

//## Module: CXOSBC13%370A61C70133; Package specification
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC13.hpp

#ifndef CXOSBC13_h
#define CXOSBC13_h 1

//## begin module%370A61C70133.additionalIncludes preserve=no
//## end module%370A61C70133.additionalIncludes

//## begin module%370A61C70133.includes preserve=yes
// $Date:   Apr 08 2004 11:17:20  $ $Author:   D02405  $ $Revision:   1.1  $
//## end module%370A61C70133.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class DateTime;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class CustomizationSecuritySegment;
class CustomizationStatusSegment;
class GetCustomizationStatusSegment;
} // namespace usersegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class ResponseTimeSegment;
class ListSegment;
class CommonHeaderSegment;

} // namespace segment

//## begin module%370A61C70133.declarations preserve=no
//## end module%370A61C70133.declarations

//## begin module%370A61C70133.additionalDeclarations preserve=yes
//## end module%370A61C70133.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::GetCustomizationStatusCommand%370A604F0382.preface preserve=yes
//## end command::GetCustomizationStatusCommand%370A604F0382.preface

//## Class: GetCustomizationStatusCommand%370A604F0382
//	QGCUSTAT - retrieve end user customization status.
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%370A74FB02EB;segment::InformationSegment { -> F}
//## Uses: <unnamed>%370A755B0018;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%370A75C400A5;IF::Message { -> F}
//## Uses: <unnamed>%370B641802B8;reusable::Query { -> F}
//## Uses: <unnamed>%370B646703C0;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%370B649A0360;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%370B7687016A;usersegment::CustomizationStatusSegment { -> F}
//## Uses: <unnamed>%370B768A03A9;usersegment::CustomizationSecuritySegment { -> F}
//## Uses: <unnamed>%370B798A00E6;IF::DateTime { -> F}
//## Uses: <unnamed>%371F431C0211;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%3A008FFB03C5;monitor::UseCase { -> F}
//## Uses: <unnamed>%3A017C5300F9;segment::ListSegment { -> F}

class DllExport GetCustomizationStatusCommand : public ClientCommand  //## Inherits: <unnamed>%370A63F103BB
{
  //## begin command::GetCustomizationStatusCommand%370A604F0382.initialDeclarations preserve=yes
  //## end command::GetCustomizationStatusCommand%370A604F0382.initialDeclarations

  public:
    //## Constructors (generated)
      GetCustomizationStatusCommand();

    //## Constructors (specified)
      //## Operation: GetCustomizationStatusCommand%3E96B393036B
      GetCustomizationStatusCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~GetCustomizationStatusCommand();


    //## Other Operations (specified)
      //## Operation: execute%370A635F02AD
      //	Perform the functions of this command.
      bool execute ();

    // Additional Public Declarations
      //## begin command::GetCustomizationStatusCommand%370A604F0382.public preserve=yes
      //## end command::GetCustomizationStatusCommand%370A604F0382.public

  protected:
    // Additional Protected Declarations
      //## begin command::GetCustomizationStatusCommand%370A604F0382.protected preserve=yes
      //## end command::GetCustomizationStatusCommand%370A604F0382.protected

  private:
    // Additional Private Declarations
      //## begin command::GetCustomizationStatusCommand%370A604F0382.private preserve=yes
      //## end command::GetCustomizationStatusCommand%370A604F0382.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%370A6A2101EC
      //## Role: GetCustomizationStatusCommand::<m_pGetCustomizationStatusSegment>%370A6A22025D
      //## begin command::GetCustomizationStatusCommand::<m_pGetCustomizationStatusSegment>%370A6A22025D.role preserve=no  public: usersegment::GetCustomizationStatusSegment { -> RFHgN}
      usersegment::GetCustomizationStatusSegment *m_pGetCustomizationStatusSegment;
      //## end command::GetCustomizationStatusCommand::<m_pGetCustomizationStatusSegment>%370A6A22025D.role

    // Additional Implementation Declarations
      //## begin command::GetCustomizationStatusCommand%370A604F0382.implementation preserve=yes
      //## end command::GetCustomizationStatusCommand%370A604F0382.implementation

};

//## begin command::GetCustomizationStatusCommand%370A604F0382.postscript preserve=yes
//## end command::GetCustomizationStatusCommand%370A604F0382.postscript

} // namespace command

//## begin module%370A61C70133.epilog preserve=yes
using namespace command;
//## end module%370A61C70133.epilog


#endif
