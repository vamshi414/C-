//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E9717BA036B.cm preserve=no
//	$Date:   May 27 2019 19:14:56  $ $Author:   e1009339  $ $Revision:   1.18.1.1  $
//## end module%3E9717BA036B.cm

//## begin module%3E9717BA036B.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%3E9717BA036B.cp

//## Module: CXOSBC04%3E9717BA036B; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC04.cpp

//## begin module%3E9717BA036B.additionalIncludes preserve=no
//## end module%3E9717BA036B.additionalIncludes

//## begin module%3E9717BA036B.includes preserve=yes
#define STS_ENCRYPTION_KEY_ERROR 304
#include "CXODIF04.hpp"
//## end module%3E9717BA036B.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBC07_h
#include "CXODBC07.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSUS03_h
#include "CXODUS03.hpp"
#endif
#ifndef CXOSBC04_h
#include "CXODBC04.hpp"
#endif


//## begin module%3E9717BA036B.declarations preserve=no
//## end module%3E9717BA036B.declarations

//## begin module%3E9717BA036B.additionalDeclarations preserve=yes
#ifndef CXOSBC26_h
#include "CXODBC26.hpp"
#endif
//## end module%3E9717BA036B.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::LogonCommand 

LogonCommand::LogonCommand()
  //## begin LogonCommand::LogonCommand%3E971714032C_const.hasinit preserve=no
      : m_pLogonSegment(0)
  //## end LogonCommand::LogonCommand%3E971714032C_const.hasinit
  //## begin LogonCommand::LogonCommand%3E971714032C_const.initialization preserve=yes
   ,ClientCommand("S0005D","@LOGON  ")
  //## end LogonCommand::LogonCommand%3E971714032C_const.initialization
{
  //## begin command::LogonCommand::LogonCommand%3E971714032C_const.body preserve=yes
   memcpy(m_sID,"BC04",4);
   m_pLogonSegment = new LogonSegment();
   m_hSegments.push_back(m_pLogonSegment);
   m_pAuthenticateSegment = new AuthenticateSegment();
   m_hSegments.push_back(m_pAuthenticateSegment);
  //## end command::LogonCommand::LogonCommand%3E971714032C_const.body
}

LogonCommand::LogonCommand (Handler* pSuccessor)
  //## begin command::LogonCommand::LogonCommand%3E9733FC0167.hasinit preserve=no
      : m_pLogonSegment(0)
  //## end command::LogonCommand::LogonCommand%3E9733FC0167.hasinit
  //## begin command::LogonCommand::LogonCommand%3E9733FC0167.initialization preserve=yes
   ,ClientCommand("S0005D","@LOGON  ")
  //## end command::LogonCommand::LogonCommand%3E9733FC0167.initialization
{
  //## begin command::LogonCommand::LogonCommand%3E9733FC0167.body preserve=yes
   memcpy(m_sID,"BC04",4);
   m_pSuccessor = pSuccessor;
   m_pLogonSegment = new LogonSegment();
   m_hSegments.push_back(m_pLogonSegment);
   m_pAuthenticateSegment = new AuthenticateSegment();
   m_hSegments.push_back(m_pAuthenticateSegment);
  //## end command::LogonCommand::LogonCommand%3E9733FC0167.body
}


LogonCommand::~LogonCommand()
{
  //## begin command::LogonCommand::~LogonCommand%3E971714032C_dest.body preserve=yes
   delete m_pLogonSegment;
   delete m_pAuthenticateSegment;
  //## end command::LogonCommand::~LogonCommand%3E971714032C_dest.body
}



//## Other Operations (implementation)
bool LogonCommand::execute ()
{
  //## begin command::LogonCommand::execute%3E9AFCA302EE.body preserve=yes
   UseCase hUseCase("CLIENT","## CL02 LOGON");
   int iRC;
   if ((iRC = Command::parse()) != 0)
   {
      sendError(STS_PARSE_ERROR,STS_ERROR,iRC);
      return false;
   }
   if(m_pAuthenticateSegment->presence())
   {
      string strUserId = m_pAuthenticateSegment->getUserID();
      string strPassword = m_pAuthenticateSegment->getPassword();
      string strNewPassword = m_pAuthenticateSegment->getNewPassword();
      string strHash = m_pAuthenticateSegment->getHash();
      string strCustomerID = m_pAuthenticateSegment->getCustomerID();
      string strSignature = m_pAuthenticateSegment->getSignature();
      string strKey = Security::instance()->getKey();
      char* pHash = strHash.length() == 4 ? (char*)strHash.data() : 0;
      if(!Security::instance()->decrypt(strUserId,pHash) || 
         strUserId.length() > 8)
      {      
         sendError(STS_ENCRYPTION_KEY_ERROR,STS_ERROR,304);
         return false;
      }
      //DNT-6068 remove max password length check.  let auth method (DN, LDAP, ...) check max if needed before auth.
      if(!Security::instance()->decrypt(strPassword,0))
      {
         sendError(STS_ENCRYPTION_KEY_ERROR,STS_ERROR,304);
         return false;
      }
      if(strNewPassword.length() > 0)
         if(!Security::instance()->decrypt(strNewPassword,0) ||
            strNewPassword.length() > 16)
         {
            sendError(STS_ENCRYPTION_KEY_ERROR,STS_ERROR,304);
            return false;
         }
#ifdef MVS
      if (!strUserId.empty())
         CodeTable::translate((char*)strUserId.data(),strUserId.length(),CodeTable::CX_ASCII_TO_EBCDIC);
      if (!strPassword.empty())
         CodeTable::translate((char*)strPassword.data(),strPassword.length(),CodeTable::CX_ASCII_TO_EBCDIC);
      if (!strNewPassword.empty())
         CodeTable::translate((char*)strNewPassword.data(),strNewPassword.length(),CodeTable::CX_ASCII_TO_EBCDIC);
#endif

      m_pLogonSegment->setUserID(strUserId);
      m_pLogonSegment->setPassword(strPassword);
      m_pLogonSegment->setNewPassword(strNewPassword);
      m_pLogonSegment->setApplicationName("STS");
      m_pLogonSegment->setCustomerID(strCustomerID);
      m_pLogonSegment->setSignature(strSignature);
   }
   int lInfoIDNumber = UserPool::instance()->logonRequest(*Message::instance(Message::INBOUND),m_pLogonSegment,getResponseTimeSegment());
   if (lInfoIDNumber != 0)
   {
      sendError(STS_SESSION_ERROR,STS_ERROR,lInfoIDNumber);
      return false;
   }
   return true;
  //## end command::LogonCommand::execute%3E9AFCA302EE.body
}

int LogonCommand::deport (char** ppsBuffer)
{
  //## begin command::LogonCommand::deport%46321D88003E.body preserve=yes
   CommonHeaderSegment::instance()->setServiceName(m_strServiceName);
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   CommonHeaderSegment::instance()->setCUST_ID(strCUST_ID);
   string strVersion(LATEST_MU);
   CommonHeaderSegment::instance()->setClientVersion(strVersion);
   CommonHeaderSegment::instance()->deport(ppsBuffer);
   LogonSegment::instance()->deport(ppsBuffer);
   return 0;
  //## end command::LogonCommand::deport%46321D88003E.body
}

// Additional Declarations
  //## begin command::LogonCommand%3E971714032C.declarations preserve=yes
  //## end command::LogonCommand%3E971714032C.declarations

} // namespace command

//## begin module%3E9717BA036B.epilog preserve=yes
//## end module%3E9717BA036B.epilog
