//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%477522AA0290.cm preserve=no
//	$Date:   May 14 2020 16:20:14  $ $Author:   e1009510  $ $Revision:   1.17  $
//## end module%477522AA0290.cm

//## begin module%477522AA0290.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%477522AA0290.cp

//## Module: CXOSBC25%477522AA0290; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC25.cpp

//## begin module%477522AA0290.additionalIncludes preserve=no
//## end module%477522AA0290.additionalIncludes

//## begin module%477522AA0290.includes preserve=yes
//## end module%477522AA0290.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSBC25_h
#include "CXODBC25.hpp"
#endif


//## begin module%477522AA0290.declarations preserve=no
//## end module%477522AA0290.declarations

//## begin module%477522AA0290.additionalDeclarations preserve=yes
//## end module%477522AA0290.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::Email 

//## begin command::Email::Instance%537F649000EE.attr preserve=no  private: static command::Email* {V} 0
command::Email* Email::m_pInstance = 0;
//## end command::Email::Instance%537F649000EE.attr

Email::Email()
  //## begin Email::Email%477521BC0271_const.hasinit preserve=no
      : m_hFlatFile("SMTP"),
        m_pExportFile(0)
  //## end Email::Email%477521BC0271_const.hasinit
  //## begin Email::Email%477521BC0271_const.initialization preserve=yes
  //## end Email::Email%477521BC0271_const.initialization
{
  //## begin command::Email::Email%477521BC0271_const.body preserve=yes
  //## end command::Email::Email%477521BC0271_const.body
}

Email::Email (const string& strDX_FILE_TYPE, const string& strENTITY_TYPE, const string& strENTITY_ID, const string& strDATE_RECON, const string& strSCHED_TIME)
  //## begin command::Email::Email%477524B300EA.hasinit preserve=no
      : m_hFlatFile("SMTP"),
        m_pExportFile(0)
  //## end command::Email::Email%477524B300EA.hasinit
  //## begin command::Email::Email%477524B300EA.initialization preserve=yes
  //## end command::Email::Email%477524B300EA.initialization
{
  //## begin command::Email::Email%477524B300EA.body preserve=yes
   memcpy(m_sID,"BC25",4);
   m_hFlatFile.setOwner(strENTITY_ID);
   m_hFlatFile.setDate(strDATE_RECON);
   m_hFlatFile.setScheduledTime(strSCHED_TIME);
  //## end command::Email::Email%477524B300EA.body
}

Email::Email (const string& strDX_FILE_TYPE, const string& strENTITY_TYPE, const string& strENTITY_ID, const string& strDATE_RECON, const string& strSCHED_TIME, const string& strTemplate)
  //## begin command::Email::Email%501154C20280.hasinit preserve=no
      : m_hFlatFile("SMTP"),
        m_pExportFile(0)
  //## end command::Email::Email%501154C20280.hasinit
  //## begin command::Email::Email%501154C20280.initialization preserve=yes
  //## end command::Email::Email%501154C20280.initialization
{
  //## begin command::Email::Email%501154C20280.body preserve=yes
   memcpy(m_sID,"BC25",4);
   if (strDX_FILE_TYPE == "NONE")
      m_pExportFile = new ExportFile(strTemplate.substr(2),strENTITY_TYPE,strENTITY_ID,strDATE_RECON,strSCHED_TIME);
   else
      m_pExportFile = new ExportFile(strDX_FILE_TYPE,strENTITY_TYPE,strENTITY_ID,strDATE_RECON,strSCHED_TIME);
   if (m_pExportFile->isPresent())
      m_pExportFile->erase();
   read(strTemplate);
   m_pInstance = this;
  //## end command::Email::Email%501154C20280.body
}

Email::Email (const string& strTemplate)
  //## begin command::Email::Email%537F3E26036E.hasinit preserve=no
      : m_hFlatFile("SMTP"),
        m_pExportFile(0)
  //## end command::Email::Email%537F3E26036E.hasinit
  //## begin command::Email::Email%537F3E26036E.initialization preserve=yes
  //## end command::Email::Email%537F3E26036E.initialization
{
  //## begin command::Email::Email%537F3E26036E.body preserve=yes
   memcpy(m_sID,"BC25",4);
   string strCUST_ID("****");
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   string strTimestamp(Clock::instance()->getYYYYMMDDHHMMSS(false));
   read(strTemplate);
   string strValue;
   Extract::instance()->getSpec("PROC",strValue);
   usersegment::EmailSegment::instance()->setServer(strValue);
   usersegment::EmailSegment::instance()->setField("PROC",strValue);
  //## end command::Email::Email%537F3E26036E.body
}


Email::~Email()
{
  //## begin command::Email::~Email%477521BC0271_dest.body preserve=yes
   delete m_pExportFile;
   m_pInstance = 0;
  //## end command::Email::~Email%477521BC0271_dest.body
}



//## Other Operations (implementation)
void Email::add (const char cSegment, segment::Segment* pSegment)
{
  //## begin command::Email::add%4775238B0232.body preserve=yes
   m_hXMLText.add(cSegment,pSegment);
  //## end command::Email::add%4775238B0232.body
}

bool Email::report (const char cType)
{
  //## begin command::Email::report%4775239400CB.body preserve=yes
   vector<string>::iterator p;
   Memory hMemory(271);
   for (p = m_hTemplate.begin();p != m_hTemplate.end();++p)
   {
      if ((*p)[0] == cType)
      {
         string strText((*p).data() + 1,(*p).length() - 1);
         m_hXMLText.substitute(strText,false);
         int j = strText.length() > 15 && strText.substr(strText.length() - 4,4) == "@#^!" ? 15 : 0;
         if (m_pExportFile)
         {
            if (!m_pExportFile->write(strText.data(),min((int)strText.length(),255 + j)))
               return false;
         }
         else
         {
            memcpy(hMemory,strText.data(),min((int)strText.length(),255 + j));
            if (!m_hFlatFile.write((char*)hMemory,min((int)strText.length(),255 + j)))
               return false;
         }
      }
   }
   return true;
  //## end command::Email::report%4775239400CB.body
}

bool Email::report (const string& strText)
{
  //## begin command::Email::report%537F3E67037A.body preserve=yes
   if (!m_pInstance)
      return false;
   usersegment::EmailSegment::instance()->setField("TEXT",strText);
   return m_pInstance->report('Y');
  //## end command::Email::report%537F3E67037A.body
}

bool Email::report (const char cType, const string& strText1)
{
  //## begin command::Email::report%537F4C61030F.body preserve=yes
   if (!m_pInstance)
      return false;
   usersegment::EmailSegment::instance()->setField("%1",strText1);
   return m_pInstance->report(cType);
  //## end command::Email::report%537F4C61030F.body
}

bool Email::report (const char cType, const string& strText1, const string& strText2)
{
  //## begin command::Email::report%537F4CD801E9.body preserve=yes
   if (!m_pInstance)
      return false;
   usersegment::EmailSegment::instance()->setField("%2",strText2);
   return m_pInstance->report(cType,strText1);
  //## end command::Email::report%537F4CD801E9.body
}

bool Email::report (const char cType, const string& strText1, const string& strText2, const string& strText3)
{
  //## begin command::Email::report%537F4D88019E.body preserve=yes
   if (!m_pInstance)
      return false;
   usersegment::EmailSegment::instance()->setField("%3",strText3);
   return m_pInstance->report(cType,strText1,strText2);
  //## end command::Email::report%537F4D88019E.body
}

bool Email::report (const char cType, const string& strText1, const string& strText2, const string& strText3, const string& strText4)
{
  //## begin command::Email::report%537F4CE8034B.body preserve=yes
   if (!m_pInstance)
      return false;
   usersegment::EmailSegment::instance()->setField("%4",strText4);
   return m_pInstance->report(cType,strText1,strText2,strText3);
  //## end command::Email::report%537F4CE8034B.body
}

bool Email::report (const char cType, const string& strText1, const string& strText2, const string& strText3, const string& strText4, const string& strText5)
{
  //## begin command::Email::report%537F4D0E0267.body preserve=yes
   if (!m_pInstance)
      return false;
   usersegment::EmailSegment::instance()->setField("%5",strText5);
   return m_pInstance->report(cType,strText1,strText2,strText3,strText4);
  //## end command::Email::report%537F4D0E0267.body
}

void Email::setTemplate (const char** ppszTemplate)
{
  //## begin command::Email::setTemplate%477523970138.body preserve=yes
   int i = 0;
   while (ppszTemplate[i])
      m_hTemplate.push_back(string(ppszTemplate[i++]));
  //## end command::Email::setTemplate%477523970138.body
}

void Email::update (Subject* pSubject)
{
  //## begin command::Email::update%547CE7E202F1.body preserve=yes
  //## end command::Email::update%547CE7E202F1.body
}

// Additional Declarations
  //## begin command::Email%477521BC0271.declarations preserve=yes
void Email::complete ()
{
   report('Z'," ");
   if (m_pExportFile)
      m_pExportFile->complete();
}

void Email::read(const string& strTemplate)
{
#ifdef MVS
   string strMember(strTemplate);
   strMember.replace(0,4,"DN##",4);
   FlatFile hFlatFile("JCL",strMember.c_str());
#else
   FlatFile hFlatFile("SOURCE",strTemplate.c_str());
#endif
   bool bContinue = false;
   string strBuffer;
   char sBuffer[256];
   size_t m = 0;
   bool bHTML = false;
   while (hFlatFile.read(sBuffer,256,&m))
   {
      strBuffer.assign(sBuffer,m);
      if (strBuffer.find("html") != string::npos)
         bHTML = true;
      if (bContinue)
      {
         if (strBuffer[strBuffer.length() - 1] == '\\')
            strBuffer.resize(strBuffer.length() - 1);
         else
            bContinue = false;
         m_hTemplate.back() += strBuffer;
      }
      else
      {
         if (strBuffer.empty() == false
            && strBuffer[strBuffer.length() - 1] == '\\')
         {
            strBuffer.resize(strBuffer.length() - 1);
            bContinue = true;
         }
         m_hTemplate.push_back(strBuffer);
      }
   }
   if (!bHTML)
      m_hXMLText.setHTML(false);
}
  //## end command::Email%477521BC0271.declarations

} // namespace command

//## begin module%477522AA0290.epilog preserve=yes
//## end module%477522AA0290.epilog
