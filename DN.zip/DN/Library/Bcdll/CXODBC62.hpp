//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5F5FBEC30010.cm preserve=no
//	$Date:   Oct 13 2020 05:18:12  $ $Author:   e3023547  $
//	$Revision:   1.0  $
//## end module%5F5FBEC30010.cm

//## begin module%5F5FBEC30010.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5F5FBEC30010.cp

//## Module: CXOSBC62%5F5FBEC30010; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: D:\Devel\V03.1A.R007\ConnexPlatform\Server\Library\Bcdll\CXODBC62.hpp

#ifndef CXOSBC62_h
#define CXOSBC62_h 1

//## begin module%5F5FBEC30010.additionalIncludes preserve=no
//## end module%5F5FBEC30010.additionalIncludes

//## begin module%5F5FBEC30010.includes preserve=yes
#include<map>
#include "CXODBC48.hpp"
//## end module%5F5FBEC30010.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

namespace IF {
class FlatFile;
} // namespace IF

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class XMLItem;
class GenericRuleXMLHandler;

} // namespace command

//## begin module%5F5FBEC30010.declarations preserve=no
//## end module%5F5FBEC30010.declarations

//## begin module%5F5FBEC30010.additionalDeclarations preserve=yes
//## end module%5F5FBEC30010.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::GenericRule%5F5FBE4C0304.preface preserve=yes
//## end command::GenericRule%5F5FBE4C0304.preface

//## Class: GenericRule%5F5FBE4C0304
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5F5FD007032E;IF::FlatFile { -> F}
//## Uses: <unnamed>%5F6CBAEE0397;reusable::Buffer { -> F}
//## Uses: <unnamed>%5F6CBAF103D8;IF::CodeTable { -> F}

class DllExport GenericRule : public reusable::Observer  //## Inherits: <unnamed>%5F5FD00303D1
{
  //## begin command::GenericRule%5F5FBE4C0304.initialDeclarations preserve=yes
  //## end command::GenericRule%5F5FBE4C0304.initialDeclarations

  public:
    //## Constructors (generated)
      GenericRule();

    //## Destructor (generated)
      virtual ~GenericRule();


    //## Other Operations (specified)
      //## Operation: addRule%5F5FD1710240
      void addRule (const Function& hFunction);

      //## Operation: evaluateFields%5F5FD20900DC
      bool evaluateFields (vector<CriteriaData>& hCriteriaData);

      //## Operation: evaluateRules%5F5FD1AA008B
      bool evaluateRules (vector<string>& hRuleNames);

      //## Operation: getField%5F5FD23B0145
      void getField (const string& strTable, const string& strField, string& strValue);

      //## Operation: instance%5F5FD28D03C8
      static GenericRule* instance ();

      //## Operation: loadSegment%5F5FD2C00030
      void loadSegment (const string& strTable, Segment* pSegment);

      //## Operation: setQueryParameter%5F6CBCC80174
      void setQueryParameter (string strTable, string strColumn);

      //## Operation: update%5F5FD2FA0394
      virtual void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: BindParams%5F6CBB02027D
      vector<pair<string,string> >& getBindParams ()
      {
        //## begin command::GenericRule::getBindParams%5F6CBB02027D.get preserve=no
        return m_hBindParams;
        //## end command::GenericRule::getBindParams%5F6CBB02027D.get
      }


      //## Attribute: JoinParams%5F6CBB4F006C
      set<string,less<string> >& getJoinParams ()
      {
        //## begin command::GenericRule::getJoinParams%5F6CBB4F006C.get preserve=no
        return m_hJoinParams;
        //## end command::GenericRule::getJoinParams%5F6CBB4F006C.get
      }


      //## Attribute: TranslateFields%5F6CBB7C00F2
      map<string,pair<string,string>,less<string> >& getTranslateFields ()
      {
        //## begin command::GenericRule::getTranslateFields%5F6CBB7C00F2.get preserve=no
        return m_hTranslateFields;
        //## end command::GenericRule::getTranslateFields%5F6CBB7C00F2.get
      }


    // Additional Public Declarations
      //## begin command::GenericRule%5F5FBE4C0304.public preserve=yes
      //## end command::GenericRule%5F5FBE4C0304.public

  protected:
    // Additional Protected Declarations
      //## begin command::GenericRule%5F5FBE4C0304.protected preserve=yes
      //## end command::GenericRule%5F5FBE4C0304.protected

  private:
    // Additional Private Declarations
      //## begin command::GenericRule%5F5FBE4C0304.private preserve=yes
      //## end command::GenericRule%5F5FBE4C0304.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::GenericRule::BindParams%5F6CBB02027D.attr preserve=no  public: vector<pair<string,string> > {U} 
      vector<pair<string,string> > m_hBindParams;
      //## end command::GenericRule::BindParams%5F6CBB02027D.attr

      //## Attribute: instance%5F5FD13B0222
      //## begin command::GenericRule::instance%5F5FD13B0222.attr preserve=no  private: static GenericRule* {U} 0
      static GenericRule* m_pinstance;
      //## end command::GenericRule::instance%5F5FD13B0222.attr

      //## begin command::GenericRule::JoinParams%5F6CBB4F006C.attr preserve=no  public: set<string,less<string> > {U} 
      set<string,less<string> > m_hJoinParams;
      //## end command::GenericRule::JoinParams%5F6CBB4F006C.attr

      //## begin command::GenericRule::TranslateFields%5F6CBB7C00F2.attr preserve=no  public: map<string,pair<string,string>,less<string> > {U} 
      map<string,pair<string,string>,less<string> > m_hTranslateFields;
      //## end command::GenericRule::TranslateFields%5F6CBB7C00F2.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%5F5FD01F0226
      //## Role: GenericRule::<m_hSegment>%5F5FD02000FB
      //## Qualifier: strTable%5F5FD0510149; string
      //## begin command::GenericRule::<m_hSegment>%5F5FD02000FB.role preserve=no  public: segment::Segment { -> RHgN}
      map<string, segment::Segment *, less<string> > m_hSegment;
      //## end command::GenericRule::<m_hSegment>%5F5FD02000FB.role

      //## Association: Connex Library::Command_CAT::<unnamed>%5F5FD073014B
      //## Role: GenericRule::<m_pXMLItem>%5F5FD07400FA
      //## begin command::GenericRule::<m_pXMLItem>%5F5FD07400FA.role preserve=no  public: command::XMLItem { -> RFHgN}
      XMLItem *m_pXMLItem;
      //## end command::GenericRule::<m_pXMLItem>%5F5FD07400FA.role

      //## Association: Connex Library::Command_CAT::<unnamed>%5F5FD0CB01F3
      //## Role: GenericRule::<m_hFunction>%5F5FD0CC0129
      //## begin command::GenericRule::<m_hFunction>%5F5FD0CC0129.role preserve=no  public: command::Function {1 -> 0..nVHgN}
      vector<Function> m_hFunction;
      //## end command::GenericRule::<m_hFunction>%5F5FD0CC0129.role

      //## Association: Connex Library::Command_CAT::<unnamed>%5F5FD10B0338
      //## Role: GenericRule::<m_pGenericRuleXMLHandler>%5F5FD10C03A8
      //## begin command::GenericRule::<m_pGenericRuleXMLHandler>%5F5FD10C03A8.role preserve=no  public: command::GenericRuleXMLHandler { -> RFHgN}
      GenericRuleXMLHandler *m_pGenericRuleXMLHandler;
      //## end command::GenericRule::<m_pGenericRuleXMLHandler>%5F5FD10C03A8.role

    // Additional Implementation Declarations
      //## begin command::GenericRule%5F5FBE4C0304.implementation preserve=yes
      //## end command::GenericRule%5F5FBE4C0304.implementation

};

//## begin command::GenericRule%5F5FBE4C0304.postscript preserve=yes
//## end command::GenericRule%5F5FBE4C0304.postscript

} // namespace command

//## begin module%5F5FBEC30010.epilog preserve=yes
//## end module%5F5FBEC30010.epilog


#endif
