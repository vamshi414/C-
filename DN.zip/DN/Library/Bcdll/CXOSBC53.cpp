//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%588D08DC0162.cm preserve=no
//	$Date:   Jan 15 2021 15:15:28  $ $Author:   e1094689  $ $Revision:   1.10  $
//## end module%588D08DC0162.cm

//## begin module%588D08DC0162.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%588D08DC0162.cp

//## Module: CXOSBC53%588D08DC0162; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.8A.R005\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC53.cpp

//## begin module%588D08DC0162.additionalIncludes preserve=no
//## end module%588D08DC0162.additionalIncludes

//## begin module%588D08DC0162.includes preserve=yes
#include "CXODIF16.hpp"
//## end module%588D08DC0162.includes

#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif
#ifndef CXOSBC53_h
#include "CXODBC53.hpp"
#endif


//## begin module%588D08DC0162.declarations preserve=no
//## end module%588D08DC0162.declarations

//## begin module%588D08DC0162.additionalDeclarations preserve=yes
//## end module%588D08DC0162.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::APIImport 

//## begin command::APIImport::APIImportRecord%588D0CD603A7.attr preserve=no  public: static map<string, APIImportRecord*, less<string> >* {V} 0
map<string, APIImportRecord*, less<string> >* APIImport::m_pAPIImportRecord = 0;
//## end command::APIImport::APIImportRecord%588D0CD603A7.attr

//## begin command::APIImport::Instance%589B422F0120.attr preserve=no  private: static command::APIImport* {V} 0
command::APIImport* APIImport::m_pInstance = 0;
//## end command::APIImport::Instance%589B422F0120.attr

//## begin command::APIImport::Timer%58A44BB8029E.attr preserve=no  private: static int {V} 30
int APIImport::m_iTimer = 30;
//## end command::APIImport::Timer%58A44BB8029E.attr

//## begin command::APIImport::<m_pTimer>%58A449C7022C.role preserve=no  public: static timer::Timer { -> RFHgN}
timer::Timer *APIImport::m_pTimer = 0;
//## end command::APIImport::<m_pTimer>%58A449C7022C.role

APIImport::APIImport()
  //## begin APIImport::APIImport%588D083702CC_const.hasinit preserve=no
  //## end APIImport::APIImport%588D083702CC_const.hasinit
  //## begin APIImport::APIImport%588D083702CC_const.initialization preserve=yes
  //## end APIImport::APIImport%588D083702CC_const.initialization
{
  //## begin command::APIImport::APIImport%588D083702CC_const.body preserve=yes
   memcpy(m_sID, "BC53", 4);
  //## end command::APIImport::APIImport%588D083702CC_const.body
}


APIImport::~APIImport()
{
  //## begin command::APIImport::~APIImport%588D083702CC_dest.body preserve=yes
   if (this == m_pInstance)
   {
      delete m_pTimer;
//      Database::instance()->detach(this);
      m_pInstance = 0;
   }
  //## end command::APIImport::~APIImport%588D083702CC_dest.body
}



//## Other Operations (implementation)
void APIImport::add (const string& strAPI_TYPE, command::APIImportRecord* pAPIImportRecord)
{
  //## begin command::APIImport::add%588D0DCB0249.body preserve=yes
   if (!m_pAPIImportRecord)
      m_pAPIImportRecord = new map<string, APIImportRecord*, less<string> >;
   m_pAPIImportRecord->insert(map<string, APIImportRecord*, less<string> >::value_type(strAPI_TYPE, pAPIImportRecord));
  //## end command::APIImport::add%588D0DCB0249.body
}

APIImport* APIImport::instance ()
{
  //## begin command::APIImport::instance%589B420500B0.body preserve=yes
   if (!m_pInstance)
   {
      m_pInstance = new APIImport();
      m_pTimer = new Timer();
      m_pTimer->attach(m_pInstance);
      if ((m_iTimer = Extract::instance()->getTimer("IMPORT")) == -1)
         m_iTimer = 30;
      else
      if (m_iTimer < 2)
         m_iTimer = 2;
      m_pTimer->set(m_iTimer);
      //      Database::instance()->attach(m_pInstance);
   }
   return m_pInstance;
  //## end command::APIImport::instance%589B420500B0.body
}

void APIImport::onResume ()
{
  //## begin command::APIImport::onResume%588D0E0A0357.body preserve=yes
   map<string, APIImportRecord*, less<string> >::iterator p;
   p = m_pAPIImportRecord->begin();
   m_strEndingDATA_BUFFER.erase();
   string strTSTAMP_EVENT;
   string strSpecs;
   string strNewCode;
   IF::Extract::instance()->getSpec("APITYPE", strSpecs);
   Query hQuery;
   if (Extract::instance()->getSpec("USENEW", strNewCode))
   {
       if (m_hQueueID.size() == 0)
       {
           Query hQuery(1);
           hQuery.attach(this);
           hQuery.bind("API_QUEUE_CONTROL", "QUEUE_ID", Column::LONG, &m_iQUEUE_ID);
           if (strSpecs == "MCOM")
               hQuery.setBasicPredicate("API_QUEUE_CONTROL", "API_TYPE", "IN", "('MCOM','MQUE','MFLD')");
           else if(strSpecs == "EFTPOS")
              hQuery.setBasicPredicate("API_QUEUE_CONTROL", "API_TYPE", "=", strSpecs.c_str());
           else
               hQuery.setBasicPredicate("API_QUEUE_CONTROL", "API_TYPE", "=", "VCR");
           hQuery.setBasicPredicate("API_QUEUE_CONTROL", "API_STATE", "IN", "('AS','PE','SP','RS')");
           hQuery.setBasicPredicate("API_QUEUE_CONTROL", "TSTAMP_EVENT", "<=", Clock::instance()->getYYYYMMDDHHMMSSHN().c_str());
           hQuery.setBasicPredicate("API_QUEUE_CONTROL", "RETRY_COUNT", "<", 5);
           hQuery.setOrderByClause("API_QUEUE_CONTROL.TSTAMP_EVENT ASC,API_QUEUE_CONTROL.QUEUE_ID ASC");
           if (1)
           {
               auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
               if (!pSelectStatement->execute(hQuery) || pSelectStatement->getRows() == 0)
               {
                   Application::instance()->setQueueWaitOption(true);
                   return;
               }
           }
       }
	   vector<int>::iterator p = m_hQueueID.begin();
       Query hQuery;
       hQuery.attach(this);
       m_hAPIImportRecord.bind(hQuery);
       hQuery.bind("API_QUEUE_RESPONSE", "DATA_BUFFER", Column::STRING, &m_strDATA_BUFFER);
       hQuery.join("API_QUEUE_CONTROL", "INNER", "API_QUEUE_RESPONSE", "QUEUE_ID");
       hQuery.setBasicPredicate("API_QUEUE_CONTROL", "QUEUE_ID", "=", *p); // m_hAPIImportRecord.getQUEUE_ID());
       hQuery.setOrderByClause("SEQ_NO ASC");
	   if (1)
	   {
		   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
		   pSelectStatement->execute(hQuery);
		   if (pSelectStatement->getRows() == 0)
		   {
			   Application::instance()->setQueueWaitOption(true);
			   return;
		   }
	   }
   }
   else
   {
       Query hSubQuery;
       short iNull = -1;
       hSubQuery.setSubSelect(true);
       hSubQuery.bind("API_QUEUE_CONTROL", "TSTAMP_EVENT", Column::STRING, &strTSTAMP_EVENT, &iNull, "MIN");
       hSubQuery.setBasicPredicate("API_QUEUE_CONTROL", "API_STATE", "IN", "('AS','PE','SP','RS')");
       if (strSpecs == "MCOM")
           hSubQuery.setBasicPredicate("API_QUEUE_CONTROL", "API_TYPE", "IN", "('MCOM','MQUE','MFLD')");
       else if(strSpecs == "EFTPOS")
          hSubQuery.setBasicPredicate("API_QUEUE_CONTROL", "API_TYPE", "=", strSpecs.c_str());
       else
           hSubQuery.setBasicPredicate("API_QUEUE_CONTROL", "API_TYPE", "=", "VCR");
       hSubQuery.setBasicPredicate("API_QUEUE_CONTROL", "TSTAMP_EVENT", "<=", Clock::instance()->getYYYYMMDDHHMMSSHN().c_str());
       hSubQuery.setBasicPredicate("API_QUEUE_CONTROL", "RETRY_COUNT", "<", 5);
       auto_ptr<FormatSelectVisitor> pFormatSelectVisitor((FormatSelectVisitor*)DatabaseFactory::instance()->create("FormatSelectVisitor"));
       hSubQuery.accept(*pFormatSelectVisitor);
       string strSubQuery = "(" + pFormatSelectVisitor->SQLText() + ")";
       Query hQuery;
       int lQUEUE_ID;
       hQuery.bind("API_QUEUE_CONTROL", "QUEUE_ID", Column::LONG, &lQUEUE_ID);
       hQuery.setBasicPredicate("API_QUEUE_CONTROL", "TSTAMP_EVENT", "IN", strSubQuery.c_str());
       if (strSpecs == "MCOM")
           hQuery.setBasicPredicate("API_QUEUE_CONTROL", "API_TYPE", "IN", "('MCOM','MQUE','MFLD')");
       else if (strSpecs == "EFTPOS")
          hQuery.setBasicPredicate("API_QUEUE_CONTROL", "API_TYPE", "=", strSpecs.c_str());
       else
           hQuery.setBasicPredicate("API_QUEUE_CONTROL", "API_TYPE", "=", "VCR");
       hQuery.setBasicPredicate("API_QUEUE_CONTROL", "API_STATE", "IN", "('AS','PE','SP','RS')");
       hQuery.setOrderByClause("API_QUEUE_CONTROL.TSTAMP_EVENT ASC,API_QUEUE_CONTROL.QUEUE_ID ASC");
       if (1)
       {
           auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
           if (!pSelectStatement->execute(hQuery) || pSelectStatement->getRows() == 0)
           {
               Application::instance()->setQueueWaitOption(true);
               return;
           }
       }
       hQuery.reset();
       hQuery.attach(this);
       m_hAPIImportRecord.bind(hQuery);
       hQuery.bind("API_QUEUE_RESPONSE", "DATA_BUFFER", Column::STRING, &m_strDATA_BUFFER);
       hQuery.join("API_QUEUE_CONTROL", "INNER", "API_QUEUE_RESPONSE", "QUEUE_ID");
       hQuery.setBasicPredicate("API_QUEUE_CONTROL", "QUEUE_ID", "=", lQUEUE_ID); // m_hAPIImportRecord.getQUEUE_ID());
       hQuery.setOrderByClause("SEQ_NO ASC");
       if (1)
       {
           auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
           pSelectStatement->execute(hQuery);
           if (pSelectStatement->getRows() == 0)
           {
               Application::instance()->setQueueWaitOption(true);
               return;
           }
       }

   }
   if (m_pAPIImportRecord->size() > 1)
	   p = m_pAPIImportRecord->find(m_hAPIImportRecord.getAPI_TYPE());
   m_hAPIImportRecord.setDATA_BUFFER(m_strEndingDATA_BUFFER);
   (*p).second->execute(m_hAPIImportRecord);
   if (Extract::instance()->getSpec("USENEW", strNewCode) && m_hQueueID.size())
       m_hQueueID.erase(m_hQueueID.begin());
   Application::instance()->setQueueWaitOption(false);
  //## end command::APIImport::onResume%588D0E0A0357.body
}

void APIImport::update (Subject* pSubject)
{
  //## begin command::APIImport::update%589784550331.body preserve=yes
   if (pSubject == m_pTimer)
   {
      m_pTimer->set(m_iTimer);
      Application::instance()->setQueueWaitOption(false);
      return;
   }
   else if (((Query*)pSubject)->getIndex() == 1)
   {
       m_hQueueID.push_back(m_iQUEUE_ID);
       if (m_hQueueID.size() == 1000)
           ((Query*)pSubject)->setAbort(true);
   }   
   else
       m_strEndingDATA_BUFFER += m_strDATA_BUFFER;
  //## end command::APIImport::update%589784550331.body
}

// Additional Declarations
  //## begin command::APIImport%588D083702CC.declarations preserve=yes
  //## end command::APIImport%588D083702CC.declarations

} // namespace command

//## begin module%588D08DC0162.epilog preserve=yes
//## end module%588D08DC0162.epilog
