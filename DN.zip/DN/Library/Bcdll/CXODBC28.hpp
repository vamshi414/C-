//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%48BEBE880264.cm preserve=no
//	$Date:   Nov 06 2008 14:36:02  $ $Author:   D92186  $ $Revision:   1.1  $
//## end module%48BEBE880264.cm

//## begin module%48BEBE880264.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%48BEBE880264.cp

//## Module: CXOSBC28%48BEBE880264; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC28.hpp

#ifndef CXOSBC28_h
#define CXOSBC28_h 1

//## begin module%48BEBE880264.additionalIncludes preserve=no
//## end module%48BEBE880264.additionalIncludes

//## begin module%48BEBE880264.includes preserve=yes
//## end module%48BEBE880264.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class CommonHeaderSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Security;
} // namespace command

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class KeyExchangeSegment;

} // namespace usersegment

//## begin module%48BEBE880264.declarations preserve=no
//## end module%48BEBE880264.declarations

//## begin module%48BEBE880264.additionalDeclarations preserve=yes
//## end module%48BEBE880264.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::KeyXchgCommand%48BEBE650264.preface preserve=yes
//## end command::KeyXchgCommand%48BEBE650264.preface

//## Class: KeyXchgCommand%48BEBE650264
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%490B6C3F0261;monitor::UseCase { -> F}
//## Uses: <unnamed>%490B6C5502EF;IF::Message { -> F}
//## Uses: <unnamed>%490B6CC102AF;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%490B6D7F0103;segment::InformationSegment { -> F}
//## Uses: <unnamed>%490B72B80354;Security { -> F}

class DllExport KeyXchgCommand : public ClientCommand  //## Inherits: <unnamed>%490B61E00191
{
  //## begin command::KeyXchgCommand%48BEBE650264.initialDeclarations preserve=yes
  //## end command::KeyXchgCommand%48BEBE650264.initialDeclarations

  public:
    //## Constructors (generated)
      KeyXchgCommand();

    //## Constructors (specified)
      //## Operation: KeyXchgCommand%490B65D70105
      KeyXchgCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~KeyXchgCommand();


    //## Other Operations (specified)
      //## Operation: execute%490B62640169
      //	Perform the functions of this command.
      virtual bool execute ();

    // Additional Public Declarations
      //## begin command::KeyXchgCommand%48BEBE650264.public preserve=yes
      //## end command::KeyXchgCommand%48BEBE650264.public

  protected:
    // Additional Protected Declarations
      //## begin command::KeyXchgCommand%48BEBE650264.protected preserve=yes
      //## end command::KeyXchgCommand%48BEBE650264.protected

  private:
    // Additional Private Declarations
      //## begin command::KeyXchgCommand%48BEBE650264.private preserve=yes
      //## end command::KeyXchgCommand%48BEBE650264.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%490F3AD20080
      //## Role: KeyXchgCommand::<m_pKeyExchangeSegment>%490F3AD3012B
      //## begin command::KeyXchgCommand::<m_pKeyExchangeSegment>%490F3AD3012B.role preserve=no  public: usersegment::KeyExchangeSegment { -> RFHgN}
      usersegment::KeyExchangeSegment *m_pKeyExchangeSegment;
      //## end command::KeyXchgCommand::<m_pKeyExchangeSegment>%490F3AD3012B.role

    // Additional Implementation Declarations
      //## begin command::KeyXchgCommand%48BEBE650264.implementation preserve=yes
      //## end command::KeyXchgCommand%48BEBE650264.implementation

};

//## begin command::KeyXchgCommand%48BEBE650264.postscript preserve=yes
//## end command::KeyXchgCommand%48BEBE650264.postscript

} // namespace command

//## begin module%48BEBE880264.epilog preserve=yes
//## end module%48BEBE880264.epilog


#endif
