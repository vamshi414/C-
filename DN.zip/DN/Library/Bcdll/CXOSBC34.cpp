//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4C61B70A02AD.cm preserve=no
//	$Date:   Jul 16 2018 11:05:10  $ $Author:   e1009839  $
//	$Revision:   1.4  $
//## end module%4C61B70A02AD.cm

//## begin module%4C61B70A02AD.cp preserve=no
//	Copyright (c) 1997 - 2018
//	FIS
//## end module%4C61B70A02AD.cp

//## Module: CXOSBC34%4C61B70A02AD; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC34.cpp

//## begin module%4C61B70A02AD.additionalIncludes preserve=no
//## end module%4C61B70A02AD.additionalIncludes

//## begin module%4C61B70A02AD.includes preserve=yes
//## end module%4C61B70A02AD.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSBC34_h
#include "CXODBC34.hpp"
#endif


//## begin module%4C61B70A02AD.declarations preserve=no
//## end module%4C61B70A02AD.declarations

//## begin module%4C61B70A02AD.additionalDeclarations preserve=yes
//## end module%4C61B70A02AD.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::XMLItem

XMLItem::XMLItem()
  //## begin XMLItem::XMLItem%4C61B6DB01B3_const.hasinit preserve=no
  //## end XMLItem::XMLItem%4C61B6DB01B3_const.hasinit
  //## begin XMLItem::XMLItem%4C61B6DB01B3_const.initialization preserve=yes
  //## end XMLItem::XMLItem%4C61B6DB01B3_const.initialization
{
  //## begin command::XMLItem::XMLItem%4C61B6DB01B3_const.body preserve=yes
   memcpy(m_sID,"BC34",4);
  //## end command::XMLItem::XMLItem%4C61B6DB01B3_const.body
}


XMLItem::~XMLItem()
{
  //## begin command::XMLItem::~XMLItem%4C61B6DB01B3_dest.body preserve=yes
  //## end command::XMLItem::~XMLItem%4C61B6DB01B3_dest.body
}



//## Other Operations (implementation)
void XMLItem::add (const string& strName, const string& strValue)
{
  //## begin command::XMLItem::add%4C61B8CE036C.body preserve=yes
   map<string,string,less <string> >::iterator p = m_hToken.find(strName);
   if (p != m_hToken.end())
   {
      if (strValue != (*p).second)
      {
         (*p).second += ',';
         (*p).second += strValue;
      }
   }
   else
      m_hToken.insert(map<string,string,less<string> >::value_type(strName,strValue));
   pair<multimap<string,pair<Segment*,string>,less<string> >::iterator,multimap<string,pair<Segment*,string>,less<string> >::iterator> hRange;
   hRange = m_hColumn.equal_range(strName);
   multimap<string,pair<Segment*,string>,less<string> >::iterator pRange;
   for (pRange = hRange.first;pRange != hRange.second;++pRange)
   {
      int i = 0;
      string strTemp(strValue);
      if ((*pRange).second.second[0] == '-'
         || (*pRange).second.second[0] == '.')
      {
         size_t pos = string::npos;
         while ((pos = strTemp.find((*pRange).second.second[0])) != string::npos)
            strTemp.erase(pos,1);
         i = 1;
      }
      if ((*pRange).second.second == "TSTAMP_LOCAL")
         strTemp.resize(14,'0');
      if ((*pRange).second.second[(*pRange).second.second.length() - 1] == 'n')
      {
         string strTemp2;
         char szSuffix[6] = {"12345"};
         string strName((*pRange).second.second);
         int j = 0;
         strName[strName.length() - 1] = '1';
         while ((*pRange).second.first->getField(strName.c_str(),strTemp2))
         {
            if (strTemp2.empty())
            {
               (*pRange).second.first->_fillField(strName.c_str(),strTemp);
               return;
            }
            if (j >= 4)
               return;
            strName[strName.length() - 1] = szSuffix[++j];
         }
      }
      else
         (*pRange).second.first->_fillField((*pRange).second.second.c_str() + i,strTemp);
   }
  //## end command::XMLItem::add%4C61B8CE036C.body
}

bool XMLItem::get (const char* pszName, string& strValue)
{
  //## begin command::XMLItem::get%4C63111B00FB.body preserve=yes
   map<string,string,less <string> >::iterator p = m_hToken.find(string(pszName));
   if (p != m_hToken.end())
   {
      strValue = (*p).second;
      return true;
   }
   strValue.erase();
   return false;
  //## end command::XMLItem::get%4C63111B00FB.body
}

const string& XMLItem::get (const char* pszName)
{
  //## begin command::XMLItem::get%5B4C9EDB02D3.body preserve=yes
   get(pszName,m_strValue);
   return m_strValue;
  //## end command::XMLItem::get%5B4C9EDB02D3.body
}

void XMLItem::import ()
{
  //## begin command::XMLItem::import%4C630A230393.body preserve=yes
  //## end command::XMLItem::import%4C630A230393.body
}

void XMLItem::reset ()
{
  //## begin command::XMLItem::reset%4DC0457B0055.body preserve=yes
   m_hColumn.erase(m_hColumn.begin(),m_hColumn.end());
   m_hToken.erase(m_hToken.begin(),m_hToken.end());
  //## end command::XMLItem::reset%4DC0457B0055.body
}

void XMLItem::resetToken ()
{
  //## begin command::XMLItem::resetToken%5B4CA0F6013F.body preserve=yes
   m_hToken.erase(m_hToken.begin(),m_hToken.end());
  //## end command::XMLItem::resetToken%5B4CA0F6013F.body
}

// Additional Declarations
  //## begin command::XMLItem%4C61B6DB01B3.declarations preserve=yes
  //## end command::XMLItem%4C61B6DB01B3.declarations

} // namespace command

//## begin module%4C61B70A02AD.epilog preserve=yes
//## end module%4C61B70A02AD.epilog
