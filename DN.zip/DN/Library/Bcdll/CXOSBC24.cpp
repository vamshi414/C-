//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%466045E40038.cm preserve=no
//	$Date:   Aug 19 2021 23:28:04  $ $Author:   e1014059  $ $Revision:   1.3  $
//## end module%466045E40038.cm

//## begin module%466045E40038.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%466045E40038.cp

//## Module: CXOSBC24%466045E40038; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC24.cpp

//## begin module%466045E40038.additionalIncludes preserve=no
//## end module%466045E40038.additionalIncludes

//## begin module%466045E40038.includes preserve=yes
//## end module%466045E40038.includes

#ifndef CXOSIF42_h
#include "CXODIF42.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBC24_h
#include "CXODBC24.hpp"
#endif


//## begin module%466045E40038.declarations preserve=no
//## end module%466045E40038.declarations

//## begin module%466045E40038.additionalDeclarations preserve=yes
//## end module%466045E40038.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::CommandWatch 

CommandWatch::CommandWatch()
  //## begin CommandWatch::CommandWatch%466030420035_const.hasinit preserve=no
  //## end CommandWatch::CommandWatch%466030420035_const.hasinit
  //## begin CommandWatch::CommandWatch%466030420035_const.initialization preserve=yes
  //## end CommandWatch::CommandWatch%466030420035_const.initialization
{
  //## begin command::CommandWatch::CommandWatch%466030420035_const.body preserve=yes
   memcpy(m_sID,"BC24",4);
   string strRecord;
   if (Extract::instance()->getRecord("DUSER",strRecord)
      && strRecord.find("WATCH") != string::npos)
   {
      m_hTimer.set("00010000");
      m_hTimer.attach(this);
   }
  //## end command::CommandWatch::CommandWatch%466030420035_const.body
}


CommandWatch::~CommandWatch()
{
  //## begin command::CommandWatch::~CommandWatch%466030420035_dest.body preserve=yes
  //## end command::CommandWatch::~CommandWatch%466030420035_dest.body
}



//## Other Operations (implementation)
void CommandWatch::update (Subject* pSubject)
{
  //## begin command::CommandWatch::update%46604A4802FB.body preserve=yes
   if (pSubject == &m_hTimer)
   {
      UseCase hUseCase("FD","## FD01 ROUTE COMMAND");
      // query for commands to route
      Query hQuery;
      hQuery.attach(this);
      hQuery.setRetainCursor(true);
      hQuery.bind("TASK_CONTEXT","CONTEXT_KEY",Column::STRING,&m_strCONTEXT_KEY);
      hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA);
      hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=",Application::instance()->name().c_str());
      hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","R");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
      {
         m_hTimer.set("00010000");
         Database::instance()->rollback();
         UseCase::setSuccess(false);
         return;
      }      
      if (pSelectStatement->getRows() != 0)
         m_hTimer.set("00001000");
      else
         m_hTimer.set("00010000");
      Database::instance()->commit();
      return;
   }
   // route command to task
   CommandMessage hCommandMessage(string("RESET"),m_strCONTEXT_KEY);
   if (!hCommandMessage.execute(m_strCONTEXT_DATA.c_str()))
   {
      UseCase::setSuccess(false);
      return;
   }
   //delete row now that command has been successfully passed on
   Query hQuery;
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_KEY","=",m_strCONTEXT_KEY.c_str());
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_DATA","=",m_strCONTEXT_DATA.c_str());
   hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=",Application::instance()->name().c_str());
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","R");
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   if (!pDeleteStatement->execute(hQuery))
   {
      ((Query*)pSubject)->setAbort(true);
      Database::instance()->rollback();
      UseCase::setSuccess(false);
      return;
   }
   UseCase::addItem();
   Database::instance()->commit();
  //## end command::CommandWatch::update%46604A4802FB.body
}

// Additional Declarations
  //## begin command::CommandWatch%466030420035.declarations preserve=yes
  //## end command::CommandWatch%466030420035.declarations

} // namespace command

//## begin module%466045E40038.epilog preserve=yes
//## end module%466045E40038.epilog
