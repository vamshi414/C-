//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52B437F90268.cm preserve=no
//## end module%52B437F90268.cm

//## begin module%52B437F90268.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%52B437F90268.cp

//## Module: CXOSBC40%52B437F90268; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC40.cpp

//## begin module%52B437F90268.additionalIncludes preserve=no
//## end module%52B437F90268.additionalIncludes

//## begin module%52B437F90268.includes preserve=yes
//## end module%52B437F90268.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBC40_h
#include "CXODBC40.hpp"
#endif


//## begin module%52B437F90268.declarations preserve=no
//## end module%52B437F90268.declarations

//## begin module%52B437F90268.additionalDeclarations preserve=yes
//## end module%52B437F90268.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::User 

//## begin command::User::Instance%52B4378801AA.attr preserve=no  private: static command::User* {V} 0
command::User* User::m_pInstance = 0;
//## end command::User::Instance%52B4378801AA.attr

User::User()
  //## begin User::User%52B4372F013E_const.hasinit preserve=no
  //## end User::User%52B4372F013E_const.hasinit
  //## begin User::User%52B4372F013E_const.initialization preserve=yes
  //## end User::User%52B4372F013E_const.initialization
{
  //## begin command::User::User%52B4372F013E_const.body preserve=yes
   memcpy(m_sID,"BC40",4);
  //## end command::User::User%52B4372F013E_const.body
}


User::~User()
{
  //## begin command::User::~User%52B4372F013E_dest.body preserve=yes
   m_pInstance = 0;
  //## end command::User::~User%52B4372F013E_dest.body
}



//## Other Operations (implementation)
const set <string>&  User::getEntityLevel ()
{
  //## begin command::User::getEntityLevel%6287C5190340.body preserve=yes
   if (m_strUSER_ID != CommonHeaderSegment::instance()->getUserID())
   {
      m_strUSER_ID = CommonHeaderSegment::instance()->getUserID();
      load();
   }
   return m_hEntityLevel;
  //## end command::User::getEntityLevel%6287C5190340.body
}

bool User::getRole (const string& strINST_ID_RECN_ACQ_B, const string& strINST_ID_RECN_ISS_B, const string& strPROC_ID_ACQ_B, const string& strPROC_ID_ISS_B, const string& strRPT_LVL_ID_B, string& strRole)
{
  //## begin command::User::getRole%52B439850051.body preserve=yes
   strRole = 'N';
   if (m_strUSER_ID != CommonHeaderSegment::instance()->getUserID())
   {
      m_strUSER_ID = CommonHeaderSegment::instance()->getUserID();
      if (!load())
         return false;
   }
   string strKey("*:*");
   if (m_hEntity.find(strKey) != m_hEntity.end())
   {
      strRole = 'B';
      return true;
   }
   char cAcquirer = 'N';
   char cIssuer = 'N';
   strKey = "PROC:" + strPROC_ID_ACQ_B;
   if (m_hEntity.find(strKey) != m_hEntity.end())
      cAcquirer = 'Y';
   strKey = "INST:" + strINST_ID_RECN_ACQ_B;
   if (m_hEntity.find(strKey) != m_hEntity.end())
      cAcquirer = 'Y';
   strKey = "RPTLVL:" + strRPT_LVL_ID_B;
   if (m_hEntity.find(strKey) != m_hEntity.end())
      cAcquirer = 'Y';
   strKey = "PROC:" + strPROC_ID_ISS_B;
   if (m_hEntity.find(strKey) != m_hEntity.end())
      cIssuer = 'Y';
   strKey = "INST:" + strINST_ID_RECN_ISS_B;
   if (m_hEntity.find(strKey) != m_hEntity.end())
      cIssuer = 'Y';
   if (cAcquirer == 'Y' && cIssuer == 'Y')
      strRole = 'B';
   else
   if (cAcquirer == 'Y')
      strRole = 'A';
   else
   if (cIssuer == 'Y')
      strRole = 'I';
   return true;
  //## end command::User::getRole%52B439850051.body
}

User* User::instance ()
{
  //## begin command::User::instance%52B4376C01C9.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new User();
   return m_pInstance;
  //## end command::User::instance%52B4376C01C9.body
}

bool User::load ()
{
  //## begin command::User::load%52B43FC50369.body preserve=yes
   m_hEntity.erase(m_hEntity.begin(),m_hEntity.end());
   m_hEntityLevel.erase(m_hEntityLevel.begin(), m_hEntityLevel.end());
   Query hQuery;
   hQuery.attach(this);
   hQuery.setDistinct(true);
   hQuery.setQualifier("QUALIFY","AS_USER_PROFILE");
   hQuery.setQualifier("QUALIFY","AS_ENTITY_ROLE");
   hQuery.join("AS_USER_PROFILE","INNER","AS_ENTITY_ROLE","ENTITY_ID");
   hQuery.bind("AS_ENTITY_ROLE","ROLE_ID",Column::STRING,&m_strROLE_ID);
   hQuery.bind("AS_ENTITY_ROLE","ONLINE_ENTITY_ID",Column::STRING,&m_strONLINE_ENTITY_ID);
   hQuery.setBasicPredicate("AS_USER_PROFILE","USER_ID","=",m_strUSER_ID.c_str());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*) DatabaseFactory::instance()->create("SelectStatement"));
   return pSelectStatement->execute(hQuery);
  //## end command::User::load%52B43FC50369.body
}

void User::update (Subject* pSubject)
{
  //## begin command::User::update%52B437A4011F.body preserve=yes
   if (m_strROLE_ID == "PROCS"
      || m_strROLE_ID == "ACQPROC"
      || m_strROLE_ID == "ISSPROC")
      m_strROLE_ID.assign("PROC", 4);
   m_hEntityLevel.insert(m_strROLE_ID);
   m_hEntity.insert(m_strROLE_ID + ":" + m_strONLINE_ENTITY_ID);
  //## end command::User::update%52B437A4011F.body
}

// Additional Declarations
  //## begin command::User%52B4372F013E.declarations preserve=yes
  //## end command::User%52B4372F013E.declarations

} // namespace command

//## begin module%52B437F90268.epilog preserve=yes
//## end module%52B437F90268.epilog
