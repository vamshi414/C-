//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4C61B7090201.cm preserve=no
//## end module%4C61B7090201.cm

//## begin module%4C61B7090201.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4C61B7090201.cp

//## Module: CXOSBC34%4C61B7090201; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC34.hpp

#ifndef CXOSBC34_h
#define CXOSBC34_h 1

//## begin module%4C61B7090201.additionalIncludes preserve=no
//## end module%4C61B7090201.additionalIncludes

//## begin module%4C61B7090201.includes preserve=yes
#include <map>
//## end module%4C61B7090201.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%4C61B7090201.declarations preserve=no
//## end module%4C61B7090201.declarations

//## begin module%4C61B7090201.additionalDeclarations preserve=yes
//## end module%4C61B7090201.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::XMLItem%4C61B6DB01B3.preface preserve=yes
//## end command::XMLItem%4C61B6DB01B3.preface

//## Class: XMLItem%4C61B6DB01B3
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4C61C1BD01DD;segment::Segment { -> F}

class DllExport XMLItem : public reusable::Object  //## Inherits: <unnamed>%4C61B7D402BE
{
  //## begin command::XMLItem%4C61B6DB01B3.initialDeclarations preserve=yes
  //## end command::XMLItem%4C61B6DB01B3.initialDeclarations

  public:
    //## Constructors (generated)
      XMLItem();

    //## Destructor (generated)
      virtual ~XMLItem();


    //## Other Operations (specified)
      //## Operation: add%4C61B8CE036C
      void add (const string& strName, const string& strValue);

      //## Operation: get%4C63111B00FB
      bool get (const char* pszName, string& strValue);

      //## Operation: get%5B4C9EDB02D3
      const string& get (const char* pszName);

      //## Operation: import%4C630A230393
      virtual void import ();

      //## Operation: reset%4DC0457B0055
      void reset ();

      //## Operation: resetToken%5B4CA0F6013F
      void resetToken ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Token%4C61B8630139
      const map<string,string,less<string> >& getToken () const
      {
        //## begin command::XMLItem::getToken%4C61B8630139.get preserve=no
        return m_hToken;
        //## end command::XMLItem::getToken%4C61B8630139.get
      }


    // Additional Public Declarations
      //## begin command::XMLItem%4C61B6DB01B3.public preserve=yes
      //## end command::XMLItem%4C61B6DB01B3.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Column%4C61B85D0119
      //## begin command::XMLItem::Column%4C61B85D0119.attr preserve=no  protected: multimap<string,pair<segment::Segment*,string>,less<string> > {U} 
      multimap<string,pair<segment::Segment*,string>,less<string> > m_hColumn;
      //## end command::XMLItem::Column%4C61B85D0119.attr

      //## begin command::XMLItem::Token%4C61B8630139.attr preserve=no  public: map<string,string,less<string> > {U} 
      map<string,string,less<string> > m_hToken;
      //## end command::XMLItem::Token%4C61B8630139.attr

    // Additional Protected Declarations
      //## begin command::XMLItem%4C61B6DB01B3.protected preserve=yes
      //## end command::XMLItem%4C61B6DB01B3.protected

  private:
    // Additional Private Declarations
      //## begin command::XMLItem%4C61B6DB01B3.private preserve=yes
      //## end command::XMLItem%4C61B6DB01B3.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Value%5B4C9EB5006E
      //## begin command::XMLItem::Value%5B4C9EB5006E.attr preserve=no  private: string {V} 
      string m_strValue;
      //## end command::XMLItem::Value%5B4C9EB5006E.attr

    // Additional Implementation Declarations
      //## begin command::XMLItem%4C61B6DB01B3.implementation preserve=yes
      //## end command::XMLItem%4C61B6DB01B3.implementation

};

//## begin command::XMLItem%4C61B6DB01B3.postscript preserve=yes
//## end command::XMLItem%4C61B6DB01B3.postscript

} // namespace command

//## begin module%4C61B7090201.epilog preserve=yes
//## end module%4C61B7090201.epilog


#endif
