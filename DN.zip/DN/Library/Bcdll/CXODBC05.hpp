//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3E9AD3B902AF.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E9AD3B902AF.cm

//## begin module%3E9AD3B902AF.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3E9AD3B902AF.cp

//## Module: CXOSBC05%3E9AD3B902AF; Package specification
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC05.hpp

#ifndef CXOSBC05_h
#define CXOSBC05_h 1

//## begin module%3E9AD3B902AF.additionalIncludes preserve=no
//## end module%3E9AD3B902AF.additionalIncludes

//## begin module%3E9AD3B902AF.includes preserve=yes
// $Date:   Apr 08 2004 11:17:18  $ $Author:   D02405  $ $Revision:   1.1  $
//## end module%3E9AD3B902AF.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
class InformationSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class UserPool;

} // namespace command

//## begin module%3E9AD3B902AF.declarations preserve=no
//## end module%3E9AD3B902AF.declarations

//## begin module%3E9AD3B902AF.additionalDeclarations preserve=yes
//## end module%3E9AD3B902AF.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::LogoffCommand%3E9AD37E02DE.preface preserve=yes
//## end command::LogoffCommand%3E9AD37E02DE.preface

//## Class: LogoffCommand%3E9AD37E02DE
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E9BFBBF01C5;IF::Message { -> F}
//## Uses: <unnamed>%3E9BFCDE0271;monitor::UseCase { -> F}
//## Uses: <unnamed>%3E9BFD9E03A9;segment::InformationSegment { -> F}
//## Uses: <unnamed>%3E9BFE580186;UserPool { -> F}
//## Uses: <unnamed>%3E9D8480005D;segment::CommonHeaderSegment { -> F}

class DllExport LogoffCommand : public ClientCommand  //## Inherits: <unnamed>%3E9AD39601D4
{
  //## begin command::LogoffCommand%3E9AD37E02DE.initialDeclarations preserve=yes
  //## end command::LogoffCommand%3E9AD37E02DE.initialDeclarations

  public:
    //## Constructors (generated)
      LogoffCommand();

    //## Constructors (specified)
      //## Operation: LogoffCommand%3E9C022D03B9
      LogoffCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~LogoffCommand();


    //## Other Operations (specified)
      //## Operation: execute%3E9AD6FB00AB
      //	Perform the functions of this command.
      virtual bool execute ();

    // Additional Public Declarations
      //## begin command::LogoffCommand%3E9AD37E02DE.public preserve=yes
      //## end command::LogoffCommand%3E9AD37E02DE.public

  protected:
    // Additional Protected Declarations
      //## begin command::LogoffCommand%3E9AD37E02DE.protected preserve=yes
      //## end command::LogoffCommand%3E9AD37E02DE.protected

  private:
    // Additional Private Declarations
      //## begin command::LogoffCommand%3E9AD37E02DE.private preserve=yes
      //## end command::LogoffCommand%3E9AD37E02DE.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin command::LogoffCommand%3E9AD37E02DE.implementation preserve=yes
      //## end command::LogoffCommand%3E9AD37E02DE.implementation

};

//## begin command::LogoffCommand%3E9AD37E02DE.postscript preserve=yes
//## end command::LogoffCommand%3E9AD37E02DE.postscript

} // namespace command

//## begin module%3E9AD3B902AF.epilog preserve=yes
using namespace command;
//## end module%3E9AD3B902AF.epilog


#endif
