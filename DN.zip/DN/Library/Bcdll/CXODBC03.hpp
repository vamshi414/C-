//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3729EC2C0232.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3729EC2C0232.cm

//## begin module%3729EC2C0232.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3729EC2C0232.cp

//## Module: CXOSBC03%3729EC2C0232; Package specification
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Pvcswork\Dn\Server\Library\Bcdll\CXODBC03.hpp

#ifndef CXOSBC03_h
#define CXOSBC03_h 1

//## begin module%3729EC2C0232.additionalIncludes preserve=no
//## end module%3729EC2C0232.additionalIncludes

//## begin module%3729EC2C0232.includes preserve=yes
// $Date:   Apr 08 2004 11:17:16  $ $Author:   D02405  $ $Revision:   1.2  $
//## end module%3729EC2C0232.includes

#ifndef CXOSIF37_h
#include "CXODIF37.hpp"
#endif
#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Message;

} // namespace IF

//## begin module%3729EC2C0232.declarations preserve=no
//## end module%3729EC2C0232.declarations

//## begin module%3729EC2C0232.additionalDeclarations preserve=yes
//## end module%3729EC2C0232.additionalDeclarations


//## Modelname: Connex Foundation::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::DynamicSQLCommand%3729CAD90145.preface preserve=yes
//## end command::DynamicSQLCommand%3729CAD90145.preface

//## Class: DynamicSQLCommand%3729CAD90145
//## Category: Connex Foundation::Command_CAT%3459269903E2
//## Subsystem: BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3729ED3403C2;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%372A19C30021;IF::Message { -> F}
//## Uses: <unnamed>%3741DB9002F4;IF::Extract { -> F}
//## Uses: <unnamed>%3A42655000E4;monitor::UseCase { -> F}

class DllExport DynamicSQLCommand : public reusable::Observer  //## Inherits: <unnamed>%3729CB4D03AE
{
  //## begin command::DynamicSQLCommand%3729CAD90145.initialDeclarations preserve=yes
  //## end command::DynamicSQLCommand%3729CAD90145.initialDeclarations

  public:
    //## Constructors (generated)
      DynamicSQLCommand();

    //## Destructor (generated)
      virtual ~DynamicSQLCommand();


    //## Other Operations (specified)
      //## Operation: execute%3729CB2103B5
      bool execute ();

      //## Operation: update%3729CB5B01B0
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin command::DynamicSQLCommand%3729CAD90145.public preserve=yes
      //## end command::DynamicSQLCommand%3729CAD90145.public

  protected:
    // Additional Protected Declarations
      //## begin command::DynamicSQLCommand%3729CAD90145.protected preserve=yes
      //## end command::DynamicSQLCommand%3729CAD90145.protected

  private:
    // Additional Private Declarations
      //## begin command::DynamicSQLCommand%3729CAD90145.private preserve=yes
      //## end command::DynamicSQLCommand%3729CAD90145.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Foundation::Command_CAT::<unnamed>%3729EF0300D9
      //## Role: DynamicSQLCommand::<m_pSelectStatement>%3729EF040044
      //## begin command::DynamicSQLCommand::<m_pSelectStatement>%3729EF040044.role preserve=no  public: reusable::SelectStatement { -> RFHgN}
      reusable::SelectStatement *m_pSelectStatement;
      //## end command::DynamicSQLCommand::<m_pSelectStatement>%3729EF040044.role

      //## Association: Connex Foundation::Command_CAT::<unnamed>%372A1A5D0113
      //## Role: DynamicSQLCommand::<m_hResultSet>%372A1A5D0394
      //## begin command::DynamicSQLCommand::<m_hResultSet>%372A1A5D0394.role preserve=no  public: IF::ResultSet { -> VHgN}
      IF::ResultSet m_hResultSet;
      //## end command::DynamicSQLCommand::<m_hResultSet>%372A1A5D0394.role

    // Additional Implementation Declarations
      //## begin command::DynamicSQLCommand%3729CAD90145.implementation preserve=yes
      //## end command::DynamicSQLCommand%3729CAD90145.implementation

};

//## begin command::DynamicSQLCommand%3729CAD90145.postscript preserve=yes
//## end command::DynamicSQLCommand%3729CAD90145.postscript

} // namespace command

//## begin module%3729EC2C0232.epilog preserve=yes
using namespace command;
//## end module%3729EC2C0232.epilog


#endif
