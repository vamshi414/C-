//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5B85AB560004.cm preserve=no
//	$Date:   Oct 30 2018 11:39:54  $ $Author:   e1009591  $ $Revision:   1.0  $
//## end module%5B85AB560004.cm

//## begin module%5B85AB560004.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5B85AB560004.cp

//## Module: CXOSBC56%5B85AB560004; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.9A.R008\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC56.hpp

#ifndef CXOSBC56_h
#define CXOSBC56_h 1

//## begin module%5B85AB560004.additionalIncludes preserve=no
//## end module%5B85AB560004.additionalIncludes

//## begin module%5B85AB560004.includes preserve=yes
//## end module%5B85AB560004.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#include <map>
//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class APIExport;

} // namespace command

//## begin module%5B85AB560004.declarations preserve=no
//## end module%5B85AB560004.declarations

//## begin module%5B85AB560004.additionalDeclarations preserve=yes
//## end module%5B85AB560004.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::APIQueueExportFactory%5B85A7030358.preface preserve=yes
//## end command::APIQueueExportFactory%5B85A7030358.preface

//## Class: APIQueueExportFactory%5B85A7030358
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5B85AC380069;APIExport { -> F}

class DllExport APIQueueExportFactory : public reusable::Object  //## Inherits: <unnamed>%5B85AC3500F9
{
  //## begin command::APIQueueExportFactory%5B85A7030358.initialDeclarations preserve=yes
  //## end command::APIQueueExportFactory%5B85A7030358.initialDeclarations

  public:
    //## Constructors (generated)
      APIQueueExportFactory();

    //## Destructor (generated)
      virtual ~APIQueueExportFactory();


    //## Other Operations (specified)
      //## Operation: create%5B85ACE60213
      virtual command::APIExport* create (const char* pszAPIType) = 0;

      //## Operation: instance%5B85ACE60215
      static command::APIQueueExportFactory* instance ();

    // Additional Public Declarations
      //## begin command::APIQueueExportFactory%5B85A7030358.public preserve=yes
      //## end command::APIQueueExportFactory%5B85A7030358.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Classes%5B85AC4C0014
      //## begin command::APIQueueExportFactory::Classes%5B85AC4C0014.attr preserve=no  public: map<string,int,less<string> > {V} 
      map<string,int,less<string> > m_hClasses;
      //## end command::APIQueueExportFactory::Classes%5B85AC4C0014.attr

    // Additional Protected Declarations
      //## begin command::APIQueueExportFactory%5B85A7030358.protected preserve=yes
      //## end command::APIQueueExportFactory%5B85A7030358.protected

  private:
    // Additional Private Declarations
      //## begin command::APIQueueExportFactory%5B85A7030358.private preserve=yes
      //## end command::APIQueueExportFactory%5B85A7030358.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5B85AC4C0010
      //## begin command::APIQueueExportFactory::Instance%5B85AC4C0010.attr preserve=no  private: static APIQueueExportFactory* {V} 0
      static APIQueueExportFactory* m_pInstance;
      //## end command::APIQueueExportFactory::Instance%5B85AC4C0010.attr

    // Additional Implementation Declarations
      //## begin command::APIQueueExportFactory%5B85A7030358.implementation preserve=yes
      //## end command::APIQueueExportFactory%5B85A7030358.implementation

};

//## begin command::APIQueueExportFactory%5B85A7030358.postscript preserve=yes
//## end command::APIQueueExportFactory%5B85A7030358.postscript

} // namespace command

//## begin module%5B85AB560004.epilog preserve=yes
//## end module%5B85AB560004.epilog


#endif
