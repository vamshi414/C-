//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3681283D0196.cm preserve=no
//	$Date:   Nov 25 2014 10:33:50  $ $Author:   e1009839  $ $Revision:   1.3  $
//## end module%3681283D0196.cm

//## begin module%3681283D0196.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3681283D0196.cp

//## Module: CXOSBC06%3681283D0196; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC06.cpp

//## begin module%3681283D0196.additionalIncludes preserve=no
//## end module%3681283D0196.additionalIncludes

//## begin module%3681283D0196.includes preserve=yes
//## end module%3681283D0196.includes

#ifndef CXOSRU07_h
#include "CXODRU07.hpp"
#endif
#ifndef CXOSBC06_h
#include "CXODBC06.hpp"
#endif


//## begin module%3681283D0196.declarations preserve=no
//## end module%3681283D0196.declarations

//## begin module%3681283D0196.additionalDeclarations preserve=yes
//## end module%3681283D0196.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::CopyColumnNamesVisitor

CopyColumnNamesVisitor::CopyColumnNamesVisitor()
  //## begin CopyColumnNamesVisitor::CopyColumnNamesVisitor%368127A80016_const.hasinit preserve=no
  //## end CopyColumnNamesVisitor::CopyColumnNamesVisitor%368127A80016_const.hasinit
  //## begin CopyColumnNamesVisitor::CopyColumnNamesVisitor%368127A80016_const.initialization preserve=yes
  //## end CopyColumnNamesVisitor::CopyColumnNamesVisitor%368127A80016_const.initialization
{
  //## begin command::CopyColumnNamesVisitor::CopyColumnNamesVisitor%368127A80016_const.body preserve=yes
   memcpy(m_sID,"BC06",4);
  //## end command::CopyColumnNamesVisitor::CopyColumnNamesVisitor%368127A80016_const.body
}

CopyColumnNamesVisitor::CopyColumnNamesVisitor (char** ppsBuffer)
  //## begin command::CopyColumnNamesVisitor::CopyColumnNamesVisitor%368129790050.hasinit preserve=no
  //## end command::CopyColumnNamesVisitor::CopyColumnNamesVisitor%368129790050.hasinit
  //## begin command::CopyColumnNamesVisitor::CopyColumnNamesVisitor%368129790050.initialization preserve=yes
  //## end command::CopyColumnNamesVisitor::CopyColumnNamesVisitor%368129790050.initialization
{
  //## begin command::CopyColumnNamesVisitor::CopyColumnNamesVisitor%368129790050.body preserve=yes
   memcpy(m_sID,"BC06",4);
   m_ppsBuffer = ppsBuffer;
  //## end command::CopyColumnNamesVisitor::CopyColumnNamesVisitor%368129790050.body
}


CopyColumnNamesVisitor::~CopyColumnNamesVisitor()
{
  //## begin command::CopyColumnNamesVisitor::~CopyColumnNamesVisitor%368127A80016_dest.body preserve=yes
  //## end command::CopyColumnNamesVisitor::~CopyColumnNamesVisitor%368127A80016_dest.body
}



//## Other Operations (implementation)
void CopyColumnNamesVisitor::visitColumn (reusable::Table* pTable, Column* pColumn)
{
  //## begin command::CopyColumnNamesVisitor::visitColumn%3681295F0017.body preserve=yes
   memset(*m_ppsBuffer,' ',30);
   memcpy(*m_ppsBuffer,pColumn->getName().data(),pColumn->getName().length());
   *m_ppsBuffer += 30;
  //## end command::CopyColumnNamesVisitor::visitColumn%3681295F0017.body
}

// Additional Declarations
  //## begin command::CopyColumnNamesVisitor%368127A80016.declarations preserve=yes
  //## end command::CopyColumnNamesVisitor%368127A80016.declarations

} // namespace command

//## begin module%3681283D0196.epilog preserve=yes
//## end module%3681283D0196.epilog
