//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52FB8E260257.cm preserve=no
//	$Date:   Mar 16 2018 10:05:14  $ $Author:   e1009839  $
//	$Revision:   1.4  $
//## end module%52FB8E260257.cm

//## begin module%52FB8E260257.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52FB8E260257.cp

//## Module: CXOSBC45%52FB8E260257; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC45.hpp

#ifndef CXOSBC45_h
#define CXOSBC45_h 1

//## begin module%52FB8E260257.additionalIncludes preserve=no
//## end module%52FB8E260257.additionalIncludes

//## begin module%52FB8E260257.includes preserve=yes
//## end module%52FB8E260257.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Column;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class GenericSegment;

} // namespace segment

//## begin module%52FB8E260257.declarations preserve=no
//## end module%52FB8E260257.declarations

//## begin module%52FB8E260257.additionalDeclarations preserve=yes
//## end module%52FB8E260257.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::Predicate%52FB85450346.preface preserve=yes
//## end command::Predicate%52FB85450346.preface

//## Class: Predicate%52FB85450346
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%52FB85990243;segment::GenericSegment { -> F}
//## Uses: <unnamed>%52FB94400374;reusable::Buffer { -> F}
//## Uses: <unnamed>%5485ECAD0047;database::Column { -> F}
//## Uses: <unnamed>%558919D103D5;IF::Extract { -> F}

class DllExport Predicate : public reusable::Object  //## Inherits: <unnamed>%52FB855B0167
{
  //## begin command::Predicate%52FB85450346.initialDeclarations preserve=yes
  //## end command::Predicate%52FB85450346.initialDeclarations

  public:
    //## Constructors (generated)
      Predicate();

      Predicate(const Predicate &right);

    //## Constructors (specified)
      //## Operation: Predicate%52FB90800088
      Predicate (const char* pszBuffer);

      //## Operation: Predicate%5AAAC596015B
      Predicate (const string& strParent, const string& strName, const string& strOperator, const string& strValue);

    //## Destructor (generated)
      virtual ~Predicate();

    //## Assignment Operation (generated)
      Predicate & operator=(const Predicate &right);


    //## Other Operations (specified)
      //## Operation: addColumn%52FD4979030F
      void addColumn (const string& strTag, multimap<string,database::Column,less<string> >& hTag);

      //## Operation: match%52FB85680254
      bool match (const segment::GenericSegment& hGenericSegment);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Name%52FB85AA01D1
      const string& getName () const
      {
        //## begin command::Predicate::getName%52FB85AA01D1.get preserve=no
        return m_strName;
        //## end command::Predicate::getName%52FB85AA01D1.get
      }


      //## Attribute: Operator%52FB85C1028C
      const string& getOperator () const
      {
        //## begin command::Predicate::getOperator%52FB85C1028C.get preserve=no
        return m_strOperator;
        //## end command::Predicate::getOperator%52FB85C1028C.get
      }


      //## Attribute: Parent%5AAABC080120
      const string& getParent () const
      {
        //## begin command::Predicate::getParent%5AAABC080120.get preserve=no
        return m_strParent;
        //## end command::Predicate::getParent%5AAABC080120.get
      }


      //## Attribute: Value%52FB85C10338
      const string& getValue () const
      {
        //## begin command::Predicate::getValue%52FB85C10338.get preserve=no
        return m_strValue;
        //## end command::Predicate::getValue%52FB85C10338.get
      }


    // Additional Public Declarations
      //## begin command::Predicate%52FB85450346.public preserve=yes
      //## end command::Predicate%52FB85450346.public

  protected:
    // Additional Protected Declarations
      //## begin command::Predicate%52FB85450346.protected preserve=yes
      //## end command::Predicate%52FB85450346.protected

  private:
    // Additional Private Declarations
      //## begin command::Predicate%52FB85450346.private preserve=yes
      //## end command::Predicate%52FB85450346.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::Predicate::Name%52FB85AA01D1.attr preserve=no  public: string {V} 
      string m_strName;
      //## end command::Predicate::Name%52FB85AA01D1.attr

      //## begin command::Predicate::Operator%52FB85C1028C.attr preserve=no  public: string {V} 
      string m_strOperator;
      //## end command::Predicate::Operator%52FB85C1028C.attr

      //## begin command::Predicate::Parent%5AAABC080120.attr preserve=no  public: string {V} 
      string m_strParent;
      //## end command::Predicate::Parent%5AAABC080120.attr

      //## begin command::Predicate::Value%52FB85C10338.attr preserve=no  public: string {V} 
      string m_strValue;
      //## end command::Predicate::Value%52FB85C10338.attr

    // Additional Implementation Declarations
      //## begin command::Predicate%52FB85450346.implementation preserve=yes
      //## end command::Predicate%52FB85450346.implementation

};

//## begin command::Predicate%52FB85450346.postscript preserve=yes
//## end command::Predicate%52FB85450346.postscript

} // namespace command

//## begin module%52FB8E260257.epilog preserve=yes
//## end module%52FB8E260257.epilog


#endif
