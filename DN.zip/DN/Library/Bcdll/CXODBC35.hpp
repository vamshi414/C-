//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4C61BBE30361.cm preserve=no
//	$Date:   Nov 19 2018 17:35:08  $ $Author:   e1009510  $
//	$Revision:   1.11  $
//## end module%4C61BBE30361.cm

//## begin module%4C61BBE30361.cp preserve=no
//	Copyright (c) 1997 - 2018
//	FIS
//## end module%4C61BBE30361.cp

//## Module: CXOSBC35%4C61BBE30361; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC35.hpp

#ifndef CXOSBC35_h
#define CXOSBC35_h 1

//## begin module%4C61BBE30361.additionalIncludes preserve=no
//## end module%4C61BBE30361.additionalIncludes

//## begin module%4C61BBE30361.includes preserve=yes
#ifdef _WIN32
#include "xercesc\framework\XMLFormatter.hpp"
#include "xercesc\framework\MemBufFormatTarget.hpp"
#include "xercesc\sax\HandlerBase.hpp"
#else
#include "xercesc/framework/XMLFormatter.hpp"
#include "xercesc/framework/MemBufFormatTarget.hpp"
#include "xercesc/sax/HandlerBase.hpp"
#endif
XERCES_CPP_NAMESPACE_USE
#include <vector>
#include "CXODRU05.hpp"
#ifdef MVS
#define XMLSIZE unsigned int
#else
#ifdef SOLARISAMD64 
#define XMLSIZE unsigned int
#else
#ifdef _AIX
#define XMLSIZE unsigned int
#else
#define XMLSIZE XMLSize_t
#endif
#endif
#endif
//## end module%4C61BBE30361.includes


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SOAPSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class SOAPCommand;
class XMLItem;

} // namespace command

//## begin module%4C61BBE30361.declarations preserve=no
//## end module%4C61BBE30361.declarations

//## begin module%4C61BBE30361.additionalDeclarations preserve=yes
//## end module%4C61BBE30361.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::XMLHandler%4C61BB7A012E.preface preserve=yes
//## end command::XMLHandler%4C61BB7A012E.preface

//## Class: XMLHandler%4C61BB7A012E
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4CC72F69020A;IF::Trace { -> F}
//## Uses: <unnamed>%4CC72F6B0381;IF::CodeTable { -> F}
//## Uses: <unnamed>%51B9DC86019F;segment::SOAPSegment { -> F}

class DllExport XMLHandler : public HandlerBase  //## Inherits: <unnamed>%4C61BCAC0391
{
  //## begin command::XMLHandler%4C61BB7A012E.initialDeclarations preserve=yes
  //## end command::XMLHandler%4C61BB7A012E.initialDeclarations

  public:
    //## Constructors (generated)
      XMLHandler();

    //## Constructors (specified)
      //## Operation: XMLHandler%4C61BCFB02F6
      XMLHandler (command::XMLItem* pXMLItem);

      //## Operation: XMLHandler%5B48B0C003BE
      XMLHandler (command::XMLItem* pXMLItem, command::SOAPCommand* pSOAPCommand);

    //## Destructor (generated)
      virtual ~XMLHandler();


    //## Other Operations (specified)
      //## Operation: characters%4C61BD3C03A2
      virtual void characters (const XMLCh* const chars, const XMLSIZE length);

      //## Operation: endDocument%4C61BD4C0095
      virtual void endDocument ();

      //## Operation: endElement%4C64497601C8
      virtual void endElement (const XMLCh* const name);

      //## Operation: error%4C64497D017A
      virtual void error (const SAXParseException& exc);

      //## Operation: fatalError%4C644983009F
      virtual void fatalError (const SAXParseException& exc);

      //## Operation: getToken%4C6584390298
      void getToken (const char* pszFunction, const XMLCh* const psBuffer, size_t lLength);

      //## Operation: startElement%4C6449910031
      virtual void startElement (const XMLCh* const name, AttributeList& attributes);

      //## Operation: getCharacters%5498757F0285
      const string& getCharacters ()
      {
        //## begin command::XMLHandler::getCharacters%5498757F0285.body preserve=yes
        Object hObject;
        hObject.trim(m_strCharacters);
        return m_strCharacters;
        //## end command::XMLHandler::getCharacters%5498757F0285.body
      }

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Token%4C6584A60017
      const string& getToken () const
      {
        //## begin command::XMLHandler::getToken%4C6584A60017.get preserve=no
        return m_strToken;
        //## end command::XMLHandler::getToken%4C6584A60017.get
      }


    // Additional Public Declarations
      //## begin command::XMLHandler%4C61BB7A012E.public preserve=yes
      //## end command::XMLHandler%4C61BB7A012E.public

  protected:
    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%5B489E770389
      //## Role: XMLHandler::<m_pSOAPCommand>%5B489E78033B
      //## begin command::XMLHandler::<m_pSOAPCommand>%5B489E78033B.role preserve=no  protected: command::SOAPCommand { -> RFHgN}
      SOAPCommand *m_pSOAPCommand;
      //## end command::XMLHandler::<m_pSOAPCommand>%5B489E78033B.role

    // Additional Protected Declarations
      //## begin command::XMLHandler%4C61BB7A012E.protected preserve=yes
	  vector<string> m_hElement;
      //## end command::XMLHandler%4C61BB7A012E.protected
  private:
    // Additional Private Declarations
      //## begin command::XMLHandler%4C61BB7A012E.private preserve=yes
      //## end command::XMLHandler%4C61BB7A012E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Characters%54416F1703BD
      //## begin command::XMLHandler::Characters%54416F1703BD.attr preserve=no  public: string {V} 
      string m_strCharacters;
      //## end command::XMLHandler::Characters%54416F1703BD.attr

      //## Attribute: MemBufFormatTarget%4C645753011B
      //## begin command::XMLHandler::MemBufFormatTarget%4C645753011B.attr preserve=no  private: MemBufFormatTarget {V} 
      MemBufFormatTarget m_hMemBufFormatTarget;
      //## end command::XMLHandler::MemBufFormatTarget%4C645753011B.attr

      //## begin command::XMLHandler::Token%4C6584A60017.attr preserve=no  public: string {V} 
      string m_strToken;
      //## end command::XMLHandler::Token%4C6584A60017.attr

      //## Attribute: XMLFormatter%4C6456310255
      //## begin command::XMLHandler::XMLFormatter%4C6456310255.attr preserve=no  private: XMLFormatter {V} 
      XMLFormatter m_hXMLFormatter;
      //## end command::XMLHandler::XMLFormatter%4C6456310255.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%4C61BE6A0191
      //## Role: XMLHandler::<m_pXMLItem>%4C61BE6B0058
      //## begin command::XMLHandler::<m_pXMLItem>%4C61BE6B0058.role preserve=no  public: command::XMLItem { -> RFHgN}
      XMLItem *m_pXMLItem;
      //## end command::XMLHandler::<m_pXMLItem>%4C61BE6B0058.role

    // Additional Implementation Declarations
      //## begin command::XMLHandler%4C61BB7A012E.implementation preserve=yes
      //## end command::XMLHandler%4C61BB7A012E.implementation

};

//## begin command::XMLHandler%4C61BB7A012E.postscript preserve=yes
//## end command::XMLHandler%4C61BB7A012E.postscript

} // namespace command

//## begin module%4C61BBE30361.epilog preserve=yes
using namespace command;
//## end module%4C61BBE30361.epilog


#endif
