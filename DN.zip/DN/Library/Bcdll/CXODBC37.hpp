//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4F44F3C7027F.cm preserve=no
//## end module%4F44F3C7027F.cm

//## begin module%4F44F3C7027F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4F44F3C7027F.cp

//## Module: CXOSBC37%4F44F3C7027F; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC37.hpp

#ifndef CXOSBC37_h
#define CXOSBC37_h 1

//## begin module%4F44F3C7027F.additionalIncludes preserve=no
//## end module%4F44F3C7027F.additionalIncludes

//## begin module%4F44F3C7027F.includes preserve=yes
//## end module%4F44F3C7027F.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%4F44F3C7027F.declarations preserve=no
//## end module%4F44F3C7027F.declarations

//## begin module%4F44F3C7027F.additionalDeclarations preserve=yes
//## end module%4F44F3C7027F.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::TemplateToken%4F44F17E033D.preface preserve=yes
//## end command::TemplateToken%4F44F17E033D.preface

//## Class: TemplateToken%4F44F17E033D
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport TemplateToken : public reusable::Object  //## Inherits: <unnamed>%4F44F1940344
{
  //## begin command::TemplateToken%4F44F17E033D.initialDeclarations preserve=yes
  //## end command::TemplateToken%4F44F17E033D.initialDeclarations

  public:
    //## Constructors (generated)
      TemplateToken();

      TemplateToken(const TemplateToken &right);

    //## Constructors (specified)
      //## Operation: TemplateToken%4F4502F0013D
      TemplateToken (segment::Segment* pSegment, const string& strName, int iOffset, int iLength, char cType, void* pAddress, int iSize, char cLengthType = ' ', const char* pszLengthAttribute = 0, const char* pszFunctionName = 0, const char* pszXMLTag = 0);

    //## Destructor (generated)
      virtual ~TemplateToken();

    //## Assignment Operation (generated)
      TemplateToken & operator=(const TemplateToken &right);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Address%4F450CAC0097
      const void* getAddress () const
      {
        //## begin command::TemplateToken::getAddress%4F450CAC0097.get preserve=no
        return m_pAddress;
        //## end command::TemplateToken::getAddress%4F450CAC0097.get
      }

      void setAddress (void* value)
      {
        //## begin command::TemplateToken::setAddress%4F450CAC0097.set preserve=no
        m_pAddress = value;
        //## end command::TemplateToken::setAddress%4F450CAC0097.set
      }


      //## Attribute: FunctionName%63C7711C017A
      const string& getFunctionName () const
      {
        //## begin command::TemplateToken::getFunctionName%63C7711C017A.get preserve=no
        return m_strFunctionName;
        //## end command::TemplateToken::getFunctionName%63C7711C017A.get
      }

      void setFunctionName (const string& value)
      {
        //## begin command::TemplateToken::setFunctionName%63C7711C017A.set preserve=no
        m_strFunctionName = value;
        //## end command::TemplateToken::setFunctionName%63C7711C017A.set
      }


      //## Attribute: HexToChar%5A61EDC60213
      const bool getHexToChar () const
      {
        //## begin command::TemplateToken::getHexToChar%5A61EDC60213.get preserve=no
        return m_bHexToChar;
        //## end command::TemplateToken::getHexToChar%5A61EDC60213.get
      }

      void setHexToChar (bool value)
      {
        //## begin command::TemplateToken::setHexToChar%5A61EDC60213.set preserve=no
        m_bHexToChar = value;
        //## end command::TemplateToken::setHexToChar%5A61EDC60213.set
      }


      //## Attribute: Index%5A61EDAF01EB
      const int getIndex () const
      {
        //## begin command::TemplateToken::getIndex%5A61EDAF01EB.get preserve=no
        return m_iIndex;
        //## end command::TemplateToken::getIndex%5A61EDAF01EB.get
      }

      void setIndex (int value)
      {
        //## begin command::TemplateToken::setIndex%5A61EDAF01EB.set preserve=no
        m_iIndex = value;
        //## end command::TemplateToken::setIndex%5A61EDAF01EB.set
      }


      //## Attribute: Length%4F4502BB0116
      const int getLength () const
      {
        //## begin command::TemplateToken::getLength%4F4502BB0116.get preserve=no
        return m_iLength;
        //## end command::TemplateToken::getLength%4F4502BB0116.get
      }

      void setLength (int value)
      {
        //## begin command::TemplateToken::setLength%4F4502BB0116.set preserve=no
        m_iLength = value;
        //## end command::TemplateToken::setLength%4F4502BB0116.set
      }


      //## Attribute: LengthAttribute%4F71747200BE
      const string& getLengthAttribute () const
      {
        //## begin command::TemplateToken::getLengthAttribute%4F71747200BE.get preserve=no
        return m_strLengthAttribute;
        //## end command::TemplateToken::getLengthAttribute%4F71747200BE.get
      }

      void setLengthAttribute (const string& value)
      {
        //## begin command::TemplateToken::setLengthAttribute%4F71747200BE.set preserve=no
        m_strLengthAttribute = value;
        //## end command::TemplateToken::setLengthAttribute%4F71747200BE.set
      }


      //## Attribute: LengthType%4F71B15A0210
      const char getLengthType () const
      {
        //## begin command::TemplateToken::getLengthType%4F71B15A0210.get preserve=no
        return m_cLengthType;
        //## end command::TemplateToken::getLengthType%4F71B15A0210.get
      }

      void setLengthType (char value)
      {
        //## begin command::TemplateToken::setLengthType%4F71B15A0210.set preserve=no
        m_cLengthType = value;
        //## end command::TemplateToken::setLengthType%4F71B15A0210.set
      }


      //## Attribute: Name%4F4502CA014E
      const string& getName () const
      {
        //## begin command::TemplateToken::getName%4F4502CA014E.get preserve=no
        return m_strName;
        //## end command::TemplateToken::getName%4F4502CA014E.get
      }

      void setName (const string& value)
      {
        //## begin command::TemplateToken::setName%4F4502CA014E.set preserve=no
        m_strName = value;
        //## end command::TemplateToken::setName%4F4502CA014E.set
      }


      //## Attribute: Offset%4F4502BB0027
      const int getOffset () const
      {
        //## begin command::TemplateToken::getOffset%4F4502BB0027.get preserve=no
        return m_iOffset;
        //## end command::TemplateToken::getOffset%4F4502BB0027.get
      }

      void setOffset (int value)
      {
        //## begin command::TemplateToken::setOffset%4F4502BB0027.set preserve=no
        m_iOffset = value;
        //## end command::TemplateToken::setOffset%4F4502BB0027.set
      }


      //## Attribute: Signed%5B72F2D10305
      const bool getSigned () const
      {
        //## begin command::TemplateToken::getSigned%5B72F2D10305.get preserve=no
        return m_bSigned;
        //## end command::TemplateToken::getSigned%5B72F2D10305.get
      }

      void setSigned (bool value)
      {
        //## begin command::TemplateToken::setSigned%5B72F2D10305.set preserve=no
        m_bSigned = value;
        //## end command::TemplateToken::setSigned%5B72F2D10305.set
      }


      //## Attribute: Size%4F450CC903BC
      const int getSize () const
      {
        //## begin command::TemplateToken::getSize%4F450CC903BC.get preserve=no
        return m_iSize;
        //## end command::TemplateToken::getSize%4F450CC903BC.get
      }

      void setSize (int value)
      {
        //## begin command::TemplateToken::setSize%4F450CC903BC.set preserve=no
        m_iSize = value;
        //## end command::TemplateToken::setSize%4F450CC903BC.set
      }


      //## Attribute: Table%5A61EDBC02EA
      const string& getTable () const
      {
        //## begin command::TemplateToken::getTable%5A61EDBC02EA.get preserve=no
        return m_strTable;
        //## end command::TemplateToken::getTable%5A61EDBC02EA.get
      }

      void setTable (const string& value)
      {
        //## begin command::TemplateToken::setTable%5A61EDBC02EA.set preserve=no
        m_strTable = value;
        //## end command::TemplateToken::setTable%5A61EDBC02EA.set
      }


      //## Attribute: Trim%4FEC96360316
      const bool getTrim () const
      {
        //## begin command::TemplateToken::getTrim%4FEC96360316.get preserve=no
        return m_bTrim;
        //## end command::TemplateToken::getTrim%4FEC96360316.get
      }

      void setTrim (bool value)
      {
        //## begin command::TemplateToken::setTrim%4FEC96360316.set preserve=no
        m_bTrim = value;
        //## end command::TemplateToken::setTrim%4FEC96360316.set
      }


      //## Attribute: Type%4F450C9F0224
      const char getType () const
      {
        //## begin command::TemplateToken::getType%4F450C9F0224.get preserve=no
        return m_cType;
        //## end command::TemplateToken::getType%4F450C9F0224.get
      }

      void setType (char value)
      {
        //## begin command::TemplateToken::setType%4F450C9F0224.set preserve=no
        m_cType = value;
        //## end command::TemplateToken::setType%4F450C9F0224.set
      }


      //## Attribute: VarChar%5AF44703002A
      const bool getVarChar () const
      {
        //## begin command::TemplateToken::getVarChar%5AF44703002A.get preserve=no
        return m_bVarChar;
        //## end command::TemplateToken::getVarChar%5AF44703002A.get
      }

      void setVarChar (bool value)
      {
        //## begin command::TemplateToken::setVarChar%5AF44703002A.set preserve=no
        m_bVarChar = value;
        //## end command::TemplateToken::setVarChar%5AF44703002A.set
      }


      //## Attribute: XMLTag%6463592B024B
      const string& getXMLTag () const
      {
        //## begin command::TemplateToken::getXMLTag%6463592B024B.get preserve=no
        return m_strXMLTag;
        //## end command::TemplateToken::getXMLTag%6463592B024B.get
      }

      void setXMLTag (const string& value)
      {
        //## begin command::TemplateToken::setXMLTag%6463592B024B.set preserve=no
        m_strXMLTag = value;
        //## end command::TemplateToken::setXMLTag%6463592B024B.set
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::Command_CAT::<unnamed>%4FE4D225030E
      //## Role: TemplateToken::<m_pSegment>%4FE4D22601B1
      segment::Segment * getSegment ()
      {
        //## begin command::TemplateToken::getSegment%4FE4D22601B1.get preserve=no
        return m_pSegment;
        //## end command::TemplateToken::getSegment%4FE4D22601B1.get
      }


    // Additional Public Declarations
      //## begin command::TemplateToken%4F44F17E033D.public preserve=yes
      //## end command::TemplateToken%4F44F17E033D.public

  protected:
    // Additional Protected Declarations
      //## begin command::TemplateToken%4F44F17E033D.protected preserve=yes
      //## end command::TemplateToken%4F44F17E033D.protected

  private:
    // Data Members for Class Attributes

      //## begin command::TemplateToken::XMLTag%6463592B024B.attr preserve=no  public: string {U} 
      string m_strXMLTag;
      //## end command::TemplateToken::XMLTag%6463592B024B.attr

    // Additional Private Declarations
      //## begin command::TemplateToken%4F44F17E033D.private preserve=yes
      //## end command::TemplateToken%4F44F17E033D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::TemplateToken::Address%4F450CAC0097.attr preserve=no  public: void* {V} 0
      void* m_pAddress;
      //## end command::TemplateToken::Address%4F450CAC0097.attr

      //## begin command::TemplateToken::FunctionName%63C7711C017A.attr preserve=no  public: string {V} 
      string m_strFunctionName;
      //## end command::TemplateToken::FunctionName%63C7711C017A.attr

      //## begin command::TemplateToken::HexToChar%5A61EDC60213.attr preserve=no  public: bool {V} false
      bool m_bHexToChar;
      //## end command::TemplateToken::HexToChar%5A61EDC60213.attr

      //## begin command::TemplateToken::Index%5A61EDAF01EB.attr preserve=no  public: int {V} 0
      int m_iIndex;
      //## end command::TemplateToken::Index%5A61EDAF01EB.attr

      //## begin command::TemplateToken::Length%4F4502BB0116.attr preserve=no  public: int {V} 0
      int m_iLength;
      //## end command::TemplateToken::Length%4F4502BB0116.attr

      //## begin command::TemplateToken::LengthAttribute%4F71747200BE.attr preserve=no  public: string {V} 
      string m_strLengthAttribute;
      //## end command::TemplateToken::LengthAttribute%4F71747200BE.attr

      //## begin command::TemplateToken::LengthType%4F71B15A0210.attr preserve=no  public: char {V} ' '
      char m_cLengthType;
      //## end command::TemplateToken::LengthType%4F71B15A0210.attr

      //## begin command::TemplateToken::Name%4F4502CA014E.attr preserve=no  public: string {V} 
      string m_strName;
      //## end command::TemplateToken::Name%4F4502CA014E.attr

      //## begin command::TemplateToken::Offset%4F4502BB0027.attr preserve=no  public: int {V} 0
      int m_iOffset;
      //## end command::TemplateToken::Offset%4F4502BB0027.attr

      //## begin command::TemplateToken::Signed%5B72F2D10305.attr preserve=no  public: bool {V} true
      bool m_bSigned;
      //## end command::TemplateToken::Signed%5B72F2D10305.attr

      //## begin command::TemplateToken::Size%4F450CC903BC.attr preserve=no  public: int {V} 0
      int m_iSize;
      //## end command::TemplateToken::Size%4F450CC903BC.attr

      //## begin command::TemplateToken::Table%5A61EDBC02EA.attr preserve=no  public: string {V} 
      string m_strTable;
      //## end command::TemplateToken::Table%5A61EDBC02EA.attr

      //## begin command::TemplateToken::Trim%4FEC96360316.attr preserve=no  public: bool {U} false
      bool m_bTrim;
      //## end command::TemplateToken::Trim%4FEC96360316.attr

      //## begin command::TemplateToken::Type%4F450C9F0224.attr preserve=no  public: char {V} ' '
      char m_cType;
      //## end command::TemplateToken::Type%4F450C9F0224.attr

      //## begin command::TemplateToken::VarChar%5AF44703002A.attr preserve=no  public: bool {V} false
      bool m_bVarChar;
      //## end command::TemplateToken::VarChar%5AF44703002A.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%4FE4D225030E
      //## begin command::TemplateToken::<m_pSegment>%4FE4D22601B1.role preserve=no  public: segment::Segment { -> RFHgN}
      segment::Segment *m_pSegment;
      //## end command::TemplateToken::<m_pSegment>%4FE4D22601B1.role

    // Additional Implementation Declarations
      //## begin command::TemplateToken%4F44F17E033D.implementation preserve=yes
      //## end command::TemplateToken%4F44F17E033D.implementation

};

//## begin command::TemplateToken%4F44F17E033D.postscript preserve=yes
//## end command::TemplateToken%4F44F17E033D.postscript

} // namespace command

//## begin module%4F44F3C7027F.epilog preserve=yes
using namespace command;
//## end module%4F44F3C7027F.epilog


#endif
