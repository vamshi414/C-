//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3922DECF01D4.cm preserve=no
//	$Date:   Nov 07 2016 04:02:16  $ $Author:   e3027760  $ $Revision:   1.5  $
//## end module%3922DECF01D4.cm

//## begin module%3922DECF01D4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3922DECF01D4.cp

//## Module: CXOSBC02%3922DECF01D4; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\ConnexPlatform\Server\Library\Bcdll\CXODBC02.hpp

#ifndef CXOSBC02_h
#define CXOSBC02_h 1

//## begin module%3922DECF01D4.additionalIncludes preserve=no
//## end module%3922DECF01D4.additionalIncludes

//## begin module%3922DECF01D4.includes preserve=yes
// $Date:   Nov 07 2016 04:02:16  $ $Author:   e3027760  $ $Revision:   1.5  $
//## end module%3922DECF01D4.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Row;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class GlobalContext;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ResponseTimeSegment;
class MultipleRowContextSegment;
class CommonHeaderSegment;
class InformationSegment;

} // namespace segment

//## begin module%3922DECF01D4.declarations preserve=no
//## end module%3922DECF01D4.declarations

//## begin module%3922DECF01D4.additionalDeclarations preserve=yes
//## end module%3922DECF01D4.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::ClientListCommand%3922DC500301.preface preserve=yes
//## end command::ClientListCommand%3922DC500301.preface

//## Class: ClientListCommand%3922DC500301
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3922DE3D018E;IF::Message { -> F}
//## Uses: <unnamed>%3922DE4D0169;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%3922DE6C01BD;segment::InformationSegment { -> F}
//## Uses: <unnamed>%39293D2703CA;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%3A3F962E03B2;monitor::UseCase { -> F}
//## Uses: <unnamed>%581C550C03AA;database::Database { -> F}

class DllExport ClientListCommand : public ClientCommand  //## Inherits: <unnamed>%3922DC6A0150
{
  //## begin command::ClientListCommand%3922DC500301.initialDeclarations preserve=yes
  //## end command::ClientListCommand%3922DC500301.initialDeclarations

  public:
    //## Constructors (generated)
      ClientListCommand();

    //## Constructors (specified)
      //## Operation: ClientListCommand%39DA369401F4
      ClientListCommand (const char* pszMessageID, const char* pszQueue = 0, bool bCache = true);

    //## Destructor (generated)
      virtual ~ClientListCommand();


    //## Other Operations (specified)
      //## Operation: execute%3922DCE70268
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: update%3922DCF30099
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

      //## Operation: sendError%581C41D50039
      int sendError (int iResultCode, char sSeverityLevel, int lInfoIDNumber, bool bReset = true, const char* pszText = 0);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Count%3922DD540297
      const int getCount () const
      {
        //## begin command::ClientListCommand::getCount%3922DD540297.get preserve=no
        return m_lCount;
        //## end command::ClientListCommand::getCount%3922DD540297.get
      }


      //## Attribute: TotalRecordsFound%3922E0B702EE
      const int getTotalRecordsFound () const
      {
        //## begin command::ClientListCommand::getTotalRecordsFound%3922E0B702EE.get preserve=no
        return m_lTotalRecordsFound;
        //## end command::ClientListCommand::getTotalRecordsFound%3922E0B702EE.get
      }


    // Data Members for Class Attributes

      //## Attribute: MRC%3922DD510293
      //## begin command::ClientListCommand::MRC%3922DD510293.attr preserve=no  private: char* {V} 
      char* m_pMRC;
      //## end command::ClientListCommand::MRC%3922DD510293.attr

    // Additional Public Declarations
      //## begin command::ClientListCommand%3922DC500301.public preserve=yes
      //## end command::ClientListCommand%3922DC500301.public

  protected:

    //## Other Operations (specified)
      //## Operation: exportList%3B8FB0D10280
      virtual void exportList ();

      //## Operation: retrieve%3922E25A012E
      virtual bool retrieve () = 0;

      //## Operation: sendMessage%3922DD200166
      void sendMessage ();

      //## Operation: updateList%3B8FB0D900CB
      virtual void updateList ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Cache%39DA27880368
      const bool getCache () const
      {
        //## begin command::ClientListCommand::getCache%39DA27880368.get preserve=no
        return m_bCache;
        //## end command::ClientListCommand::getCache%39DA27880368.get
      }

      void setCache (bool value)
      {
        //## begin command::ClientListCommand::setCache%39DA27880368.set preserve=no
        m_bCache = value;
        //## end command::ClientListCommand::setCache%39DA27880368.set
      }


    // Data Members for Class Attributes

      //## begin command::ClientListCommand::Count%3922DD540297.attr preserve=no  public: int {V} 0
      int m_lCount;
      //## end command::ClientListCommand::Count%3922DD540297.attr

      //## begin command::ClientListCommand::TotalRecordsFound%3922E0B702EE.attr preserve=no  public: int {V} 0
      int m_lTotalRecordsFound;
      //## end command::ClientListCommand::TotalRecordsFound%3922E0B702EE.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%3922DDBB0118
      //## Role: ClientListCommand::<m_pMultipleRowContextSegment>%3922DDBC0020
      //## begin command::ClientListCommand::<m_pMultipleRowContextSegment>%3922DDBC0020.role preserve=no  public: segment::MultipleRowContextSegment { -> RFHgN}
      segment::MultipleRowContextSegment *m_pMultipleRowContextSegment;
      //## end command::ClientListCommand::<m_pMultipleRowContextSegment>%3922DDBC0020.role

      //## Association: Connex Library::Command_CAT::<unnamed>%3922DDE102EA
      //## Role: ClientListCommand::<m_pRow>%3922DDE20133
      //## begin command::ClientListCommand::<m_pRow>%3922DDE20133.role preserve=no  public: reusable::Row { -> RFHgN}
      reusable::Row *m_pRow;
      //## end command::ClientListCommand::<m_pRow>%3922DDE20133.role

      //## Association: Connex Library::Command_CAT::<unnamed>%39DA26510108
      //## Role: ClientListCommand::<m_hQuery>%39DA26520181
      //## begin command::ClientListCommand::<m_hQuery>%39DA26520181.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end command::ClientListCommand::<m_hQuery>%39DA26520181.role

    // Additional Protected Declarations
      //## begin command::ClientListCommand%3922DC500301.protected preserve=yes
      //## end command::ClientListCommand%3922DC500301.protected

  private:
    // Additional Private Declarations
      //## begin command::ClientListCommand%3922DC500301.private preserve=yes
      //## end command::ClientListCommand%3922DC500301.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::ClientListCommand::Cache%39DA27880368.attr preserve=no  protected: bool {V} 
      bool m_bCache;
      //## end command::ClientListCommand::Cache%39DA27880368.attr

      //## Attribute: List%3922DD4D02FB
      //## begin command::ClientListCommand::List%3922DD4D02FB.attr preserve=no  private: char* {V} 
      char* m_pList;
      //## end command::ClientListCommand::List%3922DD4D02FB.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%3922DD99023C
      //## Role: ClientListCommand::<m_hListSegment>%3922DD9A012F
      //## begin command::ClientListCommand::<m_hListSegment>%3922DD9A012F.role preserve=no  public: segment::ListSegment { -> VHgN}
      segment::ListSegment m_hListSegment;
      //## end command::ClientListCommand::<m_hListSegment>%3922DD9A012F.role

      //## Association: Connex Library::Command_CAT::<unnamed>%581C583701F4
      //## Role: ClientListCommand::<m_pGlobalContext>%581C583801AD
      //## begin command::ClientListCommand::<m_pGlobalContext>%581C583801AD.role preserve=no  public: static database::GlobalContext {1 -> 2UFHgN}
      static database::GlobalContext m_pGlobalContext[2];
      //## end command::ClientListCommand::<m_pGlobalContext>%581C583801AD.role

    // Additional Implementation Declarations
      //## begin command::ClientListCommand%3922DC500301.implementation preserve=yes
      //## end command::ClientListCommand%3922DC500301.implementation

};

//## begin command::ClientListCommand%3922DC500301.postscript preserve=yes
//## end command::ClientListCommand%3922DC500301.postscript

} // namespace command

//## begin module%3922DECF01D4.epilog preserve=yes
using namespace command;
//## end module%3922DECF01D4.epilog


#endif
