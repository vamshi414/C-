//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64DFD4B400DA.cm preserve=no
//## end module%64DFD4B400DA.cm

//## begin module%64DFD4B400DA.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64DFD4B400DA.cp

//## Module: CXOSBC65%64DFD4B400DA; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC65.hpp

#ifndef CXOSBC65_h
#define CXOSBC65_h 1

//## begin module%64DFD4B400DA.additionalIncludes preserve=no
//## end module%64DFD4B400DA.additionalIncludes

//## begin module%64DFD4B400DA.includes preserve=yes
//## end module%64DFD4B400DA.includes

#ifndef CXOSBC36_h
#include "CXODBC36.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Format;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class TextSegment;
class CommonHeaderSegment;
class SOAPSegment;

} // namespace segment

//## begin module%64DFD4B400DA.declarations preserve=no
//## end module%64DFD4B400DA.declarations

//## begin module%64DFD4B400DA.additionalDeclarations preserve=yes
//## end module%64DFD4B400DA.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::RESTCommand%64DFD44D0066.preface preserve=yes
//## end command::RESTCommand%64DFD44D0066.preface

//## Class: RESTCommand%64DFD44D0066
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%651ADB2A0352;IF::Message { -> F}
//## Uses: <unnamed>%653F212001DE;reusable::Format { -> F}
//## Uses: <unnamed>%653F216B0186;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%653FA81802F8;segment::TextSegment { -> F}
//## Uses: <unnamed>%653FA9910358;segment::CommonHeaderSegment { -> F}

class DllExport RESTCommand : public SOAPCommand  //## Inherits: <unnamed>%64DFD4630233
{
  //## begin command::RESTCommand%64DFD44D0066.initialDeclarations preserve=yes
  //## end command::RESTCommand%64DFD44D0066.initialDeclarations

  public:
    //## Constructors (generated)
      RESTCommand();

    //## Constructors (specified)
      //## Operation: RESTCommand%64DFD5FF00B3
      RESTCommand (const char* pszURL, const char* pszMessageID, const char* pszQueue = 0);

    //## Destructor (generated)
      virtual ~RESTCommand();


    //## Other Operations (specified)
      //## Operation: parse%653FA6E200A2
      virtual int parse ();

      //## Operation: publishURL%651ADA52011D
      virtual void publishURL ();

      //## Operation: reply%653F1FE501EF
      virtual int reply ();

      //## Operation: update%653FC2EE03CF
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin command::RESTCommand%64DFD44D0066.public preserve=yes
      //## end command::RESTCommand%64DFD44D0066.public

  protected:
    // Additional Protected Declarations
      //## begin command::RESTCommand%64DFD44D0066.protected preserve=yes
      //## end command::RESTCommand%64DFD44D0066.protected

  private:
    // Additional Private Declarations
      //## begin command::RESTCommand%64DFD44D0066.private preserve=yes
      //## end command::RESTCommand%64DFD44D0066.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: URL%64DFD68B024B
      //## begin command::RESTCommand::URL%64DFD68B024B.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strURL;
      //## end command::RESTCommand::URL%64DFD68B024B.attr

    // Additional Implementation Declarations
      //## begin command::RESTCommand%64DFD44D0066.implementation preserve=yes
      //## end command::RESTCommand%64DFD44D0066.implementation

};

//## begin command::RESTCommand%64DFD44D0066.postscript preserve=yes
//## end command::RESTCommand%64DFD44D0066.postscript

} // namespace command

//## begin module%64DFD4B400DA.epilog preserve=yes
//## end module%64DFD4B400DA.epilog


#endif
