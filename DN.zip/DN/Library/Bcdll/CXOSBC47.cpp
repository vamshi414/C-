//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5625F0DD0079.cm preserve=no
//	$Date:   May 24 2016 11:03:14  $ $Author:   e1009510  $ $Revision:   1.0  $
//## end module%5625F0DD0079.cm

//## begin module%5625F0DD0079.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5625F0DD0079.cp

//## Module: CXOSBC47%5625F0DD0079; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC47.cpp

//## begin module%5625F0DD0079.additionalIncludes preserve=no
//## end module%5625F0DD0079.additionalIncludes

//## begin module%5625F0DD0079.includes preserve=yes
//## end module%5625F0DD0079.includes

#ifndef CXOSBC47_h
#include "CXODBC47.hpp"
#endif
//## begin module%5625F0DD0079.declarations preserve=no
//## end module%5625F0DD0079.declarations

//## begin module%5625F0DD0079.additionalDeclarations preserve=yes
//## end module%5625F0DD0079.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::Criteria 

Criteria::Criteria()
  //## begin Criteria::Criteria%5625F06B0359_const.hasinit preserve=no
  //## end Criteria::Criteria%5625F06B0359_const.hasinit
  //## begin Criteria::Criteria%5625F06B0359_const.initialization preserve=yes
  //## end Criteria::Criteria%5625F06B0359_const.initialization
{
  //## begin command::Criteria::Criteria%5625F06B0359_const.body preserve=yes
   memcpy(m_sID,"BC47",4);
  //## end command::Criteria::Criteria%5625F06B0359_const.body
}


Criteria::~Criteria()
{
  //## begin command::Criteria::~Criteria%5625F06B0359_dest.body preserve=yes
  //## end command::Criteria::~Criteria%5625F06B0359_dest.body
}



//## Other Operations (implementation)
void Criteria::addCriteriaData (const CriteriaData& hCriteriaData)
{
  //## begin command::Criteria::addCriteriaData%5628B89E01E5.body preserve=yes
   m_hCriteriaData.push_back(hCriteriaData);
  //## end command::Criteria::addCriteriaData%5628B89E01E5.body
}

void Criteria::addResult (const string& strAttribute, const string& strValue)
{
  //## begin command::Criteria::addResult%5628B982037C.body preserve=yes
   m_hResult.push_back(make_pair(strAttribute,strValue));
  //## end command::Criteria::addResult%5628B982037C.body
}

void Criteria::clear ()
{
  //## begin command::Criteria::clear%5628B11A00B8.body preserve=yes
   m_hCriteriaData.clear();
   m_hResult.clear();
  //## end command::Criteria::clear%5628B11A00B8.body
}

vector<CriteriaData>& Criteria::getCriteriaData ()
{
  //## begin command::Criteria::getCriteriaData%5628EDA00328.body preserve=yes
   return m_hCriteriaData;
  //## end command::Criteria::getCriteriaData%5628EDA00328.body
}

vector<pair<string,string> >& Criteria::getResult ()
{
  //## begin command::Criteria::getResult%5628EDDF032E.body preserve=yes
   return m_hResult;
  //## end command::Criteria::getResult%5628EDDF032E.body
}

// Additional Declarations
  //## begin command::Criteria%5625F06B0359.declarations preserve=yes
  //## end command::Criteria%5625F06B0359.declarations

} // namespace command

//## begin module%5625F0DD0079.epilog preserve=yes
//## end module%5625F0DD0079.epilog
