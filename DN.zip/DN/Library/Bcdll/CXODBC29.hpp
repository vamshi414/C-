//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4ADF0B8901A5.cm preserve=no
//	$Date:   May 26 2021 13:45:12  $ $Author:   e5549623  $
//	$Revision:   1.18  $
//## end module%4ADF0B8901A5.cm

//## begin module%4ADF0B8901A5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4ADF0B8901A5.cp

//## Module: CXOSBC29%4ADF0B8901A5; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.7A.R009\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC29.hpp

#ifndef CXOSBC29_h
#define CXOSBC29_h 1

//## begin module%4ADF0B8901A5.additionalIncludes preserve=no
//## end module%4ADF0B8901A5.additionalIncludes

//## begin module%4ADF0B8901A5.includes preserve=yes
//## end module%4ADF0B8901A5.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSBC15_h
#include "CXODBC15.hpp"
#endif
//## begin module%4ADF0B8901A5.declarations preserve=no
//## end module%4ADF0B8901A5.declarations

//## begin module%4ADF0B8901A5.additionalDeclarations preserve=yes
//## end module%4ADF0B8901A5.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::Event%4ADF0637008C.preface preserve=yes
//## end command::Event%4ADF0637008C.preface

//## Class: Event%4ADF0637008C
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4B2704D0032C;XMLDocument { -> }

class DllExport Event : public reusable::Object  //## Inherits: <unnamed>%4ADF06650196
{
  //## begin command::Event%4ADF0637008C.initialDeclarations preserve=yes
  //## end command::Event%4ADF0637008C.initialDeclarations

  public:
    //## Constructors (generated)
      Event();

    //## Destructor (generated)
      virtual ~Event();


    //## Other Operations (specified)
      //## Operation: accept%4B7AF5890028
      virtual void accept ();

      //## Operation: addRechainInformation%542D90AC0005
      virtual void addRechainInformation ();

      //## Operation: deport%4B26F6900128
      virtual bool deport (command::XMLDocument* pXMLDocument);

      //## Operation: import%4ADF064B03A9
      virtual bool import ();

      //## Operation: matchCase%4C533935035A
      virtual bool matchCase ();

      //## Operation: reject%4B7AF5A401A9
      virtual void reject ();

      //## Operation: setCASE_TYPE_IND%4BB6AED0001D
      virtual void setCASE_TYPE_IND ();

      //## Operation: setREASON_CODE%53AAD24F025C
      virtual void setREASON_CODE ();

      //## Operation: setREQUEST_TYPE_NEXT%4B990FE90370
      virtual void setREQUEST_TYPE_NEXT ();

      //## Operation: setSTATUS_NEXT%4B9910050227
      virtual void setSTATUS_NEXT ();

      //## Operation: unmatchedImport%4B98FF800196
      virtual bool unmatchedImport ();

      //## Operation: trigger%537A25CB02E6
      virtual bool trigger ();

      //## Operation: UpdateDocExportInd%57F2C0210309
      virtual bool UpdateDocExportInd (char cEXPORT_IND = 'N');

    // Additional Public Declarations
      //## begin command::Event%4ADF0637008C.public preserve=yes
      virtual bool sendRequest();
      //## end command::Event%4ADF0637008C.public

  protected:
    // Additional Protected Declarations
      //## begin command::Event%4ADF0637008C.protected preserve=yes
      //## end command::Event%4ADF0637008C.protected

  private:
    // Additional Private Declarations
      //## begin command::Event%4ADF0637008C.private preserve=yes
      //## end command::Event%4ADF0637008C.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin command::Event%4ADF0637008C.implementation preserve=yes
      //## end command::Event%4ADF0637008C.implementation

};

//## begin command::Event%4ADF0637008C.postscript preserve=yes
//## end command::Event%4ADF0637008C.postscript

} // namespace command

//## begin module%4ADF0B8901A5.epilog preserve=yes
//## end module%4ADF0B8901A5.epilog


#endif
