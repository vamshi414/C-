//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%588D08DA00B8.cm preserve=no
//	$Date:   Jan 15 2021 16:12:50  $ $Author:   e1094689  $ $Revision:   1.3  $
//## end module%588D08DA00B8.cm

//## begin module%588D08DA00B8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%588D08DA00B8.cp

//## Module: CXOSBC53%588D08DA00B8; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.8A.R005\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC53.hpp

#ifndef CXOSBC53_h
#define CXOSBC53_h 1

//## begin module%588D08DA00B8.additionalIncludes preserve=no
//## end module%588D08DA00B8.additionalIncludes

//## begin module%588D08DA00B8.includes preserve=yes
#include <vector>
//## end module%588D08DA00B8.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSBC54_h
#include "CXODBC54.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
class FormatSelectVisitor;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class Timer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%588D08DA00B8.declarations preserve=no
//## end module%588D08DA00B8.declarations

//## begin module%588D08DA00B8.additionalDeclarations preserve=yes
//## end module%588D08DA00B8.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::APIImport%588D083702CC.preface preserve=yes
//## end command::APIImport%588D083702CC.preface

//## Class: APIImport%588D083702CC
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%588D0F230252;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%588D0F350003;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%588D0F4400E8;reusable::Query { -> F}
//## Uses: <unnamed>%5898822F01E0;process::Application { -> F}
//## Uses: <unnamed>%5898823A036B;timer::Clock { -> F}
//## Uses: <unnamed>%58A0D48B0216;APIImportRecord { -> }
//## Uses: <unnamed>%5A81A70202D1;reusable::FormatSelectVisitor { -> F}

class DllExport APIImport : public reusable::Observer  //## Inherits: <unnamed>%588D0891016D
{
  //## begin command::APIImport%588D083702CC.initialDeclarations preserve=yes
  //## end command::APIImport%588D083702CC.initialDeclarations

  public:
    //## Constructors (generated)
      APIImport();

    //## Destructor (generated)
      virtual ~APIImport();


    //## Other Operations (specified)
      //## Operation: add%588D0DCB0249
      void add (const string& strAPI_TYPE, command::APIImportRecord* pAPIImportRecord);

      //## Operation: instance%589B420500B0
      static APIImport* instance ();

      //## Operation: onResume%588D0E0A0357
      void onResume ();

      //## Operation: update%589784550331
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: DATA_BUFFER%589788570318
      const string& getDATA_BUFFER () const
      {
        //## begin command::APIImport::getDATA_BUFFER%589788570318.get preserve=no
        return m_strDATA_BUFFER;
        //## end command::APIImport::getDATA_BUFFER%589788570318.get
      }

      void setDATA_BUFFER (const string& value)
      {
        //## begin command::APIImport::setDATA_BUFFER%589788570318.set preserve=no
        m_strDATA_BUFFER = value;
        //## end command::APIImport::setDATA_BUFFER%589788570318.set
      }


      //## Attribute: EndingDATA_BUFFER%5897896E01C2
      const string& getEndingDATA_BUFFER () const
      {
        //## begin command::APIImport::getEndingDATA_BUFFER%5897896E01C2.get preserve=no
        return m_strEndingDATA_BUFFER;
        //## end command::APIImport::getEndingDATA_BUFFER%5897896E01C2.get
      }

      void setEndingDATA_BUFFER (const string& value)
      {
        //## begin command::APIImport::setEndingDATA_BUFFER%5897896E01C2.set preserve=no
        m_strEndingDATA_BUFFER = value;
        //## end command::APIImport::setEndingDATA_BUFFER%5897896E01C2.set
      }


    // Additional Public Declarations
      //## begin command::APIImport%588D083702CC.public preserve=yes
      //## end command::APIImport%588D083702CC.public

  protected:
    // Additional Protected Declarations
      //## begin command::APIImport%588D083702CC.protected preserve=yes
      //## end command::APIImport%588D083702CC.protected

  private:
    // Additional Private Declarations
      //## begin command::APIImport%588D083702CC.private preserve=yes
      //## end command::APIImport%588D083702CC.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: APIImportRecord%588D0CD603A7
      //## begin command::APIImport::APIImportRecord%588D0CD603A7.attr preserve=no  public: static map<string, APIImportRecord*, less<string> >* {V} 0
      static map<string, APIImportRecord*, less<string> >* m_pAPIImportRecord;
      //## end command::APIImport::APIImportRecord%588D0CD603A7.attr

      //## begin command::APIImport::DATA_BUFFER%589788570318.attr preserve=no  public: string {U} 
      string m_strDATA_BUFFER;
      //## end command::APIImport::DATA_BUFFER%589788570318.attr

      //## begin command::APIImport::EndingDATA_BUFFER%5897896E01C2.attr preserve=no  public: string {U} 
      string m_strEndingDATA_BUFFER;
      //## end command::APIImport::EndingDATA_BUFFER%5897896E01C2.attr

      //## Attribute: hAPIImportRecord%58A0D4B9017C
      //## begin command::APIImport::hAPIImportRecord%58A0D4B9017C.attr preserve=no  private: command::APIImportRecord {U} 
      command::APIImportRecord m_hAPIImportRecord;
      //## end command::APIImport::hAPIImportRecord%58A0D4B9017C.attr

      //## Attribute: Instance%589B422F0120
      //## begin command::APIImport::Instance%589B422F0120.attr preserve=no  private: static APIImport* {V} 0
      static APIImport* m_pInstance;
      //## end command::APIImport::Instance%589B422F0120.attr

      //## Attribute: Timer%58A44BB8029E
      //## begin command::APIImport::Timer%58A44BB8029E.attr preserve=no  private: static int {V} 30
      static int m_iTimer;
      //## end command::APIImport::Timer%58A44BB8029E.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%58A449C602B6
      //## Role: APIImport::<m_pTimer>%58A449C7022C
      //## begin command::APIImport::<m_pTimer>%58A449C7022C.role preserve=no  public: static timer::Timer { -> RFHgN}
      static timer::Timer *m_pTimer;
      //## end command::APIImport::<m_pTimer>%58A449C7022C.role

    // Additional Implementation Declarations
      //## begin command::APIImport%588D083702CC.implementation preserve=yes
      vector<int> m_hQueueID;
      int m_iQUEUE_ID;
      //## end command::APIImport%588D083702CC.implementation

};

//## begin command::APIImport%588D083702CC.postscript preserve=yes
//## end command::APIImport%588D083702CC.postscript

} // namespace command

//## begin module%588D08DA00B8.epilog preserve=yes
//## end module%588D08DA00B8.epilog


#endif
