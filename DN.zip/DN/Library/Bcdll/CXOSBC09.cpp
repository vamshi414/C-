//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%36DF007300F1.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DF007300F1.cm

//## begin module%36DF007300F1.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DF007300F1.cp

//## Module: CXOSBC09%36DF007300F1; Package body
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC09.cpp

//## begin module%36DF007300F1.additionalIncludes preserve=no
//## end module%36DF007300F1.additionalIncludes

//## begin module%36DF007300F1.includes preserve=yes
// $Date:   May 14 2020 16:29:54  $ $Author:   e1009510  $ $Revision:   1.5  $
#include <stdio.h>
#include "CXODUS12.hpp"
//## end module%36DF007300F1.includes

#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSBC09_h
#include "CXODBC09.hpp"
#endif


//## begin module%36DF007300F1.declarations preserve=no
//## end module%36DF007300F1.declarations

//## begin module%36DF007300F1.additionalDeclarations preserve=yes
//## end module%36DF007300F1.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::GetProfileCommand 

GetProfileCommand::GetProfileCommand()
  //## begin GetProfileCommand::GetProfileCommand%346475AF0080_const.hasinit preserve=no
      : m_lRecordsReturnedThisMessage(0),
        m_lTotalRecordsFound(0)
  //## end GetProfileCommand::GetProfileCommand%346475AF0080_const.hasinit
  //## begin GetProfileCommand::GetProfileCommand%346475AF0080_const.initialization preserve=yes
   ,ClientCommand("S0005D","@GETUSER")
  //## end GetProfileCommand::GetProfileCommand%346475AF0080_const.initialization
{
  //## begin command::GetProfileCommand::GetProfileCommand%346475AF0080_const.body preserve=yes
   memcpy_s(m_sID,4,"UC01",4);
   m_pMultipleRowContextSegment = new MultipleRowContextSegment();
   m_hSegments.push_back(m_pMultipleRowContextSegment);
   m_hQuery.attach(this);
  //## end command::GetProfileCommand::GetProfileCommand%346475AF0080_const.body
}

GetProfileCommand::GetProfileCommand (Handler* pSuccessor)
  //## begin command::GetProfileCommand::GetProfileCommand%3E96B3E30109.hasinit preserve=no
      : m_lRecordsReturnedThisMessage(0),
        m_lTotalRecordsFound(0)
  //## end command::GetProfileCommand::GetProfileCommand%3E96B3E30109.hasinit
  //## begin command::GetProfileCommand::GetProfileCommand%3E96B3E30109.initialization preserve=yes
   ,ClientCommand("S0005D","@GETUSER")
  //## end command::GetProfileCommand::GetProfileCommand%3E96B3E30109.initialization
{
  //## begin command::GetProfileCommand::GetProfileCommand%3E96B3E30109.body preserve=yes
   memcpy_s(m_sID,4,"UC01",4);
   m_pSuccessor = pSuccessor;
   m_pMultipleRowContextSegment = new MultipleRowContextSegment();
   m_hSegments.push_back(m_pMultipleRowContextSegment);
   m_hQuery.attach(this);
  //## end command::GetProfileCommand::GetProfileCommand%3E96B3E30109.body
}


GetProfileCommand::~GetProfileCommand()
{
  //## begin command::GetProfileCommand::~GetProfileCommand%346475AF0080_dest.body preserve=yes
   delete m_pMultipleRowContextSegment;
  //## end command::GetProfileCommand::~GetProfileCommand%346475AF0080_dest.body
}



//## Other Operations (implementation)
bool GetProfileCommand::execute ()
{
  //## begin command::GetProfileCommand::execute%394918C50228.body preserve=yes
   // CL09: Client_Gets_User_Security_Data
   UseCase hUseCase("CLIENT","## CL09 GET USER SECURITY DATA");
   int iRC;
   if ((iRC = parse()) != 0)
   {
      UseCase::setSuccess(false);
      return iRC;
   }
   string strCustomerID = string(m_pMultipleRowContextSegment->STSContextData().subString(9,4));
   m_lRecordsReturnedThisMessage = 0; 
   m_lTotalRecordsFound = 0;
   Message::instance(Message::INBOUND)->reset("CRQCI ", "S0005R");
   m_pDataBuffer = Message::instance(Message::INBOUND)->data() + 8;
   CommonHeaderSegment::instance()->deport(&m_pDataBuffer);
   char* pMRC = m_pDataBuffer;
   m_pMultipleRowContextSegment->deport(&m_pDataBuffer);
   segProfileSegment *pProfileSegment = (segProfileSegment*) m_pDataBuffer;
   m_hProfileSegment.deport(&m_pDataBuffer);
   m_hQuery.reset();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery.setQualifier("QUALIFY","AS_USER_PROFILE");
   m_hQuery.setQualifier("QUALIFY","AS_PROFILE_ENTRY");
   m_hProfileSegment.bind(m_hQuery);
   m_hQuery.setBasicPredicate("AS_USER_PROFILE","CUST_ID","=",strCustomerID.c_str());
   pSelectStatement->execute(m_hQuery);
   m_pMultipleRowContextSegment->setTotalRecordsFound(m_lTotalRecordsFound);
   m_pMultipleRowContextSegment->setRecordsReturnedThisMessage(m_lRecordsReturnedThisMessage);
   int lRecordNumberLastReturned = m_pMultipleRowContextSegment->recordNumberLastReturned();
   lRecordNumberLastReturned += m_lRecordsReturnedThisMessage;
   m_pMultipleRowContextSegment->setRecordNumberLastReturned(lRecordNumberLastReturned);
   char cServerStateIndicator;
   if (lRecordNumberLastReturned < m_pMultipleRowContextSegment->totalRecordsFound())
      cServerStateIndicator = (m_pMultipleRowContextSegment->clientStateIndicator() == 'I') ? 'F' : 'M';
   else
      cServerStateIndicator = (m_pMultipleRowContextSegment->clientStateIndicator() == 'I') ? 'O' : 'L';
   m_pMultipleRowContextSegment->setServerStateIndicator(cServerStateIndicator);
   m_pMultipleRowContextSegment->deport(&pMRC);
   char szTemp[9]; 
   snprintf(szTemp,sizeof(szTemp),"%04d",m_lRecordsReturnedThisMessage);
   memcpy_s(pProfileSegment->sItemCount,sizeof(pProfileSegment->sItemCount),szTemp, 4);
   snprintf(szTemp,sizeof(szTemp),"%08d",sizeof(segProfileSegment) + (m_lRecordsReturnedThisMessage * sizeof(segProfileEntry)));
   memcpy_s(pProfileSegment->sLengthOfSegment,sizeof(pProfileSegment->sLengthOfSegment),szTemp,8);
   getResponseTimeSegment()->deport(&m_pDataBuffer);
   reply();
   return true;
  //## end command::GetProfileCommand::execute%394918C50228.body
}

int GetProfileCommand::parse ()
{
  //## begin command::GetProfileCommand::parse%394918C5037C.body preserve=yes
   int iRC;
   if ((iRC = Command::parse()) != 0)
      return sendError(STS_PARSE_ERROR,STS_ERROR,iRC);
   if (!CommonHeaderSegment::instance()->presence())
      return sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_COMMON_HEADER_SEGMENT);
   if (!m_pMultipleRowContextSegment->presence())
      return sendError(STS_PARSE_ERROR,STS_ERROR,STS_MISSING_MULTIPLEROWCONTEXT_SEGMENT);
   return 0;
  //## end command::GetProfileCommand::parse%394918C5037C.body
}

void GetProfileCommand::update (Subject* pSubject)
{
  //## begin command::GetProfileCommand::update%394918C503E1.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      m_lTotalRecordsFound++;
      if (m_lRecordsReturnedThisMessage < 625 
            && m_lRecordsReturnedThisMessage <
               m_pMultipleRowContextSegment->maxRowsToFetch())
      {
         m_lRecordsReturnedThisMessage++;
         m_hProfileSegment.exportItem(&m_pDataBuffer);
         UseCase::addItem();
      }
      else
         m_hQuery.setAbort(true);
      return;
   }
   ClientCommand::update(pSubject);
  //## end command::GetProfileCommand::update%394918C503E1.body
}

// Additional Declarations
  //## begin command::GetProfileCommand%346475AF0080.declarations preserve=yes
  //## end command::GetProfileCommand%346475AF0080.declarations

} // namespace command

//## begin module%36DF007300F1.epilog preserve=yes
//## end module%36DF007300F1.epilog
