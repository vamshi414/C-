//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4AEF0E1401D4.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%4AEF0E1401D4.cm

//## begin module%4AEF0E1401D4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4AEF0E1401D4.cp

//## Module: CXOSBC31%4AEF0E1401D4; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC31.hpp

#ifndef CXOSBC31_h
#define CXOSBC31_h 1

//## begin module%4AEF0E1401D4.additionalIncludes preserve=no
//## end module%4AEF0E1401D4.additionalIncludes

//## begin module%4AEF0E1401D4.includes preserve=yes
//## end module%4AEF0E1401D4.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class XMLDocument;

} // namespace command

//## begin module%4AEF0E1401D4.declarations preserve=no
//## end module%4AEF0E1401D4.declarations

//## begin module%4AEF0E1401D4.additionalDeclarations preserve=yes
//## end module%4AEF0E1401D4.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::Network%4AEF0BDC0138.preface preserve=yes
//## end command::Network%4AEF0BDC0138.preface

//## Class: Network%4AEF0BDC0138
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4B9183770385;XMLDocument { -> F}
//## Uses: <unnamed>%4AEF0C1E0109;reusable::Query { -> F}

class DllExport Network : public reusable::Observer  //## Inherits: <unnamed>%4B952C370041
{
  //## begin command::Network%4AEF0BDC0138.initialDeclarations preserve=yes
  //## end command::Network%4AEF0BDC0138.initialDeclarations

  public:
    //## Constructors (generated)
      Network();

    //## Destructor (generated)
      virtual ~Network();


    //## Other Operations (specified)
      //## Operation: bind%4AEF0C55030D
      virtual void bind (reusable::Query& hQuery);

      //## Operation: createCase%4AEF3EFF0399
      virtual bool createCase ();

      //## Operation: deport%4B9177DD003B
      virtual bool deport (command::XMLDocument* pXMLDocument);

      //## Operation: deport%4DB09610013C
      //## Postconditions:
      //	1. The provided buffer pointer will point to the byte
      //	following the last segment exported.
      virtual void deport (char** ppsBuffer);

      //## Operation: findCase%4AF1E12802BF
      virtual int findCase (Observer* pObserver = 0	// Instance of the Subject that has changed state.
      );

      //## Operation: instance%4AEF0C3601A5
      static Network* instance ();

      //## Operation: join%4AEF0C6703D8
      virtual void join (reusable::Query& hQuery);

      //## Operation: merge%4CC8759B03B3
      virtual void merge ();

      //## Operation: reset%538F1D140113
      virtual void reset ();

      //## Operation: retrieveCase%4B95153A0249
      virtual bool retrieveCase ();

      //## Operation: update%4B95301E0016
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

      //## Operation: updateCase%4B7C290C00D6
      virtual void updateCase ();

      //## Operation: updateDocument%538F1B6E026E
      virtual bool updateDocument (string strEXPORT_IND = "S");

      //## Operation: getNetworkResp%61C0B8E1022F
      virtual reusable::string getNetworkResp ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Name%4AEF0C76030D
      const string& getName () const
      {
        //## begin command::Network::getName%4AEF0C76030D.get preserve=no
        return m_strName;
        //## end command::Network::getName%4AEF0C76030D.get
      }

      void setName (const string& value)
      {
        //## begin command::Network::setName%4AEF0C76030D.set preserve=no
        m_strName = value;
        //## end command::Network::setName%4AEF0C76030D.set
      }


    // Additional Public Declarations
      //## begin command::Network%4AEF0BDC0138.public preserve=yes
      //## end command::Network%4AEF0BDC0138.public

  protected:
    // Additional Protected Declarations
      //## begin command::Network%4AEF0BDC0138.protected preserve=yes
      //## end command::Network%4AEF0BDC0138.protected

  private:
    // Additional Private Declarations
      //## begin command::Network%4AEF0BDC0138.private preserve=yes
      //## end command::Network%4AEF0BDC0138.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%4AEF0C4803A9
      //## begin command::Network::Instance%4AEF0C4803A9.attr preserve=no  private: static Network* {V} 0
      static Network* m_pInstance;
      //## end command::Network::Instance%4AEF0C4803A9.attr

      //## begin command::Network::Name%4AEF0C76030D.attr preserve=no  public: string {V} 
      string m_strName;
      //## end command::Network::Name%4AEF0C76030D.attr

    // Additional Implementation Declarations
      //## begin command::Network%4AEF0BDC0138.implementation preserve=yes
      //## end command::Network%4AEF0BDC0138.implementation

};

//## begin command::Network%4AEF0BDC0138.postscript preserve=yes
//## end command::Network%4AEF0BDC0138.postscript

} // namespace command

//## begin module%4AEF0E1401D4.epilog preserve=yes
//## end module%4AEF0E1401D4.epilog


#endif
