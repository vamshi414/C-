//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4AEF0E5D0222.cm preserve=no
//	$Date:   Nov 06 2009 15:18:52  $ $Author:   D02405  $
//	$Revision:   1.0  $
//## end module%4AEF0E5D0222.cm

//## begin module%4AEF0E5D0222.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4AEF0E5D0222.cp

//## Module: CXOSBC32%4AEF0E5D0222; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC32.hpp

#ifndef CXOSBC32_h
#define CXOSBC32_h 1

//## begin module%4AEF0E5D0222.additionalIncludes preserve=no
//## end module%4AEF0E5D0222.additionalIncludes

//## begin module%4AEF0E5D0222.includes preserve=yes
#include <map>
//## end module%4AEF0E5D0222.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Network;

} // namespace command

//## begin module%4AEF0E5D0222.declarations preserve=no
//## end module%4AEF0E5D0222.declarations

//## begin module%4AEF0E5D0222.additionalDeclarations preserve=yes
//## end module%4AEF0E5D0222.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::NetworkFactory%4AEF0B5A036B.preface preserve=yes
//## end command::NetworkFactory%4AEF0B5A036B.preface

//## Class: NetworkFactory%4AEF0B5A036B
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4AEF1633035B;Network { -> F}

class DllExport NetworkFactory : public reusable::Object  //## Inherits: <unnamed>%4AEF0B7E01C5
{
  //## begin command::NetworkFactory%4AEF0B5A036B.initialDeclarations preserve=yes
  //## end command::NetworkFactory%4AEF0B5A036B.initialDeclarations

  public:
    //## Constructors (generated)
      NetworkFactory();

    //## Destructor (generated)
      virtual ~NetworkFactory();


    //## Other Operations (specified)
      //## Operation: create%4AEF0B85004E
      virtual command::Network* create (const char* pszNetwork, const char* pszValue = 0) = 0;

      //## Operation: instance%4AEF0BA30280
      static NetworkFactory* instance ();

    // Additional Public Declarations
      //## begin command::NetworkFactory%4AEF0B5A036B.public preserve=yes
      //## end command::NetworkFactory%4AEF0B5A036B.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Classes%4AEF310202CE
      //## begin command::NetworkFactory::Classes%4AEF310202CE.attr preserve=no  public: map<string,int,less<string> > {V} 
      map<string,int,less<string> > m_hClasses;
      //## end command::NetworkFactory::Classes%4AEF310202CE.attr

    // Additional Protected Declarations
      //## begin command::NetworkFactory%4AEF0B5A036B.protected preserve=yes
      //## end command::NetworkFactory%4AEF0B5A036B.protected

  private:
    // Additional Private Declarations
      //## begin command::NetworkFactory%4AEF0B5A036B.private preserve=yes
      //## end command::NetworkFactory%4AEF0B5A036B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%4AEF0BB403A9
      //## begin command::NetworkFactory::Instance%4AEF0BB403A9.attr preserve=no  private: static NetworkFactory* {V} 0
      static NetworkFactory* m_pInstance;
      //## end command::NetworkFactory::Instance%4AEF0BB403A9.attr

    // Additional Implementation Declarations
      //## begin command::NetworkFactory%4AEF0B5A036B.implementation preserve=yes
      //## end command::NetworkFactory%4AEF0B5A036B.implementation

};

//## begin command::NetworkFactory%4AEF0B5A036B.postscript preserve=yes
//## end command::NetworkFactory%4AEF0B5A036B.postscript

} // namespace command

//## begin module%4AEF0E5D0222.epilog preserve=yes
//## end module%4AEF0E5D0222.epilog


#endif
