//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%370BAD3D0015.cm preserve=no
//    %X% %Q% %Z% %W%
//## end module%370BAD3D0015.cm

//## begin module%370BAD3D0015.cp preserve=no
//  Copyright (c) 1998 - 2004
//  eFunds Corporation
//## end module%370BAD3D0015.cp

//## Module: CXOSBC12%370BAD3D0015; Package body
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC12.cpp

//## begin module%370BAD3D0015.additionalIncludes preserve=no
//## end module%370BAD3D0015.additionalIncludes

//## begin module%370BAD3D0015.includes preserve=yes
// $Date:   18 Jan 2018 13:52:58  $ $Author:   e1009839  $ $Revision:   1.8  $
#include "CXODUS14.hpp"
#include "CXODIF03.hpp"  //Trace
#ifndef CXOSBS10_h
#include "CXODBS10.hpp"
#endif
//## end module%370BAD3D0015.includes

#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU07_h
#include "CXODRU07.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSUS09_h
#include "CXODUS09.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU20_h
#include "CXODRU20.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSBC12_h
#include "CXODBC12.hpp"
#endif


//## begin module%370BAD3D0015.declarations preserve=no
//## end module%370BAD3D0015.declarations

//## begin module%370BAD3D0015.additionalDeclarations preserve=yes
//## end module%370BAD3D0015.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::GetCustomizationCommand 

GetCustomizationCommand::GetCustomizationCommand()
  //## begin GetCustomizationCommand::GetCustomizationCommand%3708C99A0235_const.hasinit preserve=no
      : m_pszBuffer(0),
        m_pListSegment(0)
  //## end GetCustomizationCommand::GetCustomizationCommand%3708C99A0235_const.hasinit
  //## begin GetCustomizationCommand::GetCustomizationCommand%3708C99A0235_const.initialization preserve=yes
   ,ClientListCommand("S0005D","@##GETCUST",false)
  //## end GetCustomizationCommand::GetCustomizationCommand%3708C99A0235_const.initialization
{
  //## begin command::GetCustomizationCommand::GetCustomizationCommand%3708C99A0235_const.body preserve=yes
   memcpy(m_sID,"UC04",4);
   m_pListSegment = new ListSegment();
   m_hSegments.push_back(m_pListSegment);
   m_hQuery.attach(this);
  //## end command::GetCustomizationCommand::GetCustomizationCommand%3708C99A0235_const.body
}

GetCustomizationCommand::GetCustomizationCommand (Handler* pSuccessor)
  //## begin command::GetCustomizationCommand::GetCustomizationCommand%3E96B33203C8.hasinit preserve=no
      : m_pszBuffer(0),
        m_pListSegment(0)
  //## end command::GetCustomizationCommand::GetCustomizationCommand%3E96B33203C8.hasinit
  //## begin command::GetCustomizationCommand::GetCustomizationCommand%3E96B33203C8.initialization preserve=yes
   ,ClientListCommand("S0005D","@GETCUST",false)
  //## end command::GetCustomizationCommand::GetCustomizationCommand%3E96B33203C8.initialization
{
  //## begin command::GetCustomizationCommand::GetCustomizationCommand%3E96B33203C8.body preserve=yes
   memcpy(m_sID,"UC04",4);
   m_pSuccessor = pSuccessor;
   m_pListSegment = new ListSegment();
   m_hSegments.push_back(m_pListSegment);
   m_hQuery.attach(this);
  //## end command::GetCustomizationCommand::GetCustomizationCommand%3E96B33203C8.body
}


GetCustomizationCommand::~GetCustomizationCommand()
{
  //## begin command::GetCustomizationCommand::~GetCustomizationCommand%3708C99A0235_dest.body preserve=yes
   delete m_pListSegment;
  //## end command::GetCustomizationCommand::~GetCustomizationCommand%3708C99A0235_dest.body
}



//## Other Operations (implementation)
bool GetCustomizationCommand::retrieve ()
{
  //## begin command::GetCustomizationCommand::retrieve%3B681EDC0280.body preserve=yes
   // CL21: Client_Requests_Customization_From_DB
   UseCase hUseCase("CLIENT","## CL21 GET CUSTOMIZATION");
   if (!m_pListSegment->presence())
      return UseCase::setSuccess(false);
   char* pBuffer = (char*)*m_pListSegment;
   GetCustomizationSegment hGetCustomizationSegment;
   hGetCustomizationSegment.import(&pBuffer);
   string strCUSTOMIZE_NODE = hGetCustomizationSegment.getCUSTOMIZE_NODE();
   string strFULL_CUSTOMIZE_NAM= hGetCustomizationSegment.getFULL_CUSTOMIZE_NAM();
   if (m_pListSegment->itemCount() == 1 && strFULL_CUSTOMIZE_NAM.rfind("%") != string::npos &&
      strFULL_CUSTOMIZE_NAM.length() > 13 &&
      (strFULL_CUSTOMIZE_NAM.substr(0,10) == "VIEW_TRAN_" || strFULL_CUSTOMIZE_NAM.substr(0,9) == "VIEW_EMS_"))
   {  //FULL_CUSTOM_NAM of form: VIEW_TRAN_CUST_% or VIEW_EMS_CUST_%
      string strFULL_CUSTOMIZE_NAM1 = "%" + strFULL_CUSTOMIZE_NAM;
      string strFULL_CUSTOMIZE_NAM2 = "%" + strFULL_CUSTOMIZE_NAM;
      size_t pos = strFULL_CUSTOMIZE_NAM1.rfind("_");
      if(pos != string::npos)
         strFULL_CUSTOMIZE_NAM1.erase(pos);
      string strFULL_CUSTOMIZE_NAM3(strFULL_CUSTOMIZE_NAM1);
      strFULL_CUSTOMIZE_NAM1.append("_*%");  //VIEW_TRAN_% or VIEW_EMS_%
      strFULL_CUSTOMIZE_NAM3.append("__DEFAULT%"); 
      m_pRow = new Row;
      m_pszBuffer = new char[8192];
      m_hQuery.setQualifier("QUALIFY","CLIENT_CUSTOM_DATA");
      m_hCustomizationSegment.bind(m_hQuery);
      m_hQuery.getSearchCondition().append("(");
      m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA","CUSTOMIZE_NODE","=",strCUSTOMIZE_NODE.c_str());

      m_hQuery.getSearchCondition().append(" AND (");
      m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA","FULL_CUSTOMIZE_NAM","LIKE",strFULL_CUSTOMIZE_NAM1.c_str());
      m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA","FULL_CUSTOMIZE_NAM","LIKE",strFULL_CUSTOMIZE_NAM3.c_str(),false,false);
      m_hQuery.getSearchCondition().append(")");

      m_hQuery.getSearchCondition().append(") OR (");
      m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA","FULL_CUSTOMIZE_NAM","LIKE",strFULL_CUSTOMIZE_NAM2.c_str());
      m_hQuery.getSearchCondition().append(")");
      string strOrderByClause("CLIENT_CUSTOM_DATA.CUSTOMIZE_NODE,CLIENT_CUSTOM_DATA.FULL_CUSTOMIZE_NAM,CLIENT_CUSTOM_DATA.SEQUENCE_NO");
      m_hQuery.setOrderByClause(strOrderByClause);
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      bool bSuccess = pSelectStatement->execute(m_hQuery);
      delete [] m_pszBuffer;
      m_pszBuffer = 0;
      delete m_pRow;
      m_pRow = 0;
      if(!bSuccess)
         return UseCase::setSuccess(false);
   }
   else
   {
      string strInList = "('" + strCUSTOMIZE_NODE + "'";
      for(int i = 1; i < m_pListSegment->itemCount(); i++)
      {
         hGetCustomizationSegment.import(&pBuffer);
         strInList += ",'" + hGetCustomizationSegment.getCUSTOMIZE_NODE() + '\'';
      }
      strInList += ')';
      m_pRow = new Row;
      m_pszBuffer = new char[8192];
      m_hQuery.setQualifier("QUALIFY","CLIENT_CUSTOM_DATA");
      m_hCustomizationSegment.bind(m_hQuery);
      m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA","CUSTOMIZE_NODE","IN",strInList.c_str());
      if (hGetCustomizationSegment.getFULL_CUSTOMIZE_NAM().length() != 0)
         m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA","FULL_CUSTOMIZE_NAM","LIKE",hGetCustomizationSegment.getFULL_CUSTOMIZE_NAM().c_str());
      if (m_pMultipleRowContextSegment->presence()
         && m_pMultipleRowContextSegment->clientStateIndicator() == 'C' )
      {
         string strFULL_CUSTOMIZE_NAM((char*)m_pMultipleRowContextSegment->STSContextData(),strlen((char*)m_pMultipleRowContextSegment->STSContextData()));
         size_t n = strFULL_CUSTOMIZE_NAM.find_last_not_of(' ');
         strFULL_CUSTOMIZE_NAM.erase(n + 1);
         m_hQuery.setBasicPredicate("CLIENT_CUSTOM_DATA","FULL_CUSTOMIZE_NAM",">=",strFULL_CUSTOMIZE_NAM.c_str());
      }
      string strOrderByClause("CLIENT_CUSTOM_DATA.CUSTOMIZE_NODE,CLIENT_CUSTOM_DATA.FULL_CUSTOMIZE_NAM,CLIENT_CUSTOM_DATA.SEQUENCE_NO");
      m_hQuery.setOrderByClause(strOrderByClause);
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      bool bSuccess = pSelectStatement->execute(m_hQuery);
      delete [] m_pszBuffer;
      m_pszBuffer = 0;
      delete m_pRow;
      m_pRow = 0;
      if(!bSuccess)
         return UseCase::setSuccess(false);
   }
   return true;
  //## end command::GetCustomizationCommand::retrieve%3B681EDC0280.body
}

void GetCustomizationCommand::update (Subject* pSubject)
{
  //## begin command::GetCustomizationCommand::update%370CBA750377.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      m_pMultipleRowContextSegment->setSTSContextData(IString(m_hCustomizationSegment.getFullCustomizeName().c_str(),m_hCustomizationSegment.getFullCustomizeName().length()));
      char* p = m_pszBuffer;
      m_hCustomizationSegment.deport(&p);
      *p = '\0';
      m_pRow->getBuffer() = m_pszBuffer;
      ClientListCommand::update(m_pRow);
      UseCase::addItem();
      return;
   }
   ClientListCommand::update(pSubject);
  //## end command::GetCustomizationCommand::update%370CBA750377.body
}

// Additional Declarations
  //## begin command::GetCustomizationCommand%3708C99A0235.declarations preserve=yes
  //## end command::GetCustomizationCommand%3708C99A0235.declarations

} // namespace command

//## begin module%370BAD3D0015.epilog preserve=yes
//## end module%370BAD3D0015.epilog
