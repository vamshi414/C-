//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5F5FC49A02AF.cm preserve=no
//	$Date:   Oct 13 2020 05:18:12  $ $Author:   e3023547  $
//	$Revision:   1.0  $
//## end module%5F5FC49A02AF.cm

//## begin module%5F5FC49A02AF.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5F5FC49A02AF.cp

//## Module: CXOSBC61%5F5FC49A02AF; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: D:\Devel\V03.1A.R007\ConnexPlatform\Server\Library\Bcdll\CXODBC61.hpp

#ifndef CXOSBC61_h
#define CXOSBC61_h 1

//## begin module%5F5FC49A02AF.additionalIncludes preserve=no
//## end module%5F5FC49A02AF.additionalIncludes

//## begin module%5F5FC49A02AF.includes preserve=yes
//## end module%5F5FC49A02AF.includes

#ifndef CXOSBC48_h
#include "CXODBC48.hpp"
#endif
#ifndef CXOSBC47_h
#include "CXODBC47.hpp"
#endif
#ifndef CXOSBC46_h
#include "CXODBC46.hpp"
#endif
#ifndef CXOSBC35_h
#include "CXODBC35.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class GenericRule;

} // namespace command

//## begin module%5F5FC49A02AF.declarations preserve=no
//## end module%5F5FC49A02AF.declarations

//## begin module%5F5FC49A02AF.additionalDeclarations preserve=yes
//## end module%5F5FC49A02AF.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::GenericRuleXMLHandler%5F5FC094023A.preface preserve=yes
//## end command::GenericRuleXMLHandler%5F5FC094023A.preface

//## Class: GenericRuleXMLHandler%5F5FC094023A
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5F5FCDC40308;reusable::Buffer { -> F}

class DllExport GenericRuleXMLHandler : public XMLHandler  //## Inherits: <unnamed>%5F5FCDC702CD
{
  //## begin command::GenericRuleXMLHandler%5F5FC094023A.initialDeclarations preserve=yes
  //## end command::GenericRuleXMLHandler%5F5FC094023A.initialDeclarations

  public:
    //## Constructors (generated)
      GenericRuleXMLHandler();

    //## Constructors (specified)
      //## Operation: GenericRuleXMLHandler%5F5FCEE30382
      GenericRuleXMLHandler (XMLItem* pXMLItem);

    //## Destructor (generated)
      virtual ~GenericRuleXMLHandler();


    //## Other Operations (specified)
      //## Operation: endElement%5F5FCEB300F2
      virtual void endElement (const XMLCh* const name);

      //## Operation: startElement%5F5FCF19030F
      void startElement (const XMLCh* const name, AttributeList& attributes);

    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::Command_CAT::<unnamed>%5F5FD3950166
      //## Role: GenericRuleXMLHandler::<m_pGenericRule>%5F5FD3960046
      void setGenericRule (GenericRule * value)
      {
        //## begin command::GenericRuleXMLHandler::setGenericRule%5F5FD3960046.set preserve=no
        m_pGenericRule = value;
        //## end command::GenericRuleXMLHandler::setGenericRule%5F5FD3960046.set
      }


    // Additional Public Declarations
      //## begin command::GenericRuleXMLHandler%5F5FC094023A.public preserve=yes
      //## end command::GenericRuleXMLHandler%5F5FC094023A.public

  protected:
    // Additional Protected Declarations
      //## begin command::GenericRuleXMLHandler%5F5FC094023A.protected preserve=yes
      //## end command::GenericRuleXMLHandler%5F5FC094023A.protected

  private:
    // Additional Private Declarations
      //## begin command::GenericRuleXMLHandler%5F5FC094023A.private preserve=yes
      //## end command::GenericRuleXMLHandler%5F5FC094023A.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%5F5FCE2D03CA
      //## Role: GenericRuleXMLHandler::<m_hCriteriaData>%5F5FCE2E02AF
      //## begin command::GenericRuleXMLHandler::<m_hCriteriaData>%5F5FCE2E02AF.role preserve=no  public: command::CriteriaData { -> VHgN}
      CriteriaData m_hCriteriaData;
      //## end command::GenericRuleXMLHandler::<m_hCriteriaData>%5F5FCE2E02AF.role

      //## Association: Connex Library::Command_CAT::<unnamed>%5F5FCE5301E4
      //## Role: GenericRuleXMLHandler::<m_hCriteria>%5F5FCE54005C
      //## begin command::GenericRuleXMLHandler::<m_hCriteria>%5F5FCE54005C.role preserve=no  public: command::Criteria { -> VHgN}
      Criteria m_hCriteria;
      //## end command::GenericRuleXMLHandler::<m_hCriteria>%5F5FCE54005C.role

      //## Association: Connex Library::Command_CAT::<unnamed>%5F5FCE6C00AB
      //## Role: GenericRuleXMLHandler::<m_hFunction>%5F5FCE6D02BD
      //## begin command::GenericRuleXMLHandler::<m_hFunction>%5F5FCE6D02BD.role preserve=no  public: command::Function { -> VHgN}
      Function m_hFunction;
      //## end command::GenericRuleXMLHandler::<m_hFunction>%5F5FCE6D02BD.role

      //## Association: Connex Library::Command_CAT::<unnamed>%5F5FD3950166
      //## begin command::GenericRuleXMLHandler::<m_pGenericRule>%5F5FD3960046.role preserve=no  public: command::GenericRule { -> RFHgN}
      GenericRule *m_pGenericRule;
      //## end command::GenericRuleXMLHandler::<m_pGenericRule>%5F5FD3960046.role

    // Additional Implementation Declarations
      //## begin command::GenericRuleXMLHandler%5F5FC094023A.implementation preserve=yes
      //## end command::GenericRuleXMLHandler%5F5FC094023A.implementation

};

//## begin command::GenericRuleXMLHandler%5F5FC094023A.postscript preserve=yes
//## end command::GenericRuleXMLHandler%5F5FC094023A.postscript

} // namespace command

//## begin module%5F5FC49A02AF.epilog preserve=yes
//## end module%5F5FC49A02AF.epilog


#endif
