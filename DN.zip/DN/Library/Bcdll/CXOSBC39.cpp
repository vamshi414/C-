//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%517ED2BC0002.cm preserve=no
//	$Date:   Jan 19 2017 11:11:56  $ $Author:   e1009591  $
//	$Revision:   1.2  $
//## end module%517ED2BC0002.cm

//## begin module%517ED2BC0002.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%517ED2BC0002.cp

//## Module: CXOSBC39%517ED2BC0002; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.3B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC39.cpp

//## begin module%517ED2BC0002.additionalIncludes preserve=no
//## end module%517ED2BC0002.additionalIncludes

//## begin module%517ED2BC0002.includes preserve=yes
//## end module%517ED2BC0002.includes

#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBC39_h
#include "CXODBC39.hpp"
#endif


//## begin module%517ED2BC0002.declarations preserve=no
//## end module%517ED2BC0002.declarations

//## begin module%517ED2BC0002.additionalDeclarations preserve=yes
//## end module%517ED2BC0002.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::ImportData 

//## begin command::ImportData::Instance%517EDA18020E.attr preserve=no  private: static command::ImportData* {V} 0
command::ImportData* ImportData::m_pInstance = 0;
//## end command::ImportData::Instance%517EDA18020E.attr

ImportData::ImportData()
  //## begin ImportData::ImportData%517EC6BF0036_const.hasinit preserve=no
      : m_lDI_FILE_ID(0),
        m_siSEQ_NO(0),
        m_iTRANSACTION_NO(0)
  //## end ImportData::ImportData%517EC6BF0036_const.hasinit
  //## begin ImportData::ImportData%517EC6BF0036_const.initialization preserve=yes
  //## end ImportData::ImportData%517EC6BF0036_const.initialization
{
  //## begin command::ImportData::ImportData%517EC6BF0036_const.body preserve=yes
  //## end command::ImportData::ImportData%517EC6BF0036_const.body
}


ImportData::~ImportData()
{
  //## begin command::ImportData::~ImportData%517EC6BF0036_dest.body preserve=yes
  //## end command::ImportData::~ImportData%517EC6BF0036_dest.body
}



//## Other Operations (implementation)
bool ImportData::insert (const char* pszBuffer, int m, bool bTruncate,const string& strStatus)
{
  //## begin command::ImportData::insert%517ECC3000C8.body preserve=yes
   string strDATA_BUFFER;
   Table hTable("DI_DATA");
   auto_ptr<reusable::Statement> pInsertStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("InsertStatement"));
   int n = -1;
   string strTemp;
   while (m > 0)
   {
      if (m > 3500)
         strDATA_BUFFER.assign(pszBuffer,3500);
      else
         strDATA_BUFFER.assign(pszBuffer,m);
      hTable.set("DI_FILE_ID",m_lDI_FILE_ID,true);
      hTable.set("TRANSACTION_NO",m_iTRANSACTION_NO,true);
      hTable.set("SEQ_NO",(int)m_siSEQ_NO,true);
      hTable.set("DI_STATE",strStatus);
      hTable.set("IMPORT_KEY",m_strIMPORT_KEY);
      hTable.set("REJECT_CODES",m_strREJECT_CODES);
      hTable.set("TSTAMP_PARSED",strTemp);
      hTable.set("TSTAMP_NEXT_PARSE",strTemp);
      hTable.set("TSTAMP_RETRY_COUNT",n);
      hTable.set("DATA_BUFFER",strDATA_BUFFER,false,false,bTruncate);
      if (!pInsertStatement->execute(hTable))
         return false;
      m_siSEQ_NO ++;
      if (m > 3500)
         pszBuffer += 3500;
      m -= 3500;
   }
   return true;
  //## end command::ImportData::insert%517ECC3000C8.body
}

command::ImportData* ImportData::instance ()
{
  //## begin command::ImportData::instance%517ED9A2022C.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ImportData();
   return m_pInstance;

  //## end command::ImportData::instance%517ED9A2022C.body
}

// Additional Declarations
  //## begin command::ImportData%517EC6BF0036.declarations preserve=yes
  //## end command::ImportData%517EC6BF0036.declarations

} // namespace command

//## begin module%517ED2BC0002.epilog preserve=yes
//## end module%517ED2BC0002.epilog
