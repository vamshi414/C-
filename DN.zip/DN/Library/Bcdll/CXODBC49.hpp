//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5625F9D00253.cm preserve=no
//	$Date:   Jan 10 2017 08:25:36  $ $Author:   e1009674  $ $Revision:   1.1  $
//## end module%5625F9D00253.cm

//## begin module%5625F9D00253.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5625F9D00253.cp

//## Module: CXOSBC49%5625F9D00253; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC49.hpp

#ifndef CXOSBC49_h
#define CXOSBC49_h 1

//## begin module%5625F9D00253.additionalIncludes preserve=no
//## end module%5625F9D00253.additionalIncludes

//## begin module%5625F9D00253.includes preserve=yes
#include<map>
//## end module%5625F9D00253.includes

#ifndef CXOSBC48_h
#include "CXODBC48.hpp"
#endif
#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
} // namespace IF

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class XMLItem;
class GenericFunctionXMLHandler;
class Criteria;
class CriteriaData;

} // namespace command

//## begin module%5625F9D00253.declarations preserve=no
//## end module%5625F9D00253.declarations

//## begin module%5625F9D00253.additionalDeclarations preserve=yes
//## end module%5625F9D00253.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::GenericFunction%5625DB8C00A5.preface preserve=yes
//## end command::GenericFunction%5625DB8C00A5.preface

//## Class: GenericFunction%5625DB8C00A5
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%562647260046;IF::FlatFile { -> F}
//## Uses: <unnamed>%5628DE7400C0;CriteriaData { -> F}
//## Uses: <unnamed>%5628DE7801CE;Criteria { -> F}

class DllExport GenericFunction : public reusable::Observer  //## Inherits: <unnamed>%5625DB8C00D3
{
  //## begin command::GenericFunction%5625DB8C00A5.initialDeclarations preserve=yes
  //## end command::GenericFunction%5625DB8C00A5.initialDeclarations

  public:
    //## Constructors (generated)
      GenericFunction();

    //## Destructor (generated)
      virtual ~GenericFunction();


    //## Other Operations (specified)
      //## Operation: addFunction%5628B2BC01BE
      void addFunction (const Function& hFunction);

      //## Operation: evaluate%5626088B0290
      bool evaluate (const string& strFunction, vector<pair<string,string> >& hResult);

      //## Operation: evaluateFields%562608C10055
      bool evaluateFields (vector<CriteriaData>& hCriteriaData);

      //## Operation: getField%5874ECDC017B
      void getField (const string& strTable, const string& strField, string& strValue);

      //## Operation: instance%5625FFA3023D
      static GenericFunction* instance ();

      //## Operation: loadSegment%5626086701A4
      void loadSegment (const string& strTable, Segment* pSegment);

      //## Operation: update%5626015D00C0
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin command::GenericFunction%5625DB8C00A5.public preserve=yes
      //## end command::GenericFunction%5625DB8C00A5.public

  protected:
    // Additional Protected Declarations
      //## begin command::GenericFunction%5625DB8C00A5.protected preserve=yes
      //## end command::GenericFunction%5625DB8C00A5.protected

  private:
    // Additional Private Declarations
      //## begin command::GenericFunction%5625DB8C00A5.private preserve=yes
      //## end command::GenericFunction%5625DB8C00A5.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: instance%562600330259
      //## begin command::GenericFunction::instance%562600330259.attr preserve=no  private: static GenericFunction* {U} 0
      static GenericFunction* m_pinstance;
      //## end command::GenericFunction::instance%562600330259.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%5625FA57021B
      //## Role: GenericFunction::<m_hFunction>%5625FA59014D
      //## begin command::GenericFunction::<m_hFunction>%5625FA59014D.role preserve=no  public: command::Function {1 -> 0..nVHgN}
      vector<Function> m_hFunction;
      //## end command::GenericFunction::<m_hFunction>%5625FA59014D.role

      //## Association: Connex Library::Command_CAT::<unnamed>%5625FB2100AC
      //## Role: GenericFunction::<m_hSegment>%5625FB2202CC
      //## Qualifier: strTable%5625FB88023E; string
      //## begin command::GenericFunction::<m_hSegment>%5625FB2202CC.role preserve=no  public: segment::Segment { -> RHgN}
      map<string, segment::Segment *, less<string> > m_hSegment;
      //## end command::GenericFunction::<m_hSegment>%5625FB2202CC.role

      //## Association: Connex Library::Command_CAT::<unnamed>%56264FEA02AA
      //## Role: GenericFunction::<m_pGenericFunctionXMLHandler>%56264FEC0066
      //## begin command::GenericFunction::<m_pGenericFunctionXMLHandler>%56264FEC0066.role preserve=no  public: command::GenericFunctionXMLHandler { -> RFHgN}
      GenericFunctionXMLHandler *m_pGenericFunctionXMLHandler;
      //## end command::GenericFunction::<m_pGenericFunctionXMLHandler>%56264FEC0066.role

      //## Association: Connex Library::Command_CAT::<unnamed>%5628C5DF02D7
      //## Role: GenericFunction::<m_pXMLItem>%5628C5E10061
      //## begin command::GenericFunction::<m_pXMLItem>%5628C5E10061.role preserve=no  public: command::XMLItem { -> RFHgN}
      XMLItem *m_pXMLItem;
      //## end command::GenericFunction::<m_pXMLItem>%5628C5E10061.role

    // Additional Implementation Declarations
      //## begin command::GenericFunction%5625DB8C00A5.implementation preserve=yes
      //## end command::GenericFunction%5625DB8C00A5.implementation

};

//## begin command::GenericFunction%5625DB8C00A5.postscript preserve=yes
//## end command::GenericFunction%5625DB8C00A5.postscript

} // namespace command

//## begin module%5625F9D00253.epilog preserve=yes
//## end module%5625F9D00253.epilog


#endif
