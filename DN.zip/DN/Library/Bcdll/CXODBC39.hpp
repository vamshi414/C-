//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%517ED2B90124.cm preserve=no
//	$Date:   Jan 19 2017 11:10:54  $ $Author:   e1009591  $
//	$Revision:   1.2  $
//## end module%517ED2B90124.cm

//## begin module%517ED2B90124.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%517ED2B90124.cp

//## Module: CXOSBC39%517ED2B90124; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.3B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC39.hpp

#ifndef CXOSBC39_h
#define CXOSBC39_h 1

//## begin module%517ED2B90124.additionalIncludes preserve=no
//## end module%517ED2B90124.additionalIncludes

//## begin module%517ED2B90124.includes preserve=yes
//## end module%517ED2B90124.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;

} // namespace reusable

//## begin module%517ED2B90124.declarations preserve=no
//## end module%517ED2B90124.declarations

//## begin module%517ED2B90124.additionalDeclarations preserve=yes
//## end module%517ED2B90124.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::ImportData%517EC6BF0036.preface preserve=yes
//## end command::ImportData%517EC6BF0036.preface

//## Class: ImportData%517EC6BF0036
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%517ECD0C011C;reusable::Table { -> F}
//## Uses: <unnamed>%517ECD2702A2;reusable::Statement { -> F}
//## Uses: <unnamed>%517ECD4D0108;database::Database { -> F}
//## Uses: <unnamed>%517EE9350189;database::DatabaseFactory { -> F}

class DllExport ImportData : public reusable::Object  //## Inherits: <unnamed>%517EE6070092
{
  //## begin command::ImportData%517EC6BF0036.initialDeclarations preserve=yes
  //## end command::ImportData%517EC6BF0036.initialDeclarations

  public:
    //## Constructors (generated)
      ImportData();

    //## Destructor (generated)
      virtual ~ImportData();


    //## Other Operations (specified)
      //## Operation: insert%517ECC3000C8
      bool insert (const char* pszBuffer, int m, bool bTruncate,const string& strStatus = "IW");

      //## Operation: instance%517ED9A2022C
      static ImportData* instance ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: DI_FILE_ID%517EDD7302FE
      const int getDI_FILE_ID () const
      {
        //## begin command::ImportData::getDI_FILE_ID%517EDD7302FE.get preserve=no
        return m_lDI_FILE_ID;
        //## end command::ImportData::getDI_FILE_ID%517EDD7302FE.get
      }

      void setDI_FILE_ID (int value)
      {
        //## begin command::ImportData::setDI_FILE_ID%517EDD7302FE.set preserve=no
        m_lDI_FILE_ID = value;
        //## end command::ImportData::setDI_FILE_ID%517EDD7302FE.set
      }


      //## Attribute: IMPORT_KEY%5190F9290037
      const string& getIMPORT_KEY () const
      {
        //## begin command::ImportData::getIMPORT_KEY%5190F9290037.get preserve=no
        return m_strIMPORT_KEY;
        //## end command::ImportData::getIMPORT_KEY%5190F9290037.get
      }

      void setIMPORT_KEY (const string& value)
      {
        //## begin command::ImportData::setIMPORT_KEY%5190F9290037.set preserve=no
        m_strIMPORT_KEY = value;
        //## end command::ImportData::setIMPORT_KEY%5190F9290037.set
      }


      //## Attribute: REJECT_CODES%517EE18F008C
      const string& getREJECT_CODES () const
      {
        //## begin command::ImportData::getREJECT_CODES%517EE18F008C.get preserve=no
        return m_strREJECT_CODES;
        //## end command::ImportData::getREJECT_CODES%517EE18F008C.get
      }

      void setREJECT_CODES (const string& value)
      {
        //## begin command::ImportData::setREJECT_CODES%517EE18F008C.set preserve=no
        m_strREJECT_CODES = value;
        //## end command::ImportData::setREJECT_CODES%517EE18F008C.set
      }


      //## Attribute: SEQ_NO%517ED966031C
      const int getSEQ_NO () const
      {
        //## begin command::ImportData::getSEQ_NO%517ED966031C.get preserve=no
        return m_siSEQ_NO;
        //## end command::ImportData::getSEQ_NO%517ED966031C.get
      }

      void setSEQ_NO (int value)
      {
        //## begin command::ImportData::setSEQ_NO%517ED966031C.set preserve=no
        m_siSEQ_NO = value;
        //## end command::ImportData::setSEQ_NO%517ED966031C.set
      }


      //## Attribute: TRANSACTION_NO%517ED966031D
      const int getTRANSACTION_NO () const
      {
        //## begin command::ImportData::getTRANSACTION_NO%517ED966031D.get preserve=no
        return m_iTRANSACTION_NO;
        //## end command::ImportData::getTRANSACTION_NO%517ED966031D.get
      }

      void setTRANSACTION_NO (int value)
      {
        //## begin command::ImportData::setTRANSACTION_NO%517ED966031D.set preserve=no
        m_iTRANSACTION_NO = value;
        //## end command::ImportData::setTRANSACTION_NO%517ED966031D.set
      }


    // Additional Public Declarations
      //## begin command::ImportData%517EC6BF0036.public preserve=yes
      //## end command::ImportData%517EC6BF0036.public

  protected:
    // Additional Protected Declarations
      //## begin command::ImportData%517EC6BF0036.protected preserve=yes
      //## end command::ImportData%517EC6BF0036.protected

  private:
    // Additional Private Declarations
      //## begin command::ImportData%517EC6BF0036.private preserve=yes
      //## end command::ImportData%517EC6BF0036.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::ImportData::DI_FILE_ID%517EDD7302FE.attr preserve=no  public: int {V} 0
      int m_lDI_FILE_ID;
      //## end command::ImportData::DI_FILE_ID%517EDD7302FE.attr

      //## begin command::ImportData::IMPORT_KEY%5190F9290037.attr preserve=no  public: string {U} 
      string m_strIMPORT_KEY;
      //## end command::ImportData::IMPORT_KEY%5190F9290037.attr

      //## Attribute: Instance%517EDA18020E
      //## begin command::ImportData::Instance%517EDA18020E.attr preserve=no  private: static ImportData* {V} 0
      static ImportData* m_pInstance;
      //## end command::ImportData::Instance%517EDA18020E.attr

      //## begin command::ImportData::REJECT_CODES%517EE18F008C.attr preserve=no  public: string {V} 
      string m_strREJECT_CODES;
      //## end command::ImportData::REJECT_CODES%517EE18F008C.attr

      //## begin command::ImportData::SEQ_NO%517ED966031C.attr preserve=no  public: int {U} 0
      int m_siSEQ_NO;
      //## end command::ImportData::SEQ_NO%517ED966031C.attr

      //## begin command::ImportData::TRANSACTION_NO%517ED966031D.attr preserve=no  public: int {U} 0
      int m_iTRANSACTION_NO;
      //## end command::ImportData::TRANSACTION_NO%517ED966031D.attr

    // Additional Implementation Declarations
      //## begin command::ImportData%517EC6BF0036.implementation preserve=yes
      //## end command::ImportData%517EC6BF0036.implementation

};

//## begin command::ImportData%517EC6BF0036.postscript preserve=yes
//## end command::ImportData%517EC6BF0036.postscript

} // namespace command

//## begin module%517ED2B90124.epilog preserve=yes
//## end module%517ED2B90124.epilog


#endif
