//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5625F79B0232.cm preserve=no
//	$Date:   May 24 2016 11:03:12  $ $Author:   e1009510  $ $Revision:   1.0  $
//## end module%5625F79B0232.cm

//## begin module%5625F79B0232.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5625F79B0232.cp

//## Module: CXOSBC48%5625F79B0232; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC48.hpp

#ifndef CXOSBC48_h
#define CXOSBC48_h 1

//## begin module%5625F79B0232.additionalIncludes preserve=no
//## end module%5625F79B0232.additionalIncludes

//## begin module%5625F79B0232.includes preserve=yes
//## end module%5625F79B0232.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSBC47_h
#include "CXODBC47.hpp"
#endif
//## begin module%5625F79B0232.declarations preserve=no
//## end module%5625F79B0232.declarations

//## begin module%5625F79B0232.additionalDeclarations preserve=yes
//## end module%5625F79B0232.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::Function%5625F72A0314.preface preserve=yes
//## end command::Function%5625F72A0314.preface

//## Class: Function%5625F72A0314
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport Function : public reusable::Object  //## Inherits: <unnamed>%5625F7770379
{
  //## begin command::Function%5625F72A0314.initialDeclarations preserve=yes
  //## end command::Function%5625F72A0314.initialDeclarations

  public:
    //## Constructors (generated)
      Function();

    //## Destructor (generated)
      virtual ~Function();

    //## Equality Operations (generated)
      bool operator==(const Function &right) const;

      bool operator!=(const Function &right) const;


    //## Other Operations (specified)
      //## Operation: addCriteria%5628AAC70013
      void addCriteria (const Criteria& hCriteria);

      //## Operation: clear%5628D64502A9
      void clear ();

      //## Operation: getCriteria%5628EA56007A
      vector<Criteria>& getCriteria ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Name%562643C00270
      const string& getName () const
      {
        //## begin command::Function::getName%562643C00270.get preserve=no
        return m_strName;
        //## end command::Function::getName%562643C00270.get
      }

      void setName (const string& value)
      {
        //## begin command::Function::setName%562643C00270.set preserve=no
        m_strName = value;
        //## end command::Function::setName%562643C00270.set
      }


    // Additional Public Declarations
      //## begin command::Function%5625F72A0314.public preserve=yes
      //## end command::Function%5625F72A0314.public

  protected:
    // Additional Protected Declarations
      //## begin command::Function%5625F72A0314.protected preserve=yes
      //## end command::Function%5625F72A0314.protected

  private:
    // Additional Private Declarations
      //## begin command::Function%5625F72A0314.private preserve=yes
      //## end command::Function%5625F72A0314.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::Function::Name%562643C00270.attr preserve=no  public: string {U} 
      string m_strName;
      //## end command::Function::Name%562643C00270.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%5625F85E014F
      //## Role: Function::<m_hCriteria>%5625F86000C2
      //## begin command::Function::<m_hCriteria>%5625F86000C2.role preserve=no  public: command::Criteria {1 -> 0..nVHgN}
      vector<Criteria> m_hCriteria;
      //## end command::Function::<m_hCriteria>%5625F86000C2.role

    // Additional Implementation Declarations
      //## begin command::Function%5625F72A0314.implementation preserve=yes
      //## end command::Function%5625F72A0314.implementation

};

//## begin command::Function%5625F72A0314.postscript preserve=yes
//## end command::Function%5625F72A0314.postscript

} // namespace command

//## begin module%5625F79B0232.epilog preserve=yes
//## end module%5625F79B0232.epilog


#endif
