//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%44E387D4038A.cm preserve=no
//	$Date:   Jul 12 2019 16:00:04  $ $Author:   e1089842  $ $Revision:   1.9  $
//## end module%44E387D4038A.cm

//## begin module%44E387D4038A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%44E387D4038A.cp

//## Module: CXOSBC20%44E387D4038A; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV03.0A.R006\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC20.hpp

#ifndef CXOSBC20_h
#define CXOSBC20_h 1

//## begin module%44E387D4038A.additionalIncludes preserve=no
//## end module%44E387D4038A.additionalIncludes

//## begin module%44E387D4038A.includes preserve=yes
//## end module%44E387D4038A.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSBC16_h
#include "CXODBC16.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class ExportFile;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%44E387D4038A.declarations preserve=no
//## end module%44E387D4038A.declarations

//## begin module%44E387D4038A.additionalDeclarations preserve=yes
//## end module%44E387D4038A.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::Audit%442D8AA50222.preface preserve=yes
//## end command::Audit%442D8AA50222.preface

//## Class: Audit%442D8AA50222
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%442D8C1D0261;segment::Segment { -> F}

class DllExport Audit : public reusable::Object  //## Inherits: <unnamed>%442D8AF3031C
{
  //## begin command::Audit%442D8AA50222.initialDeclarations preserve=yes
  //## end command::Audit%442D8AA50222.initialDeclarations

  public:
    //## Constructors (generated)
      Audit();

    //## Constructors (specified)
      //## Operation: Audit%47F2220C03E7
      Audit (database::ExportFile* pExportFile);

      //## Operation: Audit%442D8B8A037A
      Audit (const string& strDX_FILE_TYPE, const string& strENTITY_TYPE, const string& strENTITY_ID, const string& strDATE_RECON, const string& strSCHED_TIME);

    //## Destructor (generated)
      virtual ~Audit();


    //## Other Operations (specified)
      //## Operation: add%442D8BAA0177
      void add (const char cSegment, segment::Segment* pSegment);

      //## Operation: complete%446C7F7600CF
      bool complete ();

      //## Operation: empty%456F069F00EA
      bool empty ();

      //## Operation: getDX_FILE_ID%5D28C9F20006
      const int& getDX_FILE_ID ();

      //## Operation: getDX_FILE_TYPE%5D28CABB03C1
      const reusable::string& getDX_FILE_TYPE ();

      //## Operation: isPresent%45AA937F009C
      bool isPresent ();

      //## Operation: read%4D093A2E03D0
      bool read (int iSEQ_NO, string& strDATA_BUFFER);

      //## Operation: release%480F275000C4
      void release ();

      //## Operation: replace%4468083B0271
      bool replace (int lSEQ_NO, const string& strDATA_BUFFER);

      //## Operation: report%442D8BE10280
      bool report (const char cType);

      //## Operation: setTemplate%442D8BB40148
      void setTemplate (const char** ppszTemplate);

      //## Operation: write%4D097DAE002E
      bool write (char *szDATA_BUFFER, int iBufferLen, int iSEQ_NO);

    // Additional Public Declarations
      //## begin command::Audit%442D8AA50222.public preserve=yes
      //## end command::Audit%442D8AA50222.public

  protected:
    // Additional Protected Declarations
      //## begin command::Audit%442D8AA50222.protected preserve=yes
      //## end command::Audit%442D8AA50222.protected

  private:
    // Additional Private Declarations
      //## begin command::Audit%442D8AA50222.private preserve=yes
      //## end command::Audit%442D8AA50222.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Template%442D8C43009C
      //## begin command::Audit::Template%442D8C43009C.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hTemplate;
      //## end command::Audit::Template%442D8C43009C.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%442D8BF70203
      //## Role: Audit::<m_pExportFile>%442D8BF8003E
      //## begin command::Audit::<m_pExportFile>%442D8BF8003E.role preserve=no  public: database::ExportFile { -> RFHgN}
      database::ExportFile *m_pExportFile;
      //## end command::Audit::<m_pExportFile>%442D8BF8003E.role

      //## Association: Connex Library::Command_CAT::<unnamed>%442D8D0A002E
      //## Role: Audit::<m_hXMLText>%442D8D0A0203
      //## begin command::Audit::<m_hXMLText>%442D8D0A0203.role preserve=no  public: command::XMLText { -> VHgN}
      XMLText m_hXMLText;
      //## end command::Audit::<m_hXMLText>%442D8D0A0203.role

    // Additional Implementation Declarations
      //## begin command::Audit%442D8AA50222.implementation preserve=yes
      //## end command::Audit%442D8AA50222.implementation

};

//## begin command::Audit%442D8AA50222.postscript preserve=yes
//## end command::Audit%442D8AA50222.postscript

} // namespace command

//## begin module%44E387D4038A.epilog preserve=yes
using namespace command;
//## end module%44E387D4038A.epilog


#endif
