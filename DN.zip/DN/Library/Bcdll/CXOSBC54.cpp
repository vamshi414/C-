//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%588D0B29019A.cm preserve=no
//## end module%588D0B29019A.cm

//## begin module%588D0B29019A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%588D0B29019A.cp

//## Module: CXOSBC54%588D0B29019A; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC54.cpp

//## begin module%588D0B29019A.additionalIncludes preserve=no
//## end module%588D0B29019A.additionalIncludes

//## begin module%588D0B29019A.includes preserve=yes
#include "CXODIF03.hpp"
//## end module%588D0B29019A.includes

#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBC54_h
#include "CXODBC54.hpp"
#endif


//## begin module%588D0B29019A.declarations preserve=no
//## end module%588D0B29019A.declarations

//## begin module%588D0B29019A.additionalDeclarations preserve=yes
//## end module%588D0B29019A.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::APIImportRecord 

APIImportRecord::APIImportRecord()
  //## begin APIImportRecord::APIImportRecord%588D09DB0266_const.hasinit preserve=no
      : m_iRETRY_MINUTES(15)
  //## end APIImportRecord::APIImportRecord%588D09DB0266_const.hasinit
  //## begin APIImportRecord::APIImportRecord%588D09DB0266_const.initialization preserve=yes
  //## end APIImportRecord::APIImportRecord%588D09DB0266_const.initialization
{
  //## begin command::APIImportRecord::APIImportRecord%588D09DB0266_const.body preserve=yes
   string strResetTime;
   if (IF::Extract::instance()->getSpec("IMPRETRY", strResetTime))
      m_iRETRY_MINUTES = atoi(strResetTime.c_str());
  //## end command::APIImportRecord::APIImportRecord%588D09DB0266_const.body
}


APIImportRecord::~APIImportRecord()
{
  //## begin command::APIImportRecord::~APIImportRecord%588D09DB0266_dest.body preserve=yes
  //## end command::APIImportRecord::~APIImportRecord%588D09DB0266_dest.body
}


APIImportRecord & APIImportRecord::operator=(const APIImportRecord &right)
{
  //## begin command::APIImportRecord::operator=%588D09DB0266_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_lQUEUE_ID = right.getQUEUE_ID();
   m_siSEQ_NO = right.getSEQ_NO();
   m_strTSTAMP_EVENT = right.getTSTAMP_EVENT();
   m_siRETRY_COUNT = right.getRETRY_COUNT();
   m_lCASE_ID = right.getCASE_ID();
   m_strDATA_BUFFER = right.getDATA_BUFFER();
   m_strREQ_TYPE = right.getREQ_TYPE();
   m_strAPI_STATE= right.getAPI_STATE();
   return *this;
  //## end command::APIImportRecord::operator=%588D09DB0266_assign.body
}



//## Other Operations (implementation)
void APIImportRecord::bind (reusable::Query& hQuery)
{
  //## begin command::APIImportRecord::bind%5898669E0273.body preserve=yes
   hQuery.bind("API_QUEUE_CONTROL", "QUEUE_ID", Column::LONG, &m_lQUEUE_ID);
   hQuery.bind("API_QUEUE_CONTROL", "RETRY_COUNT", Column::SHORT, &m_siRETRY_COUNT);
   hQuery.bind("API_QUEUE_CONTROL", "TSTAMP_EVENT", Column::STRING, &m_strTSTAMP_EVENT);
   hQuery.bind("API_QUEUE_CONTROL", "REQ_TYPE", Column::STRING, &m_strREQ_TYPE);
   hQuery.bind("API_QUEUE_CONTROL", "CASE_ID", Column::LONG, &m_lCASE_ID);
   hQuery.bind("API_QUEUE_CONTROL", "API_TYPE", Column::STRING, &m_strAPI_TYPE);
   hQuery.bind("API_QUEUE_CONTROL", "API_STATE", Column::STRING, &m_strAPI_STATE);
  //## end command::APIImportRecord::bind%5898669E0273.body
}

bool APIImportRecord::execute (const command::APIImportRecord& hAPIImportRecord)
{
  //## begin command::APIImportRecord::execute%588D106002FB.body preserve=yes
   *this = hAPIImportRecord;
   reusable::Table hTable("API_QUEUE_CONTROL");
   hTable.set("QUEUE_ID", m_lQUEUE_ID, true);
   hTable.set("API_STATE", "SP");
   auto_ptr<reusable::Statement> pUpdateStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("UpdateStatement"));
   if (!pUpdateStatement->execute(hTable))
      return false;

   Table hTable2("API_QEVENT_LOG");
   hTable2.set("QUEUE_ID", m_lQUEUE_ID);
   hTable2.set("TSTAMP_CREATED", Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   hTable2.set("TSTAMP_EVENT", m_strTSTAMP_EVENT);
   hTable2.set("API_STATE", "SP");
   hTable2.set("USER_ID", Extract::instance()->getName());
   hTable2.set("RETRY_COUNT", m_siRETRY_COUNT);
   hTable2.set("API_RESULT", " ");
   auto_ptr<reusable::Statement> pInsertStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("InsertStatement"));
   if (!pInsertStatement->execute(hTable2))
      return false;
   Database::instance()->commit();

   bool b = parse(hAPIImportRecord.getDATA_BUFFER());
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
   {
      Database::instance()->rollback();
      b = false;
   }
   hTable.set("API_STATE", (b) ? "AC" : "PE");
   hTable.set("API_RESULT", m_strAPI_RESULT);
   if (b)
   {
      hTable.set("TSTAMP_EVENT", Clock::instance()->getYYYYMMDDHHMMSSHN(true));
      hTable.set("CASE_ID", getCASE_ID());
   }
   else
   {
      m_siRETRY_COUNT++;
      string strDate(Clock::instance()->getDate());
      string strTime(Clock::instance()->getTime().substr(0, 6));
      Timestamp::adjust(strDate, strTime, m_iRETRY_MINUTES);
      string strTSTAMP_NEXT_PARSE = strDate.substr(0, 8);
      strTSTAMP_NEXT_PARSE += strTime;
      strTSTAMP_NEXT_PARSE += "00";
      hTable.set("TSTAMP_EVENT", strTSTAMP_NEXT_PARSE);
      hTable.set("RETRY_COUNT", m_siRETRY_COUNT);
      int iLen = 0;
      char szDupMsg[512];
      string strDupMsg = "API error -";
      strDupMsg.append("QUEUE_ID = %ld, TSTAMP_EVENT = %s ");
      strDupMsg.append
         ("CASE_ID = %ld, RETRY_COUNT = %d, API_RESULT = %s");
      iLen = snprintf(szDupMsg,sizeof(szDupMsg),strDupMsg.data(),
         m_lQUEUE_ID,
         m_strTSTAMP_EVENT.c_str(),
         m_lCASE_ID,
         m_siRETRY_COUNT,
         m_strAPI_RESULT.c_str());
      Trace::put(szDupMsg, iLen, true);
   }
   if (!pUpdateStatement->execute(hTable))
      return false;

   hTable2.reset();
   hTable2.set("QUEUE_ID", m_lQUEUE_ID);
   hTable2.set("TSTAMP_CREATED", Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   hTable2.set("TSTAMP_EVENT", m_strTSTAMP_EVENT);
   hTable2.set("API_STATE", (b) ? "AC" : "PE");
   hTable2.set("USER_ID", Extract::instance()->getName());
   hTable2.set("RETRY_COUNT", m_siRETRY_COUNT);
   hTable2.set("API_RESULT", m_strAPI_RESULT);
   if (!pInsertStatement->execute(hTable2))
      return false;

   return true;
  //## end command::APIImportRecord::execute%588D106002FB.body
}

bool APIImportRecord::parse (const string& strDATA_BUFFER)
{
  //## begin command::APIImportRecord::parse%588D10CF0209.body preserve=yes
   return true;
  //## end command::APIImportRecord::parse%588D10CF0209.body
}

void APIImportRecord::update (Subject* pSubject)
{
  //## begin command::APIImportRecord::update%588F52060321.body preserve=yes
  //## end command::APIImportRecord::update%588F52060321.body
}

// Additional Declarations
  //## begin command::APIImportRecord%588D09DB0266.declarations preserve=yes
  //## end command::APIImportRecord%588D09DB0266.declarations

} // namespace command

//## begin module%588D0B29019A.epilog preserve=yes
//## end module%588D0B29019A.epilog
