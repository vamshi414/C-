//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3681283C000E.cm preserve=no
//	$Date:   Nov 25 2014 10:33:50  $ $Author:   e1009839  $ $Revision:   1.3  $
//## end module%3681283C000E.cm

//## begin module%3681283C000E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3681283C000E.cp

//## Module: CXOSBC06%3681283C000E; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC06.hpp

#ifndef CXOSBC06_h
#define CXOSBC06_h 1

//## begin module%3681283C000E.additionalIncludes preserve=no
//## end module%3681283C000E.additionalIncludes

//## begin module%3681283C000E.includes preserve=yes
// $Date:   Nov 25 2014 10:33:50  $ $Author:   e1009839  $ $Revision:   1.3  $
//## end module%3681283C000E.includes

#ifndef CXOSRU09_h
#include "CXODRU09.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Column;

} // namespace reusable

//## begin module%3681283C000E.declarations preserve=no
//## end module%3681283C000E.declarations

//## begin module%3681283C000E.additionalDeclarations preserve=yes
//## end module%3681283C000E.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::CopyColumnNamesVisitor%368127A80016.preface preserve=yes
//## end command::CopyColumnNamesVisitor%368127A80016.preface

//## Class: CopyColumnNamesVisitor%368127A80016
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%368141B50282;reusable::Column { -> F}

class DllExport CopyColumnNamesVisitor : public reusable::QueryVisitor  //## Inherits: <unnamed>%36812920020B
{
  //## begin command::CopyColumnNamesVisitor%368127A80016.initialDeclarations preserve=yes
  //## end command::CopyColumnNamesVisitor%368127A80016.initialDeclarations

  public:
    //## Constructors (generated)
      CopyColumnNamesVisitor();

    //## Constructors (specified)
      //## Operation: CopyColumnNamesVisitor%368129790050
      CopyColumnNamesVisitor (char** ppsBuffer);

    //## Destructor (generated)
      virtual ~CopyColumnNamesVisitor();


    //## Other Operations (specified)
      //## Operation: visitColumn%3681295F0017
      virtual void visitColumn (reusable::Table* pTable, Column* pColumn);

    // Additional Public Declarations
      //## begin command::CopyColumnNamesVisitor%368127A80016.public preserve=yes
      //## end command::CopyColumnNamesVisitor%368127A80016.public

  protected:
    // Additional Protected Declarations
      //## begin command::CopyColumnNamesVisitor%368127A80016.protected preserve=yes
      //## end command::CopyColumnNamesVisitor%368127A80016.protected

  private:
    // Additional Private Declarations
      //## begin command::CopyColumnNamesVisitor%368127A80016.private preserve=yes
      //## end command::CopyColumnNamesVisitor%368127A80016.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%36812ACB0010
      //## begin command::CopyColumnNamesVisitor::Buffer%36812ACB0010.attr preserve=no  private: char** {U} 
      char** m_ppsBuffer;
      //## end command::CopyColumnNamesVisitor::Buffer%36812ACB0010.attr

    // Additional Implementation Declarations
      //## begin command::CopyColumnNamesVisitor%368127A80016.implementation preserve=yes
      //## end command::CopyColumnNamesVisitor%368127A80016.implementation

};

//## begin command::CopyColumnNamesVisitor%368127A80016.postscript preserve=yes
//## end command::CopyColumnNamesVisitor%368127A80016.postscript

} // namespace command

//## begin module%3681283C000E.epilog preserve=yes
using namespace command;
//## end module%3681283C000E.epilog


#endif
