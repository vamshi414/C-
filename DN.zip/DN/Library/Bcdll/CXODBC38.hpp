//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4F6B40EE0253.cm preserve=no
//	$Date:   Oct 04 2016 07:35:06  $ $Author:   e1009839  $
//	$Revision:   1.4  $
//## end module%4F6B40EE0253.cm

//## begin module%4F6B40EE0253.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4F6B40EE0253.cp

//## Module: CXOSBC38%4F6B40EE0253; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC38.hpp

#ifndef CXOSBC38_h
#define CXOSBC38_h 1

//## begin module%4F6B40EE0253.additionalIncludes preserve=no
//## end module%4F6B40EE0253.additionalIncludes

//## begin module%4F6B40EE0253.includes preserve=yes
#include <map>
//## end module%4F6B40EE0253.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSBC37_h
#include "CXODBC37.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;

} // namespace reusable

//## begin module%4F6B40EE0253.declarations preserve=no
//## end module%4F6B40EE0253.declarations

//## begin module%4F6B40EE0253.additionalDeclarations preserve=yes
//## end module%4F6B40EE0253.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::Template%4F6B3DC901A1.preface preserve=yes
//## end command::Template%4F6B3DC901A1.preface

//## Class: Template%4F6B3DC901A1
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4F6B3F820217;reusable::Buffer { -> F}
//## Uses: <unnamed>%4F6B4F5B0280;segment::Segment { -> }
//## Uses: <unnamed>%4F6C07270312;IF::FlatFile { -> F}

class DllExport Template : public reusable::Observer  //## Inherits: <unnamed>%57EEA01601CF
{
  //## begin command::Template%4F6B3DC901A1.initialDeclarations preserve=yes
  //## end command::Template%4F6B3DC901A1.initialDeclarations

  public:
    //## Constructors (generated)
      Template();

    //## Destructor (generated)
      virtual ~Template();


    //## Other Operations (specified)
      //## Operation: getList%4F72D02E03B4
      map<string, TemplateToken, less<string> >* getList ();

      //## Operation: getSegment%4F6B4F820194
      virtual segment::Segment* getSegment (char cType);

      //## Operation: mapToken%4F6B3DC901A2
      virtual int mapToken (const string& strToken, string& strValue);

      //## Operation: mapToken%4F71948500FC
      virtual int mapToken (map<string,TemplateToken,less <string> >::iterator pToken, string& strValue);

      //## Operation: read%4F6B3DC901C3
      virtual bool read ();

      //## Operation: trim%4FEC9984001C
      void trim (string& strValue);

      //## Operation: update%57EEA02800B9
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin command::Template%4F6B3DC901A1.public preserve=yes
      //## end command::Template%4F6B3DC901A1.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Member%4F6C05EE00DF
      //## begin command::Template::Member%4F6C05EE00DF.attr preserve=no  public: string {U} 
      string m_strMember;
      //## end command::Template::Member%4F6C05EE00DF.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%4F6B3DC901C5
      //## Role: Template::<m_hTemplateToken>%4F6B3DC901C6
      //## Qualifier: name%4F6B40910229; string
      //## begin command::Template::<m_hTemplateToken>%4F6B3DC901C6.role preserve=no  protected: command::TemplateToken { -> VHgN}
      map<string, TemplateToken, less<string> > m_hTemplateToken;
      //## end command::Template::<m_hTemplateToken>%4F6B3DC901C6.role

    // Additional Protected Declarations
      //## begin command::Template%4F6B3DC901A1.protected preserve=yes
      //## end command::Template%4F6B3DC901A1.protected

  private:
    // Additional Private Declarations
      //## begin command::Template%4F6B3DC901A1.private preserve=yes
      //## end command::Template%4F6B3DC901A1.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin command::Template%4F6B3DC901A1.implementation preserve=yes
      //## end command::Template%4F6B3DC901A1.implementation

};

//## begin command::Template%4F6B3DC901A1.postscript preserve=yes
//## end command::Template%4F6B3DC901A1.postscript

} // namespace command

//## begin module%4F6B40EE0253.epilog preserve=yes
using namespace command;
//## end module%4F6B40EE0253.epilog


#endif
