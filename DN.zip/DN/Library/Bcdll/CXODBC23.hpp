//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%462DCEE6022D.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%462DCEE6022D.cm

//## begin module%462DCEE6022D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%462DCEE6022D.cp

//## Module: CXOSBC23%462DCEE6022D; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\ConnexPlatform\Server\Library\Bcdll\CXODBC23.hpp

#ifndef CXOSBC23_h
#define CXOSBC23_h 1

//## begin module%462DCEE6022D.additionalIncludes preserve=no
//## end module%462DCEE6022D.additionalIncludes

//## begin module%462DCEE6022D.includes preserve=yes
#ifdef _WIN32
#include "windows.h"
#include "Winldap.h"
#define SUPPORTLDAP
#include "winber.h"
#else
#ifdef MVS
#include "ldap.h"
#define SUPPORTLDAP
#endif
#ifdef SOLARISAMD64
#include "ldap.h"
#define SUPPORTLDAP
#endif
#ifdef _UNIX
#ifdef _AIX
#define LDAP long
#else
#define SUPPORTLDAP
#define LDAP_DEPRECATED 1
#include "ldap.h"
#endif
#endif
#endif 
//## end module%462DCEE6022D.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Console;
} // namespace IF

namespace reusable {
class Buffer;
class Statement;
} // namespace reusable

namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace IF {
class AdvancedEncryptionStandard;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
} // namespace timer

namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Security;

} // namespace command

//## begin module%462DCEE6022D.declarations preserve=no
//## end module%462DCEE6022D.declarations

//## begin module%462DCEE6022D.additionalDeclarations preserve=yes
//## end module%462DCEE6022D.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::OpenLDAP%462DCEB90092.preface preserve=yes
//## end command::OpenLDAP%462DCEB90092.preface

//## Class: OpenLDAP%462DCEB90092
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%462DCFF302EE;IF::Console { -> F}
//## Uses: <unnamed>%462DD01302C1;IF::Trace { -> F}
//## Uses: <unnamed>%462DD01802B2;IF::Extract { -> F}
//## Uses: <unnamed>%463170AC013D;timer::Date { -> F}
//## Uses: <unnamed>%4641FBB60242;monitor::UseCase { -> F}
//## Uses: <unnamed>%5C934E73035B;Security { -> F}
//## Uses: <unnamed>%5C93540D020F;reusable::Query { -> F}
//## Uses: <unnamed>%5C93544C027F;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5C9355C2021E;database::Database { -> F}
//## Uses: <unnamed>%5C9355C70330;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5C9356A200BE;reusable::Statement { -> F}
//## Uses: <unnamed>%5C9356F502A7;IF::AdvancedEncryptionStandard { -> F}
//## Uses: <unnamed>%5CB05613018F;reusable::Buffer { -> F}

class DllExport OpenLDAP : public reusable::Object  //## Inherits: <unnamed>%462DCFE602CE
{
  //## begin command::OpenLDAP%462DCEB90092.initialDeclarations preserve=yes
  //## end command::OpenLDAP%462DCEB90092.initialDeclarations

  public:
    //## Constructors (generated)
      OpenLDAP();

    //## Destructor (generated)
      virtual ~OpenLDAP();


    //## Other Operations (specified)
      //## Operation: instance%462DD1CA02DD
      static OpenLDAP* instance ();

      //## Operation: logon%462DD56F00CE
      bool logon (const string &strUSER_ID, const string &strPassword, const string &strNewPassword, string &strResult);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Active%5CAB49B3017B
      const bool& isActive () const
      {
        //## begin command::OpenLDAP::isActive%5CAB49B3017B.get preserve=no
        return m_bActive;
        //## end command::OpenLDAP::isActive%5CAB49B3017B.get
      }


      //## Attribute: DatePasswordExpires%463EB38B0340
      const reusable::string& getDatePasswordExpires () const
      {
        //## begin command::OpenLDAP::getDatePasswordExpires%463EB38B0340.get preserve=no
        return m_strDatePasswordExpires;
        //## end command::OpenLDAP::getDatePasswordExpires%463EB38B0340.get
      }


    // Additional Public Declarations
      //## begin command::OpenLDAP%462DCEB90092.public preserve=yes
      //## end command::OpenLDAP%462DCEB90092.public

  protected:
    // Additional Protected Declarations
      //## begin command::OpenLDAP%462DCEB90092.protected preserve=yes
      //## end command::OpenLDAP%462DCEB90092.protected

  private:

    //## Other Operations (specified)
      //## Operation: closeAndGetResult%5C8A2C160127
      bool closeAndGetResult (LDAP* pLDAP, const string& strMessage, const string strResult, const int iResultCode, string& strFinalResult);

      //## Operation: getSpec%621807DF024E
      void getSpec (vector<string>& hExtractValues, const reusable::string&  strParam, reusable::string& strValue);

      //## Operation: getLDAPPasswordExpirationDate%5C7D0F1001E2
      reusable::string getLDAPPasswordExpirationDate (const string& strAdPwdExp);

    // Additional Private Declarations
      //## begin command::OpenLDAP%462DCEB90092.private preserve=yes
      //## end command::OpenLDAP%462DCEB90092.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::OpenLDAP::Active%5CAB49B3017B.attr preserve=no  public: bool {U} 
      bool m_bActive;
      //## end command::OpenLDAP::Active%5CAB49B3017B.attr

      //## Attribute: ADAttribute%5C7904CD0341
      //## begin command::OpenLDAP::ADAttribute%5C7904CD0341.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strADAttribute;
      //## end command::OpenLDAP::ADAttribute%5C7904CD0341.attr

      //## begin command::OpenLDAP::DatePasswordExpires%463EB38B0340.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strDatePasswordExpires;
      //## end command::OpenLDAP::DatePasswordExpires%463EB38B0340.attr

      //## Attribute: DNBase%5C78F9C4035A
      //## begin command::OpenLDAP::DNBase%5C78F9C4035A.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strDNBase;
      //## end command::OpenLDAP::DNBase%5C78F9C4035A.attr

      //## Attribute: DNEntry%4630AE650246
      //## begin command::OpenLDAP::DNEntry%4630AE650246.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strDNEntry;
      //## end command::OpenLDAP::DNEntry%4630AE650246.attr

      //## Attribute: Filter%5C7904730153
      //## begin command::OpenLDAP::Filter%5C7904730153.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strFilter;
      //## end command::OpenLDAP::Filter%5C7904730153.attr

      //## Attribute: FilterAttribute%5C7E198200BC
      //## begin command::OpenLDAP::FilterAttribute%5C7E198200BC.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strFilterAttribute;
      //## end command::OpenLDAP::FilterAttribute%5C7E198200BC.attr

      //## Attribute: HostName%462DE01A02C2
      //## begin command::OpenLDAP::HostName%462DE01A02C2.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strHostName;
      //## end command::OpenLDAP::HostName%462DE01A02C2.attr

      //## Attribute: Instance%462DD24C0129
      //## begin command::OpenLDAP::Instance%462DD24C0129.attr preserve=no  private: static OpenLDAP* {V} 0
      static OpenLDAP* m_pInstance;
      //## end command::OpenLDAP::Instance%462DD24C0129.attr

      //## Attribute: LdAdminPassword%5CB0831D023D
      //## begin command::OpenLDAP::LdAdminPassword%5CB0831D023D.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strLdAdminPassword;
      //## end command::OpenLDAP::LdAdminPassword%5CB0831D023D.attr

      //## Attribute: PortNumber%462DDFD10217
      //## begin command::OpenLDAP::PortNumber%462DDFD10217.attr preserve=no  private: int {V} 
      int m_iPortNumber;
      //## end command::OpenLDAP::PortNumber%462DDFD10217.attr

      //## Attribute: PWDInterval%5C78FA07018E
      //## begin command::OpenLDAP::PWDInterval%5C78FA07018E.attr preserve=no  private: int {U} 
      int m_iPWDInterval;
      //## end command::OpenLDAP::PWDInterval%5C78FA07018E.attr

      //## Attribute: SecureFlag%621800120364
      //## begin command::OpenLDAP::SecureFlag%621800120364.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strSecureFlag;
      //## end command::OpenLDAP::SecureFlag%621800120364.attr

      //## Attribute: StartTLSFlag%6217FD940097
      //## begin command::OpenLDAP::StartTLSFlag%6217FD940097.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strStartTLSFlag;
      //## end command::OpenLDAP::StartTLSFlag%6217FD940097.attr

    // Additional Implementation Declarations
      //## begin command::OpenLDAP%462DCEB90092.implementation preserve=yes
      //## end command::OpenLDAP%462DCEB90092.implementation

};

//## begin command::OpenLDAP%462DCEB90092.postscript preserve=yes
//## end command::OpenLDAP%462DCEB90092.postscript

} // namespace command

//## begin module%462DCEE6022D.epilog preserve=yes
using namespace command;
//## end module%462DCEE6022D.epilog


#endif
