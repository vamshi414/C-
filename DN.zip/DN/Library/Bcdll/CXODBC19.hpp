//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4242F9A80251.cm preserve=no
//	$Date:   Apr 23 2013 12:59:12  $ $Author:   e1024360  $
//	$Revision:   1.12  $
//## end module%4242F9A80251.cm

//## begin module%4242F9A80251.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4242F9A80251.cp

//## Module: CXOSBC19%4242F9A80251; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.3B.R001\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC19.hpp

#ifndef CXOSBC19_h
#define CXOSBC19_h 1

//## begin module%4242F9A80251.additionalIncludes preserve=no
//## end module%4242F9A80251.additionalIncludes

//## begin module%4242F9A80251.includes preserve=yes
#include <vector>
#define DONT_RETRY 4
//## end module%4242F9A80251.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Console;
} // namespace IF

namespace reusable {
class SearchCondition;
class Table;
class Statement;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
} // namespace timer

namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Audit;
} // namespace command

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ImportReportAuditSegment;

} // namespace segment

//## begin module%4242F9A80251.declarations preserve=no
//## end module%4242F9A80251.declarations

//## begin module%4242F9A80251.additionalDeclarations preserve=yes
//## end module%4242F9A80251.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::ImportTransaction%4242F95E03D8.preface preserve=yes
//## end command::ImportTransaction%4242F95E03D8.preface

//## Class: ImportTransaction%4242F95E03D8
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%424834DB009C;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%424834DE01D4;reusable::Table { -> F}
//## Uses: <unnamed>%424834E00000;reusable::Statement { -> F}
//## Uses: <unnamed>%4248434100EA;timer::Clock { -> F}
//## Uses: <unnamed>%424843EB0167;database::Database { -> F}
//## Uses: <unnamed>%431600DB0138;timer::Date { -> F}
//## Uses: <unnamed>%446B2DBB03C1;reusable::Query { -> F}
//## Uses: <unnamed>%446B2DC400B1;Audit { -> F}
//## Uses: <unnamed>%446B2DC60227;IF::Extract { -> F}
//## Uses: <unnamed>%446B2FDB02BA;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%45CA498A01C2;IF::Console { -> F}
//## Uses: <unnamed>%4720882000AB;segment::ImportReportAuditSegment { -> F}
//## Uses: <unnamed>%4A8B17E20303;reusable::SearchCondition { -> F}

class DllExport ImportTransaction : public reusable::Observer  //## Inherits: <unnamed>%4242F9890222
{
  //## begin command::ImportTransaction%4242F95E03D8.initialDeclarations preserve=yes
  //## end command::ImportTransaction%4242F95E03D8.initialDeclarations

  public:
    //## Constructors (generated)
      ImportTransaction();

      ImportTransaction(const ImportTransaction &right);

    //## Constructors (specified)
      //## Operation: ImportTransaction%4720E6D3038A
      ImportTransaction (const char* pszDX_FILE_TYPE);

    //## Destructor (generated)
      virtual ~ImportTransaction();

    //## Assignment Operation (generated)
      ImportTransaction & operator=(const ImportTransaction &right);


    //## Other Operations (specified)
      //## Operation: addSegments%47234655033C
      virtual void addSegments (command::Audit& hAudit);

      //## Operation: bind%50479A5C0293
      void bind (reusable::Query& hQuery);

      //## Operation: execute%42482E110222
      bool execute (const ImportTransaction& hImportTransaction);

      //## Operation: parse%4242FDDC02CE
      virtual bool parse (const vector<string>& hDATA_BUFFER);

      //## Operation: setENTITY_ID%5176A0A102E0
      virtual void setENTITY_ID ();

      //## Operation: update%45E49D6F00B3
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: DATE_RECON%446453FF012B
      const string& getDATE_RECON () const
      {
        //## begin command::ImportTransaction::getDATE_RECON%446453FF012B.get preserve=no
        return m_strDATE_RECON;
        //## end command::ImportTransaction::getDATE_RECON%446453FF012B.get
      }


      //## Attribute: DI_FILE_ID%431D82E403D8
      const int& getDI_FILE_ID () const
      {
        //## begin command::ImportTransaction::getDI_FILE_ID%431D82E403D8.get preserve=no
        return m_lDI_FILE_ID;
        //## end command::ImportTransaction::getDI_FILE_ID%431D82E403D8.get
      }


      //## Attribute: DI_FILE_TYPE%5048ADFE0286
      const string& getDI_FILE_TYPE () const
      {
        //## begin command::ImportTransaction::getDI_FILE_TYPE%5048ADFE0286.get preserve=no
        return m_strDI_FILE_TYPE;
        //## end command::ImportTransaction::getDI_FILE_TYPE%5048ADFE0286.get
      }


      //## Attribute: DI_PATH%50489FCF0284
      const string& getDI_PATH () const
      {
        //## begin command::ImportTransaction::getDI_PATH%50489FCF0284.get preserve=no
        return m_strDI_PATH;
        //## end command::ImportTransaction::getDI_PATH%50489FCF0284.get
      }

      void setDI_PATH (const string& value)
      {
        //## begin command::ImportTransaction::setDI_PATH%50489FCF0284.set preserve=no
        m_strDI_PATH = value;
        //## end command::ImportTransaction::setDI_PATH%50489FCF0284.set
      }


      //## Attribute: DX_FILE_TYPE%4720E68102FD
      const string& getDX_FILE_TYPE () const
      {
        //## begin command::ImportTransaction::getDX_FILE_TYPE%4720E68102FD.get preserve=no
        return m_strDX_FILE_TYPE;
        //## end command::ImportTransaction::getDX_FILE_TYPE%4720E68102FD.get
      }


      //## Attribute: DATA_BUFFER%5047D0B600E1
      vector<string>& getDATA_BUFFER ()
      {
        //## begin command::ImportTransaction::getDATA_BUFFER%5047D0B600E1.get preserve=no
        return m_hDATA_BUFFER;
        //## end command::ImportTransaction::getDATA_BUFFER%5047D0B600E1.get
      }

      void setDATA_BUFFER (const vector<string>& value)
      {
        //## begin command::ImportTransaction::setDATA_BUFFER%5047D0B600E1.set preserve=no
        m_hDATA_BUFFER = value;
        //## end command::ImportTransaction::setDATA_BUFFER%5047D0B600E1.set
      }


      //## Attribute: SCHED_TIME%4464541A00FC
      const string& getSCHED_TIME () const
      {
        //## begin command::ImportTransaction::getSCHED_TIME%4464541A00FC.get preserve=no
        return m_strSCHED_TIME;
        //## end command::ImportTransaction::getSCHED_TIME%4464541A00FC.get
      }

      void setSCHED_TIME (const string& value)
      {
        //## begin command::ImportTransaction::setSCHED_TIME%4464541A00FC.set preserve=no
        m_strSCHED_TIME = value;
        //## end command::ImportTransaction::setSCHED_TIME%4464541A00FC.set
      }


      //## Attribute: TRANSACTION_NO%431D82E50177
      const int& getTRANSACTION_NO () const
      {
        //## begin command::ImportTransaction::getTRANSACTION_NO%431D82E50177.get preserve=no
        return m_lTRANSACTION_NO;
        //## end command::ImportTransaction::getTRANSACTION_NO%431D82E50177.get
      }


      //## Attribute: TSTAMP_RETRY_COUNT%461CBD5D01E0
      const int& getTSTAMP_RETRY_COUNT () const
      {
        //## begin command::ImportTransaction::getTSTAMP_RETRY_COUNT%461CBD5D01E0.get preserve=no
        return m_lTSTAMP_RETRY_COUNT;
        //## end command::ImportTransaction::getTSTAMP_RETRY_COUNT%461CBD5D01E0.get
      }

      void setTSTAMP_RETRY_COUNT (const int& value)
      {
        //## begin command::ImportTransaction::setTSTAMP_RETRY_COUNT%461CBD5D01E0.set preserve=no
        m_lTSTAMP_RETRY_COUNT = value;
        //## end command::ImportTransaction::setTSTAMP_RETRY_COUNT%461CBD5D01E0.set
      }


      //## Attribute: TSTAMP_INITIATED%5048AE65005A
      const string& getTSTAMP_INITIATED () const
      {
        //## begin command::ImportTransaction::getTSTAMP_INITIATED%5048AE65005A.get preserve=no
        return m_strTSTAMP_INITIATED;
        //## end command::ImportTransaction::getTSTAMP_INITIATED%5048AE65005A.get
      }

      void setTSTAMP_INITIATED (const string& value)
      {
        //## begin command::ImportTransaction::setTSTAMP_INITIATED%5048AE65005A.set preserve=no
        m_strTSTAMP_INITIATED = value;
        //## end command::ImportTransaction::setTSTAMP_INITIATED%5048AE65005A.set
      }


    // Additional Public Declarations
      //## begin command::ImportTransaction%4242F95E03D8.public preserve=yes
      //## end command::ImportTransaction%4242F95E03D8.public
  protected:

    //## Other Operations (specified)
      //## Operation: endAudit%45824B09035F
      virtual bool endAudit (int lTSTAMP_RETRY_COUNT);

      //## Operation: getIMPORT_KEY%47208B7603C8
      const string& getIMPORT_KEY (short int siSEQ_NO = 0);

      //## Operation: getREJECT_CODES%471CC399029F
      const string& getREJECT_CODES (short int siSEQ_NO = 0);

      //## Operation: setDetail%472347EA02FD
      void setDetail (const char* pszDetail);

      //## Operation: setHeading%472347D901F4
      void setHeading (const char* pszHeading);

      //## Operation: setIMPORT_KEY%47208B840271
      void setIMPORT_KEY (const string& strIMPORT_KEY, short int siSEQ_NO = 0);

      //## Operation: setREJECT_CODES%471CC33D02DE
      void setREJECT_CODES (const string& strREJECT_CODES, short int siSEQ_NO = 0);

      //## Operation: writeAudit%47210559037A
      virtual bool writeAudit ();

    // Data Members for Class Attributes

      //## begin command::ImportTransaction::DATE_RECON%446453FF012B.attr preserve=no  public: string {V} 
      string m_strDATE_RECON;
      //## end command::ImportTransaction::DATE_RECON%446453FF012B.attr

      //## begin command::ImportTransaction::DI_FILE_ID%431D82E403D8.attr preserve=no  public: int {V} 0
      int m_lDI_FILE_ID;
      //## end command::ImportTransaction::DI_FILE_ID%431D82E403D8.attr

      //## begin command::ImportTransaction::DI_PATH%50489FCF0284.attr preserve=no  public: string {V} 
      string m_strDI_PATH;
      //## end command::ImportTransaction::DI_PATH%50489FCF0284.attr

      //## begin command::ImportTransaction::DATA_BUFFER%5047D0B600E1.attr preserve=no  public: vector<string> {V} 
      vector<string> m_hDATA_BUFFER;
      //## end command::ImportTransaction::DATA_BUFFER%5047D0B600E1.attr

      //## Attribute: ENTITY_ID%5176A03D0143
      //## begin command::ImportTransaction::ENTITY_ID%5176A03D0143.attr preserve=no  private: string {U} 
      string m_strENTITY_ID;
      //## end command::ImportTransaction::ENTITY_ID%5176A03D0143.attr

      //## begin command::ImportTransaction::SCHED_TIME%4464541A00FC.attr preserve=no  public: string {V} 
      string m_strSCHED_TIME;
      //## end command::ImportTransaction::SCHED_TIME%4464541A00FC.attr

      //## Attribute: SEQ_NO%471CCB3A037A
      //## begin command::ImportTransaction::SEQ_NO%471CCB3A037A.attr preserve=no  protected: short int {VA} 0
      short int m_siSEQ_NO;
      //## end command::ImportTransaction::SEQ_NO%471CCB3A037A.attr

      //## begin command::ImportTransaction::TSTAMP_RETRY_COUNT%461CBD5D01E0.attr preserve=no  public: int {V} 0
      int m_lTSTAMP_RETRY_COUNT;
      //## end command::ImportTransaction::TSTAMP_RETRY_COUNT%461CBD5D01E0.attr

      //## begin command::ImportTransaction::TSTAMP_INITIATED%5048AE65005A.attr preserve=no  public: string {U} 
      string m_strTSTAMP_INITIATED;
      //## end command::ImportTransaction::TSTAMP_INITIATED%5048AE65005A.attr

    // Additional Protected Declarations
      //## begin command::ImportTransaction%4242F95E03D8.protected preserve=yes
      //## end command::ImportTransaction%4242F95E03D8.protected

  private:
    // Additional Private Declarations
      //## begin command::ImportTransaction%4242F95E03D8.private preserve=yes
      //## end command::ImportTransaction%4242F95E03D8.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Detail%472345D003C8
      //## begin command::ImportTransaction::Detail%472345D003C8.attr preserve=no  public: string {V} 
      string m_strDetail;
      //## end command::ImportTransaction::Detail%472345D003C8.attr

      //## begin command::ImportTransaction::DI_FILE_TYPE%5048ADFE0286.attr preserve=no  public: string {V} 
      string m_strDI_FILE_TYPE;
      //## end command::ImportTransaction::DI_FILE_TYPE%5048ADFE0286.attr

      //## begin command::ImportTransaction::DX_FILE_TYPE%4720E68102FD.attr preserve=no  public: string {V} 
      string m_strDX_FILE_TYPE;
      //## end command::ImportTransaction::DX_FILE_TYPE%4720E68102FD.attr

      //## Attribute: Heading%472345A701E4
      //## begin command::ImportTransaction::Heading%472345A701E4.attr preserve=no  public: string {V} 
      string m_strHeading;
      //## end command::ImportTransaction::Heading%472345A701E4.attr

      //## Attribute: IMPORT_KEY%4318405103D8
      //## begin command::ImportTransaction::IMPORT_KEY%4318405103D8.attr preserve=no  public: vector<string> {V} 
      vector<string> m_hIMPORT_KEY;
      //## end command::ImportTransaction::IMPORT_KEY%4318405103D8.attr

      //## Attribute: REJECT_CODES%428CA74903D8
      //## begin command::ImportTransaction::REJECT_CODES%428CA74903D8.attr preserve=no  public: vector<string> {V} 
      vector<string> m_hREJECT_CODES;
      //## end command::ImportTransaction::REJECT_CODES%428CA74903D8.attr

      //## begin command::ImportTransaction::TRANSACTION_NO%431D82E50177.attr preserve=no  public: int {V} 0
      int m_lTRANSACTION_NO;
      //## end command::ImportTransaction::TRANSACTION_NO%431D82E50177.attr

    // Additional Implementation Declarations
      //## begin command::ImportTransaction%4242F95E03D8.implementation preserve=yes
      //## end command::ImportTransaction%4242F95E03D8.implementation

};

//## begin command::ImportTransaction%4242F95E03D8.postscript preserve=yes
//## end command::ImportTransaction%4242F95E03D8.postscript

} // namespace command

//## begin module%4242F9A80251.epilog preserve=yes
using namespace command;
//## end module%4242F9A80251.epilog


#endif
