//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%456F2ECC003E.cm preserve=no
//	$Date:   18 Jan 2018 13:52:16  $ $Author:   e1009839  $ $Revision:   1.3  $
//## end module%456F2ECC003E.cm

//## begin module%456F2ECC003E.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%456F2ECC003E.cp

//## Module: CXOSBC22%456F2ECC003E; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC22.hpp

#ifndef CXOSBC22_h
#define CXOSBC22_h 1

//## begin module%456F2ECC003E.additionalIncludes preserve=no
//## end module%456F2ECC003E.additionalIncludes

//## begin module%456F2ECC003E.includes preserve=yes
//## end module%456F2ECC003E.includes

#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;

} // namespace segment

//## begin module%456F2ECC003E.declarations preserve=no
//## end module%456F2ECC003E.declarations

//## begin module%456F2ECC003E.additionalDeclarations preserve=yes
//## end module%456F2ECC003E.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::HandshakeCommand%456F2E4E00AB.preface preserve=yes
//## end command::HandshakeCommand%456F2E4E00AB.preface

//## Class: HandshakeCommand%456F2E4E00AB
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%456F332702DE;database::GlobalContext { -> F}
//## Uses: <unnamed>%456F33DF000F;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%4581CAFF033C;IF::Extract { -> F}

class DllExport HandshakeCommand : public ClientCommand  //## Inherits: <unnamed>%456F2E5A037A
{
  //## begin command::HandshakeCommand%456F2E4E00AB.initialDeclarations preserve=yes
  //## end command::HandshakeCommand%456F2E4E00AB.initialDeclarations

  public:
    //## Constructors (generated)
      HandshakeCommand();

    //## Constructors (specified)
      //## Operation: HandshakeCommand%4574FB34015B
      HandshakeCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~HandshakeCommand();


    //## Other Operations (specified)
      //## Operation: execute%456F2F700186
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: deport%4581C9940167
      //	Export this command into a message buffer.
      //## Semantics:
      //	1. Call Segment::deport for each segment that is present
      //	in this command.
      //## Postconditions:
      //	1. The provided buffer pointer will point to the byte
      //	following the last segment exported.
      int deport (char** ppsBuffer);

      //## Operation: instance%456F3206029F
      static HandshakeCommand* instance ();

    // Additional Public Declarations
      //## begin command::HandshakeCommand%456F2E4E00AB.public preserve=yes
      //## end command::HandshakeCommand%456F2E4E00AB.public

  protected:
    // Additional Protected Declarations
      //## begin command::HandshakeCommand%456F2E4E00AB.protected preserve=yes
      //## end command::HandshakeCommand%456F2E4E00AB.protected

  private:
    // Additional Private Declarations
      //## begin command::HandshakeCommand%456F2E4E00AB.private preserve=yes
      //## end command::HandshakeCommand%456F2E4E00AB.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%456F32120251
      //## begin command::HandshakeCommand::Instance%456F32120251.attr preserve=no  private: static HandshakeCommand* {V} 0
      static HandshakeCommand* m_pInstance;
      //## end command::HandshakeCommand::Instance%456F32120251.attr

    // Additional Implementation Declarations
      //## begin command::HandshakeCommand%456F2E4E00AB.implementation preserve=yes
      //## end command::HandshakeCommand%456F2E4E00AB.implementation

};

//## begin command::HandshakeCommand%456F2E4E00AB.postscript preserve=yes
//## end command::HandshakeCommand%456F2E4E00AB.postscript

} // namespace command

//## begin module%456F2ECC003E.epilog preserve=yes
using namespace command;
//## end module%456F2ECC003E.epilog


#endif
