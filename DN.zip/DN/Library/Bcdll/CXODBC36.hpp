//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4DC02E8A000C.cm preserve=no
//## end module%4DC02E8A000C.cm

//## begin module%4DC02E8A000C.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4DC02E8A000C.cp

//## Module: CXOSBC36%4DC02E8A000C; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC36.hpp

#ifndef CXOSBC36_h
#define CXOSBC36_h 1

//## begin module%4DC02E8A000C.additionalIncludes preserve=no
//## end module%4DC02E8A000C.additionalIncludes

//## begin module%4DC02E8A000C.includes preserve=yes
//## end module%4DC02E8A000C.includes

#ifndef CXOSRU20_h
#include "CXODRU20.hpp"
#endif
#ifndef CXOSBC34_h
#include "CXODBC34.hpp"
#endif
#ifndef CXOSBC16_h
#include "CXODBC16.hpp"
#endif
#ifndef CXOSBC15_h
#include "CXODBC15.hpp"
#endif
#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class Query;
class FormatSelectVisitor;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
} // namespace IF

namespace reusable {
class Format;
} // namespace reusable

namespace IF {
class Trace;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
class SOAPSegment;
class TextSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Security;
class User;
class XMLHandler;
} // namespace command

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class AsRoleRelation;
} // namespace usersegment

//## Modelname: Connex Library::SecurityWrapper_CAT (SWDLL)%4A09A922013D
namespace securitywrapper {
class SecurityWrapper;

} // namespace securitywrapper

//## begin module%4DC02E8A000C.declarations preserve=no
//## end module%4DC02E8A000C.declarations

//## begin module%4DC02E8A000C.additionalDeclarations preserve=yes
//## end module%4DC02E8A000C.additionalDeclarations


namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::SOAPCommand%4DC02CEB0096.preface preserve=yes
//## end command::SOAPCommand%4DC02CEB0096.preface

//## Class: SOAPCommand%4DC02CEB0096
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4DC043B401EE;IF::Trace { -> F}
//## Uses: <unnamed>%4DC043DD0056;reusable::Buffer { -> F}
//## Uses: <unnamed>%4DC81EE50379;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%519CFC4003D9;IF::CodeTable { -> F}
//## Uses: <unnamed>%51B9DF3000C6;database::Database { -> F}
//## Uses: <unnamed>%52C739310389;Security { -> F}
//## Uses: <unnamed>%5305FE890255;securitywrapper::SecurityWrapper { -> F}
//## Uses: <unnamed>%5412E79100D5;reusable::FormatSelectVisitor { -> F}
//## Uses: <unnamed>%5412E7AE0224;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5412E84201C5;reusable::Query { -> F}
//## Uses: <unnamed>%5412E9190032;IF::Extract { -> F}
//## Uses: <unnamed>%5412E9610198;segment::SOAPSegment { -> F}
//## Uses: <unnamed>%5C6B0B680367;usersegment::AsRoleRelation { -> F}
//## Uses: <unnamed>%65CE1D950315;reusable::Format { -> F}
//## Uses: <unnamed>%65CE1E090183;User { -> F}

class DllExport SOAPCommand : public ClientCommand  //## Inherits: <unnamed>%4DC02F420394
{
  //## begin command::SOAPCommand%4DC02CEB0096.initialDeclarations preserve=yes
  //## end command::SOAPCommand%4DC02CEB0096.initialDeclarations

  public:
    //## Constructors (generated)
      SOAPCommand();

    //## Constructors (specified)
      //## Operation: SOAPCommand%4DC04DAF03D3
      SOAPCommand (const char* pszMessageID, const char* pszQueue = 0);

    //## Destructor (generated)
      virtual ~SOAPCommand();


    //## Other Operations (specified)
      //## Operation: attribute%5DDD341801E6
      virtual void attribute (const string& strTag, const string& strAttribute, const string& strValue);

      //## Operation: endElement%5B47CAFF023E
      virtual bool endElement (const string& strTag);

      //## Operation: parse%4DC031CF0372
      virtual int parse ();

      //## Operation: reply%4DC81AAB00FF
      virtual int reply ();

      //## Operation: reset%4E983F9C0098
      void reset ();

      //## Operation: revert%5DD4048101DD
      void revert ();

      //## Operation: save%5DD404770353
      void save ();

      //## Operation: secure%5412D9FB0108
      static void secure (reusable::Query& hQuery, const char* pszTable);

      //## Operation: startElement%5B4CECAB02BF
      virtual bool startElement (const string& strTag);

      //## Operation: update%530509AA01AC
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: MaxRows%519F63FF00A1
      const int getMaxRows () const
      {
        //## begin command::SOAPCommand::getMaxRows%519F63FF00A1.get preserve=no
        return m_iMaxRows;
        //## end command::SOAPCommand::getMaxRows%519F63FF00A1.get
      }

      void setMaxRows (int value)
      {
        //## begin command::SOAPCommand::setMaxRows%519F63FF00A1.set preserve=no
        m_iMaxRows = value;
        //## end command::SOAPCommand::setMaxRows%519F63FF00A1.set
      }


      //## Attribute: SkipRows%65CE1E59036D
      const int getSkipRows () const
      {
        //## begin command::SOAPCommand::getSkipRows%65CE1E59036D.get preserve=no
        return m_iSkipRows;
        //## end command::SOAPCommand::getSkipRows%65CE1E59036D.get
      }

      void setSkipRows (int value)
      {
        //## begin command::SOAPCommand::setSkipRows%65CE1E59036D.set preserve=no
        m_iSkipRows = value;
        //## end command::SOAPCommand::setSkipRows%65CE1E59036D.set
      }


      //## Attribute: TotalRows%65D7576E036A
      const int getTotalRows () const
      {
        //## begin command::SOAPCommand::getTotalRows%65D7576E036A.get preserve=no
        return m_iTotalRows;
        //## end command::SOAPCommand::getTotalRows%65D7576E036A.get
      }

      void setTotalRows (int value)
      {
        //## begin command::SOAPCommand::setTotalRows%65D7576E036A.set preserve=no
        m_iTotalRows = value;
        //## end command::SOAPCommand::setTotalRows%65D7576E036A.set
      }


      //## Attribute: USER_PASSWORD%52C6D9FD0329
      const string& getUSER_PASSWORD () const
      {
        //## begin command::SOAPCommand::getUSER_PASSWORD%52C6D9FD0329.get preserve=no
        return m_strUSER_PASSWORD;
        //## end command::SOAPCommand::getUSER_PASSWORD%52C6D9FD0329.get
      }

      void setUSER_PASSWORD (const string& value)
      {
        //## begin command::SOAPCommand::setUSER_PASSWORD%52C6D9FD0329.set preserve=no
        m_strUSER_PASSWORD = value;
        //## end command::SOAPCommand::setUSER_PASSWORD%52C6D9FD0329.set
      }


      //## Attribute: USER_ID%52C6D9D80197
      const string& getUSER_ID () const
      {
        //## begin command::SOAPCommand::getUSER_ID%52C6D9D80197.get preserve=no
        return m_strUSER_ID;
        //## end command::SOAPCommand::getUSER_ID%52C6D9D80197.get
      }

      void setUSER_ID (const string& value)
      {
        //## begin command::SOAPCommand::setUSER_ID%52C6D9D80197.set preserve=no
        m_strUSER_ID = value;
        //## end command::SOAPCommand::setUSER_ID%52C6D9D80197.set
      }


    // Additional Public Declarations
      //## begin command::SOAPCommand%4DC02CEB0096.public preserve=yes
      //## end command::SOAPCommand%4DC02CEB0096.public

  protected:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Rows%519F652A0284
      const int getRows () const
      {
        //## begin command::SOAPCommand::getRows%519F652A0284.get preserve=no
        return m_iRows;
        //## end command::SOAPCommand::getRows%519F652A0284.get
      }

      void setRows (int value)
      {
        //## begin command::SOAPCommand::setRows%519F652A0284.set preserve=no
        m_iRows = value;
        //## end command::SOAPCommand::setRows%519F652A0284.set
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::Command_CAT::<unnamed>%521D56B40014
      //## Role: SOAPCommand::<m_pXMLDocument>%521D56B5018E
      XMLDocument * getXMLDocument ()
      {
        //## begin command::SOAPCommand::getXMLDocument%521D56B5018E.get preserve=no
        return m_pXMLDocument;
        //## end command::SOAPCommand::getXMLDocument%521D56B5018E.get
      }


    // Data Members for Class Attributes

      //## begin command::SOAPCommand::MaxRows%519F63FF00A1.attr preserve=no  public: int {V} 100
      int m_iMaxRows;
      //## end command::SOAPCommand::MaxRows%519F63FF00A1.attr

      //## Attribute: Reply%4DC04C80010E
      //## begin command::SOAPCommand::Reply%4DC04C80010E.attr preserve=no  private: string {U} 
      string m_strReply;
      //## end command::SOAPCommand::Reply%4DC04C80010E.attr

      //## begin command::SOAPCommand::Rows%519F652A0284.attr preserve=no  protected: int {VA} 0
      int m_iRows;
      //## end command::SOAPCommand::Rows%519F652A0284.attr

      //## begin command::SOAPCommand::SkipRows%65CE1E59036D.attr preserve=no  public: int {V} 0
      int m_iSkipRows;
      //## end command::SOAPCommand::SkipRows%65CE1E59036D.attr

      //## begin command::SOAPCommand::TotalRows%65D7576E036A.attr preserve=no  public: int {V} 0
      int m_iTotalRows;
      //## end command::SOAPCommand::TotalRows%65D7576E036A.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%4DC042A601F8
      //## Role: SOAPCommand::<m_pTextSegment>%4DC042A70236
      //## begin command::SOAPCommand::<m_pTextSegment>%4DC042A70236.role preserve=no  public: segment::TextSegment { -> RFHgN}
      segment::TextSegment *m_pTextSegment;
      //## end command::SOAPCommand::<m_pTextSegment>%4DC042A70236.role

      //## Association: Connex Library::Command_CAT::<unnamed>%4DC0431B00DA
      //## Role: SOAPCommand::<m_pXMLItem>%4DC0431C005D
      //## begin command::SOAPCommand::<m_pXMLItem>%4DC0431C005D.role preserve=no  public: command::XMLItem { -> RHgN}
      XMLItem *m_pXMLItem;
      //## end command::SOAPCommand::<m_pXMLItem>%4DC0431C005D.role

      //## Association: Connex Library::Command_CAT::<unnamed>%4DC0435700E7
      //## Role: SOAPCommand::<m_pXMLHandler>%4DC0435703C6
      //## begin command::SOAPCommand::<m_pXMLHandler>%4DC0435703C6.role preserve=no  public: command::XMLHandler { -> RFHgN}
      XMLHandler *m_pXMLHandler;
      //## end command::SOAPCommand::<m_pXMLHandler>%4DC0435703C6.role

      //## Association: Connex Library::Command_CAT::<unnamed>%521D56B40014
      //## begin command::SOAPCommand::<m_pXMLDocument>%521D56B5018E.role preserve=no  protected: command::XMLDocument { -> RHgAN}
      XMLDocument *m_pXMLDocument;
      //## end command::SOAPCommand::<m_pXMLDocument>%521D56B5018E.role

      //## Association: Connex Library::Command_CAT::<unnamed>%521DE2BD0171
      //## Role: SOAPCommand::<m_hXMLText>%521DE2BE0134
      //## begin command::SOAPCommand::<m_hXMLText>%521DE2BE0134.role preserve=no  protected: command::XMLText { -> VHgAN}
      XMLText m_hXMLText;
      //## end command::SOAPCommand::<m_hXMLText>%521DE2BE0134.role

      //## Association: Connex Library::Command_CAT::<unnamed>%521DE40700BF
      //## Role: SOAPCommand::<m_hRow>%521DE40702E4
      //## begin command::SOAPCommand::<m_hRow>%521DE40702E4.role preserve=no  protected: reusable::Row { -> VHgAN}
      reusable::Row m_hRow;
      //## end command::SOAPCommand::<m_hRow>%521DE40702E4.role

    // Additional Protected Declarations
      //## begin command::SOAPCommand%4DC02CEB0096.protected preserve=yes
      //## end command::SOAPCommand%4DC02CEB0096.protected

  private:
    // Additional Private Declarations
      //## begin command::SOAPCommand%4DC02CEB0096.private preserve=yes
      //## end command::SOAPCommand%4DC02CEB0096.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Header%65CE1C64005B
      //## begin command::SOAPCommand::Header%65CE1C64005B.attr preserve=no  private: vector<string> {V} 
      vector<string> m_hHeader;
      //## end command::SOAPCommand::Header%65CE1C64005B.attr

      //## Attribute: ReplyLength%5DD404EE0360
      //## begin command::SOAPCommand::ReplyLength%5DD404EE0360.attr preserve=no  private: int {V} 0
      int m_iReplyLength;
      //## end command::SOAPCommand::ReplyLength%5DD404EE0360.attr

      //## begin command::SOAPCommand::USER_PASSWORD%52C6D9FD0329.attr preserve=no  public: string {V} 
      string m_strUSER_PASSWORD;
      //## end command::SOAPCommand::USER_PASSWORD%52C6D9FD0329.attr

      //## begin command::SOAPCommand::USER_ID%52C6D9D80197.attr preserve=no  public: string {V} 
      string m_strUSER_ID;
      //## end command::SOAPCommand::USER_ID%52C6D9D80197.attr

      //## Attribute: ZipText%5305FD5202DC
      //## begin command::SOAPCommand::ZipText%5305FD5202DC.attr preserve=no  private: unsigned char* {V} 0
      unsigned char* m_pZipText;
      //## end command::SOAPCommand::ZipText%5305FD5202DC.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%53050634013F
      //## Role: SOAPCommand::<m_hMessage>%5305063501B1
      //## begin command::SOAPCommand::<m_hMessage>%5305063501B1.role preserve=no  public: IF::Message { -> VHgN}
      IF::Message m_hMessage;
      //## end command::SOAPCommand::<m_hMessage>%5305063501B1.role

    // Additional Implementation Declarations
      //## begin command::SOAPCommand%4DC02CEB0096.implementation preserve=yes
      static int m_iInstance;
      //## end command::SOAPCommand%4DC02CEB0096.implementation
};

//## begin command::SOAPCommand%4DC02CEB0096.postscript preserve=yes
//## end command::SOAPCommand%4DC02CEB0096.postscript

} // namespace command

//## begin module%4DC02E8A000C.epilog preserve=yes
//## end module%4DC02E8A000C.epilog


#endif
