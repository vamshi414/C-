//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4ADF0B8A034B.cm preserve=no
//	$Date:   May 26 2021 13:46:38  $ $Author:   e5549623  $
//	$Revision:   1.16  $
//## end module%4ADF0B8A034B.cm

//## begin module%4ADF0B8A034B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4ADF0B8A034B.cp

//## Module: CXOSBC29%4ADF0B8A034B; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\bV02.7A.R009\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC29.cpp

//## begin module%4ADF0B8A034B.additionalIncludes preserve=no
//## end module%4ADF0B8A034B.additionalIncludes

//## begin module%4ADF0B8A034B.includes preserve=yes
//## end module%4ADF0B8A034B.includes

#ifndef CXOSBC29_h
#include "CXODBC29.hpp"
#endif
//## begin module%4ADF0B8A034B.declarations preserve=no
//## end module%4ADF0B8A034B.declarations

//## begin module%4ADF0B8A034B.additionalDeclarations preserve=yes
//## end module%4ADF0B8A034B.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::Event 

Event::Event()
  //## begin Event::Event%4ADF0637008C_const.hasinit preserve=no
  //## end Event::Event%4ADF0637008C_const.hasinit
  //## begin Event::Event%4ADF0637008C_const.initialization preserve=yes
  //## end Event::Event%4ADF0637008C_const.initialization
{
  //## begin command::Event::Event%4ADF0637008C_const.body preserve=yes
  //## end command::Event::Event%4ADF0637008C_const.body
}


Event::~Event()
{
  //## begin command::Event::~Event%4ADF0637008C_dest.body preserve=yes
  //## end command::Event::~Event%4ADF0637008C_dest.body
}



//## Other Operations (implementation)
void Event::accept ()
{
  //## begin command::Event::accept%4B7AF5890028.body preserve=yes
  //## end command::Event::accept%4B7AF5890028.body
}

void Event::addRechainInformation ()
{
  //## begin command::Event::addRechainInformation%542D90AC0005.body preserve=yes
  //## end command::Event::addRechainInformation%542D90AC0005.body
}

bool Event::deport (command::XMLDocument* pXMLDocument)
{
  //## begin command::Event::deport%4B26F6900128.body preserve=yes
   return false;
  //## end command::Event::deport%4B26F6900128.body
}

bool Event::import ()
{
  //## begin command::Event::import%4ADF064B03A9.body preserve=yes
   return false;
  //## end command::Event::import%4ADF064B03A9.body
}

bool Event::matchCase ()
{
  //## begin command::Event::matchCase%4C533935035A.body preserve=yes
  return true;
  //## end command::Event::matchCase%4C533935035A.body
}

void Event::reject ()
{
  //## begin command::Event::reject%4B7AF5A401A9.body preserve=yes
  //## end command::Event::reject%4B7AF5A401A9.body
}

void Event::setCASE_TYPE_IND ()
{
  //## begin command::Event::setCASE_TYPE_IND%4BB6AED0001D.body preserve=yes
  //## end command::Event::setCASE_TYPE_IND%4BB6AED0001D.body
}

void Event::setREASON_CODE ()
{
  //## begin command::Event::setREASON_CODE%53AAD24F025C.body preserve=yes
  //## end command::Event::setREASON_CODE%53AAD24F025C.body
}

void Event::setREQUEST_TYPE_NEXT ()
{
  //## begin command::Event::setREQUEST_TYPE_NEXT%4B990FE90370.body preserve=yes
  //## end command::Event::setREQUEST_TYPE_NEXT%4B990FE90370.body
}

void Event::setSTATUS_NEXT ()
{
  //## begin command::Event::setSTATUS_NEXT%4B9910050227.body preserve=yes
  //## end command::Event::setSTATUS_NEXT%4B9910050227.body
}

bool Event::unmatchedImport ()
{
  //## begin command::Event::unmatchedImport%4B98FF800196.body preserve=yes
  return false;
  //## end command::Event::unmatchedImport%4B98FF800196.body
}

bool Event::trigger ()
{
  //## begin command::Event::trigger%537A25CB02E6.body preserve=yes
   return false;
  //## end command::Event::trigger%537A25CB02E6.body
}

bool Event::UpdateDocExportInd (char cEXPORT_IND)
{
  //## begin command::Event::UpdateDocExportInd%57F2C0210309.body preserve=yes
   return false;
  //## end command::Event::UpdateDocExportInd%57F2C0210309.body
}

// Additional Declarations
  //## begin command::Event%4ADF0637008C.declarations preserve=yes
bool Event::sendRequest()
{
    return false;
}
  //## end command::Event%4ADF0637008C.declarations

} // namespace command

//## begin module%4ADF0B8A034B.epilog preserve=yes
//## end module%4ADF0B8A034B.epilog
