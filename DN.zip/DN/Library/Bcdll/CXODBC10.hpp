//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%36DF0455029F.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DF0455029F.cm

//## begin module%36DF0455029F.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DF0455029F.cp

//## Module: CXOSBC10%36DF0455029F; Package specification
//## Subsystem: BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC10.hpp

#ifndef CXOSBC10_h
#define CXOSBC10_h 1

//## begin module%36DF0455029F.additionalIncludes preserve=no
//## end module%36DF0455029F.additionalIncludes

//## begin module%36DF0455029F.includes preserve=yes
// $Date:   Jun 30 2006 11:35:08  $ $Author:   D02405  $ $Revision:   1.2  $
//## end module%36DF0455029F.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS10_h
#include "CXODBS10.hpp"
#endif
#ifndef CXOSUS05_h
#include "CXODUS05.hpp"
#endif
#ifndef CXOSBC01_h
#include "CXODBC01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class ResponseTimeSegment;
class CommonHeaderSegment;

} // namespace segment

//## begin module%36DF0455029F.declarations preserve=no
//## end module%36DF0455029F.declarations

//## begin module%36DF0455029F.additionalDeclarations preserve=yes
//## end module%36DF0455029F.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::GetRelationshipCommand%34636A8A01CD.preface preserve=yes
//## end command::GetRelationshipCommand%34636A8A01CD.preface

//## Class: GetRelationshipCommand%34636A8A01CD
//	QGETDATA - retrieve end user list of authorized entities.
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39451022004A;segment::MultipleRowContextSegment { -> F}
//## Uses: <unnamed>%394511050259;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%3945110702AC;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3945335C015F;segment::InformationSegment { -> F}
//## Uses: <unnamed>%3945335E00CC;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%394539FA01C9;IF::Extract { -> F}
//## Uses: <unnamed>%39462C230026;IF::Message { -> F}
//## Uses: <unnamed>%39462C2500AB;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%3A008C910057;monitor::UseCase { -> F}

class DllExport GetRelationshipCommand : public ClientCommand  //## Inherits: <unnamed>%3597885E0096
{
  //## begin command::GetRelationshipCommand%34636A8A01CD.initialDeclarations preserve=yes
  //## end command::GetRelationshipCommand%34636A8A01CD.initialDeclarations

  public:
    //## Constructors (generated)
      GetRelationshipCommand();

    //## Constructors (specified)
      //## Operation: GetRelationshipCommand%3E96B4010232
      GetRelationshipCommand (Handler* pSuccessor);

    //## Destructor (generated)
      virtual ~GetRelationshipCommand();


    //## Other Operations (specified)
      //## Operation: execute%394532200133
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: parse%39453220016F
      //	Parse this command into segments.
      //## Semantics:
      //	1. Verify the message length.
      //	2. Reset all segments.
      //	3. Import the available segments.
      virtual int parse ();

      //## Operation: update%3945322001AB
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin command::GetRelationshipCommand%34636A8A01CD.public preserve=yes
      //## end command::GetRelationshipCommand%34636A8A01CD.public

  protected:
    // Additional Protected Declarations
      //## begin command::GetRelationshipCommand%34636A8A01CD.protected preserve=yes
      //## end command::GetRelationshipCommand%34636A8A01CD.protected

  private:
    // Additional Private Declarations
      //## begin command::GetRelationshipCommand%34636A8A01CD.private preserve=yes
      //## end command::GetRelationshipCommand%34636A8A01CD.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: RecordsReturnedThisMessage%394512E203DB
      //## begin command::GetRelationshipCommand::RecordsReturnedThisMessage%394512E203DB.attr preserve=no  private: int {U} 0
      int m_lRecordsReturnedThisMessage;
      //## end command::GetRelationshipCommand::RecordsReturnedThisMessage%394512E203DB.attr

      //## Attribute: TotalRecordsFound%394512F3015F
      //## begin command::GetRelationshipCommand::TotalRecordsFound%394512F3015F.attr preserve=no  private: int {U} 0
      int m_lTotalRecordsFound;
      //## end command::GetRelationshipCommand::TotalRecordsFound%394512F3015F.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%3945102902AC
      //## Role: GetRelationshipCommand::<m_pMultipleRowContextSegment>%3945102903BB
      //## begin command::GetRelationshipCommand::<m_pMultipleRowContextSegment>%3945102903BB.role preserve=no  public: segment::MultipleRowContextSegment { -> RHgN}
      segment::MultipleRowContextSegment *m_pMultipleRowContextSegment;
      //## end command::GetRelationshipCommand::<m_pMultipleRowContextSegment>%3945102903BB.role

      //## Association: Connex Library::Command_CAT::<unnamed>%394536CC01A1
      //## Role: GetRelationshipCommand::<m_hQuery>%394536CC0327
      //## begin command::GetRelationshipCommand::<m_hQuery>%394536CC0327.role preserve=no  public: reusable::Query { -> UHgN}
      reusable::Query m_hQuery;
      //## end command::GetRelationshipCommand::<m_hQuery>%394536CC0327.role

      //## Association: Connex Library::Command_CAT::<unnamed>%39454AC30240
      //## Role: GetRelationshipCommand::<m_hRelationshipSegment>%39454AC3039F
      //## begin command::GetRelationshipCommand::<m_hRelationshipSegment>%39454AC3039F.role preserve=no  public: usersegment::RelationshipSegment { -> VHgN}
      usersegment::RelationshipSegment m_hRelationshipSegment;
      //## end command::GetRelationshipCommand::<m_hRelationshipSegment>%39454AC3039F.role

    // Additional Implementation Declarations
      //## begin command::GetRelationshipCommand%34636A8A01CD.implementation preserve=yes
      //## end command::GetRelationshipCommand%34636A8A01CD.implementation

};

//## begin command::GetRelationshipCommand%34636A8A01CD.postscript preserve=yes
//## end command::GetRelationshipCommand%34636A8A01CD.postscript

} // namespace command

//## begin module%36DF0455029F.epilog preserve=yes
using namespace command;
//## end module%36DF0455029F.epilog


#endif
