//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%40B3A98C02CE.cm preserve=no
//## end module%40B3A98C02CE.cm

//## begin module%40B3A98C02CE.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%40B3A98C02CE.cp

//## Module: CXOSBC16%40B3A98C02CE; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC16.hpp

#ifndef CXOSBC16_h
#define CXOSBC16_h 1

//## begin module%40B3A98C02CE.additionalIncludes preserve=no
//## end module%40B3A98C02CE.additionalIncludes

//## begin module%40B3A98C02CE.includes preserve=yes
#include <map>
//## end module%40B3A98C02CE.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class KeyRing;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class AESKey;

} // namespace database

//## begin module%40B3A98C02CE.declarations preserve=no
//## end module%40B3A98C02CE.declarations

//## begin module%40B3A98C02CE.additionalDeclarations preserve=yes
//## end module%40B3A98C02CE.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::XMLText%40B3ABBB01D4.preface preserve=yes
//## end command::XMLText%40B3ABBB01D4.preface

//## Class: XMLText%40B3ABBB01D4
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4B99492603D6;reusable::KeyRing { -> F}
//## Uses: <unnamed>%4B994938000D;timer::Clock { -> F}
//## Uses: <unnamed>%536230E70325;reusable::Buffer { -> F}
//## Uses: <unnamed>%5C2381D10147;IF::Extract { -> F}
//## Uses: <unnamed>%5C2381F0010F;IF::CodeTable { -> F}
//## Uses: <unnamed>%5C23821202FF;database::AESKey { -> F}

class DllExport XMLText : public reusable::Object  //## Inherits: <unnamed>%40B4EC4E0280
{
  //## begin command::XMLText%40B3ABBB01D4.initialDeclarations preserve=yes
  //## end command::XMLText%40B3ABBB01D4.initialDeclarations

  public:
    //## Constructors (generated)
      XMLText();

    //## Destructor (generated)
      virtual ~XMLText();


    //## Other Operations (specified)
      //## Operation: add%40B4ED13007D
      void add (const char cSegment, segment::Segment* pSegment);

      //## Operation: sizeOfEntry%4EAF091C01BC
      short sizeOfEntry (const string& strText);

      //## Operation: substitute%40B4EFE402FD
      void substitute (string& strText, bool bTruncate = true, bool bSuppressEmptyTags = true);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: HTML%58224D45024C
      void setHTML (bool value)
      {
        //## begin command::XMLText::setHTML%58224D45024C.set preserve=no
        m_bHTML = value;
        //## end command::XMLText::setHTML%58224D45024C.set
      }


      //## Attribute: Mask%53622EAA01D7
      void setMask (bool value)
      {
        //## begin command::XMLText::setMask%53622EAA01D7.set preserve=no
        m_bMask = value;
        //## end command::XMLText::setMask%53622EAA01D7.set
      }


    // Additional Public Declarations
      //## begin command::XMLText%40B3ABBB01D4.public preserve=yes
      void addCommas(char* pszBuffer, size_t iBufferSize);
      //## end command::XMLText%40B3ABBB01D4.public

  protected:
    // Additional Protected Declarations
      //## begin command::XMLText%40B3ABBB01D4.protected preserve=yes
      //## end command::XMLText%40B3ABBB01D4.protected

  private:
    // Additional Private Declarations
      //## begin command::XMLText%40B3ABBB01D4.private preserve=yes
      //## end command::XMLText%40B3ABBB01D4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::XMLText::HTML%58224D45024C.attr preserve=no  public: bool {V} true
      bool m_bHTML;
      //## end command::XMLText::HTML%58224D45024C.attr

      //## begin command::XMLText::Mask%53622EAA01D7.attr preserve=no  public: bool {V} true
      bool m_bMask;
      //## end command::XMLText::Mask%53622EAA01D7.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%40B5D44A0138
      //## Role: XMLText::<m_hSegment>%40B5D44B006D
      //## Qualifier: cSegment%40B5D457029F; char
      //## begin command::XMLText::<m_hSegment>%40B5D44B006D.role preserve=no  public: segment::Segment { -> RHgN}
      map<char, segment::Segment *, less<char> > m_hSegment;
      //## end command::XMLText::<m_hSegment>%40B5D44B006D.role

    // Additional Implementation Declarations
      //## begin command::XMLText%40B3ABBB01D4.implementation preserve=yes
      //## end command::XMLText%40B3ABBB01D4.implementation

};

//## begin command::XMLText%40B3ABBB01D4.postscript preserve=yes
//## end command::XMLText%40B3ABBB01D4.postscript

} // namespace command

//## begin module%40B3A98C02CE.epilog preserve=yes
using namespace command;
//## end module%40B3A98C02CE.epilog


#endif
