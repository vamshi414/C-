//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E9AF2CB0119.cm preserve=no
//	$Date:   Nov 06 2008 14:35:58  $ $Author:   D92186  $ $Revision:   1.3  $
//## end module%3E9AF2CB0119.cm

//## begin module%3E9AF2CB0119.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%3E9AF2CB0119.cp

//## Module: CXOSBC07%3E9AF2CB0119; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXODBC07.hpp

#ifndef CXOSBC07_h
#define CXOSBC07_h 1

//## begin module%3E9AF2CB0119.additionalIncludes preserve=no
//## end module%3E9AF2CB0119.additionalIncludes

//## begin module%3E9AF2CB0119.includes preserve=yes
// $Date:   Nov 06 2008 14:35:58  $ $Author:   D92186  $ $Revision:   1.3  $
#include <map>
//## end module%3E9AF2CB0119.includes

#ifndef CXOSBC08_h
#include "CXODBC08.hpp"
#endif
#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class ResponseTimeSegment;
class CommonHeaderSegment;
} // namespace segment

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class LogonSegment;

} // namespace usersegment

//## begin module%3E9AF2CB0119.declarations preserve=no
//## end module%3E9AF2CB0119.declarations

//## begin module%3E9AF2CB0119.additionalDeclarations preserve=yes
//## end module%3E9AF2CB0119.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::UserPool%3E9AF20F01F4.preface preserve=yes
//## end command::UserPool%3E9AF20F01F4.preface

//## Class: UserPool%3E9AF20F01F4
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E9BF2C2002E;timer::Clock { -> F}
//## Uses: <unnamed>%3E9BF2D60271;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%3E9BF2D9032C;segment::ResponseTimeSegment { -> F}
//## Uses: <unnamed>%3E9BF2E401D4;usersegment::LogonSegment { -> F}
//## Uses: <unnamed>%3E9BF2F10148;IF::Message { -> F}
//## Uses: <unnamed>%3E9C008D036B;segment::InformationSegment { -> F}

class DllExport UserPool : public reusable::Object  //## Inherits: <unnamed>%3E9AF23901A5
{
  //## begin command::UserPool%3E9AF20F01F4.initialDeclarations preserve=yes
  //## end command::UserPool%3E9AF20F01F4.initialDeclarations

  public:
    //## Constructors (generated)
      UserPool();

    //## Destructor (generated)
      virtual ~UserPool();


    //## Other Operations (specified)
      //## Operation: instance%3E9AFB2300FA
      static UserPool* instance ();

      //## Operation: logoffRequest%3E9AF53C00EA
      bool logoffRequest (IF::Message& hMessage, segment::CommonHeaderSegment* pCommonHeaderSegment, segment::ResponseTimeSegment* pResponseTimeSegment);

      //## Operation: logonRequest%3E9AF5410157
      int logonRequest (IF::Message& hMessage, usersegment::LogonSegment* pLogonSegment, segment::ResponseTimeSegment* pResponseTimeSegment);

      //## Operation: securityResponse%3E9AF5440177
      bool securityResponse (IF::Message& hMessage);

    // Additional Public Declarations
      //## begin command::UserPool%3E9AF20F01F4.public preserve=yes
      //## end command::UserPool%3E9AF20F01F4.public

  protected:
    // Additional Protected Declarations
      //## begin command::UserPool%3E9AF20F01F4.protected preserve=yes
      //## end command::UserPool%3E9AF20F01F4.protected

  private:
    // Additional Private Declarations
      //## begin command::UserPool%3E9AF20F01F4.private preserve=yes
      //## end command::UserPool%3E9AF20F01F4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3E9AFB3E031C
      //## begin command::UserPool::Instance%3E9AFB3E031C.attr preserve=no  private: static UserPool* {V} 0
      static UserPool* m_pInstance;
      //## end command::UserPool::Instance%3E9AFB3E031C.attr

    // Data Members for Associations

      //## Association: Connex Library::Command_CAT::<unnamed>%3E9BF309008C
      //## Role: UserPool::<m_hUserSession>%3E9BF309035B
      //## Qualifier: strUserID%3E9BF36301B5; string
      //## begin command::UserPool::<m_hUserSession>%3E9BF309035B.role preserve=no  public: command::UserSession { -> VHgN}
      map<string, UserSession, less<string> > m_hUserSession;
      //## end command::UserPool::<m_hUserSession>%3E9BF309035B.role

    // Additional Implementation Declarations
      //## begin command::UserPool%3E9AF20F01F4.implementation preserve=yes
      //## end command::UserPool%3E9AF20F01F4.implementation

};

//## begin command::UserPool%3E9AF20F01F4.postscript preserve=yes
//## end command::UserPool%3E9AF20F01F4.postscript

} // namespace command

//## begin module%3E9AF2CB0119.epilog preserve=yes
using namespace command;
//## end module%3E9AF2CB0119.epilog


#endif
