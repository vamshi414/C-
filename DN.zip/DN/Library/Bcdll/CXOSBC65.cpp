//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64DFD4B600FF.cm preserve=no
//## end module%64DFD4B600FF.cm

//## begin module%64DFD4B600FF.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64DFD4B600FF.cp

//## Module: CXOSBC65%64DFD4B600FF; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXOSBC65.cpp

//## begin module%64DFD4B600FF.additionalIncludes preserve=no
//## end module%64DFD4B600FF.additionalIncludes

//## begin module%64DFD4B600FF.includes preserve=yes
//## end module%64DFD4B600FF.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSRU15_h
#include "CXODRU15.hpp"
#endif
#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
#ifndef CXOSBS19_h
#include "CXODBS19.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBC65_h
#include "CXODBC65.hpp"
#endif


//## begin module%64DFD4B600FF.declarations preserve=no
//## end module%64DFD4B600FF.declarations

//## begin module%64DFD4B600FF.additionalDeclarations preserve=yes
//## end module%64DFD4B600FF.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::RESTCommand 

RESTCommand::RESTCommand()
  //## begin RESTCommand::RESTCommand%64DFD44D0066_const.hasinit preserve=no
  //## end RESTCommand::RESTCommand%64DFD44D0066_const.hasinit
  //## begin RESTCommand::RESTCommand%64DFD44D0066_const.initialization preserve=yes
  //## end RESTCommand::RESTCommand%64DFD44D0066_const.initialization
{
  //## begin command::RESTCommand::RESTCommand%64DFD44D0066_const.body preserve=yes
  //## end command::RESTCommand::RESTCommand%64DFD44D0066_const.body
}

RESTCommand::RESTCommand (const char* pszURL, const char* pszMessageID, const char* pszQueue)
  //## begin command::RESTCommand::RESTCommand%64DFD5FF00B3.hasinit preserve=no
  //## end command::RESTCommand::RESTCommand%64DFD5FF00B3.hasinit
  //## begin command::RESTCommand::RESTCommand%64DFD5FF00B3.initialization preserve=yes
   : SOAPCommand(pszMessageID,pszQueue)
   ,m_strURL(pszURL)
  //## end command::RESTCommand::RESTCommand%64DFD5FF00B3.initialization
{
  //## begin command::RESTCommand::RESTCommand%64DFD5FF00B3.body preserve=yes
   publishURL();
  //## end command::RESTCommand::RESTCommand%64DFD5FF00B3.body
}


RESTCommand::~RESTCommand()
{
  //## begin command::RESTCommand::~RESTCommand%64DFD44D0066_dest.body preserve=yes
  //## end command::RESTCommand::~RESTCommand%64DFD44D0066_dest.body
}



//## Other Operations (implementation)
int RESTCommand::parse ()
{
  //## begin command::RESTCommand::parse%653FA6E200A2.body preserve=yes
   return SOAPCommand::parse();
  //## end command::RESTCommand::parse%653FA6E200A2.body
}

void RESTCommand::publishURL ()
{
  //## begin command::RESTCommand::publishURL%651ADA52011D.body preserve=yes
   Message::instance(Message::OUTBOUND)->reset("SRVCLI","S0013R",false);
   char* p = Message::instance(Message::OUTBOUND)->data();
   memset(p,' ',9);
   memcpy(p,m_strServiceName.data(),m_strServiceName.length() < 9 ? m_strServiceName.length() : 8);
   memcpy(p + 8,m_strURL.data(),m_strURL.length());
   Message::instance(Message::OUTBOUND)->setDataLength(8 + m_strURL.length());
   Message::instance(Message::OUTBOUND)->send("##CI01");
  //## end command::RESTCommand::publishURL%651ADA52011D.body
}

int RESTCommand::reply ()
{
  //## begin command::RESTCommand::reply%653F1FE501EF.body preserve=yes
   m_pXMLDocument->write("");
   size_t pos = m_strReply.find("<RtnCde>");
   if (pos != string::npos)
      m_strReply[pos + 8] = segment::SOAPSegment::instance()->getRtnCde()[0];
   reusable::Format::XMLtoJSON(m_strReply);
   CommonHeaderSegment::instance()->setServiceName("QHTTP");
   return SOAPCommand::reply();
  //## end command::RESTCommand::reply%653F1FE501EF.body
}

void RESTCommand::update (Subject* pSubject)
{
  //## begin command::RESTCommand::update%653FC2EE03CF.body preserve=yes
   if (pSubject == Message::instance(Message::INBOUND))
      if (Message::instance(Message::INBOUND)->messageID() == "S0004D")
         publishURL();
   SOAPCommand::update(pSubject);
  //## end command::RESTCommand::update%653FC2EE03CF.body
}

// Additional Declarations
  //## begin command::RESTCommand%64DFD44D0066.declarations preserve=yes
  //## end command::RESTCommand%64DFD44D0066.declarations

} // namespace command

//## begin module%64DFD4B600FF.epilog preserve=yes
//## end module%64DFD4B600FF.epilog
