//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%48BEBBE90129.cm preserve=no
//## end module%48BEBBE90129.cm

//## begin module%48BEBBE90129.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%48BEBBE90129.cp

//## Module: CXOSBC26%48BEBBE90129; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC26.hpp

#ifndef CXOSBC26_h
#define CXOSBC26_h 1

//## begin module%48BEBBE90129.additionalIncludes preserve=no
//## end module%48BEBBE90129.additionalIncludes

//## begin module%48BEBBE90129.includes preserve=yes
#define PWD_UPPER 0
#define PWD_LOWER 1
#define PWD_DIGIT 2
#define PWD_SPECIAL 3
#define PWD_REPEATING 4
#define PWD_MIN_LEN 5
#define PWD_UPPER_ERR 7
#define PWD_LOWER_ERR 8
#define PWD_DIGIT_ERR 9
#define PWD_SPECIAL_ERR 10
#define PWD_REPEATING_ERR 11
#define PWD_MIN_LEN_ERR 12
#define PWD_HISTORY_ERR 13

#define STS_LOGON_DENIED 10
#define STS_DATABASE_FAILURE 15
#define STS_UNKNOWN_USER_ID 20
#define STS_UNKNOWN_TERMINAL 21
#define STS_PASSWORD_MISMATCH 22
#define STS_INVALID_NEW_PASSWORD 23
#define STS_NEW_PASSWORD_REQUIRED 24
#define STS_ACCESS_SECURITY_UNAVAILABLE 25
#define STS_USER_ID_REVOKED 40
#define STS_INVALID_PASSWORD_HISTORY 111
#include <vector>
//## end module%48BEBBE90129.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class KeyExchangeSegment;
} // namespace usersegment

namespace reusable {
class Key;
class KeyRing;
class Buffer;
class Table;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class PersistentSegment;

} // namespace segment

//## begin module%48BEBBE90129.declarations preserve=no
//## end module%48BEBBE90129.declarations

//## begin module%48BEBBE90129.additionalDeclarations preserve=yes
//## end module%48BEBBE90129.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::Security%48BEBB9F0137.preface preserve=yes
//## end command::Security%48BEBB9F0137.preface

//## Class: Security%48BEBB9F0137
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%48BEC8F400B2;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%48BEC8F601E2;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%48BEC8FB0076;reusable::Table { -> F}
//## Uses: <unnamed>%48BEC8FF016C;reusable::Statement { -> F}
//## Uses: <unnamed>%48BEC90501C5;database::Database { -> F}
//## Uses: <unnamed>%48BEE50D017E;IF::Extract { -> F}
//## Uses: <unnamed>%490B715D030F;IF::Message { -> F}
//## Uses: <unnamed>%490F72E1037E;usersegment::KeyExchangeSegment { -> F}
//## Uses: <unnamed>%48BEC8F80307;reusable::Query { -> F}
//## Uses: <unnamed>%51ED89A8028D;reusable::Buffer { -> F}
//## Uses: <unnamed>%55562E6A01E7;reusable::KeyRing { -> F}
//## Uses: <unnamed>%55562E6E03AF;reusable::Key { -> F}
//## Uses: <unnamed>%5602BC6D006F;segment::PersistentSegment { -> F}

class DllExport Security : public reusable::Observer  //## Inherits: <unnamed>%48BEBBAB00A8
{
  //## begin command::Security%48BEBB9F0137.initialDeclarations preserve=yes
  //## end command::Security%48BEBB9F0137.initialDeclarations

  public:
    //## Constructors (generated)
      Security();

    //## Destructor (generated)
      virtual ~Security();


    //## Other Operations (specified)
      //## Operation: authenticateUser%48BECFC80323
      virtual int authenticateUser (const string& strUserid, const string& strPassword);

      //## Operation: decrypt%49A6A8CB00EB
      bool decrypt (string& strText, char* pHash = 0);

      //## Operation: incrementFailCount%48C14BF703C4
      void incrementFailCount (const string& strUserid);

      //## Operation: getAccountStatus%48BEDEA90348
      char getAccountStatus (const string& strUserid);

      //## Operation: getLastLogonDate%48BEDED70326
      reusable::string getLastLogonDate (const string& strUserid);

      //## Operation: getPasswordExpiration%48BEDF06000C
      reusable::string getPasswordExpiration (const string& strUserid);

      //## Operation: getUserRole%5602BC86009D
      virtual char getUserRole (segment::PersistentSegment* pSegment);

      //## Operation: instance%490B6EE8013E
      static Security* instance ();

      //## Operation: keyXchgRequest%490B701803B2
      int keyXchgRequest (const string& strKeyId = "");

      //## Operation: processLogon%48BECF4D03D0
      virtual reusable::string processLogon (const string& strUserid, const string& strPassword, const string& strNewPassword, bool bReLogon = false);

      //## Operation: hash%4E0B4DEA036C
      void hash (const string& strInput, string& strOutput);

      //## Operation: update%48C155A1024F
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Hash%49A6A9E1032F
      const string& getHash () const
      {
        //## begin command::Security::getHash%49A6A9E1032F.get preserve=no
        return m_strHash;
        //## end command::Security::getHash%49A6A9E1032F.get
      }


      //## Attribute: Key%490F6F7A00C9
      const string& getKey () const
      {
        //## begin command::Security::getKey%490F6F7A00C9.get preserve=no
        return m_strKey;
        //## end command::Security::getKey%490F6F7A00C9.get
      }


      //## Attribute: SecurityType%58CFDCB70164
      const string& getSecurityType () const
      {
        //## begin command::Security::getSecurityType%58CFDCB70164.get preserve=no
        return m_strSecurityType;
        //## end command::Security::getSecurityType%58CFDCB70164.get
      }

      void setSecurityType (const string& value)
      {
        //## begin command::Security::setSecurityType%58CFDCB70164.set preserve=no
        m_strSecurityType = value;
        //## end command::Security::setSecurityType%58CFDCB70164.set
      }


    // Additional Public Declarations
      //## begin command::Security%48BEBB9F0137.public preserve=yes
      string updateLastLogon2 (const string& strUserid);

      //## end command::Security%48BEBB9F0137.public
  protected:

    //## Other Operations (specified)
      //## Operation: changePassword%48BED0B401EC
      virtual int changePassword (const string& strUserid, const string& strNewPassword);

      //## Operation: initialize%48BED54F0129
      void initialize ();

      //## Operation: generateDigest%48C01497033E
      virtual void generateDigest (char cDigestMethod, const string& strPassword, string& strDigest, const string& strSalt = "");

      //## Operation: generateSalt%51ED847401F4
      void generateSalt (string& strSalt);

      //## Operation: retrievePwdHistory%48C154450064
      void retrievePwdHistory (const string& strUserid);

      //## Operation: updateLastLogon%48C14BCC000B
      void updateLastLogon (const string& strUserid);

      //## Operation: updateUserStatus%48C96BF20088
      void updateUserStatus (const string& strUserid, const char& cStatus);

      //## Operation: validatePassword%48BEC5980098
      virtual int validatePassword (const string& strUserid, const string& strPassword);

      //## Operation: validatePwdComplexity%48BED0F20399
      virtual int validatePwdComplexity (const string& strNewPassword);

      //## Operation: validatePwdHistory%48C15F61003B
      virtual int validatePwdHistory (const string& strNewPassword);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: AP_PWD_EXPIRE_DAYS%5B4F95A00069
      const short getAP_PWD_EXPIRE_DAYS () const
      {
        //## begin command::Security::getAP_PWD_EXPIRE_DAYS%5B4F95A00069.get preserve=no
        return m_siAP_PWD_EXPIRE_DAYS;
        //## end command::Security::getAP_PWD_EXPIRE_DAYS%5B4F95A00069.get
      }


      //## Attribute: CUST_ID%48BED3C90290
      const string& getCUST_ID () const
      {
        //## begin command::Security::getCUST_ID%48BED3C90290.get preserve=no
        return m_strCUST_ID;
        //## end command::Security::getCUST_ID%48BED3C90290.get
      }


      //## Attribute: DIGEST_METHOD%48BED406031A
      const char getDIGEST_METHOD () const
      {
        //## begin command::Security::getDIGEST_METHOD%48BED406031A.get preserve=no
        return m_cDIGEST_METHOD;
        //## end command::Security::getDIGEST_METHOD%48BED406031A.get
      }


      //## Attribute: DIGIT_REQ_FLG%48BED4F1003D
      const bool getDIGIT_REQ_FLG () const
      {
        //## begin command::Security::getDIGIT_REQ_FLG%48BED4F1003D.get preserve=no
        return m_bDIGIT_REQ_FLG;
        //## end command::Security::getDIGIT_REQ_FLG%48BED4F1003D.get
      }


      //## Attribute: LOWER_CASE_REQ_FLG%48BED4EF01D5
      const bool getLOWER_CASE_REQ_FLG () const
      {
        //## begin command::Security::getLOWER_CASE_REQ_FLG%48BED4EF01D5.get preserve=no
        return m_bLOWER_CASE_REQ_FLG;
        //## end command::Security::getLOWER_CASE_REQ_FLG%48BED4EF01D5.get
      }


      //## Attribute: MAX_FAIL_ATTEMPTS%48BED44502A3
      const short getMAX_FAIL_ATTEMPTS () const
      {
        //## begin command::Security::getMAX_FAIL_ATTEMPTS%48BED44502A3.get preserve=no
        return m_siMAX_FAIL_ATTEMPTS;
        //## end command::Security::getMAX_FAIL_ATTEMPTS%48BED44502A3.get
      }


      //## Attribute: PWD_EXPIRE_DAYS%48BED472009F
      const short getPWD_EXPIRE_DAYS () const
      {
        //## begin command::Security::getPWD_EXPIRE_DAYS%48BED472009F.get preserve=no
        return m_siPWD_EXPIRE_DAYS;
        //## end command::Security::getPWD_EXPIRE_DAYS%48BED472009F.get
      }


      //## Attribute: PWD_HISTORY_COUNT%48BED490003E
      const short getPWD_HISTORY_COUNT () const
      {
        //## begin command::Security::getPWD_HISTORY_COUNT%48BED490003E.get preserve=no
        return m_siPWD_HISTORY_COUNT;
        //## end command::Security::getPWD_HISTORY_COUNT%48BED490003E.get
      }


      //## Attribute: PWD_MIN_LENGTH%48BED48E00DB
      const short getPWD_MIN_LENGTH () const
      {
        //## begin command::Security::getPWD_MIN_LENGTH%48BED48E00DB.get preserve=no
        return m_siPWD_MIN_LENGTH;
        //## end command::Security::getPWD_MIN_LENGTH%48BED48E00DB.get
      }


      //## Attribute: REPEATING_CHAR_FLG%48BED5150388
      const bool getREPEATING_CHAR_FLG () const
      {
        //## begin command::Security::getREPEATING_CHAR_FLG%48BED5150388.get preserve=no
        return m_bREPEATING_CHAR_FLG;
        //## end command::Security::getREPEATING_CHAR_FLG%48BED5150388.get
      }


      //## Attribute: SPECIAL_REQ_FLG%48BED4F202DD
      const bool getSPECIAL_REQ_FLG () const
      {
        //## begin command::Security::getSPECIAL_REQ_FLG%48BED4F202DD.get preserve=no
        return m_bSPECIAL_REQ_FLG;
        //## end command::Security::getSPECIAL_REQ_FLG%48BED4F202DD.get
      }


      //## Attribute: UPPER_CASE_REQ_FLG%48BED4D901DD
      const bool getUPPER_CASE_REQ_FLG () const
      {
        //## begin command::Security::getUPPER_CASE_REQ_FLG%48BED4D901DD.get preserve=no
        return m_bUPPER_CASE_REQ_FLG;
        //## end command::Security::getUPPER_CASE_REQ_FLG%48BED4D901DD.get
      }


    // Data Members for Class Attributes

      //## Attribute: Instance%490B6EFE0104
      //## begin command::Security::Instance%490B6EFE0104.attr preserve=no  public: static Security* {V} 0
      static Security* m_pInstance;
      //## end command::Security::Instance%490B6EFE0104.attr

      //## Attribute: PwdRulesErrors%4A5787310236
      //## begin command::Security::PwdRulesErrors%4A5787310236.attr preserve=no  protected: char[15] {U} 
      char m_sPwdRulesErrors[15];
      //## end command::Security::PwdRulesErrors%4A5787310236.attr

    // Additional Protected Declarations
      //## begin command::Security%48BEBB9F0137.protected preserve=yes
      const bool getCONSOLE_SECURITY_ENABLED () const
      {
        return m_bCONSOLE_SECURITY_ENABLED;
      }
      map<string, string, less<string> > m_hPasswordExpiry;
      //## end command::Security%48BEBB9F0137.protected
  private:

    //## Other Operations (specified)
      //## Operation: generateKey%490F70550359
      void generateKey ();

    // Additional Private Declarations
      //## begin command::Security%48BEBB9F0137.private preserve=yes
      //## end command::Security%48BEBB9F0137.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin command::Security::AP_PWD_EXPIRE_DAYS%5B4F95A00069.attr preserve=no  protected: short {U} 365
      short m_siAP_PWD_EXPIRE_DAYS;
      //## end command::Security::AP_PWD_EXPIRE_DAYS%5B4F95A00069.attr

      //## begin command::Security::CUST_ID%48BED3C90290.attr preserve=no  protected: string {U} "****"
      string m_strCUST_ID;
      //## end command::Security::CUST_ID%48BED3C90290.attr

      //## begin command::Security::DIGEST_METHOD%48BED406031A.attr preserve=no  protected: char {U} 'M'
      char m_cDIGEST_METHOD;
      //## end command::Security::DIGEST_METHOD%48BED406031A.attr

      //## begin command::Security::DIGIT_REQ_FLG%48BED4F1003D.attr preserve=no  protected: bool {U} true
      bool m_bDIGIT_REQ_FLG;
      //## end command::Security::DIGIT_REQ_FLG%48BED4F1003D.attr

      //## begin command::Security::Hash%49A6A9E1032F.attr preserve=no  public: string {U} 
      string m_strHash;
      //## end command::Security::Hash%49A6A9E1032F.attr

      //## Attribute: HistoryDIGEST_METHOD%49A6AE7C02EF
      //## begin command::Security::HistoryDIGEST_METHOD%49A6AE7C02EF.attr preserve=no  private: char {U} 
      char m_cHistoryDIGEST_METHOD;
      //## end command::Security::HistoryDIGEST_METHOD%49A6AE7C02EF.attr

      //## begin command::Security::Key%490F6F7A00C9.attr preserve=no  public: string {U} 
      string m_strKey;
      //## end command::Security::Key%490F6F7A00C9.attr

      //## begin command::Security::LOWER_CASE_REQ_FLG%48BED4EF01D5.attr preserve=no  protected: bool {U} true
      bool m_bLOWER_CASE_REQ_FLG;
      //## end command::Security::LOWER_CASE_REQ_FLG%48BED4EF01D5.attr

      //## begin command::Security::MAX_FAIL_ATTEMPTS%48BED44502A3.attr preserve=no  protected: short {U} 3
      short m_siMAX_FAIL_ATTEMPTS;
      //## end command::Security::MAX_FAIL_ATTEMPTS%48BED44502A3.attr

      //## Attribute: NEW_PASSWORD%49A6AE3702BD
      //## begin command::Security::NEW_PASSWORD%49A6AE3702BD.attr preserve=no  private: string {U} 
      string m_strNEW_PASSWORD;
      //## end command::Security::NEW_PASSWORD%49A6AE3702BD.attr

      //## Attribute: PwdHistory%48C156260124
      //## begin command::Security::PwdHistory%48C156260124.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hPwdHistory;
      //## end command::Security::PwdHistory%48C156260124.attr

      //## begin command::Security::PWD_EXPIRE_DAYS%48BED472009F.attr preserve=no  protected: short {U} 90
      short m_siPWD_EXPIRE_DAYS;
      //## end command::Security::PWD_EXPIRE_DAYS%48BED472009F.attr

      //## begin command::Security::PWD_HISTORY_COUNT%48BED490003E.attr preserve=no  protected: short {U} 10
      short m_siPWD_HISTORY_COUNT;
      //## end command::Security::PWD_HISTORY_COUNT%48BED490003E.attr

      //## begin command::Security::PWD_MIN_LENGTH%48BED48E00DB.attr preserve=no  protected: short {U} 8
      short m_siPWD_MIN_LENGTH;
      //## end command::Security::PWD_MIN_LENGTH%48BED48E00DB.attr

      //## begin command::Security::REPEATING_CHAR_FLG%48BED5150388.attr preserve=no  protected: bool {U} false
      bool m_bREPEATING_CHAR_FLG;
      //## end command::Security::REPEATING_CHAR_FLG%48BED5150388.attr

      //## Attribute: SALT%51ED859E01B9
      //## begin command::Security::SALT%51ED859E01B9.attr preserve=no  private: string {U} 
      string m_strSALT;
      //## end command::Security::SALT%51ED859E01B9.attr

      //## begin command::Security::SecurityType%58CFDCB70164.attr preserve=no  public: string {U} 
      string m_strSecurityType;
      //## end command::Security::SecurityType%58CFDCB70164.attr

      //## begin command::Security::SPECIAL_REQ_FLG%48BED4F202DD.attr preserve=no  protected: bool {U} true
      bool m_bSPECIAL_REQ_FLG;
      //## end command::Security::SPECIAL_REQ_FLG%48BED4F202DD.attr

      //## Attribute: TSTAMP_PASSWORD%5554B18202FE
      //## begin command::Security::TSTAMP_PASSWORD%5554B18202FE.attr preserve=no  private: string {U} 
      string m_strTSTAMP_PASSWORD;
      //## end command::Security::TSTAMP_PASSWORD%5554B18202FE.attr

      //## begin command::Security::UPPER_CASE_REQ_FLG%48BED4D901DD.attr preserve=no  protected: bool {U} true
      bool m_bUPPER_CASE_REQ_FLG;
      //## end command::Security::UPPER_CASE_REQ_FLG%48BED4D901DD.attr

    // Additional Implementation Declarations
      //## begin command::Security%48BEBB9F0137.implementation preserve=yes
      bool m_bCONSOLE_SECURITY_ENABLED;
      //## end command::Security%48BEBB9F0137.implementation
};

//## begin command::Security%48BEBB9F0137.postscript preserve=yes
//## end command::Security%48BEBB9F0137.postscript

} // namespace command

//## begin module%48BEBBE90129.epilog preserve=yes
//## end module%48BEBBE90129.epilog


#endif
