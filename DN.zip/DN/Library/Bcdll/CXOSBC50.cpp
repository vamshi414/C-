//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%56264F0002D9.cm preserve=no
//	$Date:   May 14 2020 16:20:20  $ $Author:   e1009510  $ $Revision:   1.2  $
//## end module%56264F0002D9.cm

//## begin module%56264F0002D9.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%56264F0002D9.cp

//## Module: CXOSBC50%56264F0002D9; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC50.cpp

//## begin module%56264F0002D9.additionalIncludes preserve=no
//## end module%56264F0002D9.additionalIncludes

//## begin module%56264F0002D9.includes preserve=yes
#ifdef _WIN32
//#include "windows.h"
#include "xercesc\sax\AttributeList.hpp"
#else
#include "xercesc/sax/AttributeList.hpp"
#endif
//## end module%56264F0002D9.includes

#ifndef CXOSBC49_h
#include "CXODBC49.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSBC50_h
#include "CXODBC50.hpp"
#endif


//## begin module%56264F0002D9.declarations preserve=no
//## end module%56264F0002D9.declarations

//## begin module%56264F0002D9.additionalDeclarations preserve=yes
//## end module%56264F0002D9.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::GenericFunctionXMLHandler 

GenericFunctionXMLHandler::GenericFunctionXMLHandler()
  //## begin GenericFunctionXMLHandler::GenericFunctionXMLHandler%56264DEB024A_const.hasinit preserve=no
      : m_pGenericFunction(0)
  //## end GenericFunctionXMLHandler::GenericFunctionXMLHandler%56264DEB024A_const.hasinit
  //## begin GenericFunctionXMLHandler::GenericFunctionXMLHandler%56264DEB024A_const.initialization preserve=yes
  //## end GenericFunctionXMLHandler::GenericFunctionXMLHandler%56264DEB024A_const.initialization
{
  //## begin command::GenericFunctionXMLHandler::GenericFunctionXMLHandler%56264DEB024A_const.body preserve=yes
  //## end command::GenericFunctionXMLHandler::GenericFunctionXMLHandler%56264DEB024A_const.body
}

GenericFunctionXMLHandler::GenericFunctionXMLHandler (XMLItem* pXMLItem)
  //## begin command::GenericFunctionXMLHandler::GenericFunctionXMLHandler%5629D314036D.hasinit preserve=no
      : m_pGenericFunction(0)
  //## end command::GenericFunctionXMLHandler::GenericFunctionXMLHandler%5629D314036D.hasinit
  //## begin command::GenericFunctionXMLHandler::GenericFunctionXMLHandler%5629D314036D.initialization preserve=yes
  ,XMLHandler(pXMLItem)
  //## end command::GenericFunctionXMLHandler::GenericFunctionXMLHandler%5629D314036D.initialization
{
  //## begin command::GenericFunctionXMLHandler::GenericFunctionXMLHandler%5629D314036D.body preserve=yes
  //## end command::GenericFunctionXMLHandler::GenericFunctionXMLHandler%5629D314036D.body
}


GenericFunctionXMLHandler::~GenericFunctionXMLHandler()
{
  //## begin command::GenericFunctionXMLHandler::~GenericFunctionXMLHandler%56264DEB024A_dest.body preserve=yes
  //## end command::GenericFunctionXMLHandler::~GenericFunctionXMLHandler%56264DEB024A_dest.body
}



//## Other Operations (implementation)
void GenericFunctionXMLHandler::endElement (const XMLCh* const name)
{
  //## begin command::GenericFunctionXMLHandler::endElement%56264E55020A.body preserve=yes
   if (m_hElement.size() > 2)
   {
      if (m_hElement[m_hElement.size() - 2] == "Criteria")
      {
         vector<string> hTokens;
         if (Buffer::parse(m_hElement.back(),".",hTokens) == 2 )
         {
            m_hCriteriaData.setField(hTokens[1]);
            m_hCriteriaData.setTable(hTokens[0]);
            m_hCriteriaData.setValue(getCharacters());
            m_hCriteria.addCriteriaData(m_hCriteriaData);
            m_hCriteriaData.clear();
         }
      }
      else if (m_hElement[m_hElement.size() - 2] == "Result")
      {
         m_hCriteria.addResult(m_hElement.back(),getCharacters());
      }
      else if (m_hElement[m_hElement.size() - 2] == "Function")
      {
         if (m_hElement.back() == "Name")
            m_hFunction.setName(getCharacters());
      }
   }
   if (m_hElement.back() == "Group")
   {
      m_hFunction.addCriteria(m_hCriteria);
      m_hCriteria.clear();
   }
   if (m_hElement.back() == "Function" && m_pGenericFunction)
   {
      m_pGenericFunction->addFunction(m_hFunction);
      m_hFunction.clear();
   }
   XMLHandler::endElement(name);
  //## end command::GenericFunctionXMLHandler::endElement%56264E55020A.body
}

void GenericFunctionXMLHandler::startElement (const XMLCh* const name, AttributeList& attributes)
{
  //## begin command::GenericFunctionXMLHandler::startElement%56264E55020C.body preserve=yes
   XMLHandler::startElement(name,attributes);
   if (m_hElement.size() > 2
      && m_hElement[m_hElement.size() - 2] == "Criteria")
   {
      const XMLCh* pType = attributes.getValue("operator");
      if (pType)
      {
         getToken("GenericFunctionXMLHandler::startElement operator= ",pType,XMLString::stringLen(pType));
         m_hCriteriaData.setOperator(getToken());
      }
      else
         m_hCriteriaData.setOperator("=");
      pType = attributes.getValue("substring");
      if (pType)
      {
         getToken("GenericFunctionXMLHandler::startElement substring= ",pType,XMLString::stringLen(pType));
         m_hCriteriaData.setSubStringAttribute(getToken());
      }
   }
  //## end command::GenericFunctionXMLHandler::startElement%56264E55020C.body
}

// Additional Declarations
  //## begin command::GenericFunctionXMLHandler%56264DEB024A.declarations preserve=yes
  //## end command::GenericFunctionXMLHandler%56264DEB024A.declarations

} // namespace command

//## begin module%56264F0002D9.epilog preserve=yes
//## end module%56264F0002D9.epilog



