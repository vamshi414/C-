//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6436F24602DA.cm preserve=no
//## end module%6436F24602DA.cm

//## begin module%6436F24602DA.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6436F24602DA.cp

//## Module: CXOSBC17%6436F24602DA; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC17.hpp

#ifndef CXOSBC17_h
#define CXOSBC17_h 1

//## begin module%6436F24602DA.additionalIncludes preserve=no
//## end module%6436F24602DA.additionalIncludes

//## begin module%6436F24602DA.includes preserve=yes
//## end module%6436F24602DA.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class HealthMonitorSegment;

} // namespace segment

//## begin module%6436F24602DA.declarations preserve=no
//## end module%6436F24602DA.declarations

//## begin module%6436F24602DA.additionalDeclarations preserve=yes
//## end module%6436F24602DA.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::Count%6436D7AB03A7.preface preserve=yes
//## end command::Count%6436D7AB03A7.preface

//## Class: Count%6436D7AB03A7
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6436F3DD02C3;segment::HealthMonitorSegment { -> F}
//## Uses: <unnamed>%6436F4EB028B;reusable::Table { -> F}
//## Uses: <unnamed>%6436F4ED03B2;reusable::Statement { -> F}
//## Uses: <unnamed>%6436F4F0025B;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%6436F588034B;process::Application { -> F}
//## Uses: <unnamed>%6436F5A90013;timer::Clock { -> F}

class DllExport Count : public reusable::Object  //## Inherits: <unnamed>%6436D7F302C6
{
  //## begin command::Count%6436D7AB03A7.initialDeclarations preserve=yes
  //## end command::Count%6436D7AB03A7.initialDeclarations

  public:
    //## Constructors (generated)
      Count();

    //## Destructor (generated)
      virtual ~Count();


    //## Other Operations (specified)
      //## Operation: apply%6436F39F0047
      static bool apply (segment::HealthMonitorSegment& hHealthMonitorSegment);

      //## Operation: commit%64381E0201A2
      bool commit ();

      //## Operation: increment%6436D7C80311
      void increment (const reusable::string& strDOMAIN_NAME, const reusable::string& strMEMBER_NAME, const reusable::string& strBUCKET, int iITEM_COUNT = 1);

      //## Operation: instance%64381E130383
      static Count* instance ();

      //## Operation: set%6436D8B8028A
      bool set (const reusable::string& strDOMAIN_NAME, const reusable::string& strMEMBER_NAME, const reusable::string& strBUCKET, int iITEM_COUNT);

    // Additional Public Declarations
      //## begin command::Count%6436D7AB03A7.public preserve=yes
      //## end command::Count%6436D7AB03A7.public

  protected:
    // Additional Protected Declarations
      //## begin command::Count%6436D7AB03A7.protected preserve=yes
      //## end command::Count%6436D7AB03A7.protected

  private:
    // Additional Private Declarations
      //## begin command::Count%6436D7AB03A7.private preserve=yes
      //## end command::Count%6436D7AB03A7.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BUCKET%64381EA4006B
      //## begin command::Count::BUCKET%64381EA4006B.attr preserve=no  private: map<string,int,less<string> > {V} 
      map<string,int,less<string> > m_hBUCKET;
      //## end command::Count::BUCKET%64381EA4006B.attr

      //## Attribute: Instance%64381E2E02C3
      //## begin command::Count::Instance%64381E2E02C3.attr preserve=no  private: static Count* {V} 0
      static Count* m_pInstance;
      //## end command::Count::Instance%64381E2E02C3.attr

    // Additional Implementation Declarations
      //## begin command::Count%6436D7AB03A7.implementation preserve=yes
      //## end command::Count%6436D7AB03A7.implementation

};

//## begin command::Count%6436D7AB03A7.postscript preserve=yes
//## end command::Count%6436D7AB03A7.postscript

} // namespace command

//## begin module%6436F24602DA.epilog preserve=yes
//## end module%6436F24602DA.epilog


#endif
