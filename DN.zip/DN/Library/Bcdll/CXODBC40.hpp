//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52B437F200EB.cm preserve=no
//## end module%52B437F200EB.cm

//## begin module%52B437F200EB.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%52B437F200EB.cp

//## Module: CXOSBC40%52B437F200EB; Package specification
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bcdll\CXODBC40.hpp

#ifndef CXOSBC40_h
#define CXOSBC40_h 1

//## begin module%52B437F200EB.additionalIncludes preserve=no
//## end module%52B437F200EB.additionalIncludes

//## begin module%52B437F200EB.includes preserve=yes
#include <set>
//## end module%52B437F200EB.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;

} // namespace segment

//## begin module%52B437F200EB.declarations preserve=no
//## end module%52B437F200EB.declarations

//## begin module%52B437F200EB.additionalDeclarations preserve=yes
//## end module%52B437F200EB.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

//## begin command::User%52B4372F013E.preface preserve=yes
//## end command::User%52B4372F013E.preface

//## Class: User%52B4372F013E
//## Category: Connex Library::Command_CAT%3459269903E2
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%52B443E400D4;reusable::Query { -> F}
//## Uses: <unnamed>%52B443E801E5;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%52B443ED00DD;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%52B44DAC031F;segment::CommonHeaderSegment { -> F}

class DllExport User : public reusable::Observer  //## Inherits: <unnamed>%52B4375B0070
{
  //## begin command::User%52B4372F013E.initialDeclarations preserve=yes
  //## end command::User%52B4372F013E.initialDeclarations

  public:
    //## Constructors (generated)
      User();

    //## Destructor (generated)
      virtual ~User();


    //## Other Operations (specified)
      //## Operation: getEntityLevel%6287C5190340
      const set <string>&  getEntityLevel ();

      //## Operation: getRole%52B439850051
      bool getRole (const string& strINST_ID_RECN_ACQ_B, const string& strINST_ID_RECN_ISS_B, const string& strPROC_ID_ACQ_B, const string& strPROC_ID_ISS_B, const string& strRPT_LVL_ID_B, string& strRole);

      //## Operation: instance%52B4376C01C9
      static User* instance ();

      //## Operation: load%52B43FC50369
      bool load ();

      //## Operation: update%52B437A4011F
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin command::User%52B4372F013E.public preserve=yes
      //## end command::User%52B4372F013E.public

  protected:
    // Additional Protected Declarations
      //## begin command::User%52B4372F013E.protected preserve=yes
      //## end command::User%52B4372F013E.protected

  private:
    // Additional Private Declarations
      //## begin command::User%52B4372F013E.private preserve=yes
      //## end command::User%52B4372F013E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Entity%52B442260203
      //## begin command::User::Entity%52B442260203.attr preserve=no  private: set<string,less<string> > {V} 
      set<string,less<string> > m_hEntity;
      //## end command::User::Entity%52B442260203.attr

      //## Attribute: EntityLevel%62A053BA039F
      //## begin command::User::EntityLevel%62A053BA039F.attr preserve=no  private: set<string> {V} 
      set<string> m_hEntityLevel;
      //## end command::User::EntityLevel%62A053BA039F.attr

      //## Attribute: Instance%52B4378801AA
      //## begin command::User::Instance%52B4378801AA.attr preserve=no  private: static User* {V} 0
      static User* m_pInstance;
      //## end command::User::Instance%52B4378801AA.attr

      //## Attribute: ONLINE_ENTITY_ID%52B4420803AB
      //## begin command::User::ONLINE_ENTITY_ID%52B4420803AB.attr preserve=no  private: string {V} 
      string m_strONLINE_ENTITY_ID;
      //## end command::User::ONLINE_ENTITY_ID%52B4420803AB.attr

      //## Attribute: ROLE_ID%52B442090207
      //## begin command::User::ROLE_ID%52B442090207.attr preserve=no  private: string {V} 
      string m_strROLE_ID;
      //## end command::User::ROLE_ID%52B442090207.attr

      //## Attribute: USER_ID%52B439FA023A
      //## begin command::User::USER_ID%52B439FA023A.attr preserve=no  private: string {V} 
      string m_strUSER_ID;
      //## end command::User::USER_ID%52B439FA023A.attr

    // Additional Implementation Declarations
      //## begin command::User%52B4372F013E.implementation preserve=yes
      //## end command::User%52B4372F013E.implementation

};

//## begin command::User%52B4372F013E.postscript preserve=yes
//## end command::User%52B4372F013E.postscript

} // namespace command

//## begin module%52B437F200EB.epilog preserve=yes
//## end module%52B437F200EB.epilog


#endif
