//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4242EBB00213.cm preserve=no
//	$Date:   Mar 04 2020 04:28:02  $ $Author:   E5350313  $ $Revision:   1.50.2.2  $
//## end module%4242EBB00213.cm

//## begin module%4242EBB00213.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4242EBB00213.cp

//## Module: CXOSBC18%4242EBB00213; Package body
//## Subsystem: Connex Library::BCDLL%394E1F84004A
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bcdll\CXOSBC18.cpp

//## begin module%4242EBB00213.additionalIncludes preserve=no
//## end module%4242EBB00213.additionalIncludes

//## begin module%4242EBB00213.includes preserve=yes
#include "CXODIF03.hpp"
//## end module%4242EBB00213.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSBC19_h
#include "CXODBC19.hpp"
#endif
#ifndef CXOSBS24_h
#include "CXODBS24.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSBC39_h
#include "CXODBC39.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif
#ifndef CXOSTM13_h
#include "CXODTM13.hpp"
#endif
#ifndef CXOSBC18_h
#include "CXODBC18.hpp"
#endif


//## begin module%4242EBB00213.declarations preserve=no
//## end module%4242EBB00213.declarations

//## begin module%4242EBB00213.additionalDeclarations preserve=yes
//## end module%4242EBB00213.additionalDeclarations


//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
//## begin command%3459269903E2.initialDeclarations preserve=yes
//## end command%3459269903E2.initialDeclarations

// Class command::ImportFile 

//## begin command::ImportFile::ImportTransaction%4451C13D02A1.attr preserve=no  public: static map<string, pair<ImportTransaction *,ImportFile *>, less<string> >* {V} 0
map<string, pair<ImportTransaction *,ImportFile *>, less<string> >* ImportFile::m_pImportTransaction = 0;
//## end command::ImportFile::ImportTransaction%4451C13D02A1.attr

//## begin command::ImportFile::Instance%424302A002FD.attr preserve=no  private: static command::ImportFile* {V} 0
command::ImportFile* ImportFile::m_pInstance = 0;
//## end command::ImportFile::Instance%424302A002FD.attr

//## begin command::ImportFile::Timer%4C40AD1103AD.attr preserve=no  private: static int {V} 60
int ImportFile::m_iTimer = 60;
//## end command::ImportFile::Timer%4C40AD1103AD.attr

//## begin command::ImportFile::<m_pTimer>%4C40A7C0001C.role preserve=no  public: static timer::Timer { -> RFHgN}
timer::Timer *ImportFile::m_pTimer = 0;
//## end command::ImportFile::<m_pTimer>%4C40A7C0001C.role

//## begin command::ImportFile::<m_pHourAlarm>%5228958F0216.role preserve=no  public: static timer::HourAlarm { -> RFHgN}
timer::HourAlarm *ImportFile::m_pHourAlarm = 0;
//## end command::ImportFile::<m_pHourAlarm>%5228958F0216.role

ImportFile::ImportFile()
  //## begin ImportFile::ImportFile%4242EB5F02FD_const.hasinit preserve=no
      : m_iDI_FILE_ID(0),
        m_siSEQ_NO(0),
        m_iTRANSACTION_NO(0),
        m_bVariableBlock(false),
        m_pGenerationDataGroup(0)
  //## end ImportFile::ImportFile%4242EB5F02FD_const.hasinit
  //## begin ImportFile::ImportFile%4242EB5F02FD_const.initialization preserve=yes
  //## end ImportFile::ImportFile%4242EB5F02FD_const.initialization
{
  //## begin command::ImportFile::ImportFile%4242EB5F02FD_const.body preserve=yes
   memcpy_s(m_sID,4,"BC18",4);
  //## end command::ImportFile::ImportFile%4242EB5F02FD_const.body
}


ImportFile::~ImportFile()
{
  //## begin command::ImportFile::~ImportFile%4242EB5F02FD_dest.body preserve=yes
   if (this == m_pInstance)
   {
      delete m_pTimer;
      delete m_pHourAlarm;
      Database::instance()->detach(this);
      m_pInstance = 0;
   }
  //## end command::ImportFile::~ImportFile%4242EB5F02FD_dest.body
}



//## Other Operations (implementation)
bool ImportFile::acceptRecord (char* pBuffer, int& m)
{
  //## begin command::ImportFile::acceptRecord%45E361A50178.body preserve=yes
   ++m_iTRANSACTION_NO;
   m_siSEQ_NO = 1;
   return true;
  //## end command::ImportFile::acceptRecord%45E361A50178.body
}

void ImportFile::add (const char* pszGENNAM, command::ImportTransaction* pImportTransaction, command::ImportFile* pImportFile)
{
  //## begin command::ImportFile::add%4242FB4B009C.body preserve=yes
   pair<ImportTransaction*,ImportFile*> hPair(pImportTransaction,pImportFile);
   if (!m_pImportTransaction)
      m_pImportTransaction = new map<string,pair<ImportTransaction*,ImportFile*>,less<string> >;
   m_pImportTransaction->insert(map<string,pair<ImportTransaction*,ImportFile*>,less<string> >::value_type(pszGENNAM,hPair));
  //## end command::ImportFile::add%4242FB4B009C.body
}

void ImportFile::age ()
{
  //## begin command::ImportFile::age%47D77D7E004E.body preserve=yes
   UseCase hUseCase("DR","## DR87 AGE IMPORT FILE");
   int iDI_FILE_ID = 0;
   int iDays = 60;
   string strDays;
   if (Extract::instance()->getSpec("AGEIMPRT",strDays))
   {
      iDays = atoi(strDays.c_str());
      if (iDays < 30)
         iDays = 30;
   }
   Date hDate(Date::today());
   hDate -= iDays;
   string strDate(hDate.asString("%Y%m%d"));
   Query hQuery;
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   hQuery.setBasicPredicate("DI_DATA_CONTROL","TSTAMP_INITIATED","<",strDate.c_str());
   UseCase::setSuccess(pDeleteStatement->execute(hQuery));
   UseCase::addItem(pDeleteStatement->getRows());
   Database::instance()->commit();
  //## end command::ImportFile::age%47D77D7E004E.body
}

ImportFile* ImportFile::instance ()
{
  //## begin command::ImportFile::instance%424302B40213.body preserve=yes
   if (!m_pInstance)
   {
      m_pInstance = new ImportFile();
      Database::instance()->attach(m_pInstance);
      m_pTimer = new Timer();
      m_pTimer->attach(m_pInstance);
      m_pHourAlarm = new HourAlarm;
      m_pHourAlarm->attach(m_pInstance);
      if ((m_iTimer = Extract::instance()->getTimer("IMPORT")) == -1)
         m_iTimer = 60;
      else
      if (m_iTimer < 2)
         m_iTimer = 2;
      else
      if (m_iTimer > 60)
         m_iTimer = 60;
      m_pTimer->set(m_iTimer);
   }
   return m_pInstance;
  //## end command::ImportFile::instance%424302B40213.body
}

void ImportFile::onResume ()
{
  //## begin command::ImportFile::onResume%4248272402FD.body preserve=yes
   if (!m_pImportTransaction)
   {
      Application::instance()->setQueueWaitOption(true);
      return;
   }
   map<string,pair<ImportTransaction*,ImportFile*>,less<string> >::iterator p;
   if (m_hImportTransactions.size() == 0)
   {
      UseCase hUseCase("DR","## DR88 IMPORT");
      string strDI_FILE_TYPE("(");
      for (p = m_pImportTransaction->begin();p != m_pImportTransaction->end();++p)
      {
         if (strDI_FILE_TYPE.length() > 1)
            strDI_FILE_TYPE.append(",",1);
         strDI_FILE_TYPE.append("'",1);
         strDI_FILE_TYPE += (*p).first;
         strDI_FILE_TYPE.append("'",1);
      }
      strDI_FILE_TYPE.append(")",1);
      Query hQuery;
      hQuery.attach(this);
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      int lDI_FILE_ID = 0;
      int lTRANSACTION_NO = 0;
      int lTSTAMP_RETRY_COUNT = 0;
      string strDI_PATH;
      string strTSTAMP_INITIATED;
      hQuery.join("DI_DATA","INNER","DI_DATA_CONTROL","DI_FILE_ID");
      hQuery.bind("DI_DATA","SEQ_NO",Column::LONG,&m_siSEQ_NO);
      m_hImportTransaction.bind(hQuery);
      hQuery.bind("DI_DATA","DATA_BUFFER",Column::STRING,&m_strDATA_BUFFER);
      hQuery.setBasicPredicate("DI_DATA_CONTROL","DI_FILE_ID",">=",m_iDI_FILE_ID);
      hQuery.setBasicPredicate("DI_DATA","DI_STATE","IN","('IF','IW')");
      hQuery.setBasicPredicate("DI_DATA","TSTAMP_RETRY_COUNT","<",5);
      hQuery.setBasicPredicate("DI_DATA","TSTAMP_NEXT_PARSE","<",Clock::instance()->getYYYYMMDDHHMMSSHN().c_str());
      hQuery.setBasicPredicate("DI_DATA_CONTROL","DI_FILE_TYPE","IN",strDI_FILE_TYPE.c_str());
      hQuery.setOrderByClause("DI_FILE_ID ASC,TRANSACTION_NO ASC,SEQ_NO ASC");
      bool b = pSelectStatement->execute(hQuery);
      if (pSelectStatement->getRows() == 0)
      {
         Application::instance()->setQueueWaitOption(true);
         UseCase::setSuccess(b);
         return;
      }
   }
   m_hImportTransaction = m_hImportTransactions.front(); 
   p = m_pImportTransaction->find(m_hImportTransaction.getDI_FILE_TYPE());
   if (p == m_pImportTransaction->end())
   {
      m_hImportTransactions.erase(m_hImportTransactions.begin(),m_hImportTransactions.end());
      Application::instance()->setQueueWaitOption(true);
      UseCase::setSuccess(false);
      return;
   }
   ImportReportAuditSegment::instance()->setTSTAMP_INITIATED(Timestamp::format(m_hImportTransaction.getTSTAMP_INITIATED()));
   ImportReportAuditSegment::instance()->setPATH(m_hImportTransaction.getDI_PATH());
   ImportReportAuditSegment::instance()->setDI_FILE_ID(m_hImportTransaction.getDI_FILE_ID());
   (*p).second.first->setTSTAMP_RETRY_COUNT(m_hImportTransaction.getTSTAMP_RETRY_COUNT());
   (*p).second.first->execute(m_hImportTransaction);
   m_hImportTransactions.pop_front();
  //## end command::ImportFile::onResume%4248272402FD.body
}

bool ImportFile::read (const char* pszGENNAM, bool bTruncate)
{
  //## begin command::ImportFile::read%424321DB035B.body preserve=yes
   UseCase hUseCase("DR","## DR36 READ IMPORT FILE");
   m_strFileName = pszGENNAM;
   if (!m_pImportTransaction)
      return false;
   map<string,pair<ImportTransaction*,ImportFile*>,less<string> >::iterator p = m_pImportTransaction->find(pszGENNAM);
   if (p == m_pImportTransaction->end())
      return false;
   if (!(*p).second.second) // DNBTCH has no file
      return false;
   m_bVariableBlock = (*p).second.second->getVariableBlock();
   m_pGenerationDataGroup = new GenerationDataGroup(Application::instance()->image(),Application::instance()->name(),pszGENNAM,m_bVariableBlock);
   if (!m_pGenerationDataGroup->open())
   {
      delete m_pGenerationDataGroup;
      return false;
   }
   Query hQuery;
   int lDI_FILE_ID = 0;
   short iNull = -1;
   hQuery.bind("DI_DATA_CONTROL","DI_FILE_ID",Column::LONG,&lDI_FILE_ID,&iNull,"MAX");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
   {
      Database::instance()->rollback();
      delete m_pGenerationDataGroup;
      return UseCase::setSuccess(false);
   }
   ++lDI_FILE_ID;
   m_strTSTAMP_INITIATED = Clock::instance()->getYYYYMMDDHHMMSSHN();
   auto_ptr<reusable::Statement> pInsertStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("InsertStatement"));
   reusable::Table hTable("DI_DATA_CONTROL");
   hTable.set("DI_FILE_ID",lDI_FILE_ID,true);
   hTable.set("DI_FILE_TYPE",pszGENNAM);
#ifdef MVS
   hTable.set("DI_PATH",m_pGenerationDataGroup->datasetName());
#else
   hTable.set("DI_PATH",m_pGenerationDataGroup->getName());
#endif
   hTable.set("TSTAMP_INITIATED",m_strTSTAMP_INITIATED);
   if (!pInsertStatement->execute(hTable))
   {
      Database::instance()->rollback();
      delete m_pGenerationDataGroup;
      return UseCase::setSuccess(false);
   }
   m_iTRANSACTION_NO = 0;
   m_siSEQ_NO = 1;
   m_strTranSeqNum = "0";
   string strDATA_BUFFER;
   size_t m = 0;
   int iLen = 0;
   string strTemp;
   IString strRecord;
   Extract::instance()->get("DUSER   ",strRecord);
   char szReadBuffer[32768];
   while (m_pGenerationDataGroup->read(szReadBuffer,32768,&m))
   {
      if (m < SIZE_MAX)
         iLen = (int)m;
      if (m > 0 && acceptRecord(szReadBuffer, iLen))
      {
         ImportData::instance()->setTRANSACTION_NO(m_iTRANSACTION_NO);
         ImportData::instance()->setSEQ_NO(m_siSEQ_NO);
         ImportData::instance()->setDI_FILE_ID(lDI_FILE_ID);
         ImportData::instance()->setIMPORT_KEY(strTemp);
         if (ImportData::instance()->insert(szReadBuffer,m,bTruncate)  == false)
         {
            Database::instance()->rollback();
            delete m_pGenerationDataGroup;
            return UseCase::setSuccess(false);
         }
      }
   }
   m_pGenerationDataGroup->commit();
   Database::instance()->commit();
   Console::display("ST274"); // ST274 - PROCESSING OF IMPORT FILE RECORDS STARTING
   delete m_pGenerationDataGroup;
   Application::instance()->setQueueWaitOption(false);
   return true;
  //## end command::ImportFile::read%424321DB035B.body
}

void ImportFile::update (Subject* pSubject)
{
  //## begin command::ImportFile::update%4242EB8403A9.body preserve=yes
   if (pSubject == m_pTimer)
   {
#ifndef MVS
      if (m_pImportTransaction)
      {
         map<string,pair<ImportTransaction*,ImportFile*>,less<string> >::iterator p;
         for (p = m_pImportTransaction->begin();p != m_pImportTransaction->end();++p)
            if ((*p).second.second) // DNBTCH has no file
               (*p).second.second->read((*p).first.c_str(),false);
      }
#endif
      m_pTimer->set(m_iTimer);
      Application::instance()->setQueueWaitOption(false);
      return;
   }
   if (pSubject == m_pHourAlarm )
   {
      if (!m_pImportTransaction)
         return;
      map<string,pair<ImportTransaction*,ImportFile*>,less<string> >::iterator p;
      string strDI_FILE_TYPE("(");
      for (p = m_pImportTransaction->begin();p != m_pImportTransaction->end();++p)
      {
         if (strDI_FILE_TYPE.length() > 1)
            strDI_FILE_TYPE.append(",",1);
         strDI_FILE_TYPE.append("'",1);
         strDI_FILE_TYPE += (*p).first;
         strDI_FILE_TYPE.append("'",1);
      }
      strDI_FILE_TYPE.append(")",1);
      Query hQuery;
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      short iNull = -1;
      hQuery.join("DI_DATA","INNER","DI_DATA_CONTROL","DI_FILE_ID");
      hQuery.bind("DI_DATA_CONTROL","DI_FILE_ID",Column::LONG,&m_iDI_FILE_ID,&iNull,"MIN");
      hQuery.setBasicPredicate("DI_DATA","DI_STATE","IN","('IF','IW')");
      hQuery.setBasicPredicate("DI_DATA","TSTAMP_RETRY_COUNT","<",5);
      hQuery.setBasicPredicate("DI_DATA_CONTROL","DI_FILE_TYPE","IN",strDI_FILE_TYPE.c_str());
      if (pSelectStatement->execute(hQuery) && iNull == -1)
      {
         hQuery.reset();
         hQuery.bind("DI_DATA_CONTROL","DI_FILE_ID",Column::LONG,&m_iDI_FILE_ID,&iNull,"MAX");
         if (!pSelectStatement->execute(hQuery) || iNull == -1 )
            m_iDI_FILE_ID = 0;
      }
      return;
   }
   if (pSubject == Database::instance())
   {
      if (Database::instance()->state() == Database::CONNECTED
         && m_pImportTransaction)
      {
         update(m_pHourAlarm);
         Application::instance()->setQueueWaitOption(false);
      }
      return;
   }
   if (m_siSEQ_NO == 1)
   {
      string strSCHED_TIME(m_hImportTransaction.getTSTAMP_INITIATED().data() + 8,4);
      char szTemp[PERCENTD];
      snprintf(szTemp,sizeof(szTemp),"%02d",m_hImportTransaction.getTSTAMP_RETRY_COUNT() + 1);
      strSCHED_TIME.append(szTemp,2);
      m_hImportTransaction.setSCHED_TIME(strSCHED_TIME); 
      m_hImportTransactions.push_back(m_hImportTransaction);
   }
   m_hImportTransactions.back().getDATA_BUFFER().push_back(m_strDATA_BUFFER);
   return;
  //## end command::ImportFile::update%4242EB8403A9.body
}

// Additional Declarations
  //## begin command::ImportFile%4242EB5F02FD.declarations preserve=yes
  //## end command::ImportFile%4242EB5F02FD.declarations

} // namespace command

//## begin module%4242EBB00213.epilog preserve=yes
//## end module%4242EBB00213.epilog
