//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E4A573A01A5.cm preserve=no
//	$Date:   Jul 17 2020 08:25:58  $ $Author:   e1009339  $
//	$Revision:   1.82.1.0  $
//## end module%3E4A573A01A5.cm

//## begin module%3E4A573A01A5.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%3E4A573A01A5.cp

//## Module: CXOSBL03%3E4A573A01A5; Package body
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bldll\CXOSBL03.cpp

//## begin module%3E4A573A01A5.additionalIncludes preserve=no
//## end module%3E4A573A01A5.additionalIncludes

//## begin module%3E4A573A01A5.includes preserve=yes
// $Date:   Jul 17 2020 08:25:58  $ $Author:   e1009339  $ $Revision:   1.82.1.0  $
#include "CXODBL04.hpp"  // Mandatory field arrays
#include "CXODIF03.hpp"
//## end module%3E4A573A01A5.includes

#ifndef CXOSBL03_h
#include "CXODBL03.hpp"
#endif
//## begin module%3E4A573A01A5.declarations preserve=no
//## end module%3E4A573A01A5.declarations

//## begin module%3E4A573A01A5.additionalDeclarations preserve=yes
/*
  TYPE CODES: 
    C = CASE SEGMENT
    U = CASE UNIQUE SEGMENT
    P = PHASE SEGMENT
    H = PHASE UNIQUE SEGMENT
    N = NATIONAL NETWORKS SEGMENT
    Y = PAYMENT SEGMENT
    A = PRE AUTH SEGMENT
    F = FILLER 
    M = MEMBER VARIABLE REQUIRED
    
*/

#define ELEMENTS 84
#define CUR_CASHBACK_IDX 46
#define CASHBACK_AMT_IDX 48
#define CUR_POI_IDX 51
#define AMT_POI_IDX 53
#define CUR_SURCHARGE_FEE_IDX 56
#define AMT_SURCHARGE_FEE_IDX 58

Elements MasterCardMessage_Elements[ELEMENTS + 1] =
{
//   0, 1,C           
//   1, 1,C           
     2, 1,AN  ,"Y        ","v19 ",'C',"PAN",
     3, 1,AN  ,"         ","v6  ",'U',"PROCESS_CODE",
     4, 1,FLT ," %012.0f ","f12 ",'P',"AMT_ADJUSTMENT",
     5, 1,FLT ," %012.0f ","f12 ",'P',"AMT_ADJ_TRAN",
     6, 1,FLT ," %012.0f ","f12 ",'P',"AMT_ADJ_CARD_BILL",
//   7, 1,NUM ," %010d   ","f10 ",'C',"TRAN_DATE_TIME", 
//   8, 1,NUM ," %08d    ","f8  ",'C',"CARD_BILL_FEE_AMT",   
     9, 1,NUM ," %08d    ","f8  ",'F'," ", // "RECON_CONV_RATE",     // ???
    10, 1,NUM ," %08d    ","f8  ",'F'," ", // CARD_BILL_CONV_RATE",  // ??? 
    11, 1,AN  ,"         ","f6  ",'C',"SYS_TRACE_AUDIT_NO",  
    12, 1,AN  ,"         ","s12 ",'C',"TSTAMP_LOCAL",  // LAST 12 BYTES
 // 13, 1,NUM ," %04d    ","f4  ",'C',"EFFECTIVE_DATE",
    14, 1,AN  ,"         ","f4  ",'F'," ",
 // 15, 1,NUM ," %06d    ","f6  ",'P',"SETTLEMENT_DATE",
 // 16, 1,NUM ," %04d    ","f4  ",'P',"CONVERSION_DATE",
 // 17, 1,NUM ," %04d    ","f4  ",'C',"CAPTURE_DATE",
 // 18, 1,NUM ," %04d    ","f4  ",'C',"MERCHANT_TYPE",
 // 19, 1,NUM ," %03d    ","f8  ",'C',"CARD_BILL_CONV_RATE",
 // 20, 1,NUM ," %03d    ","f3  ",'C',"PAN_COUNTRY_CODE",    
 // 21, 1,NUM ," %03d    ","f3  ",'C',"FORWARD_INST_COUNTRY_CODE",
    22, 1,AN  ,"         ","v1  ",'U',"CARD_INP_CAP_IND",
    22, 2,AN  ,"         ","v1  ",'U',"CARDH_AUTH_CAP_IND",
    22, 3,AN  ,"         ","v1  ",'U',"CARD_CAPT_CAP_IND",
    22, 4,AN  ,"         ","v1  ",'U',"TERM_OPER_ENVI_IND",
    22, 5,AN  ,"         ","v1  ",'U',"CARDH_PRESENT_IND",
    22, 6,AN  ,"         ","v1  ",'U',"CARD_PRESENT_IND",
    22, 7,AN  ,"         ","v1  ",'U',"CARD_INP_MODE_IND",
    22, 8,AN  ,"         ","v1  ",'U',"CARDH_AUTHMOD_IND",
    22, 9,AN  ,"         ","v1  ",'U',"CARDH_AUTHENT_IND",
    22,10,AN  ,"         ","v1  ",'U',"CARD_OUT_CAP_IND",
    22,11,AN  ,"         ","v1  ",'U',"TERM_OUT_CAP_IND",
    22,12,AN  ,"         ","v1  ",'U',"PIN_CAPT_CAP_IND",
    23, 1,NUM ," %03d    ","f3  ",'C',"CARD_SEQ_NO",
 // 24, 1,NUM ," %03d    ","f3  ",'C',"FUNCTION_CODE",       
    25, 1,ALP  ,"         ","f4  ",'P',"REASON_CODE",  // FIRST 4 BYTES
    26, 1,AN  ,"         ","v4  ",'C',"MERCHANT_CAT_CODE", 
 // 28, 1,NUM ," %06d    ","f6  ",'C',"RECON_DATE",
 // 29, 1,NUM ," %03d    ","f3  ",'C',"RECON_INDICATOR",    
    30, 1,FLT ," %012.0f ","f12 ",'C',"AMT_TRAN", 
    30, 2,ALP  ,"         ","f12 ",'F',"000000000000", 
    31, 1,ANS ,"         ","v23 ",'N',"ACQ_REF_NO",             
    32, 1,NUM ," %011d   ","f11 ",'U',"ACQ_ICA",
    33, 1,NUM ," %011d   ","f11 ",'U',"ISS_ICA",
 // 34, 1,AN  ,"         ","v28 ",'C',"PAN_EXTENDED",
 // 35, 1,ANS ,"         ","v37 ",'C',"TRACK2_DATA",
 // 36, 1,ANS ,"         ","v104",'C',"TRACK3_DATA",
    37, 1,ANS ,"         ","v12 ",'C',"RETRIEVAL_REF_NO",
    38, 1,AN  ,"         ","v6  ",'N',"AUTH_ID_RESP",
 // 39, 1,NUM ," %03d    ","f3  ",'C',"ACTION_CODE",    
    40, 1,NUM ," %03d    ","f3  ",'F',"000", // "SERVICE_CODE"
    41, 1,ANS ,"         ","v8  ",'C',"NET_TERM_ID",         
    42, 1,ANS ,"         ","v15 ",'C',"CARD_ACPT_ID",
    43, 1,ANS ,"         ","v83 ",'C',"CARD_ACPT_NAME", //CARD_ACPT_NAME/LOC/CITY
    43, 2,ANS ,"         ","v10 ",'C',"CARD_ACPT_ZIP",               
    43, 3,ANS ,"         ","v3  ",'C',"CARD_ACPT_REGION",
    43, 4,ANS ,"         ","v3  ",'C',"CARD_ACPT_COUNTRY",
//    44, 1,ANS ,"         ","v99 ",'C',"ADD_RESPONSE_DATA",
    45, 1,ANS ,"         ","v76 ",'C',"TRACK1_DATA",
 // 46, 1,ANS ,"         ","v204",'C',"FEES_AMOUNTS",
 // 47, 1,ANS ,"         ","v999",'C',"ADDITIONAL_DATA_NATL",
    48,-1,ANS ,"         ","v999",'C',"ADDITIONAL_DATA",  // Use secondary table
    49, 1,AN  ,"         ","v3  ",'P',"CUR_ADJUSTMENT", //recon amt currency
    50, 1,AN  ,"         ","f3  ",'P',"CUR_ADJ_TRAN",  
    51, 1,AN  ,"         ","f3  ",'P',"CUR_CARDH_BILL",      
 // 52
    54, 1,ALP  ,"         ","f2  ",'F',"09",   //  Account Type           
    54, 2,ALP  ,"         ","f2  ",'F',"40",   //  Amount Type            
    54, 3,AN  ,"         ","v3  ",'C',"CUR_CASHBACK",  //  Currency Code 
    54, 4,ALP  ,"         ","f1  ",'F',"D",     //  Amount Sign           
    54, 5,AMT ," %012d   ","f12 ",'C',"CASHBACK_AMT", //CashBack Amt   
    54, 6,ALP  ,"         ","f2  ",'F',"00",   //  POI Account Type
    54, 7,ALP  ,"         ","f2  ",'F',"58",   //  POI Amount Type
    54, 8,AN  ,"         ","v3  ",'U',"CUR_POI",  //  POI Currency Code 
    54, 9,ALP  ,"         ","f1  ",'F',"D",     //  POI Amount Sign 
    54,10,AMT ," %012d   ","f12 ",'U',"AMT_POI", // POI CashBack Amt 
    54,11,ALP  ,"         ","f2  ",'F',"00",   
    54,12,ALP  ,"         ","f2  ",'F',"42",   
    54,13,AN  ,"         ","v3  ",'C',"CUR_SURCHARGE_FEE",   
    54,14,ALP  ,"         ","f1  ",'F',"D",      
    54,15,AMT ," %012d   ","f12 ",'C',"AMT_SURCHARGE_FEE", 
    54,16,ALP  ,"         ","f2  ",'F',"  ",   
    54,17,ALP  ,"         ","f2  ",'F',"  ",   
    54,18,AN  ,"         ","v3  ",'F',"   ",   
    54,19,ALP  ,"         ","f1  ",'F'," ",      
    54,20,AMT ," %012d   ","f12 ",'F',"000000000000", 
    54,21,ALP  ,"         ","f2  ",'F',"  ",   
    54,22,ALP  ,"         ","f2  ",'F',"  ",   
    54,23,AN  ,"         ","v3  ",'F',"   ",   
    54,24,ALP  ,"         ","f1  ",'F'," ",      
    54,25,AMT ," %012d   ","f12 ",'F',"000000000000", 
    54,26,ALP  ,"         ","f2  ",'F',"  ",   
    54,27,ALP  ,"         ","f2  ",'F',"  ",   
    54,28,AN  ,"         ","v3  ",'F',"   ",   
    54,29,ALP  ,"         ","f1  ",'F'," ",      
    54,30,AMT ," %012d   ","f12 ",'F',"000000000000", 
    55, 1,ALP  ,"         ","f255",'F'," ", // 'INT_CIRCUIT_CARD",  // ???
 // 56
 // ...
 // 61
 // 62, 1,ANS ,"         ","v999",'C',"ADDL_DATA2",
    63, 1,ANS ,"         ","v1  ",'U',"LIFECYCLE_SUP_IND", 
    63, 2,ANS ,"         ","v15 ",'U',"LIFECYCLE_TRACE_ID", 
 // 64
 // ...
 // 70
    71, 1,NUM ," %08d    ","f8  ",'M',"SOURCE_MSG_NO",  // MEMBER VARIABLE
    72, 1,ANS ,"         ","v99 ",'H',"MC_MMT",
    73, 1,AN  ,"         ","v6  ",'U',"DATE_ACTION", // ACTION DATE
 // 74                                  
 // ...
 // 92
    93, 1,NUM ," %011d   ","f11 ",'U',"ACQ_ICA",
    94, 1,NUM ," %011d   ","f11 ",'U',"ISS_ICA",
    95, 1,AN  ,"         ","v10 ",'H',"CARD_ISS_REF_DATA",
 // 96
 // 97
 // 98
 // 99
   100, 1,ALP  ," %011s   ","f11 ",'F'," ",
 //101
 //...
 //122
 //123, 1,ANS ,"         ","v999",'C',"ADDL_DATA3",
 //124, 1,ANS ,"         ","v999",'C',"ADDL_DATA4",
 //125, 1,ANS ,"         ","v999",'C',"ADDL_DATA5",
 //126
 //127
 //128, 1,B   '"         ","    ",'C',"MAC"
     0, 1,0   ,"~","~",' ',"~"
};

#define PDS_ELEMENTS 162
Elements MasterCardMessage_PDS_Elements[PDS_ELEMENTS + 1] =
{
 //  2, 1,ANS  ,"         ","f3  ",'C',"PRODUCT_ID",
 //  5, 1,ANS  ,"         ","v110",'P',"MSG_ERR_IND",
     5, 1,ANS  ,"         ","f5  ",'H',"ERR_DE_1",
     5, 2,ANS  ,"         ","f2  ",'H',"ERR_SEV_CODE_1",
     5, 3,ANS  ,"         ","f4  ",'H',"ERR_MSG_1",
     5, 4,ANS  ,"         ","f3  ",'H',"ERR_SUBFIELD_ID_1",
     5, 5,ANS  ,"         ","f5  ",'H',"ERR_DE_2",
     5, 6,ANS  ,"         ","f2  ",'H',"ERR_SEV_CODE_2",
     5, 7,ANS  ,"         ","f4  ",'H',"ERR_MSG_2",
     5, 8,ANS  ,"         ","f3  ",'H',"ERR_SUBFIELD_ID_2",
     5, 9,ANS  ,"         ","f5  ",'H',"ERR_DE_3",
     5,10,ANS  ,"         ","f2  ",'H',"ERR_SEV_CODE_3",
     5,11,ANS  ,"         ","f4  ",'H',"ERR_MSG_3",
     5,12,ANS  ,"         ","f3  ",'H',"ERR_SUBFIELD_ID_3",
     5,13,ANS  ,"         ","f5  ",'H',"ERR_DE_4",
     5,14,ANS  ,"         ","f2  ",'H',"ERR_SEV_CODE_4",
     5,15,ANS  ,"         ","f4  ",'H',"ERR_MSG_4",
     5,16,ANS  ,"         ","f3  ",'H',"ERR_SUBFIELD_ID_4",
     5,17,ANS  ,"         ","f5  ",'H',"ERR_DE_5",
     5,18,ANS  ,"         ","f2  ",'H',"ERR_SEV_CODE_5",
     5,19,ANS  ,"         ","f4  ",'H',"ERR_MSG_5",
     5,20,ANS  ,"         ","f3  ",'H',"ERR_SUBFIELD_ID_5",
     5,21,ANS  ,"         ","f5  ",'H',"ERR_DE_6",
     5,22,ANS  ,"         ","f2  ",'H',"ERR_SEV_CODE_6",
     5,23,ANS  ,"         ","f4  ",'H',"ERR_MSG_6",
     5,24,ANS  ,"         ","f3  ",'H',"ERR_SUBFIELD_ID_6",
     5,25,ANS  ,"         ","f5  ",'H',"ERR_DE_7",
     5,26,ANS  ,"         ","f2  ",'H',"ERR_SEV_CODE_7",
     5,27,ANS  ,"         ","f4  ",'H',"ERR_MSG_7",
     5,28,ANS  ,"         ","f3  ",'H',"ERR_SUBFIELD_ID_7",
     5,29,ANS  ,"         ","f5  ",'H',"ERR_DE_8",
     5,30,ANS  ,"         ","f2  ",'H',"ERR_SEV_CODE_8",
     5,31,ANS  ,"         ","f4  ",'H',"ERR_MSG_8",
     5,32,ANS  ,"         ","f3  ",'H',"ERR_SUBFIELD_ID_8",
     5,33,ANS  ,"         ","f5  ",'H',"ERR_DE_9",
     5,34,ANS  ,"         ","f2  ",'H',"ERR_SEV_CODE_9",
     5,35,ANS  ,"         ","f4  ",'H',"ERR_MSG_9",
     5,36,ANS  ,"         ","f3  ",'H',"ERR_SUBFIELD_ID_9",
     5,37,ANS  ,"         ","f5  ",'H',"ERR_DE_10",
     5,38,ANS  ,"         ","f2  ",'H',"ERR_SEV_CODE_10",
     5,39,ANS  ,"         ","f4  ",'H',"ERR_MSG_10",
     5,40,ANS  ,"         ","f3  ",'H',"ERR_SUBFIELD_ID_10",
     6, 1,AN   ,"         ","f3  ",'F'," ",//ACPT_BRAND_CODE",
     6, 2,AN   ,"         ","f1  ",'F'," ",//BUS_SERV_LVL_IND",
     6, 3,AN   ,"         ","f6  ",'F'," ",//BUS_SERV_CODE",
//  20, 1,ALP  ,"         ","f6  ",'F'," ", // "DATE_CONV",      
    23, 1,ANS  ,"         ","v3  ",'U',"TERMINAL_TYPE",
    25, 1,ALP  ,"         ","f7  ",'M',"MsgRevInd", 
    26, 1,ALP  ,"         ","f7  ",'F'," ", // "FILE_REV_IND",   
    43, 1,ALP  ,"         ","f3  ",'F'," ", // "PGM_REG_ID",     
    52, 1,ANS  ,"         ","v3  ",'U',"MCI_ECS_LVL_IND",
    58, 1,ANS  ,"         ","v2  ",'E',"TOKEN_ASSURANCE",
    59, 1,ANS  ,"         ","v11 ",'E',"TOKEN_REQUESTOR_ID",
   105, 1,AN   ,"         ","f3  ",'M',"FileType",  
   105, 2,AN   ,"         ","f6  ",'M',"RefData",   
   105, 3,AN   ,"         ","f11 ",'M',"MemProcID", 
   105, 4,AN   ,"         ","f5  ",'M',"SeqNo",   // File_ID
   122, 1,ANS  ,"         ","f1  ",'M',"ProcMode",      // ???
   137, 1,NUM  ," %020d   ","f20 ",'U',"FEE_CNTL_NO",  
   138, 1,NUM  ," %08d    ","f8  ",'M',"SOURCE_MSG_NO_ID",
   146, 1, ALP ,"         ","f2  ",'F',"00", //  Fee Type Code,
   146, 2, AN  ,"         ","f2  ",'U',"PROCESS_CODE", //  Fee Processing Code,
   146, 3, ALP ,"         ","f2  ",'F',"00", //  Fee Settlement Indicator,
   146, 4, AN  ,"         ","f3  ",'C',"CUR_SURCHARGE_FEE", //  Fee currency,   
   146, 5, AMT ," %08d    ","f8  ",'C',"AMT_INTRCHG_FEE", //  Fee Amount,
   146, 6, AN  ,"         ","f3  ",'C',"CUR_SURCHARGE_FEE", //  Recon Fee currency,   
   146, 7, AMT ," %08d    ","f8  ",'C',"AMT_INTRCHG_FEE", //  Recon Fee Amount,
   146, 8, ALP ,"         ","f308",'F'," ",
   148, 1,AN   ,"         ","f3  ",'F'," ",   
   148, 2,AN   ,"         ","f1  ",'F'," ",   
   148, 3,AN   ,"         ","v3  ",'F'," ",   
   148, 4,AN   ,"         ","v1  ",'F'," ",   
   148, 5,ALP  ,"         ","f52 ",'F'," ",   // CUR-EXP-ENTRIES 4x14 
   149, 1,AN   ,"         ","f3  ",'C',"CUR_TRAN",
   149, 2,ALP  ,"         ","f3  ",'F',"000", 
//   150, 1,ALP  ,"         ","f168",'F'," ", // ??? UNIDENTIFIED ACQ-INTR-CUR-CONV
 //158, 1,ANS ,"         ","v20 ",'C',"BUS_ACTIVITY",
   158, 1,AN   ,"         ","v3  ",'U',"ACPT_BRAND_CODE",
   158, 2,AN   ,"         ","v1  ",'U',"BUS_SERV_LVL_IND",
   158, 3,AN   ,"         ","v6  ",'U',"BUS_SERV_CODE",
   158, 4,AN   ,"         ","v2  ",'U',"INTRCHG_RATE_DSG",
   158, 5,AN   ,"         ","v6  ",'U',"BUS_DATE",  // 6 0F 8 BYTES
   158, 6,AN   ,"         ","v2  ",'U',"BUS_CYCLE",
   159, 1,ALP  ,"         ","f39 ",'F'," ", // "SETTLE_DATA1", 
   159, 3,AN   ,"         ","v1  ",'C',"CNV_RCN_STL_IND", 
   159, 4,ALP  ,"         ","f27 ",'F'," ",
   165, 1,ANS  ,"         ","f1  ",'H',"SETL_IND",
   165, 2,ALP  ,"         ","f29 ",'F'," ",  // ???
   170, 1,ANS  ,"         ","v16 ",'U',"CUST_SERV_PHONE",
   170, 2,ANS  ,"         ","v16 ",'U',"MERCH_PHONE",
   170, 3,ANS  ,"         ","v25 ",'U',"ADDL_CONTACT_INFO",
   171, 1,ALP  ,"         ","f99 ",'F'," ", // "ALT_MERCH_DESC", 
   172, 1,ALP  ,"         ","f30 ",'F'," ", // "SOLE_PROP_NAME",
   173, 1,ALP  ,"         ","f30 ",'F'," ", // "LEGAL_CORP_NAME",
   174, 1,ALP  ,"         ","f15 ",'F'," ",    // "DUN_&_BRAD_NO",
   175, 1,ALP  ,"         ","f99 ",'F'," ", // "CARD_ACPT_URL", 
   176, 1,ANS  ,"         ","v6  ",'U',"MCI_ASSIGNED_ID",
   181, 1,ANS  ,"         ","v2  ",'Y',"INSTALLMENT_TYPE",
   181, 2,NUM  ,"Y%02d    ","f2  ",'Y',"NUM_INSTALLMENTS",
   181, 3,NUM  ,"Y%05d    ","f5  ",'Y',"ISS_INTER_RATE",
   181, 4,NUM  ,"Y%012d   ","f12 ",'Y',"AMT_FIRST",
   181, 5,NUM  ,"Y%012d   ","f12 ",'Y',"AMT_SUBSEQUENT",
   181, 6,NUM  ,"Y%05d    ","f5  ",'Y',"ANNUAL_PERCNT_RATE",
   181, 7,NUM  ,"Y%012d   ","f12 ",'Y',"F_AMT_INSTALLMENT",
   189, 1,ALP  ,"         ","f41 ",'F'," ", // "POI_PHONE",      
   190, 1,ALP  ,"         ","f6  ",'F'," ", // "PARTNER_ID",     
   191, 1,AN   ,"         ","f1  ",'M',"MsgInd",
   192, 1,AN   ,"         ","v3  ",'U',"PYMT_TRAN_INIT",
   194, 1,AN   ,"         ","v1  ",'U',"REMOTE_PGM_IND",
   200, 1,AN   ,"         ","v6  ",'U',"FRD_NOTIFY_DATE", 
   200, 2,AN   ,"         ","v2  ",'U',"FRD_NOTIFY_SVC_COUNTER",
   207, 1,AN   ,"         ","v3  ",'U',"PPOL_PGM_DATA",
   208, 1,FLT  ," %011.0f ","f11 ",'U',"PAYMENT_FID",
   208, 2,ANS  ,"         ","v15 ",'U',"MERCHANT_ID",
   209, 1,FLT  ," %011.0f ","f11 ",'U',"SALES_ORG_ID",
   210, 1,AN   ,"         ","v2  ",'U',"TRANSIT_TRAN_IND",
   210, 2,AN   ,"         ","v2  ",'U',"TRANSPORT_MODE_IND",
   228, 1,NUM  ," %d      ","f1  ",'H',"DOC_CODE_IND",
   230, 1,NUM  ," %d      ","f1  ",'H',"DOC_CODE_IND",
   231, 1,ALP  ,"         ","f7  ",'F'," ", // UNIDENTIFIED MC-PREF-ACQ-ENDPT
   241, 1,ANS  ,"         ","v7  ",'U',"MASTERCOM_CTRL_NO", // "MASTERCOM_CTRL_NO",  
   242, 1,ALP  ,"         ","f1  ",'F'," ", // "MC_SERVICE_IND",  
   243, 1,ALP  ,"         ","f38 ",'F'," ", // "MC_RETRVL_RESP",  
   244, 1,ALP  ,"         ","f12 ",'F'," ", // "SUPPORT_DOC_DATE",
   260, 1,ALP  ,"         ","f4  ",'F'," ", // "EDIT_EXCL_IND",   // ???
   262, 1,NUM  ," %d      ","f1  ",'H',"DOC_IND",
   263, 1,AN   ,"         ","v15 ",'F'," ", //INTRCHG_LIFE_CYCLE",
   264, 1,AN   ,"         ","f4  ",'U',"ORIG_RTR_RESN",
   265, 1,ALP  ,"         ","f110",'F'," ", // "INIT_PRES_FEE_COL",// ???
   266, 1,ALP  ,"         ","f127",'F'," ", // "CHG_FEE_COL_RTRN", 
   267, 1,ALP  ,"         ","f127",'F'," ", // "SEC_PRES_FEE_COL_RTRN",// ???
   268, 1,AN   ,"         ","f12 ",'M'," ", // PARTIAL_AMT
   268, 2,AN   ,"         ","f3  ",'P',"CUR_ADJUSTMENT",
   280, 1,AN   ,"         ","f3  ",'M',"FileType",   
   280, 2,AN   ,"         ","f6  ",'M',"RefData",   
   280, 3,AN   ,"         ","f11 ",'M',"MemProcID", 
   280, 4,AN   ,"         ","f5  ",'M',"SeqNo",   
   300, 1,AN   ,"         ","f3  ",'M',"FileType",  
   300, 2,AN   ,"         ","f6  ",'M',"RefData",   
   300, 3,AN   ,"         ","f11 ",'M',"MemProcID", 
   300, 4,AN   ,"         ","f5  ",'M',"SeqNo",   // File_ID
   301, 1,AN   ,"         ","f16 ",'M',"CheckSumAmount",  
   302, 1,AN   ,"         ","f1  ",'C',"RECON_MEM_ACTIVITY",
   306, 1,AN   ,"         ","f8  ",'M',"TotalRecs",         
// 358, 1,ANS  ,"         ","v20 ",'C',"RECON_BUS_ACTIVITY",
   358, 1,AN   ,"         ","f3  ",'C',"ACPT_BRAND_CODE",
   358, 2,AN   ,"         ","f1  ",'C',"BUS_SERV_LVL_IND",
   358, 3,AN   ,"         ","f6  ",'C',"BUS_SERV_CODE",
   358, 4,AN   ,"         ","f2  ",'C',"INTRCHG_RATE_DSG",
   358, 5,AN   ,"         ","f6  ",'C',"BUS_DATE",
   358, 6,AN   ,"         ","f2  ",'C',"BUS_CYCLE",
   370, 1,AN   ,"         ","v38 ",'C',"RECON_ACCT_RANGE",  // ???
   372, 1,NUM  ," %07d    ","f7  ",'C',"RECON_TRAN_FUNC",   // ???       
   374, 1,NUM  ," %02d    ","f2  ",'C',"RECON_PROC_CD",     // ???         
   378, 1,ALP  ,"         ","f1  ",'C',"ORIG_REV_TOT_IND",  // ???
   380, 1,AN   ,"         ","f17 ",'C',"DEBIT_TRAN_AMT",    // ???
   381, 1,AN   ,"         ","f17 ",'C',"CREDIT_TRAN_AMT",   // ??? 
   382, 1,AN   ,"         ","f17 ",'C',"NET_TRAN_AMT",      // ???
   390, 1,AN   ,"         ","f17 ",'C',"DEBIT_RECON_AMT",   // ???
   391, 1,AN   ,"         ","f17 ",'C',"CREDIT_RECON_AMT",  // ???
   392, 1,AN   ,"         ","f15 ",'C',"DEBIT_REC_FEE_AMT", // ???
   393, 1,AN   ,"         ","f15 ",'C',"CREDIT_REC_FEE_AMT",// ???
   394, 1,AN   ,"         ","f17 ",'C',"NET_RECON_AMT",     // ???
   395, 1,AN   ,"         ","f15 ",'C',"NET_RECON_FEE",     // ???
   396, 1,AN   ,"         ","f17 ",'C',"NET_RECON_TOT",     // ???
   400, 1,NUM  ," %010d   ","f10 ",'C',"DEBT_TRAN_NO",      // ???
   401, 1,NUM  ," %010d   ","f10 ",'C',"CRED_TRAN_NO",      // ???
   402, 1,NUM  ," %010d   ","f10 ",'C',"TOTL_TRAN_NO",      // ???
     0, 1,0    ,"~","~",' ',"~"
};

//## end module%3E4A573A01A5.additionalDeclarations


//## Modelname: Connex Library::BitMapLayouts_CAT%3E4A483C030D
namespace bmlayouts {
//## begin bmlayouts%3E4A483C030D.initialDeclarations preserve=yes
//## end bmlayouts%3E4A483C030D.initialDeclarations

// Class bmlayouts::MasterCardMessage 

MasterCardMessage::MasterCardMessage()
  //## begin MasterCardMessage::MasterCardMessage%3E4A56860251_const.hasinit preserve=no
      : m_lNumberOfPDSelements(0),
        m_lSOURCE_MSG_NO(0)
  //## end MasterCardMessage::MasterCardMessage%3E4A56860251_const.hasinit
  //## begin MasterCardMessage::MasterCardMessage%3E4A56860251_const.initialization preserve=yes
  //## end MasterCardMessage::MasterCardMessage%3E4A56860251_const.initialization
{
  //## begin bmlayouts::MasterCardMessage::MasterCardMessage%3E4A56860251_const.body preserve=yes
   m_strMessageType = "1240";
   m_strFunctionCode = "205";
   m_lNumberOfElements    = ELEMENTS;
   m_lNumberOfPDSelements = PDS_ELEMENTS;
  //## end bmlayouts::MasterCardMessage::MasterCardMessage%3E4A56860251_const.body
}


MasterCardMessage::~MasterCardMessage()
{
  //## begin bmlayouts::MasterCardMessage::~MasterCardMessage%3E4A56860251_dest.body preserve=yes
  //## end bmlayouts::MasterCardMessage::~MasterCardMessage%3E4A56860251_dest.body
}



//## Other Operations (implementation)
struct Elements* MasterCardMessage::elements () const
{
  //## begin bmlayouts::MasterCardMessage::elements%3E4A97ED030D.body preserve=yes
   return &MasterCardMessage_Elements[0];
  //## end bmlayouts::MasterCardMessage::elements%3E4A97ED030D.body
}

void MasterCardMessage::deport ()
{
  //## begin bmlayouts::MasterCardMessage::deport%3E4A5713034B.body preserve=yes
   
   struct Elements* ppszElements    = elements();
   struct Elements* ppszPDSelements = PDSelements();
   char   szTemp[32];
   m_iPos=7;
   memset(m_pszBuffer, ' ', ExportBufferSize - 1);
   m_pszBuffer[ExportBufferSize - 1] = '\0';
   int l = strlen(m_pszBuffer);
   memcpy(m_pszBuffer,     m_strMessageType.data(),  4);
   memcpy(&m_pszBuffer[4], m_strFunctionCode.data(), 3);
   m_hCurrCodes.erase(m_hCurrCodes.begin(),m_hCurrCodes.end());
   setElementMaps();  // Set the regular and PDS element maps
   for (int i = 0; i < m_lNumberOfElements; i++)
   {
      // Check for regular mandatory fields and PDS fields  

      if (m_aPresence[ppszElements[i].siDENo] == 'M')  
         if (ppszElements[i].siDESubfield < 0) // PDS fields   
         {  
            for (int j=0; j < m_lNumberOfPDSelements; j++)
            {               
               if (m_aPDSpresence[ppszPDSelements[j].siDENo] == 'M')
               {                  
                  if (ppszPDSelements[j].cSegInd == 'M')  // member variable
                  {            
                   
                     switch (ppszPDSelements[j].siDENo)
                     {
                        case 25:
                           m_strValue = m_cMsgRevInd;
                           m_strValue += "      ";
                           break;
                       case 105:
                           switch (ppszPDSelements[j].siDESubfield)
                           {
                              case 1: m_strValue = m_strFileType; break;
                              case 2: m_strValue = m_strRefData; break;
                              case 3: m_strValue = m_strMemProcID; break;
                              case 4: m_strValue = m_strSeqNo; break;
                           }
                           break;
                        case 122:
                           m_strValue = m_strProcMode; break;
                        case 191:
                           m_strValue = m_strMsgInd; break;
                        case 268:
                           if (ppszPDSelements[j].siDESubfield == 1)
                           {
                              getValue('C', "AMT_RECON_NET", m_strValue);
                              size_t pos = m_strValue.find(" "); // take out $
                              if (pos != string::npos)
                                 m_strValue.erase(0,pos + 1);
                              double dTranAmt = atof(m_strValue.data());
                              getValue('P', "AMT_ADJUSTMENT", m_strValue);
                              pos = m_strValue.find(" ");
                              if (pos != string::npos)
                                 m_strValue.erase(0,pos + 1);
                              double dAdjAmt = atof(m_strValue.data());
                              char szTemp[15];
                              if (dTranAmt > dAdjAmt)
                              {
                                 sprintf(szTemp,"%012.0f",(dTranAmt-dAdjAmt)*100);
                                 m_strValue = szTemp;
                              }
                              else if (dTranAmt < dAdjAmt)
                              {
                                 sprintf(szTemp,"%012.0f",(dAdjAmt-dTranAmt)*100);
                                 m_strValue = szTemp;
                              }
                              else
                                 m_strValue = "000000000000";
                           }
                           break;
                        case 301:
                           sprintf(szTemp, "%016.0f",m_dCheckSumAmount);
                           m_strValue = szTemp; break;
                        case 306:
                           sprintf(szTemp, "%08d",m_lTotalRecs);
                           m_strValue = szTemp; break;
                     }
                  }
                  else
                  {
                     if (ppszPDSelements[j].siDENo == 241)
                     {
                        if (m_strMessageType == "1240")
                           ppszPDSelements[j].pszName = "MC_RTR_CTRL_NO";
                     }
                     getValue(ppszPDSelements[j].cSegInd, ppszPDSelements[j].pszName,m_strValue);
                     if (ppszPDSelements[j].siDENo == 146 && m_strMessageType == "1442")
                     {
                        if (ppszPDSelements[j].siDESubfield == 2)
                        {
                           getValue('P',"ACTION_TO_CARDHLDR",m_strValue);
                           m_strValue[0] == 'C' ? m_strValue.replace(0,2,"19") : m_strValue.replace(0,2,"29");
                        }
                        else if (ppszPDSelements[j].siDESubfield == 5 || ppszPDSelements[j].siDESubfield == 7)
                        {
                           getValue('C',"AMT_INTRCHG_FEE",m_strValue);
                           size_t pos = m_strValue.find("-");
                           if (pos != string::npos)
                              m_strValue = m_strValue.replace(pos,1,"0");
                        }
                        else if (ppszPDSelements[j].siDESubfield == 4 || ppszPDSelements[j].siDESubfield == 6)
                        {
                           if (m_strValue.length() == 0)
                              m_strValue = "840";
                        }
                     }
                     else if (ppszPDSelements[j].siDENo == 52)
                     {
                        if (m_strValue == "*")
                           m_strValue = "   ";
                     }
                  }
                  //process Currency Codes
                  if (ppszPDSelements[j].siDENo == 148)
                  {
                     switch (ppszPDSelements[j].siDESubfield)
                     {
                        case 1:
                           pCurrCode = m_hCurrCodes.begin();
                           m_strValue = (*pCurrCode);
                           break;
                        case 2:
                           m_strValue = getCurrencyExp(*pCurrCode);
                           ++pCurrCode;
                           break;
                        case 3:
                           if (pCurrCode != m_hCurrCodes.end())
                              m_strValue = (*pCurrCode);
                           break;
                        case 4:
                           if (pCurrCode != m_hCurrCodes.end())
                              m_strValue = getCurrencyExp(*pCurrCode);
                           break;
                     }
                  }

                  if (ppszPDSelements[j].pszLength[0] == 's') // special "length" processing 
                  {                             
                  }
                  m_iPos += exportField(&ppszPDSelements[j], &m_pszBuffer[m_iPos]);
               }
            }
         }   
      else
      {  
         m_strValue.erase();
         // gather all currency code types
         switch(ppszElements[i].siDENo)
         {
            case 4:  
               getValue(ppszElements[i].cSegInd, "CUR_ADJUSTMENT", m_strValue);
               break;
            case 5:
               getValue(ppszElements[i].cSegInd, "CUR_RECON", m_strValue);
               break;
            case 6:
               getValue(ppszElements[i].cSegInd, "CUR_CARDH_BILL", m_strValue);
               break;
            case 30:
               if (ppszElements[i].siDESubfield == 1)
                  getValue(ppszElements[i].cSegInd, "CUR_TRAN", m_strValue);
               else
                  getValue(ppszElements[i].cSegInd, "CUR_RECON_NET", m_strValue);
               break;
         }
         if (m_strValue.length() != 0)
         {
            pCurrCode = m_hCurrCodes.begin();
            while (pCurrCode != m_hCurrCodes.end() && (*pCurrCode) != m_strValue)
               pCurrCode++;
            if (pCurrCode == m_hCurrCodes.end())
               m_hCurrCodes.push_back(m_strValue);
            if (ppszElements[i].siDENo == 4) 
            {
               getValue('U', "CUR_POI", m_strValue); // for PDS 148
               if (m_strValue.length() != 0)
               {
                  pCurrCode = m_hCurrCodes.begin();
                  while (pCurrCode != m_hCurrCodes.end() && (*pCurrCode) != m_strValue)
                     pCurrCode++;
                  if (pCurrCode == m_hCurrCodes.end())
                     m_hCurrCodes.push_back(m_strValue);
               }
            }
         }
         getValue(ppszElements[i].cSegInd, ppszElements[i].pszName, m_strValue);
         if (ppszElements[i].siDENo == 3 && m_strMessageType == "1740")
         {
            string strUserRole;
            getValue('P', "USER_ROLE", strUserRole);
            string strCHAction;
            getValue('P', "ACTION_TO_CARDHLDR", strCHAction);
            if (strCHAction[0] == 'C')
               if (strUserRole == "A")
                  m_strValue.replace(0, 2, "29");
               else
                  m_strValue.replace(0, 2, "19");
            else if (strCHAction[0] == 'D')
               if (strUserRole == "A")
                  m_strValue.replace(0, 2, "19");
               else
                  m_strValue.replace(0, 2, "29");
         }
         else if (ppszElements[i].siDENo == 4)
         {
            m_bAddAmount = true;
            string strTemp;

            getValue('C', "AMT_RECON_NET", strTemp);
            size_t pos = strTemp.find(" "); 
            if (pos != string::npos)
	            strTemp.erase(0,pos + 1);
            pos = strTemp.find_first_of('.');
            if (pos != string::npos)  // delete '.' 
	            strTemp.erase(pos,1);
            double dAMT_RECON_NET = atof(strTemp.data());
            getValue('P', "AMT_ADJUSTMENT", strTemp);
            pos = strTemp.find(" ");
            if (pos != string::npos)
	            strTemp.erase(0,pos + 1);
            pos = strTemp.find_first_of('.');
            if (pos != string::npos)  // delete '.' 
	            strTemp.erase(pos,1);
            double dAMT_ADJUSTMENT = atof(strTemp.data());
            getValue('P', "AMT_SURCHARGE", strTemp);
            pos = strTemp.find(" ");
            if (pos != string::npos)
	            strTemp.erase(0,pos + 1);
            pos = strTemp.find_first_of('.');
            if (pos != string::npos)  // delete '.' 
	            strTemp.erase(pos,1);
            double dAMT_SURCHARGE = atof(strTemp.data());
            char szTemp[15];
            if (dAMT_RECON_NET != dAMT_ADJUSTMENT)
	            sprintf(szTemp,"%012.0f",(dAMT_ADJUSTMENT+dAMT_SURCHARGE));
            else
	            sprintf(szTemp,"%012.0f",dAMT_ADJUSTMENT);
            m_strValue = szTemp;
         }
         else if (ppszElements[i].siDENo == 50)
         {
            if (m_strValue.length() == 0)
               m_strValue = "840";
         }
         else if (ppszElements[i].siDENo == 54)
         {
            if (ppszElements[i].siDESubfield == 5)
            {
               if( m_strMessageType == "1442")
               {
                  if ( m_strFunctionCode == "453" || m_strFunctionCode == "454")
                  {
                     m_strValue = "000000000000"; //Chargeback Partial
                  }
                  else if ( m_strFunctionCode == "450" || m_strFunctionCode == "451")
                  {
                     getValue(ppszElements[i].cSegInd, "CASHBACK_AMT", m_strValue); // Chargeback Full
                  }
               }
            }
         }
         else if (ppszElements[i].siDENo == 72)
         {
            ppszElements[i].pszLength = "v99 ";
            ppszElements[i].pszName = "MC_MMT";
         }
         else if (ppszElements[i].siDENo == 43 && ppszElements[i].siDESubfield == 1)
         {
            string work;
            work = m_strValue;
            work += "\\";
            getValue(ppszElements[i].cSegInd, "CARD_ACPT_LOC", m_strValue);
            work += m_strValue;
            work += "\\";
            getValue(ppszElements[i].cSegInd, "CARD_ACPT_CITY", m_strValue);
            work += m_strValue;
            if (work.length() < 83)
               work += "\\";
            else
               work.substr(83,1) = "\\";
            m_strValue = work;
         }
         else if (ppszElements[i].siDENo == 93)
         {
            string strUSER_ROLE;
            getValue('P', "USER_ROLE", strUSER_ROLE);
            if (strUSER_ROLE == "A")
            {
               getValue(ppszElements[i].cSegInd, "ISS_ICA", m_strValue);
            }
         }
         else if (ppszElements[i].siDENo == 33 || ppszElements[i].siDENo == 94)
         {
            string strUSER_ROLE;
            getValue('P', "USER_ROLE", strUSER_ROLE);
            if (strUSER_ROLE == "A")
            {
               getValue(ppszElements[i].cSegInd, "ACQ_ICA", m_strValue);
            }
         }
         if (ppszElements[i].cSegInd == 'M')  // member variable
         {            
            if (ppszElements[i].siDENo == 71)
            {
               sprintf(szTemp,"%08d",getSOURCE_MSG_NO()); 
               m_strValue = szTemp;
            }
         }

         if (ppszElements[i].pszLength[0] == 's') // special "length" processing 
         {
            
            if (ppszElements[i].pszName == "TSTAMP_LOCAL")
               m_strValue.erase(0,2);
            
            /* other special fields logic here */
            
         }
         m_iPos += exportField(&ppszElements[i], &m_pszBuffer[m_iPos]); // Process regular mandatory fields
      }
   }
   
   m_pszBuffer[m_iPos]= '\0';

   return;
  //## end bmlayouts::MasterCardMessage::deport%3E4A5713034B.body
}

char MasterCardMessage::getCurrencyExp (const string& strCurrencyCode)
{
  //## begin bmlayouts::MasterCardMessage::getCurrencyExp%3EE74A1A035B.body preserve=yes
   return ' ';
  //## end bmlayouts::MasterCardMessage::getCurrencyExp%3EE74A1A035B.body
}

bool MasterCardMessage::import ()
{
  //## begin bmlayouts::MasterCardMessage::import%3E4A63DB0109.body preserve=yes
   
   struct Elements* ppszElements = elements();
   struct Elements* ppszPDSelements = PDSelements();
   char work[1000];
   char data[1000]; 
   if (memcmp(m_pszBuffer, "1644685", 7) == 0)
   {
      m_iPos = 7;
      m_strMessageType.assign(m_pszBuffer,4);
      m_strFunctionCode.assign(m_pszBuffer+4,3);
   }
   else
   {
      m_iPos = 18;
      m_strInstID.assign(m_pszBuffer+1,10);
      m_strMessageType.assign(m_pszBuffer+11,4);
      m_strFunctionCode.assign(m_pszBuffer+15,3);
   }

   setElementMaps();  // Set the regular and PDS element maps
   int iAmount_Type = 0;   
   for (int i = 0; i < m_lNumberOfElements; i++)
   {
      // Check for regular mandatory fields and PDS fields  

      if (m_aPresence[ppszElements[i].siDENo] == 'M')
      {
         if (ppszElements[i].siDESubfield < 0) // PDS fields   
         {  
            for (int j=0; j < m_lNumberOfPDSelements; j++)  
            {
			   if (m_aPDSpresence[ppszPDSelements[j].siDENo] == 'M')
               {
                  if (ppszPDSelements[j].pszLength[0] == 's') // special "length" processing 
                  {          
                     importField(&ppszPDSelements[j], &m_pszBuffer[m_iPos], false);
                     memcpy(work, m_strValue.c_str(), m_strValue.length());
                     work[m_strValue.length()] = '\0';
                     importField(&ppszPDSelements[j], &data[0]);
                  }
                  else if (ppszPDSelements[j].cSegInd == 'M')  // member variable
                  {            
                     if (ppszPDSelements[j].siDENo == 25)
                     {
                        m_cMsgRevInd = m_pszBuffer[m_iPos];
                     }
                     else if (ppszPDSelements[j].siDENo == 280 ||
                              ppszPDSelements[j].siDENo == 300)
                     {
                        if (ppszPDSelements[j].siDESubfield == 2)
                           m_strRefData.assign(&m_pszBuffer[m_iPos],6);
                        else if (ppszPDSelements[j].siDESubfield == 4)
                           m_strSeqNo.assign(&m_pszBuffer[m_iPos],5);
                     }
                     else if (ppszPDSelements[j].siDENo == 138)
                     {
                        string temp;
                        temp.assign(&m_pszBuffer[m_iPos],8);
                        m_lSOURCE_MSG_NO = atoi(temp.c_str());
                     }
                  }
                  else 
                     importField(&ppszPDSelements[j], &m_pszBuffer[m_iPos]);
  
                  m_iPos += atoi(ppszPDSelements[j].pszLength+1);
               }
            }
         }   
         else
         {   
            if (ppszElements[i].pszLength[0] == 's') // special "length" processing 
            {                             
               int iLen = importField(&ppszElements[i], &m_pszBuffer[m_iPos], false);
               memcpy(work, &m_pszBuffer[m_iPos], iLen);
               work[iLen] = '\0';

               if (ppszElements[i].pszName == "TSTAMP_LOCAL")
               {
                  strcpy(data,"20");
                  strcat(data,work);                                                
               }
               else
                  strcpy(data,work);                                                

               m_strValue = data;
               importField(&ppszElements[i], &data[0]);
            }
            else
            {
               if (ppszElements[i].siDENo == 72)
               {
                  if (m_strMessageType == "1644" && m_strFunctionCode == "691")
                  {
                     ppszElements[i].pszLength = "v200";
                     ppszElements[i].pszName = "REJECT_INFO";
                  }
                  else
                  {
                     ppszElements[i].pszLength = "v99 ";
                     ppszElements[i].pszName = "MC_MMT";
                  }
                  importField(&ppszElements[i], &m_pszBuffer[m_iPos]);
               }

               else if (ppszElements[i].siDENo == 43 && ppszElements[i].siDESubfield == 1)
               {
                  string strTemp;
                  importField(&ppszElements[i], &m_pszBuffer[m_iPos],false);
                  size_t pos = m_strValue.find_first_of('\\');
                  strTemp = m_strValue.substr(0,pos);
                  setValue(ppszElements[i].cSegInd, ppszElements[i].pszName, strTemp);
                  m_strValue.erase(0,pos+1);
                  pos = m_strValue.find_first_of('\\');
                  strTemp = m_strValue.substr(0,pos);
                  setValue(ppszElements[i].cSegInd, "CARD_ACPT_LOC", strTemp);
                  m_strValue.erase(0,pos+1);
                  pos = m_strValue.find_first_of('\\');
                  strTemp = m_strValue.substr(0,pos);
                  setValue(ppszElements[i].cSegInd, "CARD_ACPT_CITY", strTemp);
               }
			   else if (ppszElements[i].siDENo == 54)
               {
				   if (ppszElements[i].siDESubfield == 2 || ppszElements[i].siDESubfield == 7 ||
					   ppszElements[i].siDESubfield == 12 || ppszElements[i].siDESubfield == 17 ||
					   ppszElements[i].siDESubfield == 22 || ppszElements[i].siDESubfield == 27)
				   {
					   importField(&ppszElements[i], &m_pszBuffer[m_iPos],false);
					   iAmount_Type = atoi(m_strValue.c_str());					   
				   }
				   else if (ppszElements[i].siDESubfield == 3 || ppszElements[i].siDESubfield == 8 ||
					   ppszElements[i].siDESubfield == 13 || ppszElements[i].siDESubfield == 18 ||
					   ppszElements[i].siDESubfield == 23 || ppszElements[i].siDESubfield == 28)
				   {
					   switch (iAmount_Type)
					   {
					   case 40:
						   importField(&ppszElements[CUR_CASHBACK_IDX], &m_pszBuffer[m_iPos]);
						   break;
					   case 42:
						   importField(&ppszElements[CUR_SURCHARGE_FEE_IDX], &m_pszBuffer[m_iPos]);
						   break;
					   case 58:
						   importField(&ppszElements[CUR_POI_IDX], &m_pszBuffer[m_iPos]);
						   break;
					  
					   }
				   }
				   else if (ppszElements[i].siDESubfield == 5 || ppszElements[i].siDESubfield == 10 ||
					   ppszElements[i].siDESubfield == 15 || ppszElements[i].siDESubfield == 20 ||
					   ppszElements[i].siDESubfield == 25 || ppszElements[i].siDESubfield == 30)
				   {
					   switch (iAmount_Type)
					   {
					   case 40:
						   importField(&ppszElements[CASHBACK_AMT_IDX], &m_pszBuffer[m_iPos]);
						   break;
					   case 42:
						   importField(&ppszElements[AMT_SURCHARGE_FEE_IDX], &m_pszBuffer[m_iPos]);
						   break;
					   case 58:
						   importField(&ppszElements[AMT_POI_IDX], &m_pszBuffer[m_iPos]);
						   break;
					   
					   }
					   iAmount_Type = 0;
				   }
				   else		  
					   importField(&ppszElements[i], &m_pszBuffer[m_iPos]);
			   }
               else
                  importField(&ppszElements[i], &m_pszBuffer[m_iPos]); // Process regular mandatory fields
            }
            m_iPos += atoi(ppszElements[i].pszLength + 1);
         }
      }
   }

   m_pszBuffer[m_iPos+1] = '\0';
   return 0;
  //## end bmlayouts::MasterCardMessage::import%3E4A63DB0109.body
}

struct Elements* MasterCardMessage::PDSelements ()
{
  //## begin bmlayouts::MasterCardMessage::PDSelements%3E568A530213.body preserve=yes
   return &MasterCardMessage_PDS_Elements[0];
  //## end bmlayouts::MasterCardMessage::PDSelements%3E568A530213.body
}

void MasterCardMessage::setElementMaps ()
{
  //## begin bmlayouts::MasterCardMessage::setElementMaps%3E665EC302DE.body preserve=yes
   
   switch (atoi(m_strMessageType.data()))
   {
      case ADMIN: 
         switch (atoi(m_strFunctionCode.data()))
         {
         case 603: memcpy(m_aPresence,    aADMN603,     sizeof(aADMN603));
                   memcpy(m_aPDSpresence, aADMN603_PDS, sizeof(aADMN603_PDS));
            break;
         case 640: memcpy(m_aPresence,    aADMN640,     sizeof(aADMN640));
                   memcpy(m_aPDSpresence, aADMN640_PDS, sizeof(aADMN640_PDS));
            break;
         case 680: memcpy(m_aPresence,    aADMN680,     sizeof(aADMN680));
                   memcpy(m_aPDSpresence, aADMN680_PDS, sizeof(aADMN680_PDS));
            break;
         case 685: memcpy(m_aPresence,    aADMN685,     sizeof(aADMN685));
                   memcpy(m_aPDSpresence, aADMN685_PDS, sizeof(aADMN685_PDS));
            break;
         case 691: memcpy(m_aPresence,    aADMN691,     sizeof(aADMN691));
                   memcpy(m_aPDSpresence, aADMN691_PDS, sizeof(aADMN691_PDS));
            break;
         case 693: memcpy(m_aPresence,    aADMN693,     sizeof(aADMN693));
                   memcpy(m_aPDSpresence, aADMN693_PDS, sizeof(aADMN693_PDS));
            break;
         case 695: memcpy(m_aPresence,    aADMN695,     sizeof(aADMN695));
                   memcpy(m_aPDSpresence, aADMN695_PDS, sizeof(aADMN695_PDS));
            break;
         case 697: memcpy(m_aPresence,    aADMN697,     sizeof(aADMN697));
                   memcpy(m_aPDSpresence, aADMN697_PDS, sizeof(aADMN697_PDS));
            break;
         case 699: memcpy(m_aPresence,    aADMN699,     sizeof(aADMN699));
                   memcpy(m_aPDSpresence, aADMN699_PDS, sizeof(aADMN699_PDS));
            break;
         }
         break;
      case CHARGEBACK: memcpy(m_aPresence,    aCHBK,     sizeof(aCHBK));
                       memcpy(m_aPDSpresence, aCHBK_PDS, sizeof(aCHBK_PDS)); 
         break;
      case FEES: 
      {
         string strReasonCode;
         getValue('P', "REASON_CODE", strReasonCode);
         switch (atoi(strReasonCode.substr(0,4).c_str()))
         {
            case 7614: memcpy(m_aPresence,    aFEES_RETR,     sizeof(aFEES_RETR));
                       memcpy(m_aPDSpresence, aFEES_RETR_PDS, sizeof(aFEES_RETR_PDS)); 
                       break;
            default: memcpy(m_aPresence,    aFEES,     sizeof(aFEES));
                     memcpy(m_aPDSpresence, aFEES_PDS, sizeof(aFEES_PDS)); 
                     break;
         }
         break;
      }
      case PRESENTMENT:
         switch (atoi(m_strFunctionCode.data()))
         {
            case 200: memcpy(m_aPresence,    aPRES200,     sizeof(aPRES200));
                      memcpy(m_aPDSpresence, aPRES200_PDS, sizeof(aPRES200_PDS));
               break;
            case 205:  
            case 282: memcpy(m_aPresence,    aPRES205,     sizeof(aPRES205));
                      memcpy(m_aPDSpresence, aPRES205_PDS, sizeof(aPRES205_PDS));
               break;
         }
         break;
   }
  //## end bmlayouts::MasterCardMessage::setElementMaps%3E665EC302DE.body
}

void MasterCardMessage::update (Subject* pSubject)
{
  //## begin bmlayouts::MasterCardMessage::update%3E92D3310203.body preserve=yes
  //## end bmlayouts::MasterCardMessage::update%3E92D3310203.body
}

void MasterCardMessage::updateFields (void* hSegment, char cInd)
{
  //## begin bmlayouts::MasterCardMessage::updateFields%3E9ECD3A0251.body preserve=yes
   struct Elements* ppszElements    = elements();
   struct Elements* ppszPDSelements = PDSelements();
   
   setElementMaps();  // Set the regular and PDS element maps

   for (int i = 0; i < m_lNumberOfElements; i++)
   {
      // Check for regular mandatory fields and PDS fields  
	   
	   if (m_aPresence[ppszElements[i].siDENo] == 'M')  
      {
         if (ppszElements[i].siDESubfield < 0) // PDS fields   
         {  
            for (int j=0; j < m_lNumberOfPDSelements; j++)
            {               
			   if (m_aPDSpresence[ppszPDSelements[j].siDENo] == 'M' &&
                   ppszPDSelements[j].cSegInd == cInd)
               {
				  getValue(ppszPDSelements[j].cSegInd, ppszPDSelements[j].pszName, m_strValue, true, hSegment);
                  setValue(ppszPDSelements[j].cSegInd, ppszPDSelements[j].pszName, m_strValue);
			   }
            }
         }
         else
         {
            if (ppszElements[i].cSegInd == cInd)
            {
               if (ppszElements[i].siDENo == 72)
               {
                  if (m_strMessageType == "1644" && m_strFunctionCode == "691")
                  {
                     ppszElements[i].pszLength = "v200";
                     ppszElements[i].pszName = "REJECT_INFO";
                  }
                  else
                  {
                     ppszElements[i].pszLength = "v99 ";
                     ppszElements[i].pszName = "MC_MMT";
                  }
               }
               getValue(ppszElements[i].cSegInd, ppszElements[i].pszName, m_strValue, true, hSegment);
               setValue(ppszElements[i].cSegInd, ppszElements[i].pszName, m_strValue);
            }
         }
      }
   }
  //## end bmlayouts::MasterCardMessage::updateFields%3E9ECD3A0251.body
}

// Additional Declarations
  //## begin bmlayouts::MasterCardMessage%3E4A56860251.declarations preserve=yes
  //## end bmlayouts::MasterCardMessage%3E4A56860251.declarations

} // namespace bmlayouts

//## begin module%3E4A573A01A5.epilog preserve=yes
//## end module%3E4A573A01A5.epilog
