//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E4A4F9D031C.cm preserve=no
//	$Date:   Jul 09 2021 08:00:52  $ $Author:   e5632407  $ $Revision:   1.117.1.1  $
//## end module%3E4A4F9D031C.cm

//## begin module%3E4A4F9D031C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3E4A4F9D031C.cp

//## Module: CXOSBL02%3E4A4F9D031C; Package body
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Source file: C:\bV02.4B.R009\Build\ConnexPlatform\Server\Library\Bldll\CXOSBL02.cpp

//## begin module%3E4A4F9D031C.additionalIncludes preserve=no
//## end module%3E4A4F9D031C.additionalIncludes

//## begin module%3E4A4F9D031C.includes preserve=yes
// $Date:   Jul 09 2021 08:00:52  $ $Author:   e5632407  $ $Revision:   1.117.1.1  $
#include "CXODBL05.hpp"  // Mandatory field arrays
#include "CXODIF03.hpp"
#include "CXODTM04.hpp"
#include "CXODTM06.hpp"

//## end module%3E4A4F9D031C.includes

#ifndef CXOSBL02_h
#include "CXODBL02.hpp"
#endif
//## begin module%3E4A4F9D031C.declarations preserve=no
//## end module%3E4A4F9D031C.declarations

//## begin module%3E4A4F9D031C.additionalDeclarations preserve=yes
/*
  TYPE CODES: 
    C = CASE SEGMENT
    U = CASE UNIQUE SEGMENT
    P = PHASE SEGMENT
    H = PHASE UNIQUE SEGMENT
    N = NATIONAL NETWORKS SEGMENT
    D = FRAUD SEGMENT
    R = FRAUD UNIQUE SEGMENT
    L = CARDHOLDER INFORMATION SEGMENT
    A = PRE AUTH SEGMENT
    F = FILLER 
    M = MEMBER VARIABLE REQUIRED
    E = CREDIT SEGMENT
	
*/

#define ELEMENTS 144
Elements VisaMessage_Elements[ELEMENTS + 1] =
{
//   0, 0,C           
//   1, 0,C           
     2, 1,AN  ,"Y        ","l2  ",'C',"PAN",
 //  3, 1,ALP  ,"         ","f6  ",'C',"TRAN_TYPE_ID",
     4, 1,AMT ," %012d   ","f12 ",'P',"AMT_ADJUSTMENT",
     5, 1,AMT ," %012d   ","f12 ",'P',"AMT_ADJ_TRAN",
     6, 1,AMT ," %012d   ","f12 ",'P',"AMT_ADJ_CARD_BILL",
     7, 1,AN  ,"         ","f10 ",'H',"TRANSMIT_DATE_TIME",
     9, 1,AN  ,"         ","v8  ",'M',"ConvRate1",
    10, 1,AN  ,"         ","v8  ",'M',"ConvRate2",
    11, 1,NUM ," %06d    ","f6  ",'C',"SYS_TRACE_AUDIT_NO",
    12, 1,NUM ," %06d    ","s6  ",'C',"TSTAMP_LOCAL",      // time
    13, 1,NUM ," %04d    ","s4  ",'C',"TSTAMP_LOCAL",      // date
    14, 1,NUM ," %04d    ","f4  ",'P',"DATE_EXPIRATION",
    15, 1,NUM ," %04d    ","f4  ",'P',"DATE_RECON",
 // 16, 1,NUM ," %04d    ","f4  ",'P',"DATE_CONV",
 // 17, 1,NUM ," %04d    ","f4  ",'C',"CAPTURE_DATE",
    18, 1,NUM ," %04d    ","f4  ",'C',"MERCHANT_CAT_CODE",
    19, 1,AN  ,"         ","v3  ",'C',"COUNTRY_ACQ",
    20, 1,AN  ,"         ","v3  ",'C',"PAN_COUNTRY_CODE",    
    21, 1,AN  ,"         ","v3  ",'C',"COUNTRY_ISS",
 // 22, 0,AN  ,"         ","f4  ",' ',"POS_ENTRY_MODE",     // Multiple fields
 // 22, 1,AN  ,"         ","f2  ",'U',"PAN_DT_ENTRY_MODE",   
 // 22, 2,AN  ,"         ","f1  ",'U',"PIN_ENTRY_CAP_IND",  
 // 22, 3,AN  ,"         ","f1  ",'F',"0",  
 // 23, 1,NUM ," %03d    ","f3  ",'C',"CARD_SEQ_NUMBER",
 // 24, 1,NUM ," %03d    ","f3  ",'C',"FUNCTION_CODE",
 // 25, 1,NUM ," %02d    ","f2  ",'U',"POS_COND_CODE",
 // 28, 1,NUM ," %09d    ","f9  ",'C',"AMT_SURCHARGE_FEE",
 // 29, 1,NUM ," %03d    ","f3  ",'C',"RECON_INDICATOR",    
 // 30, 1,NUM ," %012d   ","f12 ",'C',"AMT_TRAN", 
 // 30, 2,NUM ," %012d   ","f12 ",'C',"RECON_AMT", 
 // 31, 1,ANS ,"         ","v23 ",'C',"ACQ_REF_DATA",             
    32, 1,AN  ,"         ","l2  ",'U',"ACQ_BIN",
    33, 1,AN  ,"         ","l2  ",'U',"ISS_BIN",
 // 34, 1,AN  ,"         ","v28 ",'C',"PAN_EXTENDED",
 // 35, 1,ANS ,"         ","v37 ",'C',"TRACK2_DATA",
 // 36, 1,ANS ,"         ","v104",'C',"TRACK3_DATA",
    37, 1,AN  ,"         ","v12 ",'C',"RETRIEVAL_REF_NO",
    38, 1,AN  ,"         ","f6  ",'N',"AUTH_ID_RESP",
 // 39, 1,NUM ," %02d    ","f2  ",'H',"RESP_CODE",    
 // 40, 0,NUM ," %03d    ","f3  ",'C',"SERVICE_CODE",          
    41, 1,ANS ,"         ","v8  ",'C',"CARD_ACPT_TERM_ID",        
    42, 1,ANS ,"         ","v15 ",'C',"CARD_ACPT_ID",
//    43, 1,ANS ,"         ","v25 ",'C',"CARD_ACPT_NAME",
    43, 1,ANS ,"         ","v23 ",'C',"CARD_ACPT_LOC",
    43, 2,ANS ,"         ","v13 ",'C',"CARD_ACPT_CITY",
    43, 4,ANS ,"         ","f2  ",'C',"CARD_ACPT_REGION",
    43, 4,ANS ,"         ","f2  ",'C',"CARD_ACPT_COUNTRY",
 // 44, 1,ANS ,"         ","v25 ",'C',"ADDL_RESPONSE_DATA",
 // 44, 1,ANS ,"         ","v11 ",'F'," ",   
 // 44, 2,ANS ,"         ","v2  ",'H',"ORIG_RESP_CODE",
 // 45, 1,ANS ,"         ","v76 ",'C',"TRACK1_DATA",
 // 46, 1,ANS ,"         ","v204",'C',"FEES_AMOUNTS",
 // 47, 1,ANS ,"         ","v999",'C',"ADDITIONAL_DATA_NATL",
 // 48,-1,ANS ,"         ","v255",'C',"ADDITIONAL_DATA",  // Use secondary table
    49, 1,NUM ," %03d    ","f3  ",'P',"CUR_ADJUSTMENT",    
    50, 1,NUM ," %03d    ","f3  ",'P',"CUR_ADJ_TRAN",              
    51, 1,NUM ," %03d    ","f3  ",'P',"CUR_CARDH_BILL",       
 // 52, 1,NUM ," %016d   ","f16 ",'C',"PIN",
 // 53, 1,ANS ,"         ","f16 ",'C',"SECUR_CONTROL",
    54, 1,AN  ,"         ","l3  ",'A',"CASHBACK_AMT",   //61.1
 // 55, 1,B   ,"         ","v255",'C',"INT_CIRCUIT_CARD",
 // 56
 // ...
 // 58
    59, 1,AN  ,"         ","l3  ",'M',"POS_GEO_DATA",
//    59, 1,ALP  ,"         ","f3  ",'F',"010",
//    59, 2,ANS ,"         ","v2  ",'C',"CARD_ACPT_REGION",
//    59, 3,AN  ,"         ","v3  ",'C',"CARD_ACPT_COUNTY",
//    59, 4,ANS ,"         ","v5  ",'C',"CARD_ACPT_ZIP",
 // 60, 1,NUM ,"         ","v12 ",'C',"ADDL_POS_INFO",
 // 60, 1,NUM ,"         ","f1  ",'U',"TERM_TYPE_IND",
 // 60, 2,NUM ,"         ","f1  ",'U',"TERM_TYPE_CAP_IND",
 // 61, 1,NUM ,"         ","v24 ",'F'," ", // "OTHER_AMTS",
 // 62, 1,ANS ,"         ","v59 ",'C',"PAYMENT_SRV_FLDS",  // ???
    63, 1,ANS ,"         ","l3  ",'F',"?????", // input only, discard
 // 64
 // ...
 // 70, 1,NUM ," %03d    ","f3  ",'H',"NETW_MGT_CODE",
    70, 1,NUM ,"         ","f3  ",'M',"ISS_INST_ID",  // Issuing institution to acquirer/consumer
 // 71, 1,NUM ," %08d    ","f8  ",'C',"MSG_NUMBER",
 // 72, 1,ANS ,"         ","v99 ",'C',"DATA_RECORD",
 // 73, 1,NUM ," %06d    ","f6  ",'C',"ACTION_DATE",
 // 74                                  
 // ...
 // 89
 // 90, 1,AN  ,"         ","f42 ",'C',"ORIG_DATA",
    90, 1,NUM ," %04d    ","f4  ",'U',"FUNCTION_CODE",
    90, 2,NUM ," %06d    ","f6  ",'C',"SYS_TRACE_AUDIT_NO",
    90, 3,AN  ,"         ","v10 ",'U',"TRANSMIT_DATE_TIME",
    90, 4,NUM ," %011d   ","f11 ",'U',"ACQ_BIN",
    90, 5,NUM ," %011d   ","f11 ",'U',"ISS_BIN",
   100, 1,AN  ,"         ","l2  ",'M',"RECV_INST_ID",  // test field 
   104, 1,AN  ,"         ","l3  ",'U',"REIMBURSEMENT_ATTR",
   105, 0,ANS ,"         ","l3  ",' ',"LARGE_PRIVATE_DATA",  
   105, 1,ALP  ,"         ","f5  ",'F',"*NV*\\",
   105, 2,ALP  ,"         ","f4  ",'F',"0000",  // imbedded length
   105, 3,_B  ,"         ","f8  ",'F',"0",     // bit map
   105, 4,AN  ,"         ","l3  ",'M',"ADDITIONAL_DATA", //48
   105, 5,AN  ,"         ","l2  ",'M',"POSEntryCode",    //60
   105, 6,AN  ,"         ","l2  ",'U',"ISS_BIN",         //100
   105, 7,AN  ,"         ","l2  ",'M',"AdtlTraceData",   //115
   105, 8,AN  ,"         ","l3  ",'M',"SUPPORT_INFO",    //125
   106, 0,AN  ,"         ","l3  ",'M',"Bit106_DATA", 

   111, 0,ANS ,"         ","l3  ",' ',"ADDITIONAL_PRIVATE_DATA",  
   111, 1,ALP  ,"         ","f2  ",'F',"NV",
   111, 2,ALP  ,"         ","f3  ",'F',"000",  // imbedded length
   111, 3,_B  ,"         ","f8  ",'F',"0",    // bit map
   111, 4,AN  ,"         ","f2  ",'U',"PAN_DT_ENTRY_MODE",  //22
   111, 4,AN  ,"         ","f1  ",'U',"PIN_ENTRY_CAP_IND",  //22
   111, 5,NUM ," %02d    ","f2  ",'H',"POS_COND_CODE",      //25
   111, 6,NUM ," %02d    ","f2  ",'H',"RESP_CODE",          //39
   111, 7,AN  ,"         "," 4  ",' ',"VALIDATION_CODE",    // 62.3 VALIDATION CODE ???
   111, 8,AN  ,"         ","f1  ",'U',"REQ_PYMT_SERV_IND",  //62.15
   111, 9,AN  ,"         ","f2  ",'U',"CHB_RIGHTS_IND",     //62.16
   111,10,AN  ,"         ","f1  ",'H',"EXCLD_TRAN_ID",      //62.18
   111,11,AN  ,"         ","v10 ",'U',"MERCH_VERIFY_VALUE", // 62.20 MERCHANT VALIDATION VALUE
   111,12,ANS ,"         ","s4  ",'P',"REASON_CODE",  //63.3
   111,13,NUM ," %04d    ","f4  ",'H',"STIP_SW_RESN_CODE",  //63.4
   111,14,AN  ,"         ","v1  ",'R',"FRD_TYPE_IND",       // 63.9 FRAUD DATA
   111,14,AN  ,"         ","v1  ",'R',"FRD_NOTIF_TYPE_IND", // 63.9 FRAUD DATA
   111,14,AN  ,"         ","v1  ",'R',"CHECK_FRD_IND",      // 63.9 FRAUD DATA
   111,14,ALP ,"         ","f11 ",'F'," ",                  // 63.9 FRAUD DATA
   111,15,AN  ,"         "," 1  ",' ',"RECURRING_PYMT_IND", // 126.13 RECURRING PAYMENT INDICATOR
   111,16,AN  ,"         ","f2  ",'U',"PRODUCT_ID", // 62.23 PRODUCT ID
   111,17,AN  ,"         ","f9  ",'M',"Transaction_Fee", // 28 AMT_SURCHARGE_FEE
   111,18,AN  ,"         ","v1  ",'U',"MARKET_FLG",      // 62.4 Market Specific Info
   111,19,AN  ,"         ","v19 ",'E',"PAN_TOKEN",      // DE123 Usage 2 Dataset ID 68 Tag 01
   111,20,AN  ,"         ","v2  ",'E',"TOKEN_ASSURANCE",      // DE123 Usage 2 Dataset ID 68 Tag 02
   111,21,AN  ,"         ","v11 ",'E',"TOKEN_REQUESTOR_ID",      // DE123 Usage 2 Dataset ID 68 Tag 03
   111,22,AN  ,"         ","v19 ",'E',"PAN_RANGE",      // DE123 Usage 2 Dataset ID 68 Tag 04
   111,23,AN  ,"         ","V5  ",'U',"AGENT_UNIQUE_ID", //DE126.18 Agent Unique Id
   121, 0,ANS ,"         ","l3  ",' ',"ADDITIONAL_PRIVATE_DATA",  
   121, 1,ALP  ,"         ","f2  ",'F',"NV",
   121, 2,ALP  ,"         ","f3  ",'F',"000",  // imbedded length
   121, 3,_B  ,"         ","f8  ",'F',"0",    // bit map
   121, 4,AN  ,"         ","f2  ",'U',"PAN_DT_ENTRY_MODE",
   121, 4,AN  ,"         ","f1  ",'U',"PIN_ENTRY_CAP_IND",
   121, 5,NUM ," %02d    ","f2  ",'H',"POS_COND_CODE",
   121, 6,NUM ," %02d    ","f2  ",'H',"RESP_CODE",
   121, 7,AN  ,"         "," 4  ",' ',"VALIDATION_CODE",  // 62.3 VALIDATION CODE
   121, 8,AN  ,"         ","f1  ",'U',"REQ_PYMT_SERV_IND",
   121, 9,AN  ,"         ","f2  ",'U',"CHB_RIGHTS_IND",  
   121,10,AN  ,"         ","f1  ",'H',"EXCLD_TRAN_ID",
   121,11,AN  ,"         ","v10 ",'U',"MERCH_VERIFY_VALUE",  // 62.20 MERCHANT VALIDATION VALUE
   121,12,ANS ,"         ","s4  ",'P',"REASON_CODE", //63.3
   121,13,NUM ," %04d    ","f4  ",'H',"STIP_SW_RESN_CODE", //63.4
   121,14,AN  ,"         ","v1  ",'R',"FRD_TYPE_IND",  // 63.9 FRAUD DATA
   121,14,AN  ,"         ","v1  ",'R',"FRD_NOTIF_TYPE_IND",  // 63.9 FRAUD DATA
   121,14,AN  ,"         ","v1  ",'R',"CHECK_FRD_IND",  // 63.9 FRAUD DATA
   121,14,ALP  ,"         ","f11 ",'F'," ",//FRAUD_DATA",  // 63.9 FRAUD DATA
   121,15,AN  ,"         "," 1  ",' ',"RECURRING_PYMT_IND",  // 126.13 RECURRING PAYMENT INDICATOR
   121,16,AN  ,"         ","f2  ",'U',"PRODUCT_ID", // 62.23 PRODUCT ID
   121,17,AN  ,"         ","f9  ",'M',"Transaction_Fee", // 28 AMT_SURCHARGE_FEE
   121,18,AN  ,"         ","v1  ",'U',"MARKET_FLG",      // 62.4 Market Specific Info
   121,19,AN  ,"         ","v19  ",'E',"PAN_TOKEN",      // DE123 Usage 2 Dataset ID 68 Tag 01
   121,20,AN  ,"         ","v2  ",'E',"TOKEN_ASSURANCE",      // DE123 Usage 2 Dataset ID 68 Tag 02
   121,21,AN  ,"         ","v11 ",'E',"TOKEN_REQUESTOR_ID",      // DE123 Usage 2 Dataset ID 68 Tag 03
   121,22,AN  ,"         ","v19 ",'E',"PAN_RANGE",      // DE123 Usage 2 Dataset ID 68 Tag 04
   121,23,AN  ,"         ","v5  ",'U',"AGENT_UNIQUE_ID", //DE126.18 Agent Unique Id
   126, 0,ANS ,"         ","l3  ",' ',"REFERENCE_DATA",
   126, 1,ALP  ,"         ","f1  ",'F',"4",
   126, 2,NUM ," %04d    ","f4  ",'M',"MessageType", 
   126, 3,NUM ," %06d    ","f6  ",'H',"PROCESS_CODE",    //3
   126, 4,AN  ,"         ","v1  ",'U',"AUTH_CHAR_FLG",   //62.1
   126, 5,AN  ,"         ","v15 ",'U',"TRAN_IDENTIFIER", //62.2
   126, 6,AN  ,"         ","v2  ",'U',"MULTI_CLR_SEQ_NO",//62.11
   126, 7,AN  ,"         ","v2  ",'U',"MULTI_CLR_SEQ_CNT",//62.12
   126, 8,NUM ," %04d    ","f4  ",'U',"NETWORK_ID",      //63.1
   126, 9,AN  ,"         ","v1  ",'U',"FLOOR_LIMIT_IND", //63.6,s1
   126, 9,AN  ,"         ","v1  ",'U',"CRB_IND",         //63.6,s2
   126, 9,AN  ,"         ","v1  ",'U',"STIP_IND",        //63.6,s3
   126, 9,AN  ,"         ","v1  ",'U',"MOTO_IND",        //63.6,s4
   126, 9,AN  ,"         ","v1  ",'U',"SPL_CHG_IND",     //63.6,s5
   126, 9,AN  ,"         ","v1  ",'U',"RIS_SPL_COND_IND",//63.6,s6
   126, 9,AN  ,"         ","v1  ",'U',"MERCH_SPL_COND_IND",//63.6,s7
   126,10,AN  ,"         ","v8  ",'U',"ACQ_BUSINESS_ID", //63.8
   126,11,AN  ,"         ","v3  ",'U',"FEE_PGM_IND",     //63.19
   126,12,NUM ," %03d    ","f3  ",'H',"NETW_MGMT_CODE",  //70
 
   127, 0,ANS ,"         ","l3  ",' ',"REFERENCE_DATA",
   127, 1,ALP  ,"         ","f1  ",'F',"4",
   127, 2,NUM ," %04d    ","f4  ",'M',"MessageType",
   127, 3,NUM ," %06d    ","f6  ",'H',"PROCESS_CODE",
   127, 4,AN  ,"         ","f1  ",'U',"AUTH_CHAR_FLG",
   127, 5,AN  ,"         ","f15 ",'U',"TRAN_IDENTIFIER",
   127, 6,AN  ,"         ","v2  ",'U',"MULTI_CLR_SEQ_NO",
   127, 7,AN  ,"         ","v2  ",'U',"MULTI_CLR_SEQ_CNT",
   127, 8,NUM ," %04d    ","f4  ",'U',"NETWORK_ID",
   127, 9,AN  ,"         ","v1  ",'U',"FLOOR_LIMIT_IND",
   127, 9,AN  ,"         ","v1  ",'U',"CRB_IND",
   127, 9,AN  ,"         ","v1  ",'U',"STIP_IND",
   127, 9,AN  ,"         ","v1  ",'U',"MOTO_IND",
   127, 9,AN  ,"         ","v1  ",'U',"SPL_CHG_IND",
   127, 9,AN  ,"         ","v1  ",'U',"RIS_SPL_COND_IND",
   127, 9,AN  ,"         ","v1  ",'U',"MERCH_SPL_COND_IND",
   127,10,AN  ,"         ","v8  ",'U',"ACQ_BUSINESS_ID",
   127,11,AN  ,"         ","v3  ",'U',"FEE_PGM_IND",
   127,12,NUM ," %03d    ","f3  ",'H',"NETW_MGMT_CODE", 
     0, 1,0   ,"~","~",' ',"~"
};

#define SEC_ELEMENTS 2
Elements VisaMessage_Sec_Elements[SEC_ELEMENTS + 1] =
{
     2, 1,ANS ,"         ","f3  ",'C',"PRODUCT_ID",
     5, 1,ANS ,"         ","v110",'P',"MSG_ERR_IND",

     0, 1,0   ,"~","~",' ',"~"
};
//## end module%3E4A4F9D031C.additionalDeclarations


//## Modelname: Connex Library::BitMapLayouts_CAT%3E4A483C030D
namespace bmlayouts {
//## begin bmlayouts%3E4A483C030D.initialDeclarations preserve=yes
//## end bmlayouts%3E4A483C030D.initialDeclarations

// Class bmlayouts::VisaMessage 

VisaMessage::VisaMessage()
  //## begin VisaMessage::VisaMessage%3E4A4EA0038A_const.hasinit preserve=no
      : m_lNumberOfSecElements(0),
        m_dAMT_ADJUSTMENT(0)
  //## end VisaMessage::VisaMessage%3E4A4EA0038A_const.hasinit
  //## begin VisaMessage::VisaMessage%3E4A4EA0038A_const.initialization preserve=yes
  //## end VisaMessage::VisaMessage%3E4A4EA0038A_const.initialization
{
  //## begin bmlayouts::VisaMessage::VisaMessage%3E4A4EA0038A_const.body preserve=yes
   memcpy(m_sID,"BL02",4);
   m_strMessageType = "0220";
   m_lNumberOfElements    = ELEMENTS;
   m_lNumberOfSecElements = SEC_ELEMENTS;
  //## end bmlayouts::VisaMessage::VisaMessage%3E4A4EA0038A_const.body
}


VisaMessage::~VisaMessage()
{
  //## begin bmlayouts::VisaMessage::~VisaMessage%3E4A4EA0038A_dest.body preserve=yes
  //## end bmlayouts::VisaMessage::~VisaMessage%3E4A4EA0038A_dest.body
}



//## Other Operations (implementation)
char VisaMessage::checkPresence (const string& strFieldName)
{
  //## begin bmlayouts::VisaMessage::checkPresence%3FE7130303D8.body preserve=yes
   struct Elements* ppszElements = elements();
   setElementMaps();  // Set the regular and secondary element maps
   for (int i = 0; i < m_lNumberOfElements; i++)
   {
      if (ppszElements[i].pszName == strFieldName)
         return m_aPresence[ppszElements[i].siDENo];
   }
   return '*';
  //## end bmlayouts::VisaMessage::checkPresence%3FE7130303D8.body
}

struct Elements* VisaMessage::elements () const
{
  //## begin bmlayouts::VisaMessage::elements%3E4A5094032C.body preserve=yes
   return &VisaMessage_Elements[0];
  //## end bmlayouts::VisaMessage::elements%3E4A5094032C.body
}

void VisaMessage::deport ()
{
  //## begin bmlayouts::VisaMessage::deport%3E68BF570242.body preserve=yes
   
   struct Elements* ppszElements = elements();
   struct Elements* ppszSecElements = secElements();
   unsigned char bytes[34];
   m_iPos=36;
   memset(m_pszBuffer, ' ', ExportBufferSize - 1);
   m_pszBuffer[ExportBufferSize - 1] = '\0';
   memcpy(m_pszBuffer, "0600", 4);  // fixed message ID
   m_dAMT_ADJUSTMENT=0;
   m_strSurChargeInd = "D";
   m_strAmountSurcharge="";
   setElementMaps();  // Set the regular and secondary element maps

//   toBits(m_aPresence, (char *) bytes, 16);  // Set the bit map
//   hexChar(&m_pszBuffer[4], bytes, 16);      // Make it characters 
   int i = 0;
   Trace::put("Visa deport");
   for (i = 0; i < m_lNumberOfElements; i++)
   {
	   // Check for regular mandatory fields and secondary fields  

	   if (m_aPresence[ppszElements[i].siDENo] == 'M')
	   {
		   if (ppszElements[i].siDESubfield < 0) // Secondary fields   
		   {  
			   for (int j=0; j < m_lNumberOfSecElements; j++)
				   if (m_aSecPresence[ppszSecElements[j].siDENo] == 'M')
				   {
					   getValue(ppszElements[i].cSegInd, ppszElements[i].pszName, m_strValue);
					   m_iPos += exportField(&ppszSecElements[j], &m_pszBuffer[m_iPos]);
				   }
		   }   
		   else
		   {			
			   if (ppszElements[i].siDENo == 4 && m_strMessageType == "0600")
			   {
				   getValue('C', "AMT_TRAN", m_strValue);
			   }
			   else
				   getValue(ppszElements[i].cSegInd, ppszElements[i].pszName, m_strValue);
			   if (ppszElements[i].siDENo == 4)
			   {
				   size_t pos;
               string strCaseAmountSC,strREQUEST_TYPE,strTRAN_TYPE_ID;
               string strAMT_RECON_NET,strAMT_ADJUSTMENT,strPROCESS_CODE, strMCC;
				   char szTemp[25];
				   double dAMT_SURCHARGE = 0,dAMT_RECON_NET = 0,dCaseAmountSC =0;
               bool bFull=true;
            
               Trace::put("Process DE 4 ");
               strAMT_ADJUSTMENT = m_strValue;  // has the PHASE.AMT_ADJUSTMENT
               pos = strAMT_ADJUSTMENT.find(" ");  
               if (pos != string::npos)
	               strAMT_ADJUSTMENT.erase(0,pos + 1);
               pos = strAMT_ADJUSTMENT.find_first_of('.');
               if (pos != string::npos)  // delete '.' 
	               strAMT_ADJUSTMENT.erase(pos,1);
               m_dAMT_ADJUSTMENT = atof(strAMT_ADJUSTMENT.c_str());

				   getValue('C', "REQUEST_TYPE", strREQUEST_TYPE);
				   if( strREQUEST_TYPE.substr(0,3) == "ADJ" || strREQUEST_TYPE == "REP1"||
                   strREQUEST_TYPE == "CHB1")
				   {	
				      getValue('C', "AMT_RECON_NET", strAMT_RECON_NET);
                  getValue('C', "AMT_SURCHARGE_FEE", strCaseAmountSC);
				      getValue('P', "AMT_SURCHARGE", m_strAmountSurcharge);
                  getValue('C', "MERCHANT_CAT_CODE", strMCC);
                  getValue('C', "TRAN_TYPE_ID", strTRAN_TYPE_ID);
                  getValue('H', "PROCESS_CODE", strPROCESS_CODE);

                  pos = strAMT_RECON_NET.find(" ");                  // get the CASE.AMT_RECON_NET
                  if (pos != string::npos)
	                  strAMT_RECON_NET.erase(0,pos + 1);
                  pos = strAMT_RECON_NET.find_first_of('.');
                  if (pos != string::npos)  // delete '.' 
	                  strAMT_RECON_NET.erase(pos,1);
                  dAMT_RECON_NET = atof(strAMT_RECON_NET.c_str());

			         pos = m_strAmountSurcharge.find(" ");     
				      if (pos != string::npos)
					      m_strAmountSurcharge.erase(0,pos + 1);
				      pos = m_strAmountSurcharge.find_first_of('.');
				      if (pos != string::npos)  // delete '.' 
					      m_strAmountSurcharge.erase(pos,1);
                  dAMT_SURCHARGE = atof(m_strAmountSurcharge.c_str()); 
                  pos = strCaseAmountSC.find(" ");                  // get the CASE.AMT_SURCHARGE
                  if (pos != string::npos)                           // this has the init full or part sc indication
	                  strCaseAmountSC.erase(0,pos + 1);
                  pos = strCaseAmountSC.find_first_of('.');
                  if (pos != string::npos)  // delete '.' 
	                  strCaseAmountSC.erase(pos,1);
                  dCaseAmountSC = atof(strCaseAmountSC.c_str());

                  Trace::put(strAMT_ADJUSTMENT.c_str());
                  Trace::put(strAMT_RECON_NET.c_str());
                  Trace::put(m_strAmountSurcharge.c_str());
                  Trace::put(strCaseAmountSC.c_str());

                  if (strTRAN_TYPE_ID.substr(0,2) == "01"      // withdrawal
                     && m_dAMT_ADJUSTMENT < (dAMT_RECON_NET - dAMT_SURCHARGE))
                     bFull = false;
                  if (strTRAN_TYPE_ID.substr(0,2) != "01")     // deposits
                  {
                     if (strREQUEST_TYPE.substr(0,3) == "ADJ")
                     {
                        if (m_dAMT_ADJUSTMENT != dAMT_RECON_NET)  //adj amt can be > tran amt
                           bFull = false;
                     }
                     else if (m_dAMT_ADJUSTMENT < dAMT_RECON_NET)
                        bFull = false;
                  }                  
                  if (bFull) 
                  {
                     m_strSurChargeInd="";
                     if (strREQUEST_TYPE.substr(0,3) == "ADJ")
                     {
                        if (strPROCESS_CODE.substr(0,2) == "02")
                              m_strSurChargeInd = "D";      
                        else if (strPROCESS_CODE.substr(0,2) == "22")
                              m_strSurChargeInd = "C";      
                     }
                     string strTRAN_TYPE_ID;
                     getValue('C', "TRAN_TYPE_ID", strTRAN_TYPE_ID);
                     if (strMCC == "6011"
                        && (strTRAN_TYPE_ID.substr(0,2) == "21"
                        || strTRAN_TYPE_ID.substr(0,2) == "25"))
                        m_dAMT_ADJUSTMENT += dAMT_SURCHARGE;
                  }
                  else
                  {
                     if (strMCC == "6011")
                     {
                        dAMT_SURCHARGE = 0;
                        m_strAmountSurcharge="000000000000";
                     }
                     else
                        m_dAMT_ADJUSTMENT += dAMT_SURCHARGE;
                  }
                  if (strMCC != "6011")
                     getValue('P', "ACTION_TO_CARDHLDR", m_strSurChargeInd);
                  snprintf(szTemp,sizeof(szTemp),"%012.0f",m_dAMT_ADJUSTMENT);
					   m_strValue = szTemp;
				   }
            }
			   if (ppszElements[i].siDENo == 14)
			   {
				   if (m_strValue.length() == 0)
					   m_strValue = "4912";
			   }
               else if (ppszElements[i].siDENo == 49 && m_strMessageType == "0600")
			   {
				   getValue('P', "CUR_ADJ_TRAN", m_strValue);
			   }
			   else if (ppszElements[i].siDENo == 54)
			   {
				   char szTemp[25];
				   string strCurCode, strAction;
				   getValue('C', "CUR_TRAN", strCurCode);
				   getValue('P', "ACTION_TO_CARDHLDR", strAction);
				   if (strAction == "C")
					   snprintf(szTemp,sizeof(szTemp),"9797%s%013.0f",strCurCode.data(),atof(m_strValue.data())*100);
				   else
					   snprintf(szTemp,sizeof(szTemp),"9797%sD%012.0f",strCurCode.data(),atof(m_strValue.data())*100);
				   m_strValue = szTemp;
			   }
			   else if (ppszElements[i].siDENo == 59) // POS Geographic Data
			   {
				   char szTemp[25];
				   memset(szTemp, ' ', sizeof(szTemp));
				   getValue('C', "CARD_ACPT_REGION", m_strValue);
				   memcpy(szTemp, m_strValue.data(), m_strValue.length());
				   getValue('C', "CARD_ACPT_COUNTY", m_strValue);
				   memcpy(szTemp+2, m_strValue.data(), m_strValue.length());
				   getValue('C', "CARD_ACPT_ZIP", m_strValue);
				   memcpy(szTemp+5, m_strValue.data(), m_strValue.length());
				   szTemp[10] = '\0';
				   m_strValue = szTemp;
			   }
			   else if (ppszElements[i].siDENo == 100) // 100th field
			   {
				   m_strValue = "585858";
				   string strNetId;
				   if(m_strMessageType == "0220")
					   getValue('C', "NET_ID_ISS", strNetId);
				   else if(m_strMessageType == "0422" || m_strMessageType == "0600")
					   getValue('C', "NET_ID_ACQ", strNetId);
				   string strTranslatedVal;
				   if(getGenericValue("ADMIN_ISO_RTING",strNetId,strTranslatedVal))
					   if(strTranslatedVal.length() > 0)
						   m_strValue = strTranslatedVal;            
			   }
			   else if (ppszElements[i].siDENo == 70) // 70th field
			   {
				   if(m_strMessageType == "0220")
					   m_strValue = "821";
				   else
					   m_strValue = "812";
			   }

			   if (ppszElements[i].siDESubfield > 0)
			   {
               string strNETWORK_ID;
   		      getValue('U', "NETWORK_ID", strNETWORK_ID);
   			   if (strcmp(ppszElements[i].pszName, "TRANSMIT_DATE_TIME") == 0)
               {
      			   if (ppszElements[i].siDENo == 7) 
   					   m_strValue = "          ";  // send blanks on export, save on import    
                  else if (ppszElements[i].siDENo == 90 && strNETWORK_ID != "0003")
                  {
   		            getValue('C', "TSTAMP_TRANS", m_strValue);
						   if (m_strValue.length() > 0)
						   {
							   m_strValue.erase(0,2);  
							   m_strValue.erase(10,4);                  
						   }
						   else	
							   m_strValue = "          ";  
                  }
               }
				   else if (strcmp(ppszElements[i].pszName, "FUNCTION_CODE") == 0)
               {
                  string strPOS_COND_CODE;
                  getValue('H', "POS_COND_CODE", strPOS_COND_CODE);
                  if (m_strMessageType == "0220" && strPOS_COND_CODE == "13"
                     && strNETWORK_ID == "0003")
                     m_strValue = "0422";
               }
				   else if (ppszElements[i].siDENo == 90
                  && strcmp(ppszElements[i].pszName, "ISS_BIN") == 0
                  && strNETWORK_ID == "0003")
               {
                  m_strValue = "00000000000";
               }

				   if (ppszElements[i].cSegInd == 'M')  // member variable
				   {
				   }

				   if (strcmp(ppszElements[i].pszName, "CARD_ACPT_COUNTRY") == 0)
				   {
					   string strCountryCodeISO2;
					   if(getCountryCodeISO2(m_strValue, strCountryCodeISO2))
						   if(strCountryCodeISO2.length() > 0)
							   m_strValue = strCountryCodeISO2;
				   }

				   if (ppszElements[i].pszLength[0] == 's')  // special "length" processing 
				   {
					   //cout << '[' << m_strValue << ']' << endl;  // test              
					   if (strcmp(ppszElements[i].pszName, "TSTAMP_LOCAL") == 0)
					   {
						   if (ppszElements[i].siDENo == 12) 
							   m_strValue.erase(0,8);  // time
						   else
						   {
							   m_strValue.erase(0,4);  // date
							   m_strValue.erase(4,6);
						   }
					   }
					   else if (strcmp(ppszElements[i].pszName, "TSTAMP_TRANS") == 0)
					   {
						   if (m_strValue.length() > 0)
						   {
							   m_strValue.erase(0,2);  
							   m_strValue.erase(10,4);                  
						   }
						   else	
							   m_strValue = "          ";  // send blanks on export, save on import
					   }

					   // other special length processing
				   }
				   if (ppszElements[i].siDENo == 4)
				   {
					   m_bAddAmount = true;
				   }
				   m_iPos += exportField(&ppszElements[i], &m_pszBuffer[m_iPos]); // Process regular mandatory fields
			   }
			   else 
				   i += wrapField(&ppszElements[i]);  // Wrap 0 field and export it
		   }         
	   } // end if (m_aPresence[ppszElements[i].siDENo] == 'M')
	   else if (m_aPresence[ppszElements[i].siDENo] == 'C')
	   {
		   if (m_strBit106_DATA.length() > 0)
		   {
			   Trace::put("106 has something");
			   m_aPresence[ppszElements[i].siDENo] = 'M';
			   i += wrapField(&ppszElements[i]);  // Wrap 0 field and export it
		   }
	   }
   } //END OF FOR-LOOP
   
   toBits(m_aPresence, (char *) bytes, 16);  // Set the bit map
   hexChar(&m_pszBuffer[4], bytes, 16);      // Make it characters 
   m_pszBuffer[m_iPos]= '\0';

   for (i=0; i < m_iPos; i++)
      if (m_pszBuffer[i] == '\0') m_pszBuffer[i] = '?';  // no nulls! 

   return;

  //## end bmlayouts::VisaMessage::deport%3E68BF570242.body
}

bool VisaMessage::import ()
{
  //## begin bmlayouts::VisaMessage::import%3E68BF5D01B5.body preserve=yes
   
   struct Elements* ppszElements    = elements();
   struct Elements* ppszSecElements = secElements();
   short iLen;
   char work[1000], data[1000];
   unsigned char bytes[34];
   m_iPos = 36;
   m_strADDITIONAL_DATA = "";
   m_strPOSEntryCode = "";
   m_strSUPPORT_INFO = "";
   m_strAdtlTraceData = "";
   m_strBit106_DATA = "";
   m_strSurChargeInd="";
   m_strAmountSurcharge="";   
   m_strREASON_CODE = "";
   memcpy(m_aPresence, aAllVisa, sizeof(aAllVisa));  // Set the universal element map

   charHex(&m_pszBuffer[4], bytes, 16);      // Make bit map true hexadecimal 
   
   for (int i = 0; i < m_lNumberOfElements; i++)
   {
      // Check for regular mandatory fields and secondary fields  
      
      work[0] = NULL; data[0] = NULL;

      if ((m_aPresence[ppszElements[i].siDENo] == 'M') &&    // Bit on in table
          (testBit((char *) bytes, ppszElements[i].siDENo))) // Bit on in msg 
         if (ppszElements[i].siDESubfield < 0) // secondary fields   
         {  
            for (int j=0; j < m_lNumberOfSecElements; j++) 
            {
               if (m_aSecPresence[ppszSecElements[j].siDENo] == 'M')
               {                  
                  m_iPos += importField(&ppszSecElements[j], &m_pszBuffer[m_iPos]);
               }
            }
         }   
         else 
         {
            if (ppszElements[i].siDESubfield > 0)
            {
               if (ppszElements[i].pszLength[0] == 's')  // special "length" processing 
               {
                  iLen = importField(&ppszElements[i], &m_pszBuffer[m_iPos], false);
                  memcpy(work, &m_pszBuffer[m_iPos], iLen);
                  work[iLen] = '\0';
               
                  if (strcmp(ppszElements[i].pszName, "REASON_CODE") == 0)
                  {
                     strcpy(data,work);
                     m_iPos += iLen; 
                  }
			       
                  if (strcmp(ppszElements[i].pszName, "TSTAMP_LOCAL") == 0)
                  {
                     if ((ppszElements[i].siDENo == 12) &&
                         (m_aPresence[ppszElements[i+1].siDENo] == 'M')) // LOCAL_TRAN_DATE
                     {
                        string strYYYY(Clock::instance()->getYYYYMMDDHHMMSS().substr(0,4));
                        int iMM = atoi(Clock::instance()->getYYYYMMDDHHMMSS().substr(4,2).c_str());
                        string strDate(&m_pszBuffer[m_iPos+6],4);
                        if ((strDate.substr(0,2) >= "09" && strDate.substr(0,2) <= "12")
                           && (iMM >= 1 && iMM <= 4))
                           snprintf(data,sizeof(data),"%d%s%s",atoi(strYYYY.data())-1,strDate.c_str(),work);
                        else
                           snprintf(data,sizeof(data),"%s%s%s",strYYYY.c_str(),strDate.c_str(),work);
                        i++;
                        iLen += 4;
                     }
                     else if (ppszElements[i].siDENo == 13)
                     {
                        string strYYYY(Clock::instance()->getYYYYMMDDHHMMSS().substr(0,4));
                        int iMM = atoi(Clock::instance()->getYYYYMMDDHHMMSS().substr(4,2).c_str());
                        string strTime(Clock::instance()->getYYYYMMDDHHMMSS().substr(8,6));
                        string strFileMM(work,2);
                        int iTranDate = atoi(strFileMM.c_str());
                        if (iTranDate > iMM)
                           snprintf(data,sizeof(data),"%d%s%s",atoi(strYYYY.data())-1,work,strTime.c_str());
                        else
                           snprintf(data,sizeof(data),"%s%s%s",strYYYY.c_str(),work,strTime.c_str());
                     }
                     
                     m_iPos += iLen;  
                  }

                  if (strcmp(ppszElements[i].pszName, "TSTAMP_TRANS") == 0)
                  {
                     strcpy(data,"20");
                     strcat(data,work);
                     Date hDate(data);
                     if (hDate.getMonth() > 0 && hDate.getMonth() < 13)
                     {
                        if (hDate.getDay() > 0 && hDate.getDay() < 31)
                           strcat(data,"0000");
                        else
                           data[0] = NULL;
                     }
                     else
                        data[0] = NULL;
                     m_iPos += 10; 
                  }

                  // Other special fields here
                  
                  if (strlen(data) > 0) // if something to import 
                  {
                     m_strValue = data;
                     importField(&ppszElements[i], &data[0]);  // data parm ignored for special
                  }
               }
               else
               {
                  if (ppszElements[i].siDENo == 90)
                  {
                     if (ppszElements[i].siDESubfield != 2
                        && ppszElements[i].siDESubfield != 4
                        && ppszElements[i].siDESubfield != 5)
                        m_iPos += importField(&ppszElements[i], &m_pszBuffer[m_iPos]); // Process regular mandatory fields
                     else
                        m_iPos += atoi((ppszElements[i].pszLength)+1);
                  }
                  else
                     m_iPos += importField(&ppszElements[i], &m_pszBuffer[m_iPos]); // Process regular mandatory fields
               }
            }
            else
               i += unwrapField(&ppszElements[i]);  // Unwrap field and import subfields
         }
   }      
   return 0;

  //## end bmlayouts::VisaMessage::import%3E68BF5D01B5.body
}

struct Elements* VisaMessage::secElements ()
{
  //## begin bmlayouts::VisaMessage::secElements%3E68C6E20157.body preserve=yes
   return &VisaMessage_Sec_Elements[0];
  //## end bmlayouts::VisaMessage::secElements%3E68C6E20157.body
}

void VisaMessage::setElementMaps ()
{
  //## begin bmlayouts::VisaMessage::setElementMaps%3E68BF66005D.body preserve=yes
   short dataSwitch = 0;
   string s1, s2, s3, s4, s5, s6;  
   Trace::put ("setElementMaps");
   switch (atoi(m_strMessageType.c_str()))
   {
      case 220:
         dataSwitch = 1;			   
         getValue('H', "POS_COND_CODE", m_strValue);
         Trace::put ("POS_COND_CODE ");
         Trace::put (m_strValue.c_str());
         if (m_strValue == "00")
         {
   		   getValue('U', "NETWORK_ID", m_strValue);
            if (m_strValue == "0003")
            {
   	         memcpy(m_aPresence, aADJ220_ILK, sizeof(aADJ220_ILK));
	            memcpy(m_aAdtlDataPrivate, aADJ220ADP_ILK, sizeof(aADJ220ADP_ILK));
	            memcpy(m_aReferenceData, aADJ220RD_ILK, sizeof(aADJ220RD_ILK));
            }
            else
            {
   	         memcpy(m_aPresence, aADJ220, sizeof(aADJ220));
	            memcpy(m_aAdtlDataPrivate, aADJ220ADP, sizeof(aADJ220ADP));
	            memcpy(m_aReferenceData, aADJ220RD, sizeof(aADJ220RD));
            }
	         memcpy(m_aLargePrivateData, aADJ220LPD, sizeof(aADJ220LPD));
	         m_strRequestType = "ADJ";
         }
         else if(m_strValue == "13")
         {
   		   getValue('U', "NETWORK_ID", m_strValue);
            if (m_strValue == "0003")
            {
	            memcpy(m_aPresence, aREPR220_ILK, sizeof(aREPR220_ILK));
               memcpy(m_aReferenceData, aREPR220RD_ILK, sizeof(aREPR220RD_ILK));
   	         memcpy(m_aLargePrivateData, aREPR220LPD_ILK, sizeof(aREPR220LPD_ILK));
            }
            else
            {
               memcpy(m_aReferenceData, aREPR220RD, sizeof(aREPR220RD));
	            memcpy(m_aPresence, aREPR220, sizeof(aREPR220));
   	         memcpy(m_aLargePrivateData, aREPR220LPD, sizeof(aREPR220LPD));
            }
  	         memcpy(m_aAdtlDataPrivate, aREPR220ADP, sizeof(aREPR220ADP));
	         m_strRequestType = "REP";
         }
         else
         {
            memcpy(m_aPresence, aFEES220, sizeof(aFEES220));
            memcpy(m_aAdtlDataPrivate, aFEES422ADP, sizeof(aFEES422ADP));
            memcpy(m_aLargePrivateData, aFEES422LPD, sizeof(aFEES422LPD));
            memcpy(m_aReferenceData, aFEES422RD, sizeof(aFEES422RD));
            m_strRequestType = "FEE";
         }
         break;
      case 422:
            dataSwitch = 1;			   
		      getValue('H', "POS_COND_CODE", m_strValue);
            if ((m_strValue == "17") || (m_strValue == "54"))
            {
   		      getValue('U', "NETWORK_ID", m_strValue);
               if (m_strValue == "0003")
               {
                  memcpy(m_aPresence, aCHBK422_ILK, sizeof(aCHBK422_ILK));
                  memcpy(m_aAdtlDataPrivate, aCHBK422ADP_ILK, sizeof(aCHBK422ADP_ILK));
                  memcpy(m_aReferenceData, aCHBK422RD_ILK, sizeof(aCHBK422RD_ILK));
               }
               else
               {
                  memcpy(m_aPresence, aCHBK422, sizeof(aCHBK422));
                  memcpy(m_aAdtlDataPrivate, aCHBK422ADP, sizeof(aCHBK422ADP));
                  memcpy(m_aReferenceData, aCHBK422RD, sizeof(aCHBK422RD));
               }
               memcpy(m_aLargePrivateData, aCHBK422LPD, sizeof(aCHBK422LPD));
               m_strRequestType = "CHB";
            }
            else
            {
               memcpy(m_aPresence, aFEES422, sizeof(aFEES422));
               memcpy(m_aAdtlDataPrivate, aFEES422ADP, sizeof(aFEES422ADP));
               memcpy(m_aLargePrivateData, aFEES422LPD, sizeof(aFEES422LPD));
               memcpy(m_aReferenceData, aFEES422RD, sizeof(aFEES422RD));
               m_strRequestType = "FEE";
            }
            break;
      case 600:
               dataSwitch = 2;			   
               memcpy(m_aPresence, aCOPY600, sizeof(aCOPY600));
               memcpy(m_aAdtlDataPrivate, aCOPY600ADP, sizeof(aCOPY600ADP));
               memcpy(m_aLargePrivateData, aCOPY600LPD, sizeof(aCOPY600LPD));
               memcpy(m_aReferenceData, aCOPY600RD, sizeof(aCOPY600RD));
               getValue('H', "NETW_MGMT_CODE", m_strValue);
               m_strRequestType = "RR";
			   switch (atoi(m_strValue.c_str()))
               {
                  case 883:
                     memcpy(m_aPresence, aTEXT600, sizeof(aTEXT600));
                     memcpy(m_aAdtlDataPrivate, aTEXT600ADP, sizeof(aTEXT600ADP));
                     memcpy(m_aLargePrivateData, aTEXT600LPD, sizeof(aTEXT600LPD));
                     memcpy(m_aReferenceData, aTEXT600RD, sizeof(aTEXT600RD));
                     break;
                  case 885:
                     memcpy(m_aPresence, aVCFRS600_885, sizeof(aVCFRS600_885));
                     memcpy(m_aAdtlDataPrivate, aVCFRS600_885ADP, sizeof(aVCFRS600_885ADP));
                     memcpy(m_aLargePrivateData, aVCFRS600_885LPD, sizeof(aVCFRS600_885LPD));
                     memcpy(m_aReferenceData, aVCFRS600_885RD, sizeof(aVCFRS600_885RD));
                     break;
                  case 886:
                     memcpy(m_aPresence, aVCFRS600_886, sizeof(aVCFRS600_886));
                     memcpy(m_aAdtlDataPrivate, aVCFRS600_886ADP, sizeof(aVCFRS600_886ADP));
                     memcpy(m_aLargePrivateData, aVCFRS600_886LPD, sizeof(aVCFRS600_886LPD));
                     memcpy(m_aReferenceData, aVCFRS600_886RD, sizeof(aVCFRS600_886RD));
                     break;
                  case 887:
                     memcpy(m_aPresence, aVCFRS600_887, sizeof(aVCFRS600_887));
                     memcpy(m_aAdtlDataPrivate, aVCFRS600_887ADP, sizeof(aVCFRS600_887ADP));
                     memcpy(m_aLargePrivateData, aVCFRS600_887LPD, sizeof(aVCFRS600_887LPD));
                     memcpy(m_aReferenceData, aVCFRS600_887RD, sizeof(aVCFRS600_887RD));
                     break;
               }
           break;
      case 9620:
            dataSwitch = 3;			   
            memcpy(m_aPresence, aFRAUD9620, sizeof(aFRAUD9620));
            memcpy(m_aAdtlDataPrivate, aFRAUD9620ADP, sizeof(aFRAUD9620ADP));
            memcpy(m_aLargePrivateData, aFRAUD9620LPD, sizeof(aFRAUD9620LPD));
            memcpy(m_aReferenceData, aFRAUD9620RD, sizeof(aFRAUD9620RD));
            m_strRequestType = "FRD";
            break;
   }

   m_strADDITIONAL_DATA = "";
   m_strPOSEntryCode = "";
   m_strSUPPORT_INFO = "";
   m_strAdtlTraceData = "";
   m_strBit106_DATA = "";
   switch (dataSwitch)
   {
      case 1:

         if (m_strRequestType != "FEE")
         {
            char szREQ_CONTACT_NAME[16];
            char szREQ_CONTACT_PHONE[11];
            memset(szREQ_CONTACT_NAME, ' ', 15);
            memset(szREQ_CONTACT_PHONE, ' ', 10);
            getValue('H', "USAGE_CODE", s1);
            getValue('H', "DOC_IND",    s2);
            getValue('H', "CHB_REF_NO", s3);
   		   getValue('U', "NETWORK_ID", m_strValue);
            getValue('H', "VISA_MMT",   s4);
            if (m_strValue == "0003" && m_strRequestType == "ADJ")
            {
               getValue('P', "REQ_CONTACT_NAME",s5);
               if (s5.length() > 15)
                  s5.erase(15);
               memcpy(szREQ_CONTACT_NAME,s5.data(),s5.length());
               getValue('P', "REQ_CONTACT_PHONE",s6);
               if (s6.length() > 10)
                  s6.erase(10);
               memcpy(szREQ_CONTACT_PHONE,s6.data(),s6.length());
               if (s2.length() == 0)
                  m_strADDITIONAL_DATA = "V" + s1 + " " + s3;
               else
                  m_strADDITIONAL_DATA = "V" + s1 + s2 + s3;
               m_strADDITIONAL_DATA.append(szREQ_CONTACT_NAME,15);
               m_strADDITIONAL_DATA.append(szREQ_CONTACT_PHONE,10);
               m_strADDITIONAL_DATA += s4;
            }
            else
            {
               if (s2.length() == 0)
                  m_strADDITIONAL_DATA = "V" + s1 + " " + s3 + s4;
               else
                  m_strADDITIONAL_DATA = "V" + s1 + s2 + s3 + s4;
            }
            if (m_strADDITIONAL_DATA.length() < 9)
               m_strADDITIONAL_DATA = "";  // length must be 10 to 59

            getValue('U', "TERM_TYPE_IND", s1);
            getValue('U', "TERM_ENTRY_CAP_IND", s2);
            s3 = "0";
            getValue('U', "EXIST_DEBT_FLG", s4);
            if(s4 == "9")
               m_strPOSEntryCode = s1 + s2 + s3 + s4;
            else
               m_strPOSEntryCode = s1 + s2;
         }
         else
            getValue('H', "VISA_MMT", m_strADDITIONAL_DATA);

         break;
      case 2:
		   getValue('H', "ISSUER_CNTL_NO", s1);
		   getValue('P', "REQ_CONTACT_FAX", s2);
		   getValue('U', "RFC_BIN", s3);
		   getValue('U', "SOURCE_SUB_ADDR", s4);
         char szAdtlData[60];
         memset(szAdtlData, ' ', sizeof(szAdtlData));
         szAdtlData[0] = 'W';
         memcpy(szAdtlData+1, s1.data(), s1.length());
         if (s2.length() == 0) // Fax number
            memcpy(szAdtlData+10, "                ", 16);
         else
         {
            if (s2.length() > 16)
               memcpy(szAdtlData+10, s2.data(), 16);
            else
               memcpy(szAdtlData+10, s2.data(), s2.length());
         }
         szAdtlData[26] = '1';  // Issuer Fulfillment Method
         szAdtlData[27] = ' ';
         if (s3.length() == 0) // RFC Bin
            memcpy(szAdtlData+28, "000000", 6);
         else
            memcpy(szAdtlData+28, s3.data(), s3.length());
         memcpy(szAdtlData+34, "000000000000", 12);
         if (s4.length() == 0)
            memcpy(szAdtlData+46, "0000000", 7);
         else
            memcpy(szAdtlData+46, s4.data(), s4.length());
         szAdtlData[53] = '\0';
		   m_strADDITIONAL_DATA = szAdtlData;
         getValue('H', "VISA_MMT", m_strSUPPORT_INFO);
         break;
      case 3:
         getValue('U', "TERM_TYPE_IND", s1);
 	      getValue('U', "TERM_ENTRY_CAP_IND", s2);
         m_strPOSEntryCode = s1 + s2;
         char szAdtlFraudInfo[260];
         memset(szAdtlFraudInfo, ' ', sizeof(szAdtlFraudInfo));
         memcpy(szAdtlFraudInfo, "06", 2);
         getValue('L', "POSTAL_CODE", s1);
         memcpy(szAdtlFraudInfo+2, s1.data(), s1.length());
 	      getValue('L', "LAST_NAME_1", s1);
         memcpy(szAdtlFraudInfo+12, s1.data(), s1.length());
 	      getValue('L', "FIRST_NAME_1", s1);
         memcpy(szAdtlFraudInfo+37, s1.data(), s1.length());
         memcpy(szAdtlFraudInfo+52, " ", 1);  // MI
 	      getValue('L', "ADDRESS_LINE_1", s1);
         memcpy(szAdtlFraudInfo+53, s1.data(), s1.length());
 	      getValue('L', "ADDRESS_LINE_2", s1);
         memcpy(szAdtlFraudInfo+74, s1.data(), s1.length());
 	      getValue('L', "CITY", s1);
         memcpy(szAdtlFraudInfo+97, s1.data(), s1.length());
 	      getValue('L', "REGION", s1);
         memcpy(szAdtlFraudInfo+111, s1.data(), s1.length());
 	      getValue('L', "HOME_PHONE_NO", s1);
         memcpy(szAdtlFraudInfo+113, s1.data(), s1.length());
 	      getValue('L', "SSN_1", s1);
         memcpy(szAdtlFraudInfo+123, s1.data(), s1.length());
 	      getValue('D', "MAIL_POSTAL_CD", s1);
         memcpy(szAdtlFraudInfo+132, s1.data(), s1.length());
 	      getValue('R', "CARD_VALID_FROM", s1);  
         memcpy(szAdtlFraudInfo+141, s1.data(), s1.length());
 	      getValue('D', "MAIL_DATE", s1);
         memcpy(szAdtlFraudInfo+145, s1.data(), s1.length());
 	      getValue('D', "MAIL_CITY", s1);
         memcpy(szAdtlFraudInfo+151, s1.data(), s1.length());
 	      getValue('D', "MAIL_REGION", s1);
         memcpy(szAdtlFraudInfo+179, s1.data(), s1.length());
         memcpy(szAdtlFraudInfo+181, "0                   ", 19); // Market Segment Code(0),Locator Number(11),Case Number(6),Arrest Code(1)
 	      getValue('R', "ISS_GEN_AUTH_IND", s1);
         memcpy(szAdtlFraudInfo+201, s1.data(), s1.length());
 	      getValue('R', "ACCT_SEQ_NO", s1);
         memcpy(szAdtlFraudInfo+202, s1.data(), s1.length());
 	      getValue('R', "FRD_INVESTIGE_STS", s1);
         memcpy(szAdtlFraudInfo+206, s1.data(), s1.length());
 	      getValue('R', "CASHBACK_FLG", s1);
         memcpy(szAdtlFraudInfo+208, s1.data(), s1.length());
 	      getValue('R', "CARD_CAP_IND", s1);
         memcpy(szAdtlFraudInfo+209, s1.data(), s1.length());
 	      getValue('R', "TRAVEL_AGENCY_ID", s1);
         memcpy(szAdtlFraudInfo+210, s1.data(), s1.length());
 	      getValue('R', "CARDH_ID_METH_IND", s1);
         memcpy(szAdtlFraudInfo+218, s1.data(), s1.length());
         szAdtlFraudInfo[219] = '\0';
         m_strSUPPORT_INFO = szAdtlFraudInfo; 
         break;
   }	
	
   /*
   cout << "Element Maps values: [" << m_strMessageType << 
		   ','  << m_strValue <<
		   ','  << m_strADDITIONAL_DATA << ']' << endl;   
   */

  //## end bmlayouts::VisaMessage::setElementMaps%3E68BF66005D.body
}

int VisaMessage::unwrapField (Elements *pZeroElement)
{
  //## begin bmlayouts::VisaMessage::unwrapField%3E8C68F002BF.body preserve=yes
   int  loop, index, Pos, Bit;
   int  saveSubfield = 0;
   char work[1000];
   char szBitmap[] = {"X0000000000000000"};   
   unsigned char bytes[18];
   
   loop = 2; 
   while (*(pZeroElement[loop].pszName) != '~')
      if (pZeroElement[loop].siDESubfield > 1) loop++; else break;

   if (pZeroElement[0].siDENo == 106)  // imbedded length
   {
      if (memcmp(&m_pszBuffer[m_iPos], "NV", 2) == 0)
         return 1;
   }

   m_iPos += importField(&pZeroElement[0], &m_pszBuffer[m_iPos], false);
   if (pZeroElement[0].siDENo == 106)  
      return 0;
   memset(work, NULL, sizeof(work));
   memcpy(work, m_strValue.c_str(), m_strValue.length());
   work[m_strValue.length()] = '\0';
   Pos   = 0;
   Bit   = 0;
   index = 0;
   
   if (pZeroElement[0].siDENo == 105)  // imbedded length and bit map
   {
      charHex(&work[9], bytes, 4);     // Make bit map true hexadecimal 
      Pos   = 17;
      Bit   = 1;
      index = 3;      
   }
   else if ((pZeroElement[0].siDENo == 111) | (pZeroElement[0].siDENo == 121)) // imbedded length and bit map
   {
      charHex(&work[5], bytes, 4);      // Make bit map true hexadecimal 
      Pos   = 13;
      Bit   = 1;
      index = 3;      
   }


   for (short i = index+1; i < loop; i++)
      if (Bit == 0)
      {           
         if (work[Pos] != NULL) // no more data
         {
            Pos += importField(&pZeroElement[i], &work[Pos]);
            if (pZeroElement[i].cSegInd == 'M') // member variable
            {
		         if (strcmp(pZeroElement[i].pszName, "ADDITIONAL_DATA") == 0)
			         m_strADDITIONAL_DATA = m_strValue;  // save for now
		         else if (strcmp(pZeroElement[i].pszName, "POSEntryCode") == 0)
   			      m_strPOSEntryCode = m_strValue;  // save for now
		         else if (strcmp(pZeroElement[i].pszName, "Transaction_Fee") == 0)
               {
                  m_strSurChargeInd = m_strValue.substr(0,1);
                  m_strAmountSurcharge = m_strValue.substr(1,8); // save for now
               }
		         else if (strcmp(pZeroElement[i].pszName, "SUPPORT_INFO") == 0)
   			      m_strSUPPORT_INFO = m_strValue;  // save for now
               else
                  m_strMessageType = m_strValue;   
               //cout << "MessageType: " << m_strMessageType << endl;  
            }
         }
      }
      else
      {           
         if (saveSubfield != pZeroElement[i].siDESubfield &&
             saveSubfield != 0) Bit++;   
         if (testBit((char *) bytes, Bit))
         {
            Pos += importField(&pZeroElement[i], &work[Pos]);
		      if (strcmp(pZeroElement[i].pszName, "ADDITIONAL_DATA") == 0)
			      m_strADDITIONAL_DATA = m_strValue;  // save for now
		      else if (strcmp(pZeroElement[i].pszName, "POSEntryCode") == 0)
   			   m_strPOSEntryCode = m_strValue;  // save for now
            else if (strcmp(pZeroElement[i].pszName, "Transaction_Fee") == 0)
            {
               m_strSurChargeInd = m_strValue.substr(0,1);
               m_strAmountSurcharge = m_strValue.substr(1,8); // save for now
            }
		      else if (strcmp(pZeroElement[i].pszName, "SUPPORT_INFO") == 0)
   			   m_strSUPPORT_INFO = m_strValue;  // save for now
		      else if (strcmp(pZeroElement[i].pszName, "AdtlTraceData") == 0)
            {
               m_strAdtlTraceData = m_strValue;
               if (m_strValue.length() > 15)
               {
                  string strTemp = m_strValue.substr(15,4);
                  setValue('H', "REJECT_CODE", strTemp);
               }
            }
		      else if (strcmp(pZeroElement[i].pszName, "REASON_CODE") == 0)
               m_strREASON_CODE.assign(work+Pos-4,4);
         }
         saveSubfield = pZeroElement[i].siDESubfield;
      }
      
   return loop-1;

  //## end bmlayouts::VisaMessage::unwrapField%3E8C68F002BF.body
}

void VisaMessage::update (Subject* pSubject)
{
  //## begin bmlayouts::VisaMessage::update%3E92D36C03A9.body preserve=yes
  //## end bmlayouts::VisaMessage::update%3E92D36C03A9.body
}

int VisaMessage::wrapField (Elements *pZeroElement)
{
  //## begin bmlayouts::VisaMessage::wrapField%3E8C4C1300FA.body preserve=yes
   int  loop, Pos, Bit;
   int  savePos = 0, saveSubfield = 0;
   char work[1000];
   char szFormat[10] = {"         "};
   char szTemp[32];
   char szBitmap[] = {"X00000000000000000000000000000000"};   
   unsigned char bytes[19];
   struct Elements pSaveElement;
   char aBitPresence[24];
   bool bOverLimit = false;

   switch (pZeroElement[0].siDENo)
   {
      case 105: 
         memcpy(aBitPresence, m_aLargePrivateData, sizeof(m_aLargePrivateData)); 
         break;
      case 111: 
      case 121: 
         memcpy(aBitPresence, m_aAdtlDataPrivate, sizeof(m_aAdtlDataPrivate)); 
         break;
      case 126: 
      case 127: 
         memcpy(aBitPresence, m_aReferenceData, sizeof(m_aReferenceData)); 
         break;
   }

   memset(work, NULL, sizeof(work));
   loop = 2; 
   while (*(pZeroElement[loop].pszName) != '~')
      if (pZeroElement[loop].siDESubfield > 1) loop++; else break; 
   Pos = 0;
   Bit = 0;
   for (short i = 1; i < loop; i++)
   {
	   Trace::put("wrap fields");
	   char szNo[65];
	   snprintf(szNo,sizeof(szNo),"%d  %c  %s",pZeroElement[i].siDESubfield,aBitPresence[pZeroElement[i].siDESubfield],
         pZeroElement[i].pszName);
	   Trace::put(szNo);
	   if (aBitPresence[pZeroElement[i].siDESubfield] == 'M')
	   {
		   if (pZeroElement[i].cSegInd == 'M') // member variable
		   {
			   if (strcmp(pZeroElement[i].pszName, "ADDITIONAL_DATA") == 0)
				   m_strValue = m_strADDITIONAL_DATA;
			   else if (strcmp(pZeroElement[i].pszName, "POSEntryCode") == 0)
				   m_strValue = m_strPOSEntryCode;
			   else if (strcmp(pZeroElement[i].pszName, "SUPPORT_INFO") == 0)
				   m_strValue = m_strSUPPORT_INFO;
			   else if (strcmp(pZeroElement[i].pszName, "AdtlTraceData") == 0)
				   m_strValue = m_strAdtlTraceData;
			   else
			   {
				   snprintf(szTemp,sizeof(szTemp),"%04d",atoi(m_strMessageType.c_str()));
				   m_strValue = szTemp;
			   }
		   }
		   else if (pZeroElement[i].siDENo == 105 && pZeroElement[i].siDESubfield == 6 &&
			   m_strMessageType == "9620")
			   m_strValue = "400050";
		   else getValue(pZeroElement[i].cSegInd, pZeroElement[i].pszName, m_strValue);

		   if (strcmp(pZeroElement[i].pszName, "REASON_CODE") == 0)
		   {
			   int iCode = atoi(m_strValue.c_str()); 
			   char szTemp[5];
			   snprintf(szTemp,sizeof(szTemp),"%04d",iCode);
			   m_strValue = szTemp;
		   }
		   else if ((strcmp(pZeroElement[i].pszName, "MULTI_CLR_SEQ_NO") == 0 ||
			   strcmp(pZeroElement[i].pszName, "MULTI_CLR_SEQ_CNT") == 0) &&
			   m_strValue.length() > 0)
		   {
			   m_strValue.insert(0, "00", 2-m_strValue.length());
		   }
		   else if (strcmp(pZeroElement[i].pszName, "TRAN_IDENTIFIER") == 0)
		   {
			   string strTranId;
			   int iLen = (int)strlen(pZeroElement[i].pszName);
			   getValue('U', "TRAN_IDENTIFIER", strTranId);
			   if(strTranId.length()!= 0)
			   {
				   m_strValue = strTranId;
			   }
			   else
				   m_strValue = "               ";
		   }               
		   else if (strcmp(pZeroElement[i].pszName, "AUTH_CHAR_FLG") == 0)
		   {
			   string strAuthFlg;
			   int iLen = (int)strlen(pZeroElement[i].pszName);
			   getValue('U', "AUTH_CHAR_FLG", strAuthFlg);
			   if(strAuthFlg.length()!= 0)
			   {
				   m_strValue = strAuthFlg;
			   }
			   else
				   m_strValue = " ";
		   }
		   else if (strcmp(pZeroElement[i].pszName, "PAN_DT_ENTRY_MODE") == 0)
		   {
			   if (m_strValue == "90")
				   m_strValue = "01";
		   }
		   else if (strcmp(pZeroElement[i].pszName, "ACQ_BUSINESS_ID") == 0)
		   {
			   m_strValue.insert(0, "00000000", 8-m_strValue.length());
		   }
		   else if (pZeroElement[i].pszName == "RESP_CODE" &&
			   m_strValue.length() > 0)
			   m_strValue = "  ";
		   else if (pZeroElement[i].pszName == "MOTO_IND") // take second character
			   m_strValue.erase(0,1);
		   else if (pZeroElement[i].pszName == "Transaction_Fee")	// Transaction_Fee
		   {
			   char szTemp[25];
			   string strREQUEST_TYPE;
			   getValue('C', "REQUEST_TYPE", strREQUEST_TYPE);
			   if(strREQUEST_TYPE.substr(0,3) == "ADJ" || strREQUEST_TYPE == "REP1"
              || strREQUEST_TYPE == "CHB1")
			   {										
   			   if (m_strSurChargeInd == "C")
					   snprintf(szTemp,sizeof(szTemp),"C%08d",atoi(m_strAmountSurcharge.c_str()));
				   else
					   snprintf(szTemp,sizeof(szTemp),"D%08d",atoi(m_strAmountSurcharge.c_str()));
				   m_strValue = szTemp;
			   }
			   else
			   {
				   m_strValue = "";						
				   aBitPresence[pZeroElement[i].siDESubfield] = ' ';
				   continue;
			   }
		   }
		   if ((!Bit) || // not at one of the bitmapped subfields yet
			   (pZeroElement[i].cSegInd == 'F')      || // filler
			   (pZeroElement[i].pszLength[0] == 'v') || // variable
			   ((Bit) && (m_strValue.length() != 0)))  // skip null fields
		   {
			   if (pZeroElement[i].siDENo == 105)
			   {
				   string strTemp;
				   if (Pos + m_strValue.length() > 255)
				   {
					   int iLeft = 255-Pos-3;
					   m_strBit106_DATA = m_strValue.substr(iLeft, m_strValue.length()-iLeft);
					   m_strValue.erase(iLeft, m_strValue.length()-iLeft);
					   Pos += exportField(&pZeroElement[i], &work[Pos]);
				   }
				   else
					   Pos += exportField(&pZeroElement[i], &work[Pos]);
			   }
			   else if (pZeroElement[0].siDENo == 106)
			   {
				   bOverLimit = true;
				   m_strValue = m_strBit106_DATA;
				   m_iPos += exportField(&pZeroElement[0], &m_pszBuffer[m_iPos]);
			   }
			   else
				   Pos += exportField(&pZeroElement[i], &work[Pos]);
		   }
	   }
	   else if (pZeroElement[0].siDENo == 106)
	   {
		   bOverLimit = true;
		   m_strValue = m_strBit106_DATA;
		   m_iPos += exportField(&pZeroElement[0], &m_pszBuffer[m_iPos]);
	   }
	   else if (pZeroElement[i].siDENo == 126 || pZeroElement[i].siDENo == 127)
	   {
		   string strTemp(pZeroElement[i].pszLength);
		   pSaveElement = pZeroElement[i];
		   pSaveElement.pszName = " ";
		   pSaveElement.cSegInd = 'F';
		   pSaveElement.iType = ALP;
		   strTemp.replace(0,1,"f");
		   pSaveElement.pszLength = (char *)strTemp.data();
		   Pos += exportField(&pSaveElement, &work[Pos]);
	   }
	   if (pZeroElement[i].iType == _B) Bit = 1;  // activate bit capture 
	   else
	   {
		   if (Bit)
		   {
			   if (saveSubfield != pZeroElement[i].siDESubfield) // different subfield
			   {
				   if (savePos != Pos) 
					   szBitmap[Bit] = 'M';  // and data exported
				   Bit++;
			   }
		   }
	   }
	   savePos      = Pos;
	   saveSubfield = pZeroElement[i].siDESubfield;
   }
   
   if (pZeroElement[0].siDENo == 105)  // imbedded length and bit map
   {
      strcpy(szFormat,"%04d");
      snprintf(szTemp,sizeof(szTemp),szFormat,Pos-9);
      memcpy(&work[5], szTemp, 4);
      toBits(szBitmap, (char *) bytes, 4); // Set bit map
      hexChar(&work[9], bytes, 4);         // Make it characters 
   }
   
   if ((pZeroElement[0].siDENo == 111) | (pZeroElement[0].siDENo == 121))  // imbedded length and bit map
   {
      strcpy(szFormat,"%03d");
      snprintf(szTemp,sizeof(szTemp),szFormat,Pos-5);
      memcpy(&work[2], szTemp, 3);
      toBits(szBitmap, (char *) bytes,4); // Set bit map
      hexChar(&work[5], bytes,4);         // Make it characters       
   }

   if (!bOverLimit)
   {
      m_strValue.assign(work, Pos);
      m_iPos += exportField(&pZeroElement[0], &m_pszBuffer[m_iPos]);
   }
   return loop-1;  
   
  //## end bmlayouts::VisaMessage::wrapField%3E8C4C1300FA.body
}

bool VisaMessage::getCountryCodeISO2 (const string& strCountryCodeISO3, string& strCountryCodeISO2)
{
  //## begin bmlayouts::VisaMessage::getCountryCodeISO2%44D2CA770089.body preserve=yes
	return false;
  //## end bmlayouts::VisaMessage::getCountryCodeISO2%44D2CA770089.body
}

bool VisaMessage::getGenericValue (const string& strType, const string& strFromValue, string& strToValue)
{
  //## begin bmlayouts::VisaMessage::getGenericValue%4648252B0367.body preserve=yes
   return false;
  //## end bmlayouts::VisaMessage::getGenericValue%4648252B0367.body
}

// Additional Declarations
  //## begin bmlayouts::VisaMessage%3E4A4EA0038A.declarations preserve=yes
  //## end bmlayouts::VisaMessage%3E4A4EA0038A.declarations

} // namespace bmlayouts

//## begin module%3E4A4F9D031C.epilog preserve=yes
//## end module%3E4A4F9D031C.epilog
