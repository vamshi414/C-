//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E4A5738035B.cm preserve=no
//	$Date:   18 Jan 2018 14:02:54  $ $Author:   e1009839  $
//	$Revision:   1.15  $
//## end module%3E4A5738035B.cm

//## begin module%3E4A5738035B.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%3E4A5738035B.cp

//## Module: CXOSBL03%3E4A5738035B; Package specification
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bldll\CXODBL03.hpp

#ifndef CXOSBL03_h
#define CXOSBL03_h 1

//## begin module%3E4A5738035B.additionalIncludes preserve=no
//## end module%3E4A5738035B.additionalIncludes

//## begin module%3E4A5738035B.includes preserve=yes
// $Date:   18 Jan 2018 14:02:54  $ $Author:   e1009839  $ $Revision:   1.15  $
#include <vector>
//## end module%3E4A5738035B.includes

#ifndef CXOSBL01_h
#include "CXODBL01.hpp"
#endif
//## begin module%3E4A5738035B.declarations preserve=no
//## end module%3E4A5738035B.declarations

//## begin module%3E4A5738035B.additionalDeclarations preserve=yes
//## end module%3E4A5738035B.additionalDeclarations


//## Modelname: Connex Library::BitMapLayouts_CAT%3E4A483C030D
namespace bmlayouts {
//## begin bmlayouts%3E4A483C030D.initialDeclarations preserve=yes
//## end bmlayouts%3E4A483C030D.initialDeclarations

//## begin bmlayouts::MasterCardMessage%3E4A56860251.preface preserve=yes
//## end bmlayouts::MasterCardMessage%3E4A56860251.preface

//## Class: MasterCardMessage%3E4A56860251
//## Category: Connex Library::BitMapLayouts_CAT%3E4A483C030D
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport MasterCardMessage : public BitMapMessage  //## Inherits: <unnamed>%3E92D62F03B9
{
  //## begin bmlayouts::MasterCardMessage%3E4A56860251.initialDeclarations preserve=yes
  //## end bmlayouts::MasterCardMessage%3E4A56860251.initialDeclarations

  public:
    //## Constructors (generated)
      MasterCardMessage();

    //## Destructor (generated)
      virtual ~MasterCardMessage();


    //## Other Operations (specified)
      //## Operation: elements%3E4A97ED030D
      struct Elements* elements () const;

      //## Operation: deport%3E4A5713034B
      virtual void deport ();

      //## Operation: getCurrencyExp%3EE74A1A035B
      virtual char getCurrencyExp (const string& strCurrencyCode);

      //## Operation: import%3E4A63DB0109
      virtual bool import ();

      //## Operation: PDSelements%3E568A530213
      struct Elements* PDSelements ();

      //## Operation: update%3E92D3310203
      virtual void update (Subject* pSubject);

      //## Operation: updateFields%3E9ECD3A0251
      void updateFields (void* hSegment, char cInd);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: MsgRevInd%3EE748220157
      const char& getMsgRevInd () const
      {
        //## begin bmlayouts::MasterCardMessage::getMsgRevInd%3EE748220157.get preserve=no
        return m_cMsgRevInd;
        //## end bmlayouts::MasterCardMessage::getMsgRevInd%3EE748220157.get
      }


      //## Attribute: RefData%3E9D56DD00EA
      const string& getRefData () const
      {
        //## begin bmlayouts::MasterCardMessage::getRefData%3E9D56DD00EA.get preserve=no
        return m_strRefData;
        //## end bmlayouts::MasterCardMessage::getRefData%3E9D56DD00EA.get
      }


      //## Attribute: SeqNo%3E9D56FF036B
      const string& getSeqNo () const
      {
        //## begin bmlayouts::MasterCardMessage::getSeqNo%3E9D56FF036B.get preserve=no
        return m_strSeqNo;
        //## end bmlayouts::MasterCardMessage::getSeqNo%3E9D56FF036B.get
      }


      //## Attribute: SOURCE_MSG_NO%3E9D621D032C
      const int& getSOURCE_MSG_NO () const
      {
        //## begin bmlayouts::MasterCardMessage::getSOURCE_MSG_NO%3E9D621D032C.get preserve=no
        return m_lSOURCE_MSG_NO;
        //## end bmlayouts::MasterCardMessage::getSOURCE_MSG_NO%3E9D621D032C.get
      }

      void setSOURCE_MSG_NO (const int& value)
      {
        //## begin bmlayouts::MasterCardMessage::setSOURCE_MSG_NO%3E9D621D032C.set preserve=no
        m_lSOURCE_MSG_NO = value;
        //## end bmlayouts::MasterCardMessage::setSOURCE_MSG_NO%3E9D621D032C.set
      }


    // Additional Public Declarations
      //## begin bmlayouts::MasterCardMessage%3E4A56860251.public preserve=yes
      //## end bmlayouts::MasterCardMessage%3E4A56860251.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: FileType%3E9D56D101D4
      //## begin bmlayouts::MasterCardMessage::FileType%3E9D56D101D4.attr preserve=no  protected: string {U} 
      string m_strFileType;
      //## end bmlayouts::MasterCardMessage::FileType%3E9D56D101D4.attr

      //## Attribute: InstID%3EE74A780196
      //## begin bmlayouts::MasterCardMessage::InstID%3EE74A780196.attr preserve=no  protected: string {U} 
      string m_strInstID;
      //## end bmlayouts::MasterCardMessage::InstID%3EE74A780196.attr

      //## Attribute: MemProcID%3E9D56E9034B
      //## begin bmlayouts::MasterCardMessage::MemProcID%3E9D56E9034B.attr preserve=no  protected: string {U} 
      string m_strMemProcID;
      //## end bmlayouts::MasterCardMessage::MemProcID%3E9D56E9034B.attr

      //## Attribute: MsgInd%3EA969A301E4
      //## begin bmlayouts::MasterCardMessage::MsgInd%3EA969A301E4.attr preserve=no  protected: string {U} 
      string m_strMsgInd;
      //## end bmlayouts::MasterCardMessage::MsgInd%3EA969A301E4.attr

      //## begin bmlayouts::MasterCardMessage::MsgRevInd%3EE748220157.attr preserve=no  public: char {U} 
      char m_cMsgRevInd;
      //## end bmlayouts::MasterCardMessage::MsgRevInd%3EE748220157.attr

      //## Attribute: PDSpresence%3E5BA4280167
      //## begin bmlayouts::MasterCardMessage::PDSpresence%3E5BA4280167.attr preserve=no  protected: char {U} 
      char m_aPDSpresence[410];
      //## end bmlayouts::MasterCardMessage::PDSpresence%3E5BA4280167.attr

      //## Attribute: ProcMode%3EA9694C0203
      //## begin bmlayouts::MasterCardMessage::ProcMode%3EA9694C0203.attr preserve=no  protected: string {U} 
      string m_strProcMode;
      //## end bmlayouts::MasterCardMessage::ProcMode%3EA9694C0203.attr

      //## begin bmlayouts::MasterCardMessage::RefData%3E9D56DD00EA.attr preserve=no  public: string {U} 
      string m_strRefData;
      //## end bmlayouts::MasterCardMessage::RefData%3E9D56DD00EA.attr

      //## begin bmlayouts::MasterCardMessage::SeqNo%3E9D56FF036B.attr preserve=no  public: string {U} 
      string m_strSeqNo;
      //## end bmlayouts::MasterCardMessage::SeqNo%3E9D56FF036B.attr

      //## begin bmlayouts::MasterCardMessage::SOURCE_MSG_NO%3E9D621D032C.attr preserve=no  public: int {V} 0
      int m_lSOURCE_MSG_NO;
      //## end bmlayouts::MasterCardMessage::SOURCE_MSG_NO%3E9D621D032C.attr

    // Additional Protected Declarations
      //## begin bmlayouts::MasterCardMessage%3E4A56860251.protected preserve=yes
      //## end bmlayouts::MasterCardMessage%3E4A56860251.protected

  private:

    //## Other Operations (specified)
      //## Operation: setElementMaps%3E665EC302DE
      void setElementMaps ();

    // Additional Private Declarations
      //## begin bmlayouts::MasterCardMessage%3E4A56860251.private preserve=yes
      //## end bmlayouts::MasterCardMessage%3E4A56860251.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: NumberOfPDSelements%3E5B9FFF0213
      //## begin bmlayouts::MasterCardMessage::NumberOfPDSelements%3E5B9FFF0213.attr preserve=no  private: int {U} 0
      int m_lNumberOfPDSelements;
      //## end bmlayouts::MasterCardMessage::NumberOfPDSelements%3E5B9FFF0213.attr

    // Additional Implementation Declarations
      //## begin bmlayouts::MasterCardMessage%3E4A56860251.implementation preserve=yes
      vector<string> m_hCurrCodes;
      vector<string>::iterator pCurrCode;
      //## end bmlayouts::MasterCardMessage%3E4A56860251.implementation
};

//## begin bmlayouts::MasterCardMessage%3E4A56860251.postscript preserve=yes
//## end bmlayouts::MasterCardMessage%3E4A56860251.postscript

} // namespace bmlayouts

//## begin module%3E4A5738035B.epilog preserve=yes
#define ADMIN        1644
#define CHARGEBACK   1442
#define FEES         1740
#define PRESENTMENT  1240

using namespace bmlayouts;
//## end module%3E4A5738035B.epilog


#endif
