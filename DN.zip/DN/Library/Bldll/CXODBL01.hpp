//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E314EE8033C.cm preserve=no
//	$Date:   18 Jan 2018 14:02:48  $ $Author:   e1009839  $
//	$Revision:   1.22  $
//## end module%3E314EE8033C.cm

//## begin module%3E314EE8033C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3E314EE8033C.cp

//## Module: CXOSBL01%3E314EE8033C; Package specification
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Bldll\CXODBL01.hpp

#ifndef CXOSBL01_h
#define CXOSBL01_h 1

//## begin module%3E314EE8033C.additionalIncludes preserve=no
//## end module%3E314EE8033C.additionalIncludes

//## begin module%3E314EE8033C.includes preserve=yes
// $Date:   18 Jan 2018 14:02:48  $ $Author:   e1009839  $ $Revision:   1.22  $
//## end module%3E314EE8033C.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%3E314EE8033C.declarations preserve=no
//## end module%3E314EE8033C.declarations

//## begin module%3E314EE8033C.additionalDeclarations preserve=yes
//## end module%3E314EE8033C.additionalDeclarations


//## Modelname: Connex Library::BitMapLayouts_CAT%3E4A483C030D
namespace bmlayouts {
//## begin bmlayouts%3E4A483C030D.initialDeclarations preserve=yes
#define ALP 0
#define AN  1
#define ANS 2
#define _B  3
#define BCD 4
#define NUM 5
#define AMT 6
#define NS  7
#define P   8
#define FLT 9 

#define ExportBufferSize 4108
//## end bmlayouts%3E4A483C030D.initialDeclarations

//## begin bmlayouts::BitMapMessage%3E314E550232.preface preserve=yes
struct Elements
{
   short siDENo;
   short siDESubfield;
   int   iType; //one of the defines above
   char* pszTypeFormat; //check for numeric(1), format(8)
   char* pszLength; //'f' or 'v', length(3)
   char  cSegInd;
   char* pszName;
};
//## end bmlayouts::BitMapMessage%3E314E550232.preface

//## Class: BitMapMessage%3E314E550232
//## Category: Connex Library::BitMapLayouts_CAT%3E4A483C030D
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3EB10E7800DA;reusable::Query { -> F}

class DllExport BitMapMessage : public reusable::Observer  //## Inherits: <unnamed>%3E316567007D
{
  //## begin bmlayouts::BitMapMessage%3E314E550232.initialDeclarations preserve=yes
  //## end bmlayouts::BitMapMessage%3E314E550232.initialDeclarations

  public:
    //## Constructors (generated)
      BitMapMessage();

    //## Destructor (generated)
      virtual ~BitMapMessage();


    //## Other Operations (specified)
      //## Operation: charHex%3EC3AB7A0242
      void charHex (char* psCharData, unsigned char* psHexData, int iLen);

      //## Operation: checkPresence%3FE710FC0203
      virtual char checkPresence (const string& strFieldName)
      {
        //## begin bmlayouts::BitMapMessage::checkPresence%3FE710FC0203.body preserve=yes
         return '*';
        //## end bmlayouts::BitMapMessage::checkPresence%3FE710FC0203.body
      }

      //## Operation: elements%3E3E687D0148
      virtual struct Elements* elements () const
      {
        //## begin bmlayouts::BitMapMessage::elements%3E3E687D0148.body preserve=yes
         return 0;
        //## end bmlayouts::BitMapMessage::elements%3E3E687D0148.body
      }

      //## Operation: deport%3E39787E03A9
      virtual void deport ();

      //## Operation: exportField%408FA0FF0119
      int exportField (Elements *pElement, char *psField, bool bIncludeLen = false, string strFieldID = "");

      //## Operation: getValue%3E4A6CDC0148
      virtual void getValue (char cSegInd, char* hName, string& hData, bool bUpdate = false, void* hSegment = 0);

      //## Operation: hexChar%3EC3AAD90167
      void hexChar (char* psCharData, unsigned char* psHexData, int iLen);

      //## Operation: import%3E35423E0167
      virtual bool import ();

      //## Operation: importField%3E6669D6030D
      int importField (Elements *pElement, char *psField, bool bPutValue = true);

      //## Operation: setBuffer%3F2677C00128
      void setBuffer (char** value, int iLen)
      {
        //## begin bmlayouts::BitMapMessage::setBuffer%3F2677C00128.body preserve=yes
         memcpy(m_pszBuffer, *value, iLen);
        //## end bmlayouts::BitMapMessage::setBuffer%3F2677C00128.body
      }

      //## Operation: setConstraints%3EB109170148
      virtual void setConstraints (reusable::Query& hQuery);

      //## Operation: setMsgType%3EB10F1D00CB
      virtual bool setMsgType (bool bExportMsg = true);

      //## Operation: setValue%3E8DE329001F
      virtual void setValue (char cSegInd, char* hName, string& hData, bool bUpdate = false, void* hSegment = 0);

      //## Operation: testBit%3E68B4850167
      bool testBit (char* bMap, int iBit);

      //## Operation: toBits%3E68BCC10196
      void toBits (char* psCMap, char* psBMap, int iLen);

      //## Operation: update%3E92D26D02AF
      virtual void update (reusable::Subject* pSubject);

      //## Operation: updateFields%3E9ECC47031C
      void updateFields (void* hSegment, char cInd);

      //## Operation: writeHeader%3EB6559803B9
      virtual bool writeHeader (string strFileDate);

      //## Operation: writeTrailer%3EB655C203C8
      virtual bool writeTrailer ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: AddAmount%3F8D4A4801C5
      const bool& getAddAmount () const
      {
        //## begin bmlayouts::BitMapMessage::getAddAmount%3F8D4A4801C5.get preserve=no
        return m_bAddAmount;
        //## end bmlayouts::BitMapMessage::getAddAmount%3F8D4A4801C5.get
      }

      void setAddAmount (const bool& value)
      {
        //## begin bmlayouts::BitMapMessage::setAddAmount%3F8D4A4801C5.set preserve=no
        m_bAddAmount = value;
        //## end bmlayouts::BitMapMessage::setAddAmount%3F8D4A4801C5.set
      }


      //## Attribute: Buffer%3E5B9EB901C5
      const char * getBuffer () const
      {
        //## begin bmlayouts::BitMapMessage::getBuffer%3E5B9EB901C5.get preserve=no
        return m_pszBuffer;
        //## end bmlayouts::BitMapMessage::getBuffer%3E5B9EB901C5.get
      }


      //## Attribute: CheckSumAmount%3EC10AAE0148
      const double& getCheckSumAmount () const
      {
        //## begin bmlayouts::BitMapMessage::getCheckSumAmount%3EC10AAE0148.get preserve=no
        return m_dCheckSumAmount;
        //## end bmlayouts::BitMapMessage::getCheckSumAmount%3EC10AAE0148.get
      }

      void setCheckSumAmount (const double& value)
      {
        //## begin bmlayouts::BitMapMessage::setCheckSumAmount%3EC10AAE0148.set preserve=no
        m_dCheckSumAmount = value;
        //## end bmlayouts::BitMapMessage::setCheckSumAmount%3EC10AAE0148.set
      }


      //## Attribute: FunctionCode%3E5284210148
      const string& getFunctionCode () const
      {
        //## begin bmlayouts::BitMapMessage::getFunctionCode%3E5284210148.get preserve=no
        return m_strFunctionCode;
        //## end bmlayouts::BitMapMessage::getFunctionCode%3E5284210148.get
      }

      void setFunctionCode (const string& value)
      {
        //## begin bmlayouts::BitMapMessage::setFunctionCode%3E5284210148.set preserve=no
        m_strFunctionCode = value;
        //## end bmlayouts::BitMapMessage::setFunctionCode%3E5284210148.set
      }


      //## Attribute: MessageType%3E5283D90242
      const string& getMessageType () const
      {
        //## begin bmlayouts::BitMapMessage::getMessageType%3E5283D90242.get preserve=no
        return m_strMessageType;
        //## end bmlayouts::BitMapMessage::getMessageType%3E5283D90242.get
      }

      void setMessageType (const string& value)
      {
        //## begin bmlayouts::BitMapMessage::setMessageType%3E5283D90242.set preserve=no
        m_strMessageType = value;
        //## end bmlayouts::BitMapMessage::setMessageType%3E5283D90242.set
      }


      //## Attribute: Pos%3E5B9F00000F
      const int& getPos () const
      {
        //## begin bmlayouts::BitMapMessage::getPos%3E5B9F00000F.get preserve=no
        return m_iPos;
        //## end bmlayouts::BitMapMessage::getPos%3E5B9F00000F.get
      }


      //## Attribute: TotalRecs%3EC10AFA01C5
      const int& getTotalRecs () const
      {
        //## begin bmlayouts::BitMapMessage::getTotalRecs%3EC10AFA01C5.get preserve=no
        return m_lTotalRecs;
        //## end bmlayouts::BitMapMessage::getTotalRecs%3EC10AFA01C5.get
      }

      void setTotalRecs (const int& value)
      {
        //## begin bmlayouts::BitMapMessage::setTotalRecs%3EC10AFA01C5.set preserve=no
        m_lTotalRecs = value;
        //## end bmlayouts::BitMapMessage::setTotalRecs%3EC10AFA01C5.set
      }


      //## Attribute: AbsentField%51C80BA60384
      const string& getAbsentField () const
      {
        //## begin bmlayouts::BitMapMessage::getAbsentField%51C80BA60384.get preserve=no
        return m_strAbsentField;
        //## end bmlayouts::BitMapMessage::getAbsentField%51C80BA60384.get
      }


    // Data Members for Class Attributes

      //## Attribute: TraceFile%3F9FE49C0128
      //## begin bmlayouts::BitMapMessage::TraceFile%3F9FE49C0128.attr preserve=no  protected: FILE* {U} NULL
      FILE* hTraceFile;
      //## end bmlayouts::BitMapMessage::TraceFile%3F9FE49C0128.attr

    // Additional Public Declarations
      //## begin bmlayouts::BitMapMessage%3E314E550232.public preserve=yes
      //## end bmlayouts::BitMapMessage%3E314E550232.public

  protected:
    // Data Members for Class Attributes

      //## begin bmlayouts::BitMapMessage::AddAmount%3F8D4A4801C5.attr preserve=no  public: bool {U} false
      bool m_bAddAmount;
      //## end bmlayouts::BitMapMessage::AddAmount%3F8D4A4801C5.attr

      //## begin bmlayouts::BitMapMessage::Buffer%3E5B9EB901C5.attr preserve=no  public: char * {U} 
      char *m_pszBuffer;
      //## end bmlayouts::BitMapMessage::Buffer%3E5B9EB901C5.attr

      //## begin bmlayouts::BitMapMessage::CheckSumAmount%3EC10AAE0148.attr preserve=no  public: double {U} 
      double m_dCheckSumAmount;
      //## end bmlayouts::BitMapMessage::CheckSumAmount%3EC10AAE0148.attr

      //## begin bmlayouts::BitMapMessage::FunctionCode%3E5284210148.attr preserve=no  public: string {U} 
      string m_strFunctionCode;
      //## end bmlayouts::BitMapMessage::FunctionCode%3E5284210148.attr

      //## begin bmlayouts::BitMapMessage::MessageType%3E5283D90242.attr preserve=no  public: string {U} 
      string m_strMessageType;
      //## end bmlayouts::BitMapMessage::MessageType%3E5283D90242.attr

      //## Attribute: NumberOfElements%3E3EBA9D037A
      //## begin bmlayouts::BitMapMessage::NumberOfElements%3E3EBA9D037A.attr preserve=no  protected: int {VA} 0
      int m_lNumberOfElements;
      //## end bmlayouts::BitMapMessage::NumberOfElements%3E3EBA9D037A.attr

      //## begin bmlayouts::BitMapMessage::Pos%3E5B9F00000F.attr preserve=no  public: int {U} 
      int m_iPos;
      //## end bmlayouts::BitMapMessage::Pos%3E5B9F00000F.attr

      //## Attribute: Presence%3E4A6F530186
      //## begin bmlayouts::BitMapMessage::Presence%3E4A6F530186.attr preserve=no  protected: char {U} 
      char m_aPresence[130];
      //## end bmlayouts::BitMapMessage::Presence%3E4A6F530186.attr

      //## begin bmlayouts::BitMapMessage::TotalRecs%3EC10AFA01C5.attr preserve=no  public: int {U} 
      int m_lTotalRecs;
      //## end bmlayouts::BitMapMessage::TotalRecs%3EC10AFA01C5.attr

      //## Attribute: Value%3E5B85610128
      //## begin bmlayouts::BitMapMessage::Value%3E5B85610128.attr preserve=no  protected: string {U} 
      string m_strValue;
      //## end bmlayouts::BitMapMessage::Value%3E5B85610128.attr

      //## begin bmlayouts::BitMapMessage::AbsentField%51C80BA60384.attr preserve=no  public: string {U} 
      string m_strAbsentField;
      //## end bmlayouts::BitMapMessage::AbsentField%51C80BA60384.attr

    // Additional Protected Declarations
      //## begin bmlayouts::BitMapMessage%3E314E550232.protected preserve=yes
      //## end bmlayouts::BitMapMessage%3E314E550232.protected

  private:
    // Additional Private Declarations
      //## begin bmlayouts::BitMapMessage%3E314E550232.private preserve=yes
      //## end bmlayouts::BitMapMessage%3E314E550232.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Element%3E3E68B300AB
      //## begin bmlayouts::BitMapMessage::Element%3E3E68B300AB.attr preserve=no  private: void** {U} 0
      void** m_pElement;
      //## end bmlayouts::BitMapMessage::Element%3E3E68B300AB.attr

      //## Attribute: PrimaryMap%3E316920036B
      //## begin bmlayouts::BitMapMessage::PrimaryMap%3E316920036B.attr preserve=no  private: char {U} 
      char m_cPrimaryMap[9];
      //## end bmlayouts::BitMapMessage::PrimaryMap%3E316920036B.attr

      //## Attribute: SecondaryMap%3E3EC4C4036B
      //## begin bmlayouts::BitMapMessage::SecondaryMap%3E3EC4C4036B.attr preserve=no  private: char {U} 
      char m_cSecondaryMap[9];
      //## end bmlayouts::BitMapMessage::SecondaryMap%3E3EC4C4036B.attr

    // Additional Implementation Declarations
      //## begin bmlayouts::BitMapMessage%3E314E550232.implementation preserve=yes
      unsigned char bits1:8;
      //## end bmlayouts::BitMapMessage%3E314E550232.implementation
};

//## begin bmlayouts::BitMapMessage%3E314E550232.postscript preserve=yes
//## end bmlayouts::BitMapMessage%3E314E550232.postscript

} // namespace bmlayouts

//## begin module%3E314EE8033C.epilog preserve=yes
using namespace bmlayouts;
//## end module%3E314EE8033C.epilog


#endif
