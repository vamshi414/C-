//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E314EEA038A.cm preserve=no
// $Date:   Jul 09 2021 07:57:56  $ $Author:   e5632407  $
// $Revision:   1.40.2.1  $
//## end module%3E314EEA038A.cm

//## begin module%3E314EEA038A.cp preserve=no
// Copyright (c) 1997 - 2012
// FIS
//## end module%3E314EEA038A.cp

//## Module: CXOSBL01%3E314EEA038A; Package body
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Bldll\CXOSBL01.cpp

//## begin module%3E314EEA038A.additionalIncludes preserve=no
//## end module%3E314EEA038A.additionalIncludes

//## begin module%3E314EEA038A.includes preserve=yes
#include "CXODIF03.hpp"
#include "CXODRU03.hpp"
#include "CXODRU37.hpp"
#include "CXODRU40.hpp"
//## end module%3E314EEA038A.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBL01_h
#include "CXODBL01.hpp"
#endif


//## begin module%3E314EEA038A.declarations preserve=no
//## end module%3E314EEA038A.declarations

//## begin module%3E314EEA038A.additionalDeclarations preserve=yes
unsigned char szMask[9] = {0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01};
//## end module%3E314EEA038A.additionalDeclarations


//## Modelname: Connex Library::BitMapLayouts_CAT%3E4A483C030D
namespace bmlayouts {
//## begin bmlayouts%3E4A483C030D.initialDeclarations preserve=yes
//## end bmlayouts%3E4A483C030D.initialDeclarations

// Class bmlayouts::BitMapMessage

BitMapMessage::BitMapMessage()
  //## begin BitMapMessage::BitMapMessage%3E314E550232_const.hasinit preserve=no
      : m_bAddAmount(false),
        m_pElement(0),
        m_lNumberOfElements(0),
        hTraceFile(NULL)
  //## end BitMapMessage::BitMapMessage%3E314E550232_const.hasinit
  //## begin BitMapMessage::BitMapMessage%3E314E550232_const.initialization preserve=yes
  //## end BitMapMessage::BitMapMessage%3E314E550232_const.initialization
{
  //## begin bmlayouts::BitMapMessage::BitMapMessage%3E314E550232_const.body preserve=yes
   m_pszBuffer = new(char [ExportBufferSize]);
  //## end bmlayouts::BitMapMessage::BitMapMessage%3E314E550232_const.body
}


BitMapMessage::~BitMapMessage()
{
  //## begin bmlayouts::BitMapMessage::~BitMapMessage%3E314E550232_dest.body preserve=yes
   delete [] m_pszBuffer;
  //## end bmlayouts::BitMapMessage::~BitMapMessage%3E314E550232_dest.body
}



//## Other Operations (implementation)
void BitMapMessage::charHex (char* psCharData, unsigned char* psHexData, int iLen)
{
  //## begin bmlayouts::BitMapMessage::charHex%3EC3AB7A0242.body preserve=yes
   char Hex[] = {"0123456789ABCDEF"};
   short i, j;
   for (short x = 0; x < iLen; x++)
   {
      i = j = 0;
      for (short y = 0; y < 16; y++)
      {
         if (psCharData[x*2]   == Hex[y]) i = y;
         if (psCharData[x*2+1] == Hex[y]) j = y;
      }
      psHexData[x] = i * 16 + j;
   }
  //## end bmlayouts::BitMapMessage::charHex%3EC3AB7A0242.body
}

void BitMapMessage::deport ()
{
  //## begin bmlayouts::BitMapMessage::deport%3E39787E03A9.body preserve=yes
  //## end bmlayouts::BitMapMessage::deport%3E39787E03A9.body
}

int BitMapMessage::exportField (Elements *pElement, char *psField, bool bIncludeLen, string strFieldID)
{
  //## begin bmlayouts::BitMapMessage::exportField%408FA0FF0119.body preserve=yes
   char   szFormat[10] = {"         "};
   char   szTemp[64];
   int    iDataLength=0;
   int    iPad, iLen;
   size_t index;
   char   *p;
   size_t pos;
   memset(psField, ' ', 16);  // clear next 16 bytes for trace
   // getValue(pElement->cSegInd, pElement->pszName, m_strValue);  // already done
   if (pElement->pszLength[0] == 'f')
      iDataLength = atoi((pElement->pszLength)+1);
   else
      iDataLength = (int)m_strValue.length();
   iPad = 0;
   int iPos = 0;
   if (strFieldID.length() > 0)
   {
      memcpy(psField, strFieldID.c_str(), strFieldID.length());
      iPos += (int)strFieldID.length();
   }
   if (bIncludeLen) // for OCS processing
      iPos += 3;
   switch(pElement->iType)
   {
      case ALP:
      case _B:
         if (pElement->cSegInd == 'F')  // Filler
         {
            iLen = (int)strlen(pElement->pszName);
            if (bIncludeLen)
            {
               snprintf(szTemp,sizeof(szTemp),"%03d",iLen);
               memcpy(&psField[iPos-3],szTemp,3);
            }
            if (iLen > 1)
            {
               memset(&psField[iPos], ' ', iDataLength);
               memcpy(&psField[iPos], pElement->pszName, iLen);
            }
            else
               memset(&psField[iPos], pElement->pszName[0], iDataLength);
         }
         else
         {
            if (bIncludeLen)
            {
               snprintf(szTemp,sizeof(szTemp),"%03d",iDataLength);
               memcpy(&psField[iPos-3],szTemp,3);
            }
            memcpy(&psField[iPos], m_strValue.c_str(), iDataLength);
         }
         break;
      case AN:
      case ANS:
         if (pElement->pszTypeFormat[0] == 'Y')
            if (atoi(m_strValue.data())==0)
               // return 0;
            {  // Make it questionable
               iDataLength = atoi((pElement->pszLength)+1);  // force length for now
               memset(psField, ' ', iDataLength);
               break;
            }
         if ((pElement->pszLength[0] == 'l') && (iDataLength > 0)) // length prefix required
         {
            iPad = (atoi((pElement->pszLength)+1));  // number of bytes
            strcpy(szFormat,"%0xd");
            memcpy(&szFormat[2], (pElement->pszLength)+1, 1);
            snprintf(szTemp,sizeof(szTemp),szFormat,iDataLength);
            memcpy(psField, szTemp, iPad);
            psField+=iPad;
         }
         if (strlen(pElement->pszTypeFormat) > 1 && *((pElement->pszTypeFormat) + 1) != ' ')
         {
            strncpy(szFormat,(pElement->pszTypeFormat) + 1,8);
            p = strchr(szFormat,' ');
            if (p) *p = '\0';
            if (bIncludeLen)
            {
               snprintf(szTemp,sizeof(szTemp),"%03d",iDataLength);
               memcpy(&psField[iPos-3], szTemp, 3);
            }
            snprintf(szTemp,sizeof(szTemp),szFormat,m_strValue.data());
            memcpy(&psField[iPos], szTemp, iDataLength);
         }
         else // 'a' type (actual value-no padding) will come here
         {
            if (bIncludeLen)
            {
               int iLen = iDataLength;
               if (pElement->pszLength[0] == 'v') // add in pad amount before writing out length
                  iLen += (atoi((pElement->pszLength)+1) - iDataLength);
               snprintf(szTemp,sizeof(szTemp),"%03d",iLen);
               memcpy(&psField[iPos-3], szTemp, 3);
            }
            int iValueLength = m_strValue.length();
            memcpy(&psField[iPos], m_strValue.data(), min(iValueLength,iDataLength));
         }
         if (pElement->pszLength[0] == 'v')  // variable length may need padding
         {
            iPad = (atoi((pElement->pszLength)+1) - iDataLength);
            if (iPad > 0)
            {
               if (bIncludeLen && iDataLength == 0)
               {
                  snprintf(szTemp,sizeof(szTemp),"%03d",iPad);
                  memcpy(&psField[iPos-3], szTemp, 3);
               }
               memset(&psField[iDataLength+iPos],' ',iPad);
            }
         }
         break;
     case FLT:
         if (m_strValue.length())
         {
            if (bIncludeLen)
            {
               snprintf(szTemp,sizeof(szTemp),"%03d",iDataLength);
               memcpy(&psField[iPos-3], szTemp, 3);
            }
            pos = m_strValue.find(" ");
            if (pos != string::npos)
               m_strValue.erase(0, pos + 1);
            if (*((pElement->pszTypeFormat) + 1) != ' ')
            {
               strncpy(szFormat,(pElement->pszTypeFormat) + 1,8);
               p = strchr(szFormat,' ');
               if (p) *p = '\0';
               index = m_strValue.find_first_of('.');
               if (index != string::npos)  // delete '.'
               m_strValue.erase(index,1);
               snprintf(szTemp,sizeof(szTemp),szFormat,atof(m_strValue.c_str()));
            }
            else
               snprintf(szTemp,sizeof(szTemp),"%0.0f",(double)atof(m_strValue.c_str()));
            memcpy(&psField[iPos], szTemp, iDataLength);
       }
         break;
      case NUM:
      case AMT:
         char t[PERCENTD];
         snprintf(t,sizeof(t),"%d",pElement->iType);
         Trace::put(t);
         if (pElement->pszTypeFormat[0] == 'Y')
            if (m_strValue.empty())
            {
               iDataLength = atoi((pElement->pszLength)+1);  // force length for now
               memset(psField, ' ', iDataLength);
               break;
            }
         if (pElement->iType == AMT)
         {
            Trace::put("num field");
            Trace::put(m_strValue.c_str());
            pos = m_strValue.find(" ");
            snprintf(t,sizeof(t),"%d",pos);
            Trace::put(t);
            if (pos != string::npos)
               m_strValue.erase(0,pos + 1);
         }
         if (bIncludeLen)
         {
            snprintf(szTemp,sizeof(szTemp),"%03d",iDataLength);
            memcpy(&psField[iPos-3], szTemp, 3);
         }
         if (*((pElement->pszTypeFormat) + 1) != ' ')
         {
            strncpy(szFormat,(pElement->pszTypeFormat) + 1,8);
            p = strchr(szFormat,' ');
            if (p) *p = '\0';
            index = m_strValue.find_first_of('.');
            if (index != string::npos)  // delete '.'
               m_strValue.erase(index,1);
            snprintf(szTemp,sizeof(szTemp),szFormat,atoi(m_strValue.c_str()));
         }
         else
            snprintf(szTemp,sizeof(szTemp),"%d",(int)atoi(m_strValue.c_str()));
         memcpy(&psField[iPos], szTemp, iDataLength);
         break;
   }
   // Fields being processed
   if(strcmp(pElement->pszName,"PAN") == 0)
   {
      int iLen = iDataLength;
      size_t pos = m_strValue.find_first_of(" ");
      if(pos != string::npos)
         iLen = pos;
   }
/*   memcpy(szTemp, psField, 16);  szTemp[16] = '\0';
   snprintf(data,sizeof(data),"%04d %c %04d %-24s (%s)\n%12s%s\n",
                 pElement->siDENo,
                 pElement->cSegInd,
                 m_iPos,
                 pElement->pszName,
                 m_strValue.c_str(),
                 " ",
                 szTemp);
   data[300] = '\n';  data[301] = NULL;  // 300 bytes max
   //fprintf(stdout, data);
   Trace::put(data);*/
   if (strFieldID.length() > 0)
      iDataLength += (int)strFieldID.length();
   if (bIncludeLen)
      iDataLength += 3;
   return iDataLength + iPad;
  //## end bmlayouts::BitMapMessage::exportField%408FA0FF0119.body
}

void BitMapMessage::getValue (char cSegInd, char* hName, string& hData, bool bUpdate, void* hSegment)
{
  //## begin bmlayouts::BitMapMessage::getValue%3E4A6CDC0148.body preserve=yes
  //## end bmlayouts::BitMapMessage::getValue%3E4A6CDC0148.body
}

void BitMapMessage::hexChar (char* psCharData, unsigned char* psHexData, int iLen)
{
  //## begin bmlayouts::BitMapMessage::hexChar%3EC3AAD90167.body preserve=yes
   char Hex[] = {"0123456789ABCDEF"};
   for (short x = 0; x < iLen; x++)
   {
      psCharData[(x*2)]   = Hex[psHexData[x] / 16];
      psCharData[(x*2)+1] = Hex[psHexData[x] % 16];
   }
  //## end bmlayouts::BitMapMessage::hexChar%3EC3AAD90167.body
}

bool BitMapMessage::import ()
{
  //## begin bmlayouts::BitMapMessage::import%3E35423E0167.body preserve=yes
   return true;
  //## end bmlayouts::BitMapMessage::import%3E35423E0167.body
}

int BitMapMessage::importField (Elements *pElement, char *psField, bool bPutValue)
{
  //## begin bmlayouts::BitMapMessage::importField%3E6669D6030D.body preserve=yes
   int    iDataLength=0, iPad=0;
   char   szTemp[32], data[1000];
   iDataLength = atoi((pElement->pszLength)+1);
   if ((pElement->pszLength[0] == 'l') && (iDataLength > 0)) // length prefix present
   {
      iPad = iDataLength;  // number of length bytes
      memcpy(szTemp, psField, iPad);
      szTemp[iPad] = '\0';
      psField+=iPad;
      iDataLength = atoi(szTemp);
   }
   if (pElement->pszLength[0] != 's')  // no special length processing
   {
      memcpy(data, psField, iDataLength);
      data[iDataLength] = '\0';
      m_strValue = data;
   }
   if (bPutValue)
      if (pElement->cSegInd != 'F' && pElement->cSegInd != 'M')
      {
         if(strcmp(pElement->pszName,"PAN") == 0)
         {
            int iLen = iDataLength;
            size_t pos = m_strValue.find_first_of(" ");
            if(pos != string::npos)
               iLen = pos;
            if(m_strValue.length() > 0 && (m_strValue[0] < '1' || m_strValue[0] > '9'))
               KeyRing::instance()->detokenize(m_strValue);
         }
         setValue(pElement->cSegInd, pElement->pszName, m_strValue);
      }
   // Fields being processed
   memcpy(szTemp, psField, 16);  szTemp[16] = '\0';
   snprintf(data,sizeof(data),"%04d %c %04d %-24s (%s)\n%12s%s\n",
                 pElement->siDENo,
                 pElement->cSegInd,
                 m_iPos,
                 pElement->pszName,
                 m_strValue.c_str(),
                 " ",
                 szTemp);
   data[300] = '\n';  data[301] = NULL;  // 300 bytes max
   //fprintf(stdout, data);
   Trace::put(data);
   if (hTraceFile)
      fprintf(hTraceFile, data);
   return iDataLength+iPad;
  //## end bmlayouts::BitMapMessage::importField%3E6669D6030D.body
}

void BitMapMessage::setConstraints (reusable::Query& hQuery)
{
  //## begin bmlayouts::BitMapMessage::setConstraints%3EB109170148.body preserve=yes
  //## end bmlayouts::BitMapMessage::setConstraints%3EB109170148.body
}

bool BitMapMessage::setMsgType (bool bExportMsg)
{
  //## begin bmlayouts::BitMapMessage::setMsgType%3EB10F1D00CB.body preserve=yes
   return true;
  //## end bmlayouts::BitMapMessage::setMsgType%3EB10F1D00CB.body
}

void BitMapMessage::setValue (char cSegInd, char* hName, string& hData, bool bUpdate, void* hSegment)
{
  //## begin bmlayouts::BitMapMessage::setValue%3E8DE329001F.body preserve=yes
  //## end bmlayouts::BitMapMessage::setValue%3E8DE329001F.body
}

bool BitMapMessage::testBit (char* bMap, int iBit)
{
  //## begin bmlayouts::BitMapMessage::testBit%3E68B4850167.body preserve=yes
   short  byte, bitno;
   byte  = (iBit-1) / 8;
   bitno = (iBit-1) % 8;
   if (bMap[byte] & szMask[bitno])
      return true;
   return false;
  //## end bmlayouts::BitMapMessage::testBit%3E68B4850167.body
}

void BitMapMessage::toBits (char* psCMap, char* psBMap, int iLen)
{
  //## begin bmlayouts::BitMapMessage::toBits%3E68BCC10196.body preserve=yes
   char byte[8];
   unsigned char x;
   unsigned char hex[] = { 0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01 };
   for (short i=0; i < iLen; i++)
   {
      x = 0;
      memcpy(byte, &psCMap[(i*8)+1], 8);   // Byte 0 ignored
      for (short j=0; j < 8; j++)
         if (byte[j] == 'M') x += hex[j];  // Check for Mandatory field
      psBMap[i] = x;
   }
   return;
  //## end bmlayouts::BitMapMessage::toBits%3E68BCC10196.body
}

void BitMapMessage::update (reusable::Subject* pSubject)
{
  //## begin bmlayouts::BitMapMessage::update%3E92D26D02AF.body preserve=yes
  //## end bmlayouts::BitMapMessage::update%3E92D26D02AF.body
}

void BitMapMessage::updateFields (void* hSegment, char cInd)
{
  //## begin bmlayouts::BitMapMessage::updateFields%3E9ECC47031C.body preserve=yes
  //## end bmlayouts::BitMapMessage::updateFields%3E9ECC47031C.body
}

bool BitMapMessage::writeHeader (string strFileDate)
{
  //## begin bmlayouts::BitMapMessage::writeHeader%3EB6559803B9.body preserve=yes
   return true;
  //## end bmlayouts::BitMapMessage::writeHeader%3EB6559803B9.body
}

bool BitMapMessage::writeTrailer ()
{
  //## begin bmlayouts::BitMapMessage::writeTrailer%3EB655C203C8.body preserve=yes
   return true;
  //## end bmlayouts::BitMapMessage::writeTrailer%3EB655C203C8.body
}

// Additional Declarations
  //## begin bmlayouts::BitMapMessage%3E314E550232.declarations preserve=yes
  //## end bmlayouts::BitMapMessage%3E314E550232.declarations

} // namespace bmlayouts

//## begin module%3E314EEA038A.epilog preserve=yes
//## end module%3E314EEA038A.epilog
