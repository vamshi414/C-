//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E4A4F9C0000.cm preserve=no
//	$Date:   18 Jan 2018 14:02:50  $ $Author:   e1009839  $ $Revision:   1.32.1.0  $
//## end module%3E4A4F9C0000.cm

//## begin module%3E4A4F9C0000.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3E4A4F9C0000.cp

//## Module: CXOSBL02%3E4A4F9C0000; Package specification
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Source file: C:\bV02.4B.R009\Build\ConnexPlatform\Server\Library\Bldll\CXODBL02.hpp

#ifndef CXOSBL02_h
#define CXOSBL02_h 1

//## begin module%3E4A4F9C0000.additionalIncludes preserve=no
//## end module%3E4A4F9C0000.additionalIncludes

//## begin module%3E4A4F9C0000.includes preserve=yes
// $Date:   18 Jan 2018 14:02:50  $ $Author:   e1009839  $ $Revision:   1.32.1.0  $
#include <set>
//## end module%3E4A4F9C0000.includes

#ifndef CXOSBL01_h
#include "CXODBL01.hpp"
#endif
//## begin module%3E4A4F9C0000.declarations preserve=no
//## end module%3E4A4F9C0000.declarations

//## begin module%3E4A4F9C0000.additionalDeclarations preserve=yes
//## end module%3E4A4F9C0000.additionalDeclarations


//## Modelname: Connex Library::BitMapLayouts_CAT%3E4A483C030D
namespace bmlayouts {
//## begin bmlayouts%3E4A483C030D.initialDeclarations preserve=yes
//## end bmlayouts%3E4A483C030D.initialDeclarations

//## begin bmlayouts::VisaMessage%3E4A4EA0038A.preface preserve=yes
//## end bmlayouts::VisaMessage%3E4A4EA0038A.preface

//## Class: VisaMessage%3E4A4EA0038A
//## Category: Connex Library::BitMapLayouts_CAT%3E4A483C030D
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport VisaMessage : public BitMapMessage  //## Inherits: <unnamed>%3E92D693038A
{
  //## begin bmlayouts::VisaMessage%3E4A4EA0038A.initialDeclarations preserve=yes
  //## end bmlayouts::VisaMessage%3E4A4EA0038A.initialDeclarations

  public:
    //## Constructors (generated)
      VisaMessage();

    //## Destructor (generated)
      virtual ~VisaMessage();


    //## Other Operations (specified)
      //## Operation: checkPresence%3FE7130303D8
      virtual char checkPresence (const string& strFieldName);

      //## Operation: elements%3E4A5094032C
      struct Elements* elements () const;

      //## Operation: deport%3E68BF570242
      virtual void deport ();

      //## Operation: import%3E68BF5D01B5
      virtual bool import ();

      //## Operation: secElements%3E68C6E20157
      struct Elements* secElements ();

      //## Operation: unwrapField%3E8C68F002BF
      virtual int unwrapField (Elements *pZeroElement);

      //## Operation: update%3E92D36C03A9
      virtual void update (Subject* pSubject);

      //## Operation: wrapField%3E8C4C1300FA
      virtual int wrapField (Elements *pZeroElement);

      //## Operation: getCountryCodeISO2%44D2CA770089
      virtual bool getCountryCodeISO2 (const string& strCountryCodeISO3, string& strCountryCodeISO2);

      //## Operation: getGenericValue%4648252B0367
      virtual bool getGenericValue (const string& strType, const string& strFromValue, string& strToValue);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ADDITIONAL_DATA%3EFC5D5602CE
      const string& getADDITIONAL_DATA () const
      {
        //## begin bmlayouts::VisaMessage::getADDITIONAL_DATA%3EFC5D5602CE.get preserve=no
        return m_strADDITIONAL_DATA;
        //## end bmlayouts::VisaMessage::getADDITIONAL_DATA%3EFC5D5602CE.get
      }


      //## Attribute: REASON_CODE%412B2BA403B9
      const string& getREASON_CODE () const
      {
        //## begin bmlayouts::VisaMessage::getREASON_CODE%412B2BA403B9.get preserve=no
        return m_strREASON_CODE;
        //## end bmlayouts::VisaMessage::getREASON_CODE%412B2BA403B9.get
      }


      //## Attribute: AdtlTraceData%400ED6F9000F
      const string& getAdtlTraceData () const
      {
        //## begin bmlayouts::VisaMessage::getAdtlTraceData%400ED6F9000F.get preserve=no
        return m_strAdtlTraceData;
        //## end bmlayouts::VisaMessage::getAdtlTraceData%400ED6F9000F.get
      }


      //## Attribute: POSEntryCode%3FFC171400BB
      const string& getPOSEntryCode () const
      {
        //## begin bmlayouts::VisaMessage::getPOSEntryCode%3FFC171400BB.get preserve=no
        return m_strPOSEntryCode;
        //## end bmlayouts::VisaMessage::getPOSEntryCode%3FFC171400BB.get
      }


      //## Attribute: SUPPORT_INFO%400410F502DE
      const string& getSUPPORT_INFO () const
      {
        //## begin bmlayouts::VisaMessage::getSUPPORT_INFO%400410F502DE.get preserve=no
        return m_strSUPPORT_INFO;
        //## end bmlayouts::VisaMessage::getSUPPORT_INFO%400410F502DE.get
      }


      //## Attribute: SurChargeInd%499030D301E7
      const string& getSurChargeInd () const
      {
        //## begin bmlayouts::VisaMessage::getSurChargeInd%499030D301E7.get preserve=no
        return m_strSurChargeInd;
        //## end bmlayouts::VisaMessage::getSurChargeInd%499030D301E7.get
      }


      //## Attribute: AmountSurcharge%499030F8030C
      const string& getAmountSurcharge () const
      {
        //## begin bmlayouts::VisaMessage::getAmountSurcharge%499030F8030C.get preserve=no
        return m_strAmountSurcharge;
        //## end bmlayouts::VisaMessage::getAmountSurcharge%499030F8030C.get
      }


      //## Attribute: AMT_ADJUSTMENT%4998E7E50218
      const double& getAMT_ADJUSTMENT () const
      {
        //## begin bmlayouts::VisaMessage::getAMT_ADJUSTMENT%4998E7E50218.get preserve=no
        return m_dAMT_ADJUSTMENT;
        //## end bmlayouts::VisaMessage::getAMT_ADJUSTMENT%4998E7E50218.get
      }


    // Additional Public Declarations
      //## begin bmlayouts::VisaMessage%3E4A4EA0038A.public preserve=yes
      //## end bmlayouts::VisaMessage%3E4A4EA0038A.public

  protected:
    // Data Members for Class Attributes

      //## begin bmlayouts::VisaMessage::ADDITIONAL_DATA%3EFC5D5602CE.attr preserve=no  public: string {V} 
      string m_strADDITIONAL_DATA;
      //## end bmlayouts::VisaMessage::ADDITIONAL_DATA%3EFC5D5602CE.attr

      //## begin bmlayouts::VisaMessage::REASON_CODE%412B2BA403B9.attr preserve=no  public: string {U} 
      string m_strREASON_CODE;
      //## end bmlayouts::VisaMessage::REASON_CODE%412B2BA403B9.attr

      //## begin bmlayouts::VisaMessage::AdtlTraceData%400ED6F9000F.attr preserve=no  public: string {U} 
      string m_strAdtlTraceData;
      //## end bmlayouts::VisaMessage::AdtlTraceData%400ED6F9000F.attr

      //## begin bmlayouts::VisaMessage::POSEntryCode%3FFC171400BB.attr preserve=no  public: string {U} 
      string m_strPOSEntryCode;
      //## end bmlayouts::VisaMessage::POSEntryCode%3FFC171400BB.attr

      //## Attribute: SecPresence%3E68CA57034B
      //## begin bmlayouts::VisaMessage::SecPresence%3E68CA57034B.attr preserve=no  protected: char {U} 
      char m_aSecPresence[410];
      //## end bmlayouts::VisaMessage::SecPresence%3E68CA57034B.attr

      //## begin bmlayouts::VisaMessage::SUPPORT_INFO%400410F502DE.attr preserve=no  public: string {U} 
      string m_strSUPPORT_INFO;
      //## end bmlayouts::VisaMessage::SUPPORT_INFO%400410F502DE.attr

      //## begin bmlayouts::VisaMessage::SurChargeInd%499030D301E7.attr preserve=no  public: string {U} 
      string m_strSurChargeInd;
      //## end bmlayouts::VisaMessage::SurChargeInd%499030D301E7.attr

      //## begin bmlayouts::VisaMessage::AmountSurcharge%499030F8030C.attr preserve=no  public: string {U} 
      string m_strAmountSurcharge;
      //## end bmlayouts::VisaMessage::AmountSurcharge%499030F8030C.attr

    // Additional Protected Declarations
      //## begin bmlayouts::VisaMessage%3E4A4EA0038A.protected preserve=yes
      //## end bmlayouts::VisaMessage%3E4A4EA0038A.protected

  private:

    //## Other Operations (specified)
      //## Operation: setElementMaps%3E68BF66005D
      void setElementMaps ();

    // Additional Private Declarations
      //## begin bmlayouts::VisaMessage%3E4A4EA0038A.private preserve=yes
      //## end bmlayouts::VisaMessage%3E4A4EA0038A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: AdtlDataPrivate%4002AD5903B9
      //## begin bmlayouts::VisaMessage::AdtlDataPrivate%4002AD5903B9.attr preserve=no  private: char {U} 
      char m_aAdtlDataPrivate[24];
      //## end bmlayouts::VisaMessage::AdtlDataPrivate%4002AD5903B9.attr

      //## Attribute: Bit106_DATA%401668D5000F
      //## begin bmlayouts::VisaMessage::Bit106_DATA%401668D5000F.attr preserve=no  private: string {U} 
      string m_strBit106_DATA;
      //## end bmlayouts::VisaMessage::Bit106_DATA%401668D5000F.attr

      //## Attribute: LargePrivateData%4002ADAB03A9
      //## begin bmlayouts::VisaMessage::LargePrivateData%4002ADAB03A9.attr preserve=no  private: char {U} 
      char m_aLargePrivateData[9];
      //## end bmlayouts::VisaMessage::LargePrivateData%4002ADAB03A9.attr

      //## Attribute: NonReqBits%3FF964C200CB
      //## begin bmlayouts::VisaMessage::NonReqBits%3FF964C200CB.attr preserve=no  private: set<string, less<string> > {U} 
      set<string, less<string> > m_hNonReqBits;
      //## end bmlayouts::VisaMessage::NonReqBits%3FF964C200CB.attr

      //## Attribute: NumberOfSecElements%3E68CA57031C
      //## begin bmlayouts::VisaMessage::NumberOfSecElements%3E68CA57031C.attr preserve=no  private: int {U} 0
      int m_lNumberOfSecElements;
      //## end bmlayouts::VisaMessage::NumberOfSecElements%3E68CA57031C.attr

      //## Attribute: ReferenceData%4002AD8900BB
      //## begin bmlayouts::VisaMessage::ReferenceData%4002AD8900BB.attr preserve=no  private: char {U} 
      char m_aReferenceData[13];
      //## end bmlayouts::VisaMessage::ReferenceData%4002AD8900BB.attr

      //## Attribute: RequestType%3FF961C300EA
      //## begin bmlayouts::VisaMessage::RequestType%3FF961C300EA.attr preserve=no  private: string {U} 
      string m_strRequestType;
      //## end bmlayouts::VisaMessage::RequestType%3FF961C300EA.attr

      //## begin bmlayouts::VisaMessage::AMT_ADJUSTMENT%4998E7E50218.attr preserve=no  public: double {U} 0
      double m_dAMT_ADJUSTMENT;
      //## end bmlayouts::VisaMessage::AMT_ADJUSTMENT%4998E7E50218.attr

    // Additional Implementation Declarations
      //## begin bmlayouts::VisaMessage%3E4A4EA0038A.implementation preserve=yes
      //## end bmlayouts::VisaMessage%3E4A4EA0038A.implementation

};

//## begin bmlayouts::VisaMessage%3E4A4EA0038A.postscript preserve=yes
//## end bmlayouts::VisaMessage%3E4A4EA0038A.postscript

} // namespace bmlayouts

//## begin module%3E4A4F9C0000.epilog preserve=yes
using namespace bmlayouts;
//## end module%3E4A4F9C0000.epilog


#endif
