//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4059AF89007D.cm preserve=no
//	$Date:   18 Jan 2018 14:03:06  $ $Author:   e1009839  $ $Revision:   1.15  $
//## end module%4059AF89007D.cm

//## begin module%4059AF89007D.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4059AF89007D.cp

//## Module: CXOSBL06%4059AF89007D; Package body
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bldll\CXOSBL06.cpp

//## begin module%4059AF89007D.additionalIncludes preserve=no
//## end module%4059AF89007D.additionalIncludes

//## begin module%4059AF89007D.includes preserve=yes
// $Date:   18 Jan 2018 14:03:06  $ $Author:   e1009839  $ $Revision:   1.15  $
//#include "CXODBL07.hpp"  // Mandatory field arrays
#include "CXODIF03.hpp"
//## end module%4059AF89007D.includes

#ifndef CXOSBL06_h
#include "CXODBL06.hpp"
#endif
//## begin module%4059AF89007D.declarations preserve=no
//## end module%4059AF89007D.declarations

//## begin module%4059AF89007D.additionalDeclarations preserve=yes
/*
  TYPE CODES: 
    C = CASE SEGMENT
    U = CASE UNIQUE SEGMENT
    P = PHASE SEGMENT
    H = PHASE UNIQUE SEGMENT
    N = NATIONAL NETWORKS SEGMENT
    D = FRAUD SEGMENT
    R = FRAUD UNIQUE SEGMENT
    L = CARDHOLDER INFORMATION SEGMENT
    F = FILLER 
    M = MEMBER VARIABLE REQUIRED
*/

//## end module%4059AF89007D.additionalDeclarations


//## Modelname: Connex Library::BitMapLayouts_CAT%3E4A483C030D
namespace bmlayouts {
//## begin bmlayouts%3E4A483C030D.initialDeclarations preserve=yes
//## end bmlayouts%3E4A483C030D.initialDeclarations

// Class bmlayouts::OCSMessage 

OCSMessage::OCSMessage()
  //## begin OCSMessage::OCSMessage%4059AEA40271_const.hasinit preserve=no
  //## end OCSMessage::OCSMessage%4059AEA40271_const.hasinit
  //## begin OCSMessage::OCSMessage%4059AEA40271_const.initialization preserve=yes
  //## end OCSMessage::OCSMessage%4059AEA40271_const.initialization
{
  //## begin bmlayouts::OCSMessage::OCSMessage%4059AEA40271_const.body preserve=yes
   memcpy(m_sID,"BL06",4);
  //## end bmlayouts::OCSMessage::OCSMessage%4059AEA40271_const.body
}


OCSMessage::~OCSMessage()
{
  //## begin bmlayouts::OCSMessage::~OCSMessage%4059AEA40271_dest.body preserve=yes
  //## end bmlayouts::OCSMessage::~OCSMessage%4059AEA40271_dest.body
}



//## Other Operations (implementation)
void OCSMessage::deport ()
{
  //## begin bmlayouts::OCSMessage::deport%4059B0830138.body preserve=yes
   m_iPos=3;
   memset(m_pszBuffer, ' ', ExportBufferSize - 1);
   m_pszBuffer[ExportBufferSize - 1] = '\0';
   m_strMember.erase();

   setElementMaps();  // Set the regular element maps
   Trace::put("before open");
   Trace::put(m_strMember.data());

   return;
  //## end bmlayouts::OCSMessage::deport%4059B0830138.body
}

char OCSMessage::getCurrencyExp (const string& strCurrencyCode)
{
  //## begin bmlayouts::OCSMessage::getCurrencyExp%407ECAE200EA.body preserve=yes
   return ' ';
  //## end bmlayouts::OCSMessage::getCurrencyExp%407ECAE200EA.body
}

bool OCSMessage::import ()
{
  //## begin bmlayouts::OCSMessage::import%4059B0830148.body preserve=yes
   return true;
  //## end bmlayouts::OCSMessage::import%4059B0830148.body
}

void OCSMessage::setElementMaps ()
{
  //## begin bmlayouts::OCSMessage::setElementMaps%4059B0830157.body preserve=yes
   Trace::put("setElementMaps");
   if (m_strCardScheme == "04")
   {
      switch (atoi(m_strMessageType.substr(0,2).c_str()))
      {
#ifdef MVS
         case 05: m_strMember = "VNTTC05"; break;
         case 10: m_strMember = "VNTTC10"; break;
         case 15: m_strMember = "VNTTC15"; break;
         case 20: m_strMember = "VNTTC20"; break;
         case 38: m_strMember = "VNTTC38"; break;
         case 40: m_strMember = "VNTTC40"; break;
         case 51: m_strMember = "VNTTC51"; break;
#else
         case 05: m_strMember = "CXOXV05"; break;
         case 10: m_strMember = "CXOXV10"; break;
         case 15: m_strMember = "CXOXV15"; break;
         case 20: m_strMember = "CXOXV20"; break;
         case 38: m_strMember = "CXOXV38"; break;
         case 40: m_strMember = "CXOXV40"; break;
         case 51: m_strMember = "CXOXV51"; break;
#endif

      }
   }
   if (m_strCardScheme == "18")
   {
      switch (atoi(m_strMessageType.substr(0,2).c_str()))
      {
#ifdef MVS
         case 05: m_strMember = "DNATC05"; break;
         case 15: m_strMember = "DNATC15"; break;
         case 38: m_strMember = "DNATC38"; break;
         case 51: m_strMember = "DNATC51"; break;
#else
         case 05: m_strMember = "CXOXD05"; break;
         case 15: m_strMember = "CXOXD15"; break;
         case 38: m_strMember = "CXOXD38"; break;
         case 51: m_strMember = "CXOXD51"; break;
#endif

      }
   }
   else if (m_strCardScheme == "XX")
   {
      switch (atoi(m_strMessageType.substr(0, 2).c_str()))
      {
#ifdef MVS
      case 05: m_strMember = "GENTC05"; break;
      case 15: m_strMember = "GENTC15"; break;
      case 38: m_strMember = "GENTC38"; break;
      case 51: m_strMember = "GENTC51"; break;
#else
      case 05: m_strMember = "CXOXG05"; break;
      case 15: m_strMember = "CXOXG15"; break;
      case 38: m_strMember = "CXOXG38"; break;
      case 51: m_strMember = "CXOXG51"; break;
#endif

      }
   }
   else if (m_strCardScheme == "99")
   {
      switch (atoi(m_strMessageType.substr(0, 2).c_str()))
      {
#ifdef MVS
      case 05: m_strMember = "EHBTC05"; break;
      case 15: m_strMember = "EHBTC15"; break;
      case 38: m_strMember = "EHBTC38"; break;
      case 51: m_strMember = "EHBTC51"; break;
#else
      case 05: m_strMember = "CXOXE05"; break;
      case 15: m_strMember = "CXOXE15"; break;
      case 38: m_strMember = "CXOXE38"; break;
      case 51: m_strMember = "CXOXE51"; break;
#endif

      }
   }
   else if (m_strCardScheme == "05")
   {
      Trace::put("MCI");
      switch (atoi(m_strMessageType.c_str()))
      {
#ifdef MVS
         case 1240: 
            switch (atoi(m_strFunctionCode.c_str()))
            {
               case 200: m_strMember = "MCIPRM"; break;
               case 205: m_strMember = "MCIPRM2"; break;
            }
            break;
         case 1442: m_strMember = "MCICHB"; break;
         case 1644: 
            switch (atoi(m_strFunctionCode.c_str()))
            {
               case 603: m_strMember = "MCIRR"; break;
            }
            break;
         case 1740: 
            if ( m_strReasonCode == "7614")
               m_strMember = "MCIFEEA";  
            else
               m_strMember = "MCIFEE";
            break; 
#else
         case 1240: 
            switch (atoi(m_strFunctionCode.c_str()))
            {
               case 200: m_strMember = "CXOXMPRM"; break;
               case 205: m_strMember = "CXOXMPR2"; break;
            }
            break;
         case 1442: m_strMember = "CXOXMCHB"; break;
         case 1644: 
            switch (atoi(m_strFunctionCode.c_str()))
            {
               case 603: m_strMember = "CXOXMRR"; break;
            }
            break;
         case 1740: 
            if ( m_strReasonCode == "7614")
               m_strMember = "CXOXMFEA";  
            else
               m_strMember = "CXOXMFEE";
            break; 
#endif
      }
  }

   Trace::put(m_strMember.data());
   memcpy(m_pszBuffer, m_strRecordType.data(), m_strRecordType.length());
  //## end bmlayouts::OCSMessage::setElementMaps%4059B0830157.body
}

void OCSMessage::update (Subject* pSubject)
{
  //## begin bmlayouts::OCSMessage::update%4086CA9802BF.body preserve=yes
  //## end bmlayouts::OCSMessage::update%4086CA9802BF.body
}

void OCSMessage::writeField (const string& strFieldID, string& hData, int iType, char* pLength, char* pFormat, char* pName)
{
  //## begin bmlayouts::OCSMessage::writeField%409157740242.body preserve=yes
   Trace::put("writeField");
   struct Elements pSpecialElement;
   m_strValue.erase();
   m_strValue = hData;
   pSpecialElement.iType = iType;
   pSpecialElement.pszLength = pLength;
   pSpecialElement.pszName = pName;
   string strTemp(pFormat);
   if (pFormat[0] == '%')
      strTemp.insert(0, " ", 1);
   pSpecialElement.pszTypeFormat = (char*)strTemp.data();
   if (strFieldID == "000220" && m_strRecordType == "M  ")  // adjustment amount
      m_bAddAmount = true;
   if (strFieldID == "000030" && m_strRecordType == "VAD") 
   {
      size_t pos = m_strValue.find("\r");
      while (pos != string::npos)
      {
         m_strValue.erase(pos,2);
         pos = m_strValue.find("\r");  
      }
   }
      // Export field id, length and value
   m_iPos += exportField(&pSpecialElement, &m_pszBuffer[m_iPos], true, strFieldID); // Process regular mandatory fields
   Trace::put(m_pszBuffer);
  //## end bmlayouts::OCSMessage::writeField%409157740242.body
}

// Additional Declarations
  //## begin bmlayouts::OCSMessage%4059AEA40271.declarations preserve=yes
  //## end bmlayouts::OCSMessage%4059AEA40271.declarations

} // namespace bmlayouts

//## begin module%4059AF89007D.epilog preserve=yes
//## end module%4059AF89007D.epilog
