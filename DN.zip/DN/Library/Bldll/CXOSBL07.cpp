//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%517E45E501D5.cm preserve=no
//	$Date:   18 Jan 2018 14:03:10  $ $Author:   e1009839  $ $Revision:   1.5  $
//## end module%517E45E501D5.cm

//## begin module%517E45E501D5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	181
//## end module%517E45E501D5.cp

//## Module: CXOSBL07%517E45E501D5; Package body
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Source file: C:\V02.3B.R009\Build\ConnexPlatform\Server\Library\Bldll\CXOSBL07.cpp

//## begin module%517E45E501D5.additionalIncludes preserve=no
//## end module%517E45E501D5.additionalIncludes

//## begin module%517E45E501D5.includes preserve=yes
#include "CXODBL08.hpp"
#include "CXODIF03.hpp"
#include <set>
//## end module%517E45E501D5.includes

#ifndef CXOSDB24_h
#include "CXODDB24.hpp"
#endif
#ifndef CXOSBL07_h
#include "CXODBL07.hpp"
#endif


//## begin module%517E45E501D5.declarations preserve=no
//## end module%517E45E501D5.declarations

//## begin module%517E45E501D5.additionalDeclarations preserve=yes
/*
  TYPE CODES: 
    C = CASE SEGMENT
    U = CASE UNIQUE SEGMENT
    P = PHASE SEGMENT
    H = PHASE UNIQUE SEGMENT
    N = NATIONAL NETWORKS SEGMENT
    Y = PAYMENT SEGMENT
    A = PRE AUTH SEGMENT
    F = FILLER 
    M = MEMBER VARIABLE REQUIRED    
*/
#define ELEMENTS 36
Elements IPMMessage_Elements[ELEMENTS + 1] =
{     
     2, 1,AN  ,"Y        ","l2  ",'C',"PAN",
     3, 1,AN  ,"         ","v6  ",'U',"PROCESS_CODE",
     4, 1,AMT ," %012d   ","f12 ",'P',"AMT_ADJUSTMENT",
    12, 1,AN  ,"         ","f12 ",'C',"TSTAMP_LOCAL",  // LAST 12 BYTES
    22, 1,AN  ,"         ","v1  ",'U',"CARD_INP_CAP_IND",
    22, 2,AN  ,"         ","v1  ",'U',"CARDH_AUTH_CAP_IND",
    22, 3,AN  ,"         ","v1  ",'U',"CARD_CAPT_CAP_IND",
    22, 4,AN  ,"         ","v1  ",'U',"TERM_OPER_ENVI_IND",
    22, 5,AN  ,"         ","v1  ",'U',"CARDH_PRESENT_IND",
    22, 6,AN  ,"         ","v1  ",'U',"CARD_PRESENT_IND",
    22, 7,AN  ,"         ","v1  ",'U',"CARD_INP_MODE_IND",
    22, 8,AN  ,"         ","v1  ",'U',"CARDH_AUTHMOD_IND",
    22, 9,AN  ,"         ","v1  ",'U',"CARDH_AUTHENT_IND",
    22,10,AN  ,"         ","v1  ",'U',"CARD_OUT_CAP_IND",
    22,11,AN  ,"         ","v1  ",'U',"TERM_OUT_CAP_IND",
    22,12,AN  ,"         ","v1  ",'U',"PIN_CAPT_CAP_IND",
    24, 1,NUM ," %03d    ","f3  ",'M',"FunctionCode",       
    25, 1,ALP ,"         ","f4  ",'P',"REASON_CODE",  // FIRST 4 BYTES
    26, 1,AN  ,"         ","v4  ",'C',"MERCHANT_CAT_CODE", 
    30, 1,AMT ," %012d   ","f12 ",'C',"AMT_TRAN", 
    30, 2,ALP ,"         ","f12 ",'F',"000000000000", 
    31, 1,ANS ,"         ","l2  ",'N',"ACQ_REF_NO",     
    33, 1,ANS ,"         ","l2  ",'U',"ISS_ICA",
    38, 1,AN  ,"         ","v6  ",'N',"AUTH_ID_RESP",
    42, 1,ANS ,"         ","v15 ",'C',"CARD_ACPT_ID",
    43, 1,ANS ,"         ","l2  ",'C',"CARD_ACPT_NAME", //CARD_ACPT_NAME/LOC/CITY
    48,-1,ANS ,"         ","v999",'C',"ADDITIONAL_DATA",  // Use secondary table
    49, 1,AN  ,"         ","v3  ",'P',"CUR_ADJUSTMENT", //recon amt currency
    54, 1,AN  ,"         ","l3  ",'M',"  ",   //  Account Type           
    63, 1,AN  ,"         ","l3  ",'U',"LIFECYCLE_SUP_IND", 
    71, 1,NUM ," %08d    ","f8  ",'M',"SOURCE_MSG_NO",  // MEMBER VARIABLE
    72, 1,AN  ,"         ","l3  ",'H',"MC_MMT",
    73, 1,AN  ,"         ","v6  ",'U',"DATE_ACTION", // ACTION DATE
	93, 1,ANS ,"         ","l2  ",'U',"ACQ_ICA",
    94, 1,ANS ,"         ","l2  ",'U',"ISS_ICA",
    95, 1,AN  ,"         ","l2  ",'H',"CARD_ISS_REF_DATA",
     0, 1,0   ,"~","~",' ',"~"
};

#define PDS_ELEMENTS 31
Elements IPMMessage_PDS_Elements[PDS_ELEMENTS + 1] =
{     
    23, 1,ANS  ,"         ","v3  ",'U',"TERMINAL_TYPE",
    25, 1,ALP  ,"         ","f7  ",'M',"MsgRevInd", 
    52, 1,ANS  ,"         ","v3  ",'U',"MCI_ECS_LVL_IND",
    58, 1,ANS  ,"         ","v2  ",'E',"TOKEN_ASSURANCE",
    59, 1,ANS  ,"         ","v11 ",'E',"TOKEN_REQUESTOR_ID",
   105, 1,AN   ,"         ","f25 ",'M',"FileType",  
   122, 1,ANS  ,"         ","f1  ",'M',"ProcMode",      
   137, 1,NUM  ," %020d   ","f20 ",'U',"FEE_CNTL_NO", 
   148, 1,AN   ,"         ","f4  ",'F'," ",   
   149, 1,AN   ,"         ","f6  ",'C',"CUR_TRAN",
   158, 1,AN   ,"         ","f12 ",'U',"ACPT_BRAND_CODE",
   165, 1,ANS  ,"         ","f30 ",'H',"SETL_IND", 
   176, 1,ANS  ,"         ","v6  ",'U',"MCI_ASSIGNED_ID",
   181, 1,ANS  ,"         ","v2  ",'Y',"INSTALLMENT_TYPE",
   181, 2,NUM  ,"Y%02d    ","f2  ",'Y',"NUM_INSTALLMENTS",
   181, 3,NUM  ,"Y%05d    ","f5  ",'Y',"ISS_INTER_RATE",
   181, 4,NUM  ,"Y%012d   ","f12 ",'Y',"AMT_FIRST",
   181, 5,NUM  ,"Y%012d   ","f12 ",'Y',"AMT_SUBSEQUENT",
   181, 6,NUM  ,"Y%05d    ","f5  ",'Y',"ANNUAL_PERCNT_RATE",
   181, 7,NUM  ,"Y%012d   ","f12 ",'Y',"F_AMT_INSTALLMENT",
   192, 1,AN   ,"         ","v3  ",'U',"PYMT_TRAN_INIT",
   194, 1,AN   ,"         ","v1  ",'U',"REMOTE_PGM_IND",
   207, 1,AN   ,"         ","v3  ",'U',"PPOL_PGM_DATA",
   210, 1,AN   ,"         ","v2  ",'U',"TRANSIT_TRAN_IND",
   210, 2,AN   ,"         ","v2  ",'U',"TRANSPORT_MODE_IND",
   228, 1,NUM  ," %d      ","f1  ",'H',"DOC_CODE_IND",
   230, 1,NUM  ," %d      ","f1  ",'H',"DOC_CODE_IND",
   262, 1,NUM  ," %d      ","f1  ",'H',"DOC_IND",
   264, 1,AN   ,"         ","f4  ",'U',"ORIG_RETRVL_REAS",
   301, 1,AN   ,"         ","f16 ",'M',"CheckSumAmount",  
   306, 1,AN   ,"         ","f8  ",'M',"TotalRecs",         
     0, 1,0    ,"~","~",' ',"~"
};

#define BLANK_ELEMENTS 1
int iValidBlankDE[BLANK_ELEMENTS] = {54};
set<int> ValidBlankDE (iValidBlankDE, iValidBlankDE + BLANK_ELEMENTS);

#define BLANK_PDS 3
int iValidBlankPDS[BLANK_PDS] = {148, 228, 230};
set<int> ValidBlankPDS (iValidBlankPDS, iValidBlankPDS + BLANK_PDS);

//## end module%517E45E501D5.additionalDeclarations


//## Modelname: Connex Library::BitMapLayouts_CAT%3E4A483C030D
namespace bmlayouts {
//## begin bmlayouts%3E4A483C030D.initialDeclarations preserve=yes
//## end bmlayouts%3E4A483C030D.initialDeclarations

// Class bmlayouts::IPMMessage 

IPMMessage::IPMMessage()
  //## begin IPMMessage::IPMMessage%517E455E002B_const.hasinit preserve=no
      : m_lNumberOfPDSelements(0),
        m_lSOURCE_MSG_NO(0)
  //## end IPMMessage::IPMMessage%517E455E002B_const.hasinit
  //## begin IPMMessage::IPMMessage%517E455E002B_const.initialization preserve=yes
  //## end IPMMessage::IPMMessage%517E455E002B_const.initialization
{
  //## begin bmlayouts::IPMMessage::IPMMessage%517E455E002B_const.body preserve=yes
   m_lNumberOfElements    = ELEMENTS;
   m_lNumberOfPDSelements = PDS_ELEMENTS;
  //## end bmlayouts::IPMMessage::IPMMessage%517E455E002B_const.body
}


IPMMessage::~IPMMessage()
{
  //## begin bmlayouts::IPMMessage::~IPMMessage%517E455E002B_dest.body preserve=yes
  //## end bmlayouts::IPMMessage::~IPMMessage%517E455E002B_dest.body
}



//## Other Operations (implementation)
char IPMMessage::checkPresence (const string& strFieldName)
{
  //## begin bmlayouts::IPMMessage::checkPresence%517E497202F6.body preserve=yes
	return ' ';
  //## end bmlayouts::IPMMessage::checkPresence%517E497202F6.body
}

struct Elements* IPMMessage::elements () const
{
  //## begin bmlayouts::IPMMessage::elements%517E4880011C.body preserve=yes
   return &IPMMessage_Elements[0];
  //## end bmlayouts::IPMMessage::elements%517E4880011C.body
}

void IPMMessage::deport ()
{
  //## begin bmlayouts::IPMMessage::deport%517E48880262.body preserve=yes
   struct Elements* ppszElements    = elements();
   struct Elements* ppszPDSelements = PDSelements();
   unsigned char bytes[34];
   char szTemp[32], aPresenceMap[130], szFieldID[5] = {"    "};
   string strFieldID;
   
   memset(m_pszBuffer, ' ', ExportBufferSize - 1);
   m_pszBuffer[ExportBufferSize - 1] = '\0';   
   memcpy(m_pszBuffer,     m_strMessageType.data(),  4);
   m_strAbsentField.erase();
   int l = strlen(m_pszBuffer);
   m_iPos= 20; // Skip space (16 bytes) for BitMap and continue with moving mandatory fields 
   memset(aPresenceMap, ' ', sizeof(aPresenceMap));
   memset(m_aPresence, ' ', sizeof(m_aPresence));
   memset(m_aPDSpresence, ' ', sizeof(m_aPDSpresence));
   int iPDSLen=0;
   int iDE48Pos;

   setElementMaps();
   for (int i = 0; i < m_lNumberOfElements; i++)
   {
      if (m_aPresence[ppszElements[i].siDENo] == 'M' || m_aPresence[ppszElements[i].siDENo] == 'C')
      {
         if (ppszElements[i].siDESubfield < 0)
         {
            iDE48Pos = m_iPos;
            m_iPos += 3;
            for (int j=0; j < m_lNumberOfPDSelements; j++)
            {
               if (m_aPDSpresence[ppszPDSelements[j].siDENo] == 'M' || m_aPDSpresence[ppszPDSelements[j].siDENo] == 'C')
               {
                  getValue(ppszPDSelements[j].cSegInd, ppszPDSelements[j].pszName, m_strValue);
                  if (ppszPDSelements[j].siDENo == 52)
                  {
                     if (m_strValue == "*")
                     m_strValue = "   ";
                  }
                  else if (ppszPDSelements[j].siDENo == 25)
                  {
                     if (m_cMsgRevInd == 'R')
                     {
                        m_strValue = m_cMsgRevInd;
                        m_strValue += "      ";
                     }
                     else
                        m_strValue.erase();
                  }
                  else if (ppszPDSelements[j].siDENo == 105)
                  {
                     m_strValue += m_strFileType;
                     m_strValue += m_strRefData;
                     sprintf(szTemp,"%011ld",atoi(m_strMemProcID.c_str()));
                     m_strValue += szTemp;
                     m_strValue += m_strSeqNo;
                  }
                  else if (ppszPDSelements[j].siDENo == 122)
                  {
                     m_strValue = m_strProcMode;
                  }
                  else if (ppszPDSelements[j].siDENo == 148)
                  {  
                     short nDECIMAL_PLACES = 0;
                     char szTemp[5] = {"    "};
                     string strCUR_SYMBOL;
                     for (pCurrCode = m_hCurrCodes.begin(); pCurrCode != m_hCurrCodes.end(); pCurrCode++)
                     {
                        m_strValue += (*pCurrCode);
						      CurrencyCode::instance()->getCurrencyDetails(m_strValue, strCUR_SYMBOL, nDECIMAL_PLACES);
                        sprintf(szTemp,"%1d",nDECIMAL_PLACES);
						      m_strValue += szTemp;				
                     }
                     if (m_hCurrCodes.size() > 1)
                     {
                        sprintf(szTemp,"f%d",4*m_hCurrCodes.size());
                        memcpy(ppszPDSelements[j].pszLength,szTemp,strlen(szTemp));
                     }
                  }
                  else if (ppszPDSelements[j].siDENo == 149)
                  {  
                     m_strValue += "000";
                  }
                  else if (ppszPDSelements[j].siDENo == 158)
                  {
                     string work = m_strValue;
                     getValue('U', "BUS_SERV_LVL_IND", m_strValue);
                     work += m_strValue;
                     getValue('U', "BUS_SERV_CODE", m_strValue);
                     work += m_strValue;
                     getValue('U', "INTRCHG_RATE_DSG", m_strValue);
                     work += m_strValue;
                     m_strValue = work;
                  }
                  else if (ppszPDSelements[j].siDENo == 165)
                     m_strValue += "                             ";
                  else if (ppszPDSelements[j].siDENo == 301)
                  {
                     sprintf(szTemp, "%016.0f",m_dCheckSumAmount);
                     m_strValue = szTemp;
                  }
                  else if (ppszPDSelements[j].siDENo == 306)
                  {
                     sprintf(szTemp, "%08d",m_lTotalRecs);
                     m_strValue = szTemp;
                  }
                  sprintf(szFieldID,"%04d",ppszPDSelements[j].siDENo);
                  strFieldID = szFieldID;
                  int iOldPos = m_iPos;
                  m_iPos += exportField(&ppszPDSelements[j], &m_pszBuffer[m_iPos],true,strFieldID);
                  if (((m_iPos - iOldPos) < 8 || (m_strValue.length() == 0)) && ppszPDSelements[j].cSegInd != 'F') //store field name if EMPTY field
                  {
                     if (m_aPDSpresence[ppszPDSelements[j].siDENo] == 'M'  && (ValidBlankPDS.find(ppszPDSelements[j].siDENo) == ValidBlankPDS.end()))
                     {
                        if (m_strAbsentField.length() == 0)
						{
							m_strAbsentField = "(PDS" + strFieldID + ")";
							m_strAbsentField += ppszPDSelements[j].pszName;
						}
						else
						{
							m_strAbsentField += ", (PDS" + strFieldID + ")";
						    m_strAbsentField += ppszPDSelements[j].pszName;
						}
                        Trace::put("MANDATORY PDS BLANK/EMPTY");
                        Trace::put(m_strAbsentField.c_str());                        
                     }
                     else							//Conditional field
                        m_iPos = iOldPos;			// move back m_iPos (hence not export)
                  }
                  else
                     iPDSLen += m_strValue.length() + 7;
               }
            }							// END J LOOP
            aPresenceMap[ppszElements[i].siDENo] = 'M';
            sprintf(szTemp,"%03d", iPDSLen);
            memcpy(&m_pszBuffer[iDE48Pos], szTemp, 3);
		 } //END PDS ELEMENT
		 else
		 {
			m_strValue.erase();
			switch(ppszElements[i].siDENo)
			{
            case 4:  
               getValue(ppszElements[i].cSegInd, "CUR_ADJUSTMENT", m_strValue);
               break;
            case 5:
               getValue(ppszElements[i].cSegInd, "CUR_RECON", m_strValue);
               break;
            case 6:
               getValue(ppszElements[i].cSegInd, "CUR_CARDH_BILL", m_strValue);
               break;
            case 30:
               if (ppszElements[i].siDESubfield == 1)
                  getValue(ppszElements[i].cSegInd, "CUR_TRAN", m_strValue);
               else
                  getValue(ppszElements[i].cSegInd, "CUR_RECON_NET", m_strValue);
               break;
			}
			if (m_strValue.length() != 0)
			{
			   pCurrCode = m_hCurrCodes.begin();
               while (pCurrCode != m_hCurrCodes.end() && (*pCurrCode) != m_strValue)
                  pCurrCode++;
               if (pCurrCode == m_hCurrCodes.end())
                  m_hCurrCodes.push_back(m_strValue);
               if (ppszElements[i].siDENo == 4) 
               {
                  getValue('U', "CUR_POI", m_strValue); // for PDS 148
                  if (m_strValue.length() != 0)
                  {
                     pCurrCode = m_hCurrCodes.begin();
                     while (pCurrCode != m_hCurrCodes.end() && (*pCurrCode) != m_strValue)
                        pCurrCode++;
                     if (pCurrCode == m_hCurrCodes.end())
                        m_hCurrCodes.push_back(m_strValue);
                  }
               }
            }
			getValue(ppszElements[i].cSegInd, ppszElements[i].pszName, m_strValue);
			if (ppszElements[i].siDENo == 3 && m_strMessageType == "1740")
			{
			   string strCHAction;
			   getValue('P', "ACTION_TO_CARDHLDR", strCHAction);
			   if (strCHAction[0] == 'C')
				  m_strValue.replace(0,2,"19");
			   else if (strCHAction[0] == 'D')
				  m_strValue.replace(0,2,"29");
			}
			else if (ppszElements[i].siDENo == 4)
			{
			   m_bAddAmount = true;
			   string strTemp;
			   getValue('C', "AMT_RECON_NET", strTemp);
			   size_t pos = strTemp.find(" "); 
			   if (pos != string::npos)
				  strTemp.erase(0,pos + 1);
			   pos = strTemp.find_first_of('.');
			   if (pos != string::npos)  // delete '.' 
				  strTemp.erase(pos,1);
			   double dAMT_RECON_NET = atof(strTemp.data());
			   getValue('P', "AMT_ADJUSTMENT", strTemp);
			   pos = strTemp.find(" ");
			   if (pos != string::npos)
				  strTemp.erase(0,pos + 1);
			   pos = strTemp.find_first_of('.');
			   if (pos != string::npos)  // delete '.' 
			      strTemp.erase(pos,1);
			   double dAMT_ADJUSTMENT = atof(strTemp.data());
			   getValue('P', "AMT_SURCHARGE", strTemp);
			   pos = strTemp.find(" ");
			   if (pos != string::npos)
				  strTemp.erase(0,pos + 1);
			   pos = strTemp.find_first_of('.');
			   if (pos != string::npos)  // delete '.' 
			      strTemp.erase(pos,1);
			   double dAMT_SURCHARGE = atof(strTemp.data());
			   char szTemp[15];
			   if (dAMT_RECON_NET != dAMT_ADJUSTMENT)
				  sprintf(szTemp,"%012.0f",(dAMT_ADJUSTMENT+dAMT_SURCHARGE));
			   else
			      sprintf(szTemp,"%012.0f",dAMT_ADJUSTMENT);
			    m_strValue = szTemp;
			}
			else if (ppszElements[i].siDENo == 12)
            {
			   getValue(ppszElements[i].cSegInd, "TSTAMP_LOCAL", m_strValue);
               if (m_strValue.length() > 13)
                  m_strValue.erase(0,2); 
            }
			else if (ppszElements[i].siDENo == 43)
			{
			   string work;
			   work = m_strValue;
			   work += "\\";
			   getValue(ppszElements[i].cSegInd, "CARD_ACPT_LOC", m_strValue);
			   work += m_strValue;
			   work += "\\";
			   getValue(ppszElements[i].cSegInd, "CARD_ACPT_CITY", m_strValue);
			   work += m_strValue;
			   if (work.length() < 83)
			      work += "\\";
			   else
			 	  work.substr(83,1) = "\\";
			   getValue(ppszElements[i].cSegInd, "CARD_ACPT_ZIP", m_strValue);
               work += m_strValue;
               for (int k=m_strValue.length();k<10;k++)
                  work += " ";
			   getValue(ppszElements[i].cSegInd, "CARD_ACPT_REGION", m_strValue);
               work += m_strValue;
               for (int k=m_strValue.length();k<3;k++)
                  work += " ";
			   getValue(ppszElements[i].cSegInd, "CARD_ACPT_COUNTRY", m_strValue);
               work += m_strValue;
               m_strValue = work;
			}
			else if (ppszElements[i].siDENo == 50)
			{
			   if (m_strValue.length() == 0)
			      m_strValue = "840";
			}
			else if (ppszElements[i].siDENo == 54)
            setDE54();
			else if (ppszElements[i].siDENo == 63)
            {
               string work;
               getValue('U', "LIFECYCLE_SUP_IND", m_strValue); 
               if (m_strValue.length() == 0)
                  m_strValue = " ";
               getValue('U', "LIFECYCLE_TRACE_ID", work); 
               m_strValue += work;
               for (int k=m_strValue.length();k<16;k++)
                  m_strValue += " ";
            }

			if (ppszElements[i].cSegInd == 'M')  // member variable
			{            
			   if (ppszElements[i].siDENo == 24)
               m_strValue = m_strFunctionCode;
			   if (ppszElements[i].siDENo == 71)
			   {
				  sprintf(szTemp,"%08d",getSOURCE_MSG_NO()); 
				  m_strValue = szTemp;
			   }
			}
			int iOldPos = m_iPos;
			m_iPos += exportField(&ppszElements[i], &m_pszBuffer[m_iPos]); // Process regular mandatory fields
 			aPresenceMap[ppszElements[i].siDENo] = 'M';
			sprintf(szFieldID,"%04d",ppszElements[i].siDENo);
            strFieldID = szFieldID;
			if ((m_iPos == iOldPos || (m_strValue.length() == 0)) && ppszElements[i].cSegInd != 'F') //store the field name and return failure(!) if Empty field is exported
            {
			   if (m_aPresence[ppszElements[i].siDENo] == 'M' && (ValidBlankDE.find(ppszElements[i].siDENo) == ValidBlankDE.end()))
			   {
			      if (m_strAbsentField.length() == 0)
				  {
				     m_strAbsentField = "(DE" + strFieldID + ")";
				     m_strAbsentField += ppszElements[i].pszName;
				  }
				  else
				  {
				     m_strAbsentField += ", (DE" + strFieldID + ")";
					 m_strAbsentField += ppszElements[i].pszName;
				  }			     
                   Trace::put("MANDATORY DE BLANK/EMPTY");
                   Trace::put(m_strAbsentField.c_str());			      
			   }
			   else
				   aPresenceMap[ppszElements[i].siDENo] = ' ';
			}							
		 }
	  } //END PRESENCE 'M' or 'C'
   }//END I LOOP
   aPresenceMap[1] = 'M';
   bytes[32] = '\0';                                            
   toBits(aPresenceMap, (char *) bytes, 16);  // Set the bit map
   aPresenceMap[129] = '\0';                                    
   memcpy(&m_pszBuffer[4], bytes, 16);
   m_pszBuffer[m_iPos]= '\0';
   return;
  //## end bmlayouts::IPMMessage::deport%517E48880262.body
}

bool IPMMessage::import ()
{
  //## begin bmlayouts::IPMMessage::import%517E48BA0063.body preserve=yes
   return true;
  //## end bmlayouts::IPMMessage::import%517E48BA0063.body
}

struct Elements* IPMMessage::PDSelements ()
{
  //## begin bmlayouts::IPMMessage::PDSelements%517E489A021C.body preserve=yes
	return &IPMMessage_PDS_Elements[0];
  //## end bmlayouts::IPMMessage::PDSelements%517E489A021C.body
}

void IPMMessage::setElementMaps ()
{
  //## begin bmlayouts::IPMMessage::setElementMaps%517E48A603BB.body preserve=yes
   switch (atoi(m_strMessageType.data()))
   {
      case PRESENTMENT:  memcpy(m_aPresence,    aIPM_PRES,     sizeof(aIPM_PRES));
		                 memcpy(m_aPDSpresence, aIPM_PRES_PDS, sizeof(aIPM_PRES_PDS));
         break;
      case CHARGEBACK:   memcpy(m_aPresence,    aIPM_CHBK,     sizeof(aIPM_CHBK));
                         memcpy(m_aPDSpresence, aIPM_CHBK_PDS, sizeof(aIPM_CHBK_PDS)); 
         break;
      case ADMIN: 
         switch (atoi(m_strFunctionCode.data()))
         {
         case 603: memcpy(m_aPresence,    aIPM_RREQ,     sizeof(aIPM_RREQ));
                   memcpy(m_aPDSpresence, aIPM_RREQ_PDS, sizeof(aIPM_RREQ_PDS));
            break;
         case 695: memcpy(m_aPresence,    aIPM_TRAILER,     sizeof(aIPM_TRAILER));
                   memcpy(m_aPDSpresence, aIPM_TRAILER_PDS, sizeof(aIPM_TRAILER_PDS));
            break;
         case 697: memcpy(m_aPresence,    aIPM_HEADER,     sizeof(aIPM_HEADER));
                   memcpy(m_aPDSpresence, aIPM_HEADER_PDS, sizeof(aIPM_HEADER_PDS));
            break;
         }
         break;
      case FEES:         memcpy(m_aPresence,    aIPM_FEES,     sizeof(aIPM_FEES));
		                 memcpy(m_aPDSpresence, aIPM_FEES_PDS, sizeof(aIPM_FEES_PDS));
         break;
   }
  //## end bmlayouts::IPMMessage::setElementMaps%517E48A603BB.body
}

void IPMMessage::setDE54 ()
{
  //## begin bmlayouts::IPMMessage::setDE54%51F15BF10290.body preserve=yes
   m_strValue.erase();
   if (m_strMessageType == "1442"
      && (m_strFunctionCode == "450" || m_strFunctionCode == "451"))
   {
      char szTemp[20];
      string strCASHBACK_AMT, strAMT_SURCHARGE_FEE, strAMT_POI, strAMT_TRAN, work;
      double dCASHBACK_AMT, dAMT_SURCHARGE_FEE, dAMT_POI, dAMT_TRAN;
      getValue('C', "CASHBACK_AMT", strCASHBACK_AMT); 
      getValue('C', "AMT_SURCHARGE_FEE", strAMT_SURCHARGE_FEE); 
      getValue('U', "AMT_POI", strAMT_POI); 
      getValue('C', "AMT_TRAN", strAMT_TRAN); 
      size_t pos = strCASHBACK_AMT.find(" "); 
      if (pos != string::npos)
         strCASHBACK_AMT.erase(0,pos + 1);
      pos = strCASHBACK_AMT.find_first_of('.');
      if (pos != string::npos)  // delete '.' 
         strCASHBACK_AMT.erase(pos,1);
      dCASHBACK_AMT = atof(strCASHBACK_AMT.data());

      pos = strAMT_TRAN.find(" "); 
      if (pos != string::npos)
         strAMT_TRAN.erase(0,pos + 1);
      pos = strAMT_TRAN.find_first_of('.');
      if (pos != string::npos)  // delete '.' 
         strAMT_TRAN.erase(pos,1);
      dAMT_TRAN = atof(strAMT_TRAN.data());

      pos = strAMT_SURCHARGE_FEE.find(" "); 
      if (pos != string::npos)
         strAMT_SURCHARGE_FEE.erase(0,pos + 1);
      pos = strAMT_SURCHARGE_FEE.find_first_of('.');
      if (pos != string::npos)  // delete '.' 
         strAMT_SURCHARGE_FEE.erase(pos,1);
      dAMT_SURCHARGE_FEE = atof(strAMT_SURCHARGE_FEE.data());

      pos = strAMT_POI.find(" "); 
      if (pos != string::npos)
         strAMT_POI.erase(0,pos + 1);
      pos = strAMT_POI.find_first_of('.');
      if (pos != string::npos)  // delete '.' 
         strAMT_POI.erase(pos,1);
      dAMT_POI = atof(strAMT_POI.data());

      if (dCASHBACK_AMT > 0)
      {
         m_strValue = "0940";
         getValue('C', "CUR_CASHBACK", work); 
         m_strValue += work;
         m_strValue += "D";
		 sprintf(szTemp,"%012.0f",dCASHBACK_AMT);
		 m_strValue += szTemp;
         m_strValue += "0000";
         getValue('C', "CUR_TRAN", work); 
         m_strValue += work;
         m_strValue += "D";
		 sprintf(szTemp,"%012.0f",dCASHBACK_AMT + dAMT_TRAN);
         m_strValue += szTemp;
      }
      else if (dAMT_SURCHARGE_FEE > 0)
      {
         m_strValue = "0042";
         getValue('C', "CUR_SURCHARGE_FEE", work); 
         m_strValue += work;
         m_strValue += "D";
		 sprintf(szTemp,"%012.0f",dAMT_SURCHARGE_FEE);
		 m_strValue += szTemp;

         m_strValue += "0000";
         getValue('C', "CUR_TRAN", work); 
         m_strValue += work;
         m_strValue += "D";
		 sprintf(szTemp,"%012.0f",dAMT_TRAN);
		 m_strValue += szTemp;
      }
      if (dAMT_POI > 0)
      {
         m_strValue += "0058";
         getValue('U', "CUR_POI", work); 
         m_strValue += work;
         m_strValue += "D";
		 sprintf(szTemp,"%012.0f",dAMT_POI);
		 m_strValue += szTemp;
      }
   }
  //## end bmlayouts::IPMMessage::setDE54%51F15BF10290.body
}

void IPMMessage::update (Subject* pSubject)
{
  //## begin bmlayouts::IPMMessage::update%517E48AA03DC.body preserve=yes
  //## end bmlayouts::IPMMessage::update%517E48AA03DC.body
}

void IPMMessage::updateFields (void* hSegment, char cInd)
{
  //## begin bmlayouts::IPMMessage::updateFields%517E48AE026D.body preserve=yes
  //## end bmlayouts::IPMMessage::updateFields%517E48AE026D.body
}

// Additional Declarations
  //## begin bmlayouts::IPMMessage%517E455E002B.declarations preserve=yes
  //## end bmlayouts::IPMMessage%517E455E002B.declarations

} // namespace bmlayouts

//## begin module%517E45E501D5.epilog preserve=yes
//## end module%517E45E501D5.epilog
