//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4059AF860232.cm preserve=no
//	$Date:   18 Jan 2018 14:02:56  $ $Author:   e1009839  $ $Revision:   1.7  $
//## end module%4059AF860232.cm

//## begin module%4059AF860232.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4059AF860232.cp

//## Module: CXOSBL06%4059AF860232; Package specification
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bldll\CXODBL06.hpp

#ifndef CXOSBL06_h
#define CXOSBL06_h 1

//## begin module%4059AF860232.additionalIncludes preserve=no
//## end module%4059AF860232.additionalIncludes

//## begin module%4059AF860232.includes preserve=yes
// $Date:   18 Jan 2018 14:02:56  $ $Author:   e1009839  $ $Revision:   1.7  $
//## end module%4059AF860232.includes

#ifndef CXOSBL01_h
#include "CXODBL01.hpp"
#endif
//## begin module%4059AF860232.declarations preserve=no
//## end module%4059AF860232.declarations

//## begin module%4059AF860232.additionalDeclarations preserve=yes
//## end module%4059AF860232.additionalDeclarations


//## Modelname: Connex Library::BitMapLayouts_CAT%3E4A483C030D
namespace bmlayouts {
//## begin bmlayouts%3E4A483C030D.initialDeclarations preserve=yes
//## end bmlayouts%3E4A483C030D.initialDeclarations

//## begin bmlayouts::OCSMessage%4059AEA40271.preface preserve=yes
//## end bmlayouts::OCSMessage%4059AEA40271.preface

//## Class: OCSMessage%4059AEA40271
//## Category: Connex Library::BitMapLayouts_CAT%3E4A483C030D
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport OCSMessage : public BitMapMessage  //## Inherits: <unnamed>%4059AF1C00BB
{
  //## begin bmlayouts::OCSMessage%4059AEA40271.initialDeclarations preserve=yes
  //## end bmlayouts::OCSMessage%4059AEA40271.initialDeclarations

  public:
    //## Constructors (generated)
      OCSMessage();

    //## Destructor (generated)
      virtual ~OCSMessage();


    //## Other Operations (specified)
      //## Operation: deport%4059B0830138
      virtual void deport ();

      //## Operation: getCurrencyExp%407ECAE200EA
      virtual char getCurrencyExp (const string& strCurrencyCode);

      //## Operation: import%4059B0830148
      virtual bool import ();

      //## Operation: update%4086CA9802BF
      virtual void update (Subject* pSubject);

      //## Operation: writeField%409157740242
      void writeField (const string& strFieldID, string& hData, int iType, char* pLength, char* pFormat, char* pName);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: SeqNo%4088170A02BF
      const string& getSeqNo () const
      {
        //## begin bmlayouts::OCSMessage::getSeqNo%4088170A02BF.get preserve=no
        return m_strSeqNo;
        //## end bmlayouts::OCSMessage::getSeqNo%4088170A02BF.get
      }


      //## Attribute: MsgRevInd%407D59A8007D
      const char& getMsgRevInd () const
      {
        //## begin bmlayouts::OCSMessage::getMsgRevInd%407D59A8007D.get preserve=no
        return m_cMsgRevInd;
        //## end bmlayouts::OCSMessage::getMsgRevInd%407D59A8007D.get
      }


      //## Attribute: MessageNumber%407D707D00BB
      const int& getMessageNumber () const
      {
        //## begin bmlayouts::OCSMessage::getMessageNumber%407D707D00BB.get preserve=no
        return m_lMessageNumber;
        //## end bmlayouts::OCSMessage::getMessageNumber%407D707D00BB.get
      }


    // Additional Public Declarations
      //## begin bmlayouts::OCSMessage%4059AEA40271.public preserve=yes
      //## end bmlayouts::OCSMessage%4059AEA40271.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: CardScheme%407D59280213
      //## begin bmlayouts::OCSMessage::CardScheme%407D59280213.attr preserve=no  public: string {U} 
      string m_strCardScheme;
      //## end bmlayouts::OCSMessage::CardScheme%407D59280213.attr

      //## begin bmlayouts::OCSMessage::SeqNo%4088170A02BF.attr preserve=no  public: string {U} 
      string m_strSeqNo;
      //## end bmlayouts::OCSMessage::SeqNo%4088170A02BF.attr

      //## Attribute: ForwardingInstID%408810A301C5
      //## begin bmlayouts::OCSMessage::ForwardingInstID%408810A301C5.attr preserve=no  public: string {U} 
      string m_strForwardingInstID;
      //## end bmlayouts::OCSMessage::ForwardingInstID%408810A301C5.attr

      //## Attribute: Member%4092520400FA
      //## begin bmlayouts::OCSMessage::Member%4092520400FA.attr preserve=no  public: string {U} 
      string m_strMember;
      //## end bmlayouts::OCSMessage::Member%4092520400FA.attr

      //## begin bmlayouts::OCSMessage::MsgRevInd%407D59A8007D.attr preserve=no  public: char {U} 
      char m_cMsgRevInd;
      //## end bmlayouts::OCSMessage::MsgRevInd%407D59A8007D.attr

      //## Attribute: ProcMode%4061C5760222
      //## begin bmlayouts::OCSMessage::ProcMode%4061C5760222.attr preserve=no  protected: string {U} 
      string m_strProcMode;
      //## end bmlayouts::OCSMessage::ProcMode%4061C5760222.attr

      //## begin bmlayouts::OCSMessage::MessageNumber%407D707D00BB.attr preserve=no  public: int {U} 
      int m_lMessageNumber;
      //## end bmlayouts::OCSMessage::MessageNumber%407D707D00BB.attr

      //## Attribute: ReasonCode%40B235710196
      //## begin bmlayouts::OCSMessage::ReasonCode%40B235710196.attr preserve=no  public: string {U} 
      string m_strReasonCode;
      //## end bmlayouts::OCSMessage::ReasonCode%40B235710196.attr

      //## Attribute: RecordType%408D174E004E
      //## begin bmlayouts::OCSMessage::RecordType%408D174E004E.attr preserve=no  public: string {U} 
      string m_strRecordType;
      //## end bmlayouts::OCSMessage::RecordType%408D174E004E.attr

      //## Attribute: TID%40CDD7BA02CE
      //## begin bmlayouts::OCSMessage::TID%40CDD7BA02CE.attr preserve=no  public: string {U} 
      string m_strTID;
      //## end bmlayouts::OCSMessage::TID%40CDD7BA02CE.attr

    // Additional Protected Declarations
      //## begin bmlayouts::OCSMessage%4059AEA40271.protected preserve=yes
      //## end bmlayouts::OCSMessage%4059AEA40271.protected

  private:

    //## Other Operations (specified)
      //## Operation: setElementMaps%4059B0830157
      void setElementMaps ();

    // Additional Private Declarations
      //## begin bmlayouts::OCSMessage%4059AEA40271.private preserve=yes
      //## end bmlayouts::OCSMessage%4059AEA40271.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin bmlayouts::OCSMessage%4059AEA40271.implementation preserve=yes
      //## end bmlayouts::OCSMessage%4059AEA40271.implementation

};

//## begin bmlayouts::OCSMessage%4059AEA40271.postscript preserve=yes
//## end bmlayouts::OCSMessage%4059AEA40271.postscript

} // namespace bmlayouts

//## begin module%4059AF860232.epilog preserve=yes
using namespace bmlayouts;
//## end module%4059AF860232.epilog


#endif
