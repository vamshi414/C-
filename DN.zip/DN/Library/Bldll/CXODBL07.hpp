//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%517E45E30052.cm preserve=no
//	$Date:   18 Jan 2018 14:02:58  $ $Author:   e1009839  $ $Revision:   1.1  $
//## end module%517E45E30052.cm

//## begin module%517E45E30052.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%517E45E30052.cp

//## Module: CXOSBL07%517E45E30052; Package specification
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Source file: C:\V02.3B.R009\Build\ConnexPlatform\Server\Library\Bldll\CXODBL07.hpp

#ifndef CXOSBL07_h
#define CXOSBL07_h 1

//## begin module%517E45E30052.additionalIncludes preserve=no
//## end module%517E45E30052.additionalIncludes

//## begin module%517E45E30052.includes preserve=yes
//## end module%517E45E30052.includes

#ifndef CXOSBL01_h
#include "CXODBL01.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class CurrencyCode;

} // namespace database

//## begin module%517E45E30052.declarations preserve=no
//## end module%517E45E30052.declarations

//## begin module%517E45E30052.additionalDeclarations preserve=yes
//## end module%517E45E30052.additionalDeclarations


//## Modelname: Connex Library::BitMapLayouts_CAT%3E4A483C030D
namespace bmlayouts {
//## begin bmlayouts%3E4A483C030D.initialDeclarations preserve=yes
//## end bmlayouts%3E4A483C030D.initialDeclarations

//## begin bmlayouts::IPMMessage%517E455E002B.preface preserve=yes
//## end bmlayouts::IPMMessage%517E455E002B.preface

//## Class: IPMMessage%517E455E002B
//## Category: Connex Library::BitMapLayouts_CAT%3E4A483C030D
//## Subsystem: Connex Library::BLDLL%3E4A4E3E0109
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%51ADBE67014F;database::CurrencyCode { -> F}

class DllExport IPMMessage : public BitMapMessage  //## Inherits: <unnamed>%517E47CD01FA
{
  //## begin bmlayouts::IPMMessage%517E455E002B.initialDeclarations preserve=yes
  //## end bmlayouts::IPMMessage%517E455E002B.initialDeclarations

  public:
    //## Constructors (generated)
      IPMMessage();

    //## Destructor (generated)
      virtual ~IPMMessage();


    //## Other Operations (specified)
      //## Operation: checkPresence%517E497202F6
      virtual char checkPresence (const string& strFieldName);

      //## Operation: elements%517E4880011C
      struct Elements* elements () const;

      //## Operation: deport%517E48880262
      virtual void deport ();

      //## Operation: import%517E48BA0063
      virtual bool import ();

      //## Operation: PDSelements%517E489A021C
      struct Elements* PDSelements ();

      //## Operation: setDE54%51F15BF10290
      void setDE54 ();

      //## Operation: update%517E48AA03DC
      virtual void update (Subject* pSubject);

      //## Operation: updateFields%517E48AE026D
      void updateFields (void* hSegment, char cInd);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: MsgRevInd%51B5C8EF0134
      const char& getMsgRevInd () const
      {
        //## begin bmlayouts::IPMMessage::getMsgRevInd%51B5C8EF0134.get preserve=no
        return m_cMsgRevInd;
        //## end bmlayouts::IPMMessage::getMsgRevInd%51B5C8EF0134.get
      }


      //## Attribute: RefData%51B5C8F700B9
      const string& getRefData () const
      {
        //## begin bmlayouts::IPMMessage::getRefData%51B5C8F700B9.get preserve=no
        return m_strRefData;
        //## end bmlayouts::IPMMessage::getRefData%51B5C8F700B9.get
      }


      //## Attribute: SeqNo%51B5C8F700BA
      const string& getSeqNo () const
      {
        //## begin bmlayouts::IPMMessage::getSeqNo%51B5C8F700BA.get preserve=no
        return m_strSeqNo;
        //## end bmlayouts::IPMMessage::getSeqNo%51B5C8F700BA.get
      }


      //## Attribute: SOURCE_MSG_NO%51B5C8F700C9
      const int& getSOURCE_MSG_NO () const
      {
        //## begin bmlayouts::IPMMessage::getSOURCE_MSG_NO%51B5C8F700C9.get preserve=no
        return m_lSOURCE_MSG_NO;
        //## end bmlayouts::IPMMessage::getSOURCE_MSG_NO%51B5C8F700C9.get
      }

      void setSOURCE_MSG_NO (const int& value)
      {
        //## begin bmlayouts::IPMMessage::setSOURCE_MSG_NO%51B5C8F700C9.set preserve=no
        m_lSOURCE_MSG_NO = value;
        //## end bmlayouts::IPMMessage::setSOURCE_MSG_NO%51B5C8F700C9.set
      }


    // Additional Public Declarations
      //## begin bmlayouts::IPMMessage%517E455E002B.public preserve=yes
      //## end bmlayouts::IPMMessage%517E455E002B.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: FileType%51B5C8EF0114
      //## begin bmlayouts::IPMMessage::FileType%51B5C8EF0114.attr preserve=no  protected: string {U} 
      string m_strFileType;
      //## end bmlayouts::IPMMessage::FileType%51B5C8EF0114.attr

      //## Attribute: InstID%51B5C8EF0124
      //## begin bmlayouts::IPMMessage::InstID%51B5C8EF0124.attr preserve=no  protected: string {U} 
      string m_strInstID;
      //## end bmlayouts::IPMMessage::InstID%51B5C8EF0124.attr

      //## Attribute: MemProcID%51B5C8EF0125
      //## begin bmlayouts::IPMMessage::MemProcID%51B5C8EF0125.attr preserve=no  protected: string {U} 
      string m_strMemProcID;
      //## end bmlayouts::IPMMessage::MemProcID%51B5C8EF0125.attr

      //## Attribute: MsgInd%51B5C8EF0133
      //## begin bmlayouts::IPMMessage::MsgInd%51B5C8EF0133.attr preserve=no  protected: string {U} 
      string m_strMsgInd;
      //## end bmlayouts::IPMMessage::MsgInd%51B5C8EF0133.attr

      //## begin bmlayouts::IPMMessage::MsgRevInd%51B5C8EF0134.attr preserve=no  public: char {U} 
      char m_cMsgRevInd;
      //## end bmlayouts::IPMMessage::MsgRevInd%51B5C8EF0134.attr

      //## Attribute: PDSpresence%517E49290128
      //## begin bmlayouts::IPMMessage::PDSpresence%517E49290128.attr preserve=no  protected: char {U} 
      char m_aPDSpresence[410];
      //## end bmlayouts::IPMMessage::PDSpresence%517E49290128.attr

      //## Attribute: ProcMode%51B5C8F700AA
      //## begin bmlayouts::IPMMessage::ProcMode%51B5C8F700AA.attr preserve=no  protected: string {U} 
      string m_strProcMode;
      //## end bmlayouts::IPMMessage::ProcMode%51B5C8F700AA.attr

      //## begin bmlayouts::IPMMessage::RefData%51B5C8F700B9.attr preserve=no  public: string {U} 
      string m_strRefData;
      //## end bmlayouts::IPMMessage::RefData%51B5C8F700B9.attr

      //## begin bmlayouts::IPMMessage::SeqNo%51B5C8F700BA.attr preserve=no  public: string {U} 
      string m_strSeqNo;
      //## end bmlayouts::IPMMessage::SeqNo%51B5C8F700BA.attr

      //## begin bmlayouts::IPMMessage::SOURCE_MSG_NO%51B5C8F700C9.attr preserve=no  public: int {V} 0
      int m_lSOURCE_MSG_NO;
      //## end bmlayouts::IPMMessage::SOURCE_MSG_NO%51B5C8F700C9.attr

    // Additional Protected Declarations
      //## begin bmlayouts::IPMMessage%517E455E002B.protected preserve=yes
      //## end bmlayouts::IPMMessage%517E455E002B.protected

  private:

    //## Other Operations (specified)
      //## Operation: setElementMaps%517E48A603BB
      void setElementMaps ();

    // Additional Private Declarations
      //## begin bmlayouts::IPMMessage%517E455E002B.private preserve=yes
      //## end bmlayouts::IPMMessage%517E455E002B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: NumberOfPDSelements%517E4922001F
      //## begin bmlayouts::IPMMessage::NumberOfPDSelements%517E4922001F.attr preserve=no  private: int {U} 0
      int m_lNumberOfPDSelements;
      //## end bmlayouts::IPMMessage::NumberOfPDSelements%517E4922001F.attr

    // Additional Implementation Declarations
      //## begin bmlayouts::IPMMessage%517E455E002B.implementation preserve=yes
      vector<string> m_hCurrCodes;
      vector<string>::iterator pCurrCode;
      //## end bmlayouts::IPMMessage%517E455E002B.implementation
};

//## begin bmlayouts::IPMMessage%517E455E002B.postscript preserve=yes
//## end bmlayouts::IPMMessage%517E455E002B.postscript

} // namespace bmlayouts

//## begin module%517E45E30052.epilog preserve=yes
#define ADMIN        1644
#define CHARGEBACK   1442
#define FEES         1740
#define PRESENTMENT  1240

using namespace bmlayouts;
//## end module%517E45E30052.epilog


#endif
