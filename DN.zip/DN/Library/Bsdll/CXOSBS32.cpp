//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5D0BD5660067.cm preserve=no
//	$Date:   May 14 2020 17:56:20  $ $Author:   e1009510  $
//	$Revision:   1.3  $
//## end module%5D0BD5660067.cm

//## begin module%5D0BD5660067.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5D0BD5660067.cp

//## Module: CXOSBS32%5D0BD5660067; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXOSBS32.cpp

//## begin module%5D0BD5660067.additionalIncludes preserve=no
//## end module%5D0BD5660067.additionalIncludes

//## begin module%5D0BD5660067.includes preserve=yes
//## end module%5D0BD5660067.includes

#ifndef CXOSBS32_h
#include "CXODBS32.hpp"
#endif
//## begin module%5D0BD5660067.declarations preserve=no
//## end module%5D0BD5660067.declarations

//## begin module%5D0BD5660067.additionalDeclarations preserve=yes
//## end module%5D0BD5660067.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::ActivitySegment 

ActivitySegment::ActivitySegment()
  //## begin ActivitySegment::ActivitySegment%5D0BD4BE01AC_const.hasinit preserve=no
  //## end ActivitySegment::ActivitySegment%5D0BD4BE01AC_const.hasinit
  //## begin ActivitySegment::ActivitySegment%5D0BD4BE01AC_const.initialization preserve=yes
  //## end ActivitySegment::ActivitySegment%5D0BD4BE01AC_const.initialization
{
  //## begin segment::ActivitySegment::ActivitySegment%5D0BD4BE01AC_const.body preserve=yes
   memcpy_s(m_sID,4,"BS32",4);
  //## end segment::ActivitySegment::ActivitySegment%5D0BD4BE01AC_const.body
}


ActivitySegment::~ActivitySegment()
{
  //## begin segment::ActivitySegment::~ActivitySegment%5D0BD4BE01AC_dest.body preserve=yes
  //## end segment::ActivitySegment::~ActivitySegment%5D0BD4BE01AC_dest.body
}


ActivitySegment & ActivitySegment::operator=(const ActivitySegment &right)
{
  //## begin segment::ActivitySegment::operator=%5D0BD4BE01AC_assign.body preserve=yes
   char szValue[PERCENTF];
   string strValue;
   for (map<string,int,less<string> >::const_iterator p = right.m_hColumn.begin();p != right.m_hColumn.end();++p)
   {
      strValue.assign(szValue,snprintf(szValue,sizeof(szValue),"%f",::atof(((string*)right.m_hValue[(*p).second])->c_str())));
      set((*p).first.c_str(),strValue);
   }
   return *this;
  //## end segment::ActivitySegment::operator=%5D0BD4BE01AC_assign.body
}



//## Other Operations (implementation)
void ActivitySegment::operator += (const ActivitySegment& right)
{
  //## begin segment::ActivitySegment::operator+=%5D0BD4FF03B6.body preserve=yes
   char szValue[PERCENTF];
   string strValue;
   for (map<string,int,less<string> >::const_iterator p = right.m_hColumn.begin();p != right.m_hColumn.end();++p)
   {
      strValue.assign(szValue,snprintf(szValue,sizeof(szValue),"%f",::atof(((string*)right.m_hValue[(*p).second])->c_str()) + ::atof(get((*p).first.c_str()).c_str())));
      set((*p).first.c_str(),strValue);
   }
  //## end segment::ActivitySegment::operator+=%5D0BD4FF03B6.body
}

// Additional Declarations
  //## begin segment::ActivitySegment%5D0BD4BE01AC.declarations preserve=yes
void ActivitySegment::operator -= (const ActivitySegment& right)
{
   //## begin segment::ActivitySegment::operator+=%5D0BD4FF03B6.body preserve=yes
   char szValue[PERCENTF];
   string strValue;
   for (map<string, int, less<string> >::const_iterator p = right.m_hColumn.begin(); p != right.m_hColumn.end(); ++p)
   {
      strValue.assign(szValue, snprintf(szValue,sizeof(szValue),"%f", ::atof(get((*p).first.c_str()).c_str()) - ::atof(((string*)right.m_hValue[(*p).second])->c_str())));
      set((*p).first.c_str(), strValue);
   }
}
  //## end segment::ActivitySegment%5D0BD4BE01AC.declarations

} // namespace segment

//## begin module%5D0BD5660067.epilog preserve=yes
//## end module%5D0BD5660067.epilog
