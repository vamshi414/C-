//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5AB2A7D80391.cm preserve=no
//	$Date:   Jan 07 2019 14:57:50  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%5AB2A7D80391.cm

//## begin module%5AB2A7D80391.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5AB2A7D80391.cp

//## Module: CXOSBS30%5AB2A7D80391; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.8A.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS30.hpp

#ifndef CXOSBS30_h
#define CXOSBS30_h 1

//## begin module%5AB2A7D80391.additionalIncludes preserve=no
//## end module%5AB2A7D80391.additionalIncludes

//## begin module%5AB2A7D80391.includes preserve=yes
//## end module%5AB2A7D80391.includes

#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class SegmentVersion;
class InformationSegment;
} // namespace segment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

namespace segment {
class CommonHeaderSegment;

} // namespace segment

//## begin module%5AB2A7D80391.declarations preserve=no
//## end module%5AB2A7D80391.declarations

//## begin module%5AB2A7D80391.additionalDeclarations preserve=yes
//## end module%5AB2A7D80391.additionalDeclarations


namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::ContactSegment%5AB2A71701C4.preface preserve=yes
//## end segment::ContactSegment%5AB2A71701C4.preface

//## Class: ContactSegment%5AB2A71701C4
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5AB2A9CF0311;InformationSegment { -> F}
//## Uses: <unnamed>%5AB2A9D2007D;reusable::Query { -> F}
//## Uses: <unnamed>%5AB2A9D5012D;timer::Clock { -> F}
//## Uses: <unnamed>%5AB2A9E100D6;CommonHeaderSegment { -> F}
//## Uses: <unnamed>%5AB2A9E40053;SegmentVersion { -> F}
//## Uses: <unnamed>%5AB2A9ED01BC;IF::Extract { -> F}

class DllExport ContactSegment : public PersistentSegment  //## Inherits: <unnamed>%5AB2A8FD01D2
{
  //## begin segment::ContactSegment%5AB2A71701C4.initialDeclarations preserve=yes
public:
   enum Type
   {
      SENDER,
      RECEIVER,
      CUSTOMER
   };
  //## end segment::ContactSegment%5AB2A71701C4.initialDeclarations

  public:
    //## Constructors (generated)
      ContactSegment();

      ContactSegment(const ContactSegment &right);

    //## Destructor (generated)
      virtual ~ContactSegment();

    //## Assignment Operation (generated)
      ContactSegment & operator=(const ContactSegment &right);


    //## Other Operations (specified)
      //## Operation: bind%5AB2ADED023E
      virtual void bind (Query& hQuery);

      //## Operation: fields%5AB2A9480387
      virtual struct Fields* fields () const;

      //## Operation: instance%5AB2A948038B
      static ContactSegment* instance (Type nType);

      //## Operation: reset%5AB2A948038F
      virtual void reset ();

      //## Operation: setColumns%5AB2A9480393
      virtual void setColumns (Table& hTable);

      //## Operation: setRPT_LVL_ID%5AB2A948039B
      void setRPT_LVL_ID (const string& value)
      {
        //## begin segment::ContactSegment::setRPT_LVL_ID%5AB2A948039B.body preserve=yes
        //## end segment::ContactSegment::setRPT_LVL_ID%5AB2A948039B.body
      }

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ADDRESS_LINE_1%5AB2A97502E8
      void setADDRESS_LINE_1 (const string& value)
      {
        //## begin segment::ContactSegment::setADDRESS_LINE_1%5AB2A97502E8.set preserve=no
        m_strADDRESS_LINE_1 = value;
        //## end segment::ContactSegment::setADDRESS_LINE_1%5AB2A97502E8.set
      }


      //## Attribute: ADDRESS_LINE_2%5AB2A97502FB
      void setADDRESS_LINE_2 (const string& value)
      {
        //## begin segment::ContactSegment::setADDRESS_LINE_2%5AB2A97502FB.set preserve=no
        m_strADDRESS_LINE_2 = value;
        //## end segment::ContactSegment::setADDRESS_LINE_2%5AB2A97502FB.set
      }


      //## Attribute: BIN%5AB2A9750307
      const string& getBIN () const
      {
        //## begin segment::ContactSegment::getBIN%5AB2A9750307.get preserve=no
        return m_strBIN;
        //## end segment::ContactSegment::getBIN%5AB2A9750307.get
      }

      void setBIN (const string& value)
      {
        //## begin segment::ContactSegment::setBIN%5AB2A9750307.set preserve=no
        m_strBIN = value;
        //## end segment::ContactSegment::setBIN%5AB2A9750307.set
      }


      //## Attribute: CITY%5AB2A975030A
      void setCITY (const string& value)
      {
        //## begin segment::ContactSegment::setCITY%5AB2A975030A.set preserve=no
        m_strCITY = value;
        //## end segment::ContactSegment::setCITY%5AB2A975030A.set
      }


      //## Attribute: ContactInstID%5AB2A975030E
      const string& getContactInstID () const
      {
        //## begin segment::ContactSegment::getContactInstID%5AB2A975030E.get preserve=no
        return m_strContactInstID;
        //## end segment::ContactSegment::getContactInstID%5AB2A975030E.get
      }

      void setContactInstID (const string& value)
      {
        //## begin segment::ContactSegment::setContactInstID%5AB2A975030E.set preserve=no
        m_strContactInstID = value;
        //## end segment::ContactSegment::setContactInstID%5AB2A975030E.set
      }


      //## Attribute: ContactProcID%5AB2A9750311
      const string& getContactProcID () const
      {
        //## begin segment::ContactSegment::getContactProcID%5AB2A9750311.get preserve=no
        return m_strContactProcID;
        //## end segment::ContactSegment::getContactProcID%5AB2A9750311.get
      }

      void setContactProcID (const string& value)
      {
        //## begin segment::ContactSegment::setContactProcID%5AB2A9750311.set preserve=no
        m_strContactProcID = value;
        //## end segment::ContactSegment::setContactProcID%5AB2A9750311.set
      }


      //## Attribute: CONTACT_ID%5AB2AD05001E
      const int getCONTACT_ID () const
      {
        //## begin segment::ContactSegment::getCONTACT_ID%5AB2AD05001E.get preserve=no
        return m_lCONTACT_ID;
        //## end segment::ContactSegment::getCONTACT_ID%5AB2AD05001E.get
      }

      void setCONTACT_ID (int value)
      {
        //## begin segment::ContactSegment::setCONTACT_ID%5AB2AD05001E.set preserve=no
        m_lCONTACT_ID = value;
        //## end segment::ContactSegment::setCONTACT_ID%5AB2AD05001E.set
      }


      //## Attribute: CONTACT_METHOD%5AB2A9750319
      const string& getCONTACT_METHOD () const
      {
        //## begin segment::ContactSegment::getCONTACT_METHOD%5AB2A9750319.get preserve=no
        return m_strCONTACT_METHOD;
        //## end segment::ContactSegment::getCONTACT_METHOD%5AB2A9750319.get
      }

      void setCONTACT_METHOD (const string& value)
      {
        //## begin segment::ContactSegment::setCONTACT_METHOD%5AB2A9750319.set preserve=no
        m_strCONTACT_METHOD = value;
        //## end segment::ContactSegment::setCONTACT_METHOD%5AB2A9750319.set
      }


      //## Attribute: CONTACT_TYPE%5AB2A975031C
      const string& getCONTACT_TYPE () const
      {
        //## begin segment::ContactSegment::getCONTACT_TYPE%5AB2A975031C.get preserve=no
        return m_strCONTACT_TYPE;
        //## end segment::ContactSegment::getCONTACT_TYPE%5AB2A975031C.get
      }

      void setCONTACT_TYPE (const string& value)
      {
        //## begin segment::ContactSegment::setCONTACT_TYPE%5AB2A975031C.set preserve=no
        m_strCONTACT_TYPE = value;
        //## end segment::ContactSegment::setCONTACT_TYPE%5AB2A975031C.set
      }


      //## Attribute: COURIER_PTR%5AB2AD05002F
      const int& getCOURIER_PTR () const
      {
        //## begin segment::ContactSegment::getCOURIER_PTR%5AB2AD05002F.get preserve=no
        return m_lCOURIER_PTR;
        //## end segment::ContactSegment::getCOURIER_PTR%5AB2AD05002F.get
      }

      void setCOURIER_PTR (const int& value)
      {
        //## begin segment::ContactSegment::setCOURIER_PTR%5AB2AD05002F.set preserve=no
        m_lCOURIER_PTR = value;
        //## end segment::ContactSegment::setCOURIER_PTR%5AB2AD05002F.set
      }


      //## Attribute: COURIER_ROUTE_PTR%5AB2AD050046
      const int& getCOURIER_ROUTE_PTR () const
      {
        //## begin segment::ContactSegment::getCOURIER_ROUTE_PTR%5AB2AD050046.get preserve=no
        return m_lCOURIER_ROUTE_PTR;
        //## end segment::ContactSegment::getCOURIER_ROUTE_PTR%5AB2AD050046.get
      }

      void setCOURIER_ROUTE_PTR (const int& value)
      {
        //## begin segment::ContactSegment::setCOURIER_ROUTE_PTR%5AB2AD050046.set preserve=no
        m_lCOURIER_ROUTE_PTR = value;
        //## end segment::ContactSegment::setCOURIER_ROUTE_PTR%5AB2AD050046.set
      }


      //## Attribute: DEVICE_ID%5AB2A975032C
      const string& getDEVICE_ID () const
      {
        //## begin segment::ContactSegment::getDEVICE_ID%5AB2A975032C.get preserve=no
        return m_strDEVICE_ID;
        //## end segment::ContactSegment::getDEVICE_ID%5AB2A975032C.get
      }

      void setDEVICE_ID (const string& value)
      {
        //## begin segment::ContactSegment::setDEVICE_ID%5AB2A975032C.set preserve=no
        m_strDEVICE_ID = value;
        //## end segment::ContactSegment::setDEVICE_ID%5AB2A975032C.set
      }


      //## Attribute: INST_ID%5AB2A9750336
      const string& getINST_ID () const
      {
        //## begin segment::ContactSegment::getINST_ID%5AB2A9750336.get preserve=no
        return m_strINST_ID;
        //## end segment::ContactSegment::getINST_ID%5AB2A9750336.get
      }

      void setINST_ID (const string& value)
      {
        //## begin segment::ContactSegment::setINST_ID%5AB2A9750336.set preserve=no
        m_strINST_ID = value;
        //## end segment::ContactSegment::setINST_ID%5AB2A9750336.set
      }


      //## Attribute: NAME%5AB2A975033A
      void setNAME (const string& value)
      {
        //## begin segment::ContactSegment::setNAME%5AB2A975033A.set preserve=no
        m_strNAME = value;
        //## end segment::ContactSegment::setNAME%5AB2A975033A.set
      }


      //## Attribute: POSTAL_CODE%5AB2A9750345
      void setPOSTAL_CODE (const string& value)
      {
        //## begin segment::ContactSegment::setPOSTAL_CODE%5AB2A9750345.set preserve=no
        m_strPOSTAL_CODE = value;
        //## end segment::ContactSegment::setPOSTAL_CODE%5AB2A9750345.set
      }


      //## Attribute: PROC_GRP_ID%5AB2A9750349
      const string& getPROC_GRP_ID () const
      {
        //## begin segment::ContactSegment::getPROC_GRP_ID%5AB2A9750349.get preserve=no
        return m_strPROC_GRP_ID;
        //## end segment::ContactSegment::getPROC_GRP_ID%5AB2A9750349.get
      }

      void setPROC_GRP_ID (const string& value)
      {
        //## begin segment::ContactSegment::setPROC_GRP_ID%5AB2A9750349.set preserve=no
        m_strPROC_GRP_ID = value;
        //## end segment::ContactSegment::setPROC_GRP_ID%5AB2A9750349.set
      }


      //## Attribute: PROC_ID%5AB2A975034C
      const string& getPROC_ID () const
      {
        //## begin segment::ContactSegment::getPROC_ID%5AB2A975034C.get preserve=no
        return m_strPROC_ID;
        //## end segment::ContactSegment::getPROC_ID%5AB2A975034C.get
      }

      void setPROC_ID (const string& value)
      {
        //## begin segment::ContactSegment::setPROC_ID%5AB2A975034C.set preserve=no
        m_strPROC_ID = value;
        //## end segment::ContactSegment::setPROC_ID%5AB2A975034C.set
      }


      //## Attribute: REGION%5AB2A9750350
      void setREGION (const string& value)
      {
        //## begin segment::ContactSegment::setREGION%5AB2A9750350.set preserve=no
        m_strREGION = value;
        //## end segment::ContactSegment::setREGION%5AB2A9750350.set
      }


      //## Attribute: RPT_LVL_ID%5AB2A9750354
      const string& getRPT_LVL_ID () const
      {
        //## begin segment::ContactSegment::getRPT_LVL_ID%5AB2A9750354.get preserve=no
        return m_strRPT_LVL_ID;
        //## end segment::ContactSegment::getRPT_LVL_ID%5AB2A9750354.get
      }


      //## Attribute: TSTAMP_UPDATED%5AB2A975035E
      void setTSTAMP_UPDATED (const string& value)
      {
        //## begin segment::ContactSegment::setTSTAMP_UPDATED%5AB2A975035E.set preserve=no
        m_strTSTAMP_UPDATED = value;
        //## end segment::ContactSegment::setTSTAMP_UPDATED%5AB2A975035E.set
      }


      //## Attribute: UPDATED_BY_USER_ID%5AB2A9750362
      void setUPDATED_BY_USER_ID (const string& value)
      {
        //## begin segment::ContactSegment::setUPDATED_BY_USER_ID%5AB2A9750362.set preserve=no
        m_strUPDATED_BY_USER_ID = value;
        //## end segment::ContactSegment::setUPDATED_BY_USER_ID%5AB2A9750362.set
      }


      //## Attribute: USER_ID%5AB2A9750365
      const string& getUSER_ID () const
      {
        //## begin segment::ContactSegment::getUSER_ID%5AB2A9750365.get preserve=no
        return m_strUSER_ID;
        //## end segment::ContactSegment::getUSER_ID%5AB2A9750365.get
      }

      void setUSER_ID (const string& value)
      {
        //## begin segment::ContactSegment::setUSER_ID%5AB2A9750365.set preserve=no
        m_strUSER_ID = value;
        //## end segment::ContactSegment::setUSER_ID%5AB2A9750365.set
      }


    // Additional Public Declarations
      //## begin segment::ContactSegment%5AB2A71701C4.public preserve=yes
      //## end segment::ContactSegment%5AB2A71701C4.public

  protected:
    // Data Members for Class Attributes

      //## begin segment::ContactSegment::ADDRESS_LINE_1%5AB2A97502E8.attr preserve=no  public: string {V}
      string m_strADDRESS_LINE_1;
      //## end segment::ContactSegment::ADDRESS_LINE_1%5AB2A97502E8.attr

      //## begin segment::ContactSegment::ADDRESS_LINE_2%5AB2A97502FB.attr preserve=no  public: string {V}
      string m_strADDRESS_LINE_2;
      //## end segment::ContactSegment::ADDRESS_LINE_2%5AB2A97502FB.attr

      //## Attribute: ADDRESS_LINE_3%5AB2A97502FF
      //## begin segment::ContactSegment::ADDRESS_LINE_3%5AB2A97502FF.attr preserve=no  public: string {V}
      string m_strADDRESS_LINE_3;
      //## end segment::ContactSegment::ADDRESS_LINE_3%5AB2A97502FF.attr

      //## Attribute: ADDRESS_LINE_4%5AB2A9750303
      //## begin segment::ContactSegment::ADDRESS_LINE_4%5AB2A9750303.attr preserve=no  public: string {V}
      string m_strADDRESS_LINE_4;
      //## end segment::ContactSegment::ADDRESS_LINE_4%5AB2A9750303.attr

      //## begin segment::ContactSegment::BIN%5AB2A9750307.attr preserve=no  public: string {U}
      string m_strBIN;
      //## end segment::ContactSegment::BIN%5AB2A9750307.attr

      //## begin segment::ContactSegment::CITY%5AB2A975030A.attr preserve=no  public: string {V}
      string m_strCITY;
      //## end segment::ContactSegment::CITY%5AB2A975030A.attr

      //## begin segment::ContactSegment::ContactInstID%5AB2A975030E.attr preserve=no  public: string {V}
      string m_strContactInstID;
      //## end segment::ContactSegment::ContactInstID%5AB2A975030E.attr

      //## begin segment::ContactSegment::ContactProcID%5AB2A9750311.attr preserve=no  public: string {V}
      string m_strContactProcID;
      //## end segment::ContactSegment::ContactProcID%5AB2A9750311.attr

      //## begin segment::ContactSegment::CONTACT_ID%5AB2AD05001E.attr preserve=no  public: int {V} 0
      int m_lCONTACT_ID;
      //## end segment::ContactSegment::CONTACT_ID%5AB2AD05001E.attr

      //## begin segment::ContactSegment::CONTACT_METHOD%5AB2A9750319.attr preserve=no  public: string {V}
      string m_strCONTACT_METHOD;
      //## end segment::ContactSegment::CONTACT_METHOD%5AB2A9750319.attr

      //## begin segment::ContactSegment::CONTACT_TYPE%5AB2A975031C.attr preserve=no  public: string {U}
      string m_strCONTACT_TYPE;
      //## end segment::ContactSegment::CONTACT_TYPE%5AB2A975031C.attr

      //## Attribute: COUNTRY%5AB2A9750320
      //## begin segment::ContactSegment::COUNTRY%5AB2A9750320.attr preserve=no  public: string {V}
      string m_strCOUNTRY;
      //## end segment::ContactSegment::COUNTRY%5AB2A9750320.attr

      //## begin segment::ContactSegment::COURIER_PTR%5AB2AD05002F.attr preserve=no  public: int {U} 0
      int m_lCOURIER_PTR;
      //## end segment::ContactSegment::COURIER_PTR%5AB2AD05002F.attr

      //## begin segment::ContactSegment::COURIER_ROUTE_PTR%5AB2AD050046.attr preserve=no  public: int {U} 0
      int m_lCOURIER_ROUTE_PTR;
      //## end segment::ContactSegment::COURIER_ROUTE_PTR%5AB2AD050046.attr

      //## begin segment::ContactSegment::DEVICE_ID%5AB2A975032C.attr preserve=no  public: string {V}
      string m_strDEVICE_ID;
      //## end segment::ContactSegment::DEVICE_ID%5AB2A975032C.attr

      //## Attribute: EMAIL_ADDRESS%5AB2A975032F
      //## begin segment::ContactSegment::EMAIL_ADDRESS%5AB2A975032F.attr preserve=no  public: string {V}
      string m_strEMAIL_ADDRESS;
      //## end segment::ContactSegment::EMAIL_ADDRESS%5AB2A975032F.attr

      //## Attribute: FAX_NO%5AB2A9750333
      //## begin segment::ContactSegment::FAX_NO%5AB2A9750333.attr preserve=no  public: string {V}
      string m_strFAX_NO;
      //## end segment::ContactSegment::FAX_NO%5AB2A9750333.attr

      //## begin segment::ContactSegment::INST_ID%5AB2A9750336.attr preserve=no  public: string {V}
      string m_strINST_ID;
      //## end segment::ContactSegment::INST_ID%5AB2A9750336.attr

      //## begin segment::ContactSegment::NAME%5AB2A975033A.attr preserve=no  public: string {V}
      string m_strNAME;
      //## end segment::ContactSegment::NAME%5AB2A975033A.attr

      //## Attribute: ORG_NAME%5AB2A975033E
      //## begin segment::ContactSegment::ORG_NAME%5AB2A975033E.attr preserve=no  public: string {V}
      string m_strORG_NAME;
      //## end segment::ContactSegment::ORG_NAME%5AB2A975033E.attr

      //## begin segment::ContactSegment::POSTAL_CODE%5AB2A9750345.attr preserve=no  public: string {V}
      string m_strPOSTAL_CODE;
      //## end segment::ContactSegment::POSTAL_CODE%5AB2A9750345.attr

      //## begin segment::ContactSegment::PROC_GRP_ID%5AB2A9750349.attr preserve=no  public: string {V}
      string m_strPROC_GRP_ID;
      //## end segment::ContactSegment::PROC_GRP_ID%5AB2A9750349.attr

      //## begin segment::ContactSegment::PROC_ID%5AB2A975034C.attr preserve=no  public: string {V}
      string m_strPROC_ID;
      //## end segment::ContactSegment::PROC_ID%5AB2A975034C.attr

      //## begin segment::ContactSegment::REGION%5AB2A9750350.attr preserve=no  public: string {V}
      string m_strREGION;
      //## end segment::ContactSegment::REGION%5AB2A9750350.attr

      //## begin segment::ContactSegment::RPT_LVL_ID%5AB2A9750354.attr preserve=no  public: string {V}
      string m_strRPT_LVL_ID;
      //## end segment::ContactSegment::RPT_LVL_ID%5AB2A9750354.attr

      //## Attribute: TELEPHONE_NO%5AB2A975035B
      //## begin segment::ContactSegment::TELEPHONE_NO%5AB2A975035B.attr preserve=no  public: string {V}
      string m_strTELEPHONE_NO;
      //## end segment::ContactSegment::TELEPHONE_NO%5AB2A975035B.attr

      //## begin segment::ContactSegment::TSTAMP_UPDATED%5AB2A975035E.attr preserve=no  public: string {V}
      string m_strTSTAMP_UPDATED;
      //## end segment::ContactSegment::TSTAMP_UPDATED%5AB2A975035E.attr

      //## begin segment::ContactSegment::UPDATED_BY_USER_ID%5AB2A9750362.attr preserve=no  public: string {U}
      string m_strUPDATED_BY_USER_ID;
      //## end segment::ContactSegment::UPDATED_BY_USER_ID%5AB2A9750362.attr

      //## begin segment::ContactSegment::USER_ID%5AB2A9750365.attr preserve=no  public: string {V}
      string m_strUSER_ID;
      //## end segment::ContactSegment::USER_ID%5AB2A9750365.attr

    // Additional Protected Declarations
      //## begin segment::ContactSegment%5AB2A71701C4.protected preserve=yes
      //## end segment::ContactSegment%5AB2A71701C4.protected

  private:

    //## Other Operations (specified)
      //## Operation: setFields%5AB2A9480397
      void setFields ();

    // Additional Private Declarations
      //## begin segment::ContactSegment%5AB2A71701C4.private preserve=yes
      //## end segment::ContactSegment%5AB2A71701C4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Origin%5AB2A9750341
      //## begin segment::ContactSegment::Origin%5AB2A9750341.attr preserve=no  private: string {V}
      string m_strOrigin;
      //## end segment::ContactSegment::Origin%5AB2A9750341.attr

      //## Attribute: RPT_LVL_ID_OBSOLETE%5AB2A9750357
      //## begin segment::ContactSegment::RPT_LVL_ID_OBSOLETE%5AB2A9750357.attr preserve=no  public: string {V}
      string m_strRPT_LVL_ID_OBSOLETE;
      //## end segment::ContactSegment::RPT_LVL_ID_OBSOLETE%5AB2A9750357.attr

    // Additional Implementation Declarations
      //## begin segment::ContactSegment%5AB2A71701C4.implementation preserve=yes
      static ContactSegment* m_pInstance[3];
      //## end segment::ContactSegment%5AB2A71701C4.implementation

};

//## begin segment::ContactSegment%5AB2A71701C4.postscript preserve=yes
//## end segment::ContactSegment%5AB2A71701C4.postscript

} // namespace segment

//## begin module%5AB2A7D80391.epilog preserve=yes
//## end module%5AB2A7D80391.epilog


#endif
