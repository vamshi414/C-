//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35B739A80063.cm preserve=no
//	$Date:   May 31 2019 03:32:34  $ $Author:   e5558744  $ $Revision:   1.4  $
//## end module%35B739A80063.cm

//## begin module%35B739A80063.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%35B739A80063.cp

//## Module: CXOSBS12%35B739A80063; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: D:\V02.9D.R001\ConnexPlatform\Server\Library\Bsdll\CXODBS12.hpp

#ifndef CXOSBS12_h
#define CXOSBS12_h 1

//## begin module%35B739A80063.additionalIncludes preserve=no
//## end module%35B739A80063.additionalIncludes

//## begin module%35B739A80063.includes preserve=yes
// $Date:   May 31 2019 03:32:34  $ $Author:   e5558744  $ $Revision:   1.4  $
//## end module%35B739A80063.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
//## begin module%35B739A80063.declarations preserve=no
//## end module%35B739A80063.declarations

//## begin module%35B739A80063.additionalDeclarations preserve=yes
//## end module%35B739A80063.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::PrimaryKeySegment%3453FD810088.preface preserve=yes
//## end segment::PrimaryKeySegment%3453FD810088.preface

//## Class: PrimaryKeySegment%3453FD810088
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport PrimaryKeySegment : public Segment  //## Inherits: <unnamed>%3453FD950159
{
  //## begin segment::PrimaryKeySegment%3453FD810088.initialDeclarations preserve=yes
  //## end segment::PrimaryKeySegment%3453FD810088.initialDeclarations

  public:
    //## Constructors (generated)
      PrimaryKeySegment();

    //## Destructor (generated)
      virtual ~PrimaryKeySegment();


    //## Other Operations (specified)
      //## Operation: fields%3CDFCC5E0222
      virtual struct  Fields* fields () const;

      //## Operation: get%5CEF95F00307
      bool get (string& strTSTAMP_TRANS, short& siUNIQUENESS_KEY) const;

      //## Operation: setPrimaryKey%3CDFCF250261
      void setPrimaryKey (const char* pszPrimaryKey)
      {
        //## begin segment::PrimaryKeySegment::setPrimaryKey%3CDFCF250261.body preserve=yes
        m_strPrimaryKey.assign(pszPrimaryKey);
        //## end segment::PrimaryKeySegment::setPrimaryKey%3CDFCF250261.body
      }

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: PrimaryKey%3CDBFCC10203
      const string& getPrimaryKey () const
      {
        //## begin segment::PrimaryKeySegment::getPrimaryKey%3CDBFCC10203.get preserve=no
        return m_strPrimaryKey;
        //## end segment::PrimaryKeySegment::getPrimaryKey%3CDBFCC10203.get
      }


    // Additional Public Declarations
      //## begin segment::PrimaryKeySegment%3453FD810088.public preserve=yes
      //## end segment::PrimaryKeySegment%3453FD810088.public

  protected:
    // Additional Protected Declarations
      //## begin segment::PrimaryKeySegment%3453FD810088.protected preserve=yes
      //## end segment::PrimaryKeySegment%3453FD810088.protected

  private:
    // Additional Private Declarations
      //## begin segment::PrimaryKeySegment%3453FD810088.private preserve=yes
      //## end segment::PrimaryKeySegment%3453FD810088.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin segment::PrimaryKeySegment::PrimaryKey%3CDBFCC10203.attr preserve=no  public: string {V} 
      string m_strPrimaryKey;
      //## end segment::PrimaryKeySegment::PrimaryKey%3CDBFCC10203.attr

    // Additional Implementation Declarations
      //## begin segment::PrimaryKeySegment%3453FD810088.implementation preserve=yes
      //## end segment::PrimaryKeySegment%3453FD810088.implementation

};

//## begin segment::PrimaryKeySegment%3453FD810088.postscript preserve=yes
//## end segment::PrimaryKeySegment%3453FD810088.postscript

} // namespace segment

//## begin module%35B739A80063.epilog preserve=yes
using namespace segment;
//## end module%35B739A80063.epilog


#endif
