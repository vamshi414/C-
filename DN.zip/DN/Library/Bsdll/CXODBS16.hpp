//	Copyright (c) 1998 - 2004
//	eFunds Corporation
// $Date:   Apr 08 2004 10:49:22  $ $Author:   D02405  $ $Revision:   1.2  $

struct segResponseTimeSegment
{
   char sSegmentID[4];
   char sSegmentVersion[4];
   char sLengthOfSegment[8];
   char sTimestamp[5][16];
   char sReserved[16];
};
