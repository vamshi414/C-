//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4B1D0E7D02AF.cm preserve=no
//	$Date:   Dec 18 2009 09:14:04  $ $Author:   D02405  $
//	$Revision:   1.0  $
//## end module%4B1D0E7D02AF.cm

//## begin module%4B1D0E7D02AF.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4B1D0E7D02AF.cp

//## Module: CXOSBS25%4B1D0E7D02AF; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bsdll\CXOSBS25.cpp

//## begin module%4B1D0E7D02AF.additionalIncludes preserve=no
//## end module%4B1D0E7D02AF.additionalIncludes

//## begin module%4B1D0E7D02AF.includes preserve=yes
//## end module%4B1D0E7D02AF.includes

#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSBS25_h
#include "CXODBS25.hpp"
#endif


//## begin module%4B1D0E7D02AF.declarations preserve=no
//## end module%4B1D0E7D02AF.declarations

//## begin module%4B1D0E7D02AF.additionalDeclarations preserve=yes
#define FIELDS 9
Fields ExportReportAuditSegment_Fields[FIELDS + 1] = 
{
   "a        X","CONTACT",0,0,
   "a        X","DATE_RECON",0,0,
   "a        X","END",0,0,
   "a        X","ENTITY_ID",0,0,
   "a        X","FILE",0,0,
   "a        X","PATH",0,0,
   "a        X","PROC",0,0,
   "a        X","START",0,0,
   "a        X","TIMESTAMP",0,0,
   "~","~",0,0,
};
//## end module%4B1D0E7D02AF.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::ExportReportAuditSegment 

ExportReportAuditSegment::ExportReportAuditSegment()
  //## begin ExportReportAuditSegment::ExportReportAuditSegment%4B1D0D9C038A_const.hasinit preserve=no
  //## end ExportReportAuditSegment::ExportReportAuditSegment%4B1D0D9C038A_const.hasinit
  //## begin ExportReportAuditSegment::ExportReportAuditSegment%4B1D0D9C038A_const.initialization preserve=yes
  //## end ExportReportAuditSegment::ExportReportAuditSegment%4B1D0D9C038A_const.initialization
{
  //## begin segment::ExportReportAuditSegment::ExportReportAuditSegment%4B1D0D9C038A_const.body preserve=yes
   memcpy(m_sID,"RF08",4);
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strContact;
   m_pField[1] = &m_strDATE_RECON;
   m_pField[2] = &m_strEnd;
   m_pField[3] = &m_strENTITY_ID;
   m_pField[4] = &m_strFile;
   m_pField[5] = &m_strPath;
   m_pField[6] = &m_strServer;
   m_pField[7] = &m_strStart;
   m_pField[8] = &m_strTimestamp;
   m_strTimestamp = Timestamp::format(Clock::instance()->getYYYYMMDDHHMMSS());
  //## end segment::ExportReportAuditSegment::ExportReportAuditSegment%4B1D0D9C038A_const.body
}


ExportReportAuditSegment::~ExportReportAuditSegment()
{
  //## begin segment::ExportReportAuditSegment::~ExportReportAuditSegment%4B1D0D9C038A_dest.body preserve=yes
   delete [] m_pField;
  //## end segment::ExportReportAuditSegment::~ExportReportAuditSegment%4B1D0D9C038A_dest.body
}



//## Other Operations (implementation)
struct  Fields* ExportReportAuditSegment::fields () const
{
  //## begin segment::ExportReportAuditSegment::fields%4B1D0DE9033C.body preserve=yes
   return &ExportReportAuditSegment_Fields[0];
  //## end segment::ExportReportAuditSegment::fields%4B1D0DE9033C.body
}

// Additional Declarations
  //## begin segment::ExportReportAuditSegment%4B1D0D9C038A.declarations preserve=yes
  //## end segment::ExportReportAuditSegment%4B1D0D9C038A.declarations

} // namespace segment

//## begin module%4B1D0E7D02AF.epilog preserve=yes
//## end module%4B1D0E7D02AF.epilog
