//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%359CF3B7026C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%359CF3B7026C.cm

//## begin module%359CF3B7026C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%359CF3B7026C.cp

//## Module: CXOSBS09%359CF3B7026C; Package specification
//## Subsystem: BSDLL%394E1F8C0345
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bsdll\CXODBS09.hpp

#ifndef CXOSBS09_h
#define CXOSBS09_h 1

//## begin module%359CF3B7026C.additionalIncludes preserve=no
//## end module%359CF3B7026C.additionalIncludes

//## begin module%359CF3B7026C.includes preserve=yes
// $Date:   Feb 25 2021 10:15:38  $ $Author:   e1089842  $ $Revision:   1.14  $
#include "CXODRU24.hpp"
//## end module%359CF3B7026C.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;

} // namespace reusable

//## begin module%359CF3B7026C.declarations preserve=no
//## end module%359CF3B7026C.declarations

//## begin module%359CF3B7026C.additionalDeclarations preserve=yes
//## end module%359CF3B7026C.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::InformationSegment%34548B6700E4.preface preserve=yes
//## end segment::InformationSegment%34548B6700E4.preface

//## Class: InformationSegment%34548B6700E4
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3D186106003E;reusable::Transaction { -> F}

class DllExport InformationSegment : public Segment  //## Inherits: <unnamed>%34548B790194
{
  //## begin segment::InformationSegment%34548B6700E4.initialDeclarations preserve=yes
  //## end segment::InformationSegment%34548B6700E4.initialDeclarations

  public:
    //## Constructors (generated)
      InformationSegment();

    //## Destructor (generated)
      virtual ~InformationSegment();


    //## Other Operations (specified)
      //## Operation: deport%3D185EED02EE
      virtual int deport (char** ppsBuffer);

      //## Operation: import%3D185EF000CB
      virtual int import (char** ppsBuffer);

      //## Operation: instance%41925C2A0290
      static InformationSegment* instance ();

      //## Operation: setError%34632D4F0142
      void setError (char cSeverityLevel, int lErrorNumber, const char* pszText = 0);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ErrorNumber%3D185149007D
      const int getErrorNumber () const
      {
        //## begin segment::InformationSegment::getErrorNumber%3D185149007D.get preserve=no
        return m_lErrorNumber;
        //## end segment::InformationSegment::getErrorNumber%3D185149007D.get
      }

      void setErrorNumber (int value)
      {
        //## begin segment::InformationSegment::setErrorNumber%3D185149007D.set preserve=no
        m_lErrorNumber = value;
        //## end segment::InformationSegment::setErrorNumber%3D185149007D.set
      }


      //## Attribute: SeverityLevel%3D185128038A
      const char getSeverityLevel () const
      {
        //## begin segment::InformationSegment::getSeverityLevel%3D185128038A.get preserve=no
        return m_cSeverityLevel;
        //## end segment::InformationSegment::getSeverityLevel%3D185128038A.get
      }

      void setSeverityLevel (char value)
      {
        //## begin segment::InformationSegment::setSeverityLevel%3D185128038A.set preserve=no
        m_cSeverityLevel = value;
        //## end segment::InformationSegment::setSeverityLevel%3D185128038A.set
      }


      //## Attribute: Text%3D185164008C
      const string& getText () const
      {
        //## begin segment::InformationSegment::getText%3D185164008C.get preserve=no
        return m_strText;
        //## end segment::InformationSegment::getText%3D185164008C.get
      }

      void setText (const string& value)
      {
        //## begin segment::InformationSegment::setText%3D185164008C.set preserve=no
        m_strText = value;
        //## end segment::InformationSegment::setText%3D185164008C.set
      }


    // Additional Public Declarations
      //## begin segment::InformationSegment%34548B6700E4.public preserve=yes
      //## end segment::InformationSegment%34548B6700E4.public

  protected:
    // Additional Protected Declarations
      //## begin segment::InformationSegment%34548B6700E4.protected preserve=yes
      //## end segment::InformationSegment%34548B6700E4.protected

  private:
    // Additional Private Declarations
      //## begin segment::InformationSegment%34548B6700E4.private preserve=yes
      //## end segment::InformationSegment%34548B6700E4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin segment::InformationSegment::ErrorNumber%3D185149007D.attr preserve=no  public: int {V} 0
      int m_lErrorNumber;
      //## end segment::InformationSegment::ErrorNumber%3D185149007D.attr

      //## Attribute: Instance%41925C000177
      //## begin segment::InformationSegment::Instance%41925C000177.attr preserve=no  private: static InformationSegment* {V} 0
      static InformationSegment* m_pInstance;
      //## end segment::InformationSegment::Instance%41925C000177.attr

      //## begin segment::InformationSegment::SeverityLevel%3D185128038A.attr preserve=no  public: char {V} STS_INFORMATION
      char m_cSeverityLevel;
      //## end segment::InformationSegment::SeverityLevel%3D185128038A.attr

      //## begin segment::InformationSegment::Text%3D185164008C.attr preserve=no  public: string {V}
      string m_strText;
      //## end segment::InformationSegment::Text%3D185164008C.attr

    // Additional Implementation Declarations
      //## begin segment::InformationSegment%34548B6700E4.implementation preserve=yes
      //## end segment::InformationSegment%34548B6700E4.implementation

};

//## begin segment::InformationSegment%34548B6700E4.postscript preserve=yes
//## end segment::InformationSegment%34548B6700E4.postscript

} // namespace segment

//## begin module%359CF3B7026C.epilog preserve=yes
#ifndef parse_errors
#define parse_errors
#define STS_PARSE_ERROR 300
#define STS_QUERY_ERROR 301
#define STS_SESSION_ERROR 302
#define STS_SECURITY_ERROR 303
#endif

// Severity levels

#define STS_INFORMATION '1'
#define STS_WARNING '5'
#define STS_ERROR '7'
#define STS_SEVERE_ERROR '9'

// Info ID numbers

#define STS_INVALID_LENGTH 1
#define STS_MISSING_COMMON_HEADER_SEGMENT 2
#define STS_INVALID_VERSION_NUMBER 3
#define STS_INVALID_SEGMENT_LENGTH 4
#define STS_INVALID_SEGMENT_ID 6
#define STS_QUERY_ENGINE_UNAVAILABLE 11
#define STS_MISSING_PRIMARYKEY_SEGMENT 12
#define STS_INVALID_CONTEXT_DATA 13
#define STS_RECORD_NOT_FOUND 14
#define STS_DATABASE_FAILURE 15
#define STS_MISSING_MULTIPLEROWCONTEXT_SEGMENT 16
#define STS_MISSING_GETTRANSACTIONLIST_SEGMENT 17
#define STS_USER_ALREADY_LOGGED_ON 18
#define STS_PASSWORD_MISMATCH 22
#define STS_MISSING_GETSTATUS_SEGMENT 28
#define STS_MISSING_CASE_SEGMENT 30
#define STS_DUPLICATE_RECORD 35
#define STS_MISSING_LIST_SEGMENT 36
#define STS_SECURITY_NOT_FOUND 37
#define STS_INVALID_CUST_ID 38
#define STS_ACCESS_TO_DATA_DENIED 39
#define STS_INVALID_CASE_EXTENSION 44
#define STS_MISSING_CONTACT_SEGMENT 45
#define STS_MISSING_CONTACT_SEARCH_SEGMENT 47
#define STS_REQUESTER_CONTACT_NOT_FOUND 49
#define STS_RECEIVER_CONTACT_NOT_FOUND 50
#define STS_REQUESTER_TEMPLATE_OPEN_FAILURE 51
#define STS_RECEIVER_TEMPLATE_OPEN_FAILURE 52
#define STS_SMTP_OPEN_FAILURE 53
#define STS_MISSING_WORK_QUEUE_SEGMENT 55
#define STS_USER_ID_NOT_FOUND 57
#define STS_INSTITUTION_ID_NOT_FOUND 58
#define STS_PROCESSOR_ID_NOT_FOUND 59
#define STS_CUSTOMER_ID_NOT_FOUND 60
#define STS_INVALID_TOTALS_DATE 64
#define STS_MISSING_CUSTOMER_PERIOD 65
#define STS_COURIER_ID_NOT_FOUND 69
#define STS_COURIER_ROUTE_ID_NOT_FOUND 70
#define STS_ACTION_FAILED_RECORD_MODIFIED 71
#define STS_CANT_DELETE_EXISTING_DATA_FOUND 76
#define STS_MISSING_GETPAUTH_SEGMENT 87
#define STS_REFERENTIAL_INTEGRITY_ERROR 91
#define STS_UNDEFINED_NAME 92
#define STS_MAKER_REC_NOT_FOUND 99
#define STS_RPT_LVL_ID_NOT_FOUND 102
#define STS_DEVICE_ID_NOT_FOUND 106
#define STS_PROC_GRP_ID_NOT_FOUND 107
#define STS_MISSING_USERBATCH_SEGMENT 109
#define STS_CHB_COUNTER_EXCEEDS 115
#define STS_CHB_MONTHLY_COUNTER_EXCEEDS 116

// Note: add new error codes to MISC_CFG_DATA data with a CFG_DATA_TYPE of ERROR_MSGS and a DATA_VALUE of the error code + 2000.

using namespace segment;
//## end module%359CF3B7026C.epilog


#endif
