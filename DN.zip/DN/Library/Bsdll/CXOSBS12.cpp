//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35B739AA00AC.cm preserve=no
//	$Date:   May 31 2019 03:31:28  $ $Author:   e5558744  $ $Revision:   1.6  $
//## end module%35B739AA00AC.cm

//## begin module%35B739AA00AC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%35B739AA00AC.cp

//## Module: CXOSBS12%35B739AA00AC; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: D:\V02.9D.R001\ConnexPlatform\Server\Library\Bsdll\CXOSBS12.cpp

//## begin module%35B739AA00AC.additionalIncludes preserve=no
//## end module%35B739AA00AC.additionalIncludes

//## begin module%35B739AA00AC.includes preserve=yes
// $Date:   May 31 2019 03:31:28  $ $Author:   e5558744  $ $Revision:   1.6  $
#include "CXODBS17.hpp"
#include "CXODBS09.hpp"
//## end module%35B739AA00AC.includes

#ifndef CXOSBS12_h
#include "CXODBS12.hpp"
#endif
//## begin module%35B739AA00AC.declarations preserve=no
//## end module%35B739AA00AC.declarations

//## begin module%35B739AA00AC.additionalDeclarations preserve=yes
struct segPrimaryKeySegment* pSegPrimaryKeySegment = 0;
#define FIELDS 1
Fields PrimaryKeySegment_Fields[FIELDS + 1] =
{
   "a         ","PrimaryKey",offsetof(segPrimaryKeySegment,sPrimaryKey),sizeof(pSegPrimaryKeySegment->sPrimaryKey),
   "~","~",0,sizeof(segPrimaryKeySegment),
};
//## end module%35B739AA00AC.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::PrimaryKeySegment 

PrimaryKeySegment::PrimaryKeySegment()
  //## begin PrimaryKeySegment::PrimaryKeySegment%3453FD810088_const.hasinit preserve=no
  //## end PrimaryKeySegment::PrimaryKeySegment%3453FD810088_const.hasinit
  //## begin PrimaryKeySegment::PrimaryKeySegment%3453FD810088_const.initialization preserve=yes
   : Segment("S101")
  //## end PrimaryKeySegment::PrimaryKeySegment%3453FD810088_const.initialization
{
  //## begin segment::PrimaryKeySegment::PrimaryKeySegment%3453FD810088_const.body preserve=yes
   memcpy(m_sID,"BS12",4);
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strPrimaryKey;
  //## end segment::PrimaryKeySegment::PrimaryKeySegment%3453FD810088_const.body
}


PrimaryKeySegment::~PrimaryKeySegment()
{
  //## begin segment::PrimaryKeySegment::~PrimaryKeySegment%3453FD810088_dest.body preserve=yes
   delete [] m_pField;
  //## end segment::PrimaryKeySegment::~PrimaryKeySegment%3453FD810088_dest.body
}



//## Other Operations (implementation)
struct  Fields* PrimaryKeySegment::fields () const
{
  //## begin segment::PrimaryKeySegment::fields%3CDFCC5E0222.body preserve=yes
   return &PrimaryKeySegment_Fields[0];
  //## end segment::PrimaryKeySegment::fields%3CDFCC5E0222.body
}

bool PrimaryKeySegment::get (string& strTSTAMP_TRANS, short& siUNIQUENESS_KEY) const
{
  //## begin segment::PrimaryKeySegment::get%5CEF95F00307.body preserve=yes
   if (m_strPrimaryKey.length() < 17)
      return false;
   strTSTAMP_TRANS.assign(m_strPrimaryKey.data(), 16);   
   siUNIQUENESS_KEY = ::atoi(m_strPrimaryKey.substr(16, max(size_t(8), (m_strPrimaryKey.length() - size_t(16)))).c_str());
   return true;
  //## end segment::PrimaryKeySegment::get%5CEF95F00307.body
}

// Additional Declarations
  //## begin segment::PrimaryKeySegment%3453FD810088.declarations preserve=yes
  //## end segment::PrimaryKeySegment%3453FD810088.declarations

} // namespace segment

//## begin module%35B739AA00AC.epilog preserve=yes
//## end module%35B739AA00AC.epilog
