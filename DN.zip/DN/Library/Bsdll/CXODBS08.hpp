//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%37E79A0E0130.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%37E79A0E0130.cm

//## begin module%37E79A0E0130.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%37E79A0E0130.cp

//## Module: CXOSBS08%37E79A0E0130; Package specification
//## Subsystem: BSDLL%394E1F8C0345
//## Source file: C:\Pvcswork\Dn\Server\Library\Bsdll\CXODBS08.hpp

#ifndef CXOSBS08_h
#define CXOSBS08_h 1

//## begin module%37E79A0E0130.additionalIncludes preserve=no
//## end module%37E79A0E0130.additionalIncludes

//## begin module%37E79A0E0130.includes preserve=yes
// $Date:   18 Jan 2018 14:11:36  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%37E79A0E0130.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif

//## Modelname: Connex Foundation::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;

} // namespace segment

//## begin module%37E79A0E0130.declarations preserve=no
//## end module%37E79A0E0130.declarations

//## begin module%37E79A0E0130.additionalDeclarations preserve=yes
//## end module%37E79A0E0130.additionalDeclarations


namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::ListResultsSegment%37E799D1033B.preface preserve=yes
//## end segment::ListResultsSegment%37E799D1033B.preface

//## Class: ListResultsSegment%37E799D1033B
//## Category: Connex Foundation::Segment_CAT%3471F0BE0219
//## Subsystem: BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%37E7A2C80269;InformationSegment { -> F}

class DllExport ListResultsSegment : public Segment  //## Inherits: <unnamed>%37E799E9003C
{
  //## begin segment::ListResultsSegment%37E799D1033B.initialDeclarations preserve=yes
  //## end segment::ListResultsSegment%37E799D1033B.initialDeclarations

  public:
    //## Constructors (generated)
      ListResultsSegment();

    //## Destructor (generated)
      virtual ~ListResultsSegment();


    //## Other Operations (specified)
      //## Operation: operator char*%37E7A1FF020F
      operator char* () const
      {
        //## begin segment::ListResultsSegment::operator char*%37E7A1FF020F.body preserve=yes
         return m_pFirstItem;
        //## end segment::ListResultsSegment::operator char*%37E7A1FF020F.body
      }

      //## Operation: deport%37E79F2202FC
      virtual int deport (char** ppsBuffer);

      //## Operation: import%37E79F260030
      virtual int import (char** ppsBuffer);

      //## Operation: update%37E79F2A0145
      void update (char* psBuffer, int lCount, int lLength);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ItemCount%37E7A16802DB
      const int getItemCount () const
      {
        //## begin segment::ListResultsSegment::getItemCount%37E7A16802DB.get preserve=no
        return m_lItemCount;
        //## end segment::ListResultsSegment::getItemCount%37E7A16802DB.get
      }


      //## Attribute: RowSize%37E7A2590042
      const int getRowSize () const
      {
        //## begin segment::ListResultsSegment::getRowSize%37E7A2590042.get preserve=no
        return m_lRowSize;
        //## end segment::ListResultsSegment::getRowSize%37E7A2590042.get
      }


    // Additional Public Declarations
      //## begin segment::ListResultsSegment%37E799D1033B.public preserve=yes
      //## end segment::ListResultsSegment%37E799D1033B.public

  protected:
    // Additional Protected Declarations
      //## begin segment::ListResultsSegment%37E799D1033B.protected preserve=yes
      //## end segment::ListResultsSegment%37E799D1033B.protected

  private:
    // Additional Private Declarations
      //## begin segment::ListResultsSegment%37E799D1033B.private preserve=yes
      //## end segment::ListResultsSegment%37E799D1033B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin segment::ListResultsSegment::ItemCount%37E7A16802DB.attr preserve=no  public: int {V} 0
      int m_lItemCount;
      //## end segment::ListResultsSegment::ItemCount%37E7A16802DB.attr

      //## begin segment::ListResultsSegment::RowSize%37E7A2590042.attr preserve=no  public: int {V} 0
      int m_lRowSize;
      //## end segment::ListResultsSegment::RowSize%37E7A2590042.attr

      //## Attribute: FirstItem%37E7A27F0029
      //## begin segment::ListResultsSegment::FirstItem%37E7A27F0029.attr preserve=no  private: char {R} 0
      char *m_pFirstItem;
      //## end segment::ListResultsSegment::FirstItem%37E7A27F0029.attr

    // Additional Implementation Declarations
      //## begin segment::ListResultsSegment%37E799D1033B.implementation preserve=yes
      //## end segment::ListResultsSegment%37E799D1033B.implementation

};

//## begin segment::ListResultsSegment%37E799D1033B.postscript preserve=yes
//## end segment::ListResultsSegment%37E799D1033B.postscript

} // namespace segment

//## begin module%37E79A0E0130.epilog preserve=yes
using namespace segment;
//## end module%37E79A0E0130.epilog


#endif
