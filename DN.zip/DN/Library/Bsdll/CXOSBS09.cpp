//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%359CF3B90138.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%359CF3B90138.cm

//## begin module%359CF3B90138.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%359CF3B90138.cp

//## Module: CXOSBS09%359CF3B90138; Package body
//## Subsystem: BSDLL%394E1F8C0345
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bsdll\CXOSBS09.cpp

//## begin module%359CF3B90138.additionalIncludes preserve=no
//## end module%359CF3B90138.additionalIncludes

//## begin module%359CF3B90138.includes preserve=yes
// $Date:   May 14 2020 17:56:16  $ $Author:   e1009510  $ $Revision:   1.11  $
#include <stdio.h>
#include "CXODBS20.hpp"
//## end module%359CF3B90138.includes

#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif


//## begin module%359CF3B90138.declarations preserve=no
//## end module%359CF3B90138.declarations

//## begin module%359CF3B90138.additionalDeclarations preserve=yes
//## end module%359CF3B90138.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::InformationSegment 

//## begin segment::InformationSegment::Instance%41925C000177.attr preserve=no  private: static segment::InformationSegment* {V} 0
segment::InformationSegment* InformationSegment::m_pInstance = 0;
//## end segment::InformationSegment::Instance%41925C000177.attr

InformationSegment::InformationSegment()
  //## begin InformationSegment::InformationSegment%34548B6700E4_const.hasinit preserve=no
      : m_lErrorNumber(0),
        m_cSeverityLevel(STS_INFORMATION)
  //## end InformationSegment::InformationSegment%34548B6700E4_const.hasinit
  //## begin InformationSegment::InformationSegment%34548B6700E4_const.initialization preserve=yes
   ,Segment("S052")
  //## end InformationSegment::InformationSegment%34548B6700E4_const.initialization
{
  //## begin segment::InformationSegment::InformationSegment%34548B6700E4_const.body preserve=yes
   memcpy_s(m_sID,4,"BS09",4);
  //## end segment::InformationSegment::InformationSegment%34548B6700E4_const.body
}


InformationSegment::~InformationSegment()
{
  //## begin segment::InformationSegment::~InformationSegment%34548B6700E4_dest.body preserve=yes
  //## end segment::InformationSegment::~InformationSegment%34548B6700E4_dest.body
}



//## Other Operations (implementation)
int InformationSegment::deport (char** ppsBuffer)
{
  //## begin segment::InformationSegment::deport%3D185EED02EE.body preserve=yes
   segInformationSegment* pSegment = (segInformationSegment*)*ppsBuffer;
   memset(pSegment,' ',sizeof(segInformationSegment) - 2);
   memcpy_s(pSegment->sSegmentID,4,segmentID(),4);
   memcpy_s(pSegment->sSegmentVersion,4,"0100",4);
   char szTemp[PERCENTD];
   if (m_strText.length() == 0)
   {
      if (Transaction::instance()->getText().length() > 0)
         m_strText = Transaction::instance()->getText();
   }
   unsigned int m = m_strText.length();
   snprintf(szTemp,sizeof(szTemp),"%04d",m);
   memcpy_s(pSegment->sLengthOfText,4,szTemp,4);
   m += min((sizeof(segInformationSegment) - 2), (std::size_t)(UINT_MAX - m));
   snprintf(szTemp,sizeof(szTemp),"%08d",m);
   memcpy_s(pSegment->sLengthOfSegment,8,szTemp,8);
   pSegment->cSeverityLevel = m_cSeverityLevel;
   snprintf(szTemp,sizeof(szTemp),"%08d",m_lErrorNumber);
   memcpy_s(pSegment->sErrorNumber,8,szTemp,8);
   pSegment->cFormatCode = (m_strText.length() == 0) ? '0' : '1';
   memcpy_s(pSegment->sText, m_strText.length(),m_strText.data(),m_strText.length());
   *ppsBuffer += m;
   return 0;
  //## end segment::InformationSegment::deport%3D185EED02EE.body
}

int InformationSegment::import (char** ppsBuffer)
{
  //## begin segment::InformationSegment::import%3D185EF000CB.body preserve=yes
   segInformationSegment* pSegment = (segInformationSegment*)*ppsBuffer;
   if (memcmp(pSegment->sSegmentVersion,"0100",4))
      return STS_INVALID_VERSION_NUMBER;
   setPresence(true);
   m_cSeverityLevel = pSegment->cSeverityLevel;
   m_lErrorNumber = atoi(pSegment->sErrorNumber,8);
   m_strText.assign(pSegment->sText,atoi(pSegment->sLengthOfText,4));
   *ppsBuffer += atol(pSegment->sLengthOfSegment,8);
   return 0;
  //## end segment::InformationSegment::import%3D185EF000CB.body
}

segment::InformationSegment* InformationSegment::instance ()
{
  //## begin segment::InformationSegment::instance%41925C2A0290.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new InformationSegment();
   return m_pInstance;
  //## end segment::InformationSegment::instance%41925C2A0290.body
}

void InformationSegment::setError (char cSeverityLevel, int lErrorNumber, const char* pszText)
{
  //## begin segment::InformationSegment::setError%34632D4F0142.body preserve=yes
   m_cSeverityLevel = cSeverityLevel;
   m_lErrorNumber = lErrorNumber;
   if (pszText)
      m_strText = pszText;
  //## end segment::InformationSegment::setError%34632D4F0142.body
}

// Additional Declarations
  //## begin segment::InformationSegment%34548B6700E4.declarations preserve=yes
  //## end segment::InformationSegment%34548B6700E4.declarations

} // namespace segment

//## begin module%359CF3B90138.epilog preserve=yes
//## end module%359CF3B90138.epilog
