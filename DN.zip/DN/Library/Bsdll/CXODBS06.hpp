//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3597E59A0191.cm preserve=no
//	$Date:   Oct 11 2021 13:35:02  $ $Author:   e1009510  $ $Revision:   1.138  $
//## end module%3597E59A0191.cm

//## begin module%3597E59A0191.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3597E59A0191.cp

//## Module: CXOSBS06%3597E59A0191; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS06.hpp

#ifndef CXOSBS06_h
#define CXOSBS06_h 1

//## begin module%3597E59A0191.additionalIncludes preserve=no
//## end module%3597E59A0191.additionalIncludes

//## begin module%3597E59A0191.includes preserve=yes
//## end module%3597E59A0191.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Global;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class GlobalContext;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;

} // namespace segment

//## begin module%3597E59A0191.declarations preserve=no
//## end module%3597E59A0191.declarations

//## begin module%3597E59A0191.additionalDeclarations preserve=yes
//## end module%3597E59A0191.additionalDeclarations


namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::CommonHeaderSegment%3453FD6102B3.preface preserve=yes
//## end segment::CommonHeaderSegment%3453FD6102B3.preface

//## Class: CommonHeaderSegment%3453FD6102B3
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%38298FA50040;database::Database { -> F}
//## Uses: <unnamed>%38298FA80211;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%38AC6FCB0135;InformationSegment { -> F}
//## Uses: <unnamed>%38AC74BC0170;reusable::Global { -> F}
//## Uses: <unnamed>%457DAEF90128;database::GlobalContext { -> F}
//## Uses: <unnamed>%457F17770109;IF::Extract { -> F}

class DllExport CommonHeaderSegment : public Segment  //## Inherits: <unnamed>%34625BA9030D
{
  //## begin segment::CommonHeaderSegment%3453FD6102B3.initialDeclarations preserve=yes
  //## end segment::CommonHeaderSegment%3453FD6102B3.initialDeclarations

  public:
    //## Constructors (generated)
      CommonHeaderSegment();

      CommonHeaderSegment(const CommonHeaderSegment &right);

    //## Destructor (generated)
      virtual ~CommonHeaderSegment();

    //## Assignment Operation (generated)
      CommonHeaderSegment & operator=(const CommonHeaderSegment &right);


    //## Other Operations (specified)
      //## Operation: deport%37BAD0B6003A
      virtual int deport (char** ppsBuffer);

      //## Operation: fields%3A0C10A60049
      virtual struct Fields* fields () const;

      //## Operation: import%37BAD0B8014B
      virtual int import (char** ppsBuffer);

      //## Operation: instance%37BAF7210371
      static CommonHeaderSegment* instance (Object* pSender = 0);

      //## Operation: replicate%457DAE8D0128
      virtual void replicate ();

      //## Operation: size%3A0C10CB00D9
      static int size ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Alias%4280C71E0148
      const string& getAlias () const
      {
        //## begin segment::CommonHeaderSegment::getAlias%4280C71E0148.get preserve=no
        return m_strAlias;
        //## end segment::CommonHeaderSegment::getAlias%4280C71E0148.get
      }

      void setAlias (const string& value)
      {
        //## begin segment::CommonHeaderSegment::setAlias%4280C71E0148.set preserve=no
        m_strAlias = value;
        //## end segment::CommonHeaderSegment::setAlias%4280C71E0148.set
      }


      //## Attribute: ClientVersion%37BAF74B003D
      const string& getClientVersion () const
      {
        //## begin segment::CommonHeaderSegment::getClientVersion%37BAF74B003D.get preserve=no
        return m_strClientVersion;
        //## end segment::CommonHeaderSegment::getClientVersion%37BAF74B003D.get
      }

      void setClientVersion (const string& value)
      {
        //## begin segment::CommonHeaderSegment::setClientVersion%37BAF74B003D.set preserve=no
        m_strClientVersion = value;
        //## end segment::CommonHeaderSegment::setClientVersion%37BAF74B003D.set
      }


      //## Attribute: CUST_ID%3E9DB1840213
      const string& getCUST_ID () const
      {
        //## begin segment::CommonHeaderSegment::getCUST_ID%3E9DB1840213.get preserve=no
        return m_strCUST_ID;
        //## end segment::CommonHeaderSegment::getCUST_ID%3E9DB1840213.get
      }

      void setCUST_ID (const string& value)
      {
        //## begin segment::CommonHeaderSegment::setCUST_ID%3E9DB1840213.set preserve=no
        m_strCUST_ID = value;
        //## end segment::CommonHeaderSegment::setCUST_ID%3E9DB1840213.set
      }


      //## Attribute: ExternalContextData%37BAD0E102D1
      const string& getExternalContextData () const
      {
        //## begin segment::CommonHeaderSegment::getExternalContextData%37BAD0E102D1.get preserve=no
        return m_strExternalContextData;
        //## end segment::CommonHeaderSegment::getExternalContextData%37BAD0E102D1.get
      }

      void setExternalContextData (const string& value)
      {
        //## begin segment::CommonHeaderSegment::setExternalContextData%37BAD0E102D1.set preserve=no
        m_strExternalContextData = value;
        //## end segment::CommonHeaderSegment::setExternalContextData%37BAD0E102D1.set
      }


      //## Attribute: PROC_DEST_ID%457F0DAA034B
      const string& getPROC_DEST_ID () const
      {
        //## begin segment::CommonHeaderSegment::getPROC_DEST_ID%457F0DAA034B.get preserve=no
        return m_strPROC_DEST_ID;
        //## end segment::CommonHeaderSegment::getPROC_DEST_ID%457F0DAA034B.get
      }

      void setPROC_DEST_ID (const string& value)
      {
        //## begin segment::CommonHeaderSegment::setPROC_DEST_ID%457F0DAA034B.set preserve=no
        m_strPROC_DEST_ID = value;
        //## end segment::CommonHeaderSegment::setPROC_DEST_ID%457F0DAA034B.set
      }


      //## Attribute: ResultCode%37BAD15701EA
      const int getResultCode () const
      {
        //## begin segment::CommonHeaderSegment::getResultCode%37BAD15701EA.get preserve=no
        return m_iResultCode;
        //## end segment::CommonHeaderSegment::getResultCode%37BAD15701EA.get
      }

      void setResultCode (int value)
      {
        //## begin segment::CommonHeaderSegment::setResultCode%37BAD15701EA.set preserve=no
        m_iResultCode = value;
        //## end segment::CommonHeaderSegment::setResultCode%37BAD15701EA.set
      }


      //## Attribute: SecurityData%37BAD15603D4
      const string& getSecurityData () const
      {
        //## begin segment::CommonHeaderSegment::getSecurityData%37BAD15603D4.get preserve=no
        return m_strSecurityData;
        //## end segment::CommonHeaderSegment::getSecurityData%37BAD15603D4.get
      }

      void setSecurityData (const string& value)
      {
        //## begin segment::CommonHeaderSegment::setSecurityData%37BAD15603D4.set preserve=no
        m_strSecurityData = value;
        //## end segment::CommonHeaderSegment::setSecurityData%37BAD15603D4.set
      }


      //## Attribute: ServiceName%37BAD15700C8
      const string& getServiceName () const
      {
        //## begin segment::CommonHeaderSegment::getServiceName%37BAD15700C8.get preserve=no
        return m_strServiceName;
        //## end segment::CommonHeaderSegment::getServiceName%37BAD15700C8.get
      }

      void setServiceName (const string& value)
      {
        //## begin segment::CommonHeaderSegment::setServiceName%37BAD15700C8.set preserve=no
        m_strServiceName = value;
        //## end segment::CommonHeaderSegment::setServiceName%37BAD15700C8.set
      }


      //## Attribute: UserID%3A0C112101CD
      const string& getUserID () const
      {
        //## begin segment::CommonHeaderSegment::getUserID%3A0C112101CD.get preserve=no
        return m_strUserID;
        //## end segment::CommonHeaderSegment::getUserID%3A0C112101CD.get
      }

      void setUserID (const string& value)
      {
        //## begin segment::CommonHeaderSegment::setUserID%3A0C112101CD.set preserve=no
        m_strUserID = value;
        //## end segment::CommonHeaderSegment::setUserID%3A0C112101CD.set
      }


      //## Attribute: Source%5B1043BB0376
      const string& getSource () const
      {
        //## begin segment::CommonHeaderSegment::getSource%5B1043BB0376.get preserve=no
        return m_strSource;
        //## end segment::CommonHeaderSegment::getSource%5B1043BB0376.get
      }

      void setSource (const string& value)
      {
        //## begin segment::CommonHeaderSegment::setSource%5B1043BB0376.set preserve=no
        m_strSource = value;
        //## end segment::CommonHeaderSegment::setSource%5B1043BB0376.set
      }


    // Additional Public Declarations
      //## begin segment::CommonHeaderSegment%3453FD6102B3.public preserve=yes
      //## end segment::CommonHeaderSegment%3453FD6102B3.public

  protected:
    // Additional Protected Declarations
      //## begin segment::CommonHeaderSegment%3453FD6102B3.protected preserve=yes
      //## end segment::CommonHeaderSegment%3453FD6102B3.protected

  private:
    // Additional Private Declarations
      //## begin segment::CommonHeaderSegment%3453FD6102B3.private preserve=yes
      //## end segment::CommonHeaderSegment%3453FD6102B3.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin segment::CommonHeaderSegment::Alias%4280C71E0148.attr preserve=no  public: string {V} 
      string m_strAlias;
      //## end segment::CommonHeaderSegment::Alias%4280C71E0148.attr

      //## begin segment::CommonHeaderSegment::ClientVersion%37BAF74B003D.attr preserve=no  public: string {V} 
      string m_strClientVersion;
      //## end segment::CommonHeaderSegment::ClientVersion%37BAF74B003D.attr

      //## begin segment::CommonHeaderSegment::CUST_ID%3E9DB1840213.attr preserve=no  public: string {V} 
      string m_strCUST_ID;
      //## end segment::CommonHeaderSegment::CUST_ID%3E9DB1840213.attr

      //## begin segment::CommonHeaderSegment::ExternalContextData%37BAD0E102D1.attr preserve=no  public: string {V} 
      string m_strExternalContextData;
      //## end segment::CommonHeaderSegment::ExternalContextData%37BAD0E102D1.attr

      //## Attribute: Instance%37BAF6F403A9
      //## begin segment::CommonHeaderSegment::Instance%37BAF6F403A9.attr preserve=no  private: static CommonHeaderSegment {R} 0
      static CommonHeaderSegment *m_pInstance;
      //## end segment::CommonHeaderSegment::Instance%37BAF6F403A9.attr

      //## begin segment::CommonHeaderSegment::PROC_DEST_ID%457F0DAA034B.attr preserve=no  public: string {V} 
      string m_strPROC_DEST_ID;
      //## end segment::CommonHeaderSegment::PROC_DEST_ID%457F0DAA034B.attr

      //## begin segment::CommonHeaderSegment::ResultCode%37BAD15701EA.attr preserve=no  public: int {V} 0
      int m_iResultCode;
      //## end segment::CommonHeaderSegment::ResultCode%37BAD15701EA.attr

      //## begin segment::CommonHeaderSegment::SecurityData%37BAD15603D4.attr preserve=no  public: string {V} 
      string m_strSecurityData;
      //## end segment::CommonHeaderSegment::SecurityData%37BAD15603D4.attr

      //## begin segment::CommonHeaderSegment::ServiceName%37BAD15700C8.attr preserve=no  public: string {V} 
      string m_strServiceName;
      //## end segment::CommonHeaderSegment::ServiceName%37BAD15700C8.attr

      //## begin segment::CommonHeaderSegment::UserID%3A0C112101CD.attr preserve=no  public: string {V} 
      string m_strUserID;
      //## end segment::CommonHeaderSegment::UserID%3A0C112101CD.attr

      //## begin segment::CommonHeaderSegment::Source%5B1043BB0376.attr preserve=no  public: string {V} 
      string m_strSource;
      //## end segment::CommonHeaderSegment::Source%5B1043BB0376.attr

    // Additional Implementation Declarations
      //## begin segment::CommonHeaderSegment%3453FD6102B3.implementation preserve=yes
      //## end segment::CommonHeaderSegment%3453FD6102B3.implementation

};

//## begin segment::CommonHeaderSegment%3453FD6102B3.postscript preserve=yes
//## end segment::CommonHeaderSegment%3453FD6102B3.postscript

} // namespace segment

//## begin module%3597E59A0191.epilog preserve=yes
#ifndef parse_errors
#define parse_errors
#define STS_PARSE_ERROR 300
#define STS_QUERY_ERROR 301
#define STS_SESSION_ERROR 302
#define STS_SECURITY_ERROR 303
#endif

#define SEP_1999_MU "19990920"
#define FEB_2000_MU "20000223"
#define APR_2000_MU "20000417"
#define JUN_2000_MU "20000619"
#define JUL_2000_MU "20000719"
#define OCT_2000_MU "20001023"
#define JAN_2001_MU "20010129"
#define MAR_2001_MU "20010312"
#define APR_2001_MU "20010425"
#define JUN_2001_MU "20010611"
#define JUL_2001_MU "20010723"
#define AUG_2001_MU "20010820"
#define SEP_2001_MU "20010917"
#define OCT_2001_MU "20011022"
#define NOV_2001_MU "20011119"
#define JAN_2002_MU "20020109"
#define FEB_2002_MU "20020210"
#define MAR_2002_MU "20020313"
#define APR_2002_MU "20020407"
#define JUN_2002_MU "20020602"
#define AUG_2002_MU "20020811"
#define DEC_2002_MU "20021211"
#define FEB_2003_MU "20030209"
#define APR_2003_MU "20030406"
#define JUN_2003_MU "20030601"
#define JUL_2003_MU "20030725"
#define AUG_2003_MU "20030824"
#define OCT_2003_MU "20031005"
#define JAN_2004_MU "20040111"
#define MAR_2004_MU "20040321"
#define MAY_2004_MU "20040523"
#define JUL_2004_MU "20040711"
#define SEP_2004_MU "20040912"
#define DEC_2004_MU "20041205"
#define JAN_2005_MU "20050109"
#define MAR_2005_MU "20050306"
#define MAY_2005_MU "20050515"
#define JUL_2005_MU "20050717"
#define SEP_2005_MU "20050911"
#define NOV_2005_MU "20051106"
#define JAN_2006_MU "20060108"
#define MAR_2006_MU "20060312"
#define MAY_2006_MU "20060507"
#define JUL_2006_MU "20060709"
#define SEP_2006_MU "20060910"
#define NOV_2006_MU "20061105"
#define JAN_2007_MU "20070107"
#define MAR_2007_MU "20070304"
#define MAY_2007_MU "20070506"
#define JUL_2007_MU "20070715"
#define SEP_2007_MU "20070909"
#define NOV_2007_MU "20071104"
#define JAN_2008_MU "20080106"
#define FEB_2008_MU "20080210"
#define MAR_2008_MU "20080316"
#define APR_2008_MU "20080404"
#define MAY_2008_MU "20080601"
#define JUL_2008_MU "20080713"
#define SEP_2008_MU "20080907"
#define APR_2009_MU "20090417"
// V02.0A.R001
#define JUN_2009_MU "20090607"
#define JUL_2009_MU "20090719"
#define AUG_2009_MU "20090823"
#define OCT_2009_MU "20091016"
// V02.0B.R001
#define NOV_2009_MU "20091115"
#define JAN_2010_MU "20100117"
// V02.0D.R001
#define FEB_2010_MU "20100222"
#define APR_2010_MU "20100416"
#define MAY_2010_MU "20100524"
#define JUL_2010_MU "20100719"
#define AUG_2010_MU "20100823"
#define OCT_2010_MU "20101015"
#define NOV_2010_MU "20101115"
// V02.1B.R001
#define JAN_2011_MU "20110111"
#define FEB_2011_MU "20110213"
#define MAR_2011_MU "20110320"
#define APR_2011_MU "20110415"
#define MAY_2011_MU "20110515"
#define JUN_2011_MU "20110612"
#define JUL_2011_MU "20110710"
#define AUG_2011_MU "20110814"
#define SEP_2011_MU "20110911"
#define OCT_2011_MU "20111014"
#define NOV_2011_MU "20111113"
// V02.2B.R001
#define JAN_2012_MU "20120122"
#define FEB_2012_MU "20120226"
#define APR_2012_MU "20120413"
#define MAY_2012_MU "20120520"
#define JUL_2012_MU "20120715"
#define AUG_2012_MU "20120826"
#define OCT_2012_MU "20121012"
#define NOV_2012_MU "20121111"
// V02.3B.R001
#define JAN_2013_MU "20130120"
#define FEB_2013_MU "20130217"
#define APR_2013_MU "20130419"
#define MAY_2013_MU "20130519"
#define JUN_2013_MU "20130616"
#define AUG_2013_MU "20130818"
#define OCT_2013_MU "20131018"
#define NOV_2013_MU "20131117"
// V02.4B.R001
#define JAN_2014_MU "20140112"
#define FEB_2014_MU "20140223"
#define APR_2014_MU "20140411"
#define MAY_2014_MU "20140518"
#define JUN_2014_MU "20140615"
#define JUL_2014_MU "20140720"
#define AUG_2014_MU "20140817"
#define SEP_2014_MU "20140921"
#define OCT_2014_MU "20141017"
#define NOV_2014_MU "20141102"
// V02.5B.R001
#define JAN_2015_MU "20150111"
#define FEB_2015_MU "20150222"
#define MAR_2015_MU "20150322"
#define APR_2015_MU "20150417"
#define MAY_2015_MU "20150517"
#define JUN_2015_MU "20150614"
#define JUL_2015_MU "20150719"
#define AUG_2015_MU "20150816"
#define SEP_2015_MU "20150920"
#define OCT_2015_MU "20151016"
#define NOV_2015_MU "20151115"
// V02.7A.R001
#define JAN_2016_MU "20160110"
#define FEB_2016_MU "20160221"
#define MAR_2016_MU "20160320"
#define APR_2016_MU "20160415"
#define MAY_2016_MU "20160522"
#define JUN_2016_MU "20160619"
#define JUL_2016_MU "20160724"
#define AUG_2016_MU "20160821"
#define SEP_2016_MU "20160918"
#define OCT_2016_MU "20161014"
#define NOV_2016_MU "20161113"

// V02.8A.R001
#define JAN_2017_MU "20170108"
#define FEB_2017_MU "20170219"
#define MAR_2017_MU "20170319"
#define APR_2017_MU "20170421"
#define MAY_2017_MU "20170521"
#define JUN_2017_MU "20170618"
#define JUL_2017_MU "20170723"
#define AUG_2017_MU "20170820"
#define SEP_2017_MU "20170917"
#define OCT_2017_MU "20171013"
#define NOV_2017_MU "20171112"

// V02.9A.R001
#define JAN_2018_MU "20180107"
#define FEB_2018_MU "20180218"
#define MAR_2018_MU "20180318"
#define APR_2018_MU "20180420"
#define MAY_2018_MU "20180520"
#define JUN_2018_MU "20180617"
#define JUL_2018_MU "20180723"
#define AUG_2018_MU "20180822"
#define SEP_2018_MU "20180916"
#define OCT_2018_MU "20181012"
#define NOV_2018_MU "20181111"

// V03.0A.R001
#define JAN_2019_MU "20190113"
#define FEB_2019_MU "20190224"
#define MAR_2019_MU "20190317"
#define APR_2019_MU "20190412"
#define MAY_2019_MU "20190519"
#define JUN_2019_MU "20190616"
#define JUL_2019_MU "20190721"
#define AUG_2019_MU "20190825"
#define SEP_2019_MU "20190915"
#define OCT_2019_MU "20191018"
#define NOV_2019_MU "20191110"

// V03.1A.R001
#define JAN_2020_MU "20200112"
#define FEB_2020_MU "20200223"
#define MAR_2020_MU "20200316"
#define APR_2020_MU "20200417"
#define MAY_2020_MU "20200517"
#define JUN_2020_MU "20200614"
#define JUL_2020_MU "20200719"
#define AUG_2020_MU "20200823"
#define SEP_2020_MU "20200913"
#define OCT_2020_MU "20201016"
#define NOV_2020_MU "20201108"

// V03.2A.R001
#define JAN_2021_MU "20210124"
#define FEB_2021_MU "20210228"
#define APR_2021_MU "20210416"
#define MAY_2021_MU "20210523"
#define JUN_2021_MU "20210620"
#define JUL_2021_MU "20210725"
#define AUG_2021_MU "20210822"
#define OCT_2021_MU "20211015"
#define NOV_2021_MU "20211121"

// V03.3A.R001
#define JAN_2022_MU "20220123"
#define FEB_2022_MU "20220227"
#define APR_2022_MU "20220422"
#define JUN_2022_MU "20220619"
#define JUL_2022_MU "20220724"
#define AUG_2022_MU "20220821"
#define OCT_2022_MU "20221014"
#define NOV_2022_MU "20221120"

// V03.4A.R001
#define JAN_2023_MU "20230122"
#define MAY_2023_MU "20230521"
#define JUN_2023_MU "20230618"
#define JUL_2023_MU "20230723"
#define AUG_2023_MU "20230820"
#define OCT_2023_MU "20231013"
#define NOV_2023_MU "20231119"

// V03.5A.R001
#define JAN_2024_MU "20240121"
#define FEB_2024_MU "20240225"
#define APR_2024_MU "20240412"
#define MAY_2024_MU "20240519"
#define JUN_2024_MU "20240623"
#define JUL_2024_MU "20240721"
#define AUG_2024_MU "20240825"
#define OCT_2024_MU "20241018"
#define NOV_2024_MU "20241117"

// When adding new MU values, update LATEST_MU below
#define LATEST_MU APR_2024_MU

using namespace segment;
//## end module%3597E59A0191.epilog


#endif
