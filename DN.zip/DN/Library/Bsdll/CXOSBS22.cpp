//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E7635830138.cm preserve=no
//	$Date:   Jun 11 2021 00:41:10  $ $Author:   e3028298  $ $Revision:   1.6  $
//## end module%3E7635830138.cm

//## begin module%3E7635830138.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3E7635830138.cp

//## Module: CXOSBS22%3E7635830138; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: D:\Devel\V03.2A.R003\ConnexPlatform\Server\Library\Bsdll\CXOSBS22.cpp

//## begin module%3E7635830138.additionalIncludes preserve=no
//## end module%3E7635830138.additionalIncludes

//## begin module%3E7635830138.includes preserve=yes
#include "CXODBS06.hpp"
#include "CXODMN07.hpp"
//## end module%3E7635830138.includes

#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBS22_h
#include "CXODBS22.hpp"
#endif


//## begin module%3E7635830138.declarations preserve=no
//## end module%3E7635830138.declarations

//## begin module%3E7635830138.additionalDeclarations preserve=yes

struct segHealthMonitorSegment* pSegHealthMonitorSegment = 0;
#define FIELDS 7
Fields HealthMonitorSegment_Fields[FIELDS + 1] =
{
   "a        X"," ",offsetof(segHealthMonitorSegment,cOperator),sizeof(pSegHealthMonitorSegment->cOperator),
   "a        K","IMAGE_ID",offsetof(segHealthMonitorSegment,sIMAGE),sizeof(pSegHealthMonitorSegment->sIMAGE),
   "a        K","DOMAIN_NAME",offsetof(segHealthMonitorSegment,sDOMAIN),sizeof(pSegHealthMonitorSegment->sDOMAIN),
   "a        K","MEMBER_NAME",offsetof(segHealthMonitorSegment,sMEMBER),sizeof(pSegHealthMonitorSegment->sMEMBER),
   "a        K","BUCKET",offsetof(segHealthMonitorSegment,sBUCKET),sizeof(pSegHealthMonitorSegment->sBUCKET),
   "a        K","TIME_PERIOD",offsetof(segHealthMonitorSegment,sPERIOD),sizeof(pSegHealthMonitorSegment->sPERIOD),
   "l         ","ITEM_COUNT",offsetof(segHealthMonitorSegment,sCOUNT),sizeof(pSegHealthMonitorSegment->sCOUNT),
   "~","~",0,sizeof(segHealthMonitorSegment),
};
//## end module%3E7635830138.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::HealthMonitorSegment 

//## begin segment::HealthMonitorSegment::Instance%3E77409803C8.attr preserve=no  private: static segment::HealthMonitorSegment* {U} 0
segment::HealthMonitorSegment* HealthMonitorSegment::m_pInstance = 0;
//## end segment::HealthMonitorSegment::Instance%3E77409803C8.attr

HealthMonitorSegment::HealthMonitorSegment()
  //## begin HealthMonitorSegment::HealthMonitorSegment%3E761856038A_const.hasinit preserve=no
      : m_lITEM_COUNT(0)
  //## end HealthMonitorSegment::HealthMonitorSegment%3E761856038A_const.hasinit
  //## begin HealthMonitorSegment::HealthMonitorSegment%3E761856038A_const.initialization preserve=yes
   ,PersistentSegment("HMS","SYS_HEALTH_MON","QUALIFY")
  //## end HealthMonitorSegment::HealthMonitorSegment%3E761856038A_const.initialization
{
  //## begin segment::HealthMonitorSegment::HealthMonitorSegment%3E761856038A_const.body preserve=yes
   memcpy(m_sID,"BS22",4);
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strOperator;
   m_pField[1] = &m_strIMAGE_ID;
   m_pField[2] = &m_strDOMAIN_NAME;
   m_pField[3] = &m_strMEMBER_NAME;
   m_pField[4] = &m_strBUCKET;
   m_pField[5] = &m_strTIME_PERIOD;
   m_pField[6] = &m_lITEM_COUNT;
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0100",APR_2003_MU,87,87));
  //## end segment::HealthMonitorSegment::HealthMonitorSegment%3E761856038A_const.body
}

HealthMonitorSegment::HealthMonitorSegment(const HealthMonitorSegment &right)
  //## begin HealthMonitorSegment::HealthMonitorSegment%3E761856038A_copy.hasinit preserve=no
  //## end HealthMonitorSegment::HealthMonitorSegment%3E761856038A_copy.hasinit
  //## begin HealthMonitorSegment::HealthMonitorSegment%3E761856038A_copy.initialization preserve=yes
  //## end HealthMonitorSegment::HealthMonitorSegment%3E761856038A_copy.initialization
{
  //## begin segment::HealthMonitorSegment::HealthMonitorSegment%3E761856038A_copy.body preserve=yes
   memcpy(m_sID,"BS22",4);
   m_strIMAGE_ID = right.m_strIMAGE_ID;
   m_strDOMAIN_NAME = right.m_strDOMAIN_NAME; 
   m_strMEMBER_NAME = right.m_strMEMBER_NAME;
   m_strBUCKET = right.m_strBUCKET;
   m_strTIME_PERIOD = right.m_strTIME_PERIOD;
   m_lITEM_COUNT = right.m_lITEM_COUNT;
  //## end segment::HealthMonitorSegment::HealthMonitorSegment%3E761856038A_copy.body
}


HealthMonitorSegment::~HealthMonitorSegment()
{
  //## begin segment::HealthMonitorSegment::~HealthMonitorSegment%3E761856038A_dest.body preserve=yes
  //## end segment::HealthMonitorSegment::~HealthMonitorSegment%3E761856038A_dest.body
}


HealthMonitorSegment & HealthMonitorSegment::operator=(const HealthMonitorSegment &right)
{
  //## begin segment::HealthMonitorSegment::operator=%3E761856038A_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_strIMAGE_ID = right.m_strIMAGE_ID;
   m_strDOMAIN_NAME = right.m_strDOMAIN_NAME; 
   m_strMEMBER_NAME = right.m_strMEMBER_NAME;
   m_strBUCKET = right.m_strBUCKET;
   m_strTIME_PERIOD = right.m_strTIME_PERIOD;
   return *this;
  //## end segment::HealthMonitorSegment::operator=%3E761856038A_assign.body
}



//## Other Operations (implementation)
struct Fields* HealthMonitorSegment::fields () const
{
  //## begin segment::HealthMonitorSegment::fields%3E763F57005D.body preserve=yes
   return &HealthMonitorSegment_Fields[0];
  //## end segment::HealthMonitorSegment::fields%3E763F57005D.body
}

segment::HealthMonitorSegment* HealthMonitorSegment::instance ()
{
  //## begin segment::HealthMonitorSegment::instance%3E763B7D0213.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new HealthMonitorSegment();
   return m_pInstance;
  //## end segment::HealthMonitorSegment::instance%3E763B7D0213.body
}

void HealthMonitorSegment::reset ()
{
  //## begin segment::HealthMonitorSegment::reset%3E763C6E0203.body preserve=yes
   Segment::reset();
   m_strIMAGE_ID.erase();
   m_strDOMAIN_NAME.erase();
   m_strMEMBER_NAME.erase();
   m_strBUCKET.erase();
   m_strTIME_PERIOD.erase();
   m_lITEM_COUNT = 0;
  //## end segment::HealthMonitorSegment::reset%3E763C6E0203.body
}

// Additional Declarations
  //## begin segment::HealthMonitorSegment%3E761856038A.declarations preserve=yes
  //## end segment::HealthMonitorSegment%3E761856038A.declarations

} // namespace segment

//## begin module%3E7635830138.epilog preserve=yes
//## end module%3E7635830138.epilog
