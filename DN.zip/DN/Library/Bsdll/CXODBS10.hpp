//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%35A3BB9A00C0.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%35A3BB9A00C0.cm

//## begin module%35A3BB9A00C0.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%35A3BB9A00C0.cp

//## Module: CXOSBS10%35A3BB9A00C0; Package specification
//## Subsystem: BSDLL%394E1F8C0345
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bsdll\CXODBS10.hpp

#ifndef CXOSBS10_h
#define CXOSBS10_h 1

//## begin module%35A3BB9A00C0.additionalIncludes preserve=no
//## end module%35A3BB9A00C0.additionalIncludes

//## begin module%35A3BB9A00C0.includes preserve=yes
// $Date:   18 Jan 2018 14:11:42  $ $Author:   e1009839  $ $Revision:   1.5  $
//## end module%35A3BB9A00C0.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class IString;
} // namespace reusable

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;

} // namespace segment

//## begin module%35A3BB9A00C0.declarations preserve=no
//## end module%35A3BB9A00C0.declarations

//## begin module%35A3BB9A00C0.additionalDeclarations preserve=yes
//## end module%35A3BB9A00C0.additionalDeclarations


namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::MultipleRowContextSegment%34609BFF01B9.preface preserve=yes
//## end segment::MultipleRowContextSegment%34609BFF01B9.preface

//## Class: MultipleRowContextSegment%34609BFF01B9
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%35A659C90279;InformationSegment { -> F}
//## Uses: <unnamed>%3B5C42E70222;InformationSegment { -> F}
//## Uses: <unnamed>%3BFE99A6000F;reusable::IString { -> F}

class DllExport MultipleRowContextSegment : public Segment  //## Inherits: <unnamed>%34609C0E02C9
{
  //## begin segment::MultipleRowContextSegment%34609BFF01B9.initialDeclarations preserve=yes
  //## end segment::MultipleRowContextSegment%34609BFF01B9.initialDeclarations

  public:
    //## Constructors (generated)
      MultipleRowContextSegment();

    //## Destructor (generated)
      virtual ~MultipleRowContextSegment();


    //## Other Operations (specified)
      //## Operation: deport%379F023E0210
      virtual int deport (char** ppsBuffer);

      //## Operation: fields%3827107D0000
      virtual struct  Fields* fields () const;

      //## Operation: import%379F024101CE
      virtual int import (char** ppsBuffer);

      //## Operation: segmentVersion%3834250202AE
      virtual char* segmentVersion ()
      {
        //## begin segment::MultipleRowContextSegment::segmentVersion%3834250202AE.body preserve=yes
         return "0101";
        //## end segment::MultipleRowContextSegment::segmentVersion%3834250202AE.body
      }

      //## Operation: update%37F9064B02ED
      static void update (char* psBuffer, int lTotalRecordsFound);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Archive%3EA5A11E0251
      const char getArchive () const
      {
        //## begin segment::MultipleRowContextSegment::getArchive%3EA5A11E0251.get preserve=no
        return m_cArchive;
        //## end segment::MultipleRowContextSegment::getArchive%3EA5A11E0251.get
      }


      //## Attribute: ClientStateIndicator%379F01540083
      const char clientStateIndicator () const
      {
        //## begin segment::MultipleRowContextSegment::clientStateIndicator%379F01540083.get preserve=no
        return m_cClientStateIndicator;
        //## end segment::MultipleRowContextSegment::clientStateIndicator%379F01540083.get
      }

      void setClientStateIndicator (char value)
      {
        //## begin segment::MultipleRowContextSegment::setClientStateIndicator%379F01540083.set preserve=no
        m_cClientStateIndicator = value;
        //## end segment::MultipleRowContextSegment::setClientStateIndicator%379F01540083.set
      }


      //## Attribute: MaxRowsToFetch%379F019A00FC
      const int maxRowsToFetch () const
      {
        //## begin segment::MultipleRowContextSegment::maxRowsToFetch%379F019A00FC.get preserve=no
        return m_lMaxRowsToFetch;
        //## end segment::MultipleRowContextSegment::maxRowsToFetch%379F019A00FC.get
      }

      void setMaxRowsToFetch (int value)
      {
        //## begin segment::MultipleRowContextSegment::setMaxRowsToFetch%379F019A00FC.set preserve=no
        m_lMaxRowsToFetch = value;
        //## end segment::MultipleRowContextSegment::setMaxRowsToFetch%379F019A00FC.set
      }


      //## Attribute: RecordNumberLastReturned%379F019A01F6
      const int recordNumberLastReturned () const
      {
        //## begin segment::MultipleRowContextSegment::recordNumberLastReturned%379F019A01F6.get preserve=no
        return m_lRecordNumberLastReturned;
        //## end segment::MultipleRowContextSegment::recordNumberLastReturned%379F019A01F6.get
      }

      void setRecordNumberLastReturned (int value)
      {
        //## begin segment::MultipleRowContextSegment::setRecordNumberLastReturned%379F019A01F6.set preserve=no
        m_lRecordNumberLastReturned = value;
        //## end segment::MultipleRowContextSegment::setRecordNumberLastReturned%379F019A01F6.set
      }


      //## Attribute: RecordsReturnedThisMessage%379F019A02DC
      const int recordsReturnedThisMessage () const
      {
        //## begin segment::MultipleRowContextSegment::recordsReturnedThisMessage%379F019A02DC.get preserve=no
        return m_lRecordsReturnedThisMessage;
        //## end segment::MultipleRowContextSegment::recordsReturnedThisMessage%379F019A02DC.get
      }

      void setRecordsReturnedThisMessage (int value)
      {
        //## begin segment::MultipleRowContextSegment::setRecordsReturnedThisMessage%379F019A02DC.set preserve=no
        m_lRecordsReturnedThisMessage = value;
        //## end segment::MultipleRowContextSegment::setRecordsReturnedThisMessage%379F019A02DC.set
      }


      //## Attribute: ServerStateIndicator%379F0199010E
      const char serverStateIndicator () const
      {
        //## begin segment::MultipleRowContextSegment::serverStateIndicator%379F0199010E.get preserve=no
        return m_cServerStateIndicator;
        //## end segment::MultipleRowContextSegment::serverStateIndicator%379F0199010E.get
      }

      void setServerStateIndicator (char value)
      {
        //## begin segment::MultipleRowContextSegment::setServerStateIndicator%379F0199010E.set preserve=no
        m_cServerStateIndicator = value;
        //## end segment::MultipleRowContextSegment::setServerStateIndicator%379F0199010E.set
      }


      //## Attribute: STSContextData%379F019B023E
      const IString STSContextData () const
      {
        //## begin segment::MultipleRowContextSegment::STSContextData%379F019B023E.get preserve=no
        return m_strSTSContextData;
        //## end segment::MultipleRowContextSegment::STSContextData%379F019B023E.get
      }

      void setSTSContextData (IString value)
      {
        //## begin segment::MultipleRowContextSegment::setSTSContextData%379F019B023E.set preserve=no
        m_strSTSContextData = value;
        //## end segment::MultipleRowContextSegment::setSTSContextData%379F019B023E.set
      }


      //## Attribute: TotalRecordsFound%379F019A03D7
      const int totalRecordsFound () const
      {
        //## begin segment::MultipleRowContextSegment::totalRecordsFound%379F019A03D7.get preserve=no
        return m_lTotalRecordsFound;
        //## end segment::MultipleRowContextSegment::totalRecordsFound%379F019A03D7.get
      }

      void setTotalRecordsFound (int value)
      {
        //## begin segment::MultipleRowContextSegment::setTotalRecordsFound%379F019A03D7.set preserve=no
        m_lTotalRecordsFound = value;
        //## end segment::MultipleRowContextSegment::setTotalRecordsFound%379F019A03D7.set
      }


    // Additional Public Declarations
      //## begin segment::MultipleRowContextSegment%34609BFF01B9.public preserve=yes
      //## end segment::MultipleRowContextSegment%34609BFF01B9.public

  protected:
    // Data Members for Class Attributes

      //## begin segment::MultipleRowContextSegment::ClientStateIndicator%379F01540083.attr preserve=no  public: char {V} 'I'
      char m_cClientStateIndicator;
      //## end segment::MultipleRowContextSegment::ClientStateIndicator%379F01540083.attr

      //## begin segment::MultipleRowContextSegment::MaxRowsToFetch%379F019A00FC.attr preserve=no  public: int {V} 10
      int m_lMaxRowsToFetch;
      //## end segment::MultipleRowContextSegment::MaxRowsToFetch%379F019A00FC.attr

      //## begin segment::MultipleRowContextSegment::RecordNumberLastReturned%379F019A01F6.attr preserve=no  public: int {V} 0
      int m_lRecordNumberLastReturned;
      //## end segment::MultipleRowContextSegment::RecordNumberLastReturned%379F019A01F6.attr

      //## begin segment::MultipleRowContextSegment::RecordsReturnedThisMessage%379F019A02DC.attr preserve=no  public: int {V} 0
      int m_lRecordsReturnedThisMessage;
      //## end segment::MultipleRowContextSegment::RecordsReturnedThisMessage%379F019A02DC.attr

      //## begin segment::MultipleRowContextSegment::ServerStateIndicator%379F0199010E.attr preserve=no  public: char {V} ' '
      char m_cServerStateIndicator;
      //## end segment::MultipleRowContextSegment::ServerStateIndicator%379F0199010E.attr

      //## begin segment::MultipleRowContextSegment::STSContextData%379F019B023E.attr preserve=no  public: IString {V} 
      IString m_strSTSContextData;
      //## end segment::MultipleRowContextSegment::STSContextData%379F019B023E.attr

      //## begin segment::MultipleRowContextSegment::TotalRecordsFound%379F019A03D7.attr preserve=no  public: int {V} 0
      int m_lTotalRecordsFound;
      //## end segment::MultipleRowContextSegment::TotalRecordsFound%379F019A03D7.attr

    // Additional Protected Declarations
      //## begin segment::MultipleRowContextSegment%34609BFF01B9.protected preserve=yes
      //## end segment::MultipleRowContextSegment%34609BFF01B9.protected

  private:
    // Additional Private Declarations
      //## begin segment::MultipleRowContextSegment%34609BFF01B9.private preserve=yes
      //## end segment::MultipleRowContextSegment%34609BFF01B9.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin segment::MultipleRowContextSegment::Archive%3EA5A11E0251.attr preserve=no  public: char {V} 'N'
      char m_cArchive;
      //## end segment::MultipleRowContextSegment::Archive%3EA5A11E0251.attr

    // Additional Implementation Declarations
      //## begin segment::MultipleRowContextSegment%34609BFF01B9.implementation preserve=yes
      //## end segment::MultipleRowContextSegment%34609BFF01B9.implementation

};

//## begin segment::MultipleRowContextSegment%34609BFF01B9.postscript preserve=yes
//## end segment::MultipleRowContextSegment%34609BFF01B9.postscript

} // namespace segment

//## begin module%35A3BB9A00C0.epilog preserve=yes
using namespace segment;
//## end module%35A3BB9A00C0.epilog


#endif
