//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3720CEDC009D.cm preserve=no
//## end module%3720CEDC009D.cm

//## begin module%3720CEDC009D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3720CEDC009D.cp

//## Module: CXOSBS02%3720CEDC009D; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS02.hpp

#ifndef CXOSBS02_h
#define CXOSBS02_h 1

//## begin module%3720CEDC009D.additionalIncludes preserve=no
//## end module%3720CEDC009D.additionalIncludes

//## begin module%3720CEDC009D.includes preserve=yes
//## end module%3720CEDC009D.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class SharedResource;
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class NonStopClock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseCatalog;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
class GetColumnsVisitor;
} // namespace segment

namespace reusable {
class Transaction;
class Table;

} // namespace reusable

//## begin module%3720CEDC009D.declarations preserve=no
//## end module%3720CEDC009D.declarations

//## begin module%3720CEDC009D.additionalDeclarations preserve=yes
#include <map>
//## end module%3720CEDC009D.additionalDeclarations


namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::PersistentSegment%3720CE37012B.preface preserve=yes
//## end segment::PersistentSegment%3720CE37012B.preface

//## Class: PersistentSegment%3720CE37012B
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3720D891017C;reusable::Table { -> F}
//## Uses: <unnamed>%395889340128;IF::SharedResource { -> F}
//## Uses: <unnamed>%3A1C22A2001B;reusable::Transaction { -> F}
//## Uses: <unnamed>%3A23D113020C;CommonHeaderSegment { -> F}
//## Uses: <unnamed>%3720D8EE0306;reusable::Query { -> F}
//## Uses: <unnamed>%5B2D311F0241;IF::Trace { -> F}
//## Uses: <unnamed>%5B2D31380091;IF::CodeTable { -> F}
//## Uses: <unnamed>%5B2D314F030A;timer::NonStopClock { -> F}
//## Uses: <unnamed>%5B2D39C30073;GetColumnsVisitor { -> F}
//## Uses: <unnamed>%5B2D39F803A4;database::DatabaseCatalog { -> F}

class DllExport PersistentSegment : public Segment  //## Inherits: <unnamed>%3720CE4000A2
{
  //## begin segment::PersistentSegment%3720CE37012B.initialDeclarations preserve=yes
  //## end segment::PersistentSegment%3720CE37012B.initialDeclarations

  public:
    //## Constructors (generated)
      PersistentSegment();

      PersistentSegment(const PersistentSegment &right);

    //## Constructors (specified)
      //## Operation: PersistentSegment%3720E2A80267
      PersistentSegment (const char* pszSegmentID);

      //## Operation: PersistentSegment%385FD9A80217
      PersistentSegment (const char* pszSegmentID, const char* pszTableName, const char* pszQualifier = "CUSTQUAL");

    //## Destructor (generated)
      virtual ~PersistentSegment();

    //## Assignment Operation (generated)
      PersistentSegment & operator=(const PersistentSegment &right);


    //## Other Operations (specified)
      //## Operation: addColumn%5B2D321C03BC
      void addColumn (const string& strName, short int iType, int lLength, short int iScale);

      //## Operation: bind%3720D89D0242
      virtual void bind (Query& hQuery);

      //## Operation: bindPerCatalog%5B2D322102EC
      bool bindPerCatalog (Query& hQuery);

      //## Operation: fields%3EC281E403B9
      virtual struct  Fields* fields () const
      {
        //## begin segment::PersistentSegment::fields%3EC281E403B9.body preserve=yes
         return m_pFields;
        //## end segment::PersistentSegment::fields%3EC281E403B9.body
      }

      //## Operation: getKey%3DBA9F13001F
      virtual reusable::string getKey ();

      //## Operation: getKey%3A0EE5CE03C4
      virtual bool getKey (Query& hQuery);

      //## Operation: matches%3DBA9F5B03C8
      bool matches (const PersistentSegment& hPersistentSegment);

      //## Operation: notify%395888FE0275
      void notify ();

      //## Operation: persistent%373728910169
      virtual bool persistent ()
      {
        //## begin segment::PersistentSegment::persistent%373728910169.body preserve=yes
         return true;
        //## end segment::PersistentSegment::persistent%373728910169.body
      }

      //## Operation: reset%3F44CDBE0167
      virtual void reset ();

      //## Operation: setColumns%3720CF41011A
      virtual void setColumns (Table& hTable);

      //## Operation: setField%403F636F00EA
      virtual bool setField (char* pszName, const string& strValue) const;

      //## Operation: setField%4FD64F2C03E1
      virtual bool setField (Fields* ppszFields, const char cDelimiter, char* psInputBuffer, int& iBuffer, char** psLoadField, bool bAsciiInput = true) const;

      //## Operation: setFinancialData%4074F98E0280
      virtual void setFinancialData ();

      //## Operation: setKey%3A196FC2022F
      void setKey ();

      //## Operation: setPredicate%3A1949C200EE
      void setPredicate (Query& hQuery);

      //## Operation: setTStampUpdated%3A1C22F10032
      void setTStampUpdated ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Qualifier%3925B4470117
      const reusable::string& getQualifier () const
      {
        //## begin segment::PersistentSegment::getQualifier%3925B4470117.get preserve=no
        return m_strQualifier;
        //## end segment::PersistentSegment::getQualifier%3925B4470117.get
      }

      void setQualifier (const reusable::string& value)
      {
        //## begin segment::PersistentSegment::setQualifier%3925B4470117.set preserve=no
        m_strQualifier = value;
        //## end segment::PersistentSegment::setQualifier%3925B4470117.set
      }


      //## Attribute: TableName%385FD9CC022D
      const reusable::string& getTableName () const
      {
        //## begin segment::PersistentSegment::getTableName%385FD9CC022D.get preserve=no
        return m_strTableName;
        //## end segment::PersistentSegment::getTableName%385FD9CC022D.get
      }

      void setTableName (const reusable::string& value)
      {
        //## begin segment::PersistentSegment::setTableName%385FD9CC022D.set preserve=no
        m_strTableName = value;
        //## end segment::PersistentSegment::setTableName%385FD9CC022D.set
      }


    // Additional Public Declarations
      //## begin segment::PersistentSegment%3720CE37012B.public preserve=yes
      bool addComma (Fields* ppszFields,char* pBuffer,char** pFormatted,int* ilen,string &strDelimiter);
      //## end segment::PersistentSegment%3720CE37012B.public
  protected:

    //## Other Operations (specified)
      //## Operation: queryCatalog%5B2D32280272
      bool queryCatalog ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Names%3EC36DC6032C
      const char* getNames () const
      {
        //## begin segment::PersistentSegment::getNames%3EC36DC6032C.get preserve=no
        return m_pszNames;
        //## end segment::PersistentSegment::getNames%3EC36DC6032C.get
      }


    // Data Members for Class Attributes

      //## Attribute: Null%401FE8D702DE
      //## begin segment::PersistentSegment::Null%401FE8D702DE.attr preserve=no  protected: short int {R} 0
      short int *m_piNull;
      //## end segment::PersistentSegment::Null%401FE8D702DE.attr

      //## Attribute: ServiceName%3A0EE62403C8
      //## begin segment::PersistentSegment::ServiceName%3A0EE62403C8.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strServiceName;
      //## end segment::PersistentSegment::ServiceName%3A0EE62403C8.attr

      //## begin segment::PersistentSegment::TableName%385FD9CC022D.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strTableName;
      //## end segment::PersistentSegment::TableName%385FD9CC022D.attr

    // Additional Protected Declarations
      //## begin segment::PersistentSegment%3720CE37012B.protected preserve=yes
      //## end segment::PersistentSegment%3720CE37012B.protected

  private:
    // Data Members for Class Attributes

      //## Attribute: iNull%3A0EE62E03A4
      //## begin segment::PersistentSegment::iNull%3A0EE62E03A4.attr preserve=no  private: short int {V} 0
      short int m_iNull;
      //## end segment::PersistentSegment::iNull%3A0EE62E03A4.attr

    // Additional Private Declarations
      //## begin segment::PersistentSegment%3720CE37012B.private preserve=yes
      //## end segment::PersistentSegment%3720CE37012B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Attributes%3EC36DE500FA
      //## begin segment::PersistentSegment::Attributes%3EC36DE500FA.attr preserve=no  protected: static char*[5] {V} {0,0,0,0,0}
      static char* m_pszAttributes[5];
      //## end segment::PersistentSegment::Attributes%3EC36DE500FA.attr

      //## Attribute: Fields%3EC2820102FD
      //## begin segment::PersistentSegment::Fields%3EC2820102FD.attr preserve=no  protected: struct Fields* {V} 0
      struct Fields* m_pFields;
      //## end segment::PersistentSegment::Fields%3EC2820102FD.attr

      //## Attribute: Index%3EC3F2A70177
      //## begin segment::PersistentSegment::Index%3EC3F2A70177.attr preserve=no  protected: int {V} 0
      int m_iIndex;
      //## end segment::PersistentSegment::Index%3EC3F2A70177.attr

      //## begin segment::PersistentSegment::Names%3EC36DC6032C.attr preserve=no  protected: char* {V} 0
      char* m_pszNames;
      //## end segment::PersistentSegment::Names%3EC36DC6032C.attr

      //## begin segment::PersistentSegment::Qualifier%3925B4470117.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strQualifier;
      //## end segment::PersistentSegment::Qualifier%3925B4470117.attr

    // Additional Implementation Declarations
      //## begin segment::PersistentSegment%3720CE37012B.implementation preserve=yes
      //## end segment::PersistentSegment%3720CE37012B.implementation

};

//## begin segment::PersistentSegment%3720CE37012B.postscript preserve=yes
//## end segment::PersistentSegment%3720CE37012B.postscript

} // namespace segment

//## begin module%3720CEDC009D.epilog preserve=yes
using namespace segment;
//## end module%3720CEDC009D.epilog


#endif
