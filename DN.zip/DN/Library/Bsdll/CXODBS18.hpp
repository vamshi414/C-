//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3BB346F50290.cm preserve=no
//	$Date:   Apr 29 2020 09:46:06  $ $Author:   e1014059  $ $Revision:   1.13  $
//## end module%3BB346F50290.cm

//## begin module%3BB346F50290.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3BB346F50290.cp

//## Module: CXOSBS18%3BB346F50290; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV03.0A.R003\ConnexPlatform\Server\Library\Bsdll\CXODBS18.hpp

#ifndef CXOSBS18_h
#define CXOSBS18_h 1

//## begin module%3BB346F50290.additionalIncludes preserve=no
//## end module%3BB346F50290.additionalIncludes

//## begin module%3BB346F50290.includes preserve=yes
// $Date:   Apr 29 2020 09:46:06  $ $Author:   e1014059  $ $Revision:   1.13  $
//## end module%3BB346F50290.includes

#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class NPI;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;

} // namespace IF

//## begin module%3BB346F50290.declarations preserve=no
//## end module%3BB346F50290.declarations

//## begin module%3BB346F50290.additionalDeclarations preserve=yes
//## end module%3BB346F50290.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::RepositorySegment%3BB3463500BB.preface preserve=yes
//## end segment::RepositorySegment%3BB3463500BB.preface

//## Class: RepositorySegment%3BB3463500BB
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3DC19EC30157;reusable::Query { -> F}
//## Uses: <unnamed>%54566BF00053;reusable::NPI { -> F}
//## Uses: <unnamed>%5EA8029401E5;IF::Trace { -> F}

class DllExport RepositorySegment : public PersistentSegment  //## Inherits: <unnamed>%3BB346860232
{
  //## begin segment::RepositorySegment%3BB3463500BB.initialDeclarations preserve=yes
  //## end segment::RepositorySegment%3BB3463500BB.initialDeclarations

  public:
    //## Constructors (generated)
      RepositorySegment();

      RepositorySegment(const RepositorySegment &right);

    //## Constructors (specified)
      //## Operation: RepositorySegment%3BB9C2990167
      RepositorySegment (const char* pszSegmentID, const char* pszTableName, const char* pszQualifier = "CUSTQUAL");

    //## Destructor (generated)
      virtual ~RepositorySegment();

    //## Assignment Operation (generated)
      RepositorySegment & operator=(const RepositorySegment &right);


    //## Other Operations (specified)
      //## Operation: bind%3DC18ECB033C
      void bind (Query& hQuery, const char* szLocatorTable = 0, bool bLoadFields = false);

      //## Operation: loadField%3BB4C5B0031C
      virtual void* loadField (int nField) const
      {
        //## begin segment::RepositorySegment::loadField%3BB4C5B0031C.body preserve=yes
         if (!m_pLoadField)
            return 0;
         return m_pLoadField[nField];
        //## end segment::RepositorySegment::loadField%3BB4C5B0031C.body
      }

      //## Operation: read%3BB34C2D029F
      virtual int read (char** ppsBuffer);

      //## Operation: reset%3BB8A267004E
      virtual void reset ();

      //## Operation: reverseShift%40FD81070242
      int reverseShift ();

      //## Operation: setColumns%40FEB037038A
      void setColumns (Table& hTable, bool bLocator);

      //## Operation: shift%3BB346B00186
      int shift ();

      //## Operation: write%3BB34C3A01B5
      virtual int write (char** ppsBuffer);

    // Additional Public Declarations
      //## begin segment::RepositorySegment%3BB3463500BB.public preserve=yes
      void repair(int iOffset);
      //## end segment::RepositorySegment%3BB3463500BB.public
  protected:
    // Data Members for Class Attributes

      //## Attribute: Buffer%3BB897CC02CE
      //## begin segment::RepositorySegment::Buffer%3BB897CC02CE.attr preserve=no  public: char* {U} 
      char* m_pBuffer;
      //## end segment::RepositorySegment::Buffer%3BB897CC02CE.attr

      //## Attribute: BufferLength%3BB897F6030D
      //## begin segment::RepositorySegment::BufferLength%3BB897F6030D.attr preserve=no  public: int {U} 
      int m_lBufferLength;
      //## end segment::RepositorySegment::BufferLength%3BB897F6030D.attr

      //## Attribute: LoadField%3BB4C24B031C
      //## begin segment::RepositorySegment::LoadField%3BB4C24B031C.attr preserve=no  protected: void** {UA} 0
      void** m_pLoadField;
      //## end segment::RepositorySegment::LoadField%3BB4C24B031C.attr

    // Additional Protected Declarations
      //## begin segment::RepositorySegment%3BB3463500BB.protected preserve=yes
      //## end segment::RepositorySegment%3BB3463500BB.protected

  private:
    // Additional Private Declarations
      //## begin segment::RepositorySegment%3BB3463500BB.private preserve=yes
      //## end segment::RepositorySegment%3BB3463500BB.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin segment::RepositorySegment%3BB3463500BB.implementation preserve=yes
      //## end segment::RepositorySegment%3BB3463500BB.implementation

};

//## begin segment::RepositorySegment%3BB3463500BB.postscript preserve=yes
//## end segment::RepositorySegment%3BB3463500BB.postscript

} // namespace segment

//## begin module%3BB346F50290.epilog preserve=yes
using namespace segment;
//## end module%3BB346F50290.epilog


#endif
