//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3597E59F0329.cm preserve=no
//	$Date:   Jul 10 2018 12:12:36  $ $Author:   e1009591  $ $Revision:   1.15  $
//## end module%3597E59F0329.cm

//## begin module%3597E59F0329.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3597E59F0329.cp

//## Module: CXOSBS06%3597E59F0329; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXOSBS06.cpp

//## begin module%3597E59F0329.additionalIncludes preserve=no
//## end module%3597E59F0329.additionalIncludes

//## begin module%3597E59F0329.includes preserve=yes
#include "CXODBS13.hpp"
//## end module%3597E59F0329.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSRU23_h
#include "CXODRU23.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif


//## begin module%3597E59F0329.declarations preserve=no
//## end module%3597E59F0329.declarations

//## begin module%3597E59F0329.additionalDeclarations preserve=yes
struct segCommonHeaderSegment* pCommonHeaderSegment = 0;
#define FIELDS 7
Fields CommonHeaderSegment_Fields[FIELDS + 1] =
{
   "a         ","SERVICE_NAME",offsetof(segCommonHeaderSegment,sServiceName),sizeof(pCommonHeaderSegment->sServiceName),
   "a         ","SECURITY_DATA",offsetof(segCommonHeaderSegment,sSecurityData),sizeof(pCommonHeaderSegment->sSecurityData),
   "a         ","EXTERNAL_CONTEXT_DATA",offsetof(segCommonHeaderSegment,sExternalContextData),sizeof(pCommonHeaderSegment->sExternalContextData),
   "l%03d     ","RESULT_CODE",offsetof(segCommonHeaderSegment,sResultCode),sizeof(pCommonHeaderSegment->sResultCode),
   "a         ","CLIENT_VERSION",offsetof(segCommonHeaderSegment,sClientVersion),sizeof(pCommonHeaderSegment->sClientVersion),
   "a         ","CUST_ID",offsetof(segCommonHeaderSegment,sCUST_ID),sizeof(pCommonHeaderSegment->sCUST_ID),
   "a         ","Source",offsetof(segCommonHeaderSegment,cSource),sizeof(pCommonHeaderSegment->cSource),
   "~","~",0,sizeof(segCommonHeaderSegment)
};
//## end module%3597E59F0329.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::CommonHeaderSegment 

//## begin segment::CommonHeaderSegment::Instance%37BAF6F403A9.attr preserve=no  private: static segment::CommonHeaderSegment {R} 0
segment::CommonHeaderSegment *CommonHeaderSegment::m_pInstance = 0;
//## end segment::CommonHeaderSegment::Instance%37BAF6F403A9.attr

CommonHeaderSegment::CommonHeaderSegment()
  //## begin CommonHeaderSegment::CommonHeaderSegment%3453FD6102B3_const.hasinit preserve=no
      : m_iResultCode(0)
  //## end CommonHeaderSegment::CommonHeaderSegment%3453FD6102B3_const.hasinit
  //## begin CommonHeaderSegment::CommonHeaderSegment%3453FD6102B3_const.initialization preserve=yes
   ,Segment("S001")
  //## end CommonHeaderSegment::CommonHeaderSegment%3453FD6102B3_const.initialization
{
  //## begin segment::CommonHeaderSegment::CommonHeaderSegment%3453FD6102B3_const.body preserve=yes
   memcpy(m_sID,"BS06",4);
   m_strClientVersion = LATEST_MU;
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strServiceName;
   m_pField[1] = &m_strSecurityData;
   m_pField[2] = &m_strExternalContextData;
   m_pField[3] = &m_iResultCode;
   m_pField[4] = &m_strClientVersion;
   m_pField[5] = &m_strCUST_ID;
   m_pField[6] = &m_strSource;
  //## end segment::CommonHeaderSegment::CommonHeaderSegment%3453FD6102B3_const.body
}

CommonHeaderSegment::CommonHeaderSegment(const CommonHeaderSegment &right)
  //## begin CommonHeaderSegment::CommonHeaderSegment%3453FD6102B3_copy.hasinit preserve=no
  //## end CommonHeaderSegment::CommonHeaderSegment%3453FD6102B3_copy.hasinit
  //## begin CommonHeaderSegment::CommonHeaderSegment%3453FD6102B3_copy.initialization preserve=yes
  : m_iResultCode(0)
   ,Segment(right)
  //## end CommonHeaderSegment::CommonHeaderSegment%3453FD6102B3_copy.initialization
{
  //## begin segment::CommonHeaderSegment::CommonHeaderSegment%3453FD6102B3_copy.body preserve=yes
   m_strClientVersion = right.m_strClientVersion;
   m_strExternalContextData = right.m_strExternalContextData;
   m_strSecurityData = right.m_strSecurityData;
   m_strServiceName = right.m_strServiceName;
   m_iResultCode = right.m_iResultCode;
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strServiceName;
   m_pField[1] = &m_strSecurityData;
   m_pField[2] = &m_strExternalContextData;
   m_pField[3] = &m_iResultCode;
   m_pField[4] = &m_strClientVersion;
   m_pField[5] = &m_strCUST_ID;
   m_pField[6] = &m_strSource;
  //## end segment::CommonHeaderSegment::CommonHeaderSegment%3453FD6102B3_copy.body
}


CommonHeaderSegment::~CommonHeaderSegment()
{
  //## begin segment::CommonHeaderSegment::~CommonHeaderSegment%3453FD6102B3_dest.body preserve=yes
   //if ((getGlobal() != 0) && (getGlobal()->getObject("BS06") == this))
   //   getGlobal()->erase(this);
   delete [] m_pField;
  //## end segment::CommonHeaderSegment::~CommonHeaderSegment%3453FD6102B3_dest.body
}


CommonHeaderSegment & CommonHeaderSegment::operator=(const CommonHeaderSegment &right)
{
  //## begin segment::CommonHeaderSegment::operator=%3453FD6102B3_assign.body preserve=yes
   if (this == &right)
      return *this;
   ((Segment&)*this) = right;
   m_strClientVersion = right.m_strClientVersion;
   m_strExternalContextData = right.m_strExternalContextData;
   m_strSecurityData = right.m_strSecurityData;
   m_strServiceName = right.m_strServiceName;
   m_iResultCode = right.m_iResultCode;
   m_strCUST_ID = right.m_strCUST_ID;
   m_strSource = right.m_strSource;
   return *this;
  //## end segment::CommonHeaderSegment::operator=%3453FD6102B3_assign.body
}



//## Other Operations (implementation)
int CommonHeaderSegment::deport (char** ppsBuffer)
{
  //## begin segment::CommonHeaderSegment::deport%37BAD0B6003A.body preserve=yes
   m_strServiceName.replace(0,1,"R");
   return Segment::deport(ppsBuffer);
  //## end segment::CommonHeaderSegment::deport%37BAD0B6003A.body
}

struct Fields* CommonHeaderSegment::fields () const
{
  //## begin segment::CommonHeaderSegment::fields%3A0C10A60049.body preserve=yes
   return &CommonHeaderSegment_Fields[0];
  //## end segment::CommonHeaderSegment::fields%3A0C10A60049.body
}

int CommonHeaderSegment::import (char** ppsBuffer)
{
  //## begin segment::CommonHeaderSegment::import%37BAD0B8014B.body preserve=yes
   segCommonHeaderSegment* p = (segCommonHeaderSegment*)*ppsBuffer;
   p->sSecurityData[63] = 'x'; // work around string memory assertion error in CI !!!
   int iRC = Segment::import(ppsBuffer);
   if (iRC == 0)
   {
      size_t pos = m_strSecurityData[26] == ' ' ? 0 : 26;
      m_strUserID = m_strSecurityData.substr(pos,8);
      pos = m_strUserID.find_last_not_of(' ');
      if (pos != string::npos)
         m_strUserID.erase(pos + 1);
      m_strAlias = m_strSecurityData.substr(0,8);
      pos = m_strAlias.find_last_not_of(' ');
      if (pos != string::npos)
         m_strAlias.erase(pos + 1);
   }
   return iRC;
  //## end segment::CommonHeaderSegment::import%37BAD0B8014B.body
}

CommonHeaderSegment* CommonHeaderSegment::instance (Object* pSender)
{
  //## begin segment::CommonHeaderSegment::instance%37BAF7210371.body preserve=yes
   //if ((pSender == 0) || (pSender->getGlobal() == 0))
   //{
      if (!m_pInstance)
         m_pInstance = new CommonHeaderSegment();
      return m_pInstance;
   /*}
   CommonHeaderSegment* pCommonHeaderSegment = (CommonHeaderSegment*)pSender->getGlobal()->getObject("BS06");
   if (!pCommonHeaderSegment)
   {
      pCommonHeaderSegment = new CommonHeaderSegment();
      pCommonHeaderSegment->setGlobal(pSender->getGlobal());
      pSender->getGlobal()->setObject("BS06",pCommonHeaderSegment);
   }
   return pCommonHeaderSegment; */
  //## end segment::CommonHeaderSegment::instance%37BAF7210371.body
}

void CommonHeaderSegment::replicate ()
{
  //## begin segment::CommonHeaderSegment::replicate%457DAE8D0128.body preserve=yes
   string strName(m_strPROC_DEST_ID);
   strName.resize(4,' ');
   strName += " VERSION";
   GlobalContext hGlobalContext(strName.c_str());
   string strData;
   hGlobalContext.get(strData);
   strData.empty() ? setClientVersion("99991231") : setClientVersion(strData); 
   m_strExternalContextData.erase();
   Extract::instance()->getSpec("CUSTOMER",m_strCUST_ID);
  //## end segment::CommonHeaderSegment::replicate%457DAE8D0128.body
}

int CommonHeaderSegment::size ()
{
  //## begin segment::CommonHeaderSegment::size%3A0C10CB00D9.body preserve=yes
   return sizeof(segCommonHeaderSegment);
  //## end segment::CommonHeaderSegment::size%3A0C10CB00D9.body
}

// Additional Declarations
  //## begin segment::CommonHeaderSegment%3453FD6102B3.declarations preserve=yes
  //## end segment::CommonHeaderSegment%3453FD6102B3.declarations

} // namespace segment

//## begin module%3597E59F0329.epilog preserve=yes
//## end module%3597E59F0329.epilog
