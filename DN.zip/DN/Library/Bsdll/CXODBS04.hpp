//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%365191100111.cm preserve=no
//	$Date:   18 Jan 2018 14:11:30  $ $Author:   e1009839  $
//	$Revision:   1.8  $
//## end module%365191100111.cm

//## begin module%365191100111.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%365191100111.cp

//## Module: CXOSBS04%365191100111; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.5B.R003\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS04.hpp

#ifndef CXOSBS04_h
#define CXOSBS04_h 1

//## begin module%365191100111.additionalIncludes preserve=no
//## end module%365191100111.additionalIncludes

//## begin module%365191100111.includes preserve=yes
// $Date:   18 Jan 2018 14:11:30  $ $Author:   e1009839  $ $Revision:   1.8  $
#include <vector>
//## end module%365191100111.includes

#ifndef CXOSRU14_h
#include "CXODRU14.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CXString;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Log;
class Message;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class Segment;
class ListSegment;

} // namespace segment

//## begin module%365191100111.declarations preserve=no
//## end module%365191100111.declarations

//## begin module%365191100111.additionalDeclarations preserve=yes
//## end module%365191100111.additionalDeclarations


namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::Command%3454E2FA011D.preface preserve=yes
//## end segment::Command%3454E2FA011D.preface

//## Class: Command%3454E2FA011D; Abstract
//	The Command class encapsulates a request as an object.
//	The request can be executed or constructed and forwarded
//	in a message to another process for execution.
//
//	It is based on the Command object in the Command pattern
//	and the Observer object in the Observer pattern.
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%365196E001D8;InformationSegment { -> F}
//## Uses: <unnamed>%3651970700BC;IF::Message { -> F}
//## Uses: <unnamed>%365197240136;IF::Log { -> F}
//## Uses: <unnamed>%365199B10211;Segment { -> F}
//## Uses: <unnamed>%3BFE9ACD0138;reusable::CXString { -> F}
//## Uses: <unnamed>%457EA85E0290;ListSegment { -> F}

class DllExport Command : public reusable::Handler  //## Inherits: <unnamed>%3731D6990295
{
  //## begin segment::Command%3454E2FA011D.initialDeclarations preserve=yes
  //## end segment::Command%3454E2FA011D.initialDeclarations

  public:
    //## Constructors (generated)
      Command();

    //## Constructors (specified)
      //## Operation: Command%3472F1F50313
      //## Semantics:
      //	1. Copy pszMessageID to m_strMessageID.
      //	2. Create a new interval.
      Command (const char* pszMessageID);

    //## Destructor (generated)
      virtual ~Command();


    //## Other Operations (specified)
      //## Operation: execute%3454E30F022C
      //	Perform the functions of this command.
      virtual bool execute () = 0;

      //## Operation: deport%346CBC560271
      //	Export this command into a message buffer.
      //## Semantics:
      //	1. Call Segment::deport for each segment that is present
      //	in this command.
      //## Postconditions:
      //	1. The provided buffer pointer will point to the byte
      //	following the last segment exported.
      int deport (char** ppsBuffer);

      //## Operation: forward%346CBC7E00C0
      //	Forward this command to another process.
      //## Semantics:
      //	1. Call Application::message to get a Message object.
      //	2. Format the common and unique headers.
      //	3. Call Command::deport to copy this command into the
      //	message data.
      //	4. Call Message::send to forward this command to another
      //	process.
      //	5. Return the results of Message::send.
      int forward (const char* pszQueue) const;

      //## Operation: import%34609E7002A8
      //	Parse a command message into its individual segments.
      //## Semantics:
      //	1. Call Segment::reset for each segment in the
      //	collection.
      //	2. Parse the buffer by calling Segment::import for each
      //	segment that is present in the buffer.
      //	3. Return true if the parse is successful; else false.
      bool import (char* psBuffer, int iBuffer);

      //## Operation: log%34733EBF00FD
      //	Copy this command to the system log.
      //## Semantics:
      //	1. Call Application::message to get a Message object.
      //	2. Format the common and unique headers.
      //	3. Call Command::deport to copy this command into the
      //	message data.
      //	4. Call Application::log to copy this command to the
      //	system log.
      //	5. Return the results of Application::log.
      void log (const char* pszReason, const char* pszMessageID = 0) const;

      //## Operation: parse%3499BD8301A0
      //	Parse this command into segments.
      //## Semantics:
      //	1. Verify the message length.
      //	2. Reset all segments.
      //	3. Import the available segments.
      virtual int parse ();

      //## Operation: replicate%457D8FD50203
      virtual bool replicate ();

      //## Operation: reply%556C6B8501E8
      virtual int reply ();

      //## Operation: update%3651938B002D
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: MessageID%3472F17003C6
      const string& messageID () const
      {
        //## begin segment::Command::messageID%3472F17003C6.get preserve=no
        return m_strMessageID;
        //## end segment::Command::messageID%3472F17003C6.get
      }


      //## Attribute: Update%449020200119
      void setUpdate (const bool& value)
      {
        //## begin segment::Command::setUpdate%449020200119.set preserve=no
        m_bUpdate = value;
        //## end segment::Command::setUpdate%449020200119.set
      }


      //## Attribute: InfoIDNumber%55CA1CA50138
      const int& getInfoIDNumber () const
      {
        //## begin segment::Command::getInfoIDNumber%55CA1CA50138.get preserve=no
        return m_lInfoIDNumber;
        //## end segment::Command::getInfoIDNumber%55CA1CA50138.get
      }

      void setInfoIDNumber (const int& value)
      {
        //## begin segment::Command::setInfoIDNumber%55CA1CA50138.set preserve=no
        m_lInfoIDNumber = value;
        //## end segment::Command::setInfoIDNumber%55CA1CA50138.set
      }


    // Additional Public Declarations
      //## begin segment::Command%3454E2FA011D.public preserve=yes
      //## end segment::Command%3454E2FA011D.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Segments%346CBC1601E3
      //	The set of segments contained in this command.
      //## begin segment::Command::Segments%346CBC1601E3.attr preserve=no  protected: vector<Segment*> {VA} 
      vector<Segment*> m_hSegments;
      //## end segment::Command::Segments%346CBC1601E3.attr

      //## Attribute: Transaction%352A1FAA030A
      //## begin segment::Command::Transaction%352A1FAA030A.attr preserve=no  protected: int {UA} -1
      int m_nTransaction;
      //## end segment::Command::Transaction%352A1FAA030A.attr

      //## begin segment::Command::Update%449020200119.attr preserve=no  public: bool {U} false
      bool m_bUpdate;
      //## end segment::Command::Update%449020200119.attr

      //## begin segment::Command::InfoIDNumber%55CA1CA50138.attr preserve=no  public: int {V} 0
      int m_lInfoIDNumber;
      //## end segment::Command::InfoIDNumber%55CA1CA50138.attr

    // Additional Protected Declarations
      //## begin segment::Command%3454E2FA011D.protected preserve=yes
      //## end segment::Command%3454E2FA011D.protected

  private:
    // Additional Private Declarations
      //## begin segment::Command%3454E2FA011D.private preserve=yes
      //## end segment::Command%3454E2FA011D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Error%352A1F950260
      //## begin segment::Command::Error%352A1F950260.attr preserve=no  private: string {U} 
      string m_strError;
      //## end segment::Command::Error%352A1F950260.attr

      //## begin segment::Command::MessageID%3472F17003C6.attr preserve=no  public: string {V} 
      string m_strMessageID;
      //## end segment::Command::MessageID%3472F17003C6.attr

    // Additional Implementation Declarations
      //## begin segment::Command%3454E2FA011D.implementation preserve=yes
      //## end segment::Command%3454E2FA011D.implementation

};

//## begin segment::Command%3454E2FA011D.postscript preserve=yes
//## end segment::Command%3454E2FA011D.postscript

} // namespace segment

//## begin module%365191100111.epilog preserve=yes
using namespace segment;
//## end module%365191100111.epilog


#endif
