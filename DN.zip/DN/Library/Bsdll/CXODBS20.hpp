//  Copyright (c) 1998 - 2004
//  eFunds Corporation
// $Date:   Nov 24 2004 15:23:14  $ $Author:   D02405  $ $Revision:   1.2  $

struct segInformationSegment
{
   char sSegmentID[4];
   char sSegmentVersion[4];
   char sLengthOfSegment[8];
   char cSeverityLevel;
   char sErrorNumber[8];
   char cFormatCode;
   char sReserved[6];
   char sLengthOfText[4];
   char sText[2];
};
