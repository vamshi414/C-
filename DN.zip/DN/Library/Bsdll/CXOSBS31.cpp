//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3EC3ECC0035B.cm preserve=no
//	$Date:   Jul 16 2018 15:36:10  $ $Author:   e1009839  $ $Revision:   1.0  $
//## end module%3EC3ECC0035B.cm

//## begin module%3EC3ECC0035B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3EC3ECC0035B.cp

//## Module: CXOSBS31%3EC3ECC0035B; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXOSBS31.cpp

//## begin module%3EC3ECC0035B.additionalIncludes preserve=no
//## end module%3EC3ECC0035B.additionalIncludes

//## begin module%3EC3ECC0035B.includes preserve=yes
//## end module%3EC3ECC0035B.includes

#ifndef CXOSDB12_h
#include "CXODDB12.hpp"
#endif
#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif
#ifndef CXOSBS31_h
#include "CXODBS31.hpp"
#endif


//## begin module%3EC3ECC0035B.declarations preserve=no
//## end module%3EC3ECC0035B.declarations

//## begin module%3EC3ECC0035B.additionalDeclarations preserve=yes
//## end module%3EC3ECC0035B.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::GetColumnsVisitor

GetColumnsVisitor::GetColumnsVisitor()
  //## begin GetColumnsVisitor::GetColumnsVisitor%3EC3EAFC0196_const.hasinit preserve=no
      : m_pPersistentSegment(0)
  //## end GetColumnsVisitor::GetColumnsVisitor%3EC3EAFC0196_const.hasinit
  //## begin GetColumnsVisitor::GetColumnsVisitor%3EC3EAFC0196_const.initialization preserve=yes
  //## end GetColumnsVisitor::GetColumnsVisitor%3EC3EAFC0196_const.initialization
{
  //## begin segment::GetColumnsVisitor::GetColumnsVisitor%3EC3EAFC0196_const.body preserve=yes
  //## end segment::GetColumnsVisitor::GetColumnsVisitor%3EC3EAFC0196_const.body
}

GetColumnsVisitor::GetColumnsVisitor (segment::PersistentSegment* pPersistentSegment)
  //## begin segment::GetColumnsVisitor::GetColumnsVisitor%3EC3EBBC009C.hasinit preserve=no
      : m_pPersistentSegment(0)
  //## end segment::GetColumnsVisitor::GetColumnsVisitor%3EC3EBBC009C.hasinit
  //## begin segment::GetColumnsVisitor::GetColumnsVisitor%3EC3EBBC009C.initialization preserve=yes
  //## end segment::GetColumnsVisitor::GetColumnsVisitor%3EC3EBBC009C.initialization
{
  //## begin segment::GetColumnsVisitor::GetColumnsVisitor%3EC3EBBC009C.body preserve=yes
   memcpy(m_sID,"BS31",4);
   m_pPersistentSegment = pPersistentSegment;
  //## end segment::GetColumnsVisitor::GetColumnsVisitor%3EC3EBBC009C.body
}


GetColumnsVisitor::~GetColumnsVisitor()
{
  //## begin segment::GetColumnsVisitor::~GetColumnsVisitor%3EC3EAFC0196_dest.body preserve=yes
  //## end segment::GetColumnsVisitor::~GetColumnsVisitor%3EC3EAFC0196_dest.body
}



//## Other Operations (implementation)
void GetColumnsVisitor::visitDatabaseColumn (database::DatabaseColumn* pDatabaseColumn)
{
  //## begin segment::GetColumnsVisitor::visitDatabaseColumn%3EC3EB1D0000.body preserve=yes
   m_pPersistentSegment->addColumn(pDatabaseColumn->getName(),pDatabaseColumn->getType(),pDatabaseColumn->getLength(),pDatabaseColumn->getScale());
  //## end segment::GetColumnsVisitor::visitDatabaseColumn%3EC3EB1D0000.body
}

// Additional Declarations
  //## begin segment::GetColumnsVisitor%3EC3EAFC0196.declarations preserve=yes
  //## end segment::GetColumnsVisitor%3EC3EAFC0196.declarations

} // namespace segment

//## begin module%3EC3ECC0035B.epilog preserve=yes
//## end module%3EC3ECC0035B.epilog
