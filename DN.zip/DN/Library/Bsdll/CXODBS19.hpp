//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3D176FE301E4.cm preserve=no
//	$Date:   Jun 14 2013 08:47:02  $ $Author:   e1009652  $ $Revision:   1.8  $
//## end module%3D176FE301E4.cm

//## begin module%3D176FE301E4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3D176FE301E4.cp

//## Module: CXOSBS19%3D176FE301E4; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.3B.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS19.hpp

#ifndef CXOSBS19_h
#define CXOSBS19_h 1

//## begin module%3D176FE301E4.additionalIncludes preserve=no
//## end module%3D176FE301E4.additionalIncludes

//## begin module%3D176FE301E4.includes preserve=yes
// $Date:   Jun 14 2013 08:47:02  $ $Author:   e1009652  $ $Revision:   1.8  $
//## end module%3D176FE301E4.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
//## begin module%3D176FE301E4.declarations preserve=no
//## end module%3D176FE301E4.declarations

//## begin module%3D176FE301E4.additionalDeclarations preserve=yes
//## end module%3D176FE301E4.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::TextSegment%3D176F850138.preface preserve=yes
//## end segment::TextSegment%3D176F850138.preface

//## Class: TextSegment%3D176F850138
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport TextSegment : public Segment  //## Inherits: <unnamed>%3D176FA30242
{
  //## begin segment::TextSegment%3D176F850138.initialDeclarations preserve=yes
  //## end segment::TextSegment%3D176F850138.initialDeclarations

  public:
    //## Constructors (generated)
      TextSegment();

    //## Destructor (generated)
      virtual ~TextSegment();


    //## Other Operations (specified)
      //## Operation: fields%3D176FB100BB
      virtual struct  Fields* fields () const;

      //## Operation: size%4EAF0645039F
      short size ();

      //## Operation: writeJSON%51B9EFE101B7
      void writeJSON (const string& strLabel, string& strValue, bool bLast = false);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Text%3D176FBB0157
      const string& getText () const
      {
        //## begin segment::TextSegment::getText%3D176FBB0157.get preserve=no
        return m_strText;
        //## end segment::TextSegment::getText%3D176FBB0157.get
      }

      void setText (const string& value)
      {
        //## begin segment::TextSegment::setText%3D176FBB0157.set preserve=no
        m_strText = value;
        //## end segment::TextSegment::setText%3D176FBB0157.set
      }


    // Additional Public Declarations
      //## begin segment::TextSegment%3D176F850138.public preserve=yes
      //## end segment::TextSegment%3D176F850138.public

  protected:
    // Additional Protected Declarations
      //## begin segment::TextSegment%3D176F850138.protected preserve=yes
      //## end segment::TextSegment%3D176F850138.protected

  private:
    // Additional Private Declarations
      //## begin segment::TextSegment%3D176F850138.private preserve=yes
      //## end segment::TextSegment%3D176F850138.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%51B9F0500051
      //## begin segment::TextSegment::Buffer%51B9F0500051.attr preserve=no  private: char* {U} 0
      char* m_pBuffer;
      //## end segment::TextSegment::Buffer%51B9F0500051.attr

      //## Attribute: Offset%51B9F07B013E
      //## begin segment::TextSegment::Offset%51B9F07B013E.attr preserve=no  private: int {U} 0
      int m_iOffset;
      //## end segment::TextSegment::Offset%51B9F07B013E.attr

      //## begin segment::TextSegment::Text%3D176FBB0157.attr preserve=no  public: string {V} 
      string m_strText;
      //## end segment::TextSegment::Text%3D176FBB0157.attr

    // Additional Implementation Declarations
      //## begin segment::TextSegment%3D176F850138.implementation preserve=yes
      //## end segment::TextSegment%3D176F850138.implementation

};

//## begin segment::TextSegment%3D176F850138.postscript preserve=yes
//## end segment::TextSegment%3D176F850138.postscript

} // namespace segment

//## begin module%3D176FE301E4.epilog preserve=yes
using namespace segment;
//## end module%3D176FE301E4.epilog


#endif
