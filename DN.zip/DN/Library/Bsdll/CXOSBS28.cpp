//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%51C3585202C5.cm preserve=no
//	$Date:   May 14 2020 17:56:18  $ $Author:   e1009510  $ $Revision:   1.5  $
//## end module%51C3585202C5.cm

//## begin module%51C3585202C5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%51C3585202C5.cp

//## Module: CXOSBS28%51C3585202C5; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.4B.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXOSBS28.cpp

//## begin module%51C3585202C5.additionalIncludes preserve=no
//## end module%51C3585202C5.additionalIncludes

//## begin module%51C3585202C5.includes preserve=yes
#include "CXODIF16.hpp"
#include "CXODDB25.hpp"
#include <algorithm>
#include <cmath>
//## end module%51C3585202C5.includes

#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSTM11_h
#include "CXODTM11.hpp"
#endif
#ifndef CXOSBS28_h
#include "CXODBS28.hpp"
#endif


//## begin module%51C3585202C5.declarations preserve=no
//## end module%51C3585202C5.declarations

//## begin module%51C3585202C5.additionalDeclarations preserve=yes
//## end module%51C3585202C5.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
struct segAuditEventSegment* pAuditEventSegment = 0;
#define FIELDS 11
Fields AuditEventSegment_Fields[FIELDS + 1] =
{
   "a         ","TSTAMP_CREATED",offsetof(segAuditEventSegment,sTSTAMP_CREATED),sizeof(pAuditEventSegment->sTSTAMP_CREATED),
   "a         ","TASKID",offsetof(segAuditEventSegment,sTASKID),sizeof(pAuditEventSegment->sTASKID),
   "s%08ld    ","SEQ_NO",offsetof(segAuditEventSegment,sSEQ_NO),sizeof(pAuditEventSegment->sSEQ_NO),
   "a         ","CUST_ID",offsetof(segAuditEventSegment,sCUST_ID),sizeof(pAuditEventSegment->sCUST_ID),
   "a         ","CUST_STAT",offsetof(segAuditEventSegment,cCUST_STAT),sizeof(pAuditEventSegment->cCUST_STAT),
   "a         ","USER_ID",offsetof(segAuditEventSegment,sUSER_ID),sizeof(pAuditEventSegment->sUSER_ID),
   "s%08ld    ","EVENT_TYPE",offsetof(segAuditEventSegment,sEVENT_TYPE),sizeof(pAuditEventSegment->sEVENT_TYPE),
   "s%08ld    ","RETURN_CODE",offsetof(segAuditEventSegment,sRETURN_CODE),sizeof(pAuditEventSegment->sRETURN_CODE),
   "a         ","ORIGINATION",offsetof(segAuditEventSegment,sORIGINATION),sizeof(pAuditEventSegment->sORIGINATION),
   "a         ","RESOURCE_NAME",offsetof(segAuditEventSegment,sRESOURCE_NAME),sizeof(pAuditEventSegment->sRESOURCE_NAME),
   "a         ","RESOURCE_KEY",offsetof(segAuditEventSegment,sRESOURCE_KEY),sizeof(pAuditEventSegment->sRESOURCE_KEY),
   "~","~",0,sizeof(segAuditEventSegment)
};

//## end segment%3471F0BE0219.initialDeclarations

// Class segment::AuditEventSegment 

//## begin segment::AuditEventSegment::Instance%51D332BE03AD.attr preserve=no  private: static segment::AuditEventSegment {R} 0
segment::AuditEventSegment *AuditEventSegment::m_pInstance = 0;
//## end segment::AuditEventSegment::Instance%51D332BE03AD.attr

AuditEventSegment::AuditEventSegment()
  //## begin AuditEventSegment::AuditEventSegment%51C357660313_const.hasinit preserve=no
      : m_lEVENT_TYPE(0),
        m_lRETURN_CODE(0),
        m_lSEQ_NO(0)
  //## end AuditEventSegment::AuditEventSegment%51C357660313_const.hasinit
  //## begin AuditEventSegment::AuditEventSegment%51C357660313_const.initialization preserve=yes
  , PersistentSegment("A001","AUDIT_EVENT","QUALIFY")
  //## end AuditEventSegment::AuditEventSegment%51C357660313_const.initialization
{
  //## begin segment::AuditEventSegment::AuditEventSegment%51C357660313_const.body preserve=yes
   memcpy_s(m_sID,4,"BS28",4);
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strTSTAMP_CREATED;
   m_pField[1] = &m_strTASKID;
   m_pField[2] = &m_lSEQ_NO;
   m_pField[3] = &m_strCUST_ID;
   m_pField[4] = &m_strCUST_STAT;
   m_pField[5] = &m_strUSER_ID;
   m_pField[6] = &m_lEVENT_TYPE;
   m_pField[7] = &m_lRETURN_CODE;
   m_pField[8] = &m_strORIGINATION;
   m_pField[9] = &m_strRESOURCE_NAME;
   m_pField[10] = &m_strRESOURCE_KEY;
   Extract::instance()->getSpec("AUDITENV",m_strAUDITENV);
   Extract::instance()->getSpec("PRODUCT",m_strPRODUCT);
  //## end segment::AuditEventSegment::AuditEventSegment%51C357660313_const.body
}

AuditEventSegment::AuditEventSegment(const AuditEventSegment &right)
  //## begin AuditEventSegment::AuditEventSegment%51C357660313_copy.hasinit preserve=no
  //## end AuditEventSegment::AuditEventSegment%51C357660313_copy.hasinit
  //## begin AuditEventSegment::AuditEventSegment%51C357660313_copy.initialization preserve=yes
   : m_lEVENT_TYPE(0),
     m_lRETURN_CODE(0),
     m_lSEQ_NO(0), 
   PersistentSegment(right)
  //## end AuditEventSegment::AuditEventSegment%51C357660313_copy.initialization
{
  //## begin segment::AuditEventSegment::AuditEventSegment%51C357660313_copy.body preserve=yes
   memcpy_s(m_sID,4,"BS28",4);
   m_strTSTAMP_CREATED = right.m_strTSTAMP_CREATED;
   m_strTASKID = right.m_strTASKID;
   m_lSEQ_NO = right.m_lSEQ_NO;
   m_strCUST_ID = right.m_strCUST_ID;
   m_strCUST_STAT = right.m_strCUST_STAT;
   m_strUSER_ID = right.m_strUSER_ID;
   m_lEVENT_TYPE = right.m_lEVENT_TYPE;
   m_lRETURN_CODE = right.m_lRETURN_CODE;
   m_strORIGINATION = right.m_strORIGINATION;
   m_strRESOURCE_NAME = right.m_strRESOURCE_NAME;
   m_strRESOURCE_KEY = right.m_strRESOURCE_KEY;
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strTSTAMP_CREATED;
   m_pField[1] = &m_strTASKID;
   m_pField[2] = &m_lSEQ_NO;
   m_pField[3] = &m_strCUST_ID;
   m_pField[4] = &m_strCUST_STAT;
   m_pField[5] = &m_strUSER_ID;
   m_pField[6] = &m_lEVENT_TYPE;
   m_pField[7] = &m_lRETURN_CODE;
   m_pField[8] = &m_strORIGINATION;
   m_pField[9] = &m_strRESOURCE_NAME;
   m_pField[10] = &m_strRESOURCE_KEY;
   Extract::instance()->getSpec("AUDITENV",m_strAUDITENV);
   Extract::instance()->getSpec("PRODUCT",m_strPRODUCT);
  //## end segment::AuditEventSegment::AuditEventSegment%51C357660313_copy.body
}


AuditEventSegment::~AuditEventSegment()
{
  //## begin segment::AuditEventSegment::~AuditEventSegment%51C357660313_dest.body preserve=yes
   delete [] m_pField;
  //## end segment::AuditEventSegment::~AuditEventSegment%51C357660313_dest.body
}


AuditEventSegment & AuditEventSegment::operator=(const AuditEventSegment &right)
{
  //## begin segment::AuditEventSegment::operator=%51C357660313_assign.body preserve=yes
   if (this == &right)
      return *this;
   ((Segment&)*this) = right;
   m_strTSTAMP_CREATED = right.m_strTSTAMP_CREATED;
   m_strTASKID = right.m_strTASKID;
   m_lSEQ_NO = right.m_lSEQ_NO;
   m_strCUST_ID = right.m_strCUST_ID;
   m_strCUST_STAT = right.m_strCUST_STAT;
   m_strUSER_ID = right.m_strUSER_ID;
   m_lEVENT_TYPE = right.m_lEVENT_TYPE;
   m_lRETURN_CODE = right.m_lRETURN_CODE;
   m_strORIGINATION = right.m_strORIGINATION;
   m_strRESOURCE_NAME = right.m_strRESOURCE_NAME;
   m_strRESOURCE_KEY = right.m_strRESOURCE_KEY;
   return *this;
  //## end segment::AuditEventSegment::operator=%51C357660313_assign.body
}



//## Other Operations (implementation)
bool AuditEventSegment::_field (const char* pszName, string& strValue, bool bDescription, bool bFormat) const
{
  //## begin segment::AuditEventSegment::_field%51DAFE7802EC.body preserve=yes
   if (!strcmp(pszName,"Timestamp")) 
   {
      if (m_strTSTAMP_CREATED.length() > 13)
      {
         char sSTCK[8];
         memset(sSTCK,0x00,8);
         Clock::instance()->set(m_strTSTAMP_CREATED.substr(0,8).c_str(),m_strTSTAMP_CREATED.substr(8,6).c_str(),sSTCK);
         strValue = Clock::instance()->getYYYYMMDDHHMMSS(false,"%d-%02d-%02dT%02d:%02d:%02d");
         double dGMTOffset = Clock::instance()->getGMTOffset();
         char szGMTOffset[PERCENTD+5];
         snprintf(szGMTOffset,sizeof(szGMTOffset),"%+03d:%02d",(int)dGMTOffset,int(abs(fmod(dGMTOffset,1))*60));
         strValue.append(szGMTOffset);
      }
      return true;
   }
   if (!strcmp(pszName,"Environment"))
   {
      strValue = m_strAUDITENV;
      return true;
   }
   if (!strcmp(pszName,"Product"))
   {
      strValue = m_strPRODUCT;
      return true;
   }
   if (!strcmp(pszName,"Version"))
   {
      strValue.assign(Extract::instance()->getVersion().data(),11);
      return true;
   }
   if (!strcmp(pszName,"FileID"))
   {
      char szDX_FILE_ID[PERCENTD];
      snprintf(szDX_FILE_ID,sizeof(szDX_FILE_ID),"%d",m_iDX_FILE_ID);
      strValue = szDX_FILE_ID;
      return true;
   }
   if (!strcmp(pszName,"Outcome"))
   {
      if (m_lRETURN_CODE == 0)
         strValue = "Success";
      else
      {
         char szRETURN_CODE[PERCENTD+8];
         snprintf(szRETURN_CODE, sizeof(szRETURN_CODE), "Failure-%d", m_lRETURN_CODE);
         strValue = szRETURN_CODE;
      }
      return true;
   }
   if (!strcmp(pszName,"EventType"))
   {
      int EventType = m_lEVENT_TYPE % 100;
      switch(EventType)
      {
         case 0: 
            strValue = "SELECT"; 
            break;
         case 1: 
            strValue = "INSERT"; 
            break;
         case 2: 
            strValue = "UPDATE"; 
            break;
         case 3: 
            strValue = "DELETE"; 
            break; 
         case 4: 
            strValue = "OPERATOR COMMAND"; 
            break;
      }
      return true;
   }
   if (!strcmp(pszName,"CategoryType"))
   {
      int CategoryType = m_lEVENT_TYPE / 100;
      switch(CategoryType)
      {
         case 1: 
         case 2: 
            strValue = "Admin Action"; 
            break;
         case 3: 
            strValue = "Application ID"; 
            break; 
         case 4: 
            strValue = "Audit Log"; 
            break;
         case 5: 
            strValue = "Cardholder Data"; 
            break;
         case 6: 
            strValue = "Invalid Access"; 
            break;
         case 7: 
            strValue = "System Level Object"; 
            break;
      }
      return true;
   }
   return Segment::_field(pszName,strValue,bDescription,bFormat);
  //## end segment::AuditEventSegment::_field%51DAFE7802EC.body
}

struct  Fields* AuditEventSegment::fields () const
{
  //## begin segment::AuditEventSegment::fields%51C3613F00E0.body preserve=yes
   return &AuditEventSegment_Fields[0];
  //## end segment::AuditEventSegment::fields%51C3613F00E0.body
}

AuditEventSegment* AuditEventSegment::instance ()
{
  //## begin segment::AuditEventSegment::instance%51D32BBF0183.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new AuditEventSegment();
   return m_pInstance;

  //## end segment::AuditEventSegment::instance%51D32BBF0183.body
}

// Additional Declarations
  //## begin segment::AuditEventSegment%51C357660313.declarations preserve=yes
  //## end segment::AuditEventSegment%51C357660313.declarations

} // namespace segment

//## begin module%51C3585202C5.epilog preserve=yes
//## end module%51C3585202C5.epilog
