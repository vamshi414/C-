//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E76357E030D.cm preserve=no
//	$Date:   Jun 11 2021 00:39:34  $ $Author:   e3028298  $ $Revision:   1.6  $
//## end module%3E76357E030D.cm

//## begin module%3E76357E030D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3E76357E030D.cp

//## Module: CXOSBS22%3E76357E030D; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: D:\Devel\V03.2A.R003\ConnexPlatform\Server\Library\Bsdll\CXODBS22.hpp

#ifndef CXOSBS22_h
#define CXOSBS22_h 1

//## begin module%3E76357E030D.additionalIncludes preserve=no
//## end module%3E76357E030D.additionalIncludes

//## begin module%3E76357E030D.includes preserve=yes
// $Date:   Jun 11 2021 00:39:34  $ $Author:   e3028298  $ $Revision:   1.6  $
//## end module%3E76357E030D.includes

#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;

} // namespace segment

//## begin module%3E76357E030D.declarations preserve=no
//## end module%3E76357E030D.declarations

//## begin module%3E76357E030D.additionalDeclarations preserve=yes
//## end module%3E76357E030D.additionalDeclarations


namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::HealthMonitorSegment%3E761856038A.preface preserve=yes
//## end segment::HealthMonitorSegment%3E761856038A.preface

//## Class: HealthMonitorSegment%3E761856038A
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E7776C30261;InformationSegment { -> F}

class DllExport HealthMonitorSegment : public PersistentSegment  //## Inherits: <unnamed>%3E76351C03B9
{
  //## begin segment::HealthMonitorSegment%3E761856038A.initialDeclarations preserve=yes
  //## end segment::HealthMonitorSegment%3E761856038A.initialDeclarations

  public:
    //## Constructors (generated)
      HealthMonitorSegment();

      HealthMonitorSegment(const HealthMonitorSegment &right);

    //## Destructor (generated)
      virtual ~HealthMonitorSegment();

    //## Assignment Operation (generated)
      HealthMonitorSegment & operator=(const HealthMonitorSegment &right);


    //## Other Operations (specified)
      //## Operation: fields%3E763F57005D
      virtual struct Fields* fields () const;

      //## Operation: instance%3E763B7D0213
      //	Return the instance of the inbound or outbound message
      //	buffer.
      static HealthMonitorSegment* instance ();

      //## Operation: reset%3E763C6E0203
      void reset ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: BUCKET%3E7638AC03C8
      const reusable::string& getBUCKET () const
      {
        //## begin segment::HealthMonitorSegment::getBUCKET%3E7638AC03C8.get preserve=no
        return m_strBUCKET;
        //## end segment::HealthMonitorSegment::getBUCKET%3E7638AC03C8.get
      }

      void setBUCKET (const reusable::string& value)
      {
        //## begin segment::HealthMonitorSegment::setBUCKET%3E7638AC03C8.set preserve=no
        m_strBUCKET = value;
        //## end segment::HealthMonitorSegment::setBUCKET%3E7638AC03C8.set
      }


      //## Attribute: DOMAIN_NAME%3E7636AA029F
      const reusable::string& getDOMAIN_NAME () const
      {
        //## begin segment::HealthMonitorSegment::getDOMAIN_NAME%3E7636AA029F.get preserve=no
        return m_strDOMAIN_NAME;
        //## end segment::HealthMonitorSegment::getDOMAIN_NAME%3E7636AA029F.get
      }

      void setDOMAIN_NAME (const reusable::string& value)
      {
        //## begin segment::HealthMonitorSegment::setDOMAIN_NAME%3E7636AA029F.set preserve=no
        m_strDOMAIN_NAME = value;
        //## end segment::HealthMonitorSegment::setDOMAIN_NAME%3E7636AA029F.set
      }


      //## Attribute: IMAGE_ID%60B49854012F
      const reusable::string& getIMAGE_ID () const
      {
        //## begin segment::HealthMonitorSegment::getIMAGE_ID%60B49854012F.get preserve=no
        return m_strIMAGE_ID;
        //## end segment::HealthMonitorSegment::getIMAGE_ID%60B49854012F.get
      }

      void setIMAGE_ID (const reusable::string& value)
      {
        //## begin segment::HealthMonitorSegment::setIMAGE_ID%60B49854012F.set preserve=no
        m_strIMAGE_ID = value;
        //## end segment::HealthMonitorSegment::setIMAGE_ID%60B49854012F.set
      }


      //## Attribute: ITEM_COUNT%3E7638E70157
      const int& getITEM_COUNT () const
      {
        //## begin segment::HealthMonitorSegment::getITEM_COUNT%3E7638E70157.get preserve=no
        return m_lITEM_COUNT;
        //## end segment::HealthMonitorSegment::getITEM_COUNT%3E7638E70157.get
      }

      void setITEM_COUNT (const int& value)
      {
        //## begin segment::HealthMonitorSegment::setITEM_COUNT%3E7638E70157.set preserve=no
        m_lITEM_COUNT = value;
        //## end segment::HealthMonitorSegment::setITEM_COUNT%3E7638E70157.set
      }


      //## Attribute: MEMBER_NAME%3E76388D037A
      const reusable::string& getMEMBER_NAME () const
      {
        //## begin segment::HealthMonitorSegment::getMEMBER_NAME%3E76388D037A.get preserve=no
        return m_strMEMBER_NAME;
        //## end segment::HealthMonitorSegment::getMEMBER_NAME%3E76388D037A.get
      }

      void setMEMBER_NAME (const reusable::string& value)
      {
        //## begin segment::HealthMonitorSegment::setMEMBER_NAME%3E76388D037A.set preserve=no
        m_strMEMBER_NAME = value;
        //## end segment::HealthMonitorSegment::setMEMBER_NAME%3E76388D037A.set
      }


      //## Attribute: Operator%3E776AB60222
      const reusable::string& getOperator () const
      {
        //## begin segment::HealthMonitorSegment::getOperator%3E776AB60222.get preserve=no
        return m_strOperator;
        //## end segment::HealthMonitorSegment::getOperator%3E776AB60222.get
      }

      void setOperator (const reusable::string& value)
      {
        //## begin segment::HealthMonitorSegment::setOperator%3E776AB60222.set preserve=no
        m_strOperator = value;
        //## end segment::HealthMonitorSegment::setOperator%3E776AB60222.set
      }


      //## Attribute: TIME_PERIOD%3E7638C8029F
      const reusable::string& getTIME_PERIOD () const
      {
        //## begin segment::HealthMonitorSegment::getTIME_PERIOD%3E7638C8029F.get preserve=no
        return m_strTIME_PERIOD;
        //## end segment::HealthMonitorSegment::getTIME_PERIOD%3E7638C8029F.get
      }

      void setTIME_PERIOD (const reusable::string& value)
      {
        //## begin segment::HealthMonitorSegment::setTIME_PERIOD%3E7638C8029F.set preserve=no
        m_strTIME_PERIOD = value;
        //## end segment::HealthMonitorSegment::setTIME_PERIOD%3E7638C8029F.set
      }


    // Additional Public Declarations
      //## begin segment::HealthMonitorSegment%3E761856038A.public preserve=yes
      //## end segment::HealthMonitorSegment%3E761856038A.public

  protected:
    // Additional Protected Declarations
      //## begin segment::HealthMonitorSegment%3E761856038A.protected preserve=yes
      //## end segment::HealthMonitorSegment%3E761856038A.protected

  private:
    // Data Members for Class Attributes

      //## begin segment::HealthMonitorSegment::BUCKET%3E7638AC03C8.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strBUCKET;
      //## end segment::HealthMonitorSegment::BUCKET%3E7638AC03C8.attr

      //## begin segment::HealthMonitorSegment::DOMAIN_NAME%3E7636AA029F.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strDOMAIN_NAME;
      //## end segment::HealthMonitorSegment::DOMAIN_NAME%3E7636AA029F.attr

      //## begin segment::HealthMonitorSegment::IMAGE_ID%60B49854012F.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strIMAGE_ID;
      //## end segment::HealthMonitorSegment::IMAGE_ID%60B49854012F.attr

      //## begin segment::HealthMonitorSegment::ITEM_COUNT%3E7638E70157.attr preserve=no  public: int {U} 0
      int m_lITEM_COUNT;
      //## end segment::HealthMonitorSegment::ITEM_COUNT%3E7638E70157.attr

      //## begin segment::HealthMonitorSegment::MEMBER_NAME%3E76388D037A.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strMEMBER_NAME;
      //## end segment::HealthMonitorSegment::MEMBER_NAME%3E76388D037A.attr

      //## begin segment::HealthMonitorSegment::Operator%3E776AB60222.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strOperator;
      //## end segment::HealthMonitorSegment::Operator%3E776AB60222.attr

      //## begin segment::HealthMonitorSegment::TIME_PERIOD%3E7638C8029F.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strTIME_PERIOD;
      //## end segment::HealthMonitorSegment::TIME_PERIOD%3E7638C8029F.attr

    // Additional Private Declarations
      //## begin segment::HealthMonitorSegment%3E761856038A.private preserve=yes
      //## end segment::HealthMonitorSegment%3E761856038A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3E77409803C8
      //	A pointer to the one-and-only instance of Extract.
      //## begin segment::HealthMonitorSegment::Instance%3E77409803C8.attr preserve=no  private: static HealthMonitorSegment* {U} 0
      static HealthMonitorSegment* m_pInstance;
      //## end segment::HealthMonitorSegment::Instance%3E77409803C8.attr

    // Additional Implementation Declarations
      //## begin segment::HealthMonitorSegment%3E761856038A.implementation preserve=yes
      //## end segment::HealthMonitorSegment%3E761856038A.implementation

};

//## begin segment::HealthMonitorSegment%3E761856038A.postscript preserve=yes
//## end segment::HealthMonitorSegment%3E761856038A.postscript

} // namespace segment

//## begin module%3E76357E030D.epilog preserve=yes
//## end module%3E76357E030D.epilog


#endif
