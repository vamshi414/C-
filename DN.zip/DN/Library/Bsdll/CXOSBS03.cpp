//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3920346E011A.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3920346E011A.cm

//## begin module%3920346E011A.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3920346E011A.cp

//## Module: CXOSBS03%3920346E011A; Package body
//## Subsystem: BSDLL%394E1F8C0345
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bsdll\CXOSBS03.cpp

//## begin module%3920346E011A.additionalIncludes preserve=no
//## end module%3920346E011A.additionalIncludes

//## begin module%3920346E011A.includes preserve=yes
// $Date:   Jun 30 2006 11:35:20  $ $Author:   D02405  $ $Revision:   1.5  $
//## end module%3920346E011A.includes

#ifndef CXOSBS03_h
#include "CXODBS03.hpp"
#endif
//## begin module%3920346E011A.declarations preserve=no
//## end module%3920346E011A.declarations

//## begin module%3920346E011A.additionalDeclarations preserve=yes
//## end module%3920346E011A.additionalDeclarations


//## Modelname: Connex Foundation::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::SegmentVersion 






SegmentVersion::SegmentVersion()
  //## begin SegmentVersion::SegmentVersion%392051780337_const.hasinit preserve=no
      : m_lLastOffset(0),
        m_lStructLen(0)
  //## end SegmentVersion::SegmentVersion%392051780337_const.hasinit
  //## begin SegmentVersion::SegmentVersion%392051780337_const.initialization preserve=yes
  //## end SegmentVersion::SegmentVersion%392051780337_const.initialization
{
  //## begin segment::SegmentVersion::SegmentVersion%392051780337_const.body preserve=yes
  //## end segment::SegmentVersion::SegmentVersion%392051780337_const.body
}

SegmentVersion::SegmentVersion(const SegmentVersion &right)
  //## begin SegmentVersion::SegmentVersion%392051780337_copy.hasinit preserve=no
      : m_lLastOffset(0),
        m_lStructLen(0)
  //## end SegmentVersion::SegmentVersion%392051780337_copy.hasinit
  //## begin SegmentVersion::SegmentVersion%392051780337_copy.initialization preserve=yes
  //## end SegmentVersion::SegmentVersion%392051780337_copy.initialization
{
  //## begin segment::SegmentVersion::SegmentVersion%392051780337_copy.body preserve=yes
   memcpy(m_sID,"BS03",4);
   m_strVersion = right.m_strVersion; 
   m_strClientMU = right.m_strClientMU;
   m_lLastOffset = right.m_lLastOffset;
   m_lStructLen = right.m_lStructLen; 
  //## end segment::SegmentVersion::SegmentVersion%392051780337_copy.body
}

SegmentVersion::SegmentVersion (const char* pszVersion, const char* pszClientMU, const int lLastOffset, const int lStructLen)
  //## begin segment::SegmentVersion::SegmentVersion%392051DC0146.hasinit preserve=no
      : m_lLastOffset(0),
        m_lStructLen(0)
  //## end segment::SegmentVersion::SegmentVersion%392051DC0146.hasinit
  //## begin segment::SegmentVersion::SegmentVersion%392051DC0146.initialization preserve=yes
   ,m_strVersion(pszVersion)
   ,m_strClientMU(pszClientMU)
  //## end segment::SegmentVersion::SegmentVersion%392051DC0146.initialization
{
  //## begin segment::SegmentVersion::SegmentVersion%392051DC0146.body preserve=yes
   memcpy(m_sID,"BS03",4);
   m_lLastOffset = lLastOffset;
   m_lStructLen = lStructLen;
  //## end segment::SegmentVersion::SegmentVersion%392051DC0146.body
}


SegmentVersion::~SegmentVersion()
{
  //## begin segment::SegmentVersion::~SegmentVersion%392051780337_dest.body preserve=yes
  //## end segment::SegmentVersion::~SegmentVersion%392051780337_dest.body
}


SegmentVersion & SegmentVersion::operator=(const SegmentVersion &right)
{
  //## begin segment::SegmentVersion::operator=%392051780337_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_strVersion = right.m_strVersion; 
   m_strClientMU = right.m_strClientMU;
   m_lLastOffset = right.m_lLastOffset;
   m_lStructLen = right.m_lStructLen; 
   return *this;
  //## end segment::SegmentVersion::operator=%392051780337_assign.body
}


// Additional Declarations
  //## begin segment::SegmentVersion%392051780337.declarations preserve=yes
  //## end segment::SegmentVersion%392051780337.declarations

} // namespace segment

//## begin module%3920346E011A.epilog preserve=yes
//## end module%3920346E011A.epilog
