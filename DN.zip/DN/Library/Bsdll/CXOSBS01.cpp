//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35A3DE92022B.cm preserve=no
//	$Date:   Aug 17 2021 01:51:02  $ $Author:   e5644299  $
//	$Revision:   1.74  $
//## end module%35A3DE92022B.cm

//## begin module%35A3DE92022B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%35A3DE92022B.cp

//## Module: CXOSBS01%35A3DE92022B; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXOSBS01.cpp

//## begin module%35A3DE92022B.additionalIncludes preserve=no
//## end module%35A3DE92022B.additionalIncludes

//## begin module%35A3DE92022B.includes preserve=yes
#include <math.h>
#include "CXODIF03.hpp"
#include "CXODRU37.hpp"
#include "CXODRU07.hpp"
//## end module%35A3DE92022B.includes

#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSDB24_h
#include "CXODDB24.hpp"
#endif
#ifndef CXOSRL04_h
#include "CXODRL04.hpp"
#endif
#ifndef CXOSRL06_h
#include "CXODRL06.hpp"
#endif
#ifndef CXOSRU48_h
#include "CXODRU48.hpp"
#endif
#ifndef CXOSDB16_h
#include "CXODDB16.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif


//## begin module%35A3DE92022B.declarations preserve=no
//## end module%35A3DE92022B.declarations

//## begin module%35A3DE92022B.additionalDeclarations preserve=yes
//## end module%35A3DE92022B.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::Segment

//## begin segment::Segment::Buffer%39BA976D0100.attr preserve=no  public: static char* {V} 0
char* Segment::m_pszBuffer = 0;
//## end segment::Segment::Buffer%39BA976D0100.attr

Segment::Segment()
  //## begin Segment::Segment%3453FD3F025A_const.hasinit preserve=no
      : m_pCurrencyCode(0),
        m_pField(0),
        m_lNumberOfFields(0),
        m_bPresence(false),
        m_lSize(0),
        m_strVersion("0100")
  //## end Segment::Segment%3453FD3F025A_const.hasinit
  //## begin Segment::Segment%3453FD3F025A_const.initialization preserve=yes
  //## end Segment::Segment%3453FD3F025A_const.initialization
{
  //## begin segment::Segment::Segment%3453FD3F025A_const.body preserve=yes
  //## end segment::Segment::Segment%3453FD3F025A_const.body
}

Segment::Segment(const Segment &right)
  //## begin Segment::Segment%3453FD3F025A_copy.hasinit preserve=no
  //## end Segment::Segment%3453FD3F025A_copy.hasinit
  //## begin Segment::Segment%3453FD3F025A_copy.initialization preserve=yes
  : m_pCurrencyCode(0),
    m_pField(0),
    m_lNumberOfFields(0),
    m_bPresence(false),
    m_lSize(0),
    m_strVersion("0100")
  //## end Segment::Segment%3453FD3F025A_copy.initialization
{
  //## begin segment::Segment::Segment%3453FD3F025A_copy.body preserve=yes
   m_lNumberOfFields = right.m_lNumberOfFields;
   setPresence(right.presence());
   m_strSegmentID = right.segmentID();
   m_lSize = right.m_lSize;
   m_strVersion = right.m_strVersion;
  //## end segment::Segment::Segment%3453FD3F025A_copy.body
}

Segment::Segment (const char* pszSegmentID)
  //## begin segment::Segment::Segment%371F8EE803E4.hasinit preserve=no
      : m_pCurrencyCode(0),
        m_pField(0),
        m_lNumberOfFields(0),
        m_bPresence(false),
        m_lSize(0),
        m_strVersion("0100")
  //## end segment::Segment::Segment%371F8EE803E4.hasinit
  //## begin segment::Segment::Segment%371F8EE803E4.initialization preserve=yes
  //## end segment::Segment::Segment%371F8EE803E4.initialization
{
  //## begin segment::Segment::Segment%371F8EE803E4.body preserve=yes
   m_strSegmentID.set(pszSegmentID,strlen(pszSegmentID));
  //## end segment::Segment::Segment%371F8EE803E4.body
}


Segment::~Segment()
{
  //## begin segment::Segment::~Segment%3453FD3F025A_dest.body preserve=yes
   delete m_pCurrencyCode;
  //## end segment::Segment::~Segment%3453FD3F025A_dest.body
}


Segment & Segment::operator=(const Segment &right)
{
  //## begin segment::Segment::operator=%3453FD3F025A_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_lNumberOfFields = right.m_lNumberOfFields;
   setPresence(right.presence());
   m_strSegmentID = right.m_strSegmentID;
   m_lSize = right.m_lSize;
   m_strVersion = right.m_strVersion;
   return *this;
  //## end segment::Segment::operator=%3453FD3F025A_assign.body
}



//## Other Operations (implementation)
void Segment::addCurrencyCode (const char* pszMonetaryAmount, const char* pszCurrencyCode)
{
  //## begin segment::Segment::addCurrencyCode%41EBB029001F.body preserve=yes
   if (!m_pCurrencyCode)
      m_pCurrencyCode = new map<string,string,less<string> >;
   m_pCurrencyCode->insert(map<string, string>::value_type(string(pszMonetaryAmount),string(pszCurrencyCode)));
  //## end segment::Segment::addCurrencyCode%41EBB029001F.body
}

void Segment::addVariableExpression (const string& strTableName)
{
  //## begin segment::Segment::addVariableExpression%42C063F202BF.body preserve=yes
   struct Fields* ppszFields = fields();
   void* psAddress = 0;
   int i = 0;
   RuleVariableExpression *pRuleVariableExpression = new RuleVariableExpression();
   while (*ppszFields[i].pszName != '~')
   {
      psAddress = field(i);
      pRuleVariableExpression->setTable(strTableName);
      pRuleVariableExpression->setField(ppszFields[i].pszName);
      pRuleVariableExpression->setDataAddress(psAddress);
      pRuleVariableExpression->setDataLength(0);
      pRuleVariableExpression->setStartPosition(0);
      switch (*(ppszFields[i].pszAttributes))
      {
         case 'a':
         case 'O':
         case 'u':
         case 'U':
         case 'w':
         case 'W':
            pRuleVariableExpression->setDataType("STRING");
//                        m_pRuleVariableExpressionLoader->getDataType() == "DATE"     ||
//                        m_pRuleVariableExpressionLoader->getDataType() == "MMYYDATE" ||
//                        m_pRuleVariableExpressionLoader->getDataType() == "DDMM" ||
//                        m_pRuleVariableExpressionLoader->getDataType() == "TIME";
            break;
         case 'd':
            pRuleVariableExpression->setDataType("DOUBLE");
            break;
         case 's':
            pRuleVariableExpression->setDataType("SHORT");
            break;
         case 'l':
            pRuleVariableExpression->setDataType("LONG");
            break;
      }
      RulesEngine::instance()->addVariableExpression(*pRuleVariableExpression);
      ++i;
   }
   delete pRuleVariableExpression;
  //## end segment::Segment::addVariableExpression%42C063F202BF.body
}

bool Segment::_address (const char* pszName, void** ppsAddress, const char** ppszMetadata, bool bLoadField) const
{
  //## begin segment::Segment::_address%3EC0F3CA0203.body preserve=yes
   struct Fields* ppszFields = fields();
   int i = 0;
   while (*ppszFields[i].pszName != '~')
   {
      if (!strcmp(ppszFields[i].pszName,pszName))
      {
         if (bLoadField)
         {
           switch (*(ppszFields[i].pszAttributes))
           {
              case 'a':
              case 'A':
              case 'b':
              case 'O':
              case 'u':
              case 'U':
              case 'w':
              case 'W':
                 *(ppsAddress) = (char*)loadField(i);
                 break;
              case 'l':
              case 's':
              case 'd':
                 *(ppsAddress) = field(i);
                 break;
           }
           *(ppszMetadata) = ppszFields[i].pszAttributes;
         }
         else
         {
           *(ppsAddress) = field(i);
           *(ppszMetadata) = ppszFields[i].pszAttributes;
         }
         return true;
      }
      ++i;
   }
   return false;
  //## end segment::Segment::_address%3EC0F3CA0203.body
}

bool Segment::checkPresence ()
{
  //## begin segment::Segment::checkPresence%564C5A27015E.body preserve=yes
   struct Fields* ppszFields = fields();
   bool bPresence = false;
   for (int i = 0;i < m_lNumberOfFields;i++)
   {
      switch (*(ppszFields[i].pszAttributes))
      {
         case 'a':
         case 'A':
         case 'b':
         case 'O':
         case 'u':
         case 'U':
         case 'W':
            if ((*(string*)field(i)).length())
               bPresence = true;
            break;
         case 'c':
         case 'v':
            if ((*(CXString*)field(i)).length())
               bPresence = true;
            break;
         case 'd':
            if (*(double*)field(i) != 0)
               bPresence = true;
            break;
         case 'l':
            if (*(int*)field(i) != 0)
               bPresence = true;
            break;
         case 's':
            if(*(short int*)field(i) != 0)
               bPresence = true;
            break;
      }
      if (bPresence)
         break;
   }
   return bPresence;
  //## end segment::Segment::checkPresence%564C5A27015E.body
}

void Segment::clear ()
{
  //## begin segment::Segment::clear%39897CDF01B6.body preserve=yes
   struct Fields* ppszFields = fields();
   char szBlanks[255];
   memset(szBlanks,' ',sizeof(szBlanks));
   for (int i = 0;i < m_lNumberOfFields;i++)
   {
      switch (*(ppszFields[i].pszAttributes))
      {
         case 'a':
         case 'A':
         case 'b':
         case 'O':
            (*(string*)field(i)).assign(szBlanks,ppszFields[i].siLength);
            break;
         case 'c':
         case 'v':
            (*(CXString*)field(i)).set(szBlanks,ppszFields[i].siLength);
            break;
      }
   }
  //## end segment::Segment::clear%39897CDF01B6.body
}

void Segment::copySegment (segment::Segment& hSegment)
{
  //## begin segment::Segment::copySegment%4E80E570016F.body preserve=yes
   struct Fields* ppszFields = fields();
   struct Fields* copyFromFields = hSegment.fields();
   string strValue;
   int i = 0;
   while (*copyFromFields[i].pszName != '~')
   {
      if (hSegment.getFieldByIndex(i,strValue))
         setField(copyFromFields[i].pszName,strValue);
      i++;
   }
  //## end segment::Segment::copySegment%4E80E570016F.body
}

int Segment::deport (char** ppsBuffer)
{
  //## begin segment::Segment::deport%3454C3C70367.body preserve=yes
   struct Fields* ppszFields = fields();
   int nLengthOfSegment = 0;
   char szVersion[5] = {"    "};
   // multiple versions
   if (!m_hSegmentVersion.empty())
   {
      vector<SegmentVersion>::iterator pVersion;
      for (pVersion = m_hSegmentVersion.begin();pVersion != m_hSegmentVersion.end();++pVersion)
      {
         if (CommonHeaderSegment::instance(this)->getClientVersion() >= (*pVersion).getClientMU())
         {
            nLengthOfSegment = (*pVersion).getStructLen();
            memcpy_s(szVersion,sizeof(szVersion),(*pVersion).getVersion().data(),4);
            break;
         }
      }
   }
   // latest version only
   else
   {
      nLengthOfSegment = ppszFields[m_lNumberOfFields].siLength;
      memcpy_s(szVersion,sizeof(szVersion),segmentVersion(),4);
   }
   memset(*ppsBuffer,' ',nLengthOfSegment);
   memcpy_s(*ppsBuffer,4,segmentID(),4);
   memcpy_s((*ppsBuffer) + 4,4,szVersion,4);
   exportFields(*ppsBuffer,nLengthOfSegment);
   char szTemp[PERCENTD];
   snprintf(szTemp,sizeof(szTemp),"%08d",nLengthOfSegment);
   memcpy_s((*ppsBuffer) + 8,8,szTemp,8);
   *ppsBuffer += nLengthOfSegment;
   return 0;
  //## end segment::Segment::deport%3454C3C70367.body
}

void Segment::exportFields (char* psBuffer, int& nLengthOfSegment)
{
  //## begin segment::Segment::exportFields%457024E502CE.body preserve=yes
   struct Fields* ppszFields = fields();
   char* pValue = 0;
   char* p = 0;
   int iLength = 0;
   string strTemp;
   double d = 0;
   char szTemp[32];
   char szFormat[10] = {"         "};
   char* pszFormat = "%04d";
   int m = 4;
   int iUVariable = nLengthOfSegment;

   for (int i = 0;i < m_lNumberOfFields;i++)
   {
      if (ppszFields[i].siOffset < 0)
         continue;
      int iNPI = 0;
      Column::setNPI(ppszFields[i].pszName, iNPI);
      if ((*(ppszFields[i].pszAttributes + 8)) > '0'
         && (*(ppszFields[i].pszAttributes + 8)) <= '9'
         || iNPI > 0)
      {
         if (!iNPI)
            iNPI = *(ppszFields[i].pszAttributes + 8) - '0';
         NPI::instance(iNPI)->addMask((*((string*)field(i))).data(),
            (short)(*((string*)field(i))).length(),0,
            (*((string*)field(i))).length(),0,iNPI);
      }
      if ((ppszFields[i].siOffset + ppszFields[i].siLength) <= nLengthOfSegment
         && ppszFields[i].siLength > 0)
      {
         switch (*(ppszFields[i].pszAttributes))
         {
            case 'a':
            case 'A':
               pValue = (char*)(*((string*)field(i))).c_str();
               iLength = (*((string*)field(i))).length();
               for (int i = 0; i < iLength; i++)
                  pValue[i] = isprint((int)(unsigned char)pValue[i]) ? pValue[i] : ' ';
               break;
            case 'b':
            case 'O':
               pValue = (char*)(*((string*)field(i))).c_str();
               iLength = (*((string*)field(i))).length();
               break;
             case 'W':
               snprintf(szTemp,sizeof(szTemp),"%04d",iUVariable);
               memcpy_s(psBuffer + ppszFields[i].siOffset,4,szTemp,4);
               iLength = (*((string*)field(i))).length();
               snprintf(szTemp,sizeof(szTemp),"%06d",iLength);
               memcpy(psBuffer + iUVariable,szTemp,6);
               memcpy_s(psBuffer + iUVariable + 6,iLength,(char*)(*((string*)field(i))).c_str(),iLength);
               iUVariable += (iLength + 6);
               nLengthOfSegment += (iLength + 6);
               break;
            case 'w':
               pszFormat = "%08d";
               m = 8;
            case 'u':
               pValue = (char*)(*((string*)field(i))).c_str();
               snprintf(szTemp,sizeof(szTemp),pszFormat,(*((string*)field(i))).length());
               nLengthOfSegment += (int)((*((string*)field(i))).length() - ppszFields[i].siLength);
               memcpy_s(psBuffer + (ppszFields[i].siOffset - m),m,szTemp,m);
               iLength = (*((string*)field(i))).length();
               break;
            case 'U':
               snprintf(szTemp,sizeof(szTemp),"%04d",iUVariable);
               memcpy_s(psBuffer + ppszFields[i].siOffset,4,szTemp,4);
               iLength = (*((string*)field(i))).length();
               snprintf(szTemp,sizeof(szTemp),"%04d",iLength);
               memcpy(psBuffer + iUVariable,szTemp,4);
               memcpy_s(psBuffer + iUVariable + 4,iLength,(char*)(*((string*)field(i))).c_str(),iLength);
               iUVariable += (iLength + 4);
               nLengthOfSegment += (iLength + 4);
               break;
            case 'c':
            case 'v':
               pValue = (char*)(*((CXString*)field(i)));
               iLength = (*((CXString*)field(i))).length();
               break;
            case 'i':
               pValue = (char*)(*((IString*)field(i)));
               iLength = (*((IString*)field(i))).length();
               break;
            case 'p':
               pValue = (char*)field(i);
               iLength = strlen(pValue);
               break;
            case 'C':
               pValue = (char*)field(i);
               iLength = 1;
               break;
            case 'l':
               if (*((ppszFields[i].pszAttributes) + 1) != ' ')
               {
                  memcpy_s(szFormat,sizeof(szFormat),(ppszFields[i].pszAttributes) + 1,8);
                  p = strchr(szFormat + 2,' ');
                  if (p)
                     *p = '\0';
                  if(*(int*)field(i) == -1 &&
                     strcmp(szFormat,"%010ld") == 0)
                  {
                     strcpy(szTemp,"-000000001");
                     iLength = 10;
                  }
                  else
                     iLength = snprintf(szTemp,sizeof(szTemp),szFormat,*(int*)field(i));
               }
               else
                  iLength = snprintf(szTemp,sizeof(szTemp),"%d",*(int*)field(i));
               pValue = szTemp;
               break;
            case 'd':
               memcpy_s(szFormat,sizeof(szFormat),ppszFields[i].pszAttributes + 1,8);
               p = strchr(szFormat,' ');
               if (p)
                  *p = '\0';
               d = *(double*)field(i);
               iLength = snprintf(szTemp,sizeof(szTemp),szFormat,d);
               pValue = szTemp;
               break;
            case 's':
               if (*((ppszFields[i].pszAttributes) + 1) != ' ')
                  memcpy_s(szFormat,sizeof(szFormat),(ppszFields[i].pszAttributes)+1,8);
               else
                  strcpy(szFormat,"%d");
               iLength = snprintf(szTemp,sizeof(szTemp),szFormat,*(short int*)field(i));
               pValue = szTemp;
               break;
            default:
               pValue= "???????????";
               iLength = strlen(pValue);
         }
         if (*(ppszFields[i].pszAttributes) != 'U'
            && *(ppszFields[i].pszAttributes) != 'W')
         {
            if (iLength > ppszFields[i].siLength
               && *(ppszFields[i].pszAttributes) != 'u'
               && *(ppszFields[i].pszAttributes) != 'w')
               iLength = ppszFields[i].siLength;
            if (iLength > 0)
               memcpy_s(psBuffer + (ppszFields[i].siOffset),iLength,pValue,iLength);
         }
      }
   }
  //## end segment::Segment::exportFields%457024E502CE.body
}

bool Segment::_field (const char* pszName, CXString& hValue, bool bDescription, bool bFormat) const
{
  //## begin segment::Segment::_field%3720BB7603DB.body preserve=yes
   struct Fields* ppszFields = fields();
   char szTemp[32];
   char szFormat[10] = {"         "};
   char cFormatOption = ' ';
   char* p = 0;
   double d = 0;
   char* pLoadField = 0;
   int i = 0;
   map < string,string > :: const_iterator hIter;
   string strCURRENCY_CODE;
   string strCUR_SYMBOL("$");
   short nDECIMAL_PLACES = 2;
   char szDECIMAL_PLACES[6];
   char szValue[32]= "\0";
   if (!isalpha(*pszName))
      cFormatOption = *(pszName++);
   while (*ppszFields[i].pszName != '~')
   {
      if (!strcmp(ppszFields[i].pszName,pszName))
      {
         switch (*(ppszFields[i].pszAttributes))
         {
            case 'A':
            case 'b':
               pLoadField = (char*)loadField(i);
               if (pLoadField
                  && *(pLoadField) != '\0')
               {
                  short* siLen = (short*)(pLoadField - 2);
                  hValue.set(pLoadField,*siLen);
               }
               else
                  hValue.set((char*)(*(string*)field(i)).data(),(*(string*)field(i)).length());
               break;
            case 'a':
            case 'O':
            case 'u':
            case 'U':
            case 'w':
            case 'W':
               pLoadField = (char*)loadField(i);
               if (pLoadField && *(pLoadField) != '\0')
                  hValue.set(pLoadField,strlen(pLoadField));
               else
                  hValue.set((char*)(*(string*)field(i)).data(),(*(string*)field(i)).length());
               break;
            case 'c':
            case 'v':
               hValue = *(CXString*)field(i);
               break;
            case 'i':
               hValue.set((char*)(*(IString*)field(i)),(*(IString*)field(i)).length());
               break;
            case 'd':
               memcpy_s(szFormat,sizeof(szFormat),ppszFields[i].pszAttributes + 1,8);
               p = strchr(szFormat,' ');
               if (p)
                  *p = '\0';
               p = strstr(szFormat,".0");
               d = *(double*)field(i);
               if ((!bFormat) || (bFormat && cFormatOption == '%'))
               {
                  snprintf(szValue,sizeof(szValue),szFormat,d);
                  hValue.overlayWith(szValue);
                  break;
               }
               if (m_pCurrencyCode)
               {
                  hIter = m_pCurrencyCode->find(ppszFields[i].pszName);
                  if (hIter != m_pCurrencyCode->end())
                  {
                     CXString hVal;
                     _field(hIter->second.c_str(),hVal);
                     strCURRENCY_CODE = (char*)hVal;
                     //get decimal places and currency symbol
                     CurrencyCode::instance()->getCurrencyDetails(strCURRENCY_CODE,strCUR_SYMBOL,nDECIMAL_PLACES);
                  }
               }
               if (p)
               {
                  snprintf(szDECIMAL_PLACES,sizeof(szDECIMAL_PLACES),"%d",nDECIMAL_PLACES);
                  *(p + 1) = szDECIMAL_PLACES[0];
               }
               d = d / pow((double)10,nDECIMAL_PLACES);
               if (cFormatOption == ' ')
               {
                  strcpy(szValue,strCUR_SYMBOL.c_str());
                  strcat(szValue," ");
               }
               snprintf(szTemp,sizeof(szTemp),szFormat,d);
               strcat(szValue,szTemp);
               hValue.overlayWith(szValue);
               break;
            case 's':
               if (*((ppszFields[i].pszAttributes) + 1) != ' ')
                  memcpy_s(szFormat,sizeof(szFormat),(ppszFields[i].pszAttributes) + 1,8);
               else
                  strcpy(szFormat,"%d");
               snprintf(szTemp,sizeof(szTemp),szFormat,*(short int*)field(i));
               hValue.overlayWith(szTemp);
               break;
            case 'l':
               if (*((ppszFields[i].pszAttributes) + 1) != ' ')
               {
                  memcpy_s(szFormat,sizeof(szFormat),(ppszFields[i].pszAttributes) + 1,8);
                  p = strchr(szFormat + 2,' ');
                  if (p)
                     *p = '\0';
                  d = *(int*)field(i);
                  //*** "%-10d" is changed to "%-10.2f" (currency):
                  p = strstr(szFormat,"-10d");
                  if (p)
                  {
                     //*** convert any hard coded decimal values:
                     memcpy_s(szFormat + 4,sizeof(szFormat)-4,".2f",3);
                     if (strstr(szFormat,".2"))
                        d = d / 100;
                     snprintf(szTemp,sizeof(szTemp),szFormat,d);
                  }
                  //******************************************
                  else
                     snprintf(szTemp,sizeof(szTemp),szFormat,*(int*)field(i));
               }
               else
                  snprintf(szTemp,sizeof(szTemp),"%d",*(int*)field(i));
               hValue.overlayWith(szTemp);
               break;
            case 'p':
            case 'C':
               hValue.set((char*)field(i),ppszFields[i].siLength);
               break;
         }
         if (bDescription)
         {
            //!!! is this needed (ara) hValue.stripTrailing();
            char c = *((ppszFields[i].pszAttributes) + 9);
            string strTemp;
            bool bReturn = false;
            switch (c)
            {
               case 'f':
                  bReturn = CRTransactionTypeIndicator::description((char*)hValue,strTemp);
                  break;
            }
            if (bReturn)
               hValue.set(strTemp.data(),strTemp.length());
         }
         return true;
      }
      ++i;
   }
   return false;
  //## end segment::Segment::_field%3720BB7603DB.body
}

bool Segment::_field (const char* pszName, string& strValue, bool bDescription, bool bFormat) const
{
  //## begin segment::Segment::_field%4B731F4A0222.body preserve=yes
   CXString hValue;
   bool b = _field(pszName,hValue,bDescription,bFormat);
   strValue.assign((char*)hValue,hValue.length());
   return b;
  //## end segment::Segment::_field%4B731F4A0222.body
}

bool Segment::_fillField (const char* pszName, const string& hValue)
{
  //## begin segment::Segment::_fillField%56A783AF01A1.body preserve=yes
   bool bSizeOverrun;
   return _fillField(pszName, hValue, bSizeOverrun);
  //## end segment::Segment::_fillField%56A783AF01A1.body
}

bool Segment::_fillField (const char* pszName, const string& hValue, bool& bSizeOverrun)
{
  //## begin segment::Segment::_fillField%3E8D9B400109.body preserve=yes
   struct Fields* ppszFields = fields();
   int i = 0;
   int l = 0;
   int s = 0;
   double d = 0;
   bSizeOverrun = false;
   while (*ppszFields[i].pszName != '~')
   {
      if (!strcmp(ppszFields[i].pszName,pszName))
      {
         switch (*(ppszFields[i].pszAttributes))
         {
            case 'a':
               if (ppszFields[i].siLength != 0 && hValue.length() > ppszFields[i].siLength)
                  bSizeOverrun = true;
            case 'O':
            case 'u':
            case 'U':
            case 'W':
               *(string *)field(i) = hValue;
               break;
            case 'l':
               l = ::atol(hValue.c_str());
               *(int *)field(i) = l;
               break;
            case 'd':
               d = ::atof(hValue.c_str());
               *(double *)field(i) = d;
               break;
            case 's':
               s = ::atoi(hValue.c_str());
               *(short *)field(i) = s;
               break;
         }
         return true;
      }
      ++i;
   }
   return false;
  //## end segment::Segment::_fillField%3E8D9B400109.body
}

bool Segment::getField (const char* pszName, string& strValue, bool bDescription, bool bFormat) const
{
  //## begin segment::Segment::getField%3EC5040D01E4.body preserve=yes
   CXString strTemp;
   bool b = _field((char*)pszName,strTemp,bDescription,bFormat);
   strValue = (char*)strTemp;
   return b;
  //## end segment::Segment::getField%3EC5040D01E4.body
}

bool Segment::getFieldByIndex (int iIndex, string& hValue)
{
  //## begin segment::Segment::getFieldByIndex%4E7CC07401CC.body preserve=yes
   struct Fields* ppszFields = fields();
   char szTemp[32];
   char szFormat[10] = {"         "};
   char* p = 0;
   double d = 0;
   char szValue[32];
   if (iIndex < m_lNumberOfFields)
   {
      switch (*(ppszFields[iIndex].pszAttributes))
      {
         case 'a':
         case 'A':
         case 'b':
         case 'O':
         case 'u':
         case 'U':
         case 'w':
         case 'W':
            hValue.assign((char*)(*(string*)field(iIndex)).data(),(*(string*)field(iIndex)).length());
            break;
         case 'd':
            memcpy_s(szFormat,sizeof(szFormat),ppszFields[iIndex].pszAttributes + 1,8);
            p = strchr(szFormat,' ');
            if (p)
               *p = '\0';
            d = *(double*)field(iIndex);
            snprintf(szValue,sizeof(szValue),szFormat,d);
            hValue.assign(szValue);
            break;
         case 's':
            if (*((ppszFields[iIndex].pszAttributes) + 1) != ' ')
               memcpy_s(szFormat,sizeof(szFormat),(ppszFields[iIndex].pszAttributes) + 1,8);
            else
               strcpy(szFormat,"%d");
            snprintf(szTemp,sizeof(szTemp),szFormat,*(short int*)field(iIndex));
            hValue.assign(szTemp);
            break;
         case 'l':
            if (*((ppszFields[iIndex].pszAttributes) + 1) != ' ')
            {
               memcpy_s(szFormat,sizeof(szFormat),(ppszFields[iIndex].pszAttributes) + 1,8);
               p = strchr(szFormat + 2,' ');
               if (p)
                  *p = '\0';
               snprintf(szTemp,sizeof(szTemp),szFormat,*(int*)field(iIndex));
            }
            else
               snprintf(szTemp,sizeof(szTemp),"%d",*(int*)field(iIndex));
            hValue.assign(szTemp);
            break;
         case 'p':
         case 'C':
            hValue.assign((char*)field(iIndex),ppszFields[iIndex].siLength);
            break;
      }
      return true;
   }
   return false;
  //## end segment::Segment::getFieldByIndex%4E7CC07401CC.body
}

bool Segment::getFieldIndex (const char* pszName, int& iIndex) const
{
  //## begin segment::Segment::getFieldIndex%4D3DF3D30358.body preserve=yes
   struct Fields* ppszFields = fields();
   int i = 0;
   while (*ppszFields[i].pszName != '~')
   {
      if (!strcmp(ppszFields[i].pszName,pszName))
      {
         iIndex = i;
         return true;
      }
      i++;
   }
   iIndex = -1;
   return false;
  //## end segment::Segment::getFieldIndex%4D3DF3D30358.body
}

int Segment::import (char** ppsBuffer)
{
  //## begin segment::Segment::import%3454C3C001C3.body preserve=yes
   struct Fields* ppszFields = fields();
   int nLengthOfSegment = 0;
   // multiple versions
   if (!m_hSegmentVersion.empty())
   {
      vector<SegmentVersion>::iterator pVersion;
      for (pVersion = m_hSegmentVersion.begin();pVersion != m_hSegmentVersion.end();++pVersion)
      {
         if (memcmp((*ppsBuffer) + 4,(*pVersion).getVersion().data(),4) == 0)
            nLengthOfSegment = (*pVersion).getStructLen();
      }
      if (nLengthOfSegment == 0)
      {
         string strText((*ppsBuffer),4);
         strText += " segment expecting version(s):";
         for (pVersion = m_hSegmentVersion.begin();pVersion != m_hSegmentVersion.end();++pVersion)
         {
            strText += " ";
            strText += (*pVersion).getVersion();
         }
         InformationSegment::instance()->setText(strText);
         return STS_INVALID_VERSION_NUMBER;
      }
   }
   else
   // latest version only
   {
      nLengthOfSegment = ppszFields[m_lNumberOfFields].siLength;
      if (memcmp((*ppsBuffer) + 4,segmentVersion(),4) != 0)
      {
         string strText((*ppsBuffer),4);
         strText += " segment expecting version: ";
         strText.append(segmentVersion(),4);
         InformationSegment::instance()->setText(strText);
         return STS_INVALID_VERSION_NUMBER;
      }
   }
   // update expected length of segment based upon variable length fields
   int i = 0;
   for (i = 0;i < m_lNumberOfFields;i++)
   {
      if (*(ppszFields[i].pszAttributes) == 'u'
         && (ppszFields[i].siOffset + (ppszFields[i].siLength - 4)) <= nLengthOfSegment
         && ppszFields[i].siLength > 0)
      {
         char szTemp[5] = {"    "};
         memcpy_s(szTemp,sizeof(szTemp),(*ppsBuffer)+ppszFields[i].siOffset - 4,4);
         nLengthOfSegment += ::atoi(szTemp) - ppszFields[i].siLength;
      }
      else
      if (*(ppszFields[i].pszAttributes) == 'U'
         && (ppszFields[i].siOffset + (ppszFields[i].siLength)) <= nLengthOfSegment
         && ppszFields[i].siLength > 0)
      {
         char szTemp[5] = {"    "};
         memcpy_s(szTemp,sizeof(szTemp),(*ppsBuffer) + ppszFields[i].siOffset,4);
         int iOffset = ::atol(szTemp);
         memcpy_s(szTemp,sizeof(szTemp),(*ppsBuffer) + iOffset,4);
         int iVarDataLen = ::atol(szTemp) + 4;
         nLengthOfSegment += iVarDataLen;
      }
      else
      if (*(ppszFields[i].pszAttributes) == 'W'
         && (ppszFields[i].siOffset + (ppszFields[i].siLength)) <= nLengthOfSegment
         && ppszFields[i].siLength > 0)
      {
         char szTemp[7] = {"      "};
         memcpy_s(szTemp,sizeof(szTemp),(*ppsBuffer) + ppszFields[i].siOffset,4);
         int iOffset = ::atol(szTemp);
         memcpy_s(szTemp,sizeof(szTemp),(*ppsBuffer) + iOffset,6);
         int iVarDataLen = ::atol(szTemp) + 6;
         nLengthOfSegment += iVarDataLen;
      }
      else
      if (*(ppszFields[i].pszAttributes) == 'w'
         && (ppszFields[i].siOffset + ppszFields[i].siLength) <= nLengthOfSegment
         && ppszFields[i].siLength > 0)
      {
         char szTemp[9] = {"        "};
         memcpy_s(szTemp,sizeof(szTemp),(*ppsBuffer) + ppszFields[i].siOffset - 8,8);
         nLengthOfSegment += ::atoi(szTemp) - ppszFields[i].siLength;
      }
   }
   char szTemp[32];
   snprintf(szTemp,sizeof(szTemp),"%08d",nLengthOfSegment);
   if (memcmp((*ppsBuffer)+8,szTemp,8) != 0)
   {
      string strText((*ppsBuffer),4);
      strText += " segment expecting length: ";
      strText.append(szTemp,8);
      InformationSegment::instance()->setText(strText);
      return STS_INVALID_SEGMENT_LENGTH;
   }
   m_bPresence = true;
   importFields(*ppsBuffer,nLengthOfSegment);
   // advance the buffer pointer
   *ppsBuffer += nLengthOfSegment;
   return 0;
  //## end segment::Segment::import%3454C3C001C3.body
}

void Segment::importFields (const char* psBuffer, int nLengthOfSegment)
{
  //## begin segment::Segment::importFields%456F8B12035B.body preserve=yes
   struct Fields* ppszFields = fields();
   string strValue;
   size_t pos = string::npos;
   for (int i = 0;i < m_lNumberOfFields;i++)
   {
      int lLength = 0;
      int iOffset = 0;
      if (*(ppszFields[i].pszAttributes) == 'u')
      {
         char szTemp[5] = {"    "};
         memcpy_s(szTemp,sizeof(szTemp),psBuffer + ppszFields[i].siOffset - 4,4);
         lLength = ::atol(szTemp);
         if (lLength == 0)
            (*(string*)field(i)).erase();
      }
      else
      if (*(ppszFields[i].pszAttributes) == 'U')
      {
         char szTemp[5] = {"    "};
         memcpy_s(szTemp,sizeof(szTemp),psBuffer + ppszFields[i].siOffset,4);
         iOffset = ::atol(szTemp);
         memcpy_s(szTemp,sizeof(szTemp),psBuffer + iOffset,4);
         lLength = ::atol(szTemp);
         if (lLength == 0)
            (*(string*)field(i)).erase();
      }
      else
      if (*(ppszFields[i].pszAttributes) == 'W')
      {
         char szTemp[7] = {"      "};
         memcpy_s(szTemp,sizeof(szTemp),psBuffer + ppszFields[i].siOffset,4);
         iOffset = ::atol(szTemp);
         memcpy_s(szTemp,sizeof(szTemp),psBuffer + iOffset,6);
         lLength = ::atol(szTemp);
         if (lLength == 0)
            (*(string*)field(i)).erase();
      }
      else
      if (*(ppszFields[i].pszAttributes) == 'w')
      {
         char szTemp[9] = {"        "};
         memcpy_s(szTemp,sizeof(szTemp),psBuffer + ppszFields[i].siOffset - 8,8);
         lLength = ::atol(szTemp);
         if (lLength == 0)
            (*(string*)field(i)).erase();
      }
      else
         lLength = ppszFields[i].siLength;
      if ((ppszFields[i].siOffset + lLength <= nLengthOfSegment)
         // lLength == 0 in the metadata for fields that are not sent to the client
         && (lLength > 0))
      {
         if (*(ppszFields[i].pszAttributes) == 'U')
            strValue.assign(psBuffer + iOffset + 4,lLength);
         else if (*(ppszFields[i].pszAttributes) == 'W')
            strValue.assign(psBuffer + iOffset + 6,lLength);
         else
            strValue.assign(psBuffer + ppszFields[i].siOffset,lLength);
         // take off all the extra spaces at the end
         pos = strValue.find_last_not_of(' ');
         if (pos == string::npos)
            strValue.erase();
         else
            strValue.erase(pos + 1);
         switch (*(ppszFields[i].pszAttributes))
         {
            case 'a':
            case 'A':
            case 'b':
            case 'O':
            case 'u':
            case 'U':
            case 'w':
            case 'W':
            {
                *(string*)field(i) = strValue;
                int iNPI = 0;
                Column::setNPI(ppszFields[i].pszName, iNPI);
                if ((*(ppszFields[i].pszAttributes + 8)) > '0'
                    && (*(ppszFields[i].pszAttributes + 8)) <= '9'
                    || iNPI > 0)
                {
                    if (!iNPI)
                        iNPI = *(ppszFields[i].pszAttributes + 8) - '0';
                    NPI::instance(iNPI)->addMask((*((string*)field(i))).data(),
                        (short)(*((string*)field(i))).length(), 0,
                        (*((string*)field(i))).length(), 0, iNPI);
                }
                break;
            }
            case 'c':
            case 'v':
               (*(CXString*)field(i)).set(psBuffer + ppszFields[i].siOffset,lLength);
               break;
            case 'i':
               *(IString*)field(i) = IString(strValue.data(),strValue.length());
               break;
            case 'p':
            case 'C':
               memcpy_s((char*)field(i),lLength,strValue.c_str(),lLength);
               break;
            case 'l':
               *(int*)field(i) = ::atol(strValue.c_str());
               break;
            case 'd':
               *(double*)field(i) = ::atof(strValue.c_str());
               break;
            case 's':
               *(short int*)field(i) = ::atoi(strValue.c_str());
               break;
         }
      }
   }
  //## end segment::Segment::importFields%456F8B12035B.body
}

double Segment::lltof (int lValue1, int lValue2)
{
  //## begin segment::Segment::lltof%3720BCE3023B.body preserve=yes
   double d = 0;
   if (lValue1 != 0)
   {
      d = lValue1;
      d = d * 4294967296e+0;
   }
   d += (unsigned int)lValue2;
   return d;
  //## end segment::Segment::lltof%3720BCE3023B.body
}

void Segment::merge (const Segment& hSegment)
{
  //## begin segment::Segment::merge%4B035BF801F4.body preserve=yes
   struct Fields* ppszFields = fields();
   for (int i = 0;i < m_lNumberOfFields;i++)
   {
         switch (*(ppszFields[i].pszAttributes))
         {
            case 'a':
            case 'A':
            case 'b':
            case 'O':
            case 'u':
            case 'U':
            case 'w':
            case 'W':
               if ((*((string*)hSegment.field(i))).length() > 0)
                  *((string*)field(i)) = *((string*)hSegment.field(i));
               break;
            case 'c':
            case 'v':
               if ((*((CXString*)hSegment.field(i))).length() > 0)
                  *((CXString*)field(i)) = *((CXString*)hSegment.field(i));
               break;
            case 'i':
               if ((*((IString*)hSegment.field(i))).length() > 0)
                  *((IString*)field(i)) = *((IString*)hSegment.field(i));
               break;
            case 'l':
               if (*((int*)hSegment.field(i)) != 0)
                  *((int*)field(i)) = *((int*)hSegment.field(i));
               break;
            case 'd':
               if (*((double*)hSegment.field(i)) != 0)
                  *((double*)field(i)) = *((double*)hSegment.field(i));
               break;
            case 's':
               if (*((short int*)hSegment.field(i)) != 0)
                  *((short int*)field(i)) = *((short int*)hSegment.field(i));
               break;
         }
   }
  //## end segment::Segment::merge%4B035BF801F4.body
}

bool Segment::offset (const char* pszName, short& siOffset, short& siLength)
{
  //## begin segment::Segment::offset%38219F0B01CE.body preserve=yes
   struct Fields* ppszFields = fields();
   int i = 0;
   while (*(ppszFields[i].pszName )!= '~')
   {
      if (!strcmp(ppszFields[i].pszName,pszName))
      {
         siOffset = ppszFields[i].siOffset;
         siLength = ppszFields[i].siLength;
         return true;
      }
      i++;
   }
   return false;
  //## end segment::Segment::offset%38219F0B01CE.body
}

int Segment::read (char** ppsBuffer)
{
  //## begin segment::Segment::read%3720BC1E021A.body preserve=yes
   return 0;
  //## end segment::Segment::read%3720BC1E021A.body
}

void Segment::replicate ()
{
  //## begin segment::Segment::replicate%457D8F990399.body preserve=yes
  //## end segment::Segment::replicate%457D8F990399.body
}

bool Segment::setField (const char* pszName, const string& hValue) const
{
  //## begin segment::Segment::setField%38283EDA0393.body preserve=yes
   struct Fields* ppszFields = fields();
   CXString strTemp;
   int i = 0;
   while (*ppszFields[i].pszName != '~')
   {
      if (!strcmp(ppszFields[i].pszName,pszName))
      {
         switch (*(ppszFields[i].pszAttributes))
         {
            case 'a':
            case 'A':
            case 'b':
            case 'O':
            case 'u':
            case 'U':
            case 'w':
            case 'W':
               *(string*)field(i) = hValue;
               break;
            case 'c':
            case 'v':
               strTemp.set(hValue.c_str(),hValue.length());
               *(CXString*)field(i) = strTemp;
               break;
            case 'i':
               *(IString*)field(i) = IString(hValue.c_str());
               break;
            case 'd':
               *(double*)field(i) = ::atof(hValue.c_str());
               break;
            case 's':
               *(short int*)field(i) = ::atoi(hValue.c_str());
               break;
            case 'l':
               *(int*)field(i) = ::atol(hValue.c_str());
                break;
            case 'p':
            case 'C':
               memcpy_s((char*)field(i), ppszFields[i].siLength,hValue.c_str(),ppszFields[i].siLength);
               break;
         }
         return true;
      }
      i++;
   }
   return false;
  //## end segment::Segment::setField%38283EDA0393.body
}

bool Segment::setFieldByIndex (int iIndex, const string& hValue)
{
  //## begin segment::Segment::setFieldByIndex%4D3DF41501C4.body preserve=yes
   struct Fields* ppszFields = fields();
   CXString strTemp;
   if (iIndex < m_lNumberOfFields)
   {
      switch (*(ppszFields[iIndex].pszAttributes))
      {
         case 'a':
         case 'A':
         case 'b':
         case 'O':
         case 'u':
         case 'U':
         case 'w':
         case 'W':
            *(string*)field(iIndex) = hValue;
            break;
         case 'c':
         case 'v':
            strTemp.set(hValue.c_str(),hValue.length());
            *(CXString*)field(iIndex) = strTemp;
            break;
         case 'i':
            *(IString*)field(iIndex) = IString(hValue.c_str());
            break;
         case 'd':
            *(double*)field(iIndex) = ::atof(hValue.c_str());
            break;
         case 's':
            *(short int*)field(iIndex) = ::atoi(hValue.c_str());
            break;
         case 'l':
            *(int*)field(iIndex) = ::atol(hValue.c_str());
            break;
         case 'p':
         case 'C':
            memcpy((char*)field(iIndex),hValue.c_str(),ppszFields[iIndex].siLength);
            break;
      }
      return true;
   }
   else
      return false;
  //## end segment::Segment::setFieldByIndex%4D3DF41501C4.body
}

int Segment::write (char** ppsBuffer)
{
  //## begin segment::Segment::write%371F8F320001.body preserve=yes
   return 0;
  //## end segment::Segment::write%371F8F320001.body
}

// Additional Declarations
  //## begin segment::Segment%3453FD3F025A.declarations preserve=yes
void Segment::wipe(const char* pszName)
{
   //## begin segment::PersistentSegment::setField%403F636F00EA.body preserve=yes
   struct Fields* ppszFields = fields();
   int i = 0;
   while (*ppszFields[i].pszName != '~')
   {
      if (!strcmp(ppszFields[i].pszName, pszName) && *(ppszFields[i].pszAttributes) == 'a')
      {
         ((string*)m_pField[i])->wipe();
         break;
      }
      ++i;
   }
}
  //## end segment::Segment%3453FD3F025A.declarations

} // namespace segment

//## begin module%35A3DE92022B.epilog preserve=yes
//## end module%35A3DE92022B.epilog
