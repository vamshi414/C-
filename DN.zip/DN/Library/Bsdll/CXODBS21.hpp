//	Copyright (c) 1998 - 2004
//	eFunds Corporation
// $Date:   Apr 08 2004 10:49:24  $ $Author:   D02405  $ $Revision:   1.1  $

struct segListResultsSegment
{
   char sSegmentID[4];
   char sSegmentVersion[4];
   char sLengthOfSegment[8];
   char sReserved[8];
   char sLengthOfRow[8];
};
