//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3720CEDD0383.cm preserve=no
//## end module%3720CEDD0383.cm

//## begin module%3720CEDD0383.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3720CEDD0383.cp

//## Module: CXOSBS02%3720CEDD0383; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXOSBS02.cpp

//## begin module%3720CEDD0383.additionalIncludes preserve=no
//## end module%3720CEDD0383.additionalIncludes

//## begin module%3720CEDD0383.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%3720CEDD0383.includes

#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSIF20_h
#include "CXODIF20.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSTM10_h
#include "CXODTM10.hpp"
#endif
#ifndef CXOSBS31_h
#include "CXODBS31.hpp"
#endif
#ifndef CXOSDB10_h
#include "CXODDB10.hpp"
#endif
#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif


//## begin module%3720CEDD0383.declarations preserve=no
//## end module%3720CEDD0383.declarations

//## begin module%3720CEDD0383.additionalDeclarations preserve=yes
//## end module%3720CEDD0383.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::PersistentSegment 

//## begin segment::PersistentSegment::Attributes%3EC36DE500FA.attr preserve=no  protected: static char*[5] {V} {0,0,0,0,0}
char* PersistentSegment::m_pszAttributes[5] = {0,0,0,0,0};
//## end segment::PersistentSegment::Attributes%3EC36DE500FA.attr

PersistentSegment::PersistentSegment()
  //## begin PersistentSegment::PersistentSegment%3720CE37012B_const.hasinit preserve=no
      : m_pFields(0),
        m_iIndex(0),
        m_pszNames(0),
        m_iNull(0),
        m_piNull(0)
  //## end PersistentSegment::PersistentSegment%3720CE37012B_const.hasinit
  //## begin PersistentSegment::PersistentSegment%3720CE37012B_const.initialization preserve=yes
  //## end PersistentSegment::PersistentSegment%3720CE37012B_const.initialization
{
  //## begin segment::PersistentSegment::PersistentSegment%3720CE37012B_const.body preserve=yes
  //## end segment::PersistentSegment::PersistentSegment%3720CE37012B_const.body
}

PersistentSegment::PersistentSegment(const PersistentSegment &right)
  //## begin PersistentSegment::PersistentSegment%3720CE37012B_copy.hasinit preserve=no
  //## end PersistentSegment::PersistentSegment%3720CE37012B_copy.hasinit
  //## begin PersistentSegment::PersistentSegment%3720CE37012B_copy.initialization preserve=yes
   : m_strQualifier(right.m_strQualifier)
   ,m_strServiceName(right.m_strServiceName)
   ,m_strTableName(right.m_strTableName)
   ,Segment(right)
  //## end PersistentSegment::PersistentSegment%3720CE37012B_copy.initialization
{
  //## begin segment::PersistentSegment::PersistentSegment%3720CE37012B_copy.body preserve=yes
   m_iNull = right.m_iNull;
   m_iIndex = 0;
   if (right.m_pFields)
   {
      m_pFields = new struct Fields[m_lNumberOfFields + 1];
      memcpy((void*)m_pFields,(void*)right.m_pFields,sizeof(struct Fields) * m_lNumberOfFields);
      m_pszNames = new char[(m_lNumberOfFields + 1) * 33];
      memcpy(m_pszNames,right.m_pszNames,(m_lNumberOfFields + 1) * 33);
      char* pszName = m_pszNames;
      m_pField = new void*[m_lNumberOfFields];
      if (right.m_piNull != 0)
         m_piNull = new short[m_lNumberOfFields];
      int i = 0;
      for (i = 0;i < m_lNumberOfFields;++i)
      {
         m_pFields[i].pszName = pszName;
         switch (m_pFields[i].pszAttributes[0])
         {
            case 'a':
            case 'O':
               m_pField[i] = new string(*((string*)right.m_pField[i]));
               break;
            case 'l':
               m_pField[i] = new int;
               *((int*)m_pField[i]) = *((int*)right.m_pField[i]);
               break;
            case 's':
               m_pField[i] = new short int;
               *((short int*)m_pField[i]) = *((short int*)right.m_pField[i]);
               break;
            case 'd':
               m_pField[i] = new double;
               *((double*)m_pField[i]) = *((double*)right.m_pField[i]);
               break;
         }
         pszName += 33;
         if (right.m_piNull != 0)
            m_piNull[i] = right.m_piNull[i];
      }
      m_pFields[i].pszName = pszName; // "~"
   }
   else
   {
      m_pFields = 0;
      m_pszNames = 0;
      m_pField = 0;
      m_piNull = 0;
   }
  //## end segment::PersistentSegment::PersistentSegment%3720CE37012B_copy.body
}

PersistentSegment::PersistentSegment (const char* pszSegmentID)
  //## begin segment::PersistentSegment::PersistentSegment%3720E2A80267.hasinit preserve=no
      : m_pFields(0),
        m_iIndex(0),
        m_pszNames(0),
        m_iNull(0),
        m_piNull(0)
  //## end segment::PersistentSegment::PersistentSegment%3720E2A80267.hasinit
  //## begin segment::PersistentSegment::PersistentSegment%3720E2A80267.initialization preserve=yes
   ,Segment(pszSegmentID)
  //## end segment::PersistentSegment::PersistentSegment%3720E2A80267.initialization
{
  //## begin segment::PersistentSegment::PersistentSegment%3720E2A80267.body preserve=yes
  //## end segment::PersistentSegment::PersistentSegment%3720E2A80267.body
}

PersistentSegment::PersistentSegment (const char* pszSegmentID, const char* pszTableName, const char* pszQualifier)
  //## begin segment::PersistentSegment::PersistentSegment%385FD9A80217.hasinit preserve=no
      : m_pFields(0),
        m_iIndex(0),
        m_pszNames(0),
        m_iNull(0),
        m_piNull(0)
  //## end segment::PersistentSegment::PersistentSegment%385FD9A80217.hasinit
  //## begin segment::PersistentSegment::PersistentSegment%385FD9A80217.initialization preserve=yes
   ,Segment(pszSegmentID)
   ,m_strQualifier(pszQualifier)
   ,m_strTableName(pszTableName)
  //## end segment::PersistentSegment::PersistentSegment%385FD9A80217.initialization
{
  //## begin segment::PersistentSegment::PersistentSegment%385FD9A80217.body preserve=yes
  //## end segment::PersistentSegment::PersistentSegment%385FD9A80217.body
}


PersistentSegment::~PersistentSegment()
{
  //## begin segment::PersistentSegment::~PersistentSegment%3720CE37012B_dest.body preserve=yes
   if (m_pFields)
   {
      for (int i = 0;i < m_lNumberOfFields;++i)
         switch (m_pFields[i].pszAttributes[0])
         {
            case 'a':
            case 'O':
               delete (string*)m_pField[i];
               break;
            case 'l':
               delete (int*)m_pField[i];
               break;
            case 's':
               delete (short int*)m_pField[i];
               break;
            case 'd':
               delete (double*)m_pField[i];
               break;
         }
      delete [] m_pField;
      delete [] m_pFields;
      delete [] m_piNull;
      delete [] m_pszNames;
   }
  //## end segment::PersistentSegment::~PersistentSegment%3720CE37012B_dest.body
}


PersistentSegment & PersistentSegment::operator=(const PersistentSegment &right)
{
  //## begin segment::PersistentSegment::operator=%3720CE37012B_assign.body preserve=yes
   if (this == &right)
      return *this;
   Segment::operator=(right);
   m_strQualifier = right.m_strQualifier;
   m_strServiceName = right.m_strServiceName;
   m_strTableName = right.m_strTableName;
   if (m_pFields)
   {
      for (int i = 0;i < m_lNumberOfFields;++i)
      {
         switch (m_pFields[i].pszAttributes[0])
         {
            case 'a':
            case 'O':
               *((string*)m_pField[i]) = *((string*)right.m_pField[i]);
               break;
            case 'l':
               *((int*)m_pField[i]) = *((int*)right.m_pField[i]);
               break;
            case 's':
               *((short int*)m_pField[i]) = *((short int*)right.m_pField[i]);
               break;
            case 'd':
               *((double*)m_pField[i]) = *((double*)right.m_pField[i]);
               break;
         }
         if (m_piNull && right.m_piNull)
            m_piNull[i] = right.m_piNull[i];
      }
   }
   return *this;
  //## end segment::PersistentSegment::operator=%3720CE37012B_assign.body
}



//## Other Operations (implementation)
void PersistentSegment::addColumn (const string& strName, short int iType, int lLength, short int iScale)
{
  //## begin segment::PersistentSegment::addColumn%5B2D321C03BC.body preserve=yes
   m_pFields[m_iIndex].siOffset = 0;
   m_pFields[m_iIndex].siLength = (short int)lLength;
   m_pFields[m_iIndex].pszAttributes = m_pszAttributes[iType];
   memcpy(m_pszNames + (m_iIndex * 33),strName.data(),strName.length());
   m_pFields[m_iIndex].pszName = m_pszNames + (m_iIndex * 33);
   switch (iType)
   {
      case 0:
      case 4:
         m_pField[m_iIndex] = new string;
         break;
      case 1:
         m_pField[m_iIndex] = new int;
         break;
      case 2:
         m_pField[m_iIndex] = new short int;
         break;
      case 3:
         m_pField[m_iIndex] = new double;
         break;
   }
   ++m_iIndex;
  //## end segment::PersistentSegment::addColumn%5B2D321C03BC.body
}

void PersistentSegment::bind (Query& hQuery)
{
  //## begin segment::PersistentSegment::bind%3720D89D0242.body preserve=yes
   struct Fields* ppszFields = fields();
   int i = 0;
   Column::ColumnType nColumnType;
   if (m_strQualifier.length())
      hQuery.setQualifier(m_strQualifier.c_str(),m_strTableName.c_str());
   while (*ppszFields[i].pszName != '~')
   {
      switch (*(ppszFields[i].pszAttributes))
      {
         case 'd':
            nColumnType = Column::DOUBLE;
            break;
         case 's':
            nColumnType = Column::SHORT;
            break;
         case 'l':
            nColumnType = Column::LONG;
            break;
         case 'O':
            nColumnType = Column::CLOB;
            break;
         default:
            nColumnType = Column::STRING;
      }
      int iNPI = 0;
      if ((*(ppszFields[i].pszAttributes + 8)) > '0'
         && (*(ppszFields[i].pszAttributes + 8)) <= '9')
         iNPI = *(ppszFields[i].pszAttributes + 8) - '0';
      if (strcmp(ppszFields[i].pszName, "PAN") == 0 && iNPI == 0)
         iNPI = 2;
      if (*(ppszFields[i].pszAttributes + 9) != 'X')
         if (m_piNull)
            hQuery.bind(m_strTableName.c_str(),ppszFields[i].pszName,nColumnType,field(i),&m_piNull[i],0,iNPI);
         else
            hQuery.bind(m_strTableName.c_str(),ppszFields[i].pszName,nColumnType,field(i),0,0,iNPI);
      i++;
   }
  //## end segment::PersistentSegment::bind%3720D89D0242.body
}

bool PersistentSegment::bindPerCatalog (Query& hQuery)
{
  //## begin segment::PersistentSegment::bindPerCatalog%5B2D322102EC.body preserve=yes
   if (!queryCatalog())
      return false;
   bind(hQuery);
   return true;
  //## end segment::PersistentSegment::bindPerCatalog%5B2D322102EC.body
}

reusable::string PersistentSegment::getKey ()
{
  //## begin segment::PersistentSegment::getKey%3DBA9F13001F.body preserve=yes
   return string("");
  //## end segment::PersistentSegment::getKey%3DBA9F13001F.body
}

bool PersistentSegment::getKey (Query& hQuery)
{
  //## begin segment::PersistentSegment::getKey%3A0EE5CE03C4.body preserve=yes
   int i = 0;
   bool bMAXRequired = false;
   hQuery.setQualifier(m_strQualifier.c_str(),m_strTableName.c_str());
   struct Fields* ppszFields = fields();
   while (*ppszFields[i].pszName != '~')
   {
      if (*(ppszFields[i].pszAttributes + 9) == 'K')
      {
         if (*(ppszFields[i].pszAttributes) == 'a')
            hQuery.setBasicPredicate(m_strTableName.c_str(),ppszFields[i].pszName,"=",(char*)(*((string*)field(i))).c_str());
         else
            hQuery.setBasicPredicate(m_strTableName.c_str(),ppszFields[i].pszName,"=",*((int*)field(i)));
      }
      else
      if (*(ppszFields[i].pszAttributes + 9) == 'T' || *(ppszFields[i].pszAttributes + 9) == 'C')
      {
         *(string*)field(i) = Transaction::instance()->getTimeStamp().substr(0,ppszFields[i].siLength);
      }
      else
      if (*(ppszFields[i].pszAttributes + 9) == 'S')
      {
         if (*(int*)field(i) == 0)
         {
            hQuery.bind(m_strTableName.c_str(),ppszFields[i].pszName,Column::LONG,field(i),&m_iNull,"MAX");
            bMAXRequired=true;
         }
         else
            hQuery.setBasicPredicate(m_strTableName.c_str(),ppszFields[i].pszName,"=",*((int*)field(i)));
      }
      i++;
   }
   return bMAXRequired;
  //## end segment::PersistentSegment::getKey%3A0EE5CE03C4.body
}

bool PersistentSegment::matches (const PersistentSegment& hPersistentSegment)
{
  //## begin segment::PersistentSegment::matches%3DBA9F5B03C8.body preserve=yes
   struct Fields* ppszFields = fields();
   char szTemp[64];
   int i = 0;
   while (*ppszFields[i].pszName != '~')
   {
      if (strncmp(ppszFields[i].pszName,"CC_",3) || strcmp(ppszFields[i].pszName,"CC_STATE") == 0)
         switch (*(ppszFields[i].pszAttributes))
         {
            case 'a':
            case 'A':
            case 'b':
            case 'O':
            case 'u':
            case 'U':
            case 'w':
               if (*(string*)hPersistentSegment.field(i) != "?"
                  && *(string*)field(i) != *(string*)hPersistentSegment.field(i))
               {
                  strcpy(szTemp,"match fail on ");
                  size_t length = min( (sizeof(szTemp) - strlen(szTemp) -1), strlen(ppszFields[i].pszName));
                  strncat(szTemp, ppszFields[i].pszName, length);
                  Trace::put(szTemp);
                  Trace::put((*(string*)field(i)).c_str());
                  Trace::put((*(string*)hPersistentSegment.field(i)).c_str());
                  return false;
               }
               break;
         }
      i++;
   }
   return true;
  //## end segment::PersistentSegment::matches%3DBA9F5B03C8.body
}

void PersistentSegment::notify ()
{
  //## begin segment::PersistentSegment::notify%395888FE0275.body preserve=yes
   string strName("##");
   strName += m_strTableName;
   SharedResource hSharedResource(strName.c_str());
   hSharedResource.notify();
  //## end segment::PersistentSegment::notify%395888FE0275.body
}

bool PersistentSegment::queryCatalog ()
{
  //## begin segment::PersistentSegment::queryCatalog%5B2D32280272.body preserve=yes
   if (m_lNumberOfFields != 0)
      return true;
   m_lNumberOfFields = DatabaseCatalog::instance()->getColumnCount(getTableName());
   if (m_lNumberOfFields == 0)
      return false;
   m_pFields = new struct Fields[m_lNumberOfFields + 1];
   if (!m_pszAttributes[0])
   {
      m_pszAttributes[0] = new char[11];
      strcpy(m_pszAttributes[0],"a         ");
      m_pszAttributes[1] = new char[11];
      strcpy(m_pszAttributes[1],"l%01d     ");
      m_pszAttributes[2] = new char[11];
      strcpy(m_pszAttributes[2],"s%01hd    ");
      m_pszAttributes[3] = new char[11];
      strcpy(m_pszAttributes[3],"d%01.0f   ");
      m_pszAttributes[4] = new char[11];
      strcpy(m_pszAttributes[4],"O         ");
   }
   m_pszNames = new char[(m_lNumberOfFields + 1) * 33];
   memset(m_pszNames,'\0',(m_lNumberOfFields + 1) * 33);
   char* pszName = m_pszNames;
   m_pField = new void*[m_lNumberOfFields];
   *(m_pszNames + (m_lNumberOfFields * 33)) = '~';
   m_pFields[m_lNumberOfFields].pszName = m_pszNames + (m_lNumberOfFields * 33);
   m_piNull = new short[m_lNumberOfFields];
   for (int i = 0;i < m_lNumberOfFields;++i)
      m_piNull[i] = 0;
   GetColumnsVisitor hGetColumnsVisitor(this);
   DatabaseCatalog::instance()->accept(hGetColumnsVisitor,getTableName());
   return true;
  //## end segment::PersistentSegment::queryCatalog%5B2D32280272.body
}

void PersistentSegment::reset ()
{
  //## begin segment::PersistentSegment::reset%3F44CDBE0167.body preserve=yes
   Segment::reset();
   struct Fields* ppszFields = fields();
   for (int i = 0;i < m_lNumberOfFields;i++)
   {
      switch (*(ppszFields[i].pszAttributes))
      {
         case 'a':
         case 'A':
         case 'b':
         case 'O':
         case 'u':
         case 'U':
         case 'W':
            if (!strcmp(ppszFields[i].pszName, "PAN"))
               (*(string*)field(i)).wipe();
            else
               (*(string*)field(i)).erase();
            break;
         case 'c':
         case 'v':
            (*(CXString*)field(i)).remove(1);
            break;
         case 'd':
            *(double*)field(i) = 0;
            break;
         case 'l':
            *(int*)field(i) = 0;
            break;
         case 's':
            *(short int*)field(i) = 0;
            break;
      }
   }
  //## end segment::PersistentSegment::reset%3F44CDBE0167.body
}

void PersistentSegment::setColumns (Table& hTable)
{
  //## begin segment::PersistentSegment::setColumns%3720CF41011A.body preserve=yes
   hTable.setName(m_strTableName.c_str());
   hTable.setQualifier(m_strQualifier.c_str());
   struct Fields* ppszFields = fields();
   int i = 0;
   bool bKey = false;
   while (*ppszFields[i].pszName != '~')
   {
      // Key Fields:- 'K'ey Field; 'T'imestamp; 'S'equence Number
      bKey = ((*(ppszFields[i].pszAttributes + 9) == 'K') || (*(ppszFields[i].pszAttributes + 9) == 'S'));
      if (*(ppszFields[i].pszAttributes + 9) != 'X')
      {
         int iNPI = ((*(ppszFields[i].pszAttributes + 8)) > '0' && (*(ppszFields[i].pszAttributes + 8)) <= '9') ? (*(ppszFields[i].pszAttributes + 8)) - '0' : 0;
         switch (*(ppszFields[i].pszAttributes))
         {
            case 'a':
               if (*(ppszFields[i].pszAttributes + 9) == 'T')
                  hTable.set(ppszFields[i].pszName,*((string*)field(i)),Column::TSTAMP_UPDATED);
               else
                  hTable.set(ppszFields[i].pszName,*((string*)field(i)),0,bKey,true,iNPI);
               break;
            case 'u':
            case 'U':
            case 'W':
               hTable.set(ppszFields[i].pszName,*((string*)field(i)),0,bKey,false,iNPI);
               break;
            case 'O':
               hTable.set(ppszFields[i].pszName,*((string*)field(i)),Column::CLOB);
               break;
            case 'd':
               if ((*(ppszFields[i].pszAttributes + 9) == 'N') && (*(double*)field(i) == 0))
                  hTable.set(ppszFields[i].pszName,"~NULL!");
               else
                  hTable.set(ppszFields[i].pszName,*((double*)field(i)),bKey);
               break;
            case 's':
               if (CommonHeaderSegment::instance()->getServiceName().find("DNCROW") != string::npos)
               {
                  if (*(ppszFields[i].pszAttributes + 9) == '#')
                     ++*((short*)field(i));
               }
               if ((*(ppszFields[i].pszAttributes + 9) == 'N') && (*(short*)field(i) == 0))
                  hTable.set(ppszFields[i].pszName,"~NULL!");
               else
                  hTable.set(ppszFields[i].pszName,(int)*((short*)field(i)),bKey);
               break;
            case 'l':
               if ((*(ppszFields[i].pszAttributes + 9) == 'N') && (*(int*)field(i) == 0))
                  hTable.set(ppszFields[i].pszName,"~NULL!");
               else
                  hTable.set(ppszFields[i].pszName,*((int*)field(i)),bKey);
               break;
         }
      }
      i++;
   }
  //## end segment::PersistentSegment::setColumns%3720CF41011A.body
}

bool PersistentSegment::setField (char* pszName, const string& strValue) const
{
  //## begin segment::PersistentSegment::setField%403F636F00EA.body preserve=yes
   if (m_piNull)
   {
      struct Fields* ppszFields = fields();
      int i = 0;
      while (*ppszFields[i].pszName != '~')
      {
         if (!strcmp(ppszFields[i].pszName,pszName))
         {
            m_piNull[i] = (strValue == "~NULL!") ? -1 : 0;
            break;
         }
         ++i;
      }
   }
   return Segment::setField(pszName,strValue);
  //## end segment::PersistentSegment::setField%403F636F00EA.body
}

bool PersistentSegment::setField (Fields* ppszFields, const char cDelimiter, char* psInputBuffer, int& iBuffer, char** psLoadField, bool bAsciiInput) const
{
  //## begin segment::PersistentSegment::setField%4FD64F2C03E1.body preserve=yes
   int i = 0;
   int j = 0;
   char *pStart = *psLoadField;
   char szValue[12];
   while (*ppszFields[i].pszAttributes != '~')
   {
      switch (*ppszFields[i].pszAttributes)
      {
      case 'a':
         {
#ifdef MVS
            if (bAsciiInput)
               CodeTable::translate(psInputBuffer,ppszFields[i].siLength,CodeTable::CX_ASCII_TO_EBCDIC);
#else
            if (!bAsciiInput)
               CodeTable::translate(psInputBuffer,ppszFields[i].siLength,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
            char *q = psInputBuffer;
            while ((cDelimiter == '~') && (q = strchr(psInputBuffer,'~')))
               *q = '-';
            if (*psInputBuffer != ' ')
            {
               memcpy(*psLoadField,psInputBuffer,ppszFields[i].siLength);
               *psLoadField = *psLoadField + ppszFields[i].siLength;
            }
            iBuffer += ppszFields[i].siLength;
            break;
         }
      case 's':
         {
            struct Temp
            {
               short siTemp;
            };
            Temp *pTemp = (Temp*)psInputBuffer;
            memset(szValue,' ',11);
            int iReturn = snprintf(szValue,sizeof(szValue),"%d",ntohs(pTemp->siTemp));
            snprintf(szValue,sizeof(szValue),"%d",ntohs(pTemp->siTemp));
            memcpy_s(*psLoadField,iReturn,szValue,iReturn);
            *psLoadField = *psLoadField + iReturn;
            iBuffer += ppszFields[i].siLength;
            break;
         }
      case 'i':
         {
            struct Temp
            {
               int iTemp;
            };
            Temp *pTemp = (Temp*)psInputBuffer;
            memset(szValue,' ',11);
            int iReturn = snprintf(szValue,sizeof(szValue),"%.2f",((ntohl(pTemp->iTemp))*.01));
            memcpy_s(*psLoadField,iReturn,szValue,iReturn);
            *psLoadField = *psLoadField + iReturn;
            iBuffer += ppszFields[i].siLength;
            break;
         }
      case 't':
         {
            if (memcmp(psInputBuffer + 2,"\0\0\0\0\0\0",6) != 0
               && memcmp(psInputBuffer + 2,"      ",6) != 0)
               memcpy_s(*psLoadField,16,NonStopClock::getYYYYMMDDHHMMSShh(psInputBuffer + 2).data(),16);
            else
               memcpy_s(*psLoadField,16,"0000000000000000",16);
            *psLoadField = *psLoadField + 16;
            iBuffer += ppszFields[i].siLength;
         }
         break;
      case 'b':
         {
            string strTemp;
            CodeTable::nibbleToByte(psInputBuffer,2,strTemp);
            char psBits[16];
            char sBits[65] = {"0000000100100011010001010110011110001001101010111100110111101111"};
            char szBuffer[32];
            char pszHex [17] = {"0123456789ABCDEF"};
            int k = 0;
            for (int n = 0;n < 4;n++)
            {
               char* p = strchr(pszHex,strTemp[n]);
               if (!p)
                  memcpy_s(psBits+(n*4),4,sBits,4);
               else
                  memcpy_s(psBits+(n*4),4,sBits+((p-pszHex)*4),4);
            }
            int r = strlen(ppszFields[i].pszName) / 3;
            for (int n = 0;n < r;n++)
            {
               if (psBits[n] == '1')
               {
                  memcpy_s(szBuffer+k,3,ppszFields[i].pszName+(n*3),3);
                  k += 3;
               }
            }
            memcpy_s(*psLoadField,k,szBuffer,k);
            *psLoadField = *psLoadField + k;
            iBuffer += 2;
         }
         break;
      default:
         psInputBuffer += ppszFields[i].siLength;
         iBuffer += ppszFields[i].siLength;
         i++;
         continue;
      }
      psInputBuffer += ppszFields[i].siLength;
      memcpy_s(*psLoadField,1,&cDelimiter,1);
      *psLoadField = *psLoadField + 1;
      i++;
   }
   *psLoadField = pStart;
   return true;
  //## end segment::PersistentSegment::setField%4FD64F2C03E1.body
}

void PersistentSegment::setFinancialData ()
{
  //## begin segment::PersistentSegment::setFinancialData%4074F98E0280.body preserve=yes
  //## end segment::PersistentSegment::setFinancialData%4074F98E0280.body
}

void PersistentSegment::setKey ()
{
  //## begin segment::PersistentSegment::setKey%3A196FC2022F.body preserve=yes
   int i = 0;
   struct Fields* ppszFields = fields();
   while (*ppszFields[i].pszName != '~')
   {
      if (*(ppszFields[i].pszAttributes + 9) == 'S')
         ++*(int*)field(i);
      i++;
   }
  //## end segment::PersistentSegment::setKey%3A196FC2022F.body
}

void PersistentSegment::setPredicate (Query& hQuery)
{
  //## begin segment::PersistentSegment::setPredicate%3A1949C200EE.body preserve=yes
   int i = 0;
   hQuery.setQualifier(m_strQualifier.c_str(),m_strTableName.c_str());
   struct Fields* ppszFields = fields();
   while (*ppszFields[i].pszName != '~')
   {
      if ((CommonHeaderSegment::instance()->getServiceName().find("DNCROW") != string::npos
         && *(ppszFields[i].pszAttributes + 9) == 'A')
         || (CommonHeaderSegment::instance()->getServiceName().find("DNDROW") != string::npos
         && (*(ppszFields[i].pszAttributes + 9) == 'K' || *(ppszFields[i].pszAttributes + 9) == 'T' || *(ppszFields[i].pszAttributes + 9) == 'S')))
      {
         if (*(ppszFields[i].pszAttributes) == 'a')
            hQuery.setBasicPredicate(m_strTableName.c_str(),ppszFields[i].pszName,"=",(char*)(*((string*)field(i))).c_str());
         else
         if (*(ppszFields[i].pszAttributes) == 's')
            hQuery.setBasicPredicate(m_strTableName.c_str(),ppszFields[i].pszName,"=",*((short*)field(i)));
         else
            hQuery.setBasicPredicate(m_strTableName.c_str(),ppszFields[i].pszName,"=",*((int*)field(i)));
      }
      else
      if (CommonHeaderSegment::instance()->getServiceName().find("DNDROW") != string::npos
         && *(ppszFields[i].pszAttributes + 9) == '#')
         hQuery.setBasicPredicate(m_strTableName.c_str(),ppszFields[i].pszName,"=",(int)*((short*)field(i)));
      i++;
   }
  //## end segment::PersistentSegment::setPredicate%3A1949C200EE.body
}

void PersistentSegment::setTStampUpdated ()
{
  //## begin segment::PersistentSegment::setTStampUpdated%3A1C22F10032.body preserve=yes
   int i = 0;
   struct Fields* ppszFields = fields();
   while (*ppszFields[i].pszName != '~')
   {
      if ((CommonHeaderSegment::instance()->getServiceName().find("DNCROW") != string::npos)
         && (*(ppszFields[i].pszAttributes + 9) == 'T' || *(ppszFields[i].pszAttributes + 9) == 'C'))
         *(string*)field(i) = Transaction::instance()->getTimeStamp().substr(0,ppszFields[i].siLength);
      else
      if ((CommonHeaderSegment::instance()->getServiceName().find("DNUROW") != string::npos)
         && (*(ppszFields[i].pszAttributes + 9) == 'T'))
         *(string*)field(i) = Transaction::instance()->getTimeStamp().substr(0,ppszFields[i].siLength);
      i++;
   }
  //## end segment::PersistentSegment::setTStampUpdated%3A1C22F10032.body
}

// Additional Declarations
  //## begin segment::PersistentSegment%3720CE37012B.declarations preserve=yes
  //## end segment::PersistentSegment%3720CE37012B.declarations

} // namespace segment

//## begin module%3720CEDD0383.epilog preserve=yes
//## end module%3720CEDD0383.epilog
