//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5AB2A7DA01D2.cm preserve=no
//	$Date:   Apr 02 2018 18:13:44  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5AB2A7DA01D2.cm

//## begin module%5AB2A7DA01D2.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5AB2A7DA01D2.cp

//## Module: CXOSBS30%5AB2A7DA01D2; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.8A.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXOSBS30.cpp

//## begin module%5AB2A7DA01D2.additionalIncludes preserve=no
//## end module%5AB2A7DA01D2.additionalIncludes

//## begin module%5AB2A7DA01D2.includes preserve=yes
//## end module%5AB2A7DA01D2.includes

#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBS03_h
#include "CXODBS03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBS30_h
#include "CXODBS30.hpp"
#endif


//## begin module%5AB2A7DA01D2.declarations preserve=no
//## end module%5AB2A7DA01D2.declarations

//## begin module%5AB2A7DA01D2.additionalDeclarations preserve=yes
struct segContactSegment
{
   char sSegmentID[4];                 // 0000
   char sSegmentVersion[4];            // 0004
   char sLengthOfSegment[8];           // 0008
   char sCONTACT_ID[10];               // 0016
   char sNAME[40];                     // 0026
   char sINST_ID[11];                  // 0066
   char sPROC_ID[8];                   // 0077
   char sPROC_GRP_ID[8];               // 0085
   char cCONTACT_METHOD;               // 0093
   char sTELEPHONE_NO[20];             // 0094
   char sFAX_NO[20];                   // 0114
   char sADDRESS_LINE_1[60];           // 0134
   char sADDRESS_LINE_2[60];           // 0194
   char sADDRESS_LINE_3[60];           // 0254
   char sADDRESS_LINE_4[60];           // 0314
   char sEMAIL_ADDRESS[60];            // 0374
   char sCONTACT_TYPE[4];              // 0434
   char sTSTAMP_UPDATED[16];           // 0438
   char sUSER_ID[8];                   // 0454
   char sCOURIER_PTR[10];              // 0462
   char sCOURIER_ROUTE_PTR[10];        // 0472
   char sUPDATED_BY_USER_ID[8];        // 0482
   char sBIN[11];                      // 0490
   char sDEVICE_ID[8];                 // 0501
   char sORG_NAME[60];                 // 0509
   char sCITY[60];                     // 0569
   char sREGION[2];                    // 0629
   char sPOSTAL_CODE[10];              // 0631
   char sCOUNTRY[60];                  // 0641
   char sRPT_LVL_ID_OBSOLETE[10];      // 0701
   char sRPT_LVL_ID[35];               // 0711
   char sReserved[3];                  // 0746
};

struct segContactSegment* pContactSegment = 0;
#define FIELDS 31
Fields ContactSegment_Fields[FIELDS + 1] =
{
   "a         ", "ADDRESS_LINE_1", offsetof(segContactSegment, sADDRESS_LINE_1), sizeof(pContactSegment->sADDRESS_LINE_1),
   "a         ", "ADDRESS_LINE_2", offsetof(segContactSegment, sADDRESS_LINE_2), sizeof(pContactSegment->sADDRESS_LINE_2),
   "a         ", "ADDRESS_LINE_3", offsetof(segContactSegment, sADDRESS_LINE_3), sizeof(pContactSegment->sADDRESS_LINE_3),
   "a         ", "ADDRESS_LINE_4", offsetof(segContactSegment, sADDRESS_LINE_4), sizeof(pContactSegment->sADDRESS_LINE_4),
   "l         ", "CONTACT_ID", offsetof(segContactSegment, sCONTACT_ID), sizeof(pContactSegment->sCONTACT_ID),
   "a         ", "CONTACT_METHOD", offsetof(segContactSegment, cCONTACT_METHOD), sizeof(pContactSegment->cCONTACT_METHOD),
   "a         ", "CONTACT_TYPE", offsetof(segContactSegment, sCONTACT_TYPE), sizeof(pContactSegment->sCONTACT_TYPE),
   "a         ", "EMAIL_ADDRESS", offsetof(segContactSegment, sEMAIL_ADDRESS), sizeof(pContactSegment->sEMAIL_ADDRESS),
   "a         ", "FAX_NO", offsetof(segContactSegment, sFAX_NO), sizeof(pContactSegment->sFAX_NO),
   "a         ", "INST_ID", offsetof(segContactSegment, sINST_ID), sizeof(pContactSegment->sINST_ID),
   "a         ", "NAME", offsetof(segContactSegment, sNAME), sizeof(pContactSegment->sNAME),
   "a         ", "PROC_GRP_ID", offsetof(segContactSegment, sPROC_GRP_ID), sizeof(pContactSegment->sPROC_GRP_ID),
   "a         ", "PROC_ID", offsetof(segContactSegment, sPROC_ID), sizeof(pContactSegment->sPROC_ID),
   "a         ", "TELEPHONE_NO", offsetof(segContactSegment, sTELEPHONE_NO), sizeof(pContactSegment->sTELEPHONE_NO),
   "a        T", "TSTAMP_UPDATED", offsetof(segContactSegment, sTSTAMP_UPDATED), sizeof(pContactSegment->sTSTAMP_UPDATED),
   "a         ", "USER_ID", offsetof(segContactSegment, sUSER_ID), sizeof(pContactSegment->sUSER_ID),
   "l%010ld   S", "COURIER_PTR", offsetof(segContactSegment, sCOURIER_PTR), sizeof(pContactSegment->sCOURIER_PTR),
   "l%010ld   S", "COURIER_ROUTE_PTR", offsetof(segContactSegment, sCOURIER_ROUTE_PTR), sizeof(pContactSegment->sCOURIER_ROUTE_PTR),
   "a         ", "UPDATED_BY_USER_ID", offsetof(segContactSegment, sUPDATED_BY_USER_ID), sizeof(pContactSegment->sUPDATED_BY_USER_ID),
   "a         ", "BIN", offsetof(segContactSegment, sBIN), sizeof(pContactSegment->sBIN),
   "a         ", "DEVICE_ID", offsetof(segContactSegment, sDEVICE_ID), sizeof(pContactSegment->sDEVICE_ID),
   "a        X", "ContactInstID", 0, 0,
   "a        X", "ContactProcID", 0, 0,
   "a         ", "ORG_NAME", offsetof(segContactSegment, sORG_NAME), sizeof(pContactSegment->sORG_NAME),
   "a         ", "CITY", offsetof(segContactSegment, sCITY), sizeof(pContactSegment->sCITY),
   "a         ", "REGION", offsetof(segContactSegment, sREGION), sizeof(pContactSegment->sREGION),
   "a         ", "POSTAL_CODE", offsetof(segContactSegment, sPOSTAL_CODE), sizeof(pContactSegment->sPOSTAL_CODE),
   "a         ", "COUNTRY", offsetof(segContactSegment, sCOUNTRY), sizeof(pContactSegment->sCOUNTRY),
   "a        X", "RPT_LVL_ID_OBSOLETE", offsetof(segContactSegment, sRPT_LVL_ID_OBSOLETE), sizeof(pContactSegment->sRPT_LVL_ID_OBSOLETE),
   "a         ", "ORIGIN", 0, 0,
   "a         ", "RPT_LVL_ID", offsetof(segContactSegment, sRPT_LVL_ID), sizeof(pContactSegment->sRPT_LVL_ID),
   "~", "~", 0, sizeof(segContactSegment)
};

ContactSegment* ContactSegment::m_pInstance[3] = { 0, 0, 0 };
//## end module%5AB2A7DA01D2.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::ContactSegment 

ContactSegment::ContactSegment()
  //## begin ContactSegment::ContactSegment%5AB2A71701C4_const.hasinit preserve=no
      : m_lCONTACT_ID(0),
        m_lCOURIER_PTR(0),
        m_lCOURIER_ROUTE_PTR(0)
  //## end ContactSegment::ContactSegment%5AB2A71701C4_const.hasinit
  //## begin ContactSegment::ContactSegment%5AB2A71701C4_const.initialization preserve=yes
  , PersistentSegment("S212")
  //## end ContactSegment::ContactSegment%5AB2A71701C4_const.initialization
{
  //## begin segment::ContactSegment::ContactSegment%5AB2A71701C4_const.body preserve=yes
   memcpy(m_sID, "BS30", 4);
   setFields();
   reset();
   if (!Extract::instance()->getSpec("ORIGIN", m_strOrigin))
      m_strOrigin = "DataNavigator@fisglobal.com";
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0107", JUN_2013_MU, 711, sizeof(segContactSegment)));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0106", NOV_2005_MU, 711, 712));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0105", JAN_2004_MU, 509, 512));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0104", AUG_2002_MU, 501, 504));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0103", SEP_2001_MU, 490, 496));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0102", JAN_2001_MU, 482, 488));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0101", SEP_1999_MU, 463, 464));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0100", SEP_1999_MU, 455, 456));
  //## end segment::ContactSegment::ContactSegment%5AB2A71701C4_const.body
}

ContactSegment::ContactSegment(const ContactSegment &right)
  //## begin ContactSegment::ContactSegment%5AB2A71701C4_copy.hasinit preserve=no
  //## end ContactSegment::ContactSegment%5AB2A71701C4_copy.hasinit
  //## begin ContactSegment::ContactSegment%5AB2A71701C4_copy.initialization preserve=yes
  : m_lCONTACT_ID(0),
  m_lCOURIER_PTR(0),
  m_lCOURIER_ROUTE_PTR(0)
  //## end ContactSegment::ContactSegment%5AB2A71701C4_copy.initialization
{
  //## begin segment::ContactSegment::ContactSegment%5AB2A71701C4_copy.body preserve=yes
   setFields();
   m_strADDRESS_LINE_1 = right.m_strADDRESS_LINE_1;
   m_strADDRESS_LINE_2 = right.m_strADDRESS_LINE_2;
   m_strADDRESS_LINE_3 = right.m_strADDRESS_LINE_3;
   m_strADDRESS_LINE_4 = right.m_strADDRESS_LINE_4;
   m_strBIN = right.m_strBIN;
   m_lCONTACT_ID = right.m_lCONTACT_ID;
   m_strCONTACT_METHOD = right.m_strCONTACT_METHOD;
   m_strCONTACT_TYPE = right.m_strCONTACT_TYPE;
   m_strDEVICE_ID = right.m_strDEVICE_ID;
   m_strEMAIL_ADDRESS = right.m_strEMAIL_ADDRESS;
   m_strFAX_NO = right.m_strFAX_NO;
   m_strINST_ID = right.m_strINST_ID;
   m_strNAME = right.m_strNAME;
   m_strPROC_GRP_ID = right.m_strPROC_GRP_ID;
   m_strPROC_ID = right.m_strPROC_ID;
   m_strTELEPHONE_NO = right.m_strTELEPHONE_NO;
   m_strTSTAMP_UPDATED = right.m_strTSTAMP_UPDATED;
   m_lCOURIER_PTR = right.m_lCOURIER_PTR;
   m_lCOURIER_ROUTE_PTR = right.m_lCOURIER_ROUTE_PTR;
   m_strUPDATED_BY_USER_ID = right.m_strUPDATED_BY_USER_ID;
   m_strContactInstID = right.m_strContactInstID;
   m_strContactProcID = right.m_strContactProcID;
   m_strORG_NAME = right.m_strORG_NAME;
   m_strCITY = right.m_strCITY;
   m_strREGION = right.m_strREGION;
   m_strPOSTAL_CODE = right.m_strPOSTAL_CODE;
   m_strCOUNTRY = right.m_strCOUNTRY;
   m_strRPT_LVL_ID = right.m_strRPT_LVL_ID;
   m_strRPT_LVL_ID_OBSOLETE = right.m_strRPT_LVL_ID_OBSOLETE;
   m_strOrigin = right.m_strOrigin;
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0107", JUN_2013_MU, 711, sizeof(segContactSegment)));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0106", NOV_2005_MU, 711, 712));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0105", JAN_2004_MU, 509, 512));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0104", AUG_2002_MU, 501, 504));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0103", SEP_2001_MU, 490, 496));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0102", JAN_2001_MU, 482, 488));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0101", SEP_1999_MU, 463, 464));
   Segment::m_hSegmentVersion.push_back(SegmentVersion("0100", SEP_1999_MU, 455, 456));
  //## end segment::ContactSegment::ContactSegment%5AB2A71701C4_copy.body
}


ContactSegment::~ContactSegment()
{
  //## begin segment::ContactSegment::~ContactSegment%5AB2A71701C4_dest.body preserve=yes
   delete[] m_pField;
  //## end segment::ContactSegment::~ContactSegment%5AB2A71701C4_dest.body
}


ContactSegment & ContactSegment::operator=(const ContactSegment &right)
{
  //## begin segment::ContactSegment::operator=%5AB2A71701C4_assign.body preserve=yes
   if (this == &right)
      return *this;
   PersistentSegment::operator=(right);
   m_strADDRESS_LINE_1 = right.m_strADDRESS_LINE_1;
   m_strADDRESS_LINE_2 = right.m_strADDRESS_LINE_2;
   m_strADDRESS_LINE_3 = right.m_strADDRESS_LINE_3;
   m_strADDRESS_LINE_4 = right.m_strADDRESS_LINE_4;
   m_strBIN = right.m_strBIN;
   m_lCONTACT_ID = right.m_lCONTACT_ID;
   m_strCONTACT_METHOD = right.m_strCONTACT_METHOD;
   m_strCONTACT_TYPE = right.m_strCONTACT_TYPE;
   m_strDEVICE_ID = right.m_strDEVICE_ID;
   m_strEMAIL_ADDRESS = right.m_strEMAIL_ADDRESS;
   m_strFAX_NO = right.m_strFAX_NO;
   m_strINST_ID = right.m_strINST_ID;
   m_strNAME = right.m_strNAME;
   m_strPROC_GRP_ID = right.m_strPROC_GRP_ID;
   m_strPROC_ID = right.m_strPROC_ID;
   m_strTELEPHONE_NO = right.m_strTELEPHONE_NO;
   m_strTSTAMP_UPDATED = right.m_strTSTAMP_UPDATED;
   m_lCOURIER_PTR = right.m_lCOURIER_PTR;
   m_lCOURIER_ROUTE_PTR = right.m_lCOURIER_ROUTE_PTR;
   m_strUPDATED_BY_USER_ID = right.m_strUPDATED_BY_USER_ID;
   m_strContactInstID = right.m_strContactInstID;
   m_strContactProcID = right.m_strContactProcID;
   m_strORG_NAME = right.m_strORG_NAME;
   m_strCITY = right.m_strCITY;
   m_strREGION = right.m_strREGION;
   m_strPOSTAL_CODE = right.m_strPOSTAL_CODE;
   m_strCOUNTRY = right.m_strCOUNTRY;
   m_strRPT_LVL_ID = right.m_strRPT_LVL_ID;
   m_strRPT_LVL_ID_OBSOLETE = right.m_strRPT_LVL_ID_OBSOLETE;
   m_strOrigin = right.m_strOrigin;
   return *this;
  //## end segment::ContactSegment::operator=%5AB2A71701C4_assign.body
}



//## Other Operations (implementation)
void ContactSegment::bind (Query& hQuery)
{
  //## begin segment::ContactSegment::bind%5AB2ADED023E.body preserve=yes
   hQuery.bind("CONTACT_TYPE", "ADDRESS_LINE_1", Column::STRING, &m_strADDRESS_LINE_1);
   hQuery.bind("CONTACT_TYPE", "ADDRESS_LINE_2", Column::STRING, &m_strADDRESS_LINE_2);
   hQuery.bind("CONTACT_TYPE", "ADDRESS_LINE_3", Column::STRING, &m_strADDRESS_LINE_3);
   hQuery.bind("CONTACT_TYPE", "ADDRESS_LINE_4", Column::STRING, &m_strADDRESS_LINE_4);
   hQuery.bind("CONTACT_TYPE", "CONTACT_ID", Column::LONG, &m_lCONTACT_ID);
   hQuery.bind("CONTACT_TYPE", "CONTACT_METHOD", Column::STRING, &m_strCONTACT_METHOD);
   hQuery.bind("CONTACT_TYPE", "CONTACT_TYPE", Column::STRING, &m_strCONTACT_TYPE);
   hQuery.bind("CONTACT_TYPE", "EMAIL_ADDRESS", Column::STRING, &m_strEMAIL_ADDRESS);
   hQuery.bind("CONTACT_TYPE", "FAX_NO", Column::STRING, &m_strFAX_NO);
   hQuery.bind("CONTACT_TYPE", "NAME", Column::STRING, &m_strNAME);
   hQuery.bind("CONTACT_TYPE", "TELEPHONE_NO", Column::STRING, &m_strTELEPHONE_NO);
   hQuery.bind("CONTACT_TYPE", "TSTAMP_UPDATED", Column::STRING, &m_strTSTAMP_UPDATED);
   hQuery.bind("CONTACT_TYPE", "UPDATED_BY_USER_ID", Column::STRING, &m_strUPDATED_BY_USER_ID);
   hQuery.bind("CONTACT_TYPE", "ORG_NAME", Column::STRING, &m_strORG_NAME);
   hQuery.bind("CONTACT_TYPE", "CITY", Column::STRING, &m_strCITY);
   hQuery.bind("CONTACT_TYPE", "REGION", Column::STRING, &m_strREGION);
   hQuery.bind("CONTACT_TYPE", "POSTAL_CODE", Column::STRING, &m_strPOSTAL_CODE);
   hQuery.bind("CONTACT_TYPE", "COUNTRY", Column::STRING, &m_strCOUNTRY);
  //## end segment::ContactSegment::bind%5AB2ADED023E.body
}

struct Fields* ContactSegment::fields () const
{
  //## begin segment::ContactSegment::fields%5AB2A9480387.body preserve=yes
   return &ContactSegment_Fields[0];
  //## end segment::ContactSegment::fields%5AB2A9480387.body
}

ContactSegment* ContactSegment::instance (Type nType)
{
  //## begin segment::ContactSegment::instance%5AB2A948038B.body preserve=yes
   if (!m_pInstance[nType])
      m_pInstance[nType] = new ContactSegment();
   return m_pInstance[nType];
  //## end segment::ContactSegment::instance%5AB2A948038B.body
}

void ContactSegment::reset ()
{
  //## begin segment::ContactSegment::reset%5AB2A948038F.body preserve=yes
   Segment::reset();
   m_strADDRESS_LINE_1.erase();
   m_strADDRESS_LINE_2.erase();
   m_strADDRESS_LINE_3.erase();
   m_strADDRESS_LINE_4.erase();
   m_strBIN.erase();
   m_lCONTACT_ID = 0;
   m_strCONTACT_METHOD.erase();
   m_strCONTACT_TYPE.erase();
   m_strDEVICE_ID.erase();
   m_strEMAIL_ADDRESS.erase();
   m_strFAX_NO.erase();
   m_strINST_ID.erase();
   m_strNAME.erase();
   m_strPROC_GRP_ID.erase();
   m_strPROC_ID.erase();
   m_strTELEPHONE_NO.erase();
   m_strTSTAMP_UPDATED.erase();
   m_lCOURIER_PTR = 0;
   m_lCOURIER_ROUTE_PTR = 0;
   m_strUPDATED_BY_USER_ID.erase();
   m_strUSER_ID.erase();
   m_strORG_NAME.erase();
   m_strCITY.erase();
   m_strREGION.erase();
   m_strPOSTAL_CODE.erase();
   m_strCOUNTRY.erase();
   m_strRPT_LVL_ID.erase();
   m_strRPT_LVL_ID_OBSOLETE.erase();
  //## end segment::ContactSegment::reset%5AB2A948038F.body
}

void ContactSegment::setColumns (Table& hTable)
{
  //## begin segment::ContactSegment::setColumns%5AB2A9480393.body preserve=yes
   hTable.setName("CONTACT_TYPE");
   hTable.setQualifier("QUALIFY");
   hTable.set("ADDRESS_LINE_1", m_strADDRESS_LINE_1);
   hTable.set("ADDRESS_LINE_2", m_strADDRESS_LINE_2);
   hTable.set("ADDRESS_LINE_3", m_strADDRESS_LINE_3);
   hTable.set("ADDRESS_LINE_4", m_strADDRESS_LINE_4);
   hTable.set("CONTACT_ID", m_lCONTACT_ID, true);
   hTable.set("CONTACT_METHOD", m_strCONTACT_METHOD);
   hTable.set("CONTACT_TYPE", m_strCONTACT_TYPE, false, true);
   hTable.set("EMAIL_ADDRESS", m_strEMAIL_ADDRESS);
   hTable.set("FAX_NO", m_strFAX_NO);
   hTable.set("NAME", m_strNAME);
   hTable.set("TELEPHONE_NO", m_strTELEPHONE_NO);
   hTable.set("TSTAMP_UPDATED", m_strTSTAMP_UPDATED, Column::TSTAMP_UPDATED);
   hTable.set("UPDATED_BY_USER_ID", m_strUPDATED_BY_USER_ID);
   hTable.set("ORG_NAME", m_strORG_NAME);
   hTable.set("CITY", m_strCITY);
   hTable.set("REGION", m_strREGION);
   hTable.set("POSTAL_CODE", m_strPOSTAL_CODE);
   hTable.set("COUNTRY", m_strCOUNTRY);
  //## end segment::ContactSegment::setColumns%5AB2A9480393.body
}

void ContactSegment::setFields ()
{
  //## begin segment::ContactSegment::setFields%5AB2A9480397.body preserve=yes
   m_lNumberOfFields = FIELDS;
   setSize((int)sizeof(segContactSegment));
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strADDRESS_LINE_1;
   m_pField[1] = &m_strADDRESS_LINE_2;
   m_pField[2] = &m_strADDRESS_LINE_3;
   m_pField[3] = &m_strADDRESS_LINE_4;
   m_pField[4] = &m_lCONTACT_ID;
   m_pField[5] = &m_strCONTACT_METHOD;
   m_pField[6] = &m_strCONTACT_TYPE;
   m_pField[7] = &m_strEMAIL_ADDRESS;
   m_pField[8] = &m_strFAX_NO;
   m_pField[9] = &m_strINST_ID;
   m_pField[10] = &m_strNAME;
   m_pField[11] = &m_strPROC_GRP_ID;
   m_pField[12] = &m_strPROC_ID;
   m_pField[13] = &m_strTELEPHONE_NO;
   m_pField[14] = &m_strTSTAMP_UPDATED;
   m_pField[15] = &m_strUSER_ID;
   m_pField[16] = &m_lCOURIER_PTR;
   m_pField[17] = &m_lCOURIER_ROUTE_PTR;
   m_pField[18] = &m_strUPDATED_BY_USER_ID;
   m_pField[19] = &m_strBIN;
   m_pField[20] = &m_strDEVICE_ID;
   m_pField[21] = &m_strContactInstID;
   m_pField[22] = &m_strContactProcID;
   m_pField[23] = &m_strORG_NAME;
   m_pField[24] = &m_strCITY;
   m_pField[25] = &m_strREGION;
   m_pField[26] = &m_strPOSTAL_CODE;
   m_pField[27] = &m_strCOUNTRY;
   m_pField[28] = &m_strRPT_LVL_ID_OBSOLETE;
   m_pField[29] = &m_strOrigin;
   m_pField[30] = &m_strRPT_LVL_ID;
  //## end segment::ContactSegment::setFields%5AB2A9480397.body
}

// Additional Declarations
  //## begin segment::ContactSegment%5AB2A71701C4.declarations preserve=yes
  //## end segment::ContactSegment%5AB2A71701C4.declarations

} // namespace segment

//## begin module%5AB2A7DA01D2.epilog preserve=yes
//## end module%5AB2A7DA01D2.epilog
