//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%37728D58010B.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%37728D58010B.cm

//## begin module%37728D58010B.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%37728D58010B.cp

//## Module: CXOSBS05%37728D58010B; Package body
//## Subsystem: BSDLL%394E1F8C0345
//## Source file: C:\Pvcswork\Dn\Server\Library\Bsdll\CXOSBS05.cpp

//## begin module%37728D58010B.additionalIncludes preserve=no
//## end module%37728D58010B.additionalIncludes

//## begin module%37728D58010B.includes preserve=yes
// $Date:   Jan 02 2019 21:16:10  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%37728D58010B.includes

#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBS05_h
#include "CXODBS05.hpp"
#endif


//## begin module%37728D58010B.declarations preserve=no
//## end module%37728D58010B.declarations

//## begin module%37728D58010B.additionalDeclarations preserve=yes
//## end module%37728D58010B.additionalDeclarations


//## Modelname: Connex Foundation::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::Response





Response::Response()
  //## begin Response::Response%37728C1802AF_const.hasinit preserve=no
  //## end Response::Response%37728C1802AF_const.hasinit
  //## begin Response::Response%37728C1802AF_const.initialization preserve=yes
  //## end Response::Response%37728C1802AF_const.initialization
{
  //## begin segment::Response::Response%37728C1802AF_const.body preserve=yes
   memcpy(m_sID,"BS05",4);
  //## end segment::Response::Response%37728C1802AF_const.body
}


Response::~Response()
{
  //## begin segment::Response::~Response%37728C1802AF_dest.body preserve=yes
  //## end segment::Response::~Response%37728C1802AF_dest.body
}



//## Other Operations (implementation)
void Response::addSegment (Segment* pSegment)
{
  //## begin segment::Response::addSegment%37728CC902DC.body preserve=yes
   m_hSegment.push_back(pSegment);
  //## end segment::Response::addSegment%37728CC902DC.body
}

int Response::parse (const char* psBuffer, int lBuffer)
{
  //## begin segment::Response::parse%37728CEC0250.body preserve=yes
   // reset all segments
   vector<Segment*>::iterator ppSegment;
   for (ppSegment = m_hSegment.begin();ppSegment != m_hSegment.end();++ppSegment)
   {
      (*ppSegment)->reset();
   }
   // validate the common header segment
   char pszSegmentID[5] = {"    "};
   // evil cast !!!
   char* pSegmentID = (char*)psBuffer /*+ 8 !!!*/;
   // parse the segments
   char* pEndOfMessage = pSegmentID + lBuffer;
   int iRC = 0;
   while ((pSegmentID < pEndOfMessage) && (iRC == 0))
   {
      // assume invalid segment ID
      iRC = STS_INVALID_SEGMENT_ID;
      memcpy(pszSegmentID,pSegmentID,4);
      for (ppSegment = m_hSegment.begin();ppSegment != m_hSegment.end();++ppSegment)
      {
         if ( ((*ppSegment)->segmentID() == (const char*)pszSegmentID) &&
              ((*ppSegment)->presence() == false)  )
         {
            iRC = (*ppSegment)->import(&pSegmentID);
            break;
         }
      }
   }
   if (iRC != 0)
   {
      m_strError = "Parse error";
      return -1;
   }
   return 0;
  //## end segment::Response::parse%37728CEC0250.body
}

// Additional Declarations
  //## begin segment::Response%37728C1802AF.declarations preserve=yes
  //## end segment::Response%37728C1802AF.declarations

} // namespace segment

//## begin module%37728D58010B.epilog preserve=yes
//## end module%37728D58010B.epilog
