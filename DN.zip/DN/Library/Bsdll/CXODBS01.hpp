//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35A3DE9002FB.cm preserve=no
//	$Date:   Feb 06 2020 13:16:22  $ $Author:   e1009839  $
//	$Revision:   1.37  $
//## end module%35A3DE9002FB.cm

//## begin module%35A3DE9002FB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%35A3DE9002FB.cp

//## Module: CXOSBS01%35A3DE9002FB; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS01.hpp

#ifndef CXOSBS01_h
#define CXOSBS01_h 1

//## begin module%35A3DE9002FB.additionalIncludes preserve=no
//## end module%35A3DE9002FB.additionalIncludes

//## begin module%35A3DE9002FB.includes preserve=yes
#include <stddef.h>
#include <vector>
#include <map>
//## end module%35A3DE9002FB.includes

#ifndef CXOSRU03_h
#include "CXODRU03.hpp"
#endif
#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSBS03_h
#include "CXODBS03.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class NPI;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class CurrencyCode;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;
class CommonHeaderSegment;
} // namespace segment

//## Modelname: Connex Library::Rules_CAT (RLDLL)%3EB810F40157
namespace rules {
class RulesEngine;
class RuleVariableExpression;

} // namespace rules

//## begin module%35A3DE9002FB.declarations preserve=no
//## end module%35A3DE9002FB.declarations

//## begin module%35A3DE9002FB.additionalDeclarations preserve=yes
//## end module%35A3DE9002FB.additionalDeclarations


namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::Segment%3453FD3F025A.preface preserve=yes
struct Fields
{
   const char* pszAttributes;
   const char* pszName;
   short siOffset;
   short siLength;
};
//## end segment::Segment%3453FD3F025A.preface

//## Class: Segment%3453FD3F025A
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39227EF8011B;CommonHeaderSegment { -> F}
//## Uses: <unnamed>%3BFE9919032C;InformationSegment { -> F}
//## Uses: <unnamed>%3CF8C6230389;database::CRTransactionTypeIndicator { -> F}
//## Uses: <unnamed>%41CAF2770232;database::CurrencyCode { -> F}
//## Uses: <unnamed>%42C0642D0271;rules::RulesEngine { -> F}
//## Uses: <unnamed>%42C140EB031C;rules::RuleVariableExpression { -> F}
//## Uses: <unnamed>%42C146A602AF;reusable::CXString { -> }
//## Uses: <unnamed>%5457BA770109;reusable::NPI { -> F}

class DllExport Segment : public reusable::Object  //## Inherits: <unnamed>%34EDFA05033C
{
  //## begin segment::Segment%3453FD3F025A.initialDeclarations preserve=yes
  //## end segment::Segment%3453FD3F025A.initialDeclarations

  public:
    //## Constructors (generated)
      Segment();

      Segment(const Segment &right);

    //## Constructors (specified)
      //## Operation: Segment%371F8EE803E4
      Segment (const char* pszSegmentID);

    //## Destructor (generated)
      virtual ~Segment();

    //## Assignment Operation (generated)
      Segment & operator=(const Segment &right);


    //## Other Operations (specified)
      //## Operation: addCurrencyCode%41EBB029001F
      void addCurrencyCode (const char* pszMonetaryAmount, const char* pszCurrencyCode);

      //## Operation: addVariableExpression%42C063F202BF
      void addVariableExpression (const string& strTableName);

      //## Operation: _address%3EC0F3CA0203
      bool _address (const char* pszName, void** ppsAddress, const char** ppszMetadata, bool bLoadField = false) const;

      //## Operation: atof%3BB894A202DE
      static double atof (const char *psText, unsigned iTextLength)
      {
        //## begin segment::Segment::atof%3BB894A202DE.body preserve=yes
         if (iTextLength >= 32)
            return 0;
         char m_szText[32];
         memcpy(m_szText,psText,iTextLength);
         m_szText[iTextLength] = '\0';
         return ::atof(m_szText);
        //## end segment::Segment::atof%3BB894A202DE.body
      }

      //## Operation: atoi%3BB895C70399
      static short atoi (const char *psText, unsigned iTextLength)
      {
        //## begin segment::Segment::atoi%3BB895C70399.body preserve=yes
         if (iTextLength >= 32)
            return 0;
         char m_szText[32];
         memcpy(m_szText,psText,iTextLength);
         m_szText[iTextLength] = '\0';
         return (short)::atoi(m_szText);
        //## end segment::Segment::atoi%3BB895C70399.body
      }

      //## Operation: atol%3BB896010203
      static int atol (const char *psText, unsigned iTextLength)
      {
        //## begin segment::Segment::atol%3BB896010203.body preserve=yes
         if (iTextLength >= 32)
            return 0;
         char m_szText[32];
         memcpy(m_szText,psText,iTextLength);
         m_szText[iTextLength] = '\0';
         return ::atoi(m_szText);
        //## end segment::Segment::atol%3BB896010203.body
      }

      //## Operation: checkPresence%564C5A27015E
      virtual bool checkPresence ();

      //## Operation: clear%39897CDF01B6
      virtual void clear ();

      //## Operation: copySegment%4E80E570016F
      void copySegment (Segment& hSegment);

      //## Operation: deport%3454C3C70367
      virtual int deport (char** ppsBuffer);

      //## Operation: exportFields%457024E502CE
      virtual void exportFields (char* psBuffer, int& nLengthOfSegment);

      //## Operation: _field%3720BB7603DB
      bool _field (const char* pszName, CXString& hValue, bool bDescription = false, bool bFormat = true) const;

      //## Operation: _field%4B731F4A0222
      virtual bool _field (const char* pszName, string& strValue, bool bDescription = false, bool bFormat = true) const;

      //## Operation: field%3718A91A00C2
      void* field (int nField) const
      {
        //## begin segment::Segment::field%3718A91A00C2.body preserve=yes
         return m_pField[nField];
        //## end segment::Segment::field%3718A91A00C2.body
      }

      //## Operation: fields%3720BBEB03B1
      virtual struct  Fields* fields () const
      {
        //## begin segment::Segment::fields%3720BBEB03B1.body preserve=yes
         return 0;
        //## end segment::Segment::fields%3720BBEB03B1.body
      }

      //## Operation: _fillField%56A783AF01A1
      virtual bool _fillField (const char* pszName, const string& hValue);

      //## Operation: _fillField%3E8D9B400109
      virtual bool _fillField (const char* pszName, const string& hValue, bool& bSizeOverrun);

      //## Operation: getField%3EC5040D01E4
      bool getField (const char* pszName, string& strValue, bool bDescription = false, bool bFormat = true) const;

      //## Operation: getFieldByIndex%4E7CC07401CC
      virtual bool getFieldByIndex (int iIndex, string& hValue);

      //## Operation: getFieldIndex%4D3DF3D30358
      virtual bool getFieldIndex (const char* pszName, int& iIndex) const;

      //## Operation: import%3454C3C001C3
      virtual int import (char** ppsBuffer);

      //## Operation: importFields%456F8B12035B
      void importFields (const char* psBuffer, int nLengthOfSegment);

      //## Operation: lltof%3720BCE3023B
      static double lltof (int lValue1, int lValue2);

      //## Operation: loadField%3C07EEB300AB
      virtual void* loadField (int nField) const
      {
        //## begin segment::Segment::loadField%3C07EEB300AB.body preserve=yes
         return 0;
        //## end segment::Segment::loadField%3C07EEB300AB.body
      }

      //## Operation: merge%4B035BF801F4
      void merge (const Segment& hSegment);

      //## Operation: offset%38219F0B01CE
      bool offset (const char* pszName, short& siOffset, short& siLength);

      //## Operation: persistent%3737283F0161
      virtual bool persistent ()
      {
        //## begin segment::Segment::persistent%3737283F0161.body preserve=yes
         return false;
        //## end segment::Segment::persistent%3737283F0161.body
      }

      //## Operation: read%3720BC1E021A
      virtual int read (char** ppsBuffer);

      //## Operation: replicate%457D8F990399
      virtual void replicate ();

      //## Operation: reset%3718A95B036E
      virtual void reset ()
      {
        //## begin segment::Segment::reset%3718A95B036E.body preserve=yes
         setPresence(false);
        //## end segment::Segment::reset%3718A95B036E.body
      }

      //## Operation: segmentVersion%38330C680398
      virtual char* segmentVersion ()
      {
        //## begin segment::Segment::segmentVersion%38330C680398.body preserve=yes
         return "0100";
        //## end segment::Segment::segmentVersion%38330C680398.body
      }

      //## Operation: setField%38283EDA0393
      virtual bool setField (const char* pszName, const string& hValue) const;

      //## Operation: setFieldByIndex%4D3DF41501C4
      virtual bool setFieldByIndex (int iIndex, const string& hValue);

      //## Operation: write%371F8F320001
      virtual int write (char** ppsBuffer);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: NumberOfFields%392FAEB6030A
      const int getNumberOfFields () const
      {
        //## begin segment::Segment::getNumberOfFields%392FAEB6030A.get preserve=no
        return m_lNumberOfFields;
        //## end segment::Segment::getNumberOfFields%392FAEB6030A.get
      }


      //## Attribute: Presence%35A638290394
      const bool presence () const
      {
        //## begin segment::Segment::presence%35A638290394.get preserve=no
        return m_bPresence;
        //## end segment::Segment::presence%35A638290394.get
      }

      void setPresence (bool value)
      {
        //## begin segment::Segment::setPresence%35A638290394.set preserve=no
        m_bPresence = value;
        //## end segment::Segment::setPresence%35A638290394.set
      }


      //## Attribute: SegmentID%35A6381B0019
      const reusable::CXString& segmentID () const
      {
        //## begin segment::Segment::segmentID%35A6381B0019.get preserve=no
        return m_strSegmentID;
        //## end segment::Segment::segmentID%35A6381B0019.get
      }

      void setSegmentID (const reusable::CXString& value)
      {
        //## begin segment::Segment::setSegmentID%35A6381B0019.set preserve=no
        m_strSegmentID = value;
        //## end segment::Segment::setSegmentID%35A6381B0019.set
      }


      //## Attribute: Size%39B7AC4203BE
      const int& getSize () const
      {
        //## begin segment::Segment::getSize%39B7AC4203BE.get preserve=no
        return m_lSize;
        //## end segment::Segment::getSize%39B7AC4203BE.get
      }

      void setSize (const int& value)
      {
        //## begin segment::Segment::setSize%39B7AC4203BE.set preserve=no
        m_lSize = value;
        //## end segment::Segment::setSize%39B7AC4203BE.set
      }


    // Data Members for Class Attributes

      //## begin segment::Segment::Size%39B7AC4203BE.attr preserve=no  public: int {UA} 0
      int m_lSize;
      //## end segment::Segment::Size%39B7AC4203BE.attr

      //## Attribute: Version%379F0D6F002F
      //## begin segment::Segment::Version%379F0D6F002F.attr preserve=no  public: reusable::string {VA} "0100"
      reusable::string m_strVersion;
      //## end segment::Segment::Version%379F0D6F002F.attr

    // Additional Public Declarations
      //## begin segment::Segment%3453FD3F025A.public preserve=yes
      void wipe(const char* pszName);
      //## end segment::Segment%3453FD3F025A.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Buffer%39BA976D0100
      //## begin segment::Segment::Buffer%39BA976D0100.attr preserve=no  public: static char* {V} 0
      static char* m_pszBuffer;
      //## end segment::Segment::Buffer%39BA976D0100.attr

      //## Attribute: CurrencyCode%41BF56CC00CB
      //## begin segment::Segment::CurrencyCode%41BF56CC00CB.attr preserve=no  protected: map<string,string,less<string> > {RA} 0
      map<string,string,less<string> > *m_pCurrencyCode;
      //## end segment::Segment::CurrencyCode%41BF56CC00CB.attr

      //## Attribute: Field%392FA76002EB
      //## begin segment::Segment::Field%392FA76002EB.attr preserve=no  protected: void** {VA} 0
      void** m_pField;
      //## end segment::Segment::Field%392FA76002EB.attr

      //## begin segment::Segment::NumberOfFields%392FAEB6030A.attr preserve=no  public: int {V} 0
      int m_lNumberOfFields;
      //## end segment::Segment::NumberOfFields%392FAEB6030A.attr

    // Data Members for Associations

      //## Association: Connex Library::Segment_CAT::<unnamed>%392993FA0119
      //## Role: Segment::<m_hSegmentVersion>%392993FA0368
      //## begin segment::Segment::<m_hSegmentVersion>%392993FA0368.role preserve=no  protected: segment::SegmentVersion {1 -> 0..nVHgN}
      vector<SegmentVersion> m_hSegmentVersion;
      //## end segment::Segment::<m_hSegmentVersion>%392993FA0368.role

    // Additional Protected Declarations
      //## begin segment::Segment%3453FD3F025A.protected preserve=yes
      //## end segment::Segment%3453FD3F025A.protected

  private:
    // Additional Private Declarations
      //## begin segment::Segment%3453FD3F025A.private preserve=yes
      //## end segment::Segment%3453FD3F025A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin segment::Segment::Presence%35A638290394.attr preserve=no  public: bool {V} false
      bool m_bPresence;
      //## end segment::Segment::Presence%35A638290394.attr

      //## begin segment::Segment::SegmentID%35A6381B0019.attr preserve=no  public: reusable::CXString {V} 
      reusable::CXString m_strSegmentID;
      //## end segment::Segment::SegmentID%35A6381B0019.attr

    // Additional Implementation Declarations
      //## begin segment::Segment%3453FD3F025A.implementation preserve=yes
      //## end segment::Segment%3453FD3F025A.implementation

};

//## begin segment::Segment%3453FD3F025A.postscript preserve=yes
//## end segment::Segment%3453FD3F025A.postscript

} // namespace segment

//## begin module%35A3DE9002FB.epilog preserve=yes
using namespace segment;
//## end module%35A3DE9002FB.epilog


#endif
