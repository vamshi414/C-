//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%44448CFD015F.cm preserve=no
//	$Date:   Oct 30 2007 09:42:22  $ $Author:   D02405  $
//	$Revision:   1.2  $
//## end module%44448CFD015F.cm

//## begin module%44448CFD015F.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%44448CFD015F.cp

//## Module: CXOSBS24%44448CFD015F; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bsdll\CXODBS24.hpp

#ifndef CXOSBS24_h
#define CXOSBS24_h 1

//## begin module%44448CFD015F.additionalIncludes preserve=no
//## end module%44448CFD015F.additionalIncludes

//## begin module%44448CFD015F.includes preserve=yes
//## end module%44448CFD015F.includes

#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif
//## begin module%44448CFD015F.declarations preserve=no
//## end module%44448CFD015F.declarations

//## begin module%44448CFD015F.additionalDeclarations preserve=yes
//## end module%44448CFD015F.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::ImportReportAuditSegment%44448BD602FD.preface preserve=yes
//## end segment::ImportReportAuditSegment%44448BD602FD.preface

//## Class: ImportReportAuditSegment%44448BD602FD
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport ImportReportAuditSegment : public PersistentSegment  //## Inherits: <unnamed>%44448C41037D
{
  //## begin segment::ImportReportAuditSegment%44448BD602FD.initialDeclarations preserve=yes
  //## end segment::ImportReportAuditSegment%44448BD602FD.initialDeclarations

  public:
    //## Constructors (generated)
      ImportReportAuditSegment();

    //## Destructor (generated)
      virtual ~ImportReportAuditSegment();


    //## Other Operations (specified)
      //## Operation: fields%4444AC7C026E
      struct Fields* fields () const;

      //## Operation: instance%4720886E029F
      static ImportReportAuditSegment* instance ();

      //## Operation: setCount%47224E210000
      void setCount (int iCount, int iIndex = 0);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: DATE_RECON%472341690167
      const string& getDATE_RECON () const
      {
        //## begin segment::ImportReportAuditSegment::getDATE_RECON%472341690167.get preserve=no
        return m_strDATE_RECON;
        //## end segment::ImportReportAuditSegment::getDATE_RECON%472341690167.get
      }

      void setDATE_RECON (const string& value)
      {
        //## begin segment::ImportReportAuditSegment::setDATE_RECON%472341690167.set preserve=no
        m_strDATE_RECON = value;
        //## end segment::ImportReportAuditSegment::setDATE_RECON%472341690167.set
      }


      //## Attribute: DI_FILE_ID%472341A5004E
      const int getDI_FILE_ID () const
      {
        //## begin segment::ImportReportAuditSegment::getDI_FILE_ID%472341A5004E.get preserve=no
        return m_iDI_FILE_ID;
        //## end segment::ImportReportAuditSegment::getDI_FILE_ID%472341A5004E.get
      }

      void setDI_FILE_ID (int value)
      {
        //## begin segment::ImportReportAuditSegment::setDI_FILE_ID%472341A5004E.set preserve=no
        m_iDI_FILE_ID = value;
        //## end segment::ImportReportAuditSegment::setDI_FILE_ID%472341A5004E.set
      }


      //## Attribute: FILE%4444ABA60097
      const string& getFILE () const
      {
        //## begin segment::ImportReportAuditSegment::getFILE%4444ABA60097.get preserve=no
        return m_strFILE;
        //## end segment::ImportReportAuditSegment::getFILE%4444ABA60097.get
      }

      void setFILE (const string& value)
      {
        //## begin segment::ImportReportAuditSegment::setFILE%4444ABA60097.set preserve=no
        m_strFILE = value;
        //## end segment::ImportReportAuditSegment::setFILE%4444ABA60097.set
      }


      //## Attribute: IMPORT_KEY%472088D9037A
      const string& getIMPORT_KEY () const
      {
        //## begin segment::ImportReportAuditSegment::getIMPORT_KEY%472088D9037A.get preserve=no
        return m_strIMPORT_KEY;
        //## end segment::ImportReportAuditSegment::getIMPORT_KEY%472088D9037A.get
      }

      void setIMPORT_KEY (const string& value)
      {
        //## begin segment::ImportReportAuditSegment::setIMPORT_KEY%472088D9037A.set preserve=no
        m_strIMPORT_KEY = value;
        //## end segment::ImportReportAuditSegment::setIMPORT_KEY%472088D9037A.set
      }


      //## Attribute: Pass%47224DF902CE
      const int getPass () const
      {
        //## begin segment::ImportReportAuditSegment::getPass%47224DF902CE.get preserve=no
        return m_iPass;
        //## end segment::ImportReportAuditSegment::getPass%47224DF902CE.get
      }

      void setPass (int value)
      {
        //## begin segment::ImportReportAuditSegment::setPass%47224DF902CE.set preserve=no
        m_iPass = value;
        //## end segment::ImportReportAuditSegment::setPass%47224DF902CE.set
      }


      //## Attribute: PATH%4444ABC0026C
      const string& getPATH () const
      {
        //## begin segment::ImportReportAuditSegment::getPATH%4444ABC0026C.get preserve=no
        return m_strPATH;
        //## end segment::ImportReportAuditSegment::getPATH%4444ABC0026C.get
      }

      void setPATH (const string& value)
      {
        //## begin segment::ImportReportAuditSegment::setPATH%4444ABC0026C.set preserve=no
        m_strPATH = value;
        //## end segment::ImportReportAuditSegment::setPATH%4444ABC0026C.set
      }


      //## Attribute: REJECT_CODES%4444AB5A019F
      const string& getREJECT_CODES () const
      {
        //## begin segment::ImportReportAuditSegment::getREJECT_CODES%4444AB5A019F.get preserve=no
        return m_strREJECT_CODES;
        //## end segment::ImportReportAuditSegment::getREJECT_CODES%4444AB5A019F.get
      }

      void setREJECT_CODES (const string& value)
      {
        //## begin segment::ImportReportAuditSegment::setREJECT_CODES%4444AB5A019F.set preserve=no
        m_strREJECT_CODES = value;
        //## end segment::ImportReportAuditSegment::setREJECT_CODES%4444AB5A019F.set
      }


      //## Attribute: SEQ_NO%472088BF0186
      const short getSEQ_NO () const
      {
        //## begin segment::ImportReportAuditSegment::getSEQ_NO%472088BF0186.get preserve=no
        return m_siSEQ_NO;
        //## end segment::ImportReportAuditSegment::getSEQ_NO%472088BF0186.get
      }

      void setSEQ_NO (short value)
      {
        //## begin segment::ImportReportAuditSegment::setSEQ_NO%472088BF0186.set preserve=no
        m_siSEQ_NO = value;
        //## end segment::ImportReportAuditSegment::setSEQ_NO%472088BF0186.set
      }


      //## Attribute: Server%47231EA9000F
      const string& getServer () const
      {
        //## begin segment::ImportReportAuditSegment::getServer%47231EA9000F.get preserve=no
        return m_strServer;
        //## end segment::ImportReportAuditSegment::getServer%47231EA9000F.get
      }

      void setServer (const string& value)
      {
        //## begin segment::ImportReportAuditSegment::setServer%47231EA9000F.set preserve=no
        m_strServer = value;
        //## end segment::ImportReportAuditSegment::setServer%47231EA9000F.set
      }


      //## Attribute: TIMESTAMP%4444ABD900F5
      const string& getTIMESTAMP () const
      {
        //## begin segment::ImportReportAuditSegment::getTIMESTAMP%4444ABD900F5.get preserve=no
        return m_strTIMESTAMP;
        //## end segment::ImportReportAuditSegment::getTIMESTAMP%4444ABD900F5.get
      }

      void setTIMESTAMP (const string& value)
      {
        //## begin segment::ImportReportAuditSegment::setTIMESTAMP%4444ABD900F5.set preserve=no
        m_strTIMESTAMP = value;
        //## end segment::ImportReportAuditSegment::setTIMESTAMP%4444ABD900F5.set
      }


      //## Attribute: TRANSACTION_NO%472088A1007D
      const int getTRANSACTION_NO () const
      {
        //## begin segment::ImportReportAuditSegment::getTRANSACTION_NO%472088A1007D.get preserve=no
        return m_iTRANSACTION_NO;
        //## end segment::ImportReportAuditSegment::getTRANSACTION_NO%472088A1007D.get
      }

      void setTRANSACTION_NO (int value)
      {
        //## begin segment::ImportReportAuditSegment::setTRANSACTION_NO%472088A1007D.set preserve=no
        m_iTRANSACTION_NO = value;
        //## end segment::ImportReportAuditSegment::setTRANSACTION_NO%472088A1007D.set
      }


      //## Attribute: TSTAMP_INITIATED%47234181002E
      const string& getTSTAMP_INITIATED () const
      {
        //## begin segment::ImportReportAuditSegment::getTSTAMP_INITIATED%47234181002E.get preserve=no
        return m_strTSTAMP_INITIATED;
        //## end segment::ImportReportAuditSegment::getTSTAMP_INITIATED%47234181002E.get
      }

      void setTSTAMP_INITIATED (const string& value)
      {
        //## begin segment::ImportReportAuditSegment::setTSTAMP_INITIATED%47234181002E.set preserve=no
        m_strTSTAMP_INITIATED = value;
        //## end segment::ImportReportAuditSegment::setTSTAMP_INITIATED%47234181002E.set
      }


    // Additional Public Declarations
      //## begin segment::ImportReportAuditSegment%44448BD602FD.public preserve=yes
      //## end segment::ImportReportAuditSegment%44448BD602FD.public

  protected:
    // Additional Protected Declarations
      //## begin segment::ImportReportAuditSegment%44448BD602FD.protected preserve=yes
      //## end segment::ImportReportAuditSegment%44448BD602FD.protected

  private:
    // Additional Private Declarations
      //## begin segment::ImportReportAuditSegment%44448BD602FD.private preserve=yes
      //## end segment::ImportReportAuditSegment%44448BD602FD.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Count%4444ABED01B1
      //## begin segment::ImportReportAuditSegment::Count%4444ABED01B1.attr preserve=no  public: int[3] {V} 
      int m_iCount[3];
      //## end segment::ImportReportAuditSegment::Count%4444ABED01B1.attr

      //## begin segment::ImportReportAuditSegment::DATE_RECON%472341690167.attr preserve=no  public: string {V} 
      string m_strDATE_RECON;
      //## end segment::ImportReportAuditSegment::DATE_RECON%472341690167.attr

      //## begin segment::ImportReportAuditSegment::DI_FILE_ID%472341A5004E.attr preserve=no  public: int {V} 0
      int m_iDI_FILE_ID;
      //## end segment::ImportReportAuditSegment::DI_FILE_ID%472341A5004E.attr

      //## begin segment::ImportReportAuditSegment::FILE%4444ABA60097.attr preserve=no  public: string {V} 
      string m_strFILE;
      //## end segment::ImportReportAuditSegment::FILE%4444ABA60097.attr

      //## begin segment::ImportReportAuditSegment::IMPORT_KEY%472088D9037A.attr preserve=no  public: string {V} 
      string m_strIMPORT_KEY;
      //## end segment::ImportReportAuditSegment::IMPORT_KEY%472088D9037A.attr

      //## Attribute: Instance%4720883B0232
      //## begin segment::ImportReportAuditSegment::Instance%4720883B0232.attr preserve=no  private: static ImportReportAuditSegment* {V} 0
      static ImportReportAuditSegment* m_pInstance;
      //## end segment::ImportReportAuditSegment::Instance%4720883B0232.attr

      //## begin segment::ImportReportAuditSegment::Pass%47224DF902CE.attr preserve=no  public: int {V} 0
      int m_iPass;
      //## end segment::ImportReportAuditSegment::Pass%47224DF902CE.attr

      //## begin segment::ImportReportAuditSegment::PATH%4444ABC0026C.attr preserve=no  public: string {V} 
      string m_strPATH;
      //## end segment::ImportReportAuditSegment::PATH%4444ABC0026C.attr

      //## begin segment::ImportReportAuditSegment::REJECT_CODES%4444AB5A019F.attr preserve=no  public: string {U} 
      string m_strREJECT_CODES;
      //## end segment::ImportReportAuditSegment::REJECT_CODES%4444AB5A019F.attr

      //## begin segment::ImportReportAuditSegment::SEQ_NO%472088BF0186.attr preserve=no  public: short {V} 0
      short m_siSEQ_NO;
      //## end segment::ImportReportAuditSegment::SEQ_NO%472088BF0186.attr

      //## begin segment::ImportReportAuditSegment::Server%47231EA9000F.attr preserve=no  public: string {V} 
      string m_strServer;
      //## end segment::ImportReportAuditSegment::Server%47231EA9000F.attr

      //## begin segment::ImportReportAuditSegment::TIMESTAMP%4444ABD900F5.attr preserve=no  public: string {V} 
      string m_strTIMESTAMP;
      //## end segment::ImportReportAuditSegment::TIMESTAMP%4444ABD900F5.attr

      //## begin segment::ImportReportAuditSegment::TRANSACTION_NO%472088A1007D.attr preserve=no  public: int {V} 0
      int m_iTRANSACTION_NO;
      //## end segment::ImportReportAuditSegment::TRANSACTION_NO%472088A1007D.attr

      //## begin segment::ImportReportAuditSegment::TSTAMP_INITIATED%47234181002E.attr preserve=no  public: string {V} 
      string m_strTSTAMP_INITIATED;
      //## end segment::ImportReportAuditSegment::TSTAMP_INITIATED%47234181002E.attr

    // Additional Implementation Declarations
      //## begin segment::ImportReportAuditSegment%44448BD602FD.implementation preserve=yes
      //## end segment::ImportReportAuditSegment%44448BD602FD.implementation

};

//## begin segment::ImportReportAuditSegment%44448BD602FD.postscript preserve=yes
//## end segment::ImportReportAuditSegment%44448BD602FD.postscript

} // namespace segment

//## begin module%44448CFD015F.epilog preserve=yes
//## end module%44448CFD015F.epilog


#endif
