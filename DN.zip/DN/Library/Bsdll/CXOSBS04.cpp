//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3651911103BB.cm preserve=no
//	$Date:   May 14 2020 17:56:10  $ $Author:   e1009510  $
//	$Revision:   1.19  $
//## end module%3651911103BB.cm

//## begin module%3651911103BB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3651911103BB.cp

//## Module: CXOSBS04%3651911103BB; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.5B.R003\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXOSBS04.cpp

//## begin module%3651911103BB.additionalIncludes preserve=no
//## end module%3651911103BB.additionalIncludes

//## begin module%3651911103BB.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%3651911103BB.includes

#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSRU03_h
#include "CXODRU03.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSBS04_h
#include "CXODBS04.hpp"
#endif


//## begin module%3651911103BB.declarations preserve=no
//## end module%3651911103BB.declarations

//## begin module%3651911103BB.additionalDeclarations preserve=yes
//## end module%3651911103BB.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::Command 

Command::Command()
  //## begin Command::Command%3454E2FA011D_const.hasinit preserve=no
      : m_nTransaction(-1),
        m_bUpdate(false),
        m_lInfoIDNumber(0)
  //## end Command::Command%3454E2FA011D_const.hasinit
  //## begin Command::Command%3454E2FA011D_const.initialization preserve=yes
  //## end Command::Command%3454E2FA011D_const.initialization
{
  //## begin segment::Command::Command%3454E2FA011D_const.body preserve=yes
  //## end segment::Command::Command%3454E2FA011D_const.body
}

Command::Command (const char* pszMessageID)
  //## begin segment::Command::Command%3472F1F50313.hasinit preserve=no
      : m_nTransaction(-1),
        m_bUpdate(false),
        m_lInfoIDNumber(0)
  //## end segment::Command::Command%3472F1F50313.hasinit
  //## begin segment::Command::Command%3472F1F50313.initialization preserve=yes
  //## end segment::Command::Command%3472F1F50313.initialization
{
  //## begin segment::Command::Command%3472F1F50313.body preserve=yes
  //## end segment::Command::Command%3472F1F50313.body
}


Command::~Command()
{
  //## begin segment::Command::~Command%3454E2FA011D_dest.body preserve=yes
  //## end segment::Command::~Command%3454E2FA011D_dest.body
}



//## Other Operations (implementation)
int Command::deport (char** ppsBuffer)
{
  //## begin segment::Command::deport%346CBC560271.body preserve=yes
   vector<Segment*>::iterator ppSegment;
   for (ppSegment = m_hSegments.begin();ppSegment != m_hSegments.end();++ppSegment)
   {
      if ((*ppSegment)->presence())
         (*ppSegment)->deport(ppsBuffer);
   }
   return 0;
  //## end segment::Command::deport%346CBC560271.body
}

int Command::forward (const char* pszQueue) const
{
  //## begin segment::Command::forward%346CBC7E00C0.body preserve=yes
   return 0;
  //## end segment::Command::forward%346CBC7E00C0.body
}

bool Command::import (char* psBuffer, int iBuffer)
{
  //## begin segment::Command::import%34609E7002A8.body preserve=yes
   vector<Segment*>::iterator ppSegment;
   for (ppSegment = m_hSegments.begin();ppSegment != m_hSegments.end();++ppSegment)
      (*ppSegment)->reset();
   char szSegmentID[5] = {"****"};
   bool bFound = true;
   while (bFound)
   {
      bFound = false;
      memcpy (szSegmentID,psBuffer,4);
      psBuffer += 4;
      if (memcmp(szSegmentID,"Z999",4) == 0)
         break;
      for (ppSegment = m_hSegments.begin();ppSegment != m_hSegments.end();++ppSegment)
      {
         if (((*ppSegment)->segmentID() == (const char*)szSegmentID)
            && (!(*ppSegment)->presence()))
         {
            (*ppSegment)->read(&psBuffer);
            bFound = true;
            break;
         }
      }
   }
   return (memcmp(szSegmentID,"Z999",4) == 0);
  //## end segment::Command::import%34609E7002A8.body
}

void Command::log (const char* pszReason, const char* pszMessageID) const
{
  //## begin segment::Command::log%34733EBF00FD.body preserve=yes
   Message::instance(Message::OUTBOUND)->reset("STSLOG",m_strMessageID.c_str());
   char* psBuffer = Message::instance(Message::OUTBOUND)->data();
   vector<Segment*>::const_iterator ppSegment;
   for (ppSegment = m_hSegments.begin();ppSegment != m_hSegments.end();++ppSegment)
   {
      if ((*ppSegment)->presence())
         (*ppSegment)->write(&psBuffer);
   }
   Message::instance(Message::OUTBOUND)->setDataLength(psBuffer - Message::instance(Message::OUTBOUND)->data());
   if (pszMessageID)
      Log::put(Message::instance(Message::OUTBOUND)->buffer(),
         Message::instance(Message::OUTBOUND)->messageLength(),
         pszMessageID,pszReason);
   else
      Log::put(Message::instance(Message::OUTBOUND)->buffer(),
         Message::instance(Message::OUTBOUND)->messageLength(),
         m_strMessageID.c_str(),pszReason);
  //## end segment::Command::log%34733EBF00FD.body
}

int Command::parse ()
{
  //## begin segment::Command::parse%3499BD8301A0.body preserve=yes
   char szLength[PERCENTD];
   snprintf(szLength,PERCENTD,"%08d",Message::instance(Message::INBOUND)->dataLength());
   if (strncmp(Message::instance(Message::INBOUND)->data(),szLength,8))
   {
      m_strError = "Invalid message length";
      return STS_INVALID_LENGTH;
   }
   vector<Segment*>::iterator ppSegment;
   for (ppSegment = m_hSegments.begin();ppSegment != m_hSegments.end(); ++ppSegment)
      (*ppSegment)->reset();
   char pszSegmentID[5] = {"    "};
   char* pSegmentID = Message::instance(Message::INBOUND)->data() + 8;
   // parse the segments
   char* pEndOfMessage = Message::instance(Message::INBOUND)->data() + Message::instance(Message::INBOUND)->dataLength();
   int iRC = 0;
   while ((pSegmentID < pEndOfMessage) && (iRC == 0))
   {
      // assume invalid segment ID
      iRC = STS_INVALID_SEGMENT_ID;
      memcpy_s(pszSegmentID,4,pSegmentID,4);
      for (ppSegment = m_hSegments.begin();ppSegment != m_hSegments.end();++ppSegment)
      {
         if (((*ppSegment)->segmentID() == (const char*)pszSegmentID)
            && ((*ppSegment)->presence() == false))
         {
            iRC = (*ppSegment)->import(&pSegmentID);
            break;
         }
      }
   }
   return iRC;
  //## end segment::Command::parse%3499BD8301A0.body
}

bool Command::replicate ()
{
  //## begin segment::Command::replicate%457D8FD50203.body preserve=yes
   char pszSegmentID[5] = {"    "};
   char* psBuffer[2];
   psBuffer[0] = Message::instance(Message::OUTBOUND)->data() + 8;
   psBuffer[1] = Message::instance(Message::INBOUND)->data() + 8;
   char* pEndOfMessage = Message::instance(Message::OUTBOUND)->data() + Message::instance(Message::OUTBOUND)->dataLength();
   vector<Segment*>::iterator ppSegment;
   vector<Segment*>::iterator ppSegment2;
   int iRC = 0;
   while ((psBuffer[0] < pEndOfMessage) && (iRC == 0))
   {
      iRC = STS_INVALID_SEGMENT_ID;
      memcpy_s(pszSegmentID,4,psBuffer[0],4);
      for (ppSegment = m_hSegments.begin();ppSegment != m_hSegments.end();++ppSegment)
      {
         if ((*ppSegment)->segmentID() == (const char*)pszSegmentID)
         {
            iRC = (*ppSegment)->import(&psBuffer[0]);
            (*ppSegment)->replicate();
            char* q = psBuffer[1];
            if (memcmp(pszSegmentID,"S053",4) == 0
               || memcmp(pszSegmentID,"S269",4) == 0
               || memcmp(pszSegmentID,"S400",4) == 0
               || memcmp(pszSegmentID,"S912",4) == 0)
               ;
            else
               (*ppSegment)->deport(&psBuffer[1]);
            if (!memcmp(pszSegmentID,"L001",4))
            {
               char* p = (char*)*((ListSegment*)(*ppSegment));
               memcpy_s(pszSegmentID,4,p,4);
               int iItemCount = ((ListSegment*)(*ppSegment))->itemCount();
               for (ppSegment2 = m_hSegments.begin();ppSegment2 != m_hSegments.end();++ppSegment2)
               {
                  if ((*ppSegment2)->segmentID() == (const char*)pszSegmentID
                     && memcmp(pszSegmentID,"S273",4) != 0)
                  {
                     for (int j = 0;j < ((ListSegment*)(*ppSegment))->itemCount();++j)
                     {
                        iRC = (*ppSegment2)->import(&p);
                        (*ppSegment2)->replicate();
                        if ((*ppSegment2)->presence())
                           (*ppSegment2)->deport(&psBuffer[1]);
                        else
                           --iItemCount;
                     }
                     break;
                  }
               }
               ((ListSegment*)(*ppSegment))->update(q,iItemCount,psBuffer[1] - q);
            }
            break;
         }
      }
   }
   Message::instance(Message::INBOUND)->data()[24] = 'Q';
   Message::instance(Message::INBOUND)->setDataLength(psBuffer[1] - Message::instance(Message::INBOUND)->data());
   char szText[9];
   snprintf(szText,sizeof(szText),"%08d",Message::instance(Message::INBOUND)->dataLength());
   memcpy_s(Message::instance(Message::INBOUND)->data(),8,szText,8);
   return (iRC == 0);
  //## end segment::Command::replicate%457D8FD50203.body
}

int Command::reply ()
{
  //## begin segment::Command::reply%556C6B8501E8.body preserve=yes
	return 0;
  //## end segment::Command::reply%556C6B8501E8.body
}

void Command::update (Subject* pSubject)
{
  //## begin segment::Command::update%3651938B002D.body preserve=yes
  //## end segment::Command::update%3651938B002D.body
}

// Additional Declarations
  //## begin segment::Command%3454E2FA011D.declarations preserve=yes
  //## end segment::Command%3454E2FA011D.declarations

} // namespace segment

//## begin module%3651911103BB.epilog preserve=yes
//## end module%3651911103BB.epilog
