//	Copyright (c) 1998 - 2004
//	eFunds Corporation
// $Date:   Apr 08 2004 10:49:22  $ $Author:   D02405  $ $Revision:   1.3  $

struct segMultipleRowContextSegment
{
   char sSegmentID[4];
   char sSegmentVersion[4];
   char sLengthOfSegment[8];
   char cClientStateIndicator;
   char cArchive;
   char sReserved1[2];
   char sMaxRowsToFetch[4];
   char sTotalRecordsFound[4];
   char sRecordsReturnedThisMessage[4];
   char cServerStateIndicator;
   char sRecordNumberLastReturned[4];
   char sSTSContextData[64];
   char sReserved2[11];
};

struct segMultipleRowContextSegment_0101
{
   char sSegmentID[4];
   char sSegmentVersion[4];
   char sLengthOfSegment[8];
   char cClientStateIndicator;
   char cArchive;
   char sReserved1[2];
   char sMaxRowsToFetch[8];
   char sTotalRecordsFound[8];
   char sRecordsReturnedThisMessage[8];
   char cServerStateIndicator;
   char sRecordNumberLastReturned[8];
   char sSTSContextData[64];
   char sReserved2[11];
};
