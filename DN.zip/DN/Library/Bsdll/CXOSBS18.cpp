//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3BB346FA036B.cm preserve=no
//	$Date:   Aug 17 2021 01:54:12  $ $Author:   e5644299  $ $Revision:   1.39  $
//## end module%3BB346FA036B.cm

//## begin module%3BB346FA036B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3BB346FA036B.cp

//## Module: CXOSBS18%3BB346FA036B; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV03.0A.R003\ConnexPlatform\Server\Library\Bsdll\CXOSBS18.cpp

//## begin module%3BB346FA036B.additionalIncludes preserve=no
//## end module%3BB346FA036B.additionalIncludes

//## begin module%3BB346FA036B.includes preserve=yes
#include <stdio.h>
//## end module%3BB346FA036B.includes

#ifndef CXOSRU48_h
#include "CXODRU48.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS18_h
#include "CXODBS18.hpp"
#endif


//## begin module%3BB346FA036B.declarations preserve=no
//## end module%3BB346FA036B.declarations

//## begin module%3BB346FA036B.additionalDeclarations preserve=yes
//## end module%3BB346FA036B.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::RepositorySegment 

RepositorySegment::RepositorySegment()
  //## begin RepositorySegment::RepositorySegment%3BB3463500BB_const.hasinit preserve=no
      : m_pLoadField(0)
  //## end RepositorySegment::RepositorySegment%3BB3463500BB_const.hasinit
  //## begin RepositorySegment::RepositorySegment%3BB3463500BB_const.initialization preserve=yes
  //## end RepositorySegment::RepositorySegment%3BB3463500BB_const.initialization
{
  //## begin segment::RepositorySegment::RepositorySegment%3BB3463500BB_const.body preserve=yes
  //## end segment::RepositorySegment::RepositorySegment%3BB3463500BB_const.body
}

RepositorySegment::RepositorySegment(const RepositorySegment &right)
  //## begin RepositorySegment::RepositorySegment%3BB3463500BB_copy.hasinit preserve=no
  //## end RepositorySegment::RepositorySegment%3BB3463500BB_copy.hasinit
  //## begin RepositorySegment::RepositorySegment%3BB3463500BB_copy.initialization preserve=yes
  :m_pLoadField(0)
   ,PersistentSegment(right)
  //## end RepositorySegment::RepositorySegment%3BB3463500BB_copy.initialization
{
  //## begin segment::RepositorySegment::RepositorySegment%3BB3463500BB_copy.body preserve=yes
  //## end segment::RepositorySegment::RepositorySegment%3BB3463500BB_copy.body
}

RepositorySegment::RepositorySegment (const char* pszSegmentID, const char* pszTableName, const char* pszQualifier)
  //## begin segment::RepositorySegment::RepositorySegment%3BB9C2990167.hasinit preserve=no
      : m_pLoadField(0)
  //## end segment::RepositorySegment::RepositorySegment%3BB9C2990167.hasinit
  //## begin segment::RepositorySegment::RepositorySegment%3BB9C2990167.initialization preserve=yes
   ,PersistentSegment(pszSegmentID,pszTableName)
  //## end segment::RepositorySegment::RepositorySegment%3BB9C2990167.initialization
{
  //## begin segment::RepositorySegment::RepositorySegment%3BB9C2990167.body preserve=yes
  //## end segment::RepositorySegment::RepositorySegment%3BB9C2990167.body
}


RepositorySegment::~RepositorySegment()
{
  //## begin segment::RepositorySegment::~RepositorySegment%3BB3463500BB_dest.body preserve=yes
  //## end segment::RepositorySegment::~RepositorySegment%3BB3463500BB_dest.body
}


RepositorySegment & RepositorySegment::operator=(const RepositorySegment &right)
{
  //## begin segment::RepositorySegment::operator=%3BB3463500BB_assign.body preserve=yes
   if (this == &right)
      return *this;
   PersistentSegment::operator=(right);
   struct Fields* ppszFields = fields();
   for (int i = 0; i < m_lNumberOfFields; i++)
   {
      bool bLoadField = loadField(i);
      switch (*(ppszFields[i].pszAttributes))
      {
      case 'a':
      case 'O':
         if (bLoadField)
            memcpy_s((char*)loadField(i), ppszFields[i].siLength,(char*)right.loadField(i), ppszFields[i].siLength);
         (*((string*)field(i))) = (*((string*)right.field(i)));
         break;
      case 'A':
      case 'b':
      case 'u':
      case 'U':
         if (bLoadField)
         {
            memcpy_s((char*)loadField(i), ppszFields[i].siLength,(char*)right.loadField(i), ppszFields[i].siLength);
            (*(short*)((char*)loadField(i) - 2)) = (*(short*)((char*)right.loadField(i) - 2));
         }
         (*((string*)field(i))) = (*((string*)right.field(i)));
         break;
         //case 'c':
         //case 'v':
         //   if (bLoadField)
         //      memcpy((char*)loadField(i), (char*)right.loadField(i), ppszFields[i].siLength);
         //   (*(CXString*)field(i)) = (*(CXString*)right.field(i));
         //   break;
      case 'd':
         (*(double*)field(i)) = (*(double*)right.field(i));
         break;
      case 'l':
         (*(int*)field(i)) = (*(int*)right.field(i));
         break;
      case 's':
         (*(short int*)field(i)) = (*(short int*)right.field(i));
         break;
      }
   }
   return *this;
  //## end segment::RepositorySegment::operator=%3BB3463500BB_assign.body
}



//## Other Operations (implementation)
void RepositorySegment::bind (Query& hQuery, const char* szLocatorTable, bool bLoadFields)
{
  //## begin segment::RepositorySegment::bind%3DC18ECB033C.body preserve=yes
   struct Fields* ppszFields = fields();
   int i = 0;
   Column::ColumnType nColumnType;
   void* currentLoadField;
   // In order to have the locator fileds first in the select statement and use the
   // metadata to bind the columns, the TSTAMP_TRANS column is bound first so the
   // joins can all remain with the tables in the same order (locator, table)
   if (szLocatorTable)
      while (*ppszFields[i].pszName != '~')
      {
         if (!strcmp(ppszFields[i].pszName,"TSTAMP_TRANS"))
         {
            currentLoadField = loadField(i);
            nColumnType = (bLoadFields && currentLoadField) ? Column::CHAR : Column::STRING;
            hQuery.bind(szLocatorTable,ppszFields[i].pszName,nColumnType,(bLoadFields && currentLoadField) ? currentLoadField : field(i));
            break;
         }
         i++;
      }
   i = 0;
   while (*ppszFields[i].pszName != '~')
   {
      currentLoadField = loadField(i);
      switch (*(ppszFields[i].pszAttributes))
      {
         case 'd':
            nColumnType = Column::DOUBLE;
            break;
         case 's':
            nColumnType = Column::SHORT;
            break;
         case 'l':
            nColumnType = Column::LONG;
            break;
         default:
            nColumnType = (bLoadFields && currentLoadField) ? Column::CHAR : Column::STRING;
      }
      int iNPI = ((*(ppszFields[i].pszAttributes + 8)) > '0' && (*(ppszFields[i].pszAttributes + 8)) <= '9') ? (*(ppszFields[i].pszAttributes + 8)) - '0' : 0;
      if (*(ppszFields[i].pszAttributes + 9) == 'L')
      {
         if (szLocatorTable)
            hQuery.bind(szLocatorTable, ppszFields[i].pszName, nColumnType, (bLoadFields && currentLoadField) ? currentLoadField : field(i), 0, 0, iNPI);
      }
      else
      if (*(ppszFields[i].pszAttributes + 9) != 'X')
         hQuery.bind(m_strTableName.c_str(),ppszFields[i].pszName,nColumnType,(bLoadFields && currentLoadField) ? currentLoadField : field(i),0,0,iNPI);
      i++;
   }
  //## end segment::RepositorySegment::bind%3DC18ECB033C.body
}

int RepositorySegment::read (char** ppsBuffer)
{
  //## begin segment::RepositorySegment::read%3BB34C2D029F.body preserve=yes
   memcpy(m_pBuffer,*ppsBuffer,m_lBufferLength);
   *ppsBuffer += m_lBufferLength;
   setPresence(true);
#ifdef _WIN32
   /* the following traces out every column in the segment
      ... keep for future detail debugging
   char szBuffer[1024];
   struct Fields* ppszFields = fields();
   int nLengthOfSegment = ppszFields[m_lNumberOfFields].siLength;
   for (int i = 0;i < m_lNumberOfFields;i++)
   {
      if ((ppszFields[i].siOffset + ppszFields[i].siLength)
         <= nLengthOfSegment && ppszFields[i].siLength > 0)
      {
         memset(szBuffer,' ',1024);
         memcpy(szBuffer,ppszFields[i].pszName,strlen(ppszFields[i].pszName));
         if (loadField(i))
         {
            if (*(ppszFields[i].pszAttributes) == 'a')
            {
               strcpy(szBuffer + 19,(char*)loadField(i));
            }
            else
            if (*(ppszFields[i].pszAttributes) == 'A'
               || *(ppszFields[i].pszAttributes) == 'v')
            {
               memcpy(szBuffer + 19,(char*)loadField(i),(*(short*)((char*)loadField(i) - 2)));
               szBuffer[19 + (*(short*)((char*)loadField(i) - 2))] = '\0';
            }
         }
         else
         if (*(ppszFields[i].pszAttributes) == 'l')
         {
            sprintf(szBuffer + 19,"%-10d",*(int*)field(i));
         }
         else
         if (*(ppszFields[i].pszAttributes) == 'd')
         {
            sprintf(szBuffer + 19,"%-18.0f",*(double*)field(i));
         }
         else
         if (*(ppszFields[i].pszAttributes) == 's')
         {
            sprintf(szBuffer + 19,"%-hd",*(short*)field(i));
         }
         else
            szBuffer[19] = '\0';
         Trace::put(szBuffer);
      }
   }
*/
#endif
   struct Fields* ppszFields = fields();
   for (int i = 0; i < m_lNumberOfFields; i++)
   {
       int iNPI = 0;
       Column::setNPI(ppszFields[i].pszName, iNPI);
       if ((*(ppszFields[i].pszAttributes + 8)) > '0'
           && (*(ppszFields[i].pszAttributes + 8)) <= '9'
           || iNPI > 0)
       {
           void* pVal = m_pLoadField[i];
           if (!iNPI)
               iNPI = *(ppszFields[i].pszAttributes + 8) - '0';
           if (pVal)
               NPI::instance(iNPI)->addMask((char*)pVal, ppszFields[i].siLength, 0, ppszFields[i].siLength, 0, iNPI);
       }
   }
   return 0;
  //## end segment::RepositorySegment::read%3BB34C2D029F.body
}

void RepositorySegment::reset ()
{
  //## begin segment::RepositorySegment::reset%3BB8A267004E.body preserve=yes
   PersistentSegment::reset();
   memset(m_pBuffer,'\0',m_lBufferLength);
   struct Fields* ppszFields = fields();
   for (int i = 0;i < m_lNumberOfFields;i++)
   {
      if (*(ppszFields[i].pszAttributes) == 'd')
         *(double*)field(i) = 0;
   }
  //## end segment::RepositorySegment::reset%3BB8A267004E.body
}

int RepositorySegment::reverseShift ()
{
  //## begin segment::RepositorySegment::reverseShift%40FD81070242.body preserve=yes
   struct Fields* ppszFields = fields();
   for (int i = 0;i < m_lNumberOfFields;i++)
   {
      if (loadField(i))
      {
         if (*(ppszFields[i].pszAttributes) == 'a'
            || *(ppszFields[i].pszAttributes) == 'O')
         {
            if (i == 33 && memcmp(ppszFields[i].pszName, "TSTAMP_TRANS", 12) == 0)
            {
               Trace::put((char*)loadField(i));
               Trace::put((char*)(*((string*)field(i))).data());
            }
            ((string*)field(i))->assign((char*)loadField(i));
            if (i == 33 && memcmp(ppszFields[i].pszName, "TSTAMP_TRANS", 12) == 0)
               Trace::put((char*)(*((string*)field(i))).data());
         }
         else
         if (*(ppszFields[i].pszAttributes) == 'A'
            || *(ppszFields[i].pszAttributes) == 'b'
            || *(ppszFields[i].pszAttributes) == 'u'
            || *(ppszFields[i].pszAttributes) == 'U')
         {
            int len = (*(short*)((char*)loadField(i) - 2));
            ((string*)field(i))->assign((char*)loadField(i),len);
         }
         else
         if (*(ppszFields[i].pszAttributes) == 'v')
         {
            int len = (*(short*)((char*)loadField(i) - 2));
            ((CXString*)field(i))->set((char*)loadField(i),len);
         }
      }
   }
   return 0;
  //## end segment::RepositorySegment::reverseShift%40FD81070242.body
}

void RepositorySegment::setColumns (Table& hTable, bool bLocator)
{
  //## begin segment::RepositorySegment::setColumns%40FEB037038A.body preserve=yes
   struct Fields* ppszFields = fields();
   int i = 0;
   bool bKey = false;
   while (*ppszFields[i].pszName != '~')
   {
      // Key Fields:- 'K'ey Field; 'T'imestamp; 'S'equence Number
      bKey = ((*(ppszFields[i].pszAttributes + 9) == 'K') || (*(ppszFields[i].pszAttributes + 9) == 'S'));
      if (*(ppszFields[i].pszAttributes + 9) != 'X')
      {
         int iNPI = ((*(ppszFields[i].pszAttributes + 8)) > '0' && (*(ppszFields[i].pszAttributes + 8)) <= '9') ? (*(ppszFields[i].pszAttributes + 8)) - '0' : 0;
         if ((*(ppszFields[i].pszAttributes + 9) == 'L' && bLocator)
            || (*(ppszFields[i].pszAttributes + 9) != 'L' && !bLocator))
         {
            switch (*(ppszFields[i].pszAttributes))
            {
               case 'a':
               case 'A':
               case 'u':
               case 'U':
                  if (*(ppszFields[i].pszAttributes + 9) == 'T')
                     hTable.set(ppszFields[i].pszName,*((string*)field(i)),Column::TSTAMP_UPDATED);
                  else
                     hTable.set(ppszFields[i].pszName,*((string*)field(i)),0,bKey,true,iNPI);
                  break;
               case 'O':
                  hTable.set(ppszFields[i].pszName,*((string*)field(i)),Column::CLOB);
                  break;
               case 'b':
                  hTable.set(ppszFields[i].pszName,*((string*)field(i)),0,bKey,false);
                  break;
               case 'd':
                  if ((*(ppszFields[i].pszAttributes + 9) == 'N') && (*(double*)field(i) == 0))
                     hTable.set(ppszFields[i].pszName,"~NULL!");
                  else
                     hTable.set(ppszFields[i].pszName,*((double*)field(i)),bKey);
                  break;
               case 's':
                  //if (CommonHeaderSegment::instance()->getServiceName().find("DNCROW") != string::npos)
                  //{
                  //    if (*(ppszFields[i].pszAttributes + 9) == '#')
                  //       ++*((short*)field(i));
                  //}
                  if ((*(ppszFields[i].pszAttributes + 9) == 'N') && (*(short*)field(i) == 0))
                     hTable.set(ppszFields[i].pszName,"~NULL!");
                  else
                     hTable.set(ppszFields[i].pszName,(int)*((short*)field(i)),bKey);
                  break;
               case 'l':
                  if ((*(ppszFields[i].pszAttributes + 9) == 'N') && (*(int*)field(i) == 0))
                     hTable.set(ppszFields[i].pszName,"~NULL!");
                  else
                     hTable.set(ppszFields[i].pszName,*((int*)field(i)),bKey);
                  break;
            }
         }
      }
      i++;
   }
  //## end segment::RepositorySegment::setColumns%40FEB037038A.body
}

int RepositorySegment::shift ()
{
  //## begin segment::RepositorySegment::shift%3BB346B00186.body preserve=yes
   struct Fields* ppszFields = fields();
   int nLengthOfSegment = ppszFields[m_lNumberOfFields].siLength;
   for (int i = 0;i < m_lNumberOfFields;i++)
   {
      if ((ppszFields[i].siOffset + ppszFields[i].siLength) <= nLengthOfSegment && ppszFields[i].siLength > 0)
      {
         if (loadField(i))
         {
            if (*(ppszFields[i].pszAttributes) == 'a'
               || *(ppszFields[i].pszAttributes) == 'O')
               memcpy((char*)loadField(i),(char*)(*((string*)field(i))).data(),(*((string*)field(i))).length());
            else
            if (*(ppszFields[i].pszAttributes) == 'A'
               || *(ppszFields[i].pszAttributes) == 'u'
               || *(ppszFields[i].pszAttributes) == 'U')
            {
               memcpy((char*)loadField(i),(char*)(*((string*)field(i))).data(),(*((string*)field(i))).length());
               (*(short*)((char*)loadField(i) - 2)) = (short)(*((string*)field(i))).length();
            }
            else
            if (*(ppszFields[i].pszAttributes) == 'v')
            {
               memcpy((char*)loadField(i),(char*)(*((CXString*)field(i))).data(),(*((CXString*)field(i))).length());
               (*(short*)((char*)loadField(i) - 2)) = (*((CXString*)field(i))).length();
            }
         }
      }
   }
   return 0;
  //## end segment::RepositorySegment::shift%3BB346B00186.body
}

int RepositorySegment::write (char** ppsBuffer)
{
  //## begin segment::RepositorySegment::write%3BB34C3A01B5.body preserve=yes
   memcpy(*ppsBuffer,(char*)segmentID(),4);
   *ppsBuffer += 4;
   memcpy(*ppsBuffer,m_pBuffer,m_lBufferLength);
   *ppsBuffer += m_lBufferLength;
   struct Fields* ppszFields = fields();
   for (int i = 0; i < m_lNumberOfFields; i++)
   {
       int iNPI = 0;
       Column::setNPI(ppszFields[i].pszName, iNPI);
       if ((*(ppszFields[i].pszAttributes + 8)) > '0'
           && (*(ppszFields[i].pszAttributes + 8)) <= '9'
           || iNPI > 0)
       {
           void* pVal = m_pLoadField[i];
           if (!iNPI)
               iNPI = *(ppszFields[i].pszAttributes + 8) - '0';
           if (pVal)
               NPI::instance(iNPI)->addMask((char*)pVal, ppszFields[i].siLength, 0, ppszFields[i].siLength, 0, iNPI);
       }
   }
   return 0;
  //## end segment::RepositorySegment::write%3BB34C3A01B5.body
}

// Additional Declarations
  //## begin segment::RepositorySegment%3BB3463500BB.declarations preserve=yes
void RepositorySegment::repair(int iOffset)
{
   //field to be repaired will be the offset #
   struct Fields* ppszFields = fields();
   switch (*(ppszFields[iOffset].pszAttributes))
   {
      case 'a':
      case 'A':
      case 'b':
      case 'O':
      case 'u':
      case 'U':
      case 'w':
         ((char*)loadField(iOffset))[ppszFields[iOffset].siLength] = '\0';
         break;
      case 'd': //Double
         *(double*)field(iOffset)=0;
         break;
      case 'l': //Long
         *(int*)field(iOffset)=0;
         break;
      case 's': //Short
         *(short int*)field(iOffset)=0;
         break;
   }
}

  //## end segment::RepositorySegment%3BB3463500BB.declarations
} // namespace segment

//## begin module%3BB346FA036B.epilog preserve=yes
//## end module%3BB346FA036B.epilog
