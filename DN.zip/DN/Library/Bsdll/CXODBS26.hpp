//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%519F591E02CC.cm preserve=no
//## end module%519F591E02CC.cm

//## begin module%519F591E02CC.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%519F591E02CC.cp

//## Module: CXOSBS26%519F591E02CC; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS26.hpp

#ifndef CXOSBS26_h
#define CXOSBS26_h 1

//## begin module%519F591E02CC.additionalIncludes preserve=no
//## end module%519F591E02CC.additionalIncludes

//## begin module%519F591E02CC.includes preserve=yes
//## end module%519F591E02CC.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
//## begin module%519F591E02CC.declarations preserve=no
//## end module%519F591E02CC.declarations

//## begin module%519F591E02CC.additionalDeclarations preserve=yes
//## end module%519F591E02CC.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::SOAPSegment%519F589502BA.preface preserve=yes
//## end segment::SOAPSegment%519F589502BA.preface

//## Class: SOAPSegment%519F589502BA
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport SOAPSegment : public Segment  //## Inherits: <unnamed>%519F58A70395
{
  //## begin segment::SOAPSegment%519F589502BA.initialDeclarations preserve=yes
  //## end segment::SOAPSegment%519F589502BA.initialDeclarations

  public:
    //## Constructors (generated)
      SOAPSegment();

    //## Destructor (generated)
      virtual ~SOAPSegment();


    //## Other Operations (specified)
      //## Operation: fields%519F59B60301
      virtual struct  Fields* fields () const;

      //## Operation: getMsg%62507C7E0075
      reusable::string getMsg (int iIndex);

      //## Operation: instance%519F5B8B0216
      static SOAPSegment* instance ();

      //## Operation: reset%52F0EB9C0122
      virtual void reset ();

      //## Operation: setMsg%52F0EB7A0274
      int setMsg (const string& strMsgCde, const string& strTyp, const string& strTxt);

      //## Operation: setRtnCde%52F38FC50337
      int setRtnCde (char cRtnCde);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ActyId%51B9C57E02FF
      const string& getActyId () const
      {
        //## begin segment::SOAPSegment::getActyId%51B9C57E02FF.get preserve=no
        return m_strActyId;
        //## end segment::SOAPSegment::getActyId%51B9C57E02FF.get
      }

      void setActyId (const string& value)
      {
        //## begin segment::SOAPSegment::setActyId%51B9C57E02FF.set preserve=no
        m_strActyId = value;
        //## end segment::SOAPSegment::setActyId%51B9C57E02FF.set
      }


      //## Attribute: MsgCde%52F03D4A00F7
      const string& getMsgCde () const
      {
        //## begin segment::SOAPSegment::getMsgCde%52F03D4A00F7.get preserve=no
        return m_strMsgCde;
        //## end segment::SOAPSegment::getMsgCde%52F03D4A00F7.get
      }

      void setMsgCde (const string& value)
      {
        //## begin segment::SOAPSegment::setMsgCde%52F03D4A00F7.set preserve=no
        m_strMsgCde = value;
        //## end segment::SOAPSegment::setMsgCde%52F03D4A00F7.set
      }


      //## Attribute: MsgCount%52F0EC22021E
      const int& getMsgCount () const
      {
        //## begin segment::SOAPSegment::getMsgCount%52F0EC22021E.get preserve=no
        return m_iMsgCount;
        //## end segment::SOAPSegment::getMsgCount%52F0EC22021E.get
      }


      //## Attribute: MsgUuid%51B9C44D00FA
      const string& getMsgUuid () const
      {
        //## begin segment::SOAPSegment::getMsgUuid%51B9C44D00FA.get preserve=no
        return m_strMsgUuid;
        //## end segment::SOAPSegment::getMsgUuid%51B9C44D00FA.get
      }

      void setMsgUuid (const string& value)
      {
        //## begin segment::SOAPSegment::setMsgUuid%51B9C44D00FA.set preserve=no
        m_strMsgUuid = value;
        //## end segment::SOAPSegment::setMsgUuid%51B9C44D00FA.set
      }


      //## Attribute: RACFRtnCde%582CCD5302FC
      const int& getRACFRtnCde () const
      {
        //## begin segment::SOAPSegment::getRACFRtnCde%582CCD5302FC.get preserve=no
        return m_iRACFRtnCde;
        //## end segment::SOAPSegment::getRACFRtnCde%582CCD5302FC.get
      }

      void setRACFRtnCde (const int& value)
      {
        //## begin segment::SOAPSegment::setRACFRtnCde%582CCD5302FC.set preserve=no
        m_iRACFRtnCde = value;
        //## end segment::SOAPSegment::setRACFRtnCde%582CCD5302FC.set
      }


      //## Attribute: RtnCde%519F58BF0140
      const string& getRtnCde () const
      {
        //## begin segment::SOAPSegment::getRtnCde%519F58BF0140.get preserve=no
        return m_strRtnCde;
        //## end segment::SOAPSegment::getRtnCde%519F58BF0140.get
      }


      //## Attribute: ServVer%5DF79369013E
      const string& getServVer () const
      {
        //## begin segment::SOAPSegment::getServVer%5DF79369013E.get preserve=no
        return m_strServVer;
        //## end segment::SOAPSegment::getServVer%5DF79369013E.get
      }

      void setServVer (const string& value)
      {
        //## begin segment::SOAPSegment::setServVer%5DF79369013E.set preserve=no
        m_strServVer = value;
        //## end segment::SOAPSegment::setServVer%5DF79369013E.set
      }


      //## Attribute: Txt%52F03D4A0349
      const string& getTxt () const
      {
        //## begin segment::SOAPSegment::getTxt%52F03D4A0349.get preserve=no
        return m_strTxt;
        //## end segment::SOAPSegment::getTxt%52F03D4A0349.get
      }

      void setTxt (const string& value)
      {
        //## begin segment::SOAPSegment::setTxt%52F03D4A0349.set preserve=no
        m_strTxt = value;
        //## end segment::SOAPSegment::setTxt%52F03D4A0349.set
      }


      //## Attribute: Typ%52F03D4A020D
      const string& getTyp () const
      {
        //## begin segment::SOAPSegment::getTyp%52F03D4A020D.get preserve=no
        return m_strTyp;
        //## end segment::SOAPSegment::getTyp%52F03D4A020D.get
      }

      void setTyp (const string& value)
      {
        //## begin segment::SOAPSegment::setTyp%52F03D4A020D.set preserve=no
        m_strTyp = value;
        //## end segment::SOAPSegment::setTyp%52F03D4A020D.set
      }


      //## Attribute: USER_ID%543DA11000A4
      const string& getUSER_ID () const
      {
        //## begin segment::SOAPSegment::getUSER_ID%543DA11000A4.get preserve=no
        return m_strUSER_ID;
        //## end segment::SOAPSegment::getUSER_ID%543DA11000A4.get
      }

      void setUSER_ID (const string& value)
      {
        //## begin segment::SOAPSegment::setUSER_ID%543DA11000A4.set preserve=no
        m_strUSER_ID = value;
        //## end segment::SOAPSegment::setUSER_ID%543DA11000A4.set
      }


      //## Attribute: USER_PASSWORD%543DA146014C
      const string& getUSER_PASSWORD () const
      {
        //## begin segment::SOAPSegment::getUSER_PASSWORD%543DA146014C.get preserve=no
        return m_strUSER_PASSWORD;
        //## end segment::SOAPSegment::getUSER_PASSWORD%543DA146014C.get
      }

      void setUSER_PASSWORD (const string& value)
      {
        //## begin segment::SOAPSegment::setUSER_PASSWORD%543DA146014C.set preserve=no
        m_strUSER_PASSWORD = value;
        //## end segment::SOAPSegment::setUSER_PASSWORD%543DA146014C.set
      }


    // Additional Public Declarations
      //## begin segment::SOAPSegment%519F589502BA.public preserve=yes
      //## end segment::SOAPSegment%519F589502BA.public

  protected:
    // Additional Protected Declarations
      //## begin segment::SOAPSegment%519F589502BA.protected preserve=yes
      //## end segment::SOAPSegment%519F589502BA.protected

  private:
    // Additional Private Declarations
      //## begin segment::SOAPSegment%519F589502BA.private preserve=yes
      //## end segment::SOAPSegment%519F589502BA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin segment::SOAPSegment::ActyId%51B9C57E02FF.attr preserve=no  public: string {V} 
      string m_strActyId;
      //## end segment::SOAPSegment::ActyId%51B9C57E02FF.attr

      //## Attribute: Instance%519F5B7500A4
      //## begin segment::SOAPSegment::Instance%519F5B7500A4.attr preserve=no  private: static SOAPSegment* {V} 0
      static SOAPSegment* m_pInstance;
      //## end segment::SOAPSegment::Instance%519F5B7500A4.attr

      //## begin segment::SOAPSegment::MsgCde%52F03D4A00F7.attr preserve=no  public: string {V} 
      string m_strMsgCde;
      //## end segment::SOAPSegment::MsgCde%52F03D4A00F7.attr

      //## begin segment::SOAPSegment::MsgCount%52F0EC22021E.attr preserve=no  public: int {V} 0
      int m_iMsgCount;
      //## end segment::SOAPSegment::MsgCount%52F0EC22021E.attr

      //## begin segment::SOAPSegment::MsgUuid%51B9C44D00FA.attr preserve=no  public: string {V} 
      string m_strMsgUuid;
      //## end segment::SOAPSegment::MsgUuid%51B9C44D00FA.attr

      //## Attribute: Msg%6250794902F0
      //## begin segment::SOAPSegment::Msg%6250794902F0.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hMsg;
      //## end segment::SOAPSegment::Msg%6250794902F0.attr

      //## begin segment::SOAPSegment::RACFRtnCde%582CCD5302FC.attr preserve=no  public: int {U} 0
      int m_iRACFRtnCde;
      //## end segment::SOAPSegment::RACFRtnCde%582CCD5302FC.attr

      //## begin segment::SOAPSegment::RtnCde%519F58BF0140.attr preserve=no  public: string {V} 
      string m_strRtnCde;
      //## end segment::SOAPSegment::RtnCde%519F58BF0140.attr

      //## begin segment::SOAPSegment::ServVer%5DF79369013E.attr preserve=no  public: string {V} 
      string m_strServVer;
      //## end segment::SOAPSegment::ServVer%5DF79369013E.attr

      //## begin segment::SOAPSegment::Txt%52F03D4A0349.attr preserve=no  public: string {V} 
      string m_strTxt;
      //## end segment::SOAPSegment::Txt%52F03D4A0349.attr

      //## begin segment::SOAPSegment::Typ%52F03D4A020D.attr preserve=no  public: string {V} 
      string m_strTyp;
      //## end segment::SOAPSegment::Typ%52F03D4A020D.attr

      //## begin segment::SOAPSegment::USER_ID%543DA11000A4.attr preserve=no  public: string {V} 
      string m_strUSER_ID;
      //## end segment::SOAPSegment::USER_ID%543DA11000A4.attr

      //## begin segment::SOAPSegment::USER_PASSWORD%543DA146014C.attr preserve=no  public: string {V} 
      string m_strUSER_PASSWORD;
      //## end segment::SOAPSegment::USER_PASSWORD%543DA146014C.attr

    // Additional Implementation Declarations
      //## begin segment::SOAPSegment%519F589502BA.implementation preserve=yes
      //## end segment::SOAPSegment%519F589502BA.implementation

};

//## begin segment::SOAPSegment%519F589502BA.postscript preserve=yes
//## end segment::SOAPSegment%519F589502BA.postscript

} // namespace segment

//## begin module%519F591E02CC.epilog preserve=yes
//## end module%519F591E02CC.epilog


#endif
