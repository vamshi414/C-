//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%359B6F850112.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%359B6F850112.cm

//## begin module%359B6F850112.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%359B6F850112.cp

//## Module: CXOSBS11%359B6F850112; Package specification
//## Subsystem: BSDLL%394E1F8C0345
//## Source file: C:\Pvcswork\Dn\Server\Library\Bsdll\CXODBS11.hpp

#ifndef CXOSBS11_h
#define CXOSBS11_h 1

//## begin module%359B6F850112.additionalIncludes preserve=no
//## end module%359B6F850112.additionalIncludes

//## begin module%359B6F850112.includes preserve=yes
// $Date:   18 Jan 2018 14:11:44  $ $Author:   e1009839  $ $Revision:   1.3  $
//## end module%359B6F850112.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSRU24_h
#include "CXODRU24.hpp"
#endif

//## Modelname: Connex Foundation::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;

} // namespace segment

//## begin module%359B6F850112.declarations preserve=no
//## end module%359B6F850112.declarations

//## begin module%359B6F850112.additionalDeclarations preserve=yes
//## end module%359B6F850112.additionalDeclarations


namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::ResponseTimeSegment%3453FD9B0248.preface preserve=yes
//## end segment::ResponseTimeSegment%3453FD9B0248.preface

//## Class: ResponseTimeSegment%3453FD9B0248
//## Category: Connex Foundation::Segment_CAT%3471F0BE0219
//## Subsystem: BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3D18536F01E4;reusable::IString { -> }
//## Uses: <unnamed>%3D185CC501A5;InformationSegment { -> F}

class DllExport ResponseTimeSegment : public Segment  //## Inherits: <unnamed>%3453FDAC010C
{
  //## begin segment::ResponseTimeSegment%3453FD9B0248.initialDeclarations preserve=yes
  //## end segment::ResponseTimeSegment%3453FD9B0248.initialDeclarations

  public:
    //## Constructors (generated)
      ResponseTimeSegment();

    //## Destructor (generated)
      virtual ~ResponseTimeSegment();

    //## Assignment Operation (generated)
      ResponseTimeSegment & operator=(const ResponseTimeSegment &right);


    //## Other Operations (specified)
      //## Operation: deport%3D1850170157
      virtual int deport (char** ppsBuffer);

      //## Operation: import%3D1850190203
      virtual int import (char** ppsBuffer);

    // Additional Public Declarations
      //## begin segment::ResponseTimeSegment%3453FD9B0248.public preserve=yes
      //## end segment::ResponseTimeSegment%3453FD9B0248.public

  protected:
    // Additional Protected Declarations
      //## begin segment::ResponseTimeSegment%3453FD9B0248.protected preserve=yes
      //## end segment::ResponseTimeSegment%3453FD9B0248.protected

  private:
    // Additional Private Declarations
      //## begin segment::ResponseTimeSegment%3453FD9B0248.private preserve=yes
      //## end segment::ResponseTimeSegment%3453FD9B0248.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Timestamp%3D185089008C
      //## begin segment::ResponseTimeSegment::Timestamp%3D185089008C.attr preserve=no  private: IString[3] {V} 
      IString m_strTimestamp[3];
      //## end segment::ResponseTimeSegment::Timestamp%3D185089008C.attr

    // Data Members for Associations

      //## Association: Connex Foundation::Segment_CAT::<unnamed>%3D18505602DE
      //## Role: ResponseTimeSegment::<m_hDateTime>%3D18505701A5
      //## begin segment::ResponseTimeSegment::<m_hDateTime>%3D18505701A5.role preserve=no  public: IF::DateTime { -> VHgN}
      IF::DateTime m_hDateTime;
      //## end segment::ResponseTimeSegment::<m_hDateTime>%3D18505701A5.role

    // Additional Implementation Declarations
      //## begin segment::ResponseTimeSegment%3453FD9B0248.implementation preserve=yes
      //## end segment::ResponseTimeSegment%3453FD9B0248.implementation

};

//## begin segment::ResponseTimeSegment%3453FD9B0248.postscript preserve=yes
//## end segment::ResponseTimeSegment%3453FD9B0248.postscript

} // namespace segment

//## begin module%359B6F850112.epilog preserve=yes
using namespace segment;
//## end module%359B6F850112.epilog


#endif
