//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63A4B929026C.cm preserve=no
//## end module%63A4B929026C.cm

//## begin module%63A4B929026C.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63A4B929026C.cp

//## Module: CXOSBS33%63A4B929026C; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS33.hpp

#ifndef CXOSBS33_h
#define CXOSBS33_h 1

//## begin module%63A4B929026C.additionalIncludes preserve=no
//## end module%63A4B929026C.additionalIncludes

//## begin module%63A4B929026C.includes preserve=yes
//## end module%63A4B929026C.includes

#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif
//## begin module%63A4B929026C.declarations preserve=no
//## end module%63A4B929026C.declarations

//## begin module%63A4B929026C.additionalDeclarations preserve=yes
//## end module%63A4B929026C.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::NetworkSegment%63A4B88502AE.preface preserve=yes
//## end segment::NetworkSegment%63A4B88502AE.preface

//## Class: NetworkSegment%63A4B88502AE
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport NetworkSegment : public PersistentSegment  //## Inherits: <unnamed>%63A4BB3D002D
{
  //## begin segment::NetworkSegment%63A4B88502AE.initialDeclarations preserve=yes
  //## end segment::NetworkSegment%63A4B88502AE.initialDeclarations

  public:
    //## Constructors (generated)
      NetworkSegment();

      NetworkSegment(const NetworkSegment &right);

    //## Constructors (specified)
      //## Operation: NetworkSegment%63A559E50049
      NetworkSegment (const char* pszSegment, const char* pszTableName);

    //## Destructor (generated)
      virtual ~NetworkSegment();

    //## Assignment Operation (generated)
      NetworkSegment & operator=(const NetworkSegment &right);


    //## Other Operations (specified)
      //## Operation: preview%63A4C34700BE
      virtual bool preview (const char* psBuffer);

      //## Operation: scrape%63A4C1630082
      virtual bool scrape (const char* sBuffer, int iRecordLength);

      //## Operation: setDatasetName%63A4C6F301D4
      virtual void setDatasetName (const reusable::string& strValue);

    // Additional Public Declarations
      //## begin segment::NetworkSegment%63A4B88502AE.public preserve=yes
      //## end segment::NetworkSegment%63A4B88502AE.public

  protected:
    // Additional Protected Declarations
      //## begin segment::NetworkSegment%63A4B88502AE.protected preserve=yes
      //## end segment::NetworkSegment%63A4B88502AE.protected

  private:
    // Additional Private Declarations
      //## begin segment::NetworkSegment%63A4B88502AE.private preserve=yes
      //## end segment::NetworkSegment%63A4B88502AE.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin segment::NetworkSegment%63A4B88502AE.implementation preserve=yes
      //## end segment::NetworkSegment%63A4B88502AE.implementation

};

//## begin segment::NetworkSegment%63A4B88502AE.postscript preserve=yes
//## end segment::NetworkSegment%63A4B88502AE.postscript

} // namespace segment

//## begin module%63A4B929026C.epilog preserve=yes
//## end module%63A4B929026C.epilog


#endif
