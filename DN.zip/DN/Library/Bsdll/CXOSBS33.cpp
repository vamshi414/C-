//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63A4B92C0395.cm preserve=no
//## end module%63A4B92C0395.cm

//## begin module%63A4B92C0395.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63A4B92C0395.cp

//## Module: CXOSBS33%63A4B92C0395; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXOSBS33.cpp

//## begin module%63A4B92C0395.additionalIncludes preserve=no
//## end module%63A4B92C0395.additionalIncludes

//## begin module%63A4B92C0395.includes preserve=yes
//## end module%63A4B92C0395.includes

#ifndef CXOSBS33_h
#include "CXODBS33.hpp"
#endif
//## begin module%63A4B92C0395.declarations preserve=no
//## end module%63A4B92C0395.declarations

//## begin module%63A4B92C0395.additionalDeclarations preserve=yes
//## end module%63A4B92C0395.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::NetworkSegment 

NetworkSegment::NetworkSegment()
  //## begin NetworkSegment::NetworkSegment%63A4B88502AE_const.hasinit preserve=no
  //## end NetworkSegment::NetworkSegment%63A4B88502AE_const.hasinit
  //## begin NetworkSegment::NetworkSegment%63A4B88502AE_const.initialization preserve=yes
  //## end NetworkSegment::NetworkSegment%63A4B88502AE_const.initialization
{
  //## begin segment::NetworkSegment::NetworkSegment%63A4B88502AE_const.body preserve=yes
   memcpy(m_sID,"BS33",4);
  //## end segment::NetworkSegment::NetworkSegment%63A4B88502AE_const.body
}

NetworkSegment::NetworkSegment(const NetworkSegment &right)
  //## begin NetworkSegment::NetworkSegment%63A4B88502AE_copy.hasinit preserve=no
  //## end NetworkSegment::NetworkSegment%63A4B88502AE_copy.hasinit
  //## begin NetworkSegment::NetworkSegment%63A4B88502AE_copy.initialization preserve=yes
   : PersistentSegment(right)
  //## end NetworkSegment::NetworkSegment%63A4B88502AE_copy.initialization
{
  //## begin segment::NetworkSegment::NetworkSegment%63A4B88502AE_copy.body preserve=yes
  //## end segment::NetworkSegment::NetworkSegment%63A4B88502AE_copy.body
}

NetworkSegment::NetworkSegment (const char* pszSegment, const char* pszTableName)
  //## begin segment::NetworkSegment::NetworkSegment%63A559E50049.hasinit preserve=no
  //## end segment::NetworkSegment::NetworkSegment%63A559E50049.hasinit
  //## begin segment::NetworkSegment::NetworkSegment%63A559E50049.initialization preserve=yes
   : PersistentSegment(pszSegment,pszTableName)
  //## end segment::NetworkSegment::NetworkSegment%63A559E50049.initialization
{
  //## begin segment::NetworkSegment::NetworkSegment%63A559E50049.body preserve=yes
   memcpy(m_sID,"BS33",4);
  //## end segment::NetworkSegment::NetworkSegment%63A559E50049.body
}


NetworkSegment::~NetworkSegment()
{
  //## begin segment::NetworkSegment::~NetworkSegment%63A4B88502AE_dest.body preserve=yes
  //## end segment::NetworkSegment::~NetworkSegment%63A4B88502AE_dest.body
}


NetworkSegment & NetworkSegment::operator=(const NetworkSegment &right)
{
  //## begin segment::NetworkSegment::operator=%63A4B88502AE_assign.body preserve=yes
   if (this == &right)
      return *this;
   PersistentSegment::operator=(right);
   return *this;
  //## end segment::NetworkSegment::operator=%63A4B88502AE_assign.body
}



//## Other Operations (implementation)
bool NetworkSegment::preview (const char* psBuffer)
{
  //## begin segment::NetworkSegment::preview%63A4C34700BE.body preserve=yes
   return false;
  //## end segment::NetworkSegment::preview%63A4C34700BE.body
}

bool NetworkSegment::scrape (const char* sBuffer, int iRecordLength)
{
  //## begin segment::NetworkSegment::scrape%63A4C1630082.body preserve=yes
   return false;
  //## end segment::NetworkSegment::scrape%63A4C1630082.body
}

void NetworkSegment::setDatasetName (const reusable::string& strValue)
{
  //## begin segment::NetworkSegment::setDatasetName%63A4C6F301D4.body preserve=yes
  //## end segment::NetworkSegment::setDatasetName%63A4C6F301D4.body
}

// Additional Declarations
  //## begin segment::NetworkSegment%63A4B88502AE.declarations preserve=yes
  //## end segment::NetworkSegment%63A4B88502AE.declarations

} // namespace segment

//## begin module%63A4B92C0395.epilog preserve=yes
//## end module%63A4B92C0395.epilog
