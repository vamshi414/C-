//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5D0BD5630146.cm preserve=no
//	$Date:   Jan 03 2020 14:26:36  $ $Author:   e1009652  $
//	$Revision:   1.2  $
//## end module%5D0BD5630146.cm

//## begin module%5D0BD5630146.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5D0BD5630146.cp

//## Module: CXOSBS32%5D0BD5630146; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS32.hpp

#ifndef CXOSBS32_h
#define CXOSBS32_h 1

//## begin module%5D0BD5630146.additionalIncludes preserve=no
//## end module%5D0BD5630146.additionalIncludes

//## begin module%5D0BD5630146.includes preserve=yes
//## end module%5D0BD5630146.includes

#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
//## begin module%5D0BD5630146.declarations preserve=no
//## end module%5D0BD5630146.declarations

//## begin module%5D0BD5630146.additionalDeclarations preserve=yes
//## end module%5D0BD5630146.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::ActivitySegment%5D0BD4BE01AC.preface preserve=yes
//## end segment::ActivitySegment%5D0BD4BE01AC.preface

//## Class: ActivitySegment%5D0BD4BE01AC
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport ActivitySegment : public GenericSegment  //## Inherits: <unnamed>%5D0BD4D80238
{
  //## begin segment::ActivitySegment%5D0BD4BE01AC.initialDeclarations preserve=yes
  //## end segment::ActivitySegment%5D0BD4BE01AC.initialDeclarations

  public:
    //## Constructors (generated)
      ActivitySegment();

    //## Destructor (generated)
      virtual ~ActivitySegment();

    //## Assignment Operation (generated)
      ActivitySegment & operator=(const ActivitySegment &right);


    //## Other Operations (specified)
      //## Operation: operator+=%5D0BD4FF03B6
      void operator += (const ActivitySegment& right);

    // Additional Public Declarations
      //## begin segment::ActivitySegment%5D0BD4BE01AC.public preserve=yes
      void operator -= (const ActivitySegment& right);
      //## end segment::ActivitySegment%5D0BD4BE01AC.public

  protected:
    // Additional Protected Declarations
      //## begin segment::ActivitySegment%5D0BD4BE01AC.protected preserve=yes
      //## end segment::ActivitySegment%5D0BD4BE01AC.protected

  private:
    // Additional Private Declarations
      //## begin segment::ActivitySegment%5D0BD4BE01AC.private preserve=yes
      //## end segment::ActivitySegment%5D0BD4BE01AC.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin segment::ActivitySegment%5D0BD4BE01AC.implementation preserve=yes
      //## end segment::ActivitySegment%5D0BD4BE01AC.implementation

};

//## begin segment::ActivitySegment%5D0BD4BE01AC.postscript preserve=yes
//## end segment::ActivitySegment%5D0BD4BE01AC.postscript

} // namespace segment

//## begin module%5D0BD5630146.epilog preserve=yes
//## end module%5D0BD5630146.epilog


#endif
