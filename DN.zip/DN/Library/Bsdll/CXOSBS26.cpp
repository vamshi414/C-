//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%519F592002C3.cm preserve=no
//## end module%519F592002C3.cm

//## begin module%519F592002C3.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%519F592002C3.cp

//## Module: CXOSBS26%519F592002C3; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXOSBS26.cpp

//## begin module%519F592002C3.additionalIncludes preserve=no
//## end module%519F592002C3.additionalIncludes

//## begin module%519F592002C3.includes preserve=yes
//## end module%519F592002C3.includes

#ifndef CXOSBS26_h
#include "CXODBS26.hpp"
#endif
//## begin module%519F592002C3.declarations preserve=no
//## end module%519F592002C3.declarations

//## begin module%519F592002C3.additionalDeclarations preserve=yes
#define FIELDS 9
Fields SOAPSegment_Fields[FIELDS + 1] =
{
   "a         ","ActyId",0,0,
   "a         ","MsgCde",0,0,
   "a         ","MsgUuid",0,0,
   "a         ","RtnCde",0,0,
   "a         ","ServVer",0,0,
   "a         ","Txt",0,0,
   "a         ","Typ",0,0,
   "a         ","USER_ID",0,0,
   "a         ","USER_PASSWORD",0,0,
   "~","~",-1,0,
};
//## end module%519F592002C3.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::SOAPSegment 

//## begin segment::SOAPSegment::Instance%519F5B7500A4.attr preserve=no  private: static segment::SOAPSegment* {V} 0
segment::SOAPSegment* SOAPSegment::m_pInstance = 0;
//## end segment::SOAPSegment::Instance%519F5B7500A4.attr

SOAPSegment::SOAPSegment()
  //## begin SOAPSegment::SOAPSegment%519F589502BA_const.hasinit preserve=no
      : m_iMsgCount(0),
        m_iRACFRtnCde(0)
  //## end SOAPSegment::SOAPSegment%519F589502BA_const.hasinit
  //## begin SOAPSegment::SOAPSegment%519F589502BA_const.initialization preserve=yes
  //## end SOAPSegment::SOAPSegment%519F589502BA_const.initialization
{
  //## begin segment::SOAPSegment::SOAPSegment%519F589502BA_const.body preserve=yes
   memcpy(m_sID,"BS26",4);
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strActyId;
   m_pField[1] = &m_strMsgCde;
   m_pField[2] = &m_strMsgUuid;
   m_pField[3] = &m_strRtnCde;
   m_pField[4] = &m_strServVer;
   m_pField[5] = &m_strTxt;
   m_pField[6] = &m_strTyp;
   m_pField[7] = &m_strUSER_ID;
   m_pField[8] = &m_strUSER_PASSWORD;
   m_strRtnCde.assign("0",1);
  //## end segment::SOAPSegment::SOAPSegment%519F589502BA_const.body
}


SOAPSegment::~SOAPSegment()
{
  //## begin segment::SOAPSegment::~SOAPSegment%519F589502BA_dest.body preserve=yes
   delete [] m_pField;
  //## end segment::SOAPSegment::~SOAPSegment%519F589502BA_dest.body
}



//## Other Operations (implementation)
struct  Fields* SOAPSegment::fields () const
{
  //## begin segment::SOAPSegment::fields%519F59B60301.body preserve=yes
   return &SOAPSegment_Fields[0];
  //## end segment::SOAPSegment::fields%519F59B60301.body
}

string SOAPSegment::getMsg (int iIndex)
{
  //## begin segment::SOAPSegment::getMsg%62507C7E0075.body preserve=yes
   if (iIndex < m_hMsg.size())
      return m_hMsg[iIndex];
   return "";
  //## end segment::SOAPSegment::getMsg%62507C7E0075.body
}

SOAPSegment* SOAPSegment::instance ()
{
  //## begin segment::SOAPSegment::instance%519F5B8B0216.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new SOAPSegment;
   return m_pInstance;
  //## end segment::SOAPSegment::instance%519F5B8B0216.body
}

void SOAPSegment::reset ()
{
  //## begin segment::SOAPSegment::reset%52F0EB9C0122.body preserve=yes
   Segment::reset();
   m_strActyId.erase();
   m_strMsgCde.erase();
   m_iMsgCount = 0;
   m_strMsgUuid.erase();
   m_iRACFRtnCde = 0;
   m_strRtnCde.assign("0",1);
   m_strServVer.erase();
   m_strTxt.erase();
   m_strTyp.erase();
   m_strUSER_ID.erase();
   m_strUSER_PASSWORD.erase();
   m_hMsg.erase(m_hMsg.begin(), m_hMsg.end());
  //## end segment::SOAPSegment::reset%52F0EB9C0122.body
}

int SOAPSegment::setMsg (const string& strMsgCde, const string& strTyp, const string& strTxt)
{
  //## begin segment::SOAPSegment::setMsg%52F0EB7A0274.body preserve=yes
   m_hMsg.push_back(strMsgCde);
   m_hMsg.push_back(strTyp);
   m_hMsg.push_back(strTxt);
   return ++m_iMsgCount;
  //## end segment::SOAPSegment::setMsg%52F0EB7A0274.body
}

int SOAPSegment::setRtnCde (char cRtnCde)
{
  //## begin segment::SOAPSegment::setRtnCde%52F38FC50337.body preserve=yes
   m_strRtnCde = cRtnCde;
   return atoi(&cRtnCde,1);
  //## end segment::SOAPSegment::setRtnCde%52F38FC50337.body
}

// Additional Declarations
  //## begin segment::SOAPSegment%519F589502BA.declarations preserve=yes
  //## end segment::SOAPSegment%519F589502BA.declarations

} // namespace segment

//## begin module%519F592002C3.epilog preserve=yes
//## end module%519F592002C3.epilog
