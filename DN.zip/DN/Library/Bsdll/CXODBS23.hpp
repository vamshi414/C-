//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E89F4A701C5.cm preserve=no
//## end module%3E89F4A701C5.cm

//## begin module%3E89F4A701C5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3E89F4A701C5.cp

//## Module: CXOSBS23%3E89F4A701C5; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS23.hpp

#ifndef CXOSBS23_h
#define CXOSBS23_h 1

//## begin module%3E89F4A701C5.additionalIncludes preserve=no
//## end module%3E89F4A701C5.additionalIncludes

//## begin module%3E89F4A701C5.includes preserve=yes
#include <map>
#include <vector>
//## end module%3E89F4A701C5.includes

#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;

} // namespace reusable

//## begin module%3E89F4A701C5.declarations preserve=no
//## end module%3E89F4A701C5.declarations

//## begin module%3E89F4A701C5.additionalDeclarations preserve=yes
//## end module%3E89F4A701C5.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::GenericSegment%3E89F377034B.preface preserve=yes
//## end segment::GenericSegment%3E89F377034B.preface

//## Class: GenericSegment%3E89F377034B
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E8A036901D4;reusable::Column { -> F}
//## Uses: <unnamed>%3E8A03AC0119;reusable::Query { -> F}
//## Uses: <unnamed>%51E7F9F302EE;reusable::Table { -> F}

class DllExport GenericSegment : public PersistentSegment  //## Inherits: <unnamed>%3E89F3B0036B
{
  //## begin segment::GenericSegment%3E89F377034B.initialDeclarations preserve=yes
  //## end segment::GenericSegment%3E89F377034B.initialDeclarations

  public:
    //## Constructors (generated)
      GenericSegment();

    //## Destructor (generated)
      virtual ~GenericSegment();

    //## Assignment Operation (generated)
      GenericSegment & operator=(const GenericSegment &right);


    //## Other Operations (specified)
      //## Operation: add%3E89F4230399
      void add (const string& strValue);

      //## Operation: bind%3E8A02EA0242
      virtual void bind (const char* pszTable, const char* pszColumn, reusable::Query& hQuery, const char* pszFunction = 0, int iNPI = 0);

      //## Operation: copy%56312A1401DD
      void copy (segment::Segment& hSegment) const;

      //## Operation: deport%3E89F4120148
      virtual int deport (char** ppsBuffer);

      //## Operation: deport%51E7F98C035F
      virtual int deport (char** ppsBuffer, reusable::Table& hTable);

      //## Operation: erase%5E18F57100D0
      void erase (const char* pszName);

      //## Operation: _field%519CD5090161
      virtual bool _field (const char* pszName, string& strValue, bool bDescription = false, bool bFormat = true) const;

      //## Operation: get%542C1BB70270
      const string& get (const char* pszName, short* psiNull = 0);

      //## Operation: getColumnName%652ED87B01C2
      bool getColumnName (int iIndex, string& hValue);

      //## Operation: getFieldByIndex%5E27B9B301A0
      virtual bool getFieldByIndex (int iIndex, string& hValue) const;

      //## Operation: getFieldIndex%5E27B99C02DA
      virtual bool getFieldIndex (const char* pszName, int& iIndex) const;

      //## Operation: getColumnCount%652ED8DA004E
      int getColumnCount ();

      //## Operation: import%3E89F404032C
      virtual int import (char** ppsBuffer);

      //## Operation: import%51E7F9AF018C
      virtual int import (char** ppsBuffer, reusable::Table& hTable);

      //## Operation: isNull%56A7C58E015C
      bool isNull () const;

      //## Operation: reset%3E89F40B0000
      virtual void reset ();

      //## Operation: set%542C1B8B03DA
      int set (const char* pszName, const string& strValue);

      //## Operation: set%542C24F80198
      void set (const char* pszName, int iValue);

      //## Operation: set%648214910189
      void set (const char* pszName, long lValue);

      //## Operation: set%5C4A139C0076
      void set (const char* pszName, double dValue);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: RecordType%3E8AF1900213
      void setRecordType (const reusable::string& value)
      {
        //## begin segment::GenericSegment::setRecordType%3E8AF1900213.set preserve=no
        m_strRecordType = value;
        //## end segment::GenericSegment::setRecordType%3E8AF1900213.set
      }


      //## Attribute: Value%3E8AF5D10109
      const vector<string*>& getValue () const
      {
        //## begin segment::GenericSegment::getValue%3E8AF5D10109.get preserve=no
        return m_hValue;
        //## end segment::GenericSegment::getValue%3E8AF5D10109.get
      }


    // Additional Public Declarations
      //## begin segment::GenericSegment%3E89F377034B.public preserve=yes
      //## end segment::GenericSegment%3E89F377034B.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Column%519CD51D031C
      //## begin segment::GenericSegment::Column%519CD51D031C.attr preserve=no  protected: map<string,int,less<string> > {VA} 
      map<string,int,less<string> > m_hColumn;
      //## end segment::GenericSegment::Column%519CD51D031C.attr

      //## begin segment::GenericSegment::Value%3E8AF5D10109.attr preserve=no  public: vector<string*> {V} 
      vector<string*> m_hValue;
      //## end segment::GenericSegment::Value%3E8AF5D10109.attr

    // Additional Protected Declarations
      //## begin segment::GenericSegment%3E89F377034B.protected preserve=yes
      //## end segment::GenericSegment%3E89F377034B.protected

  private:
    // Additional Private Declarations
      //## begin segment::GenericSegment%3E89F377034B.private preserve=yes
      //## end segment::GenericSegment%3E89F377034B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Null%56A7C5210370
      //## begin segment::GenericSegment::Null%56A7C5210370.attr preserve=no  private: vector<short> {V} 
      vector<short> m_hNull;
      //## end segment::GenericSegment::Null%56A7C5210370.attr

      //## begin segment::GenericSegment::RecordType%3E8AF1900213.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strRecordType;
      //## end segment::GenericSegment::RecordType%3E8AF1900213.attr

    // Additional Implementation Declarations
      //## begin segment::GenericSegment%3E89F377034B.implementation preserve=yes
      //## end segment::GenericSegment%3E89F377034B.implementation

};

//## begin segment::GenericSegment%3E89F377034B.postscript preserve=yes
//## end segment::GenericSegment%3E89F377034B.postscript

} // namespace segment

//## begin module%3E89F4A701C5.epilog preserve=yes
using namespace segment;
//## end module%3E89F4A701C5.epilog


#endif
