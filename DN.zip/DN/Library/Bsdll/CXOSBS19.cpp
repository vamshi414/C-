//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3D176FE4032C.cm preserve=no
//	$Date:   Feb 07 2018 06:53:14  $ $Author:   e1044731  $ $Revision:   1.9  $
//## end module%3D176FE4032C.cm

//## begin module%3D176FE4032C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3D176FE4032C.cp

//## Module: CXOSBS19%3D176FE4032C; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.3B.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXOSBS19.cpp

//## begin module%3D176FE4032C.additionalIncludes preserve=no
//## end module%3D176FE4032C.additionalIncludes

//## begin module%3D176FE4032C.includes preserve=yes
#include "CXODBS29.hpp"
//## end module%3D176FE4032C.includes

#ifndef CXOSBS19_h
#include "CXODBS19.hpp"
#endif
//## begin module%3D176FE4032C.declarations preserve=no
//## end module%3D176FE4032C.declarations

//## begin module%3D176FE4032C.additionalDeclarations preserve=yes
struct segTextSegment* pSegTextSegment = 0;
#define FIELDS 1
Fields TextSegment_Fields[FIELDS + 1] =
{
   "w         ","TEXT",offsetof(segTextSegment,sText),sizeof(pSegTextSegment->sText),
   "~","~",-1,sizeof(segTextSegment),
};
//## end module%3D176FE4032C.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::TextSegment 

TextSegment::TextSegment()
  //## begin TextSegment::TextSegment%3D176F850138_const.hasinit preserve=no
      : m_pBuffer(0),
        m_iOffset(0)
  //## end TextSegment::TextSegment%3D176F850138_const.hasinit
  //## begin TextSegment::TextSegment%3D176F850138_const.initialization preserve=yes
    ,Segment("S055")
  //## end TextSegment::TextSegment%3D176F850138_const.initialization
{
  //## begin segment::TextSegment::TextSegment%3D176F850138_const.body preserve=yes
   memcpy(m_sID,"BS19",4);
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strText;
  //## end segment::TextSegment::TextSegment%3D176F850138_const.body
}


TextSegment::~TextSegment()
{
  //## begin segment::TextSegment::~TextSegment%3D176F850138_dest.body preserve=yes
   delete [] m_pField;
   delete [] m_pBuffer;
  //## end segment::TextSegment::~TextSegment%3D176F850138_dest.body
}



//## Other Operations (implementation)
struct  Fields* TextSegment::fields () const
{
  //## begin segment::TextSegment::fields%3D176FB100BB.body preserve=yes
   return &TextSegment_Fields[0];
  //## end segment::TextSegment::fields%3D176FB100BB.body
}

short TextSegment::size ()
{
  //## begin segment::TextSegment::size%4EAF0645039F.body preserve=yes
	return sizeof(segTextSegment);
  //## end segment::TextSegment::size%4EAF0645039F.body
}

void TextSegment::writeJSON (const string& strLabel, string& strValue, bool bLast)
{
  //## begin segment::TextSegment::writeJSON%51B9EFE101B7.body preserve=yes
   while(strValue.length() > 0 && strValue[strValue.length()-1] == ' ')
   strValue.resize(strValue.length()-1);
   if((m_iOffset + strLabel.length() + strValue.length() + 17) > 8192)
      return;
   if(m_iOffset == 0)
   {
      m_pBuffer = new char[8192];
      memset(m_pBuffer,' ',8192);
      m_pBuffer[m_iOffset] = '{';
      m_iOffset++;
   }
   if(strLabel == "CUSTOMER")
   {
      memcpy(m_pBuffer+m_iOffset,"\"CUSTOMER\":\"",12);
      m_iOffset+=12;
      memcpy(m_pBuffer+m_iOffset,strValue.data(),strValue.length());
      m_iOffset += strValue.length();
      memcpy(m_pBuffer+m_iOffset,"\",\"FIELDS\":[",12);
      m_iOffset += 12;
   }
   else
   {
      memcpy(m_pBuffer+m_iOffset,"{\"KEY\":\"",8);
      m_iOffset+=8;
      memcpy(m_pBuffer+m_iOffset,strLabel.data(),strLabel.length());
      m_iOffset += strLabel.length();
      memcpy(m_pBuffer+m_iOffset,"\",\"VAL\":\"",9);
      m_iOffset+=9;
      memcpy(m_pBuffer+m_iOffset,strValue.data(),strValue.length());
      m_iOffset += strValue.length();
      memcpy(m_pBuffer+m_iOffset,"\"},",3);
      m_iOffset+=3;
   }
   if(bLast)
   {
      m_iOffset--;
      memcpy(m_pBuffer+m_iOffset,"]}",2);
      m_iOffset+=2;
      m_strText.assign(m_pBuffer,m_iOffset);
      delete [] m_pBuffer;
      m_pBuffer = 0;
      m_iOffset = 0;
   }
  //## end segment::TextSegment::writeJSON%51B9EFE101B7.body
}

// Additional Declarations
  //## begin segment::TextSegment%3D176F850138.declarations preserve=yes
  //## end segment::TextSegment%3D176F850138.declarations

} // namespace segment

//## begin module%3D176FE4032C.epilog preserve=yes
//## end module%3D176FE4032C.epilog
