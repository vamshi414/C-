//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35B63A24012D.cm preserve=no
//	$Date:   18 Jan 2018 14:11:34  $ $Author:   e1009839  $ $Revision:   1.6  $
//## end module%35B63A24012D.cm

//## begin module%35B63A24012D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%35B63A24012D.cp

//## Module: CXOSBS07%35B63A24012D; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS07.hpp

#ifndef CXOSBS07_h
#define CXOSBS07_h 1

//## begin module%35B63A24012D.additionalIncludes preserve=no
//## end module%35B63A24012D.additionalIncludes

//## begin module%35B63A24012D.includes preserve=yes
// $Date:   18 Jan 2018 14:11:34  $ $Author:   e1009839  $ $Revision:   1.6  $
//## end module%35B63A24012D.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;

} // namespace segment

//## begin module%35B63A24012D.declarations preserve=no
//## end module%35B63A24012D.declarations

//## begin module%35B63A24012D.additionalDeclarations preserve=yes
//## end module%35B63A24012D.additionalDeclarations


namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::ListSegment%34609CDE0214.preface preserve=yes
//## end segment::ListSegment%34609CDE0214.preface

//## Class: ListSegment%34609CDE0214
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3918526B02BB;InformationSegment { -> F}

class DllExport ListSegment : public Segment  //## Inherits: <unnamed>%34609CEA03B6
{
  //## begin segment::ListSegment%34609CDE0214.initialDeclarations preserve=yes
  //## end segment::ListSegment%34609CDE0214.initialDeclarations

  public:
    //## Constructors (generated)
      ListSegment();

    //## Destructor (generated)
      ~ListSegment();


    //## Other Operations (specified)
      //## Operation: deport%391836F10126
      virtual int deport (char** ppsBuffer);

      //## Operation: import%391836B60366
      virtual int import (char** ppsBuffer);

      //## Operation: operator char*%3918382D021B
      operator char* () const
      {
        //## begin segment::ListSegment::operator char*%3918382D021B.body preserve=yes
     	return m_pFirstItem;
        //## end segment::ListSegment::operator char*%3918382D021B.body
      }

      //## Operation: read%3950077F01CD
      virtual int read (char** ppsBuffer);

      //## Operation: update%3460A53301C1
      void update (char* psBuffer, int lCount, int lLength);

      //## Operation: write%39520B710071
      virtual int write (char** ppsBuffer);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ItemCount%391832D60319
      int itemCount () const
      {
        //## begin segment::ListSegment::itemCount%391832D60319.get preserve=no
        return m_iItemCount;
        //## end segment::ListSegment::itemCount%391832D60319.get
      }

      void setItemCount (int value)
      {
        //## begin segment::ListSegment::setItemCount%391832D60319.set preserve=no
        m_iItemCount = value;
        //## end segment::ListSegment::setItemCount%391832D60319.set
      }


      //## Attribute: RowSize%3918333103A6
      int getRowSize ()
      {
        //## begin segment::ListSegment::getRowSize%3918333103A6.get preserve=no
        return m_lRowSize;
        //## end segment::ListSegment::getRowSize%3918333103A6.get
      }


    // Additional Public Declarations
      //## begin segment::ListSegment%34609CDE0214.public preserve=yes
      //## end segment::ListSegment%34609CDE0214.public

  protected:
    // Additional Protected Declarations
      //## begin segment::ListSegment%34609CDE0214.protected preserve=yes
      //## end segment::ListSegment%34609CDE0214.protected

  private:
    // Additional Private Declarations
      //## begin segment::ListSegment%34609CDE0214.private preserve=yes
      //## end segment::ListSegment%34609CDE0214.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: FirstItem%39183313030D
      //## begin segment::ListSegment::FirstItem%39183313030D.attr preserve=no  public: char* {V} 0
      char* m_pFirstItem;
      //## end segment::ListSegment::FirstItem%39183313030D.attr

      //## begin segment::ListSegment::ItemCount%391832D60319.attr preserve=no  public: int {V} 0
      int m_iItemCount;
      //## end segment::ListSegment::ItemCount%391832D60319.attr

      //## begin segment::ListSegment::RowSize%3918333103A6.attr preserve=no  public: int {V} 0
      int m_lRowSize;
      //## end segment::ListSegment::RowSize%3918333103A6.attr

    // Additional Implementation Declarations
      //## begin segment::ListSegment%34609CDE0214.implementation preserve=yes
      //## end segment::ListSegment%34609CDE0214.implementation

};

//## begin segment::ListSegment%34609CDE0214.postscript preserve=yes
//## end segment::ListSegment%34609CDE0214.postscript

} // namespace segment

//## begin module%35B63A24012D.epilog preserve=yes
using namespace segment;
//## end module%35B63A24012D.epilog


#endif
