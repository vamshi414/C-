//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%37E79A0F0394.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%37E79A0F0394.cm

//## begin module%37E79A0F0394.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%37E79A0F0394.cp

//## Module: CXOSBS08%37E79A0F0394; Package body
//## Subsystem: BSDLL%394E1F8C0345
//## Source file: C:\Pvcswork\Dn\Server\Library\Bsdll\CXOSBS08.cpp

//## begin module%37E79A0F0394.additionalIncludes preserve=no
//## end module%37E79A0F0394.additionalIncludes

//## begin module%37E79A0F0394.includes preserve=yes
// $Date:   May 14 2020 17:56:12  $ $Author:   e1009510  $ $Revision:   1.7  $
#include <stdio.h>
#include "CXODBS21.hpp"
//## end module%37E79A0F0394.includes

#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBS08_h
#include "CXODBS08.hpp"
#endif


//## begin module%37E79A0F0394.declarations preserve=no
//## end module%37E79A0F0394.declarations

//## begin module%37E79A0F0394.additionalDeclarations preserve=yes
//## end module%37E79A0F0394.additionalDeclarations


//## Modelname: Connex Foundation::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::ListResultsSegment 







ListResultsSegment::ListResultsSegment()
  //## begin ListResultsSegment::ListResultsSegment%37E799D1033B_const.hasinit preserve=no
      : m_lItemCount(0),
        m_lRowSize(0),
        m_pFirstItem(0)
  //## end ListResultsSegment::ListResultsSegment%37E799D1033B_const.hasinit
  //## begin ListResultsSegment::ListResultsSegment%37E799D1033B_const.initialization preserve=yes
   ,Segment("L002")
  //## end ListResultsSegment::ListResultsSegment%37E799D1033B_const.initialization
{
  //## begin segment::ListResultsSegment::ListResultsSegment%37E799D1033B_const.body preserve=yes
   memcpy_s(m_sID,4,"BS08",4);
  //## end segment::ListResultsSegment::ListResultsSegment%37E799D1033B_const.body
}


ListResultsSegment::~ListResultsSegment()
{
  //## begin segment::ListResultsSegment::~ListResultsSegment%37E799D1033B_dest.body preserve=yes
  //## end segment::ListResultsSegment::~ListResultsSegment%37E799D1033B_dest.body
}



//## Other Operations (implementation)
int ListResultsSegment::deport (char** ppsBuffer)
{
  //## begin segment::ListResultsSegment::deport%37E79F2202FC.body preserve=yes
   segListResultsSegment* pSegment = (segListResultsSegment*)*ppsBuffer;
   memset(pSegment,' ',sizeof(segListResultsSegment));
   strncpy(pSegment->sSegmentID,segmentID(),4);
   strncpy(pSegment->sSegmentVersion,"0100",4);
   // length of segment
   char szTemp[9];
   int m = sizeof(segListResultsSegment);
   snprintf(szTemp,sizeof(szTemp),"%08d",m);
   strncpy(pSegment->sLengthOfSegment,szTemp,8);
   strncpy(pSegment->sLengthOfRow,"00000000",8);
   // advance the buffer pointer
   *ppsBuffer += m;
   return 0;
  //## end segment::ListResultsSegment::deport%37E79F2202FC.body
}

int ListResultsSegment::import (char** ppsBuffer)
{
  //## begin segment::ListResultsSegment::import%37E79F260030.body preserve=yes
   segListResultsSegment* pSegment = (segListResultsSegment*)*ppsBuffer;
   // validate segment
   if (strncmp(pSegment->sSegmentVersion,"0100",4))
      return STS_INVALID_VERSION_NUMBER;
   setPresence(true);
   // length of row
   m_lRowSize = atoi(pSegment->sLengthOfRow,8);
   // first item in list
   m_pFirstItem = *ppsBuffer + sizeof(segListResultsSegment);
   // advance the buffer pointer
   *ppsBuffer += atol(pSegment->sLengthOfSegment,8);
   if (m_lRowSize == 0)
      m_lItemCount = 0;
   else
   {  //vericode
      int iSegmentLength = atol(pSegment->sLengthOfSegment, 8);
      int iSizeofSegment = sizeof(segListResultsSegment);
      if(iSegmentLength > 0 && iSegmentLength > iSizeofSegment && m_lRowSize > 0)
         m_lItemCount = (iSegmentLength - iSizeofSegment) / m_lRowSize;
      //m_lItemCount = (atol(pSegment->sLengthOfSegment, 8) - sizeof(segListResultsSegment)) / m_lRowSize;
   }
   return 0;
  //## end segment::ListResultsSegment::import%37E79F260030.body
}

void ListResultsSegment::update (char* psBuffer, int lCount, int lLength)
{
  //## begin segment::ListResultsSegment::update%37E79F2A0145.body preserve=yes
   segListResultsSegment* pSegment = (segListResultsSegment*)psBuffer;
   // update the buffer based on number and size of items in list
   char szTemp[PERCENTD];
   snprintf(szTemp,sizeof(szTemp),"%08d",lLength);
   strncpy(pSegment->sLengthOfSegment,szTemp,8);
   int lLengthOfRow = 0;
   if (lCount > 0)
      lLengthOfRow = (lLength - sizeof(segListResultsSegment)) / lCount;
   snprintf(szTemp,sizeof(szTemp),"%08d",lLengthOfRow);
   strncpy(pSegment->sLengthOfRow,szTemp,8);
  //## end segment::ListResultsSegment::update%37E79F2A0145.body
}

// Additional Declarations
  //## begin segment::ListResultsSegment%37E799D1033B.declarations preserve=yes
  //## end segment::ListResultsSegment%37E799D1033B.declarations

} // namespace segment

//## begin module%37E79A0F0394.epilog preserve=yes
//## end module%37E79A0F0394.epilog
