//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%35B63A260157.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%35B63A260157.cm

//## begin module%35B63A260157.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%35B63A260157.cp

//## Module: CXOSBS07%35B63A260157; Package body
//## Subsystem: BSDLL%394E1F8C0345
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bsdll\CXOSBS07.cpp

//## begin module%35B63A260157.additionalIncludes preserve=no
//## end module%35B63A260157.additionalIncludes

//## begin module%35B63A260157.includes preserve=yes
// $Date:   May 14 2020 17:56:10  $ $Author:   e1009510  $ $Revision:   1.8  $
#include <stdio.h>
#include "CXODBS14.hpp"
//## end module%35B63A260157.includes

#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif


//## begin module%35B63A260157.declarations preserve=no
//## end module%35B63A260157.declarations

//## begin module%35B63A260157.additionalDeclarations preserve=yes
//## end module%35B63A260157.additionalDeclarations


//## Modelname: Connex Foundation::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::ListSegment 


































ListSegment::ListSegment()
  //## begin ListSegment::ListSegment%34609CDE0214_const.hasinit preserve=no
      : m_pFirstItem(0),
        m_iItemCount(0),
        m_lRowSize(0)
  //## end ListSegment::ListSegment%34609CDE0214_const.hasinit
  //## begin ListSegment::ListSegment%34609CDE0214_const.initialization preserve=yes
   ,Segment("L001")
  //## end ListSegment::ListSegment%34609CDE0214_const.initialization
{
  //## begin segment::ListSegment::ListSegment%34609CDE0214_const.body preserve=yes
   setSize(sizeof(segListSegment));
  //## end segment::ListSegment::ListSegment%34609CDE0214_const.body
}


ListSegment::~ListSegment()
{
  //## begin segment::ListSegment::~ListSegment%34609CDE0214_dest.body preserve=yes
  //## end segment::ListSegment::~ListSegment%34609CDE0214_dest.body
}



//## Other Operations (implementation)
int ListSegment::deport (char** ppsBuffer)
{
  //## begin segment::ListSegment::deport%391836F10126.body preserve=yes
   segListSegment* pSegment = (segListSegment*)*ppsBuffer;
   memset(pSegment,' ',sizeof(segListSegment));
   memcpy_s(pSegment->sSegmentID,4,(char*) segmentID(),4);
   memcpy_s(pSegment->sSegmentVersion,4,"0100",4);
   // length of segment
   char szTemp[9];
   int m = sizeof(segListSegment);
   snprintf(szTemp,sizeof(szTemp),"%08d",m);
   memcpy_s(pSegment->sLengthOfSegment,8,szTemp,8);
   memcpy_s(pSegment->sItemCount,4,"0000",4);
   // advance the buffer pointer
   *ppsBuffer += m;
   return 0;  
  //## end segment::ListSegment::deport%391836F10126.body
}

int ListSegment::import (char** ppsBuffer)
{
  //## begin segment::ListSegment::import%391836B60366.body preserve=yes
   segListSegment* pSegment = (segListSegment*)*ppsBuffer;
   // validate segment
   if (strncmp(pSegment->sSegmentVersion,"0100",4))
      return STS_INVALID_VERSION_NUMBER;
   setPresence(true);
   // item count
   m_iItemCount = atoi(pSegment->sItemCount,4);
   // first item in list
   m_pFirstItem = *ppsBuffer + sizeof(segListSegment);
   // advance the buffer pointer
   *ppsBuffer += atol(pSegment->sLengthOfSegment,8);
   if (m_iItemCount == 0)
      m_lRowSize = 0;
   else
      m_lRowSize = (atol(pSegment->sLengthOfSegment,8) - 26) / m_iItemCount;
   return 0;
  //## end segment::ListSegment::import%391836B60366.body
}

int ListSegment::read (char** ppsBuffer)
{
  //## begin segment::ListSegment::read%3950077F01CD.body preserve=yes
   return import(ppsBuffer);
  //## end segment::ListSegment::read%3950077F01CD.body
}

void ListSegment::update (char* psBuffer, int lCount, int lLength)
{
  //## begin segment::ListSegment::update%3460A53301C1.body preserve=yes
   segListSegment* pSegment = (segListSegment*)psBuffer;
   // update the buffer based on number and size of items in list
   char szTemp[PERCENTD];
   snprintf(szTemp,sizeof(szTemp),"%08d",lLength);
   memcpy_s(pSegment->sLengthOfSegment,8,szTemp,8);
   m_iItemCount = lCount;
   snprintf(szTemp,sizeof(szTemp),"%04d",lCount);
   memcpy_s(pSegment->sItemCount,4,szTemp,4);
  //## end segment::ListSegment::update%3460A53301C1.body
}

int ListSegment::write (char** ppsBuffer)
{
  //## begin segment::ListSegment::write%39520B710071.body preserve=yes
   memcpy_s(*ppsBuffer,4,(char*)segmentID(),4);
   *ppsBuffer += 4;
   return deport(ppsBuffer);
  //## end segment::ListSegment::write%39520B710071.body
}

// Additional Declarations
  //## begin segment::ListSegment%34609CDE0214.declarations preserve=yes
  //## end segment::ListSegment%34609CDE0214.declarations

} // namespace segment

//## begin module%35B63A260157.epilog preserve=yes
//## end module%35B63A260157.epilog
