//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%51C352D20180.cm preserve=no
//	$Date:   May 19 2020 10:41:12  $ $Author:   e5579974  $ $Revision:   1.14  $
//## end module%51C352D20180.cm

//## begin module%51C352D20180.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%51C352D20180.cp

//## Module: CXOSBS27%51C352D20180; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.4B.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXOSBS27.cpp

//## begin module%51C352D20180.additionalIncludes preserve=no
//## end module%51C352D20180.additionalIncludes

//## begin module%51C352D20180.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#ifndef CXOSBS13_h
#include "CXODBS13.hpp"
#endif
#ifndef CXOSBS14_h
#include "CXODBS14.hpp"
#endif
#ifndef CXOSBS20_h
#include "CXODBS20.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif

//## end module%51C352D20180.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU07_h
#include "CXODRU07.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSBS28_h
#include "CXODBS28.hpp"
#endif
#ifndef CXOSIF48_h
#include "CXODIF48.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSRU37_h
#include "CXODRU37.hpp"
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif


//## begin module%51C352D20180.declarations preserve=no
//## end module%51C352D20180.declarations

//## begin module%51C352D20180.additionalDeclarations preserve=yes
#define STS_DUPLICATE_RECORD 35
//## end module%51C352D20180.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::AuditEvent

AuditEvent::AuditEvent()
  //## begin AuditEvent::AuditEvent%51C3523501DC_const.hasinit preserve=no
      : m_lSEQ_NO(0)
  //## end AuditEvent::AuditEvent%51C3523501DC_const.hasinit
  //## begin AuditEvent::AuditEvent%51C3523501DC_const.initialization preserve=yes
  //## end AuditEvent::AuditEvent%51C3523501DC_const.initialization
{
  //## begin segment::AuditEvent::AuditEvent%51C3523501DC_const.body preserve=yes
   Message::instance(Message::INBOUND)->attach(this);
  //## end segment::AuditEvent::AuditEvent%51C3523501DC_const.body
}


AuditEvent::~AuditEvent()
{
  //## begin segment::AuditEvent::~AuditEvent%51C3523501DC_dest.body preserve=yes
   Message::instance(Message::INBOUND)->detach(this);
  //## end segment::AuditEvent::~AuditEvent%51C3523501DC_dest.body
}



//## Other Operations (implementation)
void AuditEvent::captureEvent (const IF::Message& hMessage, const string& strCommand)
{
  //## begin segment::AuditEvent::captureEvent%51CA3D060123.body preserve=yes
   hGDMHeader* pGDMHeader = (hGDMHeader*)(char*)hMessage.buffer();
   if (memcmp(pGDMHeader->sReferenceNumber,"00000000",8) == 0 
      && strCommand != "QUIESCE")
      return; //not issued from console operator
   if (pGDMHeader->sDate[0] == '0')
      m_hAuditEventSegment.setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
   else
      m_hAuditEventSegment.setTSTAMP_CREATED(string(pGDMHeader->sDate,8) + string(pGDMHeader->sTime,6) + "00");
   m_lSEQ_NO = m_strLastTstamp == m_hAuditEventSegment.getTSTAMP_CREATED() ? ++m_lSEQ_NO : 1;
   m_strLastTstamp = m_hAuditEventSegment.getTSTAMP_CREATED();
   m_hAuditEventSegment.setSEQ_NO(m_lSEQ_NO);
   m_hAuditEventSegment.setEVENT_TYPE(ADMIN_ACTION + OPERATOR_COMMAND);
   m_hAuditEventSegment.setCUST_ID(m_strCUST_ID);
   string strUSER_ID(pGDMHeader->sReferenceNumber,8);
   if (strUSER_ID == "00000000")
   {
      m_hAuditEventSegment.setUSER_ID(m_strUSER_ID);
      m_hAuditEventSegment.setORIGINATION(m_strHostName);
   }
   else
   {
      m_hAuditEventSegment.setUSER_ID(strUSER_ID);
      m_hAuditEventSegment.setORIGINATION("CONSOLE");
   }
   m_hAuditEventSegment.setTASKID(m_strTASKID);
   m_hAuditEventSegment.setRESOURCE_NAME(strCommand);
   m_hAuditEventSegment.setRESOURCE_KEY(string(hMessage.context()));
   if (m_strTASKID == "MMC    ")
   {
      size_t pos = strCommand.find_last_of("+");
      if (pos != string::npos)
      {
         m_hAuditEventSegment.setRESOURCE_NAME(strCommand.substr(0,pos));
         m_hAuditEventSegment.setRESOURCE_KEY(strCommand.substr(pos+1));
      }
   }
   commitEvent(true);
  //## end segment::AuditEvent::captureEvent%51CA3D060123.body
}

void AuditEvent::captureEvent (const string& strTableName, const string& strSearchCondition, const string& strPredicates)
{
  //## begin segment::AuditEvent::captureEvent%51E4207002FF.body preserve=yes
   if (m_hTables.size() == 0 || strTableName == "AUDIT_EVENT")
      return;
   map<string,vector<string>,less<string> >::iterator p;
   p = m_hTables.find(strTableName);
   if (p == m_hTables.end())
      return;
   m_hAuditEventSegment.setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
   m_lSEQ_NO = m_strLastTstamp == m_hAuditEventSegment.getTSTAMP_CREATED() ? ++m_lSEQ_NO : 1;
   m_strLastTstamp = m_hAuditEventSegment.getTSTAMP_CREATED();
   m_hAuditEventSegment.setSEQ_NO(m_lSEQ_NO);
   m_hAuditEventSegment.setEVENT_TYPE(ADMIN_ACTION + DEL);
   m_hAuditEventSegment.setCUST_ID(m_strCUST_ID);
   m_hAuditEventSegment.setUSER_ID(m_strUSER_ID);
   m_hAuditEventSegment.setTASKID(m_strTASKID);
   m_hAuditEventSegment.setORIGINATION(m_strHostName);
   m_hAuditEventSegment.setRESOURCE_NAME(strTableName);
   vector<string> hTokens;
   Buffer::parse(strPredicates,",",hTokens);
   string strRESOURCE_KEY = strSearchCondition;
   size_t pos = strRESOURCE_KEY.find_first_of('?');
   int i = 0;
   while (pos != string::npos && i < hTokens.size())
   {
      strRESOURCE_KEY.replace(pos,1,hTokens[i++]);
      pos = strRESOURCE_KEY.find_first_of('?');
   }
   m_hAuditEventSegment.setRESOURCE_KEY(strRESOURCE_KEY);
   commitEvent(false);
  //## end segment::AuditEvent::captureEvent%51E4207002FF.body
}

void AuditEvent::captureEvent (const IF::Message& hMessage)
{
  //## begin segment::AuditEvent::captureEvent%51C868360087.body preserve=yes
   if (memcmp(Message::instance(Message::INBOUND)->buffer(), "TIMEOUT", 7) == 0 
      || hMessage.getSource() == "HTTP")
      return;
   char szLength[9] = {"        "};
   char* psBuffer = hMessage.data() + 8;
   char* pEndOfMessage = hMessage.data() + hMessage.dataLength();
   if (memcmp(psBuffer,"S001",4) != 0)
      return;
   m_hAuditEventSegment.setEVENT_TYPE(0);
   struct segCommonHeaderSegment* pCommonHeaderSegment = (struct segCommonHeaderSegment*)psBuffer;
   char cType = pCommonHeaderSegment->sServiceName[0];
   string strServiceName(pCommonHeaderSegment->sServiceName+1,7);
   map<string,string,less<string> >::iterator q;
   if((q = m_hServices.find(strServiceName)) == m_hServices.end())
      return;
   m_hAuditEventSegment.setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
   m_hAuditEventSegment.setEVENT_TYPE(CARDHOLDER_DATA);
   if (strServiceName.substr(0,4) == "LOGO")
   {
      if (cType == 'Q')
         return; //Userid not available until Reply
      m_hAuditEventSegment.setEVENT_TYPE(APPLICATION_ID);
   }
   else
      m_hAuditEventSegment.setEVENT_TYPE(CARDHOLDER_DATA);
   m_lSEQ_NO = m_strLastTstamp == m_hAuditEventSegment.getTSTAMP_CREATED() ? ++m_lSEQ_NO : 1;
   m_strLastTstamp = m_hAuditEventSegment.getTSTAMP_CREATED();
   m_hAuditEventSegment.setSEQ_NO(m_lSEQ_NO);
   m_hAuditEventSegment.setCUST_ID(m_strCUST_ID);
   m_hAuditEventSegment.setUSER_ID(string(pCommonHeaderSegment->sSecurityData,8));
   m_hAuditEventSegment.setTASKID(m_strTASKID);
   m_hAuditEventSegment.setRETURN_CODE(0);
   m_hAuditEventSegment.setORIGINATION(strServiceName);
   m_hAuditEventSegment.setRESOURCE_NAME((*q).second);
   string strRESOURCE_KEY(" ");
   memcpy(szLength,psBuffer + 8,8);
   psBuffer += atoi(szLength);
   if (cType == 'Q')
   {
      while (psBuffer < pEndOfMessage)
      {
         if (memcmp(psBuffer,"S101",4) == 0)
         {
            memcpy(szLength,psBuffer + 8,8);
            int iLen = atoi(szLength)-16 >= 0 ? atoi(szLength) - 16 : 0;
            if (strServiceName == "EMRCHDR" || strServiceName == "EMUCHDR")
            {
               char* buffer = new char[iLen];
               memcpy(buffer,psBuffer+16,(unsigned int)iLen);
               Mask::maskPan(buffer,iLen);
               strRESOURCE_KEY.append(buffer,iLen);
               delete [] buffer;
            }
            else
               strRESOURCE_KEY.append(psBuffer+16,iLen);
            break;
         }
         else
         if (memcmp(psBuffer,"L001",4) == 0)
         {
            psBuffer += sizeof(struct segListSegment);
            continue;
         }
         else
         if (memcmp(psBuffer,"S220",4) == 0)
         {
            memcpy(szLength,psBuffer + 8,8);
            string strBuffer(psBuffer+16,atoi(szLength)-16);
            vector<string> hTokens;
            Buffer::parse(strBuffer," ",hTokens);
            for(int i = 0; i < hTokens.size(); i++)
            {
               if (hTokens[i].length() > 0)
               {
                  strRESOURCE_KEY.append(hTokens[i].data(),hTokens[i].length());
                  strRESOURCE_KEY.append(",");
               }
            }
         }
         memcpy(szLength,psBuffer + 8,8);
         psBuffer += atoi(szLength);
      }
   }
   else if (cType == 'R')
   {
      //search for Error condition in S052
      while (psBuffer < pEndOfMessage)
      {
         if (memcmp(psBuffer,"S052",4) == 0)
         {
            struct segInformationSegment* pInformationSegment = (struct segInformationSegment*)psBuffer;
            m_hAuditEventSegment.setRETURN_CODE(atoi(string(pInformationSegment->sErrorNumber,8).c_str()));
            break;
         }
         memcpy(szLength,psBuffer + 8,8);
         psBuffer += atoi(szLength);
      }
   }
   if (strRESOURCE_KEY.length() > 2048)
      strRESOURCE_KEY.resize(2048);
   //mask PANs
   int iOffset = 0;
   if ((iOffset = strRESOURCE_KEY.find("PAN,IN,")) != string::npos)
   {  // FIN_LOCATOR,PAN,IN,0077('4531098278784536','4531098278784537','4531098278784538','4531098278784539'),...
      int iINLength = atoi(strRESOURCE_KEY.substr(iOffset+7,4).c_str());
      int iStart = iOffset+13;
      while(iStart < strRESOURCE_KEY.length() && iStart < iOffset+11+iINLength)
      {
         int iEnd = strRESOURCE_KEY.find("'",iStart);
         int iLength = (iEnd != string::npos) ? iEnd-iStart:strRESOURCE_KEY.length()-iStart;
         int iReplaceLength = (iLength > 10) ? iLength-10:iLength-6;
         strRESOURCE_KEY.replace(iStart+6,iReplaceLength,iReplaceLength,'*');
         iStart += iLength+3;
      }
   }
   else if ((iOffset = strRESOURCE_KEY.find("PAN,=,")) != string::npos)
   {  // FIN_LOCATOR,PAN,=,0018'4534079082443236',...
      int iLength = atoi(strRESOURCE_KEY.substr(iOffset+6,4).c_str())-2;
      int iStart = iOffset+11;
      if (iStart + iLength > strRESOURCE_KEY.length())
         iLength = strRESOURCE_KEY.length()-iStart;
      int iReplaceLength = (iLength > 10) ? iLength-10:iLength-6;
      strRESOURCE_KEY.replace(iStart+6,iReplaceLength,iReplaceLength,'*');
   }
   else if ((iOffset = strRESOURCE_KEY.find("PAN,LIKE,")) != string::npos)
   {  // FIN_LOCATOR,PAN,LIKE,0013'4531627832%',...
      int iLength = atoi(strRESOURCE_KEY.substr(iOffset+9,4).c_str())-3;
      if (iLength > 6)
      {
         int iStart = iOffset+14;
         if (iStart + iLength > strRESOURCE_KEY.length())
            iLength = strRESOURCE_KEY.length()-iStart;
         strRESOURCE_KEY.replace(iStart+6,iLength-6,iLength-6,'*');
      }
   }
   m_hAuditEventSegment.setRESOURCE_KEY(strRESOURCE_KEY);
   commitEvent(false);
  //## end segment::AuditEvent::captureEvent%51C868360087.body
}

void AuditEvent::captureEvent (reusable::Table& hTable, short sEventType)
{
  //## begin segment::AuditEvent::captureEvent%51C48AC5038D.body preserve=yes
   if (database::AuditEvent::ADMIN_ACTION > SHRT_MAX - sEventType 
      || m_hTables.size() == 0 
      || hTable.getName() == "AUDIT_EVENT"
      || m_hTables.find(hTable.getName()) == m_hTables.end())
      return;
   map<string, Column, less<string> >& hColumns = hTable.getColumn();
   map<string, Column, less<string> >::iterator q;
   if (hTable.getName() == "CRCHGET"
      && (q = hColumns.find("TABLEID")) != hColumns.end()
      && m_hTables.find((*q).second.getValue()) == m_hTables.end())
      return;
   m_hAuditEventSegment.setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
   m_lSEQ_NO = m_strLastTstamp == m_hAuditEventSegment.getTSTAMP_CREATED() ?  ++m_lSEQ_NO : 1;
   m_strLastTstamp = m_hAuditEventSegment.getTSTAMP_CREATED();
   m_hAuditEventSegment.setSEQ_NO(m_lSEQ_NO);
   m_hAuditEventSegment.setEVENT_TYPE(database::AuditEvent::ADMIN_ACTION + sEventType);
   m_hAuditEventSegment.setCUST_ID(m_strCUST_ID);
   m_hAuditEventSegment.setUSER_ID(m_strUSER_ID);
   m_hAuditEventSegment.setTASKID(m_strTASKID);
   m_hAuditEventSegment.setORIGINATION(m_strHostName);
   m_hAuditEventSegment.setRESOURCE_NAME(hTable.getName());
   string strRESOURCE_KEY;
   map<string, vector<string>, less<string> >::iterator p;
   p = m_hTables.find(hTable.getName());
   for(int i = 0; i < (*p).second.size(); i++)
   {
      if((q = hColumns.find((*p).second[i])) != hColumns.end())
         strRESOURCE_KEY.append((*q).second.getValue());
      strRESOURCE_KEY.append("~");
   }
   if (strRESOURCE_KEY.length() > 0)
      strRESOURCE_KEY.resize(strRESOURCE_KEY.length()-1);
   else
      strRESOURCE_KEY.assign(" ");
   m_hAuditEventSegment.setRESOURCE_KEY(strRESOURCE_KEY);
   commitEvent(false);
  //## end segment::AuditEvent::captureEvent%51C48AC5038D.body
}

void AuditEvent::captureEvent (const string& strUSER_ID, short sEVENT_TYPE, short sRETURN_CODE, const string& strRESOURCE_NAME, const string& strRESOURCE_KEY)
{
  //## begin segment::AuditEvent::captureEvent%524C43A902E6.body preserve=yes
   m_hAuditEventSegment.setTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
   m_lSEQ_NO = m_strLastTstamp == m_hAuditEventSegment.getTSTAMP_CREATED() ? ++m_lSEQ_NO : 1;
   m_strLastTstamp = m_hAuditEventSegment.getTSTAMP_CREATED();
   m_hAuditEventSegment.setSEQ_NO(m_lSEQ_NO);
   m_hAuditEventSegment.setEVENT_TYPE(sEVENT_TYPE);
   m_hAuditEventSegment.setRETURN_CODE(sRETURN_CODE);
   m_hAuditEventSegment.setCUST_ID(m_strCUST_ID);
   if (!strUSER_ID.empty())
      m_hAuditEventSegment.setUSER_ID(strUSER_ID);
   else
      m_hAuditEventSegment.setUSER_ID(m_strUSER_ID);
   m_hAuditEventSegment.setTASKID(m_strTASKID);
   m_hAuditEventSegment.setORIGINATION(m_strHostName);
   m_hAuditEventSegment.setRESOURCE_NAME(strRESOURCE_NAME);
   m_hAuditEventSegment.setRESOURCE_KEY(strRESOURCE_KEY);
   commitEvent(false);
  //## end segment::AuditEvent::captureEvent%524C43A902E6.body
}

bool AuditEvent::commitEvent (bool bCommit)
{
  //## begin segment::AuditEvent::commitEvent%51DB310B010A.body preserve=yes
   if (m_hAuditEventSegment.getEVENT_TYPE() == 0)
      return true;
   bool bReturn = true;
   Table hTable;
   m_hAuditEventSegment.setColumns(hTable);
   auto_ptr<reusable::Statement> pInsertStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("InsertStatement"));
   if (pInsertStatement->execute(hTable) == false)
   {
      if (pInsertStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
      {
         unsigned int uiSize = 58 + 9 + 1 +                     //static values + # of commas + 1 for null terminator
            m_hAuditEventSegment.getRESOURCE_NAME().length() +
            m_hAuditEventSegment.getRESOURCE_KEY().length() +
            m_hAuditEventSegment.getORIGINATION().length();
         char* pszBuffer = new  char[uiSize];
         Trace::put("Audit Event Failure", -1, true);
         Trace::put("INSERT INTO AUDIT_EVENT(TSTAMP_CREATED,TASKID,SEQ_NO,CUST_ID,USER_ID,EVENT_TYPE,RETURN_CODE,ORIGINATION,RESOURCE_NAME,RESOURCE_KEY)", -1, true);
         Trace::put(pszBuffer, snprintf(pszBuffer, uiSize, "Values(%s,%s,%d,%s,%s,%d,%d,%s,%s,%s)",
            m_hAuditEventSegment.getTSTAMP_CREATED().c_str(),
            m_hAuditEventSegment.getTASKID().c_str(),
            m_hAuditEventSegment.getSEQ_NO(),
            m_hAuditEventSegment.getCUST_ID().c_str(),
            m_hAuditEventSegment.getUSER_ID().c_str(),
            m_hAuditEventSegment.getEVENT_TYPE(),
            m_hAuditEventSegment.getRETURN_CODE(),
            m_hAuditEventSegment.getORIGINATION().c_str(),
            m_hAuditEventSegment.getRESOURCE_NAME().c_str(),
            m_hAuditEventSegment.getRESOURCE_KEY().c_str()), true);
         delete [] pszBuffer;
         Console::display("CX000","AUDIT ALERT: INSERT FAILED - SEE TRACE FOR DETAILS");
         bReturn = false;
      }
   }
   m_hAuditEventSegment.setEVENT_TYPE(0);
   if (bCommit)
      return Database::instance()->commit();
   return bReturn;
  //## end segment::AuditEvent::commitEvent%51DB310B010A.body
}

bool AuditEvent::load ()
{
  //## begin segment::AuditEvent::load%51C354680098.body preserve=yes
   m_strTASKID = Application::instance()->name();
   Query hQuery;
   hQuery.setQualifier("QUALIFY","AUDIT_EVENT");
   hQuery.bind("AUDIT_EVENT","TSTAMP_CREATED",Column::STRING,&m_strLastTstamp,0,"MAX");
   hQuery.setBasicPredicate("AUDIT_EVENT","TASKID","=",m_strTASKID.c_str());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   if (!m_strLastTstamp.empty())
   {
      hQuery.reset();
      hQuery.setQualifier("QUALIFY","AUDIT_EVENT");
      hQuery.bind("AUDIT_EVENT","SEQ_NO",Column::LONG,&m_lSEQ_NO,0,"MAX");
      hQuery.setBasicPredicate("AUDIT_EVENT","TSTAMP_CREATED","=",m_strLastTstamp.c_str());
      hQuery.setBasicPredicate("AUDIT_EVENT","TASKID","=",m_strTASKID.c_str());
      if (!pSelectStatement->execute(hQuery))
         return false;
   }
   Extract::instance()->getSpec("CUSTOMER",m_strCUST_ID);
   Extract::instance()->getSpec("USERID",m_strUSER_ID);
   AdvancedEncryptionStandard::decrypt(m_strUSER_ID);
   m_strHostName = Extract::instance()->getHost();
   //read template to see which tables to monitor
   string strTemplate("CXOXPADS");
#ifdef MVS
   string strMember(strTemplate);
   strMember.replace(0,4,"DN##",4);
   FlatFile hFlatFile("JCL",strMember.c_str());
#else
   FlatFile hFlatFile("SOURCE",strTemplate.c_str());
#endif
   char sBuffer[256];
   size_t m = 0;
   vector<string> hTokens;
   vector<string> hVector;
   pair<map<string,vector<string>,less<string> >::iterator,bool> hResult;
   int i = 0;
   while (hFlatFile.read(sBuffer,256,&m))
   {
      i = Buffer::parse(string(sBuffer,m),",",hTokens);
      if (i > 0)
      {
         hResult = m_hTables.insert(map<string,vector<string>,less<string> >::value_type(hTokens[0],hVector));
         for (int j = 1; j<i; j++)
            (*hResult.first).second.push_back(hTokens[j]);
      }
   }
   //load service names that have PADSS logging implications
   m_hServices.insert(map<string,string,less<string> >::value_type("AULTRAN","AU_TRAN"));
   m_hServices.insert(map<string,string,less<string> >::value_type("AUTRDTL","AU_TRAN"));
   m_hServices.insert(map<string,string,less<string> >::value_type("AUTTRAN","AU_TRAN"));
   m_hServices.insert(map<string,string,less<string> >::value_type("DNLFTRN","FINANCIAL RECORD"));
   m_hServices.insert(map<string,string,less<string> >::value_type("DNLHIGH","FINANCIAL RECORD"));
   m_hServices.insert(map<string,string,less<string> >::value_type("DNLTRAN","FINANCIAL RECORD"));
   m_hServices.insert(map<string,string,less<string> >::value_type("DNRPAUT","FINANCIAL RECORD"));
   m_hServices.insert(map<string,string,less<string> >::value_type("SUMTRAN","FINANCIAL RECORD"));
   m_hServices.insert(map<string,string,less<string> >::value_type("TRANALL","FINANCIAL RECORD"));
   m_hServices.insert(map<string,string,less<string> >::value_type("TRNDTL","FINANCIAL RECORD"));
   m_hServices.insert(map<string,string,less<string> >::value_type("DNCBTCH","EMS_CASE"));
   m_hServices.insert(map<string,string,less<string> >::value_type("EMCCASE","EMS_CASE"));
   m_hServices.insert(map<string,string,less<string> >::value_type("EMLCASE","EMS_CASE"));
   m_hServices.insert(map<string,string,less<string> >::value_type("EMLHIGH","EMS_CASE"));
   m_hServices.insert(map<string,string,less<string> >::value_type("EMUCASE","EMS_CASE"));
   m_hServices.insert(map<string,string,less<string> >::value_type("EMRCASE","EMS_CASE"));
   m_hServices.insert(map<string,string,less<string> >::value_type("RELCASE","EMS_CASE"));
   m_hServices.insert(map<string,string,less<string> >::value_type("EMRCHDR","CARDHOLDER"));
   m_hServices.insert(map<string,string,less<string> >::value_type("EMUCHDR","CARDHOLDER"));
   m_hServices.insert(map<string,string,less<string> >::value_type("LOGON  ","ACCESS SECURITY"));
   m_hServices.insert(map<string,string,less<string> >::value_type("LOGOFF ","ACCESS SECURITY"));
   return true;
  //## end segment::AuditEvent::load%51C354680098.body
}

void AuditEvent::update (Subject* pSubject)
{
  //## begin segment::AuditEvent::update%51CA0CA6002A.body preserve=yes
   if (pSubject == Message::instance(Message::INBOUND))
   {
      Message hMessage = *Message::instance(Message::INBOUND);
      switch (hMessage.type())
      {
         case APPLICATION:
            captureEvent(hMessage);
            break;
         case RESET:
            captureEvent(hMessage,"RESET");
         case TRACE:
            if (hMessage.context() == "OFF")
               captureEvent(hMessage,"TRACE OFF");
            else
            if ((hMessage.context() == "ON") 
               || (hMessage.context().length() == 0))
               captureEvent(hMessage,"TRACE ON");
            break;
         case REFRESH:
            captureEvent(hMessage,"REFRESH");
            break;
         case QUIESCE:
            captureEvent(hMessage,"QUIESCE");
            break;
         case SHUTDOWN:
            captureEvent(hMessage,"SHUTDOWN");
            break;
         case START:
            captureEvent(hMessage,"START");
            break;
         case STARTWTR:
            captureEvent(hMessage,"STARTWTR");
            break;
      }
   }
  //## end segment::AuditEvent::update%51CA0CA6002A.body
}

// Additional Declarations
  //## begin segment::AuditEvent%51C3523501DC.declarations preserve=yes
  //## end segment::AuditEvent%51C3523501DC.declarations

} // namespace segment

//## begin module%51C352D20180.epilog preserve=yes
//## end module%51C352D20180.epilog
