//	Copyright (c) 1998 - 2024
//	FIS

#ifndef CXODBS13_HPP
#define CXODBS13_HPP

struct segCommonHeaderSegment
{
   char sSegmentID[4];                    // 0000 - 'S001'
   char sSegmentVersion[4];               // 0004 - '0100'
   char sLengthOfSegment[8];              // 0008 - '00000160'
   char sServiceName[8];                  // 0016
   char sSecurityData[64];                // 0024
   char sExternalContextData[32];         // 0088
   char sResultCode[3];                   // 0120
   char sClientVersion[8];                // 0123 yyyymmdd version of web client
   char sCUST_ID[4];                      // 0131 transaction source
   char cSource;                          // 0135
   char sReserved[24];                    // 0136 - ' '
};

#endif

