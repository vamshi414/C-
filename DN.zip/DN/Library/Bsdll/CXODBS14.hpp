//	Copyright (c) 1998 - 2004
//	eFunds Corporation
// $Date:   Apr 08 2004 10:49:22  $ $Author:   D02405  $ $Revision:   1.2  $

struct segListSegment
{
   char sSegmentID[4];
   char sSegmentVersion[4];
   char sLengthOfSegment[8];
   char sItemCount[4];
   char sReserved[6];
};
