//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3920346C0276.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3920346C0276.cm

//## begin module%3920346C0276.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3920346C0276.cp

//## Module: CXOSBS03%3920346C0276; Package specification
//## Subsystem: BSDLL%394E1F8C0345
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bsdll\CXODBS03.hpp

#ifndef CXOSBS03_h
#define CXOSBS03_h 1

//## begin module%3920346C0276.additionalIncludes preserve=no
//## end module%3920346C0276.additionalIncludes

//## begin module%3920346C0276.includes preserve=yes
// $Date:   Jun 30 2006 11:35:16  $ $Author:   D02405  $ $Revision:   1.4  $
//## end module%3920346C0276.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%3920346C0276.declarations preserve=no
//## end module%3920346C0276.declarations

//## begin module%3920346C0276.additionalDeclarations preserve=yes
//## end module%3920346C0276.additionalDeclarations


//## Modelname: Connex Foundation::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::SegmentVersion%392051780337.preface preserve=yes
//## end segment::SegmentVersion%392051780337.preface

//## Class: SegmentVersion%392051780337
//## Category: Connex Foundation::Segment_CAT%3471F0BE0219
//## Subsystem: BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class DllExport SegmentVersion : public reusable::Object  //## Inherits: <unnamed>%39205190004C
{
  //## begin segment::SegmentVersion%392051780337.initialDeclarations preserve=yes
  //## end segment::SegmentVersion%392051780337.initialDeclarations

  public:
    //## Constructors (generated)
      SegmentVersion();

      SegmentVersion(const SegmentVersion &right);

    //## Constructors (specified)
      //## Operation: SegmentVersion%392051DC0146
      SegmentVersion (const char* pszVersion, const char* pszClientMU, const int lLastOffset, const int lStructLen);

    //## Destructor (generated)
      virtual ~SegmentVersion();

    //## Assignment Operation (generated)
      SegmentVersion & operator=(const SegmentVersion &right);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ClientMU%392051BB012A
      const string& getClientMU () const
      {
        //## begin segment::SegmentVersion::getClientMU%392051BB012A.get preserve=no
        return m_strClientMU;
        //## end segment::SegmentVersion::getClientMU%392051BB012A.get
      }

      void setClientMU (const string& value)
      {
        //## begin segment::SegmentVersion::setClientMU%392051BB012A.set preserve=no
        m_strClientMU = value;
        //## end segment::SegmentVersion::setClientMU%392051BB012A.set
      }


      //## Attribute: LastOffset%392051C1015B
      const int getLastOffset () const
      {
        //## begin segment::SegmentVersion::getLastOffset%392051C1015B.get preserve=no
        return m_lLastOffset;
        //## end segment::SegmentVersion::getLastOffset%392051C1015B.get
      }

      void setLastOffset (int value)
      {
        //## begin segment::SegmentVersion::setLastOffset%392051C1015B.set preserve=no
        m_lLastOffset = value;
        //## end segment::SegmentVersion::setLastOffset%392051C1015B.set
      }


      //## Attribute: StructLen%392051CC0175
      const int getStructLen () const
      {
        //## begin segment::SegmentVersion::getStructLen%392051CC0175.get preserve=no
        return m_lStructLen;
        //## end segment::SegmentVersion::getStructLen%392051CC0175.get
      }

      void setStructLen (int value)
      {
        //## begin segment::SegmentVersion::setStructLen%392051CC0175.set preserve=no
        m_lStructLen = value;
        //## end segment::SegmentVersion::setStructLen%392051CC0175.set
      }


      //## Attribute: Version%392051AF00E7
      const string& getVersion () const
      {
        //## begin segment::SegmentVersion::getVersion%392051AF00E7.get preserve=no
        return m_strVersion;
        //## end segment::SegmentVersion::getVersion%392051AF00E7.get
      }

      void setVersion (const string& value)
      {
        //## begin segment::SegmentVersion::setVersion%392051AF00E7.set preserve=no
        m_strVersion = value;
        //## end segment::SegmentVersion::setVersion%392051AF00E7.set
      }


    // Data Members for Class Attributes

      //## begin segment::SegmentVersion::ClientMU%392051BB012A.attr preserve=no  public: string {V} 
      string m_strClientMU;
      //## end segment::SegmentVersion::ClientMU%392051BB012A.attr

      //## begin segment::SegmentVersion::LastOffset%392051C1015B.attr preserve=no  public: int {V} 0
      int m_lLastOffset;
      //## end segment::SegmentVersion::LastOffset%392051C1015B.attr

      //## begin segment::SegmentVersion::StructLen%392051CC0175.attr preserve=no  public: int {V} 0
      int m_lStructLen;
      //## end segment::SegmentVersion::StructLen%392051CC0175.attr

      //## begin segment::SegmentVersion::Version%392051AF00E7.attr preserve=no  public: string {V} 
      string m_strVersion;
      //## end segment::SegmentVersion::Version%392051AF00E7.attr

    // Additional Public Declarations
      //## begin segment::SegmentVersion%392051780337.public preserve=yes
      //## end segment::SegmentVersion%392051780337.public

  protected:
    // Additional Protected Declarations
      //## begin segment::SegmentVersion%392051780337.protected preserve=yes
      //## end segment::SegmentVersion%392051780337.protected

  private:
    // Additional Private Declarations
      //## begin segment::SegmentVersion%392051780337.private preserve=yes
      //## end segment::SegmentVersion%392051780337.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin segment::SegmentVersion%392051780337.implementation preserve=yes
      //## end segment::SegmentVersion%392051780337.implementation

};

//## begin segment::SegmentVersion%392051780337.postscript preserve=yes
//## end segment::SegmentVersion%392051780337.postscript

} // namespace segment

//## begin module%3920346C0276.epilog preserve=yes
using namespace segment;
//## end module%3920346C0276.epilog


#endif
