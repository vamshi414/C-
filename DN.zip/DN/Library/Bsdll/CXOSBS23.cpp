//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E89F4AA0399.cm preserve=no
//## end module%3E89F4AA0399.cm

//## begin module%3E89F4AA0399.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3E89F4AA0399.cp

//## Module: CXOSBS23%3E89F4AA0399; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXOSBS23.cpp

//## begin module%3E89F4AA0399.additionalIncludes preserve=no
//## end module%3E89F4AA0399.additionalIncludes

//## begin module%3E89F4AA0399.includes preserve=yes
//## end module%3E89F4AA0399.includes

#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU07_h
#include "CXODRU07.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif


//## begin module%3E89F4AA0399.declarations preserve=no
//## end module%3E89F4AA0399.declarations

//## begin module%3E89F4AA0399.additionalDeclarations preserve=yes
struct segGenericSegment
{
   char sSegmentID[4];
   char sSegmentVersion[4];
   char sLengthOfSegment[8];
   char sRecordType[24];
   char sCount[4];
};
//## end module%3E89F4AA0399.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::GenericSegment 



GenericSegment::GenericSegment()
  //## begin GenericSegment::GenericSegment%3E89F377034B_const.hasinit preserve=no
  //## end GenericSegment::GenericSegment%3E89F377034B_const.hasinit
  //## begin GenericSegment::GenericSegment%3E89F377034B_const.initialization preserve=yes
   : PersistentSegment("S401")
  //## end GenericSegment::GenericSegment%3E89F377034B_const.initialization
{
  //## begin segment::GenericSegment::GenericSegment%3E89F377034B_const.body preserve=yes
   memcpy_s(m_sID,4,"BS23",4);
   m_hNull.reserve(1024);
   m_hValue.reserve(1024);
  //## end segment::GenericSegment::GenericSegment%3E89F377034B_const.body
}


GenericSegment::~GenericSegment()
{
  //## begin segment::GenericSegment::~GenericSegment%3E89F377034B_dest.body preserve=yes
   reset();
  //## end segment::GenericSegment::~GenericSegment%3E89F377034B_dest.body
}


GenericSegment & GenericSegment::operator=(const GenericSegment &right)
{
  //## begin segment::GenericSegment::operator=%3E89F377034B_assign.body preserve=yes
   if (this == &right)
      return *this;
   PersistentSegment::operator=(right);
   for (map<string,int,less<string> >::const_iterator p = right.m_hColumn.begin();p != right.m_hColumn.end();++p)
      set((*p).first.c_str(),right.m_hValue[(*p).second]->c_str());
   return *this;
  //## end segment::GenericSegment::operator=%3E89F377034B_assign.body
}



//## Other Operations (implementation)
void GenericSegment::add (const string& strValue)
{
  //## begin segment::GenericSegment::add%3E89F4230399.body preserve=yes
   string* pstrValue = new string;
   *pstrValue = strValue;
   m_hValue.push_back(pstrValue);
   m_hNull.push_back(0);
  //## end segment::GenericSegment::add%3E89F4230399.body
}

void GenericSegment::bind (const char* pszTable, const char* pszColumn, reusable::Query& hQuery, const char* pszFunction, int iNPI)
{
  //## begin segment::GenericSegment::bind%3E8A02EA0242.body preserve=yes
   if (m_hColumn.find(string(pszColumn)) != m_hColumn.end())
      return;
   m_hColumn.insert(map<string,int,less<string> >::value_type(string(pszColumn),m_hValue.size()));
   string* pstrValue = new string();
   m_hValue.push_back(pstrValue);
   m_hNull.push_back(0);
   hQuery.bind(pszTable,pszColumn,Column::STRING,pstrValue,&m_hNull[m_hNull.size() - 1],pszFunction,iNPI);
  //## end segment::GenericSegment::bind%3E8A02EA0242.body
}

void GenericSegment::copy (segment::Segment& hSegment) const
{
  //## begin segment::GenericSegment::copy%56312A1401DD.body preserve=yes
   for (map<string,int,less<string> >::const_iterator p = m_hColumn.begin();p != m_hColumn.end();++p)
      hSegment.setField((*p).first.c_str(),*m_hValue[(*p).second]);
  //## end segment::GenericSegment::copy%56312A1401DD.body
}

int GenericSegment::deport (char** ppsBuffer)
{
  //## begin segment::GenericSegment::deport%3E89F4120148.body preserve=yes
   segGenericSegment* pGenericSegment = (segGenericSegment*)*ppsBuffer;
   memset(pGenericSegment,' ',sizeof(segGenericSegment));
   memcpy_s(pGenericSegment->sSegmentID,4,"S401",4);
   memcpy_s(pGenericSegment->sSegmentVersion,4,"0100",4);
   memcpy_s(pGenericSegment->sRecordType,sizeof(pGenericSegment->sRecordType),m_strRecordType.data(),m_strRecordType.length());
   char szTemp[PERCENTD];
   snprintf(szTemp,sizeof(szTemp),"%04d",m_hValue.size());
   memcpy_s(pGenericSegment->sCount,4,szTemp,4);
   *ppsBuffer += 38;
   vector<string*>::iterator p;
   for (p = m_hValue.begin();p != m_hValue.end();++p)
   {
      snprintf(szTemp,sizeof(szTemp),"%04d",(*p)->length());
      memcpy_s(*ppsBuffer,4,szTemp,4);
      *ppsBuffer += 4;
      memcpy_s(*ppsBuffer,(*p)->length(),(*p)->data(),(*p)->length());
      *ppsBuffer += (*p)->length();
   }
   snprintf(szTemp,sizeof(szTemp),"%08d",(*ppsBuffer) - (char*)pGenericSegment);
   memcpy_s(pGenericSegment->sLengthOfSegment,8,szTemp,8);
   return 0;
  //## end segment::GenericSegment::deport%3E89F4120148.body
}

int GenericSegment::deport (char** ppsBuffer, reusable::Table& hTable)
{
  //## begin segment::GenericSegment::deport%51E7F98C035F.body preserve=yes
   segGenericSegment* pGenericSegment = (segGenericSegment*)*ppsBuffer;
   memset(pGenericSegment,' ',sizeof(segGenericSegment));
   memcpy_s(pGenericSegment->sSegmentID,4,"S401",4);
   memcpy_s(pGenericSegment->sSegmentVersion,4,"0100",4);
   snprintf(pGenericSegment->sRecordType,sizeof(pGenericSegment->sRecordType),"%02hd",hTable.getRow());
   memcpy_s(pGenericSegment->sRecordType + 2,sizeof(pGenericSegment->sRecordType)-2,hTable.getName().data(),hTable.getName().length());
   char szTemp[PERCENTD];
   snprintf(szTemp,sizeof(szTemp),"%04d",hTable.getColumn().size());
   memcpy_s(pGenericSegment->sCount,4,szTemp,4);
   *ppsBuffer += sizeof(segGenericSegment);
   map<string,Column,less<string> >::iterator p;
   for (p = hTable.getColumn().begin();p != hTable.getColumn().end();++p)
   {
      if ((*p).second.getNumeric()
         && (*p).second.getValue().empty())
         (*p).second.setValue("0");
      snprintf(szTemp,sizeof(szTemp),"%04d",(*p).second.getValue().length());
      memcpy_s(*ppsBuffer,4,szTemp,4);
      *ppsBuffer += 4;
      memcpy_s(*ppsBuffer, (*p).second.getValue().length(),(*p).second.getValue().data(),(*p).second.getValue().length());
      *ppsBuffer += (*p).second.getValue().length();
   }
   snprintf(szTemp,sizeof(szTemp),"%08d",(*ppsBuffer) - (char*)pGenericSegment);
   memcpy_s(pGenericSegment->sLengthOfSegment,8,szTemp,8);
   return 0;
  //## end segment::GenericSegment::deport%51E7F98C035F.body
}

void GenericSegment::erase (const char* pszName)
{
  //## begin segment::GenericSegment::erase%5E18F57100D0.body preserve=yes
   map<string, int, less<string> >::const_iterator p = m_hColumn.find(string(pszName));
   if (p != m_hColumn.end())
      m_hValue[(*p).second]->erase();
  //## end segment::GenericSegment::erase%5E18F57100D0.body
}

bool GenericSegment::_field (const char* pszName, string& strValue, bool bDescription, bool bFormat) const
{
  //## begin segment::GenericSegment::_field%519CD5090161.body preserve=yes
   map<string,int,less<string> >::const_iterator p = m_hColumn.find(string(pszName));
   if (p == m_hColumn.end())
   {
      strValue.erase();
      return false;
   }
   strValue = *m_hValue[(*p).second];
   return true;
  //## end segment::GenericSegment::_field%519CD5090161.body
}

const string& GenericSegment::get (const char* pszName, short* psiNull)
{
  //## begin segment::GenericSegment::get%542C1BB70270.body preserve=yes
   map<string,int,less<string> >::const_iterator p = m_hColumn.find(string(pszName));
   if (m_hColumn.find(string(pszName)) == m_hColumn.end())
   {
      m_hColumn.insert(map<string,int,less<string> >::value_type(string(pszName),m_hValue.size()));
      string* pstrValue = new string();
      m_hValue.push_back(pstrValue);
      m_hNull.push_back(0);
      p = m_hColumn.find(string(pszName));
   }
   if (psiNull)
      *psiNull = m_hNull[(*p).second];
   return *m_hValue[(*p).second];
  //## end segment::GenericSegment::get%542C1BB70270.body
}

bool GenericSegment::getColumnName (int iIndex, string& hValue)
{
  //## begin segment::GenericSegment::getColumnName%652ED87B01C2.body preserve=yes
   for (map<string, int, less<string> >::const_iterator p = m_hColumn.begin(); p != m_hColumn.end(); ++p)
   {
      if ((*p).second == iIndex)
      {
         hValue = (*p).first;
         return true;
      }
   }
   return false;
  //## end segment::GenericSegment::getColumnName%652ED87B01C2.body
}

bool GenericSegment::getFieldByIndex (int iIndex, string& hValue) const
{
  //## begin segment::GenericSegment::getFieldByIndex%5E27B9B301A0.body preserve=yes
   if (iIndex < 0
      || iIndex >= m_hValue.size())
      return false;
   hValue = *m_hValue[iIndex];
   return true;
  //## end segment::GenericSegment::getFieldByIndex%5E27B9B301A0.body
}

bool GenericSegment::getFieldIndex (const char* pszName, int& iIndex) const
{
  //## begin segment::GenericSegment::getFieldIndex%5E27B99C02DA.body preserve=yes
   map<string,int,less<string> >::const_iterator p = m_hColumn.find(string(pszName));
   if (m_hColumn.find(string(pszName)) == m_hColumn.end())
   {
      iIndex = -1;
      return false;
   }
   iIndex = (*p).second;
   return true;
  //## end segment::GenericSegment::getFieldIndex%5E27B99C02DA.body
}

int GenericSegment::getColumnCount ()
{
  //## begin segment::GenericSegment::getColumnCount%652ED8DA004E.body preserve=yes
   return m_hColumn.size();
  //## end segment::GenericSegment::getColumnCount%652ED8DA004E.body
}

int GenericSegment::import (char** ppsBuffer)
{
  //## begin segment::GenericSegment::import%3E89F404032C.body preserve=yes
   segGenericSegment* pGenericSegment = (segGenericSegment*)*ppsBuffer;
   m_strRecordType.assign(pGenericSegment->sRecordType,22);
   size_t pos = m_strRecordType.find(' ');
   if (pos != string::npos)
      m_strRecordType.erase(pos);
   int i = atoi(pGenericSegment->sCount,4);
   char* p = pGenericSegment->sCount + 4;
   do
   {
      int j = atoi(p,4);
      p += 4;
      string* pstrValue = new string(p,j);
      m_hValue.push_back(pstrValue);
      m_hNull.push_back(0);
      p += j;
   }
   while (--i > 0);
   *ppsBuffer = p;
   return 0;
  //## end segment::GenericSegment::import%3E89F404032C.body
}

int GenericSegment::import (char** ppsBuffer, reusable::Table& hTable)
{
  //## begin segment::GenericSegment::import%51E7F9AF018C.body preserve=yes
   segGenericSegment* pGenericSegment = (segGenericSegment*)*ppsBuffer;
   map<string,Column,less<string> >::iterator c = hTable.getColumn().begin();
   int i = atoi(pGenericSegment->sCount,4);
   char* p = pGenericSegment->sCount + 4;
   do
   {
      int j = atoi(p,4);
      p += 4;
      (*c).second.setValue(p,j);
      ++c;
      p += j;
   }
   while (--i > 0);
   *ppsBuffer = p;
   return 0;
  //## end segment::GenericSegment::import%51E7F9AF018C.body
}

bool GenericSegment::isNull () const
{
  //## begin segment::GenericSegment::isNull%56A7C58E015C.body preserve=yes
   return find(m_hNull.begin(),m_hNull.end(),0) == m_hNull.end();
  //## end segment::GenericSegment::isNull%56A7C58E015C.body
}

void GenericSegment::reset ()
{
  //## begin segment::GenericSegment::reset%3E89F40B0000.body preserve=yes
   m_hColumn.erase(m_hColumn.begin(),m_hColumn.end());
   vector<string*>::iterator p;
   for (p = m_hValue.begin();p != m_hValue.end();++p)
      delete *p;
   m_hNull.erase(m_hNull.begin(),m_hNull.end());
   m_hValue.erase(m_hValue.begin(),m_hValue.end());
  //## end segment::GenericSegment::reset%3E89F40B0000.body
}

int GenericSegment::set (const char* pszName, const string& strValue)
{
  //## begin segment::GenericSegment::set%542C1B8B03DA.body preserve=yes
   map<string,int,less<string> >::const_iterator p = m_hColumn.find(string(pszName));
   if (m_hColumn.find(string(pszName)) == m_hColumn.end())
   {
      m_hColumn.insert(map<string,int,less<string> >::value_type(string(pszName),m_hValue.size()));
      string* pstrValue = new string();
      m_hValue.push_back(pstrValue);
      m_hNull.push_back(0);
      p = m_hColumn.find(string(pszName));
   }
   *m_hValue[(*p).second] = strValue;
   return (*p).second;
  //## end segment::GenericSegment::set%542C1B8B03DA.body
}

void GenericSegment::set (const char* pszName, int iValue)
{
  //## begin segment::GenericSegment::set%542C24F80198.body preserve=yes
   char szValue[PERCENTD];
   snprintf(szValue,sizeof(szValue),"%d",iValue);
   set(pszName,szValue);
  //## end segment::GenericSegment::set%542C24F80198.body
}

void GenericSegment::set (const char* pszName, long lValue)
{
  //## begin segment::GenericSegment::set%648214910189.body preserve=yes
   char szValue[PERCENTF];   // PERCENTD only allows for 11 digits
   snprintf(szValue, sizeof(szValue), "%d", lValue);
   set(pszName, szValue);
  //## end segment::GenericSegment::set%648214910189.body
}

void GenericSegment::set (const char* pszName, double dValue)
{
  //## begin segment::GenericSegment::set%5C4A139C0076.body preserve=yes
   char szValue[PERCENTF];
   snprintf(szValue,sizeof(szValue),"%f",dValue);
   set(pszName,szValue);
  //## end segment::GenericSegment::set%5C4A139C0076.body
}

// Additional Declarations
  //## begin segment::GenericSegment%3E89F377034B.declarations preserve=yes
  //## end segment::GenericSegment%3E89F377034B.declarations

} // namespace segment

//## begin module%3E89F4AA0399.epilog preserve=yes
//## end module%3E89F4AA0399.epilog
