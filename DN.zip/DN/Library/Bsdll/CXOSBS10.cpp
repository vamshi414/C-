//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%35A3BB9C009B.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%35A3BB9C009B.cm

//## begin module%35A3BB9C009B.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%35A3BB9C009B.cp

//## Module: CXOSBS10%35A3BB9C009B; Package body
//## Subsystem: BSDLL%394E1F8C0345
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bsdll\CXOSBS10.cpp

//## begin module%35A3BB9C009B.additionalIncludes preserve=no
//## end module%35A3BB9C009B.additionalIncludes

//## begin module%35A3BB9C009B.includes preserve=yes
// $Date:   May 14 2020 17:56:16  $ $Author:   e1009510  $ $Revision:   1.12  $
#include <stdio.h>
#include "CXODBS15.hpp"
//## end module%35A3BB9C009B.includes

#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSRU24_h
#include "CXODRU24.hpp"
#endif
#ifndef CXOSBS10_h
#include "CXODBS10.hpp"
#endif


//## begin module%35A3BB9C009B.declarations preserve=no
//## end module%35A3BB9C009B.declarations

//## begin module%35A3BB9C009B.additionalDeclarations preserve=yes
struct segMultipleRowContextSegment_0101* pMRC = 0;
#define FIELDS 8
Fields MultipleRowContextSegment_Fields[FIELDS + 1] =
{
   "C         ","ClientStateIndicator",offsetof(segMultipleRowContextSegment_0101,cClientStateIndicator),sizeof(pMRC->cClientStateIndicator),
   "l%08d     ","MaxRowsToFetch",offsetof(segMultipleRowContextSegment_0101,sMaxRowsToFetch),sizeof(pMRC->sMaxRowsToFetch),
   "l%08d     ","TotalRecordsFound",offsetof(segMultipleRowContextSegment_0101,sTotalRecordsFound),sizeof(pMRC->sTotalRecordsFound),
   "l%08d     ","RecordsReturnedThisMessage",offsetof(segMultipleRowContextSegment_0101,sRecordsReturnedThisMessage),sizeof(pMRC->sRecordsReturnedThisMessage),
   "C         ","ServerStateIndicator",offsetof(segMultipleRowContextSegment_0101,cServerStateIndicator),sizeof(pMRC->cServerStateIndicator),
   "l%08d     ","RecordNumberLastReturned",offsetof(segMultipleRowContextSegment_0101,sRecordNumberLastReturned),sizeof(pMRC->sRecordNumberLastReturned),
   "i         ","STSContextData",offsetof(segMultipleRowContextSegment_0101,sSTSContextData),sizeof(pMRC->sSTSContextData),
   "C         ","Archive",offsetof(segMultipleRowContextSegment_0101,cArchive),sizeof(pMRC->cArchive),
   "~","~",0,sizeof(segMultipleRowContextSegment_0101)
};
//## end module%35A3BB9C009B.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::MultipleRowContextSegment 

MultipleRowContextSegment::MultipleRowContextSegment()
  //## begin MultipleRowContextSegment::MultipleRowContextSegment%34609BFF01B9_const.hasinit preserve=no
      : m_cArchive('N'),
        m_cClientStateIndicator('I'),
        m_lMaxRowsToFetch(10),
        m_lRecordNumberLastReturned(0),
        m_lRecordsReturnedThisMessage(0),
        m_cServerStateIndicator(' '),
        m_lTotalRecordsFound(0)
  //## end MultipleRowContextSegment::MultipleRowContextSegment%34609BFF01B9_const.hasinit
  //## begin MultipleRowContextSegment::MultipleRowContextSegment%34609BFF01B9_const.initialization preserve=yes
   ,Segment("S002")
  //## end MultipleRowContextSegment::MultipleRowContextSegment%34609BFF01B9_const.initialization
{
  //## begin segment::MultipleRowContextSegment::MultipleRowContextSegment%34609BFF01B9_const.body preserve=yes
   memcpy_s(m_sID,4,"BS10",4);
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_cClientStateIndicator;
   m_pField[1] = &m_lMaxRowsToFetch;
   m_pField[2] = &m_lTotalRecordsFound;
   m_pField[3] = &m_lRecordsReturnedThisMessage;
   m_pField[4] = &m_cServerStateIndicator;
   m_pField[5] = &m_lRecordNumberLastReturned;
   m_pField[6] = &m_strSTSContextData;
   m_pField[7] = &m_cArchive;
  //## end segment::MultipleRowContextSegment::MultipleRowContextSegment%34609BFF01B9_const.body
}


MultipleRowContextSegment::~MultipleRowContextSegment()
{
  //## begin segment::MultipleRowContextSegment::~MultipleRowContextSegment%34609BFF01B9_dest.body preserve=yes
   delete [] m_pField;
  //## end segment::MultipleRowContextSegment::~MultipleRowContextSegment%34609BFF01B9_dest.body
}



//## Other Operations (implementation)
int MultipleRowContextSegment::deport (char** ppsBuffer)
{
  //## begin segment::MultipleRowContextSegment::deport%379F023E0210.body preserve=yes
   int m;
   char szTemp[4 * PERCENTD];
   if (m_strVersion == "0100")
   {
      segMultipleRowContextSegment* pSegment = (segMultipleRowContextSegment*)*ppsBuffer;
      memset(pSegment,' ',sizeof(segMultipleRowContextSegment));
      memcpy_s(pSegment->sSegmentID,4,segmentID(),4);
      memcpy_s(pSegment->sSegmentVersion,4,"0100",4);
      m = sizeof(segMultipleRowContextSegment);
      snprintf(szTemp,sizeof(szTemp),"%08d",m);
      memcpy_s(pSegment->sLengthOfSegment,8,szTemp,8);
      snprintf(szTemp,sizeof(szTemp),"%04d%04d%04d %04d",
         m_lMaxRowsToFetch,
         m_lTotalRecordsFound,
         m_lRecordsReturnedThisMessage,
         m_lRecordNumberLastReturned);
      memcpy_s(pSegment->sMaxRowsToFetch,17,szTemp,17);
      pSegment->cClientStateIndicator = m_cClientStateIndicator;
      pSegment->cServerStateIndicator = m_cServerStateIndicator;
      memcpy_s(pSegment->sSTSContextData,sizeof(pSegment->sSTSContextData),m_strSTSContextData,m_strSTSContextData.length());
      *ppsBuffer += m;
   }
   else
      Segment::deport(ppsBuffer);
   return 0;
  //## end segment::MultipleRowContextSegment::deport%379F023E0210.body
}

struct  Fields* MultipleRowContextSegment::fields () const
{
  //## begin segment::MultipleRowContextSegment::fields%3827107D0000.body preserve=yes
   return &MultipleRowContextSegment_Fields[0];
  //## end segment::MultipleRowContextSegment::fields%3827107D0000.body
}

int MultipleRowContextSegment::import (char** ppsBuffer)
{
  //## begin segment::MultipleRowContextSegment::import%379F024101CE.body preserve=yes
   segMultipleRowContextSegment* pSegment = (segMultipleRowContextSegment*)*ppsBuffer;
   if (memcmp(pSegment->sSegmentVersion,"0100",4) != 0
      && memcmp(pSegment->sSegmentVersion,"0101",4) != 0)
      return STS_INVALID_VERSION_NUMBER;
   m_strVersion.assign(pSegment->sSegmentVersion,4);
   setPresence(true);
   if (m_strVersion == "0100")
   {
      if (strncmp(pSegment->sLengthOfSegment,"00000112",8))
         return STS_INVALID_SEGMENT_LENGTH;
      if (pSegment->cClientStateIndicator != 'I'
         && pSegment->cClientStateIndicator != 'C'
         && pSegment->cClientStateIndicator != 'P')
         return STS_INVALID_CONTEXT_DATA;
      IString strMaxRowsToFetch(pSegment->sMaxRowsToFetch,4);
      if (pSegment->cClientStateIndicator != 'I')
      {
         IString strTotalRecordsFound(pSegment->sTotalRecordsFound,4);
         IString strRecordNumberLastReturned(pSegment->sRecordNumberLastReturned,4);
         m_lTotalRecordsFound = strTotalRecordsFound.asInt();
         m_lRecordNumberLastReturned = strRecordNumberLastReturned.asInt();
      }
      else
      {
         m_lTotalRecordsFound = 0;
         m_lRecordNumberLastReturned = 0;
         m_strSTSContextData = "190001010000000000000000";
      }
      pSegment->sReserved2[0] = '\0';
      m_strSTSContextData.overlayWith(pSegment->sSTSContextData);
      m_cArchive = pSegment->cArchive;
      m_cClientStateIndicator = pSegment->cClientStateIndicator;
      m_cServerStateIndicator = pSegment->cServerStateIndicator;
      m_lMaxRowsToFetch = strMaxRowsToFetch.asInt();
   }
   else
   {
      segMultipleRowContextSegment_0101* pSegment = (segMultipleRowContextSegment_0101*)*ppsBuffer;
      if (strncmp(pSegment->sLengthOfSegment,"00000128",8))
         return STS_INVALID_SEGMENT_LENGTH;
      if (pSegment->cClientStateIndicator != 'I'
         && pSegment->cClientStateIndicator != 'C'
         && pSegment->cClientStateIndicator != 'P')
         return STS_INVALID_CONTEXT_DATA;
      IString strMaxRowsToFetch(pSegment->sMaxRowsToFetch,8);
      if (pSegment->cClientStateIndicator != 'I')
      {
         IString strTotalRecordsFound(pSegment->sTotalRecordsFound,8);
         IString strRecordNumberLastReturned(pSegment->sRecordNumberLastReturned,8);
         m_lTotalRecordsFound = strTotalRecordsFound.asInt();
         m_lRecordNumberLastReturned = strRecordNumberLastReturned.asInt();
      }
      else
      {
         m_lTotalRecordsFound = 0;
         m_lRecordNumberLastReturned = 0;
         m_strSTSContextData = "190001010000000000000000";
      }
      pSegment->sReserved2[0] = '\0';
      m_strSTSContextData.overlayWith(pSegment->sSTSContextData);
      m_cArchive = pSegment->cArchive;
      m_cClientStateIndicator = pSegment->cClientStateIndicator;
      m_cServerStateIndicator = pSegment->cServerStateIndicator;
      m_lMaxRowsToFetch = strMaxRowsToFetch.asInt();
   }
   m_lRecordsReturnedThisMessage = 0;
   *ppsBuffer += atol(pSegment->sLengthOfSegment,8);
   return 0;
  //## end segment::MultipleRowContextSegment::import%379F024101CE.body
}

void MultipleRowContextSegment::update (char* psBuffer, int lTotalRecordsFound)
{
  //## begin segment::MultipleRowContextSegment::update%37F9064B02ED.body preserve=yes
   char szTemp[PERCENTD];
   segMultipleRowContextSegment* pSegment = (segMultipleRowContextSegment*)psBuffer;
   if (memcmp(pSegment->sSegmentVersion,"0100",4) == 0)
   {
      snprintf(szTemp,sizeof(szTemp),"%04d",lTotalRecordsFound);
      memcpy_s(pSegment->sTotalRecordsFound,4,szTemp,4);
   }
   else
   {
      segMultipleRowContextSegment_0101* pSegment = (segMultipleRowContextSegment_0101*)psBuffer;
      snprintf(szTemp,sizeof(szTemp),"%08d",lTotalRecordsFound);
      memcpy_s(pSegment->sTotalRecordsFound,8,szTemp,8);
   }
  //## end segment::MultipleRowContextSegment::update%37F9064B02ED.body
}

// Additional Declarations
  //## begin segment::MultipleRowContextSegment%34609BFF01B9.declarations preserve=yes
  //## end segment::MultipleRowContextSegment%34609BFF01B9.declarations

} // namespace segment

//## begin module%35A3BB9C009B.epilog preserve=yes
//## end module%35A3BB9C009B.epilog
