//	Copyright (c) 1998 - 2024
//	FIS

#ifndef CXODBS29_HPP
#define CXODBS29_HPP

struct segTextSegment
{
   char sSegmentID[4];                 // 0000 - 'S055'
   char sSegmentVersion[4];            // 0004 - '0100'
   char sLengthOfSegment[8];           // 0008 total length of segment
   char sReserved[30];                 // 0016 - ' '
   char sLengthOfData[8];              // 0046 length of sText
   char sText[2];                      // 0054
};

#endif

