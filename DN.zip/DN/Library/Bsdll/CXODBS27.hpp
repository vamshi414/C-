//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%51C352D00347.cm preserve=no
//	$Date:   May 14 2020 17:56:10  $ $Author:   e1009510  $ $Revision:   1.7  $
//## end module%51C352D00347.cm

//## begin module%51C352D00347.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%51C352D00347.cp

//## Module: CXOSBS27%51C352D00347; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.4B.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS27.hpp

#ifndef CXOSBS27_h
#define CXOSBS27_h 1

//## begin module%51C352D00347.additionalIncludes preserve=no
//## end module%51C352D00347.additionalIncludes

//## begin module%51C352D00347.includes preserve=yes
#include <map>
#include <vector>
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBS28_h
#include "CXODBS28.hpp"
#endif
//## end module%51C352D00347.includes

#ifndef CXOSDB44_h
#include "CXODDB44.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
class Mask;
class Buffer;
class Column;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class FlatFile;
class Extract;
class AdvancedEncryptionStandard;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class AuditEventSegment;
class Segment;

} // namespace segment

//## begin module%51C352D00347.declarations preserve=no
//## end module%51C352D00347.declarations

//## begin module%51C352D00347.additionalDeclarations preserve=yes
//## end module%51C352D00347.additionalDeclarations


namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::AuditEvent%51C3523501DC.preface preserve=yes
//## end segment::AuditEvent%51C3523501DC.preface

//## Class: AuditEvent%51C3523501DC
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%51C3527802F2;Segment { -> F}
//## Uses: <unnamed>%51C3527C005F;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%51C352800030;database::Database { -> F}
//## Uses: <unnamed>%51C3528300C0;reusable::Statement { -> F}
//## Uses: <unnamed>%51C352860059;reusable::Table { -> F}
//## Uses: <unnamed>%51C352890059;IF::Message { -> F}
//## Uses: <unnamed>%51C3528D0148;IF::Extract { -> F}
//## Uses: <unnamed>%51C3529300C3;reusable::Column { -> F}
//## Uses: <unnamed>%51C47FFE0082;process::Application { -> F}
//## Uses: <unnamed>%51C48D42015D;AuditEventSegment { -> F}
//## Uses: <unnamed>%51C491240320;IF::AdvancedEncryptionStandard { -> F}
//## Uses: <unnamed>%51D3335002F4;reusable::Buffer { -> F}
//## Uses: <unnamed>%51D3335301B4;IF::FlatFile { -> F}
//## Uses: <unnamed>%51E56255024D;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%51E562580297;reusable::Query { -> F}
//## Uses: <unnamed>%51E562DF002B;timer::Clock { -> F}
//## Uses: <unnamed>%524595BA0246;reusable::Mask { -> F}

class DllExport AuditEvent : public database::AuditEvent  //## Inherits: <unnamed>%51C855AC00B4
{
  //## begin segment::AuditEvent%51C3523501DC.initialDeclarations preserve=yes
  //## end segment::AuditEvent%51C3523501DC.initialDeclarations

  public:
    //## Constructors (generated)
      AuditEvent();

    //## Destructor (generated)
      virtual ~AuditEvent();


    //## Other Operations (specified)
      //## Operation: captureEvent%51CA3D060123
      virtual void captureEvent (const IF::Message& hMessage, const string& strCommand);

      //## Operation: captureEvent%51E4207002FF
      virtual void captureEvent (const string& strTableName, const string& strSearchCondition, const string& strPredicates);

      //## Operation: captureEvent%51C868360087
      virtual void captureEvent (const IF::Message& hMessage);

      //## Operation: captureEvent%51C48AC5038D
      virtual void captureEvent (reusable::Table& hTable, short sEventType);

      //## Operation: captureEvent%524C43A902E6
      virtual void captureEvent (const string& strUSER_ID, short sEVENT_TYPE, short sRETURN_CODE, const string& strRESOURCE_NAME, const string& strRESOURCE_KEY);

      //## Operation: commitEvent%51DB310B010A
      virtual bool commitEvent (bool bCommit);

      //## Operation: load%51C354680098
      virtual bool load ();

      //## Operation: update%51CA0CA6002A
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin segment::AuditEvent%51C3523501DC.public preserve=yes
      //## end segment::AuditEvent%51C3523501DC.public

  protected:
    // Additional Protected Declarations
      //## begin segment::AuditEvent%51C3523501DC.protected preserve=yes
      //## end segment::AuditEvent%51C3523501DC.protected

  private:
    // Additional Private Declarations
      //## begin segment::AuditEvent%51C3523501DC.private preserve=yes
      //## end segment::AuditEvent%51C3523501DC.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: SEQ_NO%51C48C4C0292
      //## begin segment::AuditEvent::SEQ_NO%51C48C4C0292.attr preserve=no  private: int {U} 0
      int m_lSEQ_NO;
      //## end segment::AuditEvent::SEQ_NO%51C48C4C0292.attr

      //## Attribute: CUST_ID%51C48D9F0127
      //## begin segment::AuditEvent::CUST_ID%51C48D9F0127.attr preserve=no  private: string {U} 
      string m_strCUST_ID;
      //## end segment::AuditEvent::CUST_ID%51C48D9F0127.attr

      //## Attribute: HostName%51C49239031F
      //## begin segment::AuditEvent::HostName%51C49239031F.attr preserve=no  private: string {U} 
      string m_strHostName;
      //## end segment::AuditEvent::HostName%51C49239031F.attr

      //## Attribute: IPAddress%51C4923B02B4
      //## begin segment::AuditEvent::IPAddress%51C4923B02B4.attr preserve=no  private: string {U} 
      string m_strIPAddress;
      //## end segment::AuditEvent::IPAddress%51C4923B02B4.attr

      //## Attribute: TASKID%51C48E5601A9
      //## begin segment::AuditEvent::TASKID%51C48E5601A9.attr preserve=no  private: string {U} 
      string m_strTASKID;
      //## end segment::AuditEvent::TASKID%51C48E5601A9.attr

      //## Attribute: USER_ID%51C48EA50031
      //## begin segment::AuditEvent::USER_ID%51C48EA50031.attr preserve=no  private: string {U} 
      string m_strUSER_ID;
      //## end segment::AuditEvent::USER_ID%51C48EA50031.attr

      //## Attribute: LastTstamp%51C8861801A5
      //## begin segment::AuditEvent::LastTstamp%51C8861801A5.attr preserve=no  private: string {U} 
      string m_strLastTstamp;
      //## end segment::AuditEvent::LastTstamp%51C8861801A5.attr

    // Additional Implementation Declarations
      //## begin segment::AuditEvent%51C3523501DC.implementation preserve=yes
      vector<AuditEventSegment> m_hAuditEvents;
      AuditEventSegment m_hAuditEventSegment;
      map<string,string,less<string> > m_hServices;  //services and resource names
      //## end segment::AuditEvent%51C3523501DC.implementation
};

//## begin segment::AuditEvent%51C3523501DC.postscript preserve=yes
//## end segment::AuditEvent%51C3523501DC.postscript

} // namespace segment

//## begin module%51C352D00347.epilog preserve=yes
//## end module%51C352D00347.epilog


#endif
