//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%44448D08020B.cm preserve=no
//	$Date:   Aug 07 2009 15:08:54  $ $Author:   D02405  $
//	$Revision:   1.3  $
//## end module%44448D08020B.cm

//## begin module%44448D08020B.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%44448D08020B.cp

//## Module: CXOSBS24%44448D08020B; Package body
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bsdll\CXOSBS24.cpp

//## begin module%44448D08020B.additionalIncludes preserve=no
//## end module%44448D08020B.additionalIncludes

//## begin module%44448D08020B.includes preserve=yes
//## end module%44448D08020B.includes

#ifndef CXOSBS24_h
#include "CXODBS24.hpp"
#endif
//## begin module%44448D08020B.declarations preserve=no
//## end module%44448D08020B.declarations

//## begin module%44448D08020B.additionalDeclarations preserve=yes
#define FIELDS 15
Fields ImportReportAuditSegment_Fields[FIELDS + 1] = 
{
   "a        X","PROC",0,0,
   "a        X","FILE",0,0,
   "l         ","DI_FILE_ID",0,0,
   "a        X","PATH",0,0,
   "a        X","DATE_RECON",0,0,
   "a        X","TSTAMP_INITIATED",0,0,
   "a        X","TIMESTAMP",0,0,
   "l         ","TRANSACTION_NO",0,0,
   "s         ","SEQ_NO",0,0,
   "a         ","IMPORT_KEY",0,0,
   "a         ","REJECT_CODES",0,0,
   "l        X","Pass",0,0,
   "l        X","Total",0,0,
   "l        X","Success",0,0,
   "l        X","Failure",0,0,
   "~" ,"~", -1,0,
};
//## end module%44448D08020B.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::ImportReportAuditSegment 

//## begin segment::ImportReportAuditSegment::Instance%4720883B0232.attr preserve=no  private: static segment::ImportReportAuditSegment* {V} 0
segment::ImportReportAuditSegment* ImportReportAuditSegment::m_pInstance = 0;
//## end segment::ImportReportAuditSegment::Instance%4720883B0232.attr

ImportReportAuditSegment::ImportReportAuditSegment()
  //## begin ImportReportAuditSegment::ImportReportAuditSegment%44448BD602FD_const.hasinit preserve=no
      : m_iDI_FILE_ID(0),
        m_iPass(0),
        m_siSEQ_NO(0),
        m_iTRANSACTION_NO(0)
  //## end ImportReportAuditSegment::ImportReportAuditSegment%44448BD602FD_const.hasinit
  //## begin ImportReportAuditSegment::ImportReportAuditSegment%44448BD602FD_const.initialization preserve=yes
   ,PersistentSegment("S999","DI_DATA")
  //## end ImportReportAuditSegment::ImportReportAuditSegment%44448BD602FD_const.initialization
{
  //## begin segment::ImportReportAuditSegment::ImportReportAuditSegment%44448BD602FD_const.body preserve=yes
   memcpy(m_sID,"BS24",4); 
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strServer;
   m_pField[1] = &m_strFILE;
   m_pField[2] = &m_iDI_FILE_ID;
   m_pField[3] = &m_strPATH;
   m_pField[4] = &m_strDATE_RECON;
   m_pField[5] = &m_strTSTAMP_INITIATED;
   m_pField[6] = &m_strTIMESTAMP;
   m_pField[7] = &m_iTRANSACTION_NO;
   m_pField[8] = &m_siSEQ_NO;
   m_pField[9] = &m_strIMPORT_KEY;
   m_pField[10] = &m_strREJECT_CODES;
   m_pField[11] = &m_iPass;
   m_pField[12] = &m_iCount[0];
   m_pField[13] = &m_iCount[1];
   m_pField[14] = &m_iCount[2];
  //## end segment::ImportReportAuditSegment::ImportReportAuditSegment%44448BD602FD_const.body
}


ImportReportAuditSegment::~ImportReportAuditSegment()
{
  //## begin segment::ImportReportAuditSegment::~ImportReportAuditSegment%44448BD602FD_dest.body preserve=yes
   delete [] m_pField;
  //## end segment::ImportReportAuditSegment::~ImportReportAuditSegment%44448BD602FD_dest.body
}



//## Other Operations (implementation)
struct Fields* ImportReportAuditSegment::fields () const
{
  //## begin segment::ImportReportAuditSegment::fields%4444AC7C026E.body preserve=yes
   return &ImportReportAuditSegment_Fields[0];
  //## end segment::ImportReportAuditSegment::fields%4444AC7C026E.body
}

segment::ImportReportAuditSegment* ImportReportAuditSegment::instance ()
{
  //## begin segment::ImportReportAuditSegment::instance%4720886E029F.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ImportReportAuditSegment();
   return m_pInstance;
  //## end segment::ImportReportAuditSegment::instance%4720886E029F.body
}

void ImportReportAuditSegment::setCount (int iCount, int iIndex)
{
  //## begin segment::ImportReportAuditSegment::setCount%47224E210000.body preserve=yes
   m_iCount[iIndex] = iCount;
  //## end segment::ImportReportAuditSegment::setCount%47224E210000.body
}

// Additional Declarations
  //## begin segment::ImportReportAuditSegment%44448BD602FD.declarations preserve=yes
  //## end segment::ImportReportAuditSegment%44448BD602FD.declarations

} // namespace segment

//## begin module%44448D08020B.epilog preserve=yes
//## end module%44448D08020B.epilog
