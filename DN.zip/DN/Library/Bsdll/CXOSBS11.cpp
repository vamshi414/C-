//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%359B6F87010B.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%359B6F87010B.cm

//## begin module%359B6F87010B.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%359B6F87010B.cp

//## Module: CXOSBS11%359B6F87010B; Package body
//## Subsystem: BSDLL%394E1F8C0345
//## Source file: C:\Pvcswork\Dn\Server\Library\Bsdll\CXOSBS11.cpp

//## begin module%359B6F87010B.additionalIncludes preserve=no
//## end module%359B6F87010B.additionalIncludes

//## begin module%359B6F87010B.includes preserve=yes
// $Date:   May 14 2020 17:56:18  $ $Author:   e1009510  $ $Revision:   1.5  $
#include <stdio.h>
#include "CXODBS16.hpp"
//## end module%359B6F87010B.includes

#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif


//## begin module%359B6F87010B.declarations preserve=no
//## end module%359B6F87010B.declarations

//## begin module%359B6F87010B.additionalDeclarations preserve=yes
//## end module%359B6F87010B.additionalDeclarations


//## Modelname: Connex Foundation::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

// Class segment::ResponseTimeSegment 






ResponseTimeSegment::ResponseTimeSegment()
  //## begin ResponseTimeSegment::ResponseTimeSegment%3453FD9B0248_const.hasinit preserve=no
  //## end ResponseTimeSegment::ResponseTimeSegment%3453FD9B0248_const.hasinit
  //## begin ResponseTimeSegment::ResponseTimeSegment%3453FD9B0248_const.initialization preserve=yes
   : Segment("S053")
  //## end ResponseTimeSegment::ResponseTimeSegment%3453FD9B0248_const.initialization
{
  //## begin segment::ResponseTimeSegment::ResponseTimeSegment%3453FD9B0248_const.body preserve=yes
   memcpy_s(m_sID,4,"BS11",4);
  //## end segment::ResponseTimeSegment::ResponseTimeSegment%3453FD9B0248_const.body
}


ResponseTimeSegment::~ResponseTimeSegment()
{
  //## begin segment::ResponseTimeSegment::~ResponseTimeSegment%3453FD9B0248_dest.body preserve=yes
  //## end segment::ResponseTimeSegment::~ResponseTimeSegment%3453FD9B0248_dest.body
}


ResponseTimeSegment & ResponseTimeSegment::operator=(const ResponseTimeSegment &right)
{
  //## begin segment::ResponseTimeSegment::operator=%3453FD9B0248_assign.body preserve=yes
   if (this == &right)
      return *this;
   ((Segment&)*this) = right;
   for (int i = 0;i <= 2;++i)
      m_strTimestamp[i] = right.m_strTimestamp[i];
   return *this;
  //## end segment::ResponseTimeSegment::operator=%3453FD9B0248_assign.body
}



//## Other Operations (implementation)
int ResponseTimeSegment::deport (char** ppsBuffer)
{
  //## begin segment::ResponseTimeSegment::deport%3D1850170157.body preserve=yes
   if (presence() == false)
      return 0;
   segResponseTimeSegment* pSegment = (segResponseTimeSegment*)*ppsBuffer;
   memset(pSegment,' ',sizeof(segResponseTimeSegment));
   strncpy(pSegment->sSegmentID,"S053",4);
   strncpy(pSegment->sSegmentVersion,"0100",4);
   char szTemp[9];
   int m = sizeof(segResponseTimeSegment);
   snprintf(szTemp,sizeof(szTemp),"%08d",m);
   strncpy(pSegment->sLengthOfSegment,szTemp,8);
   m_hDateTime.setCurrent(m_strTimestamp[2]);
   for (int i = 0;i <= 2;++i)
      strncpy(pSegment->sTimestamp[i + 1],m_strTimestamp[i],16);
   *ppsBuffer += m;
   return 0;
  //## end segment::ResponseTimeSegment::deport%3D1850170157.body
}

int ResponseTimeSegment::import (char** ppsBuffer)
{
  //## begin segment::ResponseTimeSegment::import%3D1850190203.body preserve=yes
   segResponseTimeSegment* pSegment = (segResponseTimeSegment*)*ppsBuffer;
   if (strncmp(pSegment->sSegmentVersion,"0100",4))
      return STS_INVALID_VERSION_NUMBER;
   if (strncmp(pSegment->sLengthOfSegment,"00000112",8))
      return STS_INVALID_SEGMENT_LENGTH;
   setPresence(true);
   IString strTimestamp0(pSegment->sTimestamp[0],16);
   m_strTimestamp[0] = strTimestamp0;
   m_hDateTime.setCurrent(m_strTimestamp[1]);
   *ppsBuffer += atol(pSegment->sLengthOfSegment,8);
   return 0;
  //## end segment::ResponseTimeSegment::import%3D1850190203.body
}

// Additional Declarations
  //## begin segment::ResponseTimeSegment%3453FD9B0248.declarations preserve=yes
  //## end segment::ResponseTimeSegment%3453FD9B0248.declarations

} // namespace segment

//## begin module%359B6F87010B.epilog preserve=yes
//## end module%359B6F87010B.epilog
