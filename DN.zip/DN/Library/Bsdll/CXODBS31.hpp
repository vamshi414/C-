//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3EC3ECBE038A.cm preserve=no
//	$Date:   Jul 16 2018 15:35:50  $ $Author:   e1009839  $ $Revision:   1.0  $
//## end module%3EC3ECBE038A.cm

//## begin module%3EC3ECBE038A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3EC3ECBE038A.cp

//## Module: CXOSBS31%3EC3ECBE038A; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS31.hpp

#ifndef CXOSBS31_h
#define CXOSBS31_h 1

//## begin module%3EC3ECBE038A.additionalIncludes preserve=no
//## end module%3EC3ECBE038A.additionalIncludes

//## begin module%3EC3ECBE038A.includes preserve=yes
//## end module%3EC3ECBE038A.includes

#ifndef CXOSDB13_h
#include "CXODDB13.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseColumn;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class PersistentSegment;

} // namespace segment

//## begin module%3EC3ECBE038A.declarations preserve=no
//## end module%3EC3ECBE038A.declarations

//## begin module%3EC3ECBE038A.additionalDeclarations preserve=yes
//## end module%3EC3ECBE038A.additionalDeclarations


namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::GetColumnsVisitor%3EC3EAFC0196.preface preserve=yes
//## end segment::GetColumnsVisitor%3EC3EAFC0196.preface

//## Class: GetColumnsVisitor%3EC3EAFC0196
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3EC3F0C9006D;database::DatabaseColumn { -> F}

class DllExport GetColumnsVisitor : public database::DatabaseCatalogVisitor  //## Inherits: <unnamed>%3EC3EB1301B5
{
  //## begin segment::GetColumnsVisitor%3EC3EAFC0196.initialDeclarations preserve=yes
  //## end segment::GetColumnsVisitor%3EC3EAFC0196.initialDeclarations

  public:
    //## Constructors (generated)
      GetColumnsVisitor();

    //## Constructors (specified)
      //## Operation: GetColumnsVisitor%3EC3EBBC009C
      GetColumnsVisitor (segment::PersistentSegment* pPersistentSegment);

    //## Destructor (generated)
      virtual ~GetColumnsVisitor();


    //## Other Operations (specified)
      //## Operation: visitDatabaseColumn%3EC3EB1D0000
      virtual void visitDatabaseColumn (database::DatabaseColumn* pDatabaseColumn);

    // Additional Public Declarations
      //## begin segment::GetColumnsVisitor%3EC3EAFC0196.public preserve=yes
      //## end segment::GetColumnsVisitor%3EC3EAFC0196.public

  protected:
    // Additional Protected Declarations
      //## begin segment::GetColumnsVisitor%3EC3EAFC0196.protected preserve=yes
      //## end segment::GetColumnsVisitor%3EC3EAFC0196.protected

  private:
    // Additional Private Declarations
      //## begin segment::GetColumnsVisitor%3EC3EAFC0196.private preserve=yes
      //## end segment::GetColumnsVisitor%3EC3EAFC0196.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Library::Segment_CAT::<unnamed>%5B2D3757022D
      //## Role: GetColumnsVisitor::<m_pPersistentSegment>%5B2D3758014E
      //## begin segment::GetColumnsVisitor::<m_pPersistentSegment>%5B2D3758014E.role preserve=no  public: segment::PersistentSegment { -> RFHgN}
      PersistentSegment *m_pPersistentSegment;
      //## end segment::GetColumnsVisitor::<m_pPersistentSegment>%5B2D3758014E.role

    // Additional Implementation Declarations
      //## begin segment::GetColumnsVisitor%3EC3EAFC0196.implementation preserve=yes
      //## end segment::GetColumnsVisitor%3EC3EAFC0196.implementation

};

//## begin segment::GetColumnsVisitor%3EC3EAFC0196.postscript preserve=yes
//## end segment::GetColumnsVisitor%3EC3EAFC0196.postscript

} // namespace segment

//## begin module%3EC3ECBE038A.epilog preserve=yes
//## end module%3EC3ECBE038A.epilog


#endif
