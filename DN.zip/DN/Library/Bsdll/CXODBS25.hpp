//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4B1D0E7C00AB.cm preserve=no
//	$Date:   Dec 18 2009 09:14:04  $ $Author:   D02405  $
//	$Revision:   1.0  $
//## end module%4B1D0E7C00AB.cm

//## begin module%4B1D0E7C00AB.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4B1D0E7C00AB.cp

//## Module: CXOSBS25%4B1D0E7C00AB; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Bsdll\CXODBS25.hpp

#ifndef CXOSBS25_h
#define CXOSBS25_h 1

//## begin module%4B1D0E7C00AB.additionalIncludes preserve=no
//## end module%4B1D0E7C00AB.additionalIncludes

//## begin module%4B1D0E7C00AB.includes preserve=yes
//## end module%4B1D0E7C00AB.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Timestamp;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;

} // namespace timer

//## begin module%4B1D0E7C00AB.declarations preserve=no
//## end module%4B1D0E7C00AB.declarations

//## begin module%4B1D0E7C00AB.additionalDeclarations preserve=yes
//## end module%4B1D0E7C00AB.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::ExportReportAuditSegment%4B1D0D9C038A.preface preserve=yes
//## end segment::ExportReportAuditSegment%4B1D0D9C038A.preface

//## Class: ExportReportAuditSegment%4B1D0D9C038A
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4B1D0DCC00FA;timer::Clock { -> F}
//## Uses: <unnamed>%4B1D0DCE034B;IF::Timestamp { -> F}

class DllExport ExportReportAuditSegment : public Segment  //## Inherits: <unnamed>%4B1D0DC9037A
{
  //## begin segment::ExportReportAuditSegment%4B1D0D9C038A.initialDeclarations preserve=yes
  //## end segment::ExportReportAuditSegment%4B1D0D9C038A.initialDeclarations

  public:
    //## Constructors (generated)
      ExportReportAuditSegment();

    //## Destructor (generated)
      virtual ~ExportReportAuditSegment();


    //## Other Operations (specified)
      //## Operation: fields%4B1D0DE9033C
      virtual struct  Fields* fields () const;

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Contact%4B1D0E14006D
      void setContact (const string& value)
      {
        //## begin segment::ExportReportAuditSegment::setContact%4B1D0E14006D.set preserve=no
        m_strContact = value;
        //## end segment::ExportReportAuditSegment::setContact%4B1D0E14006D.set
      }


      //## Attribute: End%4B1D0E14006E
      void setEnd (const string& value)
      {
        //## begin segment::ExportReportAuditSegment::setEnd%4B1D0E14006E.set preserve=no
        m_strEnd = value;
        //## end segment::ExportReportAuditSegment::setEnd%4B1D0E14006E.set
      }


      //## Attribute: DATE_RECON%4B1D0E14007D
      void setDATE_RECON (const string& value)
      {
        //## begin segment::ExportReportAuditSegment::setDATE_RECON%4B1D0E14007D.set preserve=no
        m_strDATE_RECON = value;
        //## end segment::ExportReportAuditSegment::setDATE_RECON%4B1D0E14007D.set
      }


      //## Attribute: ENTITY_ID%4B1D0E14008C
      void setENTITY_ID (const string& value)
      {
        //## begin segment::ExportReportAuditSegment::setENTITY_ID%4B1D0E14008C.set preserve=no
        m_strENTITY_ID = value;
        //## end segment::ExportReportAuditSegment::setENTITY_ID%4B1D0E14008C.set
      }


      //## Attribute: File%4B1D0E14008D
      void setFile (const string& value)
      {
        //## begin segment::ExportReportAuditSegment::setFile%4B1D0E14008D.set preserve=no
        m_strFile = value;
        //## end segment::ExportReportAuditSegment::setFile%4B1D0E14008D.set
      }


      //## Attribute: Path%4B1D0E14009C
      void setPath (const string& value)
      {
        //## begin segment::ExportReportAuditSegment::setPath%4B1D0E14009C.set preserve=no
        m_strPath = value;
        //## end segment::ExportReportAuditSegment::setPath%4B1D0E14009C.set
      }


      //## Attribute: Server%4B1D0E1400AB
      void setServer (const string& value)
      {
        //## begin segment::ExportReportAuditSegment::setServer%4B1D0E1400AB.set preserve=no
        m_strServer = value;
        //## end segment::ExportReportAuditSegment::setServer%4B1D0E1400AB.set
      }


      //## Attribute: Start%4B1D0E1400AC
      void setStart (const string& value)
      {
        //## begin segment::ExportReportAuditSegment::setStart%4B1D0E1400AC.set preserve=no
        m_strStart = value;
        //## end segment::ExportReportAuditSegment::setStart%4B1D0E1400AC.set
      }


    // Additional Public Declarations
      //## begin segment::ExportReportAuditSegment%4B1D0D9C038A.public preserve=yes
      //## end segment::ExportReportAuditSegment%4B1D0D9C038A.public

  protected:
    // Additional Protected Declarations
      //## begin segment::ExportReportAuditSegment%4B1D0D9C038A.protected preserve=yes
      //## end segment::ExportReportAuditSegment%4B1D0D9C038A.protected

  private:
    // Additional Private Declarations
      //## begin segment::ExportReportAuditSegment%4B1D0D9C038A.private preserve=yes
      //## end segment::ExportReportAuditSegment%4B1D0D9C038A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin segment::ExportReportAuditSegment::Contact%4B1D0E14006D.attr preserve=no  public: string {V} 
      string m_strContact;
      //## end segment::ExportReportAuditSegment::Contact%4B1D0E14006D.attr

      //## begin segment::ExportReportAuditSegment::End%4B1D0E14006E.attr preserve=no  public: string {V} 
      string m_strEnd;
      //## end segment::ExportReportAuditSegment::End%4B1D0E14006E.attr

      //## begin segment::ExportReportAuditSegment::DATE_RECON%4B1D0E14007D.attr preserve=no  public: string {V} 
      string m_strDATE_RECON;
      //## end segment::ExportReportAuditSegment::DATE_RECON%4B1D0E14007D.attr

      //## begin segment::ExportReportAuditSegment::ENTITY_ID%4B1D0E14008C.attr preserve=no  public: string {V} 
      string m_strENTITY_ID;
      //## end segment::ExportReportAuditSegment::ENTITY_ID%4B1D0E14008C.attr

      //## begin segment::ExportReportAuditSegment::File%4B1D0E14008D.attr preserve=no  public: string {V} 
      string m_strFile;
      //## end segment::ExportReportAuditSegment::File%4B1D0E14008D.attr

      //## begin segment::ExportReportAuditSegment::Path%4B1D0E14009C.attr preserve=no  public: string {V} 
      string m_strPath;
      //## end segment::ExportReportAuditSegment::Path%4B1D0E14009C.attr

      //## begin segment::ExportReportAuditSegment::Server%4B1D0E1400AB.attr preserve=no  public: string {V} 
      string m_strServer;
      //## end segment::ExportReportAuditSegment::Server%4B1D0E1400AB.attr

      //## begin segment::ExportReportAuditSegment::Start%4B1D0E1400AC.attr preserve=no  public: string {V} 
      string m_strStart;
      //## end segment::ExportReportAuditSegment::Start%4B1D0E1400AC.attr

      //## Attribute: Timestamp%4B1D0E1400BB
      //## begin segment::ExportReportAuditSegment::Timestamp%4B1D0E1400BB.attr preserve=no  public: string {V} 
      string m_strTimestamp;
      //## end segment::ExportReportAuditSegment::Timestamp%4B1D0E1400BB.attr

    // Additional Implementation Declarations
      //## begin segment::ExportReportAuditSegment%4B1D0D9C038A.implementation preserve=yes
      //## end segment::ExportReportAuditSegment%4B1D0D9C038A.implementation

};

//## begin segment::ExportReportAuditSegment%4B1D0D9C038A.postscript preserve=yes
//## end segment::ExportReportAuditSegment%4B1D0D9C038A.postscript

} // namespace segment

//## begin module%4B1D0E7C00AB.epilog preserve=yes
//## end module%4B1D0E7C00AB.epilog


#endif
