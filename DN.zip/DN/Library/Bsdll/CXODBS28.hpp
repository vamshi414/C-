//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%51C358500208.cm preserve=no
//	$Date:   Sep 26 2013 10:56:54  $ $Author:   e1009652  $ $Revision:   1.3  $
//## end module%51C358500208.cm

//## begin module%51C358500208.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%51C358500208.cp

//## Module: CXOSBS28%51C358500208; Package specification
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Source file: C:\bV02.4B.R001\Windows\Build\ConnexPlatform\Server\Library\Bsdll\CXODBS28.hpp

#ifndef CXOSBS28_h
#define CXOSBS28_h 1

//## begin module%51C358500208.additionalIncludes preserve=no
//## end module%51C358500208.additionalIncludes

//## begin module%51C358500208.includes preserve=yes
struct segAuditEventSegment
{
   char  sSegmentID[4];
   char  sSegmentVersion[4];
   char  sLengthOfSegment[8];
   char  sTSTAMP_CREATED[16];
   char  sTASKID[7];
   char  sSEQ_NO[4];
   char  sCUST_ID[4];
   char  cCUST_STAT;
   char  sUSER_ID[8];
   char  sEVENT_TYPE[4];
   char  sRETURN_CODE[4];
   char  sORIGINATION[256];
   char  sRESOURCE_NAME[64];
   char  sRESOURCE_KEY[2048];
};
//## end module%51C358500208.includes

#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class GMTClock;
class Clock;

} // namespace timer

//## begin module%51C358500208.declarations preserve=no
//## end module%51C358500208.declarations

//## begin module%51C358500208.additionalDeclarations preserve=yes
//## end module%51C358500208.additionalDeclarations


//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::AuditEventSegment%51C357660313.preface preserve=yes
//## end segment::AuditEventSegment%51C357660313.preface

//## Class: AuditEventSegment%51C357660313
//## Category: Connex Library::Segment_CAT%3471F0BE0219
//## Subsystem: Connex Library::BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%522F71AF0279;timer::Clock { -> F}
//## Uses: <unnamed>%522F71C10150;timer::GMTClock { -> F}

class DllExport AuditEventSegment : public PersistentSegment  //## Inherits: <unnamed>%51C882B700AC
{
  //## begin segment::AuditEventSegment%51C357660313.initialDeclarations preserve=yes
  //## end segment::AuditEventSegment%51C357660313.initialDeclarations

  public:
    //## Constructors (generated)
      AuditEventSegment();

      AuditEventSegment(const AuditEventSegment &right);

    //## Destructor (generated)
      virtual ~AuditEventSegment();

    //## Assignment Operation (generated)
      AuditEventSegment & operator=(const AuditEventSegment &right);


    //## Other Operations (specified)
      //## Operation: _field%51DAFE7802EC
      virtual bool _field (const char* pszName, string& strValue, bool bDescription = false, bool bFormat = true) const;

      //## Operation: fields%51C3613F00E0
      virtual struct  Fields* fields () const;

      //## Operation: instance%51D32BBF0183
      static AuditEventSegment* instance ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: AUDITENV%522F74840029
      const string& getAUDITENV () const
      {
        //## begin segment::AuditEventSegment::getAUDITENV%522F74840029.get preserve=no
        return m_strAUDITENV;
        //## end segment::AuditEventSegment::getAUDITENV%522F74840029.get
      }

      void setAUDITENV (const string& value)
      {
        //## begin segment::AuditEventSegment::setAUDITENV%522F74840029.set preserve=no
        m_strAUDITENV = value;
        //## end segment::AuditEventSegment::setAUDITENV%522F74840029.set
      }


      //## Attribute: CUST_ID%51C36945038F
      const string& getCUST_ID () const
      {
        //## begin segment::AuditEventSegment::getCUST_ID%51C36945038F.get preserve=no
        return m_strCUST_ID;
        //## end segment::AuditEventSegment::getCUST_ID%51C36945038F.get
      }

      void setCUST_ID (const string& value)
      {
        //## begin segment::AuditEventSegment::setCUST_ID%51C36945038F.set preserve=no
        m_strCUST_ID = value;
        //## end segment::AuditEventSegment::setCUST_ID%51C36945038F.set
      }


      //## Attribute: CUST_STAT%51C4BF35013C
      const string& getCUST_STAT () const
      {
        //## begin segment::AuditEventSegment::getCUST_STAT%51C4BF35013C.get preserve=no
        return m_strCUST_STAT;
        //## end segment::AuditEventSegment::getCUST_STAT%51C4BF35013C.get
      }

      void setCUST_STAT (const string& value)
      {
        //## begin segment::AuditEventSegment::setCUST_STAT%51C4BF35013C.set preserve=no
        m_strCUST_STAT = value;
        //## end segment::AuditEventSegment::setCUST_STAT%51C4BF35013C.set
      }


      //## Attribute: EVENT_TYPE%51C4BF9B0088
      const short& getEVENT_TYPE () const
      {
        //## begin segment::AuditEventSegment::getEVENT_TYPE%51C4BF9B0088.get preserve=no
        return m_lEVENT_TYPE;
        //## end segment::AuditEventSegment::getEVENT_TYPE%51C4BF9B0088.get
      }

      void setEVENT_TYPE (const short& value)
      {
        //## begin segment::AuditEventSegment::setEVENT_TYPE%51C4BF9B0088.set preserve=no
        m_lEVENT_TYPE = value;
        //## end segment::AuditEventSegment::setEVENT_TYPE%51C4BF9B0088.set
      }


      //## Attribute: ORIGINATION%51C369450396
      const string& getORIGINATION () const
      {
        //## begin segment::AuditEventSegment::getORIGINATION%51C369450396.get preserve=no
        return m_strORIGINATION;
        //## end segment::AuditEventSegment::getORIGINATION%51C369450396.get
      }

      void setORIGINATION (const string& value)
      {
        //## begin segment::AuditEventSegment::setORIGINATION%51C369450396.set preserve=no
        m_strORIGINATION = value;
        //## end segment::AuditEventSegment::setORIGINATION%51C369450396.set
      }


      //## Attribute: PRODUCT%522F748402A9
      const string& getPRODUCT () const
      {
        //## begin segment::AuditEventSegment::getPRODUCT%522F748402A9.get preserve=no
        return m_strPRODUCT;
        //## end segment::AuditEventSegment::getPRODUCT%522F748402A9.get
      }

      void setPRODUCT (const string& value)
      {
        //## begin segment::AuditEventSegment::setPRODUCT%522F748402A9.set preserve=no
        m_strPRODUCT = value;
        //## end segment::AuditEventSegment::setPRODUCT%522F748402A9.set
      }


      //## Attribute: RESOURCE_KEY%51C4BF5701B4
      const string& getRESOURCE_KEY () const
      {
        //## begin segment::AuditEventSegment::getRESOURCE_KEY%51C4BF5701B4.get preserve=no
        return m_strRESOURCE_KEY;
        //## end segment::AuditEventSegment::getRESOURCE_KEY%51C4BF5701B4.get
      }

      void setRESOURCE_KEY (const string& value)
      {
        //## begin segment::AuditEventSegment::setRESOURCE_KEY%51C4BF5701B4.set preserve=no
        m_strRESOURCE_KEY = value;
        //## end segment::AuditEventSegment::setRESOURCE_KEY%51C4BF5701B4.set
      }


      //## Attribute: RESOURCE_NAME%51C4BF55029C
      const string& getRESOURCE_NAME () const
      {
        //## begin segment::AuditEventSegment::getRESOURCE_NAME%51C4BF55029C.get preserve=no
        return m_strRESOURCE_NAME;
        //## end segment::AuditEventSegment::getRESOURCE_NAME%51C4BF55029C.get
      }

      void setRESOURCE_NAME (const string& value)
      {
        //## begin segment::AuditEventSegment::setRESOURCE_NAME%51C4BF55029C.set preserve=no
        m_strRESOURCE_NAME = value;
        //## end segment::AuditEventSegment::setRESOURCE_NAME%51C4BF55029C.set
      }


      //## Attribute: RETURN_CODE%51C4BFA50129
      const short& getRETURN_CODE () const
      {
        //## begin segment::AuditEventSegment::getRETURN_CODE%51C4BFA50129.get preserve=no
        return m_lRETURN_CODE;
        //## end segment::AuditEventSegment::getRETURN_CODE%51C4BFA50129.get
      }

      void setRETURN_CODE (const short& value)
      {
        //## begin segment::AuditEventSegment::setRETURN_CODE%51C4BFA50129.set preserve=no
        m_lRETURN_CODE = value;
        //## end segment::AuditEventSegment::setRETURN_CODE%51C4BFA50129.set
      }


      //## Attribute: SEQ_NO%51C369450384
      const short& getSEQ_NO () const
      {
        //## begin segment::AuditEventSegment::getSEQ_NO%51C369450384.get preserve=no
        return m_lSEQ_NO;
        //## end segment::AuditEventSegment::getSEQ_NO%51C369450384.get
      }

      void setSEQ_NO (const short& value)
      {
        //## begin segment::AuditEventSegment::setSEQ_NO%51C369450384.set preserve=no
        m_lSEQ_NO = value;
        //## end segment::AuditEventSegment::setSEQ_NO%51C369450384.set
      }


      //## Attribute: TASKID%51C4BF6F0093
      const string& getTASKID () const
      {
        //## begin segment::AuditEventSegment::getTASKID%51C4BF6F0093.get preserve=no
        return m_strTASKID;
        //## end segment::AuditEventSegment::getTASKID%51C4BF6F0093.get
      }

      void setTASKID (const string& value)
      {
        //## begin segment::AuditEventSegment::setTASKID%51C4BF6F0093.set preserve=no
        m_strTASKID = value;
        //## end segment::AuditEventSegment::setTASKID%51C4BF6F0093.set
      }


      //## Attribute: TSTAMP_CREATED%51C36945039B
      const string& getTSTAMP_CREATED () const
      {
        //## begin segment::AuditEventSegment::getTSTAMP_CREATED%51C36945039B.get preserve=no
        return m_strTSTAMP_CREATED;
        //## end segment::AuditEventSegment::getTSTAMP_CREATED%51C36945039B.get
      }

      void setTSTAMP_CREATED (const string& value)
      {
        //## begin segment::AuditEventSegment::setTSTAMP_CREATED%51C36945039B.set preserve=no
        m_strTSTAMP_CREATED = value;
        //## end segment::AuditEventSegment::setTSTAMP_CREATED%51C36945039B.set
      }


      //## Attribute: USER_ID%51C3694503B5
      const string& getUSER_ID () const
      {
        //## begin segment::AuditEventSegment::getUSER_ID%51C3694503B5.get preserve=no
        return m_strUSER_ID;
        //## end segment::AuditEventSegment::getUSER_ID%51C3694503B5.get
      }

      void setUSER_ID (const string& value)
      {
        //## begin segment::AuditEventSegment::setUSER_ID%51C3694503B5.set preserve=no
        m_strUSER_ID = value;
        //## end segment::AuditEventSegment::setUSER_ID%51C3694503B5.set
      }


    // Additional Public Declarations
      //## begin segment::AuditEventSegment%51C357660313.public preserve=yes
      const int& getDX_FILE_ID () const
      {
        return m_iDX_FILE_ID;
      }

      void setDX_FILE_ID (const int& value)
      {
        m_iDX_FILE_ID = value;
      }
      //## end segment::AuditEventSegment%51C357660313.public
  protected:
    // Additional Protected Declarations
      //## begin segment::AuditEventSegment%51C357660313.protected preserve=yes
      //## end segment::AuditEventSegment%51C357660313.protected

  private:
    // Additional Private Declarations
      //## begin segment::AuditEventSegment%51C357660313.private preserve=yes
      //## end segment::AuditEventSegment%51C357660313.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin segment::AuditEventSegment::AUDITENV%522F74840029.attr preserve=no  public: string {U} 
      string m_strAUDITENV;
      //## end segment::AuditEventSegment::AUDITENV%522F74840029.attr

      //## begin segment::AuditEventSegment::CUST_ID%51C36945038F.attr preserve=no  public: string {U} 
      string m_strCUST_ID;
      //## end segment::AuditEventSegment::CUST_ID%51C36945038F.attr

      //## begin segment::AuditEventSegment::CUST_STAT%51C4BF35013C.attr preserve=no  public: string {U} 
      string m_strCUST_STAT;
      //## end segment::AuditEventSegment::CUST_STAT%51C4BF35013C.attr

      //## begin segment::AuditEventSegment::EVENT_TYPE%51C4BF9B0088.attr preserve=no  public: short {U} 0
      short m_lEVENT_TYPE;
      //## end segment::AuditEventSegment::EVENT_TYPE%51C4BF9B0088.attr

      //## begin segment::AuditEventSegment::ORIGINATION%51C369450396.attr preserve=no  public: string {U} 
      string m_strORIGINATION;
      //## end segment::AuditEventSegment::ORIGINATION%51C369450396.attr

      //## begin segment::AuditEventSegment::PRODUCT%522F748402A9.attr preserve=no  public: string {U} 
      string m_strPRODUCT;
      //## end segment::AuditEventSegment::PRODUCT%522F748402A9.attr

      //## begin segment::AuditEventSegment::RESOURCE_KEY%51C4BF5701B4.attr preserve=no  public: string {U} 
      string m_strRESOURCE_KEY;
      //## end segment::AuditEventSegment::RESOURCE_KEY%51C4BF5701B4.attr

      //## begin segment::AuditEventSegment::RESOURCE_NAME%51C4BF55029C.attr preserve=no  public: string {U} 
      string m_strRESOURCE_NAME;
      //## end segment::AuditEventSegment::RESOURCE_NAME%51C4BF55029C.attr

      //## begin segment::AuditEventSegment::RETURN_CODE%51C4BFA50129.attr preserve=no  public: short {U} 0
      short m_lRETURN_CODE;
      //## end segment::AuditEventSegment::RETURN_CODE%51C4BFA50129.attr

      //## begin segment::AuditEventSegment::SEQ_NO%51C369450384.attr preserve=no  public: short {U} 0
      short m_lSEQ_NO;
      //## end segment::AuditEventSegment::SEQ_NO%51C369450384.attr

      //## begin segment::AuditEventSegment::TASKID%51C4BF6F0093.attr preserve=no  public: string {U} 
      string m_strTASKID;
      //## end segment::AuditEventSegment::TASKID%51C4BF6F0093.attr

      //## begin segment::AuditEventSegment::TSTAMP_CREATED%51C36945039B.attr preserve=no  public: string {U} 
      string m_strTSTAMP_CREATED;
      //## end segment::AuditEventSegment::TSTAMP_CREATED%51C36945039B.attr

      //## begin segment::AuditEventSegment::USER_ID%51C3694503B5.attr preserve=no  public: string {U} 
      string m_strUSER_ID;
      //## end segment::AuditEventSegment::USER_ID%51C3694503B5.attr

      //## Attribute: Instance%51D332BE03AD
      //## begin segment::AuditEventSegment::Instance%51D332BE03AD.attr preserve=no  private: static AuditEventSegment {R} 0
      static AuditEventSegment *m_pInstance;
      //## end segment::AuditEventSegment::Instance%51D332BE03AD.attr

    // Additional Implementation Declarations
      //## begin segment::AuditEventSegment%51C357660313.implementation preserve=yes
      int m_iDX_FILE_ID;
      //## end segment::AuditEventSegment%51C357660313.implementation
};

//## begin segment::AuditEventSegment%51C357660313.postscript preserve=yes
//## end segment::AuditEventSegment%51C357660313.postscript

} // namespace segment

//## begin module%51C358500208.epilog preserve=yes
using namespace segment;
//## end module%51C358500208.epilog


#endif
