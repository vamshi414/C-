//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%37728D5601C6.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%37728D5601C6.cm

//## begin module%37728D5601C6.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%37728D5601C6.cp

//## Module: CXOSBS05%37728D5601C6; Package specification
//## Subsystem: BSDLL%394E1F8C0345
//## Source file: C:\Pvcswork\Dn\Server\Library\Bsdll\CXODBS05.hpp

#ifndef CXOSBS05_h
#define CXOSBS05_h 1

//## begin module%37728D5601C6.additionalIncludes preserve=no
//## end module%37728D5601C6.additionalIncludes

//## begin module%37728D5601C6.includes preserve=yes
// $Date:   Jun 30 2006 11:35:16  $ $Author:   D02405  $ $Revision:   1.3  $
#include <vector>
//## end module%37728D5601C6.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Foundation::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;

} // namespace segment

//## begin module%37728D5601C6.declarations preserve=no
//## end module%37728D5601C6.declarations

//## begin module%37728D5601C6.additionalDeclarations preserve=yes
//## end module%37728D5601C6.additionalDeclarations


namespace segment {
//## begin segment%3471F0BE0219.initialDeclarations preserve=yes
//## end segment%3471F0BE0219.initialDeclarations

//## begin segment::Response%37728C1802AF.preface preserve=yes
//## end segment::Response%37728C1802AF.preface

//## Class: Response%37728C1802AF
//## Category: Connex Foundation::Segment_CAT%3471F0BE0219
//## Subsystem: BSDLL%394E1F8C0345
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3BFE9BC103B9;InformationSegment { -> F}

class DllExport Response : public reusable::Object  //## Inherits: <unnamed>%37728C3F0161
{
  //## begin segment::Response%37728C1802AF.initialDeclarations preserve=yes
  //## end segment::Response%37728C1802AF.initialDeclarations

  public:
    //## Constructors (generated)
      Response();

    //## Destructor (generated)
      virtual ~Response();


    //## Other Operations (specified)
      //## Operation: addSegment%37728CC902DC
      void addSegment (Segment* pSegment);

      //## Operation: parse%37728CEC0250
      int parse (const char* psBuffer, int lBuffer);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Error%37728CA203A8
      const string& getError () const
      {
        //## begin segment::Response::getError%37728CA203A8.get preserve=no
        return m_strError;
        //## end segment::Response::getError%37728CA203A8.get
      }


    // Additional Public Declarations
      //## begin segment::Response%37728C1802AF.public preserve=yes
      //## end segment::Response%37728C1802AF.public

  protected:
    // Additional Protected Declarations
      //## begin segment::Response%37728C1802AF.protected preserve=yes
      //## end segment::Response%37728C1802AF.protected

  private:
    // Additional Private Declarations
      //## begin segment::Response%37728C1802AF.private preserve=yes
      //## end segment::Response%37728C1802AF.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin segment::Response::Error%37728CA203A8.attr preserve=no  public: string {V} 
      string m_strError;
      //## end segment::Response::Error%37728CA203A8.attr

    // Data Members for Associations

      //## Association: Connex Foundation::Segment_CAT::<unnamed>%3BFE9BCC003E
      //## Role: Response::<m_hSegment>%3BFE9BCC01E4
      //## begin segment::Response::<m_hSegment>%3BFE9BCC01E4.role preserve=no  public: segment::Segment { -> 0..nRHgN}
      vector<Segment*> m_hSegment;
      //## end segment::Response::<m_hSegment>%3BFE9BCC01E4.role

    // Additional Implementation Declarations
      //## begin segment::Response%37728C1802AF.implementation preserve=yes
      //## end segment::Response%37728C1802AF.implementation

};

//## begin segment::Response%37728C1802AF.postscript preserve=yes
//## end segment::Response%37728C1802AF.postscript

} // namespace segment

//## begin module%37728D5601C6.epilog preserve=yes
using namespace segment;
//## end module%37728D5601C6.epilog


#endif
