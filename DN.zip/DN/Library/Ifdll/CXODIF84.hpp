//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%665A018003CF.cm preserve=no
//## end module%665A018003CF.cm

//## begin module%665A018003CF.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%665A018003CF.cp

//## Module: CXOSIF84%665A018003CF; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF84.hpp

#ifndef CXOSIF84_h
#define CXOSIF84_h 1

//## begin module%665A018003CF.additionalIncludes preserve=no
//## end module%665A018003CF.additionalIncludes

//## begin module%665A018003CF.includes preserve=yes
//## end module%665A018003CF.includes

#ifndef CXOSIF55_h
#include "CXODIF55.hpp"
#endif
#ifndef CXOSRU14_h
#include "CXODRU14.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
//## begin module%665A018003CF.declarations preserve=no
//## end module%665A018003CF.declarations

//## begin module%665A018003CF.additionalDeclarations preserve=yes
//## end module%665A018003CF.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Batch%665A007D0062.preface preserve=yes
//## end IF::Batch%665A007D0062.preface

//## Class: Batch%665A007D0062
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%665A0B690364;reusable::Signal { -> }
//## Uses: <unnamed>%665A0B6E0099;ExternalQueue { -> }

class DllExport Batch : public reusable::Handler  //## Inherits: <unnamed>%665A024C0374
{
  //## begin IF::Batch%665A007D0062.initialDeclarations preserve=yes
public:
   enum State
   {
      IDLE,
      BUSY,
      HASH_SENT,
      HASH_RECEIVED,
      RESTART
   };
  //## end IF::Batch%665A007D0062.initialDeclarations

  public:
    //## Constructors (generated)
      Batch();

    //## Destructor (generated)
      virtual ~Batch();


    //## Other Operations (specified)
      //## Operation: instance%665A05180273
      static Batch* instance ();

      //## Operation: add%665A0A7A03A3
      virtual void add (reusable::Signal* pSignal, IF::ExternalQueue* pQueue);

      //## Operation: addRecord%665A153902CB
      virtual void addRecord (unsigned int iHash);

      //## Operation: beginBlock%665A162B004C
      virtual void beginBlock ();

      //## Operation: endBlock%665A165F0083
      virtual void endBlock ();

      //## Operation: getSize%66969403015D
      int getSize (int iIndex = 0) const
      {
        //## begin IF::Batch::getSize%66969403015D.body preserve=yes
         return(m_iSize[iIndex]);
        //## end IF::Batch::getSize%66969403015D.body
      }

      //## Operation: onConfirm%665A16740071
      virtual void onConfirm ();

      //## Operation: restart%665A16D40314
      virtual void restart ();

      //## Operation: setSize%669694340058
      void setSize (int iValue, int iIndex = 0)
      {
        //## begin IF::Batch::setSize%669694340058.body preserve=yes
         m_iSize[iIndex] = iValue;
        //## end IF::Batch::setSize%669694340058.body
      }

      //## Operation: update%665A172D00F7
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

      //## Operation: update%665A175000E8
      virtual void update (const string& strQueueName, const string& strTimestamp);

      //## Operation: updateLogConfirmation%665A17B5010A
      virtual void updateLogConfirmation ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Count%665A02EE036B
      const int& getCount () const
      {
        //## begin IF::Batch::getCount%665A02EE036B.get preserve=no
        return m_iCount;
        //## end IF::Batch::getCount%665A02EE036B.get
      }

      void setCount (const int& value)
      {
        //## begin IF::Batch::setCount%665A02EE036B.set preserve=no
        m_iCount = value;
        //## end IF::Batch::setCount%665A02EE036B.set
      }


      //## Attribute: DST%665A0357019D
      const bool& getDST () const
      {
        //## begin IF::Batch::getDST%665A0357019D.get preserve=no
        return m_bDST;
        //## end IF::Batch::getDST%665A0357019D.get
      }

      void setDST (const bool& value)
      {
        //## begin IF::Batch::setDST%665A0357019D.set preserve=no
        m_bDST = value;
        //## end IF::Batch::setDST%665A0357019D.set
      }


      //## Attribute: GMTOffset%665A039C021B
      const int& getGMTOffset () const
      {
        //## begin IF::Batch::getGMTOffset%665A039C021B.get preserve=no
        return m_iGMTOffset;
        //## end IF::Batch::getGMTOffset%665A039C021B.get
      }

      void setGMTOffset (const int& value)
      {
        //## begin IF::Batch::setGMTOffset%665A039C021B.set preserve=no
        m_iGMTOffset = value;
        //## end IF::Batch::setGMTOffset%665A039C021B.set
      }


      //## Attribute: Index%665A03B601DF
      const unsigned int& getIndex () const
      {
        //## begin IF::Batch::getIndex%665A03B601DF.get preserve=no
        return m_iIndex;
        //## end IF::Batch::getIndex%665A03B601DF.get
      }

      void setIndex (const unsigned int& value)
      {
        //## begin IF::Batch::setIndex%665A03B601DF.set preserve=no
        m_iIndex = value;
        //## end IF::Batch::setIndex%665A03B601DF.set
      }


      //## Attribute: Number%665A03E6008F
      const int& getNumber () const
      {
        //## begin IF::Batch::getNumber%665A03E6008F.get preserve=no
        return m_iNumber;
        //## end IF::Batch::getNumber%665A03E6008F.get
      }

      void setNumber (const int& value)
      {
        //## begin IF::Batch::setNumber%665A03E6008F.set preserve=no
        m_iNumber = value;
        //## end IF::Batch::setNumber%665A03E6008F.set
      }


      //## Attribute: Restart%665A040401DF
      const int& getRestart () const
      {
        //## begin IF::Batch::getRestart%665A040401DF.get preserve=no
        return m_iRestart;
        //## end IF::Batch::getRestart%665A040401DF.get
      }

      void setRestart (const int& value)
      {
        //## begin IF::Batch::setRestart%665A040401DF.set preserve=no
        m_iRestart = value;
        //## end IF::Batch::setRestart%665A040401DF.set
      }


      //## Attribute: RestartSeconds%665A0419032F
      const int& getRestartSeconds () const
      {
        //## begin IF::Batch::getRestartSeconds%665A0419032F.get preserve=no
        return m_iRestartSeconds;
        //## end IF::Batch::getRestartSeconds%665A0419032F.get
      }

      void setRestartSeconds (const int& value)
      {
        //## begin IF::Batch::setRestartSeconds%665A0419032F.set preserve=no
        m_iRestartSeconds = value;
        //## end IF::Batch::setRestartSeconds%665A0419032F.set
      }


      //## Attribute: Rollback%665A04410051
      const int& getRollback () const
      {
        //## begin IF::Batch::getRollback%665A04410051.get preserve=no
        return m_iRollback;
        //## end IF::Batch::getRollback%665A04410051.get
      }

      void setRollback (const int& value)
      {
        //## begin IF::Batch::setRollback%665A04410051.set preserve=no
        m_iRollback = value;
        //## end IF::Batch::setRollback%665A04410051.set
      }


      //## Attribute: RollbackSeconds%665A04580224
      const int& getRollbackSeconds () const
      {
        //## begin IF::Batch::getRollbackSeconds%665A04580224.get preserve=no
        return m_iRollbackSeconds;
        //## end IF::Batch::getRollbackSeconds%665A04580224.get
      }

      void setRollbackSeconds (const int& value)
      {
        //## begin IF::Batch::setRollbackSeconds%665A04580224.set preserve=no
        m_iRollbackSeconds = value;
        //## end IF::Batch::setRollbackSeconds%665A04580224.set
      }


      //## Attribute: Ticks%665A048E0102
      const double& getTicks () const
      {
        //## begin IF::Batch::getTicks%665A048E0102.get preserve=no
        return m_dTicks;
        //## end IF::Batch::getTicks%665A048E0102.get
      }

      void setTicks (const double& value)
      {
        //## begin IF::Batch::setTicks%665A048E0102.set preserve=no
        m_dTicks = value;
        //## end IF::Batch::setTicks%665A048E0102.set
      }


      //## Attribute: Time%665A04AC0209
      const int& getTime () const
      {
        //## begin IF::Batch::getTime%665A04AC0209.get preserve=no
        return m_iTime;
        //## end IF::Batch::getTime%665A04AC0209.get
      }

      void setTime (const int& value)
      {
        //## begin IF::Batch::setTime%665A04AC0209.set preserve=no
        m_iTime = value;
        //## end IF::Batch::setTime%665A04AC0209.set
      }


      //## Attribute: State%665A196E00CD
      const State& getState () const
      {
        //## begin IF::Batch::getState%665A196E00CD.get preserve=no
        return m_nState;
        //## end IF::Batch::getState%665A196E00CD.get
      }

      void setState (const State& value)
      {
        //## begin IF::Batch::setState%665A196E00CD.set preserve=no
        m_nState = value;
        //## end IF::Batch::setState%665A196E00CD.set
      }


    // Additional Public Declarations
      //## begin IF::Batch%665A007D0062.public preserve=yes
      //## end IF::Batch%665A007D0062.public

  protected:
    // Data Members for Class Attributes

      //## begin IF::Batch::Count%665A02EE036B.attr preserve=no  public: int {U} 0
      int m_iCount;
      //## end IF::Batch::Count%665A02EE036B.attr

      //## begin IF::Batch::DST%665A0357019D.attr preserve=no  public: bool {U} false
      bool m_bDST;
      //## end IF::Batch::DST%665A0357019D.attr

      //## begin IF::Batch::GMTOffset%665A039C021B.attr preserve=no  public: int {U} 0
      int m_iGMTOffset;
      //## end IF::Batch::GMTOffset%665A039C021B.attr

      //## begin IF::Batch::Index%665A03B601DF.attr preserve=no  public: unsigned int {U} 0
      unsigned int m_iIndex;
      //## end IF::Batch::Index%665A03B601DF.attr

      //## Attribute: Instance%665A04D101EA
      //## begin IF::Batch::Instance%665A04D101EA.attr preserve=no  private: static Batch* {U} 0
      static Batch* m_pInstance;
      //## end IF::Batch::Instance%665A04D101EA.attr

      //## begin IF::Batch::Number%665A03E6008F.attr preserve=no  public: int {U} 0
      int m_iNumber;
      //## end IF::Batch::Number%665A03E6008F.attr

      //## begin IF::Batch::Restart%665A040401DF.attr preserve=no  public: int {U} 0
      int m_iRestart;
      //## end IF::Batch::Restart%665A040401DF.attr

      //## begin IF::Batch::RestartSeconds%665A0419032F.attr preserve=no  public: int {U} 900
      int m_iRestartSeconds;
      //## end IF::Batch::RestartSeconds%665A0419032F.attr

      //## begin IF::Batch::Rollback%665A04410051.attr preserve=no  public: int {U} 0
      int m_iRollback;
      //## end IF::Batch::Rollback%665A04410051.attr

      //## begin IF::Batch::RollbackSeconds%665A04580224.attr preserve=no  public: int {U} 300
      int m_iRollbackSeconds;
      //## end IF::Batch::RollbackSeconds%665A04580224.attr

      //## Attribute: Size%665A047B0151
      //## begin IF::Batch::Size%665A047B0151.attr preserve=no  public: int[2] {U} 
      int m_iSize[2];
      //## end IF::Batch::Size%665A047B0151.attr

      //## begin IF::Batch::Ticks%665A048E0102.attr preserve=no  public: double {U} 0
      double m_dTicks;
      //## end IF::Batch::Ticks%665A048E0102.attr

      //## begin IF::Batch::Time%665A04AC0209.attr preserve=no  public: int {U} 30
      int m_iTime;
      //## end IF::Batch::Time%665A04AC0209.attr

      //## begin IF::Batch::State%665A196E00CD.attr preserve=no  public: State {U} IDLE
      State m_nState;
      //## end IF::Batch::State%665A196E00CD.attr

    // Additional Protected Declarations
      //## begin IF::Batch%665A007D0062.protected preserve=yes
      //## end IF::Batch%665A007D0062.protected

  private:
    // Additional Private Declarations
      //## begin IF::Batch%665A007D0062.private preserve=yes
      //## end IF::Batch%665A007D0062.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::Batch%665A007D0062.implementation preserve=yes
      //## end IF::Batch%665A007D0062.implementation

};

//## begin IF::Batch%665A007D0062.postscript preserve=yes
//## end IF::Batch%665A007D0062.postscript

} // namespace IF

//## begin module%665A018003CF.epilog preserve=yes
using namespace IF;
//## end module%665A018003CF.epilog


#endif
