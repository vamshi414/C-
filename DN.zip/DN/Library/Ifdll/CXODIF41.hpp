//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3DE24A350251.cm preserve=no
//	$Date:   Jun 22 2020 13:35:44  $ $Author:   e1009839  $ $Revision:   1.7  $
//## end module%3DE24A350251.cm

//## begin module%3DE24A350251.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%3DE24A350251.cp

//## Module: CXOSIF41%3DE24A350251; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF41.hpp

#ifndef CXOSIF41_h
#define CXOSIF41_h 1

//## begin module%3DE24A350251.additionalIncludes preserve=no
//## end module%3DE24A350251.additionalIncludes

//## begin module%3DE24A350251.includes preserve=yes
// $Date:   Jun 22 2020 13:35:44  $ $Author:   e1009839  $ $Revision:   1.7  $
//## end module%3DE24A350251.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;

} // namespace IF

//## begin module%3DE24A350251.declarations preserve=no
//## end module%3DE24A350251.declarations

//## begin module%3DE24A350251.additionalDeclarations preserve=yes
//## end module%3DE24A350251.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::VariableBlockFile%3DE24944000F.preface preserve=yes
//## end IF::VariableBlockFile%3DE24944000F.preface

//## Class: VariableBlockFile%3DE24944000F
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FB804BC0017;Trace { -> F}

class DllExport VariableBlockFile : public FlatFile  //## Inherits: <unnamed>%3DE2495A03C8
{
  //## begin IF::VariableBlockFile%3DE24944000F.initialDeclarations preserve=yes
  public:
      enum Format
      {
         UNKNOWN,
         BDW_RDW,
         RDW_1014,
         RDW
      };
  //## end IF::VariableBlockFile%3DE24944000F.initialDeclarations

  public:
    //## Constructors (generated)
      VariableBlockFile();

    //## Constructors (specified)
      //## Operation: VariableBlockFile%3DEB777C00EA
      VariableBlockFile (const char* pszName);

    //## Destructor (generated)
      virtual ~VariableBlockFile();


    //## Other Operations (specified)
      //## Operation: close%3F9DE35F002F
      virtual bool close ();

      //## Operation: flush%3F9DDDE10127
      virtual bool flush ();

      //## Operation: open%3F9DF4C4006E
      virtual bool open (enum OpenType nOpenType = CX_OPEN_INPUT);

      //## Operation: read%3DE24AB80261
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool* pbReadError = NULL);

      //## Operation: write%3F9DAD3301E6
      virtual bool write (char* psBuffer, int lRecordLength);

    // Additional Public Declarations
      //## begin IF::VariableBlockFile%3DE24944000F.public preserve=yes
      //## end IF::VariableBlockFile%3DE24944000F.public

  protected:
    // Additional Protected Declarations
      //## begin IF::VariableBlockFile%3DE24944000F.protected preserve=yes
      //## end IF::VariableBlockFile%3DE24944000F.protected

  private:

    //## Other Operations (specified)
      //## Operation: writeBlock%3F9DE21A028A
      bool writeBlock ();

    // Additional Private Declarations
      //## begin IF::VariableBlockFile%3DE24944000F.private preserve=yes
#ifdef _WIN64
       int cxiget(long long* plFile,char* psBuffer,int* plBufferLength,int* plRecordLength,int* plRC);
#else
       int cxiget(long* plFile,char* psBuffer,int* plBufferLength,int* plRecordLength,int* plRC);
#endif
      //## end IF::VariableBlockFile%3DE24944000F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%3DEB6A260196
      //## begin IF::VariableBlockFile::Buffer%3DEB6A260196.attr preserve=no  private: char* {V} 0
      char* m_psBuffer;
      //## end IF::VariableBlockFile::Buffer%3DEB6A260196.attr

      //## Attribute: BufferLength%3DEB6D37037A
      //## begin IF::VariableBlockFile::BufferLength%3DEB6D37037A.attr preserve=no  private: int {V} 32768
      int m_lBufferLength;
      //## end IF::VariableBlockFile::BufferLength%3DEB6D37037A.attr

      //## Attribute: Cursor%3DE24ADB02DE
      //## begin IF::VariableBlockFile::Cursor%3DE24ADB02DE.attr preserve=no  private: char* {V} 0
      char* m_psCursor;
      //## end IF::VariableBlockFile::Cursor%3DE24ADB02DE.attr

      //## Attribute: Counter%3DE24B1E0271
      //## begin IF::VariableBlockFile::Counter%3DE24B1E0271.attr preserve=no  private: int {U} 0
      int m_lCounter;
      //## end IF::VariableBlockFile::Counter%3DE24B1E0271.attr

      //## Attribute: Writing%3F9DF50D0091
      //## begin IF::VariableBlockFile::Writing%3F9DF50D0091.attr preserve=no  private: bool {U} false
      bool m_bWriting;
      //## end IF::VariableBlockFile::Writing%3F9DF50D0091.attr

    // Additional Implementation Declarations
      //## begin IF::VariableBlockFile%3DE24944000F.implementation preserve=yes
      enum Format m_siFormat;
      //## end IF::VariableBlockFile%3DE24944000F.implementation

};

//## begin IF::VariableBlockFile%3DE24944000F.postscript preserve=yes
//## end IF::VariableBlockFile%3DE24944000F.postscript

} // namespace IF

//## begin module%3DE24A350251.epilog preserve=yes
//## end module%3DE24A350251.epilog


#endif
