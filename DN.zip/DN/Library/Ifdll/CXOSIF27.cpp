//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3626706F022E.cm preserve=no
//    %X% %Q% %Z% %W%
//## end module%3626706F022E.cm

//## begin module%3626706F022E.cp preserve=no
//  Copyright (c) 1998 - 2004
//  eFunds Corporation
//## end module%3626706F022E.cp

//## Module: CXOSIF27%3626706F022E; Package body
//## Subsystem: IFDLL%3597E8E8030E
//  .
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXOSIF27.cpp

//## begin module%3626706F022E.additionalIncludes preserve=no
//## end module%3626706F022E.additionalIncludes

//## begin module%3626706F022E.includes preserve=yes
// $Date:   May 15 2020 09:01:24  $ $Author:   e1009510  $ $Revision:   1.7  $
//## end module%3626706F022E.includes

#ifndef CXOSIF26_h
#include "CXODIF26.hpp"
#endif
#ifndef CXOSIF27_h
#include "CXODIF27.hpp"
#endif


//## begin module%3626706F022E.declarations preserve=no
//## end module%3626706F022E.declarations

//## begin module%3626706F022E.additionalDeclarations preserve=yes
#ifdef MVS
extern "OS"
{
int CXCURC(int* plAmount,int* lRate,int* lFactor,char* cReciprocalFlag,const char* psProcessCode,const char* psMessageID,double* pfResult,int* plRC);
}
#endif
//## end module%3626706F022E.additionalDeclarations


//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Currency 

Currency::Currency()
  //## begin Currency::Currency%35F697410256_const.hasinit preserve=no
  //## end Currency::Currency%35F697410256_const.hasinit
  //## begin Currency::Currency%35F697410256_const.initialization preserve=yes
  //## end Currency::Currency%35F697410256_const.initialization
{
  //## begin IF::Currency::Currency%35F697410256_const.body preserve=yes
   memcpy(m_sID,"IF27",4);
  //## end IF::Currency::Currency%35F697410256_const.body
}


Currency::~Currency()
{
  //## begin IF::Currency::~Currency%35F697410256_dest.body preserve=yes
  //## end IF::Currency::~Currency%35F697410256_dest.body
}



//## Other Operations (implementation)
bool Currency::convertIBMAmt (const char* psDecimalAmount, short siLength, int lReversalFee, int lRate, int lFactor, const char *psProcessCode, const char *psMessageID, double* pfResultAmount)
{
  //## begin IF::Currency::convertIBMAmt%35F697CA0285.body preserve=yes
   int lAmount = 0;
   Decimal::asLong(psDecimalAmount,siLength,&lAmount);
   if (lReversalFee < 0)
      lAmount += lReversalFee;
   else
      lAmount -= lReversalFee;
   char cReciprocalFlag = 'N';
   int lRC = 0;
#ifdef MVS
   CXCURC(&lAmount,&lRate,&lFactor,&cReciprocalFlag,psProcessCode,psMessageID,pfResultAmount,&lRC);
#else
      double dRate = (double)lRate;
      for (int i = 0; i < lFactor; ++i)
         dRate = dRate / 10;
      *pfResultAmount = (double)lAmount * dRate;
#endif
   return (lRC == 0);
  //## end IF::Currency::convertIBMAmt%35F697CA0285.body
}

// Additional Declarations
  //## begin IF::Currency%35F697410256.declarations preserve=yes
  //## end IF::Currency%35F697410256.declarations

} // namespace IF

//## begin module%3626706F022E.epilog preserve=yes
//## end module%3626706F022E.epilog
