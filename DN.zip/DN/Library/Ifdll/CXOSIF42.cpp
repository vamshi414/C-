//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E2F1BBE00EA.cm preserve=no
//  $Date:   Jun 24 2021 11:10:58  $ $Author:   e1014059  $ $Revision:   1.10  $
//## end module%3E2F1BBE00EA.cm

//## begin module%3E2F1BBE00EA.cp preserve=no
//  Copyright (c) 1998 - 2005
//  eFunds Corporation
//## end module%3E2F1BBE00EA.cp

//## Module: CXOSIF42%3E2F1BBE00EA; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//  .
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXOSIF42.cpp

//## begin module%3E2F1BBE00EA.additionalIncludes preserve=no
//## end module%3E2F1BBE00EA.additionalIncludes

//## begin module%3E2F1BBE00EA.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif

//## end module%3E2F1BBE00EA.includes

#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF42_h
#include "CXODIF42.hpp"
#endif


//## begin module%3E2F1BBE00EA.declarations preserve=no
//## end module%3E2F1BBE00EA.declarations

//## begin module%3E2F1BBE00EA.additionalDeclarations preserve=yes
//## end module%3E2F1BBE00EA.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::CommandMessage

CommandMessage::CommandMessage()
  //## begin CommandMessage::CommandMessage%3E2F1AC60177_const.hasinit preserve=no
  //## end CommandMessage::CommandMessage%3E2F1AC60177_const.hasinit
  //## begin CommandMessage::CommandMessage%3E2F1AC60177_const.initialization preserve=yes
  //## end CommandMessage::CommandMessage%3E2F1AC60177_const.initialization
{
  //## begin IF::CommandMessage::CommandMessage%3E2F1AC60177_const.body preserve=yes
   memcpy(m_sID,"IF42",4);
  //## end IF::CommandMessage::CommandMessage%3E2F1AC60177_const.body
}

CommandMessage::CommandMessage(const CommandMessage &right)
  //## begin CommandMessage::CommandMessage%3E2F1AC60177_copy.hasinit preserve=no
  //## end CommandMessage::CommandMessage%3E2F1AC60177_copy.hasinit
  //## begin CommandMessage::CommandMessage%3E2F1AC60177_copy.initialization preserve=yes
   : Message(right)
  //## end CommandMessage::CommandMessage%3E2F1AC60177_copy.initialization
{
  //## begin IF::CommandMessage::CommandMessage%3E2F1AC60177_copy.body preserve=yes
   memcpy(m_sID,"IF42",4);
   m_strData1 = right.m_strData1;
   m_strData2 = right.m_strData2;
  //## end IF::CommandMessage::CommandMessage%3E2F1AC60177_copy.body
}

CommandMessage::CommandMessage (const string& strData1, const string& strData2)
  //## begin IF::CommandMessage::CommandMessage%3E3556FD02BF.hasinit preserve=no
  //## end IF::CommandMessage::CommandMessage%3E3556FD02BF.hasinit
  //## begin IF::CommandMessage::CommandMessage%3E3556FD02BF.initialization preserve=yes
   : m_strData1(strData1)
   ,m_strData2(strData2)
  //## end IF::CommandMessage::CommandMessage%3E3556FD02BF.initialization
{
  //## begin IF::CommandMessage::CommandMessage%3E3556FD02BF.body preserve=yes
   memcpy(m_sID,"IF42",4);
   hGDMHeader* pGDMHeader = (hGDMHeader*)(char*)*m_pMemory;
   memcpy(pGDMHeader->sDescription,"CNX ",4);
   pGDMHeader->siTotalHeaderLength = htons(35);
   pGDMHeader->cConcatenation = 'N';
   memcpy(pGDMHeader->sType,"F2",2);
   memcpy(pGDMHeader->sVersion,"01",2);
   pGDMHeader->siLengthOfFormatTwoArea = htons(28);
   pGDMHeader->siSubAreaLength = htons(26);
   string strUserid("00000000");
   Extract::instance()->getSpec("OPERATOR",strUserid);
   strUserid.resize(8,' ');
   memcpy(pGDMHeader->sReferenceNumber,strUserid.data(),strUserid.length());
   memcpy(pGDMHeader->sDate,"00000000",8);
   memcpy(pGDMHeader->sTime,"000000",6);
   memcpy(pGDMHeader->sPriority,"01",2);
   pGDMHeader->siTotalDataAreaLength = htons(0);
   pGDMHeader->siDataLength1 = htons(m_strData1.length());
   pGDMHeader->siDataElement1 = htons(0);
   memset(pGDMHeader->sData1,' ',8);
   memcpy(pGDMHeader->sData1,m_strData1.data(),m_strData1.length());
   pGDMHeader->siDataLength2 = htons(m_strData2.length());
   pGDMHeader->siDataElement2 = htons(0);
   memset(pGDMHeader->sData2,' ',52);
   memcpy(pGDMHeader->sData2,m_strData2.data(),m_strData2.length());
   pGDMHeader->siTotalMessageLength = htons(111);
   Message::setMessageLength(111);
  //## end IF::CommandMessage::CommandMessage%3E3556FD02BF.body
}


CommandMessage::~CommandMessage()
{
  //## begin IF::CommandMessage::~CommandMessage%3E2F1AC60177_dest.body preserve=yes
  //## end IF::CommandMessage::~CommandMessage%3E2F1AC60177_dest.body
}


CommandMessage & CommandMessage::operator=(const CommandMessage &right)
{
  //## begin IF::CommandMessage::operator=%3E2F1AC60177_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_strData1 = right.m_strData1;
   m_strData2 = right.m_strData2;
   return *this;
  //## end IF::CommandMessage::operator=%3E2F1AC60177_assign.body
}



//## Other Operations (implementation)
bool CommandMessage::execute (const char* pszQueueName)
{
  //## begin IF::CommandMessage::execute%3E3553920399.body preserve=yes
   return Queue::send(pszQueueName,this,Queue::COMMAND);
  //## end IF::CommandMessage::execute%3E3553920399.body
}

// Additional Declarations
  //## begin IF::CommandMessage%3E2F1AC60177.declarations preserve=yes
  //## end IF::CommandMessage%3E2F1AC60177.declarations

} // namespace IF

//## begin module%3E2F1BBE00EA.epilog preserve=yes
//## end module%3E2F1BBE00EA.epilog
