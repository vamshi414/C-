//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3703A7390047.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3703A7390047.cm

//## begin module%3703A7390047.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3703A7390047.cp

//## Module: CXOSIF35%3703A7390047; Package specification
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXODIF35.hpp

#ifndef CXOSIF35_h
#define CXOSIF35_h 1

//## begin module%3703A7390047.additionalIncludes preserve=no
//## end module%3703A7390047.additionalIncludes

//## begin module%3703A7390047.includes preserve=yes
// $Date:   Jun 30 2006 11:35:42  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%3703A7390047.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Log;
class Message;

} // namespace IF

//## begin module%3703A7390047.declarations preserve=no
//## end module%3703A7390047.declarations

//## begin module%3703A7390047.additionalDeclarations preserve=yes
//## end module%3703A7390047.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::ResourceUsage%3703A47D004B.preface preserve=yes
//## end IF::ResourceUsage%3703A47D004B.preface

//## Class: ResourceUsage%3703A47D004B
//	The ResourceUsage class encapsulates the functions
//	required for collecting/logging resource usage data.
//
//	CXODIF35.hpp
//	CXOSIF35.cpp
//## Category: Connex Foundation::IF_CAT%3451F55F009E
//## Subsystem: IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3703ACED0119;Log { -> F}
//## Uses: <unnamed>%3703CB6E0077;Message { -> F}
//## Uses: <unnamed>%370A6E3B01A2;DateTime { -> F}

class DllExport ResourceUsage : public reusable::Object  //## Inherits: <unnamed>%3703A5BB000C
{
  //## begin IF::ResourceUsage%3703A47D004B.initialDeclarations preserve=yes
  //## end IF::ResourceUsage%3703A47D004B.initialDeclarations

  public:
    //## Constructors (generated)
      ResourceUsage();

    //## Destructor (generated)
      virtual ~ResourceUsage();


    //## Other Operations (specified)
      //## Operation: log%3703C4800347
      //	Log the resource usage data.
      //## Semantics:
      //	1. Build standard RUC record.
      //	2. Call Log::put().
      static bool log (const char *psMessageID, const char *psReason, const char *psUserID, const char* psEntityData, const char* psSubType, int lCount, const char *psMessageData, int lMessageDataLength);

    // Additional Public Declarations
      //## begin IF::ResourceUsage%3703A47D004B.public preserve=yes
      //## end IF::ResourceUsage%3703A47D004B.public

  protected:
    // Additional Protected Declarations
      //## begin IF::ResourceUsage%3703A47D004B.protected preserve=yes
      //## end IF::ResourceUsage%3703A47D004B.protected

  private:
    // Additional Private Declarations
      //## begin IF::ResourceUsage%3703A47D004B.private preserve=yes
      //## end IF::ResourceUsage%3703A47D004B.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::ResourceUsage%3703A47D004B.implementation preserve=yes
      //## end IF::ResourceUsage%3703A47D004B.implementation

};

//## begin IF::ResourceUsage%3703A47D004B.postscript preserve=yes
//## end IF::ResourceUsage%3703A47D004B.postscript

} // namespace IF

//## begin module%3703A7390047.epilog preserve=yes
using namespace IF;
//## end module%3703A7390047.epilog


#endif
