//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36266D3A038C.cm preserve=no
//## end module%36266D3A038C.cm

//## begin module%36266D3A038C.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36266D3A038C.cp

//## Module: CXOSIF10%36266D3A038C; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF10.hpp

#ifndef CXOSIF10_h
#define CXOSIF10_h 1

//## begin module%36266D3A038C.additionalIncludes preserve=no
//## end module%36266D3A038C.additionalIncludes

//## begin module%36266D3A038C.includes preserve=yes
//## end module%36266D3A038C.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Extract;
class OperatingSystemFileFactory;
class ZosFile;
class WindowsFile;
class UnixFile;
class File;

} // namespace IF

//## begin module%36266D3A038C.declarations preserve=no
//## end module%36266D3A038C.declarations

//## begin module%36266D3A038C.additionalDeclarations preserve=yes
//## end module%36266D3A038C.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::FlatFile%345C6F890047.preface preserve=yes
//## end IF::FlatFile%345C6F890047.preface

//## Class: FlatFile%345C6F890047
//	The FlatFile class encapsulates access to a dataset.
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%491EEE860261;UnixFile { -> F}
//## Uses: <unnamed>%491EEE890109;WindowsFile { -> F}
//## Uses: <unnamed>%491EEE8C00EA;ZosFile { -> F}
//## Uses: <unnamed>%50C5EEDE01ED;Extract { -> F}
//## Uses: <unnamed>%50C5EEE102E1;Trace { -> F}
//## Uses: <unnamed>%50C5EEF300EF;OperatingSystemFileFactory { -> F}

class DllExport FlatFile : public reusable::Object  //## Inherits: <unnamed>%34732E5101BD
{
  //## begin IF::FlatFile%345C6F890047.initialDeclarations preserve=yes
  public:
      enum OpenType
      {
         CX_OPEN_INPUT,
         CX_OPEN_OUTPUT,
         CX_OPEN_UPDATE,
         CX_OPEN_RESET,
         CX_OPEN_APPEND,
         CX_OPEN_OUTPUT_BINARY
      };
      enum AccessOption
      {
         ADR,
         CNV,
         KEY,
         DIR,
         SEQ,
         SKP,
         ARD,
         LRD,
         FWD,
         BWD,
         NSP,
         NUP,
         UPD,
         KEQ,
         KGE,
         FKS,
         GEN,
         LOC,
         MVE
      };
      enum SeekOffset
      {
         CX_SEEK_SET = 0,
         CX_SEEK_CUR = 1,
         CX_SEEK_END = 2
   	  };

  //## end IF::FlatFile%345C6F890047.initialDeclarations

  public:
    //## Constructors (generated)
      FlatFile();

    //## Constructors (specified)
      //## Operation: FlatFile%3F9C973E026A
      FlatFile (const char* pszName);

      //## Operation: FlatFile%374AA58800A6
      FlatFile (const char* pszName, const char* pszMember);

    //## Destructor (generated)
      virtual ~FlatFile();


    //## Other Operations (specified)
      //## Operation: close%374AA5AD0316
      virtual bool close ();

      //## Operation: copy%4C519B230009
      bool copy (const char* pszTarget, const char* pszOutputFileName = 0);

      //## Operation: datasetName%374AAE040121
      const string& datasetName ();

      //## Operation: executeFtp%4C5078290277
      bool executeFtp ();

      //## Operation: flush%3F9DAF0101D6
      virtual bool flush ();

      //## Operation: getBaseName%4C507CD50125
      bool getBaseName (string& strBaseName, bool bIncludeExtension = false);

      //## Operation: getDatasetName%491EE37502AF
      const string& getDatasetName ();

      //## Operation: getDate%491EE3940109
      const string& getDate ();

      //## Operation: getName%491EE3A3032C
      const string& getName ();

      //## Operation: getRecordCount%491EE3CD006D
      int getRecordCount () const;

      //## Operation: getScheduledTime%491EE3F902AF
      const string& getScheduledTime ();

      //## Operation: getSequence%491EE418031C
      int getSequence ();

      //## Operation: getType%5AC3DCBF02DB
      const string& getType ();

      //## Operation: isFolderEmpty%65B26C89001F
      static bool isFolderEmpty (const char* pszFolder);

      //## Operation: isMail%52D940210376
      virtual bool isMail ();

      //## Operation: isOpen%45804F800138
      bool isOpen ();

      //## Operation: move%3FA98D5202E3
      bool move (const char* pszTarget, const char* pszOutputFileName = 0);

      //## Operation: open%374AA5B80308
      virtual bool open (enum OpenType nOpenType = CX_OPEN_INPUT);

      //## Operation: pick%65B26DE500D4
      static bool pick (const char* pszFolder, reusable::string& strDatasetName);

      //## Operation: purge%496DFC99037A
      static void purge (const char* pszFolder, const string& strPeriod);

      //## Operation: purgeFolder%4C6951100392
      static void purgeFolder (const char* pszFolder, const string& strPeriod);

      //## Operation: read%374AA5E5028B
      virtual bool read (char* psBuffer, size_t iBufferLength, size_t* piRecordLength, bool* pbReadError = 0);

      //## Operation: read%58ECDFF6038C
      bool read (string& strBuffer);

      //## Operation: remove%3EE9A9490203
      bool remove ();

      //## Operation: seek%516C095B015A
      void seek (int SeekPos, enum SeekOffset nSeekOffset = CX_SEEK_SET);

      //## Operation: setAccessOption%374AA61B0365
      void setAccessOption (enum AccessOption nAccessOption);

      //## Operation: setDatasetName%374AAD6A018E
      void setDatasetName (const char* pszDatasetName);

      //## Operation: setDate%491EE39C000F
      void setDate (const string& strDate);

      //## Operation: setDX_FILE_ID%65B26C160182
      void setDX_FILE_ID (int iDX_FILE_ID);

      //## Operation: setDX_REPORT_ID%55F9D7A601E5
      void setDX_REPORT_ID (int iDX_REPORT_ID);

      //## Operation: setFolder%4D2F7B110231
      void setFolder (const string& strFolder);

      //## Operation: setMember%374AAD770024
      void setMember (const char* pszMember);

      //## Operation: setName%374AAD8001F4
      void setName (const char* pszName);

      //## Operation: setOwner%491EE3AA036B
      void setOwner (const string& strOwner);

      //## Operation: setPath%4665872301B5
      void setPath (const string& strPath);

      //## Operation: setRecordFormat%491EE3E000CB
      void setRecordFormat (const string& strRecordFormat);

      //## Operation: setScheduledTime%491EE4030399
      void setScheduledTime (const string& strScheduledTime);

      //## Operation: setSequence%491EE420036B
      void setSequence (int iSequence);

      //## Operation: tellg%516C0A9B006D
      int tellg ();

      //## Operation: unzip%4C5073900383
      bool unzip ();

      //## Operation: write%374AA64401D3
      virtual bool write (char* psBuffer, int iRecordLength);

      //## Operation: zip%4C50793C0086
      bool zip (const string& strArchiveName);

    // Additional Public Declarations
      //## begin IF::FlatFile%345C6F890047.public preserve=yes
#ifdef _WIN64
      long long getFile ();
#else
      long getFile ();
#endif
      bool getEncryption();
      bool decrypt(char* psBuffer, int* plRecordLength);
      //## end IF::FlatFile%345C6F890047.public
  protected:
    // Additional Protected Declarations
      //## begin IF::FlatFile%345C6F890047.protected preserve=yes
      //## end IF::FlatFile%345C6F890047.protected

  private:
    // Additional Private Declarations
      //## begin IF::FlatFile%345C6F890047.private preserve=yes
      //## end IF::FlatFile%345C6F890047.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Library::IF_CAT::<unnamed>%491EDEA103D8
      //## Role: FlatFile::<m_this>%491EDEA20261
      //## begin IF::FlatFile::<m_this>%491EDEA20261.role preserve=no  public: IF::File { -> RFHgN}
      File *m_this;
      //## end IF::FlatFile::<m_this>%491EDEA20261.role

    // Additional Implementation Declarations
      //## begin IF::FlatFile%345C6F890047.implementation preserve=yes
      //## end IF::FlatFile%345C6F890047.implementation

};

//## begin IF::FlatFile%345C6F890047.postscript preserve=yes
//## end IF::FlatFile%345C6F890047.postscript

} // namespace IF

//## begin module%36266D3A038C.epilog preserve=yes
using namespace IF;
//## end module%36266D3A038C.epilog


#endif
