//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%36DC594A0075.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DC594A0075.cm

//## begin module%36DC594A0075.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DC594A0075.cp

//## Module: CXOSIF33%36DC594A0075; Package specification
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXODIF33.hpp

#ifndef CXOSIF33_h
#define CXOSIF33_h 1

//## begin module%36DC594A0075.additionalIncludes preserve=no
//## end module%36DC594A0075.additionalIncludes

//## begin module%36DC594A0075.includes preserve=yes
// $Date:   Jun 30 2006 11:35:42  $ $Author:   D02405  $ $Revision:   1.3  $
#include <map>
//## end module%36DC594A0075.includes

#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class MDSQueue;
class MDSSignal;

} // namespace IF

//## begin module%36DC594A0075.declarations preserve=no
//## end module%36DC594A0075.declarations

//## begin module%36DC594A0075.additionalDeclarations preserve=yes
//## end module%36DC594A0075.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::MDSQueueFactory%36DC581C02F2.preface preserve=yes
//## end IF::MDSQueueFactory%36DC581C02F2.preface

//## Class: MDSQueueFactory%36DC581C02F2
//## Category: Connex Foundation::IF_CAT%3451F55F009E
//## Subsystem: IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%36DC58EA02EE;MDSQueue { -> F}
//## Uses: <unnamed>%36DC58ED01EE;MDSSignal { -> F}

class DllExport MDSQueueFactory : public QueueFactory  //## Inherits: <unnamed>%36DC582A02E8
{
  //## begin IF::MDSQueueFactory%36DC581C02F2.initialDeclarations preserve=yes
  //## end IF::MDSQueueFactory%36DC581C02F2.initialDeclarations

  public:
    //## Constructors (generated)
      MDSQueueFactory();

    //## Destructor (generated)
      virtual ~MDSQueueFactory();


    //## Other Operations (specified)
      //## Operation: create%36DC583303D1
      virtual Object* create (const char* pszClass, const char* pszValue = 0);

    // Additional Public Declarations
      //## begin IF::MDSQueueFactory%36DC581C02F2.public preserve=yes
      //## end IF::MDSQueueFactory%36DC581C02F2.public

  protected:
    // Additional Protected Declarations
      //## begin IF::MDSQueueFactory%36DC581C02F2.protected preserve=yes
      //## end IF::MDSQueueFactory%36DC581C02F2.protected

  private:
    // Additional Private Declarations
      //## begin IF::MDSQueueFactory%36DC581C02F2.private preserve=yes
      //## end IF::MDSQueueFactory%36DC581C02F2.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Classes%36DC58AA02EC
      //## begin IF::MDSQueueFactory::Classes%36DC58AA02EC.attr preserve=no  private: map<string,int,less<string> > {U} 
      map<string,int,less<string> > m_hClasses;
      //## end IF::MDSQueueFactory::Classes%36DC58AA02EC.attr

    // Additional Implementation Declarations
      //## begin IF::MDSQueueFactory%36DC581C02F2.implementation preserve=yes
      //## end IF::MDSQueueFactory%36DC581C02F2.implementation

};

//## begin IF::MDSQueueFactory%36DC581C02F2.postscript preserve=yes
//## end IF::MDSQueueFactory%36DC581C02F2.postscript

} // namespace IF

//## begin module%36DC594A0075.epilog preserve=yes
using namespace IF;
//## end module%36DC594A0075.epilog


#endif
