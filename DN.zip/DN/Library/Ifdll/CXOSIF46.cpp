//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%41AB78E70280.cm preserve=no
//	$Date:   Apr 02 2009 12:13:12  $ $Author:   D94163  $
//	$Revision:   1.3  $
//## end module%41AB78E70280.cm

//## begin module%41AB78E70280.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%41AB78E70280.cp

//## Module: CXOSIF46%41AB78E70280; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXOSIF46.cpp

//## begin module%41AB78E70280.additionalIncludes preserve=no
//## end module%41AB78E70280.additionalIncludes

//## begin module%41AB78E70280.includes preserve=yes
// $Date:   Apr 02 2009 12:13:12  $ $Author:   D94163  $ $Revision:   1.3  $
//## end module%41AB78E70280.includes

#ifndef CXOSIF47_h
#include "CXODIF47.hpp"
#endif
#ifndef CXOSIF46_h
#include "CXODIF46.hpp"
#endif


//## begin module%41AB78E70280.declarations preserve=no
//## end module%41AB78E70280.declarations

//## begin module%41AB78E70280.additionalDeclarations preserve=yes
//## end module%41AB78E70280.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::QueueManager 

//## begin IF::QueueManager::QueueManager%41AB847901C5.attr preserve=no  private: static map<string,QueueManager*,less<string> > {R} 0
map<string,QueueManager*,less<string> > *QueueManager::m_pQueueManager = 0;
//## end IF::QueueManager::QueueManager%41AB847901C5.attr

QueueManager::QueueManager()
  //## begin QueueManager::QueueManager%41AB603B0157_const.hasinit preserve=no
  //## end QueueManager::QueueManager%41AB603B0157_const.hasinit
  //## begin QueueManager::QueueManager%41AB603B0157_const.initialization preserve=yes
  //## end QueueManager::QueueManager%41AB603B0157_const.initialization
{
  //## begin IF::QueueManager::QueueManager%41AB603B0157_const.body preserve=yes
  //## end IF::QueueManager::QueueManager%41AB603B0157_const.body
}

QueueManager::QueueManager (const string& strName)
  //## begin IF::QueueManager::QueueManager%41AB7F1B001F.hasinit preserve=no
  //## end IF::QueueManager::QueueManager%41AB7F1B001F.hasinit
  //## begin IF::QueueManager::QueueManager%41AB7F1B001F.initialization preserve=yes
   : m_strName(strName)
  //## end IF::QueueManager::QueueManager%41AB7F1B001F.initialization
{
  //## begin IF::QueueManager::QueueManager%41AB7F1B001F.body preserve=yes
  //## end IF::QueueManager::QueueManager%41AB7F1B001F.body
}


QueueManager::~QueueManager()
{
  //## begin IF::QueueManager::~QueueManager%41AB603B0157_dest.body preserve=yes
  //## end IF::QueueManager::~QueueManager%41AB603B0157_dest.body
}



//## Other Operations (implementation)
IF::QueueManager* QueueManager::instance (const string& strName)
{
  //## begin IF::QueueManager::instance%41AB7A8B01D4.body preserve=yes
   if (m_pQueueManager == 0)
      m_pQueueManager = new map<string,QueueManager*,less<string> >;
   map<string,QueueManager*,less<string> >::iterator pQueueManager;
   pQueueManager = m_pQueueManager->find(strName);
   if (pQueueManager == m_pQueueManager->end())
   {
      m_pQueueManager->insert(map<string,QueueManager*,less<string> >::value_type(strName,(QueueManager*)ExternalQueueFactory::instance()->create("QueueManager",strName.c_str())));
      pQueueManager = m_pQueueManager->find(strName);
      (*pQueueManager).second->connect();
   }
   return (*pQueueManager).second;
  //## end IF::QueueManager::instance%41AB7A8B01D4.body
}

void QueueManager::terminate ()
{
  //## begin IF::QueueManager::terminate%41AB776102EE.body preserve=yes
   if (m_pQueueManager == 0)
      return;
   map<string,QueueManager*,less<string> >::iterator ppQueueManager;
   for (ppQueueManager = m_pQueueManager->begin();ppQueueManager != m_pQueueManager->end();++ppQueueManager)
      delete (*ppQueueManager).second;
   m_pQueueManager->erase(m_pQueueManager->begin(),m_pQueueManager->end());
  //## end IF::QueueManager::terminate%41AB776102EE.body
}

// Additional Declarations
  //## begin IF::QueueManager%41AB603B0157.declarations preserve=yes
  //## end IF::QueueManager%41AB603B0157.declarations

} // namespace IF

//## begin module%41AB78E70280.epilog preserve=yes
//## end module%41AB78E70280.epilog
