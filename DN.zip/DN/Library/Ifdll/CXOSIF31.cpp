//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%36DBF5E403A4.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DBF5E403A4.cm

//## begin module%36DBF5E403A4.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DBF5E403A4.cp

//## Module: CXOSIF31%36DBF5E403A4; Package body
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXOSIF31.cpp

//## begin module%36DBF5E403A4.additionalIncludes preserve=no
//## end module%36DBF5E403A4.additionalIncludes

//## begin module%36DBF5E403A4.includes preserve=yes
// $Date:   Aug 19 2016 14:53:52  $ $Author:   e1009652  $ $Revision:   1.7  $
//## end module%36DBF5E403A4.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF31_h
#include "CXODIF31.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif


//## begin module%36DBF5E403A4.declarations preserve=no
//## end module%36DBF5E403A4.declarations

//## begin module%36DBF5E403A4.additionalDeclarations preserve=yes
//## end module%36DBF5E403A4.additionalDeclarations


//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::DiskQueue 


DiskQueue::DiskQueue()
  //## begin DiskQueue::DiskQueue%36DBF58D0038_const.hasinit preserve=no
  //## end DiskQueue::DiskQueue%36DBF58D0038_const.hasinit
  //## begin DiskQueue::DiskQueue%36DBF58D0038_const.initialization preserve=yes
  //## end DiskQueue::DiskQueue%36DBF58D0038_const.initialization
{
  //## begin IF::DiskQueue::DiskQueue%36DBF58D0038_const.body preserve=yes
   memcpy(m_sID,"IF31",4);
   m_pQueue = 0;
  //## end IF::DiskQueue::DiskQueue%36DBF58D0038_const.body
}

DiskQueue::DiskQueue (const char* pszName)
  //## begin IF::DiskQueue::DiskQueue%36DD52F40048.hasinit preserve=no
  //## end IF::DiskQueue::DiskQueue%36DD52F40048.hasinit
  //## begin IF::DiskQueue::DiskQueue%36DD52F40048.initialization preserve=yes
   : Queue(pszName)
  //## end IF::DiskQueue::DiskQueue%36DD52F40048.initialization
{
  //## begin IF::DiskQueue::DiskQueue%36DD52F40048.body preserve=yes
   memcpy(m_sID,"IF31",4);
   m_pQueue = 0;
   m_strName.insert(0,"Queue\\",6);
   size_t n = m_strName.find_first_of(' ');
   if (n != string::npos)
      m_strName.erase(n);
   m_strName += ".txt";
  //## end IF::DiskQueue::DiskQueue%36DD52F40048.body
}


DiskQueue::~DiskQueue()
{
  //## begin IF::DiskQueue::~DiskQueue%36DBF58D0038_dest.body preserve=yes
   close();
  //## end IF::DiskQueue::~DiskQueue%36DBF58D0038_dest.body
}



//## Other Operations (implementation)
bool DiskQueue::close ()
{
  //## begin IF::DiskQueue::close%36DD52BD02D4.body preserve=yes
   if (m_pQueue)
      fclose(m_pQueue);
   m_pQueue = 0;
   return true;
  //## end IF::DiskQueue::close%36DD52BD02D4.body
}

bool DiskQueue::open ()
{
  //## begin IF::DiskQueue::open%36DD52BF03DB.body preserve=yes
   m_pQueue = fopen(m_strName.c_str(),"r");
   if (!m_pQueue)
      return false;
#ifndef MVS
   m_pSignal->deliver();
#endif
   return true;
  //## end IF::DiskQueue::open%36DD52BF03DB.body
}

bool DiskQueue::send (Message* pMessage, enum MessageType nMessageType)
{
  //## begin IF::DiskQueue::send%36DE953B0002.body preserve=yes
   if (!m_pQueue)
      m_pQueue = fopen(m_strName.c_str(),"w");
   if (!m_pQueue)
      return false;
   hStandardHeader* pStandardHeader = (hStandardHeader*)pMessage->buffer();
   hUniqueHeader* pUniqueHeader = (hUniqueHeader*)(pMessage->buffer() + sizeof(struct hStandardHeader));
   hData* pData = (hData*)(pMessage->buffer() + sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader));
   char* p = pMessage->buffer() + pMessage->messageLength();
   *p = '\0';
   char szQueue[32];
   strcpy(szQueue,m_strName.c_str());
   p = strchr(szQueue,'.');
   if (p)
     *p = '\0';
   if (pStandardHeader->siTotalHeaderLength == (sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader) - 2))
      fprintf(m_pQueue,
      "CNX %s %d %d %2.2s %3.3s %3.3s %ld %ld %6.6s %hd %2.2s %hd %s\n",
         szQueue,
         pStandardHeader->siTotalHeaderLength,
         pStandardHeader->siLength,
         pStandardHeader->sFormat,
         pStandardHeader->sSenderID,
         pStandardHeader->sReceiverID,
         (long)pStandardHeader->pSenderCBAddress,
         (long)pStandardHeader->pReceiverCBAddress,
         pStandardHeader->sMessageID,
         pUniqueHeader->siLength,
         pUniqueHeader->sFormat,
         pData->siLength,
         pData->sText);
   else
      fprintf(m_pQueue,"TXT %s %s\n",szQueue,pMessage->buffer());
   fflush(m_pQueue);
   return true;
  //## end IF::DiskQueue::send%36DE953B0002.body
}

void DiskQueue::update (Subject* pSubject)
{
  //## begin IF::DiskQueue::update%36DC66680219.body preserve=yes
   char szType[4];
   int iRC;
   iRC = fscanf(m_pQueue,"%3s",szType);
   if (iRC == EOF)
      return;
   if (!strcmp(szType,"RES"))
   {
      fgets(Message::instance(Message::INBOUND)->buffer(),4096,m_pQueue); // !!!
      return;
   }
   char psQueueName[32];
   if (!strcmp(szType,"CNX"))
   {
      unsigned short siTotalHeaderLength;
      unsigned short siLength;
      char sFormat[3];
      char sSenderID[4];
      char sReceiverID[4];
      void* pSenderCBAddress;
      void* pReceiverCBAddress;
      char sMessageID[7];
      unsigned short siLength2;
      char sFormat2[3];
      unsigned short siLength3;
      hStandardHeader* pStandardHeader = (hStandardHeader*)Message::instance(Message::INBOUND)->buffer();
      hUniqueHeader* pUniqueHeader = (hUniqueHeader*)(Message::instance(Message::INBOUND)->buffer() + sizeof(struct hStandardHeader));
      hData* pData = (hData*)(Message::instance(Message::INBOUND)->buffer() + sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader));
      fscanf(m_pQueue,
         "%31s %hd %hd %02s %03s %03s %ld %ld %06s %hd %02s %hd ",
         psQueueName,
         &siTotalHeaderLength,
         &siLength,
         sFormat,
         sSenderID,
         sReceiverID,
         &pSenderCBAddress,
         &pReceiverCBAddress,
         sMessageID,
         &siLength2,
         sFormat2,
         &siLength3);
      pStandardHeader->siTotalHeaderLength = siTotalHeaderLength;
      pStandardHeader->siLength = siLength;
      memcpy(pStandardHeader->sFormat, sFormat, sizeof(pStandardHeader->sFormat));
      memcpy(pStandardHeader->sSenderID, sSenderID, sizeof(pStandardHeader->sSenderID));
      memcpy(pStandardHeader->sReceiverID, sReceiverID, sizeof(pStandardHeader->sReceiverID));
      pStandardHeader->pSenderCBAddress = pSenderCBAddress;
      pStandardHeader->pReceiverCBAddress = pReceiverCBAddress;
      memcpy(pStandardHeader->sMessageID, sMessageID, sizeof(pStandardHeader->sMessageID));
      pUniqueHeader->siLength = siLength2;
      memcpy(pUniqueHeader->sFormat, sFormat2, sizeof(pUniqueHeader->sFormat));
      pData->siLength = siLength3;

      fgets(pData->sText,4096,m_pQueue); // !!!
      strncpy(pStandardHeader->sSenderSTCKValue,"        ",8);
      strncpy(pStandardHeader->sReceiverSTCKValue,"        ",8);
      strncpy(pStandardHeader->sFiller,"        ",8);
      pStandardHeader->siResponsePriority = 200;
      Message::instance(Message::INBOUND)->setSource(psQueueName);
      Message::instance(Message::INBOUND)->setMessageLength(pStandardHeader->siTotalHeaderLength + 2
         + pData->siLength + 2);
   }
   else
   if (!strcmp(szType,"GDM"))
   {
      hGDMHeader* pGDMHeader = (hGDMHeader*)Message::instance(Message::INBOUND)->buffer();
      unsigned short siTotalMessageLength;
      char sDescription[4];    
      unsigned short siTotalHeaderLength;
      char cConcatenation[5];
      unsigned short siLengthOfFormatTwoArea;
      unsigned short siSubAreaLength;
      char sReferenceNumber[24];
      unsigned short siTotalDataAreaLength;
      unsigned short siDataLength1;
      unsigned short siDataElement1;
      char sData1[8];
      unsigned short siDataLength2;
      unsigned short siDataElement2;
      char sData2[24];
      fscanf(m_pQueue,
         "%31s %hd %04c %hd %05c %hd %hd %24c %hd %hd %hd %08c %hd %hd %24c",
         psQueueName,
         &siTotalMessageLength,
         sDescription,
         &siTotalHeaderLength,
         &cConcatenation,
         &siLengthOfFormatTwoArea,
         &siSubAreaLength,
         sReferenceNumber,
         &siTotalDataAreaLength,
         &siDataLength1,
         &siDataElement1,
         sData1,
         &siDataLength2,
         &siDataElement2,
         sData2);

      pGDMHeader->siTotalMessageLength = siTotalMessageLength;
      memcpy(pGDMHeader->sDescription, sDescription, sizeof(pGDMHeader->sDescription));
      pGDMHeader->siTotalHeaderLength = siTotalHeaderLength;
      pGDMHeader->cConcatenation = cConcatenation[1];
      pGDMHeader->siLengthOfFormatTwoArea = siLengthOfFormatTwoArea;
      pGDMHeader->siSubAreaLength = siSubAreaLength;
      memcpy(pGDMHeader->sReferenceNumber, sReferenceNumber, sizeof(pGDMHeader->sReferenceNumber));
      pGDMHeader->siTotalDataAreaLength = siTotalDataAreaLength;
      pGDMHeader->siDataLength1 = siDataLength1;
      pGDMHeader->siDataElement1 = siDataElement1;
      memcpy(pGDMHeader->sData1, sData1, sizeof(pGDMHeader->sData1));
      pGDMHeader->siDataLength2 = siDataLength2;
      pGDMHeader->siDataElement2 = siDataElement2;
      memcpy(pGDMHeader->sData2,sData2,sizeof(sData2));
      pGDMHeader->sDescription[3] = ' ';
      Message::instance(Message::INBOUND)->setSource(psQueueName);
      Message::instance(Message::INBOUND)->setMessageLength(pGDMHeader->siTotalMessageLength);
   }
   else
   {
      fscanf(m_pQueue,"%31s ", psQueueName);
      fgets(Message::instance(Message::INBOUND)->buffer(),4096,m_pQueue);
      Message::instance(Message::INBOUND)->setSource(psQueueName);
      Message::instance(Message::INBOUND)->setMessageLength((int)strlen(Message::instance(Message::INBOUND)->buffer()));
   }
   Message::instance(Message::INBOUND)->identifyBuffer();
   Message::instance(Message::INBOUND)->notify();
#ifndef MVS
   m_pSignal->deliver();
#endif
  //## end IF::DiskQueue::update%36DC66680219.body
}

// Additional Declarations
  //## begin IF::DiskQueue%36DBF58D0038.declarations preserve=yes
  //## end IF::DiskQueue%36DBF58D0038.declarations

} // namespace IF

//## begin module%36DBF5E403A4.epilog preserve=yes
//## end module%36DBF5E403A4.epilog
