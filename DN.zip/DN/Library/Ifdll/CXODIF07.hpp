//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36266C4C03C6.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36266C4C03C6.cm

//## begin module%36266C4C03C6.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36266C4C03C6.cp

//## Module: CXOSIF07%36266C4C03C6; Package specification
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF07.hpp

#ifndef CXOSIF07_h
#define CXOSIF07_h 1

//## begin module%36266C4C03C6.additionalIncludes preserve=no
//## end module%36266C4C03C6.additionalIncludes

//## begin module%36266C4C03C6.includes preserve=yes
// $Date:   Jun 30 2006 11:35:36  $ $Author:   D02405  $ $Revision:   1.4  $
#define CM_DEALLOCATE_ABEND 3
#include "CXODRU24.hpp"
//## end module%36266C4C03C6.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;
class Message;

} // namespace IF

//## begin module%36266C4C03C6.declarations preserve=no
//## end module%36266C4C03C6.declarations

//## begin module%36266C4C03C6.additionalDeclarations preserve=yes
//## end module%36266C4C03C6.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Conversation%34801B4D0150.preface preserve=yes
//## end IF::Conversation%34801B4D0150.preface

//## Class: Conversation%34801B4D0150
//	The Conversation class encapsulates the functionality of
//	a CPI/C conversation.
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%364DA10C00AE;Message { -> F}
//## Uses: <unnamed>%3AB683E6006B;Queue { -> F}

class DllExport Conversation : public reusable::Object  //## Inherits: <unnamed>%34801C76036A
{
  //## begin IF::Conversation%34801B4D0150.initialDeclarations preserve=yes
  //## end IF::Conversation%34801B4D0150.initialDeclarations

  public:
    //## Constructors (generated)
      Conversation();

      Conversation(const Conversation &right);

    //## Destructor (generated)
      virtual ~Conversation();

    //## Assignment Operation (generated)
      Conversation & operator=(const Conversation &right);


    //## Other Operations (specified)
      //## Operation: accept%364D9F8D0189
      int accept (const char* psConversationID, const char* pszSymDestName);

      //## Operation: allocate%364D9F93012E
      int allocate ();

      //## Operation: deallocate%36CEBDD30026
      static int deallocate (const char* psConversationID, int lDeallocateType = CM_DEALLOCATE_ABEND);

      //## Operation: initialize%364D9F9C0308
      int initialize (const char* pszSymDestName);

      //## Operation: receive%364D9FA300B9
      int receive (IF::Message& hMessage);

      //## Operation: send%364D9FA801F6
      int send (IF::Message& hMessage);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ConversationID%364D9F0B01F1
      const IString& getConversationID () const
      {
        //## begin IF::Conversation::getConversationID%364D9F0B01F1.get preserve=no
        return m_strConversationID;
        //## end IF::Conversation::getConversationID%364D9F0B01F1.get
      }


      //## Attribute: SendType%364D9F2002A5
      const int getSendType () const
      {
        //## begin IF::Conversation::getSendType%364D9F2002A5.get preserve=no
        return m_lSendType;
        //## end IF::Conversation::getSendType%364D9F2002A5.get
      }

      void setSendType (int value)
      {
        //## begin IF::Conversation::setSendType%364D9F2002A5.set preserve=no
        m_lSendType = value;
        //## end IF::Conversation::setSendType%364D9F2002A5.set
      }


      //## Attribute: SymDestName%364D9F170071
      const string& getSymDestName () const
      {
        //## begin IF::Conversation::getSymDestName%364D9F170071.get preserve=no
        return m_strSymDestName;
        //## end IF::Conversation::getSymDestName%364D9F170071.get
      }


    // Additional Public Declarations
      //## begin IF::Conversation%34801B4D0150.public preserve=yes
      //## end IF::Conversation%34801B4D0150.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Conversation%34801B4D0150.protected preserve=yes
      //## end IF::Conversation%34801B4D0150.protected

  private:
    // Additional Private Declarations
      //## begin IF::Conversation%34801B4D0150.private preserve=yes
      //## end IF::Conversation%34801B4D0150.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin IF::Conversation::ConversationID%364D9F0B01F1.attr preserve=no  public: IString {V} 
      IString m_strConversationID;
      //## end IF::Conversation::ConversationID%364D9F0B01F1.attr

      //## begin IF::Conversation::SendType%364D9F2002A5.attr preserve=no  public: int {V} CM_SEND_AND_PREP_TO_RECEIVE
      int m_lSendType;
      //## end IF::Conversation::SendType%364D9F2002A5.attr

      //## begin IF::Conversation::SymDestName%364D9F170071.attr preserve=no  public: string {V} 
      string m_strSymDestName;
      //## end IF::Conversation::SymDestName%364D9F170071.attr

    // Additional Implementation Declarations
      //## begin IF::Conversation%34801B4D0150.implementation preserve=yes
      //## end IF::Conversation%34801B4D0150.implementation

};

//## begin IF::Conversation%34801B4D0150.postscript preserve=yes
//## end IF::Conversation%34801B4D0150.postscript

} // namespace IF

//## begin module%36266C4C03C6.epilog preserve=yes
using namespace IF;
//## end module%36266C4C03C6.epilog


#endif
