//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%362666BF0282.cm preserve=no
//	$Date:   Nov 16 2012 09:54:02  $ $Author:   e1009839  $ $Revision:   1.5  $
//## end module%362666BF0282.cm

//## begin module%362666BF0282.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%362666BF0282.cp

//## Module: CXOSIF05%362666BF0282; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.3A.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF05.hpp

#ifndef CXOSIF05_h
#define CXOSIF05_h 1

//## begin module%362666BF0282.additionalIncludes preserve=no
//## end module%362666BF0282.additionalIncludes

//## begin module%362666BF0282.includes preserve=yes
// $Date:   Nov 16 2012 09:54:02  $ $Author:   e1009839  $ $Revision:   1.5  $
//## end module%362666BF0282.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%362666BF0282.declarations preserve=no
//## end module%362666BF0282.declarations

//## begin module%362666BF0282.additionalDeclarations preserve=yes
//## end module%362666BF0282.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Memory%345C724100DE.preface preserve=yes
//## end IF::Memory%345C724100DE.preface

//## Class: Memory%345C724100DE
//	The Memory class encapsulates an interface to the Connex
//	memory allocation functions.
//
//	CXODIF05.hpp
//	CXOSIF05.cpp
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport Memory : public reusable::Object  //## Inherits: <unnamed>%34801A54038D
{
  //## begin IF::Memory%345C724100DE.initialDeclarations preserve=yes
  //## end IF::Memory%345C724100DE.initialDeclarations

  public:
    //## Constructors (generated)
      Memory();

    //## Constructors (specified)
      //## Operation: Memory%3481C79602C9
      //## Semantics:
      //	1. Call CXAVS to allocate memory.
      Memory (int lLength, bool bAboveTheLine = false);

    //## Destructor (generated)
      virtual ~Memory();


    //## Other Operations (specified)
      //## Operation: operator char*%3481C7A300A1
      operator char* () const
      {
        //## begin IF::Memory::operator char*%3481C7A300A1.body preserve=yes
         return m_pMemory;
        //## end IF::Memory::operator char*%3481C7A300A1.body
      }

      //## Operation: locate%50A3C339004F
      static char* locate (const string& strName, const char* pszKey);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Length%379F15380001
      const int getLength () const
      {
        //## begin IF::Memory::getLength%379F15380001.get preserve=no
        return m_lLength;
        //## end IF::Memory::getLength%379F15380001.get
      }


    // Additional Public Declarations
      //## begin IF::Memory%345C724100DE.public preserve=yes
      //## end IF::Memory%345C724100DE.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Memory%345C724100DE.protected preserve=yes
      //## end IF::Memory%345C724100DE.protected

  private:
    // Additional Private Declarations
      //## begin IF::Memory%345C724100DE.private preserve=yes
      //## end IF::Memory%345C724100DE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: AboveTheLine%4CC701EA01FE
      //## begin IF::Memory::AboveTheLine%4CC701EA01FE.attr preserve=no  private: bool {U} false
      bool m_bAboveTheLine;
      //## end IF::Memory::AboveTheLine%4CC701EA01FE.attr

      //## begin IF::Memory::Length%379F15380001.attr preserve=no  public: int {V} 0
      int m_lLength;
      //## end IF::Memory::Length%379F15380001.attr

      //## Attribute: Memory%3481C7F602C7
      //## begin IF::Memory::Memory%3481C7F602C7.attr preserve=no  private: char* {U} 0
      char* m_pMemory;
      //## end IF::Memory::Memory%3481C7F602C7.attr

    // Additional Implementation Declarations
      //## begin IF::Memory%345C724100DE.implementation preserve=yes
      //## end IF::Memory%345C724100DE.implementation

};

//## begin IF::Memory%345C724100DE.postscript preserve=yes
//## end IF::Memory%345C724100DE.postscript

} // namespace IF

//## begin module%362666BF0282.epilog preserve=yes
using namespace IF;
//## end module%362666BF0282.epilog


#endif
