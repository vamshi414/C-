// CXODIF14.hpp - CPI/C API definition
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
// $Date:   May 15 2020 09:01:06  $ $Author:   e1009510  $ $Revision:   1.5  $
// CPI/C return codes
#ifdef MVS
#define CM_OK 0
#define CM_ALLOCATE_FAILURE_NO_RETRY 1
#define CM_ALLOCATE_FAILURE_RETRY 2
#define CM_CONVERSATION_TYPE_MISMATCH 3
#define CM_PIP_NOT_SPECIFIED_RIGHT 5
#define CM_SECURITY_NOT_VALID 6
#define CM_SYNC_LVL_NOT_SUPPORTED_LU 7
#define CM_SYNC_LVL_NOT_SYPPORTED_PGM 8
#define CM_TPN_NOT_RECOGNIZED 9
#define CM_TP_NOT_AVAILABLE_NO_RETRY 10
#define CM_TP_NOT_AVAILABLE_RETRY 11
#define CM_DEALLOCATED_ABEND 17
#define CM_DEALLOCATED_NORMAL 18
#define CM_PARAMETER_ERROR 19
#define CM_PRODUCT_SPECIFIC_ERROR 20
#define CM_PROGRAM_ERROR_NO_TRUNC 21
#define CM_PROGRAM_ERROR_PURGING 22
#define CM_PROGRAM_ERROR_TRUNC 23
#define CM_PROGRAM_PARAMETER_CHECK 24
#define CM_PROGRAM_STATE_CHECK 25
#define CM_RESOURCE_FAILURE_NO_RETRY 26
#define CM_RESOURCE_FAILURE_RETRY 27
#define CM_UNSUCCESSFUL 28
#define CM_DEALLOCATED_ABEND_SVC 30
#define CM_DEALLOCATED_ABEND_TIMER 31
#define CM_SVC_ERROR_NO_TRUNC 32
#define CM_SVC_ERROR_PURGING 33
#define CM_SVC_ERROR_TRUNC 34
#define CM_TAKE_BACKOUT 100
#define CM_DEALLOCATED_ABEND_BO 130
#define CM_DEALLOCATED_SVC_BO 131
#define CM_DEALLOCATED_ABEND_TIMER_BO 132
#define CM_RESOURCE_FAIL_NO_RETRY_BO 133
#define CM_RESOURCE_FAILURE_RETRY_BO 134
#define CM_DEALLOCATED_NORMAL_BO 135

// CXWAIT status received
#define CX_CONVERSATION_REQUEST_PENDING 0
#define CX_DATA_PENDING 1
#define CX_CONFIRMED_COMPLETED 2
#define CX_OPEN_COMPLETED 3
#define CX_REQUEST_TO_SEND_RECEIVED 4
#define CX_DESTINATION_UNAVAILABLE 5
#define CX_SESSION_DEACTIVATED 6

// CONVERSATION_ID DS XL8
#define CX_CID_SIZE 9			//Includes space for the null terminator
#define CX_SDN_SIZE 9			//Includes space for the null terminator

// CONVERSATION_STATE
#define CM_INITIALIZE_STATE 2
#define CM_SEND_STATE 3
#define CM_RECEIVE_STATE 4
#define CM_SEND_PENDING_STATE 5
#define CM_CONFIRM_STATE 6
#define CM_CONFIRM_SEND_STATE 7
#define CM_CONFIRM_DEALLOCATE_STATE 8
#define CM_DEFER_RECEIVE_STATE 9
#define CM_DEFER_DEALLOCATE_STATE 10
#define CM_SYNC_POINT_STATE 11
#define CM_SYNC_POINT_SEND_STATE 12
#define CM_SYNC_POINT_DEALLOC_STATE 13

// CONVERSATION_TYPE
#define CM_BASIC_CONVERSATION 0
#define CM_MAPPED_CONVERSATION 1

// DATA_RECEIVED
#define CM_NO_DATA_RECEIVED 0
#define CM_DATA_RECEIVED 1
#define CM_COMPLETE_DATA_RECEIVED 2
#define CM_INCOMPLETE_DATA_RECEIVED 3

// DEALLOCATE_TYPE
#define CM_DEALLOCATE_SYNC_LEVEL 0
#define CM_DEALLOCATE_FLUSH 1
#define CM_DEALLOCATE_CONFIRM 2
#define CM_DEALLOCATE_ABEND 3

// DEACTIVATE_TYPE
#define CM_DEACTIVATE_NORMAL 0
#define CM_DEACTIVATE_IMMEDIATE 1

// ERROR_DIRECTION
#define CM_RECEIVE_ERROR 0
#define CM_SEND_ERROR 1

// FILL
#define CM_FILL_LL 0
#define CM_FILL_BUFFER 1

// CM_PREPARE_TO_RECEIVE_TYPE
#define CM_PREP_TO_RECEIVE_SYNC_LEVEL 0
#define CM_PREP_TO_RECEIVE_FLUSH 1
#define CM_PREP_TO_RECEIVE_CONFIRM 2

// RECEIVE_TYPE
#define CM_RECEIVE_AND_WAIT 0
#define CM_RECEIVE_IMMEDIATE 1

// REQUEST_TO_SEND_RECEIVED
#define CM_REQ_TO_SEND_NOT_RECEIVED 0
#define CM_REQ_TO_SEND_RECEIVED 1

// RETURN_CONTROL
#define CM_WHEN_SESSION_ALLOCATED 0
#define CM_IMMEDIATE 1

// SEND_TYPE
#define CM_BUFFER_DATA 0
#define CM_SEND_AND_FLUSH 1
#define CM_SEND_AND_CONFIRM 2
#define CM_SEND_AND_PREP_TO_RECEIVE 3
#define CM_SEND_AND_DEALLOCATE 4

// STATUS_RECEIVED
#define CM_NO_STATUS_RECEIVED 0
#define CM_SEND_RECEIVED 1
#define CM_CONFIRM_RECEIVED 2
#define CM_CONFIRM_SEND_RECEIVED 3
#define CM_CONFIRM_DEALLOC_RECEIVED 4
#define CM_TAKE_COMMIT 5
#define CM_TAKE_COMMIT_SEND 6
#define CM_TAKE_COMMIT_DEALLOCATE 7

// SYNC_LEVEL
#define CM_NONE 0
#define CM_CONFIRM 1
#define CM_SYNC_POINT 2

extern "OS"
{
DllExport int CMACCP(const char* psConversationID,int* plRC);
DllExport int CMALLC(const char* psConversationID,int* plRC);
DllExport int CXCLOS(const char* pszSymDestName,int* plRC);
DllExport int CMDEAL(const char* psConversationID,int* plRC);
DllExport int CMEPLN(const char* psConversationID,char* psPartnerLUName,int* plPartnerLUNameLength,int* plRC);
DllExport int CMINIT(const char* psConversationID,const char* psSymDestName,int* plRC);
DllExport int CXOPEN(const char* pszSymDestName,int* plRC);
DllExport int CMRCV(const char* psConversationID,char* psBuffer,int* plBufferLength,int* plDataReceived,int* plReceivedLength,int* plStatusReceived,int* plRequestToSendReceived,int* plRC);
DllExport int CMSCT(const char* psConversationID,int* plConversationType,int* plRC);
DllExport int CMSDT(const char* psConversationID,int* plDeallocateType,int* plRC);
DllExport int CMSEND(const char* psConversationID,char* psBuffer,int* plMessageLength,int* plRequestToSendReceived,int* plRC);
DllExport int CMSPTR(const char* psConversationID,int* plPrepareToReceiveType,int* plRC);
DllExport int CXSOT(int* plType,int* plRC);
DllExport int CMSST(const char psConversationID[CX_CID_SIZE], int* plSendType, int* plRC);
DllExport int CXWAIT(char psConversationID[CX_CID_SIZE], char psSymDestName[CX_SDN_SIZE], int* plStatusReceived, int* plRC);
}
#endif
