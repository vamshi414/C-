//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3664097902B1.cm preserve=no
//	$Date:   Jun 22 2020 13:35:48  $ $Author:   e1009839  $ $Revision:   1.25  $
//## end module%3664097902B1.cm

//## begin module%3664097902B1.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3664097902B1.cp

//## Module: CXOSIF28%3664097902B1; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.8A.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF28.cpp

//## begin module%3664097902B1.additionalIncludes preserve=no
//## end module%3664097902B1.additionalIncludes

//## begin module%3664097902B1.includes preserve=yes
#include <time.h>
#include "CXODIF08.hpp"
//## end module%3664097902B1.includes

#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
//## begin module%3664097902B1.declarations preserve=no
//## end module%3664097902B1.declarations

//## begin module%3664097902B1.additionalDeclarations preserve=yes
#ifdef MVS
extern "OS"
{
int CXTADJ(char* psDate,char* psTime,int* plOffset,int* plRC);
}
#endif
static const int iSecondsInDay = 86400; //60*60*24
static const int iSecondsInHour = 3600;
static const int dayOfWeek[7] = { 4, 5, 6, 0, 1, 2, 3 }; //Jan 1 1970 was a thursday
static const int daysToMonth[2][13] =
{
   { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 },
   { 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366 }
};
static const int daysInMonth[2][13] =
{
   { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 },
   { 0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }
};
static const time_t secondsToYear[100] = {
   0, 31536000, 63072000, 94694400, 126230400, 157766400, 189302400, 220924800, 252460800, 283996800,
   315532800, 347155200, 378691200, 410227200, 441763200, 473385600, 504921600, 536457600, 567993600,
   599616000, 631152000, 662688000, 694224000, 725846400, 757382400, 788918400, 820454400, 852076800,
   883612800, 915148800, 946684800, 978307200, 1009843200, 1041379200, 1072915200, 1104537600, 1136073600,
   1167609600, 1199145600, 1230768000, 1262304000, 1293840000, 1325376000, 1356998400, 1388534400, 1420070400,
   1451606400, 1483228800, 1514764800, 1546300800, 1577836800, 1609459200, 1640995200, 1672531200, 1704067200,
   1735689600, 1767225600, 1798761600, 1830297600, 1861920000, 1893456000, 1924992000, 1956528000, 1988150400,
   2019686400, 2051222400, 2082758400, 2114380800, 2145916800, 2177452800, 2208988800, 2240611200, 2272147200,
   2303683200, 2335219200, 2366841600, 2398377600, 2429913600, 2461449600, 2493072000, 2524608000, 2556144000,
   2587680000, 2619302400, 2650838400, 2682374400, 2713910400, 2745532800, 2777068800, 2808604800, 2840140800,
   2871763200, 2903299200, 2934835200, 2966371200, 2997993600, 3029529600, 3061065600, 3092601600, 3124224000 };
//## end module%3664097902B1.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Timestamp

Timestamp::Timestamp()
  //## begin Timestamp::Timestamp%366408C300CF_const.hasinit preserve=no
  //## end Timestamp::Timestamp%366408C300CF_const.hasinit
  //## begin Timestamp::Timestamp%366408C300CF_const.initialization preserve=yes
  //## end Timestamp::Timestamp%366408C300CF_const.initialization
{
  //## begin IF::Timestamp::Timestamp%366408C300CF_const.body preserve=yes
  //## end IF::Timestamp::Timestamp%366408C300CF_const.body
}


Timestamp::~Timestamp()
{
  //## begin IF::Timestamp::~Timestamp%366408C300CF_dest.body preserve=yes
  //## end IF::Timestamp::~Timestamp%366408C300CF_dest.body
}



//## Other Operations (implementation)
int Timestamp::adjust (string& strDate, string& strTime, int lOffset)
{
  //## begin IF::Timestamp::adjust%366408D6023F.body preserve=yes
   // strDate format YYYYMMDDJJJ
   // strTime format HHMMSS
   char szDate[13] = {"Jyyyymmddjjj"};
   char szTime[7] = {"hhmmss"};
   memcpy(szDate + 1,strDate.data() + 4,4);
   memcpy(szDate + 5,strDate.data(),4);
   memcpy(szDate + 9,strDate.data() + 8,3);
   memcpy(szTime,strTime.data(),6);
   int lRC = 0;
   if (lOffset > 0)
   {
      int iLimit = 999;
      while (lRC == 0 && lOffset > 0)
      {
#ifdef MVS
         lOffset > iLimit ?
            lOffset -= iLimit + (0 * CXTADJ(szDate,szTime,&iLimit,&lRC)) :
            lOffset -= lOffset + (0 * CXTADJ(szDate,szTime,&lOffset,&lRC));
#else
         lOffset > iLimit ?
            lOffset -= iLimit + (0 * DateTime::adjust(szDate,szTime,iLimit)) :
            lOffset -= lOffset + (0 * DateTime::adjust(szDate,szTime,lOffset));
#endif
      }
   }
   else
   {
      int iLimit = -999;
      while (lRC == 0 && lOffset < 0)
      {
#ifdef MVS
         lOffset > iLimit ?
            lOffset -= iLimit + (0 * CXTADJ(szDate,szTime,&iLimit,&lRC)) :
            lOffset -= lOffset + (0 * CXTADJ(szDate,szTime,&lOffset,&lRC));
#else
         lOffset > iLimit ?
            lOffset -= iLimit + (0 * DateTime::adjust(szDate,szTime,iLimit)) :
            lOffset -= lOffset + (0 * DateTime::adjust(szDate,szTime,lOffset));
#endif
      }
   }
   if (lRC == 0)
   {
      char sTemp[4];
      memcpy(sTemp,szDate + 1,4);
      memcpy(szDate + 1,szDate + 5,4);
      memcpy(szDate + 5,sTemp,4);
      strDate = szDate + 1;
      strTime = szTime;
   }
   return lRC;
  //## end IF::Timestamp::adjust%366408D6023F.body
}

int Timestamp::adjustGMT (string& strDate, string& strTime, int lOffset)
{
  //## begin IF::Timestamp::adjustGMT%3F8AF4150000.body preserve=yes
   // strDate format YYYYMMDDJJJ
   // strTime format HHMMSS
   char szDate[12] = { "YYYYMMDDJJJ" };
   char szTime[7] = { "hhmmss" };
   memcpy(szDate, strDate.data(), 11);
   memcpy(szTime, strTime.data(), 6);
   struct tm Tm;
   Tm.tm_yday = atoi(szDate + 8) -1;
   szDate[8] = '\0';
   Tm.tm_mday = atoi(szDate + 6);
   szDate[6] = '\0';
   Tm.tm_mon = atoi(szDate + 4) - 1;
   szDate[4] = '\0';
   Tm.tm_year = atoi(szDate);
   Tm.tm_sec = atoi(szTime + 4);
   szTime[4] = '\0';
   Tm.tm_min = atoi(szTime + 2);
   szTime[2] = '\0';
   Tm.tm_hour = atoi(szTime);
   adjustGMT(Tm, lOffset);
   snprintf(szDate,sizeof(szDate), "%04d%02d%02d%03d", Tm.tm_year, Tm.tm_mon + 1, Tm.tm_mday, Tm.tm_yday+1);
   snprintf(szTime,sizeof(szTime), "%02d%02d%02d", Tm.tm_hour, Tm.tm_min, Tm.tm_sec);
   strDate.assign(szDate);
   strTime.assign(szTime);
   return 0;
  //## end IF::Timestamp::adjustGMT%3F8AF4150000.body
}

void Timestamp::adjustGMT (struct tm& Tm, int lOffset)
{
  //## begin IF::Timestamp::adjustGMT%5B994D210281.body preserve=yes
   bool bLeap = 0;
   Tm.tm_min += lOffset;
   if (Tm.tm_min >= 60)
   { //moving time forward to next hour
      while (Tm.tm_min >= 60)
      {
         Tm.tm_min -= 60;
         Tm.tm_hour++;
         if (Tm.tm_hour == 24)
         {
            Tm.tm_hour = 0;
            Tm.tm_mday++;
            Tm.tm_yday++;
            bLeap = ((Tm.tm_year + 1900) % 400 == 0 || ((Tm.tm_year + 1900) % 4 == 0 && (Tm.tm_year + 1900) % 100 != 0));
            if (Tm.tm_mday > daysInMonth[bLeap][Tm.tm_mon+1])
            {
               Tm.tm_mday = 1;
               Tm.tm_mon++;
               if (Tm.tm_mon > 11)
               {
                  Tm.tm_mon = 0;
                  Tm.tm_year++;
                  Tm.tm_yday = 0;
               }
            }
         }
      }
   }
   else if (Tm.tm_min < 0)
   { //moving time backward to previous hour
      while (Tm.tm_min < 0)
      {
         Tm.tm_min *= -1;
         Tm.tm_min = 60 - Tm.tm_min;
         Tm.tm_hour--;
         if (Tm.tm_hour < 0)
         {
            Tm.tm_hour = 23;
            Tm.tm_mday--;
            if (Tm.tm_mday < 1)
            {
               Tm.tm_mon--;
               if (Tm.tm_mon < 0)
               {
                  Tm.tm_mon = 11;
                  Tm.tm_year--;
               }
               bLeap = ((Tm.tm_year + 1900) % 400 == 0 || ((Tm.tm_year + 1900) % 4 == 0 && (Tm.tm_year + 1900) % 100 != 0));
               Tm.tm_mday = daysInMonth[bLeap][Tm.tm_mon+1];
            }
            Tm.tm_yday--;
            if (Tm.tm_yday < 0)
               Tm.tm_yday = (bLeap) ? 365 : 364;
         }
      }
   }
  //## end IF::Timestamp::adjustGMT%5B994D210281.body
}

string Timestamp::format (const string& strTimestamp)
{
  //## begin IF::Timestamp::format%4433C7EE0213.body preserve=yes
   string strBuffer(strTimestamp);
   if (strBuffer.length() >= 16)
      strBuffer.insert(14,":");
   if (strBuffer.length() >= 14)
   {
      strBuffer.insert(12,":");
      strBuffer.insert(10,":");
      strBuffer.insert(8," ");
   }
   if (strBuffer.length() >= 8)
   {
      strBuffer.insert(6,"-");
      strBuffer.insert(4,"-");
   }
   return strBuffer;
  //## end IF::Timestamp::format%4433C7EE0213.body
}

void Timestamp::gmt (struct tm& hTm, time_t tTime)
{
  //## begin IF::Timestamp::gmt%5B99490600AA.body preserve=yes
   hTm.tm_isdst = -1;
   int i = 0;
   while (tTime >= secondsToYear[i])
      i++;
   i--;
   hTm.tm_year = i + 70;
   tTime -= secondsToYear[i];
   int iTotalDaysSince1970 = secondsToYear[i] / iSecondsInDay;
   hTm.tm_yday = 0;
   while (tTime >= iSecondsInDay)
   {
      tTime -= iSecondsInDay;
      hTm.tm_yday++;
   }
   iTotalDaysSince1970 += hTm.tm_yday;
   hTm.tm_wday = dayOfWeek[iTotalDaysSince1970 % 7];
   bool bLeap = ((hTm.tm_year + 1900) % 400 == 0 || ((hTm.tm_year + 1900) % 4 == 0 && (hTm.tm_year + 1900) % 100 != 0));
   i = 1;
   while (hTm.tm_yday + 1 > daysToMonth[bLeap][i])
      i++;
   hTm.tm_mon = i - 1;
   hTm.tm_mday = hTm.tm_yday + 1 - ((i > 1) ? daysToMonth[bLeap][i - 1] : 0);
   hTm.tm_hour = 0;
   while (tTime >= iSecondsInHour)
   {
      tTime -= iSecondsInHour;
      hTm.tm_hour++;
   }
   hTm.tm_min = 0;
   while (tTime >= 60)
   {
      tTime -= 60;
      hTm.tm_min++;
   }
   hTm.tm_sec = tTime;
  //## end IF::Timestamp::gmt%5B99490600AA.body
}

int Timestamp::gmtToLocal (string& strYYYYMMDDHHMMSS)
{
  //## begin IF::Timestamp::gmtToLocal%483E77D100D2.body preserve=yes
   time_t sysTime,localTime,gmTime,offsetTime;
   struct tm Tm;
   Tm.tm_year = atoi(strYYYYMMDDHHMMSS.substr(0,4).c_str()) - 1900;
   Tm.tm_mon = atoi(strYYYYMMDDHHMMSS.substr(4,2).c_str()) - 1;
   Tm.tm_mday = atoi(strYYYYMMDDHHMMSS.substr(6,2).c_str());
   Tm.tm_hour = atoi(strYYYYMMDDHHMMSS.substr(8,2).c_str());
   Tm.tm_min = atoi(strYYYYMMDDHHMMSS.substr(10,2).c_str());
   Tm.tm_sec =  atoi(strYYYYMMDDHHMMSS.substr(12,2).c_str());
   Tm.tm_isdst = -1;
   sysTime = mktime(&Tm);
#ifdef _WIN32
   gmtime_s(&Tm,&sysTime);
#else
   gmtime_r(&sysTime,&Tm);
#endif
   gmTime = mktime(&Tm);
#ifdef _WIN32
   localtime_s(&Tm,&sysTime);
#else
   localtime_r(&sysTime,&Tm);
#endif
   localTime = mktime(&Tm);
   offsetTime = difftime(localTime,gmTime);
   sysTime += offsetTime;
   if (Tm.tm_isdst == 1)
      sysTime += 3600;
   struct tm htm;
#ifdef _WIN32
   localtime_s(&htm,&sysTime);
#else
   localtime_r(&sysTime,&htm);
#endif
   char sFormattedTime[15];
   strftime(sFormattedTime,15,"%Y%m%d%H%M%S",&htm);
   strYYYYMMDDHHMMSS.replace(0,14,sFormattedTime);
   return 0;
  //## end IF::Timestamp::gmtToLocal%483E77D100D2.body
}

// Additional Declarations
  //## begin IF::Timestamp%366408C300CF.declarations preserve=yes
  //## end IF::Timestamp%366408C300CF.declarations
} // namespace IF

//## begin module%3664097902B1.epilog preserve=yes
//## end module%3664097902B1.epilog
