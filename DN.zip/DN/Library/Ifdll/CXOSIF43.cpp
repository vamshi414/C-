//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E43FBDB007D.cm preserve=no
//	$Date:   Mar 25 2015 14:01:38  $ $Author:   e1009839  $ $Revision:   1.5  $
//## end module%3E43FBDB007D.cm

//## begin module%3E43FBDB007D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3E43FBDB007D.cp

//## Module: CXOSIF43%3E43FBDB007D; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF43.cpp

//## begin module%3E43FBDB007D.additionalIncludes preserve=no
//## end module%3E43FBDB007D.additionalIncludes

//## begin module%3E43FBDB007D.includes preserve=yes
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif
//## end module%3E43FBDB007D.includes

#ifndef CXOSIF43_h
#include "CXODIF43.hpp"
#endif
//## begin module%3E43FBDB007D.declarations preserve=no
//## end module%3E43FBDB007D.declarations

//## begin module%3E43FBDB007D.additionalDeclarations preserve=yes
//## end module%3E43FBDB007D.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Registry 

//## begin IF::Registry::Service%54786BDA03AA.attr preserve=no  public: static string* {V} 0
string* Registry::m_pstrService = 0;
//## end IF::Registry::Service%54786BDA03AA.attr

Registry::Registry()
  //## begin Registry::Registry%3E43FB280251_const.hasinit preserve=no
  //## end Registry::Registry%3E43FB280251_const.hasinit
  //## begin Registry::Registry%3E43FB280251_const.initialization preserve=yes
  //## end Registry::Registry%3E43FB280251_const.initialization
{
  //## begin IF::Registry::Registry%3E43FB280251_const.body preserve=yes
  //## end IF::Registry::Registry%3E43FB280251_const.body
}


Registry::~Registry()
{
  //## begin IF::Registry::~Registry%3E43FB280251_dest.body preserve=yes
  //## end IF::Registry::~Registry%3E43FB280251_dest.body
}



//## Other Operations (implementation)
bool Registry::get (const string& strKey, string* pstrValue)
{
  //## begin IF::Registry::get%3E43FB5C003E.body preserve=yes
#ifdef _WIN32
   char szValue[_MAX_PATH];
   DWORD lValue = _MAX_PATH;
   HKEY hKey = 0;
   string strText("SOFTWARE\\FIS\\");
   strText += getService();
   strText += "\\Server\\Settings";
   if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,TEXT(strText.c_str()),0,KEY_QUERY_VALUE,&hKey) == ERROR_SUCCESS)
   {
      if (RegQueryValueEx(hKey,strKey.c_str(),NULL,NULL,(LPBYTE)szValue,&lValue) == ERROR_SUCCESS)
         *pstrValue = szValue;
   }
   else
   {
      strText = "SOFTWARE\\eFunds, Inc.\\";
      strText += getService();
      strText += "\\Server\\Settings";
      if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,TEXT(strText.c_str()),0,KEY_QUERY_VALUE,&hKey) == ERROR_SUCCESS)
         if (RegQueryValueEx(hKey,strKey.c_str(),NULL,NULL,(LPBYTE)szValue,&lValue) == ERROR_SUCCESS)
            *pstrValue = szValue;
   }
   RegCloseKey(hKey);
#endif
   return true;
  //## end IF::Registry::get%3E43FB5C003E.body
}

const string& Registry::getService ()
{
  //## begin IF::Registry::getService%54786E010229.body preserve=yes
   if (!m_pstrService)
      m_pstrService = new string("DataNavigator");
   return *m_pstrService;
  //## end IF::Registry::getService%54786E010229.body
}

bool Registry::put (const string& strKey, const string& strValue)
{
  //## begin IF::Registry::put%3E43FB9E030D.body preserve=yes
#ifdef _WIN32
   HKEY hKey = 0;
   DWORD dwDisposition = 0;
   string strText("SOFTWARE\\FIS\\");
   strText += getService();
   strText += "\\Server\\Settings";
   if (RegCreateKeyEx(HKEY_LOCAL_MACHINE,TEXT(strText.c_str()),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,&dwDisposition) == ERROR_SUCCESS)
      if (RegSetValueEx(hKey,strKey.c_str(),NULL,REG_SZ,(LPBYTE)strValue.data(),strValue.length()) != ERROR_SUCCESS)
         ;
   RegCloseKey(hKey);
#endif
   return true;
  //## end IF::Registry::put%3E43FB9E030D.body
}

void Registry::setService (const char* pszService)
{
  //## begin IF::Registry::setService%54786E2D028E.body preserve=yes
   if (!m_pstrService)
      m_pstrService = new string("DataNavigator");
   int i = strlen(pszService);
   if (i == 0)
      return;
   while (i > 0 && pszService[--i] != ' ')
      ;
   if (i > 0)
      m_pstrService->assign(pszService,i);
  //## end IF::Registry::setService%54786E2D028E.body
}

// Additional Declarations
  //## begin IF::Registry%3E43FB280251.declarations preserve=yes
  //## end IF::Registry%3E43FB280251.declarations

} // namespace IF

//## begin module%3E43FBDB007D.epilog preserve=yes
//## end module%3E43FBDB007D.epilog
