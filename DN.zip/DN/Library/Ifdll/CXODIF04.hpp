//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%362662B10081.cm preserve=no
//	$Date:   Jan 31 2017 13:32:00  $ $Author:   e1009510  $ $Revision:   1.12  $
//## end module%362662B10081.cm

//## begin module%362662B10081.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%362662B10081.cp

//## Module: CXOSIF04%362662B10081; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF04.hpp

#ifndef CXOSIF04_h
#define CXOSIF04_h 1

//## begin module%362662B10081.additionalIncludes preserve=no
//## end module%362662B10081.additionalIncludes

//## begin module%362662B10081.includes preserve=yes
//## end module%362662B10081.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%362662B10081.declarations preserve=no
//## end module%362662B10081.declarations

//## begin module%362662B10081.additionalDeclarations preserve=yes
//## end module%362662B10081.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::CodeTable%348027B0024A.preface preserve=yes
//## end IF::CodeTable%348027B0024A.preface

//## Class: CodeTable%348027B0024A
//	The CodeTable class encapsulates an interface to the
//	Connex translation tables.
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport CodeTable : public reusable::Object  //## Inherits: <unnamed>%348028DF0119
{
  //## begin IF::CodeTable%348027B0024A.initialDeclarations preserve=yes
  public:
      enum TranslateType
      {
         CX_ASCII_TO_EBCDIC,
         CX_EBCDIC_TO_ASCII,
         CX_ASCII_TO_BCD
      };
  //## end IF::CodeTable%348027B0024A.initialDeclarations

  public:
    //## Constructors (generated)
      CodeTable();

    //## Destructor (generated)
      virtual ~CodeTable();


    //## Other Operations (specified)
      //## Operation: byteToNibble%559C15750160
      static void byteToNibble (const string& strInput, unsigned char* psBuffer);

      //## Operation: hexToDouble%4D12815D0325
      static double hexToDouble (const char* pszBuffer);

      //## Operation: nibbleToBit%52FBFB1E0230
      static void nibbleToBit (const string& strNibbles, string& strBits);

      //## Operation: nibbleToByte%4714BC7203E2
      static void nibbleToByte (const char* psBuffer, unsigned int uiBuffer, string& strResult, bool bTruncate = false);

      //## Operation: translate%3481C5590239
      //	Translate characters between ASCII and EBCDIC.
      //## Semantics:
      //	1. If nTranslateType is CX_ASCII_TO_EBCDIC, call CXATOE.
      //	2. If nTranslateType is CX_EBCDIC_TO_ASCII, call CXETOA.
      static void translate (char* psBuffer, unsigned int uiBuffer, enum TranslateType nTranslateType);

    // Additional Public Declarations
      //## begin IF::CodeTable%348027B0024A.public preserve=yes
      //## end IF::CodeTable%348027B0024A.public

  protected:
    // Additional Protected Declarations
      //## begin IF::CodeTable%348027B0024A.protected preserve=yes
      //## end IF::CodeTable%348027B0024A.protected

  private:
    // Additional Private Declarations
      //## begin IF::CodeTable%348027B0024A.private preserve=yes
      //## end IF::CodeTable%348027B0024A.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::CodeTable%348027B0024A.implementation preserve=yes
      //## end IF::CodeTable%348027B0024A.implementation

};

//## begin IF::CodeTable%348027B0024A.postscript preserve=yes
//## end IF::CodeTable%348027B0024A.postscript

} // namespace IF

//## begin module%362662B10081.epilog preserve=yes
using namespace IF;
//## end module%362662B10081.epilog


#endif
