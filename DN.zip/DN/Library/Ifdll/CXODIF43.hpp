//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E43FBD803A9.cm preserve=no
//	$Date:   Mar 25 2015 14:01:36  $ $Author:   e1009839  $ $Revision:   1.2  $
//## end module%3E43FBD803A9.cm

//## begin module%3E43FBD803A9.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3E43FBD803A9.cp

//## Module: CXOSIF43%3E43FBD803A9; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF43.hpp

#ifndef CXOSIF43_h
#define CXOSIF43_h 1

//## begin module%3E43FBD803A9.additionalIncludes preserve=no
//## end module%3E43FBD803A9.additionalIncludes

//## begin module%3E43FBD803A9.includes preserve=yes
//## end module%3E43FBD803A9.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%3E43FBD803A9.declarations preserve=no
//## end module%3E43FBD803A9.declarations

//## begin module%3E43FBD803A9.additionalDeclarations preserve=yes
//## end module%3E43FBD803A9.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Registry%3E43FB280251.preface preserve=yes
//## end IF::Registry%3E43FB280251.preface

//## Class: Registry%3E43FB280251
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport Registry : public reusable::Object  //## Inherits: <unnamed>%3E43FB920157
{
  //## begin IF::Registry%3E43FB280251.initialDeclarations preserve=yes
  //## end IF::Registry%3E43FB280251.initialDeclarations

  public:
    //## Constructors (generated)
      Registry();

    //## Destructor (generated)
      virtual ~Registry();


    //## Other Operations (specified)
      //## Operation: get%3E43FB5C003E
      static bool get (const string& strKey, string* pstrValue);

      //## Operation: getService%54786E010229
      static const string& getService ();

      //## Operation: put%3E43FB9E030D
      static bool put (const string& strKey, const string& strValue);

      //## Operation: setService%54786E2D028E
      static void setService (const char* pszService);

    // Additional Public Declarations
      //## begin IF::Registry%3E43FB280251.public preserve=yes
      //## end IF::Registry%3E43FB280251.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Registry%3E43FB280251.protected preserve=yes
      //## end IF::Registry%3E43FB280251.protected

  private:
    // Additional Private Declarations
      //## begin IF::Registry%3E43FB280251.private preserve=yes
      //## end IF::Registry%3E43FB280251.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Service%54786BDA03AA
      //## begin IF::Registry::Service%54786BDA03AA.attr preserve=no  public: static string* {V} 0
      static string* m_pstrService;
      //## end IF::Registry::Service%54786BDA03AA.attr

    // Additional Implementation Declarations
      //## begin IF::Registry%3E43FB280251.implementation preserve=yes
      //## end IF::Registry%3E43FB280251.implementation

};

//## begin IF::Registry%3E43FB280251.postscript preserve=yes
//## end IF::Registry%3E43FB280251.postscript

} // namespace IF

//## begin module%3E43FBD803A9.epilog preserve=yes
using namespace IF;
//## end module%3E43FBD803A9.epilog


#endif
