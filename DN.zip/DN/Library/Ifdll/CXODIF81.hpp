//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%550C1ABC01D0.cm preserve=no
//	$Date:   Apr 02 2018 15:22:56  $ $Author:   e1009652  $ $Revision:   1.8  $
//## end module%550C1ABC01D0.cm

//## begin module%550C1ABC01D0.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%550C1ABC01D0.cp

//## Module: CXOSIF81%550C1ABC01D0; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.8A.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF81.hpp

#ifndef CXOSIF81_h
#define CXOSIF81_h 1

//## begin module%550C1ABC01D0.additionalIncludes preserve=no
//## end module%550C1ABC01D0.additionalIncludes

//## begin module%550C1ABC01D0.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#include <Ws2tcpip.h>
#else
#include <unistd.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>
#endif
#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
//## end module%550C1ABC01D0.includes

#ifndef CXOSIF39_h
#include "CXODIF39.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CriticalSection;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
class Extract;
class Sleep;

} // namespace IF

//## begin module%550C1ABC01D0.declarations preserve=no
//## end module%550C1ABC01D0.declarations

//## begin module%550C1ABC01D0.additionalDeclarations preserve=yes
//## end module%550C1ABC01D0.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::SecureSocketQueue%550C1A730245.preface preserve=yes
//## end IF::SecureSocketQueue%550C1A730245.preface

//## Class: SecureSocketQueue%550C1A730245
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%550C29F1008F;Extract { -> F}
//## Uses: <unnamed>%550C2A050190;Sleep { -> F}
//## Uses: <unnamed>%550C2A25025B;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%58ECE04101EF;FlatFile { -> F}

class DllExport SecureSocketQueue : public SocketQueue  //## Inherits: <unnamed>%550C1A8C01F2
{
  //## begin IF::SecureSocketQueue%550C1A730245.initialDeclarations preserve=yes
  //## end IF::SecureSocketQueue%550C1A730245.initialDeclarations

  public:
    //## Constructors (generated)
      SecureSocketQueue();

      SecureSocketQueue(const SecureSocketQueue &right);

    //## Constructors (specified)
      //## Operation: SecureSocketQueue%550C21F70164
      SecureSocketQueue (const char* pszName);

    //## Destructor (generated)
      virtual ~SecureSocketQueue();

    //## Assignment Operation (generated)
      SecureSocketQueue & operator=(const SecureSocketQueue &right);


    //## Other Operations (specified)
      //## Operation: initialize%58ECD99601F6
      bool initialize (const char* pszName);

      //## Operation: initServerCTX%550C1DDC0138
      SSL_CTX* initServerCTX ();

      //## Operation: loadCertificates%550C1E07037F
      bool loadCertificates (SSL_CTX* ctx);

      //## Operation: receive%58B82F47018B
      virtual size_t receive (void* pBuffer, size_t iLength);

      //## Operation: receive%58B837410277
      virtual bool receive ();

      //## Operation: send%58B83A7C0029
      virtual size_t send (void* pBuffer, size_t iLength);

      //## Operation: send%550C1DA70301
      virtual bool send (Message* pMessage, enum MessageType nMessageType);

    // Additional Public Declarations
      //## begin IF::SecureSocketQueue%550C1A730245.public preserve=yes
      string m_strClientCertificate;
      //## end IF::SecureSocketQueue%550C1A730245.public

  protected:
    // Additional Protected Declarations
      //## begin IF::SecureSocketQueue%550C1A730245.protected preserve=yes
      //## end IF::SecureSocketQueue%550C1A730245.protected

  private:
    // Additional Private Declarations
      //## begin IF::SecureSocketQueue%550C1A730245.private preserve=yes
      //## end IF::SecureSocketQueue%550C1A730245.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: SecureApplicationQueue%550C1E630320
      //## begin IF::SecureSocketQueue::SecureApplicationQueue%550C1E630320.attr preserve=no  private: static SecureSocketQueue* {U} 0
      static SecureSocketQueue* m_pSecureApplicationQueue;
      //## end IF::SecureSocketQueue::SecureApplicationQueue%550C1E630320.attr

      //## Attribute: SSL%550C1EA7034C
      //## begin IF::SecureSocketQueue::SSL%550C1EA7034C.attr preserve=no  private: SSL* {U} 0
      SSL* m_pSSL;
      //## end IF::SecureSocketQueue::SSL%550C1EA7034C.attr

      //## Attribute: CTX%550C1EC40218
      //## begin IF::SecureSocketQueue::CTX%550C1EC40218.attr preserve=no  private: SSL_CTX* {U} 0
      SSL_CTX* m_pCTX;
      //## end IF::SecureSocketQueue::CTX%550C1EC40218.attr

      //## Attribute: Method%550C1ED70229
      //## begin IF::SecureSocketQueue::Method%550C1ED70229.attr preserve=no  private: SSL_METHOD* {VC} 0
      const SSL_METHOD* m_pMethod;
      //## end IF::SecureSocketQueue::Method%550C1ED70229.attr

      //## Attribute: POST%58EF822B0003
      //## begin IF::SecureSocketQueue::POST%58EF822B0003.attr preserve=no  private: string {V} 
      string m_strPOST;
      //## end IF::SecureSocketQueue::POST%58EF822B0003.attr

    // Additional Implementation Declarations
      //## begin IF::SecureSocketQueue%550C1A730245.implementation preserve=yes
      //## end IF::SecureSocketQueue%550C1A730245.implementation

};

//## begin IF::SecureSocketQueue%550C1A730245.postscript preserve=yes
//## end IF::SecureSocketQueue%550C1A730245.postscript

} // namespace IF

//## begin module%550C1ABC01D0.epilog preserve=yes
//## end module%550C1ABC01D0.epilog


#endif
