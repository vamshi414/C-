//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36266FA90229.cm preserve=no
//	$Date:   Jan 03 2008 01:24:56  $ $Author:   D01321  $ $Revision:   1.4  $
//## end module%36266FA90229.cm

//## begin module%36266FA90229.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%36266FA90229.cp

//## Module: CXOSIF20%36266FA90229; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF20.hpp

#ifndef CXOSIF20_h
#define CXOSIF20_h 1

//## begin module%36266FA90229.additionalIncludes preserve=no
//## end module%36266FA90229.additionalIncludes

//## begin module%36266FA90229.includes preserve=yes
#include <set>
// $Date:   Jan 03 2008 01:24:56  $ $Author:   D01321  $ $Revision:   1.4  $
//## end module%36266FA90229.includes

#ifndef CXOSRU01_h
#include "CXODRU01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;
class RemoteObserver;
class Message;

} // namespace IF

//## begin module%36266FA90229.declarations preserve=no
//## end module%36266FA90229.declarations

//## begin module%36266FA90229.additionalDeclarations preserve=yes
//## end module%36266FA90229.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::SharedResource%34A405D70348.preface preserve=yes
//## end IF::SharedResource%34A405D70348.preface

//## Class: SharedResource%34A405D70348
//	The SharedResource class provides local and remote
//	notification of state changes to an object.
//
//	It is based on the Subject object in the Observer
//	pattern.
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%36289897033F;Queue { -> F}
//## Uses: <unnamed>%3628989B025F;Message { -> F}

class DllExport SharedResource : public reusable::Subject  //## Inherits: <unnamed>%34A406C903DC
{
  //## begin IF::SharedResource%34A405D70348.initialDeclarations preserve=yes
  //## end IF::SharedResource%34A405D70348.initialDeclarations

  public:
    //## Constructors (generated)
      SharedResource();

    //## Constructors (specified)
      //## Operation: SharedResource%34A406DD00AF
      //## Semantics:
      //	1. Copy pszName to m_strName.
      //	2. Call RemoteObserver::RemoteObserver(pszName).
      //	3. Call Queue::attach(m_strName) to monitor changes to
      //	this shared resource.
      SharedResource (const char* pszName);

    //## Destructor (generated)
      virtual ~SharedResource();


    //## Other Operations (specified)
      //## Operation: name%34B2CC45022E
      //	Returns the name of this shared resource.
      //## Semantics:
      //	1. Return m_strName.
      const string& name () const
      {
        //## begin IF::SharedResource::name%34B2CC45022E.body preserve=yes
         return m_strName;
        //## end IF::SharedResource::name%34B2CC45022E.body
      }

      //## Operation: notify%34A406F9002D
      //	Notify all local and remote observers of a state change
      //	in this SharedResource.
      //## Semantics:
      //	1. Call Subject::notify() to notify local observers.
      //	2. Use Message::instance(Message::OUTBOUND).
      //	3. Call Message::reset().
      //	4. Format a remote notification message.
      //	5. Call Message::send(m_strName) to notify remote
      //	observers.
      void notify ();

      //## Operation: commit%476A6BB1008E
      static void commit ();

      //## Operation: rollback%476A6BC20189
      static void rollback ();

    // Additional Public Declarations
      //## begin IF::SharedResource%34A405D70348.public preserve=yes
      //## end IF::SharedResource%34A405D70348.public

  protected:
    // Additional Protected Declarations
      //## begin IF::SharedResource%34A405D70348.protected preserve=yes
      //## end IF::SharedResource%34A405D70348.protected

  private:
    // Additional Private Declarations
      //## begin IF::SharedResource%34A405D70348.private preserve=yes
      //## end IF::SharedResource%34A405D70348.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Name%34A407520202
      //## begin IF::SharedResource::Name%34A407520202.attr preserve=no  private: string {U} 
      string m_strName;
      //## end IF::SharedResource::Name%34A407520202.attr

      //## Attribute: SharedObjects%477A1BB200E7
      //## begin IF::SharedResource::SharedObjects%477A1BB200E7.attr preserve=no  private: static set<string, less<string> > {R} 0
      static set<string, less<string> > *m_pSharedObjects;
      //## end IF::SharedResource::SharedObjects%477A1BB200E7.attr

    // Data Members for Associations

      //## Association: Connex Library::IF_CAT::<unnamed>%36279B2902FA
      //## Role: SharedResource::<m_pRemoteObserver>%36279B2B0072
      //## begin IF::SharedResource::<m_pRemoteObserver>%36279B2B0072.role preserve=no  public: IF::RemoteObserver { -> RFHgN}
      RemoteObserver *m_pRemoteObserver;
      //## end IF::SharedResource::<m_pRemoteObserver>%36279B2B0072.role

    // Additional Implementation Declarations
      //## begin IF::SharedResource%34A405D70348.implementation preserve=yes
      //## end IF::SharedResource%34A405D70348.implementation

};

//## begin IF::SharedResource%34A405D70348.postscript preserve=yes
//## end IF::SharedResource%34A405D70348.postscript

} // namespace IF

//## begin module%36266FA90229.epilog preserve=yes
using namespace IF;
//## end module%36266FA90229.epilog


#endif
