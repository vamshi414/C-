//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4B0C3E90000F.cm preserve=no
//	$Date:   Jan 18 2010 15:28:24  $ $Author:   D92186  $
//	$Revision:   1.2  $
//## end module%4B0C3E90000F.cm

//## begin module%4B0C3E90000F.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%4B0C3E90000F.cp

//## Module: CXOSIF56%4B0C3E90000F; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF56.hpp

#ifndef CXOSIF56_h
#define CXOSIF56_h 1

//## begin module%4B0C3E90000F.additionalIncludes preserve=no
//## end module%4B0C3E90000F.additionalIncludes

//## begin module%4B0C3E90000F.includes preserve=yes
#include <map>
//## end module%4B0C3E90000F.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class ZosFile;
class WindowsFile;
class UnixFile;
class File;

} // namespace IF

//## begin module%4B0C3E90000F.declarations preserve=no
//## end module%4B0C3E90000F.declarations

//## begin module%4B0C3E90000F.additionalDeclarations preserve=yes
//## end module%4B0C3E90000F.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::OperatingSystemFileFactory%4B0C3E4B00F3.preface preserve=yes
//## end IF::OperatingSystemFileFactory%4B0C3E4B00F3.preface

//## Class: OperatingSystemFileFactory%4B0C3E4B00F3
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4B15682401DB;File { -> F}
//## Uses: <unnamed>%4B15685B01D5;ZosFile { -> F}
//## Uses: <unnamed>%4B15685D03B9;UnixFile { -> F}
//## Uses: <unnamed>%4B15686002AF;WindowsFile { -> F}

class DllExport OperatingSystemFileFactory : public reusable::Object  //## Inherits: <unnamed>%4B154A1000E0
{
  //## begin IF::OperatingSystemFileFactory%4B0C3E4B00F3.initialDeclarations preserve=yes
  //## end IF::OperatingSystemFileFactory%4B0C3E4B00F3.initialDeclarations

  public:
    //## Constructors (generated)
      OperatingSystemFileFactory();

    //## Destructor (generated)
      virtual ~OperatingSystemFileFactory();


    //## Other Operations (specified)
      //## Operation: create%4B154ACC023B
      virtual IF::File* create ();

      //## Operation: create%4B156B41028D
      virtual IF::File* create (const char* pszName);

      //## Operation: create%4B156B460295
      virtual IF::File* create (const char* pszName, const char* pszMember);

      //## Operation: instance%4B154ACC024F
      static OperatingSystemFileFactory* instance ();

    // Additional Public Declarations
      //## begin IF::OperatingSystemFileFactory%4B0C3E4B00F3.public preserve=yes
      //## end IF::OperatingSystemFileFactory%4B0C3E4B00F3.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Classes%4B154ADD00F7
      //## begin IF::OperatingSystemFileFactory::Classes%4B154ADD00F7.attr preserve=no  public: map<string,int,less<string> > {U} 
      map<string,int,less<string> > m_hClasses;
      //## end IF::OperatingSystemFileFactory::Classes%4B154ADD00F7.attr

    // Additional Protected Declarations
      //## begin IF::OperatingSystemFileFactory%4B0C3E4B00F3.protected preserve=yes
      //## end IF::OperatingSystemFileFactory%4B0C3E4B00F3.protected

  private:
    // Additional Private Declarations
      //## begin IF::OperatingSystemFileFactory%4B0C3E4B00F3.private preserve=yes
      //## end IF::OperatingSystemFileFactory%4B0C3E4B00F3.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%4B154ADD00ED
      //## begin IF::OperatingSystemFileFactory::Instance%4B154ADD00ED.attr preserve=no  private: static OperatingSystemFileFactory {R} 0
      static OperatingSystemFileFactory *m_pInstance;
      //## end IF::OperatingSystemFileFactory::Instance%4B154ADD00ED.attr

    // Additional Implementation Declarations
      //## begin IF::OperatingSystemFileFactory%4B0C3E4B00F3.implementation preserve=yes
      //## end IF::OperatingSystemFileFactory%4B0C3E4B00F3.implementation

};

//## begin IF::OperatingSystemFileFactory%4B0C3E4B00F3.postscript preserve=yes
//## end IF::OperatingSystemFileFactory%4B0C3E4B00F3.postscript

} // namespace IF

//## begin module%4B0C3E90000F.epilog preserve=yes
//## end module%4B0C3E90000F.epilog


#endif
