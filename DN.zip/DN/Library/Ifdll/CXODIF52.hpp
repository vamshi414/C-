//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%491EED1D0167.cm preserve=no
//## end module%491EED1D0167.cm

//## begin module%491EED1D0167.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%491EED1D0167.cp

//## Module: CXOSIF52%491EED1D0167; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF52.hpp

#ifndef CXOSIF52_h
#define CXOSIF52_h 1

//## begin module%491EED1D0167.additionalIncludes preserve=no
//## end module%491EED1D0167.additionalIncludes

//## begin module%491EED1D0167.includes preserve=yes
//## end module%491EED1D0167.includes

#ifndef CXOSIF50_h
#include "CXODIF50.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class SecondaryCodes;
class SiteSpecification;
class Extract;

} // namespace IF

//## begin module%491EED1D0167.declarations preserve=no
//## end module%491EED1D0167.declarations

//## begin module%491EED1D0167.additionalDeclarations preserve=yes
//## end module%491EED1D0167.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::WindowsFile%491EEC89003E.preface preserve=yes
//## end IF::WindowsFile%491EEC89003E.preface

//## Class: WindowsFile%491EEC89003E
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%491EFBE001A5;Extract { -> F}
//## Uses: <unnamed>%491EFBE203D8;Trace { -> F}
//## Uses: <unnamed>%491EFBE403C8;SecondaryCodes { -> F}
//## Uses: <unnamed>%491EFBE7000F;reusable::Transaction { -> F}
//## Uses: <unnamed>%491EFBEA008C;SiteSpecification { -> F}

class DllExport WindowsFile : public File  //## Inherits: <unnamed>%491EEC99007D
{
  //## begin IF::WindowsFile%491EEC89003E.initialDeclarations preserve=yes
  //## end IF::WindowsFile%491EEC89003E.initialDeclarations

  public:
    //## Constructors (generated)
      WindowsFile();

    //## Constructors (specified)
      //## Operation: WindowsFile%491EEFE2009C
      WindowsFile (const char* pszName, const char* pszMember);

      //## Operation: WindowsFile%491EEFE303B9
      WindowsFile (const char* pszName);

    //## Destructor (generated)
      virtual ~WindowsFile();


    //## Other Operations (specified)
      //## Operation: close%639F8C3C039F
      virtual bool close ();

      //## Operation: copy%4C519D3A0399
      virtual bool copy (const char* pszTarget, const char* pszOutputFileName = 0);

      //## Operation: getBaseName%4C507EAE0184
      virtual bool getBaseName (string& strBaseName, bool bIncludeExtension = false);

      //## Operation: isFolderEmpty%639F8D14023C
      static bool isFolderEmpty (const char* pszFolder);

      //## Operation: move%491EF44D007D
      virtual bool move (const char* pszTarget, const char* pszOutputFileName = 0);

      //## Operation: open%491EF8A0038A
      virtual bool open (enum OpenType nOpenType = CX_OPEN_INPUT);

      //## Operation: pick%65B26FC3003B
      static bool pick (const char* pszFolder, reusable::string& strDatasetName);

      //## Operation: purge%496DFD92035B
      static void purge (const char* pszFolder, const string& strPeriod);

      //## Operation: purgeFolder%4AB935A20071
      static void purgeFolder (const char* pszFolder, const string& strPeriod);

      //## Operation: remove%491EF56301A5
      virtual bool remove ();

      //## Operation: seek%516C0B5E02C2
      virtual void seek (int SeekPos, enum SeekOffset nSeekOffset = CX_SEEK_SET);

      //## Operation: tellg%516C0B5E02C7
      virtual int tellg ();

      //## Operation: unzip%4C6954840357
      virtual bool unzip ();

      //## Operation: write%491EF7FB0167
      virtual bool write (char* psBuffer, int lRecordLength);

      //## Operation: zip%4C69548B024D
      virtual bool zip (const string& strArchiveName);

    // Additional Public Declarations
      //## begin IF::WindowsFile%491EEC89003E.public preserve=yes
      //## end IF::WindowsFile%491EEC89003E.public

  protected:
    // Additional Protected Declarations
      //## begin IF::WindowsFile%491EEC89003E.protected preserve=yes
      //## end IF::WindowsFile%491EEC89003E.protected

  private:

    //## Other Operations (specified)
      //## Operation: purgeFiles%4ABA34160054
      static void purgeFiles (const string& strFolder);

    // Additional Private Declarations
      //## begin IF::WindowsFile%491EEC89003E.private preserve=yes
      //## end IF::WindowsFile%491EEC89003E.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::WindowsFile%491EEC89003E.implementation preserve=yes
      //## end IF::WindowsFile%491EEC89003E.implementation

};

//## begin IF::WindowsFile%491EEC89003E.postscript preserve=yes
//## end IF::WindowsFile%491EEC89003E.postscript

} // namespace IF

//## begin module%491EED1D0167.epilog preserve=yes
//## end module%491EED1D0167.epilog


#endif
