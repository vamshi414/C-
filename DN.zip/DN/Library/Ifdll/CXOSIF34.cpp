//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36DC5A390029.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DC5A390029.cm

//## begin module%36DC5A390029.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DC5A390029.cp

//## Module: CXOSIF34%36DC5A390029; Package body
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXOSIF34.cpp

//## begin module%36DC5A390029.additionalIncludes preserve=no
//## end module%36DC5A390029.additionalIncludes

//## begin module%36DC5A390029.includes preserve=yes
// $Date:   Jun 30 2006 11:35:52  $ $Author:   D02405  $ $Revision:   1.4  $
//## end module%36DC5A390029.includes

#ifndef CXOSIF31_h
#include "CXODIF31.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOSIF34_h
#include "CXODIF34.hpp"
#endif


//## begin module%36DC5A390029.declarations preserve=no
//## end module%36DC5A390029.declarations

//## begin module%36DC5A390029.additionalDeclarations preserve=yes

#define CLASSES 2

const char* pszDiskQueueClass[CLASSES] =
{
   "Queue",
   "Signal" 
};
//## end module%36DC5A390029.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::DiskQueueFactory 

DiskQueueFactory::DiskQueueFactory()
  //## begin DiskQueueFactory::DiskQueueFactory%36DC59A600BE_const.hasinit preserve=no
  //## end DiskQueueFactory::DiskQueueFactory%36DC59A600BE_const.hasinit
  //## begin DiskQueueFactory::DiskQueueFactory%36DC59A600BE_const.initialization preserve=yes
  //## end DiskQueueFactory::DiskQueueFactory%36DC59A600BE_const.initialization
{
  //## begin IF::DiskQueueFactory::DiskQueueFactory%36DC59A600BE_const.body preserve=yes
   memcpy(m_sID,"IF34",4);
   string strClass;
   for (int m = 0;m < CLASSES;++m)
   {
      strClass = pszDiskQueueClass[m];
      m_hClasses.insert(map<string,int,less<string> >::value_type(strClass,m));
   }
  //## end IF::DiskQueueFactory::DiskQueueFactory%36DC59A600BE_const.body
}


DiskQueueFactory::~DiskQueueFactory()
{
  //## begin IF::DiskQueueFactory::~DiskQueueFactory%36DC59A600BE_dest.body preserve=yes
   m_hClasses.erase(m_hClasses.begin(),m_hClasses.end());
  //## end IF::DiskQueueFactory::~DiskQueueFactory%36DC59A600BE_dest.body
}



//## Other Operations (implementation)
Object* DiskQueueFactory::create (const char* pszClass, const char* pszValue)
{
  //## begin IF::DiskQueueFactory::create%36DC59DB02AF.body preserve=yes
   string strClass(pszClass);
   map<string,int,less<string> >::iterator pClass = m_hClasses.find(strClass);
   if (pClass == m_hClasses.end())
      return 0;
   switch ((*pClass).second)
   {
      case 0:
         return new DiskQueue(pszValue);
      case 1:
         return new Signal(pszValue);
   }
   return 0;
  //## end IF::DiskQueueFactory::create%36DC59DB02AF.body
}

// Additional Declarations
  //## begin IF::DiskQueueFactory%36DC59A600BE.declarations preserve=yes
  //## end IF::DiskQueueFactory%36DC59A600BE.declarations

} // namespace IF

//## begin module%36DC5A390029.epilog preserve=yes
//## end module%36DC5A390029.epilog
