//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4CC9E6D10371.cm preserve=no
//	$Date:   Nov 10 2010 11:47:54  $ $Author:   D94163  $
//	$Revision:   1.1  $
//## end module%4CC9E6D10371.cm

//## begin module%4CC9E6D10371.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4CC9E6D10371.cp

//## Module: CXOSIF57%4CC9E6D10371; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF57.hpp

#ifndef CXOSIF57_h
#define CXOSIF57_h 1

//## begin module%4CC9E6D10371.additionalIncludes preserve=no
//## end module%4CC9E6D10371.additionalIncludes

//## begin module%4CC9E6D10371.includes preserve=yes
#include <vector>
//## end module%4CC9E6D10371.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Signal;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Memory;

} // namespace IF

//## begin module%4CC9E6D10371.declarations preserve=no
//## end module%4CC9E6D10371.declarations

//## begin module%4CC9E6D10371.additionalDeclarations preserve=yes
//## end module%4CC9E6D10371.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::SignalList%4CC9E6A802D4.preface preserve=yes
//## end IF::SignalList%4CC9E6A802D4.preface

//## Class: SignalList%4CC9E6A802D4
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4CCAE06802CB;Trace { -> F}

class DllExport SignalList : public reusable::Object  //## Inherits: <unnamed>%4CCAE95501A7
{
  //## begin IF::SignalList%4CC9E6A802D4.initialDeclarations preserve=yes
  //## end IF::SignalList%4CC9E6A802D4.initialDeclarations

  public:
    //## Constructors (generated)
      SignalList();

    //## Destructor (generated)
      virtual ~SignalList();


    //## Other Operations (specified)
      //## Operation: enable%4CCADACA02FE
      void enable (Signal* pSignal, bool bEnable);

      //## Operation: getMutex%4CCB1A4D0202
      char* getMutex ();

      //## Operation: getSignal%4CCAEDCF00CA
      Signal* getSignal (int index);

      //## Operation: instance%4CCAE99200FC
      static SignalList* instance ();

      //## Operation: size%4CCAEB450395
      int size ();

    // Additional Public Declarations
      //## begin IF::SignalList%4CC9E6A802D4.public preserve=yes
      //## end IF::SignalList%4CC9E6A802D4.public

  protected:
    // Additional Protected Declarations
      //## begin IF::SignalList%4CC9E6A802D4.protected preserve=yes
      //## end IF::SignalList%4CC9E6A802D4.protected

  private:
    // Additional Private Declarations
      //## begin IF::SignalList%4CC9E6A802D4.private preserve=yes
      //## end IF::SignalList%4CC9E6A802D4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%4CCAE96C0021
      //## begin IF::SignalList::Instance%4CCAE96C0021.attr preserve=no  private: static SignalList* {U} 0
      static SignalList* m_pInstance;
      //## end IF::SignalList::Instance%4CCAE96C0021.attr

    // Data Members for Associations

      //## Association: Connex Library::IF_CAT::<unnamed>%4CCAD3D80359
      //## Role: SignalList::<m_hSignal>%4CCAD3D9024F
      //## begin IF::SignalList::<m_hSignal>%4CCAD3D9024F.role preserve=no  public: reusable::Signal {1 -> 0..nRFHgN}
      vector<reusable::Signal*> m_hSignal;
      //## end IF::SignalList::<m_hSignal>%4CCAD3D9024F.role

      //## Association: Connex Library::IF_CAT::<unnamed>%4CCADCB00330
      //## Role: SignalList::<m_pMutex>%4CCADCB10246
      //## begin IF::SignalList::<m_pMutex>%4CCADCB10246.role preserve=no  public: IF::Memory { -> RFHgN}
      Memory *m_pMutex;
      //## end IF::SignalList::<m_pMutex>%4CCADCB10246.role

    // Additional Implementation Declarations
      //## begin IF::SignalList%4CC9E6A802D4.implementation preserve=yes
        bool m_bWaitListChanged;
      //## end IF::SignalList%4CC9E6A802D4.implementation

};

//## begin IF::SignalList%4CC9E6A802D4.postscript preserve=yes
//## end IF::SignalList%4CC9E6A802D4.postscript

} // namespace IF

//## begin module%4CC9E6D10371.epilog preserve=yes
//## end module%4CC9E6D10371.epilog


#endif
