//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35ADFD6B0297.cm preserve=no
//	$Date:   Jul 19 2020 15:55:40  $ $Author:   e1009839  $
//	$Revision:   1.20  $
//## end module%35ADFD6B0297.cm

//## begin module%35ADFD6B0297.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%35ADFD6B0297.cp

//## Module: CXOSIF08%35ADFD6B0297; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF08.cpp

//## begin module%35ADFD6B0297.additionalIncludes preserve=no
//## end module%35ADFD6B0297.additionalIncludes

//## begin module%35ADFD6B0297.includes preserve=yes
#include <sstream>
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%35ADFD6B0297.includes

#ifndef CXOSRU24_h
#include "CXODRU24.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif


//## begin module%35ADFD6B0297.declarations preserve=no
//## end module%35ADFD6B0297.declarations

//## begin module%35ADFD6B0297.additionalDeclarations preserve=yes
#ifdef MVS
extern "OS"
{
int CXGTS(char* psDateTime,char* psStck,int* plRC);
int CXCSDT(char* psDate,char* psTime,const char* psTimestamp,int* plRC);
int CXCTTS(const char* psTimestamp,char* psDateTime,int* plRC);
int CXTADJ(char* psDate,char* psTime,int* plOffset,int* plRC);
}
#endif
//## end module%35ADFD6B0297.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::DateTime

//## begin IF::DateTime::Hundreths%3850283400CD.attr preserve=no  private: static short {U} 0
short DateTime::m_siHundreths = 0;
//## end IF::DateTime::Hundreths%3850283400CD.attr

//## begin IF::DateTime::PrevSC%385027BD02DF.attr preserve=no  private: static char[3] {U} {"  "}
char DateTime::m_sPrevSC[3] = {"  "};
//## end IF::DateTime::PrevSC%385027BD02DF.attr

DateTime::DateTime()
  //## begin DateTime::DateTime%345407FC0130_const.hasinit preserve=no
  //## end DateTime::DateTime%345407FC0130_const.hasinit
  //## begin DateTime::DateTime%345407FC0130_const.initialization preserve=yes
  //## end DateTime::DateTime%345407FC0130_const.initialization
{
  //## begin IF::DateTime::DateTime%345407FC0130_const.body preserve=yes
   memcpy(m_sID,"IF08",4);
   m_sYYYY[4] = '\0';
   m_sMM[2] = '\0';
   m_sDD[2] = '\0';
   m_sHR[2] = '\0';
   m_sMN[2] = '\0';
   m_sSC[2] = '\0';
   m_sHN[2] = '\0';
  //## end IF::DateTime::DateTime%345407FC0130_const.body
}


DateTime::~DateTime()
{
  //## begin IF::DateTime::~DateTime%345407FC0130_dest.body preserve=yes
  //## end IF::DateTime::~DateTime%345407FC0130_dest.body
}



//## Other Operations (implementation)
int DateTime::adjust (string& strDateTime, int iOffset)
{
  //## begin IF::DateTime::adjust%52B4A3A30119.body preserve=yes
   char sDateTime[17] = {"                "};
   memcpy(sDateTime,strDateTime.data() + 4,4);
   memcpy(sDateTime + 4,strDateTime.data(),4);
   memcpy(sDateTime + 8,strDateTime.data() + 8,8);
   int iRC = 0;
#ifdef MVS
   CXTADJ(sDateTime,sDateTime + 8,&iOffset,&iRC);
#else
   iRC = adjust(sDateTime,sDateTime + 8,iOffset);
#endif
   if (iRC == 0)
   {
      char sMMDD[4];
      memcpy(sMMDD,sDateTime,4);
      memcpy(sDateTime,sDateTime + 4,4);
      memcpy(sDateTime + 4,sMMDD,4);
      strDateTime.assign(sDateTime,16);
   }
   return iRC;
  //## end IF::DateTime::adjust%52B4A3A30119.body
}

int DateTime::adjust (char* psDate, char* psTime, int iOffset)
{
  //## begin IF::DateTime::adjust%5EDFEFF8006C.body preserve=yes
   char szTemp[9] = {"        "};
   tm tmDate;
   tm *tmTime = &tmDate;
   if (psDate[0] == 'J')
      memcpy(szTemp,psDate + 1,8);
   else
      memcpy(szTemp,psDate,8);
   tmTime->tm_year = atoi(szTemp + 4) - 1900;
   szTemp[4] = '\0';
   tmTime->tm_mday = atoi(szTemp + 2);
   szTemp[2] = '\0';
   tmTime->tm_mon = atoi(szTemp) - 1;
   memcpy(szTemp,psTime,6);
   szTemp[6] = '\0';
   tmTime->tm_sec = atoi(szTemp + 4);
   szTemp[4] = '\0';
   tmTime->tm_min = atoi(szTemp + 2);
   szTemp[2] = '\0';
   tmTime->tm_hour = atoi(szTemp);
   tmTime->tm_min += iOffset;
   tmTime->tm_isdst = -1;
   time_t htime_t = mktime(tmTime);
   struct tm htm;
#ifdef _WIN32
   localtime_s(&htm,&htime_t);
#else
   localtime_r(&htime_t,&htm);
#endif
   std::stringstream ss;
   ss << std::setfill('0') << std::setw(2) << htm.tm_mon + 1
      << std::setfill('0') << std::setw(2) << htm.tm_mday
      << std::setfill('0') << std::setw(4) << htm.tm_year + 1900
      << std::setfill('0') << std::setw(3) << htm.tm_yday + 1
      << std::setfill('0') << std::setw(2) << htm.tm_hour
      << std::setfill('0') << std::setw(2) << htm.tm_min
      << std::setfill('0') << std::setw(2) << htm.tm_sec;
   if (psDate[0] == 'J')
      memcpy((void*)(psDate + 1),ss.str().data(),11);
   else
      memcpy(psDate,ss.str().data(),8);
   memcpy(psTime,ss.str().data() + 11,6);
   return 0;
  //## end IF::DateTime::adjust%5EDFEFF8006C.body
}

void DateTime::calcCentury (const char* psDateYYMMDD, char* psCentury)
{
  //## begin IF::DateTime::calcCentury%38502064000A.body preserve=yes
   char sYY[3] = {"  "};
   if (!strncmp("000000",psDateYYMMDD,6))
      memcpy(psCentury,"00",2);
   else
   if (!strncmp("      ",psDateYYMMDD,6))
      memcpy(psCentury,"  ",2);
   else
   {
      memcpy(sYY,psDateYYMMDD,2);
      if (atoi(sYY) > 49)
         memcpy(psCentury,"19",2);
      else
         memcpy(psCentury,"20",2);
   }
  //## end IF::DateTime::calcCentury%38502064000A.body
}

int DateTime::calcMinsElapsed (DateTime& hDateTime)
{
  //## begin IF::DateTime::calcMinsElapsed%3947F51E006D.body preserve=yes
   int lThisYear = atoi(m_sYYYY);
   int lPrevYear = atoi(hDateTime.m_sYYYY);
   int lBaseYear;
   if (lThisYear <= lPrevYear)
      lBaseYear = lThisYear;
   else
      lBaseYear = lPrevYear;
   int iJulianDays[12][2];
   // non leapyear
   iJulianDays[11][0] = 334;
   iJulianDays[10][0] = 304;
   iJulianDays[9][0] = 273;
   iJulianDays[8][0] = 243;
   iJulianDays[7][0] = 212;
   iJulianDays[6][0] = 181;
   iJulianDays[5][0] = 151;
   iJulianDays[4][0] = 120;
   iJulianDays[3][0] = 90;
   iJulianDays[2][0] = 59;
   iJulianDays[1][0] = 31;
   iJulianDays[0][0] = 0;
   // leapyear
   iJulianDays[11][1] = 335;
   iJulianDays[10][1] = 305;
   iJulianDays[9][1] = 274;
   iJulianDays[8][1] = 244;
   iJulianDays[7][1] = 213;
   iJulianDays[6][1] = 182;
   iJulianDays[5][1] = 152;
   iJulianDays[4][1] = 121;
   iJulianDays[3][1] = 91;
   iJulianDays[2][1] = 60;
   iJulianDays[1][1] = 31;
   iJulianDays[0][1] = 0;
   // start with mins since start of month
   int lThisTotalMN = atoi(m_sMN) +
      ((atoi(m_sHR))*60) +
      ((atoi(m_sDD))*1440);

   // add no. of mins from start of year to start of month
   if (lThisYear % 4 == 0)
      lThisTotalMN += iJulianDays[(atoi(m_sMM)-1)][1]*1440;
   else
      lThisTotalMN += iJulianDays[(atoi(m_sMM)-1)][0]*1440;

   // add no. of mins from base year to start of year
   int lTemp = lBaseYear;
   while (lTemp != lThisYear)
   {
      if (lTemp % 4 == 0)
         lThisTotalMN += 366*1440;
      else
         lThisTotalMN += 365*1440;
      lTemp++;
   }
   // start with mins since start of month
   int lPrevTotalMN = atoi(hDateTime.m_sMN) +
         ((atoi(hDateTime.m_sHR))*60) +
         ((atoi(hDateTime.m_sDD))*1440);
   // add no. of mins from start of year to start of month
   if (lPrevYear % 4 == 0)
      lPrevTotalMN += iJulianDays[(atoi(hDateTime.m_sMM)-1)][1]*1440;
   else
      lPrevTotalMN += iJulianDays[(atoi(hDateTime.m_sMM)-1)][0]*1440;
   // add no. of mins from base year to start of year
   lTemp = lBaseYear;
   while (lTemp != lPrevYear)
   {
      if (lTemp % 4 == 0)
         lPrevTotalMN += 366*1440;
      else
         lPrevTotalMN += 365*1440;
      lTemp++;
   }
   if (lThisTotalMN >= lPrevTotalMN)
      return lThisTotalMN - lPrevTotalMN;
   return lPrevTotalMN - lThisTotalMN;
  //## end IF::DateTime::calcMinsElapsed%3947F51E006D.body
}

int DateTime::calcQueueTime (DateTime& hDateTime)
{
  //## begin IF::DateTime::calcQueueTime%385024DF0097.body preserve=yes
   int lThisTotalHN = (atoi(m_sHN)) + ((atoi(m_sSC)) * 100) +
      ((atoi(m_sMN)) * 6000) + ((atoi(m_sHR)) * 360000);
   int lPrevTotalHN = (atoi(hDateTime.m_sHN)) +
      ((atoi(hDateTime.m_sSC)) * 100) +
      ((atoi(hDateTime.m_sMN)) * 6000) +
      ((atoi(hDateTime.m_sHR)) * 360000);
   if (lThisTotalHN < lPrevTotalHN)
      return ((lThisTotalHN + 8640000) - lPrevTotalHN);
   return (lThisTotalHN - lPrevTotalHN);
  //## end IF::DateTime::calcQueueTime%385024DF0097.body
}

void DateTime::convertToTandem (IString& strYYYYMMDDHHMMSS, IString& strTimestamp)
{
  //## begin IF::DateTime::convertToTandem%385025570276.body preserve=yes
   double iYY = atof(strYYYYMMDDHHMMSS.subString(3,2));
   double iMM = atof(strYYYYMMDDHHMMSS.subString(5,2));
   double iDD = atof(strYYYYMMDDHHMMSS.subString(7,2));
   double iHH = atof(strYYYYMMDDHHMMSS.subString(9,2));
   double iMN = atof(strYYYYMMDDHHMMSS.subString(11,2));
   double iSS = atof(strYYYYMMDDHHMMSS.subString(13,2));
   double sCS = atof(strYYYYMMDDHHMMSS.subString(15,2));
   char* szDays;
   if (((int)iYY % 4) == 0)
      szDays = "000031060091121152182213244274305335";
   else
      szDays = "000031059090120151181212243273304334";
   char szTemp[4] = {"   "};
   memcpy(szTemp,szDays + (((int)iMM - 1) * 3),3);
   double iDDD = atof(szTemp) + iDD;
   if (iYY < 75)
      iYY += 100;
   int ix = (int)iYY - 73;
   int iy = ix / 4;
   double iLY = (double)iy;
   double iY = iYY - 75 - iLY;
   double dDCMSTAMP_00 = iY * 3153600000
      + iLY  * 3162240000
      + iDDD * 8640000
      + iHH  * 360000
      + iMN  * 6000
      + iSS  * 100
     + sCS;
   std:stringstream ss;
   ss << std::fixed << std::setfill('0') << std::setprecision(0) << std::setw(18) << dDCMSTAMP_00;
   reusable::IString strFoo(ss.str().c_str());
   reusable::IString strFoo2 = reusable::IString::d2x(strFoo);
   reusable::IString strFoo3;
   while (strFoo2.length() < 12)
      strFoo2.insert("0");
   char szClock[6];
   char x2[2] = {" "};
   unsigned int j = 0;
   for (unsigned int i = 1;i < strFoo2.length();i += 2)
   {
      x2[0] = strFoo2[(int)i];
#ifdef MVS
      if (x2[0] <= 'F')
         szClock[j] = x2[0] - 'A' + 10;
#else
      if (x2[0] >= 'A')
         szClock[j] = x2[0] - 'A' + 10;
#endif
      else
         szClock[j] = atoi(x2);
      szClock[j] = szClock[j] << 4;
      x2[0] = strFoo2[(int)(i + 1)];
#ifdef MVS
      if (x2[0] <= 'F')
         szClock[j] += x2[0] - 'A' + 10;
#else
      if (x2[0] >= 'A')
         szClock[j] += x2[0] - 'A' + 10;
#endif
      else
         szClock[j] += atoi(x2);
      ++j;
   }
   reusable::IString strTemp(szClock,6);
   strTimestamp = strTemp;
  //## end IF::DateTime::convertToTandem%385025570276.body
}

void DateTime::dateTime (IString& hDateTime)
{
  //## begin IF::DateTime::dateTime%385025960277.body preserve=yes
   char szTemp[17];
   memcpy(szTemp,m_sYYYY,4);
   memcpy(szTemp + 4,m_sMM,2);
   memcpy(szTemp + 6,m_sDD,2);
   memcpy(szTemp + 8,m_sHR,2);
   memcpy(szTemp + 10,m_sMN,2);
   memcpy(szTemp + 12,m_sSC,2);
   memcpy(szTemp + 14,m_sHN,2);
   szTemp[16] = '\0';
   hDateTime = szTemp;
  //## end IF::DateTime::dateTime%385025960277.body
}

void DateTime::format (reusable::string& strTstamp, const reusable::string& strFormat)
{
  //## begin IF::DateTime::format%5C8604F80186.body preserve=yes
   if (strTstamp.length() < 14)
      return;
   char szDateTime[15] = { "              " };
   memcpy(szDateTime,strTstamp.data(),14);
   struct tm htm;
   htm.tm_sec = atoi(szDateTime + 12);
   szDateTime[12] = '\0';
   htm.tm_min = atoi(szDateTime + 10);
   szDateTime[10] = '\0';
   htm.tm_hour = atoi(szDateTime + 8);
   szDateTime[8] = '\0';
   htm.tm_mday = atoi(szDateTime + 6);
   szDateTime[6] = '\0';
   htm.tm_mon = atoi(szDateTime + 4) - 1;
   szDateTime[4] = '\0';
   htm.tm_year = atoi(szDateTime) - 1900;
   htm.tm_wday = 0;
   htm.tm_yday = 0;
   htm.tm_isdst = -1;
   char szDate[64];
   time_t t;
   t = mktime(&htm);
#ifdef _WIN32
   localtime_s(&htm,&t);
#else
   localtime_r(&t,&htm);
#endif
   strftime(szDate,64,strFormat.c_str(),&htm);
   strTstamp.assign(szDate);
  //## end IF::DateTime::format%5C8604F80186.body
}

int DateTime::getDateTimeClock (char* psDateTime, char* psStck)
{
  //## begin IF::DateTime::getDateTimeClock%5EDFF8580386.body preserve=yes
   time_t htime_t;
   time(&htime_t);
   struct tm htm;
#ifdef _WIN32
   localtime_s(&htm,&htime_t);
#else
   localtime_r(&htime_t,&htm);
#endif
   std:stringstream ss;
   ss << std::setfill('0') << std::setw(4) << htm.tm_year + 1900
      << std::setfill('0') << std::setw(2) << htm.tm_mon + 1
      << std::setfill('0') << std::setw(2) << htm.tm_mday
      << std::setfill('0') << std::setw(2) << htm.tm_hour
      << std::setfill('0') << std::setw(2) << htm.tm_min
      << std::setfill('0') << std::setw(2) << htm.tm_sec
      << "00";
   memcpy(psDateTime,ss.str().data(),16);
   memset(psStck,'\0',8);
   clock_t* pClock = (clock_t*)(psStck + (8 - sizeof(clock_t)));
   *pClock += clock();
   return 0;
  //## end IF::DateTime::getDateTimeClock%5EDFF8580386.body
}

void DateTime::getIBMStck (IString& strStck)
{
  //## begin IF::DateTime::getIBMStck%385025E00273.body preserve=yes
   int lRC;
   char psDateTime[16];
   char psStck[8];
#ifdef MVS
   CXGTS(psDateTime,psStck,&lRC);
#else
   lRC = getDateTimeClock(psDateTime,psStck);
#endif
   strStck = psStck;
  //## end IF::DateTime::getIBMStck%385025E00273.body
}

void DateTime::setCurrent (IString& hDateTime)
{
  //## begin IF::DateTime::setCurrent%385025C90054.body preserve=yes
   int lRC;
   char psDateTime[16];
   char psStck[8];
#ifdef MVS
   CXGTS(psDateTime,psStck,&lRC);
#else
   lRC = getDateTimeClock(psDateTime,psStck);
#endif
   memcpy(m_sYYYY,psDateTime,4);
   memcpy(m_sMM,psDateTime + 4,2);
   memcpy(m_sDD,psDateTime + 6,2);
   memcpy(m_sHR,psDateTime + 8,2);
   memcpy(m_sMN,psDateTime + 10,2);
   memcpy(m_sSC,psDateTime + 12,2);
   memcpy(m_sHN,psDateTime + 14,2);
   char szTemp[17];
   memcpy(szTemp,m_sYYYY,4);
   memcpy(szTemp + 4,m_sMM,2);
   memcpy(szTemp + 6,m_sDD,2);
   memcpy(szTemp + 8,m_sHR,2);
   memcpy(szTemp + 10,m_sMN,2);
   memcpy(szTemp + 12,m_sSC,2);
   memcpy(szTemp + 14,m_sHN,2);
   szTemp[16] = '\0';
   hDateTime = szTemp;
  //## end IF::DateTime::setCurrent%385025C90054.body
}

void DateTime::setDateTime (const char* psDateTime)
{
  //## begin IF::DateTime::setDateTime%385025FD01CB.body preserve=yes
   memcpy(m_sYYYY,psDateTime,4);
   memcpy(m_sMM,psDateTime + 4,2);
   memcpy(m_sDD,psDateTime + 6,2);
   memcpy(m_sHR,psDateTime + 8,2);
   memcpy(m_sMN,psDateTime + 10,2);
   memcpy(m_sSC,psDateTime + 12,2);
   memcpy(m_sHN,psDateTime + 14,2);
  //## end IF::DateTime::setDateTime%385025FD01CB.body
}

void DateTime::setFromB24 (unsigned int lTimestamp1, unsigned int lTimestamp2, IString& hDateTime)
{
  //## begin IF::DateTime::setFromB24%393FBC0203D1.body preserve=yes
   int iSecsInDay = 86400;
   int iSecsInHour = 3600;
   int iSecsInMin = 60;
   int iGMTDiff = 0; // TIMEDIFF
#ifdef MVS
   union
   {
      unsigned int iTime[2];
      unsigned long long uldTimestamp;
   }uTimeBuf;
   unsigned long long dTimestamp = 0;
   uTimeBuf.iTime[0] = lTimestamp1; uTimeBuf.iTime[1] = lTimestamp2;
   dTimestamp =uTimeBuf.uldTimestamp;
#else
   unsigned long long dTimestamp = 0;
   dTimestamp = lTimestamp1;
   dTimestamp = dTimestamp * 4294967296;
   dTimestamp += lTimestamp2;
#endif
   if (dTimestamp == 0)
      return;
   dTimestamp = dTimestamp / 1000000;
   int lDays = (int)(dTimestamp / iSecsInDay);
   int lRemSecs = (int)(dTimestamp - (lDays * iSecsInDay));

   // Adjust for time difference
   lRemSecs = lRemSecs + (12*iSecsInHour - iGMTDiff*iSecsInHour);
   int iHours = lRemSecs / iSecsInHour;
   lRemSecs = lRemSecs - (iHours * iSecsInHour);
   while (iHours > 23)
   {
      iHours -= 24;
      lDays += 1;
   }
   int iMins = lRemSecs / iSecsInMin;
   lRemSecs = lRemSecs - (iMins * iSecsInMin);
   int iSecs = lRemSecs + 1;
   if (iSecs >= 60)
   {
      iSecs = 00;
      iMins++;
      if (iMins >= 60)
      {
         iMins = 00;
         iHours++;
      }
      if (iHours >= 24)
      {
         iHours = 00;
         lDays++;
      }
   }
   {
   std:stringstream ss;
   ss << std::setfill('0') << std::setw(2) << iHours
      << std::setfill('0') << std::setw(2) << iMins
      << std::setfill('0') << std::setw(2) << iSecs;
   memcpy(m_sHR,ss.str().data(),2);
   memcpy(m_sMN,ss.str().data() + 2,2);
   memcpy(m_sSC,ss.str().data() + 4,2);
   memcpy(m_sHN,"00",2);
   }
   lDays -= 2305810;
   lDays -= 3;
   int iYears = 1601;
   for (;;)
   {
      lDays -= 365;
      if (iYears % 400 == 0 || (iYears % 4 == 0 && iYears % 100 != 0))
         lDays -= 1;
      iYears += 1;
      if (iYears % 400 == 0 || (iYears % 4 == 0 && iYears % 100 != 0))
      {
         if (lDays <= 366)
            break;
      }
      else
      {
         if (lDays <= 365)
            break;
      }
   }
   int iJulianDays[12];
   if (iYears % 400 == 0 || (iYears % 4 == 0 && iYears % 100 != 0))
   {
      // leapyear
      iJulianDays[11] = 335;
      iJulianDays[10] = 305;
      iJulianDays[9] = 274;
      iJulianDays[8] = 244;
      iJulianDays[7] = 213;
      iJulianDays[6] = 182;
      iJulianDays[5] = 152;
      iJulianDays[4] = 121;
      iJulianDays[3] = 91;
      iJulianDays[2] = 60;
      iJulianDays[1] = 31;
      iJulianDays[0] = 0;
   }
      else
   {
      // non leapyear
      iJulianDays[11] = 334;
      iJulianDays[10] = 304;
      iJulianDays[9] = 273;
      iJulianDays[8] = 243;
      iJulianDays[7] = 212;
      iJulianDays[6] = 181;
      iJulianDays[5] = 151;
      iJulianDays[4] = 120;
      iJulianDays[3] = 90;
      iJulianDays[2] = 59;
      iJulianDays[1] = 31;
      iJulianDays[0] = 0;
   }
   int iMonths=12;
   while (iJulianDays[iMonths-1] >= lDays)
      iMonths--;
   lDays = lDays - iJulianDays[iMonths-1];
   std::stringstream ss;
   ss << std::setfill('0') << std::setw(4) << iYears
      << std::setfill('0') << std::setw(2) << iMonths
      << std::setfill('0') << std::setw(2) << lDays;
   memcpy(m_sYYYY,ss.str().data(),4);
   memcpy(m_sMM,ss.str().data() + 4,2);
   memcpy(m_sDD,ss.str().data() + 6,2);
   char szTemp[17];
   memcpy(szTemp,m_sYYYY,4);
   memcpy(szTemp + 4,m_sMM,2);
   memcpy(szTemp + 6,m_sDD,2);
   memcpy(szTemp + 8,m_sHR,2);
   memcpy(szTemp + 10,m_sMN,2);
   memcpy(szTemp + 12,m_sSC,2);
   memcpy(szTemp + 14,m_sHN,2);
   szTemp[16] = '\0';
   hDateTime = szTemp;
  //## end IF::DateTime::setFromB24%393FBC0203D1.body
}

void DateTime::setFromIBM (const char* psTimestamp, IString& hDateTime)
{
  //## begin IF::DateTime::setFromIBM%3850265E0212.body preserve=yes
#ifdef MVS
   char pszDate[12];
   pszDate[11] = '\0';
   char pszTime[9];
   pszTime[8] = '\0';
   int lRC;
   CXCSDT(pszDate,pszTime,psTimestamp,&lRC);
   memcpy(m_sYYYY,pszDate + 4,4);
   memcpy(m_sMM,pszDate,2);
   memcpy(m_sDD,pszDate + 2,2);
   memcpy(m_sHR,pszTime,2);
   memcpy(m_sMN,pszTime + 2,2);
   memcpy(m_sSC,pszTime + 4,2);
   memcpy(m_sHN,pszTime + 6,2);
#else
   unsigned int* piStck = (unsigned int*)psTimestamp;
#ifdef _WIN32
   unsigned __int64 llSTCK = ntohl(piStck[0]);
#else
   unsigned long llSTCK = ntohl(piStck[0]);
#endif
   llSTCK *= 4294967296;
   llSTCK += ntohl(piStck[1]);
   llSTCK -= 10857480192000000000;
   llSTCK /= 4096;
   int iMinutesSince1Jan1984 = llSTCK / 60000000;
   int iSecondsSince1Jan1984 = llSTCK % 60000000;
   int iSecond = iSecondsSince1Jan1984 / 1000000;
   iSecondsSince1Jan1984 = iSecondsSince1Jan1984 % 1000000;
   int iHundredths = iSecondsSince1Jan1984 / 10000;
   int iHoursSince1Jan1984 = iMinutesSince1Jan1984 / 60;
   int iMinute = iMinutesSince1Jan1984 % 60;
   int iHour = iHoursSince1Jan1984 % 24;
   int iDaysSince1Jan1984 = iHoursSince1Jan1984 / 24;
   int iYear = iDaysSince1Jan1984 * 100;
   int iDays = iYear % 36525;
   iYear = iYear / 36525;
   iYear = iYear + 1984;
   unsigned int lYears = iYear;
   int j = iDays / 100;
   unsigned int iDay = j + 1;
   unsigned int lJulianDays[12] = {0,31,0,31,30,31,30,31,31,30,31,30};
   lJulianDays[2] = (lYears % 4 == 0) ? lJulianDays[1] + 29 : lJulianDays[1] + 28;
   for (int k = 3;k < 12;k++)
      lJulianDays[k] = lJulianDays[k] + lJulianDays[k - 1];
   unsigned int iMonth = 12;
   while (lJulianDays[iMonth - 1] >= iDay)
      iMonth--;
   iDay = iDay - lJulianDays[iMonth - 1];
   std:stringstream ss;
   ss << std::setfill('0') << std::setw(4) << iYear
      << std::setfill('0') << std::setw(2) << iMonth
      << std::setfill('0') << std::setw(2) << iDay
      << std::setfill('0') << std::setw(2) << iHour
      << std::setfill('0') << std::setw(2) << iMinute
      << std::setfill('0') << std::setw(2) << iSecond
      << std::setfill('0') << std::setw(2) << iHundredths;
   memcpy(m_sYYYY,ss.str().data(),4);
   memcpy(m_sMM,ss.str().data() + 4,2);
   memcpy(m_sDD,ss.str().data() + 6,2);
   memcpy(m_sHR,ss.str().data() + 8,2);
   memcpy(m_sMN,ss.str().data() + 10,2);
   memcpy(m_sSC,ss.str().data() + 12,2);
   memcpy(m_sHN,ss.str().data() + 14,2);
#endif
   char szTemp[17];
   memcpy(szTemp,m_sYYYY,4);
   memcpy(szTemp + 4,m_sMM,2);
   memcpy(szTemp + 6,m_sDD,2);
   memcpy(szTemp + 8,m_sHR,2);
   memcpy(szTemp + 10,m_sMN,2);
   memcpy(szTemp + 12,m_sSC,2);
   memcpy(szTemp + 14,m_sHN,2);
   szTemp[16] = '\0';
   hDateTime = szTemp;
  //## end IF::DateTime::setFromIBM%3850265E0212.body
}

void DateTime::setFromTandem (const char* psTimestamp, IString& hDateTime)
{
  //## begin IF::DateTime::setFromTandem%38502618029C.body preserve=yes
   int lRC = 0;
   char pszTimeDate[24];
   pszTimeDate[23] = '\0';
#ifdef MVS
   CXCTTS(psTimestamp,pszTimeDate,&lRC);
#endif
   char sCentury[2];
   calcCentury(pszTimeDate + 12,sCentury);
   memcpy(m_sYYYY,sCentury,2);
   memcpy(m_sYYYY + 2,pszTimeDate + 12,2);
   memcpy(m_sMM,pszTimeDate + 14,2);
   memcpy(m_sDD,pszTimeDate + 16,2);
   memcpy(m_sHR,pszTimeDate,2);
   memcpy(m_sMN,pszTimeDate + 2,2);
   memcpy(m_sSC,pszTimeDate + 4,2);
#ifndef MVS
   m_siHundreths += 1;
   if (strcmp(m_sSC,m_sPrevSC))
      m_siHundreths = 0;
   std:stringstream ss;
   ss << std::setfill('0') << std::setw(2) << m_siHundreths;
   memcpy(m_sHN,ss.str().data(),2);
#else
   memcpy(m_sHN,pszTimeDate + 6,2);
#endif
   memcpy(m_sPrevSC,m_sSC,2);
   char szTemp[17];
   memcpy(szTemp,m_sYYYY,4);
   memcpy(szTemp + 4,m_sMM,2);
   memcpy(szTemp + 6,m_sDD,2);
   memcpy(szTemp + 8,m_sHR,2);
   memcpy(szTemp + 10,m_sMN,2);
   memcpy(szTemp + 12,m_sSC,2);
   memcpy(szTemp + 14,m_sHN,2);
   szTemp[16] = '\0';
   hDateTime = szTemp;
  //## end IF::DateTime::setFromTandem%38502618029C.body
}

int DateTime::timeAdjust (IString& strTstamp, int lOffset)
{
  //## begin IF::DateTime::timeAdjust%3850266F0130.body preserve=yes
   // strTstamp is expected to be in CCYYMMDDHHMMSSHN format
   char psTstamp[17];
   memcpy(psTstamp,strTstamp,16);
   psTstamp[16] = '\0';
   // reformat date into MMDDCCYY format
   memcpy(psTstamp,strTstamp.subString(5,4),4);
   memcpy(psTstamp + 4,strTstamp.subString(1,4),4);
   int lRC;
#ifdef MVS
   CXTADJ(psTstamp,psTstamp + 8,&lOffset,&lRC);
#else
   lRC = adjust(psTstamp,psTstamp + 8,lOffset);
#endif
   if (lRC == 0)
   {
      // extract date into CCYYMMDD
      char psTemp[8];
      memcpy(psTemp,psTstamp + 4,4);
      memcpy(psTemp + 4,psTstamp,4);
      // overlay date
      memcpy(psTstamp,psTemp,8);
      // fill-in the IString with the result
      strTstamp = psTstamp;
   }
   return lRC;
  //## end IF::DateTime::timeAdjust%3850266F0130.body
}

// Additional Declarations
  //## begin IF::DateTime%345407FC0130.declarations preserve=yes
  //## end IF::DateTime%345407FC0130.declarations

} // namespace IF

//## begin module%35ADFD6B0297.epilog preserve=yes
//## end module%35ADFD6B0297.epilog
