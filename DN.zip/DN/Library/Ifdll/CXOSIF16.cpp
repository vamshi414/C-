//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36266F4F005D.cm preserve=no
//## end module%36266F4F005D.cm

//## begin module%36266F4F005D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36266F4F005D.cp

//## Module: CXOSIF16%36266F4F005D; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF16.cpp

//## begin module%36266F4F005D.additionalIncludes preserve=no
//## end module%36266F4F005D.additionalIncludes

//## begin module%36266F4F005D.includes preserve=yes
#ifdef _WIN32
#include <direct.h>
#include <winsock2.h>
#endif
#include "CXODIF44.hpp"
#include "CXODIF45.hpp"
#include "CXODRU37.hpp"
//## end module%36266F4F005D.includes

#ifndef CXOSIF43_h
#include "CXODIF43.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSRU36_h
#include "CXODRU36.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif


//## begin module%36266F4F005D.declarations preserve=no
//## end module%36266F4F005D.declarations

//## begin module%36266F4F005D.additionalDeclarations preserve=yes
#ifdef _UNIX
#include <sys/stat.h>
#include <unistd.h>
#endif
//## end module%36266F4F005D.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Extract 

//## begin IF::Extract::Instance%3472FB800117.attr preserve=no  private: static IF::Extract* {U} 0
IF::Extract* Extract::m_pInstance = 0;
//## end IF::Extract::Instance%3472FB800117.attr

Extract::Extract()
  //## begin Extract::Extract%3472FB2202C0_const.hasinit preserve=no
      : m_strCustomerQualifier("CUSTQUAL"),
        m_siTargetCount(1)
  //## end Extract::Extract%3472FB2202C0_const.hasinit
  //## begin Extract::Extract%3472FB2202C0_const.initialization preserve=yes
  //## end Extract::Extract%3472FB2202C0_const.initialization
{
  //## begin IF::Extract::Extract%3472FB2202C0_const.body preserve=yes
   memcpy(m_sID,"IF16",4);
#ifndef MVS
   char szHost[257] = {"UNKNOWN"};
   gethostname(szHost,256);
   szHost[256] = '\0';
   m_strHost = szHost;
   transform(m_strHost.begin(),m_strHost.end(),m_strHost.begin(),::toupper);
#endif
  //## end IF::Extract::Extract%3472FB2202C0_const.body
}


Extract::~Extract()
{
  //## begin IF::Extract::~Extract%3472FB2202C0_dest.body preserve=yes
   m_hRecords.erase(m_hRecords.begin(),m_hRecords.end());
  //## end IF::Extract::~Extract%3472FB2202C0_dest.body
}



//## Other Operations (implementation)
void Extract::addRecord (const string& strRecord)
{
  //## begin IF::Extract::addRecord%48E692150166.body preserve=yes
   m_hRecords.push_back(strRecord);
  //## end IF::Extract::addRecord%48E692150166.body
}

bool Extract::find (const char* pszArgument, string& strRecord) const
{
  //## begin IF::Extract::find%461649CC0251.body preserve=yes
   std::vector<string>::const_iterator pString;
   for (pString = m_hRecords.begin();pString != m_hRecords.end();++pString)
   {
      if ((*pString).find(pszArgument) != string::npos)
      {
         strRecord = (*pString).c_str();
         return true;
      }
   }
   return false;
  //## end IF::Extract::find%461649CC0251.body
}

bool Extract::get (const char* pszKey, IString& strRecord) const
{
  //## begin IF::Extract::get%38511F2603D0.body preserve=yes
   size_t m = strlen(pszKey);
   std::vector<string>::const_iterator pString;
   for (pString = m_hRecords.begin();pString != m_hRecords.end();++pString)
   {
      if ((*pString).substr(0,m) == pszKey)
      {
         strRecord = (*pString).c_str();
         return true;
      }
   }
   return false;
  //## end IF::Extract::get%38511F2603D0.body
}

bool Extract::get (int lIndex, IString& strRecord) const
{
  //## begin IF::Extract::get%38511F950362.body preserve=yes
  if ((lIndex + 1) > m_hRecords.size())
      return false;
   strRecord = m_hRecords[lIndex].c_str();
   return true;
  //## end IF::Extract::get%38511F950362.body
}

bool Extract::getAddressSpace (const string& strName, string& strAddressSpace)
{
  //## begin IF::Extract::getAddressSpace%3F2FD22A005D.body preserve=yes
   map<string,string,less <string> >::iterator p;
   p = m_hAddressSpace.find(strName);
   if (p == m_hAddressSpace.end())
      return false;
   strAddressSpace = (*p).second;
   return true;
  //## end IF::Extract::getAddressSpace%3F2FD22A005D.body
}

void Extract::getCustomer (set<string> &hCustomer)
{
  //## begin IF::Extract::getCustomer%46414DDE0382.body preserve=yes
   hCustomer = m_hCustomers;
  //## end IF::Extract::getCustomer%46414DDE0382.body
}

bool Extract::getHost (const string& strAddressSpace, string& strHost)
{
  //## begin IF::Extract::getHost%3E7226BD00BB.body preserve=yes
   map<string,string,less <string> >::iterator p;
   p = m_hHost.find(strAddressSpace);
   if (p == m_hHost.end())
      return false;
   strHost = (*p).second;
   return true;
  //## end IF::Extract::getHost%3E7226BD00BB.body
}

bool Extract::getLong (const char* pszKey, const char* pszSearchValue, int* plValue)
{
  //## begin IF::Extract::getLong%38511FE70139.body preserve=yes
   string strRecord;
   size_t m = strlen(pszKey);
   vector<string>::const_iterator pString;
   for (pString = m_hRecords.begin();pString != m_hRecords.end();++pString)
   {
      if (pString->substr(0,m) == pszKey)
      {
         strRecord = *pString;
         size_t pos = strRecord.find(pszSearchValue);
         if (pos != string::npos)
         {
            strRecord = strRecord.substr(pos + strlen(pszSearchValue));
            size_t n = strRecord.find_first_not_of("0123456789");
            if (n > 9)
               *plValue = atoi(strRecord.substr(0,9).c_str());
            else
               *plValue = atoi(strRecord.substr(0,n).c_str());
            return true;
         }
      }
   }
   return false;
  //## end IF::Extract::getLong%38511FE70139.body
}

bool Extract::getQueue (const char* pszName, string& strHost, unsigned short* piPort)
{
  //## begin IF::Extract::getQueue%3E720781005D.body preserve=yes
   string strPort(pszName);
   size_t pos = strPort.find_first_of(' ');
   if (pos != string::npos)
      strPort.erase(pos);
   Trace::put("Extract::getQueue()");
   Trace::put(strPort.data(),strPort.length());
   string strName;
   string strValue;
   if (IF::Extract::instance()->getSpec(pszName,strValue))
   {
      vector<string> hTokens;
      if (Buffer::parse(strValue,"~",hTokens) >= 2)
      {
         strHost = hTokens[0];
         *piPort = atoi(hTokens[1].c_str());
         return true;
      }
   }
#ifndef MVS
   for (;;)
   {
      map<string,string,less <string> >::iterator p;
      // p = m_hPort.find(strPort); !!! this find only works the first time through in .NET C++ ... bug ???
      for (p = m_hPort.begin();p != m_hPort.end();++p)
      {
         if (strcmp((*p).first.c_str(),strPort.c_str()) == 0)
            break;
      }
      if (p == m_hPort.end())
         break;
      strName.assign(strPort.data(),strPort.length());
      strPort.assign((*p).second.data(),(*p).second.length());
      Trace::put(strName.data(),strName.length());
      Trace::put(strPort.data(),strPort.length());
   }
   if (strName.length() == 0)
   {
      string strBuffer("Missing port for: ");
      strBuffer += pszName;
      Trace::put(strBuffer.data(),strBuffer.length());
      return false;
   }
   *piPort = atoi(strPort.c_str());
   if (strName == "FM")
      return true;
   map<string,string,less <string> >::iterator p2;
   // p2 = m_hAddressSpace.find(strName); !!!
   for (p2 = m_hAddressSpace.begin();p2 != m_hAddressSpace.end();++p2)
   {
      if (strcmp((*p2).first.c_str(),strName.c_str()) == 0)
         break;
   }
   if (p2 == m_hAddressSpace.end())
   {
      string strBuffer("Missing address space for: ");
      strBuffer += strName;
      Trace::put(strBuffer.data(),strBuffer.length());
      return false;
   }
   if (!getHost((*p2).second,strHost))
   {
      string strBuffer("Missing host for: ");
      strBuffer += (*p2).second;
      Trace::put(strBuffer.data(),strBuffer.length());
      return false;
   }
#endif
   return true;
  //## end IF::Extract::getQueue%3E720781005D.body
}

bool Extract::getRecord (const char* pszKey, string& strRecord) const
{
  //## begin IF::Extract::getRecord%3E70AAC00251.body preserve=yes
   size_t m = strlen(pszKey);
   std::vector<string>::const_iterator pString;
   for (pString = m_hRecords.begin();pString != m_hRecords.end();++pString)
   {
      if ((*pString).substr(0,m) == pszKey)
      {
         strRecord = *pString;
         return true;
      }
   }
   return false;
  //## end IF::Extract::getRecord%3E70AAC00251.body
}

bool Extract::getRecord (int lIndex, string& strRecord) const
{
  //## begin IF::Extract::getRecord%3E70AAC30128.body preserve=yes
   if ((lIndex + 1) > m_hRecords.size())
      return false;
   strRecord = m_hRecords[lIndex];
   return true;
  //## end IF::Extract::getRecord%3E70AAC30128.body
}

bool Extract::getSpec (const char* pszKey, string& strValue, const char* pszCUST_ID) const
{
  //## begin IF::Extract::getSpec%385120260085.body preserve=yes
   char szKey[9] = {"        "};
   size_t m = strlen(pszKey);
   if (m > 8)
      m = 8;
   memcpy(szKey,pszKey,m);
   vector<string>::const_reverse_iterator pString;
   string strCustomer;
   for (pString = m_hRecords.rbegin();pString != m_hRecords.rend();++pString)
   {
      if ((*pString).length() == 11
         && (*pString).substr(0,3) == ">> "
         && (*pString).substr(7,4) == "SPEC")
         strCustomer = (*pString).substr(3,4) == "SITE" ? "" : (*pString).substr(3,4);
      if (pszCUST_ID
         && strCustomer.empty() == false
         && strCustomer != pszCUST_ID)
         continue;
      if ((*pString).substr(0,8) == "DSPEC   "
         && (*pString).substr(8,8) == szKey)
      {
         strValue = (*pString).substr(16,min(size_t(230),(*pString).length() - 16));
         size_t pos = strValue.find_first_not_of(' ');
         if (pos > 0)
            strValue.erase(0,pos);
         pos = strValue.find_last_not_of(' ');
         if (pos == string::npos)
            strValue.erase();
         else
            strValue.erase(pos + 1);
         return true;
      }
   }
   return false;
  //## end IF::Extract::getSpec%385120260085.body
}

void Extract::getSpec (vector<string>& hExtractValues, const string&  strParam, string& strValue)
{
  //## begin IF::Extract::getSpec%5ED891DD001C.body preserve=yes
   strValue = "";
   vector<string>::iterator p;
   for (p = hExtractValues.begin();p != hExtractValues.end();++p)
   {
      if ((*p).length() >= strParam.length()
         && (*p).substr(0, strParam.length()) == strParam)
      {
         // front of string matches
         if ((*p).length() == strParam.length())
            return;   // param is just keyword, no ~ or value
         else if ((*p).substr(strParam.length(), 1) == "~")
            if ((*p).length() == (strParam.length() + 1))
               return;   // param is just keyword with ~ and no value
            else
            {
               strValue = (*p).substr(strParam.length() + 1, (*p).length() - strParam.length() - 1);  // param match with value after tilde
               strValue.erase(std::find(strValue.begin(), strValue.end(), '\0'), strValue.end());   // Extract module returns strings with nulls so need to do this
               return;
            }
      }
   }
  //## end IF::Extract::getSpec%5ED891DD001C.body
}

void Extract::getSpec (const char* pszKey, vector<string>& hValue) const
{
  //## begin IF::Extract::getSpec%5C40DA4F001D.body preserve=yes
   char szKey[17] = {"DSPEC           "};
   memcpy(szKey + 8,pszKey,min(size_t(8),strlen(pszKey)));
   vector<string>::const_iterator p;
   for (p = m_hRecords.begin();p != m_hRecords.end();++p)
      if ((*p).length() > 16
         && memcmp((*p).data(),szKey,16) == 0)
      {
         string strTemp((*p).data() + 16,min(size_t(230),(*p).length() - 16));
         trim(strTemp);
         hValue.push_back(strTemp);
      }
  //## end IF::Extract::getSpec%5C40DA4F001D.body
}

bool Extract::getSpec (const char *pszModuleID, const string &pszKey, string &strValue)
{
  //## begin IF::Extract::getSpec%5ED892A4009A.body preserve=yes
   vector<string> hExtractValues;
   getSpec(pszModuleID, hExtractValues);
   getSpec(hExtractValues, pszKey, strValue);
   return !strValue.empty();
  //## end IF::Extract::getSpec%5ED892A4009A.body
}

bool Extract::getString (const char* pszKey, const char* pszSearchValue, string& strValue, int iLength)
{
  //## begin IF::Extract::getString%3851205D01DA.body preserve=yes
   string strRecord;
   size_t pos = string::npos;
   if (getRecord(pszKey,strRecord)
      && (pos = strRecord.find(pszSearchValue)) != string::npos)
   {
      strValue = strRecord.substr(pos + strlen(pszSearchValue));
      if (strValue.length() > iLength)
         strValue.resize(iLength);
      pos = strValue.find_first_of(" ,!");
      if (pos != string::npos)
         strValue.erase(pos);
      return true;
   }
   return false;
  //## end IF::Extract::getString%3851205D01DA.body
}

int Extract::getTimer (const char* pszTimer)
{
  //## begin IF::Extract::getTimer%3851209100A8.body preserve=yes
   string strBuffer;
   if (getRecord("DMISC   ",strBuffer))
   {
      segDMISC* pMsg = (segDMISC*)strBuffer.data();
      size_t i = strlen(pszTimer);
      char* p = 0;
#ifdef MVS
      if (memcmp(pMsg->sTMENAME1,pszTimer,i) == 0)
         return pMsg->lTMESEC1;
      else
      if (memcmp(pMsg->sTMENAME2,pszTimer,i) == 0)
         return pMsg->lTMESEC2;
      else
      if (memcmp(pMsg->sTMENAME3,pszTimer,i) == 0)
         return pMsg->lTMESEC3;
#else
      if (memcmp(pMsg->sTMENAME1,pszTimer,i) == 0)
         p = pMsg->sTMESEC1;
      else
      if (memcmp(pMsg->sTMENAME2,pszTimer,i) == 0)
         p = pMsg->sTMESEC2;
      else
      if (memcmp(pMsg->sTMENAME3,pszTimer,i) == 0)
         p = pMsg->sTMESEC3;
#endif
      if (p)
      {
         char szTMESEC[7];
         memcpy(szTMESEC,p,6);
         szTMESEC[6] = '\0';
         int m = atoi(szTMESEC + 4);
         szTMESEC[4] = '\0';
         m += atoi(szTMESEC + 2) * 60;
         szTMESEC[2] = '\0';
         m += atoi(szTMESEC) * 3600;
         return m;
      }
   }
   return -1;
  //## end IF::Extract::getTimer%3851209100A8.body
}

string Extract::getVersion ()
{
  //## begin IF::Extract::getVersion%491371EA033C.body preserve=yes
   return string(
#include "CXODRU00.hpp"
   );
  //## end IF::Extract::getVersion%491371EA033C.body
}

Extract* Extract::instance ()
{
  //## begin IF::Extract::instance%38503B0E01B5.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new Extract();
   return m_pInstance;
  //## end IF::Extract::instance%38503B0E01B5.body
}

bool Extract::read (const char* pszName, const char* pszMember)
{
  //## begin IF::Extract::read%3E70DD580222.body preserve=yes
   string strAddressSpace;
   string strPort;
   FlatFile hExtract(pszName,pszMember);
   char* psBuffer = new char[257];
   memset(psBuffer,' ',257);
   int n = 0;
   if (!strcmp(pszMember,"CUSTSPEC"))
   {
      memcpy(psBuffer,"DSPEC",5);
      n = 8;
   }
   size_t m = 0;
   while (hExtract.read(psBuffer + n,256 - n,&m))
   {
      if (memcmp(psBuffer, "DSPEC   ", 8) == 0)
      {
         char* p = strchr(psBuffer, 0xFF);
         if (p)
            *p = ' ';
      }
      if (m_hCustomers.empty()
         && memcmp(psBuffer,"DSPEC   CUSTOMER",16) == 0)
      {
         string strValue(psBuffer + 16,4);
         m_hCustomers.insert(strValue);
      }
      if (strlen(psBuffer) < 24
         && ((memcmp(psBuffer,"DQUEUE  ",8) == 0)
         || (memcmp(psBuffer,"DFILES  ",8) == 0)))
         m = 24;
      if (memcmp(psBuffer,"DFILES  ",8) == 0)
      {
         char* p;
#ifdef _WIN32
         while (p = strchr(psBuffer,'/'))
            *p = '\\';
#else
         while (p = strchr(psBuffer,'\\'))
            *p = '/';
#endif
      }
      m_hRecords.push_back(string(psBuffer,m + n));
      if (m + n <= 256)
         psBuffer[m + n] = '\0';
#ifndef MVS
      if (memcmp(psBuffer,"DQUEUE  ",8) == 0)
      {
         string strFirst(psBuffer + 8,8);
         string strSecond(psBuffer + 16,8);
         size_t pos = strFirst.find_first_of(' ');
         if (pos != string::npos)
            strFirst.erase(pos);
         pos = strSecond.find_first_of(' ');
         if (pos != string::npos)
            strSecond.erase(pos);
         m_hPort[strFirst] = strSecond;
         string strType(psBuffer + 32);
         strType.resize(4,' ');
         if (strType == "FM  ")
         {
            if(m_strTaskType.empty())
               m_strTaskType = "FM";
            m_hPort["FM"] = strSecond;
            strPort = strSecond;
            strAddressSpace.assign(psBuffer + 8,8);
            pos = strAddressSpace.find_first_of(' ');
            if (pos != string::npos)
               strAddressSpace.erase(pos);
            map<string,string,less <string> >::iterator p;
            p = m_hHost.find(strAddressSpace);
            if (p != m_hHost.end())
               m_hAddressSpace.insert(map<string,string,less <string> >::value_type(strFirst,strAddressSpace));
            for (p = m_hPort.begin();p != m_hPort.end();++p)
               if ((*p).second == "&FM")
                  (*p).second = strPort;
         }
         else
         if (strAddressSpace.length())
            m_hAddressSpace.insert(map<string,string,less <string> >::value_type(strFirst,strAddressSpace));
         rtrim(strType);
         if(memcmp(m_strName.data(),strFirst.data(),strFirst.length()) == 0)
            m_strTaskType = strType;
      }
      else
      if (memcmp(psBuffer,"DHOST   ",8) == 0)
      {
         string strFirst(psBuffer + 8,8);
         string strSecond(psBuffer + 16);
         size_t pos = strFirst.find_first_of(' ');
         if (pos != string::npos)
            strFirst.erase(pos);
         pos = strSecond.find_first_of(' ');
         if (pos != string::npos)
            strSecond.erase(pos);
         transform(strSecond.begin(),strSecond.end(),strSecond.begin(),::toupper);
         m_hHost.insert(map<string, string, less <string> >::value_type(strFirst, strSecond));
         m_hHost.insert(map<string, string, less <string> >::value_type(strSecond, strSecond));
         m_hAddressSpace.insert(map<string, string, less <string> >::value_type(strSecond, strSecond));
         m_hPort.insert(map<string, string, less <string> >::value_type(strSecond, "&FM"));
      }
#endif
      if (memcmp(psBuffer,"DSPEC   ",8) == 0)
      {
         string strKey(psBuffer + 8,8);
         size_t pos = strKey.find_last_not_of(' ');
         if (pos == string::npos)
            strKey.erase();
         else
            strKey.erase(pos + 1);

         string strValue(psBuffer+16);
#ifdef MVS
         strValue.resize(64,' ');
#endif
         pos = strValue.find_first_not_of(' ');
         if (pos > 0)
            strValue.erase(0,pos);
         pos = strValue.find_last_not_of(' ');
         if (pos == string::npos)
            strValue.erase();
         else
            strValue.erase(pos + 1);
         if (memcmp(pszMember, m_strImage.data(), 3) == 0 )
         {
            map<string, string, less <string> >::iterator pIterator;
            string strFirst = "@" + strKey;
            pIterator = m_hHost.find(strFirst);
            if (pIterator != m_hHost.end())
            {
               transform(strValue.begin(), strValue.end(), strValue.begin(), ::toupper);
               m_hHost.erase(pIterator);
               m_hHost.insert(map<string, string, less <string> >::value_type(strValue, strValue));
               for (pIterator = m_hHost.begin(); pIterator != m_hHost.end(); pIterator++)
               {
                  if ((*pIterator).second == strFirst)
                     (*pIterator).second = strValue;
               }
               pIterator = m_hAddressSpace.find(strFirst);
               if (pIterator != m_hAddressSpace.end())
               {
                  m_hAddressSpace.erase(pIterator);
                  m_hAddressSpace.insert(map<string, string, less <string> >::value_type(strValue, strValue));
               }
               pIterator = m_hPort.find(strFirst);
               if (pIterator != m_hPort.end())
               {
                  string strsecond = (*pIterator).second;
                  m_hPort.erase(pIterator);
                  m_hPort.insert(map<string, string, less <string> >::value_type(strValue, strsecond));
               }
            }
         }
         SiteSpecification::instance()->add(strKey,strValue);
      }
      memset(psBuffer + n,' ',256 - n);
   }
   delete [] psBuffer;
   return true;
  //## end IF::Extract::read%3E70DD580222.body
}

void Extract::refresh (bool bNotify)
{
  //## begin IF::Extract::refresh%385120CE0153.body preserve=yes
   m_hRecords.erase(m_hRecords.begin(),m_hRecords.end());
   m_hHost.erase(m_hHost.begin(), m_hHost.end());
   m_hAddressSpace.erase(m_hAddressSpace.begin(), m_hAddressSpace.end());
   m_hPort.erase(m_hPort.begin(), m_hPort.end());
#ifdef CS
   read("EDB     ",0);
#else
   m_hCustomers.erase(m_hCustomers.begin(),m_hCustomers.end());
   size_t m = 0;
#ifdef MVS
   {
      FlatFile hExtract("EDB     ",0);
      char* psBuffer = new char[256];
      while (hExtract.read(psBuffer,256,&m))
      {
         if (memcmp(psBuffer,"DSPEC   CUSTOMER",16) == 0)
         {
            string strValue(psBuffer + 16,4);
            m_hCustomers.insert(strValue);
         }
      }
      delete [] psBuffer;
   }
   m_hRecords.push_back(string(">> SITESPEC"));
   read("EDB     ","SITESPC");
   m_hRecords.push_back(string(">> SITESPEC"));
   string strCustomer;
   string strBreak(">> ");
   set<string,less<string> >::iterator pCustomer;
   for (pCustomer = m_hCustomers.begin();pCustomer != m_hCustomers.end();pCustomer++)
   {
      strCustomer = (*pCustomer) + "SPC";
      strBreak.erase(3);
      strBreak += strCustomer;
      m_hRecords.push_back(strBreak);
      read("EDB     ",strCustomer.c_str());
      m_hRecords.push_back(strBreak);
   }
   strBreak.erase(3);
   strBreak += m_strName;
   m_hRecords.push_back(strBreak);
   read("EDB     ",0);
   m_hRecords.push_back(strBreak);
   if (m_strName.length() >= 4
      && m_strName.substr(2,2) == "TE")
   {
      m_hRecords.push_back(string(">> FM"));
      read("EDB     ","PM"); // to detect presence of CXOPAF00
      m_hRecords.push_back(string(">> FM"));
   }
#else
   m_hRecords.push_back(string(">> HOST"));
   read("EDB     ","HOST");
   m_hRecords.push_back(string(">> HOST"));
   FlatFile hExtract("EDB     ",m_strName.c_str());
   char* psBuffer = new char[256];
   while (hExtract.read(psBuffer,256,&m))
   {
      if (memcmp(psBuffer,"DSPEC   CUSTOMER",16) == 0)
      {
         string strValue(psBuffer + 16,4);
         m_hCustomers.insert(strValue);
      }
   }
   delete [] psBuffer;
   m_hRecords.push_back(string(">> SITESPEC"));
   read("EDB     ","SITESPEC");
   m_hRecords.push_back(string(">> SITESPEC"));
   string strCustomer;
   string strBreak(">> ");
   set<string,less<string> >::iterator pCustomer;
   for (pCustomer = m_hCustomers.begin();pCustomer != m_hCustomers.end();pCustomer++)
   {
      strCustomer = (*pCustomer) + "SPEC";
      strBreak.erase(3);
      strBreak += strCustomer;
      m_hRecords.push_back(strBreak);
      read("EDB     ",strCustomer.c_str());
      m_hRecords.push_back(strBreak);
   }
   strBreak.erase(3);
   strBreak += m_strName;
   m_hRecords.push_back(strBreak);
   read("EDB     ",m_strName.c_str());
   m_hRecords.push_back(strBreak);
   if (m_strName != "FM     ")
   {
      m_hRecords.push_back(string(">> FM"));
      read("EDB     ","FM");
      m_hRecords.push_back(string(">> FM"));
   }
   strBreak.erase(3);
   string strImage(m_strImage);
   size_t pos = strImage.find_first_of('/');
   if (pos != string::npos)
      strImage.erase(pos, 1);
   strImage.append("SPEC");
   strBreak += strImage ;
   m_hRecords.push_back(strBreak);
   read("EDB     ", strImage.c_str());
   m_hRecords.push_back(strBreak);

   FlatFile hScript("SOURCE", "STARTUP");
   if (hScript.open())
   {
      char* psBuffer = new char[4096];
      size_t m = 0;
      int iCount = 0;
      while (hScript.read(psBuffer, 4094, &m))
      {
         string strType;
         string strTask;
         if (memcmp(psBuffer, "TARGET", 6) == 0)
         {
            string strBuffer(psBuffer, m);
            vector<string> hTokens;
            Buffer::parse(strBuffer, " =", hTokens);
            if (hTokens.size() >= 3)
            {
               if (hTokens[1] == "ALL")
                  m_siTargetCount = atoi(hTokens[2].c_str());
               else if (hTokens[1] == "TYPE")
               {
                  iCount = atoi(hTokens[3].c_str());
                  strType = hTokens[2];
               }
               else
               {
                  iCount = atoi(hTokens[2].c_str());
                  strTask = hTokens[1];
               }
               strTask.resize(7, ' ');
               if (strTask == m_strName)
               {
                  m_siTargetCount = iCount;
                  break;
               }
               else if (strType == m_strTaskType)
               {
                  m_siTargetCount = iCount;
                  break;
               }
            }
         }
         else
            break;
      }
      delete[] psBuffer;
   }
   map<string,string,less <string> >::iterator p;
   string strBuffer;
   for (p = m_hHost.begin();p != m_hHost.end();++p)
   {
      strBuffer = "Host: ";
      strBuffer += (*p).first;
      strBuffer += " - ";
      strBuffer += (*p).second;
      Trace::put(strBuffer.data(),strBuffer.length());
   }
   for (p = m_hAddressSpace.begin();p != m_hAddressSpace.end();++p)
   {
      strBuffer = "Address space: ";
      strBuffer += (*p).first;
      strBuffer += " - ";
      strBuffer += (*p).second;
      Trace::put(strBuffer.data(),strBuffer.length());
   }
   for (p = m_hPort.begin();p != m_hPort.end();++p)
   {
      strBuffer = "Port: ";
      strBuffer += (*p).first;
      strBuffer += " - ";
      strBuffer += (*p).second;
      Trace::put(strBuffer.data(),strBuffer.length());
   }
#endif
   getSpec("CUSTQUAL",m_strCustomerQualifier);
   getSpec("QUALIFY",m_strQualify);
   getSpec("CUSTOM",m_strCustomCode[0]);
   if (m_strCustomCode[0] == "PYPL" || m_strCustomCode[0] == "INTT" || m_strCustomCode[0] == "EPI" || m_strCustomCode[0] == "CVRN")
   {
      m_strCustomCode[1] = m_strCustomCode[0];
      m_strCustomCode[0] = "MPS";
   }
   getSpec("DBVENDOR",m_strDatabaseVendor);
   getSpec("PERF", m_strPerf);
   Hint::instance()->reset();
   m = 0;
   string strRecord;
   vector<string> hTokens;
   while (getRecord(m++,strRecord))
   {
      if (strRecord.length() > 16)
      {
         if (strRecord.substr(0,16) == "DSPEC   HINTUSE ")
         {
            string strUseCase(strRecord.substr(16));
            size_t pos = strUseCase.find(' ');
            if (pos != string::npos)
               strUseCase.erase(pos);
            Hint::instance()->addUseCase(strUseCase);
         }
         if (strRecord.substr(0,16) == "DSPEC   HINTIDX ")
         {
            if (Buffer::parse(strRecord.substr(16)," ",hTokens) >= 3)
               Hint::instance()->addIndex(hTokens[0],hTokens[1],hTokens[2]);
         }
      }
   }
#endif
   vector<string> hValue;
   if (m_strDatabaseVendor == "ORACLE")
   {
      string strProgram;
      string strKey("DQUEUE  ");
      strKey += m_strName;
      if (Extract::instance()->getRecord(strKey.c_str(), strProgram))
      {
         strProgram.erase(0, 24);
         strProgram.erase(8);
         rtrim(strProgram);
      }
      vector<string> hValueQuery;
      vector<string> hValueTable;
      FlatFile hFlatfile("SOURCE", "CXOXIF16");
      char szSpec[17] = { "DSPEC           " };
      char* szKey[] = { "RU11", "RU06" };
      char sBuffer[256];
      size_t iRecordLength = 0;
      vector<string> hProgram;
      while (hFlatfile.read(sBuffer, 256, &iRecordLength))
      {
         if (iRecordLength > 5 && memcmp(sBuffer, "TYPE=", 5) == 0)
         {
            hProgram.clear();
            Buffer::parse(sBuffer, "= ", hProgram);
         }
         if (iRecordLength > 16 
            && hProgram.size() > 1
            && (std::find(hProgram.begin(), hProgram.end(),strProgram) != hProgram.end() || hProgram[1] == "ALL"))
         {
            for (int i = 0; i < 2; i++)
            {
               memcpy(szSpec + 8, szKey[i], 4);
               if (memcmp(sBuffer, szSpec, 16) == 0)
               {
                  string strTemp(sBuffer + 16, min(size_t(64), iRecordLength - 16));
                  trim(strTemp);
                  if (i == 0)
                     hValueQuery.push_back(strTemp);
                  else
                     hValueTable.push_back(strTemp);
               }
            }
         }
      }
      getSpec("RU11", hValue);
      hValue.insert(hValue.end(), hValueQuery.begin(), hValueQuery.end());
      reusable::Query::setSpec(hValue);
      hValue.clear();
      getSpec("RU06",hValue);
      hValue.insert(hValue.end(), hValueTable.begin(), hValueTable.end());
      reusable::Table::setSpec(hValue);
   }
   hValue.clear();
   getSpec("RU07",hValue);
   reusable::Column::setSpec(hValue);
   hValue.clear();
   getSpec("RU37", hValue);
   reusable::Mask::setSpec(hValue);
   // notify observers if refresh part
   if (bNotify)
      notify();
  //## end IF::Extract::refresh%385120CE0153.body
}

void Extract::setName (const string& strName)
{
  //## begin IF::Extract::setName%3D52AC280213.body preserve=yes
   m_strName = strName;
   Trace::put(getVersion().c_str());
   refresh(false);
  //## end IF::Extract::setName%3D52AC280213.body
}

bool Extract::setRecord (const char* pszKey, const string& strRecord)
{
  //## begin IF::Extract::setRecord%5395DC14006C.body preserve=yes
   size_t m = strlen(pszKey);
   std::vector<string>::iterator pString;
   for (pString = m_hRecords.begin();pString != m_hRecords.end();++pString)
   {
      if ((*pString).substr(0,m) == pszKey)
      {
         (*pString) = strRecord;
         return true;
      }
   }
   return false;
  //## end IF::Extract::setRecord%5395DC14006C.body
}

bool Extract::setup ()
{
  //## begin IF::Extract::setup%3E6F64DF0232.body preserve=yes
#ifndef MVS
   char sBuffer[_MAX_PATH] = {"_getcwd error"};
#ifdef _WIN32
   _getcwd(sBuffer,_MAX_PATH);
#else
   getcwd(sBuffer,_MAX_PATH);
   Trace::put("getcwd");
   Trace::put(sBuffer);
#endif
   Trace::put(sBuffer);
#ifdef _WIN32
   m_hRecords.push_back(string("DFILES  SITESPECSetup\\SITESPEC.txt"));
   m_hRecords.push_back(string("DFILES  CUSTSPECSetup\\CUSTSPEC.txt"));
#else
   m_hRecords.push_back(string("DFILES  SITESPECSetup/SITESPEC.txt"));
   m_hRecords.push_back(string("DFILES  CUSTSPECSetup/CUSTSPEC.txt"));
#endif
   IF::FlatFile hFlatFile("SITESPEC");
   memcpy(sBuffer,"DSPEC   ",8);
   size_t m = 0;
   while (hFlatFile.read(sBuffer + 8,248,&m))
   {
      if (sBuffer[8] != '*')
      {
         // made all HOST names upper case
         if (memcmp(sBuffer + 8,"PROC",4) == 0)
         {
            for (unsigned int i = 15;i < strlen(sBuffer);++i)
               sBuffer[i] = toupper(sBuffer[i]);
         }
         m_hRecords.push_back(string(sBuffer,m + 8));
         for (unsigned int i = 8;i < 16;++i)
            sBuffer[i] = toupper(sBuffer[i]);
         m_hRecords.push_back(string(sBuffer,m + 8));
      }
   }
   string strService("DataNavigator");
   getSpec("SERVICE",strService);
   strService.append(" FM");
   Registry::setService(strService.c_str());
   if (!Registry::put("NODE001",m_strNode001))
      return false;
   if (!getSpec("QUALIFY",m_strQualify))
      return false;
   if (!Registry::put("QUALIFY",m_strQualify))
      return false;
   {
      IF::FlatFile hCustSpec("CUSTSPEC");
      while (hCustSpec.read(sBuffer + 8,248,&m))
      {
         if (sBuffer[8] != '*')
         {
            m_hRecords.push_back(string(sBuffer,m + 8));
            for (unsigned int i = 8;i < 16;++i)
               sBuffer[i] = toupper(sBuffer[i]);
            m_hRecords.push_back(string(sBuffer,m + 8));
            if (memcmp(sBuffer + 8,"CUSTQUAL",8) == 0)
            {
               string strFolder(m_strNode001);
#ifdef _WIN32
               strFolder += "\\";
#else
               strFolder += "/";
#endif
               strFolder += sBuffer + 21;
#ifdef _WIN32
               CreateDirectoryEx(m_strNode001.c_str(),strFolder.c_str(),NULL);
#else
               mkdir(strFolder.c_str(),S_IRWXU | S_IRWXG);
#endif
            }
         }
      }
   }
   string strCustomer;
   if (!getSpec("CUSTOMER",strCustomer))
      return false;
   {
     string strTemp("DFILES  PPROD   ");
     strTemp += m_strQualify;
#ifdef _WIN32
     strTemp += "\\Pprod\\%member.txt";
#else
     strTemp += "/Pprod/%member.txt";
#endif
     m_hRecords.push_back(strTemp);
     IF::FlatFile hSiteSpec("PPROD","FM");
     if (hSiteSpec.read(sBuffer,248, &m))
     {
       Trace::put("PPROD FM.txt file already exists");
       return true;
     }
   }
#ifdef _WIN32
   string strDirectory(m_strNode001);
   strDirectory += "\\Smtp";
   CreateDirectoryEx(m_strNode001.c_str(),strDirectory.c_str(),NULL);
   strDirectory = m_strNode001;
   strDirectory += "\\Smtp\\DeadLetter";
   CreateDirectoryEx(m_strNode001.c_str(),strDirectory.c_str(),NULL);
   strDirectory = m_strNode001;
   strDirectory += "\\Smtp\\Inbox";
   CreateDirectoryEx(m_strNode001.c_str(),strDirectory.c_str(),NULL);
   strDirectory = m_strNode001;
   strDirectory += "\\Smtp\\Outbox";
   CreateDirectoryEx(m_strNode001.c_str(),strDirectory.c_str(),NULL);
   strDirectory = m_strNode001;
   strDirectory += "\\Logs";
   CreateDirectoryEx(m_strNode001.c_str(),strDirectory.c_str(),NULL);
   strDirectory = m_strNode001;
   strDirectory += "\\Logs\\Open";
   CreateDirectoryEx(m_strNode001.c_str(),strDirectory.c_str(),NULL);
   strDirectory = m_strNode001;
   strDirectory += "\\Logs\\Closed";
   CreateDirectoryEx(m_strNode001.c_str(),strDirectory.c_str(),NULL);
   string strFolder(m_strNode001);
   strFolder += "\\";
   strFolder += m_strQualify;
   CreateDirectoryEx(m_strNode001.c_str(),strFolder.c_str(),NULL);
   strDirectory = strFolder;
   strDirectory += "\\Pprev";
   CreateDirectoryEx(m_strNode001.c_str(),strDirectory.c_str(),NULL);
   strDirectory = strFolder;
   strDirectory += "\\Pprod";
   CreateDirectoryEx(m_strNode001.c_str(),strDirectory.c_str(),NULL);
   strDirectory = strFolder;
   strDirectory += "\\Pstage";
   CreateDirectoryEx(m_strNode001.c_str(),strDirectory.c_str(),NULL);
#else
   string strDirectory(m_strNode001);
   strDirectory += "/Smtp";
   mkdir(strDirectory.c_str(),S_IRWXU | S_IRWXG);
   strDirectory = m_strNode001;
   strDirectory += "/Smtp/DeadLetter";
   mkdir(strDirectory.c_str(),S_IRWXU | S_IRWXG);
   strDirectory = m_strNode001;
   strDirectory += "/Smtp/Inbox";
   mkdir(strDirectory.c_str(),S_IRWXU | S_IRWXG);
   strDirectory = m_strNode001;
   strDirectory += "/Smtp/Outbox";
   mkdir(strDirectory.c_str(),S_IRWXU | S_IRWXG);
   strDirectory = m_strNode001;
   strDirectory += "/Logs";
   mkdir(strDirectory.c_str(),S_IRWXU | S_IRWXG);
   strDirectory = m_strNode001;
   strDirectory += "/Logs/Open";
   mkdir(strDirectory.c_str(),S_IRWXU | S_IRWXG);
   strDirectory = m_strNode001;
   strDirectory += "/Logs/Closed";
   mkdir(strDirectory.c_str(),S_IRWXU | S_IRWXG);
   string strFolder(m_strNode001);
   strFolder += "/";
   strFolder += m_strQualify;
   mkdir(strFolder.c_str(),S_IRWXU | S_IRWXG);
   strDirectory = strFolder;
   strDirectory += "/Pprev";
   mkdir(strDirectory.c_str(),S_IRWXU | S_IRWXG);
   strDirectory = strFolder;
   strDirectory += "/Pprod";
   mkdir(strDirectory.c_str(),S_IRWXU | S_IRWXG);
   strDirectory = strFolder;
   strDirectory += "/Pstage";
   mkdir(strDirectory.c_str(),S_IRWXU | S_IRWXG);
#endif
   string strTemp("DFILES  PPROD   ");
   strTemp += m_strQualify;
#ifdef _WIN32
   strTemp += "\\Pprod\\%member.txt";
#else
   strTemp += "/Pprod/%member.txt";
#endif
   m_hRecords.push_back(strTemp);
   {
      IF::FlatFile hSiteSpec("PPROD","SITESPEC");
      m = 0;
      string strBuffer;
      while (getRecord(m++,strBuffer))
      {
         if (strBuffer.substr(0,5) == "DSPEC")
            hSiteSpec.write((char*)strBuffer.data(),(int)strBuffer.length());
      }
      string strMember(strCustomer);
      strMember += "SPEC";
      IF::FlatFile hSpec("PPROD",strMember.c_str());
      {
         IF::FlatFile hHost("PPROD","HOST");
         string strProc;
         if (!getSpec("PROC",strProc))
            return false;
         string strDHost("DHOST   DNDN00  ");
         strDHost += strProc;
         hHost.write((char*)strDHost.data(),(int)strDHost.length());
         IF::FlatFile hFM("PPROD","FM");
         hFM.write("DUSER   FM",10);
         string strPortPFM("31000",5);
         getSpec("PORTPFM",strPortPFM);
         int j = atoi(strPortPFM.c_str());
         char szBuffer[34 + PERCENTD];
         hFM.write(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"DQUEUE  DNDN00  %05d   CXOPFM00FM    ",j));
         hFM.write(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"DQUEUE  HM      %05d   CXOPHM00HM  T ",++j));
         hFM.write(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"DQUEUE  MMC     %05d   CXOPWM00MMC T ",++j));
         hFM.write(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"DQUEUE  XT      %05d   CXOPXT00XT  T ",++j));
      }
      IF::FlatFile hMMC("PPROD","MMC");
      hMMC.write("DUSER   MMC",11);
      IF::FlatFile hHM("PPROD","HM");
      hHM.write("DUSER   HM",10);
      strTemp = "DSPEC   CUSTOMER";
      strTemp += strCustomer;
      hHM.write((char*)strTemp.data(),(int)strTemp.length());
      IF::FlatFile hXT("PPROD","XT");
      hXT.write("DUSER   XT",10);
      strTemp = "DFILES  PPROD   ";
      strTemp += m_strQualify;
#ifdef _WIN32
      strTemp += "\\Pprod\\%member.txt";
#else
      strTemp += "/Pprod/%member.txt";
#endif
      hXT.write((char*)strTemp.data(),(int)strTemp.length());
      strTemp = "DFILES  PSTAGE  ";
      strTemp += m_strQualify;
#ifdef _WIN32
      strTemp += "\\Pstage\\%member.txt";
#else
      strTemp += "/Pstage/%member.txt";
#endif
      hXT.write((char*)strTemp.data(),(int)strTemp.length());
#ifdef _WIN32
      hXT.write("DFILES  SCRIPT  Alpha\\Source\\%member.txt",40);
      hXT.write("DFILES  CONTROL Alpha\\Control\\%member.txt",41);
      hXT.write("DFILES  DATA    Alpha\\Data\\%member.txt",38);
      hXT.write("DFILES  RULES   Alpha\\Rules\\%member.txt",39);
      hXT.write("DFILES  DDATA   Delta\\Data\\%member.txt",38);
      hXT.write("DFILES  DRULES  Delta\\Rules\\%member.txt",39);
#else
      hXT.write("DFILES  SCRIPT  Alpha/Source/%member.txt",40);
      hXT.write("DFILES  CONTROL Alpha/Control/%member.txt",41);
      hXT.write("DFILES  DATA    Alpha/Data/%member.txt",38);
      hXT.write("DFILES  RULES   Alpha/Rules/%member.txt",39);
      hXT.write("DFILES  DDATA   Delta/Data/%member.txt",38);
      hXT.write("DFILES  DRULES  Delta/Rules/%member.txt",39);
#endif
      strTemp = "DSPEC   CUSTOMER";
      strTemp += strCustomer;
      hXT.write((char*)strTemp.data(),(int)strTemp.length());
   }
#endif
   return true;
  //## end IF::Extract::setup%3E6F64DF0232.body
}

// Additional Declarations
  //## begin IF::Extract%3472FB2202C0.declarations preserve=yes
  //## end IF::Extract%3472FB2202C0.declarations

} // namespace IF

//## begin module%36266F4F005D.epilog preserve=yes
//## end module%36266F4F005D.epilog
