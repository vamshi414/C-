// Copyright (c) 1998 - 2007
// eFunds Corporation
// $Date:   Dec 28 2006 11:04:40  $ $Author:   D02405  $ $Revision:   1.5  $

#ifndef CXODIF18_HPP
#define CXODIF18_HPP

#ifndef MVS
#pragma pack(push)
#endif
#pragma pack(1)

struct RecordBuffer
{
   char sBlockID[4];
   char sVersion[4];
   int lLength;
   int lBufferPointer;
   int lBufferLength;
   char sFiller[8];
};

struct StatusBlock_0610
{
   char sBlockID[4];
   char sVersion[4];
   int lLength;
   char sRequestBlockID[4];
   int lSeverityLevel;
   int lErrorCode;
   char sErrorPgmName[8];
   char sErrorPgmLabel[4];
   char sErrorCallerName[8];
   char sErrorCallerLabel[4];
   char sReturnStatusCode[2];
   char sErrorInfo[9];
   char sFiller[1];
   char sUserMessage[80];
   char sSystemMessage[80];
   int lLogThreshold;
   char sFiller2[512];
};

struct StatusBlock
{
   char sBlockID[4];
   char sVersion[4];
   int lLength;
   char sRequestBlockID[4];
   int lSeverityLevel;
   int lErrorCode;
   char sErrorPgmName[32];
   char sErrorPgmLabel[9];
   char sErrorCallerName[32];
   char sErrorCallerLabel[9];
   char sReturnStatusCode[2];
   char sErrorInfo[9];
   char sFiller[1];
   char sUserMessage[80];
   char sSystemMessage[80];
   int lLogThreshold;
   char sFiller2[512];
};

struct IndexItem
{
   char sTopicID[10];
   char sTopicItem[30];
   char sTopicVersion[14];
   char sFiller[1];
};

struct IndexBuffer
{
   char sBlockID[4];
   char sVersion[4];
   int lArrayMax;
   int lArrayUsed;
   IndexItem IndexArray[32];
};

struct VersionCloseBlock
{
   char sBlockID[4];
   char sVersion[4];
   char sArchiveID[10];
   char sArchiveVersion[14];
   char sFiller2[8];
};

struct VersionOpenBlock
{
   char sBlockID[4];
   char sVersion[4];
   char sWriteDirectFlag[1];
   char sVSAMSpaceReleaseFlag[1];
   char sFiller1[10];
   char sArchiveID[10];
   char sArchiveVersion[14];
   char sFiller2[8];
   char sDataType[1];
   char sFiller3[10];
};

struct VersionPutBlock
{
   char sBlockID[4];
   char sVersion[4];
   int lDataLength;
   char sFiller1[8];
   int lRecordOffset;
   int lRecordBlockID;
   int lRecordSequenceNbr;
   char sSectionCode[30];
   short siImageType;
   char sPageClassName[30];
   char sFiller2[60];
};

#ifdef MVS
#pragma pack(reset)
#else
#pragma pack(pop)
#endif

#endif
