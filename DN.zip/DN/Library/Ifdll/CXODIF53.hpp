//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%491EED52035B.cm preserve=no
//## end module%491EED52035B.cm

//## begin module%491EED52035B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%491EED52035B.cp

//## Module: CXOSIF53%491EED52035B; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF53.hpp

#ifndef CXOSIF53_h
#define CXOSIF53_h 1

//## begin module%491EED52035B.additionalIncludes preserve=no
//## end module%491EED52035B.additionalIncludes

//## begin module%491EED52035B.includes preserve=yes
//## end module%491EED52035B.includes

#ifndef CXOSIF50_h
#include "CXODIF50.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Memory;
class Extract;
class SecondaryCodes;
class SiteSpecification;

} // namespace IF

//## begin module%491EED52035B.declarations preserve=no
//## end module%491EED52035B.declarations

//## begin module%491EED52035B.additionalDeclarations preserve=yes
//## end module%491EED52035B.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::ZosFile%491EECA3031C.preface preserve=yes
//## end IF::ZosFile%491EECA3031C.preface

//## Class: ZosFile%491EECA3031C
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%491EFBF702FD;Extract { -> F}
//## Uses: <unnamed>%491EFBF9037A;Trace { -> F}
//## Uses: <unnamed>%491EFBFC000F;SecondaryCodes { -> F}
//## Uses: <unnamed>%491EFBFE0138;reusable::Transaction { -> F}
//## Uses: <unnamed>%491EFC000399;SiteSpecification { -> F}

class DllExport ZosFile : public File  //## Inherits: <unnamed>%491EECB202DE
{
  //## begin IF::ZosFile%491EECA3031C.initialDeclarations preserve=yes
  //## end IF::ZosFile%491EECA3031C.initialDeclarations

  public:
    //## Constructors (generated)
      ZosFile();

    //## Constructors (specified)
      //## Operation: ZosFile%491EEFFD009C
      ZosFile (const char* pszName, const char* pszMember);

      //## Operation: ZosFile%491EEFFE0222
      ZosFile (const char* pszName);

    //## Destructor (generated)
      virtual ~ZosFile();


    //## Other Operations (specified)
      //## Operation: close%491EF725002E
      virtual bool close ();

      //## Operation: datasetName%491EF3A90128
      virtual const string& datasetName ();

      //## Operation: flush%491EF3FD030D
      virtual bool flush ();

      //## Operation: isMail%52D940DC02B6
      virtual bool isMail ();

      //## Operation: move%491EF43E03D8
      virtual bool move (const char* pszTarget, const char* pszOutputFileName = 0);

      //## Operation: open%491EF88C0213
      virtual bool open (enum OpenType nOpenType = CX_OPEN_INPUT);

      //## Operation: purge%496DFD7400BB
      static void purge (const char* pszFolder, const string& strPeriod);

      //## Operation: read%491EF772038A
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool* pbReadError = NULL);

      //## Operation: remove%491EF56F0203
      virtual bool remove ();

      //## Operation: setAccessOption%491EFF42033C
      virtual void setAccessOption (enum AccessOption nAccessOption);

      //## Operation: setMember%491EF626033C
      virtual void setMember (const char* pszMember);

      //## Operation: write%491EF7ED0203
      virtual bool write (char* psBuffer, int lRecordLength);

    // Additional Public Declarations
      //## begin IF::ZosFile%491EECA3031C.public preserve=yes
      //## end IF::ZosFile%491EECA3031C.public

  protected:
    // Additional Protected Declarations
      //## begin IF::ZosFile%491EECA3031C.protected preserve=yes
      //## end IF::ZosFile%491EECA3031C.protected

  private:
    // Additional Private Declarations
      //## begin IF::ZosFile%491EECA3031C.private preserve=yes
      //## end IF::ZosFile%491EECA3031C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DDCount%4CBC8CE90072
      //## begin IF::ZosFile::DDCount%4CBC8CE90072.attr preserve=no  public: static int {V} 0
      static int m_iDDCount;
      //## end IF::ZosFile::DDCount%4CBC8CE90072.attr

      //## Attribute: DDName%4CBC8D530199
      //## begin IF::ZosFile::DDName%4CBC8D530199.attr preserve=no  public: string {V} 
      string m_strDDName;
      //## end IF::ZosFile::DDName%4CBC8D530199.attr

    // Data Members for Associations

      //## Association: Connex Library::IF_CAT::<unnamed>%654E091A0085
      //## Role: ZosFile::<m_pMemory>%654E091B0147
      //## begin IF::ZosFile::<m_pMemory>%654E091B0147.role preserve=no  public: static IF::Memory { -> RFHgN}
      static Memory *m_pMemory;
      //## end IF::ZosFile::<m_pMemory>%654E091B0147.role

    // Additional Implementation Declarations
      //## begin IF::ZosFile%491EECA3031C.implementation preserve=yes
      //## end IF::ZosFile%491EECA3031C.implementation

};

//## begin IF::ZosFile%491EECA3031C.postscript preserve=yes
//## end IF::ZosFile%491EECA3031C.postscript

} // namespace IF

//## begin module%491EED52035B.epilog preserve=yes
//## end module%491EED52035B.epilog


#endif
