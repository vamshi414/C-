//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%36266B6E007D.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36266B6E007D.cm

//## begin module%36266B6E007D.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36266B6E007D.cp

//## Module: CXOSIF06%36266B6E007D; Package specification
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXODIF06.hpp

#ifndef CXOSIF06_h
#define CXOSIF06_h 1

//## begin module%36266B6E007D.additionalIncludes preserve=no
//## end module%36266B6E007D.additionalIncludes

//## begin module%36266B6E007D.includes preserve=yes
// $Date:   Apr 08 2004 07:21:16  $ $Author:   D02405  $ $Revision:   1.2  $
//## end module%36266B6E007D.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%36266B6E007D.declarations preserve=no
//## end module%36266B6E007D.declarations

//## begin module%36266B6E007D.additionalDeclarations preserve=yes
//## end module%36266B6E007D.additionalDeclarations


//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::SecondaryCodes%34802A3D0040.preface preserve=yes
//## end IF::SecondaryCodes%34802A3D0040.preface

//## Class: SecondaryCodes%34802A3D0040
//	The SecondaryCodes class encapsulates an interface to
//	the Connex secondary codes (diagnostic information
//	related to the last call to the Connex high level API).
//
//	CXODIF06.hpp
//	CXOSIF06.cpp
//## Category: Connex Foundation::IF_CAT%3451F55F009E
//## Subsystem: IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class DllExport SecondaryCodes : public reusable::Object  //## Inherits: <unnamed>%34802A81037D
{
  //## begin IF::SecondaryCodes%34802A3D0040.initialDeclarations preserve=yes
  //## end IF::SecondaryCodes%34802A3D0040.initialDeclarations

  public:
    //## Constructors (generated)
      SecondaryCodes();

    //## Destructor (generated)
      virtual ~SecondaryCodes();


    //## Other Operations (specified)
      //## Operation: extract%3481C6AD0300
      //	Return the secondary codes for the current process.
      static string extract ();

    // Additional Public Declarations
      //## begin IF::SecondaryCodes%34802A3D0040.public preserve=yes
      //## end IF::SecondaryCodes%34802A3D0040.public

  protected:
    // Additional Protected Declarations
      //## begin IF::SecondaryCodes%34802A3D0040.protected preserve=yes
      //## end IF::SecondaryCodes%34802A3D0040.protected

  private:
    // Additional Private Declarations
      //## begin IF::SecondaryCodes%34802A3D0040.private preserve=yes
      //## end IF::SecondaryCodes%34802A3D0040.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::SecondaryCodes%34802A3D0040.implementation preserve=yes
      //## end IF::SecondaryCodes%34802A3D0040.implementation

};

//## begin IF::SecondaryCodes%34802A3D0040.postscript preserve=yes
//## end IF::SecondaryCodes%34802A3D0040.postscript

} // namespace IF

//## begin module%36266B6E007D.epilog preserve=yes
using namespace IF;
//## end module%36266B6E007D.epilog


#endif
