//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3729F8B803A3.cm preserve=no
//	$Date:   Apr 17 2018 20:07:20  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3729F8B803A3.cm

//## begin module%3729F8B803A3.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3729F8B803A3.cp

//## Module: CXOSIF37%3729F8B803A3; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF37.hpp

#ifndef CXOSIF37_h
#define CXOSIF37_h 1

//## begin module%3729F8B803A3.additionalIncludes preserve=no
//## end module%3729F8B803A3.additionalIncludes

//## begin module%3729F8B803A3.includes preserve=yes
// $Date:   Apr 17 2018 20:07:20  $ $Author:   e1009839  $ $Revision:   1.4  $
#define CM_SEND_AND_FLUSH 1
//## end module%3729F8B803A3.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Decimal;
class Queue;
class Message;

} // namespace IF

//## begin module%3729F8B803A3.declarations preserve=no
//## end module%3729F8B803A3.declarations

//## begin module%3729F8B803A3.additionalDeclarations preserve=yes
//## end module%3729F8B803A3.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::ResultSet%3729F87C0130.preface preserve=yes
//## end IF::ResultSet%3729F87C0130.preface

//## Class: ResultSet%3729F87C0130
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3729FA1601E4;Message { -> F}
//## Uses: <unnamed>%5AD6974C01F8;Queue { -> F}
//## Uses: <unnamed>%5AD697970077;Decimal { -> F}

class DllExport ResultSet : public reusable::Object  //## Inherits: <unnamed>%3729F893031E
{
  //## begin IF::ResultSet%3729F87C0130.initialDeclarations preserve=yes
  //## end IF::ResultSet%3729F87C0130.initialDeclarations

  public:
    //## Constructors (generated)
      ResultSet();

    //## Destructor (generated)
      virtual ~ResultSet();


    //## Other Operations (specified)
      //## Operation: addRow%3729F97800E2
      void addRow (const char* pszDescription, const char* pszRow);

      //## Operation: close%3729F9B6004B
      void close ();

      //## Operation: reply%3A5E01C603CD
      void reply ();

    // Additional Public Declarations
      //## begin IF::ResultSet%3729F87C0130.public preserve=yes
      //## end IF::ResultSet%3729F87C0130.public

  protected:
    // Additional Protected Declarations
      //## begin IF::ResultSet%3729F87C0130.protected preserve=yes
      //## end IF::ResultSet%3729F87C0130.protected

  private:
    // Additional Private Declarations
      //## begin IF::ResultSet%3729F87C0130.private preserve=yes
      //## end IF::ResultSet%3729F87C0130.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Cursor%372A033302F7
      //## begin IF::ResultSet::Cursor%372A033302F7.attr preserve=no  private: char* {V} 0
      char* m_pCursor;
      //## end IF::ResultSet::Cursor%372A033302F7.attr

      //## Attribute: Row%3729FCD20082
      //## begin IF::ResultSet::Row%3729FCD20082.attr preserve=no  private: int {V} 0
      int m_lRow;
      //## end IF::ResultSet::Row%3729FCD20082.attr

      //## Attribute: Rows%372A03F401D2
      //## begin IF::ResultSet::Rows%372A03F401D2.attr preserve=no  private: int {V} 0
      int m_lRows;
      //## end IF::ResultSet::Rows%372A03F401D2.attr

      //## Attribute: RowSize%372A04A9027C
      //## begin IF::ResultSet::RowSize%372A04A9027C.attr preserve=no  private: int {V} 0
      int m_lRowSize;
      //## end IF::ResultSet::RowSize%372A04A9027C.attr

    // Additional Implementation Declarations
      //## begin IF::ResultSet%3729F87C0130.implementation preserve=yes
      //## end IF::ResultSet%3729F87C0130.implementation

};

//## begin IF::ResultSet%3729F87C0130.postscript preserve=yes
//## end IF::ResultSet%3729F87C0130.postscript

} // namespace IF

//## begin module%3729F8B803A3.epilog preserve=yes
using namespace IF;
//## end module%3729F8B803A3.epilog


#endif
