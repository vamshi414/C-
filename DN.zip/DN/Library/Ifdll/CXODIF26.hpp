//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%35CB0EB20230.cm preserve=no
//	$Date:   May 07 2009 15:38:02  $ $Author:   D02405  $ $Revision:   1.7  $
//## end module%35CB0EB20230.cm

//## begin module%35CB0EB20230.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%35CB0EB20230.cp

//## Module: CXOSIF26%35CB0EB20230; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF26.hpp

#ifndef CXOSIF26_h
#define CXOSIF26_h 1

//## begin module%35CB0EB20230.additionalIncludes preserve=no
//## end module%35CB0EB20230.additionalIncludes

//## begin module%35CB0EB20230.includes preserve=yes
//## end module%35CB0EB20230.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;

} // namespace IF

//## begin module%35CB0EB20230.declarations preserve=no
//## end module%35CB0EB20230.declarations

//## begin module%35CB0EB20230.additionalDeclarations preserve=yes
//## end module%35CB0EB20230.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Decimal%35CB0754029C.preface preserve=yes
//## end IF::Decimal%35CB0754029C.preface

//## Class: Decimal%35CB0754029C
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4A03347B029F;CodeTable { -> F}

class DllExport Decimal : public reusable::Object  //## Inherits: <unnamed>%35CB0CC800F5
{
  //## begin IF::Decimal%35CB0754029C.initialDeclarations preserve=yes
  //## end IF::Decimal%35CB0754029C.initialDeclarations

  public:
    //## Constructors (generated)
      Decimal();

    //## Destructor (generated)
      virtual ~Decimal();


    //## Other Operations (specified)
      //## Operation: asLong%35CB0CF201C8
      static bool asLong (const char *psDecimalValue, short siLength, int* piBinaryValue);

      //## Operation: asDecimal%3C9F8EC40232
      static bool asDecimal (int iBinaryValue, char *psDecimalValue, short siLength);

      //## Operation: asDecimal%49E5F40401D4
      static bool asDecimal (double dDoubleValue, char *psDecimalValue, short siLength);

      //## Operation: asDouble%3A0AC1230012
      static bool asDouble (const char *psDecimalValue, short siLength, double* pdDoubleValue);

    // Additional Public Declarations
      //## begin IF::Decimal%35CB0754029C.public preserve=yes
      //## end IF::Decimal%35CB0754029C.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Decimal%35CB0754029C.protected preserve=yes
      //## end IF::Decimal%35CB0754029C.protected

  private:
    // Additional Private Declarations
      //## begin IF::Decimal%35CB0754029C.private preserve=yes
      //## end IF::Decimal%35CB0754029C.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::Decimal%35CB0754029C.implementation preserve=yes
      //## end IF::Decimal%35CB0754029C.implementation

};

//## begin IF::Decimal%35CB0754029C.postscript preserve=yes
//## end IF::Decimal%35CB0754029C.postscript

} // namespace IF

//## begin module%35CB0EB20230.epilog preserve=yes
using namespace IF;
//## end module%35CB0EB20230.epilog


#endif
