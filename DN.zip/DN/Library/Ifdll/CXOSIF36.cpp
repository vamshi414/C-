//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%37189CF202C5.cm preserve=no
//	$Date:   Nov 17 2021 15:07:02  $ $Author:   e1009839  $ $Revision:   1.12  $
//## end module%37189CF202C5.cm

//## begin module%37189CF202C5.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%37189CF202C5.cp

//## Module: CXOSIF36%37189CF202C5; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXOSIF36.cpp

//## begin module%37189CF202C5.additionalIncludes preserve=no
//## end module%37189CF202C5.additionalIncludes

//## begin module%37189CF202C5.includes preserve=yes
// $Date:   Nov 17 2021 15:07:02  $ $Author:   e1009839  $ $Revision:   1.12  $
#ifdef _WIN32
#include <time.h>
#endif
#ifdef _UNIX
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#endif
#include "CXODIF03.hpp"
#include "CXODIF44.hpp"
//## end module%37189CF202C5.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF38_h
#include "CXODIF38.hpp"
#endif
#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF36_h
#include "CXODIF36.hpp"
#endif


//## begin module%37189CF202C5.declarations preserve=no
//## end module%37189CF202C5.declarations

//## begin module%37189CF202C5.additionalDeclarations preserve=yes
//## end module%37189CF202C5.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::EMailMessage

//## begin IF::EMailMessage::Instance%3C45DE8A0010.attr preserve=no  private: static IF::EMailMessage {R} 0
IF::EMailMessage *EMailMessage::m_pInstance = 0;
//## end IF::EMailMessage::Instance%3C45DE8A0010.attr

//## begin IF::EMailMessage::<m_pMemory>%3A15528A01BC.role preserve=no  public: static IF::Memory { -> RHgN}
Memory *EMailMessage::m_pMemory = 0;
//## end IF::EMailMessage::<m_pMemory>%3A15528A01BC.role


//## begin IF::EMailMessage::<m_hEMailMessages>%3E859FEA0109.role preserve=no  public: static IF::EMailMessage {1 -> 0..*VFHgN}
vector<EMailMessage> EMailMessage::m_hEMailMessages;
//## end IF::EMailMessage::<m_hEMailMessages>%3E859FEA0109.role

EMailMessage::EMailMessage()
  //## begin EMailMessage::EMailMessage%37189C910190_const.hasinit preserve=no
  //## end EMailMessage::EMailMessage%37189C910190_const.hasinit
  //## begin EMailMessage::EMailMessage%37189C910190_const.initialization preserve=yes
  //## end EMailMessage::EMailMessage%37189C910190_const.initialization
{
  //## begin IF::EMailMessage::EMailMessage%37189C910190_const.body preserve=yes
   memcpy(m_sID,"IF36",4);
  //## end IF::EMailMessage::EMailMessage%37189C910190_const.body
}

EMailMessage::EMailMessage(const EMailMessage &right)
  //## begin EMailMessage::EMailMessage%37189C910190_copy.hasinit preserve=no
  //## end EMailMessage::EMailMessage%37189C910190_copy.hasinit
  //## begin EMailMessage::EMailMessage%37189C910190_copy.initialization preserve=yes
  //## end EMailMessage::EMailMessage%37189C910190_copy.initialization
{
  //## begin IF::EMailMessage::EMailMessage%37189C910190_copy.body preserve=yes
   memcpy(m_sID,"IF36",4);
   m_hText = right.m_hText;
   m_hFormat = right.m_hFormat;
   m_strFile = right.m_strFile;
  //## end IF::EMailMessage::EMailMessage%37189C910190_copy.body
}


EMailMessage::~EMailMessage()
{
  //## begin IF::EMailMessage::~EMailMessage%37189C910190_dest.body preserve=yes
   if (this == m_pInstance)
   {
      delete m_pMemory;
      m_pMemory = 0;
   }
  //## end IF::EMailMessage::~EMailMessage%37189C910190_dest.body
}


EMailMessage & EMailMessage::operator=(const EMailMessage &right)
{
  //## begin IF::EMailMessage::operator=%37189C910190_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_hText = right.m_hText;
   m_hFormat = right.m_hFormat;
   m_strFile = right.m_strFile;
   return *this;
  //## end IF::EMailMessage::operator=%37189C910190_assign.body
}



//## Other Operations (implementation)
void EMailMessage::accept (IF::EMailMessageVisitor& hEMailMessageVisitor)
{
  //## begin IF::EMailMessage::accept%3742C27F024D.body preserve=yes
   hEMailMessageVisitor.visitEMailMessage(this);
   vector<string>::iterator pstrText;
   for (pstrText = m_hFormat.begin();pstrText != m_hFormat.end();++pstrText)
      hEMailMessageVisitor.addFormat((*pstrText).data(),(int)(*pstrText).length());
   for (pstrText = m_hText.begin();pstrText != m_hText.end();++pstrText)
      hEMailMessageVisitor.visitText(&(*pstrText));
  //## end IF::EMailMessage::accept%3742C27F024D.body
}

void EMailMessage::eraseAll ()
{
  //## begin IF::EMailMessage::eraseAll%3C45DF7B02D4.body preserve=yes
   m_hEMailMessages.erase(m_hEMailMessages.begin(),m_hEMailMessages.end());
  //## end IF::EMailMessage::eraseAll%3C45DF7B02D4.body
}

IF::EMailMessage* EMailMessage::instance ()
{
  //## begin IF::EMailMessage::instance%3C45DD7B01E7.body preserve=yes
   if (!m_pInstance)
   {
      m_pMemory = new Memory(256);
      m_pInstance = new EMailMessage();
   }
   return m_pInstance;
  //## end IF::EMailMessage::instance%3C45DD7B01E7.body
}

bool EMailMessage::open (const string& strFile, const string& strMember)
{
  //## begin IF::EMailMessage::open%3742BFFA0259.body preserve=yes
#ifdef MVS
   FlatFile hTemplate(strFile.c_str(),strMember.c_str());
#else
   FlatFile hTemplate("SOURCE",strMember.c_str());
#endif
   if (!hTemplate.open())
      return false;
   m_hText.erase(m_hText.begin(),m_hText.end());
   char* psBuffer = new char[256];
   size_t nReadBytes;
   bool bFormatSection(false);
   bool bContinuation(false);
   size_t pos;
   string strText;
   strText.reserve(512);
   while (hTemplate.read(psBuffer,256,&nReadBytes))
   {
      if (strstr(psBuffer,"ADD NAME=") != 0)
         ;
      else
      if (nReadBytes >= 7 && !memcmp(psBuffer,"#FORMAT",7))
         bFormatSection = true;
      else
      if (bFormatSection)
      {
         if (nReadBytes >= 4 && !memcmp(psBuffer,"#END",4))
            bFormatSection = false;
         else
         {
            strText.assign(psBuffer,nReadBytes);
            m_hFormat.push_back(strText);
            strText.erase();
         }
      }
      else
      {
         bContinuation = (nReadBytes > 0) && (psBuffer[nReadBytes - 1] == '&');
         strText.append(psBuffer,bContinuation ? nReadBytes-1 : nReadBytes);
         pos = strText.find_last_not_of(' ');
         if (pos != string::npos)
            strText.erase(pos + 1);
         if (!bContinuation)
         {
            m_hText.push_back(strText);
            strText.erase();
         }
      }
   }
   delete [] psBuffer;
   return true;
  //## end IF::EMailMessage::open%3742BFFA0259.body
}

void EMailMessage::save ()
{
  //## begin IF::EMailMessage::save%3C45DDBC00B4.body preserve=yes
   m_hEMailMessages.push_back(*EMailMessage::instance());
  //## end IF::EMailMessage::save%3C45DDBC00B4.body
}

bool EMailMessage::send (const string& strFile)
{
  //## begin IF::EMailMessage::send%37189DA40018.body preserve=yes
   FlatFile hDestination(strFile.c_str());
   if (!hDestination.open(FlatFile::CX_OPEN_OUTPUT))
      return false;
   char* pszBuffer = (char*) *m_pMemory;
   vector<string>::iterator pstrText;
   for (pstrText = m_hText.begin(); pstrText != m_hText.end(); ++pstrText)
   {
	   size_t n;
	   if ((n = pstrText->find("#REPEAT")) == string::npos)
	   {
		   while ((n = pstrText->find("\n")) != string::npos)
		   {
#ifdef MVS
			   memset(pszBuffer, ' ', 256);
			   memcpy(pszBuffer, pstrText->data(), n);
			   hDestination.write(pszBuffer, 256);
#else
			   hDestination.write((char*)pstrText->data(), (int)n);
#endif
			   pstrText->erase(0, n + 1);
		   }
#ifdef MVS
		   memset(pszBuffer, ' ', 256);
		   int i = (pstrText->length() > 256) ? 256 : pstrText->length();
		   memcpy(pszBuffer, pstrText->data(), i);
		   hDestination.write(pszBuffer, 256);
#else
		   hDestination.write((char*)pstrText->data(), (int)pstrText->length());
#endif
	   }
   }
#ifndef MVS
   string strKey("PATH");
   string strValue(hDestination.datasetName());
   SiteSpecification::instance()->add(strKey,strValue);
   hDestination.close();
   time_t tTime;
   time(&tTime);
   tm *tmTime = localtime(&tTime);
   char szTemp[32];
   string strDate(szTemp,snprintf(szTemp,sizeof(szTemp),"D%04d%02d%02d.T%02d%02d%02d",
      tmTime->tm_year + 1900,tmTime->tm_mon + 1,tmTime->tm_mday,
      tmTime->tm_hour,tmTime->tm_min,tmTime->tm_sec));
   strDate.erase(1,2);
   Job::submit(strFile.c_str(),"&DATE   ",strDate.c_str());
#endif
   return true;
  //## end IF::EMailMessage::send%37189DA40018.body
}

bool EMailMessage::sendAll ()
{
  //## begin IF::EMailMessage::sendAll%3C45EA190387.body preserve=yes
   vector<EMailMessage>::iterator pEMailMessage;
   for (pEMailMessage = m_hEMailMessages.begin();pEMailMessage != m_hEMailMessages.end();++pEMailMessage)
   {
	   Trace::put("EMailMessage::sendAll");
	  Trace::put(pEMailMessage->m_strFile.c_str());
      if (!pEMailMessage->send(pEMailMessage->m_strFile))
      {
         eraseAll();
         return false;
      }
   }
   eraseAll();
   return true;
  //## end IF::EMailMessage::sendAll%3C45EA190387.body
}

// Additional Declarations
  //## begin IF::EMailMessage%37189C910190.declarations preserve=yes
  //## end IF::EMailMessage%37189C910190.declarations

} // namespace IF

//## begin module%37189CF202C5.epilog preserve=yes
//## end module%37189CF202C5.epilog
