//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36DC56BB0005.cm preserve=no
//	$Date:   Apr 02 2018 15:08:22  $ $Author:   e1009652  $ $Revision:   1.3  $
//## end module%36DC56BB0005.cm

//## begin module%36DC56BB0005.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%36DC56BB0005.cp

//## Module: CXOSIF32%36DC56BB0005; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.8A.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF32.hpp

#ifndef CXOSIF32_h
#define CXOSIF32_h 1

//## begin module%36DC56BB0005.additionalIncludes preserve=no
//## end module%36DC56BB0005.additionalIncludes

//## begin module%36DC56BB0005.includes preserve=yes
// $Date:   Apr 02 2018 15:08:22  $ $Author:   e1009652  $ $Revision:   1.3  $
//## end module%36DC56BB0005.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;

} // namespace IF

//## begin module%36DC56BB0005.declarations preserve=no
//## end module%36DC56BB0005.declarations

//## begin module%36DC56BB0005.additionalDeclarations preserve=yes
//## end module%36DC56BB0005.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::QueueFactory%36DC539F00F1.preface preserve=yes
//## end IF::QueueFactory%36DC539F00F1.preface

//## Class: QueueFactory%36DC539F00F1
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5ABD49240336;Queue { -> F}

class DllExport QueueFactory : public reusable::Object  //## Inherits: <unnamed>%36DC53C60350
{
  //## begin IF::QueueFactory%36DC539F00F1.initialDeclarations preserve=yes
  //## end IF::QueueFactory%36DC539F00F1.initialDeclarations

  public:
    //## Constructors (generated)
      QueueFactory();

    //## Destructor (generated)
      virtual ~QueueFactory();


    //## Other Operations (specified)
      //## Operation: create%36DC53F1018F
      virtual Object* create (const char* pszClass, const char* pszValue = 0) = 0;

      //## Operation: create%5ABD487E01A8
      virtual IF::Queue* create (const IF::Queue& hQueue);

      //## Operation: instance%36DC54360184
      static QueueFactory* instance ();

    // Additional Public Declarations
      //## begin IF::QueueFactory%36DC539F00F1.public preserve=yes
      //## end IF::QueueFactory%36DC539F00F1.public

  protected:
    // Additional Protected Declarations
      //## begin IF::QueueFactory%36DC539F00F1.protected preserve=yes
      //## end IF::QueueFactory%36DC539F00F1.protected

  private:
    // Additional Private Declarations
      //## begin IF::QueueFactory%36DC539F00F1.private preserve=yes
      //## end IF::QueueFactory%36DC539F00F1.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%36DC545A0303
      //## begin IF::QueueFactory::Instance%36DC545A0303.attr preserve=no  private: static QueueFactory {R} 0
      static QueueFactory *m_pInstance;
      //## end IF::QueueFactory::Instance%36DC545A0303.attr

    // Additional Implementation Declarations
      //## begin IF::QueueFactory%36DC539F00F1.implementation preserve=yes
      //## end IF::QueueFactory%36DC539F00F1.implementation

};

//## begin IF::QueueFactory%36DC539F00F1.postscript preserve=yes
//## end IF::QueueFactory%36DC539F00F1.postscript

} // namespace IF

//## begin module%36DC56BB0005.epilog preserve=yes
using namespace IF;
//## end module%36DC56BB0005.epilog


#endif
