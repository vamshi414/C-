//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3AAA898D03C6.cm preserve=no
//   $Date:   May 28 2021 08:29:40  $ $Author:   e5627846  $ $Revision:   1.123  $
//## end module%3AAA898D03C6.cm

//## begin module%3AAA898D03C6.cp preserve=no
//   Copyright (c) 1997 - 2012
//   FIS
//## end module%3AAA898D03C6.cp

//## Module: CXOSIF39%3AAA898D03C6; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//   .
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF39.cpp

//## begin module%3AAA898D03C6.additionalIncludes preserve=no
//## end module%3AAA898D03C6.additionalIncludes

//## begin module%3AAA898D03C6.includes preserve=yes
#ifdef MVS
#include <leawi.h>
#include <sys/select.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include <algorithm>
#ifdef _WIN32
#include <process.h>
//#include <Winsock2.h>
#else
#define __IPV6
#include <sys/socket.h>
#include <poll.h>
#include <netdb.h>
#include <pthread.h>
#include <errno.h>
#endif
#include <time.h>
#ifdef SOMAXCONN
#undef SOMAXCONN
#endif
#define SOMAXCONN 256
#include "CXODRU15.hpp"
#include <algorithm>
//## end module%3AAA898D03C6.includes

#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSIF57_h
#include "CXODIF57.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF39_h
#include "CXODIF39.hpp"
#endif


//## begin module%3AAA898D03C6.declarations preserve=no
//## end module%3AAA898D03C6.declarations

//## begin module%3AAA898D03C6.additionalDeclarations preserve=yes
#ifdef _WIN32
#define _Optlink
#define ETIMEDOUT 10060
#define ECONNRESET 10054
#else
#define _Optlink *
#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
//#define ETIMEDOUT 145 is defined in errno.h
#define closesocket ::close
int WSAGetLastError()
{
   return errno;
}
#endif
#define MAX_INCOMING_MESSAGE_SIZE 1024000
// include CXOSSW01.hpp after CXODIF39.hpp
#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif

extern "C"
{
void _Optlink ReadConnection(void* pSocketQueue)
{
   while (((SocketQueue*)pSocketQueue)->getThread() == 0)
#ifdef _WIN32
      ::Sleep(1);
#else
      break;
   ((SocketQueue*)pSocketQueue)->setThread(SocketQueue::m_iThread++);
#endif
   ((SocketQueue*)pSocketQueue)->trace("ReadConnection");
   SocketQueue::add((SocketQueue*)pSocketQueue);
   if (((SocketQueue*)pSocketQueue)->getInterface() == SocketQueue::CRLF)
   {
      Message* pMessage = ((SocketQueue*)pSocketQueue)->message(sizeof(struct hGDMHeader));
      pMessage->setSource("");
      hGDMHeader* pGDMHeader = (hGDMHeader*)(char*)pMessage->buffer();
      memcpy(pGDMHeader->sDescription,"CNX ",4);
      pGDMHeader->siDataElement1 = htons(0);
      memcpy(pGDMHeader->sData1,"CONNECT ",8);
      pGDMHeader->siDataLength1 = htons(8);
      pGDMHeader->siDataElement2 = htons(0);
      memset(pGDMHeader->sData2,' ',24);
      pGDMHeader->siDataLength2 = htons(0);
      pMessage->setMessageLength(sizeof(struct hGDMHeader));
      char sCorrelId[PERCENTF+8];
      memset(sCorrelId,' ',PERCENTF+8);
      Object::snprintf(sCorrelId, sizeof(sCorrelId), "%08x%16.0f", ((SocketQueue*)pSocketQueue)->getThread(), ((SocketQueue*)pSocketQueue)->getTicks());
      pMessage->setCorrelId(sCorrelId);
      ((SocketQueue*)pSocketQueue)->push(pMessage,((SocketQueue*)pSocketQueue)->getSignal());
   }
   for (;;)
      if (!((SocketQueue*)pSocketQueue)->receive())
         break;
   ((SocketQueue*)pSocketQueue)->trace("~ReadConnection");
   SocketQueue::remove((SocketQueue*)pSocketQueue);
#ifdef _WIN32
   _endthread();
#else
#ifdef _AIX
   pthread_exit(0);
#endif
   return 0;
#endif
}
}

void _Optlink PollConnections(void* pSocketQueue)
{
   ((SocketQueue*)pSocketQueue)->m_pFDs = new vector<struct pollfd>;
   struct pollfd fd;
   fd.fd = ((SocketQueue*)pSocketQueue)->getServerSocket();
   fd.events = POLLIN;
   fd.revents = 0;
   ((SocketQueue*)pSocketQueue)->m_pFDs->push_back(fd);
   ((SocketQueue*)pSocketQueue)->trace("PollConnections");
   for (;;)
   {
      if (!((SocketQueue*)pSocketQueue)->poll())
         break;
   }
#ifdef _WIN32
   _endthread();
#else
#ifdef _AIX
   pthread_exit(0);
#endif
   return 0;
#endif
}

void _Optlink AcceptConnections(void* pSocketQueue)
{
#ifdef _WIN32
   int lThread = 0;
#else
   pthread_t hThread;
   ((SocketQueue*)pSocketQueue)->setThread(SocketQueue::m_iThread++);
#endif
   ((SocketQueue*)pSocketQueue)->trace("AcceptConnections");
   for (;;)
   {
      if (!((SocketQueue*)pSocketQueue)->accept())
         break;
      SocketQueue* pConnection = (SocketQueue*)QueueFactory::instance()->create(*(Queue*)pSocketQueue);
#ifdef _WIN32
      if (lThread = _beginthread(ReadConnection,0,pConnection))
#else
      pthread_attr_t attr;
      pthread_attr_init(&attr);
#ifdef _UNIX
      pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
#else
      int ds = 1;
      pthread_attr_setdetachstate(&attr,&ds);
#endif
      if (pthread_create(&hThread,&attr,ReadConnection,pConnection) == 0)
#endif
      {
#ifdef _WIN32
         pConnection->setThread(lThread);
#endif
      }
      else
         SocketQueue::remove(pConnection);
   }
#ifdef _WIN32
   _endthread();
#else
#ifdef _AIX
   pthread_exit(0);
#endif
   return 0;
#endif
}
//## end module%3AAA898D03C6.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
bool SocketQueue::m_bCout = false;
//## end IF%3451F55F009E.initialDeclarations

// Class IF::SocketQueue

//## begin IF::SocketQueue::Address%464380F201A5.attr preserve=no  public: static string {V}
string SocketQueue::m_strAddress;
//## end IF::SocketQueue::Address%464380F201A5.attr

//## begin IF::SocketQueue::Count%48A447F40148.attr preserve=no  private: static double {V} 0
double SocketQueue::m_dCount = 0;
//## end IF::SocketQueue::Count%48A447F40148.attr

//## begin IF::SocketQueue::QueueDepth%58B876DD01B5.attr preserve=no  private: static int {V} 0
int SocketQueue::m_iQueueDepth = 0;
//## end IF::SocketQueue::QueueDepth%58B876DD01B5.attr

//## begin IF::SocketQueue::Quiesced%4722003A001F.attr preserve=no  private: static bool {V} false
bool SocketQueue::m_bQuiesced = false;
//## end IF::SocketQueue::Quiesced%4722003A001F.attr

//## begin IF::SocketQueue::Thread%4D121FB503D7.attr preserve=no  public: static int {VA} 0
int SocketQueue::m_iThread = 0;
//## end IF::SocketQueue::Thread%4D121FB503D7.attr


//## begin IF::SocketQueue::<m_pApplicationQueue>%40251FED004E.role preserve=no  public: static IF::SocketQueue { -> RFHgN}
SocketQueue *SocketQueue::m_pApplicationQueue = 0;
//## end IF::SocketQueue::<m_pApplicationQueue>%40251FED004E.role

SocketQueue::SocketQueue()
  //## begin SocketQueue::SocketQueue%3AAA88A20102_const.hasinit preserve=no
      : m_hConnectionSocket(-1),
        m_pFDs(0),
        m_nInterface(NORMAL),
        m_iPort(0),
        m_bServer(true),
        m_hServerSocket(-1),
        m_dTicks(0),
        m_iTimeout(30)
  //## end SocketQueue::SocketQueue%3AAA88A20102_const.hasinit
  //## begin SocketQueue::SocketQueue%3AAA88A20102_const.initialization preserve=yes
  //## end SocketQueue::SocketQueue%3AAA88A20102_const.initialization
{
  //## begin IF::SocketQueue::SocketQueue%3AAA88A20102_const.body preserve=yes
   memcpy(m_sID,"IF39",4);
   trace("SocketQueue::SocketQueue()");
   m_iRetryCount = -1;
  //## end IF::SocketQueue::SocketQueue%3AAA88A20102_const.body
}

SocketQueue::SocketQueue(const SocketQueue &right)
  //## begin SocketQueue::SocketQueue%3AAA88A20102_copy.hasinit preserve=no
  //## end SocketQueue::SocketQueue%3AAA88A20102_copy.hasinit
  //## begin SocketQueue::SocketQueue%3AAA88A20102_copy.initialization preserve=yes
   :Queue(right)
  //## end SocketQueue::SocketQueue%3AAA88A20102_copy.initialization
{
  //## begin IF::SocketQueue::SocketQueue%3AAA88A20102_copy.body preserve=yes
   memcpy(m_sID,"IF39",4);
   m_hConnectionSocket = right.m_hConnectionSocket;
   m_nInterface = right.m_nInterface;
   m_bServer = false;
   memcpy((char*)&(m_hClientAddress),(char*)&(right.m_hClientAddress),sizeof(m_hClientAddress));
   m_dTicks = ++m_dCount;
   m_iPort = 0;
   m_hServerSocket = -1;
   Extract::instance()->getSpec("SLEEP",m_strSleep); // e.g. "000000000001000" for 1 microsecond
   trace("SocketQueue::SocketQueue(const SocketQueue&)");
   m_iRetryCount = -1;
  //## end IF::SocketQueue::SocketQueue%3AAA88A20102_copy.body
}

SocketQueue::SocketQueue (const char* pszName)
  //## begin IF::SocketQueue::SocketQueue%3AAA8CAA02BE.hasinit preserve=no
      : m_hConnectionSocket(-1),
        m_pFDs(0),
        m_nInterface(NORMAL),
        m_iPort(0),
        m_bServer(true),
        m_hServerSocket(-1),
        m_dTicks(0),
        m_iTimeout(30)
  //## end IF::SocketQueue::SocketQueue%3AAA8CAA02BE.hasinit
  //## begin IF::SocketQueue::SocketQueue%3AAA8CAA02BE.initialization preserve=yes
   ,Queue(pszName)
  //## end IF::SocketQueue::SocketQueue%3AAA8CAA02BE.initialization
{
  //## begin IF::SocketQueue::SocketQueue%3AAA8CAA02BE.body preserve=yes
   memcpy(m_sID,"IF39",4);
   m_strRealName = pszName;
   m_strRealName.resize(8,' ');
   if (!Extract::instance()->getQueue(pszName,m_strName,&m_iPort))
      m_iPort = 65535;
   trace("SocketQueue::SocketQueue(const char*)");
   m_iRetryCount = -1;
  //## end IF::SocketQueue::SocketQueue%3AAA8CAA02BE.body
}


SocketQueue::~SocketQueue()
{
  //## begin IF::SocketQueue::~SocketQueue%3AAA88A20102_dest.body preserve=yes
#ifdef _WIN32
   // if (m_hConnectionSocket != -1)
#endif
      close();
   if (m_pSignal)
      if (!m_bQuiesced)
      {
         Message* pMessage = message(sizeof(struct hGDMHeader));
         hGDMHeader* pGDMHeader = (hGDMHeader*)(char*)pMessage->buffer();
         memcpy(pGDMHeader->sDescription,"CNX ",4);
         pGDMHeader->siDataElement1 = htons(0);
         memcpy(pGDMHeader->sData1,"DEALLOC ",8);
         pGDMHeader->siDataLength1 = htons(8);
         pGDMHeader->siDataElement2 = htons(0);
         memset(pGDMHeader->sData2,' ',sizeof(pGDMHeader->sData2));
         char sCorrelId[PERCENTF+8];
         memset(sCorrelId,' ',PERCENTF+8);
         snprintf(sCorrelId,sizeof(sCorrelId),"%08x%16.0f",m_lThread,m_dTicks);
         memcpy(pGDMHeader->sData2,sCorrelId,24);
         pGDMHeader->siDataLength2 = htons(24);
         pGDMHeader->siTotalMessageLength = htons(sizeof(struct hGDMHeader));
         pMessage->setMessageLength(sizeof(struct hGDMHeader));
         pMessage->setSource(m_strName);
         push(pMessage,m_pSignal);
      }
   trace("SocketQueue::~SocketQueue()");
   if (m_pSignal)
   {
      m_pSignal->detach(this);
      SignalList::instance()->enable(m_pSignal,false);
   }
  //## end IF::SocketQueue::~SocketQueue%3AAA88A20102_dest.body
}


SocketQueue & SocketQueue::operator=(const SocketQueue &right)
{
  //## begin IF::SocketQueue::operator=%3AAA88A20102_assign.body preserve=yes
   m_hConnectionSocket = right.m_hConnectionSocket;
   m_nInterface = right.m_nInterface;
   m_bServer = false;
   m_hServerSocket = -1;
   m_lThread = right.m_lThread;
   memcpy((char*)&(m_hClientAddress),(char*)&(right.m_hClientAddress),sizeof(m_hClientAddress));
   trace("SocketQueue::operator=");
   return *this;
  //## end IF::SocketQueue::operator=%3AAA88A20102_assign.body
}



//## Other Operations (implementation)
bool SocketQueue::accept ()
{
  //## begin IF::SocketQueue::accept%3AACB3500288.body preserve=yes
    trace("SocketQueue::accept");
#ifdef _WIN32
   int i = sizeof(m_hClientAddress);
#else
   unsigned int i = sizeof(m_hClientAddress);
#endif
   for (;;)
   {
      if ((m_hConnectionSocket = ::accept(m_hServerSocket,(struct sockaddr*)&m_hClientAddress,&i)) == INVALID_SOCKET)
      {
         int iError = WSAGetLastError();
         if (iError != 0)
         {
            char szTemp[32];
            snprintf(szTemp,sizeof(szTemp),"::accept returned %d",(int)WSAGetLastError());
            trace(szTemp);
         }
#ifdef _WIN32
         if (iError == 10038) // socket was closed
            return false;
         if (iError != 10004)
            return reportError("accept",iError);
#else
         if (iError == ENOTSOCK)
            return false;
         if (iError != EINTR)
            return reportError("accept",iError);
#endif
     }
      else
         break;
   }
   return true;
  //## end IF::SocketQueue::accept%3AACB3500288.body
}

void SocketQueue::add (SocketQueue* pSocketQueue)
{
  //## begin IF::SocketQueue::add%3AAA970E02CD.body preserve=yes
   CriticalSection hCriticalSection;
   if (!m_pQueue)
      m_pQueue = new map<string,Queue*,less<string> >;
   m_pQueue->insert(map<string,Queue*,less<string> >::value_type(pSocketQueue->getRealName(),pSocketQueue));
  //## end IF::SocketQueue::add%3AAA970E02CD.body
}

int SocketQueue::charHexToInt (const char* charHex, int iLength)
{
  //## begin IF::SocketQueue::charHexToInt%58F0E8130342.body preserve=yes
   if (iLength > 5)
      return -1;
   int iReturnVal = 0;
   int j = 0;
   char Hex[] = {"0123456789abcdefABCDEF"};
#ifdef MVS
   Hex[0] = 0x30;
   Hex[1] = 0x31;
   Hex[2] = 0x32;
   Hex[3] = 0x33;
   Hex[4] = 0x34;
   Hex[5] = 0x35;
   Hex[6] = 0x36;
   Hex[7] = 0x37;
   Hex[8] = 0x38;
   Hex[9] = 0x39;
   Hex[10] = 0x61;
   Hex[11] = 0x62;
   Hex[12] = 0x63;
   Hex[13] = 0x64;
   Hex[14] = 0x65;
   Hex[15] = 0x66;
   Hex[16] = 0x41;
   Hex[17] = 0x42;
   Hex[18] = 0x43;
   Hex[19] = 0x44;
   Hex[20] = 0x45;
   Hex[21] = 0x46;
#endif
   int place[6] = {1,16,256,4096,65536};
   for (int i = 0;i < iLength;i++)
   {
      for (j = 0;j < 22;j++)
         if (charHex[i] == Hex[j])
         {
            iReturnVal += (j > 15 ? j - 6 : j) * (place[iLength - 1 - i]);
            break;
         }
      if (j == 22)
         return -1; //not hex value
   }
   return iReturnVal;
  //## end IF::SocketQueue::charHexToInt%58F0E8130342.body
}

bool SocketQueue::close ()
{
  //## begin IF::SocketQueue::close%3AAA8C2E0310.body preserve=yes
   if (m_bServer
      && m_hServerSocket != -1)
   {
#ifdef _UNIX
      shutdown(m_hServerSocket,2);
#else
      if (closesocket(m_hServerSocket) == SOCKET_ERROR)
         return reportError("closesocket",WSAGetLastError());
#endif
      m_hServerSocket = -1;
   }
   else
   if (m_hConnectionSocket != -1)
   {
#ifdef _UNIX
      shutdown(m_hConnectionSocket,2);
#endif
      if (closesocket(m_hConnectionSocket) == SOCKET_ERROR)
         return reportError("closesocket",WSAGetLastError());
      m_hConnectionSocket = -1;
   }
   return true;
  //## end IF::SocketQueue::close%3AAA8C2E0310.body
}

void SocketQueue::closeConnections ()
{
  //## begin IF::SocketQueue::closeConnections%3DCBDE280261.body preserve=yes
   m_bQuiesced = true;
   if (!m_pQueue)
      return;
   CriticalSection hCriticalSection;
   map<string,Queue*,less<string> >::iterator pQueue = m_pQueue->begin();
   while (pQueue != m_pQueue->end())
   {
      if (((SocketQueue*)(*pQueue).second)->getThread() == 0)
      {
         delete (SocketQueue*)(*pQueue).second;
         pQueue = m_pQueue->begin();
      }
      else
         ++pQueue;
   }
  //## end IF::SocketQueue::closeConnections%3DCBDE280261.body
}

bool SocketQueue::connect (bool bSecureMVS)
{
  //## begin IF::SocketQueue::connect%3AACBC5902DE.body preserve=yes
   if (m_hConnectionSocket != -1)
      return true;
   string strTemp("SocketQueue::connect to: ");
   strTemp += m_strName;
   trace(strTemp.c_str());
   Trace::put(strTemp.c_str());
   // pszName should be "computer_name~port_number" or "port_number"
   m_bServer = false;
   if ((m_hConnectionSocket = socket(AF_INET,SOCK_STREAM,0)) == INVALID_SOCKET)
      return reportError("socket",WSAGetLastError());
   char szHostName[257];
   int iLen = m_strName.length() > 255 ? 255:m_strName.length();
   memcpy(szHostName,m_strName.data(),iLen);
   szHostName[iLen] = '\0';
   if (!strcmp(szHostName,"local"))
      if (gethostname(szHostName,256) != 0)
         return reportError("gethostname",43);
   szHostName[256] = '\0'; // force null termination for Fortify (POSIX.1 does not define if null terminator is added if truncation occurs)
   m_strHost = szHostName;
   strTemp += " ";
   strTemp.append(szHostName);
   trace(strTemp.c_str());
   struct addrinfo hints;
   struct addrinfo* pAddrInfo = 0;
   memset(&hints,0,sizeof(hints));
   hints.ai_family = AF_INET;
   hints.ai_socktype = SOCK_STREAM;
   if (bSecureMVS)
      hints.ai_flags = AI_NUMERICHOST | AI_CANONNAME;  //added
   char szPort[9];
   snprintf(szPort,sizeof(szPort),"%d",m_iPort);
   int error = getaddrinfo(szHostName,szPort,&hints,&pAddrInfo);
   if (error)
   {
      if (pAddrInfo)
         freeaddrinfo(pAddrInfo);
      return reportError("getaddrinfo",error);
   }
   if (::connect(m_hConnectionSocket,pAddrInfo->ai_addr,pAddrInfo->ai_addrlen) == SOCKET_ERROR)
   {
      int rc = WSAGetLastError();
      closesocket(m_hConnectionSocket);
      m_hConnectionSocket = -1;
      freeaddrinfo(pAddrInfo);
      return reportError("connect",rc);
   }
   freeaddrinfo(pAddrInfo);
   return true;
  //## end IF::SocketQueue::connect%3AACBC5902DE.body
}

bool SocketQueue::exists (const string& strName)
{
  //## begin IF::SocketQueue::exists%530F988302B0.body preserve=yes
   map<string,Queue*,less<string> >::iterator p = m_pQueue->find(strName);
   return p != m_pQueue->end();
  //## end IF::SocketQueue::exists%530F988302B0.body
}

void SocketQueue::free (IF::Message* pMessage)
{
  //## begin IF::SocketQueue::free%5AFFC8CF0196.body preserve=yes
   CriticalSection hCriticalSection;
   pMessage->setNext(Message::getFree());
   Message::setFree(pMessage);
  //## end IF::SocketQueue::free%5AFFC8CF0196.body
}

int SocketQueue::getQueueDepth ()
{
  //## begin IF::SocketQueue::getQueueDepth%3EB928F50261.body preserve=yes
   return m_iQueueDepth;
  //## end IF::SocketQueue::getQueueDepth%3EB928F50261.body
}

void SocketQueue::initialize ()
{
  //## begin IF::SocketQueue::initialize%3E7C62780138.body preserve=yes
#ifdef _WIN32
   int rc = 0;
   WORD wVersionRequested = MAKEWORD(1,1);
   WSADATA wsaData;
   if ((rc = WSAStartup(wVersionRequested,&wsaData)) != 0)
      Trace::put("WSAStartup failure 1");
   if (LOBYTE(wsaData.wVersion) != 1 || HIBYTE(wsaData.wVersion) != 1)
      Trace::put("WSAStartup failure 2");
#endif
  //## end IF::SocketQueue::initialize%3E7C62780138.body
}

bool SocketQueue::listen ()
{
  //## begin IF::SocketQueue::listen%4024E934008C.body preserve=yes
   if (m_lThread != 0)
      return true;
   if (m_pApplicationQueue)
      m_pSignal = m_pApplicationQueue->m_pSignal;
#ifdef _WIN32
   return (m_lThread = _beginthread(ReadConnection,0,this));
#else
   pthread_attr_t attr;
   pthread_attr_init(&attr);
#ifdef _UNIX
   pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
#else
   int ds = 1;
   pthread_attr_setdetachstate(&attr,&ds);
#endif
   pthread_t hThread;
   return (pthread_create(&hThread,&attr,ReadConnection,this) == 0);
#endif
  //## end IF::SocketQueue::listen%4024E934008C.body
}

IF::Message* SocketQueue::message (int iBufferLength)
{
  //## begin IF::SocketQueue::message%53879842004C.body preserve=yes
   CriticalSection hCriticalSection;
   Message* pMessage = 0;
   if (Message::getFree() == 0)
      pMessage = new Message(iBufferLength);
   else
   {
      pMessage = Message::getFree();
      Message::setFree(pMessage->getNext());
      pMessage->setNext(0);
      pMessage->reserve(iBufferLength);
   }
   return pMessage;
  //## end IF::SocketQueue::message%53879842004C.body
}

bool SocketQueue::open ()
{
  //## begin IF::SocketQueue::open%3AAA8C3203B6.body preserve=yes
   char szHostName[257];
   gethostname(szHostName,256);
   szHostName[256] = '\0'; // force null termination for Fortify (POSIX.1 does not define if null terminator is added if truncation occurs)
   string strTemp("SocketQueue::open() ");
   strTemp.append(szHostName);
   Trace::put(strTemp.data(),strTemp.length(),true);
   Extract::instance()->getSpec("COUT",strTemp);
   m_bCout = strTemp == "Y";
   m_strName = szHostName;
   char szPort[PERCENTD];
   snprintf(szPort,sizeof(szPort),"%d",m_iPort);
   string strName(Extract::instance()->getName());
   size_t pos = strName.find(' ');
   if (pos != string::npos)
      strName.erase(pos);
   string strHost;
   if (strName == "FM")
      strHost = Extract::instance()->getHost();
   else
   {
      string strAddressSpace;
      Extract::instance()->getAddressSpace(strName,strAddressSpace);
      Extract::instance()->getHost(strAddressSpace,strHost);
   }
   m_strHost = strHost;
   m_pApplicationQueue = this;
   bool b = open(strHost.c_str(),szPort);
   return b;
  //## end IF::SocketQueue::open%3AAA8C3203B6.body
}

bool SocketQueue::open (const char* pszHost, const char* pszPort)
{
  //## begin IF::SocketQueue::open%4E979DD600FF.body preserve=yes
   Trace::put("SocketQueue::open(host,port)",-1,true);
   Trace::put(pszHost,-1,true);
   Trace::put(pszPort,-1,true);
   m_strHost.assign(pszHost);
   if ((m_hServerSocket = socket(AF_INET,SOCK_STREAM,0)) == INVALID_SOCKET)
   {
      char szBuffer[PERCENTD + 32];
      Trace::put(szBuffer,sprintf(szBuffer,"socket() failed: %d",WSAGetLastError()),true);
      return false;
   }
   struct addrinfo hints;
   struct addrinfo* pAddrInfo0 = 0;
   struct addrinfo* pAddrInfo = 0;
   memset(&hints,0,sizeof(hints));
   hints.ai_family = AF_INET;
   hints.ai_socktype = SOCK_STREAM;
   int error = getaddrinfo(pszHost,pszPort,&hints,&pAddrInfo0);
   if (error)
   {
      if (pAddrInfo0)
         freeaddrinfo(pAddrInfo0);
      char szBuffer[PERCENTD + 32];
      Trace::put(szBuffer,sprintf(szBuffer,"getaddrinfo() failed: %d",error),true);
      return false;
   }
   Trace::put("getaddrinfo() results:",-1,true);
   for (struct addrinfo* p = pAddrInfo0;p;p = p->ai_next)
   {
      struct sockaddr_in* pS = (struct sockaddr_in*)p->ai_addr;
      char szAddress[256];
      unsigned char* pC = (unsigned char*)&pS->sin_addr;
      Trace::put(szAddress,snprintf(szAddress,sizeof(szAddress),"%d.%d.%d.%d",(int)*(pC + 0),(int)*(pC + 1),(int)*(pC + 2),(int)*(pC + 3)),true);
      if (!strcmp(pszHost,szAddress))
      {
         m_strAddress = szAddress;
         pAddrInfo = p;
      }
   }
   if (!pAddrInfo)
      pAddrInfo = pAddrInfo0;
#ifdef _UNIX
   int iReusePort = 1;
   if (setsockopt(m_hServerSocket,SOL_SOCKET,SO_REUSEADDR,&iReusePort,sizeof(iReusePort)) == -1)
   {
      freeaddrinfo(pAddrInfo0);
      char szBuffer[PERCENTD + 32];
      Trace::put(szBuffer,sprintf(szBuffer,"setsockopt() failed: %d",WSAGetLastError()),true);
      return false;
   }
#endif
   Trace::put("bind()",-1,true);
   Trace::put(m_strAddress.data(),m_strAddress.length(),true);
   if (bind(m_hServerSocket,pAddrInfo->ai_addr,pAddrInfo->ai_addrlen) == SOCKET_ERROR)
   {
      freeaddrinfo(pAddrInfo0);
      char szBuffer[PERCENTD + 32];
      Trace::put(szBuffer,sprintf(szBuffer,"bind() failed: %d",WSAGetLastError()),true);
      return false;
   }
   freeaddrinfo(pAddrInfo0);
   if (::listen(m_hServerSocket,SOMAXCONN) == SOCKET_ERROR)
   {
      char szBuffer[PERCENTD + 32];
      Trace::put(szBuffer,sprintf(szBuffer,"listen() failed: %d",WSAGetLastError()),true);
      return false;
   }
#ifdef _WIN32
   if (Extract::instance()->getName().substr(2,2) == "CI"
      || Extract::instance()->getName() == "HM     ")
   {
      if (!(m_lThread = _beginthread(PollConnections,0,this)))
         return reportError("_beginthread",0);
   }
   else
   {
      if (!(m_lThread = _beginthread(AcceptConnections,0,this)))
         return reportError("_beginthread",0);
   }
#else
   pthread_attr_t attr;
   pthread_attr_init(&attr);
#ifdef _UNIX
   pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
   if (Extract::instance()->getName().substr(2,2) == "CI"
      || Extract::instance()->getName() == "HM     ")
   {
      if (pthread_create(&m_hThread,&attr,PollConnections,this) != 0)
         return reportError("pthread_create",0);
   }
   else
   {
      if (pthread_create(&m_hThread,&attr,AcceptConnections,this) != 0)
         return reportError("pthread_create",0);
   }
#else
   m_pApplicationQueue = this; // ClientInterface on IBM z/OS
   int ds = 1;
   pthread_attr_setdetachstate(&attr,&ds);
   if (pthread_create(&m_hThread,&attr,AcceptConnections,this) != 0)
      return reportError("pthread_create",0);
#endif
#endif
   IF::Sleep::goTo("00000010");
   return true;
  //## end IF::SocketQueue::open%4E979DD600FF.body
}

bool SocketQueue::poll ()
{
  //## begin IF::SocketQueue::poll%586EA71B0351.body preserve=yes
   char szDate[12] = {"           "};
   char szTime[9] = {"        "};
   if (m_bCout)
   {
      time_t tTime;
      time(&tTime);
      tm *tmTime = localtime(&tTime);
      snprintf(szDate,sizeof(szDate),"%04d%02d%02d%03d",tmTime->tm_year + 1900,tmTime->tm_mon + 1,tmTime->tm_mday,tmTime->tm_yday + 1);
      snprintf(szTime,sizeof(szTime),"%02d%02d%02d00",tmTime->tm_hour,tmTime->tm_min,tmTime->tm_sec);
   }
#ifdef _WIN32
   int iRC = WSAPoll(&(*m_pFDs)[0],m_pFDs->size(),5000);
#endif
#ifdef _UNIX
   int iRC = ::poll(&(*m_pFDs)[0],m_pFDs->size(),5000);
#endif
#ifdef MVS
   int iRC = ::poll(&(*m_pFDs)[0],m_pFDs->size(),100);
#endif
   if (m_bCout)
   {
      CriticalSection hCriticalSection;
      cout << szDate << " " << szTime << " port " << m_iPort << " poll returns " << iRC << " fd count " << m_pFDs->size() << endl;
   }
   if (m_bQuiesced)
      return false;
   if (iRC > 0)
   {
      vector<struct pollfd>::iterator p;
      int k = 0;
      while (k < m_pFDs->size())
      {
         if (m_bCout)
         {
            CriticalSection hCriticalSection;
            cout << "fd " << k << " " << (*m_pFDs)[k].fd << " events " << (*m_pFDs)[k].events << " revents " << (*m_pFDs)[k].revents << endl;
         }
         if (m_bQuiesced)
            return false;
         if ((*m_pFDs)[k].revents & POLLHUP)
         {
            SocketQueue* x = 0;
            {
               CriticalSection hCriticalSection;
               for (map<string,Queue*,less<string> >::iterator q = m_pQueue->begin();q != m_pQueue->end();++q)
               {
                  SocketQueue* r = (SocketQueue*)(*q).second;
                  if (r->getConnectionSocket() == (*m_pFDs)[k].fd)
                  {
                     x = (SocketQueue*)(*q).second;
                     if (m_bCout)
                        cout << "POLLHUP " << (*m_pFDs)[k].fd << x->getName() << " " << x->getRealName() << endl;
                     break;
                  }
               }
            }
            if (x != 0)
            {
               SocketQueue::remove(x);
               (*m_pFDs)[k].fd = 0;
            }
         }
         else
         if ((*m_pFDs)[k].revents & POLLERR)
         {
            SocketQueue* x = 0;
            {
               CriticalSection hCriticalSection;
               for (map<string,Queue*,less<string> >::iterator q = m_pQueue->begin();q != m_pQueue->end();++q)
               {
                  SocketQueue* r = (SocketQueue*)(*q).second;
                  if (r->getConnectionSocket() == (*m_pFDs)[k].fd)
                  {
                     x = (SocketQueue*)(*q).second;
                     if (m_bCout)
                        cout << "POLLERR " << (*m_pFDs)[k].fd << x->getName() << " " << x->getRealName() << endl;
                     break;
                  }
               }
            }
            if (x != 0)
            {
               SocketQueue::remove(x);
               (*m_pFDs)[k].fd = 0;
            }
         }
         else
         if ((*m_pFDs)[k].revents & POLLIN)
         {
            if ((*m_pFDs)[k].fd == m_hServerSocket)
            {
               {
                  CriticalSection hCriticalSection;
                  if (!accept())
                     continue;
               }
               SocketQueue* pConnection = (SocketQueue*)QueueFactory::instance()->create(*(Queue*)this);
               pConnection->setThread(++m_iThread);
               SocketQueue::add((SocketQueue*)pConnection);
               struct pollfd fd;
               fd.fd = pConnection->getConnectionSocket();
               fd.events = POLLIN;
               fd.revents = 0;
               m_pFDs->push_back(fd);
               if (m_bCout)
               {
                  CriticalSection hCriticalSection;
                  cout << "POLLIN accept fd " << fd.fd << " name " << pConnection->getName() << " real name " << pConnection->getRealName() << endl;
               }
            }
            else
            {
               SocketQueue* x = 0;
               {
                  CriticalSection hCriticalSection;
                  for (map<string,Queue*,less<string> >::iterator q = m_pQueue->begin();q != m_pQueue->end();++q)
                  {
                     SocketQueue* r = (SocketQueue*)(*q).second;
                     if (r->getConnectionSocket() == (*m_pFDs)[k].fd)
                     {
                        x = (SocketQueue*)(*q).second;
                        if (m_bCout)
                           cout << "POLLIN receive fd " << (*m_pFDs)[k].fd << " name " << x->getName() << " real name " << x->getRealName();
                        break;
                     }
                   }
               }
               if (x != 0)
               {
                  if (!x->receive())
                  {
                     SocketQueue::remove(x);
                     (*m_pFDs)[k].fd = 0;
                  }
                  else
                  if (m_bCout)
                     cout << " recv success" << endl;
               }
            }
            if (--iRC <= 0)
               break;
         }
         ++k;
      }
      for (p = m_pFDs->begin();p != m_pFDs->end();++p)
      {
         if ((*p).fd == 0)
         {
            m_pFDs->erase(p);
            p = m_pFDs->begin();
         }
      }
   }
   else
   if (iRC != 0)
   {
      int iErrno = WSAGetLastError();
      if (iErrno != EINTR)
         return reportError("poll",iErrno);
   }
   return true;
  //## end IF::SocketQueue::poll%586EA71B0351.body
}

bool SocketQueue::poll (const char* pszName)
{
  //## begin IF::SocketQueue::poll%3F326CCE0138.body preserve=yes
   if (connect())
   {
#ifdef _WIN32
      if (m_lThread = _beginthread(ReadConnection,0,this))
#else
      pthread_attr_t attr;
      pthread_attr_init(&attr);
#ifdef _UNIX
      pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
#else
      int ds = 1;
      pthread_attr_setdetachstate(&attr,&ds);
#endif
      pthread_t hThread;
      if (pthread_create(&hThread,&attr,ReadConnection,this) == 0)
#endif
      {
         CriticalSection hCriticalSection;
         char szName[9] = {"        "};
         int i = strlen(pszName);
         if (i > 8)
            i = 8;
         memcpy(szName,pszName,i);
         if (!m_pQueue)
            m_pQueue = new map<string,Queue*,less<string> >;
         m_pQueue->insert(map<string,Queue*,less<string> >::value_type(szName,this));
         return true;
      }
   }
   return false;
  //## end IF::SocketQueue::poll%3F326CCE0138.body
}

bool SocketQueue::pop ()
{
  //## begin IF::SocketQueue::pop%3EAE7F5C01F4.body preserve=yes
   CriticalSection hCriticalSection;
   if (Message::getFirst() == 0)
   {
#ifdef MVS
      if (m_pApplicationQueue)
      {
         long* pECB = (long*)(m_pApplicationQueue->m_pSignal->getMutex());
         *pECB = 0;
      }
#endif
      return false;
   }
   Message* pFree = Message::getFirst();
   *Message::instance(Message::INBOUND) = *Message::getFirst();
   Message::setFirst(Message::getFirst()->getNext());
   if (Message::getFirst() == 0)
      Message::setLast(0);
   pFree->setNext(Message::getFree());
   Message::setFree(pFree);
   --m_iQueueDepth;
   return true;
  //## end IF::SocketQueue::pop%3EAE7F5C01F4.body
}

void SocketQueue::push (IF::Message* pMessage, reusable::Signal* pSignal)
{
  //## begin IF::SocketQueue::push%538793BC006F.body preserve=yes
   CriticalSection hCriticalSection;
   if (Message::getFirst() == 0)
   {
      Message::setFirst(pMessage);
      if (pSignal)
         pSignal->deliver(-1,1,&m_iQueueDepth);
      m_iQueueDepth = 1;
   }
   else
   {
      Message::getLast()->setNext(pMessage);
      ++m_iQueueDepth;
   }
   Message::setLast(pMessage);
  //## end IF::SocketQueue::push%538793BC006F.body
}

size_t SocketQueue::receive (void* pBuffer, size_t iLength)
{
  //## begin IF::SocketQueue::receive%58B82DCF0302.body preserve=yes
   return recv(m_hConnectionSocket,(char*)pBuffer,iLength,0);
  //## end IF::SocketQueue::receive%58B82DCF0302.body
}

bool SocketQueue::receive ()
{
  //## begin IF::SocketQueue::receive%3AAA9DD80091.body preserve=yes
   switch (m_nInterface)
   {
      case CRLF:
         return receiveCRLF();
      case HTTP:
         return receiveHTTP();
      case NORMAL:
         return receiveNORMAL();
   }
   return receivePOST();
  //## end IF::SocketQueue::receive%3AAA9DD80091.body
}

bool SocketQueue::receiveCRLF ()
{
  //## begin IF::SocketQueue::receiveCRLF%58B81792027B.body preserve=yes
   bool bTimeout = false;
   Message* pMessage = message(MAX_BUFFER_SIZE);
   int m = 0;
   int bytes = 0;
   char* buffer = 0;
#ifdef _WIN32
   int iTimeout = m_iTimeout * 1000; // 30 seconds in milliseconds
   setsockopt(m_hConnectionSocket, SOL_SOCKET,SO_RCVTIMEO,(const char*)&iTimeout,sizeof(int));
#else
   struct timeval tv;
   memset(&tv,0,sizeof(tv));
   tv.tv_sec = m_iTimeout;
   setsockopt(m_hConnectionSocket,SOL_SOCKET,SO_RCVTIMEO,(const char*)&tv,sizeof(struct timeval));
#endif
   do
   {
      buffer = pMessage->buffer() + m;
      bytes = receive(buffer,1);
      if (bytes <= 0)
      {
         int iError = WSAGetLastError();
#ifdef _UNIX
         if (iError == EAGAIN
            || iError == EWOULDBLOCK)
#else
         if (iError == ETIMEDOUT || iError == EAGAIN || iError == EWOULDBLOCK)
#endif
         {
            memcpy(pMessage->buffer(),"TIMEOUT",7);
            m = 7;
            bTimeout = true;
            break;
         }
         if (iError == EINTR)
            continue;
         free(pMessage);
         return reportError("recv",iError);
      }
      m += bytes;
   }
   while (*buffer != 0x0A && m < pMessage->bufferLength());
   pMessage->setSource("");
   if (m)
   {
#ifdef _WIN32
      ::Sleep(1);
#else
      if (!m_strSleep.empty())
         IF::Sleep::goTo(m_strSleep.c_str());
#endif
      pMessage->setMessageLength(m);
      char sCorrelId[32] = {"                        "};
      snprintf(sCorrelId,sizeof(sCorrelId),"%08x%16.0f",m_lThread,m_dTicks);
      pMessage->setCorrelId(sCorrelId);
      push(pMessage,m_pApplicationQueue->m_pSignal);
   }
   else
      free(pMessage);
   if (bTimeout)
      return false;
   return (m != 0);
  //## end IF::SocketQueue::receiveCRLF%58B81792027B.body
}

bool SocketQueue::receiveHTTP ()
{
  //## begin IF::SocketQueue::receiveHTTP%58B8179C0246.body preserve=yes
   Message* pMessage = message(MAX_BUFFER_SIZE);
   int m = 0;
   int bytes = 0;
   char* buffer = 0;
   pMessage->setSource("HTTP");
#ifdef MVS
   fd_set readfds,writefds,exceptfds;
   FD_ZERO(&readfds);
   FD_ZERO(&writefds);
   FD_ZERO(&exceptfds);
   FD_SET(m_hConnectionSocket,&readfds);
   struct timeval tv;
   memset(&tv,0,sizeof(tv));
   tv.tv_sec = m_iTimeout;
   if (select(m_hConnectionSocket + 1,&readfds,&writefds,&exceptfds,&tv) < 1)
   {
      memcpy(pMessage->buffer(),"TIMEOUT",7);
      m = 7;
   }
   else
#endif
#ifdef _WIN32
   int iTimeout = m_iTimeout * 1000; // 30 seconds in milliseconds
   setsockopt(m_hConnectionSocket,SOL_SOCKET,SO_RCVTIMEO,(const char*)&iTimeout,sizeof(int));
#endif
#ifdef _UNIX
   struct timeval tv;
   memset(&tv,0,sizeof(tv));
   tv.tv_sec = m_iTimeout;
   setsockopt(m_hConnectionSocket,SOL_SOCKET,SO_RCVTIMEO,(const char*)&tv,sizeof(struct timeval));
#endif
   {
      char szContentLength[17] = {"Content-Length: "};
      char szcontentlength[17] = {"content-length: "};
#ifdef MVS
      szContentLength[0] = 0x43;
      szContentLength[1] = 0x6F;
      szContentLength[2] = 0x6E;
      szContentLength[3] = 0x74;
      szContentLength[4] = 0x65;
      szContentLength[5] = 0x6E;
      szContentLength[6] = 0x74;
      szContentLength[7] = 0x2D;
      szContentLength[8] = 0x4C;
      szContentLength[9] = 0x65;
      szContentLength[10] = 0x6E;
      szContentLength[11] = 0x67;
      szContentLength[12] = 0x74;
      szContentLength[13] = 0x68;
      szContentLength[14] = 0x3A;
      szContentLength[15] = 0x20;
      szcontentlength[0] = 0x63;
      szcontentlength[1] = 0x6F;
      szcontentlength[2] = 0x6E;
      szcontentlength[3] = 0x74;
      szcontentlength[4] = 0x65;
      szcontentlength[5] = 0x6E;
      szcontentlength[6] = 0x74;
      szcontentlength[7] = 0x2D;
      szcontentlength[8] = 0x6C;
      szcontentlength[9] = 0x65;
      szcontentlength[10] = 0x6E;
      szcontentlength[11] = 0x67;
      szcontentlength[12] = 0x74;
      szcontentlength[13] = 0x68;
      szcontentlength[14] = 0x3A;
      szcontentlength[15] = 0x20;
#endif
      string strContentLength = "Content-Length: ";
      char szTransferEncoding[27] = {"Transfer-Encoding: chunked"};
#ifdef MVS
      szTransferEncoding[0] = 0x54;
      szTransferEncoding[1] = 0x72;
      szTransferEncoding[2] = 0x61;
      szTransferEncoding[3] = 0x6E;
      szTransferEncoding[4] = 0x73;
      szTransferEncoding[5] = 0x66;
      szTransferEncoding[6] = 0x65;
      szTransferEncoding[7] = 0x72;
      szTransferEncoding[8] = 0x2D;
      szTransferEncoding[9] = 0x45;
      szTransferEncoding[10] = 0x6E;
      szTransferEncoding[11] = 0x63;
      szTransferEncoding[12] = 0x6F;
      szTransferEncoding[13] = 0x64;
      szTransferEncoding[14] = 0x69;
      szTransferEncoding[15] = 0x6E;
      szTransferEncoding[16] = 0x67;
      szTransferEncoding[17] = 0x3A;
      szTransferEncoding[18] = 0x20;
      szTransferEncoding[19] = 0x63;
      szTransferEncoding[20] = 0x68;
      szTransferEncoding[21] = 0x75;
      szTransferEncoding[22] = 0x6E;
      szTransferEncoding[23] = 0x6B;
      szTransferEncoding[24] = 0x65;
      szTransferEncoding[25] = 0x64;
#endif
      char szMessage[MAX_BUFFER_SIZE];
      int iPos = 0;
      int iBytesToRead = 0;
      bool bChunked = false;
      vector<string> hTokens;
      while (iPos < MAX_BUFFER_SIZE)
      {
         buffer = szMessage + iPos;
         bytes = receive(buffer,1);
         if (bytes <= 0)
         {
            int iError = WSAGetLastError();
#ifdef _UNIX
            if (iError == EAGAIN
               || iError == EWOULDBLOCK)
#else
            if (iError == ETIMEDOUT || iError == EAGAIN || iError == EWOULDBLOCK)
#endif
            {
               memcpy(pMessage->buffer(),"TIMEOUT",7);
               m = 7;
               break;
            }
            if (iError == EINTR)
               continue;
            if (iError == ECONNRESET)
            {
               memcpy(pMessage->buffer(), "SOCKERR", 7);
               m = 7;
               break;
            }
            free(pMessage);
            return reportError("recv",iError);
         }
         if (*buffer != 0x0D)
            iPos += bytes;
         if (*buffer == 0x0A)
         {
		    if(iPos == 1)  // '/n' is the only value in buffer
                break;     // an empty line (i.e.,a line with nothing preceding the CRLF) indicating the end of the header fields, and possibly a message - body
            string strLine(szMessage,iPos);
            hTokens.push_back(strLine);
            if (hTokens.size() > 32)
            {
               memcpy(pMessage->buffer(),"TIMEOUT",7);
               m = 7;
               break;
            }
            iPos = 0;
            bool bFIS = Extract::instance()->getCustomCode() == "FIS";
            if (strLine.length() > 16
               && (memcmp(strLine.data(), szContentLength, 16) == 0
                  || memcmp(strLine.data(), szcontentlength, 16) == 0))
            {
               iBytesToRead = bFIS ? CodeTable::hexToDouble(strLine.substr(17).c_str()) : atoi(strLine.substr(16).c_str());
               if (iBytesToRead > 0 && bFIS )
                  iBytesToRead++;
            }
            else
            if (iBytesToRead == 0)
               iBytesToRead = bFIS ? CodeTable::hexToDouble(strLine.c_str()) : atoi(strLine.c_str());
            if (strLine.length() >= 26
               && memcmp(strLine.data(),szTransferEncoding,26) == 0)
               bChunked = true;
            if (strLine.length() < 3
               && bChunked)
               break;
         }
      }
      if (bChunked)
      {
         char sTemp[64];
         buffer = szMessage;
         while (true)
         {
            int iOffset = 0;
            int iChunkSize = 0;
            while (true)
            {
               bytes = receive(sTemp + iOffset++,1);
               if (bytes <= 0)
               {
                  int iError = WSAGetLastError();
                  if (iError == EINTR)
                     continue;
                  free(pMessage);
                  return reportError("recv",iError);
               }
               if (sTemp[iOffset - 1] == 0x0A)
               {
                  iChunkSize = charHexToInt(sTemp,iOffset - 2);
                  if (iChunkSize == -1)
                  {
                     free(pMessage);
                     return reportError("recv",-1);
                  }
                  break;
               }
            }
            if (iChunkSize == 0)
               break;
            while (iChunkSize > 0)
            {
               bytes = receive(buffer,iChunkSize);
               if (bytes <= 0)
               {
                  int iError = WSAGetLastError();
                  if (iError == EINTR)
                     continue;
                  free(pMessage);
                  return reportError("recv",iError);
               }
               iChunkSize -= bytes;
               buffer += bytes;
            }
         }
         string strLine(szMessage,buffer - szMessage);
         hTokens.push_back(strLine);
         char* p = pMessage->buffer();
         for (int i = 0;i < hTokens.size();i++)
         {
            memcpy(p,hTokens[i].data(),hTokens[i].length());
            p += hTokens[i].length();
         }
         m = p - pMessage->buffer();
      }
      else
      if (iBytesToRead > 0)
      {
         buffer = szMessage;
         int k = iBytesToRead;
         while (iBytesToRead > 0 && buffer - szMessage + iBytesToRead < MAX_BUFFER_SIZE)
         {
            bytes = receive(buffer,iBytesToRead);
            if (bytes <= 0)
            {
               int iError = WSAGetLastError();
               if (iError == EINTR)
                  continue;
               free(pMessage);
               return reportError("recv",iError);
            }
            iBytesToRead -= bytes;
            buffer += bytes;
         }
         string strLine(szMessage,k);
         trace(strLine.c_str());
         hTokens.push_back(strLine);
         char* p = pMessage->buffer();
         for (int i = 0;i < hTokens.size();i++)
         {
            memcpy(p,hTokens[i].data(),hTokens[i].length());
            p += hTokens[i].length();
         }
         m = p - pMessage->buffer();
      }
   }
   if (m)
   {
#ifdef _WIN32
      ::Sleep(1);
#else
      if (!m_strSleep.empty())
         IF::Sleep::goTo(m_strSleep.c_str());
#endif
      pMessage->setMessageLength(m);
      char sCorrelId[32] = {"                        "};
      snprintf(sCorrelId,sizeof(sCorrelId),"%08x%16.0f",m_lThread,m_dTicks);
      pMessage->setCorrelId(sCorrelId);
      push(pMessage,m_pSignal);
   }
   else
      free(pMessage);
   return false;
  //## end IF::SocketQueue::receiveHTTP%58B8179C0246.body
}

bool SocketQueue::receiveNORMAL ()
{
  //## begin IF::SocketQueue::receiveNORMAL%58B8182200A3.body preserve=yes
   Message* pMessage = message(sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader) + 4);
   int m = 0;
   int bytes = 0;
   char* buffer = 0;
   int total_bytes_rcvd = 0;
   do
   {
      buffer = pMessage->buffer() + total_bytes_rcvd;
      bytes = receive(buffer,8 - total_bytes_rcvd);
      if (bytes <= 0)
      {
         if (bytes < 0)
         {
            int iError = WSAGetLastError();
            if (iError == EINTR)
               continue;
            if (m_bCout)
               cout << " recv failure" << endl;
            free(pMessage);
            return reportError("recv", iError);
         }
         else 
         {  //0 length recv indicating normal close of socket after all data sent by peer
            if (m_bCout)
               cout << " recv normal close" << endl;
            free(pMessage);
            return false;  //force close and removal of socket and fd
         }
      }
      total_bytes_rcvd = total_bytes_rcvd + bytes;
   }
   while (total_bytes_rcvd < 8);
   unsigned short* piLength = (unsigned short*)pMessage->buffer();
   unsigned short* piLength2 = (unsigned short*)pMessage->buffer() + 1; //+ 1 short
   hGDMHeader* pGDMHeader = (hGDMHeader*)pMessage->buffer();
   if (memcmp(pGDMHeader->sDescription,"CNX ",4) == 0)
      m = ntohs(pGDMHeader->siTotalMessageLength);
   else
   if (ntohs(*piLength) == (sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader) - 2)  &&
       ntohs(*piLength2) == (sizeof(struct hStandardHeader) - sizeof(struct hUniqueHeader)))
   {
      do
      {
         buffer = pMessage->buffer() + total_bytes_rcvd;
         bytes = receive(buffer,(sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader) + 2) - total_bytes_rcvd);
         if (bytes <= 0)
         {
            int iError = WSAGetLastError();
            if (iError == EINTR)
               continue;
            free(pMessage);
            return reportError("recv",iError);
         }
         total_bytes_rcvd = total_bytes_rcvd + bytes;
      }
      while (total_bytes_rcvd < (sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader) + 2));
      hUniqueHeader* pUniqueHeader = (hUniqueHeader*)(pMessage->buffer() + sizeof(struct hStandardHeader));
      if (memcmp(pUniqueHeader->sFormat,"02",2) == 0)
      {
         do
         {
            buffer = pMessage->buffer() + total_bytes_rcvd;
            bytes = receive(buffer,(sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader) + 4) - total_bytes_rcvd);
            if (bytes <= 0)
            {
               free(pMessage);
               return reportError("recv",WSAGetLastError());
            }
            total_bytes_rcvd = total_bytes_rcvd + bytes;
         }
         while (total_bytes_rcvd < (sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader) + 4));
         unsigned int* piLength = (unsigned int*)(pMessage->buffer() + (sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader)));
         m = sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader) + 4 + ntohl(*piLength);
      }
      else
      {
         piLength = (unsigned short*)(pMessage->buffer() + (sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader)));
         m = sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader) + 2 + ntohs(*piLength);
      }
      string strName(pMessage->buffer() + sizeof(struct hStandardHeader) - 8,8);
      // !!! ??? m_strName = strName; to force server to create new socket on reply
      pMessage->setSource(strName);
      m_strRealName = strName;
   }
   else
   {
      pMessage->buffer()[8] = '\0';
      for(int i = 0; i < 8; i++)
      {
#ifdef MVS
         pMessage->buffer()[i] = pMessage->buffer()[i] | 0xF0;
#endif
         if(!isdigit(pMessage->buffer()[i]))
         {
            string strTemp;
            CodeTable::nibbleToByte(pMessage->buffer(), 8, strTemp);
            strTemp.insert(0, "receiveNORMAL:error1 length = ");
            trace(strTemp.c_str(), true);
            free(pMessage);
            return false;
         }
      }
      m = atoi(pMessage->buffer());
#ifdef MVS
      for (int i = 0;i < 8;++i)
         pMessage->buffer()[i] = pMessage->buffer()[i] & 0x3F;
#endif
      pMessage->setSource(m_strName);
   }
   if (m <= 0 || m > MAX_INCOMING_MESSAGE_SIZE)
   {
      string strTemp;
      CodeTable::nibbleToByte(pMessage->buffer(), 8, strTemp);
      strTemp.insert(0, "receiveNORMAL:error2 length = ");
      trace(strTemp.c_str(), true);
      free(pMessage);
      return false;
   }
   pMessage->reserve(m);
   while (total_bytes_rcvd < m)
   {
      buffer = pMessage->buffer() + total_bytes_rcvd;
      bytes = receive(buffer,m - total_bytes_rcvd);
      if (bytes <= 0)
      {
         int iError = WSAGetLastError();
         if (iError == EINTR)
            continue;
         free(pMessage);
         return reportError("recv",iError);
      }
      total_bytes_rcvd = total_bytes_rcvd + bytes;
   }
   if (m)
   {
#ifdef _WIN32
      ::Sleep(1);
#else
      if (!m_strSleep.empty())
         IF::Sleep::goTo(m_strSleep.c_str());
#endif
      pMessage->setMessageLength(m);
      char sCorrelId[32] = {"                        "};
      snprintf(sCorrelId,sizeof(sCorrelId),"%08x%16.0f",m_lThread,m_dTicks);
      pMessage->setCorrelId(sCorrelId);
      push(pMessage,m_pApplicationQueue->m_pSignal);
   }
   else
      free(pMessage);
   return (m != 0);
  //## end IF::SocketQueue::receiveNORMAL%58B8182200A3.body
}

bool SocketQueue::receivePOST ()
{
  //## begin IF::SocketQueue::receivePOST%58B817AA0084.body preserve=yes
   bool bTimeout = false;
   bool bSockErr = false;
   Message* pMessage = message(MAX_BUFFER_SIZE);
   int m = 0;
   int bytes = 0;
   char* buffer = 0;
   pMessage->setSource("POST");
#ifdef MVS
   fd_set readfds,writefds,exceptfds;
   FD_ZERO(&readfds);
   FD_ZERO(&writefds);
   FD_ZERO(&exceptfds);
   FD_SET(m_hConnectionSocket,&readfds);
   struct timeval tv;
   memset(&tv,0,sizeof(tv));
   tv.tv_sec = m_iTimeout;
   if (select(m_hConnectionSocket + 1,&readfds,&writefds,&exceptfds,&tv) < 1)
   {
      memcpy(pMessage->buffer(),"TIMEOUT",7);
      m = 7;
   }
   else
#endif
#ifdef _WIN32
   int iTimeout = m_iTimeout * 1000; // 30 seconds in milliseconds
   setsockopt(m_hConnectionSocket,SOL_SOCKET,SO_RCVTIMEO,(const char*)&iTimeout,sizeof(int));
#endif
#ifdef _UNIX
   struct timeval tv;
   memset(&tv,0,sizeof(tv));
   tv.tv_sec = m_iTimeout;
   setsockopt(m_hConnectionSocket,SOL_SOCKET,SO_RCVTIMEO,(const char*)&tv,sizeof(struct timeval));
#endif
   {
      char szContentLength[17] = {"Content-Length: "};
      char szcontentlength[17] = {"content-length: "};
#ifdef MVS
      szContentLength[0] = 0x43;
      szContentLength[1] = 0x6F;
      szContentLength[2] = 0x6E;
      szContentLength[3] = 0x74;
      szContentLength[4] = 0x65;
      szContentLength[5] = 0x6E;
      szContentLength[6] = 0x74;
      szContentLength[7] = 0x2D;
      szContentLength[8] = 0x4C;
      szContentLength[9] = 0x65;
      szContentLength[10] = 0x6E;
      szContentLength[11] = 0x67;
      szContentLength[12] = 0x74;
      szContentLength[13] = 0x68;
      szContentLength[14] = 0x3A;
      szContentLength[15] = 0x20;
      szcontentlength[0] = 0x63;
      szcontentlength[1] = 0x6F;
      szcontentlength[2] = 0x6E;
      szcontentlength[3] = 0x74;
      szcontentlength[4] = 0x65;
      szcontentlength[5] = 0x6E;
      szcontentlength[6] = 0x74;
      szcontentlength[7] = 0x2D;
      szcontentlength[8] = 0x6C;
      szcontentlength[9] = 0x65;
      szcontentlength[10] = 0x6E;
      szcontentlength[11] = 0x67;
      szcontentlength[12] = 0x74;
      szcontentlength[13] = 0x68;
      szcontentlength[14] = 0x3A;
      szcontentlength[15] = 0x20;
#endif
      char szMessage[MAX_BUFFER_SIZE];
      int iPos = 0;
      int iBytesToRead = 0;
      vector<string> hTokens;
      while (iPos < MAX_BUFFER_SIZE)
      {
         buffer = szMessage + iPos;
         bytes = receive(buffer,1);
         if (bytes <= 0)
         {
            IF::Sleep::goTo("00000100"); // !!! not sure on this
          //  return true; // !!! SSL_READ is not blocking on no input
            int iError = WSAGetLastError();
#ifdef _UNIX
            if (iError == EAGAIN
               || iError == EWOULDBLOCK)
#else
            if (iError == ETIMEDOUT || iError == EAGAIN || iError == EWOULDBLOCK)
#endif
            {
               memcpy(pMessage->buffer(),"TIMEOUT",7);
               m = 7;
               bTimeout = true;
               break;
            }
            if (iError == EINTR)
               continue;
            if (iError == ECONNRESET)
            {
               memcpy(pMessage->buffer(), "SOCKERR", 7);
               m = 7;
               bSockErr = true;
               break;
            }

            free(pMessage);
            return reportError("recv",iError);
         }
         if (*buffer != 0x0D && *buffer != 0x0A)
            iPos += bytes;
         if (*buffer == 0x0A)
         {
            if (iPos == 0)
               break;
            string strLine(szMessage,iPos);
            trace(strLine.c_str());
            if (hTokens.empty()
               && iPos > 7 
               && strLine.length() > 8
               && (memcmp(strLine.data(),"POST /",6) == 0
               || memcmp(strLine.data(),"GET /",5) == 0
               || memcmp(strLine.data(),"PUT /",5) == 0
               || memcmp(strLine.data(),"DELETE /",8) == 0
               || memcmp(strLine.data(),"OPTIONS /",9) == 0))
            {
               string strDestination(strLine.data() + 5,strLine.length() - 5);
               size_t pos = strDestination.find(' ');
               if (pos != string::npos)
                  strDestination.erase(pos);
               pMessage->setDestination(strDestination);
            }
            hTokens.push_back(strLine);
            if (hTokens.size() > 20)
            {
               memcpy(pMessage->buffer(),"TIMEOUT",7);
               m = 7;
               break;
            }
            iPos = 0;
            if (strLine.length() > 16
               && (memcmp(strLine.data(),szContentLength,16) == 0
               || memcmp(strLine.data(),szcontentlength,16) == 0))
               iBytesToRead = atoi(strLine.substr(16).c_str());
         }
      }
      {
         hTokens.push_back(string("\n"));
         buffer = szMessage;
         int k = iBytesToRead;
         while (iBytesToRead > 0 && buffer - szMessage + iBytesToRead < MAX_BUFFER_SIZE)
         {
            bytes = receive(buffer,iBytesToRead);
            if (bytes <= 0)
            {
               int iError = WSAGetLastError();
               if (iError == EINTR)
                  continue;
               free(pMessage);
               return reportError("recv",iError);
            }
            iBytesToRead -= bytes;
            buffer += bytes;
         }
         string strLine(szMessage,k);
         trace(strLine.c_str());
         hTokens.push_back(strLine);
         char* p = pMessage->buffer();
         for (int i = 0;i < hTokens.size();i++)
         {
            if (i > 0)
            {
               *p = '\n';
               ++p;
            }
            memcpy(p,hTokens[i].data(),hTokens[i].length());
            p += hTokens[i].length();
         }
         m = p - pMessage->buffer();
      }
   }
   if (m)
   {
#ifdef _WIN32
      ::Sleep(1);
#else
      if (!m_strSleep.empty())
         IF::Sleep::goTo(m_strSleep.c_str());
#endif
      pMessage->setMessageLength(m);
      char sCorrelId[32] = {"                        "};
      snprintf(sCorrelId,sizeof(sCorrelId),"%08x%16.0f",m_lThread,m_dTicks);
      pMessage->setCorrelId(sCorrelId);
      push(pMessage,m_pApplicationQueue->m_pSignal);
   }
   else
      free(pMessage);
   if (bTimeout || bSockErr)
      return false;
   return (m != 0);
  //## end IF::SocketQueue::receivePOST%58B817AA0084.body
}

void SocketQueue::remove (SocketQueue* pSocketQueue)
{
  //## begin IF::SocketQueue::remove%3AB37E6E01A5.body preserve=yes
   string strName(pSocketQueue->getRealName());
   CriticalSection hCriticalSection;
   delete pSocketQueue;
   map<string,Queue*,less<string> >::iterator p = m_pQueue->find(strName);
   if (p != m_pQueue->end())
      (*p).second->close();
  //## end IF::SocketQueue::remove%3AB37E6E01A5.body
}

bool SocketQueue::reportError (const char* pszFunction, int lRC)
{
  //## begin IF::SocketQueue::reportError%3AAAA43602E4.body preserve=yes
   char* pszBuffer = new_char((PERCENTD + 27),strlen(pszFunction));
   if (pszBuffer == 0)
      return false;
   snprintf(pszBuffer, (PERCENTD + 27) + strlen(pszFunction), "SocketQueue::reportError %s %d", pszFunction, lRC);
   trace(pszBuffer,true);
   delete [] pszBuffer;
   return false;
  //## end IF::SocketQueue::reportError%3AAAA43602E4.body
}

size_t SocketQueue::send (void* pBuffer, size_t iLength)
{
  //## begin IF::SocketQueue::send%58B83A9E03E4.body preserve=yes
/*
#ifdef _UNIX
   //Set non-blocking mode
   int flags = fcntl(m_hConnectionSocket, F_GETFL);
   int result = fcntl(m_hConnectionSocket, F_SETFL, flags & ~O_NONBLOCK);
#endif
#ifdef _WIN32
   //Set non-blocking mode
   unsigned long ul = 1;
   int ret = ioctlsocket(m_hConnectionSocket, FIONBIO, (unsigned long *)&ul); 
#endif
*/
   return ::send(m_hConnectionSocket,(char*)pBuffer,iLength,0);
  //## end IF::SocketQueue::send%58B83A9E03E4.body
}

bool SocketQueue::send (Message* pMessage, enum MessageType nMessageType)
{
  //## begin IF::SocketQueue::send%3AAA8C62008A.body preserve=yes
   trace("SocketQueue::send");
   if (m_iPort == 65535)
      return false;
   if (m_hConnectionSocket == -1)
   {
      if (!connect())
         return false;
      IF::Sleep::goTo("00000010");
   }
   unsigned int j = 0;
   char * p = 0;
   unsigned short* piLength = (unsigned short*)pMessage->buffer();
   hGDMHeader* pGDMHeader = (hGDMHeader*)pMessage->buffer();
   if (m_nInterface == POST)
   {
      if (pMessage->messageLength() < 222)
         return false;
      string strText(pMessage->buffer() + 222,pMessage->messageLength() - 222);
      trace(strText.c_str());
      send((void*)strText.data(),strText.length());
      return true;
   }
   else
   if (m_nInterface == CRLF || m_nInterface == HTTP)
   {
      if(Extract::instance()->getCustomCode() != "FIS")
      {
         j = pMessage->dataLength();
         p = pMessage->buffer() +  pMessage->messageLength() - pMessage->dataLength();
      }
   }  
   else
   if (memcmp(pGDMHeader->sDescription,"CNX ",4) == 0)
     ;
   else
   if (ntohs(*piLength) == (sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader) - 2))
   {
      memset(pMessage->buffer() + sizeof(struct hStandardHeader) - 8,' ',8);
      memcpy(pMessage->buffer() + sizeof(struct hStandardHeader) - 8,Extract::instance()->getName().data(),Extract::instance()->getName().length());
   }
   else
   {
      *(pMessage->buffer() + pMessage->messageLength()) = '\0';
      char szTemp[PERCENTD];
      snprintf(szTemp,sizeof(szTemp),"%08d",pMessage->messageLength());
#ifdef MVS
      CodeTable::translate(szTemp,8,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
      if (memcmp(szTemp,pMessage->buffer(),8) != 0)
      {
         snprintf(szTemp,sizeof(szTemp),"%08d",pMessage->messageLength() + 8);
#ifdef MVS
         CodeTable::translate(szTemp,8,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
         j = 8;
         p = szTemp;
#ifdef _WIN32
         DWORD dwTimeout = m_iTimeout * 1000; // 30 seconds in milliseconds
         setsockopt(m_hConnectionSocket, SOL_SOCKET, SO_SNDTIMEO, (const char*)&dwTimeout, sizeof(DWORD));
#else
         struct timeval tv;
         memset(&tv,0,sizeof(tv));
         tv.tv_sec = m_iTimeout;
         setsockopt(m_hConnectionSocket,SOL_SOCKET,SO_SNDTIMEO,(const char*)&tv,sizeof(struct timeval));
#endif
         if (!sendPacket(p, j))
            return false;
      }
   }
   if( j == 0 )
   {
      j = pMessage->messageLength();
      p = pMessage->buffer();
   }
#ifdef _WIN32

   DWORD dwTimeout = m_iTimeout*1000; // 30 seconds in milliseconds
   setsockopt(m_hConnectionSocket, SOL_SOCKET,SO_SNDTIMEO,(const char*)&dwTimeout,sizeof(DWORD));
#else
   struct timeval tv;
   memset(&tv,0,sizeof(tv));
   tv.tv_sec = m_iTimeout;
   setsockopt(m_hConnectionSocket,SOL_SOCKET,SO_SNDTIMEO,(const char*)&tv,sizeof(struct timeval));
#endif
   return sendPacket(p,j);
  //## end IF::SocketQueue::send%3AAA8C62008A.body
}

void SocketQueue::setThread (int lThread)
{
  //## begin IF::SocketQueue::setThread%3AB66502039F.body preserve=yes
   char szTemp[PERCENTD+9];
   snprintf(szTemp,sizeof(szTemp),"%d        ",lThread);
   szTemp[8] = '\0';
   m_strName = szTemp;
   m_strRealName = szTemp;
   trace("SocketQueue::setThread");
#ifndef MVS
   m_pSignal->deliver(lThread,0);
#endif
   m_lThread = lThread;
  //## end IF::SocketQueue::setThread%3AB66502039F.body
}

void SocketQueue::terminate ()
{
  //## begin IF::SocketQueue::terminate%3DC97163036B.body preserve=yes
#ifdef _WIN32
   WSACleanup();
#endif
  //## end IF::SocketQueue::terminate%3DC97163036B.body
}

void SocketQueue::trace (int lPosition)
{
  //## begin IF::SocketQueue::trace%3DCA7A89006D.body preserve=yes
   trace("");
  //## end IF::SocketQueue::trace%3DCA7A89006D.body
}

void SocketQueue::trace (const char* pszMethod, bool bCritical)
{
  //## begin IF::SocketQueue::trace%3D6A62C800FA.body preserve=yes
   #ifndef MVS
   if (getName().empty()
      || m_pApplicationQueue == 0
      || (Trace::getEnable() == false && bCritical == false))
      return;
   char szTemp[256];
   int iLen = snprintf(szTemp,sizeof(szTemp),"%08x %d <%s> <%s> %d %d %hd %s",
#ifdef _WIN64
      (long long)this,
#else
      (long)this,
#endif
      m_lThread,
      getName().c_str(),
      getRealName().c_str(),
      m_hServerSocket,
      m_hConnectionSocket,
      m_iPort,
      pszMethod);
   Message* pMessage = message(sizeof(struct hGDMHeader) + iLen);
   pMessage->setSource("");
   hGDMHeader* pGDMHeader = (hGDMHeader*)(char*)pMessage->buffer();
   memcpy(pGDMHeader->sDescription,"CNX ",4);
   pGDMHeader->siDataElement1 = htons(0);
   memcpy(pGDMHeader->sData1,"TRACE   ",8);
   pGDMHeader->siDataLength1 = htons(8);
   pGDMHeader->siDataElement2 = htons(0);
   memset(pGDMHeader->sData2,' ',24);
   if (!bCritical)
   {
      memcpy(pGDMHeader->sData2,"WRITE",5);
      pGDMHeader->siDataLength2 = htons(5);
   }
   else
   {
      memcpy(pGDMHeader->sData2,"WRITEC",6);
      pGDMHeader->siDataLength2 = htons(6);
   }
   memcpy((char*)pGDMHeader + sizeof(struct hGDMHeader) - 44,szTemp,iLen);
   pGDMHeader->siTotalMessageLength = htons(sizeof(struct hGDMHeader) - 44 + iLen);
   pMessage->setMessageLength(sizeof(struct hGDMHeader) - 44 + iLen);
   push(pMessage,m_pApplicationQueue->m_pSignal);
#endif
  //## end IF::SocketQueue::trace%3D6A62C800FA.body
}

void SocketQueue::update (Subject* pSubject)
{
  //## begin IF::SocketQueue::update%3AAA8C670055.body preserve=yes
#ifdef MVS
   if (pop())
   {
      Message::instance(Message::INBOUND)->identifyBuffer();
      Message::instance(Message::INBOUND)->notify();
      if (getQueueDepth() == 0)
      {
         long* pECB = (long*)m_pSignal->getMutex();
         *pECB = 0;
      }
      else
         m_pSignal->deliver();
   }
#endif
  //## end IF::SocketQueue::update%3AAA8C670055.body
}

//## Get and Set Operations for Class Attributes (implementation)

const string& SocketQueue::getAddress ()
{
  //## begin IF::SocketQueue::getAddress%464380F201A5.get preserve=no
  return m_strAddress;
  //## end IF::SocketQueue::getAddress%464380F201A5.get
}

// Additional Declarations
  //## begin IF::SocketQueue%3AAA88A20102.declarations preserve=yes
bool SocketQueue::sendPacket(char* p, int j)
{
   int iRetryCount = -1;
   while (j > 0)
   {
      int i = send(p, j);
      if (i == j)
         break;
      if (i == SOCKET_ERROR)
      {
         int iError = WSAGetLastError();
         reportError("send", iError);
         if (iError == ETIMEDOUT)
            return false;
         if (!m_strHost.empty())
         {
            if (m_hConnectionSocket != -1)
               closesocket(m_hConnectionSocket);
            m_hConnectionSocket = -1;
            if (!connect())
               return false;
            i = send(p, j);
            if (i == SOCKET_ERROR)
               return reportError("send", WSAGetLastError());
            if (i < j)
            {
               reportProgress(i, j);
               j -= i;
               p += i;
               continue;
            }
            return true;
         }
         if (iError != EAGAIN && iError != EWOULDBLOCK && iError != 10035) //10035 is windows WSAEWOULDBLOCK
            return false;
         if (iRetryCount < 0)
            iRetryCount = initRetryCount();
         if (iRetryCount == 0)
            return reportError("send abort", iError);
         Sleep::goTo("00000100");
         iRetryCount--;
      }
      else if (i < j)
      {
         reportProgress(i, j);
         Sleep::goTo("00000100");
         j -= i;
         p += i;
         iRetryCount = -1;
      }
   }
   return true;
}
bool SocketQueue::reportProgress(int iSent, int iTotal)
{
   char pszBuffer[2*PERCENTD + 23];
   snprintf(pszBuffer,sizeof(pszBuffer), "SocketQueue::send %d of %d", iSent, iTotal);
   trace(pszBuffer, true);
   return true;
}
int SocketQueue::initRetryCount()
{
   if (m_iRetryCount == -1)
   {
      string strRetryCount;
      Extract::instance()->getRecord("DSPEC   IF39    RETRYCOUNT~", strRetryCount);
      if (strRetryCount.length() > 27)
         m_iRetryCount = atoi(strRetryCount.substr(27).c_str());
      else if (Extract::instance()->getName().substr(2, 2) == "CI")
         m_iRetryCount = 10;
      else
         m_iRetryCount = 0;
   }
   return m_iRetryCount;
}
  //## end IF::SocketQueue%3AAA88A20102.declarations

} // namespace IF

//## begin module%3AAA898D03C6.epilog preserve=yes
//## end module%3AAA898D03C6.epilog
