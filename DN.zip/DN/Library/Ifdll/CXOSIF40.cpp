//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3AAA89DF00FD.cm preserve=no
//	$Date:   Apr 05 2018 15:48:24  $ $Author:   e1009652  $ $Revision:   1.6  $
//## end module%3AAA89DF00FD.cm

//## begin module%3AAA89DF00FD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3AAA89DF00FD.cp

//## Module: CXOSIF40%3AAA89DF00FD; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.8A.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF40.cpp

//## begin module%3AAA89DF00FD.additionalIncludes preserve=no
//## end module%3AAA89DF00FD.additionalIncludes

//## begin module%3AAA89DF00FD.includes preserve=yes
// $Date:   Apr 05 2018 15:48:24  $ $Author:   e1009652  $ $Revision:   1.6  $
//## end module%3AAA89DF00FD.includes

#ifndef CXOSIF39_h
#include "CXODIF39.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOSIF40_h
#include "CXODIF40.hpp"
#endif


//## begin module%3AAA89DF00FD.declarations preserve=no
//## end module%3AAA89DF00FD.declarations

//## begin module%3AAA89DF00FD.additionalDeclarations preserve=yes
#ifndef CXOSIF81_h
#include "CXODIF81.hpp"
#endif
#include <typeinfo>
#define CLASSES 3

const char* pszSocketQueueClass[CLASSES] =
{
   "Queue",
   "Signal",
   "SecureQueue"
};
//## end module%3AAA89DF00FD.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::SocketQueueFactory 

SocketQueueFactory::SocketQueueFactory()
  //## begin SocketQueueFactory::SocketQueueFactory%3AAA88E40048_const.hasinit preserve=no
  //## end SocketQueueFactory::SocketQueueFactory%3AAA88E40048_const.hasinit
  //## begin SocketQueueFactory::SocketQueueFactory%3AAA88E40048_const.initialization preserve=yes
  //## end SocketQueueFactory::SocketQueueFactory%3AAA88E40048_const.initialization
{
  //## begin IF::SocketQueueFactory::SocketQueueFactory%3AAA88E40048_const.body preserve=yes
   memcpy(m_sID,"IF40",4);
   string strClass;
   for (int m = 0;m < CLASSES;++m)
   {
      strClass = pszSocketQueueClass[m];
      m_hClasses.insert(map<string,int,less<string> >::value_type(strClass,m));
   }
  //## end IF::SocketQueueFactory::SocketQueueFactory%3AAA88E40048_const.body
}


SocketQueueFactory::~SocketQueueFactory()
{
  //## begin IF::SocketQueueFactory::~SocketQueueFactory%3AAA88E40048_dest.body preserve=yes
   m_hClasses.erase(m_hClasses.begin(),m_hClasses.end());
  //## end IF::SocketQueueFactory::~SocketQueueFactory%3AAA88E40048_dest.body
}



//## Other Operations (implementation)
Object* SocketQueueFactory::create (const char* pszClass, const char* pszValue)
{
  //## begin IF::SocketQueueFactory::create%3AAA890501D6.body preserve=yes
   string strClass(pszClass);
   map<string,int,less<string> >::iterator pClass = m_hClasses.find(strClass);
   if (pClass == m_hClasses.end())
      return 0;
   switch ((*pClass).second)
   {
      case 0:
         return new SocketQueue(pszValue);
      case 1:
         return new Signal(pszValue);
      case 2:
         return new SecureSocketQueue(pszValue);
   }
   return 0;
  //## end IF::SocketQueueFactory::create%3AAA890501D6.body
}

Queue* SocketQueueFactory::create (const Queue& hQueue)
{
  //## begin IF::SocketQueueFactory::create%5ABD481D01EB.body preserve=yes
   string strClassName = typeid(hQueue).name();
   if (strClassName.find("SecureSocketQueue") != string::npos) //On Windows strClassName = "class IF::SecureSocketQueue")
      return new SecureSocketQueue(dynamic_cast<const SecureSocketQueue&> (hQueue));
   else
      return new SocketQueue(dynamic_cast<const SocketQueue&> (hQueue));
  //## end IF::SocketQueueFactory::create%5ABD481D01EB.body
}

// Additional Declarations
  //## begin IF::SocketQueueFactory%3AAA88E40048.declarations preserve=yes
  //## end IF::SocketQueueFactory%3AAA88E40048.declarations

} // namespace IF

//## begin module%3AAA89DF00FD.epilog preserve=yes
//## end module%3AAA89DF00FD.epilog
