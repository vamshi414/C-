// Copyright (c) 1998 - 2007
// eFunds Corporation
// $Date:   Dec 28 2006 11:04:40  $ $Author:   D02405  $ $Revision:   1.5  $

#ifndef CXODIF19_HPP
#define CXODIF19_HPP

#ifndef MVS
#pragma pack(push)
#endif
#pragma pack(1)

struct CloseArchiveBlock
{
   char sBlockID[4];
   char sVersion[4];
   int lLength;
};

struct CloseSessionBlock
{
   char sBlockID[4];
   char sVersion[4];
   int lLength;
};

struct GetRecordBlock
{
   char sBlockID[4];
   char sVersion[4];
   int lLength;
   char sRequestedSectionCode[30];
   char sRequestedSectionQualifier[15];
   char sFiller1[3];
   int lRequestedPageNumber;
   char sReturnedSectionCode[30];
   char sReturnedSectionQualifier[15];
   char sFiller2[3];
   int lPageWithinQualifiedSection;
   int lPageWithinSectionCode;
   short siNbrOfColsPerLine;
   short siNbrOfLinesInPage;
   int lPageDataLength;
   char sDataType[1];
   char sFiller3[91];
};

struct OpenArchiveBlock
{
   char sBlockID[4];
   char sVersion[4];
   int lLength;
   char sArchiveID[10];
   char sFiller[1];
   char sMediaSelectCode[1];
   int lMaxPageSize;
   char sRequestedVersionID[14];
   char sOpenedVersionID[14];
   int lNumHighIndexBuffers;
   int lNumLowIndexBuffers;
};

struct OpenSessionBlock_0610
{
   char sBlockID[4];
   char sVersion[4];
   int lLength;
   char sServerID[30];
   char sUserID[10];
   char sPassword[8];
   char sReceipientID[10];
   short siServerWarningLevel;
};

struct OpenSessionBlock
{
   char sBlockID[4];
   char sVersion[4];
   int lLength;
   char sServerID[30];
   char sFiller1[2];
   char sUserID[10];
   char sPassword[8];
   char sFiller2[2];
   int lSecInfoType;
   int lSecInfoAddr;
   int lSecInfoLen;
   char sReceipientID[10];
   short siServerWarningLevel;
   int lAccessPermissions;
};

#ifdef MVS
#pragma pack(reset)
#else
#pragma pack(pop)
#endif

#endif
