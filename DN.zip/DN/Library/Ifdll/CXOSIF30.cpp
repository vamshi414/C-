//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%36DAA3820164.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DAA3820164.cm

//## begin module%36DAA3820164.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DAA3820164.cp

//## Module: CXOSIF30%36DAA3820164; Package body
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXOSIF30.cpp

//## begin module%36DAA3820164.additionalIncludes preserve=no
//## end module%36DAA3820164.additionalIncludes

//## begin module%36DAA3820164.includes preserve=yes
//## end module%36DAA3820164.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF30_h
#include "CXODIF30.hpp"
#endif


//## begin module%36DAA3820164.declarations preserve=no
//## end module%36DAA3820164.declarations

//## begin module%36DAA3820164.additionalDeclarations preserve=yes
#include "CXODIF13.hpp"
#include "CXODIF03.hpp"
//## end module%36DAA3820164.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::MDSQueue

MDSQueue::MDSQueue()
  //## begin MDSQueue::MDSQueue%36DA9F6D03E2_const.hasinit preserve=no
  //## end MDSQueue::MDSQueue%36DA9F6D03E2_const.hasinit
  //## begin MDSQueue::MDSQueue%36DA9F6D03E2_const.initialization preserve=yes
  //## end MDSQueue::MDSQueue%36DA9F6D03E2_const.initialization
{
  //## begin IF::MDSQueue::MDSQueue%36DA9F6D03E2_const.body preserve=yes
   memcpy(m_sID,"IF30",4);
  //## end IF::MDSQueue::MDSQueue%36DA9F6D03E2_const.body
}

MDSQueue::MDSQueue (const char* pszName)
  //## begin IF::MDSQueue::MDSQueue%36DE94140383.hasinit preserve=no
  //## end IF::MDSQueue::MDSQueue%36DE94140383.hasinit
  //## begin IF::MDSQueue::MDSQueue%36DE94140383.initialization preserve=yes
   : Queue(pszName)
  //## end IF::MDSQueue::MDSQueue%36DE94140383.initialization
{
  //## begin IF::MDSQueue::MDSQueue%36DE94140383.body preserve=yes
   memcpy(m_sID,"IF30",4);
   if (m_strName.length() < 8)
      m_strName.append("        ",8 - m_strName.length());
   string strTemp("DQUEUE  ");
   strTemp += m_strName;
   IString strRealName;
   if (Extract::instance()->get(strTemp.c_str(),strRealName))
      m_strRealName.assign((char*)strRealName + 16,8);
   else
      m_strRealName = m_strName;
  //## end IF::MDSQueue::MDSQueue%36DE94140383.body
}


MDSQueue::~MDSQueue()
{
  //## begin IF::MDSQueue::~MDSQueue%36DA9F6D03E2_dest.body preserve=yes
  //## end IF::MDSQueue::~MDSQueue%36DA9F6D03E2_dest.body
}



//## Other Operations (implementation)
bool MDSQueue::close ()
{
  //## begin IF::MDSQueue::close%36DE8B5A02F5.body preserve=yes
   return true;
  //## end IF::MDSQueue::close%36DE8B5A02F5.body
}

int MDSQueue::getQueueDepth ()
{
  //## begin IF::MDSQueue::getQueueDepth%3EB928B402DE.body preserve=yes
   int iQueueDepth = 0;
   int iRC = 0;
#ifdef MVS
   CXQDEP(&iQueueDepth,&iRC);
#endif
   return iQueueDepth;
  //## end IF::MDSQueue::getQueueDepth%3EB928B402DE.body
}

bool MDSQueue::open ()
{
  //## begin IF::MDSQueue::open%36DE8B5E0323.body preserve=yes
   return true;
  //## end IF::MDSQueue::open%36DE8B5E0323.body
}

bool MDSQueue::send (Message* pMessage, enum MessageType nMessageType)
{
  //## begin IF::MDSQueue::send%36DE8B6301AD.body preserve=yes
   int lRC = 0;
#ifdef MVS
   int n = 0;
   int m = (int)m_strRealName.length();
   if (m > 8)
      CXSONL(&m,&n);
   int lMessageLength = pMessage->messageLength();
   CXQPUT(pMessage->buffer(),m_strRealName.data(),&lMessageLength,&lRC);
   m = 8;
   CXSONL(&m,&n);
#endif
   return (lRC == 0);
  //## end IF::MDSQueue::send%36DE8B6301AD.body
}

void MDSQueue::update (reusable::Subject* pSubject)
{
  //## begin IF::MDSQueue::update%36DC65E6030C.body preserve=yes
   char szQueueName[9] = {"        "};
   int lBufferLength = Message::instance(Message::INBOUND)->bufferLength();
   int lMessageLength = 0;
   int lRC = 0;
#ifdef MVS
   CXQGET(Message::instance(Message::INBOUND)->buffer(),szQueueName,&lBufferLength,&lMessageLength,&lRC);
   if (lRC == 17)
   {
      Message::instance(Message::INBOUND)->reserve(lMessageLength);
      lBufferLength = Message::instance(Message::INBOUND)->bufferLength();
      CXQGET(Message::instance(Message::INBOUND)->buffer(),szQueueName,&lBufferLength,&lMessageLength,&lRC);
   }
#endif
   if (lRC == 0)
   {
      Message::instance(Message::INBOUND)->setSource(szQueueName);
      Message::instance(Message::INBOUND)->setDestination(m_strRealName);
      Message::instance(Message::INBOUND)->setMessageLength(lMessageLength);
      Message::instance(Message::INBOUND)->identifyBuffer();
      Message::instance(Message::INBOUND)->notify();
   }
  //## end IF::MDSQueue::update%36DC65E6030C.body
}

// Additional Declarations
  //## begin IF::MDSQueue%36DA9F6D03E2.declarations preserve=yes
  //## end IF::MDSQueue%36DA9F6D03E2.declarations

} // namespace IF

//## begin module%36DAA3820164.epilog preserve=yes
//## end module%36DAA3820164.epilog
