//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3626582A03A7.cm preserve=no
//	$Date:   May 15 2020 09:01:12  $ $Author:   e1009510  $ $Revision:   1.22  $
//## end module%3626582A03A7.cm

//## begin module%3626582A03A7.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3626582A03A7.cp

//## Module: CXOSIF02%3626582A03A7; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF02.cpp

//## begin module%3626582A03A7.additionalIncludes preserve=no
//## end module%3626582A03A7.additionalIncludes

//## begin module%3626582A03A7.includes preserve=yes
#include "CXODIF12.hpp"
//## end module%3626582A03A7.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU37_h
#include "CXODRU37.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif


//## begin module%3626582A03A7.declarations preserve=no
//## end module%3626582A03A7.declarations

//## begin module%3626582A03A7.additionalDeclarations preserve=yes
#ifdef MVS
extern "OS"
{
int CXLOG(const char* psBuffer,int* piBufferLength,
   const char* psCBEKey,const char* psMessageID,const char* psReason,
   const char* psDestination,const char* psStation,const char* psLUName,
   int* plRC);
}
#endif

struct LogHeader
{
   double dTicks;
   char sProcessName[8];
   char sMessageID[5];
   char cRetry;
   char sReason[18];
   char sStation[8];
   char sLUName[8];
   char cFlag;
   char sFiller[7];
};
//## end module%3626582A03A7.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Log

//## begin IF::Log::Enable%586FAF06004B.attr preserve=no  private: static short {V} -1
short Log::m_siEnable = -1;
//## end IF::Log::Enable%586FAF06004B.attr

//## begin IF::Log::PriCustLogger%3FAEBD390028.attr preserve=no  public: static string {U}
string Log::m_strPriCustLogger;
//## end IF::Log::PriCustLogger%3FAEBD390028.attr

//## begin IF::Log::SecCustLogger%3FAEBD5102CB.attr preserve=no  public: static string {U}
string Log::m_strSecCustLogger;
//## end IF::Log::SecCustLogger%3FAEBD5102CB.attr

Log::Log()
  //## begin Log::Log%34626247038B_const.hasinit preserve=no
  //## end Log::Log%34626247038B_const.hasinit
  //## begin Log::Log%34626247038B_const.initialization preserve=yes
  //## end Log::Log%34626247038B_const.initialization
{
  //## begin IF::Log::Log%34626247038B_const.body preserve=yes
  //## end IF::Log::Log%34626247038B_const.body
}


Log::~Log()
{
  //## begin IF::Log::~Log%34626247038B_dest.body preserve=yes
  //## end IF::Log::~Log%34626247038B_dest.body
}



//## Other Operations (implementation)
int Log::cut (const char* pszDestination)
{
  //## begin IF::Log::cut%36EED83A0361.body preserve=yes
   Message::instance(Message::OUTBOUND)->reset("NSMLOG","H0305C",false);
   memset(Message::instance(Message::OUTBOUND)->data(),' ',286);
   memset(Message::instance(Message::OUTBOUND)->data(),'\0',9);
   memcpy_s(Message::instance(Message::OUTBOUND)->data() + 9,7,"DCUTLOG",7);
   Message::instance(Message::OUTBOUND)->setDataLength(286);
#ifdef MVS
   Queue::send(pszDestination,Message::instance(Message::OUTBOUND),Queue::REQUEST);
#else
   Queue::send(m_strPriCustLogger.c_str(),Message::instance(Message::OUTBOUND),Queue::REQUEST);
   if (m_strSecCustLogger.length() > 0)
      Queue::send(m_strSecCustLogger.c_str(),Message::instance(Message::OUTBOUND),Queue::REQUEST);
#endif
   return 0;
  //## end IF::Log::cut%36EED83A0361.body
}

int Log::endOfDay (const char* pszDestination)
{
  //## begin IF::Log::endOfDay%36EED8590167.body preserve=yes
   Message::instance(Message::OUTBOUND)->reset("NSMLOG","H0306C",false);
   memset(Message::instance(Message::OUTBOUND)->data(),' ',210);
   memset(Message::instance(Message::OUTBOUND)->data(),'\0',9);
   memcpy_s(Message::instance(Message::OUTBOUND)->data() + 9,4,"DEOD",4);
   Message::instance(Message::OUTBOUND)->setDataLength(210);
#ifdef MVS
   Queue::send(pszDestination,Message::instance(Message::OUTBOUND),Queue::REQUEST);
#else
   Queue::send(m_strPriCustLogger.c_str(),Message::instance(Message::OUTBOUND),Queue::REQUEST);
   if (m_strSecCustLogger.length() > 0)
      Queue::send(m_strSecCustLogger.c_str(),Message::instance(Message::OUTBOUND),Queue::REQUEST);
#endif
   return 0;
  //## end IF::Log::endOfDay%36EED8590167.body
}

int Log::put (const char* psBuffer, int iBuffer, const char* psMessageID, const char* pszReason, const char* psCBEKey, const char* pszDestination, const char* pszStation, const char* pszLUName)
{
  //## begin IF::Log::put%34626270005F.body preserve=yes
#ifndef MVS
   if (m_siEnable == -1)
   {
      IString strTemp;
      m_siEnable = (Extract::instance()->get("DQUEUE  LOGP    ",strTemp)) ? 1 : 0;
   }
   if (m_siEnable == 0)
      return 0;
#endif
   int lRC = 0;
   char sReason[19] = {"                  "};
   size_t i = strlen(pszReason);
   if (i > 18)
      i = 18;
   memcpy_s(sReason,sizeof(sReason),pszReason,i);
   if (!psCBEKey)
      psCBEKey = "            ";
#ifdef MVS
   char sDestination[9] = {"        "};
   if (pszDestination)
   {
      string strTemp("DQUEUE  ");
      strTemp += pszDestination;
      IString strRealName;
      if (Extract::instance()->get(strTemp.c_str(),strRealName))
         memcpy_s(sDestination,sizeof(sDestination),(char*)strRealName + 16,8);
      else
      {
         i = strlen(pszDestination);
         if (i > 8)
            i = 8;
         memcpy_s(sDestination,sizeof(sDestination),pszDestination,i);
      }
   }
   else
      memcpy_s(sDestination,sizeof(sDestination),"@LOGGER",7);
   char sStation[9] = {"        "};
   if (pszStation)
   {
      i = strlen(pszStation);
      if (i > 8)
         i = 8;
      memcpy_s(sStation,sizeof(sStation),pszStation,i);
   }
   char sLUName[9] = {"        "};
   if (pszLUName)
   {
      i = strlen(pszLUName);
      if (i > 8)
         i = 8;
      memcpy_s(sLUName,sizeof(sLUName),pszLUName,i);
   }
   // 64 byte header + 32676 byte data = maximum log record of 32740 on z/OS
   if (iBuffer > 32676)
      iBuffer = 32676;
   char* pTempBuffer = new char[iBuffer];
   memcpy_s(pTempBuffer,iBuffer,psBuffer,iBuffer);
   Mask::maskCardNumber((char*)pTempBuffer, iBuffer);
   CXLOG(pTempBuffer,&iBuffer,psCBEKey,psMessageID,sReason,sDestination,sStation,sLUName,&lRC);
   delete [] pTempBuffer;
#else
   if (!pszDestination)
      pszDestination = "LOGP";
   Message::instance(Message::OUTBOUND)->reset("   LOG","L0001D",false);
   Message::instance(Message::OUTBOUND)->setSenderCBAddress(*((void**)psCBEKey));
   Message::instance(Message::OUTBOUND)->setSenderSTCKValue(psCBEKey + 4);
   Message::instance(Message::OUTBOUND)->reserve(sizeof(struct hStandardHeader) + sizeof(struct hUniqueHeader) + sizeof(struct hData2) + sizeof(struct LogHeader) + iBuffer) ;
   LogHeader* p = (LogHeader*)Message::instance(Message::OUTBOUND)->data();
   memset(p,' ',sizeof(LogHeader));
   memcpy_s(p->sMessageID,sizeof(p->sMessageID),psMessageID,5);
   p->cRetry = '\0';
   memcpy_s(p->sReason,sizeof(p->sReason),sReason,18);
   memcpy_s((char*)p + sizeof(LogHeader),iBuffer,psBuffer,iBuffer);
   Mask::maskCardNumber((char*)p + sizeof(LogHeader), iBuffer);
   Message::instance(Message::OUTBOUND)->setDataLength(sizeof(LogHeader) + iBuffer);
   if (strcmp(pszDestination,"LOGP") == 0)
   {
      Queue::send("LOGP",Message::instance(Message::OUTBOUND),Queue::REQUEST);
      IString strTemp;
      if (Extract::instance()->get("DQUEUE  LOGS",strTemp))
         Queue::send("LOGS",Message::instance(Message::OUTBOUND),Queue::REQUEST);
   }
   else
   if (strcmp(pszDestination,"CUSTLOG") == 0)
   {
      p->dTicks = 0; // Clock::getTicks(); need to move TMDLL below IFDLL !!!
      p->cFlag = '\0';
      Queue::send(m_strPriCustLogger.c_str(),Message::instance(Message::OUTBOUND),Queue::REQUEST);
      if (m_strSecCustLogger.length() > 0)
         Queue::send(m_strSecCustLogger.c_str(),Message::instance(Message::OUTBOUND),Queue::REQUEST);
   }
   else
      Queue::send(pszDestination,Message::instance(Message::OUTBOUND),Queue::REQUEST);
#endif
   return lRC;
  //## end IF::Log::put%34626270005F.body
}

//## Get and Set Operations for Class Attributes (implementation)

void Log::setPriCustLogger (const string& value)
{
  //## begin IF::Log::setPriCustLogger%3FAEBD390028.set preserve=no
  m_strPriCustLogger = value;
  //## end IF::Log::setPriCustLogger%3FAEBD390028.set
}

void Log::setSecCustLogger (const string& value)
{
  //## begin IF::Log::setSecCustLogger%3FAEBD5102CB.set preserve=no
  m_strSecCustLogger = value;
  //## end IF::Log::setSecCustLogger%3FAEBD5102CB.set
}

// Additional Declarations
  //## begin IF::Log%34626247038B.declarations preserve=yes
  //## end IF::Log%34626247038B.declarations

} // namespace IF

//## begin module%3626582A03A7.epilog preserve=yes
//## end module%3626582A03A7.epilog
