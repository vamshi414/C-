//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36266FAA0339.cm preserve=no
//	$Date:   May 15 2020 09:01:20  $ $Author:   e1009510  $ $Revision:   1.9  $
//## end module%36266FAA0339.cm

//## begin module%36266FAA0339.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%36266FAA0339.cp

//## Module: CXOSIF20%36266FAA0339; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXOSIF20.cpp

//## begin module%36266FAA0339.additionalIncludes preserve=no
//## end module%36266FAA0339.additionalIncludes

//## begin module%36266FAA0339.includes preserve=yes
// $Date:   May 15 2020 09:01:20  $ $Author:   e1009510  $ $Revision:   1.9  $
#include "CXODIF16.hpp"
//## end module%36266FAA0339.includes

#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF21_h
#include "CXODIF21.hpp"
#endif
#ifndef CXOSIF20_h
#include "CXODIF20.hpp"
#endif


//## begin module%36266FAA0339.declarations preserve=no
//## end module%36266FAA0339.declarations

//## begin module%36266FAA0339.additionalDeclarations preserve=yes
#ifdef MVS
extern "OS"
{
int CXGTN(char* psName,int* plRC);
}
#endif
//## end module%36266FAA0339.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::SharedResource 

//## begin IF::SharedResource::SharedObjects%477A1BB200E7.attr preserve=no  private: static set<string, less<string> > {R} 0
set<string, less<string> > *SharedResource::m_pSharedObjects = 0;
//## end IF::SharedResource::SharedObjects%477A1BB200E7.attr

SharedResource::SharedResource()
  //## begin SharedResource::SharedResource%34A405D70348_const.hasinit preserve=no
      : m_pRemoteObserver(0)
  //## end SharedResource::SharedResource%34A405D70348_const.hasinit
  //## begin SharedResource::SharedResource%34A405D70348_const.initialization preserve=yes
  //## end SharedResource::SharedResource%34A405D70348_const.initialization
{
  //## begin IF::SharedResource::SharedResource%34A405D70348_const.body preserve=yes
  //## end IF::SharedResource::SharedResource%34A405D70348_const.body
}

SharedResource::SharedResource (const char* pszName)
  //## begin IF::SharedResource::SharedResource%34A406DD00AF.hasinit preserve=no
      : m_pRemoteObserver(0)
  //## end IF::SharedResource::SharedResource%34A406DD00AF.hasinit
  //## begin IF::SharedResource::SharedResource%34A406DD00AF.initialization preserve=yes
  //## end IF::SharedResource::SharedResource%34A406DD00AF.initialization
{
  //## begin IF::SharedResource::SharedResource%34A406DD00AF.body preserve=yes
   string strName("@");
   strName += pszName;
   size_t n = strName.find("##");
   if (n != string::npos)
   {
      string strTemp;
      if (Extract::instance()->getSpec("CUSTABBR",strTemp))
         strName.replace(n,2,strTemp.data(),strTemp.length());
      else
      {
         char pName[7];
         int lRC;
#ifdef MVS
         CXGTN(pName, &lRC);
#else
         memcpy_s(pName,7,getApplicationName(),7);
#endif
         strName.replace(n,2,pName,2);
      }
   }
   m_strName = strName;
   Queue::attach(m_strName.c_str(),Queue::CX_DISTRIBUTION_QUEUE);
   m_pRemoteObserver = new RemoteObserver(this,m_strName.c_str());
  //## end IF::SharedResource::SharedResource%34A406DD00AF.body
}


SharedResource::~SharedResource()
{
  //## begin IF::SharedResource::~SharedResource%34A405D70348_dest.body preserve=yes
   Queue::detach(m_strName.c_str());
   delete m_pRemoteObserver;
  //## end IF::SharedResource::~SharedResource%34A405D70348_dest.body
}



//## Other Operations (implementation)
void SharedResource::notify ()
{
  //## begin IF::SharedResource::notify%34A406F9002D.body preserve=yes
   Subject::notify();
#ifdef MVS
   if (!m_pSharedObjects)
      m_pSharedObjects = new set<string,less<string> >;
   m_pSharedObjects->insert(m_strName);
#endif
  //## end IF::SharedResource::notify%34A406F9002D.body
}

void SharedResource::commit ()
{
  //## begin IF::SharedResource::commit%476A6BB1008E.body preserve=yes
#ifdef MVS
   if (m_pSharedObjects)
   {
      set<string>::iterator pIterSharedObjects;
      for (pIterSharedObjects = m_pSharedObjects->begin();
         pIterSharedObjects != m_pSharedObjects->end();++pIterSharedObjects)
      {
         string strName = *pIterSharedObjects;
         Message::instance(Message::OUTBOUND)->reset("NTYOBS","S0006D");
         Message::instance(Message::OUTBOUND)->setDataLength(strName.length());
         memcpy(Message::instance(Message::OUTBOUND)->data(),strName.data(),strName.length());
         Message::instance(Message::OUTBOUND)->send(strName.c_str());
      }
      m_pSharedObjects->erase(m_pSharedObjects->begin(),m_pSharedObjects->end());
   }
#endif
  //## end IF::SharedResource::commit%476A6BB1008E.body
}

void SharedResource::rollback ()
{
  //## begin IF::SharedResource::rollback%476A6BC20189.body preserve=yes
#ifdef MVS
   if (m_pSharedObjects)
      m_pSharedObjects->erase(m_pSharedObjects->begin(),m_pSharedObjects->end());
#endif
  //## end IF::SharedResource::rollback%476A6BC20189.body
}

// Additional Declarations
  //## begin IF::SharedResource%34A405D70348.declarations preserve=yes
  //## end IF::SharedResource%34A405D70348.declarations

} // namespace IF

//## begin module%36266FAA0339.epilog preserve=yes
//## end module%36266FAA0339.epilog
