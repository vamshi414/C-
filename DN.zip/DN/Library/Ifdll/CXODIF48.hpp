//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%44A0E932029F.cm preserve=no
//	$Date:   Jun 03 2009 16:27:52  $ $Author:   D92186  $ $Revision:   1.4  $
//## end module%44A0E932029F.cm

//## begin module%44A0E932029F.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%44A0E932029F.cp

//## Module: CXOSIF48%44A0E932029F; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF48.hpp

#ifndef CXOSIF48_h
#define CXOSIF48_h 1

//## begin module%44A0E932029F.additionalIncludes preserve=no
//## end module%44A0E932029F.additionalIncludes

//## begin module%44A0E932029F.includes preserve=yes
//## end module%44A0E932029F.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Console;
class FlatFile;
class Trace;

} // namespace IF

//## begin module%44A0E932029F.declarations preserve=no
//## end module%44A0E932029F.declarations

//## begin module%44A0E932029F.additionalDeclarations preserve=yes
//## end module%44A0E932029F.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::AdvancedEncryptionStandard%44A0E76300CB.preface preserve=yes
//## end IF::AdvancedEncryptionStandard%44A0E76300CB.preface

//## Class: AdvancedEncryptionStandard%44A0E76300CB
//	<body>
//	<title>CG
//	<h1>CQ
//	<h2>MS
//	<h3>Database Connection
//	<p>
//	The DataNavigator Server services connect to the
//	database using the USERID and PASSWORD values in the
//	site specification.
//	These values can be in the clear or encrypted.
//	Use the CR Client for Security to generate cryptograms
//	for your userid and password values:
//	<p>
//	<img src=CXOCCQ01.gif>
//	<p>
//	Use the CR Client for the DataNavigator Server to enter
//	the cryptograms in the Site Specification custom table
//	data.
//	If cryptograms are used, also add a new entry named
//	ENCRYPT with a value of ON.
//	<p>
//	Sample entries from a SITESPEC.txt extract file:
//	<p>
//	<ul>
//	<li>DSPEC USERID  rAj/JTivurhCfCU2BeCyiA==
//	<li>DSPEC PASSWORD0q34/4+2AVHKezZ2FdotrQ==
//	<li>DSPEC ENCRYPT ON
//	</ul>
//	Custom Table Data definitions are in the Custom Tables
//	folder in the CR Client for the DataNavigator Server.
//	</body>
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%44A0FDB20232;Extract { -> F}
//## Uses: <unnamed>%44A0FDDE002E;FlatFile { -> F}
//## Uses: <unnamed>%44A0FE0B029F;Trace { -> F}
//## Uses: <unnamed>%44A0FE4800FA;Console { -> F}

class DllExport AdvancedEncryptionStandard : public reusable::Object  //## Inherits: <unnamed>%44A0E7E4033C
{
  //## begin IF::AdvancedEncryptionStandard%44A0E76300CB.initialDeclarations preserve=yes
  //## end IF::AdvancedEncryptionStandard%44A0E76300CB.initialDeclarations

  public:
    //## Constructors (generated)
      AdvancedEncryptionStandard();

    //## Destructor (generated)
      virtual ~AdvancedEncryptionStandard();


    //## Other Operations (specified)
      //## Operation: decrypt%44A0EB4C0213
      static bool decrypt (string& strText);

      //## Operation: encrypt%44A0EB55000F
      static bool encrypt (string& strText);

      //## Operation: generateKey%4A26DCE301A9
      static string generateKey ();

      //## Operation: initialize%44A0F1A50109
      static bool initialize (string* pUserKey = NULL);

    // Additional Public Declarations
      //## begin IF::AdvancedEncryptionStandard%44A0E76300CB.public preserve=yes
      //## end IF::AdvancedEncryptionStandard%44A0E76300CB.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: DefaultKey%4A26DCD302AB
      //## begin IF::AdvancedEncryptionStandard::DefaultKey%4A26DCD302AB.attr preserve=no  private: static string {U} 
      static string m_strDefaultKey;
      //## end IF::AdvancedEncryptionStandard::DefaultKey%4A26DCD302AB.attr

      //## Attribute: UserKey%44A0EBCC00CB
      //## begin IF::AdvancedEncryptionStandard::UserKey%44A0EBCC00CB.attr preserve=no  private: static string {U} 
      static string m_strUserKey;
      //## end IF::AdvancedEncryptionStandard::UserKey%44A0EBCC00CB.attr

    // Additional Protected Declarations
      //## begin IF::AdvancedEncryptionStandard%44A0E76300CB.protected preserve=yes
      //## end IF::AdvancedEncryptionStandard%44A0E76300CB.protected

  private:
    // Additional Private Declarations
      //## begin IF::AdvancedEncryptionStandard%44A0E76300CB.private preserve=yes
      static bool m_bEncryption;
      //## end IF::AdvancedEncryptionStandard%44A0E76300CB.private
  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::AdvancedEncryptionStandard%44A0E76300CB.implementation preserve=yes
      //## end IF::AdvancedEncryptionStandard%44A0E76300CB.implementation

};

//## begin IF::AdvancedEncryptionStandard%44A0E76300CB.postscript preserve=yes
//## end IF::AdvancedEncryptionStandard%44A0E76300CB.postscript

} // namespace IF

//## begin module%44A0E932029F.epilog preserve=yes
using namespace IF;
//## end module%44A0E932029F.epilog


#endif
