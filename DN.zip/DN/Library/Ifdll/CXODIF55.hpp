//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%49B94B2F029F.cm preserve=no
//	$Date:   Mar 07 2013 15:34:56  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%49B94B2F029F.cm

//## begin module%49B94B2F029F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%49B94B2F029F.cp

//## Module: CXOSIF55%49B94B2F029F; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: c:\ConnexPlatform\Server\Library\Ifdll\CXODIF55.hpp

#ifndef CXOSIF55_h
#define CXOSIF55_h 1

//## begin module%49B94B2F029F.additionalIncludes preserve=no
//## end module%49B94B2F029F.additionalIncludes

//## begin module%49B94B2F029F.includes preserve=yes
//## end module%49B94B2F029F.includes

#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
//## begin module%49B94B2F029F.declarations preserve=no
//## end module%49B94B2F029F.declarations

//## begin module%49B94B2F029F.additionalDeclarations preserve=yes
//## end module%49B94B2F029F.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::ExternalQueue%49B94AD60000.preface preserve=yes
//## end IF::ExternalQueue%49B94AD60000.preface

//## Class: ExternalQueue%49B94AD60000
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport ExternalQueue : public Queue  //## Inherits: <unnamed>%49B94BC40148
{
  //## begin IF::ExternalQueue%49B94AD60000.initialDeclarations preserve=yes
  //## end IF::ExternalQueue%49B94AD60000.initialDeclarations

  public:
    //## Constructors (generated)
      ExternalQueue();

    //## Constructors (specified)
      //## Operation: ExternalQueue%49B95C840280
      ExternalQueue (const char* pszName);

    //## Destructor (generated)
      virtual ~ExternalQueue();


    //## Other Operations (specified)
      //## Operation: backup%5137739502A8
      virtual void backup ();

      //## Operation: commit%49BA7F210186
      virtual bool commit () = 0;

      //## Operation: getDepth%49BAAA6A0000
      virtual int getDepth () = 0;

      //## Operation: reset%49BABA3701A5
      void reset ();

      //## Operation: rollback%49BA7F26029F
      virtual bool rollback () = 0;

      //## Operation: setInBatch%4A1564C2009C
      virtual void setInBatch (bool bValue);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: BatchSize%49BA7E9E02CE
      const int& getBatchSize () const
      {
        //## begin IF::ExternalQueue::getBatchSize%49BA7E9E02CE.get preserve=no
        return m_iBatchSize;
        //## end IF::ExternalQueue::getBatchSize%49BA7E9E02CE.get
      }

      void setBatchSize (const int& value)
      {
        //## begin IF::ExternalQueue::setBatchSize%49BA7E9E02CE.set preserve=no
        m_iBatchSize = value;
        //## end IF::ExternalQueue::setBatchSize%49BA7E9E02CE.set
      }


      //## Attribute: InBatch%49B94C2F01E4
      const bool getInBatch () const
      {
        //## begin IF::ExternalQueue::getInBatch%49B94C2F01E4.get preserve=no
        return m_bInBatch;
        //## end IF::ExternalQueue::getInBatch%49B94C2F01E4.get
      }


      //## Attribute: QueueManager%49B94C0A00DA
      const string& getQueueManager () const
      {
        //## begin IF::ExternalQueue::getQueueManager%49B94C0A00DA.get preserve=no
        return m_strQueueManager;
        //## end IF::ExternalQueue::getQueueManager%49B94C0A00DA.get
      }


    // Additional Public Declarations
      //## begin IF::ExternalQueue%49B94AD60000.public preserve=yes
      void setTimestamp (const string& value)
      {
         if (m_strTimestamp < value)
            m_strTimestamp = value;
      }
      const string& getTimestamp () const
      {
        return m_strTimestamp;
      }
      //## end IF::ExternalQueue%49B94AD60000.public
  protected:
    // Data Members for Class Attributes

      //## Attribute: Balance%49B94EB2005D
      //## begin IF::ExternalQueue::Balance%49B94EB2005D.attr preserve=no  public: bool {U} false
      bool m_bBalance;
      //## end IF::ExternalQueue::Balance%49B94EB2005D.attr

      //## begin IF::ExternalQueue::BatchSize%49BA7E9E02CE.attr preserve=no  public: int {U} 100
      int m_iBatchSize;
      //## end IF::ExternalQueue::BatchSize%49BA7E9E02CE.attr

      //## Attribute: Depth%49B94C5B02FD
      //## begin IF::ExternalQueue::Depth%49B94C5B02FD.attr preserve=no  public: int {U} 0
      int m_iDepth;
      //## end IF::ExternalQueue::Depth%49B94C5B02FD.attr

      //## begin IF::ExternalQueue::InBatch%49B94C2F01E4.attr preserve=no  public: bool {V} false
      bool m_bInBatch;
      //## end IF::ExternalQueue::InBatch%49B94C2F01E4.attr

      //## begin IF::ExternalQueue::QueueManager%49B94C0A00DA.attr preserve=no  public: string {U} 
      string m_strQueueManager;
      //## end IF::ExternalQueue::QueueManager%49B94C0A00DA.attr

    // Additional Protected Declarations
      //## begin IF::ExternalQueue%49B94AD60000.protected preserve=yes
      //## end IF::ExternalQueue%49B94AD60000.protected

  private:
    // Additional Private Declarations
      //## begin IF::ExternalQueue%49B94AD60000.private preserve=yes
      string m_strTimestamp;
      //## end IF::ExternalQueue%49B94AD60000.private
  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::ExternalQueue%49B94AD60000.implementation preserve=yes
      //## end IF::ExternalQueue%49B94AD60000.implementation

};

//## begin IF::ExternalQueue%49B94AD60000.postscript preserve=yes
//## end IF::ExternalQueue%49B94AD60000.postscript

} // namespace IF

//## begin module%49B94B2F029F.epilog preserve=yes
//## end module%49B94B2F029F.epilog


#endif
