//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3626706E0269.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3626706E0269.cm

//## begin module%3626706E0269.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3626706E0269.cp

//## Module: CXOSIF27%3626706E0269; Package specification
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXODIF27.hpp

#ifndef CXOSIF27_h
#define CXOSIF27_h 1

//## begin module%3626706E0269.additionalIncludes preserve=no
//## end module%3626706E0269.additionalIncludes

//## begin module%3626706E0269.includes preserve=yes
// $Date:   Jun 30 2006 11:35:40  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%3626706E0269.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Decimal;

} // namespace IF

//## begin module%3626706E0269.declarations preserve=no
//## end module%3626706E0269.declarations

//## begin module%3626706E0269.additionalDeclarations preserve=yes
//## end module%3626706E0269.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Currency%35F697410256.preface preserve=yes
//## end IF::Currency%35F697410256.preface

//## Class: Currency%35F697410256
//## Category: Connex Foundation::IF_CAT%3451F55F009E
//## Subsystem: IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3BFE7ACB035B;Decimal { -> F}

class DllExport Currency : public reusable::Object  //## Inherits: <unnamed>%35F697AC0304
{
  //## begin IF::Currency%35F697410256.initialDeclarations preserve=yes
  //## end IF::Currency%35F697410256.initialDeclarations

  public:
    //## Constructors (generated)
      Currency();

    //## Destructor (generated)
      virtual ~Currency();


    //## Other Operations (specified)
      //## Operation: convertIBMAmt%35F697CA0285
      static bool convertIBMAmt (const char* psDecimalAmount, short siLength, int lReversalFee, int lRate, int lFactor, const char *psProcessCode, const char *psMessageID, double* pdResultAmount);

    // Additional Public Declarations
      //## begin IF::Currency%35F697410256.public preserve=yes
      //## end IF::Currency%35F697410256.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Currency%35F697410256.protected preserve=yes
      //## end IF::Currency%35F697410256.protected

  private:
    // Additional Private Declarations
      //## begin IF::Currency%35F697410256.private preserve=yes
      //## end IF::Currency%35F697410256.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::Currency%35F697410256.implementation preserve=yes
      //## end IF::Currency%35F697410256.implementation

};

//## begin IF::Currency%35F697410256.postscript preserve=yes
//## end IF::Currency%35F697410256.postscript

} // namespace IF

//## begin module%3626706E0269.epilog preserve=yes
using namespace IF;
//## end module%3626706E0269.epilog


#endif
