//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%362670200108.cm preserve=no
//	$Date:   Jun 21 2017 15:57:52  $ $Author:   e1009839  $ $Revision:   1.14  $
//## end module%362670200108.cm

//## begin module%362670200108.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%362670200108.cp

//## Module: CXOSIF23%362670200108; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXOSIF23.cpp

//## begin module%362670200108.additionalIncludes preserve=no
//## end module%362670200108.additionalIncludes

//## begin module%362670200108.includes preserve=yes
#include "CXODRU37.hpp"
//## end module%362670200108.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF23_h
#include "CXODIF23.hpp"
#endif


//## begin module%362670200108.declarations preserve=no
//## end module%362670200108.declarations

//## begin module%362670200108.additionalDeclarations preserve=yes
//## end module%362670200108.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Session 

//## begin IF::Session::ApplicationName%3AE8849903D9.attr preserve=no  public: static string* {V} 0
string* Session::m_pstrApplicationName = 0;
//## end IF::Session::ApplicationName%3AE8849903D9.attr

//## begin IF::Session::Region%352B759B00FD.attr preserve=no  public: static string* {V} 0
string* Session::m_pstrRegion = 0;
//## end IF::Session::Region%352B759B00FD.attr

//## begin IF::Session::System%352B75960218.attr preserve=no  public: static string* {V} 0
string* Session::m_pstrSystem = 0;
//## end IF::Session::System%352B75960218.attr

Session::Session()
  //## begin Session::Session%352B74A1005D_const.hasinit preserve=no
      : m_bASCII(false),
        m_bOn(false)
  //## end Session::Session%352B74A1005D_const.hasinit
  //## begin Session::Session%352B74A1005D_const.initialization preserve=yes
  //## end Session::Session%352B74A1005D_const.initialization
{
  //## begin IF::Session::Session%352B74A1005D_const.body preserve=yes
   memcpy(m_sID,"IF23",4);
  //## end IF::Session::Session%352B74A1005D_const.body
}

Session::Session(const Session &right)
  //## begin Session::Session%352B74A1005D_copy.hasinit preserve=no
      : m_bASCII(false),
        m_bOn(false)
  //## end Session::Session%352B74A1005D_copy.hasinit
  //## begin Session::Session%352B74A1005D_copy.initialization preserve=yes
   ,Observer(right)
   ,m_strPartnerLUName(right.m_strPartnerLUName)
   ,m_strUserID(right.m_strUserID)
   ,m_strPassword(right.m_strPassword)
   ,m_strNewPassword(right.m_strNewPassword)
   ,m_strReturnCode(right.m_strReturnCode)
  //## end Session::Session%352B74A1005D_copy.initialization
{
  //## begin IF::Session::Session%352B74A1005D_copy.body preserve=yes
   memcpy(m_sID,"IF23",4);
   m_bOn = right.m_bOn;
  //## end IF::Session::Session%352B74A1005D_copy.body
}

Session::Session (const string& strPartnerLUName)
  //## begin IF::Session::Session%352B74EF029A.hasinit preserve=no
      : m_bASCII(false),
        m_bOn(false)
  //## end IF::Session::Session%352B74EF029A.hasinit
  //## begin IF::Session::Session%352B74EF029A.initialization preserve=yes
   ,m_strPartnerLUName(strPartnerLUName)
  //## end IF::Session::Session%352B74EF029A.initialization
{
  //## begin IF::Session::Session%352B74EF029A.body preserve=yes
   memcpy(m_sID,"IF23",4);
  //## end IF::Session::Session%352B74EF029A.body
}


Session::~Session()
{
  //## begin IF::Session::~Session%352B74A1005D_dest.body preserve=yes
  //## end IF::Session::~Session%352B74A1005D_dest.body
}


Session & Session::operator=(const Session &right)
{
  //## begin IF::Session::operator=%352B74A1005D_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_bOn = right.m_bOn;
   m_strPartnerLUName = right.m_strPartnerLUName;
   m_strUserID = right.m_strUserID;
   m_strPassword = right.m_strPassword;
   m_strNewPassword = right.m_strNewPassword;
   m_strReturnCode = right.m_strReturnCode;
   return *this;
  //## end IF::Session::operator=%352B74A1005D_assign.body
}



//## Other Operations (implementation)
string Session::getApplicationName ()
{
  //## begin IF::Session::getApplicationName%43F1344202AF.body preserve=yes
   if (!m_pstrApplicationName)
      m_pstrApplicationName = new string;
   return *m_pstrApplicationName;
  //## end IF::Session::getApplicationName%43F1344202AF.body
}

bool Session::logoff (IF::Message& hMessage, const string& strConversationID)
{
  //## begin IF::Session::logoff%352B750500B1.body preserve=yes
   hMessage.reset("CI ACS","C4611D",false);
   hMessage.setSenderCBAddress(this);
   msgLogon* pLogon = (msgLogon*)hMessage.data();
   memset((void*)pLogon,' ',sizeof(msgLogon));
   strncpy(pLogon->sType,"LG",2);
   pLogon->cFunction = 'F';
   memcpy(pLogon->sAdminTerminalID,"CI      ",8);
   pLogon->cResourceClass = 'A';
   if (!m_pstrApplicationName)
      m_pstrApplicationName = new string;
   memcpy(pLogon->sResourceID,m_pstrApplicationName->data(),m_pstrApplicationName->length());
   memcpy(pLogon->sPassword,m_strPassword.data(),m_strPassword.length());
   if (!m_pstrSystem)
      m_pstrSystem = new string;
   memcpy(pLogon->sAdminSystemID,m_pstrSystem->data(),m_pstrSystem->length());
   if (!m_pstrRegion)
      m_pstrRegion = new string;
   memcpy(pLogon->sAdminRegionID,m_pstrRegion->data(),m_pstrRegion->length());
   memcpy(pLogon->sAdminOperatorID,m_strUserID.data(),m_strUserID.length());
   hMessage.setDataLength(sizeof(struct msgLogon));
#ifdef MVS
   return (hMessage.send("@ACCESS") == 0);
#else
   return (hMessage.send("ACS") == 0);
#endif
  //## end IF::Session::logoff%352B750500B1.body
}

bool Session::logon (IF::Message& hMessage, const string& strConversationID)
{
  //## begin IF::Session::logon%352B750902B6.body preserve=yes
   hMessage.reset("CI ACS","C4611D",false);
   hMessage.setSenderCBAddress(this);
   msgLogon* pLogon = (msgLogon*)hMessage.data();
   memset((void*)pLogon,' ',sizeof(msgLogon));
   strncpy(pLogon->sType,"LG",2);
   pLogon->cFunction = 'O';
   memcpy(pLogon->sAdminTerminalID,"CI      ",8);
   pLogon->cResourceClass = 'A';
   if (!m_pstrApplicationName)
      m_pstrApplicationName = new string;
   memcpy(pLogon->sResourceID,m_pstrApplicationName->data(),m_pstrApplicationName->length());
   memcpy(pLogon->sPassword,m_strPassword.data(),m_strPassword.length());
   memcpy(pLogon->sNewPassword,m_strNewPassword.data(),m_strNewPassword.length());
   memcpy(pLogon->sAdminOperatorID,m_strUserID.data(),m_strUserID.length());
   hMessage.setDataLength(sizeof(struct msgLogon));
#ifdef MVS
   return (hMessage.send("@ACCESS") == 0);
#else
   return (hMessage.send("ACS") == 0);
#endif
  //## end IF::Session::logon%352B750902B6.body
}

void Session::securityResponse (IF::Message& hMessage)
{
  //## begin IF::Session::securityResponse%352B7510037E.body preserve=yes
   msgLogon* pLogon = (msgLogon*)hMessage.data();
   char szTemp[9];
   szTemp[5] = '\0';
   strncpy(szTemp,pLogon->sReturnCode,5);
   //cout << "(" << szTemp << ")" << endl;
   char* p = strchr(szTemp,' ');
   if (p)
      *p = '\0';
   m_strReturnCode = szTemp;
   m_bOn = (pLogon->cFunction == 'O' && m_strReturnCode.length() == 0);
   if (m_bOn)
   {
      szTemp[8] = '\0';
      strncpy(szTemp,pLogon->sAdminSystemID,8);
      if (!m_pstrSystem)
         m_pstrSystem = new string;
      *m_pstrSystem = szTemp;
      strncpy(szTemp,pLogon->sAdminRegionID,8);
      if (!m_pstrRegion)
         m_pstrRegion = new string;
      *m_pstrRegion = szTemp;
      if (m_strNewPassword.length() > 0)
         m_strPassword = m_strNewPassword;
   }
  //## end IF::Session::securityResponse%352B7510037E.body
}

void Session::setApplicationName (const string& strApplicationName)
{
  //## begin IF::Session::setApplicationName%43F1344C0109.body preserve=yes
   if (!m_pstrApplicationName)
      m_pstrApplicationName = new string;
   *m_pstrApplicationName = strApplicationName;
  //## end IF::Session::setApplicationName%43F1344C0109.body
}

void Session::update (Subject* pSubject)
{
  //## begin IF::Session::update%380C67F40144.body preserve=yes
  //## end IF::Session::update%380C67F40144.body
}

// Additional Declarations
  //## begin IF::Session%352B74A1005D.declarations preserve=yes
  //## end IF::Session%352B74A1005D.declarations

} // namespace IF

//## begin module%362670200108.epilog preserve=yes
//## end module%362670200108.epilog
