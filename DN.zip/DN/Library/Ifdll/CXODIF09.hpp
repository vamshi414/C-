//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%36266CAD00C2.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36266CAD00C2.cm

//## begin module%36266CAD00C2.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36266CAD00C2.cp

//## Module: CXOSIF09%36266CAD00C2; Package specification
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXODIF09.hpp

#ifndef CXOSIF09_h
#define CXOSIF09_h 1

//## begin module%36266CAD00C2.additionalIncludes preserve=no
//## end module%36266CAD00C2.additionalIncludes

//## begin module%36266CAD00C2.includes preserve=yes
// $Date:   Jun 30 2006 11:35:36  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%36266CAD00C2.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Console;

} // namespace IF

//## begin module%36266CAD00C2.declarations preserve=no
//## end module%36266CAD00C2.declarations

//## begin module%36266CAD00C2.additionalDeclarations preserve=yes
//## end module%36266CAD00C2.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Destination%34801B760358.preface preserve=yes
//## end IF::Destination%34801B760358.preface

//## Class: Destination%34801B760358
//	The Destination class encapsulates the functionality of
//	a CPI/C destination.
//
//	CXODIF09.hpp
//	CXOSIF09.cpp
//## Category: Connex Foundation::IF_CAT%3451F55F009E
//## Subsystem: IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%364DA59F0062;Console { -> F}

class DllExport Destination : public reusable::Object  //## Inherits: <unnamed>%34801C790378
{
  //## begin IF::Destination%34801B760358.initialDeclarations preserve=yes
  //## end IF::Destination%34801B760358.initialDeclarations

  public:
    //## Constructors (generated)
      Destination();

      Destination(const Destination &right);

    //## Constructors (specified)
      //## Operation: Destination%364D9DBB0216
      Destination (const char* pszName, const char* pszSymDestName, bool bDisplay = true);

    //## Destructor (generated)
      virtual ~Destination();

    //## Assignment Operation (generated)
      Destination & operator=(const Destination &right);


    //## Other Operations (specified)
      //## Operation: close%364D9DCD017B
      int close ();

      //## Operation: open%364D9DD4006D
      int open ();

      //## Operation: openCompleted%364D9DD8020D
      void openCompleted ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Name%364D9D750143
      const string& getName () const
      {
        //## begin IF::Destination::getName%364D9D750143.get preserve=no
        return m_strName;
        //## end IF::Destination::getName%364D9D750143.get
      }


      //## Attribute: SymDestName%364D9D7F0382
      const string& getSymDestName () const
      {
        //## begin IF::Destination::getSymDestName%364D9D7F0382.get preserve=no
        return m_strSymDestName;
        //## end IF::Destination::getSymDestName%364D9D7F0382.get
      }


    // Additional Public Declarations
      //## begin IF::Destination%34801B760358.public preserve=yes
      //## end IF::Destination%34801B760358.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Destination%34801B760358.protected preserve=yes
      //## end IF::Destination%34801B760358.protected

  private:

    //## Other Operations (specified)
      //## Operation: display%364D9EBD01B2
      void display (const char* pszState);

    // Additional Private Declarations
      //## begin IF::Destination%34801B760358.private preserve=yes
      //## end IF::Destination%34801B760358.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Display%364D9D850005
      //## begin IF::Destination::Display%364D9D850005.attr preserve=no  private: bool {V} false
      bool m_bDisplay;
      //## end IF::Destination::Display%364D9D850005.attr

      //## begin IF::Destination::Name%364D9D750143.attr preserve=no  public: string {V} 
      string m_strName;
      //## end IF::Destination::Name%364D9D750143.attr

      //## Attribute: Open%364D9D8A01CF
      //## begin IF::Destination::Open%364D9D8A01CF.attr preserve=no  private: bool {V} false
      bool m_bOpen;
      //## end IF::Destination::Open%364D9D8A01CF.attr

      //## begin IF::Destination::SymDestName%364D9D7F0382.attr preserve=no  public: string {V} 
      string m_strSymDestName;
      //## end IF::Destination::SymDestName%364D9D7F0382.attr

    // Additional Implementation Declarations
      //## begin IF::Destination%34801B760358.implementation preserve=yes
      //## end IF::Destination%34801B760358.implementation

};

//## begin IF::Destination%34801B760358.postscript preserve=yes
//## end IF::Destination%34801B760358.postscript

} // namespace IF

//## begin module%36266CAD00C2.epilog preserve=yes
using namespace IF;
//## end module%36266CAD00C2.epilog


#endif
