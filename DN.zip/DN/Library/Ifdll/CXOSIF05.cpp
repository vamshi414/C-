//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%362666C10086.cm preserve=no
//	$Date:   Aug 21 2020 15:36:42  $ $Author:   e1009839  $ $Revision:   1.12  $
//## end module%362666C10086.cm

//## begin module%362666C10086.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%362666C10086.cp

//## Module: CXOSIF05%362666C10086; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.3A.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF05.cpp

//## begin module%362666C10086.additionalIncludes preserve=no
//## end module%362666C10086.additionalIncludes

//## begin module%362666C10086.includes preserve=yes
#include <memory.h>
//## end module%362666C10086.includes

#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
//## begin module%362666C10086.declarations preserve=no
//## end module%362666C10086.declarations

//## begin module%362666C10086.additionalDeclarations preserve=yes
#ifdef MVS
extern "OS"
{
int CXAVS(char** ppsMemory,int* plLength,int* plRC);
int CXFVS(char** ppsMemory,int* plRC);
int CXLVS(const char* psTask,const char* psKey,char** ppsMemory,int* plRC);
int CXSSAM(int* plLocation,int* plRC);
}
#endif
//## end module%362666C10086.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Memory


Memory::Memory()
  //## begin Memory::Memory%345C724100DE_const.hasinit preserve=no
      : m_bAboveTheLine(false),
        m_lLength(0),
        m_pMemory(0)
  //## end Memory::Memory%345C724100DE_const.hasinit
  //## begin Memory::Memory%345C724100DE_const.initialization preserve=yes
  //## end Memory::Memory%345C724100DE_const.initialization
{
  //## begin IF::Memory::Memory%345C724100DE_const.body preserve=yes
   memcpy(m_sID,"IF05",4);
  //## end IF::Memory::Memory%345C724100DE_const.body
}

Memory::Memory (int lLength, bool bAboveTheLine)
  //## begin IF::Memory::Memory%3481C79602C9.hasinit preserve=no
      : m_bAboveTheLine(false),
        m_lLength(0),
        m_pMemory(0)
  //## end IF::Memory::Memory%3481C79602C9.hasinit
  //## begin IF::Memory::Memory%3481C79602C9.initialization preserve=yes
  //## end IF::Memory::Memory%3481C79602C9.initialization
{
  //## begin IF::Memory::Memory%3481C79602C9.body preserve=yes
   memcpy(m_sID,"IF05",4);
   if (lLength <= 0)
      return;
   m_lLength = lLength;
   m_bAboveTheLine = bAboveTheLine;
#ifdef MVS
   int lLocation = bAboveTheLine ? 0 : 1;
   int lRC = 0;
   CXSSAM(&lLocation,&lRC);
   CXAVS(&m_pMemory,&lLength,&lRC);
#else
   m_pMemory = new char[lLength];
   memset(m_pMemory,0x00,lLength);
#endif
  //## end IF::Memory::Memory%3481C79602C9.body
}


Memory::~Memory()
{
  //## begin IF::Memory::~Memory%345C724100DE_dest.body preserve=yes
   if (m_pMemory)
   {
#ifdef MVS
      int lRC = 0;
      CXFVS(&m_pMemory,&lRC);
#else
      delete [] m_pMemory;
#endif
   }
  //## end IF::Memory::~Memory%345C724100DE_dest.body
}



//## Other Operations (implementation)
char* Memory::locate (const string& strName, const char* pszKey)
{
  //## begin IF::Memory::locate%50A3C339004F.body preserve=yes
   char* p = 0;
   int lRC = 4;
#ifdef MVS
   CXLVS(strName.data(),pszKey,&p,&lRC);
#endif
   return lRC == 0 ? p : 0;
  //## end IF::Memory::locate%50A3C339004F.body
}

// Additional Declarations
  //## begin IF::Memory%345C724100DE.declarations preserve=yes
  //## end IF::Memory%345C724100DE.declarations

} // namespace IF

//## begin module%362666C10086.epilog preserve=yes
//## end module%362666C10086.epilog
