//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3EC3955B0203.cm preserve=no
// $Date:   May 15 2020 09:01:32  $ $Author:   e1009510  $
// $Revision:   1.12  $
//## end module%3EC3955B0203.cm

//## begin module%3EC3955B0203.cp preserve=no
// Copyright (c) 1997 - 2011
// FIS
//## end module%3EC3955B0203.cp

//## Module: CXOSIF44%3EC3955B0203; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
// .
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXOSIF44.cpp

//## begin module%3EC3955B0203.additionalIncludes preserve=no
//## end module%3EC3955B0203.additionalIncludes

//## begin module%3EC3955B0203.includes preserve=yes
#include <algorithm>
//## end module%3EC3955B0203.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF48_h
#include "CXODIF48.hpp"
#endif
#ifndef CXOSIF44_h
#include "CXODIF44.hpp"
#endif


//## begin module%3EC3955B0203.declarations preserve=no
//## end module%3EC3955B0203.declarations

//## begin module%3EC3955B0203.additionalDeclarations preserve=yes
//## end module%3EC3955B0203.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::SiteSpecification

//## begin IF::SiteSpecification::Instance%3EC394BE029F.attr preserve=no  private: static IF::SiteSpecification* {V} 0
IF::SiteSpecification* SiteSpecification::m_pInstance = 0;
//## end IF::SiteSpecification::Instance%3EC394BE029F.attr

SiteSpecification::SiteSpecification()
  //## begin SiteSpecification::SiteSpecification%3EC3947302CE_const.hasinit preserve=no
  //## end SiteSpecification::SiteSpecification%3EC3947302CE_const.hasinit
  //## begin SiteSpecification::SiteSpecification%3EC3947302CE_const.initialization preserve=yes
  //## end SiteSpecification::SiteSpecification%3EC3947302CE_const.initialization
{
  //## begin IF::SiteSpecification::SiteSpecification%3EC3947302CE_const.body preserve=yes
   memcpy(m_sID,"IF44",4);
   m_iCount[0] = 0;
   m_iCount[1] = 0;
   m_iOffset[0] = 0;
   m_iOffset[1] = 0;
   m_hValues["PLAN"] = "NA";
   m_hValues["DBDISK1"] = "f:";
   m_hValues["DBDISK2"] = "f:";
   m_hValues["DBDISK3"] = "e:";
   m_hValues["DBDISK4"] = "e:";
   m_hValues["DBFOLDER"] = "DN";
   m_hValues["DBDATA"] = "f:";
   m_hValues["DBINDEX"] = "f:";
   int i = 0;
   size_t pos;
   string strRecord;
   string strFirst;
   string strSecond;
   while (IF::Extract::instance()->getRecord(i++,strRecord))
   {
      if ((strRecord.substr(0,8) == "DSPEC   ") &&
          (strRecord.length() > 16))
      {
         strFirst = strRecord.substr(8,8);
         pos = strFirst.find_last_not_of(' ');
         if (pos == string::npos)
            strFirst.erase();
         else
            strFirst.erase(pos + 1);
         strSecond = strRecord.substr(16,64);
         size_t pos = strSecond.find_first_not_of(' ');
         if (pos != string::npos
            && pos > 0)
            strSecond.erase(0,pos);
         pos = strSecond.find_last_not_of(' ');
         if (pos == string::npos)
            strSecond.erase();
         else
            strSecond.erase(pos + 1);
         transform(strFirst.begin(),strFirst.end(),strFirst.begin(), ::toupper);
         m_hValues[strFirst] = strSecond;
      }
   }
   m_hValues["DOT"] = ".";
  //## end IF::SiteSpecification::SiteSpecification%3EC3947302CE_const.body
}


SiteSpecification::~SiteSpecification()
{
  //## begin IF::SiteSpecification::~SiteSpecification%3EC3947302CE_dest.body preserve=yes
  //## end IF::SiteSpecification::~SiteSpecification%3EC3947302CE_dest.body
}



//## Other Operations (implementation)
bool SiteSpecification::add (string& strFirst, string& strSecond)
{
  //## begin IF::SiteSpecification::add%3F205E4202BF.body preserve=yes
   size_t pos = strFirst.find_last_not_of(' ');
   if (pos == string::npos)
      strFirst.erase();
   else
      strFirst.erase(pos + 1);
   transform(strFirst.begin(),strFirst.end(),strFirst.begin(), ::toupper);
   m_hValues[strFirst] = strSecond;
   return true;
  //## end IF::SiteSpecification::add%3F205E4202BF.body
}

IF::SiteSpecification* SiteSpecification::instance ()
{
  //## begin IF::SiteSpecification::instance%3EC394D602AF.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new SiteSpecification();
   return m_pInstance;
  //## end IF::SiteSpecification::instance%3EC394D602AF.body
}

bool SiteSpecification::parseInclude (char* pszBuffer)
{
  //## begin IF::SiteSpecification::parseInclude%3ECD1F1101B5.body preserve=yes
   m_strMember.erase();
   m_strIndex[0].erase();
   m_strIndex[1].erase();
   m_iCount[0] = 1;
   m_iCount[1] = 1;
   int m = 0;
   m_iOffset[0] = 0;
   m_iOffset[1] = 0;
   map<string,string,less<string> >::iterator pKey;
   char *p = strtok(pszBuffer + 1," ");
   char *q = 0;
   while (p)
   {
      q = strchr(p,'+');
      if (q)
      {
         *q = '\0';
         ++q;
         for (unsigned int i = 0;i < strlen(q);++i)
            q[i] = toupper(q[i]);
         pKey = m_hValues.find(q);
         if (pKey == m_hValues.end())
         {
            string strFirst(q);
            strFirst.insert(0,"Missing DSPEC value: ",21);
            Trace::put(strFirst.data(),strFirst.length(),true);
            return false;
        }
         m_iOffset[m] = atoi((*pKey).second.c_str());
         m_strIndex[m] = q;
      }
      q = strchr(p,':');
      if (q)
      {
         *q = '\0';
         ++q;
      }
      else
         q = "%02d";
      for (unsigned int i = 0;i < strlen(p);++i)
         p[i] = toupper(p[i]);
      if (m_strMember.length() == 0)
         m_strMember = p;
      else
      {
         m_strFormat[m] = q;
         if (m_strIndex[m].length() == 0)
            m_strIndex[m] = p;
         pKey = m_hValues.find(p);
         if (pKey == m_hValues.end())
         {
            m_strIndex[m].insert(0,"Missing DSPEC value: ",21);
            Trace::put(m_strIndex[m].data(),m_strIndex[m].length(),true);
            return false;
         }
         m_iCount[m] = atoi((*pKey).second.c_str());
         m++;
      }
      p = strtok(0," ");
   }
   return true;
  //## end IF::SiteSpecification::parseInclude%3ECD1F1101B5.body
}

bool SiteSpecification::substitute (string& strBuffer, int i, int j)
{
  //## begin IF::SiteSpecification::substitute%3EC395CE00BB.body preserve=yes
   map<string,string,less <string> >::iterator p;
   string strFirst;
   char szBuffer[16];
   string strCount[2];
   snprintf(szBuffer,sizeof(szBuffer),m_strFormat[0].c_str(),i);
   strCount[0] = szBuffer;
   snprintf(szBuffer,sizeof(szBuffer),m_strFormat[1].c_str(),j);
   strCount[1] = szBuffer;
   size_t pos[2];
   pos[0] = strBuffer.find('&');
   while (pos[0] != string::npos)
   {
      pos[1] = pos[0] + 1;
      while (pos[1] < strBuffer.length() && strBuffer[pos[1]] != '.')
         ++pos[1];
      if (pos[1] == strBuffer.length())
      {
         string strTemp = strBuffer.substr(pos[0],pos[1] - pos[0]);
         strTemp.insert(0,"Warning: no matching period: ",29);
         Trace::put(strTemp.data(),strTemp.length(),true);
         return true;
      }
      strFirst = strBuffer.substr(pos[0] + 1,pos[1] - pos[0] - 1);
      transform(strFirst.begin(),strFirst.end(),strFirst.begin(), ::toupper);
      if (strFirst == m_strIndex[0])
         strBuffer.replace(pos[0],pos[1] - pos[0] + 1,strCount[0]);
      else
      if (strFirst == m_strIndex[1])
         strBuffer.replace(pos[0],pos[1] - pos[0] + 1,strCount[1]);
      else
      if (strFirst == "YYYYMMDDHHMMSS")
         strBuffer.replace(pos[0],pos[1] - pos[0] + 1,Transaction::instance()->getTimeStamp().substr(0,14));
      else
      {
         p = m_hValues.find(strFirst);
         if (p == m_hValues.end())
         {
            strFirst.insert(0,"Missing DSPEC value: ",21);
            Trace::put(strFirst.data(),strFirst.length(),true);
            return false;
         }
         string strSecond((*p).second);
         if (strSecond.length() > 2
            && strSecond[strSecond.length() - 1] == '='
            && strSecond[strSecond.length() - 2] == '=')
            AdvancedEncryptionStandard::decrypt(strSecond);
         strBuffer.replace(pos[0],pos[1] - pos[0] + 1,strSecond);
      }
      pos[0] = strBuffer.find('&');
   }
   return true;
  //## end IF::SiteSpecification::substitute%3EC395CE00BB.body
}

// Additional Declarations
  //## begin IF::SiteSpecification%3EC3947302CE.declarations preserve=yes
  //## end IF::SiteSpecification%3EC3947302CE.declarations

} // namespace IF

//## begin module%3EC3955B0203.epilog preserve=yes
//## end module%3EC3955B0203.epilog
