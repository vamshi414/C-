//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3729F8BA016B.cm preserve=no
//	$Date:   May 15 2020 09:01:30  $ $Author:   e1009510  $ $Revision:   1.14  $
//## end module%3729F8BA016B.cm

//## begin module%3729F8BA016B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3729F8BA016B.cp

//## Module: CXOSIF37%3729F8BA016B; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF37.cpp

//## begin module%3729F8BA016B.additionalIncludes preserve=no
//## end module%3729F8BA016B.additionalIncludes

//## begin module%3729F8BA016B.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%3729F8BA016B.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF26_h
#include "CXODIF26.hpp"
#endif
#ifndef CXOSIF37_h
#include "CXODIF37.hpp"
#endif


//## begin module%3729F8BA016B.declarations preserve=no
//## end module%3729F8BA016B.declarations

//## begin module%3729F8BA016B.additionalDeclarations preserve=yes
#ifdef _WIN32
#pragma pack(push)
#endif
#pragma pack(1)

struct hODBCData
{
   char cType;
   char sClass[2];
   char sSubClass[3];
   int lNativeError;
   char sErrorMessage[40];
   char sData[2];
};

#ifdef MVS
#pragma pack(reset)
#endif
#ifdef _WIN32
#pragma pack(pop)
#endif
#ifdef _UNIX
#pragma pack()
#endif

//## end module%3729F8BA016B.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::ResultSet 

ResultSet::ResultSet()
  //## begin ResultSet::ResultSet%3729F87C0130_const.hasinit preserve=no
      : m_pCursor(0),
        m_lRow(0),
        m_lRows(0),
        m_lRowSize(0)
  //## end ResultSet::ResultSet%3729F87C0130_const.hasinit
  //## begin ResultSet::ResultSet%3729F87C0130_const.initialization preserve=yes
  //## end ResultSet::ResultSet%3729F87C0130_const.initialization
{
  //## begin IF::ResultSet::ResultSet%3729F87C0130_const.body preserve=yes
   memcpy(m_sID,"IF37",4);
  //## end IF::ResultSet::ResultSet%3729F87C0130_const.body
}


ResultSet::~ResultSet()
{
  //## begin IF::ResultSet::~ResultSet%3729F87C0130_dest.body preserve=yes
  //## end IF::ResultSet::~ResultSet%3729F87C0130_dest.body
}



//## Other Operations (implementation)
void ResultSet::addRow (const char* pszDescription, const char* pszRow)
{
  //## begin IF::ResultSet::addRow%3729F97800E2.body preserve=yes

#ifdef _WIN32
#pragma pack(push)
#endif
#pragma pack(1)

   struct hDescription
   {
      char sColumnName[18];
      short int nDataType;
      int nPrecision;
      short int nScale;
   };

#ifdef MVS
#pragma pack(reset)
#endif
#ifdef _WIN32
#pragma pack(pop)
#endif
#ifdef _UNIX
#pragma pack()
#endif

   int i = 0;
   int j = 0;
   hODBCData* pODBCData = (hODBCData*)Message::instance(Message::INBOUND)->data();
   if (m_lRow == 0)
   {
      Message::instance(Message::INBOUND)->reset("SRVCLI","H5050R");
      memcpy(pODBCData->sClass,"00",2);
      memcpy(pODBCData->sSubClass,"000",3);
      pODBCData->lNativeError = htonl(0);
      memset(pODBCData->sErrorMessage,' ',sizeof(pODBCData->sErrorMessage));
      pODBCData->cType = 0x01;
      // number of columns
      int* pDescription = (int*)pszDescription;
      j = *pDescription;
      hDescription* p = (hDescription*)(pszDescription + 4);
      for (i = 0;i < j;++i)
      {
         m_lRowSize += ntohl(p->nPrecision);
         if (ntohs(p->nDataType) == 1)
            --m_lRowSize;
         ++p;
      }
      Message::instance(Message::INBOUND)->setDataLength(sizeof(struct hODBCData) + 2 + (j * sizeof(struct hDescription)));
      memcpy(pODBCData->sData + 4,pszDescription + 2, 2 + (j * sizeof(struct hDescription)));
#ifndef MVS
      short n = short(*((int*)pszDescription));
      short* px = (short*)(pODBCData->sData + 4);
      *px = htons(n);
#endif
      j = m_lRowSize + 6;
      int* py = (int*)pODBCData->sData;
      *py = j;
      // change VARCHAR type to CHAR for Dialog Manager
      py = (int*)pszDescription;
      j = *py;
      p = (hDescription*)(pODBCData->sData + 6);
      for (i = 0;i < j;++i)
      {
         if (p->sColumnName[0] == ' ')
         {
            snprintf(p->sColumnName,sizeof(p->sColumnName),"%d",i + 1);
            p->sColumnName[strlen(p->sColumnName)] = ' ';
         }
         else
         {
            char psTemp[18];
            memcpy(psTemp,p->sColumnName,18);
            memset(p->sColumnName,' ',18);
            int m = 0;
            for (int k = 0;k < 18;++k)
            if (psTemp[k] != '_')
               p->sColumnName[m++] = psTemp[k];
         }
         if (ntohs(p->nDataType) == 1)
            p->nPrecision = htonl(ntohl(p->nPrecision) - 1);
         if (ntohs(p->nDataType) == 6)
            p->nDataType = htons(3);
         if (ntohs(p->nDataType) == 9)
            p->nDataType = htons(1);
         ++p;
      }
      reply();
      m_pCursor = pODBCData->sData + 2;
   }
   pODBCData->cType = 0x04;
   ++m_lRows;
   ++m_lRow;
   snprintf(m_pCursor,7,"%06d",m_lRow);
   m_pCursor += 6;
   int* py = (int*)pszDescription;
   j = *py;
   hDescription* p = (hDescription*)(pszDescription + 4);
   char* pszCurrentPosition = (char*)pszRow;
   int k;
   for (i = 0;i < j;++i)
   {
      if (ntohs(p->nDataType) == 9)
      {
         k = *((short int*)pszCurrentPosition);
         pszCurrentPosition += 2; // length prefix
      }
      else
         k = ntohl(p->nPrecision);
      memset(m_pCursor,' ',ntohl(p->nPrecision));
#ifdef MVS
      if (ntohs(p->nDataType) == 6)
      {
         int l = (int)(*(double*)pszCurrentPosition);
         Decimal::asDecimal(l,m_pCursor,8);
      }
      else
#endif
         memcpy(m_pCursor,pszCurrentPosition,k);
      m_pCursor += ntohl(p->nPrecision);
      pszCurrentPosition += (ntohl(p->nPrecision) + 2);
      if (ntohs(p->nDataType) == 1)
         --m_pCursor; // null terminator
      ++p;
   }
   if ((m_pCursor - pODBCData->sData) > 32000) //64000 does not work
   {
      Message::instance(Message::INBOUND)->setDataLength(m_pCursor - (char*)pODBCData);
      short int* p = (short int*)pODBCData->sData;
      *p = htons((short int)m_lRows);
      reply();
      m_lRows = 0;
      m_pCursor = pODBCData->sData + 2;
   }
  //## end IF::ResultSet::addRow%3729F97800E2.body
}

void ResultSet::close ()
{
  //## begin IF::ResultSet::close%3729F9B6004B.body preserve=yes
   hODBCData* pODBCData;
   if (m_lRows > 0)
   {
      pODBCData = (hODBCData*)Message::instance(Message::INBOUND)->data();
      Message::instance(Message::INBOUND)->setDataLength(m_pCursor - (char*)pODBCData);
      short int* p = (short int*)pODBCData->sData;
      *p = htons((short int)m_lRows);
      reply();
   }
   else
      Message::instance(Message::INBOUND)->reset("SRVCLI","H5050R");
   pODBCData = (hODBCData*)Message::instance(Message::INBOUND)->data();
   Message::instance(Message::INBOUND)->setDataLength(sizeof(struct hODBCData));
   pODBCData->cType = (m_lRows == 0) ? 0x03 : 0x02;
   memcpy(pODBCData->sClass,"08",2);
   memcpy(pODBCData->sSubClass,"000",3);
   pODBCData->lNativeError = htonl(100);
   memset(pODBCData->sErrorMessage,' ',sizeof(pODBCData->sErrorMessage));
   memcpy(pODBCData->sErrorMessage,"END OF DATA",11);
   reply();
   m_pCursor = 0;
   m_lRow = 0;
   m_lRows = 0;
   m_lRowSize = 0;
  //## end IF::ResultSet::close%3729F9B6004B.body
}

void ResultSet::reply ()
{
  //## begin IF::ResultSet::reply%3A5E01C603CD.body preserve=yes
#ifdef MVS
   Message::instance(Message::INBOUND)->reply();
#else
   char sConversationID[9] = {"        "};
   char sSymDestName[9] = {"        "};
   memcpy(sConversationID,Message::instance(Message::INBOUND)->getCorrelId().data(),8);
   int m = 0;
   sscanf(sConversationID,"%08x",&m);
   snprintf(sSymDestName,sizeof(sSymDestName),"%d",m);
   Queue::send(sSymDestName,Message::instance(Message::INBOUND));
#endif
  //## end IF::ResultSet::reply%3A5E01C603CD.body
}

// Additional Declarations
  //## begin IF::ResultSet%3729F87C0130.declarations preserve=yes
  //## end IF::ResultSet%3729F87C0130.declarations

} // namespace IF

//## begin module%3729F8BA016B.epilog preserve=yes
//## end module%3729F8BA016B.epilog
