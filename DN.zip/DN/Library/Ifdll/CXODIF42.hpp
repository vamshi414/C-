//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E2F1BB70271.cm preserve=no
//	$Date:   Jan 23 2006 09:38:54  $ $Author:   D02405  $ $Revision:   1.4  $
//## end module%3E2F1BB70271.cm

//## begin module%3E2F1BB70271.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%3E2F1BB70271.cp

//## Module: CXOSIF42%3E2F1BB70271; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF42.hpp

#ifndef CXOSIF42_h
#define CXOSIF42_h 1

//## begin module%3E2F1BB70271.additionalIncludes preserve=no
//## end module%3E2F1BB70271.additionalIncludes

//## begin module%3E2F1BB70271.includes preserve=yes
// $Date:   Jan 23 2006 09:38:54  $ $Author:   D02405  $ $Revision:   1.4  $
//## end module%3E2F1BB70271.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;

} // namespace IF

//## begin module%3E2F1BB70271.declarations preserve=no
//## end module%3E2F1BB70271.declarations

//## begin module%3E2F1BB70271.additionalDeclarations preserve=yes
//## end module%3E2F1BB70271.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::CommandMessage%3E2F1AC60177.preface preserve=yes
//## end IF::CommandMessage%3E2F1AC60177.preface

//## Class: CommandMessage%3E2F1AC60177
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E35558000AB;Queue { -> F}

class DllExport CommandMessage : public Message  //## Inherits: <unnamed>%3E2F1B6300CB
{
  //## begin IF::CommandMessage%3E2F1AC60177.initialDeclarations preserve=yes
  //## end IF::CommandMessage%3E2F1AC60177.initialDeclarations

  public:
    //## Constructors (generated)
      CommandMessage();

      CommandMessage(const CommandMessage &right);

    //## Constructors (specified)
      //## Operation: CommandMessage%3E3556FD02BF
      CommandMessage (const string& strData1, const string& strData2);

    //## Destructor (generated)
      virtual ~CommandMessage();

    //## Assignment Operation (generated)
      CommandMessage & operator=(const CommandMessage &right);


    //## Other Operations (specified)
      //## Operation: execute%3E3553920399
      bool execute (const char* pszQueueName);

    // Additional Public Declarations
      //## begin IF::CommandMessage%3E2F1AC60177.public preserve=yes
      //## end IF::CommandMessage%3E2F1AC60177.public

  protected:
    // Additional Protected Declarations
      //## begin IF::CommandMessage%3E2F1AC60177.protected preserve=yes
      //## end IF::CommandMessage%3E2F1AC60177.protected

  private:
    // Additional Private Declarations
      //## begin IF::CommandMessage%3E2F1AC60177.private preserve=yes
      //## end IF::CommandMessage%3E2F1AC60177.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Data1%3E355D0E003E
      //## begin IF::CommandMessage::Data1%3E355D0E003E.attr preserve=no  private: string {U} 
      string m_strData1;
      //## end IF::CommandMessage::Data1%3E355D0E003E.attr

      //## Attribute: Data2%3E355D2700AB
      //## begin IF::CommandMessage::Data2%3E355D2700AB.attr preserve=no  private: string {U} 
      string m_strData2;
      //## end IF::CommandMessage::Data2%3E355D2700AB.attr

    // Additional Implementation Declarations
      //## begin IF::CommandMessage%3E2F1AC60177.implementation preserve=yes
      //## end IF::CommandMessage%3E2F1AC60177.implementation

};

//## begin IF::CommandMessage%3E2F1AC60177.postscript preserve=yes
//## end IF::CommandMessage%3E2F1AC60177.postscript

} // namespace IF

//## begin module%3E2F1BB70271.epilog preserve=yes
using namespace IF;
//## end module%3E2F1BB70271.epilog


#endif
