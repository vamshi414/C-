//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3AAA898C020C.cm preserve=no
//	$Date:   Dec 04 2019 13:53:30  $ $Author:   e1009652  $ $Revision:   1.41  $
//## end module%3AAA898C020C.cm

//## begin module%3AAA898C020C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3AAA898C020C.cp

//## Module: CXOSIF39%3AAA898C020C; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF39.hpp

#ifndef CXOSIF39_h
#define CXOSIF39_h 1

//## begin module%3AAA898C020C.additionalIncludes preserve=no
//## end module%3AAA898C020C.additionalIncludes

//## begin module%3AAA898C020C.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#include <Ws2tcpip.h>
#else
#include <unistd.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>
#endif
//## end module%3AAA898C020C.includes

#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Sleep;
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Signal;
class Buffer;
class CriticalSection;
} // namespace reusable

namespace IF {
class Trace;
class SignalList;

} // namespace IF

//## begin module%3AAA898C020C.declarations preserve=no
//## end module%3AAA898C020C.declarations

//## begin module%3AAA898C020C.additionalDeclarations preserve=yes
//## end module%3AAA898C020C.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::SocketQueue%3AAA88A20102.preface preserve=yes
//## end IF::SocketQueue%3AAA88A20102.preface

//## Class: SocketQueue%3AAA88A20102
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3AAA913A010F;Message { -> }
//## Uses: <unnamed>%3AAA91F003CE;reusable::Signal { -> F}
//## Uses: <unnamed>%3AB65EE200FC;Extract { -> F}
//## Uses: <unnamed>%3AC4714F0263;Trace { -> F}
//## Uses: <unnamed>%4CC70992026B;reusable::Buffer { -> F}
//## Uses: <unnamed>%4CC709DF00C4;Sleep { -> F}
//## Uses: <unnamed>%4CC70AB402E4;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%4CCAF76303C2;SignalList { -> F}
//## Uses: <unnamed>%4D1353AC011C;CodeTable { -> F}

class DllExport SocketQueue : public Queue  //## Inherits: <unnamed>%3AAA88C500B2
{
  //## begin IF::SocketQueue%3AAA88A20102.initialDeclarations preserve=yes
  public:
   enum Interface
   {
      NORMAL,
      CRLF,
      HTTP,
      POST
   };
  //## end IF::SocketQueue%3AAA88A20102.initialDeclarations

  public:
    //## Constructors (generated)
      SocketQueue();

      SocketQueue(const SocketQueue &right);

    //## Constructors (specified)
      //## Operation: SocketQueue%3AAA8CAA02BE
      SocketQueue (const char* pszName);

    //## Destructor (generated)
      virtual ~SocketQueue();

    //## Assignment Operation (generated)
      SocketQueue & operator=(const SocketQueue &right);


    //## Other Operations (specified)
      //## Operation: accept%3AACB3500288
      bool accept ();

      //## Operation: add%3AAA970E02CD
      static void add (SocketQueue* pSocketQueue);

      //## Operation: close%3AAA8C2E0310
      virtual bool close ();

      //## Operation: closeConnections%3DCBDE280261
      static void closeConnections ();

      //## Operation: connect%3AACBC5902DE
      bool connect (bool bSecureMVS = false);

      //## Operation: exists%530F988302B0
      static bool exists (const string& strName);

      //## Operation: free%5AFFC8CF0196
      void free (IF::Message* pMessage);

      //## Operation: getQueueDepth%3EB928F50261
      static int getQueueDepth ();

      //## Operation: initialize%3E7C62780138
      static void initialize ();

      //## Operation: listen%4024E934008C
      virtual bool listen ();

      //## Operation: message%53879842004C
      IF::Message* message (int iBufferLength);

      //## Operation: open%3AAA8C3203B6
      virtual bool open ();

      //## Operation: open%4E979DD600FF
      bool open (const char* pszHost, const char* pszPort);

      //## Operation: poll%586EA71B0351
      bool poll ();

      //## Operation: poll%3F326CCE0138
      virtual bool poll (const char* pszName);

      //## Operation: pop%3EAE7F5C01F4
      static bool pop ();

      //## Operation: push%538793BC006F
      void push (IF::Message* pMessage, reusable::Signal* pSignal);

      //## Operation: receive%58B82DCF0302
      virtual size_t receive (void* pBuffer, size_t iLength);

      //## Operation: receive%3AAA9DD80091
      virtual bool receive ();

      //## Operation: receiveCRLF%58B81792027B
      bool receiveCRLF ();

      //## Operation: receiveHTTP%58B8179C0246
      bool receiveHTTP ();

      //## Operation: receiveNORMAL%58B8182200A3
      bool receiveNORMAL ();

      //## Operation: receivePOST%58B817AA0084
      bool receivePOST ();

      //## Operation: remove%3AB37E6E01A5
      static void remove (SocketQueue* pSocketQueue);

      //## Operation: send%58B83A9E03E4
      virtual size_t send (void* pBuffer, size_t iLength);

      //## Operation: send%3AAA8C62008A
      virtual bool send (Message* pMessage, enum MessageType nMessageType);

      //## Operation: setThread%3AB66502039F
      void setThread (int lThread);

      //## Operation: terminate%3DC97163036B
      static void terminate ();

      //## Operation: trace%3DCA7A89006D
      virtual void trace (int lPosition);

      //## Operation: trace%3D6A62C800FA
      void trace (const char* pszMethod, bool bCritical = false);

      //## Operation: update%3AAA8C670055
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Address%464380F201A5
      static const string& getAddress ();

      //## Attribute: ConnectionSocket%3AAA9F5801A2
      const int getConnectionSocket () const
      {
        //## begin IF::SocketQueue::getConnectionSocket%3AAA9F5801A2.get preserve=no
        return m_hConnectionSocket;
        //## end IF::SocketQueue::getConnectionSocket%3AAA9F5801A2.get
      }


      //## Attribute: Interface%58B815230189
      const enum Interface getInterface () const
      {
        //## begin IF::SocketQueue::getInterface%58B815230189.get preserve=no
        return m_nInterface;
        //## end IF::SocketQueue::getInterface%58B815230189.get
      }

      void setInterface (enum Interface value)
      {
        //## begin IF::SocketQueue::setInterface%58B815230189.set preserve=no
        m_nInterface = value;
        //## end IF::SocketQueue::setInterface%58B815230189.set
      }


      //## Attribute: ServerSocket%3AAA9F720362
      const int getServerSocket () const
      {
        //## begin IF::SocketQueue::getServerSocket%3AAA9F720362.get preserve=no
        return m_hServerSocket;
        //## end IF::SocketQueue::getServerSocket%3AAA9F720362.get
      }


      //## Attribute: Ticks%3AB39C320347
      const double getTicks () const
      {
        //## begin IF::SocketQueue::getTicks%3AB39C320347.get preserve=no
        return m_dTicks;
        //## end IF::SocketQueue::getTicks%3AB39C320347.get
      }


      //## Attribute: Timeout%5632712202F7
      const int& getTimeout () const
      {
        //## begin IF::SocketQueue::getTimeout%5632712202F7.get preserve=no
        return m_iTimeout;
        //## end IF::SocketQueue::getTimeout%5632712202F7.get
      }

      void setTimeout (const int& value)
      {
        //## begin IF::SocketQueue::setTimeout%5632712202F7.set preserve=no
        m_iTimeout = value;
        //## end IF::SocketQueue::setTimeout%5632712202F7.set
      }


    // Data Members for Class Attributes

      //## Attribute: FDs%586EA75501E4
      //## begin IF::SocketQueue::FDs%586EA75501E4.attr preserve=no  public: vector<struct pollfd> {RA} 0
      vector<struct pollfd> *m_pFDs;
      //## end IF::SocketQueue::FDs%586EA75501E4.attr

      //## Attribute: Thread%4D121FB503D7
      //## begin IF::SocketQueue::Thread%4D121FB503D7.attr preserve=no  public: static int {VA} 0
      static int m_iThread;
      //## end IF::SocketQueue::Thread%4D121FB503D7.attr

    // Additional Public Declarations
      //## begin IF::SocketQueue%3AAA88A20102.public preserve=yes
      bool sendPacket(char* p, int j);
      bool reportProgress(int iSent, int iTotal);
      int initRetryCount();
      int m_iRetryCount;
      //## end IF::SocketQueue%3AAA88A20102.public

  protected:

    //## Other Operations (specified)
      //## Operation: reportError%3AAAA43602E4
      //	Saves error information.
      bool reportError (const char* pszFunction, int lRC);

    // Data Members for Class Attributes

      //## begin IF::SocketQueue::Address%464380F201A5.attr preserve=no  public: static string {V} 
      static string m_strAddress;
      //## end IF::SocketQueue::Address%464380F201A5.attr

      //## Attribute: ClientAddress%3AACB0960216
      //	The address structure for the server.
      //## begin IF::SocketQueue::ClientAddress%3AACB0960216.attr preserve=no  protected: struct sockaddr_in {V} 
      struct sockaddr_in m_hClientAddress;
      //## end IF::SocketQueue::ClientAddress%3AACB0960216.attr

      //## begin IF::SocketQueue::ConnectionSocket%3AAA9F5801A2.attr preserve=no  public: int {V} -1
      int m_hConnectionSocket;
      //## end IF::SocketQueue::ConnectionSocket%3AAA9F5801A2.attr

      //## Attribute: Host%58B8771700F7
      //## begin IF::SocketQueue::Host%58B8771700F7.attr preserve=no  private: string {V} 
      string m_strHost;
      //## end IF::SocketQueue::Host%58B8771700F7.attr

      //## begin IF::SocketQueue::Interface%58B815230189.attr preserve=no  public: enum Interface {V} NORMAL
      enum Interface m_nInterface;
      //## end IF::SocketQueue::Interface%58B815230189.attr

      //## Attribute: Port%3AACB6960139
      //## begin IF::SocketQueue::Port%3AACB6960139.attr preserve=no  protected: unsigned short {V} 0
      unsigned short m_iPort;
      //## end IF::SocketQueue::Port%3AACB6960139.attr

      //## begin IF::SocketQueue::ServerSocket%3AAA9F720362.attr preserve=no  public: int {V} -1
      int m_hServerSocket;
      //## end IF::SocketQueue::ServerSocket%3AAA9F720362.attr

      //## Attribute: Sleep%45059A1403C8
      //## begin IF::SocketQueue::Sleep%45059A1403C8.attr preserve=no  private: string {V} 
      string m_strSleep;
      //## end IF::SocketQueue::Sleep%45059A1403C8.attr

      //## begin IF::SocketQueue::Ticks%3AB39C320347.attr preserve=no  public: double {V} 0
      double m_dTicks;
      //## end IF::SocketQueue::Ticks%3AB39C320347.attr

      //## begin IF::SocketQueue::Timeout%5632712202F7.attr preserve=no  public: int {U} 30
      int m_iTimeout;
      //## end IF::SocketQueue::Timeout%5632712202F7.attr

    // Additional Protected Declarations
      //## begin IF::SocketQueue%3AAA88A20102.protected preserve=yes
 #ifndef _WIN32
      pthread_t m_hThread;
#endif
      //## end IF::SocketQueue%3AAA88A20102.protected
  private:

    //## Other Operations (specified)
      //## Operation: charHexToInt%58F0E8130342
      int charHexToInt (const char* charHex, int iLength);

    // Additional Private Declarations
      //## begin IF::SocketQueue%3AAA88A20102.private preserve=yes
      //## end IF::SocketQueue%3AAA88A20102.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Count%48A447F40148
      //## begin IF::SocketQueue::Count%48A447F40148.attr preserve=no  private: static double {V} 0
      static double m_dCount;
      //## end IF::SocketQueue::Count%48A447F40148.attr

      //## Attribute: Error%3AAAA520033B
      //## begin IF::SocketQueue::Error%3AAAA520033B.attr preserve=no  private: string {V} 
      string m_strError;
      //## end IF::SocketQueue::Error%3AAAA520033B.attr

      //## Attribute: QueueDepth%58B876DD01B5
      //## begin IF::SocketQueue::QueueDepth%58B876DD01B5.attr preserve=no  private: static int {V} 0
      static int m_iQueueDepth;
      //## end IF::SocketQueue::QueueDepth%58B876DD01B5.attr

      //## Attribute: Quiesced%4722003A001F
      //## begin IF::SocketQueue::Quiesced%4722003A001F.attr preserve=no  private: static bool {V} false
      static bool m_bQuiesced;
      //## end IF::SocketQueue::Quiesced%4722003A001F.attr

      //## Attribute: Server%3AAA9F40023E
      //## begin IF::SocketQueue::Server%3AAA9F40023E.attr preserve=no  private: bool {V} true
      bool m_bServer;
      //## end IF::SocketQueue::Server%3AAA9F40023E.attr

      //## Attribute: ServerAddress%3AAAA46300AE
      //	The address structure for the server.
      //## begin IF::SocketQueue::ServerAddress%3AAAA46300AE.attr preserve=no  private: struct sockaddr_in {V} 
      struct sockaddr_in m_hServerAddress;
      //## end IF::SocketQueue::ServerAddress%3AAAA46300AE.attr

    // Data Members for Associations

      //## Association: Connex Library::IF_CAT::<unnamed>%40251FEC02AF
      //## Role: SocketQueue::<m_pApplicationQueue>%40251FED004E
      //## begin IF::SocketQueue::<m_pApplicationQueue>%40251FED004E.role preserve=no  public: static IF::SocketQueue { -> RFHgN}
      static SocketQueue *m_pApplicationQueue;
      //## end IF::SocketQueue::<m_pApplicationQueue>%40251FED004E.role

    // Additional Implementation Declarations
      //## begin IF::SocketQueue%3AAA88A20102.implementation preserve=yes
      static bool m_bCout;
      //## end IF::SocketQueue%3AAA88A20102.implementation
};

//## begin IF::SocketQueue%3AAA88A20102.postscript preserve=yes
//## end IF::SocketQueue%3AAA88A20102.postscript

} // namespace IF

//## begin module%3AAA898C020C.epilog preserve=yes
using namespace IF;
//## end module%3AAA898C020C.epilog


#endif
