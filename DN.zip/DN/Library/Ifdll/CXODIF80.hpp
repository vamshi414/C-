//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5367E0850183.cm preserve=no
//	$Date:   May 09 2014 15:55:20  $ $Author:   e1009591  $ $Revision:   1.0  $
//## end module%5367E0850183.cm

//## begin module%5367E0850183.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5367E0850183.cp

//## Module: CXOSIF80%5367E0850183; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.4B.R007\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF80.hpp

#ifndef CXOSIF80_h
#define CXOSIF80_h 1

//## begin module%5367E0850183.additionalIncludes preserve=no
//## end module%5367E0850183.additionalIncludes

//## begin module%5367E0850183.includes preserve=yes
#include <map>
#include <set>
//## end module%5367E0850183.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;

} // namespace IF

//## begin module%5367E0850183.declarations preserve=no
//## end module%5367E0850183.declarations

//## begin module%5367E0850183.additionalDeclarations preserve=yes
//## end module%5367E0850183.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Resource%5367E06303A6.preface preserve=yes
//## end IF::Resource%5367E06303A6.preface

//## Class: Resource%5367E06303A6
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5367F23A00C7;FlatFile { -> F}

class DllExport Resource : public reusable::Object  //## Inherits: <unnamed>%5367F20A031C
{
  //## begin IF::Resource%5367E06303A6.initialDeclarations preserve=yes
  //## end IF::Resource%5367E06303A6.initialDeclarations

  public:
    //## Constructors (generated)
      Resource();

    //## Destructor (generated)
      virtual ~Resource();


    //## Other Operations (specified)
      //## Operation: instance%5367F3B602D1
      static Resource* instance ();

      //## Operation: getText%536801EF0353
      bool getText (const string& strKey, string& strText);

    // Additional Public Declarations
      //## begin IF::Resource%5367E06303A6.public preserve=yes
      //## end IF::Resource%5367E06303A6.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Resource%5367E06303A6.protected preserve=yes
      //## end IF::Resource%5367E06303A6.protected

  private:
    // Additional Private Declarations
      //## begin IF::Resource%5367E06303A6.private preserve=yes
      //## end IF::Resource%5367E06303A6.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5367F4790131
      //## begin IF::Resource::Instance%5367F4790131.attr preserve=no  private: static Resource* {V} 0
      static Resource* m_pInstance;
      //## end IF::Resource::Instance%5367F4790131.attr

    // Additional Implementation Declarations
      //## begin IF::Resource%5367E06303A6.implementation preserve=yes
	  map<string,string,less<string> > m_hResource;
      //## end IF::Resource%5367E06303A6.implementation

};

//## begin IF::Resource%5367E06303A6.postscript preserve=yes
//## end IF::Resource%5367E06303A6.postscript

} // namespace IF

//## begin module%5367E0850183.epilog preserve=yes
//## end module%5367E0850183.epilog


#endif
