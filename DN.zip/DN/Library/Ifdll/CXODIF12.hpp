//  Copyright (c) 1998 - 2017
//  FIS
// $Date:   Jun 21 2017 15:43:16  $ $Author:   e1009839  $ $Revision:   1.14  $

#ifndef CXODIF12_HPP
#define CXODIF12_HPP

// GDM Header (asm version CXBDDM03)
#include "CXODRU32.hpp"
struct hGDMHeader
{
   unsigned short siTotalMessageLength;
   char sDescription[4];
   unsigned short siTotalHeaderLength;
   char cConcatenation;
   char sType[2];
   char sVersion[2];
   unsigned short siLengthOfFormatTwoArea;
   unsigned short siSubAreaLength;
   char sReferenceNumber[8];
   char sDate[8]; // YYYYMMDD
   char sTime[6]; // HHMMSS
   char sPriority[2];
   unsigned short siTotalDataAreaLength;
   unsigned short siDataLength1;
   short siDataElement1;
   char sData1[8];
   unsigned short siDataLength2;
   short siDataElement2;
   char sData2[52];
};
// Connex standard header (asm version CXCDSISH)
struct hStandardHeader
{
   unsigned short siTotalHeaderLength;
   unsigned short siLength;
   char sFormat[2];
   char sSenderID[3];
   char sReceiverID[3];
#ifdef _WIN32
#ifndef _WIN64
   long lAddress1;
#endif
#endif
   void* pSenderCBAddress;
   char sSenderSTCKValue[8];
#ifdef _WIN32
#ifndef _WIN64
   long lAddress2;
#endif
#endif
   void* pReceiverCBAddress;
   char sReceiverSTCKValue[8];
   short siResponsePriority;
   char sMessageID[5];
   char cMessageType;
   char sFiller[8];
};
// Connex unique header
struct hUniqueHeader
{
   unsigned short siLength;
   char sFormat[2];
};
// Connex data
struct hData
{
   unsigned short siLength;
   char sText[1];
};
struct hData2
{
   unsigned int iLength;
   char sText[1];
};
#include "CXODRU33.hpp"

#endif
