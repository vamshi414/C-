//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%491EECDD0261.cm preserve=no
//## end module%491EECDD0261.cm

//## begin module%491EECDD0261.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%491EECDD0261.cp

//## Module: CXOSIF51%491EECDD0261; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF51.hpp

#ifndef CXOSIF51_h
#define CXOSIF51_h 1

//## begin module%491EECDD0261.additionalIncludes preserve=no
//## end module%491EECDD0261.additionalIncludes

//## begin module%491EECDD0261.includes preserve=yes
//## end module%491EECDD0261.includes

#ifndef CXOSIF50_h
#include "CXODIF50.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class SecondaryCodes;
class SiteSpecification;
class Extract;

} // namespace IF

//## begin module%491EECDD0261.declarations preserve=no
//## end module%491EECDD0261.declarations

//## begin module%491EECDD0261.additionalDeclarations preserve=yes
//## end module%491EECDD0261.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::UnixFile%491EEC6B0109.preface preserve=yes
//## end IF::UnixFile%491EEC6B0109.preface

//## Class: UnixFile%491EEC6B0109
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%491EFBCB037A;Extract { -> F}
//## Uses: <unnamed>%491EFBCD0399;Trace { -> F}
//## Uses: <unnamed>%491EFBCF03A9;SecondaryCodes { -> F}
//## Uses: <unnamed>%491EFBD2005D;reusable::Transaction { -> F}
//## Uses: <unnamed>%491EFBD6007D;SiteSpecification { -> F}
//## Uses: <unnamed>%63F4FB5D0145;reusable::Buffer { -> F}

class DllExport UnixFile : public File  //## Inherits: <unnamed>%491EEC80000F
{
  //## begin IF::UnixFile%491EEC6B0109.initialDeclarations preserve=yes
  //## end IF::UnixFile%491EEC6B0109.initialDeclarations

  public:
    //## Constructors (generated)
      UnixFile();

    //## Constructors (specified)
      //## Operation: UnixFile%491EEFC3008C
      UnixFile (const char* pszName, const char* pszMember);

      //## Operation: UnixFile%491EEFC500CB
      UnixFile (const char* pszName);

    //## Destructor (generated)
      virtual ~UnixFile();


    //## Other Operations (specified)
      //## Operation: close%65F841BA033D
      virtual bool close ();

      //## Operation: copy%4C519DBD029D
      virtual bool copy (const char* pszTarget, const char* pszOutputFileName = 0);

      //## Operation: getBaseName%4C507E660342
      virtual bool getBaseName (string& strBaseName, bool bIncludeExtension = false);

      //## Operation: isFolderEmpty%63F4FAFD00F5
      static bool isFolderEmpty (const char* pszFolder);

      //## Operation: match%63F4FA5202C6
      static bool match (const reusable::string& strPath, const string& strPattern);

      //## Operation: move%491EF45B0186
      virtual bool move (const char* pszTarget, const char* pszOutputFileName = 0);

      //## Operation: open%491EF8B2006D
      virtual bool open (enum OpenType nOpenType = CX_OPEN_INPUT);

      //## Operation: pick%65B26F820170
      static bool pick (const char* pszFolder, reusable::string& strDatasetName);

      //## Operation: purge%496DFDA6036B
      static void purge (const char* pszFolder, const string& strPeriod);

      //## Operation: purgeFolder%4C6952180313
      static void purgeFolder (const char* pszFolder, const string& strPeriod);

      //## Operation: remove%491EF55702EE
      virtual bool remove ();

      //## Operation: unzip%4C69537200F8
      virtual bool unzip ();

      //## Operation: write%491EF80601A5
      virtual bool write (char* psBuffer, int lRecordLength);

      //## Operation: zip%4C69537B00F8
      virtual bool zip (const string& strArchiveName);

    // Additional Public Declarations
      //## begin IF::UnixFile%491EEC6B0109.public preserve=yes
      //## end IF::UnixFile%491EEC6B0109.public

  protected:
    // Additional Protected Declarations
      //## begin IF::UnixFile%491EEC6B0109.protected preserve=yes
      //## end IF::UnixFile%491EEC6B0109.protected

  private:
    // Additional Private Declarations
      //## begin IF::UnixFile%491EEC6B0109.private preserve=yes
      //## end IF::UnixFile%491EEC6B0109.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::UnixFile%491EEC6B0109.implementation preserve=yes
      //## end IF::UnixFile%491EEC6B0109.implementation

};

//## begin IF::UnixFile%491EEC6B0109.postscript preserve=yes
//## end IF::UnixFile%491EEC6B0109.postscript

} // namespace IF

//## begin module%491EECDD0261.epilog preserve=yes
//## end module%491EECDD0261.epilog


#endif
