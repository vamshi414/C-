// Copyright (c) 1998 - 2016
// FIS
// $Date:   May 15 2020 09:01:04  $ $Author:   e1009510  $ $Revision:   1.10  $
#ifdef MVS
extern "OS"
{
DllExport int CXALRM(const char* psContext,const char* psTime,int* plRC);
DllExport int CXAON(const char* pszName,int* plRC);
DllExport int CXATOE(unsigned char* psBuffer,unsigned int* plBufferLength,int* plRC);
DllExport int CXAVS(char** ppsMemory,int* plLength,int* plRC);
DllExport int CXCTMR(const char* psContext,int* plRC);
DllExport int CXCTTS(const char* psTimestamp,char* psDateTime,int* plRC);
DllExport int CXDON(const char* pszName,int* plRC);
DllExport int CXDUMP(int* plUserCompletionCode,int* plRC);
DllExport int CXEFDN(const char* psName,char* psDatasetName,int* pLRC);
DllExport int CXESC(char* pszSecondaryCodes,int* plRC);
DllExport int CXETOA(unsigned char* psBuffer,unsigned int* plBufferLength,int* plRC);
DllExport int CXFVS(char** ppsMemory,int* plRC);
DllExport int CXGTN(char* psName,int* plRC);
DllExport int CXGTS(char* psDateTime,char* psStck,int* plRC);
#ifdef _WIN64
DllExport int CXICLS(long long* plFile,int* plRC);
DllExport int CXIGET(long long* plFile,char* psBuffer,int* plBufferLength,int* plRecordLength,int* plRC);
DllExport int CXIOPN(const char* psName,long long* plFile,int* plRC);
DllExport int CXIPUT(long long* plFile,char* psBuffer,int* plRecordLength,int* plRC);
DllExport int CXSFAO(long long* plFile,int* plOption,int* plRC);
#else
DllExport int CXICLS(long* plFile,int* plRC);
DllExport int CXIGET(long* plFile,char* psBuffer,int* plBufferLength,int* plRecordLength,int* plRC);
DllExport int CXIOPN(const char* psName,long* plFile,int* plRC);
DllExport int CXIPUT(long* plFile,char* psBuffer,int* plRecordLength,int* plRC);
DllExport int CXSFAO(long* plFile,int* plOption,int* plRC);
#endif
DllExport int CXINIT(char* psImage,char* psName,int* plRC);
DllExport int CXLOG(const char* psBuffer,int* plBufferLength,const char* psCBEKey,const char* psMessageID,const char* psReason,const char* psDestination,const char* psStation,const char* psLUName,int* plRC);
DllExport int CXQDEP(int* piQueueDepth,int* piRC);
DllExport int CXQGET(char* psBuffer,char* psQueueName,int* plBufferLength,int* plMessageLength,int* plRC);
DllExport int CXQOBS(const char* pszQueueName,int* plRC);
DllExport int CXQPUT(const char* psBuffer,const char* psQueueName,int* plMessageLength,int* plRC);
DllExport int CXQWFM(int* plSignalCount,int* plSignals,int* plRC);
DllExport int CXSDPO(int* plOption,int* plRC);
DllExport int CXSDRO(int* plOption,int* plRC);
DllExport int CXSDTO(int* plOption,int* plRC);
DllExport int CXSFDN(const char* psName,const char* psDatasetName,int* plRC);
DllExport int CXSFMN(const char* psName,const char* psMember,int* plRC);
DllExport int CXSFOO(int* plOption,int* plRC);
DllExport int CXSJOB(const char* psMember,...);
DllExport int CXSONL(int* plLength,int* plRC);
DllExport int CXSONT(int* plType,int* plRC);
DllExport int CXSPPS(int* plPSWProblemState,int* plRC);
DllExport int CXSQR(int* plRC);
DllExport int CXSQWO(int* plOption,int* plRC);
DllExport int CXSRR(int* plRC);
DllExport int CXSSAM(int* plLocation,int* plRC);
DllExport int CXSTMR(const char* psContext,const char* psInterval,int* plRC);
DllExport int CXSTN(const char* psName,int* plRC);
DllExport int CXQRFM(int* plRC);
DllExport int CXTADJ(char* psDate,char* psTime,int* plOffset,int* plRC);
DllExport int CXTERM(int* plRC);
DllExport int CXWTR(const char* psBuffer,unsigned int* plBufferLength,int* plRC);
}
#endif
