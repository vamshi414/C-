//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35BF63F800F5.cm preserve=no
//## end module%35BF63F800F5.cm

//## begin module%35BF63F800F5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%35BF63F800F5.cp

//## Module: CXOSIF03%35BF63F800F5; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF03.cpp

//## begin module%35BF63F800F5.additionalIncludes preserve=no
//## end module%35BF63F800F5.additionalIncludes

//## begin module%35BF63F800F5.includes preserve=yes
#include "CXODRU29.hpp"
//## end module%35BF63F800F5.includes

#ifndef CXOSRU37_h
#include "CXODRU37.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSRU55_h
#include "CXODRU55.hpp"
#endif
#ifndef CXOSIF82_h
#include "CXODIF82.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif


//## begin module%35BF63F800F5.declarations preserve=no
//## end module%35BF63F800F5.declarations

//## begin module%35BF63F800F5.additionalDeclarations preserve=yes
//## end module%35BF63F800F5.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Trace 

//## begin IF::Trace::Trace_i%5AE0A1550392.attr preserve=no  private: static vector<Trace_i>* {V} 0
vector<Trace_i>* Trace::m_pTrace_i = 0;
//## end IF::Trace::Trace_i%5AE0A1550392.attr

Trace::Trace()
  //## begin Trace::Trace%347C8C3A019D_const.hasinit preserve=no
  //## end Trace::Trace%347C8C3A019D_const.hasinit
  //## begin Trace::Trace%347C8C3A019D_const.initialization preserve=yes
  //## end Trace::Trace%347C8C3A019D_const.initialization
{
  //## begin IF::Trace::Trace%347C8C3A019D_const.body preserve=yes
  //## end IF::Trace::Trace%347C8C3A019D_const.body
}


Trace::~Trace()
{
  //## begin IF::Trace::~Trace%347C8C3A019D_dest.body preserve=yes
  //## end IF::Trace::~Trace%347C8C3A019D_dest.body
}



//## Other Operations (implementation)
const bool Trace::getEnable ()
{
  //## begin IF::Trace::getEnable%499B1F060201.body preserve=yes
   return Trace_i::getEnable();
  //## end IF::Trace::getEnable%499B1F060201.body
}

Trace_i& Trace::getInstance ()
{
  //## begin IF::Trace::getInstance%5AE0801403E4.body preserve=yes
   CriticalSection hCriticalSection;
   if (!m_pTrace_i)
   {
      m_pTrace_i = new vector<Trace_i>;
      m_pTrace_i->reserve(CXTHREADS);
      Trace_i x;
      for (int i = 0;i <= reusable::Thread::getTotal();++i)
         m_pTrace_i->push_back(x);
   }
   int i = reusable::Thread::getNumber();
   while (m_pTrace_i->size() < (i + 1))
   {
      Trace_i x;
      m_pTrace_i->push_back(x);
   }
   return (*m_pTrace_i)[i];
  //## end IF::Trace::getInstance%5AE0801403E4.body
}

const string& Trace::getTemplate ()
{
  //## begin IF::Trace::getTemplate%650A021A0160.body preserve=yes
   return getInstance().getTemplate();
  //## end IF::Trace::getTemplate%650A021A0160.body
}

void Trace::initialize ()
{
  //## begin IF::Trace::initialize%6509F3D50066.body preserve=yes
   getInstance().initialize();
  //## end IF::Trace::initialize%6509F3D50066.body
}

void Trace::put (const char* pszFile, unsigned int ulLine, const char* psBuffer, size_t lBuffer, bool bCritical)
{
  //## begin IF::Trace::put%347C91DA0107.body preserve=yes
   if (bCritical == false
      && Trace_i::getEnable() == false)
      return;
   getInstance().put(pszFile,ulLine,psBuffer,lBuffer);
  //## end IF::Trace::put%347C91DA0107.body
}

void Trace::put (const char* psBuffer, size_t lBuffer, bool bCritical)
{
  //## begin IF::Trace::put%347C91D2017E.body preserve=yes
   if (bCritical == false
      && Trace_i::getEnable() == false)
      return;
   getInstance().put(psBuffer,lBuffer);
  //## end IF::Trace::put%347C91D2017E.body
}

void Trace::put (const char* pszText, const string& strBuffer, bool bCritical)
{
  //## begin IF::Trace::put%530F89AE0201.body preserve=yes
   if (bCritical == false
      && Trace_i::getEnable() == false)
      return;
   getInstance().put(pszText,strBuffer);
  //## end IF::Trace::put%530F89AE0201.body
}

void Trace::putHex (const char* psBuffer, int lBuffer, bool bCritical)
{
  //## begin IF::Trace::putHex%41E81CC20261.body preserve=yes
   if (bCritical == false
      && Trace_i::getEnable() == false)
      return;
   getInstance().putHex(psBuffer,lBuffer);
  //## end IF::Trace::putHex%41E81CC20261.body
}

void Trace::setEnable (bool value)
{
  //## begin IF::Trace::setEnable%5AE074260246.body preserve=yes
   Trace_i::setEnable(value);
  //## end IF::Trace::setEnable%5AE074260246.body
}

void Trace::terminate ()
{
  //## begin IF::Trace::terminate%3F0196530196.body preserve=yes
   getInstance().terminate();
  //## end IF::Trace::terminate%3F0196530196.body
}

// Additional Declarations
  //## begin IF::Trace%347C8C3A019D.declarations preserve=yes
  //## end IF::Trace%347C8C3A019D.declarations

} // namespace IF

//## begin module%35BF63F800F5.epilog preserve=yes
//## end module%35BF63F800F5.epilog


