//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35A240160126.cm preserve=no
//	$Date:   Jun 24 2021 11:10:56  $ $Author:   e1014059  $ $Revision:   1.31  $
//## end module%35A240160126.cm

//## begin module%35A240160126.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%35A240160126.cp

//## Module: CXOSIF22%35A240160126; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.4B.R001\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF22.cpp

//## begin module%35A240160126.additionalIncludes preserve=no
//## end module%35A240160126.additionalIncludes

//## begin module%35A240160126.includes preserve=yes
//## end module%35A240160126.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif


//## begin module%35A240160126.declarations preserve=no
//## end module%35A240160126.declarations

//## begin module%35A240160126.additionalDeclarations preserve=yes
#include "CXODIF13.hpp"
map<string,Queue*,less<string> >* Queue::m_pQueue = 0;
//## end module%35A240160126.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Queue

Queue::Queue()
  //## begin Queue::Queue%34A4155701BD_const.hasinit preserve=no
      : m_lThread(0),
        m_pSignal(0)
  //## end Queue::Queue%34A4155701BD_const.hasinit
  //## begin Queue::Queue%34A4155701BD_const.initialization preserve=yes
  //## end Queue::Queue%34A4155701BD_const.initialization
{
  //## begin IF::Queue::Queue%34A4155701BD_const.body preserve=yes
   memcpy(m_sID,"IF22",4);
  //## end IF::Queue::Queue%34A4155701BD_const.body
}

Queue::Queue(const Queue &right)
  //## begin Queue::Queue%34A4155701BD_copy.hasinit preserve=no
  //## end Queue::Queue%34A4155701BD_copy.hasinit
  //## begin Queue::Queue%34A4155701BD_copy.initialization preserve=yes
   : Observer(right)
  //## end Queue::Queue%34A4155701BD_copy.initialization
{
  //## begin IF::Queue::Queue%34A4155701BD_copy.body preserve=yes
   m_strName = right.m_strName;
   m_strRealName = right.m_strRealName;
#ifdef MVS
   m_pSignal = 0;
#else
   m_pSignal = right.m_pSignal;
#endif
   m_lThread = right.m_lThread;
  //## end IF::Queue::Queue%34A4155701BD_copy.body
}

Queue::Queue (const char* pszName)
  //## begin IF::Queue::Queue%36DE90A5037F.hasinit preserve=no
      : m_lThread(0),
        m_pSignal(0)
  //## end IF::Queue::Queue%36DE90A5037F.hasinit
  //## begin IF::Queue::Queue%36DE90A5037F.initialization preserve=yes
   ,m_strName(pszName)
  //## end IF::Queue::Queue%36DE90A5037F.initialization
{
  //## begin IF::Queue::Queue%36DE90A5037F.body preserve=yes
   memcpy(m_sID,"IF22",4);
  //## end IF::Queue::Queue%36DE90A5037F.body
}


Queue::~Queue()
{
  //## begin IF::Queue::~Queue%34A4155701BD_dest.body preserve=yes
   CriticalSection hCriticalSection;
   if (m_pQueue)
   {
      map<string,Queue*,less<string> >::iterator pQueue = m_pQueue->begin();
      while (pQueue != m_pQueue->end())
      {
         Queue* p = (*pQueue).second;
         if (p == this)
         {
            m_pQueue->erase(pQueue);
            pQueue = m_pQueue->begin();
         }
         else
            ++pQueue;
      }
   }
  //## end IF::Queue::~Queue%34A4155701BD_dest.body
}



//## Other Operations (implementation)
int Queue::attach (const char* pszName, enum ObjectType nObjectType)
{
  //## begin IF::Queue::attach%34A4159801D4.body preserve=yes
   int lRC = 0;
   int m = 0;
   int n = 0;
   string strName(queueName(pszName));
   if ((m = (int)strName.length()) > 8)
#ifdef MVS
      CXSONL(&m,&lRC);
#endif
   if (lRC == 0)
   {
      // set object name type
      m = (int)nObjectType;
#ifdef MVS
      CXSONT(&m,&lRC);
      // add object name
      if (lRC == 0)
         CXAON(strName.data(),&lRC);
#endif
   }
   m = 8;
#ifdef MVS
   CXSONL(&m,&n);
#endif
   return lRC;
  //## end IF::Queue::attach%34A4159801D4.body
}

void Queue::close (const string& strName)
{
  //## begin IF::Queue::close%515AFC9C03A0.body preserve=yes
   if (m_pQueue)
   {
      map<string,Queue*,less<string> >::iterator p = m_pQueue->find(strName);
      if (p != m_pQueue->end())
         (*p).second->close();
   }
  //## end IF::Queue::close%515AFC9C03A0.body
}

int Queue::detach (const char* pszName)
{
  //## begin IF::Queue::detach%34A415A30202.body preserve=yes
   int lRC = 0;
#ifdef MVS
   int m = 0;
   int n = 0;
   string strName(queueName(pszName));
   if ((m = (int)strName.length()) > 8)
      CXSONL(&m,&lRC);
   if (lRC == 0)
      // delete object name
      CXDON(strName.data(),&lRC);
   m = 8;
   CXSONL(&m,&n);
#endif
   return lRC;
  //## end IF::Queue::detach%34A415A30202.body
}

void Queue::insert (const string&  strName, IF::Queue* pQueue)
{
  //## begin IF::Queue::insert%4CC7036003E7.body preserve=yes
   if (!m_pQueue)
      m_pQueue = new map<string,Queue*,less<string> >;
   map<string,Queue*,less<string> >::iterator p = m_pQueue->find(strName);
   if (p == m_pQueue->end())
      m_pQueue->insert(map<string,Queue*,less<string> >::value_type(strName,pQueue));
  //## end IF::Queue::insert%4CC7036003E7.body
}

bool Queue::listen ()
{
  //## begin IF::Queue::listen%4024E915000F.body preserve=yes
   return false;
  //## end IF::Queue::listen%4024E915000F.body
}

bool Queue::listen (const char* pszName)
{
  //## begin IF::Queue::listen%4024E72802BF.body preserve=yes
   if (m_pQueue)
   {
      string strName(queueName(pszName));
      map<string,Queue*,less<string> >::iterator pQueue = m_pQueue->find(strName);
      if (pQueue != m_pQueue->end())
         return (*pQueue).second->listen();
   }
   return false;
  //## end IF::Queue::listen%4024E72802BF.body
}

Queue* Queue::locate (const string& strRealName)
{
  //## begin IF::Queue::locate%36EE7C2F0234.body preserve=yes
   if (!m_pQueue)
      m_pQueue = new map<string,Queue*,less<string> >;
   map<string,Queue*,less<string> >::iterator pQueue;
   for (pQueue = m_pQueue->begin();pQueue != m_pQueue->end();++pQueue)
      if ((*pQueue).second->getRealName() == strRealName)
         return (*pQueue).second;
   Queue* p = (Queue*)QueueFactory::instance()->create("Queue",strRealName.c_str());
   m_pQueue->insert(map<string,Queue*,less<string> >::value_type(strRealName,p));
   return p;
  //## end IF::Queue::locate%36EE7C2F0234.body
}

int Queue::observe (const char* pszName)
{
  //## begin IF::Queue::observe%36DA96EB015F.body preserve=yes
   int lRC = 0;
   string strName = queueName(pszName);
#ifdef MVS
   CXQOBS(strName.data(),&lRC);
#endif
   return lRC;
  //## end IF::Queue::observe%36DA96EB015F.body
}

string Queue::queueName (const char* pszName)
{
  //## begin IF::Queue::queueName%36DA971101E6.body preserve=yes
   // replace ##
   string strBuffer(pszName);
   size_t n = strBuffer.find("##");
   if (n != string::npos)
   {
#ifdef MVS
      char sName[7];
      int lRC;
      CXGTN(sName,&lRC);
      strBuffer.replace(n,2,sName,2);
#else
      strBuffer.replace(n,2,Extract::instance()->getName().substr(0,2));
      if (strBuffer[0] == '@')
         strBuffer.erase(0,1);
#endif
   }
   if (strBuffer.length() < 8)
      strBuffer.resize(8,' ');
   return strBuffer;
  //## end IF::Queue::queueName%36DA971101E6.body
}

bool Queue::reply (int lThread, Message* pMessage, enum MessageType nMessageType)
{
  //## begin IF::Queue::reply%4023E1C6005D.body preserve=yes
   if (m_pQueue)
   {
      map<string,Queue*,less<string> >::iterator pQueue;
      for (pQueue = m_pQueue->begin();pQueue != m_pQueue->end();++pQueue)
         if ((*pQueue).second->getThread() == lThread)
            return (*pQueue).second->send(pMessage,nMessageType);
   }
   return false;
  //## end IF::Queue::reply%4023E1C6005D.body
}

bool Queue::send (const char* pszName, Message* pMessage, enum MessageType nMessageType)
{
  //## begin IF::Queue::send%36DDB00F02A4.body preserve=yes
   string strName(queueName(pszName));
   Trace::put("Message to:",strName);
   Trace::putHex(pMessage->buffer(),pMessage->messageLength());
   if (nMessageType == Queue::COMMAND)
   {
      Queue* p = (Queue*)QueueFactory::instance()->create("Queue", strName.c_str());
      bool b = p->send(pMessage, DATAGRAM);
      delete p;
      return b;
   }
   CriticalSection hCriticalSection;
   if (!m_pQueue)
      m_pQueue = new map<string,Queue*,less<string> >;
   map<string,Queue*,less<string> >::iterator pQueue = m_pQueue->find(strName);
   if (pQueue == m_pQueue->end())
   {
      Queue* p = (Queue*)QueueFactory::instance()->create("Queue",strName.c_str());
      if (p->send(pMessage,nMessageType))
      {
         m_pQueue->insert(map<string,Queue*,less<string> >::value_type(strName,p));
         return true;
      }
      delete p;
      return false;
   }
   return (*pQueue).second->send(pMessage,nMessageType);
  //## end IF::Queue::send%36DDB00F02A4.body
}

void Queue::terminate ()
{
  //## begin IF::Queue::terminate%36DEA4F0031B.body preserve=yes
   CriticalSection hCriticalSection;
   if (!m_pQueue)
      return;
   map<string,Queue*,less<string> >::iterator pQueue = m_pQueue->begin();
   while (pQueue != m_pQueue->end())
   {
      Queue* p = (*pQueue).second;
      ++pQueue;
      p->close();
   }
  //## end IF::Queue::terminate%36DEA4F0031B.body
}

void Queue::trace (int lPosition)
{
  //## begin IF::Queue::trace%3DCA779E033C.body preserve=yes
  //## end IF::Queue::trace%3DCA779E033C.body
}

int Queue::traceAll ()
{
  //## begin IF::Queue::traceAll%3DCA7996001F.body preserve=yes
   CriticalSection hCriticalSection;
   if (!m_pQueue)
      return 0;
   Trace::put("Connections:");
   int lPosition = 0;
   map<string,Queue*,less<string> >::iterator pQueue;
   for (pQueue = m_pQueue->begin();pQueue != m_pQueue->end();++pQueue)
   {
      Trace::put((*pQueue).first.c_str());
      (*pQueue).second->trace(lPosition++);
   }
   return (int)m_pQueue->size();
  //## end IF::Queue::traceAll%3DCA7996001F.body
}

// Additional Declarations
  //## begin IF::Queue%34A4155701BD.declarations preserve=yes
  //## end IF::Queue%34A4155701BD.declarations

} // namespace IF

//## begin module%35A240160126.epilog preserve=yes
//## end module%35A240160126.epilog
