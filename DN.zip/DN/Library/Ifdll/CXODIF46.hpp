//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%41AB78E30157.cm preserve=no
//	$Date:   Jan 31 2017 13:38:50  $ $Author:   e1009510  $
//	$Revision:   1.3.1.0  $
//## end module%41AB78E30157.cm

//## begin module%41AB78E30157.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%41AB78E30157.cp

//## Module: CXOSIF46%41AB78E30157; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF46.hpp

#ifndef CXOSIF46_h
#define CXOSIF46_h 1

//## begin module%41AB78E30157.additionalIncludes preserve=no
//## end module%41AB78E30157.additionalIncludes

//## begin module%41AB78E30157.includes preserve=yes
// $Date:   Jan 31 2017 13:38:50  $ $Author:   e1009510  $ $Revision:   1.3.1.0  $
#include <map>
//## end module%41AB78E30157.includes

#ifndef CXOSRU01_h
#include "CXODRU01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class ExternalQueueFactory;

} // namespace IF

//## begin module%41AB78E30157.declarations preserve=no
//## end module%41AB78E30157.declarations

//## begin module%41AB78E30157.additionalDeclarations preserve=yes
//## end module%41AB78E30157.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::QueueManager%41AB603B0157.preface preserve=yes
//## end IF::QueueManager%41AB603B0157.preface

//## Class: QueueManager%41AB603B0157
//	This class is the common base class for MqQueueManager
//	and TableQueueManager
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%41AD0A5D03C8;ExternalQueueFactory { -> F}

class DllExport QueueManager : public reusable::Subject  //## Inherits: <unnamed>%41AB603B0177
{
  //## begin IF::QueueManager%41AB603B0157.initialDeclarations preserve=yes
  public:
  enum QueueManagerState
   {
      CONNECTED,
      DISCONNECTED
   };
  //## end IF::QueueManager%41AB603B0157.initialDeclarations

  public:
    //## Constructors (generated)
      QueueManager();

    //## Constructors (specified)
      //## Operation: QueueManager%41AB7F1B001F
      QueueManager (const string& strName);

    //## Destructor (generated)
      virtual ~QueueManager();


    //## Other Operations (specified)
      //## Operation: commit%41AB76C601E4
      virtual bool commit () = 0;

      //## Operation: connect%41D319E1001F
      virtual bool connect () = 0;

      //## Operation: getState%41AB7ABD0232
      virtual const QueueManager::QueueManagerState& getState () const
      {
        //## begin IF::QueueManager::getState%41AB7ABD0232.body preserve=yes
         return m_nState;
        //## end IF::QueueManager::getState%41AB7ABD0232.body
      }

      //## Operation: instance%41AB7A8B01D4
      static QueueManager* instance (const string& strName);

      //## Operation: rollback%41AB774B036B
      virtual bool rollback () = 0;

      //## Operation: terminate%41AB776102EE
      static void terminate ();

      //## Operation: trace%41AB77740261
      virtual void trace (const char* pszFunction) = 0;

    // Additional Public Declarations
      //## begin IF::QueueManager%41AB603B0157.public preserve=yes
      //## end IF::QueueManager%41AB603B0157.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Name%36E047B7027B
      //## begin IF::QueueManager::Name%36E047B7027B.attr preserve=no  public: string {V} 
      string m_strName;
      //## end IF::QueueManager::Name%36E047B7027B.attr

      //## Attribute: State%41AB834301A5
      //## begin IF::QueueManager::State%41AB834301A5.attr preserve=no  private: QueueManager::QueueManagerState {U} 
      QueueManager::QueueManagerState m_nState;
      //## end IF::QueueManager::State%41AB834301A5.attr

    // Additional Protected Declarations
      //## begin IF::QueueManager%41AB603B0157.protected preserve=yes
      //## end IF::QueueManager%41AB603B0157.protected

  private:
    // Data Members for Class Attributes

      //## Attribute: QueueManager%41AB847901C5
      //## begin IF::QueueManager::QueueManager%41AB847901C5.attr preserve=no  private: static map<string,QueueManager*,less<string> > {R} 0
      static map<string,QueueManager*,less<string> > *m_pQueueManager;
      //## end IF::QueueManager::QueueManager%41AB847901C5.attr

    // Additional Private Declarations
      //## begin IF::QueueManager%41AB603B0157.private preserve=yes
      //## end IF::QueueManager%41AB603B0157.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::QueueManager%41AB603B0157.implementation preserve=yes
      //## end IF::QueueManager%41AB603B0157.implementation

};

//## begin IF::QueueManager%41AB603B0157.postscript preserve=yes
//## end IF::QueueManager%41AB603B0157.postscript

} // namespace IF

//## begin module%41AB78E30157.epilog preserve=yes
using namespace IF;
//## end module%41AB78E30157.epilog


#endif
