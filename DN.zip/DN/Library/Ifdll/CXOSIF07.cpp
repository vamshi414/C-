//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36266C4E0148.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36266C4E0148.cm

//## begin module%36266C4E0148.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36266C4E0148.cp

//## Module: CXOSIF07%36266C4E0148; Package body
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXOSIF07.cpp

//## begin module%36266C4E0148.additionalIncludes preserve=no
//## end module%36266C4E0148.additionalIncludes

//## begin module%36266C4E0148.includes preserve=yes
// $Date:   May 15 2020 09:01:16  $ $Author:   e1009510  $ $Revision:   1.7  $
#define CM_SEND_AND_PREP_TO_RECEIVE 3
#define CM_OK 0
#define CM_MAPPED_CONVERSATION 1
#define CM_PREP_TO_RECEIVE_FLUSH 1
//## end module%36266C4E0148.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF07_h
#include "CXODIF07.hpp"
#endif


//## begin module%36266C4E0148.declarations preserve=no
//## end module%36266C4E0148.declarations

//## begin module%36266C4E0148.additionalDeclarations preserve=yes
#include "CXODIF14.hpp"
//## end module%36266C4E0148.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Conversation 

Conversation::Conversation()
  //## begin Conversation::Conversation%34801B4D0150_const.hasinit preserve=no
      : m_lSendType(CM_SEND_AND_PREP_TO_RECEIVE)
  //## end Conversation::Conversation%34801B4D0150_const.hasinit
  //## begin Conversation::Conversation%34801B4D0150_const.initialization preserve=yes
  //## end Conversation::Conversation%34801B4D0150_const.initialization
{
  //## begin IF::Conversation::Conversation%34801B4D0150_const.body preserve=yes
   memcpy(m_sID,"IF07",4);
   m_strConversationID = "        ";
  //## end IF::Conversation::Conversation%34801B4D0150_const.body
}

Conversation::Conversation(const Conversation &right)
  //## begin Conversation::Conversation%34801B4D0150_copy.hasinit preserve=no
      : m_lSendType(CM_SEND_AND_PREP_TO_RECEIVE)
  //## end Conversation::Conversation%34801B4D0150_copy.hasinit
  //## begin Conversation::Conversation%34801B4D0150_copy.initialization preserve=yes
   ,Object(right)
  //## end Conversation::Conversation%34801B4D0150_copy.initialization
{
  //## begin IF::Conversation::Conversation%34801B4D0150_copy.body preserve=yes
   memcpy(m_sID,"IF07",4);
   m_strConversationID = right.m_strConversationID;
   m_lSendType = right.m_lSendType;
   m_strSymDestName = right.m_strSymDestName;
  //## end IF::Conversation::Conversation%34801B4D0150_copy.body
}


Conversation::~Conversation()
{
  //## begin IF::Conversation::~Conversation%34801B4D0150_dest.body preserve=yes
  //## end IF::Conversation::~Conversation%34801B4D0150_dest.body
}


Conversation & Conversation::operator=(const Conversation &right)
{
  //## begin IF::Conversation::operator=%34801B4D0150_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_strConversationID = right.m_strConversationID;
   m_lSendType = right.m_lSendType;
   m_strSymDestName = right.m_strSymDestName;
   return *this;
  //## end IF::Conversation::operator=%34801B4D0150_assign.body
}



//## Other Operations (implementation)
int Conversation::accept (const char* psConversationID, const char* pszSymDestName)
{
  //## begin IF::Conversation::accept%364D9F8D0189.body preserve=yes
   IString strConversationID(psConversationID,8);
   m_strConversationID = strConversationID;
   m_strSymDestName = pszSymDestName;
   int lRC = CM_OK;
#ifdef MVS
   CMACCP(psConversationID,&lRC);
#endif
   return lRC;
  //## end IF::Conversation::accept%364D9F8D0189.body
}

int Conversation::allocate ()
{
  //## begin IF::Conversation::allocate%364D9F93012E.body preserve=yes
   int lRC = CM_OK;
#ifdef MVS
   CMALLC(m_strConversationID,&lRC);
#endif
   return lRC;
  //## end IF::Conversation::allocate%364D9F93012E.body
}

int Conversation::deallocate (const char* psConversationID, int lDeallocateType)
{
  //## begin IF::Conversation::deallocate%36CEBDD30026.body preserve=yes
   int lRC = CM_OK;
#ifdef MVS
   CMSDT(psConversationID,&lDeallocateType,&lRC);
   if (lRC == CM_OK)
      CMDEAL(psConversationID,&lRC);
#endif
   return lRC;
  //## end IF::Conversation::deallocate%36CEBDD30026.body
}

int Conversation::initialize (const char* pszSymDestName)
{
  //## begin IF::Conversation::initialize%364D9F9C0308.body preserve=yes
   m_strSymDestName = pszSymDestName;
   int lRC = CM_OK;
   char szConversationID[9] = {"        "};
#ifdef MVS
   CMINIT(szConversationID,m_strSymDestName.c_str(),&lRC);
#endif
   IString strConversationID(szConversationID,8);
   m_strConversationID = strConversationID;
   if (lRC == CM_OK)
   {
      int m = CM_MAPPED_CONVERSATION;
#ifdef MVS
      CMSCT(m_strConversationID,&m,&lRC);
#endif
      if (lRC == CM_OK)
      {
         m = CM_PREP_TO_RECEIVE_FLUSH;
#ifdef MVS
         CMSPTR(m_strConversationID,&m,&lRC);
#endif
      }
   }
   return lRC;
  //## end IF::Conversation::initialize%364D9F9C0308.body
}

int Conversation::receive (IF::Message& hMessage)
{
  //## begin IF::Conversation::receive%364D9FA300B9.body preserve=yes
   int lRC = CM_OK;
#ifdef MVS
   int lBufferLength = hMessage.bufferLength();
   int lDataReceived;
   int lReceivedLength;
   int lStatusReceived;
   int lRequestToSendReceived;
   CMRCV(m_strConversationID,hMessage.buffer(),&lBufferLength,
      &lDataReceived,&lReceivedLength,&lStatusReceived,&lRequestToSendReceived,&lRC);
   hMessage.identifyBuffer();
   hMessage.setMessageLength(lReceivedLength);
#endif
   return lRC;
  //## end IF::Conversation::receive%364D9FA300B9.body
}

int Conversation::send (IF::Message& hMessage)
{
  //## begin IF::Conversation::send%364D9FA801F6.body preserve=yes
   int lRC;
#ifdef MVS
   int lRequestToSendReceived;
   CMSST(m_strConversationID,&m_lSendType,&lRC);
   int lMessageLength = hMessage.messageLength();
   CMSEND(m_strConversationID,hMessage.buffer(),&lMessageLength,&lRequestToSendReceived,&lRC);
#else
   //lRC = Queue::reply(atoi((char*)m_strConversationID),&hMessage) ? 0 : -1;
   //if (lRC != 0)
      lRC = Queue::send(m_strSymDestName.c_str(),&hMessage) ? 0 : -1;
#endif
   return lRC;
  //## end IF::Conversation::send%364D9FA801F6.body
}

// Additional Declarations
  //## begin IF::Conversation%34801B4D0150.declarations preserve=yes
  //## end IF::Conversation%34801B4D0150.declarations

} // namespace IF

//## begin module%36266C4E0148.epilog preserve=yes
//## end module%36266C4E0148.epilog
