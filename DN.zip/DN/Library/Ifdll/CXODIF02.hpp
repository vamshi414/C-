//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36265829030F.cm preserve=no
//	$Date:   Jan 06 2017 09:41:44  $ $Author:   e1009839  $ $Revision:   1.8  $
//## end module%36265829030F.cm

//## begin module%36265829030F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%36265829030F.cp

//## Module: CXOSIF02%36265829030F; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF02.hpp

#ifndef CXOSIF02_h
#define CXOSIF02_h 1

//## begin module%36265829030F.additionalIncludes preserve=no
//## end module%36265829030F.additionalIncludes

//## begin module%36265829030F.includes preserve=yes
// $Date:   Jan 06 2017 09:41:44  $ $Author:   e1009839  $ $Revision:   1.8  $
//## end module%36265829030F.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Mask;
} // namespace reusable

namespace IF {
class Extract;
class Queue;

} // namespace IF

//## begin module%36265829030F.declarations preserve=no
//## end module%36265829030F.declarations

//## begin module%36265829030F.additionalDeclarations preserve=yes
//## end module%36265829030F.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Log%34626247038B.preface preserve=yes
//## end IF::Log%34626247038B.preface

//## Class: Log%34626247038B
//	The Log class encapsulates an interface to the Connex
//	log.
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%36EE7368012E;Message { -> F}
//## Uses: <unnamed>%36EE74740383;Queue { -> F}
//## Uses: <unnamed>%370258130328;Extract { -> F}
//## Uses: <unnamed>%496E030E0203;reusable::Mask { -> F}

class DllExport Log : public reusable::Object  //## Inherits: <unnamed>%347C8C0F010F
{
  //## begin IF::Log%34626247038B.initialDeclarations preserve=yes
  //## end IF::Log%34626247038B.initialDeclarations

  public:
    //## Constructors (generated)
      Log();

    //## Destructor (generated)
      virtual ~Log();


    //## Other Operations (specified)
      //## Operation: cut%36EED83A0361
      static int cut (const char* pszDestination);

      //## Operation: endOfDay%36EED8590167
      static int endOfDay (const char* pszDestination);

      //## Operation: put%34626270005F
      //	Put a message on the log.
      //## Semantics:
      //	1. Call CXLOG.
      static int put (const char* psBuffer, int iBuffer, const char* psMessageID, const char* pszReason, const char* psCBEKey = 0, const char* pszDestination = 0, const char* pszStation = 0, const char* pszLUName = 0);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: PriCustLogger%3FAEBD390028
      static void setPriCustLogger (const string& value);

      //## Attribute: SecCustLogger%3FAEBD5102CB
      static void setSecCustLogger (const string& value);

    // Additional Public Declarations
      //## begin IF::Log%34626247038B.public preserve=yes
      //## end IF::Log%34626247038B.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Log%34626247038B.protected preserve=yes
      //## end IF::Log%34626247038B.protected

  private:
    // Additional Private Declarations
      //## begin IF::Log%34626247038B.private preserve=yes
      //## end IF::Log%34626247038B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Enable%586FAF06004B
      //## begin IF::Log::Enable%586FAF06004B.attr preserve=no  private: static short {V} -1
      static short m_siEnable;
      //## end IF::Log::Enable%586FAF06004B.attr

      //## begin IF::Log::PriCustLogger%3FAEBD390028.attr preserve=no  public: static string {U} 
      static string m_strPriCustLogger;
      //## end IF::Log::PriCustLogger%3FAEBD390028.attr

      //## begin IF::Log::SecCustLogger%3FAEBD5102CB.attr preserve=no  public: static string {U} 
      static string m_strSecCustLogger;
      //## end IF::Log::SecCustLogger%3FAEBD5102CB.attr

    // Additional Implementation Declarations
      //## begin IF::Log%34626247038B.implementation preserve=yes
      //## end IF::Log%34626247038B.implementation

};

//## begin IF::Log%34626247038B.postscript preserve=yes
//## end IF::Log%34626247038B.postscript

} // namespace IF

//## begin module%36265829030F.epilog preserve=yes
using namespace IF;
//## end module%36265829030F.epilog


#endif
