//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%364DA5250265.cm preserve=no
//	$Date:   May 15 2020 09:01:18  $ $Author:   e1009510  $
//	$Revision:   1.20  $
//## end module%364DA5250265.cm

//## begin module%364DA5250265.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%364DA5250265.cp

//## Module: CXOSIF15%364DA5250265; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF15.cpp

//## begin module%364DA5250265.additionalIncludes preserve=no
//## end module%364DA5250265.additionalIncludes

//## begin module%364DA5250265.includes preserve=yes
#include <memory.h>
#include "CXODIF03.hpp"
//## end module%364DA5250265.includes

#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSRU24_h
#include "CXODRU24.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif


//## begin module%364DA5250265.declarations preserve=no
//## end module%364DA5250265.declarations

//## begin module%364DA5250265.additionalDeclarations preserve=yes
#ifdef MVS
extern "OS"
{
long CXDMOC(const char* psMessageKey,const char* psText,long* plRC);
}
#endif

//## end module%364DA5250265.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Console

//## begin IF::Console::HN%40083960004E.attr preserve=no  private: static short {U} 0
short Console::m_siHN = 0;
//## end IF::Console::HN%40083960004E.attr

//## begin IF::Console::Message%3E933A9103D8.attr preserve=no  public: static vector<string>* {V} 0
vector<string>* Console::m_pMessage = 0;
//## end IF::Console::Message%3E933A9103D8.attr

//## begin IF::Console::PrevHHMM%449966BD035F.attr preserve=no  private: static char[4] {U}
char Console::m_sPrevHHMM[4];
//## end IF::Console::PrevHHMM%449966BD035F.attr

//## begin IF::Console::PrevSS%400838820213.attr preserve=no  private: static char[2] {U}
char Console::m_sPrevSS[2];
//## end IF::Console::PrevSS%400838820213.attr

//## begin IF::Console::RecentMessage%4499665D031E.attr preserve=no  private: static set<string, less<string> > {R} 0
set<string, less<string> > *Console::m_pRecentMessage = 0;
//## end IF::Console::RecentMessage%4499665D031E.attr

Console::Console()
  //## begin Console::Console%364DA4A70390_const.hasinit preserve=no
  //## end Console::Console%364DA4A70390_const.hasinit
  //## begin Console::Console%364DA4A70390_const.initialization preserve=yes
  //## end Console::Console%364DA4A70390_const.initialization
{
  //## begin IF::Console::Console%364DA4A70390_const.body preserve=yes
   memcpy(m_sID,"IF15",4);
  //## end IF::Console::Console%364DA4A70390_const.body
}


Console::~Console()
{
  //## begin IF::Console::~Console%364DA4A70390_dest.body preserve=yes
  //## end IF::Console::~Console%364DA4A70390_dest.body
}



//## Other Operations (implementation)
void Console::display (const char* psMessageKey, int iValue)
{
  //## begin IF::Console::display%385030F50260.body preserve=yes
   char sText[PERCENTD];
   snprintf(sText,sizeof(sText),"%d",iValue);
   display(psMessageKey,sText);
  //## end IF::Console::display%385030F50260.body
}

void Console::display (const char* psMessageKey, const char* psText1, const char* psText2, const char* psText3, const char* psText4, const char* psText5)
{
  //## begin IF::Console::display%3C35E73800A7.body preserve=yes
   char psMessageIDText[14] = {"********     "};
   memcpy(psMessageIDText+8,psMessageKey,5);
#ifdef MVS
   char sText[60];
#else
   char sText[256];
#endif
   char *psText = sText;
   const char *pTextPtrs[6];
   pTextPtrs[0] = psText1;
   pTextPtrs[1] = psText2;
   pTextPtrs[2] = psText3;
   pTextPtrs[3] = psText4;
   pTextPtrs[4] = psText5;
   pTextPtrs[5] = 0;
   memset(sText,' ',sizeof(sText));
#ifdef MVS
   short int* psiArguments = (short int*)psText;
   *psiArguments = 0;
   short siRemainingBytes(sizeof(sText)-4);
   char *psData = sText + 2;
   short siIndex = 0;
   string strText(psMessageKey,5);
   while (pTextPtrs[siIndex] && (siRemainingBytes > 0))
   {
      strText += pTextPtrs[siIndex];
      short int* psiArgumentLength = (short int*)psData;
      psData += 2;
      (*psiArguments)++;
      *psiArgumentLength = strlen(pTextPtrs[siIndex]) > siRemainingBytes ? siRemainingBytes: strlen(pTextPtrs[siIndex]);
      memcpy(psData,pTextPtrs[siIndex],*psiArgumentLength);
      psData += *psiArgumentLength;
      siRemainingBytes -= (2 + *psiArgumentLength);
      siIndex++;
   }
#else
   short siRemainingBytes(sizeof(sText));
   short siIndex = 0;
   string strText(psMessageKey,5);
   short siParamLength = 0;
   while (pTextPtrs[siIndex] && (siRemainingBytes > 0))
   {
      strText += pTextPtrs[siIndex];
      siParamLength = strlen(pTextPtrs[siIndex]) > siRemainingBytes ? siRemainingBytes - 1 : strlen(pTextPtrs[siIndex]);
      memcpy(psText,pTextPtrs[siIndex],siParamLength);
      psText += siParamLength;
      *psText++ = '|';
      siRemainingBytes -= siParamLength + 1;
      siIndex++;
   }
#endif
   long lRC = 0;
   DateTime hDateTime;
   IString strCurrentDateTime;
   hDateTime.setCurrent(strCurrentDateTime);
   CriticalSection hCriticalSection;
   if (!m_pRecentMessage)
      m_pRecentMessage = new set<string,less<string> >;
   if (memcmp((char*)strCurrentDateTime.subString(9,4),m_sPrevHHMM,4) != 0)
   {
      memcpy(m_sPrevHHMM,(char*)strCurrentDateTime.subString(9,4),4);
      m_pRecentMessage->erase(m_pRecentMessage->begin(),m_pRecentMessage->end());
   }
   pair<set<string,less<string> >::iterator,bool> hResult = m_pRecentMessage->insert(strText);
   if (!hResult.second)
      return;
#ifdef MVS
   CXDMOC(psMessageIDText,sText,&lRC);
   char sBuffer[82];
   memcpy(sBuffer,"CXDMOC: ",8);
   memcpy(sBuffer + 8,psMessageIDText,14);
   memcpy(sBuffer + 22,sText,sizeof(sText));
   Trace::put(sBuffer,82);
#endif
#ifndef MVS
   strCurrentDateTime.remove(15);
   char psMessageData[277];
   memcpy(psMessageData,psMessageKey,5);
   if (memcmp((char*)strCurrentDateTime.subString(13,2),m_sPrevSS,2) != 0)
   {
      memcpy(m_sPrevSS,(char*)strCurrentDateTime.subString(13,2),2);
      m_siHN = 0;
   }
   char szTemp[PERCENTHD];
   snprintf(szTemp,sizeof(szTemp),"%02hd",m_siHN++);
   strCurrentDateTime += szTemp;
   if (m_siHN == 100)
      m_siHN = 0;
   memcpy(psMessageData + 5,(char*)strCurrentDateTime,16);
   memcpy(psMessageData + 21,sText,sizeof(sText));
   if (!m_pMessage)
      m_pMessage = new vector<string>;
   m_pMessage->push_back(string(psMessageData,277));
   Trace::put(psMessageData,277,true);
#endif
  //## end IF::Console::display%3C35E73800A7.body
}

const vector<string>& Console::getMessage ()
{
  //## begin IF::Console::getMessage%43F8A08201E4.body preserve=yes
   CriticalSection hCriticalSection;
   if (!m_pMessage)
      m_pMessage = new vector<string>;
   return *m_pMessage;
  //## end IF::Console::getMessage%43F8A08201E4.body
}

void Console::purgeMessages ()
{
  //## begin IF::Console::purgeMessages%3E9336D2029F.body preserve=yes
   CriticalSection hCriticalSection;
   if (m_pMessage)
      m_pMessage->erase(m_pMessage->begin(),m_pMessage->end());
  //## end IF::Console::purgeMessages%3E9336D2029F.body
}

// Additional Declarations
  //## begin IF::Console%364DA4A70390.declarations preserve=yes
  //## end IF::Console%364DA4A70390.declarations

} // namespace IF

//## begin module%364DA5250265.epilog preserve=yes
//## end module%364DA5250265.epilog
