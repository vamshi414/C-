//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3AAA89DD0213.cm preserve=no
//	$Date:   Apr 02 2018 15:11:48  $ $Author:   e1009652  $ $Revision:   1.5  $
//## end module%3AAA89DD0213.cm

//## begin module%3AAA89DD0213.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3AAA89DD0213.cp

//## Module: CXOSIF40%3AAA89DD0213; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.8A.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF40.hpp

#ifndef CXOSIF40_h
#define CXOSIF40_h 1

//## begin module%3AAA89DD0213.additionalIncludes preserve=no
//## end module%3AAA89DD0213.additionalIncludes

//## begin module%3AAA89DD0213.includes preserve=yes
// $Date:   Apr 02 2018 15:11:48  $ $Author:   e1009652  $ $Revision:   1.5  $
#include <map>
//## end module%3AAA89DD0213.includes

#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Signal;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class SocketQueue;

} // namespace IF

//## begin module%3AAA89DD0213.declarations preserve=no
//## end module%3AAA89DD0213.declarations

//## begin module%3AAA89DD0213.additionalDeclarations preserve=yes
//## end module%3AAA89DD0213.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::SocketQueueFactory%3AAA88E40048.preface preserve=yes
//## end IF::SocketQueueFactory%3AAA88E40048.preface

//## Class: SocketQueueFactory%3AAA88E40048
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3AAA89330331;SocketQueue { -> F}
//## Uses: <unnamed>%3AAA8936017D;reusable::Signal { -> F}

class DllExport SocketQueueFactory : public QueueFactory  //## Inherits: <unnamed>%3AAA88F80173
{
  //## begin IF::SocketQueueFactory%3AAA88E40048.initialDeclarations preserve=yes
  //## end IF::SocketQueueFactory%3AAA88E40048.initialDeclarations

  public:
    //## Constructors (generated)
      SocketQueueFactory();

    //## Destructor (generated)
      virtual ~SocketQueueFactory();


    //## Other Operations (specified)
      //## Operation: create%3AAA890501D6
      virtual Object* create (const char* pszClass, const char* pszValue = 0);

      //## Operation: create%5ABD481D01EB
      virtual IF::Queue* create (const Queue& hQueue);

    // Additional Public Declarations
      //## begin IF::SocketQueueFactory%3AAA88E40048.public preserve=yes
      //## end IF::SocketQueueFactory%3AAA88E40048.public

  protected:
    // Additional Protected Declarations
      //## begin IF::SocketQueueFactory%3AAA88E40048.protected preserve=yes
      //## end IF::SocketQueueFactory%3AAA88E40048.protected

  private:
    // Additional Private Declarations
      //## begin IF::SocketQueueFactory%3AAA88E40048.private preserve=yes
      //## end IF::SocketQueueFactory%3AAA88E40048.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Classes%3AAA8A75026C
      //## begin IF::SocketQueueFactory::Classes%3AAA8A75026C.attr preserve=no  private: map<string,int,less<string> > {U} 
      map<string,int,less<string> > m_hClasses;
      //## end IF::SocketQueueFactory::Classes%3AAA8A75026C.attr

    // Additional Implementation Declarations
      //## begin IF::SocketQueueFactory%3AAA88E40048.implementation preserve=yes
      //## end IF::SocketQueueFactory%3AAA88E40048.implementation

};

//## begin IF::SocketQueueFactory%3AAA88E40048.postscript preserve=yes
//## end IF::SocketQueueFactory%3AAA88E40048.postscript

} // namespace IF

//## begin module%3AAA89DD0213.epilog preserve=yes
using namespace IF;
//## end module%3AAA89DD0213.epilog


#endif
