//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%38513FFD008C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%38513FFD008C.cm

//## begin module%38513FFD008C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%38513FFD008C.cp

//## Module: CXOSIF24%38513FFD008C; Package specification
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXODIF24.hpp

#ifndef CXOSIF24_h
#define CXOSIF24_h 1

//## begin module%38513FFD008C.additionalIncludes preserve=no
//## end module%38513FFD008C.additionalIncludes

//## begin module%38513FFD008C.includes preserve=yes
// $Date:   Jun 30 2006 11:35:40  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%38513FFD008C.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSRU24_h
#include "CXODRU24.hpp"
#endif
//## begin module%38513FFD008C.declarations preserve=no
//## end module%38513FFD008C.declarations

//## begin module%38513FFD008C.additionalDeclarations preserve=yes
//## end module%38513FFD008C.additionalDeclarations


//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::HashItem%385138A501BE.preface preserve=yes
//## end IF::HashItem%385138A501BE.preface

//## Class: HashItem%385138A501BE
//## Category: Connex Foundation::IF_CAT%3451F55F009E
//## Subsystem: IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3BFE84D2009C;reusable::IString { -> }

class DllExport HashItem : public reusable::Object  //## Inherits: <unnamed>%385140BC01AD
{
  //## begin IF::HashItem%385138A501BE.initialDeclarations preserve=yes
  //## end IF::HashItem%385138A501BE.initialDeclarations

  public:
    //## Constructors (generated)
      HashItem();

      HashItem(const HashItem &right);

    //## Constructors (specified)
      //## Operation: HashItem%385148FA018B
      HashItem (int lSeqNo, int lRecordReadNo, int lRecordSentNo, double dDropHashTotal, double dLRHashTotal, IString& strConversationID, int lTranSentCnt, const char* pszTimeStamp);

    //## Destructor (generated)
      virtual ~HashItem();

    //## Assignment Operation (generated)
      HashItem & operator=(const HashItem &right);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: SeqNo%3851424C02D5
      int itemKey () const
      {
        //## begin IF::HashItem::itemKey%3851424C02D5.get preserve=no
        return m_lSeqNo;
        //## end IF::HashItem::itemKey%3851424C02D5.get
      }


      //## Attribute: RecordReadNo%38514638018D
      int recordReadNo () const
      {
        //## begin IF::HashItem::recordReadNo%38514638018D.get preserve=no
        return m_lRecordReadNo;
        //## end IF::HashItem::recordReadNo%38514638018D.get
      }


      //## Attribute: RecordSentNo%3851464603A0
      int recordSentNo () const
      {
        //## begin IF::HashItem::recordSentNo%3851464603A0.get preserve=no
        return m_lRecordSentNo;
        //## end IF::HashItem::recordSentNo%3851464603A0.get
      }


      //## Attribute: TranSentCnt%3851467C03E4
      int tranSentCnt () const
      {
        //## begin IF::HashItem::tranSentCnt%3851467C03E4.get preserve=no
        return m_lTranSentCnt;
        //## end IF::HashItem::tranSentCnt%3851467C03E4.get
      }

      void setTranSentCnt (int value)
      {
        //## begin IF::HashItem::setTranSentCnt%3851467C03E4.set preserve=no
        m_lTranSentCnt = value;
        //## end IF::HashItem::setTranSentCnt%3851467C03E4.set
      }


      //## Attribute: DropHashTotal%385146DC0360
      double dropHashTotal () const
      {
        //## begin IF::HashItem::dropHashTotal%385146DC0360.get preserve=no
        return m_dDropHashTotal;
        //## end IF::HashItem::dropHashTotal%385146DC0360.get
      }


      //## Attribute: LRHashTotal%3851470F0227
      double lrHashTotal () const
      {
        //## begin IF::HashItem::lrHashTotal%3851470F0227.get preserve=no
        return m_dLRHashTotal;
        //## end IF::HashItem::lrHashTotal%3851470F0227.get
      }

      void setLRHashTotal (double value)
      {
        //## begin IF::HashItem::setLRHashTotal%3851470F0227.set preserve=no
        m_dLRHashTotal = value;
        //## end IF::HashItem::setLRHashTotal%3851470F0227.set
      }


      //## Attribute: ConversationID%3851476C0357
      const IString& conversationID () const
      {
        //## begin IF::HashItem::conversationID%3851476C0357.get preserve=no
        return m_strConversationID;
        //## end IF::HashItem::conversationID%3851476C0357.get
      }


      //## Attribute: TimeStamp%385147C10343
      const IString& timeStamp () const
      {
        //## begin IF::HashItem::timeStamp%385147C10343.get preserve=no
        return m_strTimeStamp;
        //## end IF::HashItem::timeStamp%385147C10343.get
      }


    // Additional Public Declarations
      //## begin IF::HashItem%385138A501BE.public preserve=yes
      //## end IF::HashItem%385138A501BE.public

  protected:
    // Additional Protected Declarations
      //## begin IF::HashItem%385138A501BE.protected preserve=yes
      //## end IF::HashItem%385138A501BE.protected

  private:
    // Additional Private Declarations
      //## begin IF::HashItem%385138A501BE.private preserve=yes
      //## end IF::HashItem%385138A501BE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin IF::HashItem::SeqNo%3851424C02D5.attr preserve=no  public: int {U} 0
      int m_lSeqNo;
      //## end IF::HashItem::SeqNo%3851424C02D5.attr

      //## begin IF::HashItem::RecordReadNo%38514638018D.attr preserve=no  public: int {U} 0
      int m_lRecordReadNo;
      //## end IF::HashItem::RecordReadNo%38514638018D.attr

      //## begin IF::HashItem::RecordSentNo%3851464603A0.attr preserve=no  public: int {U} 0
      int m_lRecordSentNo;
      //## end IF::HashItem::RecordSentNo%3851464603A0.attr

      //## begin IF::HashItem::TranSentCnt%3851467C03E4.attr preserve=no  public: int {U} 0
      int m_lTranSentCnt;
      //## end IF::HashItem::TranSentCnt%3851467C03E4.attr

      //## begin IF::HashItem::DropHashTotal%385146DC0360.attr preserve=no  public: double {U} 0
      double m_dDropHashTotal;
      //## end IF::HashItem::DropHashTotal%385146DC0360.attr

      //## begin IF::HashItem::LRHashTotal%3851470F0227.attr preserve=no  public: double {U} 0
      double m_dLRHashTotal;
      //## end IF::HashItem::LRHashTotal%3851470F0227.attr

      //## begin IF::HashItem::ConversationID%3851476C0357.attr preserve=no  public: IString {U} 
      IString m_strConversationID;
      //## end IF::HashItem::ConversationID%3851476C0357.attr

      //## begin IF::HashItem::TimeStamp%385147C10343.attr preserve=no  public: IString {U} 
      IString m_strTimeStamp;
      //## end IF::HashItem::TimeStamp%385147C10343.attr

    // Additional Implementation Declarations
      //## begin IF::HashItem%385138A501BE.implementation preserve=yes
      //## end IF::HashItem%385138A501BE.implementation

};

//## begin IF::HashItem%385138A501BE.postscript preserve=yes
//## end IF::HashItem%385138A501BE.postscript

} // namespace IF

//## begin module%38513FFD008C.epilog preserve=yes
using namespace IF;
//## end module%38513FFD008C.epilog


#endif
