//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%41ACFF7F030D.cm preserve=no
//	$Date:   Apr 02 2009 12:13:12  $ $Author:   D94163  $
//	$Revision:   1.2  $
//## end module%41ACFF7F030D.cm

//## begin module%41ACFF7F030D.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%41ACFF7F030D.cp

//## Module: CXOSIF47%41ACFF7F030D; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF47.hpp

#ifndef CXOSIF47_h
#define CXOSIF47_h 1

//## begin module%41ACFF7F030D.additionalIncludes preserve=no
//## end module%41ACFF7F030D.additionalIncludes

//## begin module%41ACFF7F030D.includes preserve=yes
// $Date:   Apr 02 2009 12:13:12  $ $Author:   D94163  $ $Revision:   1.2  $
//## end module%41ACFF7F030D.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%41ACFF7F030D.declarations preserve=no
//## end module%41ACFF7F030D.declarations

//## begin module%41ACFF7F030D.additionalDeclarations preserve=yes
//## end module%41ACFF7F030D.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::ExternalQueueFactory%41ACFD3202DE.preface preserve=yes
//## end IF::ExternalQueueFactory%41ACFD3202DE.preface

//## Class: ExternalQueueFactory%41ACFD3202DE
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport ExternalQueueFactory : public reusable::Object  //## Inherits: <unnamed>%41ACFD32036B
{
  //## begin IF::ExternalQueueFactory%41ACFD3202DE.initialDeclarations preserve=yes
  //## end IF::ExternalQueueFactory%41ACFD3202DE.initialDeclarations

  public:
    //## Constructors (generated)
      ExternalQueueFactory();

    //## Destructor (generated)
      virtual ~ExternalQueueFactory();


    //## Other Operations (specified)
      //## Operation: create%41ACFD83008C
      virtual Object* create (const char* pszClass, const char* pszValue = 0) = 0;

      //## Operation: instance%41ACFD8901F4
      static ExternalQueueFactory* instance ();

    // Additional Public Declarations
      //## begin IF::ExternalQueueFactory%41ACFD3202DE.public preserve=yes
      //## end IF::ExternalQueueFactory%41ACFD3202DE.public

  protected:
    // Additional Protected Declarations
      //## begin IF::ExternalQueueFactory%41ACFD3202DE.protected preserve=yes
      //## end IF::ExternalQueueFactory%41ACFD3202DE.protected

  private:
    // Data Members for Class Attributes

      //## Attribute: Instance%41AD04430138
      //## begin IF::ExternalQueueFactory::Instance%41AD04430138.attr preserve=no  private: static ExternalQueueFactory {R} 0
      static ExternalQueueFactory *m_pInstance;
      //## end IF::ExternalQueueFactory::Instance%41AD04430138.attr

    // Additional Private Declarations
      //## begin IF::ExternalQueueFactory%41ACFD3202DE.private preserve=yes
      //## end IF::ExternalQueueFactory%41ACFD3202DE.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::ExternalQueueFactory%41ACFD3202DE.implementation preserve=yes
      //## end IF::ExternalQueueFactory%41ACFD3202DE.implementation

};

//## begin IF::ExternalQueueFactory%41ACFD3202DE.postscript preserve=yes
//## end IF::ExternalQueueFactory%41ACFD3202DE.postscript

} // namespace IF

//## begin module%41ACFF7F030D.epilog preserve=yes
using namespace IF;
//## end module%41ACFF7F030D.epilog


#endif
