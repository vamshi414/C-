//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%362524A402EA.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%362524A402EA.cm

//## begin module%362524A402EA.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%362524A402EA.cp

//## Module: CXOSIF21%362524A402EA; Package body
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXOSIF21.cpp

//## begin module%362524A402EA.additionalIncludes preserve=no
//## end module%362524A402EA.additionalIncludes

//## begin module%362524A402EA.includes preserve=yes
// $Date:   Jun 21 2017 15:38:36  $ $Author:   e1009839  $ $Revision:   1.4  $
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%362524A402EA.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF21_h
#include "CXODIF21.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU01_h
#include "CXODRU01.hpp"
#endif


//## begin module%362524A402EA.declarations preserve=no
//## end module%362524A402EA.declarations

//## begin module%362524A402EA.additionalDeclarations preserve=yes
//## end module%362524A402EA.additionalDeclarations


//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::RemoteObserver 




RemoteObserver::RemoteObserver()
  //## begin RemoteObserver::RemoteObserver%34A4060B02E8_const.hasinit preserve=no
  //## end RemoteObserver::RemoteObserver%34A4060B02E8_const.hasinit
  //## begin RemoteObserver::RemoteObserver%34A4060B02E8_const.initialization preserve=yes
  //## end RemoteObserver::RemoteObserver%34A4060B02E8_const.initialization
{
  //## begin IF::RemoteObserver::RemoteObserver%34A4060B02E8_const.body preserve=yes
   memcpy(m_sID,"IF21",4);
  //## end IF::RemoteObserver::RemoteObserver%34A4060B02E8_const.body
}

RemoteObserver::RemoteObserver (Subject* pOwner, const char* pszName)
  //## begin IF::RemoteObserver::RemoteObserver%36252A7E015E.hasinit preserve=no
  //## end IF::RemoteObserver::RemoteObserver%36252A7E015E.hasinit
  //## begin IF::RemoteObserver::RemoteObserver%36252A7E015E.initialization preserve=yes
   : m_strName(pszName)
  //## end IF::RemoteObserver::RemoteObserver%36252A7E015E.initialization
{
  //## begin IF::RemoteObserver::RemoteObserver%36252A7E015E.body preserve=yes
   m_pSubject = pOwner;
   Message::instance(Message::INBOUND)->attach(this);
  //## end IF::RemoteObserver::RemoteObserver%36252A7E015E.body
}


RemoteObserver::~RemoteObserver()
{
  //## begin IF::RemoteObserver::~RemoteObserver%34A4060B02E8_dest.body preserve=yes
   Message::instance(Message::INBOUND)->detach(this);
  //## end IF::RemoteObserver::~RemoteObserver%34A4060B02E8_dest.body
}



//## Other Operations (implementation)
void RemoteObserver::update (Subject* pSubject)
{
  //## begin IF::RemoteObserver::update%3626051C024F.body preserve=yes
   if (Message::instance(Message::INBOUND)->messageID() != (const char*)"S0006D")
      return;
   if (Extract::instance()->getName() == Message::instance(Message::INBOUND)->getSource().substr(0,7))
      return;
   string strData(Message::instance(Message::INBOUND)->data(),Message::instance(Message::INBOUND)->dataLength());
   if (strData == m_strName)
      m_pSubject->notify();
  //## end IF::RemoteObserver::update%3626051C024F.body
}

// Additional Declarations
  //## begin IF::RemoteObserver%34A4060B02E8.declarations preserve=yes
  //## end IF::RemoteObserver%34A4060B02E8.declarations

} // namespace IF

//## begin module%362524A402EA.epilog preserve=yes
//## end module%362524A402EA.epilog
