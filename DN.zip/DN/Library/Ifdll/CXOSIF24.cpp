//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3851402B0114.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3851402B0114.cm

//## begin module%3851402B0114.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3851402B0114.cp

//## Module: CXOSIF24%3851402B0114; Package body
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXOSIF24.cpp

//## begin module%3851402B0114.additionalIncludes preserve=no
//## end module%3851402B0114.additionalIncludes

//## begin module%3851402B0114.includes preserve=yes
// $Date:   Jun 30 2006 11:35:48  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%3851402B0114.includes

#ifndef CXOSIF24_h
#include "CXODIF24.hpp"
#endif
//## begin module%3851402B0114.declarations preserve=no
//## end module%3851402B0114.declarations

//## begin module%3851402B0114.additionalDeclarations preserve=yes
//## end module%3851402B0114.additionalDeclarations


//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::HashItem 










HashItem::HashItem()
  //## begin HashItem::HashItem%385138A501BE_const.hasinit preserve=no
      : m_lSeqNo(0),
        m_lRecordReadNo(0),
        m_lRecordSentNo(0),
        m_lTranSentCnt(0),
        m_dDropHashTotal(0),
        m_dLRHashTotal(0)
  //## end HashItem::HashItem%385138A501BE_const.hasinit
  //## begin HashItem::HashItem%385138A501BE_const.initialization preserve=yes
  //## end HashItem::HashItem%385138A501BE_const.initialization
{
  //## begin IF::HashItem::HashItem%385138A501BE_const.body preserve=yes
   memcpy(m_sID,"IF24",4);
  //## end IF::HashItem::HashItem%385138A501BE_const.body
}

HashItem::HashItem(const HashItem &right)
  //## begin HashItem::HashItem%385138A501BE_copy.hasinit preserve=no
      : m_lSeqNo(0),
        m_lRecordReadNo(0),
        m_lRecordSentNo(0),
        m_lTranSentCnt(0),
        m_dDropHashTotal(0),
        m_dLRHashTotal(0)
  //## end HashItem::HashItem%385138A501BE_copy.hasinit
  //## begin HashItem::HashItem%385138A501BE_copy.initialization preserve=yes
  //## end HashItem::HashItem%385138A501BE_copy.initialization
{
  //## begin IF::HashItem::HashItem%385138A501BE_copy.body preserve=yes
   memcpy(m_sID,"IF24",4);
   m_lSeqNo = right.m_lSeqNo;
   m_lRecordReadNo = right.m_lRecordReadNo;
   m_lRecordSentNo = right.m_lRecordSentNo;
   m_dDropHashTotal = right.m_dDropHashTotal;
   m_dLRHashTotal = right.m_dLRHashTotal;
   m_lTranSentCnt = right.m_lTranSentCnt;
   m_strTimeStamp = right.m_strTimeStamp;
   m_strConversationID = right.m_strConversationID;
  //## end IF::HashItem::HashItem%385138A501BE_copy.body
}

HashItem::HashItem (int lSeqNo, int lRecordReadNo, int lRecordSentNo, double dDropHashTotal, double dLRHashTotal, IString& strConversationID, int lTranSentCnt, const char* pszTimeStamp)
  //## begin IF::HashItem::HashItem%385148FA018B.hasinit preserve=no
      : m_lSeqNo(0),
        m_lRecordReadNo(0),
        m_lRecordSentNo(0),
        m_lTranSentCnt(0),
        m_dDropHashTotal(0),
        m_dLRHashTotal(0)
  //## end IF::HashItem::HashItem%385148FA018B.hasinit
  //## begin IF::HashItem::HashItem%385148FA018B.initialization preserve=yes
  //## end IF::HashItem::HashItem%385148FA018B.initialization
{
  //## begin IF::HashItem::HashItem%385148FA018B.body preserve=yes
   memcpy(m_sID,"IF24",4);
   m_lSeqNo = lSeqNo;
   m_lRecordReadNo = lRecordReadNo;
   m_lRecordSentNo = lRecordSentNo;
   m_dDropHashTotal = dDropHashTotal;
   m_dLRHashTotal = dLRHashTotal;
   m_lTranSentCnt = lTranSentCnt;
   m_strConversationID = strConversationID;
   m_strTimeStamp = pszTimeStamp;
  //## end IF::HashItem::HashItem%385148FA018B.body
}


HashItem::~HashItem()
{
  //## begin IF::HashItem::~HashItem%385138A501BE_dest.body preserve=yes
  //## end IF::HashItem::~HashItem%385138A501BE_dest.body
}


HashItem & HashItem::operator=(const HashItem &right)
{
  //## begin IF::HashItem::operator=%385138A501BE_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_strConversationID = right.m_strConversationID;
   m_strTimeStamp = right.m_strTimeStamp;
   m_lSeqNo = right.m_lSeqNo;
   m_lRecordReadNo = right.m_lRecordReadNo;
   m_lRecordSentNo = right.m_lRecordSentNo;
   m_dDropHashTotal = right.m_dDropHashTotal;
   m_dLRHashTotal = right.m_dLRHashTotal;
   m_lTranSentCnt = right.m_lTranSentCnt;
   return *this;
  //## end IF::HashItem::operator=%385138A501BE_assign.body
}


// Additional Declarations
  //## begin IF::HashItem%385138A501BE.declarations preserve=yes
  //## end IF::HashItem%385138A501BE.declarations

} // namespace IF

//## begin module%3851402B0114.epilog preserve=yes
//## end module%3851402B0114.epilog
