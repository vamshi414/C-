//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%359CF1C3037B.cm preserve=no
//	$Date:   Jun 21 2017 16:04:28  $ $Author:   e1009839  $ $Revision:   1.18  $
//## end module%359CF1C3037B.cm

//## begin module%359CF1C3037B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%359CF1C3037B.cp

//## Module: CXOSIF11%359CF1C3037B; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF11.hpp

#ifndef CXOSIF11_h
#define CXOSIF11_h 1

//## begin module%359CF1C3037B.additionalIncludes preserve=no
//## end module%359CF1C3037B.additionalIncludes

//## begin module%359CF1C3037B.includes preserve=yes
// $Date:   Jun 21 2017 16:04:28  $ $Author:   e1009839  $ $Revision:   1.18  $
#include "CXODIF12.hpp"

#define MAX_BUFFER_SIZE 65516
#define MAX_MESSAGE_SIZE 64000
//## end module%359CF1C3037B.includes

#ifndef CXOSRU24_h
#include "CXODRU24.hpp"
#endif
#ifndef CXOSRU01_h
#include "CXODRU01.hpp"
#endif
#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;
class Trace;

} // namespace IF

//## begin module%359CF1C3037B.declarations preserve=no
//## end module%359CF1C3037B.declarations

//## begin module%359CF1C3037B.additionalDeclarations preserve=yes
enum messageType
{
   APPLICATION,
   TIMER,
   QUIESCE,
   SHUTDOWN,
   REFRESH,
   RESET,
   NOTIFY,
   CONFIRM,
   TRACE,
   START,
   STARTWTR,
   DEALLOCATE,
   CONNECT
};
//## end module%359CF1C3037B.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Message%345C720A0194.preface preserve=yes
//## end IF::Message%345C720A0194.preface

//## Class: Message%345C720A0194
//	The Message class represents a Connex message buffer.
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%36DE9ECE016F;Queue { -> F}
//## Uses: <unnamed>%3BFE82CC01B5;reusable::IString { -> }
//## Uses: <unnamed>%41F557810290;Trace { -> F}

class DllExport Message : public reusable::Subject  //## Inherits: <unnamed>%34A4001501DF
{
  //## begin IF::Message%345C720A0194.initialDeclarations preserve=yes
  public:
  enum Buffer
  {
      INBOUND,
      OUTBOUND
  };
  //## end IF::Message%345C720A0194.initialDeclarations

  public:
    //## Constructors (generated)
      Message();

      Message(const Message &right);

    //## Constructors (specified)
      //## Operation: Message%34A3FE9F0232
      //	Construct a message with a buffer of the requested
      //	length.
      Message (int lBufferLength);

    //## Destructor (generated)
      virtual ~Message();

    //## Assignment Operation (generated)
      Message & operator=(const Message &right);


    //## Other Operations (specified)
      //## Operation: operator+=%515D789D007B
      Message& operator += (const Message& right);

      //## Operation: buffer%34A3FEA80325
      //	Return the address of the internal message buffer.
      //## Semantics:
      //	1. Return m_psBuffer.
      char* buffer () const
      {
        //## begin IF::Message::buffer%34A3FEA80325.body preserve=yes
         return (char*)*m_pMemory;
        //## end IF::Message::buffer%34A3FEA80325.body
      }

      //## Operation: bufferLength%34A3FEAE0003
      //	Return the size of the internal message buffer.
      //## Semantics:
      //	1. Return m_lBufferLength.
      int bufferLength () const
      {
        //## begin IF::Message::bufferLength%34A3FEAE0003.body preserve=yes
         return m_lBufferLength;
        //## end IF::Message::bufferLength%34A3FEAE0003.body
      }

      //## Operation: context%34A3FEB303D5
      //	Return the context information for the current message.
      //## Semantics:
      //	1. Return m_strContext.
      const IString& context () const
      {
        //## begin IF::Message::context%34A3FEB303D5.body preserve=yes
        return m_strContext;
        //## end IF::Message::context%34A3FEB303D5.body
      }

      //## Operation: data%592DD890017B
      char* data () const;

      //## Operation: dataLength%592DD8AB014E
      unsigned int dataLength () const;

      //## Operation: format%592DD6720117
      short format () const;

      //## Operation: identifyBuffer%34A3FEC10028
      //	Determine the type of the current message.
      //## Semantics:
      //	1. Based on the current message, set m_nType to one of:
      //	    a. APPLICATION.
      //	    b. TIMER.
      //	    c. RESET.
      //	    d. REFRESH
      //	    e. QUIESCE.
      //	    f. SHUTDOWN
      //	2. Save the message ID in m_strMessageID.
      //	3. Save context information in m_strContext.
      //	4. Save receiver data in m_lReceiverCBAddress and m_str
      //	ReceiverSTCKValue.
      void identifyBuffer ();

      //## Operation: instance%34A3FECC0164
      //	Return the instance of the inbound or outbound message
      //	buffer.
      static IF::Message* instance (Message::Buffer nBuffer);

      //## Operation: messageID%34A3FED3033B
      //	Return the message ID of the current message.
      //## Semantics:
      //	1. Return m_strMessageID.
      const IString& messageID () const
      {
        //## begin IF::Message::messageID%34A3FED3033B.body preserve=yes
         return m_strMessageID;
        //## end IF::Message::messageID%34A3FED3033B.body
      }

      //## Operation: messageLength%34A3FED9027B
      //	Return the length of the current message.
      //## Semantics:
      //	1. Return m_lMessageLength.
      int messageLength () const
      {
        //## begin IF::Message::messageLength%34A3FED9027B.body preserve=yes
         return m_lMessageLength;
        //## end IF::Message::messageLength%34A3FED9027B.body
      }

      //## Operation: receive%34A3FEF103D4
      //	Retrieve the next message from the input queue.
      //## Semantics:
      //	1. Call CXQWFM to wait for a message.
      //	2. Call CXQGET to retrieve the next message from the
      //	input queue.
      //	3. If a message was retrieved:
      //	    a. Call Message::identifyBuffer to evaluate the
      //	message.
      //	    b. Call Subject::notify to notify all observers.
      //	4. Return the return code from CXQGET.
      int receive ();

      //## Operation: receiverCBAddress%34A3FEF60147
      //	Return the receiver CBA address for the current message.
      //## Semantics:
      //	1. Return m_lReceiverCBAddress.
      void* receiverCBAddress () const
      {
        //## begin IF::Message::receiverCBAddress%34A3FEF60147.body preserve=yes
         return m_pReceiverCBAddress;
        //## end IF::Message::receiverCBAddress%34A3FEF60147.body
      }

      //## Operation: receiverSTCKValue%34A3FF0101C5
      //	Return the receiver STCK value for the current message.
      //## Semantics:
      //	1. Return m_strReceiverSTCKValue.
      const IString& receiverSTCKValue () const
      {
        //## begin IF::Message::receiverSTCKValue%34A3FF0101C5.body preserve=yes
         return m_strReceiverSTCKValue;
        //## end IF::Message::receiverSTCKValue%34A3FF0101C5.body
      }

      //## Operation: reply%34A3FF0A0087
      //	Send this message back to the original sender.
      //## Semantics:
      //	1. Call Message::send(m_strQueueName).
      int reply ();

      //## Operation: reserve%4639F7DD002E
      void reserve (int lBufferLength);

      //## Operation: reset%34A3FF0E00E7
      //	Reset the standard and unique headers in the current
      //	message.
      void reset (const char* pszSenderReceiver, const char* pszMessageID, bool bSwap = true);

      //## Operation: send%34A3FF1900A7
      //	Send the current message to another process.
      //## Semantics:
      //	1. Set m_lMessageLength to the length of the current
      //	message.
      //	2. Call Message::send(pszQueueName,m_lMessageLength).
      int send (const char* pszQueueName);

      //## Operation: send%34A3FF1D0157
      //	Send the current message to another process.
      //## Semantics:
      //	1. Call CXQPUT to send this message to another process.
      int send (const char* pszQueueName, int lMessageLength);

      //## Operation: setCorrelId%37C2EBD6022A
      void setCorrelId (const char* psCorrelId);

      //## Operation: setDataLength%34A3FF2101B7
      //	Set the length of the data portion of this message.
      //## Semantics:
      //	1. Set the length field in the data portion of this
      //	message.
      //	2. Recalculate m_lMessageLength.
      void setDataLength (unsigned int iDataLength);

      //## Operation: setMessageLength%34A3FF2A01A5
      //	Set the length of the current message.
      void setMessageLength (int lMessageLength)
      {
        //## begin IF::Message::setMessageLength%34A3FF2A01A5.body preserve=yes
         m_lMessageLength = lMessageLength;
        //## end IF::Message::setMessageLength%34A3FF2A01A5.body
      }

      //## Operation: setReceiverCBAddress%37E246550076
      //	Set the sender CBA address for the current message.
      void setReceiverCBAddress (void* pReceiverCBAddress);

      //## Operation: setSenderCBAddress%34A3FF3203CE
      //	Set the sender CBA address for the current message.
      void setSenderCBAddress (void* pSenderCBAddress);

      //## Operation: setReceiverSTCKValue%37E246240224
      //	Set the sender STCK value for the current message.
      void setReceiverSTCKValue (const char* psReceiverSTCKValue);

      //## Operation: setSenderSTCKValue%34A3FF3B02D6
      //	Set the sender STCK value for the current message.
      void setSenderSTCKValue (const char* psSenderSTCKValue);

      //## Operation: type%34A3FF470229
      //	Return the type of the current message.
      //## Semantics:
      //	1. Return m_nType.
      messageType type () const
      {
        //## begin IF::Message::type%34A3FF470229.body preserve=yes
         return m_nType;
        //## end IF::Message::type%34A3FF470229.body
      }

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: CorrelId%37C2E889015D
      const reusable::IString& getCorrelId () const
      {
        //## begin IF::Message::getCorrelId%37C2E889015D.get preserve=no
        return m_strCorrelId;
        //## end IF::Message::getCorrelId%37C2E889015D.get
      }


      //## Attribute: Destination%36EEBB940166
      const string& getDestination () const
      {
        //## begin IF::Message::getDestination%36EEBB940166.get preserve=no
        return m_strDestination;
        //## end IF::Message::getDestination%36EEBB940166.get
      }

      void setDestination (const string& value)
      {
        //## begin IF::Message::setDestination%36EEBB940166.set preserve=no
        m_strDestination = value;
        //## end IF::Message::setDestination%36EEBB940166.set
      }


      //## Attribute: Source%34A401890393
      //	The origin of the current message.
      const string& getSource () const
      {
        //## begin IF::Message::getSource%34A401890393.get preserve=no
        return m_strSource;
        //## end IF::Message::getSource%34A401890393.get
      }

      void setSource (const string& value)
      {
        //## begin IF::Message::setSource%34A401890393.set preserve=no
        m_strSource = value;
        //## end IF::Message::setSource%34A401890393.set
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::IF_CAT::First%538776E60364
      //## Role: Message::<m_pFirst>%538776E70360
      static Message * getFirst ();
      static void setFirst (Message * value);

      //## Association: Connex Library::IF_CAT::Next%538776EF00F2
      //## Role: Message::<m_pNext>%538776F00149
      Message * getNext ()
      {
        //## begin IF::Message::getNext%538776F00149.get preserve=no
        return m_pNext;
        //## end IF::Message::getNext%538776F00149.get
      }

      void setNext (Message * value)
      {
        //## begin IF::Message::setNext%538776F00149.set preserve=no
        m_pNext = value;
        //## end IF::Message::setNext%538776F00149.set
      }


      //## Association: Connex Library::IF_CAT::Last%538776F501EE
      //## Role: Message::<m_pLast>%538776F60211
      static Message * getLast ();
      static void setLast (Message * value);

      //## Association: Connex Library::IF_CAT::Free%538776FC0043
      //## Role: Message::<m_pFree>%538776FC0368
      static Message * getFree ();
      static void setFree (Message * value);

    // Additional Public Declarations
      //## begin IF::Message%345C720A0194.public preserve=yes
      //## end IF::Message%345C720A0194.public

  protected:
    // Data Members for Associations

      //## Association: Connex Library::IF_CAT::<unnamed>%36276ED80257
      //## Role: Message::<m_pMemory>%36276ED901F4
      //## begin IF::Message::<m_pMemory>%36276ED901F4.role preserve=no  public: IF::Memory { -> RHgN}
      Memory *m_pMemory;
      //## end IF::Message::<m_pMemory>%36276ED901F4.role

    // Additional Protected Declarations
      //## begin IF::Message%345C720A0194.protected preserve=yes
      //## end IF::Message%345C720A0194.protected

  private:

    //## Other Operations (specified)
      //## Operation: dataBuffer%34A3FEBA028B
      //	Return the address of the data portion of the internal
      //	message buffer.
      hData* dataBuffer () const;

    // Additional Private Declarations
      //## begin IF::Message%345C720A0194.private preserve=yes
      //## end IF::Message%345C720A0194.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BufferLength%34A401580162
      //	The length of the message buffer.
      //## begin IF::Message::BufferLength%34A401580162.attr preserve=no  private: int {U} 
      int m_lBufferLength;
      //## end IF::Message::BufferLength%34A401580162.attr

      //## Attribute: Context%34A4015E00C0
      //	The context information for the current message.
      //## begin IF::Message::Context%34A4015E00C0.attr preserve=no  private: reusable::IString {U} 
      reusable::IString m_strContext;
      //## end IF::Message::Context%34A4015E00C0.attr

      //## begin IF::Message::CorrelId%37C2E889015D.attr preserve=no  public: reusable::IString {U} 
      reusable::IString m_strCorrelId;
      //## end IF::Message::CorrelId%37C2E889015D.attr

      //## begin IF::Message::Destination%36EEBB940166.attr preserve=no  public: string {V} 
      string m_strDestination;
      //## end IF::Message::Destination%36EEBB940166.attr

      //## Attribute: MessageID%34A4016401CD
      //	The message ID of the current message.
      //## begin IF::Message::MessageID%34A4016401CD.attr preserve=no  private: reusable::IString {U} 
      reusable::IString m_strMessageID;
      //## end IF::Message::MessageID%34A4016401CD.attr

      //## Attribute: MessageLength%34A4016C0279
      //	The length of the current message.
      //## begin IF::Message::MessageLength%34A4016C0279.attr preserve=no  private: int {U} 0
      int m_lMessageLength;
      //## end IF::Message::MessageLength%34A4016C0279.attr

      //## Attribute: ReceiverCBAddress%34A40175000F
      //	The receiver CBA address of the current message.
      //## begin IF::Message::ReceiverCBAddress%34A40175000F.attr preserve=no  private: void* {V} 0
      void* m_pReceiverCBAddress;
      //## end IF::Message::ReceiverCBAddress%34A40175000F.attr

      //## Attribute: ReceiverSTCKValue%34A4017D025F
      //	The receiver STCK value of the current message.
      //## begin IF::Message::ReceiverSTCKValue%34A4017D025F.attr preserve=no  private: reusable::IString {U} 
      reusable::IString m_strReceiverSTCKValue;
      //## end IF::Message::ReceiverSTCKValue%34A4017D025F.attr

      //## begin IF::Message::Source%34A401890393.attr preserve=no  public: string {V} 
      string m_strSource;
      //## end IF::Message::Source%34A401890393.attr

      //## Attribute: Type%34F4999B0161
      //	The possible types of messages (APPLICATION, TIMER,
      //	QUIESCE, SHUTDOWN, REFRESH, RESET, NOTIFY).
      //## begin IF::Message::Type%34F4999B0161.attr preserve=no  private: messageType {U} 
      messageType m_nType;
      //## end IF::Message::Type%34F4999B0161.attr

    // Data Members for Associations

      //## Association: Connex Library::IF_CAT::First%538776E60364
      //## begin IF::Message::<m_pFirst>%538776E70360.role preserve=no  public: static IF::Message { -> RFHgN}
      static Message *m_pFirst;
      //## end IF::Message::<m_pFirst>%538776E70360.role

      //## Association: Connex Library::IF_CAT::Next%538776EF00F2
      //## begin IF::Message::<m_pNext>%538776F00149.role preserve=no  public: IF::Message { -> RFHgN}
      Message *m_pNext;
      //## end IF::Message::<m_pNext>%538776F00149.role

      //## Association: Connex Library::IF_CAT::Last%538776F501EE
      //## begin IF::Message::<m_pLast>%538776F60211.role preserve=no  public: static IF::Message { -> RFHgN}
      static Message *m_pLast;
      //## end IF::Message::<m_pLast>%538776F60211.role

      //## Association: Connex Library::IF_CAT::Free%538776FC0043
      //## begin IF::Message::<m_pFree>%538776FC0368.role preserve=no  public: static IF::Message { -> RFHgN}
      static Message *m_pFree;
      //## end IF::Message::<m_pFree>%538776FC0368.role

    // Additional Implementation Declarations
      //## begin IF::Message%345C720A0194.implementation preserve=yes
      static Message* m_pInstance[2];
      //## end IF::Message%345C720A0194.implementation
};

//## begin IF::Message%345C720A0194.postscript preserve=yes
//## end IF::Message%345C720A0194.postscript

} // namespace IF

//## begin module%359CF1C3037B.epilog preserve=yes
using namespace IF;
//## end module%359CF1C3037B.epilog


#endif
