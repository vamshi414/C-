//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3DE24A370000.cm preserve=no
//	$Date:   Jun 22 2020 13:35:50  $ $Author:   e1009839  $ $Revision:   1.20  $
//## end module%3DE24A370000.cm

//## begin module%3DE24A370000.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3DE24A370000.cp

//## Module: CXOSIF41%3DE24A370000; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Dn_codes\V03.0A.R005\ConnexPlatform\Server\Library\Ifdll\CXOSIF41.cpp

//## begin module%3DE24A370000.additionalIncludes preserve=no
//## end module%3DE24A370000.additionalIncludes

//## begin module%3DE24A370000.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%3DE24A370000.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF41_h
#include "CXODIF41.hpp"
#endif


//## begin module%3DE24A370000.declarations preserve=no
//## end module%3DE24A370000.declarations

//## begin module%3DE24A370000.additionalDeclarations preserve=yes
#ifdef MVS
extern "OS"
{
int CXIGET(long* plFile,char* psBuffer,int* plBufferLength,int* plRecordLength,int* plRC);
int CXSFRF(long* plFile,char* psRecordFormat,int* plRC);
}
#endif
#define BUFFERSIZE 32768
//## end module%3DE24A370000.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::VariableBlockFile

VariableBlockFile::VariableBlockFile()
  //## begin VariableBlockFile::VariableBlockFile%3DE24944000F_const.hasinit preserve=no
      : m_psBuffer(0),
        m_psCursor(0),
        m_lCounter(0),
        m_bWriting(false)
  //## end VariableBlockFile::VariableBlockFile%3DE24944000F_const.hasinit
  //## begin VariableBlockFile::VariableBlockFile%3DE24944000F_const.initialization preserve=yes
  //## end VariableBlockFile::VariableBlockFile%3DE24944000F_const.initialization
{
  //## begin IF::VariableBlockFile::VariableBlockFile%3DE24944000F_const.body preserve=yes
   memcpy(m_sID,"IF41",4);
   m_lBufferLength = BUFFERSIZE;
   m_psBuffer = new char[BUFFERSIZE];
   setRecordFormat("VB");
   m_siFormat = UNKNOWN;
  //## end IF::VariableBlockFile::VariableBlockFile%3DE24944000F_const.body
}

VariableBlockFile::VariableBlockFile (const char* pszName)
  //## begin IF::VariableBlockFile::VariableBlockFile%3DEB777C00EA.hasinit preserve=no
      : m_psBuffer(0),
        m_psCursor(0),
        m_lCounter(0),
        m_bWriting(false)
  //## end IF::VariableBlockFile::VariableBlockFile%3DEB777C00EA.hasinit
  //## begin IF::VariableBlockFile::VariableBlockFile%3DEB777C00EA.initialization preserve=yes
   ,FlatFile(pszName)
  //## end IF::VariableBlockFile::VariableBlockFile%3DEB777C00EA.initialization
{
  //## begin IF::VariableBlockFile::VariableBlockFile%3DEB777C00EA.body preserve=yes
   memcpy(m_sID,"IF41",4);
   m_lBufferLength = BUFFERSIZE;
   m_psBuffer = new char[BUFFERSIZE];
   setRecordFormat("VB");
   m_siFormat = UNKNOWN;
  //## end IF::VariableBlockFile::VariableBlockFile%3DEB777C00EA.body
}


VariableBlockFile::~VariableBlockFile()
{
  //## begin IF::VariableBlockFile::~VariableBlockFile%3DE24944000F_dest.body preserve=yes
   delete [] m_psBuffer;
  //## end IF::VariableBlockFile::~VariableBlockFile%3DE24944000F_dest.body
}



//## Other Operations (implementation)
bool VariableBlockFile::close ()
{
  //## begin IF::VariableBlockFile::close%3F9DE35F002F.body preserve=yes
   int iRC = 0;
   if (m_bWriting && m_lCounter > 4)
      iRC = writeBlock();
   FlatFile::close();
   m_psCursor = 0;
   m_lCounter = 0;
   m_siFormat = UNKNOWN;
   return (iRC == 0) ? true: false;
  //## end IF::VariableBlockFile::close%3F9DE35F002F.body
}

bool VariableBlockFile::flush ()
{
  //## begin IF::VariableBlockFile::flush%3F9DDDE10127.body preserve=yes
   int iRC = 0;
   if (m_bWriting && m_lCounter > 4)
      iRC = writeBlock();
   FlatFile::flush();
   return (iRC == 0) ? true: false;
  //## end IF::VariableBlockFile::flush%3F9DDDE10127.body
}

bool VariableBlockFile::open (enum OpenType nOpenType)
{
  //## begin IF::VariableBlockFile::open%3F9DF4C4006E.body preserve=yes
   if (nOpenType != CX_OPEN_INPUT)
   {
      m_bWriting = true;
      m_psCursor = m_psBuffer + 4;
      m_lCounter = 4;
   }
   return FlatFile::open(nOpenType);
  //## end IF::VariableBlockFile::open%3F9DF4C4006E.body
}

bool VariableBlockFile::read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool* pbReadError)
{
  //## begin IF::VariableBlockFile::read%3DE24AB80261.body preserve=yes
   int lRC = 0;
   if (getFile() == -1)
      if (!open())
         return false;
   if (m_lCounter == 0
      || (m_psCursor != 0
#ifdef _LITTLE_ENDIAN
      && ntohs(*(unsigned short*)m_psCursor) == 0))
#else
      && *(unsigned short*)m_psCursor == 0))
#endif
   {
#ifdef _WIN64
      long long lFile = getFile();
#else
      long lFile = getFile();
#endif
#ifdef MVS
      CXIGET(&lFile,m_psBuffer,&m_lBufferLength,&m_lCounter,&lRC);
#else
      cxiget(&lFile,m_psBuffer,&m_lBufferLength,&m_lCounter,&lRC);
#endif
      if (lRC != 0)
      {
         if (pbReadError && lRC == 11)
            *pbReadError = true;
         return false;
      }
      if (m_siFormat == RDW)
      {
         memcpy(psBuffer,m_psBuffer,m_lCounter);
         *plRecordLength = m_lCounter;
         m_lCounter = 0;
         return lRC == 0;
      }
      int lBDW = 0;
#ifdef _LITTLE_ENDIAN
      lBDW = ntohs(*(unsigned short*)m_psBuffer);
#else
      lBDW = *(unsigned short*)m_psBuffer;
#endif
      if ((((*(m_psBuffer + 2) == 0x20) && (*(m_psBuffer + 3) == 0x20))
       ||  ((*(m_psBuffer + 2) == 0x00) && (*(m_psBuffer + 3) == 0x00)))
       && (((*(m_psBuffer + 6) == 0x20) && (*(m_psBuffer + 7) == 0x20))
       ||  ((*(m_psBuffer + 6) == 0x00) && (*(m_psBuffer + 7) == 0x00)))
       && lBDW == m_lCounter)
      {
         m_psCursor = m_psBuffer + 4;
         m_lCounter -= 4;
      }
      else
      {
         *plRecordLength = m_lCounter;
         if (*plRecordLength > lBufferLength)
            return false;
         memcpy(psBuffer,m_psBuffer,*plRecordLength);
         if (getEncryption())
            decrypt(psBuffer, (int*)plRecordLength);
         m_lCounter = 0;
         return true;
      }
   }
#ifdef _LITTLE_ENDIAN
   *plRecordLength = ntohs(*(unsigned short*)m_psCursor) - 4;
#else
   *plRecordLength = *(unsigned short*)m_psCursor - 4;
#endif
   m_psCursor += 4;
   m_lCounter -= 4;
   memcpy(psBuffer,m_psCursor,*plRecordLength);
   if (getEncryption())
      decrypt(psBuffer,(int*)plRecordLength);
   m_psCursor += *plRecordLength;
   m_lCounter -= *plRecordLength;
   return m_lCounter >= 0;
  //## end IF::VariableBlockFile::read%3DE24AB80261.body
}

bool VariableBlockFile::write (char* psBuffer, int lRecordLength)
{
  //## begin IF::VariableBlockFile::write%3F9DAD3301E6.body preserve=yes
   int iRC = 0;
   int iEncryptionHeaderSize = getEncryption() ? 20 : 0;
   if (m_lCounter + lRecordLength + 4 + iEncryptionHeaderSize > 8192)
      iRC = writeBlock();
   if (lRecordLength + 8 + iEncryptionHeaderSize > 8192)
   {
      char szTemp[100];
      if (getEncryption())
         Trace::put(szTemp, snprintf(szTemp,sizeof(szTemp), "Record length (%08d) +8 + encryption header greater than block size!", lRecordLength), true);
      else
         Trace::put(szTemp, snprintf(szTemp,sizeof(szTemp), "Record length (%08d) +8 greater than block size!", lRecordLength), true);
      return false;
   }
#ifdef _LITTLE_ENDIAN
   *(unsigned short*)m_psCursor = htons((unsigned short)lRecordLength + 4);
#else
   *(unsigned short*)m_psCursor = (unsigned short)lRecordLength + 4;
#endif
   memset(m_psCursor+2,0,2);
   m_psCursor += 4;
   m_lCounter += 4;
   memcpy(m_psCursor,psBuffer,lRecordLength);
   m_psCursor += lRecordLength;
   m_lCounter += lRecordLength;
   return (iRC == 0) ? true : false;
  //## end IF::VariableBlockFile::write%3F9DAD3301E6.body
}

bool VariableBlockFile::writeBlock ()
{
  //## begin IF::VariableBlockFile::writeBlock%3F9DE21A028A.body preserve=yes
#ifdef _LITTLE_ENDIAN
   *(unsigned short*)m_psBuffer = htons((unsigned short)m_lCounter);
#else
   *(unsigned short*)m_psBuffer = (unsigned short)m_lCounter;
#endif
   memset(m_psBuffer+2,0,2);
   // pad out block to 8k
   memset(m_psCursor,'X',(8192-m_lCounter));
   int iRC = FlatFile::write(m_psBuffer,8192);
   memset(m_psBuffer,0,m_lBufferLength);
   m_psCursor = m_psBuffer+4;
   m_lCounter = 4;
   return (iRC == 0) ? true : false;
  //## end IF::VariableBlockFile::writeBlock%3F9DE21A028A.body
}

// Additional Declarations
  //## begin IF::VariableBlockFile%3DE24944000F.declarations preserve=yes
#ifdef _WIN64
int VariableBlockFile::cxiget(long long* plFile,char* psBuffer,int* plBufferLength,int* plRecordLength,int* plRC)
#else
int VariableBlockFile::cxiget(long* plFile,char* psBuffer,int* plBufferLength,int* plRecordLength,int* plRC)
#endif
{
   memset((void*)psBuffer,0,(size_t)*plBufferLength);
   *plRecordLength = 0;
   *plRC = 0;
   char sTemp[7];
   if (m_siFormat == RDW)
   {
      if (!fread(psBuffer,1,(size_t)4,(FILE*)*plFile))
      {
         if (!feof((FILE*)*plFile))
            *plRC = 11;
         else
            *plRC = 6;
         return false;
      }
      unsigned short x = ntohs(*((unsigned short*)(psBuffer))) - 4;
      if (!fread(psBuffer,1,(size_t)x,(FILE*)*plFile))
      {
         if (!feof((FILE*)*plFile))
            *plRC = 11;
         else
            *plRC = 6;
         return false;
      }
      *plRecordLength = x;
      return true;
   }
   if (ftell((FILE*)*plFile) == 0)
   {
      if (!fread(psBuffer,1,(size_t)4,(FILE*)*plFile))
      {
         if (!feof((FILE*)*plFile))
            *plRC = 11;
         else
            *plRC = 6;
         return 0;
      }
      if (*((unsigned short*)psBuffer) == 0)
      {
         // assume a MasterCard IPM variable block file
         // each logical record preceded by a four byte length
         // bytes 1013 and 1014 of every 'block' contain x'40' and must be dropped
         m_siFormat = RDW_1014;
         memset(psBuffer + 6,'\0',2);
         unsigned short x = ntohs(*((unsigned short*)(psBuffer + 2)));
         x = x + 4;
         *((unsigned short*)(psBuffer + 4)) = htons(x);
         memset(psBuffer + 2,'\0',2);
         x = x + 4;
         *((unsigned short*)psBuffer) = htons(x);
      }
      else
      {
         if (!fread(psBuffer + 4,1,(size_t)4,(FILE*)*plFile))
         {
            if (!feof((FILE*)*plFile))
               *plRC = 11;
            else
               *plRC = 6;
            return 0;
         }
         // detect either IBM z/OS VB or MasterCard RDW only file
         m_siFormat = *((unsigned short*)(psBuffer + 6)) == 0 ? BDW_RDW : RDW;
         if (m_siFormat == RDW)
         {
            // read rest of first record
            unsigned short x = ntohs(*((unsigned short*)(psBuffer))) - 4;
            memcpy(psBuffer,psBuffer + 4,4);
            if (!fread(psBuffer + 4,1,(size_t)x - 4,(FILE*)*plFile))
            {
               if (!feof((FILE*)*plFile))
                  *plRC = 11;
               else
                  *plRC = 6;
               return false;
            }
            *plRecordLength = x;
            return true;
         }
      }
   }
   else
   {
      if (m_siFormat == RDW_1014)
      {
         int lRecordLength = 0;
         int iSeek = ftell((FILE*)*plFile);
         int iRemainder = iSeek % 1014;
         if (iRemainder + 4 + 2 >= 1014)
         {
            lRecordLength = fread(psBuffer + 4,1,(size_t)(1014 - iRemainder),(FILE*)*plFile) - 2;
            lRecordLength += fread(psBuffer + 4 + (1014 - iRemainder) - 2,1,(size_t)(4 - (1014 - iRemainder) + 2),(FILE*)*plFile);
         }
         else
            lRecordLength = fread(psBuffer + 4,1,(size_t)4,(FILE*)*plFile);
         if (lRecordLength == 0)
         {
            if (!feof((FILE*)*plFile))
               *plRC = 11;
            else
               *plRC = 6;
            return 0;
         }
         unsigned short x = ntohs(*((unsigned short*)(psBuffer + 6)));
         if (x == 0)
         {
            *plRC = 6;
            return 0;
         }
         memset(psBuffer + 6,'\0',2);
         x = x + 4;
         *((unsigned short*)(psBuffer + 4)) = htons(x);
         memset(psBuffer + 2,'\0',2);
         x = x + 4;
         *((unsigned short*)psBuffer) = htons(x);
      }
      else
      if (!fread(psBuffer,1,(size_t)8,(FILE*)*plFile))
      {
         if (!feof((FILE*)*plFile))
            *plRC = 11;
         else
            *plRC = 6;
         return 0;
      }
   }
   if (m_siFormat == BDW_RDW)
      while ((*((unsigned short*)psBuffer) == 0)
         || (*((unsigned short*)(psBuffer + 2)) != 0 && (((*(psBuffer + 2) != 0x20) && (*(psBuffer + 3) != 0x20))))
         || (*((unsigned short*)(psBuffer + 4)) == 0)
         || (*((unsigned short*)(psBuffer + 6)) != 0 && (((*(psBuffer + 5) != 0x20) && (*(psBuffer + 6) != 0x20)))))
      {
         memcpy_s(sTemp,7,psBuffer + 1,7);
         memcpy_s(psBuffer,4096,sTemp,7);
         if (!fread(psBuffer + 7,1,(size_t)1,(FILE*)*plFile))
         {
            if (!feof((FILE*)*plFile))
               *plRC = 11;
            else
               *plRC = 6;
            return 0;
         }
      }
   *plRecordLength = ntohs(*(unsigned short*)psBuffer);
   int lRecordLength = 0;
   if (m_siFormat == BDW_RDW)
   {
      if (*plRecordLength < *plBufferLength)
         lRecordLength = fread(psBuffer + 8,1,(size_t)(*plRecordLength - 8),(FILE*)*plFile);
   }
   else
   if (m_siFormat == RDW_1014)
   {
      int iSeek = ftell((FILE*)*plFile);
      int iRemainder = iSeek % 1014;
      if (iRemainder + (*plRecordLength - 8) + 2 >= 2028)
      {
         int tempLen = 8 + 1014 - iRemainder + (*plRecordLength - 8 - 1014 - iRemainder);
         if (tempLen < *plBufferLength)
         {
            lRecordLength = fread(psBuffer + 8,1,(size_t)(1014 - iRemainder),(FILE*)*plFile) - 2;
            lRecordLength += fread(psBuffer + 8 + (1014 - iRemainder) - 2,1,(size_t)1014,(FILE*)*plFile) - 2;
            lRecordLength += fread(psBuffer + 8 + 1012 + (1014 - iRemainder) - 2,1,(size_t)(*plRecordLength - 8 - 1012 - (1014 - iRemainder) + 2),(FILE*)*plFile);
         }
      }
      else
      if (iRemainder + (*plRecordLength - 8) + 2 >= 1014)
      {
         int tempLen = 8 + 1014 - iRemainder + (*plRecordLength - 8 - 1014 - iRemainder);
         if (tempLen < *plBufferLength)
         {
            lRecordLength = fread(psBuffer + 8,1,(size_t)(1014 - iRemainder),(FILE*)*plFile) - 2;
            lRecordLength += fread(psBuffer + 8 + (1014 - iRemainder) - 2,1,(size_t)(*plRecordLength - 8 - (1014 - iRemainder) + 2),(FILE*)*plFile);
         }
      }
      else
      {
         if (*plRecordLength < *plBufferLength)
            lRecordLength = fread(psBuffer + 8,1,(size_t)(*plRecordLength - 8),(FILE*)*plFile);
      }
   }
   if (lRecordLength != (*plRecordLength - 8))
   {
      if (ferror((FILE*)*plFile))
         *plRC = 11;
      else
         *plRC = 6;
   }
   return 0;
}
  //## end IF::VariableBlockFile%3DE24944000F.declarations

} // namespace IF

//## begin module%3DE24A370000.epilog preserve=yes
//## end module%3DE24A370000.epilog
