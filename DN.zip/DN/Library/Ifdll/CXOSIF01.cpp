//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36264F290212.cm preserve=no
//	$Date:   Jul 29 2020 22:07:14  $ $Author:   e1009591  $ $Revision:   1.49  $
//## end module%36264F290212.cm

//## begin module%36264F290212.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%36264F290212.cp

//## Module: CXOSIF01%36264F290212; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF01.cpp

//## begin module%36264F290212.additionalIncludes preserve=no
//## end module%36264F290212.additionalIncludes

//## begin module%36264F290212.includes preserve=yes
#include <memory.h>
#include <stdlib.h>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <time.h>
#include <windows.h>
#include <direct.h>
#include <io.h>
#endif
#ifdef _UNIX
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#endif
//## end module%36264F290212.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF44_h
#include "CXODIF44.hpp"
#endif
#ifndef CXOSIF48_h
#include "CXODIF48.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif


//## begin module%36264F290212.declarations preserve=no
//## end module%36264F290212.declarations

//## begin module%36264F290212.additionalDeclarations preserve=yes
#ifdef MVS
extern "OS"
{
long CXGTN(char* psName,long* plRC);
}
#endif

//## end module%36264F290212.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Job

//## begin IF::Job::Member%40587A60030D.attr preserve=no  public: static string {R} 0
string *Job::m_pstrMember = 0;
//## end IF::Job::Member%40587A60030D.attr

//## begin IF::Job::Parameters%54357DDD00CB.attr preserve=no  private: static map<string,string,less<string> >* {V} 0
map<string,string,less<string> >* Job::m_pParameters = 0;
//## end IF::Job::Parameters%54357DDD00CB.attr

Job::Job()
  //## begin Job::Job%347C8C420266_const.hasinit preserve=no
  //## end Job::Job%347C8C420266_const.hasinit
  //## begin Job::Job%347C8C420266_const.initialization preserve=yes
  //## end Job::Job%347C8C420266_const.initialization
{
  //## begin IF::Job::Job%347C8C420266_const.body preserve=yes
  //## end IF::Job::Job%347C8C420266_const.body
}


Job::~Job()
{
  //## begin IF::Job::~Job%347C8C420266_dest.body preserve=yes
  //## end IF::Job::~Job%347C8C420266_dest.body
}



//## Other Operations (implementation)
bool Job::execute (const string &strMember)
{
  //## begin IF::Job::execute%3F4F75E900DA.body preserve=yes
   enum jobType {CMD,DDL,FTP,PERL};
   jobType nJobType = CMD;
   string strCommand;
   string strBinName(strMember);
   {
      char sBuffer[256];
      size_t m = 0;
      string strBuffer;
      size_t pos;
      string strKey("TYPE");
#ifdef _WIN32
      string strValue("cmd");
#else
      string strValue("sh");
#endif
      IF::FlatFile hSource("SOURCE",strMember.c_str());
      if (!hSource.open())
         return true;
      while (hSource.read(sBuffer,256,&m))
      {
       strBuffer.assign(sBuffer,m);
       if ((strBuffer.find("CONNECT ") != string::npos)
            || (strBuffer.find("DDLSCRPT") != string::npos))
         {
            strValue = "txt";
            nJobType = DDL;
         }
         if (strBuffer.find("bye") != string::npos)
         {
            strValue = "txt";
            nJobType = FTP;
         }
         if (strBuffer.find("perl ") != string::npos)
         {
            strValue = "pl";
            nJobType = PERL;
         }
      }
      SiteSpecification::instance()->add(strKey,strValue);
      hSource.close();
      IF::FlatFile hBin("BIN");
      while (hSource.read(sBuffer,256,&m))
      {
         Trace::put(sBuffer,m);
         strBuffer.assign(sBuffer,m);
         if (!SiteSpecification::instance()->substitute(strBuffer))
            return false;
         Trace::put(strBuffer.data(),strBuffer.length());
         pos = strBuffer.find("ADD NAME=");
         if (pos != string::npos)
         {
            strBinName = strBuffer.substr(pos + 9);
            hBin.setMember(strBinName.c_str());
         }
         else
         if (strBuffer.find("perl ") != string::npos)
         {
            strCommand = strBuffer;
       }
         else
            hBin.write((char*)strBuffer.data(),(int)strBuffer.length());
      }
   }
   time_t tTime;
   time(&tTime);
   tm *tmTime = localtime(&tTime);
   char szTemp[32];
   int i = snprintf(szTemp,sizeof(szTemp),"%04d-%02d-%02d~%02d_%02d_%02d_00",
      tmTime->tm_year + 1900,tmTime->tm_mon + 1,tmTime->tm_mday,
      tmTime->tm_hour,tmTime->tm_min,tmTime->tm_sec);
   if (!m_pstrMember)
      m_pstrMember = new string();
   m_pstrMember->assign(szTemp,i);
   *m_pstrMember += "~";
   *m_pstrMember += Extract::instance()->getHost();
   *m_pstrMember += "~";
   *m_pstrMember += strBinName;
   string strFileName(Extract::instance()->getNode001());

#ifdef _WIN32
   strFileName += "\\Trace\\";
#else
   strFileName += "/Trace/";
#endif
   strFileName.append(szTemp,10);
#ifdef _WIN32
   strFileName += "\\JobSubmit";
#else
   strFileName += "/JobSubmit";
#endif
   int j = 0;
   string strPassword("PPPPPPPP");
   if (nJobType == DDL)
   {
      string strDBVendor("ORACLE");
      string strDSName("XXXX");
      string strUserId("UUUUUUUU");
      Extract::instance()->getSpec("DBVENDOR",strDBVendor);
      if (!Extract::instance()->getSpec("DBDS",strDSName))
         if (!Extract::instance()->getSpec("DBNAME",strDSName))
            Extract::instance()->getSpec("UDBCONN",strDSName);
      if (Extract::instance()->getSpec("CUSTPASS",strPassword))
         Extract::instance()->getSpec("CUSTQUAL",strUserId);
      else
      {
         Extract::instance()->getSpec("USERID",strUserId);
         Extract::instance()->getSpec("PASSWORD",strPassword);
      }
      AdvancedEncryptionStandard::decrypt(strUserId);
      AdvancedEncryptionStandard::decrypt(strPassword);
      strCommand = "ExecuteDDL ";
      strCommand += strBinName;
      strCommand += ".txt ";
      strCommand += strDBVendor;
      strCommand += " ";
      strCommand += strDSName;
      strCommand += " ";
      strCommand += strUserId;
#ifdef _WIN32
      if (strDBVendor != "POSTGRES")
         strCommand += " \"";
      else
         strCommand += " ";
#else
      strCommand += " '";
#endif
      j = strCommand.length();
      strCommand += strPassword;
#ifdef _WIN32
      if (strDBVendor != "POSTGRES")
         strCommand += "\" ";
      else
         strCommand += " ";
#else
      strCommand += "' ";
#endif
      strCommand.append(szTemp,10);
      strCommand += " ";
      strCommand.append(szTemp + 11,11);
      strCommand += " ";
      strCommand += Extract::instance()->getHost();
      strCommand += " ";
      strCommand += strMember;
   }
   else
   if (nJobType == FTP)
   {
      strCommand = "ExecuteFTP ";
      strCommand += strBinName;
      strCommand += ".txt 1>>\"";
      strCommand += strFileName;
      strCommand += "~Results.txt\"";
#ifdef _WIN32
      strCommand += " 2>>&1";
#else
      strCommand += " 2>>\"";
      strCommand += strFileName;
      strCommand += "~Results.txt\"";
#endif
   }
   else
   if (nJobType == PERL)
   {
      size_t n = strCommand.find("%date~%time");
      if (n != string::npos)
         strCommand.replace(n,11,szTemp);
      strCommand += " 2>>\"";
      strCommand += strFileName;
      strCommand += "~Results.txt\"";
   }
   else
   {
      strCommand = strBinName;
#ifdef _WIN32
      strCommand += ".cmd 1>>\"";
#else
      strCommand += ".sh 1>>\"";
#endif
      strCommand += strFileName;
      strCommand += "~Job.txt\"";
      strCommand += " 2>>\"";
      strCommand += strFileName;
      strCommand += "~Results.txt\"";
   }
   if (j)
      Trace::put((strCommand.substr(0,j) + "********" +
         strCommand.substr(j + strPassword.length())).data(),
         strCommand.length() - strPassword.length() + 8,true);
   else
      Trace::put(strCommand.data(),strCommand.length(),true);
   vector<string> hTokens;
   Buffer::parse(strCommand,";",hTokens);
   vector<string>::iterator p;
   for (p = hTokens.begin();p != hTokens.end();++p)
      i = system((*p).c_str());
   if (nJobType != DDL)
      return true;
   return (i == 0 || i == 2);
  //## end IF::Job::execute%3F4F75E900DA.body
}

const string& Job::getMember ()
{
  //## begin IF::Job::getMember%40587A8103C8.body preserve=yes
   if (!m_pstrMember)
      m_pstrMember = new string();
   return *m_pstrMember;
  //## end IF::Job::getMember%40587A8103C8.body
}

string Job::jobName (const char* pszMember)
{
  //## begin IF::Job::jobName%3850128500AC.body preserve=yes
   string strBuffer(pszMember);
   size_t n = strBuffer.find("##");
   if (n != string::npos)
   {
      char sName[7];
      long lRC = 0;
#ifdef MVS
      CXGTN(sName,&lRC);
#else
      memcpy_s(sName,7,getApplicationName(),7);
#endif
      strBuffer.replace(n,2,sName,2);
   }
#ifdef MVS
   strBuffer.resize(8,' ');
#endif
   return strBuffer;
  //## end IF::Job::jobName%3850128500AC.body
}

bool Job::submit (const char* pszMember)
{
  //## begin IF::Job::submit%347C930A03AD.body preserve=yes
   string strMember(jobName(pszMember));
#ifdef MVS
   if (m_pParameters == 0)
      m_pParameters = new map<string,string,less<string > >;
   IF::FlatFile hSource("JCL",strMember.c_str());
   if (!hSource.open())
      return false;
   IF::FlatFile hInternalReader("INTRDR");
   if (!hInternalReader.open())
      return false;
   char sBuffer[81];
   size_t m = 0;
   string strBuffer;
   map<string,string,less<string> >::iterator p;
   while (hSource.read(sBuffer,80,&m))
   {
      strBuffer.assign(sBuffer,72);
      for (p = m_pParameters->begin();p != m_pParameters->end();++p)
      {
         size_t pos = strBuffer.find((*p).first);
         if (pos != string::npos)
            strBuffer.replace(pos,(*p).first.length(),(*p).second);
      }
      strBuffer.resize(80,' ');
      memcpy(sBuffer,strBuffer.data(),80);
      sBuffer[80] = '\0';
      hInternalReader.write(sBuffer,80);
   }
   Console::display("SB001",strMember.c_str());
   return true;
#else
   return execute(strMember);
#endif
  //## end IF::Job::submit%347C930A03AD.body
}

bool Job::submit (const char* pszMember, const char* psParm1, const char* psValue1, const char* psParm2, const char* psValue2, const char* psParm3, const char* psValue3, const char* psParm4, const char* psValue4, const char* psParm5, const char* psValue5, const char* psParm6, const char* psValue6, const char* psParm7, const char* psValue7, const char* psParm8, const char* psValue8)
{
  //## begin IF::Job::submit%3626570B0015.body preserve=yes
#ifdef MVS
   if (m_pParameters == 0)
      m_pParameters = new map<string,string,less<string > >;
   Job x;
   string strFirst(psParm1);
   m_pParameters->insert(map<string,string,less<string> >::value_type(x.rtrim(strFirst),string(psValue1,strlen(psValue1))));
   if (psParm2)
   {
      strFirst.assign(psParm2);
      m_pParameters->insert(map<string,string,less<string> >::value_type(x.rtrim(strFirst),string(psValue2,strlen(psValue2))));
   }
   if (psParm3)
   {
      strFirst.assign(psParm3);
      m_pParameters->insert(map<string,string,less<string> >::value_type(x.rtrim(strFirst),string(psValue3,strlen(psValue3))));
   }
   if (psParm4)
   {
      strFirst.assign(psParm4);
      m_pParameters->insert(map<string,string,less<string> >::value_type(x.rtrim(strFirst),string(psValue4,strlen(psValue4))));
   }
   if (psParm5)
   {
      strFirst.assign(psParm5);
      m_pParameters->insert(map<string,string,less<string> >::value_type(x.rtrim(strFirst),string(psValue5,strlen(psValue5))));
   }
   if (psParm6)
   {
      strFirst.assign(psParm6);
      m_pParameters->insert(map<string,string,less<string> >::value_type(x.rtrim(strFirst),string(psValue6,strlen(psValue6))));
   }
   if (psParm7)
   {
      strFirst.assign(psParm7);
      m_pParameters->insert(map<string,string,less<string> >::value_type(x.rtrim(strFirst),string(psValue7,strlen(psValue7))));
   }
   if (psParm8)
   {
      strFirst.assign(psParm8);
      m_pParameters->insert(map<string,string,less<string> >::value_type(x.rtrim(strFirst),string(psValue8,strlen(psValue8))));
   }
   bool b = submit(pszMember);
   m_pParameters->erase(m_pParameters->begin(),m_pParameters->end());
   return b;
#else
   string strParm1(psParm1 + 1);
   string strValue1(psValue1,strlen(psValue1));
   if (!SiteSpecification::instance()->add(strParm1,strValue1))
      return false;
   if (psParm2)
   {
      string strParm2(psParm2 + 1);
      string strValue2(psValue2,strlen(psValue2));
      if (!SiteSpecification::instance()->add(strParm2,strValue2))
         return false;
   }
   if (psParm3)
   {
      string strParm3(psParm3 + 1);
      string strValue3(psValue3,strlen(psValue3));
      if (!SiteSpecification::instance()->add(strParm3,strValue3))
         return false;
   }
   if (psParm4)
   {
      string strParm4(psParm4 + 1);
      string strValue4(psValue4,strlen(psValue4));
      if (!SiteSpecification::instance()->add(strParm4,strValue4))
         return false;
   }
   if (psParm5)
   {
      string strParm5(psParm5 + 1);
      string strValue5(psValue5,strlen(psValue5));
      if (!SiteSpecification::instance()->add(strParm5,strValue5))
         return false;
   }
   if (psParm6)
   {
      string strParm6(psParm6 + 1);
      string strValue6(psValue6,strlen(psValue6));
      if (!SiteSpecification::instance()->add(strParm6,strValue6))
         return false;
   }
   if (psParm7)
   {
      string strParm7(psParm7 + 1);
      string strValue7(psValue7,strlen(psValue7));
      if (!SiteSpecification::instance()->add(strParm7,strValue7))
         return false;
   }
   if (psParm8)
   {
      string strParm8(psParm8 + 1);
      string strValue8(psValue8,strlen(psValue8));
      if (!SiteSpecification::instance()->add(strParm8,strValue8))
         return false;
   }
   string strMember(jobName(pszMember));
   return execute(strMember);
#endif
  //## end IF::Job::submit%3626570B0015.body
}

// Additional Declarations
  //## begin IF::Job%347C8C420266.declarations preserve=yes
bool Job::submit(const char* pszMember, map<string, string,less<string> >& hParameters)
{
#ifdef MVS
   if (m_pParameters == 0)
      m_pParameters = new map<string, string, less<string > >;
   map<string,string, less<string> >::iterator p;
   for (p = hParameters.begin(); p != hParameters.end(); p++)
   {
      string strFirst((*p).first);
      m_pParameters->insert(map<string, string, less<string> >::value_type(rtrim(strFirst), (*p).second));
   }
   bool b = submit(pszMember);
   m_pParameters->erase(m_pParameters->begin(), m_pParameters->end());
   return b;
#else
   map<string, string, less<string> >::iterator p;
   for (p = hParameters.begin(); p != hParameters.end(); p++)
   {
      string strParm((*p).first + 1);
      if (!SiteSpecification::instance()->add(strParm, (*p).second))
         return false;
   }
   string strMember(jobName(pszMember));
   return execute(strMember);
#endif
}
  //## end IF::Job%347C8C420266.declarations

} // namespace IF

//## begin module%36264F290212.epilog preserve=yes
//## end module%36264F290212.epilog
