//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52601C270074.cm preserve=no
//	$Date:   Jan 16 2014 16:59:52  $ $Author:   e1009839  $ $Revision:   1.0  $
//## end module%52601C270074.cm

//## begin module%52601C270074.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52601C270074.cp

//## Module: CXOSIF58%52601C270074; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.4B.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF58.hpp

#ifndef CXOSIF58_h
#define CXOSIF58_h 1

//## begin module%52601C270074.additionalIncludes preserve=no
//## end module%52601C270074.additionalIncludes

//## begin module%52601C270074.includes preserve=yes
//## end module%52601C270074.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%52601C270074.declarations preserve=no
//## end module%52601C270074.declarations

//## begin module%52601C270074.additionalDeclarations preserve=yes
//## end module%52601C270074.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::RACF%52601B1D0390.preface preserve=yes
//## end IF::RACF%52601B1D0390.preface

//## Class: RACF%52601B1D0390
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport RACF : public reusable::Object  //## Inherits: <unnamed>%52601B380137
{
  //## begin IF::RACF%52601B1D0390.initialDeclarations preserve=yes
  //## end IF::RACF%52601B1D0390.initialDeclarations

  public:
    //## Constructors (generated)
      RACF();

    //## Destructor (generated)
      virtual ~RACF();


    //## Other Operations (specified)
      //## Operation: validatePassword%52601B73013B
      static int validatePassword (const string& strUSER_ID, const string& strUSER_PASSWORD);

    // Additional Public Declarations
      //## begin IF::RACF%52601B1D0390.public preserve=yes
      //## end IF::RACF%52601B1D0390.public

  protected:
    // Additional Protected Declarations
      //## begin IF::RACF%52601B1D0390.protected preserve=yes
      //## end IF::RACF%52601B1D0390.protected

  private:
    // Additional Private Declarations
      //## begin IF::RACF%52601B1D0390.private preserve=yes
      //## end IF::RACF%52601B1D0390.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::RACF%52601B1D0390.implementation preserve=yes
      //## end IF::RACF%52601B1D0390.implementation

};

//## begin IF::RACF%52601B1D0390.postscript preserve=yes
//## end IF::RACF%52601B1D0390.postscript

} // namespace IF

//## begin module%52601C270074.epilog preserve=yes
//## end module%52601C270074.epilog


#endif
