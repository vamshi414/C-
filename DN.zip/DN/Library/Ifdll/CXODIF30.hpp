//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%36DAA38002DD.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DAA38002DD.cm

//## begin module%36DAA38002DD.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DAA38002DD.cp

//## Module: CXOSIF30%36DAA38002DD; Package specification
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF30.hpp

#ifndef CXOSIF30_h
#define CXOSIF30_h 1

//## begin module%36DAA38002DD.additionalIncludes preserve=no
//## end module%36DAA38002DD.additionalIncludes

//## begin module%36DAA38002DD.includes preserve=yes
// $Date:   Jun 30 2006 11:35:42  $ $Author:   D02405  $ $Revision:   1.4  $
//## end module%36DAA38002DD.includes

#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Extract;

} // namespace IF

//## begin module%36DAA38002DD.declarations preserve=no
//## end module%36DAA38002DD.declarations

//## begin module%36DAA38002DD.additionalDeclarations preserve=yes
//## end module%36DAA38002DD.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::MDSQueue%36DA9F6D03E2.preface preserve=yes
//## end IF::MDSQueue%36DA9F6D03E2.preface

//## Class: MDSQueue%36DA9F6D03E2
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%36DAE84701EA;Message { -> F}
//## Uses: <unnamed>%37024E8003BA;Extract { -> F}

class DllExport MDSQueue : public Queue  //## Inherits: <unnamed>%36DA9F7D02FE
{
  //## begin IF::MDSQueue%36DA9F6D03E2.initialDeclarations preserve=yes
  //## end IF::MDSQueue%36DA9F6D03E2.initialDeclarations

  public:
    //## Constructors (generated)
      MDSQueue();

    //## Constructors (specified)
      //## Operation: MDSQueue%36DE94140383
      MDSQueue (const char* pszName);

    //## Destructor (generated)
      virtual ~MDSQueue();


    //## Other Operations (specified)
      //## Operation: close%36DE8B5A02F5
      virtual bool close ();

      //## Operation: getQueueDepth%3EB928B402DE
      static int getQueueDepth ();

      //## Operation: open%36DE8B5E0323
      virtual bool open ();

      //## Operation: send%36DE8B6301AD
      virtual bool send (Message* pMessage, enum MessageType nMessageType);

      //## Operation: update%36DC65E6030C
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (reusable::Subject* pSubject);

    // Additional Public Declarations
      //## begin IF::MDSQueue%36DA9F6D03E2.public preserve=yes
      //## end IF::MDSQueue%36DA9F6D03E2.public

  protected:
    // Additional Protected Declarations
      //## begin IF::MDSQueue%36DA9F6D03E2.protected preserve=yes
      //## end IF::MDSQueue%36DA9F6D03E2.protected

  private:
    // Additional Private Declarations
      //## begin IF::MDSQueue%36DA9F6D03E2.private preserve=yes
      //## end IF::MDSQueue%36DA9F6D03E2.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::MDSQueue%36DA9F6D03E2.implementation preserve=yes
      //## end IF::MDSQueue%36DA9F6D03E2.implementation

};

//## begin IF::MDSQueue%36DA9F6D03E2.postscript preserve=yes
//## end IF::MDSQueue%36DA9F6D03E2.postscript

} // namespace IF

//## begin module%36DAA38002DD.epilog preserve=yes
using namespace IF;
//## end module%36DAA38002DD.epilog


#endif
