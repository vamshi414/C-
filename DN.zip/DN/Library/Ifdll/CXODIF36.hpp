//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%37189CF10025.cm preserve=no
//	$Date:   Oct 16 2018 13:50:00  $ $Author:   e1009652  $ $Revision:   1.5  $
//## end module%37189CF10025.cm

//## begin module%37189CF10025.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%37189CF10025.cp

//## Module: CXOSIF36%37189CF10025; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF36.hpp

#ifndef CXOSIF36_h
#define CXOSIF36_h 1

//## begin module%37189CF10025.additionalIncludes preserve=no
//## end module%37189CF10025.additionalIncludes

//## begin module%37189CF10025.includes preserve=yes
// $Date:   Oct 16 2018 13:50:00  $ $Author:   e1009652  $ $Revision:   1.5  $
//## end module%37189CF10025.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Job;
class EMailMessageVisitor;
class FlatFile;

} // namespace IF

//## begin module%37189CF10025.declarations preserve=no
//## end module%37189CF10025.declarations

//## begin module%37189CF10025.additionalDeclarations preserve=yes
#include <vector>
//## end module%37189CF10025.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::EMailMessage%37189C910190.preface preserve=yes
//## end IF::EMailMessage%37189C910190.preface

//## Class: EMailMessage%37189C910190
//	The EMailMessage class provides the function of sending
//	a mail message.
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: writes%3718A14201F1;FlatFile { -> F}
//## Uses: <unnamed>%3742C2D9036E;EMailMessageVisitor { -> F}
//## Uses: submits%3E85A0A702CE;Job { -> F}
//## Uses: <unnamed>%3E85A889033C;Extract { -> F}

class DllExport EMailMessage : public reusable::Object  //## Inherits: <unnamed>%37189C980258
{
  //## begin IF::EMailMessage%37189C910190.initialDeclarations preserve=yes
  //friend class vector<EMailMessage>;
  //## end IF::EMailMessage%37189C910190.initialDeclarations

  public:
    //## Constructors (generated)
      EMailMessage(const EMailMessage &right);

    //## Destructor (generated)
      virtual ~EMailMessage();

    //## Assignment Operation (generated)
      EMailMessage & operator=(const EMailMessage &right);


    //## Other Operations (specified)
      //## Operation: accept%3742C27F024D
      void accept (IF::EMailMessageVisitor& hEMailMessageVisitor);

      //## Operation: eraseAll%3C45DF7B02D4
      //	Send this mail message.
      //## Semantics:
      //	Write all records to the strDestination dataset.
      static void eraseAll ();

      //## Operation: instance%3C45DD7B01E7
      static EMailMessage* instance ();

      //## Operation: open%3742BFFA0259
      bool open (const string& strFile, const string& strMember);

      //## Operation: save%3C45DDBC00B4
      //	Send this mail message.
      //## Semantics:
      //	Write all records to the strDestination dataset.
      static void save ();

      //## Operation: send%37189DA40018
      //	Send this mail message.
      //## Semantics:
      //	Write all records to the strDestination dataset.
      bool send (const string& strFile);

      //## Operation: sendAll%3C45EA190387
      //	Send this mail message.
      //## Semantics:
      //	Write all records to the strDestination dataset.
      static bool sendAll ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: File%44ED99A70332
      const string& getFile () const
      {
        //## begin IF::EMailMessage::getFile%44ED99A70332.get preserve=no
        return m_strFile;
        //## end IF::EMailMessage::getFile%44ED99A70332.get
      }

      void setFile (const string& value)
      {
        //## begin IF::EMailMessage::setFile%44ED99A70332.set preserve=no
        m_strFile = value;
        //## end IF::EMailMessage::setFile%44ED99A70332.set
      }


    // Additional Public Declarations
      //## begin IF::EMailMessage%37189C910190.public preserve=yes
      //## end IF::EMailMessage%37189C910190.public

  protected:
    // Additional Protected Declarations
      //## begin IF::EMailMessage%37189C910190.protected preserve=yes
      //## end IF::EMailMessage%37189C910190.protected

  private:
    //## Constructors (generated)
      EMailMessage();

    // Data Members for Class Attributes

      //## begin IF::EMailMessage::File%44ED99A70332.attr preserve=no  public: string {U} 
      string m_strFile;
      //## end IF::EMailMessage::File%44ED99A70332.attr

    // Additional Private Declarations
      //## begin IF::EMailMessage%37189C910190.private preserve=yes
      //## end IF::EMailMessage%37189C910190.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3C45DE8A0010
      //## begin IF::EMailMessage::Instance%3C45DE8A0010.attr preserve=no  private: static EMailMessage {R} 0
      static EMailMessage *m_pInstance;
      //## end IF::EMailMessage::Instance%3C45DE8A0010.attr

    // Data Members for Associations

      //## Association: Connex Library::IF_CAT::<unnamed>%3A1552880213
      //## Role: EMailMessage::<m_pMemory>%3A15528A01BC
      //## begin IF::EMailMessage::<m_pMemory>%3A15528A01BC.role preserve=no  public: static IF::Memory { -> RHgN}
      static Memory *m_pMemory;
      //## end IF::EMailMessage::<m_pMemory>%3A15528A01BC.role

      //## Association: Connex Library::IF_CAT::<unnamed>%3E859FE90290
      //## Role: EMailMessage::<m_hEMailMessages>%3E859FEA0109
      //## begin IF::EMailMessage::<m_hEMailMessages>%3E859FEA0109.role preserve=no  public: static IF::EMailMessage {1 -> 0..*VFHgN}
      static vector<EMailMessage> m_hEMailMessages;
      //## end IF::EMailMessage::<m_hEMailMessages>%3E859FEA0109.role

    // Additional Implementation Declarations
      //## begin IF::EMailMessage%37189C910190.implementation preserve=yes
      std::vector<string> m_hFormat;
      std::vector<string> m_hText;
      //## end IF::EMailMessage%37189C910190.implementation
};

//## begin IF::EMailMessage%37189C910190.postscript preserve=yes
//## end IF::EMailMessage%37189C910190.postscript

} // namespace IF

//## begin module%37189CF10025.epilog preserve=yes
using namespace IF;
//## end module%37189CF10025.epilog


#endif
