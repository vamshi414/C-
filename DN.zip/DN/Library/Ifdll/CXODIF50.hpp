//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%491ED9AD01A5.cm preserve=no
//## end module%491ED9AD01A5.cm

//## begin module%491ED9AD01A5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%491ED9AD01A5.cp

//## Module: CXOSIF50%491ED9AD01A5; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF50.hpp

#ifndef CXOSIF50_h
#define CXOSIF50_h 1

//## begin module%491ED9AD01A5.additionalIncludes preserve=no
//## end module%491ED9AD01A5.additionalIncludes

//## begin module%491ED9AD01A5.includes preserve=yes
//## end module%491ED9AD01A5.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Thread;
class Trace;
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class SecondaryCodes;
class SiteSpecification;
class Extract;

} // namespace IF

//## begin module%491ED9AD01A5.declarations preserve=no
//## end module%491ED9AD01A5.declarations

//## begin module%491ED9AD01A5.additionalDeclarations preserve=yes
//## end module%491ED9AD01A5.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::File%491ED8FE038A.preface preserve=yes
#define VB_BLOCKSIZE 8192
//## end IF::File%491ED8FE038A.preface

//## Class: File%491ED8FE038A
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%491EDB81037A;Extract { -> F}
//## Uses: <unnamed>%491EDB8400FA;Trace { -> F}
//## Uses: <unnamed>%491EDB8602AF;SecondaryCodes { -> F}
//## Uses: <unnamed>%491EDBAE009C;reusable::Transaction { -> F}
//## Uses: <unnamed>%491EDBC1009C;SiteSpecification { -> F}
//## Uses: <unnamed>%5AE088BD0237;reusable::Thread { -> F}
//## Uses: <unnamed>%63CDB12D00BE;reusable::Trace { -> F}

class DllExport File : public reusable::Object  //## Inherits: <unnamed>%491ED935007D
{
  //## begin IF::File%491ED8FE038A.initialDeclarations preserve=yes
  public:
      enum OpenType
      {
         CX_OPEN_INPUT,
         CX_OPEN_OUTPUT,
         CX_OPEN_UPDATE,
         CX_OPEN_RESET,
         CX_OPEN_APPEND
      };
      enum AccessOption
      {
         ADR,
         CNV,
         KEY,
         DIR,
         SEQ,
         SKP,
         ARD,
         LRD,
         FWD,
         BWD,
         NSP,
         NUP,
         UPD,
         KEQ,
         KGE,
         FKS,
         GEN,
         LOC,
         MVE
      };
      enum SeekOffset
      {
         CX_SEEK_SET = 0,
         CX_SEEK_CUR = 1,
         CX_SEEK_END = 2
      };
  //## end IF::File%491ED8FE038A.initialDeclarations

  public:
    //## Constructors (generated)
      File();

    //## Constructors (specified)
      //## Operation: File%491ED947032C
      File (const char* pszName, const char* pszMember);

      //## Operation: File%491ED947032F
      File (const char* pszName);

    //## Destructor (generated)
      virtual ~File();


    //## Other Operations (specified)
      //## Operation: block%63CDAF2A0113
      bool block (char* psBuffer, int lRecordLength);

      //## Operation: close%491ED947033C
      virtual bool close ();

      //## Operation: copy%4C519CAD0394
      virtual bool copy (const char* pszTarget, const char* pszOutputFileName = 0);

      //## Operation: datasetName%491ED947033D
      virtual const string& datasetName ();

      //## Operation: deblock%63CDAEE902F7
      int deblock (char* psBuffer, size_t lBufferLength);

      //## Operation: decrypt%63CDAE570360
      virtual bool decrypt (char* psBuffer, int* plRecordLength);

      //## Operation: flush%491ED947034B
      virtual bool flush ();

      //## Operation: getBaseName%4C507D9101FE
      virtual bool getBaseName (string& strBaseName, bool bIncludeExtension = false);

      //## Operation: isMail%52D93CFA038B
      virtual bool isMail ();

      //## Operation: isOpen%491ED947034C
      bool isOpen ();

      //## Operation: move%491ED947035B
      virtual bool move (const char* pszTarget, const char* pszOutputFileName = 0);

      //## Operation: open%491ED947035D
      virtual bool open (enum OpenType nOpenType = CX_OPEN_INPUT);

      //## Operation: read%491ED947036B
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool* pbReadError = NULL);

      //## Operation: remove%491ED947037A
      virtual bool remove ();

      //## Operation: seek%516C0A7E00EE
      virtual void seek (int SeekPos, enum SeekOffset nSeekOffset = CX_SEEK_SET);

      //## Operation: setAccessOption%491ED947037B
      virtual void setAccessOption (enum AccessOption nAccessOption);

      //## Operation: setDatasetName%491ED947038A
      void setDatasetName (const char* pszDatasetName);

      //## Operation: setMember%491ED9470399
      virtual void setMember (const char* pszMember);

      //## Operation: setName%491ED947039B
      void setName (const char* pszName);

      //## Operation: setPath%491ED94703A9
      void setPath (const string& strPath);

      //## Operation: system%63CDADD5026D
      static int system (const char* command);

      //## Operation: tellg%516C0AEF027E
      virtual int tellg ();

      //## Operation: unzip%4C6955F3033F
      virtual bool unzip ();

      //## Operation: write%491ED94703B9
      virtual bool write (char* psBuffer, int lRecordLength);

      //## Operation: zip%4C6955EC034E
      virtual bool zip (const string& strArchiveName);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Block%63CDAACA025D
      const char* getBlock () const
      {
        //## begin IF::File::getBlock%63CDAACA025D.get preserve=no
        return m_psBlock;
        //## end IF::File::getBlock%63CDAACA025D.get
      }


      //## Attribute: BlockSize%63CDAAAE0376
      const int getBlockSize () const
      {
        //## begin IF::File::getBlockSize%63CDAAAE0376.get preserve=no
        return m_iBlockSize;
        //## end IF::File::getBlockSize%63CDAAAE0376.get
      }


      //## Attribute: Cursor%63CDAAF70004
      const char* getCursor () const
      {
        //## begin IF::File::getCursor%63CDAAF70004.get preserve=no
        return m_psCursor;
        //## end IF::File::getCursor%63CDAAF70004.get
      }


      //## Attribute: DatasetName%491ED984006D
      const reusable::string& getDatasetName () const
      {
        //## begin IF::File::getDatasetName%491ED984006D.get preserve=no
        return m_strDatasetName;
        //## end IF::File::getDatasetName%491ED984006D.get
      }


      //## Attribute: Date%491ED984007D
      const reusable::string& getDate () const
      {
        //## begin IF::File::getDate%491ED984007D.get preserve=no
        return m_strDate;
        //## end IF::File::getDate%491ED984007D.get
      }

      void setDate (const reusable::string& value)
      {
        //## begin IF::File::setDate%491ED984007D.set preserve=no
        m_strDate = value;
        //## end IF::File::setDate%491ED984007D.set
      }


      //## Attribute: DX_FILE_ID%63CDB94000DC
      const int getDX_FILE_ID () const
      {
        //## begin IF::File::getDX_FILE_ID%63CDB94000DC.get preserve=no
        return m_iDX_FILE_ID;
        //## end IF::File::getDX_FILE_ID%63CDB94000DC.get
      }

      void setDX_FILE_ID (int value)
      {
        //## begin IF::File::setDX_FILE_ID%63CDB94000DC.set preserve=no
        m_iDX_FILE_ID = value;
        //## end IF::File::setDX_FILE_ID%63CDB94000DC.set
      }


      //## Attribute: DX_REPORT_ID%55F9C7750367
      const int getDX_REPORT_ID () const
      {
        //## begin IF::File::getDX_REPORT_ID%55F9C7750367.get preserve=no
        return m_iDX_REPORT_ID;
        //## end IF::File::getDX_REPORT_ID%55F9C7750367.get
      }

      void setDX_REPORT_ID (int value)
      {
        //## begin IF::File::setDX_REPORT_ID%55F9C7750367.set preserve=no
        m_iDX_REPORT_ID = value;
        //## end IF::File::setDX_REPORT_ID%55F9C7750367.set
      }


      //## Attribute: Encryption%63CDAC2901AE
      const bool getEncryption () const
      {
        //## begin IF::File::getEncryption%63CDAC2901AE.get preserve=no
        return m_bEncryption;
        //## end IF::File::getEncryption%63CDAC2901AE.get
      }

      void setEncryption (bool value)
      {
        //## begin IF::File::setEncryption%63CDAC2901AE.set preserve=no
        m_bEncryption = value;
        //## end IF::File::setEncryption%63CDAC2901AE.set
      }


      //## Attribute: EOF%63CDAAF70105
      const bool getEOF () const
      {
        //## begin IF::File::getEOF%63CDAAF70105.get preserve=no
        return m_bEOF;
        //## end IF::File::getEOF%63CDAAF70105.get
      }


      //## Attribute: Flush%63CDAB2003CB
      const bool getFlush () const
      {
        //## begin IF::File::getFlush%63CDAB2003CB.get preserve=no
        return m_bFlush;
        //## end IF::File::getFlush%63CDAB2003CB.get
      }


      //## Attribute: Folder%4D2F738702CA
      void setFolder (const reusable::string& value)
      {
        //## begin IF::File::setFolder%4D2F738702CA.set preserve=no
        m_strFolder = value;
        //## end IF::File::setFolder%4D2F738702CA.set
      }


      //## Attribute: Name%491ED98400AB
      const reusable::string& getName () const
      {
        //## begin IF::File::getName%491ED98400AB.get preserve=no
        return m_strName;
        //## end IF::File::getName%491ED98400AB.get
      }


      //## Attribute: Owner%491ED98400BB
      void setOwner (const reusable::string& value)
      {
        //## begin IF::File::setOwner%491ED98400BB.set preserve=no
        m_strOwner = value;
        //## end IF::File::setOwner%491ED98400BB.set
      }


      //## Attribute: RecordCount%491ED98400CB
      const int getRecordCount () const
      {
        //## begin IF::File::getRecordCount%491ED98400CB.get preserve=no
        return m_iRecordCount;
        //## end IF::File::getRecordCount%491ED98400CB.get
      }


      //## Attribute: RecordFormat%491ED98400DA
      void setRecordFormat (const reusable::string& value)
      {
        //## begin IF::File::setRecordFormat%491ED98400DA.set preserve=no
        m_strRecordFormat = value;
        //## end IF::File::setRecordFormat%491ED98400DA.set
      }


      //## Attribute: Remainder%63CDAAAF0154
      const int getRemainder () const
      {
        //## begin IF::File::getRemainder%63CDAAAF0154.get preserve=no
        return m_iRemainder;
        //## end IF::File::getRemainder%63CDAAAF0154.get
      }


      //## Attribute: ScheduledTime%491ED98400EA
      const reusable::string& getScheduledTime () const
      {
        //## begin IF::File::getScheduledTime%491ED98400EA.get preserve=no
        return m_strScheduledTime;
        //## end IF::File::getScheduledTime%491ED98400EA.get
      }

      void setScheduledTime (const reusable::string& value)
      {
        //## begin IF::File::setScheduledTime%491ED98400EA.set preserve=no
        m_strScheduledTime = value;
        //## end IF::File::setScheduledTime%491ED98400EA.set
      }


      //## Attribute: Sequence%491ED98400EB
      const int getSequence () const
      {
        //## begin IF::File::getSequence%491ED98400EB.get preserve=no
        return m_lSequence;
        //## end IF::File::getSequence%491ED98400EB.get
      }

      void setSequence (int value)
      {
        //## begin IF::File::setSequence%491ED98400EB.set preserve=no
        m_lSequence = value;
        //## end IF::File::setSequence%491ED98400EB.set
      }


      //## Attribute: Type%4B5620630000
      const reusable::string& getType () const
      {
        //## begin IF::File::getType%4B5620630000.get preserve=no
        return m_strType;
        //## end IF::File::getType%4B5620630000.get
      }


    // Additional Public Declarations
      //## begin IF::File%491ED8FE038A.public preserve=yes
#ifdef _WIN64
      long long m_lFile;
      const long long getFile () const
#else
      long m_lFile;
      const long getFile () const
#endif
      {
         return m_lFile;
      }
      //## end IF::File%491ED8FE038A.public
  protected:
    // Data Members for Class Attributes

      //## begin IF::File::Block%63CDAACA025D.attr preserve=no  public: char* {V} 0
      char* m_psBlock;
      //## end IF::File::Block%63CDAACA025D.attr

      //## begin IF::File::BlockSize%63CDAAAE0376.attr preserve=no  public: int {V} 65536
      int m_iBlockSize;
      //## end IF::File::BlockSize%63CDAAAE0376.attr

      //## begin IF::File::Cursor%63CDAAF70004.attr preserve=no  public: char* {V} 0
      char* m_psCursor;
      //## end IF::File::Cursor%63CDAAF70004.attr

      //## begin IF::File::DatasetName%491ED984006D.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strDatasetName;
      //## end IF::File::DatasetName%491ED984006D.attr

      //## begin IF::File::Encryption%63CDAC2901AE.attr preserve=no  public: bool {V} false
      bool m_bEncryption;
      //## end IF::File::Encryption%63CDAC2901AE.attr

      //## begin IF::File::EOF%63CDAAF70105.attr preserve=no  public: bool {V} false
      bool m_bEOF;
      //## end IF::File::EOF%63CDAAF70105.attr

      //## begin IF::File::Flush%63CDAB2003CB.attr preserve=no  public: bool {V} false
      bool m_bFlush;
      //## end IF::File::Flush%63CDAB2003CB.attr

      //## Attribute: Member%491ED984009C
      //## begin IF::File::Member%491ED984009C.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strMember;
      //## end IF::File::Member%491ED984009C.attr

      //## begin IF::File::Name%491ED98400AB.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strName;
      //## end IF::File::Name%491ED98400AB.attr

      //## begin IF::File::RecordCount%491ED98400CB.attr preserve=no  public: int {V} 0
      int m_iRecordCount;
      //## end IF::File::RecordCount%491ED98400CB.attr

      //## begin IF::File::RecordFormat%491ED98400DA.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strRecordFormat;
      //## end IF::File::RecordFormat%491ED98400DA.attr

      //## begin IF::File::Remainder%63CDAAAF0154.attr preserve=no  public: int {V} 0
      int m_iRemainder;
      //## end IF::File::Remainder%63CDAAAF0154.attr

      //## Attribute: TemporaryCount%639F8FD902D4
      //## begin IF::File::TemporaryCount%639F8FD902D4.attr preserve=no  protected: static int {VA} 0
      static int m_iTemporaryCount;
      //## end IF::File::TemporaryCount%639F8FD902D4.attr

      //## Attribute: TemporaryName%639F90000095
      //## begin IF::File::TemporaryName%639F90000095.attr preserve=no  protected: reusable::string {VA} 
      reusable::string m_strTemporaryName;
      //## end IF::File::TemporaryName%639F90000095.attr

    // Additional Protected Declarations
      //## begin IF::File%491ED8FE038A.protected preserve=yes
      //## end IF::File%491ED8FE038A.protected

  private:
    // Additional Private Declarations
      //## begin IF::File%491ED8FE038A.private preserve=yes
      //## end IF::File%491ED8FE038A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin IF::File::Date%491ED984007D.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strDate;
      //## end IF::File::Date%491ED984007D.attr

      //## begin IF::File::DX_FILE_ID%63CDB94000DC.attr preserve=no  public: int {V} 0
      int m_iDX_FILE_ID;
      //## end IF::File::DX_FILE_ID%63CDB94000DC.attr

      //## begin IF::File::DX_REPORT_ID%55F9C7750367.attr preserve=no  public: int {V} 0
      int m_iDX_REPORT_ID;
      //## end IF::File::DX_REPORT_ID%55F9C7750367.attr

      //## begin IF::File::Folder%4D2F738702CA.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strFolder;
      //## end IF::File::Folder%4D2F738702CA.attr

      //## Attribute: Hundreths%491ED984008C
      //## begin IF::File::Hundreths%491ED984008C.attr preserve=no  private: static short {V} 0
      static short m_siHundreths;
      //## end IF::File::Hundreths%491ED984008C.attr

      //## begin IF::File::Owner%491ED98400BB.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strOwner;
      //## end IF::File::Owner%491ED98400BB.attr

      //## begin IF::File::ScheduledTime%491ED98400EA.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strScheduledTime;
      //## end IF::File::ScheduledTime%491ED98400EA.attr

      //## begin IF::File::Sequence%491ED98400EB.attr preserve=no  public: int {V} 0
      int m_lSequence;
      //## end IF::File::Sequence%491ED98400EB.attr

      //## begin IF::File::Type%4B5620630000.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strType;
      //## end IF::File::Type%4B5620630000.attr

    // Additional Implementation Declarations
      //## begin IF::File%491ED8FE038A.implementation preserve=yes
      //## end IF::File%491ED8FE038A.implementation

};

//## begin IF::File%491ED8FE038A.postscript preserve=yes
//## end IF::File%491ED8FE038A.postscript

} // namespace IF

//## begin module%491ED9AD01A5.epilog preserve=yes
//## end module%491ED9AD01A5.epilog


#endif
