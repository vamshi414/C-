//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%36DBF5E3008B.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DBF5E3008B.cm

//## begin module%36DBF5E3008B.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DBF5E3008B.cp

//## Module: CXOSIF31%36DBF5E3008B; Package specification
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXODIF31.hpp

#ifndef CXOSIF31_h
#define CXOSIF31_h 1

//## begin module%36DBF5E3008B.additionalIncludes preserve=no
//## end module%36DBF5E3008B.additionalIncludes

//## begin module%36DBF5E3008B.includes preserve=yes
// $Date:   Apr 08 2004 07:21:22  $ $Author:   D02405  $ $Revision:   1.2  $
#include <stdio.h>
//## end module%36DBF5E3008B.includes

#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Signal;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Message;

} // namespace IF

//## begin module%36DBF5E3008B.declarations preserve=no
//## end module%36DBF5E3008B.declarations

//## begin module%36DBF5E3008B.additionalDeclarations preserve=yes
//## end module%36DBF5E3008B.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::DiskQueue%36DBF58D0038.preface preserve=yes
//## end IF::DiskQueue%36DBF58D0038.preface

//## Class: DiskQueue%36DBF58D0038
//## Category: Connex Foundation::IF_CAT%3451F55F009E
//## Subsystem: IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%36DC424D038A;Message { -> F}
//## Uses: <unnamed>%36DD559B018F;reusable::Signal { -> F}

class DllExport DiskQueue : public Queue  //## Inherits: <unnamed>%36DBF5980232
{
  //## begin IF::DiskQueue%36DBF58D0038.initialDeclarations preserve=yes
  //## end IF::DiskQueue%36DBF58D0038.initialDeclarations

  public:
    //## Constructors (generated)
      DiskQueue();

    //## Constructors (specified)
      //## Operation: DiskQueue%36DD52F40048
      DiskQueue (const char* pszName);

    //## Destructor (generated)
      virtual ~DiskQueue();


    //## Other Operations (specified)
      //## Operation: close%36DD52BD02D4
      virtual bool close ();

      //## Operation: open%36DD52BF03DB
      virtual bool open ();

      //## Operation: send%36DE953B0002
      virtual bool send (Message* pMessage, enum MessageType nMessageType);

      //## Operation: update%36DC66680219
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin IF::DiskQueue%36DBF58D0038.public preserve=yes
      //## end IF::DiskQueue%36DBF58D0038.public

  protected:
    // Additional Protected Declarations
      //## begin IF::DiskQueue%36DBF58D0038.protected preserve=yes
      //## end IF::DiskQueue%36DBF58D0038.protected

  private:
    // Additional Private Declarations
      //## begin IF::DiskQueue%36DBF58D0038.private preserve=yes
      //## end IF::DiskQueue%36DBF58D0038.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Queue%36DBF6DD032A
      //## begin IF::DiskQueue::Queue%36DBF6DD032A.attr preserve=no  private: FILE* {U} 
      FILE* m_pQueue;
      //## end IF::DiskQueue::Queue%36DBF6DD032A.attr

    // Additional Implementation Declarations
      //## begin IF::DiskQueue%36DBF58D0038.implementation preserve=yes
      //## end IF::DiskQueue%36DBF58D0038.implementation

};

//## begin IF::DiskQueue%36DBF58D0038.postscript preserve=yes
//## end IF::DiskQueue%36DBF58D0038.postscript

} // namespace IF

//## begin module%36DBF5E3008B.epilog preserve=yes
using namespace IF;
//## end module%36DBF5E3008B.epilog


#endif
