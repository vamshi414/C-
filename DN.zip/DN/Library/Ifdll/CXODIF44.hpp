//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3EC395590157.cm preserve=no
//	$Date:   Oct 04 2011 09:13:44  $ $Author:   e1009839  $
//	$Revision:   1.5  $
//## end module%3EC395590157.cm

//## begin module%3EC395590157.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%3EC395590157.cp

//## Module: CXOSIF44%3EC395590157; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF44.hpp

#ifndef CXOSIF44_h
#define CXOSIF44_h 1

//## begin module%3EC395590157.additionalIncludes preserve=no
//## end module%3EC395590157.additionalIncludes

//## begin module%3EC395590157.includes preserve=yes
#include <map>
//## end module%3EC395590157.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class AdvancedEncryptionStandard;
class Extract;

} // namespace IF

//## begin module%3EC395590157.declarations preserve=no
//## end module%3EC395590157.declarations

//## begin module%3EC395590157.additionalDeclarations preserve=yes
//## end module%3EC395590157.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::SiteSpecification%3EC3947302CE.preface preserve=yes
//## end IF::SiteSpecification%3EC3947302CE.preface

//## Class: SiteSpecification%3EC3947302CE
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3EC394AD0119;Extract { -> F}
//## Uses: <unnamed>%3EC3D20F029F;reusable::Transaction { -> F}
//## Uses: <unnamed>%3EC4EABE01D4;Trace { -> F}
//## Uses: <unnamed>%4E8B0B23021F;AdvancedEncryptionStandard { -> F}

class DllExport SiteSpecification : public reusable::Object  //## Inherits: <unnamed>%3EC39496004E
{
  //## begin IF::SiteSpecification%3EC3947302CE.initialDeclarations preserve=yes
  //## end IF::SiteSpecification%3EC3947302CE.initialDeclarations

  public:
    //## Constructors (generated)
      SiteSpecification();

    //## Destructor (generated)
      virtual ~SiteSpecification();


    //## Other Operations (specified)
      //## Operation: add%3F205E4202BF
      bool add (string& strFirst, string& strSecond);

      //## Operation: instance%3EC394D602AF
      static SiteSpecification* instance ();

      //## Operation: parseInclude%3ECD1F1101B5
      bool parseInclude (char* pszBuffer);

      //## Operation: substitute%3EC395CE00BB
      //## Preconditions:
      //	<body>
      //	<title>IG
      //	<h1>H*
      //	<h2>FI
      //	<h3>Site Specification
      //	<p>
      //	<table>
      //	<tr>
      //	<th>Variable
      //	<th>Default
      //	<th>Comments
      //	<tr>
      //	<td><i>db2name</i>
      //	<td>
      //	<td>
      //	<tr>
      //	<td><i>fax</i>
      //	<td>
      //	<td>
      //	<tr>
      //	<td><i>mail</i>
      //	<td>
      //	<td>
      //	<tr>
      //	<td><i>node001</i>
      //	<td>\\<i>proc</i>\eFunds\Server
      //	<td>
      //	<tr>
      //	<td><i>password</i>
      //	<td>
      //	<td>
      //	<tr>
      //	<td><i>plan</i>
      //	<td>
      //	<td>
      //	<tr>
      //	<td><i>portpfm</i>
      //	<td>52000
      //	<td>
      //	<tr>
      //	<td><i>porttfm</i>
      //	<td>52000
      //	<td>
      //	<tr>
      //	<td><i>proc</i>
      //	<td>
      //	<td>Application server DNS name
      //	<tr>
      //	<td><i>qualify</i>
      //	<td>
      //	<td>
      //	<tr>
      //	<td><i>service</i>
      //	<td>DataNavigator
      //	<td>
      //	<tr>
      //	<td><i>userid</i>
      //	<td>
      //	<td>
      //	</table>
      //	</p>
      //	<h3>Customer Specification
      //	<p>
      //	<table>
      //	<tr>
      //	<th>Variable
      //	<th>Default
      //	<th>Comments
      //	<tr>
      //	<td><i>aimodule</i>
      //	<td>CXOPXI00
      //	<td>Acquiring platform transaction interface module
      //	<tr>
      //	<td><i>cumodule</i>
      //	<td>CXOPXC00
      //	<td>Acquiring platform configuration interface module
      //	<tr>
      //	<td><i>custabbr</i>
      //	<td>AC
      //	<td>Two character customer abbreviation
      //	<tr>
      //	<td><i>custqual</i>
      //	<td>
      //	<td>
      //	<tr>
      //	<td><i>customer</i>
      //	<td>ACME
      //	<td>Four character customer abbreviation
      //	<tr>
      //	<td><i>dba</i>
      //	<td>
      //	<td>
      //	<tr>
      //	<td><i>lethread</i>
      //	<td>3
      //	<td>
      //	<tr>
      //	<td><i>loctabs</i>
      //	<td>8
      //	<td>
      //	<tr>
      //	<td><i>log</i>
      //	<td>yyyymmdd~01
      //	<td>First log file to load with DataNavigator
      //	<tr>
      //	<td><i>parts</i>
      //	<td>
      //	<td>
      //	<tr>
      //	<td><i>portprod</i>
      //	<td>51000
      //	<td>
      //	<tr>
      //	<td><i>porttest</i>
      //	<td>51000
      //	<td>
      //	<tr>
      //	<td><i>qethread</i>
      //	<td>4
      //	<td>
      //	<tr>
      //	<td><i>rethread</i>
      //	<td>2
      //	<td>
      //	<tr>
      //	<td><i>set</i>
      //	<td>1
      //	<td>
      //	<tr>
      //	<td><i>unload</i>
      //	<td>000004
      //	<td>
      //	</table>
      //	</p>
      //	</body>
      bool substitute (string& strBuffer, int i = 0, int j = 0);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Count%3ECD1ED3035B
      const int* getCount () const
      {
        //## begin IF::SiteSpecification::getCount%3ECD1ED3035B.get preserve=no
        return m_iCount;
        //## end IF::SiteSpecification::getCount%3ECD1ED3035B.get
      }


      //## Attribute: Member%3ECD23420186
      const string& getMember () const
      {
        //## begin IF::SiteSpecification::getMember%3ECD23420186.get preserve=no
        return m_strMember;
        //## end IF::SiteSpecification::getMember%3ECD23420186.get
      }


      //## Attribute: Offset%3ED35868035B
      const int* getOffset () const
      {
        //## begin IF::SiteSpecification::getOffset%3ED35868035B.get preserve=no
        return m_iOffset;
        //## end IF::SiteSpecification::getOffset%3ED35868035B.get
      }


    // Additional Public Declarations
      //## begin IF::SiteSpecification%3EC3947302CE.public preserve=yes
      //## end IF::SiteSpecification%3EC3947302CE.public

  protected:
    // Additional Protected Declarations
      //## begin IF::SiteSpecification%3EC3947302CE.protected preserve=yes
      //## end IF::SiteSpecification%3EC3947302CE.protected

  private:
    // Additional Private Declarations
      //## begin IF::SiteSpecification%3EC3947302CE.private preserve=yes
      //## end IF::SiteSpecification%3EC3947302CE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin IF::SiteSpecification::Count%3ECD1ED3035B.attr preserve=no  public: int[2] {V} 
      int m_iCount[2];
      //## end IF::SiteSpecification::Count%3ECD1ED3035B.attr

      //## Attribute: Format%3ECD1E6D03D8
      //## begin IF::SiteSpecification::Format%3ECD1E6D03D8.attr preserve=no  private: string[2] {V} 
      string m_strFormat[2];
      //## end IF::SiteSpecification::Format%3ECD1E6D03D8.attr

      //## Attribute: Index%3ECD1E8B0271
      //## begin IF::SiteSpecification::Index%3ECD1E8B0271.attr preserve=no  private: string[2] {V} 
      string m_strIndex[2];
      //## end IF::SiteSpecification::Index%3ECD1E8B0271.attr

      //## Attribute: Instance%3EC394BE029F
      //## begin IF::SiteSpecification::Instance%3EC394BE029F.attr preserve=no  private: static SiteSpecification* {V} 0
      static SiteSpecification* m_pInstance;
      //## end IF::SiteSpecification::Instance%3EC394BE029F.attr

      //## begin IF::SiteSpecification::Member%3ECD23420186.attr preserve=no  public: string {V} 
      string m_strMember;
      //## end IF::SiteSpecification::Member%3ECD23420186.attr

      //## begin IF::SiteSpecification::Offset%3ED35868035B.attr preserve=no  public: int[2] {V} 
      int m_iOffset[2];
      //## end IF::SiteSpecification::Offset%3ED35868035B.attr

    // Additional Implementation Declarations
      //## begin IF::SiteSpecification%3EC3947302CE.implementation preserve=yes
      map<string,string,less <string> > m_hValues;
      //## end IF::SiteSpecification%3EC3947302CE.implementation
};

//## begin IF::SiteSpecification%3EC3947302CE.postscript preserve=yes
//## end IF::SiteSpecification%3EC3947302CE.postscript

} // namespace IF

//## begin module%3EC395590157.epilog preserve=yes
using namespace IF;
//## end module%3EC395590157.epilog


#endif
