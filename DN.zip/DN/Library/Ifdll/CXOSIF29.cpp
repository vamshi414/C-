//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36DAA0BC0036.cm preserve=no
//	$Date:   Jun 30 2006 11:35:50  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%36DAA0BC0036.cm

//## begin module%36DAA0BC0036.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%36DAA0BC0036.cp

//## Module: CXOSIF29%36DAA0BC0036; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXOSIF29.cpp

//## begin module%36DAA0BC0036.additionalIncludes preserve=no
//## end module%36DAA0BC0036.additionalIncludes

//## begin module%36DAA0BC0036.includes preserve=yes
// $Date:   Jun 30 2006 11:35:50  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%36DAA0BC0036.includes

#ifndef CXOSIF29_h
#include "CXODIF29.hpp"
#endif
//## begin module%36DAA0BC0036.declarations preserve=no
//## end module%36DAA0BC0036.declarations

//## begin module%36DAA0BC0036.additionalDeclarations preserve=yes
//## end module%36DAA0BC0036.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::MDSSignal 

MDSSignal::MDSSignal()
  //## begin MDSSignal::MDSSignal%36DA9C0C01A3_const.hasinit preserve=no
  //## end MDSSignal::MDSSignal%36DA9C0C01A3_const.hasinit
  //## begin MDSSignal::MDSSignal%36DA9C0C01A3_const.initialization preserve=yes
  //## end MDSSignal::MDSSignal%36DA9C0C01A3_const.initialization
{
  //## begin IF::MDSSignal::MDSSignal%36DA9C0C01A3_const.body preserve=yes
   memcpy(m_sID,"IF29",4);
  //## end IF::MDSSignal::MDSSignal%36DA9C0C01A3_const.body
}


MDSSignal::~MDSSignal()
{
  //## begin IF::MDSSignal::~MDSSignal%36DA9C0C01A3_dest.body preserve=yes
  //## end IF::MDSSignal::~MDSSignal%36DA9C0C01A3_dest.body
}



//## Other Operations (implementation)
long MDSSignal::getMutex ()
{
  //## begin IF::MDSSignal::getMutex%36DA9EE501BF.body preserve=yes
   return 0; // ECB address is filled in by CXQWFM
  //## end IF::MDSSignal::getMutex%36DA9EE501BF.body
}

// Additional Declarations
  //## begin IF::MDSSignal%36DA9C0C01A3.declarations preserve=yes
  //## end IF::MDSSignal%36DA9C0C01A3.declarations

} // namespace IF

//## begin module%36DAA0BC0036.epilog preserve=yes
//## end module%36DAA0BC0036.epilog
