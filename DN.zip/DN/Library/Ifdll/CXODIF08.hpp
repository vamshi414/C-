//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35ADFD6803DD.cm preserve=no
//	$Date:   Jun 19 2020 08:38:34  $ $Author:   e1009839  $
//	$Revision:   1.11  $
//## end module%35ADFD6803DD.cm

//## begin module%35ADFD6803DD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%35ADFD6803DD.cp

//## Module: CXOSIF08%35ADFD6803DD; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF08.hpp

#ifndef CXOSIF08_h
#define CXOSIF08_h 1

//## begin module%35ADFD6803DD.additionalIncludes preserve=no
//## end module%35ADFD6803DD.additionalIncludes

//## begin module%35ADFD6803DD.includes preserve=yes
//## end module%35ADFD6803DD.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class IString;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;

} // namespace IF

//## begin module%35ADFD6803DD.declarations preserve=no
//## end module%35ADFD6803DD.declarations

//## begin module%35ADFD6803DD.additionalDeclarations preserve=yes
//## end module%35ADFD6803DD.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::DateTime%345407FC0130.preface preserve=yes
//## end IF::DateTime%345407FC0130.preface

//## Class: DateTime%345407FC0130
//	The DateTime class provides timestamp access and
//	calculation functions.
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3BFE8383005D;reusable::IString { -> F}
//## Uses: <unnamed>%47FC87DA003D;CodeTable { -> F}

class DllExport DateTime : public reusable::Object  //## Inherits: <unnamed>%34801C6E0160
{
  //## begin IF::DateTime%345407FC0130.initialDeclarations preserve=yes
  //## end IF::DateTime%345407FC0130.initialDeclarations

  public:
    //## Constructors (generated)
      DateTime();

    //## Destructor (generated)
      virtual ~DateTime();


    //## Other Operations (specified)
      //## Operation: adjust%52B4A3A30119
      static int adjust (string& strDateTime, int iOffset);

      //## Operation: adjust%5EDFEFF8006C
      static int adjust (char* psDate, char* psTime, int iOffset);

      //## Operation: calcCentury%38502064000A
      static void calcCentury (const char* psDateYYMMDD, char* psCentury);

      //## Operation: calcMinsElapsed%3947F51E006D
      int calcMinsElapsed (DateTime& hDateTime);

      //## Operation: calcQueueTime%385024DF0097
      int calcQueueTime (DateTime& hDateTime);

      //## Operation: convertToTandem%385025570276
      void convertToTandem (IString& strYYYYMMDDHHMMSS, IString& strTimestamp);

      //## Operation: dateTime%385025960277
      void dateTime (IString& hDateTime);

      //## Operation: format%5C8604F80186
      static void format (reusable::string& strTstamp, const reusable::string& strFormat);

      //## Operation: getDateTimeClock%5EDFF8580386
      static int getDateTimeClock (char* psDateTime, char* psStck);

      //## Operation: getIBMStck%385025E00273
      void getIBMStck (IString& strStck);

      //## Operation: setCurrent%385025C90054
      void setCurrent (IString& hDateTime);

      //## Operation: setDateTime%385025FD01CB
      void setDateTime (const char* psDateTime);

      //## Operation: setFromB24%393FBC0203D1
      void setFromB24 (unsigned int lTimestamp1, unsigned int lTimestamp2, IString& hDateTime);

      //## Operation: setFromIBM%3850265E0212
      void setFromIBM (const char* psTimestamp, IString& hDateTime);

      //## Operation: setFromTandem%38502618029C
      void setFromTandem (const char* psTimestamp, IString& hDateTime);

      //## Operation: timeAdjust%3850266F0130
      int timeAdjust (IString& strTstamp, int lOffset);

    // Additional Public Declarations
      //## begin IF::DateTime%345407FC0130.public preserve=yes
      //## end IF::DateTime%345407FC0130.public

  protected:
    // Additional Protected Declarations
      //## begin IF::DateTime%345407FC0130.protected preserve=yes
      //## end IF::DateTime%345407FC0130.protected

  private:
    // Additional Private Declarations
      //## begin IF::DateTime%345407FC0130.private preserve=yes
      //## end IF::DateTime%345407FC0130.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DD%385027910123
      //## begin IF::DateTime::DD%385027910123.attr preserve=no  private: char[3] {U} 
      char m_sDD[3];
      //## end IF::DateTime::DD%385027910123.attr

      //## Attribute: HN%385027AA02C3
      //## begin IF::DateTime::HN%385027AA02C3.attr preserve=no  private: char[3] {U} 
      char m_sHN[3];
      //## end IF::DateTime::HN%385027AA02C3.attr

      //## Attribute: HR%38502791035E
      //## begin IF::DateTime::HR%38502791035E.attr preserve=no  private: char[3] {U} 
      char m_sHR[3];
      //## end IF::DateTime::HR%38502791035E.attr

      //## Attribute: Hundreths%3850283400CD
      //## begin IF::DateTime::Hundreths%3850283400CD.attr preserve=no  private: static short {U} 0
      static short m_siHundreths;
      //## end IF::DateTime::Hundreths%3850283400CD.attr

      //## Attribute: MM%3850275503B1
      //## begin IF::DateTime::MM%3850275503B1.attr preserve=no  private: char[3] {U} 
      char m_sMM[3];
      //## end IF::DateTime::MM%3850275503B1.attr

      //## Attribute: MN%38502792012E
      //## begin IF::DateTime::MN%38502792012E.attr preserve=no  private: char[3] {U} 
      char m_sMN[3];
      //## end IF::DateTime::MN%38502792012E.attr

      //## Attribute: PrevSC%385027BD02DF
      //## begin IF::DateTime::PrevSC%385027BD02DF.attr preserve=no  private: static char[3] {U} {"  "}
      static char m_sPrevSC[3];
      //## end IF::DateTime::PrevSC%385027BD02DF.attr

      //## Attribute: SC%385027AA00CF
      //## begin IF::DateTime::SC%385027AA00CF.attr preserve=no  private: char[3] {U} 
      char m_sSC[3];
      //## end IF::DateTime::SC%385027AA00CF.attr

      //## Attribute: YYYY%3850269A0164
      //## begin IF::DateTime::YYYY%3850269A0164.attr preserve=no  private: char[5] {U} 
      char m_sYYYY[5];
      //## end IF::DateTime::YYYY%3850269A0164.attr

    // Additional Implementation Declarations
      //## begin IF::DateTime%345407FC0130.implementation preserve=yes
      //## end IF::DateTime%345407FC0130.implementation

};

//## begin IF::DateTime%345407FC0130.postscript preserve=yes
//## end IF::DateTime%345407FC0130.postscript

} // namespace IF

//## begin module%35ADFD6803DD.epilog preserve=yes
using namespace IF;
//## end module%35ADFD6803DD.epilog


#endif
