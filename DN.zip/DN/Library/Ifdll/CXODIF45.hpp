//  Copyright (c) 1998 - 2005
//  eFunds Corporation
// $Date:   Jun 30 2006 11:35:44  $ $Author:   D02405  $ $Revision:   1.3  $
#ifdef _WIN32
#pragma pack(push)
#endif
#pragma pack(1)

struct segDMISC
{
   char sKey[8];
   char sTASKTYPE[4];
   char sTaskVersion[4];
   char cTraceOption;
   char sFiller1[87];
   char sTMENAME1[8];
#ifdef MVS
   int lTMESEC1;
#else
   char sTMESEC1[8];
#endif
   char sTMENAME2[8];
#ifdef MVS
   int lTMESEC2;
#else
   char sTMESEC2[8];
#endif
   char sTMENAME3[8];
#ifdef MVS
   int lTMESEC3;
#else
   char sTMESEC3[8];
#endif
   int lMessageSize;
   int lNumericData[4];
   char sUserArea[80];
   char sTaskSubType[4];
   char sFiller2[11];
};

#ifdef MVS
#pragma pack(reset)
#endif
#ifdef _WIN32
#pragma pack(pop)
#endif
#ifdef _UNIX
#pragma pack()
#endif
