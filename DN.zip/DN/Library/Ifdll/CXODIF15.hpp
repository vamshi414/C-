//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%364DA5230320.cm preserve=no
//	$Date:   Jan 03 2019 16:18:46  $ $Author:   e1009839  $
//	$Revision:   1.10  $
//## end module%364DA5230320.cm

//## begin module%364DA5230320.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%364DA5230320.cp

//## Module: CXOSIF15%364DA5230320; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF15.hpp

#ifndef CXOSIF15_h
#define CXOSIF15_h 1

//## begin module%364DA5230320.additionalIncludes preserve=no
//## end module%364DA5230320.additionalIncludes

//## begin module%364DA5230320.includes preserve=yes
#include <set>
#include <vector>
//## end module%364DA5230320.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class IString;
class CriticalSection;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DateTime;

} // namespace IF

//## begin module%364DA5230320.declarations preserve=no
//## end module%364DA5230320.declarations

//## begin module%364DA5230320.additionalDeclarations preserve=yes
//## end module%364DA5230320.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Console%364DA4A70390.preface preserve=yes
//## end IF::Console%364DA4A70390.preface

//## Class: Console%364DA4A70390
//	The Console class encapsulates an interface to the
//	Connex console.
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E947B0300AB;DateTime { -> F}
//## Uses: <unnamed>%45A4E8CD002E;reusable::IString { -> F}
//## Uses: <unnamed>%5C07FF4302E6;reusable::CriticalSection { -> F}

class DllExport Console : public reusable::Object  //## Inherits: <unnamed>%385030B30203
{
  //## begin IF::Console%364DA4A70390.initialDeclarations preserve=yes
  //## end IF::Console%364DA4A70390.initialDeclarations

  public:
    //## Constructors (generated)
      Console();

    //## Destructor (generated)
      virtual ~Console();


    //## Other Operations (specified)
      //## Operation: display%385030F50260
      static void display (const char* psMessageKey, int iValue);

      //## Operation: display%3C35E73800A7
      static void display (const char* psMessageKey, const char* psText1 = 0, const char* psText2 = 0, const char* psText3 = 0, const char* psText4 = 0, const char* psText5 = 0);

      //## Operation: getMessage%43F8A08201E4
      static const vector<string>& getMessage ();

      //## Operation: purgeMessages%3E9336D2029F
      static void purgeMessages ();

    // Additional Public Declarations
      //## begin IF::Console%364DA4A70390.public preserve=yes
      //## end IF::Console%364DA4A70390.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Console%364DA4A70390.protected preserve=yes
      //## end IF::Console%364DA4A70390.protected

  private:
    // Additional Private Declarations
      //## begin IF::Console%364DA4A70390.private preserve=yes
      //## end IF::Console%364DA4A70390.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: HN%40083960004E
      //## begin IF::Console::HN%40083960004E.attr preserve=no  private: static short {U} 0
      static short m_siHN;
      //## end IF::Console::HN%40083960004E.attr

      //## Attribute: Message%3E933A9103D8
      //## begin IF::Console::Message%3E933A9103D8.attr preserve=no  public: static vector<string>* {V} 0
      static vector<string>* m_pMessage;
      //## end IF::Console::Message%3E933A9103D8.attr

      //## Attribute: PrevHHMM%449966BD035F
      //## begin IF::Console::PrevHHMM%449966BD035F.attr preserve=no  private: static char[4] {U} 
      static char m_sPrevHHMM[4];
      //## end IF::Console::PrevHHMM%449966BD035F.attr

      //## Attribute: PrevSS%400838820213
      //## begin IF::Console::PrevSS%400838820213.attr preserve=no  private: static char[2] {U} 
      static char m_sPrevSS[2];
      //## end IF::Console::PrevSS%400838820213.attr

      //## Attribute: RecentMessage%4499665D031E
      //## begin IF::Console::RecentMessage%4499665D031E.attr preserve=no  private: static set<string, less<string> > {R} 0
      static set<string, less<string> > *m_pRecentMessage;
      //## end IF::Console::RecentMessage%4499665D031E.attr

    // Additional Implementation Declarations
      //## begin IF::Console%364DA4A70390.implementation preserve=yes
      //## end IF::Console%364DA4A70390.implementation

};

//## begin IF::Console%364DA4A70390.postscript preserve=yes
//## end IF::Console%364DA4A70390.postscript

} // namespace IF

//## begin module%364DA5230320.epilog preserve=yes
using namespace IF;
//## end module%364DA5230320.epilog


#endif
