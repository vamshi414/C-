//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36DAA0BA0097.cm preserve=no
//	$Date:   Jun 30 2006 11:35:42  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%36DAA0BA0097.cm

//## begin module%36DAA0BA0097.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%36DAA0BA0097.cp

//## Module: CXOSIF29%36DAA0BA0097; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF29.hpp

#ifndef CXOSIF29_h
#define CXOSIF29_h 1

//## begin module%36DAA0BA0097.additionalIncludes preserve=no
//## end module%36DAA0BA0097.additionalIncludes

//## begin module%36DAA0BA0097.includes preserve=yes
// $Date:   Jun 30 2006 11:35:42  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%36DAA0BA0097.includes

#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
//## begin module%36DAA0BA0097.declarations preserve=no
//## end module%36DAA0BA0097.declarations

//## begin module%36DAA0BA0097.additionalDeclarations preserve=yes
//## end module%36DAA0BA0097.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::MDSSignal%36DA9C0C01A3.preface preserve=yes
//## end IF::MDSSignal%36DA9C0C01A3.preface

//## Class: MDSSignal%36DA9C0C01A3
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport MDSSignal : public reusable::Signal  //## Inherits: <unnamed>%36DA9C1E0376
{
  //## begin IF::MDSSignal%36DA9C0C01A3.initialDeclarations preserve=yes
  //## end IF::MDSSignal%36DA9C0C01A3.initialDeclarations

  public:
    //## Constructors (generated)
      MDSSignal();

    //## Destructor (generated)
      virtual ~MDSSignal();


    //## Other Operations (specified)
      //## Operation: getMutex%36DA9EE501BF
      virtual long getMutex ();

    // Additional Public Declarations
      //## begin IF::MDSSignal%36DA9C0C01A3.public preserve=yes
      //## end IF::MDSSignal%36DA9C0C01A3.public

  protected:
    // Additional Protected Declarations
      //## begin IF::MDSSignal%36DA9C0C01A3.protected preserve=yes
      //## end IF::MDSSignal%36DA9C0C01A3.protected

  private:
    // Additional Private Declarations
      //## begin IF::MDSSignal%36DA9C0C01A3.private preserve=yes
      //## end IF::MDSSignal%36DA9C0C01A3.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::MDSSignal%36DA9C0C01A3.implementation preserve=yes
      //## end IF::MDSSignal%36DA9C0C01A3.implementation

};

//## begin IF::MDSSignal%36DA9C0C01A3.postscript preserve=yes
//## end IF::MDSSignal%36DA9C0C01A3.postscript

} // namespace IF

//## begin module%36DAA0BA0097.epilog preserve=yes
using namespace IF;
//## end module%36DAA0BA0097.epilog


#endif
