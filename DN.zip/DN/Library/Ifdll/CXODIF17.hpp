// CXODIF17.hpp - Mobius API Definition
// Copyright (c) 1998 - 2007
// eFunds Corporation
// $Date:   Dec 28 2006 11:04:40  $ $Author:   D02405  $ $Revision:   1.4  $

#ifdef MVS
extern "OS"
#else
extern "C"
#endif
{
int CXCLA(void* pStatusBlock,void* pSessionHandle,void* pCloseArchiveBlock);
int CXCLS(void* pStatusBlock,void* pSessionHandle,void* pCloseSessionBlock);
int CXOPA(void* pStatusBlock,void* pSessionHandle,void* pOpenArchiveBlock);
int CXOPS(void* pStatusBlock,void* pSessionHandle,void* pOpenSessionBlock);
int CXGPA(void* pStatusBlock,void* pSessionHandle,void* pGetRecordBlock,void* pRecordBuffer);
int CXVCLO(void* pStatusBlock,void* pSessionHandle,void* pVersionCloseBlock);
int CXVOPN(void* pStatusBlock,void* pSessionHandle,void* pVersionOpenBlock);
int CXVPUT(void* pStatusBlock,void* pSessionHandle,void* pVersionPutBlock,void* pRecordBuffer,void* pIndexBuffer);
int CXVDVR(void* pVersion);
}
