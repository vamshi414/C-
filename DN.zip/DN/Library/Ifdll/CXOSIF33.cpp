//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%36DC594B0257.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DC594B0257.cm

//## begin module%36DC594B0257.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DC594B0257.cp

//## Module: CXOSIF33%36DC594B0257; Package body
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXOSIF33.cpp

//## begin module%36DC594B0257.additionalIncludes preserve=no
//## end module%36DC594B0257.additionalIncludes

//## begin module%36DC594B0257.includes preserve=yes
// $Date:   Jun 30 2006 11:35:52  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%36DC594B0257.includes

#ifndef CXOSIF29_h
#include "CXODIF29.hpp"
#endif
#ifndef CXOSIF30_h
#include "CXODIF30.hpp"
#endif
#ifndef CXOSIF33_h
#include "CXODIF33.hpp"
#endif


//## begin module%36DC594B0257.declarations preserve=no
//## end module%36DC594B0257.declarations

//## begin module%36DC594B0257.additionalDeclarations preserve=yes

#define CLASSES 2

const char* pszMDSQueueClass[CLASSES] =
{
   "Queue",
   "Signal" 
};
//## end module%36DC594B0257.additionalDeclarations


//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::MDSQueueFactory 


MDSQueueFactory::MDSQueueFactory()
  //## begin MDSQueueFactory::MDSQueueFactory%36DC581C02F2_const.hasinit preserve=no
  //## end MDSQueueFactory::MDSQueueFactory%36DC581C02F2_const.hasinit
  //## begin MDSQueueFactory::MDSQueueFactory%36DC581C02F2_const.initialization preserve=yes
  //## end MDSQueueFactory::MDSQueueFactory%36DC581C02F2_const.initialization
{
  //## begin IF::MDSQueueFactory::MDSQueueFactory%36DC581C02F2_const.body preserve=yes
   memcpy(m_sID,"IF33",4);
   string strClass;
   for (int m = 0;m < CLASSES;++m)
   {
      strClass = pszMDSQueueClass[m];
      m_hClasses.insert(map<string,int,less<string> >::value_type(strClass,m));
   }
  //## end IF::MDSQueueFactory::MDSQueueFactory%36DC581C02F2_const.body
}


MDSQueueFactory::~MDSQueueFactory()
{
  //## begin IF::MDSQueueFactory::~MDSQueueFactory%36DC581C02F2_dest.body preserve=yes
   m_hClasses.erase(m_hClasses.begin(),m_hClasses.end());
  //## end IF::MDSQueueFactory::~MDSQueueFactory%36DC581C02F2_dest.body
}



//## Other Operations (implementation)
Object* MDSQueueFactory::create (const char* pszClass, const char* pszValue)
{
  //## begin IF::MDSQueueFactory::create%36DC583303D1.body preserve=yes
   string strClass(pszClass);
   map<string,int,less<string> >::iterator pClass = m_hClasses.find(strClass);
   if (pClass == m_hClasses.end())
      return 0;
   switch ((*pClass).second)
   {
      case 0:
         return new MDSQueue(pszValue);
      case 1:
         return new MDSSignal();
   }
   return 0;
  //## end IF::MDSQueueFactory::create%36DC583303D1.body
}

// Additional Declarations
  //## begin IF::MDSQueueFactory%36DC581C02F2.declarations preserve=yes
  //## end IF::MDSQueueFactory%36DC581C02F2.declarations

} // namespace IF

//## begin module%36DC594B0257.epilog preserve=yes
//## end module%36DC594B0257.epilog
