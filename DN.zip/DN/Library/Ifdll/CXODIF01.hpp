//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36264F280102.cm preserve=no
//	$Date:   Jan 28 2020 08:07:36  $ $Author:   e3028298  $ $Revision:   1.13  $
//## end module%36264F280102.cm

//## begin module%36264F280102.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%36264F280102.cp

//## Module: CXOSIF01%36264F280102; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\V03.1C.R001\ConnexPlatform\Server\Library\Ifdll\CXODIF01.hpp

#ifndef CXOSIF01_h
#define CXOSIF01_h 1

//## begin module%36264F280102.additionalIncludes preserve=no
//## end module%36264F280102.additionalIncludes

//## begin module%36264F280102.includes preserve=yes
#include <map>
//## end module%36264F280102.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
class Trace;
class Extract;
class Console;
class AdvancedEncryptionStandard;
class SiteSpecification;

} // namespace IF

//## begin module%36264F280102.declarations preserve=no
//## end module%36264F280102.declarations

//## begin module%36264F280102.additionalDeclarations preserve=yes
//## end module%36264F280102.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Job%347C8C420266.preface preserve=yes
//## end IF::Job%347C8C420266.preface

//## Class: Job%347C8C420266
//	The Job class encapsulates an interface to the Connex
//	job submission facility.
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E42B47E008C;Trace { -> F}
//## Uses: <unnamed>%3F2159ED006D;FlatFile { -> F}
//## Uses: <unnamed>%3F215A17032C;SiteSpecification { -> F}
//## Uses: <unnamed>%44A10920033C;AdvancedEncryptionStandard { -> F}
//## Uses: <unnamed>%5435562B01B6;Console { -> F}
//## Uses: <unnamed>%5435562E0125;Extract { -> F}
//## Uses: <unnamed>%5435567B035E;reusable::Buffer { -> F}

class DllExport Job : public reusable::Object  //## Inherits: <unnamed>%347C8C4A01C8
{
  //## begin IF::Job%347C8C420266.initialDeclarations preserve=yes
  //## end IF::Job%347C8C420266.initialDeclarations

  public:
    //## Constructors (generated)
      Job();

    //## Destructor (generated)
      virtual ~Job();


    //## Other Operations (specified)
      //## Operation: getMember%40587A8103C8
      static const string& getMember ();

      //## Operation: submit%347C930A03AD
      //	Submit a batch job.
      //## Semantics:
      //	1. Call CXSJOB.
      static bool submit (const char* pszMember);

      //## Operation: submit%3626570B0015
      static bool submit (const char* pszMember, const char* psParm1, const char* psValue1, const char* psParm2 = 0, const char* psValue2 = 0, const char* psParm3 = 0, const char* psValue3 = 0, const char* psParm4 = 0, const char* psValue4 = 0, const char* psParm5 = 0, const char* psValue5 = 0, const char* psParm6 = 0, const char* psValue6 = 0, const char* psParm7 = 0, const char* psValue7 = 0, const char* psParm8 = 0, const char* psValue8 = 0);

    // Additional Public Declarations
      //## begin IF::Job%347C8C420266.public preserve=yes
      static bool submit (const char* pszMember, map<string, string, less<string> >& hParameters);
      //## end IF::Job%347C8C420266.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Job%347C8C420266.protected preserve=yes
      //## end IF::Job%347C8C420266.protected

  private:

    //## Other Operations (specified)
      //## Operation: execute%3F4F75E900DA
      static bool execute (const string &strMember);

      //## Operation: jobName%3850128500AC
      static reusable::string jobName (const char* pszMember);

    // Additional Private Declarations
      //## begin IF::Job%347C8C420266.private preserve=yes
      //## end IF::Job%347C8C420266.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Member%40587A60030D
      //## begin IF::Job::Member%40587A60030D.attr preserve=no  public: static string {R} 0
      static string *m_pstrMember;
      //## end IF::Job::Member%40587A60030D.attr

      //## Attribute: Parameters%54357DDD00CB
      //## begin IF::Job::Parameters%54357DDD00CB.attr preserve=no  private: static map<string,string,less<string> >* {V} 0
      static map<string,string,less<string> >* m_pParameters;
      //## end IF::Job::Parameters%54357DDD00CB.attr

    // Additional Implementation Declarations
      //## begin IF::Job%347C8C420266.implementation preserve=yes
      //## end IF::Job%347C8C420266.implementation

};

//## begin IF::Job%347C8C420266.postscript preserve=yes
//## end IF::Job%347C8C420266.postscript

} // namespace IF

//## begin module%36264F280102.epilog preserve=yes
using namespace IF;
//## end module%36264F280102.epilog


#endif
