//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3664097703C7.cm preserve=no
//	$Date:   Sep 13 2018 08:39:08  $ $Author:   e1009652  $ $Revision:   1.7  $
//## end module%3664097703C7.cm

//## begin module%3664097703C7.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3664097703C7.cp

//## Module: CXOSIF28%3664097703C7; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.8A.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF28.hpp

#ifndef CXOSIF28_h
#define CXOSIF28_h 1

//## begin module%3664097703C7.additionalIncludes preserve=no
//## end module%3664097703C7.additionalIncludes

//## begin module%3664097703C7.includes preserve=yes
// $Date:   Sep 13 2018 08:39:08  $ $Author:   e1009652  $ $Revision:   1.7  $
//## end module%3664097703C7.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%3664097703C7.declarations preserve=no
//## end module%3664097703C7.declarations

//## begin module%3664097703C7.additionalDeclarations preserve=yes
//## end module%3664097703C7.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Timestamp%366408C300CF.preface preserve=yes
//## end IF::Timestamp%366408C300CF.preface

//## Class: Timestamp%366408C300CF
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport Timestamp : public reusable::Object  //## Inherits: <unnamed>%366408CB03B5
{
  //## begin IF::Timestamp%366408C300CF.initialDeclarations preserve=yes
  //## end IF::Timestamp%366408C300CF.initialDeclarations

  public:
    //## Constructors (generated)
      Timestamp();

    //## Destructor (generated)
      virtual ~Timestamp();


    //## Other Operations (specified)
      //## Operation: adjust%366408D6023F
      static int adjust (string& strDate, string& strTime, int lOffset);

      //## Operation: adjustGMT%3F8AF4150000
      static int adjustGMT (string& strDate, string& strTime, int lOffset);

      //## Operation: adjustGMT%5B994D210281
      static void adjustGMT (struct tm& Tm, int lOffset);

      //## Operation: format%4433C7EE0213
      static string format (const string& strTimestamp);

      //## Operation: gmt%5B99490600AA
      static void gmt (struct tm& hTm, time_t tTime);

      //## Operation: gmtToLocal%483E77D100D2
      static int gmtToLocal (string& strYYYYMMDDHHMMSS);

    // Additional Public Declarations
      //## begin IF::Timestamp%366408C300CF.public preserve=yes
      //## end IF::Timestamp%366408C300CF.public
  protected:
    // Additional Protected Declarations
      //## begin IF::Timestamp%366408C300CF.protected preserve=yes
      //## end IF::Timestamp%366408C300CF.protected

  private:
    // Additional Private Declarations
      //## begin IF::Timestamp%366408C300CF.private preserve=yes
      //## end IF::Timestamp%366408C300CF.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::Timestamp%366408C300CF.implementation preserve=yes
      //## end IF::Timestamp%366408C300CF.implementation

};

//## begin IF::Timestamp%366408C300CF.postscript preserve=yes
//## end IF::Timestamp%366408C300CF.postscript

} // namespace IF

//## begin module%3664097703C7.epilog preserve=yes
using namespace IF;
//## end module%3664097703C7.epilog


#endif
