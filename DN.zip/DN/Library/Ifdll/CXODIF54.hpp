//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%496F4ED90026.cm preserve=no
//	$Date:   Jan 24 2009 12:40:36  $ $Author:   D02405  $
//	$Revision:   1.0  $
//## end module%496F4ED90026.cm

//## begin module%496F4ED90026.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%496F4ED90026.cp

//## Module: CXOSIF54%496F4ED90026; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF54.hpp

#ifndef CXOSIF54_h
#define CXOSIF54_h 1

//## begin module%496F4ED90026.additionalIncludes preserve=no
//## end module%496F4ED90026.additionalIncludes

//## begin module%496F4ED90026.includes preserve=yes
//## end module%496F4ED90026.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%496F4ED90026.declarations preserve=no
//## end module%496F4ED90026.declarations

//## begin module%496F4ED90026.additionalDeclarations preserve=yes
//## end module%496F4ED90026.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::TraceBuffer%496F4F580083.preface preserve=yes
//## end IF::TraceBuffer%496F4F580083.preface

//## Class: TraceBuffer%496F4F580083
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport TraceBuffer : public reusable::Object  //## Inherits: <unnamed>%496F4F7901F3
{
  //## begin IF::TraceBuffer%496F4F580083.initialDeclarations preserve=yes
  //## end IF::TraceBuffer%496F4F580083.initialDeclarations

  public:
    //## Constructors (generated)
      TraceBuffer();

      TraceBuffer(const TraceBuffer &right);

    //## Destructor (generated)
      virtual ~TraceBuffer();

    // Data Members for Class Attributes

      //## Attribute: Buffer%496F50C10154
      //## begin IF::TraceBuffer::Buffer%496F50C10154.attr preserve=no  public: char* {U} 0
      char* m_pszBuffer;
      //## end IF::TraceBuffer::Buffer%496F50C10154.attr

      //## Attribute: BufferLength%496F50FA030F
      //## begin IF::TraceBuffer::BufferLength%496F50FA030F.attr preserve=no  public: unsigned int {U} 0
      unsigned int m_ulBufferLength;
      //## end IF::TraceBuffer::BufferLength%496F50FA030F.attr

      //## Attribute: BufferType%496F508D020E
      //## begin IF::TraceBuffer::BufferType%496F508D020E.attr preserve=no  public: short {U} 0
      short m_siBufferType;
      //## end IF::TraceBuffer::BufferType%496F508D020E.attr

    // Additional Public Declarations
      //## begin IF::TraceBuffer%496F4F580083.public preserve=yes
      //## end IF::TraceBuffer%496F4F580083.public

  protected:
    // Additional Protected Declarations
      //## begin IF::TraceBuffer%496F4F580083.protected preserve=yes
      //## end IF::TraceBuffer%496F4F580083.protected

  private:
    // Additional Private Declarations
      //## begin IF::TraceBuffer%496F4F580083.private preserve=yes
      //## end IF::TraceBuffer%496F4F580083.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::TraceBuffer%496F4F580083.implementation preserve=yes
      //## end IF::TraceBuffer%496F4F580083.implementation

};

//## begin IF::TraceBuffer%496F4F580083.postscript preserve=yes
//## end IF::TraceBuffer%496F4F580083.postscript

} // namespace IF

//## begin module%496F4ED90026.epilog preserve=yes
//## end module%496F4ED90026.epilog


#endif
