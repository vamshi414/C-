//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6359A67B033F.cm preserve=no
//## end module%6359A67B033F.cm

//## begin module%6359A67B033F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6359A67B033F.cp

//## Module: CXOSIF83%6359A67B033F; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF83.hpp

#ifndef CXOSIF83_h
#define CXOSIF83_h 1

//## begin module%6359A67B033F.additionalIncludes preserve=no
//## end module%6359A67B033F.additionalIncludes

//## begin module%6359A67B033F.includes preserve=yes
struct HSSAPICALL
{  //HSSAPI call structure from thales SRM user reference
   char   sSRMWorkArea[128];
   short  siSRMWorkAreaLen;      //0x0080
   char   sSRMId[4];             //"SRM " or is it "HSSn"?
   char   sSRMFunction[8];       //"CALL    "
   char   sSRMFeedBack[4];       //"0000"
   char   sAPIReturnCode[4];     //"0000"
   struct InputMsg
   {
      char SRMHeader[32];      //Binary
      char UserHeader[32];     //Binary
      struct DecryptMsg        //character
      {
         char sCommandCode[2]; //"M2" DECRYPT BLOCK
         char sModeFlag[2];    //"03" CFB64 (requires IV)
         char cInputFormFlag;  //"1"  text
         char cOutputFormFlag; //"2"  Hex Encoded Binary
         char sKeyType[3];     //"00A" ZEK encr under LMK pair 30-31
         char cKeyPrefix;      //"U" 
         char sEncryptKey[32]; //32 char Hex encoded 16 byte key
         char sIV[16];         //16 chars yyyymmddhhmmss00 Initial Vector
         char sEncPANLength[4];//"0030" Char Hex length of 48
         char sEncPAN[48];     //48 char Hex encoded 24 byte value
      } DecryptMsg;
   } InputMsg;
   struct OutputMsg
   {
      char sRespMsgHeader[32];  //Binary
      char sRespUserHeader[32]; //Binary
      char sRespMsgCode[2];     //M3
      char sRespMsgErrCode[2];
      char sOutputIV[16];
      char sDecryptedLength[4];
      char sDecryptedValue[24];
      char sFiller[256];
   } OutputMsg;
};
struct Header
{
   short siMsgLength;
   char sRestofHeader[30];
};
#ifdef MVS
extern "OS"
{
   DllExport void HSSAPI(const char* pSRMWorkArea,
                         short int*  pSRMWorkAreaLen,
                         const char* pSRMId,
                         const char* pSRMFunction,
                         const char* pSRMFeedBack,
                         const char* pInputMsg,
                         const char* pOutputMsg);
}
#else
//allow compile and debugging on open systems
void HSSAPI(const char* pSRMWorkArea,
   short int* pSRMWorkAreaLen,
   const char* pSRMId,
   const char* pSRMFunction,
   const char* pSRMFeedBack,
   const char* pInputMsg,
   const char* pOutputMsg)
{
   struct HSSAPICALL* p = (struct HSSAPICALL*)pSRMWorkArea;
   memcpy((char*)pSRMFeedBack, "0000", 4);
   memcpy((char*)p->sAPIReturnCode, "0000", 4);
   memcpy((char*)p->OutputMsg.sRespMsgCode,"M3",2); //debugging
   memcpy((char*)p->OutputMsg.sRespMsgErrCode,"00", 2); //debugging
   memcpy((char*)p->OutputMsg.sDecryptedLength, "0018", 4);//length = 24;
   memcpy((char*)p->OutputMsg.sOutputIV, "AF02DE9833FC99C9", 16);
   memcpy((char*)p->OutputMsg.sDecryptedValue,"4567890123456789        ", 24);
};
#endif

//## end module%6359A67B033F.includes

#ifndef CXOSRU01_h
#include "CXODRU01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Extract;

} // namespace IF

//## begin module%6359A67B033F.declarations preserve=no
//## end module%6359A67B033F.declarations

//## begin module%6359A67B033F.additionalDeclarations preserve=yes
//## end module%6359A67B033F.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::HSM%6359A5DF0371.preface preserve=yes
//## end IF::HSM%6359A5DF0371.preface

//## Class: HSM%6359A5DF0371
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6359AACC0184;Extract { -> F}
//## Uses: <unnamed>%635A8A390239;Trace { -> F}

class DllExport HSM : public reusable::Subject  //## Inherits: <unnamed>%6359A62B0363
{
  //## begin IF::HSM%6359A5DF0371.initialDeclarations preserve=yes
  //## end IF::HSM%6359A5DF0371.initialDeclarations

  public:
    //## Constructors (generated)
      HSM();

    //## Destructor (generated)
      virtual ~HSM();


    //## Other Operations (specified)
      //## Operation: decrypt%6359ABE703D4
      reusable::string decrypt (const string& strKeyIndex, const string& strIV, string& strEncryptedPAN);

      //## Operation: dummyCall%635AAF8701D6
      void dummyCall ();

      //## Operation: instance%6359A86E006F
      static HSM* instance ();

    // Additional Public Declarations
      //## begin IF::HSM%6359A5DF0371.public preserve=yes
      bool isCritical(string strErrorCode);
      string getErrorText(string strErrorCode);
      //## end IF::HSM%6359A5DF0371.public

  protected:
    // Additional Protected Declarations
      //## begin IF::HSM%6359A5DF0371.protected preserve=yes
      //## end IF::HSM%6359A5DF0371.protected

  private:
    // Additional Private Declarations
      //## begin IF::HSM%6359A5DF0371.private preserve=yes
      map<string, string, less<string> > m_hHSMErrors;
      //## end IF::HSM%6359A5DF0371.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%6359A8570259
      //## begin IF::HSM::Instance%6359A8570259.attr preserve=no  private: static HSM* {V} 0
      static HSM* m_pInstance;
      //## end IF::HSM::Instance%6359A8570259.attr

      //## Attribute: Debug%635AA9840384
      //## begin IF::HSM::Debug%635AA9840384.attr preserve=no  private: bool {U} false
      bool m_bDebug;
      //## end IF::HSM::Debug%635AA9840384.attr

      //## Attribute: Keys%6359AA850118
      //## begin IF::HSM::Keys%6359AA850118.attr preserve=no  private: string[99] {U} 
      string m_strKeys[99];
      //## end IF::HSM::Keys%6359AA850118.attr

      //## Attribute: SRMId%635AA486038F
      //## begin IF::HSM::SRMId%635AA486038F.attr preserve=no  private: string {U} 
      string m_strSRMId;
      //## end IF::HSM::SRMId%635AA486038F.attr

    // Additional Implementation Declarations
      //## begin IF::HSM%6359A5DF0371.implementation preserve=yes
      //## end IF::HSM%6359A5DF0371.implementation

};

//## begin IF::HSM%6359A5DF0371.postscript preserve=yes
//## end IF::HSM%6359A5DF0371.postscript

} // namespace IF

//## begin module%6359A67B033F.epilog preserve=yes
//## end module%6359A67B033F.epilog


#endif
