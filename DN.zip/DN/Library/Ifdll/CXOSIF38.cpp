//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3742C40F019E.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3742C40F019E.cm

//## begin module%3742C40F019E.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3742C40F019E.cp

//## Module: CXOSIF38%3742C40F019E; Package body
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXOSIF38.cpp

//## begin module%3742C40F019E.additionalIncludes preserve=no
//## end module%3742C40F019E.additionalIncludes

//## begin module%3742C40F019E.includes preserve=yes
// $Date:   Jun 30 2006 11:35:52  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%3742C40F019E.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF36_h
#include "CXODIF36.hpp"
#endif
#ifndef CXOSIF38_h
#include "CXODIF38.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif


//## begin module%3742C40F019E.declarations preserve=no
//## end module%3742C40F019E.declarations

//## begin module%3742C40F019E.additionalDeclarations preserve=yes
//## end module%3742C40F019E.additionalDeclarations


//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::EMailMessageVisitor 




EMailMessageVisitor::EMailMessageVisitor()
  //## begin EMailMessageVisitor::EMailMessageVisitor%3742C0B003CD_const.hasinit preserve=no
  //## end EMailMessageVisitor::EMailMessageVisitor%3742C0B003CD_const.hasinit
  //## begin EMailMessageVisitor::EMailMessageVisitor%3742C0B003CD_const.initialization preserve=yes
  //## end EMailMessageVisitor::EMailMessageVisitor%3742C0B003CD_const.initialization
{
  //## begin IF::EMailMessageVisitor::EMailMessageVisitor%3742C0B003CD_const.body preserve=yes
  //## end IF::EMailMessageVisitor::EMailMessageVisitor%3742C0B003CD_const.body
}


EMailMessageVisitor::~EMailMessageVisitor()
{
  //## begin IF::EMailMessageVisitor::~EMailMessageVisitor%3742C0B003CD_dest.body preserve=yes
  //## end IF::EMailMessageVisitor::~EMailMessageVisitor%3742C0B003CD_dest.body
}



//## Other Operations (implementation)
void EMailMessageVisitor::addFormat (const char* pszBuffer, int lLength)
{
  //## begin IF::EMailMessageVisitor::addFormat%3A194D0A00AE.body preserve=yes
  //## end IF::EMailMessageVisitor::addFormat%3A194D0A00AE.body
}

void EMailMessageVisitor::visitEMailMessage (EMailMessage* pEMailMessage)
{
  //## begin IF::EMailMessageVisitor::visitEMailMessage%3742C137025F.body preserve=yes
  //## end IF::EMailMessageVisitor::visitEMailMessage%3742C137025F.body
}

void EMailMessageVisitor::visitText (string* pText)
{
  //## begin IF::EMailMessageVisitor::visitText%3742C185030B.body preserve=yes
   Trace::put("EMailMessageVisitor::visitText");
   if ((m_pSQL == 0) || memcmp(m_pSQL,"SQL(",4))
      return;
   Trace::put(m_pSQL);

   char* s;
   char *pTableName = m_pSQL + 4;
   s = strchr(pTableName,',');
   if (!s)
      return;
   *s = '\0';

   char *pDescriptionColumn = s + 1;
   s = strchr(pDescriptionColumn,',');
   if (!s)
      return;
   *s = '\0';

   char *pValueColumn = s + 1;
   s = strchr(pValueColumn,',');
   if (!s)
   {
      s = strchr(pValueColumn,')');
      if (!s)
         return;
   }
   *s = '\0';

   m_hQuery.reset();
   m_hQuery.setQualifier("QUALIFY",pTableName);
   m_hQuery.bind(pTableName,pDescriptionColumn,Column::STRING,&m_strValue);
   m_hQuery.setBasicPredicate(pTableName,pValueColumn,"=",m_strValue.c_str());
   s++;
   char* t;
   for (;;)
   {
      t = strchr(s,'=');
      if (!t)
         break;
      *t = '\0';
      pValueColumn = s;
      s = t+1;
      t = strchr(s,',');
      if (!t)
      {
         t = strchr(s,')');
         if (!t)
            break;
      }
      *t = '\0';
      m_hQuery.setBasicPredicate(pTableName,pValueColumn,"=",s);
      s = t+1;
   }
   string strCUST_ID;
   if (Transaction::instance()->getQualifier() == "CUSTQUAL")
      Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   else
      strCUST_ID = Transaction::instance()->getCustomer().c_str();
   string strTemp = "('" + strCUST_ID + "','****')";
   m_hQuery.setBasicPredicate(pTableName,"CUST_ID","IN",strTemp.c_str());
  //## end IF::EMailMessageVisitor::visitText%3742C185030B.body
}

// Additional Declarations
  //## begin IF::EMailMessageVisitor%3742C0B003CD.declarations preserve=yes
  //## end IF::EMailMessageVisitor%3742C0B003CD.declarations

} // namespace IF

//## begin module%3742C40F019E.epilog preserve=yes
//## end module%3742C40F019E.epilog
