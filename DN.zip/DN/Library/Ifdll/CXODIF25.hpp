//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%37FA122C0166.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%37FA122C0166.cm

//## begin module%37FA122C0166.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%37FA122C0166.cp

//## Module: CXOSIF25%37FA122C0166; Package specification
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXODIF25.hpp

#ifndef CXOSIF25_h
#define CXOSIF25_h 1

//## begin module%37FA122C0166.additionalIncludes preserve=no
//## end module%37FA122C0166.additionalIncludes

//## begin module%37FA122C0166.includes preserve=yes
// $Date:   Apr 08 2004 07:21:20  $ $Author:   D02405  $ $Revision:   1.2  $
//## end module%37FA122C0166.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%37FA122C0166.declarations preserve=no
//## end module%37FA122C0166.declarations

//## begin module%37FA122C0166.additionalDeclarations preserve=yes
//## end module%37FA122C0166.additionalDeclarations


//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Sleep%37FA11530146.preface preserve=yes
//## end IF::Sleep%37FA11530146.preface

//## Class: Sleep%37FA11530146
//## Category: Connex Foundation::IF_CAT%3451F55F009E
//## Subsystem: IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class DllExport Sleep : public reusable::Object  //## Inherits: <unnamed>%37FA11830195
{
  //## begin IF::Sleep%37FA11530146.initialDeclarations preserve=yes
  //## end IF::Sleep%37FA11530146.initialDeclarations

  public:
    //## Constructors (generated)
      Sleep();

    //## Destructor (generated)
      virtual ~Sleep();


    //## Other Operations (specified)
      //## Operation: goTo%38514E2E022F
      static void goTo (const char* psInterval);

    // Additional Public Declarations
      //## begin IF::Sleep%37FA11530146.public preserve=yes
      //## end IF::Sleep%37FA11530146.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Sleep%37FA11530146.protected preserve=yes
      //## end IF::Sleep%37FA11530146.protected

  private:
    // Additional Private Declarations
      //## begin IF::Sleep%37FA11530146.private preserve=yes
      //## end IF::Sleep%37FA11530146.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::Sleep%37FA11530146.implementation preserve=yes
      //## end IF::Sleep%37FA11530146.implementation

};

//## begin IF::Sleep%37FA11530146.postscript preserve=yes
//## end IF::Sleep%37FA11530146.postscript

} // namespace IF

//## begin module%37FA122C0166.epilog preserve=yes
using namespace IF;
//## end module%37FA122C0166.epilog


#endif
