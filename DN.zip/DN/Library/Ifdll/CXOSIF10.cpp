//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36266D3C0031.cm preserve=no
//## end module%36266D3C0031.cm

//## begin module%36266D3C0031.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36266D3C0031.cp

//## Module: CXOSIF10%36266D3C0031; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF10.cpp

//## begin module%36266D3C0031.additionalIncludes preserve=no
//## end module%36266D3C0031.additionalIncludes

//## begin module%36266D3C0031.includes preserve=yes
//## end module%36266D3C0031.includes

#ifndef CXOSIF51_h
#include "CXODIF51.hpp"
#endif
#ifndef CXOSIF52_h
#include "CXODIF52.hpp"
#endif
#ifndef CXOSIF53_h
#include "CXODIF53.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF56_h
#include "CXODIF56.hpp"
#endif
#ifndef CXOSIF50_h
#include "CXODIF50.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif


//## begin module%36266D3C0031.declarations preserve=no
//## end module%36266D3C0031.declarations

//## begin module%36266D3C0031.additionalDeclarations preserve=yes
//## end module%36266D3C0031.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::FlatFile 

FlatFile::FlatFile()
  //## begin FlatFile::FlatFile%345C6F890047_const.hasinit preserve=no
      : m_this(0)
  //## end FlatFile::FlatFile%345C6F890047_const.hasinit
  //## begin FlatFile::FlatFile%345C6F890047_const.initialization preserve=yes
  //## end FlatFile::FlatFile%345C6F890047_const.initialization
{
  //## begin IF::FlatFile::FlatFile%345C6F890047_const.body preserve=yes
   memcpy(m_sID,"IF10",4);
   m_this = OperatingSystemFileFactory::instance()->create();
  //## end IF::FlatFile::FlatFile%345C6F890047_const.body
}

FlatFile::FlatFile (const char* pszName)
  //## begin IF::FlatFile::FlatFile%3F9C973E026A.hasinit preserve=no
      : m_this(0)
  //## end IF::FlatFile::FlatFile%3F9C973E026A.hasinit
  //## begin IF::FlatFile::FlatFile%3F9C973E026A.initialization preserve=yes
  //## end IF::FlatFile::FlatFile%3F9C973E026A.initialization
{
  //## begin IF::FlatFile::FlatFile%3F9C973E026A.body preserve=yes
   memcpy(m_sID,"IF10",4);
   m_this = OperatingSystemFileFactory::instance()->create(pszName);
  //## end IF::FlatFile::FlatFile%3F9C973E026A.body
}

FlatFile::FlatFile (const char* pszName, const char* pszMember)
  //## begin IF::FlatFile::FlatFile%374AA58800A6.hasinit preserve=no
      : m_this(0)
  //## end IF::FlatFile::FlatFile%374AA58800A6.hasinit
  //## begin IF::FlatFile::FlatFile%374AA58800A6.initialization preserve=yes
  //## end IF::FlatFile::FlatFile%374AA58800A6.initialization
{
  //## begin IF::FlatFile::FlatFile%374AA58800A6.body preserve=yes
   memcpy(m_sID,"IF10",4);
   string strMember;
   if (Extract::instance()->getSpec(pszMember,strMember) && strMember[0] == '=')
   {
      string strTemp(strMember,1);
      m_this = OperatingSystemFileFactory::instance()->create(pszName,strTemp.c_str());
   }
   else
      m_this = OperatingSystemFileFactory::instance()->create(pszName,pszMember);
  //## end IF::FlatFile::FlatFile%374AA58800A6.body
}


FlatFile::~FlatFile()
{
  //## begin IF::FlatFile::~FlatFile%345C6F890047_dest.body preserve=yes
   delete m_this;
  //## end IF::FlatFile::~FlatFile%345C6F890047_dest.body
}



//## Other Operations (implementation)
bool FlatFile::close ()
{
  //## begin IF::FlatFile::close%374AA5AD0316.body preserve=yes
   return m_this->close();
  //## end IF::FlatFile::close%374AA5AD0316.body
}

bool FlatFile::copy (const char* pszTarget, const char* pszOutputFileName)
{
  //## begin IF::FlatFile::copy%4C519B230009.body preserve=yes
   return m_this->copy(pszTarget,pszOutputFileName);
  //## end IF::FlatFile::copy%4C519B230009.body
}

const string& FlatFile::datasetName ()
{
  //## begin IF::FlatFile::datasetName%374AAE040121.body preserve=yes
   return m_this->datasetName();
  //## end IF::FlatFile::datasetName%374AAE040121.body
}

bool FlatFile::executeFtp ()
{
  //## begin IF::FlatFile::executeFtp%4C5078290277.body preserve=yes
   string strFtpCommand;
   if (!IF::Extract::instance()->getSpec("FTPSEND",strFtpCommand))
      return false;
   size_t pos = strFtpCommand.find("%f");
   if (pos == string::npos)
      return false;
   strFtpCommand.replace(pos,2,m_this->getDatasetName());
   return (system(strFtpCommand.c_str()) == 0 ? true : false);
  //## end IF::FlatFile::executeFtp%4C5078290277.body
}

bool FlatFile::flush ()
{
  //## begin IF::FlatFile::flush%3F9DAF0101D6.body preserve=yes
   return m_this->flush();
  //## end IF::FlatFile::flush%3F9DAF0101D6.body
}

bool FlatFile::getBaseName (string& strBaseName, bool bIncludeExtension)
{
  //## begin IF::FlatFile::getBaseName%4C507CD50125.body preserve=yes
   return m_this->getBaseName(strBaseName, bIncludeExtension);
  //## end IF::FlatFile::getBaseName%4C507CD50125.body
}

const string& FlatFile::getDatasetName ()
{
  //## begin IF::FlatFile::getDatasetName%491EE37502AF.body preserve=yes
   return m_this->getDatasetName();
  //## end IF::FlatFile::getDatasetName%491EE37502AF.body
}

const string& FlatFile::getDate ()
{
  //## begin IF::FlatFile::getDate%491EE3940109.body preserve=yes
   return m_this->getDate();
  //## end IF::FlatFile::getDate%491EE3940109.body
}

const string& FlatFile::getName ()
{
  //## begin IF::FlatFile::getName%491EE3A3032C.body preserve=yes
   return m_this->getName();
  //## end IF::FlatFile::getName%491EE3A3032C.body
}

int FlatFile::getRecordCount () const
{
  //## begin IF::FlatFile::getRecordCount%491EE3CD006D.body preserve=yes
   return m_this->getRecordCount();
  //## end IF::FlatFile::getRecordCount%491EE3CD006D.body
}

const string& FlatFile::getScheduledTime ()
{
  //## begin IF::FlatFile::getScheduledTime%491EE3F902AF.body preserve=yes
   return m_this->getScheduledTime();
  //## end IF::FlatFile::getScheduledTime%491EE3F902AF.body
}

int FlatFile::getSequence ()
{
  //## begin IF::FlatFile::getSequence%491EE418031C.body preserve=yes
   return m_this->getSequence();
  //## end IF::FlatFile::getSequence%491EE418031C.body
}

const string& FlatFile::getType ()
{
  //## begin IF::FlatFile::getType%5AC3DCBF02DB.body preserve=yes
   return m_this->getType();
  //## end IF::FlatFile::getType%5AC3DCBF02DB.body
}

bool FlatFile::isFolderEmpty (const char* pszFolder)
{
  //## begin IF::FlatFile::isFolderEmpty%65B26C89001F.body preserve=yes
#ifdef _UNIX
   return UnixFile::isFolderEmpty(pszFolder);
#else
   return WindowsFile::isFolderEmpty(pszFolder);
#endif
  //## end IF::FlatFile::isFolderEmpty%65B26C89001F.body
}

bool FlatFile::isMail ()
{
  //## begin IF::FlatFile::isMail%52D940210376.body preserve=yes
   return m_this->isMail();
  //## end IF::FlatFile::isMail%52D940210376.body
}

bool FlatFile::isOpen ()
{
  //## begin IF::FlatFile::isOpen%45804F800138.body preserve=yes
   return m_this->isOpen();
  //## end IF::FlatFile::isOpen%45804F800138.body
}

bool FlatFile::move (const char* pszTarget, const char* pszOutputFileName)
{
  //## begin IF::FlatFile::move%3FA98D5202E3.body preserve=yes
   return m_this->move(pszTarget, pszOutputFileName);
  //## end IF::FlatFile::move%3FA98D5202E3.body
}

bool FlatFile::open (enum OpenType nOpenType)
{
  //## begin IF::FlatFile::open%374AA5B80308.body preserve=yes
   return m_this->open((File::OpenType)nOpenType);
  //## end IF::FlatFile::open%374AA5B80308.body
}

bool FlatFile::pick (const char* pszFolder, reusable::string& strDatasetName)
{
  //## begin IF::FlatFile::pick%65B26DE500D4.body preserve=yes
#ifdef _UNIX
   return UnixFile::pick(pszFolder,strDatasetName);
#else
   return WindowsFile::pick(pszFolder,strDatasetName);
#endif
  //## end IF::FlatFile::pick%65B26DE500D4.body
}

void FlatFile::purge (const char* pszFolder, const string& strPeriod)
{
  //## begin IF::FlatFile::purge%496DFC99037A.body preserve=yes
#ifdef _UNIX
   UnixFile::purge(pszFolder,strPeriod);
#endif
#ifdef _WIN32
   WindowsFile::purge(pszFolder,strPeriod);
#endif
#ifdef MVS
   ZosFile::purge(pszFolder,strPeriod);
#endif
  //## end IF::FlatFile::purge%496DFC99037A.body
}

void FlatFile::purgeFolder (const char* pszFolder, const string& strPeriod)
{
  //## begin IF::FlatFile::purgeFolder%4C6951100392.body preserve=yes
#ifdef _UNIX
   UnixFile::purgeFolder(pszFolder,strPeriod);
#endif
#ifdef _WIN32
   WindowsFile::purgeFolder(pszFolder,strPeriod);
#endif
  //## end IF::FlatFile::purgeFolder%4C6951100392.body
}

bool FlatFile::read (char* psBuffer, size_t iBufferLength, size_t* piRecordLength, bool* pbReadError)
{
  //## begin IF::FlatFile::read%374AA5E5028B.body preserve=yes
   bool b = m_this->read(psBuffer,iBufferLength,piRecordLength,pbReadError);
   if (b)
      Trace::putHex(psBuffer,*piRecordLength);
   return b;
  //## end IF::FlatFile::read%374AA5E5028B.body
}

bool FlatFile::read (string& strBuffer)
{
  //## begin IF::FlatFile::read%58ECDFF6038C.body preserve=yes
   if (!open())
      return false;
   char sBuffer[256];
   size_t iRecordLength = 0;
   while (read(sBuffer,256,&iRecordLength))
   {
      strBuffer.append(sBuffer,iRecordLength);
      strBuffer.append("\n");
   }
   return true;
  //## end IF::FlatFile::read%58ECDFF6038C.body
}

bool FlatFile::remove ()
{
  //## begin IF::FlatFile::remove%3EE9A9490203.body preserve=yes
   return m_this->remove();
  //## end IF::FlatFile::remove%3EE9A9490203.body
}

void FlatFile::seek (int SeekPos, enum SeekOffset nSeekOffset)
{
  //## begin IF::FlatFile::seek%516C095B015A.body preserve=yes
   m_this->seek(SeekPos,(File::SeekOffset)nSeekOffset);
  //## end IF::FlatFile::seek%516C095B015A.body
}

void FlatFile::setAccessOption (enum AccessOption nAccessOption)
{
  //## begin IF::FlatFile::setAccessOption%374AA61B0365.body preserve=yes
   m_this->setAccessOption((File::AccessOption)nAccessOption);
  //## end IF::FlatFile::setAccessOption%374AA61B0365.body
}

void FlatFile::setDatasetName (const char* pszDatasetName)
{
  //## begin IF::FlatFile::setDatasetName%374AAD6A018E.body preserve=yes
   m_this->setDatasetName(pszDatasetName);
  //## end IF::FlatFile::setDatasetName%374AAD6A018E.body
}

void FlatFile::setDate (const string& strDate)
{
  //## begin IF::FlatFile::setDate%491EE39C000F.body preserve=yes
   m_this->setDate(strDate);
  //## end IF::FlatFile::setDate%491EE39C000F.body
}

void FlatFile::setDX_FILE_ID (int iDX_FILE_ID)
{
  //## begin IF::FlatFile::setDX_FILE_ID%65B26C160182.body preserve=yes
   m_this->setDX_FILE_ID(iDX_FILE_ID);
  //## end IF::FlatFile::setDX_FILE_ID%65B26C160182.body
}

void FlatFile::setDX_REPORT_ID (int iDX_REPORT_ID)
{
  //## begin IF::FlatFile::setDX_REPORT_ID%55F9D7A601E5.body preserve=yes
   m_this->setDX_REPORT_ID(iDX_REPORT_ID);
  //## end IF::FlatFile::setDX_REPORT_ID%55F9D7A601E5.body
}

void FlatFile::setFolder (const string& strFolder)
{
  //## begin IF::FlatFile::setFolder%4D2F7B110231.body preserve=yes
   m_this->setFolder(strFolder);
  //## end IF::FlatFile::setFolder%4D2F7B110231.body
}

void FlatFile::setMember (const char* pszMember)
{
  //## begin IF::FlatFile::setMember%374AAD770024.body preserve=yes
   m_this->setMember(pszMember);
  //## end IF::FlatFile::setMember%374AAD770024.body
}

void FlatFile::setName (const char* pszName)
{
  //## begin IF::FlatFile::setName%374AAD8001F4.body preserve=yes
   m_this->setName(pszName);
  //## end IF::FlatFile::setName%374AAD8001F4.body
}

void FlatFile::setOwner (const string& strOwner)
{
  //## begin IF::FlatFile::setOwner%491EE3AA036B.body preserve=yes
   m_this->setOwner(strOwner);
  //## end IF::FlatFile::setOwner%491EE3AA036B.body
}

void FlatFile::setPath (const string& strPath)
{
  //## begin IF::FlatFile::setPath%4665872301B5.body preserve=yes
   m_this->setPath(strPath);
  //## end IF::FlatFile::setPath%4665872301B5.body
}

void FlatFile::setRecordFormat (const string& strRecordFormat)
{
  //## begin IF::FlatFile::setRecordFormat%491EE3E000CB.body preserve=yes
   m_this->setRecordFormat(strRecordFormat);
  //## end IF::FlatFile::setRecordFormat%491EE3E000CB.body
}

void FlatFile::setScheduledTime (const string& strScheduledTime)
{
  //## begin IF::FlatFile::setScheduledTime%491EE4030399.body preserve=yes
   m_this->setScheduledTime(strScheduledTime);
  //## end IF::FlatFile::setScheduledTime%491EE4030399.body
}

void FlatFile::setSequence (int iSequence)
{
  //## begin IF::FlatFile::setSequence%491EE420036B.body preserve=yes
   m_this->setSequence(iSequence);
  //## end IF::FlatFile::setSequence%491EE420036B.body
}

int FlatFile::tellg ()
{
  //## begin IF::FlatFile::tellg%516C0A9B006D.body preserve=yes
   return m_this->tellg();
  //## end IF::FlatFile::tellg%516C0A9B006D.body
}

bool FlatFile::unzip ()
{
  //## begin IF::FlatFile::unzip%4C5073900383.body preserve=yes
   return m_this->unzip();
  //## end IF::FlatFile::unzip%4C5073900383.body
}

bool FlatFile::write (char* psBuffer, int iRecordLength)
{
  //## begin IF::FlatFile::write%374AA64401D3.body preserve=yes
   return m_this->write(psBuffer,iRecordLength);
  //## end IF::FlatFile::write%374AA64401D3.body
}

bool FlatFile::zip (const string& strArchiveName)
{
  //## begin IF::FlatFile::zip%4C50793C0086.body preserve=yes
   return m_this->zip(strArchiveName);
  //## end IF::FlatFile::zip%4C50793C0086.body
}

// Additional Declarations
  //## begin IF::FlatFile%345C6F890047.declarations preserve=yes
#ifdef _WIN64
long long FlatFile::getFile ()
#else
long FlatFile::getFile ()
#endif
{
   return m_this->getFile();
}
bool FlatFile::getEncryption()
{
   return m_this->getEncryption();
}
bool FlatFile::decrypt(char* psBuffer, int* plRecordLength)
{
   return m_this->decrypt(psBuffer, plRecordLength);
}
  //## end IF::FlatFile%345C6F890047.declarations
} // namespace IF

//## begin module%36266D3C0031.epilog preserve=yes
//## end module%36266D3C0031.epilog
