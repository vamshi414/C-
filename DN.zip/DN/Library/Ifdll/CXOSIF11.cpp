//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%359CF1C50202.cm preserve=no
//	$Date:   May 19 2020 09:33:12  $ $Author:   e5579974  $ $Revision:   1.33  $
//## end module%359CF1C50202.cm

//## begin module%359CF1C50202.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%359CF1C50202.cp

//## Module: CXOSIF11%359CF1C50202; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF11.cpp

//## begin module%359CF1C50202.additionalIncludes preserve=no
//## end module%359CF1C50202.additionalIncludes

//## begin module%359CF1C50202.includes preserve=yes
#include <stdio.h>
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%359CF1C50202.includes

#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif


//## begin module%359CF1C50202.declarations preserve=no
//## end module%359CF1C50202.declarations

//## begin module%359CF1C50202.additionalDeclarations preserve=yes
#ifdef MVS
extern "OS"
#else
extern "C"
#endif
{
int CXQGET(char* psBuffer,char* psQueueName,int* plBufferLength,int* plMessageLength,int* plRC);
int CXQPUT(const char* psBuffer,const char* psQueueName,int* plMessageLength,int* plRC);
int CXSONL(int* plLength,int* plRC);
}
Message* Message::m_pInstance[2] = {0,0};
//## end module%359CF1C50202.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Message


//## begin IF::Message::<m_pFirst>%538776E70360.role preserve=no  public: static IF::Message { -> RFHgN}
Message *Message::m_pFirst = 0;
//## end IF::Message::<m_pFirst>%538776E70360.role


//## begin IF::Message::<m_pLast>%538776F60211.role preserve=no  public: static IF::Message { -> RFHgN}
Message *Message::m_pLast = 0;
//## end IF::Message::<m_pLast>%538776F60211.role


//## begin IF::Message::<m_pFree>%538776FC0368.role preserve=no  public: static IF::Message { -> RFHgN}
Message *Message::m_pFree = 0;
//## end IF::Message::<m_pFree>%538776FC0368.role

Message::Message()
  //## begin Message::Message%345C720A0194_const.hasinit preserve=no
      : m_lMessageLength(0),
        m_pReceiverCBAddress(0),
        m_pNext(0)
  //## end Message::Message%345C720A0194_const.hasinit
  //## begin Message::Message%345C720A0194_const.initialization preserve=yes
  //## end Message::Message%345C720A0194_const.initialization
{
  //## begin IF::Message::Message%345C720A0194_const.body preserve=yes
   memcpy(m_sID,"IF11",4);
   m_lBufferLength = MAX_BUFFER_SIZE;
   m_pMemory = new Memory(m_lBufferLength,true);
   m_nType = APPLICATION;
   m_strCorrelId = "                        ";
  //## end IF::Message::Message%345C720A0194_const.body
}

Message::Message(const Message &right)
  //## begin Message::Message%345C720A0194_copy.hasinit preserve=no
  //## end Message::Message%345C720A0194_copy.hasinit
  //## begin Message::Message%345C720A0194_copy.initialization preserve=yes
   :Subject(right)
  //## end Message::Message%345C720A0194_copy.initialization
{
  //## begin IF::Message::Message%345C720A0194_copy.body preserve=yes
   memcpy(m_sID,"IF11",4);
   if (right.m_lMessageLength > 0)
   {
      m_lBufferLength = right.m_lMessageLength + 4095;
      m_lBufferLength = m_lBufferLength / 4096;
      m_lBufferLength = m_lBufferLength * 4096;
      if (m_lBufferLength > right.m_lBufferLength)
         m_lBufferLength = right.m_lBufferLength;
      m_pMemory = new Memory(m_lBufferLength,true);
      if ((char*)*m_pMemory)
        memcpy((char*)*m_pMemory,(char*)*(right.m_pMemory),right.m_lMessageLength);
   }
   else
   {
      m_lBufferLength = right.m_lBufferLength;
      m_pMemory = new Memory(m_lBufferLength,true);
   }
   m_strContext = right.m_strContext;
   m_strCorrelId = right.m_strCorrelId;
   m_strDestination = right.m_strDestination;
   m_strMessageID = right.m_strMessageID;
   m_lMessageLength = right.m_lMessageLength;
   m_pNext = 0;
   m_pReceiverCBAddress = right.m_pReceiverCBAddress;
   m_strReceiverSTCKValue = right.m_strReceiverSTCKValue;
   m_strSource = right.m_strSource;
   m_nType = right.m_nType;
  //## end IF::Message::Message%345C720A0194_copy.body
}

Message::Message (int lBufferLength)
  //## begin IF::Message::Message%34A3FE9F0232.hasinit preserve=no
      : m_lMessageLength(0),
        m_pReceiverCBAddress(0),
        m_pNext(0)
  //## end IF::Message::Message%34A3FE9F0232.hasinit
  //## begin IF::Message::Message%34A3FE9F0232.initialization preserve=yes
  //## end IF::Message::Message%34A3FE9F0232.initialization
{
  //## begin IF::Message::Message%34A3FE9F0232.body preserve=yes
   memcpy(m_sID,"IF11",4);
   m_lBufferLength = lBufferLength;
   m_pMemory = new Memory(m_lBufferLength,true);
   m_nType = APPLICATION;
   m_strCorrelId = "                        ";
  //## end IF::Message::Message%34A3FE9F0232.body
}


Message::~Message()
{
  //## begin IF::Message::~Message%345C720A0194_dest.body preserve=yes
   delete m_pMemory;
  //## end IF::Message::~Message%345C720A0194_dest.body
}


Message & Message::operator=(const Message &right)
{
  //## begin IF::Message::operator=%345C720A0194_assign.body preserve=yes
   if (this == &right)
      return *this;
   if (m_lBufferLength < right.m_lMessageLength)
   {
      delete m_pMemory;
      m_lBufferLength = right.m_lMessageLength + 4095;
      m_lBufferLength = m_lBufferLength / 4096;
      m_lBufferLength = m_lBufferLength * 4096;
      m_pMemory = new Memory(m_lBufferLength,true);
   }
   if ((char*)*m_pMemory)
      memcpy((char*)*m_pMemory,(char*)*(right.m_pMemory),right.m_lMessageLength);
   m_strContext = right.m_strContext;
   m_strCorrelId = right.m_strCorrelId;
   m_strDestination = right.m_strDestination;
   m_strMessageID = right.m_strMessageID;
   m_lMessageLength = right.m_lMessageLength;
   m_pNext = 0;
   m_pReceiverCBAddress = right.m_pReceiverCBAddress;
   m_strReceiverSTCKValue = right.m_strReceiverSTCKValue;
   m_strSource = right.m_strSource;
   m_nType = right.m_nType;
   return *this;
  //## end IF::Message::operator=%345C720A0194_assign.body
}



//## Other Operations (implementation)
IF::Message& Message::operator += (const Message& right)
{
  //## begin IF::Message::operator+=%515D789D007B.body preserve=yes
   if (format() == 1)
   {
      hData* p = right.dataBuffer();
      short int i = ntohs(p->siLength);
      if (m_lBufferLength < (m_lMessageLength + i))
      {
         Memory* p = m_pMemory;
         m_lBufferLength = m_lMessageLength + i + 4095;
         m_lBufferLength = m_lBufferLength / 4096;
         m_lBufferLength = m_lBufferLength * 4096;
         m_pMemory = new Memory(m_lBufferLength,true);
         memcpy((char*)*m_pMemory,(char*)*p,m_lMessageLength);
         delete p;
      }
      memcpy((char*)*m_pMemory + m_lMessageLength,p->sText,i);
      p = dataBuffer();
      p->siLength = htons(ntohs(p->siLength) + i);
      m_lMessageLength += i;
   }
   else
   {
      hData2* p = (hData2*)right.dataBuffer();
      short int i = ntohl(p->iLength);
      if (m_lBufferLength < (m_lMessageLength + i))
      {
         Memory* p = m_pMemory;
         m_lBufferLength = m_lMessageLength + i + 4095;
         m_lBufferLength = m_lBufferLength / 4096;
         m_lBufferLength = m_lBufferLength * 4096;
         m_pMemory = new Memory(m_lBufferLength,true);
         memcpy((char*)*m_pMemory,(char*)*p,m_lMessageLength);
         delete p;
      }
      memcpy((char*)*m_pMemory + m_lMessageLength,p->sText,i);
      p = (hData2*)dataBuffer();
      p->iLength = htonl(ntohl(p->iLength) + i);
      m_lMessageLength += i;
   }
   return *this;
  //## end IF::Message::operator+=%515D789D007B.body
}

char* Message::data () const
{
  //## begin IF::Message::data%592DD890017B.body preserve=yes
   if (format() == 1)
   {
      hData* pData = dataBuffer();
      return pData->sText;
   }
   hData2* pData = (hData2*)dataBuffer();
   return pData->sText;
  //## end IF::Message::data%592DD890017B.body
}

hData* Message::dataBuffer () const
{
  //## begin IF::Message::dataBuffer%34A3FEBA028B.body preserve=yes
  hStandardHeader* pHeader = (hStandardHeader*)(char*)*m_pMemory;
  return (hData*)((char*)((char*)*m_pMemory + ntohs(pHeader->siTotalHeaderLength) + 2));
  //## end IF::Message::dataBuffer%34A3FEBA028B.body
}

unsigned int Message::dataLength () const
{
  //## begin IF::Message::dataLength%592DD8AB014E.body preserve=yes
   if (m_lMessageLength == 0)
      return 0;
   hStandardHeader* pHeader = (hStandardHeader*)(char*)*m_pMemory;
   if (format() == 1)
   {
      hData* pData = (hData*)((char*)((char*)*m_pMemory + ntohs(pHeader->siTotalHeaderLength) + 2));
      return ntohs(pData->siLength);
   }
   hData2* pData = (hData2*)((char*)((char*)*m_pMemory + ntohs(pHeader->siTotalHeaderLength) + 2));
   return ntohl(pData->iLength);
  //## end IF::Message::dataLength%592DD8AB014E.body
}

short Message::format () const
{
  //## begin IF::Message::format%592DD6720117.body preserve=yes
   hUniqueHeader* pUniqueHeader = (hUniqueHeader*)((char*)*m_pMemory + sizeof(hStandardHeader));
   return memcmp(pUniqueHeader->sFormat,"01",2) == 0 ? 1 : 2;
  //## end IF::Message::format%592DD6720117.body
}

void Message::identifyBuffer ()
{
  //## begin IF::Message::identifyBuffer%34A3FEC10028.body preserve=yes
   hGDMHeader* pGDMHeader = (hGDMHeader*)(char*)*m_pMemory;
   m_nType = APPLICATION;
   m_strMessageID = "";
   m_strContext = "";
   m_strReceiverSTCKValue = "";
   if (memcmp(pGDMHeader->sData1,"TRACE   ",8) != 0
      && memcmp(pGDMHeader->sData2,"WRITE",5) != 0)
   {
      Trace::put("Message from:",m_strSource);
#ifdef MVS
      Trace::put(buffer(),m_lMessageLength);
#else
      Trace::putHex(buffer(),m_lMessageLength);
#endif
   }
   if (m_lMessageLength >= 55
      && memcmp(pGDMHeader->sDescription,"CNX ",4) == 0)
   {
      if (!memcmp(pGDMHeader->sData1,"TIMER   ",8))
      {
         m_nType = TIMER;
         m_strContext.assign(pGDMHeader->sData2,24);
      }
      else
      if (!memcmp(pGDMHeader->sData1,"DEALLOC ",8))
         m_nType = DEALLOCATE;
      else
      if (!memcmp(pGDMHeader->sData1,"LOGGER  ",8))
      {
         m_nType = CONFIRM;
         m_strContext.assign(pGDMHeader->sData2,24);
      }
      else
      if (!memcmp(pGDMHeader->sData1,"RESET   ",8))
      {
         m_nType = RESET;
         m_strContext.assign(pGDMHeader->sData2,ntohs(pGDMHeader->siDataLength2));
      }
      else
      if (!memcmp(pGDMHeader->sData1,"TRACE   ",8))
      {
         m_nType = TRACE;
         m_strContext.assign(pGDMHeader->sData2,ntohs(pGDMHeader->siDataLength2));
      }
      else
      if (!memcmp(pGDMHeader->sData1,"REFRESH ",8))
         m_nType = REFRESH;
      else
      if (!memcmp(pGDMHeader->sData1,"QUIESCE ",8))
         m_nType = QUIESCE;
      else
      if (!memcmp(pGDMHeader->sData1,"SHUTDOWN",8))
         m_nType = SHUTDOWN;
      else
      if (!memcmp(pGDMHeader->sData1,"START   ",8))
      {
         m_nType = START;
         m_strContext.assign(pGDMHeader->sData2,ntohs(pGDMHeader->siDataLength2));
      }
      else
      if (!memcmp(pGDMHeader->sData1,"STARTWTR",8))
      {
         m_nType = STARTWTR;
         m_strContext.assign(pGDMHeader->sData2,ntohs(pGDMHeader->siDataLength2));
      }
      else
      if (!memcmp(pGDMHeader->sData1,"CONNECT ",8))
         m_nType = CONNECT;
   }
   else
   {
      hStandardHeader* pHeader = (hStandardHeader*)(char*)*m_pMemory;
      if ((ntohs(pHeader->siLength) != (sizeof(struct hStandardHeader) - 4))
         || (memcmp(pHeader->sFormat,"01",2) != 0))
         return;
      m_strMessageID.assign(pHeader->sMessageID,6);
      if (m_strMessageID == "H0499C")
      {
         m_nType = TIMER;
         m_strContext.assign((const char*)&pHeader->pReceiverCBAddress,12);
      }
      else
      if (m_strMessageID == "H6000R")
      {
         m_nType = CONFIRM;
         m_strContext.assign((const char*)&pHeader->pReceiverCBAddress,12);
      }
      else
      if (m_strMessageID == "H0114D")
         m_nType = NOTIFY;
      else
      if (m_strMessageID == "H0115C")
         m_nType = REFRESH;
      else
      if (m_strMessageID == "H0111C")
         m_nType = QUIESCE;
      else
      if (m_strMessageID == "H0110C")
         m_nType = SHUTDOWN;
      m_pReceiverCBAddress = pHeader->pReceiverCBAddress;
      m_strReceiverSTCKValue.assign(pHeader->sReceiverSTCKValue,8);
   }
  //## end IF::Message::identifyBuffer%34A3FEC10028.body
}

IF::Message* Message::instance (Message::Buffer nBuffer)
{
  //## begin IF::Message::instance%34A3FECC0164.body preserve=yes
   if (!m_pInstance[nBuffer])
      m_pInstance[nBuffer] = new Message();
   return m_pInstance[nBuffer];
  //## end IF::Message::instance%34A3FECC0164.body
}

int Message::receive ()
{
  //## begin IF::Message::receive%34A3FEF103D4.body preserve=yes
   char szQueueName[9] = {"        "};
   int lRC = 0;
   int len = 9;
#ifdef MVS
   CXQGET((char*)*m_pMemory,szQueueName,&m_lBufferLength,&m_lMessageLength,&lRC);
   if (lRC == 17)
   {
      reserve(m_lMessageLength);
      CXQGET((char*)*m_pMemory,szQueueName,&m_lBufferLength,&m_lMessageLength,&lRC);
   }
#endif
   if (lRC == 0)
   {
      m_strSource = szQueueName;
      identifyBuffer();
      notify();
   }
   return lRC;
  //## end IF::Message::receive%34A3FEF103D4.body
}

int Message::reply ()
{
  //## begin IF::Message::reply%34A3FF0A0087.body preserve=yes
   if (m_strSource == "POST")
   {
      char sConversationID[9] = {"        "};
      char sSymDestName[9] = {"        "};
      memcpy(sConversationID,m_strCorrelId.data(),8);
      int m = 0;
      sscanf(sConversationID,"%08x",&m);
      sprintf(sSymDestName,"%d",m);
      return Queue::send(sSymDestName,this,Queue::REPLY);
   }
   return Queue::send(m_strSource.c_str(),this,Queue::REPLY);
  //## end IF::Message::reply%34A3FF0A0087.body
}

void Message::reserve (int lBufferLength)
{
  //## begin IF::Message::reserve%4639F7DD002E.body preserve=yes
   if (lBufferLength > m_lBufferLength)
   {
      Memory* pMemory = m_pMemory;
      m_pMemory = new Memory(lBufferLength,true);
      memcpy((char*)*m_pMemory,(char*)*(pMemory),m_lBufferLength);
      m_lBufferLength = lBufferLength;
      delete pMemory;
   }
  //## end IF::Message::reserve%4639F7DD002E.body
}

void Message::reset (const char* pszSenderReceiver, const char* pszMessageID, bool bSwap)
{
  //## begin IF::Message::reset%34A3FF0E00E7.body preserve=yes
   hStandardHeader* pStandardHeader = (hStandardHeader*)(char*)*m_pMemory;
   pStandardHeader->siTotalHeaderLength = htons(sizeof(hStandardHeader) + sizeof(hUniqueHeader) - 2);
   pStandardHeader->siLength = htons(sizeof(hStandardHeader) - 4);
   memcpy(pStandardHeader->sFormat,"01",2);
   if (!pszSenderReceiver)
   {
      char x3[3];
      memcpy(x3,pStandardHeader->sSenderID,3);
      memcpy(pStandardHeader->sSenderID,pStandardHeader->sReceiverID,3);
      memcpy(pStandardHeader->sReceiverID,x3,3);
   }
   else
   if (strlen(pszSenderReceiver) == 3)
   {
      memcpy(pStandardHeader->sReceiverID,pStandardHeader->sSenderID,3);
      memcpy(pStandardHeader->sSenderID,pszSenderReceiver,3);
   }
   else
      memcpy(pStandardHeader->sSenderID,pszSenderReceiver,6);
   if (bSwap)
   {
      pStandardHeader->pReceiverCBAddress = pStandardHeader->pSenderCBAddress;
      memcpy(pStandardHeader->sReceiverSTCKValue,pStandardHeader->sSenderSTCKValue,8);
   }
   else
   {
      pStandardHeader->pReceiverCBAddress = 0;
      memset(pStandardHeader->sReceiverSTCKValue,0,8);
   }
   memset(&pStandardHeader->pSenderCBAddress,0,sizeof(pStandardHeader->pSenderCBAddress));
   memset(&pStandardHeader->sSenderSTCKValue,0,8);
   pStandardHeader->siResponsePriority = htons(200);
   memcpy(pStandardHeader->sMessageID,pszMessageID,6);
   memset(pStandardHeader->sFiller,' ',8);
   hUniqueHeader* pUniqueHeader = (hUniqueHeader*)((char*)*m_pMemory + sizeof(hStandardHeader));
   pUniqueHeader->siLength = htons(sizeof(hUniqueHeader) - 2);
   if (memcmp(pszMessageID,"C4611D",6) == 0
      || memcmp(pszMessageID,"H0305C",6) == 0
      || memcmp(pszMessageID,"H0306C",6) == 0
      || memcmp(pszMessageID,"H5050D",6) == 0
      || memcmp(pszMessageID,"H5050R",6) == 0
      || memcmp(pszMessageID,"L0001D",6) == 0)
      memcpy(pUniqueHeader->sFormat,"01",2);
   else
      memcpy(pUniqueHeader->sFormat,"02",2);
  //## end IF::Message::reset%34A3FF0E00E7.body
}

int Message::send (const char* pszQueueName)
{
  //## begin IF::Message::send%34A3FF1900A7.body preserve=yes
   hStandardHeader* pStandardHeader = (hStandardHeader*)(char*)*m_pMemory;
   if (format() == 1)
   {
      hData* pData = (hData*)((char*)*m_pMemory + ntohs(pStandardHeader->siTotalHeaderLength) + 2);
      m_lMessageLength = ntohs(pStandardHeader->siTotalHeaderLength) + ntohs(pData->siLength) + 4;
   }
   else
   {
      hData2* pData = (hData2*)((char*)*m_pMemory + ntohs(pStandardHeader->siTotalHeaderLength) + 2);
      m_lMessageLength = ntohs(pStandardHeader->siTotalHeaderLength) + ntohl(pData->iLength) + 6;
   }
   return Queue::send(pszQueueName,this,Queue::DATAGRAM) ? 0 : 8;
  //## end IF::Message::send%34A3FF1900A7.body
}

int Message::send (const char* pszQueueName, int lMessageLength)
{
  //## begin IF::Message::send%34A3FF1D0157.body preserve=yes
   m_lMessageLength = lMessageLength;
   return Queue::send(pszQueueName,this,Queue::DATAGRAM) ? 0 : 8;
  //## end IF::Message::send%34A3FF1D0157.body
}

void Message::setCorrelId (const char* psCorrelId)
{
  //## begin IF::Message::setCorrelId%37C2EBD6022A.body preserve=yes
   memcpy((char*)m_strCorrelId,psCorrelId,24);
  //## end IF::Message::setCorrelId%37C2EBD6022A.body
}

void Message::setDataLength (unsigned int iDataLength)
{
  //## begin IF::Message::setDataLength%34A3FF2101B7.body preserve=yes
#define DATA_EXTRA 4
#define DATA2_EXTRA 6
   if (iDataLength < INT_MAX - max(DATA_EXTRA, DATA2_EXTRA) )
   {
      hStandardHeader* pStandardHeader = (hStandardHeader*)(char*)*m_pMemory;
      if (format() == 1)
      {
         hData* pData = (hData*)((char*)*m_pMemory + ntohs(pStandardHeader->siTotalHeaderLength) + 2);
         pData->siLength = htons((short)iDataLength);
         m_lMessageLength = ntohs(pStandardHeader->siTotalHeaderLength);
         if (m_lMessageLength < INT_MAX - (int)(iDataLength + DATA_EXTRA))
            m_lMessageLength += (int)(iDataLength + DATA_EXTRA);
      }
      else
      {
         hData2* pData = (hData2*)((char*)*m_pMemory + ntohs(pStandardHeader->siTotalHeaderLength) + 2);
         pData->iLength = htonl(iDataLength);
         m_lMessageLength = ntohs(pStandardHeader->siTotalHeaderLength);
         if (m_lMessageLength < INT_MAX - (int)(iDataLength + DATA2_EXTRA))
            m_lMessageLength += (int)(iDataLength + DATA2_EXTRA);
      }
   }
  //## end IF::Message::setDataLength%34A3FF2101B7.body
}

void Message::setReceiverCBAddress (void* pReceiverCBAddress)
{
  //## begin IF::Message::setReceiverCBAddress%37E246550076.body preserve=yes
   hStandardHeader* pStandardHeader = (hStandardHeader*)(char*)*m_pMemory;
   pStandardHeader->pReceiverCBAddress = pReceiverCBAddress;
  //## end IF::Message::setReceiverCBAddress%37E246550076.body
}

void Message::setSenderCBAddress (void* pSenderCBAddress)
{
  //## begin IF::Message::setSenderCBAddress%34A3FF3203CE.body preserve=yes
   hStandardHeader* pStandardHeader = (hStandardHeader*)(char*)*m_pMemory;
   pStandardHeader->pSenderCBAddress = pSenderCBAddress;
  //## end IF::Message::setSenderCBAddress%34A3FF3203CE.body
}

void Message::setReceiverSTCKValue (const char* psReceiverSTCKValue)
{
  //## begin IF::Message::setReceiverSTCKValue%37E246240224.body preserve=yes
   hStandardHeader* pStandardHeader = (hStandardHeader*)(char*)*m_pMemory;
   memcpy(pStandardHeader->sReceiverSTCKValue,psReceiverSTCKValue,8);
  //## end IF::Message::setReceiverSTCKValue%37E246240224.body
}

void Message::setSenderSTCKValue (const char* psSenderSTCKValue)
{
  //## begin IF::Message::setSenderSTCKValue%34A3FF3B02D6.body preserve=yes
   hStandardHeader* pStandardHeader = (hStandardHeader*)(char*)*m_pMemory;
   memcpy(pStandardHeader->sSenderSTCKValue,psSenderSTCKValue,8);
  //## end IF::Message::setSenderSTCKValue%34A3FF3B02D6.body
}

//## Get and Set Operations for Associations (implementation)

Message * Message::getFirst ()
{
  //## begin IF::Message::getFirst%538776E70360.get preserve=no
  return m_pFirst;
  //## end IF::Message::getFirst%538776E70360.get
}

void Message::setFirst (Message * value)
{
  //## begin IF::Message::setFirst%538776E70360.set preserve=no
  m_pFirst = value;
  //## end IF::Message::setFirst%538776E70360.set
}

Message * Message::getLast ()
{
  //## begin IF::Message::getLast%538776F60211.get preserve=no
  return m_pLast;
  //## end IF::Message::getLast%538776F60211.get
}

void Message::setLast (Message * value)
{
  //## begin IF::Message::setLast%538776F60211.set preserve=no
  m_pLast = value;
  //## end IF::Message::setLast%538776F60211.set
}

Message * Message::getFree ()
{
  //## begin IF::Message::getFree%538776FC0368.get preserve=no
  return m_pFree;
  //## end IF::Message::getFree%538776FC0368.get
}

void Message::setFree (Message * value)
{
  //## begin IF::Message::setFree%538776FC0368.set preserve=no
  m_pFree = value;
  //## end IF::Message::setFree%538776FC0368.set
}

// Additional Declarations
  //## begin IF::Message%345C720A0194.declarations preserve=yes
  //## end IF::Message%345C720A0194.declarations

} // namespace IF

//## begin module%359CF1C50202.epilog preserve=yes
//## end module%359CF1C50202.epilog
