//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3703A740032C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3703A740032C.cm

//## begin module%3703A740032C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3703A740032C.cp

//## Module: CXOSIF35%3703A740032C; Package body
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXOSIF35.cpp

//## begin module%3703A740032C.additionalIncludes preserve=no
//## end module%3703A740032C.additionalIncludes

//## begin module%3703A740032C.includes preserve=yes
// $Date:   May 15 2020 09:01:28  $ $Author:   e1009510  $ $Revision:   1.5  $
#include <stdio.h>
#include "CXODRU24.hpp"
//## end module%3703A740032C.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSIF35_h
#include "CXODIF35.hpp"
#endif


//## begin module%3703A740032C.declarations preserve=no
//## end module%3703A740032C.declarations

//## begin module%3703A740032C.additionalDeclarations preserve=yes
//## end module%3703A740032C.additionalDeclarations


//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::ResourceUsage 

ResourceUsage::ResourceUsage()
  //## begin ResourceUsage::ResourceUsage%3703A47D004B_const.hasinit preserve=no
  //## end ResourceUsage::ResourceUsage%3703A47D004B_const.hasinit
  //## begin ResourceUsage::ResourceUsage%3703A47D004B_const.initialization preserve=yes
  //## end ResourceUsage::ResourceUsage%3703A47D004B_const.initialization
{
  //## begin IF::ResourceUsage::ResourceUsage%3703A47D004B_const.body preserve=yes
   memcpy(m_sID,"IF35",4);
  //## end IF::ResourceUsage::ResourceUsage%3703A47D004B_const.body
}


ResourceUsage::~ResourceUsage()
{
  //## begin IF::ResourceUsage::~ResourceUsage%3703A47D004B_dest.body preserve=yes
  //## end IF::ResourceUsage::~ResourceUsage%3703A47D004B_dest.body
}



//## Other Operations (implementation)
bool ResourceUsage::log (const char *psMessageID, const char *psReason, const char *psUserID, const char* psEntityData, const char* psSubType, int lCount, const char *psMessageData, int lMessageDataLength)
{
  //## begin IF::ResourceUsage::log%3703C4800347.body preserve=yes
   Message* pMessage = Message::instance(Message::OUTBOUND);
   memset(pMessage->data(),' ',500);
   IString strCurrentDateTime;
   DateTime hDateTime;
   hDateTime.setCurrent(strCurrentDateTime);
   memcpy(pMessage->data(),(char*)strCurrentDateTime.subString(1,16),16);
   memcpy(pMessage->data() + 16,"10",2);
   memcpy(pMessage->data() + 18,psUserID,8);
   memcpy(pMessage->data() + 26,psEntityData,100);
   char szCount[9] = {"        "};
   snprintf(szCount,sizeof(szCount),"%08d",lCount);
   memcpy(pMessage->data() + 126,szCount,8);
   memcpy(pMessage->data() + 134,psMessageData,lMessageDataLength);
   pMessage->setDataLength(lMessageDataLength + 134);
   Log::put((char*)pMessage->data() - 2,pMessage->messageLength(),psMessageID,psReason); // !!! ???
   return true;
  //## end IF::ResourceUsage::log%3703C4800347.body
}

// Additional Declarations
  //## begin IF::ResourceUsage%3703A47D004B.declarations preserve=yes
  //## end IF::ResourceUsage%3703A47D004B.declarations

} // namespace IF

//## begin module%3703A740032C.epilog preserve=yes
//## end module%3703A740032C.epilog
