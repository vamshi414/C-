//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36DC5A370199.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DC5A370199.cm

//## begin module%36DC5A370199.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DC5A370199.cp

//## Module: CXOSIF34%36DC5A370199; Package specification
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF34.hpp

#ifndef CXOSIF34_h
#define CXOSIF34_h 1

//## begin module%36DC5A370199.additionalIncludes preserve=no
//## end module%36DC5A370199.additionalIncludes

//## begin module%36DC5A370199.includes preserve=yes
// $Date:   Jun 30 2006 11:35:42  $ $Author:   D02405  $ $Revision:   1.4  $
#include <map>
//## end module%36DC5A370199.includes

#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Signal;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DiskQueue;

} // namespace IF

//## begin module%36DC5A370199.declarations preserve=no
//## end module%36DC5A370199.declarations

//## begin module%36DC5A370199.additionalDeclarations preserve=yes
//## end module%36DC5A370199.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::DiskQueueFactory%36DC59A600BE.preface preserve=yes
//## end IF::DiskQueueFactory%36DC59A600BE.preface

//## Class: DiskQueueFactory%36DC59A600BE
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%36DC59F900DB;DiskQueue { -> F}
//## Uses: <unnamed>%36DC59FB03D7;reusable::Signal { -> F}

class DllExport DiskQueueFactory : public QueueFactory  //## Inherits: <unnamed>%36DC59B4006E
{
  //## begin IF::DiskQueueFactory%36DC59A600BE.initialDeclarations preserve=yes
  //## end IF::DiskQueueFactory%36DC59A600BE.initialDeclarations

  public:
    //## Constructors (generated)
      DiskQueueFactory();

    //## Destructor (generated)
      virtual ~DiskQueueFactory();


    //## Other Operations (specified)
      //## Operation: create%36DC59DB02AF
      virtual Object* create (const char* pszClass, const char* pszValue = 0);

    // Additional Public Declarations
      //## begin IF::DiskQueueFactory%36DC59A600BE.public preserve=yes
      //## end IF::DiskQueueFactory%36DC59A600BE.public

  protected:
    // Additional Protected Declarations
      //## begin IF::DiskQueueFactory%36DC59A600BE.protected preserve=yes
      //## end IF::DiskQueueFactory%36DC59A600BE.protected

  private:
    // Additional Private Declarations
      //## begin IF::DiskQueueFactory%36DC59A600BE.private preserve=yes
      //## end IF::DiskQueueFactory%36DC59A600BE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Classes%36DC59BC0200
      //## begin IF::DiskQueueFactory::Classes%36DC59BC0200.attr preserve=no  private: map<string,int,less<string> > {V} 
      map<string,int,less<string> > m_hClasses;
      //## end IF::DiskQueueFactory::Classes%36DC59BC0200.attr

    // Additional Implementation Declarations
      //## begin IF::DiskQueueFactory%36DC59A600BE.implementation preserve=yes
      //## end IF::DiskQueueFactory%36DC59A600BE.implementation

};

//## begin IF::DiskQueueFactory%36DC59A600BE.postscript preserve=yes
//## end IF::DiskQueueFactory%36DC59A600BE.postscript

} // namespace IF

//## begin module%36DC5A370199.epilog preserve=yes
using namespace IF;
//## end module%36DC5A370199.epilog


#endif
