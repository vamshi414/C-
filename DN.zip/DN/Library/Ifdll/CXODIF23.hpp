//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3626701F00D4.cm preserve=no
//	$Date:   Jun 21 2017 15:59:46  $ $Author:   e1009839  $ $Revision:   1.8  $
//## end module%3626701F00D4.cm

//## begin module%3626701F00D4.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%3626701F00D4.cp

//## Module: CXOSIF23%3626701F00D4; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXODIF23.hpp

#ifndef CXOSIF23_h
#define CXOSIF23_h 1

//## begin module%3626701F00D4.additionalIncludes preserve=no
//## end module%3626701F00D4.additionalIncludes

//## begin module%3626701F00D4.includes preserve=yes
#include "CXODRU24.hpp"
//## end module%3626701F00D4.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;

} // namespace IF

//## begin module%3626701F00D4.declarations preserve=no
//## end module%3626701F00D4.declarations

//## begin module%3626701F00D4.additionalDeclarations preserve=yes
//## end module%3626701F00D4.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Session%352B74A1005D.preface preserve=yes
//## end IF::Session%352B74A1005D.preface

//## Class: Session%352B74A1005D
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%380C6A970235;Message { -> F}

class DllExport Session : public reusable::Observer  //## Inherits: <unnamed>%380C67E40336
{
  //## begin IF::Session%352B74A1005D.initialDeclarations preserve=yes
  //## end IF::Session%352B74A1005D.initialDeclarations

  public:
    //## Constructors (generated)
      Session();

      Session(const Session &right);

    //## Constructors (specified)
      //## Operation: Session%352B74EF029A
      Session (const string& strPartnerLUName);

    //## Destructor (generated)
      virtual ~Session();

    //## Assignment Operation (generated)
      Session & operator=(const Session &right);


    //## Other Operations (specified)
      //## Operation: getApplicationName%43F1344202AF
      static string getApplicationName ();

      //## Operation: logoff%352B750500B1
      bool logoff (IF::Message& hMessage, const string& strConversationID);

      //## Operation: logon%352B750902B6
      bool logon (IF::Message& hMessage, const string& strConversationID);

      //## Operation: securityResponse%352B7510037E
      void securityResponse (IF::Message& hMessage);

      //## Operation: setApplicationName%43F1344C0109
      static void setApplicationName (const string& strApplicationName);

      //## Operation: update%380C67F40144
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ASCII%352B75820129
      const bool ASCII () const
      {
        //## begin IF::Session::ASCII%352B75820129.get preserve=no
        return m_bASCII;
        //## end IF::Session::ASCII%352B75820129.get
      }


      //## Attribute: NewPassword%352B75AC0011
      const string& getNewPassword () const
      {
        //## begin IF::Session::getNewPassword%352B75AC0011.get preserve=no
        return m_strNewPassword;
        //## end IF::Session::getNewPassword%352B75AC0011.get
      }

      void setNewPassword (const string& value)
      {
        //## begin IF::Session::setNewPassword%352B75AC0011.set preserve=no
        m_strNewPassword = value;
        //## end IF::Session::setNewPassword%352B75AC0011.set
      }


      //## Attribute: On%352B7588015A
      const bool getOn () const
      {
        //## begin IF::Session::getOn%352B7588015A.get preserve=no
        return m_bOn;
        //## end IF::Session::getOn%352B7588015A.get
      }

      void setOn (bool value)
      {
        //## begin IF::Session::setOn%352B7588015A.set preserve=no
        m_bOn = value;
        //## end IF::Session::setOn%352B7588015A.set
      }


      //## Attribute: PartnerLUName%352B758D021F
      const string& getPartnerLUName () const
      {
        //## begin IF::Session::getPartnerLUName%352B758D021F.get preserve=no
        return m_strPartnerLUName;
        //## end IF::Session::getPartnerLUName%352B758D021F.get
      }

      void setPartnerLUName (const string& value)
      {
        //## begin IF::Session::setPartnerLUName%352B758D021F.set preserve=no
        m_strPartnerLUName = value;
        //## end IF::Session::setPartnerLUName%352B758D021F.set
      }


      //## Attribute: Password%352B75A403DB
      const string& getPassword () const
      {
        //## begin IF::Session::getPassword%352B75A403DB.get preserve=no
        return m_strPassword;
        //## end IF::Session::getPassword%352B75A403DB.get
      }

      void setPassword (const string& value)
      {
        //## begin IF::Session::setPassword%352B75A403DB.set preserve=no
        m_strPassword = value;
        //## end IF::Session::setPassword%352B75A403DB.set
      }


      //## Attribute: ReturnCode%352B75B102E9
      const string& getReturnCode () const
      {
        //## begin IF::Session::getReturnCode%352B75B102E9.get preserve=no
        return m_strReturnCode;
        //## end IF::Session::getReturnCode%352B75B102E9.get
      }

      void setReturnCode (const string& value)
      {
        //## begin IF::Session::setReturnCode%352B75B102E9.set preserve=no
        m_strReturnCode = value;
        //## end IF::Session::setReturnCode%352B75B102E9.set
      }


      //## Attribute: UserID%352B75A00028
      const string& getUserID () const
      {
        //## begin IF::Session::getUserID%352B75A00028.get preserve=no
        return m_strUserID;
        //## end IF::Session::getUserID%352B75A00028.get
      }

      void setUserID (const string& value)
      {
        //## begin IF::Session::setUserID%352B75A00028.set preserve=no
        m_strUserID = value;
        //## end IF::Session::setUserID%352B75A00028.set
      }


    // Additional Public Declarations
      //## begin IF::Session%352B74A1005D.public preserve=yes
      //## end IF::Session%352B74A1005D.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Session%352B74A1005D.protected preserve=yes
      //## end IF::Session%352B74A1005D.protected

  private:
    // Additional Private Declarations
      //## begin IF::Session%352B74A1005D.private preserve=yes
      //## end IF::Session%352B74A1005D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ApplicationName%3AE8849903D9
      //## begin IF::Session::ApplicationName%3AE8849903D9.attr preserve=no  public: static string* {V} 0
      static string* m_pstrApplicationName;
      //## end IF::Session::ApplicationName%3AE8849903D9.attr

      //## begin IF::Session::ASCII%352B75820129.attr preserve=no  public: bool {V} false
      bool m_bASCII;
      //## end IF::Session::ASCII%352B75820129.attr

      //## begin IF::Session::NewPassword%352B75AC0011.attr preserve=no  public: string {V} 
      string m_strNewPassword;
      //## end IF::Session::NewPassword%352B75AC0011.attr

      //## begin IF::Session::On%352B7588015A.attr preserve=no  public: bool {V} false
      bool m_bOn;
      //## end IF::Session::On%352B7588015A.attr

      //## begin IF::Session::PartnerLUName%352B758D021F.attr preserve=no  public: string {V} 
      string m_strPartnerLUName;
      //## end IF::Session::PartnerLUName%352B758D021F.attr

      //## begin IF::Session::Password%352B75A403DB.attr preserve=no  public: string {V} 
      string m_strPassword;
      //## end IF::Session::Password%352B75A403DB.attr

      //## Attribute: Region%352B759B00FD
      //## begin IF::Session::Region%352B759B00FD.attr preserve=no  public: static string* {V} 0
      static string* m_pstrRegion;
      //## end IF::Session::Region%352B759B00FD.attr

      //## begin IF::Session::ReturnCode%352B75B102E9.attr preserve=no  public: string {V} 
      string m_strReturnCode;
      //## end IF::Session::ReturnCode%352B75B102E9.attr

      //## Attribute: System%352B75960218
      //## begin IF::Session::System%352B75960218.attr preserve=no  public: static string* {V} 0
      static string* m_pstrSystem;
      //## end IF::Session::System%352B75960218.attr

      //## begin IF::Session::UserID%352B75A00028.attr preserve=no  public: string {V} 
      string m_strUserID;
      //## end IF::Session::UserID%352B75A00028.attr

    // Additional Implementation Declarations
      //## begin IF::Session%352B74A1005D.implementation preserve=yes
      //## end IF::Session%352B74A1005D.implementation

};

//## begin IF::Session%352B74A1005D.postscript preserve=yes
//## end IF::Session%352B74A1005D.postscript

} // namespace IF

//## begin module%3626701F00D4.epilog preserve=yes
using namespace IF;
//## end module%3626701F00D4.epilog


#endif
