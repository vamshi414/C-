//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35BF63F60200.cm preserve=no
//## end module%35BF63F60200.cm

//## begin module%35BF63F60200.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%35BF63F60200.cp

//## Module: CXOSIF03%35BF63F60200; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF03.hpp

#ifndef CXOSIF03_h
#define CXOSIF03_h 1

//## begin module%35BF63F60200.additionalIncludes preserve=no
//## end module%35BF63F60200.additionalIncludes

//## begin module%35BF63F60200.includes preserve=yes
//## end module%35BF63F60200.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Mask;
class Thread;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Trace_i;

} // namespace IF

//## begin module%35BF63F60200.declarations preserve=no
//## end module%35BF63F60200.declarations

//## begin module%35BF63F60200.additionalDeclarations preserve=yes
#include <vector>
//## end module%35BF63F60200.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Trace%347C8C3A019D.preface preserve=yes
//## end IF::Trace%347C8C3A019D.preface

//## Class: Trace%347C8C3A019D
//	The Trace class encapsulates an interface to the Connex
//	trace.
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5AE076BB0235;reusable::Mask { -> F}
//## Uses: <unnamed>%5AE076CD02A4;CodeTable { -> F}
//## Uses: <unnamed>%5AE07739012A;reusable::Thread { -> F}
//## Uses: <unnamed>%5AE0A17B0288;Trace_i { -> F}

class DllExport Trace : public reusable::Object  //## Inherits: <unnamed>%347C8C4D009F
{
  //## begin IF::Trace%347C8C3A019D.initialDeclarations preserve=yes
  //## end IF::Trace%347C8C3A019D.initialDeclarations

  public:
    //## Constructors (generated)
      Trace();

    //## Destructor (generated)
      virtual ~Trace();


    //## Other Operations (specified)
      //## Operation: getEnable%499B1F060201
      static const bool getEnable ();

      //## Operation: getInstance%5AE0801403E4
      static IF::Trace_i& getInstance ();

      //## Operation: getTemplate%650A021A0160
      static const reusable::string& getTemplate ();

      //## Operation: initialize%6509F3D50066
      static void initialize ();

      //## Operation: put%347C91DA0107
      //	Put a entry in the trace file.
      //## Semantics:
      //	1. Call CXWTR.
      static void put (const char* pszFile, unsigned int ulLine, const char* psBuffer, size_t lBuffer = -1, bool bCritical = false);

      //## Operation: put%347C91D2017E
      //	Put an entry in the trace file.
      //## Semantics:
      //	1. Call CXWTR.
      static void put (const char* psBuffer, size_t lBuffer = -1, bool bCritical = false);

      //## Operation: put%530F89AE0201
      static void put (const char* pszText, const string& strBuffer, bool bCritical = false);

      //## Operation: putHex%41E81CC20261
      //	Put an entry in the trace file.
      //## Semantics:
      //	1. Call CXWTR.
      static void putHex (const char* psBuffer, int lBuffer = -1, bool bCritical = false);

      //## Operation: setEnable%5AE074260246
      static void setEnable (bool value);

      //## Operation: terminate%3F0196530196
      static void terminate ();

    // Additional Public Declarations
      //## begin IF::Trace%347C8C3A019D.public preserve=yes
      //## end IF::Trace%347C8C3A019D.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Trace%347C8C3A019D.protected preserve=yes
      //## end IF::Trace%347C8C3A019D.protected

  private:
    // Additional Private Declarations
      //## begin IF::Trace%347C8C3A019D.private preserve=yes
      //## end IF::Trace%347C8C3A019D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Trace_i%5AE0A1550392
      //## begin IF::Trace::Trace_i%5AE0A1550392.attr preserve=no  private: static vector<Trace_i>* {V} 0
      static vector<Trace_i>* m_pTrace_i;
      //## end IF::Trace::Trace_i%5AE0A1550392.attr

    // Additional Implementation Declarations
      //## begin IF::Trace%347C8C3A019D.implementation preserve=yes
      //## end IF::Trace%347C8C3A019D.implementation

};

//## begin IF::Trace%347C8C3A019D.postscript preserve=yes
//## end IF::Trace%347C8C3A019D.postscript

} // namespace IF

//## begin module%35BF63F60200.epilog preserve=yes
using namespace IF;
//## end module%35BF63F60200.epilog


#endif
