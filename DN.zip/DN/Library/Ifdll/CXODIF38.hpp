//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3742C40D038F.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3742C40D038F.cm

//## begin module%3742C40D038F.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3742C40D038F.cp

//## Module: CXOSIF38%3742C40D038F; Package specification
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXODIF38.hpp

#ifndef CXOSIF38_h
#define CXOSIF38_h 1

//## begin module%3742C40D038F.additionalIncludes preserve=no
//## end module%3742C40D038F.additionalIncludes

//## begin module%3742C40D038F.includes preserve=yes
// $Date:   Jun 30 2006 11:35:42  $ $Author:   D02405  $ $Revision:   1.3  $
//## end module%3742C40D038F.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class EMailMessage;

} // namespace IF

//## begin module%3742C40D038F.declarations preserve=no
//## end module%3742C40D038F.declarations

//## begin module%3742C40D038F.additionalDeclarations preserve=yes
//## end module%3742C40D038F.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::EMailMessageVisitor%3742C0B003CD.preface preserve=yes
//## end IF::EMailMessageVisitor%3742C0B003CD.preface

//## Class: EMailMessageVisitor%3742C0B003CD
//## Category: Connex Foundation::IF_CAT%3451F55F009E
//## Subsystem: IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3742C1C702C0;EMailMessage { -> F}
//## Uses: <unnamed>%3CEE548F03E2;Trace { -> F}
//## Uses: <unnamed>%3CEE63DE010D;reusable::Transaction { -> F}
//## Uses: <unnamed>%3CEE63EF0360;Extract { -> F}

class DllExport EMailMessageVisitor : public reusable::Object  //## Inherits: <unnamed>%3742C0D00120
{
  //## begin IF::EMailMessageVisitor%3742C0B003CD.initialDeclarations preserve=yes
  //## end IF::EMailMessageVisitor%3742C0B003CD.initialDeclarations

  public:
    //## Constructors (generated)
      EMailMessageVisitor();

    //## Destructor (generated)
      virtual ~EMailMessageVisitor();


    //## Other Operations (specified)
      //## Operation: addFormat%3A194D0A00AE
      virtual void addFormat (const char* pszBuffer, int lLength);

      //## Operation: visitEMailMessage%3742C137025F
      virtual void visitEMailMessage (EMailMessage* pEMailMessage);

      //## Operation: visitText%3742C185030B
      virtual void visitText (string* pText);

    // Additional Public Declarations
      //## begin IF::EMailMessageVisitor%3742C0B003CD.public preserve=yes
      //## end IF::EMailMessageVisitor%3742C0B003CD.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: SQL%3CEE53B00229
      //## begin IF::EMailMessageVisitor::SQL%3CEE53B00229.attr preserve=no  protected: char * {U} 
      char *m_pSQL;
      //## end IF::EMailMessageVisitor::SQL%3CEE53B00229.attr

      //## Attribute: Value%3CEE564E0060
      //## begin IF::EMailMessageVisitor::Value%3CEE564E0060.attr preserve=no  protected: string {U} 
      string m_strValue;
      //## end IF::EMailMessageVisitor::Value%3CEE564E0060.attr

    // Data Members for Associations

      //## Association: Connex Foundation::IF_CAT::<unnamed>%3CEE659B00C6
      //## Role: EMailMessageVisitor::<m_hQuery>%3CEE659D0029
      //## begin IF::EMailMessageVisitor::<m_hQuery>%3CEE659D0029.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end IF::EMailMessageVisitor::<m_hQuery>%3CEE659D0029.role

    // Additional Protected Declarations
      //## begin IF::EMailMessageVisitor%3742C0B003CD.protected preserve=yes
      //## end IF::EMailMessageVisitor%3742C0B003CD.protected

  private:
    // Additional Private Declarations
      //## begin IF::EMailMessageVisitor%3742C0B003CD.private preserve=yes
      //## end IF::EMailMessageVisitor%3742C0B003CD.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::EMailMessageVisitor%3742C0B003CD.implementation preserve=yes
      //## end IF::EMailMessageVisitor%3742C0B003CD.implementation

};

//## begin IF::EMailMessageVisitor%3742C0B003CD.postscript preserve=yes
//## end IF::EMailMessageVisitor%3742C0B003CD.postscript

} // namespace IF

//## begin module%3742C40D038F.epilog preserve=yes
using namespace IF;
//## end module%3742C40D038F.epilog


#endif
