//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36DC56BC0274.cm preserve=no
//	$Date:   Apr 05 2018 15:47:44  $ $Author:   e1009652  $ $Revision:   1.4  $
//## end module%36DC56BC0274.cm

//## begin module%36DC56BC0274.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%36DC56BC0274.cp

//## Module: CXOSIF32%36DC56BC0274; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.8A.R001\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXOSIF32.cpp

//## begin module%36DC56BC0274.additionalIncludes preserve=no
//## end module%36DC56BC0274.additionalIncludes

//## begin module%36DC56BC0274.includes preserve=yes
// $Date:   Apr 05 2018 15:47:44  $ $Author:   e1009652  $ $Revision:   1.4  $
#include <memory.h>
//## end module%36DC56BC0274.includes

#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif


//## begin module%36DC56BC0274.declarations preserve=no
//## end module%36DC56BC0274.declarations

//## begin module%36DC56BC0274.additionalDeclarations preserve=yes
#include "CXODIF22.hpp"
#include "CXODIF39.hpp"
//## end module%36DC56BC0274.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::QueueFactory 

//## begin IF::QueueFactory::Instance%36DC545A0303.attr preserve=no  private: static IF::QueueFactory {R} 0
IF::QueueFactory *QueueFactory::m_pInstance = 0;
//## end IF::QueueFactory::Instance%36DC545A0303.attr

QueueFactory::QueueFactory()
  //## begin QueueFactory::QueueFactory%36DC539F00F1_const.hasinit preserve=no
  //## end QueueFactory::QueueFactory%36DC539F00F1_const.hasinit
  //## begin QueueFactory::QueueFactory%36DC539F00F1_const.initialization preserve=yes
  //## end QueueFactory::QueueFactory%36DC539F00F1_const.initialization
{
  //## begin IF::QueueFactory::QueueFactory%36DC539F00F1_const.body preserve=yes
   memcpy(m_sID,"IF32",4);
   m_pInstance = this;
  //## end IF::QueueFactory::QueueFactory%36DC539F00F1_const.body
}


QueueFactory::~QueueFactory()
{
  //## begin IF::QueueFactory::~QueueFactory%36DC539F00F1_dest.body preserve=yes
  //## end IF::QueueFactory::~QueueFactory%36DC539F00F1_dest.body
}



//## Other Operations (implementation)
Queue* QueueFactory::create (const IF::Queue& hQueue)
{
  //## begin IF::QueueFactory::create%5ABD487E01A8.body preserve=yes
   return new SocketQueue(dynamic_cast<const SocketQueue&> (hQueue));
  //## end IF::QueueFactory::create%5ABD487E01A8.body
}

QueueFactory* QueueFactory::instance ()
{
  //## begin IF::QueueFactory::instance%36DC54360184.body preserve=yes
   return m_pInstance;
  //## end IF::QueueFactory::instance%36DC54360184.body
}

// Additional Declarations
  //## begin IF::QueueFactory%36DC539F00F1.declarations preserve=yes
  //## end IF::QueueFactory%36DC539F00F1.declarations

} // namespace IF

//## begin module%36DC56BC0274.epilog preserve=yes
//## end module%36DC56BC0274.epilog
