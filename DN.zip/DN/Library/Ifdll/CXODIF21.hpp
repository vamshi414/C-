//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%362524A30086.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%362524A30086.cm

//## begin module%362524A30086.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%362524A30086.cp

//## Module: CXOSIF21%362524A30086; Package specification
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXODIF21.hpp

#ifndef CXOSIF21_h
#define CXOSIF21_h 1

//## begin module%362524A30086.additionalIncludes preserve=no
//## end module%362524A30086.additionalIncludes

//## begin module%362524A30086.includes preserve=yes
// $Date:   Apr 08 2004 07:21:20  $ $Author:   D02405  $ $Revision:   1.2  $
//## end module%362524A30086.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Subject;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Message;

} // namespace IF

//## begin module%362524A30086.declarations preserve=no
//## end module%362524A30086.declarations

//## begin module%362524A30086.additionalDeclarations preserve=yes
//## end module%362524A30086.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::RemoteObserver%34A4060B02E8.preface preserve=yes
//## end IF::RemoteObserver%34A4060B02E8.preface

//## Class: RemoteObserver%34A4060B02E8
//	The RemoteObserver class provides observer functionality
//	to the Subject class.
//
//	It is based on the ConcreteObserver class in the
//	Observer pattern.
//## Category: Connex Foundation::IF_CAT%3451F55F009E
//## Subsystem: IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%36260A220140;Message { -> F}
//## Uses: <unnamed>%3BFE7B76002E;Extract { -> F}

class DllExport RemoteObserver : public reusable::Observer  //## Inherits: <unnamed>%34A4081B007A
{
  //## begin IF::RemoteObserver%34A4060B02E8.initialDeclarations preserve=yes
  //## end IF::RemoteObserver%34A4060B02E8.initialDeclarations

  public:
    //## Constructors (generated)
      RemoteObserver();

    //## Constructors (specified)
      //## Operation: RemoteObserver%36252A7E015E
      RemoteObserver (Subject* pOwner, const char* pszName);

    //## Destructor (generated)
      virtual ~RemoteObserver();


    //## Other Operations (specified)
      //## Operation: update%3626051C024F
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin IF::RemoteObserver%34A4060B02E8.public preserve=yes
      //## end IF::RemoteObserver%34A4060B02E8.public

  protected:
    // Additional Protected Declarations
      //## begin IF::RemoteObserver%34A4060B02E8.protected preserve=yes
      //## end IF::RemoteObserver%34A4060B02E8.protected

  private:
    // Additional Private Declarations
      //## begin IF::RemoteObserver%34A4060B02E8.private preserve=yes
      //## end IF::RemoteObserver%34A4060B02E8.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: strName%34A4086301E7
      //## begin IF::RemoteObserver::strName%34A4086301E7.attr preserve=no  private: string {U} 
      string m_strName;
      //## end IF::RemoteObserver::strName%34A4086301E7.attr

    // Data Members for Associations

      //## Association: Connex Foundation::IF_CAT::<unnamed>%36252A130092
      //## Role: RemoteObserver::<m_pSubject>%36252A1402BA
      //## begin IF::RemoteObserver::<m_pSubject>%36252A1402BA.role preserve=no  public: reusable::Subject { -> RFHgN}
      reusable::Subject *m_pSubject;
      //## end IF::RemoteObserver::<m_pSubject>%36252A1402BA.role

    // Additional Implementation Declarations
      //## begin IF::RemoteObserver%34A4060B02E8.implementation preserve=yes
      //## end IF::RemoteObserver%34A4060B02E8.implementation

};

//## begin IF::RemoteObserver%34A4060B02E8.postscript preserve=yes
//## end IF::RemoteObserver%34A4060B02E8.postscript

} // namespace IF

//## begin module%362524A30086.epilog preserve=yes
using namespace IF;
//## end module%362524A30086.epilog


#endif
