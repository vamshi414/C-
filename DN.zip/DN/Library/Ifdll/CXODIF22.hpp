//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35A240140137.cm preserve=no
//	$Date:   Jun 24 2021 11:10:54  $ $Author:   e1014059  $ $Revision:   1.18  $
//## end module%35A240140137.cm

//## begin module%35A240140137.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%35A240140137.cp

//## Module: CXOSIF22%35A240140137; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\bV02.4B.R001\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF22.hpp

#ifndef CXOSIF22_h
#define CXOSIF22_h 1

//## begin module%35A240140137.additionalIncludes preserve=no
//## end module%35A240140137.additionalIncludes

//## begin module%35A240140137.includes preserve=yes
// $Date:   Jun 24 2021 11:10:54  $ $Author:   e1014059  $ $Revision:   1.18  $
#include <map>
//## end module%35A240140137.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Signal;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

namespace reusable {
class CriticalSection;
} // namespace reusable

namespace IF {
class Trace;
class Extract;
class QueueFactory;

} // namespace IF

//## begin module%35A240140137.declarations preserve=no
//## end module%35A240140137.declarations

//## begin module%35A240140137.additionalDeclarations preserve=yes
//## end module%35A240140137.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Queue%34A4155701BD.preface preserve=yes
//## end IF::Queue%34A4155701BD.preface

//## Class: Queue%34A4155701BD
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%36DDB1BB024F;Message { -> F}
//## Uses: <unnamed>%36DE9A240399;QueueFactory { -> F}
//## Uses: <unnamed>%3AC487420208;Extract { -> F}
//## Uses: <unnamed>%3DCA7B2103C8;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%41F559A40203;Trace { -> F}

class DllExport Queue : public reusable::Observer  //## Inherits: <unnamed>%36DA963E01E3
{
  //## begin IF::Queue%34A4155701BD.initialDeclarations preserve=yes
  public:
      enum MessageType
      {
         DATAGRAM,
         REQUEST,
         REPLY,
         COMMAND
      };
      enum ObjectType
      {
         CX_NORMAL_QUEUE,
         CX_DISTRIBUTION_QUEUE,
         CX_SELECTION_QUEUE
      };
  //## end IF::Queue%34A4155701BD.initialDeclarations

  public:
    //## Constructors (generated)
      Queue();

      Queue(const Queue &right);

    //## Constructors (specified)
      //## Operation: Queue%36DE90A5037F
      Queue (const char* pszName);

    //## Destructor (generated)
      virtual ~Queue();


    //## Other Operations (specified)
      //## Operation: attach%34A4159801D4
      static int attach (const char* pszName, enum ObjectType nObjectType = CX_NORMAL_QUEUE);

      //## Operation: close%36DD523000FA
      virtual bool close () = 0;

      //## Operation: close%515AFC9C03A0
      static void close (const string& strName);

      //## Operation: detach%34A415A30202
      static int detach (const char* pszName);

      //## Operation: getDepth%41AE2535034B
      virtual int getDepth ()
      {
        //## begin IF::Queue::getDepth%41AE2535034B.body preserve=yes
         return 0;
        //## end IF::Queue::getDepth%41AE2535034B.body
      }

      //## Operation: insert%4CC7036003E7
      static void insert (const string&  strName, Queue* pQueue);

      //## Operation: listen%4024E915000F
      virtual bool listen ();

      //## Operation: listen%4024E72802BF
      static bool listen (const char* pszName);

      //## Operation: locate%36EE7C2F0234
      static Queue* locate (const string& strRealName);

      //## Operation: observe%36DA96EB015F
      static int observe (const char* pszName);

      //## Operation: onQuiesce%41AE25F6030D
      virtual void onQuiesce ()
      {
        //## begin IF::Queue::onQuiesce%41AE25F6030D.body preserve=yes
        //## end IF::Queue::onQuiesce%41AE25F6030D.body
      }

      //## Operation: open%36DD5221030B
      virtual bool open () = 0;

      //## Operation: reply%4023E1C6005D
      static bool reply (int lThread, Message* pMessage, enum MessageType nMessageType = DATAGRAM);

      //## Operation: send%36DDB00F02A4
      static bool send (const char* pszName, Message* pMessage, enum MessageType nMessageType = DATAGRAM);

      //## Operation: send%36DE8A60004C
      virtual bool send (Message* pMessage, enum MessageType nMessageType) = 0;

      //## Operation: terminate%36DEA4F0031B
      static void terminate ();

      //## Operation: trace%3DCA779E033C
      virtual void trace (int lPosition);

      //## Operation: traceAll%3DCA7996001F
      static int traceAll ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Name%36DE906C00D4
      const string& getName () const
      {
        //## begin IF::Queue::getName%36DE906C00D4.get preserve=no
        return m_strName;
        //## end IF::Queue::getName%36DE906C00D4.get
      }


      //## Attribute: RealName%36EE7DB901FE
      const string& getRealName () const
      {
        //## begin IF::Queue::getRealName%36EE7DB901FE.get preserve=no
        return m_strRealName;
        //## end IF::Queue::getRealName%36EE7DB901FE.get
      }


      //## Attribute: Thread%4023FA14000F
      const int getThread () const
      {
        //## begin IF::Queue::getThread%4023FA14000F.get preserve=no
        return m_lThread;
        //## end IF::Queue::getThread%4023FA14000F.get
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::IF_CAT::<unnamed>%4A65CCE9001F
      //## Role: Queue::<m_pSignal>%4A65CCE90399
      reusable::Signal * getSignal ()
      {
        //## begin IF::Queue::getSignal%4A65CCE90399.get preserve=no
        return m_pSignal;
        //## end IF::Queue::getSignal%4A65CCE90399.get
      }

      void setSignal (reusable::Signal * value)
      {
        //## begin IF::Queue::setSignal%4A65CCE90399.set preserve=no
        m_pSignal = value;
        //## end IF::Queue::setSignal%4A65CCE90399.set
      }


    // Additional Public Declarations
      //## begin IF::Queue%34A4155701BD.public preserve=yes
      //## end IF::Queue%34A4155701BD.public

  protected:
    // Data Members for Class Attributes

      //## begin IF::Queue::Name%36DE906C00D4.attr preserve=no  public: string {V} 
      string m_strName;
      //## end IF::Queue::Name%36DE906C00D4.attr

      //## begin IF::Queue::RealName%36EE7DB901FE.attr preserve=no  public: string {V} 
      string m_strRealName;
      //## end IF::Queue::RealName%36EE7DB901FE.attr

      //## begin IF::Queue::Thread%4023FA14000F.attr preserve=no  public: int {V} 0
      int m_lThread;
      //## end IF::Queue::Thread%4023FA14000F.attr

    // Data Members for Associations

      //## Association: Connex Library::IF_CAT::<unnamed>%4A65CCE9001F
      //## begin IF::Queue::<m_pSignal>%4A65CCE90399.role preserve=no  public: reusable::Signal { -> RFHgN}
      reusable::Signal *m_pSignal;
      //## end IF::Queue::<m_pSignal>%4A65CCE90399.role

    // Additional Protected Declarations
      //## begin IF::Queue%34A4155701BD.protected preserve=yes
      static map<string,Queue*,less<string> >* m_pQueue;
      //## end IF::Queue%34A4155701BD.protected
  private:

    //## Other Operations (specified)
      //## Operation: queueName%36DA971101E6
      static string queueName (const char* pszName);

    // Additional Private Declarations
      //## begin IF::Queue%34A4155701BD.private preserve=yes
      //## end IF::Queue%34A4155701BD.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IF::Queue%34A4155701BD.implementation preserve=yes
      //## end IF::Queue%34A4155701BD.implementation

};

//## begin IF::Queue%34A4155701BD.postscript preserve=yes
//## end IF::Queue%34A4155701BD.postscript

} // namespace IF

//## begin module%35A240140137.epilog preserve=yes
using namespace IF;
//## end module%35A240140137.epilog


#endif
