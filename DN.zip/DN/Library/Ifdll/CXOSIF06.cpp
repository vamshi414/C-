//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%36266B6F009D.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36266B6F009D.cm

//## begin module%36266B6F009D.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36266B6F009D.cp

//## Module: CXOSIF06%36266B6F009D; Package body
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXOSIF06.cpp

//## begin module%36266B6F009D.additionalIncludes preserve=no
//## end module%36266B6F009D.additionalIncludes

//## begin module%36266B6F009D.includes preserve=yes
// $Date:   May 15 2020 09:01:14  $ $Author:   e1009510  $ $Revision:   1.4  $
//## end module%36266B6F009D.includes

#ifndef CXOSIF06_h
#include "CXODIF06.hpp"
#endif
//## begin module%36266B6F009D.declarations preserve=no
//## end module%36266B6F009D.declarations

//## begin module%36266B6F009D.additionalDeclarations preserve=yes
#ifdef MVS
extern "OS"
{
int CXESC(char* pszSecondaryCodes,int* plRC);
}
#endif
//## end module%36266B6F009D.additionalDeclarations


//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::SecondaryCodes 

SecondaryCodes::SecondaryCodes()
  //## begin SecondaryCodes::SecondaryCodes%34802A3D0040_const.hasinit preserve=no
  //## end SecondaryCodes::SecondaryCodes%34802A3D0040_const.hasinit
  //## begin SecondaryCodes::SecondaryCodes%34802A3D0040_const.initialization preserve=yes
  //## end SecondaryCodes::SecondaryCodes%34802A3D0040_const.initialization
{
  //## begin IF::SecondaryCodes::SecondaryCodes%34802A3D0040_const.body preserve=yes
   memcpy(m_sID,"IF06",4);
  //## end IF::SecondaryCodes::SecondaryCodes%34802A3D0040_const.body
}


SecondaryCodes::~SecondaryCodes()
{
  //## begin IF::SecondaryCodes::~SecondaryCodes%34802A3D0040_dest.body preserve=yes
  //## end IF::SecondaryCodes::~SecondaryCodes%34802A3D0040_dest.body
}



//## Other Operations (implementation)
string SecondaryCodes::extract ()
{
  //## begin IF::SecondaryCodes::extract%3481C6AD0300.body preserve=yes
   char szSecondaryCodes[61];
#ifdef MVS
   int lRC;
   CXESC(szSecondaryCodes,&lRC);
#else
   szSecondaryCodes[0] = '\0';
#endif
   szSecondaryCodes[60] = '\0';
   return string(szSecondaryCodes);
  //## end IF::SecondaryCodes::extract%3481C6AD0300.body
}

// Additional Declarations
  //## begin IF::SecondaryCodes%34802A3D0040.declarations preserve=yes
  //## end IF::SecondaryCodes%34802A3D0040.declarations

} // namespace IF

//## begin module%36266B6F009D.epilog preserve=yes
//## end module%36266B6F009D.epilog
