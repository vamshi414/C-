//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%35CB0EBC0267.cm preserve=no
//	$Date:   Jun 22 2020 13:35:46  $ $Author:   e1009839  $ $Revision:   1.12  $
//## end module%35CB0EBC0267.cm

//## begin module%35CB0EBC0267.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%35CB0EBC0267.cp

//## Module: CXOSIF26%35CB0EBC0267; Package body
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\IFDLL\CXOSIF26.cpp

//## begin module%35CB0EBC0267.additionalIncludes preserve=no
//## end module%35CB0EBC0267.additionalIncludes

//## begin module%35CB0EBC0267.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%35CB0EBC0267.includes

#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF26_h
#include "CXODIF26.hpp"
#endif


//## begin module%35CB0EBC0267.declarations preserve=no
//## end module%35CB0EBC0267.declarations

//## begin module%35CB0EBC0267.additionalDeclarations preserve=yes
#ifdef MVS
extern "OS"
{
int CXCVB(const char* psDecimalValue,int* piBinaryValue,int* piRC);
int CXCVP(int* piBinaryValue,char* psDecimalValue,int* piRC);
}
#endif
//## end module%35CB0EBC0267.additionalDeclarations


//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Decimal

Decimal::Decimal()
  //## begin Decimal::Decimal%35CB0754029C_const.hasinit preserve=no
  //## end Decimal::Decimal%35CB0754029C_const.hasinit
  //## begin Decimal::Decimal%35CB0754029C_const.initialization preserve=yes
  //## end Decimal::Decimal%35CB0754029C_const.initialization
{
  //## begin IF::Decimal::Decimal%35CB0754029C_const.body preserve=yes
  //## end IF::Decimal::Decimal%35CB0754029C_const.body
}


Decimal::~Decimal()
{
  //## begin IF::Decimal::~Decimal%35CB0754029C_dest.body preserve=yes
  //## end IF::Decimal::~Decimal%35CB0754029C_dest.body
}



//## Other Operations (implementation)
bool Decimal::asLong (const char *psDecimalValue, short siLength, int* piBinaryValue)
{
  //## begin IF::Decimal::asLong%35CB0CF201C8.body preserve=yes
   *piBinaryValue = 0;
   if (siLength < 1
      || siLength > 8)
      return false;
   int iRC = 0;
   char psTemp[8];
   memset(psTemp,'\0',sizeof(psTemp));
   memcpy(psTemp + (8 - siLength),psDecimalValue,siLength);
#ifdef MVS
   CXCVB(psTemp,piBinaryValue,&iRC);
#else
   unsigned int hi = ntohl(*(unsigned int*)psDecimalValue);
   unsigned int low = ntohl(*(unsigned int*)(psDecimalValue + 4));
   char szTemp[20];
   sprintf(szTemp,"%x%07x",hi,low >> 4);
   double d = atof(szTemp);
   if ((low & 0x0000000F) == 0xd)
      d *= -1;
   if (d >= -2147483648.00 && d <= 2147483647.00)
      *piBinaryValue = (int)d;
#endif
   return (iRC == 0);
  //## end IF::Decimal::asLong%35CB0CF201C8.body
}

bool Decimal::asDecimal (int iBinaryValue, char *psDecimalValue, short siLength)
{
  //## begin IF::Decimal::asDecimal%3C9F8EC40232.body preserve=yes
   if (siLength < 1
      || siLength > 8)
      return false;
   int iRC = 0;
#ifdef MVS
   char psTemp[8];
   CXCVP(&iBinaryValue,psTemp,&iRC);
   memcpy(psDecimalValue,psTemp + (8 - siLength),siLength);
#else
   asDecimal((double)iBinaryValue,psDecimalValue,siLength);
#endif
   return (iRC == 0);
  //## end IF::Decimal::asDecimal%3C9F8EC40232.body
}

bool Decimal::asDecimal (double dDoubleValue, char *psDecimalValue, short siLength)
{
  //## begin IF::Decimal::asDecimal%49E5F40401D4.body preserve=yes
   if (siLength < 1
      || siLength > 8)
      return false;
   int iRC = 0;
   char psTemp[8];
#ifdef MVS
   if (dDoubleValue <= 2147483647
      && dDoubleValue >= -2147483648)
   {
      int iBinaryValue = (int)dDoubleValue;
      CXCVP(&iBinaryValue,psTemp,&iRC);
      memcpy(psDecimalValue,psTemp + (8 - siLength),siLength);
      return (iRC == 0);
   }
#endif
   char szTemp[PERCENTF];
   snprintf(szTemp,sizeof(szTemp),"%015.0f",dDoubleValue);
   szTemp[15] = (dDoubleValue >= 0) ? 0x0F : 0x0D;
   for (int i = 0; i < 8; i++)
      psTemp[i] = (szTemp[2*i] << 4) | (szTemp[(2*i)+1] & 0x0F);
   memcpy(psDecimalValue,psTemp + (8 - siLength),siLength);
   return (iRC == 0);
  //## end IF::Decimal::asDecimal%49E5F40401D4.body
}

bool Decimal::asDouble (const char *psDecimalValue, short siLength, double* pdDoubleValue)
{
  //## begin IF::Decimal::asDouble%3A0AC1230012.body preserve=yes
   string strResult;
   CodeTable::nibbleToByte(psDecimalValue,siLength,strResult);
   char cSign = strResult[strResult.length() - 1];
   strResult.erase(strResult.length() - 1);
   *pdDoubleValue = atof(strResult.c_str());
   if (cSign == 'D')
      *pdDoubleValue = 0 - *pdDoubleValue;
   return true;
  //## end IF::Decimal::asDouble%3A0AC1230012.body
}

// Additional Declarations
  //## begin IF::Decimal%35CB0754029C.declarations preserve=yes
  //## end IF::Decimal%35CB0754029C.declarations

} // namespace IF

//## begin module%35CB0EBC0267.epilog preserve=yes
//## end module%35CB0EBC0267.epilog
