//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%36266CAE007D.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36266CAE007D.cm

//## begin module%36266CAE007D.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36266CAE007D.cp

//## Module: CXOSIF09%36266CAE007D; Package body
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXOSIF09.cpp

//## begin module%36266CAE007D.additionalIncludes preserve=no
//## end module%36266CAE007D.additionalIncludes

//## begin module%36266CAE007D.includes preserve=yes
// $Date:   May 15 2020 09:01:16  $ $Author:   e1009510  $ $Revision:   1.5  $
//## end module%36266CAE007D.includes

#ifndef CXOSIF09_h
#include "CXODIF09.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif


//## begin module%36266CAE007D.declarations preserve=no
//## end module%36266CAE007D.declarations

//## begin module%36266CAE007D.additionalDeclarations preserve=yes
#include "CXODIF14.hpp"
#define CM_OK 0
//## end module%36266CAE007D.additionalDeclarations


//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Destination 






Destination::Destination()
  //## begin Destination::Destination%34801B760358_const.hasinit preserve=no
      : m_bDisplay(false),
        m_bOpen(false)
  //## end Destination::Destination%34801B760358_const.hasinit
  //## begin Destination::Destination%34801B760358_const.initialization preserve=yes
  //## end Destination::Destination%34801B760358_const.initialization
{
  //## begin IF::Destination::Destination%34801B760358_const.body preserve=yes
   memcpy(m_sID,"IF09",4);
  //## end IF::Destination::Destination%34801B760358_const.body
}

Destination::Destination(const Destination &right)
  //## begin Destination::Destination%34801B760358_copy.hasinit preserve=no
      : m_bDisplay(false),
        m_bOpen(false)
  //## end Destination::Destination%34801B760358_copy.hasinit
  //## begin Destination::Destination%34801B760358_copy.initialization preserve=yes
   ,Object(right)
  //## end Destination::Destination%34801B760358_copy.initialization
{
  //## begin IF::Destination::Destination%34801B760358_copy.body preserve=yes
   memcpy(m_sID,"IF09",4);
   m_bDisplay = right.m_bDisplay;
   m_strName = right.m_strName;
   m_bOpen = right.m_bOpen;
   m_strSymDestName = right.m_strSymDestName;
  //## end IF::Destination::Destination%34801B760358_copy.body
}

Destination::Destination (const char* pszName, const char* pszSymDestName, bool bDisplay)
  //## begin IF::Destination::Destination%364D9DBB0216.hasinit preserve=no
      : m_bDisplay(false),
        m_bOpen(false)
  //## end IF::Destination::Destination%364D9DBB0216.hasinit
  //## begin IF::Destination::Destination%364D9DBB0216.initialization preserve=yes
   ,m_strName(pszName)
   ,m_strSymDestName(pszSymDestName)
  //## end IF::Destination::Destination%364D9DBB0216.initialization
{
  //## begin IF::Destination::Destination%364D9DBB0216.body preserve=yes
   memcpy(m_sID,"IF09",4);
   m_bDisplay = bDisplay;
  //## end IF::Destination::Destination%364D9DBB0216.body
}


Destination::~Destination()
{
  //## begin IF::Destination::~Destination%34801B760358_dest.body preserve=yes
   close();
  //## end IF::Destination::~Destination%34801B760358_dest.body
}


Destination & Destination::operator=(const Destination &right)
{
  //## begin IF::Destination::operator=%34801B760358_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_bDisplay = right.m_bDisplay;
   m_strName = right.m_strName;
   m_bOpen = right.m_bOpen;
   m_strSymDestName = right.m_strSymDestName;
   return *this;
  //## end IF::Destination::operator=%34801B760358_assign.body
}



//## Other Operations (implementation)
int Destination::close ()
{
  //## begin IF::Destination::close%364D9DCD017B.body preserve=yes
   int lRC = CM_OK;
#ifdef MVS
   if (m_bOpen)
      CXCLOS(m_strSymDestName.c_str(),&lRC);
#endif
   return lRC;
  //## end IF::Destination::close%364D9DCD017B.body
}

void Destination::display (const char* pszState)
{
  //## begin IF::Destination::display%364D9EBD01B2.body preserve=yes
   if (m_bDisplay)
      Console::display(pszState,m_strSymDestName.c_str());
  //## end IF::Destination::display%364D9EBD01B2.body
}

int Destination::open ()
{
  //## begin IF::Destination::open%364D9DD4006D.body preserve=yes
   if (m_bOpen)
   {
      m_bOpen = false;
      display("CX201");
   }
   int lRC = CM_OK;
   int m = 1;
#ifdef MVS
   CXSOT(&m,&lRC);
   CXOPEN(m_strSymDestName.c_str(),&lRC);
#endif
   return lRC;
  //## end IF::Destination::open%364D9DD4006D.body
}

void Destination::openCompleted ()
{
  //## begin IF::Destination::openCompleted%364D9DD8020D.body preserve=yes
   m_bOpen = true;
   display("CX200");
  //## end IF::Destination::openCompleted%364D9DD8020D.body
}

// Additional Declarations
  //## begin IF::Destination%34801B760358.declarations preserve=yes
  //## end IF::Destination%34801B760358.declarations

} // namespace IF

//## begin module%36266CAE007D.epilog preserve=yes
//## end module%36266CAE007D.epilog
