//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36266F4D02E5.cm preserve=no
//## end module%36266F4D02E5.cm

//## begin module%36266F4D02E5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36266F4D02E5.cp

//## Module: CXOSIF16%36266F4D02E5; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF16.hpp

#ifndef CXOSIF16_h
#define CXOSIF16_h 1

//## begin module%36266F4D02E5.additionalIncludes preserve=no
//## end module%36266F4D02E5.additionalIncludes

//## begin module%36266F4D02E5.includes preserve=yes
#include <vector>
#include <map>
#include <set>
//## end module%36266F4D02E5.includes

#ifndef CXOSRU24_h
#include "CXODRU24.hpp"
#endif
#ifndef CXOSRU01_h
#include "CXODRU01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
class Hint;
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Registry;

} // namespace IF

//## begin module%36266F4D02E5.declarations preserve=no
//## end module%36266F4D02E5.declarations

//## begin module%36266F4D02E5.additionalDeclarations preserve=yes
//## end module%36266F4D02E5.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Extract%3472FB2202C0.preface preserve=yes
//## end IF::Extract%3472FB2202C0.preface

//## Class: Extract%3472FB2202C0
//	The Extract class provides access to the extract file
//	for a process.
//
//	It is based on the Singleton pattern.
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1



//## Uses: <unnamed>%38512318030E;Trace { -> F}
//## Uses: <unnamed>%3851231C03E6;FlatFile { -> F}
//## Uses: <unnamed>%3E6F655403A9;Registry { -> F}
//## Uses: <unnamed>%471F51D8032C;reusable::IString { -> }
//## Uses: <unnamed>%47D14D26009C;reusable::Buffer { -> F}
//## Uses: <unnamed>%47D14D3F0177;reusable::Hint { -> F}
//## Uses: <unnamed>%5FB2D3390225;reusable::Query { -> F}

class DllExport Extract : public reusable::Subject  //## Inherits: <unnamed>%38511EBE034E
{
  //## begin IF::Extract%3472FB2202C0.initialDeclarations preserve=yes
  //## end IF::Extract%3472FB2202C0.initialDeclarations

  public:
    //## Constructors (generated)
      Extract();

    //## Destructor (generated)
      virtual ~Extract();


    //## Other Operations (specified)
      //## Operation: addRecord%48E692150166
      void addRecord (const string& strRecord);

      //## Operation: find%461649CC0251
      bool find (const char* pszArgument, string& strRecord) const;

      //## Operation: get%38511F2603D0
      bool get (const char* pszKey, IString& strRecord) const;

      //## Operation: get%38511F950362
      bool get (int lIndex, IString& strRecord) const;

      //## Operation: getAddressSpace%3F2FD22A005D
      bool getAddressSpace (const string& strName, string& strAddressSpace);

      //## Operation: getCustomCode%61AE42A603B3
      const reusable::string& getCustomCode (int iIndex = 0)
      {
        //## begin IF::Extract::getCustomCode%61AE42A603B3.body preserve=yes
         return m_strCustomCode[iIndex];
        //## end IF::Extract::getCustomCode%61AE42A603B3.body
      }

      //## Operation: getCustomer%46414DDE0382
      void getCustomer (set<string> &hCustomer);

      //## Operation: getHost%3E7226BD00BB
      bool getHost (const string& strAddressSpace, string& strHost);

      //## Operation: getLong%38511FE70139
      bool getLong (const char* pszKey, const char* pszSearchValue, int* plValue);

      //## Operation: getQueue%3E720781005D
      bool getQueue (const char* pszName, string& strHost, unsigned short* piPort);

      //## Operation: getRecord%3E70AAC00251
      bool getRecord (const char* pszKey, string& strRecord) const;

      //## Operation: getRecord%3E70AAC30128
      bool getRecord (int lIndex, string& strRecord) const;

      //## Operation: getSpec%385120260085
      bool getSpec (const char* pszKey, string& strValue, const char* pszCUST_ID = 0) const;

      //## Operation: getSpec%5ED891DD001C
      void getSpec (vector<string>& hExtractValues, const string&  strParam, string& strValue);

      //## Operation: getSpec%5C40DA4F001D
      void getSpec (const char* pszKey, vector<string>& hValue) const;

      //## Operation: getSpec%5ED892A4009A
      bool getSpec (const char *pszModuleID, const string &pszKey, string &strValue);

      //## Operation: getString%3851205D01DA
      bool getString (const char* pszKey, const char* pszSearchValue, string& strValue, int iLength);

      //## Operation: getTimer%3851209100A8
      int getTimer (const char* pszTimer);

      //## Operation: getVersion%491371EA033C
      reusable::string getVersion ();

      //## Operation: instance%38503B0E01B5
      static Extract* instance ();

      //## Operation: read%3E70DD580222
      bool read (const char* pszName, const char* pszMember);

      //## Operation: refresh%385120CE0153
      void refresh (bool bNotify = true);

      //## Operation: setCustomCode%61AE433202F0
      void setCustomCode (const string& value, int iIndex = 0)
      {
        //## begin IF::Extract::setCustomCode%61AE433202F0.body preserve=yes
         m_strCustomCode[iIndex] = value;
        //## end IF::Extract::setCustomCode%61AE433202F0.body
      }

      //## Operation: setName%3D52AC280213
      void setName (const string& strName);

      //## Operation: setRecord%5395DC14006C
      bool setRecord (const char* pszKey, const string& strRecord);

      //## Operation: setup%3E6F64DF0232
      //## Postconditions:
      //	<body>
      //	<title>IG
      //	<h1>HN
      //	<h2>FO
      //	<h3>DataNavigator file system
      //	<p>
      //	The first instance of an Application Server generates
      //	the initial configuration files:
      //	<ol>
      //	<li>HKEY_LOCAL_MACHINE\SOFTWARE\eFunds, Inc.\Data
      //	Navigator\Server\Settings
      //	<ul>
      //	<li>NODE001 REG_SZ <i>node001</i>
      //	<li>QUALIFY REG_SZ <i>qualify</i>
      //	</ul>
      //	<li><i>node001</i>\Smtp
      //	<li><i>node001</i>\Smtp\DeadLetter
      //	<li><i>node001</i>\Smtp\Inbox
      //	<li><i>node001</i>\Smtp\Outbox
      //	<li><i>node001</i>\Trace
      //	<li><i>node001\qualify</i>\Pprev
      //	<li><i>node001\qualify</i>\Pprod
      //	<ul>
      //	<li><i>customer</i>SPEC.txt
      //	<li>FM.txt
      //	<li>HM.txt
      //	<li>HOST.txt
      //	<li>MMC.txt
      //	<li>SITESPEC.txt
      //	<li>XT.txt
      //	</ul>
      //	<li><i>node001\qualify</i>\Pstage
      //	<li>Services
      //	<ul>
      //	<li>DataNavigator FM
      //	</ul>
      //	</ol>
      //	</body>
      bool setup ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Alias%468A3C9F0148
      //	Server name
      const string& getAlias () const
      {
        //## begin IF::Extract::getAlias%468A3C9F0148.get preserve=no
        return m_strAlias;
        //## end IF::Extract::getAlias%468A3C9F0148.get
      }

      void setAlias (const string& value)
      {
        //## begin IF::Extract::setAlias%468A3C9F0148.set preserve=no
        m_strAlias = value;
        //## end IF::Extract::setAlias%468A3C9F0148.set
      }


      //## Attribute: CustomerQualifier%471F4CA6008C
      const string& getCustomerQualifier () const
      {
        //## begin IF::Extract::getCustomerQualifier%471F4CA6008C.get preserve=no
        return m_strCustomerQualifier;
        //## end IF::Extract::getCustomerQualifier%471F4CA6008C.get
      }


      //## Attribute: CUTOFF_TIME%45786A7F0290
      //	End of business day
      const string& getCUTOFF_TIME () const
      {
        //## begin IF::Extract::getCUTOFF_TIME%45786A7F0290.get preserve=no
        return m_strCUTOFF_TIME;
        //## end IF::Extract::getCUTOFF_TIME%45786A7F0290.get
      }

      void setCUTOFF_TIME (const string& value)
      {
        //## begin IF::Extract::setCUTOFF_TIME%45786A7F0290.set preserve=no
        m_strCUTOFF_TIME = value;
        //## end IF::Extract::setCUTOFF_TIME%45786A7F0290.set
      }


      //## Attribute: DatabaseVendor%5442D5860230
      //	Common database qualifier
      const string& getDatabaseVendor () const
      {
        //## begin IF::Extract::getDatabaseVendor%5442D5860230.get preserve=no
        return m_strDatabaseVendor;
        //## end IF::Extract::getDatabaseVendor%5442D5860230.get
      }

      void setDatabaseVendor (const string& value)
      {
        //## begin IF::Extract::setDatabaseVendor%5442D5860230.set preserve=no
        m_strDatabaseVendor = value;
        //## end IF::Extract::setDatabaseVendor%5442D5860230.set
      }


      //## Attribute: Host%3E7C7114031C
      //	Server name
      const string& getHost () const
      {
        //## begin IF::Extract::getHost%3E7C7114031C.get preserve=no
        return m_strHost;
        //## end IF::Extract::getHost%3E7C7114031C.get
      }

      void setHost (const string& value)
      {
        //## begin IF::Extract::setHost%3E7C7114031C.set preserve=no
        m_strHost = value;
        //## end IF::Extract::setHost%3E7C7114031C.set
      }


      //## Attribute: Image%60C1D94903DE
      const string& getImage () const
      {
        //## begin IF::Extract::getImage%60C1D94903DE.get preserve=no
        return m_strImage;
        //## end IF::Extract::getImage%60C1D94903DE.get
      }

      void setImage (const string& value)
      {
        //## begin IF::Extract::setImage%60C1D94903DE.set preserve=no
        m_strImage = value;
        //## end IF::Extract::setImage%60C1D94903DE.set
      }


      //## Attribute: Name%3ABC940500E6
      //	Service name
      const string& getName () const
      {
        //## begin IF::Extract::getName%3ABC940500E6.get preserve=no
        return m_strName;
        //## end IF::Extract::getName%3ABC940500E6.get
      }


      //## Attribute: Node001%3E6DD6DB00BB
      //	File system
      const string& getNode001 () const
      {
        //## begin IF::Extract::getNode001%3E6DD6DB00BB.get preserve=no
        return m_strNode001;
        //## end IF::Extract::getNode001%3E6DD6DB00BB.get
      }

      void setNode001 (const string& value)
      {
        //## begin IF::Extract::setNode001%3E6DD6DB00BB.set preserve=no
        m_strNode001 = value;
        //## end IF::Extract::setNode001%3E6DD6DB00BB.set
      }


      //## Attribute: Qualify%3E6DD6FE0138
      //	Common database qualifier
      const string& getQualify () const
      {
        //## begin IF::Extract::getQualify%3E6DD6FE0138.get preserve=no
        return m_strQualify;
        //## end IF::Extract::getQualify%3E6DD6FE0138.get
      }

      void setQualify (const string& value)
      {
        //## begin IF::Extract::setQualify%3E6DD6FE0138.set preserve=no
        m_strQualify = value;
        //## end IF::Extract::setQualify%3E6DD6FE0138.set
      }


      //## Attribute: TargetCount%60C1D9B40325
      const short& getTargetCount () const
      {
        //## begin IF::Extract::getTargetCount%60C1D9B40325.get preserve=no
        return m_siTargetCount;
        //## end IF::Extract::getTargetCount%60C1D9B40325.get
      }


      //## Attribute: TaskType%60C1D98800C3
      //	Service name
      const string& getTaskType () const
      {
        //## begin IF::Extract::getTaskType%60C1D98800C3.get preserve=no
        return m_strTaskType;
        //## end IF::Extract::getTaskType%60C1D98800C3.get
      }


    // Additional Public Declarations
      //## begin IF::Extract%3472FB2202C0.public preserve=yes
      const reusable::string& getPerf() const
      {
         return m_strPerf;
      }
      //## end IF::Extract%3472FB2202C0.public
  protected:
    // Additional Protected Declarations
      //## begin IF::Extract%3472FB2202C0.protected preserve=yes
      //## end IF::Extract%3472FB2202C0.protected

  private:
    // Additional Private Declarations
      //## begin IF::Extract%3472FB2202C0.private preserve=yes
      //## end IF::Extract%3472FB2202C0.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin IF::Extract::Alias%468A3C9F0148.attr preserve=no  public: string {V} 
      string m_strAlias;
      //## end IF::Extract::Alias%468A3C9F0148.attr

      //## Attribute: CustomCode%47B5D6D802D2
      //	File system
      //## begin IF::Extract::CustomCode%47B5D6D802D2.attr preserve=no  public: string[2] {V} 
      string m_strCustomCode[2];
      //## end IF::Extract::CustomCode%47B5D6D802D2.attr

      //## begin IF::Extract::CustomerQualifier%471F4CA6008C.attr preserve=no  public: string {V} "CUSTQUAL"
      string m_strCustomerQualifier;
      //## end IF::Extract::CustomerQualifier%471F4CA6008C.attr

      //## Attribute: Customers%46404762029A
      //## begin IF::Extract::Customers%46404762029A.attr preserve=no  private: set<string, less<string> > {U} 
      set<string, less<string> > m_hCustomers;
      //## end IF::Extract::Customers%46404762029A.attr

      //## begin IF::Extract::CUTOFF_TIME%45786A7F0290.attr preserve=no  public: string {V} 
      string m_strCUTOFF_TIME;
      //## end IF::Extract::CUTOFF_TIME%45786A7F0290.attr

      //## begin IF::Extract::DatabaseVendor%5442D5860230.attr preserve=no  public: string {V} 
      string m_strDatabaseVendor;
      //## end IF::Extract::DatabaseVendor%5442D5860230.attr

      //## begin IF::Extract::Host%3E7C7114031C.attr preserve=no  public: string {V} 
      string m_strHost;
      //## end IF::Extract::Host%3E7C7114031C.attr

      //## begin IF::Extract::Image%60C1D94903DE.attr preserve=no  public: string {V} 
      string m_strImage;
      //## end IF::Extract::Image%60C1D94903DE.attr

      //## Attribute: Instance%3472FB800117
      //	A pointer to the one-and-only instance of Extract
      //## begin IF::Extract::Instance%3472FB800117.attr preserve=no  private: static Extract* {U} 0
      static Extract* m_pInstance;
      //## end IF::Extract::Instance%3472FB800117.attr

      //## begin IF::Extract::Name%3ABC940500E6.attr preserve=no  public: string {V} 
      string m_strName;
      //## end IF::Extract::Name%3ABC940500E6.attr

      //## begin IF::Extract::Node001%3E6DD6DB00BB.attr preserve=no  public: string {V} 
      string m_strNode001;
      //## end IF::Extract::Node001%3E6DD6DB00BB.attr

      //## begin IF::Extract::Qualify%3E6DD6FE0138.attr preserve=no  public: string {V} 
      string m_strQualify;
      //## end IF::Extract::Qualify%3E6DD6FE0138.attr

      //## begin IF::Extract::TargetCount%60C1D9B40325.attr preserve=no  public: short {U} 1
      short m_siTargetCount;
      //## end IF::Extract::TargetCount%60C1D9B40325.attr

      //## begin IF::Extract::TaskType%60C1D98800C3.attr preserve=no  public: string {V} 
      string m_strTaskType;
      //## end IF::Extract::TaskType%60C1D98800C3.attr

    // Additional Implementation Declarations
      //## begin IF::Extract%3472FB2202C0.implementation preserve=yes
      vector<string> m_hRecords;
      map<string,string,less <string> > m_hAddressSpace;
      map<string,string,less <string> > m_hHost;
      map<string,string,less <string> > m_hPort;
      string m_strPerf;
      //## end IF::Extract%3472FB2202C0.implementation
};

//## begin IF::Extract%3472FB2202C0.postscript preserve=yes
//## end IF::Extract%3472FB2202C0.postscript

} // namespace IF

//## begin module%36266F4D02E5.epilog preserve=yes
using namespace IF;
//## end module%36266F4D02E5.epilog


#endif
