//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%37FA1234001D.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%37FA1234001D.cm

//## begin module%37FA1234001D.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%37FA1234001D.cp

//## Module: CXOSIF25%37FA1234001D; Package body
//## Subsystem: IFDLL%3597E8E8030E
//	.
//## Source file: C:\Pvcswork\Dn\Server\Library\IFDLL\CXOSIF25.cpp

//## begin module%37FA1234001D.additionalIncludes preserve=no
//## end module%37FA1234001D.additionalIncludes

//## begin module%37FA1234001D.includes preserve=yes
#ifdef _WIN32
#include <windows.h>
#endif
#ifdef _UNIX
#include <unistd.h>
#endif
#include <memory.h>
//## end module%37FA1234001D.includes

#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
//## begin module%37FA1234001D.declarations preserve=no
//## end module%37FA1234001D.declarations

//## begin module%37FA1234001D.additionalDeclarations preserve=yes
#ifdef MVS
extern "OS"
{
int CXWTMR(const char* psInterval,int* plRC);
}
#endif
//## end module%37FA1234001D.additionalDeclarations


//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

// Class IF::Sleep

Sleep::Sleep()
  //## begin Sleep::Sleep%37FA11530146_const.hasinit preserve=no
  //## end Sleep::Sleep%37FA11530146_const.hasinit
  //## begin Sleep::Sleep%37FA11530146_const.initialization preserve=yes
  //## end Sleep::Sleep%37FA11530146_const.initialization
{
  //## begin IF::Sleep::Sleep%37FA11530146_const.body preserve=yes
   memcpy(m_sID,"IF25",4);
  //## end IF::Sleep::Sleep%37FA11530146_const.body
}


Sleep::~Sleep()
{
  //## begin IF::Sleep::~Sleep%37FA11530146_dest.body preserve=yes
  //## end IF::Sleep::~Sleep%37FA11530146_dest.body
}



//## Other Operations (implementation)
void Sleep::goTo (const char* psInterval)
{
  //## begin IF::Sleep::goTo%38514E2E022F.body preserve=yes
   int lRC;
#ifdef MVS
   CXWTMR(psInterval,&lRC);
#else
#ifdef _WIN64
      long long lMilliseconds = 0;
#else
      long lMilliseconds = 0;
#endif
      char sInterval[16] = { "000000000000000" };
      int i = (int)strlen(psInterval);
      if (i > 15)
         i = 15;
      memcpy_s(sInterval,16,psInterval,i);
#ifdef _UNIX
      long lNanoseconds = atoi(sInterval + 8);
#endif
      sInterval[8] = 0;
      i = atoi(sInterval + 6);
      lMilliseconds = (i * 10);
      sInterval[6] = 0;
      i = atoi(sInterval + 4);
      lMilliseconds += (i * 1000);
      sInterval[4] = 0;
      i = atoi(sInterval + 2);
      lMilliseconds += (i * 60000);
      sInterval[2] = 0;
      i = atoi(sInterval);
      lMilliseconds += (i * 1440000);
#ifdef _WIN32
      SleepEx(lMilliseconds,false);
#else
      struct timespec timeOut;
      timeOut.tv_sec = 0;
      timeOut.tv_nsec = (lMilliseconds * 1000000) + lNanoseconds;
      long lSeconds = lMilliseconds / 1000;
      sleep(lSeconds);
#endif
#endif
  //## end IF::Sleep::goTo%38514E2E022F.body
}

// Additional Declarations
  //## begin IF::Sleep%37FA11530146.declarations preserve=yes
  //## end IF::Sleep%37FA11530146.declarations

} // namespace IF

//## begin module%37FA1234001D.epilog preserve=yes
//## end module%37FA1234001D.epilog
