//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5AE06E52023F.cm preserve=no
//## end module%5AE06E52023F.cm

//## begin module%5AE06E52023F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5AE06E52023F.cp

//## Module: CXOSIF82%5AE06E52023F; Package specification
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Ifdll\CXODIF82.hpp

#ifndef CXOSIF82_h
#define CXOSIF82_h 1

//## begin module%5AE06E52023F.additionalIncludes preserve=no
//## end module%5AE06E52023F.additionalIncludes

//## begin module%5AE06E52023F.includes preserve=yes
//## end module%5AE06E52023F.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
class Extract;

} // namespace IF

//## begin module%5AE06E52023F.declarations preserve=no
//## end module%5AE06E52023F.declarations

//## begin module%5AE06E52023F.additionalDeclarations preserve=yes
//## end module%5AE06E52023F.additionalDeclarations


namespace IF {
//## begin IF%3451F55F009E.initialDeclarations preserve=yes
//## end IF%3451F55F009E.initialDeclarations

//## begin IF::Trace_i%5AE06DE902A8.preface preserve=yes
//## end IF::Trace_i%5AE06DE902A8.preface

//## Class: Trace_i%5AE06DE902A8
//## Category: Connex Library::IF_CAT%3451F55F009E
//## Subsystem: Connex Library::IFDLL%3597E8E8030E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5AE074B60183;Extract { -> F}

class DllExport Trace_i : public reusable::Object  //## Inherits: <unnamed>%5AE06E2A01CD
{
  //## begin IF::Trace_i%5AE06DE902A8.initialDeclarations preserve=yes
  //## end IF::Trace_i%5AE06DE902A8.initialDeclarations

  public:
    //## Constructors (generated)
      Trace_i();

      Trace_i(const Trace_i &right);

    //## Destructor (generated)
      virtual ~Trace_i();

    //## Assignment Operation (generated)
      Trace_i & operator=(const Trace_i &right);


    //## Other Operations (specified)
      //## Operation: flush%5AE06F6F0155
      void flush (bool bClearMask = false);

      //## Operation: getEnable%5AE06F6F0173
      static const bool getEnable ();

      //## Operation: holdBuffers%5AE06F6F018D
      static void holdBuffers ();

      //## Operation: initialize%6509F486002B
      void initialize ();

      //## Operation: purgeTraceBuffer%5AE06F6F019D
      void purgeTraceBuffer ();

      //## Operation: put%5AE06F6F019E
      //	Put a entry in the trace file.
      //## Semantics:
      //	1. Call CXWTR.
      void put (const char* pszFile, unsigned int ulLine, const char* psBuffer, size_t lBuffer = -1);

      //## Operation: put%5AE06F6F01AC
      //	Put an entry in the trace file.
      //## Semantics:
      //	1. Call CXWTR.
      void put (const char* psBuffer, size_t lBuffer = -1);

      //## Operation: put%5AE06F6F01BC
      void put (const char* pszText, const string& strBuffer);

      //## Operation: putHex%5AE06F6F01CC
      //	Put an entry in the trace file.
      //## Semantics:
      //	1. Call CXWTR.
      void putHex (const char* psBuffer, int lBuffer = -1);

      //## Operation: releaseBuffers%5AE06F6F01DB
      void releaseBuffers (bool bHold = false);

      //## Operation: terminate%5AE06F6F01EB
      void terminate ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Enable%5AE06F9402A4
      static void setEnable (bool value);

      //## Attribute: Template%6509F51E031A
      static const string& getTemplate ()
      {
        //## begin IF::Trace_i::getTemplate%6509F51E031A.get preserve=no
        return m_strTemplate;
        //## end IF::Trace_i::getTemplate%6509F51E031A.get
      }


    // Additional Public Declarations
      //## begin IF::Trace_i%5AE06DE902A8.public preserve=yes
      //## end IF::Trace_i%5AE06DE902A8.public

  protected:
    // Additional Protected Declarations
      //## begin IF::Trace_i%5AE06DE902A8.protected preserve=yes
      //## end IF::Trace_i%5AE06DE902A8.protected

  private:

    //## Other Operations (specified)
      //## Operation: addBuffer%5AE06F6F012F
      //	Put an entry in the trace file.
      //## Semantics:
      //	1. Call CXWTR.
      void addBuffer (const char* psBuffer, size_t lBuffer = -1, short siBufType = 0);

      //## Operation: flushHex%5AE06F6F015E
      void flushHex (const char* pszBuffer, unsigned int ulBuffer);

      //## Operation: flushTrace%5AE06F6F0161
      void flushTrace (const char* pszBuffer, unsigned int ulBuffer, bool bFlush = false);

      //## Operation: formatHex%5AE06F6F016E
      void formatHex (const char* pInBuffer, char* pOutBuffer, int iOffset, unsigned int ulBuffer);

    // Additional Private Declarations
      //## begin IF::Trace_i%5AE06DE902A8.private preserve=yes
      //## end IF::Trace_i%5AE06DE902A8.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin IF::Trace_i::Enable%5AE06F9402A4.attr preserve=no  public: static bool {V} false
      static bool m_bEnable;
      //## end IF::Trace_i::Enable%5AE06F9402A4.attr

      //## Attribute: Hold%5AE06F9402B4
      //## begin IF::Trace_i::Hold%5AE06F9402B4.attr preserve=no  public: static bool {V} false
      static bool m_bHold;
      //## end IF::Trace_i::Hold%5AE06F9402B4.attr

      //## Attribute: Lock%5AE06F9402C3
      //## begin IF::Trace_i::Lock%5AE06F9402C3.attr preserve=no  public: static bool {V} false
      static bool m_bLock;
      //## end IF::Trace_i::Lock%5AE06F9402C3.attr

      //## Attribute: MaxSize%5F11E15C02FE
      //## begin IF::Trace_i::MaxSize%5F11E15C02FE.attr preserve=no  private: double {V} 0
      double m_dMaxSize;
      //## end IF::Trace_i::MaxSize%5F11E15C02FE.attr

      //## begin IF::Trace_i::Template%6509F51E031A.attr preserve=no  public: static string {U} 
      static string m_strTemplate;
      //## end IF::Trace_i::Template%6509F51E031A.attr

      //## Attribute: TotalBytes%5F11E13E0010
      //## begin IF::Trace_i::TotalBytes%5F11E13E0010.attr preserve=no  private: double {V} 0
      double m_dTotalBytes;
      //## end IF::Trace_i::TotalBytes%5F11E13E0010.attr

    // Data Members for Associations

      //## Association: Connex Library::IF_CAT::<unnamed>%5AE08446037A
      //## Role: Trace_i::<m_pFlatFile>%5AE0844702BE
      //## begin IF::Trace_i::<m_pFlatFile>%5AE0844702BE.role preserve=no  public: IF::FlatFile { -> RFHgN}
      FlatFile *m_pFlatFile;
      //## end IF::Trace_i::<m_pFlatFile>%5AE0844702BE.role

    // Additional Implementation Declarations
      //## begin IF::Trace_i%5AE06DE902A8.implementation preserve=yes
      //## end IF::Trace_i%5AE06DE902A8.implementation

};

//## begin IF::Trace_i%5AE06DE902A8.postscript preserve=yes
//## end IF::Trace_i%5AE06DE902A8.postscript

} // namespace IF

//## begin module%5AE06E52023F.epilog preserve=yes
//## end module%5AE06E52023F.epilog


#endif
