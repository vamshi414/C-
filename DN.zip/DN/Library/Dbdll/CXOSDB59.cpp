//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5ADF367102A0.cm preserve=no
//	$Date:   Jan 03 2019 10:45:56  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%5ADF367102A0.cm

//## begin module%5ADF367102A0.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5ADF367102A0.cp

//## Module: CXOSDB59%5ADF367102A0; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB59.cpp

//## begin module%5ADF367102A0.additionalIncludes preserve=no
//## end module%5ADF367102A0.additionalIncludes

//## begin module%5ADF367102A0.includes preserve=yes
//## end module%5ADF367102A0.includes

#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU07_h
#include "CXODRU07.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB59_h
#include "CXODDB59.hpp"
#endif


//## begin module%5ADF367102A0.declarations preserve=no
//## end module%5ADF367102A0.declarations

//## begin module%5ADF367102A0.additionalDeclarations preserve=yes
//## end module%5ADF367102A0.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::RowVisitor

RowVisitor::RowVisitor (const string& strRow)
  //## begin database::RowVisitor::RowVisitor%5ADF374F027D.hasinit preserve=no
      : m_iIndex(0)
  //## end database::RowVisitor::RowVisitor%5ADF374F027D.hasinit
  //## begin database::RowVisitor::RowVisitor%5ADF374F027D.initialization preserve=yes
   ,m_strRow(strRow)
  //## end database::RowVisitor::RowVisitor%5ADF374F027D.initialization
{
  //## begin database::RowVisitor::RowVisitor%5ADF374F027D.body preserve=yes
   memcpy(m_sID,"DB59",4);
  //## end database::RowVisitor::RowVisitor%5ADF374F027D.body
}


RowVisitor::~RowVisitor()
{
  //## begin database::RowVisitor::~RowVisitor%5ADF34FB006D_dest.body preserve=yes
  //## end database::RowVisitor::~RowVisitor%5ADF34FB006D_dest.body
}



//## Other Operations (implementation)
void RowVisitor::visitColumn (reusable::Table* pTable, Column* pColumn)
{
  //## begin database::RowVisitor::visitColumn%5ADF353000A5.body preserve=yes
   short iNull = m_strRow[m_iIndex] == 'N' ? 0 : -1;
   ++m_iIndex;
   short iSize = 0;
   memcpy((void*)&iSize,m_strRow.data() + m_iIndex,2);
   m_iIndex += 2;
   void* pValue = (void*)(m_strRow.data() + m_iIndex);
   m_iIndex += iSize;
   ++m_iIndex;
   pColumn->setValue(Column::STRING,iSize,pValue,iNull);
  //## end database::RowVisitor::visitColumn%5ADF353000A5.body
}

void RowVisitor::visitQuery (Query* pQuery)
{
  //## begin database::RowVisitor::visitQuery%5ADF35320346.body preserve=yes
   m_iIndex = 0;
  //## end database::RowVisitor::visitQuery%5ADF35320346.body
}

void RowVisitor::visitTable (Table* pTable)
{
  //## begin database::RowVisitor::visitTable%5ADF353403BF.body preserve=yes
  //## end database::RowVisitor::visitTable%5ADF353403BF.body
}

// Additional Declarations
  //## begin database::RowVisitor%5ADF34FB006D.declarations preserve=yes
  //## end database::RowVisitor%5ADF34FB006D.declarations

} // namespace database

//## begin module%5ADF367102A0.epilog preserve=yes
//## end module%5ADF367102A0.epilog
