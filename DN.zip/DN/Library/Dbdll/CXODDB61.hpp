//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C06E02E0153.cm preserve=no
//	$Date:   Jun 12 2019 07:57:30  $ $Author:   e1009839  $
//	$Revision:   1.3  $
//## end module%5C06E02E0153.cm

//## begin module%5C06E02E0153.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C06E02E0153.cp

//## Module: CXOSDB61%5C06E02E0153; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB61.hpp

#ifndef CXOSDB61_h
#define CXOSDB61_h 1

//## begin module%5C06E02E0153.additionalIncludes preserve=no
//## end module%5C06E02E0153.additionalIncludes

//## begin module%5C06E02E0153.includes preserve=yes
//## end module%5C06E02E0153.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CriticalSection;
class Thread;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Sleep;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%5C06E02E0153.declarations preserve=no
//## end module%5C06E02E0153.declarations

//## begin module%5C06E02E0153.additionalDeclarations preserve=yes
//## end module%5C06E02E0153.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Delegate%5C06DEED0051.preface preserve=yes
//## end database::Delegate%5C06DEED0051.preface

//## Class: Delegate%5C06DEED0051
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5C06E2CE0059;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%5C06E35A00E0;IF::Sleep { -> F}
//## Uses: <unnamed>%5C0FF2C900D1;reusable::Thread { -> F}
//## Uses: <unnamed>%5C1134E0025C;Database { -> F}

class DllExport Delegate : public reusable::Object  //## Inherits: <unnamed>%5C06DFE80129
{
  //## begin database::Delegate%5C06DEED0051.initialDeclarations preserve=yes
  public:
      enum State
      {
         IDLE,
         COMMITREQUIRED,
         ROLLBACKREQUIRED,
         COMMIT,
         ROLLBACK
      };
  //## end database::Delegate%5C06DEED0051.initialDeclarations

  public:
    //## Constructors (generated)
      Delegate();

      Delegate(const Delegate &right);

    //## Destructor (generated)
      virtual ~Delegate();

    //## Assignment Operation (generated)
      Delegate & operator=(const Delegate &right);


    //## Other Operations (specified)
      //## Operation: addThread%5C06E0DB02D8
      int addThread ();

      //## Operation: busy%5C06E0DF01E1
      bool busy ();

      //## Operation: commit%5C06E0E20398
      void commit (const reusable::string& strCONTEXT_DATA);

      //## Operation: execute%5C06F06902A6
      virtual void execute (vector<Object*>& hObject);

      //## Operation: getActive%5C2CD6F90314
      bool getActive (int iThread);

      //## Operation: getFirst%5C06E0E60302
      Delegate* getFirst (int iThread);

      //## Operation: getLast%5C06E0E902B0
      Delegate* getLast (int iThread);

      //## Operation: getState%5C0ED800036A
      Delegate::State getState ();

      //## Operation: getState%5C06E0EC0161
      Delegate::State getState (int iThread);

      //## Operation: instance%5C0FE7610318
      static Delegate* instance (int iNumber);

      //## Operation: pop%5C06ECB70183
      bool pop (int iThread, vector<Object*>& hObject);

      //## Operation: push%5C06EB7003E0
      void push (int iThread, Delegate* pDelegate);

      //## Operation: rollback%5C06E0EF018B
      void rollback ();

      //## Operation: setActive%5C2CD704030D
      void setActive (int iThread, bool bActive);

      //## Operation: setFirst%5C06E0F201F1
      void setFirst (int iThread, Delegate* pDelegate);

      //## Operation: setLast%5C06E0F502A9
      void setLast (int iThread, Delegate* pDelegate);

      //## Operation: setState%5C06E0F802D1
      void setState (int iThread, Delegate::State nState);

      //## Operation: wait%5C06E0FD00C1
      void wait ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: CONTEXT_DATA%5D00F2630037
      const reusable::string& getCONTEXT_DATA () const
      {
        //## begin database::Delegate::getCONTEXT_DATA%5D00F2630037.get preserve=no
        return m_strCONTEXT_DATA;
        //## end database::Delegate::getCONTEXT_DATA%5D00F2630037.get
      }

      void setCONTEXT_DATA (const reusable::string& value)
      {
        //## begin database::Delegate::setCONTEXT_DATA%5D00F2630037.set preserve=no
        m_strCONTEXT_DATA = value;
        //## end database::Delegate::setCONTEXT_DATA%5D00F2630037.set
      }


      //## Attribute: CONTEXT_KEY%5CFFB5850035
      const reusable::string& getCONTEXT_KEY () const
      {
        //## begin database::Delegate::getCONTEXT_KEY%5CFFB5850035.get preserve=no
        return m_strCONTEXT_KEY;
        //## end database::Delegate::getCONTEXT_KEY%5CFFB5850035.get
      }

      void setCONTEXT_KEY (const reusable::string& value)
      {
        //## begin database::Delegate::setCONTEXT_KEY%5CFFB5850035.set preserve=no
        m_strCONTEXT_KEY = value;
        //## end database::Delegate::setCONTEXT_KEY%5CFFB5850035.set
      }


      //## Attribute: Quiesce%5C2E196C009A
      const bool getQuiesce () const
      {
        //## begin database::Delegate::getQuiesce%5C2E196C009A.get preserve=no
        return m_bQuiesce;
        //## end database::Delegate::getQuiesce%5C2E196C009A.get
      }

      void setQuiesce (bool value)
      {
        //## begin database::Delegate::setQuiesce%5C2E196C009A.set preserve=no
        m_bQuiesce = value;
        //## end database::Delegate::setQuiesce%5C2E196C009A.set
      }


      //## Attribute: Threads%5C06E11001C8
      const int getThreads () const;

    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::Database_CAT::<unnamed>%5C06E1CF02ED
      //## Role: Delegate::<m_pNext>%5C06E1D002B9
      Delegate * getNext ()
      {
        //## begin database::Delegate::getNext%5C06E1D002B9.get preserve=no
        return m_pNext;
        //## end database::Delegate::getNext%5C06E1D002B9.get
      }

      void setNext (Delegate * value)
      {
        //## begin database::Delegate::setNext%5C06E1D002B9.set preserve=no
        m_pNext = value;
        //## end database::Delegate::setNext%5C06E1D002B9.set
      }


    // Additional Public Declarations
      //## begin database::Delegate%5C06DEED0051.public preserve=yes
      //## end database::Delegate%5C06DEED0051.public

  protected:
    // Additional Protected Declarations
      //## begin database::Delegate%5C06DEED0051.protected preserve=yes
      //## end database::Delegate%5C06DEED0051.protected

  private:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Number%5C0FECCC0296
      const int getNumber () const
      {
        //## begin database::Delegate::getNumber%5C0FECCC0296.get preserve=no
        return m_iNumber;
        //## end database::Delegate::getNumber%5C0FECCC0296.get
      }

      void setNumber (int value)
      {
        //## begin database::Delegate::setNumber%5C0FECCC0296.set preserve=no
        m_iNumber = value;
        //## end database::Delegate::setNumber%5C0FECCC0296.set
      }


    // Additional Private Declarations
      //## begin database::Delegate%5C06DEED0051.private preserve=yes
      //## end database::Delegate%5C06DEED0051.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Active%5C2CD6C1007D
      //## begin database::Delegate::Active%5C2CD6C1007D.attr preserve=no  public: vector<bool>* {V} 0
      vector<bool>* m_pActive;
      //## end database::Delegate::Active%5C2CD6C1007D.attr

      //## begin database::Delegate::CONTEXT_DATA%5D00F2630037.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strCONTEXT_DATA;
      //## end database::Delegate::CONTEXT_DATA%5D00F2630037.attr

      //## begin database::Delegate::CONTEXT_KEY%5CFFB5850035.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strCONTEXT_KEY;
      //## end database::Delegate::CONTEXT_KEY%5CFFB5850035.attr

      //## Attribute: First%5C06E5DB01F1
      //## begin database::Delegate::First%5C06E5DB01F1.attr preserve=no  public: vector<Delegate*>* {V} 0
      vector<Delegate*>* m_pFirst;
      //## end database::Delegate::First%5C06E5DB01F1.attr

      //## Attribute: Instance%5C0FEC8A0340
      //## begin database::Delegate::Instance%5C0FEC8A0340.attr preserve=no  private: static vector<Delegate*>* {V} 0
      static vector<Delegate*>* m_pInstance;
      //## end database::Delegate::Instance%5C0FEC8A0340.attr

      //## Attribute: Last%5C06E60403E5
      //## begin database::Delegate::Last%5C06E60403E5.attr preserve=no  public: vector<Delegate*>* {V} 0
      vector<Delegate*>* m_pLast;
      //## end database::Delegate::Last%5C06E60403E5.attr

      //## begin database::Delegate::Number%5C0FECCC0296.attr preserve=no  private: int {V} 0
      int m_iNumber;
      //## end database::Delegate::Number%5C0FECCC0296.attr

      //## begin database::Delegate::Quiesce%5C2E196C009A.attr preserve=no  public: bool {V} false
      bool m_bQuiesce;
      //## end database::Delegate::Quiesce%5C2E196C009A.attr

      //## Attribute: State%5C06E10C0338
      //## begin database::Delegate::State%5C06E10C0338.attr preserve=no  public: vector<Delegate::State>* {V} 0
      vector<Delegate::State>* m_pState;
      //## end database::Delegate::State%5C06E10C0338.attr

      //## begin database::Delegate::Threads%5C06E11001C8.attr preserve=no  public: int {V} 0
      int m_iThreads;
      //## end database::Delegate::Threads%5C06E11001C8.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%5C06E1CF02ED
      //## begin database::Delegate::<m_pNext>%5C06E1D002B9.role preserve=no  public: database::Delegate { -> RFHgN}
      Delegate *m_pNext;
      //## end database::Delegate::<m_pNext>%5C06E1D002B9.role

    // Additional Implementation Declarations
      //## begin database::Delegate%5C06DEED0051.implementation preserve=yes
      //## end database::Delegate%5C06DEED0051.implementation

};

//## begin database::Delegate%5C06DEED0051.postscript preserve=yes
//## end database::Delegate%5C06DEED0051.postscript

} // namespace database

//## begin module%5C06E02E0153.epilog preserve=yes
//## end module%5C06E02E0153.epilog


#endif
