//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4AFD733000FD.cm preserve=no
//	$Date:   Jul 31 2015 10:45:06  $ $Author:   e1009652  $ $Revision:   1.3  $
//## end module%4AFD733000FD.cm

//## begin module%4AFD733000FD.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%4AFD733000FD.cp

//## Module: CXOSDB38%4AFD733000FD; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB38.cpp

//## begin module%4AFD733000FD.additionalIncludes preserve=no
//## end module%4AFD733000FD.additionalIncludes

//## begin module%4AFD733000FD.includes preserve=yes
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
//## end module%4AFD733000FD.includes

#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
#ifndef CXOSDB38_h
#include "CXODDB38.hpp"
#endif


//## begin module%4AFD733000FD.declarations preserve=no
//## end module%4AFD733000FD.declarations

//## begin module%4AFD733000FD.additionalDeclarations preserve=yes
//## end module%4AFD733000FD.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::TransportKey 

TransportKey::TransportKey()
  //## begin TransportKey::TransportKey%4AFD72DF00A8_const.hasinit preserve=no
  //## end TransportKey::TransportKey%4AFD72DF00A8_const.hasinit
  //## begin TransportKey::TransportKey%4AFD72DF00A8_const.initialization preserve=yes
  //## end TransportKey::TransportKey%4AFD72DF00A8_const.initialization
{
  //## begin database::TransportKey::TransportKey%4AFD72DF00A8_const.body preserve=yes
   memcpy(m_sID,"DB38",4);
  //## end database::TransportKey::TransportKey%4AFD72DF00A8_const.body
}


TransportKey::~TransportKey()
{
  //## begin database::TransportKey::~TransportKey%4AFD72DF00A8_dest.body preserve=yes
  //## end database::TransportKey::~TransportKey%4AFD72DF00A8_dest.body
}



//## Other Operations (implementation)
bool TransportKey::decrypt (string& strText)
{
  //## begin database::TransportKey::decrypt%4AFD73D70272.body preserve=yes
   //decryption of keys uses ecb mode instead of cbc mode used for data.
   //calling cbc 8 bytes a time is essentially the same thing as using ecb mode.
   //because we use an initvector of all hex 0's.
   if(strText.length() == 32)
   {
      unsigned char szKey[16];
      CodeTable::byteToNibble(strText,szKey);
      strText.assign((char*)szKey,16);
   }
   if(strText.length() != 16)
      return false;
   string strTemp1(strText.data(),8);
   if(!crypt(strTemp1,8,DES_DECRYPT))
      return false;
   string strTemp2(strText.data()+8,8);
   if(!crypt(strTemp2,8,DES_DECRYPT))
      return false;
   strText = strTemp1 + strTemp2;
   return true;
  //## end database::TransportKey::decrypt%4AFD73D70272.body
}

bool TransportKey::encrypt (string& strText)
{
  //## begin database::TransportKey::encrypt%4AFD73D7027C.body preserve=yes
   //encryption of keys uses ecb mode instead of cbc mode used for data.
   //calling cbc 8 bytes a time is essentially the same thing as using ecb mode.
   //because we use an initvector of all hex 0's.
   if(strText.length() == 8)
      return DESKey::encrypt(strText); //check digits
   if(strText.length() == 32)
   {
      unsigned char szKey[16];
      CodeTable::byteToNibble(strText,szKey);
      strText.assign((char*)szKey,16);
   }
   if(strText.length() != 16)
      return false;
   string strTemp1(strText.data(),8);
   if(!crypt(strTemp1,8,DES_ENCRYPT))
      return false;
   string strTemp2(strText.data()+8,8);
   if(!crypt(strTemp2,8,DES_ENCRYPT))
      return false;
   strText = strTemp1 + strTemp2;
   return true;
  //## end database::TransportKey::encrypt%4AFD73D7027C.body
}

// Additional Declarations
  //## begin database::TransportKey%4AFD72DF00A8.declarations preserve=yes
  //## end database::TransportKey%4AFD72DF00A8.declarations

} // namespace database

//## begin module%4AFD733000FD.epilog preserve=yes
//## end module%4AFD733000FD.epilog
