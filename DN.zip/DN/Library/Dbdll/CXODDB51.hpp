//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5480B43C03D0.cm preserve=no
//	$Date:   Dec 18 2014 15:02:38  $ $Author:   e1009510  $ $Revision:   1.0  $
//## end module%5480B43C03D0.cm

//## begin module%5480B43C03D0.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5480B43C03D0.cp

//## Module: CXODDB51%5480B43C03D0; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB51.hpp

#ifndef CXODDB51_h
#define CXODDB51_h 1

//## begin module%5480B43C03D0.additionalIncludes preserve=no
//## end module%5480B43C03D0.additionalIncludes

//## begin module%5480B43C03D0.includes preserve=yes
//## end module%5480B43C03D0.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%5480B43C03D0.declarations preserve=no
//## end module%5480B43C03D0.declarations

//## begin module%5480B43C03D0.additionalDeclarations preserve=yes
//## end module%5480B43C03D0.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Column%5480B4C40180.preface preserve=yes
//## end database::Column%5480B4C40180.preface

//## Class: Column%5480B4C40180
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport Column : public reusable::Object  //## Inherits: <unnamed>%5480B4D2039E
{
  //## begin database::Column%5480B4C40180.initialDeclarations preserve=yes
  //## end database::Column%5480B4C40180.initialDeclarations

  public:
    //## Constructors (generated)
      Column();

      Column(const Column &right);

    //## Constructors (specified)
      //## Operation: Column%5480B63E00D4
      Column (const string& strTable, const string& strColumn, int iNPI);

    //## Destructor (generated)
      virtual ~Column();

    //## Assignment Operation (generated)
      Column & operator=(const Column &right);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Column%5480B5FD015A
      const string& getColumn () const
      {
        //## begin database::Column::getColumn%5480B5FD015A.get preserve=no
        return m_strColumn;
        //## end database::Column::getColumn%5480B5FD015A.get
      }


      //## Attribute: NPI%5480B60801D6
      const int& getNPI () const
      {
        //## begin database::Column::getNPI%5480B60801D6.get preserve=no
        return m_iNPI;
        //## end database::Column::getNPI%5480B60801D6.get
      }


      //## Attribute: Table%5480B5CB02D2
      const string& getTable () const
      {
        //## begin database::Column::getTable%5480B5CB02D2.get preserve=no
        return m_strTable;
        //## end database::Column::getTable%5480B5CB02D2.get
      }


    // Additional Public Declarations
      //## begin database::Column%5480B4C40180.public preserve=yes
      //## end database::Column%5480B4C40180.public

  protected:
    // Additional Protected Declarations
      //## begin database::Column%5480B4C40180.protected preserve=yes
      //## end database::Column%5480B4C40180.protected

  private:
    // Additional Private Declarations
      //## begin database::Column%5480B4C40180.private preserve=yes
      //## end database::Column%5480B4C40180.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin database::Column::Column%5480B5FD015A.attr preserve=no  public: string {U} 
      string m_strColumn;
      //## end database::Column::Column%5480B5FD015A.attr

      //## begin database::Column::NPI%5480B60801D6.attr preserve=no  public: int {U} 0
      int m_iNPI;
      //## end database::Column::NPI%5480B60801D6.attr

      //## begin database::Column::Table%5480B5CB02D2.attr preserve=no  public: string {U} 
      string m_strTable;
      //## end database::Column::Table%5480B5CB02D2.attr

    // Additional Implementation Declarations
      //## begin database::Column%5480B4C40180.implementation preserve=yes
      //## end database::Column%5480B4C40180.implementation

};

//## begin database::Column%5480B4C40180.postscript preserve=yes
//## end database::Column%5480B4C40180.postscript

} // namespace database

//## begin module%5480B43C03D0.epilog preserve=yes
//## end module%5480B43C03D0.epilog


#endif
