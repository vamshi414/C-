//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6490C66800B5.cm preserve=no
//## end module%6490C66800B5.cm

//## begin module%6490C66800B5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6490C66800B5.cp

//## Module: CXODDB70%6490C66800B5; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB70.cpp

//## begin module%6490C66800B5.additionalIncludes preserve=no
//## end module%6490C66800B5.additionalIncludes

//## begin module%6490C66800B5.includes preserve=yes
#ifndef MVS
#ifdef __cplusplus
extern "C"
{
#include "ptkn.h"
}
#endif
#endif
struct rqst {
   int command;     //tokenize, detokenize
   int base;        //alphabet base � 10 or 62
   int encode;      //encode flag
   int rc;          //response code
   char str[512];   //clear value
   int  str_len;    //clear value length
   char ctx[512];   //context
   int ctx_len;     //context length
   char tkn[512];   //token
   int tkn_len;     //token length, the same value as str_len
   int ofst;        //metadata offset
};
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
//## end module%6490C66800B5.includes

#ifndef CXOSDB65_h
#include "CXODDB65.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXODDB70_h
#include "CXODDB70.hpp"
#endif


//## begin module%6490C66800B5.declarations preserve=no
//## end module%6490C66800B5.declarations

//## begin module%6490C66800B5.additionalDeclarations preserve=yes
//## end module%6490C66800B5.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::PenkoToken 

PenkoToken::PenkoToken()
  //## begin PenkoToken::PenkoToken%6490C6F001B3_const.hasinit preserve=no
      : m_strContextOption("PTKN_TOKEN_CONTEXT"),
        m_strMethodOption("PTKN_TOKEN_METHOD")
  //## end PenkoToken::PenkoToken%6490C6F001B3_const.hasinit
  //## begin PenkoToken::PenkoToken%6490C6F001B3_const.initialization preserve=yes
  //## end PenkoToken::PenkoToken%6490C6F001B3_const.initialization
{
  //## begin database::PenkoToken::PenkoToken%6490C6F001B3_const.body preserve=yes
   memcpy(m_sID, "DB70", 4);
#ifndef MVS
   m_tt.tt = 0;
   m_tt.rt = 0;
   memset(m_tt.pur, ' ', 4);
   m_tt2.tt = 0;
   m_tt2.rt = 0;
   memset(m_tt2.pur, ' ', 4);
#endif
  //## end database::PenkoToken::PenkoToken%6490C6F001B3_const.body
}


PenkoToken::~PenkoToken()
{
  //## begin database::PenkoToken::~PenkoToken%6490C6F001B3_dest.body preserve=yes
#ifndef MVS
   if (memcmp(m_tt.pur, "ttn6", 4) == 0)
      ptknttfree(&m_tt);
   if (memcmp(m_tt2.pur, "tta3", 4) == 0)
      ptknttfree(&m_tt2);
#endif
  //## end database::PenkoToken::~PenkoToken%6490C6F001B3_dest.body
}



//## Other Operations (implementation)
int PenkoToken::deriveContext ()
{
  //## begin database::PenkoToken::deriveContext%64D3EC8D037E.body preserve=yes
   m_strContext.assign(Extract::instance()->getQualify());
   string strContextSave = m_strContext;
   string::iterator p;
   int iLen = m_strContext.length();
   for (int i = 0; i < iLen; i++)
   {
      m_strContext.insert(i, 1, m_strContext.data()[iLen - 1]);
      p = m_strContext.end() - 1;
      m_strContext.erase(p);
   }
   transform(m_strContext.begin(), m_strContext.end(), m_strContext.begin(), ::tolower);
   rqst hRqst;
   memset(&hRqst, '0x00', sizeof(struct rqst));
   memcpy(hRqst.str, m_strContext.data(), m_strContext.length());
   hRqst.str_len = m_strContext.length();
   hRqst.ofst = 0;
   memcpy(hRqst.ctx, strContextSave.data(), strContextSave.length());
   hRqst.ctx_len = strContextSave.length();
#ifndef MVS
   int rc = ptknget(&m_tt2, hRqst.str, hRqst.str_len, hRqst.ctx, hRqst.ctx_len, hRqst.tkn);
   if (rc)
   {
      IF::Trace::put(m_szErrorMsg, sprintf(m_szErrorMsg, "*** deriveContext Error: %d ptknget a3", rc), true);
      return 0;
   }
#endif
   m_strContext.assign(hRqst.tkn, hRqst.str_len); //hRqst.tkn_len is not filled in
   return 1;
  //## end database::PenkoToken::deriveContext%64D3EC8D037E.body
}

int PenkoToken::detokenize (string& strTokenText, const string& strENTITY_ID, const string& strENTITY_TYPE)
{
  //## begin database::PenkoToken::detokenize%64946F4E03DB.body preserve=yes
   short siMethod = getMethod(strENTITY_ID, strENTITY_TYPE);
   if (siMethod < 1 || siMethod > 4)
      siMethod = 1;
   string strContext;
   getContext(strENTITY_ID, strENTITY_TYPE, strContext);
   return detokenize(strTokenText, strContext, siMethod);
  //## end database::PenkoToken::detokenize%64946F4E03DB.body
}

int PenkoToken::detokenize (string& strTokenText, const string& strTokenContext, short siTokenMethod)
{
  //## begin database::PenkoToken::detokenize%6491B5A000C0.body preserve=yes
   if (strTokenText.length() < 6)
      return 0;
   string strContext(strTokenContext);
   int iMiddleDigitsLength = strTokenText.length() - 10;
   int iPrefixLength = 6;
   int iSuffixLength = strTokenText.length() == 15 ? 3 : 4;
   if (strTokenText.length() < 15)
   {
      if (siTokenMethod == 1)
         siTokenMethod = 3;
      else
      if (siTokenMethod == 2)
         siTokenMethod = 4;
   }
   switch (siTokenMethod)
   {
      case 1:
      case 2:
         iMiddleDigitsLength = iMiddleDigitsLength < 6 ? 6 : iMiddleDigitsLength;
         if (strContext != "000000")
         {
            strContext.append(strTokenText.data(), iPrefixLength);
            strContext.append(strTokenText.data() + strTokenText.length() - iSuffixLength, iSuffixLength);
         }
         break;
      case 3:
      case 4:
         iPrefixLength = 0;
         iMiddleDigitsLength = strTokenText.length();
         break;
   }
   rqst hRqst;
   memset(&hRqst, '0x00', sizeof(struct rqst));
   memcpy(hRqst.tkn, strTokenText.data() + iPrefixLength, iMiddleDigitsLength);
   hRqst.tkn_len = iMiddleDigitsLength;
   memcpy(hRqst.ctx, strContext.data(), strContext.length());
   hRqst.ctx_len = strContext.length();
   hRqst.ofst = iMiddleDigitsLength - 3;
   //decode metadata
#ifndef MVS
   int rc = 0;
   if (siTokenMethod == 1 || siTokenMethod == 3)
   {
      rc = ptkndec(m_tt.b, &m_tt.cde, (unsigned char*)hRqst.tkn, hRqst.tkn_len, hRqst.ofst);
      if (rc)
      {
         IF::Trace::put(m_szErrorMsg, sprintf(m_szErrorMsg, "*** Error: %d ptkndec", rc), true);
         return 1;
      }
   }
   // Detokenize
   rc = ptkninv(&m_tt, hRqst.tkn, hRqst.tkn_len, hRqst.ctx, hRqst.ctx_len, hRqst.str);
   if (rc)
   {
      IF::Trace::put(m_szErrorMsg, sprintf(m_szErrorMsg, "*** Error: %d ptkninv", rc), true);
      return 1;
   }
#endif
   strTokenText.replace(iPrefixLength, iMiddleDigitsLength, hRqst.str, iMiddleDigitsLength);
   return 0;
  //## end database::PenkoToken::detokenize%6491B5A000C0.body
}

int PenkoToken::detokenize (string& strTokenText)
{
  //## begin database::PenkoToken::detokenize%64D3EC2E02DC.body preserve=yes
   if (strTokenText.empty() || strTokenText.data()[0] != '~')
      return 0;
   else
      strTokenText.erase(0, 1);
   rqst hRqst;
   memset(&hRqst, '0x00', sizeof(struct rqst));
   memcpy(hRqst.tkn, strTokenText.data(), strTokenText.length());
   hRqst.tkn_len = strTokenText.length();
   hRqst.ofst = 0;
   memcpy(hRqst.ctx, m_strContext.data(), m_strContext.length());
   hRqst.ctx_len = m_strContext.length();
#ifndef MVS
   int rc = ptkninv(&m_tt2, hRqst.tkn, hRqst.tkn_len, hRqst.ctx, hRqst.ctx_len, hRqst.str);
   if (rc)
   {
      IF::Trace::put(m_szErrorMsg, sprintf(m_szErrorMsg, "*** Error: %d ptkninv a3", rc), true);
      return 1;
   }
#endif
   strTokenText.assign(hRqst.str, hRqst.tkn_len);
   strTokenText.append(" ");
   return 0;
  //## end database::PenkoToken::detokenize%64D3EC2E02DC.body
}

void PenkoToken::getContext (const string& strENTITY_ID, const string& strENTITY_TYPE, string& strTokenContext)
{
  //## begin database::PenkoToken::getContext%649466190378.body preserve=yes
   char buf[68];
   Trace::put(buf, sprintf(buf, "DB70::getContext input: ENTITY_ID=%s,ENTITY_TYPE=%s", strENTITY_ID.c_str(), strENTITY_TYPE.c_str()));
   string strKey(strENTITY_TYPE + strENTITY_ID + m_strContextOption);
   map<string, string, less<string> >::iterator p;
   if (m_hUsecaseOptions.empty())
   {
      string strCUST_ID;
      Extract::instance()->getSpec("CUSTOMER", strCUST_ID);
      EntityOption::instance()->loadUseCaseOptions("DB70", strCUST_ID, &m_hUsecaseOptions);
   }
   p = m_hUsecaseOptions.find(strKey);
   if (p == m_hUsecaseOptions.end() || m_hUsecaseOptions[strKey] == "DEFAULT")
   {
      strTokenContext.assign(strENTITY_ID);
      if (strENTITY_TYPE == "*I" && strENTITY_ID.length() >= 9)
      {
         if (strENTITY_ID.length() < 11)
            strTokenContext.insert(0, 11 - strENTITY_ID.length(), '0');
         strTokenContext.replace(0, 2, "59");
      }
   }
   else
      strTokenContext.assign(m_hUsecaseOptions[strKey]);
   Trace::put(buf, sprintf(buf,"DB70::getContext returns:%s",strTokenContext.c_str()));
  //## end database::PenkoToken::getContext%649466190378.body
}

int PenkoToken::getMethod (const string& strENTITY_ID, const string& strENTITY_TYPE)
{
  //## begin database::PenkoToken::getMethod%6494682E0063.body preserve=yes
   int iTokenMethod = 1; //default
   map<string, string, less<string> >::iterator p;
   string strKey = strENTITY_TYPE + strENTITY_ID + m_strMethodOption;
   p = m_hUsecaseOptions.find(strKey);
   if (p != m_hUsecaseOptions.end())
      iTokenMethod = atoi(m_hUsecaseOptions[strKey].c_str());
   return iTokenMethod;
  //## end database::PenkoToken::getMethod%6494682E0063.body
}

int PenkoToken::initializeA3 ()
{
  //## begin database::PenkoToken::initializeA3%64ED04B20202.body preserve=yes
   UseCase hUseCase("DIST", "## DT11 LOAD PTKN A3 TABLE");
#ifndef MVS
   IF::Trace::put("Initializing A3 PTKN table", -1, true);
   if (m_strPTKNFolder.empty())
   {
      Trace::put("A3 PTKN Table initialization failed - DFILES for PTKN Table Path not configured", -1, true);
      return UseCase::setSuccess(false);
   }
   int rc = ptknttinit(&m_tt2, (char*)m_strPTKNFolder.c_str(), "00", 62, 3); // a3
   if (rc)
   {
      IF::Trace::put(m_szErrorMsg, sprintf(m_szErrorMsg, "a3 ptknttinit Error %d", rc), true);
      return UseCase::setSuccess(false);
   }
   rc = ptknload(&m_tt2, 1);
   if (rc)
   {
      IF::Trace::put(m_szErrorMsg, sprintf(m_szErrorMsg, "a3 ptknload Error %d", rc), true);
      return UseCase::setSuccess(false);
   }
   string strCheckDigits;
   if (Extract::instance()->getRecord("DSPEC   DB70    CHECKDIGITSA3~", strCheckDigits))
   {
      strCheckDigits.erase(0, 30);
      trim(strCheckDigits);
      if (strCheckDigits.length() == 6)
         if (memcmp(&m_tt2.chk, strCheckDigits.c_str(), 6) != 0)
         {
            Trace::put("A3 PTKN Table initialization failed - Check Digits for PTKN a3 table do not match", -1, true);
            return UseCase::setSuccess(false);
         }
      IF::Trace::put("A3 PTKN table Check Digits match", -1, true);
   }
   if (!deriveContext())
   {
     IF::Trace::put("A3 PTKN Table initialization failed - context derivation failed", -1, true);
      return UseCase::setSuccess(false);
   }
   IF::Trace::put("A3 PTKN table initialization completed successfully", -1, true);
#endif
   return UseCase::setSuccess(true);
  //## end database::PenkoToken::initializeA3%64ED04B20202.body
}

int PenkoToken::initializeN6 ()
{
  //## begin database::PenkoToken::initializeN6%64ED04B00243.body preserve=yes
   UseCase hUseCase("DIST", "## DT10 LOAD PTKN N6 TABLE");
#ifndef MVS
   IF::Trace::put("Initializing N6 PTKN table", -1, true);
   if (m_strPTKNFolder.empty())
   {
      Trace::put("N6 PTKN Table initialization failed - DFILES for PTKN Table Path not configured", -1, true);
      return UseCase::setSuccess(false);
   }
   int rc = ptknttinit(&m_tt, (char*)m_strPTKNFolder.c_str(), "00", 10, 6); // n6
   if (rc)
   {
      IF::Trace::put(m_szErrorMsg, sprintf(m_szErrorMsg, "n6 ptknttinit Error %d", rc), true);
      return UseCase::setSuccess(false);
   }
   rc = ptknload(&m_tt, 1);
   if (rc)
   {
      IF::Trace::put(m_szErrorMsg, sprintf(m_szErrorMsg, "n6 ptknload Error %d", rc), true);
      return UseCase::setSuccess(false);
   }
   string strCheckDigits;
   if (Extract::instance()->getRecord("DSPEC   DB70    CHECKDIGITS~", strCheckDigits))
   {
      strCheckDigits.erase(0, 28);
      trim(strCheckDigits);
      if (strCheckDigits.length() == 6)
         if (memcmp(&m_tt.chk, strCheckDigits.c_str(), 6) != 0)
         {
            Trace::put("N6 PTKN table initialization failed - Check Digitsdo not match", -1, true);
            return UseCase::setSuccess(false);
         }
      IF::Trace::put("N6 PTKN table Check Digits match", -1, true);
   }
   IF::Trace::put("N6 PTKN table initialization completed successfully", -1, true);
#endif
   return UseCase::setSuccess(true);
   //## end database::PenkoToken::initializeN6%64ED04B00243.body
}

bool PenkoToken::isA3Configured ()
{
  //## begin database::PenkoToken::isA3Configured%64ED0235020F.body preserve=yes
   string strColumnNPI;
   Extract::instance()->getRecord("DSPEC   RU07    NPI~", strColumnNPI);
   return strColumnNPI.find("=3") != string::npos;
  //## end database::PenkoToken::isA3Configured%64ED0235020F.body
}

bool PenkoToken::isN6Configured ()
{
  //## begin database::PenkoToken::isN6Configured%64ED02370318.body preserve=yes
   int lCount = 0;
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER", strCUST_ID);
   Query hQuery;
   hQuery.attach(this);
   hQuery.setQualifier("QUALIFY", "ENTITY_OPTION");
   hQuery.bind("ENTITY_OPTION", "*", Column::LONG, &lCount, 0, "COUNT");
   hQuery.setBasicPredicate("ENTITY_OPTION", "CUST_ID", "=", strCUST_ID.c_str());
   hQuery.setBasicPredicate("ENTITY_OPTION", "USE_CASE_NAME", "=", "DB70");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   return pSelectStatement->execute(hQuery) && lCount > 0;
  //## end database::PenkoToken::isN6Configured%64ED02370318.body
}

bool PenkoToken::load ()
{
  //## begin database::PenkoToken::load%6491B20D0332.body preserve=yes
   if (!m_hUsecaseOptions.empty())
      m_hUsecaseOptions.erase(m_hUsecaseOptions.begin(), m_hUsecaseOptions.end());
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER", strCUST_ID);
   EntityOption::instance()->loadUseCaseOptions("DB70", strCUST_ID, &m_hUsecaseOptions);
   if (Extract::instance()->getRecord("DFILES  DB70    ", m_strPTKNFolder))
   {
      m_strPTKNFolder.erase(0, 16);
      trim(m_strPTKNFolder);
      m_strPTKNFolder.insert(0, 1, '/');
      if (m_strPTKNFolder[m_strPTKNFolder.length() - 1] != '/' &&
         m_strPTKNFolder[m_strPTKNFolder.length() - 1] != '\\')
         m_strPTKNFolder.append("/", 1);
      m_strPTKNFolder.insert(0, Extract::instance()->getNode001());
   }
#ifndef MVS
   string strRecord;
   if (memcmp(m_tt.pur, "ttn6", 4) != 0)
   {
      if (Extract::instance()->getRecord("DSPEC   DB70    LOADTABLE~N6", strRecord)
         && isN6Configured() )
      {
         if (!initializeN6())
         {
            ptknttfree(&m_tt);
            memcpy(m_tt.pur, "    ", 4);
            Trace::put("PTKN N6 Library initialization has failed", -1, true);
            return false;
         }
         m_bN6Active = true;
      }
   }
   if (memcmp(m_tt2.pur, "tta3", 4) != 0)
   {
      if (isA3Configured())
      {
         if (!initializeA3())
         {
            ptknttfree(&m_tt2);
            memcpy(m_tt2.pur, "    ", 4);
            Trace::put("PTKN A3 Library initialization has failed", -1, true);
            return false;
         }
         m_bA3Active = true;
      }
   }
   if (Extract::instance()->getRecord("DSPEC   DB70    ISTPTKN ", strRecord)
      && m_bN6Active)
      m_bISTWantsToken = true;
#endif
   return true;
  //## end database::PenkoToken::load%6491B20D0332.body
}

int PenkoToken::tokenize (string& strClearText, const string& strENTITY_ID, const string& strENTITY_TYPE)
{
  //## begin database::PenkoToken::tokenize%64945DC202BB.body preserve=yes
   short siMethod = getMethod(strENTITY_ID, strENTITY_TYPE);
   if (siMethod < 1 || siMethod > 4)
      siMethod = 1;
   string strContext;
   getContext(strENTITY_ID, strENTITY_TYPE,strContext);
   return tokenize(strClearText, strContext, siMethod);
  //## end database::PenkoToken::tokenize%64945DC202BB.body
}

int PenkoToken::tokenize (string& strClearText, const string& strTokenContext, short siTokenMethod)
{
  //## begin database::PenkoToken::tokenize%6491B5F40112.body preserve=yes
#ifndef MVS   
   /*
      iTokenMethod:
      1 = Partial Pan(middle digits), n6 table with encoding(the default)
      2 = Partial Pan(middle digits), n6 table no encoding
      3 = Full PAN, n6 table, with encoding
      4 = Full PAN, n6 table, no encoding
   */
   if (strClearText.length() < 6)
      return 0;
   Trace::put(" --------- PTKN TOKENIZE ---------------");
   char temp[50];
   string strContext(strTokenContext);
   int iMiddleDigitsLength = strClearText.length() - 10;
   int iPrefixLength = 6;
   int iSuffixLength = strClearText.length() == 15 ? 3 : 4;
   if (strClearText.length() < 15)
   {
      if (siTokenMethod == 1)
         siTokenMethod = 3;
      else
      if (siTokenMethod == 2)
         siTokenMethod = 4;
   }
   switch (siTokenMethod)
   {
   case 1: 
   case 2:
      iMiddleDigitsLength = iMiddleDigitsLength < 6 ? 6 : iMiddleDigitsLength;
      if (strContext != "000000")
      {
         strContext.append(strClearText.data(), iPrefixLength);
         strContext.append(strClearText.data() + strClearText.length() - iSuffixLength, iSuffixLength);
      }
      Trace::put(temp, sprintf(temp, " PREFIX          ==> %s", strClearText.substr(0, iPrefixLength).c_str()));
//    Trace::put(temp, sprintf(temp, " MIDDLE DIGITS   ==> %s", strClearText.substr(iPrefixLength, iMiddleDigitsLength).c_str()));
      Trace::put(temp, sprintf(temp, " SUFFIX          ==> %s", strClearText.substr(iPrefixLength + iMiddleDigitsLength, iSuffixLength).c_str()));
      Trace::put(temp, sprintf(temp, " Initial Context ==> %s", strTokenContext.c_str()));
      Trace::put(temp, sprintf(temp, " Final Context   ==> %s", strContext.c_str()));
      break;
   case 3:
   case 4:
      iPrefixLength = 0;
      iMiddleDigitsLength = strClearText.length();
      break;
   }
   rqst hRqst;
   memset(&hRqst, '0x00', sizeof(struct rqst));
   memcpy(hRqst.str, strClearText.data() + iPrefixLength, iMiddleDigitsLength);
   hRqst.str_len = iMiddleDigitsLength;
   hRqst.ofst = iMiddleDigitsLength - 3;
   memcpy(hRqst.ctx, strContext.data(), strContext.length());
   hRqst.ctx_len = strContext.length();
   if (memcmp(m_tt.pur, "ttn6", 4) != 0)
   {
      IF::Trace::put(" Warning - PTKN N6 table is not loaded",-1,true);
      return 1;
   }
   int rc = 0;
   rc = ptknget(&m_tt, hRqst.str, hRqst.str_len, hRqst.ctx, hRqst.ctx_len, hRqst.tkn);
   if (rc)
   {
      IF::Trace::put(m_szErrorMsg, sprintf(m_szErrorMsg, "*** Error: %d ptknget", rc), true);
      return 1;
   }
   Trace::put(temp, sprintf(temp, " Pre-Enc Token   ==> %s", string(hRqst.tkn,iMiddleDigitsLength).c_str()));
   if (siTokenMethod == 1 || siTokenMethod == 3)
   {
      hRqst.tkn_len = iMiddleDigitsLength;
      rc = ptknenc(m_tt.b, m_tt.cde, (unsigned char*)&hRqst.tkn, hRqst.tkn_len, hRqst.ofst);
      if (rc)
      {
         IF::Trace::put(m_szErrorMsg, sprintf(m_szErrorMsg, "*** Error: %d ptknenc", rc), true);
         return 1;
      }
   }
   strClearText.replace(iPrefixLength, iMiddleDigitsLength, hRqst.tkn, iMiddleDigitsLength);
   Trace::put(temp, sprintf(temp, " Final Token     ==> %s", strClearText.c_str()));
   Trace::put(" ---------------------------------------");
#endif
   return 0;
  //## end database::PenkoToken::tokenize%6491B5F40112.body
}

int PenkoToken::tokenize (string& strClearText)
{
  //## begin database::PenkoToken::tokenize%64D3EBFD02C5.body preserve=yes
#ifndef MVS
   rqst hRqst;
   memset(&hRqst, '0x00', sizeof(struct rqst));
   memcpy(hRqst.str, strClearText.data(),strClearText.length());
   hRqst.str_len = strClearText.length();
   hRqst.ofst = 0;
   memcpy(hRqst.ctx, m_strContext.data(), m_strContext.length());
   hRqst.ctx_len = m_strContext.length();
   if (memcmp(m_tt2.pur, "tta3", 4) != 0)
   {
      IF::Trace::put("Warning - PTKN A3 table is not loaded", -1, true);
      return 1;
   }
   int rc = 0;
   rc = ptknget(&m_tt2, hRqst.str, hRqst.str_len, hRqst.ctx, hRqst.ctx_len, hRqst.tkn);
   if (rc)
   {
      IF::Trace::put(m_szErrorMsg, sprintf(m_szErrorMsg, "*** Error: %d ptknget a3", rc), true);
      return 1;
   }
   strClearText.assign(hRqst.tkn, hRqst.str_len); //hRqst.tkn_len is not filled in
   strClearText.insert(0,1,'~');
   if (strClearText.data()[strClearText.length() - 1] == ' ')
      strClearText.erase(strClearText.length() - 1);
#endif
   return 0;
  //## end database::PenkoToken::tokenize%64D3EBFD02C5.body
}

// Additional Declarations
  //## begin database::PenkoToken%6490C6F001B3.declarations preserve=yes
bool PenkoToken::isToken(const char* psToken, int iLen)
{
   if (!m_bN6Active)
      return false;
   if (iLen < 15 || iLen > 28)
      return false;
   for (int i = 0; i < 6; i++)
   { //1st 6 digits must be numeric
      if (psToken[i] < '0' || psToken[i] > '9')
         return false;
   }
   if (psToken[iLen - 3] == 'a')
      return true;  //full pan encryption with encoding
   int iSuffixLength = iLen == 15 ? 3 : 4;
   for (int i = iLen - iSuffixLength; i < iLen; i++)
   { //last 3 or 4 digits must be numeric
      if (psToken[i] < '0' || psToken[i] > '9')
         return false;
   }
   if (psToken[iLen - iSuffixLength - 3] != 'a')
      return false;
   return true; //partial pan encryption with encoding
}
  //## end database::PenkoToken%6490C6F001B3.declarations

} // namespace database

//## begin module%6490C66800B5.epilog preserve=yes
//## end module%6490C66800B5.epilog
