//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A84A708032B.cm preserve=no
//## end module%5A84A708032B.cm

//## begin module%5A84A708032B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5A84A708032B.cp

//## Module: CXOSDB56%5A84A708032B; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB56.cpp

//## begin module%5A84A708032B.additionalIncludes preserve=no
//## end module%5A84A708032B.additionalIncludes

//## begin module%5A84A708032B.includes preserve=yes
#include <sstream>
//## end module%5A84A708032B.includes

#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU55_h
#include "CXODRU55.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSDB56_h
#include "CXODDB56.hpp"
#endif


//## begin module%5A84A708032B.declarations preserve=no
//## end module%5A84A708032B.declarations

//## begin module%5A84A708032B.additionalDeclarations preserve=yes
#define STS_DUPLICATE_RECORD 35
//## end module%5A84A708032B.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::Array 

//## begin database::Array::Count%5C0E69FE02D6.attr preserve=no  private: static int {V} 0
int Array::m_iCount = 0;
//## end database::Array::Count%5C0E69FE02D6.attr

//## begin database::Array::Instance%5A84A68D00A3.attr preserve=no  private: static vector<map<string,Array*,less<string> >*>* {V} 0
vector<map<string,Array*,less<string> >*>* Array::m_pInstance = 0;
//## end database::Array::Instance%5A84A68D00A3.attr

//## begin database::Array::Order%6114C04200F5.attr preserve=no  private: static vector<vector<string>* >* {V} 0
vector<vector<string>* >* Array::m_pOrder = 0;
//## end database::Array::Order%6114C04200F5.attr

Array::Array(const Array &right)
  //## begin Array::Array%5A84A65F029D_copy.hasinit preserve=no
  //## end Array::Array%5A84A65F029D_copy.hasinit
  //## begin Array::Array%5A84A65F029D_copy.initialization preserve=yes
  //## end Array::Array%5A84A65F029D_copy.initialization
{
  //## begin database::Array::Array%5A84A65F029D_copy.body preserve=yes
   memcpy(m_sID, "DB56", 4);
   m_pTable = right.m_pTable;
   m_strClass = right.m_strClass;
   m_strDate = right.m_strDate;
   m_iTables = right.m_iTables;
  //## end database::Array::Array%5A84A65F029D_copy.body
}

Array::Array (const string& strClass)
  //## begin database::Array::Array%6584FB08006F.hasinit preserve=no
      : m_iRows(1),
        m_pTable(0),
        m_iTables(0)
  //## end database::Array::Array%6584FB08006F.hasinit
  //## begin database::Array::Array%6584FB08006F.initialization preserve=yes
  //## end database::Array::Array%6584FB08006F.initialization
{
  //## begin database::Array::Array%6584FB08006F.body preserve=yes
   memcpy(m_sID, "DB56", 4);
   m_pTable = new vector<Table>;
   m_pTable->reserve(m_iRows);
   m_strClass = strClass;
   m_strDate = MidnightAlarm::instance()->getToday();
   m_iTables = 0;
  //## end database::Array::Array%6584FB08006F.body
}


Array::~Array()
{
  //## begin database::Array::~Array%5A84A65F029D_dest.body preserve=yes
   delete m_pTable;
  //## end database::Array::~Array%5A84A65F029D_dest.body
}



//## Other Operations (implementation)
void Array::abort ()
{
  //## begin database::Array::abort%5C0ED5720237.body preserve=yes
  //## end database::Array::abort%5C0ED5720237.body
}

bool Array::add (const reusable::Table& hTable, const string& strClass)
{
  //## begin database::Array::add%5A85B881001A.body preserve=yes
   int i = reusable::Thread::getNumber();
   if (!m_pInstance)
   {
      m_pInstance = new vector<map<string,Array*,less<string> >*>;
      m_pInstance->reserve(reusable::Thread::getTotal());
      m_pOrder = new vector<vector<string>* >;
      m_pOrder->reserve(reusable::Thread::getTotal());
      for (int j = 0; j < reusable::Thread::getTotal(); ++j)
      {
         m_pInstance->push_back(0);
         m_pOrder->push_back(0);
      }
   }
   if (!(*m_pInstance)[i])
      (*m_pInstance)[i] = new map<string,Array*,less<string> >;
   if (!(*m_pOrder)[i])
      (*m_pOrder)[i] = new vector<string>;
   map<string, Array*, less<string> >::iterator p = (*m_pInstance)[i]->find(hTable.getName());
   if (p == (*m_pInstance)[i]->end())
   {
      (*m_pInstance)[i]->insert(map<string, Array*>::value_type(hTable.getName(),new Array(strClass)));
      (*m_pOrder)[i]->push_back(hTable.getName());
      p = (*m_pInstance)[i]->find(hTable.getName());
      (*p).second->m_iRows = hTable.getRows();
   }
   ++(*p).second->m_iTables;
   if ((*p).second->m_iTables > (*p).second->m_pTable->size())
      (*p).second->m_pTable->push_back(hTable);
   else
      (*((*p).second->m_pTable))[(*p).second->m_iTables - 1] = hTable;
   if ((*p).second->m_iTables == (*p).second->m_iRows)
   {
      if (strClass == "InsertStatement")
      {
         string strHint;
         reusable::Table::getHint(hTable.getTableName(), strHint);
         if (strHint.find("APPEND") != string::npos)
            return true;
      }
      if (Delegate::instance(reusable::Thread::getNumber())->getThreads() == 0)
         return (*p).second->insert();
      Delegate::instance(reusable::Thread::getNumber())->push(++m_iCount % Delegate::instance(reusable::Thread::getNumber())->getThreads(),new Array(*((*p).second)));
      (*p).second->m_pTable = new vector<Table>;
   }
   return true;
  //## end database::Array::add%5A85B881001A.body
}

void Array::addToGroup (reusable::Table* pTable)
{
  //## begin database::Array::addToGroup%66B2348A01FC.body preserve=yes
   for (int i = 0; i < m_hGroup.size(); i++)
   {
      if ((*pTable) == (*m_hGroup[i].first))
      {
         if(!m_hGroup[i].first->getTable())
            m_hGroup[i].first->setTable(pTable);
         if (m_hGroup[i].second)
            m_hGroup[i].second->setTable(pTable);
         m_hGroup[i].second = pTable;
         return;
      }
   }
   m_hGroup.push_back(make_pair(pTable, (Table*)0));
  //## end database::Array::addToGroup%66B2348A01FC.body
}

void Array::clear ()
{
  //## begin database::Array::clear%5C17BE4100C1.body preserve=yes
   int i = reusable::Thread::getNumber();
   if (!m_pInstance)
   {
      m_pInstance = new vector<map<string,Array*,less<string> >*>;
      m_pInstance->reserve(reusable::Thread::getTotal());
      m_pOrder = new vector<vector<string>* >;
      m_pOrder->reserve(reusable::Thread::getTotal());
      for (int j = 0; j < reusable::Thread::getTotal(); ++j)
      {
         m_pInstance->push_back(0);
         m_pOrder->push_back(0);
      }
   }
   if (!(*m_pInstance)[i])
      (*m_pInstance)[i] = new map<string,Array*,less<string> >;
   if (!(*m_pOrder)[i])
      (*m_pOrder)[i] = new vector<string>;
   map<string,Array*,less<string> >::iterator p;
   for (p = (*m_pInstance)[i]->begin();p != (*m_pInstance)[i]->end();++p)
      (*p).second->m_iTables = 0;
  //## end database::Array::clear%5C17BE4100C1.body
}

bool Array::commit ()
{
  //## begin database::Array::commit%5A84B09B01CF.body preserve=yes
   int i = reusable::Thread::getNumber();
   if (!m_pInstance)
   {
      m_pInstance = new vector<map<string,Array*,less<string> >*>;
      m_pInstance->reserve(reusable::Thread::getTotal());
      m_pOrder = new vector<vector<string>* >;
      m_pOrder->reserve(reusable::Thread::getTotal());
      for (int j = 0; j < reusable::Thread::getTotal(); ++j)
      {
         m_pInstance->push_back(0);
         m_pOrder->push_back(0);
      }
   }
   if ((*m_pInstance)[i])
   {
      map<string,Array*,less<string> >::iterator p;
      vector<string>::iterator pIterator;
      for (pIterator = (*m_pOrder)[i]->begin(); pIterator != (*m_pOrder)[i]->end(); ++pIterator)
      {
         p = (*m_pInstance)[i]->find((*pIterator));
         if (p == (*m_pInstance)[i]->end())
            return false;
         if ((*p).second->m_iTables > 0)
         {
            (*p).second->m_strDate = MidnightAlarm::instance()->getToday();
            if (!(*p).second->insert())
               return false;
         }
      }
      // (*m_pInstance)[i]->erase(std::remove_if((*m_pInstance)[i]->begin(),(*m_pInstance)[i]->end(),[&](const std::pair<reusable::string,database::Array*> p)-> bool { return p.second->m_strDate != MidnightAlarm::instance()->getToday(); }),(*m_pInstance)[i]->end());
      p = (*m_pInstance)[i]->begin();
      while (p != (*m_pInstance)[i]->end())
      {
         if ((*p).second->m_strDate != MidnightAlarm::instance()->getToday())
         {
            string strBuffer("Age table from Array: ");
            strBuffer += (*p).first;
            Trace::put(strBuffer.data(),strBuffer.length(),true);
            for (pIterator = (*m_pOrder)[i]->begin();pIterator != (*m_pOrder)[i]->end();++pIterator)
               if ((*pIterator) == (*p).first)
               {
                  (*m_pOrder)[i]->erase(pIterator);
                  break;
               }
            delete (*p).second;
            (*m_pInstance)[i]->erase(p);
            p = (*m_pInstance)[i]->begin();
            continue;
         }
        ++p;
      }
   }
   return true;
  //## end database::Array::commit%5A84B09B01CF.body
}

void Array::execute (vector<Object*>& hObject)
{
  //## begin database::Array::execute%5C0E687503E7.body preserve=yes
   insert();
  //## end database::Array::execute%5C0E687503E7.body
}

void Array::initialize ()
{
  //## begin database::Array::initialize%5F3A78640274.body preserve=yes
/*   string strRecord;
   if (Extract::instance()->getRecord("DSPEC   DB56    ROWS~",strRecord))
      m_iRows = atoi(strRecord.substr(21).c_str());
   else
      m_iRows = 512;*/
  //## end database::Array::initialize%5F3A78640274.body
}

bool Array::insert ()
{
  //## begin database::Array::insert%5A85B617006B.body preserve=yes
   m_hGroup.clear();
   for (int i = 0; i < m_iTables; ++i)
   {
      (*m_pTable)[i].setTable(0);
      addToGroup(&(*m_pTable)[i]);
   }
   bool b = true;
   for (int i =0 ; i < m_hGroup.size();i++)
   { 
      auto_ptr<reusable::Statement> pStatement((reusable::Statement*)database::DatabaseFactory::instance()->create(m_strClass.c_str()));
      pStatement->setArray(true);
      b = b && pStatement->execute(*m_hGroup[i].first);
   }
   stringstream ss;
   ss << (*m_pTable)[0].getName() << " " << m_strClass << " " << m_iTables;
   Trace::put(ss.str().data(),ss.str().length(),true);
   m_iTables = 0;
   return b;
  //## end database::Array::insert%5A85B617006B.body
}

// Additional Declarations
  //## begin database::Array%5A84A65F029D.declarations preserve=yes
  //## end database::Array%5A84A65F029D.declarations

} // namespace database

//## begin module%5A84A708032B.epilog preserve=yes
//## end module%5A84A708032B.epilog
