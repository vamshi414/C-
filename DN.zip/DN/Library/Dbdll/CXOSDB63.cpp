//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C3F97C70085.cm preserve=no
//	$Date:   Jan 31 2019 09:20:10  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5C3F97C70085.cm

//## begin module%5C3F97C70085.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C3F97C70085.cp

//## Module: CXOSDB63%5C3F97C70085; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB63.cpp

//## begin module%5C3F97C70085.additionalIncludes preserve=no
//## end module%5C3F97C70085.additionalIncludes

//## begin module%5C3F97C70085.includes preserve=yes
//## end module%5C3F97C70085.includes

#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSDB63_h
#include "CXODDB63.hpp"
#endif


//## begin module%5C3F97C70085.declarations preserve=no
//## end module%5C3F97C70085.declarations

//## begin module%5C3F97C70085.additionalDeclarations preserve=yes
//## end module%5C3F97C70085.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::ReportFactory 

//## begin database::ReportFactory::Instance%5C40AEBE01A0.attr preserve=no  private: static database::ReportFactory* {V} 0
database::ReportFactory* ReportFactory::m_pInstance = 0;
//## end database::ReportFactory::Instance%5C40AEBE01A0.attr

ReportFactory::ReportFactory()
  //## begin ReportFactory::ReportFactory%5C3F9788036D_const.hasinit preserve=no
  //## end ReportFactory::ReportFactory%5C3F9788036D_const.hasinit
  //## begin ReportFactory::ReportFactory%5C3F9788036D_const.initialization preserve=yes
  //## end ReportFactory::ReportFactory%5C3F9788036D_const.initialization
{
  //## begin database::ReportFactory::ReportFactory%5C3F9788036D_const.body preserve=yes
   memcpy(m_sID,"DB63",4);
  //## end database::ReportFactory::ReportFactory%5C3F9788036D_const.body
}


ReportFactory::~ReportFactory()
{
  //## begin database::ReportFactory::~ReportFactory%5C3F9788036D_dest.body preserve=yes
  //## end database::ReportFactory::~ReportFactory%5C3F9788036D_dest.body
}



//## Other Operations (implementation)
database::ExportFile* ReportFactory::create (const reusable::string& strName)
{
  //## begin database::ReportFactory::create%5C3F9B68037B.body preserve=yes
   map<string,cloneFunction,less<string> >::iterator p = m_hReport.find(strName);
   if (p == m_hReport.end())
      return 0;
   return (*p).second();
  //## end database::ReportFactory::create%5C3F9B68037B.body
}

database::ReportFactory* ReportFactory::instance ()
{
  //## begin database::ReportFactory::instance%5C40AED401B7.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ReportFactory();
   return m_pInstance;
  //## end database::ReportFactory::instance%5C40AED401B7.body
}

bool ReportFactory::registerReport (const reusable::string& strName, cloneFunction hCloneFunction)
{
  //## begin database::ReportFactory::registerReport%5C3F99EA0097.body preserve=yes
   m_hReport[strName] = hCloneFunction;
   return true;
  //## end database::ReportFactory::registerReport%5C3F99EA0097.body
}

// Additional Declarations
  //## begin database::ReportFactory%5C3F9788036D.declarations preserve=yes
  //## end database::ReportFactory%5C3F9788036D.declarations

} // namespace database

//## begin module%5C3F97C70085.epilog preserve=yes
//## end module%5C3F97C70085.epilog
