//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%459254D6018C.cm preserve=no
//	$Date:   Jul 10 2012 14:12:44  $ $Author:   e1009839  $
//	$Revision:   1.4  $
//## end module%459254D6018C.cm

//## begin module%459254D6018C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%459254D6018C.cp

//## Module: CXOSDB28%459254D6018C; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB28.hpp

#ifndef CXOSDB28_h
#define CXOSDB28_h 1

//## begin module%459254D6018C.additionalIncludes preserve=no
//## end module%459254D6018C.additionalIncludes

//## begin module%459254D6018C.includes preserve=yes
//## end module%459254D6018C.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Status;
class Context;
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%459254D6018C.declarations preserve=no
//## end module%459254D6018C.declarations

//## begin module%459254D6018C.additionalDeclarations preserve=yes
//## end module%459254D6018C.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Channel%4592547A0328.preface preserve=yes
//## end database::Channel%4592547A0328.preface

//## Class: Channel%4592547A0328
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%45AE10240069;reusable::Query { -> F}
//## Uses: <unnamed>%45AE106E01D0;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%45AE109D03C4;DatabaseFactory { -> F}
//## Uses: <unnamed>%45AE119500F6;Database { -> F}
//## Uses: <unnamed>%461379D303CF;Context { -> F}
//## Uses: <unnamed>%4FF702860165;Status { -> F}

class DllExport Channel : public reusable::Observer  //## Inherits: <unnamed>%4592549A0164
{
  //## begin database::Channel%4592547A0328.initialDeclarations preserve=yes
  //## end database::Channel%4592547A0328.initialDeclarations

  public:
    //## Constructors (generated)
      Channel();

    //## Constructors (specified)
      //## Operation: Channel%4613885A0377
      Channel (const string& strIMAGEID, const string& strTASKID);

    //## Destructor (generated)
      virtual ~Channel();


    //## Other Operations (specified)
      //## Operation: getProgress%45C3123602DA
      static bool getProgress (string& strTimestamp);

      //## Operation: getStatus%4FF6FF71035D
      void getStatus ();

      //## Operation: setProgress%459255D40135
      bool setProgress (const string& strTimestamp, int iDepth);

      //## Operation: update%4594E6590177
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin database::Channel%4592547A0328.public preserve=yes
      //## end database::Channel%4592547A0328.public

  protected:
    // Additional Protected Declarations
      //## begin database::Channel%4592547A0328.protected preserve=yes
      //## end database::Channel%4592547A0328.protected

  private:
    // Additional Private Declarations
      //## begin database::Channel%4592547A0328.private preserve=yes
      //## end database::Channel%4592547A0328.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: IMAGEID%461389570387
      //## begin database::Channel::IMAGEID%461389570387.attr preserve=no  private: string {V} 
      string m_strIMAGEID;
      //## end database::Channel::IMAGEID%461389570387.attr

      //## Attribute: TASKID%4613897100B7
      //## begin database::Channel::TASKID%4613897100B7.attr preserve=no  private: string {V} 
      string m_strTASKID;
      //## end database::Channel::TASKID%4613897100B7.attr

    // Additional Implementation Declarations
      //## begin database::Channel%4592547A0328.implementation preserve=yes
      //## end database::Channel%4592547A0328.implementation

};

//## begin database::Channel%4592547A0328.postscript preserve=yes
//## end database::Channel%4592547A0328.postscript

} // namespace database

//## begin module%459254D6018C.epilog preserve=yes
//## end module%459254D6018C.epilog


#endif
