//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%498229450066.cm preserve=no
//	$Date:   May 06 2020 10:58:38  $ $Author:   e1009652  $ $Revision:   1.9  $
//## end module%498229450066.cm

//## begin module%498229450066.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%498229450066.cp

//## Module: CXOSDB34%498229450066; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB34.hpp

#ifndef CXOSDB34_h
#define CXOSDB34_h 1

//## begin module%498229450066.additionalIncludes preserve=no
//## end module%498229450066.additionalIncludes

//## begin module%498229450066.includes preserve=yes
//## end module%498229450066.includes

#ifndef CXOSRU41_h
#include "CXODRU41.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::SecurityWrapper_CAT (SWDLL)%4A09A922013D
namespace securitywrapper {
class SecurityWrapper;

} // namespace securitywrapper

//## begin module%498229450066.declarations preserve=no
//## end module%498229450066.declarations

//## begin module%498229450066.additionalDeclarations preserve=yes
//## end module%498229450066.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::AESKey%498228FD013F.preface preserve=yes
//## end database::AESKey%498228FD013F.preface

//## Class: AESKey%498228FD013F
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%498346FA00D1;DatabaseFactory { -> F}
//## Uses: <unnamed>%498347050358;reusable::Statement { -> F}
//## Uses: <unnamed>%4983470B0176;reusable::Query { -> F}
//## Uses: <unnamed>%4A09D819011D;securitywrapper::SecurityWrapper { -> F}

class DllExport AESKey : public reusable::Key  //## Inherits: <unnamed>%4982291A01D7
{
  //## begin database::AESKey%498228FD013F.initialDeclarations preserve=yes
  public:
   enum TranslateType
   {
      CX_ASCII_TO_EBCDIC,
      CX_EBCDIC_TO_ASCII
   };
  //## end database::AESKey%498228FD013F.initialDeclarations

  public:
    //## Constructors (generated)
      AESKey();

      AESKey(const AESKey &right);

    //## Constructors (specified)
      //## Operation: AESKey%49834A3503A2
      AESKey (const string& strKey);

    //## Destructor (generated)
      virtual ~AESKey();

    //## Assignment Operation (generated)
      AESKey & operator=(const AESKey &right);


    //## Other Operations (specified)
      //## Operation: decrypt%49822AC3019C
      virtual bool decrypt (string& strText);

      //## Operation: encrypt%49822AC301A9
      virtual bool encrypt (string& strText);

      //## Operation: generateDigest%49ECE45800BF
      static void generateDigest (string& strValue);

      //## Operation: generateHash%4A09DEA503E4
      static int generateHash (const char* szValue, int iLength);

      //## Operation: validate%551C214D0054
      virtual bool validate ();

    // Additional Public Declarations
      //## begin database::AESKey%498228FD013F.public preserve=yes
      virtual void encrypt_256(unsigned char* p );
      virtual void decrypt_256(unsigned char* p );
      virtual void computeCheckDigits();
      void computeLegacyCheckDigits();
      bool encryptRecord(const unsigned char* pInputBuffer, unsigned char* pOutputBuffer, int iEncryptOffset, int iEncryptLength, int iRecordLength);
      bool decryptRecord(const unsigned char* pInputBuffer, unsigned char* pOutputBuffer, int iEncryptOffset, int iEncryptLength, int iRecordLength);
      static void generateSHA512Digest(string& strValue);
      static int getMaxBufferSize(){ return 32736;} //largest block evenly divisible by 16 bytes under x'7fff' with addition of header sections (20 or 28 bytes) 
      static bool translate(char* psBuffer, unsigned int uiBuffer, enum TranslateType nTranslateType);
	  static void encryptWithOneTimeKey(string& strValue,const string& strAAD = "");
	  static void decryptWithOneTimeKey(string& strValue,const string& strAAD = "");
      //## end database::AESKey%498228FD013F.public

  protected:
    // Additional Protected Declarations
      //## begin database::AESKey%498228FD013F.protected preserve=yes
      //## end database::AESKey%498228FD013F.protected

  private:
    // Additional Private Declarations
      //## begin database::AESKey%498228FD013F.private preserve=yes
     void encryptCheckDigits(unsigned char* pBuffer, int iLength);
      //## end database::AESKey%498228FD013F.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::AESKey%498228FD013F.implementation preserve=yes
      //## end database::AESKey%498228FD013F.implementation
};

//## begin database::AESKey%498228FD013F.postscript preserve=yes
//## end database::AESKey%498228FD013F.postscript

} // namespace database

//## begin module%498229450066.epilog preserve=yes
//## end module%498229450066.epilog


#endif
