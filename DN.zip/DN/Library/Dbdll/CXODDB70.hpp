//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6490C665026A.cm preserve=no
//## end module%6490C665026A.cm

//## begin module%6490C665026A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6490C665026A.cp

//## Module: CXODDB70%6490C665026A; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB70.hpp

#ifndef CXODDB70_h
#define CXODDB70_h 1

//## begin module%6490C665026A.additionalIncludes preserve=no
//## end module%6490C665026A.additionalIncludes

//## begin module%6490C665026A.includes preserve=yes
#ifndef MVS
#include "ptkn.h"
#endif
//## end module%6490C665026A.includes

#ifndef CXOSRU63_h
#include "CXODRU63.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class EntityOption;

} // namespace database

//## begin module%6490C665026A.declarations preserve=no
//## end module%6490C665026A.declarations

//## begin module%6490C665026A.additionalDeclarations preserve=yes
//## end module%6490C665026A.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::PenkoToken%6490C6F001B3.preface preserve=yes
//## end database::PenkoToken%6490C6F001B3.preface

//## Class: PenkoToken%6490C6F001B3
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6491EC590353;EntityOption { -> F}
//## Uses: <unnamed>%6492038B036E;IF::Trace { -> F}
//## Uses: <unnamed>%649203C90286;IF::Extract { -> F}
//## Uses: <unnamed>%649A00400073;reusable::Query { -> F}
//## Uses: <unnamed>%649A00560300;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%649A007A012B;DatabaseFactory { -> F}

class DllExport PenkoToken : public reusable::PenkoToken  //## Inherits: <unnamed>%6490C7170040
{
  //## begin database::PenkoToken%6490C6F001B3.initialDeclarations preserve=yes
  //## end database::PenkoToken%6490C6F001B3.initialDeclarations

  public:
    //## Constructors (generated)
      PenkoToken();

    //## Destructor (generated)
      virtual ~PenkoToken();


    //## Other Operations (specified)
      //## Operation: detokenize%64946F4E03DB
      int detokenize (string& strTokenText, const string& strENTITY_ID, const string& strENTITY_TYPE);

      //## Operation: detokenize%6491B5A000C0
      int detokenize (string& strTokenText, const string& strTokenContext, short siTokenMethod);

      //## Operation: detokenize%64D3EC2E02DC
      int detokenize (string& strTokenText);

      //## Operation: getContext%649466190378
      void getContext (const string& strENTITY_ID, const string& strENTITY_TYPE, string& strTokenContext);

      //## Operation: getMethod%6494682E0063
      int getMethod (const string& strENTITY_ID, const string& strENTITY_TYPE);

      //## Operation: load%6491B20D0332
      virtual bool load ();

      //## Operation: tokenize%64945DC202BB
      int tokenize (string& strClearText, const string& strENTITY_ID, const string& strENTITY_TYPE);

      //## Operation: tokenize%6491B5F40112
      int tokenize (string& strClearText, const string& strTokenContext, short siTokenMethod);

      //## Operation: tokenize%64D3EBFD02C5
      int tokenize (string& strClearText);

    // Additional Public Declarations
      //## begin database::PenkoToken%6490C6F001B3.public preserve=yes
      bool isToken(const char* psToken, int iLen);
      //## end database::PenkoToken%6490C6F001B3.public

  protected:
    // Additional Protected Declarations
      //## begin database::PenkoToken%6490C6F001B3.protected preserve=yes
      //## end database::PenkoToken%6490C6F001B3.protected

  private:

    //## Other Operations (specified)
      //## Operation: deriveContext%64D3EC8D037E
      int deriveContext ();

      //## Operation: initializeA3%64ED04B20202
      int initializeA3 ();

      //## Operation: initializeN6%64ED04B00243
      int initializeN6 ();

      //## Operation: isA3Configured%64ED0235020F
      bool isA3Configured ();

      //## Operation: isN6Configured%64ED02370318
      bool isN6Configured ();

    // Additional Private Declarations
      //## begin database::PenkoToken%6490C6F001B3.private preserve=yes
#ifndef MVS
      tt_t m_tt;
      tt_t m_tt2;
#endif
      //## end database::PenkoToken%6490C6F001B3.private
  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Context%64D3ED200393
      //## begin database::PenkoToken::Context%64D3ED200393.attr preserve=no  private: string {U} 
      string m_strContext;
      //## end database::PenkoToken::Context%64D3ED200393.attr

      //## Attribute: ContextOption%6491F296029F
      //## begin database::PenkoToken::ContextOption%6491F296029F.attr preserve=no  private: string {U} "PTKN_TOKEN_CONTEXT"
      string m_strContextOption;
      //## end database::PenkoToken::ContextOption%6491F296029F.attr

      //## Attribute: ErrorMsg%6491B9580394
      //## begin database::PenkoToken::ErrorMsg%6491B9580394.attr preserve=no  private: char[60] {U} 
      char m_szErrorMsg[60];
      //## end database::PenkoToken::ErrorMsg%6491B9580394.attr

      //## Attribute: MethodOption%6491F28C023C
      //## begin database::PenkoToken::MethodOption%6491F28C023C.attr preserve=no  private: string {U} "PTKN_TOKEN_METHOD"
      string m_strMethodOption;
      //## end database::PenkoToken::MethodOption%6491F28C023C.attr

      //## Attribute: PTKNFolder%64ED061403B2
      //## begin database::PenkoToken::PTKNFolder%64ED061403B2.attr preserve=no  private: string {U} 
      string m_strPTKNFolder;
      //## end database::PenkoToken::PTKNFolder%64ED061403B2.attr

      //## Attribute: UsecaseOptions%6491F00600E0
      //## begin database::PenkoToken::UsecaseOptions%6491F00600E0.attr preserve=no  private: map<string, string, less<string> > {U} 
      map<string, string, less<string> > m_hUsecaseOptions;
      //## end database::PenkoToken::UsecaseOptions%6491F00600E0.attr

    // Additional Implementation Declarations
      //## begin database::PenkoToken%6490C6F001B3.implementation preserve=yes
      //## end database::PenkoToken%6490C6F001B3.implementation

};

//## begin database::PenkoToken%6490C6F001B3.postscript preserve=yes
//## end database::PenkoToken%6490C6F001B3.postscript

} // namespace database

//## begin module%6490C665026A.epilog preserve=yes
//## end module%6490C665026A.epilog


#endif
