//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%44802A210186.cm preserve=no
//	$Date:   Jun 28 2018 12:51:16  $ $Author:   e1009591  $ $Revision:   1.10.1.1  $
//## end module%44802A210186.cm

//## begin module%44802A210186.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%44802A210186.cp

//## Module: CXOSDB08%44802A210186; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB08.cpp

//## begin module%44802A210186.additionalIncludes preserve=no
//## end module%44802A210186.additionalIncludes

//## begin module%44802A210186.includes preserve=yes
#include "CXODTM06.hpp"
#include "CXODRU11.hpp"
#include "CXODDB02.hpp"
#include "CXODIF16.hpp"
#include "CXODDB01.hpp"
#include "CXODRU12.hpp"
//## end module%44802A210186.includes

#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSDB08_h
#include "CXODDB08.hpp"
#endif
#ifndef CXOSDB10_h
#include "CXODDB10.hpp"
#endif

//## begin module%44802A210186.declarations preserve=no
//## end module%44802A210186.declarations

//## begin module%44802A210186.additionalDeclarations preserve=yes
//## end module%44802A210186.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::SwitchClock 

//## begin database::SwitchClock::Instance%4480299B002E.attr preserve=no  public: static database::SwitchClock {R} 0
database::SwitchClock *SwitchClock::m_pInstance = 0;
//## end database::SwitchClock::Instance%4480299B002E.attr

SwitchClock::SwitchClock()
  //## begin SwitchClock::SwitchClock%448028B7000F_const.hasinit preserve=no
  //## end SwitchClock::SwitchClock%448028B7000F_const.hasinit
  //## begin SwitchClock::SwitchClock%448028B7000F_const.initialization preserve=yes
   : m_hGlobalContext("SWITCH CLOCK")
   , m_iSwitchEOD(-1)
  //## end SwitchClock::SwitchClock%448028B7000F_const.initialization
{
  //## begin database::SwitchClock::SwitchClock%448028B7000F_const.body preserve=yes
   memcpy(m_sID,"DB08",4);
  //## end database::SwitchClock::SwitchClock%448028B7000F_const.body
}


SwitchClock::~SwitchClock()
{
  //## begin database::SwitchClock::~SwitchClock%448028B7000F_dest.body preserve=yes
   MinuteTimer::instance()->detach(this);
  //## end database::SwitchClock::~SwitchClock%448028B7000F_dest.body
}



//## Other Operations (implementation)
database::SwitchClock* SwitchClock::instance ()
{
  //## begin database::SwitchClock::instance%448029BE037A.body preserve=yes
   if (!m_pInstance)
   {
      m_pInstance = new SwitchClock();
      MinuteTimer::instance()->attach(m_pInstance);
      m_pInstance->update(0);
   }
   return m_pInstance;
  //## end database::SwitchClock::instance%448029BE037A.body
}

bool SwitchClock::set (const string& strYYYYMMDDHHMMSSHN)
{
  //## begin database::SwitchClock::set%44802ACD03B9.body preserve=yes
   if (strYYYYMMDDHHMMSSHN.c_str() > Clock::instance()->getYYYYMMDDHHMMSSHN())
      return true;
   MinuteTimer::instance()->detach(this);
   if (!m_hGlobalContext.put(strYYYYMMDDHHMMSSHN.c_str()))
      return false;
   char sSTCK[8];
   memset(sSTCK,0x00,8);
   Clock::set(strYYYYMMDDHHMMSSHN.substr(0,8).c_str(),strYYYYMMDDHHMMSSHN.substr(8,8).c_str(),sSTCK);
   m_dTicks = Clock::instance()->getTicks();
   return true;
  //## end database::SwitchClock::set%44802ACD03B9.body
}

void SwitchClock::update (Subject* pSubject)
{
  //## begin database::SwitchClock::update%44803CD0004E.body preserve=yes
   string strYYYYMMDDHHMMSSHN;
   m_hGlobalContext.get(strYYYYMMDDHHMMSSHN);
   if (strYYYYMMDDHHMMSSHN.length() < 16)
   {
      if (strYYYYMMDDHHMMSSHN == "WALL CLOCK")
         strYYYYMMDDHHMMSSHN = Clock::instance()->getYYYYMMDDHHMMSSHN();
      else
      {
         DatabaseCatalog::instance()->getTable("FIN_L%","MIN",strYYYYMMDDHHMMSSHN);
         if (strYYYYMMDDHHMMSSHN.empty())
            strYYYYMMDDHHMMSSHN.assign(Clock::instance()->getYYYYMMDDHHMMSSHN().data(),6);
         else
            strYYYYMMDDHHMMSSHN.erase(0,5);
         strYYYYMMDDHHMMSSHN += "01";
         Date hDate(strYYYYMMDDHHMMSSHN.c_str());
         hDate -= 1;
         strYYYYMMDDHHMMSSHN = hDate.asString("%Y%m%d");
         strYYYYMMDDHHMMSSHN += "23595999";
      }
   }
   char sSTCK[8];
   memset(sSTCK,0x00,8);
   Clock::set(strYYYYMMDDHHMMSSHN.substr(0,8).c_str(),strYYYYMMDDHHMMSSHN.substr(8,8).c_str(),sSTCK);
   m_dTicks = Clock::instance()->getTicks();
  //## end database::SwitchClock::update%44803CD0004E.body
}

// Additional Declarations
//## begin database::SwitchClock%448028B7000F.declarations preserve=yes
bool SwitchClock::checkEODEvent()
{
   if (m_iSwitchEOD == -1)
   {
      Query hQuery;
      string strCOMMAND;
      string strTaskName(Extract::instance()->getName());
      trim(strTaskName);
      hQuery.setQualifier("QUALIFY","CREVNTT");
      hQuery.bind("CREVNTT","NETCMD",Column::STRING,&strCOMMAND);
      hQuery.setBasicPredicate("CREVNTT","NETCMD","=","RESET");
      hQuery.setBasicPredicate("CREVNTT","PROCID","=",strTaskName.c_str());
      hQuery.setBasicPredicate("CREVNTT","NETCOPT1","=","EOD");
      hQuery.setBasicPredicate("CREVNTT","CC_STATE","=","A");
      hQuery.setBasicPredicate("CREVNTT","CC_CHANGE_GRP_ID","IS NULL");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         return false;
      }
      m_iSwitchEOD = pSelectStatement->getRows() > 0 ? 1 : 0;
   }
   return m_iSwitchEOD == 1;
}
//## end database::SwitchClock%448028B7000F.declarations
} // namespace database

//## begin module%44802A210186.epilog preserve=yes
//## end module%44802A210186.epilog
