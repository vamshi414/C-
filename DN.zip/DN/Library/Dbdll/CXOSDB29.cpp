//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%45934F340072.cm preserve=no
//	$Date:   Jul 10 2012 14:12:56  $ $Author:   e1009839  $
//	$Revision:   1.2  $
//## end module%45934F340072.cm

//## begin module%45934F340072.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%45934F340072.cp

//## Module: CXOSDB29%45934F340072; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB29.cpp

//## begin module%45934F340072.additionalIncludes preserve=no
//## end module%45934F340072.additionalIncludes

//## begin module%45934F340072.includes preserve=yes
//## end module%45934F340072.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB29_h
#include "CXODDB29.hpp"
#endif


//## begin module%45934F340072.declarations preserve=no
//## end module%45934F340072.declarations

//## begin module%45934F340072.additionalDeclarations preserve=yes
//## end module%45934F340072.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::Status 

//## begin database::Status::Instance%459350EC0379.attr preserve=no  public: static database::Status* {U} 0
database::Status* Status::m_pInstance = 0;
//## end database::Status::Instance%459350EC0379.attr

Status::Status()
  //## begin Status::Status%45934EE70043_const.hasinit preserve=no
  //## end Status::Status%45934EE70043_const.hasinit
  //## begin Status::Status%45934EE70043_const.initialization preserve=yes
  //## end Status::Status%45934EE70043_const.initialization
{
  //## begin database::Status::Status%45934EE70043_const.body preserve=yes
   memcpy(m_sID,"DB29",4);
  //## end database::Status::Status%45934EE70043_const.body
}


Status::~Status()
{
  //## begin database::Status::~Status%45934EE70043_dest.body preserve=yes
  //## end database::Status::~Status%45934EE70043_dest.body
}



//## Other Operations (implementation)
void Status::bind (reusable::Query& hQuery)
{
  //## begin database::Status::bind%4FFAE9F0027A.body preserve=yes
   hQuery.bind("TASK_CONTEXT","TASKID",Column::STRING,&m_strTASKID);
   hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA);
  //## end database::Status::bind%4FFAE9F0027A.body
}

pair<string,int> Status::getStatus ()
{
  //## begin database::Status::getStatus%4FFAE9720014.body preserve=yes
   int iSecond = 0;
   if (m_strCONTEXT_DATA.length() > 17)
   {
      iSecond = atoi(m_strCONTEXT_DATA.substr(17).c_str());
      if (iSecond > 99999)
         iSecond = 2;
      else
      if (iSecond > 9999)
         iSecond = 1;
      else
         iSecond = 0;
   }
   if (m_strCONTEXT_DATA.length() >= 16)
   {  
      m_strCONTEXT_DATA.insert(14,":");
      m_strCONTEXT_DATA.insert(12,":");
      m_strCONTEXT_DATA.insert(10,":");
      m_strCONTEXT_DATA.insert(8," ");
      m_strCONTEXT_DATA.insert(6,"-");
      m_strCONTEXT_DATA.insert(4,"-");
   }
   return make_pair(m_strCONTEXT_DATA,iSecond);
  //## end database::Status::getStatus%4FFAE9720014.body
}

database::Status* Status::instance ()
{
  //## begin database::Status::instance%4593513C00F8.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new Status();
   return m_pInstance;
  //## end database::Status::instance%4593513C00F8.body
}

// Additional Declarations
  //## begin database::Status%45934EE70043.declarations preserve=yes
  //## end database::Status%45934EE70043.declarations

} // namespace database

//## begin module%45934F340072.epilog preserve=yes
//## end module%45934F340072.epilog
