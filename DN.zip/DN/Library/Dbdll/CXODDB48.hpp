//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5442CCAD00F9.cm preserve=no
//	$Date:   Oct 20 2014 13:13:40  $ $Author:   e1009839  $ $Revision:   1.0  $
//## end module%5442CCAD00F9.cm

//## begin module%5442CCAD00F9.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5442CCAD00F9.cp

//## Module: CXOSDB48%5442CCAD00F9; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB48.hpp

#ifndef CXOSDB48_h
#define CXOSDB48_h 1

//## begin module%5442CCAD00F9.additionalIncludes preserve=no
//## end module%5442CCAD00F9.additionalIncludes

//## begin module%5442CCAD00F9.includes preserve=yes
//## end module%5442CCAD00F9.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

namespace reusable {
class Query;

} // namespace reusable

//## begin module%5442CCAD00F9.declarations preserve=no
//## end module%5442CCAD00F9.declarations

//## begin module%5442CCAD00F9.additionalDeclarations preserve=yes
//## end module%5442CCAD00F9.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::ReportingLevel%5442CC670002.preface preserve=yes
//## end database::ReportingLevel%5442CC670002.preface

//## Class: ReportingLevel%5442CC670002
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5442CE280021;IF::Extract { -> F}
//## Uses: <unnamed>%5442CE2B0039;reusable::Buffer { -> F}
//## Uses: <unnamed>%5442D8E00364;reusable::Query { -> F}

class DllExport ReportingLevel : public reusable::Object  //## Inherits: <unnamed>%5442CC800173
{
  //## begin database::ReportingLevel%5442CC670002.initialDeclarations preserve=yes
  //## end database::ReportingLevel%5442CC670002.initialDeclarations

  public:
    //## Constructors (generated)
      ReportingLevel();

    //## Destructor (generated)
      virtual ~ReportingLevel();


    //## Other Operations (specified)
      //## Operation: join%5442CD150088
      static void join (reusable::Query& hQuery, const char* pszFromTable, const char* pszFromColumn, const string& strOperator, const string& strValue);

    // Additional Public Declarations
      //## begin database::ReportingLevel%5442CC670002.public preserve=yes
      //## end database::ReportingLevel%5442CC670002.public

  protected:
    // Additional Protected Declarations
      //## begin database::ReportingLevel%5442CC670002.protected preserve=yes
      //## end database::ReportingLevel%5442CC670002.protected

  private:
    // Additional Private Declarations
      //## begin database::ReportingLevel%5442CC670002.private preserve=yes
      //## end database::ReportingLevel%5442CC670002.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::ReportingLevel%5442CC670002.implementation preserve=yes
      //## end database::ReportingLevel%5442CC670002.implementation

};

//## begin database::ReportingLevel%5442CC670002.postscript preserve=yes
//## end database::ReportingLevel%5442CC670002.postscript

} // namespace database

//## begin module%5442CCAD00F9.epilog preserve=yes
//## end module%5442CCAD00F9.epilog


#endif
