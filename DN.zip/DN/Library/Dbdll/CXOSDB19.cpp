//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3A36756901A0.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3A36756901A0.cm

//## begin module%3A36756901A0.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3A36756901A0.cp

//## Module: CXOSDB19%3A36756901A0; Package body
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXOSDB19.cpp

//## begin module%3A36756901A0.additionalIncludes preserve=no
//## end module%3A36756901A0.additionalIncludes

//## begin module%3A36756901A0.includes preserve=yes
// $Date:   Apr 08 2004 10:16:54  $ $Author:   D02405  $ $Revision:   1.2  $
//## end module%3A36756901A0.includes

#ifndef CXOSDB19_h
#include "CXODDB19.hpp"
#endif
#ifndef CXOSDB20_h
#include "CXODDB20.hpp"
#endif


//## begin module%3A36756901A0.declarations preserve=no
//## end module%3A36756901A0.declarations

//## begin module%3A36756901A0.additionalDeclarations preserve=yes
//## end module%3A36756901A0.additionalDeclarations


//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::License 

//## begin database::License::Instance%3ADB0FC50371.attr preserve=no  private: static License* {U} 0
License* License::m_pInstance = 0;
//## end database::License::Instance%3ADB0FC50371.attr

License::License()
  //## begin License::License%3A36611601DA_const.hasinit preserve=no
  //## end License::License%3A36611601DA_const.hasinit
  //## begin License::License%3A36611601DA_const.initialization preserve=yes
  //## end License::License%3A36611601DA_const.initialization
{
  //## begin database::License::License%3A36611601DA_const.body preserve=yes
   memcpy(m_sID,"DB19",4);
  //## end database::License::License%3A36611601DA_const.body
}


License::~License()
{
  //## begin database::License::~License%3A36611601DA_dest.body preserve=yes
  //## end database::License::~License%3A36611601DA_dest.body
}



//## Other Operations (implementation)
License::Status License::getStatus (const char* pszOption)
{
  //## begin database::License::getStatus%3A36616F00FC.body preserve=yes
   return (License::Status)License_i::instance()->getStatus(pszOption);
  //## end database::License::getStatus%3A36616F00FC.body
}

License* License::instance ()
{
  //## begin database::License::instance%3ADB0FE60089.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new License();
   return m_pInstance;
  //## end database::License::instance%3ADB0FE60089.body
}

void License::getProductAccess (const char* pszOption, string* strRelationshipID, string* strOnlineEntityID)
{
  //## begin database::License::getProductAccess%3ADB10B10117.body preserve=yes
   License_i::instance()->retrieveAccess(pszOption, strRelationshipID, strOnlineEntityID, m_pInstance);
  //## end database::License::getProductAccess%3ADB10B10117.body
}

// Additional Declarations
  //## begin database::License%3A36611601DA.declarations preserve=yes
  //## end database::License%3A36611601DA.declarations

} // namespace database

//## begin module%3A36756901A0.epilog preserve=yes
//## end module%3A36756901A0.epilog
