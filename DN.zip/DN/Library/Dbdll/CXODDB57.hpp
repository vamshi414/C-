//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5ADE4F1F013D.cm preserve=no
//	$Date:   May 09 2018 07:49:26  $ $Author:   e1009839  $
//	$Revision:   1.2  $
//## end module%5ADE4F1F013D.cm

//## begin module%5ADE4F1F013D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5ADE4F1F013D.cp

//## Module: CXOSDB57%5ADE4F1F013D; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB57.hpp

#ifndef CXOSDB57_h
#define CXOSDB57_h 1

//## begin module%5ADE4F1F013D.additionalIncludes preserve=no
//## end module%5ADE4F1F013D.additionalIncludes

//## begin module%5ADE4F1F013D.includes preserve=yes
//## end module%5ADE4F1F013D.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSRU26_h
#include "CXODRU26.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Timestamp;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
class CriticalSection;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class RowSet;

} // namespace database

//## begin module%5ADE4F1F013D.declarations preserve=no
//## end module%5ADE4F1F013D.declarations

//## begin module%5ADE4F1F013D.additionalDeclarations preserve=yes
//## end module%5ADE4F1F013D.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::RowCache%5ADE4E7D0382.preface preserve=yes
//## end database::RowCache%5ADE4E7D0382.preface

//## Class: RowCache%5ADE4E7D0382
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5ADE518D00CF;reusable::Query { -> F}
//## Uses: <unnamed>%5AE9D5A9022B;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%5AE9DDA90054;timer::Clock { -> F}
//## Uses: <unnamed>%5AE9DDAC0161;IF::Timestamp { -> F}
//## Uses: <unnamed>%5AE9E3F20159;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%5AF19AED0024;reusable::HashTable { -> }
//## Uses: <unnamed>%5AF2E10E0242;monitor::UseCase { -> F}

class DllExport RowCache : public reusable::Observer  //## Inherits: <unnamed>%5ADE4EAD00E4
{
  //## begin database::RowCache%5ADE4E7D0382.initialDeclarations preserve=yes
  //## end database::RowCache%5ADE4E7D0382.initialDeclarations

  public:
    //## Constructors (generated)
      RowCache();

    //## Destructor (generated)
      virtual ~RowCache();


    //## Other Operations (specified)
      //## Operation: create%5ADE508C0321
      database::RowSet* create (const string& strName);

      //## Operation: instance%5ADF1B7C010C
      static RowCache* instance ();

      //## Operation: retrieve%5ADE512800E0
      bool retrieve (const string& strName, reusable::Query& hQuery, int& iRows);

      //## Operation: update%5ADE4EB50162
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin database::RowCache%5ADE4E7D0382.public preserve=yes
      //## end database::RowCache%5ADE4E7D0382.public

  protected:
    // Additional Protected Declarations
      //## begin database::RowCache%5ADE4E7D0382.protected preserve=yes
      //## end database::RowCache%5ADE4E7D0382.protected

  private:
    // Additional Private Declarations
      //## begin database::RowCache%5ADE4E7D0382.private preserve=yes
      //## end database::RowCache%5ADE4E7D0382.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5ADF1B980002
      //## begin database::RowCache::Instance%5ADF1B980002.attr preserve=no  private: static RowCache* {V} 0
      static RowCache* m_pInstance;
      //## end database::RowCache::Instance%5ADF1B980002.attr

      //## Attribute: RowSet%5AF19A9D0175
      //## begin database::RowCache::RowSet%5AF19A9D0175.attr preserve=no  private: reusable::HashTable< RowSet> {V} 
      reusable::HashTable< RowSet> m_hRowSet;
      //## end database::RowCache::RowSet%5AF19A9D0175.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%5AF2576B03B3
      //## Role: RowCache::<m_pLast>%5AF2576D002A
      //## begin database::RowCache::<m_pLast>%5AF2576D002A.role preserve=no  public: database::RowSet { -> RFHgN}
      RowSet *m_pLast;
      //## end database::RowCache::<m_pLast>%5AF2576D002A.role

      //## Association: Connex Library::Database_CAT::<unnamed>%5AF25F39031B
      //## Role: RowCache::<m_pFirst>%5AF25F3A0136
      //## begin database::RowCache::<m_pFirst>%5AF25F3A0136.role preserve=no  public: database::RowSet { -> RFHgN}
      RowSet *m_pFirst;
      //## end database::RowCache::<m_pFirst>%5AF25F3A0136.role

    // Additional Implementation Declarations
      //## begin database::RowCache%5ADE4E7D0382.implementation preserve=yes
      //## end database::RowCache%5ADE4E7D0382.implementation

};

//## begin database::RowCache%5ADE4E7D0382.postscript preserve=yes
//## end database::RowCache%5ADE4E7D0382.postscript

} // namespace database

//## begin module%5ADE4F1F013D.epilog preserve=yes
//## end module%5ADE4F1F013D.epilog


#endif
