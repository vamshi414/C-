//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3A36756702E7.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3A36756702E7.cm

//## begin module%3A36756702E7.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3A36756702E7.cp

//## Module: CXOSDB19%3A36756702E7; Package specification
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXODDB19.hpp

#ifndef CXOSDB19_h
#define CXOSDB19_h 1

//## begin module%3A36756702E7.additionalIncludes preserve=no
//## end module%3A36756702E7.additionalIncludes

//## begin module%3A36756702E7.includes preserve=yes
// $Date:   Jan 31 2017 16:41:48  $ $Author:   e1009510  $ $Revision:   1.3  $
//## end module%3A36756702E7.includes

#ifndef CXOSRU01_h
#include "CXODRU01.hpp"
#endif

//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
class License_i;

} // namespace database

//## begin module%3A36756702E7.declarations preserve=no
//## end module%3A36756702E7.declarations

//## begin module%3A36756702E7.additionalDeclarations preserve=yes
//## end module%3A36756702E7.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::License%3A36611601DA.preface preserve=yes
//## end database::License%3A36611601DA.preface

//## Class: License%3A36611601DA
//## Category: DataNavigator Foundation::Database_CAT%3451F34D0218
//## Subsystem: DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3A368B68039B;License_i { -> F}

class DllExport License : public reusable::Subject  //## Inherits: <unnamed>%3ADB0FA70255
{
  //## begin database::License%3A36611601DA.initialDeclarations preserve=yes
  public:
  enum Status
   {
      UNKNOWN = -1,
      NOT_LICENSED,
      LICENSED
   };
  //## end database::License%3A36611601DA.initialDeclarations

  public:
    //## Constructors (generated)
      License();

    //## Destructor (generated)
      virtual ~License();


    //## Other Operations (specified)
      //## Operation: getStatus%3A36616F00FC
      static Status getStatus (const char* pszOption);

      //## Operation: instance%3ADB0FE60089
      static License* instance ();

      //## Operation: getProductAccess%3ADB10B10117
      static void getProductAccess (const char* pszOption, string* strRelationshipID, string* strOnlineEntityID);

    // Additional Public Declarations
      //## begin database::License%3A36611601DA.public preserve=yes
      //## end database::License%3A36611601DA.public

  protected:
    // Additional Protected Declarations
      //## begin database::License%3A36611601DA.protected preserve=yes
      //## end database::License%3A36611601DA.protected

  private:
    // Additional Private Declarations
      //## begin database::License%3A36611601DA.private preserve=yes
      //## end database::License%3A36611601DA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3ADB0FC50371
      //## begin database::License::Instance%3ADB0FC50371.attr preserve=no  private: static License* {U} 0
      static License* m_pInstance;
      //## end database::License::Instance%3ADB0FC50371.attr

    // Additional Implementation Declarations
      //## begin database::License%3A36611601DA.implementation preserve=yes
      //## end database::License%3A36611601DA.implementation

};

//## begin database::License%3A36611601DA.postscript preserve=yes
//## end database::License%3A36611601DA.postscript

} // namespace database

//## begin module%3A36756702E7.epilog preserve=yes
using namespace database;
//## end module%3A36756702E7.epilog


#endif
