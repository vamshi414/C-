//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%545C216E03AE.cm preserve=no
//	$Date:   Jan 10 2020 07:18:20  $ $Author:   e1009839  $ $Revision:   1.8  $
//## end module%545C216E03AE.cm

//## begin module%545C216E03AE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%545C216E03AE.cp

//## Module: CXOSDB50%545C216E03AE; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.0A.R005\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB50.cpp

//## begin module%545C216E03AE.additionalIncludes preserve=no
//## end module%545C216E03AE.additionalIncludes

//## begin module%545C216E03AE.includes preserve=yes
//## end module%545C216E03AE.includes

#ifndef CXOSRU54_h
#include "CXODRU54.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSDB50_h
#include "CXODDB50.hpp"
#endif


//## begin module%545C216E03AE.declarations preserve=no
//## end module%545C216E03AE.declarations

//## begin module%545C216E03AE.additionalDeclarations preserve=yes
#define STS_DUPLICATE_RECORD 35
//## end module%545C216E03AE.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::DataModel

//## begin database::DataModel::Instance%545C22EF01FF.attr preserve=no  private: static database::DataModel* {V} 0
database::DataModel* DataModel::m_pInstance = 0;
//## end database::DataModel::Instance%545C22EF01FF.attr

DataModel::DataModel()
  //## begin DataModel::DataModel%545C1EA00044_const.hasinit preserve=no
  //## end DataModel::DataModel%545C1EA00044_const.hasinit
  //## begin DataModel::DataModel%545C1EA00044_const.initialization preserve=yes
  //## end DataModel::DataModel%545C1EA00044_const.initialization
{
  //## begin database::DataModel::DataModel%545C1EA00044_const.body preserve=yes
   memcpy(m_sID,"DB50",4);
   m_pInstance = this;
   MidnightAlarm::instance()->attach(this);
  //## end database::DataModel::DataModel%545C1EA00044_const.body
}


DataModel::~DataModel()
{
  //## begin database::DataModel::~DataModel%545C1EA00044_dest.body preserve=yes
   MidnightAlarm::instance()->detach(this);
  //## end database::DataModel::~DataModel%545C1EA00044_dest.body
}



//## Other Operations (implementation)
bool DataModel::insert ()
{
  //## begin database::DataModel::insert%545E94F0037A.body preserve=yes
   transform(m_strTABLE_NAME.begin(), m_strTABLE_NAME.end(), m_strTABLE_NAME.begin(), toupper);
   transform(m_strCOLUMN_NAME.begin(), m_strCOLUMN_NAME.end(), m_strCOLUMN_NAME.begin(), toupper);
   if (m_strCOLUMN_NAME == "*")
   {
      size_t pos = m_strTABLE_NAME.find("20");
      if (pos != string::npos)
         m_hTable.insert(m_strTABLE_NAME.substr(0,pos));
   }
   reusable::Table hTable("DATA_MODEL");
   hTable.set("TABLE_NAME",m_strTABLE_NAME);
   hTable.set("COLUMN_NAME",m_strCOLUMN_NAME);
   hTable.set("DATA_TYPE",m_strDATA_TYPE);
   hTable.set("COLUMN_STATUS",m_strCOLUMN_STATUS);
   auto_ptr<reusable::Statement> pInsertStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("InsertStatement"));
   return (pInsertStatement->execute(hTable)
      || pInsertStatement->getInfoIDNumber() == STS_DUPLICATE_RECORD);
  //## end database::DataModel::insert%545E94F0037A.body
}

DataModel* DataModel::instance ()
{
  //## begin database::DataModel::instance%545C22D400A8.body preserve=yes
   if (!m_pInstance)
      new DataModel;
   return m_pInstance;
  //## end database::DataModel::instance%545C22D400A8.body
}

bool DataModel::load ()
{
  //## begin database::DataModel::load%545C1EDC0178.body preserve=yes
   reusable::DataModel::instance()->reset();
   Query hQuery;
   hQuery.attach(this);
   hQuery.bind("DATA_MODEL","TABLE_NAME",Column::STRING,&m_strTABLE_NAME);
   hQuery.bind("DATA_MODEL","COLUMN_NAME",Column::STRING,&m_strCOLUMN_NAME);
   hQuery.bind("DATA_MODEL","DATA_TYPE",Column::STRING,&m_strDATA_TYPE);
   hQuery.bind("DATA_MODEL","COLUMN_STATUS",Column::STRING,&m_strCOLUMN_STATUS);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   reusable::DataModel::instance()->setIndex(reusable::DataModel::instance()->getIndex() == 0 ? 1 : 0);
   return true;
  //## end database::DataModel::load%545C1EDC0178.body
}

bool DataModel::refresh ()
{
  //## begin database::DataModel::refresh%545FB9F50122.body preserve=yes
   m_strYYYYMM.erase();
   GlobalContext hBegin("##BEGIN");
   string strBegin;
   if (!hBegin.get(strBegin,'F'))
      return false;
   if (strBegin.empty())
      return true;
   GlobalContext hEnd("##END");
   if (!hEnd.get(m_strYYYYMM,'F'))
   {
      m_strYYYYMM.erase();
      return false;
   }
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   do
   {
      strBegin.append("01",2);
      Date hDate(strBegin.c_str());
      hDate -= 1;
      strBegin = hDate.asString("%Y%m");
      string strValue("%yyyymm%");
      strValue.replace(1,6,strBegin.data(),6);
      Query hQuery;
      hQuery.setBasicPredicate("DATA_MODEL","TABLE_NAME","LIKE",strValue.c_str());
      if (!pDeleteStatement->execute(hQuery))
         return false;
   }
   while (pDeleteStatement->getRows() > 0);
   return true;
  //## end database::DataModel::refresh%545FB9F50122.body
}

void DataModel::update (Subject* pSubject)
{
  //## begin database::DataModel::update%545C20D1039C.body preserve=yes
   if (pSubject == MidnightAlarm::instance())
   {
      database::Cache::reload(this);
      return;
   }
   reusable::DataModel::instance()->add(m_strTABLE_NAME,m_strCOLUMN_NAME,m_strDATA_TYPE,m_strCOLUMN_STATUS,Clock::instance()->getDate().substr(0,6));
  //## end database::DataModel::update%545C20D1039C.body
}

// Additional Declarations
  //## begin database::DataModel%545C1EA00044.declarations preserve=yes
  //## end database::DataModel%545C1EA00044.declarations

} // namespace database

//## begin module%545C216E03AE.epilog preserve=yes
//## end module%545C216E03AE.epilog
