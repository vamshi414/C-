//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EC21A0D0023.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%5EC21A0D0023.cm

//## begin module%5EC21A0D0023.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5EC21A0D0023.cp

//## Module: CXOSDB66%5EC21A0D0023; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB66.hpp

#ifndef CXOSDB66_h
#define CXOSDB66_h 1

//## begin module%5EC21A0D0023.additionalIncludes preserve=no
//## end module%5EC21A0D0023.additionalIncludes

//## begin module%5EC21A0D0023.includes preserve=yes
//## end module%5EC21A0D0023.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%5EC21A0D0023.declarations preserve=no
//## end module%5EC21A0D0023.declarations

//## begin module%5EC21A0D0023.additionalDeclarations preserve=yes
//## end module%5EC21A0D0023.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Generation%5EC218E00394.preface preserve=yes
//## end database::Generation%5EC218E00394.preface

//## Class: Generation%5EC218E00394
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5EC2197B0259;reusable::Statement { -> F}
//## Uses: <unnamed>%5EC2197F0242;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5EC21983009B;reusable::Table { -> F}
//## Uses: <unnamed>%5EC219870054;reusable::Query { -> F}
//## Uses: <unnamed>%5EC2198B029F;DatabaseFactory { -> F}
//## Uses: <unnamed>%5EC2199200DA;Database { -> F}
//## Uses: <unnamed>%5EC2199F0125;monitor::UseCase { -> F}
//## Uses: <unnamed>%5EC23585007D;IF::FlatFile { -> F}
//## Uses: <unnamed>%5EC2A0430217;timer::Clock { -> F}

class DllExport Generation : public reusable::Object  //## Inherits: <unnamed>%5EC218E003AF
{
  //## begin database::Generation%5EC218E00394.initialDeclarations preserve=yes
  //## end database::Generation%5EC218E00394.initialDeclarations

  public:
    //## Constructors (generated)
      Generation();

    //## Constructors (specified)
      //## Operation: Generation%5EC2235F0008
      Generation (const reusable::string strIMAGEID, const reusable::string strTASKID, const reusable::string strGDG_TYPE);

    //## Destructor (generated)
      virtual ~Generation();


    //## Other Operations (specified)
      //## Operation: commit%5EC22A8D0018
      bool commit ();

      //## Operation: isDuplicate%5EC52C5102F5
      bool isDuplicate (const reusable::string& strHash);

      //## Operation: open%5EC22F930254
      bool open ();

      //## Operation: reset%5EC36BB30037
      void reset ();

      //## Operation: save%5EC2942D026B
      bool save ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: FILE_HASH%5EC3DF6801C1
      const reusable::string& getFILE_HASH () const
      {
        //## begin database::Generation::getFILE_HASH%5EC3DF6801C1.get preserve=no
        return m_strFILE_HASH;
        //## end database::Generation::getFILE_HASH%5EC3DF6801C1.get
      }

      void setFILE_HASH (const reusable::string& value)
      {
        //## begin database::Generation::setFILE_HASH%5EC3DF6801C1.set preserve=no
        m_strFILE_HASH = value;
        //## end database::Generation::setFILE_HASH%5EC3DF6801C1.set
      }


      //## Attribute: FILE_SIZE%5EC251A80138
      const int& getFILE_SIZE () const
      {
        //## begin database::Generation::getFILE_SIZE%5EC251A80138.get preserve=no
        return m_iFILE_SIZE;
        //## end database::Generation::getFILE_SIZE%5EC251A80138.get
      }

      void setFILE_SIZE (const int& value)
      {
        //## begin database::Generation::setFILE_SIZE%5EC251A80138.set preserve=no
        m_iFILE_SIZE = value;
        //## end database::Generation::setFILE_SIZE%5EC251A80138.set
      }


      //## Attribute: GDG_NUMBER%5EC229F10262
      const int& getGDG_NUMBER () const
      {
        //## begin database::Generation::getGDG_NUMBER%5EC229F10262.get preserve=no
        return m_iGDG_NUMBER;
        //## end database::Generation::getGDG_NUMBER%5EC229F10262.get
      }

      void setGDG_NUMBER (const int& value)
      {
        //## begin database::Generation::setGDG_NUMBER%5EC229F10262.set preserve=no
        m_iGDG_NUMBER = value;
        //## end database::Generation::setGDG_NUMBER%5EC229F10262.set
      }


      //## Attribute: GDG_PATH%5EC24CBD01C2
      const reusable::string& getGDG_PATH () const
      {
        //## begin database::Generation::getGDG_PATH%5EC24CBD01C2.get preserve=no
        return m_strGDG_PATH;
        //## end database::Generation::getGDG_PATH%5EC24CBD01C2.get
      }

      void setGDG_PATH (const reusable::string& value)
      {
        //## begin database::Generation::setGDG_PATH%5EC24CBD01C2.set preserve=no
        m_strGDG_PATH = value;
        //## end database::Generation::setGDG_PATH%5EC24CBD01C2.set
      }


      //## Attribute: GDG_PROGRESS%5EC2515803C2
      const int& getGDG_PROGRESS () const
      {
        //## begin database::Generation::getGDG_PROGRESS%5EC2515803C2.get preserve=no
        return m_iGDG_PROGRESS;
        //## end database::Generation::getGDG_PROGRESS%5EC2515803C2.get
      }

      void setGDG_PROGRESS (const int& value)
      {
        //## begin database::Generation::setGDG_PROGRESS%5EC2515803C2.set preserve=no
        m_iGDG_PROGRESS = value;
        //## end database::Generation::setGDG_PROGRESS%5EC2515803C2.set
      }


      //## Attribute: Null%5EC2536D02F7
      const short& getNull () const
      {
        //## begin database::Generation::getNull%5EC2536D02F7.get preserve=no
        return m_iNull;
        //## end database::Generation::getNull%5EC2536D02F7.get
      }

      void setNull (const short& value)
      {
        //## begin database::Generation::setNull%5EC2536D02F7.set preserve=no
        m_iNull = value;
        //## end database::Generation::setNull%5EC2536D02F7.set
      }


      //## Attribute: RECORD_COUNT%5EC2519703E2
      const int& getRECORD_COUNT () const
      {
        //## begin database::Generation::getRECORD_COUNT%5EC2519703E2.get preserve=no
        return m_iRECORD_COUNT;
        //## end database::Generation::getRECORD_COUNT%5EC2519703E2.get
      }

      void setRECORD_COUNT (const int& value)
      {
        //## begin database::Generation::setRECORD_COUNT%5EC2519703E2.set preserve=no
        m_iRECORD_COUNT = value;
        //## end database::Generation::setRECORD_COUNT%5EC2519703E2.set
      }


      //## Attribute: REPORT_DATE%60CB462A025F
      const reusable::string& getREPORT_DATE () const
      {
        //## begin database::Generation::getREPORT_DATE%60CB462A025F.get preserve=no
        return m_strREPORT_DATE;
        //## end database::Generation::getREPORT_DATE%60CB462A025F.get
      }

      void setREPORT_DATE (const reusable::string& value)
      {
        //## begin database::Generation::setREPORT_DATE%60CB462A025F.set preserve=no
        m_strREPORT_DATE = value;
        //## end database::Generation::setREPORT_DATE%60CB462A025F.set
      }


      //## Attribute: REPORT_NAME%60CB45FE033B
      const reusable::string& getREPORT_NAME () const
      {
        //## begin database::Generation::getREPORT_NAME%60CB45FE033B.get preserve=no
        return m_strREPORT_NAME;
        //## end database::Generation::getREPORT_NAME%60CB45FE033B.get
      }

      void setREPORT_NAME (const reusable::string& value)
      {
        //## begin database::Generation::setREPORT_NAME%60CB45FE033B.set preserve=no
        m_strREPORT_NAME = value;
        //## end database::Generation::setREPORT_NAME%60CB45FE033B.set
      }


    // Additional Public Declarations
      //## begin database::Generation%5EC218E00394.public preserve=yes
      //## end database::Generation%5EC218E00394.public

  protected:
    // Additional Protected Declarations
      //## begin database::Generation%5EC218E00394.protected preserve=yes
      //## end database::Generation%5EC218E00394.protected

  private:
    // Additional Private Declarations
      //## begin database::Generation%5EC218E00394.private preserve=yes
      //## end database::Generation%5EC218E00394.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin database::Generation::FILE_HASH%5EC3DF6801C1.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strFILE_HASH;
      //## end database::Generation::FILE_HASH%5EC3DF6801C1.attr

      //## begin database::Generation::FILE_SIZE%5EC251A80138.attr preserve=no  public: int {V} 0
      int m_iFILE_SIZE;
      //## end database::Generation::FILE_SIZE%5EC251A80138.attr

      //## Attribute: GDG_FILE_TYPE%5EC21DCC02D7
      //## begin database::Generation::GDG_FILE_TYPE%5EC21DCC02D7.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strGDG_FILE_TYPE;
      //## end database::Generation::GDG_FILE_TYPE%5EC21DCC02D7.attr

      //## begin database::Generation::GDG_NUMBER%5EC229F10262.attr preserve=no  public: int {V} 0
      int m_iGDG_NUMBER;
      //## end database::Generation::GDG_NUMBER%5EC229F10262.attr

      //## begin database::Generation::GDG_PATH%5EC24CBD01C2.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strGDG_PATH;
      //## end database::Generation::GDG_PATH%5EC24CBD01C2.attr

      //## begin database::Generation::GDG_PROGRESS%5EC2515803C2.attr preserve=no  public: int {V} 0
      int m_iGDG_PROGRESS;
      //## end database::Generation::GDG_PROGRESS%5EC2515803C2.attr

      //## Attribute: GDG_STATE%5EC2514700C0
      //## begin database::Generation::GDG_STATE%5EC2514700C0.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strGDG_STATE;
      //## end database::Generation::GDG_STATE%5EC2514700C0.attr

      //## Attribute: IMAGEID%5EC218E0039D
      //	The image name of this context item (will contain "*"
      //	for global context items).
      //## begin database::Generation::IMAGEID%5EC218E0039D.attr preserve=no  protected: reusable::string {V} 
      reusable::string m_strIMAGEID;
      //## end database::Generation::IMAGEID%5EC218E0039D.attr

      //## begin database::Generation::Null%5EC2536D02F7.attr preserve=no  public: short {V} -1
      short m_iNull;
      //## end database::Generation::Null%5EC2536D02F7.attr

      //## begin database::Generation::RECORD_COUNT%5EC2519703E2.attr preserve=no  public: int {V} 0
      int m_iRECORD_COUNT;
      //## end database::Generation::RECORD_COUNT%5EC2519703E2.attr

      //## begin database::Generation::REPORT_DATE%60CB462A025F.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strREPORT_DATE;
      //## end database::Generation::REPORT_DATE%60CB462A025F.attr

      //## begin database::Generation::REPORT_NAME%60CB45FE033B.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strREPORT_NAME;
      //## end database::Generation::REPORT_NAME%60CB45FE033B.attr

      //## Attribute: TASKID%5EC218E0039F
      //	The task name of this context item (will contain "*" for
      //	global context items).
      //## begin database::Generation::TASKID%5EC218E0039F.attr preserve=no  protected: reusable::string {V} 
      reusable::string m_strTASKID;
      //## end database::Generation::TASKID%5EC218E0039F.attr

      //## Attribute: TSTAMP_CLOSE%5EC251780010
      //## begin database::Generation::TSTAMP_CLOSE%5EC251780010.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTSTAMP_CLOSE;
      //## end database::Generation::TSTAMP_CLOSE%5EC251780010.attr

      //## Attribute: TSTAMP_OPEN%5EC2516B03E3
      //## begin database::Generation::TSTAMP_OPEN%5EC2516B03E3.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTSTAMP_OPEN;
      //## end database::Generation::TSTAMP_OPEN%5EC2516B03E3.attr

    // Additional Implementation Declarations
      //## begin database::Generation%5EC218E00394.implementation preserve=yes
      //## end database::Generation%5EC218E00394.implementation

};

//## begin database::Generation%5EC218E00394.postscript preserve=yes
//## end database::Generation%5EC218E00394.postscript

} // namespace database

//## begin module%5EC21A0D0023.epilog preserve=yes
//## end module%5EC21A0D0023.epilog


#endif
