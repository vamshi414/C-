//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%44802A1F035B.cm preserve=no
//	$Date:   Jun 26 2018 08:26:56  $ $Author:   e1009591  $ $Revision:   1.0.1.0  $
//## end module%44802A1F035B.cm

//## begin module%44802A1F035B.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%44802A1F035B.cp

//## Module: CXOSDB08%44802A1F035B; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB08.hpp

#ifndef CXOSDB08_h
#define CXOSDB08_h 1

//## begin module%44802A1F035B.additionalIncludes preserve=no
//## end module%44802A1F035B.additionalIncludes

//## begin module%44802A1F035B.includes preserve=yes
//## end module%44802A1F035B.includes

#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MinuteTimer;
} // namespace timer

//## begin module%44802A1F035B.declarations preserve=no
//## end module%44802A1F035B.declarations

//## begin module%44802A1F035B.additionalDeclarations preserve=yes
//## end module%44802A1F035B.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::SwitchClock%448028B7000F.preface preserve=yes
//## end database::SwitchClock%448028B7000F.preface

//## Class: SwitchClock%448028B7000F
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%44808290032C;timer::MinuteTimer { -> F}

class DllExport SwitchClock : public timer::Clock  //## Inherits: <unnamed>%448028E50167
{
  //## begin database::SwitchClock%448028B7000F.initialDeclarations preserve=yes
  //## end database::SwitchClock%448028B7000F.initialDeclarations

  public:
    //## Constructors (generated)
      SwitchClock();

    //## Destructor (generated)
      virtual ~SwitchClock();


    //## Other Operations (specified)
      //## Operation: instance%448029BE037A
      //	Returns the one and only instance of the Clock.
      static SwitchClock* instance ();

      //## Operation: set%44802ACD03B9
      bool set (const string& strYYYYMMDDHHMMSSHN);

      //## Operation: update%44803CD0004E
      //	Refreshes the clock values by retrieving the hardware
      //	timer.
      virtual void update (Subject* pSubject	// Either MinuteTimer::instance or zero
      );

    // Additional Public Declarations
      //## begin database::SwitchClock%448028B7000F.public preserve=yes
      bool checkEODEvent();
      //## end database::SwitchClock%448028B7000F.public

  protected:
    // Additional Protected Declarations
      //## begin database::SwitchClock%448028B7000F.protected preserve=yes
      //## end database::SwitchClock%448028B7000F.protected

  private:
    // Additional Private Declarations
      //## begin database::SwitchClock%448028B7000F.private preserve=yes
      //## end database::SwitchClock%448028B7000F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%4480299B002E
      //	One and only instance of SwitchClock
      //## begin database::SwitchClock::Instance%4480299B002E.attr preserve=no  public: static SwitchClock {R} 0
      static SwitchClock *m_pInstance;
      //## end database::SwitchClock::Instance%4480299B002E.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%44802974034B
      //## Role: SwitchClock::<m_hGlobalContext>%448029750251
      //## begin database::SwitchClock::<m_hGlobalContext>%448029750251.role preserve=no  public: database::GlobalContext { -> VHgN}
      GlobalContext m_hGlobalContext;
      //## end database::SwitchClock::<m_hGlobalContext>%448029750251.role

    // Additional Implementation Declarations
      //## begin database::SwitchClock%448028B7000F.implementation preserve=yes
      int m_iSwitchEOD;
      //## end database::SwitchClock%448028B7000F.implementation

};

//## begin database::SwitchClock%448028B7000F.postscript preserve=yes
//## end database::SwitchClock%448028B7000F.postscript

} // namespace database

//## begin module%44802A1F035B.epilog preserve=yes
using namespace database;
//## end module%44802A1F035B.epilog


#endif
