//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4FE9A982004B.cm preserve=no
//	$Date:   Jan 02 2019 21:29:42  $ $Author:   e1009839  $
//	$Revision:   1.2  $
//## end module%4FE9A982004B.cm

//## begin module%4FE9A982004B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4FE9A982004B.cp

//## Module: CXOSDB43%4FE9A982004B; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB43.hpp

#ifndef CXOSDB43_h
#define CXOSDB43_h 1

//## begin module%4FE9A982004B.additionalIncludes preserve=no
//## end module%4FE9A982004B.additionalIncludes

//## begin module%4FE9A982004B.includes preserve=yes
//## end module%4FE9A982004B.includes

#ifndef CXOSRU46_h
#include "CXODRU46.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Sleep;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;

} // namespace monitor

//## begin module%4FE9A982004B.declarations preserve=no
//## end module%4FE9A982004B.declarations

//## begin module%4FE9A982004B.additionalDeclarations preserve=yes
//## end module%4FE9A982004B.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Cache%4FE9A8E903E1.preface preserve=yes
//## end database::Cache%4FE9A8E903E1.preface

//## Class: Cache%4FE9A8E903E1
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4FF420030088;IF::Sleep { -> F}
//## Uses: <unnamed>%4FF4259800D2;Database { -> F}
//## Uses: <unnamed>%4FF428D80034;monitor::UseCase { -> F}

class DllExport Cache : public reusable::Cache  //## Inherits: <unnamed>%4FF5CD81035E
{
  //## begin database::Cache%4FE9A8E903E1.initialDeclarations preserve=yes
  public:
  enum State
   {
      EMPTY,
      LOADING,
      LOADED
   };
  //## end database::Cache%4FE9A8E903E1.initialDeclarations

  public:
    //## Constructors (generated)
      Cache();

    //## Destructor (generated)
      virtual ~Cache();


    //## Other Operations (specified)
      //## Operation: initialize%4FE9C68103D2
      static void initialize ();

      //## Operation: reload%4FF7242103A7
      static void reload (reusable::Cache* pCache);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: State%5C1A7AB30059
      static const enum Cache::State getState ();
      static void setState (enum Cache::State value);

    // Additional Public Declarations
      //## begin database::Cache%4FE9A8E903E1.public preserve=yes
      //## end database::Cache%4FE9A8E903E1.public

  protected:
    // Additional Protected Declarations
      //## begin database::Cache%4FE9A8E903E1.protected preserve=yes
      //## end database::Cache%4FE9A8E903E1.protected

  private:
    // Additional Private Declarations
      //## begin database::Cache%4FE9A8E903E1.private preserve=yes
      //## end database::Cache%4FE9A8E903E1.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin database::Cache::State%5C1A7AB30059.attr preserve=no  public: static enum Cache::State {V} EMPTY
      static enum Cache::State m_nState;
      //## end database::Cache::State%5C1A7AB30059.attr

    // Additional Implementation Declarations
      //## begin database::Cache%4FE9A8E903E1.implementation preserve=yes
      //## end database::Cache%4FE9A8E903E1.implementation

};

//## begin database::Cache%4FE9A8E903E1.postscript preserve=yes
//## end database::Cache%4FE9A8E903E1.postscript

} // namespace database

//## begin module%4FE9A982004B.epilog preserve=yes
//## end module%4FE9A982004B.epilog


#endif
