//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5442CCAE03A7.cm preserve=no
//	$Date:   Oct 20 2014 13:14:12  $ $Author:   e1009839  $ $Revision:   1.0  $
//## end module%5442CCAE03A7.cm

//## begin module%5442CCAE03A7.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5442CCAE03A7.cp

//## Module: CXOSDB48%5442CCAE03A7; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB48.cpp

//## begin module%5442CCAE03A7.additionalIncludes preserve=no
//## end module%5442CCAE03A7.additionalIncludes

//## begin module%5442CCAE03A7.includes preserve=yes
//## end module%5442CCAE03A7.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB48_h
#include "CXODDB48.hpp"
#endif


//## begin module%5442CCAE03A7.declarations preserve=no
//## end module%5442CCAE03A7.declarations

//## begin module%5442CCAE03A7.additionalDeclarations preserve=yes
//## end module%5442CCAE03A7.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::ReportingLevel 

ReportingLevel::ReportingLevel()
  //## begin ReportingLevel::ReportingLevel%5442CC670002_const.hasinit preserve=no
  //## end ReportingLevel::ReportingLevel%5442CC670002_const.hasinit
  //## begin ReportingLevel::ReportingLevel%5442CC670002_const.initialization preserve=yes
  //## end ReportingLevel::ReportingLevel%5442CC670002_const.initialization
{
  //## begin database::ReportingLevel::ReportingLevel%5442CC670002_const.body preserve=yes
  //## end database::ReportingLevel::ReportingLevel%5442CC670002_const.body
}


ReportingLevel::~ReportingLevel()
{
  //## begin database::ReportingLevel::~ReportingLevel%5442CC670002_dest.body preserve=yes
  //## end database::ReportingLevel::~ReportingLevel%5442CC670002_dest.body
}



//## Other Operations (implementation)
void ReportingLevel::join (reusable::Query& hQuery, const char* pszFromTable, const char* pszFromColumn, const string& strOperator, const string& strValue)
{
  //## begin database::ReportingLevel::join%5442CD150088.body preserve=yes
   string strCTE1(
      "WITH CTE1 (RPT_LVL_ID,NEXT_ID) AS"
      " ("
      " SELECT"
      " RPT_LVL_ID,"
      " NEXT_ID"
      " FROM qualify.REPORTING_LVL"
      " WHERE"
      " RPT_LVL_ID predicate"
      " UNION ALL"
      " SELECT"
      " C.RPT_LVL_ID,"
      " C.NEXT_ID"
      " FROM qualify.REPORTING_LVL C"
      " INNER JOIN CTE1 P"
      " ON P.RPT_LVL_ID = C.NEXT_ID"
      " ) "
     );
   size_t pos = strCTE1.find("qualify");
   strCTE1.replace(pos,7,Extract::instance()->getQualify());
   pos = strCTE1.find("qualify");
   strCTE1.replace(pos,7,Extract::instance()->getQualify());
   pos = strCTE1.find("predicate");
   if (strOperator == "IN"
      || strOperator == "NOT IN")
   {
      vector<string> hTokens;
      Buffer::parse(strValue,"(',)",hTokens);
      string strPredicate(" (");
      vector<string>::iterator p;
      for (p = hTokens.begin();p != hTokens.end();++p)
      {
         if (!(*p).empty())
         {
            if (strPredicate.length() > 2)
               strPredicate += ",";
            strPredicate += "'";
            strPredicate += (*p);
            strPredicate += "'";
         }
      }
      strPredicate += ")";
      strCTE1.replace(pos,9,strPredicate);
      strCTE1.insert(pos,strOperator);
   }
   else
   {
      if (strValue[0] != '\'')
         strCTE1.insert(pos + 9,"'");
      strCTE1.replace(pos,9,strValue);
      if (strValue[0] != '\'')
         strCTE1.insert(pos,"'");
      strCTE1.insert(pos," ");
      strCTE1.insert(pos,strOperator);
   }
   hQuery.join(pszFromTable,"INNER","CTE1",pszFromColumn,"RPT_LVL_ID");
   hQuery.setCTE(strCTE1);
  //## end database::ReportingLevel::join%5442CD150088.body
}

// Additional Declarations
  //## begin database::ReportingLevel%5442CC670002.declarations preserve=yes
  //## end database::ReportingLevel%5442CC670002.declarations

} // namespace database

//## begin module%5442CCAE03A7.epilog preserve=yes
//## end module%5442CCAE03A7.epilog
