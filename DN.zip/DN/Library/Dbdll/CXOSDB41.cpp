//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4C5059F90307.cm preserve=no
//	$Date:   May 14 2020 18:12:40  $ $Author:   e1009510  $ $Revision:   1.5  $
//## end module%4C5059F90307.cm

//## begin module%4C5059F90307.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4C5059F90307.cp

//## Module: CXOSDB41%4C5059F90307; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB41.cpp

//## begin module%4C5059F90307.additionalIncludes preserve=no
//## end module%4C5059F90307.additionalIncludes

//## begin module%4C5059F90307.includes preserve=yes
#include "CXODIF53.hpp"
#include <algorithm>
//## end module%4C5059F90307.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CX0SDB41_h
#include "CXODDB41.hpp"
#endif


//## begin module%4C5059F90307.declarations preserve=no
//## end module%4C5059F90307.declarations

//## begin module%4C5059F90307.additionalDeclarations preserve=yes
//## end module%4C5059F90307.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::ZosXMLEncryptedFile 

ZosXMLEncryptedFile::ZosXMLEncryptedFile()
  //## begin ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C50597C02D5_const.hasinit preserve=no
  //## end ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C50597C02D5_const.hasinit
  //## begin ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C50597C02D5_const.initialization preserve=yes
  //## end ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C50597C02D5_const.initialization
{
  //## begin database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C50597C02D5_const.body preserve=yes
   memcpy_s(m_sID,4,"DB41",4);
  //## end database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C50597C02D5_const.body
}

ZosXMLEncryptedFile::ZosXMLEncryptedFile (const char* pszName, const char* pszMember)
  //## begin database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C8155E600CD.hasinit preserve=no
  //## end database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C8155E600CD.hasinit
  //## begin database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C8155E600CD.initialization preserve=yes
      : ZosEncryptedFile(pszName,pszMember)
  //## end database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C8155E600CD.initialization
{
  //## begin database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C8155E600CD.body preserve=yes
   memcpy_s(m_sID,4,"DB41",4);
  //## end database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C8155E600CD.body
}

ZosXMLEncryptedFile::ZosXMLEncryptedFile (const char* pszName)
  //## begin database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C8155E600D0.hasinit preserve=no
  //## end database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C8155E600D0.hasinit
  //## begin database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C8155E600D0.initialization preserve=yes
      : ZosEncryptedFile(pszName)
  //## end database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C8155E600D0.initialization
{
  //## begin database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C8155E600D0.body preserve=yes
   memcpy_s(m_sID,4,"DB41",4);
  //## end database::ZosXMLEncryptedFile::ZosXMLEncryptedFile%4C8155E600D0.body
}


ZosXMLEncryptedFile::~ZosXMLEncryptedFile()
{
  //## begin database::ZosXMLEncryptedFile::~ZosXMLEncryptedFile%4C50597C02D5_dest.body preserve=yes
   delete m_pKey;
  //## end database::ZosXMLEncryptedFile::~ZosXMLEncryptedFile%4C50597C02D5_dest.body
}



//## Other Operations (implementation)
bool ZosXMLEncryptedFile::write (char* psBuffer, int lRecordLength)
{
  //## begin database::ZosXMLEncryptedFile::write%4C505B2A02D6.body preserve=yes
#ifdef MVS
   string strValue(psBuffer,lRecordLength);
   size_t startPos = 0;
   size_t pos = strValue.find("<Pan>");
   if(pos != string::npos)
      startPos = pos+5;
   else
   {
      pos = strValue.find("<CardholderAccount>");
      if(pos != string::npos)
         startPos = pos+19;
   }
   if(startPos > 0)
   { 
      string strDefaultDataKey = KeyRing::instance()->getDefaultDataKey();
      if(strDefaultDataKey.length() != 6)
      {
         IF::Trace::put("Warning! Unable to encrypt record - Default Key not set");
         return ZosFile::write(psBuffer,lRecordLength);   
      }
      setKey(strDefaultDataKey.substr(2,4));
      string strBeginLine(psBuffer,startPos);
      string strPAN(psBuffer+startPos,lRecordLength-startPos);
      pos = strPAN.find("<"); //look for end tag
      string strEndLine;
      if(pos != string::npos)
      {
         strEndLine.assign(strPAN.substr(pos));
         strPAN.erase(pos);
      }

      //trim leading and trailing blanks
      pos = strPAN.find_first_not_of(" ");
      if(pos != string::npos && pos > 0)
         strPAN.erase(0,pos);
      pos = strPAN.find(" ");
      if(pos != string::npos)
         strPAN.erase(pos);
      int iLen = strPAN.length(); //save unencrypted length
      if(iLen > 0)
      {
         if (encryptPAN(strPAN))
         {
            unsigned int iTempLength = strBeginLine.length() + 6 + 4 + 7 + strPAN.length() + strEndLine.length() + 1;
            char* pTempBuffer = new char[iTempLength];
            lRecordLength = snprintf(pTempBuffer,iTempLength,"%s<DKCD>%s</DKCD>%s%s",
               strBeginLine.c_str(),
               strDefaultDataKey.substr(2,4).c_str(),
               strPAN.c_str(),
               strEndLine.c_str());
            bool bReturn = ZosFile::write(pTempBuffer, lRecordLength);
            delete [] pTempBuffer;
            return bReturn;
         }
      } 
   }
   return ZosFile::write(psBuffer,lRecordLength);
#else
   return true;
#endif
  //## end database::ZosXMLEncryptedFile::write%4C505B2A02D6.body
}

bool ZosXMLEncryptedFile::read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool* pbReadError)
{
  //## begin database::ZosXMLEncryptedFile::read%4C505B51000A.body preserve=yes
   if(!ZosFile::read(psBuffer,lBufferLength,plRecordLength,pbReadError))
      return false;
   string strRecord(psBuffer,*plRecordLength);
   size_t posStart = strRecord.find("<DKCD>");   
   if(posStart != string::npos)
   {
      string strBeginLine(psBuffer, posStart);
      size_t posEnd = strRecord.find("</DKCD>");
      if(posEnd == string::npos || posEnd-posStart < 4)
      {
         IF::Trace::put("Error - Invalid <DKCD> tag");
         return false;
      }
      if(!setKey(strRecord.substr(posStart+6,4)))
      {
         IF::Trace::put("Error decrypting record - Key not found");
         return false;
      }
      string strEndLine(psBuffer+posEnd+7,strRecord.length()-posEnd+7);
      string strPAN;
      size_t pos = strEndLine.find("</");
      if(pos != string::npos)
      {
         strPAN.assign(strEndLine.substr(0,pos));
         strEndLine.erase(0,pos);
      }
      else
      {
         strPAN.assign(strEndLine);
         strEndLine.erase();
      }
      //trim leading and trailing blanks
      pos = strPAN.find_first_not_of(" ");
      if(pos != string::npos && pos > 0)
         strPAN.erase(0,pos);
      pos = strPAN.find(" ");
      if(pos != string::npos)
         strPAN.erase(pos);
      if(!m_pKey->decrypt(strPAN))
      {
         IF::Trace::put("Read Failure, unable to decrypt record");
         return false;
      }
      *plRecordLength = snprintf(psBuffer,strBeginLine.length()+strPAN.length()+strEndLine.length(),"%s%s%s",
      strBeginLine.c_str(),
      strPAN.c_str(),
      strEndLine.c_str());
   }
   return true;
  //## end database::ZosXMLEncryptedFile::read%4C505B51000A.body
}

bool ZosXMLEncryptedFile::encryptPAN (string& strPAN)
{
  //## begin database::ZosXMLEncryptedFile::encryptPAN%4C8156B20067.body preserve=yes
   if(!m_pKey)
      return false;
   while(strPAN.length() % 8 != 0)
      strPAN.append(" "); //pad to multiple of 8
   if(!m_pKey->encrypt(strPAN))
      return false;
   return true;
  //## end database::ZosXMLEncryptedFile::encryptPAN%4C8156B20067.body
}

// Additional Declarations
  //## begin database::ZosXMLEncryptedFile%4C50597C02D5.declarations preserve=yes
  //## end database::ZosXMLEncryptedFile%4C50597C02D5.declarations
} // namespace database

//## begin module%4C5059F90307.epilog preserve=yes
//## end module%4C5059F90307.epilog
