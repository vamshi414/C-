//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%53D178410374.cm preserve=no
//  $Date:   Oct 21 2014 14:43:54  $ $Author:   e1024360  $
//  $Revision:   1.1  $
//## end module%53D178410374.cm

//## begin module%53D178410374.cp preserve=no
//  Copyright (c) 1997 - 2012
//  FIS
//## end module%53D178410374.cp

//## Module: CXOSDB46%53D178410374; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//  .
//## Source file: C:\bV02.4B.R007\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB46.cpp

//## begin module%53D178410374.additionalIncludes preserve=no
//## end module%53D178410374.additionalIncludes

//## begin module%53D178410374.includes preserve=yes
#include "CXODRU10.hpp"
//## end module%53D178410374.includes

#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDB46_h
#include "CXODDB46.hpp"
#endif


//## begin module%53D178410374.declarations preserve=no
//## end module%53D178410374.declarations

//## begin module%53D178410374.additionalDeclarations preserve=yes
//## end module%53D178410374.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::EMSBusinessDate 

//## begin database::EMSBusinessDate::Instance%53D298E700A2.attr preserve=no  private: static database::EMSBusinessDate* {U} 
database::EMSBusinessDate* EMSBusinessDate::m_pInstance;
//## end database::EMSBusinessDate::Instance%53D298E700A2.attr

EMSBusinessDate::EMSBusinessDate()
  //## begin EMSBusinessDate::EMSBusinessDate%53D1780101BD_const.hasinit preserve=no
  //## end EMSBusinessDate::EMSBusinessDate%53D1780101BD_const.hasinit
  //## begin EMSBusinessDate::EMSBusinessDate%53D1780101BD_const.initialization preserve=yes
  //## end EMSBusinessDate::EMSBusinessDate%53D1780101BD_const.initialization
{
  //## begin database::EMSBusinessDate::EMSBusinessDate%53D1780101BD_const.body preserve=yes
   memcpy(m_sID,"DB46",4);
   MidnightAlarm::instance()->attach(this);
   m_pCalendar = new database::Calendar();
  //## end database::EMSBusinessDate::EMSBusinessDate%53D1780101BD_const.body
}


EMSBusinessDate::~EMSBusinessDate()
{
  //## begin database::EMSBusinessDate::~EMSBusinessDate%53D1780101BD_dest.body preserve=yes
   MidnightAlarm::instance()->detach(this);
  //## end database::EMSBusinessDate::~EMSBusinessDate%53D1780101BD_dest.body
}



//## Other Operations (implementation)
void EMSBusinessDate::calculateBusinessDate (string& strEvent, timer::Date& hBusinessDate, int iNumDays)
{
  //## begin database::EMSBusinessDate::calculateBusinessDate%53D297C5031E.body preserve=yes
   if (strEvent.length() == 0)
   {
      hBusinessDate += iNumDays;
      return;
   }
   int iNumBusDays = 0;
   m_pCalendar->setCalendar(strEvent);
   while (iNumBusDays < iNumDays)
   {
      hBusinessDate += 1;
      if (m_pCalendar->isBusinessDay(hBusinessDate))
         iNumBusDays++;
   }
  //## end database::EMSBusinessDate::calculateBusinessDate%53D297C5031E.body
}

string EMSBusinessDate::getBusinessCalendar (const string& strCUR_RECON_NET, const string& strCUR_TRAN, const string& strUSER_ROLE, const string& strCUST_ID, const string& strEMS_CALENDAR_DFLT)
{
  //## begin database::EMSBusinessDate::getBusinessCalendar%53D2982E0364.body preserve=yes
   string strCurrencyEvent = Transaction::instance()->getCustAbbr();
   strCurrencyEvent.resize(2,' ');

   strCurrencyEvent+= "EM";
   string strCustomerEvent = strCurrencyEvent;
   if (strUSER_ROLE == "I")
      strCurrencyEvent += strCUR_RECON_NET;
   else
      strCurrencyEvent += strCUR_TRAN;
   strCustomerEvent += strCUST_ID;

   string strBUSINESS_CALENDAR;
   if (m_pCalendar->doesExist(strCurrencyEvent) && m_pCalendar->doesExist(strCustomerEvent))
   {
      if (strEMS_CALENDAR_DFLT == "C")
         strBUSINESS_CALENDAR = strCurrencyEvent;
      else
         strBUSINESS_CALENDAR = strCustomerEvent;
   }
   else if (m_pCalendar->doesExist(strCurrencyEvent))
      strBUSINESS_CALENDAR = strCurrencyEvent;
   else if (m_pCalendar->doesExist(strCustomerEvent))
      strBUSINESS_CALENDAR = strCustomerEvent;

   return (strBUSINESS_CALENDAR);
  //## end database::EMSBusinessDate::getBusinessCalendar%53D2982E0364.body
}

EMSBusinessDate* EMSBusinessDate::instance ()
{
  //## begin database::EMSBusinessDate::instance%53D298A50058.body preserve=yes
   if (!m_pInstance)
   {
      m_pInstance = new EMSBusinessDate();
      m_pInstance->load();
   }
   return m_pInstance;
  //## end database::EMSBusinessDate::instance%53D298A50058.body
}

bool EMSBusinessDate::load ()
{
  //## begin database::EMSBusinessDate::load%53D185950027.body preserve=yes
   m_strEVNTID.erase();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery;
   hQuery.attach(this);
   hQuery.setQualifier("QUALIFY","CREVNTT");
   hQuery.bind("CREVNTT","EVNTID",Column::STRING,&m_strEVNTID);
   hQuery.setBasicPredicate("CREVNTT","EVNTID","LIKE", "%EM%");
   hQuery.setBasicPredicate("CREVNTT","CC_STATE","=","A");
   hQuery.setBasicPredicate("CREVNTT","CC_CHANGE_GRP_ID","IS NULL");
   if (!pSelectStatement->execute(hQuery))
   {
      hQuery.detach(this);
      return false;
   }
   hQuery.detach(this);
   return true;
  //## end database::EMSBusinessDate::load%53D185950027.body
}

void EMSBusinessDate::update (Subject* pSubject)
{
  //## begin database::EMSBusinessDate::update%53D298960357.body preserve=yes
   if (pSubject == MidnightAlarm::instance() || pSubject == Database::instance())
   {
      if (Database::instance()->state() == Database::CONNECTED)
         Cache::reload(this);
   }
   else
   {
      m_pCalendar->loadBusinessDays(m_strEVNTID);
      m_pCalendar->loadHolidays(m_strEVNTID);
   }
  //## end database::EMSBusinessDate::update%53D298960357.body
}

// Additional Declarations
  //## begin database::EMSBusinessDate%53D1780101BD.declarations preserve=yes
  //## end database::EMSBusinessDate%53D1780101BD.declarations

} // namespace database

//## begin module%53D178410374.epilog preserve=yes
//## end module%53D178410374.epilog
