//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5898C1930010.cm preserve=no
//	$Date:   May 14 2020 18:12:44  $ $Author:   e1009510  $ $Revision:   1.1  $
//## end module%5898C1930010.cm

//## begin module%5898C1930010.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5898C1930010.cp

//## Module: CXOSDB54%5898C1930010; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB54.cpp

//## begin module%5898C1930010.additionalIncludes preserve=no
//## end module%5898C1930010.additionalIncludes

//## begin module%5898C1930010.includes preserve=yes
//## end module%5898C1930010.includes

#ifndef CXOSRU07_h
#include "CXODRU07.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSDB54_h
#include "CXODDB54.hpp"
#endif


//## begin module%5898C1930010.declarations preserve=no
//## end module%5898C1930010.declarations

//## begin module%5898C1930010.additionalDeclarations preserve=yes
#define STS_DUPLICATE_RECORD 35
//## end module%5898C1930010.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::APIAuditEventVisitor 

APIAuditEventVisitor::APIAuditEventVisitor()
  //## begin APIAuditEventVisitor::APIAuditEventVisitor%5898C08B00EC_const.hasinit preserve=no
      : m_siSequenceNo(0)
  //## end APIAuditEventVisitor::APIAuditEventVisitor%5898C08B00EC_const.hasinit
  //## begin APIAuditEventVisitor::APIAuditEventVisitor%5898C08B00EC_const.initialization preserve=yes
  //## end APIAuditEventVisitor::APIAuditEventVisitor%5898C08B00EC_const.initialization
{
  //## begin database::APIAuditEventVisitor::APIAuditEventVisitor%5898C08B00EC_const.body preserve=yes
  //## end database::APIAuditEventVisitor::APIAuditEventVisitor%5898C08B00EC_const.body
}

APIAuditEventVisitor::APIAuditEventVisitor (Table* pTable, Statement* pStatement)
  //## begin database::APIAuditEventVisitor::APIAuditEventVisitor%5898D1A5035F.hasinit preserve=no
      : m_siSequenceNo(0)
  //## end database::APIAuditEventVisitor::APIAuditEventVisitor%5898D1A5035F.hasinit
  //## begin database::APIAuditEventVisitor::APIAuditEventVisitor%5898D1A5035F.initialization preserve=yes
  //## end database::APIAuditEventVisitor::APIAuditEventVisitor%5898D1A5035F.initialization
{
  //## begin database::APIAuditEventVisitor::APIAuditEventVisitor%5898D1A5035F.body preserve=yes
   memcpy_s(m_sID,4,"DB54", 4);
   m_pTable = pTable;
   m_pStatement = pStatement;
  //## end database::APIAuditEventVisitor::APIAuditEventVisitor%5898D1A5035F.body
}


APIAuditEventVisitor::~APIAuditEventVisitor()
{
  //## begin database::APIAuditEventVisitor::~APIAuditEventVisitor%5898C08B00EC_dest.body preserve=yes
  //## end database::APIAuditEventVisitor::~APIAuditEventVisitor%5898C08B00EC_dest.body
}



//## Other Operations (implementation)
bool APIAuditEventVisitor::insertRow ()
{
  //## begin database::APIAuditEventVisitor::insertRow%5898C2EF00C4.body preserve=yes
   char szTemp[9];
   snprintf(szTemp,sizeof(szTemp),"%d",++m_siSequenceNo);
   m_pTable->set("SEQ_NO", szTemp, true);
   if (!m_pStatement->execute(*m_pTable))
   {
      m_siSequenceNo = -1;
      return false;
   }
   return true;
  //## end database::APIAuditEventVisitor::insertRow%5898C2EF00C4.body
}

bool APIAuditEventVisitor::successful ()
{
  //## begin database::APIAuditEventVisitor::successful%58998197039D.body preserve=yes
   return (m_siSequenceNo != -1);
  //## end database::APIAuditEventVisitor::successful%58998197039D.body
}

void APIAuditEventVisitor::visitColumn (Table* pTable, Column* pColumn)
{
  //## begin database::APIAuditEventVisitor::visitColumn%5898C22F0054.body preserve=yes
   if (!pColumn->modified())
      return;
   // return if transaction already failed on previous event
   if (m_siSequenceNo == -1)
      return;
   m_pTable->set("COLUMN_CHANGED", pColumn->getName());
   m_pTable->set("OLD_VALUE", pColumn->getOldValue());
   m_pTable->set("NEW_VALUE", pColumn->getValue());
   if (!insertRow())
   {
      if (m_pStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
         return;

      short iNull;
      Query hQuery;
      hQuery.bind("API_QUEUE_DATA_CHG", "SEQ_NO", Column::SHORT, &m_siSequenceNo, &iNull, "MAX");
      hQuery.setBasicPredicate("API_QUEUE_DATA_CHG", "TSTAMP_CREATED", "=", Transaction::instance()->getTimeStamp().c_str());
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
      {
         m_siSequenceNo = -1;
         return;
      }
      if (!insertRow())
         return;
   }
  //## end database::APIAuditEventVisitor::visitColumn%5898C22F0054.body
}

// Additional Declarations
  //## begin database::APIAuditEventVisitor%5898C08B00EC.declarations preserve=yes
  //## end database::APIAuditEventVisitor%5898C08B00EC.declarations

} // namespace database

//## begin module%5898C1930010.epilog preserve=yes
//## end module%5898C1930010.epilog
