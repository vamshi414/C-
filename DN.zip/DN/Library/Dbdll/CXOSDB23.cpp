//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3F742F1B01B5.cm preserve=no
//	$Date:   May 14 2020 18:12:12  $ $Author:   e1009510  $ $Revision:   1.11  $
//## end module%3F742F1B01B5.cm

//## begin module%3F742F1B01B5.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%3F742F1B01B5.cp

//## Module: CXOSDB23%3F742F1B01B5; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB23.cpp

//## begin module%3F742F1B01B5.additionalIncludes preserve=no
//## end module%3F742F1B01B5.additionalIncludes

//## begin module%3F742F1B01B5.includes preserve=yes
//## end module%3F742F1B01B5.includes

#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSDB23_h
#include "CXODDB23.hpp"
#endif


//## begin module%3F742F1B01B5.declarations preserve=no
//## end module%3F742F1B01B5.declarations

//## begin module%3F742F1B01B5.additionalDeclarations preserve=yes
//## end module%3F742F1B01B5.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::Password 

Password::Password()
  //## begin Password::Password%3F742DF5035B_const.hasinit preserve=no
  //## end Password::Password%3F742DF5035B_const.hasinit
  //## begin Password::Password%3F742DF5035B_const.initialization preserve=yes
  //## end Password::Password%3F742DF5035B_const.initialization
{
  //## begin database::Password::Password%3F742DF5035B_const.body preserve=yes
   memcpy(m_sID,"DB23",4);
  //## end database::Password::Password%3F742DF5035B_const.body
}


Password::~Password()
{
  //## begin database::Password::~Password%3F742DF5035B_dest.body preserve=yes
  //## end database::Password::~Password%3F742DF5035B_dest.body
}



//## Other Operations (implementation)
bool Password::decrypt (string& strText)
{
  //## begin database::Password::decrypt%3F742E1C01A5.body preserve=yes
   size_t i = (strText.length() > 16) ? 16 : strText.length();
   char sText[17] = {"0000000000000000"};
   memcpy(sText,strText.data(),i);
   unsigned char sCryptogram[9] = {"        "};
   // pack
   char sHex[17] = {"0123456789ABCDEF"};
#ifdef MVS
   CodeTable::translate(sHex,16,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
   char* p = 0;
   i = 0;
   int j = 0;
   unsigned long k = 0;
   for (j = 0;j < 8;++j)
   {
      p = strchr(sHex,sText[i]);
      if (!p)
         return false;
      k = (unsigned long)(p - sHex) * 16;
      ++i;
      p = strchr(sHex,sText[i]);
      if (!p)
         return false;
      ++i;
      k += (unsigned long)(p - sHex);
      sCryptogram[j] = (unsigned char)k;
   }
   if(strText.length() > 1)
      sCryptogram[(strText.length() / 2) - 1] = sCryptogram[(strText.length() / 2) - 1] - 3;
   // left shift by 1 bit
   bool b = (sCryptogram[0] & 0x80);
   if (b)
      sCryptogram[0] = sCryptogram[0] & 0x7F;
   unsigned char sShort[2];
   unsigned short* piShort = (unsigned short*)&sShort[0];
   for (j = 0;j < 8;++j)
   {
#ifdef _LITTLE_ENDIAN
      sShort[0] = sCryptogram[j + 1];
      sShort[1] = sCryptogram[j];
#else
      sShort[0] = sCryptogram[j];
      sShort[1] = sCryptogram[j + 1]; 
#endif
      *piShort = *piShort * 2;
#ifdef _LITTLE_ENDIAN
      sCryptogram[j] = sShort[1];
#else
      sCryptogram[j] = sShort[0];
#endif
   }
   if (b && strText.length() > 1)
      sCryptogram[(strText.length() / 2) - 1] += 1; // high order
   // translate
   char sTable[256];
   j = 255;
   for (i = 0;i < 256;++i)
      sTable[i] = j--;
   sTable[0] = 0x40;
   sTable[191] = 0xFF;
   for (j = 0;j < 8;++j)
   {
      k = sCryptogram[j];
      sCryptogram[j] = sTable[k];
   }
   i = 8;
   while (i > 0 && sCryptogram[i-1] == ' ')
      --i;
#ifdef MVS
   CodeTable::translate((char*)sCryptogram,8,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   strText.assign((char*)sCryptogram,i);
   return true;
  //## end database::Password::decrypt%3F742E1C01A5.body
}

bool Password::encrypt (string& strText)
{
  //## begin database::Password::encrypt%3F742E7B01E4.body preserve=yes
   size_t i = (strText.length() > 8) ? 8 : strText.length();
   unsigned char sBuffer[9] = {"        "};
   memcpy(sBuffer,strText.data(),i);
   // translate
   char sTable[256];
   int j = 255;
   for (i = 0;i < 256;++i)
      sTable[i] = j--;
   sTable[0] = 0x40;
   sTable[191] = 0xFF;
   unsigned int k = 0;
   for (j = 0;j < 8;++j)
   {
      k = sBuffer[j];
      sBuffer[j] = sTable[k];
   }
   // right shift by 1 bit
   bool b = (sBuffer[7] & 0x01);
   if (b)
      sBuffer[7] = sBuffer[7] & 0xFE;
   unsigned char sCryptogram[9] = {"        "};
   unsigned char sShort[2];
   unsigned short* piShort = (unsigned short*)&sShort[0];
   *piShort = 0;
   for (j = 0;j < 8;++j)
   {
#ifdef _LITTLE_ENDIAN
      if (j > 0)
         sShort[1] = sBuffer[j - 1]; // little endian !!!
      sShort[0] = sBuffer[j];
      *piShort = *piShort / 2;
      sCryptogram[j] = sShort[0];
#else
      sShort[1] = sBuffer[j];
      if(j>0)
      	sShort[0] = sBuffer[j - 1]; 
      *piShort = *piShort / 2;
      sCryptogram[j] = sShort[1];
#endif
   }
   if (b)
      sCryptogram[0] |= 0x80; // high order
   sCryptogram[7] = sCryptogram[7] + 3;
   char sText[17] = {"0000000000000000"};
   char sHex[17] = {"0123456789ABCDEF"};
   // unpack
   unsigned char c;
   i = 0;
   for (j = 0;j < 8;++j)
   {
      k = sCryptogram[j];
      k = k / 16;
      c = sCryptogram[j];
      c = c >> 4;
      sText[i++] = sHex[c];
      c = sCryptogram[j];
      c = c << 4;
      c = c >> 4;
      sText[i++] = sHex[c];
   }
   strText = sText;
   return false;
  //## end database::Password::encrypt%3F742E7B01E4.body
}

// Additional Declarations
  //## begin database::Password%3F742DF5035B.declarations preserve=yes
  //## end database::Password%3F742DF5035B.declarations

} // namespace database

//## begin module%3F742F1B01B5.epilog preserve=yes
//## end module%3F742F1B01B5.epilog
