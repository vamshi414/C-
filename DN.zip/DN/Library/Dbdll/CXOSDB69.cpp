//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%647735D00174.cm preserve=no
//## end module%647735D00174.cm

//## begin module%647735D00174.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%647735D00174.cp

//## Module: CXOSDB69%647735D00174; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\ConnexPlatform\Server\Library\Dbdll\CXOSDB69.cpp

//## begin module%647735D00174.additionalIncludes preserve=no
//## end module%647735D00174.additionalIncludes

//## begin module%647735D00174.includes preserve=yes
//## end module%647735D00174.includes

#ifndef CXOSRU09_h
#include "CXODRU09.hpp"
#endif
#ifndef CXOSDB59_h
#include "CXODDB59.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU07_h
#include "CXODRU07.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSDB69_h
#include "CXODDB69.hpp"
#endif


//## begin module%647735D00174.declarations preserve=no
//## end module%647735D00174.declarations

//## begin module%647735D00174.additionalDeclarations preserve=yes
//## end module%647735D00174.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::FileFormatFactory 

//## begin database::FileFormatFactory::Instance%64773488031D.attr preserve=no  private: static database::FileFormatFactory* {U} 0
database::FileFormatFactory* FileFormatFactory::m_pInstance = 0;
//## end database::FileFormatFactory::Instance%64773488031D.attr

FileFormatFactory::FileFormatFactory()
  //## begin FileFormatFactory::FileFormatFactory%6477330102C1_const.hasinit preserve=no
  //## end FileFormatFactory::FileFormatFactory%6477330102C1_const.hasinit
  //## begin FileFormatFactory::FileFormatFactory%6477330102C1_const.initialization preserve=yes
  //## end FileFormatFactory::FileFormatFactory%6477330102C1_const.initialization
{
  //## begin database::FileFormatFactory::FileFormatFactory%6477330102C1_const.body preserve=yes
   memcpy(m_sID,"DB69",4);
  //## end database::FileFormatFactory::FileFormatFactory%6477330102C1_const.body
}


FileFormatFactory::~FileFormatFactory()
{
  //## begin database::FileFormatFactory::~FileFormatFactory%6477330102C1_dest.body preserve=yes
  //## end database::FileFormatFactory::~FileFormatFactory%6477330102C1_dest.body
}



//## Other Operations (implementation)
database::ExportFile* FileFormatFactory::create (const reusable::string& strName)
{
  //## begin database::FileFormatFactory::create%647733830047.body preserve=yes
   map<string,cloneFunction,less<string> >::iterator p = m_hReport.find(strName);
   if (p == m_hReport.end())
      return 0;
   return (*p).second();
  //## end database::FileFormatFactory::create%647733830047.body
}

database::FileFormatFactory* FileFormatFactory::instance ()
{
  //## begin database::FileFormatFactory::instance%647733CB0307.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new FileFormatFactory();
   return m_pInstance;
  //## end database::FileFormatFactory::instance%647733CB0307.body
}

bool FileFormatFactory::registerReport (const reusable::string& strName, cloneFunction hCloneFunction)
{
  //## begin database::FileFormatFactory::registerReport%64773401012C.body preserve=yes
   m_hReport[strName] = hCloneFunction;
   return true;
  //## end database::FileFormatFactory::registerReport%64773401012C.body
}

// Additional Declarations
  //## begin database::FileFormatFactory%6477330102C1.declarations preserve=yes
  //## end database::FileFormatFactory%6477330102C1.declarations

} // namespace database

//## begin module%647735D00174.epilog preserve=yes
//## end module%647735D00174.epilog
