//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4B070B1901B3.cm preserve=no
//	$Date:   Feb 22 2021 10:06:46  $ $Author:   e1009652  $ $Revision:   1.7  $
//## end module%4B070B1901B3.cm

//## begin module%4B070B1901B3.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4B070B1901B3.cp

//## Module: CXOSDB39%4B070B1901B3; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.1A.R011\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB39.hpp

#ifndef CXOSDB39_h
#define CXOSDB39_h 1

//## begin module%4B070B1901B3.additionalIncludes preserve=no
//## end module%4B070B1901B3.additionalIncludes

//## begin module%4B070B1901B3.includes preserve=yes
//## end module%4B070B1901B3.includes

#ifndef CXOSDB37_h
#include "CXODDB37.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;

} // namespace IF

//## begin module%4B070B1901B3.declarations preserve=no
//## end module%4B070B1901B3.declarations

//## begin module%4B070B1901B3.additionalDeclarations preserve=yes
//## end module%4B070B1901B3.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::IBMKey%4B070ADF01DC.preface preserve=yes
//## end database::IBMKey%4B070ADF01DC.preface

//## Class: IBMKey%4B070ADF01DC
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4B1423460367;IF::Trace { -> F}

class DllExport IBMKey : public DESKey  //## Inherits: <unnamed>%4B070AF501AE
{
  //## begin database::IBMKey%4B070ADF01DC.initialDeclarations preserve=yes
  //## end database::IBMKey%4B070ADF01DC.initialDeclarations

  public:
    //## Constructors (generated)
      IBMKey();

    //## Destructor (generated)
      virtual ~IBMKey();


    //## Other Operations (specified)
      //## Operation: addKey%4C45DF8F002E
      bool addKey (const string& strKeyId, const string& strKey);

      //## Operation: decrypt%4B070B9503A7
      virtual bool decrypt (string& strText);

      //## Operation: decryptAES%6033CC8700CF
      bool decryptAES (unsigned char* pCipherText, int iCipherLength, unsigned char* pClearText);

      //## Operation: deleteKey%4C45E87F0101
      bool deleteKey (const string& strKeyId);

      //## Operation: encrypt%4B070B9503BB
      virtual bool encrypt (string& strText);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Label%6033CEDB0043
      const string& getLabel () const
      {
        //## begin database::IBMKey::getLabel%6033CEDB0043.get preserve=no
        return m_strLabel;
        //## end database::IBMKey::getLabel%6033CEDB0043.get
      }

      void setLabel (const string& value)
      {
        //## begin database::IBMKey::setLabel%6033CEDB0043.set preserve=no
        m_strLabel = value;
        m_strLabel.resize(64,' ');
        //## end database::IBMKey::setLabel%6033CEDB0043.set
      }


    // Additional Public Declarations
      //## begin database::IBMKey%4B070ADF01DC.public preserve=yes
      //## end database::IBMKey%4B070ADF01DC.public
  protected:
    // Additional Protected Declarations
      //## begin database::IBMKey%4B070ADF01DC.protected preserve=yes
      //## end database::IBMKey%4B070ADF01DC.protected

  private:

    //## Other Operations (specified)
      //## Operation: csnbCKM%4C45DF250128
      bool csnbCKM (const string& strKeyLabel);

      //## Operation: csnbKRC%4B26895C01D6
      int csnbKRC ();

      //## Operation: csnbKRD%4C45E8190053
      bool csnbKRD (const string& strKeyLabel);

      //## Operation: csnbKRW%4B2689800222
      bool csnbKRW ();

    // Additional Private Declarations
      //## begin database::IBMKey%4B070ADF01DC.private preserve=yes
      //## end database::IBMKey%4B070ADF01DC.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: KeyToken%4B47837402D6
      //## begin database::IBMKey::KeyToken%4B47837402D6.attr preserve=no  private: char[64] {U} 
      char m_szKeyToken[64];
      //## end database::IBMKey::KeyToken%4B47837402D6.attr

      //## begin database::IBMKey::Label%6033CEDB0043.attr preserve=no  public: string {U} 
      string m_strLabel;
      //## end database::IBMKey::Label%6033CEDB0043.attr

    // Additional Implementation Declarations
      //## begin database::IBMKey%4B070ADF01DC.implementation preserve=yes
      //## end database::IBMKey%4B070ADF01DC.implementation

};

//## begin database::IBMKey%4B070ADF01DC.postscript preserve=yes
//## end database::IBMKey%4B070ADF01DC.postscript

} // namespace database

//## begin module%4B070B1901B3.epilog preserve=yes
//## end module%4B070B1901B3.epilog


#endif
