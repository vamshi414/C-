//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63A3CF1C03AD.cm preserve=no
//## end module%63A3CF1C03AD.cm

//## begin module%63A3CF1C03AD.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63A3CF1C03AD.cp

//## Module: CXOSDB68%63A3CF1C03AD; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB68.cpp

//## begin module%63A3CF1C03AD.additionalIncludes preserve=no
//## end module%63A3CF1C03AD.additionalIncludes

//## begin module%63A3CF1C03AD.includes preserve=yes
//## end module%63A3CF1C03AD.includes

#ifndef CXOSDB68_h
#include "CXODDB68.hpp"
#endif
//## begin module%63A3CF1C03AD.declarations preserve=no
//## end module%63A3CF1C03AD.declarations

//## begin module%63A3CF1C03AD.additionalDeclarations preserve=yes
//## end module%63A3CF1C03AD.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::NetworkReportFactory 

//## begin database::NetworkReportFactory::Instance%5C40AEBE01A0.attr preserve=no  private: static database::NetworkReportFactory* {V} 0
database::NetworkReportFactory* NetworkReportFactory::m_pInstance = 0;
//## end database::NetworkReportFactory::Instance%5C40AEBE01A0.attr

NetworkReportFactory::NetworkReportFactory()
  //## begin NetworkReportFactory::NetworkReportFactory%5C3F9788036D_const.hasinit preserve=no
  //## end NetworkReportFactory::NetworkReportFactory%5C3F9788036D_const.hasinit
  //## begin NetworkReportFactory::NetworkReportFactory%5C3F9788036D_const.initialization preserve=yes
  //## end NetworkReportFactory::NetworkReportFactory%5C3F9788036D_const.initialization
{
  //## begin database::NetworkReportFactory::NetworkReportFactory%5C3F9788036D_const.body preserve=yes
   memcpy(m_sID,"DB68",4);
  //## end database::NetworkReportFactory::NetworkReportFactory%5C3F9788036D_const.body
}


NetworkReportFactory::~NetworkReportFactory()
{
  //## begin database::NetworkReportFactory::~NetworkReportFactory%5C3F9788036D_dest.body preserve=yes
  //## end database::NetworkReportFactory::~NetworkReportFactory%5C3F9788036D_dest.body
}



//## Other Operations (implementation)
Object* NetworkReportFactory::create (const char* sBuffer, int iRecordLength, const string& strFileName)
{
  //## begin database::NetworkReportFactory::create%5C3F9B68037B.body preserve=yes
   map<string,cloneFunction,less<string> >::iterator p;
   Object* q = 0;
   for (p = m_hNetworkReport.begin();p != m_hNetworkReport.end();p++)
   {
      q = (*p).second(sBuffer, iRecordLength, strFileName);
      if (q != 0)
         break;
   }
   return q;
  //## end database::NetworkReportFactory::create%5C3F9B68037B.body
}

NetworkReportFactory* NetworkReportFactory::instance ()
{
  //## begin database::NetworkReportFactory::instance%5C40AED401B7.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new NetworkReportFactory();
   return m_pInstance;
  //## end database::NetworkReportFactory::instance%5C40AED401B7.body
}

bool NetworkReportFactory::registerReport (const reusable::string& strName, cloneFunction hCloneFunction)
{
  //## begin database::NetworkReportFactory::registerReport%5C3F99EA0097.body preserve=yes
   m_hNetworkReport[strName] = hCloneFunction;
   return true;
  //## end database::NetworkReportFactory::registerReport%5C3F99EA0097.body
}

// Additional Declarations
  //## begin database::NetworkReportFactory%5C3F9788036D.declarations preserve=yes
  //## end database::NetworkReportFactory%5C3F9788036D.declarations

} // namespace database

//## begin module%63A3CF1C03AD.epilog preserve=yes
//## end module%63A3CF1C03AD.epilog
