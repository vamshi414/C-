//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C8C0A8A030E.cm preserve=no
//	$Date:   Oct 07 2019 14:55:14  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5C8C0A8A030E.cm

//## begin module%5C8C0A8A030E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C8C0A8A030E.cp

//## Module: CXOSDB64%5C8C0A8A030E; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB64.hpp

#ifndef CXOSDB64_h
#define CXOSDB64_h 1

//## begin module%5C8C0A8A030E.additionalIncludes preserve=no
//## end module%5C8C0A8A030E.additionalIncludes

//## begin module%5C8C0A8A030E.includes preserve=yes
//## end module%5C8C0A8A030E.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Memory;

} // namespace IF

//## begin module%5C8C0A8A030E.declarations preserve=no
//## end module%5C8C0A8A030E.declarations

//## begin module%5C8C0A8A030E.additionalDeclarations preserve=yes
//## end module%5C8C0A8A030E.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::MultiArray%5C8C09E50039.preface preserve=yes
//## end database::MultiArray%5C8C09E50039.preface

//## Class: MultiArray%5C8C09E50039
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport MultiArray : public reusable::Object  //## Inherits: <unnamed>%5C8C0A0A037F
{
  //## begin database::MultiArray%5C8C09E50039.initialDeclarations preserve=yes
  //## end database::MultiArray%5C8C09E50039.initialDeclarations

  public:
    //## Constructors (generated)
      MultiArray();

    //## Destructor (generated)
      virtual ~MultiArray();


    //## Other Operations (specified)
      //## Operation: append%5C8C12160156
      void append (const char* psEntry);

      //## Operation: clear%5C91876803D8
      void clear ();

      //## Operation: find%5C8C10B401B6
      const char* find (const char* psKey);

      //## Operation: findFirst%5D9B82B4016C
      const char* findFirst (const char* psKey);

      //## Operation: getNext%5D9B82E00380
      const char* getNext (const char* psBuffer);

      //## Operation: insert%5C8C12330232
      const char* insert (const char* psEntry);

      //## Operation: reserve%5C8C106F032D
      void reserve (int iReserve, int iSize, int iKey);

    // Additional Public Declarations
      //## begin database::MultiArray%5C8C09E50039.public preserve=yes
      //## end database::MultiArray%5C8C09E50039.public

  protected:
    // Additional Protected Declarations
      //## begin database::MultiArray%5C8C09E50039.protected preserve=yes
      //## end database::MultiArray%5C8C09E50039.protected

  private:
    // Additional Private Declarations
      //## begin database::MultiArray%5C8C09E50039.private preserve=yes
      //## end database::MultiArray%5C8C09E50039.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Count%5C8C11BE01CE
      //## begin database::MultiArray::Count%5C8C11BE01CE.attr preserve=no  private: int {V} 0
      int m_iCount;
      //## end database::MultiArray::Count%5C8C11BE01CE.attr

      //## Attribute: Key%5C8C10E102DD
      //## begin database::MultiArray::Key%5C8C10E102DD.attr preserve=no  private: int {V} 0
      int m_iKey;
      //## end database::MultiArray::Key%5C8C10E102DD.attr

      //## Attribute: Reserve%5C8C11BE038F
      //## begin database::MultiArray::Reserve%5C8C11BE038F.attr preserve=no  private: int {V} 0
      int m_iReserve;
      //## end database::MultiArray::Reserve%5C8C11BE038F.attr

      //## Attribute: Size%5C8C11D80110
      //## begin database::MultiArray::Size%5C8C11D80110.attr preserve=no  private: int {V} 0
      int m_iSize;
      //## end database::MultiArray::Size%5C8C11D80110.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%5D9B8BDC00B3
      //## Role: MultiArray::<m_pMemory>%5D9B8BDC02F3
      //## begin database::MultiArray::<m_pMemory>%5D9B8BDC02F3.role preserve=no  public: IF::Memory { -> RFHgN}
      IF::Memory *m_pMemory;
      //## end database::MultiArray::<m_pMemory>%5D9B8BDC02F3.role

    // Additional Implementation Declarations
      //## begin database::MultiArray%5C8C09E50039.implementation preserve=yes
      //## end database::MultiArray%5C8C09E50039.implementation

};

//## begin database::MultiArray%5C8C09E50039.postscript preserve=yes
//## end database::MultiArray%5C8C09E50039.postscript

} // namespace database

//## begin module%5C8C0A8A030E.epilog preserve=yes
//## end module%5C8C0A8A030E.epilog


#endif
