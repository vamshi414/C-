//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36224C11033F.cm preserve=no
//	$Date:   Aug 19 2021 23:27:00  $ $Author:   e1014059  $
//	$Revision:   1.10  $
//## end module%36224C11033F.cm

//## begin module%36224C11033F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%36224C11033F.cp

//## Module: CXOSDB05%36224C11033F; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB05.cpp

//## begin module%36224C11033F.additionalIncludes preserve=no
//## end module%36224C11033F.additionalIncludes

//## begin module%36224C11033F.includes preserve=yes
//## end module%36224C11033F.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif


//## begin module%36224C11033F.declarations preserve=no
//## end module%36224C11033F.declarations

//## begin module%36224C11033F.additionalDeclarations preserve=yes
#define STS_RECORD_NOT_FOUND 14
//## end module%36224C11033F.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::Context 

Context::Context()
  //## begin Context::Context%3479E7B002B5_const.hasinit preserve=no
      : m_strQualifier("CUSTQUAL")
  //## end Context::Context%3479E7B002B5_const.hasinit
  //## begin Context::Context%3479E7B002B5_const.initialization preserve=yes
  //## end Context::Context%3479E7B002B5_const.initialization
{
  //## begin database::Context::Context%3479E7B002B5_const.body preserve=yes
   memcpy(m_sID,"DB05",4);
  //## end database::Context::Context%3479E7B002B5_const.body
}

Context::Context (const string& strImage, const string& strTask)
  //## begin database::Context::Context%3479FA9A02C1.hasinit preserve=no
      : m_strQualifier("CUSTQUAL")
  //## end database::Context::Context%3479FA9A02C1.hasinit
  //## begin database::Context::Context%3479FA9A02C1.initialization preserve=yes
   ,m_strImage(strImage != "*" ? "I01/" : strImage)
   ,m_strTask(strTask)
  //## end database::Context::Context%3479FA9A02C1.initialization
{
  //## begin database::Context::Context%3479FA9A02C1.body preserve=yes
   memcpy(m_sID,"DB05",4);
  //## end database::Context::Context%3479FA9A02C1.body
}


Context::~Context()
{
  //## begin database::Context::~Context%3479E7B002B5_dest.body preserve=yes
  //## end database::Context::~Context%3479E7B002B5_dest.body
}



//## Other Operations (implementation)
bool Context::get (const char* pszKey, string& strData, char cType, const char* pszFunction)
{
  //## begin database::Context::get%3479F1BD02F1.body preserve=yes
   char szCONTEXT_TYPE[2] = {" "};
   szCONTEXT_TYPE[0] = cType;
   strData.erase();
   short iNull = 0;
   Query hQuery;
   hQuery.setQualifier(m_strQualifier.c_str(),"TASK_CONTEXT");
   if (pszFunction[0] != '\0')
      hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",Column::STRING,&strData,&iNull,pszFunction);
   else
      hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",Column::STRING,&strData);
   if (m_strImage.length())
      hQuery.setBasicPredicate("TASK_CONTEXT","IMAGEID","=",m_strImage.c_str());
   if (m_strTask.length())
      hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=",m_strTask.c_str());
   if (pszKey[0] != '\0')
      hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_KEY","=",pszKey);
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=",szCONTEXT_TYPE);
   auto_ptr<SelectStatement> pSelectStatement ((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(hQuery);
   Database::instance()->setTransactionState(b ? Database::COMMITREQUIRED : Database::ROLLBACKREQUIRED);
   return b;
  //## end database::Context::get%3479F1BD02F1.body
}

bool Context::put (const char* pszKey, const char* pszData, char cType)
{
  //## begin database::Context::put%3479F1CB0283.body preserve=yes
   char szCONTEXT_TYPE[2] = {" "};
   szCONTEXT_TYPE[0] = cType;
   Table hTable("TASK_CONTEXT");
   hTable.setQualifier(m_strQualifier);
   hTable.set("CONTEXT_DATA",pszData,false,false);
   hTable.set("IMAGEID",m_strImage.c_str(),false,true);
   hTable.set("TASKID",m_strTask.c_str(),false,true);
   hTable.set("CONTEXT_TYPE",szCONTEXT_TYPE,false,true);
   hTable.set("CONTEXT_KEY",pszKey,false,true);
   auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   bool b = pUpdateStatement->execute(hTable);
   if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
   {
      auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      b = pInsertStatement->execute(hTable);
   }
   Database::instance()->setTransactionState(b ? Database::COMMITREQUIRED : Database::ROLLBACKREQUIRED);
   return b;
  //## end database::Context::put%3479F1CB0283.body
}

bool Context::remove (const char* pszKey, char cType)
{
  //## begin database::Context::remove%5BBE188201D0.body preserve=yes
   char szCONTEXT_TYPE[2] = {" "};
   szCONTEXT_TYPE[0] = cType;
   reusable::Query hQuery;
   hQuery.setBasicPredicate("TASK_CONTEXT","IMAGEID","=",m_strImage.c_str());
   hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=",m_strTask.c_str());
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=",szCONTEXT_TYPE);
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_KEY","=",pszKey);
   auto_ptr<reusable::SelectStatement> pDeleteStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("DeleteStatement"));
   bool b = pDeleteStatement->execute(hQuery);
   Database::instance()->setTransactionState(b ? Database::COMMITREQUIRED : Database::ROLLBACKREQUIRED);
   return b;
  //## end database::Context::remove%5BBE188201D0.body
}

// Additional Declarations
  //## begin database::Context%3479E7B002B5.declarations preserve=yes
  //## end database::Context%3479E7B002B5.declarations

} // namespace database

//## begin module%36224C11033F.epilog preserve=yes
//## end module%36224C11033F.epilog
