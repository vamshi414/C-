//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%40A8FE8F03B9.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%40A8FE8F03B9.cm

//## begin module%40A8FE8F03B9.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%40A8FE8F03B9.cp

//## Module: CXOSDB04%40A8FE8F03B9; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB04.hpp

#ifndef CXOSDB04_h
#define CXOSDB04_h 1

//## begin module%40A8FE8F03B9.additionalIncludes preserve=no
//## end module%40A8FE8F03B9.additionalIncludes

//## begin module%40A8FE8F03B9.includes preserve=yes
#include <memory>
//## end module%40A8FE8F03B9.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSDB66_h
#include "CXODDB66.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Console;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

namespace IF {
class VariableBlockFile;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Context;
} // namespace database

//## Modelname: Connex Library::SecurityWrapper_CAT (SWDLL)%4A09A922013D
namespace securitywrapper {
class SecurityWrapper;

} // namespace securitywrapper

//## begin module%40A8FE8F03B9.declarations preserve=no
//## end module%40A8FE8F03B9.declarations

//## begin module%40A8FE8F03B9.additionalDeclarations preserve=yes
//## end module%40A8FE8F03B9.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::GenerationDataGroup%40A8FDA4029F.preface preserve=yes
//## end database::GenerationDataGroup%40A8FDA4029F.preface

//## Class: GenerationDataGroup%40A8FDA4029F
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%40A9F3C40242;Context { -> F}
//## Uses: <unnamed>%40AA39CA03C8;IF::Extract { -> F}
//## Uses: <unnamed>%43BFF6EF0186;timer::Clock { -> F}
//## Uses: <unnamed>%44C4C5B5003E;IF::Console { -> F}
//## Uses: <unnamed>%4548F89201E4;IF::VariableBlockFile { -> F}
//## Uses: <unnamed>%5344058C03B5;IF::Trace { -> F}
//## Uses: <unnamed>%534405D60305;reusable::Buffer { -> F}
//## Uses: <unnamed>%5F91D50803C2;securitywrapper::SecurityWrapper { -> F}

class DllExport GenerationDataGroup : public reusable::Observer  //## Inherits: <unnamed>%45589E14008C
{
  //## begin database::GenerationDataGroup%40A8FDA4029F.initialDeclarations preserve=yes
  //## end database::GenerationDataGroup%40A8FDA4029F.initialDeclarations

  public:
    //## Constructors (generated)
      GenerationDataGroup();

    //## Constructors (specified)
      //## Operation: GenerationDataGroup%40A9F6D8000F
      GenerationDataGroup (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlock = false);

    //## Destructor (generated)
      virtual ~GenerationDataGroup();


    //## Other Operations (specified)
      //## Operation: checkPoint%418F882601B5
      bool checkPoint (int iOffset = 0);

      //## Operation: close%45828B55014F
      void close ();

      //## Operation: commit%40AA06C10280
      virtual bool commit ();

      //## Operation: datasetName%4548FC70000F
      const string& datasetName ();

      //## Operation: getName%45490593008C
      const string& getName ();

      //## Operation: getRecordCount%5F91DA2B03A4
      int getRecordCount ();

      //## Operation: getSize%40A9FD080399
      bool getSize (int* plRecordCount, size_t* plByteCount, size_t* plMaxRecordLength, bool bTruncate = false);

      //## Operation: open%40A9F3B202CE
      virtual bool open (enum FlatFile::OpenType nOpenType = FlatFile::CX_OPEN_INPUT,bool* pbDuplicate = 0, bool* pbEmpty = 0);

      //## Operation: read%418F8822036B
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward = false, bool bTruncate = false);

      //## Operation: rollback%4D88FB7F03B5
      bool rollback ();

      //## Operation: update%4558A1100119
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: CONTEXT_KEY%40A9F7680203
      const reusable::string& getCONTEXT_KEY () const
      {
        //## begin database::GenerationDataGroup::getCONTEXT_KEY%40A9F7680203.get preserve=no
        return m_strCONTEXT_KEY;
        //## end database::GenerationDataGroup::getCONTEXT_KEY%40A9F7680203.get
      }


      //## Attribute: Progress%40AE0DAA02DE
      const int getProgress () const
      {
        //## begin database::GenerationDataGroup::getProgress%40AE0DAA02DE.get preserve=no
        return m_lProgress;
        //## end database::GenerationDataGroup::getProgress%40AE0DAA02DE.get
      }


      //## Attribute: ReadError%484CD2480198
      const bool getReadError () const
      {
        //## begin database::GenerationDataGroup::getReadError%484CD2480198.get preserve=no
        return m_bReadError;
        //## end database::GenerationDataGroup::getReadError%484CD2480198.get
      }

      void setReadError (bool value)
      {
        //## begin database::GenerationDataGroup::setReadError%484CD2480198.set preserve=no
        m_bReadError = value;
        //## end database::GenerationDataGroup::setReadError%484CD2480198.set
      }


      //## Attribute: Timestamp%43BFDFF1007D
      const reusable::string& getTimestamp () const
      {
        //## begin database::GenerationDataGroup::getTimestamp%43BFDFF1007D.get preserve=no
        return m_strTimestamp;
        //## end database::GenerationDataGroup::getTimestamp%43BFDFF1007D.get
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::Database_CAT::<unnamed>%46926CBE007D
      //## Role: GenerationDataGroup::<m_pFile>%46926CBE031C
      IF::FlatFile * getFlatFile ()
      {
        //## begin database::GenerationDataGroup::getFlatFile%46926CBE031C.get preserve=no
        return m_pFile;
        //## end database::GenerationDataGroup::getFlatFile%46926CBE031C.get
      }


      //## Association: Connex Library::Database_CAT::<unnamed>%5EC221600082
      //## Role: GenerationDataGroup::<m_hGeneration>%5EC2216100C8
      Generation& getGeneration ()
      {
        //## begin database::GenerationDataGroup::getGeneration%5EC2216100C8.get preserve=no
        return m_hGeneration;
        //## end database::GenerationDataGroup::getGeneration%5EC2216100C8.get
      }


    // Additional Public Declarations
      //## begin database::GenerationDataGroup%40A8FDA4029F.public preserve=yes
      virtual bool read (char* psBuffer, int lBufferLength, int* plRecordLength, bool bFastForward = false, bool bTruncate = false);
      void setRecordFormat(const string& strRecordFormat)
      {
         m_pFile->setRecordFormat(strRecordFormat);
      }

      //## end database::GenerationDataGroup%40A8FDA4029F.public
  protected:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: IMAGEID%40AA17CA01A5
      const reusable::string& getIMAGEID () const
      {
        //## begin database::GenerationDataGroup::getIMAGEID%40AA17CA01A5.get preserve=no
        return m_strIMAGEID;
        //## end database::GenerationDataGroup::getIMAGEID%40AA17CA01A5.get
      }


      //## Attribute: TASKID%40AA17CA029F
      const reusable::string& getTASKID () const
      {
        //## begin database::GenerationDataGroup::getTASKID%40AA17CA029F.get preserve=no
        return m_strTASKID;
        //## end database::GenerationDataGroup::getTASKID%40AA17CA029F.get
      }


    // Data Members for Class Attributes

      //## Attribute: Number%40AA13CA034B
      //## begin database::GenerationDataGroup::Number%40AA13CA034B.attr preserve=no  public: int {V} 0
      int m_lNumber;
      //## end database::GenerationDataGroup::Number%40AA13CA034B.attr

      //## begin database::GenerationDataGroup::Progress%40AE0DAA02DE.attr preserve=no  public: int {V} 0
      int m_lProgress;
      //## end database::GenerationDataGroup::Progress%40AE0DAA02DE.attr

      //## begin database::GenerationDataGroup::ReadError%484CD2480198.attr preserve=no  public: bool {V} false
      bool m_bReadError;
      //## end database::GenerationDataGroup::ReadError%484CD2480198.attr

    // Additional Protected Declarations
      //## begin database::GenerationDataGroup%40A8FDA4029F.protected preserve=yes
      //## end database::GenerationDataGroup%40A8FDA4029F.protected

  private:
    // Additional Private Declarations
      //## begin database::GenerationDataGroup%40A8FDA4029F.private preserve=yes
      //## end database::GenerationDataGroup%40A8FDA4029F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin database::GenerationDataGroup::CONTEXT_KEY%40A9F7680203.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strCONTEXT_KEY;
      //## end database::GenerationDataGroup::CONTEXT_KEY%40A9F7680203.attr

      //## begin database::GenerationDataGroup::IMAGEID%40AA17CA01A5.attr preserve=no  protected: reusable::string {V} 
      reusable::string m_strIMAGEID;
      //## end database::GenerationDataGroup::IMAGEID%40AA17CA01A5.attr

      //## begin database::GenerationDataGroup::TASKID%40AA17CA029F.attr preserve=no  protected: reusable::string {V} 
      reusable::string m_strTASKID;
      //## end database::GenerationDataGroup::TASKID%40AA17CA029F.attr

      //## begin database::GenerationDataGroup::Timestamp%43BFDFF1007D.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strTimestamp;
      //## end database::GenerationDataGroup::Timestamp%43BFDFF1007D.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%46926CBE007D
      //## begin database::GenerationDataGroup::<m_pFile>%46926CBE031C.role preserve=no  public: IF::FlatFile { -> RHgN}
      IF::FlatFile *m_pFile;
      //## end database::GenerationDataGroup::<m_pFile>%46926CBE031C.role

      //## Association: Connex Library::Database_CAT::<unnamed>%5EC221600082
      //## begin database::GenerationDataGroup::<m_hGeneration>%5EC2216100C8.role preserve=no  public: database::Generation { -> VHgN}
      Generation m_hGeneration;
      //## end database::GenerationDataGroup::<m_hGeneration>%5EC2216100C8.role

    // Additional Implementation Declarations
      //## begin database::GenerationDataGroup%40A8FDA4029F.implementation preserve=yes
      //## end database::GenerationDataGroup%40A8FDA4029F.implementation

};

//## begin database::GenerationDataGroup%40A8FDA4029F.postscript preserve=yes
//## end database::GenerationDataGroup%40A8FDA4029F.postscript

} // namespace database

//## begin module%40A8FE8F03B9.epilog preserve=yes
using namespace database;
//## end module%40A8FE8F03B9.epilog


#endif
