//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%53F3392F0287.cm preserve=no
//## end module%53F3392F0287.cm

//## begin module%53F3392F0287.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%53F3392F0287.cp

//## Module: CXOSDB47%53F3392F0287; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB47.cpp

//## begin module%53F3392F0287.additionalIncludes preserve=no
//## end module%53F3392F0287.additionalIncludes

//## begin module%53F3392F0287.includes preserve=yes
#include <vector>
//## end module%53F3392F0287.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXODDB51_h
#include "CXODDB51.hpp"
#endif
#ifndef CXOSDB47_h
#include "CXODDB47.hpp"
#endif


//## begin module%53F3392F0287.declarations preserve=no
//## end module%53F3392F0287.declarations

//## begin module%53F3392F0287.additionalDeclarations preserve=yes
//## end module%53F3392F0287.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::View 

View::View()
  //## begin View::View%53F3383D020C_const.hasinit preserve=no
      : m_iIndex(0)
  //## end View::View%53F3383D020C_const.hasinit
  //## begin View::View%53F3383D020C_const.initialization preserve=yes
  //## end View::View%53F3383D020C_const.initialization
{
  //## begin database::View::View%53F3383D020C_const.body preserve=yes
  //## end database::View::View%53F3383D020C_const.body
}

View::View (const char* pszZOSMember, const char* pszOpenMember)
  //## begin database::View::View%53F34A290126.hasinit preserve=no
      : m_iIndex(0)
  //## end database::View::View%53F34A290126.hasinit
  //## begin database::View::View%53F34A290126.initialization preserve=yes
  //## end database::View::View%53F34A290126.initialization
{
  //## begin database::View::View%53F34A290126.body preserve=yes

#ifdef MVS
   FlatFile hFlatFile("JCL",pszZOSMember);
#else
   FlatFile hFlatFile("SOURCE",pszOpenMember);
#endif
   string strParent;
   string strTag;
   vector<string> hTag;
   string strTable;
   string strColumn;
   string strSynonym;
   int iNPI = 0;
   char sBuffer[256];
   bool bErase = false;
   size_t m = 0;
   while (hFlatFile.read(sBuffer,256,&m))
   {
      int k = m;
      while (k > 0
         && sBuffer[k - 1] == ' ')
         --k;
      sBuffer[k] = '\0';
      if (!memcmp(sBuffer, "CREATE TABLE ", 13))
      {
         char* p = strchr(sBuffer, '.');
         if (p)
         {
            ++p;
            if (*p == '.')
               ++p;
            strTable.assign(p);
            size_t pos = strTable.find_last_not_of(" ");
            if (pos != string::npos)
               strTable.erase(pos + 1);
            pos = strTable.find('&');
            if (pos != string::npos)
               strTable.erase(pos);
            m_hTable.insert(strTable);
            hTag.erase(hTag.begin(), hTag.end());
         }
      }
      else
      if (!memcmp(sBuffer, "CREATE ", 7))
         strTable.clear();
      else
      if (!memcmp(sBuffer," /* @",5))
      {
         string strBuffer(sBuffer + 5);
         vector<string> hTokens;
         Buffer::parse(strBuffer,",;",hTokens);
         if (hTokens.size() > 2)
         {
            int j = 0; // MINUTE
            if (hTokens[2] == "HOUR")
               j = 1;
            else
            if (hTokens[2] == "MONTH")
               j = 2;
            m_hIndexColumns[hTokens[0]] = make_pair(atoi(hTokens[1].c_str()),j);
         }
      }
      else
      if (!memcmp(sBuffer," /* +",5))
      {
         strParent.assign(sBuffer + 5,m - 5);
         size_t pos = strParent.find(" */");
         if (pos != string::npos)
            strParent.erase(pos);
         vector<string> hTokens;
         Buffer::parse(strParent," ",hTokens);
         strParent = hTokens[0];
         m_hHeader.insert(strParent);
         if (hTokens.size() == 2)
            m_hPrefix.insert(map<string,string,less<string> >::value_type(hTokens[0],hTokens[1]));
      }
      else
      if (!memcmp(sBuffer," /* -",5))
      {
         if (bErase)
            hTag.erase(hTag.begin(),hTag.end());
         strTag.assign(sBuffer + 5,m - 5);
         string strBuffer(sBuffer + 5);
         vector<string> hTokens;
         Buffer::parse(strBuffer,",;",hTokens);
         strTag = hTokens[0];
         size_t pos = strTag.find(" */");
         if (pos != string::npos)
            strTag.erase(pos);
         pos = strTag.find(':');
         if (pos != string::npos)
            strTag.erase(0,pos + 1);
         hTag.push_back(strTag);
         bErase = false;
         iNPI = 0;
         int i = 1;
         while (i < hTokens.size())
         {
            if (hTokens[i][0] == '#')
            {
               iNPI = hTokens[i][1] - '0';
               break;
            }
            else if (hTokens[i][0] == '<' && hTokens[i][hTokens[i].length() - 1] == '>')
            {
               hTokens[i].erase(0,1);
               hTokens[i].resize(hTokens[i].length() - 1);
               m_hSegment24Tokens.insert(map<string,string, less<string> >::value_type(strTag,hTokens[i]));
               break;
            }
            i++;
         }
      }
      else
      if (!memcmp(sBuffer," /* */",6))
      {
         hTag.erase(hTag.begin(),hTag.end());
      }
      else
      if (!memcmp(sBuffer," /* |",5))
      {
         strSynonym.assign(sBuffer + 5,m - 5);
         size_t pos = strSynonym.find(" */");
         if (pos != string::npos)
            strSynonym.erase(pos);
      }
      else
      if ((hTag.empty() == false
          || strSynonym.empty() == false)
         && strTable.empty() == false
         && memcmp(sBuffer,"       ",7) == 0)
      {
         strColumn.assign(sBuffer + 7,m - 7);
         size_t pos = strColumn.find(' ');
         if (pos != string::npos)
            strColumn.erase(pos);
         if (strstr(sBuffer," CHAR(") == 0
            && strstr(sBuffer," VARCHAR(") == 0)
            m_hNumericColumns.insert(strColumn);
         if (strSynonym.empty() == false)
         {
            string strFirst(strParent);
            strFirst += ':';
            strFirst += strSynonym;
            m_hSynonyms.insert(multimap<string,database::Column,less<string> >::value_type(strFirst,database::Column(strTable,strColumn,iNPI)));
            strSynonym.erase();
         }
         vector<string>::iterator p;
         for (p = hTag.begin();p != hTag.end();++p)
         {
            string strFirst(strParent);
            strFirst += ':';
            strFirst += (*p);
            m_hTag.insert(multimap<string,database::Column,less<string> >::value_type(strFirst,database::Column(strTable,strColumn,iNPI)));
         }
         bErase = true;
      }
      else
      if (!memcmp(sBuffer," /* ^",5))
      {
         string strTemp;
         strTemp.assign(sBuffer + 5,m - 5);
         size_t pos = strTemp.find(" ^*/");
         if (pos != string::npos)
            strTemp.erase(pos);
         m_hOneToMany.insert(strTemp);
      }
   }
  //## end database::View::View%53F34A290126.body
}


View::~View()
{
  //## begin database::View::~View%53F3383D020C_dest.body preserve=yes
  //## end database::View::~View%53F3383D020C_dest.body
}



//## Other Operations (implementation)
void View::bind (Query& hQuery, const string& strParent, const string& strTag, int iNPI)
{
  //## begin database::View::bind%53F33ECA0305.body preserve=yes
  //## end database::View::bind%53F33ECA0305.body
}

const map<string,set<string,less<string> >,less<string> >& View::getChild ()
{
  //## begin database::View::getChild%52C2BD5A030D.body preserve=yes
   return m_hChild;
  //## end database::View::getChild%52C2BD5A030D.body
}

const set<string,less<string> >& View::getHeader ()
{
  //## begin database::View::getHeader%66005F0C02AE.body preserve=yes
   return m_hHeader;
  //## end database::View::getHeader%66005F0C02AE.body
}

const set<string,less<string> >& View::getOneToMany ()
{
  //## begin database::View::getOneToMany%66005F1D0249.body preserve=yes
   return m_hOneToMany;
  //## end database::View::getOneToMany%66005F1D0249.body
}

const set<string,less<string> >& View::getParent ()
{
  //## begin database::View::getParent%524C1E1A0366.body preserve=yes
   return m_hParent;
  //## end database::View::getParent%524C1E1A0366.body
}

const map<string, string, less<string> >& View::getSegment24Tokens ()
{
  //## begin database::View::getSegment24Tokens%66005DE80153.body preserve=yes
   return m_hSegment24Tokens;
  //## end database::View::getSegment24Tokens%66005DE80153.body
}

void View::join (Query& hQuery)
{
  //## begin database::View::join%53F33ECF02B4.body preserve=yes
   hQuery.reset();
   hQuery.setMonitor(true);
   m_hChild.erase(m_hChild.begin(),m_hChild.end());
   m_hJoin.erase(m_hJoin.begin(),m_hJoin.end());
   m_hParent.erase(m_hParent.begin(),m_hParent.end());
   m_iIndex = 99;
   m_strIndex.erase();
  //## end database::View::join%53F33ECF02B4.body
}

void View::setBasicPredicate (Query& hQuery, const string& strParent, const string& strTag, string& strOperator, const string& strToken, const char* pszFunction)
{
  //## begin database::View::setBasicPredicate%53F33ED3031F.body preserve=yes
   string strFirst(strParent);
   strFirst += ':';
   strFirst += strTag;
   pair<multimap<string,database::Column,less<string> >::iterator,multimap<string,database::Column,less<string> >::iterator> hRange = m_hSynonyms.equal_range(strFirst);
   if (hRange.first != hRange.second)
   {
      multimap<string,database::Column,less<string> >::iterator p = hRange.first;
      if (hQuery.getSearchCondition().length() > 0)
         hQuery.getSearchCondition().append(" AND ");
      hQuery.getSearchCondition().append("(");
      for (;p != hRange.second;++p)
      {
         vector<string> hTokens;
         string strValue;
         setValue(strOperator,strToken,hTokens,strValue);
         if (strOperator.find("NOT") != string::npos)
            hQuery.setBasicPredicate((*p).second.getTable().c_str(),(*p).second.getColumn().c_str(),strOperator.c_str(),strValue.c_str(),
            m_hNumericColumns.find((*p).second.getColumn()) != m_hNumericColumns.end(),true,pszFunction);
         else
            hQuery.setBasicPredicate((*p).second.getTable().c_str(),(*p).second.getColumn().c_str(),strOperator.c_str(),strValue.c_str(),
            m_hNumericColumns.find((*p).second.getColumn()) != m_hNumericColumns.end(),false,pszFunction);
      }
      hQuery.getSearchCondition().append(")");
      return;
   }
   multimap<string,database::Column,less<string> >::iterator p = m_hTag.find(strFirst);
   if (p == m_hTag.end())
   {
      //string strTxt("Undefined predicate: ");
      //strTxt += strTag;
      //SOAPSegment::instance()->setMsg("RS90.2","Validation Error",strTxt); 
      return;
   }
   vector<string> hTokens;
   string strValue;
   setValue(strOperator,strToken,hTokens,strValue);
   hQuery.setBasicPredicate((*p).second.getTable().c_str(),(*p).second.getColumn().c_str(),strOperator.c_str(),strValue.c_str(),
      m_hNumericColumns.find((*p).second.getColumn()) != m_hNumericColumns.end(),true,pszFunction);
  //## end database::View::setBasicPredicate%53F33ED3031F.body
}

void View::setBasicPredicate (Query& hQuery, const string& strColumn, string& strOperator, const string& strToken)
{
  //## begin database::View::setBasicPredicate%596FB69902F2.body preserve=yes
  //## end database::View::setBasicPredicate%596FB69902F2.body
}

void View::setValue (const string& strOperator, const string& strToken, vector<string>& hTokens, string& strValue)
{
  //## begin database::View::setValue%53FF7D9C0046.body preserve=yes
   if (strOperator == "NOT BETWEEN"
      || strOperator == "BETWEEN"
      || strOperator == "IN"
      || strOperator == "NOT IN")
   {
      if (strOperator == "IN"
         || strOperator == "NOT IN")
         strValue = '(';
      Buffer::parse(strToken,"(,).",hTokens);
      for (int i = 0;i < hTokens.size();++i)
      {
         strValue += "'";
         strValue += hTokens[i];
         strValue += "'";
         if (strOperator == "NOT BETWEEN"
            || strOperator == "BETWEEN")
         {
            if (i == 0)
               strValue += " AND ";
         }
         else
         {
            if (i < hTokens.size() - 1)
               strValue += ",";
         }
      }
      if (strOperator == "IN"
         || strOperator == "NOT IN")
         strValue += ')';
   }
   else
      strValue = strToken;
  //## end database::View::setValue%53FF7D9C0046.body
}

bool View::skip ()
{
  //## begin database::View::skip%53F33EDA0013.body preserve=yes
   return false;
  //## end database::View::skip%53F33EDA0013.body
}

// Additional Declarations
  //## begin database::View%53F3383D020C.declarations preserve=yes
const multimap<string,database::Column,less<string> >& View::getTag ()
{
   return m_hTag;
}
  //## end database::View%53F3383D020C.declarations
} // namespace database

//## begin module%53F3392F0287.epilog preserve=yes
//## end module%53F3392F0287.epilog
