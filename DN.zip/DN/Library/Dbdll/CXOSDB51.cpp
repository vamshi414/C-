//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5480B43F029D.cm preserve=no
//	$Date:   Aug 06 2021 06:31:36  $ $Author:   e5644299  $ $Revision:   1.1  $
//## end module%5480B43F029D.cm

//## begin module%5480B43F029D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5480B43F029D.cp

//## Module: CXODDB51%5480B43F029D; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB51.cpp

//## begin module%5480B43F029D.additionalIncludes preserve=no
//## end module%5480B43F029D.additionalIncludes

//## begin module%5480B43F029D.includes preserve=yes
#include "CXODRU07.hpp"
//## end module%5480B43F029D.includes

#ifndef CXODDB51_h
#include "CXODDB51.hpp"
#endif
//## begin module%5480B43F029D.declarations preserve=no
//## end module%5480B43F029D.declarations

//## begin module%5480B43F029D.additionalDeclarations preserve=yes
//## end module%5480B43F029D.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::Column 

Column::Column()
  //## begin Column::Column%5480B4C40180_const.hasinit preserve=no
      : m_iNPI(0)
  //## end Column::Column%5480B4C40180_const.hasinit
  //## begin Column::Column%5480B4C40180_const.initialization preserve=yes
  //## end Column::Column%5480B4C40180_const.initialization
{
  //## begin database::Column::Column%5480B4C40180_const.body preserve=yes
  //## end database::Column::Column%5480B4C40180_const.body
}

Column::Column(const Column &right)
  //## begin Column::Column%5480B4C40180_copy.hasinit preserve=no
  //## end Column::Column%5480B4C40180_copy.hasinit
  //## begin Column::Column%5480B4C40180_copy.initialization preserve=yes
  //## end Column::Column%5480B4C40180_copy.initialization
{
  //## begin database::Column::Column%5480B4C40180_copy.body preserve=yes
   m_strTable = right.m_strTable;
   m_strColumn = right.m_strColumn;
   m_iNPI = right.m_iNPI;
  //## end database::Column::Column%5480B4C40180_copy.body
}

Column::Column (const string& strTable, const string& strColumn, int iNPI)
  //## begin database::Column::Column%5480B63E00D4.hasinit preserve=no
      : m_iNPI(0)
  //## end database::Column::Column%5480B63E00D4.hasinit
  //## begin database::Column::Column%5480B63E00D4.initialization preserve=yes
  //## end database::Column::Column%5480B63E00D4.initialization
{
  //## begin database::Column::Column%5480B63E00D4.body preserve=yes
   m_strTable = strTable;
   m_strColumn = strColumn;
   reusable::Column::setNPI(m_strColumn.c_str(),iNPI);
   m_iNPI = iNPI;
  //## end database::Column::Column%5480B63E00D4.body
}


Column::~Column()
{
  //## begin database::Column::~Column%5480B4C40180_dest.body preserve=yes
  //## end database::Column::~Column%5480B4C40180_dest.body
}


Column & Column::operator=(const Column &right)
{
  //## begin database::Column::operator=%5480B4C40180_assign.body preserve=yes
   m_strTable = right.m_strTable;
   m_strColumn = right.m_strColumn;
   m_iNPI = right.m_iNPI;
   return *this;
  //## end database::Column::operator=%5480B4C40180_assign.body
}


// Additional Declarations
  //## begin database::Column%5480B4C40180.declarations preserve=yes
  //## end database::Column%5480B4C40180.declarations

} // namespace database

//## begin module%5480B43F029D.epilog preserve=yes
//## end module%5480B43F029D.epilog
