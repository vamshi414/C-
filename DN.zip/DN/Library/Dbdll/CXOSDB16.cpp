//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%378B86B1010A.cm preserve=no
//	$Date:   May 12 2020 10:57:04  $ $Author:   E5350313  $ $Revision:   1.11  $
//## end module%378B86B1010A.cm

//## begin module%378B86B1010A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%378B86B1010A.cp

//## Module: CXOSDB16%378B86B1010A; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Dn_codes\V03.1A.R004\ConnexPlatform\Server\Library\Dbdll\CXOSDB16.cpp

//## begin module%378B86B1010A.additionalIncludes preserve=no
//## end module%378B86B1010A.additionalIncludes

//## begin module%378B86B1010A.includes preserve=yes
#include "CXODDB25.hpp"
//## end module%378B86B1010A.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB16_h
#include "CXODDB16.hpp"
#endif


//## begin module%378B86B1010A.declarations preserve=no
//## end module%378B86B1010A.declarations

//## begin module%378B86B1010A.additionalDeclarations preserve=yes
//## end module%378B86B1010A.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::CRTransactionTypeIndicator 

//## begin database::CRTransactionTypeIndicator::Instance%54AE9B430352.attr preserve=no  private: static database::CRTransactionTypeIndicator* {V} 0
database::CRTransactionTypeIndicator* CRTransactionTypeIndicator::m_pInstance = 0;
//## end database::CRTransactionTypeIndicator::Instance%54AE9B430352.attr

CRTransactionTypeIndicator::CRTransactionTypeIndicator()
  //## begin CRTransactionTypeIndicator::CRTransactionTypeIndicator%378B84F70349_const.hasinit preserve=no
  //## end CRTransactionTypeIndicator::CRTransactionTypeIndicator%378B84F70349_const.hasinit
  //## begin CRTransactionTypeIndicator::CRTransactionTypeIndicator%378B84F70349_const.initialization preserve=yes
  //## end CRTransactionTypeIndicator::CRTransactionTypeIndicator%378B84F70349_const.initialization
{
  //## begin database::CRTransactionTypeIndicator::CRTransactionTypeIndicator%378B84F70349_const.body preserve=yes
   memcpy(m_sID,"DB16",4);
  //## end database::CRTransactionTypeIndicator::CRTransactionTypeIndicator%378B84F70349_const.body
}


CRTransactionTypeIndicator::~CRTransactionTypeIndicator()
{
  //## begin database::CRTransactionTypeIndicator::~CRTransactionTypeIndicator%378B84F70349_dest.body preserve=yes
   m_pInstance = 0;
  //## end database::CRTransactionTypeIndicator::~CRTransactionTypeIndicator%378B84F70349_dest.body
}



//## Other Operations (implementation)
bool CRTransactionTypeIndicator::description (const string& strTRAN_TYPE_ID, string& strCFG_DESCRIPTION)
{
  //## begin database::CRTransactionTypeIndicator::description%378B85D30205.body preserve=yes
   map<string, struct sTTISecond*, less<string> >::iterator p = instance()->m_hTransactionType.find(strTRAN_TYPE_ID);
   if (p == instance()->m_hTransactionType.end())
   {
      strCFG_DESCRIPTION.erase();
      return false;
   }
   strCFG_DESCRIPTION.assign((*p).second->sCFG_DESCRIPTION_3, sizeof((*p).second->sCFG_DESCRIPTION_3));
   return true;
  //## end database::CRTransactionTypeIndicator::description%378B85D30205.body
}

bool CRTransactionTypeIndicator::getDepositoryInd (const string& strTRAN_TYPE_ID, string& strDEPOSITORY_IND)
{
  //## begin database::CRTransactionTypeIndicator::getDepositoryInd%3AE6D8700375.body preserve=yes
   map<string, struct sTTISecond*, less<string> >::iterator p = instance()->m_hTransactionType.find(strTRAN_TYPE_ID);
   if (p == instance()->m_hTransactionType.end())
   {
      strDEPOSITORY_IND.erase();
      return false;
   }
   strDEPOSITORY_IND.assign((*p).second->cDEPOSITORY_IND, sizeof((*p).second->cDEPOSITORY_IND));
   return true;
  //## end database::CRTransactionTypeIndicator::getDepositoryInd%3AE6D8700375.body
}

bool CRTransactionTypeIndicator::getDescription (const string& strTRAN_TYPE_ID, string& strCFG_DESCRIPTION)
{
  //## begin database::CRTransactionTypeIndicator::getDescription%5E137B0302C5.body preserve=yes
   map<string, struct sTTISecond*, less<string> >::iterator p = instance()->m_hTransactionType.find(strTRAN_TYPE_ID);
   if (p == instance()->m_hTransactionType.end() || strTRAN_TYPE_ID.length() < 6)
   {
      strCFG_DESCRIPTION.erase();
      return false;
   }
   strCFG_DESCRIPTION.assign((*p).second->sCFG_DESCRIPTION_0, sizeof((*p).second->sCFG_DESCRIPTION_0));
   rtrim(strCFG_DESCRIPTION);
   if (memcmp(strTRAN_TYPE_ID.data()+2,"00",2) != 0 || memcmp(strTRAN_TYPE_ID.data()+4,"00",2 == 0))
   {
      strCFG_DESCRIPTION.append(" ");
      strCFG_DESCRIPTION.append((*p).second->sCFG_DESCRIPTION_1, sizeof((*p).second->sCFG_DESCRIPTION_1));
      rtrim(strCFG_DESCRIPTION);
   }
   else 
   if (memcmp(strTRAN_TYPE_ID.data()+4,"00",2) != 0)
   {
      strCFG_DESCRIPTION.append(" ");
      strCFG_DESCRIPTION.append((*p).second->sCFG_DESCRIPTION_2, sizeof((*p).second->sCFG_DESCRIPTION_2));
      rtrim(strCFG_DESCRIPTION);
   }
   return true;
  //## end database::CRTransactionTypeIndicator::getDescription%5E137B0302C5.body
}

bool CRTransactionTypeIndicator::getImpact (const string& strTRAN_TYPE_ID, string& strIMPACT_TO_ACQ, string& strIMPACT_TO_ISS)
{
  //## begin database::CRTransactionTypeIndicator::getImpact%385BAECB0331.body preserve=yes
   map<string, struct sTTISecond*, less<string> >::iterator p = instance()->m_hTransactionType.find(strTRAN_TYPE_ID);
   if (p == instance()->m_hTransactionType.end())
   {
      strIMPACT_TO_ACQ.erase();
      strIMPACT_TO_ISS.erase();
      return false;
   }
   strIMPACT_TO_ACQ.assign((*p).second->cIMPACT_TO_ACQ, sizeof((*p).second->cIMPACT_TO_ACQ));
   strIMPACT_TO_ISS.assign((*p).second->cIMPACT_TO_ISS, sizeof((*p).second->cIMPACT_TO_ISS));
   return true;
  //## end database::CRTransactionTypeIndicator::getImpact%385BAECB0331.body
}

bool CRTransactionTypeIndicator::getPostDropIndicator (const string& strTRAN_TYPE_ID, string& strPOST_PROC_DROP_IND, string& strPOST_DEP_DROP_IND)
{
  //## begin database::CRTransactionTypeIndicator::getPostDropIndicator%5EB2A345018B.body preserve=yes
   map<string, struct sTTISecond*, less<string> >::iterator p = instance()->m_hTransactionType.find(strTRAN_TYPE_ID);
   if (p == instance()->m_hTransactionType.end())
   {
      strPOST_PROC_DROP_IND.erase();
      strPOST_DEP_DROP_IND.erase();
      return false;
   }
   strPOST_PROC_DROP_IND.assign((*p).second->cPOST_PROC_DROP_IND, sizeof((*p).second->cPOST_PROC_DROP_IND));
   strPOST_DEP_DROP_IND.assign((*p).second->cPOST_DEP_DROP_IND, sizeof((*p).second->cPOST_DEP_DROP_IND));
   return true;
  //## end database::CRTransactionTypeIndicator::getPostDropIndicator%5EB2A345018B.body
}

bool CRTransactionTypeIndicator::getPostProcessCode (const string& strTRAN_TYPE_ID, string& strPOST_CMS_PROC_CODE)
{
  //## begin database::CRTransactionTypeIndicator::getPostProcessCode%5EB29F6A0246.body preserve=yes
   map<string, struct sTTISecond*, less<string> >::iterator p = instance()->m_hTransactionType.find(strTRAN_TYPE_ID);
   if (p == instance()->m_hTransactionType.end())
   {
      strPOST_CMS_PROC_CODE.erase();
      return false;
   }
   strPOST_CMS_PROC_CODE.assign((*p).second->sPOST_CMS_PROC_CODE, sizeof((*p).second->sPOST_CMS_PROC_CODE));
   return true;
  //## end database::CRTransactionTypeIndicator::getPostProcessCode%5EB29F6A0246.body
}

bool CRTransactionTypeIndicator::getPostTranCode (const string& strTRAN_TYPE_ID, string& strPOST_ACH_TRAN_CODE)
{
  //## begin database::CRTransactionTypeIndicator::getPostTranCode%5EB2A29802F3.body preserve=yes
   map<string, struct sTTISecond*, less<string> >::iterator p = instance()->m_hTransactionType.find(strTRAN_TYPE_ID);
   if (p == instance()->m_hTransactionType.end())
   {
      strPOST_ACH_TRAN_CODE.erase();
      return false;
   }
   strPOST_ACH_TRAN_CODE.assign((*p).second->sPOST_ACH_TRAN_CODE, sizeof((*p).second->sPOST_ACH_TRAN_CODE));
   return true;
  //## end database::CRTransactionTypeIndicator::getPostTranCode%5EB2A29802F3.body
}

bool CRTransactionTypeIndicator::getTranGroup (const string& strTRAN_TYPE_ID, string& strTRAN_GROUP)
{
  //## begin database::CRTransactionTypeIndicator::getTranGroup%45CC2C1D021D.body preserve=yes
   map<string, struct sTTISecond*, less<string> >::iterator p = instance()->m_hTransactionType.find(strTRAN_TYPE_ID);
   if (p == instance()->m_hTransactionType.end())
   {
      strTRAN_GROUP.erase();
      return false;
   }
   strTRAN_GROUP.assign((*p).second->sTRAN_GROUP, sizeof((*p).second->sTRAN_GROUP));
   return true;
  //## end database::CRTransactionTypeIndicator::getTranGroup%45CC2C1D021D.body
}

CRTransactionTypeIndicator* CRTransactionTypeIndicator::instance ()
{
  //## begin database::CRTransactionTypeIndicator::instance%54AE9B6D03E2.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new CRTransactionTypeIndicator();
   return m_pInstance;
  //## end database::CRTransactionTypeIndicator::instance%54AE9B6D03E2.body
}

bool CRTransactionTypeIndicator::load ()
{
  //## begin database::CRTransactionTypeIndicator::load%54AE99CB0369.body preserve=yes
   string strCUST_ID;
   m_hTransactionType.erase(m_hTransactionType.begin(),m_hTransactionType.end());
   Query hQuery;
   hQuery.attach(this);
   hQuery.setQualifier("QUALIFY","TRAN_TYPE_IND");
   hQuery.setQualifier("QUALIFY", "TTI_FUNCTION_TYPE");
   hQuery.setQualifier("QUALIFY", "TTI_ACCOUNT_TYPE TTI_ACCOUNT_TYPE_FROM");
   hQuery.setQualifier("QUALIFY", "TTI_ACCOUNT_TYPE TTI_ACCOUNT_TYPE_TO");
   hQuery.join("TRAN_TYPE_IND", "INNER", "TTI_FUNCTION_TYPE","FUNCTION_TYPE");
   hQuery.join("TRAN_TYPE_IND", "INNER", "TTI_ACCOUNT_TYPE TTI_ACCOUNT_TYPE_FROM", "SUBSTR(PROCESS_CODE,3,2)","ACCOUNT_TYPE");
   hQuery.join("TRAN_TYPE_IND", "INNER", "TTI_ACCOUNT_TYPE TTI_ACCOUNT_TYPE_TO", "SUBSTR(PROCESS_CODE,5,2)", "ACCOUNT_TYPE");
   hQuery.bind("TRAN_TYPE_IND","PROCESS_CODE",Column::STRING,&m_strPROCESS_CODE);
   hQuery.bind("TRAN_TYPE_IND","MSG_CLASS",Column::STRING,&m_strMSG_CLASS);
   hQuery.bind("TRAN_TYPE_IND","PRE_AUTH",Column::STRING,&m_strPRE_AUTH);
   hQuery.bind("TRAN_TYPE_IND","MEDIA_TYPE",Column::STRING,&m_strMEDIA_TYPE);
   hQuery.bind("TRAN_TYPE_IND","CUST_ID",Column::STRING,&strCUST_ID);
   hQuery.bind("TRAN_TYPE_IND","IMPACT_TO_ACQ",Column::STRING,&m_strIMPACT_TO_ACQ);
   hQuery.bind("TRAN_TYPE_IND","IMPACT_TO_ISS",Column::STRING,&m_strIMPACT_TO_ISS);
   hQuery.bind("TRAN_TYPE_IND","DEPOSITORY_IND",Column::STRING,&m_strDEPOSITORY_IND);
   hQuery.bind("TRAN_TYPE_IND","TRAN_GROUP",Column::STRING,&m_strTRAN_GROUP);
   hQuery.bind("TRAN_TYPE_IND","CFG_DESCRIPTION",Column::STRING,&m_strCFG_DESCRIPTION[3]);
   hQuery.bind("TTI_FUNCTION_TYPE","CFG_DESCRIPTION",Column::STRING,&m_strCFG_DESCRIPTION[0]);
   hQuery.bind("TTI_ACCOUNT_TYPE_FROM","CFG_DESCRIPTION",Column::STRING,&m_strCFG_DESCRIPTION[1]);
   hQuery.bind("TTI_ACCOUNT_TYPE_TO","CFG_DESCRIPTION",Column::STRING,&m_strCFG_DESCRIPTION[2]);
   hQuery.bind("TRAN_TYPE_IND","POST_CMS_PROC_CODE",Column::STRING,&m_strPOST_CMS_PROC_CODE);
   hQuery.bind("TRAN_TYPE_IND","POST_ACH_TRAN_CODE",Column::STRING,&m_strPOST_ACH_TRAN_CODE);
   hQuery.bind("TRAN_TYPE_IND","POST_PROC_DROP_IND",Column::STRING,&m_strPOST_PROC_DROP_IND);
   hQuery.bind("TRAN_TYPE_IND","POST_DEP_DROP_IND",Column::STRING,&m_strPOST_DEP_DROP_IND);
   hQuery.setBasicPredicate("TRAN_TYPE_IND","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("TRAN_TYPE_IND","CC_STATE","=","A");
   hQuery.setBasicPredicate("TTI_FUNCTION_TYPE", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("TTI_FUNCTION_TYPE", "CC_STATE", "=", "A");
   hQuery.setBasicPredicate("TTI_ACCOUNT_TYPE_FROM", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("TTI_ACCOUNT_TYPE_FROM", "CC_STATE", "=", "A");
   hQuery.setBasicPredicate("TTI_ACCOUNT_TYPE_TO", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("TTI_ACCOUNT_TYPE_TO", "CC_STATE", "=", "A");
   string strCUST_IDs("('****','");
   string strBuffer;
   Extract::instance()->getSpec("CUSTOMER",strBuffer);
   strCUST_IDs += strBuffer;
   strCUST_IDs += "')";
   hQuery.setBasicPredicate("TRAN_TYPE_IND","CUST_ID","IN",strCUST_IDs.c_str());
   hQuery.setOrderByClause("PROCESS_CODE,MSG_CLASS,PRE_AUTH,MEDIA_TYPE,CUST_ID DESC");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   return pSelectStatement->execute(hQuery);
  //## end database::CRTransactionTypeIndicator::load%54AE99CB0369.body
}

void CRTransactionTypeIndicator::update (Subject* pSubject)
{
  //## begin database::CRTransactionTypeIndicator::update%385BB31F015D.body preserve=yes
   string strFirst(m_strPROCESS_CODE);
   strFirst += m_strMSG_CLASS;
   strFirst += m_strPRE_AUTH;
   strFirst += m_strMEDIA_TYPE;
   struct sTTISecond* pTTISecond = new struct sTTISecond;
   memset(pTTISecond, ' ', sizeof(sTTISecond));
   memcpy(&pTTISecond->cIMPACT_TO_ACQ, m_strIMPACT_TO_ACQ.data(), m_strIMPACT_TO_ACQ.length());
   memcpy(&pTTISecond->cIMPACT_TO_ISS, m_strIMPACT_TO_ISS.data(), m_strIMPACT_TO_ISS.length());
   memcpy(&pTTISecond->cDEPOSITORY_IND, m_strDEPOSITORY_IND.data(), m_strDEPOSITORY_IND.length());
   memcpy(pTTISecond->sTRAN_GROUP, m_strTRAN_GROUP.data(), m_strTRAN_GROUP.length());
   memcpy(pTTISecond->sCFG_DESCRIPTION_0, m_strCFG_DESCRIPTION[0].data(), m_strCFG_DESCRIPTION[0].length()); //TTI_FUNCTION.DESCRIPTION (19 chars)
   memcpy(pTTISecond->sCFG_DESCRIPTION_1, m_strCFG_DESCRIPTION[1].data(), m_strCFG_DESCRIPTION[1].length()); //TTI_ACCOUNT.DESCRIPTION FROM (28 chars)
   memcpy(pTTISecond->sCFG_DESCRIPTION_2, m_strCFG_DESCRIPTION[2].data(), m_strCFG_DESCRIPTION[2].length()); //TTI_ACCOUNT.DESCRIPTION TO (28 chars)
   memcpy(pTTISecond->sCFG_DESCRIPTION_3, m_strCFG_DESCRIPTION[3].data(), m_strCFG_DESCRIPTION[3].length()); //TRAN_TYPE_IND.DESCRIPTION
   memcpy(pTTISecond->sPOST_CMS_PROC_CODE, m_strPOST_CMS_PROC_CODE.data(), m_strPOST_CMS_PROC_CODE.length());
   memcpy(pTTISecond->sPOST_ACH_TRAN_CODE, m_strPOST_ACH_TRAN_CODE.data(), m_strPOST_ACH_TRAN_CODE.length());
   memcpy(&pTTISecond->cPOST_PROC_DROP_IND, m_strPOST_PROC_DROP_IND.data(), m_strPOST_PROC_DROP_IND.length());
   memcpy(&pTTISecond->cPOST_DEP_DROP_IND, m_strPOST_DEP_DROP_IND.data(), m_strPOST_DEP_DROP_IND.length());
   m_hTransactionType.insert(map<string, struct sTTISecond*, less<string> >::value_type(strFirst, pTTISecond));
  //## end database::CRTransactionTypeIndicator::update%385BB31F015D.body
}

// Additional Declarations
  //## begin database::CRTransactionTypeIndicator%378B84F70349.declarations preserve=yes
  //## end database::CRTransactionTypeIndicator%378B84F70349.declarations

} // namespace database

//## begin module%378B86B1010A.epilog preserve=yes
//## end module%378B86B1010A.epilog
