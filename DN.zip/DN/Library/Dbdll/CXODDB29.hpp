//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%45934F310209.cm preserve=no
//	$Date:   Jul 10 2012 14:12:48  $ $Author:   e1009839  $
//	$Revision:   1.2  $
//## end module%45934F310209.cm

//## begin module%45934F310209.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%45934F310209.cp

//## Module: CXOSDB29%45934F310209; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB29.hpp

#ifndef CXOSDB29_h
#define CXOSDB29_h 1

//## begin module%45934F310209.additionalIncludes preserve=no
//## end module%45934F310209.additionalIncludes

//## begin module%45934F310209.includes preserve=yes
//## end module%45934F310209.includes

#ifndef CXOSRU01_h
#include "CXODRU01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%45934F310209.declarations preserve=no
//## end module%45934F310209.declarations

//## begin module%45934F310209.additionalDeclarations preserve=yes
//## end module%45934F310209.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Status%45934EE70043.preface preserve=yes
//## end database::Status%45934EE70043.preface

//## Class: Status%45934EE70043
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4FFAF1F201E7;reusable::Query { -> F}

class DllExport Status : public reusable::Subject  //## Inherits: <unnamed>%45934F0A01DA
{
  //## begin database::Status%45934EE70043.initialDeclarations preserve=yes
  //## end database::Status%45934EE70043.initialDeclarations

  public:
    //## Constructors (generated)
      Status();

    //## Destructor (generated)
      virtual ~Status();


    //## Other Operations (specified)
      //## Operation: bind%4FFAE9F0027A
      void bind (reusable::Query& hQuery);

      //## Operation: getStatus%4FFAE9720014
      pair<string,int> getStatus ();

      //## Operation: instance%4593513C00F8
      static Status* instance ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: TASKID%45AE0A540167
      const string& getTASKID () const
      {
        //## begin database::Status::getTASKID%45AE0A540167.get preserve=no
        return m_strTASKID;
        //## end database::Status::getTASKID%45AE0A540167.get
      }

      void setTASKID (const string& value)
      {
        //## begin database::Status::setTASKID%45AE0A540167.set preserve=no
        m_strTASKID = value;
        //## end database::Status::setTASKID%45AE0A540167.set
      }


    // Additional Public Declarations
      //## begin database::Status%45934EE70043.public preserve=yes
      //## end database::Status%45934EE70043.public

  protected:
    // Additional Protected Declarations
      //## begin database::Status%45934EE70043.protected preserve=yes
      //## end database::Status%45934EE70043.protected

  private:
    // Additional Private Declarations
      //## begin database::Status%45934EE70043.private preserve=yes
      //## end database::Status%45934EE70043.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CONTEXT_DATA%4FFAEA0F0017
      //## begin database::Status::CONTEXT_DATA%4FFAEA0F0017.attr preserve=no  public: string {V} 
      string m_strCONTEXT_DATA;
      //## end database::Status::CONTEXT_DATA%4FFAEA0F0017.attr

      //## Attribute: Instance%459350EC0379
      //## begin database::Status::Instance%459350EC0379.attr preserve=no  public: static Status* {U} 0
      static Status* m_pInstance;
      //## end database::Status::Instance%459350EC0379.attr

      //## begin database::Status::TASKID%45AE0A540167.attr preserve=no  public: string {V} 
      string m_strTASKID;
      //## end database::Status::TASKID%45AE0A540167.attr

    // Additional Implementation Declarations
      //## begin database::Status%45934EE70043.implementation preserve=yes
      //## end database::Status%45934EE70043.implementation

};

//## begin database::Status%45934EE70043.postscript preserve=yes
//## end database::Status%45934EE70043.postscript

} // namespace database

//## begin module%45934F310209.epilog preserve=yes
//## end module%45934F310209.epilog


#endif
