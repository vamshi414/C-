//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4982289D0390.cm preserve=no
//	$Date:   Sep 30 2015 10:46:36  $ $Author:   e1009652  $ $Revision:   1.12  $
//## end module%4982289D0390.cm

//## begin module%4982289D0390.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4982289D0390.cp

//## Module: CXOSDB33%4982289D0390; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5C.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB33.hpp

#ifndef CXOSDB33_h
#define CXOSDB33_h 1

//## begin module%4982289D0390.additionalIncludes preserve=no
//## end module%4982289D0390.additionalIncludes

//## begin module%4982289D0390.includes preserve=yes
#ifndef CXOSDB34_h
#include "CXODDB34.hpp"
#endif
//## end module%4982289D0390.includes

#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
class FormatSelectVisitor;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CommandMessage;
class Extract;
class Console;
} // namespace IF

namespace reusable {
class Key;
class KeyManager;
class Mask;
} // namespace reusable

namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class GlobalContext;
class DatabaseFactory;
class Cache;
class IBMKey;
class TransportKey;
class DESKey;
class AESKey;
} // namespace database

//## Modelname: Connex Library::SecurityWrapper_CAT (SWDLL)%4A09A922013D
namespace securitywrapper {
class SecurityWrapper;

} // namespace securitywrapper

//## begin module%4982289D0390.declarations preserve=no
//## end module%4982289D0390.declarations

//## begin module%4982289D0390.additionalDeclarations preserve=yes
struct TokenControl
{
   //part 1 (1st 64 bytes)
   char SerialNo[4];    
   char Hash[10];
   char ShuffleScheme[2];
   char RowOrder[48];
   //part 2 (2nd 64 bytes)
   char StartDate[6]; //YYYYMM 
   char EndDate[6]; //YYYYMM tokenization through this month default 999999
   char Reserved[52];
};
//## end module%4982289D0390.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::AESKeyRing%4982285D018F.preface preserve=yes
//## end database::AESKeyRing%4982285D018F.preface

//## Class: AESKeyRing%4982285D018F
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%49822B7B0331;AESKey { -> F}
//## Uses: <unnamed>%498346EA018D;Database { -> F}
//## Uses: <unnamed>%498346EC0302;reusable::Table { -> F}
//## Uses: <unnamed>%498346EF02C0;IF::Trace { -> F}
//## Uses: <unnamed>%498346F601C6;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4983472B005A;reusable::Query { -> F}
//## Uses: <unnamed>%4983472D039C;reusable::Statement { -> F}
//## Uses: <unnamed>%4983473002CE;DatabaseFactory { -> F}
//## Uses: <unnamed>%498350B600DF;reusable::Key { -> F}
//## Uses: <unnamed>%4A0082800377;IF::CommandMessage { -> F}
//## Uses: <unnamed>%4A09A5820106;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%4AFD8D10038E;TransportKey { -> F}
//## Uses: <unnamed>%4AFD8D13022A;DESKey { -> F}
//## Uses: <unnamed>%4B0C0BD30039;IBMKey { -> F}
//## Uses: <unnamed>%4FF5ECB90048;reusable::Mask { -> F}
//## Uses: <unnamed>%4FF5ECFC03CB;timer::Date { -> F}
//## Uses: <unnamed>%4FF5ED19003B;IF::Extract { -> F}
//## Uses: <unnamed>%4FF5ED4B028E;securitywrapper::SecurityWrapper { -> F}
//## Uses: <unnamed>%5012E2000144;IF::Console { -> F}
//## Uses: <unnamed>%5012E4C700DB;reusable::KeyManager { -> F}
//## Uses: <unnamed>%501695D8001D;Cache { -> F}
//## Uses: <unnamed>%50200B0F01CB;reusable::FormatSelectVisitor { -> F}
//## Uses: <unnamed>%524479EA01E7;GlobalContext { -> F}

class DllExport AESKeyRing : public reusable::KeyRing  //## Inherits: <unnamed>%4982287B0228
{
  //## begin database::AESKeyRing%4982285D018F.initialDeclarations preserve=yes
  //## end database::AESKeyRing%4982285D018F.initialDeclarations

  public:
    //## Constructors (generated)
      AESKeyRing();

    //## Destructor (generated)
      virtual ~AESKeyRing();


    //## Other Operations (specified)
      //## Operation: bind%560407960177
      bool bind (reusable::Query& hQuery);

      //## Operation: decrypt%4983A3D50071
      virtual bool decrypt (const string& strYYYYMM, string& strText);

      //## Operation: detokenize%49DE352902A7
      virtual void detokenize (string& strPAN);

      //## Operation: detokenize%49DE352902A9
      virtual void detokenize (char* psPAN, int iPanLength);

      //## Operation: encrypt%4983A3D50073
      virtual bool encrypt (const string& strYYYYMM, string& strText);

      //## Operation: exists%50105FA5025E
      virtual int exists ();

      //## Operation: getTransportKey%4AF1A5D4006F
      virtual reusable::Key* getTransportKey (const string& strKeyId);

      //## Operation: isPrimary%5604318801BD
      virtual bool isPrimary ();

      //## Operation: load%4FF5E01602BD
      virtual bool load ();

      //## Operation: loadTokens%49DE36940078
      virtual bool loadTokens ();

      //## Operation: mask%49822E66019B
      bool mask (int& iBufferLength, char* pBuffer, int iOffset, int iLength, int iNPI = 2);

      //## Operation: recoverFromBackups%5012AD6401F6
      bool recoverFromBackups ();

      //## Operation: refreshKeys%50105AD901C0
      virtual void refreshKeys ();

      //## Operation: repairKeys%5012D2350288
      bool repairKeys ();

      //## Operation: repairTokens%5012D24A01B0
      bool repairTokens ();

      //## Operation: reset%4983A3C702D4
      virtual bool reset ();

      //## Operation: resetKeys%4A01EE0203A3
      virtual bool resetKeys ();

      //## Operation: setColumns%56042C0F00B0
      bool setColumns (reusable::Table& hTable);

      //## Operation: tokenize%49DE3531005A
      virtual void tokenize (string& strPAN);

      //## Operation: tokenize%49DE35310064
      virtual void tokenize (char* psPAN, int iPanLength);

      //## Operation: tokenize%4A01BB0400A9
      virtual void tokenize (char* psPAN, int iPanLength, char* psTSTAMP_TRANS);

      //## Operation: unmask%49822E6601A5
      bool unmask (int& iLength, char* pBuffer);

      //## Operation: update%49822FFB02A1
      virtual void update (Subject* pSubject);

      //## Operation: validateTokens%5012B9860229
      virtual bool validateTokens ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ApplicationName%4D08E8FE0372
      void setApplicationName (const string& value)
      {
        //## begin database::AESKeyRing::setApplicationName%4D08E8FE0372.set preserve=no
        m_strApplicationName = value;
        //## end database::AESKeyRing::setApplicationName%4D08E8FE0372.set
      }


    // Additional Public Declarations
      //## begin database::AESKeyRing%4982285D018F.public preserve=yes
      //## end database::AESKeyRing%4982285D018F.public

  protected:
    // Additional Protected Declarations
      //## begin database::AESKeyRing%4982285D018F.protected preserve=yes
      //## end database::AESKeyRing%4982285D018F.protected

  private:

    //## Other Operations (specified)
      //## Operation: findToken%49F9F48001F7
      int findToken (const string& strToken);

      //## Operation: tokenize_1%4A0339250020
      virtual void tokenize_1 (char* psPAN, int iPanLength);

    // Additional Private Declarations
      //## begin database::AESKeyRing%4982285D018F.private preserve=yes
      //## end database::AESKeyRing%4982285D018F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin database::AESKeyRing::ApplicationName%4D08E8FE0372.attr preserve=no  public: string {V} 
      string m_strApplicationName;
      //## end database::AESKeyRing::ApplicationName%4D08E8FE0372.attr

      //## Attribute: CONTEXT_KEY%4983476302D1
      //## begin database::AESKeyRing::CONTEXT_KEY%4983476302D1.attr preserve=no  private: string {U} 
      string m_strCONTEXT_KEY;
      //## end database::AESKeyRing::CONTEXT_KEY%4983476302D1.attr

      //## Attribute: CONTEXT_DATA%498347AC033A
      //## begin database::AESKeyRing::CONTEXT_DATA%498347AC033A.attr preserve=no  private: string {U} 
      string m_strCONTEXT_DATA;
      //## end database::AESKeyRing::CONTEXT_DATA%498347AC033A.attr

      //## Attribute: DATE%49DE37BE0320
      //## begin database::AESKeyRing::DATE%49DE37BE0320.attr preserve=no  private: string {U} 
      string m_strDATE;
      //## end database::AESKeyRing::DATE%49DE37BE0320.attr

      //## Attribute: Hash%49FB080800B0
      //## begin database::AESKeyRing::Hash%49FB080800B0.attr preserve=no  private: int {U} 
      int m_lHash;
      //## end database::AESKeyRing::Hash%49FB080800B0.attr

      //## Attribute: Offset%49DE37D60112
      //## begin database::AESKeyRing::Offset%49DE37D60112.attr preserve=no  private: int {U} 0
      int m_iOffset;
      //## end database::AESKeyRing::Offset%49DE37D60112.attr

      //## Attribute: SEQ_NO%49FB025102B5
      //## begin database::AESKeyRing::SEQ_NO%49FB025102B5.attr preserve=no  private: int {U} 
      int m_iSEQ_NO;
      //## end database::AESKeyRing::SEQ_NO%49FB025102B5.attr

      //## Attribute: SerialNo%49FB0805035F
      //## begin database::AESKeyRing::SerialNo%49FB0805035F.attr preserve=no  private: int {U} 
      int m_iSerialNo;
      //## end database::AESKeyRing::SerialNo%49FB0805035F.attr

      //## Attribute: ShuffleScheme%49FB08120105
      //## begin database::AESKeyRing::ShuffleScheme%49FB08120105.attr preserve=no  private: int {U} 
      int m_iShuffleScheme;
      //## end database::AESKeyRing::ShuffleScheme%49FB08120105.attr

      //## Attribute: TOKEN%49DE37BB02A3
      //## begin database::AESKeyRing::TOKEN%49DE37BB02A3.attr preserve=no  private: string {U} 
      string m_strTOKEN;
      //## end database::AESKeyRing::TOKEN%49DE37BB02A3.attr

      //## Attribute: TokenControl%49FB0297008F
      //## begin database::AESKeyRing::TokenControl%49FB0297008F.attr preserve=no  private: string {U} 
      string m_strTokenControl;
      //## end database::AESKeyRing::TokenControl%49FB0297008F.attr

      //## Attribute: Tokens%49DE37FF0369
      //## begin database::AESKeyRing::Tokens%49DE37FF0369.attr preserve=no  private: char[11136][4] {U} 
      char m_arrayTokens[11136][4];
      //## end database::AESKeyRing::Tokens%49DE37FF0369.attr

      //## Attribute: TokenOrder%49F9F360032A
      //## begin database::AESKeyRing::TokenOrder%49F9F360032A.attr preserve=no  private: short[11136] {U} 
      short m_arrayTokenOrder[11136];
      //## end database::AESKeyRing::TokenOrder%49F9F360032A.attr

      //## Attribute: DATA_BUFFER%5012ADDD0013
      //## begin database::AESKeyRing::DATA_BUFFER%5012ADDD0013.attr preserve=no  private: string {U} 
      string m_strDATA_BUFFER;
      //## end database::AESKeyRing::DATA_BUFFER%5012ADDD0013.attr

      //## Attribute: DATE_RECON%5012ADDD001E
      //## begin database::AESKeyRing::DATE_RECON%5012ADDD001E.attr preserve=no  private: string {U} 
      string m_strDATE_RECON;
      //## end database::AESKeyRing::DATE_RECON%5012ADDD001E.attr

      //## Attribute: DX_FILE_ID%5012ADDD0027
      //## begin database::AESKeyRing::DX_FILE_ID%5012ADDD0027.attr preserve=no  private: int {U} 
      int m_iDX_FILE_ID;
      //## end database::AESKeyRing::DX_FILE_ID%5012ADDD0027.attr

    // Additional Implementation Declarations
      //## begin database::AESKeyRing%4982285D018F.implementation preserve=yes
      vector<pair<int,string> > m_hBackups;
      vector<string> m_hKeysDATA_BUFFER;
      vector<string> m_hTokensDATA_BUFFER;
      bool m_bIST;
      //## end database::AESKeyRing%4982285D018F.implementation
};

//## begin database::AESKeyRing%4982285D018F.postscript preserve=yes
//## end database::AESKeyRing%4982285D018F.postscript

} // namespace database

//## begin module%4982289D0390.epilog preserve=yes
//## end module%4982289D0390.epilog


#endif
