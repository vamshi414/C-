//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4974904400B6.cm preserve=no
//	$Date:   Nov 28 2017 20:02:28  $ $Author:   e1009839  $ $Revision:   1.21  $
//## end module%4974904400B6.cm

//## begin module%4974904400B6.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4974904400B6.cp

//## Module: CXOSDB32%4974904400B6; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5C.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB32.hpp

#ifndef CXOSDB32_h
#define CXOSDB32_h 1

//## begin module%4974904400B6.additionalIncludes preserve=no
//## end module%4974904400B6.additionalIncludes

//## begin module%4974904400B6.includes preserve=yes
#include <map>
#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSDB34_h
#include "CXODDB34.hpp"
#endif
struct sKey
{
   char sId[7];
   char sSpacer1[2];
  // short int iNull0;
   char sType[10];
   char sSpacer2[2];
   // short int iNull1;
   char sDefault[2];
};
struct sKeyPart
{
   char sTKCD[5];       //transport key check digits
   char sSpacer1[2];    //short int iNull0;
   char sKEY1[33];      //32 character (hex) key  
   char sSpacer2[2];    //short int iNull1;
   char sKEY2[33];      //32 character (hex) key  
   char sSpacer3[2];    //short int iNull2;
   char sKPCD[5];       //Key part check digits
   char sSpacer4[2];    //short int iNull3;
   char sSTATUS[41];    //Status message
};
//## end module%4974904400B6.includes

#ifndef CXOSRU39_h
#include "CXODRU39.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
class Key;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Memory;
class Extract;
class ResultSet;
class Console;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class IBMKey;
class TransportKey;
class DESKey;
class AESKey;
class AESKeyRing;
class DatabaseFactory;
class ExportFile;
class GenerationDataGroup;

} // namespace database

//## begin module%4974904400B6.declarations preserve=no
//## end module%4974904400B6.declarations

//## begin module%4974904400B6.additionalDeclarations preserve=yes
//## end module%4974904400B6.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::AESKeyManager%49748F87033F.preface preserve=yes
//## end database::AESKeyManager%49748F87033F.preface

//## Class: AESKeyManager%49748F87033F
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%49749B4B01F5;ExportFile { -> F}
//## Uses: <unnamed>%49749FDE027B;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%49749FE100EF;IF::Trace { -> F}
//## Uses: <unnamed>%49749FE40053;reusable::Table { -> F}
//## Uses: <unnamed>%49749FE70026;Database { -> F}
//## Uses: <unnamed>%49749FE9026D;DatabaseFactory { -> F}
//## Uses: <unnamed>%4974A02D03CA;reusable::Query { -> F}
//## Uses: <unnamed>%4974A03000FD;reusable::Statement { -> F}
//## Uses: <unnamed>%4974A0E602A3;timer::Clock { -> F}
//## Uses: <unnamed>%4975FEFC02EF;monitor::UseCase { -> F}
//## Uses: <unnamed>%4978E914007A;timer::Date { -> F}
//## Uses: <unnamed>%498334420398;AESKey { -> F}
//## Uses: <unnamed>%498334CA02E9;AESKeyRing { -> F}
//## Uses: <unnamed>%4989BE690184;reusable::Key { -> F}
//## Uses: <unnamed>%4AF44AB401A2;IF::Console { -> F}
//## Uses: <unnamed>%4AF44ADD0317;GenerationDataGroup { -> F}
//## Uses: <unnamed>%4AFD8E89037F;DESKey { -> F}
//## Uses: <unnamed>%4AFD8E8B02EC;TransportKey { -> F}
//## Uses: <unnamed>%4B264F7B01CC;IBMKey { -> F}
//## Uses: <unnamed>%4C814FAE0378;IF::ResultSet { -> F}
//## Uses: <unnamed>%4C8150870267;IF::Memory { -> F}
//## Uses: <unnamed>%4C81508A0302;DESKey { -> F}
//## Uses: <unnamed>%4C81508D0310;IF::Extract { -> F}

class DllExport AESKeyManager : public reusable::KeyManager  //## Inherits: <unnamed>%49748FB101D7
{
  //## begin database::AESKeyManager%49748F87033F.initialDeclarations preserve=yes
  //## end database::AESKeyManager%49748F87033F.initialDeclarations

  public:
    //## Constructors (generated)
      AESKeyManager();

    //## Destructor (generated)
      virtual ~AESKeyManager();


    //## Other Operations (specified)
      //## Operation: ageKeys%49F5E3D00374
      virtual bool ageKeys (const string& strYYYYMM);

      //## Operation: backup%4977315401D5
      virtual bool backup ();

      //## Operation: begin%4A048113023D
      virtual bool begin ();

      //## Operation: bind%5604159B007C
      bool bind (reusable::Query& hQuery, bool bCount, bool bCONTEXT_KEY, bool bCONTEXT_DATA);

      //## Operation: end%4A048113023E
      virtual bool end ();

      //## Operation: changeMasterKey%4A0469C60254
      virtual bool changeMasterKey ();

      //## Operation: checkEnvironment%501934120380
      bool checkEnvironment ();

      //## Operation: checkKey%49762CF002EB
      virtual bool checkKey (const string& strYYYYMM);

      //## Operation: checkSSLEnvironment%553120BC01A5
      bool checkSSLEnvironment ();

      //## Operation: createDataKey%5514396E011F
      virtual bool createDataKey (const enum Key::KeyType keyType = Key::DES);

      //## Operation: createKey%49749DE1012F
      virtual bool createKey (const string& strYYYYMM);

      //## Operation: createPassPhrase%552431610177
      bool createPassPhrase (string& strPassPhrase);

      //## Operation: createPKCS12%5524316F008A
      bool createPKCS12 (const string& strPassPhrase, const string& strName, EVP_PKEY* pKey, X509* x509);

      //## Operation: createTokens%49DE184C0343
      virtual bool createTokens (const string& strYYYYMM, const string& strStartDate);

      //## Operation: createTransportKey%4C3769C20201
      virtual bool createTransportKey ();

      //## Operation: deleteKey%4975F6000189
      virtual bool deleteKey (const string& strYYYYMM);

      //## Operation: deleteSSLEnvironment%5524319202C2
      bool deleteSSLEnvironment ();

      //## Operation: environmentWarning%50169DDB01D2
      bool environmentWarning (const string& strCommand);

      //## Operation: exportDataKey%4C472A9801E7
      virtual bool exportDataKey (string& strErrorMsg);

      //## Operation: exportSSLCertificate%5524235801DD
      bool exportSSLCertificate ();

      //## Operation: exportTransportKey%4C472A1400DB
      virtual bool exportTransportKey (string& strErrorMsg);

      //## Operation: handleKeyCommands%4C8138B303A6
      virtual bool handleKeyCommands (const string& strCommand, string& strConsoleMsg);

      //## Operation: importDataKey%4B1EAFE10007
      virtual bool importDataKey (const string& strTKCD, const string& strKey, const string& strDKCD, string& strErrorMsg, string& strConsoleMsg);

      //## Operation: importSSLCertificate%55242CAB004A
      virtual bool importSSLCertificate (const string& strPassPhrase);

      //## Operation: importTransportKey%4AF4497901FA
      virtual bool importTransportKey (const string& strContext);

      //## Operation: initialize%497498EC02B1
      virtual bool initialize ();

      //## Operation: initSSLEnvironment%551441530381
      virtual bool initSSLEnvironment ();

      //## Operation: loadSSLEnvironment%5604328E02CA
      bool loadSSLEnvironment ();

      //## Operation: loadSSLEnvironment%55198C3C0237
      virtual bool loadSSLEnvironment (void** pKey, void** x509, void** p12);

      //## Operation: readKeyFile%4AF4498C000F
      virtual bool readKeyFile (const string& strImageId, const string& strTaskId);

      //## Operation: reencryptTokens%49DE185D02A7
      virtual bool reencryptTokens (const string& strYYYYMM);

      //## Operation: reencryptTokens%49F09AF502D8
      virtual bool reencryptTokens ();

      //## Operation: setDefaultDataKey%4C3B6CFA0156
      virtual bool setDefaultDataKey (const string& strKeyId);

      //## Operation: setDefaultTransportKey%4C3B6CE70089
      virtual bool setDefaultTransportKey (const string& strKeyId);

      //## Operation: update%4974957C0175
      virtual void update (Subject* pSubject);

      //## Operation: sendKeyListResponse%4C8143990092
      void sendKeyListResponse ();

      //## Operation: sendKeyImportResponse%4C8143AE021A
      void sendKeyImportResponse (struct sKeyPart& hKeyPart);

      //## Operation: setColumns%5604213E0146
      bool setColumns (reusable::Table& hTable);

      //## Operation: setDefaultAESDataKey%55143C4F0206
      virtual bool setDefaultAESDataKey (const string& strKeyId);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Certificate%55A53CC60391
      const X509* getCertificate () const
      {
        //## begin database::AESKeyManager::getCertificate%55A53CC60391.get preserve=no
        return m_pCertificate;
        //## end database::AESKeyManager::getCertificate%55A53CC60391.get
      }

      void setCertificate (X509*& value)
      {
        //## begin database::AESKeyManager::setCertificate%55A53CC60391.set preserve=no
        m_pCertificate = value;
        //## end database::AESKeyManager::setCertificate%55A53CC60391.set
      }


    // Additional Public Declarations
      //## begin database::AESKeyManager%49748F87033F.public preserve=yes
      string testGenerateKey();
      void initializeKeyGenerator();
      string generateKey2();
      //## end database::AESKeyManager%49748F87033F.public
  protected:
    // Data Members for Class Attributes

      //## begin database::AESKeyManager::Certificate%55A53CC60391.attr preserve=no  public: X509* {U} 0
      X509* m_pCertificate;
      //## end database::AESKeyManager::Certificate%55A53CC60391.attr

    // Additional Protected Declarations
      //## begin database::AESKeyManager%49748F87033F.protected preserve=yes
      //## end database::AESKeyManager%49748F87033F.protected

  private:

    //## Other Operations (specified)
      //## Operation: constructMasterKeys%49EF3441024C
      bool constructMasterKeys (database::AESKey& hMasterKey, database::AESKey& hMasterSeed, const string& strSeed);

      //## Operation: createKey_1%4989B59F00B6
      bool createKey_1 (const string& strYYYYMM, reusable::Key* pMasterKey);

      //## Operation: createMasterKey%4974990D00C4
      bool createMasterKey ();

      //## Operation: generateKey%497498D3011A
      string generateKey ();

      //## Operation: generateBeginDate%4A01A9BF0387
      bool generateBeginDate (string& strBeginDate);

      //## Operation: generateEndDate%4A047DF40108
      bool generateEndDate (string& strEndDate);

      //## Operation: nYYJJJ%4A087BB902EC
      string nYYJJJ (const string& strDate);

      //## Operation: obfuscate%497733A9006B
      bool obfuscate (const string& strYYYYMM, string& strText);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: PrivateKey%55A53CC60395
      const EVP_PKEY* getPrivateKey () const
      {
        //## begin database::AESKeyManager::getPrivateKey%55A53CC60395.get preserve=no
        return m_pPrivateKey;
        //## end database::AESKeyManager::getPrivateKey%55A53CC60395.get
      }

      void setPrivateKey (EVP_PKEY*& value)
      {
        //## begin database::AESKeyManager::setPrivateKey%55A53CC60395.set preserve=no
        m_pPrivateKey = value;
        //## end database::AESKeyManager::setPrivateKey%55A53CC60395.set
      }


      //## Attribute: PublicKey%55A53CC6039A
      const EVP_PKEY* getPublicKey () const
      {
        //## begin database::AESKeyManager::getPublicKey%55A53CC6039A.get preserve=no
        return m_pPublicKey;
        //## end database::AESKeyManager::getPublicKey%55A53CC6039A.get
      }

      void setPublicKey (EVP_PKEY*& value)
      {
        //## begin database::AESKeyManager::setPublicKey%55A53CC6039A.set preserve=no
        m_pPublicKey = value;
        //## end database::AESKeyManager::setPublicKey%55A53CC6039A.set
      }


    // Additional Private Declarations
      //## begin database::AESKeyManager%49748F87033F.private preserve=yes
      //## end database::AESKeyManager%49748F87033F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DATE%49DE1C4300B7
      //## begin database::AESKeyManager::DATE%49DE1C4300B7.attr preserve=no  private: string {U} 
      string m_strDATE;
      //## end database::AESKeyManager::DATE%49DE1C4300B7.attr

      //## Attribute: SEQ_NO%49DE1B78039A
      //## begin database::AESKeyManager::SEQ_NO%49DE1B78039A.attr preserve=no  private: int {U} 
      int m_iSEQ_NO;
      //## end database::AESKeyManager::SEQ_NO%49DE1B78039A.attr

      //## Attribute: TOKEN%49DE1B5800C3
      //## begin database::AESKeyManager::TOKEN%49DE1B5800C3.attr preserve=no  private: string {U} 
      string m_strTOKEN;
      //## end database::AESKeyManager::TOKEN%49DE1B5800C3.attr

      //## Attribute: YYYYMM%49DE1C440299
      //## begin database::AESKeyManager::YYYYMM%49DE1C440299.attr preserve=no  private: string {U} 
      string m_strYYYYMM;
      //## end database::AESKeyManager::YYYYMM%49DE1C440299.attr

      //## Attribute: CONTEXT_KEY%49EF3BE700B7
      //## begin database::AESKeyManager::CONTEXT_KEY%49EF3BE700B7.attr preserve=no  private: string[2] {U} 
      string m_strCONTEXT_KEY[2];
      //## end database::AESKeyManager::CONTEXT_KEY%49EF3BE700B7.attr

      //## Attribute: CONTEXT_DATA%49EF3C20020E
      //## begin database::AESKeyManager::CONTEXT_DATA%49EF3C20020E.attr preserve=no  private: string[2] {U} 
      string m_strCONTEXT_DATA[2];
      //## end database::AESKeyManager::CONTEXT_DATA%49EF3C20020E.attr

      //## Attribute: Count%5604188801D1
      //## begin database::AESKeyManager::Count%5604188801D1.attr preserve=no  private: int {U} 0
      int m_lCount;
      //## end database::AESKeyManager::Count%5604188801D1.attr

      //## Attribute: PassPhrase%560433070120
      //## begin database::AESKeyManager::PassPhrase%560433070120.attr preserve=no  private: string {U} 
      string m_strPassPhrase;
      //## end database::AESKeyManager::PassPhrase%560433070120.attr

      //## begin database::AESKeyManager::PrivateKey%55A53CC60395.attr preserve=no  private: EVP_PKEY* {U} 0
      EVP_PKEY* m_pPrivateKey;
      //## end database::AESKeyManager::PrivateKey%55A53CC60395.attr

      //## begin database::AESKeyManager::PublicKey%55A53CC6039A.attr preserve=no  private: EVP_PKEY* {U} 0
      EVP_PKEY* m_pPublicKey;
      //## end database::AESKeyManager::PublicKey%55A53CC6039A.attr

      //## Attribute: ServerP12%5604331F0281
      //## begin database::AESKeyManager::ServerP12%5604331F0281.attr preserve=no  private: string {U} 
      string m_strServerP12;
      //## end database::AESKeyManager::ServerP12%5604331F0281.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%49EE08C30196
      //## Role: AESKeyManager::<m_hExportFile>%49EE08C50167
      //## begin database::AESKeyManager::<m_hExportFile>%49EE08C50167.role preserve=no  public: database::ExportFile { -> VFHgN}
      ExportFile m_hExportFile;
      //## end database::AESKeyManager::<m_hExportFile>%49EE08C50167.role

    // Additional Implementation Declarations
      //## begin database::AESKeyManager%49748F87033F.implementation preserve=yes
      AESKey m_hMasterKey[2];
      AESKey m_hMasterSeed[2];
      string m_strStatusMsg;
      string m_strKeyGenerator;
      char m_szKeyGenerator[65];
      string m_strServerPrivateKey;
      string m_strServerCertificate;
      string m_strServerPrivateKeyPhrase;
      string m_strServerP12Partial;
      //## end database::AESKeyManager%49748F87033F.implementation
};

//## begin database::AESKeyManager%49748F87033F.postscript preserve=yes
//## end database::AESKeyManager%49748F87033F.postscript

} // namespace database

//## begin module%4974904400B6.epilog preserve=yes
//## end module%4974904400B6.epilog


#endif
