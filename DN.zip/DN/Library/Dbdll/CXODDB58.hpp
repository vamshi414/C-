//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5ADE4F7D0301.cm preserve=no
//	$Date:   Jan 02 2019 21:46:04  $ $Author:   e1009839  $ $Revision:   1.3  $
//## end module%5ADE4F7D0301.cm

//## begin module%5ADE4F7D0301.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5ADE4F7D0301.cp

//## Module: CXOSDB58%5ADE4F7D0301; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB58.hpp

#ifndef CXOSDB58_h
#define CXOSDB58_h 1

//## begin module%5ADE4F7D0301.additionalIncludes preserve=no
//## end module%5ADE4F7D0301.additionalIncludes

//## begin module%5ADE4F7D0301.includes preserve=yes
//## end module%5ADE4F7D0301.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class RowVisitor;

} // namespace database

//## begin module%5ADE4F7D0301.declarations preserve=no
//## end module%5ADE4F7D0301.declarations

//## begin module%5ADE4F7D0301.additionalDeclarations preserve=yes
//## end module%5ADE4F7D0301.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::RowSet%5ADE4EE60091.preface preserve=yes
//## end database::RowSet%5ADE4EE60091.preface

//## Class: RowSet%5ADE4EE60091
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5ADF34B80079;reusable::Query { -> F}
//## Uses: <unnamed>%5ADF364101F3;RowVisitor { -> F}
//## Uses: <unnamed>%5AE9DC2C02DD;timer::Clock { -> F}

class DllExport RowSet : public reusable::Object  //## Inherits: <unnamed>%5ADE4EFE0135
{
  //## begin database::RowSet%5ADE4EE60091.initialDeclarations preserve=yes
  //## end database::RowSet%5ADE4EE60091.initialDeclarations

  public:
    //## Constructors (generated)
      RowSet();

      RowSet(const RowSet &right);

    //## Constructors (specified)
      //## Operation: RowSet%5AF260A40345
      RowSet (const string& strName);

      //## Operation: RowSet%5AF19B990273
      RowSet (const string& strName, RowSet* pNext);

    //## Destructor (generated)
      virtual ~RowSet();

    //## Equality Operations (generated)
      bool operator==(const RowSet &right) const;

      bool operator!=(const RowSet &right) const;


    //## Other Operations (specified)
      //## Operation: append%5ADF236F01F3
      void append (int nIndex, int iSize, void* pValue, short iNull);

      //## Operation: clear%5AF2E33F0044
      void clear ();

      //## Operation: close%5AEB07A4008A
      void close ();

      //## Operation: closed%5AEB07AC0176
      bool closed ();

      //## Operation: key%5AF19C1C0193
      const int key () const;

      //## Operation: retrieve%5ADF3486013B
      int retrieve (reusable::Query& hQuery);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Clock%5AE9DBF603E0
      const reusable::string& getClock () const
      {
        //## begin database::RowSet::getClock%5AE9DBF603E0.get preserve=no
        return m_strClock;
        //## end database::RowSet::getClock%5AE9DBF603E0.get
      }


      //## Attribute: InUse%5BEEDA84030F
      const short getInUse () const
      {
        //## begin database::RowSet::getInUse%5BEEDA84030F.get preserve=no
        return m_siInUse;
        //## end database::RowSet::getInUse%5BEEDA84030F.get
      }

      void setInUse (short value)
      {
        //## begin database::RowSet::setInUse%5BEEDA84030F.set preserve=no
        m_siInUse = value;
        //## end database::RowSet::setInUse%5BEEDA84030F.set
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::Database_CAT::<unnamed>%5AF258040041
      //## Role: RowSet::<m_pNext>%5AF258040307
      RowSet * getNext ()
      {
        //## begin database::RowSet::getNext%5AF258040307.get preserve=no
        return m_pNext;
        //## end database::RowSet::getNext%5AF258040307.get
      }

      void setNext (RowSet * value)
      {
        //## begin database::RowSet::setNext%5AF258040307.set preserve=no
        m_pNext = value;
        //## end database::RowSet::setNext%5AF258040307.set
      }


      //## Association: Connex Library::Database_CAT::<unnamed>%5AF25FCD0038
      //## Role: RowSet::<m_pPrevious>%5AF25FCD0375
      RowSet * getPrevious ()
      {
        //## begin database::RowSet::getPrevious%5AF25FCD0375.get preserve=no
        return m_pPrevious;
        //## end database::RowSet::getPrevious%5AF25FCD0375.get
      }

      void setPrevious (RowSet * value)
      {
        //## begin database::RowSet::setPrevious%5AF25FCD0375.set preserve=no
        m_pPrevious = value;
        //## end database::RowSet::setPrevious%5AF25FCD0375.set
      }


    // Additional Public Declarations
      //## begin database::RowSet%5ADE4EE60091.public preserve=yes
      int getTotal () const
      {
        return m_iTotal;
      }
      void append(int nRow,int nIndex,int iSize,void* pValue,short iNull);


      //## end database::RowSet%5ADE4EE60091.public
  protected:
    // Additional Protected Declarations
      //## begin database::RowSet%5ADE4EE60091.protected preserve=yes
      //## end database::RowSet%5ADE4EE60091.protected

  private:
    // Additional Private Declarations
      //## begin database::RowSet%5ADE4EE60091.private preserve=yes
      //## end database::RowSet%5ADE4EE60091.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin database::RowSet::Clock%5AE9DBF603E0.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strClock;
      //## end database::RowSet::Clock%5AE9DBF603E0.attr

      //## begin database::RowSet::InUse%5BEEDA84030F.attr preserve=no  public: short {V} 0
      short m_siInUse;
      //## end database::RowSet::InUse%5BEEDA84030F.attr

      //## Attribute: Name%5AF19BDF01BA
      //## begin database::RowSet::Name%5AF19BDF01BA.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strName;
      //## end database::RowSet::Name%5AF19BDF01BA.attr

      //## Attribute: Row%5ADF27B90159
      //## begin database::RowSet::Row%5ADF27B90159.attr preserve=no  private: vector<string> {V} 
      vector<string> m_hRow;
      //## end database::RowSet::Row%5ADF27B90159.attr

      //## Attribute: Total%5AEB08C90349
      //## begin database::RowSet::Total%5AEB08C90349.attr preserve=no  private: int {V} 0
      int m_iTotal;
      //## end database::RowSet::Total%5AEB08C90349.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%5AF258040041
      //## begin database::RowSet::<m_pNext>%5AF258040307.role preserve=no  public: database::RowSet { -> RFHgN}
      RowSet *m_pNext;
      //## end database::RowSet::<m_pNext>%5AF258040307.role

      //## Association: Connex Library::Database_CAT::<unnamed>%5AF25FCD0038
      //## begin database::RowSet::<m_pPrevious>%5AF25FCD0375.role preserve=no  public: database::RowSet { -> RFHgN}
      RowSet *m_pPrevious;
      //## end database::RowSet::<m_pPrevious>%5AF25FCD0375.role

    // Additional Implementation Declarations
      //## begin database::RowSet%5ADE4EE60091.implementation preserve=yes
      //## end database::RowSet%5ADE4EE60091.implementation

};

//## begin database::RowSet%5ADE4EE60091.postscript preserve=yes
//## end database::RowSet%5ADE4EE60091.postscript

} // namespace database

//## begin module%5ADE4F7D0301.epilog preserve=yes
//## end module%5ADE4F7D0301.epilog


#endif
