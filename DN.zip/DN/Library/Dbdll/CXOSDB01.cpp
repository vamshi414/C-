//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%366E8F550292.cm preserve=no
//## end module%366E8F550292.cm

//## begin module%366E8F550292.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%366E8F550292.cp

//## Module: CXOSDB01%366E8F550292; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB01.cpp

//## begin module%366E8F550292.additionalIncludes preserve=no
//## end module%366E8F550292.additionalIncludes

//## begin module%366E8F550292.includes preserve=yes
#include "CXODDB43.hpp"
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif
#include "CXODDB21.hpp"
#ifndef MVS
#include "CXODDB70.hpp"
#endif
//## end module%366E8F550292.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF20_h
#include "CXODIF20.hpp"
#endif
#ifndef CXOSTM11_h
#include "CXODTM11.hpp"
#endif
#ifndef CXOSDB33_h
#include "CXODDB33.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU55_h
#include "CXODRU55.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif


//## begin module%366E8F550292.declarations preserve=no
//## end module%366E8F550292.declarations

//## begin module%366E8F550292.additionalDeclarations preserve=yes
//## end module%366E8F550292.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::Database 

//## begin database::Database::Instance%5C0591F900B5.attr preserve=no  private: static database::Database* {V} 0
database::Database* Database::m_pInstance = 0;
//## end database::Database::Instance%5C0591F900B5.attr

Database::Database()
  //## begin Database::Database%3452433401B8_const.hasinit preserve=no
      : m_bDisconnect(false),
        m_bDormant(true),
        m_nTransaction(0)
  //## end Database::Database%3452433401B8_const.hasinit
  //## begin Database::Database%3452433401B8_const.initialization preserve=yes
  //## end Database::Database%3452433401B8_const.initialization
{
  //## begin database::Database::Database%3452433401B8_const.body preserve=yes
   m_nState = NEVERCONNECTED;
   m_nTransactionState = IDLE;
   AESKeyRing::instance();
#ifndef MVS
   new database::PenkoToken();
#endif
  //## end database::Database::Database%3452433401B8_const.body
}


Database::~Database()
{
  //## begin database::Database::~Database%3452433401B8_dest.body preserve=yes
  //## end database::Database::~Database%3452433401B8_dest.body
}



//## Other Operations (implementation)
int Database::commit ()
{
  //## begin database::Database::commit%34549605022D.body preserve=yes
   m_nTransactionState = IDLE;
   char szTrace[64];
   Trace::put(szTrace,snprintf(szTrace,sizeof(szTrace),"Database::commit(), Transaction: %d",++m_nTransaction));
   GMTClock::instance()->update(0);
   SharedResource::commit();
   return 0;
  //## end database::Database::commit%34549605022D.body
}

bool Database::connect ()
{
  //## begin database::Database::connect%3470DC8E006A.body preserve=yes
   setState(Database::CONNECTED);
   return true;
  //## end database::Database::connect%3470DC8E006A.body
}

bool Database::connect (char* pszSubSystem, char* pszPlan)
{
  //## begin database::Database::connect%3821964900E4.body preserve=yes
   setState(Database::CONNECTED);
   return true;
  //## end database::Database::connect%3821964900E4.body
}

void Database::disconnect ()
{
  //## begin database::Database::disconnect%3470DC960198.body preserve=yes
  //## end database::Database::disconnect%3470DC960198.body
}

bool Database::getDormant ()
{
  //## begin database::Database::getDormant%3CA388AD006D.body preserve=yes
   if (m_nTransactionState == IDLE)
      m_nTransactionState = BUSY;
   return m_bDormant;
  //## end database::Database::getDormant%3CA388AD006D.body
}

Database* Database::instance (int i)
{
  //## begin database::Database::instance%3470E00D01F8.body preserve=yes
   if (!m_pInstance)
   {
     if (!DatabaseFactory::instance())
        m_pInstance = new Database();
     else
        m_pInstance = (Database*)DatabaseFactory::instance()->create("Database");
      Filter::instance();
   }
   return m_pInstance;
  //## end database::Database::instance%3470E00D01F8.body
}

const string Database::qualifier (const char* pszQualifier) const
{
  //## begin database::Database::qualifier%374D73770085.body preserve=yes
   if (!strcmp(pszQualifier,"CUSTQUAL"))
   {
      if (Transaction::instance()->getQualifier() == "CUSTQUAL")
         return m_strQualifier;
      else
         return Transaction::instance()->getQualifier();
   }
   if (!strcmp(pszQualifier,"QUALIFY"))
      return m_strCommonQualifier;
   return string(pszQualifier);
  //## end database::Database::qualifier%374D73770085.body
}

int Database::rollback ()
{
  //## begin database::Database::rollback%3454960B0069.body preserve=yes
   m_nTransactionState = IDLE;
   char szTrace[64];
   Trace::put(szTrace,snprintf(szTrace,sizeof(szTrace),"Database::rollback(), Transaction: %d",++m_nTransaction));
   GMTClock::instance()->update(0);
   SharedResource::rollback();
   return 0;
  //## end database::Database::rollback%3454960B0069.body
}

void Database::setState (Database::databaseState nState)
{
  //## begin database::Database::setState%366E9C1F0128.body preserve=yes
   if (m_nState == NEVERCONNECTED
      && nState == DISCONNECTED)
      return;
   if (m_nState != nState)
   {
      if (m_nState == NEVERCONNECTED
         && nState == CONNECTED)
      {
         m_nState = nState;
         database::Cache::initialize();
         notify();
      }
      else
         m_nState = nState;
   }
  //## end database::Database::setState%366E9C1F0128.body
}

void Database::setTransactionState (Database::workState nTransactionState)
{
  //## begin database::Database::setTransactionState%43A97B31002E.body preserve=yes
   if (m_nTransactionState != Database::ROLLBACKREQUIRED)
      m_nTransactionState = nTransactionState;
  //## end database::Database::setTransactionState%43A97B31002E.body
}

void Database::traceSQLError (void* p, const char* pszID, const char* pszMethodName)
{
  //## begin database::Database::traceSQLError%34F48B630103.body preserve=yes
  //## end database::Database::traceSQLError%34F48B630103.body
}

void Database::traceSQLError (const string& strMessage)
{
  //## begin database::Database::traceSQLError%444A1638037A.body preserve=yes
  //## end database::Database::traceSQLError%444A1638037A.body
}

const char* Database::upper ()
{
  //## begin database::Database::upper%53A89D2D0291.body preserve=yes
   return "UPPER";
  //## end database::Database::upper%53A89D2D0291.body
}

// Additional Declarations
  //## begin database::Database%3452433401B8.declarations preserve=yes
  //## end database::Database%3452433401B8.declarations

} // namespace database

//## begin module%366E8F550292.epilog preserve=yes
//## end module%366E8F550292.epilog
