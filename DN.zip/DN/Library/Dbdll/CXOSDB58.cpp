//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5ADE4F7F01EA.cm preserve=no
//	$Date:   May 14 2020 18:12:44  $ $Author:   e1009510  $ $Revision:   1.4  $
//## end module%5ADE4F7F01EA.cm

//## begin module%5ADE4F7F01EA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5ADE4F7F01EA.cp

//## Module: CXOSDB58%5ADE4F7F01EA; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB58.cpp

//## begin module%5ADE4F7F01EA.additionalIncludes preserve=no
//## end module%5ADE4F7F01EA.additionalIncludes

//## begin module%5ADE4F7F01EA.includes preserve=yes
#include "CXODIF03.hpp"
//## end module%5ADE4F7F01EA.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB59_h
#include "CXODDB59.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSDB58_h
#include "CXODDB58.hpp"
#endif


//## begin module%5ADE4F7F01EA.declarations preserve=no
//## end module%5ADE4F7F01EA.declarations

//## begin module%5ADE4F7F01EA.additionalDeclarations preserve=yes
//## end module%5ADE4F7F01EA.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::RowSet

RowSet::RowSet()
  //## begin RowSet::RowSet%5ADE4EE60091_const.hasinit preserve=no
      : m_siInUse(0),
        m_iTotal(0),
        m_pNext(0),
        m_pPrevious(0)
  //## end RowSet::RowSet%5ADE4EE60091_const.hasinit
  //## begin RowSet::RowSet%5ADE4EE60091_const.initialization preserve=yes
  //## end RowSet::RowSet%5ADE4EE60091_const.initialization
{
  //## begin database::RowSet::RowSet%5ADE4EE60091_const.body preserve=yes
   memcpy_s(m_sID,4,"DB58",4);
  //## end database::RowSet::RowSet%5ADE4EE60091_const.body
}

RowSet::RowSet(const RowSet &right)
  //## begin RowSet::RowSet%5ADE4EE60091_copy.hasinit preserve=no
  //## end RowSet::RowSet%5ADE4EE60091_copy.hasinit
  //## begin RowSet::RowSet%5ADE4EE60091_copy.initialization preserve=yes
   : Object(right)
   ,m_strClock(right.m_strClock)
   ,m_strName(right.m_strName)
  //## end RowSet::RowSet%5ADE4EE60091_copy.initialization
{
  //## begin database::RowSet::RowSet%5ADE4EE60091_copy.body preserve=yes
   m_siInUse = right.m_siInUse;
   m_pNext = right.m_pNext;
   m_pPrevious = right.m_pPrevious;
   m_hRow = right.m_hRow;
   m_iTotal = right.m_iTotal;
  //## end database::RowSet::RowSet%5ADE4EE60091_copy.body
}

RowSet::RowSet (const string& strName)
  //## begin database::RowSet::RowSet%5AF260A40345.hasinit preserve=no
      : m_siInUse(0),
        m_iTotal(0),
        m_pNext(0),
        m_pPrevious(0)
  //## end database::RowSet::RowSet%5AF260A40345.hasinit
  //## begin database::RowSet::RowSet%5AF260A40345.initialization preserve=yes
   ,m_strName(strName)
  //## end database::RowSet::RowSet%5AF260A40345.initialization
{
  //## begin database::RowSet::RowSet%5AF260A40345.body preserve=yes
   memcpy_s(m_sID,4,"DB58",4);
  //## end database::RowSet::RowSet%5AF260A40345.body
}

RowSet::RowSet (const string& strName, database::RowSet* pNext)
  //## begin database::RowSet::RowSet%5AF19B990273.hasinit preserve=no
      : m_siInUse(0),
        m_iTotal(0),
        m_pNext(0),
        m_pPrevious(0)
  //## end database::RowSet::RowSet%5AF19B990273.hasinit
  //## begin database::RowSet::RowSet%5AF19B990273.initialization preserve=yes
   ,m_strName(strName)
  //## end database::RowSet::RowSet%5AF19B990273.initialization
{
  //## begin database::RowSet::RowSet%5AF19B990273.body preserve=yes
   memcpy_s(m_sID,4,"DB58",4);
   m_pNext = pNext;
  //## end database::RowSet::RowSet%5AF19B990273.body
}


RowSet::~RowSet()
{
  //## begin database::RowSet::~RowSet%5ADE4EE60091_dest.body preserve=yes
  //## end database::RowSet::~RowSet%5ADE4EE60091_dest.body
}


bool RowSet::operator==(const RowSet &right) const
{
  //## begin database::RowSet::operator==%5ADE4EE60091_eq.body preserve=yes
   return m_strName == right.m_strName;
  //## end database::RowSet::operator==%5ADE4EE60091_eq.body
}

bool RowSet::operator!=(const RowSet &right) const
{
  //## begin database::RowSet::operator!=%5ADE4EE60091_neq.body preserve=yes
   return m_strName != right.m_strName;
  //## end database::RowSet::operator!=%5ADE4EE60091_neq.body
}



//## Other Operations (implementation)
void RowSet::append (int nIndex, int iSize, void* pValue, short iNull)
{
  //## begin database::RowSet::append%5ADF236F01F3.body preserve=yes
   if (closed())
      return;
   if (nIndex == 0)
   {
      string x;
      if (!m_hRow.empty())
      {
         Trace::put(m_hRow.back().data(),m_hRow.back().length());
         x.reserve(m_iTotal / m_hRow.size());
      }
      m_hRow.push_back(x);
   }
   m_hRow.back().append(iNull == -1 ? "Y" : "N");
   char szTemp[PERCENTD];
   m_hRow.back().append(szTemp,snprintf(szTemp,sizeof(szTemp),"%04d",iSize));
   m_hRow.back().append((char*)pValue,iSize);
   m_hRow.back().append("\0",1);
   m_iTotal += 6;
   m_iTotal += iSize;
  //## end database::RowSet::append%5ADF236F01F3.body
}

void RowSet::clear ()
{
  //## begin database::RowSet::clear%5AF2E33F0044.body preserve=yes
   m_hRow.erase(m_hRow.begin(),m_hRow.end());
  //## end database::RowSet::clear%5AF2E33F0044.body
}

void RowSet::close ()
{
  //## begin database::RowSet::close%5AEB07A4008A.body preserve=yes
   if (!m_hRow.empty())
      Trace::put(m_hRow.back().data(),m_hRow.back().length());
   m_strClock = Clock::instance()->getYYYYMMDDHHMMSS();
  //## end database::RowSet::close%5AEB07A4008A.body
}

bool RowSet::closed ()
{
  //## begin database::RowSet::closed%5AEB07AC0176.body preserve=yes
   return m_strClock.size() > 0;
  //## end database::RowSet::closed%5AEB07AC0176.body
}

const int RowSet::key () const
{
  //## begin database::RowSet::key%5AF19C1C0193.body preserve=yes
   int h = 0;
   for (int i = 0;i < m_strName.length();i++)
   {
      h += m_strName[i];
      h += (h << 10);
      h ^= (h >> 6);
   }
   h += (h << 3);
   h ^= (h >> 11);
   h += (h << 15);
   if (h < 0)
      h = 0 - h;
   return h;
  //## end database::RowSet::key%5AF19C1C0193.body
}

int RowSet::retrieve (reusable::Query& hQuery)
{
  //## begin database::RowSet::retrieve%5ADF3486013B.body preserve=yes
   int i = 0;
   for (vector<string>::iterator p = m_hRow.begin();p != m_hRow.end();++p)
   {
      RowVisitor hRowVisitor((*p));
      hQuery.accept(hRowVisitor);
      hQuery.notify();
      ++i;
      if (hQuery.getAbort())
         break;
   }
   return i;
  //## end database::RowSet::retrieve%5ADF3486013B.body
}

// Additional Declarations
  //## begin database::RowSet%5ADE4EE60091.declarations preserve=yes
void RowSet::append(int nRow, int nIndex, int iSize, void* pValue, short iNull)
{
   //## begin database::RowSet::append%5ADF236F01F3.body preserve=yes
    m_hRow[nRow].append(iNull == -1 ? "Y" : "N");
    char szTemp[PERCENTD];
    m_hRow[nRow].append(szTemp,snprintf(szTemp,sizeof(szTemp),"%04d",iSize));
    m_hRow[nRow].append((char*)pValue,iSize);
    m_hRow[nRow].append("\0",1);
    m_iTotal += 6;
    m_iTotal += iSize;
   //## end database::RowSet::append%5ADF236F01F3.body
}

  //## end database::RowSet%5ADE4EE60091.declarations

} // namespace database

//## begin module%5ADE4F7F01EA.epilog preserve=yes
//## end module%5ADE4F7F01EA.epilog
