//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5360F1CB028C.cm preserve=no
// $Date:   Jun 27 2014 08:55:48  $ $Author:   e1009839  $ $Revision:   1.0  $
//## end module%5360F1CB028C.cm

//## begin module%5360F1CB028C.cp preserve=no
// Copyright (c) 1997 - 2012
// FIS
//## end module%5360F1CB028C.cp

//## Module: CXOSDB45%5360F1CB028C; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
// .
//## Source file: C:\bV02.5A.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB45.cpp

//## begin module%5360F1CB028C.additionalIncludes preserve=no
//## end module%5360F1CB028C.additionalIncludes

//## begin module%5360F1CB028C.includes preserve=yes
//## end module%5360F1CB028C.includes

#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB45_h
#include "CXODDB45.hpp"
#endif


//## begin module%5360F1CB028C.declarations preserve=no
//## end module%5360F1CB028C.declarations

//## begin module%5360F1CB028C.additionalDeclarations preserve=yes
#define STS_RECORD_NOT_FOUND 14
//## end module%5360F1CB028C.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::TaskLife

TaskLife::TaskLife()
  //## begin TaskLife::TaskLife%5360F125024F_const.hasinit preserve=no
      : m_iMaxDays(180)
  //## end TaskLife::TaskLife%5360F125024F_const.hasinit
  //## begin TaskLife::TaskLife%5360F125024F_const.initialization preserve=yes
  //## end TaskLife::TaskLife%5360F125024F_const.initialization
{
  //## begin database::TaskLife::TaskLife%5360F125024F_const.body preserve=yes
   memcpy(m_sID,"DB45",4);
  //## end database::TaskLife::TaskLife%5360F125024F_const.body
}

TaskLife::TaskLife (const string &strIMAGEID, const string &strTASKID)
  //## begin database::TaskLife::TaskLife%53A93F870167.hasinit preserve=no
      : m_iMaxDays(180)
  //## end database::TaskLife::TaskLife%53A93F870167.hasinit
  //## begin database::TaskLife::TaskLife%53A93F870167.initialization preserve=yes
   ,m_strIMAGEID(strIMAGEID)
   ,m_strTASKID(strTASKID)
  //## end database::TaskLife::TaskLife%53A93F870167.initialization
{
  //## begin database::TaskLife::TaskLife%53A93F870167.body preserve=yes
   memcpy(m_sID,"DB45",4);
   m_strSTART_TIME = Clock::instance()->getYYYYMMDDHHMMSSHN();
   MinuteTimer::instance()->attach(this);
   MidnightAlarm::instance()->attach(this);
   Extract::instance()->getLong("DUSER   ","MAXDAYS=",&m_iMaxDays);
  //## end database::TaskLife::TaskLife%53A93F870167.body
}


TaskLife::~TaskLife()
{
  //## begin database::TaskLife::~TaskLife%5360F125024F_dest.body preserve=yes
   MinuteTimer::instance()->detach(this);
   MidnightAlarm::instance()->detach(this);
   update(0);
  //## end database::TaskLife::~TaskLife%5360F125024F_dest.body
}



//## Other Operations (implementation)
void TaskLife::update (Subject* pSubject)
{
  //## begin database::TaskLife::update%5360F8D502B4.body preserve=yes
   if (pSubject == MinuteTimer::instance()
      || pSubject == 0)
   {
      Table hTable("TASK_LIFE");
      hTable.setQualifier("QUALIFY");
      hTable.set("IMAGEID",m_strIMAGEID,false,true);
      hTable.set("TASKID",m_strTASKID,false,true);
      hTable.set("START_TIME",m_strSTART_TIME,false,true);
      hTable.set("END_TIME",Clock::instance()->getYYYYMMDDHHMMSSHN());
      if (pSubject == 0)
         hTable.set("END_STATUS","S");
      else
         hTable.set("END_STATUS","A");
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      if (pUpdateStatement->execute(hTable) == false
         && pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      {
         auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         pInsertStatement->execute(hTable);
      }
   }
   else
   {
      Date hDate(Date::today());
      hDate -= m_iMaxDays;
      string strDate(hDate.asString("%Y%m%d"));
      Query hQuery;
      hQuery.setQualifier("QUALIFY","TASK_LIFE");
      hQuery.setBasicPredicate("TASK_LIFE","END_TIME","<",strDate.c_str());
      hQuery.setBasicPredicate("TASK_LIFE","IMAGEID","=",m_strIMAGEID.c_str());
      hQuery.setBasicPredicate("TASK_LIFE","TASKID","=",m_strTASKID.c_str());
      auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
      pDeleteStatement->execute(hQuery);
   }
   Database::instance()->commit();
  //## end database::TaskLife::update%5360F8D502B4.body
}

// Additional Declarations
  //## begin database::TaskLife%5360F125024F.declarations preserve=yes
  //## end database::TaskLife%5360F125024F.declarations

} // namespace database

//## begin module%5360F1CB028C.epilog preserve=yes
//## end module%5360F1CB028C.epilog
