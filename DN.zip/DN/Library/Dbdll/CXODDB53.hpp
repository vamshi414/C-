//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%585D57A80335.cm preserve=no
//	$Date:   Jan 19 2017 15:54:48  $ $Author:   e1009839  $ $Revision:   1.2  $
//## end module%585D57A80335.cm

//## begin module%585D57A80335.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%585D57A80335.cp

//## Module: CXOSDB53%585D57A80335; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB53.hpp

#ifndef CXOSDB53_h
#define CXOSDB53_h 1

//## begin module%585D57A80335.additionalIncludes preserve=no
//## end module%585D57A80335.additionalIncludes

//## begin module%585D57A80335.includes preserve=yes
#include <vector>
//## end module%585D57A80335.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;

} // namespace timer

//## begin module%585D57A80335.declarations preserve=no
//## end module%585D57A80335.declarations

//## begin module%585D57A80335.additionalDeclarations preserve=yes
//## end module%585D57A80335.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::SQLCache%585D56D20017.preface preserve=yes
//## end database::SQLCache%585D56D20017.preface

//## Class: SQLCache%585D56D20017
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%585D585303C1;timer::Clock { -> F}

class DllExport SQLCache : public reusable::Object  //## Inherits: <unnamed>%585D56E60129
{
  //## begin database::SQLCache%585D56D20017.initialDeclarations preserve=yes
  //## end database::SQLCache%585D56D20017.initialDeclarations

  public:
    //## Constructors (generated)
      SQLCache();

    //## Destructor (generated)
      virtual ~SQLCache();


    //## Other Operations (specified)
      //## Operation: clear%585D6C2C0253
      void clear ();

      //## Operation: free%588113E301BD
      void free (int nInstance);

      //## Operation: save%585D575601B2
      bool save (const string& strSQLText, int& nInstance);

    // Additional Public Declarations
      //## begin database::SQLCache%585D56D20017.public preserve=yes
      //## end database::SQLCache%585D56D20017.public

  protected:
    // Additional Protected Declarations
      //## begin database::SQLCache%585D56D20017.protected preserve=yes
      //## end database::SQLCache%585D56D20017.protected

  private:
    // Additional Private Declarations
      //## begin database::SQLCache%585D56D20017.private preserve=yes
      //## end database::SQLCache%585D56D20017.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: SQLText%585D570E01A7
      //## begin database::SQLCache::SQLText%585D570E01A7.attr preserve=no  private: vector<string> {V} 
      vector<string> m_hSQLText;
      //## end database::SQLCache::SQLText%585D570E01A7.attr

      //## Attribute: Timestamp%585D570E01B1
      //## begin database::SQLCache::Timestamp%585D570E01B1.attr preserve=no  private: vector<string> {V} 
      vector<string> m_hTimestamp;
      //## end database::SQLCache::Timestamp%585D570E01B1.attr

    // Additional Implementation Declarations
      //## begin database::SQLCache%585D56D20017.implementation preserve=yes
      //## end database::SQLCache%585D56D20017.implementation

};

//## begin database::SQLCache%585D56D20017.postscript preserve=yes
//## end database::SQLCache%585D56D20017.postscript

} // namespace database

//## begin module%585D57A80335.epilog preserve=yes
//## end module%585D57A80335.epilog


#endif
