//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%49831D5B027F.cm preserve=no
//	$Date:   Aug 06 2012 15:14:04  $ $Author:   E1009652  $ $Revision:   1.4  $
//## end module%49831D5B027F.cm

//## begin module%49831D5B027F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%49831D5B027F.cp

//## Module: CXOSDB36%49831D5B027F; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB36.cpp

//## begin module%49831D5B027F.additionalIncludes preserve=no
//## end module%49831D5B027F.additionalIncludes

//## begin module%49831D5B027F.includes preserve=yes
//## end module%49831D5B027F.includes

#ifndef CXOSDB32_h
#include "CXODDB32.hpp"
#endif
#ifndef CXOSDB33_h
#include "CXODDB33.hpp"
#endif
#ifndef CXOSDB36_h
#include "CXODDB36.hpp"
#endif


//## begin module%49831D5B027F.declarations preserve=no
//## end module%49831D5B027F.declarations

//## begin module%49831D5B027F.additionalDeclarations preserve=yes
//## end module%49831D5B027F.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::AESKeyFactory 

AESKeyFactory::AESKeyFactory()
  //## begin AESKeyFactory::AESKeyFactory%49831BFF0242_const.hasinit preserve=no
  //## end AESKeyFactory::AESKeyFactory%49831BFF0242_const.hasinit
  //## begin AESKeyFactory::AESKeyFactory%49831BFF0242_const.initialization preserve=yes
  //## end AESKeyFactory::AESKeyFactory%49831BFF0242_const.initialization
{
  //## begin database::AESKeyFactory::AESKeyFactory%49831BFF0242_const.body preserve=yes
   memcpy(m_sID,"DB36",4);
  //## end database::AESKeyFactory::AESKeyFactory%49831BFF0242_const.body
}


AESKeyFactory::~AESKeyFactory()
{
  //## begin database::AESKeyFactory::~AESKeyFactory%49831BFF0242_dest.body preserve=yes
  //## end database::AESKeyFactory::~AESKeyFactory%49831BFF0242_dest.body
}



//## Other Operations (implementation)
Object* AESKeyFactory::create (const char* pszClass)
{
  //## begin database::AESKeyFactory::create%4983227501B4.body preserve=yes
   if(m_hClasses.size() == 0)
   {
      #define CLASSES 2
      const char* pszClass[CLASSES] =
      {
         "KeyManager",
         "KeyRing"
      };
      for (int i = 0; i < CLASSES; ++i)
         m_hClasses.insert(map<string,int,less<string> >::value_type(string(pszClass[i]),i));
   }
   map<string,int,less<string> >::iterator pClass = m_hClasses.find(string(pszClass));
   if (pClass == m_hClasses.end())
      return 0;
   Object* pObject = 0;
   switch ((*pClass).second)
   {
      case 0:
         pObject = new AESKeyManager();
         AESKeyManager::instance()->initialize();
         break;
      case 1:
         pObject = new AESKeyRing();
         break;
   }
   return pObject;
  //## end database::AESKeyFactory::create%4983227501B4.body
}

// Additional Declarations
  //## begin database::AESKeyFactory%49831BFF0242.declarations preserve=yes
  //## end database::AESKeyFactory%49831BFF0242.declarations

} // namespace database

//## begin module%49831D5B027F.epilog preserve=yes
//## end module%49831D5B027F.epilog
