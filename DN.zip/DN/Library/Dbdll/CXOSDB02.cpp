//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%35758E98005D.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%35758E98005D.cm

//## begin module%35758E98005D.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%35758E98005D.cp

//## Module: CXOSDB02%35758E98005D; Package body
//## Subsystem: DBDLL%35758D89000D
// .
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXOSDB02.cpp

//## begin module%35758E98005D.additionalIncludes preserve=no
//## end module%35758E98005D.additionalIncludes

//## begin module%35758E98005D.includes preserve=yes
// $Date:   Jan 02 2019 21:28:12  $ $Author:   e1009839  $ $Revision:   1.3  $
//## end module%35758E98005D.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU23_h
#include "CXODRU23.hpp"
#endif


//## begin module%35758E98005D.declarations preserve=no
//## end module%35758E98005D.declarations

//## begin module%35758E98005D.additionalDeclarations preserve=yes
//## end module%35758E98005D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::DatabaseFactory

//## begin database::DatabaseFactory::Instance%346CD11B026C.attr preserve=no  private: static DatabaseFactory* {V} 0
DatabaseFactory* DatabaseFactory::m_pInstance = 0;
//## end database::DatabaseFactory::Instance%346CD11B026C.attr


DatabaseFactory::DatabaseFactory()
  //## begin DatabaseFactory::DatabaseFactory%346CB1F40387_const.hasinit preserve=no
  //## end DatabaseFactory::DatabaseFactory%346CB1F40387_const.hasinit
  //## begin DatabaseFactory::DatabaseFactory%346CB1F40387_const.initialization preserve=yes
  //## end DatabaseFactory::DatabaseFactory%346CB1F40387_const.initialization
{
  //## begin database::DatabaseFactory::DatabaseFactory%346CB1F40387_const.body preserve=yes
   m_pInstance = this;
  //## end database::DatabaseFactory::DatabaseFactory%346CB1F40387_const.body
}


DatabaseFactory::~DatabaseFactory()
{
  //## begin database::DatabaseFactory::~DatabaseFactory%346CB1F40387_dest.body preserve=yes
  //## end database::DatabaseFactory::~DatabaseFactory%346CB1F40387_dest.body
}



//## Other Operations (implementation)
DatabaseFactory* DatabaseFactory::instance (Object* pSender)
{
  //## begin database::DatabaseFactory::instance%346CD1320016.body preserve=yes
   return m_pInstance;
  //## end database::DatabaseFactory::instance%346CD1320016.body
}

// Additional Declarations
  //## begin database::DatabaseFactory%346CB1F40387.declarations preserve=yes
  //## end database::DatabaseFactory%346CB1F40387.declarations

} // namespace database

//## begin module%35758E98005D.epilog preserve=yes
//## end module%35758E98005D.epilog
