//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4728ED640271.cm preserve=no
//  $Date:   May 14 2020 18:12:14  $ $Author:   e1009510  $ $Revision:   1.8  $
//## end module%4728ED640271.cm

//## begin module%4728ED640271.cp preserve=no
//  Copyright (c) 1997 - 2012
//  FIS
//## end module%4728ED640271.cp

//## Module: CXOSDB31%4728ED640271; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//  .
//## Source file: C:\bV02.4B.R007\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB31.cpp

//## begin module%4728ED640271.additionalIncludes preserve=no
//## end module%4728ED640271.additionalIncludes

//## begin module%4728ED640271.includes preserve=yes
#include "CXODIF03.hpp"
//## end module%4728ED640271.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB31_h
#include "CXODDB31.hpp"
#endif


//## begin module%4728ED640271.declarations preserve=no
//## end module%4728ED640271.declarations

//## begin module%4728ED640271.additionalDeclarations preserve=yes
//## end module%4728ED640271.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::Calendar 

Calendar::Calendar()
  //## begin Calendar::Calendar%4728ECDA02E1_const.hasinit preserve=no
  //## end Calendar::Calendar%4728ECDA02E1_const.hasinit
  //## begin Calendar::Calendar%4728ECDA02E1_const.initialization preserve=yes
  //## end Calendar::Calendar%4728ECDA02E1_const.initialization
{
  //## begin database::Calendar::Calendar%4728ECDA02E1_const.body preserve=yes
   memcpy_s(m_sID,4,"DB31",4);
   m_strYear = Clock::instance()->getYYYYMMDDHHMMSS();
   m_strYear.resize(4);
   MidnightAlarm::instance()->attach(this);
  //## end database::Calendar::Calendar%4728ECDA02E1_const.body
}


Calendar::~Calendar()
{
  //## begin database::Calendar::~Calendar%4728ECDA02E1_dest.body preserve=yes
   MidnightAlarm::instance()->detach(this);
   m_hHolidays.erase(m_hHolidays.begin(),m_hHolidays.end());
   m_hBusinessDays.erase(m_hBusinessDays.begin(),m_hBusinessDays.end());
  //## end database::Calendar::~Calendar%4728ECDA02E1_dest.body
}



//## Other Operations (implementation)
string Calendar::calculateDateFromExcludedInterval ()
{
  //## begin database::Calendar::calculateDateFromExcludedInterval%538631B40309.body preserve=yes
   //The variables that contain the information is m_strXDAY,m_strXWEEK, and m_strXMONTH
   Trace::put("Inside calculateDateFromExcludedInterval");
   Trace::put(m_strXDAY.c_str());
   Trace::put(m_strXWEEK.c_str());
   Trace::put(m_strXMONTH.c_str());
   Trace::put(m_strYear.c_str());
   Trace::put("above atoi");
   char szTemp1[64];
   int iDay = atoi(m_strXDAY.c_str());
   int iWeek = atoi(m_strXWEEK.c_str());
   int iMonth = atoi(m_strXMONTH.c_str());
   int iYear = atoi(m_strYear.c_str());
   snprintf(szTemp1,sizeof(szTemp1),"XDAY %d",iDay);
   Trace::put(szTemp1);
   snprintf(szTemp1,sizeof(szTemp1),"XWEEK %d",iWeek);
   Trace::put(szTemp1);
   snprintf(szTemp1,sizeof(szTemp1),"Month %d",iMonth);
   Trace::put(szTemp1);
   snprintf(szTemp1,sizeof(szTemp1),"Year %d",iYear);
   Trace::put(szTemp1);
   int iDateDayOfWeek, iDayOfMonth;
   if(iWeek != 9)
   {
      Date hDate(iYear, iMonth, 1);//creates a date with the passed in month and year, 1st of the month 
      iDayOfMonth = 1;
      //iDateDayOfWeek represents a number between 0-6 telling us the day of the week. 0=Sunday
      //we want to find out which day of the week, the first falls on
      iDateDayOfWeek = atoi((hDate.asString("%w")).c_str());
      snprintf(szTemp1,sizeof(szTemp1),"Datedayofweek %d",iDateDayOfWeek);
      Trace::put(szTemp1);
      while(iDateDayOfWeek != iDay)//adds a day until we are at the desired day of week.
      {
         iDayOfMonth++;
         iDateDayOfWeek = iDateDayOfWeek % 7;
         iDateDayOfWeek++;
         snprintf(szTemp1,sizeof(szTemp1),"InLoop %d",iDateDayOfWeek);
         Trace::put(szTemp1);
      }
      iDayOfMonth +=(iWeek-1)*7;
   }
   //if the week is 9, it assumes you want the last desired day of the week for the month.
   else
   {
      
      Trace::put("in else");
      Date hDate(iYear, iMonth, 21); 
      iDayOfMonth = 21;
      iDateDayOfWeek = atoi((hDate.asString("%w")).c_str());
      for(int i=iDayOfMonth; i<=hDate.daysInMonth(iYear,iMonth); i++)
      {
         if(iDateDayOfWeek == iDay)
            iDayOfMonth=i;
         iDateDayOfWeek = iDateDayOfWeek % 7;
         iDateDayOfWeek++;
         Trace::put("in forloop");
      }
   }
   Trace::put("exit calculateDateFromExcludedInterval");
   char szTemp[9];
   snprintf(szTemp,sizeof(szTemp),"%04d%02d%02d",iYear,iMonth,iDayOfMonth);
   return szTemp;
  //## end database::Calendar::calculateDateFromExcludedInterval%538631B40309.body
}

bool Calendar::doesExist (string& strEvent)
{
  //## begin database::Calendar::doesExist%5385FD9902FE.body preserve=yes
   if (m_hBusinessDays.find(strEvent) != m_hBusinessDays.end())
      return true;
   return false;
  //## end database::Calendar::doesExist%5385FD9902FE.body
}

bool Calendar::isBusinessDay (const timer::Date& hDate)
{
  //## begin database::Calendar::isBusinessDay%538600F90232.body preserve=yes
   if (m_pBusinessDaysItr == m_hBusinessDays.end() || (*m_pBusinessDaysItr).second.empty())
      return true;
   if (isHoliday(hDate))
      return false;
   return ((*m_pBusinessDaysItr).second.find(hDate.asString("%w")) != (*m_pBusinessDaysItr).second.end());
  //## end database::Calendar::isBusinessDay%538600F90232.body
}

bool Calendar::isHoliday (const timer::Date& hDate)
{
  //## begin database::Calendar::isHoliday%4728F1530020.body preserve=yes
   if ((*m_pHolidaysItr).second.empty())
      return false;
   string strDate(hDate.asString("%Y%m%d"));
   return ((*m_pHolidaysItr).second.find(strDate) != (*m_pHolidaysItr).second.end());
  //## end database::Calendar::isHoliday%4728F1530020.body
}

bool Calendar::isWeekday (const timer::Date& hDate)
{
  //## begin database::Calendar::isWeekday%4728F15F01C2.body preserve=yes
   return (hDate.asString("%w") > "0" && hDate.asString("%w") < "6"); 
  //## end database::Calendar::isWeekday%4728F15F01C2.body
}

bool Calendar::loadBusinessDays (const string& strEvent)
{
  //## begin database::Calendar::loadBusinessDays%5387826801BF.body preserve=yes
   m_pBusinessDaysItr = m_hBusinessDays.find(strEvent);
   if (m_pBusinessDaysItr != m_hBusinessDays.end())
      (*m_pBusinessDaysItr).second.erase((*m_pBusinessDaysItr).second.begin(),(*m_pBusinessDaysItr).second.end());
   else
   {
      set<string> hTemp;
      m_hBusinessDays.insert(map<string,set<string>,less<string> >::value_type(strEvent,hTemp));
      m_pBusinessDaysItr = m_hBusinessDays.find(strEvent);
   }
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery(1);
   hQuery.attach(this);
   hQuery.setQualifier("QUALIFY","CREVNTT");
   hQuery.setQualifier("QUALIFY","CREVCLT");
   hQuery.setQualifier("QUALIFY","CREVCDT");
   hQuery.join("CREVNTT","INNER","CREVCLT","EVCLID");
   hQuery.join("CREVCLT","INNER","CREVCDT","EVCLID");
   hQuery.bind("CREVCDT","EVNTDAY",Column::STRING,&m_strEVNTDAY);
   hQuery.setBasicPredicate("CREVNTT","EVNTID","=",strEvent.c_str());
   hQuery.setBasicPredicate("CREVNTT","CC_STATE","=","A");
   hQuery.setBasicPredicate("CREVNTT","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("CREVCLT","CC_STATE","=","A");
   hQuery.setBasicPredicate("CREVCLT","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setOrderByClause("CREVCDT.EVNTDAY DESC");
   return (pSelectStatement->execute(hQuery));
  //## end database::Calendar::loadBusinessDays%5387826801BF.body
}

bool Calendar::loadHolidays (const string& strEvent)
{
  //## begin database::Calendar::loadHolidays%4728F5980195.body preserve=yes
   m_pHolidaysItr = m_hHolidays.find(strEvent);
   if (m_pHolidaysItr != m_hHolidays.end())
      (*m_pHolidaysItr).second.erase((*m_pHolidaysItr).second.begin(),(*m_pHolidaysItr).second.end());
   else
   {
      set<string> hTemp;
      m_hHolidays.insert(map<string,set<string>,less<string> >::value_type(strEvent,hTemp));
      m_pHolidaysItr = m_hHolidays.find(strEvent);
   }
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery(2);
   hQuery.attach(this);
   hQuery.setQualifier("QUALIFY","CREVNTT");
   hQuery.setQualifier("QUALIFY","CREVELT");
   hQuery.setQualifier("QUALIFY","CREVEXT");
   hQuery.join("CREVNTT","INNER","CREVELT","EVELID");
   hQuery.join("CREVELT","INNER","CREVEXT","EVELID");
   hQuery.bind("CREVEXT","XDATE",Column::STRING,&m_strXDATE);
   hQuery.setBasicPredicate("CREVNTT","EVNTID","=",strEvent.c_str());
   hQuery.setBasicPredicate("CREVNTT","CC_STATE","=","A");
   hQuery.setBasicPredicate("CREVNTT","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("CREVELT","CC_STATE","=","A");
   hQuery.setBasicPredicate("CREVELT","CC_CHANGE_GRP_ID","IS NULL");
   if (!pSelectStatement->execute(hQuery))
      return false;

   hQuery.reset();
   hQuery.setIndex(3);
   hQuery.setQualifier("QUALIFY","CREVNTT");
   hQuery.setQualifier("QUALIFY","CREVMDT");
   hQuery.join("CREVNTT","LEFT OUTER", "CREVMDT","EVMLID");
   hQuery.join("CREVNTT","LEFT OUTER", "CREVMDT","EVMLSTAT");
   hQuery.bind("CREVMDT","XDAY",Column::STRING,&m_strXDAY);
   hQuery.bind("CREVMDT","XWEEK",Column::STRING,&m_strXWEEK);
   hQuery.bind("CREVMDT","XMONTH",Column::STRING,&m_strXMONTH);
   hQuery.setBasicPredicate("CREVNTT","EVNTID","=",strEvent.c_str());
   hQuery.setBasicPredicate("CREVNTT","CC_STATE","=","A");
   hQuery.setBasicPredicate("CREVNTT","CC_CHANGE_GRP_ID","IS NULL");
   return (pSelectStatement->execute(hQuery));
  //## end database::Calendar::loadHolidays%4728F5980195.body
}

void Calendar::setCalendar (const string& strEvent)
{
  //## begin database::Calendar::setCalendar%53878B6300A1.body preserve=yes
   m_pHolidaysItr = m_hHolidays.find(strEvent);
   m_pBusinessDaysItr = m_hBusinessDays.find(strEvent);
  //## end database::Calendar::setCalendar%53878B6300A1.body
}

void Calendar::update (Subject* pSubject)
{
  //## begin database::Calendar::update%4728F10D0214.body preserve=yes
   if (pSubject == MidnightAlarm::instance())
   {
      m_strYear = MidnightAlarm::instance()->getToday();
      m_strYear.resize(4);
      return;
   }
   if (((Query*)pSubject)->getIndex() == 1)
   {
      if (m_strEVNTDAY == "E")
         ((Query*)pSubject)->setAbort(true);
      else
        (*m_pBusinessDaysItr).second.insert(m_strEVNTDAY);
      return;
   }
   if (((Query*)pSubject)->getIndex() == 2)
   {
      if (memcmp(m_strXDATE.data(),"9999",4) == 0)
         m_strXDATE.replace(0,4,m_strYear.data());
      (*m_pHolidaysItr).second.insert(m_strXDATE);
      return;
   }
   if (((Query*)pSubject)->getIndex() == 3)
   {
      if (!m_strXDAY.empty() && !m_strXWEEK.empty() && !m_strXMONTH.empty())
         m_strXDATE = calculateDateFromExcludedInterval();
      (*m_pHolidaysItr).second.insert(m_strXDATE);
      return;
   }
  //## end database::Calendar::update%4728F10D0214.body
}

// Additional Declarations
  //## begin database::Calendar%4728ECDA02E1.declarations preserve=yes
  //## end database::Calendar%4728ECDA02E1.declarations

} // namespace database

//## begin module%4728ED640271.epilog preserve=yes
//## end module%4728ED640271.epilog
