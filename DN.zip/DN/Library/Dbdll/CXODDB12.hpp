//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3EC3E2F50138.cm preserve=no
//## end module%3EC3E2F50138.cm

//## begin module%3EC3E2F50138.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3EC3E2F50138.cp

//## Module: CXOSDB12%3EC3E2F50138; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB12.hpp

#ifndef CXOSDB12_h
#define CXOSDB12_h 1

//## begin module%3EC3E2F50138.additionalIncludes preserve=no
//## end module%3EC3E2F50138.additionalIncludes

//## begin module%3EC3E2F50138.includes preserve=yes
// $Date:   Apr 19 2016 06:37:32  $ $Author:   e1009839  $ $Revision:   1.5  $
//## end module%3EC3E2F50138.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseCatalogVisitor;

} // namespace database

//## begin module%3EC3E2F50138.declarations preserve=no
//## end module%3EC3E2F50138.declarations

//## begin module%3EC3E2F50138.additionalDeclarations preserve=yes
//## end module%3EC3E2F50138.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::DatabaseColumn%3EC3DC9F0399.preface preserve=yes
//## end database::DatabaseColumn%3EC3DC9F0399.preface

//## Class: DatabaseColumn%3EC3DC9F0399
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3EC3DE1B033C;reusable::Query { -> F}
//## Uses: <unnamed>%3EC3EFAD004E;DatabaseCatalogVisitor { -> F}

class DllExport DatabaseColumn : public reusable::Observer  //## Inherits: <unnamed>%3EC4BE4D00FA
{
  //## begin database::DatabaseColumn%3EC3DC9F0399.initialDeclarations preserve=yes
  //## end database::DatabaseColumn%3EC3DC9F0399.initialDeclarations

  public:
    //## Constructors (generated)
      DatabaseColumn();

      DatabaseColumn(const DatabaseColumn &right);

    //## Destructor (generated)
      virtual ~DatabaseColumn();

    //## Assignment Operation (generated)
      DatabaseColumn & operator=(const DatabaseColumn &right);


    //## Other Operations (specified)
      //## Operation: accept%3EC3E9D103D8
      void accept (database::DatabaseCatalogVisitor& hDatabaseCatalogVisitor);

      //## Operation: bind%3EC3DDF401A5
      void bind (reusable::Query& hQuery);

      //## Operation: update%3EC4BE560177
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ConstraintName%56F2BE7100EB
      const string& getConstraintName () const
      {
        //## begin database::DatabaseColumn::getConstraintName%56F2BE7100EB.get preserve=no
        return m_strConstraintName;
        //## end database::DatabaseColumn::getConstraintName%56F2BE7100EB.get
      }

      void setConstraintName (const string& value)
      {
        //## begin database::DatabaseColumn::setConstraintName%56F2BE7100EB.set preserve=no
        m_strConstraintName = value;
        //## end database::DatabaseColumn::setConstraintName%56F2BE7100EB.set
      }


      //## Attribute: Key%4783B50F000F
      const bool getKey () const
      {
        //## begin database::DatabaseColumn::getKey%4783B50F000F.get preserve=no
        return m_bKey;
        //## end database::DatabaseColumn::getKey%4783B50F000F.get
      }

      void setKey (bool value)
      {
        //## begin database::DatabaseColumn::setKey%4783B50F000F.set preserve=no
        m_bKey = value;
        //## end database::DatabaseColumn::setKey%4783B50F000F.set
      }


      //## Attribute: KeySequence%4784DE0A0280
      string& getKeySequence ()
      {
        //## begin database::DatabaseColumn::getKeySequence%4784DE0A0280.get preserve=no
        return m_strKeySequence;
        //## end database::DatabaseColumn::getKeySequence%4784DE0A0280.get
      }

      void setKeySequence (const string& value)
      {
        //## begin database::DatabaseColumn::setKeySequence%4784DE0A0280.set preserve=no
        m_strKeySequence = value;
        //## end database::DatabaseColumn::setKeySequence%4784DE0A0280.set
      }


      //## Attribute: Length%3EC3DDBC01E4
      const int getLength () const
      {
        //## begin database::DatabaseColumn::getLength%3EC3DDBC01E4.get preserve=no
        return m_lLength;
        //## end database::DatabaseColumn::getLength%3EC3DDBC01E4.get
      }

      void setLength (int value)
      {
        //## begin database::DatabaseColumn::setLength%3EC3DDBC01E4.set preserve=no
        m_lLength = value;
        //## end database::DatabaseColumn::setLength%3EC3DDBC01E4.set
      }


      //## Attribute: Name%3EC3DD8F006D
      const string& getName () const
      {
        //## begin database::DatabaseColumn::getName%3EC3DD8F006D.get preserve=no
        return m_strName;
        //## end database::DatabaseColumn::getName%3EC3DD8F006D.get
      }

      void setName (const string& value)
      {
        //## begin database::DatabaseColumn::setName%3EC3DD8F006D.set preserve=no
        m_strName = value;
        //## end database::DatabaseColumn::setName%3EC3DD8F006D.set
      }


      //## Attribute: Precision%659483DE017F
      const short int getPrecision () const
      {
        //## begin database::DatabaseColumn::getPrecision%659483DE017F.get preserve=no
        return m_iPrecision;
        //## end database::DatabaseColumn::getPrecision%659483DE017F.get
      }

      void setPrecision (short int value)
      {
        //## begin database::DatabaseColumn::setPrecision%659483DE017F.set preserve=no
        m_iPrecision = value;
        //## end database::DatabaseColumn::setPrecision%659483DE017F.set
      }


      //## Attribute: Scale%3EC3DDCD004E
      const short int getScale () const
      {
        //## begin database::DatabaseColumn::getScale%3EC3DDCD004E.get preserve=no
        return m_iScale;
        //## end database::DatabaseColumn::getScale%3EC3DDCD004E.get
      }

      void setScale (short int value)
      {
        //## begin database::DatabaseColumn::setScale%3EC3DDCD004E.set preserve=no
        m_iScale = value;
        //## end database::DatabaseColumn::setScale%3EC3DDCD004E.set
      }


      //## Attribute: Type%3EC3DDAA01F4
      const short int getType () const
      {
        //## begin database::DatabaseColumn::getType%3EC3DDAA01F4.get preserve=no
        return m_iType;
        //## end database::DatabaseColumn::getType%3EC3DDAA01F4.get
      }

      void setType (short int value)
      {
        //## begin database::DatabaseColumn::setType%3EC3DDAA01F4.set preserve=no
        m_iType = value;
        //## end database::DatabaseColumn::setType%3EC3DDAA01F4.set
      }


    // Additional Public Declarations
      //## begin database::DatabaseColumn%3EC3DC9F0399.public preserve=yes
      //## end database::DatabaseColumn%3EC3DC9F0399.public

  protected:
    // Additional Protected Declarations
      //## begin database::DatabaseColumn%3EC3DC9F0399.protected preserve=yes
      //## end database::DatabaseColumn%3EC3DC9F0399.protected

  private:
    // Additional Private Declarations
      //## begin database::DatabaseColumn%3EC3DC9F0399.private preserve=yes
      //## end database::DatabaseColumn%3EC3DC9F0399.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin database::DatabaseColumn::ConstraintName%56F2BE7100EB.attr preserve=no  public: string {V} 
      string m_strConstraintName;
      //## end database::DatabaseColumn::ConstraintName%56F2BE7100EB.attr

      //## begin database::DatabaseColumn::Key%4783B50F000F.attr preserve=no  public: bool {U} false
      bool m_bKey;
      //## end database::DatabaseColumn::Key%4783B50F000F.attr

      //## begin database::DatabaseColumn::KeySequence%4784DE0A0280.attr preserve=no  public: string {V} 
      string m_strKeySequence;
      //## end database::DatabaseColumn::KeySequence%4784DE0A0280.attr

      //## begin database::DatabaseColumn::Length%3EC3DDBC01E4.attr preserve=no  public: int {V} 0
      int m_lLength;
      //## end database::DatabaseColumn::Length%3EC3DDBC01E4.attr

      //## begin database::DatabaseColumn::Name%3EC3DD8F006D.attr preserve=no  public: string {V} 
      string m_strName;
      //## end database::DatabaseColumn::Name%3EC3DD8F006D.attr

      //## begin database::DatabaseColumn::Precision%659483DE017F.attr preserve=no  public: short int {V} 0
      short int m_iPrecision;
      //## end database::DatabaseColumn::Precision%659483DE017F.attr

      //## begin database::DatabaseColumn::Scale%3EC3DDCD004E.attr preserve=no  public: short int {V} 0
      short int m_iScale;
      //## end database::DatabaseColumn::Scale%3EC3DDCD004E.attr

      //## begin database::DatabaseColumn::Type%3EC3DDAA01F4.attr preserve=no  public: short int {V} 0
      short int m_iType;
      //## end database::DatabaseColumn::Type%3EC3DDAA01F4.attr

      //## Attribute: TypeName%3EC4BDDF001F
      //## begin database::DatabaseColumn::TypeName%3EC4BDDF001F.attr preserve=no  private: string {V} 
      string m_strTypeName;
      //## end database::DatabaseColumn::TypeName%3EC4BDDF001F.attr

    // Additional Implementation Declarations
      //## begin database::DatabaseColumn%3EC3DC9F0399.implementation preserve=yes
      int m_lOrdinal_Position;
      //## end database::DatabaseColumn%3EC3DC9F0399.implementation
};

//## begin database::DatabaseColumn%3EC3DC9F0399.postscript preserve=yes
//## end database::DatabaseColumn%3EC3DC9F0399.postscript

} // namespace database

//## begin module%3EC3E2F50138.epilog preserve=yes
using namespace database;
//## end module%3EC3E2F50138.epilog


#endif
