//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3EC3E25B02BF.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3EC3E25B02BF.cm

//## begin module%3EC3E25B02BF.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3EC3E25B02BF.cp

//## Module: CXOSDB13%3EC3E25B02BF; Package specification
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB13.hpp

#ifndef CXOSDB13_h
#define CXOSDB13_h 1

//## begin module%3EC3E25B02BF.additionalIncludes preserve=no
//## end module%3EC3E25B02BF.additionalIncludes

//## begin module%3EC3E25B02BF.includes preserve=yes
// $Date:   Apr 08 2004 10:16:48  $ $Author:   D02405  $ $Revision:   1.1  $
//## end module%3EC3E25B02BF.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseColumn;
class DatabaseTable;
class DatabaseCatalog;

} // namespace database

//## begin module%3EC3E25B02BF.declarations preserve=no
//## end module%3EC3E25B02BF.declarations

//## begin module%3EC3E25B02BF.additionalDeclarations preserve=yes
//## end module%3EC3E25B02BF.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::DatabaseCatalogVisitor%3EC3DCB500FA.preface preserve=yes
//## end database::DatabaseCatalogVisitor%3EC3DCB500FA.preface

//## Class: DatabaseCatalogVisitor%3EC3DCB500FA
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3EC3DD7A0399;DatabaseCatalog { -> F}
//## Uses: <unnamed>%3EC3DD7D0186;DatabaseTable { -> F}
//## Uses: <unnamed>%3EC3DD7F031C;DatabaseColumn { -> F}

class DllExport DatabaseCatalogVisitor : public reusable::Object  //## Inherits: <unnamed>%3EC3DCD5029F
{
  //## begin database::DatabaseCatalogVisitor%3EC3DCB500FA.initialDeclarations preserve=yes
  //## end database::DatabaseCatalogVisitor%3EC3DCB500FA.initialDeclarations

  public:
    //## Constructors (generated)
      DatabaseCatalogVisitor();

    //## Destructor (generated)
      virtual ~DatabaseCatalogVisitor();


    //## Other Operations (specified)
      //## Operation: visitDatabaseCatalog%3EC3DD1300FA
      virtual void visitDatabaseCatalog (DatabaseCatalog* pDatabaseCatalog);

      //## Operation: visitDatabaseColumn%3EC3DD2F0242
      virtual void visitDatabaseColumn (DatabaseColumn* pDatabaseColumn);

      //## Operation: visitDatabaseTable%3EC3DD2F038A
      virtual void visitDatabaseTable (DatabaseTable* pDatabaseTable);

    // Additional Public Declarations
      //## begin database::DatabaseCatalogVisitor%3EC3DCB500FA.public preserve=yes
      //## end database::DatabaseCatalogVisitor%3EC3DCB500FA.public

  protected:
    // Additional Protected Declarations
      //## begin database::DatabaseCatalogVisitor%3EC3DCB500FA.protected preserve=yes
      //## end database::DatabaseCatalogVisitor%3EC3DCB500FA.protected

  private:
    // Additional Private Declarations
      //## begin database::DatabaseCatalogVisitor%3EC3DCB500FA.private preserve=yes
      //## end database::DatabaseCatalogVisitor%3EC3DCB500FA.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::DatabaseCatalogVisitor%3EC3DCB500FA.implementation preserve=yes
      //## end database::DatabaseCatalogVisitor%3EC3DCB500FA.implementation

};

//## begin database::DatabaseCatalogVisitor%3EC3DCB500FA.postscript preserve=yes
//## end database::DatabaseCatalogVisitor%3EC3DCB500FA.postscript

} // namespace database

//## begin module%3EC3E25B02BF.epilog preserve=yes
using namespace database;
//## end module%3EC3E25B02BF.epilog


#endif
