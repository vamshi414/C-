//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36224C0F03E6.cm preserve=no
//	$Date:   Oct 10 2018 10:49:00  $ $Author:   e1009839  $
//	$Revision:   1.6  $
//## end module%36224C0F03E6.cm

//## begin module%36224C0F03E6.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%36224C0F03E6.cp

//## Module: CXOSDB05%36224C0F03E6; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB05.hpp

#ifndef CXOSDB05_h
#define CXOSDB05_h 1

//## begin module%36224C0F03E6.additionalIncludes preserve=no
//## end module%36224C0F03E6.additionalIncludes

//## begin module%36224C0F03E6.includes preserve=yes
// $Date:   Oct 10 2018 10:49:00  $ $Author:   e1009839  $ $Revision:   1.6  $
//## end module%36224C0F03E6.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%36224C0F03E6.declarations preserve=no
//## end module%36224C0F03E6.declarations

//## begin module%36224C0F03E6.additionalDeclarations preserve=yes
//## end module%36224C0F03E6.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Context%3479E7B002B5.preface preserve=yes
//## end database::Context%3479E7B002B5.preface

//## Class: Context%3479E7B002B5; Abstract
//	The Context class provides an interface to save and
//	restore context information in persistent storage.
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3977456C0259;reusable::Statement { -> F}
//## Uses: <unnamed>%3977456E0144;reusable::Table { -> F}
//## Uses: <unnamed>%397745710012;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%39774572035C;reusable::Query { -> F}
//## Uses: <unnamed>%397751470326;DatabaseFactory { -> F}
//## Uses: <unnamed>%46134E670338;Database { -> F}
//## Uses: <unnamed>%46134E9701D6;monitor::UseCase { -> F}

class DllExport Context : public reusable::Object  //## Inherits: <unnamed>%34EDE2A40390
{
  //## begin database::Context%3479E7B002B5.initialDeclarations preserve=yes
  //## end database::Context%3479E7B002B5.initialDeclarations

  public:
    //## Constructors (generated)
      Context();

    //## Constructors (specified)
      //## Operation: Context%3479FA9A02C1
      //	Create a new task unique context item.
      //## Semantics:
      //	1. Save the image and task names.
      Context (const string& strImage, const string& strTask);

    //## Destructor (generated)
      virtual ~Context();


    //## Other Operations (specified)
      //## Operation: get%3479F1BD02F1
      //	Retrieve a context item from persistent storage.
      virtual bool get (const char* pszKey, string& strData, char cType = ' ', const char* pszFunction = "");

      //## Operation: put%3479F1CB0283
      //	Save a context item in persistent storage.
      virtual bool put (const char* pszKey, const char* pszData, char cType = ' ');

      //## Operation: remove%5BBE188201D0
      bool remove (const char* pszKey, char cType);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Qualifier%4A13125C00DA
      const string& getQualifier () const
      {
        //## begin database::Context::getQualifier%4A13125C00DA.get preserve=no
        return m_strQualifier;
        //## end database::Context::getQualifier%4A13125C00DA.get
      }

      void setQualifier (const string& value)
      {
        //## begin database::Context::setQualifier%4A13125C00DA.set preserve=no
        m_strQualifier = value;
        //## end database::Context::setQualifier%4A13125C00DA.set
      }


    // Additional Public Declarations
      //## begin database::Context%3479E7B002B5.public preserve=yes
      //## end database::Context%3479E7B002B5.public

  protected:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Image%3479FE26019B
      //	The image name of this context item (will contain "*"
      //	for global context items).
      const string& getImage () const
      {
        //## begin database::Context::getImage%3479FE26019B.get preserve=no
        return m_strImage;
        //## end database::Context::getImage%3479FE26019B.get
      }

      void setImage (const string& value)
      {
        //## begin database::Context::setImage%3479FE26019B.set preserve=no
        m_strImage = value;
        //## end database::Context::setImage%3479FE26019B.set
      }


      //## Attribute: Task%3479FE350002
      //	The task name of this context item (will contain "*" for
      //	global context items).
      const string& getTask () const
      {
        //## begin database::Context::getTask%3479FE350002.get preserve=no
        return m_strTask;
        //## end database::Context::getTask%3479FE350002.get
      }

      void setTask (const string& value)
      {
        //## begin database::Context::setTask%3479FE350002.set preserve=no
        m_strTask = value;
        //## end database::Context::setTask%3479FE350002.set
      }


    // Data Members for Class Attributes

      //## begin database::Context::Image%3479FE26019B.attr preserve=no  protected: string {V} 
      string m_strImage;
      //## end database::Context::Image%3479FE26019B.attr

      //## begin database::Context::Qualifier%4A13125C00DA.attr preserve=no  public: string {U} "CUSTQUAL"
      string m_strQualifier;
      //## end database::Context::Qualifier%4A13125C00DA.attr

      //## begin database::Context::Task%3479FE350002.attr preserve=no  protected: string {V} 
      string m_strTask;
      //## end database::Context::Task%3479FE350002.attr

    // Additional Protected Declarations
      //## begin database::Context%3479E7B002B5.protected preserve=yes
      //## end database::Context%3479E7B002B5.protected

  private:
    // Additional Private Declarations
      //## begin database::Context%3479E7B002B5.private preserve=yes
      //## end database::Context%3479E7B002B5.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::Context%3479E7B002B5.implementation preserve=yes
      //## end database::Context%3479E7B002B5.implementation

};

//## begin database::Context%3479E7B002B5.postscript preserve=yes
//## end database::Context%3479E7B002B5.postscript

} // namespace database

//## begin module%36224C0F03E6.epilog preserve=yes
using namespace database;
//## end module%36224C0F03E6.epilog


#endif
