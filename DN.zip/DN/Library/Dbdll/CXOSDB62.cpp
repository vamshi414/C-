//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C0E978602AD.cm preserve=no
//	$Date:   Jun 11 2019 07:39:54  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%5C0E978602AD.cm

//## begin module%5C0E978602AD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C0E978602AD.cp

//## Module: CXOSDB62%5C0E978602AD; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB62.cpp

//## begin module%5C0E978602AD.additionalIncludes preserve=no
//## end module%5C0E978602AD.additionalIncludes

//## begin module%5C0E978602AD.includes preserve=yes
//## end module%5C0E978602AD.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB62_h
#include "CXODDB62.hpp"
#endif


//## begin module%5C0E978602AD.declarations preserve=no
//## end module%5C0E978602AD.declarations

//## begin module%5C0E978602AD.additionalDeclarations preserve=yes
//## end module%5C0E978602AD.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::Query 

Query::Query()
  //## begin Query::Query%5C0E96A601BF_const.hasinit preserve=no
  //## end Query::Query%5C0E96A601BF_const.hasinit
  //## begin Query::Query%5C0E96A601BF_const.initialization preserve=yes
  //## end Query::Query%5C0E96A601BF_const.initialization
{
  //## begin database::Query::Query%5C0E96A601BF_const.body preserve=yes
  //## end database::Query::Query%5C0E96A601BF_const.body
}

Query::Query (const reusable::Query& hQuery)
  //## begin database::Query::Query%5C0E96FD003C.hasinit preserve=no
  //## end database::Query::Query%5C0E96FD003C.hasinit
  //## begin database::Query::Query%5C0E96FD003C.initialization preserve=yes
   : m_hQuery(hQuery)
  //## end database::Query::Query%5C0E96FD003C.initialization
{
  //## begin database::Query::Query%5C0E96FD003C.body preserve=yes
   memcpy(m_sID,"DB62",4);
  //## end database::Query::Query%5C0E96FD003C.body
}


Query::~Query()
{
  //## begin database::Query::~Query%5C0E96A601BF_dest.body preserve=yes
  //## end database::Query::~Query%5C0E96A601BF_dest.body
}



//## Other Operations (implementation)
void Query::execute (vector<Object*>& hObject)
{
  //## begin database::Query::execute%5C0E96D00320.body preserve=yes
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery.setDelegate(false);
   pSelectStatement->execute(m_hQuery);
  //## end database::Query::execute%5C0E96D00320.body
}

// Additional Declarations
  //## begin database::Query%5C0E96A601BF.declarations preserve=yes
  //## end database::Query%5C0E96A601BF.declarations

} // namespace database

//## begin module%5C0E978602AD.epilog preserve=yes
//## end module%5C0E978602AD.epilog
