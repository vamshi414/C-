//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4AF064AD038C.cm preserve=no
//	$Date:   Feb 09 2021 08:17:28  $ $Author:   e1009652  $ $Revision:   1.13  $
//## end module%4AF064AD038C.cm

//## begin module%4AF064AD038C.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4AF064AD038C.cp

//## Module: CXOSDB37%4AF064AD038C; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB37.cpp

//## begin module%4AF064AD038C.additionalIncludes preserve=no
//## end module%4AF064AD038C.additionalIncludes

//## begin module%4AF064AD038C.includes preserve=yes
#include <algorithm>
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
//## end module%4AF064AD038C.includes

#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
#ifndef CXOSDB37_h
#include "CXODDB37.hpp"
#endif


//## begin module%4AF064AD038C.declarations preserve=no
//## end module%4AF064AD038C.declarations

//## begin module%4AF064AD038C.additionalDeclarations preserve=yes
//## end module%4AF064AD038C.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::DESKey 

DESKey::DESKey()
  //## begin DESKey::DESKey%4AF064710131_const.hasinit preserve=no
      : m_iReasonCode(0),
        m_iReturnCode(0)
  //## end DESKey::DESKey%4AF064710131_const.hasinit
  //## begin DESKey::DESKey%4AF064710131_const.initialization preserve=yes
  //## end DESKey::DESKey%4AF064710131_const.initialization
{
  //## begin database::DESKey::DESKey%4AF064710131_const.body preserve=yes
   memcpy(m_sID,"DB37",4);
   m_iType = Key::DES;
  //## end database::DESKey::DESKey%4AF064710131_const.body
}

DESKey::DESKey(const DESKey &right)
  //## begin DESKey::DESKey%4AF064710131_copy.hasinit preserve=no
      : m_iReasonCode(0),
        m_iReturnCode(0)
  //## end DESKey::DESKey%4AF064710131_copy.hasinit
  //## begin DESKey::DESKey%4AF064710131_copy.initialization preserve=yes
  //## end DESKey::DESKey%4AF064710131_copy.initialization
{
  //## begin database::DESKey::DESKey%4AF064710131_copy.body preserve=yes
   memcpy(m_sID,"DB37",4);
   m_strKey = right.m_strKey;
   m_strIdentifier = right.m_strIdentifier;
   m_strCONTEXT_DATA = right.m_strCONTEXT_DATA;
   m_strCONTEXT_KEY = right.m_strCONTEXT_KEY;
   m_strCryptogram = right.m_strCryptogram;
   m_strCheckDigits = right.m_strCheckDigits;
   m_iStrength = right.m_iStrength;
   m_iType = right.m_iType;
  //## end database::DESKey::DESKey%4AF064710131_copy.body
}

DESKey::DESKey (const string& strKey)
  //## begin database::DESKey::DESKey%4AF1A2280039.hasinit preserve=no
      : m_iReasonCode(0),
        m_iReturnCode(0)
  //## end database::DESKey::DESKey%4AF1A2280039.hasinit
  //## begin database::DESKey::DESKey%4AF1A2280039.initialization preserve=yes
  //## end database::DESKey::DESKey%4AF1A2280039.initialization
{
  //## begin database::DESKey::DESKey%4AF1A2280039.body preserve=yes
   memcpy(m_sID,"DB37",4);
   m_iType = Key::DES;
   m_iStrength = 168; //original default was 3DES2Key 112 bit 
   setKey(strKey);
  //## end database::DESKey::DESKey%4AF1A2280039.body
}


DESKey::~DESKey()
{
  //## begin database::DESKey::~DESKey%4AF064710131_dest.body preserve=yes
  //## end database::DESKey::~DESKey%4AF064710131_dest.body
}


DESKey & DESKey::operator=(const DESKey &right)
{
  //## begin database::DESKey::operator=%4AF064710131_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_strKey = right.m_strKey;
   m_strIdentifier = right.m_strIdentifier;
   m_strCONTEXT_DATA = right.m_strCONTEXT_DATA;
   m_strCONTEXT_KEY = right.m_strCONTEXT_KEY;
   m_strCryptogram = right.m_strCryptogram;
   m_strCheckDigits = right.m_strCheckDigits;
   m_iStrength = right.m_iStrength;
   m_iType = right.m_iType;
   return *this;
  //## end database::DESKey::operator=%4AF064710131_assign.body
}



//## Other Operations (implementation)
bool DESKey::crypt (string& strText, int iLength, int enc)
{
  //## begin database::DESKey::crypt%4AF07E32029A.body preserve=yes
//   if(m_strKey.length() != 16)
      return false;
/*
   unsigned char* pOutput = new unsigned char[iLength];
   DES_cblock left, right,middle;
   DES_key_schedule key1, key2,key3;

   memcpy(&left,(char*)m_strKey.data(),8);
   DES_set_odd_parity(&left);
//   DES_set_key_checked(&left,&key1);

   memcpy(&right,m_strKey.data()+8,8);
   DES_set_odd_parity(&right);
//   DES_set_key_checked(&right,&key2);

   memcpy(&middle, m_strKey.data() + 4, 8);
   DES_set_odd_parity(&middle);
//   DES_set_key_checked(&middle, &key3);

   DES_cblock initVector;
   memset((char*)initVector,'\0',8);
   //for (int i=0; i<8; i++)
   //   initVector[i] = 0;	
   if (m_iStrength == 112)
   {
      SecurityWrapper::DES_ede3_cbc_encrypt((unsigned char*)strText.data(),
         pOutput,
         strText.length(),
         &key1,
         &key2,
         &key1,      //<=== use key1 as key3 effectively making it 2key 112 bit strength for compatability with existing DES keys
         &initVector,
         enc);
   }
   else if (m_iStrength == 168)
   {
      SecurityWrapper::DES_ede3_cbc_encrypt((unsigned char*)strText.data(),
         pOutput,
         strText.length(),
         &key1,
         &key2,
         &key3,
         &initVector,
         enc);
   }
   strText.assign((const char*)pOutput,iLength);
   delete [] pOutput;
   return true;
   */
  //## end database::DESKey::crypt%4AF07E32029A.body
}

bool DESKey::decrypt (string& strText)
{
  //## begin database::DESKey::decrypt%4AF065C70036.body preserve=yes
   int iLength = strText.length();
   return crypt(strText,iLength,DES_DECRYPT);
  //## end database::DESKey::decrypt%4AF065C70036.body
}

bool DESKey::encrypt (string& strText)
{
  //## begin database::DESKey::encrypt%4AF065C7004A.body preserve=yes
   if (strText.length() > INT_MAX - 8)
      return false;
   int iLength = strText.length() % 8 == 0 ? 
      strText.length() : strText.length() + 8 - (strText.length() % 8);
   return crypt(strText,iLength,DES_ENCRYPT);
  //## end database::DESKey::encrypt%4AF065C7004A.body
}

void DESKey::setKey (const string& strKey)
{
  //## begin database::DESKey::setKey%4AF43F530158.body preserve=yes
   if(strKey.length() == 32)
   {
      unsigned char szKey[16];
      CodeTable::byteToNibble(strKey,szKey);
      m_strKey.assign((char*)szKey,16);
   }
   else
      m_strKey = strKey;
   if(m_strCheckDigits.length() == 0) //don't compute if already set 
      computeCheckDigits();
  //## end database::DESKey::setKey%4AF43F530158.body
}


// Additional Declarations
  //## begin database::DESKey%4AF064710131.declarations preserve=yes
bool DESKey::validate()
{
   string strCryptogram = getCryptogram();
   string strCheckDigits = strCryptogram.substr(0,min(size_t(4),strCryptogram.length()));
   return (strCheckDigits == m_strCheckDigits);
}
  //## end database::DESKey%4AF064710131.declarations

} // namespace database

//## begin module%4AF064AD038C.epilog preserve=yes
//## end module%4AF064AD038C.epilog
