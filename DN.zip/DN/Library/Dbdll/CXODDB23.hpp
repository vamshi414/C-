//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3F742F1A001F.cm preserve=no
//	$Date:   Jun 28 2006 09:54:36  $ $Author:   D01575  $ $Revision:   1.4  $
//## end module%3F742F1A001F.cm

//## begin module%3F742F1A001F.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%3F742F1A001F.cp

//## Module: CXOSDB23%3F742F1A001F; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB23.hpp

#ifndef CXOSDB23_h
#define CXOSDB23_h 1

//## begin module%3F742F1A001F.additionalIncludes preserve=no
//## end module%3F742F1A001F.additionalIncludes

//## begin module%3F742F1A001F.includes preserve=yes
// $Date:   Jun 28 2006 09:54:36  $ $Author:   D01575  $ $Revision:   1.4  $

//## end module%3F742F1A001F.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;

} // namespace IF

//## begin module%3F742F1A001F.declarations preserve=no
//## end module%3F742F1A001F.declarations

//## begin module%3F742F1A001F.additionalDeclarations preserve=yes
//## end module%3F742F1A001F.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Password%3F742DF5035B.preface preserve=yes
//## end database::Password%3F742DF5035B.preface

//## Class: Password%3F742DF5035B
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%43311A870167;IF::CodeTable { -> F}

class DllExport Password : public reusable::Object  //## Inherits: <unnamed>%3F742E1003A9
{
  //## begin database::Password%3F742DF5035B.initialDeclarations preserve=yes
  //## end database::Password%3F742DF5035B.initialDeclarations

  public:
    //## Constructors (generated)
      Password();

    //## Destructor (generated)
      virtual ~Password();


    //## Other Operations (specified)
      //## Operation: decrypt%3F742E1C01A5
      static bool decrypt (string& strText);

      //## Operation: encrypt%3F742E7B01E4
      static bool encrypt (string& strText);

    // Additional Public Declarations
      //## begin database::Password%3F742DF5035B.public preserve=yes
      //## end database::Password%3F742DF5035B.public

  protected:
    // Additional Protected Declarations
      //## begin database::Password%3F742DF5035B.protected preserve=yes
      //## end database::Password%3F742DF5035B.protected

  private:
    // Additional Private Declarations
      //## begin database::Password%3F742DF5035B.private preserve=yes
      //## end database::Password%3F742DF5035B.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::Password%3F742DF5035B.implementation preserve=yes
      //## end database::Password%3F742DF5035B.implementation

};

//## begin database::Password%3F742DF5035B.postscript preserve=yes
//## end database::Password%3F742DF5035B.postscript

} // namespace database

//## begin module%3F742F1A001F.epilog preserve=yes
//## end module%3F742F1A001F.epilog


#endif
