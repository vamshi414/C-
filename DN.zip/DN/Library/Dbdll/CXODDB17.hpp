//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%38D265DC00D3.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%38D265DC00D3.cm

//## begin module%38D265DC00D3.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%38D265DC00D3.cp

//## Module: CXOSDB17%38D265DC00D3; Package specification
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXODDB17.hpp

#ifndef CXOSDB17_h
#define CXOSDB17_h 1

//## begin module%38D265DC00D3.additionalIncludes preserve=no
//## end module%38D265DC00D3.additionalIncludes

//## begin module%38D265DC00D3.includes preserve=yes
// $Date:   Jun 30 2006 11:35:24  $ $Author:   D02405  $ $Revision:   1.3  $
#include <map>
//## end module%38D265DC00D3.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%38D265DC00D3.declarations preserve=no
//## end module%38D265DC00D3.declarations

//## begin module%38D265DC00D3.additionalDeclarations preserve=yes
//## end module%38D265DC00D3.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::DisputeProcessor%38D264AF033F.preface preserve=yes
//## end database::DisputeProcessor%38D264AF033F.preface

//## Class: DisputeProcessor%38D264AF033F
//	This class determines the STAR Dispute Processor ID
//	associated swith the Institution, Processor, or
//	Processor Group (which ever is found first).
//## Category: DataNavigator Foundation::Database_CAT%3451F34D0218
//## Subsystem: DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%38D26AAF0170;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%38D26AB503C8;reusable::Query { -> F}
//## Uses: <unnamed>%38D26AB90098;DatabaseFactory { -> F}
//## Uses: <unnamed>%38D693E80308;IF::Extract { -> F}

class DllExport DisputeProcessor : public reusable::Observer  //## Inherits: <unnamed>%38D6955101BD
{
  //## begin database::DisputeProcessor%38D264AF033F.initialDeclarations preserve=yes
  //## end database::DisputeProcessor%38D264AF033F.initialDeclarations

  public:
    //## Constructors (generated)
      DisputeProcessor();

    //## Destructor (generated)
      virtual ~DisputeProcessor();


    //## Other Operations (specified)
      //## Operation: getDisputeProcessor%38D2657603B1
      bool getDisputeProcessor (const string& strInstitution, const string& strProcessor, const string& strProcGroup, string& strDisputeProcID, int& lSeqNo);

      //## Operation: update%38D696840015
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin database::DisputeProcessor%38D264AF033F.public preserve=yes
      //## end database::DisputeProcessor%38D264AF033F.public

  protected:
    // Additional Protected Declarations
      //## begin database::DisputeProcessor%38D264AF033F.protected preserve=yes
      //## end database::DisputeProcessor%38D264AF033F.protected

  private:

    //## Other Operations (specified)
      //## Operation: getEntity%38D2844A0095
      bool getEntity (const string& strEntity, string& strDisputeProcID, int& lSeqNo);

      //## Operation: getInstitution%38D267E70305
      bool getInstitution (const string& strInstitution, string& strDisputeProcID, int& lSeqNo);

      //## Operation: getProcessor%38D268BA038C
      bool getProcessor (const string& strProcessor, string& strDisputeProcID, int& lSeqNo);

      //## Operation: getProcGroup%38D268C5000D
      bool getProcGroup (const string& strProcGroup, string& strDisputeProcID, int& lSeqNo);

    // Additional Private Declarations
      //## begin database::DisputeProcessor%38D264AF033F.private preserve=yes
      //## end database::DisputeProcessor%38D264AF033F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CUST_ID%38D69465025E
      //## begin database::DisputeProcessor::CUST_ID%38D69465025E.attr preserve=no  private: string {U} 
      string m_strCUST_ID;
      //## end database::DisputeProcessor::CUST_ID%38D69465025E.attr

    // Additional Implementation Declarations
      //## begin database::DisputeProcessor%38D264AF033F.implementation preserve=yes
      map<string,pair<string,int>,less<string> > m_hEntities;
      //## end database::DisputeProcessor%38D264AF033F.implementation
};

//## begin database::DisputeProcessor%38D264AF033F.postscript preserve=yes
//## end database::DisputeProcessor%38D264AF033F.postscript

} // namespace database

//## begin module%38D265DC00D3.epilog preserve=yes
using namespace database;
//## end module%38D265DC00D3.epilog


#endif
