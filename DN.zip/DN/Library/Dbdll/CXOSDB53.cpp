//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%585D57AA01C8.cm preserve=no
//	$Date:   Jan 19 2017 15:56:36  $ $Author:   e1009839  $ $Revision:   1.1  $
//## end module%585D57AA01C8.cm

//## begin module%585D57AA01C8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%585D57AA01C8.cp

//## Module: CXOSDB53%585D57AA01C8; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB53.cpp

//## begin module%585D57AA01C8.additionalIncludes preserve=no
//## end module%585D57AA01C8.additionalIncludes

//## begin module%585D57AA01C8.includes preserve=yes
//## end module%585D57AA01C8.includes

#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSDB53_h
#include "CXODDB53.hpp"
#endif


//## begin module%585D57AA01C8.declarations preserve=no
//## end module%585D57AA01C8.declarations

//## begin module%585D57AA01C8.additionalDeclarations preserve=yes
//## end module%585D57AA01C8.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::SQLCache 





SQLCache::SQLCache()
  //## begin SQLCache::SQLCache%585D56D20017_const.hasinit preserve=no
  //## end SQLCache::SQLCache%585D56D20017_const.hasinit
  //## begin SQLCache::SQLCache%585D56D20017_const.initialization preserve=yes
  //## end SQLCache::SQLCache%585D56D20017_const.initialization
{
  //## begin database::SQLCache::SQLCache%585D56D20017_const.body preserve=yes
   memcpy(m_sID,"DB53",4);
   clear();
  //## end database::SQLCache::SQLCache%585D56D20017_const.body
}


SQLCache::~SQLCache()
{
  //## begin database::SQLCache::~SQLCache%585D56D20017_dest.body preserve=yes
  //## end database::SQLCache::~SQLCache%585D56D20017_dest.body
}



//## Other Operations (implementation)
void SQLCache::clear ()
{
  //## begin database::SQLCache::clear%585D6C2C0253.body preserve=yes
   m_hSQLText.erase(m_hSQLText.begin(),m_hSQLText.end());
   m_hTimestamp.erase(m_hTimestamp.begin(),m_hTimestamp.end());
   string strSQLText;
   string strTimestamp("0000000000000000");
   for (int i = 0;i < 10;++i)
   {
      m_hSQLText.push_back(strSQLText);
      m_hTimestamp.push_back(strTimestamp);
   }
  //## end database::SQLCache::clear%585D6C2C0253.body
}

void SQLCache::free (int nInstance)
{
  //## begin database::SQLCache::free%588113E301BD.body preserve=yes
   m_hTimestamp[nInstance] = Clock::instance()->getYYYYMMDDHHMMSSHN(true);
  //## end database::SQLCache::free%588113E301BD.body
}

bool SQLCache::save (const string& strSQLText, int& nInstance)
{
  //## begin database::SQLCache::save%585D575601B2.body preserve=yes
   bool bCache = false;
   nInstance = -1;
   int i = 0;
   vector<string>::iterator p;
   for (p = m_hSQLText.begin();p != m_hSQLText.end();++p)
   {
      if (bCache = (strSQLText == (*p)))
      {
         nInstance = i;
         break;
      }
      if ((*p).empty())
      {
         (*p) = strSQLText;
         nInstance = i;
         break;
      }
      ++i;
   }
   if (nInstance == -1)
   {
      i = 0;
      string strTimestamp("9999999999999999");
      for (p = m_hTimestamp.begin();p != m_hTimestamp.end();++p)
      {
         if ((*p) < strTimestamp)
         {
            strTimestamp = (*p);
            nInstance = i;
         }
         ++i;
      }
      m_hSQLText[nInstance] = strSQLText;
   }
   m_hTimestamp[nInstance].assign("9999123123595999",16);
   return bCache;
  //## end database::SQLCache::save%585D575601B2.body
}

// Additional Declarations
  //## begin database::SQLCache%585D56D20017.declarations preserve=yes
  //## end database::SQLCache%585D56D20017.declarations

} // namespace database

//## begin module%585D57AA01C8.epilog preserve=yes
//## end module%585D57AA01C8.epilog
