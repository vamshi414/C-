//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C8C0A8D00B4.cm preserve=no
//	$Date:   May 27 2020 16:16:46  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%5C8C0A8D00B4.cm

//## begin module%5C8C0A8D00B4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C8C0A8D00B4.cp

//## Module: CXOSDB64%5C8C0A8D00B4; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB64.cpp

//## begin module%5C8C0A8D00B4.additionalIncludes preserve=no
//## end module%5C8C0A8D00B4.additionalIncludes

//## begin module%5C8C0A8D00B4.includes preserve=yes
//## end module%5C8C0A8D00B4.includes

#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSDB64_h
#include "CXODDB64.hpp"
#endif


//## begin module%5C8C0A8D00B4.declarations preserve=no
//## end module%5C8C0A8D00B4.declarations

//## begin module%5C8C0A8D00B4.additionalDeclarations preserve=yes
//## end module%5C8C0A8D00B4.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::MultiArray

MultiArray::MultiArray()
  //## begin MultiArray::MultiArray%5C8C09E50039_const.hasinit preserve=no
      : m_iCount(0),
        m_iKey(0),
        m_iReserve(0),
        m_iSize(0),
        m_pMemory(0)
  //## end MultiArray::MultiArray%5C8C09E50039_const.hasinit
  //## begin MultiArray::MultiArray%5C8C09E50039_const.initialization preserve=yes
  //## end MultiArray::MultiArray%5C8C09E50039_const.initialization
{
  //## begin database::MultiArray::MultiArray%5C8C09E50039_const.body preserve=yes
   memcpy(m_sID,"DB64",4);
  //## end database::MultiArray::MultiArray%5C8C09E50039_const.body
}


MultiArray::~MultiArray()
{
  //## begin database::MultiArray::~MultiArray%5C8C09E50039_dest.body preserve=yes
   delete m_pMemory;
  //## end database::MultiArray::~MultiArray%5C8C09E50039_dest.body
}



//## Other Operations (implementation)
void MultiArray::append (const char* psEntry)
{
  //## begin database::MultiArray::append%5C8C12160156.body preserve=yes
   if (m_iCount == m_iReserve)
      reserve(m_iCount + max(1,min(256,m_iCount / 10)),m_iSize,m_iKey);
   memcpy((char*)*m_pMemory + (m_iCount * m_iSize),psEntry,m_iSize);
   ++m_iCount;
  //## end database::MultiArray::append%5C8C12160156.body
}

void MultiArray::clear ()
{
  //## begin database::MultiArray::clear%5C91876803D8.body preserve=yes
   m_iCount = 0;
  //## end database::MultiArray::clear%5C91876803D8.body
}

const char* MultiArray::find (const char* psKey)
{
  //## begin database::MultiArray::find%5C8C10B401B6.body preserve=yes
   if (!m_pMemory)
      return 0;
   int iHigh = m_iCount;
   int iLow = 0;
   int iMiddle = m_iCount / 2;
   while (iMiddle < m_iCount)
   {
      int i = memcmp((char*)*m_pMemory + (iMiddle * m_iSize),psKey,m_iKey);
      if (i == 0)
         return (char*)*m_pMemory + (iMiddle * m_iSize);
      if (iLow == iHigh || iMiddle > iHigh || iMiddle < iLow)
         break;
      if (i < 0)
         iLow = iMiddle + 1;
      else
         iHigh = iMiddle - 1;
      iMiddle = iLow + (iHigh - iLow) / 2;
   }
   return 0;
  //## end database::MultiArray::find%5C8C10B401B6.body
}

const char* MultiArray::findFirst (const char* psKey)
{
  //## begin database::MultiArray::findFirst%5D9B82B4016C.body preserve=yes
   const char *p = 0;
   p = find(psKey);
   if (p != 0)
      while (p != (char*)*m_pMemory
         && memcmp(p, p - m_iSize, m_iKey) == 0)
         p = p - m_iSize;
   return p;
  //## end database::MultiArray::findFirst%5D9B82B4016C.body
}

const char* MultiArray::getNext (const char* psBuffer)
{
  //## begin database::MultiArray::getNext%5D9B82E00380.body preserve=yes
   int k = psBuffer - (char*)*m_pMemory;
   if ((psBuffer - (char*)*m_pMemory) >= ((m_iCount-1) * m_iSize))
      return 0;
   return (psBuffer + m_iSize);
  //## end database::MultiArray::getNext%5D9B82E00380.body
}

const char* MultiArray::insert (const char* psEntry)
{
  //## begin database::MultiArray::insert%5C8C12330232.body preserve=yes
   if (m_iCount == m_iReserve)
      reserve(m_iCount + max(1,min(256,m_iCount / 10)),m_iSize,m_iKey);
   char* p = (char*)*m_pMemory + ((m_iCount - 1) * m_iSize);
   while (p >= (char*)*m_pMemory)
   {
      if (memcmp(p,psEntry,m_iKey) < 0)
         break;
      memcpy(p + m_iSize,p,m_iSize);
      p -= m_iSize;
   }
   memcpy(p + m_iSize,psEntry,m_iSize);
   ++m_iCount;
   return p + m_iSize;
  //## end database::MultiArray::insert%5C8C12330232.body
}

void MultiArray::reserve (int iReserve, int iSize, int iKey)
{
  //## begin database::MultiArray::reserve%5C8C106F032D.body preserve=yes
   Memory* p = m_pMemory;
   m_pMemory = new IF::Memory(iReserve * iSize,true);
   if (p)
   {
      memcpy((char*)*m_pMemory,(char*)*p,m_iCount * iSize);
      delete p;
   }
   m_iReserve = iReserve;
   m_iSize = iSize;
   m_iKey = iKey;
  //## end database::MultiArray::reserve%5C8C106F032D.body
}

// Additional Declarations
  //## begin database::MultiArray%5C8C09E50039.declarations preserve=yes
  //## end database::MultiArray%5C8C09E50039.declarations

} // namespace database

//## begin module%5C8C0A8D00B4.epilog preserve=yes
//## end module%5C8C0A8D00B4.epilog
