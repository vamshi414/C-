//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%40A8FE9100EA.cm preserve=no
//	$Date:   Aug 19 2021 23:40:46  $ $Author:   e5632407  $
//	$Revision:   1.71  $
//## end module%40A8FE9100EA.cm

//## begin module%40A8FE9100EA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%40A8FE9100EA.cp

//## Module: CXOSDB04%40A8FE9100EA; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB04.cpp

//## begin module%40A8FE9100EA.additionalIncludes preserve=no
//## end module%40A8FE9100EA.additionalIncludes

//## begin module%40A8FE9100EA.includes preserve=yes
#ifdef _WIN32
#include <direct.h>
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/stat.h>
#include <unistd.h>
#endif
//## end module%40A8FE9100EA.includes

#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF41_h
#include "CXODIF41.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif


//## begin module%40A8FE9100EA.declarations preserve=no
//## end module%40A8FE9100EA.declarations

//## begin module%40A8FE9100EA.additionalDeclarations preserve=yes
//## end module%40A8FE9100EA.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::GenerationDataGroup

GenerationDataGroup::GenerationDataGroup()
  //## begin GenerationDataGroup::GenerationDataGroup%40A8FDA4029F_const.hasinit preserve=no
      : m_lNumber(0),
        m_lProgress(0),
        m_bReadError(false),
        m_pFile(0)
  //## end GenerationDataGroup::GenerationDataGroup%40A8FDA4029F_const.hasinit
  //## begin GenerationDataGroup::GenerationDataGroup%40A8FDA4029F_const.initialization preserve=yes
  //## end GenerationDataGroup::GenerationDataGroup%40A8FDA4029F_const.initialization
{
  //## begin database::GenerationDataGroup::GenerationDataGroup%40A8FDA4029F_const.body preserve=yes
   memcpy(m_sID,"DB04",4);
  //## end database::GenerationDataGroup::GenerationDataGroup%40A8FDA4029F_const.body
}

GenerationDataGroup::GenerationDataGroup (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlock)
  //## begin database::GenerationDataGroup::GenerationDataGroup%40A9F6D8000F.hasinit preserve=no
      : m_lNumber(0),
        m_lProgress(0),
        m_bReadError(false),
        m_pFile(0)
  //## end database::GenerationDataGroup::GenerationDataGroup%40A9F6D8000F.hasinit
  //## begin database::GenerationDataGroup::GenerationDataGroup%40A9F6D8000F.initialization preserve=yes
   ,m_strIMAGEID("I01/")
   ,m_strTASKID(strTASKID)
   ,m_strCONTEXT_KEY(pszName)
   ,m_hGeneration("I01/",strTASKID,pszName)
  //## end database::GenerationDataGroup::GenerationDataGroup%40A9F6D8000F.initialization
{
  //## begin database::GenerationDataGroup::GenerationDataGroup%40A9F6D8000F.body preserve=yes
   memcpy(m_sID,"DB04",4);
   if (bVariableBlock)
      m_pFile = new VariableBlockFile(pszName);
   else
      m_pFile = new FlatFile(pszName);
  //## end database::GenerationDataGroup::GenerationDataGroup%40A9F6D8000F.body
}


GenerationDataGroup::~GenerationDataGroup()
{
  //## begin database::GenerationDataGroup::~GenerationDataGroup%40A8FDA4029F_dest.body preserve=yes
   delete m_pFile;
  //## end database::GenerationDataGroup::~GenerationDataGroup%40A8FDA4029F_dest.body
}



//## Other Operations (implementation)
bool GenerationDataGroup::checkPoint (int iOffset)
{
  //## begin database::GenerationDataGroup::checkPoint%418F882601B5.body preserve=yes
   m_hGeneration.setGDG_PROGRESS(m_lProgress - iOffset);
   return m_hGeneration.save();
  //## end database::GenerationDataGroup::checkPoint%418F882601B5.body
}

void GenerationDataGroup::close ()
{
  //## begin database::GenerationDataGroup::close%45828B55014F.body preserve=yes
   m_pFile->close();
   m_lProgress = 0;
  //## end database::GenerationDataGroup::close%45828B55014F.body
}

bool GenerationDataGroup::commit ()
{
  //## begin database::GenerationDataGroup::commit%40AA06C10280.body preserve=yes
   m_hGeneration.setGDG_PROGRESS(m_lProgress);
   string strDatasetName(m_pFile->getDatasetName());
   m_hGeneration.setGDG_PATH(strDatasetName);
   if (!m_hGeneration.commit())
      return false;
   string strBaseName;
   m_pFile->getBaseName(strBaseName,true);
   m_pFile->move("..\\Complete");
   m_pFile->close();
   m_lProgress = 0;
#ifdef MVS
   // ST251 - FILE @ GENERATION @ IMPORT COMPLETED
   char szCONTEXT_DATA[PERCENTD];
   snprintf(szCONTEXT_DATA,sizeof(szCONTEXT_DATA),"%04d",m_lNumber);
   Console::display("ST251",m_strCONTEXT_KEY.c_str(),szCONTEXT_DATA );
#else
   // ST251 - FILE @@@@@@@@: @@@@@@@@@@@@@@@@@@@@@@@@@@@@ IMPORT COMPLETED
   Console::display("ST251",m_strCONTEXT_KEY.c_str(),strBaseName.c_str());
#endif
   return true;
  //## end database::GenerationDataGroup::commit%40AA06C10280.body
}

const string& GenerationDataGroup::datasetName ()
{
  //## begin database::GenerationDataGroup::datasetName%4548FC70000F.body preserve=yes
   return m_pFile->getDatasetName(); // !!! obsolete can be removed !!!
  //## end database::GenerationDataGroup::datasetName%4548FC70000F.body
}

const string& GenerationDataGroup::getName ()
{
  //## begin database::GenerationDataGroup::getName%45490593008C.body preserve=yes
   return m_pFile->getName();
  //## end database::GenerationDataGroup::getName%45490593008C.body
}

int GenerationDataGroup::getRecordCount ()
{
  //## begin database::GenerationDataGroup::getRecordCount%5F91DA2B03A4.body preserve=yes
   return m_hGeneration.getRECORD_COUNT();
  //## end database::GenerationDataGroup::getRecordCount%5F91DA2B03A4.body
}

bool GenerationDataGroup::getSize (int* plRecordCount, size_t* plByteCount, size_t* plMaxRecordLength, bool bTruncate)
{
  //## begin database::GenerationDataGroup::getSize%40A9FD080399.body preserve=yes
   *plRecordCount = 0;
   *plByteCount = 0;
   *plMaxRecordLength = 0;
   char* psBuffer = new char[32768];
   size_t m = 0;
   EVP_MD* md = (EVP_MD*)EVP_sha512();
   EVP_MD_CTX* mdctx = EVP_MD_CTX_new();
   unsigned char md_value[EVP_MAX_MD_SIZE];
   unsigned int md_len;
   EVP_MD_CTX_reset(mdctx);
   EVP_DigestInit_ex(mdctx,md,NULL);
   bool b = IF::Trace::getEnable();
   IF::Trace::setEnable(false);
   while (read(psBuffer,32768,&m,false,bTruncate))
   {
      EVP_DigestUpdate(mdctx,psBuffer,m);
      if (*plRecordCount >= INT_MAX)
      {
         EVP_MD_CTX_free(mdctx);
         delete [] psBuffer;
         return false;
      }
      ++*plRecordCount;
      if (*plByteCount < INT_MAX - m)
         *plByteCount += m;
      if (m > *plMaxRecordLength)
         *plMaxRecordLength = m;
   }
   IF::Trace::setEnable(b);
   if (m_pFile->isOpen() && *plByteCount == 0)
      commit();
   else
      m_pFile->close();
   delete [] psBuffer;
   EVP_DigestFinal_ex(mdctx,md_value,&md_len);
   EVP_MD_CTX_free(mdctx);
   char szTemp[3];
   string strHash;
   for (int i = 0; i < md_len; i++)
      strHash.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%02x",(unsigned char)md_value[i]));
   m_hGeneration.setFILE_HASH(strHash);
   m_hGeneration.setRECORD_COUNT(*plRecordCount);
   m_hGeneration.setFILE_SIZE(*plByteCount);
   m_lProgress = 0;
   return (*plRecordCount > 0);
  //## end database::GenerationDataGroup::getSize%40A9FD080399.body
}

bool GenerationDataGroup::open (enum FlatFile::OpenType nOpenType, bool* pbDuplicate, bool* pbEmpty)
{
  //## begin database::GenerationDataGroup::open%40A9F3B202CE.body preserve=yes
   if (pbDuplicate)
      *pbDuplicate = false;
   if (pbEmpty)
      *pbEmpty = false;
   Context hContext(m_strIMAGEID,m_strTASKID);
   string strCONTEXT_DATA;
   if (hContext.get(m_strCONTEXT_KEY.c_str(),strCONTEXT_DATA) == false)
      return false;
   Trace::put(strCONTEXT_DATA.c_str());
#ifdef MVS
   m_pFile->setName(m_strCONTEXT_KEY.c_str());
#endif
   m_lProgress = 0;
   int j = 0;
   if (strCONTEXT_DATA.length() == 0)
   {
      if (!m_hGeneration.open())
         return false;
         char szCONTEXT_DATA[64] = { "" };
         snprintf(szCONTEXT_DATA,sizeof(szCONTEXT_DATA),"%04d %07d",m_hGeneration.getGDG_NUMBER(),m_hGeneration.getGDG_PROGRESS());
         strCONTEXT_DATA.assign(szCONTEXT_DATA);
   }
   else
      m_hGeneration.reset();
   vector<string> hTokens;
   int iTokens = Buffer::parse(strCONTEXT_DATA," ",hTokens);
   m_lNumber = atoi(hTokens[0].c_str());
   m_hGeneration.setGDG_NUMBER( m_lNumber); //if read from TASK_CONTEXT
   if (iTokens > 1)
   {
      j = atoi(hTokens[1].c_str());
      m_hGeneration.setGDG_PROGRESS( j ); //if read from TASK_CONTEXT

#ifndef MVS
      string strPath;
      if (hContext.get(m_strCONTEXT_KEY.c_str(),strPath,'D') == false)
         return false;
      if (strPath.empty())
         strPath.assign(m_hGeneration.getGDG_PATH());
      if (!strPath.empty())
         m_pFile->setPath(strPath);
#endif
   }
   m_strTimestamp = (iTokens > 2) ? hTokens[2] : Clock::instance()->getYYYYMMDDHHMMSSHN();
   string strDatasetName(m_pFile->datasetName());
   Trace::put(strDatasetName.c_str());
#ifdef MVS
   if (strDatasetName.length() == 0)
      return false;
   size_t n = strDatasetName.find(' ');
   if (n != string::npos)
      strDatasetName.resize(n);
   strDatasetName.resize(strDatasetName.length() - 7);
   char szFileGDG[8];
   snprintf(szFileGDG,sizeof(szFileGDG),"%04dV00",m_lNumber);
   strDatasetName.append(szFileGDG,7);
   m_pFile->setDatasetName(strDatasetName.c_str());
   Trace::put(strDatasetName.c_str());
#endif
   if (!m_pFile->open(nOpenType))
   {
      if (Clock::instance()->getMinute() == 0)
      {
         if (m_lNumber == 1)
         {
#ifdef MVS
            char szTemp[15];
            memcpy(szTemp,strCONTEXT_DATA.data(),4);
            memcpy(szTemp + 4," OF IMPORT",10);
            szTemp[14]='\0';
            Console::display("ST242",m_strCONTEXT_KEY.c_str(),szTemp);
#else
            Console::display("ST242",m_strCONTEXT_KEY.c_str(),(strDatasetName.length () > 35) ? (strDatasetName.substr(0,32) + "...").c_str() : strDatasetName.c_str());
            //ST242 - FILE @@@@@@@@: @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ NOT FOUND
#endif
         }
      }
      m_lProgress = -1;
      return false;
   }
   //Duplicate Validation...
   m_hGeneration.setGDG_PATH(m_pFile->getDatasetName());
   if (m_hGeneration.getFILE_HASH().empty())
   {
      int iRecordCount;
      size_t iByteCount;
      size_t iMaxRecordLength;
      bool bEmpty = false;
      if (!getSize(&iRecordCount,&iByteCount,&iMaxRecordLength))
      {
         if (pbEmpty && iRecordCount == 0)
            *pbEmpty = true;
         bEmpty = true;
      }
      else 
      {
         if (!m_pFile->open(nOpenType)) //re-open the file as getSize will close it.
            return false;
         if (m_hGeneration.isDuplicate(m_hGeneration.getFILE_HASH()))
         {
            Trace::put("Duplicate file (Name : Hash) ", m_pFile->getDatasetName() + " : " + m_hGeneration.getFILE_HASH(), true);
            string strFileName;
            m_pFile->getBaseName(strFileName, true);
            char szTemp[PERCENTF];
            snprintf(szTemp, sizeof(szTemp), "DuplicateFile - %s", strFileName.c_str());
            Console::display("ST700", szTemp);
#ifdef MVS
            commit();
#else
            m_pFile->move("..\\Complete");
#endif
            if (pbDuplicate)
               *pbDuplicate = true;
            return false;
         }
      }
      if (!bEmpty && !m_hGeneration.save())
         return false;
      if (!hContext.remove(m_strCONTEXT_KEY.c_str(),' '))
         return false;
#ifndef MVS
      if (!hContext.remove(m_strCONTEXT_KEY.c_str(),'D'))
         return false;
#endif
      if (bEmpty)
         return false;
   }
#ifdef MVS
   Console::display("ST243",m_strCONTEXT_KEY.c_str(),strCONTEXT_DATA.substr(0,4).c_str());
#else
   string strBaseName;
   m_pFile->getBaseName(strBaseName,true);
   Console::display("ST243",m_strCONTEXT_KEY.c_str(),strBaseName.c_str());
   // ST243 - FILE @@@@@@@@: @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ IMPORT STARTED
#endif
   // fast forward
   char* psBuffer = new char[32768];
   size_t m = 0;
   bool b = true;
   int i = 0;
   bool bTrace = Trace::getEnable();
   if (j)
   {
      Trace::put("Fast Forward :", m_hGeneration.getGDG_PATH(), true);
      Trace::setEnable(false);
   }
   while (b && i < j)
   {
      b = read(psBuffer,32768,&m,true);
      ++i;
   }
   Trace::setEnable(bTrace);
   delete [] psBuffer;
   return true;
  //## end database::GenerationDataGroup::open%40A9F3B202CE.body
}

bool GenerationDataGroup::read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward, bool bTruncate)
{
  //## begin database::GenerationDataGroup::read%418F8822036B.body preserve=yes
   if (lBufferLength <= 0)
      return false;
   if (!m_pFile->isOpen())
      if (!open(FlatFile::CX_OPEN_INPUT))
      {
         m_lProgress = -1;
         return false;
      }
   m_bReadError = false;
   bool b = m_pFile->read(psBuffer,lBufferLength,plRecordLength,&m_bReadError);
   if (b)
   {
      ++m_lProgress;
      if (bTruncate)
      {
         while (*plRecordLength > 0
            && psBuffer[*plRecordLength - 1] == ' ')
            *plRecordLength -= 1;
         psBuffer[*plRecordLength] = '\0';
      }
   }
   return b;
  //## end database::GenerationDataGroup::read%418F8822036B.body
}

bool GenerationDataGroup::rollback ()
{
  //## begin database::GenerationDataGroup::rollback%4D88FB7F03B5.body preserve=yes
   return true;
  //## end database::GenerationDataGroup::rollback%4D88FB7F03B5.body
}

void GenerationDataGroup::update (Subject* pSubject)
{
  //## begin database::GenerationDataGroup::update%4558A1100119.body preserve=yes
  //## end database::GenerationDataGroup::update%4558A1100119.body
}

// Additional Declarations
  //## begin database::GenerationDataGroup%40A8FDA4029F.declarations preserve=yes
bool GenerationDataGroup::read (char* psBuffer, int lBufferLength, int* plRecordLength, bool bFastForward, bool bTruncate)
{
   if (lBufferLength <= 0)
      return false;
   if (!m_pFile->isOpen())
      if (!open(FlatFile::CX_OPEN_INPUT))
      {
         m_lProgress = -1;
         return false;
      }
   m_bReadError = false;
   size_t m = (size_t)lBufferLength;
   size_t n = 0;
   bool b = m_pFile->read(psBuffer,m,&n,&m_bReadError);
   if (b)
   {
      ++m_lProgress;
      if (bTruncate)
      {
         while (*plRecordLength > 0
            && psBuffer[*plRecordLength - 1] == ' ')
            *plRecordLength -= 1;
         psBuffer[*plRecordLength] = '\0';
      }
   }
   *plRecordLength = (int)n;
   return b;
}
  //## end database::GenerationDataGroup%40A8FDA4029F.declarations
} // namespace database

//## begin module%40A8FE9100EA.epilog preserve=yes
//## end module%40A8FE9100EA.epilog
