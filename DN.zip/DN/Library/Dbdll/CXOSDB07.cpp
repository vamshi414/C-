//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3715EEB001C7.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3715EEB001C7.cm

//## begin module%3715EEB001C7.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3715EEB001C7.cp

//## Module: CXOSDB07%3715EEB001C7; Package body
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXOSDB07.cpp

//## begin module%3715EEB001C7.additionalIncludes preserve=no
//## end module%3715EEB001C7.additionalIncludes

//## begin module%3715EEB001C7.includes preserve=yes
// $Date:   Apr 08 2004 10:16:52  $ $Author:   D02405  $ $Revision:   1.2  $
//## end module%3715EEB001C7.includes

#ifndef CXOSDB07_h
#include "CXODDB07.hpp"
#endif
//## begin module%3715EEB001C7.declarations preserve=no
//## end module%3715EEB001C7.declarations

//## begin module%3715EEB001C7.additionalDeclarations preserve=yes
//## end module%3715EEB001C7.additionalDeclarations


//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::TransactionRemover 






TransactionRemover::TransactionRemover()
  //## begin TransactionRemover::TransactionRemover%34C3A79F0094_const.hasinit preserve=no
      : m_cType(' ')
  //## end TransactionRemover::TransactionRemover%34C3A79F0094_const.hasinit
  //## begin TransactionRemover::TransactionRemover%34C3A79F0094_const.initialization preserve=yes
  //## end TransactionRemover::TransactionRemover%34C3A79F0094_const.initialization
{
  //## begin database::TransactionRemover::TransactionRemover%34C3A79F0094_const.body preserve=yes
  //## end database::TransactionRemover::TransactionRemover%34C3A79F0094_const.body
}


TransactionRemover::~TransactionRemover()
{
  //## begin database::TransactionRemover::~TransactionRemover%34C3A79F0094_dest.body preserve=yes
  //## end database::TransactionRemover::~TransactionRemover%34C3A79F0094_dest.body
}


// Additional Declarations
  //## begin database::TransactionRemover%34C3A79F0094.declarations preserve=yes
  //## end database::TransactionRemover%34C3A79F0094.declarations

} // namespace database

//## begin module%3715EEB001C7.epilog preserve=yes
//## end module%3715EEB001C7.epilog
