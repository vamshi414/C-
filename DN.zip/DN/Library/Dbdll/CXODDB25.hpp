//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41D9BB600119.cm preserve=no
//## end module%41D9BB600119.cm

//## begin module%41D9BB600119.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%41D9BB600119.cp

//## Module: CXOSDB25%41D9BB600119; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB25.hpp

#ifndef CXOSDB25_h
#define CXOSDB25_h 1

//## begin module%41D9BB600119.additionalIncludes preserve=no
//## end module%41D9BB600119.additionalIncludes

//## begin module%41D9BB600119.includes preserve=yes
#include <vector>
#define DATA_BUFFER 65536
//## end module%41D9BB600119.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SearchCondition;
class Statement;
class SelectStatement;
class Row;
class Query;
class KeyRing;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DateTime;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

namespace IF {
class Extract;
class Job;
class Timestamp;
class SiteSpecification;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MinuteTimer;
class Timer;
} // namespace timer

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace database {
class SwitchClock;
class FileFactory;
class Array;

} // namespace database

//## begin module%41D9BB600119.declarations preserve=no
//## end module%41D9BB600119.declarations

//## begin module%41D9BB600119.additionalDeclarations preserve=yes
//## end module%41D9BB600119.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::ExportFile%41D9B9BD0251.preface preserve=yes
//## end database::ExportFile%41D9B9BD0251.preface

//## Class: ExportFile%41D9B9BD0251
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%41DDB05A0000;DatabaseFactory { -> F}
//## Uses: <unnamed>%41DECFB20203;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%41E4381001B5;Database { -> F}
//## Uses: <unnamed>%41E4495D034B;timer::Clock { -> F}
//## Uses: <unnamed>%41E705330196;monitor::UseCase { -> F}
//## Uses: <unnamed>%41E94B040186;timer::Timer { -> F}
//## Uses: <unnamed>%41E94E2F00CB;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%41ED4F4B000F;IF::Trace { -> F}
//## Uses: <unnamed>%4230CB5803B9;IF::Extract { -> F}
//## Uses: <unnamed>%4484358103D8;SwitchClock { -> F}
//## Uses: <unnamed>%448435A702DE;IF::Timestamp { -> F}
//## Uses: <unnamed>%45758E8A0238;IF::FlatFile { -> }
//## Uses: <unnamed>%45920A0F01D7;reusable::SearchCondition { -> F}
//## Uses: <unnamed>%48E533EE0056;reusable::Query { -> F}
//## Uses: <unnamed>%49E33ED90084;reusable::KeyRing { -> F}
//## Uses: <unnamed>%5A84ACAD03C8;Array { -> F}
//## Uses: <unnamed>%6310B71D03D4;IF::DateTime { -> F}
//## Uses: <unnamed>%6555E993004D;IF::SiteSpecification { -> F}
//## Uses: <unnamed>%6555E9BB0398;IF::Job { -> F}

class DllExport ExportFile : public reusable::Observer  //## Inherits: <unnamed>%41D9B9F0032C
{
  //## begin database::ExportFile%41D9B9BD0251.initialDeclarations preserve=yes
  //## end database::ExportFile%41D9B9BD0251.initialDeclarations

  public:
    //## Constructors (generated)
      ExportFile();

      ExportFile(const ExportFile &right);

    //## Constructors (specified)
      //## Operation: ExportFile%43D4E7A0037A
      ExportFile (const string& strDX_FILE_TYPE, const string& strENTITY_TYPE, const string& strENTITY_ID, const string& strDATE_RECON, const string& strSCHED_TIME);

    //## Destructor (generated)
      virtual ~ExportFile();

    //## Assignment Operation (generated)
      ExportFile & operator=(const ExportFile &right);

    //## Equality Operations (generated)
      bool operator==(const ExportFile &right) const;

      bool operator!=(const ExportFile &right) const;


    //## Other Operations (specified)
      //## Operation: append%43BFED2500DA
      bool append ();

      //## Operation: bind%41E93CE20119
      void bind (reusable::Query& hQuery);

      //## Operation: bind2%4230C6A7003E
      void bind2 (reusable::Query& hQuery);

      //## Operation: close%42064EB6003E
      virtual bool close ();

      //## Operation: complete%41EC5FFE02DE
      bool complete ();

      //## Operation: create%41E948B10399
      virtual bool create ();

      //## Operation: distribute%457571790326
      virtual bool distribute (string& strDATA_BUFFER, IF::FlatFile& hFlatFile);

      //## Operation: email%476734670157
      virtual bool email ();

      //## Operation: erase%45C036110326
      virtual bool erase ();

      //## Operation: finish%5C486F8901E1
      virtual bool finish (IF::FlatFile& hFlatFile);

      //## Operation: getCount%45390EEC0251
      int getCount ();

      //## Operation: getDX_FILE_ID%61157FA40088
      int getDX_FILE_ID (int iIndex = 0) const;

      //## Operation: getPrevious%6115817002A5
      bool getPrevious (Query& hQuery, ExportFile& hPrevious, int iDays, const char* pszDX_FILE_TYPE = 0);

      //## Operation: import%453FA39001A5
      virtual bool import ();

      //## Operation: import%4767CBC600AB
      virtual void import (const string& strDATA_BUFFER);

      //## Operation: initialize%4517F24901E3
      virtual bool initialize ();

      //## Operation: initiate%41EC5F21038A
      bool initiate ();

      //## Operation: isPresent%45ABE5D90399
      bool isPresent ();

      //## Operation: isPresent2%6115815A02DA
      bool isPresent2 ();

      //## Operation: key%47FE36CD03B3
      int key () const;

      //## Operation: read%43C6B2050167
      bool read (int iSEQ_NO, string& strDATA_BUFFER);

      //## Operation: replace%43C6B22901D4
      bool replace (int iSEQ_NO, const string& strDATA_BUFFER);

      //## Operation: replicate%41EEBD7B01E4
      virtual bool replicate (const string& strDATE_RECON, const string& strRole);

      //## Operation: reschedule%492197310134
      bool reschedule ();

      //## Operation: reschedule%582CD6780004
      static bool reschedule (const string& strDX_FILE_TYPE, const string& strDATE_RECON);

      //## Operation: reserveBuffer%62A1B8C1038E
      void reserveBuffer (size_t lBufferLength);

      //## Operation: setDX_FILE_ID%61157FC800DB
      void setDX_FILE_ID (int iDX_FILE_ID, int iIndex = 0);

      //## Operation: setKey%47FE47AE0243
      void setKey (char* psValue, int iLength);

      //## Operation: setOrderByClause%4E84933900CC
      virtual void setOrderByClause (reusable::Query& hQuery);

      //## Operation: start%5C486F880131
      virtual bool start (IF::FlatFile& hFlatFile);

      //## Operation: submit%6555E70A0248
      virtual bool submit (string& strDX_PATH);

      //## Operation: trigger%41F6BBC1032C
      bool trigger ();

      //## Operation: unionAll%6115817E0215
      virtual bool unionAll (Query& hQuery);

      //## Operation: update%41E8644F03A9
      virtual void update (Subject* pSubject);

      //## Operation: updateProgress%41EC630600EA
      bool updateProgress (int lDX_FILE_ID, const char* pszDX_STATE, string strTSTAMP_FORMATTED);

      //## Operation: write%41E825B20213
      virtual bool write (int iDATA_BUFFER, int iSEQ_NO = -1, bool bUpdate = false, bool bTruncate = true);

      //## Operation: write%43D4E582033C
      bool write (const char* psDATA_BUFFER, int iDATA_BUFFER, int iSEQ_NO = -1);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ALT_REC_KEY%45BF40A7016B
      //	This column may be used for different purposes over
      //	time, although it's initial usage will be to perform
      //	Totals reset. The common denominator in the usage of
      //	this column is that it will be an alternate key for
      //	searching the data. It will still be included in a
      //	unique index consisting of ALT_REC_KEY and FILE_ID, in
      //	that order.
      const string& getALT_REC_KEY () const
      {
        //## begin database::ExportFile::getALT_REC_KEY%45BF40A7016B.get preserve=no
        return m_strALT_REC_KEY;
        //## end database::ExportFile::getALT_REC_KEY%45BF40A7016B.get
      }

      void setALT_REC_KEY (const string& value)
      {
        //## begin database::ExportFile::setALT_REC_KEY%45BF40A7016B.set preserve=no
        m_strALT_REC_KEY = value;
        //## end database::ExportFile::setALT_REC_KEY%45BF40A7016B.set
      }


      //## Attribute: DATA_BUFFER%41E8323C008C
      static char* getDATA_BUFFER ();

      //## Attribute: DATE_RECON%41E82FE0003E
      const string& getDATE_RECON () const
      {
        //## begin database::ExportFile::getDATE_RECON%41E82FE0003E.get preserve=no
        return m_strDATE_RECON;
        //## end database::ExportFile::getDATE_RECON%41E82FE0003E.get
      }

      void setDATE_RECON (const string& value)
      {
        //## begin database::ExportFile::setDATE_RECON%41E82FE0003E.set preserve=no
        m_strDATE_RECON = value;
        //## end database::ExportFile::setDATE_RECON%41E82FE0003E.set
      }


      //## Attribute: DX_FILE_TYPE%41E8300901C5
      const string& getDX_FILE_TYPE () const
      {
        //## begin database::ExportFile::getDX_FILE_TYPE%41E8300901C5.get preserve=no
        return m_strDX_FILE_TYPE;
        //## end database::ExportFile::getDX_FILE_TYPE%41E8300901C5.get
      }

      void setDX_FILE_TYPE (const string& value)
      {
        //## begin database::ExportFile::setDX_FILE_TYPE%41E8300901C5.set preserve=no
        m_strDX_FILE_TYPE = value;
        //## end database::ExportFile::setDX_FILE_TYPE%41E8300901C5.set
      }


      //## Attribute: DX_REPORT_ID%4EB16E8D00C7
      const int& getDX_REPORT_ID () const
      {
        //## begin database::ExportFile::getDX_REPORT_ID%4EB16E8D00C7.get preserve=no
        return m_iDX_REPORT_ID;
        //## end database::ExportFile::getDX_REPORT_ID%4EB16E8D00C7.get
      }

      void setDX_REPORT_ID (const int& value)
      {
        //## begin database::ExportFile::setDX_REPORT_ID%4EB16E8D00C7.set preserve=no
        m_iDX_REPORT_ID = value;
        //## end database::ExportFile::setDX_REPORT_ID%4EB16E8D00C7.set
      }


      //## Attribute: DX_REPORT_STAT%4EB16F01029B
      const string& getDX_REPORT_STAT () const
      {
        //## begin database::ExportFile::getDX_REPORT_STAT%4EB16F01029B.get preserve=no
        return m_strDX_REPORT_STAT;
        //## end database::ExportFile::getDX_REPORT_STAT%4EB16F01029B.get
      }

      void setDX_REPORT_STAT (const string& value)
      {
        //## begin database::ExportFile::setDX_REPORT_STAT%4EB16F01029B.set preserve=no
        m_strDX_REPORT_STAT = value;
        //## end database::ExportFile::setDX_REPORT_STAT%4EB16F01029B.set
      }


      //## Attribute: DX_STATE%41F7C1B4006D
      const string& getDX_STATE () const
      {
        //## begin database::ExportFile::getDX_STATE%41F7C1B4006D.get preserve=no
        return m_strDX_STATE;
        //## end database::ExportFile::getDX_STATE%41F7C1B4006D.get
      }

      void setDX_STATE (const string& value)
      {
        //## begin database::ExportFile::setDX_STATE%41F7C1B4006D.set preserve=no
        m_strDX_STATE = value;
        //## end database::ExportFile::setDX_STATE%41F7C1B4006D.set
      }


      //## Attribute: EmptyReport%6220DED50276
      const bool& getEmptyReport () const
      {
        //## begin database::ExportFile::getEmptyReport%6220DED50276.get preserve=no
        return m_bEmptyReport;
        //## end database::ExportFile::getEmptyReport%6220DED50276.get
      }

      void setEmptyReport (const bool& value)
      {
        //## begin database::ExportFile::setEmptyReport%6220DED50276.set preserve=no
        m_bEmptyReport = value;
        //## end database::ExportFile::setEmptyReport%6220DED50276.set
      }


      //## Attribute: ENTITY_ID%41E82FA400EA
      const string& getENTITY_ID () const
      {
        //## begin database::ExportFile::getENTITY_ID%41E82FA400EA.get preserve=no
        return m_strENTITY_ID;
        //## end database::ExportFile::getENTITY_ID%41E82FA400EA.get
      }

      void setENTITY_ID (const string& value)
      {
        //## begin database::ExportFile::setENTITY_ID%41E82FA400EA.set preserve=no
        m_strENTITY_ID = value;
        //## end database::ExportFile::setENTITY_ID%41E82FA400EA.set
      }


      //## Attribute: ENTITY_TYPE%41EE6DE20128
      const string& getENTITY_TYPE () const
      {
        //## begin database::ExportFile::getENTITY_TYPE%41EE6DE20128.get preserve=no
        return m_strENTITY_TYPE;
        //## end database::ExportFile::getENTITY_TYPE%41EE6DE20128.get
      }

      void setENTITY_TYPE (const string& value)
      {
        //## begin database::ExportFile::setENTITY_TYPE%41EE6DE20128.set preserve=no
        m_strENTITY_TYPE = value;
        //## end database::ExportFile::setENTITY_TYPE%41EE6DE20128.set
      }


      //## Attribute: EXPORT_RETRY_COUNT%454142EF0290
      const int& getEXPORT_RETRY_COUNT () const
      {
        //## begin database::ExportFile::getEXPORT_RETRY_COUNT%454142EF0290.get preserve=no
        return m_iEXPORT_RETRY_COUNT;
        //## end database::ExportFile::getEXPORT_RETRY_COUNT%454142EF0290.get
      }

      void setEXPORT_RETRY_COUNT (const int& value)
      {
        //## begin database::ExportFile::setEXPORT_RETRY_COUNT%454142EF0290.set preserve=no
        m_iEXPORT_RETRY_COUNT = value;
        //## end database::ExportFile::setEXPORT_RETRY_COUNT%454142EF0290.set
      }


      //## Attribute: Null%4EDD369D0050
      const short int& getNull () const
      {
        //## begin database::ExportFile::getNull%4EDD369D0050.get preserve=no
        return m_iNull;
        //## end database::ExportFile::getNull%4EDD369D0050.get
      }

      void setNull (const short int& value)
      {
        //## begin database::ExportFile::setNull%4EDD369D0050.set preserve=no
        m_iNull = value;
        //## end database::ExportFile::setNull%4EDD369D0050.set
      }


      //## Attribute: Key%47FE364C01D6
      const string& getKey () const
      {
        //## begin database::ExportFile::getKey%47FE364C01D6.get preserve=no
        return m_strKey;
        //## end database::ExportFile::getKey%47FE364C01D6.get
      }

      void setKey (const string& value)
      {
        //## begin database::ExportFile::setKey%47FE364C01D6.set preserve=no
        m_strKey = value;
        //## end database::ExportFile::setKey%47FE364C01D6.set
      }


      //## Attribute: ORDER_BY%6303EDAC031C
      const string& getORDER_BY () const
      {
        //## begin database::ExportFile::getORDER_BY%6303EDAC031C.get preserve=no
        return m_strORDER_BY;
        //## end database::ExportFile::getORDER_BY%6303EDAC031C.get
      }

      void setORDER_BY (const string& value)
      {
        //## begin database::ExportFile::setORDER_BY%6303EDAC031C.set preserve=no
        m_strORDER_BY = value;
        //## end database::ExportFile::setORDER_BY%6303EDAC031C.set
      }


      //## Attribute: ROUTING_DATA%4224C4F601C5
      const string& getROUTING_DATA () const
      {
        //## begin database::ExportFile::getROUTING_DATA%4224C4F601C5.get preserve=no
        return m_strROUTING_DATA;
        //## end database::ExportFile::getROUTING_DATA%4224C4F601C5.get
      }

      void setROUTING_DATA (const string& value)
      {
        //## begin database::ExportFile::setROUTING_DATA%4224C4F601C5.set preserve=no
        m_strROUTING_DATA = value;
        //## end database::ExportFile::setROUTING_DATA%4224C4F601C5.set
      }


      //## Attribute: ROUTING_PASSWORD%4224C5030203
      const string& getROUTING_PASSWORD () const
      {
        //## begin database::ExportFile::getROUTING_PASSWORD%4224C5030203.get preserve=no
        return m_strROUTING_PASSWORD;
        //## end database::ExportFile::getROUTING_PASSWORD%4224C5030203.get
      }

      void setROUTING_PASSWORD (const string& value)
      {
        //## begin database::ExportFile::setROUTING_PASSWORD%4224C5030203.set preserve=no
        m_strROUTING_PASSWORD = value;
        //## end database::ExportFile::setROUTING_PASSWORD%4224C5030203.set
      }


      //## Attribute: ROUTING_TYPE%4224C50302BF
      const string& getROUTING_TYPE () const
      {
        //## begin database::ExportFile::getROUTING_TYPE%4224C50302BF.get preserve=no
        return m_strROUTING_TYPE;
        //## end database::ExportFile::getROUTING_TYPE%4224C50302BF.get
      }

      void setROUTING_TYPE (const string& value)
      {
        //## begin database::ExportFile::setROUTING_TYPE%4224C50302BF.set preserve=no
        m_strROUTING_TYPE = value;
        //## end database::ExportFile::setROUTING_TYPE%4224C50302BF.set
      }


      //## Attribute: ROUTING_USER_ID%4224C503037A
      const string& getROUTING_USER_ID () const
      {
        //## begin database::ExportFile::getROUTING_USER_ID%4224C503037A.get preserve=no
        return m_strROUTING_USER_ID;
        //## end database::ExportFile::getROUTING_USER_ID%4224C503037A.get
      }

      void setROUTING_USER_ID (const string& value)
      {
        //## begin database::ExportFile::setROUTING_USER_ID%4224C503037A.set preserve=no
        m_strROUTING_USER_ID = value;
        //## end database::ExportFile::setROUTING_USER_ID%4224C503037A.set
      }


      //## Attribute: SCHED_FREQUENCY%4230CE660000
      const string& getSCHED_FREQUENCY () const
      {
        //## begin database::ExportFile::getSCHED_FREQUENCY%4230CE660000.get preserve=no
        return m_strSCHED_FREQUENCY;
        //## end database::ExportFile::getSCHED_FREQUENCY%4230CE660000.get
      }

      void setSCHED_FREQUENCY (const string& value)
      {
        //## begin database::ExportFile::setSCHED_FREQUENCY%4230CE660000.set preserve=no
        m_strSCHED_FREQUENCY = value;
        //## end database::ExportFile::setSCHED_FREQUENCY%4230CE660000.set
      }


      //## Attribute: SCHED_TIME%430B77DB0157
      const string& getSCHED_TIME () const
      {
        //## begin database::ExportFile::getSCHED_TIME%430B77DB0157.get preserve=no
        return m_strSCHED_TIME;
        //## end database::ExportFile::getSCHED_TIME%430B77DB0157.get
      }

      void setSCHED_TIME (const string& value)
      {
        //## begin database::ExportFile::setSCHED_TIME%430B77DB0157.set preserve=no
        m_strSCHED_TIME = value;
        //## end database::ExportFile::setSCHED_TIME%430B77DB0157.set
      }


      //## Attribute: SEQ_NO%41E82DC6001F
      const int& getSEQ_NO () const
      {
        //## begin database::ExportFile::getSEQ_NO%41E82DC6001F.get preserve=no
        return m_iSEQ_NO;
        //## end database::ExportFile::getSEQ_NO%41E82DC6001F.get
      }

      void setSEQ_NO (const int& value)
      {
        //## begin database::ExportFile::setSEQ_NO%41E82DC6001F.set preserve=no
        m_iSEQ_NO = value;
        //## end database::ExportFile::setSEQ_NO%41E82DC6001F.set
      }


      //## Attribute: TASK_FORMATTED%42037C430138
      const string& getTASK_FORMATTED () const
      {
        //## begin database::ExportFile::getTASK_FORMATTED%42037C430138.get preserve=no
        return m_strTASK_FORMATTED;
        //## end database::ExportFile::getTASK_FORMATTED%42037C430138.get
      }

      void setTASK_FORMATTED (const string& value)
      {
        //## begin database::ExportFile::setTASK_FORMATTED%42037C430138.set preserve=no
        m_strTASK_FORMATTED = value;
        //## end database::ExportFile::setTASK_FORMATTED%42037C430138.set
      }


      //## Attribute: TSTAMP_FORMATTED%42037C4B00CB
      const string& getTSTAMP_FORMATTED () const
      {
        //## begin database::ExportFile::getTSTAMP_FORMATTED%42037C4B00CB.get preserve=no
        return m_strTSTAMP_FORMATTED;
        //## end database::ExportFile::getTSTAMP_FORMATTED%42037C4B00CB.get
      }

      void setTSTAMP_FORMATTED (const string& value)
      {
        //## begin database::ExportFile::setTSTAMP_FORMATTED%42037C4B00CB.set preserve=no
        m_strTSTAMP_FORMATTED = value;
        //## end database::ExportFile::setTSTAMP_FORMATTED%42037C4B00CB.set
      }


      //## Attribute: TSTAMP_INITIATED%43B59FA40148
      const string& getTSTAMP_INITIATED () const
      {
        //## begin database::ExportFile::getTSTAMP_INITIATED%43B59FA40148.get preserve=no
        return m_strTSTAMP_INITIATED;
        //## end database::ExportFile::getTSTAMP_INITIATED%43B59FA40148.get
      }

      void setTSTAMP_INITIATED (const string& value)
      {
        //## begin database::ExportFile::setTSTAMP_INITIATED%43B59FA40148.set preserve=no
        m_strTSTAMP_INITIATED = value;
        //## end database::ExportFile::setTSTAMP_INITIATED%43B59FA40148.set
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Library::Database_CAT::<unnamed>%453FAD920000
      //## Role: ExportFile::<m_pRow>%453FAD920280
      reusable::Row * getRow ()
      {
        //## begin database::ExportFile::getRow%453FAD920280.get preserve=no
        return m_pRow;
        //## end database::ExportFile::getRow%453FAD920280.get
      }


    // Additional Public Declarations
      //## begin database::ExportFile%41D9B9BD0251.public preserve=yes
      //## end database::ExportFile%41D9B9BD0251.public

  protected:

    //## Other Operations (specified)
      //## Operation: insert%4BB226160251
      virtual bool insert (const char* psDATA_BUFFER, int iDATA_BUFFER, int iSEQ_NO, bool bUpdate, bool bTruncate);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: SwitchClock%45BF09BD0227
      void setSwitchClock (const bool& value)
      {
        //## begin database::ExportFile::setSwitchClock%45BF09BD0227.set preserve=no
        m_bSwitchClock = value;
        //## end database::ExportFile::setSwitchClock%45BF09BD0227.set
      }


    // Data Members for Class Attributes

      //## begin database::ExportFile::ALT_REC_KEY%45BF40A7016B.attr preserve=no  public: string {V} 
      string m_strALT_REC_KEY;
      //## end database::ExportFile::ALT_REC_KEY%45BF40A7016B.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%41EE6D3600BB
      //## Role: ExportFile::<m_pInsertStatement>%41EE6D36036B
      //## begin database::ExportFile::<m_pInsertStatement>%41EE6D36036B.role preserve=no  protected: reusable::Statement { -> RFHgAN}
      reusable::Statement *m_pInsertStatement;
      //## end database::ExportFile::<m_pInsertStatement>%41EE6D36036B.role

      //## Association: Connex Library::Database_CAT::<unnamed>%42BAB50702FD
      //## Role: ExportFile::<m_hTable>%42BAB50801A5
      //## begin database::ExportFile::<m_hTable>%42BAB50801A5.role preserve=no  protected: reusable::Table { -> VHgAN}
      reusable::Table m_hTable;
      //## end database::ExportFile::<m_hTable>%42BAB50801A5.role

      //## Association: Connex Library::Database_CAT::<unnamed>%43C6D5570222
      //## Role: ExportFile::<m_pUpdateStatement>%43C6D558007D
      //## begin database::ExportFile::<m_pUpdateStatement>%43C6D558007D.role preserve=no  protected: reusable::Statement { -> RFHgAN}
      reusable::Statement *m_pUpdateStatement;
      //## end database::ExportFile::<m_pUpdateStatement>%43C6D558007D.role

    // Additional Protected Declarations
      //## begin database::ExportFile%41D9B9BD0251.protected preserve=yes
      //## end database::ExportFile%41D9B9BD0251.protected

  private:
    // Additional Private Declarations
      //## begin database::ExportFile%41D9B9BD0251.private preserve=yes
      //## end database::ExportFile%41D9B9BD0251.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin database::ExportFile::DATA_BUFFER%41E8323C008C.attr preserve=no  public: static char* {V} 0
      static char* m_pDATA_BUFFER;
      //## end database::ExportFile::DATA_BUFFER%41E8323C008C.attr

      //## begin database::ExportFile::DATE_RECON%41E82FE0003E.attr preserve=no  public: string {V} 
      string m_strDATE_RECON;
      //## end database::ExportFile::DATE_RECON%41E82FE0003E.attr

      //## Attribute: DX_FILE_ID%41E832980186
      //## begin database::ExportFile::DX_FILE_ID%41E832980186.attr preserve=no  public: int[2] {V} 
      int m_iDX_FILE_ID[2];
      //## end database::ExportFile::DX_FILE_ID%41E832980186.attr

      //## begin database::ExportFile::DX_FILE_TYPE%41E8300901C5.attr preserve=no  public: string {V} 
      string m_strDX_FILE_TYPE;
      //## end database::ExportFile::DX_FILE_TYPE%41E8300901C5.attr

      //## Attribute: DX_INST_ID%4230CBC50186
      //## begin database::ExportFile::DX_INST_ID%4230CBC50186.attr preserve=no  public: string {U} 
      string m_strDX_INST_ID;
      //## end database::ExportFile::DX_INST_ID%4230CBC50186.attr

      //## begin database::ExportFile::DX_REPORT_ID%4EB16E8D00C7.attr preserve=no  public: int {U} -1
      int m_iDX_REPORT_ID;
      //## end database::ExportFile::DX_REPORT_ID%4EB16E8D00C7.attr

      //## begin database::ExportFile::DX_REPORT_STAT%4EB16F01029B.attr preserve=no  public: string {U} 
      string m_strDX_REPORT_STAT;
      //## end database::ExportFile::DX_REPORT_STAT%4EB16F01029B.attr

      //## begin database::ExportFile::DX_STATE%41F7C1B4006D.attr preserve=no  public: string {V} 
      string m_strDX_STATE;
      //## end database::ExportFile::DX_STATE%41F7C1B4006D.attr

      //## begin database::ExportFile::EmptyReport%6220DED50276.attr preserve=no  public: bool {U} false
      bool m_bEmptyReport;
      //## end database::ExportFile::EmptyReport%6220DED50276.attr

      //## begin database::ExportFile::ENTITY_ID%41E82FA400EA.attr preserve=no  public: string {V} 
      string m_strENTITY_ID;
      //## end database::ExportFile::ENTITY_ID%41E82FA400EA.attr

      //## begin database::ExportFile::ENTITY_TYPE%41EE6DE20128.attr preserve=no  public: string {V} 
      string m_strENTITY_TYPE;
      //## end database::ExportFile::ENTITY_TYPE%41EE6DE20128.attr

      //## begin database::ExportFile::EXPORT_RETRY_COUNT%454142EF0290.attr preserve=no  public: int {V} 0
      int m_iEXPORT_RETRY_COUNT;
      //## end database::ExportFile::EXPORT_RETRY_COUNT%454142EF0290.attr

      //## begin database::ExportFile::Null%4EDD369D0050.attr preserve=no  public: short int {U} 0
      short int m_iNull;
      //## end database::ExportFile::Null%4EDD369D0050.attr

      //## begin database::ExportFile::Key%47FE364C01D6.attr preserve=no  public: string {V} 
      string m_strKey;
      //## end database::ExportFile::Key%47FE364C01D6.attr

      //## begin database::ExportFile::ORDER_BY%6303EDAC031C.attr preserve=no  public: string {V} 
      string m_strORDER_BY;
      //## end database::ExportFile::ORDER_BY%6303EDAC031C.attr

      //## begin database::ExportFile::ROUTING_DATA%4224C4F601C5.attr preserve=no  public: string {V} 
      string m_strROUTING_DATA;
      //## end database::ExportFile::ROUTING_DATA%4224C4F601C5.attr

      //## begin database::ExportFile::ROUTING_PASSWORD%4224C5030203.attr preserve=no  public: string {V} 
      string m_strROUTING_PASSWORD;
      //## end database::ExportFile::ROUTING_PASSWORD%4224C5030203.attr

      //## begin database::ExportFile::ROUTING_TYPE%4224C50302BF.attr preserve=no  public: string {V} 
      string m_strROUTING_TYPE;
      //## end database::ExportFile::ROUTING_TYPE%4224C50302BF.attr

      //## begin database::ExportFile::ROUTING_USER_ID%4224C503037A.attr preserve=no  public: string {V} 
      string m_strROUTING_USER_ID;
      //## end database::ExportFile::ROUTING_USER_ID%4224C503037A.attr

      //## Attribute: SCHED_OFFSET_TIME%4230CC0201B5
      //## begin database::ExportFile::SCHED_OFFSET_TIME%4230CC0201B5.attr preserve=no  public: string {U} 
      string m_strSCHED_OFFSET_TIME;
      //## end database::ExportFile::SCHED_OFFSET_TIME%4230CC0201B5.attr

      //## begin database::ExportFile::SCHED_FREQUENCY%4230CE660000.attr preserve=no  public: string {U} 
      string m_strSCHED_FREQUENCY;
      //## end database::ExportFile::SCHED_FREQUENCY%4230CE660000.attr

      //## begin database::ExportFile::SCHED_TIME%430B77DB0157.attr preserve=no  public: string {V} 
      string m_strSCHED_TIME;
      //## end database::ExportFile::SCHED_TIME%430B77DB0157.attr

      //## begin database::ExportFile::SEQ_NO%41E82DC6001F.attr preserve=no  public: int {V} -1
      int m_iSEQ_NO;
      //## end database::ExportFile::SEQ_NO%41E82DC6001F.attr

      //## begin database::ExportFile::SwitchClock%45BF09BD0227.attr preserve=no  protected: bool {U} true
      bool m_bSwitchClock;
      //## end database::ExportFile::SwitchClock%45BF09BD0227.attr

      //## begin database::ExportFile::TASK_FORMATTED%42037C430138.attr preserve=no  public: string {V} 
      string m_strTASK_FORMATTED;
      //## end database::ExportFile::TASK_FORMATTED%42037C430138.attr

      //## begin database::ExportFile::TSTAMP_FORMATTED%42037C4B00CB.attr preserve=no  public: string {V} 
      string m_strTSTAMP_FORMATTED;
      //## end database::ExportFile::TSTAMP_FORMATTED%42037C4B00CB.attr

      //## begin database::ExportFile::TSTAMP_INITIATED%43B59FA40148.attr preserve=no  public: string {V} 
      string m_strTSTAMP_INITIATED;
      //## end database::ExportFile::TSTAMP_INITIATED%43B59FA40148.attr

      //## Attribute: BufferSize%62A1B9B201EF
      //## begin database::ExportFile::BufferSize%62A1B9B201EF.attr preserve=no  private: static size_t {V} 0
      static size_t m_lBufferSize;
      //## end database::ExportFile::BufferSize%62A1B9B201EF.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%42BAB50503B9
      //## Role: ExportFile::<m_pFileFactory>%42BAB506029F
      //## begin database::ExportFile::<m_pFileFactory>%42BAB506029F.role preserve=no  public: database::FileFactory { -> RFHgN}
      FileFactory *m_pFileFactory;
      //## end database::ExportFile::<m_pFileFactory>%42BAB506029F.role

      //## Association: Connex Library::Database_CAT::<unnamed>%453FAD920000
      //## begin database::ExportFile::<m_pRow>%453FAD920280.role preserve=no  public: reusable::Row { -> RFHgN}
      reusable::Row *m_pRow;
      //## end database::ExportFile::<m_pRow>%453FAD920280.role

    // Additional Implementation Declarations
      //## begin database::ExportFile%41D9B9BD0251.implementation preserve=yes
      //## end database::ExportFile%41D9B9BD0251.implementation

};

//## begin database::ExportFile%41D9B9BD0251.postscript preserve=yes
//## end database::ExportFile%41D9B9BD0251.postscript

} // namespace database

//## begin module%41D9BB600119.epilog preserve=yes
using namespace database;
//## end module%41D9BB600119.epilog


#endif
