//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5971113C01DC.cm preserve=no
//	$Date:   May 14 2020 18:12:10  $ $Author:   e1009510  $
//	$Revision:   1.1  $
//## end module%5971113C01DC.cm

//## begin module%5971113C01DC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5971113C01DC.cp

//## Module: CXOSDB55%5971113C01DC; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB55.hpp

#ifndef CXOSDB55_h
#define CXOSDB55_h 1

//## begin module%5971113C01DC.additionalIncludes preserve=no
//## end module%5971113C01DC.additionalIncludes

//## begin module%5971113C01DC.includes preserve=yes
//## end module%5971113C01DC.includes

#ifndef CXOSIF51_h
#include "CXODIF51.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Key;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%5971113C01DC.declarations preserve=no
//## end module%5971113C01DC.declarations

//## begin module%5971113C01DC.additionalDeclarations preserve=yes
//## end module%5971113C01DC.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::UnixEncryptedFile%5970F4710075.preface preserve=yes
//## end database::UnixEncryptedFile%5970F4710075.preface

//## Class: UnixEncryptedFile%5970F4710075
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%59711795000B;Database { -> F}
//## Uses: <unnamed>%597118450071;reusable::Key { -> F}

class DllExport UnixEncryptedFile : public IF::UnixFile  //## Inherits: <unnamed>%5970F49A003B
{
  //## begin database::UnixEncryptedFile%5970F4710075.initialDeclarations preserve=yes
  //## end database::UnixEncryptedFile%5970F4710075.initialDeclarations

  public:
    //## Constructors (generated)
      UnixEncryptedFile();

    //## Constructors (specified)
      //## Operation: UnixEncryptedFile%597205DE005C
      UnixEncryptedFile (const char* pszName, const char* pszMember);

      //## Operation: UnixEncryptedFile%597205DE005F
      UnixEncryptedFile (const char* pszName);

    //## Destructor (generated)
      virtual ~UnixEncryptedFile();


    //## Other Operations (specified)
      //## Operation: open%5970F8EA01EB
      virtual bool open (enum OpenType nOpenType = CX_OPEN_INPUT);

      //## Operation: read%5970F63400E6
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool* pbReadError = NULL);

      //## Operation: setKey%5970F65A03DA
      bool setKey (const string& strCheckDigits);

      //## Operation: write%5970F63902B0
      virtual bool write (char* psBuffer, int lRecordLength);

      //## Operation: writeBinary%597203CB0320
      bool writeBinary (char* psBuffer, int lRecordLength);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: EncryptLength%5970F7E7005C
      const int& getEncryptLength () const
      {
        //## begin database::UnixEncryptedFile::getEncryptLength%5970F7E7005C.get preserve=no
        return m_iEncryptLength;
        //## end database::UnixEncryptedFile::getEncryptLength%5970F7E7005C.get
      }

      void setEncryptLength (const int& value)
      {
        //## begin database::UnixEncryptedFile::setEncryptLength%5970F7E7005C.set preserve=no
        m_iEncryptLength = value;
        //## end database::UnixEncryptedFile::setEncryptLength%5970F7E7005C.set
      }


      //## Attribute: EncryptOffset%5970F8160364
      const int& getEncryptOffset () const
      {
        //## begin database::UnixEncryptedFile::getEncryptOffset%5970F8160364.get preserve=no
        return m_iEncryptOffset;
        //## end database::UnixEncryptedFile::getEncryptOffset%5970F8160364.get
      }

      void setEncryptOffset (const int& value)
      {
        //## begin database::UnixEncryptedFile::setEncryptOffset%5970F8160364.set preserve=no
        m_iEncryptOffset = value;
        //## end database::UnixEncryptedFile::setEncryptOffset%5970F8160364.set
      }


      //## Attribute: Endln%5970F8B40102
      void setEndln (const bool& value)
      {
        //## begin database::UnixEncryptedFile::setEndln%5970F8B40102.set preserve=no
        m_bEndln = value;
        //## end database::UnixEncryptedFile::setEndln%5970F8B40102.set
      }


      //## Attribute: Method%59720A180151
      void setMethod (const int& value)
      {
        //## begin database::UnixEncryptedFile::setMethod%59720A180151.set preserve=no
        m_iMethod = value;
        //## end database::UnixEncryptedFile::setMethod%59720A180151.set
      }


    // Additional Public Declarations
      //## begin database::UnixEncryptedFile%5970F4710075.public preserve=yes
      //## end database::UnixEncryptedFile%5970F4710075.public

  protected:
    // Additional Protected Declarations
      //## begin database::UnixEncryptedFile%5970F4710075.protected preserve=yes
      //## end database::UnixEncryptedFile%5970F4710075.protected

  private:
    // Additional Private Declarations
      //## begin database::UnixEncryptedFile%5970F4710075.private preserve=yes
      //## end database::UnixEncryptedFile%5970F4710075.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: EncryptionBuffer%5970F88301DB
      //## begin database::UnixEncryptedFile::EncryptionBuffer%5970F88301DB.attr preserve=no  public: unsigned char* {U} 0
      unsigned char* m_pEncryptionBuffer;
      //## end database::UnixEncryptedFile::EncryptionBuffer%5970F88301DB.attr

      //## begin database::UnixEncryptedFile::EncryptLength%5970F7E7005C.attr preserve=no  public: int {U} 0
      int m_iEncryptLength;
      //## end database::UnixEncryptedFile::EncryptLength%5970F7E7005C.attr

      //## begin database::UnixEncryptedFile::EncryptOffset%5970F8160364.attr preserve=no  public: int {U} 0
      int m_iEncryptOffset;
      //## end database::UnixEncryptedFile::EncryptOffset%5970F8160364.attr

      //## begin database::UnixEncryptedFile::Endln%5970F8B40102.attr preserve=no  public: bool {U} true
      bool m_bEndln;
      //## end database::UnixEncryptedFile::Endln%5970F8B40102.attr

      //## Attribute: Key%5970F733012E
      //## begin database::UnixEncryptedFile::Key%5970F733012E.attr preserve=no  public: reusable::Key* {U} 0
      reusable::Key* m_pKey;
      //## end database::UnixEncryptedFile::Key%5970F733012E.attr

      //## begin database::UnixEncryptedFile::Method%59720A180151.attr preserve=no  public: int {U} 2
      int m_iMethod;
      //## end database::UnixEncryptedFile::Method%59720A180151.attr

    // Additional Implementation Declarations
      //## begin database::UnixEncryptedFile%5970F4710075.implementation preserve=yes
      //## end database::UnixEncryptedFile%5970F4710075.implementation

};

//## begin database::UnixEncryptedFile%5970F4710075.postscript preserve=yes
//## end database::UnixEncryptedFile%5970F4710075.postscript

} // namespace database

//## begin module%5971113C01DC.epilog preserve=yes
//## end module%5971113C01DC.epilog


#endif
