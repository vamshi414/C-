//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41ED29D10213.cm preserve=no
//	$Date:   Aug 08 2021 22:15:24  $ $Author:   e5614616  $
//	$Revision:   1.33  $
//## end module%41ED29D10213.cm

//## begin module%41ED29D10213.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%41ED29D10213.cp

//## Module: CXOSDB27%41ED29D10213; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Dbdll\CXOSDB27.cpp

//## begin module%41ED29D10213.additionalIncludes preserve=no
//## end module%41ED29D10213.additionalIncludes

//## begin module%41ED29D10213.includes preserve=yes
#include <algorithm>
//## end module%41ED29D10213.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB26_h
#include "CXODDB26.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSDB27_h
#include "CXODDB27.hpp"
#endif


//## begin module%41ED29D10213.declarations preserve=no
//## end module%41ED29D10213.declarations

//## begin module%41ED29D10213.additionalDeclarations preserve=yes
//## end module%41ED29D10213.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
void closePostingFile( database::ExportFile*& pExportFile)
{
   if (pExportFile->close())
      Database::instance()->commit();
}

void deletePostingFile( database::ExportFile*& pExportFile)
{
   delete pExportFile;
}

void closePostingFiles(pair<const string,vector<database::ExportFile*> >& hPostingFile)
{
   for_each(hPostingFile.second.begin(),hPostingFile.second.end(),closePostingFile);
}

void deletePostingFiles(pair<const string,vector<database::ExportFile*> >& hPostingFile)
{
   for_each(hPostingFile.second.begin(),hPostingFile.second.end(),deletePostingFile);
}
//## end database%3451F34D0218.initialDeclarations

// Class database::DataControl 

//## begin database::DataControl::DataControl%4DF8B15103DE.attr preserve=no  private: static map<string,DataControl*,less<string> >* {V} 0
map<string,DataControl*,less<string> >* DataControl::m_pDataControl = 0;
//## end database::DataControl::DataControl%4DF8B15103DE.attr

//## begin database::DataControl::Instance%41ED2A7F02EE.attr preserve=no  private: static database::DataControl* {V} 0
database::DataControl* DataControl::m_pInstance = 0;
//## end database::DataControl::Instance%41ED2A7F02EE.attr

DataControl::DataControl()
  //## begin DataControl::DataControl%41ED292801E4_const.hasinit preserve=no
      : m_strQualifier("CUSTQUAL"),
        m_bSuccess(false)
  //## end DataControl::DataControl%41ED292801E4_const.hasinit
  //## begin DataControl::DataControl%41ED292801E4_const.initialization preserve=yes
  //## end DataControl::DataControl%41ED292801E4_const.initialization
{
  //## begin database::DataControl::DataControl%41ED292801E4_const.body preserve=yes
   memcpy(m_sID,"DB27",4);
   MinuteTimer::instance()->attach(this);
   MidnightAlarm::instance()->attach(this);
   update(MidnightAlarm::instance());
  //## end database::DataControl::DataControl%41ED292801E4_const.body
}

DataControl::DataControl (const string& strQualifier)
  //## begin database::DataControl::DataControl%4DF8FB710270.hasinit preserve=no
      : m_strQualifier("CUSTQUAL"),
        m_bSuccess(false)
  //## end database::DataControl::DataControl%4DF8FB710270.hasinit
  //## begin database::DataControl::DataControl%4DF8FB710270.initialization preserve=yes
  //## end database::DataControl::DataControl%4DF8FB710270.initialization
{
  //## begin database::DataControl::DataControl%4DF8FB710270.body preserve=yes
   memcpy(m_sID,"DB27",4);
   m_strQualifier = strQualifier;
   if (m_strQualifier == "CUSTQUAL")
      MinuteTimer::instance()->attach(this);
   MidnightAlarm::instance()->attach(this);
   update(MidnightAlarm::instance());
  //## end database::DataControl::DataControl%4DF8FB710270.body
}


DataControl::~DataControl()
{
  //## begin database::DataControl::~DataControl%41ED292801E4_dest.body preserve=yes
   for_each(m_hPostingFile.begin(),m_hPostingFile.end(),database::deletePostingFiles);
   MidnightAlarm::instance()->detach(this);
   MinuteTimer::instance()->detach(this);
  //## end database::DataControl::~DataControl%41ED292801E4_dest.body
}



//## Other Operations (implementation)
bool DataControl::getDestination (const string& strPROC_ID, const string& strDX_FILE_TYPE, string& strPROC_DEST_ID)
{
  //## begin database::DataControl::getDestination%457F0EEC0261.body preserve=yes
   Query hQuery;
   hQuery.setQualifier("QUALIFY","DX_PROC_DEST");
   hQuery.setQualifier("QUALIFY","DX_FILE_TYPE");
   hQuery.join("DX_PROC_DEST","INNER","DX_FILE_TYPE","DX_FILE_GROUP");
   hQuery.bind("DX_PROC_DEST","PROC_DEST_ID",Column::STRING,&strPROC_DEST_ID);
   hQuery.setBasicPredicate("DX_PROC_DEST","PROC_ID","=",strPROC_ID.c_str());
   hQuery.setBasicPredicate("DX_PROC_DEST","CUST_ID","=",Transaction::instance()->getCustomer().c_str());
   string strTemp("(" + strDX_FILE_TYPE +")");
   hQuery.setBasicPredicate("DX_FILE_TYPE","DX_FILE_TYPE","IN",strTemp.c_str());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   if (pSelectStatement->getRows() > 0)
      return true;
   hQuery.reset();
   hQuery.setQualifier("QUALIFY","DX_PROC_GRP_DEST");
   hQuery.setQualifier("QUALIFY","DX_FILE_TYPE");
   hQuery.join("DX_PROC_GRP_DEST","INNER","DX_FILE_TYPE","DX_FILE_GROUP");
   hQuery.bind("DX_PROC_GRP_DEST","PROC_GRP_DEST_ID",Column::STRING,&strPROC_DEST_ID);
   hQuery.setBasicPredicate("DX_PROC_GRP_DEST","PROC_GRP_ID","=",strPROC_ID.c_str());
   hQuery.setBasicPredicate("DX_PROC_GRP_DEST","CUST_ID","=",Transaction::instance()->getCustomer().c_str());
   hQuery.setBasicPredicate("DX_FILE_TYPE","DX_FILE_TYPE","IN",strTemp.c_str());
   return (pSelectStatement->execute(hQuery) && pSelectStatement->getRows() > 0);
  //## end database::DataControl::getDestination%457F0EEC0261.body
}

bool DataControl::getInstitutionDestination (const string& strINST_ID,const string& strDX_FILE_TYPE,string& strINST_DEST_ID)
{
  //## begin database::DataControl::getInstitutionDestination%610CA6E0003D.body preserve=yes
   Query hQuery;
   hQuery.setQualifier("QUALIFY","DX_INST_DEST");
   hQuery.setQualifier("QUALIFY","DX_FILE_TYPE");
   hQuery.join("DX_INST_DEST","INNER","DX_FILE_TYPE","DX_FILE_GROUP");
   hQuery.bind("DX_INST_DEST","INST_DEST_ID",Column::STRING, &strINST_DEST_ID);
   hQuery.setBasicPredicate("DX_INST_DEST","INST_ID","=",strINST_ID.c_str());
   hQuery.setBasicPredicate("DX_INST_DEST","CUST_ID","=",Transaction::instance()->getCustomer().c_str());
   string strTemp("(" + strDX_FILE_TYPE + ")");
   hQuery.setBasicPredicate("DX_FILE_TYPE","DX_FILE_TYPE","IN",strTemp.c_str());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   return (pSelectStatement->getRows() > 0);
  //## end database::DataControl::getInstitutionDestination%610CA6E0003D.body
}

database::DataControl* DataControl::instance (const char* pszQualifier)
{
  //## begin database::DataControl::instance%41ED2A9502AF.body preserve=yes
   if (pszQualifier && strcmp(pszQualifier,"CUSTQUAL")!= 0)
   {
      string strQualifier(pszQualifier);
      if (!m_pDataControl)
         m_pDataControl = new map<string,DataControl*,less<string> >;
      map<string,DataControl*,less<string> >::iterator p = m_pDataControl->find(strQualifier);
      if (p != m_pDataControl->end())
         return (*p).second;
      DataControl* pDataControl = new DataControl(strQualifier);
      m_pDataControl->insert(map<string,DataControl*,less<string> >::value_type(strQualifier,pDataControl));
      return pDataControl;
   }
   if (!m_pInstance)
      m_pInstance = new DataControl();
   return m_pInstance;
  //## end database::DataControl::instance%41ED2A9502AF.body
}

bool DataControl::replicate (const char* pszENTITY_TYPE, const string& strENTITY_ID, const string& strDATE_RECON, const string& strRole)
{
  //## begin database::DataControl::replicate%41ED297800BB.body preserve=yes
   m_strKey.assign(pszENTITY_TYPE,2);
   m_strKey += strENTITY_ID;
   map<string,vector<ExportFile*>,less<string> >::iterator pPostingFile = m_hPostingFile.find(m_strKey);
   if (pPostingFile != m_hPostingFile.end())
   {
      ExportFile* p = 0;
      for (int i = 0;i < (*pPostingFile).second.size();i++)
      {
         ExportFile* q = (*pPostingFile).second[i];
         if ((p == 0 || (*p) != (*q))
            && q->getDX_STATE() == "PI")
            if (q->replicate(strDATE_RECON,strRole))
               p = q;
      }
   }
   return true;
  //## end database::DataControl::replicate%41ED297800BB.body
}

void DataControl::update (Subject* pSubject)
{
  //## begin database::DataControl::update%41ED2953004E.body preserve=yes
   string strTASK_FORMATTED(Extract::instance()->getName());
   if (pSubject == MidnightAlarm::instance()
      || (pSubject == MinuteTimer::instance()
      && m_bSuccess == false))
   {
      for (int i = 0;i < 4;++i)
         m_bLevel[i] = false;
      for_each(m_hPostingFile.begin(),m_hPostingFile.end(),database::deletePostingFiles);
      m_hPostingFile.erase(m_hPostingFile.begin(),m_hPostingFile.end());
      Query hQuery;
      hQuery.attach(this);
      m_hExportFile.bind(hQuery);
      hQuery.setQualifier(m_strQualifier.c_str(),"DX_DATA_CONTROL");
      m_hExportFile.setSEQ_NO(-1);
      strTASK_FORMATTED.replace(0,2,"__",2);
      if (strTASK_FORMATTED.substr(2,2) == "EI"
         || strTASK_FORMATTED.substr(2,2) == "EB"
         || strTASK_FORMATTED.substr(2,2) == "DF")
         strTASK_FORMATTED="__EMS";
      strTASK_FORMATTED += "%";
      hQuery.setBasicPredicate("DX_DATA_CONTROL","TASK_FORMATTED","LIKE",strTASK_FORMATTED.c_str());
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_STATE","=","PI");
      hQuery.setOrderByClause("ENTITY_TYPE,ENTITY_ID,DX_FILE_TYPE,DX_REPORT_ID,DATE_RECON,SCHED_TIME");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      m_bSuccess = pSelectStatement->execute(hQuery);
      Database::instance()->commit();
      if (pSubject == MidnightAlarm::instance())
         return;
   }
   if (pSubject == MinuteTimer::instance())
   {
      for_each(m_hPostingFile.begin(),m_hPostingFile.end(),database::closePostingFiles);
      return;
   }
   if (m_hExportFile.getNull() == -1)
      m_hExportFile.setDX_REPORT_ID(-1);
   ExportFile* pExportFile = FileFactory::instance()->create(m_hExportFile);
   if (pExportFile)
   {
      if (strTASK_FORMATTED.substr(2,2) == "EI"
         || strTASK_FORMATTED.substr(2,2) == "DF")
         pExportFile->setSEQ_NO(999999999);
      pExportFile->initialize();
      string strKey(pExportFile->getENTITY_TYPE());
      if (strKey == "*G")
         m_bLevel[G] = true;
      else
      if (strKey == "*P")
         m_bLevel[P] = true;
      else
      if (strKey == "*I")
         m_bLevel[I] = true;
      else
      if (strKey == "AM")
         m_bLevel[M] = true;
      strKey += pExportFile->getENTITY_ID();
      map<string,vector<ExportFile*>,less<string> >::iterator pPostingFile = m_hPostingFile.find(strKey);
      if (pPostingFile == m_hPostingFile.end())
      {
         vector<ExportFile*> hExportFiles;
         hExportFiles.push_back(pExportFile);
         m_hPostingFile.insert(map<string,vector<ExportFile*>,less<string> >::value_type(strKey,hExportFiles));
      }
      else
         (*pPostingFile).second.push_back(pExportFile);
   }
  //## end database::DataControl::update%41ED2953004E.body
}

// Additional Declarations
  //## begin database::DataControl%41ED292801E4.declarations preserve=yes
  //## end database::DataControl%41ED292801E4.declarations

} // namespace database

//## begin module%41ED29D10213.epilog preserve=yes
//## end module%41ED29D10213.epilog
