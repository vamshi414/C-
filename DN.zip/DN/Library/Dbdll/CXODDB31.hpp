//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4728ED630003.cm preserve=no
//	$Date:   Sep 26 2016 11:30:30  $ $Author:   e1009674  $ $Revision:   1.3  $
//## end module%4728ED630003.cm

//## begin module%4728ED630003.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4728ED630003.cp

//## Module: CXOSDB31%4728ED630003; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB31.hpp

#ifndef CXOSDB31_h
#define CXOSDB31_h 1

//## begin module%4728ED630003.additionalIncludes preserve=no
//## end module%4728ED630003.additionalIncludes

//## begin module%4728ED630003.includes preserve=yes
#include <map>
#include <set>
//## end module%4728ED630003.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
class MidnightAlarm;

} // namespace timer

//## begin module%4728ED630003.declarations preserve=no
//## end module%4728ED630003.declarations

//## begin module%4728ED630003.additionalDeclarations preserve=yes
//## end module%4728ED630003.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Calendar%4728ECDA02E1.preface preserve=yes
//## end database::Calendar%4728ECDA02E1.preface

//## Class: Calendar%4728ECDA02E1
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4728F25E0197;DatabaseFactory { -> F}
//## Uses: <unnamed>%4728F26001FE;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4728F2620283;timer::Date { -> F}
//## Uses: <unnamed>%53862F4003BC;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%538630D5033D;timer::Clock { -> F}
//## Uses: <unnamed>%538784700146;reusable::Query { -> F}

class DllExport Calendar : public reusable::Observer  //## Inherits: <unnamed>%4728ECF303C3
{
  //## begin database::Calendar%4728ECDA02E1.initialDeclarations preserve=yes
  //## end database::Calendar%4728ECDA02E1.initialDeclarations

  public:
    //## Constructors (generated)
      Calendar();

    //## Destructor (generated)
      virtual ~Calendar();


    //## Other Operations (specified)
      //## Operation: calculateDateFromExcludedInterval%538631B40309
      string calculateDateFromExcludedInterval ();

      //## Operation: doesExist%5385FD9902FE
      bool doesExist (string& strEvent);

      //## Operation: isBusinessDay%538600F90232
      bool isBusinessDay (const timer::Date& hDate);

      //## Operation: isHoliday%4728F1530020
      bool isHoliday (const timer::Date& hDate);

      //## Operation: isWeekday%4728F15F01C2
      bool isWeekday (const timer::Date& hDate);

      //## Operation: loadBusinessDays%5387826801BF
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>TE
      //	 <h2>MS
      //	<h3>Business day and holiday configuration
      //	 <p>
      //	 Business days and holidays are configured within Event
      //	 Management in the CR Client.
      //	 The switch business days of the week are configured as
      //	 an Event Calendar.
      //	 Holidays are defined as an Event Exception.
      //	 In the CR Client, define an Event
      //	 and associate it with an Event Calendar and Event
      //	 Exception. The events can be named:
      //	 <ul>
      //	 <li> <i>ca</i>SETTLE: This is the calendar for
      //	totaling. </li>
      //	 <li> <i>ca</i>EM<i>cust</i>: This is the EMS calendar
      //	associated with the 4 character CUST ID(switch). </li>
      //	 <li> <i>ca</i>EM<i>cur</i>: This is the EMS calendar
      //	associated with the specified 3 char currency code. </li>
      //	</ul>
      //	 The default calendar that will be used for Exception
      //	Processing, Switch (S) or Currency (C),
      //	can be specified as the 'Default EMS Calendar' for the
      //	Customer using the CR Editor.
      //	 <p>
      //	 If you provide one entry as 'E:Everyday' in the Event
      //	  Calendar, settlement is done each and every day.
      //	 Any holidays in the Event Exception are avoided when
      //	 generating the effective date in ACH files.
      //	 Saturday and Sunday dates are also avoided when
      //	  producing ACH files (i.e. ACH files produced on
      //	 Saturday, Sunday and Monday all have Monday as the
      //	 effective date).
      //	 <p>
      //	  If you enter individual days in the Event Calendar,
      //	  settlement is not done on any unspecified days or
      //	 holidays.
      //	  If you enter all 7 days of the week, settlement is only
      //	  avoided on any designated holidays.
      //	 Similarly, business days and holidays are taken into
      //	account
      //	 when calculations are being made for exception
      //	processing.
      //	Specification of individual days is typically used to
      //	 configure 5 day business days:
      //	 <p>
      //	 <table>
      //	 <tr>
      //	 <th>Event ID
      //	  <th>Event Day
      //	  <th>Event Time
      //	  <tr>
      //	  <td>&caSETTLE
      //	  <td>1 (Monday)
      //	  <td>180000
      //	  <tr>
      //	  <td>&caSETTLE
      //	  <td>2 (Tuesday)
      //	  <td>180000
      //	  <tr>
      //	  <td>&caSETTLE
      //	   <td>3 (Wednesday)
      //	   <td>180000
      //	   <tr>
      //	   <td>&caSETTLE
      //	   <td>4 (Thursday)
      //	  <td>180000
      //	  <tr>
      //	  <td>&caSETTLE
      //	  <td>5 (Friday)
      //	  <td>180000
      //	  </table>
      //	  <p>
      //	   An example 7 day settlement would be:
      //	  <p>
      //	  <table>
      //	  <tr>
      //	  <th>Event ID
      //	  <th>Event Day
      //	  <th>Event Time
      //	  <tr>
      //	  <td>&caSETTLE
      //	  <td>E (Everyday)
      //	  <td>180000
      //	  </table>
      //	  <p>
      //	  The holidays are configured as Event Exceptions.
      //	  Sample holidays would be:
      //	  <p>
      //	  <table>
      //	  <tr>
      //	  <th>Event ID
      //	  <th>Event Exception ID
      //	  <th>Exception Date
      //	  <th>Exception Time
      //	   <tr>
      //	   <td>&caSETTLE
      //	   <td>&caHOLIDY
      //	   <td>20120101 (New Year's Day)
      //	   <td>00000000 (not used)
      //	   <tr>
      //	   <td>&caSETTLE
      //	   <td>&caHOLIDY
      //	   <td>20120704 (Fourth of July)
      //	   <td>00000000 (not used)
      //	   <tr>
      //	  <td>&caSETTLE
      //	  <td>&caHOLIDY
      //	  <td>20121225 (Christmas)
      //	  <td>00000000 (not used)
      //	  </table>
      //	  <p>
      //	  For EMS calendars, recurring holidays can also be
      //	specified with the as follows:
      //	 <table>
      //	  <tr>
      //	  <th>Event ID
      //	  <th>Event Exception ID
      //	  <th>Exception Date
      //	 <th>Exception Time
      //	  <tr>
      //	  <td>&caEMcust
      //	 <td>&caHOLIDY
      //	  <td>99990704 (Fourth of July every year)
      //	  <td>00000000 (not used)
      //	  <tr>
      //	  <td>&caEMcur
      //	  <td>&caHOLIDY
      //	  <td>99991225 (Christmas every year)
      //	  <td>00000000 (not used)
      //	  </table>
      //	  <p>
      //	  For EMS Calendars, there is also an opportunity to
      //	provide specific days and intervals
      //	 that need to be excluded that are not specific dates.
      //	In the CR client, you would have to create repeating
      //	event exceptions that can be associated with an event.
      //	Some examples of the repeating event exceptions are:
      //	 <table>
      //	  <tr>
      //	 <th>Event ID
      //	  <th>Repeating Event Exception ID
      //	  <th>Day of the Week
      //	  <th>Week No
      //	  <th>Month No
      //	  <th>Comment
      //	  <tr>
      //	  <td>&caEMcust
      //	  <td>&caRHLDAY
      //	   <td>1 (Monday)
      //	   <td>1 (First Week)
      //	   <td>09 (September)
      //	  <td>Labor Day: First Monday of September
      //	  <tr>
      //	  <td>&caEMcur
      //	  <td>&caRHLDAY
      //	   <td>4 (Thursday)
      //	   <td>9 (last week of the month)
      //	    <td>11 (November)
      //	   <td>Thanksgiving Day: Last Thursday of November
      //	   <tr>
      //	   </table>
      //	   </body>
      bool loadBusinessDays (const string& strEvent);

      //## Operation: loadHolidays%4728F5980195
      bool loadHolidays (const string& strEvent);

      //## Operation: setCalendar%53878B6300A1
      void setCalendar (const string& strEvent);

      //## Operation: update%4728F10D0214
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: XDAY%5386315800AE
      void setXDAY (const string& value)
      {
        //## begin database::Calendar::setXDAY%5386315800AE.set preserve=no
        m_strXDAY = value;
        //## end database::Calendar::setXDAY%5386315800AE.set
      }


      //## Attribute: XMONTH%5386316B0256
      void setXMONTH (const string& value)
      {
        //## begin database::Calendar::setXMONTH%5386316B0256.set preserve=no
        m_strXMONTH = value;
        //## end database::Calendar::setXMONTH%5386316B0256.set
      }


      //## Attribute: XWEEK%5386316101A6
      void setXWEEK (const string& value)
      {
        //## begin database::Calendar::setXWEEK%5386316101A6.set preserve=no
        m_strXWEEK = value;
        //## end database::Calendar::setXWEEK%5386316101A6.set
      }


      //## Attribute: Year%5384FE84018E
      void setYear (const string& value)
      {
        //## begin database::Calendar::setYear%5384FE84018E.set preserve=no
        m_strYear = value;
        //## end database::Calendar::setYear%5384FE84018E.set
      }


    // Additional Public Declarations
      //## begin database::Calendar%4728ECDA02E1.public preserve=yes
      //## end database::Calendar%4728ECDA02E1.public

  protected:
    // Additional Protected Declarations
      //## begin database::Calendar%4728ECDA02E1.protected preserve=yes
      //## end database::Calendar%4728ECDA02E1.protected

  private:
    // Additional Private Declarations
      //## begin database::Calendar%4728ECDA02E1.private preserve=yes
      //## end database::Calendar%4728ECDA02E1.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BusinessDays%5385F5260097
      //## begin database::Calendar::BusinessDays%5385F5260097.attr preserve=no  private: map <string, set<string>, less<string> > {U} 
      map <string, set<string>, less<string> > m_hBusinessDays;
      //## end database::Calendar::BusinessDays%5385F5260097.attr

      //## Attribute: BusinessDaysItr%5385F542025F
      //## begin database::Calendar::BusinessDaysItr%5385F542025F.attr preserve=no  private: map <string, set<string>, less<string>>::iterator {U} 
      map <string, set<string>, less<string> >::iterator m_pBusinessDaysItr;
      //## end database::Calendar::BusinessDaysItr%5385F542025F.attr

      //## Attribute: Holidays%4728F0E3007A
      //## begin database::Calendar::Holidays%4728F0E3007A.attr preserve=no  private: map <string, set<string>, less<string> > {U} 
      map <string, set<string>, less<string> > m_hHolidays;
      //## end database::Calendar::Holidays%4728F0E3007A.attr

      //## Attribute: HolidaysItr%5384FF8603AC
      //## begin database::Calendar::HolidaysItr%5384FF8603AC.attr preserve=no  private: map <string, set<string>, less<string>>::iterator {U} 
      map <string, set<string>, less<string> >::iterator m_pHolidaysItr;
      //## end database::Calendar::HolidaysItr%5384FF8603AC.attr

      //## Attribute: EVNTDAY%538788840285
      //## begin database::Calendar::EVNTDAY%538788840285.attr preserve=no  private: string {V} 
      string m_strEVNTDAY;
      //## end database::Calendar::EVNTDAY%538788840285.attr

      //## Attribute: XDATE%4728F7AA02FF
      //## begin database::Calendar::XDATE%4728F7AA02FF.attr preserve=no  private: string {V} 
      string m_strXDATE;
      //## end database::Calendar::XDATE%4728F7AA02FF.attr

      //## begin database::Calendar::XDAY%5386315800AE.attr preserve=no  public: string {V} 
      string m_strXDAY;
      //## end database::Calendar::XDAY%5386315800AE.attr

      //## begin database::Calendar::XMONTH%5386316B0256.attr preserve=no  public: string {V} 
      string m_strXMONTH;
      //## end database::Calendar::XMONTH%5386316B0256.attr

      //## begin database::Calendar::XWEEK%5386316101A6.attr preserve=no  public: string {V} 
      string m_strXWEEK;
      //## end database::Calendar::XWEEK%5386316101A6.attr

      //## begin database::Calendar::Year%5384FE84018E.attr preserve=no  public: string {U} 
      string m_strYear;
      //## end database::Calendar::Year%5384FE84018E.attr

    // Additional Implementation Declarations
      //## begin database::Calendar%4728ECDA02E1.implementation preserve=yes
      //## end database::Calendar%4728ECDA02E1.implementation

};

//## begin database::Calendar%4728ECDA02E1.postscript preserve=yes
//## end database::Calendar%4728ECDA02E1.postscript

} // namespace database

//## begin module%4728ED630003.epilog preserve=yes
//## end module%4728ED630003.epilog


#endif
