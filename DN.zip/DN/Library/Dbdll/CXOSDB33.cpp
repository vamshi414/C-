//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4982289F011C.cm preserve=no
//	$Date:   Jun 09 2021 08:56:50  $ $Author:   e1009652  $ $Revision:   1.57  $
//## end module%4982289F011C.cm

//## begin module%4982289F011C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4982289F011C.cp

//## Module: CXOSDB33%4982289F011C; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5C.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB33.cpp

//## begin module%4982289F011C.additionalIncludes preserve=no
//## end module%4982289F011C.additionalIncludes

//## begin module%4982289F011C.includes preserve=yes
#define STS_RECORD_NOT_FOUND 14
#include <algorithm>
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#ifndef CXOSRU48_h
#include "CXODRU48.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSDB70_h
#include "CXODDB70.hpp"
#endif
//## end module%4982289F011C.includes

#ifndef CXOSDB34_h
#include "CXODDB34.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU41_h
#include "CXODRU41.hpp"
#endif
#ifndef CXOSIF42_h
#include "CXODIF42.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSDB38_h
#include "CXODDB38.hpp"
#endif
#ifndef CXOSDB37_h
#include "CXODDB37.hpp"
#endif
#ifndef CXOSDB39_h
#include "CXODDB39.hpp"
#endif
#ifndef CXOSRU37_h
#include "CXODRU37.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSRU39_h
#include "CXODRU39.hpp"
#endif
#ifndef CXOSDB43_h
#include "CXODDB43.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSDB33_h
#include "CXODDB33.hpp"
#endif


//## begin module%4982289F011C.declarations preserve=no
//## end module%4982289F011C.declarations

//## begin module%4982289F011C.additionalDeclarations preserve=yes
//static int m_arraySEQ_NO[25] = {13,15,17,1,4,3,9,18,12,11,21,2,10,5,19,8,6,14,20,7,16,22,23,24};
//## end module%4982289F011C.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::AESKeyRing 

AESKeyRing::AESKeyRing()
  //## begin AESKeyRing::AESKeyRing%4982285D018F_const.hasinit preserve=no
      : m_iOffset(0)
  //## end AESKeyRing::AESKeyRing%4982285D018F_const.hasinit
  //## begin AESKeyRing::AESKeyRing%4982285D018F_const.initialization preserve=yes
  //## end AESKeyRing::AESKeyRing%4982285D018F_const.initialization
{
  //## begin database::AESKeyRing::AESKeyRing%4982285D018F_const.body preserve=yes
   memcpy_s(m_sID,4,"DB33",4);
   MidnightAlarm::instance()->attach(this);
  //## end database::AESKeyRing::AESKeyRing%4982285D018F_const.body
}


AESKeyRing::~AESKeyRing()
{
  //## begin database::AESKeyRing::~AESKeyRing%4982285D018F_dest.body preserve=yes
   MidnightAlarm::instance()->detach(this);
  //## end database::AESKeyRing::~AESKeyRing%4982285D018F_dest.body
}



//## Other Operations (implementation)
bool AESKeyRing::bind (reusable::Query& hQuery)
{
  //## begin database::AESKeyRing::bind%560407960177.body preserve=yes
   int lCount = 0;
   Query hQuery1;
   hQuery1.bind("TASK_CONTEXT","*",reusable::Column::LONG,&lCount,0,"COUNT");
   hQuery1.setBasicPredicate("TASK_CONTEXT","IMAGEID","=","*");
   hQuery1.setBasicPredicate("TASK_CONTEXT","TASKID","=","*");
   hQuery1.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","K");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery1))
      return false;
   if(lCount == 0)
   {
      hQuery.setQualifier("QUALIFY","TASK_CONTEXT_COMN");
      hQuery.bind("TASK_CONTEXT_COMN","CONTEXT_KEY",Column::STRING,&m_strCONTEXT_KEY);
      hQuery.bind("TASK_CONTEXT_COMN","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA);
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN","IMAGE_ID","=","*");
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN","TASK_ID","=","*");
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN","CONTEXT_TYPE","=","K");
   }
   else
   {
      hQuery.bind("TASK_CONTEXT","CONTEXT_KEY",Column::STRING,&m_strCONTEXT_KEY);
      hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA);
      hQuery.setBasicPredicate("TASK_CONTEXT","IMAGEID","=","*");
      hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=","*");
      hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","K");
   }
   return true;
  //## end database::AESKeyRing::bind%560407960177.body
}

bool AESKeyRing::decrypt (const string& strYYYYMM,string& strText)
{
  //## begin database::AESKeyRing::decrypt%4983A3D50071.body preserve=yes
   Key* pKey = getKey(strYYYYMM);
   if (!pKey)
      return false;
   return pKey->decrypt(strText);
  //## end database::AESKeyRing::decrypt%4983A3D50071.body
}

void AESKeyRing::detokenize (string& strPAN)
{
  //## begin database::AESKeyRing::detokenize%49DE352902A7.body preserve=yes
   if (strPAN.length() > 28)
      return;
   char szTemp[28];
   memcpy_s(szTemp,sizeof(szTemp),strPAN.data(),strPAN.length());
   detokenize(szTemp,strPAN.length());
   strPAN.assign(szTemp,strPAN.length());
   if (PenkoToken::instance()->ISTwantsToken())
      PenkoToken::instance()->tokenize(strPAN, "000000", 1);
  //## end database::AESKeyRing::detokenize%49DE352902A7.body
}

void AESKeyRing::detokenize (char* psPAN,int iPanLength)
{
  //## begin database::AESKeyRing::detokenize%49DE352902A9.body preserve=yes
   if (!getActive())
      return;
   if (!getInitialized())
      return;
   if (iPanLength > 28 || iPanLength < 9)
      return;
   int i = 0;
   for (i = 0; i < iPanLength; i++)
   {  //check for real length
      if (psPAN[i] == '\0' || psPAN[i] == ' ')
         break;
      if (psPAN[i] >= '0' && psPAN[i] <= '9')
         return;
   }
   iPanLength = i;
   if (iPanLength < 9)
      return;
   char szPAN[31];
   memcpy_s(szPAN,sizeof(szPAN),psPAN,iPanLength);
   int iOffset = 0;
   string strToken;
   //map<string,int,less<string> >::iterator q;
   while (iPanLength > 0)
   {
      int iLen = (iPanLength > 4 ? 4 : iPanLength);
      strToken.assign(psPAN+iOffset,iLen);
      while (strToken.length() % 4 != 0)
         strToken.append(" ");
      int k = findToken(strToken);
      if (k < 0)
         return;
      if (k >= 11100)
         snprintf(szPAN+iOffset,sizeof(szPAN)-iOffset,"%d",(k-11100));
      else if (k >= 11000)
         snprintf(szPAN+iOffset,sizeof(szPAN) - iOffset,"%02d",(k-11000));
      else if (k >= 10000)
         snprintf(szPAN+iOffset,sizeof(szPAN) - iOffset,"%03d",(k-10000));
      else
         snprintf(szPAN+iOffset,sizeof(szPAN) - iOffset,"%04d",k);
      iPanLength-=4;
      iOffset+=iLen;
   }
   iPanLength = iOffset;
   switch (m_iShuffleScheme)
   {
      case 1:
         memcpy_s(psPAN,3,szPAN+iPanLength-6,3);
         memcpy_s(psPAN+3,iPanLength - 9,szPAN+3,iPanLength-9);
         memcpy_s(psPAN+3+iPanLength-9,3,szPAN+iPanLength-3,3);
         memcpy_s(psPAN+iPanLength-3,3,szPAN,3);
         break;
      case 2 :
         if (iPanLength >= 16)
         {
            memcpy_s(psPAN,1,szPAN+3,1);
            memcpy_s(psPAN+1,1,szPAN+5,1);
            memcpy_s(psPAN+2,1,szPAN+7,1);
            memcpy_s(psPAN+3,1,szPAN+9,1);
            memcpy_s(psPAN+4,1,szPAN+11,1);
            memcpy_s(psPAN+5,1,szPAN+13,1);
            memcpy_s(psPAN+6,1,szPAN+4,1);
            memcpy_s(psPAN+7,1,szPAN+6,1);
            memcpy_s(psPAN+8,1,szPAN+8,1);
            memcpy_s(psPAN+9,1,szPAN+10,1);
            memcpy_s(psPAN+10,1,szPAN+12,1);
            memcpy_s(psPAN+11,iPanLength - 14,szPAN+14,iPanLength-14);
            memcpy_s(psPAN+iPanLength-3,3,szPAN,3);
         }
         else 
         {
            memcpy_s(psPAN,3,szPAN+iPanLength-6,3);
            memcpy_s(psPAN+3,iPanLength - 9,szPAN+3,iPanLength-9);
            memcpy_s(psPAN+3+iPanLength-9,3,szPAN+iPanLength-3,3);
            memcpy_s(psPAN+iPanLength-3,3,szPAN,3);
         }
         break;
      default:
         memcpy_s(psPAN,iPanLength,szPAN,iPanLength);
         break;
   }
  //## end database::AESKeyRing::detokenize%49DE352902A9.body
}

bool AESKeyRing::encrypt (const string& strYYYYMM,string& strText)
{
  //## begin database::AESKeyRing::encrypt%4983A3D50073.body preserve=yes
   Key* pKey = getKey(strYYYYMM);
   if (!pKey)
      return false;
   return pKey->encrypt(strText);
  //## end database::AESKeyRing::encrypt%4983A3D50073.body
}

int AESKeyRing::exists ()
{
  //## begin database::AESKeyRing::exists%50105FA5025E.body preserve=yes
   //determine if tokenization is activated
   int lCount = 0;
   Query hQuery;
   hQuery.setQualifier("QUALIFY","DN_SYMBOLS");
   hQuery.bind("DN_SYMBOLS","*",Column::LONG,&lCount,0,"COUNT");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if(!pSelectStatement->execute(hQuery))
      return -1;
   if(lCount > 0)
      return 1;
   //check if tokens are included in the most recent backup
   string strDATE_RECON;
   string strTSTAMP_INITIATED;
   int iDX_FILE_ID = 0;
   hQuery.reset(); 
   hQuery.setSubSelect(true); 
   hQuery.bind("DX_DATA_CONTROL","TSTAMP_INITIATED",Column::STRING,&strTSTAMP_INITIATED,0,"MAX");
   hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","=","BACKUP");
   auto_ptr<reusable::FormatSelectVisitor>pFormatSelectVisitor
      ((reusable::FormatSelectVisitor*)database::DatabaseFactory::instance()->create("FormatSelectVisitor"));
   hQuery.accept(*pFormatSelectVisitor);
   string strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ") ";
   hQuery.reset();
   hQuery.setSubSelect(false);
   hQuery.bind("DX_DATA_CONTROL","DX_FILE_ID",Column::LONG,&iDX_FILE_ID);
   hQuery.bind("DX_DATA_CONTROL","DATE_RECON",Column::STRING,&strDATE_RECON);
   hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","=","BACKUP");
   hQuery.setBasicPredicate("DX_DATA_CONTROL","TSTAMP_INITIATED","IN",strSubSelect.c_str());
   if(!pSelectStatement->execute(hQuery))
      return -1;
   if(iDX_FILE_ID == 0 || strDATE_RECON.length() == 0)
      return  0;
   lCount = 0;
   hQuery.reset();
   string strTableName("DX_DATA_");
   strTableName.append(strDATE_RECON);
   hQuery.bind(strTableName.c_str(),"*",Column::LONG,&lCount,0,"COUNT");
   hQuery.setBasicPredicate(strTableName.c_str(),"DX_FILE_ID","=",iDX_FILE_ID);
   hQuery.setBasicPredicate(strTableName.c_str(),"DATA_BUFFER","LIKE","000000__:%");
   if(!pSelectStatement->execute(hQuery))
      return -1;
   if(lCount > 0)
      return 1;
   return 0;
  //## end database::AESKeyRing::exists%50105FA5025E.body
}

int AESKeyRing::findToken (const string& strToken)
{
  //## begin database::AESKeyRing::findToken%49F9F48001F7.body preserve=yes
   int iHigh = 11136;
   int iLow = 0;
   int iMiddle = 11136/2;
   while (true)
   {
      int iC = memcmp((char*)m_arrayTokens[m_arrayTokenOrder[iMiddle]],strToken.data(),4);
      if (iC == 0)
         break;
      if (iLow == iHigh || iMiddle > iHigh || iMiddle < iLow)
         return -1;  //prevent infinite loop on bad input
      if (iC < 0)
         iLow = iMiddle+1;
      else
         iHigh = iMiddle-1;
      iMiddle = iLow + (iHigh - iLow)/2;
   }
   return m_arrayTokenOrder[iMiddle];
  //## end database::AESKeyRing::findToken%49F9F48001F7.body
}

Key* AESKeyRing::getTransportKey (const string& strKeyId)
{
  //## begin database::AESKeyRing::getTransportKey%4AF1A5D4006F.body preserve=yes
   Key* pKey = getKey(strKeyId);
   if (pKey)
      return pKey;
   if (strKeyId.length() <6 || strKeyId.substr(0,2) != "TK")
      return 0;

   //build transport key from key parts
   string strKP1("P");
   strKP1.append(strKeyId.substr(2,4));
   strKP1.append("1");
   Key* pKey1 = getKey(strKP1);
   if (!pKey1)
      return 0;
   string strKP2(strKP1);
   strKP2.replace(5,1,"2");
   Key* pKey2 = getKey(strKP2);
   if (!pKey2)
      return 0;
   string strKP3(strKP2);
   strKP3.replace(5,1,"3");
   Key* pKey3 = getKey(strKP3);
   if (!pKey3)
   {  //allow 2 part keys (used to require 3 parts)
      pKey3 = new Key;
      char szNull[32];
      memset(szNull,'\0',32);
      pKey3->setRawKey(szNull,32);
   }
   unsigned char szTPKey[32];
   for (int i = 0; i < 32; i++)
   {
      szTPKey[i] = pKey1->getRawKey()[i] ^ pKey2->getRawKey()[i] ^ pKey3->getRawKey()[i];
   }
   AESKey* pTransportKey = new AESKey;
   pTransportKey->setType(Key::AES256_3);
   pTransportKey->setStrength(256);
   pTransportKey->setRawKey((char*)szTPKey,32);
   pTransportKey->computeCheckDigits();
   if (pTransportKey->getCheckDigits() != strKeyId.substr(2,4))
      return 0;
   //add transport key to ring and return results
   addKey(strKeyId,pTransportKey);
   return getKey(strKeyId);
  //## end database::AESKeyRing::getTransportKey%4AF1A5D4006F.body
}

bool AESKeyRing::isPrimary ()
{
  //## begin database::AESKeyRing::isPrimary%5604318801BD.body preserve=yes
   if(m_iPrimary == -1)
   {
      string strCustId;
      Extract::instance()->getSpec("CUSTOMER",strCustId);
      string strCUST_ID;
      Query hQuery;
      hQuery.setQualifier("QUALIFY","STS_CUSTOMER");
      hQuery.bind("STS_CUSTOMER","CUST_ID",reusable::Column::STRING,&strCUST_ID,0,"MIN");
      hQuery.setBasicPredicate("STS_CUSTOMER","CC_STATE","=","A");
      hQuery.setBasicPredicate("STS_CUSTOMER","CC_CHANGE_GRP_ID","IS NULL");
      hQuery.setBasicPredicate("STS_CUSTOMER","CUST_ID","<>","****");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if(!pSelectStatement->execute(hQuery))
      {
         IF::Trace::put("Warning,AESKeyRing::isPrimary() - unable to query STS_CUSTOMER table",-1,true);
         return false;
      }
      if(strCustId == strCUST_ID)
         m_iPrimary = 1;
      else
         m_iPrimary = 0;
   }
   return KeyRing::isPrimary();
  //## end database::AESKeyRing::isPrimary%5604318801BD.body
}

bool AESKeyRing::load ()
{
  //## begin database::AESKeyRing::load%4FF5E01602BD.body preserve=yes
   //exclude XT,CRQ and other common tasks
   string strTemp;
   if (!Extract::instance()->getSpec("CUSTQUAL",strTemp))
      return true;
   int iExist = exists();
   if(iExist < 0)
      return false; //DB errors
   if(iExist == 0)
   {  //tokenization is not turned on
      Mask::setTokensExist(false);
      setActive(false);
      //load DES keys if they exist
      if(!resetKeys()) 
         return false;
      setInitialized(true);
   }
   else
   {
      Mask::setTokensExist(true);
      setActive(true);
      if(!reset())
         return false;
   }
   m_bIST = false;
   int i = 0;
   string strRecord;
   while (Extract::instance()->getRecord(i++, strRecord))
   {
      strRecord.resize(32, ' ');
      if (strRecord.substr(0, 8) == "DQUEUE  " && strRecord.substr(24, 6) == "CXOPOI")
      {
         m_bIST = true;
         break;
      }
   }
   SecurityWrapper::initializeRNG();
   return true;
  //## end database::AESKeyRing::load%4FF5E01602BD.body
}

bool AESKeyRing::loadTokens ()
{
  //## begin database::AESKeyRing::loadTokens%49DE36940078.body preserve=yes
   int iTokensExist = exists();
   if (iTokensExist == 0)
   {  //tokenization is not turned on
      Mask::setTokensExist(false);
      setActive(false);
      return true;
   }
   else if (iTokensExist == -1)
      return false; //database read failure
   //tokens exist - proceed to load them
   memset(m_arrayTokens,'9',11136*4); //mark array so we can test if loaded
   m_strTokenControl.erase();
   m_iOffset = 0;
   {
      Query hQuery;
      hQuery.setIndex(3);
      hQuery.attach(this);
      hQuery.setQualifier("QUALIFY","DN_SYMBOLS");
      hQuery.bind("DN_SYMBOLS","DN_SYMBOL",Column::STRING,&m_strTOKEN);
      hQuery.bind("DN_SYMBOLS","SYMBOL_ID",Column::STRING,&m_strDATE);
      hQuery.bind("DN_SYMBOLS","SEQ_NO",Column::LONG,&m_iSEQ_NO);
      hQuery.setBasicPredicate("DN_SYMBOLS","SEQ_NO","BETWEEN"," 1 AND 25 ");
      hQuery.setOrderByClause("SEQ_NO ASC");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery) || pSelectStatement->getRows() != 25)
      {
         Trace::put("Warning! Tokens failed to load 1",-1,true);
         return false;
      }
   }
   return validateTokens();
  //## end database::AESKeyRing::loadTokens%49DE36940078.body
}

bool AESKeyRing::mask (int& iBufferLength,char* pBuffer,int iOffset,int iLength,int iNPI)
{
  //## begin database::AESKeyRing::mask%49822E66019B.body preserve=yes
   // new
   // |<--2--->|<--- 4 ---->|<---- 4 --->|<-5->|
   // |NPI type|Token Offset|Token Length|?@#^!|
   // old
   // |<--- 4 ---->|<---- 4 --->|<-4->|
   // |Token Offset|Token Length|@#^! |
   if (!getActive())
      return true;
   if (!getInitialized())
      return false;
   if (iBufferLength < iOffset+iLength)
      return false;
   Date hDate(Date::today());
   if (getStartDate() <= hDate.asString("%Y%m") &&
      hDate.asString("%Y%m") <= getEndDate())
   {
      int iCursor = iBufferLength;
      char szMask[6] = {"?@#^!"};
      szMask[3] = 0xAC;
      while (iCursor - 15 > 0
         && (memcmp(pBuffer + iCursor - 5,"?@#^!",5) == 0
         || memcmp(pBuffer + iCursor - 5,szMask,5) == 0))
      {//if not 1st mask on this buffer then may need to adjust iOffset
         int iNPI2 =  atoi(string(pBuffer+iCursor-15,2).c_str());
         if(!NPI::instance(iNPI2)->isFormatPreserved())
         {
            int iProtectedLength = atoi(string(pBuffer+iCursor-9,4).c_str());
            int iProtectedOffset = atoi(string(pBuffer+iCursor-13,4).c_str());
            string strOriginalValue(pBuffer+iProtectedOffset,iProtectedLength);
            NPI::instance(iNPI2)->unprotect(strOriginalValue);
            iOffset += iProtectedLength - strOriginalValue.length();
         }
         iCursor -= 15;
      }
      char* pTemp = pBuffer+iOffset;
      int iSaveLen = iLength;
      if(!NPI::instance(iNPI)->isFormatPreserved())
      {
         pTemp = new char[NPI::instance(iNPI)->protectSize(iLength) + 1];
         memcpy_s(pTemp,iLength,pBuffer+iOffset,iLength);
      }
      NPI::instance(iNPI)->protect(pTemp,iLength);
      if(iLength > iSaveLen)
      {  //shift data after NPI field to allow for extra size of protected data
         int iShift = iLength-iSaveLen;
         for(int i = 1; i <= (pBuffer+iBufferLength) - (pBuffer+iOffset+iSaveLen); i++)
            pBuffer[iBufferLength+iShift-i] = pBuffer[iBufferLength-i];
         iBufferLength += iShift;
         memcpy_s(pBuffer+iOffset,iLength,pTemp,iLength);
         delete [] pTemp;
      }
      iBufferLength+= snprintf(pBuffer+iBufferLength,16,"%02d%04d%04d?@#^!",
         iNPI,               //NPI type
         iOffset,            //token offset
         iLength);            //token length
   }
   return true;
  //## end database::AESKeyRing::mask%49822E66019B.body
}

bool AESKeyRing::recoverFromBackups ()
{
  //## begin database::AESKeyRing::recoverFromBackups%5012AD6401F6.body preserve=yes
   KeyRing::reset();
   m_hBackups.erase(m_hBackups.begin(),m_hBackups.end());
   Query hQuery(4);
   hQuery.attach(this);
   hQuery.bind("DX_DATA_CONTROL","DATE_RECON",Column::STRING,&m_strDATE_RECON);
   hQuery.bind("DX_DATA_CONTROL","DX_FILE_ID",Column::LONG,&m_iDX_FILE_ID);
   hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","=","BACKUP");
   hQuery.setOrderByClause("DATE_RECON DESC,TSTAMP_INITIATED  DESC"); 
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if(!pSelectStatement->execute(hQuery) || pSelectStatement->getRows() == 0)
      return false;
   vector<pair<int,string> >::iterator q;
   for (q = m_hBackups.begin();q != m_hBackups.end();++q)
   {
      m_iOffset = 0;
      m_hKeysDATA_BUFFER.erase(m_hKeysDATA_BUFFER.begin(),m_hKeysDATA_BUFFER.end());
      m_hTokensDATA_BUFFER.erase(m_hTokensDATA_BUFFER.begin(),m_hTokensDATA_BUFFER.end());
      m_strTokenControl.erase();
      hQuery.reset();
      hQuery.setIndex(5);
      hQuery.attach(this);
      string strTable("DX_DATA_");
      strTable.append((*q).second);
      hQuery.bind(strTable.c_str(),"DATA_BUFFER",Column::STRING,&m_strDATA_BUFFER);
      hQuery.setBasicPredicate(strTable.c_str(),"DX_FILE_ID","=",(*q).first);
      hQuery.setOrderByClause("SEQ_NO ASC");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if(!pSelectStatement->execute(hQuery))
         return false;
      if(pSelectStatement->getRows() == 0 || pSelectStatement->getRows() < 27 )
         continue;
      vector<string>::iterator p;
      for(int i = 1; i < 3; i++)
      {  //recover keys
         for (p = m_hKeysDATA_BUFFER.begin();p != m_hKeysDATA_BUFFER.end();++p)
         {
            if((*p).length() < 96)
            {
               if((*p).length() >= 38 )
               {
                  if((*p).substr(0,21) == "DEFAULT_TRANSPORT_KEY")
                     setDefaultTransportKey((*p).substr(32,6));
                  else
                  if((*p).substr(0,16) == "DEFAULT_DATA_KEY")
                     setDefaultDataKey((*p).substr(32,6));
                  else
                  if((*p).substr(0,20) == "DEFAULT_AES_DATA_KEY")
                     setDefaultAESDataKey((*p).substr(32,6));
               }
               continue;
            }
            m_strCONTEXT_KEY.assign((*p).substr(0,32));
            m_strCONTEXT_DATA.assign((*p).substr(32));
            Query hQuery2(i);
            update(&hQuery2);
            if(i == 1 && getKey("Master"))
               break;
         }
      }
      for (p = m_hTokensDATA_BUFFER.begin();p != m_hTokensDATA_BUFFER.end();++p)
      {  //recover tokens
         m_iSEQ_NO = atoi((*p).substr(0,8).c_str());
         m_strDATE.assign((*p).substr(9,6));
         m_strTOKEN.assign((*p).substr(16));
         Query hQuery2(3);
         update(&hQuery2);
      }
      if(!validateTokens())
         continue;
      setInitializedFromBackups(true);
      char szMsg[80];
      Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"AESKeyRing - Keys and Tokens recovered from BACKUP file %s:%d",
         (*q).second.c_str(),(*q).first),true);      
      return true;
   }
   return false;
  //## end database::AESKeyRing::recoverFromBackups%5012AD6401F6.body
}

void AESKeyRing::refreshKeys ()
{
  //## begin database::AESKeyRing::refreshKeys%50105AD901C0.body preserve=yes
   AESKeyRing hAESKeyRing;
   if(!hAESKeyRing.resetKeys())
      return;
   map<string,Key*,less<string> >* pKeys = hAESKeyRing.getKeys();
   map<string,Key*,less<string> >::iterator q;
   for(q = pKeys->begin(); q != pKeys->end(); q++)
   {  //add any keys we are missing
      if(!getKey((*q).second->getIdentifier()))
      {
         if((*q).second->getType() == Key::DES)
         {  //copy key to new key
            const DESKey* pKey = (const DESKey*)((*q).second);
            DESKey* pDESKey = new DESKey(*pKey);
            addKey(pKey->getIdentifier(),pDESKey);
         }
         else
         {  //copy key to new key
            const AESKey* pKey = (const AESKey*)((*q).second);
            AESKey* pAESKey = new AESKey(*pKey);
            addKey(pKey->getIdentifier(),pAESKey);
         }
      }
   }
   if(hAESKeyRing.getDefaultDataKey().length() > 0)
      setDefaultDataKey(hAESKeyRing.getDefaultDataKey());
   if(hAESKeyRing.getDefaultTransportKey().length() > 0)
      setDefaultTransportKey(hAESKeyRing.getDefaultTransportKey());
   if(hAESKeyRing.getDefaultAESDataKey().length() > 0)
      setDefaultAESDataKey(hAESKeyRing.getDefaultAESDataKey());
  //## end database::AESKeyRing::refreshKeys%50105AD901C0.body
}

bool AESKeyRing::repairKeys ()
{
  //## begin database::AESKeyRing::repairKeys%5012D2350288.body preserve=yes
   vector<string>::iterator p;
   for (p = m_hKeysDATA_BUFFER.begin();p != m_hKeysDATA_BUFFER.end();++p)
   {
      Table hTable;
      if(!setColumns(hTable))
         return false;
      hTable.set("CONTEXT_KEY",(*p).substr(0,32),false,true);
      hTable.set("CONTEXT_DATA",(*p).substr(32,(*p).length()-32));
      auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      if(!pUpdateStatement->execute(hTable))
      {
         if(pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
         {
            auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
            if(pInsertStatement->execute(hTable))
               continue;
         }
         return false;
      }
   }
   return true;
  //## end database::AESKeyRing::repairKeys%5012D2350288.body
}

bool AESKeyRing::repairTokens ()
{
  //## begin database::AESKeyRing::repairTokens%5012D24A01B0.body preserve=yes
   vector<string>::iterator p;
   for (p = m_hTokensDATA_BUFFER.begin();p != m_hTokensDATA_BUFFER.end();++p)
   {
      int iSEQ_NO = atoi((*p).substr(0,8).c_str());
      string strDATE((*p).substr(9,6));
      string strTOKEN((*p).substr(16));
      Table hTable("DN_SYMBOLS");
      hTable.setQualifier("QUALIFY");
      hTable.set("SEQ_NO",iSEQ_NO,true);
      hTable.set("DN_SYMBOL",strTOKEN);
      hTable.set("SYMBOL_ID",strDATE);
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      if(!pUpdateStatement->execute(hTable))
      {
         if(pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
         {
            auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
            if(pInsertStatement->execute(hTable))
               continue;
         }
         return false;
      }
   }
   return true;
  //## end database::AESKeyRing::repairTokens%5012D24A01B0.body
}

bool AESKeyRing::reset ()
{
  //## begin database::AESKeyRing::reset%4983A3C702D4.body preserve=yes
   //note: this method only called if tokenization is active: getActive(true)
   //exclude XT,CRQ and other common tasks
   string strTemp;
   if (!Extract::instance()->getSpec("CUSTQUAL",strTemp))
      return true; 
   setInitialized(false);
   if (!resetKeys() || !loadTokens())
   {
      if(!recoverFromBackups())
         return false;
   }
   setInitialized(true);
   return true;
  //## end database::AESKeyRing::reset%4983A3C702D4.body
}

bool AESKeyRing::resetKeys ()
{
  //## begin database::AESKeyRing::resetKeys%4A01EE0203A3.body preserve=yes
   KeyRing::reset(); //empty ring
   setInitialized(false);
#ifdef MVS
   string strICSFOption;
   Extract::instance()->getSpec("ICSF    ",strICSFOption);
   if (strICSFOption == "ON")         //default is "OFF"
      setICSF(true);
#endif
   setDefaultTransportKey("");
   setDefaultDataKey("");
   setDefaultAESDataKey("");
   for (int i = 1; i < 3; i++)
   {
      Query hQuery(i);
      hQuery.attach(this);
      if(!bind(hQuery))
         return false;
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery) || (pSelectStatement->getRows() == 0 && getActive()) || 
         (hQuery.getAbort() == true && i == 2))
         return false; 
   }
#ifdef MVS
   //load key map for ICSF calls
   FlatFile hKeyMap("PCIKEY");
   char* psBuffer = new char[256];
   memset(psBuffer,' ',256);
   size_t m = 0;
   while (hKeyMap.read(psBuffer,256,&m))
   {
      if (m > 12)
      {
         if (memcmp(psBuffer,"DKEY    ",8) == 0)
         {
            string strKeyId("IBM");
            strKeyId.append(psBuffer+8,4);
            if (!getKey(strKeyId))
            {
               string strKeyLabel(psBuffer+12,m-12);
               strKeyLabel.resize(64,' ');
               IBMKey* pKey = new IBMKey();
               pKey->setIdentifier(strKeyId);
               pKey->setCheckDigits(strKeyId.substr(3,4));
               pKey->setLabel(strKeyLabel);
               addKey(strKeyId,pKey);
            }
         }
      }
   }
   delete [] psBuffer;
#endif
   return true;
  //## end database::AESKeyRing::resetKeys%4A01EE0203A3.body
}

bool AESKeyRing::setColumns (reusable::Table& hTable)
{
  //## begin database::AESKeyRing::setColumns%56042C0F00B0.body preserve=yes
   int lCount = 0;
   Query hQuery;
   hQuery.bind("TASK_CONTEXT","*",reusable::Column::LONG,&lCount,0,"COUNT");
   hQuery.setBasicPredicate("TASK_CONTEXT","IMAGEID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","K");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   if(lCount == 0)
   {  //use TASK_CONTEXT_COMN
      hTable.setName("TASK_CONTEXT_COMN");
      hTable.setQualifier("QUALIFY");
      hTable.set("IMAGE_ID","*",false,true);
      hTable.set("TASK_ID","*",false,true);
      hTable.set("CONTEXT_TYPE","K",false,true);
   }
   else
   {  //Use TASK_CONTEXT
      hTable.setName("TASK_CONTEXT");
      hTable.set("IMAGEID","*",false,true);
      hTable.set("TASKID","*",false,true);
      hTable.set("CONTEXT_TYPE","K",false,true);
   }
   return true;
  //## end database::AESKeyRing::setColumns%56042C0F00B0.body
}

void AESKeyRing::tokenize (string& strPAN)
{
  //## begin database::AESKeyRing::tokenize%49DE3531005A.body preserve=yes
   if (strPAN.length() > 28)
      return;
   char szTemp[28];
   memcpy_s(szTemp,sizeof(szTemp),strPAN.data(),strPAN.length());
   tokenize(szTemp,strPAN.length());
   strPAN.assign(szTemp,strPAN.length());
  //## end database::AESKeyRing::tokenize%49DE3531005A.body
}

void AESKeyRing::tokenize (char* psPAN,int iPanLength)
{
  //## begin database::AESKeyRing::tokenize%49DE35310064.body preserve=yes
   if (!getActive())
      return;
   if (!getInitialized())
      return;
   Date hDate(Date::today());
   if (getStartDate() <= hDate.asString("%Y%m") &&
      hDate.asString("%Y%m") <= getEndDate())
      tokenize_1(psPAN,iPanLength);
  //## end database::AESKeyRing::tokenize%49DE35310064.body
}

void AESKeyRing::tokenize (char* psPAN,int iPanLength,char* psTSTAMP_TRANS)
{
  //## begin database::AESKeyRing::tokenize%4A01BB0400A9.body preserve=yes
   string strTSTAMP_TRANS(psTSTAMP_TRANS,6);
   if (getStartDate() <= strTSTAMP_TRANS &&
      strTSTAMP_TRANS <= getEndDate())
      tokenize_1(psPAN,iPanLength);
  //## end database::AESKeyRing::tokenize%4A01BB0400A9.body
}

void AESKeyRing::tokenize_1 (char* psPAN,int iPanLength)
{
  //## begin database::AESKeyRing::tokenize_1%4A0339250020.body preserve=yes
   if (iPanLength > 28 || iPanLength < 9)
      return;
   if (m_bIST && PenkoToken::instance()->isToken(psPAN, iPanLength))
   {
      string strPAN(psPAN, iPanLength);
      if(strPAN[iPanLength-3] == 'a')
         PenkoToken::instance()->detokenize(strPAN, "", 3);
      else
         PenkoToken::instance()->detokenize(strPAN, "000000", 1);
      memcpy(psPAN, strPAN.data(), strPAN.length());
   }
   int i = 0;
   for (i = 0; i < iPanLength; i++)
   {  //check for real length
      if (psPAN[i] == '\0' || psPAN[i] == ' ')
         break;
      if (psPAN[i] < '0' || psPAN[i] > '9')
         return;
   }
   iPanLength = i;
   if (iPanLength < 9)
      return;
   char szPAN[29];
   switch (m_iShuffleScheme)
   {
      case 1:
         memcpy_s(szPAN,3,psPAN+iPanLength-3,3);
         memcpy_s(szPAN+iPanLength-6,3,psPAN,3);
         memcpy_s(szPAN+iPanLength-3,3,psPAN+iPanLength-6,3);
         memcpy_s(szPAN+3,iPanLength - 9,psPAN+3,iPanLength-9);
         break;
      case 2 :
         memcpy_s(szPAN,3,psPAN+iPanLength-3,3);
         if (iPanLength >= 16)
         {
            memcpy_s(szPAN+3,1,psPAN,1);
            memcpy_s(szPAN+4,1,psPAN+6,1);
            memcpy_s(szPAN+5,1,psPAN+1,1);
            memcpy_s(szPAN+6,1,psPAN+7,1);
            memcpy_s(szPAN+7,1,psPAN+2,1);
            memcpy_s(szPAN+8,1,psPAN+8,1);
            memcpy_s(szPAN+9,1,psPAN+3,1);
            memcpy_s(szPAN+10,1,psPAN+9,1);
            memcpy_s(szPAN+11,1,psPAN+4,1);
            memcpy_s(szPAN+12,1,psPAN+10,1);
            memcpy_s(szPAN+13,1,psPAN+5,1);
            memcpy_s(szPAN+14,iPanLength - 14,psPAN+11,iPanLength-14);
         }
         else
         {
            memcpy_s(szPAN+iPanLength-6,3,psPAN,3);
            memcpy_s(szPAN+iPanLength-3,3,psPAN+iPanLength-6,3);
            memcpy_s(szPAN+3,iPanLength - 9,psPAN+3,iPanLength-9);
         }
         break;
      default:
         memcpy_s(szPAN,iPanLength,psPAN,iPanLength);
         break;
   }
   szPAN[iPanLength] = '\0';
   int iLen = 0;
   int iOffset = 0;
   while (iPanLength > 0)
   {
      iLen = (iPanLength % 4 > 0 ? iPanLength%4 : 4);
      iOffset = iPanLength - iLen;
      int k = atoi(szPAN+iOffset);
      if (iLen < 4)
         k += 10000;
      if (iLen < 3)
         k+=1000;
      if (iLen < 2)
         k+=100;
      memcpy_s(psPAN+iOffset,iLen,m_arrayTokens[k],iLen);
      szPAN[iOffset] = '\0';
      iPanLength -= iLen;
   }
  //## end database::AESKeyRing::tokenize_1%4A0339250020.body
}

bool AESKeyRing::unmask (int& iLength,char* pBuffer)
{
  //## begin database::AESKeyRing::unmask%49822E6601A5.body preserve=yes
   // new
   // |<--2--->|<--- 4 ---->|<---- 4 --->|<-5->|
   // |NPI type|Token Offset|Token Length|?@#^!|
   // old
   // |<--- 4 ---->|<---- 4 --->|<-4->|
   // |Token Offset|Token Length|@#^! |
   char szMask[5] = {"@#^!"};
   szMask[2] = 0xAC;
   if (memcmp(pBuffer + iLength - 4,"@#^!",4) != 0
      && memcmp(pBuffer + iLength - 4,szMask,4) != 0)
      return true;
   if (!getInitialized())
      return false;
   while (iLength > 4
      && (memcmp(pBuffer + iLength - 4,"@#^!",4) == 0
      || memcmp(pBuffer + iLength - 4,szMask,4) == 0))
   {
      if(pBuffer[iLength-5] == '?')
      {  //handle new format
         int iTokenOffset = atoi(string(pBuffer+iLength-13,4).c_str());
         int iTokenLength = atoi(string(pBuffer+iLength-9,4).c_str());
         int iNPI = atoi(string(pBuffer+iLength-15,2).c_str());
         int iSaveLen = iTokenLength;
         NPI::instance(iNPI)->unprotect(pBuffer+iTokenOffset,iTokenLength);
         int iShift = iSaveLen-iTokenLength;
         if(iShift > 0)
         { //shift buffer to adjust for smaller value
            for(int i = 0; i < (pBuffer+iLength-15) - (pBuffer+iTokenOffset+iSaveLen);i++)
               pBuffer[iTokenOffset+iTokenLength+i] = pBuffer[iTokenOffset+iSaveLen+i];
         }
         memset(pBuffer+iLength-15-iShift,' ',15+iShift);
         iLength -= (15+iShift);
      }
      else
      {  //handle old format 
         int iTokenOffset = atoi(string(pBuffer+iLength-12,4).c_str());
         int iTokenLength = atoi(string(pBuffer+iLength-8,4).c_str());
         detokenize(pBuffer+iTokenOffset,iTokenLength);
         memset(pBuffer+iLength-12,' ',12);
         iLength -= 12;
      }
      pBuffer[iLength] = '\0';
   }
   return true;
  //## end database::AESKeyRing::unmask%49822E6601A5.body
}

void AESKeyRing::update (Subject* pSubject)
{
  //## begin database::AESKeyRing::update%49822FFB02A1.body preserve=yes
   if (pSubject == MidnightAlarm::instance())
   {
      database::Cache::reload(this);
      return;
   }
   if (((Query*)pSubject)->getIndex() == 1)
   {
      if (m_strCONTEXT_DATA.length() < 64)
         return;
      int iKeySize = 32;
      if (m_strCONTEXT_DATA.length() == 100 && m_strCONTEXT_DATA.data()[99] == '3')
         iKeySize = 64;
      string strKey(m_strCONTEXT_DATA.data(),iKeySize);
      string strCipher(m_strCONTEXT_DATA.data() + iKeySize,22);
      strCipher.append("=="); //restore pad characters
      AESKey hKey(strKey);
      bool bTranslationRequired = false;
      hKey.decrypt(strCipher);
      if (strCipher != "FYX120b7Q2198442" && '9' == 0x39)
      {  //retry in case key was originally created on IBM.
         strKey.assign(m_strCONTEXT_DATA.data(),iKeySize);
         CodeTable::translate((char*)strKey.data(),strKey.length(),CodeTable::CX_ASCII_TO_EBCDIC);
         hKey.setKey(strKey);
         strCipher.assign(m_strCONTEXT_DATA.data() + iKeySize,22);
         strCipher.append("=="); //restore pad characters
         hKey.decrypt(strCipher);
         CodeTable::translate((char*)strCipher.data(),strCipher.length(),CodeTable::CX_EBCDIC_TO_ASCII);
         bTranslationRequired = true;
      }
      if (strCipher.length() == 16 && strCipher == "FYX120b7Q2198442")
      {
         Key* pKey = new AESKey(strKey);
         pKey->setIdentifier("Master-Seed");
         pKey->setCONTEXT_DATA(m_strCONTEXT_DATA);
         pKey->setCONTEXT_KEY(m_strCONTEXT_KEY);
         string strCryptogram(Key::getCryptoPhrase(),16);
         pKey->encrypt(strCryptogram);
         pKey->setCryptogram(strCryptogram);
         m_hKeys.insert(map<string,Key*,less<string> >::value_type(string("Master-Seed"),pKey));
         string strMasterKey(strKey);
         string strAdditionalData("C194E7B3434563222D1FAB4BACE39585");
         if (bTranslationRequired)
            AESKey::translate((char*)strAdditionalData.data(),strAdditionalData.length(),AESKey::CX_ASCII_TO_EBCDIC);
         strMasterKey.append(strAdditionalData);
         Key* pMasterKey;
         if (strKey.length() > 32)
         {
            AESKey::generateSHA512Digest(strMasterKey);
            pMasterKey = new AESKey();
            pMasterKey->setRawKey((char*)strMasterKey.data(),strMasterKey.length());
         }
         else
         {
             AESKey::generateDigest(strMasterKey);
             if (bTranslationRequired)
                AESKey::translate((char*)strMasterKey.data(),strMasterKey.length(),AESKey::CX_ASCII_TO_EBCDIC);
             pMasterKey = new AESKey(strMasterKey);
         }
         pMasterKey->setIdentifier("Master");
         strCryptogram.assign(Key::getCryptoPhrase(),16);
         pMasterKey->encrypt(strCryptogram);
         pMasterKey->setCryptogram(strCryptogram);
         m_hKeys.insert(map<string,Key*,less<string> >::value_type(string("Master"),pMasterKey));
         Trace::put("MasterKey loaded",-1,true);
         ((Query*)pSubject)->setAbort(true); //master key found
      }
   }
   else
   if (((Query*)pSubject)->getIndex() == 2)
   {
      if (!getKey("Master"))
      {  //cannot process keys without the master key
         Trace::put("MasterKey Not found",-1,true);
         ((Query*)pSubject)->setAbort(true);
         return;
      }
      AESKey* pMasterSeed = (AESKey*)getKey("Master-Seed");
      if (m_strCONTEXT_DATA == pMasterSeed->getCONTEXT_DATA())
         return; //skip the master key
      if (m_strCONTEXT_KEY == "DEFAULT_TRANSPORT_KEY")
      {
         Trace::put("Default Transport Key loaded");
         m_strDefaultTransportKey = m_strCONTEXT_DATA;
         return;
      }
      if (m_strCONTEXT_KEY == "DEFAULT_DATA_KEY")
      {
         Trace::put("Default Data Key loaded");
         m_strDefaultDataKey = m_strCONTEXT_DATA;
         return;
      }
      if (m_strCONTEXT_KEY == "DEFAULT_AES_DATA_KEY")
      {
         Trace::put("Default AES Data Key loaded");
         m_strDefaultAESDataKey = m_strCONTEXT_DATA;
         return;
      }
      char cKeyTypeInd = ' ';
      string strCONTEXT_DATA(m_strCONTEXT_DATA);
      if(strCONTEXT_DATA.length() == 100)
      {
         cKeyTypeInd = strCONTEXT_DATA[99];
         if (cKeyTypeInd == '2')
            strCONTEXT_DATA.resize(64);
         if (cKeyTypeInd == '3')
            strCONTEXT_DATA.resize(88);
      }
      AESKey* pMasterKey = (AESKey*)getKey("Master");
      pMasterKey->decrypt(strCONTEXT_DATA);
      bool bEBCDIC_TO_ASCII = AESKey::translate((char*)strCONTEXT_DATA.data(),8,AESKey::CX_EBCDIC_TO_ASCII);
      string strKeyType;
      if (strCONTEXT_DATA.length() == 48 || strCONTEXT_DATA.length() == 64 || strCONTEXT_DATA.length() == 88)
      {
         Key* pKey = 0;
         if (strCONTEXT_DATA[0] == 'P' || strCONTEXT_DATA[0] == 'D')
         {  //data keys
            if(cKeyTypeInd == '2')
            {  //AES Data Keys
               string strKey;
               char szTemp[3];
               for (int i = 8; i < 24; i++)
               { //expand 16 byte hex key to 32 char hex key
                  unsigned char c = strCONTEXT_DATA.data()[i];
                  strKey.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%02x",c));
               }
               //if original key was EBCDIC character encoded hex then need to translate ASCII char encoded hex to EBCDIC.
               if (bEBCDIC_TO_ASCII) //EBCDIC data on ASCII machine
                  CodeTable::translate((char*)strKey.data(),strKey.length(),CodeTable::CX_ASCII_TO_EBCDIC); 
               pKey = new AESKey(strKey);
               AESKey::translate((char*)strCONTEXT_DATA.data() + 25,13,AESKey::CX_EBCDIC_TO_ASCII);
               pKey->setStrength(256);     //do this before computeCheckDigits
               pKey->setType(Key::AES256);
               pKey->computeCheckDigits(); //do before setting cryptogram
               pKey->setCryptogram(strCONTEXT_DATA.substr(25,13));
               pKey->setCreateDate(strCONTEXT_DATA.substr(30,8));
               strKeyType.assign("AES");
            }
            else
            if (cKeyTypeInd == '3')
            {  //AES Data Keys (new and improved)
               pKey = new AESKey();
               pKey->setRawKey((char*)strCONTEXT_DATA.data() + 8,32);
               pKey->setType(Key::AES256_3);
               pKey->computeCheckDigits(); //do before setting cryptogram
               AESKey::translate((char*)strCONTEXT_DATA.data() + 41,13,AESKey::CX_EBCDIC_TO_ASCII);
               pKey->setCryptogram(strCONTEXT_DATA.substr(41,13));
               pKey->setCreateDate(strCONTEXT_DATA.substr(46,8));
               strKeyType.assign("AES");
           }
            else
            {  //DES data keys
               pKey = new DESKey();
               strKeyType.assign("DES");
               if (cKeyTypeInd == '1')
                  pKey->setStrength(168);//Triple DES 3 keys (168 bit strength)
               else
                  pKey->setStrength(112);//Triple DES 2 keys (112 bit strength)
               pKey->setKey(strCONTEXT_DATA.substr(8,16));
               AESKey::translate((char*)strCONTEXT_DATA.data() + 25,13,AESKey::CX_EBCDIC_TO_ASCII);
               pKey->setCryptogram(strCONTEXT_DATA.substr(25,13));
               pKey->setCreateDate(strCONTEXT_DATA.substr(30,8));
            }
         }
         else
         {
            string strKey;
            if (cKeyTypeInd == '3')
            {  //handle 256 bit key with new format for encrypting tokens
               //aaaaaa==xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxBBBBBBBBBBBBBBBBBBBBBBBB^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^3   
               //(a..a = key id,x..x = binary 32 bytes,B..B = 24 bytes base64 encoded cryptogram,^..^ spaces,3 = AES256 new format)   
               pKey = new AESKey();
               pKey->setRawKey((char*)strCONTEXT_DATA.data()+8,32);
               pKey->setStrength(256);     //do this before computeCheckDigits
               pKey->setType(Key::AES256_3);
               pKey->computeCheckDigits(); //do before setting cryptogram
               AESKey::translate((char*)strCONTEXT_DATA.data() + 40,24,AESKey::CX_EBCDIC_TO_ASCII);
               pKey->setCryptogram(strCONTEXT_DATA.substr(40,24));
               strKeyType.assign("AES");
            }
            else
            {
               char szTemp[3];  
               for (int i = 8; i < 24; i++)
               { //expand 16 byte hex key to 32 char hex key
                  unsigned char c = strCONTEXT_DATA.data()[i];
                  strKey.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%02x",c));
               }
               if (bEBCDIC_TO_ASCII)
               {
                  CodeTable::translate((char*)strKey.data(),strKey.length(),CodeTable::CX_ASCII_TO_EBCDIC);
                  CodeTable::translate((char*)strCONTEXT_DATA.data() + 24,24,CodeTable::CX_EBCDIC_TO_ASCII);
               }
               pKey = new AESKey(strKey);
               pKey->setCryptogram(strCONTEXT_DATA.substr(24,24));
            }
            if(strCONTEXT_DATA[0] == '2')
               pKey->setCreateDate(strCONTEXT_DATA.substr(0,6) + "01");
            else
            {  //nYYJJJ format
               int iYear = atoi(strCONTEXT_DATA.substr(1,2).c_str());
               if (iYear < INT_MAX - 2000)
                  iYear += 2000;
               int iJJJ = atoi(strCONTEXT_DATA.substr(3,3).c_str());
               Date hDate(iYear,iJJJ);
               pKey->setCreateDate(hDate.asString("%Y%m%d"));
            }
            strKeyType.assign("AES");
         }
         string strId(strCONTEXT_DATA.substr(0,6));
         pKey->setIdentifier(strId);
         pKey->setCONTEXT_DATA(m_strCONTEXT_DATA);
         pKey->setCONTEXT_KEY(m_strCONTEXT_KEY);
         char szKeyId[80];
         if(pKey->validate())
         {
            m_hKeys.insert(map<string,Key*,less<string> >::value_type(strId,pKey));
            Trace::put(szKeyId,snprintf(szKeyId,sizeof(szKeyId),"%s Key: %s loaded",strKeyType.c_str(),strId.c_str()),true);
         }
         else
         {
            Trace::put(szKeyId,snprintf(szKeyId,sizeof(szKeyId),"%s Key: %s not loaded - validation error",strKeyType.c_str(),strId.c_str()),true);
            delete pKey;
         }
      }
   }
   else
   if (((Query*)pSubject)->getIndex() == 3)
   {  //loadTokens
      if (m_iSEQ_NO == 25)
      {
         while (m_strTOKEN.length() >= 88)
         {
            string strTokens(m_strTOKEN.data(),86);
            strTokens.append("==");
            decrypt(m_strDATE,strTokens);
            AESKey::translate((char*)strTokens.data(),strTokens.length(),AESKey::CX_EBCDIC_TO_ASCII);
            m_strTokenControl.append(strTokens.data(),strTokens.length());
            m_strTOKEN.erase(0,88);
         }
         return;
      }
      while (m_strTOKEN.length() >= 88)
      {
         string strTokens(m_strTOKEN.data(),86);
         strTokens.append("==");
         decrypt(m_strDATE,strTokens);
         AESKey::translate((char*)strTokens.data(),strTokens.length(),AESKey::CX_EBCDIC_TO_ASCII);
         memcpy_s(((char*)m_arrayTokens)+m_iOffset,strTokens.length(),strTokens.data(),strTokens.length());
         m_iOffset+=strTokens.length();
         m_strTOKEN.erase(0,88);
      }
   }
   else
   if (((Query*)pSubject)->getIndex() == 4)
   {  //recoverFromBackups part 1
      m_hBackups.push_back(make_pair(m_iDX_FILE_ID,m_strDATE_RECON));
   }
   else
   if (((Query*)pSubject)->getIndex() == 5)
   {  //recoverFromBackups part2
      if(m_strDATA_BUFFER.length() > 132) //32 + 100 (AES Data Keys have type in column 100 of CONTEXT_DATA)
         m_hTokensDATA_BUFFER.push_back(m_strDATA_BUFFER);
      else
         m_hKeysDATA_BUFFER.push_back(m_strDATA_BUFFER);
   }
   else
   if(((Query*)pSubject)->getIndex() == 6)
   {
      Table hTable("TASK_CONTEXT_COMN");
      hTable.setQualifier("QUALIFY");
      hTable.set("IMAGE_ID","*");
      hTable.set("TASK_ID","*");
      hTable.set("CONTEXT_TYPE","K");
      hTable.set("CONTEXT_KEY",m_strCONTEXT_KEY);
      hTable.set("CONTEXT_DATA",m_strCONTEXT_DATA);
      auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      if (pInsertStatement->execute(hTable) == false)
      {
         Trace::put("AESKeyRing::update() - moveKeys insert Failure",-1,true);
         Database::instance()->rollback();
         ((Query*)pSubject)->setAbort(true);
         return;
      }
   }
  //## end database::AESKeyRing::update%49822FFB02A1.body
}

bool AESKeyRing::validateTokens ()
{
  //## begin database::AESKeyRing::validateTokens%5012B9860229.body preserve=yes
   string strArrayTokens((char*)m_arrayTokens,11136*4);
   if (strArrayTokens.find("9") != string::npos)
   {
      Trace::put("Warning! Tokens failed to load 2",-1,true);
      return false;
   }
   //process control record
   if (m_strTokenControl.length() != sizeof(struct TokenControl))
   {
      Trace::put("Warning! Tokens failed to load 3",-1,true);
      return false;
   }
   struct TokenControl* pTokenControl = (struct TokenControl*)m_strTokenControl.data();
   string strTemp(pTokenControl->SerialNo,sizeof(pTokenControl->SerialNo));
   m_iSerialNo = atoi(strTemp.c_str());
   strTemp.assign(pTokenControl->Hash,sizeof(pTokenControl->Hash));
   m_lHash = atoi(strTemp.c_str());
   strTemp.assign(pTokenControl->ShuffleScheme,sizeof(pTokenControl->ShuffleScheme));
   m_iShuffleScheme = atoi(strTemp.c_str());
   string strRowOrder(pTokenControl->RowOrder,sizeof(pTokenControl->RowOrder));

   setStartDate(string(pTokenControl->StartDate,sizeof(pTokenControl->StartDate)));
   setEndDate(string(pTokenControl->EndDate,sizeof(pTokenControl->EndDate)));
   int arrayRowOrder[25];
   for (int i = 0; i < 24; i++)
   {
      arrayRowOrder[i] = atoi(strRowOrder.substr(0,2).c_str());
      strRowOrder.erase(0,2);
   }
   //scramble the order of the rows
   char arrayTemp[11136][4];
   int iTempOffset = 0;
   for (int i = 0; i < 24; i++)
   {
      m_iOffset = (arrayRowOrder[i]-1)*16*29*4;
      memcpy_s(((char*)arrayTemp)+iTempOffset,1856,((char*)m_arrayTokens)+m_iOffset,1856);
      iTempOffset+=1856;
   }
   m_iOffset = 0;
   for (int i = 0; i < 24; i++)
   {
      memcpy_s(((char*)m_arrayTokens)+m_iOffset,1856,((char*)arrayTemp)+m_iOffset,1856);
      m_iOffset+=1856;
   }
   //sort tokens by creating map from array
   map<string,int,less<string> > mapTokens;
   for (int i = 0; i < 11136; i++)
   {
      string strToken(m_arrayTokens[i],4);
      mapTokens.insert(map<string,int,less<string> >::value_type(strToken,i));
   }
   //populate m_arrayTokenOrder to save sorted order
   int k = 0;
   map<string,int,less<string> >::iterator q;
   for (q = mapTokens.begin(); q != mapTokens.end(); q++,k++)
   {
      m_arrayTokenOrder[k] = (short)(*q).second;
   }
   
   //generate Hash of tokens for final validation
   int lHash = AESKey::generateHash((char*)m_arrayTokens,11136 * 4);
   if (lHash != m_lHash)
   {  //try again by computing the EBCDIC hash
      const char* ptr = (char*)m_arrayTokens;
      int iLength = 11136 * 4;
      lHash = 0;
      for (int i = 0; i < iLength; i++)
      {
         unsigned char c = *ptr++;
         CodeTable::translate((char*)&c,1,CodeTable::CX_ASCII_TO_EBCDIC);
         lHash = (lHash * 32) + lHash + c;
      }
      if (lHash < 0)
         lHash = -lHash;
      if (lHash != m_lHash)
      { 
         Trace::put("Warning! Tokens failed to load 4",-1,true);
         return false;
      }
   }
   
   //check if all fin tables are tokenized
   GlobalContext hBegin("##BEGIN");
   GlobalContext hEnd("##END");
   string strBegin;
   string strEnd;
   hBegin.get(strBegin,'F');
   hEnd.get(strEnd,'F');
   if(AESKeyRing::instance()->getStartDate() <= strBegin && 
      AESKeyRing::instance()->getEndDate() > strEnd)
      reusable::Mask::setTokenizeComplete(true);
   else
      reusable::Mask::setTokenizeComplete(false);
   return true;
  //## end database::AESKeyRing::validateTokens%5012B9860229.body
}

// Additional Declarations
  //## begin database::AESKeyRing%4982285D018F.declarations preserve=yes
  //## end database::AESKeyRing%4982285D018F.declarations

} // namespace database

//## begin module%4982289F011C.epilog preserve=yes
//## end module%4982289F011C.epilog


// Detached code regions:
// WARNING: this code will be lost if code is regenerated.
#if 0
//## begin database::AESKeyRing::moveKeys%5604313B019A.body preserve=no
   int lCount = 0;
   Query hQuery;
   hQuery.setQualifier("QUALIFY","TASK_CONTEXT_COMN");
   hQuery.bind("TASK_CONTEXT_COMN","*",reusable::Column::LONG,&lCount,0,"COUNT");
   hQuery.setBasicPredicate("TASK_CONTEXT_COMN","IMAGE_ID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT_COMN","TASK_ID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT_COMN","CONTEXT_TYPE","=","K");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
   {
      IF::Trace::put("AESKeyRing::moveKeys() - unable to query TASK_CONTEXT_COMN",-1,true);
      Database::instance()->rollback();
      return false;
   }
   if(lCount > 0)
      return true;  //keys already moved
   lCount = 0;
   hQuery.reset();
   hQuery.bind("TASK_CONTEXT","*",reusable::Column::LONG,&lCount,0,"COUNT");
   hQuery.setBasicPredicate("TASK_CONTEXT","IMAGEID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","K");
   if (!pSelectStatement->execute(hQuery))
   {
      IF::Trace::put("AESKeyRing::moveKeys() - unable to query TASK_CONTEXT",-1,true);
      Database::instance()->rollback();
      return false;
   }
   if(lCount == 0)
      return true; //nothing to move
   hQuery.reset();
   hQuery.setIndex(6);
   hQuery.attach(this);
   hQuery.bind("TASK_CONTEXT","CONTEXT_KEY",reusable::Column::STRING,&m_strCONTEXT_KEY);
   hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",reusable::Column::STRING,&m_strCONTEXT_DATA);
   hQuery.setBasicPredicate("TASK_CONTEXT","IMAGEID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","K");
   if (!pSelectStatement->execute(hQuery) || hQuery.getAbort() == true)
   {
      IF::Trace::put("AESKeyRing::moveKeys() - unable to move keys to TASK_CONTEXT_COMN",-1,true);
      Database::instance()->rollback();
      return false;
   }
   //delete the keys from TASK_CONTEXT
   hQuery.reset();
   hQuery.setBasicPredicate("TASK_CONTEXT","IMAGEID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","K");
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   if (!pDeleteStatement->execute(hQuery))
   {
      IF::Trace::put("AESKeyRing::moveKeys() - delete keys from TASK_CONTEXT failed",-1,true);
      Database::instance()->rollback();
      return false;
   }
   Database::instance()->commit();
   return true;
//## end database::AESKeyRing::moveKeys%5604313B019A.body

#endif
