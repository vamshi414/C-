//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%51C8512F0063.cm preserve=no
//	$Date:   Jul 29 2021 07:57:34  $ $Author:   e5632565  $ $Revision:   1.7  $
//## end module%51C8512F0063.cm

//## begin module%51C8512F0063.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%51C8512F0063.cp

//## Module: CXOSDB44%51C8512F0063; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.4B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB44.hpp

#ifndef CXOSDB44_h
#define CXOSDB44_h 1

//## begin module%51C8512F0063.additionalIncludes preserve=no
//## end module%51C8512F0063.additionalIncludes

//## begin module%51C8512F0063.includes preserve=yes
#include <set>
#include <map>

//## end module%51C8512F0063.includes

#ifndef CXOSRU46_h
#include "CXODRU46.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;

} // namespace IF

//## begin module%51C8512F0063.declarations preserve=no
//## end module%51C8512F0063.declarations

//## begin module%51C8512F0063.additionalDeclarations preserve=yes
//## end module%51C8512F0063.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::AuditEvent%51C853240081.preface preserve=yes
//## end database::AuditEvent%51C853240081.preface

//## Class: AuditEvent%51C853240081
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%51C86F79013C;reusable::Table { -> F}
//## Uses: <unnamed>%51C86F7B0238;IF::Message { -> F}

class DllExport AuditEvent : public reusable::Cache  //## Inherits: <unnamed>%51C8533903A8
{
  //## begin database::AuditEvent%51C853240081.initialDeclarations preserve=yes
  public:
   enum EventType
   {
      SELECT,
      INSERT,
      UPDATE,
      DEL,
      OPERATOR_COMMAND
   };
   enum EventCategory
   {
      ADMIN_ACTION = 100,
      APPLICATION_ID = 200,
      AUDIT_ACCESS = 300,
      AUDIT_LOG = 400,
      CARDHOLDER_DATA = 500,
      INVALID_ACCESS = 600,
      SYSTEM_LEVEL_OBJECT = 700
   };
  //## end database::AuditEvent%51C853240081.initialDeclarations

  public:
    //## Constructors (generated)
      AuditEvent();

    //## Destructor (generated)
      virtual ~AuditEvent();


    //## Other Operations (specified)
      //## Operation: capture%51E803BD02CD
      static void capture (const IF::Message& hMessage, const string& strCommand);

      //## Operation: capture%51E41D4702D3
      static void capture (const string& strTableName, const string& strSearchCondition, const string& strPredicates);

      //## Operation: capture%51E41F430106
      static void capture (const IF::Message& hMessage);

      //## Operation: capture%51CA09CC016D
      static void capture (reusable::Table& hTable, short sEventType);

      //## Operation: capture%524C477001EC
      static void capture (const string& strUSER_ID, short sEVENT_TYPE, short sRETURN_CODE, const string& strRESOURCE_NAME, const string& strRESOURCE_KEY);

      //## Operation: captureEvent%51E803BD02D4
      virtual void captureEvent (const IF::Message& hMessage, const string& strCommand);

      //## Operation: captureEvent%51E41D980038
      virtual void captureEvent (const string& strTableName, const string& strSearchCondition, const string& strPredicates);

      //## Operation: captureEvent%51E41F6E02E4
      virtual void captureEvent (const IF::Message& hMessage);

      //## Operation: captureEvent%51C86F2101CD
      virtual void captureEvent (reusable::Table& hTable, short iEventType);

      //## Operation: captureEvent%524C481400D7
      virtual void captureEvent (const string& strUSER_ID, short sEVENT_TYPE, short sRETURN_CODE, const string& strRESOURCE_NAME, const string& strRESOURCE_KEY);

      //## Operation: commit%51CA074C004C
      static bool commit (bool bCommit);

      //## Operation: commitEvent%51C855DA0277
      virtual bool commitEvent (bool bCommit);

      //## Operation: load%51C855DA0257
      virtual bool load ();

    // Additional Public Declarations
      //## begin database::AuditEvent%51C853240081.public preserve=yes
      //## end database::AuditEvent%51C853240081.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Configured%51E58356006F
      //## begin database::AuditEvent::Configured%51E58356006F.attr preserve=no  protected: bool {U} true
      bool m_bConfigured;
      //## end database::AuditEvent::Configured%51E58356006F.attr

    // Additional Protected Declarations
      //## begin database::AuditEvent%51C853240081.protected preserve=yes
      map<string,vector<string>,less<string> > m_hTables;
      //## end database::AuditEvent%51C853240081.protected
  private:
    // Additional Private Declarations
      //## begin database::AuditEvent%51C853240081.private preserve=yes
      //## end database::AuditEvent%51C853240081.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%51C855F20222
      //## begin database::AuditEvent::Instance%51C855F20222.attr preserve=no  private: static AuditEvent* {U} 0
      static AuditEvent* m_pInstance;
      //## end database::AuditEvent::Instance%51C855F20222.attr

    // Additional Implementation Declarations
      //## begin database::AuditEvent%51C853240081.implementation preserve=yes
      //## end database::AuditEvent%51C853240081.implementation

};

//## begin database::AuditEvent%51C853240081.postscript preserve=yes
//## end database::AuditEvent%51C853240081.postscript

} // namespace database

//## begin module%51C8512F0063.epilog preserve=yes
//## end module%51C8512F0063.epilog


#endif
