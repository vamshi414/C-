//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63A3CF020245.cm preserve=no
//## end module%63A3CF020245.cm

//## begin module%63A3CF020245.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63A3CF020245.cp

//## Module: CXOSDB68%63A3CF020245; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB68.hpp

#ifndef CXOSDB68_h
#define CXOSDB68_h 1

//## begin module%63A3CF020245.additionalIncludes preserve=no
//## end module%63A3CF020245.additionalIncludes

//## begin module%63A3CF020245.includes preserve=yes
//## end module%63A3CF020245.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%63A3CF020245.declarations preserve=no
//## end module%63A3CF020245.declarations

//## begin module%63A3CF020245.additionalDeclarations preserve=yes
//## end module%63A3CF020245.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::NetworkReportFactory%5C3F9788036D.preface preserve=yes
//## end database::NetworkReportFactory%5C3F9788036D.preface

//## Class: NetworkReportFactory%5C3F9788036D
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport NetworkReportFactory : public reusable::Object  //## Inherits: <unnamed>%5C3F97A402A4
{
  //## begin database::NetworkReportFactory%5C3F9788036D.initialDeclarations preserve=yes
    typedef reusable::Object* (*cloneFunction)(const char*, int, const string&);
  //## end database::NetworkReportFactory%5C3F9788036D.initialDeclarations

  public:
    //## Constructors (generated)
      NetworkReportFactory();

    //## Destructor (generated)
      virtual ~NetworkReportFactory();


    //## Other Operations (specified)
      //## Operation: create%5C3F9B68037B
      reusable::Object* create (const char* sBuffer, int iRecordLength, const string& strFileName);

      //## Operation: instance%5C40AED401B7
      static NetworkReportFactory* instance ();

      //## Operation: registerReport%5C3F99EA0097
      bool registerReport (const reusable::string& strName, cloneFunction hCloneFunction);

    // Additional Public Declarations
      //## begin database::NetworkReportFactory%5C3F9788036D.public preserve=yes
      //## end database::NetworkReportFactory%5C3F9788036D.public

  protected:
    // Additional Protected Declarations
      //## begin database::NetworkReportFactory%5C3F9788036D.protected preserve=yes
      //## end database::NetworkReportFactory%5C3F9788036D.protected

  private:
    // Additional Private Declarations
      //## begin database::NetworkReportFactory%5C3F9788036D.private preserve=yes
       map<string,cloneFunction,less<string> > m_hNetworkReport; 
      //## end database::NetworkReportFactory%5C3F9788036D.private
  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5C40AEBE01A0
      //## begin database::NetworkReportFactory::Instance%5C40AEBE01A0.attr preserve=no  private: static NetworkReportFactory* {V} 0
      static NetworkReportFactory* m_pInstance;
      //## end database::NetworkReportFactory::Instance%5C40AEBE01A0.attr

    // Additional Implementation Declarations
      //## begin database::NetworkReportFactory%5C3F9788036D.implementation preserve=yes
      //## end database::NetworkReportFactory%5C3F9788036D.implementation

};

//## begin database::NetworkReportFactory%5C3F9788036D.postscript preserve=yes
//## end database::NetworkReportFactory%5C3F9788036D.postscript

} // namespace database

//## begin module%63A3CF020245.epilog preserve=yes
//## end module%63A3CF020245.epilog


#endif
