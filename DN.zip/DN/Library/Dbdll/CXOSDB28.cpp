//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%459254DB00CD.cm preserve=no
//	$Date:   Aug 03 2020 13:54:06  $ $Author:   e1009839  $
//	$Revision:   1.11  $
//## end module%459254DB00CD.cm

//## begin module%459254DB00CD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%459254DB00CD.cp

//## Module: CXOSDB28%459254DB00CD; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB28.cpp

//## begin module%459254DB00CD.additionalIncludes preserve=no
//## end module%459254DB00CD.additionalIncludes

//## begin module%459254DB00CD.includes preserve=yes
#include <sstream>
//## end module%459254DB00CD.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSDB29_h
#include "CXODDB29.hpp"
#endif
#ifndef CXOSDB28_h
#include "CXODDB28.hpp"
#endif


//## begin module%459254DB00CD.declarations preserve=no
//## end module%459254DB00CD.declarations

//## begin module%459254DB00CD.additionalDeclarations preserve=yes
//## end module%459254DB00CD.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::Channel

Channel::Channel()
  //## begin Channel::Channel%4592547A0328_const.hasinit preserve=no
  //## end Channel::Channel%4592547A0328_const.hasinit
  //## begin Channel::Channel%4592547A0328_const.initialization preserve=yes
  //## end Channel::Channel%4592547A0328_const.initialization
{
  //## begin database::Channel::Channel%4592547A0328_const.body preserve=yes
   memcpy(m_sID,"DB28",4);
  //## end database::Channel::Channel%4592547A0328_const.body
}

Channel::Channel (const string& strIMAGEID, const string& strTASKID)
  //## begin database::Channel::Channel%4613885A0377.hasinit preserve=no
  //## end database::Channel::Channel%4613885A0377.hasinit
  //## begin database::Channel::Channel%4613885A0377.initialization preserve=yes
   : m_strIMAGEID(strIMAGEID)
   ,m_strTASKID(strTASKID)
  //## end database::Channel::Channel%4613885A0377.initialization
{
  //## begin database::Channel::Channel%4613885A0377.body preserve=yes
   memcpy(m_sID,"DB28",4);
  //## end database::Channel::Channel%4613885A0377.body
}


Channel::~Channel()
{
  //## begin database::Channel::~Channel%4592547A0328_dest.body preserve=yes
  //## end database::Channel::~Channel%4592547A0328_dest.body
}



//## Other Operations (implementation)
bool Channel::getProgress (string& strTimestamp)
{
  //## begin database::Channel::getProgress%45C3123602DA.body preserve=yes
   Query hQuery;
   short int iNull = 0;
   hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",Column::STRING,&strTimestamp,&iNull,"MIN");
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","P");
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_KEY","=","CHANNEL PROGRESS");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(hQuery);
   if (b)
   {
      if (iNull == -1)
         strTimestamp.assign("9999123123595999");
      else
         strTimestamp.resize(16);
   }
   return b;
  //## end database::Channel::getProgress%45C3123602DA.body
}

void Channel::getStatus ()
{
  //## begin database::Channel::getStatus%4FF6FF71035D.body preserve=yes
   Query hQuery;
   hQuery.attach(this);
   Status::instance()->bind(hQuery);
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_KEY","=","CHANNEL PROGRESS");
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","P");
   hQuery.setOrderByClause("TASKID");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   pSelectStatement->execute(hQuery);
  //## end database::Channel::getStatus%4FF6FF71035D.body
}

bool Channel::setProgress (const string& strTimestamp, int iDepth)
{
  //## begin database::Channel::setProgress%459255D40135.body preserve=yes
   Context hContext(m_strIMAGEID,m_strTASKID);
   stringstream ss;
   ss << strTimestamp << " " << iDepth;
   string strCONTEXT_DATA;
   if (!hContext.get("CHANNEL PROGRESS",strCONTEXT_DATA,'P'))
      return false;
   bool b = true;
   if (strCONTEXT_DATA < ss.str().c_str())
      b = hContext.put("CHANNEL PROGRESS",ss.str().c_str(),'P');
   return b;
  //## end database::Channel::setProgress%459255D40135.body
}

void Channel::update (Subject* pSubject)
{
  //## begin database::Channel::update%4594E6590177.body preserve=yes
   Status::instance()->notify();
  //## end database::Channel::update%4594E6590177.body
}

// Additional Declarations
  //## begin database::Channel%4592547A0328.declarations preserve=yes
  //## end database::Channel%4592547A0328.declarations

} // namespace database

//## begin module%459254DB00CD.epilog preserve=yes
//## end module%459254DB00CD.epilog
