//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41BF718501E4.cm preserve=no
//	$Date:   May 14 2020 18:12:12  $ $Author:   e1009510  $
//	$Revision:   1.5  $
//## end module%41BF718501E4.cm

//## begin module%41BF718501E4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%41BF718501E4.cp

//## Module: CXOSDB24%41BF718501E4; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: D:\Devel.7B.R001\ConnexPlatform\Server\Library\Dbdll\CXOSDB24.cpp

//## begin module%41BF718501E4.additionalIncludes preserve=no
//## end module%41BF718501E4.additionalIncludes

//## begin module%41BF718501E4.includes preserve=yes
#include <math.h>
//## end module%41BF718501E4.includes

#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB24_h
#include "CXODDB24.hpp"
#endif


//## begin module%41BF718501E4.declarations preserve=no
//## end module%41BF718501E4.declarations

//## begin module%41BF718501E4.additionalDeclarations preserve=yes
//## end module%41BF718501E4.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::CurrencyCode 

//## begin database::CurrencyCode::Instance%41BF75A1036B.attr preserve=no  private: static database::CurrencyCode* {V} 0
CurrencyCode* CurrencyCode::m_pInstance = 0;
//## end database::CurrencyCode::Instance%41BF75A1036B.attr

CurrencyCode::CurrencyCode()
  //## begin CurrencyCode::CurrencyCode%41BF6F49009C_const.hasinit preserve=no
      : m_bLoadCurrencyFailure(false)
  //## end CurrencyCode::CurrencyCode%41BF6F49009C_const.hasinit
  //## begin CurrencyCode::CurrencyCode%41BF6F49009C_const.initialization preserve=yes
  //## end CurrencyCode::CurrencyCode%41BF6F49009C_const.initialization
{
  //## begin database::CurrencyCode::CurrencyCode%41BF6F49009C_const.body preserve=yes
   memcpy_s(m_sID,4,"DB24",4);
   queryTable();
  //## end database::CurrencyCode::CurrencyCode%41BF6F49009C_const.body
}


CurrencyCode::~CurrencyCode()
{
  //## begin database::CurrencyCode::~CurrencyCode%41BF6F49009C_dest.body preserve=yes
  //## end database::CurrencyCode::~CurrencyCode%41BF6F49009C_dest.body
}



//## Other Operations (implementation)
string CurrencyCode::formatAmount (double dAmount, const string& strCURRENCY_CODE, int iSize, bool bLeftJustified, bool bPrefixZeros, bool bCurrencySymbol)
{
  //## begin database::CurrencyCode::formatAmount%451D19B5035B.body preserve=yes
   string strCUR_SYMBOL;
   short nDECIMAL_PLACES = 2;
   getCurrencyDetails (strCURRENCY_CODE,strCUR_SYMBOL,nDECIMAL_PLACES);
   int iPos = 0;
   char szFormat[2*PERCENTD+2];
   char szFormattedAmount[23];
   if (bCurrencySymbol)
   {
      iPos = (int)strCUR_SYMBOL.length();
      memcpy_s(szFormat,sizeof(szFormat),strCUR_SYMBOL.data(),iPos);
   }
   if(iPos < sizeof(szFormat))
      szFormat[iPos++] = '%';
   if (bLeftJustified)
      if(iPos < sizeof(szFormat))
         szFormat[iPos++] = '-';
   if (bPrefixZeros)
      if(iPos < sizeof(szFormat))
         szFormat[iPos++] = '0';
   if(iPos < sizeof(szFormat))
      snprintf(szFormat+iPos,sizeof(szFormat)-iPos,"%d.%df",iSize,nDECIMAL_PLACES);
   snprintf(szFormattedAmount,sizeof(szFormattedAmount),szFormat,dAmount/pow((double)10,nDECIMAL_PLACES));
   return string(szFormattedAmount);
  //## end database::CurrencyCode::formatAmount%451D19B5035B.body
}

bool CurrencyCode::getCurrencyDetails (const string& strCURRENCY_CODE, string& strCUR_SYMBOL, short& nDECIMAL_PLACES)
{
  //## begin database::CurrencyCode::getCurrencyDetails%41BF77C50232.body preserve=yes
   map<string,pair<string,int>,less<string> >::const_iterator CurIter;
   CurIter = m_hCurrencyDetails.find(strCURRENCY_CODE);
   if (CurIter == m_hCurrencyDetails.end())
      return false;
   strCUR_SYMBOL = (CurIter->second).first;
   nDECIMAL_PLACES = (CurIter->second).second;
   return true;
  //## end database::CurrencyCode::getCurrencyDetails%41BF77C50232.body
}

CurrencyCode* CurrencyCode::instance ()
{
  //## begin database::CurrencyCode::instance%41BF75DA00BB.body preserve=yes
   if (m_pInstance == 0)
      m_pInstance = new CurrencyCode();
   return m_pInstance;
  //## end database::CurrencyCode::instance%41BF75DA00BB.body
}

bool CurrencyCode::queryTable ()
{
  //## begin database::CurrencyCode::queryTable%41BF784001F4.body preserve=yes
   reusable::Query hQuery;
   hQuery.attach(this);
   hQuery.setQualifier("QUALIFY","CURRENCY_CODE");
   hQuery.bind("CURRENCY_CODE","CURRENCY_CODE",Column::STRING,&m_strCURRENCY_CODE);
   hQuery.bind("CURRENCY_CODE","CUR_SYMBOL",Column::STRING,&m_strCUR_SYMBOL);
   hQuery.bind("CURRENCY_CODE","DECIMAL_PLACES",Column::SHORT,&m_nDECIMAL_PLACES);
   hQuery.setBasicPredicate("CURRENCY_CODE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("CURRENCY_CODE","CC_STATE","=","A");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create(  "SelectStatement"));
   bool bexecute = pSelectStatement->execute(hQuery);
   if (!bexecute || pSelectStatement->getRows() == 0)
      m_bLoadCurrencyFailure = true;
   return bexecute;
  //## end database::CurrencyCode::queryTable%41BF784001F4.body
}

void CurrencyCode::update (Subject* pSubject)
{
  //## begin database::CurrencyCode::update%41BF766300AB.body preserve=yes
   pair<string,int> hCurrencyMapData(m_strCUR_SYMBOL,m_nDECIMAL_PLACES);
   m_hCurrencyDetails.insert(map<string,pair<string,int>,less<string> >::value_type(m_strCURRENCY_CODE,hCurrencyMapData));
  //## end database::CurrencyCode::update%41BF766300AB.body
}

// Additional Declarations
  //## begin database::CurrencyCode%41BF6F49009C.declarations preserve=yes
  //## end database::CurrencyCode%41BF6F49009C.declarations

} // namespace database

//## begin module%41BF718501E4.epilog preserve=yes
//## end module%41BF718501E4.epilog
