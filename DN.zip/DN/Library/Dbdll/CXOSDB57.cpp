//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5ADE4F200336.cm preserve=no
//	$Date:   Feb 26 2020 13:34:30  $ $Author:   e1009652  $
//	$Revision:   1.5  $
//## end module%5ADE4F200336.cm

//## begin module%5ADE4F200336.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5ADE4F200336.cp

//## Module: CXOSDB57%5ADE4F200336; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB57.cpp

//## begin module%5ADE4F200336.additionalIncludes preserve=no
//## end module%5ADE4F200336.additionalIncludes

//## begin module%5ADE4F200336.includes preserve=yes
#include "CXODIF03.hpp"
//## end module%5ADE4F200336.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB58_h
#include "CXODDB58.hpp"
#endif
#ifndef CXOSDB57_h
#include "CXODDB57.hpp"
#endif


//## begin module%5ADE4F200336.declarations preserve=no
//## end module%5ADE4F200336.declarations

//## begin module%5ADE4F200336.additionalDeclarations preserve=yes
//## end module%5ADE4F200336.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::RowCache

//## begin database::RowCache::Instance%5ADF1B980002.attr preserve=no  private: static database::RowCache* {V} 0
database::RowCache* RowCache::m_pInstance = 0;
//## end database::RowCache::Instance%5ADF1B980002.attr

RowCache::RowCache()
  //## begin RowCache::RowCache%5ADE4E7D0382_const.hasinit preserve=no
      : m_pLast(0),
        m_pFirst(0)
  //## end RowCache::RowCache%5ADE4E7D0382_const.hasinit
  //## begin RowCache::RowCache%5ADE4E7D0382_const.initialization preserve=yes
  //## end RowCache::RowCache%5ADE4E7D0382_const.initialization
{
  //## begin database::RowCache::RowCache%5ADE4E7D0382_const.body preserve=yes
   memcpy_s(m_sID,4,"DB57",4);
  //## end database::RowCache::RowCache%5ADE4E7D0382_const.body
}


RowCache::~RowCache()
{
  //## begin database::RowCache::~RowCache%5ADE4E7D0382_dest.body preserve=yes
  //## end database::RowCache::~RowCache%5ADE4E7D0382_dest.body
}



//## Other Operations (implementation)
database::RowSet* RowCache::create (const string& strName)
{
  //## begin database::RowCache::create%5ADE508C0321.body preserve=yes
   UseCase hUseCase("DR","## DB57 CREATE ROW SET");
   if (m_hRowSet.empty())
      MinuteTimer::instance()->attach(this);
   CriticalSection hCriticalSection;
   RowSet r(strName,m_pLast);
   RowSet* pRowSet = m_hRowSet.find(r);
   if (!pRowSet)
   {
      if (m_hRowSet.size() >= 1024
         && m_pFirst->getInUse() == 0
         && m_pFirst->closed())
      {
         RowSet r(*m_pFirst);
         m_pFirst = m_pFirst->getPrevious();
         m_pFirst->setNext(0);
         m_hRowSet.erase(r);
      }
      string strText("RowCache::create : ");
      strText += strName;
      Trace::put(strText.data(),strText.length(),true);
      pair<RowSet*,bool> hResult = m_hRowSet.insert(r);
      pRowSet = hResult.first;
      if (!m_pFirst)
         m_pFirst = pRowSet;
      if (m_pLast)
         m_pLast->setPrevious(pRowSet);
      m_pLast = pRowSet;
   }
   else
   if (!pRowSet->closed())
      pRowSet->clear();
   char szTemp[15 + PERCENTD];
   Trace::put(szTemp,snprintf(szTemp,sizeof(szTemp),"RowSet size = %d",m_hRowSet.size()));
   return pRowSet;
  //## end database::RowCache::create%5ADE508C0321.body
}

database::RowCache* RowCache::instance ()
{
  //## begin database::RowCache::instance%5ADF1B7C010C.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new RowCache();
   return m_pInstance;
  //## end database::RowCache::instance%5ADF1B7C010C.body
}

bool RowCache::retrieve (const string& strName, reusable::Query& hQuery, int& iRows)
{
  //## begin database::RowCache::retrieve%5ADE512800E0.body preserve=yes
   UseCase hUseCase("DR","## DB57 RETRIEVE ROW SET");
   string strText("RowCache::retrieve : ");
   strText += strName;
   Trace::put(strText.data(),strText.length(),true);
   RowSet* pRowSet = 0;
   {
      CriticalSection hCriticalSection;
      RowSet r(strName);
      pRowSet = m_hRowSet.find(r);
      if (!pRowSet)
         return UseCase::setSuccess(false);
      if (!pRowSet->closed())
         return UseCase::setSuccess(false);
      pRowSet->setInUse(pRowSet->getInUse() + 1);
   }
   iRows = pRowSet->retrieve(hQuery);
   {
      CriticalSection hCriticalSection;
      pRowSet->setInUse(pRowSet->getInUse() - 1);
   }
   UseCase::addItem(iRows);
   return true;
  //## end database::RowCache::retrieve%5ADE512800E0.body
}

void RowCache::update (Subject* pSubject)
{
  //## begin database::RowCache::update%5ADE4EB50162.body preserve=yes
   UseCase hUseCase("DR","## DB57 AGE ROW SET");
   CriticalSection hCriticalSection;
   string strClock(Clock::instance()->getYYYYMMDDHHMMSS());
   string strDate("        000");
   strDate.replace(0,8,strClock.data(),8);
   string strTime(strClock.data() + 8,6);
   Timestamp::adjust(strDate,strTime,-10);
   strClock.replace(0,8,strDate.data(),8);
   strClock.replace(8,6,strTime.data(),6);
   while (m_hRowSet.size() > 1024)
   {
      if (m_pFirst->getClock() < strClock
         && m_pFirst->getInUse() == 0)
      {
         RowSet* p = m_pFirst;
         m_pFirst = m_pFirst->getPrevious();
         if (m_pFirst)
            m_pFirst->setNext(0);
         m_hRowSet.erase(*p);
         UseCase::addItem();
      }
      else
         break;
   }
  //## end database::RowCache::update%5ADE4EB50162.body
}

// Additional Declarations
  //## begin database::RowCache%5ADE4E7D0382.declarations preserve=yes
  //## end database::RowCache%5ADE4E7D0382.declarations

} // namespace database

//## begin module%5ADE4F200336.epilog preserve=yes
//## end module%5ADE4F200336.epilog
