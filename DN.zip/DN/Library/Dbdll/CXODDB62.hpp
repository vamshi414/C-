//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C0E97850141.cm preserve=no
//	$Date:   Jun 11 2019 07:37:46  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%5C0E97850141.cm

//## begin module%5C0E97850141.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C0E97850141.cp

//## Module: CXOSDB62%5C0E97850141; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB62.hpp

#ifndef CXOSDB62_h
#define CXOSDB62_h 1

//## begin module%5C0E97850141.additionalIncludes preserve=no
//## end module%5C0E97850141.additionalIncludes

//## begin module%5C0E97850141.includes preserve=yes
//## end module%5C0E97850141.includes

#ifndef CXOSDB61_h
#include "CXODDB61.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%5C0E97850141.declarations preserve=no
//## end module%5C0E97850141.declarations

//## begin module%5C0E97850141.additionalDeclarations preserve=yes
//## end module%5C0E97850141.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Query%5C0E96A601BF.preface preserve=yes
//## end database::Query%5C0E96A601BF.preface

//## Class: Query%5C0E96A601BF
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5C0E992A0119;DatabaseFactory { -> F}
//## Uses: <unnamed>%5C0E992C0220;reusable::SelectStatement { -> F}

class DllExport Query : public Delegate  //## Inherits: <unnamed>%5C0E96C2010B
{
  //## begin database::Query%5C0E96A601BF.initialDeclarations preserve=yes
  //## end database::Query%5C0E96A601BF.initialDeclarations

  public:
    //## Constructors (generated)
      Query();

    //## Constructors (specified)
      //## Operation: Query%5C0E96FD003C
      Query (const reusable::Query& hQuery);

    //## Destructor (generated)
      virtual ~Query();


    //## Other Operations (specified)
      //## Operation: execute%5C0E96D00320
      virtual void execute (vector<Object*>& hObject);

    // Additional Public Declarations
      //## begin database::Query%5C0E96A601BF.public preserve=yes
      //## end database::Query%5C0E96A601BF.public

  protected:
    // Additional Protected Declarations
      //## begin database::Query%5C0E96A601BF.protected preserve=yes
      //## end database::Query%5C0E96A601BF.protected

  private:
    // Additional Private Declarations
      //## begin database::Query%5C0E96A601BF.private preserve=yes
      //## end database::Query%5C0E96A601BF.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%5C0E973902E8
      //## Role: Query::<m_hQuery>%5C0E973A03B9
      //## begin database::Query::<m_hQuery>%5C0E973A03B9.role preserve=no  public: reusable::Query { -> VFHgN}
      reusable::Query m_hQuery;
      //## end database::Query::<m_hQuery>%5C0E973A03B9.role

    // Additional Implementation Declarations
      //## begin database::Query%5C0E96A601BF.implementation preserve=yes
      //## end database::Query%5C0E96A601BF.implementation

};

//## begin database::Query%5C0E96A601BF.postscript preserve=yes
//## end database::Query%5C0E96A601BF.postscript

} // namespace database

//## begin module%5C0E97850141.epilog preserve=yes
//## end module%5C0E97850141.epilog


#endif
