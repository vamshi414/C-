//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3EC3E2670196.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3EC3E2670196.cm

//## begin module%3EC3E2670196.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3EC3E2670196.cp

//## Module: CXOSDB10%3EC3E2670196; Package specification
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB10.hpp

#ifndef CXOSDB10_h
#define CXOSDB10_h 1

//## begin module%3EC3E2670196.additionalIncludes preserve=no
//## end module%3EC3E2670196.additionalIncludes

//## begin module%3EC3E2670196.includes preserve=yes
// $Date:   Jun 30 2006 11:35:24  $ $Author:   D02405  $ $Revision:   1.4  $
#include <map>
//## end module%3EC3E2670196.includes

#ifndef CXOSDB11_h
#include "CXODDB11.hpp"
#endif
#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseCatalogVisitor;

} // namespace database

//## begin module%3EC3E2670196.declarations preserve=no
//## end module%3EC3E2670196.declarations

//## begin module%3EC3E2670196.additionalDeclarations preserve=yes
//## end module%3EC3E2670196.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::DatabaseCatalog%3EC3DC16004E.preface preserve=yes
//## end database::DatabaseCatalog%3EC3DC16004E.preface

//## Class: DatabaseCatalog%3EC3DC16004E
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3EC3E1AD02DE;DatabaseCatalogVisitor { -> F}

class DllExport DatabaseCatalog : public reusable::Observer  //## Inherits: <unnamed>%3EC3E150031C
{
  //## begin database::DatabaseCatalog%3EC3DC16004E.initialDeclarations preserve=yes
  //## end database::DatabaseCatalog%3EC3DC16004E.initialDeclarations

  public:
    //## Constructors (generated)
      DatabaseCatalog();

    //## Destructor (generated)
      virtual ~DatabaseCatalog();


    //## Other Operations (specified)
      //## Operation: accept%3EC3E11C00CB
      void accept (database::DatabaseCatalogVisitor& hDatabaseCatalogVisitor);

      //## Operation: accept%3EC3E17101A5
      void accept (database::DatabaseCatalogVisitor& hDatabaseCatalogVisitor, const string& strTable);

      //## Operation: addTable%3EC3F91202BF
      map<string,DatabaseTable,less<string> >::iterator addTable (const string& strTable);

      //## Operation: getColumnCount%3EC3EB77036B
      int getColumnCount (const string& strTable);

      //## Operation: getTable%41F122DB01F4
      virtual bool getTable (const string& strPattern, const char* pszFunction, string& strTable);

      //## Operation: getTableCount%41F1227E01C5
      virtual int getTableCount (const string& strPattern);

      //## Operation: instance%3EC3E4960138
      static DatabaseCatalog* instance ();

      //## Operation: isExisting%41F11BB2004E
      virtual bool isExisting (const string& strTable);

      //## Operation: update%3EC3EFF00399
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin database::DatabaseCatalog%3EC3DC16004E.public preserve=yes
      //## end database::DatabaseCatalog%3EC3DC16004E.public

  protected:
    // Additional Protected Declarations
      //## begin database::DatabaseCatalog%3EC3DC16004E.protected preserve=yes
      //## end database::DatabaseCatalog%3EC3DC16004E.protected

  private:
    // Additional Private Declarations
      //## begin database::DatabaseCatalog%3EC3DC16004E.private preserve=yes
      //## end database::DatabaseCatalog%3EC3DC16004E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3EC3E4800186
      //## begin database::DatabaseCatalog::Instance%3EC3E4800186.attr preserve=no  private: static DatabaseCatalog* {V} 0
      static DatabaseCatalog* m_pInstance;
      //## end database::DatabaseCatalog::Instance%3EC3E4800186.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%3EC3E0DC00BB
      //## Role: DatabaseCatalog::<m_hDatabaseTable>%3EC3E0DD0109
      //## Qualifier: Name%3EC3E0E70271; string
      //## begin database::DatabaseCatalog::<m_hDatabaseTable>%3EC3E0DD0109.role preserve=no  public: database::DatabaseTable { -> VHgN}
      map<string, DatabaseTable, less<string> > m_hDatabaseTable;
      //## end database::DatabaseCatalog::<m_hDatabaseTable>%3EC3E0DD0109.role

    // Additional Implementation Declarations
      //## begin database::DatabaseCatalog%3EC3DC16004E.implementation preserve=yes
      //## end database::DatabaseCatalog%3EC3DC16004E.implementation

};

//## begin database::DatabaseCatalog%3EC3DC16004E.postscript preserve=yes
//## end database::DatabaseCatalog%3EC3DC16004E.postscript

} // namespace database

//## begin module%3EC3E2670196.epilog preserve=yes
using namespace database;
//## end module%3EC3E2670196.epilog


#endif
