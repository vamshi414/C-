//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41E9697D03C8.cm preserve=no
//	$Date:   Mar 23 2020 04:42:06  $ $Author:   e1014059  $ $Revision:   1.14  $
//## end module%41E9697D03C8.cm

//## begin module%41E9697D03C8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%41E9697D03C8.cp

//## Module: CXOSDB26%41E9697D03C8; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.0A.R003\ConnexPlatform\Server\Library\Dbdll\CXODDB26.hpp

#ifndef CXOSDB26_h
#define CXOSDB26_h 1

//## begin module%41E9697D03C8.additionalIncludes preserve=no
//## end module%41E9697D03C8.additionalIncludes

//## begin module%41E9697D03C8.includes preserve=yes
struct hExportFileAttributes
{
   char sDX_FILE_TYPE[7];
   char cSCHED_FREQUENCY;              // D = Daily, M = Monthly, N = Not scheduled
   char cClockType;                    // W = Wall Clock, S = Switch Clock
   char cSCHED_OFFSET;                 // A = absolute, C = CUTOFF_TIME
   char cAdjustDate;                   // Y/N (Y = start TSTAMP_INITIATED calculation from DATE_RECON - 1)
   char sTASK[3];
   int iFileClass;
};
#ifndef CXOSDB31_h
#include "CXODDB31.hpp"
#endif

//## end module%41E9697D03C8.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
class Query;
class SearchCondition;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class WitchingHour;
class BarTime;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Timestamp;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class SwitchClock;

} // namespace database

//## begin module%41E9697D03C8.declarations preserve=no
//## end module%41E9697D03C8.declarations

//## begin module%41E9697D03C8.additionalDeclarations preserve=yes
//## end module%41E9697D03C8.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::FileFactory%41E967D6001F.preface preserve=yes
//## end database::FileFactory%41E967D6001F.preface

//## Class: FileFactory%41E967D6001F
//	The FileFactory class provides an interface for creating
//	Export File related objects.
//
//	It is based on the AbstractFactory object of the Abstract
//	Factory pattern.
//
//	It is also based on the Singleton pattern.
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%453CE44F000F;Database { -> }
//## Uses: <unnamed>%453CE45F037A;timer::MidnightAlarm { -> }
//## Uses: <unnamed>%453CE4B201B5;timer::Date { -> }
//## Uses: <unnamed>%453CE53F0148;reusable::Query { -> F}
//## Uses: <unnamed>%453D0E7601A5;DatabaseFactory { -> F}
//## Uses: <unnamed>%453D0E770222;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%453D0E8C0290;IF::Extract { -> F}
//## Uses: <unnamed>%453D0E9A0000;SwitchClock { -> F}
//## Uses: <unnamed>%453D0EE8030D;monitor::UseCase { -> F}
//## Uses: <unnamed>%453E133502CE;IF::Timestamp { -> F}
//## Uses: <unnamed>%4591F7A601A3;reusable::SearchCondition { -> F}
//## Uses: <unnamed>%4591F7C701FC;reusable::Statement { -> F}
//## Uses: <unnamed>%55A65DD70097;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%55A65DED010C;timer::BarTime { -> F}
//## Uses: <unnamed>%55A65DF10165;timer::WitchingHour { -> F}

class DllExport FileFactory : public reusable::Observer  //## Inherits: <unnamed>%41F1709C005D
{
  //## begin database::FileFactory%41E967D6001F.initialDeclarations preserve=yes
  //## end database::FileFactory%41E967D6001F.initialDeclarations

  public:
    //## Constructors (generated)
      FileFactory();

    //## Destructor (generated)
      virtual ~FileFactory();


    //## Other Operations (specified)
      //## Operation: adjustDate%4541499201B5
      virtual void adjustDate (timer::Date& hDate);

      //## Operation: buildQuery%445A6502001D
      void buildQuery (reusable::Query& hQuery, char cEntityType, char cPeriodType, bool bOrderBy = false);

      //## Operation: create%41E97B7B03A9
      virtual database::ExportFile* create (const ExportFile& hExportFile) = 0;

      //## Operation: createInLists%4F7330AE018F
      void createInLists ();

      //## Operation: getClockFiles%4E833E08019C
      const string& getClockFiles (int iIndex = 0) const
      {
        //## begin database::FileFactory::getClockFiles%4E833E08019C.body preserve=yes
         return m_strClockFiles[iIndex];
        //## end database::FileFactory::getClockFiles%4E833E08019C.body
      }

      //## Operation: getStatus%455D08AC003E
      pair<string,int> getStatus (int iIndex);

      //## Operation: instance%41E9688702FD
      static FileFactory* instance (Object* pSender = 0);

      //## Operation: reset%4591EF380168
      bool reset (const char* pszInterval);

      //## Operation: update%41F170CD0157
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: DailyFiles%445A66F7003B
      const string& getDailyFiles () const
      {
        //## begin database::FileFactory::getDailyFiles%445A66F7003B.get preserve=no
        return m_strDailyFiles;
        //## end database::FileFactory::getDailyFiles%445A66F7003B.get
      }

      void setDailyFiles (const string& value)
      {
        //## begin database::FileFactory::setDailyFiles%445A66F7003B.set preserve=no
        m_strDailyFiles = value;
        //## end database::FileFactory::setDailyFiles%445A66F7003B.set
      }


      //## Attribute: MonthlyFiles%445A670D035E
      const string& getMonthlyFiles () const
      {
        //## begin database::FileFactory::getMonthlyFiles%445A670D035E.get preserve=no
        return m_strMonthlyFiles;
        //## end database::FileFactory::getMonthlyFiles%445A670D035E.get
      }

      void setMonthlyFiles (const string& value)
      {
        //## begin database::FileFactory::setMonthlyFiles%445A670D035E.set preserve=no
        m_strMonthlyFiles = value;
        //## end database::FileFactory::setMonthlyFiles%445A670D035E.set
      }


    // Additional Public Declarations
      //## begin database::FileFactory%41E967D6001F.public preserve=yes
      //## end database::FileFactory%41E967D6001F.public

  protected:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: DX_STATE%453CE9AB034B
      void setDX_STATE (const string& value)
      {
        //## begin database::FileFactory::setDX_STATE%453CE9AB034B.set preserve=no
        m_strDX_STATE = value;
        //## end database::FileFactory::setDX_STATE%453CE9AB034B.set
      }


    // Data Members for Class Attributes

      //## Attribute: Classes%41E9838400BB
      //## begin database::FileFactory::Classes%41E9838400BB.attr preserve=no  protected: map<string,int,less<string> > {VA} 
      map<string,int,less<string> > m_hClasses;
      //## end database::FileFactory::Classes%41E9838400BB.attr

      //## Attribute: ClockFiles%4E833FC1012E
      //## begin database::FileFactory::ClockFiles%4E833FC1012E.attr preserve=no  public: string[3] {V} 
      string m_strClockFiles[3];
      //## end database::FileFactory::ClockFiles%4E833FC1012E.attr

      //## Attribute: CUTOFF_TIME%430A27530280
      //## begin database::FileFactory::CUTOFF_TIME%430A27530280.attr preserve=no  protected: string[2] {VA} 
      string m_strCUTOFF_TIME[2];
      //## end database::FileFactory::CUTOFF_TIME%430A27530280.attr

      //## begin database::FileFactory::DailyFiles%445A66F7003B.attr preserve=no  public: string {V} "('XXXXXX')"
      string m_strDailyFiles;
      //## end database::FileFactory::DailyFiles%445A66F7003B.attr

      //## Attribute: DATE_RECON%430A2729035B
      //## begin database::FileFactory::DATE_RECON%430A2729035B.attr preserve=no  protected: string[2] {VA} 
      string m_strDATE_RECON[2];
      //## end database::FileFactory::DATE_RECON%430A2729035B.attr

      //## Attribute: DX_FILE_TYPE%430A272D029F
      //## begin database::FileFactory::DX_FILE_TYPE%430A272D029F.attr preserve=no  protected: string[2] {VA} 
      string m_strDX_FILE_TYPE[2];
      //## end database::FileFactory::DX_FILE_TYPE%430A272D029F.attr

      //## Attribute: DX_REPORT_ID%4E9C3BD00130
      //## begin database::FileFactory::DX_REPORT_ID%4E9C3BD00130.attr preserve=no  protected: int[2] {VA} 
      int m_iDX_REPORT_ID[2];
      //## end database::FileFactory::DX_REPORT_ID%4E9C3BD00130.attr

      //## Attribute: DX_REPORT_STAT%4ED62A7000B6
      //## begin database::FileFactory::DX_REPORT_STAT%4ED62A7000B6.attr preserve=no  protected: string[2] {UA} 
      string m_strDX_REPORT_STAT[2];
      //## end database::FileFactory::DX_REPORT_STAT%4ED62A7000B6.attr

      //## Attribute: ENTITY_ID%445A668A01C5
      //## begin database::FileFactory::ENTITY_ID%445A668A01C5.attr preserve=no  protected: string[2] {VA} 
      string m_strENTITY_ID[2];
      //## end database::FileFactory::ENTITY_ID%445A668A01C5.attr

      //## Attribute: EntityType%445A66BE0364
      //## begin database::FileFactory::EntityType%445A66BE0364.attr preserve=no  protected: string[2] {VA} 
      string m_strEntityType[2];
      //## end database::FileFactory::EntityType%445A66BE0364.attr

      //## Attribute: INST_ID%430A2730032C
      //## begin database::FileFactory::INST_ID%430A2730032C.attr preserve=no  protected: string[2] {VA} 
      string m_strINST_ID[2];
      //## end database::FileFactory::INST_ID%430A2730032C.attr

      //## begin database::FileFactory::MonthlyFiles%445A670D035E.attr preserve=no  public: string {V} "('XXXXXX')"
      string m_strMonthlyFiles;
      //## end database::FileFactory::MonthlyFiles%445A670D035E.attr

      //## Attribute: Null%453CD9AD032C
      //## begin database::FileFactory::Null%453CD9AD032C.attr preserve=no  protected: short int {VA} 0
      short int m_iNull;
      //## end database::FileFactory::Null%453CD9AD032C.attr

      //## Attribute: Period%445A66E00205
      //## begin database::FileFactory::Period%445A66E00205.attr preserve=no  protected: string[2] {VA} 
      string m_strPeriod[2];
      //## end database::FileFactory::Period%445A66E00205.attr

      //## Attribute: PROC_ID%430A27370109
      //## begin database::FileFactory::PROC_ID%430A27370109.attr preserve=no  protected: string[2] {VA} 
      string m_strPROC_ID[2];
      //## end database::FileFactory::PROC_ID%430A27370109.attr

      //## Attribute: ROUTING_DATA%430A273A005D
      //## begin database::FileFactory::ROUTING_DATA%430A273A005D.attr preserve=no  protected: string[2] {VA} 
      string m_strROUTING_DATA[2];
      //## end database::FileFactory::ROUTING_DATA%430A273A005D.attr

      //## Attribute: ROUTING_PASSWORD%430A273C0261
      //## begin database::FileFactory::ROUTING_PASSWORD%430A273C0261.attr preserve=no  protected: string[2] {VA} 
      string m_strROUTING_PASSWORD[2];
      //## end database::FileFactory::ROUTING_PASSWORD%430A273C0261.attr

      //## Attribute: ROUTING_TYPE%430A273F0167
      //## begin database::FileFactory::ROUTING_TYPE%430A273F0167.attr preserve=no  protected: string[2] {VA} 
      string m_strROUTING_TYPE[2];
      //## end database::FileFactory::ROUTING_TYPE%430A273F0167.attr

      //## Attribute: ROUTING_USER_ID%430A27420251
      //## begin database::FileFactory::ROUTING_USER_ID%430A27420251.attr preserve=no  protected: string[2] {VA} 
      string m_strROUTING_USER_ID[2];
      //## end database::FileFactory::ROUTING_USER_ID%430A27420251.attr

      //## Attribute: SCHED_FREQUENCY%430A2745005D
      //## begin database::FileFactory::SCHED_FREQUENCY%430A2745005D.attr preserve=no  protected: string[2] {VA} 
      string m_strSCHED_FREQUENCY[2];
      //## end database::FileFactory::SCHED_FREQUENCY%430A2745005D.attr

      //## Attribute: SCHED_OFFSET%452E0396026B
      //## begin database::FileFactory::SCHED_OFFSET%452E0396026B.attr preserve=no  protected: string[2] {VA} 
      string m_strSCHED_OFFSET[2];
      //## end database::FileFactory::SCHED_OFFSET%452E0396026B.attr

      //## Attribute: SCHED_OFFSET_TIME%430A27470251
      //## begin database::FileFactory::SCHED_OFFSET_TIME%430A27470251.attr preserve=no  protected: string[2] {VA} 
      string m_strSCHED_OFFSET_TIME[2];
      //## end database::FileFactory::SCHED_OFFSET_TIME%430A27470251.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%453CD9860222
      //## Role: FileFactory::<m_pExportFile>%453CD9870157
      //## begin database::FileFactory::<m_pExportFile>%453CD9870157.role preserve=no  protected: database::ExportFile { -> RHgAN}
      ExportFile *m_pExportFile;
      //## end database::FileFactory::<m_pExportFile>%453CD9870157.role

      //## Association: Connex Library::Database_CAT::<unnamed>%5E664A9903B2
      //## Role: FileFactory::<m_hCalendar>%5E664A9B039B
      //## begin database::FileFactory::<m_hCalendar>%5E664A9B039B.role preserve=no  public: database::Calendar { -> VHgN}
      Calendar m_hCalendar;
      //## end database::FileFactory::<m_hCalendar>%5E664A9B039B.role

    // Additional Protected Declarations
      //## begin database::FileFactory%41E967D6001F.protected preserve=yes
      map<string,struct hExportFileAttributes,less<string> > m_hFileDictionary;
      //## end database::FileFactory%41E967D6001F.protected
  private:
    // Additional Private Declarations
      //## begin database::FileFactory%41E967D6001F.private preserve=yes
      //## end database::FileFactory%41E967D6001F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin database::FileFactory::DX_STATE%453CE9AB034B.attr preserve=no  protected: string {V} 
      string m_strDX_STATE;
      //## end database::FileFactory::DX_STATE%453CE9AB034B.attr

      //## Attribute: Instance%41E9690A0280
      //## begin database::FileFactory::Instance%41E9690A0280.attr preserve=no  private: static FileFactory* {V} 0
      static FileFactory* m_pInstance;
      //## end database::FileFactory::Instance%41E9690A0280.attr

      //## Attribute: EVCLID%5E664B6601FC
      //## begin database::FileFactory::EVCLID%5E664B6601FC.attr preserve=no  private: string[2] {U} 
      string m_strEVCLID[2];
      //## end database::FileFactory::EVCLID%5E664B6601FC.attr

    // Additional Implementation Declarations
      //## begin database::FileFactory%41E967D6001F.implementation preserve=yes
      //## end database::FileFactory%41E967D6001F.implementation

};

//## begin database::FileFactory%41E967D6001F.postscript preserve=yes
//## end database::FileFactory%41E967D6001F.postscript

} // namespace database

//## begin module%41E9697D03C8.epilog preserve=yes
using namespace database;
//## end module%41E9697D03C8.epilog


#endif
