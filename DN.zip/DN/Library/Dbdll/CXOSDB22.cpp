//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3D80EA260186.cm preserve=no
//	$Date:   May 21 2020 09:06:12  $ $Author:   e1009510  $
//	$Revision:   1.20  $
//## end module%3D80EA260186.cm

//## begin module%3D80EA260186.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3D80EA260186.cp

//## Module: CXOSDB22%3D80EA260186; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\V02.9B.R001\ConnexPlatform\Server\Library\Dbdll\CXOSDB22.cpp

//## begin module%3D80EA260186.additionalIncludes preserve=no
//## end module%3D80EA260186.additionalIncludes

//## begin module%3D80EA260186.includes preserve=yes
// $Date:   May 21 2020 09:06:12  $ $Author:   e1009510  $ $Revision:   1.20  $
//## end module%3D80EA260186.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB22_h
#include "CXODDB22.hpp"
#endif


//## begin module%3D80EA260186.declarations preserve=no
//## end module%3D80EA260186.declarations

//## begin module%3D80EA260186.additionalDeclarations preserve=yes
//## end module%3D80EA260186.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::GenericDelete 

GenericDelete::GenericDelete()
  //## begin GenericDelete::GenericDelete%3D80EAFB0128_const.hasinit preserve=no
      : m_siMinimumRetentionDays(0),
        m_bNumeric(false),
        m_strQualifier("CUSTQUAL")
  //## end GenericDelete::GenericDelete%3D80EAFB0128_const.hasinit
  //## begin GenericDelete::GenericDelete%3D80EAFB0128_const.initialization preserve=yes
  //## end GenericDelete::GenericDelete%3D80EAFB0128_const.initialization
{
  //## begin database::GenericDelete::GenericDelete%3D80EAFB0128_const.body preserve=yes
   memcpy_s(m_sID,4,"DB22",4);
   m_hQuery.attach(this);
  //## end database::GenericDelete::GenericDelete%3D80EAFB0128_const.body
}

GenericDelete::GenericDelete (char *pszTableName)
  //## begin database::GenericDelete::GenericDelete%3D88C522004E.hasinit preserve=no
      : m_siMinimumRetentionDays(0),
        m_bNumeric(false),
        m_strQualifier("CUSTQUAL")
  //## end database::GenericDelete::GenericDelete%3D88C522004E.hasinit
  //## begin database::GenericDelete::GenericDelete%3D88C522004E.initialization preserve=yes
   ,m_strTableName(pszTableName)
  //## end database::GenericDelete::GenericDelete%3D88C522004E.initialization
{
  //## begin database::GenericDelete::GenericDelete%3D88C522004E.body preserve=yes
   memcpy_s(m_sID,4,"DB22",4);
   m_hQuery.attach(this);
  //## end database::GenericDelete::GenericDelete%3D88C522004E.body
}

GenericDelete::GenericDelete (char *pszTableName, char *pszKeyColumn, bool bNumeric, short siMinimumRetentionDays, char *szQualifier)
  //## begin database::GenericDelete::GenericDelete%3D8888700251.hasinit preserve=no
      : m_siMinimumRetentionDays(0),
        m_bNumeric(false),
        m_strQualifier("CUSTQUAL")
  //## end database::GenericDelete::GenericDelete%3D8888700251.hasinit
  //## begin database::GenericDelete::GenericDelete%3D8888700251.initialization preserve=yes
   ,m_strTableName(pszTableName)
   ,m_strKeyColumn(pszKeyColumn)
  //## end database::GenericDelete::GenericDelete%3D8888700251.initialization
{
  //## begin database::GenericDelete::GenericDelete%3D8888700251.body preserve=yes
   memcpy_s(m_sID,4,"DB22",4);
   m_bNumeric = bNumeric;
   m_siMinimumRetentionDays = siMinimumRetentionDays;
   m_strQualifier = szQualifier;
   m_hQuery.attach(this);
  //## end database::GenericDelete::GenericDelete%3D8888700251.body
}


GenericDelete::~GenericDelete()
{
  //## begin database::GenericDelete::~GenericDelete%3D80EAFB0128_dest.body preserve=yes
  //## end database::GenericDelete::~GenericDelete%3D80EAFB0128_dest.body
}



//## Other Operations (implementation)
void GenericDelete::deleteClosedRecords (const string& strYYYYMMDDHHMMSSHN)
{
  //## begin database::GenericDelete::deleteClosedRecords%5E4A52350134.body preserve=yes
   string strTemp;
   if (!IF::Extract::instance()->getSpec("DELCNTRY",strTemp))
      return;
   getDateFromDays(m_siMinimumRetentionDays);
   m_strDeleteDate.append(strYYYYMMDDHHMMSSHN.substr(8));
   m_hQuery.reset();
   m_hQuery.setDistinct(true);
   m_hQuery.setRetainCursor(true);
   m_hQuery.setQualifier(m_strQualifier.c_str(),m_strTableName.c_str());
   m_hQuery.bind(m_strTableName.c_str(),m_strKeyColumn.c_str(),Column::STRING,&m_strKey);
   m_hQuery.setBasicPredicate(m_strTableName.c_str(),"TSTAMP_UPDATED","<=",m_strDeleteDate.c_str());
   vector<string> hTokens;
   Buffer::parse(strTemp," ",hTokens);
   strTemp.assign("(");
   for (int i = 0;i < hTokens.size();++i)
   {
      strTemp += "'";
      strTemp += hTokens[i];
      strTemp += "',";
   }
   strTemp.replace(strTemp.length()-1,1,")");
   m_hQuery.setBasicPredicate(m_strTableName.c_str(),"COUNTRY_ISS","IN",strTemp.c_str());
   if (IF::Extract::instance()->getSpec("DELSTAT",strTemp))
   {
      Buffer::parse(strTemp," ",hTokens);
      strTemp.assign("(");
      for (int i = 0;i < hTokens.size();++i)
      {
         strTemp += "'";
         strTemp += hTokens[i];
         strTemp += "',";
      }
      strTemp.replace(strTemp.length()-1,1,")");
      m_hQuery.setBasicPredicate(m_strTableName.c_str(),"STATUS","IN",strTemp.c_str());
   }
   else
      m_hQuery.setBasicPredicate(m_strTableName.c_str(),"STATUS","LIKE","CL__");
   m_hQuery.setBasicPredicate(m_strTableName.c_str(),"REQUEST_TYPE","LIKE","CHB_");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(m_hQuery))
   {
      Database::instance()->rollback();
      UseCase::setSuccess(false);
   }
   Database::instance()->commit();
   return;
  //## end database::GenericDelete::deleteClosedRecords%5E4A52350134.body
}

bool GenericDelete::deleteRecords (char *szDateColumn, char *szRetentionPeriod)
{
  //## begin database::GenericDelete::deleteRecords%3D82154D0186.body preserve=yes
   string strTemp(szRetentionPeriod);
   if (strTemp.find("MONTH") != string::npos)
   {
      Date hDate(Date::today());
      short nYear(hDate.getYear());
      short nMonth(hDate.getMonth());
      short nRetentionMonths(atoi(szRetentionPeriod));
      if (nRetentionMonths < 1)
         return false;
      while (nRetentionMonths--)
      {
         if (nMonth == 1)
         {
            nMonth = 12;
            --nYear;
         }
         else
            --nMonth;
      }
      char szDeleteDate[9];
      snprintf(szDeleteDate,sizeof(szDeleteDate),"%04d%02d%02d",nYear,nMonth,hDate.getDay());
      m_strDeleteDate = szDeleteDate;
   }
   else
   if (strTemp.find("DAY") != string::npos)
   {
      int nRetentionDays = atoi(szRetentionPeriod);
      if (nRetentionDays < 0)
         return false;
      getDateFromDays(nRetentionDays);
   }
   else
   {
      m_strDeleteDate.reserve(28);
      m_strDeleteDate.assign(szRetentionPeriod,16);
      size_t pos = m_strDeleteDate.find_last_not_of(' ');
      m_strDeleteDate.erase(pos + 1);
      if (m_strDeleteDate.length() < 4)
         return false;
      m_strDeleteDate.append("0000");
      m_strDeleteDate.resize(8);
   }
   m_strDateColumn = szDateColumn;
   return deleteRecords();
  //## end database::GenericDelete::deleteRecords%3D82154D0186.body
}

bool GenericDelete::deleteRecords (char *szDateColumn, int nRetentionDays)
{
  //## begin database::GenericDelete::deleteRecords%3D80F76E007D.body preserve=yes
   if (nRetentionDays < 0)
      return false;
   getDateFromDays(nRetentionDays);
   m_strDateColumn = szDateColumn;
   return deleteRecords();
  //## end database::GenericDelete::deleteRecords%3D80F76E007D.body
}

bool GenericDelete::deleteRecords ()
{
  //## begin database::GenericDelete::deleteRecords%3D88A2100261.body preserve=yes
   m_hQuery.reset();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery.setDistinct(true);
   m_hQuery.setRetainCursor(true);
   m_hQuery.setQualifier(m_strQualifier.c_str(),m_strTableName.c_str());
   m_hQuery.bind(m_strTableName.c_str(),m_strKeyColumn.c_str(),Column::STRING,&m_strKey);
   m_hQuery.setBasicPredicate(m_strTableName.c_str(),m_strDateColumn.c_str(),"<",m_strDeleteDate.c_str());
   if (!pSelectStatement->execute(m_hQuery))
      UseCase::setSuccess(false);
   Database::instance()->commit();
   return UseCase::getSuccess();
  //## end database::GenericDelete::deleteRecords%3D88A2100261.body
}

void GenericDelete::getDateFromDays (int nRetentionDays)
{
  //## begin database::GenericDelete::getDateFromDays%3D88A587037A.body preserve=yes
   Date hDate(Date::today());
   hDate -= nRetentionDays;
   char szDeleteDate[9];
   snprintf(szDeleteDate,sizeof(szDeleteDate),"%04d%02d%02d",hDate.getYear(),hDate.getMonth(),hDate.getDay());
   m_strDeleteDate = szDeleteDate;
  //## end database::GenericDelete::getDateFromDays%3D88A587037A.body
}

void GenericDelete::update (Subject* pSubject)
{
  //## begin database::GenericDelete::update%3D8F60F50251.body preserve=yes
   Query hQuery;
   hQuery.setQualifier(m_strQualifier.c_str(),m_strTableName.c_str());
   hQuery.setBasicPredicate(m_strTableName.c_str(),m_strKeyColumn.c_str(),"=",m_strKey.c_str(),m_bNumeric);
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   if (!pDeleteStatement->execute(hQuery))
   {
      m_hQuery.setAbort(true);
      UseCase::setSuccess(false);
      return;
   }
   UseCase::addItem(pDeleteStatement->getRows());
   Database::instance()->commit();
  //## end database::GenericDelete::update%3D8F60F50251.body
}

// Additional Declarations
  //## begin database::GenericDelete%3D80EAFB0128.declarations preserve=yes
  //## end database::GenericDelete%3D80EAFB0128.declarations

} // namespace database

//## begin module%3D80EA260186.epilog preserve=yes
//## end module%3D80EA260186.epilog
