//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3EC3E2B303D8.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3EC3E2B303D8.cm

//## begin module%3EC3E2B303D8.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3EC3E2B303D8.cp

//## Module: CXOSDB11%3EC3E2B303D8; Package body
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB11.cpp

//## begin module%3EC3E2B303D8.additionalIncludes preserve=no
//## end module%3EC3E2B303D8.additionalIncludes

//## begin module%3EC3E2B303D8.includes preserve=yes
// $Date:   Apr 19 2016 06:37:34  $ $Author:   e1009839  $ $Revision:   1.11  $
#include "CXODRU19.hpp"
//## end module%3EC3E2B303D8.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB13_h
#include "CXODDB13.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB11_h
#include "CXODDB11.hpp"
#endif


//## begin module%3EC3E2B303D8.declarations preserve=no
//## end module%3EC3E2B303D8.declarations

//## begin module%3EC3E2B303D8.additionalDeclarations preserve=yes
//## end module%3EC3E2B303D8.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::DatabaseTable

DatabaseTable::DatabaseTable()
  //## begin DatabaseTable::DatabaseTable%3EC3DC8E007D_const.hasinit preserve=no
  //## end DatabaseTable::DatabaseTable%3EC3DC8E007D_const.hasinit
  //## begin DatabaseTable::DatabaseTable%3EC3DC8E007D_const.initialization preserve=yes
  //## end DatabaseTable::DatabaseTable%3EC3DC8E007D_const.initialization
{
  //## begin database::DatabaseTable::DatabaseTable%3EC3DC8E007D_const.body preserve=yes
   memcpy(m_sID,"DB11",4);
   m_bUpperCase = false;
  //## end database::DatabaseTable::DatabaseTable%3EC3DC8E007D_const.body
}

DatabaseTable::DatabaseTable(const DatabaseTable &right)
  //## begin DatabaseTable::DatabaseTable%3EC3DC8E007D_copy.hasinit preserve=no
  //## end DatabaseTable::DatabaseTable%3EC3DC8E007D_copy.hasinit
  //## begin DatabaseTable::DatabaseTable%3EC3DC8E007D_copy.initialization preserve=yes
   : m_strName(right.m_strName)
  //## end DatabaseTable::DatabaseTable%3EC3DC8E007D_copy.initialization
{
  //## begin database::DatabaseTable::DatabaseTable%3EC3DC8E007D_copy.body preserve=yes
   memcpy(m_sID,"DB11",4);
   m_hDatabaseColumns = right.m_hDatabaseColumns;
   m_bUpperCase = right.m_bUpperCase;
  //## end database::DatabaseTable::DatabaseTable%3EC3DC8E007D_copy.body
}

DatabaseTable::DatabaseTable (const string& strName)
  //## begin database::DatabaseTable::DatabaseTable%3EC4BC34030D.hasinit preserve=no
  //## end database::DatabaseTable::DatabaseTable%3EC4BC34030D.hasinit
  //## begin database::DatabaseTable::DatabaseTable%3EC4BC34030D.initialization preserve=yes
   : m_strName(strName)
  //## end database::DatabaseTable::DatabaseTable%3EC4BC34030D.initialization
{
  //## begin database::DatabaseTable::DatabaseTable%3EC4BC34030D.body preserve=yes
   memcpy(m_sID,"DB11",4);
   m_bUpperCase = false;
   string strDBVendor;
   Extract::instance()->getSpec("DBVENDOR",strDBVendor);
   Query hQuery;
   hQuery.attach(this);
   string strTemp;
   Extract::instance()->getSpec("CUSTQUAL",strTemp);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (strDBVendor == "SQLSERVER")
   {
      hQuery.setQualifier("SYS","COLUMNS");
      hQuery.setQualifier("SYS","TYPES");
      hQuery.setQualifier("SYS","INDEX_COLUMNS");
      hQuery.join("COLUMNS","INNER","TYPES","USER_TYPE_ID");
      hQuery.join("COLUMNS","LEFT OUTER","INDEX_COLUMNS","OBJECT_ID");
      hQuery.join("COLUMNS","LEFT OUTER","INDEX_COLUMNS","COLUMN_ID");
      m_hDatabaseColumn.bind(hQuery);
      hQuery.getSearchCondition().append("COLUMNS.OBJECT_ID = OBJECT_ID('");
      hQuery.getSearchCondition().append(Extract::instance()->getQualify());
      hQuery.getSearchCondition().append(".");
      hQuery.getSearchCondition().append(strName);
      hQuery.getSearchCondition().append("')");
      if (!strTemp.empty())
      {
         hQuery.getSearchCondition().append(" OR COLUMNS.OBJECT_ID = OBJECT_ID('");
         hQuery.getSearchCondition().append(strTemp);
         hQuery.getSearchCondition().append(".");
         hQuery.getSearchCondition().append(strName);
         hQuery.getSearchCondition().append("')");
      }
   }
   else
   if (strDBVendor == "ORACLE")
   {
      hQuery.setSubSelect(true);
      hQuery.setQualifier("SYS","ALL_CONSTRAINTS");
      hQuery.setQualifier("SYS","ALL_CONS_COLUMNS");
      hQuery.join("ALL_CONSTRAINTS","INNER","ALL_CONS_COLUMNS","OWNER");
      hQuery.join("ALL_CONSTRAINTS","INNER","ALL_CONS_COLUMNS","TABLE_NAME");
      hQuery.join("ALL_CONSTRAINTS","INNER","ALL_CONS_COLUMNS","CONSTRAINT_NAME");
      hQuery.bind("ALL_CONS_COLUMNS","COLUMN_NAME",Column::STRING,(void*)0);
      hQuery.bind("ALL_CONS_COLUMNS","POSITION",Column::STRING,(void*)0);
      hQuery.getSearchCondition().append("(");
      hQuery.setBasicPredicate("ALL_CONSTRAINTS","OWNER","=",Extract::instance()->getQualify().c_str());
      if (!strTemp.empty())
         hQuery.setBasicPredicate("ALL_CONSTRAINTS","OWNER","=",strTemp.c_str(),false,false);
      hQuery.getSearchCondition().append(")");
      hQuery.setBasicPredicate("ALL_CONSTRAINTS","TABLE_NAME","=",strName.c_str());
      hQuery.setBasicPredicate("ALL_CONSTRAINTS","CONSTRAINT_TYPE","=","P");
      auto_ptr<FormatSelectVisitor> pFormatSelectVisitor((FormatSelectVisitor*)DatabaseFactory::instance()->create("FormatSelectVisitor"));
      hQuery.accept(*pFormatSelectVisitor);
      string strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ") X";
      hQuery.reset();
      hQuery.setQualifier("SYS","ALL_TAB_COLUMNS");
      hQuery.join("ALL_TAB_COLUMNS","LEFT OUTER",strSubSelect.c_str(),"COLUMN_NAME");
      m_hDatabaseColumn.bind(hQuery);
      hQuery.bind(strSubSelect.c_str(),"POSITION",Column::STRING,&m_hDatabaseColumn.getKeySequence());
      hQuery.getSearchCondition().append("(");
      hQuery.setBasicPredicate("ALL_TAB_COLUMNS","OWNER","=",Extract::instance()->getQualify().c_str());
      if (!strTemp.empty())
         hQuery.setBasicPredicate("ALL_TAB_COLUMNS","OWNER","=",strTemp.c_str(),false,false);
      hQuery.getSearchCondition().append(")");
      hQuery.setBasicPredicate("ALL_TAB_COLUMNS","TABLE_NAME","=",strName.c_str());
   }
   else 
   if (strDBVendor == "POSTGRES")
   {
      m_bUpperCase = true;
      string strQualify;
      Extract::instance()->getSpec("QUALIFY",strQualify);
      transform(strQualify.begin(),strQualify.end(),strQualify.begin(),::tolower);
      transform(m_strName.begin(),m_strName.end(),m_strName.begin(),::tolower);
      transform(strTemp.begin(),strTemp.end(),strTemp.begin(),::tolower);
      hQuery.setSubSelect(true);
      hQuery.setQualifier("information_schema","key_column_usage");
      hQuery.bind("key_column_usage","column_name",Column::STRING,(void*)0);
      hQuery.bind("key_column_usage","constraint_name",Column::STRING,(void*)0);
      hQuery.bind("key_column_usage","ordinal_position",Column::LONG,(void*)0);
      hQuery.getSearchCondition().append("(");
      hQuery.setBasicPredicate("key_column_usage","constraint_schema","=",strQualify.c_str());
      if (!strTemp.empty())
         hQuery.setBasicPredicate("key_column_usage","constraint_schema","=",strTemp.c_str(),false,false);
      hQuery.getSearchCondition().append(")");
      hQuery.setBasicPredicate("key_column_usage","table_name","=",m_strName.c_str());
      hQuery.setBasicPredicate("key_column_usage","constraint_name","like","x0%");
      auto_ptr<FormatSelectVisitor> pFormatSelectVisitor((FormatSelectVisitor*)DatabaseFactory::instance()->create("FormatSelectVisitor"));
      hQuery.accept(*pFormatSelectVisitor);
      string strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ") X";
      hQuery.reset();
      hQuery.setQualifier("information_schema","columns");
      hQuery.join("columns","LEFT OUTER",strSubSelect.c_str(),"COLUMN_NAME");
      m_hDatabaseColumn.bind(hQuery);
      hQuery.getSearchCondition().append("(");
      hQuery.setBasicPredicate("columns","table_schema","=",strQualify.c_str());
      if (!strTemp.empty())
         hQuery.setBasicPredicate("columns","table_schema","=",strTemp.c_str(),false,false);
      hQuery.getSearchCondition().append(")");
      hQuery.setBasicPredicate("columns","TABLE_NAME","=",m_strName.c_str());
   }
   else
   {
#ifdef MVS
      char* pszQualifier = "SYSIBM";
      char* pszColumns = "SYSCOLUMNS";
      char* pszName = "TBNAME";
      char* pszCreator = "TBCREATOR";
      char* pszDBName = "DBNAME";
#else
      char* pszQualifier = "SYSCAT";
      char* pszColumns = "COLUMNS";
      char* pszName = "TABNAME";
      char* pszCreator = "TABSCHEMA";
      char* pszDBName = "DEFINER";
#endif
      hQuery.setQualifier(pszQualifier,pszColumns);
      m_hDatabaseColumn.bind(hQuery);
      hQuery.getSearchCondition().append("(");
      hQuery.setBasicPredicate(pszColumns,pszCreator,"=",Extract::instance()->getQualify().c_str());
      if (!strTemp.empty())
         hQuery.setBasicPredicate(pszColumns,pszCreator,"=",strTemp.c_str(),false,false);
      hQuery.getSearchCondition().append(")");
      hQuery.setBasicPredicate(pszColumns,pszName,"=",strName.c_str());
   }
   pSelectStatement->execute(hQuery);
  //## end database::DatabaseTable::DatabaseTable%3EC4BC34030D.body
}


DatabaseTable::~DatabaseTable()
{
  //## begin database::DatabaseTable::~DatabaseTable%3EC3DC8E007D_dest.body preserve=yes
  //## end database::DatabaseTable::~DatabaseTable%3EC3DC8E007D_dest.body
}


DatabaseTable & DatabaseTable::operator=(const DatabaseTable &right)
{
  //## begin database::DatabaseTable::operator=%3EC3DC8E007D_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_strName = right.m_strName;
   m_hDatabaseColumns = right.m_hDatabaseColumns;
   return *this;
  //## end database::DatabaseTable::operator=%3EC3DC8E007D_assign.body
}



//## Other Operations (implementation)
void DatabaseTable::accept (DatabaseCatalogVisitor& hDatabaseCatalogVisitor)
{
  //## begin database::DatabaseTable::accept%3EC3E9C4034B.body preserve=yes
   hDatabaseCatalogVisitor.visitDatabaseTable(this);
   map<string,DatabaseColumn,less<string> >::iterator p;
   for (p = m_hDatabaseColumns.begin();p != m_hDatabaseColumns.end();++p)
      (*p).second.accept(hDatabaseCatalogVisitor);
  //## end database::DatabaseTable::accept%3EC3E9C4034B.body
}

void DatabaseTable::bind (Query& hQuery)
{
  //## begin database::DatabaseTable::bind%3EC3E448031C.body preserve=yes
  //## end database::DatabaseTable::bind%3EC3E448031C.body
}

int DatabaseTable::getColumnCount ()
{
  //## begin database::DatabaseTable::getColumnCount%3EC3F9FE0271.body preserve=yes
   return (int)m_hDatabaseColumns.size();
  //## end database::DatabaseTable::getColumnCount%3EC3F9FE0271.body
}

void DatabaseTable::update (Subject* pSubject)
{
  //## begin database::DatabaseTable::update%3EC3F0100109.body preserve=yes
   if (m_bUpperCase)
      transform(m_strName.begin(), m_strName.end(), m_strName.begin(), ::toupper);
   m_hDatabaseColumn.update(pSubject);
   m_hDatabaseColumns[m_hDatabaseColumn.getName()] = m_hDatabaseColumn;
  //## end database::DatabaseTable::update%3EC3F0100109.body
}

// Additional Declarations
  //## begin database::DatabaseTable%3EC3DC8E007D.declarations preserve=yes
  //## end database::DatabaseTable%3EC3DC8E007D.declarations

} // namespace database

//## begin module%3EC3E2B303D8.epilog preserve=yes
//## end module%3EC3E2B303D8.epilog
