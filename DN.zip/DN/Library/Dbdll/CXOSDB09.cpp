//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%378B5E2D020A.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%378B5E2D020A.cm

//## begin module%378B5E2D020A.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%378B5E2D020A.cp

//## Module: CXOSDB09%378B5E2D020A; Package body
//## Subsystem: DBDLL%35758D89000D
// .
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXOSDB09.cpp

//## begin module%378B5E2D020A.additionalIncludes preserve=no
//## end module%378B5E2D020A.additionalIncludes

//## begin module%378B5E2D020A.includes preserve=yes
// $Date:   Jun 05 2014 02:50:22  $ $Author:   e1014059  $ $Revision:   1.3  $
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
//## end module%378B5E2D020A.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB09_h
#include "CXODDB09.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif


//## begin module%378B5E2D020A.declarations preserve=no
//## end module%378B5E2D020A.declarations

//## begin module%378B5E2D020A.additionalDeclarations preserve=yes
//## end module%378B5E2D020A.additionalDeclarations


//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::CRInstitution
































CRInstitution::CRInstitution()
  //## begin CRInstitution::CRInstitution%378B5B020023_const.hasinit preserve=no
  //## end CRInstitution::CRInstitution%378B5B020023_const.hasinit
  //## begin CRInstitution::CRInstitution%378B5B020023_const.initialization preserve=yes
  //## end CRInstitution::CRInstitution%378B5B020023_const.initialization
{
  //## begin database::CRInstitution::CRInstitution%378B5B020023_const.body preserve=yes
   memcpy(m_sID,"DB09",4);
   reset();
  //## end database::CRInstitution::CRInstitution%378B5B020023_const.body
}


CRInstitution::~CRInstitution()
{
  //## begin database::CRInstitution::~CRInstitution%378B5B020023_dest.body preserve=yes
  //## end database::CRInstitution::~CRInstitution%378B5B020023_dest.body
}



//## Other Operations (implementation)
bool CRInstitution::name (const string& strINST_ID, string& strNAME)
{
  //## begin database::CRInstitution::name%378B6A200186.body preserve=yes
   Query hQuery;
   hQuery.setQualifier("QUALIFY","INSTITUTION");
   hQuery.bind("INSTITUTION","NAME",Column::STRING,&strNAME);
   hQuery.setBasicPredicate("INSTITUTION","INST_ID","=",strINST_ID.c_str());
   hQuery.setBasicPredicate("INSTITUTION","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("INSTITUTION","CC_STATE","IN","('A','I')");
   string strCUST_ID;
   if (Transaction::instance()->getQualifier() == "CUSTQUAL")
      Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   else
      strCUST_ID = Transaction::instance()->getCustomer().c_str();
   hQuery.setBasicPredicate("INSTITUTION","CUST_ID","=",strCUST_ID.c_str());
   SelectStatement* pSelectStatement = (SelectStatement*)DatabaseFactory::instance()->create("SelectStatement");
   pSelectStatement->execute(hQuery);
   bool bReturn = (pSelectStatement->getRows() > 0);
   delete pSelectStatement;
   return bReturn;
  //## end database::CRInstitution::name%378B6A200186.body
}

bool CRInstitution::put ()
{
  //## begin database::CRInstitution::put%378B5C5501E3.body preserve=yes
   return false;
  //## end database::CRInstitution::put%378B5C5501E3.body
}

void CRInstitution::reset ()
{
  //## begin database::CRInstitution::reset%378B5C6701CB.body preserve=yes
   char szBlanks[35];
   memset(szBlanks,' ',sizeof(szBlanks));
   m_strINST_ID.set(szBlanks,11);
   m_strINST_STAT.set(szBlanks,1);
   m_strCUST_ID.set(szBlanks,4);
   m_strCUST_STAT.set(szBlanks,1);
   m_strCC_CHANGE_GRP_ID.set(szBlanks,8);
   m_strPROC_ID.set(szBlanks,8);
   m_strPROC_STAT.set(szBlanks,1);
   m_strCC_STATE.set(szBlanks,1);
   m_strCC_LAST_OPERATION.set(szBlanks,3);
   m_strCC_USER_ID.set(szBlanks,8);
   m_strCC_TSTAMP_CHANGE.set(szBlanks,14);
   m_strNAME.set(szBlanks,35);
   m_strADJUST_INST_ID.set(szBlanks,11);
   m_strADJUST_ACCT_ID.set(szBlanks,28);
   m_strADJUST_ACCT_TYPE.set(szBlanks,2);
   m_strONLINE_FEE_INST_ID.set(szBlanks,11);
   m_strONLINE_FEE_ACCT_ID.set(szBlanks,28);
   m_strONLN_FEE_ACCT_TYPE.set(szBlanks,2);
   m_strFEE_BILL_INST_ID.set(szBlanks,11);
   m_strFEE_BILL_ACCT_ID.set(szBlanks,28);
   m_strFEE_BILL_ACCT_TYPE.set(szBlanks,2);
   m_strSETL_INST_ID.set(szBlanks,11);
   m_strSETL_ACCT_NO.set(szBlanks,28);
   m_strSETL_ACCT_TYPE.set(szBlanks,2);
   m_strFUNDS_MOVEMENT_OPT.set(szBlanks,2);
   m_strSERVICE_LINE.set(szBlanks,2);
   m_strCUTOFF_IND.set(szBlanks,1);
   m_strCUTOFF_TIME.set(szBlanks,8);
   m_strCUTOFF_START_TIME.set(szBlanks,8);
   m_strCUTOFF_COPY_FLG.set(szBlanks,1);
   m_strBILL_INTERCHG_GRP.set(szBlanks,2);
  //## end database::CRInstitution::reset%378B5C6701CB.body
}

// Additional Declarations
  //## begin database::CRInstitution%378B5B020023.declarations preserve=yes
  //## end database::CRInstitution%378B5B020023.declarations

} // namespace database

//## begin module%378B5E2D020A.epilog preserve=yes
//## end module%378B5E2D020A.epilog
