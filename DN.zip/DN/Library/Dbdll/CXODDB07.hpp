//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3715EEAE03D7.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3715EEAE03D7.cm

//## begin module%3715EEAE03D7.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3715EEAE03D7.cp

//## Module: CXOSDB07%3715EEAE03D7; Package specification
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXODDB07.hpp

#ifndef CXOSDB07_h
#define CXOSDB07_h 1

//## begin module%3715EEAE03D7.additionalIncludes preserve=no
//## end module%3715EEAE03D7.additionalIncludes

//## begin module%3715EEAE03D7.includes preserve=yes
// $Date:   Apr 08 2004 10:16:48  $ $Author:   D02405  $ $Revision:   1.2  $
#include "CXODRU24.hpp"
//## end module%3715EEAE03D7.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%3715EEAE03D7.declarations preserve=no
//## end module%3715EEAE03D7.declarations

//## begin module%3715EEAE03D7.additionalDeclarations preserve=yes
//## end module%3715EEAE03D7.additionalDeclarations


//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::TransactionRemover%34C3A79F0094.preface preserve=yes
//## end database::TransactionRemover%34C3A79F0094.preface

//## Class: TransactionRemover%34C3A79F0094
//	The TransactionRemover class encapsulates the process of
//	deleting transactions from the STS short term
//	repository..
//
//	CXODDB07.hpp
//	CXOSDB07.cpp
//## Category: DataNavigator Foundation::Database_CAT%3451F34D0218
//## Subsystem: DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class DllExport TransactionRemover : public reusable::Object  //## Inherits: <unnamed>%34EDE2B1030C
{
  //## begin database::TransactionRemover%34C3A79F0094.initialDeclarations preserve=yes
  //## end database::TransactionRemover%34C3A79F0094.initialDeclarations

  public:
    //## Constructors (generated)
      TransactionRemover();

    //## Destructor (generated)
      virtual ~TransactionRemover();


    //## Other Operations (specified)
      //## Operation: remove%34C3ACBE011C
      //	Remove the next set of transactions within the specified
      //	time range.  Return:
      //
      //	    -1 if there is a failure.
      //	    0 if there are more rows to delete.
      //	    1 if there are no more rows to delete.
      virtual int remove () = 0;

      //## Operation: setTableName%34C3B094011E
      //## Semantics:
      //	1. m_strTableName = pszTableName.
      void setTableName (const char* pszTableName)
      {
        //## begin database::TransactionRemover::setTableName%34C3B094011E.body preserve=yes
        m_strTableName = pszTableName;
        //## end database::TransactionRemover::setTableName%34C3B094011E.body
      }

      //## Operation: setTimeRange%34C3AEDC0388
      //	Establish the start and end timestamps for the current
      //	remove process.
      //## Semantics:
      //	1. m_strTimestampStart = pszTimestampStart.
      //	2. m_strTimestampEnd = pszTimestampEnd.
      virtual void setTimeRange (const char* pszTimestampStart, const char* pszTimestampEnd) = 0;

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Type%3856B08101AB
      void setType (char value)
      {
        //## begin database::TransactionRemover::setType%3856B08101AB.set preserve=no
        m_cType = value;
        //## end database::TransactionRemover::setType%3856B08101AB.set
      }


    // Additional Public Declarations
      //## begin database::TransactionRemover%34C3A79F0094.public preserve=yes
      //## end database::TransactionRemover%34C3A79F0094.public

  protected:
    // Data Members for Class Attributes

      //## begin database::TransactionRemover::Type%3856B08101AB.attr preserve=no  public: char {U} ' '
      char m_cType;
      //## end database::TransactionRemover::Type%3856B08101AB.attr

      //## Attribute: TableName%34C3B05000EE
      //	The table name in the STS short term repository.
      //## begin database::TransactionRemover::TableName%34C3B05000EE.attr preserve=no  protected: IString {U} 
      IString m_strTableName;
      //## end database::TransactionRemover::TableName%34C3B05000EE.attr

      //## Attribute: TimestampEnd%34C3B05602A5
      //	The ending timestamp for the current remove process.
      //## begin database::TransactionRemover::TimestampEnd%34C3B05602A5.attr preserve=no  protected: IString {U} 
      IString m_strTimestampEnd;
      //## end database::TransactionRemover::TimestampEnd%34C3B05602A5.attr

      //## Attribute: TimestampStart%34C3B05E0224
      //	The starting timestamp for the current remove process.
      //## begin database::TransactionRemover::TimestampStart%34C3B05E0224.attr preserve=no  protected: IString {U} 
      IString m_strTimestampStart;
      //## end database::TransactionRemover::TimestampStart%34C3B05E0224.attr

    // Additional Protected Declarations
      //## begin database::TransactionRemover%34C3A79F0094.protected preserve=yes
      //## end database::TransactionRemover%34C3A79F0094.protected

  private:
    // Additional Private Declarations
      //## begin database::TransactionRemover%34C3A79F0094.private preserve=yes
      //## end database::TransactionRemover%34C3A79F0094.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::TransactionRemover%34C3A79F0094.implementation preserve=yes
      //## end database::TransactionRemover%34C3A79F0094.implementation

};

//## begin database::TransactionRemover%34C3A79F0094.postscript preserve=yes
//## end database::TransactionRemover%34C3A79F0094.postscript

} // namespace database

//## begin module%3715EEAE03D7.epilog preserve=yes
using namespace database;
//## end module%3715EEAE03D7.epilog


#endif
