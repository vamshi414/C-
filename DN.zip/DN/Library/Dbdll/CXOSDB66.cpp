//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EC21A2701EB.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%5EC21A2701EB.cm

//## begin module%5EC21A2701EB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5EC21A2701EB.cp

//## Module: CXOSDB66%5EC21A2701EB; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB66.cpp

//## begin module%5EC21A2701EB.additionalIncludes preserve=no
//## end module%5EC21A2701EB.additionalIncludes

//## begin module%5EC21A2701EB.includes preserve=yes
//## end module%5EC21A2701EB.includes

#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSDB66_h
#include "CXODDB66.hpp"
#endif


//## begin module%5EC21A2701EB.declarations preserve=no
//## end module%5EC21A2701EB.declarations

//## begin module%5EC21A2701EB.additionalDeclarations preserve=yes
#define STS_RECORD_NOT_FOUND 14
//## end module%5EC21A2701EB.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::Generation 

Generation::Generation()
  //## begin Generation::Generation%5EC218E00394_const.hasinit preserve=no
      : m_iFILE_SIZE(0),
        m_iGDG_NUMBER(0),
        m_iGDG_PROGRESS(0),
        m_iNull(-1),
        m_iRECORD_COUNT(0)
  //## end Generation::Generation%5EC218E00394_const.hasinit
  //## begin Generation::Generation%5EC218E00394_const.initialization preserve=yes
  //## end Generation::Generation%5EC218E00394_const.initialization
{
  //## begin database::Generation::Generation%5EC218E00394_const.body preserve=yes
   memcpy(m_sID,"DB66",4);
  //## end database::Generation::Generation%5EC218E00394_const.body
}

Generation::Generation (const reusable::string strIMAGEID, const reusable::string strTASKID, const reusable::string strGDG_TYPE)
  //## begin database::Generation::Generation%5EC2235F0008.hasinit preserve=no
      : m_iFILE_SIZE(0),
        m_iGDG_NUMBER(0),
        m_iGDG_PROGRESS(0),
        m_iNull(-1),
        m_iRECORD_COUNT(0)
  //## end database::Generation::Generation%5EC2235F0008.hasinit
  //## begin database::Generation::Generation%5EC2235F0008.initialization preserve=yes
   ,m_strIMAGEID(strIMAGEID)
   ,m_strTASKID(strTASKID)
   ,m_strGDG_FILE_TYPE(strGDG_TYPE)
  //## end database::Generation::Generation%5EC2235F0008.initialization
{
  //## begin database::Generation::Generation%5EC2235F0008.body preserve=yes
   memcpy(m_sID,"DB66",4);
  //## end database::Generation::Generation%5EC2235F0008.body
}


Generation::~Generation()
{
  //## begin database::Generation::~Generation%5EC218E00394_dest.body preserve=yes
  //## end database::Generation::~Generation%5EC218E00394_dest.body
}



//## Other Operations (implementation)
bool Generation::commit ()
{
  //## begin database::Generation::commit%5EC22A8D0018.body preserve=yes
   m_strGDG_STATE = "IC";
   m_strTSTAMP_CLOSE.assign(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   return save();
  //## end database::Generation::commit%5EC22A8D0018.body
}

bool Generation::isDuplicate (const reusable::string& strHash)
{
  //## begin database::Generation::isDuplicate%5EC52C5102F5.body preserve=yes
   int iCount = 0;
   Query hQuery;
   hQuery.bind("GDG_DATA_CONTROL", "*", Column::LONG, &iCount, 0, "COUNT");
   hQuery.setBasicPredicate("GDG_DATA_CONTROL", "IMAGEID", "=", m_strIMAGEID.c_str());
   hQuery.setBasicPredicate("GDG_DATA_CONTROL", "TASKID", "=", m_strTASKID.c_str());
   hQuery.setBasicPredicate("GDG_DATA_CONTROL", "GDG_FILE_TYPE", "=", m_strGDG_FILE_TYPE.c_str());
   hQuery.setBasicPredicate("GDG_DATA_CONTROL", "GDG_PATH", "=", m_strGDG_PATH.c_str());
   hQuery.setBasicPredicate("GDG_DATA_CONTROL", "FILE_HASH", "=", strHash.c_str());
   hQuery.setBasicPredicate("GDG_DATA_CONTROL", "GDG_STATE", "=", "IC");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   return (iCount > 0);
  //## end database::Generation::isDuplicate%5EC52C5102F5.body
}

bool Generation::open ()
{
  //## begin database::Generation::open%5EC22F930254.body preserve=yes
   m_iNull = -1;
   Query hQuery;
   hQuery.bind("GDG_DATA_CONTROL", "GDG_NUMBER", Column::LONG, &m_iGDG_NUMBER, &m_iNull);
   hQuery.bind("GDG_DATA_CONTROL", "FILE_SIZE", Column::LONG, &m_iFILE_SIZE);
   hQuery.bind("GDG_DATA_CONTROL", "GDG_PROGRESS", Column::LONG, &m_iGDG_PROGRESS);
   hQuery.bind("GDG_DATA_CONTROL", "RECORD_COUNT", Column::LONG, &m_iRECORD_COUNT);
   hQuery.bind("GDG_DATA_CONTROL", "GDG_PATH", Column::STRING, &m_strGDG_PATH);
   hQuery.bind("GDG_DATA_CONTROL", "GDG_STATE", Column::STRING, &m_strGDG_STATE);
   hQuery.bind("GDG_DATA_CONTROL", "REPORT_DATE", Column::STRING, &m_strREPORT_DATE);
   hQuery.bind("GDG_DATA_CONTROL", "REPORT_NAME", Column::STRING, &m_strREPORT_NAME);
   hQuery.bind("GDG_DATA_CONTROL", "TSTAMP_OPEN", Column::STRING, &m_strTSTAMP_OPEN);
   hQuery.bind("GDG_DATA_CONTROL", "TSTAMP_CLOSE", Column::STRING, &m_strTSTAMP_CLOSE);
   hQuery.bind("GDG_DATA_CONTROL", "FILE_HASH", Column::STRING, &m_strFILE_HASH);
   hQuery.setBasicPredicate("GDG_DATA_CONTROL", "IMAGEID", "=", m_strIMAGEID.c_str());
   hQuery.setBasicPredicate("GDG_DATA_CONTROL", "TASKID", "=", m_strTASKID.c_str());
   hQuery.setBasicPredicate("GDG_DATA_CONTROL", "GDG_FILE_TYPE", "=", m_strGDG_FILE_TYPE.c_str());
   hQuery.setOrderByClause("TSTAMP_OPEN DESC");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.setAbort(true);
   bool b = pSelectStatement->execute(hQuery);
   if (m_strGDG_STATE == "IC")
   {
      int iGDGNumber = m_iGDG_NUMBER + 1;
      reset();
      m_iGDG_NUMBER = iGDGNumber;
      if (m_iGDG_NUMBER > 9999)
         m_iGDG_NUMBER = 1;
   }
   else
   if (m_iNull == -1)
   {
      reset();
      m_iGDG_NUMBER = 1;
   }
   Database::instance()->setTransactionState(b ? Database::COMMITREQUIRED : Database::ROLLBACKREQUIRED);
   return b;
  //## end database::Generation::open%5EC22F930254.body
}

void Generation::reset ()
{
  //## begin database::Generation::reset%5EC36BB30037.body preserve=yes
   m_iFILE_SIZE = 0;
   m_iGDG_NUMBER = 0;
   m_iGDG_PROGRESS = 0;
   m_iRECORD_COUNT = 0;
   m_strFILE_HASH.erase();
   m_strGDG_PATH.erase();
   m_strGDG_STATE = "II";
   m_strREPORT_DATE.erase();
   m_strREPORT_NAME.erase();
   m_strTSTAMP_CLOSE.erase();
   m_strTSTAMP_OPEN.assign(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
  //## end database::Generation::reset%5EC36BB30037.body
}

bool Generation::save ()
{
  //## begin database::Generation::save%5EC2942D026B.body preserve=yes
   Table hTable("GDG_DATA_CONTROL");
   hTable.set("GDG_NUMBER", m_iGDG_NUMBER, true);
   hTable.set("IMAGEID", m_strIMAGEID, false,true);
   hTable.set("TASKID", m_strTASKID,false, true);
   hTable.set("GDG_FILE_TYPE", m_strGDG_FILE_TYPE, false, true);
   hTable.set("REPORT_DATE", m_strREPORT_DATE);
   hTable.set("REPORT_NAME", m_strREPORT_NAME);
   hTable.set("FILE_SIZE", m_iFILE_SIZE);
   hTable.set("GDG_PROGRESS", m_iGDG_PROGRESS);
   hTable.set("RECORD_COUNT", m_iRECORD_COUNT);
   hTable.set("GDG_PATH", m_strGDG_PATH);
   hTable.set("GDG_STATE", m_strGDG_STATE);
   hTable.set("TSTAMP_OPEN", m_strTSTAMP_OPEN);
   hTable.set("TSTAMP_CLOSE", m_strTSTAMP_CLOSE);
   hTable.set("FILE_HASH", m_strFILE_HASH);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if (!pUpdateStatement->execute(hTable))
   {
      if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      {
         auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         if (!pInsertStatement->execute(hTable))
            return false;
      }
   }
   return true;
  //## end database::Generation::save%5EC2942D026B.body
}

// Additional Declarations
  //## begin database::Generation%5EC218E00394.declarations preserve=yes
  //## end database::Generation%5EC218E00394.declarations

} // namespace database

//## begin module%5EC21A2701EB.epilog preserve=yes
//## end module%5EC21A2701EB.epilog
