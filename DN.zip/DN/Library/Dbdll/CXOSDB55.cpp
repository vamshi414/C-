//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5970F53900DC.cm preserve=no
//	$Date:   May 14 2020 18:12:44  $ $Author:   e1009510  $
//	$Revision:   1.4  $
//## end module%5970F53900DC.cm

//## begin module%5970F53900DC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5970F53900DC.cp

//## Module: CXOSDB55%5970F53900DC; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB55.cpp

//## begin module%5970F53900DC.additionalIncludes preserve=no
//## end module%5970F53900DC.additionalIncludes

//## begin module%5970F53900DC.includes preserve=yes
//## end module%5970F53900DC.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRU41_h
#include "CXODRU41.hpp"
#endif
#ifndef CXOSDB55_h
#include "CXODDB55.hpp"
#endif


//## begin module%5970F53900DC.declarations preserve=no
//## end module%5970F53900DC.declarations

//## begin module%5970F53900DC.additionalDeclarations preserve=yes
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDB34_h
#include "CXODDB34.hpp"
#endif
#ifndef CXOSDB37_h
#include "CXODDB37.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSRU41_h
#include "CXODRU41.hpp"
#endif
#ifdef _WIN32
#include <WinSock2.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
//## end module%5970F53900DC.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::UnixEncryptedFile 

UnixEncryptedFile::UnixEncryptedFile()
  //## begin UnixEncryptedFile::UnixEncryptedFile%5970F4710075_const.hasinit preserve=no
      : m_pEncryptionBuffer(0),
        m_iEncryptLength(0),
        m_iEncryptOffset(0),
        m_bEndln(true),
        m_pKey(0),
        m_iMethod(2)
  //## end UnixEncryptedFile::UnixEncryptedFile%5970F4710075_const.hasinit
  //## begin UnixEncryptedFile::UnixEncryptedFile%5970F4710075_const.initialization preserve=yes
  //## end UnixEncryptedFile::UnixEncryptedFile%5970F4710075_const.initialization
{
  //## begin database::UnixEncryptedFile::UnixEncryptedFile%5970F4710075_const.body preserve=yes
   memcpy(m_sID, "DB55", 4);
  //## end database::UnixEncryptedFile::UnixEncryptedFile%5970F4710075_const.body
}

UnixEncryptedFile::UnixEncryptedFile (const char* pszName, const char* pszMember)
  //## begin database::UnixEncryptedFile::UnixEncryptedFile%597205DE005C.hasinit preserve=no
      : m_pEncryptionBuffer(0),
        m_iEncryptLength(0),
        m_iEncryptOffset(0),
        m_bEndln(true),
        m_pKey(0),
        m_iMethod(2)
  //## end database::UnixEncryptedFile::UnixEncryptedFile%597205DE005C.hasinit
  //## begin database::UnixEncryptedFile::UnixEncryptedFile%597205DE005C.initialization preserve=yes
  , UnixFile(pszName,pszMember)
  //## end database::UnixEncryptedFile::UnixEncryptedFile%597205DE005C.initialization
{
  //## begin database::UnixEncryptedFile::UnixEncryptedFile%597205DE005C.body preserve=yes
   memcpy(m_sID, "DB55", 4);
  //## end database::UnixEncryptedFile::UnixEncryptedFile%597205DE005C.body
}

UnixEncryptedFile::UnixEncryptedFile (const char* pszName)
  //## begin database::UnixEncryptedFile::UnixEncryptedFile%597205DE005F.hasinit preserve=no
      : m_pEncryptionBuffer(0),
        m_iEncryptLength(0),
        m_iEncryptOffset(0),
        m_bEndln(true),
        m_pKey(0),
        m_iMethod(2)
  //## end database::UnixEncryptedFile::UnixEncryptedFile%597205DE005F.hasinit
  //## begin database::UnixEncryptedFile::UnixEncryptedFile%597205DE005F.initialization preserve=yes
  , UnixFile(pszName)
  //## end database::UnixEncryptedFile::UnixEncryptedFile%597205DE005F.initialization
{
  //## begin database::UnixEncryptedFile::UnixEncryptedFile%597205DE005F.body preserve=yes
   memcpy(m_sID, "DB55", 4);
  //## end database::UnixEncryptedFile::UnixEncryptedFile%597205DE005F.body
}


UnixEncryptedFile::~UnixEncryptedFile()
{
  //## begin database::UnixEncryptedFile::~UnixEncryptedFile%5970F4710075_dest.body preserve=yes
   delete[] m_pEncryptionBuffer;
  //## end database::UnixEncryptedFile::~UnixEncryptedFile%5970F4710075_dest.body
}



//## Other Operations (implementation)
bool UnixEncryptedFile::open (enum OpenType nOpenType)
{
  //## begin database::UnixEncryptedFile::open%5970F8EA01EB.body preserve=yes
   if (!isOpen())
   {
      UnixFile::open(nOpenType);
      string strFileName = UnixFile::getDatasetName();
      UnixFile::close();
      string strMode = "wb";
      if (nOpenType == CX_OPEN_INPUT)
         strMode.assign("rb");
      m_lFile = (long)fopen(strFileName.c_str(), strMode.c_str());
      if (!m_lFile)
         return false;
   }
   //## end database::UnixEncryptedFile::open%5970F8EA01EB.body
}

bool UnixEncryptedFile::read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool* pbReadError)
{
  //## begin database::UnixEncryptedFile::read%5970F63400E6.body preserve=yes
   if (m_pEncryptionBuffer == 0)
      m_pEncryptionBuffer = new unsigned char[AESKey::getMaxBufferSize()];
   char sHeaderBuffer[sizeof(struct encryptionHeader2) + 1];
   if (!UnixFile::read(sHeaderBuffer, sizeof(struct encryptionHeader), plRecordLength, pbReadError))
   {
      if (feof((FILE*)m_lFile))
      {  //hit end of file looking for next encrypted record
         if (*plRecordLength > 0)
         {
            memcpy(psBuffer, sHeaderBuffer, *plRecordLength);
            return true;
         }
      }
      return false;
   }
   if (*plRecordLength != sizeof(struct encryptionHeader) || memcmp(sHeaderBuffer, ">DSS*<", 6) != 0)
   { //record is not encrypted
      fseek((FILE*)m_lFile, -20, SEEK_CUR);
      int i = 0;
      for (i = 0; i < AESKey::getMaxBufferSize(); i++)
      {
         if (!UnixFile::read((char*)m_pEncryptionBuffer + i, 1, plRecordLength, pbReadError))
         {
            if (feof((FILE*)m_lFile))
            {  //hit end of file before max buffer size
               if (i > 0)
               {
                  memcpy(psBuffer, m_pEncryptionBuffer, i);
                  *plRecordLength = i;
                  return true;
               }
            }
            return false;
         }
         if (m_pEncryptionBuffer[i] == '>')
         {  //read next 5 bytes to see if we found eyecatcher
            if (!UnixFile::read((char*)sHeaderBuffer, 5, plRecordLength, pbReadError))
            {
               if (feof((FILE*)m_lFile))
               {  //hit end of file looking for eye catcher
                  memcpy(m_pEncryptionBuffer + i + 1, sHeaderBuffer, *plRecordLength);
                  i += *plRecordLength;
                  memcpy(psBuffer, m_pEncryptionBuffer, i + 1);
                  *plRecordLength = i + 1;
                  return true;
               }
               return false;
            }
            if (*plRecordLength == 5 && memcmp(sHeaderBuffer, "DSS*<", 5) == 0)
            {  //found next encrypted record
               memcpy(psBuffer, m_pEncryptionBuffer, i - 1);
               *plRecordLength = i - 1;
               fseek((FILE*)m_lFile, -6, SEEK_CUR);
               return true;
            }
            else
               fseek((FILE*)m_lFile, -5, SEEK_CUR);
         }
      }
      //reached max buffer size
      memcpy(psBuffer, m_pEncryptionBuffer, i);
      *plRecordLength = i;
      return true;
   }
   m_iRecordCount--;
   int iHeaderLength = sizeof(struct encryptionHeader);
   struct encryptionHeader* pHeader = (struct encryptionHeader*)sHeaderBuffer;
   string strCheckDigits(pHeader->checkDigits, 4);
   bool bEndian = false;
   short siVersion = pHeader->version;
   if (siVersion >= 256)
      bEndian = true;
   siVersion = bEndian ? ntohs(pHeader->version) : pHeader->version;
   m_iMethod = bEndian ? ntohs(pHeader->encryptionMethod) : pHeader->encryptionMethod;//must set m_iMethod before call to setKey
   if (!setKey(strCheckDigits))
   {
      IF::Trace::put("Error: record not decrypted. Data Key not loaded.");
      IF::Trace::put(strCheckDigits.data(), strCheckDigits.length());
      return false;
   }
   short int siEncryptedFieldOffset = 0;
   short int siCompressionLength = bEndian ? ntohs(pHeader->compressionLength) : pHeader->compressionLength;
   short int siRecordLength = bEndian ? ntohs(pHeader->recordLength) : pHeader->recordLength;
   short int siEncryptedFieldLength = 0;
   if (lBufferLength < siRecordLength)
   {
      IF::Trace::put("Read Failure, buffer size is too small for data, use getMaxBufferSize()");
      return false;
   }
   if (siVersion == 2)
   {
      if (!UnixFile::read(sHeaderBuffer + 20, 6, plRecordLength, pbReadError))
         return false;
      m_iRecordCount--;
      iHeaderLength = sizeof(struct encryptionHeader2);
      struct encryptionHeader2* pHeader2 = (struct encryptionHeader2*)sHeaderBuffer;
      siEncryptedFieldOffset = bEndian ? ntohs(pHeader2->encryptedFieldOffset) : pHeader2->encryptedFieldOffset;
      siEncryptedFieldLength = bEndian ? ntohs(pHeader2->encryptedFieldLength) : pHeader2->encryptedFieldLength;
   }
   if (UnixFile::read((char*)m_pEncryptionBuffer, siRecordLength, plRecordLength, pbReadError) &&
      *plRecordLength == siRecordLength)
   {
      if (((AESKey*)m_pKey)->decryptRecord(m_pEncryptionBuffer, (unsigned char*)psBuffer, siEncryptedFieldOffset, siEncryptedFieldLength, siRecordLength))
         return true;
   }
   IF::Trace::put("Read Failure, unable to decrypt record");
   return false;
   //## end database::UnixEncryptedFile::read%5970F63400E6.body
}

bool UnixEncryptedFile::setKey (const string& strCheckDigits)
{
  //## begin database::UnixEncryptedFile::setKey%5970F65A03DA.body preserve=yes
   if (m_pKey)
   {
      if ((m_iMethod == 1 && ((DESKey*)m_pKey)->getCheckDigits() == strCheckDigits) ||
         (m_iMethod == 2 && ((AESKey*)m_pKey)->getCheckDigits() == strCheckDigits))
         return true;
      delete m_pKey; //new key so delete current
      m_pKey = 0;
   }
   string strIdentifier("DK");
   strIdentifier.append(strCheckDigits.data(), strCheckDigits.length());
   m_pKey = KeyRing::instance()->getKey(strIdentifier);
   if (!m_pKey)
      return false;
   return true;
   //## end database::UnixEncryptedFile::setKey%5970F65A03DA.body
}

bool UnixEncryptedFile::write (char* psBuffer, int lRecordLength)
{
  //## begin database::UnixEncryptedFile::write%5970F63902B0.body preserve=yes
   if (!m_pKey)
   {
      string strDefaultDataKey(KeyRing::instance()->getDefaultDataKey());
      if (strDefaultDataKey.length() != 6)
      {
         IF::Trace::put("Error: record not encrypted. Default Data Key not established.");
         return false;
      }
      if (!setKey(strDefaultDataKey.substr(2, 4)))
      {
         IF::Trace::put("Error: record not encrypted. Cannot set Data Key.");
         return false;
      }
   }
   if (m_pEncryptionBuffer == 0)
      m_pEncryptionBuffer = new unsigned char[AESKey::getMaxBufferSize() + sizeof(struct encryptionHeader2)];
   if (m_iEncryptLength == 0)
   {  // full record encryption
      int iRemainingLength = lRecordLength;
      while (iRemainingLength > 0)
      {
         int iEncryptLength = iRemainingLength > AESKey::getMaxBufferSize() ? AESKey::getMaxBufferSize() : iRemainingLength; //amount to encrypt on 1st pass;
         memset(m_pEncryptionBuffer + sizeof(struct encryptionHeader), ' ', 16); //padd with blanks for records < 16 bytes
         struct encryptionHeader* pHeader = (struct encryptionHeader*)m_pEncryptionBuffer;
         memcpy(pHeader->eyeCatcher, ">DSS*<", 6);
         pHeader->version = htons(1);
         memcpy(pHeader->checkDigits, m_pKey->getIdentifier().data() + m_pKey->getIdentifier().length() - 4, 4);
         pHeader->encryptionMethod = htons(m_iMethod);
         pHeader->compressionMethod = 0;
         pHeader->compressionLength = htons(iEncryptLength);  //same as in clear record length when compression not used
         pHeader->recordLength = htons(iEncryptLength); //actual in clear record length
         ((AESKey*)m_pKey)->encryptRecord((const unsigned char*)psBuffer, m_pEncryptionBuffer + sizeof(struct encryptionHeader), 0, 0, iEncryptLength);
         if (open(CX_OPEN_OUTPUT))
         {
            if (fwrite(m_pEncryptionBuffer, 1, iEncryptLength + sizeof(struct encryptionHeader), (FILE*)m_lFile) != iEncryptLength + sizeof(struct encryptionHeader))
               return false;
            m_iRecordCount++;
         }
         iRemainingLength -= iEncryptLength;
      }
      return true;
   }
   //partial encryption
   if (lRecordLength > AESKey::getMaxBufferSize() || //partial encryption cannot handle records larger than max buffer size
      m_iEncryptOffset + m_iEncryptLength > lRecordLength || //offset + length cannot exceed record size
      m_iEncryptLength < 16)                                //partial encryption requires a minimum of 16 bytes
   {
      IF::Trace::put("Error: record not encrypted. Partial encryption rule violation.");
      return false;
   }
   // partial record encryption
   struct encryptionHeader2* pHeader2 = (struct encryptionHeader2*)m_pEncryptionBuffer;
   memcpy(pHeader2->eyeCatcher, ">DSS*<", 6);
   pHeader2->version = htons(2);
   memcpy(pHeader2->checkDigits, m_pKey->getIdentifier().data() + m_pKey->getIdentifier().length() - 4, 4);
   pHeader2->encryptionMethod = htons(m_iMethod);
   pHeader2->compressionMethod = 0;
   pHeader2->compressionLength = htons(lRecordLength);
   pHeader2->sourcePlatform = htons(5);
   pHeader2->encryptedFieldOffset = htons(m_iEncryptOffset);
   pHeader2->encryptedFieldLength = htons(m_iEncryptLength); 
   pHeader2->recordLength = htons(lRecordLength);
   ((AESKey*)m_pKey)->encryptRecord((const unsigned char*)psBuffer, m_pEncryptionBuffer + sizeof(struct encryptionHeader2), m_iEncryptOffset, m_iEncryptLength, lRecordLength);
   if (open(CX_OPEN_OUTPUT))
   {
      if (fwrite(m_pEncryptionBuffer, 1, lRecordLength + sizeof(struct encryptionHeader2), (FILE*)m_lFile) != lRecordLength + sizeof(struct encryptionHeader2))
         return false;
      m_iRecordCount++;
   }
   return true;
   //## end database::UnixEncryptedFile::write%5970F63902B0.body
}

bool UnixEncryptedFile::writeBinary (char* psBuffer, int lRecordLength)
{
  //## begin database::UnixEncryptedFile::writeBinary%597203CB0320.body preserve=yes
   if (m_lFile == -1)
   if (!open(CX_OPEN_OUTPUT))
      return false;
   int iRC = 0;
   if (fwrite(psBuffer, 1, lRecordLength, (FILE*)m_lFile) != lRecordLength)
   {
      if (getType() != "TRACE")
         IF::Trace::put("FlatFile::write fwrite failure");
      return false;
   }
   ++m_iRecordCount;
   return true;
   //## end database::UnixEncryptedFile::writeBinary%597203CB0320.body
}

// Additional Declarations
  //## begin database::UnixEncryptedFile%5970F4710075.declarations preserve=yes
  //## end database::UnixEncryptedFile%5970F4710075.declarations

} // namespace database

//## begin module%5970F53900DC.epilog preserve=yes
//## end module%5970F53900DC.epilog
