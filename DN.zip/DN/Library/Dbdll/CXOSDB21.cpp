//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3B73ED130357.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3B73ED130357.cm

//## begin module%3B73ED130357.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3B73ED130357.cp

//## Module: CXOSDB21%3B73ED130357; Package body
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB21.cpp

//## begin module%3B73ED130357.additionalIncludes preserve=no
//## end module%3B73ED130357.additionalIncludes

//## begin module%3B73ED130357.includes preserve=yes
// $Date:   Sep 21 2015 03:57:58  $ $Author:   e1014059  $ $Revision:   1.7  $
//## end module%3B73ED130357.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB21_h
#include "CXODDB21.hpp"
#endif


//## begin module%3B73ED130357.declarations preserve=no
//## end module%3B73ED130357.declarations

//## begin module%3B73ED130357.additionalDeclarations preserve=yes
//## end module%3B73ED130357.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::Filter 

//## begin database::Filter::Instance%3B8D348C0222.attr preserve=no  private: static database::Filter {R} 0
database::Filter *Filter::m_pInstance = 0;
//## end database::Filter::Instance%3B8D348C0222.attr

Filter::Filter()
  //## begin Filter::Filter%3B73EAB903B6_const.hasinit preserve=no
  //## end Filter::Filter%3B73EAB903B6_const.hasinit
  //## begin Filter::Filter%3B73EAB903B6_const.initialization preserve=yes
  //## end Filter::Filter%3B73EAB903B6_const.initialization
{
  //## begin database::Filter::Filter%3B73EAB903B6_const.body preserve=yes
   memcpy(m_sID,"DB21",4);
   Database::instance()->attach(this);
  //## end database::Filter::Filter%3B73EAB903B6_const.body
}


Filter::~Filter()
{
  //## begin database::Filter::~Filter%3B73EAB903B6_dest.body preserve=yes
  m_hFragmentMap.erase(m_hFragmentMap.begin(),m_hFragmentMap.end());
  Database::instance()->detach(this);
  //## end database::Filter::~Filter%3B73EAB903B6_dest.body
}



//## Other Operations (implementation)
bool Filter::add (Query* pQuery, string strFunction)
{
  //## begin database::Filter::add%3B7439DF0251.body preserve=yes
   if (m_hFragmentMap.empty())
      return false;
   m_strFragmentKey = UseCase::getName() + '1';
   map<string,pair<string,string>,less<string> >::iterator pFragmentMap;
   pFragmentMap = m_hFragmentMap.find(m_strFragmentKey);
   if (pFragmentMap == m_hFragmentMap.end())
      return false;
   m_strFragmentMapDataQualifier = (*pFragmentMap).second.first;
   m_strFRAGMENT = (*pFragmentMap).second.second;
   m_strTABLE_NAME = m_strFragmentMapDataQualifier.substr(0,18);
   m_strSQL_FUNCTION = m_strFragmentMapDataQualifier.substr(18);
   if (strFunction != m_strSQL_FUNCTION)
      return false;
   m_hTable = pQuery->getTable();
   for (vector<Table>::iterator pTable=m_hTable.begin();pTable!=m_hTable.end();++pTable)
   {
      string strTableName = pTable->getName();
      int i = strTableName.length();
      if (i < 18)
      {
         string strSpaces("                  ");
         strTableName += strSpaces.substr(0,18 - i);
      }
      if (strTableName == m_strTABLE_NAME 
         || (m_strTABLE_NAME.substr(0,11) == "FIN_LOCATOR" 
             && strTableName.substr(0,5) == "FIN_L"))
      {
         pQuery->getSearchCondition() += " ";
         pQuery->getSearchCondition() += m_strFRAGMENT;
         return true;
      }
   }
   return false;
  //## end database::Filter::add%3B7439DF0251.body
}

database::Filter* Filter::instance ()
{
  //## begin database::Filter::instance%3B74381502FD.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new Filter();
   return m_pInstance;
  //## end database::Filter::instance%3B74381502FD.body
}

void Filter::update (Subject* pSubject)
{
  //## begin database::Filter::update%3B7439A000AB.body preserve=yes
   if (pSubject == Database::instance())
   {
      Database::instance()->detach(this);
      m_hQuery.attach(this);
      m_hQuery.bind("SQL_FRAGMENT","TASK",Column::STRING,&m_strTASK);
      m_hQuery.bind("SQL_FRAGMENT","USE_CASE_ID",Column::STRING,&m_strUSE_CASE_ID);
      m_hQuery.bind("SQL_FRAGMENT","SEQ_NO",Column::STRING,&m_strSEQ_NO);
      m_hQuery.bind("SQL_FRAGMENT","SQL_FUNCTION",Column::STRING,&m_strSQL_FUNCTION);
      m_hQuery.bind("SQL_FRAGMENT","TABLE_NAME",Column::STRING,&m_strTABLE_NAME);
      m_hQuery.bind("SQL_FRAGMENT","FRAGMENT",Column::STRING,&m_strFRAGMENT);
      m_hQuery.setBasicPredicate("SQL_FRAGMENT","CC_STATE","=","A");
	  string strCUST_ID;
	  Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
      string strInClause = "('" + strCUST_ID + "','****')";
	  m_hQuery.setBasicPredicate("SQL_FRAGMENT","CUST_ID","IN",strInClause.c_str());
      m_hQuery.setBasicPredicate("SQL_FRAGMENT","TASK","=",Extract::instance()->getName().substr(2,2).c_str());
      m_hQuery.setQualifier("QUALIFY","SQL_FRAGMENT");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      pSelectStatement->execute(m_hQuery);
      Database::instance()->commit();
   }
   if (pSubject == &m_hQuery)
   {
      m_strFragmentMapDataQualifier = m_strTABLE_NAME;
      int i = m_strTABLE_NAME.length();
      if (i != 18)
      {
         string strSpaces("                  ");
         m_strFragmentMapDataQualifier += strSpaces.substr(0,18 - i);
      }
      m_strFragmentMapDataQualifier += m_strSQL_FUNCTION;
      pair<string,string> hFragmentMapData(m_strFragmentMapDataQualifier,m_strFRAGMENT);
      m_strFragmentKey = m_strUSE_CASE_ID + m_strSEQ_NO;
      m_hFragmentMap.insert(map<string,pair<string,string>,less<string> >::value_type(m_strFragmentKey,hFragmentMapData));
   }
  //## end database::Filter::update%3B7439A000AB.body
}

// Additional Declarations
  //## begin database::Filter%3B73EAB903B6.declarations preserve=yes
  //## end database::Filter%3B73EAB903B6.declarations

} // namespace database

//## begin module%3B73ED130357.epilog preserve=yes
//## end module%3B73ED130357.epilog
