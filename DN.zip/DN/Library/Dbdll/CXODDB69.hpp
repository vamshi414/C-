//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%647735CD037C.cm preserve=no
//## end module%647735CD037C.cm

//## begin module%647735CD037C.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%647735CD037C.cp

//## Module: CXOSDB69%647735CD037C; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\ConnexPlatform\Server\Library\Dbdll\CXODDB69.hpp

#ifndef CXOSDB69_h
#define CXOSDB69_h 1

//## begin module%647735CD037C.additionalIncludes preserve=no
//## end module%647735CD037C.additionalIncludes

//## begin module%647735CD037C.includes preserve=yes
//## end module%647735CD037C.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class QueryVisitor;
class Query;
class Column;
class Table;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class ExportFile;
class RowVisitor;

} // namespace database

//## begin module%647735CD037C.declarations preserve=no
//## end module%647735CD037C.declarations

//## begin module%647735CD037C.additionalDeclarations preserve=yes
//## end module%647735CD037C.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::FileFormatFactory%6477330102C1.preface preserve=yes
//## end database::FileFormatFactory%6477330102C1.preface

//## Class: FileFormatFactory%6477330102C1
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%64788A0A00FF;reusable::QueryVisitor { -> F}
//## Uses: <unnamed>%64788A0C039A;RowVisitor { -> F}
//## Uses: <unnamed>%64788A0F0266;reusable::Query { -> F}
//## Uses: <unnamed>%64788A120286;reusable::Table { -> F}
//## Uses: <unnamed>%64788A150137;reusable::Column { -> F}
//## Uses: <unnamed>%6478907801CB;ExportFile { -> F}

class DllExport FileFormatFactory : public reusable::Object  //## Inherits: <unnamed>%6477337A0153
{
  //## begin database::FileFormatFactory%6477330102C1.initialDeclarations preserve=yes
   typedef database::ExportFile* (*cloneFunction)();
  //## end database::FileFormatFactory%6477330102C1.initialDeclarations

  public:
    //## Constructors (generated)
      FileFormatFactory();

    //## Destructor (generated)
      virtual ~FileFormatFactory();


    //## Other Operations (specified)
      //## Operation: create%647733830047
      database::ExportFile* create (const reusable::string& strName);

      //## Operation: instance%647733CB0307
      static FileFormatFactory* instance ();

      //## Operation: registerReport%64773401012C
      bool registerReport (const reusable::string& strName, cloneFunction hCloneFunction);

    // Additional Public Declarations
      //## begin database::FileFormatFactory%6477330102C1.public preserve=yes
      //## end database::FileFormatFactory%6477330102C1.public

  protected:
    // Additional Protected Declarations
      //## begin database::FileFormatFactory%6477330102C1.protected preserve=yes
      //## end database::FileFormatFactory%6477330102C1.protected

  private:
    // Data Members for Class Attributes

      //## Attribute: Instance%64773488031D
      //## begin database::FileFormatFactory::Instance%64773488031D.attr preserve=no  private: static FileFormatFactory* {U} 0
      static FileFormatFactory* m_pInstance;
      //## end database::FileFormatFactory::Instance%64773488031D.attr

    // Additional Private Declarations
      //## begin database::FileFormatFactory%6477330102C1.private preserve=yes
      //## end database::FileFormatFactory%6477330102C1.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Report%647734570184
      //## begin database::FileFormatFactory::Report%647734570184.attr preserve=no  private: map<string,cloneFunction,less<string> > {U} 
      map<string,cloneFunction,less<string> > m_hReport;
      //## end database::FileFormatFactory::Report%647734570184.attr

    // Additional Implementation Declarations
      //## begin database::FileFormatFactory%6477330102C1.implementation preserve=yes
      //## end database::FileFormatFactory%6477330102C1.implementation

};

//## begin database::FileFormatFactory%6477330102C1.postscript preserve=yes
//## end database::FileFormatFactory%6477330102C1.postscript

} // namespace database

//## begin module%647735CD037C.epilog preserve=yes
//## end module%647735CD037C.epilog


#endif
