//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5810EE8401EC.cm preserve=no
//	$Date:   Oct 26 2016 13:46:20  $ $Author:   e1009591  $ $Revision:   1.0  $
//## end module%5810EE8401EC.cm

//## begin module%5810EE8401EC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5810EE8401EC.cp

//## Module: CXOSDB52%5810EE8401EC; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB52.cpp

//## begin module%5810EE8401EC.additionalIncludes preserve=no
//## end module%5810EE8401EC.additionalIncludes

//## begin module%5810EE8401EC.includes preserve=yes
#define STS_RECORD_NOT_FOUND 14
//## end module%5810EE8401EC.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB52_h
#include "CXODDB52.hpp"
#endif


//## begin module%5810EE8401EC.declarations preserve=no
//## end module%5810EE8401EC.declarations

//## begin module%5810EE8401EC.additionalDeclarations preserve=yes
//## end module%5810EE8401EC.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::CommonContext 

CommonContext::CommonContext()
  //## begin CommonContext::CommonContext%5810EE3501EB_const.hasinit preserve=no
  //## end CommonContext::CommonContext%5810EE3501EB_const.hasinit
  //## begin CommonContext::CommonContext%5810EE3501EB_const.initialization preserve=yes
  //## end CommonContext::CommonContext%5810EE3501EB_const.initialization
{
  //## begin database::CommonContext::CommonContext%5810EE3501EB_const.body preserve=yes
   memcpy(m_sID, "DB52", 4);
  //## end database::CommonContext::CommonContext%5810EE3501EB_const.body
}

CommonContext::CommonContext (const string& strImage, const string& strTask)
  //## begin database::CommonContext::CommonContext%5810EF760129.hasinit preserve=no
  //## end database::CommonContext::CommonContext%5810EF760129.hasinit
  //## begin database::CommonContext::CommonContext%5810EF760129.initialization preserve=yes
  : m_strImage(strImage)
  , m_strTask(strTask)

  //## end database::CommonContext::CommonContext%5810EF760129.initialization
{
  //## begin database::CommonContext::CommonContext%5810EF760129.body preserve=yes
   memcpy(m_sID, "DB52", 4);
  //## end database::CommonContext::CommonContext%5810EF760129.body
}


CommonContext::~CommonContext()
{
  //## begin database::CommonContext::~CommonContext%5810EE3501EB_dest.body preserve=yes
  //## end database::CommonContext::~CommonContext%5810EE3501EB_dest.body
}



//## Other Operations (implementation)
bool CommonContext::get (const char* pszKey, string& strData, char cType, const char* pszFunction)
{
  //## begin database::CommonContext::get%5810EF680013.body preserve=yes
   char szCONTEXT_TYPE[2] = { " " };
   szCONTEXT_TYPE[0] = cType;
   strData.erase();
   short iNull = 0;
   Query hQuery;
   hQuery.setQualifier("QUALIFY", "TASK_CONTEXT_COMN");
   if (pszFunction[0] != '\0')
      hQuery.bind("TASK_CONTEXT_COMN", "CONTEXT_DATA", Column::STRING, &strData, &iNull, pszFunction);
   else
      hQuery.bind("TASK_CONTEXT_COMN", "CONTEXT_DATA", Column::STRING, &strData);
   if (m_strImage.length())
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "IMAGE_ID", "=", m_strImage.c_str());
   if (m_strTask.length())
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "TASK_ID", "=", m_strTask.c_str());
   if (pszKey[0] != '\0')
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "CONTEXT_KEY", "=", pszKey);
   hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "CONTEXT_TYPE", "=", szCONTEXT_TYPE);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   bool b = pSelectStatement->execute(hQuery);
   Database::instance()->setTransactionState(b ? Database::COMMITREQUIRED : Database::ROLLBACKREQUIRED);
   return b;
  //## end database::CommonContext::get%5810EF680013.body
}

bool CommonContext::put (const char* pszKey, const char* pszData, char cType)
{
  //## begin database::CommonContext::put%5810EF68001A.body preserve=yes
   char szCONTEXT_TYPE[2] = { " " };
   szCONTEXT_TYPE[0] = cType;
   Table hTable("TASK_CONTEXT_COMN");
   hTable.setQualifier("QUALIFY");
   hTable.set("CONTEXT_DATA", pszData, false, false);
   hTable.set("IMAGE_ID", m_strImage.c_str(), false, true);
   hTable.set("TASK_ID", m_strTask.c_str(), false, true);
   hTable.set("CONTEXT_TYPE", szCONTEXT_TYPE, false, true);
   hTable.set("CONTEXT_KEY", pszKey, false, true);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   bool b = pUpdateStatement->execute(hTable);
   if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
   {
      auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      b = pInsertStatement->execute(hTable);
   }
   Database::instance()->setTransactionState(b ? Database::COMMITREQUIRED : Database::ROLLBACKREQUIRED);
   return b;
  //## end database::CommonContext::put%5810EF68001A.body
}

// Additional Declarations
  //## begin database::CommonContext%5810EE3501EB.declarations preserve=yes
  //## end database::CommonContext%5810EE3501EB.declarations

} // namespace database

//## begin module%5810EE8401EC.epilog preserve=yes
//## end module%5810EE8401EC.epilog
