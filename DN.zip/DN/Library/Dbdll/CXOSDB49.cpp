//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%54521EDF022B.cm preserve=no
//	$Date:   May 14 2020 18:12:42  $ $Author:   e1009510  $
//	$Revision:   1.6  $
//## end module%54521EDF022B.cm

//## begin module%54521EDF022B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%54521EDF022B.cp

//## Module: CXOSDB49%54521EDF022B; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB49.cpp

//## begin module%54521EDF022B.additionalIncludes preserve=no
//## end module%54521EDF022B.additionalIncludes

//## begin module%54521EDF022B.includes preserve=yes
//## end module%54521EDF022B.includes

#ifndef CXOSDB49_h
#include "CXODDB49.hpp"
#endif
//## begin module%54521EDF022B.declarations preserve=no
//## end module%54521EDF022B.declarations

//## begin module%54521EDF022B.additionalDeclarations preserve=yes
//## end module%54521EDF022B.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::UniquenessKey 

//## begin database::UniquenessKey::Hash%5478E73A03CB.attr preserve=no  private: static unsigned short {V} 0
unsigned short UniquenessKey::m_usiHash = 0;
//## end database::UniquenessKey::Hash%5478E73A03CB.attr

//## begin database::UniquenessKey::Oat%5728F2C90073.attr preserve=no  private: static bool {V} false
bool UniquenessKey::m_bOat = false;
//## end database::UniquenessKey::Oat%5728F2C90073.attr

//## begin database::UniquenessKey::OatHash%5728F4060080.attr preserve=no  private: static unsigned int {V} 0
unsigned int UniquenessKey::m_iOatHash = 0;
//## end database::UniquenessKey::OatHash%5728F4060080.attr

//## begin database::UniquenessKey::UNIQUENESS_KEY%5452229A017F.attr preserve=no  private: static unsigned short {V} 0
unsigned short UniquenessKey::m_siUNIQUENESS_KEY = 0;
//## end database::UniquenessKey::UNIQUENESS_KEY%5452229A017F.attr

//## begin database::UniquenessKey::szUNIQUENESS_KEY%5478ECC9032E.attr preserve=no  private: static char[9] {U} 
char UniquenessKey::m_szUNIQUENESS_KEY[9];
//## end database::UniquenessKey::szUNIQUENESS_KEY%5478ECC9032E.attr

UniquenessKey::UniquenessKey()
  //## begin UniquenessKey::UniquenessKey%54521D6803A1_const.hasinit preserve=no
  //## end UniquenessKey::UniquenessKey%54521D6803A1_const.hasinit
  //## begin UniquenessKey::UniquenessKey%54521D6803A1_const.initialization preserve=yes
  //## end UniquenessKey::UniquenessKey%54521D6803A1_const.initialization
{
  //## begin database::UniquenessKey::UniquenessKey%54521D6803A1_const.body preserve=yes
   memcpy_s(m_sID,4,"DB49",4);
  //## end database::UniquenessKey::UniquenessKey%54521D6803A1_const.body
}


UniquenessKey::~UniquenessKey()
{
  //## begin database::UniquenessKey::~UniquenessKey%54521D6803A1_dest.body preserve=yes
  //## end database::UniquenessKey::~UniquenessKey%54521D6803A1_dest.body
}



//## Other Operations (implementation)
const char* UniquenessKey::get ()
{
  //## begin database::UniquenessKey::get%5478E7AE0198.body preserve=yes
   snprintf(m_szUNIQUENESS_KEY,sizeof(m_szUNIQUENESS_KEY),"%08hd",getHash());
   return m_szUNIQUENESS_KEY;
  //## end database::UniquenessKey::get%5478E7AE0198.body
}

unsigned short UniquenessKey::getHash ()
{
  //## begin database::UniquenessKey::getHash%5478E9F80218.body preserve=yes
   if (m_bOat)
   {
      unsigned short siUNIQUENESS_KEY = m_iOatHash % 32768;
      m_iOatHash = 0;
      return siUNIQUENESS_KEY;
   }
   if (m_usiHash > 32767)
      m_usiHash -= 32768;
   if (m_usiHash == 0)
      m_usiHash = 1;
   unsigned short siUNIQUENESS_KEY = m_usiHash;
   m_usiHash = 0;
   return siUNIQUENESS_KEY;
  //## end database::UniquenessKey::getHash%5478E9F80218.body
}

void UniquenessKey::hash (const char* sColumn, int iLength)
{
  //## begin database::UniquenessKey::hash%5478E76701B5.body preserve=yes
   m_bOat = false;
   for (int i = 0;i < iLength;i++)
      m_usiHash = 33 * m_usiHash + sColumn[i];
  //## end database::UniquenessKey::hash%5478E76701B5.body
}

void UniquenessKey::oatHash (const unsigned char* sColumn, int iLength)
{
  //## begin database::UniquenessKey::oatHash%5728F0E300F4.body preserve=yes
   m_bOat = true;
   unsigned h = 0;
   for (int i = 0;i < iLength;i++)
   {
      h += sColumn[i];
      h += (h << 10);
      h ^= (h >> 6);
   }
   h += (h << 3);
   h ^= (h >> 11);
   h += (h << 15);
   m_iOatHash += h;
  //## end database::UniquenessKey::oatHash%5728F0E300F4.body
}

short UniquenessKey::getHundredths ()
{
  //## begin database::UniquenessKey::getHundredths%572901A30120.body preserve=yes
   return m_iOatHash % 99;
  //## end database::UniquenessKey::getHundredths%572901A30120.body
}

// Additional Declarations
  //## begin database::UniquenessKey%54521D6803A1.declarations preserve=yes
short UniquenessKey::getSeconds ()
{
   return m_iOatHash % 6000;
}

int UniquenessKey::getHHMMSSnn ()
{
   return m_iOatHash % 23595900;
}
  //## end database::UniquenessKey%54521D6803A1.declarations

} // namespace database

//## begin module%54521EDF022B.epilog preserve=yes
//## end module%54521EDF022B.epilog
