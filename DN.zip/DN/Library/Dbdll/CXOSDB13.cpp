//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3EC3E25D030D.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3EC3E25D030D.cm

//## begin module%3EC3E25D030D.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3EC3E25D030D.cp

//## Module: CXOSDB13%3EC3E25D030D; Package body
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB13.cpp

//## begin module%3EC3E25D030D.additionalIncludes preserve=no
//## end module%3EC3E25D030D.additionalIncludes

//## begin module%3EC3E25D030D.includes preserve=yes
// $Date:   Apr 08 2004 10:16:54  $ $Author:   D02405  $ $Revision:   1.1  $
//## end module%3EC3E25D030D.includes

#ifndef CXOSDB10_h
#include "CXODDB10.hpp"
#endif
#ifndef CXOSDB11_h
#include "CXODDB11.hpp"
#endif
#ifndef CXOSDB12_h
#include "CXODDB12.hpp"
#endif
#ifndef CXOSDB13_h
#include "CXODDB13.hpp"
#endif


//## begin module%3EC3E25D030D.declarations preserve=no
//## end module%3EC3E25D030D.declarations

//## begin module%3EC3E25D030D.additionalDeclarations preserve=yes
//## end module%3EC3E25D030D.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::DatabaseCatalogVisitor 

DatabaseCatalogVisitor::DatabaseCatalogVisitor()
  //## begin DatabaseCatalogVisitor::DatabaseCatalogVisitor%3EC3DCB500FA_const.hasinit preserve=no
  //## end DatabaseCatalogVisitor::DatabaseCatalogVisitor%3EC3DCB500FA_const.hasinit
  //## begin DatabaseCatalogVisitor::DatabaseCatalogVisitor%3EC3DCB500FA_const.initialization preserve=yes
  //## end DatabaseCatalogVisitor::DatabaseCatalogVisitor%3EC3DCB500FA_const.initialization
{
  //## begin database::DatabaseCatalogVisitor::DatabaseCatalogVisitor%3EC3DCB500FA_const.body preserve=yes
  //## end database::DatabaseCatalogVisitor::DatabaseCatalogVisitor%3EC3DCB500FA_const.body
}


DatabaseCatalogVisitor::~DatabaseCatalogVisitor()
{
  //## begin database::DatabaseCatalogVisitor::~DatabaseCatalogVisitor%3EC3DCB500FA_dest.body preserve=yes
  //## end database::DatabaseCatalogVisitor::~DatabaseCatalogVisitor%3EC3DCB500FA_dest.body
}



//## Other Operations (implementation)
void DatabaseCatalogVisitor::visitDatabaseCatalog (DatabaseCatalog* pDatabaseCatalog)
{
  //## begin database::DatabaseCatalogVisitor::visitDatabaseCatalog%3EC3DD1300FA.body preserve=yes
  //## end database::DatabaseCatalogVisitor::visitDatabaseCatalog%3EC3DD1300FA.body
}

void DatabaseCatalogVisitor::visitDatabaseColumn (DatabaseColumn* pDatabaseColumn)
{
  //## begin database::DatabaseCatalogVisitor::visitDatabaseColumn%3EC3DD2F0242.body preserve=yes
  //## end database::DatabaseCatalogVisitor::visitDatabaseColumn%3EC3DD2F0242.body
}

void DatabaseCatalogVisitor::visitDatabaseTable (DatabaseTable* pDatabaseTable)
{
  //## begin database::DatabaseCatalogVisitor::visitDatabaseTable%3EC3DD2F038A.body preserve=yes
  //## end database::DatabaseCatalogVisitor::visitDatabaseTable%3EC3DD2F038A.body
}

// Additional Declarations
  //## begin database::DatabaseCatalogVisitor%3EC3DCB500FA.declarations preserve=yes
  //## end database::DatabaseCatalogVisitor%3EC3DCB500FA.declarations

} // namespace database

//## begin module%3EC3E25D030D.epilog preserve=yes
//## end module%3EC3E25D030D.epilog
