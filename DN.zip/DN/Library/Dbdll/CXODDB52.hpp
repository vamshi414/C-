//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5810EE82039B.cm preserve=no
//	$Date:   Oct 26 2016 13:46:20  $ $Author:   e1009591  $ $Revision:   1.0  $
//## end module%5810EE82039B.cm

//## begin module%5810EE82039B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5810EE82039B.cp

//## Module: CXOSDB52%5810EE82039B; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB52.hpp

#ifndef CXOSDB52_h
#define CXOSDB52_h 1

//## begin module%5810EE82039B.additionalIncludes preserve=no
//## end module%5810EE82039B.additionalIncludes

//## begin module%5810EE82039B.includes preserve=yes
//## end module%5810EE82039B.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;

} // namespace database

//## begin module%5810EE82039B.declarations preserve=no
//## end module%5810EE82039B.declarations

//## begin module%5810EE82039B.additionalDeclarations preserve=yes
//## end module%5810EE82039B.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::CommonContext%5810EE3501EB.preface preserve=yes
//## end database::CommonContext%5810EE3501EB.preface

//## Class: CommonContext%5810EE3501EB
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5810F3BB01B2;reusable::Query { -> F}
//## Uses: <unnamed>%5810F3BD012A;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5810F3BF016C;Database { -> F}
//## Uses: <unnamed>%5810F3C101E5;DatabaseFactory { -> F}
//## Uses: <unnamed>%5810F490021C;reusable::Statement { -> F}

class DllExport CommonContext : public reusable::Object  //## Inherits: <unnamed>%5810EE5E01E5
{
  //## begin database::CommonContext%5810EE3501EB.initialDeclarations preserve=yes
  //## end database::CommonContext%5810EE3501EB.initialDeclarations

  public:
    //## Constructors (generated)
      CommonContext();

    //## Constructors (specified)
      //## Operation: CommonContext%5810EF760129
      //	Create a new task unique context item.
      //## Semantics:
      //	1. Save the image and task names.
      CommonContext (const string& strImage, const string& strTask);

    //## Destructor (generated)
      virtual ~CommonContext();


    //## Other Operations (specified)
      //## Operation: get%5810EF680013
      //	Retrieve a context item from persistent storage.
      virtual bool get (const char* pszKey, string& strData, char cType = ' ', const char* pszFunction = "");

      //## Operation: put%5810EF68001A
      //	Save a context item in persistent storage.
      virtual bool put (const char* pszKey, const char* pszData, char cType = ' ');

    // Additional Public Declarations
      //## begin database::CommonContext%5810EE3501EB.public preserve=yes
      //## end database::CommonContext%5810EE3501EB.public

  protected:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Image%5810EF5E0073
      //	The image name of this context item (will contain "*"
      //	for global context items).
      const string& getImage () const
      {
        //## begin database::CommonContext::getImage%5810EF5E0073.get preserve=no
        return m_strImage;
        //## end database::CommonContext::getImage%5810EF5E0073.get
      }

      void setImage (const string& value)
      {
        //## begin database::CommonContext::setImage%5810EF5E0073.set preserve=no
        m_strImage = value;
        //## end database::CommonContext::setImage%5810EF5E0073.set
      }


      //## Attribute: Task%5810EF5E007E
      //	The task name of this context item (will contain "*" for
      //	global context items).
      const string& getTask () const
      {
        //## begin database::CommonContext::getTask%5810EF5E007E.get preserve=no
        return m_strTask;
        //## end database::CommonContext::getTask%5810EF5E007E.get
      }

      void setTask (const string& value)
      {
        //## begin database::CommonContext::setTask%5810EF5E007E.set preserve=no
        m_strTask = value;
        //## end database::CommonContext::setTask%5810EF5E007E.set
      }


    // Data Members for Class Attributes

      //## begin database::CommonContext::Image%5810EF5E0073.attr preserve=no  protected: string {V} 
      string m_strImage;
      //## end database::CommonContext::Image%5810EF5E0073.attr

      //## begin database::CommonContext::Task%5810EF5E007E.attr preserve=no  protected: string {V} 
      string m_strTask;
      //## end database::CommonContext::Task%5810EF5E007E.attr

    // Additional Protected Declarations
      //## begin database::CommonContext%5810EE3501EB.protected preserve=yes
      //## end database::CommonContext%5810EE3501EB.protected

  private:
    // Additional Private Declarations
      //## begin database::CommonContext%5810EE3501EB.private preserve=yes
      //## end database::CommonContext%5810EE3501EB.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::CommonContext%5810EE3501EB.implementation preserve=yes
      //## end database::CommonContext%5810EE3501EB.implementation

};

//## begin database::CommonContext%5810EE3501EB.postscript preserve=yes
//## end database::CommonContext%5810EE3501EB.postscript

} // namespace database

//## begin module%5810EE82039B.epilog preserve=yes
//## end module%5810EE82039B.epilog


#endif
