//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41E9697F006D.cm preserve=no
//	$Date:   Feb 18 2021 09:05:24  $ $Author:   e3027760  $ $Revision:   1.61  $
//## end module%41E9697F006D.cm

//## begin module%41E9697F006D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%41E9697F006D.cp

//## Module: CXOSDB26%41E9697F006D; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.0A.R003\ConnexPlatform\Server\Library\Dbdll\CXOSDB26.cpp

//## begin module%41E9697F006D.additionalIncludes preserve=no
//## end module%41E9697F006D.additionalIncludes

//## begin module%41E9697F006D.includes preserve=yes
//## end module%41E9697F006D.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDB08_h
#include "CXODDB08.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSRU28_h
#include "CXODRU28.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSTM14_h
#include "CXODTM14.hpp"
#endif
#ifndef CXOSTM15_h
#include "CXODTM15.hpp"
#endif
#ifndef CXOSDB26_h
#include "CXODDB26.hpp"
#endif


//## begin module%41E9697F006D.declarations preserve=no
//## end module%41E9697F006D.declarations

//## begin module%41E9697F006D.additionalDeclarations preserve=yes
#define WALLCLOCK 0
#define SWITCHCLOCK 1
#define ALL 2
//## end module%41E9697F006D.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::FileFactory 

//## begin database::FileFactory::Instance%41E9690A0280.attr preserve=no  private: static database::FileFactory* {V} 0
database::FileFactory* FileFactory::m_pInstance = 0;
//## end database::FileFactory::Instance%41E9690A0280.attr

FileFactory::FileFactory()
  //## begin FileFactory::FileFactory%41E967D6001F_const.hasinit preserve=no
      : m_strDailyFiles("('XXXXXX')"),
        m_strMonthlyFiles("('XXXXXX')"),
        m_iNull(0),
        m_pExportFile(0)
  //## end FileFactory::FileFactory%41E967D6001F_const.hasinit
  //## begin FileFactory::FileFactory%41E967D6001F_const.initialization preserve=yes
  //## end FileFactory::FileFactory%41E967D6001F_const.initialization
{
  //## begin database::FileFactory::FileFactory%41E967D6001F_const.body preserve=yes
   if (m_pInstance == 0)
      m_pInstance = this;
   Database::instance()->attach(this);
  //## end database::FileFactory::FileFactory%41E967D6001F_const.body
}


FileFactory::~FileFactory()
{
  //## begin database::FileFactory::~FileFactory%41E967D6001F_dest.body preserve=yes
   Database::instance()->detach(this);
  //## end database::FileFactory::~FileFactory%41E967D6001F_dest.body
}



//## Other Operations (implementation)
void FileFactory::adjustDate (timer::Date& hDate)
{
  //## begin database::FileFactory::adjustDate%4541499201B5.body preserve=yes
     if (!m_strEVCLID[0].empty())
     {
        if (!m_hCalendar.doesExist(m_strEVCLID[0]))
        {
           m_hCalendar.loadBusinessDays(m_strEVCLID[0]);
           m_hCalendar.loadHolidays(m_strEVCLID[0]);
        }
        m_hCalendar.setCalendar(m_strEVCLID[0]);
        while (!m_hCalendar.isBusinessDay(hDate))
           hDate += 1;
        m_strDATE_RECON[0] = hDate.asString("%Y%m%d");
     }
     hDate -= 1;
  //## end database::FileFactory::adjustDate%4541499201B5.body
}

void FileFactory::buildQuery (reusable::Query& hQuery, char cEntityType, char cPeriodType, bool bOrderBy)
{
  //## begin database::FileFactory::buildQuery%445A6502001D.body preserve=yes
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   string strDX_DEST("DX_INST_DEST");
   string strENTITY_NAME("INSTITUTION");
   string strENTITY_COLUMN("INST_ID");
   string strENTITY_TYPE("'*I'");
   if (cEntityType == 'P')
   {
      strDX_DEST.assign("DX_PROC_DEST");
      strENTITY_NAME.assign("PROCESSOR");
      strENTITY_COLUMN.assign("PROC_ID");
      strENTITY_TYPE.assign("'*P'");
   }
   else
   if (cEntityType == 'G')
   {
      strDX_DEST.assign("DX_PROC_GRP_DEST");
      strENTITY_NAME.assign("PROCESSOR_GRP");
      strENTITY_COLUMN.assign("PROC_GRP_ID");
      strENTITY_TYPE.assign("'*G'");
   }
   else
   if (cEntityType == 'M')
   {
      strDX_DEST.assign("DX_RPT_LVL_DEST");
      strENTITY_NAME.assign("REPORTING_LVL");
      strENTITY_COLUMN.assign("RPT_LVL_ID");
      strENTITY_TYPE.assign("'AM'");
   }
   hQuery.setQualifier("QUALIFY","DX_FILE_TYPE");
   hQuery.setQualifier("QUALIFY",strDX_DEST.c_str());
   hQuery.setQualifier("QUALIFY",strENTITY_NAME.c_str());
   hQuery.join("DX_FILE_TYPE","INNER",strDX_DEST.c_str(),"DX_FILE_GROUP");
   hQuery.join("DX_FILE_TYPE","INNER",strDX_DEST.c_str(),"DX_FILE_GROUP_STAT");
   hQuery.join(strDX_DEST.c_str(),"INNER",strENTITY_NAME.c_str(),strENTITY_COLUMN.c_str());
   hQuery.join("DX_FILE_TYPE","LEFT OUTER","DX_DATA_CONTROL","DX_FILE_TYPE");
   hQuery.join("DX_FILE_TYPE","LEFT OUTER","DX_DATA_CONTROL","SCHED_OFFSET_TIME","SCHED_TIME");
   hQuery.join("DX_FILE_TYPE","LEFT OUTER","DX_DATA_CONTROL", "COALESCE(DX_REPORT_ID,0)");
   hQuery.join(strDX_DEST.c_str(),"LEFT OUTER","DX_DATA_CONTROL",strENTITY_COLUMN.c_str(),"ENTITY_ID");
   hQuery.bind("DX_FILE_TYPE","DX_FILE_TYPE",Column::STRING,&m_strDX_FILE_TYPE[1]);
   hQuery.bind("DX_FILE_TYPE","DX_REPORT_ID",Column::LONG,&m_iDX_REPORT_ID[1],&m_iNull);
   hQuery.bind("DX_FILE_TYPE","DX_REPORT_STAT",Column::STRING,&m_strDX_REPORT_STAT[1]);
   hQuery.bind("DX_FILE_TYPE","SCHED_FREQUENCY",Column::STRING,&m_strSCHED_FREQUENCY[1]);
   hQuery.bind("DX_FILE_TYPE","SCHED_OFFSET",Column::STRING,&m_strSCHED_OFFSET[1]);
   hQuery.bind("DX_FILE_TYPE","SCHED_OFFSET_TIME",Column::STRING,&m_strSCHED_OFFSET_TIME[1]);
   hQuery.bind("DX_FILE_TYPE", "EVCLID", Column::STRING, &m_strEVCLID[1]);
   hQuery.bind(strDX_DEST.c_str(),strENTITY_COLUMN.c_str(),Column::STRING,&m_strENTITY_ID[1]);
   hQuery.bind(strDX_DEST.c_str(),"ROUTING_DATA",Column::STRING,&m_strROUTING_DATA[1]);
   hQuery.bind(strDX_DEST.c_str(),"ROUTING_PASSWORD",Column::STRING,&m_strROUTING_PASSWORD[1]);
   hQuery.bind(strDX_DEST.c_str(),"ROUTING_TYPE",Column::STRING,&m_strROUTING_TYPE[1]);
   hQuery.bind(strDX_DEST.c_str(),"ROUTING_USER_ID",Column::STRING,&m_strROUTING_USER_ID[1]);
   hQuery.bind(strENTITY_NAME.c_str(),"CUTOFF_TIME",Column::STRING,&m_strCUTOFF_TIME[1]);
   hQuery.bind("DX_DATA_CONTROL","DATE_RECON",Column::STRING,&m_strDATE_RECON[1]);
   hQuery.bind("",strENTITY_TYPE.c_str(),Column::STRING,&m_strEntityType[1]);
   if (cPeriodType == 'D')
   {
      hQuery.bind("","'D'",Column::STRING,&m_strPeriod[1]);
      hQuery.setBasicPredicate("DX_FILE_TYPE","DX_FILE_TYPE","IN",m_strDailyFiles.c_str());
   }
   else
   {
      hQuery.bind("","'M'",Column::STRING,&m_strPeriod[1]);
      hQuery.setBasicPredicate("DX_FILE_TYPE","DX_FILE_TYPE","IN",m_strMonthlyFiles.c_str());
   }
   hQuery.setBasicPredicate(strDX_DEST.c_str(),"CUST_ID","=",strCUST_ID.c_str());
   hQuery.setBasicPredicate(strDX_DEST.c_str(),"CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate(strDX_DEST.c_str(),"CC_STATE","=","A");
   hQuery.setBasicPredicate(strENTITY_NAME.c_str(),"CUST_ID","=",strCUST_ID.c_str());
   hQuery.setBasicPredicate(strENTITY_NAME.c_str(),"CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate(strENTITY_NAME.c_str(),"CC_STATE","IN","('A','I')");
   if (bOrderBy)
      if (cEntityType == 'M')
         hQuery.setOrderByClause("1,2,12,7,13"); // file type, report, reporting level, time offset, recon date
      else
         hQuery.setOrderByClause("1,2,8,7,13");  // file type, report, processor or institution, time offset, recon date
  //## end database::FileFactory::buildQuery%445A6502001D.body
}

void FileFactory::createInLists ()
{
  //## begin database::FileFactory::createInLists%4F7330AE018F.body preserve=yes
   string strTASK = Extract::instance()->getName().substr(2,2);
   for (int i = 0;i < 3;i++)
      m_strClockFiles[i].assign("(");
   m_strDailyFiles.assign("(");
   m_strMonthlyFiles.assign("(");
   char szBuffer[10];
   map<string,struct hExportFileAttributes,less<string> >::iterator q;
   for (q = m_hFileDictionary.begin();q != m_hFileDictionary.end();q++)
   {
      if (string((*q).second.sTASK) == strTASK)
      {
         if ((*q).second.cSCHED_FREQUENCY == 'D')
            m_strDailyFiles.append(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"'%s',",(*q).second.sDX_FILE_TYPE));
         else
         if ((*q).second.cSCHED_FREQUENCY == 'M')
            m_strMonthlyFiles.append(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"'%s',",(*q).second.sDX_FILE_TYPE));
         if ((*q).second.cClockType == 'W')
            m_strClockFiles[WALLCLOCK].append(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"'%s',",(*q).second.sDX_FILE_TYPE));
         else
         if ((*q).second.cClockType == 'S')
            m_strClockFiles[SWITCHCLOCK].append(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"'%s',",(*q).second.sDX_FILE_TYPE));
         m_strClockFiles[ALL].append(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"'%s',",(*q).second.sDX_FILE_TYPE));
      }
   }
   for (int i = 0;i < 3;i++)
   {
      if (m_strClockFiles[i] == "(")
         m_strClockFiles[i].append("'XXXXXX',");
      m_strClockFiles[i][m_strClockFiles[i].length() - 1] = ')';
   }
   if (m_strDailyFiles == "(")
      m_strDailyFiles.append("'XXXXXX',");
   m_strDailyFiles[m_strDailyFiles.length() - 1] = ')';
   if (m_strMonthlyFiles == "(")
      m_strMonthlyFiles.append("'XXXXXX',");
   m_strMonthlyFiles[m_strMonthlyFiles.length() - 1] = ')';
  //## end database::FileFactory::createInLists%4F7330AE018F.body
}

pair<string,int> FileFactory::getStatus (int iIndex)
{
  //## begin database::FileFactory::getStatus%455D08AC003E.body preserve=yes
   string strValue[2];
   Query hQuery;
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (iIndex == 0)
   {
      hQuery.bind("DX_DATA_CONTROL","TSTAMP_INITIATED",Column::STRING,&strValue[0],0,"MAX");
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_STATE","IN","('DW','DC')");
   }
   else
   {
      hQuery.bind("DX_DATA_CONTROL","TSTAMP_INITIATED",Column::STRING,&strValue[0],0,"MIN");
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_STATE","=","FW");
   }
   pSelectStatement->execute(hQuery);
   if (strValue[0].empty())
      strValue[1] = "0000-00-00 00:00:00";
   else
   {
      strValue[1].assign(strValue[0].data(),4);
      strValue[1] += '-';
      strValue[1].append(strValue[0].data() + 4,2);
      strValue[1] += '-';
      strValue[1].append(strValue[0].data() + 6,2);
      strValue[1] += ' ';
      strValue[1].append(strValue[0].data() + 8,2);
      strValue[1] += ':';
      strValue[1].append(strValue[0].data() + 10,2);
      strValue[1] += ':';
      strValue[1].append(strValue[0].data() + 12,2);
   }
   return make_pair(strValue[1],0);
  //## end database::FileFactory::getStatus%455D08AC003E.body
}

FileFactory* FileFactory::instance (Object* pSender)
{
  //## begin database::FileFactory::instance%41E9688702FD.body preserve=yes
   return m_pInstance;
  //## end database::FileFactory::instance%41E9688702FD.body
}

bool FileFactory::reset (const char* pszInterval)
{
  //## begin database::FileFactory::reset%4591EF380168.body preserve=yes
   Table hTable("DX_DATA_CONTROL");
   hTable.set("DX_STATE","PI");
   hTable.set("TASK_DISTRIBUTED"," ");
   hTable.set("TSTAMP_DISTRIBUTED"," ");
   SearchCondition hSearchCondition;
   hSearchCondition.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","IN",m_strDailyFiles.c_str());
   hSearchCondition.setBasicPredicate("DX_DATA_CONTROL","TASK_FORMATTED","=",Extract::instance()->getName().c_str());
   hSearchCondition.setBasicPredicate("DX_DATA_CONTROL","TSTAMP_FORMATTED",">",pszInterval);
   auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   pUpdateStatement->execute(hTable,hSearchCondition.getText());
   return true;
  //## end database::FileFactory::reset%4591EF380168.body
}

void FileFactory::update (Subject* pSubject)
{
  //## begin database::FileFactory::update%41F170CD0157.body preserve=yes
   if ((pSubject == Database::instance()
      || pSubject == MidnightAlarm::instance()
      || pSubject == BarTime::instance()
      || pSubject == WitchingHour::instance()
      || pSubject == MinuteTimer::instance())
      && Database::instance()->state() == Database::CONNECTED)
   {
      UseCase hUseCase("DIST","## DT04 SCHEDULE EXPORT FILE");
      int iItem = 0;
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      m_pExportFile = new ExportFile();
      for (;;)
      {
         Query hQuery;
         hQuery.attach(this);
         buildQuery(hQuery,'I','D'); // institution daily
         Query hQuery2;
         buildQuery(hQuery2,'I','M'); // institution monthly
         Query hQuery3;
         buildQuery(hQuery3,'P','D'); // processor daily
         Query hQuery4;
         buildQuery(hQuery4,'P','M',true); // processor monthly
         hQuery.setQuery(&hQuery2);
         hQuery2.setQuery(&hQuery3);
         hQuery3.setQuery(&hQuery4);
         if (pSelectStatement->execute(hQuery) == false
            || Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
         {
            Database::instance()->rollback();
            MinuteTimer::instance()->attach(this);
            UseCase::setSuccess(false);
            break;
         }
         hQuery.reset();
         hQuery.attach(this);
         buildQuery(hQuery,'M','D'); // reporting level daily
         hQuery2.reset();
         buildQuery(hQuery2,'M','M',true); // reporting level monthly
         hQuery.setQuery(&hQuery2);
         if (pSelectStatement->execute(hQuery) == false
            || Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
         {
            Database::instance()->rollback();
            MinuteTimer::instance()->attach(this);
            UseCase::setSuccess(false);
            break;
         }
         hQuery.reset();
         hQuery.attach(this);
         buildQuery(hQuery,'G','D'); // processor group daily
         hQuery2.reset();
         buildQuery(hQuery2,'G','M',true); // Processor group monthly
         hQuery.setQuery(&hQuery2);
         m_strCUTOFF_TIME[1].erase();
         if (pSelectStatement->execute(hQuery) == false
            || Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
         {
            Database::instance()->rollback();
            MinuteTimer::instance()->attach(this);
            UseCase::setSuccess(false);
            break;
         }
         if (!m_strDX_FILE_TYPE[0].empty())
         {
            update(0);
            if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
            {
               Database::instance()->rollback();
               MinuteTimer::instance()->attach(this);
               UseCase::setSuccess(false);
               break;
            }
            m_strDX_FILE_TYPE[0].erase();
         }
         Database::instance()->commit();
         if (iItem == hUseCase.getItems())
         {
            MinuteTimer::instance()->detach(this);
            break;
         }
         iItem = hUseCase.getItems();
      }
      delete m_pExportFile;
      return;
   }
   if (m_strSCHED_OFFSET_TIME[0].length() < 6)
      m_strSCHED_OFFSET_TIME[0] = "000000";
   if (m_iNull == -1)
      m_iDX_REPORT_ID[1] = -1;
   if (m_strDX_FILE_TYPE[1] == m_strDX_FILE_TYPE[0]
      && m_strENTITY_ID[1] == m_strENTITY_ID[0]
      && m_iDX_REPORT_ID[1] == m_iDX_REPORT_ID[0]
      && m_strSCHED_OFFSET_TIME[1] == m_strSCHED_OFFSET_TIME[0]
      && pSubject != 0)
      ;
   else
   if (pSubject == 0
      || m_strDX_FILE_TYPE[0].length() > 0)
   {
      if (m_strDATE_RECON[0].length() == 0
         || m_strDATE_RECON[0] <= MidnightAlarm::instance()->getToday(+2))
      {
         m_pExportFile->setDX_STATE(m_strDX_STATE);
         m_pExportFile->setDX_FILE_TYPE(m_strDX_FILE_TYPE[0]);
         if (m_strDX_FILE_TYPE[0] == "DFRDEB")
            m_strEntityType[0][0] = 'I';
         m_pExportFile->setENTITY_TYPE(m_strEntityType[0]);
         m_pExportFile->setENTITY_ID(m_strENTITY_ID[0]);
         if (m_strCUTOFF_TIME[0].empty())
            m_strCUTOFF_TIME[0] = "23595999";
         string strSCHED_TIME(m_strCUTOFF_TIME[0]);
         if (strSCHED_TIME.length() > 6)
            strSCHED_TIME.erase(6);
         m_pExportFile->setSCHED_TIME(strSCHED_TIME);
         m_pExportFile->setDX_REPORT_ID(m_iDX_REPORT_ID[0]);
         m_pExportFile->setDX_REPORT_STAT(m_strDX_REPORT_STAT[0]);
         m_pExportFile->setROUTING_DATA(m_strROUTING_DATA[0]);
         m_pExportFile->setROUTING_PASSWORD(m_strROUTING_PASSWORD[0]);
         m_pExportFile->setROUTING_TYPE(m_strROUTING_TYPE[0]);
         m_pExportFile->setROUTING_USER_ID(m_strROUTING_USER_ID[0]);
         string strTSTAMP_INITIATED;
         char szTSTAMP_INITIATED[17];
         if (m_strPeriod[0] == "D") // daily
         {
            struct hExportFileAttributes hAttributes;
            map<string,struct hExportFileAttributes,less<string> >::iterator q;
            q = m_hFileDictionary.find(m_strDX_FILE_TYPE[0]);
            if (q != m_hFileDictionary.end())
               hAttributes =  (*q).second;
            Date hDate(m_strDATE_RECON[0].length() > 0 ? m_strDATE_RECON[0].c_str() :
               SwitchClock::instance()->getYYYYMMDDHHMMSS().substr(0,8).c_str());
            hDate += 1; //next possible DATE_RECON to schedule
            m_strDATE_RECON[0] = hDate.asString("%Y%m%d");
            if (hAttributes.cAdjustDate == 'Y')
               adjustDate(hDate); //adjust DATE_RECON for non-business days,set hDate = DATE_RECON-1
            if (hAttributes.cSCHED_OFFSET == 'A')
            {  //absolute time (not based on cutoff)
               strTSTAMP_INITIATED = m_strDATE_RECON[0];
               strTSTAMP_INITIATED += m_strSCHED_OFFSET_TIME[0];
               strTSTAMP_INITIATED += "99";
            }
            else
            if (m_strSCHED_OFFSET_TIME[0] >= "240000")
            {  //special case for 240000  delay file until switch end of day
               string strDate("        000");
               strDate.replace(0,8,m_strDATE_RECON[0]);
               string strTime(Extract::instance()->getCUTOFF_TIME().data(),6);
               char szOffset[3] = {"  "};
               memcpy_s(szOffset,sizeof(szOffset),m_strSCHED_OFFSET_TIME[0].data() + 2,2);
               Timestamp::adjust(strDate,strTime,atoi(szOffset));
               strDate.resize(8);
               strTSTAMP_INITIATED = strDate;
               strTSTAMP_INITIATED += strTime;
               strTSTAMP_INITIATED.append(Extract::instance()->getCUTOFF_TIME().data() + 6,2);
            }
            else
            {  //compute TSTAMP_INITIATED based on CUTOFF_TIME + SCHED_OFFSET_TIME
               int iCutoff = atoi(m_strCUTOFF_TIME[0].substr(0,2).c_str()) * 60;
               iCutoff += atoi(m_strCUTOFF_TIME[0].substr(2,2).c_str());
               int iSeconds = atoi(m_strCUTOFF_TIME[0].substr(4,2).c_str());
               int  iOffset =  atoi(m_strSCHED_OFFSET_TIME[0].substr(0,2).c_str()) * 60;
               iOffset += atoi(m_strSCHED_OFFSET_TIME[0].substr(2,2).c_str());
               iSeconds += atoi(m_strSCHED_OFFSET_TIME[0].substr(4,2).c_str());
               if (m_strSCHED_OFFSET_TIME[0] == "235959")
                  iSeconds += 1;
               int iMinutes = iCutoff + iOffset;
               int iDays = 0;
               while (iSeconds >= 60)
               {
                  iSeconds -= 60;
                  iMinutes++;
               }
               while (iMinutes >= 1440) //24*60
               {
                  iMinutes -= 1440;
                  iDays++;
               }
               hDate += iDays;
               char szBuf[17];
               strTSTAMP_INITIATED.assign(szBuf,snprintf(szBuf,sizeof(szBuf),"%s%02d%02d%02d99",
                  hDate.asString("%Y%m%d").c_str(),iMinutes/60,iMinutes % 60,iSeconds));
            }
         }
         else
         if (m_strPeriod[0] == "M") // monthly
         {
            struct hExportFileAttributes hAttributes;
            map<string, struct hExportFileAttributes, less<string> >::iterator q;
            q = m_hFileDictionary.find(m_strDX_FILE_TYPE[0]);
            if (q != m_hFileDictionary.end())
               hAttributes = (*q).second;
            Date hDate(m_strDATE_RECON[0].length() > 0 ? m_strDATE_RECON[0].c_str() : SwitchClock::instance()->getYYYYMMDDHHMMSS().substr(0,8).c_str());
            int lYear = hDate.getYear();
            int lMonth = hDate.getMonth();
            char szDATE_RECON[17];
            if (!m_strDATE_RECON[0].empty())
               (lMonth < 12) ? lMonth++ : lMonth = 1 + (0 * ++lYear); // bump to next month
            m_strDATE_RECON[0].assign(szDATE_RECON,snprintf(szDATE_RECON,sizeof(szDATE_RECON),"%04d%02d00",lYear,lMonth));
            if (hAttributes.cAdjustDate == 'Y')
            {
               int lEndDay = Date::daysInMonth(lYear,lMonth);
               Date hDate1(lYear, lMonth, lEndDay);
               adjustDate(hDate1);
               int lDay = hDate1.getDay(); //set hDate1 = DATE_RECON-1
               strTSTAMP_INITIATED.assign(szTSTAMP_INITIATED, snprintf(szTSTAMP_INITIATED, sizeof(szTSTAMP_INITIATED), "%04d%02d%02d%s99", lYear, lMonth, lDay, m_strSCHED_OFFSET_TIME[0].c_str()));
            }
            else
            {
               // bump TSTAMP_INITIATED to the 1st day of the next month
               (lMonth < 12) ? lMonth++ : lMonth = 1 + (0 * ++lYear);
               strTSTAMP_INITIATED.assign(szTSTAMP_INITIATED,snprintf(szTSTAMP_INITIATED,sizeof(szTSTAMP_INITIATED),"%04d%02d01%s99",lYear,lMonth,m_strSCHED_OFFSET_TIME[0].c_str()));
            }
         }
         m_pExportFile->setDATE_RECON(m_strDATE_RECON[0]);
         m_pExportFile->setSCHED_TIME(m_strSCHED_OFFSET_TIME[0]);
         m_pExportFile->setSCHED_FREQUENCY(m_strSCHED_FREQUENCY[0]);
         m_pExportFile->setTSTAMP_INITIATED(strTSTAMP_INITIATED);
         if (m_strDX_STATE == "PI")
         {
            m_pExportFile->setTASK_FORMATTED(Extract::instance()->getName());
            m_pExportFile->setTSTAMP_FORMATTED(strTSTAMP_INITIATED);
         }
         if (m_pExportFile->trigger())
            UseCase::addItem();
      }
   }
   m_strDX_FILE_TYPE[0] = m_strDX_FILE_TYPE[1];
   m_strINST_ID[0] = m_strINST_ID[1];
   m_strDATE_RECON[0] = m_strDATE_RECON[1];
   m_strROUTING_DATA[0] = m_strROUTING_DATA[1];
   m_strROUTING_PASSWORD[0] = m_strROUTING_PASSWORD[1];
   m_strROUTING_TYPE[0] = m_strROUTING_TYPE[1];
   m_strROUTING_USER_ID[0] = m_strROUTING_USER_ID[1];
   m_strSCHED_FREQUENCY[0] = m_strSCHED_FREQUENCY[1];
   m_strSCHED_OFFSET[0] = m_strSCHED_OFFSET[1];
   m_strSCHED_OFFSET_TIME[0] = m_strSCHED_OFFSET_TIME[1];
   m_iDX_REPORT_ID[0] = m_iDX_REPORT_ID[1];
   m_strDX_REPORT_STAT[0] = m_strDX_REPORT_STAT[1];
   m_strCUTOFF_TIME[0] = m_strCUTOFF_TIME[1];
   m_strENTITY_ID[0] = m_strENTITY_ID[1];
   m_strEntityType[0] = m_strEntityType[1];
   m_strPeriod[0] = m_strPeriod[1];
   m_strEVCLID[0] = m_strEVCLID[1];
  //## end database::FileFactory::update%41F170CD0157.body
}

// Additional Declarations
  //## begin database::FileFactory%41E967D6001F.declarations preserve=yes
  //## end database::FileFactory%41E967D6001F.declarations

} // namespace database

//## begin module%41E9697F006D.epilog preserve=yes
//## end module%41E9697F006D.epilog
