//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%405A1D6A0196.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%405A1D6A0196.cm

//## begin module%405A1D6A0196.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%405A1D6A0196.cp

//## Module: CXOSDB03%405A1D6A0196; Package specification
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB03.hpp

#ifndef CXOSDB03_h
#define CXOSDB03_h 1

//## begin module%405A1D6A0196.additionalIncludes preserve=no
//## end module%405A1D6A0196.additionalIncludes

//## begin module%405A1D6A0196.includes preserve=yes
// $Date:   Apr 08 2004 10:16:46  $ $Author:   D02405  $ $Revision:   1.1  $
//## end module%405A1D6A0196.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Job;
class FlatFile;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;

} // namespace timer

//## begin module%405A1D6A0196.declarations preserve=no
//## end module%405A1D6A0196.declarations

//## begin module%405A1D6A0196.additionalDeclarations preserve=yes
//## end module%405A1D6A0196.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::MaintenanceProcedure%405A1CF10128.preface preserve=yes
//## end database::MaintenanceProcedure%405A1CF10128.preface

//## Class: MaintenanceProcedure%405A1CF10128
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%405B30CF0242;timer::Date { -> F}
//## Uses: <unnamed>%405B30D103A9;IF::Job { -> F}
//## Uses: <unnamed>%405B314802DE;IF::FlatFile { -> F}

class DllExport MaintenanceProcedure : public reusable::Object  //## Inherits: <unnamed>%405A1D110242
{
  //## begin database::MaintenanceProcedure%405A1CF10128.initialDeclarations preserve=yes
  //## end database::MaintenanceProcedure%405A1CF10128.initialDeclarations

  public:
    //## Constructors (generated)
      MaintenanceProcedure();

    //## Destructor (generated)
      virtual ~MaintenanceProcedure();


    //## Other Operations (specified)
      //## Operation: execute%405A1D270148
      bool execute (const char* pszMember);

      //## Operation: review%405A1E690109
      virtual void review (const char* pszText);

    // Additional Public Declarations
      //## begin database::MaintenanceProcedure%405A1CF10128.public preserve=yes
      //## end database::MaintenanceProcedure%405A1CF10128.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Member%405B031F0399
      //## begin database::MaintenanceProcedure::Member%405B031F0399.attr preserve=no  protected: string {V} 
      string m_strMember;
      //## end database::MaintenanceProcedure::Member%405B031F0399.attr

    // Additional Protected Declarations
      //## begin database::MaintenanceProcedure%405A1CF10128.protected preserve=yes
      //## end database::MaintenanceProcedure%405A1CF10128.protected

  private:
    // Additional Private Declarations
      //## begin database::MaintenanceProcedure%405A1CF10128.private preserve=yes
      //## end database::MaintenanceProcedure%405A1CF10128.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::MaintenanceProcedure%405A1CF10128.implementation preserve=yes
      //## end database::MaintenanceProcedure%405A1CF10128.implementation

};

//## begin database::MaintenanceProcedure%405A1CF10128.postscript preserve=yes
//## end database::MaintenanceProcedure%405A1CF10128.postscript

} // namespace database

//## begin module%405A1D6A0196.epilog preserve=yes
using namespace database;
//## end module%405A1D6A0196.epilog


#endif
