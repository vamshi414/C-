//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3EC3E2F603D8.cm preserve=no
//## end module%3EC3E2F603D8.cm

//## begin module%3EC3E2F603D8.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3EC3E2F603D8.cp

//## Module: CXOSDB12%3EC3E2F603D8; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB12.cpp

//## begin module%3EC3E2F603D8.additionalIncludes preserve=no
//## end module%3EC3E2F603D8.additionalIncludes

//## begin module%3EC3E2F603D8.includes preserve=yes
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
//## end module%3EC3E2F603D8.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB13_h
#include "CXODDB13.hpp"
#endif
#ifndef CXOSDB12_h
#include "CXODDB12.hpp"
#endif


//## begin module%3EC3E2F603D8.declarations preserve=no
//## end module%3EC3E2F603D8.declarations

//## begin module%3EC3E2F603D8.additionalDeclarations preserve=yes
//## end module%3EC3E2F603D8.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::DatabaseColumn 

DatabaseColumn::DatabaseColumn()
  //## begin DatabaseColumn::DatabaseColumn%3EC3DC9F0399_const.hasinit preserve=no
      : m_bKey(false),
        m_lLength(0),
        m_iPrecision(0),
        m_iScale(0),
        m_iType(0)
  //## end DatabaseColumn::DatabaseColumn%3EC3DC9F0399_const.hasinit
  //## begin DatabaseColumn::DatabaseColumn%3EC3DC9F0399_const.initialization preserve=yes
  //## end DatabaseColumn::DatabaseColumn%3EC3DC9F0399_const.initialization
{
  //## begin database::DatabaseColumn::DatabaseColumn%3EC3DC9F0399_const.body preserve=yes
   memcpy(m_sID,"DB12",4);
   m_lOrdinal_Position = 0;
  //## end database::DatabaseColumn::DatabaseColumn%3EC3DC9F0399_const.body
}

DatabaseColumn::DatabaseColumn(const DatabaseColumn &right)
  //## begin DatabaseColumn::DatabaseColumn%3EC3DC9F0399_copy.hasinit preserve=no
  //## end DatabaseColumn::DatabaseColumn%3EC3DC9F0399_copy.hasinit
  //## begin DatabaseColumn::DatabaseColumn%3EC3DC9F0399_copy.initialization preserve=yes
   : m_strConstraintName(right.m_strConstraintName)
   ,m_strKeySequence(right.m_strKeySequence)
   ,m_strName(right.m_strName)
   ,m_strTypeName(right.m_strTypeName)
  //## end DatabaseColumn::DatabaseColumn%3EC3DC9F0399_copy.initialization
{
  //## begin database::DatabaseColumn::DatabaseColumn%3EC3DC9F0399_copy.body preserve=yes
   memcpy(m_sID,"DB12",4);
   m_bKey = right.m_bKey;
   m_lLength = right.m_lLength;
   m_iScale = right.m_iScale;
   m_iType = right.m_iType;
   m_lOrdinal_Position = right.m_lOrdinal_Position;
   m_iPrecision = right.m_iPrecision;
  //## end database::DatabaseColumn::DatabaseColumn%3EC3DC9F0399_copy.body
}


DatabaseColumn::~DatabaseColumn()
{
  //## begin database::DatabaseColumn::~DatabaseColumn%3EC3DC9F0399_dest.body preserve=yes
  //## end database::DatabaseColumn::~DatabaseColumn%3EC3DC9F0399_dest.body
}


DatabaseColumn & DatabaseColumn::operator=(const DatabaseColumn &right)
{
  //## begin database::DatabaseColumn::operator=%3EC3DC9F0399_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_strConstraintName = right.m_strConstraintName;
   m_bKey = right.m_bKey;
   m_strKeySequence = right.m_strKeySequence;
   m_lLength = right.m_lLength;
   m_strName = right.m_strName;
   m_iScale = right.m_iScale;
   m_iType = right.m_iType;
   m_strTypeName = right.m_strTypeName;
   m_lOrdinal_Position = right.m_lOrdinal_Position;
   m_iPrecision = right.m_iPrecision;
   return *this;
  //## end database::DatabaseColumn::operator=%3EC3DC9F0399_assign.body
}



//## Other Operations (implementation)
void DatabaseColumn::accept (database::DatabaseCatalogVisitor& hDatabaseCatalogVisitor)
{
  //## begin database::DatabaseColumn::accept%3EC3E9D103D8.body preserve=yes
   hDatabaseCatalogVisitor.visitDatabaseColumn(this);
  //## end database::DatabaseColumn::accept%3EC3E9D103D8.body
}

void DatabaseColumn::bind (reusable::Query& hQuery)
{
  //## begin database::DatabaseColumn::bind%3EC3DDF401A5.body preserve=yes
   string strDBVendor;
   Extract::instance()->getSpec("DBVENDOR",strDBVendor);
   if (strDBVendor == "SQLSERVER")
   {
      hQuery.bind("COLUMNS","NAME",Column::STRING,&m_strName);
      hQuery.bind("TYPES","NAME",Column::STRING,&m_strTypeName);
      hQuery.bind("COLUMNS","MAX_LENGTH",Column::LONG,&m_lLength);
      hQuery.bind("COLUMNS", "SCALE", Column::SHORT, &m_iScale);
      hQuery.bind("COLUMNS", "PRECISION", Column::SHORT, &m_iPrecision);
      hQuery.bind("INDEX_COLUMNS","KEY_ORDINAL",Column::STRING,&m_strKeySequence);
      hQuery.bind("INDEX_COLUMNS","INDEX_ID",Column::STRING,&m_strConstraintName); // !!! needs work ... assuming 2 is primary key
      hQuery.setOrderByClause("COLUMNS.NAME");
   }
   else
   if (strDBVendor == "ORACLE")
   {
      hQuery.bind("ALL_TAB_COLUMNS","COLUMN_NAME",Column::STRING,&m_strName);
      hQuery.bind("ALL_TAB_COLUMNS","DATA_TYPE",Column::STRING,&m_strTypeName);
      hQuery.bind("ALL_TAB_COLUMNS","DATA_LENGTH",Column::LONG,&m_lLength);
      hQuery.bind("ALL_TAB_COLUMNS","DATA_SCALE",Column::SHORT,&m_iScale);
      hQuery.bind("ALL_TAB_COLUMNS", "DATA_PRECISION", Column::SHORT, &m_iPrecision);
      hQuery.setOrderByClause("COLUMN_NAME");
   }
   else
   if (strDBVendor == "POSTGRES")
   {
      hQuery.bind("columns","column_name",Column::STRING,&m_strName);
      hQuery.bind("columns","data_type",Column::STRING,&m_strTypeName);
      hQuery.bind("columns","character_maximum_length",Column::LONG,&m_lLength);
      hQuery.bind("columns","numeric_scale",Column::SHORT,&m_iScale);
      hQuery.bind("columns", "numeric_precision", Column::SHORT, &m_iPrecision);
      hQuery.bind("X","constraint_name",Column::STRING,&m_strConstraintName);
      hQuery.bind("X","ordinal_position",Column::LONG,&m_lOrdinal_Position);
      hQuery.setOrderByClause("column_name");
   }
   else
   {
#ifdef MVS
      hQuery.bind("SYSCOLUMNS","NAME",Column::STRING,&m_strName);
      hQuery.bind("SYSCOLUMNS","COLTYPE",Column::STRING,&m_strTypeName);
      hQuery.bind("SYSCOLUMNS","LENGTH",Column::LONG,&m_lLength);
      hQuery.bind("SYSCOLUMNS","SCALE",Column::SHORT,&m_iScale);
      hQuery.bind("SYSCOLUMNS","KEYSEQ",Column::STRING,&m_strKeySequence);
      hQuery.setOrderByClause("NAME");
#else
      hQuery.bind("COLUMNS","COLNAME",Column::STRING,&m_strName);
      hQuery.bind("COLUMNS","TYPENAME",Column::STRING,&m_strTypeName);
      hQuery.bind("COLUMNS","LENGTH",Column::LONG,&m_lLength);
      hQuery.bind("COLUMNS","SCALE",Column::SHORT,&m_iScale);
      hQuery.bind("COLUMNS","KEYSEQ",Column::STRING,&m_strKeySequence);
      hQuery.setOrderByClause("COLNAME");
#endif
   }
  //## end database::DatabaseColumn::bind%3EC3DDF401A5.body
}

void DatabaseColumn::update (Subject* pSubject)
{
  //## begin database::DatabaseColumn::update%3EC4BE560177.body preserve=yes
   m_bKey = false;
   string strDBVendor;
   Extract::instance()->getSpec("DBVENDOR",strDBVendor);
   if (strDBVendor == "POSTGRES")
      transform(m_strName.begin(),m_strName.end(),m_strName.begin(),::toupper);
   if (m_strTypeName == "CLOB"
      || m_strTypeName == "clob")
      m_iType = 4;
   else
   if (m_strTypeName == "DECIMAL"
      || m_strTypeName == "decimal" 
      || m_strTypeName == "numeric")
      m_iType = 3;
   else
   if (m_strTypeName == "SMALLINT"
      || m_strTypeName == "smallint")
      m_iType = 2;
   else
   if (m_strTypeName == "INTEGER"
      || m_strTypeName == "integer"
      || m_strTypeName == "INT"
      || m_strTypeName == "int"
      || m_strTypeName == "NUMBER")
      m_iType = 1;
   else
      m_iType = 0;
#ifdef MVS
   m_bKey = m_strKeySequence != (const char*)"0";
   if (m_strTypeName == "DECIMAL")
      m_iPrecision = m_lLength;
#else
   if (strDBVendor == "SQLSERVER")
      m_bKey = (m_strConstraintName == "2");
   else
   if (strDBVendor == "POSTGRES")
      m_bKey = memcmp(m_strConstraintName.data(),"x0",2 ) == 0 ? true : false;
   else
   {
      m_bKey = m_strKeySequence.length() > 0;
      if (m_strTypeName == "DECIMAL") //LUW
         m_iPrecision = m_lLength;
   }
#endif
  //## end database::DatabaseColumn::update%3EC4BE560177.body
}

// Additional Declarations
  //## begin database::DatabaseColumn%3EC3DC9F0399.declarations preserve=yes
  //## end database::DatabaseColumn%3EC3DC9F0399.declarations

} // namespace database

//## begin module%3EC3E2F603D8.epilog preserve=yes
//## end module%3EC3E2F603D8.epilog
