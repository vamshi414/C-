//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5FEDE6FC028B.cm preserve=no
//	$Date:   Jan 21 2021 08:57:20  $ $Author:   e1044731  $ $Revision:   1.1  $
//## end module%5FEDE6FC028B.cm

//## begin module%5FEDE6FC028B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5FEDE6FC028B.cp

//## Module: CXOSDB67%5FEDE6FC028B; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.1A.R011\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB67.hpp

#ifndef CXOSDB67_h
#define CXOSDB67_h 1

//## begin module%5FEDE6FC028B.additionalIncludes preserve=no
//## end module%5FEDE6FC028B.additionalIncludes

//## begin module%5FEDE6FC028B.includes preserve=yes
//## end module%5FEDE6FC028B.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Trace;
class Extract;
} // namespace IF

//## Modelname: Connex Library::SecurityWrapper_CAT (SWDLL)%4A09A922013D
namespace securitywrapper {
class SecurityWrapper;

} // namespace securitywrapper

//## begin module%5FEDE6FC028B.declarations preserve=no
//## end module%5FEDE6FC028B.declarations

//## begin module%5FEDE6FC028B.additionalDeclarations preserve=yes
//## end module%5FEDE6FC028B.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Keystore%5FEDE8560267.preface preserve=yes
struct KeyData
{
   char sCategory[4];            //HMAC or PAN
   char sFunction[4];            //ZMK - Key Encrypting Key, HMAC, or default of DEK for PAN category
   char sID[2];                  //00-FF with leadin zeros or "ZM" for ZMK and "HM" for HMAC
   char sKCVofComponent[6];      //Key Check Value of component
   char sKCVofKey[6];            //Key Check Value of assembled key
   char cStatus;                 //Active-Inactive status of the keys. At a time 1 pan key and 2 HMAC can be ctive
   char sComponentNumber[1];     //
   char sKeyValue[64];           //Base64, AES256 encrypted value (max actual size decoded and decrypted key in binary bytes is 32)
};
//## end database::Keystore%5FEDE8560267.preface

//## Class: Keystore%5FEDE8560267
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5FEDF46600B2;IF::Extract { -> F}
//## Uses: <unnamed>%5FEDF472020E;IF::Trace { -> F}
//## Uses: <unnamed>%5FEDF4740375;IF::CodeTable { -> F}
//## Uses: <unnamed>%5FEDF49A007A;securitywrapper::SecurityWrapper { -> F}

class DllExport Keystore : public reusable::Object  //## Inherits: <unnamed>%5FEDE87803DC
{
  //## begin database::Keystore%5FEDE8560267.initialDeclarations preserve=yes
  //## end database::Keystore%5FEDE8560267.initialDeclarations

  public:
    //## Constructors (generated)
      Keystore();

    //## Destructor (generated)
      virtual ~Keystore();


    //## Other Operations (specified)
      //## Operation: base32Decode%5FEDEA5403A7
      bool base32Decode (string strInput, string& strOutput);

      //## Operation: decrypt%5FEDEA88032D
      bool decrypt (string& strText);

      //## Operation: decryptPostilionPan%5FEDEAA7025C
      bool decryptPostilionPan (const string& strPostilionPan, string& strClearPan);

      //## Operation: desecb3%5FEDF574002F
      bool desecb3 (string& strText, const string& strKey, int enc);

      //## Operation: getKey%5FEDEB3D03AD
      reusable::string getKey (string& strKeyID);

      //## Operation: initialize%5FEDEAED0011
      bool initialize ();

      //## Operation: instance%5FEDEB0001D8
      static Keystore* instance ();

      //## Operation: setKey%5FEDEB230291
      void setKey ();

      //## Operation: hmac%5FEDF36E01D3
      bool hmac (const string& strData, const string& strKey, string& strResult);

    // Additional Public Declarations
      //## begin database::Keystore%5FEDE8560267.public preserve=yes
      //## end database::Keystore%5FEDE8560267.public

  protected:
    // Additional Protected Declarations
      //## begin database::Keystore%5FEDE8560267.protected preserve=yes
      //## end database::Keystore%5FEDE8560267.protected

  private:
    // Additional Private Declarations
      //## begin database::Keystore%5FEDE8560267.private preserve=yes
      //## end database::Keystore%5FEDE8560267.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Base32%5FEDF27B036C
      //## begin database::Keystore::Base32%5FEDF27B036C.attr preserve=no  private: map<char,string> {U} 
      map<char,string> m_hBase32;
      //## end database::Keystore::Base32%5FEDF27B036C.attr

      //## Attribute: Base64%5FEDF29B024A
      //## begin database::Keystore::Base64%5FEDF29B024A.attr preserve=no  private: map<string,char> {U} 
      map<string,char> m_hBase64;
      //## end database::Keystore::Base64%5FEDF29B024A.attr

      //## Attribute: File%5FEDECB9019D
      //## begin database::Keystore::File%5FEDECB9019D.attr preserve=no  private: FILE* {U} 
      FILE* m_pFile;
      //## end database::Keystore::File%5FEDECB9019D.attr

      //## Attribute: Key%5FEDECC700AE
      //## begin database::Keystore::Key%5FEDECC700AE.attr preserve=no  private: string {U} 
      string m_strKey;
      //## end database::Keystore::Key%5FEDECC700AE.attr

      //## Attribute: Keys%5FEDF2040198
      //## begin database::Keystore::Keys%5FEDF2040198.attr preserve=no  private: map<string,string,less<string> > {U} 
      map<string,string,less<string> > m_hKeys;
      //## end database::Keystore::Keys%5FEDF2040198.attr

      //## Attribute: InBuffer%5FEDEB9700A7
      //## begin database::Keystore::InBuffer%5FEDEB9700A7.attr preserve=no  private: unsigned char {U} 
      unsigned char m_szInBuffer[520];
      //## end database::Keystore::InBuffer%5FEDEB9700A7.attr

      //## Attribute: Instance%5FEDEB6B0117
      //## begin database::Keystore::Instance%5FEDEB6B0117.attr preserve=no  private: static Keystore* {U} 
      static Keystore* m_pInstance;
      //## end database::Keystore::Instance%5FEDEB6B0117.attr

      //## Attribute: OutBuffer%5FEDECAD003C
      //## begin database::Keystore::OutBuffer%5FEDECAD003C.attr preserve=no  private: unsigned char {U} 
      unsigned char m_szOutBuffer[520];
      //## end database::Keystore::OutBuffer%5FEDECAD003C.attr

      //## Attribute: Passphrase%5FEDECE003C3
      //## begin database::Keystore::Passphrase%5FEDECE003C3.attr preserve=no  private: string {U} 
      string m_strPassphrase;
      //## end database::Keystore::Passphrase%5FEDECE003C3.attr

      //## Attribute: Records%5FEDF1D402A3
      //## begin database::Keystore::Records%5FEDF1D402A3.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hRecords;
      //## end database::Keystore::Records%5FEDF1D402A3.attr

      //## Attribute: ValidationPhrase%5FEDF2D60245
      //## begin database::Keystore::ValidationPhrase%5FEDF2D60245.attr preserve=no  private: string {U} 
      string m_strValidationPhrase;
      //## end database::Keystore::ValidationPhrase%5FEDF2D60245.attr

    // Additional Implementation Declarations
      //## begin database::Keystore%5FEDE8560267.implementation preserve=yes
      //## end database::Keystore%5FEDE8560267.implementation

};

//## begin database::Keystore%5FEDE8560267.postscript preserve=yes
//## end database::Keystore%5FEDE8560267.postscript

} // namespace database

//## begin module%5FEDE6FC028B.epilog preserve=yes
//## end module%5FEDE6FC028B.epilog


#endif
