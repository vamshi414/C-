//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%405A1D6C00DA.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%405A1D6C00DA.cm

//## begin module%405A1D6C00DA.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%405A1D6C00DA.cp

//## Module: CXOSDB03%405A1D6C00DA; Package body
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB03.cpp

//## begin module%405A1D6C00DA.additionalIncludes preserve=no
//## end module%405A1D6C00DA.additionalIncludes

//## begin module%405A1D6C00DA.includes preserve=yes
// $Date:   May 14 2020 18:12:10  $ $Author:   e1009510  $ $Revision:   1.5  $
//## end module%405A1D6C00DA.includes

#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSDB03_h
#include "CXODDB03.hpp"
#endif


//## begin module%405A1D6C00DA.declarations preserve=no
//## end module%405A1D6C00DA.declarations

//## begin module%405A1D6C00DA.additionalDeclarations preserve=yes
//## end module%405A1D6C00DA.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::MaintenanceProcedure 

MaintenanceProcedure::MaintenanceProcedure()
  //## begin MaintenanceProcedure::MaintenanceProcedure%405A1CF10128_const.hasinit preserve=no
  //## end MaintenanceProcedure::MaintenanceProcedure%405A1CF10128_const.hasinit
  //## begin MaintenanceProcedure::MaintenanceProcedure%405A1CF10128_const.initialization preserve=yes
  //## end MaintenanceProcedure::MaintenanceProcedure%405A1CF10128_const.initialization
{
  //## begin database::MaintenanceProcedure::MaintenanceProcedure%405A1CF10128_const.body preserve=yes
  //## end database::MaintenanceProcedure::MaintenanceProcedure%405A1CF10128_const.body
}


MaintenanceProcedure::~MaintenanceProcedure()
{
  //## begin database::MaintenanceProcedure::~MaintenanceProcedure%405A1CF10128_dest.body preserve=yes
  //## end database::MaintenanceProcedure::~MaintenanceProcedure%405A1CF10128_dest.body
}



//## Other Operations (implementation)
bool MaintenanceProcedure::execute (const char* pszMember)
{
  //## begin database::MaintenanceProcedure::execute%405A1D270148.body preserve=yes
   m_strMember = pszMember;
   Date hDate(Date::today());
   string strToday(hDate.asString("%y%m%d"));
   hDate -= 1;
   string strYesterday(hDate.asString("%y%m%d"));
   if(Job::submit(pszMember,"&YYMMDD ",strToday.c_str(),"&PYYMMDD",strYesterday.c_str()))
   {
      IF::FlatFile hFlatFile("RESULTS",Job::getMember().c_str());
      char* psBuffer = new char[256];
      size_t m = 0;
      while (hFlatFile.read(psBuffer,256,&m))
         review(psBuffer);
      delete [] psBuffer;
   }
   return true;
  //## end database::MaintenanceProcedure::execute%405A1D270148.body
}

void MaintenanceProcedure::review (const char* pszText)
{
  //## begin database::MaintenanceProcedure::review%405A1E690109.body preserve=yes
  //## end database::MaintenanceProcedure::review%405A1E690109.body
}

// Additional Declarations
  //## begin database::MaintenanceProcedure%405A1CF10128.declarations preserve=yes
  //## end database::MaintenanceProcedure%405A1CF10128.declarations

} // namespace database

//## begin module%405A1D6C00DA.epilog preserve=yes
//## end module%405A1D6C00DA.epilog
