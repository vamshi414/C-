//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C06E02F023A.cm preserve=no
//	$Date:   Jun 12 2019 08:00:46  $ $Author:   e1009839  $
//	$Revision:   1.3  $
//## end module%5C06E02F023A.cm

//## begin module%5C06E02F023A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C06E02F023A.cp

//## Module: CXOSDB61%5C06E02F023A; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB61.cpp

//## begin module%5C06E02F023A.additionalIncludes preserve=no
//## end module%5C06E02F023A.additionalIncludes

//## begin module%5C06E02F023A.includes preserve=yes
//## end module%5C06E02F023A.includes

#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOSRU55_h
#include "CXODRU55.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB61_h
#include "CXODDB61.hpp"
#endif


//## begin module%5C06E02F023A.declarations preserve=no
//## end module%5C06E02F023A.declarations

//## begin module%5C06E02F023A.additionalDeclarations preserve=yes
//## end module%5C06E02F023A.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::Delegate

//## begin database::Delegate::Instance%5C0FEC8A0340.attr preserve=no  private: static vector<Delegate*>* {V} 0
vector<Delegate*>* Delegate::m_pInstance = 0;
//## end database::Delegate::Instance%5C0FEC8A0340.attr

Delegate::Delegate()
  //## begin Delegate::Delegate%5C06DEED0051_const.hasinit preserve=no
      : m_pActive(0),
        m_pFirst(0),
        m_pLast(0),
        m_iNumber(0),
        m_bQuiesce(false),
        m_pState(0),
        m_iThreads(0),
        m_pNext(0)
  //## end Delegate::Delegate%5C06DEED0051_const.hasinit
  //## begin Delegate::Delegate%5C06DEED0051_const.initialization preserve=yes
  //## end Delegate::Delegate%5C06DEED0051_const.initialization
{
  //## begin database::Delegate::Delegate%5C06DEED0051_const.body preserve=yes
   memcpy(m_sID,"DB61",4);
  //## end database::Delegate::Delegate%5C06DEED0051_const.body
}

Delegate::Delegate(const Delegate &right)
  //## begin Delegate::Delegate%5C06DEED0051_copy.hasinit preserve=no
  //## end Delegate::Delegate%5C06DEED0051_copy.hasinit
  //## begin Delegate::Delegate%5C06DEED0051_copy.initialization preserve=yes
   : Object(right)
  //## end Delegate::Delegate%5C06DEED0051_copy.initialization
{
  //## begin database::Delegate::Delegate%5C06DEED0051_copy.body preserve=yes
   m_pFirst = 0;
   m_pLast = 0;
   m_iNumber = 0;
   m_pState = 0;
   m_iThreads = 0;
   m_pNext = 0;
  //## end database::Delegate::Delegate%5C06DEED0051_copy.body
}


Delegate::~Delegate()
{
  //## begin database::Delegate::~Delegate%5C06DEED0051_dest.body preserve=yes
  //## end database::Delegate::~Delegate%5C06DEED0051_dest.body
}


Delegate & Delegate::operator=(const Delegate &right)
{
  //## begin database::Delegate::operator=%5C06DEED0051_assign.body preserve=yes
   if (&right == this)
      return *this;
   Object::operator=(right);
   m_pFirst = 0;
   m_pLast = 0;
   m_iNumber = 0;
   m_pState = 0;
   m_iThreads = 0;
   m_pNext = 0;
   return *this;
  //## end database::Delegate::operator=%5C06DEED0051_assign.body
}



//## Other Operations (implementation)
int Delegate::addThread ()
{
  //## begin database::Delegate::addThread%5C06E0DB02D8.body preserve=yes
   CriticalSection hCriticalSection;
   if (!m_pState)
   {
      m_pState = new vector<Delegate::State>;
      m_pState->reserve(CXTHREADS);
      m_pFirst = new vector<Delegate*>;
      m_pFirst->reserve(CXTHREADS);
      m_pLast = new vector<Delegate*>;
      m_pLast->reserve(CXTHREADS);
      m_pActive = new vector<bool>;
      m_pActive->reserve(CXTHREADS);
   }
   ++m_iThreads;
   m_pState->push_back(Delegate::IDLE);
   m_pFirst->push_back(0);
   m_pLast->push_back(0);
   m_pActive->push_back(false);
   return m_iThreads;
  //## end database::Delegate::addThread%5C06E0DB02D8.body
}

bool Delegate::busy ()
{
  //## begin database::Delegate::busy%5C06E0DF01E1.body preserve=yes
   for (int i = 0;i < m_pState->size();++i)
      if ((*m_pState)[i] != Delegate::IDLE)
         return true;
   return false;
  //## end database::Delegate::busy%5C06E0DF01E1.body
}

void Delegate::commit (const reusable::string& strCONTEXT_DATA)
{
  //## begin database::Delegate::commit%5C06E0E20398.body preserve=yes
   m_strCONTEXT_DATA = strCONTEXT_DATA;
   if (m_pState)
   {
      {
         CriticalSection hCriticalSection;
         for (int i = 0;i < m_pState->size();++i)
            (*m_pState)[i] = Delegate::COMMIT;
      }
      while (busy())
         Sleep::goTo("00000100");
   }
  //## end database::Delegate::commit%5C06E0E20398.body
}

void Delegate::execute (vector<Object*>& hObject)
{
  //## begin database::Delegate::execute%5C06F06902A6.body preserve=yes
  //## end database::Delegate::execute%5C06F06902A6.body
}

bool Delegate::getActive (int iThread)
{
  //## begin database::Delegate::getActive%5C2CD6F90314.body preserve=yes
   return (*m_pActive)[iThread];
  //## end database::Delegate::getActive%5C2CD6F90314.body
}

database::Delegate* Delegate::getFirst (int iThread)
{
  //## begin database::Delegate::getFirst%5C06E0E60302.body preserve=yes
   return (*m_pFirst)[iThread];
  //## end database::Delegate::getFirst%5C06E0E60302.body
}

database::Delegate* Delegate::getLast (int iThread)
{
  //## begin database::Delegate::getLast%5C06E0E902B0.body preserve=yes
   return (*m_pLast)[iThread];
  //## end database::Delegate::getLast%5C06E0E902B0.body
}

Delegate::State Delegate::getState ()
{
  //## begin database::Delegate::getState%5C0ED800036A.body preserve=yes
   if (m_pState)
      for (int i = 0;i < m_pState->size();++i)
         if ((*m_pState)[i] == Delegate::ROLLBACKREQUIRED)
            return Delegate::ROLLBACK;
   return Delegate::COMMIT;
  //## end database::Delegate::getState%5C0ED800036A.body
}

Delegate::State Delegate::getState (int iThread)
{
  //## begin database::Delegate::getState%5C06E0EC0161.body preserve=yes
   return (*m_pState)[iThread];
  //## end database::Delegate::getState%5C06E0EC0161.body
}

database::Delegate* Delegate::instance (int iNumber)
{
  //## begin database::Delegate::instance%5C0FE7610318.body preserve=yes
   if (!m_pInstance)
   {
      m_pInstance = new vector<Delegate*>;
      m_pInstance->reserve(reusable::Thread::getTotal());
      for (int j = 0;j < reusable::Thread::getTotal();++j)
         m_pInstance->push_back(0);
   }
   while (iNumber >= m_pInstance->size())
      Sleep::goTo("00000100");
   if (!(*m_pInstance)[iNumber])
      (*m_pInstance)[iNumber] = new Delegate();
   (*m_pInstance)[iNumber]->setNumber(iNumber);
   return (*m_pInstance)[iNumber];
  //## end database::Delegate::instance%5C0FE7610318.body
}

bool Delegate::pop (int iThread, vector<Object*>& hObject)
{
  //## begin database::Delegate::pop%5C06ECB70183.body preserve=yes
   Delegate* p = 0;
   {
      CriticalSection hCriticalSection;
      p = getFirst(iThread);
      if (!p)
         return false;
      setActive(iThread,true);
      setFirst(iThread,p->getNext());
      if (getFirst(iThread) == 0)
         setLast(iThread,0);
      if (getState(iThread) == Delegate::IDLE)
         setState(iThread,Delegate::COMMITREQUIRED);
   }
   p->execute(hObject);
   delete p;
   {
      CriticalSection hCriticalSection;
      if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
         setState(iThread,Delegate::ROLLBACKREQUIRED);
      setActive(iThread,false);
   }
   return true;
  //## end database::Delegate::pop%5C06ECB70183.body
}

void Delegate::push (int iThread, database::Delegate* pDelegate)
{
  //## begin database::Delegate::push%5C06EB7003E0.body preserve=yes
   CriticalSection hCriticalSection;
   if (getFirst(iThread) == 0)
      setFirst(iThread,pDelegate);
   else
      getLast(iThread)->setNext(pDelegate);
   setLast(iThread,pDelegate);
  //## end database::Delegate::push%5C06EB7003E0.body
}

void Delegate::rollback ()
{
  //## begin database::Delegate::rollback%5C06E0EF018B.body preserve=yes
   if (m_pState)
   {
      {
         CriticalSection hCriticalSection;
         for (int i = 0;i < m_pState->size();++i)
            if ((*m_pState)[i] != Delegate::IDLE)
               (*m_pState)[i] = Delegate::ROLLBACK;
      }
      while (busy())
         Sleep::goTo("00000100");
   }
  //## end database::Delegate::rollback%5C06E0EF018B.body
}

void Delegate::setActive (int iThread, bool bActive)
{
  //## begin database::Delegate::setActive%5C2CD704030D.body preserve=yes
   (*m_pActive)[iThread] = bActive;
  //## end database::Delegate::setActive%5C2CD704030D.body
}

void Delegate::setFirst (int iThread, database::Delegate* pDelegate)
{
  //## begin database::Delegate::setFirst%5C06E0F201F1.body preserve=yes
   (*m_pFirst)[iThread] = pDelegate;
  //## end database::Delegate::setFirst%5C06E0F201F1.body
}

void Delegate::setLast (int iThread, database::Delegate* pDelegate)
{
  //## begin database::Delegate::setLast%5C06E0F502A9.body preserve=yes
   (*m_pLast)[iThread] = pDelegate;
  //## end database::Delegate::setLast%5C06E0F502A9.body
}

void Delegate::setState (int iThread, Delegate::State nState)
{
  //## begin database::Delegate::setState%5C06E0F802D1.body preserve=yes
   (*m_pState)[iThread] = nState;
  //## end database::Delegate::setState%5C06E0F802D1.body
}

void Delegate::wait ()
{
  //## begin database::Delegate::wait%5C06E0FD00C1.body preserve=yes
   while (m_pFirst)
   {
      bool bWait = false;
      for (int i = 0;i < m_pFirst->size();++i)
         if (getFirst(i) != 0
            || getActive(i))
         {
            bWait = true;
            break;
         }
      if (!bWait)
         break;
      Sleep::goTo("00000100");
   }
  //## end database::Delegate::wait%5C06E0FD00C1.body
}

//## Get and Set Operations for Class Attributes (implementation)

const int Delegate::getThreads () const
{
  //## begin database::Delegate::getThreads%5C06E11001C8.get preserve=no
  return m_iThreads;
  //## end database::Delegate::getThreads%5C06E11001C8.get
}

// Additional Declarations
  //## begin database::Delegate%5C06DEED0051.declarations preserve=yes
  //## end database::Delegate%5C06DEED0051.declarations

} // namespace database

//## begin module%5C06E02F023A.epilog preserve=yes
//## end module%5C06E02F023A.epilog
