//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41ED29D000BB.cm preserve=no
//	$Date:   Aug 08 2021 22:11:44  $ $Author:   e5614616  $
//	$Revision:   1.12  $
//## end module%41ED29D000BB.cm

//## begin module%41ED29D000BB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%41ED29D000BB.cp

//## Module: CXOSDB27%41ED29D000BB; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Dbdll\CXODDB27.hpp

#ifndef CXOSDB27_h
#define CXOSDB27_h 1

//## begin module%41ED29D000BB.additionalIncludes preserve=no
//## end module%41ED29D000BB.additionalIncludes

//## begin module%41ED29D000BB.includes preserve=yes
#include <map>
#include <vector>
//## end module%41ED29D000BB.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
class Transaction;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
class FileFactory;

} // namespace database

//## begin module%41ED29D000BB.declarations preserve=no
//## end module%41ED29D000BB.declarations

//## begin module%41ED29D000BB.additionalDeclarations preserve=yes
//## end module%41ED29D000BB.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::DataControl%41ED292801E4.preface preserve=yes
//## end database::DataControl%41ED292801E4.preface

//## Class: DataControl%41ED292801E4
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%41EFAD7D038A;reusable::Query { -> F}
//## Uses: <unnamed>%41EFAD7F01C5;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%41EFAD8003D8;DatabaseFactory { -> F}
//## Uses: <unnamed>%41EFB269000F;FileFactory { -> F}
//## Uses: <unnamed>%420644D100AB;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%457F14450232;IF::Extract { -> F}
//## Uses: <unnamed>%5878D45503CF;Database { -> F}
//## Uses: <unnamed>%5878D476003C;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%5878D4C200A0;reusable::Transaction { -> F}

class DllExport DataControl : public reusable::Observer  //## Inherits: <unnamed>%41ED2949002E
{
  //## begin database::DataControl%41ED292801E4.initialDeclarations preserve=yes
  public:
      enum Level
      {
         G,
         P,
         I,
         M
      };
  //## end database::DataControl%41ED292801E4.initialDeclarations

  public:
    //## Constructors (generated)
      DataControl();

    //## Constructors (specified)
      //## Operation: DataControl%4DF8FB710270
      DataControl (const string& strQualifier);

    //## Destructor (generated)
      virtual ~DataControl();


    //## Other Operations (specified)
      //## Operation: getDestination%457F0EEC0261
      bool getDestination (const string& strPROC_ID, const string& strDX_FILE_TYPE, string& strPROC_DEST_ID);

      //## Operation: getInstitutionDestination%610CA6E0003D
      bool getInstitutionDestination (const string& strINST_ID, const string& strDX_FILE_TYPE, string& strINST_DEST_ID);

      //## Operation: instance%41ED2A9502AF
      static DataControl* instance (const char* pszQualifier = 0);

      //## Operation: replicate%41ED297800BB
      bool replicate (const char* pszENTITY_TYPE, const string& strENTITY_ID, const string& strDATE_RECON = "", const string& strRole = "A");

      //## Operation: update%41ED2953004E
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Success%4DF8BC8F0335
      const bool getSuccess () const
      {
        //## begin database::DataControl::getSuccess%4DF8BC8F0335.get preserve=no
        return m_bSuccess;
        //## end database::DataControl::getSuccess%4DF8BC8F0335.get
      }


    // Additional Public Declarations
      //## begin database::DataControl%41ED292801E4.public preserve=yes
      const bool getLevel(enum Level nLevel) const
      {
         return m_bLevel[nLevel];
      }
      //## end database::DataControl%41ED292801E4.public
  protected:
    // Additional Protected Declarations
      //## begin database::DataControl%41ED292801E4.protected preserve=yes
      //## end database::DataControl%41ED292801E4.protected

  private:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Qualifier%4DF8B1CB0219
      const string& getQualifier () const
      {
        //## begin database::DataControl::getQualifier%4DF8B1CB0219.get preserve=no
        return m_strQualifier;
        //## end database::DataControl::getQualifier%4DF8B1CB0219.get
      }

      void setQualifier (const string& value)
      {
        //## begin database::DataControl::setQualifier%4DF8B1CB0219.set preserve=no
        m_strQualifier = value;
        //## end database::DataControl::setQualifier%4DF8B1CB0219.set
      }


    // Additional Private Declarations
      //## begin database::DataControl%41ED292801E4.private preserve=yes
      //## end database::DataControl%41ED292801E4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DataControl%4DF8B15103DE
      //## begin database::DataControl::DataControl%4DF8B15103DE.attr preserve=no  private: static map<string,DataControl*,less<string> >* {V} 0
      static map<string,DataControl*,less<string> >* m_pDataControl;
      //## end database::DataControl::DataControl%4DF8B15103DE.attr

      //## Attribute: Instance%41ED2A7F02EE
      //## begin database::DataControl::Instance%41ED2A7F02EE.attr preserve=no  private: static DataControl* {V} 0
      static DataControl* m_pInstance;
      //## end database::DataControl::Instance%41ED2A7F02EE.attr

      //## Attribute: PostingFile%421E3E4D00CB
      //## begin database::DataControl::PostingFile%421E3E4D00CB.attr preserve=no  private: map<string,vector<ExportFile*>,less<string> > {V} 
      map<string,vector<ExportFile*>,less<string> > m_hPostingFile;
      //## end database::DataControl::PostingFile%421E3E4D00CB.attr

      //## begin database::DataControl::Qualifier%4DF8B1CB0219.attr preserve=no  private: string {V} "CUSTQUAL"
      string m_strQualifier;
      //## end database::DataControl::Qualifier%4DF8B1CB0219.attr

      //## begin database::DataControl::Success%4DF8BC8F0335.attr preserve=no  public: bool {V} false
      bool m_bSuccess;
      //## end database::DataControl::Success%4DF8BC8F0335.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%41EEBCF30271
      //## Role: DataControl::<m_hExportFile>%41EEBCF40157
      //## begin database::DataControl::<m_hExportFile>%41EEBCF40157.role preserve=no  public: database::ExportFile { -> VHgN}
      ExportFile m_hExportFile;
      //## end database::DataControl::<m_hExportFile>%41EEBCF40157.role

    // Additional Implementation Declarations
      //## begin database::DataControl%41ED292801E4.implementation preserve=yes
      string m_strKey;
      bool m_bLevel[4];
      //## end database::DataControl%41ED292801E4.implementation
};

//## begin database::DataControl%41ED292801E4.postscript preserve=yes
//## end database::DataControl%41ED292801E4.postscript

} // namespace database

//## begin module%41ED29D000BB.epilog preserve=yes
using namespace database;
//## end module%41ED29D000BB.epilog


#endif
