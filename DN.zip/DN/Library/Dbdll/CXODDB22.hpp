//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3D80EA2401D4.cm preserve=no
//	$Date:   May 07 2020 08:09:40  $ $Author:   e3028298  $
//	$Revision:   1.11  $
//## end module%3D80EA2401D4.cm

//## begin module%3D80EA2401D4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3D80EA2401D4.cp

//## Module: CXOSDB22%3D80EA2401D4; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\V02.9B.R001\ConnexPlatform\Server\Library\Dbdll\CXODDB22.hpp

#ifndef CXOSDB22_h
#define CXOSDB22_h 1

//## begin module%3D80EA2401D4.additionalIncludes preserve=no
//## end module%3D80EA2401D4.additionalIncludes

//## begin module%3D80EA2401D4.includes preserve=yes
// $Date:   May 07 2020 08:09:40  $ $Author:   e3028298  $ $Revision:   1.11  $
//## end module%3D80EA2401D4.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%3D80EA2401D4.declarations preserve=no
//## end module%3D80EA2401D4.declarations

//## begin module%3D80EA2401D4.additionalDeclarations preserve=yes
//## end module%3D80EA2401D4.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::GenericDelete%3D80EAFB0128.preface preserve=yes
//## end database::GenericDelete%3D80EAFB0128.preface

//## Class: GenericDelete%3D80EAFB0128
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3D80ED250196;reusable::Statement { -> F}
//## Uses: <unnamed>%3D80ED270261;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%3D80ED2C0222;reusable::Table { -> F}
//## Uses: <unnamed>%3D820F4D01B5;Database { -> F}
//## Uses: <unnamed>%3D820F6C0109;monitor::UseCase { -> F}
//## Uses: <unnamed>%3D821202037A;timer::Date { -> F}
//## Uses: <unnamed>%3D8213FB009C;DatabaseFactory { -> F}
//## Uses: <unnamed>%5E4A5CE20111;IF::Extract { -> F}
//## Uses: <unnamed>%5E4A62320177;reusable::Buffer { -> F}

class DllExport GenericDelete : public reusable::Observer  //## Inherits: <unnamed>%3D80EDA6030D
{
  //## begin database::GenericDelete%3D80EAFB0128.initialDeclarations preserve=yes
  //## end database::GenericDelete%3D80EAFB0128.initialDeclarations

  public:
    //## Constructors (generated)
      GenericDelete();

    //## Constructors (specified)
      //## Operation: GenericDelete%3D88C522004E
      GenericDelete (char *pszTableName);

      //## Operation: GenericDelete%3D8888700251
      GenericDelete (char *pszTableName, char *pszKeyColumn, bool bNumeric = false, short siMinimumRetentionDays = 0, char *szQualifier = "CUSTQUAL");

    //## Destructor (generated)
      virtual ~GenericDelete();


    //## Other Operations (specified)
      //## Operation: deleteClosedRecords%5E4A52350134
      void deleteClosedRecords (const string& strYYYYMMDDHHMMSSHN);

      //## Operation: deleteRecords%3D82154D0186
      bool deleteRecords (char *szDateColumn, char *szRetentionPeriod);

      //## Operation: deleteRecords%3D80F76E007D
      bool deleteRecords (char *szDateColumn, int nRetentionDays);

      //## Operation: update%3D8F60F50251
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin database::GenericDelete%3D80EAFB0128.public preserve=yes
      //## end database::GenericDelete%3D80EAFB0128.public

  protected:
    // Additional Protected Declarations
      //## begin database::GenericDelete%3D80EAFB0128.protected preserve=yes
      //## end database::GenericDelete%3D80EAFB0128.protected

  private:

    //## Other Operations (specified)
      //## Operation: deleteRecords%3D88A2100261
      bool deleteRecords ();

      //## Operation: getDateFromDays%3D88A587037A
      void getDateFromDays (int nRetentionDays);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: TableName%3D889CD7002E
      void setTableName (const string& value)
      {
        //## begin database::GenericDelete::setTableName%3D889CD7002E.set preserve=no
        m_strTableName = value;
        //## end database::GenericDelete::setTableName%3D889CD7002E.set
      }


    // Additional Private Declarations
      //## begin database::GenericDelete%3D80EAFB0128.private preserve=yes
      //## end database::GenericDelete%3D80EAFB0128.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DateColumn%3D8F64A600EA
      //## begin database::GenericDelete::DateColumn%3D8F64A600EA.attr preserve=no  public: string {V} 
      string m_strDateColumn;
      //## end database::GenericDelete::DateColumn%3D8F64A600EA.attr

      //## Attribute: DeleteDate%3D88A5370109
      //## begin database::GenericDelete::DeleteDate%3D88A5370109.attr preserve=no  public: string {V} 
      string m_strDeleteDate;
      //## end database::GenericDelete::DeleteDate%3D88A5370109.attr

      //## Attribute: Key%41BDBEC3036B
      //## begin database::GenericDelete::Key%41BDBEC3036B.attr preserve=no  public: string {V} 
      string m_strKey;
      //## end database::GenericDelete::Key%41BDBEC3036B.attr

      //## Attribute: KeyColumn%3D888A1A0232
      //## begin database::GenericDelete::KeyColumn%3D888A1A0232.attr preserve=no  public: string {V} 
      string m_strKeyColumn;
      //## end database::GenericDelete::KeyColumn%3D888A1A0232.attr

      //## Attribute: MinimumRetentionDays%3F2FC34F004E
      //## begin database::GenericDelete::MinimumRetentionDays%3F2FC34F004E.attr preserve=no  public: short {V} 0
      short m_siMinimumRetentionDays;
      //## end database::GenericDelete::MinimumRetentionDays%3F2FC34F004E.attr

      //## Attribute: Numeric%41BDBDB4002E
      //## begin database::GenericDelete::Numeric%41BDBDB4002E.attr preserve=no  public: bool {V} false
      bool m_bNumeric;
      //## end database::GenericDelete::Numeric%41BDBDB4002E.attr

      //## Attribute: Qualifier%4105EA0F0128
      //## begin database::GenericDelete::Qualifier%4105EA0F0128.attr preserve=no  public: string {V} "CUSTQUAL"
      string m_strQualifier;
      //## end database::GenericDelete::Qualifier%4105EA0F0128.attr

      //## begin database::GenericDelete::TableName%3D889CD7002E.attr preserve=no  private: string {V} 
      string m_strTableName;
      //## end database::GenericDelete::TableName%3D889CD7002E.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%3D8F661801E4
      //## Role: GenericDelete::<m_hQuery>%3D8F66190148
      //## begin database::GenericDelete::<m_hQuery>%3D8F66190148.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end database::GenericDelete::<m_hQuery>%3D8F66190148.role

    // Additional Implementation Declarations
      //## begin database::GenericDelete%3D80EAFB0128.implementation preserve=yes
      //## end database::GenericDelete%3D80EAFB0128.implementation

};

//## begin database::GenericDelete%3D80EAFB0128.postscript preserve=yes
//## end database::GenericDelete%3D80EAFB0128.postscript

} // namespace database

//## begin module%3D80EA2401D4.epilog preserve=yes
using namespace database;
//## end module%3D80EA2401D4.epilog


#endif
