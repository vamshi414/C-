//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4C64508B03AC.cm preserve=no
//	$Date:   May 14 2020 18:12:06  $ $Author:   e1009510  $
//	$Revision:   1.3  $
//## end module%4C64508B03AC.cm

//## begin module%4C64508B03AC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4C64508B03AC.cp

//## Module: CXOSDB42%4C64508B03AC; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB42.hpp

#ifndef CXOSDB42_h
#define CXOSDB42_h 1

//## begin module%4C64508B03AC.additionalIncludes preserve=no
//## end module%4C64508B03AC.additionalIncludes

//## begin module%4C64508B03AC.includes preserve=yes
#ifndef CXOSRU41_h
#include "CXODRU41.hpp"
#endif
//## end module%4C64508B03AC.includes

#ifndef CXOSIF52_h
#include "CXODIF52.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class KeyRing;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DESKey;

} // namespace database

//## begin module%4C64508B03AC.declarations preserve=no
//## end module%4C64508B03AC.declarations

//## begin module%4C64508B03AC.additionalDeclarations preserve=yes
//## end module%4C64508B03AC.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::WindowsEncryptedFile%4C645027028A.preface preserve=yes
   struct hFileRecord
   {
      int iRecordLength;  //including header if present
      bool bEncrypted;
   };
//## end database::WindowsEncryptedFile%4C645027028A.preface

//## Class: WindowsEncryptedFile%4C645027028A
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4C6558B70358;DESKey { -> F}
//## Uses: <unnamed>%4C6558BA03B7;IF::Trace { -> F}
//## Uses: <unnamed>%4C6558F00027;reusable::KeyRing { -> F}

class DllExport WindowsEncryptedFile : public IF::WindowsFile  //## Inherits: <unnamed>%4C64505F039C
{
  //## begin database::WindowsEncryptedFile%4C645027028A.initialDeclarations preserve=yes
  //## end database::WindowsEncryptedFile%4C645027028A.initialDeclarations

  public:
    //## Constructors (generated)
      WindowsEncryptedFile();

    //## Constructors (specified)
      //## Operation: WindowsEncryptedFile%4C655FA80025
      WindowsEncryptedFile (const char* pszName, const char* pszMember);

      //## Operation: WindowsEncryptedFile%4C655FAC027A
      WindowsEncryptedFile (const char* pszName);

    //## Destructor (generated)
      virtual ~WindowsEncryptedFile();


    //## Other Operations (specified)
      //## Operation: open%597206E50098
      virtual bool open (enum OpenType nOpenType = CX_OPEN_INPUT);

      //## Operation: read%4C6452100387
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool* pbReadError = NULL);

      //## Operation: setKey%4C6453540256
      bool setKey (const string& strCheckDigits);

      //## Operation: write%4C64521E0270
      virtual bool write (char* psBuffer, int lRecordLength);

      //## Operation: writeBinary%597206290185
      bool writeBinary (char* psBuffer, int lRecordLength);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: EncryptLength%4C6452460388
      const int& getEncryptLength () const
      {
        //## begin database::WindowsEncryptedFile::getEncryptLength%4C6452460388.get preserve=no
        return m_iEncryptLength;
        //## end database::WindowsEncryptedFile::getEncryptLength%4C6452460388.get
      }

      void setEncryptLength (const int& value)
      {
        //## begin database::WindowsEncryptedFile::setEncryptLength%4C6452460388.set preserve=no
        m_iEncryptLength = value;
        //## end database::WindowsEncryptedFile::setEncryptLength%4C6452460388.set
      }


      //## Attribute: EncryptOffset%4C6452850165
      const int& getEncryptOffset () const
      {
        //## begin database::WindowsEncryptedFile::getEncryptOffset%4C6452850165.get preserve=no
        return m_iEncryptOffset;
        //## end database::WindowsEncryptedFile::getEncryptOffset%4C6452850165.get
      }

      void setEncryptOffset (const int& value)
      {
        //## begin database::WindowsEncryptedFile::setEncryptOffset%4C6452850165.set preserve=no
        m_iEncryptOffset = value;
        //## end database::WindowsEncryptedFile::setEncryptOffset%4C6452850165.set
      }


      //## Attribute: Endln%59720A7301D9
      void setEndln (const bool& value)
      {
        //## begin database::WindowsEncryptedFile::setEndln%59720A7301D9.set preserve=no
        m_bEndln = value;
        //## end database::WindowsEncryptedFile::setEndln%59720A7301D9.set
      }


      //## Attribute: Method%5972095C028B
      void setMethod (const int& value)
      {
        //## begin database::WindowsEncryptedFile::setMethod%5972095C028B.set preserve=no
        m_iMethod = value;
        //## end database::WindowsEncryptedFile::setMethod%5972095C028B.set
      }


    // Additional Public Declarations
      //## begin database::WindowsEncryptedFile%4C645027028A.public preserve=yes
      //## end database::WindowsEncryptedFile%4C645027028A.public

  protected:
    // Additional Protected Declarations
      //## begin database::WindowsEncryptedFile%4C645027028A.protected preserve=yes
      //## end database::WindowsEncryptedFile%4C645027028A.protected

  private:
    // Additional Private Declarations
      //## begin database::WindowsEncryptedFile%4C645027028A.private preserve=yes
      //## end database::WindowsEncryptedFile%4C645027028A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: EncryptionBuffer%597209BA03A5
      //## begin database::WindowsEncryptedFile::EncryptionBuffer%597209BA03A5.attr preserve=no  public: unsigned char* {U} 0
      unsigned char* m_pEncryptionBuffer;
      //## end database::WindowsEncryptedFile::EncryptionBuffer%597209BA03A5.attr

      //## begin database::WindowsEncryptedFile::EncryptLength%4C6452460388.attr preserve=no  public: int {U} 0
      int m_iEncryptLength;
      //## end database::WindowsEncryptedFile::EncryptLength%4C6452460388.attr

      //## begin database::WindowsEncryptedFile::EncryptOffset%4C6452850165.attr preserve=no  public: int {U} 0
      int m_iEncryptOffset;
      //## end database::WindowsEncryptedFile::EncryptOffset%4C6452850165.attr

      //## begin database::WindowsEncryptedFile::Endln%59720A7301D9.attr preserve=no  public: bool {U} true
      bool m_bEndln;
      //## end database::WindowsEncryptedFile::Endln%59720A7301D9.attr

      //## Attribute: Key%4C64529400C8
      //## begin database::WindowsEncryptedFile::Key%4C64529400C8.attr preserve=no  public: Key* {U} 0
      Key* m_pKey;
      //## end database::WindowsEncryptedFile::Key%4C64529400C8.attr

      //## begin database::WindowsEncryptedFile::Method%5972095C028B.attr preserve=no  public: int {U} 2
      int m_iMethod;
      //## end database::WindowsEncryptedFile::Method%5972095C028B.attr

    // Additional Implementation Declarations
      //## begin database::WindowsEncryptedFile%4C645027028A.implementation preserve=yes
      //## end database::WindowsEncryptedFile%4C645027028A.implementation

};

//## begin database::WindowsEncryptedFile%4C645027028A.postscript preserve=yes
//## end database::WindowsEncryptedFile%4C645027028A.postscript

} // namespace database

//## begin module%4C64508B03AC.epilog preserve=yes
//## end module%4C64508B03AC.epilog


#endif
