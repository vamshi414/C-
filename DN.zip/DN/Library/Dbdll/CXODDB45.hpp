//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5360F1C802A4.cm preserve=no
//	$Date:   Jun 27 2014 08:55:46  $ $Author:   e1009839  $ $Revision:   1.0  $
//## end module%5360F1C802A4.cm

//## begin module%5360F1C802A4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5360F1C802A4.cp

//## Module: CXOSDB45%5360F1C802A4; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5A.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB45.hpp

#ifndef CXOSDB45_h
#define CXOSDB45_h 1

//## begin module%5360F1C802A4.additionalIncludes preserve=no
//## end module%5360F1C802A4.additionalIncludes

//## begin module%5360F1C802A4.includes preserve=yes
//## end module%5360F1C802A4.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

namespace timer {
class Date;
class Clock;
class MidnightAlarm;
} // namespace timer

namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%5360F1C802A4.declarations preserve=no
//## end module%5360F1C802A4.declarations

//## begin module%5360F1C802A4.additionalDeclarations preserve=yes
//## end module%5360F1C802A4.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::TaskLife%5360F125024F.preface preserve=yes
//## end database::TaskLife%5360F125024F.preface

//## Class: TaskLife%5360F125024F
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5361064B03D5;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%5361064F0187;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%53610652035C;IF::Extract { -> F}
//## Uses: <unnamed>%5361065700D7;timer::Clock { -> F}
//## Uses: <unnamed>%5361065B035A;timer::Date { -> F}
//## Uses: <unnamed>%5361067C0046;reusable::Query { -> F}
//## Uses: <unnamed>%5361069C0032;reusable::Statement { -> F}
//## Uses: <unnamed>%536106D002F9;reusable::Table { -> F}
//## Uses: <unnamed>%536106EA0022;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%53610F71021E;Database { -> F}
//## Uses: <unnamed>%53610F8702CA;DatabaseFactory { -> F}

class DllExport TaskLife : public reusable::Observer  //## Inherits: <unnamed>%536108840048
{
  //## begin database::TaskLife%5360F125024F.initialDeclarations preserve=yes
  //## end database::TaskLife%5360F125024F.initialDeclarations

  public:
    //## Constructors (generated)
      TaskLife();

    //## Constructors (specified)
      //## Operation: TaskLife%53A93F870167
      TaskLife (const string &strIMAGEID, const string &strTASKID);

    //## Destructor (generated)
      virtual ~TaskLife();


    //## Other Operations (specified)
      //## Operation: update%5360F8D502B4
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin database::TaskLife%5360F125024F.public preserve=yes
      //## end database::TaskLife%5360F125024F.public

  protected:
    // Additional Protected Declarations
      //## begin database::TaskLife%5360F125024F.protected preserve=yes
      //## end database::TaskLife%5360F125024F.protected

  private:
    // Additional Private Declarations
      //## begin database::TaskLife%5360F125024F.private preserve=yes
      //## end database::TaskLife%5360F125024F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: IMAGEID%536104EB0171
      //## begin database::TaskLife::IMAGEID%536104EB0171.attr preserve=no  private: string {U} 
      string m_strIMAGEID;
      //## end database::TaskLife::IMAGEID%536104EB0171.attr

      //## Attribute: MaxDays%536102A603DA
      //## begin database::TaskLife::MaxDays%536102A603DA.attr preserve=no  private: int {U} 180
      int m_iMaxDays;
      //## end database::TaskLife::MaxDays%536102A603DA.attr

      //## Attribute: START_TIME%5399B4A300AD
      //## begin database::TaskLife::START_TIME%5399B4A300AD.attr preserve=no  private: string {U} 
      string m_strSTART_TIME;
      //## end database::TaskLife::START_TIME%5399B4A300AD.attr

      //## Attribute: TASKID%536105050234
      //## begin database::TaskLife::TASKID%536105050234.attr preserve=no  private: string {U} 
      string m_strTASKID;
      //## end database::TaskLife::TASKID%536105050234.attr

    // Additional Implementation Declarations
      //## begin database::TaskLife%5360F125024F.implementation preserve=yes
      //string m_strStartTime;
      //## end database::TaskLife%5360F125024F.implementation
};

//## begin database::TaskLife%5360F125024F.postscript preserve=yes
//## end database::TaskLife%5360F125024F.postscript

} // namespace database

//## begin module%5360F1C802A4.epilog preserve=yes
//## end module%5360F1C802A4.epilog


#endif
