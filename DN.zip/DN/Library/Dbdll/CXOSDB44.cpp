//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%51C85130012B.cm preserve=no
//	$Date:   Jul 29 2021 07:59:42  $ $Author:   e5632565  $ $Revision:   1.5  $
//## end module%51C85130012B.cm

//## begin module%51C85130012B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%51C85130012B.cp

//## Module: CXOSDB44%51C85130012B; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.4B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB44.cpp

//## begin module%51C85130012B.additionalIncludes preserve=no
//## end module%51C85130012B.additionalIncludes

//## begin module%51C85130012B.includes preserve=yes
//## end module%51C85130012B.includes

#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDB44_h
#include "CXODDB44.hpp"
#endif


//## begin module%51C85130012B.declarations preserve=no
//## end module%51C85130012B.declarations

//## begin module%51C85130012B.additionalDeclarations preserve=yes
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
//## end module%51C85130012B.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::AuditEvent 

//## begin database::AuditEvent::Instance%51C855F20222.attr preserve=no  private: static database::AuditEvent* {U} 0
database::AuditEvent* AuditEvent::m_pInstance = 0;
//## end database::AuditEvent::Instance%51C855F20222.attr

AuditEvent::AuditEvent()
  //## begin AuditEvent::AuditEvent%51C853240081_const.hasinit preserve=no
      : m_bConfigured(true)
  //## end AuditEvent::AuditEvent%51C853240081_const.hasinit
  //## begin AuditEvent::AuditEvent%51C853240081_const.initialization preserve=yes
  //## end AuditEvent::AuditEvent%51C853240081_const.initialization
{
  //## begin database::AuditEvent::AuditEvent%51C853240081_const.body preserve=yes
   m_pInstance = this;

  //## end database::AuditEvent::AuditEvent%51C853240081_const.body
}


AuditEvent::~AuditEvent()
{
  //## begin database::AuditEvent::~AuditEvent%51C853240081_dest.body preserve=yes
   m_pInstance = 0;
  //## end database::AuditEvent::~AuditEvent%51C853240081_dest.body
}



//## Other Operations (implementation)
void AuditEvent::capture (const IF::Message& hMessage, const string& strCommand)
{
  //## begin database::AuditEvent::capture%51E803BD02CD.body preserve=yes
   if(!m_pInstance)
      return;
   if(!m_pInstance->m_bConfigured)
      return;
   m_pInstance->captureEvent(hMessage,strCommand);
  //## end database::AuditEvent::capture%51E803BD02CD.body
}

void AuditEvent::capture (const string& strTableName, const string& strSearchCondition, const string& strPredicates)
{
  //## begin database::AuditEvent::capture%51E41D4702D3.body preserve=yes
   if(!m_pInstance)
      return;
   if(!m_pInstance->m_bConfigured)
      return;
   m_pInstance->captureEvent(strTableName,strSearchCondition,strPredicates);
  //## end database::AuditEvent::capture%51E41D4702D3.body
}

void AuditEvent::capture (const IF::Message& hMessage)
{
  //## begin database::AuditEvent::capture%51E41F430106.body preserve=yes
   if(!m_pInstance)
      return;
   if(!m_pInstance->m_bConfigured)
      return;
   m_pInstance->captureEvent(hMessage);
  //## end database::AuditEvent::capture%51E41F430106.body
}

void AuditEvent::capture (reusable::Table& hTable, short sEventType)
{
  //## begin database::AuditEvent::capture%51CA09CC016D.body preserve=yes
   if(!m_pInstance)
      return;
   if(!m_pInstance->m_bConfigured)
      return;
   m_pInstance->captureEvent(hTable,sEventType);
  //## end database::AuditEvent::capture%51CA09CC016D.body
}

void AuditEvent::capture (const string& strUSER_ID, short sEVENT_TYPE, short sRETURN_CODE, const string& strRESOURCE_NAME, const string& strRESOURCE_KEY)
{
  //## begin database::AuditEvent::capture%524C477001EC.body preserve=yes
   if(!m_pInstance)
      return;
   if(!m_pInstance->m_bConfigured)
      return;
   m_pInstance->captureEvent(strUSER_ID,sEVENT_TYPE,sRETURN_CODE,strRESOURCE_NAME,strRESOURCE_KEY);
  //## end database::AuditEvent::capture%524C477001EC.body
}

void AuditEvent::captureEvent (const IF::Message& hMessage, const string& strCommand)
{
  //## begin database::AuditEvent::captureEvent%51E803BD02D4.body preserve=yes
  //## end database::AuditEvent::captureEvent%51E803BD02D4.body
}

void AuditEvent::captureEvent (const string& strTableName, const string& strSearchCondition, const string& strPredicates)
{
  //## begin database::AuditEvent::captureEvent%51E41D980038.body preserve=yes
  //## end database::AuditEvent::captureEvent%51E41D980038.body
}

void AuditEvent::captureEvent (const IF::Message& hMessage)
{
  //## begin database::AuditEvent::captureEvent%51E41F6E02E4.body preserve=yes
  //## end database::AuditEvent::captureEvent%51E41F6E02E4.body
}

void AuditEvent::captureEvent (reusable::Table& hTable, short iEventType)
{
  //## begin database::AuditEvent::captureEvent%51C86F2101CD.body preserve=yes
  //## end database::AuditEvent::captureEvent%51C86F2101CD.body
}

void AuditEvent::captureEvent (const string& strUSER_ID, short sEVENT_TYPE, short sRETURN_CODE, const string& strRESOURCE_NAME, const string& strRESOURCE_KEY)
{
  //## begin database::AuditEvent::captureEvent%524C481400D7.body preserve=yes
  //## end database::AuditEvent::captureEvent%524C481400D7.body
}

bool AuditEvent::commit (bool bCommit)
{
  //## begin database::AuditEvent::commit%51CA074C004C.body preserve=yes
   if(!m_pInstance)
      return true;
   if(!m_pInstance->m_bConfigured)
      return true;
   return m_pInstance->commitEvent(bCommit);
  //## end database::AuditEvent::commit%51CA074C004C.body
}

bool AuditEvent::commitEvent (bool bCommit)
{
  //## begin database::AuditEvent::commitEvent%51C855DA0277.body preserve=yes
   return false;
  //## end database::AuditEvent::commitEvent%51C855DA0277.body
}

bool AuditEvent::load ()
{
  //## begin database::AuditEvent::load%51C855DA0257.body preserve=yes
   return true;
  //## end database::AuditEvent::load%51C855DA0257.body
}

// Additional Declarations
  //## begin database::AuditEvent%51C853240081.declarations preserve=yes
  //## end database::AuditEvent%51C853240081.declarations

} // namespace database

//## begin module%51C85130012B.epilog preserve=yes
//## end module%51C85130012B.epilog
