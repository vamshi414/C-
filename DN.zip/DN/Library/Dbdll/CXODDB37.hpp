//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4AF064AB01C3.cm preserve=no
//	$Date:   Apr 23 2015 13:54:54  $ $Author:   e1009652  $ $Revision:   1.6  $
//## end module%4AF064AB01C3.cm

//## begin module%4AF064AB01C3.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4AF064AB01C3.cp

//## Module: CXOSDB37%4AF064AB01C3; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB37.hpp

#ifndef CXOSDB37_h
#define CXOSDB37_h 1

//## begin module%4AF064AB01C3.additionalIncludes preserve=no
//## end module%4AF064AB01C3.additionalIncludes

//## begin module%4AF064AB01C3.includes preserve=yes
struct encryptionHeader
{
   char  eyeCatcher[6];     // >DSS*<
   short version;           // value 0001
   char  checkDigits[4];    // check digits for encryption key
   short encryptionMethod;  // value 0001 3DES
   short recordLength;      // original unencrypted record length
   short compressionMethod; // value 0000
   short compressionLength; // value 0000
};
struct encryptionHeader2
{
   char  eyeCatcher[6];     // >DSS*<
   short version;           // value 0002
   char  checkDigits[4];    // check digits for encryption key
   short encryptionMethod;  // value 0001 3DES
   short recordLength;      // original unencrypted record length
   short compressionMethod; // value 0000
   short compressionLength; // value 0000
   short sourcePlatform;    // 0 = FTP Exit, 1 = CMS, 2 = HP Connex,
                            // 3 = IBM Connex, 4 = DataDistributor, 5 = DN              
   short encryptedFieldOffset; //offset 0 based
   short encryptedFieldLength; //must be multiple of 8
};
//## end module%4AF064AB01C3.includes

#ifndef CXOSRU41_h
#include "CXODRU41.hpp"
#endif

//## Modelname: Connex Library::SecurityWrapper_CAT (SWDLL)%4A09A922013D
namespace securitywrapper {
class SecurityWrapper;

} // namespace securitywrapper

//## begin module%4AF064AB01C3.declarations preserve=no
//## end module%4AF064AB01C3.declarations

//## begin module%4AF064AB01C3.additionalDeclarations preserve=yes
//## end module%4AF064AB01C3.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::DESKey%4AF064710131.preface preserve=yes
//## end database::DESKey%4AF064710131.preface

//## Class: DESKey%4AF064710131
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4AF0647F00E6;securitywrapper::SecurityWrapper { -> F}

class DllExport DESKey : public reusable::Key  //## Inherits: <unnamed>%4AF0647C00B7
{
  //## begin database::DESKey%4AF064710131.initialDeclarations preserve=yes
  //## end database::DESKey%4AF064710131.initialDeclarations

  public:
    //## Constructors (generated)
      DESKey();

      DESKey(const DESKey &right);

    //## Constructors (specified)
      //## Operation: DESKey%4AF1A2280039
      DESKey (const string& strKey);

    //## Destructor (generated)
      virtual ~DESKey();

    //## Assignment Operation (generated)
      DESKey & operator=(const DESKey &right);


    //## Other Operations (specified)
      //## Operation: decrypt%4AF065C70036
      virtual bool decrypt (string& strText);

      //## Operation: encrypt%4AF065C7004A
      virtual bool encrypt (string& strText);

      //## Operation: setKey%4AF43F530158
      virtual void setKey (const string& strKey);

      const int& getReasonCode () const
      {
        //## begin database::DESKey::getReasonCode%4C812BAF01B7.get preserve=no
        return m_iReasonCode;
        //## end database::DESKey::getReasonCode%4C812BAF01B7.get
      }


      //## Attribute: ReturnCode%4C812BEC024E
      const int& getReturnCode () const
      {
        //## begin database::DESKey::getReturnCode%4C812BEC024E.get preserve=no
        return m_iReturnCode;
        //## end database::DESKey::getReturnCode%4C812BEC024E.get
      }


    // Additional Public Declarations
      //## begin database::DESKey%4AF064710131.public preserve=yes
      virtual bool validate();
      //## end database::DESKey%4AF064710131.public

  protected:

    //## Other Operations (specified)
      //## Operation: crypt%4AF07E32029A
      bool crypt (string& strText, int iLength, int enc);

    // Data Members for Class Attributes

      //## begin database::DESKey::CheckDigits%4AF44078018B.attr preserve=no  public: string {U} 
      //## end database::DESKey::CheckDigits%4AF44078018B.attr

      //## begin database::DESKey::ReasonCode%4C812BAF01B7.attr preserve=no  public: int {U} 0
      int m_iReasonCode;
      //## end database::DESKey::ReasonCode%4C812BAF01B7.attr

      //## begin database::DESKey::ReturnCode%4C812BEC024E.attr preserve=no  public: int {U} 0
      int m_iReturnCode;
      //## end database::DESKey::ReturnCode%4C812BEC024E.attr

    // Additional Protected Declarations
      //## begin database::DESKey%4AF064710131.protected preserve=yes
      //## end database::DESKey%4AF064710131.protected

  private:
    // Additional Private Declarations
      //## begin database::DESKey%4AF064710131.private preserve=yes
      //## end database::DESKey%4AF064710131.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::DESKey%4AF064710131.implementation preserve=yes
      //## end database::DESKey%4AF064710131.implementation

};

//## begin database::DESKey%4AF064710131.postscript preserve=yes
//## end database::DESKey%4AF064710131.postscript

} // namespace database

//## begin module%4AF064AB01C3.epilog preserve=yes
//## end module%4AF064AB01C3.epilog


#endif
