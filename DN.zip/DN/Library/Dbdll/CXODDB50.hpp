//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%545C216C01C7.cm preserve=no
//	$Date:   Aug 22 2019 15:07:30  $ $Author:   e1009652  $ $Revision:   1.2  $
//## end module%545C216C01C7.cm

//## begin module%545C216C01C7.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%545C216C01C7.cp

//## Module: CXOSDB50%545C216C01C7; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.0A.R005\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB50.hpp

#ifndef CXOSDB50_h
#define CXOSDB50_h 1

//## begin module%545C216C01C7.additionalIncludes preserve=no
//## end module%545C216C01C7.additionalIncludes

//## begin module%545C216C01C7.includes preserve=yes
#include <set>
//## end module%545C216C01C7.includes

#ifndef CXOSDB43_h
#include "CXODDB43.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
class DataModel;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class DatabaseFactory;

} // namespace database

//## begin module%545C216C01C7.declarations preserve=no
//## end module%545C216C01C7.declarations

//## begin module%545C216C01C7.additionalDeclarations preserve=yes
//## end module%545C216C01C7.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::DataModel%545C1EA00044.preface preserve=yes
//## end database::DataModel%545C1EA00044.preface

//## Class: DataModel%545C1EA00044
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%545C1FA40207;reusable::DataModel { -> F}
//## Uses: <unnamed>%545C210702CD;DatabaseFactory { -> F}
//## Uses: <unnamed>%545C210A03D5;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%545C210D02D5;reusable::Query { -> F}
//## Uses: <unnamed>%545E953300A9;reusable::Statement { -> F}
//## Uses: <unnamed>%545E954E01F9;reusable::Table { -> F}
//## Uses: <unnamed>%545FB16E0130;GlobalContext { -> F}
//## Uses: <unnamed>%545FB171011F;timer::Date { -> F}
//## Uses: <unnamed>%54634F310352;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%5D5EB0530050;timer::Clock { -> F}

class DllExport DataModel : public Cache  //## Inherits: <unnamed>%545C1EC100D9
{
  //## begin database::DataModel%545C1EA00044.initialDeclarations preserve=yes
  //## end database::DataModel%545C1EA00044.initialDeclarations

  public:
    //## Constructors (generated)
      DataModel();

    //## Destructor (generated)
      virtual ~DataModel();


    //## Other Operations (specified)
      //## Operation: insert%545E94F0037A
      bool insert ();

      //## Operation: instance%545C22D400A8
      static DataModel* instance ();

      //## Operation: load%545C1EDC0178
      virtual bool load ();

      //## Operation: refresh%545FB9F50122
      virtual bool refresh ();

      //## Operation: update%545C20D1039C
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin database::DataModel%545C1EA00044.public preserve=yes
      //## end database::DataModel%545C1EA00044.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: COLUMN_NAME%545C2045016A
      //## begin database::DataModel::COLUMN_NAME%545C2045016A.attr preserve=no  protected: string {VA} 
      string m_strCOLUMN_NAME;
      //## end database::DataModel::COLUMN_NAME%545C2045016A.attr

      //## Attribute: COLUMN_STATUS%545C20460165
      //## begin database::DataModel::COLUMN_STATUS%545C20460165.attr preserve=no  protected: string {VA} 
      string m_strCOLUMN_STATUS;
      //## end database::DataModel::COLUMN_STATUS%545C20460165.attr

      //## Attribute: DATA_TYPE%545C204503B6
      //## begin database::DataModel::DATA_TYPE%545C204503B6.attr preserve=no  protected: string {VA} 
      string m_strDATA_TYPE;
      //## end database::DataModel::DATA_TYPE%545C204503B6.attr

      //## Attribute: Table%5BE06DE20158
      //## begin database::DataModel::Table%5BE06DE20158.attr preserve=no  protected: set<string, less<string> > {VA} 
      set<string, less<string> > m_hTable;
      //## end database::DataModel::Table%5BE06DE20158.attr

      //## Attribute: TABLE_NAME%545C20230242
      //## begin database::DataModel::TABLE_NAME%545C20230242.attr preserve=no  protected: string {VA} 
      string m_strTABLE_NAME;
      //## end database::DataModel::TABLE_NAME%545C20230242.attr

      //## Attribute: YYYYMM%5460A3B202F7
      //## begin database::DataModel::YYYYMM%5460A3B202F7.attr preserve=no  protected: string {VA} 
      string m_strYYYYMM;
      //## end database::DataModel::YYYYMM%5460A3B202F7.attr

    // Additional Protected Declarations
      //## begin database::DataModel%545C1EA00044.protected preserve=yes
      //## end database::DataModel%545C1EA00044.protected

  private:
    // Additional Private Declarations
      //## begin database::DataModel%545C1EA00044.private preserve=yes
      //## end database::DataModel%545C1EA00044.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%545C22EF01FF
      //## begin database::DataModel::Instance%545C22EF01FF.attr preserve=no  private: static DataModel* {V} 0
      static DataModel* m_pInstance;
      //## end database::DataModel::Instance%545C22EF01FF.attr

    // Additional Implementation Declarations
      //## begin database::DataModel%545C1EA00044.implementation preserve=yes
      //## end database::DataModel%545C1EA00044.implementation

};

//## begin database::DataModel%545C1EA00044.postscript preserve=yes
//## end database::DataModel%545C1EA00044.postscript

} // namespace database

//## begin module%545C216C01C7.epilog preserve=yes
//## end module%545C216C01C7.epilog


#endif
