//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%53D1783F0359.cm preserve=no
//  $Date:   Sep 17 2014 08:42:24  $ $Author:   e1009510  $
//  $Revision:   1.0  $
//## end module%53D1783F0359.cm

//## begin module%53D1783F0359.cp preserve=no
//  Copyright (c) 1997 - 2012
//  FIS
//## end module%53D1783F0359.cp

//## Module: CXOSDB46%53D1783F0359; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//  .
//## Source file: C:\bV02.4B.R007\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB46.hpp

#ifndef CXOSDB46_h
#define CXOSDB46_h 1

//## begin module%53D1783F0359.additionalIncludes preserve=no
//## end module%53D1783F0359.additionalIncludes

//## begin module%53D1783F0359.includes preserve=yes
//## end module%53D1783F0359.includes

#ifndef CXOSDB43_h
#include "CXODDB43.hpp"
#endif
#ifndef CXOSDB31_h
#include "CXODDB31.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;

} // namespace database

//## begin module%53D1783F0359.declarations preserve=no
//## end module%53D1783F0359.declarations

//## begin module%53D1783F0359.additionalDeclarations preserve=yes
//## end module%53D1783F0359.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::EMSBusinessDate%53D1780101BD.preface preserve=yes
//## end database::EMSBusinessDate%53D1780101BD.preface

//## Class: EMSBusinessDate%53D1780101BD
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%53D291D502BE;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%53D292140381;Database { -> F}
//## Uses: <unnamed>%53D292370149;DatabaseFactory { -> F}
//## Uses: <unnamed>%53D292A90255;reusable::Query { -> F}
//## Uses: <unnamed>%53D292C80135;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%53D292EE0080;IF::Extract { -> F}
//## Uses: <unnamed>%53D2931703B0;timer::Date { -> F}

class DllExport EMSBusinessDate : public Cache  //## Inherits: <unnamed>%53D1798703AE
{
  //## begin database::EMSBusinessDate%53D1780101BD.initialDeclarations preserve=yes
  //## end database::EMSBusinessDate%53D1780101BD.initialDeclarations

  public:
    //## Constructors (generated)
      EMSBusinessDate();

    //## Destructor (generated)
      virtual ~EMSBusinessDate();


    //## Other Operations (specified)
      //## Operation: calculateBusinessDate%53D297C5031E
      void calculateBusinessDate (string& strEvent, timer::Date& hBusinessDate, int iNumDays);

      //## Operation: getBusinessCalendar%53D2982E0364
      string getBusinessCalendar (const string& strCUR_RECON_NET, const string& strCUR_TRAN, const string& strUSER_ROLE, const string& strCUST_ID, const string& strEMS_CALENDAR_DFLT);

      //## Operation: instance%53D298A50058
      static EMSBusinessDate* instance ();

      //## Operation: load%53D185950027
      virtual bool load ();

      //## Operation: update%53D298960357
      //    Callback function that is invoked by a Subject when its
      //    state changes.
      virtual void update (Subject* pSubject    // Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin database::EMSBusinessDate%53D1780101BD.public preserve=yes
        Calendar* getCalendar()
        {
           return m_pCalendar;
        }
      //## end database::EMSBusinessDate%53D1780101BD.public

  protected:
    // Additional Protected Declarations
      //## begin database::EMSBusinessDate%53D1780101BD.protected preserve=yes
      //## end database::EMSBusinessDate%53D1780101BD.protected

  private:
    // Additional Private Declarations
      //## begin database::EMSBusinessDate%53D1780101BD.private preserve=yes
      //## end database::EMSBusinessDate%53D1780101BD.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: EVNTID%53D2944B00B8
      //## begin database::EMSBusinessDate::EVNTID%53D2944B00B8.attr preserve=no  private: string {U} 
      string m_strEVNTID;
      //## end database::EMSBusinessDate::EVNTID%53D2944B00B8.attr

      //## Attribute: Instance%53D298E700A2
      //## begin database::EMSBusinessDate::Instance%53D298E700A2.attr preserve=no  private: static EMSBusinessDate* {U} 
      static EMSBusinessDate* m_pInstance;
      //## end database::EMSBusinessDate::Instance%53D298E700A2.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%53D293C400FF
      //## Role: EMSBusinessDate::<m_pCalendar>%53D293C5004F
      //## begin database::EMSBusinessDate::<m_pCalendar>%53D293C5004F.role preserve=no  public: database::Calendar { -> RHN}
      Calendar *m_pCalendar;
      //## end database::EMSBusinessDate::<m_pCalendar>%53D293C5004F.role

    // Additional Implementation Declarations
      //## begin database::EMSBusinessDate%53D1780101BD.implementation preserve=yes
      //## end database::EMSBusinessDate%53D1780101BD.implementation

};

//## begin database::EMSBusinessDate%53D1780101BD.postscript preserve=yes
//## end database::EMSBusinessDate%53D1780101BD.postscript

} // namespace database

//## begin module%53D1783F0359.epilog preserve=yes
//## end module%53D1783F0359.epilog


#endif
