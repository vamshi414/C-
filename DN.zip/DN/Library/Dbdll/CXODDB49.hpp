//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%54521EDB0306.cm preserve=no
//	$Date:   May 11 2017 16:33:38  $ $Author:   e1009839  $
//	$Revision:   1.3  $
//## end module%54521EDB0306.cm

//## begin module%54521EDB0306.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%54521EDB0306.cp

//## Module: CXOSDB49%54521EDB0306; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB49.hpp

#ifndef CXOSDB49_h
#define CXOSDB49_h 1

//## begin module%54521EDB0306.additionalIncludes preserve=no
//## end module%54521EDB0306.additionalIncludes

//## begin module%54521EDB0306.includes preserve=yes
//## end module%54521EDB0306.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%54521EDB0306.declarations preserve=no
//## end module%54521EDB0306.declarations

//## begin module%54521EDB0306.additionalDeclarations preserve=yes
//## end module%54521EDB0306.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::UniquenessKey%54521D6803A1.preface preserve=yes
//## end database::UniquenessKey%54521D6803A1.preface

//## Class: UniquenessKey%54521D6803A1
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport UniquenessKey : public reusable::Object  //## Inherits: <unnamed>%545222030231
{
  //## begin database::UniquenessKey%54521D6803A1.initialDeclarations preserve=yes
  //## end database::UniquenessKey%54521D6803A1.initialDeclarations

  public:
    //## Constructors (generated)
      UniquenessKey();

    //## Destructor (generated)
      virtual ~UniquenessKey();


    //## Other Operations (specified)
      //## Operation: get%5478E7AE0198
      static const char* get ();

      //## Operation: getHash%5478E9F80218
      static unsigned short getHash ();

      //## Operation: hash%5478E76701B5
      static void hash (const char* sColumn, int iLength);

      //## Operation: oatHash%5728F0E300F4
      static void oatHash (const unsigned char* sColumn, int iLength);

      //## Operation: getHundredths%572901A30120
      static short getHundredths ();

    // Additional Public Declarations
      //## begin database::UniquenessKey%54521D6803A1.public preserve=yes
      static short getSeconds ();
      static int getHHMMSSnn ();
      //## end database::UniquenessKey%54521D6803A1.public

  protected:
    // Additional Protected Declarations
      //## begin database::UniquenessKey%54521D6803A1.protected preserve=yes
      //## end database::UniquenessKey%54521D6803A1.protected

  private:
    // Additional Private Declarations
      //## begin database::UniquenessKey%54521D6803A1.private preserve=yes
      //## end database::UniquenessKey%54521D6803A1.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Hash%5478E73A03CB
      //## begin database::UniquenessKey::Hash%5478E73A03CB.attr preserve=no  private: static unsigned short {V} 0
      static unsigned short m_usiHash;
      //## end database::UniquenessKey::Hash%5478E73A03CB.attr

      //## Attribute: Oat%5728F2C90073
      //## begin database::UniquenessKey::Oat%5728F2C90073.attr preserve=no  private: static bool {V} false
      static bool m_bOat;
      //## end database::UniquenessKey::Oat%5728F2C90073.attr

      //## Attribute: OatHash%5728F4060080
      //## begin database::UniquenessKey::OatHash%5728F4060080.attr preserve=no  private: static unsigned int {V} 0
      static unsigned int m_iOatHash;
      //## end database::UniquenessKey::OatHash%5728F4060080.attr

      //## Attribute: UNIQUENESS_KEY%5452229A017F
      //## begin database::UniquenessKey::UNIQUENESS_KEY%5452229A017F.attr preserve=no  private: static unsigned short {V} 0
      static unsigned short m_siUNIQUENESS_KEY;
      //## end database::UniquenessKey::UNIQUENESS_KEY%5452229A017F.attr

      //## Attribute: szUNIQUENESS_KEY%5478ECC9032E
      //## begin database::UniquenessKey::szUNIQUENESS_KEY%5478ECC9032E.attr preserve=no  private: static char[9] {U} 
      static char m_szUNIQUENESS_KEY[9];
      //## end database::UniquenessKey::szUNIQUENESS_KEY%5478ECC9032E.attr

    // Additional Implementation Declarations
      //## begin database::UniquenessKey%54521D6803A1.implementation preserve=yes
      //## end database::UniquenessKey%54521D6803A1.implementation

};

//## begin database::UniquenessKey%54521D6803A1.postscript preserve=yes
//## end database::UniquenessKey%54521D6803A1.postscript

} // namespace database

//## begin module%54521EDB0306.epilog preserve=yes
//## end module%54521EDB0306.epilog


#endif
