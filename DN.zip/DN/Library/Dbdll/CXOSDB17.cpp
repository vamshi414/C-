//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%38D26698035E.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%38D26698035E.cm

//## begin module%38D26698035E.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%38D26698035E.cp

//## Module: CXOSDB17%38D26698035E; Package body
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXOSDB17.cpp

//## begin module%38D26698035E.additionalIncludes preserve=no
//## end module%38D26698035E.additionalIncludes

//## begin module%38D26698035E.includes preserve=yes
// $Date:   Jun 05 2014 02:50:22  $ $Author:   e1014059  $ $Revision:   1.5  $
//## end module%38D26698035E.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB17_h
#include "CXODDB17.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif


//## begin module%38D26698035E.declarations preserve=no
//## end module%38D26698035E.declarations

//## begin module%38D26698035E.additionalDeclarations preserve=yes
//## end module%38D26698035E.additionalDeclarations


//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::DisputeProcessor 



DisputeProcessor::DisputeProcessor()
  //## begin DisputeProcessor::DisputeProcessor%38D264AF033F_const.hasinit preserve=no
  //## end DisputeProcessor::DisputeProcessor%38D264AF033F_const.hasinit
  //## begin DisputeProcessor::DisputeProcessor%38D264AF033F_const.initialization preserve=yes
  //## end DisputeProcessor::DisputeProcessor%38D264AF033F_const.initialization
{
  //## begin database::DisputeProcessor::DisputeProcessor%38D264AF033F_const.body preserve=yes
   Extract::instance()->getSpec("CUSTOMER",m_strCUST_ID);
   Extract::instance()->attach(this);
  //## end database::DisputeProcessor::DisputeProcessor%38D264AF033F_const.body
}


DisputeProcessor::~DisputeProcessor()
{
  //## begin database::DisputeProcessor::~DisputeProcessor%38D264AF033F_dest.body preserve=yes
   m_hEntities.erase(m_hEntities.begin(),m_hEntities.end());
   Extract::instance()->detach(this);
  //## end database::DisputeProcessor::~DisputeProcessor%38D264AF033F_dest.body
}



//## Other Operations (implementation)
bool DisputeProcessor::getDisputeProcessor (const string& strInstitution, const string& strProcessor, const string& strProcGroup, string& strDisputeProcID, int& lSeqNo)
{
  //## begin database::DisputeProcessor::getDisputeProcessor%38D2657603B1.body preserve=yes
   if (getInstitution(strInstitution, strDisputeProcID, lSeqNo) == false)
      return false;
   if (strDisputeProcID.length() == 0)
   {
      if (getProcessor(strProcessor, strDisputeProcID, lSeqNo) == false)
         return false;
      if (strDisputeProcID.length() == 0)
         if ((getProcGroup(strProcGroup, strDisputeProcID, lSeqNo) == false) ||
             (strDisputeProcID.length() == 0))
            return false;
   }
   return true;
  //## end database::DisputeProcessor::getDisputeProcessor%38D2657603B1.body
}

bool DisputeProcessor::getEntity (const string& strEntity, string& strDisputeProcID, int& lSeqNo)
{
  //## begin database::DisputeProcessor::getEntity%38D2844A0095.body preserve=yes
   map<string,pair<string,int>,less<string> >::iterator pEntity;
   pEntity = m_hEntities.find(strEntity);
   if (pEntity != m_hEntities.end())
   {
      strDisputeProcID = (*pEntity).second.first;
      lSeqNo = ++(*pEntity).second.second;
      return true;
   }
   return false;
  //## end database::DisputeProcessor::getEntity%38D2844A0095.body
}

bool DisputeProcessor::getInstitution (const string& strInstitution, string& strDisputeProcID, int& lSeqNo)
{
  //## begin database::DisputeProcessor::getInstitution%38D267E70305.body preserve=yes
   string strKey = "I" + strInstitution;
   if (getEntity(strKey, strDisputeProcID, lSeqNo) == true)
      return true;
   Query hQuery;
   hQuery.setQualifier("QUALIFY", "INSTITUTION");
   hQuery.bind("INSTITUTION","DISPUTE_PROC_ID",Column::STRING,&strDisputeProcID);
   hQuery.setBasicPredicate("INSTITUTION","INST_ID","=",strInstitution.c_str());
   hQuery.setBasicPredicate("INSTITUTION","CUST_ID","=",m_strCUST_ID.c_str());
   hQuery.setBasicPredicate("INSTITUTION","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("INSTITUTION","CC_STATE","IN","('A','I')");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   pair<string,int> hPair(strDisputeProcID,1);
   m_hEntities.insert(map<string,pair<string,int>,less<string> >::value_type(strKey,hPair));
   lSeqNo = 1;
   return true;
  //## end database::DisputeProcessor::getInstitution%38D267E70305.body
}

bool DisputeProcessor::getProcessor (const string& strProcessor, string& strDisputeProcID, int& lSeqNo)
{
  //## begin database::DisputeProcessor::getProcessor%38D268BA038C.body preserve=yes
   string strKey = "P" + strProcessor;
   if (getEntity(strKey, strDisputeProcID, lSeqNo) == true)
      return true;
   Query hQuery;
   hQuery.setQualifier("QUALIFY", "PROCESSOR");
   hQuery.bind("PROCESSOR","DISPUTE_PROC_ID",Column::STRING,&strDisputeProcID);
   hQuery.setBasicPredicate("PROCESSOR","PROC_ID","=",strProcessor.c_str());
   hQuery.setBasicPredicate("PROCESSOR","CUST_ID","=",m_strCUST_ID.c_str());
   hQuery.setBasicPredicate("PROCESSOR","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("PROCESSOR","CC_STATE","=","A");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   pair<string,int> hPair(strDisputeProcID,1);
   m_hEntities.insert(map<string,pair<string,int>,less<string> >::value_type(strKey,hPair));
   lSeqNo = 1;
   return true;
  //## end database::DisputeProcessor::getProcessor%38D268BA038C.body
}

bool DisputeProcessor::getProcGroup (const string& strProcGroup, string& strDisputeProcID, int& lSeqNo)
{
  //## begin database::DisputeProcessor::getProcGroup%38D268C5000D.body preserve=yes
   string strKey = "G" + strProcGroup;
   if (getEntity(strKey, strDisputeProcID, lSeqNo) == true)
      return true;
   Query hQuery;
   hQuery.setQualifier("QUALIFY", "PROCESSOR_GRP");
   hQuery.bind("PROCESSOR_GRP","DISPUTE_PROC_ID",Column::STRING,&strDisputeProcID);
   hQuery.setBasicPredicate("PROCESSOR_GRP","PROC_GRP_ID","=",strProcGroup.c_str());
   hQuery.setBasicPredicate("PROCESSOR_GRP","CUST_ID","=",m_strCUST_ID.c_str());
   hQuery.setBasicPredicate("PROCESSOR_GRP","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("PROCESSOR_GRP","CC_STATE","=","A");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   pair<string,int> hPair(strDisputeProcID,1);
   m_hEntities.insert(map<string,pair<string,int>,less<string> >::value_type(strKey,hPair));
   lSeqNo = 1;
   return true;
  //## end database::DisputeProcessor::getProcGroup%38D268C5000D.body
}

void DisputeProcessor::update (Subject* pSubject)
{
  //## begin database::DisputeProcessor::update%38D696840015.body preserve=yes
   if (pSubject == Extract::instance())
      Extract::instance()->getSpec("CUSTOMER",m_strCUST_ID);
  //## end database::DisputeProcessor::update%38D696840015.body
}

// Additional Declarations
  //## begin database::DisputeProcessor%38D264AF033F.declarations preserve=yes
  //## end database::DisputeProcessor%38D264AF033F.declarations

} // namespace database

//## begin module%38D26698035E.epilog preserve=yes
//## end module%38D26698035E.epilog
