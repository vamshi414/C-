//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39776592030A.cm preserve=no
//	$Date:   Apr 13 2021 14:31:48  $ $Author:   e1033757  $ $Revision:   1.8  $
//## end module%39776592030A.cm

//## begin module%39776592030A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39776592030A.cp

//## Module: CXOSDB30%39776592030A; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Dbdll\CXOSDB30.cpp

//## begin module%39776592030A.additionalIncludes preserve=no
//## end module%39776592030A.additionalIncludes

//## begin module%39776592030A.includes preserve=yes
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#include <time.h>
#include <algorithm>
//## end module%39776592030A.includes

#ifndef CXOSTM11_h
#include "CXODTM11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSDB08_h
#include "CXODDB08.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSDB30_h
#include "CXODDB30.hpp"
#endif


//## begin module%39776592030A.declarations preserve=no
//## end module%39776592030A.declarations

//## begin module%39776592030A.additionalDeclarations preserve=yes
//## end module%39776592030A.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::InsertSequenceNumber 

//## begin database::InsertSequenceNumber::Day%5B6DBE8A01F5.attr preserve=no  private: static int  {U} 0
int  InsertSequenceNumber::m_iDay = 0;
//## end database::InsertSequenceNumber::Day%5B6DBE8A01F5.attr

//## begin database::InsertSequenceNumber::HistoryDate%46034AC90258.attr preserve=no  public: static reusable::string {U} 
reusable::string InsertSequenceNumber::m_strHistoryDate;
//## end database::InsertSequenceNumber::HistoryDate%46034AC90258.attr

//## begin database::InsertSequenceNumber::Hour%5B6DB019012A.attr preserve=no  private: static int  {U} 0
int  InsertSequenceNumber::m_iHour = 0;
//## end database::InsertSequenceNumber::Hour%5B6DB019012A.attr

//## begin database::InsertSequenceNumber::InsertSequenceNumber%4C912D340169.attr preserve=no  private: static int {V} 0
int InsertSequenceNumber::m_iInsertSequenceNumber = 0;
//## end database::InsertSequenceNumber::InsertSequenceNumber%4C912D340169.attr

//## begin database::InsertSequenceNumber::Instance%46078D7901D4.attr preserve=no  private: static database::InsertSequenceNumber* {U} 0
database::InsertSequenceNumber* InsertSequenceNumber::m_pInstance = 0;
//## end database::InsertSequenceNumber::Instance%46078D7901D4.attr

//## begin database::InsertSequenceNumber::JulianDay%5B6DB00F01FA.attr preserve=no  private: static int  {U} 0
int  InsertSequenceNumber::m_iJulianDay = 0;
//## end database::InsertSequenceNumber::JulianDay%5B6DB00F01FA.attr

//## begin database::InsertSequenceNumber::Min%5B6DB021003A.attr preserve=no  private: static int  {U} 0
int  InsertSequenceNumber::m_iMin = 0;
//## end database::InsertSequenceNumber::Min%5B6DB021003A.attr

//## begin database::InsertSequenceNumber::Month%5B6DBE8802DE.attr preserve=no  private: static int  {U} 0
int  InsertSequenceNumber::m_iMonth = 0;
//## end database::InsertSequenceNumber::Month%5B6DBE8802DE.attr

//## begin database::InsertSequenceNumber::Year%5B6DAFED017A.attr preserve=no  private: static int  {U} 0
int  InsertSequenceNumber::m_iYear = 0;
//## end database::InsertSequenceNumber::Year%5B6DAFED017A.attr

InsertSequenceNumber::InsertSequenceNumber()
  //## begin InsertSequenceNumber::InsertSequenceNumber%397765380057_const.hasinit preserve=no
      : m_iHistoryDays(14)
  //## end InsertSequenceNumber::InsertSequenceNumber%397765380057_const.hasinit
  //## begin InsertSequenceNumber::InsertSequenceNumber%397765380057_const.initialization preserve=yes
  //## end InsertSequenceNumber::InsertSequenceNumber%397765380057_const.initialization
{
  //## begin database::InsertSequenceNumber::InsertSequenceNumber%397765380057_const.body preserve=yes
   memcpy(m_sID,"TM07",4);
   if (Extract::instance()->getCustomCode() == "MPS")
      m_iHistoryDays = 365;
   Extract::instance()->getLong("DUSER   ","HISTORY=",&m_iHistoryDays);
   if (m_iHistoryDays < 7)
      m_iHistoryDays = 7;
   MidnightAlarm::instance()->attach(this);
   MinuteTimer::instance()->attach(this);
   update(MinuteTimer::instance());
   update(MidnightAlarm::instance());
  //## end database::InsertSequenceNumber::InsertSequenceNumber%397765380057_const.body
}


InsertSequenceNumber::~InsertSequenceNumber()
{
  //## begin database::InsertSequenceNumber::~InsertSequenceNumber%397765380057_dest.body preserve=yes
   MidnightAlarm::instance()->detach(this);
   MinuteTimer::instance()->detach(this);
  //## end database::InsertSequenceNumber::~InsertSequenceNumber%397765380057_dest.body
}



//## Other Operations (implementation)
int InsertSequenceNumber::getYYYDDDHHMM (const char* pszTSTAMP_TRANS)
{
  //## begin database::InsertSequenceNumber::getYYYDDDHHMM%39776655026A.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new InsertSequenceNumber();
   if (pszTSTAMP_TRANS
      && memcmp(pszTSTAMP_TRANS,m_strHistoryDate.data(),8) <= 0)
      return 999999;
   if (pszTSTAMP_TRANS
      && memcmp(pszTSTAMP_TRANS,Clock::instance()->getYYYYMMDDHHMMSS().data(),10) > 0)
   {
      time_t tTime;
      struct tm Tm;
      char szYYYY[] = "    ";
      memcpy(szYYYY,pszTSTAMP_TRANS,4);
      char szMM[] = "  ";
      memcpy(szMM,pszTSTAMP_TRANS + 4,2);
      char szDD[] = "  ";
      memcpy(szDD,pszTSTAMP_TRANS + 6,2);
      char szHH[] = "  ";
      memcpy(szHH,pszTSTAMP_TRANS + 8,2);
      char szMin[] = "  ";
      memcpy(szMin,pszTSTAMP_TRANS + 10,2);
      char szSec[] = "  ";
      memcpy(szSec,pszTSTAMP_TRANS + 12,2);
      Tm.tm_year = atoi(szYYYY) - 1900;
      Tm.tm_mon = atoi(szMM) - 1;
      Tm.tm_mday = atoi(szDD);
      Tm.tm_hour = atoi(szHH);
      Tm.tm_min = atoi(szMin);
      Tm.tm_sec =  atoi(szSec);
      Tm.tm_isdst = -1;
      tTime = mktime(&Tm);
      Timestamp::gmt(Tm,tTime);
      if (Extract::instance()->getCustomCode() == "EFTPOS")
         Timestamp::adjustGMT(Tm,720); //+12 hours in minutes
      int iInsertSequenceNumber =  (Tm.tm_year + 1900 - 1997) * 10000000
         + (Tm.tm_yday + 1) * 10000
         + Tm.tm_hour * 100
         + Tm.tm_min;
      if (iInsertSequenceNumber > m_iInsertSequenceNumber)
         return iInsertSequenceNumber;
   }
   return m_iInsertSequenceNumber;
  //## end database::InsertSequenceNumber::getYYYDDDHHMM%39776655026A.body
}

reusable::string InsertSequenceNumber::getYYYYMMDDJJJHHMM ()
{
  //## begin database::InsertSequenceNumber::getYYYYMMDDJJJHHMM%5B6DBCCF0160.body preserve=yes
   if (m_iYear == 0)
      getYYYDDDHHMM();
   char szBuffer[6 * PERCENTD + 1] = { "YYYYMMDDJJJHHMM" };
   return string(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"%d%02d%02d%03d%02d%02d",m_iYear,m_iMonth,m_iDay,m_iJulianDay,m_iHour,m_iMin));
  //## end database::InsertSequenceNumber::getYYYYMMDDJJJHHMM%5B6DBCCF0160.body
}

void InsertSequenceNumber::update (reusable::Subject* pSubject)
{
  //## begin database::InsertSequenceNumber::update%4603477E02FD.body preserve=yes
   if (pSubject == MidnightAlarm::instance())
   {
      Date hDate(SwitchClock::instance()->getDate().c_str());
      hDate -= m_iHistoryDays;
      m_strHistoryDate = hDate.asString("%Y%m%d");
   }
   if (pSubject == MinuteTimer::instance())
      setInsertSequenceNumber();

  //## end database::InsertSequenceNumber::update%4603477E02FD.body
}

void InsertSequenceNumber::setInsertSequenceNumber ()
{
  //## begin database::InsertSequenceNumber::setInsertSequenceNumber%6074B0AE0122.body preserve=yes
   time_t tTime;
   time(&tTime);
   if (Extract::instance()->getCustomCode() == "EFTPOS")
      tTime += 43200;//+12 hours in seconds
   struct tm Tm;
   Timestamp::gmt(Tm, tTime);
   m_iMin = Tm.tm_min;
   m_iHour = Tm.tm_hour;
   m_iJulianDay = Tm.tm_yday + 1;
   m_iYear = Tm.tm_year + 1900;
   m_iMonth = Tm.tm_mon + 1;
   m_iDay = Tm.tm_mday;
   m_iInsertSequenceNumber = ((m_iYear - 1997) * 10000000)
      + (m_iJulianDay * 10000)
      + (m_iHour * 100)
      + m_iMin;
   return;

  //## end database::InsertSequenceNumber::setInsertSequenceNumber%6074B0AE0122.body
}

// Additional Declarations
  //## begin database::InsertSequenceNumber%397765380057.declarations preserve=yes
  //## end database::InsertSequenceNumber%397765380057.declarations

} // namespace database

//## begin module%39776592030A.epilog preserve=yes
//## end module%39776592030A.epilog
