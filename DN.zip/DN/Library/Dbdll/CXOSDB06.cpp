//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%35F96159015F.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%35F96159015F.cm

//## begin module%35F96159015F.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%35F96159015F.cp

//## Module: CXOSDB06%35F96159015F; Package body
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXOSDB06.cpp

//## begin module%35F96159015F.additionalIncludes preserve=no
//## end module%35F96159015F.additionalIncludes

//## begin module%35F96159015F.includes preserve=yes
// $Date:   Apr 08 2004 10:16:52  $ $Author:   D02405  $ $Revision:   1.2  $
#ifndef CXOSRU54_h
#include "CXODRU54.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
//## end module%35F96159015F.includes

#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif


//## begin module%35F96159015F.declarations preserve=no
//## end module%35F96159015F.declarations

//## begin module%35F96159015F.additionalDeclarations preserve=yes
//## end module%35F96159015F.additionalDeclarations


//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::GlobalContext 





GlobalContext::GlobalContext()
  //## begin GlobalContext::GlobalContext%34B2BF930022_const.hasinit preserve=no
  //## end GlobalContext::GlobalContext%34B2BF930022_const.hasinit
  //## begin GlobalContext::GlobalContext%34B2BF930022_const.initialization preserve=yes
  //## end GlobalContext::GlobalContext%34B2BF930022_const.initialization
{
  //## begin database::GlobalContext::GlobalContext%34B2BF930022_const.body preserve=yes
  //## end database::GlobalContext::GlobalContext%34B2BF930022_const.body
}

GlobalContext::GlobalContext (const char* pszName)
  //## begin database::GlobalContext::GlobalContext%34B2C1700259.hasinit preserve=no
  //## end database::GlobalContext::GlobalContext%34B2C1700259.hasinit
  //## begin database::GlobalContext::GlobalContext%34B2C1700259.initialization preserve=yes
   : SharedResource(pszName)
  //## end database::GlobalContext::GlobalContext%34B2C1700259.initialization
{
  //## begin database::GlobalContext::GlobalContext%34B2C1700259.body preserve=yes
   memcpy(m_sID,"DB06",4);
  //## end database::GlobalContext::GlobalContext%34B2C1700259.body
}


GlobalContext::~GlobalContext()
{
  //## begin database::GlobalContext::~GlobalContext%34B2BF930022_dest.body preserve=yes
  //## end database::GlobalContext::~GlobalContext%34B2BF930022_dest.body
}



//## Other Operations (implementation)
bool GlobalContext::get (string& strData, char cType)
{
  //## begin database::GlobalContext::get%34B2C2160348.body preserve=yes
   if (cType == 'F' && SharedResource::name().substr(3) == "END"
      && memcmp(Extract::instance()->getName().data() + 2, "LM", 2) != 0)
   {
      set<string> hMonths;
      reusable::DataModel::instance()->getMonths("FIN_L", hMonths);
      if (hMonths.size() > 0)
      {
         strData.assign(*(hMonths.rbegin()));
         return true;
      }
   }
   Context hContext("*","*");
   return hContext.get(SharedResource::name().c_str(),strData,cType);
  //## end database::GlobalContext::get%34B2C2160348.body
}

bool GlobalContext::put (const char* pszData, char cType)
{
  //## begin database::GlobalContext::put%34B2C21C02ED.body preserve=yes
   Context hContext("*","*");
   if (hContext.put(SharedResource::name().c_str(),pszData,cType))
   {
      SharedResource::notify();
      return true;
   }
   return false;
  //## end database::GlobalContext::put%34B2C21C02ED.body
}

// Additional Declarations
  //## begin database::GlobalContext%34B2BF930022.declarations preserve=yes
  //## end database::GlobalContext%34B2BF930022.declarations

} // namespace database

//## begin module%35F96159015F.epilog preserve=yes
//## end module%35F96159015F.epilog
