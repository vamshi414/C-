//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%498229470037.cm preserve=no
//	$Date:   Aug 27 2020 12:18:42  $ $Author:   e1009652  $ $Revision:   1.22  $
//## end module%498229470037.cm

//## begin module%498229470037.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%498229470037.cp

//## Module: CXOSDB34%498229470037; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB34.cpp

//## begin module%498229470037.additionalIncludes preserve=no
//## end module%498229470037.additionalIncludes

//## begin module%498229470037.includes preserve=yes
//#include <openssl/pem.h>
//#include <openssl/err.h>
//#include <openssl/rsa.h>
//#include <openssl/aes.h>
//#include <openssl/crypto.h>
//## end module%498229470037.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
#ifndef CXOSDB34_h
#include "CXODDB34.hpp"
#endif


//## begin module%498229470037.declarations preserve=no
//## end module%498229470037.declarations

//## begin module%498229470037.additionalDeclarations preserve=yes
#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
#ifndef CXOSDB37_h
#include "CXODDB37.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
static unsigned int kRand = 0;
#define RANDOM(n) (SecurityWrapper::RAND_bytes((unsigned char*)&kRand,4) ? kRand%n : 0)
//## end module%498229470037.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::AESKey 

AESKey::AESKey()
  //## begin AESKey::AESKey%498228FD013F_const.hasinit preserve=no
  //## end AESKey::AESKey%498228FD013F_const.hasinit
  //## begin AESKey::AESKey%498228FD013F_const.initialization preserve=yes
  //## end AESKey::AESKey%498228FD013F_const.initialization
{
  //## begin database::AESKey::AESKey%498228FD013F_const.body preserve=yes
   memcpy(m_sID,"DB34",4);
   m_iType = Key::AES128;
  //## end database::AESKey::AESKey%498228FD013F_const.body
}

AESKey::AESKey(const AESKey &right)
  //## begin AESKey::AESKey%498228FD013F_copy.hasinit preserve=no
  //## end AESKey::AESKey%498228FD013F_copy.hasinit
  //## begin AESKey::AESKey%498228FD013F_copy.initialization preserve=yes
  //## end AESKey::AESKey%498228FD013F_copy.initialization
{
  //## begin database::AESKey::AESKey%498228FD013F_copy.body preserve=yes
   memcpy(m_sID,"DB34",4);
   m_strKey = right.m_strKey;
   m_strIdentifier = right.m_strIdentifier;
   m_strCONTEXT_DATA = right.m_strCONTEXT_DATA;
   m_strCONTEXT_KEY = right.m_strCONTEXT_KEY;
   m_strCryptogram = right.m_strCryptogram;
   m_iStrength = right.m_iStrength;
   m_iType = right.m_iType;
   memcpy(m_szRawKey,right.m_szRawKey,sizeof(right.m_szRawKey));
  //## end database::AESKey::AESKey%498228FD013F_copy.body
}

AESKey::AESKey (const string& strKey)
  //## begin database::AESKey::AESKey%49834A3503A2.hasinit preserve=no
  //## end database::AESKey::AESKey%49834A3503A2.hasinit
  //## begin database::AESKey::AESKey%49834A3503A2.initialization preserve=yes
  //## end database::AESKey::AESKey%49834A3503A2.initialization
{
  //## begin database::AESKey::AESKey%49834A3503A2.body preserve=yes
   memcpy(m_sID,"DB34",4);
   m_strKey = strKey;
   m_iType = Key::AES128;
   if (m_strKey.length() == 64)
   {
      m_iType = Key::AES256_3;
      m_iStrength = 256;
      CodeTable::byteToNibble(m_strKey, m_szRawKey);
      m_szRawKey[32] = '\0';
   }
  //## end database::AESKey::AESKey%49834A3503A2.body
}


AESKey::~AESKey()
{
  //## begin database::AESKey::~AESKey%498228FD013F_dest.body preserve=yes
  //## end database::AESKey::~AESKey%498228FD013F_dest.body
}


AESKey & AESKey::operator=(const AESKey &right)
{
  //## begin database::AESKey::operator=%498228FD013F_assign.body preserve=yes
   if (this == &right)
      return *this;
   memcpy(m_sID,"DB34",4);
   m_strKey = right.m_strKey;
   m_strIdentifier = right.m_strIdentifier;
   m_strCONTEXT_DATA = right.m_strCONTEXT_DATA;
   m_strCONTEXT_KEY = right.m_strCONTEXT_KEY;
   m_strCryptogram = right.m_strCryptogram;
   m_iStrength = right.m_iStrength;
   m_iType = right.m_iType;
   memcpy(m_szRawKey,right.m_szRawKey,sizeof(right.m_szRawKey));
   return *this;
  //## end database::AESKey::operator=%498228FD013F_assign.body
}



//## Other Operations (implementation)
bool AESKey::decrypt (string& strText)
{
  //## begin database::AESKey::decrypt%49822AC3019C.body preserve=yes
   //AES works with blocks of 16 bytes
   //Note: this method is intended for use in decrypting keys and tokens
   //It expects a base64 encoded cipher as input
   if(m_strKey.length() == 0)
      return false;
   if (strText.length() > 108)
      return false;
   unsigned char szCiphertext[109];
   memset(szCiphertext,' ',108);
   szCiphertext[108] = '\0';
   unsigned char szBase64text[109];
   memset(szBase64text,' ',108);
   szBase64text[108] = '\0';
   char szPlaintext[109];
   memset( szPlaintext,0,108 );
   memcpy(szBase64text,strText.data(),strText.length());
   szBase64text[strText.length()] = '\0';
   securitywrapper::SecurityWrapper::ERR_clear_error();
   AES_KEY hDecryptKey;
   if (m_strKey.length() > 32)
   {
      if (SecurityWrapper::AES_set_decrypt_key((unsigned char *)m_szRawKey, m_iStrength, &hDecryptKey))
         return false;
   }
   else
   {
      if (SecurityWrapper::AES_set_decrypt_key((unsigned char *)m_strKey.c_str(), m_iStrength, &hDecryptKey))
         return false;
   }

   //Base 64 uses '=' as the pad char discount them when calculating cipher len
   const char *pszPadCharPos = strchr( (const char*)szBase64text, '=' );
   int iNumPadChars = 0;
   if ( pszPadCharPos != NULL )
   {
      iNumPadChars = strlen( pszPadCharPos );
   }
   int iCipherLen = SecurityWrapper::EVP_DecodeBlock((unsigned char *)szCiphertext,szBase64text,strText.length()) - iNumPadChars;
   if(iCipherLen <= 0 || iCipherLen > 108)
      return false;
   int iCurrPos = 0;
   while ( iCurrPos < iCipherLen)
   {
      SecurityWrapper::AES_decrypt( szCiphertext + iCurrPos, (unsigned char *)szPlaintext + iCurrPos, &hDecryptKey);
      iCurrPos += 16;
   }
   strText.assign(szPlaintext,iCipherLen);
   return true;
  //## end database::AESKey::decrypt%49822AC3019C.body
}

bool AESKey::encrypt (string& strText)
{
  //## begin database::AESKey::encrypt%49822AC301A9.body preserve=yes
   //Note: this method is intended for use in encrypting keys and tokens
   //that will be stored in the database. It produces a base64 encoded 
   //ciphertext.
   if(m_strKey.length() == 0 || strText.length() > 86)  
      return false;
   //verify key is valid
   string strCryptogram = getCryptogram();
   if(strCryptogram.length() > 0 && m_strCheckDigits.length() == 4)
   {
      if(m_strIdentifier[0] == 'P' ||  m_strIdentifier[0] == 'D')
      {
         string strCryptogram = getCryptogram();
         string strCheckDigits = strCryptogram.substr(0,min(size_t(4),strCryptogram.length()));
         if(strCheckDigits != m_strCheckDigits)
            return false;
      }
      else
      {
         string strCryptoPhrase(Key::getCryptoPhrase(),16);
         decrypt(strCryptogram);
         if (strCryptogram != strCryptoPhrase)
         {  //try converting to EBCDIC
            CodeTable::translate((char*)strCryptogram.data(), strCryptogram.length(), CodeTable::CX_EBCDIC_TO_ASCII);
            if (strCryptogram != strCryptoPhrase)
               return false;
         }
      }
   }
   unsigned char szCiphertext[81];
   memset(szCiphertext,' ',80);
   szCiphertext[80] = '\0';
   char szBase64text[109];
   memset(szBase64text,' ',108);
   szBase64text[108] = '\0';
   int iLen = strText.length();
   unsigned char sBuffer[65];
   memset(sBuffer,' ',64);
   sBuffer[64] = '\0';
   memcpy(sBuffer,strText.data(),iLen);
   sBuffer[iLen] = '\0';
   SecurityWrapper::ERR_clear_error();
   AES_KEY hEncryptKey;
   
   if (m_strKey.length() > 32)
   {  //AESKEY256_3 binary key
      if (SecurityWrapper::AES_set_encrypt_key((unsigned char *)m_szRawKey, m_iStrength, &hEncryptKey))
         return false;
   }
   else
   {
      if (SecurityWrapper::AES_set_encrypt_key((unsigned char *)m_strKey.c_str(), m_iStrength, &hEncryptKey))
         return false;
   }
   int iCurrPos = 0;
   while ( iCurrPos < iLen  )
   {
      SecurityWrapper::AES_encrypt( sBuffer + iCurrPos, szCiphertext + iCurrPos, &hEncryptKey);
      iCurrPos += 16;
   }
   //encode in base64 so characters are printable
   int iEncLen = SecurityWrapper::EVP_EncodeBlock((unsigned char *)szBase64text, szCiphertext, iCurrPos);
   if(iEncLen <= 0 || iEncLen > 108)
      return false;
   strText.assign(szBase64text,iEncLen);
   return true;
  //## end database::AESKey::encrypt%49822AC301A9.body
}

void AESKey::generateDigest (string& strValue)
{
  //## begin database::AESKey::generateDigest%49ECE45800BF.body preserve=yes
   EVP_MD* md = (EVP_MD*)SecurityWrapper::EVP_md5();   //md5 algorithm (16 char digest)
   EVP_MD_CTX* mdctx = SecurityWrapper::EVP_MD_CTX_new();
   unsigned char md_value[EVP_MAX_MD_SIZE];
   unsigned int md_len;
   SecurityWrapper::EVP_MD_CTX_reset(mdctx);
   SecurityWrapper::EVP_DigestInit_ex(mdctx, md, NULL);
   SecurityWrapper::EVP_DigestUpdate(mdctx, strValue.c_str(), strValue.length());
   SecurityWrapper::EVP_DigestFinal_ex(mdctx, md_value, &md_len);
   SecurityWrapper::EVP_MD_CTX_reset(mdctx);
   SecurityWrapper::EVP_MD_CTX_free(mdctx);
   strValue.assign((const char*)md_value, md_len);
   char szTemp[3];
   string strTemp(strValue);
   strValue.assign("");
   for (int i = 0; i < strTemp.length(); i++)
   {
      unsigned char c = strTemp.data()[i];
      strValue.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%02x",c));
   }



   //openssl_1.1.0e
   /*
   EVP_MD* md = (EVP_MD*)SecurityWrapper::EVP_md5();   //md5 algorithm (16 char digest)
   EVP_MD_CTX* mdctx = EVP_MD_CTX_new();
   //EVP_MD_CTX *mdctx;
   unsigned char md_value[EVP_MAX_MD_SIZE];
   unsigned int md_len;
   SecurityWrapper::EVP_MD_CTX_reset(mdctx);
   SecurityWrapper::EVP_DigestInit_ex(mdctx, md, NULL);
   SecurityWrapper::EVP_DigestUpdate(mdctx, strValue.c_str(), strValue.length());
   SecurityWrapper::EVP_DigestFinal_ex(mdctx, md_value, &md_len);
   SecurityWrapper::EVP_MD_CTX_reset(mdctx);
   strValue.assign((const char*)md_value, md_len);
   char szTemp[3];
   string strTemp(strValue);
   strValue.assign("");
   for (int i = 0; i < strTemp.length(); i++)
   {
      unsigned char c = strTemp.data()[i];
      strValue.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%02x",c));
   }
   */
   /*  Sha512 digest
   const EVP_MD* md = SecurityWrapper::EVP_sha512();   //sha512 algorithm (64 char digest)
   EVP_MD_CTX mdctx;
   unsigned char md_value[EVP_MAX_MD_SIZE];
   unsigned int md_len;
   SecurityWrapper::EVP_MD_CTX_reset(&mdctx);
   SecurityWrapper::EVP_DigestInit_ex(&mdctx, md, NULL);
   SecurityWrapper::EVP_DigestUpdate(&mdctx, strValue.c_str(), strValue.length());
   SecurityWrapper::EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
   SecurityWrapper::EVP_MD_CTX_reset(&mdctx);
   strValue.assign((const char*)md_value, md_len);
   char szTemp[3];
   string strTemp(strValue);
   strValue.assign("");
   for (int i = 0; i < strTemp.length(); i++)
   {
      unsigned char c = strTemp.data()[i];
      strValue.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%02x",c));
   }
   strValue.resize(32);
   */
  //## end database::AESKey::generateDigest%49ECE45800BF.body
}

int AESKey::generateHash (const char* szValue, int iLength)
{
  //## begin database::AESKey::generateHash%4A09DEA503E4.body preserve=yes
   const char* ptr = szValue;
   int lHashVal = 0;
   for(int i = 0; i < iLength; i++)
      lHashVal = (lHashVal<<5) + lHashVal + *ptr++;
   if (lHashVal < 0)
      return -lHashVal;
   return lHashVal;
  //## end database::AESKey::generateHash%4A09DEA503E4.body
}

bool AESKey::validate ()
{
  //## begin database::AESKey::validate%551C214D0054.body preserve=yes
   if(m_strCryptogram.length() == 0)
      return true; // not set yet
   if(m_strIdentifier[0] == 'P' ||  m_strIdentifier[0] == 'D')
   {  //data keys
      if(m_strCheckDigits.empty())
         computeCheckDigits();
      string strCryptogram = getCryptogram();
      string strCheckDigits = strCryptogram.substr(0,min(size_t(4),strCryptogram.length()));
      if (strCheckDigits != m_strCheckDigits)
      { //check for legacy technique
         computeLegacyCheckDigits();
         if (strCheckDigits != m_strCheckDigits)
            return false;
      }
      return true;
   }
   //keys used for encrypting tokens
   string strCryptoPhrase(Key::getCryptoPhrase(), 16);
   string strCryptogram = getCryptogram();
   decrypt(strCryptogram);
   if (strCryptogram != strCryptoPhrase)
   {
      CodeTable::translate((char*)strCryptogram.data(), strCryptogram.length(), CodeTable::CX_EBCDIC_TO_ASCII);
      if (strCryptogram != strCryptoPhrase)
         return false;
   }
   return true;
  //## end database::AESKey::validate%551C214D0054.body
}

// Additional Declarations
  //## begin database::AESKey%498228FD013F.declarations preserve=yes
bool AESKey::translate(char* psBuffer, unsigned int uiBuffer, enum TranslateType nTranslateType)
{
   //translation is only required in cases where data was generated on an EBCDIC machine and is 
   //now being processed on an ASCII based platform
   if ('1' == 0xF1)
      return false; //running on EBCDIC oriented machine no translation needed
   bool bTranslationRequired = false;
   if (nTranslateType == CX_ASCII_TO_EBCDIC)
   {
      for (int i = 0; i < uiBuffer; i++)
      {
         if ((psBuffer[i] >= 240 && psBuffer[i] <= 249) ||  //EBCDIC 0-9
             (psBuffer[i] >= 129 && psBuffer[i] <= 137) ||  //EBCDIC a-i
             (psBuffer[i] >= 145 && psBuffer[i] <= 153) ||  //EBCDIC j-r
             (psBuffer[i] >= 162 && psBuffer[i] <= 169) ||  //EBCDIC s-z
             (psBuffer[i] >= 193 && psBuffer[i] <= 201) ||  //EBCDIC A-I
             (psBuffer[i] >= 209 && psBuffer[i] <= 217) ||  //EBCDIC J-R
             (psBuffer[i] >= 226 && psBuffer[i] <= 233) ||  //EBCDIC S-Z
              psBuffer[i] == 78 ||  psBuffer[i] == 97   || psBuffer[i] == 126 || psBuffer[i] == 64)  //EBCDIC '+','/','=',' '
         {
            continue;  //character is EBCDIC
         }
         else
         {
            bTranslationRequired = true;  //Found a character that is not EBCDIC
            break;
         }
      }
      if (bTranslationRequired == true)
         CodeTable::translate(psBuffer, uiBuffer, CodeTable::CX_ASCII_TO_EBCDIC);
   }
   else
   {
      for (int i = 0; i < uiBuffer; i++)
      {
         if ((psBuffer[i] >= 48 && psBuffer[i] <= 57)  ||  //ASCII 0-9
             (psBuffer[i] >= 65 && psBuffer[i] <= 90)  ||  //ASCII A-Z
             (psBuffer[i] >= 97 && psBuffer[i] <= 122) ||  //ASCII a-z
             psBuffer[i] == 43 || psBuffer[i] == 47 || psBuffer[i] == 61 || psBuffer[i] == 44 || psBuffer[i] == 32)  //ASCII '+','/','=',',',' '
         {
            continue;  //Characeter is ASCII
         }
         else
         {
            bTranslationRequired = true; //Found a character that is not ASCII
            break;
         }
      }
      if (bTranslationRequired == true)
         CodeTable::translate(psBuffer, uiBuffer, CodeTable::CX_EBCDIC_TO_ASCII);
   }
   return bTranslationRequired;
}

void AESKey::generateSHA512Digest(string& strValue)
{ //returns a 64 byte character hex encoded string and 32 bytes of binary data in strValue
   const EVP_MD* md = SecurityWrapper::EVP_sha512();   //sha512 algorithm (64 char digest)
   EVP_MD_CTX* mdctx = EVP_MD_CTX_new();
   unsigned char md_value[EVP_MAX_MD_SIZE];
   unsigned int md_len;
   SecurityWrapper::EVP_MD_CTX_reset(mdctx);
   SecurityWrapper::EVP_DigestInit_ex(mdctx, md, NULL);
   SecurityWrapper::EVP_DigestUpdate(mdctx, strValue.c_str(), strValue.length());
   SecurityWrapper::EVP_DigestFinal_ex(mdctx, md_value, &md_len);
   SecurityWrapper::EVP_MD_CTX_reset(mdctx);
   SecurityWrapper::EVP_MD_CTX_free(mdctx);
   strValue.assign((const char*)md_value, md_len);
   strValue.resize(32);
}
bool AESKey::decryptRecord(const unsigned char* pInputBuffer, unsigned char* pOutputBuffer, int iEncryptOffset, int iEncryptLength, int iRecordLength)
{
   if ((iEncryptOffset + iEncryptLength > iRecordLength)  || //partial offset + length cannot exceed record length
       (iEncryptLength >  0 && iEncryptLength < 16)       || //partial encrypted data must be at least 16 bytes
       iRecordLength < 16                                 || //records must be at least 16 bytes (could be padded with blanks)
       iRecordLength > getMaxBufferSize()  )                 //must not exceed max buffer size
      return false;
   unsigned char iv_enc[16]; //initial vector (iv)
   memset(iv_enc, '\0', 16); //start with nulls as iv
   AES_KEY hDecryptKey;
   SecurityWrapper::AES_set_decrypt_key((unsigned char *)m_szRawKey,256,&hDecryptKey);
   memcpy(pOutputBuffer,pInputBuffer,iRecordLength);
   int iRemainingLength = iEncryptLength > 0 ? iEncryptLength : iRecordLength;
   int iExtraBytes = iRemainingLength % 16;
   int iDecryptLength = iRemainingLength - iExtraBytes; //multiple of 16 bytes
   ::AES_cbc_encrypt(pOutputBuffer + iEncryptOffset, pOutputBuffer + iEncryptOffset, iDecryptLength, &hDecryptKey, iv_enc, AES_DECRYPT);
   if (iExtraBytes)
   {  //decrypt last 16 bytes
      memset(iv_enc, '\0', 16); //reset iv to nulls
      ::AES_cbc_encrypt(pOutputBuffer + iEncryptOffset + (iRemainingLength - 16), pOutputBuffer + iEncryptOffset + (iRemainingLength - 16), 16, &hDecryptKey, iv_enc, AES_DECRYPT);
   }
   return true;
}
void AESKey::decrypt_256(unsigned char* p)
{
   AES_KEY hEncryptKey;
   unsigned char iv_enc[16];
   memset(iv_enc, '\0', 16);
   unsigned char sBuffer[16];
   SecurityWrapper::AES_set_decrypt_key((unsigned char *)m_szRawKey,256,&hEncryptKey);
   ::AES_cbc_encrypt(p,sBuffer,16,&hEncryptKey,iv_enc,AES_DECRYPT);
   //SecurityWrapper::AES_decrypt(p,sBuffer,&hEncryptKey);
   memcpy(p,sBuffer,16);
}
bool AESKey::encryptRecord(const unsigned char* pInputBuffer, unsigned char* pOutputBuffer, int iEncryptOffset, int iEncryptLength, int iRecordLength)
{
   if (iEncryptOffset + iEncryptLength > iRecordLength ||   //partial offset + length cannot exceed record length
       (iEncryptLength > 0 && iEncryptLength < 16)     ||   //partial encryption cannot be less than 16 bytes. 
       iRecordLength > getMaxBufferSize()  )                 //must not exceed max buffer size
      return false;  
   int iCursor = 0;
   unsigned char iv_enc[16]; //initial vector (iv)
   memset(iv_enc, '\0', 16); //start with nulls as iv
   AES_KEY hEncryptKey;
   SecurityWrapper::AES_set_encrypt_key((unsigned char *)m_szRawKey,256,&hEncryptKey);
   memcpy((void*)(pOutputBuffer),pInputBuffer,iRecordLength);
   int iRemainingLength = iEncryptLength > 0 ? iEncryptLength : iRecordLength;
   if (iRemainingLength % 16)
   {  //cipher block stealing, encrypt last 16 bytes first. 
      iCursor = iEncryptOffset + iRemainingLength - 16;
      ::AES_cbc_encrypt(pOutputBuffer + iCursor, pOutputBuffer + iCursor, 16, &hEncryptKey, iv_enc, AES_ENCRYPT);
      memset(iv_enc, '\0', 16); //reset initial vector
      iRemainingLength = iRemainingLength - (iRemainingLength % 16);   //overlap part of last 16 bytes
   }
   //encrypt the rest of the 16 byte blocks starting at beginning or iEncryptOffset if not 0
   ::AES_cbc_encrypt(pOutputBuffer + iEncryptOffset, pOutputBuffer + iEncryptOffset, iRemainingLength, &hEncryptKey, iv_enc, AES_ENCRYPT);
   return true;
}
void AESKey::encrypt_256(unsigned char* p)
{
   unsigned char sBuffer[16];
   unsigned char iv_enc[16]; //initial vector (iv)
   memset(iv_enc, '\0', 16); //start with nulls as iv
   AES_KEY hEncryptKey;
   SecurityWrapper::AES_set_encrypt_key((unsigned char *)m_szRawKey, 256, &hEncryptKey);
   //SecurityWrapper::AES_encrypt(p,sBuffer,&hEncryptKey); //encrypt in place
   ::AES_cbc_encrypt(p,sBuffer,16,&hEncryptKey,iv_enc,AES_ENCRYPT);
   memcpy(p,sBuffer,16);
}
void AESKey::computeCheckDigits()
{
   //## begin reusable::Key::computeCheckDigits%5514218203BB.body preserve=yes
   unsigned char szTemp[16];
   memset(szTemp, '\0', 16);
   string strTemp;
   if (m_iStrength == 256 && m_iType == Key::AES256_3)
   { 
      encrypt_256(szTemp);
      m_strCheckDigits.erase();
      strTemp.assign((char*)szTemp, 16);
   }
   else
   {
      encryptCheckDigits(szTemp,16);
      strTemp.assign((char*)szTemp, 16);
   }
   m_strCheckDigits.erase();
   for (int i = 0; i < 2; i++)
   {
      unsigned char c = strTemp.data()[i];
      m_strCheckDigits.append((char*)szTemp,snprintf((char*)szTemp,sizeof(szTemp),"%02X",c));
   }
   //## end reusable::Key::computeCheckDigits%5514218203BB.body
}
void AESKey::computeLegacyCheckDigits()
{
   unsigned char szTemp[16];
   memset(szTemp, '\0', 16);
   string strTemp((char*)szTemp, 16);
   m_strCheckDigits.erase();
   encrypt(strTemp);
   for (int i = 0; i < 2; i++)
   {
      unsigned char c = strTemp.data()[i];
      m_strCheckDigits.append((char*)szTemp,snprintf((char*)szTemp,sizeof(szTemp),"%02X",c));
   }
   if (m_strIdentifier.length() == 6 && m_strCheckDigits != m_strIdentifier.substr(2, 4) && 'A' == 0x41)
   {
      m_strCheckDigits.erase();
      CodeTable::translate((char*)strTemp.data(), strTemp.length(), CodeTable::CX_ASCII_TO_EBCDIC);
      for (int i = 0; i < 2; i++)
      {
         unsigned char c = strTemp.data()[i];
         m_strCheckDigits.append((char*)szTemp,snprintf((char*)szTemp,sizeof(szTemp),"%02X",c));
      }
   }
}

void AESKey::encryptCheckDigits(unsigned char* pBuffer,int iLength)
{
   AES_KEY hEncryptKey;
   if (m_strKey.length() > 32)
      SecurityWrapper::AES_set_encrypt_key((unsigned char *)m_szRawKey, m_iStrength, &hEncryptKey);
   else
      SecurityWrapper::AES_set_encrypt_key((unsigned char *)m_strKey.c_str(), m_iStrength, &hEncryptKey);
   int iCurrPos = 0;
   while (iCurrPos < iLength)
   {
      SecurityWrapper::AES_encrypt(pBuffer + iCurrPos, pBuffer + iCurrPos, &hEncryptKey);
      iCurrPos += 16;
   }
}
void AESKey::encryptWithOneTimeKey(string& strValue,const string& strAAD)
{
   /*This method is used to encrypt values contained in the XML tag <AccountNumber> stored in table API_QUEUE_REQUEST 
     A web service will read these records and decrypt the values before sending to VISA in the clear */
   if (strValue.empty() || strValue.length() > 28)
      return;
   //generate a one time key
   string strKey;
   for (int i = 0; i < 32; i++)
   {
      char c = strValue.data()[RANDOM(strValue.length())];
      strKey += c;
   }
   AESKey hAESKey;
   AESKey::generateSHA512Digest(strKey);
   string strKeyModified(strKey.substr(16));
   strKeyModified.append(strKey.substr(0,16));
   hAESKey.setRawKey((char*)strKeyModified.data(),strKeyModified.length());
   unsigned char ciphertext[28];
   unsigned char sInitVector[16];
   memcpy(sInitVector,strKeyModified.data(),16); //use 1st 16 bytes of key as iv
   unsigned char sTag[16];
   if (strAAD.length() == 0)
      memcpy(sTag,strKey.substr(16).data(),16);
#ifdef MVS
   //convert PAN to ascii to prevent issues in java on web side
   CodeTable::translate((char*)strValue.data(),strValue.length(),CodeTable::CX_EBCDIC_TO_ASCII);
#endif
   int iCiphertextLength = SecurityWrapper::gcm_encrypt((unsigned char*)strValue.data(),strValue.length(),
      (unsigned char*)strAAD.data(),strAAD.length(),
      hAESKey.getRawKey(),
      sInitVector,16,
      ciphertext,
      sTag);
   if (iCiphertextLength == -1)
   {
      string strErrorText;
      SecurityWrapper::getErrorText(strErrorText);
      IF::Trace::put("encryptWithOneTimeKey failed - openssl error: ",-1,true);
      IF::Trace::put(strErrorText.data(),strErrorText.length(),true);
      return;
   }
   strValue.assign(strKey.data(),strKey.length());
   strValue.append((char*)ciphertext,iCiphertextLength);
   strValue.append((char*)sTag,16);
   SecurityWrapper::base64Encode(strValue);
}

void AESKey::decryptWithOneTimeKey(string& strValue,const string& strAAD)
{
   securitywrapper::SecurityWrapper::base64Decode(strValue);
   string strCipher;
   string strTag;
   //parse strValue into Key, Cipher, and Tag
   string strKey = strValue.substr(16,16);
   strKey.append(strValue.substr(0,16));
   strTag.assign(strValue.substr(strValue.length() - 16)); //last 16 bytes
   strCipher.assign(strValue.substr(32,strValue.length() - 16 - 32)); //middle bytes
   unsigned char sInitVector[16];
   memcpy(sInitVector,strKey.data(),16); //use 1st 16 bytes of key as iv
   unsigned char plaintext[28];
   int iPlainTextLength = SecurityWrapper::gcm_decrypt((unsigned char*)strCipher.data(),strCipher.length(),
      (unsigned char*)strAAD.data(),strAAD.length(),
      (unsigned char*)strTag.data(),
      (unsigned char*)strKey.data(),
      sInitVector,16,
      plaintext);
   if (iPlainTextLength == -1)
   {
      string strErrorText;
      SecurityWrapper::getErrorText(strErrorText);
      if (strErrorText.empty())
         strErrorText.assign("SecurityWrapper::gcm_decrypt failed");
      IF::Trace::put("decryptWithOneTimeKey failed - openssl error: ",-1,true);
      IF::Trace::put(strErrorText.data(),strErrorText.length(),true);
      return;
   }
   strValue.assign((char*)plaintext,iPlainTextLength);
#ifdef MVS
   CodeTable::translate((char*)strValue.data(),strValue.length(),CodeTable::CX_ASCII_TO_EBCDIC);
#endif
}
  //## end database::AESKey%498228FD013F.declarations

} // namespace database

//## begin module%498229470037.epilog preserve=yes
//## end module%498229470037.epilog
