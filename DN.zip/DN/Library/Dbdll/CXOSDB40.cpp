//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4B15452901E7.cm preserve=no
//	$Date:   Apr 17 2020 15:48:02  $ $Author:   e1009510  $ $Revision:   1.16  $
//## end module%4B15452901E7.cm

//## begin module%4B15452901E7.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4B15452901E7.cp

//## Module: CXOSDB40%4B15452901E7; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB40.cpp

//## begin module%4B15452901E7.additionalIncludes preserve=no
//## end module%4B15452901E7.additionalIncludes

//## begin module%4B15452901E7.includes preserve=yes
#ifndef CXOSDB33_h
#include "CXODDB33.hpp"
#endif
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
//## end module%4B15452901E7.includes

#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSDB39_h
#include "CXODDB39.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDB40_h
#include "CXODDB40.hpp"
#endif


//## begin module%4B15452901E7.declarations preserve=no
//## end module%4B15452901E7.declarations

//## begin module%4B15452901E7.additionalDeclarations preserve=yes
#include "CXODIF16.hpp"
//## end module%4B15452901E7.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::ZosEncryptedFile 

ZosEncryptedFile::ZosEncryptedFile()
  //## begin ZosEncryptedFile::ZosEncryptedFile%4B15445301A4_const.hasinit preserve=no
      : m_iCount(0),
        m_iEncryptLength(0),
        m_iEncryptOffset(0),
        m_pKey(0)
  //## end ZosEncryptedFile::ZosEncryptedFile%4B15445301A4_const.hasinit
  //## begin ZosEncryptedFile::ZosEncryptedFile%4B15445301A4_const.initialization preserve=yes
  , m_hMemory(4096), m_pEncryptionBuffer(0), m_bVariableBlock(false)
  //## end ZosEncryptedFile::ZosEncryptedFile%4B15445301A4_const.initialization
{
  //## begin database::ZosEncryptedFile::ZosEncryptedFile%4B15445301A4_const.body preserve=yes
   memcpy(m_sID,"DB40",4);
   setEncryption(true);
   m_pEncryptionBuffer = new unsigned char[32768];
  //## end database::ZosEncryptedFile::ZosEncryptedFile%4B15445301A4_const.body
}

ZosEncryptedFile::ZosEncryptedFile (const char* pszName, const char* pszMember)
  //## begin database::ZosEncryptedFile::ZosEncryptedFile%4B154611012D.hasinit preserve=no
      : m_iCount(0),
        m_iEncryptLength(0),
        m_iEncryptOffset(0),
        m_pKey(0)
  //## end database::ZosEncryptedFile::ZosEncryptedFile%4B154611012D.hasinit
  //## begin database::ZosEncryptedFile::ZosEncryptedFile%4B154611012D.initialization preserve=yes
   , ZosFile(pszName,pszMember)
   , m_hMemory(4096), m_pEncryptionBuffer(0), m_bVariableBlock(false)
  //## end database::ZosEncryptedFile::ZosEncryptedFile%4B154611012D.initialization
{
  //## begin database::ZosEncryptedFile::ZosEncryptedFile%4B154611012D.body preserve=yes
   memcpy(m_sID,"DB40",4);
   setEncryption(true);
   m_pEncryptionBuffer = new unsigned char[32768];
  //## end database::ZosEncryptedFile::ZosEncryptedFile%4B154611012D.body
}

ZosEncryptedFile::ZosEncryptedFile (const char* pszName)
  //## begin database::ZosEncryptedFile::ZosEncryptedFile%4B1546110137.hasinit preserve=no
      : m_iCount(0),
        m_iEncryptLength(0),
        m_iEncryptOffset(0),
        m_pKey(0)
  //## end database::ZosEncryptedFile::ZosEncryptedFile%4B1546110137.hasinit
  //## begin database::ZosEncryptedFile::ZosEncryptedFile%4B1546110137.initialization preserve=yes
   , ZosFile(pszName)
   , m_hMemory(4096), m_pEncryptionBuffer(0), m_bVariableBlock(false)
  //## end database::ZosEncryptedFile::ZosEncryptedFile%4B1546110137.initialization
{
  //## begin database::ZosEncryptedFile::ZosEncryptedFile%4B1546110137.body preserve=yes
   memcpy(m_sID,"DB40",4);
   setEncryption(true);
   m_pEncryptionBuffer = new unsigned char[32768];
  //## end database::ZosEncryptedFile::ZosEncryptedFile%4B1546110137.body
}


ZosEncryptedFile::~ZosEncryptedFile()
{
  //## begin database::ZosEncryptedFile::~ZosEncryptedFile%4B15445301A4_dest.body preserve=yes
    delete[] m_pEncryptionBuffer;
  //## end database::ZosEncryptedFile::~ZosEncryptedFile%4B15445301A4_dest.body
}



//## Other Operations (implementation)
int ZosEncryptedFile::encrypt (char* psBuffer, int lRecordLength)
{
  //## begin database::ZosEncryptedFile::encrypt%4B15464A0166.body preserve=yes
   m_iCount++;
   string strDefaultDataKey = KeyRing::instance()->getDefaultDataKey();
   if(strDefaultDataKey.length() != 6 )
   {  //can't encrypt until default key is set
      if (m_iCount < 1) //only issue once per file
         IF::Trace::put("Warning, File not encrypted.Default Data Key not set");
      memcpy(m_hMemory,psBuffer,lRecordLength);
      return lRecordLength;
   }
   m_pKey = (AESKey*)KeyRing::instance()->getKey(strDefaultDataKey);
   if (!m_pKey)
   {  //can't encrypt without key
      if (m_iCount < 1)
         IF::Trace::put("Warning, File not encrypted. Cannot set Data Key");
      memcpy(m_hMemory,psBuffer,lRecordLength);
      return lRecordLength;
   }
   struct Output
   {
      short int RDW1;
      short int RDW2;
   };
   m_bVariableBlock = false;
   struct Output* pOutput = (struct Output*)(char*)psBuffer;
   if (lRecordLength == ntohs(pOutput->RDW1) && ntohs(pOutput->RDW2) == 0)
      m_bVariableBlock = true;
   unsigned char* p = m_pEncryptionBuffer;
   int iCursor = 0;
   if (m_bVariableBlock)
   {
      p += 4;
      iCursor += 4;
      pOutput = (struct Output*)(char*)m_pEncryptionBuffer;
      lRecordLength -= 4;
   }
   struct encryptionHeader2* pHeader2 = (struct encryptionHeader2*)p;
   memcpy(pHeader2,">DSS*<",6);
   pHeader2->version = htons(1);
   memcpy(pHeader2->checkDigits, m_pKey->getIdentifier().data() + m_pKey->getIdentifier().length() - 4, 4);
   pHeader2->encryptionMethod = htons(2);
   pHeader2->recordLength = htons(lRecordLength);
   pHeader2->compressionMethod = 0;
   pHeader2->compressionLength = htons(lRecordLength);
   int iHeaderSize = (m_iEncryptLength == 0) ? sizeof(struct encryptionHeader) : sizeof(struct encryptionHeader2);
   if (m_iEncryptLength > 0)
   {
      pHeader2->version = htons(2);
      pHeader2->sourcePlatform = htons(5);
      pHeader2->encryptedFieldOffset = htons(m_iEncryptOffset);
      pHeader2->encryptedFieldLength = htons(m_iEncryptLength);
   }
   if (!((AESKey*)m_pKey)->encryptRecord((const unsigned char*)psBuffer + iCursor, p + iHeaderSize, m_iEncryptOffset, m_iEncryptLength, lRecordLength))
      return 0;
   if (m_bVariableBlock)
   {
      lRecordLength += 4;
      pOutput->RDW1 = htons(lRecordLength + iHeaderSize);
      pOutput->RDW2 = 0;
   }
   return lRecordLength + iHeaderSize;
  //## end database::ZosEncryptedFile::encrypt%4B15464A0166.body
}

bool ZosEncryptedFile::read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool* pbReadError)
{
  //## begin database::ZosEncryptedFile::read%4B1546220039.body preserve=yes
   //intercept record and decrypt if necessary before passing on to 
   //base class
   if (!ZosFile::read((char*)psBuffer, lBufferLength, plRecordLength, pbReadError))
   {
      if (*pbReadError)
         IF::Trace::put("ZosFile::read failed");
      return false;
   }
   if (*plRecordLength > INT_MAX)
      return false;
   int iRecordLength;
   iRecordLength =  *((int*)plRecordLength);
   if (!decrypt(psBuffer, &iRecordLength))
   {
      *pbReadError = true;
      return false;
   }
   return true;
  //## end database::ZosEncryptedFile::read%4B1546220039.body
}

bool ZosEncryptedFile::setKey (const string& strCheckDigits)
{
  //## begin database::ZosEncryptedFile::setKey%4C813200010B.body preserve=yes
   string strIdentifier("DK");
   strIdentifier.append(strCheckDigits.data(),strCheckDigits.length());
   m_pKey = (AESKey*)KeyRing::instance()->getKey(strIdentifier);
   if(!m_pKey)
      return false;
   return true;
  //## end database::ZosEncryptedFile::setKey%4C813200010B.body
}

bool ZosEncryptedFile::write(char* psBuffer, int lRecordLength)
{
   //## begin database::ZosEncryptedFile::write%4B1546220043.body preserve=yes
   int iRetLen = encrypt(psBuffer, lRecordLength);
   memcpy(psBuffer, m_pEncryptionBuffer, iRetLen);
   return ZosFile::write((char*)psBuffer, iRetLen);
  //## end database::ZosEncryptedFile::write%4B1546220043.body
}

// Additional Declarations
  //## begin database::ZosEncryptedFile%4B15445301A4.declarations preserve=yes
bool ZosEncryptedFile::decrypt(char* psBuffer, int* plRecordLength)
{
   memcpy(m_pEncryptionBuffer, psBuffer, *plRecordLength);
   IF::Trace::putHex((char*)m_pEncryptionBuffer, *plRecordLength); //testing only
   struct encryptionHeader2* pHeader2 = (struct encryptionHeader2*)(char*)m_pEncryptionBuffer;
   if (*plRecordLength < sizeof(struct encryptionHeader) || memcmp(pHeader2->eyeCatcher, ">DSS*<", 6) != 0)
      return true;
   if (ntohs(pHeader2->encryptionMethod != 2))
   {
      IF::Trace::put("Decrypt Failure, invalid encryption method specified");
   }
   int iHeaderLength = ntohs(pHeader2->version) == 1 ? sizeof(struct encryptionHeader) : sizeof(struct encryptionHeader2);
   if (*plRecordLength < iHeaderLength + ntohs(pHeader2->recordLength))
   {
      IF::Trace::put("Decrypt Failure, invalid decryption header");
      return false;
   }
   if (!setKey(string(pHeader2->checkDigits, 4)))
   {
      IF::Trace::put("Error: record not decrypted. Data Key not loaded.");
      return false;
   }
   int iEncryptedFieldLength = 0;
   int iEncryptedFieldOffset = 0;
   if (ntohs(pHeader2->version) == 2)
   {
      iEncryptedFieldOffset = ntohs(pHeader2->encryptedFieldOffset);
      iEncryptedFieldLength = ntohs(pHeader2->encryptedFieldLength);
   }
   if (!((AESKey*)m_pKey)->decryptRecord((const unsigned char*)m_pEncryptionBuffer + iHeaderLength, (unsigned char*)psBuffer, iEncryptedFieldOffset, iEncryptedFieldLength, ntohs(pHeader2->recordLength)))
   {
      IF::Trace::put("Error: unable to decrypt record");
      return false;
   }
   *plRecordLength = ntohs(pHeader2->recordLength); //adjust length
   return true;
   //## end database::ZosEncryptedFile::read%4B1546220039.body
}


  //## end database::ZosEncryptedFile%4B15445301A4.declarations
} // namespace database

//## begin module%4B15452901E7.epilog preserve=yes
//## end module%4B15452901E7.epilog
