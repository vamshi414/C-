//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5898C1910240.cm preserve=no
//	$Date:   Jun 09 2017 18:16:18  $ $Author:   e1009510  $ $Revision:   1.0  $
//## end module%5898C1910240.cm

//## begin module%5898C1910240.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5898C1910240.cp

//## Module: CXOSDB54%5898C1910240; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB54.hpp

#ifndef CXOSDB54_h
#define CXOSDB54_h 1

//## begin module%5898C1910240.additionalIncludes preserve=no
//## end module%5898C1910240.additionalIncludes

//## begin module%5898C1910240.includes preserve=yes
//## end module%5898C1910240.includes

#ifndef CXOSRU09_h
#include "CXODRU09.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
class Table;
class Statement;
class SelectStatement;
class Query;
class Column;

} // namespace reusable

//## begin module%5898C1910240.declarations preserve=no
//## end module%5898C1910240.declarations

//## begin module%5898C1910240.additionalDeclarations preserve=yes
//## end module%5898C1910240.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::APIAuditEventVisitor%5898C08B00EC.preface preserve=yes
//## end database::APIAuditEventVisitor%5898C08B00EC.preface

//## Class: APIAuditEventVisitor%5898C08B00EC
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5898C31E028E;reusable::Column { -> F}
//## Uses: <unnamed>%5898C3520146;reusable::Query { -> F}
//## Uses: <unnamed>%5898C35E03C5;DatabaseFactory { -> F}
//## Uses: <unnamed>%5898C37D00AE;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5899824F011A;reusable::Transaction { -> F}

class DllExport APIAuditEventVisitor : public reusable::QueryVisitor  //## Inherits: <unnamed>%5898C0F80131
{
  //## begin database::APIAuditEventVisitor%5898C08B00EC.initialDeclarations preserve=yes
  //## end database::APIAuditEventVisitor%5898C08B00EC.initialDeclarations

  public:
    //## Constructors (generated)
      APIAuditEventVisitor();

    //## Constructors (specified)
      //## Operation: APIAuditEventVisitor%5898D1A5035F
      APIAuditEventVisitor (Table* pTable, Statement* pStatement);

    //## Destructor (generated)
      virtual ~APIAuditEventVisitor();


    //## Other Operations (specified)
      //## Operation: insertRow%5898C2EF00C4
      bool insertRow ();

      //## Operation: successful%58998197039D
      bool successful ();

      //## Operation: visitColumn%5898C22F0054
      virtual void visitColumn (Table* pTable, Column* pColumn);

    // Additional Public Declarations
      //## begin database::APIAuditEventVisitor%5898C08B00EC.public preserve=yes
      //## end database::APIAuditEventVisitor%5898C08B00EC.public

  protected:
    // Additional Protected Declarations
      //## begin database::APIAuditEventVisitor%5898C08B00EC.protected preserve=yes
      //## end database::APIAuditEventVisitor%5898C08B00EC.protected

  private:
    // Additional Private Declarations
      //## begin database::APIAuditEventVisitor%5898C08B00EC.private preserve=yes
      //## end database::APIAuditEventVisitor%5898C08B00EC.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: SequenceNo%5898C4630142
      //## begin database::APIAuditEventVisitor::SequenceNo%5898C4630142.attr preserve=no  private: short {U} 0
      short m_siSequenceNo;
      //## end database::APIAuditEventVisitor::SequenceNo%5898C4630142.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%5898C6F001BD
      //## Role: APIAuditEventVisitor::<m_pStatement>%5898C6F003A7
      //## begin database::APIAuditEventVisitor::<m_pStatement>%5898C6F003A7.role preserve=no  public: reusable::Statement { -> RFHgN}
      reusable::Statement *m_pStatement;
      //## end database::APIAuditEventVisitor::<m_pStatement>%5898C6F003A7.role

      //## Association: Connex Library::Database_CAT::<unnamed>%5898D2630076
      //## Role: APIAuditEventVisitor::<m_pTable>%5898D2630203
      //## begin database::APIAuditEventVisitor::<m_pTable>%5898D2630203.role preserve=no  public: reusable::Table { -> RFHgN}
      reusable::Table *m_pTable;
      //## end database::APIAuditEventVisitor::<m_pTable>%5898D2630203.role

    // Additional Implementation Declarations
      //## begin database::APIAuditEventVisitor%5898C08B00EC.implementation preserve=yes
      //## end database::APIAuditEventVisitor%5898C08B00EC.implementation

};

//## begin database::APIAuditEventVisitor%5898C08B00EC.postscript preserve=yes
//## end database::APIAuditEventVisitor%5898C08B00EC.postscript

} // namespace database

//## begin module%5898C1910240.epilog preserve=yes
//## end module%5898C1910240.epilog


#endif
