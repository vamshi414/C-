//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4FE9A9850307.cm preserve=no
//	$Date:   Jun 16 2021 00:28:58  $ $Author:   e1014059  $
//	$Revision:   1.5  $
//## end module%4FE9A9850307.cm

//## begin module%4FE9A9850307.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4FE9A9850307.cp

//## Module: CXOSDB43%4FE9A9850307; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB43.cpp

//## begin module%4FE9A9850307.additionalIncludes preserve=no
//## end module%4FE9A9850307.additionalIncludes

//## begin module%4FE9A9850307.includes preserve=yes
#include <algorithm>
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#include "CXODRU55.hpp"
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
//## end module%4FE9A9850307.includes

#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB43_h
#include "CXODDB43.hpp"
#endif


//## begin module%4FE9A9850307.declarations preserve=no
//## end module%4FE9A9850307.declarations

//## begin module%4FE9A9850307.additionalDeclarations preserve=yes
//## end module%4FE9A9850307.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
void load(reusable::Cache* pCache)
{
   while (1)
   {
      if (pCache->load())
      {
         Database::instance()->commit();
         return;
      }
      UseCase::addItem();
      Database::instance()->rollback();
      Sleep::goTo("00000500");
   }
}
//## end database%3451F34D0218.initialDeclarations

// Class database::Cache

//## begin database::Cache::State%5C1A7AB30059.attr preserve=no  public: static enum Cache::State {V} EMPTY
enum Cache::State Cache::m_nState = EMPTY;
//## end database::Cache::State%5C1A7AB30059.attr

Cache::Cache()
  //## begin Cache::Cache%4FE9A8E903E1_const.hasinit preserve=no
  //## end Cache::Cache%4FE9A8E903E1_const.hasinit
  //## begin Cache::Cache%4FE9A8E903E1_const.initialization preserve=yes
  //## end Cache::Cache%4FE9A8E903E1_const.initialization
{
  //## begin database::Cache::Cache%4FE9A8E903E1_const.body preserve=yes
  //## end database::Cache::Cache%4FE9A8E903E1_const.body
}


Cache::~Cache()
{
  //## begin database::Cache::~Cache%4FE9A8E903E1_dest.body preserve=yes
  //## end database::Cache::~Cache%4FE9A8E903E1_dest.body
}



//## Other Operations (implementation)
void Cache::initialize ()
{
  //## begin database::Cache::initialize%4FE9C68103D2.body preserve=yes
   if (reusable::Thread::getNumber() != 0)
      return;
   if (Extract::instance()->getTaskType() != "FM" && Extract::instance()->getTaskType() != "MMC")
   {
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      Query hQuery;
      int iCount;
      hQuery.setQualifier("QUALIFY", "TASK_CONTEXT_COMN");
      hQuery.bind("TASK_CONTEXT_COMN", "*", Column::LONG, &iCount, 0, "COUNT");
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "TASK_ID", "=", Extract::instance()->getName().c_str());
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "CONTEXT_KEY", "=", "STATE");
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "IMAGE_ID", "<>", Extract::instance()->getImage().c_str());
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN", "CONTEXT_DATA", "LIKE", "Started%");
      if (!pSelectStatement->execute(hQuery))
      {
         Trace::put("Error Fetching Task Status", -1, true);
         exit(1);
      }
      if ((iCount + 1) > Extract::instance()->getTargetCount())
      {
         Trace::put("Target Count of Task exceeded", -1, true);
         exit(1);
      }
   }
   m_nState = Cache::LOADING;
   if (getCache())
   {
      UseCase hUseCase("FD","## FD02 LOAD CACHE");
      for_each(getCache()->begin(),getCache()->end(),database::load);
   }
   m_nState = Cache::LOADED;
  //## end database::Cache::initialize%4FE9C68103D2.body
}

void Cache::reload (reusable::Cache* pCache)
{
  //## begin database::Cache::reload%4FF7242103A7.body preserve=yes
   UseCase hUseCase("FD","## FD03 RELOAD CACHE");
   database::load(pCache);
  //## end database::Cache::reload%4FF7242103A7.body
}

//## Get and Set Operations for Class Attributes (implementation)

const enum Cache::State Cache::getState ()
{
  //## begin database::Cache::getState%5C1A7AB30059.get preserve=no
  return m_nState;
  //## end database::Cache::getState%5C1A7AB30059.get
}

void Cache::setState (enum Cache::State value)
{
  //## begin database::Cache::setState%5C1A7AB30059.set preserve=no
  m_nState = value;
  //## end database::Cache::setState%5C1A7AB30059.set
}

// Additional Declarations
  //## begin database::Cache%4FE9A8E903E1.declarations preserve=yes
  //## end database::Cache%4FE9A8E903E1.declarations

} // namespace database

//## begin module%4FE9A9850307.epilog preserve=yes
//## end module%4FE9A9850307.epilog
