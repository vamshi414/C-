//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%35758E920361.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%35758E920361.cm

//## begin module%35758E920361.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%35758E920361.cp

//## Module: CXOSDB02%35758E920361; Package specification
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXODDB02.hpp

#ifndef CXOSDB02_h
#define CXOSDB02_h 1

//## begin module%35758E920361.additionalIncludes preserve=no
//## end module%35758E920361.additionalIncludes

//## begin module%35758E920361.additionalIncludes preserve=yes
#include <memory>
//## end module%35758E920361.additionalIncludes


//## begin module%35758E920361.includes preserve=yes
// $Date:   Jan 13 2017 15:28:58  $ $Author:   e1009510  $ $Revision:   1.3  $
//## end module%35758E920361.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Global;

} // namespace reusable

//## begin module%35758E920361.declarations preserve=no
//## end module%35758E920361.declarations

//## begin module%35758E920361.additionalDeclarations preserve=yes
//## end module%35758E920361.additionalDeclarations


//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::DatabaseFactory%346CB1F40387.preface preserve=yes
//## end database::DatabaseFactory%346CB1F40387.preface

//## Class: DatabaseFactory%346CB1F40387; Abstract
//	The DatabaseFactory class provides an interface for
//	creating database related objects.
//
//	It is based on the AbstractFactory object of the Abstract
//	Factory pattern.
//
//	It is also based on the Singleton pattern.
//
//	CXODDB02.hpp
//	CXOSDB02.cpp
//## Category: DataNavigator Foundation::Database_CAT%3451F34D0218
//## Subsystem: DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1

//## Uses: <unnamed>%38AC75040230;reusable::Global { -> F}

class DllExport DatabaseFactory : public reusable::Object  //## Inherits: <unnamed>%34EDE2A903BF
{
  //## begin database::DatabaseFactory%346CB1F40387.initialDeclarations preserve=yes
  //## end database::DatabaseFactory%346CB1F40387.initialDeclarations

  public:
    //## Constructors (generated)
      DatabaseFactory();

    //## Destructor (generated)
      virtual ~DatabaseFactory();


    //## Other Operations (specified)
      //## Operation: create%35068278007B
      virtual Object* create (const char* pszClass, const char* pszValue = 0) = 0;

      //## Operation: instance%346CD1320016
      //	Return the one-and-only instance of DatabaseFactory.
      //## Semantics:
      //	1. Return the value of m_pInstance.
      static DatabaseFactory* instance (Object* pSender = 0);

    // Additional Public Declarations
      //## begin database::DatabaseFactory%346CB1F40387.public preserve=yes
      //## end database::DatabaseFactory%346CB1F40387.public

  protected:
    // Additional Protected Declarations
      //## begin database::DatabaseFactory%346CB1F40387.protected preserve=yes
      //## end database::DatabaseFactory%346CB1F40387.protected

  private:
    // Additional Private Declarations
      //## begin database::DatabaseFactory%346CB1F40387.private preserve=yes
      //## end database::DatabaseFactory%346CB1F40387.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%346CD11B026C
      //	A pointer to the one-and-only instance of Database
      //	Factory.
      //## begin database::DatabaseFactory::Instance%346CD11B026C.attr preserve=no  private: static DatabaseFactory* {V} 0
      static DatabaseFactory* m_pInstance;
      //## end database::DatabaseFactory::Instance%346CD11B026C.attr

    // Data Members for Associations


    // Additional Implementation Declarations
      //## begin database::DatabaseFactory%346CB1F40387.implementation preserve=yes
      //## end database::DatabaseFactory%346CB1F40387.implementation

};

//## begin database::DatabaseFactory%346CB1F40387.postscript preserve=yes
//## end database::DatabaseFactory%346CB1F40387.postscript

} // namespace database

//## begin module%35758E920361.epilog preserve=yes
using namespace database;
//## end module%35758E920361.epilog


#endif
