//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41BF71820213.cm preserve=no
//	$Date:   Apr 17 2018 09:01:28  $ $Author:   e3022417  $
//	$Revision:   1.3  $
//## end module%41BF71820213.cm

//## begin module%41BF71820213.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%41BF71820213.cp

//## Module: CXOSDB24%41BF71820213; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: D:\Devel.7B.R001\ConnexPlatform\Server\Library\Dbdll\CXODDB24.hpp

#ifndef CXOSDB24_h
#define CXOSDB24_h 1

//## begin module%41BF71820213.additionalIncludes preserve=no
//## end module%41BF71820213.additionalIncludes

//## begin module%41BF71820213.includes preserve=yes
// $Date:   Apr 17 2018 09:01:28  $ $Author:   e3022417  $ $Revision:   1.3  $
//## end module%41BF71820213.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%41BF71820213.declarations preserve=no
//## end module%41BF71820213.declarations

//## begin module%41BF71820213.additionalDeclarations preserve=yes
#include <map>
//## end module%41BF71820213.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::CurrencyCode%41BF6F49009C.preface preserve=yes
//## end database::CurrencyCode%41BF6F49009C.preface

//## Class: CurrencyCode%41BF6F49009C
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%41BF705D0177;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%41BF70630128;reusable::Query { -> F}
//## Uses: <unnamed>%41BF709A0213;DatabaseFactory { -> F}

class DllExport CurrencyCode : public reusable::Observer  //## Inherits: <unnamed>%41BF6FB002AF
{
  //## begin database::CurrencyCode%41BF6F49009C.initialDeclarations preserve=yes
  //## end database::CurrencyCode%41BF6F49009C.initialDeclarations

  public:
    //## Constructors (generated)
      CurrencyCode();

    //## Destructor (generated)
      virtual ~CurrencyCode();


    //## Other Operations (specified)
      //## Operation: formatAmount%451D19B5035B
      string formatAmount (double dAmount, const string& strCURRENCY_CODE, int iSize, bool bLeftJustified = true, bool bPrefixZeros = false, bool bCurrencySymbol = false);

      //## Operation: getCurrencyDetails%41BF77C50232
      bool getCurrencyDetails (const string& strCURRENCY_CODE, string& strCUR_SYMBOL, short& nDECIMAL_PLACES);

      //## Operation: instance%41BF75DA00BB
      //	Return the one-and-only instance of CurrencyCode.
      //## Semantics:
      //	1. Return the value of m_pInstance.
      static CurrencyCode* instance ();

      //## Operation: update%41BF766300AB
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: LoadCurrencyFailure%5AD5FB2D033E
      const bool& LoadCurrencyFailure () const
      {
        //## begin database::CurrencyCode::LoadCurrencyFailure%5AD5FB2D033E.get preserve=no
        return m_bLoadCurrencyFailure;
        //## end database::CurrencyCode::LoadCurrencyFailure%5AD5FB2D033E.get
      }


    // Additional Public Declarations
      //## begin database::CurrencyCode%41BF6F49009C.public preserve=yes
      //## end database::CurrencyCode%41BF6F49009C.public

  protected:
    // Additional Protected Declarations
      //## begin database::CurrencyCode%41BF6F49009C.protected preserve=yes
      //## end database::CurrencyCode%41BF6F49009C.protected

  private:

    //## Other Operations (specified)
      //## Operation: queryTable%41BF784001F4
      bool queryTable ();

    // Data Members for Class Attributes

      //## Attribute: CURRENCY_CODE%41BF74240128
      //## begin database::CurrencyCode::CURRENCY_CODE%41BF74240128.attr preserve=no  public: string {V} 
      string m_strCURRENCY_CODE;
      //## end database::CurrencyCode::CURRENCY_CODE%41BF74240128.attr

      //## Attribute: CUR_SYMBOL%41BF747D00FA
      //## begin database::CurrencyCode::CUR_SYMBOL%41BF747D00FA.attr preserve=no  public: string {V} 
      string m_strCUR_SYMBOL;
      //## end database::CurrencyCode::CUR_SYMBOL%41BF747D00FA.attr

      //## Attribute: CurrencyDetails%41BF74CB0290
      //## begin database::CurrencyCode::CurrencyDetails%41BF74CB0290.attr preserve=no  public: map<string,pair<string,int>,less<string> > {V} 
      map<string,pair<string,int>,less<string> > m_hCurrencyDetails;
      //## end database::CurrencyCode::CurrencyDetails%41BF74CB0290.attr

      //## Attribute: DECIMAL_PLACES%41BF749F002E
      //## begin database::CurrencyCode::DECIMAL_PLACES%41BF749F002E.attr preserve=no  public: short {V} 
      short m_nDECIMAL_PLACES;
      //## end database::CurrencyCode::DECIMAL_PLACES%41BF749F002E.attr

    // Additional Private Declarations
      //## begin database::CurrencyCode%41BF6F49009C.private preserve=yes
      //## end database::CurrencyCode%41BF6F49009C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin database::CurrencyCode::LoadCurrencyFailure%5AD5FB2D033E.attr preserve=no  public: bool {U} false
      bool m_bLoadCurrencyFailure;
      //## end database::CurrencyCode::LoadCurrencyFailure%5AD5FB2D033E.attr

      //## Attribute: Instance%41BF75A1036B
      //	A pointer to the one-and-only instance of CurrencyCode.
      //## begin database::CurrencyCode::Instance%41BF75A1036B.attr preserve=no  private: static CurrencyCode* {V} 0
      static CurrencyCode* m_pInstance;
      //## end database::CurrencyCode::Instance%41BF75A1036B.attr

    // Additional Implementation Declarations
      //## begin database::CurrencyCode%41BF6F49009C.implementation preserve=yes
      //## end database::CurrencyCode%41BF6F49009C.implementation

};

//## begin database::CurrencyCode%41BF6F49009C.postscript preserve=yes
//## end database::CurrencyCode%41BF6F49009C.postscript

} // namespace database

//## begin module%41BF71820213.epilog preserve=yes
using namespace database;
//## end module%41BF71820213.epilog


#endif
