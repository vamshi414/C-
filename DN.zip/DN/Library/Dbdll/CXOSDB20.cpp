//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3A369581014A.cm preserve=no
//   %X% %Q% %Z% %W%
//## end module%3A369581014A.cm

//## begin module%3A369581014A.cp preserve=no
// Copyright (c) 1998 - 2004
// eFunds Corporation
//## end module%3A369581014A.cp

//## Module: CXOSDB20%3A369581014A; Package body
//## Subsystem: DBDLL%35758D89000D
// .
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXOSDB20.cpp

//## begin module%3A369581014A.additionalIncludes preserve=no
//## end module%3A369581014A.additionalIncludes

//## begin module%3A369581014A.includes preserve=yes
// $Date:   Jun 30 2006 11:35:28  $ $Author:   D02405  $ $Revision:   1.3  $
#include <memory.h>
#include "CXODIF03.hpp"
//## end module%3A369581014A.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB20_h
#include "CXODDB20.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU01_h
#include "CXODRU01.hpp"
#endif


//## begin module%3A369581014A.declarations preserve=no
//## end module%3A369581014A.declarations

//## begin module%3A369581014A.additionalDeclarations preserve=yes
//## end module%3A369581014A.additionalDeclarations


//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::License_i

//## begin database::License_i::Instance%3A3678A70316.attr preserve=no  private: static License_i* {V} 0
License_i* License_i::m_pInstance = 0;
//## end database::License_i::Instance%3A3678A70316.attr



License_i::License_i()
  //## begin License_i::License_i%3A3678490090_const.hasinit preserve=no
      : m_pSubject(0)
  //## end License_i::License_i%3A3678490090_const.hasinit
  //## begin License_i::License_i%3A3678490090_const.initialization preserve=yes
  //## end License_i::License_i%3A3678490090_const.initialization
{
  //## begin database::License_i::License_i%3A3678490090_const.body preserve=yes
   memcpy(m_sID,"DB20",4);
   m_hQuery.attach(this);
  //## end database::License_i::License_i%3A3678490090_const.body
}


License_i::~License_i()
{
  //## begin database::License_i::~License_i%3A3678490090_dest.body preserve=yes
  //## end database::License_i::~License_i%3A3678490090_dest.body
}



//## Other Operations (implementation)
int License_i::getStatus (const char* pszOption)
{
  //## begin database::License_i::getStatus%3A3762D60025.body preserve=yes
   map<string,int,less<string> >::iterator pOption;
   pOption = m_hOption.find(pszOption);
   if (pOption == m_hOption.end())
   {
      int lStatus = query(pszOption);
      if (lStatus == -1)
         return -1;
      pair<map<string,int,less<string> >::iterator,bool> hResult;
      hResult = m_hOption.insert(map<string,int,less<string> >::value_type(pszOption,lStatus));
      pOption = hResult.first;
   }
   return (*pOption).second;
  //## end database::License_i::getStatus%3A3762D60025.body
}

License_i* License_i::instance ()
{
  //## begin database::License_i::instance%3A367871032C.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new License_i();
   return m_pInstance;
  //## end database::License_i::instance%3A367871032C.body
}

int License_i::query (const char* pszOption)
{
  //## begin database::License_i::query%3A3769B10232.body preserve=yes
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   int m = 0;
   short iNull;
   Query hQuery;
   hQuery.join("AS_WIDGET_RESTRICT","INNER","AS_PROFILE_ENTRY","PERMISSION_ID");
   hQuery.join("AS_PROFILE_ENTRY","INNER","AS_USER_PROFILE","PROFILE_ID");
   hQuery.bind("AS_WIDGET_RESTRICT","*",Column::LONG,&m,&iNull,"COUNT");
   hQuery.setQualifier("QUALIFY","AS_WIDGET_RESTRICT");
   hQuery.setQualifier("QUALIFY","AS_PROFILE_ENTRY");
   hQuery.setQualifier("QUALIFY","AS_USER_PROFILE");
   hQuery.setBasicPredicate("AS_USER_PROFILE","CUST_ID","=",strCUST_ID.c_str());
//   hQuery.setBasicPredicate("AS_WIDGET_RESTRICT","WIDGET_ID","=","OPTN_DEVICE_SVCS");
// This is a temporary fix for St. George, Jul 2001 release so DEV_ADMIN
// recs aren't loaded.  This will be taken out for the April realease.
   hQuery.setBasicPredicate("AS_WIDGET_RESTRICT","WIDGET_ID","IN",
      "('OPTN_AUTO_BALANCE','OPTN_CASH_MGT')");
   if (!pSelectStatement->execute(hQuery))
      return -1;
   if (m > 0)
      m = 1;
   return m;
  //## end database::License_i::query%3A3769B10232.body
}

void License_i::update (Subject* pSubject)
{
  //## begin database::License_i::update%3A3697D60102.body preserve=yes
   Trace::put(__FILE__,__LINE__,"update()",-1);

   m_pSubject->notify();
  //## end database::License_i::update%3A3697D60102.body
}

void License_i::retrieveAccess (const char* pszOption, string* strRelationshipID, string* strOnlineEntityID, Subject* pSubject)
{
  //## begin database::License_i::retrieveAccess%3ADB16F800A7.body preserve=yes
   Trace::put(__FILE__,__LINE__,"retrieveAccess()",-1);
   m_pSubject = pSubject;

   // prepare query
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));

   m_hQuery.reset();

   m_hQuery.join("AS_USER_PROFILE","INNER","AS_ENTITY_ROLE","ENTITY_ID");
   m_hQuery.join("AS_ENTITY_ROLE","INNER","AS_ROLE_RELATION","ROLE_ID");
   m_hQuery.join("AS_USER_PROFILE","INNER","AS_PROFILE_ENTRY","PROFILE_ID");
   m_hQuery.join("AS_PROFILE_ENTRY","INNER","AS_WIDGET_RESTRICT","PERMISSION_ID");

   m_hQuery.setQualifier("QUALIFY","AS_ROLE_RELATION");
   m_hQuery.setQualifier("QUALIFY","AS_WIDGET_RESTRICT");
   m_hQuery.setQualifier("QUALIFY","AS_PROFILE_ENTRY");
   m_hQuery.setQualifier("QUALIFY","AS_USER_PROFILE");
   m_hQuery.setQualifier("QUALIFY","AS_ENTITY_ROLE");

   m_hQuery.bind("AS_ROLE_RELATION","RELATIONSHIP_ID",Column::STRING,strRelationshipID);
   m_hQuery.bind("AS_ENTITY_ROLE","ONLINE_ENTITY_ID",Column::STRING,strOnlineEntityID);

   m_hQuery.setDistinct(true);
   m_hQuery.setBasicPredicate("AS_USER_PROFILE","CUST_ID","=",strCUST_ID.c_str());
   m_hQuery.setBasicPredicate("AS_WIDGET_RESTRICT","WIDGET_ID","=","OPTN_AUTO_DEPOSIT");
   m_hQuery.setBasicPredicate("AS_ROLE_RELATION","RELATIONSHIP_ID","IN","('ACQINST','ACQPROC')");

   string strOrderBy("AS_ROLE_RELATION.RELATIONSHIP_ID,");
   strOrderBy += "AS_ENTITY_ROLE.ONLINE_ENTITY_ID";
   m_hQuery.setOrderByClause(strOrderBy);

   pSelectStatement->execute(m_hQuery);
  //## end database::License_i::retrieveAccess%3ADB16F800A7.body
}

// Additional Declarations
  //## begin database::License_i%3A3678490090.declarations preserve=yes
  //## end database::License_i%3A3678490090.declarations

} // namespace database

//## begin module%3A369581014A.epilog preserve=yes
//## end module%3A369581014A.epilog
