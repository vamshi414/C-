//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5E1335C201FE.cm preserve=no
//	$Date:   Oct 21 2020 22:51:08  $ $Author:   e3028298  $
//	$Revision:   1.3  $
//## end module%5E1335C201FE.cm

//## begin module%5E1335C201FE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5E1335C201FE.cp

//## Module: CXOSDB65%5E1335C201FE; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: D:\Devel\V03.1A.R007\ConnexPlatform\Server\Library\Dbdll\CXOSDB65.cpp

//## begin module%5E1335C201FE.additionalIncludes preserve=no
//## end module%5E1335C201FE.additionalIncludes

//## begin module%5E1335C201FE.includes preserve=yes
//## end module%5E1335C201FE.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB65_h
#include "CXODDB65.hpp"
#endif


//## begin module%5E1335C201FE.declarations preserve=no
//## end module%5E1335C201FE.declarations

//## begin module%5E1335C201FE.additionalDeclarations preserve=yes
//## end module%5E1335C201FE.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::EntityOption 

//## begin database::EntityOption::Instance%5E133353021B.attr preserve=no  private: static database::EntityOption* {V} 0
database::EntityOption* EntityOption::m_pInstance = 0;
//## end database::EntityOption::Instance%5E133353021B.attr

EntityOption::EntityOption()
  //## begin EntityOption::EntityOption%5E132F5600E5_const.hasinit preserve=no
      : m_pSetting(0)
  //## end EntityOption::EntityOption%5E132F5600E5_const.hasinit
  //## begin EntityOption::EntityOption%5E132F5600E5_const.initialization preserve=yes
  //## end EntityOption::EntityOption%5E132F5600E5_const.initialization
{
  //## begin database::EntityOption::EntityOption%5E132F5600E5_const.body preserve=yes
   memcpy(m_sID, "DB65", 4);
  //## end database::EntityOption::EntityOption%5E132F5600E5_const.body
}


EntityOption::~EntityOption()
{
  //## begin database::EntityOption::~EntityOption%5E132F5600E5_dest.body preserve=yes
   delete m_pSetting;
  //## end database::EntityOption::~EntityOption%5E132F5600E5_dest.body
}



//## Other Operations (implementation)
bool EntityOption::get (const reusable::string& strENTITY_TYPE, const reusable::string& strENTITY_ID, const reusable::string& strCUST_ID, const char* pszUSE_CASE_NAME, map<string,string,less<string> >* pSetting)
{
  //## begin database::EntityOption::get%5E132FA50059.body preserve=yes
   m_pSetting = pSetting;
   Query hQuery;
   hQuery.attach(this);
   hQuery.setIndex(1);
   hQuery.setQualifier("QUALIFY", "USE_CASE_CHOICE");
   hQuery.setQualifier("QUALIFY", "USE_CASE_OPTION");
   hQuery.setQualifier("QUALIFY", "ENTITY_OPTION");
   hQuery.join("USE_CASE_CHOICE", "INNER", "USE_CASE_OPTION", "USE_CASE_NAME");
   hQuery.join("USE_CASE_CHOICE", "INNER", "USE_CASE_OPTION", "OPTION_SET");
   hQuery.join("USE_CASE_OPTION", "INNER", "ENTITY_OPTION", "USE_CASE_NAME");
   hQuery.join("USE_CASE_OPTION", "INNER", "ENTITY_OPTION", "OPTION_SET");
   hQuery.bind("USE_CASE_OPTION", "OPTION_KEY", Column::STRING, &m_strOPTION_KEY);
   hQuery.bind("USE_CASE_OPTION", "OPTION_VALUE", Column::STRING, &m_strOPTION_VALUE);
   hQuery.getSearchCondition().append("((");
   hQuery.setBasicPredicate("ENTITY_OPTION", "ENTITY_TYPE", "=", "*");
   hQuery.setBasicPredicate("ENTITY_OPTION", "ENTITY_ID", "=", "*");
   hQuery.getSearchCondition().append(") OR (");
   hQuery.setBasicPredicate("ENTITY_OPTION", "ENTITY_TYPE", "=", strENTITY_TYPE.c_str());
   hQuery.setBasicPredicate("ENTITY_OPTION", "ENTITY_ID", "=", "*");
   hQuery.getSearchCondition().append(") OR (");
   hQuery.setBasicPredicate("ENTITY_OPTION", "ENTITY_TYPE", "=", strENTITY_TYPE.c_str());
   hQuery.setBasicPredicate("ENTITY_OPTION", "ENTITY_ID", "=", strENTITY_ID.c_str());
   hQuery.getSearchCondition().append("))");
   hQuery.setBasicPredicate("ENTITY_OPTION", "USE_CASE_NAME", "=", pszUSE_CASE_NAME);
   hQuery.setBasicPredicate("ENTITY_OPTION", "CUST_ID", "=", strCUST_ID.c_str());
   hQuery.setBasicPredicate("USE_CASE_CHOICE", "CC_STATE", "=", "A");
   hQuery.setBasicPredicate("USE_CASE_CHOICE", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setBasicPredicate("ENTITY_OPTION", "CC_STATE", "=", "A");
   hQuery.setBasicPredicate("ENTITY_OPTION", "CC_CHANGE_GRP_ID", "IS NULL");
   hQuery.setOrderByClause("ENTITY_OPTION.ENTITY_TYPE,ENTITY_OPTION.ENTITY_ID");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   return pSelectStatement->execute(hQuery);
  //## end database::EntityOption::get%5E132FA50059.body
}

EntityOption* EntityOption::instance ()
{
  //## begin database::EntityOption::instance%5E1333390303.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new EntityOption();
   return m_pInstance;
  //## end database::EntityOption::instance%5E1333390303.body
}

bool EntityOption::loadUseCaseOptions (const char* pszUSE_CASE_NAME, const string& strCUST_ID, map<string,string,less<string> >* pUsecaseOptions)
{
  //## begin database::EntityOption::loadUseCaseOptions%5F3B584102A4.body preserve=yes
   m_pSetting = pUsecaseOptions;
   Query hQuery;
   hQuery.attach(this);
   hQuery.setIndex(2);
   hQuery.setQualifier("QUALIFY","USE_CASE_CHOICE");
   hQuery.setQualifier("QUALIFY","USE_CASE_OPTION");
   hQuery.setQualifier("QUALIFY","ENTITY_OPTION");
   hQuery.join("USE_CASE_CHOICE","INNER","USE_CASE_OPTION","USE_CASE_NAME");
   hQuery.join("USE_CASE_CHOICE","INNER","USE_CASE_OPTION","OPTION_SET");
   hQuery.join("USE_CASE_OPTION","INNER","ENTITY_OPTION","USE_CASE_NAME");
   hQuery.join("USE_CASE_OPTION","INNER","ENTITY_OPTION","OPTION_SET");
   hQuery.bind("USE_CASE_OPTION","OPTION_KEY",Column::STRING,&m_strOPTION_KEY);
   hQuery.bind("USE_CASE_OPTION","OPTION_VALUE",Column::STRING,&m_strOPTION_VALUE);
   hQuery.bind("ENTITY_OPTION","ENTITY_TYPE",Column::STRING,&m_strENTITY_TYPE);
   hQuery.bind("ENTITY_OPTION","ENTITY_ID",Column::STRING,&m_strENTITY_ID);
   hQuery.setBasicPredicate("ENTITY_OPTION","USE_CASE_NAME","=",pszUSE_CASE_NAME);
   hQuery.setBasicPredicate("ENTITY_OPTION","CUST_ID","=",strCUST_ID.c_str());
   hQuery.setBasicPredicate("USE_CASE_CHOICE","CC_STATE","=","A");
   hQuery.setBasicPredicate("USE_CASE_CHOICE","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("ENTITY_OPTION","CC_STATE","=","A");
   hQuery.setBasicPredicate("ENTITY_OPTION","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setOrderByClause("ENTITY_OPTION.ENTITY_TYPE,ENTITY_OPTION.ENTITY_ID");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   return pSelectStatement->execute(hQuery);
  //## end database::EntityOption::loadUseCaseOptions%5F3B584102A4.body
}

void EntityOption::update (Subject* pSubject)
{
  //## begin database::EntityOption::update%5E132F8A02B6.body preserve=yes
   if (((Query*)pSubject)->getIndex() == 1)
   {
      map<string, string, less<string> >::iterator p = m_pSetting->find(m_strOPTION_KEY.c_str());
      if (p != m_pSetting->end())
      {
         if (p->second.data() != m_strOPTION_VALUE.c_str())
            p->second = m_strOPTION_VALUE;
      }
      else
         m_pSetting->insert(map<string, string, less<string> >::value_type(m_strOPTION_KEY.c_str(), m_strOPTION_VALUE.c_str()));
   }
   else
   if (((Query*)pSubject)->getIndex() == 2)
   {
      string strKey(m_strENTITY_TYPE);
      strKey += m_strENTITY_ID + m_strOPTION_KEY;
      map<string,string,less<string> >::iterator p = m_pSetting->find(strKey);
      if (p != m_pSetting->end())
      {
         if (p->second.data() != m_strOPTION_VALUE.c_str())
            p->second = m_strOPTION_VALUE;
      }
      else
         m_pSetting->insert(map<string,string,less<string> >::value_type(strKey.c_str(),m_strOPTION_VALUE.c_str()));
   }
  //## end database::EntityOption::update%5E132F8A02B6.body
}

// Additional Declarations
  //## begin database::EntityOption%5E132F5600E5.declarations preserve=yes
  //## end database::EntityOption%5E132F5600E5.declarations

} // namespace database

//## begin module%5E1335C201FE.epilog preserve=yes
//## end module%5E1335C201FE.epilog
