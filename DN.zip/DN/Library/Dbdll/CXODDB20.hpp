//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3A36957F036E.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3A36957F036E.cm

//## begin module%3A36957F036E.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3A36957F036E.cp

//## Module: CXOSDB20%3A36957F036E; Package specification
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXODDB20.hpp

#ifndef CXOSDB20_h
#define CXOSDB20_h 1

//## begin module%3A36957F036E.additionalIncludes preserve=no
//## end module%3A36957F036E.additionalIncludes

//## begin module%3A36957F036E.includes preserve=yes
// $Date:   Jun 30 2006 11:35:24  $ $Author:   D02405  $ $Revision:   1.3  $
#include <map>
//## end module%3A36957F036E.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Subject;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%3A36957F036E.declarations preserve=no
//## end module%3A36957F036E.declarations

//## begin module%3A36957F036E.additionalDeclarations preserve=yes
//## end module%3A36957F036E.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::License_i%3A3678490090.preface preserve=yes
//## end database::License_i%3A3678490090.preface

//## Class: License_i%3A3678490090
//## Category: DataNavigator Foundation::Database_CAT%3451F34D0218
//## Subsystem: DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3A37640101CA;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%3A3764040048;DatabaseFactory { -> F}
//## Uses: <unnamed>%3A37711C019C;IF::Extract { -> F}

class DllExport License_i : public reusable::Observer  //## Inherits: <unnamed>%3A3678660055
{
  //## begin database::License_i%3A3678490090.initialDeclarations preserve=yes
  //## end database::License_i%3A3678490090.initialDeclarations

  public:
    //## Constructors (generated)
      License_i();

    //## Destructor (generated)
      virtual ~License_i();


    //## Other Operations (specified)
      //## Operation: getStatus%3A3762D60025
      int getStatus (const char* pszOption);

      //## Operation: instance%3A367871032C
      static License_i* instance ();

      //## Operation: update%3A3697D60102
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

      //## Operation: retrieveAccess%3ADB16F800A7
      void retrieveAccess (const char* pszOption, string* strRelationshipID, string* strOnlineEntityID, Subject* pSubject);

    // Additional Public Declarations
      //## begin database::License_i%3A3678490090.public preserve=yes
      //## end database::License_i%3A3678490090.public

  protected:
    // Additional Protected Declarations
      //## begin database::License_i%3A3678490090.protected preserve=yes
      //## end database::License_i%3A3678490090.protected

  private:

    //## Other Operations (specified)
      //## Operation: query%3A3769B10232
      static int query (const char* pszOption);

    // Additional Private Declarations
      //## begin database::License_i%3A3678490090.private preserve=yes
      //## end database::License_i%3A3678490090.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3A3678A70316
      //## begin database::License_i::Instance%3A3678A70316.attr preserve=no  private: static License_i* {V} 0
      static License_i* m_pInstance;
      //## end database::License_i::Instance%3A3678A70316.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Database_CAT::<unnamed>%3ADB15330174
      //## Role: License_i::<m_pSubject>%3ADB153401A7
      //## begin database::License_i::<m_pSubject>%3ADB153401A7.role preserve=no  public: reusable::Subject { -> RFHgN}
      reusable::Subject *m_pSubject;
      //## end database::License_i::<m_pSubject>%3ADB153401A7.role

      //## Association: DataNavigator Foundation::Database_CAT::<unnamed>%3ADB387001A7
      //## Role: License_i::<m_hQuery>%3ADB387101BD
      //## begin database::License_i::<m_hQuery>%3ADB387101BD.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end database::License_i::<m_hQuery>%3ADB387101BD.role

    // Additional Implementation Declarations
      //## begin database::License_i%3A3678490090.implementation preserve=yes
	   map<string,int,less<string> > m_hOption;
      //## end database::License_i%3A3678490090.implementation
};

//## begin database::License_i%3A3678490090.postscript preserve=yes
//## end database::License_i%3A3678490090.postscript

} // namespace database

//## begin module%3A36957F036E.epilog preserve=yes
using namespace database;
//## end module%3A36957F036E.epilog


#endif
