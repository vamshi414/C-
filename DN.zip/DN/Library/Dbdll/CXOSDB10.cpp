//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3EC3E269032C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3EC3E269032C.cm

//## begin module%3EC3E269032C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3EC3E269032C.cp

//## Module: CXOSDB10%3EC3E269032C; Package body
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXOSDB10.cpp

//## begin module%3EC3E269032C.additionalIncludes preserve=no
//## end module%3EC3E269032C.additionalIncludes

//## begin module%3EC3E269032C.includes preserve=yes
// $Date:   Jun 30 2006 11:35:28  $ $Author:   D02405  $ $Revision:   1.5  $
//## end module%3EC3E269032C.includes

#ifndef CXOSDB13_h
#include "CXODDB13.hpp"
#endif
#ifndef CXOSDB10_h
#include "CXODDB10.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif

//## begin module%3EC3E269032C.declarations preserve=no
//## end module%3EC3E269032C.declarations

//## begin module%3EC3E269032C.additionalDeclarations preserve=yes
//## end module%3EC3E269032C.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::DatabaseCatalog 

//## begin database::DatabaseCatalog::Instance%3EC3E4800186.attr preserve=no  private: static database::DatabaseCatalog* {V} 0
database::DatabaseCatalog* DatabaseCatalog::m_pInstance = 0;
//## end database::DatabaseCatalog::Instance%3EC3E4800186.attr

DatabaseCatalog::DatabaseCatalog()
  //## begin DatabaseCatalog::DatabaseCatalog%3EC3DC16004E_const.hasinit preserve=no
  //## end DatabaseCatalog::DatabaseCatalog%3EC3DC16004E_const.hasinit
  //## begin DatabaseCatalog::DatabaseCatalog%3EC3DC16004E_const.initialization preserve=yes
  //## end DatabaseCatalog::DatabaseCatalog%3EC3DC16004E_const.initialization
{
  //## begin database::DatabaseCatalog::DatabaseCatalog%3EC3DC16004E_const.body preserve=yes
  //## end database::DatabaseCatalog::DatabaseCatalog%3EC3DC16004E_const.body
}


DatabaseCatalog::~DatabaseCatalog()
{
  //## begin database::DatabaseCatalog::~DatabaseCatalog%3EC3DC16004E_dest.body preserve=yes
  //## end database::DatabaseCatalog::~DatabaseCatalog%3EC3DC16004E_dest.body
}



//## Other Operations (implementation)
void DatabaseCatalog::accept (database::DatabaseCatalogVisitor& hDatabaseCatalogVisitor)
{
  //## begin database::DatabaseCatalog::accept%3EC3E11C00CB.body preserve=yes
   hDatabaseCatalogVisitor.visitDatabaseCatalog(this);
   map<string,DatabaseTable,less<string> >::iterator p;
   for (p = m_hDatabaseTable.begin();p != m_hDatabaseTable.end();++p)
      (*p).second.accept(hDatabaseCatalogVisitor);
  //## end database::DatabaseCatalog::accept%3EC3E11C00CB.body
}

void DatabaseCatalog::accept (database::DatabaseCatalogVisitor& hDatabaseCatalogVisitor, const string& strTable)
{
  //## begin database::DatabaseCatalog::accept%3EC3E17101A5.body preserve=yes
   map<string,DatabaseTable,less<string> >::iterator p = addTable(strTable);
   (*p).second.accept(hDatabaseCatalogVisitor);
  //## end database::DatabaseCatalog::accept%3EC3E17101A5.body
}

map<string,DatabaseTable,less<string> >::iterator DatabaseCatalog::addTable (const string& strTable)
{
  //## begin database::DatabaseCatalog::addTable%3EC3F91202BF.body preserve=yes
   map<string,DatabaseTable,less<string> >::iterator p;
   p = m_hDatabaseTable.find(strTable);
   if (p == m_hDatabaseTable.end())
   {
      DatabaseTable hDatabaseTable(strTable);
      m_hDatabaseTable[strTable] = hDatabaseTable;
      p = m_hDatabaseTable.find(strTable);
   }
   return p;
  //## end database::DatabaseCatalog::addTable%3EC3F91202BF.body
}

int DatabaseCatalog::getColumnCount (const string& strTable)
{
  //## begin database::DatabaseCatalog::getColumnCount%3EC3EB77036B.body preserve=yes
   map<string,DatabaseTable,less<string> >::iterator p = addTable(strTable);
   return (*p).second.getColumnCount();
  //## end database::DatabaseCatalog::getColumnCount%3EC3EB77036B.body
}

bool DatabaseCatalog::getTable (const string& strPattern, const char* pszFunction, string& strTable)
{
  //## begin database::DatabaseCatalog::getTable%41F122DB01F4.body preserve=yes
   return false;
  //## end database::DatabaseCatalog::getTable%41F122DB01F4.body
}

int DatabaseCatalog::getTableCount (const string& strPattern)
{
  //## begin database::DatabaseCatalog::getTableCount%41F1227E01C5.body preserve=yes
   return 0;
  //## end database::DatabaseCatalog::getTableCount%41F1227E01C5.body
}

database::DatabaseCatalog* DatabaseCatalog::instance ()
{
  //## begin database::DatabaseCatalog::instance%3EC3E4960138.body preserve=yes
   if (!m_pInstance)
      m_pInstance = (DatabaseCatalog*)DatabaseFactory::instance()->create("DatabaseCatalog");
   return m_pInstance;
  //## end database::DatabaseCatalog::instance%3EC3E4960138.body
}

bool DatabaseCatalog::isExisting (const string& strTable)
{
  //## begin database::DatabaseCatalog::isExisting%41F11BB2004E.body preserve=yes
   return false;
  //## end database::DatabaseCatalog::isExisting%41F11BB2004E.body
}

void DatabaseCatalog::update (Subject* pSubject)
{
  //## begin database::DatabaseCatalog::update%3EC3EFF00399.body preserve=yes
  //## end database::DatabaseCatalog::update%3EC3EFF00399.body
}

// Additional Declarations
  //## begin database::DatabaseCatalog%3EC3DC16004E.declarations preserve=yes
  //## end database::DatabaseCatalog%3EC3DC16004E.declarations

} // namespace database

//## begin module%3EC3E269032C.epilog preserve=yes
//## end module%3EC3E269032C.epilog

