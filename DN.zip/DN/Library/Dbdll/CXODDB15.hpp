//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%367EBFA30080.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%367EBFA30080.cm

//## begin module%367EBFA30080.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%367EBFA30080.cp

//## Module: CXOSDB15%367EBFA30080; Package specification
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXODDB15.hpp

#ifndef CXOSDB15_h
#define CXOSDB15_h 1

//## begin module%367EBFA30080.additionalIncludes preserve=no
//## end module%367EBFA30080.additionalIncludes

//## begin module%367EBFA30080.includes preserve=yes
// $Date:   Jan 19 2022 06:38:38  $ $Author:   e3015517  $ $Revision:   1.3  $
//## end module%367EBFA30080.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Job;
class Console;
} // namespace IF

//## Modelname: Connex Foundation::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MidnightAlarm;

} // namespace timer

//## begin module%367EBFA30080.declarations preserve=no
//## end module%367EBFA30080.declarations

//## begin module%367EBFA30080.additionalDeclarations preserve=yes
//## end module%367EBFA30080.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::DuplicateIndex%367EBA3F0126.preface preserve=yes
//## end database::DuplicateIndex%367EBA3F0126.preface

//## Class: DuplicateIndex%367EBA3F0126
//## Category: DataNavigator Foundation::Database_CAT%3451F34D0218
//## Subsystem: DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%367EC08A02EF;Database { -> F}
//## Uses: <unnamed>%367EC0990188;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%367ECAF400D6;DatabaseFactory { -> F}
//## Uses: <unnamed>%367ECAF602EB;reusable::Query { -> F}
//## Uses: <unnamed>%367ECAF90245;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%367F9E8D0397;IF::Job { -> F}
//## Uses: <unnamed>%367FAEF90360;IF::Console { -> F}
//## Uses: <unnamed>%36913AB703DD;timer::Clock { -> F}
//## Uses: <unnamed>%3BF43CBB0399;monitor::UseCase { -> F}

class DllExport DuplicateIndex : public reusable::Observer  //## Inherits: <unnamed>%367EBA4801E7
{
  //## begin database::DuplicateIndex%367EBA3F0126.initialDeclarations preserve=yes
  //## end database::DuplicateIndex%367EBA3F0126.initialDeclarations

  public:
    //## Constructors (generated)
      DuplicateIndex();

    //## Destructor (generated)
      virtual ~DuplicateIndex();


    //## Other Operations (specified)
      //## Operation: update%367EBB04011F
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin database::DuplicateIndex%367EBA3F0126.public preserve=yes
      //## end database::DuplicateIndex%367EBA3F0126.public

  protected:
    // Additional Protected Declarations
      //## begin database::DuplicateIndex%367EBA3F0126.protected preserve=yes
      //## end database::DuplicateIndex%367EBA3F0126.protected

  private:

    //## Other Operations (specified)
      //## Operation: dropIndex%367EBE970323
      bool dropIndex ();

      //## Operation: queryCatalog%367EBD400009
      bool queryCatalog ();

    // Additional Private Declarations
      //## begin database::DuplicateIndex%367EBA3F0126.private preserve=yes
      //## end database::DuplicateIndex%367EBA3F0126.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Name%367EBECC0366
      //## begin database::DuplicateIndex::Name%367EBECC0366.attr preserve=no  private: string {V} 
      string m_strName;
      //## end database::DuplicateIndex::Name%367EBECC0366.attr

    // Additional Implementation Declarations
      //## begin database::DuplicateIndex%367EBA3F0126.implementation preserve=yes
      string m_strDRPX2FL;
      //## end database::DuplicateIndex%367EBA3F0126.implementation

};

//## begin database::DuplicateIndex%367EBA3F0126.postscript preserve=yes
//## end database::DuplicateIndex%367EBA3F0126.postscript

} // namespace database

//## begin module%367EBFA30080.epilog preserve=yes
using namespace database;
//## end module%367EBFA30080.epilog


#endif
