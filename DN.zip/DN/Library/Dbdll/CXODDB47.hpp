//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%53F3392E011E.cm preserve=no
//## end module%53F3392E011E.cm

//## begin module%53F3392E011E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%53F3392E011E.cp

//## Module: CXOSDB47%53F3392E011E; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB47.hpp

#ifndef CXOSDB47_h
#define CXOSDB47_h 1

//## begin module%53F3392E011E.additionalIncludes preserve=no
//## end module%53F3392E011E.additionalIncludes

//## begin module%53F3392E011E.includes preserve=yes
#include <map>
#include <set>
#include <vector>
#include "CXODDB51.hpp"
//## end module%53F3392E011E.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Column;
} // namespace database

namespace reusable {
class Buffer;

} // namespace reusable

//## begin module%53F3392E011E.declarations preserve=no
//## end module%53F3392E011E.declarations

//## begin module%53F3392E011E.additionalDeclarations preserve=yes
//## end module%53F3392E011E.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::View%53F3383D020C.preface preserve=yes
//## end database::View%53F3383D020C.preface

//## Class: View%53F3383D020C
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%53F342A10398;reusable::Query { -> F}
//## Uses: <unnamed>%53F349BC0290;IF::FlatFile { -> F}
//## Uses: <unnamed>%53F34C2A03BD;reusable::Buffer { -> F}
//## Uses: <unnamed>%54821E12037D;Column { -> F}

class DllExport View : public reusable::Object  //## Inherits: <unnamed>%53F3386C00C1
{
  //## begin database::View%53F3383D020C.initialDeclarations preserve=yes
  //## end database::View%53F3383D020C.initialDeclarations

  public:
    //## Constructors (generated)
      View();

    //## Constructors (specified)
      //## Operation: View%53F34A290126
      View (const char* pszZOSMember, const char* pszOpenMember);

    //## Destructor (generated)
      virtual ~View();


    //## Other Operations (specified)
      //## Operation: bind%53F33ECA0305
      virtual void bind (Query& hQuery, const string& strParent, const string& strTag, int iNPI);

      //## Operation: getChild%52C2BD5A030D
      const map<string,set<string,less<string> >,less<string> >& getChild ();

      //## Operation: getHeader%66005F0C02AE
      const set<string,less<string> >& getHeader ();

      //## Operation: getOneToMany%66005F1D0249
      const set<string,less<string> >& getOneToMany ();

      //## Operation: getParent%524C1E1A0366
      const set<string,less<string> >& getParent ();

      //## Operation: getSegment24Tokens%66005DE80153
      const map<string, string, less<string> >& getSegment24Tokens ();

      //## Operation: join%53F33ECF02B4
      virtual void join (Query& hQuery);

      //## Operation: setBasicPredicate%53F33ED3031F
      virtual void setBasicPredicate (Query& hQuery, const string& strParent, const string& strTag, string& strOperator, const string& strToken, const char* pszFunction = 0);

      //## Operation: setBasicPredicate%596FB69902F2
      virtual void setBasicPredicate (Query& hQuery, const string& strColumn, string& strOperator, const string& strToken);

      //## Operation: setValue%53FF7D9C0046
      void setValue (const string& strOperator, const string& strToken, vector<string>& hTokens, string& strValue);

      //## Operation: skip%53F33EDA0013
      virtual bool skip ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Prefix%5400680200F6
      map<string,string,less<string> >& getPrefix ()
      {
        //## begin database::View::getPrefix%5400680200F6.get preserve=no
        return m_hPrefix;
        //## end database::View::getPrefix%5400680200F6.get
      }


    // Additional Public Declarations
      //## begin database::View%53F3383D020C.public preserve=yes
      const multimap<string,database::Column,less<string> >& getTag ();
      //## end database::View%53F3383D020C.public
  protected:
    // Data Members for Class Attributes

      //## Attribute: Child%53F33A1E0252
      //## begin database::View::Child%53F33A1E0252.attr preserve=no  protected: map<string,set<string,less<string> >,less<string> > {VA} 
      map<string,set<string,less<string> >,less<string> > m_hChild;
      //## end database::View::Child%53F33A1E0252.attr

      //## Attribute: Header%66005F4102D1
      //## begin database::View::Header%66005F4102D1.attr preserve=no  protected: set<string,less<string> > {VA} 
      set<string,less<string> > m_hHeader;
      //## end database::View::Header%66005F4102D1.attr

      //## Attribute: iIndex%53F33A2603B9
      //## begin database::View::iIndex%53F33A2603B9.attr preserve=no  protected: int {VA} 0
      int m_iIndex;
      //## end database::View::iIndex%53F33A2603B9.attr

      //## Attribute: Index%53F33A2300D9
      //## begin database::View::Index%53F33A2300D9.attr preserve=no  protected: string {VA} 
      string m_strIndex;
      //## end database::View::Index%53F33A2300D9.attr

      //## Attribute: IndexColumns%53F33A2A0209
      //## begin database::View::IndexColumns%53F33A2A0209.attr preserve=no  protected: map<string,pair<int,int>,less<string> > {VA} 
      map<string,pair<int,int>,less<string> > m_hIndexColumns;
      //## end database::View::IndexColumns%53F33A2A0209.attr

      //## Attribute: Join%53F33A2D02F2
      //## begin database::View::Join%53F33A2D02F2.attr preserve=no  protected: set<string,less<string> > {VA} 
      set<string,less<string> > m_hJoin;
      //## end database::View::Join%53F33A2D02F2.attr

      //## Attribute: NumericColumns%5416EB31038E
      //## begin database::View::NumericColumns%5416EB31038E.attr preserve=no  protected: set<string,less<string> > {VA} 
      set<string,less<string> > m_hNumericColumns;
      //## end database::View::NumericColumns%5416EB31038E.attr

      //## Attribute: OneToMany%66005F6C02BC
      //## begin database::View::OneToMany%66005F6C02BC.attr preserve=no  protected: set<string,less<string> > {VA} 
      set<string,less<string> > m_hOneToMany;
      //## end database::View::OneToMany%66005F6C02BC.attr

      //## Attribute: Parent%53F33A3100CA
      //## begin database::View::Parent%53F33A3100CA.attr preserve=no  protected: set<string,less<string> > {VA} 
      set<string,less<string> > m_hParent;
      //## end database::View::Parent%53F33A3100CA.attr

      //## begin database::View::Prefix%5400680200F6.attr preserve=no  public: map<string,string,less<string> > {V} 
      map<string,string,less<string> > m_hPrefix;
      //## end database::View::Prefix%5400680200F6.attr

      //## Attribute: Segment24Tokens%66005D0800E7
      //## begin database::View::Segment24Tokens%66005D0800E7.attr preserve=no  protected: map<string, string, less<string> > {VA} 
      map<string, string, less<string> > m_hSegment24Tokens;
      //## end database::View::Segment24Tokens%66005D0800E7.attr

      //## Attribute: Table%53F33A360149
      //## begin database::View::Table%53F33A360149.attr preserve=no  protected: set<string,less<string> > {VA} 
      set<string,less<string> > m_hTable;
      //## end database::View::Table%53F33A360149.attr

      //## Attribute: Tag%53F33A3A0039
      //## begin database::View::Tag%53F33A3A0039.attr preserve=no  protected: multimap<string,database::Column,less<string> > {VA} 
      multimap<string,database::Column,less<string> > m_hTag;
      //## end database::View::Tag%53F33A3A0039.attr

    // Additional Protected Declarations
      //## begin database::View%53F3383D020C.protected preserve=yes
      multimap<string,database::Column,less<string> > m_hSynonyms;
      //## end database::View%53F3383D020C.protected
  private:
    // Additional Private Declarations
      //## begin database::View%53F3383D020C.private preserve=yes
      //## end database::View%53F3383D020C.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::View%53F3383D020C.implementation preserve=yes
      //## end database::View%53F3383D020C.implementation

};

//## begin database::View%53F3383D020C.postscript preserve=yes
//## end database::View%53F3383D020C.postscript

} // namespace database

//## begin module%53F3392E011E.epilog preserve=yes
//## end module%53F3392E011E.epilog


#endif
