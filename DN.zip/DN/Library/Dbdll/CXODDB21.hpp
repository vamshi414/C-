//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3B73ED0C0217.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3B73ED0C0217.cm

//## begin module%3B73ED0C0217.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3B73ED0C0217.cp

//## Module: CXOSDB21%3B73ED0C0217; Package specification
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB21.hpp

#ifndef CXOSDB21_h
#define CXOSDB21_h 1

//## begin module%3B73ED0C0217.additionalIncludes preserve=no
//## end module%3B73ED0C0217.additionalIncludes

//## begin module%3B73ED0C0217.includes preserve=yes
// $Date:   Sep 29 2004 10:39:42  $ $Author:   D93545  $ $Revision:   1.3  $
#include <map>
//## end module%3B73ED0C0217.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%3B73ED0C0217.declarations preserve=no
//## end module%3B73ED0C0217.declarations

//## begin module%3B73ED0C0217.additionalDeclarations preserve=yes
//## end module%3B73ED0C0217.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Filter%3B73EAB903B6.preface preserve=yes
//## end database::Filter%3B73EAB903B6.preface

//## Class: Filter%3B73EAB903B6
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3B8FA4180242;monitor::UseCase { -> F}
//## Uses: <unnamed>%3B8FE6BA0232;Database { -> F}
//## Uses: <unnamed>%3B95351F000F;IF::Extract { -> F}
//## Uses: <unnamed>%3B953DAD0167;DatabaseFactory { -> F}
//## Uses: <unnamed>%3B9614D100D0;reusable::SelectStatement { -> F}

class DllExport Filter : public reusable::Observer  //## Inherits: <unnamed>%3B73EC2A0063
{
  //## begin database::Filter%3B73EAB903B6.initialDeclarations preserve=yes
  //## end database::Filter%3B73EAB903B6.initialDeclarations

  public:
    //## Constructors (generated)
      Filter();

    //## Destructor (generated)
      virtual ~Filter();


    //## Other Operations (specified)
      //## Operation: add%3B7439DF0251
      bool add (Query* pQuery, string strFunction);

      //## Operation: instance%3B74381502FD
      static Filter* instance ();

      //## Operation: update%3B7439A000AB
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin database::Filter%3B73EAB903B6.public preserve=yes
      //## end database::Filter%3B73EAB903B6.public

  protected:
    // Additional Protected Declarations
      //## begin database::Filter%3B73EAB903B6.protected preserve=yes
      //## end database::Filter%3B73EAB903B6.protected

  private:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: SQL_FUNCTION%3B7C24CA035B
      const string& getSQL_FUNCTION () const
      {
        //## begin database::Filter::getSQL_FUNCTION%3B7C24CA035B.get preserve=no
        return m_strSQL_FUNCTION;
        //## end database::Filter::getSQL_FUNCTION%3B7C24CA035B.get
      }

      void setSQL_FUNCTION (const string& value)
      {
        //## begin database::Filter::setSQL_FUNCTION%3B7C24CA035B.set preserve=no
        m_strSQL_FUNCTION = value;
        //## end database::Filter::setSQL_FUNCTION%3B7C24CA035B.set
      }


      //## Attribute: SEQ_NO%3B7C24AF030D
      const string& getSEQ_NO () const
      {
        //## begin database::Filter::getSEQ_NO%3B7C24AF030D.get preserve=no
        return m_strSEQ_NO;
        //## end database::Filter::getSEQ_NO%3B7C24AF030D.get
      }

      void setSEQ_NO (const string& value)
      {
        //## begin database::Filter::setSEQ_NO%3B7C24AF030D.set preserve=no
        m_strSEQ_NO = value;
        //## end database::Filter::setSEQ_NO%3B7C24AF030D.set
      }


      //## Attribute: TABLE_NAME%3B7C24DE0213
      const string& getTABLE_NAME () const
      {
        //## begin database::Filter::getTABLE_NAME%3B7C24DE0213.get preserve=no
        return m_strTABLE_NAME;
        //## end database::Filter::getTABLE_NAME%3B7C24DE0213.get
      }

      void setTABLE_NAME (const string& value)
      {
        //## begin database::Filter::setTABLE_NAME%3B7C24DE0213.set preserve=no
        m_strTABLE_NAME = value;
        //## end database::Filter::setTABLE_NAME%3B7C24DE0213.set
      }


      //## Attribute: TASK%3B81161001B5
      void setTASK (const string& value)
      {
        //## begin database::Filter::setTASK%3B81161001B5.set preserve=no
        m_strTASK = value;
        //## end database::Filter::setTASK%3B81161001B5.set
      }


      //## Attribute: USE_CASE_ID%3B7C248B009C
      const string& getUSE_CASE_ID () const
      {
        //## begin database::Filter::getUSE_CASE_ID%3B7C248B009C.get preserve=no
        return m_strUSE_CASE_ID;
        //## end database::Filter::getUSE_CASE_ID%3B7C248B009C.get
      }

      void setUSE_CASE_ID (const string& value)
      {
        //## begin database::Filter::setUSE_CASE_ID%3B7C248B009C.set preserve=no
        m_strUSE_CASE_ID = value;
        //## end database::Filter::setUSE_CASE_ID%3B7C248B009C.set
      }


    // Additional Private Declarations
      //## begin database::Filter%3B73EAB903B6.private preserve=yes
      //## end database::Filter%3B73EAB903B6.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: FRAGMENT%3B7D18C5033C
      //## begin database::Filter::FRAGMENT%3B7D18C5033C.attr preserve=no  private: string {U} 
      string m_strFRAGMENT;
      //## end database::Filter::FRAGMENT%3B7D18C5033C.attr

      //## Attribute: FragmentKey%3B7D18A100AB
      //## begin database::Filter::FragmentKey%3B7D18A100AB.attr preserve=no  private: string {U} 
      string m_strFragmentKey;
      //## end database::Filter::FragmentKey%3B7D18A100AB.attr

      //## Attribute: FragmentMapDataQualifier%3BA10777004E
      //## begin database::Filter::FragmentMapDataQualifier%3BA10777004E.attr preserve=no  private: string {U} 
      string m_strFragmentMapDataQualifier;
      //## end database::Filter::FragmentMapDataQualifier%3BA10777004E.attr

      //## begin database::Filter::SQL_FUNCTION%3B7C24CA035B.attr preserve=no  private: string {U} 
      string m_strSQL_FUNCTION;
      //## end database::Filter::SQL_FUNCTION%3B7C24CA035B.attr

      //## Attribute: Instance%3B8D348C0222
      //## begin database::Filter::Instance%3B8D348C0222.attr preserve=no  private: static Filter {R} 0
      static Filter *m_pInstance;
      //## end database::Filter::Instance%3B8D348C0222.attr

      //## begin database::Filter::SEQ_NO%3B7C24AF030D.attr preserve=no  private: string {U} 
      string m_strSEQ_NO;
      //## end database::Filter::SEQ_NO%3B7C24AF030D.attr

      //## begin database::Filter::TABLE_NAME%3B7C24DE0213.attr preserve=no  private: string {U} 
      string m_strTABLE_NAME;
      //## end database::Filter::TABLE_NAME%3B7C24DE0213.attr

      //## begin database::Filter::TASK%3B81161001B5.attr preserve=no  private: string {V} 
      string m_strTASK;
      //## end database::Filter::TASK%3B81161001B5.attr

      //## begin database::Filter::USE_CASE_ID%3B7C248B009C.attr preserve=no  private: string {U} 
      string m_strUSE_CASE_ID;
      //## end database::Filter::USE_CASE_ID%3B7C248B009C.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%3B951C0F036B
      //## Role: Filter::<m_hQuery>%3B951C100242
      //## begin database::Filter::<m_hQuery>%3B951C100242.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end database::Filter::<m_hQuery>%3B951C100242.role

      //## Association: Connex Library::Database_CAT::<unnamed>%3B951F0903C8
      //## Role: Filter::<m_hTable>%3B951F0A0280
      //## begin database::Filter::<m_hTable>%3B951F0A0280.role preserve=no  public: reusable::Table { -> 1..nVHgN}
      vector<reusable::Table> m_hTable;
      //## end database::Filter::<m_hTable>%3B951F0A0280.role

    // Additional Implementation Declarations
      //## begin database::Filter%3B73EAB903B6.implementation preserve=yes
      map<string,pair<string,string>,less<string> > m_hFragmentMap;
      pair<string,string> m_hFragmentMapData;
      //## end database::Filter%3B73EAB903B6.implementation
};

//## begin database::Filter%3B73EAB903B6.postscript preserve=yes
//## end database::Filter%3B73EAB903B6.postscript

} // namespace database

//## begin module%3B73ED0C0217.epilog preserve=yes
using namespace database;
//## end module%3B73ED0C0217.epilog


#endif
