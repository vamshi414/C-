//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5ADF36700015.cm preserve=no
//	$Date:   May 02 2018 11:05:08  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5ADF36700015.cm

//## begin module%5ADF36700015.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5ADF36700015.cp

//## Module: CXOSDB59%5ADF36700015; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB59.hpp

#ifndef CXOSDB59_h
#define CXOSDB59_h 1

//## begin module%5ADF36700015.additionalIncludes preserve=no
//## end module%5ADF36700015.additionalIncludes

//## begin module%5ADF36700015.includes preserve=yes
//## end module%5ADF36700015.includes

#ifndef CXOSRU09_h
#include "CXODRU09.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Query;
class Column;

} // namespace reusable

//## begin module%5ADF36700015.declarations preserve=no
//## end module%5ADF36700015.declarations

//## begin module%5ADF36700015.additionalDeclarations preserve=yes
//## end module%5ADF36700015.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::RowVisitor%5ADF34FB006D.preface preserve=yes
//## end database::RowVisitor%5ADF34FB006D.preface

//## Class: RowVisitor%5ADF34FB006D
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5ADF352202EB;reusable::Table { -> F}
//## Uses: <unnamed>%5ADF35250233;reusable::Column { -> F}
//## Uses: <unnamed>%5ADF35650238;reusable::Query { -> F}

class DllExport RowVisitor : public reusable::QueryVisitor  //## Inherits: <unnamed>%5ADF351F026B
{
  //## begin database::RowVisitor%5ADF34FB006D.initialDeclarations preserve=yes
  //## end database::RowVisitor%5ADF34FB006D.initialDeclarations

  public:
    //## Constructors (specified)
      //## Operation: RowVisitor%5ADF374F027D
      RowVisitor (const string& strRow);

    //## Destructor (generated)
      virtual ~RowVisitor();


    //## Other Operations (specified)
      //## Operation: visitColumn%5ADF353000A5
      virtual void visitColumn (reusable::Table* pTable, Column* pColumn);

      //## Operation: visitQuery%5ADF35320346
      virtual void visitQuery (Query* pQuery);

      //## Operation: visitTable%5ADF353403BF
      virtual void visitTable (Table* pTable);

    // Additional Public Declarations
      //## begin database::RowVisitor%5ADF34FB006D.public preserve=yes
      //## end database::RowVisitor%5ADF34FB006D.public

  protected:
    // Additional Protected Declarations
      //## begin database::RowVisitor%5ADF34FB006D.protected preserve=yes
      //## end database::RowVisitor%5ADF34FB006D.protected

  private:
    // Additional Private Declarations
      //## begin database::RowVisitor%5ADF34FB006D.private preserve=yes
      //## end database::RowVisitor%5ADF34FB006D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Index%5ADF37D3002C
      //## begin database::RowVisitor::Index%5ADF37D3002C.attr preserve=no  private: int {V} 0
      int m_iIndex;
      //## end database::RowVisitor::Index%5ADF37D3002C.attr

      //## Attribute: Row%5ADF3770017E
      //## begin database::RowVisitor::Row%5ADF3770017E.attr preserve=no  private: const string& {V} 
      const string& m_strRow;
      //## end database::RowVisitor::Row%5ADF3770017E.attr

    // Additional Implementation Declarations
      //## begin database::RowVisitor%5ADF34FB006D.implementation preserve=yes
      //## end database::RowVisitor%5ADF34FB006D.implementation

};

//## begin database::RowVisitor%5ADF34FB006D.postscript preserve=yes
//## end database::RowVisitor%5ADF34FB006D.postscript

} // namespace database

//## begin module%5ADF36700015.epilog preserve=yes
//## end module%5ADF36700015.epilog


#endif
