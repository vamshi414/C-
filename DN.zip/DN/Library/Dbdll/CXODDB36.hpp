//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%49831D5A0101.cm preserve=no
//	$Date:   Aug 06 2012 15:13:46  $ $Author:   E1009652  $ $Revision:   1.3  $
//## end module%49831D5A0101.cm

//## begin module%49831D5A0101.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%49831D5A0101.cp

//## Module: CXOSDB36%49831D5A0101; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB36.hpp

#ifndef CXOSDB36_h
#define CXOSDB36_h 1

//## begin module%49831D5A0101.additionalIncludes preserve=no
//## end module%49831D5A0101.additionalIncludes

//## begin module%49831D5A0101.includes preserve=yes
//## end module%49831D5A0101.includes

#ifndef CXOSRU38_h
#include "CXODRU38.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class AESKeyRing;
class AESKeyManager;

} // namespace database

//## begin module%49831D5A0101.declarations preserve=no
//## end module%49831D5A0101.declarations

//## begin module%49831D5A0101.additionalDeclarations preserve=yes
//## end module%49831D5A0101.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::AESKeyFactory%49831BFF0242.preface preserve=yes
//## end database::AESKeyFactory%49831BFF0242.preface

//## Class: AESKeyFactory%49831BFF0242
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%49832F3E019D;AESKeyManager { -> F}
//## Uses: <unnamed>%49832F4000A5;AESKeyRing { -> F}

class DllExport AESKeyFactory : public reusable::KeyFactory  //## Inherits: <unnamed>%49831C170160
{
  //## begin database::AESKeyFactory%49831BFF0242.initialDeclarations preserve=yes
  //## end database::AESKeyFactory%49831BFF0242.initialDeclarations

  public:
    //## Constructors (generated)
      AESKeyFactory();

    //## Destructor (generated)
      virtual ~AESKeyFactory();


    //## Other Operations (specified)
      //## Operation: create%4983227501B4
      virtual Object* create (const char* pszClass);

    // Additional Public Declarations
      //## begin database::AESKeyFactory%49831BFF0242.public preserve=yes
      //## end database::AESKeyFactory%49831BFF0242.public

  protected:
    // Additional Protected Declarations
      //## begin database::AESKeyFactory%49831BFF0242.protected preserve=yes
      //## end database::AESKeyFactory%49831BFF0242.protected

  private:
    // Additional Private Declarations
      //## begin database::AESKeyFactory%49831BFF0242.private preserve=yes
      //## end database::AESKeyFactory%49831BFF0242.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::AESKeyFactory%49831BFF0242.implementation preserve=yes
      //## end database::AESKeyFactory%49831BFF0242.implementation

};

//## begin database::AESKeyFactory%49831BFF0242.postscript preserve=yes
//## end database::AESKeyFactory%49831BFF0242.postscript

} // namespace database

//## begin module%49831D5A0101.epilog preserve=yes
//## end module%49831D5A0101.epilog


#endif
