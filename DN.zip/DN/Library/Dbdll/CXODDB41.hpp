//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4C5059F201ED.cm preserve=no
//	$Date:   May 14 2020 18:12:06  $ $Author:   e1009510  $ $Revision:   1.3  $
//## end module%4C5059F201ED.cm

//## begin module%4C5059F201ED.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4C5059F201ED.cp

//## Module: CX0SDB41%4C5059F201ED; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB41.hpp

#ifndef CX0SDB41_h
#define CX0SDB41_h 1

//## begin module%4C5059F201ED.additionalIncludes preserve=no
//## end module%4C5059F201ED.additionalIncludes

//## begin module%4C5059F201ED.includes preserve=yes
//## end module%4C5059F201ED.includes

#ifndef CXOSDB40_h
#include "CXODDB40.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class KeyRing;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;

} // namespace IF

//## begin module%4C5059F201ED.declarations preserve=no
//## end module%4C5059F201ED.declarations

//## begin module%4C5059F201ED.additionalDeclarations preserve=yes
//## end module%4C5059F201ED.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::ZosXMLEncryptedFile%4C50597C02D5.preface preserve=yes
//## end database::ZosXMLEncryptedFile%4C50597C02D5.preface

//## Class: ZosXMLEncryptedFile%4C50597C02D5
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4C52E07602D2;IF::Trace { -> F}
//## Uses: <unnamed>%4C52E2BF008F;reusable::KeyRing { -> F}

class DllExport ZosXMLEncryptedFile : public ZosEncryptedFile  //## Inherits: <unnamed>%4C505AE2011C
{
  //## begin database::ZosXMLEncryptedFile%4C50597C02D5.initialDeclarations preserve=yes
  //## end database::ZosXMLEncryptedFile%4C50597C02D5.initialDeclarations

  public:
    //## Constructors (generated)
      ZosXMLEncryptedFile();

    //## Constructors (specified)
      //## Operation: ZosXMLEncryptedFile%4C8155E600CD
      ZosXMLEncryptedFile (const char* pszName, const char* pszMember);

      //## Operation: ZosXMLEncryptedFile%4C8155E600D0
      ZosXMLEncryptedFile (const char* pszName);

    //## Destructor (generated)
      virtual ~ZosXMLEncryptedFile();


    //## Other Operations (specified)
      //## Operation: write%4C505B2A02D6
      virtual bool write (char* psBuffer, int lRecordLength);

      //## Operation: read%4C505B51000A
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool* pbReadError = NULL);

    // Additional Public Declarations
      //## begin database::ZosXMLEncryptedFile%4C50597C02D5.public preserve=yes
      //## end database::ZosXMLEncryptedFile%4C50597C02D5.public

  protected:
    // Additional Protected Declarations
      //## begin database::ZosXMLEncryptedFile%4C50597C02D5.protected preserve=yes
      //## end database::ZosXMLEncryptedFile%4C50597C02D5.protected

  private:

    //## Other Operations (specified)
      //## Operation: encryptPAN%4C8156B20067
      bool encryptPAN (string& strPAN);

    // Additional Private Declarations
      //## begin database::ZosXMLEncryptedFile%4C50597C02D5.private preserve=yes
      //## end database::ZosXMLEncryptedFile%4C50597C02D5.private
  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::ZosXMLEncryptedFile%4C50597C02D5.implementation preserve=yes
      //## end database::ZosXMLEncryptedFile%4C50597C02D5.implementation

};

//## begin database::ZosXMLEncryptedFile%4C50597C02D5.postscript preserve=yes
//## end database::ZosXMLEncryptedFile%4C50597C02D5.postscript

} // namespace database

//## begin module%4C5059F201ED.epilog preserve=yes
//## end module%4C5059F201ED.epilog


#endif
