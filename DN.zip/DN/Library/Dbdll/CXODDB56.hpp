//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A84A7070213.cm preserve=no
//## end module%5A84A7070213.cm

//## begin module%5A84A7070213.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5A84A7070213.cp

//## Module: CXOSDB56%5A84A7070213; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB56.hpp

#ifndef CXOSDB56_h
#define CXOSDB56_h 1

//## begin module%5A84A7070213.additionalIncludes preserve=no
//## end module%5A84A7070213.additionalIncludes

//## begin module%5A84A7070213.includes preserve=yes
#include <map>
#include <vector>
//## end module%5A84A7070213.includes

#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSDB61_h
#include "CXODDB61.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class Thread;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MidnightAlarm;
} // namespace timer

namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%5A84A7070213.declarations preserve=no
//## end module%5A84A7070213.declarations

//## begin module%5A84A7070213.additionalDeclarations preserve=yes
//## end module%5A84A7070213.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Array%5A84A65F029D.preface preserve=yes
//## end database::Array%5A84A65F029D.preface

//## Class: Array%5A84A65F029D
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5A84AD2302B3;reusable::Table { -> }
//## Uses: <unnamed>%5A84B2230212;reusable::Statement { -> F}
//## Uses: <unnamed>%5A84B2250341;DatabaseFactory { -> F}
//## Uses: <unnamed>%5C09181800A8;reusable::Thread { -> F}
//## Uses: <unnamed>%5F3A78D20335;IF::Trace { -> F}
//## Uses: <unnamed>%5F3A78F502F6;IF::Extract { -> F}
//## Uses: <unnamed>%66B234120128;timer::MidnightAlarm { -> F}

class DllExport Array : public Delegate  //## Inherits: <unnamed>%5C0E6861009B
{
  //## begin database::Array%5A84A65F029D.initialDeclarations preserve=yes
  //## end database::Array%5A84A65F029D.initialDeclarations

  public:
    //## Constructors (generated)
      Array(const Array &right);

    //## Constructors (specified)
      //## Operation: Array%6584FB08006F
      Array (const string& strClass = "InsertStatement");

    //## Destructor (generated)
      virtual ~Array();


    //## Other Operations (specified)
      //## Operation: abort%5C0ED5720237
      static void abort ();

      //## Operation: add%5A85B881001A
      static bool add (const reusable::Table& hTable, const string& strClass = "InsertStatement");

      //## Operation: addToGroup%66B2348A01FC
      void addToGroup (reusable::Table* pTable);

      //## Operation: clear%5C17BE4100C1
      static void clear ();

      //## Operation: commit%5A84B09B01CF
      static bool commit ();

      //## Operation: execute%5C0E687503E7
      virtual void execute (vector<Object*>& hObject);

      //## Operation: initialize%5F3A78640274
      static void initialize ();

      //## Operation: insert%5A85B617006B
      bool insert ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Rows%5F3A783C0072
      const int getRows () const
      {
        //## begin database::Array::getRows%5F3A783C0072.get preserve=no
        return m_iRows;
        //## end database::Array::getRows%5F3A783C0072.get
      }


    // Additional Public Declarations
      //## begin database::Array%5A84A65F029D.public preserve=yes
      //## end database::Array%5A84A65F029D.public

  protected:
    // Additional Protected Declarations
      //## begin database::Array%5A84A65F029D.protected preserve=yes
      //## end database::Array%5A84A65F029D.protected

  private:
    // Additional Private Declarations
      //## begin database::Array%5A84A65F029D.private preserve=yes
      //## end database::Array%5A84A65F029D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Class%6584FBAB00AF
      //## begin database::Array::Class%6584FBAB00AF.attr preserve=no  private: string {U} 
      string m_strClass;
      //## end database::Array::Class%6584FBAB00AF.attr

      //## Attribute: Date%66B233680183
      //## begin database::Array::Date%66B233680183.attr preserve=no  private: string {V} 
      string m_strDate;
      //## end database::Array::Date%66B233680183.attr

      //## Attribute: Count%5C0E69FE02D6
      //## begin database::Array::Count%5C0E69FE02D6.attr preserve=no  private: static int {V} 0
      static int m_iCount;
      //## end database::Array::Count%5C0E69FE02D6.attr

      //## Attribute: Group%66B233AF0224
      //## begin database::Array::Group%66B233AF0224.attr preserve=no  private: vector<pair<Table*,Table*> > {V} 
      vector<pair<Table*,Table*> > m_hGroup;
      //## end database::Array::Group%66B233AF0224.attr

      //## Attribute: Instance%5A84A68D00A3
      //## begin database::Array::Instance%5A84A68D00A3.attr preserve=no  private: static vector<map<string,Array*,less<string> >*>* {V} 0
      static vector<map<string,Array*,less<string> >*>* m_pInstance;
      //## end database::Array::Instance%5A84A68D00A3.attr

      //## Attribute: Order%6114C04200F5
      //## begin database::Array::Order%6114C04200F5.attr preserve=no  private: static vector<vector<string>* >* {V} 0
      static vector<vector<string>* >* m_pOrder;
      //## end database::Array::Order%6114C04200F5.attr

      //## begin database::Array::Rows%5F3A783C0072.attr preserve=no  public: int {V} 1
      int m_iRows;
      //## end database::Array::Rows%5F3A783C0072.attr

      //## Attribute: Table%5A84ACF60306
      //## begin database::Array::Table%5A84ACF60306.attr preserve=no  private: vector<Table>* {V} 0
      vector<Table>* m_pTable;
      //## end database::Array::Table%5A84ACF60306.attr

      //## Attribute: Tables%66B2334C0319
      //## begin database::Array::Tables%66B2334C0319.attr preserve=no  private: int {V} 0
      int m_iTables;
      //## end database::Array::Tables%66B2334C0319.attr

    // Additional Implementation Declarations
      //## begin database::Array%5A84A65F029D.implementation preserve=yes
      //## end database::Array%5A84A65F029D.implementation

};

//## begin database::Array%5A84A65F029D.postscript preserve=yes
//## end database::Array%5A84A65F029D.postscript

} // namespace database

//## begin module%5A84A7070213.epilog preserve=yes
//## end module%5A84A7070213.epilog


#endif
