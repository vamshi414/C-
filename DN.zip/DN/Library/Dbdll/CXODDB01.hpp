//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%366E8F5302EA.cm preserve=no
//## end module%366E8F5302EA.cm

//## begin module%366E8F5302EA.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%366E8F5302EA.cp

//## Module: CXOSDB01%366E8F5302EA; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB01.hpp

#ifndef CXOSDB01_h
#define CXOSDB01_h 1

//## begin module%366E8F5302EA.additionalIncludes preserve=no
//## end module%366E8F5302EA.additionalIncludes

//## begin module%366E8F5302EA.includes preserve=yes
//## end module%366E8F5302EA.includes

#ifndef CXOSRU01_h
#include "CXODRU01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CriticalSection;
class Thread;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class SharedResource;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class GMTClock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class AESKeyRing;

} // namespace database

//## begin module%366E8F5302EA.declarations preserve=no
//## end module%366E8F5302EA.declarations

//## begin module%366E8F5302EA.additionalDeclarations preserve=yes
//## end module%366E8F5302EA.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::Database%3452433401B8.preface preserve=yes
//## end database::Database%3452433401B8.preface

//## Class: Database%3452433401B8; Abstract
//	The Database class provides an abstract interface to
//	connection, disconnection, commit, and rollback
//	functions to a database.
//
//	It is based on the Singleton pattern.
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1



//## Uses: <unnamed>%3C151956007B;reusable::Transaction { -> }
//## Uses: <unnamed>%3FA682D900DA;IF::Trace { -> F}
//## Uses: <unnamed>%4773484A0361;IF::SharedResource { -> F}
//## Uses: <unnamed>%4AC36E4601C7;timer::GMTClock { -> F}
//## Uses: <unnamed>%4FF5BF1B007F;AESKeyRing { -> F}
//## Uses: <unnamed>%5AD9467602FD;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%5AD94C5B026C;DatabaseFactory { -> F}
//## Uses: <unnamed>%5AEA06890141;reusable::Thread { -> F}

class DllExport Database : public reusable::Subject  //## Inherits: <unnamed>%347B2B2A0340
{
  //## begin database::Database%3452433401B8.initialDeclarations preserve=yes
  public:
  enum databaseState
   {
      NEVERCONNECTED,
      CONNECTED,
      DISCONNECTED
   };
   enum workState
   {
      IDLE,
      BUSY,
      COMMITREQUIRED,
      ROLLBACKREQUIRED
   };
  //## end database::Database%3452433401B8.initialDeclarations

  public:
    //## Constructors (generated)
      Database();

    //## Destructor (generated)
      virtual ~Database();


    //## Other Operations (specified)
      //## Operation: commit%34549605022D
      //	Commit the current unit of work.
      //## Semantics:
      //	1. m_nTransactionState = IDLE.
      //	2. ++m_nTransaction.
      virtual int commit ();

      //## Operation: connect%3470DC8E006A
      //	Attempt to connect to the physical database.
      virtual bool connect ();

      //## Operation: connect%3821964900E4
      //	Attempt to connect to the physical database.
      virtual bool connect (char* pszSubSystem, char* pszPlan);

      //## Operation: disconnect%3470DC960198
      //	Disconnect from the physical database.
      virtual void disconnect ();

      //## Operation: getDormant%3CA388AD006D
      virtual bool getDormant ();

      //## Operation: instance%3470E00D01F8
      //	Return the one-and-only instance of Database.
      //## Semantics:
      //	1, Return m_pInstance.
      static Database* instance (int i = -1);

      //## Operation: qualifier%374D73770085
      const string qualifier (const char* pszQualifier = "CUSTQUAL") const;

      //## Operation: rollback%3454960B0069
      //	Rollback the current unit of work.
      //## Semantics:
      //	1. m_nTransactionState = IDLE.
      //	2. ++m_nTransaction.
      virtual int rollback ();

      //## Operation: setState%366E9C1F0128
      virtual void setState (Database::databaseState nState);

      //## Operation: setTransactionState%43A97B31002E
      virtual void setTransactionState (Database::workState nTransactionState);

      //## Operation: state%4FFF32C00340
      const Database::databaseState state () const
      {
        //## begin database::Database::state%4FFF32C00340.body preserve=yes
         return (m_nState == NEVERCONNECTED) ? DISCONNECTED : m_nState;
        //## end database::Database::state%4FFF32C00340.body
      }

      //## Operation: traceSQLError%34F48B630103
      //	Trace SQL error information.
      virtual void traceSQLError (void* p, const char* pszID, const char* pszMethodName);

      //## Operation: traceSQLError%444A1638037A
      virtual void traceSQLError (const string& strMessage);

      //## Operation: upper%53A89D2D0291
      virtual const char* upper ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Disconnect%3CA39A36033C
      const bool getDisconnect () const
      {
        //## begin database::Database::getDisconnect%3CA39A36033C.get preserve=no
        return m_bDisconnect;
        //## end database::Database::getDisconnect%3CA39A36033C.get
      }

      void setDisconnect (bool value)
      {
        //## begin database::Database::setDisconnect%3CA39A36033C.set preserve=no
        m_bDisconnect = value;
        //## end database::Database::setDisconnect%3CA39A36033C.set
      }


      //## Attribute: Dormant%3CA33EAD0128
      void setDormant (bool value)
      {
        //## begin database::Database::setDormant%3CA33EAD0128.set preserve=no
        m_bDormant = value;
        //## end database::Database::setDormant%3CA33EAD0128.set
      }


      //## Attribute: Name%369B776C03AA
      //	The dbName
      const reusable::string& getName () const
      {
        //## begin database::Database::getName%369B776C03AA.get preserve=no
        return m_strName;
        //## end database::Database::getName%369B776C03AA.get
      }


      //## Attribute: Transaction%34F48E8D008F
      //	The serial number of the current unit of work.
      const int transaction () const
      {
        //## begin database::Database::transaction%34F48E8D008F.get preserve=no
        return m_nTransaction;
        //## end database::Database::transaction%34F48E8D008F.get
      }


      //## Attribute: TransactionState%34F48D1B03B8
      //	The state of the current unit of work.
      const Database::workState transactionState () const
      {
        //## begin database::Database::transactionState%34F48D1B03B8.get preserve=no
        return m_nTransactionState;
        //## end database::Database::transactionState%34F48D1B03B8.get
      }


    // Additional Public Declarations
      //## begin database::Database%3452433401B8.public preserve=yes
	  string getErrorCode()
	  {
		  return m_strErrorCode;
	  }

	  void setErrorCode(string str)
	  {
		  if (str == "DBERROR")
		  {
			  if (m_strErrorCode.empty())
				  m_strErrorCode = str;
		  }
		  else
			  m_strErrorCode = str;
	  }
      //## end database::Database%3452433401B8.public
  protected:
    // Data Members for Class Attributes

      //## Attribute: CommonQualifier%374D7132018E
      //	The common qualifier of this database.
      //## begin database::Database::CommonQualifier%374D7132018E.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strCommonQualifier;
      //## end database::Database::CommonQualifier%374D7132018E.attr

      //## begin database::Database::Disconnect%3CA39A36033C.attr preserve=no  public: bool {V} false
      bool m_bDisconnect;
      //## end database::Database::Disconnect%3CA39A36033C.attr

      //## begin database::Database::Dormant%3CA33EAD0128.attr preserve=no  public: bool {V} true
      bool m_bDormant;
      //## end database::Database::Dormant%3CA33EAD0128.attr

      //## begin database::Database::Name%369B776C03AA.attr preserve=no  public: reusable::string {U} 
      reusable::string m_strName;
      //## end database::Database::Name%369B776C03AA.attr

      //## Attribute: Qualifier%34F48A7D027E
      //	The owner of this database.
      //## begin database::Database::Qualifier%34F48A7D027E.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strQualifier;
      //## end database::Database::Qualifier%34F48A7D027E.attr

      //## Attribute: State%347B35610065
      //	The current state of the database.
      //## begin database::Database::State%347B35610065.attr preserve=no  public: Database::databaseState {U} 
      Database::databaseState m_nState;
      //## end database::Database::State%347B35610065.attr

      //## begin database::Database::Transaction%34F48E8D008F.attr preserve=no  public: int {V} 0
      int m_nTransaction;
      //## end database::Database::Transaction%34F48E8D008F.attr

    // Additional Protected Declarations
      //## begin database::Database%3452433401B8.protected preserve=yes
	  string m_strErrorCode;
      //## end database::Database%3452433401B8.protected
  private:
    // Additional Private Declarations
      //## begin database::Database%3452433401B8.private preserve=yes
      //## end database::Database%3452433401B8.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5C0591F900B5
      //## begin database::Database::Instance%5C0591F900B5.attr preserve=no  private: static Database* {V} 0
      static Database* m_pInstance;
      //## end database::Database::Instance%5C0591F900B5.attr

      //## begin database::Database::TransactionState%34F48D1B03B8.attr preserve=no  public: Database::workState {V} 
      Database::workState m_nTransactionState;
      //## end database::Database::TransactionState%34F48D1B03B8.attr

    // Data Members for Associations

    // Additional Implementation Declarations
      //## begin database::Database%3452433401B8.implementation preserve=yes
      //## end database::Database%3452433401B8.implementation

};

//## begin database::Database%3452433401B8.postscript preserve=yes
//## end database::Database%3452433401B8.postscript

} // namespace database

//## begin module%366E8F5302EA.epilog preserve=yes
using namespace database;
//## end module%366E8F5302EA.epilog


#endif
