//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4AFD732E02EE.cm preserve=no
//	$Date:   Jan 18 2010 15:20:28  $ $Author:   D92186  $ $Revision:   1.2  $
//## end module%4AFD732E02EE.cm

//## begin module%4AFD732E02EE.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%4AFD732E02EE.cp

//## Module: CXOSDB38%4AFD732E02EE; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB38.hpp

#ifndef CXOSDB38_h
#define CXOSDB38_h 1

//## begin module%4AFD732E02EE.additionalIncludes preserve=no
//## end module%4AFD732E02EE.additionalIncludes

//## begin module%4AFD732E02EE.includes preserve=yes
//## end module%4AFD732E02EE.includes

#ifndef CXOSDB37_h
#include "CXODDB37.hpp"
#endif

//## Modelname: Connex Library::SecurityWrapper_CAT (SWDLL)%4A09A922013D
namespace securitywrapper {
class SecurityWrapper;

} // namespace securitywrapper

//## begin module%4AFD732E02EE.declarations preserve=no
//## end module%4AFD732E02EE.declarations

//## begin module%4AFD732E02EE.additionalDeclarations preserve=yes
//## end module%4AFD732E02EE.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::TransportKey%4AFD72DF00A8.preface preserve=yes
//## end database::TransportKey%4AFD72DF00A8.preface

//## Class: TransportKey%4AFD72DF00A8
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4AFD8BBA0291;securitywrapper::SecurityWrapper { -> F}

class DllExport TransportKey : public DESKey  //## Inherits: <unnamed>%4AFD72FB0240
{
  //## begin database::TransportKey%4AFD72DF00A8.initialDeclarations preserve=yes
  //## end database::TransportKey%4AFD72DF00A8.initialDeclarations

  public:
    //## Constructors (generated)
      TransportKey();

    //## Destructor (generated)
      virtual ~TransportKey();


    //## Other Operations (specified)
      //## Operation: decrypt%4AFD73D70272
      virtual bool decrypt (string& strText);

      //## Operation: encrypt%4AFD73D7027C
      virtual bool encrypt (string& strText);

    // Additional Public Declarations
      //## begin database::TransportKey%4AFD72DF00A8.public preserve=yes
      //## end database::TransportKey%4AFD72DF00A8.public

  protected:
    // Additional Protected Declarations
      //## begin database::TransportKey%4AFD72DF00A8.protected preserve=yes
      //## end database::TransportKey%4AFD72DF00A8.protected

  private:
    // Additional Private Declarations
      //## begin database::TransportKey%4AFD72DF00A8.private preserve=yes
      //## end database::TransportKey%4AFD72DF00A8.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::TransportKey%4AFD72DF00A8.implementation preserve=yes
      //## end database::TransportKey%4AFD72DF00A8.implementation

};

//## begin database::TransportKey%4AFD72DF00A8.postscript preserve=yes
//## end database::TransportKey%4AFD72DF00A8.postscript

} // namespace database

//## begin module%4AFD732E02EE.epilog preserve=yes
//## end module%4AFD732E02EE.epilog


#endif
