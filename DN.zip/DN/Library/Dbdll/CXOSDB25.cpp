//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41D9BB610157.cm preserve=no
//## end module%41D9BB610157.cm

//## begin module%41D9BB610157.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%41D9BB610157.cp

//## Module: CXOSDB25%41D9BB610157; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB25.cpp

//## begin module%41D9BB610157.additionalIncludes preserve=no
//## end module%41D9BB610157.additionalIncludes

//## begin module%41D9BB610157.includes preserve=yes
#define STS_DUPLICATE_RECORD 35
#define PRIMARY_KEY_DUPLICATE 1
#define UNIQUE_KEY_DUPLICATE 2

struct OutputRDW
{
   short int RDW1;
   short int RDW2;
};

//## end module%41D9BB610157.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDB08_h
#include "CXODDB08.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSRU28_h
#include "CXODRU28.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSDB56_h
#include "CXODDB56.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF44_h
#include "CXODIF44.hpp"
#endif
#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB26_h
#include "CXODDB26.hpp"
#endif
#ifndef CXOSRU20_h
#include "CXODRU20.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif


//## begin module%41D9BB610157.declarations preserve=no
//## end module%41D9BB610157.declarations

//## begin module%41D9BB610157.additionalDeclarations preserve=yes
//## end module%41D9BB610157.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::ExportFile 

//## begin database::ExportFile::DATA_BUFFER%41E8323C008C.attr preserve=no  public: static char* {V} 0
char* ExportFile::m_pDATA_BUFFER = 0;
//## end database::ExportFile::DATA_BUFFER%41E8323C008C.attr

//## begin database::ExportFile::BufferSize%62A1B9B201EF.attr preserve=no  private: static size_t {V} 0
size_t ExportFile::m_lBufferSize = 0;
//## end database::ExportFile::BufferSize%62A1B9B201EF.attr

ExportFile::ExportFile()
  //## begin ExportFile::ExportFile%41D9B9BD0251_const.hasinit preserve=no
      : m_iDX_REPORT_ID(-1),
        m_bEmptyReport(false),
        m_iEXPORT_RETRY_COUNT(0),
        m_iNull(0),
        m_iSEQ_NO(-1),
        m_bSwitchClock(true),
        m_pInsertStatement(0),
        m_pFileFactory(0),
        m_pUpdateStatement(0),
        m_pRow(0)
  //## end ExportFile::ExportFile%41D9B9BD0251_const.hasinit
  //## begin ExportFile::ExportFile%41D9B9BD0251_const.initialization preserve=yes
  //## end ExportFile::ExportFile%41D9B9BD0251_const.initialization
{
  //## begin database::ExportFile::ExportFile%41D9B9BD0251_const.body preserve=yes
   memcpy(m_sID,"DB25",4);
   if (!m_pDATA_BUFFER)
   {
      m_pDATA_BUFFER = new char[DATA_BUFFER];
      m_lBufferSize = DATA_BUFFER;
   }
   m_iDX_FILE_ID[0] = -1;
   m_iDX_FILE_ID[1] = -1;
  //## end database::ExportFile::ExportFile%41D9B9BD0251_const.body
}

ExportFile::ExportFile(const ExportFile &right)
  //## begin ExportFile::ExportFile%41D9B9BD0251_copy.hasinit preserve=no
  //## end ExportFile::ExportFile%41D9B9BD0251_copy.hasinit
  //## begin ExportFile::ExportFile%41D9B9BD0251_copy.initialization preserve=yes
   : Observer(right)
  //## end ExportFile::ExportFile%41D9B9BD0251_copy.initialization
{
  //## begin database::ExportFile::ExportFile%41D9B9BD0251_copy.body preserve=yes
   m_iEXPORT_RETRY_COUNT = 0;
   m_iNull = 0;
   m_pInsertStatement = 0;
   m_pFileFactory = 0;
   m_pUpdateStatement = 0;
   m_pRow = 0;
   m_strDATE_RECON = right.getDATE_RECON();
   m_iDX_FILE_ID[0] = right.getDX_FILE_ID(0);
   m_iDX_FILE_ID[1] = right.getDX_FILE_ID(1);
   m_strDX_FILE_TYPE = right.getDX_FILE_TYPE();
   m_strDX_STATE = right.getDX_STATE();
   m_strENTITY_ID = right.getENTITY_ID();
   m_strENTITY_TYPE = right.getENTITY_TYPE();
   m_strROUTING_DATA =  right.getROUTING_DATA();
   m_strROUTING_PASSWORD =  right.getROUTING_PASSWORD();
   m_strROUTING_TYPE =  right.getROUTING_TYPE();
   m_strROUTING_USER_ID =  right.getROUTING_USER_ID();
   m_strSCHED_TIME = right.getSCHED_TIME();
   m_iSEQ_NO = right.getSEQ_NO();
   m_strTSTAMP_FORMATTED = right.getTSTAMP_FORMATTED();
   m_strTSTAMP_INITIATED = right.getTSTAMP_INITIATED();
   m_iDX_REPORT_ID = right.getDX_REPORT_ID();
   m_bSwitchClock = right.m_bSwitchClock;
   string strName("DX_DATA_",8);
   strName += m_strDATE_RECON;
   m_hTable.setName(strName);
   m_hTable.set("DX_FILE_ID",m_iDX_FILE_ID[0],true);
  //## end database::ExportFile::ExportFile%41D9B9BD0251_copy.body
}

ExportFile::ExportFile (const string& strDX_FILE_TYPE, const string& strENTITY_TYPE, const string& strENTITY_ID, const string& strDATE_RECON, const string& strSCHED_TIME)
  //## begin database::ExportFile::ExportFile%43D4E7A0037A.hasinit preserve=no
      : m_iDX_REPORT_ID(-1),
        m_bEmptyReport(false),
        m_iEXPORT_RETRY_COUNT(0),
        m_iNull(0),
        m_iSEQ_NO(-1),
        m_bSwitchClock(true),
        m_pInsertStatement(0),
        m_pFileFactory(0),
        m_pUpdateStatement(0),
        m_pRow(0)
  //## end database::ExportFile::ExportFile%43D4E7A0037A.hasinit
  //## begin database::ExportFile::ExportFile%43D4E7A0037A.initialization preserve=yes
   ,m_strDX_FILE_TYPE(strDX_FILE_TYPE)
   ,m_strENTITY_TYPE(strENTITY_TYPE)
   ,m_strENTITY_ID(strENTITY_ID)
   ,m_strDATE_RECON(strDATE_RECON)
   ,m_strSCHED_TIME(strSCHED_TIME)
  //## end database::ExportFile::ExportFile%43D4E7A0037A.initialization
{
  //## begin database::ExportFile::ExportFile%43D4E7A0037A.body preserve=yes
   memcpy(m_sID,"DB25",4);
   if (!m_pDATA_BUFFER)
   {
      m_pDATA_BUFFER = new char[DATA_BUFFER];
      m_lBufferSize = DATA_BUFFER;
   }
   m_iDX_FILE_ID[0] = -1;
   m_iDX_FILE_ID[1] = -1;
  //## end database::ExportFile::ExportFile%43D4E7A0037A.body
}


ExportFile::~ExportFile()
{
  //## begin database::ExportFile::~ExportFile%41D9B9BD0251_dest.body preserve=yes
   delete m_pUpdateStatement;
   delete m_pInsertStatement;
  //## end database::ExportFile::~ExportFile%41D9B9BD0251_dest.body
}


ExportFile & ExportFile::operator=(const ExportFile &right)
{
  //## begin database::ExportFile::operator=%41D9B9BD0251_assign.body preserve=yes
   m_strDATE_RECON = right.getDATE_RECON();
   m_iDX_FILE_ID[0] = right.getDX_FILE_ID(0);
   m_iDX_FILE_ID[1] = right.getDX_FILE_ID(1);
   m_strDX_FILE_TYPE =  right.getDX_FILE_TYPE();
   m_strDX_STATE = right.getDX_STATE();
   m_strENTITY_ID =  right.getENTITY_ID();
   m_strENTITY_TYPE =  right.getENTITY_TYPE();
   m_strORDER_BY =  right.getORDER_BY();
   m_strSCHED_TIME = right.getSCHED_TIME();
   m_iSEQ_NO = right.getSEQ_NO();
   m_strTSTAMP_FORMATTED = right.getTSTAMP_FORMATTED();
   m_strTSTAMP_INITIATED = right.getTSTAMP_INITIATED();
   m_iDX_REPORT_ID = right.getDX_REPORT_ID();
   m_strDX_REPORT_STAT = right.getDX_REPORT_STAT();
   m_strROUTING_DATA = right.getROUTING_DATA();
   m_strROUTING_PASSWORD = right.getROUTING_PASSWORD();
   m_strROUTING_TYPE = right.getROUTING_TYPE();
   m_strROUTING_USER_ID = right.getROUTING_USER_ID();
   m_bSwitchClock = right.m_bSwitchClock;
   string strName("DX_DATA_",8);
   strName += m_strDATE_RECON;
   m_hTable.setName(strName);
   m_hTable.set("DX_FILE_ID",m_iDX_FILE_ID[0],true);
   return *this;
  //## end database::ExportFile::operator=%41D9B9BD0251_assign.body
}


bool ExportFile::operator==(const ExportFile &right) const
{
  //## begin database::ExportFile::operator==%41D9B9BD0251_eq.body preserve=yes
   return (m_strDX_FILE_TYPE == right.getDX_FILE_TYPE()
      && m_iDX_REPORT_ID == right.getDX_REPORT_ID());
  //## end database::ExportFile::operator==%41D9B9BD0251_eq.body
}

bool ExportFile::operator!=(const ExportFile &right) const
{
  //## begin database::ExportFile::operator!=%41D9B9BD0251_neq.body preserve=yes
   return (m_strDX_FILE_TYPE != right.getDX_FILE_TYPE()
      || m_iDX_REPORT_ID != right.getDX_REPORT_ID());
  //## end database::ExportFile::operator!=%41D9B9BD0251_neq.body
}



//## Other Operations (implementation)
bool ExportFile::append ()
{
  //## begin database::ExportFile::append%43BFED2500DA.body preserve=yes
   int iRows = 0;
   Query hQuery;
   hQuery.setQualifier(Extract::instance()->getCustomerQualifier().c_str(),"DX_DATA_CONTROL");
   hQuery.bind("DX_DATA_CONTROL","DX_FILE_ID",Column::LONG,&m_iDX_FILE_ID[0]);
   hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","=",m_strDX_FILE_TYPE.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL","ENTITY_TYPE","=",m_strENTITY_TYPE.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL","ENTITY_ID","=",m_strENTITY_ID.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL","DATE_RECON","=",m_strDATE_RECON.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL","SCHED_TIME","=",m_strSCHED_TIME.c_str());
   if (m_iDX_REPORT_ID != -1)
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_REPORT_ID","=",m_iDX_REPORT_ID);
   {
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
         return false;
      iRows = pSelectStatement->getRows();
   }
   m_strDX_STATE = "FI";
   if (iRows == 0)
      if (!trigger())
         return false;
   string strName("DX_DATA_",8);
   strName += m_strDATE_RECON;
   m_hTable.setName(strName);
   m_hTable.setQualifier(Extract::instance()->getCustomerQualifier());
   m_strTSTAMP_INITIATED = Clock::instance()->getYYYYMMDDHHMMSSHN();
   m_hTable.set("DX_FILE_ID",m_iDX_FILE_ID[0],true);
   return true;
  //## end database::ExportFile::append%43BFED2500DA.body
}

void ExportFile::bind (reusable::Query& hQuery)
{
  //## begin database::ExportFile::bind%41E93CE20119.body preserve=yes
   m_iSEQ_NO = -1;
   hQuery.setQualifier(Extract::instance()->getCustomerQualifier().c_str(),"DX_DATA_CONTROL");
   hQuery.bind("DX_DATA_CONTROL","DX_FILE_ID",Column::LONG,&m_iDX_FILE_ID[0]);
   hQuery.bind("DX_DATA_CONTROL","DATE_RECON",Column::STRING,&m_strDATE_RECON);
   hQuery.bind("DX_DATA_CONTROL","SCHED_TIME",Column::STRING,&m_strSCHED_TIME);
   hQuery.bind("DX_DATA_CONTROL","DX_FILE_TYPE",Column::STRING,&m_strDX_FILE_TYPE);
   hQuery.bind("DX_DATA_CONTROL","DX_STATE",Column::STRING,&m_strDX_STATE);
   hQuery.bind("DX_DATA_CONTROL","ENTITY_ID",Column::STRING,&m_strENTITY_ID);
   hQuery.bind("DX_DATA_CONTROL","ENTITY_TYPE",Column::STRING,&m_strENTITY_TYPE);
   hQuery.bind("DX_DATA_CONTROL","ORDER_BY",Column::STRING,&m_strORDER_BY);
   hQuery.bind("DX_DATA_CONTROL","TSTAMP_FORMATTED",Column::STRING,&m_strTSTAMP_FORMATTED);
   hQuery.bind("DX_DATA_CONTROL","TSTAMP_INITIATED",Column::STRING,&m_strTSTAMP_INITIATED);
   hQuery.bind("DX_DATA_CONTROL","EXPORT_RETRY_COUNT",Column::LONG,&m_iEXPORT_RETRY_COUNT);
   hQuery.bind("DX_DATA_CONTROL","ROUTING_TYPE",Column::STRING,&m_strROUTING_TYPE);
   hQuery.bind("DX_DATA_CONTROL","ROUTING_USER_ID",Column::STRING,&m_strROUTING_USER_ID);
   hQuery.bind("DX_DATA_CONTROL","ROUTING_PASSWORD",Column::STRING,&m_strROUTING_PASSWORD);
   hQuery.bind("DX_DATA_CONTROL","ROUTING_DATA",Column::STRING,&m_strROUTING_DATA);
   hQuery.bind("DX_DATA_CONTROL","DX_REPORT_ID",Column::LONG,&m_iDX_REPORT_ID,&m_iNull);
   hQuery.bind("DX_DATA_CONTROL","DX_REPORT_STAT",Column::STRING,&m_strDX_REPORT_STAT);
  //## end database::ExportFile::bind%41E93CE20119.body
}

void ExportFile::bind2 (reusable::Query& hQuery)
{
  //## begin database::ExportFile::bind2%4230C6A7003E.body preserve=yes
   hQuery.setQualifier("QUALIFY","DX_FILE_TYPE");
   hQuery.setQualifier("QUALIFY","DX_INST_DEST");
   hQuery.join("DX_FILE_TYPE","INNER","DX_INST_DEST","DX_FILE_GROUP");
   hQuery.join("DX_FILE_TYPE","INNER","DX_INST_DEST","DX_FILE_GROUP_STAT");
   hQuery.bind("DX_INST_DEST","INST_ID",Column::STRING,&m_strDX_INST_ID);
   hQuery.bind("DX_INST_DEST","ROUTING_DATA",Column::STRING,&m_strROUTING_DATA);
   hQuery.bind("DX_INST_DEST","ROUTING_PASSWORD",Column::STRING,&m_strROUTING_PASSWORD);
   hQuery.bind("DX_INST_DEST","ROUTING_TYPE",Column::STRING,&m_strROUTING_TYPE);
   hQuery.bind("DX_INST_DEST","ROUTING_USER_ID",Column::STRING,&m_strROUTING_USER_ID);
   hQuery.bind("DX_FILE_TYPE","DX_FILE_TYPE",Column::STRING,&m_strDX_FILE_TYPE);
   hQuery.bind("DX_FILE_TYPE","SCHED_FREQUENCY",Column::STRING,&m_strSCHED_FREQUENCY);
   hQuery.bind("DX_FILE_TYPE","SCHED_OFFSET_TIME",Column::STRING,&m_strSCHED_OFFSET_TIME);
   hQuery.bind("DX_FILE_TYPE","DX_REPORT_ID",Column::LONG,&m_iDX_REPORT_ID,&m_iNull);
   hQuery.bind("DX_FILE_TYPE","DX_REPORT_STAT",Column::LONG,&m_strDX_REPORT_STAT);
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.setBasicPredicate("DX_INST_DEST","CUST_ID","=",strCUST_ID.c_str());
   hQuery.setBasicPredicate("DX_INST_DEST","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("DX_INST_DEST","CC_STATE","=","A");
  //## end database::ExportFile::bind2%4230C6A7003E.body
}

bool ExportFile::close ()
{
  //## begin database::ExportFile::close%42064EB6003E.body preserve=yes
   bool b = false;
   string strYYYYMMDDHHMMSSHN = (m_bSwitchClock) ? SwitchClock::instance()->getYYYYMMDDHHMMSSHN() : Clock::instance()->getYYYYMMDDHHMMSSHN();
   if ((m_strDX_STATE == "PI"
      && m_strTSTAMP_FORMATTED <= strYYYYMMDDHHMMSSHN)
      || (m_strDX_STATE == "FI"))
   {
      b = updateProgress(m_iDX_FILE_ID[0],"DW",m_strTSTAMP_FORMATTED);
      if (b)
         m_strDX_STATE = "DW";
   }
   return b;
  //## end database::ExportFile::close%42064EB6003E.body
}

bool ExportFile::complete ()
{
  //## begin database::ExportFile::complete%41EC5FFE02DE.body preserve=yes
   return updateProgress(m_iDX_FILE_ID[0],"DW",Clock::instance()->getYYYYMMDDHHMMSSHN());
  //## end database::ExportFile::complete%41EC5FFE02DE.body
}

bool ExportFile::create ()
{
  //## begin database::ExportFile::create%41E948B10399.body preserve=yes
   m_iSEQ_NO++;
   m_hTable.set("DATA_BUFFER",m_pDATA_BUFFER);
   m_hTable.set("DX_FILE_ID",m_iDX_FILE_ID[0],true);
   m_hTable.set("SEQ_NO",m_iSEQ_NO,true);
   char szALT_REC_KEY[11];
   snprintf(szALT_REC_KEY,sizeof(szALT_REC_KEY),"%010d",m_iSEQ_NO);
   m_hTable.set("ALT_REC_KEY",string(szALT_REC_KEY,10));
   if (!m_pInsertStatement)
      m_pInsertStatement = (Statement*)DatabaseFactory::instance()->create("InsertStatement");
   return m_pInsertStatement->execute(m_hTable);
  //## end database::ExportFile::create%41E948B10399.body
}

bool ExportFile::distribute (string& strDATA_BUFFER, IF::FlatFile& hFlatFile)
{
  //## begin database::ExportFile::distribute%457571790326.body preserve=yes
   int iLength = strDATA_BUFFER.length();
   KeyRing::instance()->unmask(iLength,(char*)strDATA_BUFFER.data());
   strDATA_BUFFER.resize(iLength);
   return hFlatFile.write((char*)strDATA_BUFFER.data(),iLength);
  //## end database::ExportFile::distribute%457571790326.body
}

bool ExportFile::email ()
{
  //## begin database::ExportFile::email%476734670157.body preserve=yes
   return false;
  //## end database::ExportFile::email%476734670157.body
}

bool ExportFile::erase ()
{
  //## begin database::ExportFile::erase%45C036110326.body preserve=yes
   if (m_iDX_FILE_ID[0] == -1)
      return true;
   string strTableName("DX_DATA_",8);
   strTableName += m_strDATE_RECON;
   Query hQuery;
   hQuery.setQualifier(Extract::instance()->getCustomerQualifier().c_str(),strTableName.c_str());
   hQuery.setBasicPredicate(strTableName.c_str(),"DX_FILE_ID","=",m_iDX_FILE_ID[0]);
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   return (pDeleteStatement->execute(hQuery));
  //## end database::ExportFile::erase%45C036110326.body
}

bool ExportFile::finish (IF::FlatFile& hFlatFile)
{
  //## begin database::ExportFile::finish%5C486F8901E1.body preserve=yes
   return true;
  //## end database::ExportFile::finish%5C486F8901E1.body
}

int ExportFile::getCount ()
{
  //## begin database::ExportFile::getCount%45390EEC0251.body preserve=yes
   if (m_hTable.getName().empty()
      && append() == false)
      return 0;
   database::Array::commit();
   int iCount(0);
   Query hQuery;
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.setQualifier(Extract::instance()->getCustomerQualifier().c_str(),m_hTable.getName().c_str());
   short iNull = -1;
   hQuery.bind(m_hTable.getName().c_str(),"SEQ_NO",Column::LONG,&iCount,&iNull,"MAX");
   hQuery.setBasicPredicate(m_hTable.getName().c_str(),"DX_FILE_ID","=",m_iDX_FILE_ID[0]);
   hQuery.setBasicPredicate(m_hTable.getName().c_str(),"SEQ_NO","<",2000000000);
   if (!pSelectStatement->execute(hQuery))
      return 0;
   if (iNull == -1)
      return 0;
   if (iCount < 101)
      return 0;
   if (iCount <= 1000000000)
      return iCount-100;
   int iCount2(0);
   Query hQuery1;
   hQuery1.setQualifier(Extract::instance()->getCustomerQualifier().c_str(),m_hTable.getName().c_str());
   hQuery1.bind(m_hTable.getName().c_str(),"SEQ_NO",Column::LONG,&iCount2,&iNull,"MAX");
   hQuery1.setBasicPredicate(m_hTable.getName().c_str(),"DX_FILE_ID","=",m_iDX_FILE_ID[0]);
   hQuery1.setBasicPredicate(m_hTable.getName().c_str(),"SEQ_NO","<",1000000001);
   if (!pSelectStatement->execute(hQuery1))
      return 0;
   if (iNull == -1
      || iCount2 < 101)
      return iCount - 1000000000;
   return (iCount2-100) + (iCount - 1000000000);
  //## end database::ExportFile::getCount%45390EEC0251.body
}

int ExportFile::getDX_FILE_ID (int iIndex) const
{
  //## begin database::ExportFile::getDX_FILE_ID%61157FA40088.body preserve=yes
   return m_iDX_FILE_ID[iIndex];
  //## end database::ExportFile::getDX_FILE_ID%61157FA40088.body
}

bool ExportFile::getPrevious (Query& hQuery, database::ExportFile& hPrevious, int iDays, const char* pszDX_FILE_TYPE)
{
  //## begin database::ExportFile::getPrevious%6115817002A5.body preserve=yes
   Date hDate(m_strDATE_RECON.c_str());
   hDate -= iDays;
   hQuery.reset();
   hQuery.attach(this);
   hPrevious.bind(hQuery);
   if (pszDX_FILE_TYPE)
      hQuery.setBasicPredicate("DX_DATA_CONTROL", "DX_FILE_TYPE", "=", pszDX_FILE_TYPE);
   else
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","=",m_strDX_FILE_TYPE.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL", "DX_REPORT_ID", "=", m_iDX_REPORT_ID);
   hQuery.setBasicPredicate("DX_DATA_CONTROL", "SCHED_TIME", "=", m_strSCHED_TIME.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL", "ENTITY_ID", "=", m_strENTITY_ID.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL", "ENTITY_TYPE", "=", m_strENTITY_TYPE.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL", "DATE_RECON", "<", m_strDATE_RECON.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL", "DATE_RECON", ">=", hDate.asString("%Y%m%d").c_str());
   hQuery.setOrderByClause("DATE_RECON DESC");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   return (pSelectStatement->execute(hQuery));
  //## end database::ExportFile::getPrevious%6115817002A5.body
}

bool ExportFile::import ()
{
  //## begin database::ExportFile::import%453FA39001A5.body preserve=yes
   m_pRow = new Row();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery;
   hQuery.attach(this);
   string strName("DX_DATA_",8);
   strName += m_strDATE_RECON;
   hQuery.setQualifier(Extract::instance()->getCustomerQualifier().c_str(),strName.c_str());
   hQuery.bind(strName.c_str(),"DATA_BUFFER",Column::STRING,&m_pRow->getBuffer());
   hQuery.setBasicPredicate(strName.c_str(),"DX_FILE_ID","=",m_iDX_FILE_ID[0]);
   hQuery.setOrderByClause("SEQ_NO");
   bool b = pSelectStatement->execute(hQuery);
   delete m_pRow;
   m_pRow = 0;
   return b;
  //## end database::ExportFile::import%453FA39001A5.body
}

void ExportFile::import (const string& strDATA_BUFFER)
{
  //## begin database::ExportFile::import%4767CBC600AB.body preserve=yes
  //## end database::ExportFile::import%4767CBC600AB.body
}

bool ExportFile::initialize ()
{
  //## begin database::ExportFile::initialize%4517F24901E3.body preserve=yes
   return false;
  //## end database::ExportFile::initialize%4517F24901E3.body
}

bool ExportFile::initiate ()
{
  //## begin database::ExportFile::initiate%41EC5F21038A.body preserve=yes
   if (!updateProgress(m_iDX_FILE_ID[0],"FI",Clock::instance()->getYYYYMMDDHHMMSSHN()))
   {
      Database::instance()->rollback();
      return UseCase::setSuccess(false);
   }
   Database::instance()->commit();
   return true;
  //## end database::ExportFile::initiate%41EC5F21038A.body
}

bool ExportFile::insert (const char* psDATA_BUFFER, int iDATA_BUFFER, int iSEQ_NO, bool bUpdate, bool bTruncate)
{
  //## begin database::ExportFile::insert%4BB226160251.body preserve=yes
   if (m_iDX_FILE_ID[0] == -1
      && append() == false)
      return false;
   m_hTable.set("DATA_BUFFER",iDATA_BUFFER,psDATA_BUFFER,false,false,bTruncate);
   if (iSEQ_NO == -1)
   {
      if (m_iSEQ_NO == -1)
      {
         string strName("DX_DATA_",8);
         strName += m_strDATE_RECON;
         m_hTable.setName(strName);
         m_hTable.setQualifier(Extract::instance()->getCustomerQualifier());
         m_hTable.set("DX_FILE_ID",m_iDX_FILE_ID[0],true);
         Query hQuery;
         auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
         hQuery.setQualifier(Extract::instance()->getCustomerQualifier().c_str(),m_hTable.getName().c_str());
         short iNull = -1;
         hQuery.bind(m_hTable.getName().c_str(),"SEQ_NO",Column::LONG,&m_iSEQ_NO,&iNull,"MAX");
         hQuery.setBasicPredicate(m_hTable.getName().c_str(),"DX_FILE_ID","=",m_iDX_FILE_ID[0]);
         hQuery.setBasicPredicate(m_hTable.getName().c_str(),"SEQ_NO","<",2000000000);
         if (!pSelectStatement->execute(hQuery))
            return false;
         if (iNull == -1)
            m_iSEQ_NO = 100;
      }
      iSEQ_NO = ++m_iSEQ_NO;
   }
   if (m_strALT_REC_KEY.length() == 0)
   {
      char szALT_REC_KEY[11];
      snprintf(szALT_REC_KEY,sizeof(szALT_REC_KEY),"%010d",iSEQ_NO);
      m_strALT_REC_KEY.assign(szALT_REC_KEY,10);
   }
   m_hTable.set("ALT_REC_KEY",m_strALT_REC_KEY);
   // If its Replay try to update first
   if (bUpdate)
   {
      string strName("DX_DATA_",8);
      strName += m_strDATE_RECON;
      SearchCondition hSearchCondition;
      hSearchCondition.setBasicPredicate(strName.c_str(),"ALT_REC_KEY","=",m_strALT_REC_KEY.c_str());
      m_strALT_REC_KEY = "";
      hSearchCondition.setBasicPredicate(strName.c_str(),"DX_FILE_ID","=",m_iDX_FILE_ID[0]);
      if (!m_pUpdateStatement)
         m_pUpdateStatement = (Statement*)DatabaseFactory::instance()->create("UpdateStatement");
      if (m_pUpdateStatement->execute(m_hTable,hSearchCondition.getText()))
         return true;
   }
   else
      m_strALT_REC_KEY.erase();
   m_hTable.set("SEQ_NO",iSEQ_NO,true);
   if (!m_pInsertStatement)
      m_pInsertStatement = (Statement*)DatabaseFactory::instance()->create("InsertStatement");
   return m_pInsertStatement->execute(m_hTable);
  //## end database::ExportFile::insert%4BB226160251.body
}

bool ExportFile::isPresent ()
{
  //## begin database::ExportFile::isPresent%45ABE5D90399.body preserve=yes
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery;
   hQuery.setQualifier(Extract::instance()->getCustomerQualifier().c_str(),"DX_DATA_CONTROL");
   hQuery.bind("DX_DATA_CONTROL","DX_FILE_ID",Column::LONG,&m_iDX_FILE_ID[0]);
   hQuery.bind("DX_DATA_CONTROL", "DX_STATE", Column::STRING, &m_strDX_STATE);
   hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","=",m_strDX_FILE_TYPE.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL","ENTITY_TYPE","=",m_strENTITY_TYPE.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL","ENTITY_ID","=",m_strENTITY_ID.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL","DATE_RECON","=",m_strDATE_RECON.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL","SCHED_TIME","=",m_strSCHED_TIME.c_str());
   if (m_iDX_REPORT_ID != -1)
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_REPORT_ID","=",m_iDX_REPORT_ID);

   if (!pSelectStatement->execute(hQuery))
      return false;
   if (pSelectStatement->getRows() == 0)
      return false;
   return true;
  //## end database::ExportFile::isPresent%45ABE5D90399.body
}

bool ExportFile::isPresent2 ()
{
  //## begin database::ExportFile::isPresent2%6115815A02DA.body preserve=yes
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery;
   hQuery.setQualifier(Extract::instance()->getCustomerQualifier().c_str(),"DX_DATA_CONTROL");
   hQuery.bind("DX_DATA_CONTROL","DX_FILE_ID",Column::LONG,&m_iDX_FILE_ID[0]);
   hQuery.bind("DX_DATA_CONTROL","DX_STATE",Column::STRING,&m_strDX_STATE);
   hQuery.bind("DX_DATA_CONTROL","DX_REPORT_ID",Column::LONG,&m_iDX_REPORT_ID);
   hQuery.bind("DX_DATA_CONTROL","DX_REPORT_STAT",Column::STRING,&m_strDX_REPORT_STAT);
   hQuery.bind("DX_DATA_CONTROL","DATE_RECON",Column::STRING,&m_strDATE_RECON);
   hQuery.bind("DX_DATA_CONTROL","SCHED_TIME",Column::STRING,&m_strSCHED_TIME);
   hQuery.bind("DX_DATA_CONTROL","TSTAMP_INITIATED",Column::STRING,&m_strTSTAMP_INITIATED);
   hQuery.bind("DX_DATA_CONTROL","TASK_FORMATTED",Column::STRING,&m_strTASK_FORMATTED);
   hQuery.bind("DX_DATA_CONTROL","TSTAMP_FORMATTED",Column::STRING,&m_strTSTAMP_FORMATTED);
   hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","=",m_strDX_FILE_TYPE.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL","ENTITY_TYPE","=",m_strENTITY_TYPE.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL","ENTITY_ID","=",m_strENTITY_ID.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_STATE","NOT IN","('DW','DC')");
   hQuery.setOrderByClause("DX_DATA_CONTROL.DX_FILE_ID ASC");
   if (!pSelectStatement->execute(hQuery))
      return false;
   if (pSelectStatement->getRows() == 0)
      return false;
   return true;
  //## end database::ExportFile::isPresent2%6115815A02DA.body
}

int ExportFile::key () const
{
  //## begin database::ExportFile::key%47FE36CD03B3.body preserve=yes
   const char* ptr = m_strKey.c_str();
   int lHashVal = 0;
   while (*ptr)
      lHashVal = (lHashVal<<5) + lHashVal + *ptr++;
   if (lHashVal < 0)
      return -lHashVal;
   return lHashVal;
  //## end database::ExportFile::key%47FE36CD03B3.body
}

bool ExportFile::read (int iSEQ_NO, string& strDATA_BUFFER)
{
  //## begin database::ExportFile::read%43C6B2050167.body preserve=yes
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery;
   string strName("DX_DATA_",8);
   strName += m_strDATE_RECON;
   hQuery.setQualifier(Extract::instance()->getCustomerQualifier().c_str(),strName.c_str());
   hQuery.bind(strName.c_str(),"DATA_BUFFER",Column::STRING,&strDATA_BUFFER);
   hQuery.setBasicPredicate(strName.c_str(),"DX_FILE_ID","=",m_iDX_FILE_ID[0]);
   hQuery.setBasicPredicate(strName.c_str(),"SEQ_NO","=",iSEQ_NO);
   pSelectStatement->execute(hQuery);
   return (pSelectStatement->getRows() == 1);
  //## end database::ExportFile::read%43C6B2050167.body
}

bool ExportFile::replace (int iSEQ_NO, const string& strDATA_BUFFER)
{
  //## begin database::ExportFile::replace%43C6B22901D4.body preserve=yes
   if ((m_iDX_FILE_ID[0] == -1) && (!append()))
     return false;
   m_hTable.reset();
   string strName("DX_DATA_",8);
   strName += m_strDATE_RECON;
   m_hTable.setName(strName);
   m_hTable.setQualifier(Extract::instance()->getCustomerQualifier());
   m_hTable.set("DATA_BUFFER",strDATA_BUFFER);
   m_hTable.set("SEQ_NO",iSEQ_NO,true);
   m_hTable.set("DX_FILE_ID",m_iDX_FILE_ID[0],true);
   if (!m_pUpdateStatement)
      m_pUpdateStatement = (Statement*)DatabaseFactory::instance()->create("UpdateStatement");
   return m_pUpdateStatement->execute(m_hTable);
  //## end database::ExportFile::replace%43C6B22901D4.body
}

bool ExportFile::replicate (const string& strDATE_RECON, const string& strRole)
{
  //## begin database::ExportFile::replicate%41EEBD7B01E4.body preserve=yes
   return false;
  //## end database::ExportFile::replicate%41EEBD7B01E4.body
}

bool ExportFile::reschedule ()
{
  //## begin database::ExportFile::reschedule%492197310134.body preserve=yes
   Table hTable("DX_DATA_CONTROL");
   hTable.set("DX_FILE_ID",m_iDX_FILE_ID[0],true);
   if (m_strTSTAMP_INITIATED >= (m_strDATE_RECON + Extract::instance()->getCUTOFF_TIME()))
   {
      hTable.set("DX_STATE","DC");
      hTable.set("TSTAMP_DISTRIBUTED",m_strTSTAMP_FORMATTED);
   }
   else
   {
      IString strTemp(m_strTSTAMP_INITIATED.c_str());
      DateTime hDateTime;
      hDateTime.timeAdjust(strTemp,15);
      string strTSTAMP_INITIATED((char*)strTemp);
      hTable.set("TSTAMP_INITIATED",strTSTAMP_INITIATED);
      hTable.set("DX_STATE","FW");
   }
   hTable.set("TASK_FORMATTED",Extract::instance()->getName());
   hTable.set("TSTAMP_FORMATTED",m_strTSTAMP_FORMATTED);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   return pUpdateStatement->execute(hTable);
  //## end database::ExportFile::reschedule%492197310134.body
}

bool ExportFile::reschedule (const string& strDX_FILE_TYPE, const string& strDATE_RECON)
{
  //## begin database::ExportFile::reschedule%582CD6780004.body preserve=yes
   Table hTable("DX_DATA_CONTROL");
   hTable.set("DX_FILE_TYPE",strDX_FILE_TYPE,false,true);
   hTable.set("DATE_RECON",strDATE_RECON,false,true);
   hTable.set("DX_STATE","FW");
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   return pUpdateStatement->execute(hTable);
  //## end database::ExportFile::reschedule%582CD6780004.body
}

void ExportFile::reserveBuffer (size_t lBufferLength)
{
  //## begin database::ExportFile::reserveBuffer%62A1B8C1038E.body preserve=yes
   if (lBufferLength > m_lBufferSize)
   {
      delete []m_pDATA_BUFFER;
      m_pDATA_BUFFER = new char[lBufferLength];
      m_lBufferSize = lBufferLength;
   } 
  //## end database::ExportFile::reserveBuffer%62A1B8C1038E.body
}

void ExportFile::setDX_FILE_ID (int iDX_FILE_ID, int iIndex)
{
  //## begin database::ExportFile::setDX_FILE_ID%61157FC800DB.body preserve=yes
   m_iDX_FILE_ID[iIndex] = iDX_FILE_ID;
  //## end database::ExportFile::setDX_FILE_ID%61157FC800DB.body
}

void ExportFile::setKey (char* psValue, int iLength)
{
  //## begin database::ExportFile::setKey%47FE47AE0243.body preserve=yes
   m_strKey.assign(psValue,iLength);
  //## end database::ExportFile::setKey%47FE47AE0243.body
}

void ExportFile::setOrderByClause (reusable::Query& hQuery)
{
  //## begin database::ExportFile::setOrderByClause%4E84933900CC.body preserve=yes
   hQuery.setOrderByClause("SEQ_NO");
  //## end database::ExportFile::setOrderByClause%4E84933900CC.body
}

bool ExportFile::start (IF::FlatFile& hFlatFile)
{
  //## begin database::ExportFile::start%5C486F880131.body preserve=yes
   return true;
  //## end database::ExportFile::start%5C486F880131.body
}

bool ExportFile::submit (string& strDX_PATH)
{
  //## begin database::ExportFile::submit%6555E70A0248.body preserve=yes
   string strPath("PATH");
   SiteSpecification::instance()->add(strPath, strDX_PATH);
   string strFirst("ZERO");
   string strSecond("NO");
   SiteSpecification::instance()->add(strFirst, strSecond);
   string strDX_FILE_TYPE(getDX_FILE_TYPE());
   string strFolder("FOLDER1");
   string strFile("FILE");
   char* pszPath = new char[strDX_PATH.length() + 1];
   memcpy(pszPath, strDX_PATH.data(), strDX_PATH.length());
   pszPath[strDX_PATH.length()] = '\0';
   char* p = strtok(pszPath, "/\\");
   while (p)
   {
      string strSecond(p);
      SiteSpecification::instance()->add(strFolder, strSecond);
      SiteSpecification::instance()->add(strFile, strSecond);
      strFolder[6] = strFolder[6] + 1;
      p = strtok(0, "/\\");
   }
   delete[] pszPath;
   char szDX_FILE_ID[PERCENTD];
   snprintf(szDX_FILE_ID, sizeof(szDX_FILE_ID), "%d",getDX_FILE_ID());
   string strMember("##");
   if (getNull() != -1
      && (strDX_FILE_TYPE == "TXNACT" || strDX_FILE_TYPE == "EMSACT"))
   {
      char szReportID[PERCENTD];
      snprintf(szReportID, sizeof(szReportID), "%011d",getDX_REPORT_ID());
      strMember.append(szReportID + 5, 6);
   }
   else
      strMember += strDX_FILE_TYPE;
   string strDate;
   strDate = "D" + getDATE_RECON().substr(2, 6) + ".T" + getSCHED_TIME();
   string strZero("&ZERO.");
   SiteSpecification::instance()->substitute(strZero);
   if (strZero != "YES")
      strZero = "NO";
   string strRECON("D");
   strRECON.append(getDATE_RECON().data() + 2, 6);
#ifdef MVS
   string strApplicationName(Extract::instance()->getName());
   strApplicationName.trim();
   map<string, string, less<string> > hParameters;
   hParameters.insert(map<string, string, less<string> >::value_type("&FILEID ", string(szDX_FILE_ID)));
   hParameters.insert(map<string, string, less<string> >::value_type("&ENTITY ", getENTITY_ID().c_str()));
   hParameters.insert(map<string, string, less<string> >::value_type("&DATE   ", strDate));
   hParameters.insert(map<string, string, less<string> >::value_type("&DATA   ", getROUTING_DATA().c_str()));
   hParameters.insert(map<string, string, less<string> >::value_type("&USER   ", getROUTING_USER_ID().c_str()));
   hParameters.insert(map<string, string, less<string> >::value_type("&PASS   ", getROUTING_PASSWORD().c_str()));
   hParameters.insert(map<string, string, less<string> >::value_type("&ZERO   ", strZero));
   hParameters.insert(map<string, string, less<string> >::value_type("&RECON  ", strRECON));
   hParameters.insert(map<string, string, less<string> >::value_type("&TASKID ", strApplicationName));
   strDX_PATH.rtrim();
   hParameters.insert(map<string, string, less<string> >::value_type("&DSN    ", strDX_PATH));
   return Job::submit(strMember.c_str(), hParameters);
#endif
   return Job::submit(strMember.c_str(),
      "&FILEID ", szDX_FILE_ID,
      "&ENTITY ", getENTITY_ID().c_str(),
      "&DATE   ", strDate.c_str(),
      "&DATA   ", getROUTING_DATA().c_str(),
      "&USER   ", getROUTING_USER_ID().c_str(),
      "&PASS   ", getROUTING_PASSWORD().c_str(),
      "&ZERO   ", strZero.c_str(),
      "&RECON  ", strRECON.c_str());
  //## end database::ExportFile::submit%6555E70A0248.body
}

bool ExportFile::trigger ()
{
  //## begin database::ExportFile::trigger%41F6BBC1032C.body preserve=yes
   Query hQuery;
   short iNull = 0;
   hQuery.setQualifier(Extract::instance()->getCustomerQualifier().c_str(),"DX_DATA_CONTROL");
   hQuery.bind("DX_DATA_CONTROL","DX_FILE_ID",Column::LONG,&m_iDX_FILE_ID[0],&iNull,"MAX");
   if (1)   // reduce the number of select statements - 3 concurrent
   {
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
         return false;
   }
   int iLoopCount = 0; //safety valve
   while(iLoopCount < 1024)
   {
      Table hTable("DX_DATA_CONTROL");
      hTable.setQualifier(Extract::instance()->getCustomerQualifier());
      hTable.set("DX_FILE_ID",++m_iDX_FILE_ID[0],true);
      hTable.set("DX_STATE",m_strDX_STATE);
      hTable.set("DX_FILE_TYPE",m_strDX_FILE_TYPE);
      hTable.set("ENTITY_TYPE",m_strENTITY_TYPE);
      hTable.set("ENTITY_ID",m_strENTITY_ID);
      hTable.set("DATE_RECON",m_strDATE_RECON);
      hTable.set("SCHED_TIME",m_strSCHED_TIME);
      if (m_iDX_REPORT_ID == -1)
      {
         hTable.set("DX_REPORT_ID","~NULL!");
         hTable.set("DX_REPORT_STAT","~NULL!");
      }
      else
      {
         hTable.set("DX_REPORT_ID",m_iDX_REPORT_ID);
         hTable.set("DX_REPORT_STAT",m_strDX_REPORT_STAT);
      }
      string strTSTAMP_INITIATED;
      strTSTAMP_INITIATED = m_strTSTAMP_INITIATED;
      if (strTSTAMP_INITIATED.empty())
      {
         if (m_strSCHED_FREQUENCY == "D")
         {
            string strDate(Clock::instance()->getDate());
            string strTime(Clock::instance()->getTime().substr(0,6));
            Timestamp::adjust(strDate,strTime,(atoi(m_strSCHED_OFFSET_TIME.substr(0,2).c_str()) * 60) + atoi(m_strSCHED_OFFSET_TIME.substr(2,2).c_str()));
            strTSTAMP_INITIATED = strDate.substr(0,8);
            strTSTAMP_INITIATED += strTime;
            strTSTAMP_INITIATED += "00";
         }
         else
            strTSTAMP_INITIATED = Clock::instance()->getYYYYMMDDHHMMSSHN(true);
      }
      if (m_strSCHED_FREQUENCY == "R")
      {
         string strTime = strTSTAMP_INITIATED.substr(8,8);
         Date hDate(strTSTAMP_INITIATED.substr(0,8).c_str());
         hDate -= 1;
         strTSTAMP_INITIATED = hDate.asString("%Y%m%d");
         strTSTAMP_INITIATED += strTime;
      }
      hTable.set("TSTAMP_INITIATED",strTSTAMP_INITIATED);
      hTable.set("TASK_FORMATTED",m_strTASK_FORMATTED);
      hTable.set("TSTAMP_FORMATTED",m_strTSTAMP_FORMATTED);
      string strTemp;
      hTable.set("TASK_DISTRIBUTED",strTemp);
      hTable.set("TSTAMP_DISTRIBUTED",strTemp);
      hTable.set("TSTAMP_NEXT_EXPORT",strTemp);
      hTable.set("EXPORT_RETRY_COUNT",(int)0);
      hTable.set("ROUTING_DATA",m_strROUTING_DATA);
      hTable.set("ROUTING_TYPE",m_strROUTING_TYPE);
      hTable.set("ROUTING_USER_ID",m_strROUTING_USER_ID);
      hTable.set("ROUTING_PASSWORD",m_strROUTING_PASSWORD);
      hTable.set("ORDER_BY",m_strORDER_BY);
      if (!m_pInsertStatement)
         m_pInsertStatement = (Statement*)DatabaseFactory::instance()->create("InsertStatement");
      if (m_pInsertStatement->execute(hTable))
         return true;
      if (m_pInsertStatement->getInfoIDNumber() != STS_DUPLICATE_RECORD)
         break;
      if (m_pInsertStatement->getErrorType() != PRIMARY_KEY_DUPLICATE)
         break;
      ++iLoopCount;
   }
   m_iDX_FILE_ID[0] = -1;
   return (m_pInsertStatement->getInfoIDNumber() == STS_DUPLICATE_RECORD ? m_pInsertStatement->getErrorType() != PRIMARY_KEY_DUPLICATE : false);
  //## end database::ExportFile::trigger%41F6BBC1032C.body
}

bool ExportFile::unionAll (Query& hQuery)
{
  //## begin database::ExportFile::unionAll%6115817E0215.body preserve=yes
   return true;
  //## end database::ExportFile::unionAll%6115817E0215.body
}

void ExportFile::update (Subject* pSubject)
{
  //## begin database::ExportFile::update%41E8644F03A9.body preserve=yes
   if (pSubject != m_pRow) // i.e. callback from Query in ExportFile::import ... test for m_pRow to avoid loop
      update(m_pRow);
  //## end database::ExportFile::update%41E8644F03A9.body
}

bool ExportFile::updateProgress (int lDX_FILE_ID, const char* pszDX_STATE, string strTSTAMP_FORMATTED)
{
  //## begin database::ExportFile::updateProgress%41EC630600EA.body preserve=yes
   if (lDX_FILE_ID == -1)
      return true;
   Table hTable("DX_DATA_CONTROL");
   hTable.setQualifier(Extract::instance()->getCustomerQualifier());
   hTable.set("DX_FILE_ID",lDX_FILE_ID,true);
   string strDX_STATE(pszDX_STATE);
   hTable.set("DX_STATE",strDX_STATE);
   hTable.set("TASK_FORMATTED",Extract::instance()->getName());
   hTable.set("TSTAMP_FORMATTED",strTSTAMP_FORMATTED);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   return pUpdateStatement->execute(hTable);
  //## end database::ExportFile::updateProgress%41EC630600EA.body
}

bool ExportFile::write (int iDATA_BUFFER, int iSEQ_NO, bool bUpdate, bool bTruncate)
{
  //## begin database::ExportFile::write%41E825B20213.body preserve=yes
   for (int i = 0; i < iDATA_BUFFER; ++i)
      if (m_pDATA_BUFFER[i] < ' ')
         m_pDATA_BUFFER[i] = ' ';
   char* pDATA_BUFFER = m_pDATA_BUFFER;
   while (iDATA_BUFFER > 0)
   {
      if (!insert(pDATA_BUFFER, iDATA_BUFFER > 3800 ? 3800 : iDATA_BUFFER, iSEQ_NO, bUpdate,iDATA_BUFFER >= 3800 ? false : bTruncate))
         return false;
      pDATA_BUFFER += 3800;
      iDATA_BUFFER -= 3800;
      if (iDATA_BUFFER == 0)
         if (!insert("XZ",2,iSEQ_NO,bUpdate,bTruncate)) // will be ignored by FileDistributor::update
            return false;
   }
   return true;
  //## end database::ExportFile::write%41E825B20213.body
}

bool ExportFile::write (const char* psDATA_BUFFER, int iDATA_BUFFER, int iSEQ_NO)
{
  //## begin database::ExportFile::write%43D4E582033C.body preserve=yes
   if (iDATA_BUFFER > m_lBufferSize)
      reserveBuffer(iDATA_BUFFER);
   memcpy(m_pDATA_BUFFER,psDATA_BUFFER,iDATA_BUFFER);
   return write(iDATA_BUFFER,iSEQ_NO);
  //## end database::ExportFile::write%43D4E582033C.body
}

//## Get and Set Operations for Class Attributes (implementation)

char* ExportFile::getDATA_BUFFER ()
{
  //## begin database::ExportFile::getDATA_BUFFER%41E8323C008C.get preserve=no
  return m_pDATA_BUFFER;
  //## end database::ExportFile::getDATA_BUFFER%41E8323C008C.get
}

// Additional Declarations
  //## begin database::ExportFile%41D9B9BD0251.declarations preserve=yes
  //## end database::ExportFile%41D9B9BD0251.declarations

} // namespace database

//## begin module%41D9BB610157.epilog preserve=yes
//## end module%41D9BB610157.epilog
