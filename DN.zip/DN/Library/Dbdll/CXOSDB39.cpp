//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4B070B1A03A9.cm preserve=no
//	$Date:   Feb 22 2021 16:34:38  $ $Author:   e1009652  $ $Revision:   1.18  $
//## end module%4B070B1A03A9.cm

//## begin module%4B070B1A03A9.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4B070B1A03A9.cp

//## Module: CXOSDB39%4B070B1A03A9; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV03.1A.R011\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB39.cpp

//## begin module%4B070B1A03A9.additionalIncludes preserve=no
//## end module%4B070B1A03A9.additionalIncludes

//## begin module%4B070B1A03A9.includes preserve=yes
#include "CXODIF16.hpp"
#ifdef MVS           
#include "csfbext.h"
#endif               
#define AES_BLOCK_SIZE 16
//## end module%4B070B1A03A9.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDB39_h
#include "CXODDB39.hpp"
#endif


//## begin module%4B070B1A03A9.declarations preserve=no
//## end module%4B070B1A03A9.declarations

//## begin module%4B070B1A03A9.additionalDeclarations preserve=yes
//## end module%4B070B1A03A9.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::IBMKey 

IBMKey::IBMKey()
  //## begin IBMKey::IBMKey%4B070ADF01DC_const.hasinit preserve=no
  //## end IBMKey::IBMKey%4B070ADF01DC_const.hasinit
  //## begin IBMKey::IBMKey%4B070ADF01DC_const.initialization preserve=yes
  //## end IBMKey::IBMKey%4B070ADF01DC_const.initialization
{
  //## begin database::IBMKey::IBMKey%4B070ADF01DC_const.body preserve=yes
   memcpy(m_sID,"DB39",4);
   memset(m_szKeyToken,'\0',64);
  //## end database::IBMKey::IBMKey%4B070ADF01DC_const.body
}


IBMKey::~IBMKey()
{
  //## begin database::IBMKey::~IBMKey%4B070ADF01DC_dest.body preserve=yes
  //## end database::IBMKey::~IBMKey%4B070ADF01DC_dest.body
}



//## Other Operations (implementation)
bool IBMKey::addKey (const string& strKeyId, const string& strKey)
{
  //## begin database::IBMKey::addKey%4C45DF8F002E.body preserve=yes
   //format of strKeyId is DKxxxx where xxxx = check digits.
   if(strKeyId.length() != 6 || strKeyId.substr(0,2) != "DK")
      return false;
   setIdentifier(strKeyId);
   setCheckDigits(strKeyId.substr(2,4));
   Key::setKey(strKey); //by pass DES::setKey
   //format of data key label in ICSF is 
   //"DN.cccc.DATA.KEYxxxx" where cccc = cust id, xxxx = check digits
   string strCustId;
   Extract::instance()->getSpec("CUSTOMER",strCustId);
   string strLabel("DN.");
   strLabel.append(strCustId);
   strLabel.append(".DATA.KEY");  
   strLabel.append(getCheckDigits());
   setLabel(strLabel);
   if(!csnbCKM(m_strLabel)) //generate key to internal token 
      return false;
   int rc = csnbKRC(); //create key placeholder in ckds
   if(rc > 0)
   {
      if(rc == 100) //Key already created
         return true;
      return false;
   }
   return csnbKRW(); //update place holder with internal token
  //## end database::IBMKey::addKey%4C45DF8F002E.body
}

bool IBMKey::csnbCKM (const string& strKeyLabel)
{
  //## begin database::IBMKey::csnbCKM%4C45DF250128.body preserve=yes
   m_iReturnCode = 0;
   m_iReasonCode = 0;
   int iExitDataLength = 0;
   int iRuleArrayCount = 1;
   unsigned char sRuleArray[9] = "AES     ";
   int iCearKeyLength = 32;
   unsigned char sClearKey[32];
   memcpy(sClearKey,m_strKey.data(),m_strKey.length());
   int iKeyIdentifierLength = 64;
   unsigned char sExitData[64];
   memset(m_szKeyToken,' ',64); 
#ifdef MVS
   CSNBCKM( &m_iReturnCode,
            &m_iReasonCode,
            &iExitDataLength,
            sExitData,
            &iRuleArrayCount,
            sRuleArray,
            &iCearKeyLength,
            sClearKey,
            &iKeyIdentifierLength,
            (unsigned char*)m_szKeyToken );
#endif
   if (m_iReturnCode != 0 )
   { 
      char error_msg[100];
      Trace::put(error_msg,
         snprintf(error_msg,sizeof(error_msg),"CSNBCKM - Failed,rc = %d,reason = %d",
         m_iReturnCode,m_iReasonCode));
      return false;
   }
   return true;
  //## end database::IBMKey::csnbCKM%4C45DF250128.body
}

int IBMKey::csnbKRC ()
{
  //## begin database::IBMKey::csnbKRC%4B26895C01D6.body preserve=yes
   //Key Record Create
   if(m_strLabel.length() > 64)
      return 8;
   char keyLabel[64];
   memset(keyLabel,' ',64);
   memcpy(keyLabel,m_strLabel.data(),m_strLabel.length());
   m_iReturnCode = 0;
   m_iReasonCode = 0;
   int iExitDataLength = 0;
   unsigned char sExitData[4] = {0};        
#ifdef MVS
   CSNBKRC( &m_iReturnCode, 
            &m_iReasonCode, 
            &iExitDataLength, 
            sExitData, 
            (unsigned char*)keyLabel);
#endif
   if (m_iReturnCode != 0 )                                             
   { 
      if(m_iReturnCode == 8 && m_iReasonCode == 16036)
         return 100; //key already created
      char error_msg[100];                                   
      Trace::put(error_msg,
         snprintf(error_msg,sizeof(error_msg),"CNSBKRC - failed,rc = %d,reason = %d",
         m_iReturnCode,m_iReasonCode));   
      return m_iReturnCode;
   }
   return 0;
  //## end database::IBMKey::csnbKRC%4B26895C01D6.body
}

bool IBMKey::csnbKRD (const string& strKeyLabel)
{
  //## begin database::IBMKey::csnbKRD%4C45E8190053.body preserve=yes
   m_iReturnCode = 0;                 
   m_iReasonCode = 0;                 
   int iExitDataLength = 0;     
   int iRuleArrayCount = 1;
   unsigned char sRuleArray[8];
   memcpy(sRuleArray,"LABEL-DL",8);       
   unsigned char sExitData[4] = {0};     
   unsigned char sKeyIdentifier[64];                                        
   memset((char*)sKeyIdentifier,' ',64);    
   memcpy((char*)sKeyIdentifier,strKeyLabel.data(),strKeyLabel.length());
#ifdef MVS                                                                
   CSNBKRD( &m_iReturnCode, 
            &m_iReasonCode, 
            &iExitDataLength, 
            sExitData, 
            &iRuleArrayCount, 
            sRuleArray, 
            sKeyIdentifier);
#endif
   if(m_iReturnCode != 0)
   {
      if(m_iReturnCode == 8 && m_iReasonCode == 10012)
         return true; //key doesn't exist   
      char error_msg[100];                                   
      Trace::put(error_msg,
         snprintf(error_msg,sizeof(error_msg),"CSNBKRD - failed,rc = %d,reason = %d",
         m_iReturnCode,m_iReasonCode));   
      return false;
   }
   return true;
  //## end database::IBMKey::csnbKRD%4C45E8190053.body
}

bool IBMKey::csnbKRW ()
{
  //## begin database::IBMKey::csnbKRW%4B2689800222.body preserve=yes

  //Key Record Write
   if(m_strLabel.length() == 0 || m_strLabel.length() > 64)
      return false;
   char keyLabel[64];
   memset(keyLabel,' ',64);
   memcpy(keyLabel,m_strLabel.data(),m_strLabel.length());
   m_iReturnCode = 0;
   m_iReasonCode = 0;
   int iExitDataLength = 0;
   unsigned char sExitData[4] = {0};        
#ifdef MVS
   CSNBKRW( &m_iReturnCode, 
            &m_iReasonCode, 
            &iExitDataLength, 
            sExitData, 
            (unsigned char*)m_szKeyToken, 
            (unsigned char*)keyLabel);
#endif
   if(m_iReturnCode != 0)
   {
      char error_msg[100];                                   
      Trace::put(error_msg,
         snprintf(error_msg,sizeof(error_msg),"CNSBKRW - failed,rc = %d,reason = %d",
         m_iReturnCode,m_iReasonCode));   
      return false;
   }
   return true;
  //## end database::IBMKey::csnbKRW%4B2689800222.body
}

bool IBMKey::decrypt (string& strText)
{
  //## begin database::IBMKey::decrypt%4B070B9503A7.body preserve=yes
   //Decrypt using AES using CipherTokenStealing (CTS)
   //if length of cipher is not a multiple of AES_BLOCK_SIZE then
   //the part of the last block contains data has already been decrypted once
   //example:  24 byte cipher [cX...L.z...7...6.MmB._.6]  <== decrypt 16 bytes
   //                1st call [45431826Dxm._Zo6] <== 2nd have still decrypted
   //                2nd call         [Dxm._Zo6.MmB._.6] 
   int iCipherLength = strText.length();
   unsigned char* pCipherText = new unsigned char[iCipherLength + 1];
   memcpy(pCipherText,strText.data(),strText.length());
   pCipherText[iCipherLength] = '\0';
   unsigned char* pClearText = new unsigned char[iCipherLength + 1];
   memset(pClearText,' ',iCipherLength);
   pClearText[iCipherLength] = '\0';
   int iRemainder = iCipherLength % AES_BLOCK_SIZE;
   bool bReturnCode = true;
   if (iRemainder != 0)
   {
      // decrypt in multiple of 16 bytes
      //IBM Connex always provides a 24 byte for cipher
      bReturnCode = decryptAES(pCipherText,AES_BLOCK_SIZE,pClearText);
      if (bReturnCode)
      {
         //move 2nd 8 bytes from cleartext to start of ciphertext
         memcpy(pCipherText,pClearText + 8,8);
         //shift last 8 bytes forward by 8 bytes
         memcpy(pCipherText + 8,pCipherText + 16,8);
         //clear last 8 bytes
         memset(pCipherText + 16,' ',8);
         // decrypt 16 bytes putting results 8 bytes into pClearText 
         bReturnCode = decryptAES(pCipherText,AES_BLOCK_SIZE,pClearText + 8);
      };
   }
   else
      bReturnCode = decryptAES(pCipherText,iCipherLength,pClearText);
   if (bReturnCode)
   {
      strText.assign((char*)pClearText,iCipherLength);
      strText.trim();
      strText.resize(24,' ');
   }
   delete[] pCipherText;
   delete[] pClearText;
   return bReturnCode;
  //## end database::IBMKey::decrypt%4B070B9503A7.body
}

bool IBMKey::decryptAES (unsigned char* pCipherText, int iCipherLength, unsigned char* pClearText)
{
  //## begin database::IBMKey::decryptAES%6033CC8700CF.body preserve=yes
   int return_code = 0;
   int reason_code = 0;
   int exit_data_length = 0;
   unsigned char exit_data[5] = { 0 };
   int rule_array_count = 4;
   unsigned char rule_array[33] = "AES     CBC     KEYIDENTINITIAL ";;
   int key_identifier_length = 64;
   unsigned char key_identifier[137] = { 0 };
   memset(key_identifier,' ',136);
   memcpy(key_identifier,m_strLabel.data(),m_strLabel.length());
   int key_parms_length = 0;
   unsigned char key_parms[1] = { 0 };
   int block_size = AES_BLOCK_SIZE;
   int initialization_vector_length = AES_BLOCK_SIZE;
   unsigned char initialization_vector[17] = { 0 };
   int chain_data_length = 32;
   unsigned char* chain_data = new unsigned char[33];
   memset(chain_data,'\0',33);
   int cipher_text_length = iCipherLength;
   unsigned char* cipher_text = pCipherText;
   int clear_text_length = 32;
   unsigned char* clear_text = pClearText;
   int optional_data_length = 0;
   unsigned char optional_data[1] = { 0 };

#ifdef MVS
   CSNBSAD(
      &return_code,
      &reason_code,                  //output
      &exit_data_length,              //this field is ignored
      exit_data,                     //this field is ignored
      &rule_array_count,              //must be 2,3 or 4
      rule_array,                    //multiple of 8
      &key_identifier_length,         //input
      key_identifier,                //label of key
      &key_parms_length,              //ignored
      key_parms,                     //ignored
      &block_size,                    //AES requires 16
      &initialization_vector_length,  //must be same as block_size
      initialization_vector,         //initialized to binary zeros
      &chain_data_length,            //In=len buffer, out= len returned
      chain_data,
      &cipher_text_length,            //input
      cipher_text,
      &clear_text_length,            //In=len buffer, out= len returned
      clear_text,
      &optional_data_length,          //must be 0
      optional_data);
#endif

   bool bReturnCode = (return_code == 0) ? true : false;
   if (!bReturnCode)
   {
      char error_msg[100];
      Trace::put(error_msg,
         sprintf(error_msg,"Decrypt failed, rc = %d, reason = %d",
            return_code,reason_code));
      Trace::put(m_strIdentifier.data(),m_strIdentifier.length());
      Trace::put(m_strLabel.data(),m_strLabel.length());
   }
   delete[] chain_data;
   return bReturnCode;
  //## end database::IBMKey::decryptAES%6033CC8700CF.body
}

bool IBMKey::deleteKey (const string& strKeyId)
{
  //## begin database::IBMKey::deleteKey%4C45E87F0101.body preserve=yes
   if(strKeyId.length() != 6 || strKeyId.substr(0,2) != "DK")
      return false;
   //format of data key label in ICSF is 
   //"DN.cccc.DATA.KEYxxxx" where cccc = cust id, xxxx = check digits
   string strCustId;
   Extract::instance()->getSpec("CUSTOMER",strCustId);
   string strKeyLabel("DN.");              //data key id
   strKeyLabel.append(strCustId);
   strKeyLabel.append(".DATA.KEY");  
   strKeyLabel.append(strKeyId.substr(2,4));
   return csnbKRD(strKeyLabel); //delete key
  //## end database::IBMKey::deleteKey%4C45E87F0101.body
}

bool IBMKey::encrypt (string& strText)
{
  //## begin database::IBMKey::encrypt%4B070B9503BB.body preserve=yes
   m_iReturnCode = 0;
   m_iReasonCode = 0;
   int iExitDataLength = 0;                               
   unsigned char sExitData[4] = {0};                      
   unsigned char sDataKeyId[64];
   memset((char*)sDataKeyId,' ',64);
   memset(sDataKeyId,' ',64);    
   memcpy(sDataKeyId,m_strLabel.data(),m_strLabel.length());
   int iTextLen = strText.length(); 
   int iNewLen = ((iTextLen%8)) ? iTextLen+(8-(iTextLen%8)) : iTextLen;
   unsigned char* pCipherText = new_unsigned_char(iNewLen,1);
   memset(pCipherText,'\0',iNewLen+1);
   unsigned char* pClearText = new_unsigned_char(iTextLen,1);
   memset(pClearText,'\0',iTextLen+1);
   memcpy(pClearText,strText.data(),strText.length());
   unsigned char sICV[8] = {0};                           
   int iRuleArrayCount = 1;                               
   unsigned char sCipherProcessRule[8] = "CBC    "; //"CUSP   "      
   unsigned char sOCV[18] = {0};                          
   int padChar = 0x00;
#ifdef MVS
   CSNBENC(&m_iReturnCode,
           &m_iReasonCode,
           &iExitDataLength,                              
           sExitData,                                     
           sDataKeyId,                                                 
           &iNewLen,                                                  
           pClearText,
           sICV,                                                       
           &iRuleArrayCount,                                           
           sCipherProcessRule,                                         
           &padChar,
           sOCV,                                                       
           pCipherText); 
#endif
     if (m_iReturnCode != 0 )                                             
     { 
        delete [] pClearText;
        delete [] pCipherText;
        char error_msg[100];                                   
        Trace::put(error_msg,
           snprintf(error_msg,sizeof(error_msg),"Encrypt failed,rc = %d,reason = %d",
           m_iReturnCode,m_iReasonCode));
        Trace::put(m_strIdentifier.data(),m_strIdentifier.length());
        Trace::put(m_strLabel.data(),m_strLabel.length());
        return false;
     }
     strText.assign((char*)pCipherText,iNewLen);
     delete [] pClearText;
     delete [] pCipherText;
     return true;
  //## end database::IBMKey::encrypt%4B070B9503BB.body
}

// Additional Declarations
  //## begin database::IBMKey%4B070ADF01DC.declarations preserve=yes
  //## end database::IBMKey%4B070ADF01DC.declarations
} // namespace database

//## begin module%4B070B1A03A9.epilog preserve=yes
//## end module%4B070B1A03A9.epilog
