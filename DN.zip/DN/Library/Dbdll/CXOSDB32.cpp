//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4974904600B9.cm preserve=no
//	$Date:   Jun 09 2021 08:56:06  $ $Author:   e1009652  $ $Revision:   1.68  $
//## end module%4974904600B9.cm

//## begin module%4974904600B9.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4974904600B9.cp

//## Module: CXOSDB32%4974904600B9; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.5C.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXOSDB32.cpp

//## begin module%4974904600B9.additionalIncludes preserve=no
//## end module%4974904600B9.additionalIncludes

//## begin module%4974904600B9.includes preserve=yes
//#include <openssl/pem.h>
//#include <openssl/err.h>
//#include <openssl/rsa.h>
//#include <openssl/aes.h>
//#include <openssl/crypto.h>
#include <stack>
#include <algorithm>
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#include "CXODIF16.hpp"
#include "CXODDB37.hpp"
#include "CXODIF05.hpp"
#include <algorithm>
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif

//## end module%4974904600B9.includes

#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDB34_h
#include "CXODDB34.hpp"
#endif
#ifndef CXOSDB33_h
#include "CXODDB33.hpp"
#endif
#ifndef CXOSRU41_h
#include "CXODRU41.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif
#ifndef CXOSDB38_h
#include "CXODDB38.hpp"
#endif
#ifndef CXOSDB39_h
#include "CXODDB39.hpp"
#endif
#ifndef CXOSIF37_h
#include "CXODIF37.hpp"
#endif
#ifndef CXOSDB32_h
#include "CXODDB32.hpp"
#endif


//## begin module%4974904600B9.declarations preserve=no
//## end module%4974904600B9.declarations

//## begin module%4974904600B9.additionalDeclarations preserve=yes
#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
#ifndef CXOSRU37_h
#include "CXODRU37.hpp"
#endif
#ifndef CXOSIF48_h
#include "CXODIF48.hpp"
#endif
#define STS_RECORD_NOT_FOUND 14
static unsigned int kRand = 0;
#define RANDOM(n) (SecurityWrapper::RAND_bytes((unsigned char*)&kRand,4) ? kRand%n : 0)


//## end module%4974904600B9.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::AESKeyManager 

AESKeyManager::AESKeyManager()
  //## begin AESKeyManager::AESKeyManager%49748F87033F_const.hasinit preserve=no
      : m_pCertificate(0),
        m_lCount(0),
        m_pPrivateKey(0),
        m_pPublicKey(0)
  //## end AESKeyManager::AESKeyManager%49748F87033F_const.hasinit
  //## begin AESKeyManager::AESKeyManager%49748F87033F_const.initialization preserve=yes
  //## end AESKeyManager::AESKeyManager%49748F87033F_const.initialization
{
  //## begin database::AESKeyManager::AESKeyManager%49748F87033F_const.body preserve=yes
   memcpy_s(m_sID,4,"DB32",4);
   m_pPrivateKey = SecurityWrapper::EVP_PKEY_new();
   m_pCertificate = SecurityWrapper::X509_new();
   memset(m_szKeyGenerator,' ',64);
   m_szKeyGenerator[64] = '\0';
  //## end database::AESKeyManager::AESKeyManager%49748F87033F_const.body
}


AESKeyManager::~AESKeyManager()
{
  //## begin database::AESKeyManager::~AESKeyManager%49748F87033F_dest.body preserve=yes
   SecurityWrapper::EVP_PKEY_free(m_pPrivateKey);
   SecurityWrapper::X509_free(m_pCertificate);
  //## end database::AESKeyManager::~AESKeyManager%49748F87033F_dest.body
}



//## Other Operations (implementation)
bool AESKeyManager::ageKeys (const string& strYYYYMM)
{
  //## begin database::AESKeyManager::ageKeys%49F5E3D00374.body preserve=yes
/* don't delete keys
   if(!getActive())
      return true;
   Date hDate(Date::today());
   hDate.incrementMonth(-1*12);
   if(hDate.asString("%Y%m") < strYYYYMM)
      return false;  //don't delete keys unless at least 1 years old
   string strCurrentTokenKey;
   Query hQuery;
   hQuery.setQualifier("QUALIFY","DN_SYMBOLS");
   hQuery.bind("DN_SYMBOLS","SYMBOL_ID",Column::STRING,&strCurrentTokenKey);
   hQuery.setBasicPredicate("DN_SYMBOLS","SEQ_NO","=",25);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if(!pSelectStatement->execute(hQuery) || pSelectStatement->getRows() == 0)
      return true;
   if(nYYJJJ(strCurrentTokenKey) <= nYYJJJ(strYYYYMM))
      return true;  //do not delete key currently being used to encrypt tokens
   m_strYYYYMM = strYYYYMM;
   obfuscate("198001",m_strCONTEXT_KEY[1]);
   hQuery.reset();
   hQuery.setIndex(8);
   hQuery.attach(this);
   hQuery.bind("TASK_CONTEXT","CONTEXT_KEY",Column::STRING,&m_strCONTEXT_KEY[0]);
   hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA[0]);
   hQuery.setBasicPredicate("TASK_CONTEXT","IMAGEID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","K");
   if(!pSelectStatement->execute(hQuery))
   {
      Database::instance()->rollback();
      return false;
   }
*/
   return true;
  //## end database::AESKeyManager::ageKeys%49F5E3D00374.body
}

bool AESKeyManager::backup ()
{
  //## begin database::AESKeyManager::backup%4977315401D5.body preserve=yes
   if(!KeyRing::instance()->getInitialized() ||
       KeyRing::instance()->getInitializedFromBackups())
      return true;  //don't backup if initialization failed or used backups
   map<string,Key*,less<string> >* pKeys = KeyRing::instance()->getKeys();
   if(pKeys->size() == 0)
      return false;  //nothing to backup
   //initialize backup file
   m_hExportFile.setSEQ_NO(-1);
   string strYYYYMMDDHHMMSSHN(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   m_hExportFile.setDATE_RECON(strYYYYMMDDHHMMSSHN.substr(0,8));
   m_hExportFile.setDX_FILE_TYPE("BACKUP");
   m_hExportFile.setDX_STATE("DC");
   m_hExportFile.setENTITY_ID("PRC999");
   m_hExportFile.setENTITY_TYPE("*P");
   m_hExportFile.setSCHED_TIME(strYYYYMMDDHHMMSSHN.substr(8,6));
   m_hExportFile.setTSTAMP_INITIATED(strYYYYMMDDHHMMSSHN);
   if(!m_hExportFile.trigger()) //create DX_DATA_CONTROL entry
      return false;
   //backup keys
   map<string,Key*,less<string> >::iterator q;
   for(q = pKeys->begin(); q != pKeys->end(); q++)
   {
      if((*q).second->getIdentifier() == "Master")
         continue; //don't backup the master key (only the master seed)
      if(!(*q).second->validate())
         continue; //skip corrupted keys
      string strText = (*q).second->serialize();
      if(!m_hExportFile.write(strText.data(),strText.length()))
         return false;
   }
   //backup default data and transport designations
   char sBuffer[40];
   string strDefaultDataKey = KeyRing::instance()->getDefaultDataKey();
   if(strDefaultDataKey.length() > 0 && strDefaultDataKey.length() <= 6)
   {
      m_hExportFile.write(sBuffer,
         snprintf(sBuffer,sizeof(sBuffer),"DEFAULT_DATA_KEY                %s",strDefaultDataKey.c_str()));
   }
   string strDefaultAESDataKey = KeyRing::instance()->getDefaultAESDataKey();
   if(strDefaultAESDataKey.length() > 0 && strDefaultAESDataKey.length() <= 6)
   {
      m_hExportFile.write(sBuffer,
         snprintf(sBuffer,sizeof(sBuffer),"DEFAULT_AES_DATA_KEY            %s",strDefaultAESDataKey.c_str()));
   }
   string strDefaultTransportKey = KeyRing::instance()->getDefaultTransportKey();
   if(strDefaultTransportKey.length() > 0 && strDefaultTransportKey.length() <= 6)
   {
      m_hExportFile.write(sBuffer,
         snprintf(sBuffer,sizeof(sBuffer),"DEFAULT_TRANSPORT_KEY           %s",strDefaultTransportKey.c_str()));
   }
   if(!getActive())
      return true;
   //backup tokens
   Query hQuery;
   hQuery.setIndex(4);
   hQuery.attach(this);
   hQuery.setQualifier("QUALIFY","DN_SYMBOLS");
   hQuery.bind("DN_SYMBOLS","DN_SYMBOL",Column::STRING,&m_strTOKEN);
   hQuery.bind("DN_SYMBOLS","SYMBOL_ID",Column::STRING,&m_strDATE);
   hQuery.bind("DN_SYMBOLS","SEQ_NO",Column::LONG,&m_iSEQ_NO);
   hQuery.setBasicPredicate("DN_SYMBOLS","SEQ_NO","BETWEEN"," 1 AND 25 ");
   hQuery.setOrderByClause("SEQ_NO ASC");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if(!pSelectStatement->execute(hQuery))
      return false;
   return true;
  //## end database::AESKeyManager::backup%4977315401D5.body
}

bool AESKeyManager::begin ()
{
  //## begin database::AESKeyManager::begin%4A048113023D.body preserve=yes
   //validate environment does not already exist
   if(KeyRing::instance()->getActive())
   {
      //console message: environment exists, use recover instead
      IF::Trace::put("Warning! BEGIN command issued"
         "but system already initialized",-1,true);
      return false;
   }
   //validate FIN_L for start month is empty.
   string strBeginDate;
   if(!generateBeginDate(strBeginDate))
   {
      //console message: starting month must be empty
      IF::Trace::put("Error! Unable to find empty future month",-1,true);
      return false;
   }
   AESKey* pMasterKey = (AESKey*)KeyRing::instance()->getKey("Master");
   if(pMasterKey)
      m_hMasterKey[0] = *pMasterKey;
   else
   {
      //build the system from scratch
      string strSeed = generateKey2();
      constructMasterKeys(m_hMasterKey[0],m_hMasterSeed[0],strSeed);

      //store master seed in database
      Table hTable;
      if(!setColumns(hTable))
      {
         IF::Trace::put("AESKeyManger: Error-Unable to query context table",-1,true);
         Database::instance()->rollback();
         return false;
      }
      hTable.set("CONTEXT_KEY",m_hMasterSeed[0].getCONTEXT_KEY());
      hTable.set("CONTEXT_DATA",m_hMasterSeed[0].getCONTEXT_DATA());
      auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      if (pInsertStatement->execute(hTable) == false)
      {
         IF::Trace::put("AESKeyManger: Error-Unable to initialize Master Key",-1,true);
         Database::instance()->rollback();
         return false;
      }
   }
   //create monthly keys from today-4 to today+6
   Date hDateStart(Date::today().getYear(),Date::today().getMonth(),1);
   Date hDateEnd(hDateStart);
   hDateStart.incrementMonth(-4);
   hDateEnd.incrementMonth(6);
   while(hDateStart.asString("%Y%m") <= hDateEnd.asString("%Y%m"))
   {
      if(!createKey_1(hDateStart.asString("%Y%m"),&m_hMasterKey[0]))
      {
         Database::instance()->rollback();
         return false;
      }
      hDateStart.incrementMonth();
   }
   KeyRing::instance()->resetKeys();
   //create tokens using current monthly key
   Date hDate(Date::today());
   if(!createTokens(hDate.asString("%Y%m"),strBeginDate))
   {
      Database::instance()->rollback();
      return false;
   }
   //backup keys and tokens to DX_DATA_YYYYMMDD
   setActive(true);
   Mask::setTokensExist(true);
   KeyRing::instance()->reset(); //reload keys and tokens now that they both exist
   if(!backup())
   {
      Database::instance()->rollback();
      setActive(false);
      Mask::setTokensExist(false);
      return false;
   }
   Database::instance()->commit();
   return true;
  //## end database::AESKeyManager::begin%4A048113023D.body
}

bool AESKeyManager::bind (reusable::Query& hQuery,bool bCount,bool bCONTEXT_KEY,bool bCONTEXT_DATA)
{
  //## begin database::AESKeyManager::bind%5604159B007C.body preserve=yes
   int lCount = 0;
   Query hQuery1;
   hQuery1.bind("TASK_CONTEXT","*",reusable::Column::LONG,&lCount,0,"COUNT");
   hQuery1.setBasicPredicate("TASK_CONTEXT","IMAGEID","=","*");
   hQuery1.setBasicPredicate("TASK_CONTEXT","TASKID","=","*");
   hQuery1.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","K");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery1))
      return false;
   m_lCount = 0;
   if(lCount == 0)
   {  //use TASK_CONTEXT_COMN
      hQuery.setQualifier("QUALIFY","TASK_CONTEXT_COMN");
      if(bCount)
         hQuery.bind("TASK_CONTEXT_COMN","*",reusable::Column::LONG,&m_lCount,0,"COUNT");
      if(bCONTEXT_KEY)
         hQuery.bind("TASK_CONTEXT_COMN","CONTEXT_KEY",Column::STRING,&m_strCONTEXT_KEY[0]);
      if(bCONTEXT_DATA)
         hQuery.bind("TASK_CONTEXT_COMN","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA[0]);
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN","IMAGE_ID","=","*");
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN","TASK_ID","=","*");
      hQuery.setBasicPredicate("TASK_CONTEXT_COMN","CONTEXT_TYPE","=","K");
   }
   else
   {  //Use TASK_CONTEXT
      if(bCount)
         hQuery.bind("TASK_CONTEXT","*",reusable::Column::LONG,&m_lCount,0,"COUNT");
      if(bCONTEXT_KEY)
         hQuery.bind("TASK_CONTEXT","CONTEXT_KEY",Column::STRING,&m_strCONTEXT_KEY[0]);
      if(bCONTEXT_DATA)
         hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA[0]);
      hQuery.setBasicPredicate("TASK_CONTEXT","IMAGEID","=","*");
      hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=","*");
      hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","K");
   }
   return true;
  //## end database::AESKeyManager::bind%5604159B007C.body
}

bool AESKeyManager::end ()
{
  //## begin database::AESKeyManager::end%4A048113023E.body preserve=yes
   if(!checkEnvironment())
      return environmentWarning("END");
   string strEndDate;
   if(!generateEndDate(strEndDate))
   {
      IF::Trace::put("Error! unable to generate PADSS end date",-1,true);
      return false;
   }
   if(KeyRing::instance()->getEndDate() != "999999")
   {
      if(Clock::instance()->getYYYYMMDDHHMMSS().substr(0,6) >=
         KeyRing::instance()->getEndDate())
         return true; //nothing to do already stopped
      if(strEndDate >= KeyRing::instance()->getEndDate())
         return true; //nothing to do earliest possible end date already set
      if(Clock::instance()->getYYYYMMDDHHMMSS().substr(0,6) > strEndDate)
      {
         //error end date already exists and new date is invalid
         string strMsg("End command failed - PADSS end date already exists: ");
         strMsg.append(KeyRing::instance()->getEndDate());
         strMsg.append(" Invalid new end date: ");
         strMsg.append(strEndDate.data(),strEndDate.length());
         IF::Trace::put(strMsg.data(),strMsg.length(),true);
         return false;
      }
   }
   string strStartDate = KeyRing::instance()->getStartDate();
   if(strEndDate < strStartDate &&
      Clock::instance()->getYYYYMMDDHHMMSS().substr(0,6) > strEndDate)
      strStartDate = strEndDate;
   //select the control record from DN_SYMBOLS
   string strTOKEN;
   string strDATE;
   Query hQuery;
   hQuery.setQualifier("QUALIFY","DN_SYMBOLS");
   hQuery.bind("DN_SYMBOLS","DN_SYMBOL",Column::STRING,&strTOKEN);
   hQuery.bind("DN_SYMBOLS","SYMBOL_ID",Column::STRING,&strDATE);
   hQuery.setBasicPredicate("DN_SYMBOLS","SEQ_NO","=",25);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if(!pSelectStatement->execute(hQuery) || pSelectStatement->getRows() != 1)
   {
      IF::Trace::put("Error! PADSS control record not found",-1,true);
      return false;
   }
   //update the end date in 2nd half of control record
   if(strTOKEN.length() != (88*2))
   {
      IF::Trace::put("Error! PADSS control record invalid",-1,true);
      return false;
   }
   string strControlRecord(strTOKEN.data(),88); //save 1st 88 bytes
   strTOKEN.erase(0,88);
   strTOKEN.resize(86);
   strTOKEN.append("==");
   KeyRing::instance()->decrypt(strDATE,strTOKEN);
   memcpy_s((char*)strTOKEN.data(),strStartDate.length(),strStartDate.data(),strStartDate.length());
   memcpy_s((char*)strTOKEN.data()+6,strEndDate.length(),strEndDate.data(),strEndDate.length());
   KeyRing::instance()->encrypt(strDATE,strTOKEN);
   memcpy_s((char*)strTOKEN.data()+86,2,strTOKEN.data()+42,2);
   strControlRecord.append(strTOKEN.data(),strTOKEN.length());

   //update the control record
   Table hTable("DN_SYMBOLS");
   hTable.setQualifier("QUALIFY");
   hTable.set("SEQ_NO",(int)25,true);
   hTable.set("DN_SYMBOL",strControlRecord);
   hTable.set("SYMBOL_ID",strDATE);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if(!pUpdateStatement->execute(hTable))
   {
      IF::Trace::put("Error! PADSS update end date failed-1",-1,true);
      Database::instance()->rollback();
      return false;
   }
   if(!backup())
   {
      IF::Trace::put("Error! PADSS update end date failed-2",-1,true);
      Database::instance()->rollback();
      return false;
   }
   Database::instance()->commit();
   KeyRing::instance()->reset();
   return true;
  //## end database::AESKeyManager::end%4A048113023E.body
}

bool AESKeyManager::changeMasterKey ()
{
  //## begin database::AESKeyManager::changeMasterKey%4A0469C60254.body preserve=yes
   if(!checkEnvironment())
      return environmentWarning("Change Master Key");
   AESKey* pMasterKey = (AESKey*)KeyRing::instance()->getKey("Master");
   if(!pMasterKey)
   {
      //console message:
      IF::Trace::put("Error! Change Master Key command failed-1",-1,true);
      return false;
   }
   m_hMasterKey[0] = *pMasterKey;
   AESKey* pMasterSeed = (AESKey*)KeyRing::instance()->getKey("Master-Seed");
   if(!pMasterSeed)
   {
      //console message:
      IF::Trace::put("Error! Change Master Key command failed-2",-1,true);
      return false;
   }
   m_hMasterSeed[0] = *pMasterSeed;

   //construct new master key and new seed
   string strSeed = generateKey2();
   constructMasterKeys(m_hMasterKey[1],m_hMasterSeed[1],strSeed);

   //query all keys from task context, decrypt and re-encrypt, update
   Query hQuery(5);
   hQuery.attach(this);
   if(!bind(hQuery,false,true,true))
   {
      Database::instance()->rollback();
      IF::Trace::put("Error! Change Master Key command failed-3",-1,true);
      return false;
   }
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if(!pSelectStatement->execute(hQuery) || pSelectStatement->getRows() == 0 ||
      hQuery.getAbort() == true)
   {
      Database::instance()->rollback();
      IF::Trace::put("Error! Change Master Key command failed-4",-1,true);
      return false;
   }
   KeyRing::instance()->reset();
   if(!backup())
   {
      Database::instance()->rollback();
      IF::Trace::put("Error! Change Master Key command failed-5",-1,true);
      return false;
   }
   Database::instance()->commit();
   return true;
  //## end database::AESKeyManager::changeMasterKey%4A0469C60254.body
}

bool AESKeyManager::checkEnvironment ()
{
  //## begin database::AESKeyManager::checkEnvironment%501934120380.body preserve=yes
   if(!KeyRing::instance()->getActive())
      return true;
   if(KeyRing::instance()->getInitializedFromBackups())
      return false; //don't modify environment if there are already problems
   return true;
  //## end database::AESKeyManager::checkEnvironment%501934120380.body
}

bool AESKeyManager::checkKey (const string& strYYYYMM)
{
  //## begin database::AESKeyManager::checkKey%49762CF002EB.body preserve=yes
   if(!getActive())
      return false;
   if(!KeyRing::instance()->getKey(strYYYYMM))
      return false;
   return true;
  //## end database::AESKeyManager::checkKey%49762CF002EB.body
}

bool AESKeyManager::checkSSLEnvironment ()
{
  //## begin database::AESKeyManager::checkSSLEnvironment%553120BC01A5.body preserve=yes
   EVP_PKEY* pKey = SecurityWrapper::EVP_PKEY_new();
   X509* pX509 = SecurityWrapper::X509_new();
   PKCS12* p12 = 0;
   loadSSLEnvironment();
   bool b = loadSSLEnvironment((void**)&pKey,(void**)&pX509,(void**)&p12);
   SecurityWrapper::EVP_PKEY_free(pKey);
   SecurityWrapper::X509_free(pX509);
   SecurityWrapper::PKCS12_free(p12);
   return b;
  //## end database::AESKeyManager::checkSSLEnvironment%553120BC01A5.body
}

bool AESKeyManager::constructMasterKeys (database::AESKey& hMasterKey,database::AESKey& hMasterSeed,const string& strSeed)
{
  //## begin database::AESKeyManager::constructMasterKeys%49EF3441024C.body preserve=yes
   hMasterKey.reset();
   hMasterSeed.reset();
   //string strMasterSeed(strSeed.data(),strSeed.length());
   //strMasterSeed.append("KeyManager49831B6F0191F3C1E2D4A9");
   //hMasterSeed.generateDigest(strMasterSeed);
   hMasterSeed.setRawKey((char*)strSeed.data(),strSeed.length());
   string strSuffix = "C194E7B3434563222D1FAB4BACE39585";
   string strMasterKey = hMasterSeed.getKey() + strSuffix;
   AESKey::generateSHA512Digest(strMasterKey);
   hMasterKey.setRawKey((char*)strMasterKey.data(),strMasterKey.length());
   string strMasterLock = "FYX120b7Q2198442";
   hMasterSeed.encrypt(strMasterLock);
   string strCONTEXT_DATA(hMasterSeed.getKey());
   strCONTEXT_DATA.append(strMasterLock);
   strCONTEXT_DATA.erase(86); //remove pad charaters ("==")
   strCONTEXT_DATA.resize(100,' ');
   strCONTEXT_DATA[99] = '3';
   hMasterSeed.setCONTEXT_DATA(strCONTEXT_DATA);
   string strCONTEXT_KEY;
   obfuscate("198001",strCONTEXT_KEY);
   hMasterSeed.setCONTEXT_KEY(strCONTEXT_KEY);
   return true;
  //## end database::AESKeyManager::constructMasterKeys%49EF3441024C.body
}

bool AESKeyManager::createDataKey(const enum Key::KeyType keyType)

{
   //## begin database::AESKeyManager::createDataKey%5514396E011F.body preserve=yes
   //this method is used to create keys for encrypting files and EMS documents
   if (!checkEnvironment())
      return environmentWarning("Create Data Key");
   Key* pKey;
   char cKeyType = '3'; //new default is AES256_3 (DES is no longer valid option)
   if (keyType == Key::AES256)
      cKeyType = '2';
   pKey = new AESKey;
   pKey->setStrength(256);
   string strKeyId;
   string strKey;
   string strKeyHex;
   int iSafetyValve = 0;
   while (iSafetyValve++ < 20)
   {
      if (cKeyType == '3')
      {  //file encryption
         strKey.assign(generateKey2());
         pKey->setRawKey((char*)strKey.data(),strKey.length());
         strKeyHex.assign((char*)pKey->getRawKey());
      }
      else if (cKeyType == '2')
      {  //ems document encryption (and pass phrase encryption)
         char szTemp[3];
         string strTemp = generateKey2();
         strKeyHex.assign(strTemp.data(),16);
         for (int i = 0; i < 16; i++)
         {
            unsigned char c = strTemp.data()[i];
            strKey.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%02x",c));
         }
         pKey->setKey(strKey);
      }
      pKey->computeCheckDigits();
      strKeyId.assign("DK");
      strKeyId.append(pKey->getCheckDigits());
      if (!KeyRing::instance()->getKey(strKeyId))
         break; //no collisions so continue
      IF::Trace::put("createDataKey: collision",-1,true);
      IF::Trace::put(strKeyId.data(),strKeyId.length(),true);
   }
   delete pKey;
   if (iSafetyValve == 20)
      return false; //somethings wrong!
   //store key in TASK_CONTEXT with other keys
   //Data Keys use Id of DKxxxx where xxxx = Check Digits
   string strCONTEXT_DATA(strKeyId);
   strCONTEXT_DATA.append("==");
   strCONTEXT_DATA.append((char*)strKeyHex.data(),strKeyHex.length());
   strCONTEXT_DATA.append(",");
   strCONTEXT_DATA.append((char*)strKeyId.substr(2,4).data(),4);
   strCONTEXT_DATA.append(",");
   strCONTEXT_DATA.append(Clock::instance()->getYYYYMMDDHHMMSS().data(),8);
   Key* pMasterKey = KeyRing::instance()->getKey("Master");
   if (!pMasterKey)
   {
      //generate master key 1st time
      //first make sure environment not already there
      Query hQuery;
      if (!bind(hQuery,true,false,false))
      {
         IF::Trace::put("Key creation failed - "
            "Query of Context table failed",-1,true);
         return false;
      }
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery) || m_lCount > 0)
      {
         IF::Trace::put("Data Key creation failed - "
            "Master Key not found but key DB not empty",-1,true);
         return false;
      }
      if (!createMasterKey())
      {
         IF::Trace::put("Data Key creation failed - "
            "Unable to initialize Master Key",-1,true);
         return false;
      }
      pMasterKey = KeyRing::instance()->getKey("Master");
   }
   if (!pMasterKey)
   {
      IF::Trace::put("Data Key creation failed - "
         "Unable to initialize or create Master Key",-1,true);
      return false;
   }
   if (!pMasterKey->encrypt(strCONTEXT_DATA))
   {
      IF::Trace::put("Data Key creation failed - "
         "Unable to Encrypt with Master Key",-1,true);
      return false;
   }
   strCONTEXT_DATA.resize(100,' ');
   strCONTEXT_DATA[99] = cKeyType;
   string strCONTEXT_KEY;
   obfuscate(strKeyId,strCONTEXT_KEY);
   Table hTable;
   if (!setColumns(hTable))
   {
      IF::Trace::put("Data Key creation failed - "
         "Unable to query context table",-1,true);
      Database::instance()->rollback();
      return false;
   }
   hTable.set("CONTEXT_KEY",strCONTEXT_KEY);
   hTable.set("CONTEXT_DATA",strCONTEXT_DATA);
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   if (pInsertStatement->execute(hTable) == false)
   {
      IF::Trace::put("Data Key creation failed - "
         "Unable to insert new Key in Key DB",-1,true);
      Database::instance()->rollback();
      return false;
   }
   Database::instance()->commit();
   KeyRing::instance()->refreshKeys(); //pick up the new key
   if (KeyRing::instance()->getDefaultDataKey().length() == 0 && cKeyType == '3')
   {
      if (!setDefaultDataKey(strKeyId))
      {
         IF::Trace::put("createDataKey: Warning - unable to set DES Default Data Key!",-1,true);
         Database::instance()->rollback();
         return false;
      }
      Database::instance()->commit();
      KeyRing::instance()->refreshKeys(); //pick up the new Default designation
   }
   else if (KeyRing::instance()->getDefaultAESDataKey().length() == 0 && cKeyType == '2')
   {
      if (!setDefaultAESDataKey(strKeyId))
      {
         IF::Trace::put("createDataKey: Warning - unable to set AES Default Data Key!",-1,true);
         Database::instance()->rollback();
         return false;
      }
      Database::instance()->commit();
      KeyRing::instance()->refreshKeys(); //pick up the new Default designation
   }
   if (!backup())
   {
      IF::Trace::put("createDataKey: Warning - backup of keys failed!",-1,true);
      Database::instance()->rollback();
      return false;
   }
   Database::instance()->commit();
#ifdef MVS
#include "CXODDB39.hpp"
   //add key to ICSF if enabled 
   if(KeyRing::instance()->isICSF() && cKeyType == '3')
   {
      IBMKey hIBMKey;
      char sMsg[35];
      if(hIBMKey.addKey(strKeyId,strKeyHex))
         IF::Trace::put(sMsg,snprintf(sMsg,sizeof(sMsg),"%s successfully added to ICSF",strKeyId.c_str()),true);
      else
         IF::Trace::put(sMsg,snprintf(sMsg,sizeof(sMsg),"%s could not be added to ICSF",strKeyId.c_str()),true);
   }
#endif
   return true;
  //## end database::AESKeyManager::createDataKey%5514396E011F.body
}

bool AESKeyManager::createKey (const string& strYYYYMM)
{
  //## begin database::AESKeyManager::createKey%49749DE1012F.body preserve=yes
   //this method is used to create keys for encrypting tokens
   if(!getActive())
      return true;
   if(KeyRing::instance()->getKey(strYYYYMM))
      return true;
   Key* pMasterKey = KeyRing::instance()->getKey("Master");
   if(!pMasterKey)
      return false;
   if(!checkEnvironment())
      return environmentWarning("Create Key");
   if(strYYYYMM.length() != 6)
      return false;
   if(!createKey_1(strYYYYMM,pMasterKey))
      return false;
   KeyRing::instance()->reset(); //pickup new key
   backup(); //ensure full set is available in most recent daily backup
   Database::instance()->commit();
   return true;
  //## end database::AESKeyManager::createKey%49749DE1012F.body
}

bool AESKeyManager::createKey_1 (const string& strYYYYMM,reusable::Key* pMasterKey)
{
  //## begin database::AESKeyManager::createKey_1%4989B59F00B6.body preserve=yes
   //this method is used to create keys for encrypting tokens
   UseCase hUseCase("DR","## DR10 CREATE KEY");
   string strKey = generateKey2();
   AESKey hKey;
   hKey.setRawKey((char*)strKey.data(),strKey.length());
   string strCONTEXT_DATA(strYYYYMM);
   strCONTEXT_DATA.append("==");
   strCONTEXT_DATA.append(strKey); //32 bytes of binary data
   string strCryptogram(Key::getCryptoPhrase(),16);
   hKey.encrypt(strCryptogram);
   strCONTEXT_DATA.append(strCryptogram); //24 byte cryptogram
   if(!pMasterKey->encrypt(strCONTEXT_DATA))
      return UseCase::setSuccess(false);
   strCONTEXT_DATA.resize(100,' ');
   strCONTEXT_DATA[99] = '3'; //default is now 256 bit using actual 32 byte raw key

   string strCONTEXT_KEY;
   obfuscate(strYYYYMM,strCONTEXT_KEY);
   Table hTable;
   if(!setColumns(hTable))
   {
      IF::Trace::put("AESKeyManger: Error-Unable to query context table",-1,true);
      return UseCase::setSuccess(false);
   }
   hTable.set("CONTEXT_KEY",strCONTEXT_KEY);
   hTable.set("CONTEXT_DATA",strCONTEXT_DATA);
   auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   if (pInsertStatement->execute(hTable) == false)
   {
      IF::Trace::put("AESKeyManger: Error-Unable to initialize Key",-1,true);
      return UseCase::setSuccess(false);
   }
   UseCase::addItem();
   return true;
  //## end database::AESKeyManager::createKey_1%4989B59F00B6.body
}

bool AESKeyManager::createMasterKey ()
{
  //## begin database::AESKeyManager::createMasterKey%4974990D00C4.body preserve=yes
   //called by createDataKey and createTransportKey if 1st key being created and
   //tokenization was not started.
   string strSeed = generateKey();
   constructMasterKeys(m_hMasterKey[0],m_hMasterSeed[0],strSeed);

   //store master seed in database
   Table hTable;
   if(!setColumns(hTable))
   {
      IF::Trace::put("AESKeyManger: Error-Unable to query context table",-1,true);
      Database::instance()->rollback();
      return false;
   }
   hTable.set("CONTEXT_KEY",m_hMasterSeed[0].getCONTEXT_KEY());
   hTable.set("CONTEXT_DATA",m_hMasterSeed[0].getCONTEXT_DATA());
   auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   if (pInsertStatement->execute(hTable) == false)
   {
      IF::Trace::put("AESKeyManger: Error-Unable to initialize Master Key",-1,true);
      Database::instance()->rollback();
      return false;
   }

   KeyRing::instance()->resetKeys();

   //backup keys and tokens to DX_DATA_YYYYMMDD
   if(!backup())
   {
      Database::instance()->rollback();
      return false;
   }
   Database::instance()->commit();
   return true;
  //## end database::AESKeyManager::createMasterKey%4974990D00C4.body
}

bool AESKeyManager::createPassPhrase (string& strPassPhrase)
{
  //## begin database::AESKeyManager::createPassPhrase%552431610177.body preserve=yes
   //get default AES Data Key
   string strAESKey = AESKeyRing::instance()->getDefaultAESDataKey();
   if(strAESKey.empty())
   {
      if(!createDataKey(Key::AES256))
      {
         IF::Trace::put("createPassPhrase: unable to create Default AES Data Key",-1,true);
         Database::instance()->rollback();
         return false;
      }
      strAESKey = AESKeyRing::instance()->getDefaultAESDataKey();
   }
   Key* pAESKey = KeyRing::instance()->getKey(strAESKey);
   if(!pAESKey)
   {
      IF::Trace::put("createPassPhrase: unable to load Default AES Data Key",-1,true);
      return false;
   }
   //generate a pass phrase for PKCS12 file
   strPassPhrase = generateKey();  //use 32 char key as a passphrase
   string strEncryptedPassPhrase = strPassPhrase;
   if(!pAESKey->encrypt(strEncryptedPassPhrase))
   {
      IF::Trace::put("createPassPhrase: unable to encrypt Pass Phrase",-1,true);
      return false;
   }
   //Add encryption header to beginning of encrypted pass phrase
   if (strEncryptedPassPhrase.length() > INT_MAX - sizeof(struct encryptionHeader))
      return false;
   char* sBuffer = new char[sizeof(struct encryptionHeader) + strEncryptedPassPhrase.length()];
   struct encryptionHeader* pHeader = (struct encryptionHeader*)sBuffer;
   memset(pHeader,' ',sizeof(struct encryptionHeader));
   memcpy_s(pHeader,6,">DSS*<",6);
   pHeader->version = 1;
   pHeader->recordLength = strPassPhrase.length();
   pHeader->encryptionMethod = 2;
   pHeader->compressionMethod = 0;
   int iLen = pAESKey->getIdentifier().length();
   memcpy_s(pHeader->checkDigits,4,pAESKey->getIdentifier().data()+iLen-4,4);
   pHeader->compressionLength = (short)strEncryptedPassPhrase.length();
   memcpy_s((char*)pHeader+sizeof(struct encryptionHeader),strEncryptedPassPhrase.length(),strEncryptedPassPhrase.data(),strEncryptedPassPhrase.length());
   strEncryptedPassPhrase.assign(sBuffer,sizeof(struct encryptionHeader)+strEncryptedPassPhrase.length());
   delete [] sBuffer;

   SecurityWrapper::base64Encode(strEncryptedPassPhrase);

   //store server pass phrase in DN_KEYSTORE
   string strTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true).data(),16);
   Table hTable("DN_KEYSTORE");
   hTable.setQualifier("QUALIFY");
   hTable.set("TSTAMP_CREATED",strTSTAMP_CREATED);
   hTable.set("KEY_TYPE","SPP");
   hTable.set("KEY_FORMAT","B64");
   hTable.set("KEY_VALUE",strEncryptedPassPhrase);
   auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   if(!pInsertStatement->execute(hTable))
   {
      IF::Trace::put("createPassPhrase: insert of pass phrase failed",-1,true);
      Database::instance()->rollback();
      return false;
   }
   return true;
  //## end database::AESKeyManager::createPassPhrase%552431610177.body
}

bool AESKeyManager::createPKCS12 (const string& strPassPhrase,const string& strName,EVP_PKEY* pKey,X509* x509)
{
  //## begin database::AESKeyManager::createPKCS12%5524316F008A.body preserve=yes
   PKCS12* p12;
   p12 = SecurityWrapper::PKCS12_create((char*)strPassPhrase.c_str(),(char*)strName.c_str(),pKey,x509); 
   if(!p12) 
   {
      IF::Trace::put("createPKCS12: error creating PKCS#12 structure",-1,true);
      return false;
   }
   //read PKCS12 format into string to store in database
   BIO* pBIO = SecurityWrapper::BIO_new(SecurityWrapper::BIO_s_mem());
   SecurityWrapper::BIO_ctrl(pBIO,BIO_CTRL_FLUSH,0,NULL);
   SecurityWrapper::i2d_PKCS12_bio(pBIO,p12);
   void* pPKCS12 = 0;
   long lPKCS12 = SecurityWrapper::BIO_get_mem_data(pBIO,&pPKCS12);
   char* psPKCS12 = new char[lPKCS12];
   memcpy_s(psPKCS12,lPKCS12,pPKCS12,lPKCS12);
   SecurityWrapper::BIO_ctrl(pBIO,BIO_CTRL_SET_CLOSE,BIO_NOCLOSE,NULL);
   SecurityWrapper::BIO_free(pBIO);
   SecurityWrapper::PKCS12_free(p12);
   string strServerP12;
   CodeTable::nibbleToByte(psPKCS12,lPKCS12,strServerP12);
   delete[] psPKCS12;
   string strTSTAMP_CREATED(Clock::instance()->getYYYYMMDDHHMMSSHN(true).data(),16);
   int iLength = strServerP12.length();
   int iCount = 1;
   int iCursor = 0;
   char szKEY_TYPE[10];
   while (iLength > 0)
   {
      snprintf(szKEY_TYPE,sizeof(szKEY_TYPE),"SERVER%02d",iCount);
      Table hTable("DN_KEYSTORE");
      hTable.setQualifier("QUALIFY");
      hTable.set("TSTAMP_CREATED",strTSTAMP_CREATED);
      hTable.set("KEY_TYPE",szKEY_TYPE);
      hTable.set("KEY_FORMAT","PKCS12");
      hTable.set("KEY_VALUE",strServerP12.substr(iCursor,iLength > 4000 ? 4000 : iLength));
      auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      if (!pInsertStatement->execute(hTable))
      {
         IF::Trace::put("createPKCS12: insert of PKCS12 failed",-1,true);
         Database::instance()->rollback();
         return false;
      }
      iLength -= 4000;
      iCursor += 4000;
      iCount++;
   }
   Database::instance()->commit();
   return true;
  //## end database::AESKeyManager::createPKCS12%5524316F008A.body
}

bool AESKeyManager::createTokens (const string& strYYYYMM,const string& strStartDate)
{
  //## begin database::AESKeyManager::createTokens%49DE184C0343.body preserve=yes
   char szAlphabet[53] = {"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"};
   SecurityWrapper::initializeRNG();
   char arrayTokens[11136][4];
   map<string,int,less<string> > mapTokens;
   map<string,int,less<string> >::iterator q;
   string strToken;
   char szToken[5];
   //generate unique tokens
   unsigned int k,l,m,n = 0;
   for(int i = 0; i < 11136; i++)
   {
      bool bUnique = false;
      while(!bUnique)
      {
         SecurityWrapper::RAND_bytes((unsigned char*)&k,4);
         SecurityWrapper::RAND_bytes((unsigned char*)&l,4);
         SecurityWrapper::RAND_bytes((unsigned char*)&m,4);
         SecurityWrapper::RAND_bytes((unsigned char*)&n,4);
         if(i < 10000 || i >= 11110)
         {  //4 digit tokens (0000-9999)
            szToken[0] = szAlphabet[k % 52];
            szToken[1] = szAlphabet[l % 52];
            szToken[2] = szAlphabet[m % 52];
            szToken[3] = szAlphabet[n % 52];
         }
         else if(i >= 10000 && i < 11000)
         {  //3 digit tokens (000-999)
            szToken[0] = szAlphabet[k % 52];
            szToken[1] = szAlphabet[l % 52];
            szToken[2] = szAlphabet[m % 52];
            szToken[3] = ' ';
         }
         else if(i >= 11000 && i < 11100)
         {  //2 digit tokens (00-99)
            szToken[0] = szAlphabet[k % 52];
            szToken[1] = szAlphabet[l % 52];
            szToken[2] = ' ';
            szToken[3] = ' ';
         }
         else if(i >= 11100 && i < 11110)
         {  //1 digit tokens (0-9)
            szToken[0] = szAlphabet[k % 52];
            szToken[1] = ' ';
            szToken[2] = ' ';
            szToken[3] = ' ';
         }
         strToken.assign(szToken,4);
         q = mapTokens.find(strToken);
         if(q == mapTokens.end())
         {
            mapTokens.insert(map<string,int,less<string> >::value_type(strToken,i));
            memcpy_s(arrayTokens[i],4,strToken.data(),4);
            bUnique = true;
         }
      }
   }
   //store tokens in database
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   char pTOKEN[2553];
   Table hTable("DN_SYMBOLS");
   hTable.setQualifier("QUALIFY");
   int iOffset = 0;
   int iSEQ_NO = 1;
   string strTOKEN;
   for(int i = 0; i < 696; i++)
   {
      strTOKEN.assign(((char*)arrayTokens)+(i*64),64);
      KeyRing::instance()->encrypt(strYYYYMM,strTOKEN);
      memcpy_s(((char*)pTOKEN)+iOffset,strTOKEN.length(),strTOKEN.data(),strTOKEN.length());
      memcpy_s(((char*)pTOKEN)+iOffset+strTOKEN.length()-2,2,strTOKEN.data()+42,2);
      iOffset+= strTOKEN.length();
      if(iOffset == 2552)
      {
         strTOKEN.assign(pTOKEN,2552);
         hTable.set("SEQ_NO",iSEQ_NO++);
         hTable.set("DN_SYMBOL",strTOKEN);
         hTable.set("SYMBOL_ID",strYYYYMM);
         if(!pInsertStatement->execute(hTable))
         {
            Database::instance()->rollback();
            return false;
         }
         iOffset = 0;
      }
   }
   //construct control record
   //scramble the order of the rows so we can compute the hash
   int arraySEQ_NO[25] = {13,15,17,1,4,3,9,18,12,11,21,2,10,5,19,8,6,14,20,7,16,22,23,24};
   char arrayTemp[11136][4];
   int iTempOffset = 0;
   for(int i = 0; i < 24; i++)
   {
      iOffset = (arraySEQ_NO[i]-1)*16*29*4;
      memcpy_s(((char*)arrayTemp)+iTempOffset,1856,((char*)arrayTokens)+iOffset,1856);
      iTempOffset+=1856;
   }
   //generate Hash of tokens for final validation
   int lHash = AESKey::generateHash((char*)arrayTemp,11136 * 4);
   char szControl[65];
   memset(szControl,' ',65);
   string strFmt("%04d%010d%02d");
   strFmt.append("%02d%02d%02d%02d%02d%02d%02d%02d%02d%02d%02d%02d");
   strFmt.append("%02d%02d%02d%02d%02d%02d%02d%02d%02d%02d%02d%02d");
   strTOKEN.assign(szControl,snprintf(szControl,sizeof(szControl),strFmt.c_str(),1,lHash,2,
      arraySEQ_NO[0],arraySEQ_NO[1],arraySEQ_NO[2],arraySEQ_NO[3],
      arraySEQ_NO[4],arraySEQ_NO[5],arraySEQ_NO[6],arraySEQ_NO[7],
      arraySEQ_NO[8],arraySEQ_NO[9],arraySEQ_NO[10],arraySEQ_NO[11],
      arraySEQ_NO[12],arraySEQ_NO[13],arraySEQ_NO[14],arraySEQ_NO[15],
      arraySEQ_NO[16],arraySEQ_NO[17],arraySEQ_NO[18],arraySEQ_NO[19],
      arraySEQ_NO[20],arraySEQ_NO[21],arraySEQ_NO[22],arraySEQ_NO[23]));
   KeyRing::instance()->encrypt(strYYYYMM,strTOKEN);
   memcpy_s((char*)strTOKEN.data()+86,2,strTOKEN.data()+42,2);

   //generate 2nd part of control record
   string strEndDate("999999"); //default end date.
   memset(szControl,' ',65);
   memcpy_s(szControl,sizeof(szControl),strStartDate.data(),6);
   memcpy_s(szControl+6,sizeof(szControl)-6,strEndDate.data(),6);
   string strTOKEN2(szControl,64);
   KeyRing::instance()->encrypt(strYYYYMM,strTOKEN2);
   memcpy_s((char*)strTOKEN2.data()+86,2,strTOKEN2.data()+42,2);
   strTOKEN.append(strTOKEN2.data(),strTOKEN2.length());
   hTable.set("SEQ_NO",iSEQ_NO);
   hTable.set("DN_SYMBOL",strTOKEN);
   hTable.set("SYMBOL_ID",strYYYYMM);
   if(!pInsertStatement->execute(hTable))
   {
      Database::instance()->rollback();
      return false;
   }
   return true;
  //## end database::AESKeyManager::createTokens%49DE184C0343.body
}

bool AESKeyManager::createTransportKey ()
{
  //## begin database::AESKeyManager::createTransportKey%4C3769C20201.body preserve=yes
   if(!checkEnvironment())
      return environmentWarning("Create Transport Key");
   AESKey hTransportKey;
   string strKey[3];
   string strTKId;
   AESKey hKeyPart[3];
   int iSafetyValve = 0;
   while(iSafetyValve++ < 20)
   {
      for(int i = 0; i < 3; i++)
      {
         hKeyPart[i].setType(Key::AES256_3);
         hKeyPart[i].setStrength(256);
         strKey[i].assign(generateKey2());
         hKeyPart[i].setRawKey((char*)strKey[i].data(),strKey[i].length());
         hKeyPart[i].computeCheckDigits();
      }

      //build transport key
      unsigned char szTPKey[32];
      for(int i = 0; i < 32; i++)
      {
         szTPKey[i] = hKeyPart[0].getRawKey()[i] ^ hKeyPart[1].getRawKey()[i] ^ hKeyPart[2].getRawKey()[i];
      }
      strTKId.assign("TK");
      hTransportKey.setType(Key::AES256_3);
      hTransportKey.setStrength(256);
      hTransportKey.setRawKey((char*)szTPKey,32);
      hTransportKey.computeCheckDigits();
      strTKId.append(hTransportKey.getCheckDigits());
      if(!KeyRing::instance()->getKey(strTKId))
         break; //no collisions so continue
      IF::Trace::put("createTransportKey: collision",-1,true);
      IF::Trace::put(strTKId.data(),strTKId.length(),true);
   }
   if(iSafetyValve == 20)
      return false; //somethings wrong!

   //store key parts in TASK_CONTEXT with other keys
   char szTemp[2];
   string strKeyId[3];
   for(int i = 0; i < 3;i++)
   {
      strKeyId[i].assign("P");
      strKeyId[i].append(hTransportKey.getCheckDigits());
      strKeyId[i].append(szTemp,snprintf(szTemp,sizeof(szTemp),"%d",i+1));
      string strCONTEXT_DATA(strKeyId[i]);

      strCONTEXT_DATA.append("==");
      strCONTEXT_DATA.append((char*)hKeyPart[i].getRawKey(),32);
      strCONTEXT_DATA.append(",");
      strCONTEXT_DATA.append(hKeyPart[i].getCheckDigits().data(),hKeyPart[i].getCheckDigits().length());
      strCONTEXT_DATA.append(",");
      strCONTEXT_DATA.append(Clock::instance()->getYYYYMMDDHHMMSS().data(),8);
      Key* pMasterKey = KeyRing::instance()->getKey("Master");
      if(!pMasterKey)
      {
         //generate master key 1st time
         //first make sure environment not already there
         int lCount = 0;
         Query hQuery;
         if(!bind(hQuery,true,false,false))
         {
            IF::Trace::put("Transport Key creation failed - "
               "Query of context table failed",-1,true);
            return false;
         }
         auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
         if((!pSelectStatement->execute(hQuery)) || m_lCount > 0)
         {
            IF::Trace::put("Transport Key creation failed - "
               "Master Key not found but key DB not empty",-1,true);
            return false;
         }
         if(!createMasterKey())
         {
            IF::Trace::put("Transport Key creation failed - "
               "Unable to initialize Master Key",-1,true);
            return false;
         }
         pMasterKey = KeyRing::instance()->getKey("Master");
      }
      if(!pMasterKey->encrypt(strCONTEXT_DATA))
      {
         IF::Trace::put("Transport Key creation failed - "
            "Unable to encrypt Key Part with Master Key",-1,true);
         return false;
      }
      strCONTEXT_DATA.resize(100,' ');
      strCONTEXT_DATA[99] = '3'; //default new Transport keys to type 256_3 
      string strCONTEXT_KEY;
      obfuscate(strKeyId[i],strCONTEXT_KEY);
      Table hTable;
      if(!setColumns(hTable))
      {
         IF::Trace::put("Transport Key creation failed - "
            "Unable to query context table",-1,true);
         return false;
      }
      hTable.set("CONTEXT_KEY",strCONTEXT_KEY);
      hTable.set("CONTEXT_DATA",strCONTEXT_DATA);
      auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      if (pInsertStatement->execute(hTable) == false)
      {
         IF::Trace::put("Transport Key creation failed - "
            "Unable to add Transport Key Part to Database",-1,true);
         return false;
      }
   }
   //backup(); //ensure full set is available in most recent daily backup
   KeyRing::instance()->resetKeys(); //pickup new key
   if (KeyRing::instance()->getDefaultTransportKey() == "")
   {
      setDefaultTransportKey(strTKId);
      Database::instance()->commit();
   }
   return true;
  //## end database::AESKeyManager::createTransportKey%4C3769C20201.body
}

bool AESKeyManager::deleteKey (const string& strYYYYMM)
{
  //## begin database::AESKeyManager::deleteKey%4975F6000189.body preserve=yes
   UseCase hUseCase("DR","## DR11 DROP KEY");
   if(strYYYYMM.length() != 6)
      return false;
   if(strYYYYMM.substr(0,2) != "TK")
   {
      obfuscate(strYYYYMM,m_strCONTEXT_KEY[0]);
      Query hQuery;
      if(!bind(hQuery,false,false,false))
      {
         Database::instance()->rollback();
         return UseCase::setSuccess(false);
      }
      vector<Table> hTable = hQuery.getTable();
      if(hTable[0].getName() == "TASK_CONTEXT_COMN")
         hQuery.setBasicPredicate("TASK_CONTEXT_COMN","CONTEXT_KEY","=",m_strCONTEXT_KEY[0].c_str());
      else
         hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_KEY","=",m_strCONTEXT_KEY[0].c_str());
      auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
      if (!pDeleteStatement->execute(hQuery))
      {
         Database::instance()->rollback();
         return UseCase::setSuccess(false);
      }
      UseCase::addItem();
      if(strYYYYMM.substr(0,2) == "DK" && KeyRing::instance()->getDefaultDataKey() == strYYYYMM)
      {//delete the DEFAULT DATA KEY record
         hQuery.reset();
         if(!bind(hQuery,false,false,false))
         {
            Database::instance()->rollback();
            return UseCase::setSuccess(false);
         }
         if(hTable[0].getName() == "TASK_CONTEXT_COMN")
            hQuery.setBasicPredicate("TASK_CONTEXT_COMN","CONTEXT_KEY","=","DEFAULT_DATA_KEY");
         else
            hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_KEY","=","DEFAULT_DATA_KEY");
         auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
         if (!pDeleteStatement->execute(hQuery))
         {
            Database::instance()->rollback();
            return UseCase::setSuccess(false);
         }
         KeyRing::instance()->setDefaultDataKey("");
      }
      if(strYYYYMM.substr(0,2) == "DK" && KeyRing::instance()->isICSF())
      {
         IBMKey hIBMKey;
         if(!hIBMKey.deleteKey(strYYYYMM))
         {
            string strMsg("Delete key ");
            strMsg.append(strYYYYMM);
            strMsg.append(" from ICSF failed");
            IF::Trace::put(strMsg.data(),strMsg.length(),true);
            Database::instance()->rollback();
            return UseCase::setSuccess(false);
         }
      }
      return true;
   }
   else if(strYYYYMM.substr(0,2) == "TK")
   {
      char szTemp[2];
      for(int i = 0; i < 3; i++)
      {
         string strKeyPart("P");
         strKeyPart.append(strYYYYMM.substr(2));
         strKeyPart.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%d",i+1));
         obfuscate(strKeyPart,m_strCONTEXT_KEY[0]);
         Query hQuery;
         if(!bind(hQuery,false,false,false))
         {
            Database::instance()->rollback();
            return UseCase::setSuccess(false);
         }
         vector<Table> hTable = hQuery.getTable();
         if(hTable[0].getName() == "TASK_CONTEXT_COMN")
            hQuery.setBasicPredicate("TASK_CONTEXT_COMN","CONTEXT_KEY","=",m_strCONTEXT_KEY[0].c_str());
         else
            hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_KEY","=",m_strCONTEXT_KEY[0].c_str());
         auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
         if (!pDeleteStatement->execute(hQuery))
         {
            Database::instance()->rollback();
            return UseCase::setSuccess(false);
         }
         UseCase::addItem();
         if(KeyRing::instance()->getDefaultTransportKey() == strYYYYMM)
         {//delete the DEFAULT TRANSPORT KEY record
            hQuery.reset();
            if(!bind(hQuery,false,false,false))
            {
               Database::instance()->rollback();
               return UseCase::setSuccess(false);
            }
            if(hTable[0].getName() == "TASK_CONTEXT_COMN")
               hQuery.setBasicPredicate("TASK_CONTEXT_COMN","CONTEXT_KEY","=","DEFAULT_TRANSPORT_KEY");
            else
               hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_KEY","=","DEFAULT_TRANSPORT_KEY");
            auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
            if (!pDeleteStatement->execute(hQuery))
            {
               Database::instance()->rollback();
               return UseCase::setSuccess(false);
            }
            KeyRing::instance()->setDefaultTransportKey("");
         }
      }
      return true;
   }
   return false;
  //## end database::AESKeyManager::deleteKey%4975F6000189.body
}

bool AESKeyManager::deleteSSLEnvironment ()
{
  //## begin database::AESKeyManager::deleteSSLEnvironment%5524319202C2.body preserve=yes
   Query hQuery;
   hQuery.setQualifier("QUALIFY","DN_KEYSTORE");
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   if(!pDeleteStatement->execute(hQuery))
   {
      Database::instance()->rollback();
      return false;
   }
   Database::instance()->commit();
   return true;
  //## end database::AESKeyManager::deleteSSLEnvironment%5524319202C2.body
}

bool AESKeyManager::environmentWarning (const string& strCommand)
{
  //## begin database::AESKeyManager::environmentWarning%50169DDB01D2.body preserve=yes
   string strWarning("Warning - ");
   strWarning.append(strCommand);
   strWarning.append(" command failed,environment waiting for repair");
   IF::Trace::put(strWarning.data(),strWarning.length(),true);
   return false;
  //## end database::AESKeyManager::environmentWarning%50169DDB01D2.body
}

bool AESKeyManager::exportDataKey (string& strErrorMsg)
{
  //## begin database::AESKeyManager::exportDataKey%4C472A9801E7.body preserve=yes
   FlatFile hKeyFile("EDKFILE");
   hKeyFile.setName("EDKFILE");
   if(!hKeyFile.open(FlatFile::CX_OPEN_OUTPUT))
   {
      strErrorMsg.assign("exportDataKey failed: Unable to open file - EDKFILE");
      return false;
   }
   KeyRing::instance()->resetKeys();
   string strDefaultTransportKey = KeyRing::instance()->getDefaultTransportKey();
   if(strDefaultTransportKey.length() != 6)
   {
      strErrorMsg.assign("exportDataKey failed: Default transport key is not established");
      return false;
   }
   Key* pTransportKey = KeyRing::instance()->getTransportKey(strDefaultTransportKey);
   if(!pTransportKey)
   {
      strErrorMsg.assign("exportDataKey failed: Unable to retreive default transport key from key ring");
      return false;
   }
   string strDefaultDataKey = KeyRing::instance()->getDefaultDataKey();
   if(strDefaultDataKey.length() != 6)
   {
      strErrorMsg.assign("exportDataKey failed: Default data key is not established");
      return false;
   }
   Key* pDataKey = KeyRing::instance()->getKey(strDefaultDataKey);
   if(!pDataKey)
   {
      strErrorMsg.assign("exportDataKey failed: Unable to retrieve default data key from key ring");
      return false;
   }
   string strKey = pDataKey->getKey();
   if (strKey.length() != 64)
   {
      strErrorMsg.assign("exportDataKey failed: Invalid default data key");
      return false;
   }
   unsigned char szRawKey[33];
   memcpy_s(szRawKey,sizeof(szRawKey),pDataKey->getRawKey(),32);
   szRawKey[32] = '\0';
   for (int i = 0; i < 2; i++)
      pTransportKey->encrypt_256(szRawKey + (i * 16));
   char szTemp[3];
   strKey.assign("");
   for(int i = 0; i < 32; i++)
   {
      unsigned char c = szRawKey[i];
      strKey.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%02X",c));
   }
   char szBuffer[81];
   szBuffer[80] = '\0';
   memset(szBuffer,' ',80);
   memcpy_s(szBuffer,sizeof(szBuffer),strDefaultTransportKey.substr(2,4).data(),4);
   memcpy_s(szBuffer + 5,sizeof(szBuffer)-5,strKey.data(),64);
   memcpy_s(szBuffer + 70,sizeof(szBuffer) - 70,strDefaultDataKey.substr(2,4).data(),4);
   Memory hMemory(100);
   memcpy_s(hMemory,100,szBuffer,80);
   if(!hKeyFile.write(hMemory,80))
   {
      strErrorMsg.assign("exportDataKey failed: Unable to write to file - EDKFILE");
      return false;
   }
   hKeyFile.close();
   return true;
  //## end database::AESKeyManager::exportDataKey%4C472A9801E7.body
}

bool AESKeyManager::exportSSLCertificate ()
{
  //## begin database::AESKeyManager::exportSSLCertificate%5524235801DD.body preserve=yes
   bool bRC = false;
   SecurityWrapper::OPENSSL_init_crypto(OPENSSL_INIT_ADD_ALL_CIPHERS | OPENSSL_INIT_ADD_ALL_DIGESTS,NULL);
   SecurityWrapper::OPENSSL_init_crypto(OPENSSL_INIT_LOAD_CRYPTO_STRINGS,NULL);

   EVP_PKEY* pKey = EVP_PKEY_new();
   X509* pX509 = X509_new();
   PKCS12* p12 = 0;
   loadSSLEnvironment();
   if(!loadSSLEnvironment((void**)&pKey,(void**)&pX509,(void**)&p12))
   {
      IF::Trace::put("exportSSLCertificate: Unable to load SSL Environment",-1,true);
      Console::display("ST545","EXPORT OF SSL CERTIFICATE FAILED");
      SecurityWrapper::EVP_PKEY_free(pKey);
      SecurityWrapper::X509_free(pX509);
      SecurityWrapper::PKCS12_free(p12);
      return false;
   }
   FlatFile hCertFile("CRTFILE");
   if(!hCertFile.open(FlatFile::CX_OPEN_OUTPUT))
   {
      IF::Trace::put("exportSSLCertificate: Unable to open CRTFILE",-1,true);
      Console::display("ST545","EXPORT OF SSL CERTIFICATE FAILED");
      SecurityWrapper::EVP_PKEY_free(pKey);
      SecurityWrapper::X509_free(pX509);
      SecurityWrapper::PKCS12_free(p12);
      return false;
   }
   FILE* fp = (FILE*)hCertFile.getFile();
   if (pX509)
   {
      BIO *pBIO = SecurityWrapper::BIO_new(SecurityWrapper::BIO_s_mem());
      if (!SecurityWrapper::PEM_write_bio_X509(pBIO,pX509))
      {
         IF::Trace::put("exportSSLCertificate: PEM_write_bio_X509() failed",-1,true);
         Console::display("ST545","EXPORT OF SSL CERTIFICATE FAILED");
         SecurityWrapper::EVP_PKEY_free(pKey);
         SecurityWrapper::X509_free(pX509);
         SecurityWrapper::PKCS12_free(p12);
         SecurityWrapper::BIO_free(pBIO);
         return false; 
      }
      int iPEMLength = BIO_number_written(pBIO) + 1;
      char* pPEM = new char[BIO_number_written(pBIO) + 1];
      memset(pPEM,0,BIO_number_written(pBIO) + 1);
      SecurityWrapper::BIO_read(pBIO,pPEM,BIO_number_written(pBIO)); //need to add BIO_read to SecurityWrapper
      SecurityWrapper::BIO_free(pBIO);

      //write to disk here:
      if (!hCertFile.write(pPEM,iPEMLength))
      {
         IF::Trace::put("exportSSLCertificate: Unable to write to CRTFILE",-1,true);
         Console::display("ST545","EXPORT OF SSL CERTIFICATE FAILED");
         SecurityWrapper::EVP_PKEY_free(pKey);
         SecurityWrapper::X509_free(pX509);
         SecurityWrapper::PKCS12_free(p12);
         delete[] pPEM;
         return false;
      }
      delete[] pPEM;
   }
   hCertFile.close();
   SecurityWrapper::EVP_PKEY_free(pKey);
   SecurityWrapper::X509_free(pX509);
   SecurityWrapper::PKCS12_free(p12);
   IF::Trace::put("exportSSLCertificate: export successful",-1,true);
   Console::display("ST604","EXPORT OF SSL CERTIFICATE SUCCESSFUL");
   return true;
  //## end database::AESKeyManager::exportSSLCertificate%5524235801DD.body
}

bool AESKeyManager::exportTransportKey (string& strErrorMsg)
{
  //## begin database::AESKeyManager::exportTransportKey%4C472A1400DB.body preserve=yes
   KeyRing::instance()->resetKeys();
   string strDefaultTransportKey = KeyRing::instance()->getDefaultTransportKey();
   if(strDefaultTransportKey.length() != 6)
   {
      strErrorMsg.assign("exportTransportKey failed: default transport key is not established");
      return false;
   }
   AESKey* pTransportKey = (AESKey*)KeyRing::instance()->getTransportKey(strDefaultTransportKey);
   if(!pTransportKey)
   {
      strErrorMsg.assign("exportTransportKey failed: ");
      strErrorMsg.append("Unable to retrieve default transport key from key ring");
      return false;
   }
   for(int i = 0; i < 3; i++)
   {
      //open output file
      char szName[9];
      snprintf(szName,sizeof(szName),"ETKPART%d",i+1);
      FlatFile hKeyPartFile(szName);
      hKeyPartFile.setName(szName);
      if(!hKeyPartFile.open(FlatFile::CX_OPEN_OUTPUT))
      {
         strErrorMsg.assign("exportTransportKey failed: ");
         strErrorMsg.append("Unable to open key part file - ");
         strErrorMsg.append(szName,8);
         return false;
      }

      //generate key part records
      //TKCD <------------------ KEY PART 64 BYTES -------------------------> KPCD
      //XXXX XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX XXXX
      char szPartId[7];
      string strKeyPartId(szPartId,
         snprintf(szPartId,sizeof(szPartId),"P%s%d",strDefaultTransportKey.substr(2,4).c_str(),i+1));
      AESKey* pKeyPart = (AESKey*)KeyRing::instance()->getKey(strKeyPartId);
      if(!pKeyPart)
      {
         strErrorMsg.assign("exportTransportKey failed: ");
         strErrorMsg.append("Unable to retrieve key part ");
         strErrorMsg.append(strKeyPartId);
         return false;
      }
      string strKey = pKeyPart->getKey();
      string strCheckDigits = pKeyPart->getCheckDigits();
      if(strCheckDigits.length() != 4)
      {
         strErrorMsg.assign("exportTransportKey failed: ");
         strErrorMsg.append("Check digits invalid for key part ");
         strErrorMsg.append(strKeyPartId);
         return false;
      }
      if(strKey.length() != 64)
      {
         strErrorMsg.assign("exportTransportKey failed: Invalid key part ");
         strErrorMsg.append(strKeyPartId);
         return false;
      }
      //write to file
      char szBuffer[81];
      szBuffer[80] = '\0';
      memset(szBuffer,' ',80);
      memcpy_s(szBuffer,sizeof(szBuffer),strDefaultTransportKey.substr(2,4).data(),4);
      memcpy_s(szBuffer + 5,sizeof(szBuffer) - 5,strKey.data(),64);
      memcpy_s(szBuffer + 70,sizeof(szBuffer) - 70,strCheckDigits.data(),4);
      IF::Trace::put(szBuffer,80);
      Memory hMemory(100);
      memcpy_s(hMemory,100,szBuffer,80);
      if(!hKeyPartFile.write(hMemory,80))
      {
         strErrorMsg.assign("exportTransportKey failed: ");
         strErrorMsg.append("Unable to write to file - ");
         strErrorMsg.append(szName,8);
         return false;
      }
      hKeyPartFile.close();
   }
   return true;
  //## end database::AESKeyManager::exportTransportKey%4C472A1400DB.body
}

string AESKeyManager::generateKey ()
{
  //## begin database::AESKeyManager::generateKey%497498D3011A.body preserve=yes
   //Because achieving enough entropy to produce a truly random key is difficult, the
   //strategy being deployed here is to use the openssl RSA_generate_key to generate a
   //public/private key pair.  Then write the public part to a buffer, use MD5 to hash
   //the public key, then encode the hash result as character hex to make it easier
   //to use. return 1st 32 bytes of the printable character string.
   BIO* pBIO = SecurityWrapper::BIO_new(SecurityWrapper::BIO_s_mem());
   RSA* pRSA = NULL;
   pRSA = SecurityWrapper::RSA_generate_key(2048,65537,NULL,NULL);
   SecurityWrapper::PEM_write_bio_RSA_PUBKEY(pBIO,pRSA);
   SecurityWrapper::BIO_ctrl(pBIO,BIO_CTRL_FLUSH,0,NULL);

   void* ptr = 0;
   long sz = SecurityWrapper::BIO_get_mem_data(pBIO, &ptr);
   char psPublicKey[4096];
   memcpy_s(psPublicKey,sizeof(psPublicKey),ptr,sz);
   SecurityWrapper::BIO_ctrl(pBIO,BIO_CTRL_SET_CLOSE,BIO_NOCLOSE,NULL);
   SecurityWrapper::BIO_free(pBIO);
   string strDigest(psPublicKey,sz);
   AESKey::generateDigest(strDigest);
   return strDigest;
  //## end database::AESKeyManager::generateKey%497498D3011A.body
}

bool AESKeyManager::generateBeginDate (string& strBeginDate)
{
  //## begin database::AESKeyManager::generateBeginDate%4A01A9BF0387.body preserve=yes
   Date hDate(Date::today());
   string strCurrentMonth(hDate.asString("%Y%m"));
   for(int i = 0; i < 3; i++) //limit to 3 tries
   {
      string strFIN_L("FIN_L");
      strFIN_L.append(hDate.asString("%Y%m"));
      int lCount = 0;
      Query hQuery;
      hQuery.bind(strFIN_L.c_str(),"*",Column::LONG,&lCount,0,"COUNT");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if(!pSelectStatement->execute(hQuery) || lCount == 0)
      {  //table not created or table is empty
         strBeginDate = hDate.asString("%Y%m");
         return true;
      }
      hDate.incrementMonth();
   }
   return false;
  //## end database::AESKeyManager::generateBeginDate%4A01A9BF0387.body
}

bool AESKeyManager::generateEndDate (string& strEndDate)
{
  //## begin database::AESKeyManager::generateEndDate%4A047DF40108.body preserve=yes
   Date hDate(Date::today());
   string strCurrentMonth(hDate.asString("%Y%m"));
   for(int i = 0; i < 3; i++) //limit to 3 tries
   {
      string strFIN_L("FIN_L");
      strFIN_L.append(hDate.asString("%Y%m"));
      int lCount = 0;
      Query hQuery;
      hQuery.bind(strFIN_L.c_str(),"*",Column::LONG,&lCount,0,"COUNT");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if(!pSelectStatement->execute(hQuery) || lCount == 0)
      {
         hDate.incrementMonth(-1); //continue through end of this month
         strEndDate = hDate.asString("%Y%m");
         return true;
      }
      hDate.incrementMonth();
   }
   return false;
  //## end database::AESKeyManager::generateEndDate%4A047DF40108.body
}

bool AESKeyManager::handleKeyCommands (const string& strCommand,string& strConsoleMsg)
{
  //## begin database::AESKeyManager::handleKeyCommands%4C8138B303A6.body preserve=yes
   char szMsg[100];
   if(strCommand.length() < 70)
      IF::Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"%s request received from console",strCommand.c_str()));

   //handle list key command
   if(strCommand == "KEYS.LIST")
   {
      sendKeyListResponse();
      return true;
   }

   //handle generate data key command
   if(strCommand == "KEYS.GDK")
   {
      strConsoleMsg.assign("GEN KEY-DK");
      if(!KeyManager::instance()->createDataKey())
      {
         IF::Trace::put("Generation of Data Key failed",-1,true);
         Database::instance()->rollback();
         sendKeyListResponse();
         return false;
      }
      else
      {
         IF::Trace::put("Generation of Data Key completed successfully",-1,true);
         sendKeyListResponse();
         return true;
      }
   }

   //handle generate transport key command
   if(strCommand == "KEYS.GTK")
   {
      strConsoleMsg.assign("GEN KEY-TK");
      if(!KeyManager::instance()->createTransportKey()) //Transport Key
      {
         IF::Trace::put("Generation of Transport Key part failed",-1,true);
         Database::instance()->rollback();
         sendKeyListResponse();
         return false;
      }
      else
      {
         IF::Trace::put("Generation of Transport Key part completed successfully",-1,true);
         sendKeyListResponse();
         return false;
      }
   }

   //handle delete key command
   if(strCommand.length() >= 13 && strCommand.substr(0,7) == "KEYS.D.")
   {
      string strKeyId(strCommand.substr(7,6));
      if(!KeyManager::instance()->deleteKey(strKeyId))
      {
         Database::instance()->rollback();
         strConsoleMsg.assign("DEL ");
         strConsoleMsg.append(strKeyId);
         IF::Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"Delete of Key %s failed",strKeyId.c_str()),true);
         sendKeyListResponse();
         return false;
      }
      else
      {
         if(KeyRing::instance()->getDefaultDataKey() == strKeyId)
            KeyManager::instance()->setDefaultDataKey("");
         if(KeyRing::instance()->getDefaultTransportKey() == strKeyId)
            KeyManager::instance()->setDefaultTransportKey("");
         Database::instance()->commit();
         KeyRing::instance()->resetKeys();
         string strConsoleMsg("DEL ");
         strConsoleMsg.append(strKeyId);
         Console::display("ST604",strConsoleMsg.c_str());
         IF::Trace::put(szMsg,
            snprintf(szMsg,sizeof(szMsg),"Delete of Key %s completed successfully",
            strKeyId.c_str()),true);
         sendKeyListResponse();
         return true;
      }
   }

   //hande setDefaultDatakey and setDefaultTransportKey commands
   if(strCommand.length() >= 13 && strCommand.substr(0,7) == "KEYS.S.")
   {
      string strKeyId(strCommand.substr(7,6));
      string strConsoleMsg("SET ");
      strConsoleMsg.append(strKeyId);
      bool bSet = false;
      if(strKeyId[0] == 'D')
         bSet = KeyManager::instance()->setDefaultDataKey(strKeyId);
      if(strKeyId[0] == 'T')
         bSet = KeyManager::instance()->setDefaultTransportKey(strKeyId);
      if(!bSet)
      {
         IF::Trace::put(szMsg,snprintf(szMsg,sizeof(szMsg),"Set key as Default for %s failed",strKeyId.c_str()));
         sendKeyListResponse();
         return false;
      }
      else
      {
         Database::instance()->commit();
         KeyRing::instance()->resetKeys();
         IF::Trace::put(szMsg,
            snprintf(szMsg,sizeof(szMsg),"Set key as Default for %s completed successfully",
            strKeyId.c_str()),true);
         sendKeyListResponse();
         return true;
      }
   }

   //handle key import commands
   if(strCommand.length() >= 9 &&
      (strCommand.substr(0,9) == "KEYS.IDK."  || strCommand.substr(0,9) == "KEYS.ITK."))
   {
      //import transport key - part x of 3 or Data key
      struct sKeyPart hKeyPart;
      memset((char*)&hKeyPart,' ',sizeof(struct sKeyPart));
      if(strCommand.length() < 81)
      {
         memcpy_s(hKeyPart.sTKCD,sizeof(hKeyPart.sTKCD),"XXXX",4);
         memcpy_s(hKeyPart.sKEY1,sizeof(hKeyPart.sKEY1),"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",32);
         memcpy_s(hKeyPart.sKEY2,sizeof(hKeyPart.sKEY2),"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",32);
         memcpy_s(hKeyPart.sKPCD,sizeof(hKeyPart.sKPCD),"XXXX",4);
         memcpy_s(hKeyPart.sSTATUS,sizeof(hKeyPart.sSTATUS),"ERROR: Invalid Key or Check Digit Length",40);
         if(strCommand.length() >= 13)
            memcpy_s(hKeyPart.sTKCD,sizeof(hKeyPart.sTKCD),strCommand.data()+9,4);
         if(strCommand.length() >= 45)
            memcpy_s(hKeyPart.sKEY1,sizeof(hKeyPart.sKEY1),strCommand.data()+13,32);
         if(strCommand.length() > 13 && strCommand.length() < 45)
            memcpy_s(hKeyPart.sKEY1,sizeof(hKeyPart.sKEY1),strCommand.data()+13,strCommand.length()-13);
         if (strCommand.length() >= 77)
            memcpy_s(hKeyPart.sKEY2,sizeof(hKeyPart.sKEY2),strCommand.data() + 45,32);
         if (strCommand.length() > 45 && strCommand.length() < 77)
            memcpy_s(hKeyPart.sKEY2,sizeof(hKeyPart.sKEY2),strCommand.data() + 45,strCommand.length() - 77);
         if (strCommand.length() == 49)
            memcpy_s(hKeyPart.sKPCD,sizeof(hKeyPart.sKPCD),strCommand.data() + 45,4);
         else if (strCommand.length() == 81)
            memcpy_s(hKeyPart.sKPCD,sizeof(hKeyPart.sKPCD),strCommand.data() + 77,4);
         sendKeyImportResponse(hKeyPart);
         return false;
      }

      //import transport key
      if(strCommand.substr(0,9) == "KEYS.ITK.")
      {
         string strContext("TRANSPORT ");
         strContext.append(strCommand.substr(9,4));
         strContext.append("-");
         strContext.append(strCommand.substr(13,32));
         strContext.append(strCommand.substr(45,32));
         strContext.append("-");
         strContext.append(strCommand.substr(77,4));
         memcpy_s(hKeyPart.sTKCD,sizeof(hKeyPart.sTKCD),strCommand.data() + 9,4);
         memcpy_s(hKeyPart.sKEY1,sizeof(hKeyPart.sKEY1),strCommand.data() + 13,32);
         memcpy_s(hKeyPart.sKEY2,sizeof(hKeyPart.sKEY2),strCommand.data() + 45,32);
         memcpy_s(hKeyPart.sKPCD,sizeof(hKeyPart.sKPCD),strCommand.data() + 77,4);
         strConsoleMsg.assign("IMPORT ITK");
         if(!KeyManager::instance()->importTransportKey(strContext))
         {
            Database::instance()->rollback();
            IF::Trace::put("Import of Transport Key Part Failed",-1,true);
            memcpy_s(hKeyPart.sSTATUS,sizeof(hKeyPart.sSTATUS),"ERROR: ",7);
            memcpy_s(hKeyPart.sSTATUS+7,sizeof(hKeyPart.sSTATUS)-7,m_strStatusMsg.data(),
               m_strStatusMsg.length() <= 33 ? m_strStatusMsg.length() : 33);
            sendKeyImportResponse(hKeyPart);
            return false;
         }
         else
         {
            memcpy_s(hKeyPart.sSTATUS,sizeof(hKeyPart.sSTATUS),"TRANSPORT KEY PART IMPORTED SUCCESSFULLY",40);
            Database::instance()->commit();
            IF::Trace::put("Import of Transport Key Part completed successfully",-1,true);
            sendKeyImportResponse(hKeyPart);
            return true;
         }
      }

      //import data key
      if(strCommand.substr(0,9) == "KEYS.IDK.")
      {
         string strTKCD;
         string strKey;
         string strDKCD;
         memcpy_s(hKeyPart.sTKCD,sizeof(hKeyPart.sTKCD),strCommand.data() + 9,4);
         memcpy_s(hKeyPart.sKEY1,sizeof(hKeyPart.sKEY1),strCommand.data() + 13,32);
         memcpy_s(hKeyPart.sKEY2,sizeof(hKeyPart.sKEY2),strCommand.data() + 45,32);
         memcpy_s(hKeyPart.sKPCD,sizeof(hKeyPart.sKPCD),strCommand.data() + 77,4);
         strTKCD.assign(hKeyPart.sTKCD,4);
         strKey.assign(hKeyPart.sKEY1,32);
         strKey.append(hKeyPart.sKEY2,32);
         strDKCD.assign(hKeyPart.sKPCD,4);
         string strConsoleMsg;
         strConsoleMsg.assign("IMPORT IDK");
         if(!KeyManager::instance()->importDataKey(strTKCD,
            strKey,strDKCD,m_strStatusMsg,strConsoleMsg))
         {
            Database::instance()->rollback();
            memcpy_s(szMsg,sizeof(szMsg),"Import of Data Key failed: ",27);
            memcpy_s(szMsg+27,sizeof(szMsg)-27,m_strStatusMsg.data(),m_strStatusMsg.length());
            IF::Trace::put(szMsg,27+m_strStatusMsg.length(),true);
            memcpy_s(hKeyPart.sSTATUS,sizeof(hKeyPart.sSTATUS),"ERROR: ",7);
            memcpy_s(hKeyPart.sSTATUS+7,sizeof(hKeyPart.sSTATUS)-7,m_strStatusMsg.data(),
               m_strStatusMsg.length() <= 40 ? m_strStatusMsg.length() : 40);
            sendKeyImportResponse(hKeyPart);
            return false;
         }
         else
         {
            memcpy_s(hKeyPart.sSTATUS,sizeof(hKeyPart.sSTATUS),"DATA KEY IMPORTED SUCCESSFULLY          ",40);
            Database::instance()->commit();
            Console::display("ST604","IMPORT IDK"); //completed
            IF::Trace::put("Import of Data Key completed successfully");
            KeyRing::instance()->resetKeys();
            sendKeyImportResponse(hKeyPart);
            return true;
         }
      }
   }
   return false;
  //## end database::AESKeyManager::handleKeyCommands%4C8138B303A6.body
}

bool AESKeyManager::importDataKey (const string& strTKCD,const string& strKey,const string& strDKCD,string& strErrorMsg,string& strConsoleMsg)
{
  //## begin database::AESKeyManager::importDataKey%4B1EAFE10007.body preserve=yes
   if(!checkEnvironment())
      return environmentWarning("Import Data Key");
   string strTPKeyId("TK");         //transport key id
   strTPKeyId.append(strTKCD);      //Transport Key check digits
   transform (strTPKeyId.begin(),strTPKeyId.end(),strTPKeyId.begin(),::toupper);
   string strDKeyId("DK");          //data key id
   strDKeyId.append(strDKCD);       //Data Key check digits
   transform (strDKeyId.begin(),strDKeyId.end(),strDKeyId.begin(),::toupper);
   string strDataKey = strKey;
   transform (strDataKey.begin(),strDataKey.end(),strDataKey.begin(),::toupper);
   IF::Trace::put("importDataKey");
   IF::Trace::put(strTPKeyId.c_str());
   IF::Trace::put(strDKeyId.c_str());
   if(KeyRing::instance()->getKey(strDKeyId))
      return true; //already have this one.
   AESKey* pTransportKey = (AESKey*)KeyRing::instance()->getTransportKey(strTPKeyId);
   if (!pTransportKey)
   {
      strConsoleMsg.assign("KEY FILE FAILURE - TRANSPORT KEY NOT FOUND");
      m_strStatusMsg.assign("Transport Key not found");
      return false;
   }
   unsigned char szRawKey[33];
   CodeTable::byteToNibble(strDataKey,szRawKey);
   szRawKey[32] = '\0';
   for (int i = 0; i < 2; i++)
      pTransportKey->decrypt_256(szRawKey + (i * 16));
   AESKey hDataKey;
   hDataKey.setRawKey((char*)szRawKey,32);
   hDataKey.setIdentifier(strDKeyId);
   hDataKey.computeCheckDigits();
   if(hDataKey.getCheckDigits() != strDKeyId.substr(2,4))
   {
      strConsoleMsg.assign("KEY FILE FAILURE - CHECK DIGIT MISMATCH");
      m_strStatusMsg.assign("Data Key Check Digit mismatch");
      return false;
   }
   //store key in TASK_CONTEXT with other keys
   //Data Keys use Id of DKxxxx where xxxx = Check Digits
   string strCONTEXT_DATA(strDKeyId);
   strCONTEXT_DATA.append("==");
   strCONTEXT_DATA.append((char*)szRawKey,32);
   strCONTEXT_DATA.append(",");
   strCONTEXT_DATA.append((char*)strDKeyId.substr(2,4).data(),4);
   strCONTEXT_DATA.append(",");
   strCONTEXT_DATA.append(Clock::instance()->getYYYYMMDDHHMMSS().data(),8);
   Key* pMasterKey = KeyRing::instance()->getKey("Master");
   if(!pMasterKey || !pMasterKey->encrypt(strCONTEXT_DATA))
   {
      strConsoleMsg.assign("KEY FILE FAILURE - MASTER KEY PROBLEM");
      m_strStatusMsg.assign("Data Key encrypt failure");
      return false;
   }
   strCONTEXT_DATA.resize(100,' ');
   strCONTEXT_DATA[99] = '3'; 
   string strCONTEXT_KEY;
   obfuscate(strDKeyId,strCONTEXT_KEY);
   Table hTable;
   if(!setColumns(hTable))
   {
      strConsoleMsg.assign("KEY FILE FAILURE - ADD KEY TO DB FAILED");
      m_strStatusMsg.assign("Query context table failure");
      return false;
   }
   hTable.set("CONTEXT_KEY",strCONTEXT_KEY);
   hTable.set("CONTEXT_DATA",strCONTEXT_DATA);
   auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   if (pInsertStatement->execute(hTable) == false)
   {
      strConsoleMsg.assign("KEY FILE FAILURE - ADD KEY TO DB FAILED");
      m_strStatusMsg.assign("Insert Data Key failure");
      return false;
   }
   Database::instance()->commit();
   KeyRing::instance()->resetKeys(); //pickup new key
   backup(); //ensure full set is available in most recent daily backup
   Database::instance()->commit();
   return true;
  //## end database::AESKeyManager::importDataKey%4B1EAFE10007.body
}

bool AESKeyManager::importSSLCertificate (const string& strPassPhrase)
{
  //## begin database::AESKeyManager::importSSLCertificate%55242CAB004A.body preserve=yes
   //remove any existing environment
   if(!deleteSSLEnvironment())
   {
      IF::Trace::put("importSSLCertificate: unable to remove existing environment",-1,true);
      Console::display("ST545","IMPORT OF SSL CERTIFICATE FAILED");
      return false;
   }
   SecurityWrapper::OPENSSL_init_crypto(OPENSSL_INIT_ADD_ALL_CIPHERS | OPENSSL_INIT_ADD_ALL_DIGESTS,NULL);
   SecurityWrapper::OPENSSL_init_crypto(OPENSSL_INIT_LOAD_CRYPTO_STRINGS,NULL);

   FlatFile hPKCS12File("PKCS12");
   if(!hPKCS12File.open(FlatFile::CX_OPEN_INPUT))
   {
      IF::Trace::put("importSSLCertificate: Unable to open PKCS12",-1,true);
      Console::display("ST545","IMPORT OF SSL CERTIFICATE FAILED");
      return false;
   }
   string strFileName = hPKCS12File.getDatasetName();
   FILE* fp = fopen(strFileName.c_str(),"rb");
   int iP12Len = 8 * 1024;
   unsigned char* szServerP12 = new unsigned char[iP12Len];
   size_t iBytesRead = 0;
   while (fread(szServerP12 + iBytesRead,1,1,fp) != 0)
   {
      iBytesRead++;
      if (iBytesRead == iP12Len)
      {
         IF::Trace::put("importSSLCertificate:  Allocated buffer is too small for certificate",-1,true);
         Console::display("ST545","IMPORT OF SSL CERTIFICATE FAILED");
         delete[] szServerP12;
         fclose(fp);
         return false;
      }
   }
   fclose(fp);
   if (iBytesRead == 0)
   {
      IF::Trace::put("importSSLCertificate:  Unable to read certificate file",-1,true);
      Console::display("ST545","IMPORT OF SSL CERTIFICATE FAILED");
      delete[] szServerP12;
      return false;
   }
   szServerP12[iBytesRead] = '\0';
   BIO* pBIO = SecurityWrapper::BIO_new_mem_buf(szServerP12,iBytesRead + 1);
   if (!pBIO)
   {
      IF::Trace::put("Unable to load Server PKCS12 file to BIO",-1,true);
      Console::display("ST545","IMPORT OF SSL CERTIFICATE FAILED");
      delete[] szServerP12;
      SecurityWrapper::BIO_free(pBIO);
      return false;
   }
   PKCS12* p12 = SecurityWrapper::d2i_PKCS12_bio(pBIO,NULL);
   if (p12 == 0)
   {
      IF::Trace::put("Unable to load PKCS12 from BIO",-1,true);
      Console::display("ST545","IMPORT OF SSL CERTIFICATE FAILED");
      delete[] szServerP12;
      SecurityWrapper::BIO_free(pBIO);
      return false;
   }
   EVP_PKEY* pKey = SecurityWrapper::EVP_PKEY_new();
   X509* pX509 = SecurityWrapper::X509_new();
   if (!SecurityWrapper::PKCS12_parse(p12,strPassPhrase.c_str(),(EVP_PKEY**)&pKey,(X509**)&pX509,NULL))
   {
      IF::Trace::put("Unable to parse Server PKCS12 file",-1,true);
      Console::display("ST545","IMPORT OF SSL CERTIFICATE FAILED");
      delete[] szServerP12;
      SecurityWrapper::BIO_free(pBIO);
      SecurityWrapper::EVP_PKEY_free(pKey);
      SecurityWrapper::X509_free(pX509);
      return false;
   }
   SecurityWrapper::PKCS12_free(p12);
   SecurityWrapper::BIO_free(pBIO);
   delete[] szServerP12;

   string strPassPhraseNew;
   if(!createPassPhrase(strPassPhraseNew))
   {
      IF::Trace::put("importSSLCertificate: Unable to create new pass phrase",-1,true);
      Console::display("ST545","IMPORT OF SSL CERTIFICATE FAILED");
      SecurityWrapper::EVP_PKEY_free(pKey);
      SecurityWrapper::X509_free(pX509);
      return false;
   }
   string strName("DataNavigator Server"); 
   if(!createPKCS12(strPassPhraseNew,strName,pKey,pX509))
   {
      IF::Trace::put("importSSLCertificate: Unable to save PKCS12",-1,true);
      Console::display("ST545","IMPORT OF SSL CERTIFICATE FAILED");
      SecurityWrapper::EVP_PKEY_free(pKey);
      SecurityWrapper::X509_free(pX509);
      return false;
   }
   SecurityWrapper::EVP_PKEY_free(pKey);
   SecurityWrapper::X509_free(pX509);
   if(!loadSSLEnvironment())
   {
      IF::Trace::put("importSSLCertificate: failed to reload SSL Environment",-1,true);
      return false;
   }
   Database::instance()->commit();
   IF::Trace::put("importSSLCertificate: Certificate successfully imported",-1,true);
   Console::display("ST604","SSL CERTIFICATE SUCCESSFULLY IMPORTED");
   return true;
  //## end database::AESKeyManager::importSSLCertificate%55242CAB004A.body
}

bool AESKeyManager::importTransportKey(const string& strContext)
{
   //## begin database::AESKeyManager::importTransportKey%4AF4497901FA.body preserve=yes
   UseCase hUseCase("DR","## DR100 ADD TRANSPORT KEY PART");
   if (!checkEnvironment())
      return environmentWarning("Import Transport Key");
   //strContext may contain "RESET TRANSPORT " command (or just "TRANSPORT " followed by:
   //Transport Key Check Digits(TKCD)-AES key part (64 chars)-Key Part Check Digits (KPCD)
   //Example:
   //                TKCD-..............................KEY PART..........................-KPCD
   //RESET TRANSPORT 6377-6DE5662A77BD7080C2CA8AE6B2C0CC609713D35CDF794A640A864EF547114708-74F1
   string strTemp = strContext;
   transform(strTemp.begin(),strTemp.end(),strTemp.begin(),::toupper);
   rtrim(strTemp);
   size_t pos = strTemp.find("TRANSPORT ");
   if (pos != string::npos)
      strTemp.assign(strTemp.substr(pos + 10));
   if (pos == string::npos || strTemp.length() != 74)
   {
      Console::display("ST545","TRANSPORT KEY FAILURE - INVALID COMMAND LENGTH");
      m_strStatusMsg.assign("Parse Transport cmd failure");
      IF::Trace::put("AESKeyManger: Error - Unable to parse Transport command",-1,true);
      return UseCase::setSuccess(false);
   }
   string strTPCD(strTemp.data(),4);
   string strKeyPart(strTemp.data() + 5,64);
   string strKPCD(strTemp.data() + 70,4);
   AESKey hAESKey(strKeyPart);
   hAESKey.computeCheckDigits(); 
   string strCheckDigits = hAESKey.getCheckDigits();
   string strKey = hAESKey.getKey();
   if (strCheckDigits != strKPCD)
   {
      Console::display("ST545","TRANSPORT KEY FAILURE - KEY PART CHECK DIGITS MISMATCH");
      m_strStatusMsg.assign("Key Part Check Digit mismatch");
      IF::Trace::put("AESKeyManger: Error - Transport Key Part Check Digit mismatch",-1,true);
      return UseCase::setSuccess(false);
   }
   //store key in TASK_CONTEXT with other keys
   //Transport Key parts use Id of Pxxxxn where xxxx = TPCD and n = 1,2,3
   string strKeyId("P");
   strKeyId.append(strTPCD.data(),4);
   strKeyId.append("1");
   if(KeyRing::instance()->getKey(strKeyId))
   {
      strKeyId.replace(5,1,"2");
      if(KeyRing::instance()->getKey(strKeyId))
         strKeyId.replace(5,1,"3");
   }
   string strCONTEXT_DATA(strKeyId);
   strCONTEXT_DATA.append("==");
   strCONTEXT_DATA.append((const char*)hAESKey.getRawKey(),32);
   strCONTEXT_DATA.append(",");
   strCONTEXT_DATA.append(strKPCD.data(),4);
   strCONTEXT_DATA.append(",");
   strCONTEXT_DATA.append(Clock::instance()->getYYYYMMDDHHMMSS().data(),8);
   Key* pMasterKey = KeyRing::instance()->getKey("Master");
   if(!pMasterKey)
   {
      //generate master key 1st time
      //first make sure environment not already there
      Query hQuery;
      if(!bind(hQuery,true,false,false))
      {
         IF::Trace::put("Import Transport Key failed - "
            "Query of context table failed",-1,true);
         return false;
      }
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if(!pSelectStatement->execute(hQuery) || m_lCount > 0)
      {
         IF::Trace::put("Import Transport Key failed - "
            "Master Key not found but key DB not empty",-1,true);
         return false;
      }
      if(!createMasterKey())
      {
         IF::Trace::put("Import Transport Key failed - "
            "Unable to initialize Master Key",-1,true);
         return false;
      }
      pMasterKey = KeyRing::instance()->getKey("Master");
   }
   if(!pMasterKey)
   {
      IF::Trace::put("Import Transport Key failed - "
         "Unable to initialize or create Master Key",-1,true);
      return false;
   }
   if(!pMasterKey->encrypt(strCONTEXT_DATA))
   {
      Console::display("ST545","KEY FILE FAILURE - MASTER KEY PROBLEM");
      m_strStatusMsg.assign("Key Part encrypt failure");
      IF::Trace::put("AESKeyManger: Error-Unable to encrypt Key Part with Master Key",-1,true);
      return UseCase::setSuccess(false);
   }
   strCONTEXT_DATA.resize(100,' ');
   strCONTEXT_DATA[99] = '3'; 
   string strCONTEXT_KEY;
   obfuscate(strKeyId,strCONTEXT_KEY);
   Table hTable;
   if(!setColumns(hTable))
   {
      Console::display("ST545","KEY FILE FAILURE - ADD KEY TO DB FAILED");
      m_strStatusMsg.assign("Query context table failed");
      IF::Trace::put("AESKeyManger: Error-Unable to add Transport Key Part to Database",-1,true);
      return UseCase::setSuccess(false);
   }
   hTable.set("CONTEXT_KEY",strCONTEXT_KEY);
   hTable.set("CONTEXT_DATA",strCONTEXT_DATA);
   auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   if (pInsertStatement->execute(hTable) == false)
   {
      Console::display("ST545","KEY FILE FAILURE - ADD KEY TO DB FAILED");
      m_strStatusMsg.assign("Insert Transport Key Part failed");
      IF::Trace::put("AESKeyManger: Error-Unable to add Transport Key Part to Database",-1,true);
      return UseCase::setSuccess(false);
   }
   UseCase::addItem();
   Database::instance()->commit();
   KeyRing::instance()->resetKeys(); //pickup new key
   backup(); //ensure full set is available in most recent daily backup
   Database::instance()->commit();
   return true;
  //## end database::AESKeyManager::importTransportKey%4AF4497901FA.body
}

bool AESKeyManager::initialize ()
{
  //## begin database::AESKeyManager::initialize%497498EC02B1.body preserve=yes
   setActive(KeyRing::instance()->getActive());
   return true;
  //## end database::AESKeyManager::initialize%497498EC02B1.body
}

bool AESKeyManager::initSSLEnvironment ()
{
  //## begin database::AESKeyManager::initSSLEnvironment%551441530381.body preserve=yes
   SecurityWrapper::OPENSSL_init_crypto(OPENSSL_INIT_ADD_ALL_CIPHERS | OPENSSL_INIT_ADD_ALL_DIGESTS,NULL);

   //remove any existing environment
   if(!deleteSSLEnvironment())
   {
      IF::Trace::put("initSSLEnvironment: unable to remove existing environment",-1,true);
      return false;
   }
   string strPassPhrase;
   if(!createPassPhrase(strPassPhrase))
   {
      IF::Trace::put("initSSLEnvironment: unable to create new pass phrase",-1,true);
      return false;
   }
   RSA* pRSA = SecurityWrapper::RSA_generate_key(
            2048,   /* number of bits for the key - 2048 is a sensible value */
            RSA_F4, /* exponent - RSA_F4 is defined as 0x10001L */
            NULL,   /* callback - can be NULL if we aren't displaying progress */
            NULL    /* callback argument - not needed in this case */
   );
   if(pRSA ==NULL)
   {
      IF::Trace::put("initSSLEnvironment: unable to generate RSA Key pair",-1,true);
      Database::instance()->rollback();
      return false;
   }
   EVP_PKEY * pKey = SecurityWrapper::EVP_PKEY_new();
   SecurityWrapper::EVP_PKEY_assign_RSA(pKey,pRSA);

   //build self signed certificate
   X509 * pX509 = SecurityWrapper::X509_new();
   SecurityWrapper::X509_gmtime_adj(X509_get_notBefore(pX509),0); //not before current time
   SecurityWrapper::X509_gmtime_adj(X509_get_notAfter(pX509),946080000L); //946080000L 10950 days = (30 yrs) = (60 sec*60 min*24 hrs*365 days*30 yrs).
   SecurityWrapper::X509_set_pubkey(pX509,pKey);
   X509_NAME * name;
   name = SecurityWrapper::X509_get_subject_name(pX509);
   SecurityWrapper::X509_NAME_add_entry_by_txt(name,"C", MBSTRING_ASC,(unsigned char *)"US",-1,-1,0); //country code
   SecurityWrapper::X509_NAME_add_entry_by_txt(name,"O", MBSTRING_ASC,(unsigned char *)"FIS",-1,-1,0); //organization
   SecurityWrapper::X509_NAME_add_entry_by_txt(name,"CN",MBSTRING_ASC,(unsigned char *)"localhost",-1,-1,0); //common name
   SecurityWrapper::X509_set_issuer_name(pX509,name); //self-signed certificate set the name of the issuer to the name of the subject
   SecurityWrapper::X509_sign(pX509,pKey,EVP_sha256()); //sign the certificate

   //create PKCS12 structure for storing Private key and certificate
   string strName("DataNavigator Server"); 
   if(!createPKCS12(strPassPhrase,strName,pKey,pX509))
   {
      IF::Trace::put("initSSLEnvironment: error creating PKCS#12 structure",-1,true);
      SecurityWrapper::EVP_PKEY_free(pKey);
      SecurityWrapper::X509_free(pX509);
      return false;
   }
   SecurityWrapper::EVP_PKEY_free(pKey);
   SecurityWrapper::X509_free(pX509);
   loadSSLEnvironment();
   exportSSLCertificate();
   return true;
  //## end database::AESKeyManager::initSSLEnvironment%551441530381.body
}

bool AESKeyManager::loadSSLEnvironment ()
{
  //## begin database::AESKeyManager::loadSSLEnvironment%5604328E02CA.body preserve=yes
   Query hQuery;
   hQuery.setQualifier("QUALIFY","DN_KEYSTORE");
   hQuery.bind("DN_KEYSTORE","KEY_VALUE",reusable::Column::STRING,&m_strPassPhrase);
   hQuery.setBasicPredicate("DN_KEYSTORE","KEY_TYPE","=","SPP");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if(!pSelectStatement->execute(hQuery) || pSelectStatement->getRows() != 1 )
   {
      string strErrorMsg[2];
      strErrorMsg[0] = "loadSSLEnvironment: Server pass phrase for PKCS12 file not found";
      //try to load environment from PEM files and DSPEC value
      bool bLoadFromFile = true;
      char szBuffer[100];
      size_t m = 0;
      m_strServerPrivateKey.erase();
      m_strServerCertificate.erase();
      m_strServerPrivateKeyPhrase.erase();
      FlatFile hPKEYFile("SVRPKEY");
      if (!hPKEYFile.open(FlatFile::CX_OPEN_INPUT))
      {
         strErrorMsg[1] = "Unable to open Server Private Key PEM File (SVRPKEY)";
         bLoadFromFile = false;
      }
      if (bLoadFromFile)
      {
         hPKEYFile.read(szBuffer,80,&m);
         while (m > 0)
         {
            m_strServerPrivateKey.append(szBuffer,m);
            m_strServerPrivateKey.append("\n");
            hPKEYFile.read(szBuffer,80,&m);
         }
         hPKEYFile.close();
         if (m_strServerPrivateKey.length() == 0)
         {
            bLoadFromFile = false;
            strErrorMsg[1] = "Unable to read Server Private Key PEM File (SVRPKEY)";
         }
      }
      //try to load certificate from PEM file
      FlatFile hServerCertFile("SVRCERT");
      if (bLoadFromFile)
      {
         if (!hServerCertFile.open(FlatFile::CX_OPEN_INPUT))
         {
            strErrorMsg[1] = "Unable to open Server Certificate PEM File (SVRCERT)";
            bLoadFromFile = false;
         }
      }
      if (bLoadFromFile)
      {
         hServerCertFile.read(szBuffer,80,&m);
         while (m > 0)
         {
            m_strServerCertificate.append(szBuffer,m);
            m_strServerCertificate.append("\n");
            hServerCertFile.read(szBuffer,80,&m);
         }
         hServerCertFile.close();
         if (m_strServerCertificate.length() == 0)
         {
            bLoadFromFile = false;
            strErrorMsg[1] = "Unable to read Server Certificate PEM File (SVRCERT)";
         }
      }
      //get passphrase from "DSPEC   SVRPKPWD"
      if (bLoadFromFile)
      {
         Extract::instance()->getSpec("SVRPKPWD",m_strServerPrivateKeyPhrase);
         if (m_strServerPrivateKeyPhrase.length() == 0)
         {
            bLoadFromFile = false;
            strErrorMsg[1] = "Unable to find Server Private Key Passphrase DSPEC SVRPKPWD";
         }
         else
            bLoadFromFile = AdvancedEncryptionStandard::decrypt(m_strServerPrivateKeyPhrase);
      }
      if (bLoadFromFile)
         return true;
      IF::Trace::put(strErrorMsg[0].c_str(),-1,true);
      IF::Trace::put(strErrorMsg[1].c_str(),-1,true);
      Database::instance()->rollback();
      return false;
   }
   m_strServerP12.erase();
   hQuery.reset();
   hQuery.attach(this);
   hQuery.setIndex(1);
   hQuery.setQualifier("QUALIFY","DN_KEYSTORE");
   hQuery.bind("DN_KEYSTORE","KEY_VALUE",reusable::Column::STRING,&m_strServerP12Partial);
   hQuery.setBasicPredicate("DN_KEYSTORE","KEY_TYPE","LIKE","SERVER%");
   hQuery.setOrderByClause("KEY_TYPE ASC");
   if(!pSelectStatement->execute(hQuery) || pSelectStatement->getRows() == 0)
   {
      IF::Trace::put("loadSSLEnvironment: PKCS12 file not found",-1,true);
      Database::instance()->rollback();
      return false;
   }
   Database::instance()->commit();
   //decrypt the pass phrase
   if(m_strPassPhrase.substr(0, 6) != ">DSS*<")
      SecurityWrapper::base64Decode(m_strPassPhrase);

   string strAESKeyId = "DK" + m_strPassPhrase.substr(8,4);
   AESKey* pAESKey = (AESKey*)KeyRing::instance()->getKey(strAESKeyId);
   if(!pAESKey)
   {
      string strError("loadSSLEnvironment: Unable to load Data Key " + strAESKeyId + " for pass phrase");
      IF::Trace::put(strError.data(),strError.length(),true);
      return false;
   }
   m_strPassPhrase.erase(0,20);
   if(!pAESKey->decrypt(m_strPassPhrase))
   {
      IF::Trace::put("loadSSLEnvironment: Unable to decrypt pass phrase",-1,true);
      return false;
   }
   return true;
  //## end database::AESKeyManager::loadSSLEnvironment%5604328E02CA.body
}
bool AESKeyManager::loadSSLEnvironment (void** pKey,void** x509,void** p12)
{
  //## begin database::AESKeyManager::loadSSLEnvironment%55198C3C0237.body preserve=yes
   SecurityWrapper::OPENSSL_init_crypto(OPENSSL_INIT_ADD_ALL_CIPHERS | OPENSSL_INIT_ADD_ALL_DIGESTS,NULL);
   SecurityWrapper::OPENSSL_init_crypto(OPENSSL_INIT_LOAD_CRYPTO_STRINGS,NULL);
   if (m_strServerCertificate.length() != 0 && m_strServerPrivateKey.length() != 0 && m_strServerPrivateKeyPhrase.length() != 0)
   {
      BIO* pBIO = SecurityWrapper::BIO_new(SecurityWrapper::BIO_s_mem());
      SecurityWrapper::BIO_write(pBIO,(const void*)m_strServerPrivateKey.data(),m_strServerPrivateKey.length());
      if (!PEM_read_bio_PrivateKey(pBIO,(EVP_PKEY**)pKey,NULL,(void*)m_strServerPrivateKeyPhrase.c_str()))
      {
         IF::Trace::put("Unable to read Server Private PEM file from bio",-1,true);
         SecurityWrapper::BIO_free(pBIO);
         return false;
      }
      SecurityWrapper::BIO_free(pBIO);
      //load Server Certificate
      pBIO = SecurityWrapper::BIO_new(SecurityWrapper::BIO_s_mem());
      SecurityWrapper::BIO_write(pBIO,(const void*)m_strServerCertificate.data(),m_strServerCertificate.length());
      if (!SecurityWrapper::PEM_read_bio_X509(pBIO,(X509**)x509,NULL,NULL))
      {
         IF::Trace::put("Unable to read Server Certificate PEM file from bio",-1,true);
         SecurityWrapper::BIO_free(pBIO);
         return false;
      }
      SecurityWrapper::BIO_free(pBIO);
      return true;
   }
   if(m_strPassPhrase.length() < 32 || m_strPassPhrase.substr(0,6) == ">DSS*<" || m_strServerP12.length() == 0)
      return false;
   //Convert P12 file to binary
   int iLenP12 = m_strServerP12.length()/2;
   unsigned char* szServerP12 = new unsigned char[iLenP12]; 
   CodeTable::byteToNibble(m_strServerP12,szServerP12);
   BIO* pBIO = SecurityWrapper::BIO_new_mem_buf(szServerP12,iLenP12);
   if(!pBIO)
   {
      IF::Trace::put("Unable to load Server PKCS12 file to bio",-1,true);
      delete[] szServerP12;
      SecurityWrapper::BIO_free(pBIO);
      return false;
   }
   *p12 = SecurityWrapper::d2i_PKCS12_bio(pBIO,(PKCS12**)p12);
   if (*p12 == 0) 
   {
      IF::Trace::put("Unable to load Server PKCS12 file to bio",-1,true);
      delete[] szServerP12;
      SecurityWrapper::BIO_free(pBIO);
      return false;
   }
   if (!SecurityWrapper::PKCS12_parse(*(PKCS12**)p12,m_strPassPhrase.c_str(),(EVP_PKEY**)pKey,(X509**)x509,NULL))
   {
      IF::Trace::put("Unable to parse Server PKCS12 file",-1,true);
      delete[] szServerP12;
      SecurityWrapper::BIO_free(pBIO);
      return false;
   }
   delete[] szServerP12;
   SecurityWrapper::BIO_free(pBIO);
   return true;
  //## end database::AESKeyManager::loadSSLEnvironment%55198C3C0237.body
}

string AESKeyManager::nYYJJJ (const string& strDate)
{
  //## begin database::AESKeyManager::nYYJJJ%4A087BB902EC.body preserve=yes
   if(strDate.length() < 6)
      return "00000"; //should never be less than 6
   if(strDate.data()[0] != '2')
      return strDate.substr(1); //return YYJJJ
   Date hDate(atoi(strDate.substr(0,4).c_str()),atoi(strDate.substr(4,2).c_str()),1);
   return hDate.asString("%y%j"); //return YYJJJ
  //## end database::AESKeyManager::nYYJJJ%4A087BB902EC.body
}

bool AESKeyManager::obfuscate (const string& strYYYYMM,string& strText)
{
  //## begin database::AESKeyManager::obfuscate%497733A9006B.body preserve=yes
   //obfuscated date for use as uniqueness key
   strText.assign("F2B89C");
   strText.append(strYYYYMM);
   strText.append("X4b1077");
   AESKey::generateDigest(strText);
   return true;
  //## end database::AESKeyManager::obfuscate%497733A9006B.body
}

bool AESKeyManager::readKeyFile (const string& strImageId,const string& strTaskId)
{
  //## begin database::AESKeyManager::readKeyFile%4AF4498C000F.body preserve=yes
   UseCase hUseCase("DR","## DR35 READ KEY FILE");
   if(!checkEnvironment())
      return environmentWarning("Read Key File");
    FlatFile hKeyFile("IDKFILE");
   hKeyFile.setName("IDKFILE");
   if(!hKeyFile.open(FlatFile::CX_OPEN_INPUT))
   {
      Console::display( "ST242","IDKFILE ",
      (hKeyFile.getName().length () > 35 ) ?
         (hKeyFile.getName().substr( 0,32 ) + "...").c_str() : hKeyFile.getName().c_str());
      return UseCase::setSuccess(false);
   }
   int iRecNum = 1;
   char szMsg[100];
   char szRecord[100];
   size_t iLength=0;
   while(hKeyFile.read(szRecord,100,&iLength))
   {
      int iOffset = snprintf(szMsg,sizeof(szMsg),"Read IDKFILE failed on record number %d -",iRecNum);
      if(iLength < 74)
      {
         Console::display("ST545","KEY FILE FAILURE - INVALID RECORD SIZE ENCOUNTERED");
         memcpy_s(szMsg+iOffset,sizeof(szMsg)-iOffset,"Invalid record size encountered",31);
         IF::Trace::put(szMsg,iOffset+31,true);
         Database::instance()->rollback();
         return UseCase::setSuccess(false);
      }
      //parse record
      string strTKCD(szRecord,4);
      string strKey(szRecord+5,64);
      string strDKCD(szRecord+70,4);
      string strErrorMsg;
      string strConsoleMsg;
      if(!importDataKey(strTKCD,strKey,strDKCD,strErrorMsg,strConsoleMsg))
      {
         Console::display("ST545",strConsoleMsg.c_str());
         memcpy_s(szMsg+iOffset,sizeof(szMsg) - iOffset,strErrorMsg.data(),strErrorMsg.length());
         IF::Trace::put(szMsg,iOffset+strErrorMsg.length(),true);
         Database::instance()->rollback();
         return UseCase::setSuccess(false);
      }
      UseCase::addItem();
   }
   Console::display("ST604","KEYFILE"); //completed
   IF::Trace::put("processing of key file completed successfully",-1,true);
   return UseCase::setSuccess(true);
  //## end database::AESKeyManager::readKeyFile%4AF4498C000F.body
}

bool AESKeyManager::reencryptTokens (const string& strYYYYMM)
{
  //## begin database::AESKeyManager::reencryptTokens%49DE185D02A7.body preserve=yes
   if(!getActive())
      return true;
   if(!checkEnvironment())
      return environmentWarning("Re-encrypt Tokens");
   if(!KeyRing::instance()->getKey(strYYYYMM))
   {
      if(!createKey(strYYYYMM))
      {
         char szMessage[100];
         IF::Trace::put(szMessage,
            snprintf(szMessage,sizeof(szMessage),
            "Re-encryption of tokens failed: cannot create key: %s",
            strYYYYMM.c_str()),true);
         return false;
      }
   }
   m_strYYYYMM = strYYYYMM;
   {
      Query hQuery;
      hQuery.setIndex(3);
      hQuery.attach(this);
      hQuery.setQualifier("QUALIFY","DN_SYMBOLS");
      hQuery.bind("DN_SYMBOLS","SEQ_NO",Column::LONG,&m_iSEQ_NO);
      hQuery.bind("DN_SYMBOLS","DN_SYMBOL",Column::STRING,&m_strTOKEN);
      hQuery.bind("DN_SYMBOLS","SYMBOL_ID",Column::STRING,&m_strDATE);
      hQuery.setBasicPredicate("DN_SYMBOLS","SEQ_NO","BETWEEN"," 1 AND 25 ");
      hQuery.setOrderByClause("SEQ_NO ASC");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery) || hQuery.getAbort() == true)
      {
         Database::instance()->rollback();
         return false;
      }
   }
   if(nYYJJJ(m_strYYYYMM) > nYYJJJ(m_strDATE))
   {  
      //if we actually changed the token encryption then change Master Key also
      if(!changeMasterKey()) //performs backup() and commit/rollback as appropriate
         return false;
   }
   return true;
  //## end database::AESKeyManager::reencryptTokens%49DE185D02A7.body
}

bool AESKeyManager::reencryptTokens ()
{
  //## begin database::AESKeyManager::reencryptTokens%49F09AF502D8.body preserve=yes
   //get todays date in Julian format
   Date hDate(Date::today());
   string strNYYJJJ;
   char szNYYJJJ[7];
   for(int i = 1; i <10; i++)
   {
      if(i == 2)
         continue; //skip 2 to avoid confusion with YYYYMM dates
      strNYYJJJ.assign(szNYYJJJ,
         snprintf(szNYYJJJ,sizeof(szNYYJJJ),"%d%s",i,hDate.asString("%y%j").c_str()));
      if(!KeyRing::instance()->getKey(strNYYJJJ))
         break;
   }
   return reencryptTokens(strNYYJJJ);
  //## end database::AESKeyManager::reencryptTokens%49F09AF502D8.body
}

bool AESKeyManager::setDefaultDataKey (const string& strKeyId)
{
  //## begin database::AESKeyManager::setDefaultDataKey%4C3B6CFA0156.body preserve=yes
   //verify that key exists
   if(!checkEnvironment())  //also force reload of keys
      return environmentWarning("Set Default Data Key");
   if(!KeyRing::instance()->getKey(strKeyId))
      return false;
   Table hTable;
   if(!setColumns(hTable))
   {
      Database::instance()->rollback();
      return false;
   }
   hTable.set("CONTEXT_KEY","DEFAULT_DATA_KEY",false,true);
   hTable.set("CONTEXT_DATA",strKeyId);
   auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if(!pUpdateStatement->execute(hTable) )
   {
      if(pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      {
         auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         if(pInsertStatement->execute(hTable))
            return true;
      }
      Database::instance()->rollback();
      return false;
   }
   return true;
  //## end database::AESKeyManager::setDefaultDataKey%4C3B6CFA0156.body
}

bool AESKeyManager::setDefaultTransportKey (const string& strKeyId)
{
  //## begin database::AESKeyManager::setDefaultTransportKey%4C3B6CE70089.body preserve=yes
   if(!checkEnvironment())
      return environmentWarning("Set Default Transport Key");
   if(!KeyRing::instance()->getTransportKey(strKeyId))
      return false;
   Table hTable;
   if(!setColumns(hTable))
   {
      Database::instance()->rollback();
      return false;
   }
   hTable.set("CONTEXT_KEY","DEFAULT_TRANSPORT_KEY",false,true);
   hTable.set("CONTEXT_DATA",strKeyId);
   auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if(!pUpdateStatement->execute(hTable))
   {
      if(pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      {
         auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         if(pInsertStatement->execute(hTable))
            return true;
      }
      Database::instance()->rollback();
      return false;
   }
   return true;
  //## end database::AESKeyManager::setDefaultTransportKey%4C3B6CE70089.body
}

void AESKeyManager::update (Subject* pSubject)
{
  //## begin database::AESKeyManager::update%4974957C0175.body preserve=yes
   if (((Query*)pSubject)->getIndex() == 1)
   {
      m_strServerP12.append(m_strServerP12Partial);
   }
   else
   if (((Query*)pSubject)->getIndex() == 3)
   {  //reencryptTokens
      //only re-encrypt if new date (m_strYYYYMM) is > existing date (m_strDATE)
      //dates can be nYYJJJ or YYYYMM format so need to normalize first
      if(nYYJJJ(m_strYYYYMM) <= nYYJJJ(m_strDATE))
         return;
      string strDecryptedTokens;
      while(m_strTOKEN.length() >= 88)
      {
         string strTemp(m_strTOKEN.data(),86);
         strTemp.append("==");
         if(!KeyRing::instance()->decrypt(m_strDATE,strTemp))
         {
            ((Query*)pSubject)->setAbort(true);
            return;
         }
         strDecryptedTokens.append(strTemp);
         m_strTOKEN.erase(0,88);
      }
      Table hTable("DN_SYMBOLS");
      hTable.setQualifier("QUALIFY");
      while(strDecryptedTokens.length() >= 64)
      {
         string strTemp(strDecryptedTokens.substr(0,64));
         if (!KeyRing::instance()->encrypt(m_strYYYYMM,strTemp))
         {
            ((Query*)pSubject)->setAbort(true);
            return;
         }
         strTemp.erase(strTemp.length()-2,2);
         m_strTOKEN.append(strTemp);
         m_strTOKEN.append(strTemp.data()+42,2);
         strDecryptedTokens.erase(0,64);
      }
      hTable.set("SEQ_NO",m_iSEQ_NO,true,"=");
      hTable.set("DN_SYMBOL",m_strTOKEN);
      hTable.set("SYMBOL_ID",m_strYYYYMM); //new key date
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      if(!pUpdateStatement->execute(hTable))
      {
         if(pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
         {
            auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
            if(pInsertStatement->execute(hTable))
               return;
         }
         ((Query*)pSubject)->setAbort(true);
      }
   }
   else
   if(((Query*)pSubject)->getIndex() == 4)
   {  //backup tokens
      char szBuffer[3016];
      string strText(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"%08d:%s:%s",
         m_iSEQ_NO,m_strDATE.c_str(),m_strTOKEN.c_str()));
      m_hExportFile.write(strText.data(),strText.length());
   }
   else
   if(((Query*)pSubject)->getIndex() == 5)
   {
      if(m_strCONTEXT_KEY[0] == m_hMasterSeed[0].getCONTEXT_KEY())
         m_strCONTEXT_DATA[1] =  m_hMasterSeed[1].getCONTEXT_DATA();
      else
      {
         //decrypt with old key,re-encrypt with new key
         if(m_strCONTEXT_KEY[0].length() < 32)
            return; //skip Default key assignments
         if(m_strCONTEXT_DATA[0].length() == 100 && m_strCONTEXT_DATA[0][99] != ' ')
         {  //handle new AES 256 bit keys which have a 2 or 3 in column 100
            char c = m_strCONTEXT_DATA[0][99];
            if (c == '3')
               m_strCONTEXT_DATA[0].resize(88);
            else
               m_strCONTEXT_DATA[0].resize(64);
            m_strCONTEXT_DATA[1] = m_strCONTEXT_DATA[0];
            m_hMasterKey[0].decrypt(m_strCONTEXT_DATA[1]);
            m_hMasterKey[1].encrypt(m_strCONTEXT_DATA[1]);
            m_strCONTEXT_DATA[1].resize(100,' ');
            m_strCONTEXT_DATA[1][99] = c;
         }
         else
         {
            m_strCONTEXT_DATA[1] = m_strCONTEXT_DATA[0];
            m_hMasterKey[0].decrypt(m_strCONTEXT_DATA[1]);
            m_hMasterKey[1].encrypt(m_strCONTEXT_DATA[1]);
         }
      }
      Table hTable;
      if(!setColumns(hTable))
      {
         ((Query*)pSubject)->setAbort(true);
         return;
      }
      hTable.set("CONTEXT_KEY",m_strCONTEXT_KEY[0],false,true,"=");
      hTable.set("CONTEXT_DATA",m_strCONTEXT_DATA[1]);
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      if(!pUpdateStatement->execute(hTable))
         ((Query*)pSubject)->setAbort(true);
   }
  //## end database::AESKeyManager::update%4974957C0175.body
}

void AESKeyManager::sendKeyListResponse ()
{
  //## begin database::AESKeyManager::sendKeyListResponse%4C8143990092.body preserve=yes
#include "CXODRU32.hpp"
   struct hDescription
   {
      char sColumnName[18];
      short int nDataType;
      int nPrecision;
      short int nScale;
   };
#include "CXODRU33.hpp"
   ResultSet hResultSet;
   int j = 3;
   char* pszColumnName[3] = {"KEYID","TYPE","DEFAULT"};
   int nPrecision[3] = {7,10,2};
   int k = 4 + (j * sizeof(struct hDescription));
   char* pDescription = new char[k];
   memset(pDescription,' ',k);
   memcpy_s(pDescription,sizeof(int),&j,sizeof(int));
   hDescription* p = (hDescription*)(pDescription + 4);
   for (int i = 0;i < j;++i)
   {
      memcpy_s(p->sColumnName,sizeof(p->sColumnName),pszColumnName[i],strlen(pszColumnName[i]));
      p->nDataType = htons(1);
      p->nPrecision = htonl(nPrecision[i]);
      p->nScale = htons(0);
      ++p;
   }
   string strDefaultDataKey = KeyRing::instance()->getDefaultDataKey();
   string strDefaultTransportKey = KeyRing::instance()->getDefaultTransportKey();
   vector<string> hKeyList;
   KeyRing::instance()->getKeyList(hKeyList);
   vector<string>::iterator q;
   struct sKey hKey;
   for(q = hKeyList.begin(); q != hKeyList.end(); q++)
   {
      memset((char*)&hKey,' ',sizeof(struct sKey));
      memcpy_s(hKey.sId,sizeof(hKey.sId),(*q).data(),(*q).size());
      if(hKey.sId[0] == 'D')
      memcpy_s(hKey.sType,sizeof(hKey.sType),"DATA     ",9);
      else if(hKey.sId[0] == 'T')
         memcpy_s(hKey.sType,sizeof(hKey.sType),"TRANSPORT",9);
      else if(hKey.sId[0] == 'P' )
         memcpy_s(hKey.sType,sizeof(hKey.sType),"KEY-PART ",9);
      if((*q) == strDefaultDataKey || (*q) == strDefaultTransportKey)
         memcpy_s(hKey.sDefault,sizeof(hKey.sDefault),"Y",1);
      else
         memcpy_s(hKey.sDefault,sizeof(hKey.sDefault),"N",1);
      hResultSet.addRow(pDescription,(char*)&hKey);
   }
   hResultSet.close();
   delete [] pDescription;
  //## end database::AESKeyManager::sendKeyListResponse%4C8143990092.body
}

void AESKeyManager::sendKeyImportResponse (struct sKeyPart& hKeyPart)
{
  //## begin database::AESKeyManager::sendKeyImportResponse%4C8143AE021A.body preserve=yes
#include "CXODRU32.hpp"
   struct hDescription
   {
      char sColumnName[18];
      short int nDataType;
      int nPrecision;
      short int nScale;
   };
#include "CXODRU33.hpp"
   ResultSet hResultSet;
   int j = 4;
   char* pszColumnName[4] = {"TKCD","KEY ","KPCD","STATUS"};
   int nPrecision[4] = {5,33,5,41};
   int k = 4 + (j * sizeof(struct hDescription));
   char* pDescription = new char[k];
   memset(pDescription,' ',k);
   memcpy_s(pDescription,sizeof(int),&j,sizeof(int));
   hDescription* p = (hDescription*)(pDescription + 4);
   for (int i = 0;i < j;++i)
   {
      memcpy_s(p->sColumnName,sizeof(p->sColumnName),pszColumnName[i],strlen(pszColumnName[i]));
      p->nDataType = htons(1);
      p->nPrecision = htonl(nPrecision[i]);
      p->nScale = htons(0);
      ++p;
   }
   hResultSet.addRow(pDescription,(char*)&hKeyPart);
   hResultSet.close();
   delete [] pDescription;
  //## end database::AESKeyManager::sendKeyImportResponse%4C8143AE021A.body
}

bool AESKeyManager::setColumns (reusable::Table& hTable)
{
  //## begin database::AESKeyManager::setColumns%5604213E0146.body preserve=yes
   int lCount = 0;
   Query hQuery;
   hQuery.bind("TASK_CONTEXT","*",reusable::Column::LONG,&lCount,0,"COUNT");
   hQuery.setBasicPredicate("TASK_CONTEXT","IMAGEID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=","*");
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","K");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return false;
   if(lCount == 0)
   {  //use TASK_CONTEXT_COMN
      hTable.setName("TASK_CONTEXT_COMN");
      hTable.setQualifier("QUALIFY");
      hTable.set("IMAGE_ID","*",false,true);
      hTable.set("TASK_ID","*",false,true);
      hTable.set("CONTEXT_TYPE","K",false,true);
   }
   else
   {  //Use TASK_CONTEXT
      hTable.setName("TASK_CONTEXT");
      hTable.set("IMAGEID","*",false,true);
      hTable.set("TASKID","*",false,true);
      hTable.set("CONTEXT_TYPE","K",false,true);
   }
   return true;
  //## end database::AESKeyManager::setColumns%5604213E0146.body
}

bool AESKeyManager::setDefaultAESDataKey (const string& strKeyId)
{
  //## begin database::AESKeyManager::setDefaultAESDataKey%55143C4F0206.body preserve=yes
   //verify that key exists
   if(!checkEnvironment())
      return environmentWarning("Set Default AES Data Key");
   if(!KeyRing::instance()->getKey(strKeyId))
      return false;
   Table hTable;
   if(!setColumns(hTable))
      return false;
   hTable.set("CONTEXT_KEY","DEFAULT_AES_DATA_KEY",false,true);
   hTable.set("CONTEXT_DATA",strKeyId);
   auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if(!pUpdateStatement->execute(hTable) )
   {
      if(pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      {
         auto_ptr<Statement> pInsertStatement ((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         if(pInsertStatement->execute(hTable))
            return true;
      }
      Database::instance()->rollback();
      return false;
   }
   return true;
  //## end database::AESKeyManager::setDefaultAESDataKey%55143C4F0206.body
}

// Additional Declarations
  //## begin database::AESKeyManager%49748F87033F.declarations preserve=yes
void AESKeyManager::initializeKeyGenerator()
{
   BIO* pBIO = SecurityWrapper::BIO_new(SecurityWrapper::BIO_s_mem());
   RSA* pRSA = NULL;
   pRSA = SecurityWrapper::RSA_generate_key(2048,65537,NULL,NULL);
   SecurityWrapper::PEM_write_bio_RSA_PUBKEY(pBIO,pRSA);
   SecurityWrapper::BIO_ctrl(pBIO,BIO_CTRL_FLUSH,0,NULL);
   void* ptr = 0;
   long sz = SecurityWrapper::BIO_get_mem_data(pBIO,&ptr);
   char psPublicKey[4096];
   memcpy_s(psPublicKey,sizeof(psPublicKey),ptr,sz);
   SecurityWrapper::BIO_ctrl(pBIO,BIO_CTRL_SET_CLOSE,BIO_NOCLOSE,NULL);
   SecurityWrapper::BIO_free(pBIO);
   string strDigest(psPublicKey,sz);
   const EVP_MD* md = SecurityWrapper::EVP_sha512();   //sha512 algorithm (64 char digest)
   //EVP_MD_CTX* mdctx = SecurityWrapper::EVP_MD_CTX_new(); //openssl_1.1.0e
   EVP_MD_CTX* mdctx = SecurityWrapper::EVP_MD_CTX_new();
   unsigned char md_value[EVP_MAX_MD_SIZE];
   unsigned int md_len;
   SecurityWrapper::EVP_MD_CTX_reset(mdctx);
   SecurityWrapper::EVP_DigestInit_ex(mdctx,md,NULL);
   SecurityWrapper::EVP_DigestUpdate(mdctx,strDigest.c_str(),strDigest.length());
   SecurityWrapper::EVP_DigestFinal_ex(mdctx,md_value,&md_len);
   SecurityWrapper::EVP_MD_CTX_reset(mdctx);
   SecurityWrapper::EVP_MD_CTX_free(mdctx);
   memcpy_s(m_szKeyGenerator,sizeof(m_szKeyGenerator),(const char*)md_value,md_len);
}
string AESKeyManager::generateKey2()
{
   if (m_szKeyGenerator[0] = ' ')
      initializeKeyGenerator();
   string strKey;
   for (int i = 0; i < 32; i++)
   {
      int n = RANDOM(64);
      strKey.append(&m_szKeyGenerator[n],1);
   }
   return strKey;
}
string AESKeyManager::testGenerateKey()
{
   BIO* pBIO = SecurityWrapper::BIO_new(SecurityWrapper::BIO_s_mem());
   RSA* pRSA = NULL;
   pRSA = SecurityWrapper::RSA_generate_key(2048,65537,NULL,NULL);
   SecurityWrapper::PEM_write_bio_RSA_PUBKEY(pBIO,pRSA);
   SecurityWrapper::BIO_ctrl(pBIO,BIO_CTRL_FLUSH,0,NULL);
   void* ptr = 0;
   long sz = SecurityWrapper::BIO_get_mem_data(pBIO,&ptr);
   char psPublicKey[4096];
   memcpy_s(psPublicKey,sizeof(psPublicKey),ptr,sz);
   SecurityWrapper::BIO_ctrl(pBIO,BIO_CTRL_SET_CLOSE,BIO_NOCLOSE,NULL);
   SecurityWrapper::BIO_free(pBIO);
   string strDigest(psPublicKey,sz);
   const EVP_MD* md = SecurityWrapper::EVP_sha512();   //sha512 algorithm (64 char digest)
   //EVP_MD_CTX* mdctx = EVP_MD_CTX_new(); //openssl_1.1.0e
   EVP_MD_CTX* mdctx = SecurityWrapper::EVP_MD_CTX_new();
   unsigned char md_value[EVP_MAX_MD_SIZE];
   unsigned int md_len;
   SecurityWrapper::EVP_MD_CTX_reset(mdctx);
   SecurityWrapper::EVP_DigestInit_ex(mdctx,md,NULL);
   SecurityWrapper::EVP_DigestUpdate(mdctx,strDigest.c_str(),strDigest.length());
   SecurityWrapper::EVP_DigestFinal_ex(mdctx,md_value,&md_len);
   SecurityWrapper::EVP_MD_CTX_reset(mdctx);
   SecurityWrapper::EVP_MD_CTX_free(mdctx);
   strDigest.assign((const char*)md_value,md_len);
   char szTemp[3];
   string strValue;
   for (int i = 0; i < strDigest.length(); i++)
   {
      unsigned char c = strDigest.data()[i];
      strValue.append(szTemp,snprintf(szTemp,sizeof(szTemp),"%02x",c));
   }
   strValue.resize(32);
   return strValue;
}
  //## end database::AESKeyManager%49748F87033F.declarations

} // namespace database

//## begin module%4974904600B9.epilog preserve=yes
//## end module%4974904600B9.epilog
