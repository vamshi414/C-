//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4B15452800CD.cm preserve=no
//	$Date:   May 14 2020 18:12:04  $ $Author:   e1009510  $ $Revision:   1.9  $
//## end module%4B15452800CD.cm

//## begin module%4B15452800CD.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%4B15452800CD.cp

//## Module: CXOSDB40%4B15452800CD; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB40.hpp

#ifndef CXOSDB40_h
#define CXOSDB40_h 1

//## begin module%4B15452800CD.additionalIncludes preserve=no
//## end module%4B15452800CD.additionalIncludes

//## begin module%4B15452800CD.includes preserve=yes
#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSRU41_h
#include "CXODRU41.hpp"
#endif
//## end module%4B15452800CD.includes

#ifndef CXOSIF53_h
#include "CXODIF53.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class KeyRing;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Memory;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class IBMKey;

} // namespace database

//## begin module%4B15452800CD.declarations preserve=no
//## end module%4B15452800CD.declarations

//## begin module%4B15452800CD.additionalDeclarations preserve=yes
//## end module%4B15452800CD.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::ZosEncryptedFile%4B15445301A4.preface preserve=yes
//## end database::ZosEncryptedFile%4B15445301A4.preface

//## Class: ZosEncryptedFile%4B15445301A4
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4B15448C01FB;IF::Memory { -> F}
//## Uses: <unnamed>%4B15448E01F4;timer::Clock { -> F}
//## Uses: <unnamed>%4B1544900229;IBMKey { -> F}
//## Uses: <unnamed>%4B15449201DC;reusable::KeyRing { -> F}
//## Uses: <unnamed>%4B17FF6602CA;IF::Trace { -> F}

class DllExport ZosEncryptedFile : public IF::ZosFile  //## Inherits: <unnamed>%4B154473012B
{
  //## begin database::ZosEncryptedFile%4B15445301A4.initialDeclarations preserve=yes
  //## end database::ZosEncryptedFile%4B15445301A4.initialDeclarations

  public:
    //## Constructors (generated)
      ZosEncryptedFile();

    //## Constructors (specified)
      //## Operation: ZosEncryptedFile%4B154611012D
      ZosEncryptedFile (const char* pszName, const char* pszMember);

      //## Operation: ZosEncryptedFile%4B1546110137
      ZosEncryptedFile (const char* pszName);

    //## Destructor (generated)
      virtual ~ZosEncryptedFile();


    //## Other Operations (specified)
      //## Operation: read%4B1546220039
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool* pbReadError = NULL);

      //## Operation: write%4B1546220043
      virtual bool write (char* psBuffer, int lRecordLength);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Count%4C6560F702ED
      const int& getCount () const
      {
        //## begin database::ZosEncryptedFile::getCount%4C6560F702ED.get preserve=no
        return m_iCount;
        //## end database::ZosEncryptedFile::getCount%4C6560F702ED.get
      }

      void setCount (const int& value)
      {
        //## begin database::ZosEncryptedFile::setCount%4C6560F702ED.set preserve=no
        m_iCount = value;
        //## end database::ZosEncryptedFile::setCount%4C6560F702ED.set
      }


      //## Attribute: EncryptLength%4B59F37700EC
      const int& getEncryptLength () const
      {
        //## begin database::ZosEncryptedFile::getEncryptLength%4B59F37700EC.get preserve=no
        return m_iEncryptLength;
        //## end database::ZosEncryptedFile::getEncryptLength%4B59F37700EC.get
      }

      void setEncryptLength (const int& value)
      {
        //## begin database::ZosEncryptedFile::setEncryptLength%4B59F37700EC.set preserve=no
        m_iEncryptLength = value;
        //## end database::ZosEncryptedFile::setEncryptLength%4B59F37700EC.set
      }


      //## Attribute: EncryptOffset%4B59F31B01C3
      const int& getEncryptOffset () const
      {
        //## begin database::ZosEncryptedFile::getEncryptOffset%4B59F31B01C3.get preserve=no
        return m_iEncryptOffset;
        //## end database::ZosEncryptedFile::getEncryptOffset%4B59F31B01C3.get
      }

      void setEncryptOffset (const int& value)
      {
        //## begin database::ZosEncryptedFile::setEncryptOffset%4B59F31B01C3.set preserve=no
        m_iEncryptOffset = value;
        //## end database::ZosEncryptedFile::setEncryptOffset%4B59F31B01C3.set
      }


    // Additional Public Declarations
      //## begin database::ZosEncryptedFile%4B15445301A4.public preserve=yes
      virtual bool decrypt(char* psBuffer, int* plRecordLength);
      //## end database::ZosEncryptedFile%4B15445301A4.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Key%4B1546740233
      //## begin database::ZosEncryptedFile::Key%4B1546740233.attr preserve=no  private: Key* {U} 0
      Key* m_pKey;
      //## end database::ZosEncryptedFile::Key%4B1546740233.attr

    // Additional Protected Declarations
      //## begin database::ZosEncryptedFile%4B15445301A4.protected preserve=yes
     bool setKey(const string& strCheckDigits);
     //## end database::ZosEncryptedFile%4B15445301A4.protected
  private:

    //## Other Operations (specified)
      //## Operation: encrypt%4B15464A0166
      int encrypt (char* psBuffer, int lRecordLength);
      unsigned char* m_pEncryptionBuffer;

    // Additional Private Declarations
      //## begin database::ZosEncryptedFile%4B15445301A4.private preserve=yes
      //## end database::ZosEncryptedFile%4B15445301A4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin database::ZosEncryptedFile::Count%4C6560F702ED.attr preserve=no  public: int {U} 0
      int m_iCount;
      //## end database::ZosEncryptedFile::Count%4C6560F702ED.attr

      //## begin database::ZosEncryptedFile::EncryptLength%4B59F37700EC.attr preserve=no  public: int {U} 0
      int m_iEncryptLength;
      //## end database::ZosEncryptedFile::EncryptLength%4B59F37700EC.attr

      //## begin database::ZosEncryptedFile::EncryptOffset%4B59F31B01C3.attr preserve=no  public: int {U} 0
      int m_iEncryptOffset;
      //## end database::ZosEncryptedFile::EncryptOffset%4B59F31B01C3.attr

      //## Attribute: Memory%4B1546740251
      //## begin database::ZosEncryptedFile::Memory%4B1546740251.attr preserve=no  private: IF::Memory {U} 
      IF::Memory m_hMemory;
      //## end database::ZosEncryptedFile::Memory%4B1546740251.attr

    // Additional Implementation Declarations
      //## begin database::ZosEncryptedFile%4B15445301A4.implementation preserve=yes
      bool m_bVariableBlock;
      //## end database::ZosEncryptedFile%4B15445301A4.implementation
};

//## begin database::ZosEncryptedFile%4B15445301A4.postscript preserve=yes
//## end database::ZosEncryptedFile%4B15445301A4.postscript

} // namespace database

//## begin module%4B15452800CD.epilog preserve=yes
//## end module%4B15452800CD.epilog


#endif
