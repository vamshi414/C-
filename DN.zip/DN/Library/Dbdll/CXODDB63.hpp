//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5C3F97C40344.cm preserve=no
//	$Date:   Jan 31 2019 09:13:24  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5C3F97C40344.cm

//## begin module%5C3F97C40344.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5C3F97C40344.cp

//## Module: CXOSDB63%5C3F97C40344; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\ConnexPlatform\Server\Library\Dbdll\CXODDB63.hpp

#ifndef CXOSDB63_h
#define CXOSDB63_h 1

//## begin module%5C3F97C40344.additionalIncludes preserve=no
//## end module%5C3F97C40344.additionalIncludes

//## begin module%5C3F97C40344.includes preserve=yes
//## end module%5C3F97C40344.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class ExportFile;

} // namespace database

//## begin module%5C3F97C40344.declarations preserve=no
//## end module%5C3F97C40344.declarations

//## begin module%5C3F97C40344.additionalDeclarations preserve=yes
//## end module%5C3F97C40344.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::ReportFactory%5C3F9788036D.preface preserve=yes
//## end database::ReportFactory%5C3F9788036D.preface

//## Class: ReportFactory%5C3F9788036D
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5C3F99930034;ExportFile { -> F}

class DllExport ReportFactory : public reusable::Object  //## Inherits: <unnamed>%5C3F97A402A4
{
  //## begin database::ReportFactory%5C3F9788036D.initialDeclarations preserve=yes
     typedef database::ExportFile* (*cloneFunction)();
  //## end database::ReportFactory%5C3F9788036D.initialDeclarations

  public:
    //## Constructors (generated)
      ReportFactory();

    //## Destructor (generated)
      virtual ~ReportFactory();


    //## Other Operations (specified)
      //## Operation: create%5C3F9B68037B
      database::ExportFile* create (const reusable::string& strName);

      //## Operation: instance%5C40AED401B7
      static ReportFactory* instance ();

      //## Operation: registerReport%5C3F99EA0097
      bool registerReport (const reusable::string& strName, cloneFunction hCloneFunction);

    // Additional Public Declarations
      //## begin database::ReportFactory%5C3F9788036D.public preserve=yes
      //## end database::ReportFactory%5C3F9788036D.public

  protected:
    // Additional Protected Declarations
      //## begin database::ReportFactory%5C3F9788036D.protected preserve=yes
      //## end database::ReportFactory%5C3F9788036D.protected

  private:
    // Additional Private Declarations
      //## begin database::ReportFactory%5C3F9788036D.private preserve=yes
      map<string,cloneFunction,less<string> > m_hReport;
      //## end database::ReportFactory%5C3F9788036D.private
  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5C40AEBE01A0
      //## begin database::ReportFactory::Instance%5C40AEBE01A0.attr preserve=no  private: static ReportFactory* {V} 0
      static ReportFactory* m_pInstance;
      //## end database::ReportFactory::Instance%5C40AEBE01A0.attr

    // Additional Implementation Declarations
      //## begin database::ReportFactory%5C3F9788036D.implementation preserve=yes
      //## end database::ReportFactory%5C3F9788036D.implementation

};

//## begin database::ReportFactory%5C3F9788036D.postscript preserve=yes
//## end database::ReportFactory%5C3F9788036D.postscript

} // namespace database

//## begin module%5C3F97C40344.epilog preserve=yes
//## end module%5C3F97C40344.epilog


#endif
