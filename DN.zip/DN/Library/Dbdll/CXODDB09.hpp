//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%378B5E2B035B.cm preserve=no
//    %X% %Q% %Z% %W%
//## end module%378B5E2B035B.cm

//## begin module%378B5E2B035B.cp preserve=no
//  Copyright (c) 1998 - 2004
//  eFunds Corporation
//## end module%378B5E2B035B.cp

//## Module: CXOSDB09%378B5E2B035B; Package specification
//## Subsystem: DBDLL%35758D89000D
//  .
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXODDB09.hpp

#ifndef CXOSDB09_h
#define CXOSDB09_h 1

//## begin module%378B5E2B035B.additionalIncludes preserve=no
//## end module%378B5E2B035B.additionalIncludes

//## begin module%378B5E2B035B.includes preserve=yes
// $Date:   Apr 08 2004 10:16:48  $ $Author:   D02405  $ $Revision:   1.2  $
#include "CXODRU03.hpp"
//## end module%378B5E2B035B.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;

} // namespace IF

//## begin module%378B5E2B035B.declarations preserve=no
//## end module%378B5E2B035B.declarations

//## begin module%378B5E2B035B.additionalDeclarations preserve=yes
//## end module%378B5E2B035B.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::CRInstitution%378B5B020023.preface preserve=yes
//## end database::CRInstitution%378B5B020023.preface

//## Class: CRInstitution%378B5B020023
//## Category: DataNavigator Foundation::Database_CAT%3451F34D0218
//## Subsystem: DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%378B7C9402AB;reusable::Query { -> F}
//## Uses: <unnamed>%378B7C97015B;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%378B7CB20088;DatabaseFactory { -> F}
//## Uses: <unnamed>%378B7D36005F;IF::Extract { -> F}
//## Uses: <unnamed>%380F58060256;reusable::CXString { -> }

class DllExport CRInstitution : public reusable::Object  //## Inherits: <unnamed>%378B5B1E00F5
{
  //## begin database::CRInstitution%378B5B020023.initialDeclarations preserve=yes
  //## end database::CRInstitution%378B5B020023.initialDeclarations

  public:
    //## Constructors (generated)
      CRInstitution();

    //## Destructor (generated)
      virtual ~CRInstitution();


    //## Other Operations (specified)
      //## Operation: name%378B6A200186
      static bool name (const string& strINST_ID, string& strNAME);

      //## Operation: put%378B5C5501E3
      virtual bool put ();

      //## Operation: reset%378B5C6701CB
      void reset ();

      //## Operation: setADJUST_ACCT_ID%3B290A7C039A
      void setADJUST_ACCT_ID (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setADJUST_ACCT_ID%3B290A7C039A.body preserve=yes
         m_strADJUST_ACCT_ID.set(psText,iTextLength);
        //## end database::CRInstitution::setADJUST_ACCT_ID%3B290A7C039A.body
      }

      //## Operation: setADJUST_ACCT_TYPE%3B290E7C0193
      void setADJUST_ACCT_TYPE (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setADJUST_ACCT_TYPE%3B290E7C0193.body preserve=yes
         m_strADJUST_ACCT_TYPE.set(psText,iTextLength);
        //## end database::CRInstitution::setADJUST_ACCT_TYPE%3B290E7C0193.body
      }

      //## Operation: setADJUST_INST_ID%3B290C710047
      void setADJUST_INST_ID (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setADJUST_INST_ID%3B290C710047.body preserve=yes
         m_strADJUST_INST_ID.set(psText,iTextLength);
        //## end database::CRInstitution::setADJUST_INST_ID%3B290C710047.body
      }

      //## Operation: setBILL_INTERCHG_GRP%3B290C9603CF
      void setBILL_INTERCHG_GRP (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setBILL_INTERCHG_GRP%3B290C9603CF.body preserve=yes
         m_strBILL_INTERCHG_GRP.set(psText,iTextLength);
        //## end database::CRInstitution::setBILL_INTERCHG_GRP%3B290C9603CF.body
      }

      //## Operation: setCC_CHANGE_GRP_ID%378B5CFB026E
      void setCC_CHANGE_GRP_ID (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setCC_CHANGE_GRP_ID%378B5CFB026E.body preserve=yes
         m_strCC_CHANGE_GRP_ID.set(psText,iTextLength);
        //## end database::CRInstitution::setCC_CHANGE_GRP_ID%378B5CFB026E.body
      }

      //## Operation: setCC_LAST_OPERATION%378B5CFD02D5
      void setCC_LAST_OPERATION (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setCC_LAST_OPERATION%378B5CFD02D5.body preserve=yes
         m_strCC_LAST_OPERATION.set(psText,iTextLength);
        //## end database::CRInstitution::setCC_LAST_OPERATION%378B5CFD02D5.body
      }

      //## Operation: setCC_STATE%378B5CFD00EA
      void setCC_STATE (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setCC_STATE%378B5CFD00EA.body preserve=yes
         m_strCC_STATE.set(psText,iTextLength);
        //## end database::CRInstitution::setCC_STATE%378B5CFD00EA.body
      }

      //## Operation: setCC_TSTAMP_CHANGE%378B5CFE01D2
      void setCC_TSTAMP_CHANGE (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setCC_TSTAMP_CHANGE%378B5CFE01D2.body preserve=yes
         m_strCC_TSTAMP_CHANGE.set(psText,iTextLength);
        //## end database::CRInstitution::setCC_TSTAMP_CHANGE%378B5CFE01D2.body
      }

      //## Operation: setCC_USER_ID%378B5CFE0087
      void setCC_USER_ID (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setCC_USER_ID%378B5CFE0087.body preserve=yes
         m_strCC_USER_ID.set(psText,iTextLength);
        //## end database::CRInstitution::setCC_USER_ID%378B5CFE0087.body
      }

      //## Operation: setCUST_ID%378B5CFA024E
      void setCUST_ID (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setCUST_ID%378B5CFA024E.body preserve=yes
         m_strCUST_ID.set(psText,iTextLength);
        //## end database::CRInstitution::setCUST_ID%378B5CFA024E.body
      }

      //## Operation: setCUST_STAT%378B5CFA0335
      void setCUST_STAT (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setCUST_STAT%378B5CFA0335.body preserve=yes
         m_strCUST_STAT.set(psText,iTextLength);
        //## end database::CRInstitution::setCUST_STAT%378B5CFA0335.body
      }

      //## Operation: setCUTOFF_COPY_FLG%3B290DCB033D
      void setCUTOFF_COPY_FLG (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setCUTOFF_COPY_FLG%3B290DCB033D.body preserve=yes
         m_strCUTOFF_COPY_FLG.set(psText,iTextLength);
        //## end database::CRInstitution::setCUTOFF_COPY_FLG%3B290DCB033D.body
      }

      //## Operation: setCUTOFF_IND%3B290DE40235
      void setCUTOFF_IND (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setCUTOFF_IND%3B290DE40235.body preserve=yes
         m_strCUTOFF_IND.set(psText,iTextLength);
        //## end database::CRInstitution::setCUTOFF_IND%3B290DE40235.body
      }

      //## Operation: setCUTOFF_START_TIME%3B290DF1007B
      void setCUTOFF_START_TIME (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setCUTOFF_START_TIME%3B290DF1007B.body preserve=yes
         m_strCUTOFF_START_TIME.set(psText,iTextLength);
        //## end database::CRInstitution::setCUTOFF_START_TIME%3B290DF1007B.body
      }

      //## Operation: setCUTOFF_TIME%3B290DFD00FA
      void setCUTOFF_TIME (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setCUTOFF_TIME%3B290DFD00FA.body preserve=yes
         m_strCUTOFF_TIME.set(psText,iTextLength);
        //## end database::CRInstitution::setCUTOFF_TIME%3B290DFD00FA.body
      }

      //## Operation: setFEE_BILL_ACCT_ID%3B290E090300
      void setFEE_BILL_ACCT_ID (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setFEE_BILL_ACCT_ID%3B290E090300.body preserve=yes
         m_strFEE_BILL_ACCT_ID.set(psText,iTextLength);
        //## end database::CRInstitution::setFEE_BILL_ACCT_ID%3B290E090300.body
      }

      //## Operation: setFEE_BILL_ACCT_TYPE%3B290E8A000D
      void setFEE_BILL_ACCT_TYPE (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setFEE_BILL_ACCT_TYPE%3B290E8A000D.body preserve=yes
         m_strFEE_BILL_ACCT_TYPE.set(psText,iTextLength);
        //## end database::CRInstitution::setFEE_BILL_ACCT_TYPE%3B290E8A000D.body
      }

      //## Operation: setFEE_BILL_INST_ID%3B290E12037B
      void setFEE_BILL_INST_ID (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setFEE_BILL_INST_ID%3B290E12037B.body preserve=yes
         m_strFEE_BILL_INST_ID.set(psText,iTextLength);
        //## end database::CRInstitution::setFEE_BILL_INST_ID%3B290E12037B.body
      }

      //## Operation: setFUNDS_MOVEMENT_OPT%3B290E4000E3
      void setFUNDS_MOVEMENT_OPT (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setFUNDS_MOVEMENT_OPT%3B290E4000E3.body preserve=yes
         m_strFUNDS_MOVEMENT_OPT.set(psText,iTextLength);
        //## end database::CRInstitution::setFUNDS_MOVEMENT_OPT%3B290E4000E3.body
      }

      //## Operation: setINST_ID%378B5CC50324
      void setINST_ID (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setINST_ID%378B5CC50324.body preserve=yes
         m_strINST_ID.set(psText,iTextLength);
        //## end database::CRInstitution::setINST_ID%378B5CC50324.body
      }

      //## Operation: setINST_STAT%378B5CF800A7
      void setINST_STAT (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setINST_STAT%378B5CF800A7.body preserve=yes
         m_strINST_STAT.set(psText,iTextLength);
        //## end database::CRInstitution::setINST_STAT%378B5CF800A7.body
      }

      //## Operation: setNAME%378B5CFE0344
      void setNAME (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setNAME%378B5CFE0344.body preserve=yes
         m_strNAME.set(psText,iTextLength);
        //## end database::CRInstitution::setNAME%378B5CFE0344.body
      }

      //## Operation: setONLINE_FEE_ACCT_ID%3B290E460344
      void setONLINE_FEE_ACCT_ID (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setONLINE_FEE_ACCT_ID%3B290E460344.body preserve=yes
         m_strONLINE_FEE_ACCT_ID.set(psText,iTextLength);
        //## end database::CRInstitution::setONLINE_FEE_ACCT_ID%3B290E460344.body
      }

      //## Operation: setONLINE_FEE_INST_ID%3B290E560148
      void setONLINE_FEE_INST_ID (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setONLINE_FEE_INST_ID%3B290E560148.body preserve=yes
         m_strONLINE_FEE_INST_ID.set(psText,iTextLength);
        //## end database::CRInstitution::setONLINE_FEE_INST_ID%3B290E560148.body
      }

      //## Operation: setONLN_FEE_ACCT_TYPE%3B290EA50138
      void setONLN_FEE_ACCT_TYPE (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setONLN_FEE_ACCT_TYPE%3B290EA50138.body preserve=yes
         m_strONLN_FEE_ACCT_TYPE.set(psText,iTextLength);
        //## end database::CRInstitution::setONLN_FEE_ACCT_TYPE%3B290EA50138.body
      }

      //## Operation: setPROC_ID%378B5CFC0193
      void setPROC_ID (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setPROC_ID%378B5CFC0193.body preserve=yes
         m_strPROC_ID.set(psText,iTextLength);
        //## end database::CRInstitution::setPROC_ID%378B5CFC0193.body
      }

      //## Operation: setPROC_STAT%378B5CFC0265
      void setPROC_STAT (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setPROC_STAT%378B5CFC0265.body preserve=yes
         m_strPROC_STAT.set(psText,iTextLength);
        //## end database::CRInstitution::setPROC_STAT%378B5CFC0265.body
      }

      //## Operation: setSERVICE_LINE%3B290E5B027C
      void setSERVICE_LINE (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setSERVICE_LINE%3B290E5B027C.body preserve=yes
         m_strSERVICE_LINE.set(psText,iTextLength);
        //## end database::CRInstitution::setSERVICE_LINE%3B290E5B027C.body
      }

      //## Operation: setSETL_ACCT_NO%3B290E6503D5
      void setSETL_ACCT_NO (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setSETL_ACCT_NO%3B290E6503D5.body preserve=yes
         m_strSETL_ACCT_NO.set(psText,iTextLength);
        //## end database::CRInstitution::setSETL_ACCT_NO%3B290E6503D5.body
      }

      //## Operation: setSETL_ACCT_TYPE%3B290E9A01DC
      void setSETL_ACCT_TYPE (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setSETL_ACCT_TYPE%3B290E9A01DC.body preserve=yes
         m_strSETL_ACCT_TYPE.set(psText,iTextLength);
        //## end database::CRInstitution::setSETL_ACCT_TYPE%3B290E9A01DC.body
      }

      //## Operation: setSETL_INST_ID%3B290E71007F
      void setSETL_INST_ID (const char* psText, unsigned  iTextLength)
      {
        //## begin database::CRInstitution::setSETL_INST_ID%3B290E71007F.body preserve=yes
         m_strSETL_INST_ID.set(psText,iTextLength);
        //## end database::CRInstitution::setSETL_INST_ID%3B290E71007F.body
      }

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ADJUST_ACCT_ID%3B29080B0214
      const CXString& getADJUST_ACCT_ID () const
      {
        //## begin database::CRInstitution::getADJUST_ACCT_ID%3B29080B0214.get preserve=no
        return m_strADJUST_ACCT_ID;
        //## end database::CRInstitution::getADJUST_ACCT_ID%3B29080B0214.get
      }


      //## Attribute: ADJUST_ACCT_TYPE%3B29098B0307
      const CXString& getADJUST_ACCT_TYPE () const
      {
        //## begin database::CRInstitution::getADJUST_ACCT_TYPE%3B29098B0307.get preserve=no
        return m_strADJUST_ACCT_TYPE;
        //## end database::CRInstitution::getADJUST_ACCT_TYPE%3B29098B0307.get
      }


      //## Attribute: ADJUST_INST_ID%3B29089D016A
      const CXString& getADJUST_INST_ID () const
      {
        //## begin database::CRInstitution::getADJUST_INST_ID%3B29089D016A.get preserve=no
        return m_strADJUST_INST_ID;
        //## end database::CRInstitution::getADJUST_INST_ID%3B29089D016A.get
      }


      //## Attribute: BILL_INTERCHG_GRP%3B2908C20253
      const CXString& getBILL_INTERCHG_GRP () const
      {
        //## begin database::CRInstitution::getBILL_INTERCHG_GRP%3B2908C20253.get preserve=no
        return m_strBILL_INTERCHG_GRP;
        //## end database::CRInstitution::getBILL_INTERCHG_GRP%3B2908C20253.get
      }


      //## Attribute: CC_CHANGE_GRP_ID%378B5BC80280
      const CXString& getCC_CHANGE_GRP_ID () const
      {
        //## begin database::CRInstitution::getCC_CHANGE_GRP_ID%378B5BC80280.get preserve=no
        return m_strCC_CHANGE_GRP_ID;
        //## end database::CRInstitution::getCC_CHANGE_GRP_ID%378B5BC80280.get
      }


      //## Attribute: CC_LAST_OPERATION%378B5BCA01D9
      const CXString& getCC_LAST_OPERATION () const
      {
        //## begin database::CRInstitution::getCC_LAST_OPERATION%378B5BCA01D9.get preserve=no
        return m_strCC_LAST_OPERATION;
        //## end database::CRInstitution::getCC_LAST_OPERATION%378B5BCA01D9.get
      }


      //## Attribute: CC_STATE%378B5BCA00F3
      const CXString& getCC_STATE () const
      {
        //## begin database::CRInstitution::getCC_STATE%378B5BCA00F3.get preserve=no
        return m_strCC_STATE;
        //## end database::CRInstitution::getCC_STATE%378B5BCA00F3.get
      }


      //## Attribute: CC_TSTAMP_CHANGE%378B5BCB00A4
      const CXString& getCC_TSTAMP_CHANGE () const
      {
        //## begin database::CRInstitution::getCC_TSTAMP_CHANGE%378B5BCB00A4.get preserve=no
        return m_strCC_TSTAMP_CHANGE;
        //## end database::CRInstitution::getCC_TSTAMP_CHANGE%378B5BCB00A4.get
      }


      //## Attribute: CC_USER_ID%378B5BCA03D8
      const CXString& getCC_USER_ID () const
      {
        //## begin database::CRInstitution::getCC_USER_ID%378B5BCA03D8.get preserve=no
        return m_strCC_USER_ID;
        //## end database::CRInstitution::getCC_USER_ID%378B5BCA03D8.get
      }


      //## Attribute: CUST_ID%378B5BC701CB
      const CXString& getCUST_ID () const
      {
        //## begin database::CRInstitution::getCUST_ID%378B5BC701CB.get preserve=no
        return m_strCUST_ID;
        //## end database::CRInstitution::getCUST_ID%378B5BC701CB.get
      }


      //## Attribute: CUST_STAT%378B5BC702BB
      const CXString& getCUST_STAT () const
      {
        //## begin database::CRInstitution::getCUST_STAT%378B5BC702BB.get preserve=no
        return m_strCUST_STAT;
        //## end database::CRInstitution::getCUST_STAT%378B5BC702BB.get
      }


      //## Attribute: CUTOFF_COPY_FLG%3B2908CF019E
      const CXString& getCUTOFF_COPY_FLG () const
      {
        //## begin database::CRInstitution::getCUTOFF_COPY_FLG%3B2908CF019E.get preserve=no
        return m_strCUTOFF_COPY_FLG;
        //## end database::CRInstitution::getCUTOFF_COPY_FLG%3B2908CF019E.get
      }


      //## Attribute: CUTOFF_IND%3B2908E7001C
      const CXString& getCUTOFF_IND () const
      {
        //## begin database::CRInstitution::getCUTOFF_IND%3B2908E7001C.get preserve=no
        return m_strCUTOFF_IND;
        //## end database::CRInstitution::getCUTOFF_IND%3B2908E7001C.get
      }


      //## Attribute: CUTOFF_START_TIME%3B2908F300EB
      const CXString& getCUTOFF_START_TIME () const
      {
        //## begin database::CRInstitution::getCUTOFF_START_TIME%3B2908F300EB.get preserve=no
        return m_strCUTOFF_START_TIME;
        //## end database::CRInstitution::getCUTOFF_START_TIME%3B2908F300EB.get
      }


      //## Attribute: CUTOFF_TIME%3B290903004E
      const CXString& getCUTOFF_TIME () const
      {
        //## begin database::CRInstitution::getCUTOFF_TIME%3B290903004E.get preserve=no
        return m_strCUTOFF_TIME;
        //## end database::CRInstitution::getCUTOFF_TIME%3B290903004E.get
      }


      //## Attribute: FEE_BILL_ACCT_ID%3B29090D017F
      const CXString& getFEE_BILL_ACCT_ID () const
      {
        //## begin database::CRInstitution::getFEE_BILL_ACCT_ID%3B29090D017F.get preserve=no
        return m_strFEE_BILL_ACCT_ID;
        //## end database::CRInstitution::getFEE_BILL_ACCT_ID%3B29090D017F.get
      }


      //## Attribute: FEE_BILL_ACCT_TYPE%3B2909A3006C
      const CXString& getFEE_BILL_ACCT_TYPE () const
      {
        //## begin database::CRInstitution::getFEE_BILL_ACCT_TYPE%3B2909A3006C.get preserve=no
        return m_strFEE_BILL_ACCT_TYPE;
        //## end database::CRInstitution::getFEE_BILL_ACCT_TYPE%3B2909A3006C.get
      }


      //## Attribute: FEE_BILL_INST_ID%3B29091D016E
      const CXString& getFEE_BILL_INST_ID () const
      {
        //## begin database::CRInstitution::getFEE_BILL_INST_ID%3B29091D016E.get preserve=no
        return m_strFEE_BILL_INST_ID;
        //## end database::CRInstitution::getFEE_BILL_INST_ID%3B29091D016E.get
      }


      //## Attribute: FUNDS_MOVEMENT_OPT%3B2909250165
      const CXString& getFUNDS_MOVEMENT_OPT () const
      {
        //## begin database::CRInstitution::getFUNDS_MOVEMENT_OPT%3B2909250165.get preserve=no
        return m_strFUNDS_MOVEMENT_OPT;
        //## end database::CRInstitution::getFUNDS_MOVEMENT_OPT%3B2909250165.get
      }


      //## Attribute: INST_ID%378B5B870114
      const CXString& getINST_ID () const
      {
        //## begin database::CRInstitution::getINST_ID%378B5B870114.get preserve=no
        return m_strINST_ID;
        //## end database::CRInstitution::getINST_ID%378B5B870114.get
      }


      //## Attribute: INST_STAT%378B5BC402D5
      const CXString& getINST_STAT () const
      {
        //## begin database::CRInstitution::getINST_STAT%378B5BC402D5.get preserve=no
        return m_strINST_STAT;
        //## end database::CRInstitution::getINST_STAT%378B5BC402D5.get
      }


      //## Attribute: NAME%378B5BCB01D0
      const CXString& getNAME () const
      {
        //## begin database::CRInstitution::getNAME%378B5BCB01D0.get preserve=no
        return m_strNAME;
        //## end database::CRInstitution::getNAME%378B5BCB01D0.get
      }


      //## Attribute: PROC_ID%378B5BC9019C
      const CXString& getPROC_ID () const
      {
        //## begin database::CRInstitution::getPROC_ID%378B5BC9019C.get preserve=no
        return m_strPROC_ID;
        //## end database::CRInstitution::getPROC_ID%378B5BC9019C.get
      }


      //## Attribute: PROC_STAT%378B5BC9026E
      const CXString& getPROC_STAT () const
      {
        //## begin database::CRInstitution::getPROC_STAT%378B5BC9026E.get preserve=no
        return m_strPROC_STAT;
        //## end database::CRInstitution::getPROC_STAT%378B5BC9026E.get
      }


      //## Attribute: ONLINE_FEE_ACCT_ID%3B29092E0172
      const CXString& getONLINE_FEE_ACCT_ID () const
      {
        //## begin database::CRInstitution::getONLINE_FEE_ACCT_ID%3B29092E0172.get preserve=no
        return m_strONLINE_FEE_ACCT_ID;
        //## end database::CRInstitution::getONLINE_FEE_ACCT_ID%3B29092E0172.get
      }


      //## Attribute: ONLINE_FEE_INST_ID%3B29093E02F2
      const CXString& getONLINE_FEE_INST_ID () const
      {
        //## begin database::CRInstitution::getONLINE_FEE_INST_ID%3B29093E02F2.get preserve=no
        return m_strONLINE_FEE_INST_ID;
        //## end database::CRInstitution::getONLINE_FEE_INST_ID%3B29093E02F2.get
      }


      //## Attribute: ONLN_FEE_ACCT_TYPE%3B2909BD0178
      const CXString& getONLN_FEE_ACCT_TYPE () const
      {
        //## begin database::CRInstitution::getONLN_FEE_ACCT_TYPE%3B2909BD0178.get preserve=no
        return m_strONLN_FEE_ACCT_TYPE;
        //## end database::CRInstitution::getONLN_FEE_ACCT_TYPE%3B2909BD0178.get
      }


      //## Attribute: SERVICE_LINE%3B2909460163
      const CXString& getSERVICE_LINE () const
      {
        //## begin database::CRInstitution::getSERVICE_LINE%3B2909460163.get preserve=no
        return m_strSERVICE_LINE;
        //## end database::CRInstitution::getSERVICE_LINE%3B2909460163.get
      }


      //## Attribute: SETL_ACCT_NO%3B29094F0347
      const CXString& getSETL_ACCT_NO () const
      {
        //## begin database::CRInstitution::getSETL_ACCT_NO%3B29094F0347.get preserve=no
        return m_strSETL_ACCT_NO;
        //## end database::CRInstitution::getSETL_ACCT_NO%3B29094F0347.get
      }


      //## Attribute: SETL_ACCT_TYPE%3B2909AF010A
      const CXString& getSETL_ACCT_TYPE () const
      {
        //## begin database::CRInstitution::getSETL_ACCT_TYPE%3B2909AF010A.get preserve=no
        return m_strSETL_ACCT_TYPE;
        //## end database::CRInstitution::getSETL_ACCT_TYPE%3B2909AF010A.get
      }


      //## Attribute: SETL_INST_ID%3B290958014B
      const CXString& getSETL_INST_ID () const
      {
        //## begin database::CRInstitution::getSETL_INST_ID%3B290958014B.get preserve=no
        return m_strSETL_INST_ID;
        //## end database::CRInstitution::getSETL_INST_ID%3B290958014B.get
      }


    // Additional Public Declarations
      //## begin database::CRInstitution%378B5B020023.public preserve=yes
      //## end database::CRInstitution%378B5B020023.public

  protected:
    // Data Members for Class Attributes

      //## begin database::CRInstitution::ADJUST_ACCT_ID%3B29080B0214.attr preserve=no  public: CXString {U}
      CXString m_strADJUST_ACCT_ID;
      //## end database::CRInstitution::ADJUST_ACCT_ID%3B29080B0214.attr

      //## begin database::CRInstitution::ADJUST_ACCT_TYPE%3B29098B0307.attr preserve=no  public: CXString {U}
      CXString m_strADJUST_ACCT_TYPE;
      //## end database::CRInstitution::ADJUST_ACCT_TYPE%3B29098B0307.attr

      //## begin database::CRInstitution::ADJUST_INST_ID%3B29089D016A.attr preserve=no  public: CXString {U}
      CXString m_strADJUST_INST_ID;
      //## end database::CRInstitution::ADJUST_INST_ID%3B29089D016A.attr

      //## begin database::CRInstitution::BILL_INTERCHG_GRP%3B2908C20253.attr preserve=no  public: CXString {U}
      CXString m_strBILL_INTERCHG_GRP;
      //## end database::CRInstitution::BILL_INTERCHG_GRP%3B2908C20253.attr

      //## begin database::CRInstitution::CC_CHANGE_GRP_ID%378B5BC80280.attr preserve=no  public: CXString {U}
      CXString m_strCC_CHANGE_GRP_ID;
      //## end database::CRInstitution::CC_CHANGE_GRP_ID%378B5BC80280.attr

      //## begin database::CRInstitution::CC_LAST_OPERATION%378B5BCA01D9.attr preserve=no  public: CXString {U}
      CXString m_strCC_LAST_OPERATION;
      //## end database::CRInstitution::CC_LAST_OPERATION%378B5BCA01D9.attr

      //## begin database::CRInstitution::CC_STATE%378B5BCA00F3.attr preserve=no  public: CXString {U}
      CXString m_strCC_STATE;
      //## end database::CRInstitution::CC_STATE%378B5BCA00F3.attr

      //## begin database::CRInstitution::CC_TSTAMP_CHANGE%378B5BCB00A4.attr preserve=no  public: CXString {U}
      CXString m_strCC_TSTAMP_CHANGE;
      //## end database::CRInstitution::CC_TSTAMP_CHANGE%378B5BCB00A4.attr

      //## begin database::CRInstitution::CC_USER_ID%378B5BCA03D8.attr preserve=no  public: CXString {U}
      CXString m_strCC_USER_ID;
      //## end database::CRInstitution::CC_USER_ID%378B5BCA03D8.attr

      //## begin database::CRInstitution::CUST_ID%378B5BC701CB.attr preserve=no  public: CXString {U}
      CXString m_strCUST_ID;
      //## end database::CRInstitution::CUST_ID%378B5BC701CB.attr

      //## begin database::CRInstitution::CUST_STAT%378B5BC702BB.attr preserve=no  public: CXString {U}
      CXString m_strCUST_STAT;
      //## end database::CRInstitution::CUST_STAT%378B5BC702BB.attr

      //## begin database::CRInstitution::CUTOFF_COPY_FLG%3B2908CF019E.attr preserve=no  public: CXString {U}
      CXString m_strCUTOFF_COPY_FLG;
      //## end database::CRInstitution::CUTOFF_COPY_FLG%3B2908CF019E.attr

      //## begin database::CRInstitution::CUTOFF_IND%3B2908E7001C.attr preserve=no  public: CXString {U}
      CXString m_strCUTOFF_IND;
      //## end database::CRInstitution::CUTOFF_IND%3B2908E7001C.attr

      //## begin database::CRInstitution::CUTOFF_START_TIME%3B2908F300EB.attr preserve=no  public: CXString {U}
      CXString m_strCUTOFF_START_TIME;
      //## end database::CRInstitution::CUTOFF_START_TIME%3B2908F300EB.attr

      //## begin database::CRInstitution::CUTOFF_TIME%3B290903004E.attr preserve=no  public: CXString {U}
      CXString m_strCUTOFF_TIME;
      //## end database::CRInstitution::CUTOFF_TIME%3B290903004E.attr

      //## begin database::CRInstitution::FEE_BILL_ACCT_ID%3B29090D017F.attr preserve=no  public: CXString {U}
      CXString m_strFEE_BILL_ACCT_ID;
      //## end database::CRInstitution::FEE_BILL_ACCT_ID%3B29090D017F.attr

      //## begin database::CRInstitution::FEE_BILL_ACCT_TYPE%3B2909A3006C.attr preserve=no  public: CXString {U}
      CXString m_strFEE_BILL_ACCT_TYPE;
      //## end database::CRInstitution::FEE_BILL_ACCT_TYPE%3B2909A3006C.attr

      //## begin database::CRInstitution::FEE_BILL_INST_ID%3B29091D016E.attr preserve=no  public: CXString {U}
      CXString m_strFEE_BILL_INST_ID;
      //## end database::CRInstitution::FEE_BILL_INST_ID%3B29091D016E.attr

      //## begin database::CRInstitution::FUNDS_MOVEMENT_OPT%3B2909250165.attr preserve=no  public: CXString {U}
      CXString m_strFUNDS_MOVEMENT_OPT;
      //## end database::CRInstitution::FUNDS_MOVEMENT_OPT%3B2909250165.attr

      //## begin database::CRInstitution::INST_ID%378B5B870114.attr preserve=no  public: CXString {V}
      CXString m_strINST_ID;
      //## end database::CRInstitution::INST_ID%378B5B870114.attr

      //## begin database::CRInstitution::INST_STAT%378B5BC402D5.attr preserve=no  public: CXString {U}
      CXString m_strINST_STAT;
      //## end database::CRInstitution::INST_STAT%378B5BC402D5.attr

      //## begin database::CRInstitution::NAME%378B5BCB01D0.attr preserve=no  public: CXString {U}
      CXString m_strNAME;
      //## end database::CRInstitution::NAME%378B5BCB01D0.attr

      //## begin database::CRInstitution::PROC_ID%378B5BC9019C.attr preserve=no  public: CXString {U}
      CXString m_strPROC_ID;
      //## end database::CRInstitution::PROC_ID%378B5BC9019C.attr

      //## begin database::CRInstitution::PROC_STAT%378B5BC9026E.attr preserve=no  public: CXString {U}
      CXString m_strPROC_STAT;
      //## end database::CRInstitution::PROC_STAT%378B5BC9026E.attr

      //## begin database::CRInstitution::ONLINE_FEE_ACCT_ID%3B29092E0172.attr preserve=no  public: CXString {U}
      CXString m_strONLINE_FEE_ACCT_ID;
      //## end database::CRInstitution::ONLINE_FEE_ACCT_ID%3B29092E0172.attr

      //## begin database::CRInstitution::ONLINE_FEE_INST_ID%3B29093E02F2.attr preserve=no  public: CXString {U}
      CXString m_strONLINE_FEE_INST_ID;
      //## end database::CRInstitution::ONLINE_FEE_INST_ID%3B29093E02F2.attr

      //## begin database::CRInstitution::ONLN_FEE_ACCT_TYPE%3B2909BD0178.attr preserve=no  public: CXString {U}
      CXString m_strONLN_FEE_ACCT_TYPE;
      //## end database::CRInstitution::ONLN_FEE_ACCT_TYPE%3B2909BD0178.attr

      //## begin database::CRInstitution::SERVICE_LINE%3B2909460163.attr preserve=no  public: CXString {U}
      CXString m_strSERVICE_LINE;
      //## end database::CRInstitution::SERVICE_LINE%3B2909460163.attr

      //## begin database::CRInstitution::SETL_ACCT_NO%3B29094F0347.attr preserve=no  public: CXString {U}
      CXString m_strSETL_ACCT_NO;
      //## end database::CRInstitution::SETL_ACCT_NO%3B29094F0347.attr

      //## begin database::CRInstitution::SETL_ACCT_TYPE%3B2909AF010A.attr preserve=no  public: CXString {U}
      CXString m_strSETL_ACCT_TYPE;
      //## end database::CRInstitution::SETL_ACCT_TYPE%3B2909AF010A.attr

      //## begin database::CRInstitution::SETL_INST_ID%3B290958014B.attr preserve=no  public: CXString {U}
      CXString m_strSETL_INST_ID;
      //## end database::CRInstitution::SETL_INST_ID%3B290958014B.attr

    // Additional Protected Declarations
      //## begin database::CRInstitution%378B5B020023.protected preserve=yes
      //## end database::CRInstitution%378B5B020023.protected

  private:
    // Additional Private Declarations
      //## begin database::CRInstitution%378B5B020023.private preserve=yes
      //## end database::CRInstitution%378B5B020023.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::CRInstitution%378B5B020023.implementation preserve=yes
      //## end database::CRInstitution%378B5B020023.implementation

};

//## begin database::CRInstitution%378B5B020023.postscript preserve=yes
//## end database::CRInstitution%378B5B020023.postscript

} // namespace database

//## begin module%378B5E2B035B.epilog preserve=yes
using namespace database;
//## end module%378B5E2B035B.epilog


#endif
