//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%378B86AF035F.cm preserve=no
//	$Date:   May 12 2020 10:52:26  $ $Author:   E5350313  $ $Revision:   1.8  $
//## end module%378B86AF035F.cm

//## begin module%378B86AF035F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%378B86AF035F.cp

//## Module: CXOSDB16%378B86AF035F; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Dn_codes\V03.1A.R004\ConnexPlatform\Server\Library\Dbdll\CXODDB16.hpp

#ifndef CXOSDB16_h
#define CXOSDB16_h 1

//## begin module%378B86AF035F.additionalIncludes preserve=no
//## end module%378B86AF035F.additionalIncludes

//## begin module%378B86AF035F.includes preserve=yes
#include <map>
//## end module%378B86AF035F.includes

#ifndef CXOSDB43_h
#include "CXODDB43.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%378B86AF035F.declarations preserve=no
//## end module%378B86AF035F.declarations

//## begin module%378B86AF035F.additionalDeclarations preserve=yes
struct sTTISecond
{
   char cIMPACT_TO_ACQ[1];         //0000
   char cIMPACT_TO_ISS[1];         //0001
   char cDEPOSITORY_IND[1];        //0002
   char sTRAN_GROUP[4];            //0003
   char sCFG_DESCRIPTION_0[19];    //0007 - TTI_FUNCTION.DESCRIPTION (19 chars)
   char sCFG_DESCRIPTION_1[28];    //0026 - TTI_ACCOUNT.DESCRIPTION FROM (28 chars)
   char sCFG_DESCRIPTION_2[28];    //0054 - TTI_ACCOUNT.DESCRIPTION TO (28 chars)
   char sCFG_DESCRIPTION_3[50];    //0082 - TRAN_TYPE_IND.DESCRIPTION
   char sPOST_CMS_PROC_CODE[6];    //0132
   char sPOST_ACH_TRAN_CODE[2];    //0138
   char cPOST_PROC_DROP_IND[1];    //0140
   char cPOST_DEP_DROP_IND[1];     //0141
                                   //0142
};
//## end module%378B86AF035F.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::CRTransactionTypeIndicator%378B84F70349.preface preserve=yes
//## end database::CRTransactionTypeIndicator%378B84F70349.preface

//## Class: CRTransactionTypeIndicator%378B84F70349
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%378B86700305;DatabaseFactory { -> F}
//## Uses: <unnamed>%378B86730056;IF::Extract { -> F}
//## Uses: <unnamed>%378B8675024E;reusable::Query { -> F}
//## Uses: <unnamed>%378B86780099;reusable::SelectStatement { -> F}

class DllExport CRTransactionTypeIndicator : public Cache  //## Inherits: <unnamed>%54AE99BE00D1
{
  //## begin database::CRTransactionTypeIndicator%378B84F70349.initialDeclarations preserve=yes
  //## end database::CRTransactionTypeIndicator%378B84F70349.initialDeclarations

  public:
    //## Constructors (generated)
      CRTransactionTypeIndicator();

    //## Destructor (generated)
      virtual ~CRTransactionTypeIndicator();


    //## Other Operations (specified)
      //## Operation: description%378B85D30205
      static bool description (const string& strTRAN_TYPE_ID, string& strCFG_DESCRIPTION);

      //## Operation: getDepositoryInd%3AE6D8700375
      static bool getDepositoryInd (const string& strTRAN_TYPE_ID, string& strDEPOSITORY_IND);

      //## Operation: getDescription%5E137B0302C5
      static bool getDescription (const string& strTRAN_TYPE_ID, string& strCFG_DESCRIPTION);

      //## Operation: getImpact%385BAECB0331
      static bool getImpact (const string& strTRAN_TYPE_ID, string& strIMPACT_TO_ACQ, string& strIMPACT_TO_ISS);

      //## Operation: getPostDropIndicator%5EB2A345018B
      static bool getPostDropIndicator (const string& strTRAN_TYPE_ID, string& strPOST_PROC_DROP_IND, string& strPOST_DEP_DROP_IND);

      //## Operation: getPostProcessCode%5EB29F6A0246
      static bool getPostProcessCode (const string& strTRAN_TYPE_ID, string& strPOST_CMS_PROC_CODE);

      //## Operation: getPostTranCode%5EB2A29802F3
      static bool getPostTranCode (const string& strTRAN_TYPE_ID, string& strPOST_ACH_TRAN_CODE);

      //## Operation: getTranGroup%45CC2C1D021D
      static bool getTranGroup (const string& strTRAN_TYPE_ID, string& strTRAN_GROUP);

      //## Operation: instance%54AE9B6D03E2
      static CRTransactionTypeIndicator* instance ();

      //## Operation: load%54AE99CB0369
      virtual bool load ();

      //## Operation: update%385BB31F015D
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin database::CRTransactionTypeIndicator%378B84F70349.public preserve=yes
      //## end database::CRTransactionTypeIndicator%378B84F70349.public

  protected:
    // Additional Protected Declarations
      //## begin database::CRTransactionTypeIndicator%378B84F70349.protected preserve=yes
      //## end database::CRTransactionTypeIndicator%378B84F70349.protected

  private:
    // Data Members for Class Attributes

      //## Attribute: CFG_DESCRIPTION%54AE9F3D023E
      //## begin database::CRTransactionTypeIndicator::CFG_DESCRIPTION%54AE9F3D023E.attr preserve=no  private: reusable::string[4] {VA} 
      reusable::string m_strCFG_DESCRIPTION[4];
      //## end database::CRTransactionTypeIndicator::CFG_DESCRIPTION%54AE9F3D023E.attr

    // Additional Private Declarations
      //## begin database::CRTransactionTypeIndicator%378B84F70349.private preserve=yes
      //## end database::CRTransactionTypeIndicator%378B84F70349.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DEPOSITORY_IND%3AE6D7DC001F
      //## begin database::CRTransactionTypeIndicator::DEPOSITORY_IND%3AE6D7DC001F.attr preserve=no  private: string {V} 
      string m_strDEPOSITORY_IND;
      //## end database::CRTransactionTypeIndicator::DEPOSITORY_IND%3AE6D7DC001F.attr

      //## Attribute: IMPACT_TO_ACQ%385BB27001E8
      //## begin database::CRTransactionTypeIndicator::IMPACT_TO_ACQ%385BB27001E8.attr preserve=no  private: string {V} 
      string m_strIMPACT_TO_ACQ;
      //## end database::CRTransactionTypeIndicator::IMPACT_TO_ACQ%385BB27001E8.attr

      //## Attribute: IMPACT_TO_ISS%385BB2AF0261
      //## begin database::CRTransactionTypeIndicator::IMPACT_TO_ISS%385BB2AF0261.attr preserve=no  private: string {V} 
      string m_strIMPACT_TO_ISS;
      //## end database::CRTransactionTypeIndicator::IMPACT_TO_ISS%385BB2AF0261.attr

      //## Attribute: Instance%54AE9B430352
      //## begin database::CRTransactionTypeIndicator::Instance%54AE9B430352.attr preserve=no  private: static CRTransactionTypeIndicator* {V} 0
      static CRTransactionTypeIndicator* m_pInstance;
      //## end database::CRTransactionTypeIndicator::Instance%54AE9B430352.attr

      //## Attribute: MEDIA_TYPE%385BB68600F2
      //## begin database::CRTransactionTypeIndicator::MEDIA_TYPE%385BB68600F2.attr preserve=no  private: string {V} 
      string m_strMEDIA_TYPE;
      //## end database::CRTransactionTypeIndicator::MEDIA_TYPE%385BB68600F2.attr

      //## Attribute: MSG_CLASS%385BB68502EF
      //## begin database::CRTransactionTypeIndicator::MSG_CLASS%385BB68502EF.attr preserve=no  private: string {V} 
      string m_strMSG_CLASS;
      //## end database::CRTransactionTypeIndicator::MSG_CLASS%385BB68502EF.attr

      //## Attribute: POST_ACH_TRAN_CODE%5EB2A6F501EC
      //## begin database::CRTransactionTypeIndicator::POST_ACH_TRAN_CODE%5EB2A6F501EC.attr preserve=no  private: string {U} 
      string m_strPOST_ACH_TRAN_CODE;
      //## end database::CRTransactionTypeIndicator::POST_ACH_TRAN_CODE%5EB2A6F501EC.attr

      //## Attribute: POST_CMS_PROC_CODE%5EB2A6DA0382
      //## begin database::CRTransactionTypeIndicator::POST_CMS_PROC_CODE%5EB2A6DA0382.attr preserve=no  private: string {U} 
      string m_strPOST_CMS_PROC_CODE;
      //## end database::CRTransactionTypeIndicator::POST_CMS_PROC_CODE%5EB2A6DA0382.attr

      //## Attribute: POST_DEP_DROP_IND%5EB2A6BE01D1
      //## begin database::CRTransactionTypeIndicator::POST_DEP_DROP_IND%5EB2A6BE01D1.attr preserve=no  private: string {U} 
      string m_strPOST_DEP_DROP_IND;
      //## end database::CRTransactionTypeIndicator::POST_DEP_DROP_IND%5EB2A6BE01D1.attr

      //## Attribute: POST_PROC_DROP_IND%5EB2A69E0107
      //## begin database::CRTransactionTypeIndicator::POST_PROC_DROP_IND%5EB2A69E0107.attr preserve=no  private: string {U} 
      string m_strPOST_PROC_DROP_IND;
      //## end database::CRTransactionTypeIndicator::POST_PROC_DROP_IND%5EB2A69E0107.attr

      //## Attribute: PRE_AUTH%385BB68503D5
      //## begin database::CRTransactionTypeIndicator::PRE_AUTH%385BB68503D5.attr preserve=no  private: string {V} 
      string m_strPRE_AUTH;
      //## end database::CRTransactionTypeIndicator::PRE_AUTH%385BB68503D5.attr

      //## Attribute: PROCESS_CODE%385BB684038E
      //## begin database::CRTransactionTypeIndicator::PROCESS_CODE%385BB684038E.attr preserve=no  private: string {V} 
      string m_strPROCESS_CODE;
      //## end database::CRTransactionTypeIndicator::PROCESS_CODE%385BB684038E.attr

      //## Attribute: TRAN_GROUP%45CC2866033A
      //## begin database::CRTransactionTypeIndicator::TRAN_GROUP%45CC2866033A.attr preserve=no  private: string {V} 
      string m_strTRAN_GROUP;
      //## end database::CRTransactionTypeIndicator::TRAN_GROUP%45CC2866033A.attr

      //## Attribute: TransactionType%54AE9C760262
      //## begin database::CRTransactionTypeIndicator::TransactionType%54AE9C760262.attr preserve=no  private: map<string,struct sTTISecond*,less<string> > {V} 
      map<string,struct sTTISecond*,less<string> > m_hTransactionType;
      //## end database::CRTransactionTypeIndicator::TransactionType%54AE9C760262.attr

    // Additional Implementation Declarations
      //## begin database::CRTransactionTypeIndicator%378B84F70349.implementation preserve=yes
      //## end database::CRTransactionTypeIndicator%378B84F70349.implementation

};

//## begin database::CRTransactionTypeIndicator%378B84F70349.postscript preserve=yes
//## end database::CRTransactionTypeIndicator%378B84F70349.postscript

} // namespace database

//## begin module%378B86AF035F.epilog preserve=yes
using namespace database;
//## end module%378B86AF035F.epilog


#endif
