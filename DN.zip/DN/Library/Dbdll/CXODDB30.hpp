//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3977659100B0.cm preserve=no
//	$Date:   Apr 13 2021 14:32:18  $ $Author:   e1033757  $ $Revision:   1.4  $
//## end module%3977659100B0.cm

//## begin module%3977659100B0.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3977659100B0.cp

//## Module: CXOSDB30%3977659100B0; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\Dbdll\CXODDB30.hpp

#ifndef CXOSDB30_h
#define CXOSDB30_h 1

//## begin module%3977659100B0.additionalIncludes preserve=no
//## end module%3977659100B0.additionalIncludes

//## begin module%3977659100B0.includes preserve=yes
//## end module%3977659100B0.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Timestamp;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class GMTClock;
class Date;
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;
class SwitchClock;

} // namespace database

//## begin module%3977659100B0.declarations preserve=no
//## end module%3977659100B0.declarations

//## begin module%3977659100B0.additionalDeclarations preserve=yes
//## end module%3977659100B0.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::InsertSequenceNumber%397765380057.preface preserve=yes
//## end database::InsertSequenceNumber%397765380057.preface

//## Class: InsertSequenceNumber%397765380057
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3F8AF1330138;timer::GMTClock { -> F}
//## Uses: <unnamed>%460347AA00E7;IF::Extract { -> F}
//## Uses: <unnamed>%460348CD00CC;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%46034B66007F;SwitchClock { -> F}
//## Uses: <unnamed>%460350E900DD;timer::Date { -> F}
//## Uses: <unnamed>%5B6DB17401B8;Database { -> F}
//## Uses: <unnamed>%5B6DB1770209;DatabaseFactory { -> F}
//## Uses: <unnamed>%5B6DB17F02B8;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5B6DB1820358;reusable::Query { -> F}
//## Uses: <unnamed>%5B6DB19D0068;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%5B6DB29D0303;IF::Timestamp { -> F}

class DllExport InsertSequenceNumber : public reusable::Observer  //## Inherits: <unnamed>%4603469F0261
{
  //## begin database::InsertSequenceNumber%397765380057.initialDeclarations preserve=yes
  //## end database::InsertSequenceNumber%397765380057.initialDeclarations

  public:
    //## Destructor (generated)
      virtual ~InsertSequenceNumber();


    //## Other Operations (specified)
      //## Operation: getYYYDDDHHMM%39776655026A
      static int getYYYDDDHHMM (const char* pszTSTAMP_TRANS = 0);

      //## Operation: getYYYYMMDDJJJHHMM%5B6DBCCF0160
      static reusable::string getYYYYMMDDJJJHHMM ();

      //## Operation: update%4603477E02FD
      virtual void update (reusable::Subject* pSubject);

      //## Operation: setInsertSequenceNumber%6074B0AE0122
      static void setInsertSequenceNumber ();

    // Additional Public Declarations
      //## begin database::InsertSequenceNumber%397765380057.public preserve=yes
      //## end database::InsertSequenceNumber%397765380057.public

  protected:
    // Additional Protected Declarations
      //## begin database::InsertSequenceNumber%397765380057.protected preserve=yes
      //## end database::InsertSequenceNumber%397765380057.protected

  private:
    //## Constructors (generated)
      InsertSequenceNumber();

    // Additional Private Declarations
      //## begin database::InsertSequenceNumber%397765380057.private preserve=yes
      //## end database::InsertSequenceNumber%397765380057.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Day%5B6DBE8A01F5
      //## begin database::InsertSequenceNumber::Day%5B6DBE8A01F5.attr preserve=no  private: static int  {U} 0
      static int  m_iDay;
      //## end database::InsertSequenceNumber::Day%5B6DBE8A01F5.attr

      //## Attribute: HistoryDays%46034916039D
      //## begin database::InsertSequenceNumber::HistoryDays%46034916039D.attr preserve=no  private: int  {U} 14
      int  m_iHistoryDays;
      //## end database::InsertSequenceNumber::HistoryDays%46034916039D.attr

      //## Attribute: HistoryDate%46034AC90258
      //## begin database::InsertSequenceNumber::HistoryDate%46034AC90258.attr preserve=no  public: static reusable::string {U} 
      static reusable::string m_strHistoryDate;
      //## end database::InsertSequenceNumber::HistoryDate%46034AC90258.attr

      //## Attribute: Hour%5B6DB019012A
      //## begin database::InsertSequenceNumber::Hour%5B6DB019012A.attr preserve=no  private: static int  {U} 0
      static int  m_iHour;
      //## end database::InsertSequenceNumber::Hour%5B6DB019012A.attr

      //## Attribute: InsertSequenceNumber%4C912D340169
      //## begin database::InsertSequenceNumber::InsertSequenceNumber%4C912D340169.attr preserve=no  private: static int {V} 0
      static int m_iInsertSequenceNumber;
      //## end database::InsertSequenceNumber::InsertSequenceNumber%4C912D340169.attr

      //## Attribute: Instance%46078D7901D4
      //## begin database::InsertSequenceNumber::Instance%46078D7901D4.attr preserve=no  private: static InsertSequenceNumber* {U} 0
      static InsertSequenceNumber* m_pInstance;
      //## end database::InsertSequenceNumber::Instance%46078D7901D4.attr

      //## Attribute: JulianDay%5B6DB00F01FA
      //## begin database::InsertSequenceNumber::JulianDay%5B6DB00F01FA.attr preserve=no  private: static int  {U} 0
      static int  m_iJulianDay;
      //## end database::InsertSequenceNumber::JulianDay%5B6DB00F01FA.attr

      //## Attribute: Min%5B6DB021003A
      //## begin database::InsertSequenceNumber::Min%5B6DB021003A.attr preserve=no  private: static int  {U} 0
      static int  m_iMin;
      //## end database::InsertSequenceNumber::Min%5B6DB021003A.attr

      //## Attribute: Month%5B6DBE8802DE
      //## begin database::InsertSequenceNumber::Month%5B6DBE8802DE.attr preserve=no  private: static int  {U} 0
      static int  m_iMonth;
      //## end database::InsertSequenceNumber::Month%5B6DBE8802DE.attr

      //## Attribute: Year%5B6DAFED017A
      //## begin database::InsertSequenceNumber::Year%5B6DAFED017A.attr preserve=no  private: static int  {U} 0
      static int  m_iYear;
      //## end database::InsertSequenceNumber::Year%5B6DAFED017A.attr

    // Additional Implementation Declarations
      //## begin database::InsertSequenceNumber%397765380057.implementation preserve=yes
      //## end database::InsertSequenceNumber%397765380057.implementation

};

//## begin database::InsertSequenceNumber%397765380057.postscript preserve=yes
//## end database::InsertSequenceNumber%397765380057.postscript

} // namespace database

//## begin module%3977659100B0.epilog preserve=yes
using namespace database;
//## end module%3977659100B0.epilog


#endif
