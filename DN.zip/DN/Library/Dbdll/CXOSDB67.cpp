//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5FEDE723036B.cm preserve=no
//	$Date:   Jul 19 2021 03:40:32  $ $Author:   e1044731  $ $Revision:   1.6  $
//## end module%5FEDE723036B.cm

//## begin module%5FEDE723036B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5FEDE723036B.cp

//## Module: CXOSDB67%5FEDE723036B; Package body
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: D:\V03.1B.R001\Devel\ConnexPlatform\Server\Library\Dbdll\CXOSDB67.cpp

//## begin module%5FEDE723036B.additionalIncludes preserve=no
//## end module%5FEDE723036B.additionalIncludes

//## begin module%5FEDE723036B.includes preserve=yes
#include <sstream>
//## end module%5FEDE723036B.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
#ifndef CXOSDB67_h
#include "CXODDB67.hpp"
#endif


//## begin module%5FEDE723036B.declarations preserve=no
//## end module%5FEDE723036B.declarations

//## begin module%5FEDE723036B.additionalDeclarations preserve=yes
//## end module%5FEDE723036B.additionalDeclarations


//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::Keystore 

//## begin database::Keystore::Instance%5FEDEB6B0117.attr preserve=no  private: static database::Keystore* {U} 0
database::Keystore* Keystore::m_pInstance = 0;
//## end database::Keystore::Instance%5FEDEB6B0117.attr

Keystore::Keystore()
  //## begin Keystore::Keystore%5FEDE8560267_const.hasinit preserve=no
      : m_pFile(0)
  //## end Keystore::Keystore%5FEDE8560267_const.hasinit
  //## begin Keystore::Keystore%5FEDE8560267_const.initialization preserve=yes
  //## end Keystore::Keystore%5FEDE8560267_const.initialization
{
  //## begin database::Keystore::Keystore%5FEDE8560267_const.body preserve=yes
   memcpy(m_sID,"DB67",4);
   m_strValidationPhrase = "Copyright (c) 2020 Fidelity National Information Services       ";
  //## end database::Keystore::Keystore%5FEDE8560267_const.body
}


Keystore::~Keystore()
{
  //## begin database::Keystore::~Keystore%5FEDE8560267_dest.body preserve=yes
  //## end database::Keystore::~Keystore%5FEDE8560267_dest.body
}



//## Other Operations (implementation)
bool Keystore::base32Decode (reusable::string strInput, reusable::string& strOutput)
{
  //## begin database::Keystore::base32Decode%5FEDEA5403A7.body preserve=yes
   if (m_hBase32.size() == 0)
   {
      m_hBase32['0'] = "00000";
      m_hBase32['1'] = "00001";
      m_hBase32['2'] = "00010";
      m_hBase32['3'] = "00011";
      m_hBase32['4'] = "00100";
      m_hBase32['5'] = "00101";
      m_hBase32['6'] = "00110";
      m_hBase32['7'] = "00111";
      m_hBase32['8'] = "01000";
      m_hBase32['9'] = "01001";
      m_hBase32['A'] = "01010";
      m_hBase32['B'] = "01011";
      m_hBase32['C'] = "01100";
      m_hBase32['D'] = "01101";
      m_hBase32['E'] = "01110";
      m_hBase32['F'] = "01111";
      m_hBase32['G'] = "10000";
      m_hBase32['H'] = "10001";
      m_hBase32['I'] = "10010";
      m_hBase32['J'] = "10011";
      m_hBase32['K'] = "10100";
      m_hBase32['L'] = "10101";
      m_hBase32['M'] = "10110";
      m_hBase32['N'] = "10111";
      m_hBase32['O'] = "11000";
      m_hBase32['P'] = "11001";
      m_hBase32['Q'] = "11010";
      m_hBase32['R'] = "11011";
      m_hBase32['S'] = "11100";
      m_hBase32['T'] = "11101";
      m_hBase32['U'] = "11110";
      m_hBase32['V'] = "11111";

      m_hBase64["0000"] = '0';
      m_hBase64["0001"] = '1';
      m_hBase64["0010"] = '2';
      m_hBase64["0011"] = '3';
      m_hBase64["0100"] = '4';
      m_hBase64["0101"] = '5';
      m_hBase64["0110"] = '6';
      m_hBase64["0111"] = '7';
      m_hBase64["1000"] = '8';
      m_hBase64["1001"] = '9';
      m_hBase64["1010"] = 'A';
      m_hBase64["1011"] = 'B';
      m_hBase64["1100"] = 'C';
      m_hBase64["1101"] = 'D';
      m_hBase64["1110"] = 'E';
      m_hBase64["1111"] = 'F';
   }
   //remove padding if any
   while (strInput[strInput.length() - 1] == '=')
      strInput.erase(strInput.length() - 1);

   string strTemp;
   map<char,string>::iterator q;
   for (int i = 0; i < strInput.length(); i++)
   {
      q = m_hBase32.find(strInput[i]);
      if (q == m_hBase32.end())
         return false; //invalid base32 character
      strTemp.append((*q).second);

   }
   while (strTemp.length() % 4 != 0)
      strTemp.insert(0,1,'0');
   map<string,char>::iterator p;
   while (strTemp.length() >= 4)
   {
      p = m_hBase64.find(strTemp.substr(strTemp.length() - 4));
      strOutput.insert(0,1,(*p).second);
      strTemp.erase(strTemp.length() - 4);
   }
   //remove leading zeros
   while (strOutput.length() > 16 && strOutput[0] == '0')
      strOutput.erase(0,1);
   return true;
  //## end database::Keystore::base32Decode%5FEDEA5403A7.body
}

bool Keystore::decrypt (reusable::string& strText)
{
  //## begin database::Keystore::decrypt%5FEDEA88032D.body preserve=yes
   unsigned char szCiphertext[109];
   memset(szCiphertext,' ',108);
   szCiphertext[108] = '\0';
   unsigned char szBase64text[109];
   memset(szBase64text,' ',108);
   szBase64text[108] = '\0';
   char szPlaintext[109];
   memset(szPlaintext,0,108);
   memcpy(szBase64text,strText.data(),strText.length());
   szBase64text[strText.length()] = '\0';
   ::ERR_clear_error();
   AES_KEY hDecryptKey;
   AES_set_decrypt_key((unsigned char *)m_strKey.c_str(),256,&hDecryptKey);
   //Base 64 uses '=' as the pad char discount them when calculating cipher len
   const char *pszPadCharPos = strchr((const char*)szBase64text,'=');
   int iNumPadChars = 0;
   if (pszPadCharPos != NULL)
   {
      iNumPadChars = strlen(pszPadCharPos);
   }
   int iCipherLen = EVP_DecodeBlock((unsigned char *)szCiphertext,szBase64text,strText.length()) - iNumPadChars;
   if (iCipherLen <= 0 || iCipherLen > 108)
      return false;
   int iCurrPos = 0;
   while (iCurrPos < iCipherLen)
   {
      AES_decrypt(szCiphertext + iCurrPos,(unsigned char *)szPlaintext + iCurrPos,&hDecryptKey);
      iCurrPos += 16;
   }
   strText.assign(szPlaintext,iCipherLen);
   return true;
  //## end database::Keystore::decrypt%5FEDEA88032D.body
}

bool Keystore::decryptPostilionPan (const reusable::string& strPostilionPan, reusable::string& strClearPan)
{
  //## begin database::Keystore::decryptPostilionPan%5FEDEAA7025C.body preserve=yes
   /*The format of the postilion encrypted PAN consists of the following:
     a two hex character key index,
     a constant character representing the encryption and encoding method,
     a two hex character length representing length of the clear PAN
     a base32 encoded data value using the 0-9,A-V with "=" for pad character

   For example: 08G106QDPSI02I31K2
    - key index 08
    - encryption and encoding "G" = triple DES ECB base32 encoded.
      (Note, this is the only method we have coded for)
    - hex length x'10' or 16 decimal
    - data "6QDPSI02I31K2"

   The formula for conversion of this value to PAN in the clear is:
   1. Decode base32 using 6QDPSI02I31K2 becomes x'B646D4DD51CAD4C7'
   2. decrypt using triple DES ECB (with appropriate 24 byte key) produces x'3815D5B9C9E6A4CB'
   3. Converting x'3815D5B9C9E6A4CB' to decimal yields 4041371234567890123 as the clear PAN.

   Note that keys are entered into the keystore as 2-24 hex character encoded key parts for each key index.
   The entered values are encrypted before being stored.
   The 2 key parts must be retrieved from the keystore, decrypted then contactenated to form a 48 character encoded key.
   This key is converted to an actual hex value of 24 bytes
   where the 1st 8 bytes are key1, 2nd 8 bytes are key2, and 3rd 8 bytes are key3 in the triple key DES algorithm.
   */
	if (strPostilionPan[2] != 'G')
      return false;
   string strIndex = strPostilionPan.substr(0,2);
   string strKey = Keystore::instance()->getKey(strIndex);
   if (strKey.length() == 0)
   {
      snprintf((char*)m_szOutBuffer,sizeof(m_szOutBuffer),"Error! Key index %s could not be found in keystore.",strIndex.c_str());
      Trace::put((char*)m_szOutBuffer,-1,true);
	  return false;
   }

   //clear pan length doesn't appear to be needed. 
   //  left the code here in case more examples demonstrate a need
   //string strClearPanLength(strPostilionPan.substr(3,2));
   //CodeTable::byteToNibble(strClearPanLength,m_szOutBuffer);
   //strClearPanLength.assign((char*)m_szOutBuffer,1);

   string strBase32 = strPostilionPan.substr(5);
   while (strBase32.length() < 13)
      strBase32 = "0" + strBase32;
   string strEncryptedHexPan;
   base32Decode(strBase32,strEncryptedHexPan);

   desecb3(strEncryptedHexPan,strKey,0); //decrypt
   unsigned long long ullPAN = 0;
   memcpy(m_szOutBuffer,strEncryptedHexPan.data(),strEncryptedHexPan.length());
   for (int i = 0; i < strEncryptedHexPan.length(); i++)
   {
      ullPAN <<= 8;
      ullPAN |= m_szOutBuffer[i];
   }
   std::ostringstream oss;
   oss << ullPAN;
   strClearPan.assign(oss.str().c_str(), oss.str().length());
   return true;
  //## end database::Keystore::decryptPostilionPan%5FEDEAA7025C.body
}

bool Keystore::desecb3 (reusable::string& strText, const reusable::string& strKey, int enc)
{
  //## begin database::Keystore::desecb3%5FEDF574002F.body preserve=yes
   //convert strText to actual hex (assumes strText contains character hex)
   CodeTable::byteToNibble(strText,m_szOutBuffer);
   strText.assign((char*)m_szOutBuffer,strText.length() / 2);

   DES_cblock left,right,middle;
   DES_key_schedule key1,key2,key3;
   DES_cblock input,output;

   memcpy(&left,(char*)strKey.data(),8);
   DES_set_odd_parity(&left);
   DES_set_key_checked(&left,&key1);

   memcpy(&middle,strKey.data() + 8,8);
   DES_set_odd_parity(&middle);
   DES_set_key_checked(&middle,&key2);

   if (strKey.length() == 24)
      memcpy(&right,strKey.data() + 16,8);
   else
      memcpy(&right,strKey.data(),8); //reuse 1st key as 3rd
   DES_set_odd_parity(&right);
   DES_set_key_checked(&right,&key3);

   DES_cblock initVector;
   memset((char*)initVector,'\0',8);

   string strTemp;
   int iLoops = strText.length() / 8;
   for (int i = 0; i < iLoops; i++)
   {
      memcpy((void*)input,strText.data() + (i * 8),8);
      ::DES_ecb3_encrypt(&input,&output,&key1,&key2,&key3,enc);
      strTemp.append((char*)output,8);
   }
   strText.assign(strTemp);
   return true;
  //## end database::Keystore::desecb3%5FEDF574002F.body
}

reusable::string Keystore::getKey (reusable::string& strKeyID)
{
  //## begin database::Keystore::getKey%5FEDEB3D03AD.body preserve=yes
   //concatenate key parts and return full key
   map<string,string,less<string> >::iterator q;
   if (strKeyID == "HM1" || strKeyID == "HM2")
   {
       q = m_hKeys.find(strKeyID);
       if (q == m_hKeys.end())
           return "";
       string strHM((*q).second);
       char szTemp[3] = { "  " };
       string strResult;
       for (int i = 0; i < strHM.length(); i++)
       {
           snprintf(szTemp, 3, "%02X", (unsigned char)strHM[i]);
           strResult.append(szTemp);
       }
       return strResult;
   }
   strKeyID.append("1");
   q = m_hKeys.find(strKeyID);
   if (q == m_hKeys.end())
      return "";
   string strKey((*q).second);
   strKeyID.replace(2,1,"2");
   q = m_hKeys.find(strKeyID);
   if (q == m_hKeys.end())
      return "";
   strKey.append((*q).second);
   return strKey;
  //## end database::Keystore::getKey%5FEDEB3D03AD.body
}

bool Keystore::initialize ()
{
  //## begin database::Keystore::initialize%5FEDEAED0011.body preserve=yes
   string strKeystoreFileName;
   if (!IF::Extract::instance()->getRecord("DFILES  KEYSTORE",strKeystoreFileName))
   {
      Trace::put("Warning! DFILES for keystore not found",-1,true);
      return false;
   }
   strKeystoreFileName.erase(0,16);
   trim(strKeystoreFileName);
#ifdef _WIN32
   strKeystoreFileName.insert(0,1,'\\');
#else
   strKeystoreFileName.insert(0,1,'/');
#endif
   strKeystoreFileName.insert(0,Extract::instance()->getNode001().c_str());
   if ((m_pFile = fopen(strKeystoreFileName.c_str(),"r")) == NULL)
   {
      snprintf((char*)m_szOutBuffer,sizeof(m_szOutBuffer),"Warning! Keystore %s could not be opened.",strKeystoreFileName.c_str());
      Trace::put((char*)m_szOutBuffer,-1,true);
      return false;
   }
   while (fgets((char*)m_szInBuffer,120,m_pFile) != NULL)
   {
      size_t m = strlen((char*)m_szInBuffer) - 1;
      m_hRecords.push_back(string((char*)m_szInBuffer,m));
   }
   fclose(m_pFile);
   if (m_hRecords.size() == 0)
   {
      Trace::put("Warning! no keys found in keystore",-1,true);
      return false;
   }
   string strPassphraseFileName(strKeystoreFileName);
   strPassphraseFileName.erase(strPassphraseFileName.length() - 3);
   strPassphraseFileName.append(".ps");
   if ((m_pFile = fopen(strPassphraseFileName.c_str(),"r")) == NULL)
   {
      snprintf((char*)m_szOutBuffer,sizeof(m_szOutBuffer),"Warning! Passphrase file %s could not be opened",strPassphraseFileName.c_str());
      Trace::put((char*)m_szOutBuffer,-1,true);
      return false;
   }
   //read passphrase
   m_strPassphrase.erase();
   while (fgets((char*)m_szInBuffer,120,m_pFile) != NULL)
   {
      size_t m = strlen((char*)m_szInBuffer) - 1;
      m_strPassphrase.append((char*)m_szInBuffer,m);
   }
   fclose(m_pFile);
   if (m_strPassphrase.empty())
   {
      Trace::put("Warning! Passphrase not found",-1,true);
      return false;
   }
   setKey();

   //validate passphrase
   string strPhrase = m_hRecords[0];
   decrypt(strPhrase);
   if (strPhrase != m_strValidationPhrase)
   {
      Trace::put("Warning! Passphrase is incorrect for this keystore",-1,true);
      return false;
   }
   for (int i = 1; i < m_hRecords.size(); i++)
   {
      memcpy(m_szInBuffer,m_hRecords[i].data(),m_hRecords[i].length());
      struct KeyData* pKeyData = (KeyData*)m_szInBuffer;
      string strCategory(pKeyData->sCategory,4);
      string strKeyID(pKeyData->sID,2);
      char chStatus = pKeyData->cStatus;
      if (strCategory != "PAN " && strCategory != "HMAC")
         continue;
      if (chStatus != 'A')
         continue;
      string strIDComponentNo(pKeyData->sID,2);
      strIDComponentNo.append(pKeyData->sComponentNumber,1);
      int iEncryptedKeyLength = (strCategory == "PAN ") ? 24 : 44;
      string strKeyPart(pKeyData->sKeyValue,iEncryptedKeyLength);
      decrypt(strKeyPart);
      strKeyPart.resize(iEncryptedKeyLength / 2);
      m_hKeys.insert(map<string,string,less<string> >::value_type(strIDComponentNo,strKeyPart));
   }
   return true;
  //## end database::Keystore::initialize%5FEDEAED0011.body
}

database::Keystore* Keystore::instance ()
{
  //## begin database::Keystore::instance%5FEDEB0001D8.body preserve=yes
   if (!m_pInstance)
   {
      m_pInstance = new Keystore();
      m_pInstance->initialize();
   }
   return m_pInstance;
  //## end database::Keystore::instance%5FEDEB0001D8.body
}

void Keystore::setKey ()
{
  //## begin database::Keystore::setKey%5FEDEB230291.body preserve=yes
   //construct an AES-256 key from the Passphrase
   static unsigned char buf[256] = {
   0x00,0x01,0x02,0x03,0x37,0x2D,0x2E,0x2F,0x16,0x05,0x25,0x0B,0x0C,0x0D,0x0E,0x0F,
   0x10,0x11,0x12,0x13,0x3C,0x3D,0x32,0x26,0x18,0x19,0x3F,0x27,0x1C,0x1D,0x1E,0x1F,
   0x40,0x5A,0x7F,0x7B,0x5B,0x6C,0x50,0x7D,0x4D,0x5D,0x5C,0x4E,0x6B,0x60,0x4B,0x61,
   0xF0,0xF1,0xF2,0xF3,0xF4,0xF5,0xF6,0xF7,0xF8,0xF9,0x7A,0x5E,0x4C,0x7E,0x6E,0x6F,
   0x7C,0xC1,0xC2,0xC3,0xC4,0xC5,0xC6,0xC7,0xC8,0xC9,0xD1,0xD2,0xD3,0xD4,0xD5,0xD6,
   0xD7,0xD8,0xD9,0xE2,0xE3,0xE4,0xE5,0xE6,0xE7,0xE8,0xE9,0xAD,0xE0,0xBD,0x5F,0x6D,
   0x79,0x81,0x82,0x83,0x84,0x85,0x86,0x87,0x88,0x89,0x91,0x92,0x93,0x94,0x95,0x96,
   0x97,0x98,0x99,0xA2,0xA3,0xA4,0xA5,0xA6,0xA7,0xA8,0xA9,0xC0,0x6A,0xD0,0xA1,0x07,
   0x20,0x21,0x22,0x23,0x24,0x25,0x06,0x17,0x28,0x29,0x2A,0x2B,0x2C,0x09,0x0A,0x1B,
   0x30,0x31,0x1A,0x33,0x34,0x35,0x36,0x08,0x38,0x39,0x3A,0x3B,0x04,0x14,0x3E,0xFF,
   0x41,0x42,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x4A,0x51,0x52,0x53,0x54,0x55,0x56,
   0x57,0x58,0x59,0x62,0x63,0x64,0x65,0x66,0x67,0x68,0x69,0x6A,0x70,0x71,0x72,0x73,
   0x74,0x75,0x76,0x77,0x78,0x80,0x8A,0x8B,0x8C,0x8D,0x8E,0x8F,0x90,0x9A,0x9B,0x9C,
   0x9D,0x9E,0x9F,0xA0,0xAA,0xAB,0xAC,0xAE,0xAF,0xB0,0xB1,0xB2,0xB3,0xB4,0xB5,0xB6,
   0xB7,0xB8,0xB9,0xBA,0xBB,0xBC,0xBE,0xBF,0xCA,0xCB,0xCC,0xCD,0xCE,0xCF,0xDA,0xDB,
   0xDC,0xDD,0xDE,0xDF,0xE1,0xEA,0xEB,0xEC,0xED,0xEE,0xEF,0xFA,0xFB,0xFC,0xFD,0xFE };
   int f = 2;
   while (m_strKey.length() < 32)
   {
      f++;
      for (int i = 0; i < m_strPassphrase.length(); i++)
      {
         char c = m_strPassphrase[i];
         size_t m = c + f;
         m = m % 256;
         m_strKey.append(1,(const unsigned char)buf[m]);
      }
   }
   m_strKey.resize(32);
  //## end database::Keystore::setKey%5FEDEB230291.body
}

bool Keystore::hmac (const reusable::string& strData, const reusable::string& strKey, reusable::string& strResult)
{
  //## begin database::Keystore::hmac%5FEDF36E01D3.body preserve=yes
   //convert key from character hex to actual hex
   unsigned char szKey[65];
   CodeTable::byteToNibble(strKey, szKey);
   szKey[strKey.length() / 2] = '\0';

   //convert data from character hex to actual hex
   unsigned char szData[29];
   CodeTable::byteToNibble(strData, szData);
   szData[strData.length() / 2] = '\0';
   unsigned char md[129];
   unsigned int md_len;
   const EVP_MD* evp_md = EVP_sha1();
   unsigned char* p = HMAC(evp_md, szKey, strKey.length() / 2, szData, strData.length() / 2, md, &md_len);
   //convert result to character hex
   CodeTable::nibbleToByte((char*)p,md_len,strResult);
   return true;
  //## end database::Keystore::hmac%5FEDF36E01D3.body
}

// Additional Declarations
  //## begin database::Keystore%5FEDE8560267.declarations preserve=yes
  //## end database::Keystore%5FEDE8560267.declarations

} // namespace database

//## begin module%5FEDE723036B.epilog preserve=yes
//## end module%5FEDE723036B.epilog
