//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%367EBFA50015.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%367EBFA50015.cm

//## begin module%367EBFA50015.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%367EBFA50015.cp

//## Module: CXOSDB15%367EBFA50015; Package body
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXOSDB15.cpp

//## begin module%367EBFA50015.additionalIncludes preserve=no
//## end module%367EBFA50015.additionalIncludes

//## begin module%367EBFA50015.includes preserve=yes
// $Date:   Jan 19 2022 06:39:24  $ $Author:   e3015517  $ $Revision:   1.6  $
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
//## end module%367EBFA50015.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB15_h
#include "CXODDB15.hpp"
#endif
#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif


//## begin module%367EBFA50015.declarations preserve=no
//## end module%367EBFA50015.declarations

//## begin module%367EBFA50015.additionalDeclarations preserve=yes
//## end module%367EBFA50015.additionalDeclarations


//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

// Class database::DuplicateIndex 



DuplicateIndex::DuplicateIndex()
  //## begin DuplicateIndex::DuplicateIndex%367EBA3F0126_const.hasinit preserve=no
  //## end DuplicateIndex::DuplicateIndex%367EBA3F0126_const.hasinit
  //## begin DuplicateIndex::DuplicateIndex%367EBA3F0126_const.initialization preserve=yes
  //## end DuplicateIndex::DuplicateIndex%367EBA3F0126_const.initialization
{
  //## begin database::DuplicateIndex::DuplicateIndex%367EBA3F0126_const.body preserve=yes
   memcpy(m_sID,"DB15",4);
   Database::instance()->attach(this);
   MidnightAlarm::instance()->attach(this);
   if (!Extract::instance()->getSpec("DRPX2FL", m_strDRPX2FL))
      m_strDRPX2FL = "0";
  //## end database::DuplicateIndex::DuplicateIndex%367EBA3F0126_const.body
}


DuplicateIndex::~DuplicateIndex()
{
  //## begin database::DuplicateIndex::~DuplicateIndex%367EBA3F0126_dest.body preserve=yes
   MidnightAlarm::instance()->detach(this);
   Database::instance()->detach(this);
  //## end database::DuplicateIndex::~DuplicateIndex%367EBA3F0126_dest.body
}



//## Other Operations (implementation)
bool DuplicateIndex::dropIndex ()
{
  //## begin database::DuplicateIndex::dropIndex%367EBE970323.body preserve=yes
#ifdef MVS
   char* pszMember = "DN##DRFI";
#else
   char* pszMember = "CXOXDRDI";
#endif
   if (m_strDRPX2FL == "0")
   {
      if (!Job::submit(pszMember, "&YYYYMM ", m_strName.substr(4, 6).c_str()))
         Console::display("ST270", pszMember);
   }
   else
   {
      if (!Job::submit(pszMember, "&YYYYMM ", m_strName.substr(4, 6).c_str(), "&DRPX2FL", m_strDRPX2FL.c_str()))
         Console::display("ST270", pszMember);
   }
   Console::display("ST112",m_strName.c_str());
   UseCase::addItem();
   return true;
  //## end database::DuplicateIndex::dropIndex%367EBE970323.body
}

bool DuplicateIndex::queryCatalog ()
{
  //## begin database::DuplicateIndex::queryCatalog%367EBD400009.body preserve=yes
   UseCase hUseCase("DR","## DR19 DROP INDEX");
   Query hQuery;
   hQuery.bind("SYSINDEXES", "NAME", Column::STRING, &m_strName);
   hQuery.setBasicPredicate("SYSINDEXES","CREATOR","=",Database::instance()->qualifier().c_str());
#ifdef MVS
   hQuery.setBasicPredicate("SYSINDEXES","DBNAME","=",Database::instance()->getName().c_str());
#endif
   hQuery.setBasicPredicate("SYSINDEXES","NAME","LIKE","X2FL%");
   hQuery.setOrderByClause("SYSINDEXES.NAME");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.attach(this);
   pSelectStatement->execute(hQuery);
   Database::instance()->commit();
   return true;
  //## end database::DuplicateIndex::queryCatalog%367EBD400009.body
}

void DuplicateIndex::update (Subject* pSubject)
{
  //## begin database::DuplicateIndex::update%367EBB04011F.body preserve=yes
   if (Database::instance()->state() == Database::DISCONNECTED)
      return;
   if (pSubject == Database::instance()
      || pSubject == MidnightAlarm::instance())
   {
      if (Clock::instance()->getDay() > 14)
         queryCatalog();
      return;
   }
   string strYYYYMM(Clock::instance()->getYYYYMMDDHHMMSS().data(),6);
   if (m_strDRPX2FL != "0")
   {
      Date hDate(string(m_strName.substr(4, 6) + "01").c_str());
      hDate.incrementMonth(atoi(m_strDRPX2FL.c_str()));
      m_strName.replace(4,6,hDate.asString("%Y%m"));
   }
   if (m_strName.substr(4,6) < strYYYYMM)
      dropIndex();
  //## end database::DuplicateIndex::update%367EBB04011F.body
}

// Additional Declarations
  //## begin database::DuplicateIndex%367EBA3F0126.declarations preserve=yes
  //## end database::DuplicateIndex%367EBA3F0126.declarations

} // namespace database

//## begin module%367EBFA50015.epilog preserve=yes
//## end module%367EBFA50015.epilog
