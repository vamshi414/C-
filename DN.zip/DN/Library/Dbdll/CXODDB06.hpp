//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%35F9615701D5.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%35F9615701D5.cm

//## begin module%35F9615701D5.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%35F9615701D5.cp

//## Module: CXOSDB06%35F9615701D5; Package specification
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\PvcsWork\Dn\Server\Library\DBDLL\CXODDB06.hpp

#ifndef CXOSDB06_h
#define CXOSDB06_h 1

//## begin module%35F9615701D5.additionalIncludes preserve=no
//## end module%35F9615701D5.additionalIncludes

//## begin module%35F9615701D5.includes preserve=yes
// $Date:   Apr 08 2004 10:16:46  $ $Author:   D02405  $ $Revision:   1.2  $
//## end module%35F9615701D5.includes

#ifndef CXOSIF20_h
#include "CXODIF20.hpp"
#endif

//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
class Context;

} // namespace database

//## begin module%35F9615701D5.declarations preserve=no
//## end module%35F9615701D5.declarations

//## begin module%35F9615701D5.additionalDeclarations preserve=yes
//## end module%35F9615701D5.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::GlobalContext%34B2BF930022.preface preserve=yes
//## end database::GlobalContext%34B2BF930022.preface

//## Class: GlobalContext%34B2BF930022
//	The GlobalContext class provides an interface to save
//	and restore global context information in persistent
//	storage.
//
//	CXODDB06.hpp
//	CXOSDB06.cpp
//## Category: DataNavigator Foundation::Database_CAT%3451F34D0218
//## Subsystem: DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%397744870083;Context { -> F}

class DllExport GlobalContext : public IF::SharedResource  //## Inherits: <unnamed>%34B2BFC903CD
{
  //## begin database::GlobalContext%34B2BF930022.initialDeclarations preserve=yes
  //## end database::GlobalContext%34B2BF930022.initialDeclarations

  public:
    //## Constructors (generated)
      GlobalContext();

    //## Constructors (specified)
      //## Operation: GlobalContext%34B2C1700259
      //	Create a new global context item.
      //## Semantics:
      //	1. Call SharedResource::SharedResource(pszName).
      GlobalContext (const char* pszName);

    //## Destructor (generated)
      virtual ~GlobalContext();


    //## Other Operations (specified)
      //## Operation: get%34B2C2160348
      //	Retrieve a global context item from persistent storage.
      bool get (string& strData, char cType = ' ');

      //## Operation: put%34B2C21C02ED
      //	Save a global context item in persistent storage.
      bool put (const char* pszData, char cType = ' ');

    // Additional Public Declarations
      //## begin database::GlobalContext%34B2BF930022.public preserve=yes
      //## end database::GlobalContext%34B2BF930022.public

  protected:
    // Additional Protected Declarations
      //## begin database::GlobalContext%34B2BF930022.protected preserve=yes
      //## end database::GlobalContext%34B2BF930022.protected

  private:
    // Additional Private Declarations
      //## begin database::GlobalContext%34B2BF930022.private preserve=yes
      //## end database::GlobalContext%34B2BF930022.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin database::GlobalContext%34B2BF930022.implementation preserve=yes
      //## end database::GlobalContext%34B2BF930022.implementation

};

//## begin database::GlobalContext%34B2BF930022.postscript preserve=yes
//## end database::GlobalContext%34B2BF930022.postscript

} // namespace database

//## begin module%35F9615701D5.epilog preserve=yes
using namespace database;
//## end module%35F9615701D5.epilog


#endif
