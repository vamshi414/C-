//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3EC3E2B200BB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3EC3E2B200BB.cm

//## begin module%3EC3E2B200BB.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3EC3E2B200BB.cp

//## Module: CXOSDB11%3EC3E2B200BB; Package specification
//## Subsystem: DBDLL%35758D89000D
//	.
//## Source file: C:\Devel\ConnexPlatform\Server\Library\DBDLL\CXODDB11.hpp

#ifndef CXOSDB11_h
#define CXOSDB11_h 1

//## begin module%3EC3E2B200BB.additionalIncludes preserve=no
//## end module%3EC3E2B200BB.additionalIncludes

//## begin module%3EC3E2B200BB.includes preserve=yes
// $Date:   Oct 03 2013 07:19:02  $ $Author:   e1009839  $ $Revision:   1.3  $
#include <map>
//## end module%3EC3E2B200BB.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSDB12_h
#include "CXODDB12.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class DatabaseCatalogVisitor;

} // namespace database

//## begin module%3EC3E2B200BB.declarations preserve=no
//## end module%3EC3E2B200BB.declarations

//## begin module%3EC3E2B200BB.additionalDeclarations preserve=yes
//## end module%3EC3E2B200BB.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::DatabaseTable%3EC3DC8E007D.preface preserve=yes
//## end database::DatabaseTable%3EC3DC8E007D.preface

//## Class: DatabaseTable%3EC3DC8E007D
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3EC3E45D036B;reusable::Query { -> F}
//## Uses: <unnamed>%3EC3EFC5031C;DatabaseCatalogVisitor { -> F}
//## Uses: <unnamed>%3EC4C1E601B5;IF::Extract { -> F}
//## Uses: <unnamed>%3EC4C682007D;DatabaseFactory { -> F}
//## Uses: <unnamed>%3EC4C68402DE;reusable::SelectStatement { -> F}

class DllExport DatabaseTable : public reusable::Observer  //## Inherits: <unnamed>%3EC3DEC6037A
{
  //## begin database::DatabaseTable%3EC3DC8E007D.initialDeclarations preserve=yes
  //## end database::DatabaseTable%3EC3DC8E007D.initialDeclarations

  public:
    //## Constructors (generated)
      DatabaseTable();

      DatabaseTable(const DatabaseTable &right);

    //## Constructors (specified)
      //## Operation: DatabaseTable%3EC4BC34030D
      DatabaseTable (const string& strName);

    //## Destructor (generated)
      virtual ~DatabaseTable();

    //## Assignment Operation (generated)
      DatabaseTable & operator=(const DatabaseTable &right);


    //## Other Operations (specified)
      //## Operation: accept%3EC3E9C4034B
      void accept (DatabaseCatalogVisitor& hDatabaseCatalogVisitor);

      //## Operation: bind%3EC3E448031C
      void bind (Query& hQuery);

      //## Operation: getColumnCount%3EC3F9FE0271
      int getColumnCount ();

      //## Operation: update%3EC3F0100109
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Name%3EC3DE350109
      const string& getName () const
      {
        //## begin database::DatabaseTable::getName%3EC3DE350109.get preserve=no
        return m_strName;
        //## end database::DatabaseTable::getName%3EC3DE350109.get
      }

      void setName (const string& value)
      {
        //## begin database::DatabaseTable::setName%3EC3DE350109.set preserve=no
        m_strName = value;
        //## end database::DatabaseTable::setName%3EC3DE350109.set
      }


    // Additional Public Declarations
      //## begin database::DatabaseTable%3EC3DC8E007D.public preserve=yes
      //## end database::DatabaseTable%3EC3DC8E007D.public

  protected:
    // Additional Protected Declarations
      //## begin database::DatabaseTable%3EC3DC8E007D.protected preserve=yes
      //## end database::DatabaseTable%3EC3DC8E007D.protected

  private:
    // Additional Private Declarations
      //## begin database::DatabaseTable%3EC3DC8E007D.private preserve=yes
      bool m_bUpperCase;
      //## end database::DatabaseTable%3EC3DC8E007D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin database::DatabaseTable::Name%3EC3DE350109.attr preserve=no  public: string {V} 
      string m_strName;
      //## end database::DatabaseTable::Name%3EC3DE350109.attr

    // Data Members for Associations

      //## Association: Connex Library::Database_CAT::<unnamed>%3EC3DE57000F
      //## Role: DatabaseTable::<m_hDatabaseColumns>%3EC3DE580177
      //## Qualifier: Name%3EC3DE7D0196; string
      //## begin database::DatabaseTable::<m_hDatabaseColumns>%3EC3DE580177.role preserve=no  public: database::DatabaseColumn { -> VHgN}
      map<string, DatabaseColumn, less<string> > m_hDatabaseColumns;
      //## end database::DatabaseTable::<m_hDatabaseColumns>%3EC3DE580177.role

      //## Association: Connex Library::Database_CAT::<unnamed>%3EC4BFA50119
      //## Role: DatabaseTable::<m_hDatabaseColumn>%3EC4BFA6001F
      //## begin database::DatabaseTable::<m_hDatabaseColumn>%3EC4BFA6001F.role preserve=no  public: database::DatabaseColumn { -> VHgN}
      DatabaseColumn m_hDatabaseColumn;
      //## end database::DatabaseTable::<m_hDatabaseColumn>%3EC4BFA6001F.role

    // Additional Implementation Declarations
      //## begin database::DatabaseTable%3EC3DC8E007D.implementation preserve=yes
      //## end database::DatabaseTable%3EC3DC8E007D.implementation

};

//## begin database::DatabaseTable%3EC3DC8E007D.postscript preserve=yes
//## end database::DatabaseTable%3EC3DC8E007D.postscript

} // namespace database

//## begin module%3EC3E2B200BB.epilog preserve=yes
using namespace database;
//## end module%3EC3E2B200BB.epilog


#endif
