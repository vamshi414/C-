//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5E1335C0000B.cm preserve=no
//	$Date:   Sep 03 2020 07:08:54  $ $Author:   e3028298  $
//	$Revision:   1.1  $
//## end module%5E1335C0000B.cm

//## begin module%5E1335C0000B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5E1335C0000B.cp

//## Module: CXOSDB65%5E1335C0000B; Package specification
//## Subsystem: Connex Library::DBDLL%35758D89000D
//	.
//## Source file: D:\Devel\V03.1A.R007\ConnexPlatform\Server\Library\Dbdll\CXODDB65.hpp

#ifndef CXOSDB65_h
#define CXOSDB65_h 1

//## begin module%5E1335C0000B.additionalIncludes preserve=no
//## end module%5E1335C0000B.additionalIncludes

//## begin module%5E1335C0000B.includes preserve=yes
//## end module%5E1335C0000B.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%5E1335C0000B.declarations preserve=no
//## end module%5E1335C0000B.declarations

//## begin module%5E1335C0000B.additionalDeclarations preserve=yes
//## end module%5E1335C0000B.additionalDeclarations


namespace database {
//## begin database%3451F34D0218.initialDeclarations preserve=yes
//## end database%3451F34D0218.initialDeclarations

//## begin database::EntityOption%5E132F5600E5.preface preserve=yes
//## end database::EntityOption%5E132F5600E5.preface

//## Class: EntityOption%5E132F5600E5
//## Category: Connex Library::Database_CAT%3451F34D0218
//## Subsystem: Connex Library::DBDLL%35758D89000D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5E13310603D2;DatabaseFactory { -> F}
//## Uses: <unnamed>%5E133109035B;reusable::Query { -> F}
//## Uses: <unnamed>%5E13310C03AB;reusable::SelectStatement { -> F}

class DllExport EntityOption : public reusable::Observer  //## Inherits: <unnamed>%5E132F78031E
{
  //## begin database::EntityOption%5E132F5600E5.initialDeclarations preserve=yes
  //## end database::EntityOption%5E132F5600E5.initialDeclarations

  public:
    //## Constructors (generated)
      EntityOption();

    //## Destructor (generated)
      virtual ~EntityOption();


    //## Other Operations (specified)
      //## Operation: get%5E132FA50059
      bool get (const reusable::string& strENTITY_TYPE, const reusable::string& strENTITY_ID, const reusable::string& strCUST_ID, const char* pszUSE_CASE_NAME, map<string,string,less<string> >* pSetting);

      //## Operation: instance%5E1333390303
      static EntityOption* instance ();

      //## Operation: loadUseCaseOptions%5F3B584102A4
      bool loadUseCaseOptions (const char* pszUSE_CASE_NAME, const string& strCUST_ID, map<string,string,less<string> >* pUsecaseOptions);

      //## Operation: update%5E132F8A02B6
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin database::EntityOption%5E132F5600E5.public preserve=yes
      //## end database::EntityOption%5E132F5600E5.public

  protected:
    // Additional Protected Declarations
      //## begin database::EntityOption%5E132F5600E5.protected preserve=yes
      //## end database::EntityOption%5E132F5600E5.protected

  private:
    // Additional Private Declarations
      //## begin database::EntityOption%5E132F5600E5.private preserve=yes
      //## end database::EntityOption%5E132F5600E5.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ENTITY_ID%5F3B5908030B
      //## begin database::EntityOption::ENTITY_ID%5F3B5908030B.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strENTITY_ID;
      //## end database::EntityOption::ENTITY_ID%5F3B5908030B.attr

      //## Attribute: ENTITY_TYPE%5F3B58D00322
      //## begin database::EntityOption::ENTITY_TYPE%5F3B58D00322.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strENTITY_TYPE;
      //## end database::EntityOption::ENTITY_TYPE%5F3B58D00322.attr

      //## Attribute: Instance%5E133353021B
      //## begin database::EntityOption::Instance%5E133353021B.attr preserve=no  private: static EntityOption* {V} 0
      static EntityOption* m_pInstance;
      //## end database::EntityOption::Instance%5E133353021B.attr

      //## Attribute: OPTION_KEY%5E13317A011C
      //## begin database::EntityOption::OPTION_KEY%5E13317A011C.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strOPTION_KEY;
      //## end database::EntityOption::OPTION_KEY%5E13317A011C.attr

      //## Attribute: OPTION_VALUE%5E1331940288
      //## begin database::EntityOption::OPTION_VALUE%5E1331940288.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strOPTION_VALUE;
      //## end database::EntityOption::OPTION_VALUE%5E1331940288.attr

      //## Attribute: Setting%5E13320B0254
      //## begin database::EntityOption::Setting%5E13320B0254.attr preserve=no  private: map<string,string,less<string> >* {V} 0
      map<string,string,less<string> >* m_pSetting;
      //## end database::EntityOption::Setting%5E13320B0254.attr

    // Additional Implementation Declarations
      //## begin database::EntityOption%5E132F5600E5.implementation preserve=yes
      //## end database::EntityOption%5E132F5600E5.implementation

};

//## begin database::EntityOption%5E132F5600E5.postscript preserve=yes
//## end database::EntityOption%5E132F5600E5.postscript

} // namespace database

//## begin module%5E1335C0000B.epilog preserve=yes
//## end module%5E1335C0000B.epilog


#endif
