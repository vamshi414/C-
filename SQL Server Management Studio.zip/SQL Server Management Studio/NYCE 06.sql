/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [DX_FILE_ID]
      ,[SEQ_NO]
      ,[ALT_REC_KEY]
      ,[DATA_BUFFER]
  FROM [DN1P].[DN1PGTWY].[DX_DATA_20240320]


alter table  DN1PGTWY.EMS_TRANSITION add AMT_ACPT_TRAN DECIMAL(18)

alter table  DN1PGTWY.EMS_TRANSITION add AMT_ACPT_NET DECIMAL(18)
alter table  DN1PGTWY.EMS_TRANSITION add AMT_ADJ_TRAN DECIMAL(18)


  select * from DN1PCOMN.X_NET_INST_ID

select * from DN1PGTWY.DX_DATA_CONTROL where DX_FILE_TYPE='NYCEXP'
update DN1PGTWY.DX_DATA_CONTROL set DX_STATE !='DC'
select * from DN1PGTWY.DX_DATA_CONTROL where DX_FILE_TYPE='NYCREJ'
delete from DN1PGTWY.DX_DATA_CONTROL where DX_FILE_ID=1490803
select * from DN1PGTWY.EMS_CASE

  select * from DN1PGTWY.FIN_L202402
  select * from DN1PGTWY.FIN_L202403
  841510115              

select * from DN1PGTWY.EMS_CASE
select * from DN1PGTWY.EMS_TRANSITION where CASE_ID=1
select * from DN1PGTWY.EMS_PHASE_NYC

delete from DN1PGTWY.EMS_CASE where CASE_ID=1

select * from DN1PGTWY.GDG_DATA_CONTROL
delete from DN1PGTWY.GDG_DATA_CONTROL where GDG_FILE_TYPE='NYCREJ'
select * from DN1PGTWY.GDG_DATA_CONTROL where GDG_FILE_TYPE='NYCREJ'


select * from DN1PGTWY.EMS_PHASE_NYC

select * from DN1PGTWY.DI_DATA_CONTROL
select * from DN1PGTWY.DI_DATA

  delete from DN1PGTWY.DI_DATA
  delete from DN1PGTWY.DI_DATA_CONTROL











select * from DN1PGTWY.DI_DATA
select * from DN1PGTWY.DI_DATA_CONTROL


