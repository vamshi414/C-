/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [DX_FILE_ID]
      ,[SEQ_NO]
      ,[ALT_REC_KEY]
      ,[DATA_BUFFER]
  FROM [DN1P].[DN1PGTWY].[DX_DATA_20240401]

select * from DN1PGTWY.DX_DATA_CONTROL where DX_FILE_TYPE='NYCREJ'
delete from DN1PGTWY.DX_DATA_CONTROL  where DX_FILE_ID='1490814'
delete from DN1PGTWY.DX_DATA_CONTROL  where DX_FILE_TYPE='NYCREJ'

select * from DN1PGTWY.GDG_DATA_CONTROL

select * from DN1PGTWY.EMS_CASE
delete from DN1PGTWY.EMS_CASE
select * from DN1PGTWY.EMS_TRANSITION

select * from DN1PGTWY.EMS_PHASE_NYC

update DN1PGTWY.DX_DATA_CONTROL set DX_STATE= 'DW' where DX_FILE_ID='1490815'

select * from DN1PGTWY.EMS_DOCUMENT

\\MKEDDH01\DNDocs\NYC\OUT\202405\GTWYREQ_DOC001GP0032DKB4C.PDF
select * from DN1PGTWY.GDG_DATA_CONTROL
delete from DN1PGTWY.GDG_DATA_CONTROL where GDG_FILE_TYPE='NYCREJ'


select * from DN1PGTWY.EMS_TRANSITION




select * from DN1PCOMN.TRAN_TYPE_IND



select  from DN1PGTWY.FIN_RECORD202404

select TRAN  from DN1PGTWY.FIN_L202404

select * from DN1PGTWY.FIN_L202404


select * from DN1PCOMN.TRAN_TYPE_IND

select * from DN1PGTWY.NETWORK_FEE

alter table  DN1PGTWY.NETWORK_FEE alter column PAN char(28)


select * from DN1PGTWY.TASK_CONTEXT

SELECT * FROM SYS.OBJECTS
SELECT * FROM SYS.filegroups where name like '%DX_%'





