--qfktBeDXOhcrgbeu            
select * from DN1PGTWY.EMS_CASE where CASE_ID IN ('246412516','246412517')


select TSTAMP_TRANS,CASE_ID,CASE_NO,NET_RULES,ACQ_CASE_NO,ISS_CASE_NO,ACQ_CUST_ID,ISS_CUST_ID,NET_ID_ACQ,NET_ID_ISS,NET_ID_EMS from DN1PGTWY.EMS_CASE where CASE_ID IN ('246412516','246412517')
select * from DN1PGTWY.EMS_TRANSITION  where CASE_ID IN ('246412516','246412517')

select * from DN1PGTWY.EMS_CASE  where CASE_ID IN ('246412516','246412517')


select * from DN1PGTWY.EMS_CASE_CONTEXT where CASE_ID IN ('246412516','246412517')


select NET_ID_EMS from DN1PGTWY.EMS_CASE where CASE_ID IN ('246412516','246412517')

select * from DN1PGTWY.EMS_CREDIT  where CASE_ID='246412517'

select * from DN1PGTWY.EMS_CASE

select * from DN1PGTWY.EMS_CASE where CASE_ID IN ('246412516','246412517')
select * from DN1PGTWY.EMS_TRANSITION  where CASE_ID IN ('246412516','246412517')
select * from DN1PGTWY.EMS_CREDIT  where CASE_ID='246412517'

delete from DN1PGTWY.EMS_CASE where CASE_ID IN ('246412516','246412517')

select *  from DN1PGTWY.EMS_PHASE_VNT_VROL

select * from DN1PCOMN.INSTITUTION where INST_ID='840407779'
update DN1PCOMN.INSTITUTION set DISPUTE_PROC_ID='FX02433' where INST_ID='840407779'

select *  from DN1PGTWY.FIN_L202211 where PAN like '551066020%'

--FX02433 
update DN1PGTWY.FIN_L202301 set PAN='4179290100000168'  where TSTAMP_TRANS IN ('2023013009481840','2023013009481830');
--4179290100000163            
update DN1PGTWY.FIN_L202301 set PAN_SUFFIX='0168'  where TSTAMP_TRANS IN ('2023013009481840','2023013009481830');
select * from DN1PGTWY.FIN_L202301 where TSTAMP_TRANS IN ('2023013009481840','2023013009481830');
select * from DN1PGTWY.FIN_RECORD202301 where TSTAMP_TRANS IN('2023013009481840','2023013009481830');

update DN1PGTWY.FIN_RECORD202301 set NET_ID_ACQ='STR',NET_ID_ISS='STR' where  TSTAMP_TRANS='2023013009481830'


update DN1PGTWY.FIN_L202301 set FIN_TYPE='010' where  TSTAMP_TRANS='2023013009481830'
update DN1PGTWY.FIN_L202301 set FIN_TYPE='010' where  TSTAMP_TRANS='2023013009481840'

select * from DN1PGTWY.EMS_DATA_CHG  where CASE_ID IN ('246412516','246412517')

update DN1PGTWY.FIN_L202301 set TSTAMP_LOCAL='20230130094818' where  UNIQUENESS_KEY=9116


update DN1PGTWY.FIN_RECORD202301 set TSTAMP_TRANS='2023013009481830' where  UNIQUENESS_KEY=9115
update DN1PGTWY.FIN_RECORD202301 set TSTAMP_TRANS='2023013009481840' where  UNIQUENESS_KEY=9116


select *  from DN1PGTWY.FIN_L202301 where PAN='4179290100000176'
select *  from DN1PGTWY.FIN_RECORD202211 where TSTAMP_TRANS='2022112909481930'
--4179290100000177            
update DN1PGTWY.FIN_L202211 set PAN='4179290100000176' where TSTAMP_TRANS='2022113009481830'
update DN1PGTWY.FIN_L202211 set PAN_PREFIX='417929',PAN_SUFFIX='0177' where TSTAMP_TRANS='2022112909481930'

select * from DN1PCOMN.X_NET_INST_ID

select * from DN1PGTWY.MESSAGE_LOG


delete from  DN1PGTWY.API_QUEUE_CONTROL where QUEUE_ID IN (11,13,14,17,16,15)

INSERT [DN1PGTWY].[API_QUEUE_RESPONSE] ([QUEUE_ID], [SEQ_NO], [DATA_BUFFER]) VALUES (12,0, N'<?xml version=''1.0'' encoding=''UTF-8''?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"><soapenv:Header/><soapenv:Body><SIGetQueueResponse xmlns="http://www.visa.com/ROLSI"><Status><Code>I-300000000</Code><Message>Successfully completed Operation.</Message></Status><ResponseData> <QueueType>ALL_AWAITING_ACTION_DISPUTE</QueueType><PageInfo><PageNum>1</PageNum><TotalPages>2</TotalPages></PageInfo><Queue><FormatDQueueItem><VisaCaseNumber>1049413035</VisaCaseNumber><CaseStatus>Consumer Dispute - Saved</CaseStatus><DaysToAct>0</DaysToAct><DisputeAmt currency="840">115.00</DisputeAmt><AccountNumber>12345678</AccountNumber><MemberCaseNumber>GTWY-20200903000002</MemberCaseNumber><ARN>24515507336000000446440</ARN><RetrievalReferenceNumber>733672000000</RetrievalReferenceNumber><User>BCFS RTSI Web Service MTE2 WSI, Member Test - FIS - BCFS(Metavante)</User><LastActionDate>2018-02-27T18:20:28+00:00</LastActionDate><MerchantName>Manual Cash</MerchantName><NetworkID>0002</NetworkID><Jurisdiction jurisdictionCd="DOM"> <Jurisdiction>US (United States Of America)</Jurisdiction> </Jurisdiction><InternalId transactiononType="DISPREQ"><Id>399050</Id></InternalId></FormatDQueueItem></Queue></ResponseData></SIGetQueueResponse> </soapenv:Body></soapenv:Envelope>')


select * from DN1PGTWY.EMS_CASE

--20230118000002
delete from DN1PGTWY.DX_DATA_20230608


select * from DN1PGTWY.DX_DATA_20230608
select * from DN1PGTWY.DX_DATA_20230811

select * from DN1PGTWY.API_QUEUE_CONTROL
select * from DN1PGTWY.API_QUEUE_RESPONSE
select * from DN1PGTWY.API_QUEUE_REQUEST



select * from DN1PGTWY.API_QUEUE_CONTROL where QUEUE_ID=12
select * from DN1PGTWY.API_QUEUE_RESPONSE where QUEUE_ID=12
delete from DN1PGTWY.API_QUEUE_RESPONSE where QUEUE_ID=12
select * from DN1PGTWY.API_QUEUE_REQUEST where QUEUE_ID=12




select * from DN1PGTWY.T_ATM_ACTIVITY

select * from DN1PCOMN.DN_SYMBOLS
select * from DN1PCOMN.DN_KEYSTORE
select * from DN1PCOMN.TASK_CONTEXT_COMN where CONTEXT_TYPE='K'


select * from DN1PGTWY.FIN_L202211

select * from DN1PGTWY.FIN_L202211 group by PAN having count(*) > 1;


select PAN from
(
  select PAN, count(PAN) as num
  from  DN1PGTWY.FIN_L202211
  group by PAN
) as statistic
where num > 1;

update DN1PGTWY.FIN_RECORD202211 set MTI=1210 where  TSTAMP_TRANS='2022112909481930'

update DN1PGTWY.FIN_L202211 set  FIN_TYPE='010'  where TSTAMP_TRANS='2022112909481930'

update DN1PGTWY.FIN_L202211 set  TSTAMP_TRANS='2022112909481930' where PAN='qfktBeDXOhcrgbeu'
update DN1PGTWY.FIN_RECORD202211 set TSTAMP_TRANS='2022112909481930' where  INSERT_SEQUENCE_NO='260320705'

update DN1PGTWY.FIN_RECORD202211 set TSTAMP_TRANS='2022112909481930' where  INSERT_SEQUENCE_NO='260320705'

update DN1PGTWY.FIN_L202211 set PAN='qfktBeDXOhcrgbeu' where TSTAMP_TRANS='2022112909481930'  

select * from DN1PGTWY.FIN_L202211 where TSTAMP_TRANS='2022112909481930'


select * from DN1PCOMN.INSTITUTION where INST_ID='000001177'

select * from DN1PGTWY.API_QUEUE_CONTROL

INSERT DN1PGTWY.[API_QUEUE_CONTROL] ([QUEUE_ID], [TSTAMP_EVENT], [API_STATE], [API_TYPE], [CASE_ID], [REQ_TYPE], [RETRY_COUNT], [API_RESULT], [TSTAMP_CREATED]) 
VALUES (11, N'2023022215382600', N'AC', N'VCR       ', 0, N'SIGetDisputeDetailsResponse', -1, N'Case processing succeeded.', N'2021033010384103')

update DN1PGTWY.[API_QUEUE_CONTROL] set CASE_ID=0,RETRY_COUNT=0,API_RESULT=' ' where REQ_TYPE='SIGetDisputeDetailsResponse'


--INSERT [DN1PGTWY].[API_QUEUE_RESPONSE] ([QUEUE_ID], [SEQ_NO], [DATA_BUFFER]) 
--VALUES (11,3, N'<?xml version=''1.0'' encoding=''UTF-8''?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"><soapenv:Header/><soapenv:Body><SIGetDisputeDetailsResponse xmlns="http://www.visa.com/ROLSI"><Status><Code>I-300000000</Code><Message>Successfully completed Operation.</Message></Status><ResponseData><TransactionInfo><AccountNumber>qfktBeDXOhcrgbeuabcq</AccountNumber><Token>qfktBeDXOhcrgbeuabcq</Token><Transaction id="301007568985836"><TranDate>2022-11-29</TranDate><Amount currency="840">19.00</Amount></Transaction><MerchantName>D 10 CP</MerchantName><MerchantCity>CITY NAME</MerchantCity><MerchantCountryCode>US</MerchantCountryCode><MerchantPostalCode>22102</MerchantPostalCode><MCC>5999</MCC><ARN>24515501007000180037036</ARN><ReimbursementAttribute>J</ReimbursementAttribute><CPD>2022-11-29</CPD><TransactionCategory>D</TransactionCategory><AcquirerBID>00000014</AcquirerBID><NetworkID>0002</NetworkID><AcquirerBIN>468881</AcquirerBIN><RetrievalReferenceNumber>303207036766</RetrievalReferenceNumber><SystemTraceAuditNumber>036766</SystemTraceAuditNumber><TranDestAmt currency="840">19.00</TranDestAmt><IssuerName>City National Bank</IssuerName><AcquirerName>Intl Hdqtrs-Center Owned</AcquirerName><AccountType>00</AccountType><DisputeJurisdiction jurisdictionCd="DOM"><Jurisdiction>DOMESTIC-US</Jurisdiction><IssuerRegion>US</IssuerRegion><AcquirerRegion>US</AcquirerRegion><CountryCd>US</CountryCd></DisputeJurisdiction></TransactionInfo><VisaCaseNumber>1053097707</VisaCaseNumber><DisputeId>1734257</DisputeId><AEMInd>NotConfigured</AEMInd><DisputeCategory>12</DisputeCategory></ResponseData></SIGetDisputeDetailsResponse></soapenv:Body></soapenv:Envelope>

delete from DN1PGTWY.API_QUEUE_RESPONSE where QUEUE_ID=12

INSERT [DN1PGTWY].[API_QUEUE_RESPONSE] ([QUEUE_ID], [SEQ_NO], [DATA_BUFFER]) 
VALUES (11,3, N'<?xml version=''1.0'' encoding=''UTF-8''?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"><soapenv:Header/><soapenv:Body><SIGetDisputeDetailsResponse xmlns="http://www.visa.com/ROLSI"><Status><Code>I-300000000</Code><Message>Successfully completed Operation.</Message></Status><ResponseData><TransactionInfo><AccountNumber></AccountNumber><Token>4179290100000177</Token><Transaction id="301007568985836"><TranDate>2022-11-29</TranDate><Amount currency="840">19.00</Amount></Transaction><MerchantName>D 10 CP</MerchantName><MerchantCity>CITY NAME</MerchantCity><MerchantCountryCode>US</MerchantCountryCode><MerchantPostalCode>22102</MerchantPostalCode><MCC>5999</MCC><ARN>24515501007000180037036</ARN><ReimbursementAttribute>J</ReimbursementAttribute><CPD>2022-11-29</CPD><TransactionCategory>D</TransactionCategory><AcquirerBID>00000014</AcquirerBID><NetworkID>0002</NetworkID><AcquirerBIN>468881</AcquirerBIN><RetrievalReferenceNumber>303207036766</RetrievalReferenceNumber><SystemTraceAuditNumber>036766</SystemTraceAuditNumber><TranDestAmt currency="840">19.00</TranDestAmt><IssuerName>City National Bank</IssuerName><AcquirerName>Intl Hdqtrs-Center Owned</AcquirerName><AccountType>00</AccountType><DisputeJurisdiction jurisdictionCd="DOM"><Jurisdiction>DOMESTIC-US</Jurisdiction><IssuerRegion>US</IssuerRegion><AcquirerRegion>US</AcquirerRegion><CountryCd>US</CountryCd></DisputeJurisdiction></TransactionInfo><VisaCaseNumber>1053097707</VisaCaseNumber><DisputeId>1734257</DisputeId><AEMInd>NotConfigured</AEMInd><DisputeCategory>12</DisputeCategory></ResponseData></SIGetDisputeDetailsResponse></soapenv:Body></soapenv:Envelope>')



select * from DN1PGTWY.API_QUEUE_CONTROL     
select * from DN1PGTWY.API_QUEUE_RESPONSE
select * from DN1PGTWY.API_QUEUE_REQUEST

delete from DN1PGTWY.API_QUEUE_RESPONSE where QUEUE_ID=11

INSERT DN1PGTWY.[API_QUEUE_CONTROL] ([QUEUE_ID], [TSTAMP_EVENT], [API_STATE], [API_TYPE], [CASE_ID], [REQ_TYPE], [RETRY_COUNT], [API_RESULT], [TSTAMP_CREATED]) 
VALUES (, N'2023022215382600', N'AC', N'VCR       ', 0, N'VCRADISPUTES', -1, N'', N'2021033010384103')

update DN1PGTWY.API_QUEUE_CONTROL set API_STATE='AC' where QUEUE_ID=15


update DN1PGTWY.API_QUEUE_CONTROL set API_STATE='AS' where QUEUE_ID=12
update DN1PGTWY.API_QUEUE_CONTROL set API_RESULT='' where QUEUE_ID=12
update DN1PGTWY.API_QUEUE_CONTROL set RETRY_COUNT=0 where QUEUE_ID=12


update DN1PGTWY.API_QUEUE_RESPONSE set QUEUE_ID=17 where QUEUE_ID=12
update DN1PGTWY.API_QUEUE_REQUEST set QUEUE_ID=17 where QUEUE_ID=12

select * from DN1PGTWY.TASK_CONTEXT


select * from DN1PCOMN.X_NETWORK_STATUS

select * from DN1PGTWY.EMS_CREDIT
--111014325
--211177133
select * from DN1PCOMN.X_NET_INST_ID


INSERT [DN1PCOMN].[X_NET_INST_ID] ([NET_INST_ID_CODE], [PAN_PREFIX], [INST_ID], [INST_STAT], [CUST_ID], [CUST_STAT], [NET_ID], [X_STAT], [CC_CHANGE_GRP_ID], [CC_STATE], [CC_LAST_OPERATION], [CC_USER_ID], [CC_TSTAMP_CHANGE]) 
VALUES (N'0021010    ', N'468881      ', N'111014325  ', N' ', N'GTWY', N' ', N'VNT', N' ', NULL, N'A', N'INS', N'E5644299', N'20200928132206')


select * from DN1PCOMN.INSTITUTION where INST_ID='211177133'
select * from DN1PCOMN.INSTITUTION where INST_ID='111014325'  

update DN1PCOMN.X_NET_INST_ID set INST_ID='211177133' where PAN_PREFIX='468881'

delete from DN1PGTWY.API_QUEUE_RESPONSE where queue_id=12

INSERT [DN1PGTWY].[API_QUEUE_RESPONSE] ([QUEUE_ID], [SEQ_NO], [DATA_BUFFER]) VALUES (12,0, N'<?xml version=''1.0'' encoding=''UTF-8''?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"><soapenv:Header/><soapenv:Body><SIGetQueueResponse xmlns="http://www.visa.com/ROLSI"><Status><Code>I-300000000</Code><Message>Successfully completed Operation.</Message></Status><ResponseData> <QueueType>ALL_AWAITING_ACTION_DISPUTE</QueueType><PageInfo><PageNum>1</PageNum><TotalPages>2</TotalPages></PageInfo><Queue><FormatDQueueItem><VisaCaseNumber>1049413035</VisaCaseNumber><CaseStatus>Consumer Dispute - Saved</CaseStatus><DaysToAct>0</DaysToAct><DisputeAmt currency="840">115.00</DisputeAmt><AccountNumber>12345678</AccountNumber><MemberCaseNumber>GTWY-20200903000002</MemberCaseNumber><ARN>24515507336000000446440</ARN><RetrievalReferenceNumber>733672000000</RetrievalReferenceNumber><User>BCFS RTSI Web Service MTE2 WSI, Member Test - FIS - BCFS(Metavante)</User><LastActionDate>2018-02-27T18:20:28+00:00</LastActionDate><MerchantName>Manual Cash</MerchantName><NetworkID>0002</NetworkID><Jurisdiction jurisdictionCd="DOM"> <Jurisdiction>US (United States Of America)</Jurisdiction> </Jurisdiction><InternalId transactiononType="DISPREQ"><Id>399050</Id></InternalId></FormatDQueueItem></Queue></ResponseData></SIGetQueueResponse> </soapenv:Body></soapenv:Envelope>')

INSERT [DN1PGTWY].[API_QUEUE_RESPONSE] ([QUEUE_ID], [SEQ_NO], [DATA_BUFFER]) VALUES (12,0, N'<?xml version=''1.0'' encoding=''UTF-8''?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"><soapenv:Header/><soapenv:Body><SIGetQueueResponse xmlns="http://www.visa.com/ROLSI"><Status><Code>I-300000000</Code><Message>Successfully completed Operation.</Message></Status><ResponseData> <QueueType>ALL_AWAITING_ACTION_DISPUTE</QueueType><PageInfo><PageNum>1</PageNum><TotalPages>2</TotalPages></PageInfo><Queue><FormatDQueueItem><VisaCaseNumber>1049413035</VisaCaseNumber><CaseStatus>Consumer Dispute - Saved</CaseStatus><DaysToAct>0</DaysToAct><DisputeAmt currency="840">115.00</DisputeAmt><AccountNumber>12345678</AccountNumber><MemberCaseNumber>GTWY-20230118000002</MemberCaseNumber><ARN>24515507336000000446440</ARN><RetrievalReferenceNumber>733672000000</RetrievalReferenceNumber><User>BCFS RTSI Web Service MTE2 WSI, Member Test - FIS - BCFS(Metavante)</User><LastActionDate>2018-02-27T18:20:28+00:00</LastActionDate><MerchantName>Manual Cash</MerchantName><NetworkID>0002</NetworkID><Jurisdiction jurisdictionCd="DOM"> <Jurisdiction>US (United States Of America)</Jurisdiction> </Jurisdiction><InternalId transactiononType="DISPREQ"><Id>399050</Id></InternalId></FormatDQueueItem></Queue></ResponseData></SIGetQueueResponse> </soapenv:Body></soapenv:Envelope>')



INSERT [DN1PGTWY].API_QUEUE_REQUEST ([QUEUE_ID], [SEQ_NO], [DATA_BUFFER]) VALUES (12,0, N'<?xml version=''1.0'' ?> <env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:rol="http://www.visa.com/ROLSI"><env:Header/><env:Body><SIGetQueueRequest xmlns="http://www.visa.com/ROLSI"><RequestHeader><User id="XXXXXXXXXX" type="internalId"/><MemberRole>A</MemberRole></RequestHeader><RequestData><QueueType>ALL_AWAITING_ACTION_DISPUTE</QueueType></RequestData></SIGetQueueRequest></env:Body></env:Envelope>')



INSERT [DN1PGTWY].[API_QUEUE_RESPONSE] ([QUEUE_ID], [SEQ_NO], [DATA_BUFFER]) VALUES (11,3, N'<?xml version=''1.0'' encoding=''UTF-8''?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"><soapenv:Header/><soapenv:Body><SIGetDisputeDetailsResponse xmlns="http://www.visa.com/ROLSI"><Status><Code>I-300000000</Code><Message>Successfully completed Operation.</Message></Status><ResponseData><TransactionInfo><AccountNumber>cDOK4YQKNVQwWqQxDCfj05Bz82HI1eL3bmS3TRJ+fnbHKDO7YBgHfmLB3pdm+Wb2Fuvh4Veu91pY+UPPc939A==</AccountNumber><Token>4367800003713403</Token><Transaction id="301007568985836"><TranDate>2022-11-29</TranDate><Amount currency="840">19.00</Amount></Transaction><MerchantName>D 10 CP</MerchantName><MerchantCity>CITY NAME</MerchantCity><MerchantCountryCode>US</MerchantCountryCode><MerchantPostalCode>22102</MerchantPostalCode><MCC>5999</MCC><ARN>24515501007000180037036</ARN><ReimbursementAttribute>J</ReimbursementAttribute><CPD>2022-11-29</CPD><TransactionCategory>D</TransactionCategory><AcquirerBID>00000014</AcquirerBID><NetworkID>0002</NetworkID><AcquirerBIN>468881</AcquirerBIN><RetrievalReferenceNumber>303207036766</RetrievalReferenceNumber><SystemTraceAuditNumber>036766</SystemTraceAuditNumber><TranDestAmt currency="840">19.00</TranDestAmt><IssuerName>City National Bank</IssuerName><AcquirerName>Intl Hdqtrs-Center Owned</AcquirerName><AccountType>00</AccountType><DisputeJurisdiction jurisdictionCd="DOM"><Jurisdiction>DOMESTIC-US</Jurisdiction><IssuerRegion>US</IssuerRegion><AcquirerRegion>US</AcquirerRegion><CountryCd>US</CountryCd></DisputeJurisdiction></TransactionInfo><VisaCaseNumber>1053097707</VisaCaseNumber><DisputeId>1734257</DisputeId><AEMInd>NotConfigured</AEMInd><DisputeCategory>12</DisputeCategory></ResponseData></SIGetDisputeDetailsResponse></soapenv:Body></soapenv:Envelope>')




select * from DN1PCOMN.MISC_CFG_DATA
delete from DN1PCOMN.MISC_CFG_DATA

select * from DN1PGTWY.DATA_MODEL where TABLE_NAME like '%202308'

select * from DN1PGTWY.DATA_MODEL where TABLE_NAME like '%202310'


select * from DN1PGTWY.FIN_L202310
select ADL_DATA_PRIV_ACQ,ADL_DATA_PRIV_ISS,TSTAMP_TRANS,CIRC_ID_ISS from DN1PGTWY.FIN_RECORD202310 order by TSTAMP_TRANS
select * from DN1PGTWY.FIN_RECORD202310 order by TSTAMP_TRANS



delete from DN1PGTWY.FIN_RECORD202310
delete from DN1PGTWY.FIN_L202310


select * from DN1PGTWY.GDG_DATA_CONTROL where TASKID='GTLR1' and GDG_NUMBER=3
delete from DN1PGTWY.GDG_DATA_CONTROL where TASKID='GTLR1' and GDG_NUMBER=5

select * from DN1PGTWY.EMS_CASE_STR