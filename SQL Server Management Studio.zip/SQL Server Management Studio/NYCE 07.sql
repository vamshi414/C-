/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [DX_FILE_ID]
      ,[SEQ_NO]
      ,[ALT_REC_KEY]
      ,[DATA_BUFFER]
  FROM [DN1P].[DN1PGTWY].[DX_DATA_20240401]


select ACCT_ID_1 from DN1P.DN1PGTWY.FIN_RECORD202404


select * from DN1PCOMN.TASK_CONTEXT_COMN

select * from DN1PCOMN.STS_CUSTOMER


select * from DN1PGTWY.FIN_L202404
update DN1PGTWY.FIN_L202404 set FIN_TYPE='010' where PAN='5510101344392820'
select * from DN1PCOMN.AS_USER_LOGON

select * from DN1PGTWY.DI_DATA
select * from DN1PGTWY.DI_DATA_CONTROL

delete from DN1PGTWY.DI_DATA
delete from DN1PGTWY.DI_DATA_CONTROL


select * from DN1PGTWY.EMS_PHASE_NYC

select * from DN1PGTWY.DX_DATA_CONTROL where DX_FILE_TYPE='NYCIN'


select * from DN1PGTWY.GDG_DATA_CONTROL
delete from DN1PGTWY.GDG_DATA_CONTROL where GDG_FILE_TYPE='NYCIN'


select * from DN1PGTWY.EMS_CASE

select * from DN1PGTWY.EMS_PHASE_NYC
update DN1PGTWY.EMS_PHASE_NYC set NYCE_CASE_NO='606500114350'

select * from DN1PGTWY.EMS_DOCUMENT

select * from DN1PCOMN.STS_CUSTOMER

select * from DN1PCOMN.SYS_HEALTH_MON

SELECT * FROM sys.database_files

select * from DN1PGTWY.T_RECON_TOTAL

select * from DN1PGTWY.FIN_RECORD202404




