/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [IMAGEID]
      ,[TASKID]
      ,[CONTEXT_TYPE]
      ,[CONTEXT_KEY]
      ,[CONTEXT_DATA]
  FROM [DN1P].[DN1PGTWY].[TASK_CONTEXT] where (TASKID='GTTE' and CONTEXT_KEY like '%PROGRESS%') or CONTEXT_KEY like '@CLOSED%' or CONTEXT_KEY like '@SWITCH%'


  update [DN1PGTWY].[TASK_CONTEXT] set CONTEXT_DATA='202104221121031' where CONTEXT_KEY='ADMIN PROGRESS'

  update [DN1PGTWY].[TASK_CONTEXT] set CONTEXT_DATA='202104221121032' where CONTEXT_KEY='CUTOFF PROGRESS'


  select * from DN1PGTWY.TASK_CONTEXT


  select * from DN1PCOMN.AS_USER_LOGON



  select * from DN1PCOMN.CRTBDTT

  select * from DN1PCOMN.CRCHGET

  select * from DN1PCOMN.CRCHGPT


  select * from DN1PGTWY.FIN_RECORD202104


  select * from DN1PGTWY.FIN_L202104 where SYS_TRACE_AUDIT_NO='000356'

