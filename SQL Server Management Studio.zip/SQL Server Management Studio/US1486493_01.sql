/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [DX_FILE_ID]
      ,[SEQ_NO]
      ,[ALT_REC_KEY]
      ,[DATA_BUFFER]
  FROM [DN1P].[DN1PGTWY].[DX_DATA_20230830]


 -- delete   FROM [DN1P].[DN1PGTWY].[DX_DATA_20230830]



 select * from DN1PGTWY.DX_DATA_CONTROL where DX_FILE_TYPE='TXNACT'







