
select * from DN1PCOMN.INSTITUTION where INST_ID='000000178'

select STATUS,REQUEST_TYPE from DN1PGTWY.EMS_CASE 



delete from DN1PGTWY.EMS_CASE
delete from DN1PGTWY.EMS_CASE_MCI


--delete DN1PGTWY.EMS_CASE where CASE_ID=0

select * from DN1PGTWY.FIN_ICC202111

select * from DN1PCOMN.EMSR_NET_RULE_USE where ISS_NETWORK='MCI'

select * from DN1PCOMN.EMSR_ACTION

select * from DN1PCOMN.EMSR_TRANSITION

select * from DN1PGTWY.DX_DATA_20211119

delete from DN1PGTWY.DX_DATA_20211117

select * from DN1PGTWY.FIN_L202111
--000000000351

select SYS_TRACE_AUDIT_NO from DN1PGTWY.EMS_CASE

select * from DN1PGTWY.EMS_COMMENT

select * from  DN1PGTWY.EMS_NATIONAL_NET

select * from DN1PGTWY.EMS_FIN_PRE_AUTH


select * from DN1PGTWY.DI_DATA
select * from DN1PGTWY.GDG_DATA_CONTROL  

delete  from DN1PGTWY.GDG_DATA_CONTROL where TASKID='GTEI'

--select * from DN1PGTWY.DX_DATA_20211115

--delete from DN1PGTWY.DX_DATA_20211115

select * from DN1PCOMN.X_NET_INST_ID

ALTER TABLE [DN1P].DN1PGTWY.EMS_CASE ADD bin_length CHAR(2)


INSERT [DN1PCOMN].[X_NET_INST_ID] ([NET_INST_ID_CODE], [PAN_PREFIX], [INST_ID], [INST_STAT], [CUST_ID], [CUST_STAT], [NET_ID], [X_STAT], [CC_CHANGE_GRP_ID], [CC_STATE], [CC_LAST_OPERATION], [CC_USER_ID], [CC_TSTAMP_CHANGE]) VALUES (N'0021010    ', N'537929      ', N'000000178  ', N' ', N'GTWY', N' ', N'MCI', N' ', NULL, N'A', N'INS', N'E5644299', N'20200928132206')
GO



select * from DN1PGTWY.DX_DATA_CONTROL where DX_FILE_ID='1008396'
select * from DN1PGTWY.DX_DATA_CONTROL where DX_FILE_TYPE = 'ECOUT'

update DN1PGTWY.DX_DATA_CONTROL set DX_STATE = 'DC' where DX_FILE_ID='1008385'


select * from DN1PGTWY.DI_DATA_CONTROL 

update DN1PGTWY.DX_DATA_CONTROL set ENTITY_ID='PRC822' where DX_FILE_ID='1008396'



select * from DN1PCOMN.DX_FILE_GROUP
select * from DN1PCOMN.DX_PROC_DEST


select * from DN1PCOMN.DX_FILE

update DN1PGTWY.DX_DATA_CONTROL set DX_STATE='PI' where DX_FILE_ID ='1008396'


select * from DN1PGTWY.DI_DATA
select * from DN1PGTWY.DI_DATA_CONTROL


select * from DN1PGTWY.FIN_L202111 where PAN_PREFIX='537929'


select * from DN1PGTWY.EMS_CASE_CONTEXT
select * from DN1PCOMN.EMSR_TRANSITION where PHASE_ID='FEIN' and RULE_SET_ID='MCI'

select * from DN1PGTWY.EMS_PHASE







select * from DN1PCOMN.EMS_UNMATCHED_MSG

select * from DN1PGTWY.EMS_CASE
select * from DN1PGTWY.EMS_CASE_MCI
select * from DN1PGTWY.EMS_PHASE_MCI

select * from DN1PGTWY.EMS_TRANSITION

select * from DN1PGTWY.EMS_CASE_CONTEXT


select * from DN1PGTWY.EMS_TRANSITION


select * from DN1PGTWY.EMS_CASE where TRAN_TYPE_ID = ' ';


ALTER TABLE [DN1P].DN1PGTWY.EMS_PHASE_MCI ADD MC_DUE_DATE CHAR(8)

ALTER TABLE [DN1P].DN1PGTWY.EMS_PHASE_MCI ADD MC_LAST_MOD_DATE CHAR(8)


select CARD_ACPT_ID,DATA_PRIV_ISS,DATA_PRIV_ACQ,ADL_DATA_PRIV_ACQ,ADL_DATA_PRIV_ISS,REF_DATA_ACQ,REF_DATA_ISS from DN1PGTWY.FIN_RECORD202111

select * from DN1PGTWY.EXCEPTION202111

select * from DN1PGTWY.FIN_RECORD202111


select * from DN1PGTWY.FIN_L202111
--2021 11 01 07095532
--476173
--3552
select * from DN1PCOMN.X_NET_INST_ID

--MCI
update DN1PCOMN.X_NET_INST_ID set NET_ID='MCI' where INST_ID='000000178'


select * from DN1PCOMN.AS_PERMISSION

select * from DN1PGTWY.EMS_CASE_EBT




select * from DN1PCOMN.CONTACT_TYPE
select * from DN1PCOMN.STS_CUSTOMER


select * from DN1PCOMN.TASK_CONTEXT_COMN where CONTEXT_TYPE='K'
select * from DN1PCOMN.TASK_CONTEXT_COMN




--select * from DN1PCOMN.TASK_CONTEXT

select * from DN1PCOMN.DN_SYMBOLS

select * from DN1PCOMN.DN_KEYSTORE


select * from DN1PGTWY.FIN_RECORD202112
select * from DN1PGTWY.FIN_L202111
--20210210140954

select * from DN1PGTWY.FIN_L202112

select TSTAMP_TRANS,PAN,INST_ID_RECON_ACQ,INST_ID_RECON_ISS from DN1PGTWY.FIN_L202112 where TSTAMP_TRANS='2021120901461790'
select * from DN1PGTWY.FIN_L202112 where TSTAMP_TRANS='2021120901461790'
000002367
211170347


select * from DN1PGTWY.FIN_L202112 where INST_ID_RECON_ISS='211170347'



select TSTAMP_LOCAL,TSTAMP_TRANS,TSTAMP_UPDATED from DN1PGTWY.EMS_CASE

select * from DN1PGTWY.FIN_RECORD202112


select FRD_POSTED_DATE from DN1PGTWY.EMS_FRAUD_MCI


select * from DN1PGTWY.EMS_CASE

select * from DN1PGTWY.GDG_DATA_CONTROL


select * from DN1PGTWY.PROBLEM_TRAN

select *  from DN1PGTWY.FIN_RECORD202112
select * from DN1PCOMN.X_ADV_PROC_CODE


select * from DN1PCOMN.EMSR_RULE_SET where NET_ID_EMS='MCI'
select * from DN1PCOMN.EMSR_NET_RULE_USE  where NET_ID_EMS='MCI'
select * from DN1PCOMN.EMSR_RULE_PHASE  

select * from DN1PCOMN.EMSR_TRANSITION where NEXT_PHASE_ID LIKE 'FEE%' 

select * from DN1PCOMN.EMSR_NET_RULE_USE
select * from DN1PCOMN.X_NET_INST_ID



select * from DN1PCOMN.INSTITUTION  where INST_ID='000000178'

select * from DN1PGTWY.DX_DATA_CONTROL where DX_FILE_TYPE='TXNACT'

select * from DN1PGTWY.DX_DATA_CONTROL where DX_STATE != 'DC'
select * from DN1PGTWY.DX_DATA_CONTROL where DATE_RECON='20220107'
update DN1PGTWY.DX_DATA_CONTROL set DX_STATE = 'DC' where DATE_RECON !='20220107'


select * from DN1PGTWY.GDG_DATA_CONTROL
delete from DN1PGTWY.GDG_DATA_CONTROL where TASKID='GTEI'


update DN1PGTWY.GDG_DATA_CONTROL set GDG_STATE = 'II' where TASKID='GTEI'

delete from DN1PGTWY.EMS_CASE where CASE_ID=0


select * from DN1PGTWY.EMS_DATA_CHG
select * from DN1PGTWY.EMS_CASE
select * from DN1PGTWY.EMS_CASE_MCI
select * from DN1PGTWY.EMS_TRANSITION
select * from DN1PGTWY.EMS_CASE_CONTEXT
select * from DN1PGTWY.EMS_PHASE
select * from DN1PGTWY.EMS_NATIONAL_NET




select * from DN1PGTWY.EMS_CASE_CONTEXT


select * from DN1PCOMN.EMS_UNMATCHED_MSG
delete from DN1PCOMN.EMS_UNMATCHED_MSG

ALTER TABLE [DN1P].DN1PGTWY.EMS_CASE ADD AMT_INST_FEE INT



select * from DN1PGTWY.DI_DATA_CONTROL

ALTER TABLE [DN1P].DN1PGTWY.GDG_DATA_CONTROL ADD REPORT_DATE CHAR(8)
ALTER TABLE [DN1P].DN1PGTWY.GDG_DATA_CONTROL ADD REPORT_NAME CHAR(8)


SELECT X_NET_INST_ID.INST_ID,X_NET_INST_ID.NET_INST_ID_CODE FROM DN1PCOMN.X_NET_INST_ID X_NET_INST_ID WHERE ((X_NET_INST_ID.PAN_PREFIX LIKE '0%') OR X_NET_INST_ID.PAN_PREFIX = ?) AND (X_NET_INST_ID.NET_INST_ID_CODE LIKE '%           %') AND X_NET_INST_ID.NET_ID = ? AND X_NET_INST_ID.CC_STATE = ? ORDER BY X_NET_INST_ID.PAN_PREFIX DESC
select * from DN1PGTWY.API_QUEUE_CONTROL


select * from DN1PCOMN.DEVICE

select * from DN1PGTWY.API_QUEUE_RESPONSE

insert into dn1pgtwy.api_queue_control values('63','2022011201443764','AS','EFTPOS','-1','initiate','-1','2022011201443764',' ');

insert into dn1pgtwy.api_queue_response values('63','0','<disputeState><expiryDate>2021-12-29</expiryDate><expiryTime>12-12-21</expiryTime><currentStateDescription>TBA</currentStateDescription><phaseExpiryDate>2021-12-21</phaseExpiryDate><phaseExpiryTime>12-12-21</phaseExpiryTime><currentState>NewACQ</currentState><previousState>disputeInitiated</previousState></disputeState><disputedTransaction><systemTraceAuditNumber>002874</systemTraceAuditNumber><paymentSequenceNumber>001</paymentSequenceNumber><channelTypeCode>inStore</channelTypeCode><bin>541333</bin><processingCode>016501</processingCode><cardholderAcceptMethod>notSpecified</cardholderAcceptMethod><cashbackAmount>123.45</cashbackAmount><localTransactionDate>2021-12-11</localTransactionDate><settlementDate>2021-12-31</settlementDate><retrievalReferenceNumber>612519002874</retrievalReferenceNumber><cardAcceptMethod>notSpecified</cardAcceptMethod><cardSuffix>1289</cardSuffix><acquirerInstitutionId>123456</acquirerInstitutionId><paymentToken>65226</paymentToken><totalAmount>123.45</totalAmount><localTransactionTime>15:07:40</localTransactionTime><authorizationResponseCode>00</authorizationResponseCode><transactionAmount>50100</transactionAmount><as2805Mti>0200</as2805Mti><productTypeCode>eftposProp</productTypeCode></disputedTransaction><disputeEvidence><comment1>Extension flow test comment </comment1><documents><name>psx2j.tif</name><content>#base64 encoded value#</content></documents></disputeEvidence><disputeDetails><disputeAmount>123.45</disputeAmount><disputeDate>2021-12-28</disputeDate><processingType>CNP</processingType><scheme>eftpos</scheme><parentCaseReferenceNumber>44743430EFP2</parentCaseReferenceNumber><issuerShortName>CBAI</issuerShortName><disputeTime>15:07:40</disputeTime><reasonCode>10301</reasonCode><AcquirerShortName>PAYA</AcquirerShortName><caseReferenceNumber>44443430EFP1</caseReferenceNumber><brand>eftpos</brand><initiatedBy>C</initiatedBy></disputeDetails><merchantInformation><cardAcceptorId>TBA</cardAcceptorId><merchantName>Netflix</merchantName></merchantInformation><originalTransaction><systemTraceAuditNumber>002874</systemTraceAuditNumber><paymentSequenceNumber>001</paymentSequenceNumber><channelTypeCode>inStore</channelTypeCode><bin>541333</bin><processingCode>016501</processingCode><cardholderAcceptMethod>notSpecified</cardholderAcceptMethod><cashbackAmount>123.45</cashbackAmount><localTransactionDate>2021-12-11</localTransactionDate><settlementDate>2021-12-31</settlementDate><retrievalReferenceNumber>612519002874</retrievalReferenceNumber><cardAcceptMethod>notSpecified</cardAcceptMethod><cardSuffix>1189</cardSuffix><acquirerInstitutionId>123456</acquirerInstitutionId><paymentToken>65226</paymentToken><totalAmount>123.45</totalAmount><localTransactionTime>15:07:40</localTransactionTime><authorizationResponseCode>00</authorizationResponseCode><transactionAmount>50100</transactionAmount><as2805Mti>0200</as2805Mti><productTypeCode>eftposProp</productTypeCode></originalTransaction>');



