//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38B81C5D01F8.cm preserve=no
//	$Date:   Jul 03 2012 16:08:22  $ $Author:   d08878  $
//	$Revision:   1.16  $
//## end module%38B81C5D01F8.cm

//## begin module%38B81C5D01F8.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%38B81C5D01F8.cp

//## Module: CXOSXI01%38B81C5D01F8; Package specification
//## Subsystem: XI%38B818930275
//## Source file: C:\Devel\Dn\Server\Application\XI\CXODXI01.hpp

#ifndef CXOSXI01_h
#define CXOSXI01_h 1

//## begin module%38B81C5D01F8.additionalIncludes preserve=no
//## end module%38B81C5D01F8.additionalIncludes

//## begin module%38B81C5D01F8.includes preserve=yes
// $Date:   Jul 03 2012 16:08:22  $ $Author:   d08878  $ $Revision:   1.16  $
#include <map>
//## end module%38B81C5D01F8.includes

#ifndef CXOSSI02_h
#include "CXODSI02.hpp"
#endif
#ifndef CXOSXI07_h
#include "CXODXI07.hpp"
#endif
#ifndef CXOSXI06_h
#include "CXODXI06.hpp"
#endif
#ifndef CXOSXI05_h
#include "CXODXI05.hpp"
#endif
#ifndef CXOSXI03_h
#include "CXODXI03.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class ExternalMessageSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class Hash;
class SwitchInterface;
} // namespace switchinterface

class ExternalMessage;
//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
class Log;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%38B81C5D01F8.declarations preserve=no
//## end module%38B81C5D01F8.declarations

//## begin module%38B81C5D01F8.additionalDeclarations preserve=yes
//## end module%38B81C5D01F8.additionalDeclarations


//## begin ExternalMessageProcessor%38B803230274.preface preserve=yes
//## end ExternalMessageProcessor%38B803230274.preface

//## Class: ExternalMessageProcessor%38B803230274
//	The ExternalMessageProcessor class encapsulates the
//	functions that process the generic format messages from
//	the Acquiring Platform and format them for adding them
//	to the DataNavigator data repository.
//## Category: Platform \: Generic::ExternalInterface_CAT%38B7FFAB0000
//## Subsystem: XI%38B818930275
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3936BC5A029B;repositorysegment::ExternalMessageSegment { -> F}
//## Uses: <unnamed>%3C4DE32D003E;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C7145FA0167;database::Database { -> F}
//## Uses: <unnamed>%3C7146110109;IF::CodeTable { -> F}
//## Uses: <unnamed>%3C71463802BF;switchinterface::Hash { -> F}
//## Uses: <unnamed>%3C71465D03D8;switchinterface::SwitchInterface { -> F}
//## Uses: <unnamed>%3C71467B01F4;ExternalMessage { -> F}
//## Uses: <unnamed>%3C714698037A;IF::Message { -> F}
//## Uses: <unnamed>%3C7146AB002E;IF::Log { -> F}

class ExternalMessageProcessor : public switchinterface::MessageProcessor  //## Inherits: <unnamed>%38B8037003D3
{
  //## begin ExternalMessageProcessor%38B803230274.initialDeclarations preserve=yes
  //## end ExternalMessageProcessor%38B803230274.initialDeclarations

  public:
    //## Constructors (generated)
      ExternalMessageProcessor();

    //## Destructor (generated)
      virtual ~ExternalMessageProcessor();


    //## Other Operations (specified)
      //## Operation: dispatch%38B90AAD0117
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>XI
      //	<h2>FI
      //	<!-- ExternalMessageProcessor::dispatch : Preconditions
      //	-->
      //	<h3>Generic Transaction Log File
      //	<p>
      //	The generic transaction log file is a variable length
      //	record dataset containing one transaction per logical
      //	record.
      //	Each logical record must contain one of the following
      //	transactions:
      //	<ul>
      //	<li>Financial transaction
      //	<li>File Maintenance message
      //	<li>Device Status message
      //	<li>Device Administrative message
      //	<li>Entity Cutoff message
      //	</ul>
      //	Each transaction contains multiple segments:
      //	</p>
      //	<table>
      //	<tr>
      //	<th>Transaction
      //	<th>Segment
      //	<th>C++ struct
      //	<th>Presence
      //	<tr>
      //	<td>Financial transaction
      //	<td>External Message Header
      //	<td>CXODRS47.hpp
      //	<td>Required
      //	<tr>
      //	<td>
      //	<td>Base Transaction
      //	<td>CXODRS18.hpp
      //	<td>Required
      //	<tr>
      //	<td>
      //	<td>Settlement Transaction
      //	<td>CXODRS19.hpp
      //	<td>Required
      //	<tr>
      //	<td>
      //	<td>Reversal Transaction
      //	<td>CXODRS20.hpp
      //	<td>Optional
      //	<tr>
      //	<td>
      //	<td>Adjustment Transaction
      //	<td>CXODRS22.hpp
      //	<td>Optional
      //	<tr>
      //	<td>
      //	<td>Adjustment Transaction Extension
      //	<td>CXODRS22.hpp
      //	<td>Optional
      //	<tr>
      //	<td>
      //	<td>Fee Transaction
      //	<td>CXODRS21.hpp
      //	<td>Optional
      //	<tr>
      //	<td>
      //	<td>User
      //	<td>CXODRS23.hpp
      //	<td>Optional
      //	<tr>
      //	<tr>
      //	<td>File Maintenance message
      //	<td>External Message Header
      //	<td>CXODRS47.hpp
      //	<td>Required
      //	<tr>
      //	<td>
      //	<td>File Maintenance
      //	<td>CXODRS24.hpp
      //	<td>Required
      //	<tr>
      //	<td>Device Status message
      //	<td>External Message Header
      //	<td>CXODRS47.hpp
      //	<td>Required
      //	<tr>
      //	<td>
      //	<td>Status
      //	<td>CXODRS25.hpp
      //	<td>Required
      //	<tr>
      //	<td>Device Administrative message
      //	<td>External Message Header
      //	<td>CXODRS47.hpp
      //	<td>Required
      //	<tr>
      //	<td>
      //	<td>Admin
      //	<td>CXODRS31.hpp
      //	<td>Required
      //	<tr>
      //	<td>Entity Cutoff message
      //	<td>External Message Header
      //	<td>CXODRS47.hpp
      //	<td>Required
      //	<tr>
      //	<td>
      //	<td>Cutoff
      //	<td>CXODRS26.hpp
      //	<td>Required
      //	</table>
      //	<p>
      //	PA-DSS:  this input file contains the PAN and expiration
      //	date (if specified) in the clear.
      //	<p>
      //	Each segment begins with a segment ID, a version
      //	identifier and a length representing the total length of
      //	the segment.
      //	The specific layouts are as follows:
      //	<p>
      //	<b>External Message Header</b>
      //	#include CXODRS47.hpp
      //	<p>
      //	<b>Base Transaction</b>
      //	#include CXODRS18.hpp
      //	<p>
      //	<b>Settlement Transaction</b>
      //	#include CXODRS19.hpp
      //	<p>
      //	<b>Reversal Transaction</b>
      //	#include CXODRS20.hpp
      //	<p>
      //	<b>Adjustment Transaction</b>
      //	#include CXODRS22.hpp
      //	<p>
      //	<b>Fee Transaction</b>
      //	#include CXODRS21.hpp
      //	<p>
      //	<b>User</b>
      //	#include CXODRS23.hpp
      //	<p>
      //	<b>File Maintenance</b>
      //	#include CXODRS24.hpp
      //	<p>
      //	<b>Status</b>
      //	#include CXODRS25.hpp
      //	<p>
      //	<b>Admin</b>
      //	#include CXODRS31.hpp
      //	<p>
      //	<b>Cutoff</b>
      //	#include CXODRS26.hpp
      //	<p>
      //	The following data elements from the financial
      //	transaction contain unique sub-elements depending on the
      //	acquirer or issuer network:
      //	<ul>
      //	<li>DATA_PRIV_ACQ
      //	<li>REF_DATA_ACQ
      //	<li>ADL_DATA_PRIV_ACQ
      //	<li>DATA_PRIV_ISS
      //	<li>REF_DATA_ISS
      //	<li>ADL_DATA_PRIV_ISS
      //	</ul>
      //	The supported network format indicators and layouts are
      //	as follows:
      //	<p>
      //	<b>Mastercard CIS</b>
      //	#include CXODRS63.hpp
      //	<p>
      //	<b>Mastercard MDS</b>
      //	#include CXODRS64.hpp
      //	<p>
      //	<b>Mastercard IPM</b>
      //	#include CXODRS65.hpp
      //	<p>
      //	<b>VISA Base II</b>
      //	#include CXODRS62.hpp
      //	<p>
      //	<b>VISA Plus</b>
      //	#include CXODRS67.hpp
      //	<p>
      //	<b>AFFN</b>
      //	#include CXODRS68.hpp
      //	<p>
      //	<b>Pulse</b>
      //	#include CXODRS75.hpp
      //	</p>
      //	</body>
      int dispatch ();

      //## Operation: initialization%38B90AAF0188
      int initialization ();

      //## Operation: reset%38B90AB30292
      //	Method sets the test date value.
      virtual int reset ();

    // Data Members for Associations

      //## Association: Platform \: Generic::ExternalInterface_CAT::<unnamed>%38BA909302C1
      //## Role: ExternalMessageProcessor::<m_hExternalStatusMessage>%38BA90940312
      //## begin ExternalMessageProcessor::<m_hExternalStatusMessage>%38BA90940312.role preserve=no  public: ExternalStatusMessage { -> VHgN}
      ExternalStatusMessage m_hExternalStatusMessage;
      //## end ExternalMessageProcessor::<m_hExternalStatusMessage>%38BA90940312.role

      //## Association: Platform \: Generic::ExternalInterface_CAT::<unnamed>%38C925CF0367
      //## Role: ExternalMessageProcessor::<m_hExternalFinancialMessage>%38C925D002DC
      //## begin ExternalMessageProcessor::<m_hExternalFinancialMessage>%38C925D002DC.role preserve=no  public: ExternalFinancialMessage { -> VHgN}
      ExternalFinancialMessage m_hExternalFinancialMessage;
      //## end ExternalMessageProcessor::<m_hExternalFinancialMessage>%38C925D002DC.role

      //## Association: Platform \: Generic::ExternalInterface_CAT::<unnamed>%41C1200603C4
      //## Role: ExternalMessageProcessor::<m_hExternalCutoffMessage>%41C1200803D1
      //## begin ExternalMessageProcessor::<m_hExternalCutoffMessage>%41C1200803D1.role preserve=no  public: ExternalCutoffMessage { -> VHgN}
      ExternalCutoffMessage m_hExternalCutoffMessage;
      //## end ExternalMessageProcessor::<m_hExternalCutoffMessage>%41C1200803D1.role

      //## Association: Platform \: Generic::ExternalInterface_CAT::<unnamed>%41C1202E0385
      //## Role: ExternalMessageProcessor::<m_hExternalDeviceAdminMessage>%41C1202F02C9
      //## begin ExternalMessageProcessor::<m_hExternalDeviceAdminMessage>%41C1202F02C9.role preserve=no  public: ExternalDeviceAdminMessage { -> VHgN}
      ExternalDeviceAdminMessage m_hExternalDeviceAdminMessage;
      //## end ExternalMessageProcessor::<m_hExternalDeviceAdminMessage>%41C1202F02C9.role

    // Additional Public Declarations
      //## begin ExternalMessageProcessor%38B803230274.public preserve=yes
      typedef map<string,ExternalMessage*,less<string> > MessageList;
      //## end ExternalMessageProcessor%38B803230274.public
  protected:
    // Additional Protected Declarations
      //## begin ExternalMessageProcessor%38B803230274.protected preserve=yes
      //## end ExternalMessageProcessor%38B803230274.protected

  private:
    // Additional Private Declarations
      //## begin ExternalMessageProcessor%38B803230274.private preserve=yes
      //## end ExternalMessageProcessor%38B803230274.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DropHashTotal%38B90C720385
      //## begin ExternalMessageProcessor::DropHashTotal%38B90C720385.attr preserve=no  private: double {U} 
      double m_dDropHashTotal;
      //## end ExternalMessageProcessor::DropHashTotal%38B90C720385.attr

      //## Attribute: Messages%38B90C76010A
      //## begin ExternalMessageProcessor::Messages%38B90C76010A.attr preserve=no  private: MessageList {U} 
      MessageList m_hMessages;
      //## end ExternalMessageProcessor::Messages%38B90C76010A.attr

      //## Attribute: TranSent%38B90C77033C
      //## begin ExternalMessageProcessor::TranSent%38B90C77033C.attr preserve=no  private: int {U} 
      int m_lTranSent;
      //## end ExternalMessageProcessor::TranSent%38B90C77033C.attr

    // Additional Implementation Declarations
      //## begin ExternalMessageProcessor%38B803230274.implementation preserve=yes
      //## end ExternalMessageProcessor%38B803230274.implementation

};

//## begin ExternalMessageProcessor%38B803230274.postscript preserve=yes
//## end ExternalMessageProcessor%38B803230274.postscript

//## begin module%38B81C5D01F8.epilog preserve=yes
//## end module%38B81C5D01F8.epilog


#endif
