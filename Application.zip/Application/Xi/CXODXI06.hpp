//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%41C10C2D01E7.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%41C10C2D01E7.cm

//## begin module%41C10C2D01E7.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%41C10C2D01E7.cp

//## Module: CXOSXI06%41C10C2D01E7; Package specification
//## Subsystem: XI%38B818930275
//## Source file: C:\Devel\Dn\Server\Application\XI\CXODXI06.hpp

#ifndef CXOSXI06_h
#define CXOSXI06_h 1

//## begin module%41C10C2D01E7.additionalIncludes preserve=no
//## end module%41C10C2D01E7.additionalIncludes

//## begin module%41C10C2D01E7.includes preserve=yes
//## end module%41C10C2D01E7.includes

#ifndef CXOSXI02_h
#include "CXODXI02.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class AuditSegment;
class ExternalMessageSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class SwitchInterface;
} // namespace switchinterface

namespace repositorysegment {
class DeviceAdminSegment;
} // namespace repositorysegment

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;

} // namespace monitor

//## begin module%41C10C2D01E7.declarations preserve=no
//## end module%41C10C2D01E7.declarations

//## begin module%41C10C2D01E7.additionalDeclarations preserve=yes
//## end module%41C10C2D01E7.additionalDeclarations


//## begin ExternalDeviceAdminMessage%41C10AB3036A.preface preserve=yes
//## end ExternalDeviceAdminMessage%41C10AB3036A.preface

//## Class: ExternalDeviceAdminMessage%41C10AB3036A
//## Category: Platform \: Generic::ExternalInterface_CAT%38B7FFAB0000
//## Subsystem: XI%38B818930275
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%41C10D260163;repositorysegment::AuditSegment { -> F}
//## Uses: <unnamed>%41C110F60329;repositorysegment::ExternalMessageSegment { -> F}
//## Uses: <unnamed>%41C1110D03D6;IF::Message { -> F}
//## Uses: <unnamed>%41C1113A03E5;monitor::UseCase { -> F}
//## Uses: <unnamed>%41C111FE0044;repositorysegment::DeviceAdminSegment { -> F}
//## Uses: <unnamed>%41C119F301C9;switchinterface::SwitchInterface { -> F}

class DllExport ExternalDeviceAdminMessage : public ExternalMessage  //## Inherits: <unnamed>%41C10AF00187
{
  //## begin ExternalDeviceAdminMessage%41C10AB3036A.initialDeclarations preserve=yes
  //## end ExternalDeviceAdminMessage%41C10AB3036A.initialDeclarations

  public:
    //## Constructors (generated)
      ExternalDeviceAdminMessage();

    //## Destructor (generated)
      virtual ~ExternalDeviceAdminMessage();


    //## Other Operations (specified)
      //## Operation: insert%41C1116E0281
      virtual bool insert ();

    // Additional Public Declarations
      //## begin ExternalDeviceAdminMessage%41C10AB3036A.public preserve=yes
      //## end ExternalDeviceAdminMessage%41C10AB3036A.public

  protected:
    // Additional Protected Declarations
      //## begin ExternalDeviceAdminMessage%41C10AB3036A.protected preserve=yes
      //## end ExternalDeviceAdminMessage%41C10AB3036A.protected

  private:
    // Additional Private Declarations
      //## begin ExternalDeviceAdminMessage%41C10AB3036A.private preserve=yes
      //## end ExternalDeviceAdminMessage%41C10AB3036A.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin ExternalDeviceAdminMessage%41C10AB3036A.implementation preserve=yes
      //## end ExternalDeviceAdminMessage%41C10AB3036A.implementation

};

//## begin ExternalDeviceAdminMessage%41C10AB3036A.postscript preserve=yes
//## end ExternalDeviceAdminMessage%41C10AB3036A.postscript

//## begin module%41C10C2D01E7.epilog preserve=yes
//## end module%41C10C2D01E7.epilog


#endif
