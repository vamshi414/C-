//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%38BA72780138.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%38BA72780138.cm

//## begin module%38BA72780138.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%38BA72780138.cp

//## Module: CXOSXI03%38BA72780138; Package body
//## Subsystem: XI%38B818930275
//## Source file: C:\Devel\Dn\Server\Application\XI\CXOSXI03.cpp

//## begin module%38BA72780138.additionalIncludes preserve=no
//## end module%38BA72780138.additionalIncludes

//## begin module%38BA72780138.includes preserve=yes
// $Date:   Jun 20 2017 15:54:50  $ $Author:   e1009839  $ $Revision:   1.21  $
//## end module%38BA72780138.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRS12_h
#include "CXODRS12.hpp"
#endif
#ifndef CXOSRS10_h
#include "CXODRS10.hpp"
#endif
#ifndef CXOSRS43_h
#include "CXODRS43.hpp"
#endif
#ifndef CXOSSI01_h
#include "CXODSI01.hpp"
#endif
#ifndef CXOSXI03_h
#include "CXODXI03.hpp"
#endif


//## begin module%38BA72780138.declarations preserve=no
//## end module%38BA72780138.declarations

//## begin module%38BA72780138.additionalDeclarations preserve=yes
//## end module%38BA72780138.additionalDeclarations


// Class ExternalStatusMessage 


ExternalStatusMessage::ExternalStatusMessage()
  //## begin ExternalStatusMessage::ExternalStatusMessage%38BA6E31018E_const.hasinit preserve=no
  //## end ExternalStatusMessage::ExternalStatusMessage%38BA6E31018E_const.hasinit
  //## begin ExternalStatusMessage::ExternalStatusMessage%38BA6E31018E_const.initialization preserve=yes
  //## end ExternalStatusMessage::ExternalStatusMessage%38BA6E31018E_const.initialization
{
  //## begin ExternalStatusMessage::ExternalStatusMessage%38BA6E31018E_const.body preserve=yes
   memcpy(m_sID,"XI03",4);
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("S054",ExternalMessageSegment::instance()));
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("S907",EntityStatusSegment::instance()));
  //## end ExternalStatusMessage::ExternalStatusMessage%38BA6E31018E_const.body
}


ExternalStatusMessage::~ExternalStatusMessage()
{
  //## begin ExternalStatusMessage::~ExternalStatusMessage%38BA6E31018E_dest.body preserve=yes
  //## end ExternalStatusMessage::~ExternalStatusMessage%38BA6E31018E_dest.body
}



//## Other Operations (implementation)
bool ExternalStatusMessage::insert ()
{
  //## begin ExternalStatusMessage::insert%38BA8F0C00F2.body preserve=yes
   UseCase hUseCase("EXTERNAL","## EX07 READ STATUS");
   if (!ExternalMessage::insert())
   {
      setReason("IMPORT FAILURE");
      UseCase::setSuccess(false);
      return false;
   }
   EntityStatusSegment::instance()->shift();
   Message::instance(Message::INBOUND)->reset("AI LE ","S0002D");
   char* psBuffer = Message::instance(Message::INBOUND)->data();
   m_pAuditSegment->setHashValue(getHashValue());
   m_pAuditSegment->setSourceID(Application::instance()->name().c_str());
   m_pAuditSegment->write(&psBuffer);
#ifdef DEVL
   if (getTestDate().length() > 0)
   {
      char szTemp[16];
      memcpy(szTemp,getTestDate().data(),8);
      memcpy(szTemp + 8,EntityStatusSegment::instance()->zTSTAMP_TRANS() + 8,8);
      EntityStatusSegment::instance()->setTSTAMP_TRANS(szTemp,16);
   }
#endif
   EntityStatusSegment::instance()->setUNIQUENESS_KEY(getUNIQUENESS_KEY());
   EntityStatusSegment::instance()->write(&psBuffer);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - Message::instance(Message::INBOUND)->data());
   return true;
  //## end ExternalStatusMessage::insert%38BA8F0C00F2.body
}

// Additional Declarations
  //## begin ExternalStatusMessage%38BA6E31018E.declarations preserve=yes
  //## end ExternalStatusMessage%38BA6E31018E.declarations

//## begin module%38BA72780138.epilog preserve=yes
//## end module%38BA72780138.epilog
