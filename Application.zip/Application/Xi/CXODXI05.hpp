//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38C515250197.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%38C515250197.cm

//## begin module%38C515250197.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%38C515250197.cp

//## Module: CXOSXI05%38C515250197; Package specification
//## Subsystem: XI%38B818930275
//## Source file: C:\Devel\Dn\Server\Application\XI\CXODXI05.hpp

#ifndef CXOSXI05_h
#define CXOSXI05_h 1

//## begin module%38C515250197.additionalIncludes preserve=no
//## end module%38C515250197.additionalIncludes

//## begin module%38C515250197.includes preserve=yes
// $Date:   May 24 2005 14:25:14  $ $Author:   D02405  $ $Revision:   1.15  $
//## end module%38C515250197.includes

#ifndef CXOSXI02_h
#include "CXODXI02.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialBaseSegment;
class FinancialAdjustmentSegment;
class FinancialUserSegment;
class AuditSegment;
class ExternalMessageSegment;
class FinancialAdjustmentExtensionSegment;
class FinancialSettlementSegment;
class FinancialReversalSegment;
class FinancialFeeSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;

} // namespace monitor

//## begin module%38C515250197.declarations preserve=no
//## end module%38C515250197.declarations

//## begin module%38C515250197.additionalDeclarations preserve=yes
//## end module%38C515250197.additionalDeclarations


//## begin ExternalFinancialMessage%38C51976005F.preface preserve=yes
//## end ExternalFinancialMessage%38C51976005F.preface

//## Class: ExternalFinancialMessage%38C51976005F
//	The Financial Message class encapsulates the functions
//	that process a financial record from an Acquiring
//	Platform for preparation for adding it to the Data
//	Navigator data repository.
//## Category: Platform \: Generic::ExternalInterface_CAT%38B7FFAB0000
//## Subsystem: XI%38B818930275
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%38CD034B0207;repositorysegment::AuditSegment { -> F}
//## Uses: <unnamed>%3936C075022E;repositorysegment::ExternalMessageSegment { -> F}
//## Uses: <unnamed>%393A5F3D02A4;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3BA7A32D0138;repositorysegment::FinancialFeeSegment { -> F}
//## Uses: <unnamed>%3BB322B303B9;repositorysegment::FinancialReversalSegment { -> F}
//## Uses: <unnamed>%3BB322C70399;repositorysegment::FinancialUserSegment { -> F}
//## Uses: <unnamed>%3C4DCE8B03A9;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C594F05000F;repositorysegment::FinancialAdjustmentSegment { -> F}
//## Uses: <unnamed>%3C594F08007D;repositorysegment::FinancialAdjustmentExtensionSegment { -> F}

class ExternalFinancialMessage : public ExternalMessage  //## Inherits: <unnamed>%38C51A13021E
{
  //## begin ExternalFinancialMessage%38C51976005F.initialDeclarations preserve=yes
  //## end ExternalFinancialMessage%38C51976005F.initialDeclarations

  public:
    //## Constructors (generated)
      ExternalFinancialMessage();

    //## Destructor (generated)
      virtual ~ExternalFinancialMessage();


    //## Other Operations (specified)
      //## Operation: insert%38C51AF202FB
      virtual bool insert ();

    // Additional Public Declarations
      //## begin ExternalFinancialMessage%38C51976005F.public preserve=yes
      //## end ExternalFinancialMessage%38C51976005F.public

  protected:
    // Additional Protected Declarations
      //## begin ExternalFinancialMessage%38C51976005F.protected preserve=yes
      //## end ExternalFinancialMessage%38C51976005F.protected

  private:
    // Additional Private Declarations
      //## begin ExternalFinancialMessage%38C51976005F.private preserve=yes
      //## end ExternalFinancialMessage%38C51976005F.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: Generic::ExternalInterface_CAT::<unnamed>%3C4DB3AC03D8
      //## Role: ExternalFinancialMessage::<m_pFinancialBaseSegment>%3C4DB3AD0290
      //## begin ExternalFinancialMessage::<m_pFinancialBaseSegment>%3C4DB3AD0290.role preserve=no  public: repositorysegment::FinancialBaseSegment { -> RFHgN}
      repositorysegment::FinancialBaseSegment *m_pFinancialBaseSegment;
      //## end ExternalFinancialMessage::<m_pFinancialBaseSegment>%3C4DB3AD0290.role

      //## Association: Platform \: Generic::ExternalInterface_CAT::<unnamed>%3C4DB3CD0203
      //## Role: ExternalFinancialMessage::<m_pFinancialSettlementSegment>%3C4DB3CE0167
      //## begin ExternalFinancialMessage::<m_pFinancialSettlementSegment>%3C4DB3CE0167.role preserve=no  public: repositorysegment::FinancialSettlementSegment { -> RFHgN}
      repositorysegment::FinancialSettlementSegment *m_pFinancialSettlementSegment;
      //## end ExternalFinancialMessage::<m_pFinancialSettlementSegment>%3C4DB3CE0167.role

    // Additional Implementation Declarations
      //## begin ExternalFinancialMessage%38C51976005F.implementation preserve=yes
      //## end ExternalFinancialMessage%38C51976005F.implementation

};

//## begin ExternalFinancialMessage%38C51976005F.postscript preserve=yes
//## end ExternalFinancialMessage%38C51976005F.postscript

//## begin module%38C515250197.epilog preserve=yes
//## end module%38C515250197.epilog


#endif
