//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%38BA72750206.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%38BA72750206.cm

//## begin module%38BA72750206.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%38BA72750206.cp

//## Module: CXOSXI03%38BA72750206; Package specification
//## Subsystem: XI%38B818930275
//## Source file: C:\Devel\Dn\Server\Application\XI\CXODXI03.hpp

#ifndef CXOSXI03_h
#define CXOSXI03_h 1

//## begin module%38BA72750206.additionalIncludes preserve=no
//## end module%38BA72750206.additionalIncludes

//## begin module%38BA72750206.includes preserve=yes
// $Date:   Apr 08 2004 20:34:04  $ $Author:   D98833  $ $Revision:   1.11  $
//## end module%38BA72750206.includes

#ifndef CXOSXI02_h
#include "CXODXI02.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class EntityStatusSegment;
class AuditSegment;
class ExternalMessageSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class SwitchInterface;
} // namespace switchinterface

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;

} // namespace monitor

//## begin module%38BA72750206.declarations preserve=no
//## end module%38BA72750206.declarations

//## begin module%38BA72750206.additionalDeclarations preserve=yes
//## end module%38BA72750206.additionalDeclarations


//## begin ExternalStatusMessage%38BA6E31018E.preface preserve=yes
//## end ExternalStatusMessage%38BA6E31018E.preface

//## Class: ExternalStatusMessage%38BA6E31018E
//	The StatusMessage class encapsulates the functions that
//	process a status record from an Acquiring Platform for
//	preparation for adding it to the DataNavigator data
//	repository.
//## Category: Platform \: Generic::ExternalInterface_CAT%38B7FFAB0000
//## Subsystem: XI%38B818930275
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%38CE5A4800D8;repositorysegment::AuditSegment { -> F}
//## Uses: <unnamed>%39895CCB00CA;repositorysegment::ExternalMessageSegment { -> F}
//## Uses: <unnamed>%3C4DB208038A;IF::Message { -> F}
//## Uses: <unnamed>%3C4DB2150232;switchinterface::SwitchInterface { -> F}
//## Uses: <unnamed>%3C4DCE6E0000;monitor::UseCase { -> F}
//## Uses: <unnamed>%3D64D98901E4;repositorysegment::EntityStatusSegment { -> F}

class ExternalStatusMessage : public ExternalMessage  //## Inherits: <unnamed>%38BA717C01AE
{
  //## begin ExternalStatusMessage%38BA6E31018E.initialDeclarations preserve=yes
  //## end ExternalStatusMessage%38BA6E31018E.initialDeclarations

  public:
    //## Constructors (generated)
      ExternalStatusMessage();

    //## Destructor (generated)
      virtual ~ExternalStatusMessage();


    //## Other Operations (specified)
      //## Operation: insert%38BA8F0C00F2
      virtual bool insert ();

    // Additional Public Declarations
      //## begin ExternalStatusMessage%38BA6E31018E.public preserve=yes
      //## end ExternalStatusMessage%38BA6E31018E.public

  protected:
    // Additional Protected Declarations
      //## begin ExternalStatusMessage%38BA6E31018E.protected preserve=yes
      //## end ExternalStatusMessage%38BA6E31018E.protected

  private:
    // Additional Private Declarations
      //## begin ExternalStatusMessage%38BA6E31018E.private preserve=yes
      //## end ExternalStatusMessage%38BA6E31018E.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin ExternalStatusMessage%38BA6E31018E.implementation preserve=yes
      //## end ExternalStatusMessage%38BA6E31018E.implementation

};

//## begin ExternalStatusMessage%38BA6E31018E.postscript preserve=yes
//## end ExternalStatusMessage%38BA6E31018E.postscript

//## begin module%38BA72750206.epilog preserve=yes
//## end module%38BA72750206.epilog


#endif
