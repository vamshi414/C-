//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%41C11C3D0212.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%41C11C3D0212.cm

//## begin module%41C11C3D0212.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%41C11C3D0212.cp

//## Module: CXOSXI07%41C11C3D0212; Package specification
//## Subsystem: XI%38B818930275
//## Source file: C:\Devel\Dn\Server\Application\XI\CXODXI07.hpp

#ifndef CXOSXI07_h
#define CXOSXI07_h 1

//## begin module%41C11C3D0212.additionalIncludes preserve=no
//## end module%41C11C3D0212.additionalIncludes

//## begin module%41C11C3D0212.includes preserve=yes
//## end module%41C11C3D0212.includes

#ifndef CXOSXI02_h
#include "CXODXI02.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class AuditSegment;
class CutoffSegment;
class ExternalMessageSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class SwitchInterface;
} // namespace switchinterface

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;

} // namespace monitor

//## begin module%41C11C3D0212.declarations preserve=no
//## end module%41C11C3D0212.declarations

//## begin module%41C11C3D0212.additionalDeclarations preserve=yes
//## end module%41C11C3D0212.additionalDeclarations


//## begin ExternalCutoffMessage%41C11B7303CA.preface preserve=yes
//## end ExternalCutoffMessage%41C11B7303CA.preface

//## Class: ExternalCutoffMessage%41C11B7303CA
//## Category: Platform \: Generic::ExternalInterface_CAT%38B7FFAB0000
//## Subsystem: XI%38B818930275
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%41C11C0C0013;repositorysegment::AuditSegment { -> F}
//## Uses: <unnamed>%41C11C0E0098;repositorysegment::ExternalMessageSegment { -> F}
//## Uses: <unnamed>%41C11C11002E;repositorysegment::CutoffSegment { -> F}
//## Uses: <unnamed>%41C11C130244;IF::Message { -> F}
//## Uses: <unnamed>%41C11C180088;monitor::UseCase { -> F}
//## Uses: <unnamed>%41C11C1A02F8;switchinterface::SwitchInterface { -> F}

class DllExport ExternalCutoffMessage : public ExternalMessage  //## Inherits: <unnamed>%41C11B9500B2
{
  //## begin ExternalCutoffMessage%41C11B7303CA.initialDeclarations preserve=yes
  //## end ExternalCutoffMessage%41C11B7303CA.initialDeclarations

  public:
    //## Constructors (generated)
      ExternalCutoffMessage();

    //## Destructor (generated)
      virtual ~ExternalCutoffMessage();


    //## Other Operations (specified)
      //## Operation: insert%41C11BA10394
      virtual bool insert ();

    // Additional Public Declarations
      //## begin ExternalCutoffMessage%41C11B7303CA.public preserve=yes
      //## end ExternalCutoffMessage%41C11B7303CA.public

  protected:
    // Additional Protected Declarations
      //## begin ExternalCutoffMessage%41C11B7303CA.protected preserve=yes
      //## end ExternalCutoffMessage%41C11B7303CA.protected

  private:
    // Additional Private Declarations
      //## begin ExternalCutoffMessage%41C11B7303CA.private preserve=yes
      //## end ExternalCutoffMessage%41C11B7303CA.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin ExternalCutoffMessage%41C11B7303CA.implementation preserve=yes
      //## end ExternalCutoffMessage%41C11B7303CA.implementation

};

//## begin ExternalCutoffMessage%41C11B7303CA.postscript preserve=yes
//## end ExternalCutoffMessage%41C11B7303CA.postscript

//## begin module%41C11C3D0212.epilog preserve=yes
//## end module%41C11C3D0212.epilog


#endif
