//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38C51529011A.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%38C51529011A.cm

//## begin module%38C51529011A.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%38C51529011A.cp

//## Module: CXOSXI05%38C51529011A; Package body
//## Subsystem: XI%38B818930275
//## Source file: C:\Devel\Dn\Server\Application\XI\CXOSXI05.cpp

//## begin module%38C51529011A.additionalIncludes preserve=no
//## end module%38C51529011A.additionalIncludes

//## begin module%38C51529011A.includes preserve=yes
// $Date:   Jun 20 2017 15:54:54  $ $Author:   e1009839  $ $Revision:   1.40  $
#include "CXODXI01.hpp"
#include "CXODIF11.hpp"
#include "CXODSI01.hpp"
#include "CXODRS18.hpp"
#include "CXODRS19.hpp"
//## end module%38C51529011A.includes

#ifndef CXOSRS10_h
#include "CXODRS10.hpp"
#endif
#ifndef CXOSRS12_h
#include "CXODRS12.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSRS38_h
#include "CXODRS38.hpp"
#endif
#ifndef CXOSRS37_h
#include "CXODRS37.hpp"
#endif
#ifndef CXOSRS40_h
#include "CXODRS40.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRS39_h
#include "CXODRS39.hpp"
#endif
#ifndef CXOSRS41_h
#include "CXODRS41.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSRS36_h
#include "CXODRS36.hpp"
#endif
#ifndef CXOSXI05_h
#include "CXODXI05.hpp"
#endif


//## begin module%38C51529011A.declarations preserve=no
//## end module%38C51529011A.declarations

//## begin module%38C51529011A.additionalDeclarations preserve=yes
#include "CXODRU37.hpp"
//## end module%38C51529011A.additionalDeclarations


// Class ExternalFinancialMessage

ExternalFinancialMessage::ExternalFinancialMessage()
//## begin ExternalFinancialMessage::ExternalFinancialMessage%38C51976005F_const.hasinit preserve=no
: m_pFinancialBaseSegment(0),
m_pFinancialSettlementSegment(0)
//## end ExternalFinancialMessage::ExternalFinancialMessage%38C51976005F_const.hasinit
//## begin ExternalFinancialMessage::ExternalFinancialMessage%38C51976005F_const.initialization preserve=yes
//## end ExternalFinancialMessage::ExternalFinancialMessage%38C51976005F_const.initialization
{
   //## begin ExternalFinancialMessage::ExternalFinancialMessage%38C51976005F_const.body preserve=yes
   memcpy(m_sID,"XI05",4);
   m_pFinancialBaseSegment = FinancialBaseSegment::instance();
   m_pFinancialSettlementSegment = FinancialSettlementSegment::instance();
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("S054",ExternalMessageSegment::instance()));
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("S200",FinancialBaseSegment::instance()));
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("S201",FinancialSettlementSegment::instance()));
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("S202",FinancialReversalSegment::instance()));
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("S203",FinancialAdjustmentSegment::instance()));
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("S204",FinancialAdjustmentExtensionSegment::instance()));
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("S205",FinancialFeeSegment::instance()));
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("S206",FinancialUserSegment::instance()));
   //## end ExternalFinancialMessage::ExternalFinancialMessage%38C51976005F_const.body
}


ExternalFinancialMessage::~ExternalFinancialMessage()
{
   //## begin ExternalFinancialMessage::~ExternalFinancialMessage%38C51976005F_dest.body preserve=yes
   //## end ExternalFinancialMessage::~ExternalFinancialMessage%38C51976005F_dest.body
}



//## Other Operations (implementation)
bool ExternalFinancialMessage::insert ()
{
   //## begin ExternalFinancialMessage::insert%38C51AF202FB.body preserve=yes
   UseCase hUseCase("EXTERNAL","## EX06 READ FINANCIAL");
   if (!ExternalMessage::insert())
   {
      setReason("IMPORT FAILURE");
      return UseCase::setSuccess(false);
   }
   if (m_pFinancialBaseSegment->presence() == false
      || m_pFinancialSettlementSegment->presence() == false)
   {
      setReason("MISSING SEGMENT");
      return UseCase::setSuccess(false);
   }
   FinancialBaseSegment::instance()->shift();
   FinancialSettlementSegment::instance()->shift();
   FinancialReversalSegment::instance()->shift();
   FinancialAdjustmentSegment::instance()->shift();
   FinancialAdjustmentExtensionSegment::instance()->shift();
   FinancialFeeSegment::instance()->shift();
   FinancialUserSegment::instance()->shift();
   string strOutData;
   if (ConfigurationRepository::instance()->translate("DEVICE",(string)m_pFinancialBaseSegment->zNET_TERM_ID(),strOutData,"FIN_LOCATOR","INST_ID_RECN_ACQ_B",0))
   {
      if (strOutData.length()>0)
      {
         string strTemp(strOutData.substr(11));
         if (strlen(m_pFinancialBaseSegment->zRPT_LVL_ID_B()) ==0)
            m_pFinancialBaseSegment->setRPT_LVL_ID_B(strTemp.data(),strTemp.length());
         if (strlen(m_pFinancialBaseSegment->zINST_ID_RECN_ACQ_B()) == 0 )
            m_pFinancialBaseSegment->setINST_ID_RECN_ACQ_B(strOutData.data(),11);
         if (strlen(m_pFinancialBaseSegment->zINST_ID_ACQ())==0)
            m_pFinancialBaseSegment->setINST_ID_ACQ(strOutData.data(),11);
      }
   }
   else
      ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   if (strlen(m_pFinancialBaseSegment->zPROC_ID_ACQ_B())==0)
      if (ConfigurationRepository::instance()->translate("INSTITUTION",m_pFinancialBaseSegment->zINST_ID_RECN_ACQ_B(),strOutData,"FIN_LOCATOR","PROC_ID_ACQ_B",0))
         m_pFinancialBaseSegment->setPROC_ID_ACQ_B(strOutData.data(),8);
      else
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   if (strlen(m_pFinancialBaseSegment->zPROC_ID_ISS_B())==0)
      if (ConfigurationRepository::instance()->translate("INSTITUTION",m_pFinancialBaseSegment->zINST_ID_RECON_ISS(),strOutData,"FIN_LOCATOR","PROC_ID_ISS_B",0))
         m_pFinancialBaseSegment->setPROC_ID_ISS_B(strOutData.data(),8);
      else
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ISS_DATA);
   // !!!!!!!! if (memcmp(m_pFinancialBaseSegment->zFIN_TYPE(),"900",3) != 0)
   // !!!!!!!!   validation();
   /*
   string strSearchData, strOutData;
   ConfigurationRepository::instance()->verify("FIN_TRAN_TYPE",m_pFinancialBaseSegment->zFIN_TYPE(),0);
   ConfigurationRepository::instance()->verify("CARD_TYPE",m_pFinancialSettlementSegment->zCARD_TYPE(),0);
   ConfigurationRepository::instance()->verify("CARD_OWNER_TYPE",m_pFinancialSettlementSegment->zCARD_OWNER(),0);
   ConfigurationRepository::instance()->verify("TRAN_TYPE_IND",m_pFinancialBaseSegment->zTRAN_TYPE_ID(),0);
   //*** rechain Acquirer data **********************************
   if (ConfigurationRepository::instance()->translate("DEVICE",m_pFinancialBaseSegment->zNET_TERM_ID(),strOutData,"FIN_LOCATOR","INST_ID_RECN_ACQ_B",-1,false) == false)
   ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   else
   {
   string szTemp(strOutData.substr(11));
   if (szTemp.length() > 0)
   m_pFinancialBaseSegment->setRPT_LVL_ID_B(szTemp.data(),szTemp.length());
   m_pFinancialBaseSegment->setINST_ID_RECN_ACQ_B(strOutData.data(),11);
   }
   string strInstRecnAcqB;
   if (ConfigurationRepository::instance()->mapItem("X_INST_ID_RECON",(string)m_pFinancialBaseSegment->zINST_ID_RECON_ACQ(),(string)m_pFinancialBaseSegment->zINST_ID_ACQ(),"A",strInstRecnAcqB))
   m_pFinancialBaseSegment->setINST_ID_RECN_ACQ_B(strInstRecnAcqB.data(),strInstRecnAcqB.length());
   string strInstRecnIssB;
   if (ConfigurationRepository::instance()->mapItem("X_INST_ID_RECON",(string)m_pFinancialBaseSegment->zINST_ID_RECON_ISS(),(string)m_pFinancialBaseSegment->zINST_ID_ISS(),"I",strInstRecnIssB))
   m_pFinancialBaseSegment->setINST_ID_RECN_ISS_B(strInstRecnIssB.data(),strInstRecnIssB.length());
   else
   m_pFinancialBaseSegment->setINST_ID_RECN_ISS_B(m_pFinancialBaseSegment->zINST_ID_RECON_ISS(),11);
   //if (!m_bTranslateError)
   {
   strSearchData.assign(strOutData.data(),11);
   if (ConfigurationRepository::instance()->translate("INSTITUTION",strSearchData,strOutData,"FIN_LOCATOR","PROC_ID_ACQ_B",-1,false))
   m_pFinancialBaseSegment->setPROC_ID_ACQ_B(strOutData.data(),8);
   }
   //if (!m_bTranslateError)
   {
   strSearchData = strOutData;
   if (ConfigurationRepository::instance()->translate("PROCESSOR",strSearchData,strOutData,"FIN_LOCATOR","PROC_GRP_ID_ACQ_B",-1,false))
   m_pFinancialBaseSegment->setPROC_GRP_ID_ACQ_B(strOutData.data(),8);
   }
   //*************************************************************
   //*** rechain Issuer data **********************************
   if (ConfigurationRepository::instance()->translate("INSTITUTION",m_pFinancialBaseSegment->zINST_ID_RECON_ISS(),strOutData,"FIN_LOCATOR","PROC_ID_ISS_B",-1,false))
   m_pFinancialBaseSegment->setPROC_ID_ISS_B(strOutData.data(),8);
   //if (!m_bTranslateError)
   {
   strSearchData = strOutData;
   if (ConfigurationRepository::instance()->translate("PROCESSOR",strSearchData,strOutData,"FIN_LOCATOR","PROC_GRP_ID_ISS_B",-1,false) == false)
   {
   //strcpy(m_sUnknownTranslateValue,"PR ");
   //strcat(m_sUnknownTranslateValue,strSearchData.c_str());
   //m_bTranslateError=true;
   }
   else
   m_pFinancialBaseSegment->setPROC_GRP_ID_ISS_B(strOutData.data(),8);
   }
   //*** OPTIONAL Validation**************************************
   if (((SwitchInterface*)Application::instance())->EditAll())
   {
   if (ConfigurationRepository::instance()->translate("INSTITUTION",m_pFinancialBaseSegment->zINST_ID_RECON_ACQ(),strOutData,"FIN_LOCATOR","INST_ID_RECON_ACQ",0) == false)
   {
   //strcpy(m_sUnknownEntityValue,"IN ");
   //strcat(m_sUnknownEntityValue,strSearchData.c_str());
   //m_bEntityError=true;
   }
   if (ConfigurationRepository::instance()->translate("PROCESSOR",m_pFinancialBaseSegment->zPROC_ID_ACQ(),strOutData,"FIN_RECORD","PROC_ID_ACQ",0) == false)
   {
   //strcpy(m_sUnknownEntityValue,"PR ");
   //strcat(m_sUnknownEntityValue,strSearchData.c_str());
   //m_bEntityError=true;
   }
   if (ConfigurationRepository::instance()->translate("PROCESSOR",m_pFinancialBaseSegment->zPROC_ID_ISS(),strOutData,"FIN_RECORD","PROC_ID_ISS",0) == false)
   {
   //strcpy(m_sUnknownEntityValue,"PR ");
   //strcat(m_sUnknownEntityValue,strSearchData.c_str());
   //m_bEntityError=true;
   }
   }
   */
   Message::instance(Message::INBOUND)->reset("AI LE ","S0002D");
   char* psBuffer = Message::instance(Message::INBOUND)->data();
   m_pAuditSegment->setHashValue(getHashValue());
   m_pAuditSegment->setSourceID(Application::instance()->name().c_str());
   m_pAuditSegment->write(&psBuffer);
#ifdef DEVL
   if (getTestDate().length() > 0)
   {
      char szTemp[16];
      memcpy(szTemp,getTestDate().data(),8);
      memcpy(szTemp + 8,m_pFinancialBaseSegment->zTSTAMP_TRANS() + 8,8);
      m_pFinancialBaseSegment->setTSTAMP_TRANS(szTemp,16);
   }
#endif
   m_pFinancialBaseSegment->setUNIQUENESS_KEY(getUNIQUENESS_KEY());
   ExternalMessageSegment::instance()->setPresence(false);
   map<string,Segment*,less<string> >::iterator pSegment;
   for (pSegment = m_hSegments.begin();pSegment != m_hSegments.end();++pSegment)
      if ((*pSegment).second->presence())
         (*pSegment).second->write(&psBuffer);
   ConfigurationRepository::instance()->write(&psBuffer,m_pFinancialBaseSegment->zTSTAMP_TRANS(),m_pFinancialBaseSegment->getUNIQUENESS_KEY());
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - Message::instance(Message::INBOUND)->data());
   return true;
   //## end ExternalFinancialMessage::insert%38C51AF202FB.body
}

// Additional Declarations
//## begin ExternalFinancialMessage%38C51976005F.declarations preserve=yes
//## end ExternalFinancialMessage%38C51976005F.declarations

//## begin module%38C51529011A.epilog preserve=yes
//## end module%38C51529011A.epilog
