//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38B81EBA0194.cm preserve=no
//	$Date:   Jun 20 2017 15:54:48  $ $Author:   e1009839  $
//	$Revision:   1.24  $
//## end module%38B81EBA0194.cm

//## begin module%38B81EBA0194.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%38B81EBA0194.cp

//## Module: CXOSXI02%38B81EBA0194; Package body
//## Subsystem: XI%38B818930275
//## Source file: C:\Devel\Dn\Server\Application\XI\CXOSXI02.cpp

//## begin module%38B81EBA0194.additionalIncludes preserve=no
//## end module%38B81EBA0194.additionalIncludes

//## begin module%38B81EBA0194.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#include "CXODBS09.hpp"
#include "CXODIF03.hpp"
//## end module%38B81EBA0194.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSRS10_h
#include "CXODRS10.hpp"
#endif
#ifndef CXOSRS12_h
#include "CXODRS12.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSSI01_h
#include "CXODSI01.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSXI02_h
#include "CXODXI02.hpp"
#endif


//## begin module%38B81EBA0194.declarations preserve=no
//## end module%38B81EBA0194.declarations

//## begin module%38B81EBA0194.additionalDeclarations preserve=yes
//## end module%38B81EBA0194.additionalDeclarations


// Class ExternalMessage 

//## begin ExternalMessage::TestDate%38BA68D102DA.attr preserve=no  public: static string* {V} 0
string* ExternalMessage::m_pstrTestDate = 0;
//## end ExternalMessage::TestDate%38BA68D102DA.attr

ExternalMessage::ExternalMessage()
  //## begin ExternalMessage::ExternalMessage%38B815000279_const.hasinit preserve=no
      : m_pAuditSegment(0),
        m_lHashValue(0),
        m_iUNIQUENESS_KEY(0)
  //## end ExternalMessage::ExternalMessage%38B815000279_const.hasinit
  //## begin ExternalMessage::ExternalMessage%38B815000279_const.initialization preserve=yes
  //## end ExternalMessage::ExternalMessage%38B815000279_const.initialization
{
  //## begin ExternalMessage::ExternalMessage%38B815000279_const.body preserve=yes
   m_pAuditSegment = new AuditSegment();
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("S207",m_pAuditSegment));
  //## end ExternalMessage::ExternalMessage%38B815000279_const.body
}


ExternalMessage::~ExternalMessage()
{
  //## begin ExternalMessage::~ExternalMessage%38B815000279_dest.body preserve=yes
   m_hSegments.erase(m_hSegments.begin(),m_hSegments.end());
   delete m_pAuditSegment;
  //## end ExternalMessage::~ExternalMessage%38B815000279_dest.body
}



//## Other Operations (implementation)
string ExternalMessage::getTestDate ()
{
  //## begin ExternalMessage::getTestDate%43F8CD9B0157.body preserve=yes
   if (!m_pstrTestDate)
      m_pstrTestDate = new string;
   return *m_pstrTestDate;
  //## end ExternalMessage::getTestDate%43F8CD9B0157.body
}

bool ExternalMessage::insert ()
{
  //## begin ExternalMessage::insert%38BA67C200E5.body preserve=yes
   int iRC = 0;
   char* pSegmentID = Message::instance(Message::INBOUND)->data() + ExternalMessageSegment::instance()->size();
   char* pEndOfMessage = Message::instance(Message::INBOUND)->data() + Message::instance(Message::INBOUND)->dataLength();
   map<string,Segment*,less<string> >::iterator pSegment;
   for (pSegment = m_hSegments.begin();pSegment != m_hSegments.end();++pSegment)
      (*pSegment).second->reset();
   char pszSegmentID[5] = {"    "};
   while (((pSegmentID + 4) < pEndOfMessage) && (iRC == 0))
   {
      memcpy(pszSegmentID,pSegmentID,4);
      pSegment = m_hSegments.find(pszSegmentID);
      if (pSegment == m_hSegments.end())
         return false;
      else
      if ((*pSegment).second->presence() == false)
         iRC = (*pSegment).second->import(&pSegmentID);
   }
   if (iRC != 0)
   {
      Trace::put(InformationSegment::instance()->getText().c_str());
      return false;
   }
   if (++m_iUNIQUENESS_KEY > 1000)
      m_iUNIQUENESS_KEY = 1;
   return true;
  //## end ExternalMessage::insert%38BA67C200E5.body
}

void ExternalMessage::otherError ()
{
  //## begin ExternalMessage::otherError%398AB4B50227.body preserve=yes
   ;
  //## end ExternalMessage::otherError%398AB4B50227.body
}

void ExternalMessage::setTestDate (const string& strTestDate)
{
  //## begin ExternalMessage::setTestDate%43F8CDAB008C.body preserve=yes
   if (!m_pstrTestDate)
      m_pstrTestDate = new string;
   *m_pstrTestDate = strTestDate;
  //## end ExternalMessage::setTestDate%43F8CDAB008C.body
}

// Additional Declarations
  //## begin ExternalMessage%38B815000279.declarations preserve=yes
  //## end ExternalMessage%38B815000279.declarations

//## begin module%38B81EBA0194.epilog preserve=yes
//## end module%38B81EBA0194.epilog
