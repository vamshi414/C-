//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%41C11C3F0373.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%41C11C3F0373.cm

//## begin module%41C11C3F0373.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%41C11C3F0373.cp

//## Module: CXOSXI07%41C11C3F0373; Package body
//## Subsystem: XI%38B818930275
//## Source file: C:\Devel\Dn\Server\Application\XI\CXOSXI07.cpp

//## begin module%41C11C3F0373.additionalIncludes preserve=no
//## end module%41C11C3F0373.additionalIncludes

//## begin module%41C11C3F0373.includes preserve=yes
//## end module%41C11C3F0373.includes

#ifndef CXOSRS10_h
#include "CXODRS10.hpp"
#endif
#ifndef CXOSRS12_h
#include "CXODRS12.hpp"
#endif
#ifndef CXOSRS09_h
#include "CXODRS09.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSSI01_h
#include "CXODSI01.hpp"
#endif
#ifndef CXOSXI07_h
#include "CXODXI07.hpp"
#endif


//## begin module%41C11C3F0373.declarations preserve=no
//## end module%41C11C3F0373.declarations

//## begin module%41C11C3F0373.additionalDeclarations preserve=yes
//## end module%41C11C3F0373.additionalDeclarations


// Class ExternalCutoffMessage

ExternalCutoffMessage::ExternalCutoffMessage()
  //## begin ExternalCutoffMessage::ExternalCutoffMessage%41C11B7303CA_const.hasinit preserve=no
  //## end ExternalCutoffMessage::ExternalCutoffMessage%41C11B7303CA_const.hasinit
  //## begin ExternalCutoffMessage::ExternalCutoffMessage%41C11B7303CA_const.initialization preserve=yes
  //## end ExternalCutoffMessage::ExternalCutoffMessage%41C11B7303CA_const.initialization
{
  //## begin ExternalCutoffMessage::ExternalCutoffMessage%41C11B7303CA_const.body preserve=yes
   memcpy(m_sID,"XI07",4);
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("S054",ExternalMessageSegment::instance()));
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("C001",CutoffSegment::instance()));
  //## end ExternalCutoffMessage::ExternalCutoffMessage%41C11B7303CA_const.body
}


ExternalCutoffMessage::~ExternalCutoffMessage()
{
  //## begin ExternalCutoffMessage::~ExternalCutoffMessage%41C11B7303CA_dest.body preserve=yes
  //## end ExternalCutoffMessage::~ExternalCutoffMessage%41C11B7303CA_dest.body
}



//## Other Operations (implementation)
bool ExternalCutoffMessage::insert ()
{
  //## begin ExternalCutoffMessage::insert%41C11BA10394.body preserve=yes
   UseCase hUseCase("EXTERNAL","## EX10 READ CUTOFF");
   if (!ExternalMessage::insert())
   {
      setReason("IMPORT FAILURE");
      return false;
   }
   CutoffSegment::instance()->shift();
   Message::instance(Message::INBOUND)->reset("AI LE ","S0002D");
   char* psBuffer = Message::instance(Message::INBOUND)->data();
   m_pAuditSegment->setHashValue(getHashValue());
   m_pAuditSegment->setSourceID(Application::instance()->name().c_str());
   m_pAuditSegment->write(&psBuffer);
#ifdef DEVL
   if (getTestDate().length())
   {
      char szTemp[16];
      memcpy(szTemp,getTestDate().data(),8);
      CutoffSegment::instance()->setDATE_RECON(szTemp,8);
      memcpy(szTemp + 8,CutoffSegment::instance()->TSTAMP_END().data() + 8,8);
      CutoffSegment::instance()->setTSTAMP_END(szTemp,16);
   }
#endif
   CutoffSegment::instance()->write(&psBuffer);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - Message::instance(Message::INBOUND)->data());
   return true;
  //## end ExternalCutoffMessage::insert%41C11BA10394.body
}

// Additional Declarations
  //## begin ExternalCutoffMessage%41C11B7303CA.declarations preserve=yes
  //## end ExternalCutoffMessage%41C11B7303CA.declarations

//## begin module%41C11C3F0373.epilog preserve=yes
//## end module%41C11C3F0373.epilog
