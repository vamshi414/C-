//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38B81EB801FF.cm preserve=no
//	$Date:   Sep 06 2006 15:36:16  $ $Author:   D02405  $
//	$Revision:   1.19  $
//## end module%38B81EB801FF.cm

//## begin module%38B81EB801FF.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%38B81EB801FF.cp

//## Module: CXOSXI02%38B81EB801FF; Package specification
//## Subsystem: XI%38B818930275
//## Source file: C:\Devel\Dn\Server\Application\XI\CXODXI02.hpp

#ifndef CXOSXI02_h
#define CXOSXI02_h 1

//## begin module%38B81EB801FF.additionalIncludes preserve=no
//## end module%38B81EB801FF.additionalIncludes

//## begin module%38B81EB801FF.includes preserve=yes
// $Date:   Sep 06 2006 15:36:16  $ $Author:   D02405  $ $Revision:   1.19  $
#include <map>
#include "CXODRS10.hpp"
//## end module%38B81EB801FF.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class AuditSegment;
class ExternalMessageSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class SwitchInterface;
} // namespace switchinterface

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Log;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%38B81EB801FF.declarations preserve=no
//## end module%38B81EB801FF.declarations

//## begin module%38B81EB801FF.additionalDeclarations preserve=yes
//## end module%38B81EB801FF.additionalDeclarations


//## begin ExternalMessage%38B815000279.preface preserve=yes
//## end ExternalMessage%38B815000279.preface

//## Class: ExternalMessage%38B815000279
//	The ExternalMessage class encapsulates the functions for
//	parsing an incoming Generic Format AP message and
//	streaming the message segments to the Load Engines to
//	insert into the DB2 tables.
//## Category: Platform \: Generic::ExternalInterface_CAT%38B7FFAB0000
//## Subsystem: XI%38B818930275
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%38BD81C90121;IF::Message { -> F}
//## Uses: <unnamed>%38CE57E40114;repositorysegment::AuditSegment { -> F}
//## Uses: <unnamed>%3989636401F5;repositorysegment::ExternalMessageSegment { -> F}
//## Uses: <unnamed>%3C4DB67E029F;IF::Log { -> F}
//## Uses: <unnamed>%3C4DB6970177;switchinterface::SwitchInterface { -> F}
//## Uses: <unnamed>%3C4DB7B602CE;segment::Segment { -> F}

class ExternalMessage : public reusable::Object  //## Inherits: <unnamed>%38BAE2B40273
{
  //## begin ExternalMessage%38B815000279.initialDeclarations preserve=yes
  //## end ExternalMessage%38B815000279.initialDeclarations

  public:
    //## Constructors (generated)
      ExternalMessage();

    //## Destructor (generated)
      virtual ~ExternalMessage();


    //## Other Operations (specified)
      //## Operation: getTestDate%43F8CD9B0157
      static string getTestDate ();

      //## Operation: insert%38BA67C200E5
      virtual bool insert ();

      //## Operation: otherError%398AB4B50227
      void otherError ();

      //## Operation: setTestDate%43F8CDAB008C
      void setTestDate (const string& strTestDate);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: HashValue%38BA68CE039D
      const unsigned int& getHashValue () const
      {
        //## begin ExternalMessage::getHashValue%38BA68CE039D.get preserve=no
        return m_lHashValue;
        //## end ExternalMessage::getHashValue%38BA68CE039D.get
      }

      void setHashValue (const unsigned int& value)
      {
        //## begin ExternalMessage::setHashValue%38BA68CE039D.set preserve=no
        m_lHashValue = value;
        //## end ExternalMessage::setHashValue%38BA68CE039D.set
      }


      //## Attribute: UNIQUENESS_KEY%3C5042400242
      const short getUNIQUENESS_KEY () const
      {
        //## begin ExternalMessage::getUNIQUENESS_KEY%3C5042400242.get preserve=no
        return m_iUNIQUENESS_KEY;
        //## end ExternalMessage::getUNIQUENESS_KEY%3C5042400242.get
      }

      void setUNIQUENESS_KEY (short value)
      {
        //## begin ExternalMessage::setUNIQUENESS_KEY%3C5042400242.set preserve=no
        m_iUNIQUENESS_KEY = value;
        //## end ExternalMessage::setUNIQUENESS_KEY%3C5042400242.set
      }


    // Additional Public Declarations
      //## begin ExternalMessage%38B815000279.public preserve=yes
      //## end ExternalMessage%38B815000279.public

  protected:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Reason%38C4FCBA0030
      const string& getReason () const
      {
        //## begin ExternalMessage::getReason%38C4FCBA0030.get preserve=no
        return m_strReason;
        //## end ExternalMessage::getReason%38C4FCBA0030.get
      }

      void setReason (const string& value)
      {
        //## begin ExternalMessage::setReason%38C4FCBA0030.set preserve=no
        m_strReason = value;
        //## end ExternalMessage::setReason%38C4FCBA0030.set
      }


    // Data Members for Class Attributes

      //## Attribute: AuditSegment%38CE579E01E6
      //## begin ExternalMessage::AuditSegment%38CE579E01E6.attr preserve=no  public: repositorysegment::AuditSegment* {V} 0
      repositorysegment::AuditSegment* m_pAuditSegment;
      //## end ExternalMessage::AuditSegment%38CE579E01E6.attr

      //## Attribute: Segments%38CB940C0110
      //## begin ExternalMessage::Segments%38CB940C0110.attr preserve=no  protected: map<string, Segment*, less<string> > {VA} 
      map<string, Segment*, less<string> > m_hSegments;
      //## end ExternalMessage::Segments%38CB940C0110.attr

    // Additional Protected Declarations
      //## begin ExternalMessage%38B815000279.protected preserve=yes
      //## end ExternalMessage%38B815000279.protected

  private:
    // Additional Private Declarations
      //## begin ExternalMessage%38B815000279.private preserve=yes
      //## end ExternalMessage%38B815000279.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin ExternalMessage::HashValue%38BA68CE039D.attr preserve=no  public: unsigned int {V} 0
      unsigned int m_lHashValue;
      //## end ExternalMessage::HashValue%38BA68CE039D.attr

      //## begin ExternalMessage::Reason%38C4FCBA0030.attr preserve=no  protected: string {V} 
      string m_strReason;
      //## end ExternalMessage::Reason%38C4FCBA0030.attr

      //## Attribute: TestDate%38BA68D102DA
      //## begin ExternalMessage::TestDate%38BA68D102DA.attr preserve=no  public: static string* {V} 0
      static string* m_pstrTestDate;
      //## end ExternalMessage::TestDate%38BA68D102DA.attr

      //## begin ExternalMessage::UNIQUENESS_KEY%3C5042400242.attr preserve=no  public: short {V} 0
      short m_iUNIQUENESS_KEY;
      //## end ExternalMessage::UNIQUENESS_KEY%3C5042400242.attr

    // Additional Implementation Declarations
      //## begin ExternalMessage%38B815000279.implementation preserve=yes
      //## end ExternalMessage%38B815000279.implementation

};

//## begin ExternalMessage%38B815000279.postscript preserve=yes
//## end ExternalMessage%38B815000279.postscript

//## begin module%38B81EB801FF.epilog preserve=yes
//## end module%38B81EB801FF.epilog


#endif
