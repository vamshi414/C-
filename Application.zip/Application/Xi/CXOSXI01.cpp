//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38B81C6000D0.cm preserve=no
//	$Date:   Jun 20 2017 15:54:46  $ $Author:   e1009839  $
//	$Revision:   1.28  $
//## end module%38B81C6000D0.cm

//## begin module%38B81C6000D0.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%38B81C6000D0.cp

//## Module: CXOSXI01%38B81C6000D0; Package body
//## Subsystem: XI%38B818930275
//## Source file: C:\Devel\Dn\Server\Application\XI\CXOSXI01.cpp

//## begin module%38B81C6000D0.additionalIncludes preserve=no
//## end module%38B81C6000D0.additionalIncludes

//## begin module%38B81C6000D0.includes preserve=yes
// $Date:   Jun 20 2017 15:54:46  $ $Author:   e1009839  $ $Revision:   1.28  $
#include <stdio.h>
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#include "CXODRU24.hpp"
//## end module%38B81C6000D0.includes

#ifndef CXOSRS12_h
#include "CXODRS12.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSSI05_h
#include "CXODSI05.hpp"
#endif
#ifndef CXOSSI01_h
#include "CXODSI01.hpp"
#endif
#ifndef CXOSXI02_h
#include "CXODXI02.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSXI01_h
#include "CXODXI01.hpp"
#endif


//## begin module%38B81C6000D0.declarations preserve=no
//## end module%38B81C6000D0.declarations

//## begin module%38B81C6000D0.additionalDeclarations preserve=yes
//## end module%38B81C6000D0.additionalDeclarations


// Class ExternalMessageProcessor 

ExternalMessageProcessor::ExternalMessageProcessor()
  //## begin ExternalMessageProcessor::ExternalMessageProcessor%38B803230274_const.hasinit preserve=no
  //## end ExternalMessageProcessor::ExternalMessageProcessor%38B803230274_const.hasinit
  //## begin ExternalMessageProcessor::ExternalMessageProcessor%38B803230274_const.initialization preserve=yes
  //## end ExternalMessageProcessor::ExternalMessageProcessor%38B803230274_const.initialization
{
  //## begin ExternalMessageProcessor::ExternalMessageProcessor%38B803230274_const.body preserve=yes
   memcpy(m_sID,"XI01",4);
  //## end ExternalMessageProcessor::ExternalMessageProcessor%38B803230274_const.body
}


ExternalMessageProcessor::~ExternalMessageProcessor()
{
  //## begin ExternalMessageProcessor::~ExternalMessageProcessor%38B803230274_dest.body preserve=yes
  //## end ExternalMessageProcessor::~ExternalMessageProcessor%38B803230274_dest.body
}



//## Other Operations (implementation)
int ExternalMessageProcessor::dispatch ()
{
  //## begin ExternalMessageProcessor::dispatch%38B90AAD0117.body preserve=yes
   UseCase hUseCase("EXTERNAL","## EX05 PARSE MESSAGE");
   char* psBuffer = Message::instance(Message::INBOUND)->data();
#ifdef MVS
   if (*psBuffer != 'S')
      CodeTable::translate(psBuffer,Message::instance(Message::INBOUND)->messageLength(),CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   ExternalMessageSegment::instance()->import(&psBuffer);
   char szHash[9];
   szHash[8] = '\0';
   unsigned int lHashVal = 0;
   strncpy(szHash,ExternalMessageSegment::instance()->getAPHash().data(),8);
   sscanf(szHash,"%x",&lHashVal);
   string strTranType(psBuffer,4);
   MessageList::iterator p = m_hMessages.find(strTranType);
   if (p != m_hMessages.end())
   {
      ExternalMessage* pMessage = (*p).second;
      pMessage->setHashValue(lHashVal);
      if (pMessage->insert())
      {
         int lRC;
         string strQueueName;
         ((SwitchInterface*)Application::instance())->getLoadEngine((*p).first,strQueueName); // !!! need to check bool return value
         lRC = Message::instance(Message::INBOUND)->send(strQueueName.c_str());
         if (lRC)
         {
            ((SwitchInterface*)Application::instance())->dropLoadEngine(strQueueName);
            Hash::instance()->rejectBatch();
         }
         else
            Hash::instance()->incrementTranSentCnt();
      }
      else
      {
         pMessage->otherError();
         Hash::instance()->incrementDropTotal(lHashVal);
      }
   }
   else
   {
      Log::put(Message::instance(Message::INBOUND)->data(),Message::instance(Message::INBOUND)->dataLength(),"FINAN ","Unknown Message");
      Hash::instance()->incrementDropTotal(lHashVal);
      UseCase::setSuccess(false);
   }
   if (Database::instance()->transactionState() == Database::COMMITREQUIRED)
      Database::instance()->commit();
   else
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      Database::instance()->rollback();
   return 0;
  //## end ExternalMessageProcessor::dispatch%38B90AAD0117.body
}

int ExternalMessageProcessor::initialization ()
{
  //## begin ExternalMessageProcessor::initialization%38B90AAF0188.body preserve=yes
   m_hMessages.insert(m_hMessages.begin(),MessageList::value_type("S200",&m_hExternalFinancialMessage));
   m_hMessages.insert(m_hMessages.begin(),MessageList::value_type("S907",&m_hExternalStatusMessage));
   m_hMessages.insert(m_hMessages.begin(),MessageList::value_type("A001",&m_hExternalDeviceAdminMessage));
   m_hMessages.insert(m_hMessages.begin(),MessageList::value_type("C001",&m_hExternalCutoffMessage));
   return 0;
  //## end ExternalMessageProcessor::initialization%38B90AAF0188.body
}

int ExternalMessageProcessor::reset ()
{
  //## begin ExternalMessageProcessor::reset%38B90AB30292.body preserve=yes
   IString strContext = Message::instance(Message::INBOUND)->context();
   if (strstr(strContext,"TDATEOFF"))
      return(0);
   else
   if (strncmp(strContext.subString(1,9),"TESTDATE=",9) == 0)
   {
      char szTestDate[9];
      strncpy(szTestDate,strContext.subString(10,8),8);
      szTestDate[8] = '\0';
      m_hExternalStatusMessage.setTestDate(szTestDate);
      m_hExternalFinancialMessage.setTestDate(szTestDate);
      m_hExternalDeviceAdminMessage.setTestDate(szTestDate);
      m_hExternalCutoffMessage.setTestDate(szTestDate);
      return(1);
   }
   else
      return(0);
  //## end ExternalMessageProcessor::reset%38B90AB30292.body
}

// Additional Declarations
  //## begin ExternalMessageProcessor%38B803230274.declarations preserve=yes
  //## end ExternalMessageProcessor%38B803230274.declarations

//## begin module%38B81C6000D0.epilog preserve=yes
//## end module%38B81C6000D0.epilog
