//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%41C10C3500A8.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%41C10C3500A8.cm

//## begin module%41C10C3500A8.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%41C10C3500A8.cp

//## Module: CXOSXI06%41C10C3500A8; Package body
//## Subsystem: XI%38B818930275
//## Source file: C:\Devel\Dn\Server\Application\XI\CXOSXI06.cpp

//## begin module%41C10C3500A8.additionalIncludes preserve=no
//## end module%41C10C3500A8.additionalIncludes

//## begin module%41C10C3500A8.includes preserve=yes
//## end module%41C10C3500A8.includes

#ifndef CXOSRS10_h
#include "CXODRS10.hpp"
#endif
#ifndef CXOSRS12_h
#include "CXODRS12.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRS42_h
#include "CXODRS42.hpp"
#endif
#ifndef CXOSSI01_h
#include "CXODSI01.hpp"
#endif
#ifndef CXOSXI06_h
#include "CXODXI06.hpp"
#endif


//## begin module%41C10C3500A8.declarations preserve=no
//## end module%41C10C3500A8.declarations

//## begin module%41C10C3500A8.additionalDeclarations preserve=yes
//## end module%41C10C3500A8.additionalDeclarations


// Class ExternalDeviceAdminMessage

ExternalDeviceAdminMessage::ExternalDeviceAdminMessage()
  //## begin ExternalDeviceAdminMessage::ExternalDeviceAdminMessage%41C10AB3036A_const.hasinit preserve=no
  //## end ExternalDeviceAdminMessage::ExternalDeviceAdminMessage%41C10AB3036A_const.hasinit
  //## begin ExternalDeviceAdminMessage::ExternalDeviceAdminMessage%41C10AB3036A_const.initialization preserve=yes
  //## end ExternalDeviceAdminMessage::ExternalDeviceAdminMessage%41C10AB3036A_const.initialization
{
  //## begin ExternalDeviceAdminMessage::ExternalDeviceAdminMessage%41C10AB3036A_const.body preserve=yes
   memcpy(m_sID,"XI06",4);
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("S054",ExternalMessageSegment::instance()));
   m_hSegments.insert(map<string,Segment*,less<string> >::value_type("A001",DeviceAdminSegment::instance()));
  //## end ExternalDeviceAdminMessage::ExternalDeviceAdminMessage%41C10AB3036A_const.body
}


ExternalDeviceAdminMessage::~ExternalDeviceAdminMessage()
{
  //## begin ExternalDeviceAdminMessage::~ExternalDeviceAdminMessage%41C10AB3036A_dest.body preserve=yes
  //## end ExternalDeviceAdminMessage::~ExternalDeviceAdminMessage%41C10AB3036A_dest.body
}



//## Other Operations (implementation)
bool ExternalDeviceAdminMessage::insert ()
{
  //## begin ExternalDeviceAdminMessage::insert%41C1116E0281.body preserve=yes
   UseCase hUseCase("EXTERNAL","## EX09 READ DEVICE ADMIN");
   if (!ExternalMessage::insert())
   {
      setReason("IMPORT FAILURE");
      return false;
   }
   DeviceAdminSegment::instance()->shift();
   Message::instance(Message::INBOUND)->reset("AI LE ","S0002D");
   char* psBuffer = Message::instance(Message::INBOUND)->data();
   m_pAuditSegment->setHashValue(getHashValue());
   m_pAuditSegment->setSourceID(Application::instance()->name().c_str());
   m_pAuditSegment->write(&psBuffer);
#ifdef DEVL
   if (getTestDate().length())
   {
      char szTemp[16];
      memcpy(szTemp,getTestDate().data(),8);
      memcpy(szTemp + 8,DeviceAdminSegment::instance()->getTSTAMP_TRANS().data() + 8,8);
      DeviceAdminSegment::instance()->setTSTAMP_TRANS(szTemp,16);
   }
#endif
   DeviceAdminSegment::instance()->setUNIQUENESS_KEY(getUNIQUENESS_KEY());
   DeviceAdminSegment::instance()->write(&psBuffer);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - Message::instance(Message::INBOUND)->data());
   return true;
  //## end ExternalDeviceAdminMessage::insert%41C1116E0281.body
}

// Additional Declarations
  //## begin ExternalDeviceAdminMessage%41C10AB3036A.declarations preserve=yes
  //## end ExternalDeviceAdminMessage%41C10AB3036A.declarations

//## begin module%41C10C3500A8.epilog preserve=yes
//## end module%41C10C3500A8.epilog
