//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3B1B96AB02DE.cm preserve=no
//	$Date:   Aug 16 2021 01:41:20  $ $Author:   e5627846  $
//	$Revision:   1.50  $
//## end module%3B1B96AB02DE.cm

//## begin module%3B1B96AB02DE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3B1B96AB02DE.cp

//## Module: CXOPAM00%3B1B96AB02DE; Package body
//## Subsystem: AM%3B1B954100EA
//## Source file: C:\bV03.1B.R001\Windows\Build\Dn\Server\Application\Am\CXOPAM00.cpp

//## begin module%3B1B96AB02DE.additionalIncludes preserve=no
//## end module%3B1B96AB02DE.additionalIncludes

//## begin module%3B1B96AB02DE.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),ENVAR('TASK=AM'))
#endif
//## end module%3B1B96AB02DE.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSAR03_h
#include "CXODAR03.hpp"
#endif
#ifndef CXOSRU37_h
#include "CXODRU37.hpp"
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
#ifndef CXOSDB16_h
#include "CXODDB16.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSSA01_h
#include "CXODSA01.hpp"
#endif
#ifndef CXOSSA06_h
#include "CXODSA06.hpp"
#endif
#ifndef CXOSSA15_h
#include "CXODSA15.hpp"
#endif
#ifndef CXOSSA10_h
#include "CXODSA10.hpp"
#endif
#ifndef CXOSSA02_h
#include "CXODSA02.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSMC03_h
#include "CXODMC03.hpp"
#endif
#ifndef CXOSMC15_h
#include "CXODMC15.hpp"
#endif
#ifndef CXOSMC02_h
#include "CXODMC02.hpp"
#endif
#ifndef CXOSMC05_h
#include "CXODMC05.hpp"
#endif
#ifndef CXOSMC09_h
#include "CXODMC09.hpp"
#endif
#ifndef CXOSMC13_h
#include "CXODMC13.hpp"
#endif
#ifndef CXOSMC11_h
#include "CXODMC11.hpp"
#endif
#ifndef CXOSMC10_h
#include "CXODMC10.hpp"
#endif
#ifndef CXOSMC16_h
#include "CXODMC16.hpp"
#endif
#ifndef CXOSMC12_h
#include "CXODMC12.hpp"
#endif
#ifndef CXOSMC01_h
#include "CXODMC01.hpp"
#endif
#ifndef CXOSMC04_h
#include "CXODMC04.hpp"
#endif
#ifndef CXOSMC07_h
#include "CXODMC07.hpp"
#endif
#ifndef CXOSMC18_h
#include "CXODMC18.hpp"
#endif
#ifndef CXOSUC12_h
#include "CXODUC12.hpp"
#endif
#ifndef CXOSMC23_h
#include "CXODMC23.hpp"
#endif
#ifndef CXOSMC24_h
#include "CXODMC24.hpp"
#endif
#ifndef CXOSUC21_h
#include "CXODUC21.hpp"
#endif
#ifndef CXOSSX36_h
#include "CXODSX36.hpp"
#endif
#ifndef CXOSSX46_h
#include "CXODSX46.hpp"
#endif
#ifndef CXOSSX47_h
#include "CXODSX47.hpp"
#endif
#ifndef CXOSDB22_h
#include "CXODDB22.hpp"
#endif
#ifndef CXOPAM00_h
#include "CXODAM00.hpp"
#endif


//## begin module%3B1B96AB02DE.declarations preserve=no
//## end module%3B1B96AB02DE.declarations

//## begin module%3B1B96AB02DE.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new ATMManager();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%3B1B96AB02DE.additionalDeclarations


// Class ATMManager

ATMManager::ATMManager()
  //## begin ATMManager::ATMManager%3B17AA7C0398_const.hasinit preserve=no
      : m_lHours(0),
        m_pCutoffListCommand(0),
        m_pBalanceSheetDelete(0),
        m_pCardCaptureListCommand(0),
        m_pBalanceSheetListCommand(0),
        m_pDepositTransactionsListCommand(0),
        m_pDepositTransactionsUpdateCommand(0),
        m_pDepositDataAuditListCommand(0),
        m_pDepositVerificationSheetListCommand(0),
        m_pDepositVerificationSheetRecalculateCommand(0),
        m_pDepositVerificationSheetUpdateCommand(0),
        m_pBalanceSheetAuditListCommand(0),
        m_pBalanceSheetCreateCommand(0),
        m_pBalanceSheetUpdateCommand(0),
        m_pDepositVerificationSheetDeleteCommand(0),
        m_pAdminListCommand(0),
        m_pBalanceSheetInstListCommand(0),
        m_pBalanceSheetDeviceListCommand(0),
        m_pGetElectronicJournalCommand(0),
        m_pATMReplaceDepositCommand(0),
        m_pATMModifyDeposit(0),
        m_pATMDeposit(0),
        m_pATMSweepListCommand(0)
  //## end ATMManager::ATMManager%3B17AA7C0398_const.hasinit
  //## begin ATMManager::ATMManager%3B17AA7C0398_const.initialization preserve=yes
  //## end ATMManager::ATMManager%3B17AA7C0398_const.initialization
{
  //## begin ATMManager::ATMManager%3B17AA7C0398_const.body preserve=yes
   memcpy(m_sID,"AM00",4);
  //## end ATMManager::ATMManager%3B17AA7C0398_const.body
}


ATMManager::~ATMManager()
{
  //## begin ATMManager::~ATMManager%3B17AA7C0398_dest.body preserve=yes
   delete m_pATMSweepListCommand;
   delete m_pATMModifyDeposit;
   delete m_pATMReplaceDepositCommand;
   delete m_pGetElectronicJournalCommand;
   delete m_pAdminListCommand;
   delete m_pCutoffListCommand;
   delete m_pCardCaptureListCommand;
   delete m_pBalanceSheetDelete;
   delete m_pBalanceSheetUpdateCommand;
   delete m_pBalanceSheetCreateCommand;
   delete m_pBalanceSheetAuditListCommand;
   delete m_pDepositTransactionsListCommand;
   delete m_pDepositTransactionsUpdateCommand;
   delete m_pDepositDataAuditListCommand;
   delete m_pDepositVerificationSheetListCommand;
   delete m_pDepositVerificationSheetRecalculateCommand;
   delete m_pDepositVerificationSheetUpdateCommand;
   delete m_pDepositVerificationSheetDeleteCommand;
   delete m_pBalanceSheetDeviceListCommand;
   delete m_pBalanceSheetInstListCommand;
   delete m_pATMDeposit;
  //## end ATMManager::~ATMManager%3B17AA7C0398_dest.body
}



//## Other Operations (implementation)
int ATMManager::initialize ()
{
  //## begin ATMManager::initialize%3B17AAC9000A.body preserve=yes
   new dnplatform::DNPlatform();
   new segment::AuditEvent;
   int i = ServiceApplication::initialize();
   UseCase hUseCase("CLIENT","## CL97 START AM");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   database::CRTransactionTypeIndicator::instance();
   m_pATMModifyDeposit = new soapcommand::ATMModifyDeposit(0);
   m_pATMSweepListCommand = new soapcommand::ATMSweepListCommand(m_pATMModifyDeposit);
   m_pATMReplaceDepositCommand = new soapcommand::ATMReplaceDepositCommand(m_pATMSweepListCommand);
   m_pGetElectronicJournalCommand = new GetElectronicJournalCommand(m_pATMReplaceDepositCommand);
   m_pAdminListCommand = new AdminListCommand(m_pGetElectronicJournalCommand);
   m_pCutoffListCommand = new CutoffListCommand(m_pAdminListCommand);
   m_pCardCaptureListCommand = new CardCaptureListCommand(m_pCutoffListCommand);
   m_pBalanceSheetListCommand = new BalanceSheetListCommand(m_pCardCaptureListCommand);
   m_pBalanceSheetInstListCommand = new BalanceSheetInstListCommand(m_pBalanceSheetListCommand);
   m_pBalanceSheetDeviceListCommand = new BalanceSheetDeviceListCommand(m_pBalanceSheetInstListCommand);
   m_pBalanceSheetUpdateCommand = new BalanceSheetUpdateCommand(m_pBalanceSheetDeviceListCommand);
   m_pBalanceSheetCreateCommand = new BalanceSheetCreateCommand(m_pBalanceSheetUpdateCommand);
   m_pBalanceSheetAuditListCommand = new BalanceSheetAuditListCommand(m_pBalanceSheetCreateCommand);
   m_pDepositTransactionsListCommand = new DepositTransactionsListCommand(m_pBalanceSheetAuditListCommand);
   m_pDepositTransactionsUpdateCommand = new DepositTransactionsUpdateCommand(m_pDepositTransactionsListCommand);
   m_pDepositDataAuditListCommand = new DepositDataAuditListCommand(m_pDepositTransactionsUpdateCommand);
   m_pDepositVerificationSheetListCommand = new DepositVerificationSheetListCommand(m_pDepositDataAuditListCommand);
   m_pDepositVerificationSheetRecalculateCommand = new DepositVerificationSheetRecalculateCommand(m_pDepositVerificationSheetListCommand);
   m_pDepositVerificationSheetUpdateCommand = new DepositVerificationSheetUpdateCommand(m_pDepositVerificationSheetRecalculateCommand);
   m_pDepositVerificationSheetDeleteCommand = new DepositVerificationSheetDeleteCommand(m_pDepositVerificationSheetUpdateCommand);
   if (Extract::instance()->getCustomCode() == "SECU")
   {
      m_pATMDeposit = new secuapi::ATMDeposit();
      secuapi::CardholderLetter::instance();
      secuapi::CMSLog::instance();
      secuapi::DepositAdjustmentAudit::instance();
      secuapi::CardholderRequest::instance();
   }
   entitysegment::SwitchBusinessDay::instance();
   Database::instance()->attach(this);
   Database::instance()->connect();
   Queue::attach("@##SERVER",Queue::CX_DISTRIBUTION_QUEUE);
   m_pBalanceSheetDelete = new BalanceSheetDelete();
   ConfigurationRepository::instance()->loadTable("X_GENERIC"); 
   return 0;
  //## end ATMManager::initialize%3B17AAC9000A.body
}

int ATMManager::onMessage (Message& hMessage)
{
  //## begin ATMManager::onMessage%3B17AAED01CE.body preserve=yes
   Transaction::instance()->begin();
   string strTimeStamp = Clock::instance()->getYYYYMMDDHHMMSS(true);
   Transaction::instance()->setTimeStamp(strTimeStamp += "00");
   m_pDepositVerificationSheetDeleteCommand->update(Message::instance(Message::INBOUND));
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      Database::instance()->rollback();
   else
      Database::instance()->commit();
   Transaction::instance()->commit();
   idle();
   return 0;
  //## end ATMManager::onMessage%3B17AAED01CE.body
}

int ATMManager::onReset (Message& hMessage)
{
  //## begin ATMManager::onReset%3D82070C0148.body preserve=yes
   if (hMessage.context().indexOf("DELETE-S") > 0)
   {
      UseCase hUseCase("DR","## DR55 DELETE DEPOSIT SHEETS");
      GenericDelete hGenericDelete("DEPOSIT_VER_SHEET","DEPOSIT_SHEET_PTR",true);
      hGenericDelete.deleteRecords("TSTAMP_CREATED",(char*)hMessage.context().subString(9));
   }
   else
   if (hMessage.context().indexOf("DELETE-D") > 0)
   {
      UseCase hUseCase("DR","## DR56 DELETE DEPOSITS");
      GenericDelete hGenericDelete("DEPOSIT_TRAN","DEPOSIT_TRAN_PTR",true);
      hGenericDelete.deleteRecords("TSTAMP_CREATED",(char*)hMessage.context().subString(9));
   }
   if (Database::instance()->transactionState() == Database::COMMITREQUIRED)
      Database::instance()->commit();
   else
      Database::instance()->rollback();
   return 0;
  //## end ATMManager::onReset%3D82070C0148.body
}

// Additional Declarations
  //## begin ATMManager%3B17AA7C0398.declarations preserve=yes
  //## end ATMManager%3B17AA7C0398.declarations

//## begin module%3B1B96AB02DE.epilog preserve=yes
//## end module%3B1B96AB02DE.epilog
