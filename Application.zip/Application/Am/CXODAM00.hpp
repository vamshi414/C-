//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3B1B969F00AB.cm preserve=no
//	$Date:   Jun 22 2021 07:35:04  $ $Author:   e1009839  $
//	$Revision:   1.31  $
//## end module%3B1B969F00AB.cm

//## begin module%3B1B969F00AB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3B1B969F00AB.cp

//## Module: CXOPAM00%3B1B969F00AB; Package specification
//## Subsystem: AM%3B1B954100EA
//## Source file: C:\bV03.1B.R001\Windows\Build\Dn\Server\Application\Am\CXODAM00.hpp

#ifndef CXOPAM00_h
#define CXOPAM00_h 1

//## begin module%3B1B969F00AB.additionalIncludes preserve=no
//## end module%3B1B969F00AB.additionalIncludes

//## begin module%3B1B969F00AB.includes preserve=yes
//## end module%3B1B969F00AB.includes

#ifndef CXOSPS03_h
#include "CXODPS03.hpp"
#endif

//## Modelname: Device Management::ManagementCommand_CAT%3A06C995022A
namespace managementcommand {
class BalanceSheetAuditListCommand;
class BalanceSheetDeviceListCommand;
class BalanceSheetInstListCommand;
class DepositVerificationSheetDeleteCommand;
class DepositVerificationSheetRecalculateCommand;
class BalanceSheetDelete;
class DepositTransactionsUpdateCommand;
class DepositVerificationSheetUpdateCommand;
class DepositDataAuditListCommand;
class DepositVerificationSheetListCommand;
class DepositTransactionsListCommand;
class BalanceSheetUpdateCommand;
class BalanceSheetListCommand;
class BalanceSheetCreateCommand;
class CutoffListCommand;
class CardCaptureListCommand;
} // namespace managementcommand

//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
class ArchiveRetriever;
} // namespace archive

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::UserCommand_CAT%394E26E302E3
namespace usercommand {
class GetElectronicJournalCommand;
class AdminListCommand;
} // namespace usercommand

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: DataNavigator Foundation::SOAPCommand_CAT%4DC0633D0140
namespace soapcommand {
class ATMModifyDeposit;
class ATMReplaceDepositCommand;
} // namespace soapcommand

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
class Mask;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;
class Message;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class GlobalContext;
class DatabaseFactory;
class CRTransactionTypeIndicator;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class AuditEvent;
} // namespace segment

//## Modelname: Platform \: SECU::SECUAPI%5B7380FC01F4
namespace secuapi {
class ATMDeposit;
class CardholderRequest;
class DepositAdjustmentAudit;
class CardholderLetter;
class CMSLog;
} // namespace secuapi

namespace soapcommand {
class ATMSweepListCommand;

} // namespace soapcommand

//## begin module%3B1B969F00AB.declarations preserve=no
//## end module%3B1B969F00AB.declarations

//## begin module%3B1B969F00AB.additionalDeclarations preserve=yes
namespace secuapi {
   class ATMDeposit;
}
//## end module%3B1B969F00AB.additionalDeclarations


//## begin ATMManager%3B17AA7C0398.preface preserve=yes
//## end ATMManager%3B17AA7C0398.preface

//## Class: ATMManager%3B17AA7C0398
//	<body>
//	<title>CG
//	<h1>AM
//	<h2>AB
//	<p>
//	Auto Balance combines system generated totals with user
//	input and calculates a reconciliation position for each
//	ATM when it is balanced.
//	The DataNavigator client provides the totals calculated
//	from the logged dispense transactions.
//	The user will then enter data based on the actual
//	balancing of the ATM.
//	<p>
//	Auto Balance provides you with the following ability:
//	<p>
//	</ul>
//	<li>Access and process balance sheets for a cut-off
//	period.
//	<li>Handle non-cash media.
//	<li>Print and export a balance sheet and balancing
//	totals.
//	<li>Track and update captured card information.
//	<li>View any administrative transactions performed at a
//	device
//	<li>Show an audit trail for changes to a balance sheet
//	<li>View and process possible exception transactions.
//	</ul>
//	<p>
//	Auto Balance saves time and money by using these totals
//	and data to calculate the net position by device and
//	present a balance position for the ATM owner.
//	<p>
//	Deposit Verification allows you to view deposit
//	transactions made at a specific device.
//	You can compare the logged amounts to the actual amounts
//	contained in the deposit envelopes for the institution.
//	Deposit transactions can be changed in DataNavigator to
//	reflect the actual amounts contained in the deposit
//	envelopes.
//	By streamlining online deposit verification, the
//	institution can simplify end-of-day balancing and
//	exception adjustment processing.
//	<!-- release V02.1B.R001 -->
//	<p>
//	The FIS Advantage switch logs the electronic journal
//	uploaded from ATMs.
//	DataNavigator can be configured (by institution) to save
//	this journal in the data repository.
//	The ATM Manager provides the ATM Electronic Journal (if
//	available) combined with the logged transactions to the
//	DataNavigator client.
//	This is shown in a side-by-side format and allows the
//	user to reconcile issues between the transaction that
//	was logged and the actual function done at the ATM.
//	Transaction research also displays an Electronic Journal
//	tab on ATM transactions if the information is available.
//	<!-- /release -->
//	</p>
//	<h3>System Flow
//	<p>
//	The DataNavigator server provides device balancing and
//	verification services.
//	<p>
//	The ATM Manager service (<i>ca</i>AM) handles device
//	balance sheet and deposit verification requests from end
//	users.
//	Requests come through the Client Interface service
//	(<i>ca</i>CI01).
//	</p>
//	<img src=CXOCAM00.gif>
//	<p>
//	Refer to the <i>DataNavigator Client Device Services
//	User's Guide</i> for more information.
//	</p>
//	</body>
//	<body>
//	<title>OG
//	<h1>AM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server provides device balancing and
//	verification services.
//	<p>
//	The ATM Manager service (<i>ca</i>AM) handles device
//	balance sheet and deposit verification requests from end
//	users.
//	</p>
//	<img src=CXOOAM00.gif>
//	<h2>TS
//	<h3>DataNavigator Client
//	<p>
//	<b>Issue:</b>  End user reporting problems with services
//	provided by ATM Manager.
//	<p>
//	<b>Resolution:</b>  Refer to the Troubleshooting tips
//	for the Client Interface in the <i>DataNavigator Server
//	Operations Guide: Foundation</i> manual.
//	</p>
//	</body>
//## Category: Device Management::ATMManager_CAT%3B17A9F003AB
//## Subsystem: AM%3B1B954100EA
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..1



//## Uses: <unnamed>%3B17ABCF024B;database::Database { -> F}
//## Uses: <unnamed>%3B17ABDC039E;IF::Message { -> F}
//## Uses: <unnamed>%3B17ABE00137;monitor::UseCase { -> F}
//## Uses: <unnamed>%3B17ABF3024D;reusable::Transaction { -> F}
//## Uses: <unnamed>%3B17AC0301F6;database::GlobalContext { -> F}
//## Uses: <unnamed>%3B17AC140128;timer::Clock { -> F}
//## Uses: <unnamed>%3BCECE5801B5;IF::Queue { -> F}
//## Uses: <unnamed>%3C0E80FA034C;IF::Extract { -> F}
//## Uses: <unnamed>%3D82022801D4;database::GenericDelete { -> F}
//## Uses: <unnamed>%40A3C5AC0213;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%40A3C6D702FD;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%47D15BD602A8;archive::ArchiveRetriever { -> F}
//## Uses: <unnamed>%4E46996F003A;reusable::Mask { -> F}
//## Uses: <unnamed>%5B2BBFEF0388;segment::AuditEvent { -> F}
//## Uses: <unnamed>%5B2BC03E0145;database::CRTransactionTypeIndicator { -> F}
//## Uses: <unnamed>%5BE1EF54039B;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%5BE1F38D00F3;secuapi::ATMDeposit { -> F}
//## Uses: <unnamed>%5EA7E59C02BE;secuapi::CardholderLetter { -> F}
//## Uses: <unnamed>%5EDA1D9302BA;secuapi::CardholderRequest { -> F}
//## Uses: <unnamed>%5EDA1DD60392;secuapi::DepositAdjustmentAudit { -> F}
//## Uses: <unnamed>%5EDA1DD9035A;secuapi::CMSLog { -> F}

class ATMManager : public process::ServiceApplication  //## Inherits: <unnamed>%3BCECD60037A
{
  //## begin ATMManager%3B17AA7C0398.initialDeclarations preserve=yes
  //## end ATMManager%3B17AA7C0398.initialDeclarations

  public:
    //## Constructors (generated)
      ATMManager();

    //## Destructor (generated)
      virtual ~ATMManager();


    //## Other Operations (specified)
      //## Operation: initialize%3B17AAC9000A
      virtual int initialize ();

    // Additional Public Declarations
      //## begin ATMManager%3B17AA7C0398.public preserve=yes
      //## end ATMManager%3B17AA7C0398.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%3B17AAED01CE
      virtual int onMessage (Message& hMessage);

      //## Operation: onReset%3D82070C0148
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AM
      //	<h2>CD
      //	<h3>Delete Deposit Verification Sheets
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>AM DELETE-S12MONTHS
      //	<h4>Description
      //	<p>
      //	The ATM Manager service deletes all deposit verification
      //	sheets prior to the current years data.
      //	</p>
      //	<h4>Schedule
      //	<p>
      //	The DataNavigator Server installation automatically sets
      //	up an event to perform this command at 03:00 AM.
      //	Use the CR Client to change the time or the number of
      //	months of data to retain.
      //	<p>
      //	The Events are in the Event Management folder in the CR
      //	Client for the DataNavigator Server.
      //	</p>
      //	<h3>Delete Deposit Transactions
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>AM DELETE-D12MONTHS
      //	<h4>Description
      //	<p>
      //	The ATM Manager service deletes all deposit transactions
      //	prior to the current years data.
      //	This command only affects the <i>custqual</i>.DEPOSIT_
      //	TRAN table.
      //	</p>
      //	<h4>Schedule
      //	<p>
      //	The DataNavigator Server installation automatically sets
      //	up an event to perform this command at 03:00 AM.
      //	Use the CR Client to change the time or the number of
      //	months of data to retain.
      //	<p>
      //	The Events are in the Event Management folder in the CR
      //	Client for the DataNavigator Server.
      //	</p>
      //	</body>
      virtual int onReset (Message& hMessage);

    // Additional Protected Declarations
      //## begin ATMManager%3B17AA7C0398.protected preserve=yes
      //## end ATMManager%3B17AA7C0398.protected

  private:
    // Additional Private Declarations
      //## begin ATMManager%3B17AA7C0398.private preserve=yes
      //## end ATMManager%3B17AA7C0398.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Hours%3FBA4DDB02AF
      //## begin ATMManager::Hours%3FBA4DDB02AF.attr preserve=no  private: int {U} 0
      int m_lHours;
      //## end ATMManager::Hours%3FBA4DDB02AF.attr

    // Data Members for Associations

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17ACA00382
      //## Role: ATMManager::<m_pCutoffListCommand>%3B17ACA300D3
      //## begin ATMManager::<m_pCutoffListCommand>%3B17ACA300D3.role preserve=no  public: managementcommand::CutoffListCommand { -> RFHgN}
      managementcommand::CutoffListCommand *m_pCutoffListCommand;
      //## end ATMManager::<m_pCutoffListCommand>%3B17ACA300D3.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17ACA800C7
      //## Role: ATMManager::<m_pBalanceSheetDelete>%3B17ACA9000A
      //## begin ATMManager::<m_pBalanceSheetDelete>%3B17ACA9000A.role preserve=no  public: managementcommand::BalanceSheetDelete { -> RFHgN}
      managementcommand::BalanceSheetDelete *m_pBalanceSheetDelete;
      //## end ATMManager::<m_pBalanceSheetDelete>%3B17ACA9000A.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17ACB10015
      //## Role: ATMManager::<m_pCardCaptureListCommand>%3B17ACB1021E
      //## begin ATMManager::<m_pCardCaptureListCommand>%3B17ACB1021E.role preserve=no  public: managementcommand::CardCaptureListCommand { -> RFHgN}
      managementcommand::CardCaptureListCommand *m_pCardCaptureListCommand;
      //## end ATMManager::<m_pCardCaptureListCommand>%3B17ACB1021E.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17AE150310
      //## Role: ATMManager::<m_pBalanceSheetListCommand>%3B17AE1701AB
      //## begin ATMManager::<m_pBalanceSheetListCommand>%3B17AE1701AB.role preserve=no  public: managementcommand::BalanceSheetListCommand { -> RFHgN}
      managementcommand::BalanceSheetListCommand *m_pBalanceSheetListCommand;
      //## end ATMManager::<m_pBalanceSheetListCommand>%3B17AE1701AB.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17AE1901EA
      //## Role: ATMManager::<m_pDepositTransactionsListCommand>%3B17AE1A0097
      //## begin ATMManager::<m_pDepositTransactionsListCommand>%3B17AE1A0097.role preserve=no  public: managementcommand::DepositTransactionsListCommand { -> RFHgN}
      managementcommand::DepositTransactionsListCommand *m_pDepositTransactionsListCommand;
      //## end ATMManager::<m_pDepositTransactionsListCommand>%3B17AE1A0097.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17AE1B0233
      //## Role: ATMManager::<m_pDepositTransactionsUpdateCommand>%3B17AE1C00D6
      //## begin ATMManager::<m_pDepositTransactionsUpdateCommand>%3B17AE1C00D6.role preserve=no  public: managementcommand::DepositTransactionsUpdateCommand { -> RFHgN}
      managementcommand::DepositTransactionsUpdateCommand *m_pDepositTransactionsUpdateCommand;
      //## end ATMManager::<m_pDepositTransactionsUpdateCommand>%3B17AE1C00D6.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17AE1D0131
      //## Role: ATMManager::<m_pDepositDataAuditListCommand>%3B17AE1E001A
      //## begin ATMManager::<m_pDepositDataAuditListCommand>%3B17AE1E001A.role preserve=no  public: managementcommand::DepositDataAuditListCommand { -> RFHgN}
      managementcommand::DepositDataAuditListCommand *m_pDepositDataAuditListCommand;
      //## end ATMManager::<m_pDepositDataAuditListCommand>%3B17AE1E001A.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17AE1F017A
      //## Role: ATMManager::<m_pDepositVerificationSheetListCommand>%3B17AE2000F9
      //## begin ATMManager::<m_pDepositVerificationSheetListCommand>%3B17AE2000F9.role preserve=no  public: managementcommand::DepositVerificationSheetListCommand { -> RFHgN}
      managementcommand::DepositVerificationSheetListCommand *m_pDepositVerificationSheetListCommand;
      //## end ATMManager::<m_pDepositVerificationSheetListCommand>%3B17AE2000F9.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17AE2101E1
      //## Role: ATMManager::<m_pDepositVerificationSheetRecalculateCommand>%3B17AE2201CF
      //## begin ATMManager::<m_pDepositVerificationSheetRecalculateCommand>%3B17AE2201CF.role preserve=no  public: managementcommand::DepositVerificationSheetRecalculateCommand { -> RFHgN}
      managementcommand::DepositVerificationSheetRecalculateCommand *m_pDepositVerificationSheetRecalculateCommand;
      //## end ATMManager::<m_pDepositVerificationSheetRecalculateCommand>%3B17AE2201CF.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17AE2302E8
      //## Role: ATMManager::<m_pDepositVerificationSheetUpdateCommand>%3B17AE2402C2
      //## begin ATMManager::<m_pDepositVerificationSheetUpdateCommand>%3B17AE2402C2.role preserve=no  public: managementcommand::DepositVerificationSheetUpdateCommand { -> RFHgN}
      managementcommand::DepositVerificationSheetUpdateCommand *m_pDepositVerificationSheetUpdateCommand;
      //## end ATMManager::<m_pDepositVerificationSheetUpdateCommand>%3B17AE2402C2.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17AE2903AF
      //## Role: ATMManager::<m_pBalanceSheetAuditListCommand>%3B17AE2E0302
      //## begin ATMManager::<m_pBalanceSheetAuditListCommand>%3B17AE2E0302.role preserve=no  public: managementcommand::BalanceSheetAuditListCommand { -> RFHgN}
      managementcommand::BalanceSheetAuditListCommand *m_pBalanceSheetAuditListCommand;
      //## end ATMManager::<m_pBalanceSheetAuditListCommand>%3B17AE2E0302.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17AE380086
      //## Role: ATMManager::<m_pBalanceSheetCreateCommand>%3B17AE4100F7
      //## begin ATMManager::<m_pBalanceSheetCreateCommand>%3B17AE4100F7.role preserve=no  public: managementcommand::BalanceSheetCreateCommand { -> RFHgN}
      managementcommand::BalanceSheetCreateCommand *m_pBalanceSheetCreateCommand;
      //## end ATMManager::<m_pBalanceSheetCreateCommand>%3B17AE4100F7.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17AE450034
      //## Role: ATMManager::<m_pBalanceSheetUpdateCommand>%3B17AE4F0043
      //## begin ATMManager::<m_pBalanceSheetUpdateCommand>%3B17AE4F0043.role preserve=no  public: managementcommand::BalanceSheetUpdateCommand { -> RFHgN}
      managementcommand::BalanceSheetUpdateCommand *m_pBalanceSheetUpdateCommand;
      //## end ATMManager::<m_pBalanceSheetUpdateCommand>%3B17AE4F0043.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17F79001D4
      //## Role: ATMManager::<m_pDepositVerificationSheetDeleteCommand>%3B17F79D0138
      //## begin ATMManager::<m_pDepositVerificationSheetDeleteCommand>%3B17F79D0138.role preserve=no  public: managementcommand::DepositVerificationSheetDeleteCommand { -> RFHgN}
      managementcommand::DepositVerificationSheetDeleteCommand *m_pDepositVerificationSheetDeleteCommand;
      //## end ATMManager::<m_pDepositVerificationSheetDeleteCommand>%3B17F79D0138.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%3B17F7A90280
      //## Role: ATMManager::<m_pAdminListCommand>%3B17F7B5006D
      //## begin ATMManager::<m_pAdminListCommand>%3B17F7B5006D.role preserve=no  public: usercommand::AdminListCommand { -> RFHgN}
      usercommand::AdminListCommand *m_pAdminListCommand;
      //## end ATMManager::<m_pAdminListCommand>%3B17F7B5006D.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%41AC7C49009C
      //## Role: ATMManager::<m_pBalanceSheetInstListCommand>%41AC7C4A0222
      //## begin ATMManager::<m_pBalanceSheetInstListCommand>%41AC7C4A0222.role preserve=no  public: managementcommand::BalanceSheetInstListCommand { -> RFHgN}
      managementcommand::BalanceSheetInstListCommand *m_pBalanceSheetInstListCommand;
      //## end ATMManager::<m_pBalanceSheetInstListCommand>%41AC7C4A0222.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%41AC7E8B0148
      //## Role: ATMManager::<m_pBalanceSheetDeviceListCommand>%41AC7E8C01E4
      //## begin ATMManager::<m_pBalanceSheetDeviceListCommand>%41AC7E8C01E4.role preserve=no  public: managementcommand::BalanceSheetDeviceListCommand { -> RFHgN}
      managementcommand::BalanceSheetDeviceListCommand *m_pBalanceSheetDeviceListCommand;
      //## end ATMManager::<m_pBalanceSheetDeviceListCommand>%41AC7E8C01E4.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%469D9F3D033E
      //## Role: ATMManager::<m_pGetElectronicJournalCommand>%469D9F4A0314
      //## begin ATMManager::<m_pGetElectronicJournalCommand>%469D9F4A0314.role preserve=no  public: usercommand::GetElectronicJournalCommand { -> RFHgN}
      usercommand::GetElectronicJournalCommand *m_pGetElectronicJournalCommand;
      //## end ATMManager::<m_pGetElectronicJournalCommand>%469D9F4A0314.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%5B2BBF5F017D
      //## Role: ATMManager::<m_pATMReplaceDepositCommand>%5B2BBF600121
      //## begin ATMManager::<m_pATMReplaceDepositCommand>%5B2BBF600121.role preserve=no  public: soapcommand::ATMReplaceDepositCommand { -> RFHgN}
      soapcommand::ATMReplaceDepositCommand *m_pATMReplaceDepositCommand;
      //## end ATMManager::<m_pATMReplaceDepositCommand>%5B2BBF600121.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%5D07304F03AA
      //## Role: ATMManager::<m_pATMModifyDeposit>%5D07305B03A0
      //## begin ATMManager::<m_pATMModifyDeposit>%5D07305B03A0.role preserve=no  public: soapcommand::ATMModifyDeposit { -> RFHgN}
      soapcommand::ATMModifyDeposit *m_pATMModifyDeposit;
      //## end ATMManager::<m_pATMModifyDeposit>%5D07305B03A0.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%5EA7E83402C8
      //## Role: ATMManager::<m_pATMDeposit>%5EA7E835003F
      //## begin ATMManager::<m_pATMDeposit>%5EA7E835003F.role preserve=no  public: secuapi::ATMDeposit { -> RFHgN}
      secuapi::ATMDeposit *m_pATMDeposit;
      //## end ATMManager::<m_pATMDeposit>%5EA7E835003F.role

      //## Association: Device Management::ATMManager_CAT::<unnamed>%6013759D0396
      //## Role: ATMManager::<m_pATMSweepListCommand>%6013759F0025
      //## begin ATMManager::<m_pATMSweepListCommand>%6013759F0025.role preserve=no  public: soapcommand::ATMSweepListCommand { -> RFHgN}
      soapcommand::ATMSweepListCommand *m_pATMSweepListCommand;
      //## end ATMManager::<m_pATMSweepListCommand>%6013759F0025.role

    // Additional Implementation Declarations
      //## begin ATMManager%3B17AA7C0398.implementation preserve=yes
      //## end ATMManager%3B17AA7C0398.implementation

};

//## begin ATMManager%3B17AA7C0398.postscript preserve=yes
//## end ATMManager%3B17AA7C0398.postscript

//## begin module%3B1B969F00AB.epilog preserve=yes
//## end module%3B1B969F00AB.epilog


#endif
