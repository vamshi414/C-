//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3F28FFE803A9.cm preserve=no
//	$Date:   Oct 07 2019 11:26:44  $ $Author:   e5549623  $ $Revision:   1.7  $
//## end module%3F28FFE803A9.cm

//## begin module%3F28FFE803A9.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3F28FFE803A9.cp

//## Module: CXOPMT00%3F28FFE803A9; Package specification
//## Subsystem: MT%3F28FFC50138
//## Source file: C:\bV02.8A.R001\Windows\Build\ConnexPlatform\Server\Application\Mt\CXODMT00.hpp

#ifndef CXOPMT00_h
#define CXOPMT00_h 1

//## begin module%3F28FFE803A9.additionalIncludes preserve=no
//## end module%3F28FFE803A9.additionalIncludes

//## begin module%3F28FFE803A9.includes preserve=yes
#include <deque>
#include <vector>
//## end module%3F28FFE803A9.includes

#ifndef CXOSMT01_h
#include "CXODMT01.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Signal;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class FlatFile;
class Trace;
class SocketQueue;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;

} // namespace platform

//## begin module%3F28FFE803A9.declarations preserve=no
//## end module%3F28FFE803A9.declarations

//## begin module%3F28FFE803A9.additionalDeclarations preserve=yes
//## end module%3F28FFE803A9.additionalDeclarations


//## begin MailTransferAgent%3F28FF3D00DA.preface preserve=yes
//## end MailTransferAgent%3F28FF3D00DA.preface

//## Class: MailTransferAgent%3F28FF3D00DA
//	<body>
//	<title>CG
//	<h1>MT
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server generates email messages.
//	For example:
//	<ul>
//	<li>Database issues to the DataNavigator DBA
//	<li>Transaction fraud notifications to business analysts
//	<li>Exception case notifications to business analysts
//	</ul>
//	<p>
//	Email messages are forwarded to a mail server (e.g.
//	Microsoft IIS SMTP Server) by the Mail Transfer Agent
//	(MT) service.
//	<p>
//	<img src=CXOCMT00.gif>
//	</p>
//	<title>OG
//	<h1>MT
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Mail Transfer Agent (MT) service forwards email
//	messages to a mail server (e.g. Microsoft IIS SMTP
//	Server).
//	</p>
//	<img src=CXOOMT00.gif>
//	</p>
//	</body>
//## Category: Connex Application::MailTransferAgent_CAT%3F28FF05004E
//## Subsystem: MT%3F28FFC50138
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3F293A960138;IF::Message { -> F}
//## Uses: <unnamed>%3F293AA802EE;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%3F293AAA02CE;monitor::UseCase { -> F}
//## Uses: <unnamed>%3F2A51590271;IF::FlatFile { -> F}
//## Uses: <unnamed>%3F2A53A000BB;IF::Extract { -> F}
//## Uses: <unnamed>%3F2AA54E03C8;IF::SocketQueue { -> F}
//## Uses: <unnamed>%3F2E490500BB;reusable::Signal { -> F}
//## Uses: <unnamed>%3F2E99C8033C;database::Database { -> F}
//## Uses: <unnamed>%3FB2920A0290;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%3FB2948D006D;timer::Date { -> F}
//## Uses: <unnamed>%40AA659E0177;platform::Platform { -> F}
//## Uses: <unnamed>%5A4E238B011C;IF::Trace { -> F}

class DllExport MailTransferAgent : public process::Application  //## Inherits: <unnamed>%3F28FF590138
{
  //## begin MailTransferAgent%3F28FF3D00DA.initialDeclarations preserve=yes
  //## end MailTransferAgent%3F28FF3D00DA.initialDeclarations

  public:
    //## Constructors (generated)
      MailTransferAgent();

    //## Destructor (generated)
      virtual ~MailTransferAgent();


    //## Other Operations (specified)
      //## Operation: initialize%3F28FF600196
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>MT
      //	<h2>MS
      //	<h3>Microsoft IIS
      //	<p>
      //	Add the following Windows 2000 components to the
      //	Application Server machine that will host the Foundation
      //	services (Region DNDN00):
      //	<ul>
      //	Internet Information Services (IIS)
      //	<ul>
      //	<li>Common Files
      //	<li>Documentation
      //	<li>Internet Information Services Snap-In
      //	<li>SMTP Service
      //	</ul>
      //	</ul>
      //	</p>
      //	<img src=CXOCMT01.gif>
      //	<p>
      //	1.  To begin configuration, open the Internet Services
      //	Manager.
      //	</p>
      //	<img src=CXOCMT02.gif>
      //	<p>
      //	2.  Open the mailrelay folder.
      //	</p>
      //	<img src=CXOCMT03.gif>
      //	<p>
      //	3.  Open the Properties for the Default SMTP Virtual
      //	Server.
      //	</p>
      //	<img src=CXOCMT04.gif>
      //	<p>
      //	4.  Open the Connection... dialog and verify that the
      //	value in the TCP port field is set to 25.
      //	</p>
      //	<img src=CXOCMT05.gif>
      //	<p>
      //	5.  On the Access tab of the Default SMTP Virtual Server
      //	Properties dialog, open the Authentication ... dialog.
      //	Verify that the options "Anonymous Access", "Basic
      //	authentication" and "Windows security package" are
      //	selected.
      //	</p>
      //	<img src=CXOCMT06.gif>
      //	<p>
      //	6.  On the Access tab of the Default SMTP Virtual Server
      //	Properties dialog, open the Connection ... dialog.
      //	Verify that the option "Only the list below" is selected.
      //	The list should contain the loop back IP Address
      //	(127.0.0.1) and the IP Address of the DataNavigator
      //	Application Server that will host the Mail Transfer
      //	Agent (MT) service (e.g. 192.168.0.1).
      //	</p>
      //	<img src=CXOCMT07.gif>
      //	<p>
      //	7.  On the Access tab of the Default SMTP Virtual Server
      //	Properties dialog, open the Relay ... dialog.
      //	Verify that the option "Only the list below" is selected.
      //	The list should contain the loop back IP Address
      //	(127.0.0.1) and the IP Address of the DataNavigator
      //	Application Server that will host the Mail Transfer
      //	Agent (MT) service (e.g. 192.168.0.1).
      //	Verify that the option "Allow all computers which
      //	successfully authenticate to relay, regardless of the
      //	list above" is not selected.
      //	</p>
      //	<img src=CXOCMT08.gif>
      //	<p>
      //	8.  On the Messages tab of the Default SMTP Virtual
      //	Server Properties dialog, enter your mail administrator
      //	email address in the field labeled "Send copy of
      //	Non-Delivery report to".
      //	This dialog can now be closed.
      //	</p>
      //	<img src=CXOCMT09.gif>
      //	<p>
      //	9.  Open the Default SMTP Virtual Server folder to add a
      //	new Domain.
      //	The domain type should be set to "Remote".
      //	</p>
      //	<img src=CXOCMT10.gif>
      //	<p>
      //	10.  On the next panel, enter the name of your domain.
      //	</p>
      //	<img src=CXOCMT11.gif>
      //	<p>
      //	11.  Open the Properties for the new domain.
      //	Verify that the option "Allow incoming mail to be
      //	relayed to this domain" is selected.
      //	<p>
      //	After all configuration changes are completed, restart
      //	the SMTP service.
      //	</p>
      //	</body>
      virtual int initialize ();

      //## Operation: update%3F28FF6A029F
      //	Interprets the inbound Message and calls:
      //
      //	   Application::onConfirm
      //	   Application::onMessage
      //	   Application::onNotify
      //	   Application::onQuiesce
      //	   Application::onRefresh
      //	   Application::onReset
      //	   Application::shutdown
      //	   Timer::elapsed
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin MailTransferAgent%3F28FF3D00DA.public preserve=yes
      //## end MailTransferAgent%3F28FF3D00DA.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%3F28FF6600AB
      virtual int onMessage (Message& hMessage);

      //## Operation: onResume%3F295448007D
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>MT
      //	<h2>FI
      //	<h3>Email Messages
      //	<p>
      //	Email messages are formatted and written to the Inbox
      //	folder.
      //	These messages are picked up by the Mail Transfer Agent
      //	and forwarded to an SMTP Server.
      //	<ul>
      //	<li><i>node001</i>\Smtp\Inbox\*.txt
      //	</ul>
      //	</p>
      //	</body>
      virtual int onResume (Message& hMessage);

    // Additional Protected Declarations
      //## begin MailTransferAgent%3F28FF3D00DA.protected preserve=yes
      //## end MailTransferAgent%3F28FF3D00DA.protected

  private:

    //## Other Operations (specified)
      //## Operation: move%3F317023000F
      //## Postconditions:
      //	<body>
      //	<title>CG
      //	<h1>MT
      //	<h2>FO
      //	<h3>Email Messages
      //	<p>
      //	Processed email messages are moved out of the Inbox
      //	folder to the Outbox folder (if successful) or the Dead
      //	Letter folder (if unsuccessful).
      //	<ul>
      //	<li><i>node001</i>\Smtp\DeadLetter\*.txt
      //	<li><i>node001</i>\Smtp\Outbox\*.txt
      //	</ul>
      //	<p>
      //	The messages in both the DeadLetter and Outbox folders
      //	are automatically purged after 7 days.
      //	</p>
      //	</body>
      //	<body>
      //	<title>OG
      //	<h1>MT
      //	<h2>TS
      //	<h3>Undeliverable Email Messages
      //	<p>
      //	Processed email messages are moved to a DeadLetter
      //	folder (if unsuccessful).
      //	<ul>
      //	<li><i>node001</i>\Smtp\DeadLetter\*.txt
      //	</ul>
      //	<p>
      //	Messages that appear in the DeadLetter folder should be
      //	reviewed to determine why delivery is impossible.
      //	The trace file for the MT service will contain the
      //	reason for the failure.
      //	Messages can be resent by moving them from the Dead
      //	Letter folder back to the Inbox folder.
      //	The messages in the DeadLetter folder are automatically
      //	purged after 7 days.
      //	</p>
      //	</body>
      bool move (const string& strFolder);

      //## Operation: send%3F31796E033C
      bool send (const string& strText);

    // Additional Private Declarations
      //## begin MailTransferAgent%3F28FF3D00DA.private preserve=yes
      //## end MailTransferAgent%3F28FF3D00DA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Destination%3F317DAF006D
      //## begin MailTransferAgent::Destination%3F317DAF006D.attr preserve=no  private: string {V} 
      string m_strDestination;
      //## end MailTransferAgent::Destination%3F317DAF006D.attr

      //## Attribute: Name%3F2A52E901A5
      //## begin MailTransferAgent::Name%3F2A52E901A5.attr preserve=no  private: string {V} 
      string m_strName;
      //## end MailTransferAgent::Name%3F2A52E901A5.attr

      //## Attribute: Response%3F2955F002CE
      //## begin MailTransferAgent::Response%3F2955F002CE.attr preserve=no  private: string {V} 
      string m_strResponse;
      //## end MailTransferAgent::Response%3F2955F002CE.attr

      //## Attribute: RetryCount%5B1194670102
      //## begin MailTransferAgent::RetryCount%5B1194670102.attr preserve=no  private: int {U} 0
      int m_iRetryCount;
      //## end MailTransferAgent::RetryCount%5B1194670102.attr

    // Data Members for Associations

      //## Association: Connex Application::MailTransferAgent_CAT::<unnamed>%5A4E223000BB
      //## Role: MailTransferAgent::<m_hFax>%5A4E22310022
      //## begin MailTransferAgent::<m_hFax>%5A4E22310022.role preserve=no  public: Fax { -> VHgN}
      Fax m_hFax;
      //## end MailTransferAgent::<m_hFax>%5A4E22310022.role

    // Additional Implementation Declarations
      //## begin MailTransferAgent%3F28FF3D00DA.implementation preserve=yes
      deque<string> m_hMail;
      vector<string> m_hConversation;
      int m_iCount;
      //## end MailTransferAgent%3F28FF3D00DA.implementation
};

//## begin MailTransferAgent%3F28FF3D00DA.postscript preserve=yes
//## end MailTransferAgent%3F28FF3D00DA.postscript

//## begin module%3F28FFE803A9.epilog preserve=yes
//## end module%3F28FFE803A9.epilog


#endif
