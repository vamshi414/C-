//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3F28FFEB001F.cm preserve=no
//	$Date:   Aug 27 2020 10:41:58  $ $Author:   e1009652  $ $Revision:   1.26  $
//## end module%3F28FFEB001F.cm

//## begin module%3F28FFEB001F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3F28FFEB001F.cp

//## Module: CXOPMT00%3F28FFEB001F; Package body
//## Subsystem: MT%3F28FFC50138
//## Source file: C:\bV02.8A.R001\Windows\Build\ConnexPlatform\Server\Application\Mt\CXOPMT00.cpp

//## begin module%3F28FFEB001F.additionalIncludes preserve=no
//## end module%3F28FFEB001F.additionalIncludes

//## begin module%3F28FFEB001F.includes preserve=yes
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSTM13_h
#include "CXODTM13.hpp"
#endif
//## end module%3F28FFEB001F.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF39_h
#include "CXODIF39.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOPMT00_h
#include "CXODMT00.hpp"
#endif


//## begin module%3F28FFEB001F.declarations preserve=no
//## end module%3F28FFEB001F.declarations

//## begin module%3F28FFEB001F.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new MailTransferAgent();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%3F28FFEB001F.additionalDeclarations


// Class MailTransferAgent 

MailTransferAgent::MailTransferAgent()
  //## begin MailTransferAgent::MailTransferAgent%3F28FF3D00DA_const.hasinit preserve=no
      : m_iRetryCount(0)
  //## end MailTransferAgent::MailTransferAgent%3F28FF3D00DA_const.hasinit
  //## begin MailTransferAgent::MailTransferAgent%3F28FF3D00DA_const.initialization preserve=yes
  //## end MailTransferAgent::MailTransferAgent%3F28FF3D00DA_const.initialization
{
  //## begin MailTransferAgent::MailTransferAgent%3F28FF3D00DA_const.body preserve=yes
   memcpy(m_sID,"MT00",4);
  //## end MailTransferAgent::MailTransferAgent%3F28FF3D00DA_const.body
}


MailTransferAgent::~MailTransferAgent()
{
  //## begin MailTransferAgent::~MailTransferAgent%3F28FF3D00DA_dest.body preserve=yes
  //## end MailTransferAgent::~MailTransferAgent%3F28FF3D00DA_dest.body
}



//## Other Operations (implementation)
int MailTransferAgent::initialize ()
{
  //## begin MailTransferAgent::initialize%3F28FF600196.body preserve=yes
   new platform::Platform();
   int iRC = Application::initialize();
   UseCase hUseCase("FD","## MT00 START MT");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->connect();
   MinuteTimer::instance()->attach(this);
   MidnightAlarm::instance()->attach(this);
   HourAlarm::instance()->attach(this);
   m_iCount = 0;
   return 0;
  //## end MailTransferAgent::initialize%3F28FF600196.body
}

bool MailTransferAgent::move (const string& strFolder)
{
  //## begin MailTransferAgent::move%3F317023000F.body preserve=yes
   if (strFolder == "DeadLetter")
   {
      m_iRetryCount = (++m_iRetryCount == 3 ? 0 : m_iRetryCount);
      if (m_iRetryCount)
         return false;
   }
   else
      m_iRetryCount = 0;
#ifdef _WIN32
   string strNewFileName(m_strName);
   size_t pos = strNewFileName.find("Inbox");
   if (pos == string::npos)
      return false;
   strNewFileName.replace(pos,5,strFolder);
   Trace::put(strNewFileName.c_str());
   bool b = CopyFile(m_strName.c_str(),strNewFileName.c_str(),false);
   if (!b)
   {
      char szBuffer[32];
      Trace::put(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"CopyFile failure: %ld",GetLastError()));
      return false;
   }
   b = DeleteFile(m_strName.c_str());
   if (b == false
      && GetLastError() != 2)
   {
      char szBuffer[64];
      Trace::put(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"DeleteFile (New) failure: %ld",GetLastError()));
      return false;
   }
#else
   string strCommand("mv ");
   strCommand += m_strName;
   strCommand += " ";
   strCommand += Extract::instance()->getNode001();
   strCommand += "/Smtp/";
   strCommand += strFolder;
   strCommand += "/.";
   Trace::put(strCommand.data(),strCommand.length());
   system(strCommand.c_str());
#endif
   return true;
  //## end MailTransferAgent::move%3F317023000F.body
}

int MailTransferAgent::onMessage (Message& hMessage)
{
  //## begin MailTransferAgent::onMessage%3F28FF6600AB.body preserve=yes
   UseCase hUseCase("FD","## MT00 CONTINUE EMAIL");
   Trace::put(Message::instance(Message::INBOUND)->buffer(),Message::instance(Message::INBOUND)->messageLength());
   m_hConversation.push_back(string(Message::instance(Message::INBOUND)->buffer(),Message::instance(Message::INBOUND)->messageLength()));
   if (memcmp(Message::instance(Message::INBOUND)->buffer(),m_strResponse.data(),m_strResponse.length()))
   {
      if(memcmp(Message::instance(Message::INBOUND)->buffer(),"TIMEOUT",7) == 0)
         return UseCase::setSuccess(false);
      for (vector<string>::iterator p = m_hConversation.begin();p != m_hConversation.end();++p)
         Trace::put((*p).data(),(*p).length(),true);
      m_strDestination = "DeadLetter";
      while (m_hMail.size() > 1)
         m_hMail.pop_front();
      UseCase::setSuccess(false);
   }
   if (m_strResponse == "221 ")
   {
      setQueueWaitOption(!move(m_strDestination)); //if successful, don't wait
      return 0;
   }
   bool bSendBody = m_strResponse == "354 ";
   m_strResponse.erase();
   while (m_strResponse.length() == 0)
   {
      string strText(m_hMail.front());
      if (strText == "QUIT\r\n")
         m_strResponse = "221 ";
      else
      if (strText == "DATA\r\n")
         m_strResponse = "354 ";
      else
      if (strText.length() > 3)
      {
         string strCommand(strText.data(),4);
         if ((bSendBody == false
            && (strCommand == "HELO"
            || strCommand == "MAIL"
            || strCommand == "RCPT"))
            || (bSendBody == true
            && strCommand == "\r\n.\r"))
         m_strResponse = "250 ";
      }
      if (!send(strText))
      {
         m_hMail.erase(m_hMail.begin(),m_hMail.end());
         UseCase::setSuccess(false);
         setQueueWaitOption(true);
         break;
      }
      m_hMail.pop_front();
   }
   return 0;
  //## end MailTransferAgent::onMessage%3F28FF6600AB.body
}

int MailTransferAgent::onResume (Message& hMessage)
{
  //## begin MailTransferAgent::onResume%3F295448007D.body preserve=yes
   m_hMail.erase(m_hMail.begin(),m_hMail.end());
   m_hConversation.erase(m_hConversation.begin(),m_hConversation.end());
   m_strDestination = "Outbox";
   FlatFile hFlatFile("INBOX");
   char* psBuffer = new char[4096];
   size_t m = 0;
   while (hFlatFile.read(psBuffer,4094,&m))
   {
      memcpy(psBuffer + m,"\r\n",2);
      if (!memcmp(psBuffer,"HELO ",5))
         m_hMail.erase(m_hMail.begin(),m_hMail.end());
      m_hMail.push_back(string(psBuffer,m + 2));
   }
   delete [] psBuffer;
   if (hFlatFile.getRecordCount() == 0)
   {
      m_strName = hFlatFile.getDatasetName();
      move(m_strDestination);
   }
   if (!m_hMail.empty())
   {
      string strLimit;
      if (Extract::instance()->getSpec("LIMIT", strLimit))
      {
         int limit = atoi(strLimit.c_str());
         if (m_iCount >= limit)
         {
            if (m_iCount == limit)
               Console::display("ST150");
            m_hMail.erase(m_hMail.begin(), m_hMail.end());
            UseCase::setSuccess(false);
            setQueueWaitOption(true);
            m_iCount++;
            return 0;
         }
      }
      UseCase hUseCase("FD","## MT00 SEND EMAIL");
      m_hMail.push_back("\r\n.\r\n");
      m_hMail.push_back("QUIT\r\n");
      UseCase::addItem(m_hMail.size());
      m_strName = hFlatFile.getDatasetName();
      SocketQueue* p = new SocketQueue("SMTP");
      // note: this instance will be destructed by SocketQueue::ReadConnection
      p->setSignal(m_pSignal);
      p->setInterface(SocketQueue::CRLF);
      if (!p->poll("SMTP"))
      {
         m_hMail.erase(m_hMail.begin(),m_hMail.end());
         delete p;
         UseCase::setSuccess(false);
      }
      else {
         m_strResponse = "220 ";
         m_iCount++;
      }
   }
   setQueueWaitOption(true);
   return 0;
  //## end MailTransferAgent::onResume%3F295448007D.body
}

bool MailTransferAgent::send (const string& strText)
{
  //## begin MailTransferAgent::send%3F31796E033C.body preserve=yes
   Trace::put(strText.data(),strText.length());
   m_hConversation.push_back(strText);
   memcpy(Message::instance(Message::OUTBOUND)->buffer(),strText.data(),strText.length());
   Message::instance(Message::OUTBOUND)->setMessageLength(strText.length());
   return (Message::instance(Message::OUTBOUND)->send("SMTP",strText.length()) == 0);
  //## end MailTransferAgent::send%3F31796E033C.body
}

void MailTransferAgent::update (Subject* pSubject)
{
  //## begin MailTransferAgent::update%3F28FF6A029F.body preserve=yes
   if (pSubject == MinuteTimer::instance())
      setQueueWaitOption(SocketQueue::exists("SMTP    ") && !m_hMail.empty());
   else
   if (pSubject == MidnightAlarm::instance())
   {
      UseCase hUseCase("FD","## MT00 PURGE EMAIL");
      Date hDate(Date::today());
      hDate -= 7;
      string strPeriod(hDate.asString("%Y-%m-%d"));
      FlatFile::purge("Smtp\\DeadLetter",strPeriod);
      FlatFile::purge("Smtp\\OutBox",strPeriod);
      FlatFile::purge("Fax\\OutBox",strPeriod);
      hDate -= 31;
      strPeriod = hDate.asString("%Y-%m");
      FlatFile::purge("Smtp\\DeadLetter",strPeriod);
      FlatFile::purge("Smtp\\OutBox",strPeriod);
      FlatFile::purge("Fax\\OutBox",strPeriod);
   }
   else if (pSubject == HourAlarm::instance()) {
      m_iCount = 0;
      Console::display("ST151");
   }
   Application::update(pSubject);
  //## end MailTransferAgent::update%3F28FF6A029F.body
}

// Additional Declarations
  //## begin MailTransferAgent%3F28FF3D00DA.declarations preserve=yes
  //## end MailTransferAgent%3F28FF3D00DA.declarations

//## begin module%3F28FFEB001F.epilog preserve=yes
//## end module%3F28FFEB001F.epilog
