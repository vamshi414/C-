//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%387CFFBE034A.cm preserve=no
//## end module%387CFFBE034A.cm

//## begin module%387CFFBE034A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%387CFFBE034A.cp

//## Module: CXOPTP00%387CFFBE034A; Package specification
//## Subsystem: TP%387CFF980269
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Tp\CXODTP00.hpp

#ifndef CXOPTP00_h
#define CXOPTP00_h 1

//## begin module%387CFFBE034A.additionalIncludes preserve=no
//## end module%387CFFBE034A.additionalIncludes

//## begin module%387CFFBE034A.includes preserve=yes
//## end module%387CFFBE034A.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSAT06_h
#include "CXODAT06.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class Compactor;
class LiabilityManager;
class MISAging;
class TokenAging;
class TotalsAging2;
class TotalsAging1;
} // namespace settlement

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GenericDelete;
class CRTransactionTypeIndicator;
class Database;
} // namespace database

//## Modelname: Reconciliation::NetworkReconciliation_CAT%5637978002B1
namespace networkreconciliation {
class TotalType;
class NetworkReport;
class MasterCardIPMTemplate;
class NetworkFile;
class MASCharges;

} // namespace networkreconciliation

//## begin module%387CFFBE034A.declarations preserve=no
//## end module%387CFFBE034A.declarations

//## begin module%387CFFBE034A.additionalDeclarations preserve=yes
//## end module%387CFFBE034A.additionalDeclarations


//## begin TotalsProcessor%387CFE780392.preface preserve=yes
//## end TotalsProcessor%387CFE780392.preface

//## Class: TotalsProcessor%387CFE780392; private
//	<body>
//	<title>CG
//	<h1>TP
//	<h2>AB
//	<h3>Reconciliation
//	<!-- TotalsProcessor : General -->
//	<p>
//	DataNavigator for Merchant Services provides acquirer
//	reconciliation for Discover, MasterCard and VISA and
//	debit activity.
//	The following reports are imported for reconciliation:
//	<ul>
//	<li><a href="American Express TILR.html">American
//	Express TILR</a>
//	<li><a href="Discover Acquirer Report
//	Interface.html">Discover Acquirer Report Interface</a>
//	<li><a href="MasterCard IPM Files.html">MasterCard IPM
//	Files</a>
//	<li><a href="VISA VSS Reports.html">VISA VSS Reports</a>
//	<li><a href="VISA EP-110C VISANET Edit Package Outgoing
//	Interchange File Summary.html">VISA EP-110C VISANET Edit
//	Package Outgoing Interchange File Summary</a>
//	</ul>
//	Reconciliation of these reports is dependent on:
//	<ul>
//	<li><a href="Acquirer Bank Reconciliation
//	Totals.html">Acquirer Bank Reconciliation Totals</a>
//	</ul>
//	<h4>Automatic Aging
//	<p>
//	Settlement, MIS and ATM totals are automatically aged by
//	the DataNavigator server.
//	By default, settlement, daily MIS and hourly MIS totals
//	are retained for 180 days.
//	Yearly and monthly MIS totals are retained for 2 years.
//	ATM totals are retained for 30 days.
//	The Totals Processor service ages data automatically at
//	midnight each day.
//	<h3>System Flow
//	<p>
//	The Totals Processor service removes the oldest rows
//	from the following tables:
//	<ul>
//	<li>Settlement (T_FIN_TOTAL, T_FIN_E_GROUP_ITEM, T_FIN_
//	ENTITY_GROUP, T_FIN_PERIOD)
//	<li>MIS (T_MIS_TOTAL)
//	<li>ATM (T_ATM_EVENT, T_ATM_ACTIVITY)
//	</ul>
//	<p>
//	<img src=CXOCTP00.gif>
//	</body>
//## Category: Totals Management::TotalsProcessor_CAT%387CFE11005E
//## Subsystem: TP%387CFF980269
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%387E56DF0024;settlement::Compactor { -> F}
//## Uses: <unnamed>%387E5F5E032F;database::Database { -> F}
//## Uses: <unnamed>%387E5F6100B2;IF::Message { -> F}
//## Uses: <unnamed>%3CDA761C03A9;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%415DA0A50000;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%4161A35B034B;monitor::UseCase { -> F}
//## Uses: <unnamed>%4FA7B80C014A;settlement::LiabilityManager { -> F}
//## Uses: <unnamed>%562643400370;IF::Extract { -> F}
//## Uses: <unnamed>%562644390104;database::GenericDelete { -> F}
//## Uses: <unnamed>%562645BC0250;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%56320D4B014A;database::CRTransactionTypeIndicator { -> F}
//## Uses: <unnamed>%567AC7B60007;networkreconciliation::TotalType { -> F}
//## Uses: <unnamed>%573C69910032;networkreconciliation::MasterCardIPMTemplate { -> F}
//## Uses: <unnamed>%5CA39F61039D;settlement::TotalsAging1 { -> F}
//## Uses: <unnamed>%5CA39F6402FB;settlement::TotalsAging2 { -> F}
//## Uses: <unnamed>%5CC06753035E;entitysegment::Customer { -> F}
//## Uses: <unnamed>%5D65F1E4025E;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%60CB586A0354;networkreconciliation::NetworkReport { -> F}
//## Uses: <unnamed>%60CB586D02B6;networkreconciliation::NetworkFile { -> F}
//## Uses: <unnamed>%62FF5B13034A;settlement::TokenAging { -> F}

class TotalsProcessor : public process::Application  //## Inherits: <unnamed>%387CFF6D0394
{
  //## begin TotalsProcessor%387CFE780392.initialDeclarations preserve=yes
  //## end TotalsProcessor%387CFE780392.initialDeclarations

  public:
    //## Constructors (generated)
      TotalsProcessor();

    //## Destructor (generated)
      virtual ~TotalsProcessor();


    //## Other Operations (specified)
      //## Operation: initialize%387D03FC0388
      virtual int initialize ();

      //## Operation: update%38B2B8B80273
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin TotalsProcessor%387CFE780392.public preserve=yes
      //## end TotalsProcessor%387CFE780392.public

  protected:

    //## Other Operations (specified)
      //## Operation: onReset%387D040D006B
      virtual int onReset (Message& hMessage);

      //## Operation: onResume%5D65EDD5004A
      virtual int onResume (Message& hMessage);

    // Additional Protected Declarations
      //## begin TotalsProcessor%387CFE780392.protected preserve=yes
      //## end TotalsProcessor%387CFE780392.protected

  private:
    // Additional Private Declarations
      //## begin TotalsProcessor%387CFE780392.private preserve=yes
      //## end TotalsProcessor%387CFE780392.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Totals Management::TotalsProcessor_CAT::<unnamed>%57696A6901C4
      //## Role: TotalsProcessor::<m_pMASCharges>%57696A6A0179
      //## begin TotalsProcessor::<m_pMASCharges>%57696A6A0179.role preserve=no  public: networkreconciliation::MASCharges { -> RFHgN}
      networkreconciliation::MASCharges *m_pMASCharges;
      //## end TotalsProcessor::<m_pMASCharges>%57696A6A0179.role

      //## Association: Totals Management::TotalsProcessor_CAT::<unnamed>%5C50AFAF0144
      //## Role: TotalsProcessor::<m_hATMMediator>%5C50AFB0014D
      //## begin TotalsProcessor::<m_hATMMediator>%5C50AFB0014D.role preserve=no  public: atm::ATMMediator { -> VHgN}
      atm::ATMMediator m_hATMMediator;
      //## end TotalsProcessor::<m_hATMMediator>%5C50AFB0014D.role

      //## Association: Totals Management::TotalsProcessor_CAT::<unnamed>%62FF5992025A
      //## Role: TotalsProcessor::<m_pMISAging>%62FF59930202
      //## begin TotalsProcessor::<m_pMISAging>%62FF59930202.role preserve=no  public: settlement::MISAging { -> RFHgN}
      settlement::MISAging *m_pMISAging;
      //## end TotalsProcessor::<m_pMISAging>%62FF59930202.role

    // Additional Implementation Declarations
      //## begin TotalsProcessor%387CFE780392.implementation preserve=yes
      //## end TotalsProcessor%387CFE780392.implementation

};

//## begin TotalsProcessor%387CFE780392.postscript preserve=yes
//## end TotalsProcessor%387CFE780392.postscript

//## begin module%387CFFBE034A.epilog preserve=yes
//## end module%387CFFBE034A.epilog


#endif
