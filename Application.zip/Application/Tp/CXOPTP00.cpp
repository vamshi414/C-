//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%387CFFC0018A.cm preserve=no
//## end module%387CFFC0018A.cm

//## begin module%387CFFC0018A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%387CFFC0018A.cp

//## Module: CXOPTP00%387CFFC0018A; Package body
//## Subsystem: TP%387CFF980269
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Tp\CXOPTP00.cpp

//## begin module%387CFFC0018A.additionalIncludes preserve=no
//## end module%387CFFC0018A.additionalIncludes

//## begin module%387CFFC0018A.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#include "CXODAT13.hpp"
#include "CXODTC66.hpp"
#include "CXODNS44.hpp"
#include "CXODNS45.hpp"
#ifndef CXOSST88_h
#include "CXODST88.hpp"
#endif
#include "CXODNS49.hpp"
//## end module%387CFFC0018A.includes

#ifndef CXOSST17_h
#include "CXODST17.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSST50_h
#include "CXODST50.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDB22_h
#include "CXODDB22.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSDB16_h
#include "CXODDB16.hpp"
#endif
#ifndef CXOSNR12_h
#include "CXODNR12.hpp"
#endif
#ifndef CXOSNR04_h
#include "CXODNR04.hpp"
#endif
#ifndef CXOSST74_h
#include "CXODST74.hpp"
#endif
#ifndef CXOSST75_h
#include "CXODST75.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSNR07_h
#include "CXODNR07.hpp"
#endif
#ifndef CXOSNR01_h
#include "CXODNR01.hpp"
#endif
#ifndef CXOSST85_h
#include "CXODST85.hpp"
#endif
#ifndef CXOSNR32_h
#include "CXODNR32.hpp"
#endif
#ifndef CXOSST38_h
#include "CXODST38.hpp"
#endif
#ifndef CXOPTP00_h
#include "CXODTP00.hpp"
#endif


//## begin module%387CFFC0018A.declarations preserve=no
//## end module%387CFFC0018A.declarations

//## begin module%387CFFC0018A.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new TotalsProcessor();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%387CFFC0018A.additionalDeclarations


// Class TotalsProcessor 

TotalsProcessor::TotalsProcessor()
  //## begin TotalsProcessor::TotalsProcessor%387CFE780392_const.hasinit preserve=no
      : m_pMASCharges(0),
        m_pMISAging(0)
  //## end TotalsProcessor::TotalsProcessor%387CFE780392_const.hasinit
  //## begin TotalsProcessor::TotalsProcessor%387CFE780392_const.initialization preserve=yes
  //## end TotalsProcessor::TotalsProcessor%387CFE780392_const.initialization
{
  //## begin TotalsProcessor::TotalsProcessor%387CFE780392_const.body preserve=yes
   memcpy(m_sID,"TP00",4);
  //## end TotalsProcessor::TotalsProcessor%387CFE780392_const.body
}


TotalsProcessor::~TotalsProcessor()
{
  //## begin TotalsProcessor::~TotalsProcessor%387CFE780392_dest.body preserve=yes
   delete m_pMASCharges;
   delete m_pMISAging;
  //## end TotalsProcessor::~TotalsProcessor%387CFE780392_dest.body
}



//## Other Operations (implementation)
int TotalsProcessor::initialize ()
{
  //## begin TotalsProcessor::initialize%387D03FC0388.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("TOTALS","## TP00 START TP");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   string strRecord;
   bool b = false;
   if (IF::Extract::instance()->getRecord("DFILES  NETFLE  ",strRecord))
   {
      networkreconciliation::NetworkFile::instance();
      b = true;
   }
   if (IF::Extract::instance()->getRecord("DFILES  NETRPT  ", strRecord))
   {
      networkreconciliation::NetworkReport::instance();
      b = true;
   }
   if (IF::Extract::instance()->getRecord("DFILES  MASCHG  ", strRecord))
      m_pMASCharges = new networkreconciliation::MASCharges;
   if (b
      || m_pMASCharges)
      networkreconciliation::TotalType::instance();
   database::CRTransactionTypeIndicator::instance();
   entitysegment::Customer::instance();
   entitysegment::ProcessorGroup::instance();
   entitysegment::Processor::instance();
   entitysegment::Institution::instance();
   entitysegment::SwitchBusinessDay::instance();
   atm::TerminalSet::instance();
   int i = atoi(name().c_str() + 4);
   if (i == 0)
   {
      settlement::LiabilityManager::instance();
      m_pMISAging = new MISAging();
      Database::instance()->attach(m_pMISAging);
   }
   Database::instance()->connect();
   TotalsVersionMonitor::instance();
   if (i == 0)
   {
      if (entitysegment::Customer::instance()->getTotalsVersion() == 1)
         new TotalsAging1;
      else
      {
         new TotalsAging2;
         new totalscommand::FinancialSum;
      }
      if (Extract::instance()->getCustomCode() == "MPS")
         Compactor::instance();
      if (Extract::instance()->getCustomCode() == "FIS")
         new TokenAging;
      MidnightAlarm::instance()->attach(this);
      update(0);
   }
   m_hATMMediator.reset(false,i == 0);
   return Database::instance()->commit();
  //## end TotalsProcessor::initialize%387D03FC0388.body
}

int TotalsProcessor::onReset (Message& hMessage)
{
  //## begin TotalsProcessor::onReset%387D040D006B.body preserve=yes
   if (memcmp((char*)hMessage.context(),"EXPORT",6) == 0)
   {
      if (memcmp((char*)hMessage.context() + 8, "DIS", 3) == 0)
         ;
      else
         if (memcmp((char*)hMessage.context() + 8, "MCI", 3) == 0)
         {
            networkreconciliation::MasterCardIPMTemplate x;;
            x.deport();
         }
         else
            if (memcmp((char*)hMessage.context() + 8, "VNT", 3) == 0)
               ;
   }
   return Database::instance()->commit();
  //## end TotalsProcessor::onReset%387D040D006B.body
}

int TotalsProcessor::onResume (Message& hMessage)
{
  //## begin TotalsProcessor::onResume%5D65EDD5004A.body preserve=yes
   m_hATMMediator.update(MinuteTimer::instance());
   return 0;
  //## end TotalsProcessor::onResume%5D65EDD5004A.body
}

void TotalsProcessor::update (Subject* pSubject)
{
  //## begin TotalsProcessor::update%38B2B8B80273.body preserve=yes
   if (pSubject == MidnightAlarm::instance() 
      || pSubject == 0)
   {
      int iMinimumRetentionDays = 730;
      Extract::instance()->getLong("DUSER   ","EMSPHSTDAYS=",&iMinimumRetentionDays);
      GenericDelete hGenericDelete("T_EMS_PHASE_TOTAL","PHASE_DATE",false,iMinimumRetentionDays);
      hGenericDelete.deleteRecords("PHASE_DATE",iMinimumRetentionDays);
      if (pSubject == 0)
         return;
   }
   Application::update(pSubject);
  //## end TotalsProcessor::update%38B2B8B80273.body
}

// Additional Declarations
  //## begin TotalsProcessor%387CFE780392.declarations preserve=yes
  //## end TotalsProcessor%387CFE780392.declarations

//## begin module%387CFFC0018A.epilog preserve=yes
//## end module%387CFFC0018A.epilog
