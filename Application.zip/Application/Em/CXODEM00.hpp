//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35745A7A00F5.cm preserve=no
//## end module%35745A7A00F5.cm

//## begin module%35745A7A00F5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%35745A7A00F5.cp

//## Module: CXOPEM00%35745A7A00F5; Package specification
//## Subsystem: EM%35745A050364
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Em\CXODEM00.hpp

#ifndef CXOPEM00_h
#define CXOPEM00_h 1

//## begin module%35745A7A00F5.additionalIncludes preserve=no
//## end module%35745A7A00F5.additionalIncludes

//## begin module%35745A7A00F5.includes preserve=yes
// $Date:   Oct 26 2021 04:55:08  $ $Author:   e5614616  $ $Revision:   1.74.1.0  $
//## end module%35745A7A00F5.includes

#ifndef CXOSPS03_h
#include "CXODPS03.hpp"
#endif
#ifndef CXOSPC01_h
#include "CXODPC01.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
class CaseUpdateCommand;
class CaseCreateCommand;
} // namespace emscommand

//## Modelname: DataNavigator Foundation::Partition_CAT%346B9162029B
namespace partition {
class PartitionAllocator;
} // namespace partition

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseAccountHistorySegment;
class CaseShazamSegment;
class CasePhaseAccelSegment;
class CaseEFTPosSegment;
class CasePhaseEFTPosSegment;
} // namespace emssegment

//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
class ArchiveRetriever;
} // namespace archive

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class FeeTableFactory;
} // namespace switchinterface

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class ActionFactory;
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class DataControl;
} // namespace database

//## Modelname: Connex Library::Rules_CAT (RLDLL)%3EB810F40157
namespace rules {
class FunctionFactory;
} // namespace rules

//## Modelname: Platform \: Regions::RegionsAPI%49C79DB0002E
namespace regionsapi {
class ProvisionalCredit;

} // namespace regionsapi

//## begin module%35745A7A00F5.declarations preserve=no
//## end module%35745A7A00F5.declarations

//## begin module%35745A7A00F5.additionalDeclarations preserve=yes
//## end module%35745A7A00F5.additionalDeclarations


//## begin ExceptionManager%357450E801F6.preface preserve=yes
//## end ExceptionManager%357450E801F6.preface

//## Class: ExceptionManager%357450E801F6
//	<body>
//	<title>CG
//	<h1>EM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server provides rules based case
//	management for transaction exception items to end users.
//	<p>
//	The Exception Manager service (<i>ca</i>EMS) adds and
//	updates cases for end users.
//	Requests come through the Client Interface service
//	(<i>ca</i>CI01).
//	</p>
//	<img src=CXOCEM00.gif>
//	<p>
//	Refer to the various <i>DataNavigator Client Exception
//	Management User's Guides</i> for more information.
//	</p>
//	</body>
//	<body>
//	<title>OG
//	<h1>EM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server provides rules based case
//	management for transaction exception items to end users.
//	<p>
//	<img src=CXOOEM00.gif>
//	</p>
//	<h2>TS
//	<h3>DataNavigator Client
//	<p>
//	<b>Issue:</b>  End user reporting problems with services
//	provided by Exception Manager.
//	<p>
//	<b>Resolution:</b>  Refer to the Troubleshooting tips
//	for the Client Interface in the <i>DataNavigator Server
//	Operations Guide: Foundation</i> manual.
//	</p>
//	</body>
//## Category: Transaction Research and Adjustments::ExceptionManager_CAT%35745074002D
//## Subsystem: EM%35745A050364
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..1



//## Uses: attach%35A23F2B009B;IF::Queue { -> F}
//## Uses: <unnamed>%35A23F2E00BE;IF::Message { -> F}
//## Uses: <unnamed>%362DEB4402F6;reusable::Transaction { -> F}
//## Uses: connect%36DEEE92023A;database::Database { -> F}
//## Uses: <unnamed>%373B39130351;emssegment::CaseCashStationSegment { -> F}
//## Uses: <unnamed>%373B39170053;emssegment::CaseCirrusSegment { -> F}
//## Uses: <unnamed>%373B391B035C;emssegment::CaseHonorSegment { -> F}
//## Uses: <unnamed>%373B39250339;emssegment::CaseTransitionSegment { -> F}
//## Uses: <unnamed>%373B392A0097;emssegment::CaseInterlinkSegment { -> F}
//## Uses: <unnamed>%373B392D0164;emssegment::CaseNyceSegment { -> F}
//## Uses: <unnamed>%373B3934034E;emssegment::CasePhaseCashStationSegment { -> F}
//## Uses: <unnamed>%373B39AC02B1;emssegment::CasePhaseNyceSegment { -> F}
//## Uses: <unnamed>%373B39B00086;emssegment::CaseVisaSegment { -> F}
//## Uses: <unnamed>%373B39B301AC;emssegment::CasePhasePulseSegment { -> F}
//## Uses: <unnamed>%373B39B6016B;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%373B39B90101;emssegment::CasePhaseVisaSegment { -> F}
//## Uses: <unnamed>%373B39BC00A1;emssegment::CasePlusSegment { -> F}
//## Uses: <unnamed>%373B39BE03D9;emssegment::CasePulseSegment { -> F}
//## Uses: <unnamed>%373B39C200B4;emssegment::CaseStarSegment { -> F}
//## Uses: <unnamed>%373C3C8602F4;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%3740669A0128;emssegment::CaseAffnSegment { -> F}
//## Uses: <unnamed>%3740669D02BD;emssegment::CasePhaseAffnSegment { -> F}
//## Uses: <unnamed>%374315F200D9;ems::Case { -> F}
//## Uses: <unnamed>%3745B7A60267;emssegment::CasePhaseStarSegment { -> F}
//## Uses: <unnamed>%37CBC40F00CF;emssegment::CasePhaseMacSegment { -> F}
//## Uses: <unnamed>%37CBC41103DF;emssegment::CaseMacSegment { -> F}
//## Uses: <unnamed>%38594E050187;emssegment::CasePhaseCirrusSegment { -> F}
//## Uses: <unnamed>%39254403017A;emssegment::CasePhaseAustraliaSegment { -> F}
//## Uses: <unnamed>%3A008B0200FE;monitor::UseCase { -> F}
//## Uses: <unnamed>%3AC270910005;emssegment::CasePhaseInterlinkSegment { -> F}
//## Uses: <unnamed>%3AC270F40044;timer::Clock { -> F}
//## Uses: <unnamed>%3BCED60B036B;IF::Extract { -> F}
//## Uses: <unnamed>%3C4739AE034C;IF::EMailMessage { -> F}
//## Uses: <unnamed>%3CB599100390;emssegment::CaseAustraliaSegment { -> F}
//## Uses: <unnamed>%3E771EDB034B;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%40AA406300BB;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%4435F0BD030D;database::DataControl { -> F}
//## Uses: <unnamed>%44C77FD20225;partition::PartitionAllocator { -> F}
//## Uses: <unnamed>%44C7801D038F;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%47D4D3590270;archive::ArchiveRetriever { -> F}
//## Uses: <unnamed>%49C7D8970177;regionsapi::ProvisionalCredit { -> F}
//## Uses: <unnamed>%49DCFBF3032C;emssegment::CaseAccountHistorySegment { -> F}
//## Uses: <unnamed>%49E380EE030D;dnplatform::ActionFactory { -> F}
//## Uses: <unnamed>%49E38102005D;rules::FunctionFactory { -> F}
//## Uses: <unnamed>%5898DEC70327;emssegment::CasePhaseAccelSegment { -> F}
//## Uses: <unnamed>%5A9524000354;emssegment::CaseShazamSegment { -> F}
//## Uses: <unnamed>%61D6F37E013E;emssegment::CaseEFTPosSegment { -> F}
//## Uses: <unnamed>%61D6F394039D;emssegment::CasePhaseEFTPosSegment { -> F}
//## Uses: <unnamed>%64FE027802F0;switchinterface::FeeTableFactory { -> F}

class ExceptionManager : public process::ServiceApplication  //## Inherits: <unnamed>%3BCED23E0157
{
  //## begin ExceptionManager%357450E801F6.initialDeclarations preserve=yes
  //## end ExceptionManager%357450E801F6.initialDeclarations

  public:
    //## Constructors (generated)
      ExceptionManager();

    //## Destructor (generated)
      virtual ~ExceptionManager();


    //## Other Operations (specified)
      //## Operation: initialize%35745616026B
      int initialize ();

      //## Operation: update%37AF01AE02CC
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin ExceptionManager%357450E801F6.public preserve=yes
      //## end ExceptionManager%357450E801F6.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%3574561A000E
      int onMessage (Message& hMessage);

      //## Operation: onReset%3E9FDC27036B
      virtual int onReset (Message& hMessage);

    // Additional Protected Declarations
      //## begin ExceptionManager%357450E801F6.protected preserve=yes
      //## end ExceptionManager%357450E801F6.protected

  private:
    // Additional Private Declarations
      //## begin ExceptionManager%357450E801F6.private preserve=yes
      //## end ExceptionManager%357450E801F6.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::ExceptionManager_CAT::execute%35ACBE9D021A
      //## Role: ExceptionManager::<m_pCaseUpdateCommand>%35ACBE9F008C
      //## begin ExceptionManager::<m_pCaseUpdateCommand>%35ACBE9F008C.role preserve=no  public: emscommand::CaseUpdateCommand { -> RFHgN}
      emscommand::CaseUpdateCommand *m_pCaseUpdateCommand;
      //## end ExceptionManager::<m_pCaseUpdateCommand>%35ACBE9F008C.role

      //## Association: Transaction Research and Adjustments::ExceptionManager_CAT::<unnamed>%44C77B5F0193
      //## Role: ExceptionManager::<m_pPartitionControl>%44C77B60004B
      //## begin ExceptionManager::<m_pPartitionControl>%44C77B60004B.role preserve=no  public: partition::PartitionControl { -> RHgN}
      partition::PartitionControl *m_pPartitionControl;
      //## end ExceptionManager::<m_pPartitionControl>%44C77B60004B.role

      //## Association: Transaction Research and Adjustments::ExceptionManager_CAT::<unnamed>%4E08C288031E
      //## Role: ExceptionManager::<m_pCaseCreateCommand>%4E08C28901B7
      //## begin ExceptionManager::<m_pCaseCreateCommand>%4E08C28901B7.role preserve=no  public: emscommand::CaseCreateCommand { -> RFHgN}
      emscommand::CaseCreateCommand *m_pCaseCreateCommand;
      //## end ExceptionManager::<m_pCaseCreateCommand>%4E08C28901B7.role

    // Additional Implementation Declarations
      //## begin ExceptionManager%357450E801F6.implementation preserve=yes
	  emscommand::AuthorizationFlagCommand* m_pAuthorizationFlagCommand;
      //## end ExceptionManager%357450E801F6.implementation
};

//## begin ExceptionManager%357450E801F6.postscript preserve=yes
//## end ExceptionManager%357450E801F6.postscript

//## begin module%35745A7A00F5.epilog preserve=yes
//## end module%35745A7A00F5.epilog


#endif
