//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%35745A7F02F1.cm preserve=no
//## end module%35745A7F02F1.cm

//## begin module%35745A7F02F1.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%35745A7F02F1.cp

//## Module: CXOPEM00%35745A7F02F1; Package body
//## Subsystem: EM%35745A050364
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Em\CXOPEM00.cpp

//## begin module%35745A7F02F1.additionalIncludes preserve=no
//## end module%35745A7F02F1.additionalIncludes

//## begin module%35745A7F02F1.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),ENVAR('TASK=EM'))
#endif
#include "CXODPF01.hpp"
#include "CXODTM03.hpp"
#include "CXODNS29.hpp"
#include "CXODEC29.hpp"
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
#include "CXODDB16.hpp"
#include "CXODDB50.hpp"
#include "CXODDZ06.hpp"
#include "CXODES95.hpp"
#include "CXODDZ04.hpp"
#include "CXODDZ03.hpp"
//## end module%35745A7F02F1.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSDB27_h
#include "CXODDB27.hpp"
#endif
#ifndef CXOSPC03_h
#include "CXODPC03.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSAR03_h
#include "CXODAR03.hpp"
#endif
#ifndef CXOSRA02_h
#include "CXODRA02.hpp"
#endif
#ifndef CXOSES45_h
#include "CXODES45.hpp"
#endif
#ifndef CXOSDZ02_h
#include "CXODDZ02.hpp"
#endif
#ifndef CXOSRL17_h
#include "CXODRL17.hpp"
#endif
#ifndef CXOSES81_h
#include "CXODES81.hpp"
#endif
#ifndef CXOSES87_h
#include "CXODES87.hpp"
#endif
#ifndef CXOSES97_h
#include "CXODES97.hpp"
#endif
#ifndef CXOSES98_h
#include "CXODES98.hpp"
#endif
#ifndef CXOSSI09_h
#include "CXODSI09.hpp"
#endif
#ifndef CXOSEC02_h
#include "CXODEC02.hpp"
#endif
#ifndef CXOSEC01_h
#include "CXODEC01.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSES08_h
#include "CXODES08.hpp"
#endif
#ifndef CXOSES09_h
#include "CXODES09.hpp"
#endif
#ifndef CXOSES10_h
#include "CXODES10.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSES11_h
#include "CXODES11.hpp"
#endif
#ifndef CXOSES13_h
#include "CXODES13.hpp"
#endif
#ifndef CXOSES21_h
#include "CXODES21.hpp"
#endif
#ifndef CXOSES24_h
#include "CXODES24.hpp"
#endif
#ifndef CXOSES17_h
#include "CXODES17.hpp"
#endif
#ifndef CXOSES25_h
#include "CXODES25.hpp"
#endif
#ifndef CXOSES18_h
#include "CXODES18.hpp"
#endif
#ifndef CXOSES27_h
#include "CXODES27.hpp"
#endif
#ifndef CXOSES14_h
#include "CXODES14.hpp"
#endif
#ifndef CXOSES15_h
#include "CXODES15.hpp"
#endif
#ifndef CXOSES16_h
#include "CXODES16.hpp"
#endif
#ifndef CXOSES01_h
#include "CXODES01.hpp"
#endif
#ifndef CXOSES06_h
#include "CXODES06.hpp"
#endif
#ifndef CXOSES19_h
#include "CXODES19.hpp"
#endif
#ifndef CXOSEX01_h
#include "CXODEX01.hpp"
#endif
#ifndef CXOSES26_h
#include "CXODES26.hpp"
#endif
#ifndef CXOSES23_h
#include "CXODES23.hpp"
#endif
#ifndef CXOSES12_h
#include "CXODES12.hpp"
#endif
#ifndef CXOSES22_h
#include "CXODES22.hpp"
#endif
#ifndef CXOSES20_h
#include "CXODES20.hpp"
#endif
#ifndef CXOSES30_h
#include "CXODES30.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF36_h
#include "CXODIF36.hpp"
#endif
#ifndef CXOSES07_h
#include "CXODES07.hpp"
#endif
#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOPEM00_h
#include "CXODEM00.hpp"
#endif


//## begin module%35745A7F02F1.declarations preserve=no
//## end module%35745A7F02F1.declarations

//## begin module%35745A7F02F1.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new ExceptionManager();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%35745A7F02F1.additionalDeclarations


// Class ExceptionManager 

ExceptionManager::ExceptionManager()
  //## begin ExceptionManager::ExceptionManager%357450E801F6_const.hasinit preserve=no
      : m_pCaseUpdateCommand(0),
        m_pPartitionControl(0),
        m_pCaseCreateCommand(0)
  //## end ExceptionManager::ExceptionManager%357450E801F6_const.hasinit
  //## begin ExceptionManager::ExceptionManager%357450E801F6_const.initialization preserve=yes
     ,m_pAuthorizationFlagCommand(0)
  //## end ExceptionManager::ExceptionManager%357450E801F6_const.initialization
{
  //## begin ExceptionManager::ExceptionManager%357450E801F6_const.body preserve=yes
   memcpy(m_sID,"EM00",4);
  //## end ExceptionManager::ExceptionManager%357450E801F6_const.body
}


ExceptionManager::~ExceptionManager()
{
  //## begin ExceptionManager::~ExceptionManager%357450E801F6_dest.body preserve=yes
   delete m_pCaseCreateCommand;
   delete m_pCaseUpdateCommand;
   delete m_pAuthorizationFlagCommand;
   delete Case::instance();
   delete EMSRulesEngine::instance();
   delete CaseSegment::instance();
   delete CaseAccelSegment::instance();
   delete CaseAffnSegment::instance();
   delete CaseAustraliaSegment::instance();
   delete CaseCashStationSegment::instance();
   delete CaseCirrusSegment::instance();
   delete CaseHonorSegment::instance();
   delete CaseInterlinkSegment::instance();
   delete CaseMacSegment::instance();
   delete CaseNyceSegment::instance();
   delete CasePlusSegment::instance();
   delete CasePulseSegment::instance();
   delete CaseStarSegment::instance();
   delete CaseVisaSegment::instance();
   delete CaseShazamSegment::instance();
   delete CasePhaseSegment::instance();
   delete CasePhaseAccelSegment::instance();
   delete CasePhaseAffnSegment::instance();
   delete CasePhaseAustraliaSegment::instance();
   delete CasePhaseCashStationSegment::instance();
   delete CasePhaseCirrusSegment::instance();
   delete CasePhaseInterlinkSegment::instance();
   delete CasePhaseMacSegment::instance();
   delete CasePhaseNyceSegment::instance();
   delete CasePhasePulseSegment::instance();
   delete CasePhaseStarSegment::instance();
   delete CasePhaseVisaSegment::instance();
   delete CaseTransitionSegment::instance();
   delete EMailMessage::instance();
   delete m_pPartitionControl;
   delete FunctionFactory::instance();
   delete CaseEFTPosSegment::instance();
   delete CasePhaseEFTPosSegment::instance();
  //## end ExceptionManager::~ExceptionManager%357450E801F6_dest.body
}



//## Other Operations (implementation)
int ExceptionManager::initialize ()
{
  //## begin ExceptionManager::initialize%35745616026B.body preserve=yes
   new dnplatform::DNPlatform();
   new segment::AuditEvent;
   int iRC = ServiceApplication::initialize();
   UseCase hUseCase("CLIENT","## CL15 START EMS");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   database::DataModel::instance();
   database::CRTransactionTypeIndicator::instance();
   Customer::instance();
   new dnplatform::NetworkFactory();
   new dnplatform::ExceptionFactory();
   new PostingFileFactory();
   PostingFileFactory::instance()->setDailyFiles("('ECOUT','ECHIST')");
   Database::instance()->attach(this);
   m_pAuthorizationFlagCommand = new AuthorizationFlagCommand(0);
   m_pCaseCreateCommand = new CaseCreateCommand(m_pAuthorizationFlagCommand);
   m_pCaseUpdateCommand = new CaseUpdateCommand(m_pCaseCreateCommand);
   FeeTableFactory::instance()->create();
   Database::instance()->connect();
   m_pPartitionControl = new PartitionControl((PartitionAllocator*)DatabaseFactory::instance()->create("PartitionAllocator"));
   string strCustomer;
   Extract::instance()->getSpec("CUSTOMER",strCustomer);
   Transaction::instance()->setCustomer(strCustomer);
   Case::instance();
   EMSRulesEngine::instance();
   DataControl::instance();
   new ActionFactory();
   new dnplatform::APIExportFactory();
   return 0;
  //## end ExceptionManager::initialize%35745616026B.body
}

int ExceptionManager::onMessage (Message& hMessage)
{
  //## begin ExceptionManager::onMessage%3574561A000E.body preserve=yes
   if (hMessage.messageID() != "S0003D"
      && hMessage.messageID() != "S0003R"
      && hMessage.messageID() != "S0004D")
      return 0;
   Transaction::instance()->begin();
   Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   EMSRulesEngine::instance()->reset();
   m_pCaseUpdateCommand->update(Message::instance(Message::INBOUND));
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      Database::instance()->rollback();
   else
      Database::instance()->commit();
   Transaction::instance()->commit();
   idle();
   return 0;
  //## end ExceptionManager::onMessage%3574561A000E.body
}

int ExceptionManager::onReset (Message& hMessage)
{
  //## begin ExceptionManager::onReset%3E9FDC27036B.body preserve=yes
   return 0;
  //## end ExceptionManager::onReset%3E9FDC27036B.body
}

void ExceptionManager::update (Subject* pSubject)
{
  //## begin ExceptionManager::update%37AF01AE02CC.body preserve=yes
   if (pSubject == Database::instance())
   {
      if (Database::instance()->state() == Database::CONNECTED)
         Queue::attach("@##SERVER",Queue::CX_DISTRIBUTION_QUEUE);
      return;
   }
   ServiceApplication::update(pSubject);
  //## end ExceptionManager::update%37AF01AE02CC.body
}

// Additional Declarations
  //## begin ExceptionManager%357450E801F6.declarations preserve=yes
  //## end ExceptionManager%357450E801F6.declarations

//## begin module%35745A7F02F1.epilog preserve=yes
//## end module%35745A7F02F1.epilog
