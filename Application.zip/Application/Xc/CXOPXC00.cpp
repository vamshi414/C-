//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%392002970259.cm preserve=no
//	$Date:   Jul 26 2013 10:26:30  $ $Author:   e1009652  $
//	$Revision:   1.20  $
//## end module%392002970259.cm

//## begin module%392002970259.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%392002970259.cp

//## Module: CXOPXC00%392002970259; Package body
//## Subsystem: XC%3920003B0002
//## Source file: C:\Devel\Dn\Server\Application\XC\CXOPXC00.cpp

//## begin module%392002970259.additionalIncludes preserve=no
//## end module%392002970259.additionalIncludes

//## begin module%392002970259.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#include "CXODRU24.hpp"
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
//## end module%392002970259.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSNC01_h
#include "CXODNC01.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOPXC00_h
#include "CXODXC00.hpp"
#endif


//## begin module%392002970259.declarations preserve=no
//## end module%392002970259.declarations

//## begin module%392002970259.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new ExternalCRReader();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%392002970259.additionalDeclarations


// Class ExternalCRReader 

ExternalCRReader::ExternalCRReader()
  //## begin ExternalCRReader::ExternalCRReader%392000910024_const.hasinit preserve=no
  //## end ExternalCRReader::ExternalCRReader%392000910024_const.hasinit
  //## begin ExternalCRReader::ExternalCRReader%392000910024_const.initialization preserve=yes
  :m_hCRFile("CED")
  //## end ExternalCRReader::ExternalCRReader%392000910024_const.initialization
{
  //## begin ExternalCRReader::ExternalCRReader%392000910024_const.body preserve=yes
   memcpy(m_sID,"XC00",4);
  //## end ExternalCRReader::ExternalCRReader%392000910024_const.body
}


ExternalCRReader::~ExternalCRReader()
{
  //## begin ExternalCRReader::~ExternalCRReader%392000910024_dest.body preserve=yes
  //## end ExternalCRReader::~ExternalCRReader%392000910024_dest.body
}



//## Other Operations (implementation)
int ExternalCRReader::initialize ()
{
  //## begin ExternalCRReader::initialize%39200E1C00AB.body preserve=yes
   new dnplatform::DNPlatform();
   new segment::AuditEvent;
   int i = Application::initialize();
   UseCase hUseCase("EXTERNAL","## EX01 START XC");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   CRUpdateCommand::instance();
   Database::instance()->connect();
   return 0;
  //## end ExternalCRReader::initialize%39200E1C00AB.body
}

int ExternalCRReader::onReset (IF::Message& hMessage)
{
  //## begin ExternalCRReader::onReset%39200E27007F.body preserve=yes
   UseCase hUseCase("EXTERNAL","## EX02 RESET XC");
   m_hCRFile.process();
   return 0;
  //## end ExternalCRReader::onReset%39200E27007F.body
}

// Additional Declarations
  //## begin ExternalCRReader%392000910024.declarations preserve=yes
  //## end ExternalCRReader%392000910024.declarations

//## begin module%392002970259.epilog preserve=yes
//## end module%392002970259.epilog
