//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%392002940241.cm preserve=no
//	$Date:   Dec 13 2011 09:35:18  $ $Author:   e1009839  $
//	$Revision:   1.15  $
//## end module%392002940241.cm

//## begin module%392002940241.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%392002940241.cp

//## Module: CXOPXC00%392002940241; Package specification
//## Subsystem: XC%3920003B0002
//## Source file: C:\Devel\Dn\Server\Application\XC\CXODXC00.hpp

#ifndef CXOPXC00_h
#define CXOPXC00_h 1

//## begin module%392002940241.additionalIncludes preserve=no
//## end module%392002940241.additionalIncludes

//## begin module%392002940241.includes preserve=yes
// $Date:   Dec 13 2011 09:35:18  $ $Author:   e1009839  $ $Revision:   1.15  $
//## end module%392002940241.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSNC19_h
#include "CXODNC19.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntityCommand_CAT%394E2706012A
namespace entitycommand {
class CRUpdateCommand;
} // namespace entitycommand

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%392002940241.declarations preserve=no
//## end module%392002940241.declarations

//## begin module%392002940241.additionalDeclarations preserve=yes
//## end module%392002940241.additionalDeclarations


//## begin ExternalCRReader%392000910024.preface preserve=yes
//## end ExternalCRReader%392000910024.preface

//## Class: ExternalCRReader%392000910024
//	<body>
//	<title>CG
//	<h1>XC
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server requires replicated
//	configuration information from the switch platform
//	database.
//	<p>
//	An extract program must be developed to copy entity
//	information from the switch database (EFT DB) to the
//	generic configuration file (CF).
//	The generic configuration file contains information on
//	the processor groups, processors, reporting levels (e.g.
//	merchants), institutions, devices and PAN masks
//	associated with the switching platform.
//	<p>
//	The generic configuration file (CF) is read by the
//	Generic Configuration Interface (<i>ca</i>CU) to update
//	the DataNavigator Configuration Repository (CR).
//	The extract program should be run following the
//	completion of any related maintenance to the switch
//	database.
//	</p>
//	<img src=CXOCXC00.gif>
//	<h2>FO
//	<h3>Entity Tables
//	<p>
//	The Generic Configuration Interface populates the
//	following tables in the configuration repository:
//	<ul>
//	<li><i>qualify</i>.PROCESSOR_GRP
//	<li><i>qualify</i>.PROCESSOR
//	<li><i>qualify</i>.REPORTING_LVL
//	<li><i>qualify</i>.INSTITUTION
//	<li><i>qualify</i>.DEVICE
//	<li><i>qualify</i>.PAN_MASK
//	</ul>
//	<p>
//	After entities are added by the Generic Configuration
//	Interface, additional manual changes can be made using
//	the CR Client.
//	These tables are in the EFT-Entity Tables folder in the
//	CR Client for the DataNavigator Server.
//	</body>
//	<body>
//	<title>OG
//	<h1>XC
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server requires replicated
//	configuration information from the switch platform
//	database.
//	</p>
//	<img src=CXOOXC00.gif>
//	</body>
//## Category: Platform \: Generic::ExternalCRReader_CAT (XC)%39200005032F
//## Subsystem: XC%3920003B0002
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..1



//## Uses: <unnamed>%3B80F64D003E;monitor::UseCase { -> F}
//## Uses: <unnamed>%3DBA87030290;IF::Message { -> F}
//## Uses: <unnamed>%3DBD34130119;database::Database { -> F}
//## Uses: <unnamed>%3DFDD29A03B9;entitycommand::CRUpdateCommand { -> F}
//## Uses: <unnamed>%40AA67D70169;dnplatform::DNPlatform { -> F}

class ExternalCRReader : public process::Application  //## Inherits: <unnamed>%392001D8027D
{
  //## begin ExternalCRReader%392000910024.initialDeclarations preserve=yes
  //## end ExternalCRReader%392000910024.initialDeclarations

  public:
    //## Constructors (generated)
      ExternalCRReader();

    //## Destructor (generated)
      virtual ~ExternalCRReader();


    //## Other Operations (specified)
      //## Operation: initialize%39200E1C00AB
      virtual int initialize ();

    // Additional Public Declarations
      //## begin ExternalCRReader%392000910024.public preserve=yes
      //## end ExternalCRReader%392000910024.public

  protected:

    //## Other Operations (specified)
      //## Operation: onReset%39200E27007F
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>XC
      //	<h2>CD
      //	<!-- ExternalCRReader::onReset Preconditions -->
      //	<h3>Replicate Configuration
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>CU
      //	<h4>Description
      //	<p>
      //	The switch platform configuration is replicated to the
      //	DataNavigator Configuration Repository
      //	</p>
      //	</body>
      //	<body>
      //	<title>OG
      //	<h1>XC
      //	<h2>CD
      //	<!-- ExternalCRReader::onReset Preconditions -->
      //	<h3>Copy Configuration File to DataNavigator CR
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>CU
      //	<h4>Description
      //	<p>
      //	The Generic Configuration Interface services reads a
      //	configuration file and updates the PROCESSOR,
      //	INSTITUTION, REPORTING_LVL, DEVICE and PAN_MASK tables
      //	in the DataNavigator CR.
      //	</p>
      //	</body>
      virtual int onReset (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin ExternalCRReader%392000910024.protected preserve=yes
      //## end ExternalCRReader%392000910024.protected

  private:
    // Additional Private Declarations
      //## begin ExternalCRReader%392000910024.private preserve=yes
      //## end ExternalCRReader%392000910024.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: Generic::ExternalCRReader_CAT (XC)::<unnamed>%461F762E008A
      //## Role: ExternalCRReader::<m_hCRFile>%461F762E02AD
      //## begin ExternalCRReader::<m_hCRFile>%461F762E02AD.role preserve=no  public: entitycommand::CRFile { -> VHgN}
      entitycommand::CRFile m_hCRFile;
      //## end ExternalCRReader::<m_hCRFile>%461F762E02AD.role

    // Additional Implementation Declarations
      //## begin ExternalCRReader%392000910024.implementation preserve=yes
      //## end ExternalCRReader%392000910024.implementation

};

//## begin ExternalCRReader%392000910024.postscript preserve=yes
//## end ExternalCRReader%392000910024.postscript

//## begin module%392002940241.epilog preserve=yes
//## end module%392002940241.epilog


#endif
