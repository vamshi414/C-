//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A6061B80324.cm preserve=no
//	$Date:   Jun 26 2017 07:46:30  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3A6061B80324.cm

//## begin module%3A6061B80324.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A6061B80324.cp

//## Module: CXOSCI09%3A6061B80324; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI09.hpp

#ifndef CXOSCI09_h
#define CXOSCI09_h 1

//## begin module%3A6061B80324.additionalIncludes preserve=no
//## end module%3A6061B80324.additionalIncludes

//## begin module%3A6061B80324.includes preserve=yes
// $Date:   Jun 26 2017 07:46:30  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3A6061B80324.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

class ClientInterfaceVisitor;

//## begin module%3A6061B80324.declarations preserve=no
//## end module%3A6061B80324.declarations

//## begin module%3A6061B80324.additionalDeclarations preserve=yes
//## end module%3A6061B80324.additionalDeclarations


//## begin Server%3A606173034D.preface preserve=yes
//## end Server%3A606173034D.preface

//## Class: Server%3A606173034D
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3A60716B00CA;ClientInterfaceVisitor { -> F}
//## Uses: <unnamed>%3A659A32000E;timer::Clock { -> F}

class Server : public reusable::Object  //## Inherits: <unnamed>%3A60618E016B
{
  //## begin Server%3A606173034D.initialDeclarations preserve=yes
  //## end Server%3A606173034D.initialDeclarations

  public:
    //## Constructors (generated)
      Server();

      Server(const Server &right);

    //## Destructor (generated)
      virtual ~Server();

    //## Assignment Operation (generated)
      Server & operator=(const Server &right);


    //## Other Operations (specified)
      //## Operation: abort%3A76E4060079
      void abort ();

      //## Operation: accept%3A60716003E5
      void accept (ClientInterfaceVisitor& hClientInterfaceVisitor);

      //## Operation: getProcessTime%3A7094A80079
      int getProcessTime ();

      //## Operation: idle%3A69BD88008D
      void idle ();

      //## Operation: send%3A65940A0206
      bool send (const string& strUserID, const string& strQueueName, const string& strServiceName, Message& hMessage);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Busy%3A60624D01B6
      const bool getBusy () const
      {
        //## begin Server::getBusy%3A60624D01B6.get preserve=no
        return m_bBusy;
        //## end Server::getBusy%3A60624D01B6.get
      }

      void setBusy (bool value)
      {
        //## begin Server::setBusy%3A60624D01B6.set preserve=no
        m_bBusy = value;
        //## end Server::setBusy%3A60624D01B6.set
      }


      //## Attribute: Name%3A6071910101
      const string& getName () const
      {
        //## begin Server::getName%3A6071910101.get preserve=no
        return m_strName;
        //## end Server::getName%3A6071910101.get
      }

      void setName (const string& value)
      {
        //## begin Server::setName%3A6071910101.set preserve=no
        m_strName = value;
        //## end Server::setName%3A6071910101.set
      }


      //## Attribute: QueueName%3A76D96E016A
      const string& getQueueName () const
      {
        //## begin Server::getQueueName%3A76D96E016A.get preserve=no
        return m_strQueueName;
        //## end Server::getQueueName%3A76D96E016A.get
      }

      void setQueueName (const string& value)
      {
        //## begin Server::setQueueName%3A76D96E016A.set preserve=no
        m_strQueueName = value;
        //## end Server::setQueueName%3A76D96E016A.set
      }


      //## Attribute: ServiceName%3A6593500064
      const string& getServiceName () const
      {
        //## begin Server::getServiceName%3A6593500064.get preserve=no
        return m_strServiceName;
        //## end Server::getServiceName%3A6593500064.get
      }

      void setServiceName (const string& value)
      {
        //## begin Server::setServiceName%3A6593500064.set preserve=no
        m_strServiceName = value;
        //## end Server::setServiceName%3A6593500064.set
      }


      //## Attribute: SQL%3A6062910286
      const string& getSQL () const
      {
        //## begin Server::getSQL%3A6062910286.get preserve=no
        return m_strSQL;
        //## end Server::getSQL%3A6062910286.get
      }

      void setSQL (const string& value)
      {
        //## begin Server::setSQL%3A6062910286.set preserve=no
        m_strSQL = value;
        //## end Server::setSQL%3A6062910286.set
      }


      //## Attribute: Ticks%3A7060A40248
      const double getTicks () const
      {
        //## begin Server::getTicks%3A7060A40248.get preserve=no
        return m_dTicks;
        //## end Server::getTicks%3A7060A40248.get
      }


      //## Attribute: Timestamp%3A6594680003
      const string& getTimestamp () const
      {
        //## begin Server::getTimestamp%3A6594680003.get preserve=no
        return m_strTimestamp;
        //## end Server::getTimestamp%3A6594680003.get
      }


      //## Attribute: UserID%3A65943701E3
      const string& getUserID () const
      {
        //## begin Server::getUserID%3A65943701E3.get preserve=no
        return m_strUserID;
        //## end Server::getUserID%3A65943701E3.get
      }

      void setUserID (const string& value)
      {
        //## begin Server::setUserID%3A65943701E3.set preserve=no
        m_strUserID = value;
        //## end Server::setUserID%3A65943701E3.set
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Application::Client_CAT::<unnamed>%3A64555303E0
      //## Role: Server::<m_hMessage>%3A64555402BF
      IF::Message& getMessage ()
      {
        //## begin Server::getMessage%3A64555402BF.get preserve=no
        return m_hMessage;
        //## end Server::getMessage%3A64555402BF.get
      }

      void setMessage (const IF::Message& value)
      {
        //## begin Server::setMessage%3A64555402BF.set preserve=no
        m_hMessage = value;
        //## end Server::setMessage%3A64555402BF.set
      }


    // Additional Public Declarations
      //## begin Server%3A606173034D.public preserve=yes
      //## end Server%3A606173034D.public

  protected:
    // Additional Protected Declarations
      //## begin Server%3A606173034D.protected preserve=yes
      //## end Server%3A606173034D.protected

  private:
    // Additional Private Declarations
      //## begin Server%3A606173034D.private preserve=yes
      //## end Server%3A606173034D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin Server::Busy%3A60624D01B6.attr preserve=no  public: bool {V} false
      bool m_bBusy;
      //## end Server::Busy%3A60624D01B6.attr

      //## begin Server::Name%3A6071910101.attr preserve=no  public: string {V} 
      string m_strName;
      //## end Server::Name%3A6071910101.attr

      //## begin Server::QueueName%3A76D96E016A.attr preserve=no  public: string {V} 
      string m_strQueueName;
      //## end Server::QueueName%3A76D96E016A.attr

      //## begin Server::ServiceName%3A6593500064.attr preserve=no  public: string {V} 
      string m_strServiceName;
      //## end Server::ServiceName%3A6593500064.attr

      //## begin Server::SQL%3A6062910286.attr preserve=no  public: string {V} 
      string m_strSQL;
      //## end Server::SQL%3A6062910286.attr

      //## begin Server::Ticks%3A7060A40248.attr preserve=no  public: double {V} 0
      double m_dTicks;
      //## end Server::Ticks%3A7060A40248.attr

      //## begin Server::Timestamp%3A6594680003.attr preserve=no  public: string {V} 
      string m_strTimestamp;
      //## end Server::Timestamp%3A6594680003.attr

      //## begin Server::UserID%3A65943701E3.attr preserve=no  public: string {V} 
      string m_strUserID;
      //## end Server::UserID%3A65943701E3.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%3A64555303E0
      //## begin Server::<m_hMessage>%3A64555402BF.role preserve=no  public: IF::Message { -> VHgN}
      IF::Message m_hMessage;
      //## end Server::<m_hMessage>%3A64555402BF.role

    // Additional Implementation Declarations
      //## begin Server%3A606173034D.implementation preserve=yes
      //## end Server%3A606173034D.implementation

};

//## begin Server%3A606173034D.postscript preserve=yes
//## end Server%3A606173034D.postscript

//## begin module%3A6061B80324.epilog preserve=yes
//## end module%3A6061B80324.epilog


#endif
