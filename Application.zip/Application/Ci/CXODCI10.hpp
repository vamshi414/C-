//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A60703E03A2.cm preserve=no
//	$Date:   Jun 22 2017 07:37:00  $ $Author:   e1009839  $ $Revision:   1.5  $
//## end module%3A60703E03A2.cm

//## begin module%3A60703E03A2.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A60703E03A2.cp

//## Module: CXOSCI10%3A60703E03A2; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI10.hpp

#ifndef CXOSCI10_h
#define CXOSCI10_h 1

//## begin module%3A60703E03A2.additionalIncludes preserve=no
//## end module%3A60703E03A2.additionalIncludes

//## begin module%3A60703E03A2.includes preserve=yes
//## end module%3A60703E03A2.includes

#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSIF37_h
#include "CXODIF37.hpp"
#endif

class ServerPool;
class Server;

//## begin module%3A60703E03A2.declarations preserve=no
//## end module%3A60703E03A2.declarations

//## begin module%3A60703E03A2.additionalDeclarations preserve=yes
//## end module%3A60703E03A2.additionalDeclarations


//## begin ClientDisplayServers%3A606E48024C.preface preserve=yes
//## end ClientDisplayServers%3A606E48024C.preface

//## Class: ClientDisplayServers%3A606E48024C
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3A606E880230;Server { -> F}
//## Uses: <unnamed>%3A606E8A03A5;ServerPool { -> F}

class ClientDisplayServers : public ClientInterfaceVisitor  //## Inherits: <unnamed>%3A606E5F0335
{
  //## begin ClientDisplayServers%3A606E48024C.initialDeclarations preserve=yes
  //## end ClientDisplayServers%3A606E48024C.initialDeclarations

  public:
    //## Constructors (generated)
      ClientDisplayServers();

    //## Destructor (generated)
      virtual ~ClientDisplayServers();


    //## Other Operations (specified)
      //## Operation: visitServer%3A606E6D0213
      void visitServer (Server* pServer);

      //## Operation: visitServerPool%3A606E6B0379
      void visitServerPool (ServerPool* pServerPool);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Busy%3A7C30160253
      void setBusy (const bool& value)
      {
        //## begin ClientDisplayServers::setBusy%3A7C30160253.set preserve=no
        m_bBusy = value;
        //## end ClientDisplayServers::setBusy%3A7C30160253.set
      }


    // Additional Public Declarations
      //## begin ClientDisplayServers%3A606E48024C.public preserve=yes
      //## end ClientDisplayServers%3A606E48024C.public

  protected:
    // Additional Protected Declarations
      //## begin ClientDisplayServers%3A606E48024C.protected preserve=yes
      //## end ClientDisplayServers%3A606E48024C.protected

  private:
    // Additional Private Declarations
      //## begin ClientDisplayServers%3A606E48024C.private preserve=yes
      //## end ClientDisplayServers%3A606E48024C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin ClientDisplayServers::Busy%3A7C30160253.attr preserve=no  public: bool {V} true
      bool m_bBusy;
      //## end ClientDisplayServers::Busy%3A7C30160253.attr

      //## Attribute: Description%3A606EB202BD
      //## begin ClientDisplayServers::Description%3A606EB202BD.attr preserve=no  private: char* {V} 0
      char* m_psDescription;
      //## end ClientDisplayServers::Description%3A606EB202BD.attr

      //## Attribute: Rows%3A7A073C0262
      //## begin ClientDisplayServers::Rows%3A7A073C0262.attr preserve=no  private: int {V} 0
      int m_lRows;
      //## end ClientDisplayServers::Rows%3A7A073C0262.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%3A60737D028F
      //## Role: ClientDisplayServers::<m_hResultSet>%3A60737E00D8
      //## begin ClientDisplayServers::<m_hResultSet>%3A60737E00D8.role preserve=no  public: IF::ResultSet { -> VHgN}
      IF::ResultSet m_hResultSet;
      //## end ClientDisplayServers::<m_hResultSet>%3A60737E00D8.role

    // Additional Implementation Declarations
      //## begin ClientDisplayServers%3A606E48024C.implementation preserve=yes
      //## end ClientDisplayServers%3A606E48024C.implementation

};

//## begin ClientDisplayServers%3A606E48024C.postscript preserve=yes
//## end ClientDisplayServers%3A606E48024C.postscript

//## begin module%3A60703E03A2.epilog preserve=yes
//## end module%3A60703E03A2.epilog


#endif
