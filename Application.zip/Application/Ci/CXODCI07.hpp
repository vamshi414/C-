//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A5F24CC0259.cm preserve=no
//	$Date:   Jun 22 2017 07:38:44  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3A5F24CC0259.cm

//## begin module%3A5F24CC0259.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A5F24CC0259.cp

//## Module: CXOSCI07%3A5F24CC0259; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI07.hpp

#ifndef CXOSCI07_h
#define CXOSCI07_h 1

//## begin module%3A5F24CC0259.additionalIncludes preserve=no
//## end module%3A5F24CC0259.additionalIncludes

//## begin module%3A5F24CC0259.includes preserve=yes
//## end module%3A5F24CC0259.includes

#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSIF37_h
#include "CXODIF37.hpp"
#endif

class ClientSession;
class Server;

//## begin module%3A5F24CC0259.declarations preserve=no
//## end module%3A5F24CC0259.declarations

//## begin module%3A5F24CC0259.additionalDeclarations preserve=yes
//## end module%3A5F24CC0259.additionalDeclarations


//## begin ClientDisplayServerSQL%3A5F231D0372.preface preserve=yes
//## end ClientDisplayServerSQL%3A5F231D0372.preface

//## Class: ClientDisplayServerSQL%3A5F231D0372
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3A5F235A027F;ClientSession { -> F}
//## Uses: <unnamed>%3A62EC3E032C;Server { -> F}

class ClientDisplayServerSQL : public ClientInterfaceVisitor  //## Inherits: <unnamed>%3A5F233400C2
{
  //## begin ClientDisplayServerSQL%3A5F231D0372.initialDeclarations preserve=yes
  //## end ClientDisplayServerSQL%3A5F231D0372.initialDeclarations

  public:
    //## Constructors (generated)
      ClientDisplayServerSQL();

    //## Destructor (generated)
      virtual ~ClientDisplayServerSQL();


    //## Other Operations (specified)
      //## Operation: visitServer%3A6621BB00EC
      virtual void visitServer (Server* pServer);

    // Additional Public Declarations
      //## begin ClientDisplayServerSQL%3A5F231D0372.public preserve=yes
      //## end ClientDisplayServerSQL%3A5F231D0372.public

  protected:
    // Additional Protected Declarations
      //## begin ClientDisplayServerSQL%3A5F231D0372.protected preserve=yes
      //## end ClientDisplayServerSQL%3A5F231D0372.protected

  private:
    // Additional Private Declarations
      //## begin ClientDisplayServerSQL%3A5F231D0372.private preserve=yes
      //## end ClientDisplayServerSQL%3A5F231D0372.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Description%3A5F25D90260
      //## begin ClientDisplayServerSQL::Description%3A5F25D90260.attr preserve=no  private: char* {V} 0
      char* m_psDescription;
      //## end ClientDisplayServerSQL::Description%3A5F25D90260.attr

      //## Attribute: Rows%3A7ADCCC0250
      //## begin ClientDisplayServerSQL::Rows%3A7ADCCC0250.attr preserve=no  private: int {V} 0
      int m_lRows;
      //## end ClientDisplayServerSQL::Rows%3A7ADCCC0250.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%3A5F233D0089
      //## Role: ClientDisplayServerSQL::<m_hResultSet>%3A5F233D0313
      //## begin ClientDisplayServerSQL::<m_hResultSet>%3A5F233D0313.role preserve=no  public: IF::ResultSet { -> VHgN}
      IF::ResultSet m_hResultSet;
      //## end ClientDisplayServerSQL::<m_hResultSet>%3A5F233D0313.role

    // Additional Implementation Declarations
      //## begin ClientDisplayServerSQL%3A5F231D0372.implementation preserve=yes
      //## end ClientDisplayServerSQL%3A5F231D0372.implementation

};

//## begin ClientDisplayServerSQL%3A5F231D0372.postscript preserve=yes
//## end ClientDisplayServerSQL%3A5F231D0372.postscript

//## begin module%3A5F24CC0259.epilog preserve=yes
//## end module%3A5F24CC0259.epilog


#endif
