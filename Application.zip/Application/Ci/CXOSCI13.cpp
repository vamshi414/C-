//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A6C470C03DD.cm preserve=no
//	$Date:   Jun 26 2017 07:46:44  $ $Author:   e1009839  $ $Revision:   1.24  $
//## end module%3A6C470C03DD.cm

//## begin module%3A6C470C03DD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A6C470C03DD.cp

//## Module: CXOSCI13%3A6C470C03DD; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI13.cpp

//## begin module%3A6C470C03DD.additionalIncludes preserve=no
//## end module%3A6C470C03DD.additionalIncludes

//## begin module%3A6C470C03DD.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%3A6C470C03DD.includes

#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSBS11_h
#include "CXODBS11.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSUS15_h
#include "CXODUS15.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSCI13_h
#include "CXODCI13.hpp"
#endif


//## begin module%3A6C470C03DD.declarations preserve=no
//## end module%3A6C470C03DD.declarations

//## begin module%3A6C470C03DD.additionalDeclarations preserve=yes
//## end module%3A6C470C03DD.additionalDeclarations


// Class ClientPool 

//## begin ClientPool::Instance%3A6C4DAF02F0.attr preserve=no  private: static ClientPool* {V} 0
ClientPool* ClientPool::m_pInstance = 0;
//## end ClientPool::Instance%3A6C4DAF02F0.attr

ClientPool::ClientPool()
  //## begin ClientPool::ClientPool%3A6C46B0013C_const.hasinit preserve=no
  //## end ClientPool::ClientPool%3A6C46B0013C_const.hasinit
  //## begin ClientPool::ClientPool%3A6C46B0013C_const.initialization preserve=yes
  //## end ClientPool::ClientPool%3A6C46B0013C_const.initialization
{
  //## begin ClientPool::ClientPool%3A6C46B0013C_const.body preserve=yes
   memcpy(m_sID,"CI13",4);
   Extract::instance()->getSpec("CUSTOMER",m_strCustomerID);
   MinuteTimer::instance()->attach(this);
  //## end ClientPool::ClientPool%3A6C46B0013C_const.body
}


ClientPool::~ClientPool()
{
  //## begin ClientPool::~ClientPool%3A6C46B0013C_dest.body preserve=yes
   MinuteTimer::instance()->detach(this);
   m_hClientSession.erase(m_hClientSession.begin(),m_hClientSession.end());
  //## end ClientPool::~ClientPool%3A6C46B0013C_dest.body
}



//## Other Operations (implementation)
void ClientPool::accept (ClientInterfaceVisitor& hClientInterfaceVisitor)
{
  //## begin ClientPool::accept%3A6C52260113.body preserve=yes
   hClientInterfaceVisitor.visitClientPool(this);
   map<string,ClientSession,less<string> >::iterator pSession;
   for (pSession = m_hClientSession.begin();pSession != m_hClientSession.end();++pSession)
      (*pSession).second.accept(hClientInterfaceVisitor);
  //## end ClientPool::accept%3A6C52260113.body
}

void ClientPool::addProcessTime (const string& strUserID, int lProcessTime)
{
  //## begin ClientPool::addProcessTime%3A705C1700EF.body preserve=yes
   map<string,ClientSession,less<string> >::iterator pSession = m_hClientSession.find(strUserID);
   if (pSession != m_hClientSession.end())
   {
      lProcessTime += (*pSession).second.getProcessTime();
      (*pSession).second.setProcessTime(lProcessTime);
   }
  //## end ClientPool::addProcessTime%3A705C1700EF.body
}

void ClientPool::addQueueTime (const string& strUserID, int lQueueTime)
{
  //## begin ClientPool::addQueueTime%3A705BCD01F7.body preserve=yes
   map<string,ClientSession,less<string> >::iterator pSession = m_hClientSession.find(strUserID);
   if (pSession != m_hClientSession.end())
   {
      lQueueTime += (*pSession).second.getQueueTime();
      (*pSession).second.setQueueTime(lQueueTime);
   }
  //## end ClientPool::addQueueTime%3A705BCD01F7.body
}

void ClientPool::addRequest (const string& strUserID)
{
  //## begin ClientPool::addRequest%3A6F10EB0296.body preserve=yes
   map<string,ClientSession,less<string> >::iterator pSession = m_hClientSession.find(strUserID);
   if (pSession != m_hClientSession.end())
   {
      int lRequests = (*pSession).second.getRequests();
      ++lRequests;
      (*pSession).second.setRequests(lRequests);
      (*pSession).second.setLastRequestTimestamp(Clock::instance()->getYYYYMMDDHHMMSS());
   }
  //## end ClientPool::addRequest%3A6F10EB0296.body
}

void ClientPool::ageout ()
{
  //## begin ClientPool::ageout%3DF493E3036B.body preserve=yes
   UseCase hUseCase("CLIENT","## CL113 AGEOUT USERS");
   string strYYYYMMDDHHMMSS = Clock::instance()->getYYYYMMDDHHMMSS();
   map<string,ClientSession,less<string> >::iterator pSession;
   map<string,ClientSession,less<string> >::iterator pTempSession;
   DateTime hDateTime;
   pSession = m_hClientSession.begin();
   while (pSession != m_hClientSession.end())
   {
      IString strAdjustTimestamp((*pSession).second.getLastRequestTimestamp().c_str());
      hDateTime.timeAdjust(strAdjustTimestamp,60);
      if (memcmp(strAdjustTimestamp, strYYYYMMDDHHMMSS.data(),14) < 0)
      {
         pTempSession = ++pSession;
         m_hClientSession.erase(--pSession);
         pSession = pTempSession;
         UseCase::addItem();
      }
      else
         ++pSession;
   }
  //## end ClientPool::ageout%3DF493E3036B.body
}

bool ClientPool::getApplicationName (const string &strUserID, string& strApplicationName)
{
  //## begin ClientPool::getApplicationName%3B5D6BDC037A.body preserve=yes
   map<string,ClientSession,less<string> >::iterator pSession = m_hClientSession.find(strUserID);
   if (pSession == m_hClientSession.end()) 
      return false;
   strApplicationName = (*pSession).second.getApplicationName();
   return true;
  //## end ClientPool::getApplicationName%3B5D6BDC037A.body
}

char* ClientPool::getRelationship (const string& strUserID)
{
  //## begin ClientPool::getRelationship%3A6D92330252.body preserve=yes
   map<string,ClientSession,less<string> >::iterator pSession = m_hClientSession.find(strUserID);
   return (pSession == m_hClientSession.end()) ? 0 : (*pSession).second.relationshipSegment();
  //## end ClientPool::getRelationship%3A6D92330252.body
}

ResourceListSegment * ClientPool::getResourceListSegment (const string &strUserID)
{
  //## begin ClientPool::getResourceListSegment%3B5D6C250186.body preserve=yes
   map<string,ClientSession,less<string> >::iterator pSession = m_hClientSession.find(strUserID);
   return (pSession == m_hClientSession.end()) ? 0 : (*pSession).second.getResourceListSegment();
  //## end ClientPool::getResourceListSegment%3B5D6C250186.body
}

void* ClientPool::getSession (const string& strUserID)
{
  //## begin ClientPool::getSession%3A6C920703DE.body preserve=yes
   map<string,ClientSession,less<string> >::iterator pSession = m_hClientSession.find(strUserID);
   if (pSession == m_hClientSession.end())
      return (void*)0;
   return &((*pSession).second);
  //## end ClientPool::getSession%3A6C920703DE.body
}

ClientPool* ClientPool::instance ()
{
  //## begin ClientPool::instance%3A6C4DCC02E8.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ClientPool();
   return m_pInstance;
  //## end ClientPool::instance%3A6C4DCC02E8.body
}

bool ClientPool::isLoggedOn ()
{
  //## begin ClientPool::isLoggedOn%3A6C7AC2025C.body preserve=yes
   Trace::put("ClientPool::isLoggedOn 1");
   map<string,ClientSession,less<string> >::iterator pSession = 
      m_hClientSession.find(CommonHeaderSegment::instance()->getAlias());
   if (pSession == m_hClientSession.end()) 
      return false;
   Trace::put("ClientPool::isLoggedOn 2");
   if (CommonHeaderSegment::instance()->getServiceName() == "QLOGOFF")
      return true;
   Trace::put("ClientPool::isLoggedOn 3");
   if (CommonHeaderSegment::instance()->getSecurityData().length() < 25)
      return false;
   Trace::put("ClientPool::isLoggedOn 4");
   Trace::put((*pSession).second.getTimestamp().c_str());
   Trace::put(CommonHeaderSegment::instance()->getSecurityData().c_str());
   return ((*pSession).second.getTimestamp() == 
      CommonHeaderSegment::instance()->getSecurityData().substr(9,16));
  //## end ClientPool::isLoggedOn%3A6C7AC2025C.body
}

bool ClientPool::logoff (const string& strUserID)
{
  //## begin ClientPool::logoff%3A6C82A601E9.body preserve=yes
   Trace::put("ClientPool::logoff");
   map<string,ClientSession,less<string> >::iterator pSession = m_hClientSession.find(strUserID);
   if (pSession == m_hClientSession.end())
      return false;
   m_hClientSession.erase(pSession);
   trace();
   return true;
  //## end ClientPool::logoff%3A6C82A601E9.body
}

int ClientPool::logon (const string& strUserID, segment::CommonHeaderSegment* pCommonHeaderSegment)
{
  //## begin ClientPool::logon%3A6C7C5E010A.body preserve=yes
   Trace::put("ClientPool::logon");
   map<string,ClientSession,less<string> >::iterator pSession = m_hClientSession.find(strUserID);
   if (pSession != m_hClientSession.end())
   {
      (*pSession).second.setCommonHeaderSegment(CommonHeaderSegment::instance());
      (*pSession).second.setTimestamp(CommonHeaderSegment::instance()->getSecurityData().substr(9,16));
      //CommonHeaderSegment::instance()->setSecurityData((*pSession).second.key().c_str());
      trace();
      return 0;
   }
   ClientSession hSession;
   hSession.setUserID(strUserID.c_str());
   hSession.setTimestamp(CommonHeaderSegment::instance()->getSecurityData().substr(9,16));
   if (pCommonHeaderSegment->getServiceName() == "RLOGON")
      hSession.setApplicationName("STS");
   m_hClientSession.insert(m_hClientSession.begin(),map<string,ClientSession,less<string> >::value_type(strUserID,hSession));
   trace();
   return 0;
  //## end ClientPool::logon%3A6C7C5E010A.body
}

bool ClientPool::pop (const string& strUserID, const string& strQueueName, const string& strExternalContextData, bool bForward, bool bQuery)
{
  //## begin ClientPool::pop%3A6D9DA70276.body preserve=yes
   Trace::put("ClientPool::pop");
   map<string,ClientSession,less<string> >::iterator pSession = m_hClientSession.find(strUserID);
   if (pSession != m_hClientSession.end())
      return ((*pSession).second.pop(strQueueName,strExternalContextData.c_str(),bForward,bQuery));
   Trace::put("session not found in ClientPool::pop");
   return false;
  //## end ClientPool::pop%3A6D9DA70276.body
}

bool ClientPool::push (const string& strUserID, Message& hMessage, int lTotalRecordsFound, bool bSend)
{
  //## begin ClientPool::push%3A6DB26700CF.body preserve=yes
   Trace::put("ClientPool::push");
   map<string,ClientSession,less<string> >::iterator pSession = m_hClientSession.find(strUserID);
   if (pSession == m_hClientSession.end())
      return false;
   (*pSession).second.push(hMessage,lTotalRecordsFound,bSend);
   trace();
   return true;
  //## end ClientPool::push%3A6DB26700CF.body
}

void ClientPool::saveRelationship (Message& hMessage)
{
  //## begin ClientPool::saveRelationship%3A6C7F6B01C1.body preserve=yes
   char* pSegmentID = hMessage.data() + 8;
   char szTemp[9] = {"        "};
   char* pEndOfMessage = hMessage.data() + hMessage.dataLength();
   int iRC = CommonHeaderSegment::instance()->import(&pSegmentID);
   string strUserID(CommonHeaderSegment::instance()->getAlias());
   map<string,ClientSession,less<string> >::iterator pSession = m_hClientSession.find(strUserID);
   if (pSession == m_hClientSession.end())
      return;
   while (pSegmentID < pEndOfMessage)
   {
      if (!strncmp(pSegmentID,"S912",4))
      {
         (*pSession).second.setRelationshipSegment(pSegmentID);
         break;
      }
      memcpy(szTemp,pSegmentID + 8,8);
      pSegmentID += atoi(szTemp);
   }
  //## end ClientPool::saveRelationship%3A6C7F6B01C1.body
}

void ClientPool::setASCII (const string& strUserID, bool bASCII)
{
  //## begin ClientPool::setASCII%3A6C9A6F0307.body preserve=yes
   map<string,ClientSession,less<string> >::iterator pSession = m_hClientSession.find(strUserID);
   if (pSession != m_hClientSession.end())
      (*pSession).second.setASCII(bASCII);
  //## end ClientPool::setASCII%3A6C9A6F0307.body
}

void ClientPool::trace ()
{
  //## begin ClientPool::trace%3E9EE24302CE.body preserve=yes
   Trace::put("ClientPool::trace");
   map<string,ClientSession,less<string> >::iterator pSession;
   for (pSession = m_hClientSession.begin();pSession != m_hClientSession.end();++pSession)
      (*pSession).second.trace();
   ClientSession::traceCache();
  //## end ClientPool::trace%3E9EE24302CE.body
}

void ClientPool::update (Subject* pSubject)
{
  //## begin ClientPool::update%3A6C4DE20145.body preserve=yes
   ClientSession::purgeCache();
  //## end ClientPool::update%3A6C4DE20145.body
}

// Additional Declarations
  //## begin ClientPool%3A6C46B0013C.declarations preserve=yes
  //## end ClientPool%3A6C46B0013C.declarations

//## begin module%3A6C470C03DD.epilog preserve=yes
//## end module%3A6C470C03DD.epilog
