//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3A79944802D5.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3A79944802D5.cm

//## begin module%3A79944802D5.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3A79944802D5.cp

//## Module: CXOSCI14%3A79944802D5; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ci\CXOSCI14.cpp

//## begin module%3A79944802D5.additionalIncludes preserve=no
//## end module%3A79944802D5.additionalIncludes

//## begin module%3A79944802D5.includes preserve=yes
// $Date:   May 13 2020 11:50:54  $ $Author:   e1009510  $ $Revision:   1.5  $
#include <stdio.h>
//## end module%3A79944802D5.includes

#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSCI14_h
#include "CXODCI14.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif


//## begin module%3A79944802D5.declarations preserve=no
//## end module%3A79944802D5.declarations

//## begin module%3A79944802D5.additionalDeclarations preserve=yes
//## end module%3A79944802D5.additionalDeclarations


// Class SlowQuery 







SlowQuery::SlowQuery()
  //## begin SlowQuery::SlowQuery%3A79911C0309_const.hasinit preserve=no
      : m_dTicks(0)
  //## end SlowQuery::SlowQuery%3A79911C0309_const.hasinit
  //## begin SlowQuery::SlowQuery%3A79911C0309_const.initialization preserve=yes
  //## end SlowQuery::SlowQuery%3A79911C0309_const.initialization
{
  //## begin SlowQuery::SlowQuery%3A79911C0309_const.body preserve=yes
   memcpy(m_sID,"CI14",4);
  //## end SlowQuery::SlowQuery%3A79911C0309_const.body
}

SlowQuery::SlowQuery(const SlowQuery &right)
  //## begin SlowQuery::SlowQuery%3A79911C0309_copy.hasinit preserve=no
      : m_dTicks(0)
  //## end SlowQuery::SlowQuery%3A79911C0309_copy.hasinit
  //## begin SlowQuery::SlowQuery%3A79911C0309_copy.initialization preserve=yes
  //## end SlowQuery::SlowQuery%3A79911C0309_copy.initialization
{
  //## begin SlowQuery::SlowQuery%3A79911C0309_copy.body preserve=yes
   memcpy(m_sID,"CI14",4);
   m_strServiceName = right.m_strServiceName;
   m_strSQL = right.m_strSQL;
   m_dTicks = right.m_dTicks;
   m_strTimestamp = right.m_strTimestamp;
   m_strUserID = right.m_strUserID;
  //## end SlowQuery::SlowQuery%3A79911C0309_copy.body
}


SlowQuery::~SlowQuery()
{
  //## begin SlowQuery::~SlowQuery%3A79911C0309_dest.body preserve=yes
  //## end SlowQuery::~SlowQuery%3A79911C0309_dest.body
}


SlowQuery & SlowQuery::operator=(const SlowQuery &right)
{
  //## begin SlowQuery::operator=%3A79911C0309_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_strServiceName = right.m_strServiceName;
   m_strSQL = right.m_strSQL;
   m_dTicks = right.m_dTicks;
   m_strTimestamp = right.m_strTimestamp;
   m_strUserID = right.m_strUserID;
  //## end SlowQuery::operator=%3A79911C0309_assign.body
}



//## Other Operations (implementation)
void SlowQuery::accept (ClientInterfaceVisitor& hClientInterfaceVisitor)
{
  //## begin SlowQuery::accept%3A79955D0319.body preserve=yes
   hClientInterfaceVisitor.visitSlowQuery(this);
  //## end SlowQuery::accept%3A79955D0319.body
}

void SlowQuery::log ()
{
  //## begin SlowQuery::log%3A87EE340039.body preserve=yes
   struct sSlowQuery
   {
      char sServiceName[8];
      char sUserID[8];
      char sTicks[16];
      char sSQL[12288];
   };
   struct sSlowQuery hSlowQuery;
   memset((char*)&hSlowQuery,' ',sizeof(hSlowQuery));
   memcpy(hSlowQuery.sServiceName,m_strServiceName.data(),m_strServiceName.length());
   memcpy(hSlowQuery.sUserID,m_strUserID.data(),m_strUserID.length());
   char szTemp[PERCENTF];
   int i = snprintf(szTemp,sizeof(szTemp),"%f",m_dTicks);
   memcpy(hSlowQuery.sTicks,szTemp,i);
   i = (m_strSQL.length() > 12288) ? 12288 : m_strSQL.length();
   memcpy(hSlowQuery.sSQL,m_strSQL.data(),i);
   Log::put((char*)&hSlowQuery,32 + i,"S0008D","SLOW SQL");
  //## end SlowQuery::log%3A87EE340039.body
}

// Additional Declarations
  //## begin SlowQuery%3A79911C0309.declarations preserve=yes
  //## end SlowQuery%3A79911C0309.declarations

//## begin module%3A79944802D5.epilog preserve=yes
//## end module%3A79944802D5.epilog
