//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A7994BD0098.cm preserve=no
//	$Date:   Jun 22 2017 07:58:52  $ $Author:   e1009839  $ $Revision:   1.6  $
//## end module%3A7994BD0098.cm

//## begin module%3A7994BD0098.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A7994BD0098.cp

//## Module: CXOSCI15%3A7994BD0098; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI15.cpp

//## begin module%3A7994BD0098.additionalIncludes preserve=no
//## end module%3A7994BD0098.additionalIncludes

//## begin module%3A7994BD0098.includes preserve=yes
//## end module%3A7994BD0098.includes

#ifndef CXOSCI14_h
#include "CXODCI14.hpp"
#endif
#ifndef CXOSCI15_h
#include "CXODCI15.hpp"
#endif


//## begin module%3A7994BD0098.declarations preserve=no
//## end module%3A7994BD0098.declarations

//## begin module%3A7994BD0098.additionalDeclarations preserve=yes
#include "CXODRU32.hpp"
   struct sSlowQuery
   {
      char sDate[9];
      short int iNull0;
      char sTime[7];
      short int iNull1;
      char sServiceName[9];
      short int iNull2;
      char sUserID[9];
      short int iNull3;
      int lTicks;
      short int iNull4;
   };
#include "CXODRU33.hpp"
//## end module%3A7994BD0098.additionalDeclarations


// Class ClientDisplaySlowRequests 

ClientDisplaySlowRequests::ClientDisplaySlowRequests()
  //## begin ClientDisplaySlowRequests::ClientDisplaySlowRequests%3A7991600130_const.hasinit preserve=no
      : m_psDescription(0),
        m_lRows(0)
  //## end ClientDisplaySlowRequests::ClientDisplaySlowRequests%3A7991600130_const.hasinit
  //## begin ClientDisplaySlowRequests::ClientDisplaySlowRequests%3A7991600130_const.initialization preserve=yes
  //## end ClientDisplaySlowRequests::ClientDisplaySlowRequests%3A7991600130_const.initialization
{
  //## begin ClientDisplaySlowRequests::ClientDisplaySlowRequests%3A7991600130_const.body preserve=yes
   memcpy(m_sID,"CI15",4);
#include "CXODRU32.hpp"
   struct hDescription
   {
      char sColumnName[18];
      short int nDataType;
      int nPrecision;
      short int nScale;
   };
#include "CXODRU33.hpp"
   int j = 5;
   char* pszColumnName[5] = {"DATE","TIME","SERVICE","USERID","TICKS"};
   int nPrecision[5] = {9,7,9,9,0};
   int k = 4 + (j * sizeof(struct hDescription));
   m_psDescription = new char[k];
   memset(m_psDescription,' ',k);
   memcpy(m_psDescription,&j,sizeof(int));
   hDescription* p = (hDescription*)(m_psDescription + 4);
   for (int i = 0;i < j;++i)
   {
      memcpy(p->sColumnName,pszColumnName[i],strlen(pszColumnName[i]));
      if (nPrecision[i] == 0)
      {
         p->nDataType = 4;
         p->nPrecision = 4;
      }
      else
      {
         p->nDataType = 1;
         p->nPrecision = nPrecision[i];
      }
      p->nScale = 0;
      ++p;
   }
  //## end ClientDisplaySlowRequests::ClientDisplaySlowRequests%3A7991600130_const.body
}


ClientDisplaySlowRequests::~ClientDisplaySlowRequests()
{
  //## begin ClientDisplaySlowRequests::~ClientDisplaySlowRequests%3A7991600130_dest.body preserve=yes
   if (m_lRows == 0)
   {
      struct sSlowQuery hSlowQuery;
      memset((char*)&hSlowQuery,' ',sizeof(struct sSlowQuery));
      memcpy(hSlowQuery.sUserID,"NONE",4);
      hSlowQuery.lTicks = 0;
      m_hResultSet.addRow(m_psDescription,(char*)&hSlowQuery);
   }
   m_hResultSet.close();
   delete [] m_psDescription;
  //## end ClientDisplaySlowRequests::~ClientDisplaySlowRequests%3A7991600130_dest.body
}



//## Other Operations (implementation)
void ClientDisplaySlowRequests::visitSlowQuery (SlowQuery* pSlowQuery)
{
  //## begin ClientDisplaySlowRequests::visitSlowQuery%3A7999560069.body preserve=yes
   struct sSlowQuery hSlowQuery;
   memset((char*)&hSlowQuery,' ',sizeof(struct sSlowQuery));
   memcpy(hSlowQuery.sDate,pSlowQuery->getTimestamp().data(),8);
   memcpy(hSlowQuery.sTime,pSlowQuery->getTimestamp().data() + 8,6);
   memcpy(hSlowQuery.sServiceName,pSlowQuery->getServiceName().data(),pSlowQuery->getServiceName().length());
   memcpy(hSlowQuery.sUserID,pSlowQuery->getUserID().data(),pSlowQuery->getUserID().length());
   hSlowQuery.lTicks = pSlowQuery->getTicks();
   m_hResultSet.addRow(m_psDescription,(char*)&hSlowQuery);
   ++m_lRows;
  //## end ClientDisplaySlowRequests::visitSlowQuery%3A7999560069.body
}

// Additional Declarations
  //## begin ClientDisplaySlowRequests%3A7991600130.declarations preserve=yes
  //## end ClientDisplaySlowRequests%3A7991600130.declarations

//## begin module%3A7994BD0098.epilog preserve=yes
//## end module%3A7994BD0098.epilog

