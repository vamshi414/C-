//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%368002C900BB.cm preserve=no
//	$Date:   Jun 26 2017 07:46:26  $ $Author:   e1009839  $ $Revision:   1.27  $
//## end module%368002C900BB.cm

//## begin module%368002C900BB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%368002C900BB.cp

//## Module: CXOSCI01%368002C900BB; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI01.hpp

#ifndef CXOSCI01_h
#define CXOSCI01_h 1

//## begin module%368002C900BB.additionalIncludes preserve=no
//## end module%368002C900BB.additionalIncludes

//## begin module%368002C900BB.includes preserve=yes
#include <map>
//## end module%368002C900BB.includes

#ifndef CXOSUS15_h
#include "CXODUS15.hpp"
#endif
#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Trace;
class Timestamp;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class CommonHeaderSegment;
class InformationSegment;
} // namespace segment

class ClientInterfaceVisitor;
class ClientRequest;

//## begin module%368002C900BB.declarations preserve=no
//## end module%368002C900BB.declarations

//## begin module%368002C900BB.additionalDeclarations preserve=yes
//## end module%368002C900BB.additionalDeclarations


//## begin ClientSession%345407AF0053.preface preserve=yes
//## end ClientSession%345407AF0053.preface

//## Class: ClientSession%345407AF0053
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%37D9467B01B1;process::Application { -> F}
//## Uses: <unnamed>%37D9467E00BB;segment::InformationSegment { -> F}
//## Uses: <unnamed>%37FB27980389;IF::CodeTable { -> F}
//## Uses: <unnamed>%3A5CB8620242;ClientInterfaceVisitor { -> F}
//## Uses: <unnamed>%3E85D45900EA;IF::Trace { -> F}
//## Uses: <unnamed>%3E85D6CD00FA;timer::Clock { -> F}
//## Uses: <unnamed>%3E85D6D500FA;IF::Timestamp { -> F}
//## Uses: <unnamed>%45B6319B0222;ClientRequest { -> F}

class ClientSession : public reusable::Object  //## Inherits: <unnamed>%3E9C36550261
{
  //## begin ClientSession%345407AF0053.initialDeclarations preserve=yes
  //## end ClientSession%345407AF0053.initialDeclarations

  public:
    //## Constructors (generated)
      ClientSession();

      ClientSession(const ClientSession &right);

    //## Destructor (generated)
      virtual ~ClientSession();

    //## Assignment Operation (generated)
      ClientSession & operator=(const ClientSession &right);


    //## Other Operations (specified)
      //## Operation: accept%3A5CB84C002E
      void accept (ClientInterfaceVisitor& hClientInterfaceVisitor);

      //## Operation: getAlias%3CFF9D850280
      static string getAlias ();

      //## Operation: getCacheCount%42C45A060196
      int getCacheCount ();

      //## Operation: getCacheSize%42C45A0E0242
      int getCacheSize ();

      //## Operation: getResourceListSegment%3B5D6A0E03A9
      ResourceListSegment * getResourceListSegment ();

      //## Operation: initialize%352B7A3E0096
      void initialize ();

      //## Operation: key%352B7A4302EC
      const string& key () const;

      //## Operation: pop%37DE93C700C8
      bool pop (const string& strQueueName, const char* pszExternalContextData, bool bForward = true, bool bQuery = false);

      //## Operation: purgeCache%3E85C8DF01D4
      static void purgeCache ();

      //## Operation: push%37DE6E0D0161
      bool push (Message& hMessage, int lTotalRecordsFound, bool bSend = false);

      //## Operation: queue%3A5F10A70312
      void queue (const Message& hMessage);

      //## Operation: setCommonHeaderSegment%3EA3DC8A00FA
      void setCommonHeaderSegment (segment::CommonHeaderSegment* pCommonHeaderSegment);

      //## Operation: setRelationshipSegment%352BE2400056
      void setRelationshipSegment (char* pRelationshipSegment);

      //## Operation: trace%3E9ECAFB038A
      void trace ();

      //## Operation: traceCache%3E9EE3E00261
      static void traceCache ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: AliasCount%3CFF9AA20399
      static const int getAliasCount ()
      {
        //## begin ClientSession::getAliasCount%3CFF9AA20399.get preserve=no
        return m_lAliasCount;
        //## end ClientSession::getAliasCount%3CFF9AA20399.get
      }

      static void setAliasCount (int value)
      {
        //## begin ClientSession::setAliasCount%3CFF9AA20399.set preserve=no
        m_lAliasCount = value;
        //## end ClientSession::setAliasCount%3CFF9AA20399.set
      }


      //## Attribute: ApplicationName%3E9C489B02EE
      const string& getApplicationName () const
      {
        //## begin ClientSession::getApplicationName%3E9C489B02EE.get preserve=no
        return m_strApplicationName;
        //## end ClientSession::getApplicationName%3E9C489B02EE.get
      }

      void setApplicationName (const string& value)
      {
        //## begin ClientSession::setApplicationName%3E9C489B02EE.set preserve=no
        m_strApplicationName = value;
        //## end ClientSession::setApplicationName%3E9C489B02EE.set
      }


      //## Attribute: ASCII%3E9C3DB70232
      const bool& getASCII () const
      {
        //## begin ClientSession::getASCII%3E9C3DB70232.get preserve=no
        return m_bASCII;
        //## end ClientSession::getASCII%3E9C3DB70232.get
      }

      void setASCII (const bool& value)
      {
        //## begin ClientSession::setASCII%3E9C3DB70232.set preserve=no
        m_bASCII = value;
        //## end ClientSession::setASCII%3E9C3DB70232.set
      }


      //## Attribute: LastRequestTimestamp%3DEB6C4503B9
      const string& getLastRequestTimestamp () const
      {
        //## begin ClientSession::getLastRequestTimestamp%3DEB6C4503B9.get preserve=no
        return m_strLastRequestTimestamp;
        //## end ClientSession::getLastRequestTimestamp%3DEB6C4503B9.get
      }

      void setLastRequestTimestamp (const string& value)
      {
        //## begin ClientSession::setLastRequestTimestamp%3DEB6C4503B9.set preserve=no
        m_strLastRequestTimestamp = value;
        //## end ClientSession::setLastRequestTimestamp%3DEB6C4503B9.set
      }


      //## Attribute: ProcessTime%3A6C3ECE03BB
      const int getProcessTime () const
      {
        //## begin ClientSession::getProcessTime%3A6C3ECE03BB.get preserve=no
        return m_lProcessTime;
        //## end ClientSession::getProcessTime%3A6C3ECE03BB.get
      }

      void setProcessTime (int value)
      {
        //## begin ClientSession::setProcessTime%3A6C3ECE03BB.set preserve=no
        m_lProcessTime = value;
        //## end ClientSession::setProcessTime%3A6C3ECE03BB.set
      }


      //## Attribute: QueueTime%3A6C3E98024B
      const int getQueueTime () const
      {
        //## begin ClientSession::getQueueTime%3A6C3E98024B.get preserve=no
        return m_lQueueTime;
        //## end ClientSession::getQueueTime%3A6C3E98024B.get
      }

      void setQueueTime (int value)
      {
        //## begin ClientSession::setQueueTime%3A6C3E98024B.set preserve=no
        m_lQueueTime = value;
        //## end ClientSession::setQueueTime%3A6C3E98024B.set
      }


      //## Attribute: RelationshipSegment%352BE1F10337
      char* relationshipSegment ()
      {
        //## begin ClientSession::relationshipSegment%352BE1F10337.get preserve=no
        return m_pRelationshipSegment;
        //## end ClientSession::relationshipSegment%352BE1F10337.get
      }


      //## Attribute: Requests%3A6C3E7101E1
      const int getRequests () const
      {
        //## begin ClientSession::getRequests%3A6C3E7101E1.get preserve=no
        return m_lRequests;
        //## end ClientSession::getRequests%3A6C3E7101E1.get
      }

      void setRequests (int value)
      {
        //## begin ClientSession::setRequests%3A6C3E7101E1.set preserve=no
        m_lRequests = value;
        //## end ClientSession::setRequests%3A6C3E7101E1.set
      }


      //## Attribute: Timestamp%3919C08500DA
      const string& getTimestamp () const
      {
        //## begin ClientSession::getTimestamp%3919C08500DA.get preserve=no
        return m_strTimestamp;
        //## end ClientSession::getTimestamp%3919C08500DA.get
      }

      void setTimestamp (const string& value)
      {
        //## begin ClientSession::setTimestamp%3919C08500DA.set preserve=no
        m_strTimestamp = value;
        //## end ClientSession::setTimestamp%3919C08500DA.set
      }


      //## Attribute: UserID%3E9C48AE007D
      const string& getUserID () const
      {
        //## begin ClientSession::getUserID%3E9C48AE007D.get preserve=no
        return m_strUserID;
        //## end ClientSession::getUserID%3E9C48AE007D.get
      }

      void setUserID (const string& value)
      {
        //## begin ClientSession::setUserID%3E9C48AE007D.set preserve=no
        m_strUserID = value;
        //## end ClientSession::setUserID%3E9C48AE007D.set
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Connex Application::Client_CAT::<unnamed>%3A5F10D50386
      //## Role: ClientSession::<m_hMessage>%3A5F10D602BF
      IF::Message& getMessage ()
      {
        //## begin ClientSession::getMessage%3A5F10D602BF.get preserve=no
        return m_hMessage;
        //## end ClientSession::getMessage%3A5F10D602BF.get
      }


    // Additional Public Declarations
      //## begin ClientSession%345407AF0053.public preserve=yes
      //## end ClientSession%345407AF0053.public

  protected:
    // Additional Protected Declarations
      //## begin ClientSession%345407AF0053.protected preserve=yes
      //## end ClientSession%345407AF0053.protected

  private:
    // Additional Private Declarations
      //## begin ClientSession%345407AF0053.private preserve=yes
      //## end ClientSession%345407AF0053.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin ClientSession::AliasCount%3CFF9AA20399.attr preserve=no  public: static int {V} 0
      static int m_lAliasCount;
      //## end ClientSession::AliasCount%3CFF9AA20399.attr

      //## begin ClientSession::ApplicationName%3E9C489B02EE.attr preserve=no  public: string {V} 
      string m_strApplicationName;
      //## end ClientSession::ApplicationName%3E9C489B02EE.attr

      //## begin ClientSession::ASCII%3E9C3DB70232.attr preserve=no  public: bool {V} false
      bool m_bASCII;
      //## end ClientSession::ASCII%3E9C3DB70232.attr

      //## Attribute: ClientRequest%45B62F510148
      //## begin ClientSession::ClientRequest%45B62F510148.attr preserve=no  private: static map<string,ClientRequest,less<string> >* {V} 0
      static map<string,ClientRequest,less<string> >* m_pClientRequest;
      //## end ClientSession::ClientRequest%45B62F510148.attr

      //## Attribute: ClientRequestKey%3E9EFD3102CE
      //## begin ClientSession::ClientRequestKey%3E9EFD3102CE.attr preserve=no  private: map<string,string,less<string> > {V} 
      map<string,string,less<string> > m_hClientRequestKey;
      //## end ClientSession::ClientRequestKey%3E9EFD3102CE.attr

      //## begin ClientSession::LastRequestTimestamp%3DEB6C4503B9.attr preserve=no  public: string {U} 
      string m_strLastRequestTimestamp;
      //## end ClientSession::LastRequestTimestamp%3DEB6C4503B9.attr

      //## begin ClientSession::ProcessTime%3A6C3ECE03BB.attr preserve=no  public: int {V} 0
      int m_lProcessTime;
      //## end ClientSession::ProcessTime%3A6C3ECE03BB.attr

      //## begin ClientSession::QueueTime%3A6C3E98024B.attr preserve=no  public: int {V} 0
      int m_lQueueTime;
      //## end ClientSession::QueueTime%3A6C3E98024B.attr

      //## begin ClientSession::RelationshipSegment%352BE1F10337.attr preserve=no  public: char* {V} 0
      char* m_pRelationshipSegment;
      //## end ClientSession::RelationshipSegment%352BE1F10337.attr

      //## begin ClientSession::Requests%3A6C3E7101E1.attr preserve=no  public: int {V} 0
      int m_lRequests;
      //## end ClientSession::Requests%3A6C3E7101E1.attr

      //## Attribute: Ticks%3E85E7E3001F
      //## begin ClientSession::Ticks%3E85E7E3001F.attr preserve=no  private: static double {V} 0
      static double m_dTicks;
      //## end ClientSession::Ticks%3E85E7E3001F.attr

      //## begin ClientSession::Timestamp%3919C08500DA.attr preserve=no  public: string {U} 
      string m_strTimestamp;
      //## end ClientSession::Timestamp%3919C08500DA.attr

      //## begin ClientSession::UserID%3E9C48AE007D.attr preserve=no  public: string {V} 
      string m_strUserID;
      //## end ClientSession::UserID%3E9C48AE007D.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%39FDB5EE01E5
      //## Role: ClientSession::<m_pCommonHeaderSegment>%39FDB5EF0055
      //## begin ClientSession::<m_pCommonHeaderSegment>%39FDB5EF0055.role preserve=no  public: segment::CommonHeaderSegment { -> RFHgN}
      segment::CommonHeaderSegment *m_pCommonHeaderSegment;
      //## end ClientSession::<m_pCommonHeaderSegment>%39FDB5EF0055.role

      //## Association: Connex Application::Client_CAT::<unnamed>%3A5F10D50386
      //## begin ClientSession::<m_hMessage>%3A5F10D602BF.role preserve=no  public: IF::Message { -> VHgN}
      IF::Message m_hMessage;
      //## end ClientSession::<m_hMessage>%3A5F10D602BF.role

      //## Association: Connex Application::Client_CAT::<unnamed>%3B5D69B0005D
      //## Role: ClientSession::<m_hResourceListSegment>%3B5D69B10109
      //## begin ClientSession::<m_hResourceListSegment>%3B5D69B10109.role preserve=no  public: usersegment::ResourceListSegment { -> 1VHgN}
      usersegment::ResourceListSegment m_hResourceListSegment;
      //## end ClientSession::<m_hResourceListSegment>%3B5D69B10109.role

    // Additional Implementation Declarations
      //## begin ClientSession%345407AF0053.implementation preserve=yes
      //## end ClientSession%345407AF0053.implementation

};

//## begin ClientSession%345407AF0053.postscript preserve=yes
//## end ClientSession%345407AF0053.postscript

//## begin module%368002C900BB.epilog preserve=yes
//## end module%368002C900BB.epilog


#endif
