//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3A5CB0E3008A.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3A5CB0E3008A.cm

//## begin module%3A5CB0E3008A.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3A5CB0E3008A.cp

//## Module: CXOSCI04%3A5CB0E3008A; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ci\CXOSCI04.cpp

//## begin module%3A5CB0E3008A.additionalIncludes preserve=no
//## end module%3A5CB0E3008A.additionalIncludes

//## begin module%3A5CB0E3008A.includes preserve=yes
// $Date:   Apr 07 2004 15:03:16  $ $Author:   D98833  $ $Revision:   1.3  $
//## end module%3A5CB0E3008A.includes

#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
//## begin module%3A5CB0E3008A.declarations preserve=no
//## end module%3A5CB0E3008A.declarations

//## begin module%3A5CB0E3008A.additionalDeclarations preserve=yes
//## end module%3A5CB0E3008A.additionalDeclarations


// Class ClientInterfaceVisitor 

ClientInterfaceVisitor::ClientInterfaceVisitor()
  //## begin ClientInterfaceVisitor::ClientInterfaceVisitor%3A5CB08D039E_const.hasinit preserve=no
  //## end ClientInterfaceVisitor::ClientInterfaceVisitor%3A5CB08D039E_const.hasinit
  //## begin ClientInterfaceVisitor::ClientInterfaceVisitor%3A5CB08D039E_const.initialization preserve=yes
  //## end ClientInterfaceVisitor::ClientInterfaceVisitor%3A5CB08D039E_const.initialization
{
  //## begin ClientInterfaceVisitor::ClientInterfaceVisitor%3A5CB08D039E_const.body preserve=yes
  //## end ClientInterfaceVisitor::ClientInterfaceVisitor%3A5CB08D039E_const.body
}


ClientInterfaceVisitor::~ClientInterfaceVisitor()
{
  //## begin ClientInterfaceVisitor::~ClientInterfaceVisitor%3A5CB08D039E_dest.body preserve=yes
  //## end ClientInterfaceVisitor::~ClientInterfaceVisitor%3A5CB08D039E_dest.body
}



//## Other Operations (implementation)
void ClientInterfaceVisitor::visitClientInterface (ClientInterface* pClientInterface)
{
  //## begin ClientInterfaceVisitor::visitClientInterface%3A5CB19A0015.body preserve=yes
  //## end ClientInterfaceVisitor::visitClientInterface%3A5CB19A0015.body
}

void ClientInterfaceVisitor::visitClientPool (ClientPool* pClientPool)
{
  //## begin ClientInterfaceVisitor::visitClientPool%3A6C81670258.body preserve=yes
  //## end ClientInterfaceVisitor::visitClientPool%3A6C81670258.body
}

void ClientInterfaceVisitor::visitClientRequest (ClientRequest* pClientRequest)
{
  //## begin ClientInterfaceVisitor::visitClientRequest%3A5CB1EE00D4.body preserve=yes
  //## end ClientInterfaceVisitor::visitClientRequest%3A5CB1EE00D4.body
}

void ClientInterfaceVisitor::visitClientSession (ClientSession* pClientSession)
{
  //## begin ClientInterfaceVisitor::visitClientSession%3A5CB20B01EF.body preserve=yes
  //## end ClientInterfaceVisitor::visitClientSession%3A5CB20B01EF.body
}

void ClientInterfaceVisitor::visitQueuedRequest (QueuedRequest* pQueuedRequest)
{
  //## begin ClientInterfaceVisitor::visitQueuedRequest%3A608C170277.body preserve=yes
  //## end ClientInterfaceVisitor::visitQueuedRequest%3A608C170277.body
}

void ClientInterfaceVisitor::visitServer (Server* pServer)
{
  //## begin ClientInterfaceVisitor::visitServer%3A606894009E.body preserve=yes
  //## end ClientInterfaceVisitor::visitServer%3A606894009E.body
}

void ClientInterfaceVisitor::visitServerPool (ServerPool* pServerPool)
{
  //## begin ClientInterfaceVisitor::visitServerPool%3A60689D008D.body preserve=yes
  //## end ClientInterfaceVisitor::visitServerPool%3A60689D008D.body
}

void ClientInterfaceVisitor::visitSlowQuery (SlowQuery* pSlowQuery)
{
  //## begin ClientInterfaceVisitor::visitSlowQuery%3A7996000332.body preserve=yes
  //## end ClientInterfaceVisitor::visitSlowQuery%3A7996000332.body
}

void ClientInterfaceVisitor::visitTrace (string* pText)
{
  //## begin ClientInterfaceVisitor::visitTrace%3A7C4FAB02D1.body preserve=yes
  //## end ClientInterfaceVisitor::visitTrace%3A7C4FAB02D1.body
}

// Additional Declarations
  //## begin ClientInterfaceVisitor%3A5CB08D039E.declarations preserve=yes
  //## end ClientInterfaceVisitor%3A5CB08D039E.declarations

//## begin module%3A5CB0E3008A.epilog preserve=yes
//## end module%3A5CB0E3008A.epilog
