//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A60565F03B3.cm preserve=no
//	$Date:   May 13 2020 10:54:58  $ $Author:   e1009510  $ $Revision:   1.20  $
//## end module%3A60565F03B3.cm

//## begin module%3A60565F03B3.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A60565F03B3.cp

//## Module: CXOSCI08%3A60565F03B3; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI08.cpp

//## begin module%3A60565F03B3.additionalIncludes preserve=no
//## end module%3A60565F03B3.additionalIncludes

//## begin module%3A60565F03B3.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
//## end module%3A60565F03B3.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSCI13_h
#include "CXODCI13.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSMN02_h
#include "CXODMN02.hpp"
#endif
#ifndef CXOSCI08_h
#include "CXODCI08.hpp"
#endif


//## begin module%3A60565F03B3.declarations preserve=no
//## end module%3A60565F03B3.declarations

//## begin module%3A60565F03B3.additionalDeclarations preserve=yes
//## end module%3A60565F03B3.additionalDeclarations


// Class ServerPool 

//## begin ServerPool::Instance%3A605C88039C.attr preserve=no  private: static ServerPool* {V} 0
ServerPool* ServerPool::m_pInstance = 0;
//## end ServerPool::Instance%3A605C88039C.attr

ServerPool::ServerPool()
  //## begin ServerPool::ServerPool%3A6056100124_const.hasinit preserve=no
      : m_lCursor(0)
  //## end ServerPool::ServerPool%3A6056100124_const.hasinit
  //## begin ServerPool::ServerPool%3A6056100124_const.initialization preserve=yes
  //## end ServerPool::ServerPool%3A6056100124_const.initialization
{
  //## begin ServerPool::ServerPool%3A6056100124_const.body preserve=yes
   memcpy(m_sID,"CI08",4);
   string strTemp;
   for (int i = 0;i < 200;++i)
      m_hTrace.push_back(strTemp);
  //## end ServerPool::ServerPool%3A6056100124_const.body
}


ServerPool::~ServerPool()
{
  //## begin ServerPool::~ServerPool%3A6056100124_dest.body preserve=yes
  //## end ServerPool::~ServerPool%3A6056100124_dest.body
}



//## Other Operations (implementation)
void ServerPool::accept (ClientInterfaceVisitor& hClientInterfaceVisitor)
{
  //## begin ServerPool::accept%3A607119025D.body preserve=yes
   hClientInterfaceVisitor.visitServerPool(this);
   map<string,Server,less<string> >::iterator pServer;
   for (pServer = m_hServer.begin();pServer != m_hServer.end();++pServer)
      (*pServer).second.accept(hClientInterfaceVisitor);
   vector<QueuedRequest>::iterator pQueuedRequest;
   for (pQueuedRequest = m_hQueuedRequest.begin();pQueuedRequest != m_hQueuedRequest.end();++pQueuedRequest)
      (*pQueuedRequest).accept(hClientInterfaceVisitor);
   map<string,SlowQuery,less<string> >::reverse_iterator pSlowQuery;
   for (pSlowQuery = m_hSlowQuery.rbegin();pSlowQuery != m_hSlowQuery.rend();++pSlowQuery)
      (*pSlowQuery).second.accept(hClientInterfaceVisitor);
   int i = m_lCursor - 1;
   int j = 200;
   while (j-- > 0)
   {
      if (i < 0)
         i = 199;
      hClientInterfaceVisitor.visitTrace(&m_hTrace[i]);
      --i;
   }
  //## end ServerPool::accept%3A607119025D.body
}

void ServerPool::acceptRequest (const string& strTimestamp, ClientInterfaceVisitor& hClientInterfaceVisitor)
{
  //## begin ServerPool::acceptRequest%3A79CFC20210.body preserve=yes
   map<string,SlowQuery,less<string> >::iterator pSlowQuery;
   pSlowQuery = m_hSlowQuery.find(strTimestamp);
   if (pSlowQuery != m_hSlowQuery.end())
      (*pSlowQuery).second.accept(hClientInterfaceVisitor);
  //## end ServerPool::acceptRequest%3A79CFC20210.body
}

void ServerPool::acceptServer (const string& strServer, ClientInterfaceVisitor& hClientInterfaceVisitor)
{
  //## begin ServerPool::acceptServer%3A6621EB0023.body preserve=yes
   map<string,Server,less<string> >::iterator pServer;
   pServer = m_hServer.find(strServer);
   if (pServer != m_hServer.end())
      (*pServer).second.accept(hClientInterfaceVisitor);
  //## end ServerPool::acceptServer%3A6621EB0023.body
}

void ServerPool::drop (const string& strServer)
{
  //## begin ServerPool::drop%3A69BA8D0162.body preserve=yes
   trace("Drop server",strServer.c_str());
   set<string,less<string> >::iterator p;
   map<string,set<string,less<string> >,less<string> >::iterator pService;
   for (pService = m_hService.begin();pService != m_hService.end();++pService)
   {
      p = (*pService).second.find(strServer);
      if (p != (*pService).second.end())
         (*pService).second.erase(p);
   }
   map<string,Server,less<string> >::iterator pServer;
   pServer = m_hServer.find(strServer);
   if (pServer != m_hServer.end())
      m_hServer.erase(pServer);
  //## end ServerPool::drop%3A69BA8D0162.body
}

void ServerPool::forward (const string& strServer)
{
  //## begin ServerPool::forward%3A644CD20000.body preserve=yes
   map<string,Server,less<string> >::iterator pServer;
   pServer = m_hServer.find(Message::instance(Message::INBOUND)->getSource());
   if (pServer == m_hServer.end())
      return;
   map<string,set<string,less<string> >,less<string> >::iterator pService;
   set<string,less<string> >::iterator p;
   vector<QueuedRequest>::iterator pQueuedRequest;
   for (pQueuedRequest = m_hQueuedRequest.begin();pQueuedRequest != m_hQueuedRequest.end();++pQueuedRequest)
   {
      pService = m_hService.find((*pQueuedRequest).getServiceName());
      if (pService != m_hService.end())
      {
         p = (*pService).second.find(strServer);
         if (p != (*pService).second.end())
         {
            trace(strServer.c_str(),"takes from queue",(*pQueuedRequest).getUserID().c_str(),(*pQueuedRequest).getServiceName().c_str());
            ClientPool::instance()->addQueueTime((*pQueuedRequest).getUserID(),(*pQueuedRequest).getQueueTime());
            if ((*pServer).second.send((*pQueuedRequest).getUserID(),
               (*pQueuedRequest).getQueueName(),
               (*pQueuedRequest).getServiceName(),
               (*pQueuedRequest).getMessage()))
            {
               m_hQueuedRequest.erase(pQueuedRequest);
               Count::set("CLIENT","## CL01 START CI","ITEMS",m_hQueuedRequest.size());
            }
            return;
         }
      }
   }
  //## end ServerPool::forward%3A644CD20000.body
}

string ServerPool::getServerName (string& strServiceName)
{
  //## begin ServerPool::getServerName%5583100D02BB.body preserve=yes
   string strName("");
   map<string,set<string,less<string> >,less<string> >::iterator pService;
   pService = m_hService.find(strServiceName);
   if (pService != m_hService.end())
   {
      map<string,Server,less<string> >::iterator pServer;
      set<string,less<string> >::iterator p;
      for (p = (*pService).second.begin();p != (*pService).second.end();++p)
      {
         pServer = m_hServer.find((*p));
         if (pServer != m_hServer.end())
            strName = (*pServer).second.getName();
      }
   }
   return strName;
  //## end ServerPool::getServerName%5583100D02BB.body
}

ServerPool* ServerPool::instance ()
{
  //## begin ServerPool::instance%3A605CB3031C.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ServerPool();
   return m_pInstance;
  //## end ServerPool::instance%3A605CB3031C.body
}

void ServerPool::logoff (const string& strUserID)
{
  //## begin ServerPool::logoff%3A6EDB9C012A.body preserve=yes
   vector<QueuedRequest>::iterator pQueuedRequest;
   for (pQueuedRequest = m_hQueuedRequest.begin();pQueuedRequest != m_hQueuedRequest.end();++pQueuedRequest)
      if ((*pQueuedRequest).getUserID() == strUserID)
      {
         m_hQueuedRequest.erase(pQueuedRequest);
         Count::set("CLIENT","## CL01 START CI","ITEMS",m_hQueuedRequest.size());
         break;
      }
  //## end ServerPool::logoff%3A6EDB9C012A.body
}

int ServerPool::onDisconnect (IF::Message& hMessage)
{
  //## begin ServerPool::onDisconnect%3A76D83D037E.body preserve=yes
   map<string,Server,less<string> >::iterator pServer;
   for (pServer = m_hServer.begin();pServer != m_hServer.end();++pServer)
      if ((*pServer).second.getQueueName() == hMessage.getSource())
      {
         if (!(*pServer).second.getUserID().empty())
            trace("Aborted request from",(*pServer).second.getUserID().c_str(),"interrupted");
         (*pServer).second.abort();
         break;
      }
   vector<QueuedRequest>::iterator pQueuedRequest;
   for (pQueuedRequest = m_hQueuedRequest.begin();pQueuedRequest != m_hQueuedRequest.end();++pQueuedRequest)
      if ((*pQueuedRequest).getQueueName() == hMessage.getSource())
      {
         trace("Aborted request from",(*pQueuedRequest).getUserID().c_str(),"dropped from queue");
         m_hQueuedRequest.erase(pQueuedRequest);
         Count::set("CLIENT","## CL01 START CI","ITEMS",m_hQueuedRequest.size());
         break;
      }
   return 0;
  //## end ServerPool::onDisconnect%3A76D83D037E.body
}

bool ServerPool::queue (const string& strUserID, const string& strServiceName, Message& hMessage)
{
  //## begin ServerPool::queue%3A60893303BD.body preserve=yes
   trace("New request",strServiceName.c_str(),"from",strUserID.c_str());
   string strApplicationName;
   ClientPool::instance()->getApplicationName(strUserID,strApplicationName);
   if (strApplicationName == "STS")
   {
      map<string,Server,less<string> >::iterator pServer;
      for (pServer = m_hServer.begin();pServer != m_hServer.end();++pServer)
         if ((*pServer).second.getUserID() == strUserID
            && (*pServer).second.getServiceName() == strServiceName)
            return false;
      vector<QueuedRequest>::iterator pQueuedRequest;
      for (pQueuedRequest = m_hQueuedRequest.begin();pQueuedRequest != m_hQueuedRequest.end();++pQueuedRequest)
         if ((*pQueuedRequest).getUserID() == strUserID
            && (*pQueuedRequest).getServiceName() == strServiceName)
            return false;
   }
   ClientPool::instance()->addRequest(strUserID);
   map<string,set<string,less<string> >,less<string> >::iterator pService;
   pService = m_hService.find(strServiceName);
   if (pService != m_hService.end())
   {
      map<string,Server,less<string> >::iterator pServer;
      set<string,less<string> >::iterator p;
      for (p = (*pService).second.begin();p != (*pService).second.end();++p)
      {
         pServer = m_hServer.find((*p));
         if (pServer != m_hServer.end()
            && (*pServer).second.getBusy() == false)
         {
            if ((*pServer).second.send(strUserID,hMessage.getSource(),strServiceName,hMessage))
            {
               trace((*pServer).second.getName().c_str(),"takes",strServiceName.c_str(),"immediately");
               return true;
            }
         }
      }
   }
   // add message to the queue
   trace("Push",strServiceName.c_str(),"on queue");
   QueuedRequest hQueuedRequest;
   m_hQueuedRequest.push_back(hQueuedRequest);
   m_hQueuedRequest.back().setUserID(strUserID);
   m_hQueuedRequest.back().setQueueName(hMessage.getSource());
   m_hQueuedRequest.back().setServiceName(strServiceName);
   m_hQueuedRequest.back().setMessage(hMessage);
   Count::set("CLIENT","## CL01 START CI","ITEMS",m_hQueuedRequest.size());
   return true;
  //## end ServerPool::queue%3A60893303BD.body
}

void ServerPool::saveSQL (map<string,Server,less<string> >::iterator pServer)
{
  //## begin ServerPool::saveSQL%3A79D7C30249.body preserve=yes
   if ((*pServer).second.getSQL().length() > 0
#ifndef DEVL
      && (*pServer).second.getProcessTime() > 120000
#endif
      )
   {
      if (m_hSlowQuery.size() > 99)
         m_hSlowQuery.erase(m_hSlowQuery.begin());
      SlowQuery hSlowQuery;
      hSlowQuery.setServiceName((*pServer).second.getServiceName());
      hSlowQuery.setSQL((*pServer).second.getSQL());
      hSlowQuery.setTicks((*pServer).second.getProcessTime());
      hSlowQuery.setTimestamp((*pServer).second.getTimestamp());
      hSlowQuery.setUserID((*pServer).second.getUserID());
      hSlowQuery.log();
      pair<map<string,SlowQuery,less<string> >::iterator,bool> hResult;
      hResult = m_hSlowQuery.insert(map<string,SlowQuery,less<string> >::value_type((*pServer).second.getTimestamp(),hSlowQuery));
   }
  //## end ServerPool::saveSQL%3A79D7C30249.body
}

void ServerPool::trace (const char* pszText1, const char* pszText2, const char* pszText3, const char* pszText4)
{
  //## begin ServerPool::trace%3A7C3BEE03B2.body preserve=yes
   char szTemp[12];
   snprintf(szTemp,sizeof(szTemp),"%02ld:%02ld:%02ld : ",Clock::instance()->getHour(),Clock::instance()->getMinute(),Clock::instance()->getSecond());
   string strText(szTemp);
   strText += pszText1;
   if (pszText2)
   {
      strText += ' ';
      strText += pszText2;
      if (pszText3)
      {
         strText += ' ';
         strText += pszText3;
         if (pszText4)
         {
            strText += ' ';
            strText += pszText4;
         }
      }
   }
   m_hTrace[m_lCursor] = strText;
   m_lCursor = (m_lCursor == 199) ? 0 : m_lCursor + 1;
  //## end ServerPool::trace%3A7C3BEE03B2.body
}

void ServerPool::update (Subject* pSubject)
{
  //## begin ServerPool::update%3A60570C03E4.body preserve=yes
   if (pSubject != Message::instance(Message::INBOUND))
      return;
   map<string,Server,less<string> >::iterator pServer;
   pServer = m_hServer.find(Message::instance(Message::INBOUND)->getSource());
   if (pServer == m_hServer.end())
   {
      Server hServer;
      hServer.setName(Message::instance(Message::INBOUND)->getSource());
      pair<map<string,Server,less<string> >::iterator,bool> hResult;
      hResult = m_hServer.insert(map<string,Server,less<string> >::value_type(Message::instance(Message::INBOUND)->getSource(),hServer));
      pServer = hResult.first;
   }
   if (Message::instance(Message::INBOUND)->messageID() == "S0004R")
   {
      string strServiceName(Message::instance(Message::INBOUND)->data(),8);
      size_t pos = strServiceName.find_last_not_of(' ');
      if (pos != string::npos)
         strServiceName.erase(pos + 1);
      trace((*pServer).second.getName().c_str(),"provides service",strServiceName.c_str());
      map<string,set<string,less<string> >,less<string> >::iterator pService;
      pService = m_hService.find(strServiceName);
      if (pService == m_hService.end())
      {
         set<string,less<string> > hServer;
         pair<map<string,set<string,less<string> >,less<string> >::iterator,bool> hResult;
         hResult = m_hService.insert(map<string,set<string,less<string> >,less<string> >::value_type(strServiceName,hServer));
         pService = hResult.first;
      }
      if (Message::instance(Message::INBOUND)->data()[8] == 'Y')
      {
         (*pService).second.insert(Message::instance(Message::INBOUND)->getSource());
         if ((*pServer).second.getBusy() == false)
            forward(Message::instance(Message::INBOUND)->getSource());
      }
      else
         (*pService).second.erase(Message::instance(Message::INBOUND)->getSource());
   }
   else
   if (Message::instance(Message::INBOUND)->messageID() == "S0009R")
   {
      trace((*pServer).second.getName().c_str(),"is now idle");
      ClientPool::instance()->addProcessTime((*pServer).second.getUserID(),(*pServer).second.getProcessTime());
      saveSQL(pServer);
      (*pServer).second.idle();
      forward(Message::instance(Message::INBOUND)->getSource());
   }
   else
   if (Message::instance(Message::INBOUND)->messageID() == "S0003D")
   {
      // message returned ... server shutdown or abended
      queue((*pServer).second.getUserID(),(*pServer).second.getServiceName(),(*pServer).second.getMessage());
      drop(Message::instance(Message::INBOUND)->getSource());
   }
   else
   if (Message::instance(Message::INBOUND)->messageID() == "S0010D")
   {
      drop(Message::instance(Message::INBOUND)->getSource());
   }
   else
   if (Message::instance(Message::INBOUND)->messageID() == "S0008D")
   {
      saveSQL(pServer);
      string strSQL(Message::instance(Message::INBOUND)->data(),Message::instance(Message::INBOUND)->dataLength());
      (*pServer).second.setSQL(strSQL);
   }
   else
   if (Message::instance(Message::INBOUND)->messageID() == "S0003R")
   {
      (*pServer).second.setUserID("");
   }
  //## end ServerPool::update%3A60570C03E4.body
}

// Additional Declarations
  //## begin ServerPool%3A6056100124.declarations preserve=yes
  //## end ServerPool%3A6056100124.declarations

//## begin module%3A60565F03B3.epilog preserve=yes
//## end module%3A60565F03B3.epilog
