//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A79C20D023D.cm preserve=no
//	$Date:   Jun 22 2017 08:02:22  $ $Author:   e1009839  $ $Revision:   1.6  $
//## end module%3A79C20D023D.cm

//## begin module%3A79C20D023D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A79C20D023D.cp

//## Module: CXOSCI16%3A79C20D023D; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI16.cpp

//## begin module%3A79C20D023D.additionalIncludes preserve=no
//## end module%3A79C20D023D.additionalIncludes

//## begin module%3A79C20D023D.includes preserve=yes
//## end module%3A79C20D023D.includes

#ifndef CXOSCI14_h
#include "CXODCI14.hpp"
#endif
#ifndef CXOSCI16_h
#include "CXODCI16.hpp"
#endif


//## begin module%3A79C20D023D.declarations preserve=no
//## end module%3A79C20D023D.declarations

//## begin module%3A79C20D023D.additionalDeclarations preserve=yes
#include "CXODRU32.hpp"
   struct sSlowSQL
   {
      char sDate[9];
      short int iNull0;
      char sTime[7];
      short int iNull1;
      char sMessage[65];
      short int iNull2;
      int lTicks;
      short int iNull3;
   };
#include "CXODRU33.hpp"
//## end module%3A79C20D023D.additionalDeclarations


// Class ClientDisplaySlowSQL 

ClientDisplaySlowSQL::ClientDisplaySlowSQL()
  //## begin ClientDisplaySlowSQL::ClientDisplaySlowSQL%3A79C1070100_const.hasinit preserve=no
      : m_psDescription(0),
        m_lRows(0)
  //## end ClientDisplaySlowSQL::ClientDisplaySlowSQL%3A79C1070100_const.hasinit
  //## begin ClientDisplaySlowSQL::ClientDisplaySlowSQL%3A79C1070100_const.initialization preserve=yes
  //## end ClientDisplaySlowSQL::ClientDisplaySlowSQL%3A79C1070100_const.initialization
{
  //## begin ClientDisplaySlowSQL::ClientDisplaySlowSQL%3A79C1070100_const.body preserve=yes
   memcpy(m_sID,"CI16",4);
#include "CXODRU32.hpp"
   struct hDescription
   {
      char sColumnName[18];
      short int nDataType;
      int nPrecision;
      short int nScale;
   };
#include "CXODRU33.hpp"
   int j = 4;
   char* pszColumnName[4] = {"DATE","TIME","SQL","TICKS"};
   int nPrecision[4] = {9,7,65,0};
   int k = 4 + (j * sizeof(struct hDescription));
   m_psDescription = new char[k];
   memset(m_psDescription,' ',k);
   memcpy(m_psDescription,&j,sizeof(int));
   hDescription* p = (hDescription*)(m_psDescription + 4);
   for (int i = 0;i < j;++i)
   {
      memcpy(p->sColumnName,pszColumnName[i],strlen(pszColumnName[i]));
      if (nPrecision[i] == 0)
      {
         p->nDataType = 4;
         p->nPrecision = 4;
      }
      else
      {
         p->nDataType = 1;
         p->nPrecision = nPrecision[i];
      }
      p->nScale = 0;
      ++p;
   }
  //## end ClientDisplaySlowSQL::ClientDisplaySlowSQL%3A79C1070100_const.body
}


ClientDisplaySlowSQL::~ClientDisplaySlowSQL()
{
  //## begin ClientDisplaySlowSQL::~ClientDisplaySlowSQL%3A79C1070100_dest.body preserve=yes
   if (m_lRows == 0)
   {
      struct sSlowSQL hSlowSQL;
      memset((char*)&hSlowSQL,' ',sizeof(struct sSlowSQL));
      memcpy(hSlowSQL.sMessage,"NONE",4);
      hSlowSQL.lTicks = 0;
      m_hResultSet.addRow(m_psDescription,(char*)&hSlowSQL);
   }
   m_hResultSet.close();
   delete [] m_psDescription;
  //## end ClientDisplaySlowSQL::~ClientDisplaySlowSQL%3A79C1070100_dest.body
}



//## Other Operations (implementation)
void ClientDisplaySlowSQL::visitSlowQuery (SlowQuery* pSlowQuery)
{
  //## begin ClientDisplaySlowSQL::visitSlowQuery%3A79C2D30089.body preserve=yes
   struct sSlowSQL hSlowSQL;
   //int k = (pSlowQuery->getTimestamp().length() > 8) ? 8 : pSlowQuery->getTimestamp().length();
   int j;
   size_t pos = 0;
   int i = pSlowQuery->getSQL().length();
   while (i > 0)
   {
      memset((char*)&hSlowSQL,' ',sizeof(struct sSlowSQL));
      //memcpy(hSlowSQL.sTimestamp,pSlowQuery->getTimestamp().data(),k);
      memcpy(hSlowSQL.sDate,pSlowQuery->getTimestamp().data(),8);
      memcpy(hSlowSQL.sTime,pSlowQuery->getTimestamp().data() + 8,6);
      hSlowSQL.lTicks = pSlowQuery->getTicks();
      j = (i > 64) ? 64 : i;
      memcpy(hSlowSQL.sMessage,pSlowQuery->getSQL().data() + pos,j);
      m_hResultSet.addRow(m_psDescription,(char*)&hSlowSQL);
      ++m_lRows;
      pos += j;
      i -= j;
   }
  //## end ClientDisplaySlowSQL::visitSlowQuery%3A79C2D30089.body
}

// Additional Declarations
  //## begin ClientDisplaySlowSQL%3A79C1070100.declarations preserve=yes
  //## end ClientDisplaySlowSQL%3A79C1070100.declarations

//## begin module%3A79C20D023D.epilog preserve=yes
//## end module%3A79C20D023D.epilog

