//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A7994BB00C7.cm preserve=no
//	$Date:   Jun 22 2017 07:40:08  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3A7994BB00C7.cm

//## begin module%3A7994BB00C7.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A7994BB00C7.cp

//## Module: CXOSCI15%3A7994BB00C7; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI15.hpp

#ifndef CXOSCI15_h
#define CXOSCI15_h 1

//## begin module%3A7994BB00C7.additionalIncludes preserve=no
//## end module%3A7994BB00C7.additionalIncludes

//## begin module%3A7994BB00C7.includes preserve=yes
//## end module%3A7994BB00C7.includes

#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSIF37_h
#include "CXODIF37.hpp"
#endif

class SlowQuery;

//## begin module%3A7994BB00C7.declarations preserve=no
//## end module%3A7994BB00C7.declarations

//## begin module%3A7994BB00C7.additionalDeclarations preserve=yes
//## end module%3A7994BB00C7.additionalDeclarations


//## begin ClientDisplaySlowRequests%3A7991600130.preface preserve=yes
//## end ClientDisplaySlowRequests%3A7991600130.preface

//## Class: ClientDisplaySlowRequests%3A7991600130
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3A799966030B;SlowQuery { -> F}

class ClientDisplaySlowRequests : public ClientInterfaceVisitor  //## Inherits: <unnamed>%3A79917500EB
{
  //## begin ClientDisplaySlowRequests%3A7991600130.initialDeclarations preserve=yes
  //## end ClientDisplaySlowRequests%3A7991600130.initialDeclarations

  public:
    //## Constructors (generated)
      ClientDisplaySlowRequests();

    //## Destructor (generated)
      virtual ~ClientDisplaySlowRequests();


    //## Other Operations (specified)
      //## Operation: visitSlowQuery%3A7999560069
      virtual void visitSlowQuery (SlowQuery* pSlowQuery);

    // Additional Public Declarations
      //## begin ClientDisplaySlowRequests%3A7991600130.public preserve=yes
      //## end ClientDisplaySlowRequests%3A7991600130.public

  protected:
    // Additional Protected Declarations
      //## begin ClientDisplaySlowRequests%3A7991600130.protected preserve=yes
      //## end ClientDisplaySlowRequests%3A7991600130.protected

  private:
    // Additional Private Declarations
      //## begin ClientDisplaySlowRequests%3A7991600130.private preserve=yes
      //## end ClientDisplaySlowRequests%3A7991600130.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Description%3A79BF9F0315
      //## begin ClientDisplaySlowRequests::Description%3A79BF9F0315.attr preserve=no  private: char* {V} 0
      char* m_psDescription;
      //## end ClientDisplaySlowRequests::Description%3A79BF9F0315.attr

      //## Attribute: Rows%3A7A077300E5
      //## begin ClientDisplaySlowRequests::Rows%3A7A077300E5.attr preserve=no  private: int {V} 0
      int m_lRows;
      //## end ClientDisplaySlowRequests::Rows%3A7A077300E5.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%3A79BED70227
      //## Role: ClientDisplaySlowRequests::<m_hResultSet>%3A79BED800D4
      //## begin ClientDisplaySlowRequests::<m_hResultSet>%3A79BED800D4.role preserve=no  public: IF::ResultSet { -> VHgN}
      IF::ResultSet m_hResultSet;
      //## end ClientDisplaySlowRequests::<m_hResultSet>%3A79BED800D4.role

    // Additional Implementation Declarations
      //## begin ClientDisplaySlowRequests%3A7991600130.implementation preserve=yes
      //## end ClientDisplaySlowRequests%3A7991600130.implementation

};

//## begin ClientDisplaySlowRequests%3A7991600130.postscript preserve=yes
//## end ClientDisplaySlowRequests%3A7991600130.postscript

//## begin module%3A7994BB00C7.epilog preserve=yes
//## end module%3A7994BB00C7.epilog


#endif
