//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A60565D03C4.cm preserve=no
//	$Date:   Jun 26 2017 07:46:28  $ $Author:   e1009839  $ $Revision:   1.9  $
//## end module%3A60565D03C4.cm

//## begin module%3A60565D03C4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A60565D03C4.cp

//## Module: CXOSCI08%3A60565D03C4; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI08.hpp

#ifndef CXOSCI08_h
#define CXOSCI08_h 1

//## begin module%3A60565D03C4.additionalIncludes preserve=no
//## end module%3A60565D03C4.additionalIncludes

//## begin module%3A60565D03C4.includes preserve=yes
#include <map>
#include <set>
#include <vector>
//## end module%3A60565D03C4.includes

#ifndef CXOSCI14_h
#include "CXODCI14.hpp"
#endif
#ifndef CXOSCI11_h
#include "CXODCI11.hpp"
#endif
#ifndef CXOSCI09_h
#include "CXODCI09.hpp"
#endif
#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Queue;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class Count;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

class ClientInterfaceVisitor;
class ClientPool;

//## begin module%3A60565D03C4.declarations preserve=no
//## end module%3A60565D03C4.declarations

//## begin module%3A60565D03C4.additionalDeclarations preserve=yes
//## end module%3A60565D03C4.additionalDeclarations


//## begin ServerPool%3A6056100124.preface preserve=yes
//## end ServerPool%3A6056100124.preface

//## Class: ServerPool%3A6056100124
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3A6057040111;IF::Message { -> F}
//## Uses: <unnamed>%3A60713902C7;ClientInterfaceVisitor { -> F}
//## Uses: <unnamed>%3A69B94A00E5;IF::Queue { -> F}
//## Uses: <unnamed>%3A6EDBDD0390;ClientPool { -> F}
//## Uses: <unnamed>%3A7C4F450357;timer::Clock { -> F}
//## Uses: <unnamed>%4BCF38460006;monitor::Count { -> F}

class ServerPool : public reusable::Observer  //## Inherits: <unnamed>%3A60562B0278
{
  //## begin ServerPool%3A6056100124.initialDeclarations preserve=yes
  //## end ServerPool%3A6056100124.initialDeclarations

  public:
    //## Constructors (generated)
      ServerPool();

    //## Destructor (generated)
      virtual ~ServerPool();


    //## Other Operations (specified)
      //## Operation: accept%3A607119025D
      void accept (ClientInterfaceVisitor& hClientInterfaceVisitor);

      //## Operation: acceptRequest%3A79CFC20210
      void acceptRequest (const string& strTimestamp, ClientInterfaceVisitor& hClientInterfaceVisitor);

      //## Operation: acceptServer%3A6621EB0023
      void acceptServer (const string& strServer, ClientInterfaceVisitor& hClientInterfaceVisitor);

      //## Operation: drop%3A69BA8D0162
      void drop (const string& strServer);

      //## Operation: forward%3A644CD20000
      void forward (const string& strServer);

      //## Operation: getServerName%5583100D02BB
      string getServerName (string& strServiceName);

      //## Operation: instance%3A605CB3031C
      static ServerPool* instance ();

      //## Operation: logoff%3A6EDB9C012A
      void logoff (const string& strUserID);

      //## Operation: onDisconnect%3A76D83D037E
      int onDisconnect (IF::Message& hMessage);

      //## Operation: queue%3A60893303BD
      bool queue (const string& strUserID, const string& strServiceName, Message& hMessage);

      //## Operation: saveSQL%3A79D7C30249
      void saveSQL (map<string,Server,less<string> >::iterator pServer);

      //## Operation: trace%3A7C3BEE03B2
      void trace (const char* pszText1, const char* pszText2 = 0, const char* pszText3 = 0, const char* pszText4 = 0);

      //## Operation: update%3A60570C03E4
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin ServerPool%3A6056100124.public preserve=yes
      //## end ServerPool%3A6056100124.public

  protected:
    // Additional Protected Declarations
      //## begin ServerPool%3A6056100124.protected preserve=yes
      //## end ServerPool%3A6056100124.protected

  private:
    // Additional Private Declarations
      //## begin ServerPool%3A6056100124.private preserve=yes
      //## end ServerPool%3A6056100124.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Cursor%443BA95A035B
      //## begin ServerPool::Cursor%443BA95A035B.attr preserve=no  private: int {V} 0
      int m_lCursor;
      //## end ServerPool::Cursor%443BA95A035B.attr

      //## Attribute: Instance%3A605C88039C
      //## begin ServerPool::Instance%3A605C88039C.attr preserve=no  private: static ServerPool* {V} 0
      static ServerPool* m_pInstance;
      //## end ServerPool::Instance%3A605C88039C.attr

      //## Attribute: Service%443BA94200CB
      //## begin ServerPool::Service%443BA94200CB.attr preserve=no  private: map<string,set<string,less<string> >,less<string> > {V} 
      map<string,set<string,less<string> >,less<string> > m_hService;
      //## end ServerPool::Service%443BA94200CB.attr

      //## Attribute: Trace%443BA9200109
      //## begin ServerPool::Trace%443BA9200109.attr preserve=no  private: vector<string> {V} 
      vector<string> m_hTrace;
      //## end ServerPool::Trace%443BA9200109.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%3A60631C036C
      //## Role: ServerPool::<m_hServer>%3A60631D02D7
      //## Qualifier: Name%3A60634703E6; string
      //## begin ServerPool::<m_hServer>%3A60631D02D7.role preserve=no  public: Server { -> VHgN}
      map<string, Server, less<string> > m_hServer;
      //## end ServerPool::<m_hServer>%3A60631D02D7.role

      //## Association: Connex Application::Client_CAT::<unnamed>%3A608D8500A6
      //## Role: ServerPool::<m_hQueuedRequest>%3A608D8503B4
      //## begin ServerPool::<m_hQueuedRequest>%3A608D8503B4.role preserve=no  public: QueuedRequest {1 -> 0..nVHgN}
      vector<QueuedRequest> m_hQueuedRequest;
      //## end ServerPool::<m_hQueuedRequest>%3A608D8503B4.role

      //## Association: Connex Application::Client_CAT::<unnamed>%3A7996A5039D
      //## Role: ServerPool::<m_hSlowQuery>%3A7996A60344
      //## Qualifier: Timestamp%3A79D0AA02A0; string
      //## begin ServerPool::<m_hSlowQuery>%3A7996A60344.role preserve=no  public: SlowQuery { -> VHgN}
      map<string, SlowQuery, less<string> > m_hSlowQuery;
      //## end ServerPool::<m_hSlowQuery>%3A7996A60344.role

    // Additional Implementation Declarations
      //## begin ServerPool%3A6056100124.implementation preserve=yes
      //## end ServerPool%3A6056100124.implementation

};

//## begin ServerPool%3A6056100124.postscript preserve=yes
//## end ServerPool%3A6056100124.postscript

//## begin module%3A60565D03C4.epilog preserve=yes
//## end module%3A60565D03C4.epilog


#endif
