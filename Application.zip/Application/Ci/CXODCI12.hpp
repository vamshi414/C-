//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A62F95C0122.cm preserve=no
//	$Date:   Jun 22 2017 07:34:04  $ $Author:   e1009839  $ $Revision:   1.4  $
//## end module%3A62F95C0122.cm

//## begin module%3A62F95C0122.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A62F95C0122.cp

//## Module: CXOSCI12%3A62F95C0122; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI12.hpp

#ifndef CXOSCI12_h
#define CXOSCI12_h 1

//## begin module%3A62F95C0122.additionalIncludes preserve=no
//## end module%3A62F95C0122.additionalIncludes

//## begin module%3A62F95C0122.includes preserve=yes
//## end module%3A62F95C0122.includes

#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSIF37_h
#include "CXODIF37.hpp"
#endif

class QueuedRequest;

//## begin module%3A62F95C0122.declarations preserve=no
//## end module%3A62F95C0122.declarations

//## begin module%3A62F95C0122.additionalDeclarations preserve=yes
//## end module%3A62F95C0122.additionalDeclarations


//## begin ClientDisplayQueue%3A62F87C00D0.preface preserve=yes
//## end ClientDisplayQueue%3A62F87C00D0.preface

//## Class: ClientDisplayQueue%3A62F87C00D0
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3A62F92100C3;QueuedRequest { -> F}

class ClientDisplayQueue : public ClientInterfaceVisitor  //## Inherits: <unnamed>%3A62F89200EF
{
  //## begin ClientDisplayQueue%3A62F87C00D0.initialDeclarations preserve=yes
  //## end ClientDisplayQueue%3A62F87C00D0.initialDeclarations

  public:
    //## Constructors (generated)
      ClientDisplayQueue();

    //## Destructor (generated)
      virtual ~ClientDisplayQueue();


    //## Other Operations (specified)
      //## Operation: visitQueuedRequest%3A62F8D000DA
      virtual void visitQueuedRequest (QueuedRequest* pQueuedRequest);

    // Additional Public Declarations
      //## begin ClientDisplayQueue%3A62F87C00D0.public preserve=yes
      //## end ClientDisplayQueue%3A62F87C00D0.public

  protected:
    // Additional Protected Declarations
      //## begin ClientDisplayQueue%3A62F87C00D0.protected preserve=yes
      //## end ClientDisplayQueue%3A62F87C00D0.protected

  private:
    // Additional Private Declarations
      //## begin ClientDisplayQueue%3A62F87C00D0.private preserve=yes
      //## end ClientDisplayQueue%3A62F87C00D0.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Description%3A62F8B2018B
      //## begin ClientDisplayQueue::Description%3A62F8B2018B.attr preserve=no  private: char* {V} 0
      char* m_psDescription;
      //## end ClientDisplayQueue::Description%3A62F8B2018B.attr

      //## Attribute: Rows%3A7A06F7010E
      //## begin ClientDisplayQueue::Rows%3A7A06F7010E.attr preserve=no  private: int {V} 0
      int m_lRows;
      //## end ClientDisplayQueue::Rows%3A7A06F7010E.attr

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%3A62F8ED03A3
      //## Role: ClientDisplayQueue::<m_hResultSet>%3A62F8EE0318
      //## begin ClientDisplayQueue::<m_hResultSet>%3A62F8EE0318.role preserve=no  public: IF::ResultSet { -> VHgN}
      IF::ResultSet m_hResultSet;
      //## end ClientDisplayQueue::<m_hResultSet>%3A62F8EE0318.role

    // Additional Implementation Declarations
      //## begin ClientDisplayQueue%3A62F87C00D0.implementation preserve=yes
      //## end ClientDisplayQueue%3A62F87C00D0.implementation

};

//## begin ClientDisplayQueue%3A62F87C00D0.postscript preserve=yes
//## end ClientDisplayQueue%3A62F87C00D0.postscript

//## begin module%3A62F95C0122.epilog preserve=yes
//## end module%3A62F95C0122.epilog


#endif
