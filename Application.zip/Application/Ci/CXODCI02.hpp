//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3680031800DD.cm preserve=no
//	$Date:   May 08 2013 16:40:02  $ $Author:   e1009591  $ $Revision:   1.10  $
//## end module%3680031800DD.cm

//## begin module%3680031800DD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3680031800DD.cp

//## Module: CXOSCI02%3680031800DD; Package specification
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.3B.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXODCI02.hpp

#ifndef CXOSCI02_h
#define CXOSCI02_h 1

//## begin module%3680031800DD.additionalIncludes preserve=no
//## end module%3680031800DD.additionalIncludes

//## begin module%3680031800DD.includes preserve=yes
// $Date:   May 08 2013 16:40:02  $ $Author:   e1009591  $ $Revision:   1.10  $
//## end module%3680031800DD.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ResponseTimeSegment;
class MultipleRowContextSegment;
class InformationSegment;
} // namespace segment

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class ConfigurationDataSegment;

} // namespace usersegment

//## begin module%3680031800DD.declarations preserve=no
//## end module%3680031800DD.declarations

//## begin module%3680031800DD.additionalDeclarations preserve=yes
//## end module%3680031800DD.additionalDeclarations


//## begin ConfigurationFile%352B87AF0292.preface preserve=yes
//## end ConfigurationFile%352B87AF0292.preface

//## Class: ConfigurationFile%352B87AF0292
//## Category: Connex Application::Client_CAT%3451F4E4026D
//## Subsystem: CI%3597E8190342
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%37D940F0011A;segment::CommonHeaderSegment { -> }
//## Uses: <unnamed>%37D940F20394;usersegment::ConfigurationDataSegment { -> F}
//## Uses: <unnamed>%37D940F501D5;segment::InformationSegment { -> F}
//## Uses: <unnamed>%37D940F8019E;segment::MultipleRowContextSegment { -> F}
//## Uses: <unnamed>%37D940FC00B3;segment::ResponseTimeSegment { -> F}

class ConfigurationFile : public reusable::Object  //## Inherits: <unnamed>%352B8B14011F
{
  //## begin ConfigurationFile%352B87AF0292.initialDeclarations preserve=yes
  //## end ConfigurationFile%352B87AF0292.initialDeclarations

  public:
    //## Constructors (generated)
      ConfigurationFile();

    //## Destructor (generated)
      virtual ~ConfigurationFile();


    //## Other Operations (specified)
      //## Operation: parse%5184046802FB
      void parse (const Message& hMessage);

      //## Operation: read%352B898C02AC
      int read (char** ppSegmentID, segment::CommonHeaderSegment& hCommonHeaderSegment, segment::MultipleRowContextSegment& hMultipleRowContextSegment, segment::ResponseTimeSegment& hResponseTimeSegment);

      //## Operation: read%352B89900262
      int read (const char* pszSection, char** ppSegmentID, segment::CommonHeaderSegment& hCommonHeaderSegment, segment::MultipleRowContextSegment& hMultipleRowContextSegment, segment::ResponseTimeSegment& hResponseTimeSegment);

    // Additional Public Declarations
      //## begin ConfigurationFile%352B87AF0292.public preserve=yes
      //## end ConfigurationFile%352B87AF0292.public

  protected:
    // Additional Protected Declarations
      //## begin ConfigurationFile%352B87AF0292.protected preserve=yes
      //## end ConfigurationFile%352B87AF0292.protected

  private:
    // Additional Private Declarations
      //## begin ConfigurationFile%352B87AF0292.private preserve=yes
      //## end ConfigurationFile%352B87AF0292.private

  private: //## implementation
    // Data Members for Class Attributes

    // Data Members for Associations

      //## Association: Connex Application::Client_CAT::<unnamed>%37D93FA001D5
      //## Role: ConfigurationFile::<m_hExtract>%37D93FA1026D
      //## begin ConfigurationFile::<m_hExtract>%37D93FA1026D.role preserve=no  public: IF::FlatFile { -> VHgN}
      IF::FlatFile *m_pExtract;
      //## end ConfigurationFile::<m_hExtract>%37D93FA1026D.role

    // Additional Implementation Declarations
      //## begin ConfigurationFile%352B87AF0292.implementation preserve=yes
      string m_strEXTRACT_GRP_ID[2];
      string m_strCC_TSTAMP_CHANGE[2];
      //## end ConfigurationFile%352B87AF0292.implementation
};

//## begin ConfigurationFile%352B87AF0292.postscript preserve=yes
//## end ConfigurationFile%352B87AF0292.postscript

//## begin module%3680031800DD.epilog preserve=yes
//## end module%3680031800DD.epilog


#endif
