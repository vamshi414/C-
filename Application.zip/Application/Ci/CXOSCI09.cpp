//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A6061BA00EC.cm preserve=no
//	$Date:   Jun 26 2017 07:46:42  $ $Author:   e1009839  $ $Revision:   1.7  $
//## end module%3A6061BA00EC.cm

//## begin module%3A6061BA00EC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3A6061BA00EC.cp

//## Module: CXOSCI09%3A6061BA00EC; Package body
//## Subsystem: CI%3597E8190342
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\ConnexPlatform\Server\Application\Ci\CXOSCI09.cpp

//## begin module%3A6061BA00EC.additionalIncludes preserve=no
//## end module%3A6061BA00EC.additionalIncludes

//## begin module%3A6061BA00EC.includes preserve=yes
//## end module%3A6061BA00EC.includes

#ifndef CXOSCI04_h
#include "CXODCI04.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSCI09_h
#include "CXODCI09.hpp"
#endif


//## begin module%3A6061BA00EC.declarations preserve=no
//## end module%3A6061BA00EC.declarations

//## begin module%3A6061BA00EC.additionalDeclarations preserve=yes
//## end module%3A6061BA00EC.additionalDeclarations


// Class Server 

Server::Server()
  //## begin Server::Server%3A606173034D_const.hasinit preserve=no
      : m_bBusy(false),
        m_dTicks(0)
  //## end Server::Server%3A606173034D_const.hasinit
  //## begin Server::Server%3A606173034D_const.initialization preserve=yes
  //## end Server::Server%3A606173034D_const.initialization
{
  //## begin Server::Server%3A606173034D_const.body preserve=yes
   memcpy(m_sID,"CI09",4);
  //## end Server::Server%3A606173034D_const.body
}

Server::Server(const Server &right)
  //## begin Server::Server%3A606173034D_copy.hasinit preserve=no
  //## end Server::Server%3A606173034D_copy.hasinit
  //## begin Server::Server%3A606173034D_copy.initialization preserve=yes
  //## end Server::Server%3A606173034D_copy.initialization
{
  //## begin Server::Server%3A606173034D_copy.body preserve=yes
   memcpy(m_sID,"CI09",4);
   m_bBusy = right.m_bBusy;
   m_strName = right.m_strName;
   m_strSQL = right.m_strSQL;
   m_dTicks = right.m_dTicks;
  //## end Server::Server%3A606173034D_copy.body
}


Server::~Server()
{
  //## begin Server::~Server%3A606173034D_dest.body preserve=yes
  //## end Server::~Server%3A606173034D_dest.body
}


Server & Server::operator=(const Server &right)
{
  //## begin Server::operator=%3A606173034D_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_bBusy = right.m_bBusy;
   m_strName = right.m_strName;
   m_strSQL = right.m_strSQL;
   return *this;
  //## end Server::operator=%3A606173034D_assign.body
}



//## Other Operations (implementation)
void Server::abort ()
{
  //## begin Server::abort%3A76E4060079.body preserve=yes
   Message::instance(Message::OUTBOUND)->reset("CLISRV","S0009D",false);
   Message::instance(Message::OUTBOUND)->setDataLength(0);
   Message::instance(Message::OUTBOUND)->send(m_strName.c_str());
  //## end Server::abort%3A76E4060079.body
}

void Server::accept (ClientInterfaceVisitor& hClientInterfaceVisitor)
{
  //## begin Server::accept%3A60716003E5.body preserve=yes
   hClientInterfaceVisitor.visitServer(this);
  //## end Server::accept%3A60716003E5.body
}

int Server::getProcessTime ()
{
  //## begin Server::getProcessTime%3A7094A80079.body preserve=yes
   double d = 0;
   if (m_bBusy)
      d = (Clock::instance()->getTicks() - m_dTicks) / 4294967.296;
   return (int)d;
  //## end Server::getProcessTime%3A7094A80079.body
}

void Server::idle ()
{
  //## begin Server::idle%3A69BD88008D.body preserve=yes
   setBusy(false);
   m_strUserID.erase();
   m_strQueueName.erase();
  //## end Server::idle%3A69BD88008D.body
}

bool Server::send (const string& strUserID, const string& strQueueName, const string& strServiceName, Message& hMessage)
{
  //## begin Server::send%3A65940A0206.body preserve=yes
   m_bBusy = (hMessage.send(m_strName.c_str()) == 0);
   if (m_bBusy)
   {
      m_strUserID = strUserID;
      m_strQueueName = strQueueName;
      m_strServiceName = strServiceName;
      m_hMessage = hMessage;
      m_dTicks = Clock::instance()->getTicks();
      m_strTimestamp = Clock::instance()->getYYYYMMDDHHMMSS();
      m_strSQL.erase();
   }
   return m_bBusy;
  //## end Server::send%3A65940A0206.body
}

// Additional Declarations
  //## begin Server%3A606173034D.declarations preserve=yes
  //## end Server%3A606173034D.declarations

//## begin module%3A6061BA00EC.epilog preserve=yes
//## end module%3A6061BA00EC.epilog
