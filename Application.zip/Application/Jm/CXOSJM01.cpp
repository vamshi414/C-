//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%370F698402BB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%370F698402BB.cm

//## begin module%370F698402BB.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%370F698402BB.cp

//## Module: CXOSJM01%370F698402BB; Package body
//## Subsystem: JM%370F6722014C
//## Source file: C:\Devel\ConnexPlatform\Server\Application\Jm\CXOSJM01.cpp

//## begin module%370F698402BB.additionalIncludes preserve=no
//## end module%370F698402BB.additionalIncludes

//## begin module%370F698402BB.includes preserve=yes
// $Date:   Apr 21 2017 14:02:40  $ $Author:   e1009610  $ $Revision:   1.7  $
#include "CXODRU24.hpp"
//## end module%370F698402BB.includes

#ifndef CXOSJM01_h
#include "CXODJM01.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif


//## begin module%370F698402BB.declarations preserve=no
//## end module%370F698402BB.declarations

//## begin module%370F698402BB.additionalDeclarations preserve=yes
//## end module%370F698402BB.additionalDeclarations


// Class BatchJob 




BatchJob::BatchJob()
  //## begin BatchJob::BatchJob%370F68CF0347_const.hasinit preserve=no
  //## end BatchJob::BatchJob%370F68CF0347_const.hasinit
  //## begin BatchJob::BatchJob%370F68CF0347_const.initialization preserve=yes
  //## end BatchJob::BatchJob%370F68CF0347_const.initialization
{
  //## begin BatchJob::BatchJob%370F68CF0347_const.body preserve=yes
   memcpy(m_sID,"JM01",4);
  //## end BatchJob::BatchJob%370F68CF0347_const.body
}

BatchJob::BatchJob (const string& strName)
  //## begin BatchJob::BatchJob%371329CE0330.hasinit preserve=no
  //## end BatchJob::BatchJob%371329CE0330.hasinit
  //## begin BatchJob::BatchJob%371329CE0330.initialization preserve=yes
      : m_strName(strName)
  //## end BatchJob::BatchJob%371329CE0330.initialization
{
  //## begin BatchJob::BatchJob%371329CE0330.body preserve=yes
   memcpy(m_sID,"JM01",4);
   m_hTimer.attach(this);
  //## end BatchJob::BatchJob%371329CE0330.body
}


BatchJob::~BatchJob()
{
  //## begin BatchJob::~BatchJob%370F68CF0347_dest.body preserve=yes
   if (!m_hImages.empty())
      update(0); 
  //## end BatchJob::~BatchJob%370F68CF0347_dest.body
}



//## Other Operations (implementation)
void BatchJob::addImage (const string& strImage, const string& strDatasetName)
{
  //## begin BatchJob::addImage%370F734201BD.body preserve=yes
   if (m_hImages.find(strImage) != m_hImages.end())
      update(0);
   m_hImages.insert(map<string,string,less<string> >::value_type(strImage,strDatasetName));
   if (m_hImages.size() == 1)
      m_hTimer.set("00001500");   
  //## end BatchJob::addImage%370F734201BD.body
}

void BatchJob::submit ()
{
  //## begin BatchJob::submit%370F720603B8.body preserve=yes
   Console::display("SB001",m_strName.c_str());
  //## end BatchJob::submit%370F720603B8.body
}

void BatchJob::update (Subject* pSubject)
{
  //## begin BatchJob::update%370F7021007B.body preserve=yes
   if (!m_hImages.empty())
   {
      CriticalSection hCriticalSection("JCLSYNC ");
      submit();
      m_hImages.erase(m_hImages.begin(),m_hImages.end());
  }
  //## end BatchJob::update%370F7021007B.body
}

// Additional Declarations
  //## begin BatchJob%370F68CF0347.declarations preserve=yes
  //## end BatchJob%370F68CF0347.declarations

//## begin module%370F698402BB.epilog preserve=yes
//## end module%370F698402BB.epilog
