//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%370F674D0158.cm preserve=no
//	$Date:   Sep 11 2008 10:33:36  $ $Author:   d08529  $ $Revision:   1.5  $
//## end module%370F674D0158.cm

//## begin module%370F674D0158.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%370F674D0158.cp

//## Module: CXOPJM00%370F674D0158; Package specification
//## Subsystem: JM%370F6722014C
//## Source file: C:\Devel\ConnexPlatform\Server\Application\Jm\CXODJM00.hpp

#ifndef CXOPJM00_h
#define CXOPJM00_h 1

//## begin module%370F674D0158.additionalIncludes preserve=no
//## end module%370F674D0158.additionalIncludes

//## begin module%370F674D0158.includes preserve=yes
// $Date:   Sep 11 2008 10:33:36  $ $Author:   d08529  $ $Revision:   1.5  $
#include <map>
//## end module%370F674D0158.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class QueueFactory;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace IF {
class Queue;
class Message;
} // namespace IF

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;
} // namespace platform

class LogUnload;
class TracePrint;
class BatchJob;

//## begin module%370F674D0158.declarations preserve=no
//## end module%370F674D0158.declarations

//## begin module%370F674D0158.additionalDeclarations preserve=yes
//## end module%370F674D0158.additionalDeclarations


//## begin JobManager%370F66D7005E.preface preserve=yes
//## end JobManager%370F66D7005E.preface

//## Class: JobManager%370F66D7005E
//	The JobManager task handles the submission of the log
//	unload and trace print jobs.  The jobs are submitted
//	after all images have provided notification.
//## Category: Connex Application::JobManager_CAT%370F66980324
//## Subsystem: JM%370F6722014C
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1



//## Uses: <unnamed>%3712582D00F4;TracePrint { -> F}
//## Uses: <unnamed>%371258300315;LogUnload { -> F}
//## Uses: <unnamed>%37174A7A01A4;IF::QueueFactory { -> F}
//## Uses: <unnamed>%37174D0A0002;IF::Queue { -> F}
//## Uses: <unnamed>%37174D710047;IF::Message { -> F}
//## Uses: <unnamed>%384C1A4F02D3;IF::Extract { -> F}
//## Uses: <unnamed>%40AA62350000;platform::Platform { -> F}
//## Uses: <unnamed>%48C910F503B3;monitor::UseCase { -> F}

class JobManager : public process::Application  //## Inherits: <unnamed>%370F66F600E4
{
  //## begin JobManager%370F66D7005E.initialDeclarations preserve=yes
  //## end JobManager%370F66D7005E.initialDeclarations

  public:
    //## Constructors (generated)
      JobManager();

    //## Destructor (generated)
      virtual ~JobManager();


    //## Other Operations (specified)
      //## Operation: initialize%370F75B9011A
      //## Semantics:
      //	1. Establish a QueueFactory.
      //	2. Call Application::initialize.
      //	3. Establish a queue name of '@DUMPER'.
      virtual int initialize ();

    // Additional Public Declarations
      //## begin JobManager%370F66D7005E.public preserve=yes
      //## end JobManager%370F66D7005E.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%3CADAB32031C
      virtual int onMessage (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin JobManager%370F66D7005E.protected preserve=yes
      //## end JobManager%370F66D7005E.protected

  private:
    // Additional Private Declarations
      //## begin JobManager%370F66D7005E.private preserve=yes
      //## end JobManager%370F66D7005E.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Application::JobManager_CAT::<unnamed>%370F690E02EE
      //## Role: JobManager::<m_hBatchJob>%370F6910003E
      //## Qualifier: Name%370F693B01DA; string
      //## begin JobManager::<m_hBatchJob>%370F6910003E.role preserve=no  public: BatchJob { -> RFHgN}
      map<string, BatchJob *, less<string> > m_hBatchJob;
      //## end JobManager::<m_hBatchJob>%370F6910003E.role

    // Additional Implementation Declarations
      //## begin JobManager%370F66D7005E.implementation preserve=yes
      //## end JobManager%370F66D7005E.implementation

};

//## begin JobManager%370F66D7005E.postscript preserve=yes
//## end JobManager%370F66D7005E.postscript

//## begin module%370F674D0158.epilog preserve=yes
//## end module%370F674D0158.epilog


#endif
