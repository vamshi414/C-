//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%370F715F0349.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%370F715F0349.cm

//## begin module%370F715F0349.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%370F715F0349.cp

//## Module: CXOSJM03%370F715F0349; Package specification
//## Subsystem: JM%370F6722014C
//## Source file: C:\Pvcswork\Dn\Server\Application\Jm\CXODJM03.hpp

#ifndef CXOSJM03_h
#define CXOSJM03_h 1

//## begin module%370F715F0349.additionalIncludes preserve=no
//## end module%370F715F0349.additionalIncludes

//## begin module%370F715F0349.includes preserve=yes
// $Date:   Apr 07 2004 15:15:30  $ $Author:   D98833  $ $Revision:   1.3  $
//## end module%370F715F0349.includes

#ifndef CXOSJM01_h
#include "CXODJM01.hpp"
#endif

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Job;

} // namespace IF

//## begin module%370F715F0349.declarations preserve=no
//## end module%370F715F0349.declarations

//## begin module%370F715F0349.additionalDeclarations preserve=yes
//## end module%370F715F0349.additionalDeclarations


//## begin LogUnload%370F70C502D0.preface preserve=yes
//## end LogUnload%370F70C502D0.preface

//## Class: LogUnload%370F70C502D0
//	The LogUnload class generates the job stream that
//	unloads the log files produced by each Connex image.
//
//	CXODJM03.hpp
//	CXOSJM03.cpp
//## Category: Connex Foundation::JobManager_CAT%370F66980324
//## Subsystem: JM%370F6722014C
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%37125B440250;IF::Job { -> F}

class LogUnload : public BatchJob  //## Inherits: <unnamed>%370F70D30027
{
  //## begin LogUnload%370F70C502D0.initialDeclarations preserve=yes
  //## end LogUnload%370F70C502D0.initialDeclarations

  public:
    //## Constructors (generated)
      LogUnload();

    //## Constructors (specified)
      //## Operation: LogUnload%37177354029C
      LogUnload (const string& strName);

    //## Destructor (generated)
      virtual ~LogUnload();


    //## Other Operations (specified)
      //## Operation: submit%370F726A027B
      //	Submit the log unload job.
      virtual void submit ();

    // Additional Public Declarations
      //## begin LogUnload%370F70C502D0.public preserve=yes
      //## end LogUnload%370F70C502D0.public

  protected:
    // Additional Protected Declarations
      //## begin LogUnload%370F70C502D0.protected preserve=yes
      //## end LogUnload%370F70C502D0.protected

  private:
    // Additional Private Declarations
      //## begin LogUnload%370F70C502D0.private preserve=yes
      //## end LogUnload%370F70C502D0.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin LogUnload%370F70C502D0.implementation preserve=yes
      //## end LogUnload%370F70C502D0.implementation

};

//## begin LogUnload%370F70C502D0.postscript preserve=yes
//## end LogUnload%370F70C502D0.postscript

//## begin module%370F715F0349.epilog preserve=yes
//## end module%370F715F0349.epilog


#endif
