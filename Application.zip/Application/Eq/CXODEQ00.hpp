//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41B5436700F0.cm preserve=no
//## end module%41B5436700F0.cm

//## begin module%41B5436700F0.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%41B5436700F0.cp

//## Module: CXOPEQ00%41B5436700F0; Package specification
//## Subsystem: EQ%41B5425900F2
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Eq\CXODEQ00.hpp

#ifndef CXOPEQ00_h
#define CXOPEQ00_h 1

//## begin module%41B5436700F0.additionalIncludes preserve=no
//## end module%41B5436700F0.additionalIncludes

//## begin module%41B5436700F0.includes preserve=yes
//## end module%41B5436700F0.includes

#ifndef CXOSPS03_h
#include "CXODPS03.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;
class Case;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
class NetworkAvailableReasonCodeListCommand;
class RelatedCasesCommand;
class CaseHighlightCommand;
class CaseClientAccountingListCommand;
class CaseRetrieveRuleSetCommand;
class CaseFeeControlNumberCommand;
class RechainCaseCommand;
class CaseMMTListCommand;
class ActionDetailListCommand;
class CaseAvailableReasonCodeListCommand;
class CaseAvailablePhaseListCommand;
class CaseCardholderInfoCommand;
} // namespace emscommand

//## Modelname: DataNavigator Foundation::RepositoryCommand_CAT%394E267C0078
namespace repositorycommand {
class FinancialUpdateFinTypeCommand;
} // namespace repositorycommand

namespace emscommand {
class CaseChangeListCommand;
class CaseCommentCreateCommand;
class CaseCommentListCommand;
class CaseListCommand;
class CaseRulesDescriptionListCommand;
class CasePhaseListCommand;
class CaseWorkQueueListCommand;
class CaseDocumentListCommand;
class CaseCardholderUpdateCommand;
} // namespace emscommand

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseSegment;
class CaseTransitionSegment;
class CaseStarSegment;
class CaseVisaSegment;
class CasePhaseInterlinkSegment;
class CaseAffnSegment;
class CaseAustraliaSegment;
class CaseCashStationSegment;
class CaseCirrusSegment;
class CaseInterlinkSegment;
class CaseHonorSegment;
class CaseMacSegment;
class CaseNyceSegment;
class CasePhaseAffnSegment;
class CasePhaseAustraliaSegment;
class CasePhaseCashStationSegment;
class CasePhaseCirrusSegment;
class CasePhaseMacSegment;
class CasePhaseNyceSegment;
class CasePhasePulseSegment;
class CasePhaseSegment;
class CasePhaseStarSegment;
class CasePlusSegment;
class CasePhaseVisaSegment;
class CasePulseSegment;
class CreditSegment;
class CaseEFTPosSegment;
class CasePhaseEFTPosSegment;
class CaseShazamSegment;
class CasePhaseAccelSegment;
} // namespace emssegment

//## Modelname: Transaction Research and Adjustments::ZappException_CAT%52B9AF58018F
namespace zapp {
class CaseListCommand;
} // namespace zapp

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialBaseSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class NetworkFactory;
class ExceptionFactory;
class ActionFactory;
class DNPlatform;
} // namespace dnplatform

//## Modelname: DataNavigator Foundation::SOAPCommand_CAT%4DC0633D0140
namespace soapcommand {
class CaseCommentsListCommand;
class CaseListCommand;
class ClaimStatusCommand;
class CaseDocumentsListCommand;
} // namespace soapcommand

//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
class MmtsCommand;
class CasesCommand;
class ClaimStatusCommand;
class ClaimCommand;
class ReasonCodesCommand;
class TransitionsCommand;
} // namespace restcommand

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class AuditEvent;
} // namespace segment

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;
class Message;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CriticalSection;
class Transaction;
} // namespace reusable

namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

namespace IF {
class Extract;
class EMailMessage;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class GlobalContext;
} // namespace database

namespace segment {
class CommonHeaderSegment;
} // namespace segment

//## Modelname: Platform \: Regions::RegionsAPI%49C79DB0002E
namespace regionsapi {
class CaseCardholderInfoCommand;
} // namespace regionsapi

//## Modelname: Platform \: FIS::FIS%4C6026A60192
namespace fis {
class CaseCardholderInfoCommand;

} // namespace fis

//## begin module%41B5436700F0.declarations preserve=no
//## end module%41B5436700F0.declarations

//## begin module%41B5436700F0.additionalDeclarations preserve=yes
namespace fis{
	class CBAcctInq;
}
//## end module%41B5436700F0.additionalDeclarations


//## begin ExceptionQuery%41B5214D00E3.preface preserve=yes
//## end ExceptionQuery%41B5214D00E3.preface

//## Class: ExceptionQuery%41B5214D00E3
//	<body>
//	<title>CG
//	<h1>EQ
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server provides rules based case
//	management for transaction exception items to end users.
//	<p>
//	The Exception Query service (<i>ca</i>EQ<i>nn</i>)
//	retrieves cases, phases, comments and rules information
//	for end users.
//	Requests come through the Client Interface service
//	(<i>ca</i>CI01).
//	</p>
//	<p>
//	Refer to the various <i>DataNavigator Client Exception
//	Management User's Guides</i> for more information.
//	</p>
//	</body>
//## Category: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )%41B5209B003D
//## Subsystem: EQ%41B5425900F2
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%41B6513C0044;IF::Queue { -> F}
//## Uses: <unnamed>%41B651A8036A;IF::Message { -> F}
//## Uses: <unnamed>%41B651BF01E7;database::Database { -> F}
//## Uses: <unnamed>%41B651EF0380;reusable::Transaction { -> F}
//## Uses: <unnamed>%41B6521C014A;emssegment::CaseCashStationSegment { -> F}
//## Uses: <unnamed>%41B6528803C7;emssegment::CaseCirrusSegment { -> F}
//## Uses: <unnamed>%41B652A902A2;emssegment::CaseHonorSegment { -> F}
//## Uses: <unnamed>%41B652CE010A;emssegment::CaseInterlinkSegment { -> F}
//## Uses: <unnamed>%41B6533502A3;emssegment::CaseNyceSegment { -> F}
//## Uses: <unnamed>%41B653530170;emssegment::CasePhaseCashStationSegment { -> F}
//## Uses: <unnamed>%41B6536E01E7;emssegment::CasePhaseNyceSegment { -> F}
//## Uses: <unnamed>%41B6538A0241;emssegment::CasePhasePulseSegment { -> F}
//## Uses: <unnamed>%41B6575C01F7;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%41B6577E02BE;emssegment::CasePhaseVisaSegment { -> F}
//## Uses: <unnamed>%41B657990281;emssegment::CasePlusSegment { -> F}
//## Uses: <unnamed>%41B657B60391;emssegment::CasePulseSegment { -> F}
//## Uses: <unnamed>%41B658E101CE;emssegment::CaseStarSegment { -> F}
//## Uses: <unnamed>%41B6590700E3;emssegment::CaseTransitionSegment { -> F}
//## Uses: <unnamed>%41B6597502F4;emssegment::CaseVisaSegment { -> F}
//## Uses: <unnamed>%41B6599701A8;emssegment::CaseSegment { -> F}
//## Uses: <unnamed>%41B659B6009E;emssegment::CaseAffnSegment { -> F}
//## Uses: <unnamed>%41B65A2A0195;emssegment::CasePhaseAffnSegment { -> F}
//## Uses: <unnamed>%41B65A4C009A;ems::Case { -> F}
//## Uses: <unnamed>%41B65A6E034C;emssegment::CasePhaseStarSegment { -> F}
//## Uses: <unnamed>%41B65AED00A5;emssegment::CaseMacSegment { -> F}
//## Uses: <unnamed>%41B65B0B0153;emssegment::CasePhaseMacSegment { -> F}
//## Uses: <unnamed>%41B65B2A0306;emssegment::CasePhaseCirrusSegment { -> F}
//## Uses: <unnamed>%41B65B5902AA;emssegment::CasePhaseAustraliaSegment { -> F}
//## Uses: <unnamed>%41B65B9002A9;monitor::UseCase { -> F}
//## Uses: <unnamed>%41B65BD102CA;emssegment::CasePhaseInterlinkSegment { -> F}
//## Uses: <unnamed>%41B65C0C03E7;timer::Clock { -> F}
//## Uses: <unnamed>%41B65CD901CF;IF::Extract { -> F}
//## Uses: <unnamed>%41B65D55001F;IF::EMailMessage { -> F}
//## Uses: <unnamed>%41B65D7D006D;emssegment::CaseAustraliaSegment { -> F}
//## Uses: <unnamed>%41B65DA602A6;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%41B65DCF0223;emscommand::CaseClientAccountingListCommand { -> F}
//## Uses: <unnamed>%41B65EDF01DE;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%49EF42DC0148;regionsapi::CaseCardholderInfoCommand { -> F}
//## Uses: <unnamed>%49F8908602FD;database::GlobalContext { -> F}
//## Uses: <unnamed>%4C7BFC7E03B7;fis::CaseCardholderInfoCommand { -> F}
//## Uses: <unnamed>%4C7C04C60243;segment::CommonHeaderSegment { -> F}
//## Uses: <unnamed>%52CAFA380051;zapp::CaseListCommand { -> F}
//## Uses: <unnamed>%542AE44C0392;IF::Trace { -> F}
//## Uses: <unnamed>%542AE4810234;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%542AE4AD03DC;segment::AuditEvent { -> F}
//## Uses: <unnamed>%542AE4E7028C;emssegment::CreditSegment { -> F}
//## Uses: <unnamed>%542AE5310207;repositorysegment::FinancialBaseSegment { -> F}
//## Uses: <unnamed>%55DEFE730018;dnplatform::ActionFactory { -> F}
//## Uses: <unnamed>%564B70B20282;soapcommand::CaseListCommand { -> F}
//## Uses: <unnamed>%5898DEFB0267;emssegment::CasePhaseAccelSegment { -> F}
//## Uses: <unnamed>%5A95249E02B2;emssegment::CaseShazamSegment { -> F}
//## Uses: <unnamed>%5C6C0EDF00BA;dnplatform::NetworkFactory { -> F}
//## Uses: <unnamed>%5C6C0EF2001B;dnplatform::ExceptionFactory { -> F}
//## Uses: <unnamed>%61D6F608038E;emssegment::CaseEFTPosSegment { -> F}
//## Uses: <unnamed>%61D6F61700AF;emssegment::CasePhaseEFTPosSegment { -> F}
//## Uses: <unnamed>%62D8249902FE;soapcommand::CaseDocumentsListCommand { -> F}

class DllExport ExceptionQuery : public process::ServiceApplication  //## Inherits: <unnamed>%41B523060033
{
  //## begin ExceptionQuery%41B5214D00E3.initialDeclarations preserve=yes
  //## end ExceptionQuery%41B5214D00E3.initialDeclarations

  public:
    //## Constructors (generated)
      ExceptionQuery();

    //## Destructor (generated)
      virtual ~ExceptionQuery();


    //## Other Operations (specified)
      //## Operation: initialize%41B64CA10356
      int initialize ();

      //## Operation: update%41B64C1D007B
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin ExceptionQuery%41B5214D00E3.public preserve=yes
      //## end ExceptionQuery%41B5214D00E3.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%41B64BFE02A7
      int onMessage (Message& hMessage);

      //## Operation: onReset%41B64C090343
      virtual int onReset (Message& hMessage);

    // Additional Protected Declarations
      //## begin ExceptionQuery%41B5214D00E3.protected preserve=yes
      //## end ExceptionQuery%41B5214D00E3.protected

  private:
    // Additional Private Declarations
      //## begin ExceptionQuery%41B5214D00E3.private preserve=yes
      //## end ExceptionQuery%41B5214D00E3.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B641EE0036
      //## Role: ExceptionQuery::<m_pCaseListCommand>%41B641EE036B
      //## begin ExceptionQuery::<m_pCaseListCommand>%41B641EE036B.role preserve=no  public: emscommand::CaseListCommand { -> RFHgN}
      emscommand::CaseListCommand *m_pCaseListCommand;
      //## end ExceptionQuery::<m_pCaseListCommand>%41B641EE036B.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B6449E0360
      //## Role: ExceptionQuery::<m_pCaseChangeListCommand>%41B644A0020F
      //## begin ExceptionQuery::<m_pCaseChangeListCommand>%41B644A0020F.role preserve=no  public: emscommand::CaseChangeListCommand { -> RFHgN}
      emscommand::CaseChangeListCommand *m_pCaseChangeListCommand;
      //## end ExceptionQuery::<m_pCaseChangeListCommand>%41B644A0020F.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B64568023F
      //## Role: ExceptionQuery::<m_pCaseRulesDescriptionListCommand>%41B6456901E6
      //## begin ExceptionQuery::<m_pCaseRulesDescriptionListCommand>%41B6456901E6.role preserve=no  public: emscommand::CaseRulesDescriptionListCommand { -> RFHgN}
      emscommand::CaseRulesDescriptionListCommand *m_pCaseRulesDescriptionListCommand;
      //## end ExceptionQuery::<m_pCaseRulesDescriptionListCommand>%41B6456901E6.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B645CE03CC
      //## Role: ExceptionQuery::<m_pCasePhaseListCommand>%41B645CF02DD
      //## begin ExceptionQuery::<m_pCasePhaseListCommand>%41B645CF02DD.role preserve=no  public: emscommand::CasePhaseListCommand { -> RFHgN}
      emscommand::CasePhaseListCommand *m_pCasePhaseListCommand;
      //## end ExceptionQuery::<m_pCasePhaseListCommand>%41B645CF02DD.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B646080267
      //## Role: ExceptionQuery::<m_pCaseCommentListCommand>%41B6460803E3
      //## begin ExceptionQuery::<m_pCaseCommentListCommand>%41B6460803E3.role preserve=no  public: emscommand::CaseCommentListCommand { -> RFHgN}
      emscommand::CaseCommentListCommand *m_pCaseCommentListCommand;
      //## end ExceptionQuery::<m_pCaseCommentListCommand>%41B6460803E3.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B646440231
      //## Role: ExceptionQuery::<m_pCaseCommentCreateCommand>%41B64645000C
      //## begin ExceptionQuery::<m_pCaseCommentCreateCommand>%41B64645000C.role preserve=no  public: emscommand::CaseCommentCreateCommand { -> RFHgN}
      emscommand::CaseCommentCreateCommand *m_pCaseCommentCreateCommand;
      //## end ExceptionQuery::<m_pCaseCommentCreateCommand>%41B64645000C.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B64696018F
      //## Role: ExceptionQuery::<m_pFinancialUpdateFinTypeCommand>%41B64697010E
      //## begin ExceptionQuery::<m_pFinancialUpdateFinTypeCommand>%41B64697010E.role preserve=no  public: repositorycommand::FinancialUpdateFinTypeCommand { -> RFHgN}
      repositorycommand::FinancialUpdateFinTypeCommand *m_pFinancialUpdateFinTypeCommand;
      //## end ExceptionQuery::<m_pFinancialUpdateFinTypeCommand>%41B64697010E.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B646CE026B
      //## Role: ExceptionQuery::<m_pCaseWorkQueueListCommand>%41B646CF02BD
      //## begin ExceptionQuery::<m_pCaseWorkQueueListCommand>%41B646CF02BD.role preserve=no  public: emscommand::CaseWorkQueueListCommand { -> RFHgN}
      emscommand::CaseWorkQueueListCommand *m_pCaseWorkQueueListCommand;
      //## end ExceptionQuery::<m_pCaseWorkQueueListCommand>%41B646CF02BD.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B6471C0278
      //## Role: ExceptionQuery::<m_pCaseAvailablePhaseListCommand>%41B6471D00DE
      //## begin ExceptionQuery::<m_pCaseAvailablePhaseListCommand>%41B6471D00DE.role preserve=no  public: emscommand::CaseAvailablePhaseListCommand { -> RFHgN}
      emscommand::CaseAvailablePhaseListCommand *m_pCaseAvailablePhaseListCommand;
      //## end ExceptionQuery::<m_pCaseAvailablePhaseListCommand>%41B6471D00DE.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B6479601FB
      //## Role: ExceptionQuery::<m_pActionDetailListCommand>%41B647970365
      //## begin ExceptionQuery::<m_pActionDetailListCommand>%41B647970365.role preserve=no  public: emscommand::ActionDetailListCommand { -> RFHgN}
      emscommand::ActionDetailListCommand *m_pActionDetailListCommand;
      //## end ExceptionQuery::<m_pActionDetailListCommand>%41B647970365.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B647D002D1
      //## Role: ExceptionQuery::<m_pCaseCardholderInfoCommand>%41B647D1020A
      //## begin ExceptionQuery::<m_pCaseCardholderInfoCommand>%41B647D1020A.role preserve=no  public: emscommand::CaseCardholderInfoCommand { -> RFHgN}
      emscommand::CaseCardholderInfoCommand *m_pCaseCardholderInfoCommand;
      //## end ExceptionQuery::<m_pCaseCardholderInfoCommand>%41B647D1020A.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B64809025A
      //## Role: ExceptionQuery::<m_pCaseAvailableReasonCodeListCommand>%41B6480A0161
      //## begin ExceptionQuery::<m_pCaseAvailableReasonCodeListCommand>%41B6480A0161.role preserve=no  public: emscommand::CaseAvailableReasonCodeListCommand { -> RFHgN}
      emscommand::CaseAvailableReasonCodeListCommand *m_pCaseAvailableReasonCodeListCommand;
      //## end ExceptionQuery::<m_pCaseAvailableReasonCodeListCommand>%41B6480A0161.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B6483F0168
      //## Role: ExceptionQuery::<m_pCaseMMTListCommand>%41B6484003CC
      //## begin ExceptionQuery::<m_pCaseMMTListCommand>%41B6484003CC.role preserve=no  public: emscommand::CaseMMTListCommand { -> RFHgN}
      emscommand::CaseMMTListCommand *m_pCaseMMTListCommand;
      //## end ExceptionQuery::<m_pCaseMMTListCommand>%41B6484003CC.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B648B700A2
      //## Role: ExceptionQuery::<m_pRechainCaseCommand>%41B648B70387
      //## begin ExceptionQuery::<m_pRechainCaseCommand>%41B648B70387.role preserve=no  public: emscommand::RechainCaseCommand { -> RFHgN}
      emscommand::RechainCaseCommand *m_pRechainCaseCommand;
      //## end ExceptionQuery::<m_pRechainCaseCommand>%41B648B70387.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B649BF00D4
      //## Role: ExceptionQuery::<m_pCaseFeeControlNumberCommand>%41B649C00085
      //## begin ExceptionQuery::<m_pCaseFeeControlNumberCommand>%41B649C00085.role preserve=no  public: emscommand::CaseFeeControlNumberCommand { -> RFHgN}
      emscommand::CaseFeeControlNumberCommand *m_pCaseFeeControlNumberCommand;
      //## end ExceptionQuery::<m_pCaseFeeControlNumberCommand>%41B649C00085.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B64A200250
      //## Role: ExceptionQuery::<m_pCaseRetrieveRuleSetCommand>%41B64A210265
      //## begin ExceptionQuery::<m_pCaseRetrieveRuleSetCommand>%41B64A210265.role preserve=no  public: emscommand::CaseRetrieveRuleSetCommand { -> RFHgN}
      emscommand::CaseRetrieveRuleSetCommand *m_pCaseRetrieveRuleSetCommand;
      //## end ExceptionQuery::<m_pCaseRetrieveRuleSetCommand>%41B64A210265.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B64A780379
      //## Role: ExceptionQuery::<m_pCaseHighlightCommand>%41B64A790258
      //## begin ExceptionQuery::<m_pCaseHighlightCommand>%41B64A790258.role preserve=no  public: emscommand::CaseHighlightCommand { -> RFHgN}
      emscommand::CaseHighlightCommand *m_pCaseHighlightCommand;
      //## end ExceptionQuery::<m_pCaseHighlightCommand>%41B64A790258.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%41B65E340020
      //## Role: ExceptionQuery::<m_pCaseClientAccountingListCommand>%41B65E3402F1
      //## begin ExceptionQuery::<m_pCaseClientAccountingListCommand>%41B65E3402F1.role preserve=no  public: emscommand::CaseClientAccountingListCommand { -> RFHgN}
      emscommand::CaseClientAccountingListCommand *m_pCaseClientAccountingListCommand;
      //## end ExceptionQuery::<m_pCaseClientAccountingListCommand>%41B65E3402F1.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%499AE048002E
      //## Role: ExceptionQuery::<m_pRelatedCasesCommand>%499AE04803C8
      //## begin ExceptionQuery::<m_pRelatedCasesCommand>%499AE04803C8.role preserve=no  public: emscommand::RelatedCasesCommand { -> RFHgN}
      emscommand::RelatedCasesCommand *m_pRelatedCasesCommand;
      //## end ExceptionQuery::<m_pRelatedCasesCommand>%499AE04803C8.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%4A565B5D0177
      //## Role: ExceptionQuery::<m_pNetworkAvailableReasonCodeListCommand>%4A565B5E007D
      //## begin ExceptionQuery::<m_pNetworkAvailableReasonCodeListCommand>%4A565B5E007D.role preserve=no  public: emscommand::NetworkAvailableReasonCodeListCommand { -> RFHgN}
      emscommand::NetworkAvailableReasonCodeListCommand *m_pNetworkAvailableReasonCodeListCommand;
      //## end ExceptionQuery::<m_pNetworkAvailableReasonCodeListCommand>%4A565B5E007D.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%4A565B6002DE
      //## Role: ExceptionQuery::<m_pCaseCardholderUpdateCommand>%4A565B61029F
      //## begin ExceptionQuery::<m_pCaseCardholderUpdateCommand>%4A565B61029F.role preserve=no  public: emscommand::CaseCardholderUpdateCommand { -> RFHgN}
      emscommand::CaseCardholderUpdateCommand *m_pCaseCardholderUpdateCommand;
      //## end ExceptionQuery::<m_pCaseCardholderUpdateCommand>%4A565B61029F.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%531F302C0394
      //## Role: ExceptionQuery::<m_pCaseDocumentListCommand>%531F303301F9
      //## begin ExceptionQuery::<m_pCaseDocumentListCommand>%531F303301F9.role preserve=no  public: emscommand::CaseDocumentListCommand { -> RFHgN}
      emscommand::CaseDocumentListCommand *m_pCaseDocumentListCommand;
      //## end ExceptionQuery::<m_pCaseDocumentListCommand>%531F303301F9.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%542AE3BD0165
      //## Role: ExceptionQuery::<m_pClaimStatusCommand>%542AE3BE01DD
      //## begin ExceptionQuery::<m_pClaimStatusCommand>%542AE3BE01DD.role preserve=no  public: soapcommand::ClaimStatusCommand { -> RFHgN}
      soapcommand::ClaimStatusCommand *m_pClaimStatusCommand;
      //## end ExceptionQuery::<m_pClaimStatusCommand>%542AE3BE01DD.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%564B70E401FF
      //## Role: ExceptionQuery::<m_pXMLCaseListCommand>%564B70E5022C
      //## begin ExceptionQuery::<m_pXMLCaseListCommand>%564B70E5022C.role preserve=no  public: soapcommand::CaseListCommand { -> RFHgN}
      soapcommand::CaseListCommand *m_pXMLCaseListCommand;
      //## end ExceptionQuery::<m_pXMLCaseListCommand>%564B70E5022C.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%578AEA8500A8
      //## Role: ExceptionQuery::<m_pCaseCommentsListCommand>%578AEA92011D
      //## begin ExceptionQuery::<m_pCaseCommentsListCommand>%578AEA92011D.role preserve=no  public: soapcommand::CaseCommentsListCommand { -> RFHgN}
      soapcommand::CaseCommentsListCommand *m_pCaseCommentsListCommand;
      //## end ExceptionQuery::<m_pCaseCommentsListCommand>%578AEA92011D.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%62D827640038
      //## Role: ExceptionQuery::<m_pCaseDocumentsListCommand>%62D827720054
      //## begin ExceptionQuery::<m_pCaseDocumentsListCommand>%62D827720054.role preserve=no  public: soapcommand::CaseDocumentsListCommand { -> RFHgN}
      soapcommand::CaseDocumentsListCommand *m_pCaseDocumentsListCommand;
      //## end ExceptionQuery::<m_pCaseDocumentsListCommand>%62D827720054.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%6511C36F00F4
      //## Role: ExceptionQuery::<m_pTransitionsCommand>%6511C370017B
      //## begin ExceptionQuery::<m_pTransitionsCommand>%6511C370017B.role preserve=no  public: restcommand::TransitionsCommand { -> RFHgN}
      restcommand::TransitionsCommand *m_pTransitionsCommand;
      //## end ExceptionQuery::<m_pTransitionsCommand>%6511C370017B.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%65269211029E
      //## Role: ExceptionQuery::<m_pCasesCommand>%652692120224
      //## begin ExceptionQuery::<m_pCasesCommand>%652692120224.role preserve=no  public: restcommand::CasesCommand { -> RFHgN}
      restcommand::CasesCommand *m_pCasesCommand;
      //## end ExceptionQuery::<m_pCasesCommand>%652692120224.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%655B886200B1
      //## Role: ExceptionQuery::<m_pReasonCodesCommand>%655B886C0265
      //## begin ExceptionQuery::<m_pReasonCodesCommand>%655B886C0265.role preserve=no  public: restcommand::ReasonCodesCommand { -> RFHgN}
      restcommand::ReasonCodesCommand *m_pReasonCodesCommand;
      //## end ExceptionQuery::<m_pReasonCodesCommand>%655B886C0265.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%659E5DD400B7
      //## Role: ExceptionQuery::<m_pClaimCommand>%659E5DE100B3
      //## begin ExceptionQuery::<m_pClaimCommand>%659E5DE100B3.role preserve=no  public: restcommand::ClaimCommand { -> RFHgN}
      restcommand::ClaimCommand *m_pClaimCommand;
      //## end ExceptionQuery::<m_pClaimCommand>%659E5DE100B3.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%65B773EC0057
      //## Role: ExceptionQuery::<m_pMmtsCommand>%65B773F70192
      //## begin ExceptionQuery::<m_pMmtsCommand>%65B773F70192.role preserve=no  public: restcommand::MmtsCommand { -> RFHgN}
      restcommand::MmtsCommand *m_pMmtsCommand;
      //## end ExceptionQuery::<m_pMmtsCommand>%65B773F70192.role

      //## Association: Transaction Research and Adjustments::ExceptionQuery_CAT ( EQ )::<unnamed>%6603CEB50305
      //## Role: ExceptionQuery::<m_pRESTClaimStatusCommand>%6603CEBF0198
      //## begin ExceptionQuery::<m_pRESTClaimStatusCommand>%6603CEBF0198.role preserve=no  public: restcommand::ClaimStatusCommand { -> RFHgN}
      restcommand::ClaimStatusCommand *m_pRESTClaimStatusCommand;
      //## end ExceptionQuery::<m_pRESTClaimStatusCommand>%6603CEBF0198.role

    // Additional Implementation Declarations
      //## begin ExceptionQuery%41B5214D00E3.implementation preserve=yes
	  fis::CBAcctInq* m_pCBAcctInq;
      //## end ExceptionQuery%41B5214D00E3.implementation
};

//## begin ExceptionQuery%41B5214D00E3.postscript preserve=yes
//## end ExceptionQuery%41B5214D00E3.postscript

//## begin module%41B5436700F0.epilog preserve=yes
//## end module%41B5436700F0.epilog


#endif
