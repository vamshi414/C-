//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38A4672800B8.cm preserve=no
//	$Date:   Jul 26 2013 09:36:52  $ $Author:   e1009652  $
//	$Revision:   1.18  $
//## end module%38A4672800B8.cm

//## begin module%38A4672800B8.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%38A4672800B8.cp

//## Module: CXOPIM00%38A4672800B8; Package body
//## Subsystem: IM%38A4663D0165
//## Source file: C:\Devel\Dn\Server\Application\IM\CXOPIM00.cpp

//## begin module%38A4672800B8.additionalIncludes preserve=no
//## end module%38A4672800B8.additionalIncludes

//## begin module%38A4672800B8.includes preserve=yes
// $Date:   Jul 26 2013 09:36:52  $ $Author:   e1009652  $ $Revision:   1.18  $
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
//## end module%38A4672800B8.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSNC01_h
#include "CXODNC01.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSRU24_h
#include "CXODRU24.hpp"
#endif
#ifndef CXOPIM00_h
#include "CXODIM00.hpp"
#endif


//## begin module%38A4672800B8.declarations preserve=no
//## end module%38A4672800B8.declarations

//## begin module%38A4672800B8.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new IBMMTFReader();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%38A4672800B8.additionalDeclarations


// Class IBMMTFReader 

IBMMTFReader::IBMMTFReader()
  //## begin IBMMTFReader::IBMMTFReader%38A462130325_const.hasinit preserve=no
  //## end IBMMTFReader::IBMMTFReader%38A462130325_const.hasinit
  //## begin IBMMTFReader::IBMMTFReader%38A462130325_const.initialization preserve=yes
  :m_hCRFile("CR")
  //## end IBMMTFReader::IBMMTFReader%38A462130325_const.initialization
{
  //## begin IBMMTFReader::IBMMTFReader%38A462130325_const.body preserve=yes
   memcpy(m_sID,"IM00",4);
  //## end IBMMTFReader::IBMMTFReader%38A462130325_const.body
}


IBMMTFReader::~IBMMTFReader()
{
  //## begin IBMMTFReader::~IBMMTFReader%38A462130325_dest.body preserve=yes
  //## end IBMMTFReader::~IBMMTFReader%38A462130325_dest.body
}



//## Other Operations (implementation)
int IBMMTFReader::initialize ()
{
  //## begin IBMMTFReader::initialize%38A46EE403E1.body preserve=yes
   // CX01: Operator_Starts_IBMMTFReader
   new dnplatform::DNPlatform();
   new segment::AuditEvent;
   int i = Application::initialize();
   UseCase hUseCase("IBM","## CX01 START IM");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   CRUpdateCommand::instance();
   Database::instance()->connect();
   return 0;
  //## end IBMMTFReader::initialize%38A46EE403E1.body
}

int IBMMTFReader::onReset (IF::Message& hMessage)
{
  //## begin IBMMTFReader::onReset%38DB6F060238.body preserve=yes
   // CX02: Operator_Resets_IBMMTFReader
   UseCase hUseCase("IBM","## CX02 RESET IM");
   if (hMessage.context().subString(1,2) == "CR")
      m_hCRFile.process();
   else
      m_hIBMMTF.process();
   return 0;
  //## end IBMMTFReader::onReset%38DB6F060238.body
}

// Additional Declarations
  //## begin IBMMTFReader%38A462130325.declarations preserve=yes
  //## end IBMMTFReader%38A462130325.declarations

//## begin module%38A4672800B8.epilog preserve=yes
//## end module%38A4672800B8.epilog
