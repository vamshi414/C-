//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38DA893102A2.cm preserve=no
//	$Date:   May 20 2020 16:46:38  $ $Author:   e1009510  $
//	$Revision:   1.27  $
//## end module%38DA893102A2.cm

//## begin module%38DA893102A2.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%38DA893102A2.cp

//## Module: CXOSIM02%38DA893102A2; Package body
//## Subsystem: IM%38A4663D0165
//## Source file: C:\Devel\Dn\Server\Application\IM\CXOSIM02.cpp

//## begin module%38DA893102A2.additionalIncludes preserve=no
//## end module%38DA893102A2.additionalIncludes

//## begin module%38DA893102A2.includes preserve=yes
// $Date:   May 20 2020 16:46:38  $ $Author:   e1009510  $ $Revision:   1.27  $
#include <stdio.h>
#include "CXODRU24.hpp"
#include "CXODIM01.hpp"
#include "CXODDB01.hpp"
//## end module%38DA893102A2.includes

#ifndef CXOSNS03_h
#include "CXODNS03.hpp"
#endif
#ifndef CXOSNS01_h
#include "CXODNS01.hpp"
#endif
#ifndef CXOSNS02_h
#include "CXODNS02.hpp"
#endif
#ifndef CXOSNS05_h
#include "CXODNS05.hpp"
#endif
#ifndef CXOSRU22_h
#include "CXODRU22.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIM02_h
#include "CXODIM02.hpp"
#endif


//## begin module%38DA893102A2.declarations preserve=no
//## end module%38DA893102A2.declarations

//## begin module%38DA893102A2.additionalDeclarations preserve=yes
//## end module%38DA893102A2.additionalDeclarations


// Class IBMMTF 

IBMMTF::IBMMTF()
  //## begin IBMMTF::IBMMTF%38DA887101A1_const.hasinit preserve=no
  //## end IBMMTF::IBMMTF%38DA887101A1_const.hasinit
  //## begin IBMMTF::IBMMTF%38DA887101A1_const.initialization preserve=yes
  :CRFile("CED")
  //## end IBMMTF::IBMMTF%38DA887101A1_const.initialization
{
  //## begin IBMMTF::IBMMTF%38DA887101A1_const.body preserve=yes
   memcpy(m_sID,"IM02",4);
  //## end IBMMTF::IBMMTF%38DA887101A1_const.body
}


IBMMTF::~IBMMTF()
{
  //## begin IBMMTF::~IBMMTF%38DA887101A1_dest.body preserve=yes
  //## end IBMMTF::~IBMMTF%38DA887101A1_dest.body
}



//## Other Operations (implementation)
void IBMMTF::copyInstitution ()
{
  //## begin IBMMTF::copyInstitution%38DB94CD02FC.body preserve=yes
   // CX04: SW_Copies_Institution_From_MTF
   UseCase hUseCase("IBM","## CX04 INSTITUTION");
   hIBMMTFInst* p = (hIBMMTFInst*)m_psBuffer;
   m_pFileSegment = CRInstitutionSegment::instance();
   CRInstitutionSegment::instance()->reset();
   string strINST_ID(cutSpaces(p->cMTFKey,8));
   CheckDigit::calculate(strINST_ID);
   CRInstitutionSegment::instance()->setINST_ID(strINST_ID);
   CRInstitutionSegment::instance()->setNAME(cutSpaces(p->cName,30));
   CRInstitutionSegment::instance()->setPROC_ID(cutSpaces(p->cProc,6));
   CRInstitutionSegment::instance()->setFEE_BILL_INST_ID(cutSpaces(p->cACHfFRDABA,9));
   CRInstitutionSegment::instance()->setFEE_BILL_ACCT_ID(cutSpaces(p->cACHfDDA,17));
   CRInstitutionSegment::instance()->setSETL_INST_ID(cutSpaces(p->cACHsFRDABA,9));
   CRInstitutionSegment::instance()->setSETL_ACCT_NO(cutSpaces(p->cACHsDDA,17));
   CRInstitutionSegment::instance()->setFUNDS_MOVEMENT_OPT(cutSpaces(p->cNACHAOpt,2));
   CRInstitutionSegment::instance()->setBILL_INTERCHG_GRP(cutSpaces(p->cBill,2));
  //## end IBMMTF::copyInstitution%38DB94CD02FC.body
}

void IBMMTF::copyMerchant ()
{
  //## begin IBMMTF::copyMerchant%38DB97350398.body preserve=yes
   // CX07: SW_Copies_Merchant_From_MTF
   UseCase hUseCase("IBM","## CX07 MERCHANT");
   hIBMMTFMerch* p = (hIBMMTFMerch*)m_psBuffer;
   m_pFileSegment = CRReportingLevelSegment::instance();
   CRReportingLevelSegment::instance()->reset();

   string strRPT_LVL_ID(cutSpaces(p->cMTFKey + 2,6));
   CRReportingLevelSegment::instance()->setRPT_LVL_ID(strRPT_LVL_ID);
   CRReportingLevelSegment::instance()->setRPT_LVL_NAME(cutSpaces(p->cDesc40,35));

   string strINST_ID(cutSpaces(p->cInst,8));
   CheckDigit::calculate(strINST_ID);
   m_hMerchant[strRPT_LVL_ID] = strINST_ID;
  //## end IBMMTF::copyMerchant%38DB97350398.body
}

void IBMMTF::copyMerchantAddendum ()
{
  //## begin IBMMTF::copyMerchantAddendum%38DB9761028D.body preserve=yes
   // CX08: SW_Copies_Merchant_Addendum_From_MTF
   UseCase hUseCase("IBM","## CX08 MERCHANT ADDENDUM");
   hIBMMTFMerchAdd* p = (hIBMMTFMerchAdd*)m_psBuffer;
   m_pFileSegment = CRReportingLevelSegment::instance();
   CRReportingLevelSegment::instance()->reset();
   CRReportingLevelSegment::instance()->setRPT_LVL_ID(cutSpaces(p->cMTFKey + 2,6));
   CRReportingLevelSegment::instance()->setSETL_ACCT_NO(cutSpaces(p->cStlAcct,17));
   CRReportingLevelSegment::instance()->setSETL_INST_ID(cutSpaces(p->cStlInst,9));
  //## end IBMMTF::copyMerchantAddendum%38DB9761028D.body
}

void IBMMTF::copyProcessor ()
{
  //## begin IBMMTF::copyProcessor%38DB97360231.body preserve=yes
   // CX03: SW_Copies_Processor_From_MTF
   UseCase hUseCase("IBM","## CX03 PROCESSOR");
   hIBMMTFProc* p = (hIBMMTFProc*)m_psBuffer;
   m_pFileSegment = CRProcessorSegment::instance();
   CRProcessorSegment::instance()->reset();
   CRProcessorSegment::instance()->setPROC_ID(cutSpaces(p->cMTFKeyProcID,6));
   CRProcessorSegment::instance()->setPROC_NAME(cutSpaces(p->cName,30));
   CRProcessorSegment::instance()->setFEE_BILL_INST_ID(cutSpaces(p->cACHfFRDABA,9));
   CRProcessorSegment::instance()->setFEE_BILL_ACCT_ID(cutSpaces(p->cFDDA,17));
   CRProcessorSegment::instance()->setSETL_INST_ID(cutSpaces(p->cACHsFRDABA,9));
   CRProcessorSegment::instance()->setSETL_ACCT_NO(cutSpaces(p->cSDDA,17));
   CRProcessorSegment::instance()->setFUNDS_MOVEMENT_OPT(cutSpaces(p->cNACHAOpt,2));
   CRProcessorSegment::instance()->setSERVICE_LINE(cutSpaces(p->cSVLN,2));
   CRProcessorSegment::instance()->setINTERCEPT_FLG("N");
  //## end IBMMTF::copyProcessor%38DB97360231.body
}

void IBMMTF::copyTerminal ()
{
  //## begin IBMMTF::copyTerminal%38DB9736037B.body preserve=yes
   // CX05: SW_Copies_Terminal_From_MTF
   UseCase hUseCase("IBM","## CX05 TERMINAL");
   hIBMMTFTerm* p = (hIBMMTFTerm*)m_psBuffer;
   m_pFileSegment = CRDeviceSegment::instance();
   CRDeviceSegment::instance()->reset();
   string strDEVICE_ID(cutSpaces(p->cMTFKey,8));
   size_t pos = strDEVICE_ID.find_first_not_of(" ");
   if (pos > 0)
      strDEVICE_ID.erase(0,pos);
   CRDeviceSegment::instance()->setDEVICE_ID(strDEVICE_ID);
   CRDeviceSegment::instance()->setBILL_INTERCHG_GRP(cutSpaces(p->cGrp,2));
   CRDeviceSegment::instance()->setACPT_TERM_SORT_FLG(cutSpaces(&p->cSortSW,1));
   if (memcmp(p->sRegEFormat,"00",2) == 0
      || memcmp(p->sRegEFormat,"01",2) == 0)
   {
      hRegE00* pRegE = (hRegE00*)p->sRegE;
      CRDeviceSegment::instance()->setADDRESS(cutSpaces(pRegE->sADDRESS,sizeof(pRegE->sADDRESS)));
      CRDeviceSegment::instance()->setCITY(cutSpaces(pRegE->sCITY,sizeof(pRegE->sCITY)));
   }
   else
   if (memcmp(p->sRegEFormat,"02",2) == 0)
   {
      hRegE02* pRegE = (hRegE02*)p->sRegE;
      CRDeviceSegment::instance()->setADDRESS(cutSpaces(pRegE->sADDRESS,sizeof(pRegE->sADDRESS)));
      CRDeviceSegment::instance()->setCITY(cutSpaces(pRegE->sCITY,sizeof(pRegE->sCITY)));
      CRDeviceSegment::instance()->setREGION(cutSpaces(pRegE->sREGION,sizeof(pRegE->sREGION)));
      CRDeviceSegment::instance()->setCOUNTRY(cutSpaces(pRegE->sCOUNTRY,sizeof(pRegE->sCOUNTRY)));
      CRDeviceSegment::instance()->setPOSTAL_CODE(cutSpaces(pRegE->sPOSTAL_CODE,8));
   }
   else
   if (memcmp(p->sRegEFormat,"03",2) == 0)
   {
      hRegE03* pRegE = (hRegE03*)p->sRegE;
      CRDeviceSegment::instance()->setADDRESS(cutSpaces(pRegE->sADDRESS,sizeof(pRegE->sADDRESS)));
      CRDeviceSegment::instance()->setCITY(cutSpaces(pRegE->sCITY,sizeof(pRegE->sCITY)));
      CRDeviceSegment::instance()->setREGION(cutSpaces(pRegE->sREGION,sizeof(pRegE->sREGION)));
   }
   else
   if (memcmp(p->sRegEFormat,"05",2) == 0)
   {
      hRegE05* pRegE = (hRegE05*)p->sRegE;
      CRDeviceSegment::instance()->setADDRESS(cutSpaces(pRegE->sADDRESS,sizeof(pRegE->sADDRESS)));
      CRDeviceSegment::instance()->setCITY(cutSpaces(pRegE->sCITY,sizeof(pRegE->sCITY)));
      CRDeviceSegment::instance()->setREGION(cutSpaces(pRegE->sREGION,sizeof(pRegE->sREGION)));
   }
   else
   if (memcmp(p->sRegEFormat,"CD",2) == 0
      || memcmp(p->sRegEFormat,"C1",2) == 0)
   {
      hRegECD* pRegE = (hRegECD*)p->sRegE;
      CRDeviceSegment::instance()->setCITY(cutSpaces(pRegE->sCITY,sizeof(pRegE->sCITY)));
      CRDeviceSegment::instance()->setREGION(cutSpaces(pRegE->sREGION,sizeof(pRegE->sREGION)));
      CRDeviceSegment::instance()->setADDRESS(cutSpaces(pRegE->sADDRESS,12));
   }
   else
   {
      hRegE04* pRegE = (hRegE04*)p->sRegE;
      CRDeviceSegment::instance()->setADDRESS(cutSpaces(pRegE->sADDRESS,sizeof(pRegE->sADDRESS)));
      CRDeviceSegment::instance()->setCITY(cutSpaces(pRegE->sCITY,sizeof(pRegE->sCITY)));
      CRDeviceSegment::instance()->setREGION(cutSpaces(pRegE->sREGION,sizeof(pRegE->sREGION)));
   }
   CRDeviceSegment::instance()->setRPT_LVL_ID(cutSpaces(p->cMerch,6));
   // set INST_ID based on merchant institution
   map<string,string,less<string> >::iterator pMerchant;
   pMerchant = m_hMerchant.find(cutSpaces(p->cMerch,6));
   if (pMerchant != m_hMerchant.end())
      CRDeviceSegment::instance()->setINST_ID((*pMerchant).second);
  //## end IBMMTF::copyTerminal%38DB9736037B.body
}

void IBMMTF::copyTerminalAddendum ()
{
  //## begin IBMMTF::copyTerminalAddendum%38DB973700CA.body preserve=yes
   // CX06: SW_Copies_Terminal_Addendum_From_MTF
   UseCase hUseCase("IBM","## CX06 TERMINAL ADDENDUM");
   hIBMMTFTermAdd* p = (hIBMMTFTermAdd*)m_psBuffer;
   m_pFileSegment = CRDeviceSegment::instance();
   CRDeviceSegment::instance()->reset();
   string strDEVICE_ID(cutSpaces(p->cMTFKey,8));
   size_t pos = strDEVICE_ID.find_first_not_of(" ");
   if (pos > 0)
      strDEVICE_ID.erase(0,pos);
   CRDeviceSegment::instance()->setDEVICE_ID(strDEVICE_ID);
   CRDeviceSegment::instance()->setSETL_INST_ID(cutSpaces(p->cStlInst,9));
   CRDeviceSegment::instance()->setSETL_ACCT_NO(cutSpaces(p->cStlAcct,17));
   CRDeviceSegment::instance()->setFUNDS_MOVEMENT_OPT("00");
   CRDeviceSegment::instance()->setVENDOR_MODEL(cutSpaces(p->cVendModel,8));
   CRDeviceSegment::instance()->setPOSTAL_CODE(cutSpaces(p->cPostalCode,10));
  //## end IBMMTF::copyTerminalAddendum%38DB973700CA.body
}

bool IBMMTF::read ()
{
  //## begin IBMMTF::read%38DA94320220.body preserve=yes
   // CX02: Operator_Resets_IBMMTFReader
   #define MTF_PROC '0'
   #define MTF_PROC_ADD '5'
   #define MTF_INST '1'
   #define MTF_INST_ADD '6'
   #define MTF_TERM '7'
   #define MTF_TERM_ADD '8'
   #define MTF_MERCH '3'
   #define MTF_MERCH_ADD '4'
   if (!m_pGenerationDataGroup)
   {
      m_pGenerationDataGroup = new GenerationDataGroup(Application::instance()->image(),Application::instance()->name(),getName().c_str(),true);
      if(!m_pGenerationDataGroup->open())
         return false;
   }
   if (m_pFileSegment)
      m_pFileSegment->setPresence(false);
   m_pFileSegment = 0;
   while (m_pFileSegment == 0)
   {
      size_t lRecordLength = 0;
      if (!m_pGenerationDataGroup->read(m_psBuffer,150,&lRecordLength))
      {
         if(!m_bRecordsFound)
         {
            m_pGenerationDataGroup->commit();
            Database::instance()->commit();
         }
         return false;
      }
#ifndef MVS
      CodeTable::translate(m_psBuffer,150,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
      hIBMMTF* pIBMMTF = (hIBMMTF*)m_psBuffer;
      switch (pIBMMTF->cMTFKeyType)
      {
         case MTF_PROC:
            copyProcessor();
            break;
         case MTF_INST:
            copyInstitution();
            break;
         case MTF_TERM:
            copyTerminal();
            break;
         case MTF_TERM_ADD:
            copyTerminalAddendum();
            break;
         case MTF_MERCH:
            copyMerchant();
            break;
         case MTF_MERCH_ADD:
            copyMerchantAddendum();
            break;
      }
   }
   m_bRecordsFound = true;
   m_pFileSegment->setPresence(true);
   return true;
  //## end IBMMTF::read%38DA94320220.body
}

// Additional Declarations
  //## begin IBMMTF%38DA887101A1.declarations preserve=yes
  //## end IBMMTF%38DA887101A1.declarations

//## begin module%38DA893102A2.epilog preserve=yes
//## end module%38DA893102A2.epilog
