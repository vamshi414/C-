//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38A467190111.cm preserve=no
//	$Date:   May 08 2007 03:23:52  $ $Author:   d01575  $
//	$Revision:   1.13  $
//## end module%38A467190111.cm

//## begin module%38A467190111.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%38A467190111.cp

//## Module: CXOPIM00%38A467190111; Package specification
//## Subsystem: IM%38A4663D0165
//## Source file: C:\Devel\Dn\Server\Application\IM\CXODIM00.hpp

#ifndef CXOPIM00_h
#define CXOPIM00_h 1

//## begin module%38A467190111.additionalIncludes preserve=no
//## end module%38A467190111.additionalIncludes

//## begin module%38A467190111.includes preserve=yes
// $Date:   May 08 2007 03:23:52  $ $Author:   d01575  $ $Revision:   1.13  $
//## end module%38A467190111.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIM02_h
#include "CXODIM02.hpp"
#endif
#ifndef CXOSNC19_h
#include "CXODNC19.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntityCommand_CAT%394E2706012A
namespace entitycommand {
class CRUpdateCommand;
} // namespace entitycommand

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class IString;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%38A467190111.declarations preserve=no
//## end module%38A467190111.declarations

//## begin module%38A467190111.additionalDeclarations preserve=yes
//## end module%38A467190111.additionalDeclarations


//## begin IBMMTFReader%38A462130325.preface preserve=yes
//## end IBMMTFReader%38A462130325.preface

//## Class: IBMMTFReader%38A462130325
//	<body>
//	<title>CG
//	<h1>IM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server requires replicated
//	configuration information from the acquiring platform
//	switch database.
//	<p>
//	The eFunds Connex on IBM MTF file (CF) is read by the e
//	Funds Connex on IBM MTF Interface (<i>ca</i>CU) to
//	update the DataNavigator Configuration Repository (CR).
//	A new file should be copied to the DataNavigator Server
//	following the completion of any related maintenance to
//	the eFunds Connex on IBM CR.
//	</p>
//	<img src=CXOCIM00.gif>
//	<h2>FO
//	<h3>Entity Tables
//	<p>
//	The eFunds Connex on IBM MTF Interface populates the
//	following tables in the configuration repository:
//	<ul>
//	<li><i>qualify</i>.PROCESSOR
//	<li><i>qualify</i>.REPORTING_LVL
//	<li><i>qualify</i>.INSTITUTION
//	<li><i>qualify</i>.DEVICE
//	<li><i>qualify</i>.PAN_MASK
//	</ul>
//	<p>
//	After entities are added by the eFunds Connex on IBM MTF
//	Interface, additional manual changes can be made using
//	the CR Client.
//	These tables are in the EFT-Entity Tables folder in the
//	CR Client for the DataNavigator Server.
//	<p>
//	Your DBA contact is notified of any new entities via an
//	email.
//	The Generic Configuration Interface service
//	documentation contains information on modifying the
//	email template.
//	</body>
//	<body>
//	<title>OG
//	<h1>IM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server requires replicated
//	configuration information from the acquiring platform
//	switch database.
//	</p>
//	<img src=CXOOIM00.gif>
//	</body>
//## Category: Platform \: eFunds Connex on IBM::IBMMTFReader_CAT%38A4617903AF
//## Subsystem: IM%38A4663D0165
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..1



//## Uses: <unnamed>%3A27FAD90246;IF::Message { -> F}
//## Uses: <unnamed>%3A27FB34000C;monitor::UseCase { -> F}
//## Uses: <unnamed>%3DEE849A033C;database::Database { -> F}
//## Uses: <unnamed>%3DFDD2BE031C;entitycommand::CRUpdateCommand { -> F}
//## Uses: <unnamed>%40AA50CD008C;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%461F6309018C;reusable::IString { -> F}

class IBMMTFReader : public process::Application  //## Inherits: <unnamed>%38A4658E00A5
{
  //## begin IBMMTFReader%38A462130325.initialDeclarations preserve=yes
  //## end IBMMTFReader%38A462130325.initialDeclarations

  public:
    //## Constructors (generated)
      IBMMTFReader();

    //## Destructor (generated)
      virtual ~IBMMTFReader();


    //## Other Operations (specified)
      //## Operation: initialize%38A46EE403E1
      virtual int initialize ();

    // Additional Public Declarations
      //## begin IBMMTFReader%38A462130325.public preserve=yes
      //## end IBMMTFReader%38A462130325.public

  protected:

    //## Other Operations (specified)
      //## Operation: onReset%38DB6F060238
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>IM
      //	<h2>CD
      //	<h3>Replicate Configuration
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>CU
      //	<h4>Description
      //	<p>
      //	The EFT platform configuration is replicated to the Data
      //	Navigator Configuration Repository
      //	</p>
      //	<h4>Schedule
      //	<p>
      //	The DataNavigator Server installation automatically sets
      //	up an event to perform this command at 05:00 AM.
      //	This time can be changed to coincide with the acquiring
      //	platform database maintenance schedule.
      //	Events are in the Event Management folder in the CR
      //	Client for the DataNavigator Server.
      //	</p>
      //	</body>
      //	<body>
      //	<title>OG
      //	<h1>IM
      //	<h2>CD
      //	<h3>Copy eFunds Connex on IBM MTF to DataNavigator CR
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>CU
      //	<h4>Description
      //	<p>
      //	The eFunds Connex on IBM MTF Interface services reads an
      //	eFunds Connex on IBM MTF file and updates the PROCESSOR,
      //	INSTITUTION, REPORTING_LVL, DEVICE and PAN_MASK tables
      //	in the DataNavigator CR.
      //	</p>
      //	</body>
      virtual int onReset (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin IBMMTFReader%38A462130325.protected preserve=yes
      //## end IBMMTFReader%38A462130325.protected

  private:
    // Additional Private Declarations
      //## begin IBMMTFReader%38A462130325.private preserve=yes
      //## end IBMMTFReader%38A462130325.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: eFunds Connex on IBM::IBMMTFReader_CAT::<unnamed>%461F64DB0165
      //## Role: IBMMTFReader::<m_hCRFile>%461F64DB02BD
      //## begin IBMMTFReader::<m_hCRFile>%461F64DB02BD.role preserve=no  public: entitycommand::CRFile { -> VHgN}
      entitycommand::CRFile m_hCRFile;
      //## end IBMMTFReader::<m_hCRFile>%461F64DB02BD.role

      //## Association: Platform \: eFunds Connex on IBM::IBMMTFReader_CAT::<unnamed>%461F64DD0359
      //## Role: IBMMTFReader::<m_hIBMMTF>%461F64DE0156
      //## begin IBMMTFReader::<m_hIBMMTF>%461F64DE0156.role preserve=no  public: IBMMTF { -> VHgN}
      IBMMTF m_hIBMMTF;
      //## end IBMMTFReader::<m_hIBMMTF>%461F64DE0156.role

    // Additional Implementation Declarations
      //## begin IBMMTFReader%38A462130325.implementation preserve=yes
      //## end IBMMTFReader%38A462130325.implementation

};

//## begin IBMMTFReader%38A462130325.postscript preserve=yes
//## end IBMMTFReader%38A462130325.postscript

//## begin module%38A467190111.epilog preserve=yes
//## end module%38A467190111.epilog


#endif
