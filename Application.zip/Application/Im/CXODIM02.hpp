//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38DA892E035C.cm preserve=no
//	$Date:   May 08 2007 03:23:54  $ $Author:   d01575  $
//	$Revision:   1.8  $
//## end module%38DA892E035C.cm

//## begin module%38DA892E035C.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%38DA892E035C.cp

//## Module: CXOSIM02%38DA892E035C; Package specification
//## Subsystem: IM%38A4663D0165
//## Source file: C:\Devel\Dn\Server\Application\IM\CXODIM02.hpp

#ifndef CXOSIM02_h
#define CXOSIM02_h 1

//## begin module%38DA892E035C.additionalIncludes preserve=no
//## end module%38DA892E035C.additionalIncludes

//## begin module%38DA892E035C.includes preserve=yes
// $Date:   May 08 2007 03:23:54  $ $Author:   d01575  $ $Revision:   1.8  $
#include <map>
//## end module%38DA892E035C.includes

#ifndef CXOSNC19_h
#include "CXODNC19.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class CRDeviceSegment;
class CRInstitutionSegment;
class CRProcessorSegment;
class CRReportingLevelSegment;
} // namespace entitysegment

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CheckDigit;
} // namespace reusable

namespace IF {
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GenerationDataGroup;

} // namespace database

//## begin module%38DA892E035C.declarations preserve=no
//## end module%38DA892E035C.declarations

//## begin module%38DA892E035C.additionalDeclarations preserve=yes
//## end module%38DA892E035C.additionalDeclarations


//## begin IBMMTF%38DA887101A1.preface preserve=yes
//## end IBMMTF%38DA887101A1.preface

//## Class: IBMMTF%38DA887101A1
//## Category: Platform \: eFunds Connex on IBM::IBMMTFReader_CAT%38A4617903AF
//## Subsystem: IM%38A4663D0165
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%38DB9A040175;entitysegment::CRProcessorSegment { -> F}
//## Uses: <unnamed>%38DBCE650299;entitysegment::CRDeviceSegment { -> F}
//## Uses: <unnamed>%38DBCE680211;entitysegment::CRInstitutionSegment { -> F}
//## Uses: <unnamed>%38DBCE6B00AD;entitysegment::CRReportingLevelSegment { -> F}
//## Uses: <unnamed>%3916CDAE0098;reusable::CheckDigit { -> F}
//## Uses: <unnamed>%3A27FD80013E;monitor::UseCase { -> F}
//## Uses: <unnamed>%3DEF3A1202AF;IF::FlatFile { -> F}
//## Uses: <unnamed>%3DEF4080000F;IF::CodeTable { -> F}
//## Uses: <unnamed>%461F30C50382;database::GenerationDataGroup { -> F}
//## Uses: <unnamed>%461F31120140;process::Application { -> F}

class IBMMTF : public entitycommand::CRFile  //## Inherits: <unnamed>%3DEE85D60167
{
  //## begin IBMMTF%38DA887101A1.initialDeclarations preserve=yes
  //## end IBMMTF%38DA887101A1.initialDeclarations

  public:
    //## Constructors (generated)
      IBMMTF();

    //## Destructor (generated)
      virtual ~IBMMTF();


    //## Other Operations (specified)
      //## Operation: read%38DA94320220
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>IM
      //	<h2>FI
      //	<h3>eFunds Connex on IBM MTF
      //	<p>
      //	The Connex on IBM MTF file must be transmitted from the
      //	acquiring EFT platform to the DataNavigator server.
      //	The eFunds Connex on IBM Interface service reads the
      //	file:
      //	<ul>
      //	<li><i>node001\custqual</i>\CR.txt
      //	</ul>
      //	<p>
      //	The following records are replicated:
      //	<ul>
      //	<li>0,5 - Processor
      //	<li>1,6 - Institution
      //	<li>3,4 - Reporting Level
      //	<li>7,8 - Terminal Device
      //	</ul>
      //	</body>
      virtual bool read ();

    // Additional Public Declarations
      //## begin IBMMTF%38DA887101A1.public preserve=yes
      //## end IBMMTF%38DA887101A1.public

  protected:
    // Additional Protected Declarations
      //## begin IBMMTF%38DA887101A1.protected preserve=yes
      //## end IBMMTF%38DA887101A1.protected

  private:

    //## Other Operations (specified)
      //## Operation: copyInstitution%38DB94CD02FC
      void copyInstitution ();

      //## Operation: copyMerchant%38DB97350398
      void copyMerchant ();

      //## Operation: copyMerchantAddendum%38DB9761028D
      void copyMerchantAddendum ();

      //## Operation: copyProcessor%38DB97360231
      void copyProcessor ();

      //## Operation: copyTerminal%38DB9736037B
      void copyTerminal ();

      //## Operation: copyTerminalAddendum%38DB973700CA
      void copyTerminalAddendum ();

    // Additional Private Declarations
      //## begin IBMMTF%38DA887101A1.private preserve=yes
      //## end IBMMTF%38DA887101A1.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin IBMMTF%38DA887101A1.implementation preserve=yes
       map<string,string,less<string> > m_hMerchant;
      //## end IBMMTF%38DA887101A1.implementation
};

//## begin IBMMTF%38DA887101A1.postscript preserve=yes
//## end IBMMTF%38DA887101A1.postscript

//## begin module%38DA892E035C.epilog preserve=yes
//## end module%38DA892E035C.epilog


#endif
