//  Copyright (c) 1998 - 2004
//  eFunds Corporation
// $Date:   Mar 16 2006 11:49:40  $ $Author:   D02405  $ $Revision:   1.6  $

#ifndef CXODIM01_HPP
#define CXODIM01_HPP

#include "CXODRU32.hpp"
struct hIBMMTF
{
   char cDeleteFlag;
   char cMTFKeyType;
   char cMTFKey[8];
   char cMTFData[140];
};

struct hIBMMTFProc
{
   char cFiller1;
   char cMTFKeyType;
   char cMTFKeyProcPrefix[2];
   char cMTFKeyProcID[6];
   char cFiller2[3];
   char cName[30];
   char cFiller3;
   char cSDDA[17];
   char cFDDA[17];
   char cSVLN[2];
   char cACHsFRDABA[9];
   char cACHfFRDABA[9];
   char cNACHAOpt[2];
   char cCircuitID[6];
   char cIntercept[2];
   char cI03Ind;
   char cI03Time[6];
   char cI03StartCK[6];
   char cI03SVLN[20];
   char cRptOpts[3];
   char cPI[6];
};

struct hIBMMTFProcAdd
{
   char cFiller1;
   char cMTFKeyType;
   char cMTFKey[8];
   char cAdjABA[9];
   char cAdjAcct[17];
   char cOnlnFeeABA[9];
   char cOnlnFeeAcct[17];
   char cFiller2[88];
};

struct hIBMMTFInst
{
   char cFiller1;
   char cMTFKeyType;
   char cMTFKey[8];
   char cDDA[9];
   char cProc[6];
   char cName[30];
   char cBill[2];
   char cACHsFRDABA[9];
   char cACHfFRDABA[9];
   char cACHsDDA[17];
   char cACHfDDA[17];
   char cNACHAOpt[2];
   char cI03Ind;
   char cI03Time[6];
   char cI03StartCK[6];
   char cI03SVLN[20];
   char cChainSw;
   char cCurrType;
   char cFiller2[4];
};

struct hIBMMTFInstAdd
{
   char cFiller1;
   char cMTFKeyType;
   char cMTFKey[8];
   char cAdjABA[9];
   char cAdjAcct[17];
   char cOnlnFeeABA[9];
   char cOnlnFeeAcct[17];
   char cFiller2[88];
};

struct hIBMMTFMerch
{
   char cFiller1;
   char cMTFKeyType;
   char cMTFKey[8];
   char cDDA[9];
   char cInst[8];
   char cPhone[10];
   char cDesc40[40];
   char cDesc20_1[20];
   char cDesc20_2[20];
   char cDesc12[12];
   char cCorp[6];
   char cAcct15[15];
};

struct hIBMMTFMerchAdd
{
   char cFiller1;
   char cMTFKeyType;
   char cMTFKey[8];
   char cStlInst[9];
   char cStlAcct[17];
   char cStlOpt[2];
   char cFeebABA[9];
   char cFeebAcct[17];
   char cAdjABA[9];
   char cAdjAcct[17];
   char cOnlnFeeABA[9];
   char cOnlnFeeAcct[17];
   char cFiller2[34];
};

struct hIBMMTFTerm
{
   char cFiller1;
   char cMTFKeyType;
   char cMTFKey[8];
   char cMerch[6];
   char cWmerch[6];
   char sRegE[50];
   char cClass[2];
   char cCircuitID[6];
   char cController[6];
   char cI03Ind;
   char cI03Time[6];
   char cI03TimeStartCK[6];
   char cDevType[5];
   char cFiller[15];
   char cBill[2];
   char cPIN[2];
   char cFiller3[11];
   char cProtocol;
   char cComp;
   char cDes[8];
   char cFiller4;
   char cGrp[2];
   char cSortSW;
   char sRegEFormat[2];
};

struct hRegE00
{
   char sADDRESS[28];        // assume sizeof(DEVICE.ADDRESS)
   char sCITY[22];           // 50
};

struct hRegE02
{
   char sADDRESS[25];
   char sCITY[13];
   char sREGION[2];
   char sCOUNTRY[2];
   char sPOSTAL_CODE[11];    // 53
};

struct hRegE03
{
   char sADDRESS[17];
   char sCITY[13];
   char sREGION[2];          // 32
};

struct hRegE04
{
   char sADDRESS[18];
   char sCITY[13];
   char sREGION[2];
   char sName[14];           // 47
};

struct hRegE05
{
   char sADDRESS[28];
   char sCITY[15];
   char sREGION[2];
   char sName[25];
   char sPOSTAL_CODE[9];
   char sCOUNTY[3];
   char sCOUNTRY[2];         // 84
};

struct hRegECD
{
   char sRPT_LVL_NAME[25];
   char sCITY[11];
   char sREGION[2];
   char sADDRESS[19];
   char sPOSTAL_CODE[9];
   char sCOUNTRY[2];         // 68
};

struct hIBMMTFTermAdd
{
   char cFiller1;
   char cMTFKeyType;
   char cMTFKey[8];
   char cStlInst[9];
   char cStlAcct[17];
   char cStlOpt[2];
   short cHowAttach;
   char cLoadImageInfoID[8];
   char cVendModel[8];
   char cFeebABA[9];
   char cFeebAcct[17];
   char cAdjABA[9];
   char cAdjAcct[17];
   char cOnlnFeeABA[9];
   char cOnlnFeeAcct[17];
   char cPostalCode[10];
   char cFiller2[6];
};
#include "CXODRU33.hpp"

#endif
