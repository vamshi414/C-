// Copyright (c) 1998 - 2009
// Fidelity National Information Services
// $Date:   Sep 12 2008 15:53:06  $ $Author:   D02405  $ $Revision:   1.5  $
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif

#include "CXODIF11.hpp"
#include "CXODSI01.hpp"
#include "CXODVP01.hpp"
#include "CXODMN05.hpp"
#include "CXODDZ01.hpp"
#include "CXODIF32.hpp"

#include "CXODPS06.hpp"
   pApplication = new SwitchInterface();
   pApplication->parseCommandLine(argc,argv);
   new dnplatform::DNPlatform();
   ((SwitchInterface*)pApplication)->setMessageProcessor(new VisaBaseIIMessageProcessor);
   int iRC = 0;
   {
      iRC = pApplication->initialize();
      UseCase hUseCase("VISA","## VI10 START VI");
      if (iRC == -1)
         UseCase::setSuccess(false);
   }
   if (iRC == 0)
      pApplication->run();
#include "CXODPS07.hpp"
