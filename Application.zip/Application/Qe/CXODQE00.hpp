//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36751AC502D6.cm preserve=no
//## end module%36751AC502D6.cm

//## begin module%36751AC502D6.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36751AC502D6.cp

//## Module: CXOPQE00%36751AC502D6; Package specification
//## Subsystem: QE%3597F12A035E
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qe\CXODQE00.hpp

#ifndef CXOPQE00_h
#define CXOPQE00_h 1

//## begin module%36751AC502D6.additionalIncludes preserve=no
//## end module%36751AC502D6.additionalIncludes

//## begin module%36751AC502D6.includes preserve=yes
//## end module%36751AC502D6.includes

#ifndef CXOSBC03_h
#include "CXODBC03.hpp"
#endif
#ifndef CXOSPS03_h
#include "CXODPS03.hpp"
#endif
#ifndef CXOSEX67_h
#include "CXODEX67.hpp"
#endif
#ifndef CXOSUA07_h
#include "CXODUA07.hpp"
#endif
#ifndef CXOSSX52_h
#include "CXODSX52.hpp"
#endif
#ifndef CXOSUA01_h
#include "CXODUA01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RESTCommand_CAT%645AEC55037E
namespace restcommand {
class SettingsCommand;
} // namespace restcommand

//## Modelname: Totals Management::TotalsCommand_CAT%3884FA670353
namespace totalscommand {
class FinancialSum;
class Total;
class FinancialTotalsCommand;
} // namespace totalscommand

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialBaseSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::UserCommand_CAT%394E26E302E3
namespace usercommand {
class FinancialWebListCommand;
class TransactionHighlightCommand;
class GetPreauthTranCommand;
class FinancialAdvancedListCommand;
class FinancialBasicListCommand;
} // namespace usercommand

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: DataNavigator Foundation::SOAPCommand_CAT%4DC0633D0140
namespace soapcommand {
class TokenUpdateCommand;
class TokenListCommand;
class PanTokenCommand;
class ATMElectronicJournalCommand;
class ExternalAdjustmentListCommand;
class ATMReceiptListCommand;
class TransactionListCommand;
} // namespace soapcommand

namespace restcommand {
class ServersCommand;
class FinancialTotalsCommand;
class TransactionListCommand;
class ServicesCommand;
class SaveSettingsCommand;
class ProfilesCommand;
class EntitiesCommand;
class ReconFilesCommand;
class ReconsCommand;
class ConfigurationCommand;
} // namespace restcommand

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Mask;
class Transaction;
} // namespace reusable

namespace IF {
class Trace;
class Extract;
class Queue;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace database {
class Database;
class CRTransactionTypeIndicator;
class DataModel;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class AuditEvent;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class DNSecurity;
} // namespace command

//## Modelname: Reconciliation::ReconciliationUserInterface_CAT%4F5724BB00C4
namespace reconciliationuserinterface {
class ReconAuditCommand;
class ReconTotalListCommand;
class ReconDateListCommand;
class ReconFileListCommand;
class ReconTransitionCommand;
class ReconExtDetailsCommand;

} // namespace reconciliationuserinterface

//## begin module%36751AC502D6.declarations preserve=no
//## end module%36751AC502D6.declarations

//## begin module%36751AC502D6.additionalDeclarations preserve=yes
//## end module%36751AC502D6.additionalDeclarations


//## begin QueryEngine%34567B940016.preface preserve=yes
//## end QueryEngine%34567B940016.preface

//## Class: QueryEngine%34567B940016
//	<body>
//	<title>CG
//	<h1>QE
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The FIS DataNavigator data repository can support any
//	number of months of financial transactions.
//	These transactions are accessible to the DataNavigator
//	web client via the server transaction research services.
//	The web client provides a request message of search
//	criteria that must include a network value or one value
//	that is indexed in the database:
//	<ul>
//	<li>Primary Account Number (PAN)
//	<li>Card BIN
//	<li>Bank account number
//	<li>Issuer institution
//	<li>Issuer processor
//	<li>Device
//	<li>Merchant
//	<li>Acquirer institution
//	<li>Acquirer processor
//	</ul>
//	The network values are not indexed (searches are divided
//	into 5 minute increments of time):
//	<ul>
//	<li>Acquirer network
//	<li>Issuer network
//	</ul>
//	<p>
//	The request can also include tests of any other
//	attribute of the transaction as secondary search
//	criteria.
//	<p>
//	The Query Engine services (<i>ca</i>QE<i>nn</i>) return
//	financial transactions based on these adhoc query
//	requests from the web.
//	All requests from the web clients come through the
//	Client Interface service (<i>ca</i>CI01).
//	Any number of Query Engine services can be configured
//	based on the number of active concurrent users.
//	</p>
//	</body>
//## Category: Transaction Research and Adjustments::QueryEngine_CAT%354B34BE02EF
//## Subsystem: QE%3597F12A035E
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..n



//## Uses: <unnamed>%36752AFB02DE;reusable::Transaction { -> F}
//## Uses: <unnamed>%36752B17023E;IF::Queue { -> F}
//## Uses: <unnamed>%36752B2C02D4;IF::Message { -> F}
//## Uses: <unnamed>%36DED8610104;database::Database { -> F}
//## Uses: <unnamed>%3820AC0203CC;IF::Extract { -> F}
//## Uses: <unnamed>%3A01E3890156;monitor::UseCase { -> F}
//## Uses: <unnamed>%4017BEC8001F;ems::EMSNetRuleUseTable { -> F}
//## Uses: <unnamed>%40A4D69901E4;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%40A4D6AF0000;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%52C72B9C0349;command::DNSecurity { -> F}
//## Uses: <unnamed>%546200B10121;entitysegment::Customer { -> F}
//## Uses: <unnamed>%546200F10218;totalscommand::Total { -> F}
//## Uses: <unnamed>%546201160348;IF::Trace { -> F}
//## Uses: <unnamed>%54620145038F;segment::AuditEvent { -> F}
//## Uses: <unnamed>%5462016002F8;reusable::Mask { -> F}
//## Uses: <unnamed>%5462019201B6;repositorysegment::FinancialBaseSegment { -> F}
//## Uses: <unnamed>%546204C10397;database::DataModel { -> F}
//## Uses: <unnamed>%64E420BC01BA;totalscommand::FinancialSum { -> F}
//## Uses: <unnamed>%64E4211C0188;database::CRTransactionTypeIndicator { -> F}

class QueryEngine : public process::ServiceApplication  //## Inherits: <unnamed>%3BCED9B201A5
{
  //## begin QueryEngine%34567B940016.initialDeclarations preserve=yes
  //## end QueryEngine%34567B940016.initialDeclarations

  public:
    //## Constructors (generated)
      QueryEngine();

    //## Destructor (generated)
      virtual ~QueryEngine();


    //## Other Operations (specified)
      //## Operation: initialize%36751B5F024C
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>QE
      //	<h2>MS
      //	<h3>Scalability
      //	<p>
      //	The initial setup of the DataNavigator server typically
      //	installs four Query Engine services.  The actual number
      //	can vary from 1 to as many as 99 services.
      //	<p>
      //	Additional Query Engine services can be added to support
      //	any number (up to 99) of simultaneous transaction
      //	research requests from end-users.
      //	Current usage of the Query Engine services can be
      //	determined by examining the Client CL59 LIST FIN
      //	ADVANCED entry in System Health Monitor.
      //	</p>
      //	<h3>Performance
      //	<p>
      //	Transaction research response times are improved through
      //	accurate statistics in the database.
      //	The RUNSTATS utility should be run on a regular schedule.
      //	This utility must be modified each month to execute
      //	against the current month's tables.
      //	</p>
      //	</body>
      virtual int initialize ();

      //## Operation: setCallback%3A79CCC301C3
      virtual void setCallback (Object* pCallback);

      //## Operation: update%36751B6A01E3
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin QueryEngine%34567B940016.public preserve=yes
      //## end QueryEngine%34567B940016.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%36751B6200A1
      virtual int onMessage (Message& hMessage);

      //## Operation: onResume%3A79C495012C
      virtual int onResume (Message& hMessage);

    // Additional Protected Declarations
      //## begin QueryEngine%34567B940016.protected preserve=yes
      //## end QueryEngine%34567B940016.protected

  private:
    // Additional Private Declarations
      //## begin QueryEngine%34567B940016.private preserve=yes
      //## end QueryEngine%34567B940016.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Callback%3A79CD4003B7
      //## begin QueryEngine::Callback%3A79CD4003B7.attr preserve=no  private: ClientCommand* {U} 0
      ClientCommand* m_pCallback;
      //## end QueryEngine::Callback%3A79CD4003B7.attr

      //## Attribute: Source%3B42192402AF
      //## begin QueryEngine::Source%3B42192402AF.attr preserve=no  private: string {V} 
      string m_strSource;
      //## end QueryEngine::Source%3B42192402AF.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%3675201F01BE
      //## Role: QueryEngine::<m_pGetFinancialCommand>%3675201F03DB
      //## begin QueryEngine::<m_pGetFinancialCommand>%3675201F03DB.role preserve=no  public: ems::GetFinancialCommand { -> RHgN}
      ems::GetFinancialCommand *m_pGetFinancialCommand;
      //## end QueryEngine::<m_pGetFinancialCommand>%3675201F03DB.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%372D893B0353
      //## Role: QueryEngine::<m_hDynamicSQLCommand>%372D893C03A4
      //## begin QueryEngine::<m_hDynamicSQLCommand>%372D893C03A4.role preserve=no  public: command::DynamicSQLCommand { -> VHgN}
      command::DynamicSQLCommand m_hDynamicSQLCommand;
      //## end QueryEngine::<m_hDynamicSQLCommand>%372D893C03A4.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%3922CE860004
      //## Role: QueryEngine::<m_pFinancialAdvancedListCommand>%3922CE86022A
      //## begin QueryEngine::<m_pFinancialAdvancedListCommand>%3922CE86022A.role preserve=no  public: usercommand::FinancialAdvancedListCommand { -> RFHgN}
      usercommand::FinancialAdvancedListCommand *m_pFinancialAdvancedListCommand;
      //## end QueryEngine::<m_pFinancialAdvancedListCommand>%3922CE86022A.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%3922CEA00264
      //## Role: QueryEngine::<m_pFinancialBasicListCommand>%3922CEA10175
      //## begin QueryEngine::<m_pFinancialBasicListCommand>%3922CEA10175.role preserve=no  public: usercommand::FinancialBasicListCommand { -> RFHgN}
      usercommand::FinancialBasicListCommand *m_pFinancialBasicListCommand;
      //## end QueryEngine::<m_pFinancialBasicListCommand>%3922CEA10175.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%3CB45B110232
      //## Role: QueryEngine::<m_pGetPreauthTranCommand>%3CB45B1B02CE
      //## begin QueryEngine::<m_pGetPreauthTranCommand>%3CB45B1B02CE.role preserve=no  public: usercommand::GetPreauthTranCommand { -> RFHgN}
      usercommand::GetPreauthTranCommand *m_pGetPreauthTranCommand;
      //## end QueryEngine::<m_pGetPreauthTranCommand>%3CB45B1B02CE.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%434F60AE0124
      //## Role: QueryEngine::<m_pTransactionHighlightCommand>%434F60B10309
      //## begin QueryEngine::<m_pTransactionHighlightCommand>%434F60B10309.role preserve=no  public: usercommand::TransactionHighlightCommand { -> RFHgN}
      usercommand::TransactionHighlightCommand *m_pTransactionHighlightCommand;
      //## end QueryEngine::<m_pTransactionHighlightCommand>%434F60B10309.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%4350DB3D02B1
      //## Role: QueryEngine::<m_pFinancialWebListCommand>%4350DB3F02D2
      //## begin QueryEngine::<m_pFinancialWebListCommand>%4350DB3F02D2.role preserve=no  public: usercommand::FinancialWebListCommand { -> RFHgN}
      usercommand::FinancialWebListCommand *m_pFinancialWebListCommand;
      //## end QueryEngine::<m_pFinancialWebListCommand>%4350DB3F02D2.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%4F607DDE011B
      //## Role: QueryEngine::<m_pReconExtDetailsCommand>%4F607DDF01C7
      //## begin QueryEngine::<m_pReconExtDetailsCommand>%4F607DDF01C7.role preserve=no  public: reconciliationuserinterface::ReconExtDetailsCommand { -> RFHgN}
      reconciliationuserinterface::ReconExtDetailsCommand *m_pReconExtDetailsCommand;
      //## end QueryEngine::<m_pReconExtDetailsCommand>%4F607DDF01C7.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%4F607E43017A
      //## Role: QueryEngine::<m_pReconDateListCommand>%4F607E44014B
      //## begin QueryEngine::<m_pReconDateListCommand>%4F607E44014B.role preserve=no  public: reconciliationuserinterface::ReconDateListCommand { -> RFHgN}
      reconciliationuserinterface::ReconDateListCommand *m_pReconDateListCommand;
      //## end QueryEngine::<m_pReconDateListCommand>%4F607E44014B.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%4F607F6A0004
      //## Role: QueryEngine::<m_pReconFileListCommand>%4F607F6B014D
      //## begin QueryEngine::<m_pReconFileListCommand>%4F607F6B014D.role preserve=no  public: reconciliationuserinterface::ReconFileListCommand { -> RFHgN}
      reconciliationuserinterface::ReconFileListCommand *m_pReconFileListCommand;
      //## end QueryEngine::<m_pReconFileListCommand>%4F607F6B014D.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%4F607FE70276
      //## Role: QueryEngine::<m_pReconTransitionCommand>%4F607FE800C1
      //## begin QueryEngine::<m_pReconTransitionCommand>%4F607FE800C1.role preserve=no  public: reconciliationuserinterface::ReconTransitionCommand { -> RFHgN}
      reconciliationuserinterface::ReconTransitionCommand *m_pReconTransitionCommand;
      //## end QueryEngine::<m_pReconTransitionCommand>%4F607FE800C1.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%4F60804300F0
      //## Role: QueryEngine::<m_pReconTotalListCommand>%4F6080440083
      //## begin QueryEngine::<m_pReconTotalListCommand>%4F6080440083.role preserve=no  public: reconciliationuserinterface::ReconTotalListCommand { -> RFHgN}
      reconciliationuserinterface::ReconTotalListCommand *m_pReconTotalListCommand;
      //## end QueryEngine::<m_pReconTotalListCommand>%4F6080440083.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%4F6083F20106
      //## Role: QueryEngine::<m_pReconDetailsCommand>%4F6083F203D5
      //## begin QueryEngine::<m_pReconDetailsCommand>%4F6083F203D5.role preserve=no  public: reconciliationuserinterface::ReconDetailsCommand { -> RHgN}
      reconciliationuserinterface::ReconDetailsCommand *m_pReconDetailsCommand;
      //## end QueryEngine::<m_pReconDetailsCommand>%4F6083F203D5.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%4F73FC990302
      //## Role: QueryEngine::<m_pReconUpdateCommand>%4F73FC9A01BA
      //## begin QueryEngine::<m_pReconUpdateCommand>%4F73FC9A01BA.role preserve=no  public: reconciliationuserinterface::ReconUpdateCommand { -> RHgN}
      reconciliationuserinterface::ReconUpdateCommand *m_pReconUpdateCommand;
      //## end QueryEngine::<m_pReconUpdateCommand>%4F73FC9A01BA.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%504F258A0015
      //## Role: QueryEngine::<m_pReconAuditCommand>%504F258A02A9
      //## begin QueryEngine::<m_pReconAuditCommand>%504F258A02A9.role preserve=no  public: reconciliationuserinterface::ReconAuditCommand { -> RFHgN}
      reconciliationuserinterface::ReconAuditCommand *m_pReconAuditCommand;
      //## end QueryEngine::<m_pReconAuditCommand>%504F258A02A9.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%51A518DC0165
      //## Role: QueryEngine::<m_pSOAPTransactionListCommand>%51A518DD029C
      //## begin QueryEngine::<m_pSOAPTransactionListCommand>%51A518DD029C.role preserve=no  public: soapcommand::TransactionListCommand { -> RFHgN}
      soapcommand::TransactionListCommand *m_pSOAPTransactionListCommand;
      //## end QueryEngine::<m_pSOAPTransactionListCommand>%51A518DD029C.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%53BB05A6017C
      //## Role: QueryEngine::<m_pSOAPFinancialTotalsCommand>%53BB05A70322
      //## begin QueryEngine::<m_pSOAPFinancialTotalsCommand>%53BB05A70322.role preserve=no  public: totalscommand::FinancialTotalsCommand { -> RFHgN}
      totalscommand::FinancialTotalsCommand *m_pSOAPFinancialTotalsCommand;
      //## end QueryEngine::<m_pSOAPFinancialTotalsCommand>%53BB05A70322.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%591CBF15029B
      //## Role: QueryEngine::<m_pExternalAdjustmentListCommand>%591CBF1B010F
      //## begin QueryEngine::<m_pExternalAdjustmentListCommand>%591CBF1B010F.role preserve=no  public: soapcommand::ExternalAdjustmentListCommand { -> RFHgN}
      soapcommand::ExternalAdjustmentListCommand *m_pExternalAdjustmentListCommand;
      //## end QueryEngine::<m_pExternalAdjustmentListCommand>%591CBF1B010F.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%5ABA56AC00D4
      //## Role: QueryEngine::<m_pATMReceiptListCommand>%5ABA56AC0344
      //## begin QueryEngine::<m_pATMReceiptListCommand>%5ABA56AC0344.role preserve=no  public: soapcommand::ATMReceiptListCommand { -> RFHgN}
      soapcommand::ATMReceiptListCommand *m_pATMReceiptListCommand;
      //## end QueryEngine::<m_pATMReceiptListCommand>%5ABA56AC0344.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%5ABA56B8018C
      //## Role: QueryEngine::<m_pATMElectronicJournalCommand>%5ABA56B90014
      //## begin QueryEngine::<m_pATMElectronicJournalCommand>%5ABA56B90014.role preserve=no  public: soapcommand::ATMElectronicJournalCommand { -> RFHgN}
      soapcommand::ATMElectronicJournalCommand *m_pATMElectronicJournalCommand;
      //## end QueryEngine::<m_pATMElectronicJournalCommand>%5ABA56B90014.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%619343770375
      //## Role: QueryEngine::<m_pPanTokenCommand>%619343840325
      //## begin QueryEngine::<m_pPanTokenCommand>%619343840325.role preserve=no  public: soapcommand::PanTokenCommand { -> RFHgN}
      soapcommand::PanTokenCommand *m_pPanTokenCommand;
      //## end QueryEngine::<m_pPanTokenCommand>%619343840325.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%62CD4F4C0123
      //## Role: QueryEngine::<m_pTokenListCommand>%62CD4F5500C3
      //## begin QueryEngine::<m_pTokenListCommand>%62CD4F5500C3.role preserve=no  public: soapcommand::TokenListCommand { -> RFHgN}
      soapcommand::TokenListCommand *m_pTokenListCommand;
      //## end QueryEngine::<m_pTokenListCommand>%62CD4F5500C3.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%62CD4F5D0374
      //## Role: QueryEngine::<m_pTokenUpdateCommand>%62CD4F6800C6
      //## begin QueryEngine::<m_pTokenUpdateCommand>%62CD4F6800C6.role preserve=no  public: soapcommand::TokenUpdateCommand { -> RFHgN}
      soapcommand::TokenUpdateCommand *m_pTokenUpdateCommand;
      //## end QueryEngine::<m_pTokenUpdateCommand>%62CD4F6800C6.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%645B1037034C
      //## Role: QueryEngine::<m_pServersCommand>%645B10390136
      //## begin QueryEngine::<m_pServersCommand>%645B10390136.role preserve=no  public: restcommand::ServersCommand { -> RFHgN}
      restcommand::ServersCommand *m_pServersCommand;
      //## end QueryEngine::<m_pServersCommand>%645B10390136.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%64A823D401B3
      //## Role: QueryEngine::<m_pServicesCommand>%64A823D501E7
      //## begin QueryEngine::<m_pServicesCommand>%64A823D501E7.role preserve=no  public: restcommand::ServicesCommand { -> RFHgN}
      restcommand::ServicesCommand *m_pServicesCommand;
      //## end QueryEngine::<m_pServicesCommand>%64A823D501E7.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%64E42062000D
      //## Role: QueryEngine::<m_pRESTTransactionListCommand>%64E420630040
      //## begin QueryEngine::<m_pRESTTransactionListCommand>%64E420630040.role preserve=no  public: restcommand::TransactionListCommand { -> RFHgN}
      restcommand::TransactionListCommand *m_pRESTTransactionListCommand;
      //## end QueryEngine::<m_pRESTTransactionListCommand>%64E420630040.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%64E4206C02EB
      //## Role: QueryEngine::<m_pRESTFinancialTotalsCommand>%64E4206D0338
      //## begin QueryEngine::<m_pRESTFinancialTotalsCommand>%64E4206D0338.role preserve=no  public: restcommand::FinancialTotalsCommand { -> RFHgN}
      restcommand::FinancialTotalsCommand *m_pRESTFinancialTotalsCommand;
      //## end QueryEngine::<m_pRESTFinancialTotalsCommand>%64E4206D0338.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%65E994480176
      //## Role: QueryEngine::<m_pRESTReconsCommand>%65E9945500FB
      //## begin QueryEngine::<m_pRESTReconsCommand>%65E9945500FB.role preserve=no  public: restcommand::ReconsCommand { -> RFHgN}
      restcommand::ReconsCommand *m_pRESTReconsCommand;
      //## end QueryEngine::<m_pRESTReconsCommand>%65E9945500FB.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%65EA01D000DB
      //## Role: QueryEngine::<m_pRESTConfigurationCommand>%65EA01DA02B9
      //## begin QueryEngine::<m_pRESTConfigurationCommand>%65EA01DA02B9.role preserve=no  public: restcommand::ConfigurationCommand { -> RFHgN}
      restcommand::ConfigurationCommand *m_pRESTConfigurationCommand;
      //## end QueryEngine::<m_pRESTConfigurationCommand>%65EA01DA02B9.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%65EEF9380165
      //## Role: QueryEngine::<m_pRESTReconFilesCommand>%65EEF93F0384
      //## begin QueryEngine::<m_pRESTReconFilesCommand>%65EEF93F0384.role preserve=no  public: restcommand::ReconFilesCommand { -> RFHgN}
      restcommand::ReconFilesCommand *m_pRESTReconFilesCommand;
      //## end QueryEngine::<m_pRESTReconFilesCommand>%65EEF93F0384.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%662DE67C007C
      //## Role: QueryEngine::<m_pFinancialFactUpdateCommand>%662DE67D022A
      //## begin QueryEngine::<m_pFinancialFactUpdateCommand>%662DE67D022A.role preserve=no  public: soapcommand::FinancialFactUpdateCommand { -> RHgN}
      soapcommand::FinancialFactUpdateCommand *m_pFinancialFactUpdateCommand;
      //## end QueryEngine::<m_pFinancialFactUpdateCommand>%662DE67D022A.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%66575C5F01B3
      //## Role: QueryEngine::<m_pRESTEntitiesCommand>%66575C610321
      //## begin QueryEngine::<m_pRESTEntitiesCommand>%66575C610321.role preserve=no  public: restcommand::EntitiesCommand { -> RFHgN}
      restcommand::EntitiesCommand *m_pRESTEntitiesCommand;
      //## end QueryEngine::<m_pRESTEntitiesCommand>%66575C610321.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%66703A7202DA
      //## Role: QueryEngine::<m_pRESTProfilesCommand>%66703A760030
      //## begin QueryEngine::<m_pRESTProfilesCommand>%66703A760030.role preserve=no  public: restcommand::ProfilesCommand { -> RFHgN}
      restcommand::ProfilesCommand *m_pRESTProfilesCommand;
      //## end QueryEngine::<m_pRESTProfilesCommand>%66703A760030.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%66794C510093
      //## Role: QueryEngine::<m_pRESTSaveSettingsCommand>%66794C530007
      //## begin QueryEngine::<m_pRESTSaveSettingsCommand>%66794C530007.role preserve=no  public: restcommand::SaveSettingsCommand { -> RFHgN}
      restcommand::SaveSettingsCommand *m_pRESTSaveSettingsCommand;
      //## end QueryEngine::<m_pRESTSaveSettingsCommand>%66794C530007.role

      //## Association: Transaction Research and Adjustments::QueryEngine_CAT::<unnamed>%6682CEBB03A7
      //## Role: QueryEngine::<m_pRESTSettingsCommand>%6682CEBE0263
      //## begin QueryEngine::<m_pRESTSettingsCommand>%6682CEBE0263.role preserve=no  public: restcommand::SettingsCommand { -> RFHgN}
      restcommand::SettingsCommand *m_pRESTSettingsCommand;
      //## end QueryEngine::<m_pRESTSettingsCommand>%6682CEBE0263.role

    // Additional Implementation Declarations
      //## begin QueryEngine%34567B940016.implementation preserve=yes
      //## end QueryEngine%34567B940016.implementation

};

//## begin QueryEngine%34567B940016.postscript preserve=yes
//## end QueryEngine%34567B940016.postscript

//## begin module%36751AC502D6.epilog preserve=yes
//## end module%36751AC502D6.epilog


#endif
