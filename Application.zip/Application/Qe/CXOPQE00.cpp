//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36751AC7018F.cm preserve=no
//## end module%36751AC7018F.cm

//## begin module%36751AC7018F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36751AC7018F.cp

//## Module: CXOPQE00%36751AC7018F; Package body
//## Subsystem: QE%3597F12A035E
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qe\CXOPQE00.cpp

//## begin module%36751AC7018F.additionalIncludes preserve=no
//## end module%36751AC7018F.additionalIncludes

//## begin module%36751AC7018F.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),ENVAR('TASK=QE'))
#endif
#ifndef CXOSST88_h
#include "CXODST88.hpp"
#endif
//## end module%36751AC7018F.includes

#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBC27_h
#include "CXODBC27.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSTC59_h
#include "CXODTC59.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
#ifndef CXOSRU37_h
#include "CXODRU37.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSDB50_h
#include "CXODDB50.hpp"
#endif
#ifndef CXOSTC66_h
#include "CXODTC66.hpp"
#endif
#ifndef CXOSDB16_h
#include "CXODDB16.hpp"
#endif
#ifndef CXOSUC09_h
#include "CXODUC09.hpp"
#endif
#ifndef CXOSUC08_h
#include "CXODUC08.hpp"
#endif
#ifndef CXOSUC15_h
#include "CXODUC15.hpp"
#endif
#ifndef CXOSUC19_h
#include "CXODUC19.hpp"
#endif
#ifndef CXOSUC20_h
#include "CXODUC20.hpp"
#endif
#ifndef CXOSUA02_h
#include "CXODUA02.hpp"
#endif
#ifndef CXOSUA05_h
#include "CXODUA05.hpp"
#endif
#ifndef CXOSUA04_h
#include "CXODUA04.hpp"
#endif
#ifndef CXOSUA03_h
#include "CXODUA03.hpp"
#endif
#ifndef CXOSUA06_h
#include "CXODUA06.hpp"
#endif
#ifndef CXOSUA09_h
#include "CXODUA09.hpp"
#endif
#ifndef CXOSSX02_h
#include "CXODSX02.hpp"
#endif
#ifndef CXOSTC71_h
#include "CXODTC71.hpp"
#endif
#ifndef CXOSSX25_h
#include "CXODSX25.hpp"
#endif
#ifndef CXOSSX05_h
#include "CXODSX05.hpp"
#endif
#ifndef CXOSSX27_h
#include "CXODSX27.hpp"
#endif
#ifndef CXOSSX48_h
#include "CXODSX48.hpp"
#endif
#ifndef CXOSSX50_h
#include "CXODSX50.hpp"
#endif
#ifndef CXOSSX51_h
#include "CXODSX51.hpp"
#endif
#ifndef CXOSJX01_h
#include "CXODJX01.hpp"
#endif
#ifndef CXOSJX02_h
#include "CXODJX02.hpp"
#endif
#ifndef CXOSJX03_h
#include "CXODJX03.hpp"
#endif
#ifndef CXOSJX04_h
#include "CXODJX04.hpp"
#endif
#ifndef CXOSJX15_h
#include "CXODJX15.hpp"
#endif
#ifndef CXOSJX13_h
#include "CXODJX13.hpp"
#endif
#ifndef CXOSJX16_h
#include "CXODJX16.hpp"
#endif
#ifndef CXOSJX19_h
#include "CXODJX19.hpp"
#endif
#ifndef CXOSJX20_h
#include "CXODJX20.hpp"
#endif
#ifndef CXOSJX21_h
#include "CXODJX21.hpp"
#endif
#ifndef CXOSJX23_h
#include "CXODJX23.hpp"
#endif
#ifndef CXOSEX16_h
#include "CXODEX16.hpp"
#endif
#ifndef CXOPQE00_h
#include "CXODQE00.hpp"
#endif


//## begin module%36751AC7018F.declarations preserve=no
//## end module%36751AC7018F.declarations

//## begin module%36751AC7018F.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new QueryEngine();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%36751AC7018F.additionalDeclarations


// Class QueryEngine 

QueryEngine::QueryEngine()
  //## begin QueryEngine::QueryEngine%34567B940016_const.hasinit preserve=no
      : m_pCallback(0),
        m_pGetFinancialCommand(0),
        m_pFinancialAdvancedListCommand(0),
        m_pFinancialBasicListCommand(0),
        m_pGetPreauthTranCommand(0),
        m_pTransactionHighlightCommand(0),
        m_pFinancialWebListCommand(0),
        m_pReconExtDetailsCommand(0),
        m_pReconDateListCommand(0),
        m_pReconFileListCommand(0),
        m_pReconTransitionCommand(0),
        m_pReconTotalListCommand(0),
        m_pReconDetailsCommand(0),
        m_pReconUpdateCommand(0),
        m_pReconAuditCommand(0),
        m_pSOAPTransactionListCommand(0),
        m_pSOAPFinancialTotalsCommand(0),
        m_pExternalAdjustmentListCommand(0),
        m_pATMReceiptListCommand(0),
        m_pATMElectronicJournalCommand(0),
        m_pPanTokenCommand(0),
        m_pTokenListCommand(0),
        m_pTokenUpdateCommand(0),
        m_pServersCommand(0),
        m_pServicesCommand(0),
        m_pRESTTransactionListCommand(0),
        m_pRESTFinancialTotalsCommand(0),
        m_pRESTReconsCommand(0),
        m_pRESTConfigurationCommand(0),
        m_pRESTReconFilesCommand(0),
        m_pFinancialFactUpdateCommand(0),
        m_pRESTEntitiesCommand(0),
        m_pRESTProfilesCommand(0),
        m_pRESTSaveSettingsCommand(0),
        m_pRESTSettingsCommand(0)
  //## end QueryEngine::QueryEngine%34567B940016_const.hasinit
  //## begin QueryEngine::QueryEngine%34567B940016_const.initialization preserve=yes
  //## end QueryEngine::QueryEngine%34567B940016_const.initialization
{
  //## begin QueryEngine::QueryEngine%34567B940016_const.body preserve=yes
   memcpy(m_sID,"QE00",4);
  //## end QueryEngine::QueryEngine%34567B940016_const.body
}


QueryEngine::~QueryEngine()
{
  //## begin QueryEngine::~QueryEngine%34567B940016_dest.body preserve=yes
   delete m_pRESTSettingsCommand;
   delete m_pRESTSaveSettingsCommand;
   delete m_pRESTProfilesCommand;
   delete m_pRESTEntitiesCommand;
   delete m_pRESTReconFilesCommand;
   delete m_pRESTConfigurationCommand;
   delete m_pRESTReconsCommand;
   delete m_pExternalAdjustmentListCommand;
   delete m_pSOAPFinancialTotalsCommand;
   delete m_pSOAPTransactionListCommand;
   delete m_pRESTFinancialTotalsCommand;
   delete m_pRESTTransactionListCommand;
   delete m_pServersCommand;
   delete m_pServicesCommand;
   delete m_pGetFinancialCommand;
   delete m_pFinancialBasicListCommand;
   delete m_pFinancialAdvancedListCommand;
   delete m_pGetPreauthTranCommand;
   delete m_pTransactionHighlightCommand;
   delete m_pFinancialWebListCommand;
   delete m_pReconDetailsCommand;
   delete m_pReconExtDetailsCommand;
   delete m_pReconFileListCommand;
   delete m_pReconTotalListCommand;
   delete m_pReconDateListCommand;
   delete m_pReconUpdateCommand;
   delete m_pReconTransitionCommand;
   delete m_pReconAuditCommand;
   delete m_pATMElectronicJournalCommand;
   delete m_pATMReceiptListCommand;
   delete m_pPanTokenCommand;
   delete m_pTokenListCommand;
   delete m_pTokenUpdateCommand;
   delete m_pFinancialFactUpdateCommand;
  //## end QueryEngine::~QueryEngine%34567B940016_dest.body
}



//## Other Operations (implementation)
int QueryEngine::initialize ()
{
  //## begin QueryEngine::initialize%36751B5F024C.body preserve=yes
   new dnplatform::DNPlatform();
   new segment::AuditEvent;
   int i = ServiceApplication::initialize();
   UseCase hUseCase("CLIENT","## CL11 START QE");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->attach(this);
   database::DataModel::instance();
   database::CRTransactionTypeIndicator::instance();
   entitysegment::Customer::instance();
   totalscommand::Total::instance();
#ifndef MVS
   Database::instance()->attach(new DNSecurity());
#endif
   Database::instance()->connect();
   TotalsVersionMonitor::instance();
   EMSNetRuleUseTable::instance();
   FinancialBaseSegment::instance();
   if (entitysegment::Customer::instance()->getTotalsVersion() == 2)
      new totalscommand::FinancialSum;
   m_pServersCommand = new restcommand::ServersCommand((Handler*)0);
   m_pServicesCommand = new restcommand::ServicesCommand(m_pServersCommand);
   m_pGetPreauthTranCommand = new GetPreauthTranCommand(m_pServicesCommand);
   m_pTransactionHighlightCommand = new TransactionHighlightCommand(m_pGetPreauthTranCommand);
   m_pFinancialWebListCommand = new FinancialWebListCommand(m_pTransactionHighlightCommand);
   m_pReconDetailsCommand = new reconciliationuserinterface::ReconDetailsCommand(m_pFinancialWebListCommand);
   m_pReconExtDetailsCommand = new reconciliationuserinterface::ReconExtDetailsCommand(m_pReconDetailsCommand);
   m_pReconFileListCommand = new reconciliationuserinterface::ReconFileListCommand(m_pReconExtDetailsCommand);
   m_pReconTotalListCommand = new reconciliationuserinterface::ReconTotalListCommand(m_pReconFileListCommand);
   m_pReconDateListCommand = new reconciliationuserinterface::ReconDateListCommand(m_pReconTotalListCommand);
   m_pReconUpdateCommand = new reconciliationuserinterface::ReconUpdateCommand(m_pReconDateListCommand);
   m_pReconTransitionCommand = new reconciliationuserinterface::ReconTransitionCommand(m_pReconUpdateCommand);
   m_pReconAuditCommand = new reconciliationuserinterface::ReconAuditCommand(m_pReconTransitionCommand);
   m_pSOAPFinancialTotalsCommand = new totalscommand::FinancialTotalsCommand(m_pReconAuditCommand);
   m_pFinancialBasicListCommand = new FinancialBasicListCommand(m_pSOAPFinancialTotalsCommand);
   m_pFinancialAdvancedListCommand = new FinancialAdvancedListCommand(m_pFinancialBasicListCommand);
   m_pGetFinancialCommand = new GetFinancialCommand(m_pFinancialAdvancedListCommand);
   m_pExternalAdjustmentListCommand = new soapcommand::ExternalAdjustmentListCommand(m_pGetFinancialCommand);
   m_pSOAPTransactionListCommand = new soapcommand::TransactionListCommand(m_pExternalAdjustmentListCommand);
   m_pATMElectronicJournalCommand = new soapcommand::ATMElectronicJournalCommand(m_pSOAPTransactionListCommand);
   m_pATMReceiptListCommand = new soapcommand::ATMReceiptListCommand(m_pATMElectronicJournalCommand);
   m_pPanTokenCommand = new soapcommand::PanTokenCommand(m_pATMReceiptListCommand);
   m_pTokenListCommand = new soapcommand::TokenListCommand(m_pPanTokenCommand);
   m_pTokenUpdateCommand = new soapcommand::TokenUpdateCommand(m_pTokenListCommand);
   m_pFinancialFactUpdateCommand = new soapcommand::FinancialFactUpdateCommand(m_pTokenUpdateCommand);
   m_pRESTFinancialTotalsCommand = new restcommand::FinancialTotalsCommand(m_pFinancialFactUpdateCommand);
   m_pRESTTransactionListCommand = new restcommand::TransactionListCommand(m_pRESTFinancialTotalsCommand );
   m_pRESTConfigurationCommand = new restcommand::ConfigurationCommand(m_pRESTTransactionListCommand);
   m_pRESTReconsCommand = new restcommand::ReconsCommand(m_pRESTConfigurationCommand);
   m_pRESTReconFilesCommand = new restcommand::ReconFilesCommand(m_pRESTReconsCommand);
   m_pRESTEntitiesCommand = new restcommand::EntitiesCommand(m_pRESTReconFilesCommand);
   m_pRESTProfilesCommand = new restcommand::ProfilesCommand(m_pRESTEntitiesCommand);
   m_pRESTSaveSettingsCommand = new restcommand::SaveSettingsCommand(m_pRESTProfilesCommand);
   m_pRESTSettingsCommand = new restcommand::SettingsCommand(m_pRESTSaveSettingsCommand);
   string strBuffer;
   Queue::attach("@##SERVER",Queue::CX_DISTRIBUTION_QUEUE);
   Queue::attach("##",Queue::CX_SELECTION_QUEUE);  //needed for dialog manager
   ServiceApplication::idle();
   return 0;
  //## end QueryEngine::initialize%36751B5F024C.body
}

int QueryEngine::onMessage (Message& hMessage)
{
  //## begin QueryEngine::onMessage%36751B6200A1.body preserve=yes
   if (hMessage.messageID() == "S0003D" || hMessage.messageID() == "S0004D")
   {
      if (m_pCallback)
      {
         Trace::put("QE is still busy with previous request", hMessage.getSource(), true);
         m_pCallback->abort();
         m_pCallback = 0;
      }
      Transaction::instance()->begin();
      m_strSource = Message::instance(Message::INBOUND)->getSource();
      m_pRESTSettingsCommand->update(Message::instance(Message::INBOUND));
      if (m_pCallback)
         return 0;
      Transaction::instance()->commit();
      Database::instance()->commit();
   }
   else
   if (hMessage.messageID() == "S0009D")
   {
      if (m_pCallback)
      {
         m_pCallback->abort();
         m_pCallback = 0;
         onResume(hMessage);
         setQueueWaitOption(true);
         return 0;
      }
   }
   else
   if (hMessage.messageID() == IString("H5050D"))
   {
      m_hDynamicSQLCommand.execute();
      Database::instance()->commit();
      return 0;
   }
   if (m_pCallback == 0 
      && m_strSource.length() > 3
      && m_strSource.substr(2,2) == "CI")
      idle();
   return 0;
  //## end QueryEngine::onMessage%36751B6200A1.body
}

int QueryEngine::onResume (Message& hMessage)
{
  //## begin QueryEngine::onResume%3A79C495012C.body preserve=yes
   if (m_pCallback)
      m_pCallback->onResume();
   if (m_pCallback == 0)
   {
      Transaction::instance()->commit();
      Database::instance()->commit();
      if (m_strSource.length() > 3
         && m_strSource.substr(2,2) == "CI")
      {
         Message::instance(Message::OUTBOUND)->reset("SRVCLI", "S0009R", false);
         char* p = Message::instance(Message::OUTBOUND)->data();
         memset(p, ' ', 8);
         Message::instance(Message::OUTBOUND)->setDataLength(8);
         Message::instance(Message::OUTBOUND)->send("##CI01");
      }
   }
   return 0;
  //## end QueryEngine::onResume%3A79C495012C.body
}

void QueryEngine::setCallback (Object* pCallback)
{
  //## begin QueryEngine::setCallback%3A79CCC301C3.body preserve=yes
   m_pCallback = (ClientCommand*)pCallback;
  //## end QueryEngine::setCallback%3A79CCC301C3.body
}

void QueryEngine::update (Subject* pSubject)
{
  //## begin QueryEngine::update%36751B6A01E3.body preserve=yes
  ServiceApplication::update(pSubject);
  //## end QueryEngine::update%36751B6A01E3.body
}

// Additional Declarations
  //## begin QueryEngine%34567B940016.declarations preserve=yes
  //## end QueryEngine%34567B940016.declarations

//## begin module%36751AC7018F.epilog preserve=yes
//## end module%36751AC7018F.epilog
