//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%61FC8F410177.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%61FC8F410177.cm

//## begin module%61FC8F410177.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%61FC8F410177.cp

//## Module: CXOSCL01%61FC8F410177; Package body
//## Subsystem: CL%61FC8E2700C9
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Cl\CXOSCL01.cpp

//## begin module%61FC8F410177.additionalIncludes preserve=no
//## end module%61FC8F410177.additionalIncludes

//## begin module%61FC8F410177.includes preserve=yes
#include <vector>
#include <map>
#include <sstream>
#include "CXODTM03.hpp"
#include "CXODTM06.hpp"
#include "CXODRU62.hpp"
//## end module%61FC8F410177.includes

#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSCL01_h
#include "CXODCL01.hpp"
#endif


//## begin module%61FC8F410177.declarations preserve=no
//## end module%61FC8F410177.declarations

//## begin module%61FC8F410177.additionalDeclarations preserve=yes
//## end module%61FC8F410177.additionalDeclarations


// Class TestCases 

TestCases::TestCases()
  //## begin TestCases::TestCases%61FC826E0153_const.hasinit preserve=no
  //## end TestCases::TestCases%61FC826E0153_const.hasinit
  //## begin TestCases::TestCases%61FC826E0153_const.initialization preserve=yes
  //## end TestCases::TestCases%61FC826E0153_const.initialization
{
  //## begin TestCases::TestCases%61FC826E0153_const.body preserve=yes
  //## end TestCases::TestCases%61FC826E0153_const.body
}

TestCases::TestCases (const reusable::string& strIMAGEID, const reusable::string& strTASKID, const char* pszName, bool bVariableBlockFile)
  //## begin TestCases::TestCases%61FC8C49012E.hasinit preserve=no
  //## end TestCases::TestCases%61FC8C49012E.hasinit
  //## begin TestCases::TestCases%61FC8C49012E.initialization preserve=yes
   :GenerationDataGroup(strIMAGEID,strTASKID,pszName)
  //## end TestCases::TestCases%61FC8C49012E.initialization
{
  //## begin TestCases::TestCases%61FC8C49012E.body preserve=yes
   MinuteTimer::instance()->attach(this);
  //## end TestCases::TestCases%61FC8C49012E.body
}


TestCases::~TestCases()
{
  //## begin TestCases::~TestCases%61FC826E0153_dest.body preserve=yes
   MinuteTimer::instance()->detach(this);
  //## end TestCases::~TestCases%61FC826E0153_dest.body
}



//## Other Operations (implementation)
void TestCases::generateOCS ()
{
  //## begin TestCases::generateOCS%61FC85F20040.body preserve=yes
   if (!open())
   {
      Database::instance()->commit();
      return;
   }
   UseCase hUseCase("LOG","## CL01 START FILE");
   FlatFile hFlatFile("OCS");
   if (!hFlatFile.open(FlatFile::CX_OPEN_OUTPUT))
      return;
   entitysegment::SwitchBusinessDay::instance()->update(MidnightAlarm::instance());
   hFlatFile.write("FH",2);
   hFlatFile.write("BH",2);
   srand(time(0));
   char szBuffer[16384];
   size_t iRecordLength = 0;
   vector<string> hKey;
   map<string,string,less<string> > hRecord;
   map<string, string, less<string> >::iterator itr;
   char szToken1[PERCENTLD + 1];
   int iTranCount = 0;
   string stryyyymmddhhmmssnn;
   while (read(szBuffer,16384,&iRecordLength))
   {
      string strBuffer(szBuffer,iRecordLength);
      vector<string> hTokens;
      Buffer::parse(strBuffer,", ",hTokens);
      if (hTokens[0] == "*")
         continue;
      if (hTokens[0] == "K")
      {
         string strKey;
         hKey = hTokens;
         for (int i = 1; i<hKey.size(); i++)
         {
            replace(hKey[i].begin(),hKey[i].end(),'_',' ');
            strKey.assign(hKey[i].c_str(),3);
            if (hRecord.find(strKey) == hRecord.end())
               hRecord[strKey];
         }
         if (hRecord.find("M  ") == hRecord.end())
         {
            hFlatFile.write("Invalid Input File : Missing M Record",37);
            commit();
            Database::instance()->commit();
            return;
         }
         continue;
      }
      iTranCount = atoi(hTokens[0].c_str());
      int iPrefix = 400000;
      int iSuffix = 0;
      for (int i = 0;i < iTranCount; i++)
      {
         snprintf(szToken1,sizeof(szToken1),"000001012%012d",rand());
         for (itr = hRecord.begin();itr != hRecord.end(); ++itr)
         {
            (*itr).second.assign((*itr).first);
            (*itr).second.append(szToken1,strlen(szToken1));
         }
         for (int j = 1;j < hTokens.size();++j)
         {
            itr = hRecord.find(hKey[j].substr(0,3));
            if (itr == hRecord.end()
               || hKey[j].length() != 9)
               continue;
            if (hTokens[j] == "N/A")
               continue;
            (*itr).second.append(hKey[j].c_str() + 3);
            if (hTokens[j][0] == '#')
            {
               int iDigit = atoi(hTokens[j].c_str() + 1);
               size_t iMod = 1;
               for (int k = 0;k < iDigit;++k,iMod *= 10);
               std::ostringstream oss;
               oss << setfill('0') << setw(3) << hTokens[j].c_str() + 1 << setfill('0') << setw(iDigit) << rand() % iMod;
               (*itr).second.append(oss.str().data(),oss.str().length());
            }
            else
            if (hTokens[j] == "pan")
            {
               (*itr).second.append("016",3);
               {
               std::ostringstream oss;
               oss << setfill('0') << setw(6) << iPrefix++;
               (*itr).second.append(oss.str().data(),oss.str().length());
               }
               if (iPrefix > 599999)
                  iSuffix = 0;
               (*itr).second.append("999999",6);
               {
               std::ostringstream oss;
               oss << setfill('0') << setw(4) << iSuffix++;
               (*itr).second.append(oss.str().data(),oss.str().length());
               }
               if (iSuffix > 9999)
                  iSuffix = 0;
            }
            else
            if (hTokens[j] == "uuid")
            {
               string strUUID;
               reusable::UUID::get(strUUID);
               strUUID.resize(23,' ');
               (*itr).second.append("023",3);
               (*itr).second += strUUID;
            }
            else
            if (hTokens[j] == "yyddd")
            {
               (*itr).second.append("005",3);
               Date hDate(entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(1).c_str());
               (*itr).second += hDate.asString("%y%j");
            }
            else
            if (hTokens[j] == "yyyymmdd")
            {
               (*itr).second.append("008",3);
               (*itr).second += entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(1);
            }
            else
            if (hTokens[j].find("yyyymmddhhmmss",0,14) != string::npos)
            {
               stryyyymmddhhmmssnn.assign(entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(1));
               stryyyymmddhhmmssnn.append(Clock::instance()->getYYYYMMDDHHMMSSHN(true).c_str() + 8,hTokens[j].length() == 16 ? 8 : 6);
               (*itr).second.append(szToken1,snprintf(szToken1,sizeof(szToken1),"%03d%s",stryyyymmddhhmmssnn.length(),stryyyymmddhhmmssnn.c_str()));
            }
            else
            {
               (*itr).second.append(szToken1,snprintf(szToken1,sizeof(szToken1),"%03d",hTokens[j].length()));
               (*itr).second.append(hTokens[j]);
            }
         }
         hFlatFile.write((char*)hRecord["M  "].c_str(),hRecord["M  "].length());
         for (itr = hRecord.begin();itr != hRecord.end();++itr)
            if ((*itr).first != "M  ")
               hFlatFile.write((char*)(*itr).second.c_str(),(*itr).second.length());
      }
   }
   hFlatFile.write("BT",2);
   hFlatFile.write("FT",2);
   commit();
   Database::instance()->commit();
  //## end TestCases::generateOCS%61FC85F20040.body
}

void TestCases::update (Subject* pSubject)
{
  //## begin TestCases::update%61FC82A603A0.body preserve=yes
   generateOCS();
  //## end TestCases::update%61FC82A603A0.body
}

// Additional Declarations
  //## begin TestCases%61FC826E0153.declarations preserve=yes
  //## end TestCases%61FC826E0153.declarations

//## begin module%61FC8F410177.epilog preserve=yes
//## end module%61FC8F410177.epilog
