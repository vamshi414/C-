//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%61FC8F3E012C.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%61FC8F3E012C.cm

//## begin module%61FC8F3E012C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%61FC8F3E012C.cp

//## Module: CXOSCL01%61FC8F3E012C; Package specification
//## Subsystem: CL%61FC8E2700C9
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Cl\CXODCL01.hpp

#ifndef CXOSCL01_h
#define CXOSCL01_h 1

//## begin module%61FC8F3E012C.additionalIncludes preserve=no
//## end module%61FC8F3E012C.additionalIncludes

//## begin module%61FC8F3E012C.includes preserve=yes
//## end module%61FC8F3E012C.includes

#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%61FC8F3E012C.declarations preserve=no
//## end module%61FC8F3E012C.declarations

//## begin module%61FC8F3E012C.additionalDeclarations preserve=yes
//## end module%61FC8F3E012C.additionalDeclarations


//## begin TestCases%61FC826E0153.preface preserve=yes
//## end TestCases%61FC826E0153.preface

//## Class: TestCases%61FC826E0153
//## Category: Platform \: FIS IST::Clearing_CAT%61FC80C20197
//## Subsystem: CL%61FC8E2700C9
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%61FC85A40103;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%61FC85C9028A;IF::FlatFile { -> F}
//## Uses: <unnamed>%61FC86570283;monitor::UseCase { -> F}
//## Uses: <unnamed>%61FC867C00FA;reusable::Buffer { -> F}
//## Uses: <unnamed>%61FC86A80162;timer::Clock { -> F}
//## Uses: <unnamed>%61FC8712037A;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%61FCAB460069;database::Database { -> F}

class DllExport TestCases : public database::GenerationDataGroup  //## Inherits: <unnamed>%61FC84C10042
{
  //## begin TestCases%61FC826E0153.initialDeclarations preserve=yes
  //## end TestCases%61FC826E0153.initialDeclarations

  public:
    //## Constructors (generated)
      TestCases();

    //## Constructors (specified)
      //## Operation: TestCases%61FC8C49012E
      TestCases (const reusable::string& strIMAGEID, const reusable::string& strTASKID, const char* pszName, bool bVariableBlockFile);

    //## Destructor (generated)
      virtual ~TestCases();


    //## Other Operations (specified)
      //## Operation: generateOCS%61FC85F20040
      void generateOCS ();

      //## Operation: update%61FC82A603A0
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin TestCases%61FC826E0153.public preserve=yes
      //## end TestCases%61FC826E0153.public

  protected:
    // Additional Protected Declarations
      //## begin TestCases%61FC826E0153.protected preserve=yes
      //## end TestCases%61FC826E0153.protected

  private:
    // Additional Private Declarations
      //## begin TestCases%61FC826E0153.private preserve=yes
      //## end TestCases%61FC826E0153.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin TestCases%61FC826E0153.implementation preserve=yes
      //## end TestCases%61FC826E0153.implementation

};

//## begin TestCases%61FC826E0153.postscript preserve=yes
//## end TestCases%61FC826E0153.postscript

//## begin module%61FC8F3E012C.epilog preserve=yes
//## end module%61FC8F3E012C.epilog


#endif
