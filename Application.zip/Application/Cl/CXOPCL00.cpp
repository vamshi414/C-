//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%61FC8E7402B7.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%61FC8E7402B7.cm

//## begin module%61FC8E7402B7.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%61FC8E7402B7.cp

//## Module: CXOPCL00%61FC8E7402B7; Package body
//## Subsystem: CL%61FC8E2700C9
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Cl\CXOPCL00.cpp

//## begin module%61FC8E7402B7.additionalIncludes preserve=no
//## end module%61FC8E7402B7.additionalIncludes

//## begin module%61FC8E7402B7.includes preserve=yes
//## end module%61FC8E7402B7.includes

#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSCL01_h
#include "CXODCL01.hpp"
#endif
#ifndef CXOPCL00_h
#include "CXODCL00.hpp"
#endif


//## begin module%61FC8E7402B7.declarations preserve=no
//## end module%61FC8E7402B7.declarations

//## begin module%61FC8E7402B7.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new Clearing();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%61FC8E7402B7.additionalDeclarations


// Class Clearing 

Clearing::Clearing()
  //## begin Clearing::Clearing%61FC81360074_const.hasinit preserve=no
      : m_pTestCases(0)
  //## end Clearing::Clearing%61FC81360074_const.hasinit
  //## begin Clearing::Clearing%61FC81360074_const.initialization preserve=yes
  //## end Clearing::Clearing%61FC81360074_const.initialization
{
  //## begin Clearing::Clearing%61FC81360074_const.body preserve=yes
   memcpy(m_sID,"CL00",4);
  //## end Clearing::Clearing%61FC81360074_const.body
}


Clearing::~Clearing()
{
  //## begin Clearing::~Clearing%61FC81360074_dest.body preserve=yes
   delete m_pTestCases;
  //## end Clearing::~Clearing%61FC81360074_dest.body
}



//## Other Operations (implementation)
int Clearing::initialize ()
{
  //## begin Clearing::initialize%61FC81E50209.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("LOG","## CL00 START CL");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   entitysegment::SwitchBusinessDay::instance();
   Database::instance()->connect();
   m_pTestCases = new TestCases(Application::instance()->image(),Application::instance()->name(),"TESTCASE",false);
   return 0;
  //## end Clearing::initialize%61FC81E50209.body
}

// Additional Declarations
  //## begin Clearing%61FC81360074.declarations preserve=yes
  //## end Clearing%61FC81360074.declarations

//## begin module%61FC8E7402B7.epilog preserve=yes
//## end module%61FC8E7402B7.epilog
