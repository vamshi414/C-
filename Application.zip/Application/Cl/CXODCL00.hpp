//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%61FC8E72010A.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%61FC8E72010A.cm

//## begin module%61FC8E72010A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%61FC8E72010A.cp

//## Module: CXOPCL00%61FC8E72010A; Package specification
//## Subsystem: CL%61FC8E2700C9
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Cl\CXODCL00.hpp

#ifndef CXOPCL00_h
#define CXOPCL00_h 1

//## begin module%61FC8E72010A.additionalIncludes preserve=no
//## end module%61FC8E72010A.additionalIncludes

//## begin module%61FC8E72010A.includes preserve=yes
//## end module%61FC8E72010A.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

class TestCases;

//## begin module%61FC8E72010A.declarations preserve=no
//## end module%61FC8E72010A.declarations

//## begin module%61FC8E72010A.additionalDeclarations preserve=yes
//## end module%61FC8E72010A.additionalDeclarations


//## begin Clearing%61FC81360074.preface preserve=yes
//## end Clearing%61FC81360074.preface

//## Class: Clearing%61FC81360074
//## Category: Platform \: FIS IST::Clearing_CAT%61FC80C20197
//## Subsystem: CL%61FC8E2700C9
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%61FC87B10112;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%61FC87C7037A;monitor::UseCase { -> F}
//## Uses: <unnamed>%61FC87E502EA;database::Database { -> F}
//## Uses: <unnamed>%61FCA81F0279;entitysegment::SwitchBusinessDay { -> F}

class DllExport Clearing : public process::Application  //## Inherits: <unnamed>%61FC8169001C
{
  //## begin Clearing%61FC81360074.initialDeclarations preserve=yes
  //## end Clearing%61FC81360074.initialDeclarations

  public:
    //## Constructors (generated)
      Clearing();

    //## Destructor (generated)
      virtual ~Clearing();


    //## Other Operations (specified)
      //## Operation: initialize%61FC81E50209
      virtual int initialize ();

    // Additional Public Declarations
      //## begin Clearing%61FC81360074.public preserve=yes
      //## end Clearing%61FC81360074.public

  protected:
    // Additional Protected Declarations
      //## begin Clearing%61FC81360074.protected preserve=yes
      //## end Clearing%61FC81360074.protected

  private:
    // Additional Private Declarations
      //## begin Clearing%61FC81360074.private preserve=yes
      //## end Clearing%61FC81360074.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: FIS IST::Clearing_CAT::<unnamed>%61FC889C01BD
      //## Role: Clearing::<m_pTestCases>%61FC889D010A
      //## begin Clearing::<m_pTestCases>%61FC889D010A.role preserve=no  public: TestCases { -> RFHgN}
      TestCases *m_pTestCases;
      //## end Clearing::<m_pTestCases>%61FC889D010A.role

    // Additional Implementation Declarations
      //## begin Clearing%61FC81360074.implementation preserve=yes
      //## end Clearing%61FC81360074.implementation

};

//## begin Clearing%61FC81360074.postscript preserve=yes
//## end Clearing%61FC81360074.postscript

//## begin module%61FC8E72010A.epilog preserve=yes
//## end module%61FC8E72010A.epilog


#endif
