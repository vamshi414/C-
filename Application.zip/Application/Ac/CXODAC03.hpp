#ifndef CXODAC03_HPP
#define CXODAC03_HPP

#include "CXODRU32.hpp"
// Standard Card Unload File Header
struct hCEDUnLoadHeader
{
   char sSeqNbr[6];
   char sTitle[16];
   char sReserved1[1];
   char sUnloadDate[6];
   char sSwitchId[6];
   char sDestProcId[6];
   char sReserved2[39];
};

// Standard Card Unload File Detail
struct hCEDUnLoadDetail
{
   char sSeqNbr[6];
   char sPrfxlen[2];
   char sPrfx[19];
   char sMinPanlen[2];
   char sMaxPanlen[2];
   char sPrfxOffset[2];
   char sCbgrp[3];
   char sRptInstName[30];
   char sRptInstId[9];
   char sRptInstRegion[3];
   char sPlatform[1];
   char sIssuerRoutingOption[1];
};

// Standard Card Unload File Trailer
struct hCEDUnLoadTrailer
{
   char sSeqNbr[6];
   char sUnloadDate[6];
   char sNbrRecords[8];
   char sHashValue[12];
   char sReserved[48];
};
#include "CXODRU33.hpp"

#endif
