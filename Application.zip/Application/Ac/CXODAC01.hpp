//  Copyright (c) 1998 - 2004
//  eFunds Corporation
// $Date:   Dec 28 2020 01:25:26  $ $Author:   E5350313  $ $Revision:   1.19  $

#ifndef CXODAC01_HPP
#define CXODAC01_HPP

#include "CXODRU32.hpp"
struct hCED
{
   char sType[7];                      // 0000
   char sVersion[4];                   // 0007
};

struct hCEDINST
{
// char sType[11];                     // 0000
   char sINST_ID[11];                  // 0011
   char cInstAlwaysBlank;              // 0022
   short siStatus;                     // 0023
   char sNAME[35];                     // 0025
   char sInstAddr1[35];                // 0060
   char sInstAddr2[35];                // 0095
   char sInstAddr3[35];                // 0130
   char sInstAddr4[35];                // 0165
   char sInstCardAcptName[25];         // 0200
   char sInstCountryCode[3];           // 0225
   char cInstFiller1;                  // 0228
   short siInstIDMapOpt;               // 0229
   char sInstAtsAplList[5];            // 0231
   char sAcquirerPROC_ID[6];           // 0236
   char sSettlePROC_ID[6];             // 0242
   char sInstContactList[8];           // 0248
   char sInstRjeID[8];                 // 0256
   char sInstSetlCurCode[3];           // 0264
   char sSETL_INST_ID[11];             // 0267
   char sSETL_ACCT_NO[28];             // 0278
   char sSERVICE_LINE[2];              // 0306
   char sADJUST_INST_ID[11];           // 0308
   char sADJUST_ACCT_ID[28];           // 0319
   char sONLINE_FEE_INST_ID[11];       // 0347
   char sONLINE_FEE_ACCT_ID[28];       // 0358
   char sFEE_BILL_INST_ID[11];         // 0386
   char sFEE_BILL_ACCT_ID[28];         // 0397
   char sBILL_INTERCHG_GRP[2];         // 0425
   char sFUNDS_MOVEMENT_OPT[2];        // 0427
   char sInstUniqueData[20];           // 0429
   char sInstCustomData[5];            // 0449
   char sInstConnexData[17];           // 0454
   char sSETL_ACCT_TYPE[2];            // 0471
   char sADJUST_ACCT_TYPE[2];          // 0473
   char sONLN_FEE_ACCT_TYPE[2];        // 0475
   char sFEE_BILL_ACCT_TYPE[2];        // 0477
   char sFiller1[8];                   // 0479
   char sCUTOFF_TIME[6];               // 0487
   char sFiller2[2];                   // 0493
   char sBANK_ID[4];                   // 0495
   char sFiller3[5];                   // 0499
   char sAIMS_FI_BILLING_ID[10];       // 0504
   char sFiller[405];                  // 0514
   char sDELETE_STATUS[2];             // 0919
};

struct hCEDINTR
{
// char sType[11];                     // 0000
   char sDEVICE_ID[6];                 // 0011
   short siStatus;                     // 0017
   char sIntrCardAcptID[15];           // 0019
   char sADDRESS[28];                  // 0034
   char sCITY[27];                     // 0062
   char sREGION[3];                    // 0089
   char sCOUNTRY[3];                   // 0092
   char sCOUNTY[3];                    // 0095
   char cIntrFiller1;                  // 0098
   char sPOSTAL_CODE[10];              // 0099
   char sIntrCardAcptNameID[10];       // 0109
   char sINST_ID[11];                  // 0119
   char sDEFAULT_CUR_CODE[3];          // 0130
   char sIntrAtsAplList[8];            // 0133
   char sIntrRestrictGrp[8];           // 0141
   short siIntrServiceFeeGrp;          // 0149
   char sIntrOutbndTermGrp[8];         // 0151
   char sBILL_INTERCHG_GRP[2];         // 0159
   char sRPT_LVL_ID[10];               // 0161
   char sIntrMerchantType[4];          // 0171
   char sIntrBusinessCode[4];          // 0175
   char sIntrFloorLimit[8];            // 0179
   char sIntrCountryCode[3];           // 0187
   char sIntrAcqInstID[11];            // 0190
   short siIntrAcqBranch;              // 0201
   short siACPT_TERM_SORT_FLG;         // 0203
   char sIntrCardLogoList[8];          // 0205
   char sIntrDfltCardLogoID[8];        // 0213
   char sIntrContractList[8];          // 0221
   char sIntrDfltCbaseList[8];         // 0229
   char sIntrSourceRouteID[8];         // 0237
   char sIntrDirectRouteList[8];       // 0245
   short siIntrDirectRouteOpt;         // 0253
   short siIntrDestRouteOpt;           // 0255
   char sIntrAcqNetworkID[3];          // 0257
   char cIntrCardDataInputCap;         // 0260
   char cIntrCardholderAuthCap;        // 0261
   char cIntrCardRetentCap;            // 0262
   char cIntrOperatingEnv;             // 0263
   char cIntrCardholderPresent;        // 0264
   char cIntrCardPresent;              // 0265
   char cIntrDataOutputCap;            // 0266
   char cIntrOutputCap;                // 0267
   char cIntrPinCaptureCap;            // 0268
   char sIntrTermClass[2];             // 0269
   short siIntrResponseTimer;          // 0271
   short siIntrResponseAckTimer;       // 0273
   short siCUTOFF_IND;                 // 0275
   char sCUTOFF_TIME[6];               // 0277
   char sCUTOFF_START_TIME[6];         // 0283
   char sIntrAdvEndTimeHH[2];          // 0289
   char sIntrAdvEndTimeMM[2];          // 0291
   char sIntrAdvEndTimeSS[2];          // 0293
   char cIntrLifeCycleInd;             // 0295
   char sIntrLifeCycle[2];             // 0296
   char sIntrOnlineFeeGrp[8];          // 0298
   char cIntrFiller2;                  // 0306
   char sIntrConnexData[25];           // 0307
   char sIntrCustomData[25];           // 0332
   short siIntrConnexOpt1;             // 0357
   short siIntrConnexOpt2;             // 0359
   short siIntrConnexOpt3;             // 0361
   short siIntrConnexOpt4;             // 0363
   short siIntrConnexOpt5;             // 0365
   short siIntrCustomOpt1;             // 0367
   short siIntrCustomOpt2;             // 0369
   short siIntrCustomOpt3;             // 0371
   short siIntrCustomOpt4;             // 0373
   short siIntrCustomOpt5;             // 0375
   char sIntrCommon[118];              // 0377
};

struct hCEDPRNT
{
// char sType[11];                     // 0000
   char sPAN_MASK_ID[8];               // 0011
   short siStatus;                     // 0019
   char sPAN_MASK[28];                 // 0021
   char sPrntCommon[118];              // 0049
};

struct hCEDDMAP
{
// char sType[11];                     // 0000
   char sPROCESS_NAME[6];              // xxxx
   char sINPUT_DATA_TYPE[2];           // xxxx
   char sINPUT_DATA[20];               // xxxx
   char sOUTPUT_DATA_TYPE[2];          // xxxx
   short siStatus;                     // 0019
   char sOUTPUT_DATA_TYPE2[2];         // 0049
   char sOUTPUT_DATA[20];              // 0051
   char sFillerA[284];                 // 0011
   char sFillerB[56];                  // 0011
   char sFiller1[118];                 // 0011
   // COMMON-START                  NATIVE-2.                                  
   // DELETE-STATUS                 PIC XX.                                    
   // CHANGE-NUMBER                 PIC X(8).                                  
   // PREVIOUS-CHANGE               PIC X(8).                                  
   // UPDATING-PROGRAM              NATIVE-2.                                  
   // ADDED-TSTAMP.                 PIC x(6) HP timestamp
   // ADDED-USER                    NATIVE-2
   // UPDATED-TSTAMP                PIC x(6) HP timestamp
   // UPDATED-USER                  NATIVE-2
   // DELETED-TSTAMP                PIC x(6) HP timestamp
   // DELETED-USER                  NATIVE-2
   // ROLLED-TSTAMP                 PIC x(6) HP timestamp
   // ROLLED-USER                   NATIVE-2
   // CLIENT-ID                     PIC X(4).                                  
   // USER-NOTE                     PIC X(60).                    
};

struct hCEDCBAS
{
// char sType[11];                     // 0000
   char cIssIDNumberType;              // 0011
   char sISSUER_ID[12];                // 0012
   char sSEQUENCE_NO[4];               // 0024
   char sFiller1[1];                   // 0028
   short siStatus;                     // 0029
   short siPAN_LEN_MIN;                // 0031
   short siPAN_LEN_MAX;                // 0033
   char sFiller2[14];                  // 0035
   // ISSR-SUB-ID-LOC               NATIVE-2. 
   // ISSR-SUB-ID-NBR               PIC X(8). 
   // RANGE-EXPR-1-LOC              NATIVE-2. 
   // RANGE-EXPR-1-OPER-1           PIC X(2)  
   char sFiller3[24];						  // offset 0049
   // RANGE-EXPR-1-DATA-1           PIC X(8)
   // RANGE-EXPR-1-CONNECTOR        PIC X(3)
   // RANGE-EXPR-1-OPER-2           PIC X(2)
   // RANGE-EXPR-1-DATA-2           PIC X(8)
   // RANGE-EXPR-CONNECTOR-1        PIC X(3)
   char sFiller4[15];						  // offset 0073
   // RANGE-EXPR-2-LOC              NATIVE-2.
   // RANGE-EXPR-2-OPER-1           PIC X(2) 
   // RANGE-EXPR-2-DATA-1           PIC X(8).
   // RANGE-EXPR-2-CONNECTOR        PIC X(3) 
   char sFiller5[17];						  // offset 0088
   // RANGE-EXPR-2-OPER-2           PIC X(2)
   // RANGE-EXPR-2-DATA-2           PIC X(8)
   // RANGE-EXPR-CONNECTOR-2        PIC X(3)
   // RANGE-EXPR-3-LOC              NATIVE-2
   // RANGE-EXPR-3-OPER-1           PIC X(2)
   char sFiller6[22];						  // offset 0105
   // RANGE-EXPR-3-DATA-1           PIC X(8)
   // RANGE-EXPR-3-CONNECTOR        PIC X(3)
   // RANGE-EXPR-3-OPER-2           PIC X(2)
   // RANGE-EXPR-3-DATA-2           PIC X(8)
   // FILLER                        PIC X(1)
   char sFiller7[28];						  // offset 0127
   // CARD-LOGO-LIST                PIC X(8)
   // SOURCE-ROUTE-LIST             PIC X(8)
   // FILLER-C                      PIC X(8)
   // DEPOSIT-ONLY                  NATIVE-2
   // ISO-STANDARD-EXTENDED-PAN     NATIVE-2
   char sPAN_COUNTRY_CODE[3];				  // offset 0155
   char sISSUER_INST_ID[11];				  // offset 0158
   char sFiller8[8];						  // offset 0169
   // CARDHOLDER-CURRENCY           PIC X(3)
   // IMMEDIATE-ACTION-CODE         PIC X(3)
   // LANGUAGE-CODE                 PIC X(2)
   char sCARD_CATEGORY[2];                    // offset 0177
   char sFiller9[24];						  // offset 0179
   // CARD-LOGO-ID                  PIC X(8)
   // AP-CARD-GRP                   PIC X(8)
   // MAX-PIN-TRIES                 NATIVE-2
   // AP                            PIC X(6)
   char sFiller10[41];						  // offset 0203
   // CARD-OPTIONS-ID               PIC X(8)
   // ONUS-TRAN-SET                 PIC X(8)
   // PI-STANDIN-LIMIT-ID           PIC X(8)
   // CHK-DIGIT-PARMS-ID            PIC X(8)
   // TRACK-LOC-INFO-ID             PIC X(8)
   // DFLT-TRACK-NBR                PIC X(1)
   char sOWNER_RPT_INST_ID[11];				  // offset 0244
   char sOWNER_PROC_ID[6];					  // offset 0255
   char sFiller12[55];						  // offset 0261
   // UPDATE-TRACK1                 NATIVE-2
   // UPDATE-TRACK2                 NATIVE-2
   // UPDATE-TRACK3                 NATIVE-2
   // CONTACT-LIST                  PIC X(8)
   // CARD-MAINT-ROUT-ID            PIC X(8)
   // PRINT-MASK-ID                 PIC X(8)
   // CONNEX-DATA                   PIC X(21)
   // FRAUD-CARD-TYPE               PIC X(1)
   // SND-NG-MNT-TO-AP              NATIVE-2
   // CONNEX-OPT6                   PIC X(1)
   char sCUSTOM_DATA[25];					  // offset 0316
   char sFiller13[10];
   // CONNEX-OPT1                   NATIVE-2
   // CONNEX-OPT2                   NATIVE-2
   // CONNEX-OPT3                   NATIVE-2
   // CONNEX-OPT4                   NATIVE-2
   // CONNEX-OPT5                   NATIVE-2
   char sFiller14[18];
   // CUSTOM-OPT1                   NATIVE-2
   // CUSTOM-OPT2                   NATIVE-2
   // CUSTOM-OPT3                   NATIVE-2
   // CUSTOM-OPT4                   NATIVE-2
   // CUSTOM-OPT5                   NATIVE-2
   // ICC-PARMS-ID                  PIC X(8)
   char sFiller15[14];
   // EXPANDED-API-REQUIRED         PIC X(1)
   // SUPPRESS-HOST-BAL             PIC X(1)
   // A2A-PARTICIPATION             PIC X(1)
   // A2A-FUNDS-AVAILABLE           PIC X(1)
   // INST-INTERCHANGE-TIER         PIC X(2)
   // CARD-TYPE                     PIC X(2)
   // AP-BACKUP                     PIC X(6)
   char sFiller16[536];
   // FILLER-A                      PIC X(442)
   // FILLER-B                      NATIVE-2  OCCURS 46 TIMES
   // COMMON-START                  NATIVE-2
   char sFiller17[28];
   // DELETE-STATUS                 PIC XX
   // CHANGE-NUMBER                 PIC X(8)
   // PREVIOUS-CHANGE               PIC X(8)
   // UPDATING-PROGRAM              NATIVE-2
   // ADDED-TSTAMP.                 PIC x(6) HP timestamp
   // ADDED-USER                    NATIVE-2
   char sFiller18[88];
   // UPDATED-TSTAMP                PIC x(6) HP timestamp
   // UPDATED-USER                  NATIVE-2
   // DELETED-TSTAMP                PIC x(6) HP timestamp
   // DELETED-USER                  NATIVE-2
   // ROLLED-TSTAMP                 PIC x(6) HP timestamp
   // ROLLED-USER                   NATIVE-2
   // CLIENT-ID                     PIC X(4)
   // USER-NOTE                     PIC X(60)
};

struct hCEDPROC
{
// char sType[11];                     // 0000
   char sPROC_ID[6];                   // 0011
   short siStatus;                     // 0017
   char sPROC_NAME[35];                // 0019
   char sProcAddr1[35];                // 0054
   char sProcAddr2[35];                // 0089
   char sProcAddr3[35];                // 0124
   char sProcAddr4[35];                // 0159
   char cProcFiller1;                  // 0194
   short siProcPresentRptOnly;         // 0195
   char sProcContactList[8];           // 0197
   char sProcRjeID[8];                 // 0205
   char sSETL_INST_ID[11];             // 0213
   char sSETL_ACCT_NO[28];             // 0224
   char sSERVICE_LINE[2];              // 0252
   char sFUNDS_MOVEMENT_OPT[2];        // 0254
   char sADJUST_INST_ID[11];           // 0256
   char sADJUST_ACCT_ID[28];           // 0267
   char sONLINE_FEE_INST_ID[11];       // 0295
   char sONLINE_FEE_ACCT_ID[28];       // 0306
   char sFEE_BILL_INST_ID[11];         // 0334
   char sFEE_BILL_ACCT_ID[28];         // 0345
   char sProcCalendar[8];              // 0373
   char sProcHolidayList[8];           // 0381
   short siINTERCEPT_FLG;              // 0389
   short siProcStartEODNotify;         // 0391
   short siProcEndEODNotify;           // 0393
   short siProcHndShakeIntType;        // 0395
   short siProcHndShakeInt;            // 0397
   short siProcPendTimer;              // 0399
   char sProcSecurityCode[8];          // 0401
   short siProcEncryptCode;            // 0409
   char sProcEncryptKeysID[8];         // 0411
   short siProcKeyChgIntType;          // 0419
   short siProcKeyChgInterval;         // 0421
   char sPROCESS_NAME[6];              // 0423
   short siCUTOFF_INDa;                // 0429
   char sCUTOFF_TIMEa[4];              // 0431
   char sProcQueueFile[36];            // 0435
   char sProcProcValue[2];             // 0471
   short siCUTOFF_INDb;                // 0473
   char sCUTOFF_TIMEb[6];              // 0475
   char sCUTOFF_START_TIME[6];         // 0481
   char sProcAdvEndTime[6];            // 0487
   char sProcCustomData[25];           // 0493
   char sProcConnexData[17];           // 0518
   char sSETL_ACCT_TYPE[2];            // 0535
   char sADJUST_ACCT_TYPE[2];          // 0537
   char sONLINE_FEE_ACCT_TYPE[2];      // 0539
   char sFEE_BILL_ACCT_TYPE[2];        // 0541
   short siProcConnexOpt1;             // 0543
   short siProcConnexOpt2;             // 0545
   short siProcConnexOpt3;             // 0547
   short siProcConnexOpt4;             // 0549
   short siProcConnexOpt5;             // 0551
   short siProcCustomOpt1;             // 0553
   short siProcCustomOpt2;             // 0555
   short siProcCustomOpt3;             // 0557
   short siProcCustomOpt4;             // 0559
   short siProcCustomOpt5;             // 0561
   char siProcVerifyStatus[2];         // 0563
   char siProcDeleteStatus[2];         // 0565
   char siProcChgNbr[8];               // 0567
   char siProcPrevChg[8];              // 0575
   short siProcUpdatingPgm;            // 0583
   int siProcUpdatedTstamp4;           // 0585
   short siProcUpdatedUser;            // 0589
   int siProcDeletedTstamp4;           // 0591
   short siProcDeletedUser;            // 0595
   int siProcRolledTstamp4;            // 0597
   short siProcRolledUser;             // 0601
   char siProcClientID[4];             // 0603
   char siProcUserNote[60];            // 0607
   char sProcCommon[8];                // 0667
};

struct hCEDRPTL
{
// char sType[11];                     // 0000
   char sRPT_LVL_ID[10];               // 0011
   short siStatus;                     // 0021
   char sRPT_LVL_NAME[35];             // 0023
   char sRptlAddr1[35];                // 0058
   char sRptlAddr2[35];                // 0093
   char sRptlAddr3[35];                // 0128
   char sRptlAddr4[35];                // 0163
   char sRptlCardAcptName[25];         // 0198
   char sSETL_INST_ID[11];             // 0223
   char sSETL_ACCT_NO[28];             // 0234
   char sADJUST_INST_ID[11];           // 0262
   char sADJUST_ACCT_ID[28];           // 0273
   char sONLINE_FEE_INST_ID[11];       // 0301
   char sONLINE_FEE_ACCT_ID[28];       // 0312
   char sFEE_BILL_INST_ID[11];         // 0340
   char sFEE_BILL_ACCT_ID[28];         // 0351
   char sRptlAtsAplList[8];            // 0379
   char sNEXT_ID[10];                  // 0387
   short siRptlEDCFraudLimitCnt;       // 0397
   int lRptlEDCFraudLimitAmt4;         // 0399
   int lRptlEDCFraudLimitAmt4_1;       // 0403
   short siRptlNonEDCFraudLimitCnt;    // 0407
   int lRptlnonEDCFraudLimitAmt4;      // 0409
   int lRptlnonEDCFraudLimitAmt4_1;    // 0413
   char sTotalClass[2];                // 0417
   short siMaintainBusinessDate;       // 0419
   char sCalendarId[8];                // 0421
   char sHolidayList[8];               // 0429
   short siOnlineCutoverOpt;           // 0437
   short siCutOffCurrentLevel;         // 0439
   short siCutoffChildren;             // 0441
   short siSettlementCutoverOpt;       // 0443
   char sSettleCutoverTimeHour[2];     // 0445
   char sSettleCutoverTimeMinute[2];   // 0447
   char sSettleCutoverTimeSecond[2];   // 0449
   char sBeginCutoverSearchHour[2];    // 0451
   char sBeginCutoverSearchMinute[2];  // 0453
   char sBeginCutoverSearchSecond[2];  // 0455
   char sEndCutoverSearchHour[2];      // 0457
   char sEndCutoverSearchMinute[2];    // 0459
   char sEndCutoverSearchSecond[2];    // 0461
   char sServiceId1[28];               // 0463
   char sRptlCommon[30];               // 0491
};

struct hCEDTERM
{
// char sType[11];                     // 0000
   char sDEVICE_ID[8];                 // 0011
   short siStatus;                     // 0019
   char sTermCardAcptID[15];           // 0021
   char sADDRESS[28];                  // 0036
   char sCITY[27];                     // 0064
   char sREGION[3];                    // 0091
   char sCOUNTRY[3];                   // 0094
   char sCOUNTY[3];                    // 0097
   char cTermFiller1;                  // 0100
   char sPOSTAL_CODE[10];              // 0101
   char sTermCardAcptNameID[10];       // 0111
   char sTermAtsAplList[8];            // 0121
   char sTermRestrictGrp[8];           // 0129
   short siTermSpptsPartAppr;          // 0137
   short siTermOarEligible;            // 0139
   short siTermServiceFeeGrp;          // 0141
   char sTermOutbndTermGrp[8];         // 0143
   char sBILL_INTERCHG_GRP[2];         // 0151
   char sRPT_LVL_ID[10];               // 0153
   char sTermMerchantType[4];          // 0163
   char sTermBusinessCode[4];          // 0167
   char sTermAcqCountryCode[3];        // 0171
   char sTermAcqInstID[11];            // 0174
   char sTermCanInfoID[8];             // 0185
   short siTermAcqBranch;              // 0193
   char sINST_ID[11];                  // 0195
   char sTermAcqNetworkID[3];          // 0206
   char sTermSetlCardGrpID[8];         // 0209
   char sTermCardLogoList[8];          // 0217
   char sTermDfltCardLogoID[8];        // 0225
   char sTermContractList[8];          // 0233
   short siTermOnUsOnlyTerm;           // 0241
   short siTermDestRouteOpt;           // 0243
   short siTermResponseTimer;          // 0245
   short siTermRevTimeOut;             // 0247
   short siTermComplTimer;             // 0249
   short siTermInstrRetryCnt;          // 0251
   short siTermInstrRespTimer;         // 0253
   char cTermMaxDaysInDeposit;         // 0255
   char sDEFAULT_CUR_CODE[3];          // 0256
   char sTermDfltLanquage[2];          // 0259
   char sTermDfltFitEntry[8];          // 0261
   char cTermDfltAuthCkType;           // 0269
   char sTermChkVendorList[8];         // 0270
   char cTermCardDataInputCap;         // 0278
   char cTermCardholderAuthCap;        // 0279
   char cTermCardRetentCap;            // 0280
   char cTermOperatingEnv;             // 0281
   char cTermCardholderPresent;        // 0282
   char cTermCardPresent;              // 0283
   char cTermDataOutputCap;            // 0284
   char cTermOutputCap;                // 0285
   char cTermPinCaptureCap;            // 0286
   char sTermTermClass[2];             // 0287
   short siTermAutoCallDev;            // 0289
   char sTermDfltCbaseList[8];         // 0291
   char sTermSourceRteID[8];           // 0299
   char sTermCardLogoOptID[8];         // 0307
   char sTermCalenderID[8];            // 0315
   char sTermHolidayList[8];           // 0323
   short siTermHowAttached;            // 0331
   char sTermHotcardID[8];             // 0333
   short siTermPinBlkFmt;              // 0341
   short siTermBlkEncrypt;             // 0343
   char cTermPinPadChar;               // 0345
   char cTermZeroShrtPanSide;          // 0346
   short siTermCommEncryptCd;          // 0347
   short siTermMstrEncryptCd;          // 0349
   char sTermEncryptKeysID[8];         // 0351
   short siTermKeyChange;              // 0359
   short siTermKeyChgKeyType;          // 0361
   short siTermKeyChgIntrvlType;       // 0363
   short siTermKeyChgCnt;              // 0365
   short siTermKeyChgIntrvl;           // 0367
   short siTermComplMsgOpt;            // 0369
   short siTermMaintBusDate;           // 0371
   char sTermTotalsClass[2];           // 0373
   short siTermSndDenialToTotals;      // 0375
   char sTermSummTotalsID[10];         // 0377
   char sTermTH[6];                    // 0387
   char cTermLifeCycleInd;             // 0393
   char sTermLifeCycle[2];             // 0394
   char cTermTimeZoneOffSign;          // 0396
   short siTermTimeZoneOffHR;          // 0397
   short siTermTimeZoneOffMN;          // 0399
   char sTermCompntConfigID[8];        // 0401
   char sTermFastCashList[8];          // 0409
   char sTermLoadImgInfoID[8];         // 0417
   char sTermOverlayImgInfoID[8];      // 0425
   char sTermCommandList[8];           // 0433
   char sTermCommandCustMod[8];        // 0441
   char sTermSecondaryPost[10];        // 0449
   short siTermAuditDevInTH;           // 0459
   short siTermAuditDevInCH;           // 0461
   short siCUTOFF_IND;                 // 0463
   char sCUTOFF_TIME[6];               // 0465
   char sCUTOFF_START_TIME[6];         // 0471
   char sTermAdvEndTimeHH[2];          // 0477
   char sTermAdvEndTimeMM[2];          // 0479
   char sTermAdvEndTimeSS[2];          // 0481
   short siTermAckIfNoRespOpt;         // 0483
   int lTermMaxWithdrawlAmt4;          // 0485
   int lTermMaxWithdrawlAmt1;          // 0489
   int lTermMaxDepositAmt4;            // 0493
   int lTermMaxDepositAmt1;            // 0498
   short siTermKeySlotNmbr;            // 0501
   short siTermMaxMiniStmtItems;       // 0503
   short siTermMaxFullStmtItems;       // 0505
   short siTermStmtPrntDescWidth;      // 0507
   short siTermMaxStmtDescLines;       // 0509
   short siTermRecTranHist;            // 0511
   char sTermAltTermLocList[8];        // 0513
   char sTermOnlineFeeGrp[8];          // 0521
   char sTermRptingRegion[8];          // 0529
   char sTermRptingZone[8];            // 0537
   char sTermReqKeySeqList[8];         // 0545
   char sTermReqKeyCustMod[8];         // 0553
   char sTermReplyGrpList[8];          // 0561
   char sTermReplyCustMod[8];          // 0569
   char sTermDynScrnUpdateList[8];     // 0577
   char sTermDynScrnCustMod[8];        // 0585
   short siTermPromoType;              // 0593
   char sTermNormalOpenHour[2];        // 0595
   char sTermNormalCloseHour[2];       // 0597
   short siTermSurchgNotify;           // 0599
   short siTermCashMfmtByCan;          // 0601
   short siTermSupressStatuses;        // 0603
   short siTermSupressStateChg;        // 0605
   short siTermOfflineWarnTime;        // 0607
   short siTermTracek1OverTrack3;      // 0609
   char sTermDeviceDependData[25];     // 0611
   char sTermConnexData[25];           // 0636
   char sTermCustomData[25];           // 0661
   char cTermFiller3;                  // 0686
   short siTermDeviceOpt1;             // 0686
   short siTermDeviceOpt2;             // 0689
   short siTermDeviceOpt3;             // 0691
   short siTermDeviceOpt4;             // 0693
   short siTermDeviceOpt5;             // 0695
   short siTermConnexOpt1;             // 0697
   short siTermConnexOpt2;             // 0699
   short siTermConnexOpt3;             // 0701
   short siTermConnexOpt4;             // 0703
   short siTermConnexOpt5;             // 0705
   short siTermCustomOpt1;             // 0707
   short siTermCustomOpt2;             // 0709
   short siTermCustomOpt3;             // 0711
   short siTermCustomOpt4;             // 0713
   short siTermCustomOpt5;             // 0715
   char sTermLogicalNetId[4];          // 0717
   char sTermRKECA[8];                 // 0721
   char sTermRKESubCA[8];              // 0729
   char sTermRKEHSM[8];                // 0737
   char sTermAIDList[8];               // 0745
   char sFillerA[984];                 // 0753
   int lTermLoadImgInfoGrpmod4;        // 1737
   short siTermPOSAppsRef;             // 1741
   short siTermSSGLoadData;            // 1743
   short siTermEndpointSecType;        // 1745
   int lTermBilling;                   // 1747
   char sFillerB[190];                 // 1751
   short siTermCommonStart;            // 1941
   char sTermDeletestatus[2];          // 1943
   char sTermChangeNo[8];              // 1945
   char sTermPrevChange[8];            // 1953
   short siTermUpdatePrgm;             // 1961
   char sTermAddedTstamp[6];           // 1963
   short siTermAddedWord1;             // 1969
   short siTermAddedWord2;             // 1971
   short siTermAddedWord3;             // 1973
   short siTermAddedUser;              // 1975
   char sTermUpdatedTstamp[6];         // 1977
   short siTermUpdatedWord1;           // 1983
   short siTermUpdatedWord2;           // 1985
   short siTermUpdatedWord3;           // 1987
   short siTermUpdatedUser;            // 1989
   char sTermDeletedTstamp[6];         // 1991
   short siTermDeletedWord1;           // 1997
   short siTermDeletedWord2;           // 1999
   short siTermDeletedWord3;           // 2001
   short siTermDeletedUser;            // 2003
   char sTermRolledTstamp[6];          // 2005
   short siTermRolledWord1;            // 2011
   short siTermRolledWord2;            // 2013
   short siTermRolledWord3;            // 2015
   short siTermRolledUser;             // 2017
   char sTermClientID[4];              // 2019
   char sTermUserNote[60];             // 2023
};                                     // 2083

struct hCEDVAET
{
// char sType[11];                     // 0000
   char sDEVICE_ID[8];                 // 0011
   short siStatus;                     // 0019
   char sVaetCardAcptID[15];           // 0021
   char sADDRESS[28];                  // 0036
   char sCITY[27];                     // 0064
   char sREGION[3];                    // 0091
   char sCOUNTRY[3];                   // 0094
   char sCOUNTY[3];                    // 0097
   char sPOSTAL_CODE[10];              // 0100
   char sVaetCardAcptNameID[10];       // 0110
   char sVaetAtsAplList[8];            // 0120
   char sVaetRestrictGrp[8];           // 0128
   char cVaetMaxDaysInDeposit;         // 0136
   short siVaetSpptsPartAppr;          // 0137
   short siVaetOarEligible;            // 0139
   short siVaetServiceFeeGrp;          // 0141
   char sVaetOutbndTermGrp[8];         // 0143
   char sBILL_INTERCHG_GRP[2];         // 0151
   char sRPT_LVL_ID[10];               // 0153
   char sVaetMerchantType[4];          // 0163
   char sVaetBusinessCode[4];          // 0167
   char sVaetAcqCountryCode[3];        // 0171
   char sVaetAcqInstID[11];            // 0174
   short siVaetAcqBranch;              // 0185
   char sINST_ID[11];                  // 0187
   char sVaetAcqNetworkID[3];          // 0198
   char sVaetCardLogoList[8];          // 0201
   char sVaetDfltCardLogoID[8];        // 0209
   char sVaetContractList[8];          // 0217
   short siVaetOnUsOnlyTerm;           // 0225
   short siVaetDestRouteOpt;           // 0227
   short siVaetResponseTimer;          // 0229
   short siVaetRevTimeOut;             // 0231
   short siVaetComplTimer;             // 0233
   short siVaetInstrRetryCnt;          // 0235
   short siVaetInstrRespTimer;         // 0237
   char sDEFAULT_CUR_CODE[3];          // 0239
   char sVENDOR_MODEL[8];              // 0242
   char cVaetCardDataInputCap;         // 0250
   char cVaetCardholderAuthCap;        // 0251
   char cVaetCardRetentCap;            // 0252
   char cVaetOperatingEnv;             // 0253
   char cVaetCardholderPresent;        // 0254
   char cVaetCardPresent;              // 0255
   char cVaetDataOutputCap;            // 0256
   char cVaetOutputCap;                // 0257
   char cVaetPinCaptureCap;            // 0258
   char sVaetTermClass[2];             // 0259
   char sVaetDfltCbaseList[8];         // 0261
   char sVaetSourceRteID[8];           // 0269
   char sVaetCardLogoOptID[8];         // 0277
   char sVaetCalenderID[8];            // 0285
   char sVaetHolidayList[8];           // 0293
   short siVaetMaintBusDate;           // 0301
   char sVaetTotalsClass[2];           // 0303
   short siVaetSndDenialToTotals;      // 0305
   char sVaetSummTotalsID[10];         // 0307
   char cVaetLifeCycleInd;             // 0317
   char sVaetLifeCycle[2];             // 0318
   char cVaetTimeZoneOffSign;          // 0320
   short siVaetTimeZoneOffHR;          // 0321
   short siVaetTimeZoneOffMN;          // 0323
   char sVaetSecondaryPost[10];        // 0325
   short siCUTOFF_IND;                 // 0335
   char sCUTOFF_TIME[6];               // 0337
   char sCUTOFF_START_TIME[6];         // 0343
   char sVaetAdvEndTimeHH[2];          // 0349
   char sVaetAdvEndTimeMM[2];          // 0351
   char sVaetAdvEndTimeSS[2];          // 0353
   char sVaetConnexData[25];           // 0355
   char sVaetCustomData[25];           // 0380
   short siVaetConnexOpt1;             // 0405
   short siVaetConnexOpt2;             // 0407
   short siVaetConnexOpt3;             // 0409
   short siVaetConnexOpt4;             // 0411
   short siVaetConnexOpt5;             // 0413
   short siVaetCustomOpt1;             // 0415
   short siVaetCustomOpt2;             // 0417
   short siVaetCustomOpt3;             // 0419
   short siVaetCustomOpt4;             // 0421
   short siVaetCustomOpt5;             // 0423
};

struct hCEDPHYD
{
// char sType[11];                     // 0000
   char sDEVICE_ID[8];                 // 0011
   short siStatus;                     // 0019
   short siPhydDeviceType;             // 0021
   char sVENDOR_MODEL[8];              // 0023
   char sPhydEmulationModel[8];        // 0031
   char sPhydFirmwareRelease[8];       // 0039
   char sPhydSoftwareRelease[8];       // 0047
   short siPhydControlGrp;             // 0055
   char sPhydNoCallList[8];            // 0057
   char sPhydNoCallHoursID[8];         // 0065
   char sEscalateOverrides[8];         // 0073
   short siPhydBeginMonitorYY;         // 0081
   short siPhydBeginMonitorMM;         // 0083
   short siPhydBeginMonitorDD;         // 0085
   short siPhydEndMonitorYY;           // 0087
   short siPhydEndMonitorMM;           // 0089
   short siPhydEndMonitorDD;           // 0091
   char sPhydContactList[8];           // 0093
};
struct hCEDDADV
{
   char sDEVICE_ID[8];                        // 0000
   short siStatus;                            // 0008
   char sCIRCUIT_ID[8];                       // 0010
   char SUB_UNIT_ID[8];                       // 0018
   char cCOMM_ADDR_ENTRY_FORMAT;              // 0026
   char sCONTROL_UNIT_ADDR[3];                // 0027
   char sSELECT_ADDR[3];                      // 0030
   char sDEVICE_ADDR[3];                      // 0033
   char sSNA_PROFILE[8];                      // 0036
   char sSNA_APPLID[8];                       // 0044
   short siGENERAL_POLL;                      // 0052
   short siINITIAL_STATE_STARTED;             // 0054
   short siINITIAL_CONDITION_OPENED;          // 0056
   short siHAND_SHAKE_INTERVAL;               // 0058
   short siTRANSPARENCY;                      // 0060
   short siDATA_STREAM_OVERRIDE;              // 0062
   short siOVERRIDE_INBOUND_LEN;              // 0064
   short siOVERRIDE_OUTBOUND_LEN;             // 0066
   char sOVERRIDE_OUTBOUND_DATA[20];          // 0068
   short siHEADER_SEQ_NUM_LEN;                // 0088
   short siPROTOCOL_HEADER_OPTS;              // 0090
   short siFAST_SELECT;                       // 0092
   short siKEYBOARD_UNLOCK;                   // 0094
   short siINACTIVITY_TIMEOUT;                // 0096
   short siVIRTUAL_CIRCUIT_TYPE;              // 0098
   short siX25_CALL_USER_DATA_LEN;            // 0100
   char sX25_CALL_USER_DATA[32];              // 0102
   char sPROTOCOL_DEPENDENT_DATA[50];         // 0134
   short siPROTOCOL_OPT1;                     // 0184
   short siPROTOCOL_OPT2;                     // 0186
   short siPROTOCOL_OPT3;                     // 0188
   short siPROTOCOL_OPT4;                     // 0190
   short siPROTOCOL_OPT5;                     // 0192
   char cCOMMUNICATION_TYPE;                  // 0194
   char sALT_IP_ADDRESS1[25];                 // 0195
   char sALT_IP_ADDRESS2[25];                 // 0220
   char sALT_IP_ADDRESS3[25];                 // 0245
   char sFILLER_A[86];                        // 0270
   char sFILLER_B[38];                        // 0356
   char sVERIFY_STATUS[2];                    // 0394
   char sDELETE_STATUS[2];                    // 0396
   char sCHANGE_NUMBER[8];                    // 0398
   char sPREVIOUS_CHANGE[8];                  // 0406
   short siUPDATING_PROGRAM;                  // 0414
   int iADDED_TSTAMP_WORD;                    // 0416
   short siADDED_USER;                        // 0422
   int iUPDATED_TSTAMP_WORD;                  // 0424
   short siUPDATED_USER;                      // 0430
   int iDELETED_TSTAMP_WORD6;                 // 0432
   short siDELETED_USER;                      // 0438
   int iROLLED_TSTAMP_WORD6;                  // 0440
   short siROLLED_USER;                       // 0446
   char sCLIENT_ID[4];                        // 0448
   char sUSER_NOTE[60];                       // 0452
};
#include "CXODRU33.hpp"

#endif
