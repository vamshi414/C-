//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%38FE1D6900CC.cm preserve=no
//## end module%38FE1D6900CC.cm

//## begin module%38FE1D6900CC.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%38FE1D6900CC.cp

//## Module: CXOSAC02%38FE1D6900CC; Package body
//## Subsystem: AC%38FE1CA0036C
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Ac\CXOSAC02.cpp

//## begin module%38FE1D6900CC.additionalIncludes preserve=no
//## end module%38FE1D6900CC.additionalIncludes

//## begin module%38FE1D6900CC.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#include "CXODAC01.hpp"
#include "CXODDB01.hpp"
#include "CXODNS35.hpp"
#include "CXODNS37.hpp"
//## end module%38FE1D6900CC.includes

#ifndef CXOSNS01_h
#include "CXODNS01.hpp"
#endif
#ifndef CXOSNS02_h
#include "CXODNS02.hpp"
#endif
#ifndef CXOSNS06_h
#include "CXODNS06.hpp"
#endif
#ifndef CXOSNS03_h
#include "CXODNS03.hpp"
#endif
#ifndef CXOSNS05_h
#include "CXODNS05.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSIF41_h
#include "CXODIF41.hpp"
#endif
#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRU24_h
#include "CXODRU24.hpp"
#endif
#ifndef CXOSAC02_h
#include "CXODAC02.hpp"
#endif


//## begin module%38FE1D6900CC.declarations preserve=yes
#define BETA 10
#define HOLD 20
#define TEST 30
#define PROD 40
#define PREV 50
//## end module%38FE1D6900CC.declarations

//## begin module%38FE1D6900CC.additionalDeclarations preserve=yes
//## end module%38FE1D6900CC.additionalDeclarations


// Class AdvantageCED 

AdvantageCED::AdvantageCED()
  //## begin AdvantageCED::AdvantageCED%38FE1C28037D_const.hasinit preserve=no
      : m_bAsciiInput(false),
        m_pCursor(0),
        m_pDataBuffer(0),
        m_iPass(0),
        m_lRecordLength(0),
        m_bV13Advantage(true)
  //## end AdvantageCED::AdvantageCED%38FE1C28037D_const.hasinit
  //## begin AdvantageCED::AdvantageCED%38FE1C28037D_const.initialization preserve=yes
   ,CRFile("CED")
  //## end AdvantageCED::AdvantageCED%38FE1C28037D_const.initialization
{
  //## begin AdvantageCED::AdvantageCED%38FE1C28037D_const.body preserve=yes
   memcpy(m_sID,"AC02",4);
   m_hStatus.insert(PROD);
   string strRecord;
   Extract::instance()->getRecord("DUSER   ",strRecord);
   m_bV13Advantage = strRecord.find("V12") == string::npos;
   if (strRecord.find("BETA") != string::npos)
      m_hStatus.insert(BETA);
   if (strRecord.find("HOLD") != string::npos)
      m_hStatus.insert(HOLD);
   if (strRecord.find("TEST") != string::npos)
      m_hStatus.insert(TEST);
   if (strRecord.find("PREV") != string::npos)
      m_hStatus.insert(PREV);
  //## end AdvantageCED::AdvantageCED%38FE1C28037D_const.body
}


AdvantageCED::~AdvantageCED()
{
  //## begin AdvantageCED::~AdvantageCED%38FE1C28037D_dest.body preserve=yes
   m_hVendors.erase(m_hVendors.begin(),m_hVendors.end());
   m_hStatus.erase(m_hStatus.begin(),m_hStatus.end());
  //## end AdvantageCED::~AdvantageCED%38FE1C28037D_dest.body
}



//## Other Operations (implementation)
void AdvantageCED::copyCardBase ()
{
  //## begin AdvantageCED::copyCardBase%5760197A0378.body preserve=yes
   UseCase hUseCase("TANDEM","## AD34 CARD BASE");
   hCEDCBAS* pCEDCBAS = (hCEDCBAS*)m_pCursor;
   short siStatus = ntohs(pCEDCBAS->siStatus);
   if (m_hStatus.find(siStatus) == m_hStatus.end())
      return;
   m_pFileSegment = CRCardBaseSegment::instance();
   CRCardBaseSegment::instance()->reset();
#ifdef MVS
   if (m_bAsciiInput)
   {
      CodeTable::translate(pCEDCBAS->sISSUER_ID,sizeof(pCEDCBAS->sISSUER_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDCBAS->sSEQUENCE_NO,sizeof(pCEDCBAS->sSEQUENCE_NO),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDCBAS->sCUSTOM_DATA,sizeof(pCEDCBAS->sCUSTOM_DATA),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDCBAS->sPAN_COUNTRY_CODE,sizeof(pCEDCBAS->sPAN_COUNTRY_CODE),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDCBAS->sISSUER_INST_ID,sizeof(pCEDCBAS->sISSUER_INST_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDCBAS->sOWNER_RPT_INST_ID,sizeof(pCEDCBAS->sOWNER_RPT_INST_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDCBAS->sOWNER_PROC_ID,sizeof(pCEDCBAS->sOWNER_PROC_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDCBAS->sCARD_CATEGORY,sizeof(pCEDCBAS->sCARD_CATEGORY),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!m_bAsciiInput)
   {
      CodeTable::translate(pCEDCBAS->sISSUER_ID,sizeof(pCEDCBAS->sISSUER_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDCBAS->sSEQUENCE_NO,sizeof(pCEDCBAS->sSEQUENCE_NO),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDCBAS->sCUSTOM_DATA,sizeof(pCEDCBAS->sCUSTOM_DATA),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDCBAS->sPAN_COUNTRY_CODE,sizeof(pCEDCBAS->sPAN_COUNTRY_CODE),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDCBAS->sISSUER_INST_ID,sizeof(pCEDCBAS->sISSUER_INST_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDCBAS->sOWNER_RPT_INST_ID,sizeof(pCEDCBAS->sOWNER_RPT_INST_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDCBAS->sOWNER_PROC_ID,sizeof(pCEDCBAS->sOWNER_PROC_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDCBAS->sCARD_CATEGORY,sizeof(pCEDCBAS->sCARD_CATEGORY),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   CRCardBaseSegment::instance()->setISSUER_ID(cutSpaces(pCEDCBAS->sISSUER_ID,12));
   CRCardBaseSegment::instance()->setSEQUENCE_NO(cutSpaces(pCEDCBAS->sSEQUENCE_NO,4));
   CRCardBaseSegment::instance()->setCUSTOM_DATA(cutSpaces(pCEDCBAS->sCUSTOM_DATA,25));
   char szTemp[5];
   snprintf(szTemp,sizeof(szTemp),"%04d",ntohs(pCEDCBAS->siPAN_LEN_MIN));
   CRCardBaseSegment::instance()->setPAN_LEN_MIN(szTemp);
   snprintf(szTemp,sizeof(szTemp),"%04d",ntohs(pCEDCBAS->siPAN_LEN_MAX));
   CRCardBaseSegment::instance()->setPAN_LEN_MAX(szTemp);
   CRCardBaseSegment::instance()->setISSUER_INST_ID(cutSpaces(pCEDCBAS->sISSUER_INST_ID,11));
   CRCardBaseSegment::instance()->setOWNER_RPT_INST_ID(cutSpaces(pCEDCBAS->sOWNER_RPT_INST_ID,11));
   CRCardBaseSegment::instance()->setOWNER_PROC_ID(cutSpaces(pCEDCBAS->sOWNER_PROC_ID,6));
   CRCardBaseSegment::instance()->setCARD_CATEGORY(cutSpaces(pCEDCBAS->sCARD_CATEGORY,2));
  //## end AdvantageCED::copyCardBase%5760197A0378.body
}

void AdvantageCED::copyDataMap ()
{
  //## begin AdvantageCED::copyDataMap%5759DA0D02A2.body preserve=yes
   UseCase hUseCase("TANDEM","## AD33 DATA MAP");
   hCEDDMAP* pCEDDMAP = (hCEDDMAP*)m_pCursor;
   short siStatus = ntohs(pCEDDMAP->siStatus);
   if (m_hStatus.find(siStatus) == m_hStatus.end())
      return;
   m_pFileSegment = CRDataMapSegment::instance();
   CRDataMapSegment::instance()->reset();
#ifdef MVS
   if (m_bAsciiInput)
   {
      CodeTable::translate(pCEDDMAP->sPROCESS_NAME,sizeof(pCEDDMAP->sPROCESS_NAME),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDDMAP->sINPUT_DATA_TYPE,sizeof(pCEDDMAP->sINPUT_DATA_TYPE),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDDMAP->sINPUT_DATA,sizeof(pCEDDMAP->sINPUT_DATA),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDDMAP->sOUTPUT_DATA_TYPE,sizeof(pCEDDMAP->sOUTPUT_DATA_TYPE),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDDMAP->sOUTPUT_DATA,sizeof(pCEDDMAP->sOUTPUT_DATA),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!m_bAsciiInput)
   {
      CodeTable::translate(pCEDDMAP->sPROCESS_NAME,sizeof(pCEDDMAP->sPROCESS_NAME),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDDMAP->sINPUT_DATA_TYPE,sizeof(pCEDDMAP->sINPUT_DATA_TYPE),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDDMAP->sINPUT_DATA,sizeof(pCEDDMAP->sINPUT_DATA),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDDMAP->sOUTPUT_DATA_TYPE,sizeof(pCEDDMAP->sOUTPUT_DATA_TYPE),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDDMAP->sOUTPUT_DATA,sizeof(pCEDDMAP->sOUTPUT_DATA),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   CRDataMapSegment::instance()->setPROCESS_NAME(cutSpaces(pCEDDMAP->sPROCESS_NAME,6));
   CRDataMapSegment::instance()->setINPUT_DATA_TYPE(cutSpaces(pCEDDMAP->sINPUT_DATA_TYPE,2));
   CRDataMapSegment::instance()->setINPUT_DATA(cutSpaces(pCEDDMAP->sINPUT_DATA,20));
   CRDataMapSegment::instance()->setOUTPUT_DATA_TYPE(cutSpaces(pCEDDMAP->sOUTPUT_DATA_TYPE,2));
   CRDataMapSegment::instance()->setOUTPUT_DATA(cutSpaces(pCEDDMAP->sOUTPUT_DATA,20));
  //## end AdvantageCED::copyDataMap%5759DA0D02A2.body
}

void AdvantageCED::copyDirectAttachedDevice ()
{
  //## begin AdvantageCED::copyDirectAttachedDevice%65316712028F.body preserve=yes
   hCEDDADV* pCEDDADV = (hCEDDADV*)m_pCursor;
   short siStatus = ntohs(pCEDDADV->siStatus);
   if (m_hStatus.find(siStatus) == m_hStatus.end())
      return;
#ifdef MVS
   if (m_bAsciiInput)
   {
      CodeTable::translate(pCEDDADV->sDEVICE_ID, sizeof(pCEDDADV->sDEVICE_ID), CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDDADV->sCIRCUIT_ID, sizeof(pCEDDADV->sCIRCUIT_ID), CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!m_bAsciiInput)
   {
      CodeTable::translate(pCEDDADV->sDEVICE_ID, sizeof(pCEDDADV->sDEVICE_ID), CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDDADV->sCIRCUIT_ID, sizeof(pCEDDADV->sCIRCUIT_ID), CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   string strDevice(pCEDDADV->sDEVICE_ID,8);
   string strCircuitID(pCEDDADV->sCIRCUIT_ID,8);
   size_t pos = strCircuitID.find(' ');
   if (pos != string::npos)
      strCircuitID.erase(pos);
   m_hCircuitIDs.insert(map<string, string, less<string> >::value_type(strDevice,strCircuitID));
  //## end AdvantageCED::copyDirectAttachedDevice%65316712028F.body
}

void AdvantageCED::copyInstitution ()
{
  //## begin AdvantageCED::copyInstitution%38FE234C0187.body preserve=yes
   UseCase hUseCase("TANDEM","## AD03 INSTITUTION");

   hCEDINST* pCEDINST = (hCEDINST*)m_pCursor;
   short siStatus = ntohs(pCEDINST->siStatus);
   if (m_hStatus.find(siStatus) == m_hStatus.end())
      return;
   m_pFileSegment = CRInstitutionSegment::instance();
   CRInstitutionSegment::instance()->reset();
#ifdef MVS
   if (m_bAsciiInput)
   {
      CodeTable::translate(pCEDINST->sINST_ID,((char*)(&pCEDINST->siStatus) - pCEDINST->sINST_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDINST->sNAME,((char*)(&pCEDINST->siInstIDMapOpt) - pCEDINST->sNAME),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDINST->sInstAtsAplList,(pCEDINST->sFiller - pCEDINST->sInstAtsAplList),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!m_bAsciiInput)
   {
      CodeTable::translate(pCEDINST->sINST_ID,((char*)(&pCEDINST->siStatus) - pCEDINST->sINST_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDINST->sNAME,((char*)(&pCEDINST->siInstIDMapOpt) - pCEDINST->sNAME),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDINST->sInstAtsAplList,(pCEDINST->sFiller - pCEDINST->sInstAtsAplList),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   CRInstitutionSegment::instance()->setINST_ID(reformatINST_ID(pCEDINST->sINST_ID));
   CRInstitutionSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   CRInstitutionSegment::instance()->setNAME(cutSpaces(pCEDINST->sNAME,35));
   CRInstitutionSegment::instance()->setADJUST_INST_ID(reformatINST_ID(pCEDINST->sADJUST_INST_ID));
   CRInstitutionSegment::instance()->setADJUST_ACCT_ID(cutSpaces(pCEDINST->sADJUST_ACCT_ID,28));
   CRInstitutionSegment::instance()->setADJUST_ACCT_TYPE(cutSpaces(pCEDINST->sADJUST_ACCT_TYPE,2));
   CRInstitutionSegment::instance()->setBANK_ID(cutSpaces(pCEDINST->sBANK_ID,4));
   CRInstitutionSegment::instance()->setONLINE_FEE_INST_ID(reformatINST_ID(pCEDINST->sONLINE_FEE_INST_ID));
   CRInstitutionSegment::instance()->setONLINE_FEE_ACCT_ID(cutSpaces(pCEDINST->sONLINE_FEE_ACCT_ID,28));
   CRInstitutionSegment::instance()->setONLN_FEE_ACCT_TYPE(cutSpaces(pCEDINST->sONLN_FEE_ACCT_TYPE,2));
   CRInstitutionSegment::instance()->setFEE_BILL_INST_ID(reformatINST_ID(pCEDINST->sFEE_BILL_INST_ID));
   CRInstitutionSegment::instance()->setFEE_BILL_ACCT_ID(cutSpaces(pCEDINST->sFEE_BILL_ACCT_ID,28));
   CRInstitutionSegment::instance()->setFEE_BILL_ACCT_TYPE(cutSpaces(pCEDINST->sFEE_BILL_ACCT_TYPE,2));
   CRInstitutionSegment::instance()->setSETL_INST_ID(reformatINST_ID(pCEDINST->sSETL_INST_ID));
   CRInstitutionSegment::instance()->setSETL_ACCT_NO(cutSpaces(pCEDINST->sSETL_ACCT_NO,28));
   CRInstitutionSegment::instance()->setSETL_ACCT_TYPE(cutSpaces(pCEDINST->sSETL_ACCT_TYPE,2));
   CRInstitutionSegment::instance()->setFUNDS_MOVEMENT_OPT(cutSpaces(pCEDINST->sFUNDS_MOVEMENT_OPT,2));
   CRInstitutionSegment::instance()->setSERVICE_LINE(cutSpaces(pCEDINST->sSERVICE_LINE,2));
   CRInstitutionSegment::instance()->setBILL_INTERCHG_GRP(cutSpaces(pCEDINST->sBILL_INTERCHG_GRP,2));
   CRInstitutionSegment::instance()->setAIMS_FI_BILLING_ID(cutSpaces(pCEDINST->sAIMS_FI_BILLING_ID,10));
   CRInstitutionSegment::instance()->setCOUNTRY_CODE(cutSpaces(pCEDINST->sInstCountryCode,3));
   if (!memcmp(pCEDINST->sSettlePROC_ID,"      ",6))
      CRInstitutionSegment::instance()->setPROC_ID(cutSpaces(pCEDINST->sAcquirerPROC_ID,6));
   else
      CRInstitutionSegment::instance()->setPROC_ID(cutSpaces(pCEDINST->sSettlePROC_ID,6));
   if (memcmp(pCEDINST->sCUTOFF_TIME,"000000",6) != 0)
   {
      CRInstitutionSegment::instance()->setCUTOFF_IND("1");
      string strCUTOFF_TIME(pCEDINST->sCUTOFF_TIME,6);
      strCUTOFF_TIME += strCUTOFF_TIME[5] == '0' || strCUTOFF_TIME[5] == ' ' ? "00" : "99";
      CRInstitutionSegment::instance()->setCUTOFF_TIME(strCUTOFF_TIME);
   }
  //## end AdvantageCED::copyInstitution%38FE234C0187.body
}

void AdvantageCED::copyInterceptDevice ()
{
  //## begin AdvantageCED::copyInterceptDevice%38FE235201E0.body preserve=yes
   UseCase hUseCase("TANDEM","## AD04 INTERCEPT DEVICE");
   hCEDINTR* pCEDINTR = (hCEDINTR*)m_pCursor;
   short siStatus = ntohs(pCEDINTR->siStatus);
   if (m_hStatus.find(siStatus) == m_hStatus.end())
      return;
   m_pFileSegment = CRDeviceSegment::instance();
   CRDeviceSegment::instance()->reset();
#ifdef MVS
   if (m_bAsciiInput)
   {
      CodeTable::translate(pCEDINTR->sDEVICE_ID,sizeof(pCEDINTR->sDEVICE_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDINTR->sIntrCardAcptID,((char*)(&pCEDINTR->siIntrServiceFeeGrp) - pCEDINTR->sIntrCardAcptID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDINTR->sIntrOutbndTermGrp,((char*)(pCEDINTR->sIntrFloorLimit) - pCEDINTR->sIntrOutbndTermGrp),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDINTR->sIntrCountryCode,((char*)(&pCEDINTR->siIntrAcqBranch) - pCEDINTR->sIntrCountryCode),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDINTR->sIntrCardLogoList,((char*)(&pCEDINTR->siIntrDirectRouteOpt) - pCEDINTR->sIntrCardLogoList),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDINTR->sIntrAcqNetworkID,((char*)(&pCEDINTR->siIntrResponseTimer) - pCEDINTR->sIntrAcqNetworkID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDINTR->sCUTOFF_TIME,((char*)(&pCEDINTR->siIntrConnexOpt1) - pCEDINTR->sCUTOFF_TIME),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDINTR->sIntrCommon,sizeof(pCEDINTR->sIntrCommon),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!m_bAsciiInput)
   {
      CodeTable::translate(pCEDINTR->sDEVICE_ID,sizeof(pCEDINTR->sDEVICE_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDINTR->sIntrCardAcptID,((char*)(&pCEDINTR->siIntrServiceFeeGrp) - pCEDINTR->sIntrCardAcptID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDINTR->sIntrOutbndTermGrp,((char*)(pCEDINTR->sIntrFloorLimit) - pCEDINTR->sIntrOutbndTermGrp),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDINTR->sIntrCountryCode,((char*)(&pCEDINTR->siIntrAcqBranch) - pCEDINTR->sIntrCountryCode),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDINTR->sIntrCardLogoList,((char*)(&pCEDINTR->siIntrDirectRouteOpt) - pCEDINTR->sIntrCardLogoList),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDINTR->sIntrAcqNetworkID,((char*)(&pCEDINTR->siIntrResponseTimer) - pCEDINTR->sIntrAcqNetworkID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDINTR->sCUTOFF_TIME,((char*)(&pCEDINTR->siIntrConnexOpt1) - pCEDINTR->sCUTOFF_TIME),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDINTR->sIntrCommon,sizeof(pCEDINTR->sIntrCommon),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   string strTemp(pCEDINTR->sDEVICE_ID,6);
   CRDeviceSegment::instance()->setDEVICE_ID(strTemp);
   map<string,string,less<string> >::iterator pVendor;
   pVendor = m_hVendors.find(strTemp);
   if (pVendor != m_hVendors.end())
      CRDeviceSegment::instance()->setVENDOR_MODEL((*pVendor).second);
   CRDeviceSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   CRDeviceSegment::instance()->setRPT_LVL_ID(cutSpaces(pCEDINTR->sRPT_LVL_ID,10));
   CRDeviceSegment::instance()->setINST_ID(reformatINST_ID(pCEDINTR->sINST_ID));
   CRDeviceSegment::instance()->setBILL_INTERCHG_GRP(cutSpaces(pCEDINTR->sBILL_INTERCHG_GRP,2));
   if (ntohs(pCEDINTR->siACPT_TERM_SORT_FLG))
      CRDeviceSegment::instance()->setACPT_TERM_SORT_FLG("Y");
   else
      CRDeviceSegment::instance()->setACPT_TERM_SORT_FLG("N");
   CRDeviceSegment::instance()->setCOUNTRY(cutSpaces(pCEDINTR->sCOUNTRY,3));
   CRDeviceSegment::instance()->setCOUNTY(cutSpaces(pCEDINTR->sCOUNTY,3));
   CRDeviceSegment::instance()->setREGION(cutSpaces(pCEDINTR->sREGION,3));
   CRDeviceSegment::instance()->setPOSTAL_CODE(cutSpaces(pCEDINTR->sPOSTAL_CODE,10));
   CRDeviceSegment::instance()->setADDRESS(cutSpaces(pCEDINTR->sADDRESS,28));
   CRDeviceSegment::instance()->setCITY(cutSpaces(pCEDINTR->sCITY,27));
   CRDeviceSegment::instance()->setDEFAULT_CUR_CODE(cutSpaces(pCEDINTR->sDEFAULT_CUR_CODE,3));
   CRDeviceSegment::instance()->setPSEUDO_TERM_FLG("Y");
   if (ntohs(pCEDINTR->siCUTOFF_IND) <= 2)
   {
      char szCUTOFF_IND[4] = {"100"};
      string strCUTOFF_IND(szCUTOFF_IND + ntohs(pCEDINTR->siCUTOFF_IND),1);
      if (strCUTOFF_IND == "1"
         && memcmp(pCEDINTR->sCUTOFF_TIME,"000000",6) == 0)
         strCUTOFF_IND = "2";
      CRDeviceSegment::instance()->setCUTOFF_IND(strCUTOFF_IND);
   }
   strTemp.assign(pCEDINTR->sCUTOFF_TIME,6);
   strTemp += strTemp[5] == '0' || strTemp[5] == ' ' ? "00" : "99";
   CRDeviceSegment::instance()->setCUTOFF_TIME(strTemp);
   strTemp.assign(pCEDINTR->sCUTOFF_START_TIME,6);
   strTemp += "00";
   CRDeviceSegment::instance()->setCUTOFF_START_TIME(strTemp);
  //## end AdvantageCED::copyInterceptDevice%38FE235201E0.body
}

void AdvantageCED::copyPANMask ()
{
  //## begin AdvantageCED::copyPANMask%38FE235F02ED.body preserve=yes
   UseCase hUseCase("TANDEM","## AD05 PAN MASK");
   hCEDPRNT* pCEDPRNT = (hCEDPRNT*)m_pCursor;
   short siStatus = ntohs(pCEDPRNT->siStatus);
   if (m_hStatus.find(siStatus) == m_hStatus.end())
      return;
   m_pFileSegment = CRPanMaskSegment::instance();
   CRPanMaskSegment::instance()->reset();
#ifdef MVS
   if (m_bAsciiInput)
   {
      CodeTable::translate(pCEDPRNT->sPAN_MASK_ID,((char*)(&pCEDPRNT->siStatus) - pCEDPRNT->sPAN_MASK_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDPRNT->sPAN_MASK,sizeof(pCEDPRNT->sPAN_MASK),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDPRNT->sPrntCommon,sizeof(pCEDPRNT->sPrntCommon),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!m_bAsciiInput)
   {
      CodeTable::translate(pCEDPRNT->sPAN_MASK_ID,((char*)(&pCEDPRNT->siStatus) - pCEDPRNT->sPAN_MASK_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDPRNT->sPAN_MASK,sizeof(pCEDPRNT->sPAN_MASK),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDPRNT->sPrntCommon,sizeof(pCEDPRNT->sPrntCommon),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   CRPanMaskSegment::instance()->setPAN_MASK_ID(cutSpaces(pCEDPRNT->sPAN_MASK_ID,8));
   CRPanMaskSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   CRPanMaskSegment::instance()->setPAN_MASK(cutSpaces(pCEDPRNT->sPAN_MASK,21));
  //## end AdvantageCED::copyPANMask%38FE235F02ED.body
}

void AdvantageCED::copyPhysicalDevice ()
{
  //## begin AdvantageCED::copyPhysicalDevice%39C64E0F02B1.body preserve=yes
   hCEDPHYD* pCEDPHYD = (hCEDPHYD*)m_pCursor;
   short siStatus = ntohs(pCEDPHYD->siStatus);
   if (m_hStatus.find(siStatus) == m_hStatus.end())
      return;
#ifdef MVS
   if (m_bAsciiInput)
   {
      CodeTable::translate(pCEDPHYD->sDEVICE_ID,sizeof(pCEDPHYD->sDEVICE_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDPHYD->sVENDOR_MODEL,sizeof(pCEDPHYD->sVENDOR_MODEL),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!m_bAsciiInput)
   {
      CodeTable::translate(pCEDPHYD->sDEVICE_ID,sizeof(pCEDPHYD->sDEVICE_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDPHYD->sVENDOR_MODEL,sizeof(pCEDPHYD->sVENDOR_MODEL),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   string strDevice(pCEDPHYD->sDEVICE_ID,8);
   string strVendor(pCEDPHYD->sVENDOR_MODEL,8);
   size_t pos = strVendor.find(' ');
   if (pos != string::npos)
      strVendor.erase(pos);
   m_hVendors.insert(map<string,string,less<string> >::value_type(strDevice,strVendor));
  //## end AdvantageCED::copyPhysicalDevice%39C64E0F02B1.body
}

void AdvantageCED::copyProcessor ()
{
  //## begin AdvantageCED::copyProcessor%38FE236B03E4.body preserve=yes
   UseCase hUseCase("TANDEM","## AD06 PROCESSOR");
   hCEDPROC* pCEDPROC = (hCEDPROC*)m_pCursor;
   short siStatus = ntohs(pCEDPROC->siStatus);
   if (m_hStatus.find(siStatus) == m_hStatus.end())
      return;
   m_pFileSegment = CRProcessorSegment::instance();
   CRProcessorSegment::instance()->reset();
#ifdef MVS
   if (m_bAsciiInput)
   {
      CodeTable::translate(pCEDPROC->sPROC_ID,sizeof(pCEDPROC->sPROC_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDPROC->sPROC_NAME,((char*)(&pCEDPROC->siProcPresentRptOnly) - pCEDPROC->sPROC_NAME),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDPROC->sProcContactList,((char*)(&pCEDPROC->siINTERCEPT_FLG) - pCEDPROC->sProcContactList),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDPROC->sProcSecurityCode,sizeof(pCEDPROC->sProcSecurityCode),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDPROC->sProcEncryptKeysID,sizeof(pCEDPROC->sProcEncryptKeysID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDPROC->sPROCESS_NAME,sizeof(pCEDPROC->sPROCESS_NAME),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDPROC->sCUTOFF_TIMEa,((char*)(&pCEDPROC->siCUTOFF_INDb) - pCEDPROC->sCUTOFF_TIMEa),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDPROC->sCUTOFF_TIMEb,((char*)(&pCEDPROC->siProcConnexOpt1) - pCEDPROC->sCUTOFF_TIMEb),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDPROC->sProcCommon,sizeof(pCEDPROC->sProcCommon),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!m_bAsciiInput)
   {
      CodeTable::translate(pCEDPROC->sPROC_ID,sizeof(pCEDPROC->sPROC_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDPROC->sPROC_NAME,((char*)(&pCEDPROC->siProcPresentRptOnly) - pCEDPROC->sPROC_NAME),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDPROC->sProcContactList,((char*)(&pCEDPROC->siINTERCEPT_FLG) - pCEDPROC->sProcContactList),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDPROC->sProcSecurityCode,sizeof(pCEDPROC->sProcSecurityCode),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDPROC->sProcEncryptKeysID,sizeof(pCEDPROC->sProcEncryptKeysID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDPROC->sPROCESS_NAME,sizeof(pCEDPROC->sPROCESS_NAME),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDPROC->sCUTOFF_TIMEa,((char*)(&pCEDPROC->siCUTOFF_INDb) - pCEDPROC->sCUTOFF_TIMEa),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDPROC->sCUTOFF_TIMEb,((char*)(&pCEDPROC->siProcConnexOpt1) - pCEDPROC->sCUTOFF_TIMEb),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDPROC->sProcCommon,sizeof(pCEDPROC->sProcCommon),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   CRProcessorSegment::instance()->setPROC_ID(cutSpaces(pCEDPROC->sPROC_ID,6));
   CRProcessorSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   CRProcessorSegment::instance()->setPROCESS_NAME(cutSpaces(pCEDPROC->sPROCESS_NAME,6));
   CRProcessorSegment::instance()->setPROC_NAME(cutSpaces(pCEDPROC->sPROC_NAME,35));
   CRProcessorSegment::instance()->setADJUST_INST_ID(reformatINST_ID(pCEDPROC->sADJUST_INST_ID));
   CRProcessorSegment::instance()->setADJUST_ACCT_ID(cutSpaces(pCEDPROC->sADJUST_ACCT_ID,28));
   CRProcessorSegment::instance()->setADJUST_ACCT_TYPE(cutSpaces(pCEDPROC->sADJUST_ACCT_TYPE,2));
   CRProcessorSegment::instance()->setONLINE_FEE_INST_ID(reformatINST_ID(pCEDPROC->sONLINE_FEE_INST_ID));
   CRProcessorSegment::instance()->setONLINE_FEE_ACCT_ID(cutSpaces(pCEDPROC->sONLINE_FEE_ACCT_ID,28));
   CRProcessorSegment::instance()->setONLN_FEE_ACCT_TYPE(cutSpaces(pCEDPROC->sONLINE_FEE_ACCT_TYPE,2));
   CRProcessorSegment::instance()->setFEE_BILL_INST_ID(reformatINST_ID(pCEDPROC->sFEE_BILL_INST_ID));
   CRProcessorSegment::instance()->setFEE_BILL_ACCT_ID(cutSpaces(pCEDPROC->sFEE_BILL_ACCT_ID,28));
   CRProcessorSegment::instance()->setFEE_BILL_ACCT_TYPE(cutSpaces(pCEDPROC->sFEE_BILL_ACCT_TYPE,2));
   CRProcessorSegment::instance()->setSETL_INST_ID(reformatINST_ID(pCEDPROC->sSETL_INST_ID));
   CRProcessorSegment::instance()->setSETL_ACCT_NO(cutSpaces(pCEDPROC->sSETL_ACCT_NO,28));
   CRProcessorSegment::instance()->setSETL_ACCT_TYPE(cutSpaces(pCEDPROC->sSETL_ACCT_TYPE,2));
   CRProcessorSegment::instance()->setFUNDS_MOVEMENT_OPT(cutSpaces(pCEDPROC->sFUNDS_MOVEMENT_OPT,2));
   CRProcessorSegment::instance()->setSERVICE_LINE(cutSpaces(pCEDPROC->sSERVICE_LINE,2));
   if (ntohs(pCEDPROC->siINTERCEPT_FLG))
      CRProcessorSegment::instance()->setINTERCEPT_FLG("Y");
   else
      CRProcessorSegment::instance()->setINTERCEPT_FLG("N");
   if (ntohs(pCEDPROC->siCUTOFF_INDa) <= 2)
   {
      char szCUTOFF_IND[4] = {"210"};
      string strCUTOFF_IND(szCUTOFF_IND + ntohs(pCEDPROC->siCUTOFF_INDa),1);
      CRProcessorSegment::instance()->setCUTOFF_IND(strCUTOFF_IND);
   }
   if (ntohs(pCEDPROC->siCUTOFF_INDa) == 1)
   {
      string strTemp(pCEDPROC->sCUTOFF_TIMEa,4);
      strTemp += "0000";
      CRProcessorSegment::instance()->setCUTOFF_TIME(strTemp);
   }
   else
   if (ntohs(pCEDPROC->siCUTOFF_INDb) > 0)
   {
      string strTemp(pCEDPROC->sCUTOFF_START_TIME,6);
      strTemp += "00";
      CRProcessorSegment::instance()->setCUTOFF_START_TIME(strTemp);
      strTemp.assign(pCEDPROC->sCUTOFF_TIMEb,6);
      strTemp += strTemp[5] == '0' || strTemp[5] == ' ' ? "00" : "99";
      CRProcessorSegment::instance()->setCUTOFF_TIME(strTemp);
   }
  //## end AdvantageCED::copyProcessor%38FE236B03E4.body
}

void AdvantageCED::copyReportingLevel ()
{
  //## begin AdvantageCED::copyReportingLevel%38FE236F03D6.body preserve=yes
   UseCase hUseCase("TANDEM","## AD07 REPORTING LEVEL");
   hCEDRPTL* pCEDRPTL = (hCEDRPTL*)m_pCursor;
   short siStatus = ntohs(pCEDRPTL->siStatus);
   if (m_hStatus.find(siStatus) == m_hStatus.end())
      return;
   m_pFileSegment = CRReportingLevelSegment::instance();
   CRReportingLevelSegment::instance()->reset();
#ifdef MVS
   if (m_bAsciiInput)
   {
      CodeTable::translate(pCEDRPTL->sRPT_LVL_ID,((char*)(&pCEDRPTL->siStatus) - pCEDRPTL->sRPT_LVL_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDRPTL->sRPT_LVL_NAME,((char*)(&pCEDRPTL->siRptlEDCFraudLimitCnt) - pCEDRPTL->sRPT_LVL_NAME),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDRPTL->sTotalClass,sizeof(pCEDRPTL->sTotalClass),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDRPTL->sCalendarId,((char*)(&pCEDRPTL->siOnlineCutoverOpt) - pCEDRPTL->sCalendarId),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sSettleCutoverTimeHour,sizeof(pCEDRPTL->sSettleCutoverTimeHour),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sSettleCutoverTimeHour,sizeof(pCEDRPTL->sSettleCutoverTimeHour),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sSettleCutoverTimeMinute,sizeof(pCEDRPTL->sSettleCutoverTimeMinute),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sSettleCutoverTimeSecond,sizeof(pCEDRPTL->sSettleCutoverTimeSecond),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sBeginCutoverSearchHour,sizeof(pCEDRPTL->sBeginCutoverSearchHour),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sBeginCutoverSearchMinute,sizeof(pCEDRPTL->sBeginCutoverSearchMinute),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sBeginCutoverSearchSecond,sizeof(pCEDRPTL->sBeginCutoverSearchSecond),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sEndCutoverSearchHour,sizeof(pCEDRPTL->sEndCutoverSearchHour),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sEndCutoverSearchMinute,sizeof(pCEDRPTL->sEndCutoverSearchMinute),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sEndCutoverSearchSecond,sizeof(pCEDRPTL->sEndCutoverSearchSecond),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sServiceId1,sizeof(pCEDRPTL->sServiceId1),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sRptlCommon,sizeof(pCEDRPTL->sRptlCommon),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#else
   if (!m_bAsciiInput)
   {
      CodeTable::translate(pCEDRPTL->sRPT_LVL_ID,((char*)(&pCEDRPTL->siStatus) - pCEDRPTL->sRPT_LVL_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sRPT_LVL_NAME,((char*)(&pCEDRPTL->siRptlEDCFraudLimitCnt) - pCEDRPTL->sRPT_LVL_NAME),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sTotalClass,sizeof(pCEDRPTL->sTotalClass),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDRPTL->sCalendarId,((char*)(&pCEDRPTL->siOnlineCutoverOpt) - pCEDRPTL->sCalendarId),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sSettleCutoverTimeHour,sizeof(pCEDRPTL->sSettleCutoverTimeHour),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sSettleCutoverTimeHour,sizeof(pCEDRPTL->sSettleCutoverTimeHour),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sSettleCutoverTimeMinute,sizeof(pCEDRPTL->sSettleCutoverTimeMinute),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sSettleCutoverTimeSecond,sizeof(pCEDRPTL->sSettleCutoverTimeSecond),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sBeginCutoverSearchHour,sizeof(pCEDRPTL->sBeginCutoverSearchHour),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sBeginCutoverSearchMinute,sizeof(pCEDRPTL->sBeginCutoverSearchMinute),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sBeginCutoverSearchSecond,sizeof(pCEDRPTL->sBeginCutoverSearchSecond),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sEndCutoverSearchHour,sizeof(pCEDRPTL->sEndCutoverSearchHour),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sEndCutoverSearchMinute,sizeof(pCEDRPTL->sEndCutoverSearchMinute),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sEndCutoverSearchSecond,sizeof(pCEDRPTL->sEndCutoverSearchSecond),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sServiceId1,sizeof(pCEDRPTL->sServiceId1),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDRPTL->sRptlCommon,sizeof(pCEDRPTL->sRptlCommon),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   CRReportingLevelSegment::instance()->setRPT_LVL_ID(cutSpaces(pCEDRPTL->sRPT_LVL_ID,10));
   CRReportingLevelSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   if (strncmp(pCEDRPTL->sNEXT_ID + 2, "        ",8) != 0)
   {
      CRReportingLevelSegment::instance()->setNEXT_ID(cutSpaces(pCEDRPTL->sNEXT_ID,10));
      CRReportingLevelSegment::instance()->setNEXT_CUST_ID(Customer::instance()->getCUST_ID());
   }
   CRReportingLevelSegment::instance()->setRPT_LVL_NAME(cutSpaces(pCEDRPTL->sRPT_LVL_NAME,35));
   CRReportingLevelSegment::instance()->setADJUST_INST_ID(reformatINST_ID(pCEDRPTL->sADJUST_INST_ID));
   CRReportingLevelSegment::instance()->setADJUST_ACCT_ID(cutSpaces(pCEDRPTL->sADJUST_ACCT_ID,28));
   CRReportingLevelSegment::instance()->setONLINE_FEE_INST_ID(reformatINST_ID(pCEDRPTL->sONLINE_FEE_INST_ID));
   CRReportingLevelSegment::instance()->setONLINE_FEE_ACCT_ID(cutSpaces(pCEDRPTL->sONLINE_FEE_ACCT_ID,28));
   CRReportingLevelSegment::instance()->setFEE_BILL_INST_ID(reformatINST_ID(pCEDRPTL->sFEE_BILL_INST_ID));
   CRReportingLevelSegment::instance()->setFEE_BILL_ACCT_ID(cutSpaces(pCEDRPTL->sFEE_BILL_ACCT_ID,28));
   CRReportingLevelSegment::instance()->setSETL_INST_ID(reformatINST_ID(pCEDRPTL->sSETL_INST_ID));
   CRReportingLevelSegment::instance()->setSETL_ACCT_NO(cutSpaces(pCEDRPTL->sSETL_ACCT_NO,28));
   CRReportingLevelSegment::instance()->setCUTOFF_IND("2");
   CRReportingLevelSegment::instance()->setSERVICE_ID1(cutSpaces(pCEDRPTL->sServiceId1,28));
  //## end AdvantageCED::copyReportingLevel%38FE236F03D6.body
}

void AdvantageCED::copyTerminalDevice ()
{
  //## begin AdvantageCED::copyTerminalDevice%38FE23820030.body preserve=yes
   UseCase hUseCase("TANDEM","## AD08 TERMINAL DEVICE");
   hCEDTERM* pCEDTERM = (hCEDTERM*)m_pCursor;
   short siStatus = ntohs(pCEDTERM->siStatus);
   if (m_hStatus.find(siStatus) == m_hStatus.end())
      return;
   m_pFileSegment = CRDeviceSegment::instance();
   CRDeviceSegment::instance()->reset();
#ifdef MVS
   if (m_bAsciiInput)
   {
      CodeTable::translate(pCEDTERM->sDEVICE_ID,sizeof(pCEDTERM->sDEVICE_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermCardAcptID,((char*)(&pCEDTERM->siTermSpptsPartAppr) - pCEDTERM->sTermCardAcptID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermOutbndTermGrp,((char*)(&pCEDTERM->siTermAcqBranch) - pCEDTERM->sTermOutbndTermGrp),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sINST_ID,((char*)(&pCEDTERM->siTermOnUsOnlyTerm) - pCEDTERM->sINST_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(&pCEDTERM->cTermMaxDaysInDeposit,((char*)(&pCEDTERM->siTermAutoCallDev) - &pCEDTERM->cTermMaxDaysInDeposit),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermDfltCbaseList,((char*)(&pCEDTERM->siTermHowAttached) - pCEDTERM->sTermDfltCbaseList),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermHotcardID,sizeof(pCEDTERM->sTermHotcardID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(&pCEDTERM->cTermPinPadChar,((char*)(&pCEDTERM->siTermCommEncryptCd) - &pCEDTERM->cTermPinPadChar),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermEncryptKeysID,sizeof(pCEDTERM->sTermEncryptKeysID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermTotalsClass,sizeof(pCEDTERM->sTermTotalsClass),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermSummTotalsID,((char*)(&pCEDTERM->siTermTimeZoneOffHR) - pCEDTERM->sTermSummTotalsID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermCompntConfigID,((char*)(&pCEDTERM->siTermAuditDevInTH) - pCEDTERM->sTermCompntConfigID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sCUTOFF_TIME,((char*)(&pCEDTERM->siTermAckIfNoRespOpt) - pCEDTERM->sCUTOFF_TIME),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermAltTermLocList,((char*)(&pCEDTERM->siTermPromoType) - pCEDTERM->sTermAltTermLocList),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermNormalOpenHour,((char*)(&pCEDTERM->siTermSurchgNotify) - pCEDTERM->sTermNormalOpenHour),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermDeviceDependData,((char*)(&pCEDTERM->siTermDeviceOpt1) - pCEDTERM->sTermDeviceDependData),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermLogicalNetId,((char*)(&pCEDTERM->lTermLoadImgInfoGrpmod4) - pCEDTERM->sTermLogicalNetId),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sFillerB,sizeof(pCEDTERM->sFillerB),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermChangeNo,((char*)(&pCEDTERM->siTermAddedUser) - pCEDTERM->sTermChangeNo),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermDeletestatus,((char*)(&pCEDTERM->siTermUpdatePrgm) - pCEDTERM->sTermDeletestatus),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermUpdatedTstamp,sizeof(pCEDTERM->sTermUpdatedTstamp),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermDeletedTstamp,sizeof(pCEDTERM->sTermDeletedTstamp),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermRolledTstamp,sizeof(pCEDTERM->sTermRolledTstamp),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermClientID,sizeof(pCEDTERM->sTermRolledTstamp),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDTERM->sTermUserNote,sizeof(pCEDTERM->sTermUserNote),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!m_bAsciiInput)
   {
      CodeTable::translate(pCEDTERM->sDEVICE_ID,sizeof(pCEDTERM->sDEVICE_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermCardAcptID,((char*)(&pCEDTERM->siTermSpptsPartAppr) - pCEDTERM->sTermCardAcptID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermOutbndTermGrp,((char*)(&pCEDTERM->siTermAcqBranch) - pCEDTERM->sTermOutbndTermGrp),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sINST_ID,((char*)(&pCEDTERM->siTermOnUsOnlyTerm) - pCEDTERM->sINST_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(&pCEDTERM->cTermMaxDaysInDeposit,((char*)(&pCEDTERM->siTermAutoCallDev) - &pCEDTERM->cTermMaxDaysInDeposit),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermDfltCbaseList,((char*)(&pCEDTERM->siTermHowAttached) - pCEDTERM->sTermDfltCbaseList),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermHotcardID,sizeof(pCEDTERM->sTermHotcardID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(&pCEDTERM->cTermPinPadChar,((char*)(&pCEDTERM->siTermCommEncryptCd) - &pCEDTERM->cTermPinPadChar),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermEncryptKeysID,sizeof(pCEDTERM->sTermEncryptKeysID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermTotalsClass,sizeof(pCEDTERM->sTermTotalsClass),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermSummTotalsID,((char*)(&pCEDTERM->siTermTimeZoneOffHR) - pCEDTERM->sTermSummTotalsID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermCompntConfigID,((char*)(&pCEDTERM->siTermAuditDevInTH) - pCEDTERM->sTermCompntConfigID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sCUTOFF_TIME,((char*)(&pCEDTERM->siTermAckIfNoRespOpt) - pCEDTERM->sCUTOFF_TIME),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermAltTermLocList,((char*)(&pCEDTERM->siTermPromoType) - pCEDTERM->sTermAltTermLocList),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermNormalOpenHour,((char*)(&pCEDTERM->siTermSurchgNotify) - pCEDTERM->sTermNormalOpenHour),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermDeviceDependData,((char*)(&pCEDTERM->siTermDeviceOpt1) - pCEDTERM->sTermDeviceDependData),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermLogicalNetId,((char*)(&pCEDTERM->lTermLoadImgInfoGrpmod4) - pCEDTERM->sTermLogicalNetId),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sFillerB,sizeof(pCEDTERM->sFillerB),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermChangeNo,((char*)(&pCEDTERM->siTermAddedUser) - pCEDTERM->sTermChangeNo),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermDeletestatus,((char*)(&pCEDTERM->siTermUpdatePrgm) - pCEDTERM->sTermDeletestatus),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermUpdatedTstamp,sizeof(pCEDTERM->sTermUpdatedTstamp),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermDeletedTstamp,sizeof(pCEDTERM->sTermDeletedTstamp),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermRolledTstamp,sizeof(pCEDTERM->sTermRolledTstamp),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermClientID,sizeof(pCEDTERM->sTermRolledTstamp),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDTERM->sTermUserNote,sizeof(pCEDTERM->sTermUserNote),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   CRDeviceSegment::instance()->setDEVICE_ID(cutSpaces(pCEDTERM->sDEVICE_ID,8));
   string strTemp(pCEDTERM->sDEVICE_ID,8);
   map<string,string,less<string> >::iterator pVendor;
   pVendor = m_hVendors.find(strTemp);
   if (pVendor != m_hVendors.end())
      CRDeviceSegment::instance()->setVENDOR_MODEL((*pVendor).second);
   map<string, string, less<string> >::iterator pCircuitIDs;
   pCircuitIDs = m_hCircuitIDs.find(strTemp);
   if (pCircuitIDs != m_hCircuitIDs.end())
      CRDeviceSegment::instance()->setCIRCUIT_ID((*pCircuitIDs).second);
   CRDeviceSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   CRDeviceSegment::instance()->setRPT_LVL_ID(cutSpaces(pCEDTERM->sRPT_LVL_ID,10));
   CRDeviceSegment::instance()->setINST_ID(reformatINST_ID(pCEDTERM->sINST_ID));
   CRDeviceSegment::instance()->setBILL_INTERCHG_GRP(cutSpaces(pCEDTERM->sBILL_INTERCHG_GRP,2));
   CRDeviceSegment::instance()->setCOUNTRY(cutSpaces(pCEDTERM->sCOUNTRY,3));
   CRDeviceSegment::instance()->setCOUNTY(cutSpaces(pCEDTERM->sCOUNTY,3));
   CRDeviceSegment::instance()->setREGION(cutSpaces(pCEDTERM->sREGION,3));
   CRDeviceSegment::instance()->setPOSTAL_CODE(cutSpaces(pCEDTERM->sPOSTAL_CODE,10));
   CRDeviceSegment::instance()->setADDRESS(cutSpaces(pCEDTERM->sADDRESS,28));
   CRDeviceSegment::instance()->setCITY(cutSpaces(pCEDTERM->sCITY,27));
   CRDeviceSegment::instance()->setDEFAULT_CUR_CODE(cutSpaces(pCEDTERM->sDEFAULT_CUR_CODE,3));
   CRDeviceSegment::instance()->setPSEUDO_TERM_FLG("N");
   if (ntohs(pCEDTERM->siCUTOFF_IND) <= 2)
   {
      char szCUTOFF_IND[4] = {"010"};
      string strCUTOFF_IND(szCUTOFF_IND + ntohs(pCEDTERM->siCUTOFF_IND),1);
      CRDeviceSegment::instance()->setCUTOFF_IND(strCUTOFF_IND);
   }
   strTemp.assign(pCEDTERM->sCUTOFF_TIME,6);
   strTemp += strTemp[5] == '0' || strTemp[5] == ' ' ? "00" : "99";
   CRDeviceSegment::instance()->setCUTOFF_TIME(strTemp);
   strTemp.assign(pCEDTERM->sCUTOFF_START_TIME,6);
   strTemp += "00";
   CRDeviceSegment::instance()->setCUTOFF_START_TIME(strTemp);
   strTemp.assign(&pCEDTERM->cTermOperatingEnv,1);
   CRDeviceSegment::instance()->setTERM_OPERATING_ENV(strTemp);
   CRDeviceSegment::instance()->setNORMAL_OPEN_HOUR(cutSpaces(pCEDTERM->sTermNormalOpenHour,2));
   CRDeviceSegment::instance()->setNORMAL_CLOSE_HOUR(cutSpaces(pCEDTERM->sTermNormalCloseHour, 2));
   CRDeviceSegment::instance()->setREPORTING_REGION(cutSpaces(pCEDTERM->sTermRptingRegion, 8));
   CRDeviceSegment::instance()->setCUSTOM_DATA(cutSpaces(pCEDTERM->sTermCustomData, 25));
   char szTemp[PERCENTD];
   snprintf(szTemp,sizeof(szTemp),"%d",ntohs(pCEDTERM->siTermHowAttached));
   CRDeviceSegment::instance()->setHOW_TERM_ATTACHED(szTemp);
   if (ntohs(pCEDTERM->siTermSSGLoadData) <= 7)
   {
      snprintf(szTemp, sizeof(szTemp),"%d",ntohs(pCEDTERM->siTermSSGLoadData));
      CRDeviceSegment::instance()->setSSG_LOAD_DATA(szTemp);
   }
   snprintf(szTemp, sizeof(szTemp),"%04d",ntohs(pCEDTERM->siTermConnexOpt5));
   CRDeviceSegment::instance()->setMAX_SURCHARGE_AMOUNT(szTemp);
   CRDeviceSegment::instance()->setONLINE_FEE_GROUP(cutSpaces(pCEDTERM->sTermOnlineFeeGrp,8));
   CRDeviceSegment::instance()->setPOS_CRD_DAT_IN_CAP(cutSpaces(&pCEDTERM->cTermCardDataInputCap,1));
   CRDeviceSegment::instance()->setDELETE_STATUS(cutSpaces(pCEDTERM->sTermDeletestatus,2));
   char szTERM_BILLING_FLGS[32];
   TermBillingFlags(string((char*)&pCEDTERM->lTermBilling,4),szTERM_BILLING_FLGS);
   CRDeviceSegment::instance()->setTERM_BILLING_FLGS(cutSpaces(szTERM_BILLING_FLGS,32));
  //## end AdvantageCED::copyTerminalDevice%38FE23820030.body
}

void AdvantageCED::copyVoiceAuthDevice ()
{
  //## begin AdvantageCED::copyVoiceAuthDevice%38FE239202DC.body preserve=yes
   UseCase hUseCase("TANDEM","## AD09 VOICE AUTH DEVICE");
   hCEDVAET* pCEDVAET = (hCEDVAET*)m_pCursor;
   short siStatus = ntohs(pCEDVAET->siStatus);
   if (m_hStatus.find(siStatus) == m_hStatus.end())
      return;
   m_pFileSegment = CRDeviceSegment::instance();
   CRDeviceSegment::instance()->reset();
#ifdef MVS
   if (m_bAsciiInput)
   {
      CodeTable::translate(pCEDVAET->sDEVICE_ID,sizeof(pCEDVAET->sDEVICE_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDVAET->sVaetCardAcptID,((char*)(&pCEDVAET->siVaetSpptsPartAppr) - pCEDVAET->sVaetCardAcptID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDVAET->sVaetOutbndTermGrp,((char*)(&pCEDVAET->siVaetAcqBranch) - pCEDVAET->sVaetOutbndTermGrp),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDVAET->sINST_ID,((char*)(&pCEDVAET->siVaetOnUsOnlyTerm) - pCEDVAET->sINST_ID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDVAET->sDEFAULT_CUR_CODE,((char*)(&pCEDVAET->siVaetMaintBusDate) - pCEDVAET->sDEFAULT_CUR_CODE),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDVAET->sVaetTotalsClass,sizeof(pCEDVAET->sVaetTotalsClass),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDVAET->sVaetSummTotalsID,((char*)(&pCEDVAET->siVaetTimeZoneOffHR) - pCEDVAET->sVaetSummTotalsID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDVAET->sVaetSecondaryPost,sizeof(pCEDVAET->sVaetSecondaryPost),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCEDVAET->sCUTOFF_TIME,((char*)(&pCEDVAET->siVaetConnexOpt1) - pCEDVAET->sCUTOFF_TIME),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!m_bAsciiInput)
   {
      CodeTable::translate(pCEDVAET->sDEVICE_ID,sizeof(pCEDVAET->sDEVICE_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDVAET->sVaetCardAcptID,((char*)(&pCEDVAET->siVaetSpptsPartAppr) - pCEDVAET->sVaetCardAcptID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDVAET->sVaetOutbndTermGrp,((char*)(&pCEDVAET->siVaetAcqBranch) - pCEDVAET->sVaetOutbndTermGrp),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDVAET->sINST_ID,((char*)(&pCEDVAET->siVaetOnUsOnlyTerm) - pCEDVAET->sINST_ID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDVAET->sDEFAULT_CUR_CODE,((char*)(&pCEDVAET->siVaetMaintBusDate) - pCEDVAET->sDEFAULT_CUR_CODE),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDVAET->sVaetTotalsClass,sizeof(pCEDVAET->sVaetTotalsClass),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDVAET->sVaetSummTotalsID,((char*)(&pCEDVAET->siVaetTimeZoneOffHR) - pCEDVAET->sVaetSummTotalsID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDVAET->sVaetSecondaryPost,sizeof(pCEDVAET->sVaetSecondaryPost),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCEDVAET->sCUTOFF_TIME,((char*)(&pCEDVAET->siVaetConnexOpt1) - pCEDVAET->sCUTOFF_TIME),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   string strTemp;
   CRDeviceSegment::instance()->setDEVICE_ID(cutSpaces(pCEDVAET->sDEVICE_ID,8));
   CRDeviceSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   CRDeviceSegment::instance()->setRPT_LVL_ID(cutSpaces(pCEDVAET->sRPT_LVL_ID,10));
   CRDeviceSegment::instance()->setINST_ID(reformatINST_ID(pCEDVAET->sINST_ID));
   CRDeviceSegment::instance()->setBILL_INTERCHG_GRP(cutSpaces(pCEDVAET->sBILL_INTERCHG_GRP,2));
   CRDeviceSegment::instance()->setCOUNTRY(cutSpaces(pCEDVAET->sCOUNTRY,3));
   CRDeviceSegment::instance()->setCOUNTY(cutSpaces(pCEDVAET->sCOUNTY,3));
   CRDeviceSegment::instance()->setREGION(cutSpaces(pCEDVAET->sREGION,3));
   CRDeviceSegment::instance()->setPOSTAL_CODE(cutSpaces(pCEDVAET->sPOSTAL_CODE,10));
   CRDeviceSegment::instance()->setVENDOR_MODEL(cutSpaces(pCEDVAET->sVENDOR_MODEL,8));
   CRDeviceSegment::instance()->setADDRESS(cutSpaces(pCEDVAET->sADDRESS,28));
   CRDeviceSegment::instance()->setCITY(cutSpaces(pCEDVAET->sCITY,27));
   CRDeviceSegment::instance()->setDEFAULT_CUR_CODE(cutSpaces(pCEDVAET->sDEFAULT_CUR_CODE,3));
   if (ntohs(pCEDVAET->siCUTOFF_IND) <= 2)
   {
      char szCUTOFF_IND[4] = {"100"};
      string strCUTOFF_IND(szCUTOFF_IND + ntohs(pCEDVAET->siCUTOFF_IND),1);
      CRDeviceSegment::instance()->setCUTOFF_IND(strCUTOFF_IND);
   }
   strTemp.assign(pCEDVAET->sCUTOFF_TIME,6);
   strTemp += strTemp[5] == '0' || strTemp[5] == ' ' ? "00" : "99";
   CRDeviceSegment::instance()->setCUTOFF_TIME(strTemp);
   strTemp.assign(pCEDVAET->sCUTOFF_START_TIME,6);
   strTemp += "00";
   CRDeviceSegment::instance()->setCUTOFF_START_TIME(strTemp);
  //## end AdvantageCED::copyVoiceAuthDevice%38FE239202DC.body
}

bool AdvantageCED::read ()
{
  //## begin AdvantageCED::read%38FE23A603DF.body preserve=yes
   if (!m_pGenerationDataGroup)
   {
      m_pGenerationDataGroup = new GenerationDataGroup(Application::instance()->image(),Application::instance()->name(),getName().c_str(),true);
      m_iPass = 0;
      if (!m_pGenerationDataGroup->open())
         return false;
   }
#ifdef MVS
   m_bAsciiInput = false;
#else
   m_bAsciiInput = true;
#endif
   if (m_pFileSegment)
      m_pFileSegment->setPresence(false);
   m_pFileSegment = 0;
   while (m_pFileSegment == 0)
   {
      size_t lRecordLength = 0;
      if (!m_pGenerationDataGroup->read(m_psBuffer,8192,&lRecordLength))
      {
         if (m_iPass == 0)
         {
            m_pGenerationDataGroup->close();
            m_iPass = 1;
            continue;
         }
         else
         {
            m_iPass = 0;
            return false;
         }
      }
      hCED* pCED = (hCED*)m_psBuffer;
      m_pCursor = m_psBuffer + 7;
#ifdef MVS
      if (pCED->sType[0] != 'C')
         m_bAsciiInput = true;
      if (m_bAsciiInput)
         CodeTable::translate(pCED->sType,sizeof(pCED->sType),CodeTable::CX_ASCII_TO_EBCDIC);
#else
      if (pCED->sType[0] != 'C')
         m_bAsciiInput = false;
      if (!m_bAsciiInput)
         CodeTable::translate(pCED->sType,sizeof(pCED->sType),CodeTable::CX_EBCDIC_TO_ASCII);
#endif
      if (m_bV13Advantage)
         m_pCursor += 4; // skip over Advantage version #
      if (m_iPass == 0)
      {
         if (!strncmp(pCED->sType,"CEDPROC",7))
            copyProcessor();
         else
         if (!strncmp(pCED->sType,"CEDRPTL",7))
            copyReportingLevel();
      }
      else
      {
         if (!strncmp(pCED->sType,"CEDRPTL",7))
            copyReportingLevel();
         else
         if (!strncmp(pCED->sType,"CEDINST",7))
            copyInstitution();
         else
         if (!strncmp(pCED->sType,"CEDINTR",7))
            copyInterceptDevice();
         else
         if (!strncmp(pCED->sType,"CEDPRNT",7))
            copyPANMask();
         else
         if (!strncmp(pCED->sType,"CEDTERM",7))
            copyTerminalDevice();
         else
         if (!strncmp(pCED->sType,"CEDVAET",7))
            copyVoiceAuthDevice();
         else
         if (!strncmp(pCED->sType,"CEDPHYD",7))
            copyPhysicalDevice();
         else
         if (!strncmp(pCED->sType,"CEDDMAP",7))
            copyDataMap();
         else
         if (!strncmp(pCED->sType,"CEDCBAS",7))
            copyCardBase();
         else
         if (!strncmp(pCED->sType,"CEDDADV",7))
            copyDirectAttachedDevice();
      }
   }
   m_pFileSegment->setPresence(true);
   return true;
  //## end AdvantageCED::read%38FE23A603DF.body
}

string AdvantageCED::reformatINST_ID (const char* psINST_ID)
{
  //## begin AdvantageCED::reformatINST_ID%3922C7990239.body preserve=yes
   string strTemp;
   if (Customer::instance()->getCUST_CURRENCY_CODE() == "840"  &&
       memcmp(psINST_ID,"59",2) == 0  &&
       psINST_ID[10] != ' ')
      strTemp = cutSpaces(psINST_ID + 2,9);
   else
      strTemp = cutSpaces(psINST_ID,11);
   return strTemp;
  //## end AdvantageCED::reformatINST_ID%3922C7990239.body
}

void AdvantageCED::TermBillingFlags (const string& strFlags, char* psFlags)
{
  //## begin AdvantageCED::TermBillingFlags%6531658900C5.body preserve=yes
#include "CXODRU32.hpp"
   struct hTERM_BILLING_FLGS
   {
#ifdef _LITTLE_ENDIAN
      unsigned bAddTermBillingbit7 : 1;
      unsigned bAddTermBillingbit6 : 1;
      unsigned bAddTermBillingbit5 : 1;
      unsigned bAddTermBillingbit4 : 1;
      unsigned bAddTermBillingbit3 : 1;
      unsigned bAddTermBillingbit2 : 1;
      unsigned bAddTermBillingbit1 : 1;
      unsigned bAddTermBillingbit0 : 1;
      unsigned bAddTermBillingbit15 : 1;
      unsigned bAddTermBillingbit14 : 1;
      unsigned bAddTermBillingbit13 : 1;
      unsigned bAddTermBillingbit12 : 1;
      unsigned bAddTermBillingbit11 : 1;
      unsigned bAddTermBillingbit10 : 1;
      unsigned bAddTermBillingbit9 : 1;
      unsigned bAddTermBillingbit8 : 1;
      unsigned bAddTermBillingbit23 : 1;
      unsigned bAddTermBillingbit22 : 1;
      unsigned bAddTermBillingbit21 : 1;
      unsigned bAddTermBillingbit20 : 1;
      unsigned bAddTermBillingbit19 : 1;
      unsigned bAddTermBillingbit18 : 1;
      unsigned bAddTermBillingbit17 : 1;
      unsigned bAddTermBillingbit16 : 1;
      unsigned bAddTermBillingbit31 : 1;
      unsigned bAddTermBillingbit30 : 1;
      unsigned bAddTermBillingbit29 : 1;
      unsigned bAddTermBillingbit28 : 1;
      unsigned bAddTermBillingbit27 : 1;
      unsigned bAddTermBillingbit26 : 1;
      unsigned bAddTermBillingbit25 : 1;
      unsigned bAddTermBillingbit24 : 1;
 #else
      unsigned bAddTermBillingbit0 : 1;
      unsigned bAddTermBillingbit1 : 1;
      unsigned bAddTermBillingbit2 : 1;
      unsigned bAddTermBillingbit3 : 1;
      unsigned bAddTermBillingbit4 : 1;
      unsigned bAddTermBillingbit5 : 1;
      unsigned bAddTermBillingbit6 : 1;
      unsigned bAddTermBillingbit7 : 1;
      unsigned bAddTermBillingbit8 : 1;
      unsigned bAddTermBillingbit9 : 1;
      unsigned bAddTermBillingbit10 : 1;
      unsigned bAddTermBillingbit11 : 1;
      unsigned bAddTermBillingbit12 : 1;
      unsigned bAddTermBillingbit13 : 1;
      unsigned bAddTermBillingbit14 : 1;
      unsigned bAddTermBillingbit15 : 1;
      unsigned bAddTermBillingbit16 : 1;
      unsigned bAddTermBillingbit17 : 1;
      unsigned bAddTermBillingbit18 : 1;
      unsigned bAddTermBillingbit19 : 1;
      unsigned bAddTermBillingbit20 : 1;
      unsigned bAddTermBillingbit21 : 1;
      unsigned bAddTermBillingbit22 : 1;
      unsigned bAddTermBillingbit23 : 1;
      unsigned bAddTermBillingbit24 : 1;
      unsigned bAddTermBillingbit25 : 1;
      unsigned bAddTermBillingbit26 : 1;
      unsigned bAddTermBillingbit27 : 1;
      unsigned bAddTermBillingbit28 : 1;
      unsigned bAddTermBillingbit29 : 1;
      unsigned bAddTermBillingbit30 : 1;
      unsigned bAddTermBillingbit31 : 1;
#endif
   };
#include "CXODRU33.hpp"

memset(psFlags,'N',32);
hTERM_BILLING_FLGS* pFlags = (hTERM_BILLING_FLGS*)strFlags.data();
   if (pFlags->bAddTermBillingbit0)
      psFlags[0] = 'Y';
   if (pFlags->bAddTermBillingbit1)
      psFlags[1] = 'Y';
   if (pFlags->bAddTermBillingbit2)
      psFlags[2] = 'Y';
   if (pFlags->bAddTermBillingbit3)
      psFlags[3] = 'Y';
   if (pFlags->bAddTermBillingbit4)
      psFlags[4] = 'Y';
   if (pFlags->bAddTermBillingbit5)
      psFlags[5] = 'Y';
   if (pFlags->bAddTermBillingbit6)
      psFlags[6] = 'Y';
   if (pFlags->bAddTermBillingbit7)
      psFlags[7] = 'Y';
   if (pFlags->bAddTermBillingbit8)
      psFlags[8] = 'Y';
   if (pFlags->bAddTermBillingbit9)
      psFlags[9] = 'Y';
   if (pFlags->bAddTermBillingbit10)
      psFlags[10] = 'Y';
   if (pFlags->bAddTermBillingbit11)
      psFlags[11] = 'Y';
   if (pFlags->bAddTermBillingbit12)
      psFlags[12] = 'Y';
   if (pFlags->bAddTermBillingbit13)
      psFlags[13] = 'Y';
   if (pFlags->bAddTermBillingbit14)
      psFlags[14] = 'Y';
   if (pFlags->bAddTermBillingbit15)
      psFlags[15] = 'Y';
   if (pFlags->bAddTermBillingbit16)
      psFlags[16] = 'Y';
   if (pFlags->bAddTermBillingbit17)
      psFlags[17] = 'Y';
   if (pFlags->bAddTermBillingbit18)
      psFlags[18] = 'Y';
   if (pFlags->bAddTermBillingbit19)
      psFlags[19] = 'Y';
   if (pFlags->bAddTermBillingbit20)
      psFlags[20] = 'Y';
   if (pFlags->bAddTermBillingbit21)
      psFlags[21] = 'Y';
   if (pFlags->bAddTermBillingbit22)
      psFlags[22] = 'Y';
   if (pFlags->bAddTermBillingbit23)
      psFlags[23] = 'Y';
   if (pFlags->bAddTermBillingbit24)
      psFlags[24] = 'Y';
   if (pFlags->bAddTermBillingbit25)
      psFlags[25] = 'Y';
   if (pFlags->bAddTermBillingbit26)
      psFlags[26] = 'Y';
   if (pFlags->bAddTermBillingbit27)
      psFlags[27] = 'Y';
   if (pFlags->bAddTermBillingbit28)
      psFlags[28] = 'Y';
   if (pFlags->bAddTermBillingbit29)
      psFlags[29] = 'Y';
   if (pFlags->bAddTermBillingbit30)
      psFlags[30] = 'Y';
   if (pFlags->bAddTermBillingbit31)
      psFlags[31] = 'Y';
  //## end AdvantageCED::TermBillingFlags%6531658900C5.body
}

// Additional Declarations
  //## begin AdvantageCED%38FE1C28037D.declarations preserve=yes
  //## end AdvantageCED%38FE1C28037D.declarations

//## begin module%38FE1D6900CC.epilog preserve=yes
//## end module%38FE1D6900CC.epilog
