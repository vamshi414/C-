//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%461CA44A011D.cm preserve=no
//	$Date:   May 08 2007 03:22:10  $ $Author:   d01575  $
//	$Revision:   1.2  $
//## end module%461CA44A011D.cm

//## begin module%461CA44A011D.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%461CA44A011D.cp

//## Module: CXOSAC04%461CA44A011D; Package specification
//## Subsystem: AC%38FE1CA0036C
//## Source file: C:\Devel\Dn\Server\Application\AC\CXODAC04.hpp

#ifndef CXOSAC04_h
#define CXOSAC04_h 1

//## begin module%461CA44A011D.additionalIncludes preserve=no
//## end module%461CA44A011D.additionalIncludes

//## begin module%461CA44A011D.includes preserve=yes
//## end module%461CA44A011D.includes

#ifndef CXOSNC19_h
#include "CXODNC19.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class InstitutionBinSegment;
} // namespace entitysegment

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class VariableBlockFile;
} // namespace IF

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GenerationDataGroup;

} // namespace database

//## begin module%461CA44A011D.declarations preserve=no
//## end module%461CA44A011D.declarations

//## begin module%461CA44A011D.additionalDeclarations preserve=yes
//## end module%461CA44A011D.additionalDeclarations


//## begin AdvantageInstBIN%424952BF008C.preface preserve=yes
//## end AdvantageInstBIN%424952BF008C.preface

//## Class: AdvantageInstBIN%424952BF008C
//## Category: Platform \: eFunds Advantage::AdvantageCEDReader_CAT%38FE1927036D
//## Subsystem: AC%38FE1CA0036C
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%424953A20186;entitycommand::CRFile { -> F}
//## Uses: <unnamed>%424B920002AF;IF::VariableBlockFile { -> F}
//## Uses: <unnamed>%424B934C0119;entitysegment::InstitutionBinSegment { -> F}
//## Uses: <unnamed>%461DD72C0347;database::GenerationDataGroup { -> F}
//## Uses: <unnamed>%461DD8A5010A;process::Application { -> F}

class DllExport AdvantageInstBIN : public entitycommand::CRFile  //## Inherits: <unnamed>%424975580222
{
  //## begin AdvantageInstBIN%424952BF008C.initialDeclarations preserve=yes
  //## end AdvantageInstBIN%424952BF008C.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageInstBIN();

    //## Destructor (generated)
      virtual ~AdvantageInstBIN();


    //## Other Operations (specified)
      //## Operation: read%424952F8005D
      virtual bool read ();

    // Additional Public Declarations
      //## begin AdvantageInstBIN%424952BF008C.public preserve=yes
      //## end AdvantageInstBIN%424952BF008C.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageInstBIN%424952BF008C.protected preserve=yes
      //## end AdvantageInstBIN%424952BF008C.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageInstBIN%424952BF008C.private preserve=yes
      //## end AdvantageInstBIN%424952BF008C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CUST_ID%431305F60242
      //## begin AdvantageInstBIN::CUST_ID%431305F60242.attr preserve=no  private: string {U} 
      string m_strCUST_ID;
      //## end AdvantageInstBIN::CUST_ID%431305F60242.attr

    // Additional Implementation Declarations
      //## begin AdvantageInstBIN%424952BF008C.implementation preserve=yes
      //## end AdvantageInstBIN%424952BF008C.implementation

};

//## begin AdvantageInstBIN%424952BF008C.postscript preserve=yes
//## end AdvantageInstBIN%424952BF008C.postscript

//## begin module%461CA44A011D.epilog preserve=yes
//## end module%461CA44A011D.epilog


#endif
