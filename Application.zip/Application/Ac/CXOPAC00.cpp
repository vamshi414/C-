//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38FE1CF900F3.cm preserve=no
//	$Date:   Jul 26 2013 09:32:40  $ $Author:   e1009652  $
//	$Revision:   1.25  $
//## end module%38FE1CF900F3.cm

//## begin module%38FE1CF900F3.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%38FE1CF900F3.cp

//## Module: CXOPAC00%38FE1CF900F3; Package body
//## Subsystem: AC%38FE1CA0036C
//## Source file: C:\Devel\Dn\Server\Application\AC\CXOPAC00.cpp

//## begin module%38FE1CF900F3.additionalIncludes preserve=no
//## end module%38FE1CF900F3.additionalIncludes

//## begin module%38FE1CF900F3.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
//## end module%38FE1CF900F3.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSNC01_h
#include "CXODNC01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSAC04_h
#include "CXODAC04.hpp"
#endif
#ifndef CXOSAC02_h
#include "CXODAC02.hpp"
#endif
#ifndef CXOSNC19_h
#include "CXODNC19.hpp"
#endif
#ifndef CXOPAC00_h
#include "CXODAC00.hpp"
#endif


//## begin module%38FE1CF900F3.declarations preserve=no
//## end module%38FE1CF900F3.declarations

//## begin module%38FE1CF900F3.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new AdvantageCEDReader();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%38FE1CF900F3.additionalDeclarations


// Class AdvantageCEDReader 

AdvantageCEDReader::AdvantageCEDReader()
  //## begin AdvantageCEDReader::AdvantageCEDReader%38FE1BFD0064_const.hasinit preserve=no
      : m_pAdvantageInstBIN(0),
        m_pAdvantageCED(0),
        m_pCRFile(0)
  //## end AdvantageCEDReader::AdvantageCEDReader%38FE1BFD0064_const.hasinit
  //## begin AdvantageCEDReader::AdvantageCEDReader%38FE1BFD0064_const.initialization preserve=yes
  //## end AdvantageCEDReader::AdvantageCEDReader%38FE1BFD0064_const.initialization
{
  //## begin AdvantageCEDReader::AdvantageCEDReader%38FE1BFD0064_const.body preserve=yes
   memcpy(m_sID,"AC00",4);
  //## end AdvantageCEDReader::AdvantageCEDReader%38FE1BFD0064_const.body
}


AdvantageCEDReader::~AdvantageCEDReader()
{
  //## begin AdvantageCEDReader::~AdvantageCEDReader%38FE1BFD0064_dest.body preserve=yes
   delete m_pCRFile;
   delete m_pAdvantageInstBIN;
   delete m_pAdvantageCED;
  //## end AdvantageCEDReader::~AdvantageCEDReader%38FE1BFD0064_dest.body
}



//## Other Operations (implementation)
int AdvantageCEDReader::initialize ()
{
  //## begin AdvantageCEDReader::initialize%38FE202201BE.body preserve=yes
   // AD01: Operator_Starts_AdvantageCEDReader
   new dnplatform::DNPlatform();
   new segment::AuditEvent;
   int i = Application::initialize();
   UseCase hUseCase("TANDEM","## AD01 START AC");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   CRUpdateCommand::instance();
   Database::instance()->connect();
   string strRecord;
   if (Extract::instance()->getRecord("DFILES  CED     ",strRecord))
      m_pAdvantageCED = new AdvantageCED;
   if (Extract::instance()->getRecord("DFILES  BINLD   ",strRecord))
      m_pAdvantageInstBIN = new AdvantageInstBIN;
   if (Extract::instance()->getRecord("DFILES  CR      ",strRecord))
      m_pCRFile = new CRFile("CR");
   return 0;
  //## end AdvantageCEDReader::initialize%38FE202201BE.body
}

int AdvantageCEDReader::onReset (IF::Message& hMessage)
{
  //## begin AdvantageCEDReader::onReset%38FE202500B4.body preserve=yes
   // AD02: Operator_Resets_AdvantageCEDReader
   UseCase hUseCase("TANDEM","## AD02 RESET AC");
#ifdef MVS
   if (hMessage.context().subString(1,3) == "BIN")
   {
#endif
      if (m_pAdvantageInstBIN)
         m_pAdvantageInstBIN->process();
#ifdef MVS
      return 0;
   }
#endif

#ifdef MVS
   if (hMessage.context().subString(1,2) != "CR")
   {
#endif
      if (m_pAdvantageCED)
         m_pAdvantageCED->process();
#ifdef MVS
      return 0;
   }
#endif
   if (m_pCRFile)
      m_pCRFile->process();
   return 0;
  //## end AdvantageCEDReader::onReset%38FE202500B4.body
}

// Additional Declarations
  //## begin AdvantageCEDReader%38FE1BFD0064.declarations preserve=yes
  //## end AdvantageCEDReader%38FE1BFD0064.declarations

//## begin module%38FE1CF900F3.epilog preserve=yes
//## end module%38FE1CF900F3.epilog
