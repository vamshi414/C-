//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%38FE1CF70317.cm preserve=no
//	$Date:   Aug 20 2007 10:47:28  $ $Author:   D02405  $
//	$Revision:   1.18  $
//## end module%38FE1CF70317.cm

//## begin module%38FE1CF70317.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%38FE1CF70317.cp

//## Module: CXOPAC00%38FE1CF70317; Package specification
//## Subsystem: AC%38FE1CA0036C
//## Source file: C:\Devel\Dn\Server\Application\AC\CXODAC00.hpp

#ifndef CXOPAC00_h
#define CXOPAC00_h 1

//## begin module%38FE1CF70317.additionalIncludes preserve=no
//## end module%38FE1CF70317.additionalIncludes

//## begin module%38FE1CF70317.includes preserve=yes
//## end module%38FE1CF70317.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntityCommand_CAT%394E2706012A
namespace entitycommand {
class CRFile;
class CRUpdateCommand;
} // namespace entitycommand

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

class AdvantageInstBIN;
class AdvantageCED;
//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%38FE1CF70317.declarations preserve=no
//## end module%38FE1CF70317.declarations

//## begin module%38FE1CF70317.additionalDeclarations preserve=yes
//## end module%38FE1CF70317.additionalDeclarations


//## begin AdvantageCEDReader%38FE1BFD0064.preface preserve=yes
//## end AdvantageCEDReader%38FE1BFD0064.preface

//## Class: AdvantageCEDReader%38FE1BFD0064
//	<body>
//	<title>CG
//	<h1>AC
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server requires replicated
//	configuration information from the acquiring platform
//	switch database.
//	<p>
//	The EFD Advantage CED file (CF) is read by the EFD
//	Advantage CED Interface (<i>ca</i>CU) to update the Data
//	Navigator Configuration Repository (CR).
//	A new file should be copied to the DataNavigator Server
//	following the completion of any related maintenance to
//	the eFunds Advantage CED.
//	</p>
//	<img src=CXOCAC00.gif>
//	<h2>FO
//	<h3>Entity Tables
//	<p>
//	The EFD Advantage CED Interface populates the following
//	tables in the configuration repository:
//	<ul>
//	<li><i>qualify</i>.PROCESSOR
//	<li><i>qualify</i>.REPORTING_LVL
//	<li><i>qualify</i>.INSTITUTION
//	<li><i>qualify</i>.DEVICE
//	<li><i>qualify</i>.PAN_MASK
//	</ul>
//	<p>
//	After entities are added by the EFD Advantage CED
//	Interface, additional manual changes can be made using
//	the CR Client.
//	These tables are in the EFT-Entity Tables folder in the
//	CR Client for the DataNavigator Server.
//	<p>
//	Your DBA contact is notified of any new entities via an
//	email.
//	The Generic Configuration Interface service
//	documentation contains information on modifying the
//	email template.
//	</body>
//	<body>
//	<title>OG
//	<h1>AC
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server requires replicated
//	configuration information from the acquiring platform
//	switch database.
//	</p>
//	<img src=CXOOAC00.gif>
//	</body>
//## Category: Platform \: EFD Advantage::AdvantageCEDReader_CAT%38FE1927036D
//## Subsystem: AC%38FE1CA0036C
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..1



//## Uses: <unnamed>%3A01DF47034E;monitor::UseCase { -> F}
//## Uses: <unnamed>%3A24339203E7;IF::Message { -> F}
//## Uses: <unnamed>%3DC68553032C;database::Database { -> F}
//## Uses: <unnamed>%3DFDD2580203;entitycommand::CRUpdateCommand { -> F}
//## Uses: <unnamed>%40A27C8703D8;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%40A287730213;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%46C9AAF20290;IF::Extract { -> F}

class AdvantageCEDReader : public process::Application  //## Inherits: <unnamed>%38FE1C120173
{
  //## begin AdvantageCEDReader%38FE1BFD0064.initialDeclarations preserve=yes
  //## end AdvantageCEDReader%38FE1BFD0064.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageCEDReader();

    //## Destructor (generated)
      virtual ~AdvantageCEDReader();


    //## Other Operations (specified)
      //## Operation: initialize%38FE202201BE
      virtual int initialize ();

    // Additional Public Declarations
      //## begin AdvantageCEDReader%38FE1BFD0064.public preserve=yes
      //## end AdvantageCEDReader%38FE1BFD0064.public

  protected:

    //## Other Operations (specified)
      //## Operation: onReset%38FE202500B4
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AC
      //	<h2>CD
      //	<h3>Replicate Configuration
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>CU
      //	<h4>Description
      //	<p>
      //	The EFT platform configuration is replicated to the Data
      //	Navigator Configuration Repository
      //	</p>
      //	<h4>Schedule
      //	<p>
      //	The DataNavigator Server installation automatically sets
      //	up an event to perform this command at 05:00 AM.
      //	This time can be changed to coincide with the acquiring
      //	platform database maintenance schedule.
      //	Events are in the Event Management folder in the CR
      //	Client for the DataNavigator Server.
      //	</p>
      //	</body>
      //	<body>
      //	<title>OG
      //	<h1>AC
      //	<h2>CD
      //	<h3>Copy eFunds Advantage CED to DataNavigator CR
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>CU
      //	<h4>Description
      //	<p>
      //	The eFunds Advantage CED Interface services reads an e
      //	Funds Advantage CED file and updates the PROCESSOR,
      //	INSTITUTION, REPORTING_LVL, DEVICE and PAN_MASK tables
      //	in the DataNavigator CR.
      //	</p>
      //	</body>
      virtual int onReset (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin AdvantageCEDReader%38FE1BFD0064.protected preserve=yes
      //## end AdvantageCEDReader%38FE1BFD0064.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageCEDReader%38FE1BFD0064.private preserve=yes
      //## end AdvantageCEDReader%38FE1BFD0064.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: EFD Advantage::AdvantageCEDReader_CAT::<unnamed>%461C9A3B0358
      //## Role: AdvantageCEDReader::<m_pAdvantageInstBIN>%461C9A3C024E
      //## begin AdvantageCEDReader::<m_pAdvantageInstBIN>%461C9A3C024E.role preserve=no  public: AdvantageInstBIN { -> RFHgN}
      AdvantageInstBIN *m_pAdvantageInstBIN;
      //## end AdvantageCEDReader::<m_pAdvantageInstBIN>%461C9A3C024E.role

      //## Association: Platform \: EFD Advantage::AdvantageCEDReader_CAT::<unnamed>%461C9B250393
      //## Role: AdvantageCEDReader::<m_pAdvantageCED>%461C9B26025A
      //## begin AdvantageCEDReader::<m_pAdvantageCED>%461C9B26025A.role preserve=no  public: AdvantageCED { -> RFHgN}
      AdvantageCED *m_pAdvantageCED;
      //## end AdvantageCEDReader::<m_pAdvantageCED>%461C9B26025A.role

      //## Association: Platform \: EFD Advantage::AdvantageCEDReader_CAT::<unnamed>%461C9CBA0385
      //## Role: AdvantageCEDReader::<m_pCRFile>%461C9CBB020E
      //## begin AdvantageCEDReader::<m_pCRFile>%461C9CBB020E.role preserve=no  public: entitycommand::CRFile { -> RFHgN}
      entitycommand::CRFile *m_pCRFile;
      //## end AdvantageCEDReader::<m_pCRFile>%461C9CBB020E.role

    // Additional Implementation Declarations
      //## begin AdvantageCEDReader%38FE1BFD0064.implementation preserve=yes
      //## end AdvantageCEDReader%38FE1BFD0064.implementation

};

//## begin AdvantageCEDReader%38FE1BFD0064.postscript preserve=yes
//## end AdvantageCEDReader%38FE1BFD0064.postscript

//## begin module%38FE1CF70317.epilog preserve=yes
//## end module%38FE1CF70317.epilog


#endif
