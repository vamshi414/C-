//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%38FE1D67026E.cm preserve=no
//## end module%38FE1D67026E.cm

//## begin module%38FE1D67026E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%38FE1D67026E.cp

//## Module: CXOSAC02%38FE1D67026E; Package specification
//## Subsystem: AC%38FE1CA0036C
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Ac\CXODAC02.hpp

#ifndef CXOSAC02_h
#define CXOSAC02_h 1

//## begin module%38FE1D67026E.additionalIncludes preserve=no
//## end module%38FE1D67026E.additionalIncludes

//## begin module%38FE1D67026E.includes preserve=yes
// $Date:   Dec 28 2020 01:32:26  $ $Author:   E5350313  $ $Revision:   1.17  $
#include <map>
#include <set>
//## end module%38FE1D67026E.includes

#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSNC19_h
#include "CXODNC19.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class CRInstitutionSegment;
class CRPanMaskSegment;
class CRProcessorSegment;
class CRReportingLevelSegment;
class Customer;
class CRDeviceSegment;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class IString;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class VariableBlockFile;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GenerationDataGroup;

} // namespace database

//## begin module%38FE1D67026E.declarations preserve=no
//## end module%38FE1D67026E.declarations

//## begin module%38FE1D67026E.additionalDeclarations preserve=yes
//## end module%38FE1D67026E.additionalDeclarations


//## begin AdvantageCED%38FE1C28037D.preface preserve=yes
//## end AdvantageCED%38FE1C28037D.preface

//## Class: AdvantageCED%38FE1C28037D
//	<body>
//	<title>CG
//	<h1>AC
//	<h2>FI
//	<h3>FIS Connex on HP CED
//	<p>
//	The FIS Connex on HP CED file must be transmitted from
//	your HP NonStop switch platform to the DataNavigator
//	server.
//	The FIS Connex on HP CED Interface service reads the
//	file:
//	<ul>
//	<li><i>node001\custqual</i>\Pending\*CED.txt
//	</ul>
//	<p>
//	The following records are replicated:
//	<ul>
//	<li>CEDINST - Institution
//	<li>CEDINTR - Intercept Device
//	<li>CEDPRNT - PAN Mask
//	<li>CEDPROC - Processor
//	<li>CEDRPTL - Reporting Level
//	<li>CEDTERM - Terminal Device
//	<li>CEDVAET - Voice Authorization Device
//	<li>CEDPHYD - Physical Device
//	</ul>
//	New files are automatically detected within one minute
//	of arrival in the Pending folder. After processing the
//	file, the FIS Connex on HP CED Interface moves the file
//	to the Complete folder:
//	<ul>
//	<li><i>node001\custqual</i>\Complete
//	</ul>
//	<p>
//	The Connex on HP utility UnloadDB can be used to
//	transfer the CED file from HP NonStop to your windows
//	workstation.
//	You should be logged on to the HP NonStop with the
//	database userid and password at a TACL (command
//	interpreter) prompt:
//	<ul>
//	<li>1> UNLOADDB
//	</ul>
//	<p>
//	This will start an interactive session in UnloadDB.
//	Use the command "OUTFILE" to specify a target dataset.
//	This file will be created as an Enscribe entry-sequenced
//	file that contains IBM variable-blocked formatted
//	records.
//	<ul>
//	<li>UnloadDB 1> OUTFILE $DISK.SUBVOL.FILE1
//	</ul>
//	<p>
//	Fill in the correct values for disk, subvolume and the
//	filename of your choice.
//	You can delete this file later, so feel free to put it
//	anywhere.
//	<p>
//	Use the UnloadDB command "UNLOAD" to create the file and
//	populate it with data.
//	If you run in to a problem with size (error 45) you may
//	have to specify additional extents when you execute the
//	OUTFILE command.
//	Use "HELP OUTFILE" for additional parameters.
//	In my test switch, the default size was sufficient.
//	<ul>
//	<li>UnloadDB 2> UNLOAD
//	</ul>
//	<p>
//	Assuming everything went okay so far, exit UnloadDB and
//	tell TACL to move to the location where you created
//	FILE1:
//	<ul>
//	<li>UnloadDB 3> EXIT
//	<li>2> VOLUME $DISK.SUBVOL
//	</ul>
//	<p>
//	The next step is to convert the data from an Enscribe
//	structured file in to the unstructured format that the
//	Windows workstation expects.
//	We will use the File Utility Program to strip off the
//	Enscribe overhead.
//	First, create an unstructured file.
//	Next, copy the data from the first file to the second.
//	FUP will use the Enscribe overhead to read the data:
//	<ul>
//	<li>3> FUP CREATE FILE2, EXT (10,100)
//	</ul>
//	<p>
//	The default format is "U" (unstructured) but the default
//	extent size (2,2) will be too small.
//	Use FUP again to copy the data from the first file to
//	the second:
//	<ul>
//	<li>4> FUP COPY FILE1, FILE2, RECIN 4096, RECOUT 4096,
//	PAD 0
//	</ul>
//	<p>
//	4096 is the maximum buffer size that FUP can handle.
//	It will adjust down since the actual records are smaller.
//	<p>
//	Next, you need to move FILE2 to your Windows workstation.
//	<p>
//	Start a Command Prompt window.
//	Change to the directory where you want to receive the
//	file:
//	<ul>
//	<li>C:\>cd <i>node001\custqual</i>\Pending
//	</ul>
//	<p>
//	Start the FTP client and connect to the HP NonStop where
//	you created FILE2:
//	<ul>
//	<li>C:\<i>node001\custqual</i>\Pending>ftp
//	111.222.333.444
//	</ul>
//	<p>
//	Log on using the same userid and password you used to
//	log on to the TACL.
//	You should get a message that says "GUARDIAN API
//	enabled."
//	If instead you get a message that says "OSS API enabled"
//	issue the command "QUOTE GUARDIAN".
//	<p>
//	Change the location of the FTP server on the HP NonStop
//	to the location where you created FILE2:
//	<ul>
//	<li>ftp> cd $DISK.SUBVOL
//	</ul>
//	<p>
//	Set the transfer parameters to binary, hash and get the
//	file to a name that matches *CED.txt:
//	<ul>
//	<li>ftp> binary
//	<li>ftp> hash
//	<li>ftp> get FILE2 2013-01-10~CED.txt
//	<li>ftp> bye
//	</ul>
//	<p>
//	Back on the HP NonStop, don't forget to delete the
//	temporary files you created.
//	At the TACL prompt, issue PURGE instructions:
//	<ul>
//	<li>5> PURGE FILE1
//	<li>6> PURGE FILE2
//	</ul>
//	<p>
//
//	</body>
//## Category: Platform \: FIS Connex on HP::AdvantageCEDReader_CAT%38FE1927036D
//## Subsystem: AC%38FE1CA0036C
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%38FE21D80128;entitysegment::CRDeviceSegment { -> F}
//## Uses: <unnamed>%38FE21DB032B;entitysegment::CRInstitutionSegment { -> F}
//## Uses: <unnamed>%38FE21DF00F6;entitysegment::CRPanMaskSegment { -> F}
//## Uses: <unnamed>%38FE21E3000B;entitysegment::CRProcessorSegment { -> F}
//## Uses: <unnamed>%38FE21E502C1;entitysegment::CRReportingLevelSegment { -> F}
//## Uses: <unnamed>%392AA0E5014A;IF::CodeTable { -> F}
//## Uses: <unnamed>%3969C742018F;IF::Extract { -> F}
//## Uses: <unnamed>%3A393C6B00A8;monitor::UseCase { -> F}
//## Uses: <unnamed>%3DDEA65102BF;entitysegment::Customer { -> F}
//## Uses: <unnamed>%3DEB7718033C;IF::VariableBlockFile { -> F}
//## Uses: <unnamed>%461CA7B6030D;database::GenerationDataGroup { -> F}
//## Uses: <unnamed>%461CA7DA0261;process::Application { -> F}
//## Uses: <unnamed>%461CA80D0178;reusable::IString { -> F}

class AdvantageCED : public entitycommand::CRFile  //## Inherits: <unnamed>%3DDE8D5700FA
{
  //## begin AdvantageCED%38FE1C28037D.initialDeclarations preserve=yes
  //## end AdvantageCED%38FE1C28037D.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageCED();

    //## Destructor (generated)
      virtual ~AdvantageCED();


    //## Other Operations (specified)
      //## Operation: read%38FE23A603DF
      bool read ();

    // Additional Public Declarations
      //## begin AdvantageCED%38FE1C28037D.public preserve=yes
      //## end AdvantageCED%38FE1C28037D.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageCED%38FE1C28037D.protected preserve=yes
      //## end AdvantageCED%38FE1C28037D.protected

  private:

    //## Other Operations (specified)
      //## Operation: copyCardBase%5760197A0378
      void copyCardBase ();

      //## Operation: copyDataMap%5759DA0D02A2
      void copyDataMap ();

      //## Operation: copyDirectAttachedDevice%65316712028F
      void copyDirectAttachedDevice ();

      //## Operation: copyInstitution%38FE234C0187
      void copyInstitution ();

      //## Operation: copyInterceptDevice%38FE235201E0
      void copyInterceptDevice ();

      //## Operation: copyPANMask%38FE235F02ED
      void copyPANMask ();

      //## Operation: copyPhysicalDevice%39C64E0F02B1
      void copyPhysicalDevice ();

      //## Operation: copyProcessor%38FE236B03E4
      void copyProcessor ();

      //## Operation: copyReportingLevel%38FE236F03D6
      void copyReportingLevel ();

      //## Operation: copyTerminalDevice%38FE23820030
      void copyTerminalDevice ();

      //## Operation: copyVoiceAuthDevice%38FE239202DC
      void copyVoiceAuthDevice ();

      //## Operation: reformatINST_ID%3922C7990239
      reusable::string reformatINST_ID (const char* psINST_ID);

      //## Operation: TermBillingFlags%6531658900C5
      void TermBillingFlags (const string& strFlags, char* psFlags);

    // Additional Private Declarations
      //## begin AdvantageCED%38FE1C28037D.private preserve=yes
      //## end AdvantageCED%38FE1C28037D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: AsciiInput%39253A7903C9
      //## begin AdvantageCED::AsciiInput%39253A7903C9.attr preserve=no  private: bool {U} false
      bool m_bAsciiInput;
      //## end AdvantageCED::AsciiInput%39253A7903C9.attr

      //## Attribute: Cursor%3DDE9E7801B5
      //## begin AdvantageCED::Cursor%3DDE9E7801B5.attr preserve=no  private: char* {V} 0
      char* m_pCursor;
      //## end AdvantageCED::Cursor%3DDE9E7801B5.attr

      //## Attribute: DataBuffer%38FE224000E1
      //## begin AdvantageCED::DataBuffer%38FE224000E1.attr preserve=no  private: char* {U} 0
      char* m_pDataBuffer;
      //## end AdvantageCED::DataBuffer%38FE224000E1.attr

      //## Attribute: Pass%3DFDCF89002E
      //## begin AdvantageCED::Pass%3DFDCF89002E.attr preserve=no  private: int {V} 0
      int m_iPass;
      //## end AdvantageCED::Pass%3DFDCF89002E.attr

      //## Attribute: RecordLength%392D136C03DF
      //## begin AdvantageCED::RecordLength%392D136C03DF.attr preserve=no  private: int {U} 0
      int m_lRecordLength;
      //## end AdvantageCED::RecordLength%392D136C03DF.attr

      //## Attribute: Status%514BB9EF0271
      //## begin AdvantageCED::Status%514BB9EF0271.attr preserve=no  private: set <short>  {U} 
      set <short>  m_hStatus;
      //## end AdvantageCED::Status%514BB9EF0271.attr

      //## Attribute: V13Advantage%3923F30D0390
      //## begin AdvantageCED::V13Advantage%3923F30D0390.attr preserve=no  private: bool {U} true
      bool m_bV13Advantage;
      //## end AdvantageCED::V13Advantage%3923F30D0390.attr

      //## Attribute: Vendors%39C63A270169
      //## begin AdvantageCED::Vendors%39C63A270169.attr preserve=no  private: map<string, string, less<string> > {U} 
      map<string, string, less<string> > m_hVendors;
      //## end AdvantageCED::Vendors%39C63A270169.attr

    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AdvantageCEDReader_CAT::<unnamed>%461CA8D70217
      //## Role: AdvantageCED::<m_hDateTime>%461CA8D800DE
      //## begin AdvantageCED::<m_hDateTime>%461CA8D800DE.role preserve=no  public: IF::DateTime { -> VHgN}
      IF::DateTime m_hDateTime;
      //## end AdvantageCED::<m_hDateTime>%461CA8D800DE.role

    // Additional Implementation Declarations
      //## begin AdvantageCED%38FE1C28037D.implementation preserve=yes
      map<string, string, less<string> > m_hCircuitIDs;
      //## end AdvantageCED%38FE1C28037D.implementation
};

//## begin AdvantageCED%38FE1C28037D.postscript preserve=yes
//## end AdvantageCED%38FE1C28037D.postscript

//## begin module%38FE1D67026E.epilog preserve=yes
//## end module%38FE1D67026E.epilog


#endif
