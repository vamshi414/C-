//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%461CA44C00DF.cm preserve=no
//	$Date:   May 13 2020 12:53:50  $ $Author:   e1009510  $
//	$Revision:   1.9  $
//## end module%461CA44C00DF.cm

//## begin module%461CA44C00DF.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%461CA44C00DF.cp

//## Module: CXOSAC04%461CA44C00DF; Package body
//## Subsystem: AC%38FE1CA0036C
//## Source file: C:\Devel\Dn\Server\Application\AC\CXOSAC04.cpp

//## begin module%461CA44C00DF.additionalIncludes preserve=no
//## end module%461CA44C00DF.additionalIncludes

//## begin module%461CA44C00DF.includes preserve=yes
#include "CXODAC03.hpp"
#ifdef _WIN32
#include <winsock2.h>
#endif
//## end module%461CA44C00DF.includes

#ifndef CXOSNC19_h
#include "CXODNC19.hpp"
#endif
#ifndef CXOSIF41_h
#include "CXODIF41.hpp"
#endif
#ifndef CXOSNS25_h
#include "CXODNS25.hpp"
#endif
#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSAC04_h
#include "CXODAC04.hpp"
#endif


//## begin module%461CA44C00DF.declarations preserve=no
//## end module%461CA44C00DF.declarations

//## begin module%461CA44C00DF.additionalDeclarations preserve=yes
//## end module%461CA44C00DF.additionalDeclarations


// Class AdvantageInstBIN 

AdvantageInstBIN::AdvantageInstBIN()
  //## begin AdvantageInstBIN::AdvantageInstBIN%424952BF008C_const.hasinit preserve=no
  //## end AdvantageInstBIN::AdvantageInstBIN%424952BF008C_const.hasinit
  //## begin AdvantageInstBIN::AdvantageInstBIN%424952BF008C_const.initialization preserve=yes
  :CRFile("BINLD")
  //## end AdvantageInstBIN::AdvantageInstBIN%424952BF008C_const.initialization
{
  //## begin AdvantageInstBIN::AdvantageInstBIN%424952BF008C_const.body preserve=yes
   m_bUpdate = false;
   memcpy(m_sID,"AC04",4);
  //## end AdvantageInstBIN::AdvantageInstBIN%424952BF008C_const.body
}


AdvantageInstBIN::~AdvantageInstBIN()
{
  //## begin AdvantageInstBIN::~AdvantageInstBIN%424952BF008C_dest.body preserve=yes
  //## end AdvantageInstBIN::~AdvantageInstBIN%424952BF008C_dest.body
}



//## Other Operations (implementation)
bool AdvantageInstBIN::read ()
{
  //## begin AdvantageInstBIN::read%424952F8005D.body preserve=yes
   // AD02: Operator_Resets_AdvantageCEDReader
   if (!m_pGenerationDataGroup)
   {
      m_pGenerationDataGroup = new GenerationDataGroup(Application::instance()->image(),
                                             Application::instance()->name(),
                                             getName().c_str());
      if(!m_pGenerationDataGroup->open())
         return false;
   }
   if (m_pFileSegment)
      m_pFileSegment->setPresence(false);
   m_pFileSegment = 0;
   while (m_pFileSegment == 0)
   {
      size_t lRecordLength = 0;
      if (m_pGenerationDataGroup->read(m_psBuffer,sizeof(hCEDUnLoadHeader)+1,&lRecordLength))
      {
         if(!memcmp(m_psBuffer,"000000",6))
         {
            hCEDUnLoadHeader* pTypeHeader = (hCEDUnLoadHeader*)m_psBuffer;
            m_strCUST_ID.assign(pTypeHeader->sSwitchId,4);
         }
         else if(!memcmp(m_psBuffer,"999999",6))
         {
            hCEDUnLoadTrailer* pTypeTrailer = (hCEDUnLoadTrailer*)m_psBuffer;
            return false;
         }
         else
         {
            hCEDUnLoadDetail* pTypeDetail = (hCEDUnLoadDetail*)m_psBuffer;
            m_pFileSegment = InstitutionBinSegment::instance();
            InstitutionBinSegment::instance()->setCUST_ID(m_strCUST_ID);
            InstitutionBinSegment::instance()->setINST_ID(cutSpaces(pTypeDetail->sRptInstId,9));
            InstitutionBinSegment::instance()->setBIN(cutSpaces(pTypeDetail->sPrfx,atoi(cutSpaces(pTypeDetail->sPrfxlen,2).c_str())));
            InstitutionBinSegment::instance()->setCRD_PROD_CD_FLG("B");
            InstitutionBinSegment::instance()->setNET_ID("MCI");
            InstitutionBinSegment::instance()->setCC_CHANGE_GRP_ID("~NULL!");
            m_pFileSegment->setPresence(true);
         }
      }
      else
         return false;
   }
   return true;
  //## end AdvantageInstBIN::read%424952F8005D.body
}

// Additional Declarations
  //## begin AdvantageInstBIN%424952BF008C.declarations preserve=yes
  //## end AdvantageInstBIN%424952BF008C.declarations

//## begin module%461CA44C00DF.epilog preserve=yes
//## end module%461CA44C00DF.epilog
