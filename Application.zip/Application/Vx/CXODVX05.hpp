//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%530511260169.cm preserve=no
//	$Date:   Aug 27 2015 14:39:52  $ $Author:   e1009591  $
//	$Revision:   1.1  $
//## end module%530511260169.cm

//## begin module%530511260169.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%530511260169.cp

//## Module: CXOSVX05%530511260169; Package specification
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R003\Windows\Build\Dn\Server\Application\Vx\CXODVX05.hpp

#ifndef CXOSVX05_h
#define CXOSVX05_h 1

//## begin module%530511260169.additionalIncludes preserve=no
//## end module%530511260169.additionalIncludes

//## begin module%530511260169.includes preserve=yes
//## end module%530511260169.includes

#ifndef CXOSVX02_h
#include "CXODVX02.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ImportReportAuditSegment;

} // namespace segment

//## begin module%530511260169.declarations preserve=no
//## end module%530511260169.declarations

//## begin module%530511260169.additionalDeclarations preserve=yes
//## end module%530511260169.additionalDeclarations


//## begin BAMSUploadFile%5305100E0305.preface preserve=yes
//## end BAMSUploadFile%5305100E0305.preface

//## Class: BAMSUploadFile%5305100E0305
//## Category: DataNavigator Foundation::Application::VROLInterface_CAT%4C2B5E9102E8
//## Subsystem: VX%4C2B63AB026E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%531E15D9013A;segment::ImportReportAuditSegment { -> F}
//## Uses: <unnamed>%531E15DD007A;IF::FlatFile { -> F}
//## Uses: <unnamed>%531E15DF02DC;timer::Clock { -> F}
//## Uses: <unnamed>%531E15E30092;IF::Trace { -> F}

class DllExport BAMSUploadFile : public UploadFile  //## Inherits: <unnamed>%531E15D5022D
{
  //## begin BAMSUploadFile%5305100E0305.initialDeclarations preserve=yes
  //## end BAMSUploadFile%5305100E0305.initialDeclarations

  public:
    //## Constructors (generated)
      BAMSUploadFile();

    //## Destructor (generated)
      virtual ~BAMSUploadFile();


    //## Other Operations (specified)
      //## Operation: buildFile%531E1623012B
      virtual string buildFile (char& cStatus, const string& strFilename);

      //## Operation: execute%55C8BAF1002C
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: rebuildBAMSXML%531E16230151
      bool rebuildBAMSXML (IF::FlatFile& hInFile, const string& strOutputXMLFile);

      //## Operation: zipBAMSImages%531E16230154
      bool zipBAMSImages ();

    // Additional Public Declarations
      //## begin BAMSUploadFile%5305100E0305.public preserve=yes
      //## end BAMSUploadFile%5305100E0305.public

  protected:
    // Additional Protected Declarations
      //## begin BAMSUploadFile%5305100E0305.protected preserve=yes
      //## end BAMSUploadFile%5305100E0305.protected

  private:
    // Additional Private Declarations
      //## begin BAMSUploadFile%5305100E0305.private preserve=yes
      //## end BAMSUploadFile%5305100E0305.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin BAMSUploadFile%5305100E0305.implementation preserve=yes
   		map<string,pair<string,string>,less<string> > m_hImage;
      //## end BAMSUploadFile%5305100E0305.implementation
};

//## begin BAMSUploadFile%5305100E0305.postscript preserve=yes
//## end BAMSUploadFile%5305100E0305.postscript

//## begin module%530511260169.epilog preserve=yes
//## end module%530511260169.epilog


#endif
