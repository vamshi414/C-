//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5612E36103D5.cm preserve=no
//	$Date:   Oct 21 2015 10:54:32  $ $Author:   e1009591  $
//	$Revision:   1.0  $
//## end module%5612E36103D5.cm

//## begin module%5612E36103D5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5612E36103D5.cp

//## Module: CXOSVX13%5612E36103D5; Package specification
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R011\Windows\Build\Dn\Server\Application\Vx\CXODVX13.hpp

#ifndef CXOSVX13_h
#define CXOSVX13_h 1

//## begin module%5612E36103D5.additionalIncludes preserve=no
//## end module%5612E36103D5.additionalIncludes

//## begin module%5612E36103D5.includes preserve=yes
//## end module%5612E36103D5.includes

#ifndef CXOSVX02_h
#include "CXODVX02.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class ImportAuditSegment;
} // namespace emssegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
class Trace;
class Extract;

} // namespace IF

//## begin module%5612E36103D5.declarations preserve=no
//## end module%5612E36103D5.declarations

//## begin module%5612E36103D5.additionalDeclarations preserve=yes
//## end module%5612E36103D5.additionalDeclarations


//## begin EncryptDocuments%5612E3080174.preface preserve=yes
//## end EncryptDocuments%5612E3080174.preface

//## Class: EncryptDocuments%5612E3080174
//## Category: DataNavigator Foundation::Application::VROLInterface_CAT%4C2B5E9102E8
//## Subsystem: VX%4C2B63AB026E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5612E411022E;IF::Trace { -> F}
//## Uses: <unnamed>%5613D2C7014D;IF::FlatFile { -> F}
//## Uses: <unnamed>%5613D2CA0144;IF::Extract { -> F}
//## Uses: <unnamed>%5613D310031F;emssegment::ImportAuditSegment { -> F}
//## Uses: <unnamed>%5613D6B500E4;reusable::Buffer { -> F}

class DllExport EncryptDocuments : public UploadFile  //## Inherits: <unnamed>%5612E40301B7
{
  //## begin EncryptDocuments%5612E3080174.initialDeclarations preserve=yes
  //## end EncryptDocuments%5612E3080174.initialDeclarations

  public:
    //## Constructors (generated)
      EncryptDocuments();

    //## Destructor (generated)
      virtual ~EncryptDocuments();


    //## Other Operations (specified)
      //## Operation: createFolder%5613EF5B025A
      bool createFolder (const string& strFolder);

      //## Operation: execute%5612E45D029C
      virtual bool execute ();

      //## Operation: processENCRYPT%5613CCC80204
      bool processENCRYPT (char& cStatus);

    // Additional Public Declarations
      //## begin EncryptDocuments%5612E3080174.public preserve=yes
      //## end EncryptDocuments%5612E3080174.public

  protected:
    // Additional Protected Declarations
      //## begin EncryptDocuments%5612E3080174.protected preserve=yes
      //## end EncryptDocuments%5612E3080174.protected

  private:
    // Additional Private Declarations
      //## begin EncryptDocuments%5612E3080174.private preserve=yes
      vector<string> m_hEncrypt;
      //## end EncryptDocuments%5612E3080174.private
  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Customer%5613D45E00A0
      //## begin EncryptDocuments::Customer%5613D45E00A0.attr preserve=no  private: string {U} 
      string m_strCustomer;
      //## end EncryptDocuments::Customer%5613D45E00A0.attr

      //## Attribute: EntityFolder%5613D45E00A2
      //## begin EncryptDocuments::EntityFolder%5613D45E00A2.attr preserve=no  private: string {U} 
      string m_strEntityFolder;
      //## end EncryptDocuments::EntityFolder%5613D45E00A2.attr

      //## Attribute: HeaderFile%5613D45E00A4
      //## begin EncryptDocuments::HeaderFile%5613D45E00A4.attr preserve=no  private: string {U} 
      string m_strHeaderFile;
      //## end EncryptDocuments::HeaderFile%5613D45E00A4.attr

      //## Attribute: MainFile%5613EE3D0356
      //## begin EncryptDocuments::MainFile%5613EE3D0356.attr preserve=no  private: string {U} 
      string m_strMainFile;
      //## end EncryptDocuments::MainFile%5613EE3D0356.attr

    // Additional Implementation Declarations
      //## begin EncryptDocuments%5612E3080174.implementation preserve=yes
      //## end EncryptDocuments%5612E3080174.implementation

};

//## begin EncryptDocuments%5612E3080174.postscript preserve=yes
//## end EncryptDocuments%5612E3080174.postscript

//## begin module%5612E36103D5.epilog preserve=yes
//## end module%5612E36103D5.epilog


#endif
