//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%530D1B65018A.cm preserve=no
//	$Date:   Aug 27 2015 14:40:08  $ $Author:   e1009591  $
//	$Revision:   1.1  $
//## end module%530D1B65018A.cm

//## begin module%530D1B65018A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%530D1B65018A.cp

//## Module: CXOSVX10%530D1B65018A; Package specification
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R003\Windows\Build\Dn\Server\Application\Vx\CXODVX10.hpp

#ifndef CXOSVX10_h
#define CXOSVX10_h 1

//## begin module%530D1B65018A.additionalIncludes preserve=no
//## end module%530D1B65018A.additionalIncludes

//## begin module%530D1B65018A.includes preserve=yes
//## end module%530D1B65018A.includes

#ifndef CXOSVX02_h
#include "CXODVX02.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class ImportAuditSegment;
} // namespace emssegment

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ImportReportAuditSegment;

} // namespace segment

//## begin module%530D1B65018A.declarations preserve=no
//## end module%530D1B65018A.declarations

//## begin module%530D1B65018A.additionalDeclarations preserve=yes
//## end module%530D1B65018A.additionalDeclarations


//## begin VROLUploadFile%530CFC340396.preface preserve=yes
//## end VROLUploadFile%530CFC340396.preface

//## Class: VROLUploadFile%530CFC340396
//## Category: DataNavigator Foundation::Application::VROLInterface_CAT%4C2B5E9102E8
//## Subsystem: VX%4C2B63AB026E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%530E065A017A;IF::FlatFile { -> F}
//## Uses: <unnamed>%530E065D0391;IF::Trace { -> F}
//## Uses: <unnamed>%530E0660035A;timer::Clock { -> F}
//## Uses: <unnamed>%531DFBC5021B;UploadFile { -> F}
//## Uses: <unnamed>%531DFC1B02EE;emssegment::ImportAuditSegment { -> F}
//## Uses: <unnamed>%531DFDD4034D;segment::ImportReportAuditSegment { -> F}

class DllExport VROLUploadFile : public UploadFile  //## Inherits: <unnamed>%530E052C012C
{
  //## begin VROLUploadFile%530CFC340396.initialDeclarations preserve=yes
  //## end VROLUploadFile%530CFC340396.initialDeclarations

  public:
    //## Constructors (generated)
      VROLUploadFile();

    //## Destructor (generated)
      virtual ~VROLUploadFile();


    //## Other Operations (specified)
      //## Operation: buildDM3File%530E0922024E
      virtual string buildDM3File (char& cStatus, const string& strFilename);

      //## Operation: buildFile%530E1B7502CC
      virtual string buildFile (char& cStatus, const string& strFilename);

      //## Operation: execute%55C8BA3C02DE
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: rebuildDescriptorXML%530E09320163
      bool rebuildDescriptorXML (IF::FlatFile& hInFile, const string& strOutputXMLFile);

    // Additional Public Declarations
      //## begin VROLUploadFile%530CFC340396.public preserve=yes
      //## end VROLUploadFile%530CFC340396.public

  protected:
    // Additional Protected Declarations
      //## begin VROLUploadFile%530CFC340396.protected preserve=yes
      //## end VROLUploadFile%530CFC340396.protected

  private:
    // Additional Private Declarations
      //## begin VROLUploadFile%530CFC340396.private preserve=yes
      //## end VROLUploadFile%530CFC340396.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin VROLUploadFile%530CFC340396.implementation preserve=yes
      //## end VROLUploadFile%530CFC340396.implementation

};

//## begin VROLUploadFile%530CFC340396.postscript preserve=yes
//## end VROLUploadFile%530CFC340396.postscript

//## begin module%530D1B65018A.epilog preserve=yes
//## end module%530D1B65018A.epilog


#endif
