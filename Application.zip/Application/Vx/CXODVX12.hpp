//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%556CA04D00BD.cm preserve=no
//	$Date:   Aug 27 2015 15:24:54  $ $Author:   e1009591  $
//	$Revision:   1.0  $
//## end module%556CA04D00BD.cm

//## begin module%556CA04D00BD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%556CA04D00BD.cp

//## Module: CXOSVX12%556CA04D00BD; Package specification
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R003\Windows\Build\Dn\Server\Application\Vx\CXODVX12.hpp

#ifndef CXOSVX12_h
#define CXOSVX12_h 1

//## begin module%556CA04D00BD.additionalIncludes preserve=no
//## end module%556CA04D00BD.additionalIncludes

//## begin module%556CA04D00BD.includes preserve=yes
//## end module%556CA04D00BD.includes

#ifndef CXOSBC34_h
#include "CXODBC34.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;

} // namespace IF

//## begin module%556CA04D00BD.declarations preserve=no
//## end module%556CA04D00BD.declarations

//## begin module%556CA04D00BD.additionalDeclarations preserve=yes
//## end module%556CA04D00BD.additionalDeclarations


//## begin DocumentInquiryItem%556C8C970210.preface preserve=yes
//## end DocumentInquiryItem%556C8C970210.preface

//## Class: DocumentInquiryItem%556C8C970210
//## Category: DataNavigator Foundation::Application::VROLInterface_CAT%4C2B5E9102E8
//## Subsystem: VX%4C2B63AB026E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%556CA5A70191;IF::Trace { -> F}

class DllExport DocumentInquiryItem : public command::XMLItem  //## Inherits: <unnamed>%556CA5440197
{
  //## begin DocumentInquiryItem%556C8C970210.initialDeclarations preserve=yes
  //## end DocumentInquiryItem%556C8C970210.initialDeclarations

  public:
    //## Constructors (generated)
      DocumentInquiryItem();

    //## Destructor (generated)
      virtual ~DocumentInquiryItem();

    // Additional Public Declarations
      //## begin DocumentInquiryItem%556C8C970210.public preserve=yes
      //## end DocumentInquiryItem%556C8C970210.public

  protected:
    // Additional Protected Declarations
      //## begin DocumentInquiryItem%556C8C970210.protected preserve=yes
      //## end DocumentInquiryItem%556C8C970210.protected

  private:
    // Additional Private Declarations
      //## begin DocumentInquiryItem%556C8C970210.private preserve=yes
      //## end DocumentInquiryItem%556C8C970210.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin DocumentInquiryItem%556C8C970210.implementation preserve=yes
      //## end DocumentInquiryItem%556C8C970210.implementation

};

//## begin DocumentInquiryItem%556C8C970210.postscript preserve=yes
//## end DocumentInquiryItem%556C8C970210.postscript

//## begin module%556CA04D00BD.epilog preserve=yes
//## end module%556CA04D00BD.epilog


#endif
