//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6384D9AA03AC.cm preserve=no
//## end module%6384D9AA03AC.cm

//## begin module%6384D9AA03AC.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6384D9AA03AC.cp

//## Module: CXOSVX14%6384D9AA03AC; Package specification
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Vx\CXODVX14.hpp

#ifndef CXOSVX14_h
#define CXOSVX14_h 1

//## begin module%6384D9AA03AC.additionalIncludes preserve=no
//## end module%6384D9AA03AC.additionalIncludes

//## begin module%6384D9AA03AC.includes preserve=yes
//## end module%6384D9AA03AC.includes

#ifndef CXOSVX02_h
#include "CXODVX02.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class FlatFile;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ImportReportAuditSegment;

} // namespace segment

//## begin module%6384D9AA03AC.declarations preserve=no
//## end module%6384D9AA03AC.declarations

//## begin module%6384D9AA03AC.additionalDeclarations preserve=yes
//## end module%6384D9AA03AC.additionalDeclarations


//## begin STARUploadFile%6384DBB101A2.preface preserve=yes
//## end STARUploadFile%6384DBB101A2.preface

//## Class: STARUploadFile%6384DBB101A2
//## Category: DataNavigator Foundation::Application::VROLInterface_CAT%4C2B5E9102E8
//## Subsystem: VX%4C2B63AB026E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6384DCE702CA;IF::FlatFile { -> F}
//## Uses: <unnamed>%6384DD0B00E0;IF::Trace { -> F}
//## Uses: <unnamed>%6384DD37009D;timer::Clock { -> F}
//## Uses: <unnamed>%6384DD5F0366;segment::ImportReportAuditSegment { -> F}
//## Uses: <unnamed>%6384EE4D0255;IF::Extract { -> F}

class DllExport STARUploadFile : public UploadFile  //## Inherits: <unnamed>%6384DCC70154
{
  //## begin STARUploadFile%6384DBB101A2.initialDeclarations preserve=yes
  //## end STARUploadFile%6384DBB101A2.initialDeclarations

  public:
    //## Constructors (generated)
      STARUploadFile();

    //## Destructor (generated)
      virtual ~STARUploadFile();


    //## Other Operations (specified)
      //## Operation: buildFile%6384DFFE01C2
      virtual reusable::string buildFile (char& cStatus, const reusable::string& strFilename);

      //## Operation: execute%6384E031026C
      virtual bool execute ();

      //## Operation: packageZip%6384E06900B3
      virtual bool packageZip ();

      //## Operation: processZIP%6384E0790017
      bool processZIP (const reusable::string& strFilename);

    // Additional Public Declarations
      //## begin STARUploadFile%6384DBB101A2.public preserve=yes
      //## end STARUploadFile%6384DBB101A2.public

  protected:
    // Additional Protected Declarations
      //## begin STARUploadFile%6384DBB101A2.protected preserve=yes
      //## end STARUploadFile%6384DBB101A2.protected

  private:
    // Additional Private Declarations
      //## begin STARUploadFile%6384DBB101A2.private preserve=yes
      //## end STARUploadFile%6384DBB101A2.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin STARUploadFile%6384DBB101A2.implementation preserve=yes
      //## end STARUploadFile%6384DBB101A2.implementation

};

//## begin STARUploadFile%6384DBB101A2.postscript preserve=yes
//## end STARUploadFile%6384DBB101A2.postscript

//## begin module%6384D9AA03AC.epilog preserve=yes
//## end module%6384D9AA03AC.epilog


#endif
