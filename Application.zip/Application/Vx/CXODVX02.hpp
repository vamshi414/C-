//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4C2B68380241.cm preserve=no
//	$Date:   Aug 13 2019 09:48:04  $ $Author:   e5549623  $
//	$Revision:   1.16  $
//## end module%4C2B68380241.cm

//## begin module%4C2B68380241.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4C2B68380241.cp

//## Module: CXOSVX02%4C2B68380241; Package specification
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R003\Windows\Build\Dn\Server\Application\Vx\CXODVX02.hpp

#ifndef CXOSVX02_h
#define CXOSVX02_h 1

//## begin module%4C2B68380241.additionalIncludes preserve=no
//## end module%4C2B68380241.additionalIncludes

//## begin module%4C2B68380241.includes preserve=yes
#include <map>
#ifndef CXOSRU56_h
#include "CXODRU56.hpp"
#endif
#include "CXODIF10.hpp"
#define BUFFER_SIZE 32767
//## end module%4C2B68380241.includes

#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif
#ifndef CXOSBS04_h
#include "CXODBS04.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class ContactSegment;
class Customer;
} // namespace entitysegment

class DocumentInquiry;
class VROLUploadFile;
class MasterCardUploadFile;
class ECHISTUploadFile;
class BAMSUploadFile;
//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class FlatFile;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
} // namespace timer

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Email;
} // namespace command

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ImportReportAuditSegment;
} // namespace segment

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;

} // namespace usersegment

//## begin module%4C2B68380241.declarations preserve=no
//## end module%4C2B68380241.declarations

//## begin module%4C2B68380241.additionalDeclarations preserve=yes
//## end module%4C2B68380241.additionalDeclarations


//## begin UploadFile%4C2B61EA001E.preface preserve=yes
//## end UploadFile%4C2B61EA001E.preface

//## Class: UploadFile%4C2B61EA001E
//	<body>
//	<title>CG
//	<h1>VX
//	<h2>FO
//	<h3>UA5, DM3 and DM5 upload files
//	<p>
//	The VROL Interface service combines the XML files
//	received from the DataNavigator server with any related
//	TIFF files from the image server into a zip archive.
//	This archive is then sent via ftp to an IBM zSeries host
//	for transmission to VISA, another instance of Data
//	Navigator or a 3<sup>rd</sup> party processor.
//	<p>
//	The XML upload files must be received from the Data
//	Navigator server in the UPENDING folder.
//	UA5 files must be named as follows:
//	<ul>
//	<li>BUA5.D<i>yymmdd</i>.T<i>hhmmss</i>.VROL (e.g.
//	BUA5.D101226.T130000.VROL)
//	<li>RUA5.D<i>yymmdd</i>.T<i>hhmmss</i>.VROL (e.g.
//	RUA5.D101226.T130000.VROL)
//	</ul>
//	<p>
//	The VROL Interface service will move the files from the
//	UPENDING folder to the UFINISHE folder named as follows:
//	<ul>
//	<li>original_BUA5.D<i>yymmdd</i>.T<i>hhmmss</i>.VROL
//	<li>original_RUA5.D<i>yymmdd</i>.T<i>hhmmss</i>.VROL
//	</ul>
//	The UFINISHE folder will also contain:
//	<ul>
//	<li>the zip archive (named processed_UA5<i>md</i>00.zip)
//	<li>the ftp script used to send the zip archive to the
//	IBM zSeries host
//	</ul>
//	<p>
//	The dataset name on the host is set with the VROLU5
//	parameter:
//	<ul>
//	<li><i>VROLU5</i>.UA5<i>md</i>00 (e.g. DN.VROL.UA53A00)
//	</ul>
//	The syntax of the zip command can be set with the ZIPCOM
//	parameter.
//	<p>
//	For transmission via ftp to your host system, configure
//	the FTPIBMH, FTPUSRID, FTPPSWRD and FTPSEND parameters.
//	<p>
//	You must put a procedure in place to transmit the
//	completed zip file from your host system to VISA VROL
//	for processing.
//	Refer to the description of the File Formatter service
//	for more information on creating the UA5 XML files.
//	<p>
//	Configure the following files:
//	<p>
//	<table>
//	<tr>
//	<th>File
//	<th>Path
//	<th>Comments
//	<tr>
//	<td>UPENDING
//	<td>VROL\Upload\Pending\%member
//	<td>XML received from IBM zSeries host
//	<tr>
//	<td>UFINISHE
//	<td>VROL\Upload\Complete\%date\%member
//	<td>Zip archive sent back to IBM zSeries host
//	<tr>
//	<td>UCOMPLET
//	<td>VROL\Upload\Complete\%member
//	<td>Complete folder (used for purging oldest folders)
//	<tr>
//	<td>VROLU5
//	<td>
//	<td>IBM z/OS dataset name prefix
//	</table>
//	<p>
//	Configure the following DSPEC entries:
//	<p>
//	<table>
//	<tr>
//	<th>Key
//	<th>Value
//	<th>Comments
//	<tr>
//	<td>ZIPCOM
//	<td>C:\PROGRA~1\WINZIP\WINZIP32.exe -min -a "%d" "%f"
//	<td>Zip command syntax
//	<tr>
//	<td>FTPSEND
//	<td>ftp -i -s:"%f"
//	<td>ftp command syntax
//	<tr>
//	<td>FTPIBMH
//	<td><i>host</i>
//	<td>IBM z/OS host name
//	<tr>
//	<td>FTPUSRID
//	<td><i>user ID</i>
//	<td>IBM z/OS user ID
//	<tr>
//	<td>FTPPSWRD
//	<td><i>password</i>
//	<td>IBM z/OS password
//	<tr>
//	<td>UDELDAY
//	<td>64
//	<td>Number of days to retain upload files
//	<tr>
//	<td>MINTIFER
//	<td>3
//	<td>Minimum number of TIFF errors
//	</table>
//	<p>
//	</body>
//## Category: DataNavigator Foundation::Application::VROLInterface_CAT%4C2B5E9102E8
//## Subsystem: VX%4C2B63AB026E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4C2B634301EB;IF::FlatFile { -> F}
//## Uses: <unnamed>%4C5884E0022D;IF::Trace { -> F}
//## Uses: <unnamed>%4C607926027E;entitysegment::Customer { -> F}
//## Uses: <unnamed>%4C60792E0329;timer::Date { -> F}
//## Uses: <unnamed>%4C7296630256;entitysegment::ContactSegment { -> F}
//## Uses: <unnamed>%4C72966A0235;command::Email { -> F}
//## Uses: <unnamed>%4C72966D007F;usersegment::EmailSegment { -> F}
//## Uses: <unnamed>%4C72EF60029D;segment::ImportReportAuditSegment { -> F}
//## Uses: <unnamed>%4C73ED9D01CC;timer::Clock { -> F}
//## Uses: <unnamed>%55A7FCA2012A;IF::Message { -> F}
//## Uses: <unnamed>%55A80461004E;BAMSUploadFile { -> F}
//## Uses: <unnamed>%55A80464013F;ECHISTUploadFile { -> F}
//## Uses: <unnamed>%55A8046700A0;MasterCardUploadFile { -> F}
//## Uses: <unnamed>%55C4E1C803A0;VROLUploadFile { -> F}

class DllExport UploadFile : public segment::Command  //## Inherits: <unnamed>%55672EE00095
{
  //## begin UploadFile%4C2B61EA001E.initialDeclarations preserve=yes
  //## end UploadFile%4C2B61EA001E.initialDeclarations

  public:
    //## Constructors (generated)
      UploadFile();

    //## Destructor (generated)
      virtual ~UploadFile();


    //## Other Operations (specified)
      //## Operation: buildFile%4C695FB0021C
      virtual string buildFile (char& cStatus, const string& strFilename);

      //## Operation: cleanup%4C6970AF01BE
      virtual void cleanup ();

      //## Operation: email%4C72ECFD0161
      virtual bool email ();

      //## Operation: execute%556F58E9033D
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: executeDGMCFTPScript%55CA38580148
      virtual bool executeDGMCFTPScript (string& strFTPDatasetName, string& strOwner, const string& strFilename);

      //## Operation: executeFTPScript%55CA383202B6
      virtual bool executeFTPScript ();

      //## Operation: finalizeFiles%4C5B0F18010E
      virtual bool finalizeFiles (string& strOwner);

      //## Operation: isOnlyAlphaNum%4C6EAAA50383
      virtual bool isOnlyAlphaNum (const string& strContent, const size_t& pos, const size_t& n);

      //## Operation: packageZip%4C69602C022C
      virtual bool packageZip ();

      //## Operation: post%55CD00F201BE
      bool post (string& strXMLText);

      //## Operation: processZIP%55C9FA7E0103
      virtual bool processZIP (const string& strFilename);
      virtual bool processMSTRZIP (const string& strFilename);

      //## Operation: readExtract%4C697EE80355
      virtual bool readExtract ();

      //## Operation: rebuildBatchXML%531DFB540349
      virtual bool rebuildBatchXML (IF::FlatFile& hInFile, const string& strOutputXMLFile);

      //## Operation: removePatterns%4C5880C903CE
      virtual bool removePatterns (string& strLine);

      //## Operation: reply%55A7FC7A03E2
      virtual int reply ();

      //## Operation: resetVars%4C69605C0132
      virtual void resetVars ();

      //## Operation: restoreFiles%4C5B0EDD03B4
      virtual void restoreFiles ();

      //## Operation: sendStatus%5166D73101A7
      virtual void sendStatus (char& cStatus, const string& strReason);

      //## Operation: setSpaceParam%5D49D6B403A9
      virtual void setSpaceParam ();

      //## Operation: writeFTPScript%4C69607101AF
      virtual bool writeFTPScript (string& strFTPDatasetName, string& strOwner);

      //## Operation: zipImages%4C5881080325
      virtual bool zipImages ();

    // Data Members for Class Attributes

      //## Attribute: BatchBaseName%4C6960A20317
      //## begin UploadFile::BatchBaseName%4C6960A20317.attr preserve=no  public: string {U} 
      string m_strBatchBaseName;
      //## end UploadFile::BatchBaseName%4C6960A20317.attr

      //## Attribute: BatchOrigName%4D274A4D02CE
      //## begin UploadFile::BatchOrigName%4D274A4D02CE.attr preserve=no  public: string {U} 
      string m_strBatchOrigName;
      //## end UploadFile::BatchOrigName%4D274A4D02CE.attr

      //## Attribute: ConsecutiveErrorCount%4C72EEFC01ED
      //## begin UploadFile::ConsecutiveErrorCount%4C72EEFC01ED.attr preserve=no  private: int {U} 
      int m_iConsecutiveErrorCount;
      //## end UploadFile::ConsecutiveErrorCount%4C72EEFC01ED.attr

      //## Attribute: ContactEmailAddress%4C72EE32037A
      //## begin UploadFile::ContactEmailAddress%4C72EE32037A.attr preserve=no  public: string {U} 
      string m_strContactEmailAddress;
      //## end UploadFile::ContactEmailAddress%4C72EE32037A.attr

      //## Attribute: DaysUntilDelete%4C696F2F034D
      //## begin UploadFile::DaysUntilDelete%4C696F2F034D.attr preserve=no  public: int {U} 
      int m_iDaysUntilDelete;
      //## end UploadFile::DaysUntilDelete%4C696F2F034D.attr

      //## Attribute: DocFile%4C6960BF0374
      //## begin UploadFile::DocFile%4C6960BF0374.attr preserve=no  public: string {U} 
      string m_strDocFile;
      //## end UploadFile::DocFile%4C6960BF0374.attr

      //## Attribute: Email%4C72EE8F0182
      //## begin UploadFile::Email%4C72EE8F0182.attr preserve=no  public: command::Email* {U} 
      command::Email* m_pEmail;
      //## end UploadFile::Email%4C72EE8F0182.attr

      //## Attribute: ErrorsBetweenEmails%4C73E35B0218
      //## begin UploadFile::ErrorsBetweenEmails%4C73E35B0218.attr preserve=no  public: int {U} 
      int m_iErrorsBetweenEmails;
      //## end UploadFile::ErrorsBetweenEmails%4C73E35B0218.attr

      //## Attribute: FTPIbmHost%4C6960CF0190
      //## begin UploadFile::FTPIbmHost%4C6960CF0190.attr preserve=no  public: string {U} 
      string m_strFTPIbmHost;
      //## end UploadFile::FTPIbmHost%4C6960CF0190.attr

      //## Attribute: FTPIbmUADsName%4C6960C502C9
      //## begin UploadFile::FTPIbmUADsName%4C6960C502C9.attr preserve=no  public: string {U} 
      string m_strFTPIbmUADsName;
      //## end UploadFile::FTPIbmUADsName%4C6960C502C9.attr

      //## Attribute: FTPPassword%4C6960DB0123
      //## begin UploadFile::FTPPassword%4C6960DB0123.attr preserve=no  public: string {U} 
      string m_strFTPPassword;
      //## end UploadFile::FTPPassword%4C6960DB0123.attr

      //## Attribute: FTPScriptFile%4C6960E80374
      //## begin UploadFile::FTPScriptFile%4C6960E80374.attr preserve=no  public: IF::FlatFile {U} 
      IF::FlatFile m_hFTPScriptFile;
      //## end UploadFile::FTPScriptFile%4C6960E80374.attr

      //## Attribute: FTPUsername%4C6960F50019
      //## begin UploadFile::FTPUsername%4C6960F50019.attr preserve=no  public: string {U} 
      string m_strFTPUsername;
      //## end UploadFile::FTPUsername%4C6960F50019.attr

      //## Attribute: MinimumTifError%4C6960FE03D2
      //## begin UploadFile::MinimumTifError%4C6960FE03D2.attr preserve=no  public: int {U} 
      int m_iMinimumTifError;
      //## end UploadFile::MinimumTifError%4C6960FE03D2.attr

      //## Attribute: PreviousError%4C73F9AC02F3
      //## begin UploadFile::PreviousError%4C73F9AC02F3.attr preserve=no  public: string {U} 
      string m_strPreviousError;
      //## end UploadFile::PreviousError%4C73F9AC02F3.attr

      //## Attribute: TifCommands%4F593F6E0296
      //## begin UploadFile::TifCommands%4F593F6E0296.attr preserve=no  public: vector<string> {U} 
      vector<string> m_hTifCommands;
      //## end UploadFile::TifCommands%4F593F6E0296.attr

      //## Attribute: TifDocs%4C69610B0103
      //## begin UploadFile::TifDocs%4C69610B0103.attr preserve=no  public: vector<string> {U} 
      vector<string> m_hTifDocs;
      //## end UploadFile::TifDocs%4C69610B0103.attr

      //## Attribute: FolderName%55CA076A023A
      //## begin UploadFile::FolderName%55CA076A023A.attr preserve=no  public: string {U} 
      string m_strFolderName;
      //## end UploadFile::FolderName%55CA076A023A.attr

      //## Attribute: Filename%55CA42A40241
      //## begin UploadFile::Filename%55CA42A40241.attr preserve=no  public: string {U} 
      string m_strFilename;
      //## end UploadFile::Filename%55CA42A40241.attr

    // Additional Public Declarations
      //## begin UploadFile%4C2B61EA001E.public preserve=yes
      //## end UploadFile%4C2B61EA001E.public

  protected:
    // Data Members for Class Attributes

      //## begin UploadFile::Status%55C51326007B.attr preserve=no  private: static bool {U} false
      static bool m_bStatus;
      //## end UploadFile::Status%55C51326007B.attr

      //## Attribute: DownloadFile%55D211C00274
      //## begin UploadFile::DownloadFile%55D211C00274.attr preserve=no  private: bool {U} false
      //## end UploadFile::DownloadFile%55D211C00274.attr

    // Additional Protected Declarations
      //## begin UploadFile%4C2B61EA001E.protected preserve=yes
      static bool m_bDownloadFile;
      static string m_hFileName;
      //## end UploadFile%4C2B61EA001E.protected

  private:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Status%55C51326007B
      static const bool& getStatus ()
      {
        //## begin UploadFile::getStatus%55C51326007B.get preserve=no
        return m_bStatus;
        //## end UploadFile::getStatus%55C51326007B.get
      }

      static void setStatus (const bool& value)
      {
        //## begin UploadFile::setStatus%55C51326007B.set preserve=no
        m_bStatus = value;
        //## end UploadFile::setStatus%55C51326007B.set
      }


    // Additional Private Declarations
      //## begin UploadFile%4C2B61EA001E.private preserve=yes
      //## end UploadFile%4C2B61EA001E.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::VROLInterface_CAT::<unnamed>%4DD2D338013A
      //## Role: UploadFile::<m_hTimer>%4DD2D33900DD
      //## begin UploadFile::<m_hTimer>%4DD2D33900DD.role preserve=no  public: timer::Timer { -> VHgN}
      timer::Timer m_hTimer;
      //## end UploadFile::<m_hTimer>%4DD2D33900DD.role


//## Attribute: HeaderFile%5D4D90850223
      //## begin UploadFile::HeaderFile%5D4D90850223.attr preserve=no  private: string {U} 
      string m_strHeaderFile;
      //## end UploadFile::HeaderFile%5D4D90850223.attr

      //## Attribute: Owner%5D4D90B90214
      //## begin UploadFile::Owner%5D4D90B90214.attr preserve=no  private: string {U} 
      string m_strOwner;
      //## end UploadFile::Owner%5D4D90B90214.attr
      //## Association: DataNavigator Foundation::Application::VROLInterface_CAT::<unnamed>%556F5751024F
      //## Role: UploadFile::<m_pDocumentInquiry>%556F575201EA
      //## begin UploadFile::<m_pDocumentInquiry>%556F575201EA.role preserve=no  public: DocumentInquiry { -> RFHgN}
      DocumentInquiry *m_pDocumentInquiry;
      //## end UploadFile::<m_pDocumentInquiry>%556F575201EA.role

    // Additional Implementation Declarations
      //## begin UploadFile%4C2B61EA001E.implementation preserve=yes
      //## end UploadFile%4C2B61EA001E.implementation

};

//## begin UploadFile%4C2B61EA001E.postscript preserve=yes
//## end UploadFile%4C2B61EA001E.postscript

//## begin module%4C2B68380241.epilog preserve=yes
//## end module%4C2B68380241.epilog


#endif
