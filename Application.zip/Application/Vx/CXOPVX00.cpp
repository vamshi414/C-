//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4C2B63E30139.cm preserve=no
//	$Date:   Apr 21 2016 20:24:48  $ $Author:   e1009591  $
//	$Revision:   1.10  $
//## end module%4C2B63E30139.cm

//## begin module%4C2B63E30139.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4C2B63E30139.cp

//## Module: CXOPVX00%4C2B63E30139; Package body
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R003\Windows\Build\Dn\Server\Application\Vx\CXOPVX00.cpp

//## begin module%4C2B63E30139.additionalIncludes preserve=no
//## end module%4C2B63E30139.additionalIncludes

//## begin module%4C2B63E30139.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#include "CXODRU10.hpp"
//## end module%4C2B63E30139.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSPS03_h
#include "CXODPS03.hpp"
#endif
#ifndef CXOSVX01_h
#include "CXODVX01.hpp"
#endif
#ifndef CXOSVX04_h
#include "CXODVX04.hpp"
#endif
#ifndef CXOSVX10_h
#include "CXODVX10.hpp"
#endif
#ifndef CXOSVX13_h
#include "CXODVX13.hpp"
#endif
#ifndef CXOSVX05_h
#include "CXODVX05.hpp"
#endif
#ifndef CXOSVX09_h
#include "CXODVX09.hpp"
#endif
#ifndef CXOSVX14_h
#include "CXODVX14.hpp"
#endif
#ifndef CXOPVX00_h
#include "CXODVX00.hpp"
#endif


//## begin module%4C2B63E30139.declarations preserve=no
//## end module%4C2B63E30139.declarations

//## begin module%4C2B63E30139.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new VROLInterface();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%4C2B63E30139.additionalDeclarations


// Class VROLInterface 

VROLInterface::VROLInterface()
  //## begin VROLInterface::VROLInterface%4C2B5F0000FE_const.hasinit preserve=no
      : m_bSetup(false),
        m_iTimerValue(3600),
        m_lFile(-1),
        m_pDownloadFile(0)
 //       m_pUploadFile(0)
  //## end VROLInterface::VROLInterface%4C2B5F0000FE_const.hasinit
  //## begin VROLInterface::VROLInterface%4C2B5F0000FE_const.initialization preserve=yes
  //## end VROLInterface::VROLInterface%4C2B5F0000FE_const.initialization
{
  //## begin VROLInterface::VROLInterface%4C2B5F0000FE_const.body preserve=yes
   memcpy(m_sID,"VX00",4);
  //## end VROLInterface::VROLInterface%4C2B5F0000FE_const.body
}


VROLInterface::~VROLInterface()
{
  //## begin VROLInterface::~VROLInterface%4C2B5F0000FE_dest.body preserve=yes
//   delete m_pUploadFile;
   delete m_pDownloadFile;
  //## end VROLInterface::~VROLInterface%4C2B5F0000FE_dest.body
}



//## Other Operations (implementation)
int VROLInterface::initialize ()
{
  //## begin VROLInterface::initialize%4C2B5F2700AE.body preserve=yes
   if (m_bSetup)
   {
      IF::Extract::instance()->setup(); // will execute up to the point of getSpec CUSTOMER
#ifdef _WIN32
      string strName("DataNavigator ");
      strName += Transaction::instance()->getCustAbbr();
      strName += "VX";
      string strPath;
      char sBuffer[_MAX_PATH];
      _getcwd(sBuffer,_MAX_PATH);
      strPath = sBuffer;
      strPath += "\\CXOPVX00.exe";
      process::Service hTask(strName.c_str(),strPath.c_str(),false);
      hTask.start();
#endif
      return -1;
   }
   new dnplatform::DNPlatform();
   if (Application::initialize() != 0)
      return -1;
   Trace::setEnable(true);
   m_hCommand.push_back(new STARUploadFile());
   m_hCommand.push_back(new VROLUploadFile());
   m_hCommand.push_back(new BAMSUploadFile());
   m_hCommand.push_back(new MasterCardUploadFile());
//   m_hCommand.push_back(new ECHISTUploadFile());
   m_hCommand.push_back(new DownloadFile());
   m_hCommand.push_back(new EncryptDocuments());
//   m_pUploadFile = new UploadFile();
   string strTimerValue;
   Extract::instance()->getSpec("TIMERVAL",strTimerValue);
   if (strTimerValue.length() > 0)
      m_iTimerValue = atoi(strTimerValue.c_str());
   m_hTimer.set(m_iTimerValue);
   m_hTimer.attach(this);
   return 0;
  //## end VROLInterface::initialize%4C2B5F2700AE.body
}

void VROLInterface::parseCommandLine (int iArgc, char** ppArgv)
{
  //## begin VROLInterface::parseCommandLine%4C2B6CB002AF.body preserve=yes
   if (iArgc > 1
      && strcmp(ppArgv[1],"-debug") == 0)
      ;
   else
   {
      string strName(ppArgv[0]);
      size_t pos = strName.find_last_of(' ');
      setName(strName.c_str() + pos + 1);
   }
   int j = 0;
   char* q = 0;
   string strTemp;
   for (int i = 1;i < iArgc;++i)
   {
      switch (j)
      {
         case 0:
            if (!strcmp(ppArgv[i],"-n"))
               j = 1;
            else
            if (!strcmp(ppArgv[i],"-p"))
               j = 2;
            else
            if (!strcmp(ppArgv[i],"-q"))
               j = 3;
            else
            if (!strcmp(ppArgv[i],"-t"))
               Trace::setEnable(true);
            break;
         case 1:
            strTemp= ppArgv[i];
            if (strTemp.length() > 2)
               Transaction::instance()->setCustAbbr(strTemp.substr(0,2));
            setName(ppArgv[i]);
            j = 0;
            break;
         case 2:
            m_bSetup = true;
            q = strchr(ppArgv[i],'"');
            if (q)
               *q = '\0';
            Extract::instance()->setNode001(ppArgv[i]);
            j = 0;
            break;
         case 3:
            string strRecord("DSPEC   QUALIFY ");
            strRecord += ppArgv[i];
            Extract::instance()->addRecord(strRecord);
            j = 0;
            break;
      }
   }
  //## end VROLInterface::parseCommandLine%4C2B6CB002AF.body
}

void VROLInterface::update (Subject* pSubject)
{
  //## begin VROLInterface::update%55C4F7C6016A.body preserve=yes
   if (pSubject == &m_hTimer)
   {
      vector<Command*>::iterator ppCommand;
      for (ppCommand = m_hCommand.begin();ppCommand != m_hCommand.end();++ppCommand)
      {
         if (!(*ppCommand)->execute())
            break;
      }
       m_hTimer.set(m_iTimerValue);
   return;
   }
  //## end VROLInterface::update%55C4F7C6016A.body
}

// Additional Declarations
  //## begin VROLInterface%4C2B5F0000FE.declarations preserve=yes
  //## end VROLInterface%4C2B5F0000FE.declarations

//## begin module%4C2B63E30139.epilog preserve=yes
//## end module%4C2B63E30139.epilog
