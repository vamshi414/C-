//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%556C8CAF03DE.cm preserve=no
//	$Date:   Aug 27 2015 15:24:52  $ $Author:   e1009591  $
//	$Revision:   1.0  $
//## end module%556C8CAF03DE.cm

//## begin module%556C8CAF03DE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%556C8CAF03DE.cp

//## Module: CXOSVX11%556C8CAF03DE; Package specification
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R003\Windows\Build\Dn\Server\Application\Vx\CXODVX11.hpp

#ifndef CXOSVX11_h
#define CXOSVX11_h 1

//## begin module%556C8CAF03DE.additionalIncludes preserve=no
//## end module%556C8CAF03DE.additionalIncludes

//## begin module%556C8CAF03DE.includes preserve=yes
//## end module%556C8CAF03DE.includes

#ifndef CXOSBC33_h
#include "CXODBC33.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif

class DocumentInquiryItem;
//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;

} // namespace timer

//## begin module%556C8CAF03DE.declarations preserve=no
//## end module%556C8CAF03DE.declarations

//## begin module%556C8CAF03DE.additionalDeclarations preserve=yes
//## end module%556C8CAF03DE.additionalDeclarations


//## begin DocumentInquiry%556C9EDE02D9.preface preserve=yes
//## end DocumentInquiry%556C9EDE02D9.preface

//## Class: DocumentInquiry%556C9EDE02D9
//## Category: DataNavigator Foundation::Application::VROLInterface_CAT%4C2B5E9102E8
//## Subsystem: VX%4C2B63AB026E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%556CA5E000CE;IF::Trace { -> F}
//## Uses: <unnamed>%556CC4700394;IF::Message { -> F}
//## Uses: <unnamed>%556CC482027D;IF::Extract { -> F}
//## Uses: <unnamed>%556CC53B018D;timer::Clock { -> F}
//## Uses: <unnamed>%556F47BA0180;DocumentInquiryItem { -> F}

class DllExport DocumentInquiry : public command::SOAPService  //## Inherits: <unnamed>%556CA5CF00A7
{
  //## begin DocumentInquiry%556C9EDE02D9.initialDeclarations preserve=yes
  //## end DocumentInquiry%556C9EDE02D9.initialDeclarations

  public:
    //## Constructors (generated)
      DocumentInquiry();

    //## Destructor (generated)
      virtual ~DocumentInquiry();


    //## Other Operations (specified)
      //## Operation: post%556CC2D20285
      virtual bool post (const char* pszName, segment::Command* pCommand);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: xmlText%55C39B240295
      const string& getxmlText () const
      {
        //## begin DocumentInquiry::getxmlText%55C39B240295.get preserve=no
        return m_strxmlText;
        //## end DocumentInquiry::getxmlText%55C39B240295.get
      }

      void setxmlText (const string& value)
      {
        //## begin DocumentInquiry::setxmlText%55C39B240295.set preserve=no
        m_strxmlText = value;
        //## end DocumentInquiry::setxmlText%55C39B240295.set
      }


    // Additional Public Declarations
      //## begin DocumentInquiry%556C9EDE02D9.public preserve=yes
      //## end DocumentInquiry%556C9EDE02D9.public

  protected:
    // Data Members for Class Attributes

      //## begin DocumentInquiry::xmlText%55C39B240295.attr preserve=no  public: string {U} 
      string m_strxmlText;
      //## end DocumentInquiry::xmlText%55C39B240295.attr

    // Additional Protected Declarations
      //## begin DocumentInquiry%556C9EDE02D9.protected preserve=yes
      //## end DocumentInquiry%556C9EDE02D9.protected

  private:
    // Additional Private Declarations
      //## begin DocumentInquiry%556C9EDE02D9.private preserve=yes
      //## end DocumentInquiry%556C9EDE02D9.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::VROLInterface_CAT::<unnamed>%556F4F6A0227
      //## Role: DocumentInquiry::<m_pMessage>%556F4F6B0105
      //## begin DocumentInquiry::<m_pMessage>%556F4F6B0105.role preserve=no  public: IF::Message { -> UFHgN}
      IF::Message m_pMessage;
      //## end DocumentInquiry::<m_pMessage>%556F4F6B0105.role

      //## Association: DataNavigator Foundation::Application::VROLInterface_CAT::<unnamed>%556F4F7B028F
      //## Role: DocumentInquiry::<m_hMessage>%556F4F7F013E
      //## begin DocumentInquiry::<m_hMessage>%556F4F7F013E.role preserve=no  public: IF::Message { -> VHgN}
      IF::Message m_hMessage;
      //## end DocumentInquiry::<m_hMessage>%556F4F7F013E.role

    // Additional Implementation Declarations
      //## begin DocumentInquiry%556C9EDE02D9.implementation preserve=yes
      //## end DocumentInquiry%556C9EDE02D9.implementation

};

//## begin DocumentInquiry%556C9EDE02D9.postscript preserve=yes
//## end DocumentInquiry%556C9EDE02D9.postscript

//## begin module%556C8CAF03DE.epilog preserve=yes
//## end module%556C8CAF03DE.epilog


#endif
