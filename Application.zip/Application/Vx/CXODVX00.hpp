//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4C2B63E101F4.cm preserve=no
//	$Date:   Oct 21 2015 10:48:50  $ $Author:   e1009591  $
//	$Revision:   1.5  $
//## end module%4C2B63E101F4.cm

//## begin module%4C2B63E101F4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4C2B63E101F4.cp

//## Module: CXOPVX00%4C2B63E101F4; Package specification
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R003\Windows\Build\Dn\Server\Application\Vx\CXODVX00.hpp

#ifndef CXOPVX00_h
#define CXOPVX00_h 1

//## begin module%4C2B63E101F4.additionalIncludes preserve=no
//## end module%4C2B63E101F4.additionalIncludes

//## begin module%4C2B63E101F4.includes preserve=yes
//## end module%4C2B63E101F4.includes

#ifndef CXOSBS04_h
#include "CXODBS04.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif

class VROLUploadFile;
class MasterCardUploadFile;
class ECHISTUploadFile;
class BAMSUploadFile;
class DownloadFile;
//class UploadFile;
class EncryptDocuments;
//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Extract;
class Queue;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class ServiceApplication;
} // namespace process

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;

} // namespace platform

//## begin module%4C2B63E101F4.declarations preserve=no
//## end module%4C2B63E101F4.declarations

//## begin module%4C2B63E101F4.additionalDeclarations preserve=yes
//## end module%4C2B63E101F4.additionalDeclarations


//## begin VROLInterface%4C2B5F0000FE.preface preserve=yes
//## end VROLInterface%4C2B5F0000FE.preface

//## Class: VROLInterface%4C2B5F0000FE
//	<body>
//	<title>CG
//	<h1>VX
//	<h2>AB
//	<h3>System Flow
//	<p>
//	DataNavigator supports the exchange of disputes with
//	VISA using the VROL bulk system interface.
//	In this interface, disputes are exchanged in a zip
//	archive containing XML text and images in tif format.
//	These archives can also be exchanged with other
//	instances of DataNavigator or 3<sup>rd</sup> party
//	processors that support the VROL format.
//	<p>
//	The VROL Interface service normally executes on your
//	Windows or UNIX based image server.
//	Alternatively, it can execute on a server that has
//	access to a network share on the image server.
//	This service extracts downloaded zip archives (DM5 and
//	DM3) and creates the zip archives (UA5) for upload as
//	well as managing the images on the server.
//	It monitors the file system once a minute for new
//	datasets to process.
//	<p>
//	The following configuration assumes a Windows based
//	image server communicating with a DataNavigator server
//	on an IBM zSeries mainframe.
//	<p>
//	The image server must be configured as follows:
//	<ul>
//	<li>Create a file system (C:\FIS) on the image server as
//	shown below
//	<li>Copy the Microsoft Windows version of the FIS Data
//	Navigator server to the Alpha\Bin folder
//	<li>Create a VX.txt extract file
//	</ul>
//	<p>
//	<img src=CXOCVX00.gif>
//	<p>
//	Here is an example VX extract file:
//	<pre>
//	DMISC
//	DUSER   VX
//	DSPEC   DFOLDER DVROL
//	DFILES  DVROL   VROL\Download\Pending\%member
//	DFILES  DCOMPLET%o\Download\Complete\%f\%member
//	DFILES  DDOC    \DnDocs\Stage\%f\%member
//	DFILES  DVROLDOC\DnDocs\VROL\IN\%date\%member
//	DFILES  UPENDINGVROL\Upload\Pending\%member
//	DFILES  UCOMPLETVROL\Upload\Complete\%member
//	DFILES  UFINISHEVROL\Upload\Complete\%date\%member
//	DSPEC   DOCEXT  jpg bmp ico emf vmf tif tiff pdf html doc
//	DSPEC   VROLD5  FX1234.
//	DSPEC   VROLU5  FX1234.VROL.
//	DSPEC   ZIPCOM  C:\PROGRA~1\WINZIP\WINZIP32.exe -min -a
//	"%d" "%f"
//	DSPEC   UNZIPCOMC:\PROGRA~1\WINZIP\WINZIP32.exe -e -o %f
//	%d
//	DSPEC   FTPSEND ftp -i -s:"%f"
//	DSPEC   FTPIBMH A001
//	DSPEC   FTPUSRIDFX1234
//	DSPEC   FTPPSWRDxxxxxxxx
//	DSPEC   DDELDAY 64
//	DSPEC   UDELDAY 64
//	DSPEC   EMAILADRAlan.Ammentorp@fisglobal.com
//	DSPEC   ERMAILNM10
//	DSPEC   MINTIFER3
//	</pre>
//	<img src=CXOCVX01.gif>
//	<p>
//	<ul>
//	<li>DVROLDOC : location for incoming documents from VISA
//	VROL
//	<li>DOCEXT : document extensions that are accepted
//	</ul>
//	<p>
//	<h2>MS
//	<p>
//	<p>
//	The VROL Interface application must be run from the
//	command line initially.
//	Open a Command Prompt window and enter the following
//	commands:
//	<ul>
//	<li>cd FIS\Server\Alpha\Bin
//	<li>CXOPVX00 -debug -n VX -p <i>node001</i> -q
//	<i>qualify</i>
//	</ul>
//	The program will register itself as a new Windows
//	service named 'DataNavigator VX'.
//	The Microsoft Services dialog can now be used to stop
//	and start the application.
//	<p>
//	<p>
//	</body>
//## Category: DataNavigator Foundation::Application::VROLInterface_CAT%4C2B5E9102E8
//## Subsystem: VX%4C2B63AB026E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4C3F225C0287;IF::Extract { -> F}
//## Uses: <unnamed>%4C3F231902B3;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%4C3F238B00F5;IF::Trace { -> F}
//## Uses: <unnamed>%4C6C07220333;database::Database { -> F}
//## Uses: <unnamed>%4C6C076A0229;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4C6C07C801EF;platform::Platform { -> F}
//## Uses: <unnamed>%4C6C0805016F;IF::Queue { -> F}
//## Uses: <unnamed>%4C6C08B300C9;process::ServiceApplication { -> F}
//## Uses: <unnamed>%55C5046B0352;IF::Extract { -> F}

class DllExport VROLInterface : public process::Application  //## Inherits: <unnamed>%4C2B5F1B00AF
{
  //## begin VROLInterface%4C2B5F0000FE.initialDeclarations preserve=yes
  //## end VROLInterface%4C2B5F0000FE.initialDeclarations

  public:
    //## Constructors (generated)
      VROLInterface();

    //## Destructor (generated)
      virtual ~VROLInterface();


    //## Other Operations (specified)
      //## Operation: initialize%4C2B5F2700AE
      virtual int initialize ();

      //## Operation: parseCommandLine%4C2B6CB002AF
      //	Interprets the command line parameters:
      //	-debug:  Optional - specified as the first parameter to
      //	start the Application in Visual Studio .NET
      //	-n <name>:  Specifies the name of the Application (e.g.
      //	caQE01)
      //	-d:  Optional - causes the Application to read from a
      //	DiskQueue (only used with -debug)
      virtual void parseCommandLine (int iArgc, char** ppArgv);

      //## Operation: update%55C4F7C6016A
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Data Members for Class Attributes

      //## Attribute: TimerValue%55C503660078
      //## begin VROLInterface::TimerValue%55C503660078.attr preserve=no  public: int {U} 3600
      int m_iTimerValue;
      //## end VROLInterface::TimerValue%55C503660078.attr

    // Additional Public Declarations
      //## begin VROLInterface%4C2B5F0000FE.public preserve=yes
      //## end VROLInterface%4C2B5F0000FE.public

  protected:
    // Additional Protected Declarations
      //## begin VROLInterface%4C2B5F0000FE.protected preserve=yes
      //## end VROLInterface%4C2B5F0000FE.protected

  private:
    // Additional Private Declarations
      //## begin VROLInterface%4C2B5F0000FE.private preserve=yes
      //## end VROLInterface%4C2B5F0000FE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Setup%4C3F211E02F7
      //## begin VROLInterface::Setup%4C3F211E02F7.attr preserve=no  private: bool {U} false
      bool m_bSetup;
      //## end VROLInterface::Setup%4C3F211E02F7.attr

      //## Attribute: File%55C50D3602A1
      //## begin VROLInterface::File%55C50D3602A1.attr preserve=no  private: int {U} -1
      int m_lFile;
      //## end VROLInterface::File%55C50D3602A1.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::VROLInterface_CAT::<unnamed>%4C2B6D03003D
      //## Role: VROLInterface::<m_pDownloadFile>%4C2B6D04000F
      //## begin VROLInterface::<m_pDownloadFile>%4C2B6D04000F.role preserve=no  public: DownloadFile { -> RFHgN}
      DownloadFile *m_pDownloadFile;
      //## end VROLInterface::<m_pDownloadFile>%4C2B6D04000F.role

      //## Association: DataNavigator Foundation::Application::VROLInterface_CAT::<unnamed>%4C2B6D0A03B8
      //## Role: VROLInterface::<m_pUploadFile>%4C2B6D0B028F
      //## begin VROLInterface::<m_pUploadFile>%4C2B6D0B028F.role preserve=no  public: UploadFile { -> RFHgN}
      //UploadFile *m_pUploadFile;
      //## end VROLInterface::<m_pUploadFile>%4C2B6D0B028F.role

      //## Association: DataNavigator Foundation::Application::VROLInterface_CAT::<unnamed>%55C4FBD40231
      //## Role: VROLInterface::<m_pECHISTUploadFile>%55C4FBD50104
      //## begin VROLInterface::<m_pECHISTUploadFile>%55C4FBD50104.role preserve=no  public: ECHISTUploadFile { -> RFHgN}
      ECHISTUploadFile *m_pECHISTUploadFile;
      //## end VROLInterface::<m_pECHISTUploadFile>%55C4FBD50104.role

      //## Association: DataNavigator Foundation::Application::VROLInterface_CAT::<unnamed>%55C4FBE001A4
      //## Role: VROLInterface::<m_pVROLUploadFile>%55C4FBE1003D
      //## begin VROLInterface::<m_pVROLUploadFile>%55C4FBE1003D.role preserve=no  public: VROLUploadFile { -> RFHgN}
      VROLUploadFile *m_pVROLUploadFile;
      //## end VROLInterface::<m_pVROLUploadFile>%55C4FBE1003D.role

      //## Association: DataNavigator Foundation::Application::VROLInterface_CAT::<unnamed>%55C4FBE90094
      //## Role: VROLInterface::<m_pBAMSUploadFile>%55C4FBEA0025
      //## begin VROLInterface::<m_pBAMSUploadFile>%55C4FBEA0025.role preserve=no  public: BAMSUploadFile { -> RFHgN}
      BAMSUploadFile *m_pBAMSUploadFile;
      //## end VROLInterface::<m_pBAMSUploadFile>%55C4FBEA0025.role

      //## Association: DataNavigator Foundation::Application::VROLInterface_CAT::<unnamed>%55C4FBEF02CB
      //## Role: VROLInterface::<m_pMasterCardUploadFile>%55C4FBF00127
      //## begin VROLInterface::<m_pMasterCardUploadFile>%55C4FBF00127.role preserve=no  public: MasterCardUploadFile { -> RFHgN}
      MasterCardUploadFile *m_pMasterCardUploadFile;
      EncryptDocuments *m_pEncryptDocuments;
      //## end VROLInterface::<m_pMasterCardUploadFile>%55C4FBF00127.role

      //## Association: DataNavigator Foundation::Application::VROLInterface_CAT::<unnamed>%55C4FF5901FE
      //## Role: VROLInterface::<m_hCommand>%55C4FF5A01BD
      //## begin VROLInterface::<m_hCommand>%55C4FF5A01BD.role preserve=no  public: segment::Command {1 -> 0..nRHgN}
      vector<segment::Command*> m_hCommand;
      //## end VROLInterface::<m_hCommand>%55C4FF5A01BD.role

      //## Association: DataNavigator Foundation::Application::VROLInterface_CAT::<unnamed>%55C503EE0068
      //## Role: VROLInterface::<m_hTimer>%55C503EF0075
      //## begin VROLInterface::<m_hTimer>%55C503EF0075.role preserve=no  public: timer::Timer { -> VHgN}
      timer::Timer m_hTimer;
      //## end VROLInterface::<m_hTimer>%55C503EF0075.role

    // Additional Implementation Declarations
      //## begin VROLInterface%4C2B5F0000FE.implementation preserve=yes
      //## end VROLInterface%4C2B5F0000FE.implementation

};

//## begin VROLInterface%4C2B5F0000FE.postscript preserve=yes
//## end VROLInterface%4C2B5F0000FE.postscript

//## begin module%4C2B63E101F4.epilog preserve=yes
//## end module%4C2B63E101F4.epilog


#endif
