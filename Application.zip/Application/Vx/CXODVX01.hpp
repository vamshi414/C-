//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4C2B67DA03DB.cm preserve=no
//	$Date:   Aug 13 2019 09:46:40  $ $Author:   e5549623  $
//	$Revision:   1.19  $
//## end module%4C2B67DA03DB.cm

//## begin module%4C2B67DA03DB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4C2B67DA03DB.cp

//## Module: CXOSVX01%4C2B67DA03DB; Package specification
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R003\Windows\Build\Dn\Server\Application\Vx\CXODVX01.hpp

#ifndef CXOSVX01_h
#define CXOSVX01_h 1

//## begin module%4C2B67DA03DB.additionalIncludes preserve=no
//## end module%4C2B67DA03DB.additionalIncludes

//## begin module%4C2B67DA03DB.includes preserve=yes
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#include "CXODIF10.hpp"
//## end module%4C2B67DA03DB.includes

#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif
#ifndef CXOSVX02_h
#include "CXODVX02.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class ContactSegment;
class Customer;
} // namespace entitysegment

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ImportReportAuditSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Email;
} // namespace command

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;

} // namespace usersegment

//## begin module%4C2B67DA03DB.declarations preserve=no
//## end module%4C2B67DA03DB.declarations

//## begin module%4C2B67DA03DB.additionalDeclarations preserve=yes
//## end module%4C2B67DA03DB.additionalDeclarations


//## begin DownloadFile%4C2B622B026D.preface preserve=yes
//## end DownloadFile%4C2B622B026D.preface

//## Class: DownloadFile%4C2B622B026D
//	<body>
//	<title>CG
//	<h1>VX
//	<h2>FI
//	<h3>DM5 and DM3 download files
//	<p>
//	The DM5 and DM3 zip archives you receive from VISA must
//	be transmitted to the configured DVROL folder.
//	The files must be named as follows:
//	<ul>
//	<li>DM5<i>mdnn</i>.zip (e.g. DM54A00.zip)
//	<li>DM3<i>mdnn</i>.zip (e.g. DM34A00.zip)
//	</ul>
//	<p>
//	The VROL Interface service extracts the pending zip
//	archives into the XML and TIFF files.
//	The TIFF files are retained on the image server to allow
//	display on the DataNavigator client.
//	This XML is sent via ftp to a DataNavigator server on
//	IBM zSeries to create and update the related cases in
//	EMS.
//	<p>
//	The dataset name on the host is set with the VROLD5
//	parameter:
//	<ul>
//	<li><i>VROLD5</i>.BDM5<i>mdnn</i> (e.g. DN.VROL.BDM53A00)
//	<li><i>VROLD5</i>.RDM5<i>mdnn</i>.BDM5<i>mdnn</i> (e.g.
//	DN.VROL.RDM53A00.BDM53A00)
//	</ul>
//	The syntax of the zip command can be set with the ZIPCOM
//	parameter.
//	<p>
//	For transmission via ftp to your host system, configure
//	the FTPIBMH, FTPUSRID, FTPPSWRD and FTPSEND parameters.
//	<p>
//	The VROL Interface service will move the file from the
//	DVROL folder to the DCOMPLET folder named as follows:
//	<ul>
//	<li>original_DM5<i>mdnn</i>.zip
//	</ul>
//	The DCOMPLET folder will also contain the XML files and
//	the ftp script used to send the XML to the IBM zSeries
//	host.
//	The DDOC folder will contain the extracted TIFF files.
//	A second location (DDOC1) for the TIFF files can also be
//	configured.
//	<p>
//	Configure the following files:
//	<p>
//	<table>
//	<tr>
//	<th>File
//	<th>Path
//	<th>Comments
//	<tr>
//	<td>DVROL
//	<td>VROL\Download\Pending\%member
//	<td>
//	<tr>
//	<td>DCOMPLET
//	<td>%o\Download\Complete\%f\%member
//	<td>
//	<tr>
//	<td>DDOC
//	<td>\DnDocs\Stage\%f\%member
//	<td>
//	<tr>
//	<td>DDOC1
//	<td>
//	<td>
//	</table>
//	<p>
//	Configure the following DSPEC entries:
//	<p>
//	<table>
//	<tr>
//	<th>Key
//	<th>Value
//	<th>Comments
//	<tr>
//	<td>DFOLDER
//	<td>DVROL
//	<td>A space delimited list of download folders
//	<tr>
//	<td>UNZIPCOM
//	<td>C:\PROGRA~1\WINZIP\WINZIP32.exe -e -o %f %d
//	<td>Zip command syntax
//	<tr>
//	<td>VROLD5
//	<td><i>IBM z/OS datatset name prefix</i>
//	<td>
//	<tr>
//	<td>FTPSEND
//	<td>ftp -i -s:"%f"
//	<td>ftp command syntax
//	<tr>
//	<td>FTPIBMH
//	<td><i>host</i>
//	<td>IBM z/OS host name
//	<tr>
//	<td>FTPUSRID
//	<td><i>User ID</i>
//	<td>IBM z/OS user ID
//	<tr>
//	<td>FTPPSWRD
//	<td><i>Password</i>
//	<td>IBM z/OS password
//	<tr>
//	<td>DDELDAY
//	<td>64
//	<td>Number of days to retain download files
//	<tr>
//	<td>EMAILADR
//	<td>
//	<td>
//	<tr>
//	<td>ERMAILNM
//	<td>10
//	<td>
//	</table>
//	<p>
//	</body>
//## Category: DataNavigator Foundation::Application::VROLInterface_CAT%4C2B5E9102E8
//## Subsystem: VX%4C2B63AB026E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4C2B6327016D;IF::FlatFile { -> F}
//## Uses: <unnamed>%4C3F530A0153;IF::Trace { -> F}
//## Uses: <unnamed>%4C60504B01B4;entitysegment::Customer { -> F}
//## Uses: <unnamed>%4C605BA1006A;timer::Date { -> F}
//## Uses: <unnamed>%4C7287600020;command::Email { -> F}
//## Uses: <unnamed>%4C7294FC00B2;entitysegment::ContactSegment { -> F}
//## Uses: <unnamed>%4C72951A0016;usersegment::EmailSegment { -> F}
//## Uses: <unnamed>%4C72E4250127;segment::ImportReportAuditSegment { -> F}
//## Uses: <unnamed>%4C73ED750268;timer::Clock { -> F}

class DllExport DownloadFile : public UploadFile  //## Inherits: <unnamed>%55CBA1D302C1
{
  //## begin DownloadFile%4C2B622B026D.initialDeclarations preserve=yes
  //## end DownloadFile%4C2B622B026D.initialDeclarations

  public:
    //## Constructors (generated)
      DownloadFile();

    //## Destructor (generated)
      virtual ~DownloadFile();


    //## Other Operations (specified)
      //## Operation: checkDocExtension%53D24D7B034F
      bool checkDocExtension (string strFileName);

      //## Operation: cleanup%4C695A6E0378
      void cleanup ();

      //## Operation: createDocumentFolder%5362A9B50010
      bool createDocumentFolder (const string& strFolder, string& strSource);

      //## Operation: createFolder%4D2E214401A8
      bool createFolder (const string& strFolder);

      //## Operation: email%4C72866602A7
      bool email ();

      //## Operation: execute%5612D0060397
      virtual bool execute ();

      //## Operation: finalizeFiles%4C5AD3E3012C
      virtual bool finalizeFiles ();

      //## Operation: finishFTP%4C6959F40302
      bool finishFTP ();

      //## Operation: finalizeNonVisaFiles%63D69A870343
      bool finalizeNonVisaFiles (char& cStatus);

      //## Operation: moveFinishedFiles%4C6EB2500376
      bool moveFinishedFiles (const string& strIdentifier);

      //## Operation: processBAMS%517588850372
      bool processBAMS (char& cStatus);

      //## Operation: processCommand%4FCFA6A80271
      bool processCommand (char& cStatus, const string& strFilename);

      //## Operation: processDocument%4C695B460013
      bool processDocument (const string& strFileName);

      //## Operation: processECHIST%4F593D120172
      bool processECHIST (char& cStatus);

      //## Operation: processMSTR%535E9CC2015E
      bool processMSTR (char& cStatus);

      //## Operation: processSTAR%63D6948B031D
      bool processSTAR (char& cStatus);

      //## Operation: processVRDM%4C695A250075
      bool processVRDM (char& cStatus);

      //## Operation: processZIP%5612D02A00A5
      virtual bool processZIP (const string& strFilename);

      //## Operation: readExtract%4C697E39022E
      virtual bool readExtract ();

      //## Operation: rebuildXML%4C587F0301E9
      bool rebuildXML (IF::FlatFile& hInFile, const bool& bIsHeader = false);

      //## Operation: resetVars%4C6959A603A7
      virtual void resetVars ();

      //## Operation: restoreFiles%4C5AD32B0242
      virtual void restoreFiles ();

      //## Operation: sendStatus%517586A90334
      virtual void sendStatus (char& cStatus, const string& strReason);

      //## Operation: setSpaceParam%5D4AE66C010F
      virtual void setSpaceParam ();

      //## Operation: setupDGMCFTP%55CA3787015F
      bool setupDGMCFTP ();

      //## Operation: setupFTP%4C6959CA0010
      bool setupFTP ();

    // Additional Public Declarations
      //## begin DownloadFile%4C2B622B026D.public preserve=yes
      //## end DownloadFile%4C2B622B026D.public

  protected:
    // Additional Protected Declarations
      //## begin DownloadFile%4C2B622B026D.protected preserve=yes
      //## end DownloadFile%4C2B622B026D.protected

  private:
    // Additional Private Declarations
      //## begin DownloadFile%4C2B622B026D.private preserve=yes
	  	vector<string> m_hCustomers;
      //## end DownloadFile%4C2B622B026D.private
  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BodyFiles%4C695BE3015C
      //## begin DownloadFile::BodyFiles%4C695BE3015C.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hBodyFiles;
      //## end DownloadFile::BodyFiles%4C695BE3015C.attr

      //## Attribute: Customer%4D6CD095004E
      //## begin DownloadFile::Customer%4D6CD095004E.attr preserve=no  private: string {U} 
      string m_strCustomer;
      //## end DownloadFile::Customer%4D6CD095004E.attr

      //## Attribute: DocFileNames%53DA8DD700D3
      //## begin DownloadFile::DocFileNames%53DA8DD700D3.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hDocFileNames;
      //## end DownloadFile::DocFileNames%53DA8DD700D3.attr

      //## Attribute: Email%4C72B60900DD
      //## begin DownloadFile::Email%4C72B60900DD.attr preserve=no  private: command::Email* {U} 
      command::Email* m_pEmail;
      //## end DownloadFile::Email%4C72B60900DD.attr

      //## Attribute: EntityFolder%4D2E220302B1
      //## begin DownloadFile::EntityFolder%4D2E220302B1.attr preserve=no  private: string {U} 
      string m_strEntityFolder;
      //## end DownloadFile::EntityFolder%4D2E220302B1.attr

      //## Attribute: FTPIbmDsName%4C695BF300B0
      //## begin DownloadFile::FTPIbmDsName%4C695BF300B0.attr preserve=no  private: string {U} 
      string m_strFTPIbmDsName;
      //## end DownloadFile::FTPIbmDsName%4C695BF300B0.attr

      //## Attribute: HeaderFile%4C695C380245
      //## begin DownloadFile::HeaderFile%4C695C380245.attr preserve=no  private: string {U} 
      string m_strHeaderFile;
      //## end DownloadFile::HeaderFile%4C695C380245.attr

      //## Attribute: InvalidFileExtensions%53D396560209
      //## begin DownloadFile::InvalidFileExtensions%53D396560209.attr preserve=no  private: set<string> {U} 
      set<string> m_hInvalidFileExtensions;
      //## end DownloadFile::InvalidFileExtensions%53D396560209.attr

      //## Attribute: InvalidFiles%53D24D5E0273
      //## begin DownloadFile::InvalidFiles%53D24D5E0273.attr preserve=no  private: vector<string> {U} 
      vector<string> m_hInvalidFiles;
      //## end DownloadFile::InvalidFiles%53D24D5E0273.attr

      //## Attribute: MainFile%4C6EAEF502DA
      //## begin DownloadFile::MainFile%4C6EAEF502DA.attr preserve=no  private: string {U} 
      string m_strMainFile;
      //## end DownloadFile::MainFile%4C6EAEF502DA.attr

      //## Attribute: FTPScriptFile1%5B3114E50301
      //## begin DownloadFile::FTPScriptFile1%5B3114E50301.attr preserve=no  private: IF::FlatFile {U} 
      IF::FlatFile m_hFTPScriptFile1;
      //## end DownloadFile::FTPScriptFile1%5B3114E50301.attr

      //## Attribute: ValidFileExtensions%5B3113CA01DB
      //## begin DownloadFile::ValidFileExtensions%5B3113CA01DB.attr preserve=no  private: set<string> {U} 
      set<string> m_hValidFileExtensions;
      //## end DownloadFile::ValidFileExtensions%5B3113CA01DB.attr

      //## Attribute: DocPath%63D6A7790082
      //## begin DownloadFile::DocPath%63D6A7790082.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strDocPath;
      //## end DownloadFile::DocPath%63D6A7790082.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::VROLInterface_CAT::<unnamed>%4DD2E36B0239
      //## Role: DownloadFile::<m_hTimer>%4DD2E36C01EA
      //## begin DownloadFile::<m_hTimer>%4DD2E36C01EA.role preserve=no  public: timer::Timer { -> VHgN}
      timer::Timer m_hTimer;
      //## end DownloadFile::<m_hTimer>%4DD2E36C01EA.role

};

//## begin DownloadFile%4C2B622B026D.postscript preserve=yes
//## end DownloadFile%4C2B622B026D.postscript

//## begin module%4C2B67DA03DB.epilog preserve=yes
//## end module%4C2B67DA03DB.epilog


#endif
