//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%530D1AF202A4.cm preserve=no
//	$Date:   May 13 2020 13:17:26  $ $Author:   e1009510  $
//	$Revision:   1.10  $
//## end module%530D1AF202A4.cm

//## begin module%530D1AF202A4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%530D1AF202A4.cp

//## Module: CXOSVX09%530D1AF202A4; Package body
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R003\Windows\Build\Dn\Server\Application\Vx\CXOSVX09.cpp

//## begin module%530D1AF202A4.additionalIncludes preserve=no
//## end module%530D1AF202A4.additionalIncludes

//## begin module%530D1AF202A4.includes preserve=yes
//## end module%530D1AF202A4.includes

#ifndef CXOSBS24_h
#include "CXODBS24.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSVX09_h
#include "CXODVX09.hpp"
#endif


//## begin module%530D1AF202A4.declarations preserve=no
//## end module%530D1AF202A4.declarations

//## begin module%530D1AF202A4.additionalDeclarations preserve=yes
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <io.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>
#include <direct.h>
#endif
//## end module%530D1AF202A4.additionalDeclarations


// Class MasterCardUploadFile 

MasterCardUploadFile::MasterCardUploadFile()
  //## begin MasterCardUploadFile::MasterCardUploadFile%530CFC0E0155_const.hasinit preserve=no
  //## end MasterCardUploadFile::MasterCardUploadFile%530CFC0E0155_const.hasinit
  //## begin MasterCardUploadFile::MasterCardUploadFile%530CFC0E0155_const.initialization preserve=yes
  //## end MasterCardUploadFile::MasterCardUploadFile%530CFC0E0155_const.initialization
{
  //## begin MasterCardUploadFile::MasterCardUploadFile%530CFC0E0155_const.body preserve=yes
   memcpy(m_sID,"VX09",4);
   if(!readExtract())
      Trace::put("UploadFile::Extract is not correctly configured");
  //## end MasterCardUploadFile::MasterCardUploadFile%530CFC0E0155_const.body
}


MasterCardUploadFile::~MasterCardUploadFile()
{
  //## begin MasterCardUploadFile::~MasterCardUploadFile%530CFC0E0155_dest.body preserve=yes
  //## end MasterCardUploadFile::~MasterCardUploadFile%530CFC0E0155_dest.body
}



//## Other Operations (implementation)
string MasterCardUploadFile::buildFile (char& cStatus, const string& strFilename)
{
  //## begin MasterCardUploadFile::buildFile%531E73BA03C1.body preserve=yes
   m_strFilename = strFilename;
   string strTemp;
   if (!Extract::instance()->find("DFILES  MSTRTEMP",strTemp))
   {
      Trace::put("MSTRTEMP is not set up");
      return "MSTRTEMP is not set up";
   }
   string strTempFileName;
   FlatFile hPendingFile("UPENDING");
   hPendingFile.setMember(strFilename.c_str());
   if (!hPendingFile.open(FlatFile::CX_OPEN_INPUT))
   {
      cStatus = 'N';
      hPendingFile.close();
      return "No body file has been found: "+hPendingFile.getName();
   }
   size_t pos = hPendingFile.getDatasetName().find_last_of('\\');
   if (pos != string::npos)
   {
      string strFolderName(hPendingFile.getDatasetName().data(),0,pos);
      if (strFolderName[2] == '\\')
      {
         m_strFolderName = "\\\\";
         m_strFolderName.append(Extract::instance()->getHost());
         m_strFolderName.append(strFolderName.substr(2));
      }
      else
         m_strFolderName = strFolderName;
   }
   hPendingFile.getBaseName(strTempFileName,true);
   m_strBatchBaseName = strTempFileName;
   m_strDocFile = "MCOUT.D";
   m_strDocFile.append(Clock::instance()->getYYYYMMDDHHMMSS(),0,8);
   m_strDocFile.append(".T");
   m_strDocFile.append(Clock::instance()->getYYYYMMDDHHMMSS(),8,6);
   m_strBatchOrigName = m_strDocFile;
   m_strDocFile.append(".zip");
   FlatFile hPendingFile1("UPENDING");
   hPendingFile1.setMember(m_strBatchBaseName.c_str());
   if (!hPendingFile1.open(FlatFile::CX_OPEN_INPUT))
   {
      hPendingFile1.close();
      return "Unable to open BUA file for rebuild: "+hPendingFile.getName();
   }
   hPendingFile1.close();

   ImportReportAuditSegment::instance()->setFILE(m_strBatchBaseName);
   hPendingFile.move("UPENDING",("original_"+strTempFileName).c_str());
   hPendingFile.close();
   hPendingFile.setMember(("original_"+strTempFileName).c_str());
   if (!hPendingFile.open(FlatFile::CX_OPEN_INPUT))
      return "Body file cannot be opened for restructuring";	
   if (!rebuildBatchXML(hPendingFile,strTempFileName))
   {
      hPendingFile.move("UCOMPLET",("original_" + m_strBatchBaseName).c_str());
      hPendingFile.close();
      Trace::put("MasterCard file has no records");
      return "MasterCard file has no records";
   }
   hPendingFile.move("UCOMPLET",("original_" + m_strBatchBaseName).c_str());
   hPendingFile.close();
   if (!createICUFiles())
   {
      Trace::put("MasterCard ICU Files copy failed");
      return "MatserCard ICU Files copy failed";
   }
   if (!zipImages())
   {
      Trace::put("MasterCard Upload Zip failed");
      return "MatserCard Upload Zip failed";
   }
   Extract::instance()->getSpec("WEBSER",strTemp);
   if (strTemp != "ON")
   {
      if (!processMSTRZIP(m_strFilename))
       return "MasterCard Upload is failed during ZIP process";
   }
   return "MasterCard Upload is completed";
  //## end MasterCardUploadFile::buildFile%531E73BA03C1.body
}

bool MasterCardUploadFile::createICUFiles ()
{
  //## begin MasterCardUploadFile::createICUFiles%5320791D02E4.body preserve=yes
   FlatFile hOutFile("MSTRTEMP");
   int i = 1;
   if (m_hXML.size() > 0)
   {
      map<string, vector<string>, less<string> >::iterator q;
      for (q = m_hXML.begin();q != m_hXML.end();++q)
      {
         hOutFile.setMember(((*q).first + ".xml").c_str());
         if (!hOutFile.open(FlatFile::CX_OPEN_OUTPUT))
            return false;
         size_t pos = hOutFile.getDatasetName().find_last_of('\\');
         string strTempXML;
         string strFolderName;
         if (pos != string::npos)
         {
            strFolderName = hOutFile.getDatasetName();
            strTempXML = "****";
            if (strFolderName[2] == '\\')
            {
               strTempXML.append("\\\\");
               strTempXML.append(Extract::instance()->getHost());
               strTempXML.append(strFolderName.substr(2));
            }
            else
               strTempXML.append(strFolderName);
         }
         m_hXMLFiles.push_back(strTempXML);
         vector<string> hTags = (*q).second;
         vector<string>::iterator p;
         bool bDocument(false);
         hOutFile.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?>",56); 
         for (p = hTags.begin();p != hTags.end();++p)
         {
            if ((*p).find("<pds252_image_meta_data>") != string::npos)
               bDocument = true;
            if (bDocument && (*p).find("<s4>") != string::npos)
            {
               string strTemp("<s4>");
               strTemp.append((*q).first);
               strTemp.append("</s4>");
               hOutFile.write((char*)strTemp.data(),strTemp.length());
               bDocument = false;
            }
            else
            if ((*p).find("Wrapper") == string::npos)
               hOutFile.write((char*)(*p).data(),(*p).length());
         }
         hOutFile.close();
      }
   }
   return true;
  //## end MasterCardUploadFile::createICUFiles%5320791D02E4.body
}

bool MasterCardUploadFile::execute ()
{
  //## begin MasterCardUploadFile::execute%55C8BA0B002A.body preserve=yes
   m_hXMLFiles.erase(m_hXMLFiles.begin(),m_hXMLFiles.end());
   m_hXML.erase(m_hXML.begin(),m_hXML.end());
   if (m_bStatus)
   {
      Trace::put("MasterCard Upload is not picked up for processing");
      return false;
   }
   resetVars();
   char cStatus = 'F';
   string strReason;
   FlatFile hRemoveFile("MSTRTEMP");
   hRemoveFile.setMember("*");
   hRemoveFile.remove();
   hRemoveFile.close();
   FlatFile hTestFile("UPENDING");
   hTestFile.setMember("*.xml");
   hTestFile.remove();
   hTestFile.close();
   sendStatus(cStatus,strReason);
   m_bDownloadFile = false;
   strReason = buildFile(cStatus,"MCOUT*");
  // restoreFiles();
   return true;
  //## end MasterCardUploadFile::execute%55C8BA0B002A.body
}

bool MasterCardUploadFile::rebuildBatchXML (IF::FlatFile& hInFile, const string& strOutputXMLFile)
{
  //## begin MasterCardUploadFile::rebuildBatchXML%531F4F0D02C4.body preserve=yes
   string strLine;   
   string strRollOverTag;
   //Creates buffer for reading chunks of file
   char szTempLine[BUFFER_SIZE +1];
   size_t iReadSize = BUFFER_SIZE;
   bool bNoValidPrevLine = true;
   string strStartTag,strEndTag,strPrevLine;   
   int nPos,nPos1,nPos2,nPos3,nPos4;
   int icuseq = 0;
   string strIcuSeq("scu");
   char szTemp[11];
   string prestrIcuSeq;
   bool bFirstTime(true);
   while (hInFile.read(szTempLine,BUFFER_SIZE+1,&iReadSize)==true )
   {
      strStartTag.erase();
      strEndTag.erase();
      nPos = strLine.find_first_of("<");
      nPos1 = strLine.find_first_of(">");
      if(nPos != string::npos && nPos1 != string::npos)
         strStartTag = strLine.substr((nPos + 1),(nPos1-(nPos+1)));
      strLine = strRollOverTag + szTempLine;
      nPos2 = strLine.find("</");
      nPos3 = strLine.find_last_of(">");
      if(nPos2 != string::npos && nPos3 != string::npos)
         strEndTag = strLine.substr((nPos2 + 2),(nPos3 - (nPos2 + 2)));     
      strRollOverTag.clear();
      //removes trailing whitespace
      strLine.erase(strLine.find_last_not_of(' ')+1,string::npos);
      if (strLine.find("<icu>") != string::npos)
      {
        icuseq ++;
        strIcuSeq = "ICU";
        snprintf(szTemp,sizeof(szTemp),"%010d",icuseq);
        strIcuSeq.append(szTemp);
        if (bFirstTime)
        {
            bFirstTime = false;
            prestrIcuSeq = strIcuSeq;
         }
      }
      if (strLine.find("<scu>") != string::npos)
      {
        icuseq ++;
        strIcuSeq = "SCU";
        snprintf(szTemp,sizeof(szTemp),"%010d",icuseq);
        strIcuSeq.append(szTemp);
        if (bFirstTime)
        {
            bFirstTime = false;
            prestrIcuSeq = strIcuSeq;
         }
      }
      if(strLine.compare(0,5,"copy ")== 0)
      {
         nPos4 = strLine.find(" scu");
         if (nPos4 == string::npos)
            nPos4 = strLine.find(" icu");
         string strTemp1;
         strTemp1.assign(strLine,5,nPos4-4);
         strTemp1.append(prestrIcuSeq);
         m_hTifDocs.push_back(strTemp1);
       }  
      else if(strLine.size()!=0
         && strLine.find_first_not_of(' ')!= string::npos)//if all characters in the line are not whitespaces
      {         
         if(strLine.find_last_not_of(' ')==strLine.find_last_of('>')) //if last character in line is a >
         {
            removePatterns(strLine);
            if(bNoValidPrevLine)
            {
               strPrevLine = strLine;
               bNoValidPrevLine = false;
               continue;                
            }
            if(strStartTag.length() && strStartTag == strEndTag && strRollOverTag.length() == 0)
            {
               strPrevLine += strLine;
               removePatterns(strPrevLine);                  
               bNoValidPrevLine = true;               
            }
            if(strLine.find("<EFUNDS_") == string::npos 
               && strLine.find("</EFUNDS_") == string::npos
               && strLine.size()!=0
               && strLine.find_first_not_of(' ')!= string::npos)
            {
               map<string, vector<string>, less<string> >::iterator q;
               q = m_hXML.find(prestrIcuSeq);
               if(q != m_hXML.end())
               {
                  (*q).second.push_back(strPrevLine);      
               }
               else
               {
                  vector<string> hTags;
                  hTags.push_back(strPrevLine);
                  m_hXML.insert(map<string,vector<string>,less<string> >::value_type(prestrIcuSeq,hTags));
               }
               if (strPrevLine.find("</icu>") != string::npos
                  || strPrevLine.find("</scu>") != string::npos)
                  prestrIcuSeq = strIcuSeq;
               strPrevLine = strLine;                               
            }
            strRollOverTag="";
         }
         else
            strRollOverTag += strLine;
         
      }
   }
   map<string, vector<string>, less<string> >::iterator q;
   q = m_hXML.find(prestrIcuSeq);
   if(q != m_hXML.end())
   {
      (*q).second.push_back(strPrevLine);      
   }
   else
   {
      vector<string> hTags;
      hTags.push_back(strPrevLine);
      m_hXML.insert(map<string,vector<string>,less<string> >::value_type(prestrIcuSeq,hTags));
   }
   return (icuseq > 0);
  //## end MasterCardUploadFile::rebuildBatchXML%531F4F0D02C4.body
}

bool MasterCardUploadFile::rebuildDescriptorXML (IF::FlatFile& hInFile, const string& strOutputXMLFile)
{
  //## begin MasterCardUploadFile::rebuildDescriptorXML%531E73BA03BE.body preserve=yes
	return true;
  //## end MasterCardUploadFile::rebuildDescriptorXML%531E73BA03BE.body
}

bool MasterCardUploadFile::zipImages ()
{
  //## begin MasterCardUploadFile::zipImages%532085C90014.body preserve=yes
   int iErrorCount=0;
   string strFileLocation; 
   string strFileDestinationName;
   vector<string>::iterator pItr;
   size_t nPos1;
   string strTemp;
   Extract::instance()->getSpec("WEBSER",strTemp);
   if (strTemp == "ON")
   {
      m_hFileName = "VX09";
      string strLine;
      FlatFile hOutFile("UCOMPLET");
      string strTemp("DECRYPT");
      strTemp.append(Clock::instance()->getYYYYMMDDHHMMSS());
      strTemp.append(".txt");
      hOutFile.setMember(strTemp.c_str());
      hOutFile.setOwner("DECRYPT");
      hOutFile.setMember(strTemp.c_str());
      if (!hOutFile.open(FlatFile::CX_OPEN_OUTPUT))
         return false;
      string strFile = hOutFile.getDatasetName();
      string strXMLText("<DocDecryptOsi>");
      strXMLText += "<Folder>";
      string strLETTER_STORAGE_LOCATION;
      string strSearch1;
      string strSearch2;
      if (Extract::instance()->getSpec("WEBDOC",strLETTER_STORAGE_LOCATION))
      {
         strSearch1.assign(m_strFolderName);
         transform (strSearch1.begin(),strSearch1.end(), strSearch1.begin(), ::toupper);
         strSearch2 = strLETTER_STORAGE_LOCATION;
         transform (strSearch2.begin(),strSearch2.end(), strSearch2.begin(), ::toupper);
         size_t pos = strSearch1.find(strSearch2);
         if (pos != string::npos)
         {
            m_strFolderName.erase(pos,strLETTER_STORAGE_LOCATION.length());
            strSearch1.assign(strFile);
            transform (strSearch1.begin(),strSearch1.end(), strSearch1.begin(), ::toupper);
            pos = strSearch1.find(strSearch2);
            if (pos != string::npos)
               strFile.erase(pos,strLETTER_STORAGE_LOCATION.length());
         }
      }
      strXMLText += m_strFolderName;
      strXMLText += "</Folder>";
      strXMLText += "<ZipName>";
      strXMLText += m_strDocFile;
      strXMLText += "</ZipName>";
      for(pItr = m_hTifDocs.begin(); pItr != m_hTifDocs.end(); pItr++)
      {
         string strTemp(*pItr);
         nPos1 = strTemp.find(" SCU");
         if (nPos1 == string::npos)
            nPos1 = strTemp.find(" ICU");
         string strExtension(".TIF");
         if (strTemp.find(strExtension) == string::npos)
             strExtension = ".JPG";
         if (strTemp.find(strExtension) == string::npos)
             strExtension = ".PDF";
         if (strTemp.find(strExtension) == string::npos)
             strExtension = ".tif";
         if (strTemp.find(strExtension) == string::npos)
             strExtension = ".jpg";
         if (strTemp.find(strExtension) == string::npos)
             strExtension = ".pdf";
         strFileDestinationName.assign(strTemp,nPos1 + 1,strTemp.length() - nPos1);
         strFileDestinationName.append(strExtension.c_str());
         strFileLocation.assign(strTemp,0,nPos1);
         strLine = strFileLocation;
         strLine += " ";
         strLine += strFileDestinationName;
         if (Extract::instance()->getSpec("WEBDOC",strLETTER_STORAGE_LOCATION))
         {
            strSearch1.assign(strLine);
            transform (strSearch1.begin(),strSearch1.end(), strSearch1.begin(), ::toupper);
            size_t pos = strSearch1.find(strSearch2);
            if (pos != string::npos)
               strLine.erase(pos, strLETTER_STORAGE_LOCATION.length());
         }
         hOutFile.write((char*)strLine.data(),strLine.length());
      }
      for(pItr = m_hXMLFiles.begin(); pItr != m_hXMLFiles.end(); pItr++)
      {
         if (Extract::instance()->getSpec("WEBDOC",strLETTER_STORAGE_LOCATION))
         {
            strSearch1.assign((*pItr));
            transform (strSearch1.begin(),strSearch1.end(), strSearch1.begin(), ::toupper);
            size_t pos = strSearch1.find(strSearch2);
            if (pos != string::npos)
               (*pItr).erase(pos, strLETTER_STORAGE_LOCATION.length());
         }
         hOutFile.write((char*)(*pItr).data(),(*pItr).length());
      }
      hOutFile.close();
      strXMLText += "<FileName>";
      strXMLText += strFile;
      strXMLText += "</FileName>";
      strXMLText += "</DocDecryptOsi>";
      m_bStatus = true;
      if (!post(strXMLText))
      {
         m_bStatus = false;
         Trace::put("Not able to connect to the server");
         return false;
      }
   }
   else
   {
      FlatFile hImageFile("");
      for(pItr = m_hTifDocs.begin(); pItr != m_hTifDocs.end(); pItr++)
      {
         string strTemp(*pItr);
         nPos1 = strTemp.find(" SCU");
         if (nPos1 == string::npos)
            nPos1 = strTemp.find(" ICU");
         strFileDestinationName.assign(strTemp,nPos1 + 1,strTemp.length() - nPos1);
         strFileDestinationName.append(".TIF");
         strFileLocation.assign(strTemp,0,nPos1);
         hImageFile.setDatasetName(strFileLocation.c_str());
         if(!hImageFile.copy("MSTRTEMP",strFileDestinationName.c_str()))
         {
            iErrorCount++;
            if(iErrorCount == m_iMinimumTifError)
               return false;
         }
      }
      FlatFile hLocalImageFiles("");
      hLocalImageFiles.setMember("*");      
      hLocalImageFiles.setName("MSTRTEMP");
      if(!(hLocalImageFiles.zip(m_strDocFile)))
         return false;
      hLocalImageFiles.setMember(m_strDocFile.c_str());
      if (!hLocalImageFiles.open(FlatFile::CX_OPEN_INPUT))
      {
         Trace::put("MasterCard Zip File is not created");
         return false;
      }
      hLocalImageFiles.move("UPENDING",m_strDocFile.c_str());
      hLocalImageFiles.close();
      hLocalImageFiles.setMember("*");
      hLocalImageFiles.setName("MSTRTEMP");
      hLocalImageFiles.remove();
      hLocalImageFiles.setMember(m_strDocFile.c_str());
      hLocalImageFiles.setName("UPENDING");
      if (!hLocalImageFiles.open(FlatFile::CX_OPEN_INPUT))
      {
         Trace::put("Image Zip File is not created");
         return false;
      }
      hLocalImageFiles.close();
   }
   return true;
  //## end MasterCardUploadFile::zipImages%532085C90014.body
}

/*bool MasterCardUploadFile::processZIP (const string& strFilename)
{
  //## begin MasterCardUploadFile::processZIP%55CCD6670199.body preserve=yes
   string strOwner("MSTR");
   string strFTPDatasetName;
   if (finalizeFiles(strOwner))
   {
      if (writeFTPScript(strFTPDatasetName, strOwner))
      {
         if (executeFTPScript())
         {
            Trace::put("Successfully Uploaded: ");
            return true;
         }
         else
         {
            Trace::put("Unsuccessful execution of the FTP script");
            return false;
         }
      }
      else
      {
         if (strFTPDatasetName.length() > 0) 
         {
            Trace::put(" Dspec entry is not set up to FTP to IBM"); 
            return false;
         }
         else
         {
            Trace::put("File length downloaded to PC is less than 11 characters");
            return false;
         }
       }
   }
   else
   {    
      Trace::put("MasterCard Finalize Files failed");
      return false;
   }
   return false;
  //## end MasterCardUploadFile::processZIP%55CCD6670199.body
}*/

// Additional Declarations
  //## begin MasterCardUploadFile%530CFC0E0155.declarations preserve=yes
  //## end MasterCardUploadFile%530CFC0E0155.declarations

//## begin module%530D1AF202A4.epilog preserve=yes
//## end module%530D1AF202A4.epilog
