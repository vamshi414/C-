//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%556C8CB2023E.cm preserve=no
//	$Date:   May 13 2020 13:17:28  $ $Author:   e1009510  $
//	$Revision:   1.6  $
//## end module%556C8CB2023E.cm

//## begin module%556C8CB2023E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%556C8CB2023E.cp

//## Module: CXOSVX11%556C8CB2023E; Package body
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R003\Windows\Build\Dn\Server\Application\Vx\CXOSVX11.cpp

//## begin module%556C8CB2023E.additionalIncludes preserve=no
//## end module%556C8CB2023E.additionalIncludes

//## begin module%556C8CB2023E.includes preserve=yes
//## end module%556C8CB2023E.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSVX12_h
#include "CXODVX12.hpp"
#endif
#ifndef CXOSVX11_h
#include "CXODVX11.hpp"
#endif


//## begin module%556C8CB2023E.declarations preserve=no
//## end module%556C8CB2023E.declarations

//## begin module%556C8CB2023E.additionalDeclarations preserve=yes
//## end module%556C8CB2023E.additionalDeclarations


// Class DocumentInquiry 

DocumentInquiry::DocumentInquiry()
  //## begin DocumentInquiry::DocumentInquiry%556C9EDE02D9_const.hasinit preserve=no
  //## end DocumentInquiry::DocumentInquiry%556C9EDE02D9_const.hasinit
  //## begin DocumentInquiry::DocumentInquiry%556C9EDE02D9_const.initialization preserve=yes
  //## end DocumentInquiry::DocumentInquiry%556C9EDE02D9_const.initialization
{
  //## begin DocumentInquiry::DocumentInquiry%556C9EDE02D9_const.body preserve=yes
   memcpy(reusable::Object::m_sID,"VX11",4);
   m_pXMLItem = new DocumentInquiryItem();
  //## end DocumentInquiry::DocumentInquiry%556C9EDE02D9_const.body
}


DocumentInquiry::~DocumentInquiry()
{
  //## begin DocumentInquiry::~DocumentInquiry%556C9EDE02D9_dest.body preserve=yes
   delete m_pXMLItem;
  //## end DocumentInquiry::~DocumentInquiry%556C9EDE02D9_dest.body
}



//## Other Operations (implementation)
bool DocumentInquiry::post (const char* pszName, segment::Command* pCommand)
{
  //## begin DocumentInquiry::post%556CC2D20285.body preserve=yes  
   string strXMLText("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
   if (m_strxmlText.find("DocEncryptOsi") != string::npos)
      strXMLText.append("<DocEncryptRqst>");
   else
   if (m_strxmlText.find("DocDecryptOsi") != string::npos) 
      strXMLText.append("<DocDecryptRqst>");
   else
      strXMLText.append("<EncryptExistDocRqst>");
   strXMLText.append("<RqstHdr>"
   "<RqstHdrVer>2.0.0</RqstHdrVer>"
   "<MsgUuid>00000000-0000-0000-0000-000000000000</MsgUuid>"
   "<SrcId>WEB Application Server</SrcId>"
   "<LclPref>en-US</LclPref>"
   "<Sec>"
   "   <BasicAuthen>"
   "     <UsrId>xxxxx</UsrId>"
   "     <Pswrd>xxxxxx</Pswrd>"
   "   </BasicAuthen>"
   " </Sec>"
   " <ServPrmtrsLst>"
   "   <ServPrmtrs>"
   "     <FeId>GOLD</FeId>");
   if (m_strxmlText.find("DocEncryptOsi") != string::npos)
      strXMLText.append("<ServId>XDENCR</ServId>");
   else
   if (m_strxmlText.find("DocDecryptOsi") != string::npos)
      strXMLText.append("<ServId>XDDECR</ServId>");
   else
      strXMLText.append("<ServId>XNCDOCS</ServId>");
   strXMLText.append("     <ServVer>2.5.001</ServVer>"
   "     <ApplId>FIS DataNavigator</ApplId>"
   "   </ServPrmtrs>"
   " </ServPrmtrsLst>"
  "</RqstHdr>");
   strXMLText.append(m_strxmlText);
   string strTemp1;
   string strTemp2;
   Extract::instance()->getSpec("DOCL",strTemp1);
   size_t pos = strTemp1.find("~");
   strTemp1.replace(pos,1,":");
   Extract::instance()->getSpec("WEBROOT",strTemp2);
   if (m_strxmlText.find("DocEncryptOsi") != string::npos)
      strXMLText.append("</DocEncryptRqst>");
   else
   if (m_strxmlText.find("DocDecryptOsi") != string::npos) 
      strXMLText.append("</DocDecryptRqst>");
   else
      strXMLText.append("</EncryptExistDocRqst>");
   int i;
   if (m_strxmlText.find("DocEncryptOsi") != string::npos)
   {
       i = snprintf(IF::Message::instance(Message::OUTBOUND)->buffer(),MAX_BUFFER_SIZE,
      "POST /%s"
	  "/service/docs/save HTTP/1.1\n"
      "Host: %s\n"
      "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; MS Web "
      "Services Client Protocol)\n"
      "Content-Type: application/xml; charset=utf-8\n"
      "Accept: application/xml\n"
      "Cache-Control: no-cache\n"
      "Content-Length: %04d\n\n",strTemp2.c_str(),strTemp1.c_str(),strXMLText.length());
   }
   else
   if (m_strxmlText.find("EncryptExistDocOsi") != string::npos )
   {
       i = snprintf(IF::Message::instance(Message::OUTBOUND)->buffer(),MAX_BUFFER_SIZE,
	  "POST /%s"
	  "/service/docs/encrypt HTTP/1.1\n"
      "Host: %s\n"
      "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; MS Web "
      "Services Client Protocol)\n"
      "Content-Type: application/xml; charset=utf-8\n"
      "Accept: application/xml\n"
      "Cache-Control: no-cache\n"
      "Content-Length: %04d\n\n",strTemp2.c_str(),strTemp1.c_str(),strXMLText.length());
   }
   else
   {
	   i = snprintf(IF::Message::instance(Message::OUTBOUND)->buffer(),MAX_BUFFER_SIZE,
	  "POST /%s"
      "/service/docs/retrieve HTTP/1.1\n"
      "Host: %s\n"
      "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; MS Web "
      "Services Client Protocol)\n"
      "Content-Type: application/xml; charset=utf-8\n"
      "Accept: application/xml\n"
      "Cache-Control: no-cache\n"
      "Content-Length: %04d\n\n",strTemp2.c_str(),strTemp1.c_str(),strXMLText.length());
   }

   memcpy(IF::Message::instance(Message::OUTBOUND)->buffer() + i,strXMLText.data(),strXMLText.length());
   IF::Message::instance(IF::Message::OUTBOUND)->setMessageLength(i + strXMLText.length());
   return command::SOAPService::post(pszName,pCommand,true);
  //## end DocumentInquiry::post%556CC2D20285.body
}

// Additional Declarations
  //## begin DocumentInquiry%556C9EDE02D9.declarations preserve=yes
  //## end DocumentInquiry%556C9EDE02D9.declarations

//## begin module%556C8CB2023E.epilog preserve=yes
//## end module%556C8CB2023E.epilog
