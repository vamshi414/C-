//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%530D1AF0032C.cm preserve=no
//	$Date:   Apr 15 2016 14:00:24  $ $Author:   e1009591  $
//	$Revision:   1.2  $
//## end module%530D1AF0032C.cm

//## begin module%530D1AF0032C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%530D1AF0032C.cp

//## Module: CXOSVX09%530D1AF0032C; Package specification
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R003\Windows\Build\Dn\Server\Application\Vx\CXODVX09.hpp

#ifndef CXOSVX09_h
#define CXOSVX09_h 1

//## begin module%530D1AF0032C.additionalIncludes preserve=no
//## end module%530D1AF0032C.additionalIncludes

//## begin module%530D1AF0032C.includes preserve=yes
//## end module%530D1AF0032C.includes

#ifndef CXOSVX02_h
#include "CXODVX02.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class FlatFile;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ImportReportAuditSegment;

} // namespace segment

//## begin module%530D1AF0032C.declarations preserve=no
//## end module%530D1AF0032C.declarations

//## begin module%530D1AF0032C.additionalDeclarations preserve=yes
//## end module%530D1AF0032C.additionalDeclarations


//## begin MasterCardUploadFile%530CFC0E0155.preface preserve=yes
//## end MasterCardUploadFile%530CFC0E0155.preface

//## Class: MasterCardUploadFile%530CFC0E0155
//## Category: DataNavigator Foundation::Application::VROLInterface_CAT%4C2B5E9102E8
//## Subsystem: VX%4C2B63AB026E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%531E73410349;segment::ImportReportAuditSegment { -> F}
//## Uses: <unnamed>%531E7345006D;timer::Clock { -> F}
//## Uses: <unnamed>%531E734A0138;IF::Trace { -> F}
//## Uses: <unnamed>%531E734E0225;IF::FlatFile { -> F}
//## Uses: <unnamed>%5320AB350369;IF::Extract { -> F}

class DllExport MasterCardUploadFile : public UploadFile  //## Inherits: <unnamed>%531E733C016A
{
  //## begin MasterCardUploadFile%530CFC0E0155.initialDeclarations preserve=yes
  //## end MasterCardUploadFile%530CFC0E0155.initialDeclarations

  public:
    //## Constructors (generated)
      MasterCardUploadFile();

    //## Destructor (generated)
      virtual ~MasterCardUploadFile();


    //## Other Operations (specified)
      //## Operation: buildFile%531E73BA03C1
      virtual string buildFile (char& cStatus, const string& strFilename);

      //## Operation: createICUFiles%5320791D02E4
      bool createICUFiles ();

      //## Operation: execute%55C8BA0B002A
      //	Perform the functions of this command.
      virtual bool execute ();

      //## Operation: rebuildBatchXML%531F4F0D02C4
      virtual bool rebuildBatchXML (IF::FlatFile& hInFile, const string& strOutputXMLFile);

      //## Operation: rebuildDescriptorXML%531E73BA03BE
      bool rebuildDescriptorXML (IF::FlatFile& hInFile, const string& strOutputXMLFile);

      //## Operation: zipImages%532085C90014
      virtual bool zipImages ();

      //## Operation: processZIP%55CCD6670199
//      virtual bool processZIP (const string& strFilename);

    // Additional Public Declarations
      //## begin MasterCardUploadFile%530CFC0E0155.public preserve=yes
      //## end MasterCardUploadFile%530CFC0E0155.public

  protected:
    // Additional Protected Declarations
      //## begin MasterCardUploadFile%530CFC0E0155.protected preserve=yes
      //## end MasterCardUploadFile%530CFC0E0155.protected

  private:
    // Additional Private Declarations
      //## begin MasterCardUploadFile%530CFC0E0155.private preserve=yes
      vector<string> m_hXMLFiles;
      //## end MasterCardUploadFile%530CFC0E0155.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin MasterCardUploadFile%530CFC0E0155.implementation preserve=yes
      map<string, vector<string>, less<string> > m_hXML;
      //## end MasterCardUploadFile%530CFC0E0155.implementation
};

//## begin MasterCardUploadFile%530CFC0E0155.postscript preserve=yes
//## end MasterCardUploadFile%530CFC0E0155.postscript

//## begin module%530D1AF0032C.epilog preserve=yes
//## end module%530D1AF0032C.epilog


#endif
