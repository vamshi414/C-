//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5612E38E02AB.cm preserve=no
//	$Date:   May 13 2020 13:17:28  $ $Author:   e1009510  $
//	$Revision:   1.4  $
//## end module%5612E38E02AB.cm

//## begin module%5612E38E02AB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5612E38E02AB.cp

//## Module: CXOSVX13%5612E38E02AB; Package body
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R011\Windows\Build\Dn\Server\Application\Vx\CXOSVX13.cpp

//## begin module%5612E38E02AB.additionalIncludes preserve=no
//## end module%5612E38E02AB.additionalIncludes

//## begin module%5612E38E02AB.includes preserve=yes
//## end module%5612E38E02AB.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSES49_h
#include "CXODES49.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSVX13_h
#include "CXODVX13.hpp"
#endif


//## begin module%5612E38E02AB.declarations preserve=no
//## end module%5612E38E02AB.declarations

//## begin module%5612E38E02AB.additionalDeclarations preserve=yes
//## end module%5612E38E02AB.additionalDeclarations


// Class EncryptDocuments 

EncryptDocuments::EncryptDocuments()
  //## begin EncryptDocuments::EncryptDocuments%5612E3080174_const.hasinit preserve=no
  //## end EncryptDocuments::EncryptDocuments%5612E3080174_const.hasinit
  //## begin EncryptDocuments::EncryptDocuments%5612E3080174_const.initialization preserve=yes
  //## end EncryptDocuments::EncryptDocuments%5612E3080174_const.initialization
{
  //## begin EncryptDocuments::EncryptDocuments%5612E3080174_const.body preserve=yes
   memcpy(m_sID,"VX13",4);
   int i = 0;
   string strRecord;
   vector<string> hTokens;
   while (IF::Extract::instance()->getRecord(i++,strRecord))
   {
      if (strRecord.length() > 16
         && strRecord.substr(0,16) == "DSPEC   DFOLDER ")
      {
          // DSPEC  DFOLDER DVROL DUSPS DCARD DAFFN
         if (Buffer::parse(strRecord," ",hTokens) >= 2)
         {
            for (int j = 2; j < hTokens.size(); ++j)
               m_hEncrypt.push_back(hTokens[j]);
         }
      }
   }
  //## end EncryptDocuments::EncryptDocuments%5612E3080174_const.body
}


EncryptDocuments::~EncryptDocuments()
{
  //## begin EncryptDocuments::~EncryptDocuments%5612E3080174_dest.body preserve=yes
  //## end EncryptDocuments::~EncryptDocuments%5612E3080174_dest.body
}



//## Other Operations (implementation)
bool EncryptDocuments::createFolder (const string& strFolder)
{
  //## begin EncryptDocuments::createFolder%5613EF5B025A.body preserve=yes
   FlatFile hCreateFolderFile(strFolder.c_str(),"foldercreator");
   hCreateFolderFile.setOwner(m_strEntityFolder);
   hCreateFolderFile.setFolder(m_strHeaderFile);
   if (!(hCreateFolderFile.open(FlatFile::CX_OPEN_OUTPUT)
      && hCreateFolderFile.close()
      && hCreateFolderFile.remove()))
      return false;
   return true;
  //## end EncryptDocuments::createFolder%5613EF5B025A.body
}

bool EncryptDocuments::execute ()
{
  //## begin EncryptDocuments::execute%5612E45D029C.body preserve=yes
   Trace::put("DownloadFile::execute()");
   if (m_bStatus)
   {
      Trace::put("VROL Download is not picked up for processing");
      return false;
   }
   m_hFileName = "VX13";
   char cStatus;
   bool b = false;
//   cleanup();
   for (int i = 0;i < m_hEncrypt.size();i++)
   {
      resetVars();
      cStatus = 'F';
      m_strCustomer = m_hEncrypt[i];
      m_strEntityFolder = m_strCustomer.substr(1,(m_strCustomer.length()-1));
      string strReason;
      if (m_strCustomer == "DENCR" && m_bStatus == false)
      {
         m_bDownloadFile = true;
         b = processENCRYPT(cStatus);
         Trace::put(strReason.data(), strReason.length());
         sendStatus(cStatus,strReason);
         if (b)
         {
            string strXMLText("<EncryptExistDocOsi>");
            strXMLText += "<FileName>";
            strXMLText += m_strFolderName;
            strXMLText += "</FileName>";
            strXMLText += "</EncryptExistDocOsi>";
            m_bStatus = true;
            if (!post(strXMLText))
            {
               m_bStatus = false;
               Trace::put("Not able to connect to the server");
               return false;
            }
            return true;
		 }
      }
   }
   return true;
  //## end EncryptDocuments::execute%5612E45D029C.body
}

bool EncryptDocuments::processENCRYPT (char& cStatus)
{
  //## begin EncryptDocuments::processENCRYPT%5613CCC80204.body preserve=yes
   Trace::put("VX01::processENCRYPT");
   FlatFile hPendingFile(m_strCustomer.c_str());
   hPendingFile.setMember("DOCE*");
   if (!hPendingFile.open(FlatFile::CX_OPEN_INPUT))
   {
      hPendingFile.close();
      cStatus = 'N';
      Trace::put("Cannot find Encrypt Files");
      return false;
   }
   hPendingFile.getBaseName(m_strMainFile,true);
   m_strHeaderFile = "ENCRYPT";
   m_strEntityFolder.assign(m_strMainFile,4,4);
   hPendingFile.setOwner(m_strEntityFolder);
   hPendingFile.setFolder(m_strHeaderFile);
   hPendingFile.setMember(m_strMainFile.c_str());
   if (!createFolder("DCOMPLET"))
   {
      cStatus = 'F';
      Trace::put("Failed to create DCOMMAND folder");
      return false;
   }
   hPendingFile.move("DCOMPLET", ("original_" + m_strMainFile).c_str());
   hPendingFile.close();
   FlatFile hPendingFile1("DCOMPLET");
   hPendingFile1.setOwner(m_strEntityFolder);
   hPendingFile1.setFolder(m_strHeaderFile);
   hPendingFile1.setMember(("original_" + m_strMainFile).c_str());
   if (!hPendingFile1.open(FlatFile::CX_OPEN_INPUT))
   {
      hPendingFile1.close();
      cStatus = 'N';
      Trace::put("Cannot find Encrypt Files");
      return false;
   }
   FlatFile hOutputFile("DCOMPLET",m_strMainFile.c_str());
   hOutputFile.setOwner(m_strEntityFolder);
   hOutputFile.setFolder(m_strHeaderFile);
   if (!hOutputFile.open(FlatFile::CX_OPEN_OUTPUT))
   {
      Trace::put("Not able to open file for encrypt output file");
      return false;
   }
   char szTempLine[BUFFER_SIZE +1];
   size_t iReadSize = BUFFER_SIZE;
   string strLine;
   string strSearch1;
   string strSearch2;
   string strLETTER_STORAGE_LOCATION;
   while (hPendingFile1.read(szTempLine,BUFFER_SIZE+1,&iReadSize)==true)
   {
      strLine = szTempLine;
      if (strLine.find("<DocPath>") != string::npos)
      {
         if (Extract::instance()->getSpec("WEBDOC",strLETTER_STORAGE_LOCATION))
         {
            strSearch1.assign(strLine);
            transform (strSearch1.begin(),strSearch1.end(), strSearch1.begin(), ::toupper);
            strSearch2 = strLETTER_STORAGE_LOCATION;
            transform (strSearch2.begin(),strSearch2.end(), strSearch2.begin(), ::toupper);
            size_t pos = strSearch1.find(strSearch2);
            if (pos != string::npos)
               strLine.erase(pos,strLETTER_STORAGE_LOCATION.length());
         }
      }
      hOutputFile.write((char*)strLine.data(),strLine.length());
   }
   hPendingFile1.close();
   size_t pos = hOutputFile.getDatasetName().find_last_of('\\');
   if (pos != string::npos)
   {
      string strFolderName(hOutputFile.getDatasetName().data(),0,pos);
      if (strFolderName[2] == '\\')
      {
         m_strFolderName = "\\\\";
         m_strFolderName.append(Extract::instance()->getHost());
         m_strFolderName.append(strFolderName.substr(2));
      }
      else
         m_strFolderName = strFolderName;
   }
   m_strFolderName.append("\\");
   m_strFolderName.append(m_strMainFile);
   if (Extract::instance()->getSpec("WEBDOC",strLETTER_STORAGE_LOCATION))
   {
      strSearch1.assign(m_strFolderName);
      transform (strSearch1.begin(),strSearch1.end(), strSearch1.begin(), ::toupper);
      strSearch2 = strLETTER_STORAGE_LOCATION;
	  transform(strSearch2.begin(), strSearch2.end(), strSearch2.begin(), ::toupper);
	  size_t pos = strSearch1.find(strSearch2);
      if (pos != string::npos)
          m_strFolderName.erase(pos,strLETTER_STORAGE_LOCATION.length());
   }
   hOutputFile.close();
   cStatus = 'S';
   return true;
  //## end EncryptDocuments::processENCRYPT%5613CCC80204.body
}

// Additional Declarations
  //## begin EncryptDocuments%5612E3080174.declarations preserve=yes
  //## end EncryptDocuments%5612E3080174.declarations

//## begin module%5612E38E02AB.epilog preserve=yes
//## end module%5612E38E02AB.epilog
