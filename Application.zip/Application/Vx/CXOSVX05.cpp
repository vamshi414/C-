//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5305112801EA.cm preserve=no
//	$Date:   May 13 2020 13:17:32  $ $Author:   e1009510  $
//	$Revision:   1.3  $
//## end module%5305112801EA.cm

//## begin module%5305112801EA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5305112801EA.cp

//## Module: CXOSVX05%5305112801EA; Package body
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R003\Windows\Build\Dn\Server\Application\Vx\CXOSVX05.cpp

//## begin module%5305112801EA.additionalIncludes preserve=no
//## end module%5305112801EA.additionalIncludes

//## begin module%5305112801EA.includes preserve=yes
//## end module%5305112801EA.includes

#ifndef CXOSBS24_h
#include "CXODBS24.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSVX05_h
#include "CXODVX05.hpp"
#endif


//## begin module%5305112801EA.declarations preserve=no
//## end module%5305112801EA.declarations

//## begin module%5305112801EA.additionalDeclarations preserve=yes
#define BUFFER_SIZE 32767
//## end module%5305112801EA.additionalDeclarations


// Class BAMSUploadFile 

BAMSUploadFile::BAMSUploadFile()
  //## begin BAMSUploadFile::BAMSUploadFile%5305100E0305_const.hasinit preserve=no
  //## end BAMSUploadFile::BAMSUploadFile%5305100E0305_const.hasinit
  //## begin BAMSUploadFile::BAMSUploadFile%5305100E0305_const.initialization preserve=yes
  //## end BAMSUploadFile::BAMSUploadFile%5305100E0305_const.initialization
{
  //## begin BAMSUploadFile::BAMSUploadFile%5305100E0305_const.body preserve=yes
   memcpy(m_sID,"VX05",4);
   if(!readExtract())
       Trace::put("UploadFile::Extract is not correctly configured");
  //## end BAMSUploadFile::BAMSUploadFile%5305100E0305_const.body
}


BAMSUploadFile::~BAMSUploadFile()
{
  //## begin BAMSUploadFile::~BAMSUploadFile%5305100E0305_dest.body preserve=yes
  //## end BAMSUploadFile::~BAMSUploadFile%5305100E0305_dest.body
}



//## Other Operations (implementation)
string BAMSUploadFile::buildFile (char& cStatus, const string& strFilename)
{
  //## begin BAMSUploadFile::buildFile%531E1623012B.body preserve=yes
   m_strFilename = strFilename;
   string strTempFileName;
   // Cleans up body xml and moves to complete
   FlatFile hPendingFile("UPENDING");
   hPendingFile.setMember(strFilename.c_str());
   if (!hPendingFile.open(FlatFile::CX_OPEN_INPUT))
   {
      cStatus = 'N';
      hPendingFile.close();
      return "No body file has been found: "+hPendingFile.getName();
   }
   hPendingFile.getBaseName(m_strBatchBaseName,true);
   size_t pos = hPendingFile.getDatasetName().find_last_of('\\');
   if (pos != string::npos)
      m_strFolderName.assign(hPendingFile.getDatasetName().data(),0,pos);
   ImportReportAuditSegment::instance()->setFILE(m_strBatchBaseName);
   hPendingFile.move("UPENDING",("original_"+m_strBatchBaseName).c_str());
   hPendingFile.close();
   hPendingFile.setMember(("original_"+m_strBatchBaseName).c_str());
   if (!hPendingFile.open(FlatFile::CX_OPEN_INPUT))
   {
      Trace::put("original_Chargeback.xml can not be opened");
      return "File cannot be opened for restructuring"; 
   }
   
   rebuildBatchXML(hPendingFile,("processed_" + m_strBatchBaseName));
   hPendingFile.close();

   hPendingFile.setMember(("original_" + m_strBatchBaseName).c_str());
   if (!hPendingFile.open(FlatFile::CX_OPEN_INPUT))
   {
      Trace::put("original file is not found to move to complete folder");
      return "Body file cannot be opened for restructuring";
   }
   hPendingFile.move("UCOMPLET",("original_" + m_strBatchBaseName).c_str());
   hPendingFile.close();

   //Packages .Tifs in DUA zip and moves to complete
   if(m_hTifDocs.size()!=0 && !zipBAMSImages())
      return "Unable to package tiff images into DUA zip";

   hPendingFile.setName("UPENDING");
   hPendingFile.setMember(("processed_"+ m_strBatchBaseName).c_str());
   if (!hPendingFile.open(FlatFile::CX_OPEN_INPUT))
      return "Body file cannot be opened for restructuring";	
   rebuildBAMSXML(hPendingFile,"chargebacks.xml");
   hPendingFile.close();
   Trace::put("chargebacks xml creted successfully for BAMS");

   m_strBatchOrigName.assign("chargerep_");
   m_strBatchOrigName.append(Clock::instance()->getYYYYMMDDHHMMSS().substr(0,8));
   m_strBatchOrigName.append("_");
   m_strBatchOrigName.append(Clock::instance()->getYYYYMMDDHHMMSS().substr(8,6));
   
   hPendingFile.setMember("*");
   hPendingFile.setName("BAMSTEMP");
   if (!hPendingFile.zip(m_strBatchOrigName+".zip"))
   {
      Trace::put("Zip failed on Images and XML");
      return "Zip failed on Images and XML";
   }
   hPendingFile.close();
   Trace::put("VX02::Packaged xml and document zip into BAMS zip");
   hPendingFile.setMember((m_strBatchOrigName+".zip").c_str());
   if (!hPendingFile.open(FlatFile::CX_OPEN_INPUT))
   {
	   Trace::put("zip file not found");
	   return "Zip failed on Images and XML";
   }
   hPendingFile.move("UPENDING",(m_strBatchOrigName+".zip").c_str());
   hPendingFile.close();
   
   FlatFile hRemoveFile("BAMSTEMP");
   hRemoveFile.setMember("*");
   hRemoveFile.remove();
   m_hImage.erase(m_hImage.begin(),m_hImage.end());
   string strOwner("BAMS");
   string strFTPDatasetName;
   if (finalizeFiles(strOwner))
   {
      if (writeFTPScript(strFTPDatasetName, strOwner))
      {
         if (executeFTPScript())
            return "Successfully Uploaded: "+(const string)strFTPDatasetName;
         else
            return "Unsuccessful execution of the FTP script";
      }
      else
      {
         if (strFTPDatasetName.length() > 0) 
         {
            strFTPDatasetName.append(" Dspec entry is not set up to FTP to IBM"); 
            return strFTPDatasetName;
         }
         else
            return "File length downloaded to PC is less than 11 characters";
       }

   }
   else
   {
      Trace::put("Failed on moving from PEND to COMPLETE");
      return "Unsuccessful in moving files from Pending to Complete";
   }
  //## end BAMSUploadFile::buildFile%531E1623012B.body
}

bool BAMSUploadFile::execute ()
{
  //## begin BAMSUploadFile::execute%55C8BAF1002C.body preserve=yes
  //## begin ECHISTUploadFile::execute%55C8BA2801E2.body preserve=yes
   if (m_bStatus)
   {
      Trace::put("BAMS Upload is not picked up for processing");
      return false;
   }
   resetVars();
   char cStatus = 'F';
   string strReason;
   FlatFile hRemoveFile("BAMSTEMP");
   hRemoveFile.setMember("*");
   hRemoveFile.remove();
   strReason = buildFile(cStatus,"BAMS*");
   sendStatus(cStatus,strReason);
   restoreFiles();
   return true;
  //## end BAMSUploadFile::execute%55C8BAF1002C.body
}

bool BAMSUploadFile::rebuildBAMSXML (IF::FlatFile& hInFile, const string& strOutputXMLFile)
{
  //## begin BAMSUploadFile::rebuildBAMSXML%531E16230151.body preserve=yes
   FlatFile hOutFile("BAMSTEMP");
   hOutFile.setMember(strOutputXMLFile.c_str());
   if (!hOutFile.open(FlatFile::CX_OPEN_OUTPUT))
      return false;

   string strLine;   
   string strRollOverTag;
   //Creates buffer for reading chunks of file
   char szTempLine[BUFFER_SIZE +1];
   size_t iReadSize = BUFFER_SIZE;
   bool bNoValidPrevLine = true;
   string strStartTag,strEndTag,strPrevLine;   
   int nPos,nPos1,nPos2,nPos3;
   string strCaseNumber;
   while (hInFile.read(szTempLine,BUFFER_SIZE+1,&iReadSize)==true )
   {
      strStartTag.erase();
      strEndTag.erase();
      nPos = strLine.find_first_of("<");
      nPos1 = strLine.find_first_of(">");
      if(nPos != string::npos && nPos1 != string::npos)
         strStartTag = strLine.substr((nPos + 1),(nPos1-(nPos+1)));
         
      strLine = strRollOverTag + szTempLine;
      
      nPos2 = strLine.find("</");
      nPos3 = strLine.find_last_of(">");
      if(nPos2 != string::npos && nPos3 != string::npos)
         strEndTag = strLine.substr((nPos2 + 2),(nPos3 - (nPos2 + 2)));     
      strRollOverTag.clear();
      //removes trailing whitespace
      strLine.erase(strLine.find_last_not_of(' ')+1,string::npos);
      //removes leading 0's from ECMOTO tag
      if ((nPos = strLine.find("<CaseNumber>")) != string::npos)
      {
         nPos1 = strLine.find("</CaseNumber>");
         strCaseNumber.assign(strLine,nPos+12,nPos1-(nPos+12));  //Test this
      }
      if ((nPos = strLine.find("<PageCount>")) !=string::npos) 
      {
         map<string, pair<string,string>, less<string> >::iterator pImage;
         pImage = m_hImage.find(strCaseNumber);
         strLine.assign("       <PageCount>");
         if (pImage == m_hImage.end())
            strLine.append("0");
         else
            strLine.append((*pImage).second.first);
         strLine.append("</PageCount>");
      }
      if ((nPos = strLine.find("<ImageFileSize>")) !=string::npos)
      {
         map<string, pair<string,string>, less<string> >::iterator pImage;
         pImage = m_hImage.find(strCaseNumber);
         strLine.assign("       <ImageFileSize>");
         if (pImage == m_hImage.end())
         {
            Trace::put(("No Image for " + strCaseNumber).c_str());
            strLine.append("0");
         }
         else
            strLine.append((*pImage).second.second);
         strLine.append("</ImageFileSize>");
      }
      hOutFile.write((char*)strLine.data(),strLine.length());
   }
   hOutFile.close();
   return true;

  //## end BAMSUploadFile::rebuildBAMSXML%531E16230151.body
}

bool BAMSUploadFile::zipBAMSImages ()
{
  //## begin BAMSUploadFile::zipBAMSImages%531E16230154.body preserve=yes
   int iErrorCount=0;
   string strFileLocation; 
   string strFileDestinationName; 
   FlatFile hImageFile("");
   vector<string> tempDocs;
   vector<string>::iterator pItr;
   for(pItr = m_hTifDocs.begin(); pItr != m_hTifDocs.end(); pItr++)
   {
      string strTemp = *pItr;
      for(int x = 0; x<strTemp.length(); x++)
         strTemp[x] = tolower(strTemp[x]);
        
      string strExtension(".tif ");
      if (strTemp.find(strExtension) == string::npos)
         strExtension = ".tiff ";
      if (strTemp.find(strExtension) == string::npos)
         strExtension = ".html ";
      if (strTemp.find(strExtension) == string::npos)
         strExtension = ".xps ";
      int n = strExtension.length();  
      strFileLocation.assign(*pItr,0,strTemp.find(strExtension)+(n-1));
      strFileDestinationName.assign(*pItr, strTemp.find(strExtension)+n,strTemp.length()); 
      hImageFile.setDatasetName(strFileLocation.c_str());
      if(!hImageFile.copy("BAMSTEMP",strFileDestinationName.c_str()))
      {
         Trace::put("Failed on copying documents");
         iErrorCount++;
         if(iErrorCount == m_iMinimumTifError)
         {
            hImageFile.close();
            hImageFile.setMember("*");
            hImageFile.setName("BAMSTEMP");
            hImageFile.remove();
            return false;
         }
      }
      tempDocs.push_back(strFileDestinationName);
   }
   FlatFile hPendingFile("BAMSTEMP");
   for (pItr = tempDocs.begin(); pItr != tempDocs.end(); pItr++)
   {
      string strTemp = *pItr;
      hPendingFile.setMember(strTemp.c_str());
      hPendingFile.setRecordFormat("FB");
      if (!hPendingFile.open(FlatFile::CX_OPEN_INPUT))
         return false;
      hPendingFile.seek(0,FlatFile::CX_SEEK_END);
      int length = hPendingFile.tellg();
      hPendingFile.seek(0,FlatFile::CX_SEEK_SET);
      char szTemp[4];
      unsigned char hex[] = { 0x4D, 0x00, 0x49, 0x2A };
      size_t iReadsize = 4;
      size_t iReadsize1=2;
      char szTemp1[2];
      hPendingFile.read(szTemp,4,&iReadsize);
      int pageCount(0);
      if ((szTemp[0] == hex[0] && szTemp[1] == hex[0] && szTemp[2] == hex[1] && szTemp[3] == hex[3])
         ||(szTemp[0] == hex[2] && szTemp[1] == hex[2] && szTemp[2] == hex[3] && szTemp[3] == hex[1]))
      {
         hPendingFile.read(szTemp,4,&iReadsize);
         while (!(szTemp[0] == hex[1] && szTemp[1] == hex[1] && szTemp[2] == hex[1] && szTemp[3] == hex[1])
            && iReadsize == 4)
         {
            int Offset2 = *((int*)szTemp);
            hPendingFile.seek(Offset2,FlatFile::CX_SEEK_SET);	
            hPendingFile.read(szTemp1,2,&iReadsize1);
            short TagCount = *((short*)szTemp1);
            Offset2 = Offset2 + 2 + (TagCount*12);
            hPendingFile.seek(Offset2,FlatFile::CX_SEEK_SET);
            hPendingFile.read(szTemp,4,&iReadsize);
            pageCount ++;
         }
         hPendingFile.close();
         char szTemp2[10];
         snprintf(szTemp2,sizeof(szTemp2),"%d",pageCount);
         string strTemp2(szTemp2);
         snprintf(szTemp2,sizeof(szTemp2),"%d",length);
         string strTemp3(szTemp2);
         size_t nPos;
         if (((nPos = strTemp.find(".")) != string::npos))
            strTemp.resize(nPos);
         m_hImage.insert(map<string,pair<string,string>,less<string> >::value_type(strTemp,make_pair(strTemp2,strTemp3)));
      }
   }
   FlatFile hLocalImageFiles("");
   hLocalImageFiles.setMember("*");      
   hLocalImageFiles.setName("BAMSTEMP");
   if(!(hLocalImageFiles.zip("TempImages")))
   {
      Trace::put("Failied on either Zipping BAMS Images or Removing from BAMSTEMP folder");
      return false;
   }
   hLocalImageFiles.setMember("TempImages.zip");
   if (!hLocalImageFiles.open(FlatFile::CX_OPEN_INPUT))
   {
      Trace::put("Image Zip File is not created");
      return false;
   }
   hLocalImageFiles.move("UPENDING","Images.zip");
   hLocalImageFiles.close();
   hLocalImageFiles.setMember("*");
   hLocalImageFiles.setName("BAMSTEMP");
   hLocalImageFiles.remove();
   hLocalImageFiles.setMember("Images.zip");
   hLocalImageFiles.setName("UPENDING");
   if (!hLocalImageFiles.open(FlatFile::CX_OPEN_INPUT))
   {
      Trace::put("Image Zip File is not created");
      return false;
   }
   hLocalImageFiles.move("BAMSTEMP","Images.zip");
   hLocalImageFiles.close();   
   return true;
  //## end BAMSUploadFile::zipBAMSImages%531E16230154.body
}

// Additional Declarations
  //## begin BAMSUploadFile%5305100E0305.declarations preserve=yes
  //## end BAMSUploadFile%5305100E0305.declarations

//## begin module%5305112801EA.epilog preserve=yes
//## end module%5305112801EA.epilog
