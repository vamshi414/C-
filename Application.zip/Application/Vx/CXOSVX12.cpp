//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%556CA04F03B5.cm preserve=no
//	$Date:   Aug 27 2015 15:24:54  $ $Author:   e1009591  $
//	$Revision:   1.0  $
//## end module%556CA04F03B5.cm

//## begin module%556CA04F03B5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%556CA04F03B5.cp

//## Module: CXOSVX12%556CA04F03B5; Package body
//## Subsystem: VX%4C2B63AB026E
//## Source file: C:\bV02.5B.R003\Windows\Build\Dn\Server\Application\Vx\CXOSVX12.cpp

//## begin module%556CA04F03B5.additionalIncludes preserve=no
//## end module%556CA04F03B5.additionalIncludes

//## begin module%556CA04F03B5.includes preserve=yes
//## end module%556CA04F03B5.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSVX12_h
#include "CXODVX12.hpp"
#endif


//## begin module%556CA04F03B5.declarations preserve=no
//## end module%556CA04F03B5.declarations

//## begin module%556CA04F03B5.additionalDeclarations preserve=yes
//## end module%556CA04F03B5.additionalDeclarations


// Class DocumentInquiryItem 

DocumentInquiryItem::DocumentInquiryItem()
  //## begin DocumentInquiryItem::DocumentInquiryItem%556C8C970210_const.hasinit preserve=no
  //## end DocumentInquiryItem::DocumentInquiryItem%556C8C970210_const.hasinit
  //## begin DocumentInquiryItem::DocumentInquiryItem%556C8C970210_const.initialization preserve=yes
  //## end DocumentInquiryItem::DocumentInquiryItem%556C8C970210_const.initialization
{
  //## begin DocumentInquiryItem::DocumentInquiryItem%556C8C970210_const.body preserve=yes
  //## end DocumentInquiryItem::DocumentInquiryItem%556C8C970210_const.body
}


DocumentInquiryItem::~DocumentInquiryItem()
{
  //## begin DocumentInquiryItem::~DocumentInquiryItem%556C8C970210_dest.body preserve=yes
  //## end DocumentInquiryItem::~DocumentInquiryItem%556C8C970210_dest.body
}


// Additional Declarations
  //## begin DocumentInquiryItem%556C8C970210.declarations preserve=yes
  //## end DocumentInquiryItem%556C8C970210.declarations

//## begin module%556CA04F03B5.epilog preserve=yes
//## end module%556CA04F03B5.epilog
