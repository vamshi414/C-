//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3DE2833B0186.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3DE2833B0186.cm

//## begin module%3DE2833B0186.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3DE2833B0186.cp

//## Module: CXOSCS01%3DE2833B0186; Package body
//## Subsystem: CS%3DE26E9D009C
//## Source file: C:\Devel\ConnexPlatform\Server\Application\Cs\CXOSCS01.cpp

//## begin module%3DE2833B0186.additionalIncludes preserve=no
//## end module%3DE2833B0186.additionalIncludes

//## begin module%3DE2833B0186.includes preserve=yes
// $Date:   Aug 18 2016 14:54:46  $ $Author:   e1009652  $ $Revision:   1.5  $
#include <iostream>
#include <stdio.h>
#ifndef CXODIF11_h
#include "CXODIF11.hpp"
#endif
//## end module%3DE2833B0186.includes

#ifndef CXOSCS01_h
#include "CXODCS01.hpp"
#endif
//## begin module%3DE2833B0186.declarations preserve=no
//## end module%3DE2833B0186.declarations

//## begin module%3DE2833B0186.additionalDeclarations preserve=yes
//## end module%3DE2833B0186.additionalDeclarations


// Class SynchronousSocket 





SynchronousSocket::SynchronousSocket()
  //## begin SynchronousSocket::SynchronousSocket%3DE2722002DE_const.hasinit preserve=no
      : m_pszBuffer(0),
        m_hConnectionSocket(-1)
  //## end SynchronousSocket::SynchronousSocket%3DE2722002DE_const.hasinit
  //## begin SynchronousSocket::SynchronousSocket%3DE2722002DE_const.initialization preserve=yes
  //## end SynchronousSocket::SynchronousSocket%3DE2722002DE_const.initialization
{
  //## begin SynchronousSocket::SynchronousSocket%3DE2722002DE_const.body preserve=yes
   m_pszBuffer = new char[MAX_BUFFER_SIZE];
  //## end SynchronousSocket::SynchronousSocket%3DE2722002DE_const.body
}


SynchronousSocket::~SynchronousSocket()
{
  //## begin SynchronousSocket::~SynchronousSocket%3DE2722002DE_dest.body preserve=yes
   close();
   WSACleanup();
   delete [] m_pszBuffer;
  //## end SynchronousSocket::~SynchronousSocket%3DE2722002DE_dest.body
}



//## Other Operations (implementation)
bool SynchronousSocket::close ()
{
  //## begin SynchronousSocket::close%3DE27245033C.body preserve=yes
	if (m_hConnectionSocket != -1)
	{
	   if (closesocket(m_hConnectionSocket) == SOCKET_ERROR)
	    	return reportError("closesocket",WSAGetLastError());
	   m_hConnectionSocket = -1;
	}
   return true;
  //## end SynchronousSocket::close%3DE27245033C.body
}

bool SynchronousSocket::open (const char* pszName)
{
  //## begin SynchronousSocket::open%3DE2725B0280.body preserve=yes
   WORD wVersionRequested = MAKEWORD(1,1);
   WSADATA wsaData;
   int nErrorStatus;
   nErrorStatus = WSAStartup(wVersionRequested,&wsaData);
   if (nErrorStatus != 0)
      return reportError("WSAStartup",nErrorStatus);
	m_strName = pszName;
	// pszName should be "computer_name~port_number"
   if ((m_hConnectionSocket = (short)socket(AF_INET,SOCK_STREAM,0)) == INVALID_SOCKET)
      return reportError("socket",WSAGetLastError());
   m_hServerAddress.sin_family = AF_INET;
	char pszHostName[128];
	strcpy(pszHostName,pszName);
	char* p = strchr(pszHostName,'~');
	if (!p)
		return reportError("Open ~",42);
	*p = '\0';
	++p;
	u_short uServerPort = atoi(p);
   m_hServerAddress.sin_port = htons(uServerPort);
   PHOSTENT phe;
	phe = gethostbyname(pszHostName);
	if (!phe)
		return reportError("gethostbyname",0);
   memcpy((void*)&(m_hServerAddress.sin_addr), (void*)phe->h_addr, min(phe->h_length, 4));
   int rc = connect(m_hConnectionSocket,(struct sockaddr*)&m_hServerAddress,sizeof(m_hServerAddress));
   if (rc == SOCKET_ERROR)
   {
      rc = WSAGetLastError();
    	closesocket(m_hConnectionSocket);
		m_hConnectionSocket = -1;
      return reportError("connect",rc);
	}
   return true;		         
  //## end SynchronousSocket::open%3DE2725B0280.body
}

bool SynchronousSocket::read (string& strBuffer)
{
  //## begin SynchronousSocket::read%3DE272650213.body preserve=yes
   char sLength[9] = {"00000000"};
   unsigned int m = 0;
	unsigned int bytes = 0;
	char* buffer;
	// get length of message
	unsigned int total_bytes_rcvd = 0;
	do
	{
		buffer = sLength + total_bytes_rcvd;
    	bytes = recv(m_hConnectionSocket,buffer,8 - total_bytes_rcvd,0);
    	if (bytes <= 0)
		{
    		strBuffer = "quit";
			return reportError("recv",WSAGetLastError());
    	}
    	total_bytes_rcvd = total_bytes_rcvd + bytes;
	}
	while (total_bytes_rcvd < 8);
   if (!strncmp(sLength,"00000000",9))
      return reportError("socket",m_hConnectionSocket);
   m = atol(sLength) - 8;
	// get message
	total_bytes_rcvd = 0;
	do
	{
		buffer = m_pszBuffer + total_bytes_rcvd;
		bytes = recv(m_hConnectionSocket,buffer,(int)(m - total_bytes_rcvd),0);
		if (bytes <= 0)
			return reportError("recv",bytes);
		total_bytes_rcvd = total_bytes_rcvd + bytes;
	}
	while (total_bytes_rcvd < m);
   m_pszBuffer[m] = '\0';
   for (unsigned int i = 0;i < m;++i)
   {
      if (m_pszBuffer[i] == '\0')
         m_pszBuffer[i] = ' ';
   }
	if (m)
    	strBuffer = m_pszBuffer;
   return (m) ? true : false;
  //## end SynchronousSocket::read%3DE272650213.body
}

bool SynchronousSocket::reportError (const char* pszFunction, int lRC)
{
  //## begin SynchronousSocket::reportError%3DE2727101B5.body preserve=yes
   std::cout << "SynchronousSocket::reportError " << pszFunction << " " << lRC << endl;
   return false;
  //## end SynchronousSocket::reportError%3DE2727101B5.body
}

bool SynchronousSocket::transact (const char* pszName, const string& strRequest, string& strReply)
{
  //## begin SynchronousSocket::transact%3DE272710271.body preserve=yes
   bool bSuccess = false;
   if (open(pszName))
   {
      if (write(strRequest.c_str(),(int)strRequest.length()))
         bSuccess = read(strReply);
      close();
   }
   return bSuccess;
  //## end SynchronousSocket::transact%3DE272710271.body
}

bool SynchronousSocket::write (const char* psBuffer, int lLength)
{
  //## begin SynchronousSocket::write%3DE27271034B.body preserve=yes
   if ((send(m_hConnectionSocket,psBuffer,lLength,0)) == SOCKET_ERROR)
      return reportError("send",WSAGetLastError());
   return true;
  //## end SynchronousSocket::write%3DE27271034B.body
}

// Additional Declarations
  //## begin SynchronousSocket%3DE2722002DE.declarations preserve=yes
  //## end SynchronousSocket%3DE2722002DE.declarations

//## begin module%3DE2833B0186.epilog preserve=yes
//## end module%3DE2833B0186.epilog
