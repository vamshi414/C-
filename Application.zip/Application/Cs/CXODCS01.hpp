//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3DE2833902FD.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3DE2833902FD.cm

//## begin module%3DE2833902FD.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3DE2833902FD.cp

//## Module: CXOSCS01%3DE2833902FD; Package specification
//## Subsystem: CS%3DE26E9D009C
//## Source file: C:\Devel\ConnexPlatform\Server\Application\Cs\CXODCS01.hpp

#ifndef CXOSCS01_h
#define CXOSCS01_h 1

//## begin module%3DE2833902FD.additionalIncludes preserve=no
//## end module%3DE2833902FD.additionalIncludes

//## begin module%3DE2833902FD.includes preserve=yes
// $Date:   Oct 16 2018 13:25:52  $ $Author:   e1009652  $ $Revision:   1.3  $
#include <winsock.h>
//## end module%3DE2833902FD.includes

//## begin module%3DE2833902FD.declarations preserve=no
//## end module%3DE2833902FD.declarations

//## begin module%3DE2833902FD.additionalDeclarations preserve=yes
//## end module%3DE2833902FD.additionalDeclarations


//## begin SynchronousSocket%3DE2722002DE.preface preserve=yes
//## end SynchronousSocket%3DE2722002DE.preface

//## Class: SynchronousSocket%3DE2722002DE
//## Category: Connex Platform::ClientSimulator_CAT%3DE26E74034B
//## Subsystem: CS%3DE26E9D009C
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class SynchronousSocket 
{
  //## begin SynchronousSocket%3DE2722002DE.initialDeclarations preserve=yes
  //## end SynchronousSocket%3DE2722002DE.initialDeclarations

  public:
    //## Constructors (generated)
      SynchronousSocket();

    //## Destructor (generated)
      virtual ~SynchronousSocket();


    //## Other Operations (specified)
      //## Operation: close%3DE27245033C
      bool close ();

      //## Operation: open%3DE2725B0280
      bool open (const char* pszName);

      //## Operation: read%3DE272650213
      bool read (string& strBuffer);

      //## Operation: reportError%3DE2727101B5
      bool reportError (const char* pszFunction, int lRC);

      //## Operation: transact%3DE272710271
      bool transact (const char* pszName, const string& strRequest, string& strReply);

      //## Operation: write%3DE27271034B
      bool write (const char* psBuffer, int lLength);

    // Additional Public Declarations
      //## begin SynchronousSocket%3DE2722002DE.public preserve=yes
      //## end SynchronousSocket%3DE2722002DE.public

  protected:
    // Additional Protected Declarations
      //## begin SynchronousSocket%3DE2722002DE.protected preserve=yes
      //## end SynchronousSocket%3DE2722002DE.protected

  private:
    // Additional Private Declarations
      //## begin SynchronousSocket%3DE2722002DE.private preserve=yes
      //## end SynchronousSocket%3DE2722002DE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%3DE3C28200FA
      //## begin SynchronousSocket::Buffer%3DE3C28200FA.attr preserve=no  private: char* {V} 0
      char* m_pszBuffer;
      //## end SynchronousSocket::Buffer%3DE3C28200FA.attr

      //## Attribute: ConnectionSocket%3DE272AB02DE
      //## begin SynchronousSocket::ConnectionSocket%3DE272AB02DE.attr preserve=no  private: short {V} -1
      short m_hConnectionSocket;
      //## end SynchronousSocket::ConnectionSocket%3DE272AB02DE.attr

      //## Attribute: Name%3DE272A203D8
      //## begin SynchronousSocket::Name%3DE272A203D8.attr preserve=no  private: string {V} 
      string m_strName;
      //## end SynchronousSocket::Name%3DE272A203D8.attr

      //## Attribute: ServerAddress%3DE272AB0399
      //## begin SynchronousSocket::ServerAddress%3DE272AB0399.attr preserve=no  private: struct sockaddr_in {V} 
      struct sockaddr_in m_hServerAddress;
      //## end SynchronousSocket::ServerAddress%3DE272AB0399.attr

    // Additional Implementation Declarations
      //## begin SynchronousSocket%3DE2722002DE.implementation preserve=yes
      //## end SynchronousSocket%3DE2722002DE.implementation

};

//## begin SynchronousSocket%3DE2722002DE.postscript preserve=yes
//## end SynchronousSocket%3DE2722002DE.postscript

//## begin module%3DE2833902FD.epilog preserve=yes
//## end module%3DE2833902FD.epilog


#endif
