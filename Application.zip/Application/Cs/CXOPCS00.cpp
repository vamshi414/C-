//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3DE26F5B033C.cm preserve=no
// $Date:   May 13 2020 11:57:14  $ $Author:   e1009510  $ $Revision:   1.15  $
//## end module%3DE26F5B033C.cm

//## begin module%3DE26F5B033C.cp preserve=no
// Copyright (c) 1998 - 2005
// eFunds Corporation
//## end module%3DE26F5B033C.cp

//## Module: CXOPCS00%3DE26F5B033C; Package body
//## Subsystem: CS%3DE26E9D009C
//## Source file: C:\Devel\ConnexPlatform\Server\Application\Cs\CXOPCS00.cpp

//## begin module%3DE26F5B033C.additionalIncludes preserve=no
//## end module%3DE26F5B033C.additionalIncludes

//## begin module%3DE26F5B033C.includes preserve=yes
#include <iostream>
#include <time.h>
#include "CXODIF11.hpp"
#include "CXODDB01.hpp"
#include "CXODVS12.hpp"
#define CHAR_COLUMNS 245
char* pszChar[CHAR_COLUMNS] =
{
"ACCT_ID_1",
"ACCT_ID_2",
"ACCT_ID_3",
"ACQ_PLAT_PROD_ID",
"CARD_ACPT_BUS_CODE",
"CARD_ACPT_COUNTRY",
"CARD_ACPT_PST_CODE",
"CARD_ACPT_REGION",
"CARD_SEQ_NO",
"CIRC_ID_ACQ",
"CIRC_ID_ISS",
"COUNTRY_ACQ_INST",
"COUNTRY_ISS_INST",
"CUR_CARD_BILL",
"CUR_RECON_NET",
"CUR_TRAN",
"DATE_RECON_ACQ",
"FUNC_CODE",
"MERCH_TYPE",
"MSG_RESON_CODE_ACQ",
"MSG_RESON_CODE_ISS",
"NET_ID_ACQ",
"NET_ID_ISS",
"POS_CRDHLDR_A_METH",
"REIMBURSEMENT_ATTR",
"REV_BY",
"TRAN_DISPOSITION",
"ACCT_QUAL_1",
"ACCT_QUAL_2",
"AP_FLG",
"CARD_ACPT_ID",
"CRD_ACP_NAM_FMTFLG",
"CARD_OWNER",
"CARD_TYPE",
"CUR_RECON_ACQ",
"CUR_RECON_ISS",
"DATE_EXP",
"DATE_RECON_ISS",
"DRAFT_CAPTURE_FLG",
"EXCHG_MASTER",
"EXCHG_SETL",
"F_CUR_CODE0",
"F_CUR_CODE1",
"F_CUR_CODE2",
"F_CUR_CODE3",
"F_CUR_CODE4",
"F_CUR_CODE5",
"F_CUR_RECON_ACQ0",
"F_CUR_RECON_ACQ1",
"F_CUR_RECON_ACQ2",
"F_CUR_RECON_ACQ3",
"F_CUR_RECON_ACQ4",
"F_CUR_RECON_ACQ5",
"F_CUR_RECON_ISS0",
"F_CUR_RECON_ISS1",
"F_CUR_RECON_ISS2",
"F_CUR_RECON_ISS3",
"F_CUR_RECON_ISS4",
"F_CUR_RECON_ISS5",
"F_INITIATOR0",
"F_INITIATOR1",
"F_INITIATOR2",
"F_INITIATOR3",
"F_INITIATOR4",
"F_INITIATOR5",
"F_MEMO0",
"F_MEMO1",
"F_MEMO2",
"F_MEMO3",
"F_MEMO4",
"F_MEMO5",
"F_TYPE0",
"F_TYPE1",
"F_TYPE2",
"F_TYPE3",
"F_TYPE4",
"F_TYPE5",
"HOST_RECV_FLG",
"HOST_SENT_FLG",
"MTI",
"OAR_RQST_FLG",
"PAYEE",
"POS_CARD_CAPT_CAP",
"POS_CRD_DAT_IN_CAP",
"POS_CRD_DAT_IN_MOD",
"POS_CRD_DAT_OT_CAP",
"POS_CRDHLDR_AUTH",
"POS_CRDHLDR_AUTH_C",
"POS_CRDHLDR_PRESNT",
"POS_CARD_PRES",
"POS_OPER_ENV",
"POS_PIN_CAPT_CAP",
"POS_TERM_OUT_CAP",
"PRINT_MASK_ID",
"TERM_CLASS",
"TRAN_UNIQ_DATA_FMT",
"TSTAMP_REV_CREATED",
"FO_CUR_CODE0",
"FO_CUR_CODE1",
"FO_CUR_CODE2",
"FO_CUR_CODE3",
"FO_CUR_CODE4",
"FO_CUR_CODE5",
"FO_CUR_RECON_ACQ0",
"FO_CUR_RECON_ACQ1",
"FO_CUR_RECON_ACQ2",
"FO_CUR_RECON_ACQ3",
"FO_CUR_RECON_ACQ4",
"FO_CUR_RECON_ACQ5",
"FO_CUR_RECON_ISS0",
"FO_CUR_RECON_ISS1",
"FO_CUR_RECON_ISS2",
"FO_CUR_RECON_ISS3",
"FO_CUR_RECON_ISS4",
"FO_CUR_RECON_ISS5",
"FO_INITIATOR0",
"FO_INITIATOR1",
"FO_INITIATOR2",
"FO_INITIATOR3",
"FO_INITIATOR4",
"FO_INITIATOR5",
"FO_MEMO0",
"FO_MEMO1",
"FO_MEMO2",
"FO_MEMO3",
"FO_MEMO4",
"FO_MEMO5",
"FO_TYPE0",
"FO_TYPE1",
"FO_TYPE2",
"FO_TYPE3",
"FO_TYPE4",
"FO_TYPE5",
"ODE_TSTAMP_LOCL_TR",
"ODE_INST_ID_ACQ",
"ODE_MTI",
"ODE_SYS_TRA_AUD_NO",
"ACCT_TYPE_1",
"ACCT_TYPE_2",
"ACCT_TYPE_3",
"ACCT_TYPES_ISS",
"ADL_RESP_ACCT_TYP0",
"ADL_RESP_ACCT_TYP1",
"ADL_RESP_ACCT_TYP2",
"ADL_RESP_ACCT_TYP3",
"ADL_RESP_ACCT_TYP4",
"ADL_RESP_ACCT_TYP5",
"ADL_RQST_ACCT_TYP0",
"ADL_RQST_ACCT_TYP1",
"ADL_RQST_ACCT_TYP2",
"ADL_RQST_ACCT_TYP3",
"ADL_RQST_ACCT_TYP4",
"ADL_RQST_ACCT_TYP5",
"ADL_RESP_AMT_TYP0",
"ADL_RESP_AMT_TYP1",
"ADL_RESP_AMT_TYP2",
"ADL_RESP_AMT_TYP3",
"ADL_RESP_AMT_TYP4",
"ADL_RESP_AMT_TYP5",
"ADL_RESP_CUR_CODE0",
"ADL_RESP_CUR_CODE1",
"ADL_RESP_CUR_CODE2",
"ADL_RESP_CUR_CODE3",
"ADL_RESP_CUR_CODE4",
"ADL_RESP_CUR_CODE5",
"ADL_RQST_AMT_TYP0",
"ADL_RQST_AMT_TYP1",
"ADL_RQST_AMT_TYP2",
"ADL_RQST_AMT_TYP3",
"ADL_RQST_AMT_TYP4",
"ADL_RQST_AMT_TYP5",
"ADL_RQST_CUR_CODE0",
"ADL_RQST_CUR_CODE1",
"ADL_RQST_CUR_CODE2",
"ADL_RQST_CUR_CODE3",
"ADL_RQST_CUR_CODE4",
"ADL_RQST_CUR_CODE5",
"ALT_ROUTE_FLG",
"AP_APPROVAL_CODE",
"AP_CARD_GRP",
"AP_DATA",
"AUTH_LCYCLE_TCODE",
"CARD_ACPT_COUNTY",
"CARD_ACPT_SPNSR_ID",
"CARD_CAPT_FLG",
"CAVV_RESULT",
"CLERK_ID",
"CNTRY_RCN_ACQ_INST",
"CNTRY_RCN_ISS_INST",
"CVV_CVC_RESULT",
"CVV2_CVC2_RESULT",
"DATE_ACTION",
"DATE_CAPTURE",
"DATE_CNV_ACQ",
"DATE_CNV_ISS",
"DATE_EFFECTIVE",
"DATE_RECON_NET",
"DEPOSIT_ONLY_FLG",
"EXTENDED_PAY_DATA",
"TRAN_FROM_ACCT_FLG",
"TRAN_TO_ACCT_FLG",
"RECON_IND_ACQ",
"RESTRIC_INTCHG_GRP",
"SRV_GRP_INTCHG_IND",
"SRV_GRP_SERV_CODE",
"SOURCE_ROUTE_ID",
"STANDIN_ACT",
"STANDIN_OPTION",
"TRACK_INFO_KEY_ID",
"TRACINF_KEYTRAC_NO",
"CNTRY_REC_INST_ADJ",
"CNTRY_REQ_INST_ADJ",
"BRANCH_ID_ACQ",
"INST_ID_REC_ADJ",
"INST_ID_REQ_ADJ",
"NET_IND_ADJ",
"TSTAMP_LOCAL_ADJ",
"TSTAMP_TRANS_ADJ",
"REQ_ACQ_ISS_IND",
"TRACE_DATA_ADJ",
"ISS_ACQ_TYPE_FEE",
"MCI_UCAF_DATA",
"MCI_ECS_LVL_IND",
"MCI_AAV_RESULT_COD",
"PROC_FLGS1",
"PROC_FLGS2",
"PROC_FLGS3",
"PROC_FLGS4",
"PROC_BILLING_FLGS1",
"PROC_BILLING_FLGS2",
"PROC_BILLING_FLGS3",
"PROC_BILLING_FLGS4",
"CARD_ACPT_NAME_LOC",
"DATA_PRIV_ACQ",
"DATA_PRIV_ISS",
"REF_DATA_ACQ",
"REF_DATA_ISS",
"TRACK_2_DATA",
"TRAN_DESC",
"TRAN_UNIQUE_DATA",
"ADL_RESP_DATA",
"EXTENSION_DATA_ADJ",
"NET_UNIQUE_DAT_FEE",
"ADTL_DATA_FEE",
"ADL_DATA_PRIV_ACQ"
};

#define NUMERIC_COLUMNS 198
char* pszNumeric[NUMERIC_COLUMNS] =
{
"INSERT_SEQUENCE_NO",
"CED_BUILD_NO",
"AMT_RECON_NET",
"AMT_TRAN",
"AMT_CARD_BILL",
"AMT_RECON_ACQ",
"AMT_RECON_ISS",
"CAN_ITEM_VALUE0",
"CAN_ITEM_VALUE1",
"CAN_ITEM_VALUE2",
"CAN_ITEM_VALUE3",
"CAN_ITEM_VALUE4",
"CAN_ITEM_VALUE5",
"CAN_ITEM_VALUE6",
"CAN_ITEM_VALUE7",
"CAN_NO_ITEMS_DISP0",
"CAN_NO_ITEMS_DISP1",
"CAN_NO_ITEMS_DISP2",
"CAN_NO_ITEMS_DISP3",
"CAN_NO_ITEMS_DISP4",
"CAN_NO_ITEMS_DISP5",
"CAN_NO_ITEMS_DISP6",
"CAN_NO_ITEMS_DISP7",
"CAN_ORIG_NO_ITEMS0",
"CAN_ORIG_NO_ITEMS1",
"CAN_ORIG_NO_ITEMS2",
"CAN_ORIG_NO_ITEMS3",
"CAN_ORIG_NO_ITEMS4",
"CAN_ORIG_NO_ITEMS5",
"CAN_ORIG_NO_ITEMS6",
"CAN_ORIG_NO_ITEMS7",
"F_ADL_DEC_POS0",
"F_ADL_DEC_POS1",
"F_ADL_DEC_POS2",
"F_ADL_DEC_POS3",
"F_ADL_DEC_POS4",
"F_ADL_DEC_POS5",
"F_AMT0",
"F_AMT1",
"F_AMT2",
"F_AMT3",
"F_AMT4",
"F_AMT5",
"F_AMT_RECON_ACQ0",
"F_AMT_RECON_ACQ1",
"F_AMT_RECON_ACQ2",
"F_AMT_RECON_ACQ3",
"F_AMT_RECON_ACQ4",
"F_AMT_RECON_ACQ5",
"F_AMT_RECON_ISS0",
"F_AMT_RECON_ISS1",
"F_AMT_RECON_ISS2",
"F_AMT_RECON_ISS3",
"F_AMT_RECON_ISS4",
"F_AMT_RECON_ISS5",
"F_AMT_RECON_NET0",
"F_AMT_RECON_NET1",
"F_AMT_RECON_NET2",
"F_AMT_RECON_NET3",
"F_AMT_RECON_NET4",
"F_AMT_RECON_NET5",
"F_CNV_ACQ_DEC_POS0",
"F_CNV_ACQ_DEC_POS1",
"F_CNV_ACQ_DEC_POS2",
"F_CNV_ACQ_DEC_POS3",
"F_CNV_ACQ_DEC_POS4",
"F_CNV_ACQ_DEC_POS5",
"F_CNV_ACQ_RATE0",
"F_CNV_ACQ_RATE1",
"F_CNV_ACQ_RATE2",
"F_CNV_ACQ_RATE3",
"F_CNV_ACQ_RATE4",
"F_CNV_ACQ_RATE5",
"F_CNV_ISS_DEC_POS0",
"F_CNV_ISS_DEC_POS1",
"F_CNV_ISS_DEC_POS2",
"F_CNV_ISS_DEC_POS3",
"F_CNV_ISS_DEC_POS4",
"F_CNV_ISS_DEC_POS5",
"F_CNV_ISS_RATE0",
"F_CNV_ISS_RATE1",
"F_CNV_ISS_RATE2",
"F_CNV_ISS_RATE3",
"F_CNV_ISS_RATE4",
"F_CNV_ISS_RATE5",
"CNV_CRD_BIL_DE_POS",
"CNV_CRD_BIL_RATE",
"CNV_RCN_ACQ_DE_POS",
"CNV_RCN_ACQ_RATE",
"CNV_RCN_ISS_DE_POS",
"CNV_RCN_ISS_RATE",
"CNV_RCN_NET_DE_POS",
"CNV_RCN_NET_RATE",
"CUR_TYPE",
"DATA_PRIV_ACQ_FMT",
"DATA_PRIV_ISS_FMT",
"REF_DATA_ACQ_FMT",
"REF_DATA_ISS_FMT",
"TIME_AT_AP",
"TIME_AT_ISS",
"TIME_AT_RESP_QUE",
"TIME_AT_RESP_SWTCH",
"TIME_AT_RQST_QUE",
"TIME_AT_RQST_SWTCH",
"FO_DEC_POS0",
"FO_DEC_POS1",
"FO_DEC_POS2",
"FO_DEC_POS3",
"FO_DEC_POS4",
"FO_DEC_POS5",
"FO_AMT0",
"FO_AMT1",
"FO_AMT2",
"FO_AMT3",
"FO_AMT4",
"FO_AMT5",
"FO_AMT_RECON_ACQ0",
"FO_AMT_RECON_ACQ1",
"FO_AMT_RECON_ACQ2",
"FO_AMT_RECON_ACQ3",
"FO_AMT_RECON_ACQ4",
"FO_AMT_RECON_ACQ5",
"FO_AMT_RECON_ISS0",
"FO_AMT_RECON_ISS1",
"FO_AMT_RECON_ISS2",
"FO_AMT_RECON_ISS3",
"FO_AMT_RECON_ISS4",
"FO_AMT_RECON_ISS5",
"FO_AMT_RECON_NET0",
"FO_AMT_RECON_NET1",
"FO_AMT_RECON_NET2",
"FO_AMT_RECON_NET3",
"FO_AMT_RECON_NET4",
"FO_AMT_RECON_NET5",
"FO_CNV_ACQ_DE_POS0",
"FO_CNV_ACQ_DE_POS1",
"FO_CNV_ACQ_DE_POS2",
"FO_CNV_ACQ_DE_POS3",
"FO_CNV_ACQ_DE_POS4",
"FO_CNV_ACQ_DE_POS5",
"FO_CNV_ACQ_RATE0",
"FO_CNV_ACQ_RATE1",
"FO_CNV_ACQ_RATE2",
"FO_CNV_ACQ_RATE3",
"FO_CNV_ACQ_RATE4",
"FO_CNV_ACQ_RATE5",
"FO_CNV_ISS_DE_POS0",
"FO_CNV_ISS_DE_POS1",
"FO_CNV_ISS_DE_POS2",
"FO_CNV_ISS_DE_POS3",
"FO_CNV_ISS_DE_POS4",
"FO_CNV_ISS_DE_POS5",
"FO_CNV_ISS_RATE0",
"FO_CNV_ISS_RATE1",
"FO_CNV_ISS_RATE2",
"FO_CNV_ISS_RATE3",
"FO_CNV_ISS_RATE4",
"FO_CNV_ISS_RATE5",
"O_AMT_CARD_BILL",
"O_AMT_RECON_ACQ",
"O_AMT_RECON_ISS",
"O_AMT_RECON_NET",
"O_AMT_TRAN",
"ADL_RESP_ACCT_IDX0",
"ADL_RESP_ACCT_IDX1",
"ADL_RESP_ACCT_IDX2",
"ADL_RESP_ACCT_IDX3",
"ADL_RESP_ACCT_IDX4",
"ADL_RESP_ACCT_IDX5",
"ADL_RQST_ACCT_IDX0",
"ADL_RQST_ACCT_IDX1",
"ADL_RQST_ACCT_IDX2",
"ADL_RQST_ACCT_IDX3",
"ADL_RQST_ACCT_IDX4",
"ADL_RQST_ACCT_IDX5",
"ADL_RQST_AMT0",
"ADL_RQST_AMT1",
"ADL_RQST_AMT2",
"ADL_RQST_AMT3",
"ADL_RQST_AMT4",
"ADL_RQST_AMT5",
"ADL_RESP_AMT0",
"ADL_RESP_AMT1",
"ADL_RESP_AMT2",
"ADL_RESP_AMT3",
"ADL_RESP_AMT4",
"ADL_RESP_AMT5",
"AP_ERROR_NO",
"AP_ERROR_TRACE_LOC",
"AP_REJ_REASON_CODE",
"AUTH_LIFECYCLE_INT",
"AUTH_RQST_TIMEOUT",
"PIN_DATA_FMT",
"PIN_RESULT",
"PMC_ERROR",
"PREAUTH_COMP_OPT",
"USAGE_UPDATE_BITS",
"ORIG_AMT_TRAN_ADJ"
};
//## end module%3DE26F5B033C.includes

#ifndef CXOSCS01_h
#include "CXODCS01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOPCS00_h
#include "CXODCS00.hpp"
#endif


//## begin module%3DE26F5B033C.declarations preserve=no
//## end module%3DE26F5B033C.declarations

//## begin module%3DE26F5B033C.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new ClientSimulator();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%3DE26F5B033C.additionalDeclarations


// Class ClientSimulator

ClientSimulator::ClientSimulator()
  //## begin ClientSimulator::ClientSimulator%3DE26ED802EE_const.hasinit preserve=no
      : m_nChar(0),
        m_iHour(0),
        m_nIndex(1),
        m_nNumeric(0),
        m_pRequests(0),
        m_pResponses(0)
  //## end ClientSimulator::ClientSimulator%3DE26ED802EE_const.hasinit
  //## begin ClientSimulator::ClientSimulator%3DE26ED802EE_const.initialization preserve=yes
  //## end ClientSimulator::ClientSimulator%3DE26ED802EE_const.initialization
{
  //## begin ClientSimulator::ClientSimulator%3DE26ED802EE_const.body preserve=yes
   m_pProcessor = m_hProcessors.end();
   m_pInstitution = m_hInstitutions.end();
   m_pReportingLevel = m_hReportingLevels.end();
   m_pDevice = m_hDevices.end();
   m_pPAN = m_hPANs.end();
   m_iHour = 23;
   m_iStartHour = 23;
  //## end ClientSimulator::ClientSimulator%3DE26ED802EE_const.body
}

ClientSimulator::ClientSimulator (const char* pszConnection, const char* pszUserID, const char* pszPassword, const char* pszResponse)
  //## begin ClientSimulator::ClientSimulator%3DE295CA005D.hasinit preserve=no
      : m_nChar(0),
        m_iHour(0),
        m_nIndex(1),
        m_nNumeric(0),
        m_pRequests(0),
        m_pResponses(0)
  //## end ClientSimulator::ClientSimulator%3DE295CA005D.hasinit
  //## begin ClientSimulator::ClientSimulator%3DE295CA005D.initialization preserve=yes
   ,m_strConnection(pszConnection)
   ,m_strUserID(pszUserID)
   ,m_strPassword(pszPassword)
   ,m_strResponse(pszResponse)
  //## end ClientSimulator::ClientSimulator%3DE295CA005D.initialization
{
  //## begin ClientSimulator::ClientSimulator%3DE295CA005D.body preserve=yes
  //## end ClientSimulator::ClientSimulator%3DE295CA005D.body
}


ClientSimulator::~ClientSimulator()
{
  //## begin ClientSimulator::~ClientSimulator%3DE26ED802EE_dest.body preserve=yes
   if (m_pResponses)
      fclose(m_pResponses);
   if (m_pRequests)
      fclose(m_pRequests);
  //## end ClientSimulator::~ClientSimulator%3DE26ED802EE_dest.body
}



//## Other Operations (implementation)
int ClientSimulator::initialize ()
{
  //## begin ClientSimulator::initialize%3DE26F1B007D.body preserve=yes
   new platform::Platform();
   Application::initialize();
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->attach(this);
   Database::instance()->connect();
   m_pRequests = fopen("queue.txt","r");
   if (m_pRequests == 0)
   {
      Trace::put("Unable to open queue.txt");
    return -1;
   }
   Extract::instance()->getSpec("CI",m_strConnection);
   m_strUserID = Application::instance()->name();
   Extract::instance()->getSpec("CIPASS",m_strPassword);
   m_strResponse = m_strUserID;
   m_strResponse += "responses.txt";
   Extract::instance()->getSpec("DELAY",m_strDelay);
   Trace::put("DELAY = ");
   Trace::put(m_strDelay.c_str());
   m_pResponses = fopen(m_strResponse.c_str(),"w");
   if (m_pResponses == 0)
   {
      Trace::put("Unable to open response.txt");
    return -1;
   }
   char *p = 0;
   char szBuffer[80000];
   while (fgets(szBuffer,80000,m_pRequests))
   {
      if (szBuffer[strlen(szBuffer) - 1] == '\n')
         szBuffer[strlen(szBuffer) - 1] = '\0';
      while (p = strchr(szBuffer,'['))
         *p = '\r';
      while (p = strchr(szBuffer,']'))
         *p = '\n';
      m_hRequests.push_back(string(szBuffer));
   }
   Extract::instance()->getSpec("STARTDTE",m_strStartDate);
   if(m_strStartDate.length() == 8)
   {
      Date hDate(m_strStartDate.c_str());
      m_hDate = hDate;
   }
   else
   {
      m_hDate = Date::today();
      m_strStartDate = m_hDate.asString("%Y%m%d");
   }
   Extract::instance()->getSpec("ENDDTE",m_strEndDate);
   if(m_strEndDate.length() < 8)
      m_strEndDate = "00000000";
   transact(m_hRequests.front());
   setQueueWaitOption(false);
   Sleep::goTo("00001000");
   Trace::put("end of ClientSimulator::initialize");
   return 0;
  //## end ClientSimulator::initialize%3DE26F1B007D.body
}

void ClientSimulator::interpretResponse (const string& strReply)
{
  //## begin ClientSimulator::interpretResponse%4059A4BD009C.body preserve=yes
   const char* p = strReply.c_str();
   if (strReply.substr(16,8) == "RDNLENHI")
   {
      p = strstr(p,"S225");
      while (p)
      {
         if (memcmp(p + 16,"PR",2) == 0)
            m_hProcessors.insert(string(p + 18,8));
         else
         if (memcmp(p + 16,"IN",2) == 0)
            m_hInstitutions.insert(string(p + 18,11));
         p = strstr(p + 1,"S225");
      }
   }
   else
   if (strReply.substr(16,8) == "RDNLDEV ")
   {
      p = strstr(p,"S232");
      while (p)
      {
         m_hInstitutions.insert(string(p + 16,11));
         m_hReportingLevels.insert(string(p + 27,10));
         m_hDevices.insert(string(p + 37,8));
         p = strstr(p + 1,"S232");
      }
   }
   else
   if (strReply.substr(16,8) == "RDNLTRAN")
   {
      if (m_hPANs.size() < 1000)
      {
         p = strstr(p,"S200");
         while (p)
         {
            m_hPANs.insert(string(p + 48,28));
            p = strstr(p + 1,"S200");
         }
      }
      p = strstr(strReply.c_str(),"S052");
      if (p)
         if (strstr(p,"00000075"))
            m_hDate = Date::today();
   }
  //## end ClientSimulator::interpretResponse%4059A4BD009C.body
}

void ClientSimulator::modifyRequest (string& strRequest)
{
  //## begin ClientSimulator::modifyRequest%4059AADF0232.body preserve=yes
   char* p = (char*)strRequest.c_str();
    if (strRequest.length() < 96)
      return;
   if (strRequest.substr(24,8) == "QLOGON  ")
   {
      if (m_strUserID.length() > 0)
      {
         strRequest.replace(184,8,"        ");
         strRequest.replace(184,m_strUserID.length(),m_strUserID);
         strRequest.replace(200,8,"        ");
         strRequest.replace(200,m_strPassword.length(),m_strPassword);
      }
   }
   else
   if (m_strSecurityData.length() == 64)
      strRequest.replace(32,64,m_strSecurityData);
   char* q;
   if (strRequest.substr(24,8) == "QDNLTRAN")
   {
      p = strstr(p,"S220");
      while (p)
      {
         segReportOptionSegment* pRO = (segReportOptionSegment*)p;
         segDefaultValue* pDV = (segDefaultValue*)(p + 268);
         if (m_hProcessors.size() > 0
            && memcmp(pRO->sCOLUMN_NAME,"PROC",4) == 0)
         {
            if (m_pProcessor == m_hProcessors.end())
               m_pProcessor = m_hProcessors.begin();
            memcpy(pDV->sDEFAULT_VALUE + 1,(*m_pProcessor).data(),(*m_pProcessor).length());
            ++m_pProcessor;
         }
         else
         if (m_hInstitutions.size() > 0
            && memcmp(pRO->sCOLUMN_NAME,"INST",4) == 0)
         {
            if (m_pInstitution == m_hInstitutions.end())
               m_pInstitution = m_hInstitutions.begin();
            memcpy(pDV->sDEFAULT_VALUE + 1,(*m_pInstitution).data(),(*m_pInstitution).length());
            ++m_pInstitution;
         }
         else
         if (m_hReportingLevels.size() > 0
            && memcmp(pRO->sCOLUMN_NAME,"RPT_LVL_ID_B",12) == 0)
         {
            if (m_pReportingLevel == m_hReportingLevels.end())
               m_pReportingLevel = m_hReportingLevels.begin();
            memcpy(pDV->sDEFAULT_VALUE + 1,(*m_pReportingLevel).data(),(*m_pReportingLevel).length());
            ++m_pReportingLevel;
         }
         else
         if (m_hDevices.size() > 0
            && memcmp(pRO->sCOLUMN_NAME,"NET_TERM_ID",11) == 0)
         {
            if (m_pDevice == m_hDevices.end())
               m_pDevice = m_hDevices.begin();
            memcpy(pDV->sDEFAULT_VALUE + 1,(*m_pDevice).data(),(*m_pDevice).length());
            ++m_pDevice;
         }
         else
         if (m_hPANs.size() > 0
            && memcmp(pRO->sCOLUMN_NAME,"PAN",3) == 0)
         {
            if (m_pPAN == m_hPANs.end())
               m_pPAN = m_hPANs.begin();
            memcpy(pDV->sDEFAULT_VALUE + 1,(*m_pPAN).data(),(*m_pPAN).length());
            ++m_pPAN;
         }
         else
         if (memcmp(pRO->sCOLUMN_NAME,"<alpha>",7) == 0)
         {
            memset(pRO->sCOLUMN_NAME,' ',7);
            memcpy(pRO->sCOLUMN_NAME,pszChar[m_nChar],strlen(pszChar[m_nChar]));
            ++m_nChar;
            if (m_nChar == CHAR_COLUMNS)
               m_nChar = 0;
         }
         else
         if (memcmp(pRO->sCOLUMN_NAME,"<numeric>",9) == 0)
         {
            memset(pRO->sCOLUMN_NAME,' ',9);
            memcpy(pRO->sCOLUMN_NAME,pszNumeric[m_nNumeric],strlen(pszNumeric[m_nNumeric]));
            ++m_nNumeric;
            if (m_nNumeric == NUMERIC_COLUMNS)
               m_nNumeric = 0;
         }
         else
         if (memcmp(pRO->sCOLUMN_NAME,"TSTAMP_TRANS",12) == 0)
         {
            char szTemp[3];
            snprintf(szTemp,sizeof(szTemp),"%02d",m_iHour);
            string strDate(m_hDate.asString("%Y%m%d"));
            strDate += szTemp;
            memcpy(pDV->sDEFAULT_VALUE + 1,strDate.data(),10);
            memcpy(pDV->sDEFAULT_VALUE + 24,strDate.data(),10);
            m_hDate -= 1;
            if(m_hDate.asString("%Y%m%d") < m_strEndDate)
            {
               Date hDate(m_strStartDate.c_str());
               m_hDate = hDate;
               m_iStartHour = (m_iStartHour < 1) ? 23 : m_iStartHour - 1;
               m_iHour = m_iStartHour;
            }
            else
               m_iHour = (m_iHour < 1) ? 23 : m_iHour - 1;
         }
         p = strstr(p + 1,"S220");
      }
   }
  //## end ClientSimulator::modifyRequest%4059AADF0232.body
}

int ClientSimulator::onQuiesce ()
{
  //## begin ClientSimulator::onQuiesce%3E50E348029F.body preserve=yes
   Trace::put("ClientSimulator::onQuiesce");
   setQueueWaitOption(true);
   transact(m_hRequests.back());
   Application::onQuiesce();
   return 0;
  //## end ClientSimulator::onQuiesce%3E50E348029F.body
}

int ClientSimulator::onResume (Message& hMessage)
{
  //## begin ClientSimulator::onResume%3E1DC61A009C.body preserve=yes
   Trace::put("ClientSimulator::onResume");
   Trace::put(m_strDelay.c_str());
   transact(m_hRequests[m_nIndex]);
   ++ m_nIndex;
   if (m_nIndex == m_hRequests.size() - 1)
      m_nIndex = 1;
   Sleep::goTo(m_strDelay.c_str());
   return 0;
  //## end ClientSimulator::onResume%3E1DC61A009C.body
}

int ClientSimulator::shutdown ()
{
  //## begin ClientSimulator::shutdown%3E1DC941002E.body preserve=yes
   Trace::put("ClientSimulator::shutdown");
   setQueueWaitOption(true);
   transact(m_hRequests.back());
   Application::shutdown();
   return 0;
  //## end ClientSimulator::shutdown%3E1DC941002E.body
}

void ClientSimulator::transact (const string& strMessage)
{
  //## begin ClientSimulator::transact%3E1DC6E502FD.body preserve=yes
   Trace::put("ClientSimulator::transact");
   string strRequest(strMessage);
   SynchronousSocket hSocket;
   string strReply;
   modifyRequest(strRequest);
   for (;;)
   {
      size_t pos = strRequest.find("S053");
      if (pos != string::npos)
      {
         time_t tTime;
         time(&tTime);
         tm *tmTime = localtime(&tTime);
         char szTimestamp[17];
         snprintf(szTimestamp,sizeof(szTimestamp),"%04d%02d%02d%02d%02d%02d00",
            tmTime->tm_year + 1900,tmTime->tm_mon + 1,tmTime->tm_mday,
            tmTime->tm_hour,tmTime->tm_min,tmTime->tm_sec);
         strRequest.replace(pos + 16,16,szTimestamp);
         if (m_strTimestamps.length() > 0)
            strRequest.replace(pos + 32,64,m_strTimestamps);
      }
      Trace::put(strRequest.data(),strRequest.length());
      hSocket.transact(m_strConnection.c_str(),strRequest,strReply);
      interpretResponse(strReply);
        if (strRequest.substr(24,8) == "QLOGON  ")
        m_strSecurityData = strReply.substr(24,64);
      pos = strReply.find("S053");
      if (pos != string::npos)
      {
         time_t tTime;
         time(&tTime);
         tm *tmTime = localtime(&tTime);
         char szTimestamp[17];
         snprintf(szTimestamp,sizeof(szTimestamp),"%04d%02d%02d%02d%02d%02d00",
            tmTime->tm_year + 1900,tmTime->tm_mon + 1,tmTime->tm_mday,
            tmTime->tm_hour,tmTime->tm_min,tmTime->tm_sec);
         strReply.replace(pos + 80,16,szTimestamp);
         m_strTimestamps.assign(strReply.data() + pos + 32,64);
      }
      Trace::put(strReply.data(),strReply.length());
        fputs(strReply.c_str(),m_pResponses);
        fputs("\n",m_pResponses);
      fflush(m_pResponses);
      pos = strReply.find("S0020101");
      if (pos == string::npos)
         break;
      if (strRequest.substr(24,8) == "QDNLTRAN")
         break;
      if (strReply[pos + 44] != 'F'
         && strReply[pos + 44] != 'M')
         break;
      pos = strRequest.find("S0020101");
      if (pos == string::npos)
         break;
      strRequest[pos + 16] = 'C';
      strRequest.replace(32,64,strReply.substr(24,64));
      //move context
      size_t posReply = strReply.find("S0020101");
      size_t posRequest = strRequest.find("S0020101");
      if(posReply == string::npos || posRequest == string::npos)
         break;
      strRequest.replace(posRequest+53,64,strReply.substr(posReply+53,64));
   }
  //## end ClientSimulator::transact%3E1DC6E502FD.body
}

// Additional Declarations
  //## begin ClientSimulator%3DE26ED802EE.declarations preserve=yes
  //## end ClientSimulator%3DE26ED802EE.declarations

//## begin module%3DE26F5B033C.epilog preserve=yes
//## end module%3DE26F5B033C.epilog
