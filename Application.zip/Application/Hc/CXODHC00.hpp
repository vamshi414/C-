//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5D14E78C01FA.cm preserve=no
//	$Date:   Aug 07 2019 16:55:52  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5D14E78C01FA.cm

//## begin module%5D14E78C01FA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5D14E78C01FA.cp

//## Module: CXOPHC00%5D14E78C01FA; Package specification
//## Subsystem: HC%5D10DAE4026D
//## Source file: C:\bV02.9B.R001\Windows\Build\Dn\Server\Application\Hc\CXODHC00.hpp

#ifndef CXOPHC00_h
#define CXOPHC00_h 1

//## begin module%5D14E78C01FA.additionalIncludes preserve=no
//## end module%5D14E78C01FA.additionalIncludes

//## begin module%5D14E78C01FA.includes preserve=yes
//## end module%5D14E78C01FA.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSNC19_h
#include "CXODNC19.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntityCommand_CAT%394E2706012A
namespace entitycommand {
class CRUpdateCommand;
} // namespace entitycommand

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace IF {
class Console;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class AuditEvent;
} // namespace segment

namespace database {
class DatabaseFactory;
} // namespace database

class NCREntityFile;

//## begin module%5D14E78C01FA.declarations preserve=no
//## end module%5D14E78C01FA.declarations

//## begin module%5D14E78C01FA.additionalDeclarations preserve=yes
//## end module%5D14E78C01FA.additionalDeclarations


//## begin NCREntityFileReader%5D14E5D300FA.preface preserve=yes
//## end NCREntityFileReader%5D14E5D300FA.preface

//## Class: NCREntityFileReader%5D14E5D300FA
//## Category: Platform \: NCR Authentic::NCREntityFileReader_CAT%5D10DA71029D
//## Subsystem: HC%5D10DAE4026D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5D14E6DF028D;monitor::UseCase { -> F}
//## Uses: <unnamed>%5D14E6E20086;IF::Message { -> F}
//## Uses: <unnamed>%5D14E6E500FE;entitycommand::CRUpdateCommand { -> F}
//## Uses: <unnamed>%5D14E6E703B8;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5D14E6EA03D2;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%5D168628009E;database::Database { -> F}
//## Uses: <unnamed>%5D168655017F;IF::Console { -> F}
//## Uses: <unnamed>%5D16874F00AA;segment::AuditEvent { -> F}

class DllExport NCREntityFileReader : public process::Application  //## Inherits: <unnamed>%5D14E6B60004
{
  //## begin NCREntityFileReader%5D14E5D300FA.initialDeclarations preserve=yes
  //## end NCREntityFileReader%5D14E5D300FA.initialDeclarations

  public:
    //## Constructors (generated)
      NCREntityFileReader();

    //## Destructor (generated)
      virtual ~NCREntityFileReader();


    //## Other Operations (specified)
      //## Operation: initialize%5D14E5F20388
      int initialize ();

    // Additional Public Declarations
      //## begin NCREntityFileReader%5D14E5D300FA.public preserve=yes
      //## end NCREntityFileReader%5D14E5D300FA.public

  protected:

    //## Other Operations (specified)
      //## Operation: onReset%5D14E5F20389
      int onReset (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin NCREntityFileReader%5D14E5D300FA.protected preserve=yes
      //## end NCREntityFileReader%5D14E5D300FA.protected

  private:
    // Additional Private Declarations
      //## begin NCREntityFileReader%5D14E5D300FA.private preserve=yes
      //## end NCREntityFileReader%5D14E5D300FA.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: NCR Authentic::NCREntityFileReader_CAT::<unnamed>%5D14EECD0101
      //## Role: NCREntityFileReader::<m_hNCREntityFile>%5D14EECE002F
      //## begin NCREntityFileReader::<m_hNCREntityFile>%5D14EECE002F.role preserve=no  public: NCREntityFile { -> VFHgN}
      NCREntityFile m_hNCREntityFile;
      //## end NCREntityFileReader::<m_hNCREntityFile>%5D14EECE002F.role

      //## Association: Platform \: NCR Authentic::NCREntityFileReader_CAT::<unnamed>%5D16842B02FE
      //## Role: NCREntityFileReader::<m_hCRFile>%5D16842C0167
      //## begin NCREntityFileReader::<m_hCRFile>%5D16842C0167.role preserve=no  public: entitycommand::CRFile { -> VHgN}
      entitycommand::CRFile m_hCRFile;
      //## end NCREntityFileReader::<m_hCRFile>%5D16842C0167.role

    // Additional Implementation Declarations
      //## begin NCREntityFileReader%5D14E5D300FA.implementation preserve=yes
      //## end NCREntityFileReader%5D14E5D300FA.implementation

};

//## begin NCREntityFileReader%5D14E5D300FA.postscript preserve=yes
//## end NCREntityFileReader%5D14E5D300FA.postscript

//## begin module%5D14E78C01FA.epilog preserve=yes
//## end module%5D14E78C01FA.epilog


#endif
