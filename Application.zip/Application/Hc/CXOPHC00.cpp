//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5D14E7890182.cm preserve=no
//	$Date:   Aug 07 2019 16:55:56  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5D14E7890182.cm

//## begin module%5D14E7890182.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5D14E7890182.cp

//## Module: CXOPHC00%5D14E7890182; Package body
//## Subsystem: HC%5D10DAE4026D
//## Source file: C:\bV02.9B.R001\Windows\Build\Dn\Server\Application\Hc\CXOPHC00.cpp

//## begin module%5D14E7890182.additionalIncludes preserve=no
//## end module%5D14E7890182.additionalIncludes

//## begin module%5D14E7890182.includes preserve=yes
//## end module%5D14E7890182.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSNC01_h
#include "CXODNC01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
#ifndef CXOSHC01_h
#include "CXODHC01.hpp"
#endif
#ifndef CXOPHC00_h
#include "CXODHC00.hpp"
#endif


//## begin module%5D14E7890182.declarations preserve=no
//## end module%5D14E7890182.declarations

//## begin module%5D14E7890182.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new NCREntityFileReader();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%5D14E7890182.additionalDeclarations


// Class NCREntityFileReader 

NCREntityFileReader::NCREntityFileReader()
  //## begin NCREntityFileReader::NCREntityFileReader%5D14E5D300FA_const.hasinit preserve=no
      : m_hCRFile("CR")
  //## end NCREntityFileReader::NCREntityFileReader%5D14E5D300FA_const.hasinit
  //## begin NCREntityFileReader::NCREntityFileReader%5D14E5D300FA_const.initialization preserve=yes
  //## end NCREntityFileReader::NCREntityFileReader%5D14E5D300FA_const.initialization
{
  //## begin NCREntityFileReader::NCREntityFileReader%5D14E5D300FA_const.body preserve=yes
   memcpy(m_sID,"HC00",4);
  //## end NCREntityFileReader::NCREntityFileReader%5D14E5D300FA_const.body
}


NCREntityFileReader::~NCREntityFileReader()
{
  //## begin NCREntityFileReader::~NCREntityFileReader%5D14E5D300FA_dest.body preserve=yes
  //## end NCREntityFileReader::~NCREntityFileReader%5D14E5D300FA_dest.body
}



//## Other Operations (implementation)
int NCREntityFileReader::initialize ()
{
  //## begin NCREntityFileReader::initialize%5D14E5F20388.body preserve=yes
   new dnplatform::DNPlatform();
   new segment::AuditEvent;
   int i = Application::initialize();
   UseCase hUseCase("NCR","## NC01 START NCR");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   CRUpdateCommand::instance();
   Database::instance()->connect();
   return 0;
  //## end NCREntityFileReader::initialize%5D14E5F20388.body
}

int NCREntityFileReader::onReset (IF::Message& hMessage)
{
  //## begin NCREntityFileReader::onReset%5D14E5F20389.body preserve=yes
   UseCase hUseCase("NCR","## NC02 RESET HC");
   if (hMessage.context().subString(1,2) == "CR")
   {
      m_hCRFile.process();
      CRUpdateCommand::instance()->notify();
      Console::display("ST128");
   }
   else
   {
      m_hNCREntityFile.process();
      CRUpdateCommand::instance()->notify();
      Console::display("ST128");
   }
  return 0;
  //## end NCREntityFileReader::onReset%5D14E5F20389.body
}

// Additional Declarations
  //## begin NCREntityFileReader%5D14E5D300FA.declarations preserve=yes
  //## end NCREntityFileReader%5D14E5D300FA.declarations

//## begin module%5D14E7890182.epilog preserve=yes
//## end module%5D14E7890182.epilog
