//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5D14EF7200FF.cm preserve=no
//	$Date:   Jul 23 2020 13:48:08  $ $Author:   e1009652  $
//	$Revision:   1.1  $
//## end module%5D14EF7200FF.cm

//## begin module%5D14EF7200FF.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5D14EF7200FF.cp

//## Module: CXOSHC01%5D14EF7200FF; Package body
//## Subsystem: HC%5D10DAE4026D
//## Source file: C:\bV02.9B.R001\Windows\Build\Dn\Server\Application\Hc\CXOSHC01.cpp

//## begin module%5D14EF7200FF.additionalIncludes preserve=no
//## end module%5D14EF7200FF.additionalIncludes

//## begin module%5D14EF7200FF.includes preserve=yes
//## end module%5D14EF7200FF.includes

#ifndef CXOSNS01_h
#include "CXODNS01.hpp"
#endif
#ifndef CXOSNS02_h
#include "CXODNS02.hpp"
#endif
#ifndef CXOSNS05_h
#include "CXODNS05.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF41_h
#include "CXODIF41.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif
#ifndef CXOSNC01_h
#include "CXODNC01.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSNS10_h
#include "CXODNS10.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSHC01_h
#include "CXODHC01.hpp"
#endif


//## begin module%5D14EF7200FF.declarations preserve=no
//## end module%5D14EF7200FF.declarations

//## begin module%5D14EF7200FF.additionalDeclarations preserve=yes
//## end module%5D14EF7200FF.additionalDeclarations


// Class NCREntityFile 

NCREntityFile::NCREntityFile()
  //## begin NCREntityFile::NCREntityFile%5D14ECC302E4_const.hasinit preserve=no
      : m_bHeaderValidated(false),
        m_iInsertCount(0),
        m_bReadInstitutionMap(false)
  //## end NCREntityFile::NCREntityFile%5D14ECC302E4_const.hasinit
  //## begin NCREntityFile::NCREntityFile%5D14ECC302E4_const.initialization preserve=yes
     ,CRFile("CED")
  //## end NCREntityFile::NCREntityFile%5D14ECC302E4_const.initialization
{
  //## begin NCREntityFile::NCREntityFile%5D14ECC302E4_const.body preserve=yes
   memcpy(m_sID,"HC01",4);
  //## end NCREntityFile::NCREntityFile%5D14ECC302E4_const.body
}


NCREntityFile::~NCREntityFile()
{
  //## begin NCREntityFile::~NCREntityFile%5D14ECC302E4_dest.body preserve=yes
  //## end NCREntityFile::~NCREntityFile%5D14ECC302E4_dest.body
}



//## Other Operations (implementation)
void NCREntityFile::copyATM ()
{
  //## begin NCREntityFile::copyATM%5D14ED6B0007.body preserve=yes
   UseCase hUseCase("NCR","## NC08 ATM");
  //## end NCREntityFile::copyATM%5D14ED6B0007.body
}

void NCREntityFile::copyEntity ()
{
  //## begin NCREntityFile::copyEntity%5D14ED5C02CF.body preserve=yes
   UseCase hUseCase("NCR","## NC04 REPORTING LEVEL");
   const char* pszCursor = m_psBuffer;
   extract(&pszCursor).c_str(); // EntityCategory
   string strEntityLevel(extract(&pszCursor,1)); // EntityLevel
   string strEntityId(extract(&pszCursor)); // AGENT/CHAIN
   extract(&pszCursor).c_str(); // AGENT/CHAIN
   m_pFileSegment = CRReportingLevelSegment::instance();
   CRReportingLevelSegment::instance()->reset();
   CRReportingLevelSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   string strRPT_LVL_ID(extract(&pszCursor,16));
   CRReportingLevelSegment::instance()->setRPT_LVL_ID(strRPT_LVL_ID);
   extract(&pszCursor).c_str(); // FISDIR
   CRReportingLevelSegment::instance()->setRPT_LVL_NAME(extract(&pszCursor,35));
   extract(&pszCursor).c_str(); // LOADER
   extract(&pszCursor).c_str(); // A
   string strNEXT_ID(extract(&pszCursor,16));
   CRReportingLevelSegment::instance()->setNEXT_ID(strNEXT_ID);
   CRReportingLevelSegment::instance()->setNEXT_CUST_ID(Customer::instance()->getCUST_ID());
  //## end NCREntityFile::copyEntity%5D14ED5C02CF.body
}

void NCREntityFile::copyInstitution ()
{
  //## begin NCREntityFile::copyInstitution%5D14ED55013F.body preserve=yes
   UseCase hUseCase("NCR","## NC03 INSTITUTION ");
   m_pFileSegment = CRInstitutionSegment::instance();
   CRInstitutionSegment::instance()->reset();
   CRInstitutionSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   const char* pszCursor = m_psBuffer;
   extract(&pszCursor).c_str(); // EntityCategory
   extract(&pszCursor).c_str(); // EntityLevel
   extract(&pszCursor).c_str(); // EntityType
   string strEntityDescription(extract(&pszCursor)); // EntityDescription
   CRInstitutionSegment::instance()->setINST_ID(extract(&pszCursor,11).c_str()); // EntityId
   CRInstitutionSegment::instance()->setNAME(extract(&pszCursor,35).c_str()); // InstitutionName
   CRInstitutionSegment::instance()->setPROC_ID(Customer::instance()->getCUST_ID());   
   extract(&pszCursor).c_str(); // InstitutionFiscalYearEnd
   extract(&pszCursor).c_str(); // LanguageCode
   extract(&pszCursor).c_str(); // SecondaryLanguageCode
   extract(&pszCursor).c_str(); // ISOCurrencyCode
   string strCUTOFF_TIME(extract(&pszCursor,8));
   strCUTOFF_TIME.resize(8,'0');
   CRInstitutionSegment::instance()->setCUTOFF_TIME(strCUTOFF_TIME);
   extract(&pszCursor).c_str(); // Address1
   extract(&pszCursor).c_str(); // Address2
   extract(&pszCursor).c_str(); // City
   extract(&pszCursor).c_str(); // ProvStateCode
   extract(&pszCursor).c_str(); // ProvStateNumberCode
   extract(&pszCursor).c_str(); // ProvinceState
   extract(&pszCursor).c_str(); // CountyCode
   extract(&pszCursor).c_str(); // County
   extract(&pszCursor).c_str(); // PostalCodeZip
   extract(&pszCursor).c_str(); // CountryCode
   extract(&pszCursor).c_str(); // Country
   extract(&pszCursor).c_str(); // Phone1
   extract(&pszCursor).c_str(); // Phone2
   extract(&pszCursor).c_str(); // Fax
   extract(&pszCursor).c_str(); // Email
   extract(&pszCursor).c_str(); // URL
   extract(&pszCursor).c_str(); // ModifiedDate
   if (strEntityDescription == "MAIN_INST")
   {
      string strPROC_ID(extract(&pszCursor,8).c_str()); // Processor
      if (strPROC_ID.length() > 0)
          CRInstitutionSegment::instance()->setPROC_ID(strPROC_ID);
   }
  //## end NCREntityFile::copyInstitution%5D14ED55013F.body
}

void NCREntityFile::copyMerchant ()
{
  //## begin NCREntityFile::copyMerchant%5D1C9E47039C.body preserve=yes
   UseCase hUseCase("NCR","## NC05 REPORTING LEVEL");
   m_pFileSegment = CRReportingLevelSegment::instance();
   CRReportingLevelSegment::instance()->reset();
   CRReportingLevelSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   const char* pszCursor = m_psBuffer;
   extract(&pszCursor).c_str(); // EntityCategory
   string strEntityLevel(extract(&pszCursor,1)); // EntityLevel
   string strEntityId(extract(&pszCursor)); // EntityId
   extract(&pszCursor).c_str(); // InstitutionId
   string strName(extract(&pszCursor,35)); // EntityName
   string strEntityDBAName(extract(&pszCursor,30).c_str()); // EntityDBAName
   extract(&pszCursor).c_str(); // EntityABANumber
   extract(&pszCursor).c_str(); // EntityStatus
   string strParentEntityId(extract(&pszCursor,16).c_str()); // ParentEntityId ...
   extract(&pszCursor).c_str(); // ExternalEntityId
   extract(&pszCursor).c_str(); // CreationDate
   extract(&pszCursor).c_str(); // ExpectedStartDate
   extract(&pszCursor).c_str(); // ActualStartDate
   extract(&pszCursor).c_str(); // TerminationDate
   extract(&pszCursor).c_str(); // VATRegNumber
   extract(&pszCursor).c_str(); // SettlementAgent
   extract(&pszCursor).c_str(); // TimeZoneDiff
   extract(&pszCursor).c_str(); // InvoiceBatch
   extract(&pszCursor).c_str(); // InvoiceSubCode
   extract(&pszCursor).c_str(); // ProcessChild
   extract(&pszCursor).c_str(); // CAPNumber
   extract(&pszCursor).c_str(); // TravelAgencyCode
   extract(&pszCursor).c_str(); // TravelAgencyName
   extract(&pszCursor).c_str(); // MVV
   extract(&pszCursor).c_str(); // OilCoBrandName
   extract(&pszCursor).c_str(); // pos_fcutover_time
   string strRPT_LVL_ID(extract(&pszCursor,16));
   CRReportingLevelSegment::instance()->setRPT_LVL_NAME(strName.c_str()); // EntityName
   ContactSegment::instance(ContactSegment::SENDER)->setNAME(strName);
   extract(&pszCursor).c_str(); // area
   string strDistrict(extract(&pszCursor,11).c_str()); // district
   ContactSegment::instance(ContactSegment::SENDER)->setADDRESS_LINE_1(extract(&pszCursor,28).c_str()); // Address
   (extract(&pszCursor).c_str()); //
   ContactSegment::instance(ContactSegment::SENDER)->setCITY(extract(&pszCursor,27).c_str()); // City
   ContactSegment::instance(ContactSegment::SENDER)->setREGION(extract(&pszCursor,2).c_str()); // State
   (extract(&pszCursor).c_str()); //
   (extract(&pszCursor).c_str()); //
   (extract(&pszCursor).c_str()); //
   (extract(&pszCursor).c_str()); //
   ContactSegment::instance(ContactSegment::SENDER)->setPOSTAL_CODE(extract(&pszCursor,10).c_str()); // zip code
   ContactSegment::instance(ContactSegment::SENDER)->setCONTACT_TYPE("ALL");
   ContactSegment::instance(ContactSegment::SENDER)->setUPDATED_BY_USER_ID("SYSTEM");
   ContactSegment::instance(ContactSegment::SENDER)->setTSTAMP_UPDATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
   ContactSegment::instance(ContactSegment::SENDER)->setPresence(true);
   CRReportingLevelSegment::instance()->setRPT_LVL_ID(strEntityId.length() > 16 ? strEntityId.substr(0,16).c_str() : strEntityId.c_str());
   ContactSegment::instance(ContactSegment::SENDER)->setRPT_LVL_ID(strEntityId.length() > 16 ? strEntityId.substr(0,16).c_str() : strEntityId.c_str());
   if(strParentEntityId.empty() || strParentEntityId.find_first_not_of(' ') == string::npos)
      CRReportingLevelSegment::instance()->setNEXT_ID(strEntityId.length() > 16 ? strEntityId.substr(0,16).c_str() : strEntityId.c_str());
   else
      CRReportingLevelSegment::instance()->setNEXT_ID(strParentEntityId.length() > 16 ? strParentEntityId.substr(0,16).c_str() : strParentEntityId.c_str());
   CRReportingLevelSegment::instance()->setNEXT_CUST_ID(Customer::instance()->getCUST_ID());
  //## end NCREntityFile::copyMerchant%5D1C9E47039C.body
}

void NCREntityFile::copyTerminal ()
{
  //## begin NCREntityFile::copyTerminal%5D14ED620061.body preserve=yes
   UseCase hUseCase("NCR","## NC07 TERMINAL");
   m_pFileSegment = CRDeviceSegment::instance();
   CRDeviceSegment::instance()->reset();
   CRDeviceSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   const char* pszCursor = m_psBuffer;
   extract(&pszCursor).c_str(); // EntityCategory
   extract(&pszCursor).c_str(); // TerminalGroupId
   string strDEVICE_ID(extract(&pszCursor,32));
   if (strDEVICE_ID.length() > 8)
      strDEVICE_ID.erase(0,strDEVICE_ID.length() - 8);
   CRDeviceSegment::instance()->setDEVICE_ID(strDEVICE_ID.c_str()); // TerminalId
   string strINST_ID(extract(&pszCursor,11).c_str()); //InstitutionId
   extract(&pszCursor).c_str(); // BarAccess
   extract(&pszCursor).c_str(); // ActualStartDate
   extract(&pszCursor).c_str(); // TerminationDate
   extract(&pszCursor).c_str(); // TerminalIdNumber
   string strParentEntityId(extract(&pszCursor)); // ParentEntityId
   extract(&pszCursor).c_str(); // DefaultCurrencyCode
   extract(&pszCursor).c_str(); // CPSEligible
   extract(&pszCursor).c_str(); // DefaultMCC
   extract(&pszCursor).c_str(); // CaptureType
   extract(&pszCursor).c_str(); // pos_fcutover_time
   // CRDeviceSegment::instance()->setCUTOFF_TIME(extract(&pszCursor,8).c_str()); // pos_fcutover_time
   CRDeviceSegment::instance()->setADDRESS(extract(&pszCursor,28).c_str()); // Address1
   extract(&pszCursor).c_str(); // Address2
   CRDeviceSegment::instance()->setCITY(extract(&pszCursor,27).c_str()); // City
   CRDeviceSegment::instance()->setREGION(extract(&pszCursor,3).c_str()); // ProvStateCode
   extract(&pszCursor).c_str(); // ProvStateNumberCode
   extract(&pszCursor).c_str(); // ProvinceState
   string strCOUNTY(extract(&pszCursor,3));
   CRDeviceSegment::instance()->setCOUNTY(strCOUNTY.c_str()); // CountyCode
   extract(&pszCursor).c_str(); // County
   CRDeviceSegment::instance()->setPOSTAL_CODE(extract(&pszCursor,10).c_str()); // PostalCodeZip
   CRDeviceSegment::instance()->setCOUNTRY(extract(&pszCursor,3).c_str()); // CountryCode
   CRDeviceSegment::instance()->setINST_ID(strINST_ID.c_str());
   CRDeviceSegment::instance()->setRPT_LVL_ID(strParentEntityId.length() > 16 ? strParentEntityId.substr(0,16).c_str():strParentEntityId.c_str()); //stationid
  //## end NCREntityFile::copyTerminal%5D14ED620061.body
}

string NCREntityFile::extract (const char** ppszCursor, int iLength)
{
  //## begin NCREntityFile::extract%5D14ED6F03BD.body preserve=yes
   const char* pszCursor = *ppszCursor;
   const char* p;
   if (*pszCursor == '"')
   {
      ++pszCursor;
      p = strchr(pszCursor,'"');
      if (!p)
         p = pszCursor;
      else
         *ppszCursor = p + 2;
   }
   else
   {
#ifdef MVS
      p = strchr(pszCursor,0x6A);
      if (!p)
#endif
         p = strchr(pszCursor,'|');
      if (!p)
      {
         p = pszCursor;
         string strTemp(pszCursor);
         *ppszCursor = p + strTemp.length();
         return strTemp;
      }
      else
         *ppszCursor = p + 1;
   }
   if (iLength == 0)
      return string(pszCursor,p - pszCursor);
   return string(pszCursor,min((int)(p - pszCursor),iLength));
  //## end NCREntityFile::extract%5D14ED6F03BD.body
}

void NCREntityFile::process ()
{
  //## begin NCREntityFile::process%5D14ED7E033C.body preserve=yes
   m_bHeaderValidated = false;
   CRFile::process();
  //## end NCREntityFile::process%5D14ED7E033C.body
}

bool NCREntityFile::read ()
{
  //## begin NCREntityFile::read%5D14ED7E0346.body preserve=yes
   size_t lRecordLength = 0;
   if (!m_pGenerationDataGroup)
   {
      m_pGenerationDataGroup = new GenerationDataGroup(Application::instance()->image(),
                                                       Application::instance()->name(),
                                                       getName().c_str());
      if (!m_pGenerationDataGroup->open())
         return false;
   }
   if (m_pFileSegment)
      m_pFileSegment->setPresence(false);
   m_pFileSegment = 0;
   if (!m_bHeaderValidated)
   {
      if (!m_pGenerationDataGroup->read(m_psBuffer,4096,&lRecordLength))
         return false;
      if ((m_bHeaderValidated = validateFileHeader()) != true)
      {
         m_pGenerationDataGroup->commit();
         Database::instance()->commit();
         return false;
      }
   }
   while (m_pFileSegment == 0)
   {
      lRecordLength = 0;
      if (!m_pGenerationDataGroup->read(m_psBuffer,4096,&lRecordLength))
      {
         if (!m_bRecordsFound)
         {
            m_pGenerationDataGroup->commit();
            Database::instance()->commit();
         }
         return false;
      }
      const char* pszCursor = m_psBuffer;
      string strEntityCategory(extract(&pszCursor));
      extract(&pszCursor); //EntityLevel
      string strEntityType(extract(&pszCursor));
      string strEntityDescription(extract(&pszCursor));
      ContactSegment::instance(ContactSegment::SENDER)->reset();
      if(strEntityCategory == "INSTITUTION")
            copyInstitution();
      else
      if(strEntityCategory == "ENTITY")
         copyEntity();
      else
      if(strEntityCategory == "MERCHANT")
         copyMerchant();
      else
      if(strEntityCategory == "TERMINAL")
         copyTerminal();
   }
   m_bRecordsFound = true;
   m_pFileSegment->setPresence(true);
   return true;
  //## end NCREntityFile::read%5D14ED7E0346.body
}

void NCREntityFile::update (Subject* pSubject)
{
  //## begin NCREntityFile::update%5D14ED7E0347.body preserve=yes
   if (pSubject != &m_hQuery)
      return CRFile::update(pSubject);
   if (++m_iInsertCount % 100 == 0)
      Database::instance()->commit();
  //## end NCREntityFile::update%5D14ED7E0347.body
}

bool NCREntityFile::validateFileHeader ()
{
  //## begin NCREntityFile::validateFileHeader%5D14ED7E0350.body preserve=yes
   const char* pszCursor = m_psBuffer;
   string strToken(extract(&pszCursor)); // RecordType
   if (!memcmp(strToken.c_str(),"HEADER",6) == 0)
      return false;
   return true;
  //## end NCREntityFile::validateFileHeader%5D14ED7E0350.body
}

// Additional Declarations
  //## begin NCREntityFile%5D14ECC302E4.declarations preserve=yes
  //## end NCREntityFile%5D14ECC302E4.declarations

//## begin module%5D14EF7200FF.epilog preserve=yes
//## end module%5D14EF7200FF.epilog
