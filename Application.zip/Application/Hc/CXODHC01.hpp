//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5D14EF700177.cm preserve=no
//	$Date:   Aug 07 2019 16:55:54  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%5D14EF700177.cm

//## begin module%5D14EF700177.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5D14EF700177.cp

//## Module: CXOSHC01%5D14EF700177; Package specification
//## Subsystem: HC%5D10DAE4026D
//## Source file: C:\bV02.9B.R001\Windows\Build\Dn\Server\Application\Hc\CXODHC01.hpp

#ifndef CXOSHC01_h
#define CXOSHC01_h 1

//## begin module%5D14EF700177.additionalIncludes preserve=no
//## end module%5D14EF700177.additionalIncludes

//## begin module%5D14EF700177.includes preserve=yes
//## end module%5D14EF700177.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSNC19_h
#include "CXODNC19.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntityCommand_CAT%394E2706012A
namespace entitycommand {
class CRUpdateCommand;
} // namespace entitycommand

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
class ContactSegment;
class CRDeviceSegment;
class CRInstitutionSegment;
class CRReportingLevelSegment;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace IF {
class VariableBlockFile;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class GenerationDataGroup;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%5D14EF700177.declarations preserve=no
//## end module%5D14EF700177.declarations

//## begin module%5D14EF700177.additionalDeclarations preserve=yes
//## end module%5D14EF700177.additionalDeclarations


//## begin NCREntityFile%5D14ECC302E4.preface preserve=yes
//## end NCREntityFile%5D14ECC302E4.preface

//## Class: NCREntityFile%5D14ECC302E4
//## Category: Platform \: NCR Authentic::NCREntityFileReader_CAT%5D10DA71029D
//## Subsystem: HC%5D10DAE4026D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5D14EDDC02D1;entitysegment::CRDeviceSegment { -> F}
//## Uses: <unnamed>%5D14EDDF0335;entitysegment::CRInstitutionSegment { -> F}
//## Uses: <unnamed>%5D14EDE20259;entitysegment::CRReportingLevelSegment { -> F}
//## Uses: <unnamed>%5D14EE0A026E;IF::CodeTable { -> F}
//## Uses: <unnamed>%5D14EE170021;IF::VariableBlockFile { -> F}
//## Uses: <unnamed>%5D14EE1A0071;IF::Extract { -> F}
//## Uses: <unnamed>%5D14EE1C034B;monitor::UseCase { -> F}
//## Uses: <unnamed>%5D14EE37005E;reusable::Statement { -> F}
//## Uses: <unnamed>%5D14EE390162;process::Application { -> F}
//## Uses: <unnamed>%5D14EE3B03E2;database::GenerationDataGroup { -> F}
//## Uses: <unnamed>%5D14EE3F0338;entitycommand::CRUpdateCommand { -> F}
//## Uses: <unnamed>%5D14EE4401E4;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%5D14EE5301F9;IF::Trace { -> F}
//## Uses: <unnamed>%5D14EE56011D;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5D14EE580343;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5D14EE5B0271;entitysegment::ContactSegment { -> F}
//## Uses: <unnamed>%5D14EE5E0249;timer::Clock { -> F}
//## Uses: <unnamed>%5D14EE64011E;entitysegment::Customer { -> F}
//## Uses: <unnamed>%5D168D1D01FB;database::Database { -> F}

class DllExport NCREntityFile : public entitycommand::CRFile  //## Inherits: <unnamed>%5D14EDC60082
{
  //## begin NCREntityFile%5D14ECC302E4.initialDeclarations preserve=yes
  //## end NCREntityFile%5D14ECC302E4.initialDeclarations

  public:
    //## Constructors (generated)
      NCREntityFile();

    //## Destructor (generated)
      virtual ~NCREntityFile();


    //## Other Operations (specified)
      //## Operation: copyATM%5D14ED6B0007
      virtual void copyATM ();

      //## Operation: copyEntity%5D14ED5C02CF
      virtual void copyEntity ();

      //## Operation: copyInstitution%5D14ED55013F
      virtual void copyInstitution ();

      //## Operation: copyMerchant%5D1C9E47039C
      virtual void copyMerchant ();

      //## Operation: copyTerminal%5D14ED620061
      virtual void copyTerminal ();

      //## Operation: extract%5D14ED6F03BD
      virtual string extract (const char** ppszCursor, int iLength = 0);

      //## Operation: process%5D14ED7E033C
      virtual void process ();

      //## Operation: read%5D14ED7E0346
      virtual bool read ();

      //## Operation: update%5D14ED7E0347
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

      //## Operation: validateFileHeader%5D14ED7E0350
      virtual bool validateFileHeader ();

    // Additional Public Declarations
      //## begin NCREntityFile%5D14ECC302E4.public preserve=yes
      //## end NCREntityFile%5D14ECC302E4.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: HeaderValidated%5D14EDA10239
      //## begin NCREntityFile::HeaderValidated%5D14EDA10239.attr preserve=no  protected: bool {U} false
      bool m_bHeaderValidated;
      //## end NCREntityFile::HeaderValidated%5D14EDA10239.attr

      //## Attribute: PROC_ID%5D168C660233
      //## begin NCREntityFile::PROC_ID%5D168C660233.attr preserve=no  protected: string {U} 
      string m_strPROC_ID;
      //## end NCREntityFile::PROC_ID%5D168C660233.attr

    // Additional Protected Declarations
      //## begin NCREntityFile%5D14ECC302E4.protected preserve=yes
      //## end NCREntityFile%5D14ECC302E4.protected

  private:
    // Additional Private Declarations
      //## begin NCREntityFile%5D14ECC302E4.private preserve=yes
      //## end NCREntityFile%5D14ECC302E4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: InsertCount%5D168C3B0331
      //## begin NCREntityFile::InsertCount%5D168C3B0331.attr preserve=no  private: int {V} 0
      int m_iInsertCount;
      //## end NCREntityFile::InsertCount%5D168C3B0331.attr

      //## Attribute: InstitutionMap%5D168B380210
      //## begin NCREntityFile::InstitutionMap%5D168B380210.attr preserve=no  private: map<string,int, less<string> > {V} 
      map<string,int, less<string> > m_hInstitutionMap;
      //## end NCREntityFile::InstitutionMap%5D168B380210.attr

      //## Attribute: MerchantMap%5D168B4F0140
      //## begin NCREntityFile::MerchantMap%5D168B4F0140.attr preserve=no  private: map<string,pair<string,string>,less<string> > {V} 
      map<string,pair<string,string>,less<string> > m_hMerchantMap;
      //## end NCREntityFile::MerchantMap%5D168B4F0140.attr

      //## Attribute: ReadInstitutionMap%5D168B4001B5
      //## begin NCREntityFile::ReadInstitutionMap%5D168B4001B5.attr preserve=no  private: bool {U} false
      bool m_bReadInstitutionMap;
      //## end NCREntityFile::ReadInstitutionMap%5D168B4001B5.attr

      //## Attribute: DEVICE_ID%5D168C660224
      //## begin NCREntityFile::DEVICE_ID%5D168C660224.attr preserve=no  private: string {U} 
      string m_strDEVICE_ID;
      //## end NCREntityFile::DEVICE_ID%5D168C660224.attr

      //## Attribute: INST_ID%5D168C660225
      //## begin NCREntityFile::INST_ID%5D168C660225.attr preserve=no  private: string {U} 
      string m_strINST_ID;
      //## end NCREntityFile::INST_ID%5D168C660225.attr

    // Data Members for Associations

      //## Association: Platform \: NCR Authentic::NCREntityFileReader_CAT::<unnamed>%5D168CBB0257
      //## Role: NCREntityFile::<m_hQuery>%5D168CBC0208
      //## begin NCREntityFile::<m_hQuery>%5D168CBC0208.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end NCREntityFile::<m_hQuery>%5D168CBC0208.role

    // Additional Implementation Declarations
      //## begin NCREntityFile%5D14ECC302E4.implementation preserve=yes
      //## end NCREntityFile%5D14ECC302E4.implementation

};

//## begin NCREntityFile%5D14ECC302E4.postscript preserve=yes
//## end NCREntityFile%5D14ECC302E4.postscript

//## begin module%5D14EF700177.epilog preserve=yes
//## end module%5D14EF700177.epilog


#endif
