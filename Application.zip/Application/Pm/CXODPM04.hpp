//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%396DCD5C00DB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%396DCD5C00DB.cm

//## begin module%396DCD5C00DB.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%396DCD5C00DB.cp

//## Module: CXOSPM04%396DCD5C00DB; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM04.hpp

#ifndef CXOSPM04_h
#define CXOSPM04_h 1

//## begin module%396DCD5C00DB.additionalIncludes preserve=no
//## end module%396DCD5C00DB.additionalIncludes

//## begin module%396DCD5C00DB.includes preserve=yes
// $Date:   May 24 2005 14:25:10  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%396DCD5C00DB.includes

#ifndef CXOSPM03_h
#include "CXODPM03.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class EvidenceSegment;
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%396DCD5C00DB.declarations preserve=no
//## end module%396DCD5C00DB.declarations

//## begin module%396DCD5C00DB.additionalDeclarations preserve=yes
//## end module%396DCD5C00DB.additionalDeclarations


//## begin ProblemTranslation%396DCFB301D7.preface preserve=yes
//## end ProblemTranslation%396DCFB301D7.preface

//## Class: ProblemTranslation%396DCFB301D7
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%396DD1E80139;reusable::Statement { -> F}
//## Uses: <unnamed>%396DD1EA01C8;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%396DD1ED001E;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%396DD1EF0021;configuration::EvidenceSegment { -> F}
//## Uses: <unnamed>%396DD1F1022D;reusable::Query { -> F}
//## Uses: <unnamed>%396DD2370300;reusable::Table { -> F}
//## Uses: <unnamed>%396DF38803D6;database::DatabaseFactory { -> F}

class ProblemTranslation : public Problem  //## Inherits: <unnamed>%396DD123010E
{
  //## begin ProblemTranslation%396DCFB301D7.initialDeclarations preserve=yes
  //## end ProblemTranslation%396DCFB301D7.initialDeclarations

  public:
    //## Constructors (generated)
      ProblemTranslation();

    //## Destructor (generated)
      virtual ~ProblemTranslation();


    //## Other Operations (specified)
      //## Operation: instance%3EBFBBA603B9
      static ProblemTranslation* instance ();

      //## Operation: repair%396DD93900BA
      Problem::State repair (configuration::EvidenceSegment& hEvidenceSegment);

    // Additional Public Declarations
      //## begin ProblemTranslation%396DCFB301D7.public preserve=yes
      //## end ProblemTranslation%396DCFB301D7.public

  protected:
    // Additional Protected Declarations
      //## begin ProblemTranslation%396DCFB301D7.protected preserve=yes
      //## end ProblemTranslation%396DCFB301D7.protected

  private:
    // Additional Private Declarations
      //## begin ProblemTranslation%396DCFB301D7.private preserve=yes
      //## end ProblemTranslation%396DCFB301D7.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3EBFBB8D002E
      //## begin ProblemTranslation::Instance%3EBFBB8D002E.attr preserve=no  private: static ProblemTranslation* {V} 0
      static ProblemTranslation* m_pInstance;
      //## end ProblemTranslation::Instance%3EBFBB8D002E.attr

    // Additional Implementation Declarations
      //## begin ProblemTranslation%396DCFB301D7.implementation preserve=yes
      //## end ProblemTranslation%396DCFB301D7.implementation

};

//## begin ProblemTranslation%396DCFB301D7.postscript preserve=yes
//## end ProblemTranslation%396DCFB301D7.postscript

//## begin module%396DCD5C00DB.epilog preserve=yes
//## end module%396DCD5C00DB.epilog


#endif
