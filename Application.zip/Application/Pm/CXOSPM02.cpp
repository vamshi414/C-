//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%393142AC0120.cm preserve=no
//	$Date:   Jul 12 2016 10:21:02  $ $Author:   e1009839  $
//	$Revision:   1.32  $
//## end module%393142AC0120.cm

//## begin module%393142AC0120.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%393142AC0120.cp

//## Module: CXOSPM02%393142AC0120; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM02.cpp

//## begin module%393142AC0120.additionalIncludes preserve=no
//## end module%393142AC0120.additionalIncludes

//## begin module%393142AC0120.includes preserve=yes
#include "CXODIF16.hpp"
//## end module%393142AC0120.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB30_h
#include "CXODDB30.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSPM04_h
#include "CXODPM04.hpp"
#endif
#ifndef CXOSPM05_h
#include "CXODPM05.hpp"
#endif
#ifndef CXOSPM06_h
#include "CXODPM06.hpp"
#endif
#ifndef CXOSPM07_h
#include "CXODPM07.hpp"
#endif
#ifndef CXOSPM08_h
#include "CXODPM08.hpp"
#endif
#ifndef CXOSPM10_h
#include "CXODPM10.hpp"
#endif
#ifndef CXOSPM09_h
#include "CXODPM09.hpp"
#endif
#ifndef CXOSPM11_h
#include "CXODPM11.hpp"
#endif
#ifndef CXOSPM15_h
#include "CXODPM15.hpp"
#endif
#ifndef CXOSPM02_h
#include "CXODPM02.hpp"
#endif


//## begin module%393142AC0120.declarations preserve=no
//## end module%393142AC0120.declarations

//## begin module%393142AC0120.additionalDeclarations preserve=yes
//## end module%393142AC0120.additionalDeclarations


// Class ProblemSolver 

//## begin ProblemSolver::Instance%393143CF02A5.attr preserve=no  private: static ProblemSolver* {V} 0
ProblemSolver* ProblemSolver::m_pInstance = 0;
//## end ProblemSolver::Instance%393143CF02A5.attr

ProblemSolver::ProblemSolver()
  //## begin ProblemSolver::ProblemSolver%391818D60142_const.hasinit preserve=no
      : m_iStatus(Problem::PTM_UNKNOWN),
        m_pProblemTranslation(0),
        m_pProblemVerification(0),
        m_pProblemReimbursementFlag(0),
        m_pProblemActionCode(0),
        m_pProblemAcquirerChain(0),
        m_pProblemIssuerAccountTypes(0),
        m_pProblemIssuerChain(0),
        m_pUnmatchedAuthorization(0),
        m_pProblemActionCodeTranslation(0)
  //## end ProblemSolver::ProblemSolver%391818D60142_const.hasinit
  //## begin ProblemSolver::ProblemSolver%391818D60142_const.initialization preserve=yes
  //## end ProblemSolver::ProblemSolver%391818D60142_const.initialization
{
  //## begin ProblemSolver::ProblemSolver%391818D60142_const.body preserve=yes
   memcpy(m_sID,"PM02",4);
   m_hQuery.attach(this);
   m_pProblemTranslation = ProblemTranslation::instance();
   m_pProblemVerification = ProblemVerification::instance();
   m_pProblemReimbursementFlag = ProblemReimbursementFlag::instance();
   m_pProblemActionCode = ProblemActionCode::instance();
   m_pProblemAcquirerChain = ProblemAcquirerChain::instance();
   m_pProblemIssuerAccountTypes = ProblemIssuerAccountTypes::instance();
   m_pProblemIssuerChain = ProblemIssuerChain::instance();
   m_pUnmatchedAuthorization = UnmatchedAuthorization::instance(); 
   m_pProblemActionCodeTranslation = ProblemActionCodeTranslation::instance();
  //## end ProblemSolver::ProblemSolver%391818D60142_const.body
}


ProblemSolver::~ProblemSolver()
{
  //## begin ProblemSolver::~ProblemSolver%391818D60142_dest.body preserve=yes
   delete m_pProblemTranslation;
   delete m_pProblemVerification;
   delete m_pProblemReimbursementFlag;
   delete m_pProblemActionCode;
   delete m_pProblemAcquirerChain;
   delete m_pProblemIssuerAccountTypes;
   delete m_pProblemIssuerChain;
   delete m_pUnmatchedAuthorization; 
   delete m_pProblemActionCodeTranslation;
  //## end ProblemSolver::~ProblemSolver%391818D60142_dest.body
}



//## Other Operations (implementation)
ProblemSolver* ProblemSolver::instance ()
{
  //## begin ProblemSolver::instance%393143E603AC.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ProblemSolver();
   return m_pInstance;
  //## end ProblemSolver::instance%393143E603AC.body
}

Problem::State ProblemSolver::repair (Problem& hProblem)
{
  //## begin ProblemSolver::repair%391819460283.body preserve=yes
   // AM03: SW_Repairs_Problem_Transaction
   UseCase hUseCase("ADMIN","## AM03 FIXES PROBLEM");
   m_iStatus = Problem::PTM_UNKNOWN;
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery.reset();
   m_hEvidenceSegment.bind(m_hQuery);
   m_hQuery.setBasicPredicate("PROBLEM_TRAN","TSTAMP_TRANS","=",hProblem.getTSTAMP_TRANS().c_str());
   m_hQuery.setBasicPredicate("PROBLEM_TRAN","UNIQUENESS_KEY","=",hProblem.getUNIQUENESS_KEY());
   m_hQuery.setBasicPredicate("PROBLEM_TRAN","REASON_CODE","=",hProblem.getREASON_CODE().c_str());
   m_hQuery.setBasicPredicate("PROBLEM_TRAN","SUSPECT_TABLE","=",hProblem.getSUSPECT_TABLE().c_str());
   m_hQuery.setBasicPredicate("PROBLEM_TRAN","SOURCE_VALUE","=",hProblem.getSOURCE_VALUE().c_str());
   m_hQuery.setBasicPredicate("PROBLEM_TRAN","PROBLEM_COLUMN","=",hProblem.getPROBLEM_COLUMN().c_str());
   m_hQuery.setBasicPredicate("PROBLEM_TRAN","PROBLEM_TABLE","=",hProblem.getPROBLEM_TABLE().c_str());
   if (!pSelectStatement->execute(m_hQuery))
      m_iStatus = Problem::PTM_SQL_ERROR;
   if (m_iStatus == Problem::PTM_FIXED)
   {
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      string strTable("FIN_RECORD");
      strTable.append(hProblem.getTSTAMP_TRANS().data(),6);
      Table hTable(strTable.c_str());
      //Fetch current INSERT_SEQUENCE_NO for this transaction.
      //if INSERT_SEQUENCE_NO is -2 then transaction needs interchange data before
      //it can be totaled so set INSERT_SEQUENCE_NO to -1 instead of a valid sequence.
      int iINSERT_SEQUENCE_NO = 0;
      {
         Query hQuery;
         hQuery.bind(strTable.c_str(),"INSERT_SEQUENCE_NO",Column::LONG,&iINSERT_SEQUENCE_NO);
         hQuery.setBasicPredicate(strTable.c_str(),"TSTAMP_TRANS","=",hProblem.getTSTAMP_TRANS().c_str());
         hQuery.setBasicPredicate(strTable.c_str(),"UNIQUENESS_KEY","=",hProblem.getUNIQUENESS_KEY());
         auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
         pSelectStatement->execute(hQuery);
         if (pSelectStatement->getRows() == 0)
         {
            m_iStatus = Problem::PTM_SQL_ERROR;
            Database::instance()->rollback();
            UseCase::setSuccess(false);
            return m_iStatus;
         }
      }
      if (iINSERT_SEQUENCE_NO == -2)
         hTable.set("INSERT_SEQUENCE_NO",-1);
      else
         hTable.set("INSERT_SEQUENCE_NO",InsertSequenceNumber::getYYYDDDHHMM());
      hTable.set("TSTAMP_TRANS",hProblem.getTSTAMP_TRANS(),false,true);
      hTable.set("UNIQUENESS_KEY",(int) hProblem.getUNIQUENESS_KEY(),true);
      bool bReturn = pUpdateStatement->execute(hTable);
      if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
         m_iStatus = Problem::PTM_NOT_FOUND;
      else
      if (!bReturn)
         m_iStatus = Problem::PTM_SQL_ERROR;
      else
      if (Extract::instance()->getCustomCode() == "MPS"
         && iINSERT_SEQUENCE_NO != -2)
      {
         string strTable("FIN_AMOUNT");
         strTable.append(hProblem.getTSTAMP_TRANS().data(),6);
         Table hTable(strTable.c_str());
         hTable.set("INSERT_SEQUENCE_NO",InsertSequenceNumber::getYYYDDDHHMM());
         hTable.set("TSTAMP_TRANS",hProblem.getTSTAMP_TRANS(),false,true);
         hTable.set("UNIQUENESS_KEY",(int) hProblem.getUNIQUENESS_KEY(),true);
         bool bReturn = pUpdateStatement->execute(hTable);
         if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
            ;
         else
         if (!bReturn)
            m_iStatus = Problem::PTM_SQL_ERROR;
      }
   }
   if (m_iStatus != Problem::PTM_SQL_ERROR)
   {
      Database::instance()->commit();
      return m_iStatus;
   }
   Database::instance()->rollback();
   UseCase::setSuccess(false);
   return m_iStatus;
  //## end ProblemSolver::repair%391819460283.body
}

void ProblemSolver::update (Subject* pSubject)
{
  //## begin ProblemSolver::update%391818FD03DD.body preserve=yes
   // AM03: SW_Repairs_Problem_Transaction
   Problem* pProblem = 0;
   int lReason_Code = atoi(m_hEvidenceSegment.getREASON_CODE().c_str());
   switch (lReason_Code)
   {
      case 1:
         pProblem = m_pProblemTranslation;
         break;
      case 2:
         pProblem = m_pProblemVerification;
         break;
      case 3:
         pProblem = m_pProblemReimbursementFlag;
         break;
      case 4:
         pProblem = m_pProblemActionCode;
         break;
      case 5:
         pProblem = m_pProblemAcquirerChain;
         break;
      case 6:
         pProblem = m_pProblemIssuerChain;
         break;
      case 7:
         pProblem = m_pProblemIssuerAccountTypes;
         break;
      case 9:
         pProblem = m_pUnmatchedAuthorization;
         break;   
      case 10:
         pProblem = m_pProblemActionCodeTranslation;
         break;
      default:
         m_iStatus = Problem::PTM_SQL_ERROR;
         m_hQuery.setAbort(true);
         pProblem = 0;
         return;
   }
   UseCase hUseCase("ADMIN",pProblem->getUseCase().c_str(),false);
   pProblem->setTSTAMP_TRANS(m_hEvidenceSegment.getTSTAMP_TRANS());
   pProblem->setUNIQUENESS_KEY(m_hEvidenceSegment.getUNIQUENESS_KEY());
   enum Problem::State iStatus = pProblem->repair(m_hEvidenceSegment);
   if (iStatus == Problem::PTM_FIXED
      || iStatus == Problem::PTM_PARTIAL_FIX
      || iStatus == Problem::PTM_NOT_FOUND)
   {
      Query hQuery;
      auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
      hQuery.setBasicPredicate("PROBLEM_TRAN","TSTAMP_TRANS","=",m_hEvidenceSegment.getTSTAMP_TRANS().c_str());
      hQuery.setBasicPredicate("PROBLEM_TRAN","UNIQUENESS_KEY","=",m_hEvidenceSegment.getUNIQUENESS_KEY());
      hQuery.setBasicPredicate("PROBLEM_TRAN","PROBLEM_COLUMN","=",m_hEvidenceSegment.getPROBLEM_COLUMN().c_str());
      if (!pDeleteStatement->execute(hQuery))
         iStatus = Problem::PTM_SQL_ERROR;
   }
   switch (iStatus)
   {
      case Problem::PTM_FIXED:
         if (m_iStatus == Problem::PTM_UNKNOWN)
            m_iStatus = iStatus;
         break;
      case Problem::PTM_PARTIAL_FIX:
      case Problem::PTM_NOT_FIXED:
         UseCase::setSuccess(false);
         m_iStatus = Problem::PTM_NOT_FIXED;
         break;
      case Problem::PTM_SQL_ERROR:
         UseCase::setSuccess(false);
         m_iStatus = iStatus;
         m_hQuery.setAbort(true);
         break;
      case Problem::PTM_NOT_FOUND:
         UseCase::setSuccess(false);
         m_iStatus = iStatus;
         break;
   }
  //## end ProblemSolver::update%391818FD03DD.body
}

// Additional Declarations
  //## begin ProblemSolver%391818D60142.declarations preserve=yes
  //## end ProblemSolver%391818D60142.declarations

//## begin module%393142AC0120.epilog preserve=yes
//## end module%393142AC0120.epilog
