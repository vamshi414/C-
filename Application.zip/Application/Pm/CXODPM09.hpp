//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%396DCD6C0016.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%396DCD6C0016.cm

//## begin module%396DCD6C0016.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%396DCD6C0016.cp

//## Module: CXOSPM09%396DCD6C0016; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM09.hpp

#ifndef CXOSPM09_h
#define CXOSPM09_h 1

//## begin module%396DCD6C0016.additionalIncludes preserve=no
//## end module%396DCD6C0016.additionalIncludes

//## begin module%396DCD6C0016.includes preserve=yes
// $Date:   May 24 2005 14:25:10  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%396DCD6C0016.includes

#ifndef CXOSPM03_h
#include "CXODPM03.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class EvidenceSegment;
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%396DCD6C0016.declarations preserve=no
//## end module%396DCD6C0016.declarations

//## begin module%396DCD6C0016.additionalDeclarations preserve=yes
//## end module%396DCD6C0016.additionalDeclarations


//## begin ProblemIssuerChain%396DCFBE038C.preface preserve=yes
//## end ProblemIssuerChain%396DCFBE038C.preface

//## Class: ProblemIssuerChain%396DCFBE038C
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%396DD5FA0228;reusable::Statement { -> F}
//## Uses: <unnamed>%396DD5FC0203;reusable::Query { -> F}
//## Uses: <unnamed>%396DD5FE0378;reusable::Table { -> F}
//## Uses: <unnamed>%396DD601011A;configuration::EvidenceSegment { -> F}
//## Uses: <unnamed>%396DD60701AE;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%396DD60D0352;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%396DF33E028F;database::DatabaseFactory { -> F}

class ProblemIssuerChain : public Problem  //## Inherits: <unnamed>%396DD5F70197
{
  //## begin ProblemIssuerChain%396DCFBE038C.initialDeclarations preserve=yes
  //## end ProblemIssuerChain%396DCFBE038C.initialDeclarations

  public:
    //## Constructors (generated)
      ProblemIssuerChain();

    //## Destructor (generated)
      virtual ~ProblemIssuerChain();


    //## Other Operations (specified)
      //## Operation: instance%3EBFBEF70261
      static ProblemIssuerChain* instance ();

      //## Operation: repair%396DD97703C7
      Problem::State repair (configuration::EvidenceSegment& hEvidenceSegment);

    // Additional Public Declarations
      //## begin ProblemIssuerChain%396DCFBE038C.public preserve=yes
      //## end ProblemIssuerChain%396DCFBE038C.public

  protected:
    // Additional Protected Declarations
      //## begin ProblemIssuerChain%396DCFBE038C.protected preserve=yes
      //## end ProblemIssuerChain%396DCFBE038C.protected

  private:
    // Additional Private Declarations
      //## begin ProblemIssuerChain%396DCFBE038C.private preserve=yes
      //## end ProblemIssuerChain%396DCFBE038C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3EBFBEE203C8
      //## begin ProblemIssuerChain::Instance%3EBFBEE203C8.attr preserve=no  private: static ProblemIssuerChain* {V} 0
      static ProblemIssuerChain* m_pInstance;
      //## end ProblemIssuerChain::Instance%3EBFBEE203C8.attr

    // Additional Implementation Declarations
      //## begin ProblemIssuerChain%396DCFBE038C.implementation preserve=yes
      //## end ProblemIssuerChain%396DCFBE038C.implementation

};

//## begin ProblemIssuerChain%396DCFBE038C.postscript preserve=yes
//## end ProblemIssuerChain%396DCFBE038C.postscript

//## begin module%396DCD6C0016.epilog preserve=yes
//## end module%396DCD6C0016.epilog


#endif
