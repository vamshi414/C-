//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%393684740180.cm preserve=no
//	$Date:   Jan 31 2017 14:09:12  $ $Author:   e1009510  $
//	$Revision:   1.11  $
//## end module%393684740180.cm

//## begin module%393684740180.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%393684740180.cp

//## Module: CXOSPM03%393684740180; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM03.hpp

#ifndef CXOSPM03_h
#define CXOSPM03_h 1

//## begin module%393684740180.additionalIncludes preserve=no
//## end module%393684740180.additionalIncludes

//## begin module%393684740180.includes preserve=yes
// $Date:   Jan 31 2017 14:09:12  $ $Author:   e1009510  $ $Revision:   1.11  $
#include "CXODBS09.hpp"
#include "CXODCF81.hpp"
//## end module%393684740180.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%393684740180.declarations preserve=no
//## end module%393684740180.declarations

//## begin module%393684740180.additionalDeclarations preserve=yes
//## end module%393684740180.additionalDeclarations


//## begin Problem%3931479A00CA.preface preserve=yes
//## end Problem%3931479A00CA.preface

//## Class: Problem%3931479A00CA
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3931481F036B;reusable::Query { -> F}

class Problem : public reusable::Object  //## Inherits: <unnamed>%393147C300A1
{
  //## begin Problem%3931479A00CA.initialDeclarations preserve=yes
  public:
      enum State
      {
         PTM_UNKNOWN,
         PTM_FIXED,
         PTM_PARTIAL_FIX,
         PTM_NOT_FIXED,
         PTM_SQL_ERROR,
         PTM_NOT_FOUND
      };
  //## end Problem%3931479A00CA.initialDeclarations

  public:
    //## Constructors (generated)
      Problem();

      Problem(const Problem &right);

    //## Destructor (generated)
      virtual ~Problem();

    //## Assignment Operation (generated)
      Problem & operator=(const Problem &right);


    //## Other Operations (specified)
      //## Operation: bind%393147E80109
      void bind (reusable::Query& hQuery);

      //## Operation: repair%396DD6CD019F
      virtual Problem::State repair (EvidenceSegment& hEvidenceSegment);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: PROBLEM_COLUMN%4DC410EB00F6
      const string& getPROBLEM_COLUMN () const
      {
        //## begin Problem::getPROBLEM_COLUMN%4DC410EB00F6.get preserve=no
        return m_strPROBLEM_COLUMN;
        //## end Problem::getPROBLEM_COLUMN%4DC410EB00F6.get
      }

      void setPROBLEM_COLUMN (const string& value)
      {
        //## begin Problem::setPROBLEM_COLUMN%4DC410EB00F6.set preserve=no
        m_strPROBLEM_COLUMN = value;
        //## end Problem::setPROBLEM_COLUMN%4DC410EB00F6.set
      }


      //## Attribute: PROBLEM_TABLE%4DC410EB010D
      const string& getPROBLEM_TABLE () const
      {
        //## begin Problem::getPROBLEM_TABLE%4DC410EB010D.get preserve=no
        return m_strPROBLEM_TABLE;
        //## end Problem::getPROBLEM_TABLE%4DC410EB010D.get
      }

      void setPROBLEM_TABLE (const string& value)
      {
        //## begin Problem::setPROBLEM_TABLE%4DC410EB010D.set preserve=no
        m_strPROBLEM_TABLE = value;
        //## end Problem::setPROBLEM_TABLE%4DC410EB010D.set
      }


      //## Attribute: REASON_CODE%4DC410EB0123
      const string& getREASON_CODE () const
      {
        //## begin Problem::getREASON_CODE%4DC410EB0123.get preserve=no
        return m_strREASON_CODE;
        //## end Problem::getREASON_CODE%4DC410EB0123.get
      }

      void setREASON_CODE (const string& value)
      {
        //## begin Problem::setREASON_CODE%4DC410EB0123.set preserve=no
        m_strREASON_CODE = value;
        //## end Problem::setREASON_CODE%4DC410EB0123.set
      }


      //## Attribute: SOURCE_VALUE%4DC410EB0130
      const string& getSOURCE_VALUE () const
      {
        //## begin Problem::getSOURCE_VALUE%4DC410EB0130.get preserve=no
        return m_strSOURCE_VALUE;
        //## end Problem::getSOURCE_VALUE%4DC410EB0130.get
      }

      void setSOURCE_VALUE (const string& value)
      {
        //## begin Problem::setSOURCE_VALUE%4DC410EB0130.set preserve=no
        m_strSOURCE_VALUE = value;
        //## end Problem::setSOURCE_VALUE%4DC410EB0130.set
      }


      //## Attribute: SUSPECT_TABLE%4DC410EB013A
      const string& getSUSPECT_TABLE () const
      {
        //## begin Problem::getSUSPECT_TABLE%4DC410EB013A.get preserve=no
        return m_strSUSPECT_TABLE;
        //## end Problem::getSUSPECT_TABLE%4DC410EB013A.get
      }

      void setSUSPECT_TABLE (const string& value)
      {
        //## begin Problem::setSUSPECT_TABLE%4DC410EB013A.set preserve=no
        m_strSUSPECT_TABLE = value;
        //## end Problem::setSUSPECT_TABLE%4DC410EB013A.set
      }


      //## Attribute: TSTAMP_TRANS%393147CC0068
      const string& getTSTAMP_TRANS () const
      {
        //## begin Problem::getTSTAMP_TRANS%393147CC0068.get preserve=no
        return m_strTSTAMP_TRANS;
        //## end Problem::getTSTAMP_TRANS%393147CC0068.get
      }

      void setTSTAMP_TRANS (const string& value)
      {
        //## begin Problem::setTSTAMP_TRANS%393147CC0068.set preserve=no
        m_strTSTAMP_TRANS = value;
        //## end Problem::setTSTAMP_TRANS%393147CC0068.set
      }


      //## Attribute: UNIQUENESS_KEY%393147D60012
      const short getUNIQUENESS_KEY () const
      {
        //## begin Problem::getUNIQUENESS_KEY%393147D60012.get preserve=no
        return m_iUNIQUENESS_KEY;
        //## end Problem::getUNIQUENESS_KEY%393147D60012.get
      }

      void setUNIQUENESS_KEY (short value)
      {
        //## begin Problem::setUNIQUENESS_KEY%393147D60012.set preserve=no
        m_iUNIQUENESS_KEY = value;
        //## end Problem::setUNIQUENESS_KEY%393147D60012.set
      }


      //## Attribute: UseCase%396F19FA003B
      const string& getUseCase () const
      {
        //## begin Problem::getUseCase%396F19FA003B.get preserve=no
        return m_strUseCase;
        //## end Problem::getUseCase%396F19FA003B.get
      }


    // Additional Public Declarations
      //## begin Problem%3931479A00CA.public preserve=yes
      //## end Problem%3931479A00CA.public

  protected:
    // Data Members for Class Attributes

      //## begin Problem::TSTAMP_TRANS%393147CC0068.attr preserve=no  public: string {V} 
      string m_strTSTAMP_TRANS;
      //## end Problem::TSTAMP_TRANS%393147CC0068.attr

      //## begin Problem::UNIQUENESS_KEY%393147D60012.attr preserve=no  public: short {V} 0
      short m_iUNIQUENESS_KEY;
      //## end Problem::UNIQUENESS_KEY%393147D60012.attr

      //## begin Problem::UseCase%396F19FA003B.attr preserve=no  public: string {U} 
      string m_strUseCase;
      //## end Problem::UseCase%396F19FA003B.attr

    // Additional Protected Declarations
      //## begin Problem%3931479A00CA.protected preserve=yes
      //## end Problem%3931479A00CA.protected

  private:
    // Additional Private Declarations
      //## begin Problem%3931479A00CA.private preserve=yes
      //## end Problem%3931479A00CA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin Problem::PROBLEM_COLUMN%4DC410EB00F6.attr preserve=no  public: string {U} 
      string m_strPROBLEM_COLUMN;
      //## end Problem::PROBLEM_COLUMN%4DC410EB00F6.attr

      //## begin Problem::PROBLEM_TABLE%4DC410EB010D.attr preserve=no  public: string {U} 
      string m_strPROBLEM_TABLE;
      //## end Problem::PROBLEM_TABLE%4DC410EB010D.attr

      //## begin Problem::REASON_CODE%4DC410EB0123.attr preserve=no  public: string {U} 
      string m_strREASON_CODE;
      //## end Problem::REASON_CODE%4DC410EB0123.attr

      //## begin Problem::SOURCE_VALUE%4DC410EB0130.attr preserve=no  public: string {U} 
      string m_strSOURCE_VALUE;
      //## end Problem::SOURCE_VALUE%4DC410EB0130.attr

      //## begin Problem::SUSPECT_TABLE%4DC410EB013A.attr preserve=no  public: string {U} 
      string m_strSUSPECT_TABLE;
      //## end Problem::SUSPECT_TABLE%4DC410EB013A.attr

    // Additional Implementation Declarations
      //## begin Problem%3931479A00CA.implementation preserve=yes
      //## end Problem%3931479A00CA.implementation

};

//## begin Problem%3931479A00CA.postscript preserve=yes
//## end Problem%3931479A00CA.postscript

//## begin module%393684740180.epilog preserve=yes
//## end module%393684740180.epilog


#endif
