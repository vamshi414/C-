//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3931426A002B.cm preserve=no
//## end module%3931426A002B.cm

//## begin module%3931426A002B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3931426A002B.cp

//## Module: CXOSPM01%3931426A002B; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Pm\CXODPM01.hpp

#ifndef CXOSPM01_h
#define CXOSPM01_h 1

//## begin module%3931426A002B.additionalIncludes preserve=no
//## end module%3931426A002B.additionalIncludes

//## begin module%3931426A002B.includes preserve=yes
// $Date:   Sep 14 2010 15:26:46  $ $Author:   E1024360  $ $Revision:   1.12  $
//## end module%3931426A002B.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

class Issue;
class Problem;
class ProblemSolver;
//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Timer;
} // namespace timer

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%3931426A002B.declarations preserve=no
//## end module%3931426A002B.declarations

//## begin module%3931426A002B.additionalDeclarations preserve=yes
#include "CXODTM01.hpp" //Timer
#include "CXODPM14.hpp" //Issue
#include "CXODPM03.hpp" //Problem
//## end module%3931426A002B.additionalDeclarations


//## begin ProblemMediator%393140A00267.preface preserve=yes
#include <deque>
//## end ProblemMediator%393140A00267.preface

//## Class: ProblemMediator%393140A00267
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%393140D90327;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%393140DC0014;reusable::Query { -> F}
//## Uses: <unnamed>%393140DE020C;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%393143600269;ProblemSolver { -> F}
//## Uses: <unnamed>%3936B066026D;database::Database { -> F}
//## Uses: <unnamed>%3A3925E20392;monitor::UseCase { -> F}
//## Uses: <unnamed>%4B2130150064;IF::Extract { -> F}
//## Uses: <unnamed>%4C8111EA002A;Issue { -> F}
//## Uses: <unnamed>%4C8E66FD0209;process::Application { -> F}
//## Uses: <unnamed>%4C8FD2110337;Problem { -> F}

class ProblemMediator : public reusable::Observer  //## Inherits: <unnamed>%393140BF0031
{
  //## begin ProblemMediator%393140A00267.initialDeclarations preserve=yes
  //## end ProblemMediator%393140A00267.initialDeclarations

  public:
    //## Constructors (generated)
      ProblemMediator();

    //## Destructor (generated)
      virtual ~ProblemMediator();


    //## Other Operations (specified)
      //## Operation: instance%3931439D0267
      static ProblemMediator* instance ();

      //## Operation: retrieve%3936855103E1
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>PM
      //	<h2>FI
      //	<h3>Problem Transactions
      //	<p>
      //	Evidence related to problem transactions is retrieved
      //	from:
      //	<ul>
      //	<li><i>custqual</i>.PROBLEM_TRAN
      //	</ul>
      //	</body>
      bool retrieve ();

      //## Operation: update%393140E20348
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject = 0);

    // Additional Public Declarations
      //## begin ProblemMediator%393140A00267.public preserve=yes
      //## end ProblemMediator%393140A00267.public

  protected:
    // Additional Protected Declarations
      //## begin ProblemMediator%393140A00267.protected preserve=yes
      //## end ProblemMediator%393140A00267.protected

  private:
    // Additional Private Declarations
      //## begin ProblemMediator%393140A00267.private preserve=yes
      //## end ProblemMediator%393140A00267.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%393143840094
      //## begin ProblemMediator::Instance%393143840094.attr preserve=no  private: static ProblemMediator* {V} 0
      static ProblemMediator* m_pInstance;
      //## end ProblemMediator::Instance%393143840094.attr

      //## Attribute: Issue%4C80F911019E
      //## begin ProblemMediator::Issue%4C80F911019E.attr preserve=no  private: Issue {U} 
      Issue m_hIssue;
      //## end ProblemMediator::Issue%4C80F911019E.attr

      //## Attribute: Issues%4C80FBBC0390
      //## begin ProblemMediator::Issues%4C80FBBC0390.attr preserve=no  private: deque <Issue> {U} 
      deque <Issue> m_hIssues;
      //## end ProblemMediator::Issues%4C80FBBC0390.attr

      //## Attribute: Problem%39368630002A
      //## begin ProblemMediator::Problem%39368630002A.attr preserve=no  private: Problem {U} 
      Problem m_hProblem;
      //## end ProblemMediator::Problem%39368630002A.attr

      //## Attribute: TimerValue%4C87F6F301F0
      //## begin ProblemMediator::TimerValue%4C87F6F301F0.attr preserve=no  private: int {U} 3600
      int m_iTimerValue;
      //## end ProblemMediator::TimerValue%4C87F6F301F0.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%4C87F65A034B
      //## Role: ProblemMediator::<m_hTimer>%4C87F65C002E
      //## begin ProblemMediator::<m_hTimer>%4C87F65C002E.role preserve=no  public: timer::Timer { -> VFHgN}
      timer::Timer m_hTimer;
      //## end ProblemMediator::<m_hTimer>%4C87F65C002E.role

    // Additional Implementation Declarations
      //## begin ProblemMediator%393140A00267.implementation preserve=yes
	  int m_iIndex;
      //## end ProblemMediator%393140A00267.implementation
};

//## begin ProblemMediator%393140A00267.postscript preserve=yes
//## end ProblemMediator%393140A00267.postscript

//## begin module%3931426A002B.epilog preserve=yes
//## end module%3931426A002B.epilog


#endif
