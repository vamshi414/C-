//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%396DCD6402E6.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%396DCD6402E6.cm

//## begin module%396DCD6402E6.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%396DCD6402E6.cp

//## Module: CXOSPM07%396DCD6402E6; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM07.hpp

#ifndef CXOSPM07_h
#define CXOSPM07_h 1

//## begin module%396DCD6402E6.additionalIncludes preserve=no
//## end module%396DCD6402E6.additionalIncludes

//## begin module%396DCD6402E6.includes preserve=yes
// $Date:   May 24 2005 14:25:10  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%396DCD6402E6.includes

#ifndef CXOSPM03_h
#include "CXODPM03.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class EvidenceSegment;
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%396DCD6402E6.declarations preserve=no
//## end module%396DCD6402E6.declarations

//## begin module%396DCD6402E6.additionalDeclarations preserve=yes
//## end module%396DCD6402E6.additionalDeclarations


//## begin ProblemActionCode%396DCFBC000D.preface preserve=yes
//## end ProblemActionCode%396DCFBC000D.preface

//## Class: ProblemActionCode%396DCFBC000D
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%396DD4F0028A;reusable::Statement { -> F}
//## Uses: <unnamed>%396DD4F80335;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%396DD50101DA;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%396DD50403E7;reusable::Table { -> F}
//## Uses: <unnamed>%396DD50801F8;reusable::Query { -> F}
//## Uses: <unnamed>%396DD50D01A5;configuration::EvidenceSegment { -> F}
//## Uses: <unnamed>%396DF35A03DA;database::DatabaseFactory { -> F}

class ProblemActionCode : public Problem  //## Inherits: <unnamed>%396DD4EE006A
{
  //## begin ProblemActionCode%396DCFBC000D.initialDeclarations preserve=yes
  //## end ProblemActionCode%396DCFBC000D.initialDeclarations

  public:
    //## Constructors (generated)
      ProblemActionCode();

    //## Destructor (generated)
      virtual ~ProblemActionCode();


    //## Other Operations (specified)
      //## Operation: instance%3EBFBDE4037A
      static ProblemActionCode* instance ();

      //## Operation: repair%396DD96C02F8
      Problem::State repair (configuration::EvidenceSegment& hEvidenceSegment);

    // Additional Public Declarations
      //## begin ProblemActionCode%396DCFBC000D.public preserve=yes
      //## end ProblemActionCode%396DCFBC000D.public

  protected:
    // Additional Protected Declarations
      //## begin ProblemActionCode%396DCFBC000D.protected preserve=yes
      //## end ProblemActionCode%396DCFBC000D.protected

  private:
    // Additional Private Declarations
      //## begin ProblemActionCode%396DCFBC000D.private preserve=yes
      //## end ProblemActionCode%396DCFBC000D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3EBFBDCE0196
      //## begin ProblemActionCode::Instance%3EBFBDCE0196.attr preserve=no  private: static ProblemActionCode* {V} 0
      static ProblemActionCode* m_pInstance;
      //## end ProblemActionCode::Instance%3EBFBDCE0196.attr

    // Additional Implementation Declarations
      //## begin ProblemActionCode%396DCFBC000D.implementation preserve=yes
      //## end ProblemActionCode%396DCFBC000D.implementation

};

//## begin ProblemActionCode%396DCFBC000D.postscript preserve=yes
//## end ProblemActionCode%396DCFBC000D.postscript

//## begin module%396DCD6402E6.epilog preserve=yes
//## end module%396DCD6402E6.epilog


#endif
