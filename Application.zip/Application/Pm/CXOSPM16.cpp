//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4E034A500084.cm preserve=no
//	$Date:   Sep 19 2011 04:56:44  $ $Author:   D02684  $
//	$Revision:   1.0  $
//## end module%4E034A500084.cm

//## begin module%4E034A500084.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4E034A500084.cp

//## Module: CXOSPM16%4E034A500084; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM16.cpp

//## begin module%4E034A500084.additionalIncludes preserve=no
//## end module%4E034A500084.additionalIncludes

//## begin module%4E034A500084.includes preserve=yes
//## end module%4E034A500084.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSPM16_h
#include "CXODPM16.hpp"
#endif


//## begin module%4E034A500084.declarations preserve=no
//## end module%4E034A500084.declarations

//## begin module%4E034A500084.additionalDeclarations preserve=yes
#define FIELDS 4
Fields ProblemSummarySegment_Fields[FIELDS + 1] = 
{
   "a        X","CRClientBook",0,0,
   "a        X","ReasonDescription",0,0,
   "a        X","SOURCE_VALUE",0,0,
   "l        X","Count",0,0,
   "~","~",0,0,
};
//## end module%4E034A500084.additionalDeclarations


// Class ProblemSummarySegment 

ProblemSummarySegment::ProblemSummarySegment()
  //## begin ProblemSummarySegment::ProblemSummarySegment%4E0344D701FD_const.hasinit preserve=no
      : m_iCount(0),
        m_iNull(0)
  //## end ProblemSummarySegment::ProblemSummarySegment%4E0344D701FD_const.hasinit
  //## begin ProblemSummarySegment::ProblemSummarySegment%4E0344D701FD_const.initialization preserve=yes
  //## end ProblemSummarySegment::ProblemSummarySegment%4E0344D701FD_const.initialization
{
  //## begin ProblemSummarySegment::ProblemSummarySegment%4E0344D701FD_const.body preserve=yes
   setFields();
  //## end ProblemSummarySegment::ProblemSummarySegment%4E0344D701FD_const.body
}

ProblemSummarySegment::ProblemSummarySegment(const ProblemSummarySegment &right)
  //## begin ProblemSummarySegment::ProblemSummarySegment%4E0344D701FD_copy.hasinit preserve=no
      : m_iCount(0),
        m_iNull(0)
  //## end ProblemSummarySegment::ProblemSummarySegment%4E0344D701FD_copy.hasinit
  //## begin ProblemSummarySegment::ProblemSummarySegment%4E0344D701FD_copy.initialization preserve=yes
  //## end ProblemSummarySegment::ProblemSummarySegment%4E0344D701FD_copy.initialization
{
  //## begin ProblemSummarySegment::ProblemSummarySegment%4E0344D701FD_copy.body preserve=yes
   setFields();
   copyValues(right);
  //## end ProblemSummarySegment::ProblemSummarySegment%4E0344D701FD_copy.body
}


ProblemSummarySegment::~ProblemSummarySegment()
{
  //## begin ProblemSummarySegment::~ProblemSummarySegment%4E0344D701FD_dest.body preserve=yes
   delete [] m_pField;
  //## end ProblemSummarySegment::~ProblemSummarySegment%4E0344D701FD_dest.body
}


ProblemSummarySegment & ProblemSummarySegment::operator=(const ProblemSummarySegment &right)
{
  //## begin ProblemSummarySegment::operator=%4E0344D701FD_assign.body preserve=yes
   if (*this == right)
      return *this;
   copyValues(right);
   return *this;
  //## end ProblemSummarySegment::operator=%4E0344D701FD_assign.body
}


bool ProblemSummarySegment::operator==(const ProblemSummarySegment &right) const
{
  //## begin ProblemSummarySegment::operator==%4E0344D701FD_eq.body preserve=yes
   if (m_strREASON_CODE == right.m_strREASON_CODE &&
      m_strSUSPECT_TABLE == right.m_strSUSPECT_TABLE &&
      m_strSOURCE_VALUE == right.m_strSOURCE_VALUE &&
      m_iCount == right.m_iCount )
      return true;
   else
      return false;
  //## end ProblemSummarySegment::operator==%4E0344D701FD_eq.body
}

bool ProblemSummarySegment::operator!=(const ProblemSummarySegment &right) const
{
  //## begin ProblemSummarySegment::operator!=%4E0344D701FD_neq.body preserve=yes
   return !(operator==(right));
  //## end ProblemSummarySegment::operator!=%4E0344D701FD_neq.body
}



//## Other Operations (implementation)
void ProblemSummarySegment::bind (reusable::Query& hQuery)
{
  //## begin ProblemSummarySegment::bind%4E034D340368.body preserve=yes
   hQuery.bind("PROBLEM_TRAN","REASON_CODE",Column::STRING,&m_strREASON_CODE);
   hQuery.bind("PROBLEM_TRAN","SUSPECT_TABLE",Column::STRING,&m_strSUSPECT_TABLE);
   hQuery.bind("PROBLEM_TRAN","SOURCE_VALUE",Column::STRING,&m_strSOURCE_VALUE);
   hQuery.bind("PROBLEM_TRAN","*",Column::LONG,&m_iCount,&m_iNull,"COUNT");
   hQuery.setGroupByClause("REASON_CODE, SUSPECT_TABLE, SOURCE_VALUE");
   hQuery.setOrderByClause("REASON_CODE, SUSPECT_TABLE, SOURCE_VALUE");
  //## end ProblemSummarySegment::bind%4E034D340368.body
}

void ProblemSummarySegment::copyValues (const ProblemSummarySegment& right)
{
  //## begin ProblemSummarySegment::copyValues%4E044B3B0192.body preserve=yes
   m_strREASON_CODE = right.m_strREASON_CODE;
   m_strSUSPECT_TABLE = right.m_strSUSPECT_TABLE;
   m_strSOURCE_VALUE = right.m_strSOURCE_VALUE;
   m_iCount = right.m_iCount;
   m_iNull = right.m_iNull;
   m_strCRClientBook = right.m_strCRClientBook;
   m_strReasonDescription = right.m_strReasonDescription;
  //## end ProblemSummarySegment::copyValues%4E044B3B0192.body
}

struct  Fields* ProblemSummarySegment::fields () const
{
  //## begin ProblemSummarySegment::fields%4E04A8C302E8.body preserve=yes
   return &ProblemSummarySegment_Fields[0];
  //## end ProblemSummarySegment::fields%4E04A8C302E8.body
}

void ProblemSummarySegment::setDescription ()
{
  //## begin ProblemSummarySegment::setDescription%4E049AB20251.body preserve=yes
  ConfigurationRepository::instance()->getCRBook(m_strSUSPECT_TABLE.c_str(),m_strCRClientBook);
    if (m_strCRClientBook.length() < 25)
     m_strCRClientBook.append(25 - m_strCRClientBook.length(),' ');
  
  if(m_strSOURCE_VALUE.length() < 11 )
     m_strSOURCE_VALUE.append(11 - m_strSOURCE_VALUE.length(),' ');
  else
  {
     m_strSOURCE_VALUE.erase(8);
     m_strSOURCE_VALUE.append(3,'.');
  }

  switch (atoi(m_strREASON_CODE.c_str(),m_strREASON_CODE.length()))
   {
      case 1:
         m_strReasonDescription = "Translate Failure              ";
         break;
      case 2:
         m_strReasonDescription = "Verification Failure           ";
         break;
      case 3:
         m_strReasonDescription = "Translate Failure (Reimb. Flag)";
         break;
      case 4:
      case 10:
         m_strReasonDescription = "Translate Failure (Action Code)";
         break;
      case 5:
         m_strReasonDescription = "Acquirer Side Re-chain Failure ";
         break;
      case 6:
         m_strReasonDescription = "Issuer Side Re-chain Failure   ";
         break;
      case 7:
         m_strReasonDescription = "Translate Failure (Account)    ";
         break;
   }
  //## end ProblemSummarySegment::setDescription%4E049AB20251.body
}

void ProblemSummarySegment::setFields ()
{
  //## begin ProblemSummarySegment::setFields%4E04ABBE0038.body preserve=yes
   memcpy(m_sID,"PM16",4);
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strCRClientBook;
   m_pField[1] = &m_strReasonDescription;
   m_pField[2] = &m_strSOURCE_VALUE;
   m_pField[3] = &m_iCount;
  //## end ProblemSummarySegment::setFields%4E04ABBE0038.body
}

// Additional Declarations
  //## begin ProblemSummarySegment%4E0344D701FD.declarations preserve=yes
  //## end ProblemSummarySegment%4E0344D701FD.declarations

//## begin module%4E034A500084.epilog preserve=yes
//## end module%4E034A500084.epilog
