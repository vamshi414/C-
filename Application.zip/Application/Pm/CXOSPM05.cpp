//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%396DCD5D03C2.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%396DCD5D03C2.cm

//## begin module%396DCD5D03C2.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%396DCD5D03C2.cp

//## Module: CXOSPM05%396DCD5D03C2; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM05.cpp

//## begin module%396DCD5D03C2.additionalIncludes preserve=no
//## end module%396DCD5D03C2.additionalIncludes

//## begin module%396DCD5D03C2.includes preserve=yes
// $Date:   May 24 2005 14:25:12  $ $Author:   D02405  $ $Revision:   1.6  $
#include "CXODRU24.hpp"
//## end module%396DCD5D03C2.includes

#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSPM05_h
#include "CXODPM05.hpp"
#endif


//## begin module%396DCD5D03C2.declarations preserve=no
//## end module%396DCD5D03C2.declarations

//## begin module%396DCD5D03C2.additionalDeclarations preserve=yes
//## end module%396DCD5D03C2.additionalDeclarations


// Class ProblemVerification 

//## begin ProblemVerification::Instance%3EBFBCAD01F4.attr preserve=no  private: static ProblemVerification* {V} 0
ProblemVerification* ProblemVerification::m_pInstance = 0;
//## end ProblemVerification::Instance%3EBFBCAD01F4.attr

ProblemVerification::ProblemVerification()
  //## begin ProblemVerification::ProblemVerification%396DCFB90190_const.hasinit preserve=no
  //## end ProblemVerification::ProblemVerification%396DCFB90190_const.hasinit
  //## begin ProblemVerification::ProblemVerification%396DCFB90190_const.initialization preserve=yes
  //## end ProblemVerification::ProblemVerification%396DCFB90190_const.initialization
{
  //## begin ProblemVerification::ProblemVerification%396DCFB90190_const.body preserve=yes
   memcpy(m_sID,"PM05",4);
   m_strUseCase = "## AM11 VERIFICATION";
  //## end ProblemVerification::ProblemVerification%396DCFB90190_const.body
}


ProblemVerification::~ProblemVerification()
{
  //## begin ProblemVerification::~ProblemVerification%396DCFB90190_dest.body preserve=yes
  //## end ProblemVerification::~ProblemVerification%396DCFB90190_dest.body
}



//## Other Operations (implementation)
ProblemVerification* ProblemVerification::instance ()
{
  //## begin ProblemVerification::instance%3EBFBCC700CB.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ProblemVerification();
   return m_pInstance;
  //## end ProblemVerification::instance%3EBFBCC700CB.body
}

Problem::State ProblemVerification::repair (configuration::EvidenceSegment& hEvidenceSegment)
{
  //## begin ProblemVerification::repair%396DD9610072.body preserve=yes
   // AM11: SW_Repairs_Verification
   if (ConfigurationRepository::instance()->verify(hEvidenceSegment.getSUSPECT_TABLE().c_str(),
      hEvidenceSegment.getSOURCE_VALUE(), 0) == false)
      return PTM_NOT_FIXED;
   return PTM_FIXED;
  //## end ProblemVerification::repair%396DD9610072.body
}

// Additional Declarations
  //## begin ProblemVerification%396DCFB90190.declarations preserve=yes
  //## end ProblemVerification%396DCFB90190.declarations

//## begin module%396DCD5D03C2.epilog preserve=yes
//## end module%396DCD5D03C2.epilog
