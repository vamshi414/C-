//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%396DCD720015.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%396DCD720015.cm

//## begin module%396DCD720015.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%396DCD720015.cp

//## Module: CXOSPM10%396DCD720015; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM10.cpp

//## begin module%396DCD720015.additionalIncludes preserve=no
//## end module%396DCD720015.additionalIncludes

//## begin module%396DCD720015.includes preserve=yes
// $Date:   Feb 02 2009 07:10:42  $ $Author:   D02405  $ $Revision:   1.16  $
#include "CXODIF16.hpp"
//## end module%396DCD720015.includes

#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSPM10_h
#include "CXODPM10.hpp"
#endif


//## begin module%396DCD720015.declarations preserve=no
//## end module%396DCD720015.declarations

//## begin module%396DCD720015.additionalDeclarations preserve=yes
//## end module%396DCD720015.additionalDeclarations


// Class ProblemIssuerAccountTypes 

//## begin ProblemIssuerAccountTypes::Instance%3EBFBF7D0232.attr preserve=no  private: static ProblemIssuerAccountTypes* {V} 0
ProblemIssuerAccountTypes* ProblemIssuerAccountTypes::m_pInstance = 0;
//## end ProblemIssuerAccountTypes::Instance%3EBFBF7D0232.attr

ProblemIssuerAccountTypes::ProblemIssuerAccountTypes()
  //## begin ProblemIssuerAccountTypes::ProblemIssuerAccountTypes%396DCFC00334_const.hasinit preserve=no
  //## end ProblemIssuerAccountTypes::ProblemIssuerAccountTypes%396DCFC00334_const.hasinit
  //## begin ProblemIssuerAccountTypes::ProblemIssuerAccountTypes%396DCFC00334_const.initialization preserve=yes
  //## end ProblemIssuerAccountTypes::ProblemIssuerAccountTypes%396DCFC00334_const.initialization
{
  //## begin ProblemIssuerAccountTypes::ProblemIssuerAccountTypes%396DCFC00334_const.body preserve=yes
   memcpy(m_sID,"PM10",4);
   m_strUseCase = "## AM16 ISSUER ACCOUNT TYPES";
  //## end ProblemIssuerAccountTypes::ProblemIssuerAccountTypes%396DCFC00334_const.body
}


ProblemIssuerAccountTypes::~ProblemIssuerAccountTypes()
{
  //## begin ProblemIssuerAccountTypes::~ProblemIssuerAccountTypes%396DCFC00334_dest.body preserve=yes
  //## end ProblemIssuerAccountTypes::~ProblemIssuerAccountTypes%396DCFC00334_dest.body
}



//## Other Operations (implementation)
ProblemIssuerAccountTypes* ProblemIssuerAccountTypes::instance ()
{
  //## begin ProblemIssuerAccountTypes::instance%3EBFC03F003E.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ProblemIssuerAccountTypes();
   return m_pInstance;
  //## end ProblemIssuerAccountTypes::instance%3EBFC03F003E.body
}

Problem::State ProblemIssuerAccountTypes::repair (configuration::EvidenceSegment& hEvidenceSegment)
{
  //## begin ProblemIssuerAccountTypes::repair%396DD97C01E3.body preserve=yes
   // AM16: SW_Repairs_Issuer_Account_Types
   string strTranslatedValue;
   if (ConfigurationRepository::instance()->translate(hEvidenceSegment.getSUSPECT_TABLE().c_str(),
      hEvidenceSegment.getSOURCE_VALUE(),strTranslatedValue,"","",0) == false)
   {
      string strTemp(hEvidenceSegment.getSOURCE_VALUE());
      if (strTemp.length() > 9)
      {
        strTemp.replace(7,3,"   ",3);
        if (ConfigurationRepository::instance()->translate(hEvidenceSegment.getSUSPECT_TABLE().c_str(),
           strTemp,strTranslatedValue,"","",0) == false)
           return PTM_NOT_FIXED;
      }
      else 
        return PTM_NOT_FIXED;
   }
   string strTable("FIN_RECORD");
#ifdef MVS
   string strValue;
   Extract::instance()->getSpec("MODEL",strValue);
   if (strValue == "OPEN")
#endif
      strTable.append(m_strTSTAMP_TRANS.data(),6);
   Table hTable(strTable.c_str());
   hTable.set("ACCT_TYPES_ISS",strTranslatedValue.substr(2,4));
   hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int)m_iUNIQUENESS_KEY,true);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   bool bReturn = pUpdateStatement->execute(hTable);
   if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      return PTM_NOT_FOUND;
   if (!bReturn)
      return PTM_SQL_ERROR;
   hTable.reset();
   hTable.setName("FIN_L" + m_strTSTAMP_TRANS.substr(0,6));
   hTable.set("TRAN_TYPE_ID",strTranslatedValue);
   hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int)m_iUNIQUENESS_KEY,true);
   if (pUpdateStatement->execute(hTable))
      return PTM_FIXED;
   return PTM_SQL_ERROR;
  //## end ProblemIssuerAccountTypes::repair%396DD97C01E3.body
}

// Additional Declarations
  //## begin ProblemIssuerAccountTypes%396DCFC00334.declarations preserve=yes
  //## end ProblemIssuerAccountTypes%396DCFC00334.declarations

//## begin module%396DCD720015.epilog preserve=yes
//## end module%396DCD720015.epilog
