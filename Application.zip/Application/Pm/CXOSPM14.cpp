//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4C7FE750012D.cm preserve=no
//	$Date:   Sep 14 2010 15:26:56  $ $Author:   E1024360  $
//	$Revision:   1.1  $
//## end module%4C7FE750012D.cm

//## begin module%4C7FE750012D.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4C7FE750012D.cp

//## Module: CXOSPM14%4C7FE750012D; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM14.cpp

//## begin module%4C7FE750012D.additionalIncludes preserve=no
//## end module%4C7FE750012D.additionalIncludes

//## begin module%4C7FE750012D.includes preserve=yes
//## end module%4C7FE750012D.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSPM14_h
#include "CXODPM14.hpp"
#endif


//## begin module%4C7FE750012D.declarations preserve=no
//## end module%4C7FE750012D.declarations

//## begin module%4C7FE750012D.additionalDeclarations preserve=yes
//## end module%4C7FE750012D.additionalDeclarations


// Class Issue 

Issue::Issue()
  //## begin Issue::Issue%4C7FE6AB03DD_const.hasinit preserve=no
  //## end Issue::Issue%4C7FE6AB03DD_const.hasinit
  //## begin Issue::Issue%4C7FE6AB03DD_const.initialization preserve=yes
  //## end Issue::Issue%4C7FE6AB03DD_const.initialization
{
  //## begin Issue::Issue%4C7FE6AB03DD_const.body preserve=yes
   memcpy(m_sID,"PM14",4);
  //## end Issue::Issue%4C7FE6AB03DD_const.body
}

Issue::Issue(const Issue &right)
  //## begin Issue::Issue%4C7FE6AB03DD_copy.hasinit preserve=no
  //## end Issue::Issue%4C7FE6AB03DD_copy.hasinit
  //## begin Issue::Issue%4C7FE6AB03DD_copy.initialization preserve=yes
   :Object(right)
  //## end Issue::Issue%4C7FE6AB03DD_copy.initialization
{
  //## begin Issue::Issue%4C7FE6AB03DD_copy.body preserve=yes
   memcpy(m_sID,"PM14",4);
   m_strPROBLEM_COLUMN = right.getPROBLEM_COLUMN();
   m_strPROBLEM_TABLE = right.getPROBLEM_TABLE();
   m_strREASON_CODE = right.getREASON_CODE();
   m_strSOURCE_VALUE = right.getSOURCE_VALUE();
   m_strSUSPECT_TABLE = right.getSUSPECT_TABLE();
   m_strTSTAMP_TRANS = right.getTSTAMP_TRANS();
  //## end Issue::Issue%4C7FE6AB03DD_copy.body
}


Issue::~Issue()
{
  //## begin Issue::~Issue%4C7FE6AB03DD_dest.body preserve=yes
  //## end Issue::~Issue%4C7FE6AB03DD_dest.body
}


Issue & Issue::operator=(const Issue &right)
{
  //## begin Issue::operator=%4C7FE6AB03DD_assign.body preserve=yes
   if (this == &right)
      return *this;
   Object::operator=(right);
   m_strPROBLEM_COLUMN = right.getPROBLEM_COLUMN();
   m_strPROBLEM_TABLE = right.getPROBLEM_TABLE();
   m_strREASON_CODE = right.getREASON_CODE();
   m_strSOURCE_VALUE = right.getSOURCE_VALUE();
   m_strSUSPECT_TABLE = right.getSUSPECT_TABLE();
   m_strTSTAMP_TRANS = right.getTSTAMP_TRANS();
   return *this;
  //## end Issue::operator=%4C7FE6AB03DD_assign.body
}



//## Other Operations (implementation)
void Issue::bind (reusable::Query& hQuery)
{
  //## begin Issue::bind%4C81207300D9.body preserve=yes
   hQuery.bind("PROBLEM_TRAN","REASON_CODE",Column::STRING,&m_strREASON_CODE);
   hQuery.bind("PROBLEM_TRAN","SOURCE_VALUE",Column::STRING,&m_strSOURCE_VALUE);
   hQuery.bind("PROBLEM_TRAN","SUSPECT_TABLE",Column::STRING,&m_strSUSPECT_TABLE);
   hQuery.bind("PROBLEM_TRAN","PROBLEM_COLUMN",Column::STRING,&m_strPROBLEM_COLUMN);
   hQuery.bind("PROBLEM_TRAN","PROBLEM_TABLE",Column::STRING,&m_strPROBLEM_TABLE);
   hQuery.bind("PROBLEM_TRAN","TSTAMP_TRANS",Column::STRING,&m_strTSTAMP_TRANS,0,"MIN");
  //## end Issue::bind%4C81207300D9.body
}

// Additional Declarations
  //## begin Issue%4C7FE6AB03DD.declarations preserve=yes
  //## end Issue%4C7FE6AB03DD.declarations

//## begin module%4C7FE750012D.epilog preserve=yes
//## end module%4C7FE750012D.epilog
