//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4ACE539800B3.cm preserve=no
//	$Date:   Dec 01 2009 13:41:40  $ $Author:   E1024360  $
//	$Revision:   1.1  $
//## end module%4ACE539800B3.cm

//## begin module%4ACE539800B3.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4ACE539800B3.cp

//## Module: CXOSPM12%4ACE539800B3; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM12.hpp

#ifndef CXOSPM12_h
#define CXOSPM12_h 1

//## begin module%4ACE539800B3.additionalIncludes preserve=no
//## end module%4ACE539800B3.additionalIncludes

//## begin module%4ACE539800B3.includes preserve=yes
//## end module%4ACE539800B3.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
class Column;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Audit;
} // namespace command

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ImportReportAuditSegment;

} // namespace segment

//## begin module%4ACE539800B3.declarations preserve=no
//## end module%4ACE539800B3.declarations

//## begin module%4ACE539800B3.additionalDeclarations preserve=yes
//## end module%4ACE539800B3.additionalDeclarations


//## begin UnmatchedAuthorizationAudit%4ACE5351022A.preface preserve=yes
//## end UnmatchedAuthorizationAudit%4ACE5351022A.preface

//## Class: UnmatchedAuthorizationAudit%4ACE5351022A
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4ACF5CBA02D0;timer::Date { -> F}
//## Uses: <unnamed>%4ACF5DB203A9;segment::ImportReportAuditSegment { -> F}
//## Uses: <unnamed>%4ACF5E620167;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%4ACF609C0121;entitysegment::Customer { -> F}
//## Uses: <unnamed>%4ACF617D0033;database::Database { -> F}
//## Uses: <unnamed>%4ACF742F01CB;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4ACF7497014E;reusable::Column { -> F}
//## Uses: <unnamed>%4ACF74990380;reusable::Query { -> F}
//## Uses: <unnamed>%4ACF74DA0073;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4B0ACDE50158;configuration::ConfigurationRepository { -> F}

class DllExport UnmatchedAuthorizationAudit : public reusable::Observer  //## Inherits: <unnamed>%4ACE5459019A
{
  //## begin UnmatchedAuthorizationAudit%4ACE5351022A.initialDeclarations preserve=yes
  //## end UnmatchedAuthorizationAudit%4ACE5351022A.initialDeclarations

  public:
    //## Constructors (generated)
      UnmatchedAuthorizationAudit();

    //## Destructor (generated)
      virtual ~UnmatchedAuthorizationAudit();


    //## Other Operations (specified)
      //## Operation: add%4ACF575A0220
      void add (char cReportType, const string& strIMPORT_KEY, int iREJECT_CODE);

      //## Operation: instance%4ACF814401F9
      static UnmatchedAuthorizationAudit* instance ();

      //## Operation: writeAudit%4ACE54310247
      int writeAudit ();

      //## Operation: writeHeader%4ACF58E70302
      void writeHeader (const string& strDate);

      //## Operation: update%4ACF57370099
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin UnmatchedAuthorizationAudit%4ACE5351022A.public preserve=yes
      //## end UnmatchedAuthorizationAudit%4ACE5351022A.public

  protected:
    // Additional Protected Declarations
      //## begin UnmatchedAuthorizationAudit%4ACE5351022A.protected preserve=yes
      //## end UnmatchedAuthorizationAudit%4ACE5351022A.protected

  private:
    // Additional Private Declarations
      //## begin UnmatchedAuthorizationAudit%4ACE5351022A.private preserve=yes
      //## end UnmatchedAuthorizationAudit%4ACE5351022A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%4ACF812000B1
      //## begin UnmatchedAuthorizationAudit::Instance%4ACF812000B1.attr preserve=no  private: static UnmatchedAuthorizationAudit* {U} 0
      static UnmatchedAuthorizationAudit* m_pInstance;
      //## end UnmatchedAuthorizationAudit::Instance%4ACF812000B1.attr

      //## Attribute: SOURCE_VALUE%4B0ACF2402B5
      //## begin UnmatchedAuthorizationAudit::SOURCE_VALUE%4B0ACF2402B5.attr preserve=no  private: string {U} 
      string m_strSOURCE_VALUE;
      //## end UnmatchedAuthorizationAudit::SOURCE_VALUE%4B0ACF2402B5.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%4ACF5C120051
      //## Role: UnmatchedAuthorizationAudit::<m_pAudit>%4ACF5C120264
      //## begin UnmatchedAuthorizationAudit::<m_pAudit>%4ACF5C120264.role preserve=no  public: command::Audit { -> RFHgN}
      command::Audit *m_pAudit;
      //## end UnmatchedAuthorizationAudit::<m_pAudit>%4ACF5C120264.role

    // Additional Implementation Declarations
      //## begin UnmatchedAuthorizationAudit%4ACE5351022A.implementation preserve=yes
      //## end UnmatchedAuthorizationAudit%4ACE5351022A.implementation

};

//## begin UnmatchedAuthorizationAudit%4ACE5351022A.postscript preserve=yes
//## end UnmatchedAuthorizationAudit%4ACE5351022A.postscript

//## begin module%4ACE539800B3.epilog preserve=yes
//## end module%4ACE539800B3.epilog


#endif
