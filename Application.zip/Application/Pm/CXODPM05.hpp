//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%396DCD5A027D.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%396DCD5A027D.cm

//## begin module%396DCD5A027D.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%396DCD5A027D.cp

//## Module: CXOSPM05%396DCD5A027D; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM05.hpp

#ifndef CXOSPM05_h
#define CXOSPM05_h 1

//## begin module%396DCD5A027D.additionalIncludes preserve=no
//## end module%396DCD5A027D.additionalIncludes

//## begin module%396DCD5A027D.includes preserve=yes
// $Date:   May 24 2005 14:25:10  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%396DCD5A027D.includes

#ifndef CXOSPM03_h
#include "CXODPM03.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class EvidenceSegment;
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%396DCD5A027D.declarations preserve=no
//## end module%396DCD5A027D.declarations

//## begin module%396DCD5A027D.additionalDeclarations preserve=yes
//## end module%396DCD5A027D.additionalDeclarations


//## begin ProblemVerification%396DCFB90190.preface preserve=yes
//## end ProblemVerification%396DCFB90190.preface

//## Class: ProblemVerification%396DCFB90190
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%396DD3CB036F;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%396DD3D2001B;reusable::Query { -> F}
//## Uses: <unnamed>%396DD3D40050;configuration::EvidenceSegment { -> F}
//## Uses: <unnamed>%396DD3D603E3;reusable::Table { -> F}
//## Uses: <unnamed>%396DD3DA0149;reusable::Statement { -> F}
//## Uses: <unnamed>%396DD3DE02CC;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%396DF3730245;database::DatabaseFactory { -> F}

class ProblemVerification : public Problem  //## Inherits: <unnamed>%396DD3C902F4
{
  //## begin ProblemVerification%396DCFB90190.initialDeclarations preserve=yes
  //## end ProblemVerification%396DCFB90190.initialDeclarations

  public:
    //## Constructors (generated)
      ProblemVerification();

    //## Destructor (generated)
      virtual ~ProblemVerification();


    //## Other Operations (specified)
      //## Operation: instance%3EBFBCC700CB
      static ProblemVerification* instance ();

      //## Operation: repair%396DD9610072
      Problem::State repair (configuration::EvidenceSegment& hEvidenceSegment);

    // Additional Public Declarations
      //## begin ProblemVerification%396DCFB90190.public preserve=yes
      //## end ProblemVerification%396DCFB90190.public

  protected:
    // Additional Protected Declarations
      //## begin ProblemVerification%396DCFB90190.protected preserve=yes
      //## end ProblemVerification%396DCFB90190.protected

  private:
    // Additional Private Declarations
      //## begin ProblemVerification%396DCFB90190.private preserve=yes
      //## end ProblemVerification%396DCFB90190.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3EBFBCAD01F4
      //## begin ProblemVerification::Instance%3EBFBCAD01F4.attr preserve=no  private: static ProblemVerification* {V} 0
      static ProblemVerification* m_pInstance;
      //## end ProblemVerification::Instance%3EBFBCAD01F4.attr

    // Additional Implementation Declarations
      //## begin ProblemVerification%396DCFB90190.implementation preserve=yes
      //## end ProblemVerification%396DCFB90190.implementation

};

//## begin ProblemVerification%396DCFB90190.postscript preserve=yes
//## end ProblemVerification%396DCFB90190.postscript

//## begin module%396DCD5A027D.epilog preserve=yes
//## end module%396DCD5A027D.epilog


#endif
