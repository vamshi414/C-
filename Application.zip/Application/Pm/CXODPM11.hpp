//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4ACDFD2C02A8.cm preserve=no
//	$Date:   Nov 20 2009 06:04:10  $ $Author:   E1024360  $
//	$Revision:   1.1  $
//## end module%4ACDFD2C02A8.cm

//## begin module%4ACDFD2C02A8.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4ACDFD2C02A8.cp

//## Module: CXOSPM11%4ACDFD2C02A8; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM11.hpp

#ifndef CXOSPM11_h
#define CXOSPM11_h 1

//## begin module%4ACDFD2C02A8.additionalIncludes preserve=no
//## end module%4ACDFD2C02A8.additionalIncludes

//## begin module%4ACDFD2C02A8.includes preserve=yes
//## end module%4ACDFD2C02A8.includes

#ifndef CXOSPM03_h
#include "CXODPM03.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
class CaseCreateCommand;
} // namespace emscommand

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class Case;
class DisputedAuthorization;
} // namespace ems

class UnmatchedAuthorizationAudit;
//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
} // namespace timer

namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%4ACDFD2C02A8.declarations preserve=no
//## end module%4ACDFD2C02A8.declarations

//## begin module%4ACDFD2C02A8.additionalDeclarations preserve=yes
//## end module%4ACDFD2C02A8.additionalDeclarations


//## begin UnmatchedAuthorization%4ACDFCF600F2.preface preserve=yes
//## end UnmatchedAuthorization%4ACDFCF600F2.preface

//## Class: UnmatchedAuthorization%4ACDFCF600F2
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4ACE28FF00B5;ems::DisputedAuthorization { -> F}
//## Uses: <unnamed>%4ACE33AB0059;emscommand::CaseCreateCommand { -> F}
//## Uses: <unnamed>%4ACF7E800175;reusable::Query { -> F}
//## Uses: <unnamed>%4ACF7EAC00C9;reusable::Statement { -> F}
//## Uses: <unnamed>%4ACF7EF40250;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4ACF7F14002D;timer::Date { -> F}
//## Uses: <unnamed>%4ACF806A01BF;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4AE1EAEE03E5;IF::Extract { -> F}
//## Uses: <unnamed>%4AF330BB0011;UnmatchedAuthorizationAudit { -> F}
//## Uses: <unnamed>%4B0593AD02DC;IF::Trace { -> F}
//## Uses: <unnamed>%4B0593D101D3;ems::Case { -> F}
//## Uses: <unnamed>%4B05A0D90050;reusable::Transaction { -> F}
//## Uses: <unnamed>%4B05A0F202D0;timer::Clock { -> F}

class DllExport UnmatchedAuthorization : public Problem  //## Inherits: <unnamed>%4ACE18D6005B
{
  //## begin UnmatchedAuthorization%4ACDFCF600F2.initialDeclarations preserve=yes
  //## end UnmatchedAuthorization%4ACDFCF600F2.initialDeclarations

  public:
    //## Constructors (generated)
      UnmatchedAuthorization();

    //## Destructor (generated)
      virtual ~UnmatchedAuthorization();


    //## Other Operations (specified)
      //## Operation: ageOffOldRecords%4ACE40130308
      void ageOffOldRecords ();

      //## Operation: instance%4ACE1C8802E4
      static UnmatchedAuthorization* instance ();

      //## Operation: repair%4ACE18F200B8
      virtual Problem::State repair (EvidenceSegment& hEvidenceSegment);

    // Additional Public Declarations
      //## begin UnmatchedAuthorization%4ACDFCF600F2.public preserve=yes
      //## end UnmatchedAuthorization%4ACDFCF600F2.public

  protected:
    // Additional Protected Declarations
      //## begin UnmatchedAuthorization%4ACDFCF600F2.protected preserve=yes
      //## end UnmatchedAuthorization%4ACDFCF600F2.protected

  private:
    // Additional Private Declarations
      //## begin UnmatchedAuthorization%4ACDFCF600F2.private preserve=yes
      //## end UnmatchedAuthorization%4ACDFCF600F2.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%4ACE1C1F0161
      //## begin UnmatchedAuthorization::Instance%4ACE1C1F0161.attr preserve=no  private: static UnmatchedAuthorization* {V} 0
      static UnmatchedAuthorization* m_pInstance;
      //## end UnmatchedAuthorization::Instance%4ACE1C1F0161.attr

    // Additional Implementation Declarations
      //## begin UnmatchedAuthorization%4ACDFCF600F2.implementation preserve=yes
      //## end UnmatchedAuthorization%4ACDFCF600F2.implementation

};

//## begin UnmatchedAuthorization%4ACDFCF600F2.postscript preserve=yes
//## end UnmatchedAuthorization%4ACDFCF600F2.postscript

//## begin module%4ACDFD2C02A8.epilog preserve=yes
//## end module%4ACDFD2C02A8.epilog


#endif
