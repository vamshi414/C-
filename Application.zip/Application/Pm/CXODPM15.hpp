//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4D74F57901C8.cm preserve=no
//	$Date:   Mar 10 2011 16:23:16  $ $Author:   D93482  $
//	$Revision:   1.0  $
//## end module%4D74F57901C8.cm

//## begin module%4D74F57901C8.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4D74F57901C8.cp

//## Module: CXOSPM15%4D74F57901C8; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM15.hpp

#ifndef CXOSPM15_h
#define CXOSPM15_h 1

//## begin module%4D74F57901C8.additionalIncludes preserve=no
//## end module%4D74F57901C8.additionalIncludes

//## begin module%4D74F57901C8.includes preserve=yes
//## end module%4D74F57901C8.includes

#ifndef CXOSPM03_h
#include "CXODPM03.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
class EvidenceSegment;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%4D74F57901C8.declarations preserve=no
//## end module%4D74F57901C8.declarations

//## begin module%4D74F57901C8.additionalDeclarations preserve=yes
//## end module%4D74F57901C8.additionalDeclarations


//## begin ProblemActionCodeTranslation%4D74F4550028.preface preserve=yes
//## end ProblemActionCodeTranslation%4D74F4550028.preface

//## Class: ProblemActionCodeTranslation%4D74F4550028
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4D74F4E3000E;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%4D74F4E60137;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4D74F4E900DA;configuration::EvidenceSegment { -> F}
//## Uses: <unnamed>%4D74F4EB0270;reusable::Query { -> F}
//## Uses: <unnamed>%4D74F4EE0290;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4D74F4F301B5;reusable::Statement { -> F}
//## Uses: <unnamed>%4D74F4F70119;reusable::Table { -> F}
//## Uses: <unnamed>%4D7547D2019E;IF::Extract { -> F}

class DllExport ProblemActionCodeTranslation : public Problem  //## Inherits: <unnamed>%4D74F4550086
{
  //## begin ProblemActionCodeTranslation%4D74F4550028.initialDeclarations preserve=yes
  //## end ProblemActionCodeTranslation%4D74F4550028.initialDeclarations

  public:
    //## Constructors (generated)
      ProblemActionCodeTranslation();

    //## Destructor (generated)
      virtual ~ProblemActionCodeTranslation();


    //## Other Operations (specified)
      //## Operation: instance%4D74F4550077
      static ProblemActionCodeTranslation* instance ();

      //## Operation: repair%4D74F4550078
      Problem::State repair (configuration::EvidenceSegment& hEvidenceSegment);

    // Additional Public Declarations
      //## begin ProblemActionCodeTranslation%4D74F4550028.public preserve=yes
      //## end ProblemActionCodeTranslation%4D74F4550028.public

  protected:
    // Additional Protected Declarations
      //## begin ProblemActionCodeTranslation%4D74F4550028.protected preserve=yes
      //## end ProblemActionCodeTranslation%4D74F4550028.protected

  private:
    // Additional Private Declarations
      //## begin ProblemActionCodeTranslation%4D74F4550028.private preserve=yes
      //## end ProblemActionCodeTranslation%4D74F4550028.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%4D74F4550076
      //## begin ProblemActionCodeTranslation::Instance%4D74F4550076.attr preserve=no  private: static ProblemActionCodeTranslation* {V} 0
      static ProblemActionCodeTranslation* m_pInstance;
      //## end ProblemActionCodeTranslation::Instance%4D74F4550076.attr

    // Additional Implementation Declarations
      //## begin ProblemActionCodeTranslation%4D74F4550028.implementation preserve=yes
      //## end ProblemActionCodeTranslation%4D74F4550028.implementation

};

//## begin ProblemActionCodeTranslation%4D74F4550028.postscript preserve=yes
//## end ProblemActionCodeTranslation%4D74F4550028.postscript

//## begin module%4D74F57901C8.epilog preserve=yes
//## end module%4D74F57901C8.epilog


#endif
