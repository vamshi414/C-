//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%396DCD6102C3.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%396DCD6102C3.cm

//## begin module%396DCD6102C3.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%396DCD6102C3.cp

//## Module: CXOSPM06%396DCD6102C3; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM06.cpp

//## begin module%396DCD6102C3.additionalIncludes preserve=no
//## end module%396DCD6102C3.additionalIncludes

//## begin module%396DCD6102C3.includes preserve=yes
// $Date:   Feb 02 2009 07:10:44  $ $Author:   D02405  $ $Revision:   1.14  $
#include "CXODIF16.hpp"
//## end module%396DCD6102C3.includes

#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSPM06_h
#include "CXODPM06.hpp"
#endif


//## begin module%396DCD6102C3.declarations preserve=no
//## end module%396DCD6102C3.declarations

//## begin module%396DCD6102C3.additionalDeclarations preserve=yes
//## end module%396DCD6102C3.additionalDeclarations


// Class ProblemReimbursementFlag 

//## begin ProblemReimbursementFlag::Instance%3EBFBD250261.attr preserve=no  private: static ProblemReimbursementFlag* {V} 0
ProblemReimbursementFlag* ProblemReimbursementFlag::m_pInstance = 0;
//## end ProblemReimbursementFlag::Instance%3EBFBD250261.attr

ProblemReimbursementFlag::ProblemReimbursementFlag()
  //## begin ProblemReimbursementFlag::ProblemReimbursementFlag%396DCFBA0372_const.hasinit preserve=no
  //## end ProblemReimbursementFlag::ProblemReimbursementFlag%396DCFBA0372_const.hasinit
  //## begin ProblemReimbursementFlag::ProblemReimbursementFlag%396DCFBA0372_const.initialization preserve=yes
  //## end ProblemReimbursementFlag::ProblemReimbursementFlag%396DCFBA0372_const.initialization
{
  //## begin ProblemReimbursementFlag::ProblemReimbursementFlag%396DCFBA0372_const.body preserve=yes
   memcpy(m_sID,"PM06",4);
   m_strUseCase = "## AM12 REIMBURSEMENT FLAG";
  //## end ProblemReimbursementFlag::ProblemReimbursementFlag%396DCFBA0372_const.body
}


ProblemReimbursementFlag::~ProblemReimbursementFlag()
{
  //## begin ProblemReimbursementFlag::~ProblemReimbursementFlag%396DCFBA0372_dest.body preserve=yes
  //## end ProblemReimbursementFlag::~ProblemReimbursementFlag%396DCFBA0372_dest.body
}



//## Other Operations (implementation)
ProblemReimbursementFlag* ProblemReimbursementFlag::instance ()
{
  //## begin ProblemReimbursementFlag::instance%3EBFBD580242.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ProblemReimbursementFlag();
   return m_pInstance;
  //## end ProblemReimbursementFlag::instance%3EBFBD580242.body
}

Problem::State ProblemReimbursementFlag::repair (configuration::EvidenceSegment& hEvidenceSegment)
{
  //## begin ProblemReimbursementFlag::repair%396DD967011B.body preserve=yes
   // AM12: SW_Repairs_Reimbursement_Flag
   string strTranslatedValue;
   string strSourceValue(hEvidenceSegment.getSOURCE_VALUE());
   size_t iPos = strSourceValue.find(',');
   strSourceValue.erase(iPos);
   if (ConfigurationRepository::instance()->translate(hEvidenceSegment.getSUSPECT_TABLE().c_str(),strSourceValue,strTranslatedValue,"","",0) == false)
      return PTM_NOT_FIXED;
   if (strTranslatedValue == "Y")
   {
      strTranslatedValue = hEvidenceSegment.getSOURCE_VALUE().substr(iPos + 1,1);
      Table hTable;
      if (hEvidenceSegment.getPROBLEM_TABLE() == "FIN_LOCATOR")
         hTable.setName("FIN_L" + m_strTSTAMP_TRANS.substr(0,6));
      else
      {
         string strTable("FIN_RECORD");
#ifdef MVS
         string strValue;
         Extract::instance()->getSpec("MODEL",strValue);
         if (strValue == "OPEN")
#endif
            strTable.append(m_strTSTAMP_TRANS.data(),6);
         hTable.setName(strTable);
      }
      hTable.set(hEvidenceSegment.getPROBLEM_COLUMN().c_str(),strTranslatedValue);
      hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
      hTable.set("UNIQUENESS_KEY",(int) m_iUNIQUENESS_KEY,true);
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      bool bReturn = pUpdateStatement->execute(hTable);
      if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
         return PTM_NOT_FOUND;
      if (!bReturn)
         return PTM_SQL_ERROR;
   }
   return PTM_FIXED;
  //## end ProblemReimbursementFlag::repair%396DD967011B.body
}

// Additional Declarations
  //## begin ProblemReimbursementFlag%396DCFBA0372.declarations preserve=yes
  //## end ProblemReimbursementFlag%396DCFBA0372.declarations

//## begin module%396DCD6102C3.epilog preserve=yes
//## end module%396DCD6102C3.epilog
