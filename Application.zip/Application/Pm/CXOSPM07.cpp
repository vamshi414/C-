//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%396DCD66014E.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%396DCD66014E.cm

//## begin module%396DCD66014E.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%396DCD66014E.cp

//## Module: CXOSPM07%396DCD66014E; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM07.cpp

//## begin module%396DCD66014E.additionalIncludes preserve=no
//## end module%396DCD66014E.additionalIncludes

//## begin module%396DCD66014E.includes preserve=yes
// $Date:   Feb 02 2009 07:10:44  $ $Author:   D02405  $ $Revision:   1.13  $
#include "CXODIF16.hpp"
//## end module%396DCD66014E.includes

#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSPM07_h
#include "CXODPM07.hpp"
#endif


//## begin module%396DCD66014E.declarations preserve=no
//## end module%396DCD66014E.declarations

//## begin module%396DCD66014E.additionalDeclarations preserve=yes
//## end module%396DCD66014E.additionalDeclarations


// Class ProblemActionCode 

//## begin ProblemActionCode::Instance%3EBFBDCE0196.attr preserve=no  private: static ProblemActionCode* {V} 0
ProblemActionCode* ProblemActionCode::m_pInstance = 0;
//## end ProblemActionCode::Instance%3EBFBDCE0196.attr

ProblemActionCode::ProblemActionCode()
  //## begin ProblemActionCode::ProblemActionCode%396DCFBC000D_const.hasinit preserve=no
  //## end ProblemActionCode::ProblemActionCode%396DCFBC000D_const.hasinit
  //## begin ProblemActionCode::ProblemActionCode%396DCFBC000D_const.initialization preserve=yes
  //## end ProblemActionCode::ProblemActionCode%396DCFBC000D_const.initialization
{
  //## begin ProblemActionCode::ProblemActionCode%396DCFBC000D_const.body preserve=yes
   memcpy(m_sID,"PM07",4);
   m_strUseCase = "## AM13 ACTION CODE";
  //## end ProblemActionCode::ProblemActionCode%396DCFBC000D_const.body
}


ProblemActionCode::~ProblemActionCode()
{
  //## begin ProblemActionCode::~ProblemActionCode%396DCFBC000D_dest.body preserve=yes
  //## end ProblemActionCode::~ProblemActionCode%396DCFBC000D_dest.body
}



//## Other Operations (implementation)
ProblemActionCode* ProblemActionCode::instance ()
{
  //## begin ProblemActionCode::instance%3EBFBDE4037A.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ProblemActionCode();
   return m_pInstance;
  //## end ProblemActionCode::instance%3EBFBDE4037A.body
}

Problem::State ProblemActionCode::repair (configuration::EvidenceSegment& hEvidenceSegment)
{
  //## begin ProblemActionCode::repair%396DD96C02F8.body preserve=yes
   // AM13: SW_Repairs_Action_Code
   string strTranslatedValue;
   if (ConfigurationRepository::instance()->translate(hEvidenceSegment.getSUSPECT_TABLE().c_str(),
      hEvidenceSegment.getSOURCE_VALUE(),strTranslatedValue,"","",0) == false)
   {
      string strTemp(hEvidenceSegment.getSOURCE_VALUE());
      strTemp.replace(7,3,"   ",3);
      if (ConfigurationRepository::instance()->translate(hEvidenceSegment.getSUSPECT_TABLE().c_str(),
         strTemp,strTranslatedValue,"","",0) == false)
         return PTM_NOT_FIXED;
   }
   string strTable("FIN_RECORD");
#ifdef MVS
   string strValue;
   Extract::instance()->getSpec("MODEL",strValue);
   if (strValue == "OPEN")
#endif
      strTable.append(m_strTSTAMP_TRANS.data(),6);
   Table hTable(strTable.c_str());
   hTable.set("ACCT_TYPES_ISS",strTranslatedValue.substr(2,4));
   hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int)m_iUNIQUENESS_KEY,true);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   bool bReturn = pUpdateStatement->execute(hTable);
   if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      return PTM_NOT_FOUND;
   if (!bReturn)
      return PTM_SQL_ERROR;
   hTable.reset();
   hTable.setName("FIN_L" + m_strTSTAMP_TRANS.substr(0,6));
   hTable.set("ACT_CODE","000");
   strTranslatedValue.replace(2,4,"0000",4);
   hTable.set("TRAN_TYPE_ID",strTranslatedValue);
   hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int)m_iUNIQUENESS_KEY,true);
   if (pUpdateStatement->execute(hTable))
      return PTM_FIXED;
   return PTM_SQL_ERROR;
  //## end ProblemActionCode::repair%396DD96C02F8.body
}

// Additional Declarations
  //## begin ProblemActionCode%396DCFBC000D.declarations preserve=yes
  //## end ProblemActionCode%396DCFBC000D.declarations

//## begin module%396DCD66014E.epilog preserve=yes
//## end module%396DCD66014E.epilog
