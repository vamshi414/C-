//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4C7FE6EE0302.cm preserve=no
//	$Date:   Sep 17 2010 12:38:10  $ $Author:   E1024360  $
//	$Revision:   1.2  $
//## end module%4C7FE6EE0302.cm

//## begin module%4C7FE6EE0302.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4C7FE6EE0302.cp

//## Module: CXOSPM13%4C7FE6EE0302; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM13.cpp

//## begin module%4C7FE6EE0302.additionalIncludes preserve=no
//## end module%4C7FE6EE0302.additionalIncludes

//## begin module%4C7FE6EE0302.includes preserve=yes
//## end module%4C7FE6EE0302.includes

#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSPM02_h
#include "CXODPM02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif
#ifndef CXOSPM03_h
#include "CXODPM03.hpp"
#endif
#ifndef CXOSPM13_h
#include "CXODPM13.hpp"
#endif


//## begin module%4C7FE6EE0302.declarations preserve=no
//## end module%4C7FE6EE0302.declarations

//## begin module%4C7FE6EE0302.additionalDeclarations preserve=yes
//## end module%4C7FE6EE0302.additionalDeclarations


// Class AuthorizationMediator 

//## begin AuthorizationMediator::Instance%4C87F82E003E.attr preserve=no  private: static AuthorizationMediator* {V} 0
AuthorizationMediator* AuthorizationMediator::m_pInstance = 0;
//## end AuthorizationMediator::Instance%4C87F82E003E.attr

AuthorizationMediator::AuthorizationMediator()
  //## begin AuthorizationMediator::AuthorizationMediator%4C7FE69F00A1_const.hasinit preserve=no
      : m_iTimerValue(1800)
  //## end AuthorizationMediator::AuthorizationMediator%4C7FE69F00A1_const.hasinit
  //## begin AuthorizationMediator::AuthorizationMediator%4C7FE69F00A1_const.initialization preserve=yes
  //## end AuthorizationMediator::AuthorizationMediator%4C7FE69F00A1_const.initialization
{
  //## begin AuthorizationMediator::AuthorizationMediator%4C7FE69F00A1_const.body preserve=yes
   memcpy(m_sID,"PM13",4);
   if ((m_iTimerValue = Extract::instance()->getTimer("DISPUTE")) == -1)
      m_iTimerValue = 1800;
   m_hTimer.set(m_iTimerValue);   
   m_hTimer.attach(this);
  //## end AuthorizationMediator::AuthorizationMediator%4C7FE69F00A1_const.body
}


AuthorizationMediator::~AuthorizationMediator()
{
  //## begin AuthorizationMediator::~AuthorizationMediator%4C7FE69F00A1_dest.body preserve=yes
   m_hTimer.cancel();
   m_pInstance = 0; 
  //## end AuthorizationMediator::~AuthorizationMediator%4C7FE69F00A1_dest.body
}



//## Other Operations (implementation)
AuthorizationMediator* AuthorizationMediator::instance ()
{
  //## begin AuthorizationMediator::instance%4C87F86800E2.body preserve=yes
   if (m_pInstance == 0)
      m_pInstance = new AuthorizationMediator();
   return m_pInstance;
  //## end AuthorizationMediator::instance%4C87F86800E2.body
}

void AuthorizationMediator::retrieve ()
{
  //## begin AuthorizationMediator::retrieve%4C7FEA0301AA.body preserve=yes
   UseCase hUseCase("ADMIN","## AM05 FETCH AUTHORIZATIONS");
   {
      m_hProblems.erase(m_hProblems.begin(),m_hProblems.end());
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      Query hQuery; 
      hQuery.attach(this);
      m_hProblem.bind(hQuery);
      hQuery.setBasicPredicate("PROBLEM_TRAN","REASON_CODE","IN","('9','09')");
      hQuery.setOrderByClause("PROBLEM_TRAN.TSTAMP_TRANS ASC");
      if (!pSelectStatement->execute(hQuery))
         UseCase::setSuccess(false);
   }   
   Database::instance()->commit();
   
   for (int i = 0;i < m_hProblems.size();i++)
      ProblemSolver::instance()->repair(m_hProblems[i]);
      
   m_hTimer.set(m_iTimerValue);
  //## end AuthorizationMediator::retrieve%4C7FEA0301AA.body
}

void AuthorizationMediator::update (Subject* pSubject)
{
  //## begin AuthorizationMediator::update%4C7FEA14012D.body preserve=yes
   if (pSubject == &m_hTimer)
      retrieve();
   else
   {
      m_hProblems.push_back(m_hProblem);
      UseCase::addItem();
     }
  //## end AuthorizationMediator::update%4C7FEA14012D.body
}

// Additional Declarations
  //## begin AuthorizationMediator%4C7FE69F00A1.declarations preserve=yes
  //## end AuthorizationMediator%4C7FE69F00A1.declarations

//## begin module%4C7FE6EE0302.epilog preserve=yes
//## end module%4C7FE6EE0302.epilog
