//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%396DCD580324.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%396DCD580324.cm

//## begin module%396DCD580324.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%396DCD580324.cp

//## Module: CXOSPM04%396DCD580324; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM04.cpp

//## begin module%396DCD580324.additionalIncludes preserve=no
//## end module%396DCD580324.additionalIncludes

//## begin module%396DCD580324.includes preserve=yes
// $Date:   Feb 02 2009 07:10:44  $ $Author:   D02405  $ $Revision:   1.14  $
#include "CXODIF16.hpp"
//## end module%396DCD580324.includes

#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSPM04_h
#include "CXODPM04.hpp"
#endif


//## begin module%396DCD580324.declarations preserve=no
//## end module%396DCD580324.declarations

//## begin module%396DCD580324.additionalDeclarations preserve=yes
//## end module%396DCD580324.additionalDeclarations


// Class ProblemTranslation 

//## begin ProblemTranslation::Instance%3EBFBB8D002E.attr preserve=no  private: static ProblemTranslation* {V} 0
ProblemTranslation* ProblemTranslation::m_pInstance = 0;
//## end ProblemTranslation::Instance%3EBFBB8D002E.attr

ProblemTranslation::ProblemTranslation()
  //## begin ProblemTranslation::ProblemTranslation%396DCFB301D7_const.hasinit preserve=no
  //## end ProblemTranslation::ProblemTranslation%396DCFB301D7_const.hasinit
  //## begin ProblemTranslation::ProblemTranslation%396DCFB301D7_const.initialization preserve=yes
  //## end ProblemTranslation::ProblemTranslation%396DCFB301D7_const.initialization
{
  //## begin ProblemTranslation::ProblemTranslation%396DCFB301D7_const.body preserve=yes
   memcpy(m_sID,"PM04",4);
   m_strUseCase = "## AM10 TRANSLATION";
  //## end ProblemTranslation::ProblemTranslation%396DCFB301D7_const.body
}


ProblemTranslation::~ProblemTranslation()
{
  //## begin ProblemTranslation::~ProblemTranslation%396DCFB301D7_dest.body preserve=yes
  //## end ProblemTranslation::~ProblemTranslation%396DCFB301D7_dest.body
}



//## Other Operations (implementation)
ProblemTranslation* ProblemTranslation::instance ()
{
  //## begin ProblemTranslation::instance%3EBFBBA603B9.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ProblemTranslation();
   return m_pInstance;
  //## end ProblemTranslation::instance%3EBFBBA603B9.body
}

Problem::State ProblemTranslation::repair (configuration::EvidenceSegment& hEvidenceSegment)
{
  //## begin ProblemTranslation::repair%396DD93900BA.body preserve=yes
   // AM10: SW_Repairs_Translation        
   string strTranslatedValue;
   if (ConfigurationRepository::instance()->translate(hEvidenceSegment.getSUSPECT_TABLE().c_str(),
      hEvidenceSegment.getSOURCE_VALUE(), strTranslatedValue, "", "", 0) == false)
      return PTM_NOT_FIXED;
   if (hEvidenceSegment.getPROBLEM_TABLE().length() > 0)
   {
      Table hTable;
      string strTemp(hEvidenceSegment.getPROBLEM_TABLE());
      size_t n = strTemp.find("OCATOR");
      if (n != string::npos)
         strTemp.replace(n,6,m_strTSTAMP_TRANS.data(),6);
#ifdef MVS
      string strValue;
      Extract::instance()->getSpec("MODEL",strValue);
      if (strValue == "OPEN")
#endif
         if (strTemp == "FIN_RECORD")
            strTemp.append(m_strTSTAMP_TRANS.data(),6);
      hTable.setName(strTemp);
      hTable.set(hEvidenceSegment.getPROBLEM_COLUMN().c_str(),strTranslatedValue);
      hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
      hTable.set("UNIQUENESS_KEY",(int) m_iUNIQUENESS_KEY,true);
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      bool bReturn = pUpdateStatement->execute(hTable);
      if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
         return PTM_NOT_FOUND;
      if (!bReturn)
         return PTM_SQL_ERROR;
   }
   return PTM_FIXED;
  //## end ProblemTranslation::repair%396DD93900BA.body
}

// Additional Declarations
  //## begin ProblemTranslation%396DCFB301D7.declarations preserve=yes
  //## end ProblemTranslation%396DCFB301D7.declarations

//## begin module%396DCD580324.epilog preserve=yes
//## end module%396DCD580324.epilog
