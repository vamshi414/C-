//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%396DCD6801AB.cm preserve=no
//	$Date:   Mar 25 2021 05:03:56  $ $Author:   e3019097  $
//	$Revision:   1.18.1.2  $
//## end module%396DCD6801AB.cm

//## begin module%396DCD6801AB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%396DCD6801AB.cp

//## Module: CXOSPM08%396DCD6801AB; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Application\Pm\CXOSPM08.cpp

//## begin module%396DCD6801AB.additionalIncludes preserve=no
//## end module%396DCD6801AB.additionalIncludes

//## begin module%396DCD6801AB.includes preserve=yes
#include "CXODIF16.hpp"
//## end module%396DCD6801AB.includes

#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSPM08_h
#include "CXODPM08.hpp"
#endif


//## begin module%396DCD6801AB.declarations preserve=no
//## end module%396DCD6801AB.declarations

//## begin module%396DCD6801AB.additionalDeclarations preserve=yes
//## end module%396DCD6801AB.additionalDeclarations


// Class ProblemAcquirerChain 

//## begin ProblemAcquirerChain::Instance%3EBFBE52029F.attr preserve=no  private: static ProblemAcquirerChain* {V} 0
ProblemAcquirerChain* ProblemAcquirerChain::m_pInstance = 0;
//## end ProblemAcquirerChain::Instance%3EBFBE52029F.attr

ProblemAcquirerChain::ProblemAcquirerChain()
  //## begin ProblemAcquirerChain::ProblemAcquirerChain%396DCFBD0131_const.hasinit preserve=no
  //## end ProblemAcquirerChain::ProblemAcquirerChain%396DCFBD0131_const.hasinit
  //## begin ProblemAcquirerChain::ProblemAcquirerChain%396DCFBD0131_const.initialization preserve=yes
  //## end ProblemAcquirerChain::ProblemAcquirerChain%396DCFBD0131_const.initialization
{
  //## begin ProblemAcquirerChain::ProblemAcquirerChain%396DCFBD0131_const.body preserve=yes
   memcpy(m_sID,"PM08",4);
   m_strUseCase = "## AM14 ACQUIRER CHAIN";
  //## end ProblemAcquirerChain::ProblemAcquirerChain%396DCFBD0131_const.body
}


ProblemAcquirerChain::~ProblemAcquirerChain()
{
  //## begin ProblemAcquirerChain::~ProblemAcquirerChain%396DCFBD0131_dest.body preserve=yes
  //## end ProblemAcquirerChain::~ProblemAcquirerChain%396DCFBD0131_dest.body
}



//## Other Operations (implementation)
void ProblemAcquirerChain::fixPseudoDevice (EvidenceSegment& hEvidenceSegment)
{
  //## begin ProblemAcquirerChain::fixPseudoDevice%45DB63980282.body preserve=yes
   string strINST_ID_ACQ;
   {
      Query hQuery;
      string strFIN_LOCATOR("FIN_L");
      strFIN_LOCATOR.append(m_strTSTAMP_TRANS.data(),6);
      hQuery.bind(strFIN_LOCATOR.c_str(),"INST_ID_ACQ",Column::STRING,&strINST_ID_ACQ);
      hQuery.setBasicPredicate(strFIN_LOCATOR.c_str(),"TSTAMP_TRANS","=",m_strTSTAMP_TRANS.c_str());
      hQuery.setBasicPredicate(strFIN_LOCATOR.c_str(),"UNIQUENESS_KEY","=",m_iUNIQUENESS_KEY);
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (pSelectStatement->execute(hQuery) == false
         || pSelectStatement->getRows() == 0)
         return;
   }
   string strDEVICE_ID;
   if (ConfigurationRepository::instance()->translate("~DEVICE",strINST_ID_ACQ,strDEVICE_ID,"","",-1,false))
      hEvidenceSegment.setSOURCE_VALUE(strDEVICE_ID);
  //## end ProblemAcquirerChain::fixPseudoDevice%45DB63980282.body
}

Problem::State ProblemAcquirerChain::fixReverseChaining (EvidenceSegment& hEvidenceSegment)
{
  //## begin ProblemAcquirerChain::fixReverseChaining%52AA104D012A.body preserve=yes
   string strINST_ID_RECON_ACQ = hEvidenceSegment.getSOURCE_VALUE();
   string strINST_ID_ACQ = hEvidenceSegment.getSOURCE_VALUE();
   string strNET_TERM_ID;
   if (ConfigurationRepository::instance()->translate("DEVICERevAll",strINST_ID_ACQ,strNET_TERM_ID,"","",0) == false)
      return PTM_NOT_FIXED;
   Table hTable(string("FIN_L" + m_strTSTAMP_TRANS.substr(0,6)).c_str());
   hTable.set("NET_TERM_ID",strNET_TERM_ID);
   hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int) m_iUNIQUENESS_KEY,true);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   bool bReturn = pUpdateStatement->execute(hTable);
   if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      return PTM_NOT_FOUND;
   if (!bReturn)
      return PTM_SQL_ERROR;
   return PTM_FIXED;
  //## end ProblemAcquirerChain::fixReverseChaining%52AA104D012A.body
}

Problem::State ProblemAcquirerChain::fixXNet (EvidenceSegment& hEvidenceSegment)
{
  //## begin ProblemAcquirerChain::fixXNet%52F11BAE032A.body preserve=yes
   string strINST_ID_ACQ;
   if (ConfigurationRepository::instance()->translate("X_NET_INST_ID",hEvidenceSegment.getSOURCE_VALUE(),strINST_ID_ACQ,"","",0) == false)
      return PTM_NOT_FIXED;
   string strNET_TERM_ID;
   Table hTable(string("FIN_L" + m_strTSTAMP_TRANS.substr(0,6)).c_str());
   hTable.set("INST_ID_RECON_ACQ",strINST_ID_ACQ);
   hTable.set("INST_ID_RECN_ACQ_B",strINST_ID_ACQ);
   if (hEvidenceSegment.getPROBLEM_COLUMN() != "NET_INST_ID_CODE")
      if (ConfigurationRepository::instance()->translate("DEVICERevAll",strINST_ID_ACQ,strNET_TERM_ID,"FIN_LOCATOR","DEVICE_ID"))
         hTable.set("NET_TERM_ID",strNET_TERM_ID);
   string strPROC_ID_ACQ_B;
   if (ConfigurationRepository::instance()->translate("INSTITUTION",strINST_ID_ACQ,strPROC_ID_ACQ_B,"FIN_LOCATOR","PROC_ID_ACQ_B",0) == false)
      ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   else
   {
      hTable.set("PROC_ID_ACQ_B",strPROC_ID_ACQ_B);
      string strPROC_GRP_ID_ACQ_B;
      if (ConfigurationRepository::instance()->translate("PROCESSOR",strPROC_ID_ACQ_B,strPROC_GRP_ID_ACQ_B,"FIN_LOCATOR","PROC_GRP_ID_ACQ_B",0))
         hTable.set("PROC_GRP_ID_ACQ_B",strPROC_GRP_ID_ACQ_B);
   }

   hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int) m_iUNIQUENESS_KEY,true);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   bool bReturn = pUpdateStatement->execute(hTable);
   if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      return PTM_NOT_FOUND;
   if (!bReturn)
      return PTM_SQL_ERROR;
   return PTM_FIXED;
  //## end ProblemAcquirerChain::fixXNet%52F11BAE032A.body
}

bool ProblemAcquirerChain::getMinimumDevice (EvidenceSegment& hEvidenceSegment)
{
  //## begin ProblemAcquirerChain::getMinimumDevice%5784F182035F.body preserve=yes
   auto_ptr<SelectStatement>pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   string strRPT_LVL_ID_B;
   Query hQuery;
   string strFIN_LOCATOR("FIN_L");
   strFIN_LOCATOR.append(m_strTSTAMP_TRANS.data(),6);
   hQuery.bind(strFIN_LOCATOR.c_str(),"RPT_LVL_ID_B",Column::STRING,&strRPT_LVL_ID_B);
   hQuery.setBasicPredicate(strFIN_LOCATOR.c_str(),"TSTAMP_TRANS","=",m_strTSTAMP_TRANS.c_str());
   hQuery.setBasicPredicate(strFIN_LOCATOR.c_str(),"UNIQUENESS_KEY","=",m_iUNIQUENESS_KEY);
   if (pSelectStatement->execute(hQuery) == false
      || pSelectStatement->getRows() == 0)
      return false;
   string strNET_TERM_ID;
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   hQuery.reset();
   hQuery.setQualifier("QUALIFY","DEVICE");
   hQuery.bind("DEVICE","DEVICE_ID",Column::STRING,&strNET_TERM_ID,0,"MIN");
   hQuery.setBasicPredicate("DEVICE","RPT_LVL_ID","=",strRPT_LVL_ID_B.c_str());
   hQuery.setBasicPredicate("DEVICE","CUST_ID","=",strCUST_ID.c_str());
   if (pSelectStatement->execute(hQuery)
      && strNET_TERM_ID.empty() == false)
   {
      hEvidenceSegment.setSOURCE_VALUE(strNET_TERM_ID);
      return true;
   }
   return false;
  //## end ProblemAcquirerChain::getMinimumDevice%5784F182035F.body
}

ProblemAcquirerChain* ProblemAcquirerChain::instance ()
{
  //## begin ProblemAcquirerChain::instance%3EBFBE680290.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ProblemAcquirerChain();
   return m_pInstance;
  //## end ProblemAcquirerChain::instance%3EBFBE680290.body
}

Problem::State ProblemAcquirerChain::repair (EvidenceSegment& hEvidenceSegment)
{
  //## begin ProblemAcquirerChain::repair%396DD97103D2.body preserve=yes
   if (hEvidenceSegment.getSUSPECT_TABLE() == "DEVICERevAll")
      return fixReverseChaining(hEvidenceSegment);
   if (hEvidenceSegment.getSUSPECT_TABLE() == "X_NET_INST_ID")
      return fixXNet(hEvidenceSegment);
   Table hTable(string("FIN_L" + m_strTSTAMP_TRANS.substr(0,6)).c_str());
   if (hEvidenceSegment.getSUSPECT_TABLE() == "DEVICE"
      && hEvidenceSegment.getPROBLEM_TABLE() == "FIN_LOCATOR"
      && hEvidenceSegment.getPROBLEM_COLUMN() == "INST_ID_RECN_ACQ_B")
   {
      if (Extract::instance()->getCustomCode() == "MPS"
         && hEvidenceSegment.getSOURCE_VALUE() == " ")
      {
         if (!getMinimumDevice(hEvidenceSegment))
            return PTM_NOT_FIXED;
         hTable.set("NET_TERM_ID",hEvidenceSegment.getSOURCE_VALUE());
      }
      else
      if (Extract::instance()->getCustomCode() != "BBL")
         fixPseudoDevice(hEvidenceSegment);
   }
   string strSOURCE_VALUE(hEvidenceSegment.getSOURCE_VALUE());
   string strINST_ID_RECON_ACQ;
   string strINST_ID_ACQ;
   string strINST_ID_RECN_ACQ_B;
   if (hEvidenceSegment.getSUSPECT_TABLE() == "DEVICE"
      && strSOURCE_VALUE.length() > 19)
   {
      strINST_ID_RECON_ACQ = hEvidenceSegment.getSOURCE_VALUE().substr(8,11);
      strINST_ID_ACQ = hEvidenceSegment.getSOURCE_VALUE().substr(19);
      strSOURCE_VALUE.erase(8);
      ConfigurationRepository::instance()->mapItem("X_INST_ID_RECON",strINST_ID_RECON_ACQ,strINST_ID_ACQ,"A",strINST_ID_RECN_ACQ_B);
   }
   string strSecond;
   string strPROC_ID_ACQ_B;
   string strPROC_GRP_ID_ACQ_B;
   string strNET_TERM_ID;
   if (hEvidenceSegment.getSUSPECT_TABLE() == "DEVICE"
      && strSOURCE_VALUE == "MACQTERM")
   {
      string strDeviceID;
      Extract::instance()->getSpec("MACQTERM",strDeviceID);
      if (strDeviceID.length() > 0)
      {
         strSOURCE_VALUE = strDeviceID;
         hTable.set("NET_TERM_ID",strDeviceID);
      }
   }
   if (hEvidenceSegment.getSUSPECT_TABLE() == "DEVICE"
      && hEvidenceSegment.getPROBLEM_COLUMN() == "BBL")
   {
      if (ConfigurationRepository::instance()->translate(hEvidenceSegment.getSUSPECT_TABLE().c_str(),strSOURCE_VALUE,strSecond,"","",0))
         return PTM_FIXED;
      else
         return PTM_NOT_FIXED;
   }
   if (ConfigurationRepository::instance()->translate(hEvidenceSegment.getSUSPECT_TABLE().c_str(),strSOURCE_VALUE,strSecond,"","",0) == false)
   {
      if (Extract::instance()->getCustomCode() == "COLES"
         && hEvidenceSegment.getPROBLEM_COLUMN() == "COLES"
         && hEvidenceSegment.getSOURCE_VALUE().length() > 8
         && getDeviceDetails(hEvidenceSegment, strNET_TERM_ID, strSecond))
            hTable.set("NET_TERM_ID", strNET_TERM_ID);
      else
         return PTM_NOT_FIXED;
   }

   if (hEvidenceSegment.getSUSPECT_TABLE() == "DEVICE")
   {
      if (strSecond.length() > 11)
      {
         hTable.set("RPT_LVL_ID_B",strSecond.substr(11));
         strSecond.erase(11);
      }
      if (!strINST_ID_RECN_ACQ_B.empty())
         strSecond = strINST_ID_RECN_ACQ_B;
      hTable.set("INST_ID_RECN_ACQ_B",strSecond);
      if (ConfigurationRepository::instance()->translate("INSTITUTION",strSecond,strPROC_ID_ACQ_B,"","",0) == false)
         return PTM_NOT_FIXED;
      hTable.set("PROC_ID_ACQ_B",strPROC_ID_ACQ_B);
      if (ConfigurationRepository::instance()->translate("PROCESSOR", strPROC_ID_ACQ_B,strPROC_GRP_ID_ACQ_B,"","",0) == false)
         return PTM_NOT_FIXED;
      hTable.set("PROC_GRP_ID_ACQ_B",strPROC_GRP_ID_ACQ_B);
      if (Extract::instance()->getCustomCode() == "COLES")
      {
         hTable.set("INST_ID_RECON_ACQ", strSecond);
         hTable.set("PROC_ID_ACQ", strPROC_ID_ACQ_B);
      }
   }
   else
   if (hEvidenceSegment.getSUSPECT_TABLE() == "INSTITUTION")
   {
      hTable.set("PROC_ID_ACQ_B",strSecond);
      if (ConfigurationRepository::instance()->translate("PROCESSOR", strSecond,strPROC_GRP_ID_ACQ_B,"","",0) == false)
         return PTM_NOT_FIXED;
      hTable.set("PROC_GRP_ID_ACQ_B",strPROC_GRP_ID_ACQ_B);
   }
   else
   if (hEvidenceSegment.getSUSPECT_TABLE() == "PROCESSOR")
      hTable.set("PROC_GRP_ID_ACQ_B",strSecond);
   else
      return PTM_NOT_FIXED;
   hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int) m_iUNIQUENESS_KEY,true);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   bool bReturn = pUpdateStatement->execute(hTable);
   if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      return PTM_NOT_FOUND;
   if (!bReturn)
      return PTM_SQL_ERROR;
   if (Extract::instance()->getCustomCode() == "COLES" 
      && hEvidenceSegment.getPROBLEM_COLUMN() == "COLES"
      && (!m_strFEE_BILL_INST_ID.empty() || !strNET_TERM_ID.empty()))
   {
      Table hTable1(string("FIN_COLES" + m_strTSTAMP_TRANS.substr(0, 6)).c_str());
      if(!m_strFEE_BILL_INST_ID.empty())
         hTable1.set("STORENR", m_strFEE_BILL_INST_ID);
      if (!strNET_TERM_ID.empty())
         hTable1.set("EXT_TERM_ID", strNET_TERM_ID);
      hTable1.set("TSTAMP_TRANS", m_strTSTAMP_TRANS, false, true);
      hTable1.set("UNIQUENESS_KEY", (int)m_iUNIQUENESS_KEY, true);
      bReturn = pUpdateStatement->execute(hTable1);
      if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
         return PTM_NOT_FOUND;
      if (!bReturn)
         return PTM_SQL_ERROR;
   }
   return PTM_FIXED;
  //## end ProblemAcquirerChain::repair%396DD97103D2.body
}

// Additional Declarations
  //## begin ProblemAcquirerChain%396DCFBD0131.declarations preserve=yes
bool ProblemAcquirerChain::getDeviceDetails(EvidenceSegment& hEvidenceSegment, string& strNET_TERM_ID, string& strSecond)
{
   bool b = false;
   string strRPT_LVL_ID;
   string strSTORENR = hEvidenceSegment.getSOURCE_VALUE().substr(0, 8);
   string strINST_ID_RECON_ACQ = hEvidenceSegment.getSOURCE_VALUE().substr(8, 11);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery;
   hQuery.reset();
   hQuery.setQualifier("QUALIFY", "DEVICE");
   hQuery.setQualifier("QUALIFY", "REPORTING_LVL");
   hQuery.join("DEVICE", "INNER", "REPORTING_LVL", "RPT_LVL_ID");
   hQuery.join("DEVICE", "INNER", "REPORTING_LVL", "RPT_LVL_STAT");
   hQuery.join("DEVICE", "INNER", "REPORTING_LVL", "CUST_ID");
   hQuery.join("DEVICE", "INNER", "REPORTING_LVL", "CUST_STAT");
   hQuery.bind("DEVICE", "DEVICE_ID", Column::STRING, &strNET_TERM_ID);
   hQuery.bind("DEVICE", "RPT_LVL_ID", Column::STRING, &strRPT_LVL_ID);
   hQuery.setBasicPredicate("REPORTING_LVL", "CC_STATE", "=", "A");
   hQuery.setBasicPredicate("DEVICE", "CC_STATE", "=", "A");
   if (strSTORENR.c_str()[0] != ' ')
      hQuery.setBasicPredicate("REPORTING_LVL", "FEE_BILL_INST_ID", "=", strSTORENR.c_str());
   else
   {
      hQuery.setQualifier("QUALIFY", "INSTITUTION");
      hQuery.join("DEVICE", "INNER", "INSTITUTION", "INST_ID");
      hQuery.join("DEVICE", "INNER", "INSTITUTION", "INST_STAT");
      hQuery.join("DEVICE", "INNER", "INSTITUTION", "CUST_ID");
      hQuery.join("DEVICE", "INNER", "INSTITUTION", "CUST_STAT");
      hQuery.join("REPORTING_LVL", "INNER", "INSTITUTION", "FEE_BILL_INST_ID");
      hQuery.bind("REPORTING_LVL", "FEE_BILL_INST_ID", Column::STRING, &m_strFEE_BILL_INST_ID);
      hQuery.setBasicPredicate("INSTITUTION", "CC_STATE", "=", "A");
      hQuery.setBasicPredicate("INSTITUTION", "FEE_BILL_INST_ID", "<>", " ");
   }
   hQuery.setBasicPredicate("DEVICE", "INST_ID", "=", strINST_ID_RECON_ACQ.c_str());
   if (pSelectStatement->execute(hQuery) && pSelectStatement->getRows() == 1)
   {
      strSecond = strINST_ID_RECON_ACQ;
      strSecond.resize(11, ' ');
      strSecond += strRPT_LVL_ID;
      b = true;
   }
   return b;
}
  //## end ProblemAcquirerChain%396DCFBD0131.declarations

//## begin module%396DCD6801AB.epilog preserve=yes
//## end module%396DCD6801AB.epilog
