//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%393139700030.cm preserve=no
//	$Date:   Mar 14 2013 12:17:46  $ $Author:   lc25127  $
//	$Revision:   1.30  $
//## end module%393139700030.cm

//## begin module%393139700030.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%393139700030.cp

//## Module: CXOPPM00%393139700030; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOPPM00.cpp

//## begin module%393139700030.additionalIncludes preserve=no
//## end module%393139700030.additionalIncludes

//## begin module%393139700030.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),ENVAR('TASK=PM'))
#endif
#include "CXODRU24.hpp"
//## end module%393139700030.includes

#ifndef CXOSPM01_h
#include "CXODPM01.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSPM11_h
#include "CXODPM11.hpp"
#endif
#ifndef CXOSPM12_h
#include "CXODPM12.hpp"
#endif
#ifndef CXOSEX01_h
#include "CXODEX01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSPM13_h
#include "CXODPM13.hpp"
#endif
#ifndef CXOSPM17_h
#include "CXODPM17.hpp"
#endif
#ifndef CXOSTM13_h
#include "CXODTM13.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOPPM00_h
#include "CXODPM00.hpp"
#endif


//## begin module%393139700030.declarations preserve=no
//## end module%393139700030.declarations

//## begin module%393139700030.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new ProblemTransactionManager();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%393139700030.additionalDeclarations


// Class ProblemTransactionManager

ProblemTransactionManager::ProblemTransactionManager()
  //## begin ProblemTransactionManager::ProblemTransactionManager%3918124303B9_const.hasinit preserve=no
  //## end ProblemTransactionManager::ProblemTransactionManager%3918124303B9_const.hasinit
  //## begin ProblemTransactionManager::ProblemTransactionManager%3918124303B9_const.initialization preserve=yes
  //## end ProblemTransactionManager::ProblemTransactionManager%3918124303B9_const.initialization
{
  //## begin ProblemTransactionManager::ProblemTransactionManager%3918124303B9_const.body preserve=yes
   memcpy(m_sID,"PM00",4);
  //## end ProblemTransactionManager::ProblemTransactionManager%3918124303B9_const.body
}


ProblemTransactionManager::~ProblemTransactionManager()
{
  //## begin ProblemTransactionManager::~ProblemTransactionManager%3918124303B9_dest.body preserve=yes
   delete ProblemMediator::instance();
   delete AuthorizationMediator::instance();
   delete ConfigurationRepository::instance();
  //## end ProblemTransactionManager::~ProblemTransactionManager%3918124303B9_dest.body
}



//## Other Operations (implementation)
int ProblemTransactionManager::initialize ()
{
  //## begin ProblemTransactionManager::initialize%3918127A0259.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("ADMIN","## AM01 STARTS PTM");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->attach(this);
   Database::instance()->connect();
   ProblemMediator::instance();
   AuthorizationMediator::instance();
   ConfigurationRepository::instance();
   MidnightAlarm::instance()->attach(this);
   HourAlarm::instance()->attach(this);
   string strCustomer;
   Extract::instance()->getSpec("CUSTOMER",strCustomer);
   Transaction::instance()->setCustomer(strCustomer);
   Case::instance();
   EMSRulesEngine::instance();   
   return 0;
  //## end ProblemTransactionManager::initialize%3918127A0259.body
}

int ProblemTransactionManager::onReset (IF::Message& hMessage)
{
  //## begin ProblemTransactionManager::onReset%391812A70358.body preserve=yes
   UseCase hUseCase("ADMIN","## AM04 RESET PTM");
   ConfigurationRepository::instance()->reset();
   ConfigurationRepository::instance()->setEvidence(false);
   onResume(hMessage);
   return 0;
  //## end ProblemTransactionManager::onReset%391812A70358.body
}

int ProblemTransactionManager::onResume (IF::Message& hMessage)
{
  //## begin ProblemTransactionManager::onResume%393141C202F0.body preserve=yes
   setQueueWaitOption(ProblemMediator::instance()->retrieve());
   if (m_hProblemSummary.isEmpty()
      && m_hProblemSummary.retrieve())
   {
      Console::display("ST148");
      m_hProblemSummary.email();
   }
   Database::instance()->commit();
   return 0;
  //## end ProblemTransactionManager::onResume%393141C202F0.body
}

void ProblemTransactionManager::update (Subject* pSubject)
{
  //## begin ProblemTransactionManager::update%391812AA0349.body preserve=yes
   if (pSubject == Database::instance())
   {
      if (Database::instance()->state() == Database::CONNECTED)
         Application::setQueueWaitOption(false);
      return;
   }
   else
   if (pSubject == MidnightAlarm::instance())
   {
      onReset(*(Message::instance(Message::INBOUND)));
      if (UnmatchedAuthorizationAudit::instance()->writeAudit()== 0)
      {
         UnmatchedAuthorization::instance()->ageOffOldRecords();
         Database::instance()->commit();
      }
      else
         Database::instance()->rollback();
      m_hProblemSummary.clear();
   }
   else
   if (pSubject == HourAlarm::instance())
   {
      ProblemSummary hProblemSummary;
      if (hProblemSummary.retrieve()
         && m_hProblemSummary != hProblemSummary)
      {
         Console::display("ST148");
         hProblemSummary.email();
         m_hProblemSummary = hProblemSummary;
      }
      Database::instance()->commit();
   }
   Application::update(pSubject);
  //## end ProblemTransactionManager::update%391812AA0349.body
}

// Additional Declarations
  //## begin ProblemTransactionManager%3918124303B9.declarations preserve=yes
  //## end ProblemTransactionManager%3918124303B9.declarations

//## begin module%393139700030.epilog preserve=yes
//## end module%393139700030.epilog
