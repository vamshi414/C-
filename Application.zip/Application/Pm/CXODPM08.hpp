//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%396DCD6A010E.cm preserve=no
//	$Date:   Jan 12 2021 01:15:32  $ $Author:   e3015517  $
//	$Revision:   1.11  $
//## end module%396DCD6A010E.cm

//## begin module%396DCD6A010E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%396DCD6A010E.cp

//## Module: CXOSPM08%396DCD6A010E; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Application\Pm\CXODPM08.hpp

#ifndef CXOSPM08_h
#define CXOSPM08_h 1

//## begin module%396DCD6A010E.additionalIncludes preserve=no
//## end module%396DCD6A010E.additionalIncludes

//## begin module%396DCD6A010E.includes preserve=yes
// $Date:   Jan 12 2021 01:15:32  $ $Author:   e3015517  $ $Revision:   1.11  $
//## end module%396DCD6A010E.includes

#ifndef CXOSPM03_h
#include "CXODPM03.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
class EvidenceSegment;
} // namespace configuration

namespace reusable {
class Table;
class Statement;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%396DCD6A010E.declarations preserve=no
//## end module%396DCD6A010E.declarations

//## begin module%396DCD6A010E.additionalDeclarations preserve=yes
//## end module%396DCD6A010E.additionalDeclarations


//## begin ProblemAcquirerChain%396DCFBD0131.preface preserve=yes
//## end ProblemAcquirerChain%396DCFBD0131.preface

//## Class: ProblemAcquirerChain%396DCFBD0131
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%396DD57A0148;reusable::Statement { -> F}
//## Uses: <unnamed>%396DD57C01AF;reusable::Query { -> F}
//## Uses: <unnamed>%396DD57E0234;configuration::EvidenceSegment { -> F}
//## Uses: <unnamed>%396DD58001BE;reusable::Table { -> F}
//## Uses: <unnamed>%396DD58C0067;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%396DD59601C0;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%396DF3490104;database::DatabaseFactory { -> F}

class ProblemAcquirerChain : public Problem  //## Inherits: <unnamed>%396DD599026F
{
  //## begin ProblemAcquirerChain%396DCFBD0131.initialDeclarations preserve=yes
  //## end ProblemAcquirerChain%396DCFBD0131.initialDeclarations

  public:
    //## Constructors (generated)
      ProblemAcquirerChain();

    //## Destructor (generated)
      virtual ~ProblemAcquirerChain();


    //## Other Operations (specified)
      //## Operation: fixReverseChaining%52AA104D012A
      Problem::State fixReverseChaining (EvidenceSegment& hEvidenceSegment);

      //## Operation: fixXNet%52F11BAE032A
      Problem::State fixXNet (EvidenceSegment& hEvidenceSegment);

      //## Operation: instance%3EBFBE680290
      static ProblemAcquirerChain* instance ();

      //## Operation: repair%396DD97103D2
      Problem::State repair (EvidenceSegment& hEvidenceSegment);

    // Additional Public Declarations
      //## begin ProblemAcquirerChain%396DCFBD0131.public preserve=yes
      //## end ProblemAcquirerChain%396DCFBD0131.public

  protected:
    // Additional Protected Declarations
      //## begin ProblemAcquirerChain%396DCFBD0131.protected preserve=yes
      //## end ProblemAcquirerChain%396DCFBD0131.protected

  private:

    //## Other Operations (specified)
      //## Operation: fixPseudoDevice%45DB63980282
      void fixPseudoDevice (EvidenceSegment& hEvidenceSegment);

      //## Operation: getMinimumDevice%5784F182035F
      bool getMinimumDevice (EvidenceSegment& hEvidenceSegment);

    // Additional Private Declarations
      //## begin ProblemAcquirerChain%396DCFBD0131.private preserve=yes
      bool getDeviceDetails(EvidenceSegment& hEvidenceSegment, string& strNET_TERM_ID, string& strSecond);
      //## end ProblemAcquirerChain%396DCFBD0131.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3EBFBE52029F
      //## begin ProblemAcquirerChain::Instance%3EBFBE52029F.attr preserve=no  private: static ProblemAcquirerChain* {V} 0
      static ProblemAcquirerChain* m_pInstance;
      //## end ProblemAcquirerChain::Instance%3EBFBE52029F.attr

    // Additional Implementation Declarations
      //## begin ProblemAcquirerChain%396DCFBD0131.implementation preserve=yes
      string m_strFEE_BILL_INST_ID;
      //## end ProblemAcquirerChain%396DCFBD0131.implementation

};

//## begin ProblemAcquirerChain%396DCFBD0131.postscript preserve=yes
//## end ProblemAcquirerChain%396DCFBD0131.postscript

//## begin module%396DCD6A010E.epilog preserve=yes
//## end module%396DCD6A010E.epilog


#endif
