//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4E034A390056.cm preserve=no
//	$Date:   Sep 19 2011 04:56:44  $ $Author:   D02684  $
//	$Revision:   1.0  $
//## end module%4E034A390056.cm

//## begin module%4E034A390056.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4E034A390056.cp

//## Module: CXOSPM16%4E034A390056; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM16.hpp

#ifndef CXOSPM16_h
#define CXOSPM16_h 1

//## begin module%4E034A390056.additionalIncludes preserve=no
//## end module%4E034A390056.additionalIncludes

//## begin module%4E034A390056.includes preserve=yes
//## end module%4E034A390056.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%4E034A390056.declarations preserve=no
//## end module%4E034A390056.declarations

//## begin module%4E034A390056.additionalDeclarations preserve=yes
//## end module%4E034A390056.additionalDeclarations


//## begin ProblemSummarySegment%4E0344D701FD.preface preserve=yes
//## end ProblemSummarySegment%4E0344D701FD.preface

//## Class: ProblemSummarySegment%4E0344D701FD
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4E034DB202A2;reusable::Query { -> F}
//## Uses: <unnamed>%4E049A210336;configuration::ConfigurationRepository { -> F}

class DllExport ProblemSummarySegment : public segment::Segment  //## Inherits: <unnamed>%4E04A5D803CC
{
  //## begin ProblemSummarySegment%4E0344D701FD.initialDeclarations preserve=yes
  //## end ProblemSummarySegment%4E0344D701FD.initialDeclarations

  public:
    //## Constructors (generated)
      ProblemSummarySegment();

      ProblemSummarySegment(const ProblemSummarySegment &right);

    //## Destructor (generated)
      virtual ~ProblemSummarySegment();

    //## Assignment Operation (generated)
      ProblemSummarySegment & operator=(const ProblemSummarySegment &right);

    //## Equality Operations (generated)
      bool operator==(const ProblemSummarySegment &right) const;

      bool operator!=(const ProblemSummarySegment &right) const;


    //## Other Operations (specified)
      //## Operation: bind%4E034D340368
      virtual void bind (reusable::Query& hQuery);

      //## Operation: copyValues%4E044B3B0192
      virtual void copyValues (const ProblemSummarySegment& right);

      //## Operation: fields%4E04A8C302E8
      virtual struct  Fields* fields () const;

      //## Operation: setDescription%4E049AB20251
      virtual void setDescription ();

      //## Operation: setFields%4E04ABBE0038
      virtual void setFields ();

    // Additional Public Declarations
      //## begin ProblemSummarySegment%4E0344D701FD.public preserve=yes
      //## end ProblemSummarySegment%4E0344D701FD.public

  protected:
    // Additional Protected Declarations
      //## begin ProblemSummarySegment%4E0344D701FD.protected preserve=yes
      //## end ProblemSummarySegment%4E0344D701FD.protected

  private:
    // Additional Private Declarations
      //## begin ProblemSummarySegment%4E0344D701FD.private preserve=yes
      //## end ProblemSummarySegment%4E0344D701FD.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Count%4E034C9401FD
      //## begin ProblemSummarySegment::Count%4E034C9401FD.attr preserve=no  private: int {U} 0
      int m_iCount;
      //## end ProblemSummarySegment::Count%4E034C9401FD.attr

      //## Attribute: CRClientBook%4E0499740212
      //## begin ProblemSummarySegment::CRClientBook%4E0499740212.attr preserve=no  public: string {U} 
      string m_strCRClientBook;
      //## end ProblemSummarySegment::CRClientBook%4E0499740212.attr

      //## Attribute: Null%4E03527C0262
      //## begin ProblemSummarySegment::Null%4E03527C0262.attr preserve=no  private: short {U} 0
      short m_iNull;
      //## end ProblemSummarySegment::Null%4E03527C0262.attr

      //## Attribute: REASON_CODE%4E03451603DB
      //## begin ProblemSummarySegment::REASON_CODE%4E03451603DB.attr preserve=no  public: string {U} 
      string m_strREASON_CODE;
      //## end ProblemSummarySegment::REASON_CODE%4E03451603DB.attr

      //## Attribute: ReasonDescription%4E04995F012F
      //## begin ProblemSummarySegment::ReasonDescription%4E04995F012F.attr preserve=no  public: string {U} 
      string m_strReasonDescription;
      //## end ProblemSummarySegment::ReasonDescription%4E04995F012F.attr

      //## Attribute: SOURCE_VALUE%4E034C810162
      //## begin ProblemSummarySegment::SOURCE_VALUE%4E034C810162.attr preserve=no  public: string {U} 
      string m_strSOURCE_VALUE;
      //## end ProblemSummarySegment::SOURCE_VALUE%4E034C810162.attr

      //## Attribute: SUSPECT_TABLE%4E034C6B027D
      //## begin ProblemSummarySegment::SUSPECT_TABLE%4E034C6B027D.attr preserve=no  public: string {U} 
      string m_strSUSPECT_TABLE;
      //## end ProblemSummarySegment::SUSPECT_TABLE%4E034C6B027D.attr

    // Additional Implementation Declarations
      //## begin ProblemSummarySegment%4E0344D701FD.implementation preserve=yes
      //## end ProblemSummarySegment%4E0344D701FD.implementation

};

//## begin ProblemSummarySegment%4E0344D701FD.postscript preserve=yes
//## end ProblemSummarySegment%4E0344D701FD.postscript

//## begin module%4E034A390056.epilog preserve=yes
//## end module%4E034A390056.epilog


#endif
