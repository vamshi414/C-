//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4C7FE74F0043.cm preserve=no
//	$Date:   Sep 14 2010 15:26:50  $ $Author:   E1024360  $
//	$Revision:   1.1  $
//## end module%4C7FE74F0043.cm

//## begin module%4C7FE74F0043.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4C7FE74F0043.cp

//## Module: CXOSPM14%4C7FE74F0043; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM14.hpp

#ifndef CXOSPM14_h
#define CXOSPM14_h 1

//## begin module%4C7FE74F0043.additionalIncludes preserve=no
//## end module%4C7FE74F0043.additionalIncludes

//## begin module%4C7FE74F0043.includes preserve=yes
//## end module%4C7FE74F0043.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;

} // namespace reusable

//## begin module%4C7FE74F0043.declarations preserve=no
//## end module%4C7FE74F0043.declarations

//## begin module%4C7FE74F0043.additionalDeclarations preserve=yes
//## end module%4C7FE74F0043.additionalDeclarations


//## begin Issue%4C7FE6AB03DD.preface preserve=yes
//## end Issue%4C7FE6AB03DD.preface

//## Class: Issue%4C7FE6AB03DD
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4C8120BC01F2;reusable::Query { -> F}

class DllExport Issue : public reusable::Object  //## Inherits: <unnamed>%4C81126500D6
{
  //## begin Issue%4C7FE6AB03DD.initialDeclarations preserve=yes
  //## end Issue%4C7FE6AB03DD.initialDeclarations

  public:
    //## Constructors (generated)
      Issue();

      Issue(const Issue &right);

    //## Destructor (generated)
      virtual ~Issue();

    //## Assignment Operation (generated)
      Issue & operator=(const Issue &right);


    //## Other Operations (specified)
      //## Operation: bind%4C81207300D9
      void bind (reusable::Query& hQuery);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: PROBLEM_COLUMN%4C811F500158
      const string& getPROBLEM_COLUMN () const
      {
        //## begin Issue::getPROBLEM_COLUMN%4C811F500158.get preserve=no
        return m_strPROBLEM_COLUMN;
        //## end Issue::getPROBLEM_COLUMN%4C811F500158.get
      }

      void setPROBLEM_COLUMN (const string& value)
      {
        //## begin Issue::setPROBLEM_COLUMN%4C811F500158.set preserve=no
        m_strPROBLEM_COLUMN = value;
        //## end Issue::setPROBLEM_COLUMN%4C811F500158.set
      }


      //## Attribute: PROBLEM_TABLE%4C811F5B03A9
      const string& getPROBLEM_TABLE () const
      {
        //## begin Issue::getPROBLEM_TABLE%4C811F5B03A9.get preserve=no
        return m_strPROBLEM_TABLE;
        //## end Issue::getPROBLEM_TABLE%4C811F5B03A9.get
      }

      void setPROBLEM_TABLE (const string& value)
      {
        //## begin Issue::setPROBLEM_TABLE%4C811F5B03A9.set preserve=no
        m_strPROBLEM_TABLE = value;
        //## end Issue::setPROBLEM_TABLE%4C811F5B03A9.set
      }


      //## Attribute: REASON_CODE%4C811EE900EB
      const string& getREASON_CODE () const
      {
        //## begin Issue::getREASON_CODE%4C811EE900EB.get preserve=no
        return m_strREASON_CODE;
        //## end Issue::getREASON_CODE%4C811EE900EB.get
      }

      void setREASON_CODE (const string& value)
      {
        //## begin Issue::setREASON_CODE%4C811EE900EB.set preserve=no
        m_strREASON_CODE = value;
        //## end Issue::setREASON_CODE%4C811EE900EB.set
      }


      //## Attribute: SOURCE_VALUE%4C811F440281
      const string& getSOURCE_VALUE () const
      {
        //## begin Issue::getSOURCE_VALUE%4C811F440281.get preserve=no
        return m_strSOURCE_VALUE;
        //## end Issue::getSOURCE_VALUE%4C811F440281.get
      }

      void setSOURCE_VALUE (const string& value)
      {
        //## begin Issue::setSOURCE_VALUE%4C811F440281.set preserve=no
        m_strSOURCE_VALUE = value;
        //## end Issue::setSOURCE_VALUE%4C811F440281.set
      }


      //## Attribute: SUSPECT_TABLE%4C811F3B007D
      const string& getSUSPECT_TABLE () const
      {
        //## begin Issue::getSUSPECT_TABLE%4C811F3B007D.get preserve=no
        return m_strSUSPECT_TABLE;
        //## end Issue::getSUSPECT_TABLE%4C811F3B007D.get
      }

      void setSUSPECT_TABLE (const string& value)
      {
        //## begin Issue::setSUSPECT_TABLE%4C811F3B007D.set preserve=no
        m_strSUSPECT_TABLE = value;
        //## end Issue::setSUSPECT_TABLE%4C811F3B007D.set
      }


      //## Attribute: TSTAMP_TRANS%4C811F6A0158
      const string& getTSTAMP_TRANS () const
      {
        //## begin Issue::getTSTAMP_TRANS%4C811F6A0158.get preserve=no
        return m_strTSTAMP_TRANS;
        //## end Issue::getTSTAMP_TRANS%4C811F6A0158.get
      }

      void setTSTAMP_TRANS (const string& value)
      {
        //## begin Issue::setTSTAMP_TRANS%4C811F6A0158.set preserve=no
        m_strTSTAMP_TRANS = value;
        //## end Issue::setTSTAMP_TRANS%4C811F6A0158.set
      }


    // Additional Public Declarations
      //## begin Issue%4C7FE6AB03DD.public preserve=yes
      //## end Issue%4C7FE6AB03DD.public

  protected:
    // Additional Protected Declarations
      //## begin Issue%4C7FE6AB03DD.protected preserve=yes
      //## end Issue%4C7FE6AB03DD.protected

  private:
    // Additional Private Declarations
      //## begin Issue%4C7FE6AB03DD.private preserve=yes
      //## end Issue%4C7FE6AB03DD.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin Issue::PROBLEM_COLUMN%4C811F500158.attr preserve=no  public: string {U} 
      string m_strPROBLEM_COLUMN;
      //## end Issue::PROBLEM_COLUMN%4C811F500158.attr

      //## begin Issue::PROBLEM_TABLE%4C811F5B03A9.attr preserve=no  public: string {U} 
      string m_strPROBLEM_TABLE;
      //## end Issue::PROBLEM_TABLE%4C811F5B03A9.attr

      //## begin Issue::REASON_CODE%4C811EE900EB.attr preserve=no  public: string {U} 
      string m_strREASON_CODE;
      //## end Issue::REASON_CODE%4C811EE900EB.attr

      //## begin Issue::SOURCE_VALUE%4C811F440281.attr preserve=no  public: string {U} 
      string m_strSOURCE_VALUE;
      //## end Issue::SOURCE_VALUE%4C811F440281.attr

      //## begin Issue::SUSPECT_TABLE%4C811F3B007D.attr preserve=no  public: string {U} 
      string m_strSUSPECT_TABLE;
      //## end Issue::SUSPECT_TABLE%4C811F3B007D.attr

      //## begin Issue::TSTAMP_TRANS%4C811F6A0158.attr preserve=no  public: string {U} 
      string m_strTSTAMP_TRANS;
      //## end Issue::TSTAMP_TRANS%4C811F6A0158.attr

    // Additional Implementation Declarations
      //## begin Issue%4C7FE6AB03DD.implementation preserve=yes
      //## end Issue%4C7FE6AB03DD.implementation

};

//## begin Issue%4C7FE6AB03DD.postscript preserve=yes
//## end Issue%4C7FE6AB03DD.postscript

//## begin module%4C7FE74F0043.epilog preserve=yes
//## end module%4C7FE74F0043.epilog


#endif
