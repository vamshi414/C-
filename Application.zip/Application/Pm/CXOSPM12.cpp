//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4ACE53A000C2.cm preserve=no
//	$Date:   May 20 2020 17:53:16  $ $Author:   e1009510  $
//	$Revision:   1.2  $
//## end module%4ACE53A000C2.cm

//## begin module%4ACE53A000C2.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4ACE53A000C2.cp

//## Module: CXOSPM12%4ACE53A000C2; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM12.cpp

//## begin module%4ACE53A000C2.additionalIncludes preserve=no
//## end module%4ACE53A000C2.additionalIncludes

//## begin module%4ACE53A000C2.includes preserve=yes
//## end module%4ACE53A000C2.includes

#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSBS24_h
#include "CXODBS24.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU07_h
#include "CXODRU07.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSBC20_h
#include "CXODBC20.hpp"
#endif
#ifndef CXOSPM12_h
#include "CXODPM12.hpp"
#endif


//## begin module%4ACE53A000C2.declarations preserve=no
//## end module%4ACE53A000C2.declarations

//## begin module%4ACE53A000C2.additionalDeclarations preserve=yes
//## end module%4ACE53A000C2.additionalDeclarations


// Class UnmatchedAuthorizationAudit 

//## begin UnmatchedAuthorizationAudit::Instance%4ACF812000B1.attr preserve=no  private: static UnmatchedAuthorizationAudit* {U} 0
UnmatchedAuthorizationAudit* UnmatchedAuthorizationAudit::m_pInstance = 0;
//## end UnmatchedAuthorizationAudit::Instance%4ACF812000B1.attr

UnmatchedAuthorizationAudit::UnmatchedAuthorizationAudit()
  //## begin UnmatchedAuthorizationAudit::UnmatchedAuthorizationAudit%4ACE5351022A_const.hasinit preserve=no
      : m_pAudit(0)
  //## end UnmatchedAuthorizationAudit::UnmatchedAuthorizationAudit%4ACE5351022A_const.hasinit
  //## begin UnmatchedAuthorizationAudit::UnmatchedAuthorizationAudit%4ACE5351022A_const.initialization preserve=yes
  //## end UnmatchedAuthorizationAudit::UnmatchedAuthorizationAudit%4ACE5351022A_const.initialization
{
  //## begin UnmatchedAuthorizationAudit::UnmatchedAuthorizationAudit%4ACE5351022A_const.body preserve=yes
   memcpy(m_sID,"PM12",4);
  //## end UnmatchedAuthorizationAudit::UnmatchedAuthorizationAudit%4ACE5351022A_const.body
}


UnmatchedAuthorizationAudit::~UnmatchedAuthorizationAudit()
{
  //## begin UnmatchedAuthorizationAudit::~UnmatchedAuthorizationAudit%4ACE5351022A_dest.body preserve=yes
   delete m_pAudit;
   delete m_pInstance; 
   m_pInstance = 0; 
  //## end UnmatchedAuthorizationAudit::~UnmatchedAuthorizationAudit%4ACE5351022A_dest.body
}



//## Other Operations (implementation)
void UnmatchedAuthorizationAudit::add (char cReportType, const string& strIMPORT_KEY, int iREJECT_CODE)
{
  //## begin UnmatchedAuthorizationAudit::add%4ACF575A0220.body preserve=yes
   writeHeader(Date::today().asString("%Y%m%d"));
   //The import key being sent in is the TSTAMP_TRANS and the UNIQUENESS_KEY of the auth transaction.
   //What we need to include in the audit report is the matching criteria so that the user knows how to search for the transaction.
   //transaction is being sent in
   
   string strTSTAMP_TRANS;
   strTSTAMP_TRANS.assign(strIMPORT_KEY.c_str(),16);
   char szTemp[9]; 
   memcpy(szTemp,strIMPORT_KEY.c_str()+16,8);
   szTemp[8]='\0';
   int iUNIQUENESS_KEY = atoi(szTemp);
   
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery;
   m_strSOURCE_VALUE.erase();
   hQuery.bind("PROBLEM_TRAN","SOURCE_VALUE",Column::STRING, &m_strSOURCE_VALUE);
   hQuery.setBasicPredicate("PROBLEM_TRAN","TSTAMP_TRANS","=",strTSTAMP_TRANS.c_str());
   hQuery.setBasicPredicate("PROBLEM_TRAN","UNIQUENESS_KEY","=",iUNIQUENESS_KEY);
   pSelectStatement->execute(hQuery);
   ImportReportAuditSegment::instance()->setIMPORT_KEY(m_strSOURCE_VALUE);
   
   char szErrorNum[5];
   snprintf(szErrorNum,sizeof(szErrorNum),"%04d",iREJECT_CODE + 2000);
   string strTemp;
   ConfigurationRepository::instance()->translate("ERROR_MSG",szErrorNum,strTemp," "," ",0,false);
   ImportReportAuditSegment::instance()->setREJECT_CODES(strTemp);
   
   if (m_pAudit != 0)
      m_pAudit->report(cReportType);
  //## end UnmatchedAuthorizationAudit::add%4ACF575A0220.body
}

UnmatchedAuthorizationAudit* UnmatchedAuthorizationAudit::instance ()
{
  //## begin UnmatchedAuthorizationAudit::instance%4ACF814401F9.body preserve=yes
   if (m_pInstance == 0)
      m_pInstance = new UnmatchedAuthorizationAudit();
      
   return m_pInstance;
  //## end UnmatchedAuthorizationAudit::instance%4ACF814401F9.body
}

int UnmatchedAuthorizationAudit::writeAudit ()
{
  //## begin UnmatchedAuthorizationAudit::writeAudit%4ACE54310247.body preserve=yes
   if (m_pAudit != 0)
   {
      delete m_pAudit;
      m_pAudit = 0;
   }
   //get all the disputed authorizations that are still in the PROBLEM_TRAN table  
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery;
   hQuery.attach(this);
   m_strSOURCE_VALUE.erase();
   hQuery.bind("PROBLEM_TRAN","SOURCE_VALUE",Column::STRING,&m_strSOURCE_VALUE);
   hQuery.setBasicPredicate("PROBLEM_TRAN","REASON_CODE","=","8");
   if (!pSelectStatement->execute(hQuery))
      return 1;
   if (m_pAudit != 0)   
      m_pAudit->complete();
   return 0;
  //## end UnmatchedAuthorizationAudit::writeAudit%4ACE54310247.body
}

void UnmatchedAuthorizationAudit::writeHeader (const string& strDate)
{
  //## begin UnmatchedAuthorizationAudit::writeHeader%4ACF58E70302.body preserve=yes
   if (m_pAudit != 0)
   {
      delete m_pAudit;
      m_pAudit = 0;
   }
   
   m_pAudit = new Audit("PMDAUT","CU",Customer::instance()->getCUST_ID(),strDate,"235959");
   const char* pszAudit[] =
   {
      "HAutomatic Case Creation for Disputed Authorizations",
      "HDate:,~A.DATE_RECON.",
      "H",
      "HStatus,Transaction Information,Reason",
      "CCase Creation Failed,~A.IMPORT_KEY.,~A.REJECT_CODES.",
      "PPending Disputed Authorizations,~A.IMPORT_KEY.,~A.REJECT_CODES.",
      0
   };
   m_pAudit->add('A',ImportReportAuditSegment::instance());
   ImportReportAuditSegment::instance()->setDATE_RECON(strDate);
   m_pAudit->setTemplate(&pszAudit[0]);
   if (m_pAudit->empty())
      if (!m_pAudit->report('H'))
      {
         Database::instance()->rollback();
         delete m_pAudit; 
         m_pAudit = 0;
      }
  //## end UnmatchedAuthorizationAudit::writeHeader%4ACF58E70302.body
}

void UnmatchedAuthorizationAudit::update (Subject* pSubject)
{
  //## begin UnmatchedAuthorizationAudit::update%4ACF57370099.body preserve=yes
   if (m_pAudit == 0)
      writeHeader(MidnightAlarm::instance()->getYesterday());
   ImportReportAuditSegment::instance()->setIMPORT_KEY(m_strSOURCE_VALUE);
   m_pAudit->report('P');
  //## end UnmatchedAuthorizationAudit::update%4ACF57370099.body
}

// Additional Declarations
  //## begin UnmatchedAuthorizationAudit%4ACE5351022A.declarations preserve=yes
  //## end UnmatchedAuthorizationAudit%4ACE5351022A.declarations

//## begin module%4ACE53A000C2.epilog preserve=yes
//## end module%4ACE53A000C2.epilog
