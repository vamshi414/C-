//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3931426B014F.cm preserve=no
//## end module%3931426B014F.cm

//## begin module%3931426B014F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3931426B014F.cp

//## Module: CXOSPM01%3931426B014F; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Pm\CXOSPM01.cpp

//## begin module%3931426B014F.additionalIncludes preserve=no
//## end module%3931426B014F.additionalIncludes

//## begin module%3931426B014F.includes preserve=yes
//## end module%3931426B014F.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSPM02_h
#include "CXODPM02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSPM14_h
#include "CXODPM14.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSPM03_h
#include "CXODPM03.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif
#ifndef CXOSPM01_h
#include "CXODPM01.hpp"
#endif


//## begin module%3931426B014F.declarations preserve=no
//## end module%3931426B014F.declarations

//## begin module%3931426B014F.additionalDeclarations preserve=yes
//## end module%3931426B014F.additionalDeclarations


// Class ProblemMediator 

//## begin ProblemMediator::Instance%393143840094.attr preserve=no  private: static ProblemMediator* {V} 0
ProblemMediator* ProblemMediator::m_pInstance = 0;
//## end ProblemMediator::Instance%393143840094.attr

ProblemMediator::ProblemMediator()
  //## begin ProblemMediator::ProblemMediator%393140A00267_const.hasinit preserve=no
      : m_iTimerValue(3600)
  //## end ProblemMediator::ProblemMediator%393140A00267_const.hasinit
  //## begin ProblemMediator::ProblemMediator%393140A00267_const.initialization preserve=yes
  //## end ProblemMediator::ProblemMediator%393140A00267_const.initialization
{
  //## begin ProblemMediator::ProblemMediator%393140A00267_const.body preserve=yes
   memcpy(m_sID,"PM01",4);
   m_hTimer.set(m_iTimerValue);
   m_hTimer.attach(this);
  //## end ProblemMediator::ProblemMediator%393140A00267_const.body
}


ProblemMediator::~ProblemMediator()
{
  //## begin ProblemMediator::~ProblemMediator%393140A00267_dest.body preserve=yes
   m_hTimer.cancel();
   m_pInstance = 0;
  //## end ProblemMediator::~ProblemMediator%393140A00267_dest.body
}



//## Other Operations (implementation)
ProblemMediator* ProblemMediator::instance ()
{
  //## begin ProblemMediator::instance%3931439D0267.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ProblemMediator();
   return m_pInstance;
  //## end ProblemMediator::instance%3931439D0267.body
}

bool ProblemMediator::retrieve ()
{
  //## begin ProblemMediator::retrieve%3936855103E1.body preserve=yes
   // retrieve unique issues from the database
   if (m_hIssues.size() == 0)
   {
      UseCase hUseCase("ADMIN","## AM02 FETCH ISSUES");
      //retrieve all the distinct kinds of problems (except those related to Disputed Authorizations)
      Query hQuery(1);
      hQuery.attach(this);
      m_hIssue.bind(hQuery);
      hQuery.setBasicPredicate("PROBLEM_TRAN","REASON_CODE","NOT IN","('8','08','9','09')");
      if (Extract::instance()->getCustomCode() != "MPS")
         hQuery.setBasicPredicate("PROBLEM_TRAN","SOURCE_VALUE","<>"," ");
      string strGroupBy("REASON_CODE,SUSPECT_TABLE,SOURCE_VALUE,PROBLEM_COLUMN,PROBLEM_TABLE");
      hQuery.setGroupByClause(strGroupBy);
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
      {
         UseCase::setSuccess(false);
         m_hTimer.set(m_iTimerValue);
         Database::instance()->commit();
         return true;
      }
      //if there were no unique issues discovered, let's check again in an hour
      if (m_hIssues.size() == 0)
      {
         m_hTimer.set(m_iTimerValue);
         Database::instance()->commit();
         return true;
      }
   }
   UseCase hUseCase("ADMIN","## AM06 FETCH PROBLEMS");
   // retrieve one problem with the timestamp that is for the first issue
   {
      Query hQuery(2);
      hQuery.attach(this);
      m_hProblem.bind(hQuery);
      hQuery.setBasicPredicate("PROBLEM_TRAN","TSTAMP_TRANS","=",m_hIssues.front().getTSTAMP_TRANS().c_str());
      hQuery.setBasicPredicate("PROBLEM_TRAN","REASON_CODE","=",m_hIssues.front().getREASON_CODE().c_str());
      hQuery.setBasicPredicate("PROBLEM_TRAN","SUSPECT_TABLE","=",m_hIssues.front().getSUSPECT_TABLE().c_str());
      hQuery.setBasicPredicate("PROBLEM_TRAN","SOURCE_VALUE","=",m_hIssues.front().getSOURCE_VALUE().c_str());
      hQuery.setBasicPredicate("PROBLEM_TRAN","PROBLEM_COLUMN","=",m_hIssues.front().getPROBLEM_COLUMN().c_str());
      hQuery.setBasicPredicate("PROBLEM_TRAN","PROBLEM_TABLE","=",m_hIssues.front().getPROBLEM_TABLE().c_str());
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
      {
         UseCase::setSuccess(false);
         m_hTimer.set(m_iTimerValue);
         Database::instance()->commit();
         return true;
      }
   }
   // try to solve the one problem that is retrieved
   if (ProblemSolver::instance()->repair(m_hProblem) != Problem::PTM_FIXED)
   {
      Database::instance()->commit();
      m_hIssues.pop_front();
      if (m_hIssues.size() == 0)
      {
         m_hTimer.set(m_iTimerValue);
         return true;
      }
      return false;
   }
   // since the problem can be fixed, we should now go ahead and retrieve all problems of this kind
   Query hQuery(3);
   hQuery.attach(this);
   hQuery.setRetainCursor(true);
   m_hProblem.bind(hQuery);
   hQuery.setBasicPredicate("PROBLEM_TRAN","REASON_CODE","=",m_hIssues.front().getREASON_CODE().c_str());
   hQuery.setBasicPredicate("PROBLEM_TRAN","SOURCE_VALUE","=",m_hIssues.front().getSOURCE_VALUE().c_str());
   hQuery.setBasicPredicate("PROBLEM_TRAN","SUSPECT_TABLE","=",m_hIssues.front().getSUSPECT_TABLE().c_str());
   hQuery.setBasicPredicate("PROBLEM_TRAN","PROBLEM_COLUMN","=",m_hIssues.front().getPROBLEM_COLUMN().c_str());
   hQuery.setBasicPredicate("PROBLEM_TRAN","PROBLEM_TABLE","=",m_hIssues.front().getPROBLEM_TABLE().c_str());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == false
      || hQuery.getAbort())
   {
      UseCase::setSuccess(false);
      m_hTimer.set(m_iTimerValue);
      Database::instance()->commit();
      return true;
   }
   Database::instance()->commit();
   m_hIssues.pop_front();
   if (m_hIssues.size() == 0)
   {
      m_hTimer.set(m_iTimerValue);
      return true;
   }
   return false;
  //## end ProblemMediator::retrieve%3936855103E1.body
}

void ProblemMediator::update (Subject* pSubject)
{
  //## begin ProblemMediator::update%393140E20348.body preserve=yes
   if (pSubject == &m_hTimer)
   {
      Application::instance()->setQueueWaitOption(false);
      return;
   }
   if (((Query*)pSubject)->getIndex() == 1)
      m_hIssues.push_back(m_hIssue);
   // for query 2, we want to retrieve only 1 row just to check that problems of these types can be solved
   else
   if (((Query*)pSubject)->getIndex() == 2)
      ((Query*)pSubject)->setAbort(true);
   else
   {
      if (ProblemSolver::instance()->repair(m_hProblem) != Problem::PTM_FIXED)
      {
         ((Query*)pSubject)->setAbort(true);
         return;
      }
      UseCase::addItem();
      if (UseCase::getItems() % 1000 == 0)
         Database::instance()->commit();
   }
  //## end ProblemMediator::update%393140E20348.body
}

// Additional Declarations
  //## begin ProblemMediator%393140A00267.declarations preserve=yes
  //## end ProblemMediator%393140A00267.declarations

//## begin module%3931426B014F.epilog preserve=yes
//## end module%3931426B014F.epilog
