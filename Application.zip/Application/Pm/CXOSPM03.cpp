//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%393684A30160.cm preserve=no
//	$Date:   May 12 2011 15:49:02  $ $Author:   e1009652  $
//	$Revision:   1.11  $
//## end module%393684A30160.cm

//## begin module%393684A30160.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%393684A30160.cp

//## Module: CXOSPM03%393684A30160; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM03.cpp

//## begin module%393684A30160.additionalIncludes preserve=no
//## end module%393684A30160.additionalIncludes

//## begin module%393684A30160.includes preserve=yes
// $Date:   May 12 2011 15:49:02  $ $Author:   e1009652  $ $Revision:   1.11  $
//## end module%393684A30160.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSPM03_h
#include "CXODPM03.hpp"
#endif


//## begin module%393684A30160.declarations preserve=no
//## end module%393684A30160.declarations

//## begin module%393684A30160.additionalDeclarations preserve=yes
//## end module%393684A30160.additionalDeclarations


// Class Problem 

Problem::Problem()
  //## begin Problem::Problem%3931479A00CA_const.hasinit preserve=no
      : m_iUNIQUENESS_KEY(0)
  //## end Problem::Problem%3931479A00CA_const.hasinit
  //## begin Problem::Problem%3931479A00CA_const.initialization preserve=yes
  //## end Problem::Problem%3931479A00CA_const.initialization
{
  //## begin Problem::Problem%3931479A00CA_const.body preserve=yes
   memcpy(m_sID,"PM03",4);
  //## end Problem::Problem%3931479A00CA_const.body
}

Problem::Problem(const Problem &right)
  //## begin Problem::Problem%3931479A00CA_copy.hasinit preserve=no
      : m_iUNIQUENESS_KEY(0)
  //## end Problem::Problem%3931479A00CA_copy.hasinit
  //## begin Problem::Problem%3931479A00CA_copy.initialization preserve=yes
  //## end Problem::Problem%3931479A00CA_copy.initialization
{
  //## begin Problem::Problem%3931479A00CA_copy.body preserve=yes
   memcpy(m_sID,"PM03",4);
   m_strTSTAMP_TRANS = right.getTSTAMP_TRANS();
   m_iUNIQUENESS_KEY = right.getUNIQUENESS_KEY();
   m_strUseCase = right.getUseCase();
   m_strPROBLEM_COLUMN = right.getPROBLEM_COLUMN();
   m_strPROBLEM_TABLE = right.getPROBLEM_TABLE();
   m_strREASON_CODE = right.getREASON_CODE();
   m_strSOURCE_VALUE = right.getSOURCE_VALUE();
   m_strSUSPECT_TABLE = right.getSUSPECT_TABLE();
  //## end Problem::Problem%3931479A00CA_copy.body
}


Problem::~Problem()
{
  //## begin Problem::~Problem%3931479A00CA_dest.body preserve=yes
  //## end Problem::~Problem%3931479A00CA_dest.body
}


Problem & Problem::operator=(const Problem &right)
{
  //## begin Problem::operator=%3931479A00CA_assign.body preserve=yes
   if (this == &right)
      return *this;
   m_strTSTAMP_TRANS = right.getTSTAMP_TRANS();
   m_iUNIQUENESS_KEY = right.getUNIQUENESS_KEY();
   m_strUseCase = right.getUseCase();
   m_strPROBLEM_COLUMN = right.getPROBLEM_COLUMN();
   m_strPROBLEM_TABLE = right.getPROBLEM_TABLE();
   m_strREASON_CODE = right.getREASON_CODE();
   m_strSOURCE_VALUE = right.getSOURCE_VALUE();
   m_strSUSPECT_TABLE = right.getSUSPECT_TABLE();
   return *this;
  //## end Problem::operator=%3931479A00CA_assign.body
}



//## Other Operations (implementation)
void Problem::bind (reusable::Query& hQuery)
{
  //## begin Problem::bind%393147E80109.body preserve=yes
   // AM02: SW_Retrieves_Problems_From_DB
   hQuery.bind("PROBLEM_TRAN","TSTAMP_TRANS",Column::STRING,&m_strTSTAMP_TRANS);
   hQuery.bind("PROBLEM_TRAN","UNIQUENESS_KEY",Column::SHORT,&m_iUNIQUENESS_KEY);
   hQuery.bind("PROBLEM_TRAN","REASON_CODE",Column::STRING,&m_strREASON_CODE);
   hQuery.bind("PROBLEM_TRAN","SOURCE_VALUE",Column::STRING,&m_strSOURCE_VALUE);
   hQuery.bind("PROBLEM_TRAN","SUSPECT_TABLE",Column::STRING,&m_strSUSPECT_TABLE);
   hQuery.bind("PROBLEM_TRAN","PROBLEM_COLUMN",Column::STRING,&m_strPROBLEM_COLUMN);
   hQuery.bind("PROBLEM_TRAN","PROBLEM_TABLE",Column::STRING,&m_strPROBLEM_TABLE);
  //## end Problem::bind%393147E80109.body
}

Problem::State Problem::repair (EvidenceSegment& hEvidenceSegment)
{
  //## begin Problem::repair%396DD6CD019F.body preserve=yes
   return Problem::PTM_NOT_FIXED;
  //## end Problem::repair%396DD6CD019F.body
}

// Additional Declarations
  //## begin Problem%3931479A00CA.declarations preserve=yes
  //## end Problem%3931479A00CA.declarations

//## begin module%393684A30160.epilog preserve=yes
//## end module%393684A30160.epilog
