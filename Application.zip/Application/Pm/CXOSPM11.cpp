//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4ACDFD300315.cm preserve=no
//	$Date:   Dec 01 2009 13:41:42  $ $Author:   E1024360  $
//	$Revision:   1.3  $
//## end module%4ACDFD300315.cm

//## begin module%4ACDFD300315.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4ACDFD300315.cp

//## Module: CXOSPM11%4ACDFD300315; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM11.cpp

//## begin module%4ACDFD300315.additionalIncludes preserve=no
//## end module%4ACDFD300315.additionalIncludes

//## begin module%4ACDFD300315.includes preserve=yes
//## end module%4ACDFD300315.includes

#ifndef CXOSEX61_h
#include "CXODEX61.hpp"
#endif
#ifndef CXOSEC01_h
#include "CXODEC01.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSPM12_h
#include "CXODPM12.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSEX01_h
#include "CXODEX01.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSPM11_h
#include "CXODPM11.hpp"
#endif


//## begin module%4ACDFD300315.declarations preserve=no
//## end module%4ACDFD300315.declarations

//## begin module%4ACDFD300315.additionalDeclarations preserve=yes
#define AUTH_TRAN 0
#define FIN_TRAN  1
//## end module%4ACDFD300315.additionalDeclarations


// Class UnmatchedAuthorization 

//## begin UnmatchedAuthorization::Instance%4ACE1C1F0161.attr preserve=no  private: static UnmatchedAuthorization* {V} 0
UnmatchedAuthorization* UnmatchedAuthorization::m_pInstance = 0;
//## end UnmatchedAuthorization::Instance%4ACE1C1F0161.attr

UnmatchedAuthorization::UnmatchedAuthorization()
  //## begin UnmatchedAuthorization::UnmatchedAuthorization%4ACDFCF600F2_const.hasinit preserve=no
  //## end UnmatchedAuthorization::UnmatchedAuthorization%4ACDFCF600F2_const.hasinit
  //## begin UnmatchedAuthorization::UnmatchedAuthorization%4ACDFCF600F2_const.initialization preserve=yes
  //## end UnmatchedAuthorization::UnmatchedAuthorization%4ACDFCF600F2_const.initialization
{
  //## begin UnmatchedAuthorization::UnmatchedAuthorization%4ACDFCF600F2_const.body preserve=yes
   memcpy(m_sID,"PM11",4);
   m_strUseCase = "## AM17 UNMATCHED AUTH"; 
  //## end UnmatchedAuthorization::UnmatchedAuthorization%4ACDFCF600F2_const.body
}


UnmatchedAuthorization::~UnmatchedAuthorization()
{
  //## begin UnmatchedAuthorization::~UnmatchedAuthorization%4ACDFCF600F2_dest.body preserve=yes
  //## end UnmatchedAuthorization::~UnmatchedAuthorization%4ACDFCF600F2_dest.body
}



//## Other Operations (implementation)
void UnmatchedAuthorization::ageOffOldRecords ()
{
  //## begin UnmatchedAuthorization::ageOffOldRecords%4ACE40130308.body preserve=yes
   int iDays = 15;
   string strNumDays;
   if (Extract::instance()->getSpec("AGEOFF",strNumDays))
      iDays = atoi(strNumDays.c_str());
   
   Query hQuery;
   hQuery.setBasicPredicate("PROBLEM_TRAN","PROBLEM_TABLE","=","EMS_CASE");         
   hQuery.setBasicPredicate("PROBLEM_TRAN","REASON_CODE","IN",
      "('8','9')");         
   hQuery.setBasicPredicate("PROBLEM_TRAN","TSTAMP_INSERTED","<",
      (Date::today() - iDays).asString("%Y%m%d").c_str());         
   auto_ptr<reusable::SelectStatement> pDeleteStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("DeleteStatement"));
   pDeleteStatement->execute(hQuery); 
  //## end UnmatchedAuthorization::ageOffOldRecords%4ACE40130308.body
}

UnmatchedAuthorization* UnmatchedAuthorization::instance ()
{
  //## begin UnmatchedAuthorization::instance%4ACE1C8802E4.body preserve=yes
   if (m_pInstance == 0)
      m_pInstance = new UnmatchedAuthorization();
      
   return m_pInstance;
  //## end UnmatchedAuthorization::instance%4ACE1C8802E4.body
}

Problem::State UnmatchedAuthorization::repair (EvidenceSegment& hEvidenceSegment)
{
  //## begin UnmatchedAuthorization::repair%4ACE18F200B8.body preserve=yes
   Trace::put("PM11: repair method");
   Case::resetSegments();
   Transaction::instance()->begin();   
   string strTimeStamp = Clock::instance()->getYYYYMMDDHHMMSS(true);
   Transaction::instance()->setTimeStamp(strTimeStamp += "00");
   
   string strTSTAMP_TRANS[2];
   int iUNIQUENESS_KEY[2];
   strTSTAMP_TRANS[FIN_TRAN] = hEvidenceSegment.getTSTAMP_TRANS();
   iUNIQUENESS_KEY[FIN_TRAN] = hEvidenceSegment.getUNIQUENESS_KEY();
   
   Trace::put("PM11: Details about the financial transaction");
   Trace::put(hEvidenceSegment.getTSTAMP_TRANS().c_str());
   
   strTSTAMP_TRANS[AUTH_TRAN].assign(hEvidenceSegment.getSOURCE_VALUE().c_str(),16);
   char szTemp[9]; 
   memcpy(szTemp,hEvidenceSegment.getSOURCE_VALUE().c_str()+16,8);
   szTemp[8]='\0';
   iUNIQUENESS_KEY[AUTH_TRAN] = atoi(szTemp);
   
   Trace::put("PM11: Details about the auth transaction");
   Trace::put(hEvidenceSegment.getSOURCE_VALUE().c_str());
   
   ems::DisputedAuthorization hDisputedAuthorization(strTSTAMP_TRANS[AUTH_TRAN], iUNIQUENESS_KEY[AUTH_TRAN]);
   hDisputedAuthorization.setTSTAMP_TRANS(strTSTAMP_TRANS[FIN_TRAN],FIN_TRAN); 
   hDisputedAuthorization.setUNIQUENESS_KEY(iUNIQUENESS_KEY[FIN_TRAN],FIN_TRAN);
   CaseCreateCommand hCaseCreateCommand;
   hDisputedAuthorization.setCaseCreateCommand(&hCaseCreateCommand);
   int iResult = hDisputedAuthorization.createCase();
     
   Transaction::instance()->commit();
   //if a case was not successfully created or the evidence could not be removed
   //we are sending a PTM_SQL_ERROR, so that the main loop in PM02 will
   //rollback and abort the query.
   if (iResult != 0)
   {
      UnmatchedAuthorizationAudit::instance()->add('C',hEvidenceSegment.getSOURCE_VALUE(),iResult);
      if (iResult != STS_DUPLICATE_RECORD)
         return PTM_SQL_ERROR;
   }
   
   //remove the disputed authorization from the problem tran table and 
   //set the FIN_TYPE of the auth transaction back to its original value
   if (hDisputedAuthorization.remove()!= 0)
      return PTM_SQL_ERROR;
      
   return PTM_FIXED;
  //## end UnmatchedAuthorization::repair%4ACE18F200B8.body
}

// Additional Declarations
  //## begin UnmatchedAuthorization%4ACDFCF600F2.declarations preserve=yes
  //## end UnmatchedAuthorization%4ACDFCF600F2.declarations

//## begin module%4ACDFD300315.epilog preserve=yes
//## end module%4ACDFD300315.epilog
