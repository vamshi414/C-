//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3931396E00F6.cm preserve=no
//	$Date:   Dec 13 2011 09:31:54  $ $Author:   e1009839  $
//	$Revision:   1.18  $
//## end module%3931396E00F6.cm

//## begin module%3931396E00F6.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%3931396E00F6.cp

//## Module: CXOPPM00%3931396E00F6; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM00.hpp

#ifndef CXOPPM00_h
#define CXOPPM00_h 1

//## begin module%3931396E00F6.additionalIncludes preserve=no
//## end module%3931396E00F6.additionalIncludes

//## begin module%3931396E00F6.includes preserve=yes
// $Date:   Dec 13 2011 09:31:54  $ $Author:   e1009839  $ $Revision:   1.18  $
//## end module%3931396E00F6.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSPM17_h
#include "CXODPM17.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class Case;
class EMSRulesEngine;
} // namespace ems

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class ProblemMediator;
class AuthorizationMediator;
class UnmatchedAuthorizationAudit;
class UnmatchedAuthorization;
//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

namespace IF {
class Message;
class Extract;
class Console;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class HourAlarm;
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%3931396E00F6.declarations preserve=no
//## end module%3931396E00F6.declarations

//## begin module%3931396E00F6.additionalDeclarations preserve=yes
//## end module%3931396E00F6.additionalDeclarations


//## begin ProblemTransactionManager%3918124303B9.preface preserve=yes
//## end ProblemTransactionManager%3918124303B9.preface

//## Class: ProblemTransactionManager%3918124303B9
//	<body>
//	<title>CG
//	<h1>PM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	A transaction is marked as a problem when required
//	configuration information is not available at the time
//	the transaction is loaded by DataNavigator.
//	When the necessary configuration information is added,
//	the Problem Transaction Manager service is used to clear
//	up the issues.
//	<p>
//	A problem transaction can be viewed by the DataNavigator
//	Client using transaction research.
//	However, a problem transaction is not included in totals
//	until all issues for that transaction are resolved.
//	<p>
//	Refer to the Transaction Interface Configuration Guide
//	for information on updating configuration information.
//	</p>
//	<img src=CXOCPM00.gif>
//	</body>
//	<body>
//	<title>OG
//	<h1>PM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	A transaction is marked as a problem when required
//	configuration information is not available at the time
//	the transaction is loaded by DataNavigator.
//	The types of existing problems and number of affected
//	transactions can be determined using the Operator
//	Console.
//	Problems are resolved by updating the Configuration
//	Repository.
//	This may involve obtaining a new configuration file from
//	your EFT platform or adding configuration information
//	using the CR Client for the DataNavigator Server.
//	<p>
//	The Problem Transactions folder in the Operator Console
//	should be regularly monitored.
//	</p>
//	<img src=CXOOPM00.gif>
//	</body>
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1



//## Uses: <unnamed>%393141DC0008;ProblemMediator { -> F}
//## Uses: <unnamed>%39368AF403C8;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3936ADBE0248;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3936ADC00114;database::Database { -> F}
//## Uses: <unnamed>%39CBA3500244;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%39CBA6900164;IF::Message { -> F}
//## Uses: <unnamed>%3A3924C6025D;monitor::UseCase { -> F}
//## Uses: <unnamed>%40A4D6FF004E;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%4ACE40B40182;UnmatchedAuthorization { -> F}
//## Uses: <unnamed>%4ACF80BD03A1;UnmatchedAuthorizationAudit { -> F}
//## Uses: <unnamed>%4B059126014F;ems::Case { -> F}
//## Uses: <unnamed>%4B05915300E0;IF::Extract { -> F}
//## Uses: <unnamed>%4B0591750061;reusable::Transaction { -> F}
//## Uses: <unnamed>%4B0591A60050;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%4B0591FF004D;IF::Trace { -> F}
//## Uses: <unnamed>%4C87F7A702FC;AuthorizationMediator { -> F}
//## Uses: <unnamed>%4E045D2B013B;ProblemSummary { -> F}
//## Uses: <unnamed>%4E0462B20169;timer::HourAlarm { -> F}
//## Uses: <unnamed>%4E1172FB0333;IF::Console { -> F}

class ProblemTransactionManager : public process::Application  //## Inherits: <unnamed>%3918125F0015
{
  //## begin ProblemTransactionManager%3918124303B9.initialDeclarations preserve=yes
  //## end ProblemTransactionManager%3918124303B9.initialDeclarations

  public:
    //## Constructors (generated)
      ProblemTransactionManager();

    //## Destructor (generated)
      virtual ~ProblemTransactionManager();


    //## Other Operations (specified)
      //## Operation: initialize%3918127A0259
      virtual int initialize ();

      //## Operation: update%391812AA0349
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin ProblemTransactionManager%3918124303B9.public preserve=yes
      //## end ProblemTransactionManager%3918124303B9.public

  protected:

    //## Other Operations (specified)
      //## Operation: onReset%391812A70358
      //	Syntax:  RESET task
      //
      //	This command causes the ProblemTransactionManager task
      //	to analyze all problem transactions and attempt to clear
      //	up any outstanding issues.
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>PM
      //	<h2>CD
      //	<h3>Fix Problem Transactions
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>PTM
      //	<h4>Description
      //	<p>
      //	The ProblemTransactionManager task analyzes all problem
      //	transactions and attempts to clear up any outstanding
      //	issues.
      //	</p>
      //	<h4>Schedule
      //	<p>
      //	The DataNavigator Server installation automatically sets
      //	up an event to perform this command at 11:30 PM (30
      //	minutes prior to the default switch end of day at
      //	midnight).
      //	Use the CR Client to change the time.
      //	<p>
      //	The Events are in the Event Management folder in the CR
      //	Client for the DataNavigator Server.
      //	</p>
      //	</body>
      virtual int onReset (IF::Message& hMessage);

      //## Operation: onResume%393141C202F0
      virtual int onResume (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin ProblemTransactionManager%3918124303B9.protected preserve=yes
      //## end ProblemTransactionManager%3918124303B9.protected

  private:
    // Additional Private Declarations
      //## begin ProblemTransactionManager%3918124303B9.private preserve=yes
      //## end ProblemTransactionManager%3918124303B9.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%4E045D4302C0
      //## Role: ProblemTransactionManager::<m_hProblemSummary>%4E045D450187
      //## begin ProblemTransactionManager::<m_hProblemSummary>%4E045D450187.role preserve=no  public: ProblemSummary { -> VHgN}
      ProblemSummary m_hProblemSummary;
      //## end ProblemTransactionManager::<m_hProblemSummary>%4E045D450187.role

    // Additional Implementation Declarations
      //## begin ProblemTransactionManager%3918124303B9.implementation preserve=yes
      //## end ProblemTransactionManager%3918124303B9.implementation

};

//## begin ProblemTransactionManager%3918124303B9.postscript preserve=yes
//## end ProblemTransactionManager%3918124303B9.postscript

//## begin module%3931396E00F6.epilog preserve=yes
//## end module%3931396E00F6.epilog


#endif
