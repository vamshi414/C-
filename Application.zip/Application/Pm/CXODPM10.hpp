//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%396DCD7001CA.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%396DCD7001CA.cm

//## begin module%396DCD7001CA.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%396DCD7001CA.cp

//## Module: CXOSPM10%396DCD7001CA; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM10.hpp

#ifndef CXOSPM10_h
#define CXOSPM10_h 1

//## begin module%396DCD7001CA.additionalIncludes preserve=no
//## end module%396DCD7001CA.additionalIncludes

//## begin module%396DCD7001CA.includes preserve=yes
// $Date:   May 24 2005 14:25:10  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%396DCD7001CA.includes

#ifndef CXOSPM03_h
#include "CXODPM03.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class EvidenceSegment;
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%396DCD7001CA.declarations preserve=no
//## end module%396DCD7001CA.declarations

//## begin module%396DCD7001CA.additionalDeclarations preserve=yes
//## end module%396DCD7001CA.additionalDeclarations


//## begin ProblemIssuerAccountTypes%396DCFC00334.preface preserve=yes
//## end ProblemIssuerAccountTypes%396DCFC00334.preface

//## Class: ProblemIssuerAccountTypes%396DCFC00334
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%396DD6680096;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%396DD66E038D;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%396DD6710161;reusable::Table { -> F}
//## Uses: <unnamed>%396DD67303BD;reusable::Statement { -> F}
//## Uses: <unnamed>%396DD67603A3;reusable::Query { -> F}
//## Uses: <unnamed>%396DD67A004B;configuration::EvidenceSegment { -> F}
//## Uses: <unnamed>%396DF333030B;database::DatabaseFactory { -> F}

class ProblemIssuerAccountTypes : public Problem  //## Inherits: <unnamed>%396DD6660115
{
  //## begin ProblemIssuerAccountTypes%396DCFC00334.initialDeclarations preserve=yes
  //## end ProblemIssuerAccountTypes%396DCFC00334.initialDeclarations

  public:
    //## Constructors (generated)
      ProblemIssuerAccountTypes();

    //## Destructor (generated)
      virtual ~ProblemIssuerAccountTypes();


    //## Other Operations (specified)
      //## Operation: instance%3EBFC03F003E
      static ProblemIssuerAccountTypes* instance ();

      //## Operation: repair%396DD97C01E3
      Problem::State repair (configuration::EvidenceSegment& hEvidenceSegment);

    // Additional Public Declarations
      //## begin ProblemIssuerAccountTypes%396DCFC00334.public preserve=yes
      //## end ProblemIssuerAccountTypes%396DCFC00334.public

  protected:
    // Additional Protected Declarations
      //## begin ProblemIssuerAccountTypes%396DCFC00334.protected preserve=yes
      //## end ProblemIssuerAccountTypes%396DCFC00334.protected

  private:
    // Additional Private Declarations
      //## begin ProblemIssuerAccountTypes%396DCFC00334.private preserve=yes
      //## end ProblemIssuerAccountTypes%396DCFC00334.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3EBFBF7D0232
      //## begin ProblemIssuerAccountTypes::Instance%3EBFBF7D0232.attr preserve=no  private: static ProblemIssuerAccountTypes* {V} 0
      static ProblemIssuerAccountTypes* m_pInstance;
      //## end ProblemIssuerAccountTypes::Instance%3EBFBF7D0232.attr

    // Additional Implementation Declarations
      //## begin ProblemIssuerAccountTypes%396DCFC00334.implementation preserve=yes
      //## end ProblemIssuerAccountTypes%396DCFC00334.implementation

};

//## begin ProblemIssuerAccountTypes%396DCFC00334.postscript preserve=yes
//## end ProblemIssuerAccountTypes%396DCFC00334.postscript

//## begin module%396DCD7001CA.epilog preserve=yes
//## end module%396DCD7001CA.epilog


#endif
