//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4E035A4400B4.cm preserve=no
//	$Date:   May 14 2012 02:18:22  $ $Author:   D02684  $
//	$Revision:   1.2  $
//## end module%4E035A4400B4.cm

//## begin module%4E035A4400B4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4E035A4400B4.cp

//## Module: CXOSPM17%4E035A4400B4; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM17.hpp

#ifndef CXOSPM17_h
#define CXOSPM17_h 1

//## begin module%4E035A4400B4.additionalIncludes preserve=no
//## end module%4E035A4400B4.additionalIncludes

//## begin module%4E035A4400B4.includes preserve=yes
#include <vector>
//## end module%4E035A4400B4.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSPM16_h
#include "CXODPM16.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class ContactSegment;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Email;
} // namespace command

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;

} // namespace usersegment

//## begin module%4E035A4400B4.declarations preserve=no
//## end module%4E035A4400B4.declarations

//## begin module%4E035A4400B4.additionalDeclarations preserve=yes
//## end module%4E035A4400B4.additionalDeclarations


//## begin ProblemSummary%4E0348320178.preface preserve=yes
//## end ProblemSummary%4E0348320178.preface

//## Class: ProblemSummary%4E0348320178
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4E04524D0110;reusable::Query { -> F}
//## Uses: <unnamed>%4E04539D016F;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4E0453A00334;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4E049EA60066;IF::Extract { -> F}
//## Uses: <unnamed>%4E049F260254;entitysegment::ContactSegment { -> F}
//## Uses: <unnamed>%4E04AEA7033D;command::Email { -> F}
//## Uses: <unnamed>%4FA8C4ED01F2;usersegment::EmailSegment { -> F}
//## Uses: <unnamed>%4FA8C61F00B4;timer::Clock { -> F}

class DllExport ProblemSummary : public reusable::Observer  //## Inherits: <unnamed>%4E0452B502AA
{
  //## begin ProblemSummary%4E0348320178.initialDeclarations preserve=yes
  //## end ProblemSummary%4E0348320178.initialDeclarations

  public:
    //## Constructors (generated)
      ProblemSummary();

    //## Destructor (generated)
      virtual ~ProblemSummary();

    //## Assignment Operation (generated)
      ProblemSummary & operator=(const ProblemSummary &right);

    //## Equality Operations (generated)
      bool operator==(const ProblemSummary &right) const;

      bool operator!=(const ProblemSummary &right) const;


    //## Other Operations (specified)
      //## Operation: clear%4E81DF3B016A
      void clear ();

      //## Operation: email%4E0359D402CE
      void email ();

      //## Operation: isEmpty%4E12E1EC030F
      bool isEmpty ();

      //## Operation: retrieve%4E0359CB037A
      bool retrieve ();

      //## Operation: update%4E0454190103
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin ProblemSummary%4E0348320178.public preserve=yes
      //## end ProblemSummary%4E0348320178.public

  protected:
    // Additional Protected Declarations
      //## begin ProblemSummary%4E0348320178.protected preserve=yes
      //## end ProblemSummary%4E0348320178.protected

  private:
    // Additional Private Declarations
      //## begin ProblemSummary%4E0348320178.private preserve=yes
      //## end ProblemSummary%4E0348320178.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%4E0439DE015B
      //## Role: ProblemSummary::<m_hProblemSummarySegment>%4E0439DF018A
      //## begin ProblemSummary::<m_hProblemSummarySegment>%4E0439DF018A.role preserve=no  public: ProblemSummarySegment { -> VHgN}
      ProblemSummarySegment m_hProblemSummarySegment;
      //## end ProblemSummary::<m_hProblemSummarySegment>%4E0439DF018A.role

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%4E0459B803AD
      //## Role: ProblemSummary::<m_hQuery>%4E0459BA010D
      //## begin ProblemSummary::<m_hQuery>%4E0459BA010D.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end ProblemSummary::<m_hQuery>%4E0459BA010D.role

    // Additional Implementation Declarations
      //## begin ProblemSummary%4E0348320178.implementation preserve=yes
      vector <ProblemSummarySegment> m_hProblemSummaryList;
      //## end ProblemSummary%4E0348320178.implementation
};

//## begin ProblemSummary%4E0348320178.postscript preserve=yes
//## end ProblemSummary%4E0348320178.postscript

//## begin module%4E035A4400B4.epilog preserve=yes
//## end module%4E035A4400B4.epilog


#endif
