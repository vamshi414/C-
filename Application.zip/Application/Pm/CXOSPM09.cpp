//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%396DCD6E0330.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%396DCD6E0330.cm

//## begin module%396DCD6E0330.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%396DCD6E0330.cp

//## Module: CXOSPM09%396DCD6E0330; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM09.cpp

//## begin module%396DCD6E0330.additionalIncludes preserve=no
//## end module%396DCD6E0330.additionalIncludes

//## begin module%396DCD6E0330.includes preserve=yes
// $Date:   Jun 30 2006 12:12:38  $ $Author:   D02405  $ $Revision:   1.11  $
#include "CXODRU24.hpp"
//## end module%396DCD6E0330.includes

#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSPM09_h
#include "CXODPM09.hpp"
#endif


//## begin module%396DCD6E0330.declarations preserve=no
//## end module%396DCD6E0330.declarations

//## begin module%396DCD6E0330.additionalDeclarations preserve=yes
//## end module%396DCD6E0330.additionalDeclarations


// Class ProblemIssuerChain 

//## begin ProblemIssuerChain::Instance%3EBFBEE203C8.attr preserve=no  private: static ProblemIssuerChain* {V} 0
ProblemIssuerChain* ProblemIssuerChain::m_pInstance = 0;
//## end ProblemIssuerChain::Instance%3EBFBEE203C8.attr

ProblemIssuerChain::ProblemIssuerChain()
  //## begin ProblemIssuerChain::ProblemIssuerChain%396DCFBE038C_const.hasinit preserve=no
  //## end ProblemIssuerChain::ProblemIssuerChain%396DCFBE038C_const.hasinit
  //## begin ProblemIssuerChain::ProblemIssuerChain%396DCFBE038C_const.initialization preserve=yes
  //## end ProblemIssuerChain::ProblemIssuerChain%396DCFBE038C_const.initialization
{
  //## begin ProblemIssuerChain::ProblemIssuerChain%396DCFBE038C_const.body preserve=yes
   memcpy(m_sID,"PM09",4);
   m_strUseCase = "## AM15 ISSUER CHAIN";
  //## end ProblemIssuerChain::ProblemIssuerChain%396DCFBE038C_const.body
}


ProblemIssuerChain::~ProblemIssuerChain()
{
  //## begin ProblemIssuerChain::~ProblemIssuerChain%396DCFBE038C_dest.body preserve=yes
  //## end ProblemIssuerChain::~ProblemIssuerChain%396DCFBE038C_dest.body
}



//## Other Operations (implementation)
ProblemIssuerChain* ProblemIssuerChain::instance ()
{
  //## begin ProblemIssuerChain::instance%3EBFBEF70261.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ProblemIssuerChain();
   return m_pInstance;
  //## end ProblemIssuerChain::instance%3EBFBEF70261.body
}

Problem::State ProblemIssuerChain::repair (configuration::EvidenceSegment& hEvidenceSegment)
{
  //## begin ProblemIssuerChain::repair%396DD97703C7.body preserve=yes
   // AM15: SW_Repairs_Issuer_Chain
   string strProcId, strSourceValue, strTranslatedValue;
   string strProcGroupId, strProblemColumn, strSuspectTable;

   Table hTable(string("FIN_L" + m_strTSTAMP_TRANS.substr(0,6)).c_str());
   if (hEvidenceSegment.getSUSPECT_TABLE() == "X_NET_INST_ID")
   {
      if (ConfigurationRepository::instance()->translate("X_NET_INST_ID",
         hEvidenceSegment.getSOURCE_VALUE(), strTranslatedValue, "", "", 0) == false)
         return PTM_NOT_FIXED;
      hTable.set("INST_ID_RECN_ISS_B",strTranslatedValue);
      hTable.set("INST_ID_ISS",strTranslatedValue);
      if (ConfigurationRepository::instance()->translate("INSTITUTION",
         strTranslatedValue, strProcId, "", "", 0))
      {
         hTable.set("PROC_ID_ISS",strProcId);
         hTable.set("PROC_ID_ISS_B",strProcId);
         if (ConfigurationRepository::instance()->translate("PROCESSOR",
           strProcId, strProcGroupId, "", "", 0))
            hTable.set("PROC_GRP_ID_ISS_B",strProcGroupId);
         else
         {
            strProblemColumn = "PROC_GRP_ID_ISS_B";
            strSuspectTable = "PROCESSOR";
            strSourceValue = strProcId;
         }
      }
      else
      {
         strProblemColumn = "PROC_ID_ISS";
         strSuspectTable = "INSTITUTION";
         strSourceValue = strTranslatedValue;
      }
   }
   else
   {
      if (ConfigurationRepository::instance()->translate(hEvidenceSegment.getSUSPECT_TABLE().c_str(),
         hEvidenceSegment.getSOURCE_VALUE(), strTranslatedValue, "", "", 0) == false)
         return PTM_NOT_FIXED;
      if (ConfigurationRepository::instance()->translate("PROCESSOR",
         strTranslatedValue, strProcGroupId, "", "", 0))
         hTable.set("PROC_GRP_ID_ISS_B",strProcGroupId);
      else
      {
         strProblemColumn = "PROC_GRP_ID_ISS_B";
         strSuspectTable = "PROCESSOR";
         strSourceValue = strTranslatedValue;
      }
   }
   
   hTable.set(hEvidenceSegment.getPROBLEM_COLUMN().c_str(),strTranslatedValue);
   hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int) m_iUNIQUENESS_KEY,true);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   bool bReturn = pUpdateStatement->execute(hTable);
   if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      return PTM_NOT_FOUND;
   if (!bReturn)
      return PTM_SQL_ERROR;
   if (strProblemColumn.length() == 0)
      return PTM_FIXED;
   hTable.reset();
   EvidenceSegment hEvidenceSegment2(hEvidenceSegment);
   hEvidenceSegment2.setPROBLEM_COLUMN(strProblemColumn);
   hEvidenceSegment2.setSUSPECT_TABLE(strSuspectTable);
   hEvidenceSegment2.setREASON_CODE(EVIDENCE_TRANSLATE_FAILURE);
   hEvidenceSegment2.setSOURCE_VALUE(strSourceValue);
   hEvidenceSegment2.setColumns(hTable);
   auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   if (pInsertStatement->execute(hTable))
      return PTM_PARTIAL_FIX;
   return PTM_SQL_ERROR;
  //## end ProblemIssuerChain::repair%396DD97703C7.body
}

// Additional Declarations
  //## begin ProblemIssuerChain%396DCFBE038C.declarations preserve=yes
  //## end ProblemIssuerChain%396DCFBE038C.declarations

//## begin module%396DCD6E0330.epilog preserve=yes
//## end module%396DCD6E0330.epilog
