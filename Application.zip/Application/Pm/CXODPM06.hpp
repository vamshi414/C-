//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%396DCD5F0248.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%396DCD5F0248.cm

//## begin module%396DCD5F0248.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%396DCD5F0248.cp

//## Module: CXOSPM06%396DCD5F0248; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM06.hpp

#ifndef CXOSPM06_h
#define CXOSPM06_h 1

//## begin module%396DCD5F0248.additionalIncludes preserve=no
//## end module%396DCD5F0248.additionalIncludes

//## begin module%396DCD5F0248.includes preserve=yes
// $Date:   May 24 2005 14:25:10  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%396DCD5F0248.includes

#ifndef CXOSPM03_h
#include "CXODPM03.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class EvidenceSegment;
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%396DCD5F0248.declarations preserve=no
//## end module%396DCD5F0248.declarations

//## begin module%396DCD5F0248.additionalDeclarations preserve=yes
//## end module%396DCD5F0248.additionalDeclarations


//## begin ProblemReimbursementFlag%396DCFBA0372.preface preserve=yes
//## end ProblemReimbursementFlag%396DCFBA0372.preface

//## Class: ProblemReimbursementFlag%396DCFBA0372
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%396DD4500261;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%396DD456029C;reusable::Table { -> F}
//## Uses: <unnamed>%396DD45B013B;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%396DD4620073;configuration::EvidenceSegment { -> F}
//## Uses: <unnamed>%396DD46500F9;reusable::Query { -> F}
//## Uses: <unnamed>%396DD46700E8;reusable::Statement { -> F}
//## Uses: <unnamed>%396DF367002B;database::DatabaseFactory { -> F}

class ProblemReimbursementFlag : public Problem  //## Inherits: <unnamed>%396DD44E0196
{
  //## begin ProblemReimbursementFlag%396DCFBA0372.initialDeclarations preserve=yes
  //## end ProblemReimbursementFlag%396DCFBA0372.initialDeclarations

  public:
    //## Constructors (generated)
      ProblemReimbursementFlag();

    //## Destructor (generated)
      virtual ~ProblemReimbursementFlag();


    //## Other Operations (specified)
      //## Operation: instance%3EBFBD580242
      static ProblemReimbursementFlag* instance ();

      //## Operation: repair%396DD967011B
      Problem::State repair (configuration::EvidenceSegment& hEvidenceSegment);

    // Additional Public Declarations
      //## begin ProblemReimbursementFlag%396DCFBA0372.public preserve=yes
      //## end ProblemReimbursementFlag%396DCFBA0372.public

  protected:
    // Additional Protected Declarations
      //## begin ProblemReimbursementFlag%396DCFBA0372.protected preserve=yes
      //## end ProblemReimbursementFlag%396DCFBA0372.protected

  private:
    // Additional Private Declarations
      //## begin ProblemReimbursementFlag%396DCFBA0372.private preserve=yes
      //## end ProblemReimbursementFlag%396DCFBA0372.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%3EBFBD250261
      //## begin ProblemReimbursementFlag::Instance%3EBFBD250261.attr preserve=no  private: static ProblemReimbursementFlag* {V} 0
      static ProblemReimbursementFlag* m_pInstance;
      //## end ProblemReimbursementFlag::Instance%3EBFBD250261.attr

    // Additional Implementation Declarations
      //## begin ProblemReimbursementFlag%396DCFBA0372.implementation preserve=yes
      //## end ProblemReimbursementFlag%396DCFBA0372.implementation

};

//## begin ProblemReimbursementFlag%396DCFBA0372.postscript preserve=yes
//## end ProblemReimbursementFlag%396DCFBA0372.postscript

//## begin module%396DCD5F0248.epilog preserve=yes
//## end module%396DCD5F0248.epilog


#endif
