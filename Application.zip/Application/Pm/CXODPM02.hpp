//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%393142AA023F.cm preserve=no
//	$Date:   Mar 10 2011 14:07:10  $ $Author:   D02684  $
//	$Revision:   1.14  $
//## end module%393142AA023F.cm

//## begin module%393142AA023F.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%393142AA023F.cp

//## Module: CXOSPM02%393142AA023F; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM02.hpp

#ifndef CXOSPM02_h
#define CXOSPM02_h 1

//## begin module%393142AA023F.additionalIncludes preserve=no
//## end module%393142AA023F.additionalIncludes

//## begin module%393142AA023F.includes preserve=yes
// $Date:   Mar 10 2011 14:07:10  $ $Author:   D02684  $ $Revision:   1.14  $
//## end module%393142AA023F.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif
#ifndef CXOSPM03_h
#include "CXODPM03.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class ProblemActionCodeTranslation;
class UnmatchedAuthorization;
class ProblemIssuerAccountTypes;
class ProblemIssuerChain;
class ProblemAcquirerChain;
class ProblemActionCode;
class ProblemReimbursementFlag;
class ProblemVerification;
class ProblemTranslation;
//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
class InsertSequenceNumber;

} // namespace database

//## begin module%393142AA023F.declarations preserve=no
//## end module%393142AA023F.declarations

//## begin module%393142AA023F.additionalDeclarations preserve=yes
//## end module%393142AA023F.additionalDeclarations


//## begin ProblemSolver%391818D60142.preface preserve=yes
//## end ProblemSolver%391818D60142.preface

//## Class: ProblemSolver%391818D60142
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3931413F0189;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%393141430302;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%393141580199;reusable::Statement { -> F}
//## Uses: <unnamed>%3931419400A5;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%393148C100D9;Problem { -> }
//## Uses: <unnamed>%39536138011A;configuration::EvidenceSegment { -> F}
//## Uses: <unnamed>%39536C1D0215;database::Database { -> F}
//## Uses: <unnamed>%3978963501B2;database::InsertSequenceNumber { -> F}
//## Uses: <unnamed>%3A392CF80278;monitor::UseCase { -> F}

class ProblemSolver : public reusable::Observer  //## Inherits: <unnamed>%391818EC03D8
{
  //## begin ProblemSolver%391818D60142.initialDeclarations preserve=yes
  //## end ProblemSolver%391818D60142.initialDeclarations

  public:
    //## Constructors (generated)
      ProblemSolver();

    //## Destructor (generated)
      virtual ~ProblemSolver();


    //## Other Operations (specified)
      //## Operation: instance%393143E603AC
      static ProblemSolver* instance ();

      //## Operation: repair%391819460283
      //## Preconditions:
      //	<body>
      //	<title>OG
      //	<h1>PM
      //	<h2>TS
      //	<h3>EFT-Entity Issues
      //	<p>
      //	<b>Issue:</b>  A problem is detected in the CR Client
      //	Book Devices, Institutions or Processors.
      //	The missing value along with the number of affected
      //	transactions is provided by the Operator Console.
      //	<p>
      //	<b>Resolution:</b>  The entity ID in the Missing Value
      //	(a device, institution or processor) has not yet been
      //	replicated to the DataNavigator Configuration Repository.
      //	<p>
      //	Obtain the latest copy of the configuration file (e.g.
      //	the CED file from eFunds Advantage) and reset the
      //	Configuration Interface (e.g. eFunds Advantage CED
      //	Interface) service.
      //	<p>
      //	The Devices, Institutions and Processors are in the
      //	EFT-Entity Tables in the CR Client for the DataNavigator
      //	Server.
      //	<p>
      //	When the configuration file replication is completed,
      //	reset the Problem Transaction Manager service.
      //	The Problem Transaction Manager service will update the
      //	affected transactions.
      //	</p>
      //	<h3>Parameter Issues
      //	<p>
      //	<b>Issue:</b>  A problem is detected in any other CR
      //	Client Book.
      //	Typical examples of these types of problems are new
      //	process codes or reason codes that are being logged by
      //	your EFT platform.
      //	These platform unique codes are converted to a
      //	normalized DataNavigator standard set of values (based
      //	on the ISO 8583 standard).
      //	The missing value along with the number of affected
      //	transactions is provided by the Operator Console.
      //	<p>
      //	<b>Resolution:</b>  The Missing Value must be manually
      //	entered in the CR Client Book.
      //	<p>
      //	Use the CR Client for the DataNavigator Server to add
      //	the required entry to the CR Client Book.
      //	The data related to problem transactiions are in the
      //	Parameter Tables folder in the CR Client for the Data
      //	Navigator Server.
      //	<p>
      //	You may have to contact the eFunds Support Center for
      //	assistance in determining the appropriate translation
      //	values.
      //	<p>
      //	After the changes are completed and rolled in, reset the
      //	Problem Transaction Manager service.
      //	The Problem Transaction Manager service will update the
      //	affected transactions.
      //	</p>
      //	</body>
      //## Postconditions:
      //	<body>
      //	<title>CG
      //	<h1>PM
      //	<h2>FO
      //	<h3>Transactions
      //	<p>
      //	Problems are repaired by updating the following tables:
      //	<ul>
      //	<li><i>custqual</i>.DEV_ADMIN_L<i>yyyymm</i>
      //	<li><i>custqual</i>.DEV_ADMIN
      //	<li><i>custqual</i>.FIN_L<i>yyyymm</i>
      //	<li><i>custqual</i>.FIN_RECORD<i>yyyymm</i>
      //	<li><i>custqual</i>.PROBLEM_TRAN
      //	</ul>
      //	</body>
      Problem::State repair (Problem& hProblem);

      //## Operation: update%391818FD03DD
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin ProblemSolver%391818D60142.public preserve=yes
      //## end ProblemSolver%391818D60142.public

  protected:
    // Additional Protected Declarations
      //## begin ProblemSolver%391818D60142.protected preserve=yes
      //## end ProblemSolver%391818D60142.protected

  private:
    // Additional Private Declarations
      //## begin ProblemSolver%391818D60142.private preserve=yes
      //## end ProblemSolver%391818D60142.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Status%3953682E03D0
      //## begin ProblemSolver::Status%3953682E03D0.attr preserve=no  private: enum Problem::State {U} Problem::PTM_UNKNOWN
      enum Problem::State m_iStatus;
      //## end ProblemSolver::Status%3953682E03D0.attr

      //## Attribute: Instance%393143CF02A5
      //## begin ProblemSolver::Instance%393143CF02A5.attr preserve=no  private: static ProblemSolver* {V} 0
      static ProblemSolver* m_pInstance;
      //## end ProblemSolver::Instance%393143CF02A5.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%39536161028C
      //## Role: ProblemSolver::<m_hEvidenceSegment>%3953616103E0
      //## begin ProblemSolver::<m_hEvidenceSegment>%3953616103E0.role preserve=no  public: configuration::EvidenceSegment { -> VHgN}
      configuration::EvidenceSegment m_hEvidenceSegment;
      //## end ProblemSolver::<m_hEvidenceSegment>%3953616103E0.role

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%39536E09017C
      //## Role: ProblemSolver::<m_hQuery>%39536E0A0033
      //## begin ProblemSolver::<m_hQuery>%39536E0A0033.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end ProblemSolver::<m_hQuery>%39536E0A0033.role

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%3EBC1421033C
      //## Role: ProblemSolver::<m_pProblemTranslation>%3EBC142202DE
      //## begin ProblemSolver::<m_pProblemTranslation>%3EBC142202DE.role preserve=no  public: ProblemTranslation { -> RFHgN}
      ProblemTranslation *m_pProblemTranslation;
      //## end ProblemSolver::<m_pProblemTranslation>%3EBC142202DE.role

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%3EBC1A7900DA
      //## Role: ProblemSolver::<m_pProblemVerification>%3EBC1A7A0167
      //## begin ProblemSolver::<m_pProblemVerification>%3EBC1A7A0167.role preserve=no  public: ProblemVerification { -> RFHgN}
      ProblemVerification *m_pProblemVerification;
      //## end ProblemSolver::<m_pProblemVerification>%3EBC1A7A0167.role

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%3EBC2053038A
      //## Role: ProblemSolver::<m_pProblemReimbursementFlag>%3EBC2054029F
      //## begin ProblemSolver::<m_pProblemReimbursementFlag>%3EBC2054029F.role preserve=no  public: ProblemReimbursementFlag { -> RFHgN}
      ProblemReimbursementFlag *m_pProblemReimbursementFlag;
      //## end ProblemSolver::<m_pProblemReimbursementFlag>%3EBC2054029F.role

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%3EBC20EA033C
      //## Role: ProblemSolver::<m_pProblemActionCode>%3EBC20EB0261
      //## begin ProblemSolver::<m_pProblemActionCode>%3EBC20EB0261.role preserve=no  public: ProblemActionCode { -> RFHgN}
      ProblemActionCode *m_pProblemActionCode;
      //## end ProblemSolver::<m_pProblemActionCode>%3EBC20EB0261.role

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%3EBC213903B9
      //## Role: ProblemSolver::<m_pProblemAcquirerChain>%3EBC213A037A
      //## begin ProblemSolver::<m_pProblemAcquirerChain>%3EBC213A037A.role preserve=no  public: ProblemAcquirerChain { -> RFHgN}
      ProblemAcquirerChain *m_pProblemAcquirerChain;
      //## end ProblemSolver::<m_pProblemAcquirerChain>%3EBC213A037A.role

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%3EBC21BF03A9
      //## Role: ProblemSolver::<m_pProblemIssuerAccountTypes>%3EBC21C00222
      //## begin ProblemSolver::<m_pProblemIssuerAccountTypes>%3EBC21C00222.role preserve=no  public: ProblemIssuerAccountTypes { -> RFHgN}
      ProblemIssuerAccountTypes *m_pProblemIssuerAccountTypes;
      //## end ProblemSolver::<m_pProblemIssuerAccountTypes>%3EBC21C00222.role

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%3EBC21C5007D
      //## Role: ProblemSolver::<m_pProblemIssuerChain>%3EBC21C6004E
      //## begin ProblemSolver::<m_pProblemIssuerChain>%3EBC21C6004E.role preserve=no  public: ProblemIssuerChain { -> RFHgN}
      ProblemIssuerChain *m_pProblemIssuerChain;
      //## end ProblemSolver::<m_pProblemIssuerChain>%3EBC21C6004E.role

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%4ACE1A890387
      //## Role: ProblemSolver::<m_pUnmatchedAuthorization>%4ACE1A8A03E5
      //## begin ProblemSolver::<m_pUnmatchedAuthorization>%4ACE1A8A03E5.role preserve=no  public: UnmatchedAuthorization { -> RFHgN}
      UnmatchedAuthorization *m_pUnmatchedAuthorization;
      //## end ProblemSolver::<m_pUnmatchedAuthorization>%4ACE1A8A03E5.role

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%4D76570901A2
      //## Role: ProblemSolver::<m_pProblemActionCodeTranslation>%4D76570A0105
      //## begin ProblemSolver::<m_pProblemActionCodeTranslation>%4D76570A0105.role preserve=no  public: ProblemActionCodeTranslation { -> RFHgN}
      ProblemActionCodeTranslation *m_pProblemActionCodeTranslation;
      //## end ProblemSolver::<m_pProblemActionCodeTranslation>%4D76570A0105.role

    // Additional Implementation Declarations
      //## begin ProblemSolver%391818D60142.implementation preserve=yes
      //## end ProblemSolver%391818D60142.implementation

};

//## begin ProblemSolver%391818D60142.postscript preserve=yes
//## end ProblemSolver%391818D60142.postscript

//## begin module%393142AA023F.epilog preserve=yes
//## end module%393142AA023F.epilog


#endif
