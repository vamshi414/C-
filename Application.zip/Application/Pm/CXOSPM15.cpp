//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4D74F596011C.cm preserve=no
//	$Date:   Mar 11 2011 10:42:58  $ $Author:   e1014059  $
//	$Revision:   1.1  $
//## end module%4D74F596011C.cm

//## begin module%4D74F596011C.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4D74F596011C.cp

//## Module: CXOSPM15%4D74F596011C; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM15.cpp

//## begin module%4D74F596011C.additionalIncludes preserve=no
//## end module%4D74F596011C.additionalIncludes

//## begin module%4D74F596011C.includes preserve=yes
//## end module%4D74F596011C.includes

#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSCF81_h
#include "CXODCF81.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSPM15_h
#include "CXODPM15.hpp"
#endif


//## begin module%4D74F596011C.declarations preserve=no
//## end module%4D74F596011C.declarations

//## begin module%4D74F596011C.additionalDeclarations preserve=yes
//## end module%4D74F596011C.additionalDeclarations


// Class ProblemActionCodeTranslation 

//## begin ProblemActionCodeTranslation::Instance%4D74F4550076.attr preserve=no  private: static ProblemActionCodeTranslation* {V} 0
ProblemActionCodeTranslation* ProblemActionCodeTranslation::m_pInstance = 0;
//## end ProblemActionCodeTranslation::Instance%4D74F4550076.attr

ProblemActionCodeTranslation::ProblemActionCodeTranslation()
  //## begin ProblemActionCodeTranslation::ProblemActionCodeTranslation%4D74F4550028_const.hasinit preserve=no
  //## end ProblemActionCodeTranslation::ProblemActionCodeTranslation%4D74F4550028_const.hasinit
  //## begin ProblemActionCodeTranslation::ProblemActionCodeTranslation%4D74F4550028_const.initialization preserve=yes
  //## end ProblemActionCodeTranslation::ProblemActionCodeTranslation%4D74F4550028_const.initialization
{
  //## begin ProblemActionCodeTranslation::ProblemActionCodeTranslation%4D74F4550028_const.body preserve=yes
   memcpy(m_sID,"PM15",4);
   m_strUseCase = "## AM18 ACTION CODE";
  //## end ProblemActionCodeTranslation::ProblemActionCodeTranslation%4D74F4550028_const.body
}


ProblemActionCodeTranslation::~ProblemActionCodeTranslation()
{
  //## begin ProblemActionCodeTranslation::~ProblemActionCodeTranslation%4D74F4550028_dest.body preserve=yes
  //## end ProblemActionCodeTranslation::~ProblemActionCodeTranslation%4D74F4550028_dest.body
}



//## Other Operations (implementation)
ProblemActionCodeTranslation* ProblemActionCodeTranslation::instance ()
{
  //## begin ProblemActionCodeTranslation::instance%4D74F4550077.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ProblemActionCodeTranslation();
   return m_pInstance;
  //## end ProblemActionCodeTranslation::instance%4D74F4550077.body
}

Problem::State ProblemActionCodeTranslation::repair (configuration::EvidenceSegment& hEvidenceSegment)
{
   //## begin ProblemActionCodeTranslation::repair%4D74F4550078.body preserve=yes
   string strTranslatedValue;
   if (ConfigurationRepository::instance()->translate(
      hEvidenceSegment.getSUSPECT_TABLE().c_str(),
      hEvidenceSegment.getSOURCE_VALUE(),strTranslatedValue,"","",0) == false)
   {
      return PTM_NOT_FIXED;
   }
   string strTable("FIN_RECORD");
#ifdef MVS
   string strValue;
   Extract::instance()->getSpec("MODEL",strValue);
   if (strValue == "OPEN")
#endif
      strTable.append(m_strTSTAMP_TRANS.data(),6);
   Table hTable(strTable.c_str());
   strTranslatedValue < "100" ? hTable.set("TRAN_DISPOSITION","1") : hTable.set("TRAN_DISPOSITION","2");
   hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int)m_iUNIQUENESS_KEY,true);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   string strSearchCondition(" AND TRAN_DISPOSITION = ''");
   bool bReturn = pUpdateStatement->execute(hTable,strSearchCondition);
   if (pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
      return PTM_NOT_FOUND;
   if (!bReturn)
      return PTM_SQL_ERROR;
   hTable.reset();
   hTable.setName("FIN_L" + m_strTSTAMP_TRANS.substr(0,6));
   hTable.set("ACT_CODE",strTranslatedValue);
   hTable.set("TSTAMP_TRANS",m_strTSTAMP_TRANS,false,true);
   hTable.set("UNIQUENESS_KEY",(int)m_iUNIQUENESS_KEY,true);
   if (pUpdateStatement->execute(hTable))
      return PTM_FIXED;
   return PTM_SQL_ERROR;
   //## end ProblemActionCodeTranslation::repair%4D74F4550078.body
}

// Additional Declarations
  //## begin ProblemActionCodeTranslation%4D74F4550028.declarations preserve=yes
  //## end ProblemActionCodeTranslation%4D74F4550028.declarations

//## begin module%4D74F596011C.epilog preserve=yes
//## end module%4D74F596011C.epilog
