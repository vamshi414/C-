//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4E035A4D02D6.cm preserve=no
//	$Date:   Dec 02 2016 11:50:50  $ $Author:   e1009839  $
//	$Revision:   1.3  $
//## end module%4E035A4D02D6.cm

//## begin module%4E035A4D02D6.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4E035A4D02D6.cp

//## Module: CXOSPM17%4E035A4D02D6; Package body
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXOSPM17.cpp

//## begin module%4E035A4D02D6.additionalIncludes preserve=no
//## end module%4E035A4D02D6.additionalIncludes

//## begin module%4E035A4D02D6.includes preserve=yes
//## end module%4E035A4D02D6.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSNS10_h
#include "CXODNS10.hpp"
#endif
#ifndef CXOSBC25_h
#include "CXODBC25.hpp"
#endif
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSPM17_h
#include "CXODPM17.hpp"
#endif


//## begin module%4E035A4D02D6.declarations preserve=no
//## end module%4E035A4D02D6.declarations

//## begin module%4E035A4D02D6.additionalDeclarations preserve=yes
//## end module%4E035A4D02D6.additionalDeclarations


// Class ProblemSummary 

ProblemSummary::ProblemSummary()
  //## begin ProblemSummary::ProblemSummary%4E0348320178_const.hasinit preserve=no
  //## end ProblemSummary::ProblemSummary%4E0348320178_const.hasinit
  //## begin ProblemSummary::ProblemSummary%4E0348320178_const.initialization preserve=yes
  //## end ProblemSummary::ProblemSummary%4E0348320178_const.initialization
{
  //## begin ProblemSummary::ProblemSummary%4E0348320178_const.body preserve=yes
  //## end ProblemSummary::ProblemSummary%4E0348320178_const.body
}


ProblemSummary::~ProblemSummary()
{
  //## begin ProblemSummary::~ProblemSummary%4E0348320178_dest.body preserve=yes
  //## end ProblemSummary::~ProblemSummary%4E0348320178_dest.body
}


ProblemSummary & ProblemSummary::operator=(const ProblemSummary &right)
{
  //## begin ProblemSummary::operator=%4E0348320178_assign.body preserve=yes
   if (right == *this)
      return *this;
   m_hProblemSummaryList.clear();
   vector<ProblemSummarySegment>::const_iterator pList ;
   for(pList = right.m_hProblemSummaryList.begin();
      pList != right.m_hProblemSummaryList.end();pList++)
   {
      m_hProblemSummaryList.push_back(*pList);
   }
   return *this;
  //## end ProblemSummary::operator=%4E0348320178_assign.body
}


bool ProblemSummary::operator==(const ProblemSummary &right) const
{
  //## begin ProblemSummary::operator==%4E0348320178_eq.body preserve=yes
   if (m_hProblemSummaryList.size() != right.m_hProblemSummaryList.size())
      return false;
   
   for(int i = 0 ;i <  right.m_hProblemSummaryList.size();i++)
   {
      if(m_hProblemSummaryList[i] != right.m_hProblemSummaryList[i])
         return false;
   }
   return true;
  //## end ProblemSummary::operator==%4E0348320178_eq.body
}

bool ProblemSummary::operator!=(const ProblemSummary &right) const
{
  //## begin ProblemSummary::operator!=%4E0348320178_neq.body preserve=yes
   return !(ProblemSummary::operator==(right));
  //## end ProblemSummary::operator!=%4E0348320178_neq.body
}



//## Other Operations (implementation)
void ProblemSummary::clear ()
{
  //## begin ProblemSummary::clear%4E81DF3B016A.body preserve=yes
   m_hProblemSummaryList.erase(m_hProblemSummaryList.begin(),m_hProblemSummaryList.end());
  //## end ProblemSummary::clear%4E81DF3B016A.body
}

void ProblemSummary::email ()
{
  //## begin ProblemSummary::email%4E0359D402CE.body preserve=yes
   Query hQuery;
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   ContactSegment::instance(ContactSegment::SENDER)->bind(hQuery);
   hQuery.setQualifier("QUALIFY","CONTACT_TYPE");
   hQuery.setQualifier("QUALIFY","STS_CUSTOMER");
   hQuery.join("CONTACT_TYPE","INNER","STS_CUSTOMER","CONTACT_ID");
   hQuery.setBasicPredicate("STS_CUSTOMER","CUST_ID","=",strCustomerID.c_str());
   hQuery.setBasicPredicate("STS_CUSTOMER","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("STS_CUSTOMER","CC_STATE","=","A");
   hQuery.setBasicPredicate("CONTACT_TYPE","CONTACT_TYPE","=","DBA");
   if (pSelectStatement->execute(hQuery) == false || pSelectStatement->getRows() == 0)
   {
      return ;
   }
   if (ContactSegment::instance(ContactSegment::SENDER)->getCONTACT_METHOD() == (const char*)"E")
   {
      string strTimeStamp = Clock::instance()->getYYYYMMDDHHMMSS(false);
      command::Email hEmail("NONE","CU",strCustomerID,strTimeStamp.substr(0,8),strTimeStamp.substr(8),"CXOEPM17") ;
      EmailSegment::instance()->reset();
      EmailSegment::instance()->setENTITY_ID(strCustomerID);
      string strValue;
      Extract::instance()->getSpec("PROC",strValue);
      EmailSegment::instance()->setServer(strValue);
      hEmail.add('C',ContactSegment::instance(ContactSegment::SENDER));
      hEmail.add('D',&m_hProblemSummarySegment);
      hEmail.add('Z',EmailSegment::instance());
      hEmail.report('C');
      hEmail.report('H');
      for(int i = 0; i < m_hProblemSummaryList.size();i++)
      {
         m_hProblemSummarySegment = m_hProblemSummaryList[i];
         hEmail.report('D');
      }
      hEmail.report('T');
      hEmail.complete();
   }
  //## end ProblemSummary::email%4E0359D402CE.body
}

bool ProblemSummary::isEmpty ()
{
  //## begin ProblemSummary::isEmpty%4E12E1EC030F.body preserve=yes
   return (m_hProblemSummaryList.size() == 0) ;
  //## end ProblemSummary::isEmpty%4E12E1EC030F.body
}

bool ProblemSummary::retrieve ()
{
  //## begin ProblemSummary::retrieve%4E0359CB037A.body preserve=yes
   m_hQuery.attach(this);
   m_hQuery.reset();
   m_hProblemSummaryList.erase(m_hProblemSummaryList.begin(),m_hProblemSummaryList.end());
   m_hProblemSummarySegment.bind(m_hQuery);
      auto_ptr<reusable::SelectStatement> pSelectStatement
         ((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
      return (pSelectStatement->execute(m_hQuery) && pSelectStatement->getRows() > 0);
  //## end ProblemSummary::retrieve%4E0359CB037A.body
}

void ProblemSummary::update (Subject* pSubject)
{
  //## begin ProblemSummary::update%4E0454190103.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      m_hProblemSummarySegment.setDescription();
      m_hProblemSummaryList.push_back(m_hProblemSummarySegment);
   }
  //## end ProblemSummary::update%4E0454190103.body
}

// Additional Declarations
  //## begin ProblemSummary%4E0348320178.declarations preserve=yes
  //## end ProblemSummary%4E0348320178.declarations

//## begin module%4E035A4D02D6.epilog preserve=yes
//## end module%4E035A4D02D6.epilog
