//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4C7FE6ED01BA.cm preserve=no
//	$Date:   Sep 14 2010 15:26:48  $ $Author:   E1024360  $
//	$Revision:   1.1  $
//## end module%4C7FE6ED01BA.cm

//## begin module%4C7FE6ED01BA.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%4C7FE6ED01BA.cp

//## Module: CXOSPM13%4C7FE6ED01BA; Package specification
//## Subsystem: PM%391C2CD80124
//## Source file: C:\Devel\Dn\Server\Application\PM\CXODPM13.hpp

#ifndef CXOSPM13_h
#define CXOSPM13_h 1

//## begin module%4C7FE6ED01BA.additionalIncludes preserve=no
//## end module%4C7FE6ED01BA.additionalIncludes

//## begin module%4C7FE6ED01BA.includes preserve=yes
//## end module%4C7FE6ED01BA.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

class Problem;
class ProblemSolver;
//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Timer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%4C7FE6ED01BA.declarations preserve=no
//## end module%4C7FE6ED01BA.declarations

//## begin module%4C7FE6ED01BA.additionalDeclarations preserve=yes
//## end module%4C7FE6ED01BA.additionalDeclarations


//## begin AuthorizationMediator%4C7FE69F00A1.preface preserve=yes
//## end AuthorizationMediator%4C7FE69F00A1.preface

//## Class: AuthorizationMediator%4C7FE69F00A1
//## Category: DataNavigator Foundation::Application::ProblemTransactionManager_CAT%391812080197
//## Subsystem: PM%391C2CD80124
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4C8112EC027D;IF::Extract { -> F}
//## Uses: <unnamed>%4C81137103E6;IF::Trace { -> F}
//## Uses: <unnamed>%4C8113FD029E;monitor::UseCase { -> F}
//## Uses: <unnamed>%4C81146B032B;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4C8114770156;database::Database { -> F}
//## Uses: <unnamed>%4C8114BC0117;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4C811AC000D7;ProblemSolver { -> F}
//## Uses: <unnamed>%4C8E8E2200FD;reusable::Query { -> F}

class DllExport AuthorizationMediator : public reusable::Observer  //## Inherits: <unnamed>%4C7FE965037F
{
  //## begin AuthorizationMediator%4C7FE69F00A1.initialDeclarations preserve=yes
  //## end AuthorizationMediator%4C7FE69F00A1.initialDeclarations

  public:
    //## Constructors (generated)
      AuthorizationMediator();

    //## Destructor (generated)
      virtual ~AuthorizationMediator();


    //## Other Operations (specified)
      //## Operation: instance%4C87F86800E2
      static AuthorizationMediator* instance ();

      //## Operation: retrieve%4C7FEA0301AA
      void retrieve ();

      //## Operation: update%4C7FEA14012D
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin AuthorizationMediator%4C7FE69F00A1.public preserve=yes
      //## end AuthorizationMediator%4C7FE69F00A1.public

  protected:
    // Additional Protected Declarations
      //## begin AuthorizationMediator%4C7FE69F00A1.protected preserve=yes
      //## end AuthorizationMediator%4C7FE69F00A1.protected

  private:
    // Additional Private Declarations
      //## begin AuthorizationMediator%4C7FE69F00A1.private preserve=yes
      //## end AuthorizationMediator%4C7FE69F00A1.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%4C87F82E003E
      //## begin AuthorizationMediator::Instance%4C87F82E003E.attr preserve=no  private: static AuthorizationMediator* {V} 0
      static AuthorizationMediator* m_pInstance;
      //## end AuthorizationMediator::Instance%4C87F82E003E.attr

      //## Attribute: Problem%4C811A550137
      //## begin AuthorizationMediator::Problem%4C811A550137.attr preserve=no  private: Problem {U} 
      Problem m_hProblem;
      //## end AuthorizationMediator::Problem%4C811A550137.attr

      //## Attribute: TimerValue%4C7FE99500C0
      //## begin AuthorizationMediator::TimerValue%4C7FE99500C0.attr preserve=no  private: int {U} 1800
      int m_iTimerValue;
      //## end AuthorizationMediator::TimerValue%4C7FE99500C0.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%4C81131E03E5
      //## Role: AuthorizationMediator::<m_hTimer>%4C81131F03D6
      //## begin AuthorizationMediator::<m_hTimer>%4C81131F03D6.role preserve=no  public: timer::Timer { -> VFHgN}
      timer::Timer m_hTimer;
      //## end AuthorizationMediator::<m_hTimer>%4C81131F03D6.role

      //## Association: DataNavigator Foundation::Application::ProblemTransactionManager_CAT::<unnamed>%4C811A160270
      //## Role: AuthorizationMediator::<m_hProblems>%4C811A170176
      //## begin AuthorizationMediator::<m_hProblems>%4C811A170176.role preserve=no  public: Problem {1 -> 0..nVFHgN}
      vector<Problem> m_hProblems;
      //## end AuthorizationMediator::<m_hProblems>%4C811A170176.role

    // Additional Implementation Declarations
      //## begin AuthorizationMediator%4C7FE69F00A1.implementation preserve=yes
      //## end AuthorizationMediator%4C7FE69F00A1.implementation

};

//## begin AuthorizationMediator%4C7FE69F00A1.postscript preserve=yes
//## end AuthorizationMediator%4C7FE69F00A1.postscript

//## begin module%4C7FE6ED01BA.epilog preserve=yes
//## end module%4C7FE6ED01BA.epilog


#endif
