//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36EFE06600DC.cm preserve=no
//	$Date:   Dec 13 2011 09:33:06  $ $Author:   e1009839  $
//	$Revision:   1.9  $
//## end module%36EFE06600DC.cm

//## begin module%36EFE06600DC.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%36EFE06600DC.cp

//## Module: CXOPQM00%36EFE06600DC; Package specification
//## Subsystem: QM%36EFE03B0351
//## Source file: C:\Devel\Dn\Server\Application\Qm\CXODQM00.hpp

#ifndef CXOPQM00_h
#define CXOPQM00_h 1

//## begin module%36EFE06600DC.additionalIncludes preserve=no
//## end module%36EFE06600DC.additionalIncludes

//## begin module%36EFE06600DC.includes preserve=yes
// $Date:   Dec 13 2011 09:33:06  $ $Author:   e1009839  $ $Revision:   1.9  $
//## end module%36EFE06600DC.includes

#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Continuous Feed::MQSeries_CAT%36C82B100167
namespace mqseries {
class MqQueueFactory;
class MqQueue;
class MqQueueManager;
} // namespace mqseries

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Log;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Signal;
} // namespace reusable

namespace IF {
class Queue;
class Message;
class Console;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%36EFE06600DC.declarations preserve=no
//## end module%36EFE06600DC.declarations

//## begin module%36EFE06600DC.additionalDeclarations preserve=yes
//## end module%36EFE06600DC.additionalDeclarations


//## begin MqMonitor%36EFDFE0018E.preface preserve=yes
//## end MqMonitor%36EFDFE0018E.preface

//## Class: MqMonitor%36EFDFE0018E
//	<body>
//	<title>CG
//	<h1>QM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Queue Monitor service reads the IBM WebSphere MQ
//	system queues.
//	System alerts are displayed on the Operator Console.
//	<p>
//	The Queue Monitor service reads the following system
//	queues:
//	<ul>
//	<li>Channel
//	<li>Dead
//	<li>Event
//	<li>Performance
//	</ul>
//	</p>
//	<img src=CXOCQM00.gif>
//	<title>OG
//	<h1>QM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Queue Monitor service reads the IBM WebSphere MQ
//	system queues.
//	System alerts are displayed on the Operator Console.
//	<p>
//	The Queue Monitor service reads the following system
//	queues:
//	<ul>
//	<li>Channel
//	<li>Dead
//	<li>Event
//	<li>Performance
//	</ul>
//	<p>
//	<img src=CXOOQM00.gif>
//	</body>
//## Category: Continuous Feed::MqMonitor_CAT%36EFDF470365
//## Subsystem: QM%36EFE03B0351
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..1



//## Uses: <unnamed>%36EFE46503E0;mqseries::MqQueueFactory { -> F}
//## Uses: <unnamed>%36F0EE2F025B;IF::Message { -> F}
//## Uses: <unnamed>%36F101C20206;IF::Console { -> F}
//## Uses: <unnamed>%36F111F802F4;mqseries::MqQueueManager { -> F}
//## Uses: <unnamed>%36F112B90265;mqseries::MqQueue { -> F}
//## Uses: <unnamed>%36F25E22031C;IF::Log { -> F}
//## Uses: <unnamed>%37581511031D;IF::Trace { -> F}
//## Uses: <unnamed>%3FB442350225;database::Database { -> F}
//## Uses: <unnamed>%3FB442500396;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%40A4D73901E4;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%48C908320210;monitor::UseCase { -> F}

class MqMonitor : public process::Application  //## Inherits: <unnamed>%36EFDFFA0254
{
  //## begin MqMonitor%36EFDFE0018E.initialDeclarations preserve=yes
  //## end MqMonitor%36EFDFE0018E.initialDeclarations

  public:
    //## Constructors (generated)
      MqMonitor();

    //## Destructor (generated)
      virtual ~MqMonitor();


    //## Other Operations (specified)
      //## Operation: initialize%36EFE0C200E9
      virtual int initialize ();

      //## Operation: onQuiesce%3FCD58710026
      //	Responds to the quiesce request from FaultManager to
      //	indicate that the Application has quiesced.
      virtual int onQuiesce ();

      //## Operation: update%3FDD01ED0157
      //	Interprets the inbound Message and calls:
      //
      //	   Application::onConfirm
      //	   Application::onMessage
      //	   Application::onNotify
      //	   Application::onQuiesce
      //	   Application::onRefresh
      //	   Application::onReset
      //	   Application::shutdown
      //	   Timer::elapsed
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin MqMonitor%36EFDFE0018E.public preserve=yes
      //## end MqMonitor%36EFDFE0018E.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%36EFE0C60239
      //## Postconditions:
      //	<body>
      //	<title>OG
      //	<h1>QM
      //	<h2>TS
      //	<h3>Channel Started
      //	<p>
      //	Issue: Console reports ST018: WEBSPHERE MQ EVENT
      //	DETECTED: CHANNEL STARTED
      //	<p>
      //	Resolution: Verify the status of the feed from the EFT
      //	platform.
      //	<h3>Channel Stopped
      //	<p>
      //	Issue: Console reports ST018: WEBSPHERE MQ EVENT
      //	DETECTED: CHANNEL STOPPED
      //	<p>
      //	Resolution: Verify the status of the feed from the EFT
      //	platform.
      //	<h3>Queue Depth High
      //	<p>
      //	Issue: Console reports ST018: WEBSPHERE MQ EVENT
      //	DETECTED: QUEUE DEPTH HIGH
      //	<p>
      //	Resolution: The queue depth on the DataNavigator Server
      //	side is high.
      //	Determine why DataNavigator is slow in retrieving
      //	messages from the queue.
      //	This implies a problem with either the Queue Reader
      //	service (and/or Webshpere MQ itself) or the Load Engine
      //	services (and/or the database itself).
      //	<h3>Queue Manager Active
      //	<p>
      //	Issue: Console reports ST018: WEBSPHERE MQ EVENT
      //	DETECTED: QUEUE FULL
      //	<p>
      //	Resolution: The queue on the DataNavigator Server side
      //	is now full and messages will be queued on the acquiring
      //	platform.
      //	Determine why DataNavigator is unable to retrieve
      //	messages from the queue.
      //	This implies a problem with either the Queue Reader
      //	service (and/or Webshpere MQ itself) or the Load Engine
      //	services (and/or the database itself).
      //	<h3>Channel Started
      //	<p>
      //	Issue: Console reports ST018: WEBSPHERE MQ EVENT
      //	DETECTED: QUEUE MANAGER ACTIVE
      //	<p>
      //	Resolution: Verify the status of the feed from the EFT
      //	platform.
      //	<h3>Other Webshpere MQ Errors
      //	<p>
      //	Issue: Console reports ST018: WEBSPHERE MQ EVENT
      //	DETECTED: <i>c rrrr</i>
      //	<p>
      //	Resolution: Some other error has occurred in Websphere
      //	MQ.
      //	This error can be researched in the IBM Websphere MQ
      //	documentation.
      //	<h3>Messages on the Dead Letter Queue
      //	<p>
      //	Issue: Console reports ST025: MESSAGE(S) ON THE DEAD
      //	LETTER QUEUE
      //	<p>
      //	Resolution: Verify the status of the feed from the EFT
      //	platform.
      //	</body>
      virtual int onMessage (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin MqMonitor%36EFDFE0018E.protected preserve=yes
      //## end MqMonitor%36EFDFE0018E.protected

  private:
    // Additional Private Declarations
      //## begin MqMonitor%36EFDFE0018E.private preserve=yes
      //## end MqMonitor%36EFDFE0018E.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Continuous Feed::MqMonitor_CAT::<unnamed>%36EFE60300BB
      //## Role: MqMonitor::<m_pEventQueue>%36EFE603033B
      //## begin MqMonitor::<m_pEventQueue>%36EFE603033B.role preserve=no  public: IF::Queue {1 -> 4RFHgN}
      IF::Queue *m_pEventQueue[4];
      //## end MqMonitor::<m_pEventQueue>%36EFE603033B.role

      //## Association: Continuous Feed::MqMonitor_CAT::<unnamed>%36EFE63000AB
      //## Role: MqMonitor::<m_pEventSignal>%36EFE63002BE
      //## begin MqMonitor::<m_pEventSignal>%36EFE63002BE.role preserve=no  public: reusable::Signal {1 -> 4RFHgN}
      reusable::Signal *m_pEventSignal[4];
      //## end MqMonitor::<m_pEventSignal>%36EFE63002BE.role

      //## Association: Continuous Feed::MqMonitor_CAT::<unnamed>%3757FF4A02DB
      //## Role: MqMonitor::<m_hRetryTimer>%3757FF4B003E
      //## begin MqMonitor::<m_hRetryTimer>%3757FF4B003E.role preserve=no  public: timer::Timer { -> VHgN}
      timer::Timer m_hRetryTimer;
      //## end MqMonitor::<m_hRetryTimer>%3757FF4B003E.role

    // Additional Implementation Declarations
      //## begin MqMonitor%36EFDFE0018E.implementation preserve=yes
      //## end MqMonitor%36EFDFE0018E.implementation

};

//## begin MqMonitor%36EFDFE0018E.postscript preserve=yes
//## end MqMonitor%36EFDFE0018E.postscript

//## begin module%36EFE06600DC.epilog preserve=yes
//## end module%36EFE06600DC.epilog


#endif
