//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36EFE067039B.cm preserve=no
//	$Date:   May 20 2020 18:05:58  $ $Author:   e1009510  $
//	$Revision:   1.22  $
//## end module%36EFE067039B.cm

//## begin module%36EFE067039B.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%36EFE067039B.cp

//## Module: CXOPQM00%36EFE067039B; Package body
//## Subsystem: QM%36EFE03B0351
//## Source file: C:\Devel\Dn\Server\Application\Qm\CXOPQM00.cpp

//## begin module%36EFE067039B.additionalIncludes preserve=no
//## end module%36EFE067039B.additionalIncludes

//## begin module%36EFE067039B.includes preserve=yes
// $Date:   May 20 2020 18:05:58  $ $Author:   e1009510  $ $Revision:   1.22  $
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif

#include <stdio.h>
#include "CXODRU24.hpp"
#include "CXODIF11.hpp"
#include <cmqc.h>
#include <cmqcfc.h>
//## end module%36EFE067039B.includes

#ifndef CXOSMQ04_h
#include "CXODMQ04.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSMQ01_h
#include "CXODMQ01.hpp"
#endif
#ifndef CXOSMQ02_h
#include "CXODMQ02.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOPQM00_h
#include "CXODQM00.hpp"
#endif


//## begin module%36EFE067039B.declarations preserve=no
//## end module%36EFE067039B.declarations

//## begin module%36EFE067039B.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new MqMonitor();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%36EFE067039B.additionalDeclarations


// Class MqMonitor 

MqMonitor::MqMonitor()
  //## begin MqMonitor::MqMonitor%36EFDFE0018E_const.hasinit preserve=no
  //## end MqMonitor::MqMonitor%36EFDFE0018E_const.hasinit
  //## begin MqMonitor::MqMonitor%36EFDFE0018E_const.initialization preserve=yes
  //## end MqMonitor::MqMonitor%36EFDFE0018E_const.initialization
{
  //## begin MqMonitor::MqMonitor%36EFDFE0018E_const.body preserve=yes
   memcpy(m_sID,"QM00",4);
   for (int i = 0;i < 4;++i)
   {
      m_pEventSignal[i] = 0;
      m_pEventQueue[i] = 0;
   }
  //## end MqMonitor::MqMonitor%36EFDFE0018E_const.body
}


MqMonitor::~MqMonitor()
{
  //## begin MqMonitor::~MqMonitor%36EFDFE0018E_dest.body preserve=yes
   for (int i = 0;i < 4;++i)
   {
      delete m_pEventSignal[i];
      delete m_pEventQueue[i];
   }
  //## end MqMonitor::~MqMonitor%36EFDFE0018E_dest.body
}



//## Other Operations (implementation)
int MqMonitor::initialize ()
{
  //## begin MqMonitor::initialize%36EFE0C200E9.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("LOG","## LG02 START QM");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   new MqQueueFactory();
   char* pszEvent[4] = {"QMGR","PERFM","CHANNEL","DEAD"};
   for (int i = 0;i < 4;++i)
   {
      m_pEventSignal[i] = new Signal(pszEvent[i]);
      m_pEventQueue[i] = new MqQueue(pszEvent[i]);
      m_pEventQueue[i]->setSignal(m_pEventSignal[i]);
      m_pEventSignal[i]->attach(m_pEventQueue[i]);
      enable(m_pEventSignal[i]);
      MqQueueManager::instance(((MqQueue*)m_pEventQueue[i])->getQueueManager())->attach(this);
      m_pEventQueue[i]->open();
   }
#ifndef MVS
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->connect();
#endif
   return 0;
  //## end MqMonitor::initialize%36EFE0C200E9.body
}

int MqMonitor::onMessage (IF::Message& hMessage)
{
  //## begin MqMonitor::onMessage%36EFE0C60239.body preserve=yes
   if (hMessage.getDestination() == "DEAD")
   {
      Console::display("ST025");
      MqQueueManager::instance(((MqQueue*)m_pEventQueue[3])->getQueueManager())->rollback();
      Application::instance()->enable(m_pEventSignal[3],false);
      m_hRetryTimer.set("00150000");
      return 0;
   }
   char psText[60];
   tagMQCFH* p = (tagMQCFH*)hMessage.buffer();
   switch (p->Reason)
   {
      case MQRC_CHANNEL_STARTED:
         Console::display("ST018","CHANNEL STARTED");
         break;
      case MQRC_CHANNEL_STOPPED:
         Console::display("ST018","CHANNEL STOPPED");
         break;
      case MQRC_Q_DEPTH_HIGH:
         Console::display("ST018","QUEUE DEPTH HIGH");
         break;
      case MQRC_Q_FULL:
         Console::display("ST018","QUEUE FULL");
         break;
      case MQRC_Q_MGR_ACTIVE:
         Console::display("ST018","QUEUE MANAGER ACTIVE");
         break;
      default:
         snprintf(psText,sizeof(psText),"%01ld %04ld",p->CompCode,p->Reason);
         Console::display("ST018",psText);
   }
   int m;
   tagMQCFIN* pMQCFIN;
   tagMQCFIL* pMQCFIL;
   tagMQCFST* pMQCFST;
   tagMQCFSL* pMQCFSL;
   MQLONG* pType = (MQLONG*)((char*)p + p->StrucLength);
   for (int i = 0;i < p->ParameterCount;++i)
   {
      switch (*pType)
      {
         case MQCFT_INTEGER:
            pMQCFIN = (tagMQCFIN*)pType;
            snprintf(psText,sizeof(psText),"%ld %ld",
               pMQCFIN->Parameter,pMQCFIN->Value);
            pType = (MQLONG*)((char*)pMQCFIN + pMQCFIN->StrucLength);
            break;
         case MQCFT_STRING:
            pMQCFST = (tagMQCFST*)pType;
            snprintf(psText,sizeof(psText),"%04ld ",pMQCFST->Parameter);
            m = pMQCFST->StringLength;
            if (m > 51)
               m = 51;
            memcpy(psText + 5,&pMQCFST->String,m);
            psText[m] = '\0';
            pType = (MQLONG*)((char*)pMQCFST + pMQCFST->StrucLength);
            break;
         case MQCFT_INTEGER_LIST:
            pMQCFIL = (tagMQCFIL*)pType;
            snprintf(psText,sizeof(psText),"%04ld",pMQCFIL->Parameter);
            pType = (MQLONG*)((char*)pMQCFIL + pMQCFIL->StrucLength);
            break;
         case MQCFT_STRING_LIST:
            pMQCFSL = (tagMQCFSL*)pType;
            snprintf(psText,sizeof(psText),"%04ld",pMQCFSL->Parameter);
            pType = (MQLONG*)((char*)pMQCFSL + pMQCFSL->StrucLength);
            break;
      }
      Console::display("ST019",psText);
   }
   MqQueueManager::instance(((MqQueue*)m_pEventQueue[0])->getQueueManager())->commit();
   return 0;
  //## end MqMonitor::onMessage%36EFE0C60239.body
}

int MqMonitor::onQuiesce ()
{
  //## begin MqMonitor::onQuiesce%3FCD58710026.body preserve=yes
#ifndef MVS
   for (int i = 0;i < 4;++i)
      ((MqQueue*)m_pEventQueue[i])->onQuiesce();
#endif
   Application::onQuiesce();
   return 0;
  //## end MqMonitor::onQuiesce%3FCD58710026.body
}

void MqMonitor::update (Subject* pSubject)
{
  //## begin MqMonitor::update%3FDD01ED0157.body preserve=yes
   if (pSubject == &m_hRetryTimer)
   {
      Application::instance()->enable(m_pEventSignal[3]);
      return;
   }
   else
   if (pSubject == MqQueueManager::instance(((MqQueue*)m_pEventQueue[0])->getQueueManager()))
   {
      if (MqQueueManager::instance(((MqQueue*)m_pEventQueue[0])->getQueueManager())->getState() == MqQueueManager::DISCONNECTED)
      {
         m_hRetryTimer.cancel();
         Application::instance()->enable(m_pEventSignal[0],false);
      }
      else
         Application::instance()->enable(m_pEventSignal[0]);
      return;
   }
   else
   if (pSubject == MqQueueManager::instance(((MqQueue*)m_pEventQueue[1])->getQueueManager()))
   {
      if (MqQueueManager::instance(((MqQueue*)m_pEventQueue[1])->getQueueManager())->getState() == MqQueueManager::DISCONNECTED)
      {
         m_hRetryTimer.cancel();
         Application::instance()->enable(m_pEventSignal[1],false);
      }
      else
         Application::instance()->enable(m_pEventSignal[1]);
      return;
   }
   else
   if (pSubject == MqQueueManager::instance(((MqQueue*)m_pEventQueue[2])->getQueueManager()))
   {
      if (MqQueueManager::instance(((MqQueue*)m_pEventQueue[2])->getQueueManager())->getState() == MqQueueManager::DISCONNECTED)
      {
         m_hRetryTimer.cancel();
         Application::instance()->enable(m_pEventSignal[2],false);
      }
      else
         Application::instance()->enable(m_pEventSignal[2]);
      return;
   }
   else
   if (pSubject == MqQueueManager::instance(((MqQueue*)m_pEventQueue[3])->getQueueManager()))
   {
      if (MqQueueManager::instance(((MqQueue*)m_pEventQueue[3])->getQueueManager())->getState() == MqQueueManager::DISCONNECTED)
      {
         m_hRetryTimer.cancel();
         Application::instance()->enable(m_pEventSignal[3],false);
      }
      else
         Application::instance()->enable(m_pEventSignal[3]);
      return;
   }
   Application::update(pSubject);
  //## end MqMonitor::update%3FDD01ED0157.body
}

// Additional Declarations
  //## begin MqMonitor%36EFDFE0018E.declarations preserve=yes
  //## end MqMonitor%36EFDFE0018E.declarations

//## begin module%36EFE067039B.epilog preserve=yes
//## end module%36EFE067039B.epilog
