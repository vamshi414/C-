//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%515498920076.cm preserve=no
//	$Date:   Mar 14 2014 07:30:58  $ $Author:   e1009839  $ $Revision:   1.0  $
//## end module%515498920076.cm

//## begin module%515498920076.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%515498920076.cp

//## Module: CXOPMR00%515498920076; Package specification
//## Subsystem: MR%5154986F000E
//## Source file: C:\bV02.4B.R001\Build\ConnexPlatform\Server\Application\Mr\CXODMR00.hpp

#ifndef CXOPMR00_h
#define CXOPMR00_h 1

//## begin module%515498920076.additionalIncludes preserve=no
//## end module%515498920076.additionalIncludes

//## begin module%515498920076.includes preserve=yes
//## end module%515498920076.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace IF {
class SocketQueue;
class Sleep;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;

} // namespace platform

//## begin module%515498920076.declarations preserve=no
//## end module%515498920076.declarations

//## begin module%515498920076.additionalDeclarations preserve=yes
//## end module%515498920076.additionalDeclarations


//## begin MailRelay%515497CC0035.preface preserve=yes
//## end MailRelay%515497CC0035.preface

//## Class: MailRelay%515497CC0035
//## Category: Connex Application::MailRelay_CAT%515497A50120
//## Subsystem: MR%5154986F000E
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5154D84B03A2;platform::Platform { -> F}
//## Uses: <unnamed>%5154D8AA01FA;monitor::UseCase { -> F}
//## Uses: <unnamed>%5154D930020A;database::Database { -> F}
//## Uses: <unnamed>%5154DB3002CB;IF::Message { -> F}
//## Uses: <unnamed>%5154EB2B023C;IF::SocketQueue { -> F}
//## Uses: <unnamed>%53050DD500AD;IF::Sleep { -> F}

class DllExport MailRelay : public process::Application  //## Inherits: <unnamed>%515497F100CE
{
  //## begin MailRelay%515497CC0035.initialDeclarations preserve=yes
  //## end MailRelay%515497CC0035.initialDeclarations

  public:
    //## Constructors (generated)
      MailRelay();

    //## Destructor (generated)
      virtual ~MailRelay();


    //## Other Operations (specified)
      //## Operation: initialize%515497FE03B4
      virtual int initialize ();

    // Additional Public Declarations
      //## begin MailRelay%515497CC0035.public preserve=yes
      //## end MailRelay%515497CC0035.public

  protected:

    //## Other Operations (specified)
      //## Operation: onConnect%5159A350036A
      virtual int onConnect (Message& hMessage);

      //## Operation: onMessage%515498010103
      virtual int onMessage (Message& hMessage);

    // Additional Protected Declarations
      //## begin MailRelay%515497CC0035.protected preserve=yes
      //## end MailRelay%515497CC0035.protected

  private:

    //## Other Operations (specified)
      //## Operation: getThreadId%530508A802ED
      int getThreadId (IF::Message& hMessage);

    // Additional Private Declarations
      //## begin MailRelay%515497CC0035.private preserve=yes
      //## end MailRelay%515497CC0035.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Response%515ADDDC0332
      //## begin MailRelay::Response%515ADDDC0332.attr preserve=no  private: string {V} 
      string m_strResponse;
      //## end MailRelay::Response%515ADDDC0332.attr

    // Additional Implementation Declarations
      //## begin MailRelay%515497CC0035.implementation preserve=yes
      //## end MailRelay%515497CC0035.implementation

};

//## begin MailRelay%515497CC0035.postscript preserve=yes
//## end MailRelay%515497CC0035.postscript

//## begin module%515498920076.epilog preserve=yes
//## end module%515498920076.epilog


#endif
