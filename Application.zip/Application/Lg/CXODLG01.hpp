//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3FA0B7FE00B6.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3FA0B7FE00B6.cm

//## begin module%3FA0B7FE00B6.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3FA0B7FE00B6.cp

//## Module: CXOSLG01%3FA0B7FE00B6; Package specification
//## Subsystem: LG%3E97204A009C
//## Source file: C:\Devel\ConnexPlatform\Server\Application\Lg\CXODLG01.hpp

#ifndef CXOSLG01_h
#define CXOSLG01_h 1

//## begin module%3FA0B7FE00B6.additionalIncludes preserve=no
//## end module%3FA0B7FE00B6.additionalIncludes

//## begin module%3FA0B7FE00B6.includes preserve=yes
// $Date:   Jun 30 2006 11:21:56  $ $Author:   D02405  $ $Revision:   1.2  $
//## end module%3FA0B7FE00B6.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Queue;
class Message;
class FlatFile;
class VariableBlockFile;
class Console;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%3FA0B7FE00B6.declarations preserve=no
//## end module%3FA0B7FE00B6.declarations

//## begin module%3FA0B7FE00B6.additionalDeclarations preserve=yes
//## end module%3FA0B7FE00B6.additionalDeclarations


//## begin Logfile%3FA0B19B010F.preface preserve=yes
//## end Logfile%3FA0B19B010F.preface

//## Class: Logfile%3FA0B19B010F
//## Category: Connex Application::Logger_CAT%3E972028034B
//## Subsystem: LG%3E97204A009C
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3FA0B2DF02EC;IF::Message { -> F}
//## Uses: <unnamed>%3FA0B2E201C4;IF::Trace { -> F}
//## Uses: <unnamed>%3FA0B2E40299;monitor::UseCase { -> F}
//## Uses: <unnamed>%3FA0B3560347;IF::Queue { -> F}
//## Uses: <unnamed>%3FA0B35A02F3;IF::Console { -> F}
//## Uses: <unnamed>%3FA0C276013C;process::Application { -> F}
//## Uses: <unnamed>%3FBBF3DD02D6;IF::VariableBlockFile { -> F}
//## Uses: <unnamed>%3FBBF533030A;IF::FlatFile { -> F}

class DllExport Logfile : public reusable::Object  //## Inherits: <unnamed>%3FA0B23600F4
{
  //## begin Logfile%3FA0B19B010F.initialDeclarations preserve=yes
  //## end Logfile%3FA0B19B010F.initialDeclarations

  public:
    //## Constructors (generated)
      Logfile();

    //## Destructor (generated)
      virtual ~Logfile();


    //## Other Operations (specified)
      //## Operation: close%3FA0B9720378
      bool close ();

      //## Operation: open%3FA0B96601D6
      bool open ();

      //## Operation: swap%3FA0B98B0374
      bool swap ();

      //## Operation: write%3FA0B51801FA
      //	Writes the data from the message to the logfile.
      bool write (IF::Message& hMessage);

    // Additional Public Declarations
      //## begin Logfile%3FA0B19B010F.public preserve=yes
      //## end Logfile%3FA0B19B010F.public

  protected:
    // Additional Protected Declarations
      //## begin Logfile%3FA0B19B010F.protected preserve=yes
      //## end Logfile%3FA0B19B010F.protected

  private:

    //## Other Operations (specified)
      //## Operation: flush%3FA0B97F0056
      bool flush ();

      //## Operation: sendConfirmations%3FA0B99E0123
      void sendConfirmations ();

    // Additional Private Declarations
      //## begin Logfile%3FA0B19B010F.private preserve=yes
      //## end Logfile%3FA0B19B010F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Counter%3FA0B5920191
      //## begin Logfile::Counter%3FA0B5920191.attr preserve=no  private: int {U} 0
      int m_iCounter;
      //## end Logfile::Counter%3FA0B5920191.attr

      //## Attribute: Confirmations%3FA0C04103E3
      //## begin Logfile::Confirmations%3FA0C04103E3.attr preserve=no  private: vector<pair<string,pair<int,double> > > {U} 
      vector<pair<string,pair<void*,double> > > m_hConfirmations;
      //## end Logfile::Confirmations%3FA0C04103E3.attr

      //## Attribute: File%3FBBF417037A
      //## begin Logfile::File%3FBBF417037A.attr preserve=no  private: IF::FlatFile* {U} 0
      IF::FlatFile* m_pFile;
      //## end Logfile::File%3FBBF417037A.attr

    // Additional Implementation Declarations
      //## begin Logfile%3FA0B19B010F.implementation preserve=yes
      //## end Logfile%3FA0B19B010F.implementation

};

//## begin Logfile%3FA0B19B010F.postscript preserve=yes
//## end Logfile%3FA0B19B010F.postscript

//## begin module%3FA0B7FE00B6.epilog preserve=yes
//## end module%3FA0B7FE00B6.epilog


#endif
