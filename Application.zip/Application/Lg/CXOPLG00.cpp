//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3E9725180109.cm preserve=no
//	$Date:   Aug 12 2019 08:53:50  $ $Author:   e1009839  $ $Revision:   1.10  $
//## end module%3E9725180109.cm

//## begin module%3E9725180109.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%3E9725180109.cp

//## Module: CXOPLG00%3E9725180109; Package body
//## Subsystem: LG%3E97204A009C
//## Source file: C:\Devel\ConnexPlatform\Server\Application\Lg\CXOPLG00.cpp

//## begin module%3E9725180109.additionalIncludes preserve=no
//## end module%3E9725180109.additionalIncludes

//## begin module%3E9725180109.includes preserve=yes
//## end module%3E9725180109.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOPLG00_h
#include "CXODLG00.hpp"
#endif


//## begin module%3E9725180109.declarations preserve=no
//## end module%3E9725180109.declarations

//## begin module%3E9725180109.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new Logger();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%3E9725180109.additionalDeclarations


// Class Logger

Logger::Logger()
  //## begin Logger::Logger%3E97214A035B_const.hasinit preserve=no
  //## end Logger::Logger%3E97214A035B_const.hasinit
  //## begin Logger::Logger%3E97214A035B_const.initialization preserve=yes
  //## end Logger::Logger%3E97214A035B_const.initialization
{
  //## begin Logger::Logger%3E97214A035B_const.body preserve=yes
   memcpy(m_sID,"LG00",4);
  //## end Logger::Logger%3E97214A035B_const.body
}


Logger::~Logger()
{
  //## begin Logger::~Logger%3E97214A035B_dest.body preserve=yes
  //## end Logger::~Logger%3E97214A035B_dest.b%ody
}



//## Other Operations (implementation)
int Logger::initialize ()
{
  //## begin Logger::initialize%3E97272C01D4.body preserve=yes
   new platform::Platform();
   int iRC = Application::initialize();
   UseCase hUseCase("FD","## LG00 START LG");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->connect();
   m_hLogfile.open();
   MidnightAlarm::instance()->attach(this);
   return 0;
  //## end Logger::initialize%3E97272C01D4.body
}

int Logger::onMessage (IF::Message& hMessage)
{
  //## begin Logger::onMessage%3E97273601F4.body preserve=yes
   if (hMessage.messageID() == "L0001D")
      m_hLogfile.write(hMessage);
   else
   if (hMessage.messageID() == "H0305C"
      || hMessage.messageID() == "H0306C")
      m_hLogfile.swap();
   return 0;
  //## end Logger::onMessage%3E97273601F4.body
}

int Logger::onQuiesce ()
{
  //## begin Logger::onQuiesce%3FA0A549010A.body preserve=yes
   return Application::onQuiesce();
  //## end Logger::onQuiesce%3FA0A549010A.body
}

int Logger::onReset (IF::Message& hMessage)
{
  //## begin Logger::onReset%3FA0A55B0279.body preserve=yes
   m_hLogfile.swap();
   return 0;
  //## end Logger::onReset%3FA0A55B0279.body
}

void Logger::update (Subject* pSubject)
{
  //## begin Logger::update%4862A4470109.body preserve=yes
   if (pSubject == MidnightAlarm::instance())
      m_hLogfile.swap();
   Application::update(pSubject);
  //## end Logger::update%4862A4470109.body
}

// Additional Declarations
  //## begin Logger%3E97214A035B.declarations preserve=yes
  //## end Logger%3E97214A035B.declarations

//## begin module%3E9725180109.epilog preserve=yes
//## end module%3E9725180109.epilog
