// Copyright (c) 1998 - 2009
// Fidelity National Information Services
// $Date:   Jan 30 2009 17:06:56  $ $Author:   D02405  $ $Revision:   1.22  $
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif

#include "CXODIF11.hpp"
#include "CXODSI01.hpp"
#include "CXODIP01.hpp"
#include "CXODMN05.hpp"
#include "CXODDZ01.hpp"

#include "CXODPS06.hpp"
   pApplication = new SwitchInterface();
   pApplication->parseCommandLine(argc,argv);
   new dnplatform::DNPlatform();
   ((SwitchInterface*)pApplication)->setMessageProcessor(new IBMMessageProcessor);
   int iRC = 0;
   {
      iRC = pApplication->initialize();
      UseCase hUseCase("IBM","## CX10 START II");
      if (iRC == -1)
         UseCase::setSuccess(false);
   }
   if (iRC == 0)
      pApplication->run();
#include "CXODPS07.hpp"
