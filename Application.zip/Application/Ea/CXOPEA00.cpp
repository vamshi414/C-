//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6124CA410282.cm preserve=no
//	$Date:   Aug 30 2021 15:55:16  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%6124CA410282.cm

//## begin module%6124CA410282.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%6124CA410282.cp

//## Module: CXOPEA00%6124CA410282; Package body
//## Subsystem: EA%6124C9BD003A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\CXOPEA00.cpp

//## begin module%6124CA410282.additionalIncludes preserve=no
//## end module%6124CA410282.additionalIncludes

//## begin module%6124CA410282.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),POSIX(ON),ENVAR('TASK=EA'))
#endif
#include "CXODIF36.hpp"
#include "CXODES95.hpp"
#include "CXODES81.hpp"
#include "CXODJX05.hpp"
//## end module%6124CA410282.includes

#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB50_h
#include "CXODDB50.hpp"
#endif
#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOPEA00_h
#include "CXODEA00.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSDZ02_h
#include "CXODDZ02.hpp"
#endif
#ifndef CXOSDZ04_h
#include "CXODDZ04.hpp"
#endif
#ifndef CXOSDZ03_h
#include "CXODDZ03.hpp"
#endif
#ifndef CXOSDZ06_h
#include "CXODDZ06.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSDB16_h
#include "CXODDB16.hpp"
#endif
#ifndef CXOSEX01_h
#include "CXODEX01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSES06_h
#include "CXODES06.hpp"
#endif
#ifndef CXOSES07_h
#include "CXODES07.hpp"
#endif
#ifndef CXOSES08_h
#include "CXODES08.hpp"
#endif
#ifndef CXOSES09_h
#include "CXODES09.hpp"
#endif
#ifndef CXOSES10_h
#include "CXODES10.hpp"
#endif
#ifndef CXOSES11_h
#include "CXODES11.hpp"
#endif
#ifndef CXOSES12_h
#include "CXODES12.hpp"
#endif
#ifndef CXOSES13_h
#include "CXODES13.hpp"
#endif
#ifndef CXOSES15_h
#include "CXODES15.hpp"
#endif
#ifndef CXOSES14_h
#include "CXODES14.hpp"
#endif
#ifndef CXOSES16_h
#include "CXODES16.hpp"
#endif
#ifndef CXOSES17_h
#include "CXODES17.hpp"
#endif
#ifndef CXOSES87_h
#include "CXODES87.hpp"
#endif
#ifndef CXOSES18_h
#include "CXODES18.hpp"
#endif
#ifndef CXOSES19_h
#include "CXODES19.hpp"
#endif
#ifndef CXOSES20_h
#include "CXODES20.hpp"
#endif
#ifndef CXOSES21_h
#include "CXODES21.hpp"
#endif
#ifndef CXOSES22_h
#include "CXODES22.hpp"
#endif
#ifndef CXOSES30_h
#include "CXODES30.hpp"
#endif
#ifndef CXOSES23_h
#include "CXODES23.hpp"
#endif
#ifndef CXOSES24_h
#include "CXODES24.hpp"
#endif
#ifndef CXOSES25_h
#include "CXODES25.hpp"
#endif
#ifndef CXOSES26_h
#include "CXODES26.hpp"
#endif
#ifndef CXOSES27_h
#include "CXODES27.hpp"
#endif
#ifndef CXOSES03_h
#include "CXODES03.hpp"
#endif
#ifndef CXOSES73_h
#include "CXODES73.hpp"
#endif
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
#ifndef CXOSRL17_h
#include "CXODRL17.hpp"
#endif
#ifndef CXOSSX40_h
#include "CXODSX40.hpp"
#endif


//## begin module%6124CA410282.declarations preserve=no
//## end module%6124CA410282.declarations

//## begin module%6124CA410282.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
pApplication = new ExceptionAPI();
pApplication->parseCommandLine(argc, argv);
if (pApplication->initialize() == 0)
pApplication->run();
#include "CXODPS07.hpp"
//## end module%6124CA410282.additionalDeclarations


// Class ExceptionAPI 

ExceptionAPI::ExceptionAPI()
  //## begin ExceptionAPI::ExceptionAPI%6124CB180009_const.hasinit preserve=no
      : m_pSingleCaseCommand(0)
  //## end ExceptionAPI::ExceptionAPI%6124CB180009_const.hasinit
  //## begin ExceptionAPI::ExceptionAPI%6124CB180009_const.initialization preserve=yes
  //## end ExceptionAPI::ExceptionAPI%6124CB180009_const.initialization
{
  //## begin ExceptionAPI::ExceptionAPI%6124CB180009_const.body preserve=yes
   memcpy(m_sID, "EA00", 4);
  //## end ExceptionAPI::ExceptionAPI%6124CB180009_const.body
}


ExceptionAPI::~ExceptionAPI()
{
  //## begin ExceptionAPI::~ExceptionAPI%6124CB180009_dest.body preserve=yes
   delete m_pSingleCaseCommand;
   delete ems::Case::instance();
   delete EMSRulesEngine::instance();
   delete CaseSegment::instance();
   delete CaseAccelSegment::instance();
   delete CaseAffnSegment::instance();
   delete CaseAustraliaSegment::instance();
   delete CaseCashStationSegment::instance();
   delete CaseCirrusSegment::instance();
   delete CaseHonorSegment::instance();
   delete CaseInterlinkSegment::instance();
   delete CaseMacSegment::instance();
   delete CaseNyceSegment::instance();
   delete CasePlusSegment::instance();
   delete CasePulseSegment::instance();
   delete CaseStarSegment::instance();
   delete CaseVisaSegment::instance();
   delete CaseShazamSegment::instance();
   delete CasePhaseSegment::instance();
   delete CasePhaseAccelSegment::instance();
   delete CasePhaseAffnSegment::instance();
   delete CasePhaseAustraliaSegment::instance();
   delete CasePhaseCashStationSegment::instance();
   delete CasePhaseCirrusSegment::instance();
   delete CasePhaseInterlinkSegment::instance();
   delete CasePhaseMacSegment::instance();
   delete CasePhaseNyceSegment::instance();
   delete CasePhasePulseSegment::instance();
   delete CasePhaseStarSegment::instance();
   delete CasePhaseVisaSegment::instance();
   delete CaseTransitionSegment::instance();
   delete CreditSegment::instance();
   delete EMailMessage::instance();
   delete FunctionFactory::instance();
  //## end ExceptionAPI::~ExceptionAPI%6124CB180009_dest.body
}



//## Other Operations (implementation)
int ExceptionAPI::initialize ()
{
  //## begin ExceptionAPI::initialize%6124CBFB0007.body preserve=yes
   new dnplatform::DNPlatform();
   new segment::AuditEvent;
   int iRC = ServiceApplication::initialize();
   UseCase hUseCase("CLIENT", "## CL172 START EA");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   database::DataModel::instance();
   database::CRTransactionTypeIndicator::instance();
   Database::instance()->attach(this);
   Database::instance()->connect();
   m_pCaseCommand = new restcommand::CaseCommand(0);
   m_pSingleCaseCommand = new soapcommand::SingleCaseCommand(m_pCaseCommand);
   EMSRulesEngine::instance();
   string strCustomer;
   Extract::instance()->getSpec("CUSTOMER", strCustomer);
   Transaction::instance()->setCustomer(strCustomer);
   new ActionFactory();
   new dnplatform::NetworkFactory();
   new ExceptionFactory();
   new dnplatform::APIExportFactory();
   ems::Case::instance();
   return 0;
  //## end ExceptionAPI::initialize%6124CBFB0007.body
}

int ExceptionAPI::onMessage (Message& hMessage)
{
  //## begin ExceptionAPI::onMessage%6124CC140226.body preserve=yes
   if (hMessage.messageID() != "S0003D"
      && hMessage.messageID() != "S0003R"
      && hMessage.messageID() != "S0004D")
      return 0;
   Transaction::instance()->begin();
   string strTimeStamp = Clock::instance()->getYYYYMMDDHHMMSS(true);
   Transaction::instance()->setTimeStamp(strTimeStamp += "00");
   EMSRulesEngine::instance()->reset();
   ems::Case::resetSegments();
   FinancialBaseSegment::instance()->reset();
   m_pSingleCaseCommand->update(Message::instance(Message::INBOUND));
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      Database::instance()->rollback();
   else
      Database::instance()->commit();
   Transaction::instance()->commit();
   idle();
   return 0;
  //## end ExceptionAPI::onMessage%6124CC140226.body
}

int ExceptionAPI::onReset (Message& hMessage)
{
  //## begin ExceptionAPI::onReset%6124CC4A02A0.body preserve=yes
   return 0;
  //## end ExceptionAPI::onReset%6124CC4A02A0.body
}

void ExceptionAPI::update (Subject* pSubject)
{
  //## begin ExceptionAPI::update%6124CC750145.body preserve=yes
   if (pSubject == Database::instance())
   {
      if (Database::instance()->state() == Database::CONNECTED)
         Queue::attach("@##SERVER", Queue::CX_DISTRIBUTION_QUEUE);
      return;
   }
   ServiceApplication::update(pSubject);
  //## end ExceptionAPI::update%6124CC750145.body
}

// Additional Declarations
  //## begin ExceptionAPI%6124CB180009.declarations preserve=yes
  //## end ExceptionAPI%6124CB180009.declarations

//## begin module%6124CA410282.epilog preserve=yes
//## end module%6124CA410282.epilog
