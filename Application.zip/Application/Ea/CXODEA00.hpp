//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6124CA0800A1.cm preserve=no
//	$Date:   Aug 30 2021 15:55:14  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%6124CA0800A1.cm

//## begin module%6124CA0800A1.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%6124CA0800A1.cp

//## Module: CXOPEA00%6124CA0800A1; Package specification
//## Subsystem: EA%6124C9BD003A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\CXODEA00.hpp

#ifndef CXOPEA00_h
#define CXOPEA00_h 1

//## begin module%6124CA0800A1.additionalIncludes preserve=no
//## end module%6124CA0800A1.additionalIncludes

//## begin module%6124CA0800A1.includes preserve=yes
//## end module%6124CA0800A1.includes

#ifndef CXOSPS03_h
#include "CXODPS03.hpp"
#endif

class ExceptionAPI;
//## Modelname: Transaction Research and Adjustments::EMSSegment_CAT%394E27A9030F
namespace emssegment {
class CaseAustraliaSegment;
class CaseCashStationSegment;
class CaseCirrusSegment;
class CaseInterlinkSegment;
class CaseHonorSegment;
class CaseMacSegment;
class CaseNyceSegment;
class CasePhaseAffnSegment;
class CasePhaseAustraliaSegment;
class CasePhaseCashStationSegment;
class CasePhaseCirrusSegment;
class CasePhaseMacSegment;
class CasePhaseNyceSegment;
class CasePhasePulseSegment;
} // namespace emssegment

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;
class Case;
} // namespace ems

namespace emssegment {
class CasePhaseSegment;
class CasePhaseStarSegment;
class CasePlusSegment;
class CasePhaseVisaSegment;
class CasePulseSegment;
class CaseTransitionSegment;
class CaseStarSegment;
class CaseVisaSegment;
class CreditSegment;
class CasePhaseInterlinkSegment;
class CaseAffnSegment;
class CaseShazamSegment;
} // namespace emssegment

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialBaseSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class APIExportFactory;
class NetworkFactory;
class ExceptionFactory;
class ActionFactory;
class DNPlatform;
} // namespace dnplatform

//## Modelname: DataNavigator Foundation::SOAPCommand_CAT%4DC0633D0140
namespace soapcommand {
class SingleCaseCommand;
} // namespace soapcommand

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Queue;
class Trace;
} // namespace IF

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;
} // namespace usersegment

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace database {
class CRTransactionTypeIndicator;
class DataModel;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class AuditEvent;
} // namespace segment

//## Modelname: Connex Library::Rules_CAT (RLDLL)%3EB810F40157
namespace rules {
class FunctionFactory;
} // namespace rules

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;

} // namespace platform

//## begin module%6124CA0800A1.declarations preserve=no
//## end module%6124CA0800A1.declarations

//## begin module%6124CA0800A1.additionalDeclarations preserve=yes
//## end module%6124CA0800A1.additionalDeclarations


//## begin ExceptionAPI%6124CB180009.preface preserve=yes
//## end ExceptionAPI%6124CB180009.preface

//## Class: ExceptionAPI%6124CB180009
//## Category: Transaction Research and Adjustments::ExceptionAPI_CAT(EA)%6124C8680352
//## Subsystem: EA%6124C9BD003A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6124CE4201B3;segment::AuditEvent { -> F}
//## Uses: <unnamed>%6124CE670043;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%6124CEB30203;monitor::UseCase { -> F}
//## Uses: <unnamed>%6124CF6E0052;database::Database { -> F}
//## Uses: <unnamed>%6124CF7700CB;database::DataModel { -> F}
//## Uses: <unnamed>%6124D02402EC;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%6124D08701A9;ExceptionAPI { -> F}
//## Uses: <unnamed>%6124D0A803C9;IF::Extract { -> F}
//## Uses: <unnamed>%6124D0EE022D;reusable::Transaction { -> F}
//## Uses: <unnamed>%6124D11002BC;dnplatform::ActionFactory { -> F}
//## Uses: <unnamed>%6124D1490253;dnplatform::NetworkFactory { -> F}
//## Uses: <unnamed>%6124D1740111;dnplatform::ExceptionFactory { -> F}
//## Uses: <unnamed>%6124D1980374;dnplatform::APIExportFactory { -> F}
//## Uses: <unnamed>%6124D24903C3;IF::Trace { -> F}
//## Uses: <unnamed>%6124E8490374;platform::Platform { -> F}
//## Uses: <unnamed>%6124E87001C6;database::CRTransactionTypeIndicator { -> F}
//## Uses: <unnamed>%6124E9D6013C;ems::Case { -> F}
//## Uses: <unnamed>%6124EB61032A;timer::Clock { -> F}
//## Uses: <unnamed>%6124EB6C0173;IF::Queue { -> F}
//## Uses: <unnamed>%6124EB74036C;repositorysegment::FinancialBaseSegment { -> F}
//## Uses: <unnamed>%6124EE930063;emssegment::CaseAffnSegment { -> F}
//## Uses: <unnamed>%6124EE9E019B;emssegment::CaseAustraliaSegment { -> F}
//## Uses: <unnamed>%6124EEA801AB;emssegment::CaseCashStationSegment { -> F}
//## Uses: <unnamed>%6124F1D60189;emssegment::CaseCirrusSegment { -> F}
//## Uses: <unnamed>%6124F1E501D2;emssegment::CaseHonorSegment { -> F}
//## Uses: <unnamed>%6124F1F20252;emssegment::CaseInterlinkSegment { -> F}
//## Uses: <unnamed>%6124F1FF015A;emssegment::CaseMacSegment { -> F}
//## Uses: <unnamed>%6124F20D00DA;emssegment::CaseNyceSegment { -> F}
//## Uses: <unnamed>%6124F21B0179;emssegment::CasePulseSegment { -> F}
//## Uses: <unnamed>%6124F22A03CB;emssegment::CasePlusSegment { -> F}
//## Uses: <unnamed>%6124F239001A;emssegment::CaseStarSegment { -> F}
//## Uses: <unnamed>%6124F2480122;emssegment::CaseVisaSegment { -> F}
//## Uses: <unnamed>%6124F257001A;emssegment::CaseShazamSegment { -> F}
//## Uses: <unnamed>%6124F26603AA;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%6124F2770173;emssegment::CasePhaseAffnSegment { -> F}
//## Uses: <unnamed>%6124F337010A;emssegment::CasePhaseAustraliaSegment { -> F}
//## Uses: <unnamed>%6124F35100EA;emssegment::CasePhaseSegment { -> F}
//## Uses: <unnamed>%6124F387024A;emssegment::CasePhaseCashStationSegment { -> F}
//## Uses: <unnamed>%6124F39D0171;emssegment::CasePhaseCirrusSegment { -> F}
//## Uses: <unnamed>%6124F3B40272;emssegment::CasePhaseInterlinkSegment { -> F}
//## Uses: <unnamed>%6124F3CF007A;emssegment::CasePhaseMacSegment { -> F}
//## Uses: <unnamed>%6124F3E70139;emssegment::CasePhaseNyceSegment { -> F}
//## Uses: <unnamed>%6124F3FF03B9;emssegment::CasePhasePulseSegment { -> F}
//## Uses: <unnamed>%6124F4190229;emssegment::CasePhaseStarSegment { -> F}
//## Uses: <unnamed>%6124F4B402C9;emssegment::CasePhaseVisaSegment { -> F}
//## Uses: <unnamed>%6124F4D101E1;emssegment::CaseTransitionSegment { -> F}
//## Uses: <unnamed>%6124F4ED0191;emssegment::CreditSegment { -> F}
//## Uses: <unnamed>%6124F50B0121;usersegment::EmailSegment { -> F}
//## Uses: <unnamed>%6124F52F035B;rules::FunctionFactory { -> F}

class DllExport ExceptionAPI : public process::ServiceApplication  //## Inherits: <unnamed>%6124CCED02C3
{
  //## begin ExceptionAPI%6124CB180009.initialDeclarations preserve=yes
  //## end ExceptionAPI%6124CB180009.initialDeclarations

  public:
    //## Constructors (generated)
      ExceptionAPI();

    //## Destructor (generated)
      virtual ~ExceptionAPI();


    //## Other Operations (specified)
      //## Operation: initialize%6124CBFB0007
      int initialize ();

      //## Operation: update%6124CC750145
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin ExceptionAPI%6124CB180009.public preserve=yes
      //## end ExceptionAPI%6124CB180009.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%6124CC140226
      int onMessage (Message& hMessage);

      //## Operation: onReset%6124CC4A02A0
      virtual int onReset (Message& hMessage);

    // Additional Protected Declarations
      //## begin ExceptionAPI%6124CB180009.protected preserve=yes
      //## end ExceptionAPI%6124CB180009.protected

  private:
    // Additional Private Declarations
      //## begin ExceptionAPI%6124CB180009.private preserve=yes
      //## end ExceptionAPI%6124CB180009.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::ExceptionAPI_CAT(EA)::<unnamed>%6124CD52036A
      //## Role: ExceptionAPI::<m_pSingleCaseCommand>%6124CD540253
      //## begin ExceptionAPI::<m_pSingleCaseCommand>%6124CD540253.role preserve=no  public: soapcommand::SingleCaseCommand { -> RFHgN}
      soapcommand::SingleCaseCommand *m_pSingleCaseCommand;
      //## end ExceptionAPI::<m_pSingleCaseCommand>%6124CD540253.role

    // Additional Implementation Declarations
      //## begin ExceptionAPI%6124CB180009.implementation preserve=yes
      restcommand::CaseCommand *m_pCaseCommand;
      //## end ExceptionAPI%6124CB180009.implementation

};

//## begin ExceptionAPI%6124CB180009.postscript preserve=yes
//## end ExceptionAPI%6124CB180009.postscript

//## begin module%6124CA0800A1.epilog preserve=yes
//## end module%6124CA0800A1.epilog


#endif
