//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%38CD30C0004E.cm preserve=no
//	$Date:   Nov 19 2020 08:09:52  $ $Author:   e1009839  $
//	$Revision:   1.52  $
//## end module%38CD30C0004E.cm

//## begin module%38CD30C0004E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%38CD30C0004E.cp

//## Module: CXOPRE00%38CD30C0004E; Package body
//## Subsystem: RE%38CD2F0101BD
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Re\CXOPRE00.cpp

//## begin module%38CD30C0004E.additionalIncludes preserve=no
//## end module%38CD30C0004E.additionalIncludes

//## begin module%38CD30C0004E.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#define _SKIPRU05_
#define DAYS_TO_SCHEDULE 2
#define DAYS_TO_RETAIN 15
#include "CXODDB16.hpp"
//## end module%38CD30C0004E.includes

#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSAR03_h
#include "CXODAR03.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSVC25_h
#include "CXODVC25.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF39_h
#include "CXODIF39.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOSBC33_h
#include "CXODBC33.hpp"
#endif
#ifndef CXOSRU24_h
#include "CXODRU24.hpp"
#endif
#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOSPF29_h
#include "CXODPF29.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSVC27_h
#include "CXODVC27.hpp"
#endif
#ifndef CXOSVC08_h
#include "CXODVC08.hpp"
#endif
#ifndef CXOSVC09_h
#include "CXODVC09.hpp"
#endif
#ifndef CXOSVC10_h
#include "CXODVC10.hpp"
#endif
#ifndef CXOSVC21_h
#include "CXODVC21.hpp"
#endif
#ifndef CXOPRE00_h
#include "CXODRE00.hpp"
#endif


//## begin module%38CD30C0004E.declarations preserve=no
//## end module%38CD30C0004E.declarations

//## begin module%38CD30C0004E.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new ReportEngine();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%38CD30C0004E.additionalDeclarations


// Class ReportEngine 

ReportEngine::ReportEngine()
  //## begin ReportEngine::ReportEngine%38CD2F480197_const.hasinit preserve=no
      : m_pReportListCommand(0),
        m_pReportReadCommand(0),
        m_pReportExecuteCommand(0),
        m_pAdhocReportCommand(0),
        m_pSuspectDeviceReport(0)
  //## end ReportEngine::ReportEngine%38CD2F480197_const.hasinit
  //## begin ReportEngine::ReportEngine%38CD2F480197_const.initialization preserve=yes
  //## end ReportEngine::ReportEngine%38CD2F480197_const.initialization
{
  //## begin ReportEngine::ReportEngine%38CD2F480197_const.body preserve=yes
   memcpy(m_sID,"RE00",4);
   MinuteTimer::instance()->attach(this);
   MidnightAlarm::instance()->attach(this);
  //## end ReportEngine::ReportEngine%38CD2F480197_const.body
}


ReportEngine::~ReportEngine()
{
  //## begin ReportEngine::~ReportEngine%38CD2F480197_dest.body preserve=yes
   MinuteTimer::instance()->detach(this);
   MidnightAlarm::instance()->detach(this);
   delete m_pAdhocReportCommand;
   delete m_pReportReadCommand;
   delete m_pReportListCommand;
   delete m_pReportExecuteCommand;   
   delete m_pSuspectDeviceReport;
  //## end ReportEngine::~ReportEngine%38CD2F480197_dest.body
}



//## Other Operations (implementation)
void ReportEngine::cleanUp ()
{
  //## begin ReportEngine::cleanUp%4ED3E10D030A.body preserve=yes
   string strFREQUENCY[4] = {"D","M","Y"};
   for (int i = 0; i < 3; i++)
   {
      Date hDate(Date::today() - DAYS_TO_RETAIN - (i*366)); //monthly > 1 year, yearly > 2 yrs
      string strDate = hDate.asString("%Y%m%d");
      strDate+="0000";
      Query hQuery;
      hQuery.setSubSelect(true);
      hQuery.setQualifier("QUALIFY","REPORT_TYPE");
      hQuery.bind("REPORT_TYPE","REPORT_TYPE",Column::STRING,&m_strREPORT_TYPE);
      hQuery.setBasicPredicate("REPORT_TYPE","SCHED_FREQUENCY","=",strFREQUENCY[i].c_str());
      auto_ptr<FormatSelectVisitor> pFormatSelectVisitor((FormatSelectVisitor*)DatabaseFactory::instance()->create("FormatSelectVisitor"));
      hQuery.accept(*pFormatSelectVisitor);
      string strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ")";
      hQuery.reset();
      hQuery.setSubSelect(false);
      hQuery.setQualifier("QUALIFY","REPORT_CONTROL");
      hQuery.setBasicPredicate("REPORT_CONTROL","REPORT_STATE","=","RC");
      hQuery.setBasicPredicate("REPORT_CONTROL","TSTAMP_SCHED","<",strDate.c_str());
      hQuery.setBasicPredicate("REPORT_CONTROL","REPORT_TYPE","IN",strSubSelect.c_str());
      auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
      pDeleteStatement->execute(hQuery);
   }
   Database::instance()->commit();
  //## end ReportEngine::cleanUp%4ED3E10D030A.body
}

int ReportEngine::initialize ()
{
  //## begin ReportEngine::initialize%38CD323A0123.body preserve=yes
   new dnplatform::DNPlatform();
   int i = ServiceApplication::initialize();
   UseCase hUseCase("CLIENT","## CL76 START RE");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   database::CRTransactionTypeIndicator::instance();
   Database::instance()->attach(this);
   m_pReportExecuteCommand = new ReportExecuteCommand(0);
   m_pReportListCommand = new ReportListCommand(m_pReportExecuteCommand);
   m_pReportReadCommand = new ReportReadCommand(m_pReportListCommand);
   m_pAdhocReportCommand = new AdhocReportCommand(m_pReportReadCommand);
   Extract::instance()->getSpec("CUSTOMER",m_strCustomerID);
   Database::instance()->connect();
   string strRecord;
   if (Extract::instance()->getRecord("DFILES  SUSPAN",strRecord))
   {
      string strDate(Clock::instance()->getYYYYMMDDHHMMSSHN());
      m_pSuspectDeviceReport = new SuspectDeviceReport("SUSDEV","CU",Customer::instance()->getCUST_ID(),strDate.substr(0,8),strDate.substr(8,6));
   }
   return 0;
  //## end ReportEngine::initialize%38CD323A0123.body
}

int ReportEngine::onMessage (Message& hMessage)
{
  //## begin ReportEngine::onMessage%38CD34B901CD.body preserve=yes
   Transaction::instance()->begin();
   m_pAdhocReportCommand->update(Message::instance(Message::INBOUND));
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      Database::instance()->rollback();
   else
      Database::instance()->commit();
   Transaction::instance()->commit();
   idle();
   return 0;
  //## end ReportEngine::onMessage%38CD34B901CD.body
}

int ReportEngine::onReset (IF::Message& hMessage)
{
  //## begin ReportEngine::onReset%4C23471301BA.body preserve=yes
   if (hMessage.context().length() > 4 && memcmp((char*)hMessage.context(),"SQL",3) == 0)
   {
      string strFileName(hMessage.context().data() + 4, min(size_t(12),size_t(hMessage.context().length() - 4)));
      trim(strFileName);
      deque<viewcommand::AdhocFileExport>::iterator q;
      for(q = m_hAdhocFileExport.begin(); q != m_hAdhocFileExport.end();q++)
      {
         if (!strcmp(q->getFileName().c_str(),strFileName.c_str()))
         {
            Console::display("ST607",strFileName.c_str());
            return 0;
         }
      }
      string strDate(Clock::instance()->getYYYYMMDDHHMMSSHN());
      AdhocFileExport hAdhocFileExport(strFileName,
         "AP",Customer::instance()->getCUST_ID(),
         strDate.substr(0,8), strDate.substr(8,6));
      hAdhocFileExport.setFileName(strFileName);
      if (!(hAdhocFileExport.read()))
      {
         Console::display("ST230",strFileName.c_str());
         return 0;
      }
      m_hAdhocFileExport.push_back(hAdhocFileExport);      
      Application::instance()->setQueueWaitOption(false);
   } 
   return 0;
  //## end ReportEngine::onReset%4C23471301BA.body
}

int ReportEngine::onResume (IF::Message& hMessage)
{
  //## begin ReportEngine::onResume%4C2347660248.body preserve=yes
   if (m_hAdhocFileExport.size() == 0)
      Application::instance()->setQueueWaitOption(true);
   else
   if ((m_hAdhocFileExport.front()).process())
   {
      m_hAdhocFileExport.pop_front();
      if (m_hAdhocFileExport.size() == 0)
         Application::instance()->setQueueWaitOption(true);
   }
   return 0;
  //## end ReportEngine::onResume%4C2347660248.body
}

void ReportEngine::process ()
{
  //## begin ReportEngine::process%4EB9583103C8.body preserve=yes
   UseCase hUseCase("DIST","## DT41 PROCESS REPORTS");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery[1].reset();
   m_hQuery[1].attach(this);
   m_hQuery[1].setDistinct(true);
   m_hQuery[1].setQualifier("QUALIFY","REPORT_TYPE");
   m_hQuery[1].setQualifier("QUALIFY","REPORT_CONTROL");
   m_hQuery[1].join("REPORT_TYPE","INNER","REPORT_CONTROL","REPORT_TYPE");
   m_hQuery[1].join("REPORT_TYPE","INNER","REPORT_CONTROL","ENTITY_TYPE");
   m_hQuery[1].bind("REPORT_TYPE","REPORT_SOURCE_TYPE",Column::STRING,&m_strREPORT_SOURCE_TYPE);
   m_hQuery[1].bind("REPORT_TYPE","SCHED_FREQUENCY",Column::STRING,&m_strSCHED_FREQUENCY);
   m_hQuery[1].bind("REPORT_CONTROL","ENTITY_TYPE",Column::STRING,&m_strENTITY_TYPE);
   m_hQuery[1].bind("REPORT_CONTROL","ENTITY_ID",Column::STRING,&m_strENTITY_ID);
   m_hQuery[1].bind("REPORT_CONTROL","ADDL_ENTITY_TYPE",Column::STRING,&m_strADDL_ENTITY_TYPE);
   m_hQuery[1].bind("REPORT_CONTROL","ADDL_ENTITY_ID",Column::STRING,&m_strADDL_ENTITY_ID);
   m_hQuery[1].bind("REPORT_CONTROL","REPORT_ID",Column::LONG,&m_iREPORT_ID);
   m_hQuery[1].bind("REPORT_CONTROL","RETRY_COUNT",Column::LONG,&m_iRETRY_COUNT);
   m_hQuery[1].bind("REPORT_CONTROL","TSTAMP_SCHED",Column::STRING,&m_strTSTAMP_SCHED);
   m_hQuery[1].bind("REPORT_CONTROL","TSTAMP_INIT",Column::STRING,&m_strTSTAMP_INIT);
   m_hQuery[1].bind("REPORT_CONTROL","TSTAMP_NEXT_TRY",Column::STRING,&m_strTSTAMP_NEXT_TRY);
   m_hQuery[1].bind("REPORT_CONTROL","REPORT_STATE",Column::STRING,&m_strREPORT_STATE);
   m_hQuery[1].bind("REPORT_CONTROL","REPORT_TYPE",Column::STRING,&m_strREPORT_TYPE);
   m_hQuery[1].bind("REPORT_CONTROL","REPORT_DATE",Column::STRING,&m_strREPORT_DATE);   
   m_hQuery[1].setBasicPredicate("REPORT_CONTROL","CUST_ID","=",m_strCustomerID.c_str());
   m_hQuery[1].setBasicPredicate("REPORT_CONTROL","TSTAMP_NEXT_TRY","<",Clock::instance()->getYYYYMMDDHHMMSS().substr(0,12).c_str());
   m_hQuery[1].getSearchCondition().append(" AND (");
   m_hQuery[1].setBasicPredicate("REPORT_CONTROL","REPORT_STATE","=","RW");
   m_hQuery[1].setBasicPredicate("REPORT_CONTROL","REPORT_STATE","=","RE",false,false);
   m_hQuery[1].getSearchCondition().append(")");
   m_hQuery[1].setOrderByClause("TSTAMP_SCHED");
   if (!pSelectStatement->execute(m_hQuery[1]) || Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      Database::instance()->rollback();
   Database::instance()->commit();      
   return;
  //## end ReportEngine::process%4EB9583103C8.body
}

void ReportEngine::schedule ()
{
  //## begin ReportEngine::schedule%4EB958D5002E.body preserve=yes
   string strTask_Name(Application::instance()->name());
   if (strTask_Name.substr(2,4) > "RE01")
      return;
   UseCase hUseCase("DIST","## DT40 SCHEDULE REPORTS");
   m_hReports.erase(m_hReports.begin(),m_hReports.end());
   m_hQuery[2].reset();
   m_hQuery[2].attach(this);
   m_hQuery[2].setQualifier("QUALIFY","REPORT_TYPE");
   m_hQuery[2].bind("REPORT_TYPE","REPORT_TYPE",Column::STRING,&m_strREPORT_TYPE);
   m_hQuery[2].setBasicPredicate("REPORT_TYPE","REPORT_SOURCE_TYPE","=","D");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(m_hQuery[2]))
   {
      Database::instance()->rollback();
      hUseCase.setSuccess(false);
      Database::instance()->commit();
      return;
   }
   string strFREQUENCY[4] = {"D","M","Y"};
   for(int i = 0; i < 3; i++)
   {
      m_hQuery[0].reset();
      m_hQuery[0].attach(this);
      m_hQuery[0].setDistinct(true);
      m_hQuery[0].setQualifier("QUALIFY","REPORT_SUBSCRIBE");
      m_hQuery[0].setQualifier("QUALIFY","REPORT_TYPE");
      m_hQuery[0].bind("REPORT_SUBSCRIBE","REPORT_TYPE",Column::STRING,&m_strREPORT_TYPE);
      m_hQuery[0].bind("REPORT_SUBSCRIBE","ENTITY_TYPE",Column::STRING,&m_strENTITY_TYPE);
      m_hQuery[0].bind("REPORT_SUBSCRIBE","ENTITY_ID",Column::STRING,&m_strENTITY_ID);
      m_hQuery[0].bind("REPORT_SUBSCRIBE","ADDL_ENTITY_TYPE",Column::STRING,&m_strADDL_ENTITY_TYPE);
      m_hQuery[0].bind("REPORT_SUBSCRIBE","ADDL_ENTITY_ID",Column::STRING,&m_strADDL_ENTITY_ID);
      m_hQuery[0].bind("REPORT_SUBSCRIBE","SCHED_TIME",Column::STRING,&m_strSCHED_TIME);
      m_hQuery[0].bind("REPORT_SUBSCRIBE","CUST_ID",Column::STRING,&m_strCUST_ID);
      m_hQuery[0].bind("REPORT_SUBSCRIBE","REPORT_FMT",Column::STRING,&m_strREPORT_FMT);
      m_hQuery[0].bind("REPORT_TYPE","REPORT_NAME",Column::STRING,&m_strREPORT_NAME);
      m_hQuery[0].bind("REPORT_TYPE","SCHED_FREQUENCY",Column::STRING,&m_strSCHED_FREQUENCY);
      m_hQuery[0].join("REPORT_SUBSCRIBE","INNER","REPORT_TYPE","REPORT_TYPE");
      m_hQuery[0].join("REPORT_SUBSCRIBE","INNER","REPORT_TYPE","ENTITY_TYPE");
      m_hQuery[0].setBasicPredicate("REPORT_SUBSCRIBE","CUST_ID","=",m_strCustomerID.c_str());
      m_hQuery[0].setBasicPredicate("REPORT_TYPE","SCHED_FREQUENCY","=",strFREQUENCY[i].c_str());
      if (!pSelectStatement->execute(m_hQuery[0]) || Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      {
         Database::instance()->rollback();      
         hUseCase.setSuccess(false);
      }
   }
   Database::instance()->commit();   
  //## end ReportEngine::schedule%4EB958D5002E.body
}

void ReportEngine::update (Subject* pSubject)
{
  //## begin ReportEngine::update%4EB9586B0109.body preserve=yes
   if (pSubject == Database::instance()
      && Database::instance()->state() == Database::CONNECTED)
   {
      postingfile::TransactionDetailFile hTransactionDetailFile;
      if (!hTransactionDetailFile.configureDetailFile())
         Database::instance()->rollback();
      else
         Database::instance()->commit();
      if (!hTransactionDetailFile.verifySubscribedEntities())
         Database::instance()->rollback();
      else
         Database::instance()->commit();
      schedule();
   }
   else
   if (pSubject == MinuteTimer::instance())
   {
      string strTask_Name(Application::instance()->name());
      if (strTask_Name.substr(2,4) > "RE01")
         return;
      return(process());   
   }
   else
   if (pSubject == &m_hQuery[0])
   {
      Query hQuery;
      Date hDate(Date::today());
      string strDate;
      string strDatePlus1;
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      for(int i = 0; i < DAYS_TO_SCHEDULE; i++)
      {
         hQuery.reset();
         hQuery.setQualifier("QUALIFY","REPORT_CONTROL");
         hQuery.bind("REPORT_CONTROL","REPORT_STATE",Column::STRING,&m_strREPORT_STATE);
         hQuery.setBasicPredicate("REPORT_CONTROL","REPORT_TYPE","=",m_strREPORT_TYPE.c_str());
         hQuery.setBasicPredicate("REPORT_CONTROL","ENTITY_TYPE","=",m_strENTITY_TYPE.c_str());
         hQuery.setBasicPredicate("REPORT_CONTROL","ENTITY_ID","=",m_strENTITY_ID.c_str());
         hQuery.setBasicPredicate("REPORT_CONTROL","ADDL_ENTITY_TYPE","=",m_strADDL_ENTITY_TYPE.c_str());
         hQuery.setBasicPredicate("REPORT_CONTROL","ADDL_ENTITY_ID","=",m_strADDL_ENTITY_ID.c_str());
         hQuery.setBasicPredicate("REPORT_CONTROL","CUST_ID","=",m_strCUST_ID.c_str());
         hQuery.setBasicPredicate("REPORT_CONTROL","REPORT_FMT","=",m_strREPORT_FMT.c_str());
         if (m_strSCHED_FREQUENCY == "D")
         {
            strDate = (hDate + i).asString("%Y%m%d");
            strDatePlus1 = (hDate + i +1).asString("%Y%m%d");
         }
         else
         if (m_strSCHED_FREQUENCY == "M")        
            strDate = (hDate + (i*31)).asString("%Y%m01");       
         else
         if (m_strSCHED_FREQUENCY == "Y")       
            strDate = (hDate + i*366).asString("%Y0101");         
         hQuery.setBasicPredicate("REPORT_CONTROL","REPORT_DATE","=",strDate.c_str());
         if (!pSelectStatement->execute(hQuery))
         {
            Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            m_hQuery[0].setAbort(true);
            return;
         }
         if (pSelectStatement->getRows() != 0)
            continue;
         auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         Table hTable("REPORT_CONTROL");
         hTable.setQualifier("QUALIFY");
         hTable.set("REPORT_TYPE",m_strREPORT_TYPE);
         hTable.set("ENTITY_TYPE",m_strENTITY_TYPE);
         hTable.set("ENTITY_ID",m_strENTITY_ID);
         hTable.set("ADDL_ENTITY_TYPE",m_strADDL_ENTITY_TYPE);
         hTable.set("ADDL_ENTITY_ID",m_strADDL_ENTITY_ID);
         hTable.set("CUST_ID",m_strCUST_ID);
         hTable.set("REPORT_FMT",m_strREPORT_FMT);
         hTable.set("REPORT_STATE","RW");
         hTable.set("REPORT_DATE",strDate);
         if (m_hReports.find(m_strREPORT_TYPE) != m_hReports.end() && m_strSCHED_FREQUENCY == "D")
            strDate = strDatePlus1;
         hTable.set("TSTAMP_SCHED",strDate + m_strSCHED_TIME);
         hTable.set("TSTAMP_INIT",strDate + m_strSCHED_TIME);
         hTable.set("TSTAMP_COMPLETED","000000000000");
         hTable.set("TSTAMP_NEXT_TRY",strDate + m_strSCHED_TIME);
         hTable.set("CHECK_POINT","0");
         hTable.set("RETRY_COUNT","0",true);
         if (!pInsertStatement->execute(hTable))
         {
            Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            m_hQuery[0].setAbort(true);
            return;
         }
         UseCase::addItem();
      }      
      delete pSelectStatement.release();
      return;   
   }
   else
   if (pSubject == &m_hQuery[1])
   {
      updateStatus();
      if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
         m_hQuery[1].setAbort(true);
      return;
   } 
   else
   if (pSubject == &m_hQuery[2])
   {
      m_hReports.insert(m_strREPORT_TYPE);
      return;
   }
   else
   if (pSubject == MidnightAlarm::instance())
   {    
      Sleep::goTo("00000100");
      postingfile::TransactionDetailFile hTransactionDetailFile;
      if (!hTransactionDetailFile.verifySubscribedEntities())
         Database::instance()->rollback();
      else
         Database::instance()->commit();
      schedule();
      cleanUp();
   }
   ServiceApplication::update(pSubject);
  //## end ReportEngine::update%4EB9586B0109.body
}

void ReportEngine::updateStatus ()
{
  //## begin ReportEngine::updateStatus%4EC29ACD02A4.body preserve=yes
   if (m_strREPORT_STATE == "RE")
   {
      if (m_iRETRY_COUNT < 5)
         ++m_iRETRY_COUNT;
      else
      {
         m_iRETRY_COUNT = 0;   
         DateTime hDateTime;
         IString strAdjustTimestamp ((char*)(Clock::instance()->getYYYYMMDDHHMMSSHN()).c_str());
         hDateTime.timeAdjust(strAdjustTimestamp,60);      
         m_strTSTAMP_NEXT_TRY = strAdjustTimestamp;
         m_strREPORT_STATE = "RW";
      }
   }
   else
   {  
      m_strREPORT_STATE = "RR";
      Query hQuery;
      hQuery.bind("DX_DATA_CONTROL","DATE_RECON",Column::STRING,&m_strDATE_RECON);   
      hQuery.bind("DX_DATA_CONTROL","DX_STATE",Column::STRING,&m_strDX_STATE);   
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","=",m_strREPORT_TYPE.c_str());
      if (m_strSCHED_FREQUENCY != "M")
         hQuery.setBasicPredicate("DX_DATA_CONTROL","DATE_RECON","=",m_strREPORT_DATE.c_str());
      else  
      {
         Date hDate(m_strREPORT_DATE.c_str());
         hDate -= 1;
         string strDate = hDate.asString("%Y%m00");
         hQuery.setBasicPredicate("DX_DATA_CONTROL","DATE_RECON","=",strDate.c_str());
      }
      if (m_strENTITY_TYPE != "AI" && m_strENTITY_TYPE != "II" && m_strADDL_ENTITY_TYPE != "*S")
         hQuery.setBasicPredicate("DX_DATA_CONTROL","ENTITY_ID" ,"=" , m_strENTITY_ID.c_str());
      else
      if ((m_strENTITY_TYPE == "AI" || m_strENTITY_TYPE == "II")
         || (m_strREPORT_TYPE.substr(0,3) == "MXI" && m_strADDL_ENTITY_TYPE == "*S"))
         hQuery.setBasicPredicate("DX_DATA_CONTROL","ENTITY_ID" ,"=" , m_strADDL_ENTITY_ID.c_str());
      hQuery.setOrderByClause("DX_STATE");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
         return;
      if (pSelectStatement->getRows() > 0 && 
         m_strREPORT_SOURCE_TYPE == "G" && 
         m_strDX_STATE[0] != 'D')
         return;
   }
   m_strTSTAMP_INIT = Clock::instance()->getYYYYMMDDHHMMSS();
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   Table hTable("REPORT_CONTROL");
   hTable.setQualifier("QUALIFY");
   hTable.set("REPORT_ID",m_iREPORT_ID,true);
   hTable.set("REPORT_STATE",m_strREPORT_STATE);
   hTable.set("TSTAMP_INIT",m_strTSTAMP_INIT);
   hTable.set("TSTAMP_NEXT_TRY",m_strTSTAMP_NEXT_TRY);
   hTable.set("RETRY_COUNT",m_iRETRY_COUNT,false);
   if (!pUpdateStatement->execute(hTable))
   {
      Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
      UseCase::setSuccess(false);
   }
   UseCase::addItem();
  //## end ReportEngine::updateStatus%4EC29ACD02A4.body
}

// Additional Declarations
  //## begin ReportEngine%38CD2F480197.declarations preserve=yes
  //## end ReportEngine%38CD2F480197.declarations

//## begin module%38CD30C0004E.epilog preserve=yes
//## end module%38CD30C0004E.epilog
