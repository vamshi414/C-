//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%38CD30BE025E.cm preserve=no
//	$Date:   Nov 19 2020 08:08:42  $ $Author:   e1009839  $
//	$Revision:   1.24  $
//## end module%38CD30BE025E.cm

//## begin module%38CD30BE025E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%38CD30BE025E.cp

//## Module: CXOPRE00%38CD30BE025E; Package specification
//## Subsystem: RE%38CD2F0101BD
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Re\CXODRE00.hpp

#ifndef CXOPRE00_h
#define CXOPRE00_h 1

//## begin module%38CD30BE025E.additionalIncludes preserve=no
//## end module%38CD30BE025E.additionalIncludes

//## begin module%38CD30BE025E.includes preserve=yes
// $Date:   Nov 19 2020 08:08:42  $ $Author:   e1009839  $ $Revision:   1.24  $
//## end module%38CD30BE025E.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSPS03_h
#include "CXODPS03.hpp"
#endif

//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
class ArchiveRetriever;
} // namespace archive

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::ViewCommand_CAT%394E26F50072
namespace viewcommand {
class AdhocReportCommand;
class ReportExecuteCommand;
class ReportListCommand;
class ReportReadCommand;
class SuspectDeviceReport;
class AdhocFileExport;
} // namespace viewcommand

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class FormatSelectVisitor;
class IString;
class Transaction;
class Statement;
class Signal;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DateTime;
class Extract;
class Sleep;
class QueueFactory;
class Console;
class Queue;
class Message;
class SocketQueue;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class SOAPService;
} // namespace command

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;
} // namespace platform

//## Modelname: Data Distribution::PostingFile_CAT%41E951230177
namespace postingfile {
class TransactionDetailFile;

} // namespace postingfile

//## begin module%38CD30BE025E.declarations preserve=no
//## end module%38CD30BE025E.declarations

//## begin module%38CD30BE025E.additionalDeclarations preserve=yes
#include <deque>
//## end module%38CD30BE025E.additionalDeclarations


//## begin ReportEngine%38CD2F480197.preface preserve=yes
//## end ReportEngine%38CD2F480197.preface

//## Class: ReportEngine%38CD2F480197
//	<body>
//	<title>CG
//	<h1>RE
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server provides a set of reports to
//	end users.
//	The following reports are available:
//	<ul>
//	<li>EMS
//	<ol>
//	<li>EMS Case Data
//	<li>EMS Detail Exception Report With Fees
//	<li>EMS Summary Data
//	<li>EMS Summary Exception Report With Fees
//	<li>Queues assigned to user
//	<li>The Unmatched Report
//	<li>Users defined to queue
//	</ol>
//	<li>Fraud
//	<ol>
//	<li>Cardholder Risk Identification Service
//	<li>Master Card RiskFinder Daily Summary
//	</ol>
//	<li>Totals
//	<ol>
//	<li>eFunds Daily Totals Recap
//	<li>eFunds Interchange
//	<li>eFunds Net Funds
//	<li>eFunds Summary Balance
//	<li>eFunds Suspense
//	<li>Users defined to view
//	<li>Views assigned to user
//	</ol>
//	<li>Transaction Activity
//	<ol>
//	<li>Card Capture
//	<li>Cardholder Activity
//	<li>Terminal Activity
//	</ol>
//	<li>Adhoc Reporting
//	</ul>
//	<p>
//	The Report Engine service (<i>ca</i>RE01) returns result
//	sets from predefined report templates to end users.
//	Requests come through the Client Interface service
//	(<i>ca</i>CI01).
//	</p>
//	<img src=CXOCRE00.gif>
//	<p>
//	Refer to the <i>DataNavigator Client Report Writer
//	User's Guide</i> for more information.
//	</p>
//	<h3>Adhoc Reporting
//	<p>
//	Adhoc reporting provides a mechanism for directing adhoc
//	queries against the Data Navigator repository and
//	distributing the results using the Data Distribution
//	services.  The primary purpose for this feature is to
//	retrieve PAN information in a de-Tokenized format in
//	environments where Tokenization is turned on.  Output
//	files generated by this process can be encrypted with
//	triple DES encryption to retain PCI compliance.   For
//	each adhoc report define a 6 character file type name
//	that will be used when the output is generated. For
//	example:
//	<ul>
//	<li>DFILES ADHOC1 <i>ca</i>SQLIN1
//	<li>DFILES ADHOC2 <i>ca</i>SQLIN2
//	<li>DFILES ADHOC3 <i>ca</i>SQLIN3
//	</ul>
//	The <i>ca</i>SQLIN<i>n</i> file represents the location
//	of the SQL that will be executed to produce the report.
//	<p>
//	For each adhoc report, a matching control card should be
//	configured in the Data Distribution
//	(<i>ca</i>DT<i>nn</i>) task as follows:
//	<ul>
//	<li>DFILES ADHOC1 <i>ca</i>SQLOT1
//	<li>DFILES ADHOC2 <i>ca</i>SQLOT2
//	<li>DFILES ADHOC3 <i>ca</i>SQLOT3
//	</ul>
//	</p>
//	</body>
//	<body>
//	<title>OG
//	<h1>RE
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server provides a set of reports to
//	end users.
//	</p>
//	<img src=CXOORE00.gif>
//	<h2>TS
//	<h3>DataNavigator Client
//	<p>
//	<b>Issue:</b>  End user reporting problems with services
//	provided by Report Engine.
//	<p>
//	<b>Resolution:</b>  Refer to the Troubleshooting tips
//	for the Client Interface in the <i>DataNavigator Server
//	Operations Guide: Foundation</i> manual.
//	</p>
//	</body>
//## Category: Utility::ReportEngine_CAT%38CD2E6003E3
//## Subsystem: RE%38CD2F0101BD
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..n



//## Uses: <unnamed>%38CD35DC004E;IF::QueueFactory { -> F}
//## Uses: <unnamed>%38CD3F790089;database::Database { -> F}
//## Uses: <unnamed>%38CD3F7B00AA;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%38CE616703C2;IF::Message { -> F}
//## Uses: <unnamed>%38CE619003C1;reusable::Transaction { -> F}
//## Uses: <unnamed>%3A3E2FD4012D;monitor::UseCase { -> F}
//## Uses: <unnamed>%3BCEDA7000DA;IF::Queue { -> F}
//## Uses: <unnamed>%3C0E8AC40165;IF::Extract { -> F}
//## Uses: <unnamed>%40AA94690062;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%40AA94D70381;platform::Platform { -> F}
//## Uses: <unnamed>%47D4DEE60102;archive::ArchiveRetriever { -> F}
//## Uses: <unnamed>%4C29B8F5011A;IF::Console { -> F}
//## Uses: <unnamed>%4C2DCAB900AA;timer::Clock { -> F}
//## Uses: <unnamed>%4C35902A0029;entitysegment::Customer { -> F}
//## Uses: <unnamed>%4C3D4E1200F8;viewcommand::AdhocFileExport { -> F}
//## Uses: <unnamed>%4EB954C900B8;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%4EB954E402FA;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%4EB9563B01EC;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4EB956610130;reusable::Statement { -> F}
//## Uses: <unnamed>%4EC180CA0247;timer::Date { -> F}
//## Uses: <unnamed>%4EC29F02003C;IF::DateTime { -> F}
//## Uses: <unnamed>%4EC43FBE033D;IF::SocketQueue { -> F}
//## Uses: <unnamed>%4EC43FC50178;reusable::Signal { -> F}
//## Uses: <unnamed>%4EC43FC90021;IF::Message { -> F}
//## Uses: <unnamed>%4EC583CE00D4;command::SOAPService { -> F}
//## Uses: <unnamed>%4EEA69F5010F;reusable::IString { -> F}
//## Uses: <unnamed>%4EF0B0AD03E5;IF::Sleep { -> F}
//## Uses: <unnamed>%4F4808B602F1;postingfile::TransactionDetailFile { -> F}
//## Uses: <unnamed>%50074D4403AF;database::GlobalContext { -> F}
//## Uses: <unnamed>%50074D6B0340;reusable::FormatSelectVisitor { -> F}
//## Uses: <unnamed>%526F702A02CB;viewcommand::SuspectDeviceReport { -> F}

class ReportEngine : public process::ServiceApplication  //## Inherits: <unnamed>%3BCEDAE00290
{
  //## begin ReportEngine%38CD2F480197.initialDeclarations preserve=yes
  //## end ReportEngine%38CD2F480197.initialDeclarations

  public:
    //## Constructors (generated)
      ReportEngine();

    //## Destructor (generated)
      virtual ~ReportEngine();


    //## Other Operations (specified)
      //## Operation: cleanUp%4ED3E10D030A
      void cleanUp ();

      //## Operation: initialize%38CD323A0123
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>RE
      //	<h2>MS
      //	<h3>Scalability
      //	<p>
      //	The initial setup of the DataNavigator server typically
      //	installs two Report Engine services.
      //	The actual number can vary from 1 to as many as 99
      //	services.
      //	<p>
      //	Additional Report Engine services can be added to
      //	support any number (up to 99) of simultaneous report
      //	requests from end-users.
      //	Current usage of the Report Engine services can be
      //	determined by examining the Client CL45 RETRIEVE REPORT
      //	entry in System Health Monitor.
      //	</body>
      virtual int initialize ();

      //## Operation: schedule%4EB958D5002E
      void schedule ();

      //## Operation: update%4EB9586B0109
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin ReportEngine%38CD2F480197.public preserve=yes
      //## end ReportEngine%38CD2F480197.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%38CD34B901CD
      virtual int onMessage (Message& hMessage);

      //## Operation: onReset%4C23471301BA
      virtual int onReset (IF::Message& hMessage);

      //## Operation: onResume%4C2347660248
      virtual int onResume (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin ReportEngine%38CD2F480197.protected preserve=yes
      //## end ReportEngine%38CD2F480197.protected

  private:

    //## Other Operations (specified)
      //## Operation: process%4EB9583103C8
      void process ();

      //## Operation: updateStatus%4EC29ACD02A4
      void updateStatus ();

    // Data Members for Class Attributes

      //## Attribute: REPORT_ID%4EC19F4501D1
      //## begin ReportEngine::REPORT_ID%4EC19F4501D1.attr preserve=no  private: int {UA} 
      int m_iREPORT_ID;
      //## end ReportEngine::REPORT_ID%4EC19F4501D1.attr

      //## Attribute: RETRY_COUNT%4EC1A018015F
      //## begin ReportEngine::RETRY_COUNT%4EC1A018015F.attr preserve=no  private: int {UA} 
      int m_iRETRY_COUNT;
      //## end ReportEngine::RETRY_COUNT%4EC1A018015F.attr

    // Additional Private Declarations
      //## begin ReportEngine%38CD2F480197.private preserve=yes
      set<string> m_hReports;
      //## end ReportEngine%38CD2F480197.private
  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ADDL_ENTITY_ID%4F3E20AC01B5
      //## begin ReportEngine::ADDL_ENTITY_ID%4F3E20AC01B5.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strADDL_ENTITY_ID;
      //## end ReportEngine::ADDL_ENTITY_ID%4F3E20AC01B5.attr

      //## Attribute: ADDL_ENTITY_TYPE%4F3E209601F1
      //## begin ReportEngine::ADDL_ENTITY_TYPE%4F3E209601F1.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strADDL_ENTITY_TYPE;
      //## end ReportEngine::ADDL_ENTITY_TYPE%4F3E209601F1.attr

      //## Attribute: CUST_ID%4EEA6ACB0213
      //## begin ReportEngine::CUST_ID%4EEA6ACB0213.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strCUST_ID;
      //## end ReportEngine::CUST_ID%4EEA6ACB0213.attr

      //## Attribute: CustomerID%4EEA6A170351
      //## begin ReportEngine::CustomerID%4EEA6A170351.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strCustomerID;
      //## end ReportEngine::CustomerID%4EEA6A170351.attr

      //## Attribute: DATE_RECON%5032933D03AF
      //## begin ReportEngine::DATE_RECON%5032933D03AF.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strDATE_RECON;
      //## end ReportEngine::DATE_RECON%5032933D03AF.attr

      //## Attribute: DX_STATE%5032934D0360
      //## begin ReportEngine::DX_STATE%5032934D0360.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strDX_STATE;
      //## end ReportEngine::DX_STATE%5032934D0360.attr

      //## Attribute: ENTITY_ID%4F1751430041
      //## begin ReportEngine::ENTITY_ID%4F1751430041.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strENTITY_ID;
      //## end ReportEngine::ENTITY_ID%4F1751430041.attr

      //## Attribute: ENTITY_TYPE%4EBD8A8A0039
      //## begin ReportEngine::ENTITY_TYPE%4EBD8A8A0039.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strENTITY_TYPE;
      //## end ReportEngine::ENTITY_TYPE%4EBD8A8A0039.attr

      //## Attribute: REPORT_DATE%4EC19E53009D
      //## begin ReportEngine::REPORT_DATE%4EC19E53009D.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strREPORT_DATE;
      //## end ReportEngine::REPORT_DATE%4EC19E53009D.attr

      //## Attribute: REPORT_FMT%4F1751210228
      //## begin ReportEngine::REPORT_FMT%4F1751210228.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strREPORT_FMT;
      //## end ReportEngine::REPORT_FMT%4F1751210228.attr

      //## Attribute: REPORT_NAME%4EBD8ACE009B
      //## begin ReportEngine::REPORT_NAME%4EBD8ACE009B.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strREPORT_NAME;
      //## end ReportEngine::REPORT_NAME%4EBD8ACE009B.attr

      //## Attribute: REPORT_SOURCE_TYPE%503293730359
      //## begin ReportEngine::REPORT_SOURCE_TYPE%503293730359.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strREPORT_SOURCE_TYPE;
      //## end ReportEngine::REPORT_SOURCE_TYPE%503293730359.attr

      //## Attribute: REPORT_STATE%4EC15AAB00B8
      //## begin ReportEngine::REPORT_STATE%4EC15AAB00B8.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strREPORT_STATE;
      //## end ReportEngine::REPORT_STATE%4EC15AAB00B8.attr

      //## Attribute: REPORT_TYPE%4EBD8A4C018D
      //## begin ReportEngine::REPORT_TYPE%4EBD8A4C018D.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strREPORT_TYPE;
      //## end ReportEngine::REPORT_TYPE%4EBD8A4C018D.attr

      //## Attribute: SCHED_FREQUENCY%4ED3EB220224
      //## begin ReportEngine::SCHED_FREQUENCY%4ED3EB220224.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strSCHED_FREQUENCY;
      //## end ReportEngine::SCHED_FREQUENCY%4ED3EB220224.attr

      //## Attribute: SCHED_TIME%4EBD8ADD02EE
      //## begin ReportEngine::SCHED_TIME%4EBD8ADD02EE.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strSCHED_TIME;
      //## end ReportEngine::SCHED_TIME%4EBD8ADD02EE.attr

      //## Attribute: TSTAMP_INIT%4EC19ECD009B
      //## begin ReportEngine::TSTAMP_INIT%4EC19ECD009B.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strTSTAMP_INIT;
      //## end ReportEngine::TSTAMP_INIT%4EC19ECD009B.attr

      //## Attribute: TSTAMP_NEXT_TRY%4EC29EB7026D
      //## begin ReportEngine::TSTAMP_NEXT_TRY%4EC29EB7026D.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strTSTAMP_NEXT_TRY;
      //## end ReportEngine::TSTAMP_NEXT_TRY%4EC29EB7026D.attr

      //## Attribute: TSTAMP_SCHED%4EC19E800296
      //## begin ReportEngine::TSTAMP_SCHED%4EC19E800296.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strTSTAMP_SCHED;
      //## end ReportEngine::TSTAMP_SCHED%4EC19E800296.attr

    // Data Members for Associations

      //## Association: Utility::ReportEngine_CAT::<unnamed>%38CE6234016E
      //## Role: ReportEngine::<m_pReportListCommand>%38CE623403D1
      //## begin ReportEngine::<m_pReportListCommand>%38CE623403D1.role preserve=no  public: viewcommand::ReportListCommand { -> RFHgN}
      viewcommand::ReportListCommand *m_pReportListCommand;
      //## end ReportEngine::<m_pReportListCommand>%38CE623403D1.role

      //## Association: Utility::ReportEngine_CAT::<unnamed>%38CE623C00ED
      //## Role: ReportEngine::<m_pReportReadCommand>%38CE623C033C
      //## begin ReportEngine::<m_pReportReadCommand>%38CE623C033C.role preserve=no  public: viewcommand::ReportReadCommand { -> RFHgN}
      viewcommand::ReportReadCommand *m_pReportReadCommand;
      //## end ReportEngine::<m_pReportReadCommand>%38CE623C033C.role

      //## Association: Utility::ReportEngine_CAT::<unnamed>%38CE624201F0
      //## Role: ReportEngine::<m_pReportExecuteCommand>%38CE624203D1
      //## begin ReportEngine::<m_pReportExecuteCommand>%38CE624203D1.role preserve=no  public: viewcommand::ReportExecuteCommand { -> RFHgN}
      viewcommand::ReportExecuteCommand *m_pReportExecuteCommand;
      //## end ReportEngine::<m_pReportExecuteCommand>%38CE624203D1.role

      //## Association: Utility::ReportEngine_CAT::<unnamed>%3CD96E1401F4
      //## Role: ReportEngine::<m_pAdhocReportCommand>%3CD96E150138
      //## begin ReportEngine::<m_pAdhocReportCommand>%3CD96E150138.role preserve=no  public: viewcommand::AdhocReportCommand { -> RFHgN}
      viewcommand::AdhocReportCommand *m_pAdhocReportCommand;
      //## end ReportEngine::<m_pAdhocReportCommand>%3CD96E150138.role

      //## Association: Utility::ReportEngine_CAT::<unnamed>%4EBD86B500F6
      //## Role: ReportEngine::<m_hQuery>%4EBD86B60144
      //## begin ReportEngine::<m_hQuery>%4EBD86B60144.role preserve=no  public: reusable::Query { -> 3VHgN}
      reusable::Query m_hQuery[3];
      //## end ReportEngine::<m_hQuery>%4EBD86B60144.role

      //## Association: Utility::ReportEngine_CAT::<unnamed>%526F705A0117
      //## Role: ReportEngine::<m_pSuspectDeviceReport>%526F705B02DD
      //## begin ReportEngine::<m_pSuspectDeviceReport>%526F705B02DD.role preserve=no  public: viewcommand::SuspectDeviceReport { -> RFHgN}
      viewcommand::SuspectDeviceReport *m_pSuspectDeviceReport;
      //## end ReportEngine::<m_pSuspectDeviceReport>%526F705B02DD.role

    // Additional Implementation Declarations
      //## begin ReportEngine%38CD2F480197.implementation preserve=yes
      deque<viewcommand::AdhocFileExport> m_hAdhocFileExport;
      //## end ReportEngine%38CD2F480197.implementation
};

//## begin ReportEngine%38CD2F480197.postscript preserve=yes
//## end ReportEngine%38CD2F480197.postscript

//## begin module%38CD30BE025E.epilog preserve=yes
//## end module%38CD30BE025E.epilog


#endif
