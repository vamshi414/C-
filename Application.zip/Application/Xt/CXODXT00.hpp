//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E5A35E40271.cm preserve=no
//## end module%3E5A35E40271.cm

//## begin module%3E5A35E40271.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3E5A35E40271.cp

//## Module: CXOPXT00%3E5A35E40271; Package specification
//## Subsystem: XT%3E5A35A4029F
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Application\Xt\CXODXT00.hpp

#ifndef CXOPXT00_h
#define CXOPXT00_h 1

//## begin module%3E5A35E40271.additionalIncludes preserve=no
//## end module%3E5A35E40271.additionalIncludes

//## begin module%3E5A35E40271.includes preserve=yes
// $Date:   Jun 28 2013 07:38:48  $ $Author:   e1009839  $ $Revision:   1.10  $
//## end module%3E5A35E40271.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
class Trace;
class Extract;
class Console;
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::CRExtractCommand_CAT%3E5A42B601C5
namespace crextractcommand {
class CRTaskExtract;
class EMSRuleSet;
class EMSRules;
class CommonTableLoad;
class CRRollin;
class CRBuild;
class CRReadCommand;
class CRListCommand;
} // namespace crextractcommand

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;
} // namespace platform

namespace crextractcommand {
class CRUpdateCommand;

} // namespace crextractcommand

//## begin module%3E5A35E40271.declarations preserve=no
//## end module%3E5A35E40271.declarations

//## begin module%3E5A35E40271.additionalDeclarations preserve=yes
//## end module%3E5A35E40271.additionalDeclarations


//## begin CRExtract%3E5A34F80128.preface preserve=yes
//## end CRExtract%3E5A34F80128.preface

//## Class: CRExtract%3E5A34F80128
//	<body>
//	<title>CG
//	<h1>XT
//	<h2>AB
//	<p>
//	The CR Extract service manages the configuration data
//	tables used by the DataNavigator Server.
//	<p>
//	This service:
//	<ul>
//	<li>Populates the configuration data tables during your
//	server installation
//	<li>Updates the configuration data tables as part of a
//	server maintenance update or a version upgrade
//	<li>Rolls in changes by change group
//	<li>Generates database extract files used during the
//	execution of the DataNavigator Server
//	</ul>
//	<h3>System Flow
//	<p>
//	The DataNavigator server executes using production
//	extract files of the Configuration Repository (CR)
//	database.
//	Extract files provide a static set of configuration data
//	used by the server that is unaffected by ongoing
//	maintenance to the database.
//	The extract files contain the following types of
//	information:
//	<ul>
//	<li>Definition of each service in your configuration
//	<li>File locations
//	<li>TCP/IP port numbers
//	<li>Configuration data for download to DataNavigator
//	clients
//	<li>Miscellaneous task options, timers, etc.
//	<li>Microsoft Windows or Unix servers hosting the Data
//	Navigator services
//	</ul>
//	<p>
//	Extract files are created by the CR Extract service (XT)
//	after configuration changes are made using the CR Client
//	for the DataNavigator Server.
//	</p>
//	<img src=CXOCXT00.gif>
//	<p>
//	<h2>FI
//	<h3>Configuration Repository data model:
//	<p>
//	<img src=CXOCCR00.gif>
//	</p>
//	</body>
//	<body>
//	<title>IG
//	<h1>HC
//	<h2>AB
//	<h3>Setup
//	<p>
//	The CR Client for DataNavigator Server is installed for
//	each person responsible for changing the DataNavigator
//	Server configuration.
//	</p>
//	<ol>
//	<li>Start ... Programs ... IBM DB2 ... Set-up Tools ...
//	Configuration Assistant
//	<li>Establish a connection to the DataNavigator database
//	<li>Install the CR Client for DataNavigator Server using
//	the CR Client CD
//	<li>Start ... Programs ... CR Client ... DataNavigator
//	Server
//	</ol>
//	<h2>FI
//	<h3>Installation prerequisites
//	<p>
//	The CR Client for DataNavigator Server requires the
//	following:
//	<ul>
//	<li>Microsoft Windows 2000 or XP
//	<li>IBM UDB Version 8 Client Software
//	</ul>
//	<h2>FO
//	<h3>Results of installation
//	<p>
//	The following items are established during installation:
//	<ol>
//	<li>Connection to the DataNavigator database
//	<li>Program group: CR Client
//	<li>C:\Program Files\eFunds\CR Client
//	</ol>
//	</body>
//	<body>
//	<title>OG
//	<h1>XT
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server executes using production
//	extract files of the Configuration Repository database.
//	<p>
//	<img src=CXOOXT00.gif>
//	</body>
//## Category: Connex Application::CRExtract_CAT%3E5A342302FD
//## Subsystem: XT%3E5A35A4029F
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3E5A3FCE033C;monitor::UseCase { -> F}
//## Uses: <unnamed>%3E5A3FD3001F;database::Database { -> F}
//## Uses: <unnamed>%3E5BC6C9000F;crextractcommand::CRTaskExtract { -> F}
//## Uses: <unnamed>%3E6E17F40222;IF::FlatFile { -> F}
//## Uses: <unnamed>%3EC22E900000;crextractcommand::CRBuild { -> F}
//## Uses: <unnamed>%3EC2312C0271;IF::Trace { -> F}
//## Uses: <unnamed>%3EC3D2AD029F;reusable::Transaction { -> F}
//## Uses: <unnamed>%3ECA051B0196;timer::Clock { -> F}
//## Uses: <unnamed>%3F7C75C30242;crextractcommand::CRRollin { -> F}
//## Uses: <unnamed>%3F7C787B0242;IF::Message { -> F}
//## Uses: <unnamed>%40AA672402DE;platform::Platform { -> F}
//## Uses: <unnamed>%4F5EFF4C020B;crextractcommand::EMSRules { -> F}
//## Uses: <unnamed>%4F68A20F0194;IF::Console { -> F}
//## Uses: <unnamed>%4FD0CECA013C;IF::Extract { -> F}

class CRExtract : public process::Application  //## Inherits: <unnamed>%3E5A35430196
{
  //## begin CRExtract%3E5A34F80128.initialDeclarations preserve=yes
  //## end CRExtract%3E5A34F80128.initialDeclarations

  public:
    //## Constructors (generated)
      CRExtract();

    //## Destructor (generated)
      virtual ~CRExtract();


    //## Other Operations (specified)
      //## Operation: initialize%3E5A3B680290
      virtual int initialize ();

      //## Operation: install%474508610279
      virtual bool install ();

      //## Operation: update%3EC14CF2029F
      //	Interprets the inbound Message and calls:
      //
      //	   Application::onConfirm
      //	   Application::onMessage
      //	   Application::onNotify
      //	   Application::onQuiesce
      //	   Application::onRefresh
      //	   Application::onReset
      //	   Application::shutdown
      //	   Timer::elapsed
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin CRExtract%3E5A34F80128.public preserve=yes
      //## end CRExtract%3E5A34F80128.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%64AC1E2A0088
      virtual int onMessage (Message& hMessage);

      //## Operation: onReset%3EC2B0090000
      //	<body>
      //	<title>OG
      //	<h1>XT
      //	<h2>CD
      //	<h3>Change Group Rollin
      //	<h4>Name
      //	<p>
      //	RESET XT <i>Change ID</i>
      //	<h4>Description
      //	<p>
      //	The CR Extract service reads the DataNavigator CR tables
      //	and generates extract files in the
      //	<i>node001\qualify</i>\Pstage folder.
      //	In the Operator Console Change Management folder, choose
      //	Rollin for your Change ID:
      //	<p>
      //	<img src=CXOOXT01.gif>
      //	</p>
      //	</body>
      virtual int onReset (Message& hMessage);

    // Additional Protected Declarations
      //## begin CRExtract%3E5A34F80128.protected preserve=yes
      //## end CRExtract%3E5A34F80128.protected

  private:
    // Additional Private Declarations
      //## begin CRExtract%3E5A34F80128.private preserve=yes
      //## end CRExtract%3E5A34F80128.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Application::CRExtract_CAT::<unnamed>%48CE5342032C
      //## Role: CRExtract::<m_pCommonTableLoad>%48CE53430280
      //## begin CRExtract::<m_pCommonTableLoad>%48CE53430280.role preserve=no  public: crextractcommand::CommonTableLoad { -> RFHgN}
      crextractcommand::CommonTableLoad *m_pCommonTableLoad;
      //## end CRExtract::<m_pCommonTableLoad>%48CE53430280.role

      //## Association: Connex Application::CRExtract_CAT::<unnamed>%5138F32F00A1
      //## Role: CRExtract::<m_pEMSRuleSet>%5138F32F02C2
      //## begin CRExtract::<m_pEMSRuleSet>%5138F32F02C2.role preserve=no  public: crextractcommand::EMSRuleSet { -> RFHgN}
      crextractcommand::EMSRuleSet *m_pEMSRuleSet;
      //## end CRExtract::<m_pEMSRuleSet>%5138F32F02C2.role

      //## Association: Connex Application::CRExtract_CAT::<unnamed>%64AC1DB603CF
      //## Role: CRExtract::<m_pCRListCommand>%64AC1DB80162
      //## begin CRExtract::<m_pCRListCommand>%64AC1DB80162.role preserve=no  public: crextractcommand::CRListCommand { -> RFHgN}
      crextractcommand::CRListCommand *m_pCRListCommand;
      //## end CRExtract::<m_pCRListCommand>%64AC1DB80162.role

      //## Association: Connex Application::CRExtract_CAT::<unnamed>%64B136190199
      //## Role: CRExtract::<m_pCRReadCommand>%64B1361A0118
      //## begin CRExtract::<m_pCRReadCommand>%64B1361A0118.role preserve=no  public: crextractcommand::CRReadCommand { -> RFHgN}
      crextractcommand::CRReadCommand *m_pCRReadCommand;
      //## end CRExtract::<m_pCRReadCommand>%64B1361A0118.role

      //## Association: Connex Application::CRExtract_CAT::<unnamed>%64B69A0A01B1
      //## Role: CRExtract::<m_pCRUpdateCommand>%64B69A0B0345
      //## begin CRExtract::<m_pCRUpdateCommand>%64B69A0B0345.role preserve=no  public: crextractcommand::CRUpdateCommand { -> RFHgN}
      crextractcommand::CRUpdateCommand *m_pCRUpdateCommand;
      //## end CRExtract::<m_pCRUpdateCommand>%64B69A0B0345.role

    // Additional Implementation Declarations
      //## begin CRExtract%3E5A34F80128.implementation preserve=yes
      //## end CRExtract%3E5A34F80128.implementation

};

//## begin CRExtract%3E5A34F80128.postscript preserve=yes
//## end CRExtract%3E5A34F80128.postscript

//## begin module%3E5A35E40271.epilog preserve=yes
//## end module%3E5A35E40271.epilog


#endif
