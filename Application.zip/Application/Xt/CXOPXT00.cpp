//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E5A35EA007D.cm preserve=no
//## end module%3E5A35EA007D.cm

//## begin module%3E5A35EA007D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3E5A35EA007D.cp

//## Module: CXOPXT00%3E5A35EA007D; Package body
//## Subsystem: XT%3E5A35A4029F
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Application\Xt\CXOPXT00.cpp

//## begin module%3E5A35EA007D.additionalIncludes preserve=no
//## end module%3E5A35EA007D.additionalIncludes

//## begin module%3E5A35EA007D.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
//## end module%3E5A35EA007D.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSXF01_h
#include "CXODXF01.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSXF02_h
#include "CXODXF02.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSXF03_h
#include "CXODXF03.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSXF07_h
#include "CXODXF07.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSXF04_h
#include "CXODXF04.hpp"
#endif
#ifndef CXOSXF08_h
#include "CXODXF08.hpp"
#endif
#ifndef CXOSXF09_h
#include "CXODXF09.hpp"
#endif
#ifndef CXOSXF10_h
#include "CXODXF10.hpp"
#endif
#ifndef CXOSXF12_h
#include "CXODXF12.hpp"
#endif
#ifndef CXOPXT00_h
#include "CXODXT00.hpp"
#endif


//## begin module%3E5A35EA007D.declarations preserve=no
//## end module%3E5A35EA007D.declarations

//## begin module%3E5A35EA007D.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new CRExtract();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%3E5A35EA007D.additionalDeclarations


// Class CRExtract 

CRExtract::CRExtract()
  //## begin CRExtract::CRExtract%3E5A34F80128_const.hasinit preserve=no
      : m_pCommonTableLoad(0),
        m_pEMSRuleSet(0),
        m_pCRListCommand(0),
        m_pCRReadCommand(0),
        m_pCRUpdateCommand(0)
  //## end CRExtract::CRExtract%3E5A34F80128_const.hasinit
  //## begin CRExtract::CRExtract%3E5A34F80128_const.initialization preserve=yes
  //## end CRExtract::CRExtract%3E5A34F80128_const.initialization
{
  //## begin CRExtract::CRExtract%3E5A34F80128_const.body preserve=yes
   memcpy(m_sID,"XT00",4);
  //## end CRExtract::CRExtract%3E5A34F80128_const.body
}


CRExtract::~CRExtract()
{
  //## begin CRExtract::~CRExtract%3E5A34F80128_dest.body preserve=yes
   delete m_pCRUpdateCommand;
   delete m_pCRReadCommand;
   delete m_pCRListCommand;
   delete m_pEMSRuleSet;
   delete m_pCommonTableLoad;
  //## end CRExtract::~CRExtract%3E5A34F80128_dest.body
}



//## Other Operations (implementation)
int CRExtract::initialize ()
{
  //## begin CRExtract::initialize%3E5A3B680290.body preserve=yes
   new platform::Platform();
   new segment::AuditEvent;
   int iRC = Application::initialize();
   UseCase hUseCase("CR","## CR46 START XT");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->attach(this);
   m_pCommonTableLoad = new CommonTableLoad();
   m_pEMSRuleSet = new crextractcommand::EMSRuleSet();
   m_pCRListCommand = new CRListCommand(0);
   m_pCRReadCommand = new CRReadCommand(m_pCRListCommand);
   m_pCRUpdateCommand = new CRUpdateCommand(m_pCRReadCommand);
   Database::instance()->connect();
   return 0;
  //## end CRExtract::initialize%3E5A3B680290.body
}

bool CRExtract::install ()
{
  //## begin CRExtract::install%474508610279.body preserve=yes
   string strTemp(Extract::instance()->getNode001());
#ifdef _WIN32
   string strCommand("copy \"");
   strTemp += "\\";
   strTemp += Extract::instance()->getQualify();
   strTemp += "\\Pprod\\";
   strCommand += strTemp;
   strCommand += "\\*.txt\" \"";
#else
   string strCommand("cp ");
   strTemp += "/";
   strTemp += Extract::instance()->getQualify();
   strTemp += "/Pprod/";
   strCommand += strTemp;
   strCommand += "*.txt ";
#endif
   size_t pos = strTemp.find("Pprod");
   strTemp.replace(pos,5,"Pprev");
   strCommand += strTemp;
   system(strCommand.c_str());
#ifdef _WIN32
   strCommand.replace(0,4,"move");
#else
   strCommand.replace(0,2,"mv");
#endif
   pos = strCommand.find("Pprod");
   strCommand.replace(pos,5,"Pstage");
   pos = strCommand.find("Pprev");
   strCommand.replace(pos,5,"Pprod");
   system(strCommand.c_str());
   return true;
  //## end CRExtract::install%474508610279.body
}

int CRExtract::onMessage (Message& hMessage)
{
  //## begin CRExtract::onMessage%64AC1E2A0088.body preserve=yes
   Transaction::instance()->begin();
   m_pCRUpdateCommand->update(Message::instance(Message::INBOUND));
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      Database::instance()->rollback();
   else
      Database::instance()->commit();
   Transaction::instance()->commit();
   return 0;
  //## end CRExtract::onMessage%64AC1E2A0088.body
}

int CRExtract::onReset (Message& hMessage)
{
  //## begin CRExtract::onReset%3EC2B0090000.body preserve=yes
   reusable::Transaction::instance()->begin();
   reusable::Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSS());
   string strContext((char*)hMessage.context());
   bool bRollinOnly = (strContext.length() > 12 && strContext.substr(0,12) == "ROLLIN_ONLY;");
   if (bRollinOnly)
      strContext.erase(0,12);
   size_t pos = strContext.find(' ');
   if (pos != string::npos)
      strContext.erase(pos);
   Trace::put(strContext.data(),strContext.length());
   if (strContext.length() > 0
      && strContext != "!EXTRACT"
      && strContext != "!INSTALL"
      && strContext != "!REPLACE"
      && strContext != "!UPGRADE"
      && strContext != "!LOAD"
      && strContext != "!RULES")
   {
      CRRollin hCRRollin;
      hCRRollin.setCC_CHANGE_GRP_ID(strContext);
      if (!hCRRollin.execute())
      {
         database::Database::instance()->rollback();
         return 0;
      }
      if (!bRollinOnly)
         strContext = "!EXTRACT";
   }
#ifndef MVS
   if (strContext.length() == 0
      || strContext == "!EXTRACT")
   {
      CRTaskExtract hCRTaskExtract;
      hCRTaskExtract.execute();
   }
#endif
   if (strContext == "!LOAD")
   {
      reusable::Transaction::instance()->begin();
      reusable::Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSS());
      CRBuild hCRBuild;
      if (!hCRBuild.addCustomer("CUST"))
         database::Database::instance()->rollback();
      IF::Extract::instance()->refresh(false);
   }
#ifndef MVS
   if (strContext == "!INSTALL")
      install();
#endif
   if (strContext == "!REPLACE")
      m_pCommonTableLoad->replace();
   if (strContext == "!UPGRADE")
   {
      if (!m_pCommonTableLoad->upgrade())
      {
         database::Database::instance()->rollback();
         return 0;
      }
      if (!m_pEMSRuleSet->upgrade())
      {
         database::Database::instance()->rollback();
         return 0;
      }
   }
   if (strContext == "!RULES")
   {
      if (EMSRules::instance()->rollin(true) == false)
      {
         Console::display("ST603","Rules Rollin");
         database::Database::instance()->rollback();
         return 0;
      }
   }
   database::Database::instance()->commit();
   return 0;
  //## end CRExtract::onReset%3EC2B0090000.body
}

void CRExtract::update (Subject* pSubject)
{
  //## begin CRExtract::update%3EC14CF2029F.body preserve=yes
   if (pSubject == Database::instance()
      && Database::instance()->state() == Database::CONNECTED)
   {
      {
         reusable::Transaction::instance()->begin();
         reusable::Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSS());
         CRBuild hCRBuild;
         if (!hCRBuild.execute())
         {
            database::Database::instance()->rollback();
            return;
         }
         database::Database::instance()->commit();
      }
      m_pCommonTableLoad->update(pSubject);
      database::Database::instance()->commit();

      if (EMSRules::instance()->rollin() == false)
         database::Database::instance()->rollback();
      else
         database::Database::instance()->commit();
      return;
   }
   Application::update(pSubject);
  //## end CRExtract::update%3EC14CF2029F.body
}

// Additional Declarations
  //## begin CRExtract%3E5A34F80128.declarations preserve=yes
  //## end CRExtract%3E5A34F80128.declarations

//## begin module%3E5A35EA007D.epilog preserve=yes
//## end module%3E5A35EA007D.epilog
