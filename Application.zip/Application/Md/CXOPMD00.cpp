//	Copyright (c) 1998 - 2004
//	eFunds Corporation
// $Date:   Sep 23 2013 10:24:04  $ $Author:   e1009510  $ $Revision:   1.0  $
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif

#include "CXODIF11.hpp"
#include "CXODSI01.hpp"
#include "CXODMP08.hpp"
#include "CXODMN05.hpp"
#include "CXODDZ01.hpp"

#include "CXODPS06.hpp"
   pApplication = new SwitchInterface();
   pApplication->parseCommandLine(argc,argv);
   new dnplatform::DNPlatform();
   ((SwitchInterface*)pApplication)->setMessageProcessor(new MasterCardDraftCaptureMessageProcessor);
   int iRC = 0;
   {
      iRC = pApplication->initialize();
      UseCase hUseCase("MC","## MC04 START MD");
      if (iRC == -1)
         UseCase::setSuccess(false);
   }
   if (iRC == 0)
      pApplication->run();
#include "CXODPS07.hpp"

